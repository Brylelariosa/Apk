//! CPU-side batch of textured, coloured quads (screen-space pixels, origin top-left).
//!
//! Text and filled rectangles both sample the font atlas, so a whole overlay is
//! one vertex stream and one draw call. Pure Rust: unit-tested on the host.

use crate::font;

/// RGBA, 8 bits per channel, straight (non-premultiplied) alpha.
pub type Color = [u8; 4];

/// One vertex: position in pixels, texture coordinate, colour. 20 bytes, no padding.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Vertex {
    pub x: f32,
    pub y: f32,
    pub u: f32,
    pub v: f32,
    pub rgba: [u8; 4],
}

pub const VERTEX_STRIDE: usize = core::mem::size_of::<Vertex>();

pub struct DrawList {
    verts: Vec<Vertex>,
}

impl DrawList {
    pub fn with_capacity_quads(quads: usize) -> Self {
        Self {
            verts: Vec::with_capacity(quads * 6),
        }
    }

    pub fn clear(&mut self) {
        self.verts.clear();
    }

    pub fn vertices(&self) -> &[Vertex] {
        &self.verts
    }

    pub fn len(&self) -> usize {
        self.verts.len()
    }

    pub fn is_empty(&self) -> bool {
        self.verts.is_empty()
    }

    fn quad(&mut self, x0: f32, y0: f32, x1: f32, y1: f32, uv: [f32; 4], rgba: Color) {
        let [u0, v0, u1, v1] = uv;
        let tl = Vertex { x: x0, y: y0, u: u0, v: v0, rgba };
        let tr = Vertex { x: x1, y: y0, u: u1, v: v0, rgba };
        let bl = Vertex { x: x0, y: y1, u: u0, v: v1, rgba };
        let br = Vertex { x: x1, y: y1, u: u1, v: v1, rgba };
        self.verts.extend_from_slice(&[tl, tr, bl, tr, br, bl]);
    }

    /// Filled rectangle.
    pub fn rect(&mut self, x: f32, y: f32, w: f32, h: f32, rgba: Color) {
        let (ox, oy) = font::cell_origin(font::SOLID_INDEX);
        // Sample the centre of the solid cell: every texel there is opaque.
        let u = (ox as f32 + font::CELL_W as f32 * 0.5) / font::ATLAS_W as f32;
        let v = (oy as f32 + font::CELL_H as f32 * 0.5) / font::ATLAS_H as f32;
        self.quad(x, y, x + w, y + h, [u, v, u, v], rgba);
    }

    /// Single-line text. `scale` is screen pixels per font pixel; spaces draw nothing.
    pub fn text(&mut self, x: f32, y: f32, scale: f32, rgba: Color, s: &str) {
        let mut cx = x;
        for ch in s.chars() {
            let index = font::glyph_index(ch);
            if index != 0 {
                let w = font::GLYPH_W as f32 * scale;
                let h = font::GLYPH_H as f32 * scale;
                self.quad(cx, y, cx + w, y + h, font::glyph_uv(index), rgba);
            }
            cx += font::CELL_W as f32 * scale;
        }
    }

    /// Width in pixels of `s` when drawn with [`DrawList::text`].
    pub fn text_width(s: &str, scale: f32) -> f32 {
        s.chars().count() as f32 * font::CELL_W as f32 * scale
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const WHITE: Color = [255, 255, 255, 255];

    #[test]
    fn vertex_is_tightly_packed() {
        assert_eq!(VERTEX_STRIDE, 20);
    }

    #[test]
    fn rect_is_two_triangles() {
        let mut l = DrawList::with_capacity_quads(4);
        l.rect(1.0, 2.0, 10.0, 20.0, WHITE);
        assert_eq!(l.len(), 6);
        let v = l.vertices();
        assert_eq!((v[0].x, v[0].y), (1.0, 2.0));
        assert_eq!((v[4].x, v[4].y), (11.0, 22.0));
    }

    #[test]
    fn text_skips_spaces() {
        let mut l = DrawList::with_capacity_quads(8);
        l.text(0.0, 0.0, 2.0, WHITE, "A B");
        assert_eq!(l.len(), 12);
        // 'B' starts two cells (2 * 6 * 2 px) to the right.
        assert_eq!(l.vertices()[6].x, 24.0);
    }

    #[test]
    fn text_width_counts_chars() {
        assert_eq!(DrawList::text_width("abc", 2.0), 36.0);
        assert_eq!(DrawList::text_width("", 3.0), 0.0);
    }

    #[test]
    fn clear_keeps_capacity_and_empties() {
        let mut l = DrawList::with_capacity_quads(4);
        l.rect(0.0, 0.0, 1.0, 1.0, WHITE);
        l.clear();
        assert!(l.is_empty());
    }
}
