//! OpenGL ES 2.0 uploader for a [`DrawList`] plus a GPU-info query.
//!
//! Every function here needs a current GLES2 context on the calling thread.
//! There is deliberately no `Drop`: after a context loss the GL objects are already
//! gone and must not be touched; call [`DebugRenderer::destroy`] only while the
//! context is current.

use core::ffi::{c_char, c_void, CStr};

use crate::draw_list::{DrawList, VERTEX_STRIDE};
use crate::font;
use crate::gl;

const VERTEX_SHADER_SRC: &str = "\
attribute vec2 a_pos;
attribute vec2 a_uv;
attribute vec4 a_color;
uniform vec2 u_scale;
varying vec2 v_uv;
varying vec4 v_color;
void main() {
    gl_Position = vec4(a_pos.x * u_scale.x - 1.0, 1.0 - a_pos.y * u_scale.y, 0.0, 1.0);
    v_uv = a_uv;
    v_color = a_color;
}
";

const FRAGMENT_SHADER_SRC: &str = "\
precision mediump float;
uniform sampler2D u_tex;
varying vec2 v_uv;
varying vec4 v_color;
void main() {
    float a = texture2D(u_tex, v_uv).a;
    gl_FragColor = vec4(v_color.rgb, v_color.a * a);
}
";

/// Strings and limits reported by the GL driver.
#[derive(Clone, Debug, Default)]
pub struct GlInfo {
    pub vendor: String,
    pub renderer: String,
    pub version: String,
    pub glsl: String,
    pub extensions: String,
    pub max_texture_size: i32,
    pub max_vertex_attribs: i32,
    pub max_varying_vectors: i32,
    pub max_vertex_uniform_vectors: i32,
    pub max_fragment_uniform_vectors: i32,
    pub max_texture_units: i32,
}

impl GlInfo {
    pub fn query() -> Self {
        // SAFETY: plain state queries on the current context.
        unsafe {
            Self {
                vendor: get_string(gl::VENDOR),
                renderer: get_string(gl::RENDERER),
                version: get_string(gl::VERSION),
                glsl: get_string(gl::SHADING_LANGUAGE_VERSION),
                extensions: get_string(gl::EXTENSIONS),
                max_texture_size: get_int(gl::MAX_TEXTURE_SIZE),
                max_vertex_attribs: get_int(gl::MAX_VERTEX_ATTRIBS),
                max_varying_vectors: get_int(gl::MAX_VARYING_VECTORS),
                max_vertex_uniform_vectors: get_int(gl::MAX_VERTEX_UNIFORM_VECTORS),
                max_fragment_uniform_vectors: get_int(gl::MAX_FRAGMENT_UNIFORM_VECTORS),
                max_texture_units: get_int(gl::MAX_TEXTURE_IMAGE_UNITS),
            }
        }
    }
}

unsafe fn get_string(name: gl::GLenum) -> String {
    let p = gl::glGetString(name);
    if p.is_null() {
        String::new()
    } else {
        CStr::from_ptr(p as *const c_char)
            .to_string_lossy()
            .into_owned()
    }
}

unsafe fn get_int(name: gl::GLenum) -> i32 {
    let mut value: gl::GLint = 0;
    gl::glGetIntegerv(name, &mut value);
    value
}

pub struct DebugRenderer {
    program: gl::GLuint,
    vbo: gl::GLuint,
    texture: gl::GLuint,
    u_scale: gl::GLint,
    u_tex: gl::GLint,
}

impl DebugRenderer {
    pub fn new() -> Result<Self, String> {
        // SAFETY: requires a current GLES2 context (documented on the module).
        unsafe {
            let vs = compile(gl::VERTEX_SHADER, VERTEX_SHADER_SRC)?;
            let fs = match compile(gl::FRAGMENT_SHADER, FRAGMENT_SHADER_SRC) {
                Ok(fs) => fs,
                Err(e) => {
                    gl::glDeleteShader(vs);
                    return Err(e);
                }
            };

            let program = gl::glCreateProgram();
            gl::glAttachShader(program, vs);
            gl::glAttachShader(program, fs);
            gl::glBindAttribLocation(program, 0, b"a_pos\0".as_ptr() as *const c_char);
            gl::glBindAttribLocation(program, 1, b"a_uv\0".as_ptr() as *const c_char);
            gl::glBindAttribLocation(program, 2, b"a_color\0".as_ptr() as *const c_char);
            gl::glLinkProgram(program);
            gl::glDeleteShader(vs);
            gl::glDeleteShader(fs);

            let mut linked: gl::GLint = 0;
            gl::glGetProgramiv(program, gl::LINK_STATUS, &mut linked);
            if linked == 0 {
                let log = program_log(program);
                gl::glDeleteProgram(program);
                return Err(format!("program link failed: {log}"));
            }
            let u_scale = gl::glGetUniformLocation(program, b"u_scale\0".as_ptr() as *const c_char);
            let u_tex = gl::glGetUniformLocation(program, b"u_tex\0".as_ptr() as *const c_char);

            let mut vbo: gl::GLuint = 0;
            gl::glGenBuffers(1, &mut vbo);

            let mut texture: gl::GLuint = 0;
            gl::glGenTextures(1, &mut texture);
            gl::glBindTexture(gl::TEXTURE_2D, texture);
            gl::glTexParameteri(gl::TEXTURE_2D, gl::TEXTURE_MIN_FILTER, gl::NEAREST as gl::GLint);
            gl::glTexParameteri(gl::TEXTURE_2D, gl::TEXTURE_MAG_FILTER, gl::NEAREST as gl::GLint);
            gl::glTexParameteri(gl::TEXTURE_2D, gl::TEXTURE_WRAP_S, gl::CLAMP_TO_EDGE as gl::GLint);
            gl::glTexParameteri(gl::TEXTURE_2D, gl::TEXTURE_WRAP_T, gl::CLAMP_TO_EDGE as gl::GLint);
            gl::glPixelStorei(gl::UNPACK_ALIGNMENT, 1);
            let atlas = font::build_atlas();
            gl::glTexImage2D(
                gl::TEXTURE_2D,
                0,
                gl::ALPHA as gl::GLint,
                font::ATLAS_W as gl::GLsizei,
                font::ATLAS_H as gl::GLsizei,
                0,
                gl::ALPHA,
                gl::UNSIGNED_BYTE,
                atlas.as_ptr() as *const c_void,
            );

            let error = gl::glGetError();
            if error != 0 {
                return Err(format!("GL error 0x{error:04x} during renderer setup"));
            }
            Ok(Self {
                program,
                vbo,
                texture,
                u_scale,
                u_tex,
            })
        }
    }

    /// Sets the viewport and clears the colour buffer.
    pub fn begin_frame(&mut self, width: i32, height: i32, clear: [f32; 4]) {
        // SAFETY: requires a current context (module contract).
        unsafe {
            gl::glViewport(0, 0, width, height);
            gl::glClearColor(clear[0], clear[1], clear[2], clear[3]);
            gl::glClear(gl::COLOR_BUFFER_BIT);
        }
    }

    /// Draws the list in one call. Coordinates are pixels with the origin top-left.
    pub fn draw(&mut self, list: &DrawList, width: i32, height: i32) {
        let verts = list.vertices();
        if verts.is_empty() || width <= 0 || height <= 0 {
            return;
        }
        // SAFETY: requires a current context; `verts` is a live slice of repr(C) vertices.
        unsafe {
            gl::glEnable(gl::BLEND);
            gl::glBlendFunc(gl::SRC_ALPHA, gl::ONE_MINUS_SRC_ALPHA);
            gl::glUseProgram(self.program);
            gl::glUniform2f(self.u_scale, 2.0 / width as f32, 2.0 / height as f32);
            gl::glActiveTexture(gl::TEXTURE0);
            gl::glBindTexture(gl::TEXTURE_2D, self.texture);
            gl::glUniform1i(self.u_tex, 0);

            gl::glBindBuffer(gl::ARRAY_BUFFER, self.vbo);
            gl::glBufferData(
                gl::ARRAY_BUFFER,
                (verts.len() * VERTEX_STRIDE) as gl::GLsizeiptr,
                verts.as_ptr() as *const c_void,
                gl::STREAM_DRAW,
            );
            let stride = VERTEX_STRIDE as gl::GLsizei;
            gl::glEnableVertexAttribArray(0);
            gl::glVertexAttribPointer(0, 2, gl::FLOAT, gl::FALSE, stride, core::ptr::null());
            gl::glEnableVertexAttribArray(1);
            gl::glVertexAttribPointer(1, 2, gl::FLOAT, gl::FALSE, stride, 8usize as *const c_void);
            gl::glEnableVertexAttribArray(2);
            gl::glVertexAttribPointer(
                2,
                4,
                gl::UNSIGNED_BYTE,
                gl::TRUE,
                stride,
                16usize as *const c_void,
            );
            gl::glDrawArrays(gl::TRIANGLES, 0, verts.len() as gl::GLsizei);
            gl::glDisableVertexAttribArray(0);
            gl::glDisableVertexAttribArray(1);
            gl::glDisableVertexAttribArray(2);
            gl::glBindBuffer(gl::ARRAY_BUFFER, 0);
            gl::glDisable(gl::BLEND);
        }
    }

    /// Frees the GL objects. Only call while the context that created them is current.
    pub fn destroy(self) {
        // SAFETY: requires the owning context to be current (documented above).
        unsafe {
            gl::glDeleteProgram(self.program);
            gl::glDeleteBuffers(1, &self.vbo);
            gl::glDeleteTextures(1, &self.texture);
        }
    }
}

unsafe fn compile(kind: gl::GLenum, source: &str) -> Result<gl::GLuint, String> {
    let shader = gl::glCreateShader(kind);
    let ptr = source.as_ptr() as *const gl::GLchar;
    let len = source.len() as gl::GLint;
    gl::glShaderSource(shader, 1, &ptr, &len);
    gl::glCompileShader(shader);
    let mut ok: gl::GLint = 0;
    gl::glGetShaderiv(shader, gl::COMPILE_STATUS, &mut ok);
    if ok == 0 {
        let log = shader_log(shader);
        gl::glDeleteShader(shader);
        return Err(format!("shader compile failed: {log}"));
    }
    Ok(shader)
}

unsafe fn shader_log(shader: gl::GLuint) -> String {
    let mut len: gl::GLint = 0;
    gl::glGetShaderiv(shader, gl::INFO_LOG_LENGTH, &mut len);
    let mut buf = vec![0u8; len.max(1) as usize];
    let mut written: gl::GLsizei = 0;
    gl::glGetShaderInfoLog(shader, buf.len() as gl::GLsizei, &mut written, buf.as_mut_ptr() as *mut gl::GLchar);
    buf.truncate(written.max(0) as usize);
    String::from_utf8_lossy(&buf).into_owned()
}

unsafe fn program_log(program: gl::GLuint) -> String {
    let mut len: gl::GLint = 0;
    gl::glGetProgramiv(program, gl::INFO_LOG_LENGTH, &mut len);
    let mut buf = vec![0u8; len.max(1) as usize];
    let mut written: gl::GLsizei = 0;
    gl::glGetProgramInfoLog(program, buf.len() as gl::GLsizei, &mut written, buf.as_mut_ptr() as *mut gl::GLchar);
    buf.truncate(written.max(0) as usize);
    String::from_utf8_lossy(&buf).into_owned()
}
