//! Small text-layout helpers (pure Rust).

/// Greedy word wrap of whitespace-separated words into lines of at most `max_chars`
/// characters. A single word longer than the limit gets a line of its own.
pub fn wrap_words(s: &str, max_chars: usize) -> Vec<String> {
    let max_chars = max_chars.max(1);
    let mut lines = Vec::new();
    let mut cur = String::new();
    let mut cur_len = 0usize;
    for word in s.split_whitespace() {
        let word_len = word.chars().count();
        if cur_len > 0 && cur_len + 1 + word_len > max_chars {
            lines.push(std::mem::take(&mut cur));
            cur_len = 0;
        }
        if cur_len > 0 {
            cur.push(' ');
            cur_len += 1;
        }
        cur.push_str(word);
        cur_len += word_len;
    }
    if !cur.is_empty() {
        lines.push(cur);
    }
    lines
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wraps_at_limit() {
        assert_eq!(wrap_words("aa bb cc dd", 5), vec!["aa bb", "cc dd"]);
    }

    #[test]
    fn empty_input_gives_no_lines() {
        assert!(wrap_words("", 10).is_empty());
        assert!(wrap_words("   ", 10).is_empty());
    }

    #[test]
    fn long_word_gets_its_own_line() {
        assert_eq!(wrap_words("a verylongword b", 4), vec!["a", "verylongword", "b"]);
    }

    #[test]
    fn zero_limit_is_treated_as_one() {
        assert_eq!(wrap_words("a b", 0), vec!["a", "b"]);
    }
}
