//! Measurement primitives for the Rust-vs-original comparison.
//!
//! * [`frame`]: ring buffer of per-frame timings and summary statistics.
//! * [`procfs`]: process CPU, memory and start-up time from `/proc`.
//!
//! No `unsafe`, no allocation on the per-frame path.
#![forbid(unsafe_code)]

pub mod frame;
pub mod procfs;

pub use frame::{FrameRecorder, FrameStats};
pub use procfs::{CpuMeter, MemSample};
