//! Fixed-capacity ring buffer of per-frame timings and summary statistics.
//!
//! Two series are kept per frame, both in microseconds:
//! * `interval`: time between consecutive buffer swaps (what the display sees);
//! * `work`: CPU time spent before the swap call (what the app itself costs).
//!
//! `push` never allocates. `stats` sorts a reusable scratch buffer, so call it a
//! few times per second rather than every frame.

pub struct FrameRecorder {
    interval_us: Vec<u32>,
    work_us: Vec<u32>,
    head: usize,
    len: usize,
    total: u64,
    scratch: Vec<u32>,
}

/// Summary of the frames currently held by a [`FrameRecorder`].
///
/// "1% low" is 1 / (mean interval of the slowest 1% of frames, at least one frame).
/// Percentiles use the nearest-rank method.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct FrameStats {
    pub samples: usize,
    pub avg_ms: f32,
    pub avg_fps: f32,
    pub min_fps: f32,
    pub low1_fps: f32,
    pub p50_ms: f32,
    pub p95_ms: f32,
    pub p99_ms: f32,
    pub max_ms: f32,
    pub stddev_ms: f32,
    pub work_avg_ms: f32,
    pub work_p99_ms: f32,
}

impl FrameRecorder {
    pub fn new(capacity: usize) -> Self {
        let capacity = capacity.max(1);
        Self {
            interval_us: vec![0; capacity],
            work_us: vec![0; capacity],
            head: 0,
            len: 0,
            total: 0,
            scratch: Vec::with_capacity(capacity),
        }
    }

    pub fn capacity(&self) -> usize {
        self.interval_us.len()
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Frames pushed since creation (not limited by the ring capacity).
    pub fn total_frames(&self) -> u64 {
        self.total
    }

    pub fn push(&mut self, interval_us: u32, work_us: u32) {
        self.interval_us[self.head] = interval_us;
        self.work_us[self.head] = work_us;
        self.head = (self.head + 1) % self.interval_us.len();
        if self.len < self.interval_us.len() {
            self.len += 1;
        }
        self.total += 1;
    }

    /// Intervals oldest-to-newest as two contiguous slices (read them in order).
    pub fn intervals_ordered(&self) -> (&[u32], &[u32]) {
        ordered(&self.interval_us, self.head, self.len)
    }

    pub fn stats(&mut self) -> FrameStats {
        if self.len == 0 {
            return FrameStats::default();
        }

        // Interval series.
        let (a, b) = ordered(&self.interval_us, self.head, self.len);
        self.scratch.clear();
        self.scratch.extend_from_slice(a);
        self.scratch.extend_from_slice(b);
        self.scratch.sort_unstable();
        let s = &self.scratch;
        let n = s.len();
        let mean = mean_us(s);
        let var = s
            .iter()
            .map(|&v| {
                let d = v as f64 - mean;
                d * d
            })
            .sum::<f64>()
            / n as f64;
        let max_us = s[n - 1];
        let k = ((n + 99) / 100).clamp(1, n);
        let worst_mean = s[n - k..].iter().map(|&v| v as f64).sum::<f64>() / k as f64;
        let p50 = percentile(s, 50);
        let p95 = percentile(s, 95);
        let p99 = percentile(s, 99);

        // Work series.
        let (wa, wb) = ordered(&self.work_us, self.head, self.len);
        self.scratch.clear();
        self.scratch.extend_from_slice(wa);
        self.scratch.extend_from_slice(wb);
        self.scratch.sort_unstable();
        let w = &self.scratch;
        let work_mean = mean_us(w);
        let work_p99 = percentile(w, 99);

        FrameStats {
            samples: n,
            avg_ms: to_ms(mean),
            avg_fps: to_fps(mean),
            min_fps: to_fps(max_us as f64),
            low1_fps: to_fps(worst_mean),
            p50_ms: to_ms(p50 as f64),
            p95_ms: to_ms(p95 as f64),
            p99_ms: to_ms(p99 as f64),
            max_ms: to_ms(max_us as f64),
            stddev_ms: to_ms(var.sqrt()),
            work_avg_ms: to_ms(work_mean),
            work_p99_ms: to_ms(work_p99 as f64),
        }
    }
}

/// Splits the ring into (older part, newer part). Reading both in order yields oldest-to-newest.
fn ordered(buf: &[u32], head: usize, len: usize) -> (&[u32], &[u32]) {
    if len < buf.len() {
        (&buf[..len], &[])
    } else {
        (&buf[head..], &buf[..head])
    }
}

fn mean_us(values: &[u32]) -> f64 {
    values.iter().map(|&v| v as f64).sum::<f64>() / values.len() as f64
}

/// Nearest-rank percentile of an ascending slice; `pct` is an integer percentage.
fn percentile(sorted: &[u32], pct: usize) -> u32 {
    let n = sorted.len();
    let rank = (pct * n + 99) / 100;
    sorted[rank.clamp(1, n) - 1]
}

fn to_ms(us: f64) -> f32 {
    (us / 1000.0) as f32
}

fn to_fps(us: f64) -> f32 {
    if us > 0.0 {
        (1_000_000.0 / us) as f32
    } else {
        0.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn near(a: f32, b: f32) -> bool {
        (a - b).abs() < 0.01
    }

    #[test]
    fn steady_60hz() {
        let mut r = FrameRecorder::new(8);
        for _ in 0..8 {
            r.push(16_667, 1_000);
        }
        let s = r.stats();
        assert_eq!(s.samples, 8);
        assert!(near(s.avg_fps, 60.0), "{}", s.avg_fps);
        assert!(near(s.min_fps, 60.0));
        assert!(near(s.low1_fps, 60.0));
        assert!(near(s.p99_ms, 16.667));
        assert!(near(s.stddev_ms, 0.0));
        assert!(near(s.work_avg_ms, 1.0));
    }

    #[test]
    fn one_outlier_drives_low_and_min() {
        let mut r = FrameRecorder::new(100);
        for _ in 0..99 {
            r.push(10_000, 500);
        }
        r.push(100_000, 500);
        let s = r.stats();
        assert_eq!(s.samples, 100);
        assert!(near(s.low1_fps, 10.0), "{}", s.low1_fps);
        assert!(near(s.min_fps, 10.0));
        assert!(near(s.p50_ms, 10.0));
        assert!(near(s.p99_ms, 10.0));
        assert!(near(s.max_ms, 100.0));
        assert!(near(s.avg_ms, 10.9));
    }

    #[test]
    fn slowest_one_percent_scales_with_sample_count() {
        // 200 frames: slowest 1% = 2 frames, both 40 ms -> 25 fps.
        let mut r = FrameRecorder::new(200);
        for _ in 0..198 {
            r.push(10_000, 0);
        }
        r.push(40_000, 0);
        r.push(40_000, 0);
        let s = r.stats();
        assert!(near(s.low1_fps, 25.0), "{}", s.low1_fps);
    }

    #[test]
    fn ring_wraps_and_keeps_order() {
        let mut r = FrameRecorder::new(4);
        for v in 1..=6u32 {
            r.push(v, v);
        }
        let (a, b) = r.intervals_ordered();
        let all: Vec<u32> = a.iter().chain(b.iter()).copied().collect();
        assert_eq!(all, vec![3, 4, 5, 6]);
        assert_eq!(r.total_frames(), 6);
        assert_eq!(r.len(), 4);
        assert_eq!(r.capacity(), 4);
    }

    #[test]
    fn empty_recorder_gives_default_stats() {
        let mut r = FrameRecorder::new(4);
        assert!(r.is_empty());
        assert_eq!(r.stats(), FrameStats::default());
    }
}
