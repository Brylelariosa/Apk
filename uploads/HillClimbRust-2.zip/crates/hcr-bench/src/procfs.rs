//! Process metrics from `/proc` (Linux and Android). The parsers are pure so they
//! can be unit-tested on the host; the `read_*` functions touch the file system.

use std::time::Instant;

/// Kernel clock ticks per second as exposed in `/proc` (USER_HZ): 100 on Linux and Android.
pub const USER_HZ: u64 = 100;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ProcStat {
    /// User-mode CPU time in ticks.
    pub utime: u64,
    /// Kernel-mode CPU time in ticks.
    pub stime: u64,
    /// Process start, in ticks since boot.
    pub starttime: u64,
}

/// Parses `/proc/<pid>/stat`. The command name (field 2) may contain spaces and
/// parentheses, so parsing resumes after the last `)`.
pub fn parse_proc_stat(text: &str) -> Option<ProcStat> {
    let rest = &text[text.rfind(')')? + 1..];
    let mut it = rest.split_whitespace();
    // `rest` starts at field 3 (state); field n is index n - 3.
    let utime = it.nth(11)?.parse().ok()?; // field 14
    let stime = it.next()?.parse().ok()?; // field 15
    let starttime = it.nth(6)?.parse().ok()?; // field 22
    Some(ProcStat {
        utime,
        stime,
        starttime,
    })
}

/// Reads a `Key:   123 kB` line from `/proc/<pid>/status`.
pub fn parse_status_kb(text: &str, key: &str) -> Option<u64> {
    text.lines().find_map(|line| {
        let rest = line.strip_prefix(key)?.strip_prefix(':')?;
        rest.split_whitespace().next()?.parse().ok()
    })
}

/// First field of `/proc/uptime`: seconds since boot.
pub fn parse_uptime_secs(text: &str) -> Option<f64> {
    text.split_whitespace().next()?.parse().ok()
}

pub fn read_proc_stat() -> Option<ProcStat> {
    parse_proc_stat(&std::fs::read_to_string("/proc/self/stat").ok()?)
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct MemSample {
    pub rss_kb: u64,
    pub peak_rss_kb: u64,
}

/// Resident set size and its peak, from `/proc/self/status` (page-size independent).
pub fn read_mem() -> Option<MemSample> {
    let text = std::fs::read_to_string("/proc/self/status").ok()?;
    Some(MemSample {
        rss_kb: parse_status_kb(&text, "VmRSS")?,
        peak_rss_kb: parse_status_kb(&text, "VmHWM")?,
    })
}

/// Milliseconds since this process was created (10 ms tick resolution).
pub fn process_age_ms() -> Option<f64> {
    let uptime = parse_uptime_secs(&std::fs::read_to_string("/proc/uptime").ok()?)?;
    let started = read_proc_stat()?.starttime as f64 / USER_HZ as f64;
    Some(((uptime - started) * 1000.0).max(0.0))
}

/// Process CPU usage between successive `sample` calls.
pub struct CpuMeter {
    last_ticks: u64,
    last_at: Instant,
}

impl CpuMeter {
    pub fn new() -> Self {
        let ticks = read_proc_stat().map_or(0, |s| s.utime + s.stime);
        Self {
            last_ticks: ticks,
            last_at: Instant::now(),
        }
    }

    /// Percent of ONE core used since the previous call (can exceed 100 on multi-core).
    pub fn sample(&mut self) -> Option<f32> {
        let stat = read_proc_stat()?;
        let ticks = stat.utime + stat.stime;
        let now = Instant::now();
        let dt = now.duration_since(self.last_at).as_secs_f64();
        let dticks = ticks.saturating_sub(self.last_ticks);
        self.last_ticks = ticks;
        self.last_at = now;
        if dt <= 0.0 {
            return None;
        }
        Some((dticks as f64 / USER_HZ as f64 / dt * 100.0) as f32)
    }
}

impl Default for CpuMeter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_stat_with_spaces_and_parens_in_comm() {
        let s = "1234 (hcr app (x)) S 1 1234 1234 0 -1 4194560 1000 0 0 0 150 50 0 0 20 0 8 0 987654 1000000 500";
        assert_eq!(
            parse_proc_stat(s),
            Some(ProcStat {
                utime: 150,
                stime: 50,
                starttime: 987654
            })
        );
    }

    #[test]
    fn rejects_truncated_stat() {
        assert_eq!(parse_proc_stat("1 (x) S 1 2 3"), None);
        assert_eq!(parse_proc_stat("garbage"), None);
    }

    #[test]
    fn parses_status_values() {
        let s = "Name:\thcr\nVmPeak:\t  900 kB\nVmRSS:\t  12345 kB\nVmHWM:\t 20000 kB\n";
        assert_eq!(parse_status_kb(s, "VmRSS"), Some(12345));
        assert_eq!(parse_status_kb(s, "VmHWM"), Some(20000));
        assert_eq!(parse_status_kb(s, "Nope"), None);
    }

    #[test]
    fn parses_uptime() {
        assert_eq!(parse_uptime_secs("12345.67 54321.00\n"), Some(12345.67));
        assert_eq!(parse_uptime_secs(""), None);
    }
}
