//! Minimal EGL wrapper: one display, one OpenGL ES 2.0 context, one window surface.
//! Links the NDK's libEGL. All EGL `unsafe` is confined to this file.

use core::ffi::{c_char, c_void, CStr};
use core::ptr;

type EGLint = i32;
type EGLBoolean = u32;
type EGLDisplay = *mut c_void;
type EGLConfig = *mut c_void;
type EGLSurface = *mut c_void;
type EGLContext = *mut c_void;

const EGL_FALSE: EGLBoolean = 0;
const EGL_NONE: EGLint = 0x3038;
const EGL_SURFACE_TYPE: EGLint = 0x3033;
const EGL_WINDOW_BIT: EGLint = 0x0004;
const EGL_RENDERABLE_TYPE: EGLint = 0x3040;
const EGL_OPENGL_ES2_BIT: EGLint = 0x0004;
const EGL_RED_SIZE: EGLint = 0x3024;
const EGL_GREEN_SIZE: EGLint = 0x3023;
const EGL_BLUE_SIZE: EGLint = 0x3022;
const EGL_ALPHA_SIZE: EGLint = 0x3021;
const EGL_DEPTH_SIZE: EGLint = 0x3025;
const EGL_STENCIL_SIZE: EGLint = 0x3026;
const EGL_SAMPLES: EGLint = 0x3031;
const EGL_CONTEXT_CLIENT_VERSION: EGLint = 0x3098;
const EGL_WIDTH: EGLint = 0x3057;
const EGL_HEIGHT: EGLint = 0x3056;
const EGL_VENDOR: EGLint = 0x3053;
const EGL_VERSION: EGLint = 0x3054;
const EGL_CLIENT_APIS: EGLint = 0x308D;
const EGL_BAD_NATIVE_WINDOW: EGLint = 0x300B;
const EGL_BAD_SURFACE: EGLint = 0x300D;
const EGL_CONTEXT_LOST: EGLint = 0x300E;

#[link(name = "EGL")]
extern "C" {
    fn eglGetDisplay(display_id: *mut c_void) -> EGLDisplay;
    fn eglInitialize(dpy: EGLDisplay, major: *mut EGLint, minor: *mut EGLint) -> EGLBoolean;
    fn eglTerminate(dpy: EGLDisplay) -> EGLBoolean;
    fn eglQueryString(dpy: EGLDisplay, name: EGLint) -> *const c_char;
    fn eglChooseConfig(
        dpy: EGLDisplay,
        attrib_list: *const EGLint,
        configs: *mut EGLConfig,
        config_size: EGLint,
        num_config: *mut EGLint,
    ) -> EGLBoolean;
    fn eglGetConfigAttrib(
        dpy: EGLDisplay,
        config: EGLConfig,
        attribute: EGLint,
        value: *mut EGLint,
    ) -> EGLBoolean;
    fn eglCreateWindowSurface(
        dpy: EGLDisplay,
        config: EGLConfig,
        win: *mut c_void,
        attrib_list: *const EGLint,
    ) -> EGLSurface;
    fn eglCreateContext(
        dpy: EGLDisplay,
        config: EGLConfig,
        share_context: EGLContext,
        attrib_list: *const EGLint,
    ) -> EGLContext;
    fn eglMakeCurrent(
        dpy: EGLDisplay,
        draw: EGLSurface,
        read: EGLSurface,
        ctx: EGLContext,
    ) -> EGLBoolean;
    fn eglSwapBuffers(dpy: EGLDisplay, surface: EGLSurface) -> EGLBoolean;
    fn eglSwapInterval(dpy: EGLDisplay, interval: EGLint) -> EGLBoolean;
    fn eglDestroySurface(dpy: EGLDisplay, surface: EGLSurface) -> EGLBoolean;
    fn eglDestroyContext(dpy: EGLDisplay, ctx: EGLContext) -> EGLBoolean;
    fn eglQuerySurface(
        dpy: EGLDisplay,
        surface: EGLSurface,
        attribute: EGLint,
        value: *mut EGLint,
    ) -> EGLBoolean;
    fn eglGetError() -> EGLint;
}

/// Facts about the EGL implementation and the chosen framebuffer config.
#[derive(Clone, Debug, Default)]
pub struct EglInfo {
    pub vendor: String,
    pub version: String,
    pub client_apis: String,
    pub red: i32,
    pub green: i32,
    pub blue: i32,
    pub alpha: i32,
    pub depth: i32,
    pub stencil: i32,
    pub samples: i32,
}

/// Result of presenting a frame.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SwapOutcome {
    Presented,
    /// The window went away; wait for a new one.
    SurfaceLost,
    /// The GL context is gone; every GL object must be rebuilt.
    ContextLost,
    Failed(i32),
}

pub struct EglCore {
    display: EGLDisplay,
    config: EGLConfig,
    context: EGLContext,
    surface: EGLSurface,
    width: i32,
    height: i32,
    info: EglInfo,
}

impl EglCore {
    /// Opens the default display and creates an OpenGL ES 2.0 context (no surface yet).
    pub fn new() -> Result<Self, String> {
        // SAFETY: plain EGL calls with valid pointers to locals.
        unsafe {
            let display = eglGetDisplay(ptr::null_mut());
            if display.is_null() {
                return Err(error_message("eglGetDisplay"));
            }
            let (mut major, mut minor) = (0, 0);
            if eglInitialize(display, &mut major, &mut minor) == EGL_FALSE {
                return Err(error_message("eglInitialize"));
            }
            let config = match choose_config(display) {
                Ok(config) => config,
                Err(e) => {
                    eglTerminate(display);
                    return Err(e);
                }
            };
            let context_attribs = [EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE];
            let context =
                eglCreateContext(display, config, ptr::null_mut(), context_attribs.as_ptr());
            if context.is_null() {
                let e = error_message("eglCreateContext");
                eglTerminate(display);
                return Err(e);
            }
            let info = EglInfo {
                vendor: query_string(display, EGL_VENDOR),
                version: query_string(display, EGL_VERSION),
                client_apis: query_string(display, EGL_CLIENT_APIS),
                red: config_attrib(display, config, EGL_RED_SIZE),
                green: config_attrib(display, config, EGL_GREEN_SIZE),
                blue: config_attrib(display, config, EGL_BLUE_SIZE),
                alpha: config_attrib(display, config, EGL_ALPHA_SIZE),
                depth: config_attrib(display, config, EGL_DEPTH_SIZE),
                stencil: config_attrib(display, config, EGL_STENCIL_SIZE),
                samples: config_attrib(display, config, EGL_SAMPLES),
            };
            Ok(Self {
                display,
                config,
                context,
                surface: ptr::null_mut(),
                width: 0,
                height: 0,
                info,
            })
        }
    }

    /// Creates a surface for an `ANativeWindow*`, makes the context current and
    /// requests vsync (swap interval 1).
    pub fn attach_window(&mut self, window: *mut c_void) -> Result<(), String> {
        self.detach_window();
        // SAFETY: `window` is a live ANativeWindow owned by the caller for as long as
        // the surface exists; display/config/context are valid.
        unsafe {
            let surface = eglCreateWindowSurface(self.display, self.config, window, ptr::null());
            if surface.is_null() {
                return Err(error_message("eglCreateWindowSurface"));
            }
            if eglMakeCurrent(self.display, surface, surface, self.context) == EGL_FALSE {
                let e = error_message("eglMakeCurrent");
                eglDestroySurface(self.display, surface);
                return Err(e);
            }
            eglSwapInterval(self.display, 1);
            self.surface = surface;
        }
        self.refresh_size();
        Ok(())
    }

    /// Releases the context from this thread and destroys the surface (if any).
    pub fn detach_window(&mut self) {
        // SAFETY: valid display; the surface is destroyed exactly once.
        unsafe {
            eglMakeCurrent(self.display, ptr::null_mut(), ptr::null_mut(), ptr::null_mut());
            if !self.surface.is_null() {
                eglDestroySurface(self.display, self.surface);
                self.surface = ptr::null_mut();
            }
        }
    }

    pub fn has_surface(&self) -> bool {
        !self.surface.is_null()
    }

    /// Surface size in pixels as of the last [`EglCore::refresh_size`].
    pub fn size(&self) -> (i32, i32) {
        (self.width, self.height)
    }

    pub fn refresh_size(&mut self) {
        if self.surface.is_null() {
            return;
        }
        // SAFETY: valid display and surface; out-pointers are locals.
        unsafe {
            let (mut w, mut h) = (0, 0);
            eglQuerySurface(self.display, self.surface, EGL_WIDTH, &mut w);
            eglQuerySurface(self.display, self.surface, EGL_HEIGHT, &mut h);
            self.width = w;
            self.height = h;
        }
    }

    pub fn info(&self) -> &EglInfo {
        &self.info
    }

    /// Presents the back buffer. Blocks until vsync when the swap interval is 1.
    pub fn swap(&mut self) -> SwapOutcome {
        // SAFETY: valid display and surface.
        unsafe {
            if eglSwapBuffers(self.display, self.surface) != EGL_FALSE {
                return SwapOutcome::Presented;
            }
            match eglGetError() {
                EGL_CONTEXT_LOST => SwapOutcome::ContextLost,
                EGL_BAD_SURFACE | EGL_BAD_NATIVE_WINDOW => SwapOutcome::SurfaceLost,
                code => SwapOutcome::Failed(code),
            }
        }
    }
}

impl Drop for EglCore {
    fn drop(&mut self) {
        self.detach_window();
        // SAFETY: display and context are owned by this struct and released once.
        unsafe {
            eglDestroyContext(self.display, self.context);
            eglTerminate(self.display);
        }
    }
}

unsafe fn choose_config(display: EGLDisplay) -> Result<EGLConfig, String> {
    // Prefer 8-bit RGB, fall back to RGB565. Alpha, depth and stencil are not needed here.
    for bits in [[8, 8, 8], [5, 6, 5]] {
        let attribs: [EGLint; 11] = [
            EGL_SURFACE_TYPE,
            EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE,
            EGL_OPENGL_ES2_BIT,
            EGL_RED_SIZE,
            bits[0],
            EGL_GREEN_SIZE,
            bits[1],
            EGL_BLUE_SIZE,
            bits[2],
            EGL_NONE,
        ];
        let mut config: EGLConfig = ptr::null_mut();
        let mut count: EGLint = 0;
        if eglChooseConfig(display, attribs.as_ptr(), &mut config, 1, &mut count) != EGL_FALSE
            && count > 0
        {
            return Ok(config);
        }
    }
    Err(error_message("eglChooseConfig (no OpenGL ES 2.0 window config)"))
}

unsafe fn query_string(display: EGLDisplay, name: EGLint) -> String {
    let p = eglQueryString(display, name);
    if p.is_null() {
        String::new()
    } else {
        CStr::from_ptr(p).to_string_lossy().into_owned()
    }
}

unsafe fn config_attrib(display: EGLDisplay, config: EGLConfig, attribute: EGLint) -> i32 {
    let mut value: EGLint = 0;
    eglGetConfigAttrib(display, config, attribute, &mut value);
    value
}

fn error_message(what: &str) -> String {
    // SAFETY: eglGetError only reads thread-local state.
    let code = unsafe { eglGetError() };
    format!("{what} failed (EGL error 0x{code:04x})")
}
