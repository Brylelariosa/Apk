//! Logcat logging (tag `HCR`) and a panic hook that reports through it.

#[cfg(target_os = "android")]
mod android {
    use core::ffi::{c_char, c_int};

    #[link(name = "log")]
    extern "C" {
        fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }

    pub struct Logger;

    impl log::Log for Logger {
        fn enabled(&self, metadata: &log::Metadata) -> bool {
            metadata.level() <= log::Level::Info
        }

        fn log(&self, record: &log::Record) {
            if !self.enabled(record.metadata()) {
                return;
            }
            let priority: c_int = match record.level() {
                log::Level::Error => 6,
                log::Level::Warn => 5,
                log::Level::Info => 4,
                log::Level::Debug => 3,
                log::Level::Trace => 2,
            };
            let mut message = format!("{}", record.args());
            message.retain(|c| c != '\0');
            if let Ok(text) = std::ffi::CString::new(message) {
                // SAFETY: both pointers are valid NUL-terminated strings for the call.
                unsafe {
                    __android_log_write(
                        priority,
                        b"HCR\0".as_ptr() as *const c_char,
                        text.as_ptr(),
                    );
                }
            }
        }

        fn flush(&self) {}
    }
}

/// Routes the `log` crate to logcat (tag `HCR`, Info and above). No-op off Android.
pub fn init_logging() {
    #[cfg(target_os = "android")]
    {
        static LOGGER: android::Logger = android::Logger;
        if log::set_logger(&LOGGER).is_ok() {
            log::set_max_level(log::LevelFilter::Info);
        }
    }
}

/// Reports panics through `log` (stderr is invisible on Android).
pub fn install_panic_hook() {
    std::panic::set_hook(Box::new(|info| {
        log::error!("panic: {info}");
    }));
}
