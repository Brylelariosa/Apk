//! Android platform glue: logging, panic reporting and an EGL context.
//! No game logic lives here.

pub mod logging;

#[cfg(target_os = "android")]
pub mod egl;

pub use logging::{init_logging, install_panic_hook};
