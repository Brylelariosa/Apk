# ANALYSIS — Hill Climb Racing 1.73.2 (build 1016)

**Method.** Static inspection of the uploaded `.apks` only: zip listings, binary-manifest decode, ELF headers and strings, dex string table, asset format checks. The game was not run. Nothing was decompiled or disassembled, no protection was bypassed, and no asset content was copied into the project.
Tags: **[observed]** seen in the files · **[inferred]** reasoned from evidence · **[unknown]** not determinable statically.

## 1. Bundle [observed]
| File | Size | Contents |
|---|---|---|
| base.apk | 160 MB | manifest, 8 dex files (67.7 MB), 2,399 asset files (106.7 MB), SDK resources |
| split_config.arm64_v8a.apk | 4.2 MB | `libgame.so` (8.9 MB) + crash-reporter / datastore libs |
| split_config.en.apk | 70 KB | English strings |
| split_config.xxhdpi.apk | 184 KB | density resources (SDK UI only) |
| icon.png | 28 KB | launcher icon (Fingersoft artwork) |

Only arm64-v8a ships (no 32-bit libs).

## 2. Manifest [observed]
- Package `com.fingersoft.hillclimb`, versionName 1.73.2, versionCode 1016, minSdk 29, targetSdk 36, compileSdk 37.
- Launcher activity `com.fingersoft.game.MainActivity`: sensor-landscape, `resizeableActivity=false`, `android.max_aspect=2.4`, hardware accelerated, `largeHeap=true`, `isGame=true`.
- Requires OpenGL ES 2.0. Optional: accelerometer, touchscreen, gamepad.
- Permissions: billing, internet, network state, push (C2DM), ad ID, wake lock, notifications, foreground service, license check, install referrer.
- Meta-data `com.android.graphics.driver.prefer_angle=true` (asks the OS to prefer the ANGLE GL driver where supported; effect on this phone unverified).
- Bundled components: AdMob (new GMA SDK), Meta Audience Network, Chartboost, Moloco, ironSource, Unity Ads, InMobi, AppLovin crash reporter, Firebase (Analytics, Crashlytics NDK, Messaging, Remote Config, Auth, Sessions), Play Games v2, Play Billing 8.0.0, Helpshift, ExoPlayer, WorkManager, consent (UMP). The real list may be longer.

## 3. Architecture
### Native game: `libgame.so` [observed unless tagged]
- ELF64 AArch64, 8.9 MB, stripped. C++ symbols are not exported: only 63 JNI entry points plus libc / libpng / std symbols.
- Links `liblog`, `libz`, `libGLESv2`, `libc`, `libm`, `libdl`. `libOpenSLES.so` is loaded at runtime (`SIMPLEAUDIOENGINE_OPENSL` string).
- Contains libpng 1.6.23. GL extension names present: `GL_EXT_discard_framebuffer`, `GL_IMG_texture_compression_pvrtc`, `GL_IMG_texture_format_BGRA888` [inferred: Cocos2d capability checks].
- **Cocos2d-x 2.x**: embedded source paths `libs/cocos2d-x/cocos2dx/CC*.cpp` (CCDirector, CCScheduler, CCNode, CCSprite, CCSpriteBatchNode, CCParticleSystemQuad, CCTexture2D, CCRenderTexture, CCLabelBMFont, ...) plus a custom `CCNewFileUtils`. Exact minor version [unknown].
- Physics [inferred: Box2D]: vehicle model JSON is R.U.B.E. format (bodies, joints, images; world settings `positionIterations`, `velocityIterations`, `warmStarting`, `subStepping`, `continuousPhysics`). Box2D version [unknown].

### Java shell [observed unless tagged]
- `MultiDexApplication` → `MainActivity` → `Cocos2dxGLSurfaceView` / `Cocos2dxRenderer` → JNI `nativeInit / nativeRender / nativeResize / nativeTouches*`. Text rendering goes through Java `Cocos2dxBitmap` [inferred from class + JNI].
- The 63 JNI callbacks are almost entirely business logic: ads, IAP, consent, cloud sync and achievements, remote config, missions JSON, popup offers, server time, controller events.
- Fingersoft Java packages (class counts incl. inner classes): `game` 155, `liveops_sdk` 84, `fspromotionkit` 34, `utils` 27, `hillclimb` 23, `billing` 15. The rest of the 67.7 MB of dex is third-party SDKs.

## 4. Asset catalog [observed]
Per-file list with sizes, dimensions and SHA-256: `asset_manifest.csv` (metadata only).
| Category | Files | Size | Format / notes |
|---|---|---|---|
| Images | 1,835 PNG + 20 JPG | 70.4 MB | Valid standard PNG/JPG. Only 86 `_HD` variants. Largest page 2048x2043 |
| Plists | 71 | 0.5 MB | Cocos2d atlas descriptors (28 sets in `atlas/`) and particle configs; XML, 18 with a UTF-8 BOM |
| Audio | 150 OGG | 12.4 MB | Vorbis. 33 engine loops, 7 background tracks plus an 8-bit set, pinball, vehicle-specific SFX |
| Shaders | 35 `.fsh` + 33 `.vsh` | ~40 KB | Plain-text GLSL ES 1.00: terrain variants (night, xray, electric, bog), sky, fog, liquid, jello, glow / pixelate / edge-glow post-process, chain track, tail, prop, pit |
| Stage JSON | 128 under `stages/` | - | `//`-commented JSON (see §5) |
| Vehicle models | 7 | - | R.U.B.E. Box2D exports |
| Other game JSON | 7 `stage_data`, 1 `events`, 1 `garage` | - | challenge, frame objects, backgrounds, test level |
| Config | `default.json` | 2.6 MB | Server / billing configuration (server URLs, program id, payment-wall packages). Not gameplay |
| Translations | 73 `.po` | 7.4 MB | 18 languages, full + `-lite`, with legacy duplicate names |
| Fonts | 2 BMFont | 40 KB | `gamefont`, `gamefont-hd` (.fnt + PNG page) |
| Ad/web payloads | 9 JS, 6 HTML, Audience Network dex (5.3 MB) | - | Ad SDK content, not game content |
| Unidentified | `garage/aaa.dat` | 26 KB | High entropy (7.93 bits/byte), no known header, not referenced by name in the binary. **Not decoded** |

- Format check: all PNG, JPG, OGG and shaders are valid and unobfuscated. 54 JSON files fail strict parsing only because of `//` header comments; all 146 parse once comments are stripped. No encryption seen in any of them.
- Stage asset folders (42): actionhero, alienplanet, arctic, arcticcave, beach, bog, bootcamp, cave, construction, countryside, desert, doubleroad, factory, forest, haunted, highway, jungle, junkyard, mars, mega_desert, mega_highway, moon, mountain, mudpool, neon, night, northpole, nuclear, party, prog, ragnarok, rainbow, retro_mission, rollercoaster, rooftops, seasons, space_mission, suburbs, super_countryside, tricktrack, volcano, xmas.
- Vehicles: at least 30 distinct types by icon names (jeep, hotrod, tractor, monster, chopper / minibike / fastbike, ufo, hovercraft, snowmobile, spider, sleigh, moonlander, ...). Final count [unknown].
- Texture memory: all 1,855 images as RGBA8888 would be 0.79 GB. That is an upper bound, not a working set; per-scene usage must be measured on the phone.

## 5. Data-driven vs native-only
**In the files**
- Stage manifest keys: `id`, `type`, `blockTypes`, `blocks`, `graphics` (sky / terrain textures, dirt particle), `physics` (gravity, friction, traction category), `coinMultiplier`. Countryside: gravity (0, -10), friction 0.6, gravel traction, coin multiplier 1.25.
- JSON-block stages (e.g. jungle): `blockFile` / `objectFile`, lazy physics creation speed, hybrid-mode flags.
- 7 vehicle model files: badcar, boringcar, fastbike, projectcar (+ `_model`), ufo, plus `modifier_props`.

**Only in stripped native code**
- Classic terrain: the `algorithm` block has an empty expression string, so the generator is compiled in. The `bridge` ("code") block likewise.
- Tuning for the other vehicles, fuel / coin / diamond / score rules, crash conditions, nitro and boost behaviour, upgrade math, mission logic.
- Scene composition: UI layout, camera, zoom, design-resolution / scaling policy, input handling, engine-sound pitch logic, save format.

## 6. Reproducibility assessment
| Area | Feasibility | Approach |
|---|---|---|
| Sprites, atlases, UI textures | High | GLES2 batcher + plist/PNG loaders |
| Shaders | High (GLES2) / Medium (wgpu) | Reuse GLSL ES as-is on GLES2; wgpu needs a WGSL port of 68 files |
| Particles, BMFont, localization | High | Re-implement Cocos2d 2.x behaviour; `.po` parser |
| Audio | High | Vorbis decode + Oboe/AAudio; engine-pitch logic by observation |
| TTF / system text | Medium | Font identity unknown (Android canvas in the original) |
| Stage manifests, JSON-block terrain | Medium-High | Parse the same data |
| 7 data-defined vehicles | Medium-High | Box2D port + R.U.B.E. loader; calibrate against recordings |
| Classic terrain, other vehicles, game rules | Medium-Low | Black-box observation; near-identical, not bit-identical |
| Camera, HUD, scaling | Medium | Reference screenshots / recordings at 2400x1080 |
| Menus, garage, shop, events, missions | Low (large effort) | After the core slice |
| Ads, IAP, Play Games / cloud, Firebase, LiveOps, promos, Helpshift, consent | Not reproduced | SDK/server-bound; out of scope |

Realistic order: (1) benchmarkable slice: one stage, one vehicle, HUD, audio; (2) more stages and vehicles; (3) garage and menus. Trajectories will not be bit-identical to the original; deviation will be measured and reported.

## 7. Asset policy
Every image, sound, shader and data file belongs to Fingersoft. Options:
- **A (recommended):** the Rust app reads assets read-only at runtime from the installed original. Nothing is copied into the repo or the Rust APK. Pixel-identical visuals; no redistribution.
- **B:** recreate everything independently. Legally clean, but visuals will not match, which defeats the comparison.
- **C:** bundle assets under written permission from Fingersoft.

Status: the user replied "c and how or a". C requires written permission from the rights holder, which is not confirmed, so A is the working default. The asset source will sit behind one interface, so switching to C later is a small change. The Rust app's icon is independently drawn in every case.

## 8. Fairness notes for benchmarking
- The original has no overlay, so both apps must be measured by the same external method (on-device wireless-debug shell: SurfaceFlinger frame timestamps, `dumpsys meminfo`, `top`, `batterystats`) or by screen-recording analysis. [unverified on this phone]
- On a vsync-capped display both apps will probably sit at the refresh rate. The useful differences are likely CPU time per frame, 1% lows, RAM and power. [expectation, not a result]
- Run both offline, same brightness, cooled down, same background state. The original's ad and analytics SDKs run in the background; the Rust build has none.
- Match game state first (stage, vehicle, unlocks, upgrades). The two apps do not share save data.
- Record GL renderer / version and the resolution each app actually renders at; check whether the original goes through ANGLE.
- Scenarios that do not depend on diverging physics: menu idle, stage start idle, fixed-duration gas hold.

## 9. Unknowns to resolve by observation (Stage 4)
Physics step rate and Box2D version; terrain algorithm and seeding; camera and zoom rules; design-resolution policy at 2400x1080; which resource set (`_HD` or base) is chosen; frame pacing; per-scene texture working set; purpose of `aaa.dat`; which vehicles and stages exist in the user's save.
