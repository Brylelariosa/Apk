package com.hzcm.duelforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

private val BgColor    = Color(0xFF0D1B2A)
private val PanelColor = Color(0xFF1B263B)
private val LogColor   = Color(0xFF14213D)

@Composable
fun GameScreen(
    viewModel: GameViewModel = viewModel(),
    onOpenDebug: () -> Unit = {}
) {
    val engine = viewModel.engine
    @Suppress("UNUSED_EXPRESSION")
    viewModel.refresh
    val state = engine.state

    Box(modifier = Modifier.fillMaxSize().background(BgColor)) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
            // ── LEFT: game field + hand ──────────────────────────────
            Column(
                modifier = Modifier
                    .weight(1.7f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                OpponentPanel(engine, viewModel)
                PhaseBar(viewModel, onOpenDebug)
                PlayerPanel(engine, viewModel)
            }

            Spacer(modifier = Modifier.width(4.dp))

            // ── RIGHT: log + action sidebar ──────────────────────────
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                LogPanel(state, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(modifier = Modifier.height(4.dp))
                ActionPanel(viewModel, modifier = Modifier.fillMaxWidth())
            }
        }

        state.pendingHumanPriority?.let { prompt -> PriorityDialog(prompt, viewModel) }
        state.pendingDiscard?.let { req -> DiscardDialog(req, viewModel) }
        if (state.phase == Phase.BATTLE && state.turnPlayer == PlayerId.PLAYER)
            BattlePhaseBanner()
        if (state.gameOver) GameOverOverlay(state, viewModel)
    }
}

// ------------------------------------------------------------------
// Opponent field panel
// Real YGO layout (opponent's half, from player's view):
//   Opponent LP / hand info
//   Opponent S/T zones  ← FAR from center (their "back row")
//   Opponent monster zones  ← CLOSE to center (facing player's monsters)
// ------------------------------------------------------------------

@Composable
private fun OpponentPanel(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.AI)
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Opponent LP: ${field.lifePoints}",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
            )
            Text(
                "Hand:${field.hand.size}  Deck:${field.deck.size}  GY:${field.graveyard.size}" +
                "  Banished:${field.banished.size}  Extra:${field.extraDeck.size}",
                color = Color(0xFFAAAAAA), fontSize = 9.sp
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        // Row 1: Spell/Trap zones — FAR side (like real YGO back row for opponent)
        Row {
            Spacer(modifier = Modifier.width(CardWidth + 4.dp))
            for (i in 0..4) {
                CardView(instance = field.spellTrapZones[i], modifier = Modifier.padding(horizontal = 1.dp))
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        // Row 2: Monster zones + field zone — CLOSE to center, facing player's monsters
        Row(verticalAlignment = Alignment.CenterVertically) {
            CardView(field.fieldZone)
            Spacer(modifier = Modifier.width(4.dp))
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                CardView(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    selected = vm.attackerSelection != null && cardInst != null,
                    onClick = cardInst?.let { c -> { vm.onOpponentMonsterTapped(c) } }
                )
            }
        }
    }
}

// ------------------------------------------------------------------
// Player field panel — monsters on top (closest to center), S/T below, then hand
// Real YGO layout: [opponent] → opponent monsters → opponent S/T → [center] →
//                  player monsters → player S/T → player LP → player hand → [you]
// ------------------------------------------------------------------

@Composable
private fun PlayerPanel(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    Column {
        // Row 1: Monster zones + field zone  ← CLOSEST TO CENTER (like real YGO)
        Row(verticalAlignment = Alignment.CenterVertically) {
            CardView(field.fieldZone)
            Spacer(modifier = Modifier.width(4.dp))
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                CardView(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnMonsterTapped(c) } }
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        // Row 2: Spell/Trap zones  ← below monsters, closer to player (like real YGO)
        Row {
            Spacer(modifier = Modifier.width(CardWidth + 4.dp))
            for (i in 0..4) {
                val cardInst = field.spellTrapZones[i]
                CardView(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnSpellTrapTapped(c) } }
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Your LP: ${field.lifePoints}",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
            )
            Text(
                "Deck:${field.deck.size}  GY:${field.graveyard.size}" +
                "  Banished:${field.banished.size}  Extra:${field.extraDeck.size}",
                color = Color(0xFFAAAAAA), fontSize = 9.sp
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        LazyRow {
            items(field.hand) { cardInst ->
                CardView(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 2.dp),
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = { vm.onHandCardTapped(cardInst) }
                )
            }
        }
    }
}

private fun isSelected(card: CardInstance?, vm: GameViewModel): Boolean {
    if (card == null) return false
    if (vm.selectedCard === card) return true
    if (vm.attackerSelection === card) return true
    if (vm.tributeSelection?.chosen?.contains(card) == true) return true
    if (vm.discardChosen.contains(card)) return true
    return false
}

// ------------------------------------------------------------------
// Phase bar
// ------------------------------------------------------------------

@Composable
private fun PhaseBar(vm: GameViewModel, onOpenDebug: () -> Unit = {}) {
    val state = vm.engine.state
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val turnLabel = if (state.turnPlayer == PlayerId.PLAYER) "Your Turn" else "Opponent's Turn"
        Text(
            "Turn ${state.turnCount} - $turnLabel - ${phaseDisplayName(state.phase)}",
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Debug shortcut button — small, tucked beside the phase button
            Button(
                onClick = onOpenDebug,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("🔧", fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.width(4.dp))
            val canAdvance = state.turnPlayer == PlayerId.PLAYER && !state.gameOver &&
                state.chain.isEmpty() && state.pendingHumanPriority == null
            Button(onClick = { vm.advancePhase() }, enabled = canAdvance) {
                Text(if (state.phase == Phase.END) "End Turn" else "Next Phase", fontSize = 10.sp)
            }
        }
    }
}

private fun phaseDisplayName(phase: Phase): String = when (phase) {
    Phase.DRAW         -> "Draw Phase"
    Phase.STANDBY      -> "Standby Phase"
    Phase.MAIN1        -> "Main Phase 1"
    Phase.BATTLE_START -> "Battle Phase"
    Phase.BATTLE       -> "Battle Phase"
    Phase.MAIN2        -> "Main Phase 2"
    Phase.END          -> "End Phase"
}

// ------------------------------------------------------------------
// Log panel
// ------------------------------------------------------------------

@Composable
private fun LogPanel(state: GameState, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()
    LaunchedEffect(state.log.size) {
        if (state.log.isNotEmpty()) listState.animateScrollToItem(state.log.size - 1)
    }
    LazyColumn(
        state = listState,
        modifier = modifier.background(LogColor).padding(4.dp)
    ) {
        items(state.log) { line ->
            Text(line, color = Color(0xFFCCCCCC), fontSize = 9.sp, lineHeight = 11.sp)
        }
    }
}

// ------------------------------------------------------------------
// Action panel (sidebar)
// ------------------------------------------------------------------

@Composable
private fun ActionPanel(vm: GameViewModel, modifier: Modifier = Modifier) {
    val engine = vm.engine
    Column(
        modifier = modifier
            .background(PanelColor)
            .padding(4.dp)
            .heightIn(max = 200.dp)
            .verticalScroll(rememberScrollState())
    ) {
        val tribute  = vm.tributeSelection
        val attacker = vm.attackerSelection
        val card     = vm.selectedCard

        when {
            tribute  != null -> TributePanel(vm, tribute)
            attacker != null -> AttackerPanel(vm, engine, attacker)
            card     != null -> CardActionPanel(vm, engine, card)
            else -> Text("Tap a card to act.", color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun TributePanel(vm: GameViewModel, tribute: TributeSelection) {
    val action = if (tribute.asSet) "Set" else "Normal Summon"
    Text(
        "$action ${tribute.card.card.name}: choose ${tribute.required} tribute(s) " +
        "(${tribute.chosen.size}/${tribute.required})",
        color = Color.White, fontSize = 10.sp
    )
    Spacer(modifier = Modifier.height(4.dp))
    Row {
        Button(
            onClick = { vm.confirmTributeSummon() },
            enabled = tribute.chosen.size == tribute.required
        ) { Text("Confirm", fontSize = 10.sp) }
        Spacer(modifier = Modifier.width(4.dp))
        Button(onClick = { vm.cancelTributeSummon() }) { Text("Cancel", fontSize = 10.sp) }
    }
}

@Composable
private fun AttackerPanel(vm: GameViewModel, engine: GameEngine, attacker: CardInstance) {
    Text("${attacker.card.name} attacking.", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    Spacer(modifier = Modifier.height(4.dp))
    if (engine.canDeclareAttack(attacker, null)) {
        Text("No opp monsters — attack directly?", color = Color.LightGray, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = { vm.declareDirectAttack() }) { Text("Attack Directly", fontSize = 10.sp) }
    } else {
        Text("Tap an opponent's monster.", color = Color.LightGray, fontSize = 10.sp)
    }
}

@Composable
private fun CardActionPanel(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            CardView(
                instance = card,
                modifier = Modifier.padding(bottom = 6.dp),
                revealFaceDown = true,
                cardWidth = 150.dp,
                cardHeight = 210.dp
            )
        }
        Text(card.card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(card.card.description, color = Color.LightGray, fontSize = 9.sp, lineHeight = 11.sp)
        if (card.card.isMonster) {
            Text(
                "Lv${card.card.level ?: 0}  ${card.card.attribute?.name ?: ""} " +
                "${card.card.race?.name?.replace('_', ' ') ?: ""}  " +
                "ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}",
                color = Color(0xFFAAAAAA), fontSize = 8.sp
            )
        }
        Spacer(modifier = Modifier.height(4.dp))

        when (card.location) {
            Location.HAND         -> HandCardActions(vm, engine, card)
            Location.MONSTER_ZONE -> FieldMonsterActions(vm, engine, card)
            else -> Text("No actions available.", color = Color.Gray, fontSize = 9.sp)
        }
    }
}

@Composable
private fun HandCardActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    if (card.card.isMonster) {
        if (engine.canNormalSummon(card)) {
            val tribNote = if (card.card.tributesRequired > 0) " (${card.card.tributesRequired} trib)" else ""
            ActionButton("Normal Summon$tribNote") { vm.beginSummon(false) }
            ActionButton("Set (face-down)$tribNote") { vm.beginSummon(true) }
        }
    }
    if (card.card.isTrap && engine.canSetSpellOrTrap(card)) {
        ActionButton("Set face-down") { vm.setTrap() }
    }
    for (effect in EffectRegistry.effectsFor(card.card.id)) {
        if (engine.canActivateEffect(card, effect)) {
            ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
        }
    }
}

@Composable
private fun FieldMonsterActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    if (engine.canFlipSummon(card)) {
        ActionButton("Flip Summon") { vm.flipSummon() }
    }
    val opposite = if (card.battlePosition == BattlePosition.ATTACK) BattlePosition.DEFENSE else BattlePosition.ATTACK
    if (engine.canChangeBattlePosition(card, opposite)) {
        val label = if (opposite == BattlePosition.ATTACK) "→ Attack Pos" else "→ Defense Pos"
        ActionButton(label) { vm.changeBattlePosition(opposite) }
    }
    for (effect in EffectRegistry.effectsFor(card.card.id)) {
        if (engine.canActivateEffect(card, effect)) {
            ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(label, fontSize = 10.sp)
    }
}

// ------------------------------------------------------------------
// Priority dialog
// ------------------------------------------------------------------

@Composable
private fun PriorityDialog(prompt: PriorityPrompt, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = { /* must choose Pass explicitly */ },
        title = { Text("Respond?") },
        text = {
            Column {
                Text(prompt.reason, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(8.dp))
                prompt.optionLabels.forEachIndexed { index, label ->
                    Button(
                        onClick = { vm.submitPriorityChoice(index) },
                        modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth()
                    ) { Text(label, fontSize = 10.sp) }
                }
            }
        },
        confirmButton = {
            Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") }
        }
    )
}

// ------------------------------------------------------------------
// Discard dialog — shown when an effect requires the player to choose card(s) to discard
// ------------------------------------------------------------------

@Composable
private fun DiscardDialog(req: DiscardRequest, vm: GameViewModel) {
    val hand = vm.engine.state.field(req.player).hand
    AlertDialog(
        onDismissRequest = { /* must pick */ },
        title = { Text("Discard ${req.count} card${if (req.count > 1) "s" else ""}") },
        text = {
            Column {
                Text(req.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Tap to select (${vm.discardChosen.size}/${req.count}):",
                    fontSize = 9.sp, color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow {
                    items(hand) { card ->
                        val chosen = vm.discardChosen.contains(card)
                        CardView(
                            instance = card,
                            revealFaceDown = true,
                            selected = chosen,
                            modifier = Modifier.padding(horizontal = 3.dp),
                            onClick = { vm.onDiscardCardToggled(card) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { vm.confirmDiscard() },
                enabled = vm.discardChosen.size == req.count
            ) { Text("Discard") }
        }
    )
}

// ------------------------------------------------------------------
// Battle Phase banner — one-shot visual cue, dismisses itself
// ------------------------------------------------------------------

@Composable
private fun BattlePhaseBanner() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .background(Color(0xCC8B0000), androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Text(
                "⚔ BATTLE PHASE — Tap your monsters to attack!",
                color = Color(0xFFFF6666),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}

// ------------------------------------------------------------------
// Game over overlay
// ------------------------------------------------------------------

@Composable
private fun GameOverOverlay(state: GameState, vm: GameViewModel) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val winnerText = when (state.winner) {
                PlayerId.PLAYER -> "You Win!"
                PlayerId.AI     -> "Opponent Wins!"
                null            -> "Duel Over"
            }
            Text(winnerText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { vm.restart() }) { Text("New Duel") }
        }
    }
}
