#include "Model.h"
#include <fstream>
#include <stdexcept>
#include <cstdint>

namespace novallm {

Model::Model(const Config& config, unsigned int seed)
    : config_(config),
      tokenEmbedding_(config.vocabSize, config.embedDim, seed),
      positionalEncoding_(config.maxSeqLen, config.embedDim),
      finalNorm_(config.embedDim),
      lmHead_(config.embedDim, config.vocabSize, seed + 1000, /*useBias=*/true) {
    blocks_.reserve(static_cast<size_t>(config.numLayers));
    caches_.reserve(static_cast<size_t>(config.numLayers));
    for (int i = 0; i < config.numLayers; ++i) {
        blocks_.emplace_back(config.embedDim, config.numHeads, config.ffnHiddenDim,
                              seed + 100 + static_cast<unsigned int>(i) * 10);
        caches_.emplace_back(config.maxSeqLen, config.embedDim);
    }
}

Tensor Model::forward(const std::vector<int>& ids) const {
    Tensor x = positionalEncoding_.applyTo(tokenEmbedding_.lookupSequence(ids));
    for (const auto& block : blocks_) {
        x = block.forward(x);
    }
    x = finalNorm_.forward(x);
    return lmHead_.forward(x); // {seqLen, vocabSize}
}

Tensor Model::forwardIncremental(const std::vector<int>& newIds) {
    // All layer caches advance together, so any one of them tells us the
    // current global position new tokens are starting from.
    int startPos = caches_.empty() ? 0 : caches_[0].currentLen();
    int newLen = static_cast<int>(newIds.size());

    Tensor tokenEmb = tokenEmbedding_.lookupSequence(newIds);      // {newLen, embedDim}
    Tensor posSlice = positionalEncoding_.encodeRange(startPos, newLen);
    Tensor x({newLen, config_.embedDim});
    for (size_t k = 0; k < x.size(); ++k) {
        x.data()[k] = tokenEmb.data()[k] + posSlice.data()[k];
    }

    for (size_t i = 0; i < blocks_.size(); ++i) {
        x = blocks_[i].forwardIncremental(x, caches_[i]);
    }
    x = finalNorm_.forward(x);
    return lmHead_.forward(x); // {newLen, vocabSize}
}

void Model::resetCache() {
    for (auto& c : caches_) c.reset();
}

void Model::save(const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Model::save - cannot open " + path);

    const char magic[4] = {'N', 'M', 'D', 'L'};
    out.write(magic, 4);

    int32_t vocabSize = config_.vocabSize, embedDim = config_.embedDim, numLayers = config_.numLayers;
    int32_t numHeads = config_.numHeads, ffnHiddenDim = config_.ffnHiddenDim, maxSeqLen = config_.maxSeqLen;
    out.write(reinterpret_cast<const char*>(&vocabSize), sizeof(vocabSize));
    out.write(reinterpret_cast<const char*>(&embedDim), sizeof(embedDim));
    out.write(reinterpret_cast<const char*>(&numLayers), sizeof(numLayers));
    out.write(reinterpret_cast<const char*>(&numHeads), sizeof(numHeads));
    out.write(reinterpret_cast<const char*>(&ffnHiddenDim), sizeof(ffnHiddenDim));
    out.write(reinterpret_cast<const char*>(&maxSeqLen), sizeof(maxSeqLen));

    tokenEmbedding_.save(out);
    for (const auto& block : blocks_) block.save(out);
    finalNorm_.save(out);
    lmHead_.save(out);
    // caches_ deliberately NOT saved - generation state, not a parameter.
}

Model Model::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Model::load - cannot open " + path);

    char magic[4];
    in.read(magic, 4);
    if (magic[0] != 'N' || magic[1] != 'M' || magic[2] != 'D' || magic[3] != 'L') {
        throw std::runtime_error("Model::load - bad magic in " + path);
    }

    Config cfg{};
    int32_t v = 0;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.vocabSize = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.embedDim = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.numLayers = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.numHeads = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.ffnHiddenDim = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.maxSeqLen = v;

    Model model(cfg, /*seed=*/1); // random weights - immediately overwritten below

    model.tokenEmbedding_.load(in);
    for (auto& block : model.blocks_) block.load(in);
    model.finalNorm_.load(in);
    model.lmHead_.load(in);

    return model;
}

} // namespace novallm
