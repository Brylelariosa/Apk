#pragma once
#include <vector>
#include <string>
#include <iosfwd>
#include "../math/Tensor.h"
#include "../embedding/TokenEmbedding.h"
#include "../embedding/PositionalEncoding.h"
#include "../transformer/Block.h"
#include "../transformer/LayerNorm.h"
#include "../transformer/Linear.h"
#include "../transformer/KVCache.h"

namespace novallm {

// The full assembled model: embedding -> +positional encoding -> N
// transformer blocks -> final LayerNorm -> LM head -> logits over the
// vocabulary. "Logits" from the original component list isn't a separate
// class - it's just the shape {seqLen, vocabSize} this returns.
//
// Weights are random (untrained) until subsystem 7 exists. This class is
// the forward-pass machinery; it says nothing meaningful until training
// shapes those weights into something.
class Model {
public:
    struct Config {
        int vocabSize;
        int embedDim;
        int numLayers;
        int numHeads;
        int ffnHiddenDim;
        int maxSeqLen;
    };

    explicit Model(const Config& config, unsigned int seed = 42);

    // ids -> logits, shape {seqLen, vocabSize}. Full recompute every call -
    // for training / whole-sequence scoring, where there's no "previous
    // step" to cache.
    Tensor forward(const std::vector<int>& ids) const;

    // Incremental (KV-cached) forward for fast generation. `newIds` is
    // JUST the new token(s) since the last call - the whole prompt on the
    // first call after resetCache(), then one token at a time after.
    // Returns logits for just those new positions, {newLen, vocabSize}.
    // Mutates internal per-layer cache state; call resetCache() before
    // starting a new, unrelated sequence.
    Tensor forwardIncremental(const std::vector<int>& newIds);
    void resetCache();

    const Config& config() const { return config_; }

    // Persists/restores every learned weight (embedding, all blocks,
    // final norm, LM head). Generation cache state is NOT part of this -
    // it's ephemeral per-sequence state, not a learned parameter, and a
    // freshly loaded model always starts with empty caches.
    void save(const std::string& path) const;
    static Model load(const std::string& path);

private:
    Config config_;
    TokenEmbedding tokenEmbedding_;
    PositionalEncoding positionalEncoding_;
    std::vector<TransformerBlock> blocks_;
    LayerNorm finalNorm_;
    Linear lmHead_;
    std::vector<KVCache> caches_; // one per layer, kept in lockstep
};

} // namespace novallm
