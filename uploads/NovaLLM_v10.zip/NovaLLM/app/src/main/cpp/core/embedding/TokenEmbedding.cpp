#include "TokenEmbedding.h"
#include <random>
#include <stdexcept>
#include <ostream>
#include <istream>

namespace novallm {

TokenEmbedding::TokenEmbedding(int vocabSize, int embedDim, unsigned int seed)
    : vocabSize_(vocabSize), embedDim_(embedDim), weights_({vocabSize, embedDim}) {
    std::mt19937 rng(seed);
    std::normal_distribution<float> dist(0.0f, 0.02f); // GPT-2-style small init
    for (size_t i = 0; i < weights_.size(); ++i) {
        weights_.data()[i] = dist(rng);
    }
}

Tensor TokenEmbedding::lookup(int tokenId) const {
    if (tokenId < 0 || tokenId >= vocabSize_) {
        throw std::out_of_range("TokenEmbedding::lookup - token id out of range");
    }
    Tensor row({embedDim_});
    const float* src = weights_.data() + static_cast<size_t>(tokenId) * embedDim_;
    for (int j = 0; j < embedDim_; ++j) row.data()[j] = src[j];
    return row;
}

Tensor TokenEmbedding::lookupSequence(const std::vector<int>& tokenIds) const {
    int seqLen = static_cast<int>(tokenIds.size());
    Tensor out({seqLen, embedDim_});
    for (int i = 0; i < seqLen; ++i) {
        int id = tokenIds[static_cast<size_t>(i)];
        if (id < 0 || id >= vocabSize_) {
            throw std::out_of_range("TokenEmbedding::lookupSequence - token id out of range");
        }
        const float* src = weights_.data() + static_cast<size_t>(id) * embedDim_;
        float* dst = out.data() + static_cast<size_t>(i) * embedDim_;
        for (int j = 0; j < embedDim_; ++j) dst[j] = src[j];
    }
    return out;
}

void TokenEmbedding::save(std::ostream& out) const {
    weights_.save(out);
}

void TokenEmbedding::load(std::istream& in) {
    weights_.load(in);
    vocabSize_ = weights_.dim(0);
    embedDim_ = weights_.dim(1);
}

} // namespace novallm
