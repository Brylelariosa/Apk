package com.jarry.novallm

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        init {
            System.loadLibrary("novallm_core")
        }
    }

    external fun nativeRunMathCoreTest(): String
    external fun nativeRunTokenizerTest(): String
    external fun nativeRunEmbeddingTest(): String
    external fun nativeRunTransformerTest(): String
    external fun nativeRunDecoderTest(): String
    external fun nativeRunRuntimeTest(cacheDir: String): String
    external fun nativeRunTrainingTest(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val resultView = TextView(this).apply {
            text = "NovaLLM \u2014 tap a button to run its on-device tests."
            textSize = 14f
            setPadding(32, 32, 32, 32)
        }

        val mathButton = Button(this).apply {
            text = "Run Math Core Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunMathCoreTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val tokenizerButton = Button(this).apply {
            text = "Run Tokenizer Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTokenizerTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val embeddingButton = Button(this).apply {
            text = "Run Embedding Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunEmbeddingTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val transformerButton = Button(this).apply {
            text = "Run Transformer Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTransformerTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val decoderButton = Button(this).apply {
            text = "Run Decoder Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunDecoderTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val runtimeButton = Button(this).apply {
            text = "Run Runtime Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunRuntimeTest(cacheDir.absolutePath)
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val trainingButton = Button(this).apply {
            text = "Run Training Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTrainingTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(mathButton)
            addView(tokenizerButton)
            addView(embeddingButton)
            addView(transformerButton)
            addView(decoderButton)
            addView(runtimeButton)
            addView(trainingButton)
            addView(resultView)
        }

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
