package com.voxelsandbox.game.gl

/**
 * The GLSL programs. All voxel-chunk geometry shares one vertex format (position + uv +
 * shade) and [VERTEX]; what differs is the fragment stage:
 *
 *  - [OPAQUE_FRAGMENT]: every opaque block. No `discard` at all, so the GPU can use early
 *    depth rejection (and, on tile-based GPUs, hidden-surface removal) for the bulk of the
 *    terrain. This is the main per-pixel saving of v9.
 *  - [OPAQUE_FADE_FRAGMENT]: the same, plus a screen-door dissolve for the outer rim of the
 *    voxel area, which is how voxel terrain melts into the distant-terrain (LOD) mesh behind
 *    it instead of ending in a hard line. Only regions that touch the rim use it.
 *  - [FRAGMENT]: alpha-tested geometry (leaves, plants, lily pads) and the small overlay
 *    meshes (block outline, particles, laser). Fades out at the rim like the opaque terrain.
 *
 * Other programs:
 *  - [FAR_VERTEX]/[FAR_FRAGMENT]: the distant-terrain tiles: a circular clip around the
 *    player, a distance band per level of detail, and (close to the voxel area) the same
 *    per-block brightness grain the voxel mesher bakes in, so flat LOD colour does not look
 *    like a different material next to textured blocks.
 *  - [WATER_VERTEX]/[WATER_FRAGMENT]: every water surface (voxel chunks and distant water).
 *    Pixel-art water: a small tiling tile sampled with nearest-texel filtering, scrolled by
 *    time and by the flow direction carried in the vertices. No lighting model at all: just
 *    tile colours, a depth tint, shoreline foam and fog.
 *  - [SKY_VERTEX]/[SKY_FRAGMENT]: a full-screen gradient with a sun, drawn first.
 *  - [CLOUD_VERTEX]/[CLOUD_FRAGMENT]: the blocky cloud layer.
 */
object Shaders {
    const val VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;
out highp vec2 vWorldXZ;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
    vWorldXZ = aPosition.xz;
}
"""

    /**
     * Pixel-exact atlas lookup, a drop-in for `texture(uTexture, vTexCoord)` (see [crisp]).
     * The atlas sampler asks for nearest texels, but several mobile GPUs filter anyway (their
     * anisotropic and trilinear paths are built on bilinear probes), which turns 16x16 pixel
     * art into a smear. `texelFetch` ignores sampler state altogether, so the mip level is
     * chosen here from the screen-space footprint of a pixel (slightly sharper than the
     * hardware rule, so ground a few blocks away stays crisp) and single texels are fetched
     * and blended between the two nearest levels. ATLAS_SIZE and ATLAS_TOP_MIP are filled in
     * by [crisp] from [TextureAtlas].
     */
    private const val ATLAS_TEXEL = """
vec4 atlasTexel(highp vec2 uv) {
    highp vec2 tc = uv * ATLAS_SIZE.0;
    highp vec2 dx = dFdx(tc);
    highp vec2 dy = dFdy(tc);
    highp float lod = clamp(0.5 * log2(max(max(dot(dx, dx), dot(dy, dy)), 1.0e-6)) - 0.25, 0.0, ATLAS_TOP_MIP.0);
    int l0 = int(lod);
    int l1 = min(l0 + 1, ATLAS_TOP_MIP);
    highp float f = lod - float(l0);
    ivec2 p0 = min(ivec2(tc * exp2(-float(l0))), ivec2((ATLAS_SIZE >> l0) - 1));
    ivec2 p1 = min(ivec2(tc * exp2(-float(l1))), ivec2((ATLAS_SIZE >> l1) - 1));
    return mix(texelFetch(uTexture, p0, l0), texelFetch(uTexture, p1, l1), f);
}
"""

    /** [fragment] with its single `texture(uTexture, vTexCoord)` replaced by [ATLAS_TEXEL]'s
     *  pixel-exact lookup (the helper is inserted just before `main`). A shader that does not
     *  sample the atlas that way comes back unchanged. */
    fun crisp(fragment: String): String {
        val call = "texture(uTexture, vTexCoord)"
        val main = fragment.indexOf("void main()")
        if (main < 0 || !fragment.contains(call)) return fragment
        val helper = ATLAS_TEXEL
            .replace("ATLAS_SIZE", TextureAtlas.SIZE_PX.toString())
            .replace("ATLAS_TOP_MIP", (TextureAtlas.MIP_LEVELS - 1).toString())
        return fragment.substring(0, main) + helper + "\n" + fragment.substring(main).replace(call, "atlasTexel(vTexCoord)")
    }

    /** Opaque blocks: texture, baked shade, fog. Deliberately has no `discard`. */
    const val OPAQUE_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;

out vec4 fragColor;

void main() {
    vec3 shaded = texture(uTexture, vTexCoord).rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /** uFade: xy = centre of the voxel area (world X/Z), z = radius where the dissolve starts,
     *  w = width of the dissolve (0 = off). Fragments dissolve with an ordered-noise threshold
     *  that grows from 0 at z to 1 at z + w, so the LOD mesh behind shows through more and more. */
    const val OPAQUE_FADE_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec2 vWorldXZ;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec4 uFade;

out vec4 fragColor;

void main() {
    highp vec2 fd = vWorldXZ - uFade.xy;
    highp float fd2 = dot(fd, fd);
    if (uFade.w > 0.0 && fd2 > uFade.z * uFade.z) {
        highp float t = clamp((sqrt(fd2) - uFade.z) / uFade.w, 0.0, 1.0);
        highp float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
        if (n < t) discard;
    }
    vec3 shaded = texture(uTexture, vTexCoord).rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /** Alpha-tested terrain (leaf and plant tiles carry real transparent holes) and the
     *  overlay meshes. Same rim dissolve as [OPAQUE_FADE_FRAGMENT]; uFade.w = 0 turns it off. */
    const val FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec2 vWorldXZ;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uAlpha;
uniform highp vec4 uFade;

out vec4 fragColor;

void main() {
    highp vec2 fd = vWorldXZ - uFade.xy;
    highp float fd2 = dot(fd, fd);
    if (uFade.w > 0.0 && fd2 > uFade.z * uFade.z) {
        highp float t = clamp((sqrt(fd2) - uFade.z) / uFade.w, 0.0, 1.0);
        highp float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
        if (n < t) discard;
    }
    vec4 texColor = texture(uTexture, vTexCoord);
    if (texColor.a < 0.5) discard;
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, texColor.a * uAlpha);
}
"""

    /** uCenter: world X/Z the band radii are measured from.
     *  uBand: x = inner radius, y = outer radius, z = how far (blocks) to sink this tile at
     *  the inner edge, w = length of the zone over which that sinking fades out. */
    const val FAR_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;
out highp vec3 vWorld;

void main() {
    vec3 p = aPosition;
    highp float dist = length(p.xz - uCenter);
    float t = clamp((dist - uBand.x) / max(uBand.w, 1.0), 0.0, 1.0);
    p.y -= uBand.z * (1.0 - t * t * (3.0 - 2.0 * t));
    gl_Position = uViewProj * vec4(p, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
    vWorld = aPosition;
}
"""

    /** uClip: xy = centre of the clipped circle (world X/Z), z = its radius SQUARED.
     *  Fragments inside the circle belong to full-detail chunks and are dropped.
     *  uBand.xy = inner / outer radius of this level's ring (see FAR_VERTEX).
     *
     *  The grain block reproduces ChunkMesher.variation: a hash of the whole-block cell gives
     *  every block a brightness between 94% and 100%, so near the voxel area the flat colours
     *  carry the same speckle as real blocks. It fades out with distance (where the real
     *  textures are mip-mapped to their average colour anyway). The hash is done on highp
     *  integers on purpose: mediump ints are 16 bit on some GPUs. */
    const val FAR_FRAGMENT = """#version 300 es
precision mediump float;
precision highp int;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec3 vWorld;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec3 uClip;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec4 fragColor;

void main() {
    highp vec2 dc = vWorld.xz - uClip.xy;
    if (dot(dc, dc) < uClip.z) discard;
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 > uBand.y * uBand.y) discard;

    vec3 shaded = texture(uTexture, vTexCoord).rgb * vShade;
    if (vFogDist < 440.0) {
        highp vec3 q = floor(vWorld + vec3(0.0005));
        uvec3 u = uvec3(ivec3(q));
        uint h = (u.x * 73856093u) ^ (u.y * 19349663u) ^ (u.z * 83492791u);
        h ^= h >> 15u;
        h *= 739982445u;
        h ^= h >> 13u;
        float g = float((h >> 8u) & 255u) * (1.0 / 255.0);
        float amp = 1.0 - smoothstep(170.0, 440.0, vFogDist);
        shaded *= 1.0 + amp * (0.5 - g) * 0.12;
    }
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /**
     * Water vertex data (see ChunkMesher): position, then in the "uv" slots (x = depth of the
     * water below the vertex in blocks, or -1 for a side face; y = flow X) and in the shade
     * slot the flow Z. Flow is a vector of length 0..1 pointing the way the water runs.
     * There is no vertex swell any more: water is flat and animated by its texture only, like
     * the rest of the blocky world.
     */
    const val WATER_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aData;
layout(location = 2) in float aFlowZ;

uniform mat4 uViewProj;

out highp vec3 vWorld;
out float vDepth;
out vec2 vFlow;
out float vFogDist;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vWorld = aPosition;
    vDepth = aData.x;
    vFlow = vec2(aData.y, aFlowZ);
    vFogDist = gl_Position.w;
}
"""

    /** uClip / uBand: same meaning as in FAR_FRAGMENT (near water passes a band that spans the
     *  voxel area, or everything). uWaterTex: the 16x16 pixel-art water tile (see WaterTexture),
     *  one repeat per block, drifting slowly (or with the flow). One texture fetch per pixel and
     *  no per-pixel trigonometry: water covers a large part of the screen over an ocean, and it
     *  is the one translucent layer, so it has to be cheap on weak GPUs.
     *
     *  The pattern is the same at every distance: the tile's own mip chain averages it away where
     *  it gets smaller than a pixel, and past 260 blocks nothing but the average colour is left.
     *  (Far away the fetch only ever touches the smallest mip levels, which cost next to
     *  nothing.) */
    const val WATER_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec3 vWorld;
in float vDepth;
in vec2 vFlow;
in float vFogDist;

uniform sampler2D uWaterTex;
uniform highp float uTime;
uniform highp vec3 uEye;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec3 uClip;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec4 fragColor;

void main() {
    highp vec2 dc = vWorld.xz - uClip.xy;
    if (dot(dc, dc) < uClip.z) discard;
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;

    // Tops are textured in world X/Z; side faces (depth marker -1) in (x + z, y) so a waterfall
    // gets tall streaks that run down the face.
    float side = step(vDepth, -0.5);
    highp vec2 p = mix(vWorld.xz, vec2(vWorld.x + vWorld.z, vWorld.y), side);
    // Running water carries the pattern along its flow; still water drifts very slowly. (All
    // rates are multiples of 1/1000 tile per second, so the drift wraps cleanly with uTime.)
    highp vec2 vel = mix(vFlow * 0.9 + vec2(0.037, 0.021), vec2(0.0, -0.9), side);
    highp vec2 uv = p - vel * uTime;

    // The tile's average colour; the pattern fades into it between 150 and 260 blocks, which is
    // where the mip chain has already averaged it away.
    float near = 1.0 - smoothstep(150.0, 260.0, vFogDist);
    vec3 col = mix(vec3(0.28, 0.50, 0.85), texture(uWaterTex, uv).rgb, near);

    // Depth tint: bright azure in the shallows, deep blue over deep water (saturates at 8
    // blocks, which is what lets the mesher merge flat deep water into big quads).
    float depthK = sqrt(clamp(max(vDepth, 0.0) / 8.0, 0.0, 1.0));
    col *= mix(vec3(1.10, 1.12, 1.0), vec3(0.62, 0.76, 0.94), depthK);
    col = mix(col, vec3(0.88, 0.95, 1.0), side * 0.12);

    // At grazing angles the surface mirrors the sky: tint towards the horizon colour and get
    // more opaque. Cheap (no pow) and it also calms the far ocean.
    highp vec3 toEye = uEye - vWorld;
    float cosT = abs(toEye.y) * inversesqrt(dot(toEye, toEye) + 0.0001);
    float f = 1.0 - cosT;
    f *= f;
    float fres = f * f * (1.0 - side);
    col = mix(col, uFogColor, fres * 0.45);

    // Opacity follows the length of the light path through the water: straight down over a
    // shallow shore you still see the sand, but a slanted view through even two or three
    // blocks of water is nearly opaque (so seabed steps never show as dark lines), and the
    // far sea is solid.
    float path = max(vDepth, 0.0) / max(cosT, 0.25);
    float alpha = 0.97 - 0.39 * exp(-0.55 * path);
    alpha = mix(alpha, 0.97, smoothstep(60.0, 400.0, vFogDist));
    alpha = mix(alpha, 0.80, side);
    alpha = clamp(alpha + fres * 0.15, 0.0, 0.98);

    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);
}
"""

    /** The cloud mesh (see CloudRenderer): one tile of blocky clouds, drawn 3 x 3 times with
     *  instancing. aPos is tile-local; uOrigin is the world X/Z of the first instance's tile. */
    const val CLOUD_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in float aShade;

uniform mat4 uViewProj;
uniform highp vec2 uOrigin;
uniform highp float uTile;
uniform highp float uBaseY;

out highp vec3 vWorld;
out float vShade;

void main() {
    float fx = float(gl_InstanceID % 3);
    float fz = float(gl_InstanceID / 3);
    highp vec3 p = vec3(uOrigin.x + fx * uTile + aPos.x, uBaseY + aPos.y, uOrigin.y + fz * uTile + aPos.z);
    vWorld = p;
    vShade = aShade;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    /** Clouds: baked per-vertex shade turned into a white-to-blue-grey colour, then dissolved
     *  into the sky gradient with distance (so no alpha blending and no visible far edge).
     *  uBand restricts which 3D distances from the eye are drawn: the far pass draws the far
     *  part of the sky, the voxel pass the near part (the two use different depth ranges). */
    const val CLOUD_FRAGMENT = """#version 300 es
precision highp float;

in highp vec3 vWorld;
in float vShade;

uniform highp vec3 uEye;
uniform highp float uRadius;
uniform highp vec2 uBand;
uniform vec3 uHorizon;
uniform vec3 uZenith;

out vec4 fragColor;

void main() {
    vec3 d = vWorld - uEye;
    float dist = length(d);
    if (dist < uBand.x || dist >= uBand.y || dist >= uRadius) discard;

    // Lit white on top and towards the sun, a cool blue-grey underneath and away from it.
    vec3 col = mix(vec3(0.50, 0.58, 0.74), vec3(1.0), clamp(vShade, 0.0, 1.0));

    // Distant clouds dissolve into the sky itself (the same gradient the sky pass draws), so
    // the edge of the cloud field is invisible without any alpha blending.
    float h = clamp(d.y / max(dist, 0.001), 0.0, 1.0);
    vec3 sky = mix(uHorizon, uZenith, sqrt(h));
    col = mix(col, sky, smoothstep(0.42 * uRadius, uRadius, dist));
    fragColor = vec4(col, 1.0);
}
"""

    /** One oversized triangle covering the screen; no vertex buffer needed. */
    const val SKY_VERTEX = """#version 300 es
out vec2 vNdc;

void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = corner * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"""

    /** uForward/uRight/uUp: the camera basis; uTan.x = tan(fovY / 2) * aspect, uTan.y = tan(fovY / 2).
     *  The sun terms only matter near the sun, so every other pixel skips their pow() calls
     *  (at 0.6 the skipped part of the glow is below 0.001, so there is no visible edge). */
    const val SKY_FRAGMENT = """#version 300 es
precision highp float;

in vec2 vNdc;

uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;

out vec4 fragColor;

void main() {
    vec3 dir = normalize(uForward + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, sqrt(h));
    float sd = dot(dir, uSunDir);
    if (sd > 0.6) {
        col += vec3(1.0, 0.90, 0.68) * (pow(sd, 1500.0) * 2.0 + pow(sd, 10.0) * 0.14);
    }
    fragColor = vec4(col, 1.0);
}
"""
}
