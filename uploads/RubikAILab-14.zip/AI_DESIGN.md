# AI design

## One model of every puzzle
`rust/src/puzzle.rs` describes each puzzle as sticker polygons plus moves. A move is a rotation (axis, angle)
of every sticker whose centre projects into a layer interval on the axis. The permutation tables are
*generated* by rotating the stickers and matching them, and the renderer animates the very same rotation,
so simulation and drawing cannot disagree. Tests check the generated tables against known group facts:
3x3 quarter-turn BFS counts 1, 12, 114, 1068, 10011, 93840, 878880; 2x2 full state count 3,674,160 with the
exact published depth distribution; Skewb 3,149,280 states; Pyraminx 933,120 states (without tips).

## What the network sees
Pieces are found automatically (stickers that touch and lie in exactly the same turning layers). Every
piece slot the solver's moves can change contributes one active feature "piece P sits here with
orientation O", so the first layer is a sum of ~7 to 20 weight rows. Pieces that can swap places form an
orbit class; pieces of one class are told apart by their solved colour set.

## Training (approximate value iteration, no scramble labels)
```
target(s) = 0                       if s is solved
          = 1 + min over moves m of J_target(m(s))
```
The target network lags the trained one. A round: (1) draw a pool of random states and compute their
targets once with the frozen target network (the expensive part: one network call per move); (2) fit
the network on that pool for 2 to 4 epochs of minibatch Adam (Huber loss, gradient clipping); (3) refresh the
target network and, if the fit was good (85% of states within half a move), let the scramble depth grow.
30% of the states are drawn at the newest depths. Reusing each expensive target for several gradient steps
cuts the cost per gradient sample compared with recomputing targets for every sample.

### Why the AI cannot "just reverse the scramble"
- The trainer's labels come from the puzzle rules and the lagging network, never from the scramble that
  produced a state. A random walk is only a way to generate states.
- `Engine::solve` takes the sticker colours and nothing else. There is no API that accepts a move sequence.
- Held-out test scrambles are excluded from the training distribution (by state hash, at any depth), and
  the Test tab can also use brand-new random scrambles made at test time.
- Puzzles that can be turned as a whole (2x2, 3x3 with middle-layer turns, Skewb) are rotated into a canonical
  frame before searching and the answer is mapped back to moves on the puzzle as the player sees it; a test
  scrambles with *all* physical moves and checks that every returned solution really solves the puzzle.

## Search
Weighted A*: f = w * g + h. w = 1 is classic A*; the default 0.6 trades solution length for speed. The
learned heuristic is the network; the baseline is an admissible count of misplaced pieces per class
divided by how many pieces one move can change. Both are reported separately.

## Keeping the phone cool
- Work is done in 250 ms chunks followed by a rest so the CPU is busy only `duty` of the time.
- `ThermalGovernor` reads the battery temperature (all Android versions) and thermal status / headroom
  (Android 10 / 11+) every 2 s and lowers the duty when the phone is warmer than the preset's ceiling
  (Cool 37 C, Balanced 39.5 C, Fast 42.5 C), raises it slowly when there is room, and pauses for 20 s on a
  severe thermal status or 45 C.
- Presets also cap the threads (1 / 2 / 4, never more than half the cores). The thread runs at background priority.
- Fewer wasted network evaluations (pool reuse) means less heat for the same learning.

## Measured on the build machine (one x86 core, not a phone; 30 to 40 held-out cases, so noisy)
| Puzzle | training | result |
|---|---|---|
| 3x3, old trainer | 100 s | depth 12: 20/20, depth 14: 12/20 |
| 3x3, pool trainer, depth cap 12 | 100 s | about 1.6x the samples per second, similar solve rates |
| 3x3, pool trainer, depth cap 16 | 100 s | depth 12: 29/30, depth 14: 23/30, depth 16: 13/30 |
| 2x2 | 45 s | depth 14: 30/30, average 11 moves |
| Pyraminx | 40 s | depth 12: 30/30, average 7 moves |
| Skewb | 40 s | depth 12: 30/30, average 9 moves |
Phone speed will differ; the Test tab measures the real thing on the device.

## Method learning (Rust core)
Nothing is stored: all tables are derived from the move rules when the engine is created (background thread).
- Tracked-sticker BFS: the position of a few stickers is a closed abstraction of the cube, so BFS from solved gives
  exact distance tables (cross: 4 edges, 190k states; one table per corner+edge pair).
- 3x3 stages: cross -> pair 1..4 (IDA*, heuristic = max of the stage tables, everything solved earlier must stay
  solved) -> last layer. Algorithms are found by DFS over U/R/F turns up to length 10 that keep the first two layers
  intact (281 distinct last-layer effects); Dijkstra over 62208 states learns which algorithm to apply where.
- 2x2 / Skewb / Pyraminx: BFS table of all states within 7-8 moves, search meets it (solutions near optimal).
- Honest labelling: this is search/dynamic programming learned from the rules, not the neural network. The network
  (Train tab) is still trained and is the fallback when a method fails; the baseline mode is unchanged.

### Lessons (3x3)
Both methods put the cross on white (U) and the last layer on yellow (D). Stage = a few tracked stickers whose
positions must be home afterwards; the search is IDA* with exact tables learned by BFS (cross prefixes, corner +
edge pairs, single corners, single edges). The last layer is solved with discovered algorithms: DFS over D, R and F
turns up to 12 moves, pruned by the tables, keeping those that restore the first two layers (about 1000 distinct
effects). For each phase (OLL/PLL, or yellow cross/face/corners/edges) a multi-source Dijkstra over the 62208 last-layer
states learns which algorithm to apply, using only algorithms that keep the previous phase's goal intact.
