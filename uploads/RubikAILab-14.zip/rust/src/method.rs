//! "Method learning": solvers whose knowledge is learned from the move rules alone, with nothing prerecorded.
//!
//! * Small puzzles (2x2, Pyraminx, Skewb): a breadth-first table of every state within a few moves of solved,
//!   learned by exploring the rules; a short search from the scrambled state meets the table (optimal-ish).
//! * 3x3: two teachable methods, CFOP and the beginner layer-by-layer method, both with the white cross first.
//!   Tables for every stage (cross edges, corners, first-two-layer pairs, middle edges) are learned by BFS over the
//!   positions of a few tracked stickers. The last layer is solved with algorithms (macros) that the program
//!   discovers itself by searching for move sequences that change only the last layer; a Dijkstra over all
//!   62208 last-layer states then learns which algorithm to apply for every phase (OLL/PLL, or the four
//!   beginner phases). Nothing is stored or prerecorded.

use std::cmp::Reverse;
use std::collections::{BTreeMap, BinaryHeap, HashMap};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::OnceLock;
use std::time::Instant;

use crate::puzzle::{puzzle_by_id, Puzzle, K_CUBE2, K_CUBE3, K_PYRAMINX, K_SKEWB};
use crate::search::{K_CANCELLED, K_NODE_LIMIT, K_TIMEOUT};

pub struct Budget<'a> {
    start: Instant,
    timeout_ms: i32,
    cancel: &'a AtomicBool,
    pub nodes: u64,
}

impl<'a> Budget<'a> {
    pub fn new(timeout_ms: i32, cancel: &'a AtomicBool) -> Budget<'a> {
        Budget { start: Instant::now(), timeout_ms, cancel, nodes: 0 }
    }
    fn tick(&mut self) -> Result<(), i32> {
        self.nodes += 1;
        if self.nodes & 0x3FFF == 0 {
            if self.cancel.load(Ordering::Relaxed) {
                return Err(K_CANCELLED);
            }
            if self.start.elapsed().as_millis() as i64 > self.timeout_ms as i64 {
                return Err(K_TIMEOUT);
            }
        }
        Ok(())
    }
}

pub enum Method {
    Mitm(Mitm),
    Cube3(CubeMethod),
}

impl Method {
    /// `state` must be in the canonical frame. Returns solver moves, or a search status code on failure.
    pub fn solve(&self, pz: &Puzzle, state: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        match self {
            Method::Mitm(m) => m.solve(pz, state, b),
            Method::Cube3(c) => c.solve(pz, state, b),
        }
    }

    /// Step-by-step lesson (3x3 only; None for the other puzzles).
    pub fn teach(&self, pz: &Puzzle, state: &[u8], method: i32, b: &mut Budget) -> Option<Result<Vec<Step>, i32>> {
        match self {
            Method::Cube3(c) => Some(c.plan(pz, state, method, false, b)),
            Method::Mitm(_) => None,
        }
    }
}

static METHODS: [OnceLock<Option<Method>>; 6] =
    [OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new()];

/// The learned method of a puzzle, learning it first (once per process) when needed.
pub fn method_for(id: i32) -> Option<&'static Method> {
    if !(0..6).contains(&id) {
        return None;
    }
    METHODS[id as usize]
        .get_or_init(|| {
            let pz = puzzle_by_id(id)?;
            if !pz.valid || !pz.ai_supported {
                return None;
            }
            match id {
                K_CUBE2 => Some(Method::Mitm(Mitm::learn(pz, 8))),
                K_SKEWB => Some(Method::Mitm(Mitm::learn(pz, 7))),
                K_PYRAMINX => Some(Method::Mitm(Mitm::learn(pz, 7))),
                K_CUBE3 => Some(Method::Cube3(CubeMethod::learn(pz))),
                _ => None,
            }
        })
        .as_ref()
}

/// Starts learning in the background so the first solve does not wait.
pub fn start_learning(id: i32) {
    if (0..6).contains(&id) {
        std::thread::spawn(move || {
            let _ = method_for(id);
        });
    }
}

// ------------------------------------------------------------------------------------------ small puzzles

pub struct Mitm {
    table: HashMap<u64, u8>,
}

impl Mitm {
    fn learn(pz: &Puzzle, depth: usize) -> Mitm {
        let mut table: HashMap<u64, u8> = HashMap::new();
        let mut s0 = vec![0u8; pz.stickers];
        pz.set_solved(&mut s0);
        table.insert(pz.hash(&s0), 0);
        let mut cur: Vec<Vec<u8>> = vec![s0];
        for d in 1..=depth {
            let mut next: Vec<Vec<u8>> = Vec::new();
            for a in cur.iter() {
                for &m in pz.ai_moves.iter() {
                    let mut b = vec![0u8; pz.stickers];
                    pz.apply(a, &mut b, m);
                    let h = pz.hash(&b);
                    if !table.contains_key(&h) {
                        table.insert(h, d as u8);
                        next.push(b);
                    }
                }
            }
            cur = next;
        }
        Mitm { table }
    }

    fn dfs(
        &self,
        pz: &Puzzle,
        s: &[u8; 54],
        g: usize,
        lim: usize,
        prev: i32,
        path: &mut Vec<u8>,
        b: &mut Budget,
    ) -> Result<bool, i32> {
        b.tick()?;
        if self.table.contains_key(&pz.hash(s)) {
            return Ok(true);
        }
        if g == lim {
            return Ok(false);
        }
        for &m in pz.ai_moves.iter() {
            if prev >= 0 && m as i32 == (prev ^ 1) {
                continue;
            }
            let mut t = [0u8; 54];
            pz.apply(s, &mut t, m);
            path.push(m as u8);
            if self.dfs(pz, &t, g + 1, lim, m as i32, path, b)? {
                return Ok(true);
            }
            path.pop();
        }
        Ok(false)
    }

    fn solve(&self, pz: &Puzzle, start: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        let mut s = [0u8; 54];
        s[..pz.stickers].copy_from_slice(&start[..pz.stickers]);
        for lim in 0..=12usize {
            let mut path: Vec<u8> = Vec::new();
            if self.dfs(pz, &s, 0, lim, -1, &mut path, b)? {
                let mut cur = s;
                let mut t = [0u8; 54];
                for &m in path.iter() {
                    pz.apply(&cur, &mut t, m as usize);
                    cur = t;
                }
                // Finish by walking down the table.
                while !pz.is_solved(&cur) {
                    let d = match self.table.get(&pz.hash(&cur)) {
                        Some(&d) => d,
                        None => return Err(K_NODE_LIMIT),
                    };
                    let mut moved = false;
                    for &m in pz.ai_moves.iter() {
                        pz.apply(&cur, &mut t, m);
                        if let Some(&d2) = self.table.get(&pz.hash(&t)) {
                            if d2 + 1 == d {
                                cur = t;
                                path.push(m as u8);
                                moved = true;
                                break;
                            }
                        }
                    }
                    if !moved {
                        return Err(K_NODE_LIMIT);
                    }
                }
                return Ok(path);
            }
        }
        Err(K_NODE_LIMIT)
    }
}

// ------------------------------------------------------------------------------------------ 3x3 methods

/// Colour indices on the 3x3 (faces are U R F D L B). The cross is built on white (U), the last layer is yellow (D).
const CROSS_COLOR: usize = 0;
const LL_COLOR: usize = 3;
const RING: [usize; 4] = [2, 1, 5, 4]; // F R B L

pub const METHOD_CFOP: i32 = 0;
pub const METHOD_BEGINNER: i32 = 1;

// Stage codes of a teaching step (the Kotlin side turns them into text).
pub const STAGE_CROSS_EDGE: i32 = 1; // one cross edge, mask_a = its two colours
pub const STAGE_CORNER: i32 = 2; // beginner: one first-layer corner, mask_a = its colours
pub const STAGE_MIDDLE: i32 = 3; // beginner: one middle-layer edge, mask_a = its colours
pub const STAGE_F2L: i32 = 4; // CFOP: corner + edge pair, mask_a = corner, mask_b = edge
pub const STAGE_YCROSS: i32 = 5; // beginner: cross on the last layer (algorithm)
pub const STAGE_YFACE: i32 = 6; // beginner: finish the last-layer face (algorithm)
pub const STAGE_YCORNERS: i32 = 7; // beginner: put the last-layer corners in place (algorithm)
pub const STAGE_YEDGES: i32 = 8; // beginner: put the last-layer edges in place (algorithm)
pub const STAGE_OLL: i32 = 9; // CFOP: orient the last layer (algorithm)
pub const STAGE_PLL: i32 = 10; // CFOP: permute the last layer (algorithm)
pub const STAGE_CROSS_ALL: i32 = 11; // the whole cross at once (fast solve)

/// Algorithms are found by searching move sequences up to this length that leave the first two layers intact.
const MACRO_DEPTH: usize = 12;
/// States of the last layer are enumerated with algorithms up to this length; the first phases use them too.
const ENUM_CAP: usize = 8;

#[derive(Clone, Copy)]
struct Tracker {
    mask: usize,
    want: u8,
}

fn home_of(pz: &Puzzle, t: &Tracker) -> Option<usize> {
    for s in pz.slots.iter() {
        let mut mk = 0usize;
        for k in 0..s.n {
            mk |= 1 << pz.solved[s.stickers[k]];
        }
        if mk == t.mask {
            for k in 0..s.n {
                if pz.solved[s.stickers[k]] == t.want {
                    return Some(s.stickers[k]);
                }
            }
        }
    }
    None
}

fn pos_in(pz: &Puzzle, st: &[u8], t: &Tracker) -> Option<usize> {
    for s in pz.slots.iter() {
        let mut mk = 0usize;
        for k in 0..s.n {
            mk |= 1 << st[s.stickers[k]];
        }
        if mk == t.mask {
            for k in 0..s.n {
                if st[s.stickers[k]] == t.want {
                    return Some(s.stickers[k]);
                }
            }
        }
    }
    None
}

/// Exact distance table over the positions of 1..4 tracked stickers (an abstraction of the cube that is closed
/// under moves), learned by breadth-first search from the solved positions.
struct Table {
    d: Vec<u8>,
}

fn tkey(n: usize, p: &[u8]) -> usize {
    let mut k = 0usize;
    for i in 0..n {
        k = k * 54 + p[i] as usize;
    }
    k
}

fn build_table(inv: &[[u8; 54]; 12], homes: &[u8]) -> Table {
    let n = homes.len();
    let mut size = 1usize;
    for _ in 0..n {
        size *= 54;
    }
    let mut d = vec![255u8; size];
    let mut h = [0u8; 4];
    h[..n].copy_from_slice(homes);
    d[tkey(n, &h)] = 0;
    let mut cur: Vec<[u8; 4]> = vec![h];
    let mut depth = 0u8;
    while !cur.is_empty() {
        let mut next: Vec<[u8; 4]> = Vec::new();
        for s in cur.iter() {
            for m in 0..12 {
                let mut x = [0u8; 4];
                for i in 0..n {
                    x[i] = inv[m][s[i] as usize];
                }
                let k = tkey(n, &x);
                if d[k] == 255 {
                    d[k] = depth + 1;
                    next.push(x);
                }
            }
        }
        cur = next;
        depth += 1;
    }
    Table { d }
}

// Table ids: 0..3 cross prefixes (1..4 edges), 4..7 corner+edge pairs, 8..11 single corners, 12..15 single edges.
const T_CROSS: usize = 0;
const T_PAIR: usize = 4;
const T_CORNER: usize = 8;
const T_EDGE: usize = 12;

#[derive(Clone)]
struct Heur {
    table: usize,
    n: usize,
    idx: [usize; 4],
}

fn heur(table: usize, idx: &[usize]) -> Heur {
    let mut h = Heur { table, n: idx.len(), idx: [0; 4] };
    h.idx[..idx.len()].copy_from_slice(idx);
    h
}

/// One teaching stage: the pieces that must be home afterwards (tracked) and the tables that bound the search.
struct Spec {
    tr: Vec<Tracker>,
    heur: Vec<Heur>,
}

struct Macro {
    moves: Vec<u8>,
    inv: [u8; 20], // applying the inverse algorithm to a last-layer state: t[i] = cur[inv[i]]
}

#[derive(Clone, Copy, PartialEq)]
enum Goal {
    Edges,   // the four last-layer edges show the last-layer colour on the last-layer face
    Face,    // the whole last-layer face is one colour
    Corners, // every last-layer corner is in its own place
    Solved,
}

struct LastLayer {
    keep_pos: Vec<usize>,
    ll_pos: Vec<usize>,
    face_idx: Vec<usize>,
    edge_face_idx: Vec<usize>,
    corner_ll: Vec<[usize; 3]>,
    corner_mask: Vec<usize>,
    solved: [u8; 20],
}

impl LastLayer {
    fn goal(&self, g: Goal, s: &[u8; 20]) -> bool {
        match g {
            Goal::Edges => self.edge_face_idx.iter().all(|&i| s[i] as usize == LL_COLOR),
            Goal::Face => self.face_idx.iter().all(|&i| s[i] as usize == LL_COLOR),
            Goal::Corners => {
                for c in 0..self.corner_ll.len() {
                    let mut mk = 0usize;
                    for k in 0..3 {
                        mk |= 1 << s[self.corner_ll[c][k]];
                    }
                    if mk != self.corner_mask[c] {
                        return false;
                    }
                }
                true
            }
            Goal::Solved => *s == self.solved,
        }
    }

    fn holds(&self, need: &[Goal], s: &[u8; 20]) -> bool {
        need.iter().all(|&g| self.goal(g, s))
    }
}

/// How to get from any last-layer state of a phase to the phase goal by whole algorithms.
struct Phase {
    stage: i32,
    next: Vec<i32>,
    next_macro: Vec<i32>,
    dist: Vec<i32>,
}

struct PhaseDef {
    stage: i32,
    need: Vec<Goal>,
    target: Goal,
    cap: usize,
}

fn hash_ll(a: &[u8; 20]) -> u64 {
    let mut h: u64 = 1469598103934665603;
    for &b in a.iter() {
        h ^= b as u64;
        h = h.wrapping_mul(1099511628211);
    }
    h ^ (h >> 29)
}

/// Depth-first discovery of algorithms: sequences of D, R and F turns that restore the first two layers (the
/// tracked pieces) while changing the last layer. Pruned by the exact distance tables of those pieces.
#[allow(clippy::too_many_arguments)]
fn dfs_macros(
    pz: &Puzzle,
    inv: &[[u8; 54]; 12],
    tables: &[Table],
    f2l_home: &[u8; 12],
    ll_pos: &[usize],
    tp: &[u8; 12],
    lim: usize,
    path: &mut Vec<u8>,
    best: &mut BTreeMap<[u8; 20], Vec<u8>>,
) {
    let g = path.len();
    let mut h = tables[T_CROSS + 3].d[tkey(4, &tp[0..4])] as usize;
    for k in 0..4 {
        let v = tables[T_PAIR + k].d[tkey(2, &tp[4 + 2 * k..6 + 2 * k])] as usize;
        if v > h {
            h = v;
        }
    }
    if g > 0 && h == 0 && tp[..] == f2l_home[..] {
        let mut s = [0u8; 54];
        for i in 0..54 {
            s[i] = i as u8;
        }
        for &m in path.iter() {
            let mut t = [0u8; 54];
            for i in 0..54 {
                t[i] = s[pz.perm[m as usize][i] as usize];
            }
            s = t;
        }
        let mut key = [0u8; 20];
        let mut same = true;
        for i in 0..20 {
            key[i] = s[ll_pos[i]];
            if key[i] as usize != ll_pos[i] {
                same = false;
            }
        }
        if !same {
            let better = match best.get(&key) {
                Some(old) => old.len() > path.len(),
                None => true,
            };
            if better {
                best.insert(key, path.clone());
            }
        }
    }
    if g + h > lim || g == lim {
        return;
    }
    let prev: i32 = if g > 0 { path[g - 1] as i32 } else { -1 };
    let prev2: i32 = if g > 1 { path[g - 2] as i32 } else { -1 };
    for &m in [6usize, 7, 2, 3, 4, 5].iter() {
        if prev >= 0 {
            if m as i32 == (prev ^ 1) {
                continue;
            }
            if m as i32 == prev && prev2 == prev {
                continue;
            }
            let fm = m / 2;
            let fp = (prev / 2) as usize;
            if fm % 3 == fp % 3 && fm < fp {
                continue;
            }
        }
        let mut q = [0u8; 12];
        for i in 0..12 {
            q[i] = inv[m][tp[i] as usize];
        }
        path.push(m as u8);
        dfs_macros(pz, inv, tables, f2l_home, ll_pos, &q, lim, path, best);
        path.pop();
    }
}

/// Multi-source Dijkstra from the goal states of a phase, applying inverse algorithms that keep the previous
/// phases' goals intact. Costs are numbers of quarter turns.
fn build_phase(
    ll: &LastLayer,
    states: &[[u8; 20]],
    index: &HashMap<u64, usize>,
    macros: &[Macro],
    def: &PhaseDef,
) -> Phase {
    let n = states.len();
    let mut prev_states: Vec<usize> = Vec::new();
    for i in 0..n {
        if ll.holds(&def.need, &states[i]) {
            prev_states.push(i);
        }
    }
    let mut allowed: Vec<usize> = Vec::new();
    for (mi, mc) in macros.iter().enumerate() {
        if mc.moves.len() > def.cap {
            continue;
        }
        let mut ok = true;
        if !def.need.is_empty() {
            for &si in prev_states.iter() {
                let mut t = [0u8; 20];
                for i in 0..20 {
                    t[i] = states[si][mc.inv[i] as usize];
                }
                if !ll.holds(&def.need, &t) {
                    ok = false;
                    break;
                }
            }
        }
        if ok {
            allowed.push(mi);
        }
    }
    let mut dist = vec![-1i32; n];
    let mut next = vec![-1i32; n];
    let mut next_macro = vec![-1i32; n];
    let mut heap: BinaryHeap<Reverse<(i32, usize)>> = BinaryHeap::new();
    for &si in prev_states.iter() {
        if ll.goal(def.target, &states[si]) {
            dist[si] = 0;
            heap.push(Reverse((0, si)));
        }
    }
    while let Some(Reverse((c0, id))) = heap.pop() {
        if c0 > dist[id] {
            continue;
        }
        let cur = states[id];
        for &mi in allowed.iter() {
            let mc = &macros[mi];
            let mut t = [0u8; 20];
            for i in 0..20 {
                t[i] = cur[mc.inv[i] as usize];
            }
            let nid = match index.get(&hash_ll(&t)) {
                Some(&x) => x,
                None => continue,
            };
            let c = c0 + mc.moves.len() as i32;
            if dist[nid] < 0 || c < dist[nid] {
                dist[nid] = c;
                next[nid] = id as i32;
                next_macro[nid] = mi as i32;
                heap.push(Reverse((c, nid)));
            }
        }
    }
    Phase { stage: def.stage, next, next_macro, dist }
}

/// One step of a lesson: what to do and the moves (solver moves of the canonical frame) that do it.
#[derive(Clone, Debug)]
pub struct Step {
    pub stage: i32,
    pub mask_a: u32,
    pub mask_b: u32,
    pub alg: i32, // index of the discovered algorithm for last-layer steps, -1 otherwise
    pub moves: Vec<u8>,
}

pub struct CubeMethod {
    inv: [[u8; 54]; 12], // after move m the sticker at p sits at inv[m][p]
    cross_t: [Tracker; 4],
    corner_t: [Tracker; 4],
    edge_t: [Tracker; 4],
    tables: Vec<Table>,
    ll: LastLayer,
    macros: Vec<Macro>,
    states: Vec<[u8; 20]>,
    index: HashMap<u64, usize>,
    cfop: Vec<Phase>,
    beginner: Vec<Phase>,
}

struct Ida<'a> {
    m: &'a CubeMethod,
    spec: &'a Spec,
    n: usize,
    limit: usize,
    path: Vec<u8>,
}

impl<'a> Ida<'a> {
    fn h(&self, p: &[u8; 16]) -> usize {
        let mut best = 0usize;
        for e in self.spec.heur.iter() {
            let mut q = [0u8; 4];
            for i in 0..e.n {
                q[i] = p[e.idx[i]];
            }
            let v = self.m.tables[e.table].d[tkey(e.n, &q)] as usize;
            if v > best {
                best = v;
            }
        }
        best
    }

    fn dfs(&mut self, p: &[u8; 16], g: usize, prev: i32, prev2: i32, b: &mut Budget) -> Result<bool, i32> {
        b.tick()?;
        let h = self.h(p);
        if h == 0 {
            return Ok(true);
        }
        if g + h > self.limit || g == self.limit {
            return Ok(false);
        }
        for m in 0..12usize {
            if prev >= 0 {
                if m as i32 == (prev ^ 1) {
                    continue;
                }
                if m as i32 == prev && prev2 == prev {
                    continue;
                }
                let fm = m / 2;
                let fp = (prev / 2) as usize;
                if fm % 3 == fp % 3 && fm < fp {
                    continue;
                }
            }
            let mut q = [0u8; 16];
            for i in 0..self.n {
                q[i] = self.m.inv[m][p[i] as usize];
            }
            self.path.push(m as u8);
            if self.dfs(&q, g + 1, m as i32, prev, b)? {
                return Ok(true);
            }
            self.path.pop();
        }
        Ok(false)
    }
}

impl CubeMethod {
    fn learn(pz: &Puzzle) -> CubeMethod {
        let mut inv = [[0u8; 54]; 12];
        for m in 0..12 {
            for q in 0..54 {
                inv[m][pz.perm[m][q] as usize] = q as u8;
            }
        }
        let x = CROSS_COLOR;
        let blank = Tracker { mask: 0, want: 0 };
        let mut cross_t = [blank; 4];
        let mut corner_t = [blank; 4];
        let mut edge_t = [blank; 4];
        for i in 0..4 {
            let a = RING[i];
            let b = RING[(i + 1) % 4];
            cross_t[i] = Tracker { mask: (1 << x) | (1 << a), want: x as u8 };
            corner_t[i] = Tracker { mask: (1 << x) | (1 << a) | (1 << b), want: x as u8 };
            edge_t[i] = Tracker { mask: (1 << a) | (1 << b), want: a as u8 };
        }
        let home = |t: &Tracker| home_of(pz, t).unwrap_or(0) as u8;

        let mut tables: Vec<Table> = Vec::new();
        for k in 0..4 {
            let homes: Vec<u8> = (0..=k).map(|i| home(&cross_t[i])).collect();
            tables.push(build_table(&inv, &homes));
        }
        for k in 0..4 {
            tables.push(build_table(&inv, &[home(&corner_t[k]), home(&edge_t[k])]));
        }
        for k in 0..4 {
            tables.push(build_table(&inv, &[home(&corner_t[k])]));
        }
        for k in 0..4 {
            tables.push(build_table(&inv, &[home(&edge_t[k])]));
        }

        // Last layer: the stickers of the eight last-layer pieces; everything else must stay home in an algorithm.
        let mut keep_pos: Vec<usize> = Vec::new();
        let mut ll_pos: Vec<usize> = Vec::new();
        for s in pz.slots.iter() {
            let mut mk = 0usize;
            for k in 0..s.n {
                mk |= 1 << pz.solved[s.stickers[k]];
            }
            let is_ll = ((mk >> LL_COLOR) & 1) != 0 && s.n > 1;
            for k in 0..s.n {
                if is_ll {
                    ll_pos.push(s.stickers[k]);
                } else {
                    keep_pos.push(s.stickers[k]);
                }
            }
        }
        let mut solved = [0u8; 20];
        for i in 0..20 {
            solved[i] = pz.solved[ll_pos[i]];
        }
        let mut face_idx: Vec<usize> = Vec::new();
        let mut edge_face_idx: Vec<usize> = Vec::new();
        for i in 0..20 {
            let p = ll_pos[i];
            if pz.face_of[p] as usize == LL_COLOR {
                face_idx.push(i);
                if pz.slots[pz.slot_of[p] as usize].n == 2 {
                    edge_face_idx.push(i);
                }
            }
        }
        let mut corner_ll: Vec<[usize; 3]> = Vec::new();
        let mut corner_mask: Vec<usize> = Vec::new();
        for s in pz.slots.iter() {
            if s.n != 3 {
                continue;
            }
            let mut mk = 0usize;
            for k in 0..3 {
                mk |= 1 << pz.solved[s.stickers[k]];
            }
            if ((mk >> LL_COLOR) & 1) == 0 {
                continue;
            }
            let mut a = [0usize; 3];
            for k in 0..3 {
                for i in 0..20 {
                    if ll_pos[i] == s.stickers[k] {
                        a[k] = i;
                    }
                }
            }
            corner_ll.push(a);
            corner_mask.push(mk);
        }
        let ll = LastLayer { keep_pos, ll_pos, face_idx, edge_face_idx, corner_ll, corner_mask, solved };

        // Discover algorithms with the first two layers (cross, corners, middle edges) as tracked pieces.
        let mut f2l_home = [0u8; 12];
        for i in 0..4 {
            f2l_home[i] = home(&cross_t[i]);
            f2l_home[4 + 2 * i] = home(&corner_t[i]);
            f2l_home[5 + 2 * i] = home(&edge_t[i]);
        }
        let mut best: BTreeMap<[u8; 20], Vec<u8>> = BTreeMap::new();
        let mut path: Vec<u8> = Vec::new();
        for lim in 1..=MACRO_DEPTH {
            dfs_macros(pz, &inv, &tables, &f2l_home, &ll.ll_pos, &f2l_home, lim, &mut path, &mut best);
        }
        let mut pos_of = [0usize; 54];
        for i in 0..20 {
            pos_of[ll.ll_pos[i]] = i;
        }
        let mut macros: Vec<Macro> = Vec::new();
        for (key, moves) in best.iter() {
            let mut perm = [0u8; 20];
            let mut minv = [0u8; 20];
            for i in 0..20 {
                perm[i] = pos_of[key[i] as usize] as u8;
            }
            for i in 0..20 {
                minv[perm[i] as usize] = i as u8;
            }
            macros.push(Macro { moves: moves.clone(), inv: minv });
        }

        // Every last-layer state (62208), reached with the short algorithms.
        let mut states: Vec<[u8; 20]> = vec![solved];
        let mut index: HashMap<u64, usize> = HashMap::new();
        index.insert(hash_ll(&solved), 0);
        let mut at = 0usize;
        while at < states.len() {
            let cur = states[at];
            for mc in macros.iter() {
                if mc.moves.len() > ENUM_CAP {
                    continue;
                }
                let mut t = [0u8; 20];
                for i in 0..20 {
                    t[i] = cur[mc.inv[i] as usize];
                }
                let h = hash_ll(&t);
                if !index.contains_key(&h) {
                    index.insert(h, states.len());
                    states.push(t);
                }
            }
            at += 1;
        }

        // The phases of both methods, built in parallel.
        let defs: Vec<PhaseDef> = vec![
            PhaseDef { stage: STAGE_OLL, need: vec![], target: Goal::Face, cap: ENUM_CAP },
            PhaseDef { stage: STAGE_PLL, need: vec![Goal::Face], target: Goal::Solved, cap: MACRO_DEPTH },
            PhaseDef { stage: STAGE_YCROSS, need: vec![], target: Goal::Edges, cap: ENUM_CAP },
            PhaseDef { stage: STAGE_YFACE, need: vec![Goal::Edges], target: Goal::Face, cap: MACRO_DEPTH },
            PhaseDef { stage: STAGE_YCORNERS, need: vec![Goal::Face], target: Goal::Corners, cap: MACRO_DEPTH },
            PhaseDef {
                stage: STAGE_YEDGES,
                need: vec![Goal::Face, Goal::Corners],
                target: Goal::Solved,
                cap: MACRO_DEPTH,
            },
        ];
        let mut built: Vec<Phase> = {
            let ll_ref = &ll;
            let st_ref = &states[..];
            let ix_ref = &index;
            let mc_ref = &macros[..];
            std::thread::scope(|sc| {
                let handles: Vec<_> = defs
                    .iter()
                    .map(|d| sc.spawn(move || build_phase(ll_ref, st_ref, ix_ref, mc_ref, d)))
                    .collect();
                handles.into_iter().map(|h| h.join().expect("phase thread")).collect()
            })
        };
        let beginner = built.split_off(2);
        let cfop = built;

        CubeMethod { inv, cross_t, corner_t, edge_t, tables, ll, macros, states, index, cfop, beginner }
    }

    // ---------------------------------------------------------------- stage specs

    fn spec_cross(&self, k: usize) -> Spec {
        let tr: Vec<Tracker> = (0..=k).map(|i| self.cross_t[i]).collect();
        let idx: Vec<usize> = (0..=k).collect();
        Spec { tr, heur: vec![heur(T_CROSS + k, &idx)] }
    }

    fn spec_base(&self) -> Spec {
        Spec { tr: self.cross_t.to_vec(), heur: vec![heur(T_CROSS + 3, &[0, 1, 2, 3])] }
    }

    fn spec_f2l(&self, k: usize) -> Spec {
        let mut s = self.spec_base();
        for j in 0..=k {
            s.tr.push(self.corner_t[j]);
            s.tr.push(self.edge_t[j]);
            s.heur.push(heur(T_PAIR + j, &[4 + 2 * j, 5 + 2 * j]));
        }
        s
    }

    fn spec_corner(&self, k: usize) -> Spec {
        let mut s = self.spec_base();
        for j in 0..=k {
            s.tr.push(self.corner_t[j]);
            s.heur.push(heur(T_CORNER + j, &[4 + j]));
        }
        s
    }

    fn spec_middle(&self, k: usize) -> Spec {
        let mut s = self.spec_base();
        for j in 0..4 {
            s.tr.push(self.corner_t[j]);
            s.heur.push(heur(T_CORNER + j, &[4 + j]));
        }
        for j in 0..=k {
            s.tr.push(self.edge_t[j]);
            s.heur.push(heur(T_EDGE + j, &[8 + j]));
        }
        s
    }

    /// Searches the shortest move sequence that puts the stage's pieces home while keeping everything tracked.
    fn run_stage(
        &self,
        pz: &Puzzle,
        s: &mut [u8; 54],
        stage: i32,
        masks: (usize, usize),
        spec: &Spec,
        steps: &mut Vec<Step>,
        b: &mut Budget,
    ) -> Result<(), i32> {
        let n = spec.tr.len();
        let mut pos = [0u8; 16];
        for i in 0..n {
            pos[i] = pos_in(pz, s, &spec.tr[i]).ok_or(K_NODE_LIMIT)? as u8;
        }
        let mut ida = Ida { m: self, spec, n, limit: 0, path: Vec::new() };
        let mut found = false;
        for lim in 0..=20usize {
            ida.limit = lim;
            ida.path.clear();
            if ida.dfs(&pos, 0, -1, -1, b)? {
                found = true;
                break;
            }
        }
        if !found {
            return Err(K_NODE_LIMIT);
        }
        if !ida.path.is_empty() {
            let mut t = [0u8; 54];
            for &m in ida.path.iter() {
                pz.apply(&s[..], &mut t, m as usize);
                *s = t;
            }
            steps.push(Step { stage, mask_a: masks.0 as u32, mask_b: masks.1 as u32, alg: -1, moves: ida.path.clone() });
        }
        Ok(())
    }

    /// A complete lesson for the state (canonical frame): one step per piece or algorithm.
    /// `cross_all` builds the whole cross in one optimal step (used by the fast solver).
    pub fn plan(
        &self,
        pz: &Puzzle,
        start: &[u8],
        method: i32,
        cross_all: bool,
        b: &mut Budget,
    ) -> Result<Vec<Step>, i32> {
        let mut s = [0u8; 54];
        s.copy_from_slice(&start[..54]);
        let mut steps: Vec<Step> = Vec::new();

        if cross_all {
            let spec = self.spec_cross(3);
            self.run_stage(pz, &mut s, STAGE_CROSS_ALL, (0, 0), &spec, &mut steps, b)?;
        } else {
            for k in 0..4 {
                let spec = self.spec_cross(k);
                self.run_stage(pz, &mut s, STAGE_CROSS_EDGE, (self.cross_t[k].mask, 0), &spec, &mut steps, b)?;
            }
        }
        if method == METHOD_CFOP {
            for k in 0..4 {
                let spec = self.spec_f2l(k);
                let masks = (self.corner_t[k].mask, self.edge_t[k].mask);
                self.run_stage(pz, &mut s, STAGE_F2L, masks, &spec, &mut steps, b)?;
            }
        } else {
            for k in 0..4 {
                let spec = self.spec_corner(k);
                self.run_stage(pz, &mut s, STAGE_CORNER, (self.corner_t[k].mask, 0), &spec, &mut steps, b)?;
            }
            for k in 0..4 {
                let spec = self.spec_middle(k);
                self.run_stage(pz, &mut s, STAGE_MIDDLE, (self.edge_t[k].mask, 0), &spec, &mut steps, b)?;
            }
        }

        // The first two layers are done: the last layer is solved phase by phase with the discovered algorithms.
        for &p in self.ll.keep_pos.iter() {
            if s[p] != pz.solved[p] {
                return Err(K_NODE_LIMIT);
            }
        }
        let phases = if method == METHOD_CFOP { &self.cfop } else { &self.beginner };
        let mut t = [0u8; 54];
        for ph in phases.iter() {
            let mut cur = [0u8; 20];
            for i in 0..20 {
                cur[i] = s[self.ll.ll_pos[i]];
            }
            let mut id = match self.index.get(&hash_ll(&cur)) {
                Some(&i) => i,
                None => return Err(K_NODE_LIMIT),
            };
            if ph.dist[id] < 0 {
                return Err(K_NODE_LIMIT);
            }
            while ph.dist[id] > 0 {
                let mi = ph.next_macro[id] as usize;
                let mc = &self.macros[mi];
                for &m in mc.moves.iter() {
                    pz.apply(&s[..], &mut t, m as usize);
                    s = t;
                }
                steps.push(Step { stage: ph.stage, mask_a: 0, mask_b: 0, alg: mi as i32, moves: mc.moves.clone() });
                id = ph.next[id] as usize;
            }
        }
        if pz.is_solved(&s) {
            Ok(steps)
        } else {
            Err(K_NODE_LIMIT)
        }
    }

    /// Fast solve: CFOP with the cross built at once, all moves in one list.
    fn solve(&self, pz: &Puzzle, start: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        let steps = self.plan(pz, start, METHOD_CFOP, true, b)?;
        let mut all: Vec<u8> = Vec::new();
        for st in steps.iter() {
            all.extend_from_slice(&st.moves);
        }
        Ok(all)
    }
}
