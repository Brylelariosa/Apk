//! Engine = trainer + held-out test scrambles + inference snapshot + search, for one puzzle (port of
//! core/engine.cpp, plus the learned method solvers of method.rs).
//!
//! Threading: train/save/load/reset/configure are serialised by one mutex. solve/evaluate never touch the
//! trainable network; they read an immutable snapshot that the trainer republishes after every training chunk.
//!
//! Frames: puzzles whose solver moves cannot reorient the whole puzzle (2x2, 3x3 with slice turns, Skewb) are
//! solved in a canonical frame. solve() takes the puzzle exactly as the player sees it, rotates it into the
//! canonical frame, searches there and maps every move back to a move on the original puzzle. Only the sticker
//! colours go in; nothing about how the puzzle was scrambled is ever available to the solver.

use std::fs::File;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use crate::method::{method_for, start_learning, Budget, Step};
use crate::net::{estimate_cost, Model};
use crate::puzzle::{puzzle_by_id, Puzzle, K_MAX_AI_STICKERS};
use crate::rng::Rng;
use crate::search::{
    solve_weighted_astar, MisplacedHeuristic, NetHeuristic, SearchConfig, SearchResult, K_CANCELLED, K_INVALID,
    K_SOLVED, K_TIMEOUT,
};
use crate::trainer::{random_scramble, TestSet, TrainConfig, TrainStats, Trainer};

#[allow(dead_code)]
pub const K_LEARNED_MODE: i32 = 0;
pub const K_BASELINE_MODE: i32 = 1;

#[derive(Default)]
pub struct EvalResult {
    pub solved: i32,
    pub total: i32,
    pub avg_length: f64,
    pub avg_expanded: f64,
    pub avg_ms: f64,
    pub cancelled: bool,
}

pub struct Engine {
    puzzle: &'static Puzzle,
    model: Arc<Model>,
    tests: Arc<TestSet>,
    trainer: Mutex<Trainer>,
    snapshot: Mutex<Arc<Vec<f32>>>,
    cancel: AtomicBool,
}

impl Engine {
    /// Returns None when the puzzle has no learning solver.
    pub fn create(puzzle_id: i32, seed: u64) -> Option<Engine> {
        let pz = puzzle_by_id(puzzle_id)?;
        if !pz.valid || !pz.ai_supported {
            return None;
        }
        let model = Model::new(pz);
        if !model.ok() {
            return None;
        }
        let model = Arc::new(model);
        let tests = Arc::new(TestSet::new(pz));
        let mut trainer = Trainer::new(model.clone(), tests.clone());
        trainer.reset(seed);
        let snap = Arc::new(trainer.params().clone());
        start_learning(puzzle_id);
        Some(Engine {
            puzzle: pz,
            model,
            tests,
            trainer: Mutex::new(trainer),
            snapshot: Mutex::new(snap),
            cancel: AtomicBool::new(false),
        })
    }

    pub fn puzzle(&self) -> &'static Puzzle {
        self.puzzle
    }

    fn publish(&self, t: &Trainer) {
        let copy = Arc::new(t.params().clone());
        *self.snapshot.lock().unwrap() = copy;
    }

    fn snapshot(&self) -> Arc<Vec<f32>> {
        self.snapshot.lock().unwrap().clone()
    }

    pub fn reset(&self, seed: u64) {
        let mut t = self.trainer.lock().unwrap();
        t.reset(seed);
        self.publish(&t);
    }

    pub fn configure(&self, cfg: TrainConfig) {
        self.trainer.lock().unwrap().set_config(cfg);
    }

    pub fn config(&self) -> TrainConfig {
        self.trainer.lock().unwrap().config()
    }

    pub fn train(&self, budget_ms: i32) -> TrainStats {
        let mut t = self.trainer.lock().unwrap();
        let s = t.run(budget_ms);
        self.publish(&t);
        s
    }

    pub fn stats(&self) -> TrainStats {
        self.trainer.lock().unwrap().stats()
    }

    pub fn set_cancel(&self, cancel: bool) {
        self.cancel.store(cancel, Ordering::SeqCst);
    }

    /// `state` is the puzzle as the player sees it (stickers colours).
    pub fn solve(&self, mode: i32, state: &[u8], cfg_in: &SearchConfig) -> SearchResult {
        let pz = self.puzzle;
        let mut res = SearchResult::default();
        let mut canon = [0u8; K_MAX_AI_STICKERS];
        let mut start: &[u8] = state;
        let mut rot: i32 = 0;
        if pz.needs_canon {
            rot = pz.canon_rotation(state);
            if rot < 0 {
                res.status = K_INVALID;
                return res;
            }
            pz.rotate(state, rot as usize, &mut canon);
            start = &canon[..pz.stickers];
        }

        let mut cfg = *cfg_in;
        let mut done = false;
        if mode == K_BASELINE_MODE {
            // Classic A* with an admissible heuristic: this is the conventional, non-learning reference.
            cfg.lambda = 1.0;
            let h = MisplacedHeuristic { model: &self.model };
            res = solve_weighted_astar(&self.model, start, &h, &cfg, &self.cancel);
            done = true;
        } else if let Some(method) = method_for(pz.id) {
            // Learned method: tables and algorithms the program discovered from the rules (see method.rs).
            let t0 = Instant::now();
            let mut b = Budget::new(cfg.timeout_ms, &self.cancel);
            match method.solve(pz, start, &mut b) {
                Ok(moves) => {
                    res.status = K_SOLVED;
                    res.expanded = b.nodes.min(i32::MAX as u64) as i32;
                    res.generated = res.expanded;
                    res.elapsed_ms = t0.elapsed().as_millis() as i32;
                    res.moves = moves;
                    done = true;
                }
                Err(code) if code == K_CANCELLED || code == K_TIMEOUT => {
                    res.status = code;
                    res.elapsed_ms = t0.elapsed().as_millis() as i32;
                    done = true;
                }
                Err(_) => {}
            }
        }
        if !done {
            let snap = self.snapshot();
            let h = NetHeuristic { model: &self.model, params: &snap[..] };
            res = solve_weighted_astar(&self.model, start, &h, &cfg, &self.cancel);
        }

        if pz.needs_canon && res.status == K_SOLVED {
            for m in res.moves.iter_mut() {
                *m = pz.conj[rot as usize][*m as usize] as u8;
            }
        }
        res
    }

    /// A step-by-step lesson for the state as the player sees it. Moves are mapped back to the player's puzzle.
    /// Only the 3x3 can teach; other puzzles return K_INVALID.
    pub fn teach(&self, state: &[u8], method: i32, timeout_ms: i32) -> Result<Vec<Step>, i32> {
        let pz = self.puzzle;
        let mut canon = [0u8; K_MAX_AI_STICKERS];
        let mut start: &[u8] = state;
        let mut rot: i32 = 0;
        if pz.needs_canon {
            rot = pz.canon_rotation(state);
            if rot < 0 {
                return Err(K_INVALID);
            }
            pz.rotate(state, rot as usize, &mut canon);
            start = &canon[..pz.stickers];
        }
        let mt = method_for(pz.id).ok_or(K_INVALID)?;
        let mut b = Budget::new(timeout_ms, &self.cancel);
        let mut steps = match mt.teach(pz, start, method, &mut b) {
            Some(r) => r?,
            None => return Err(K_INVALID),
        };
        if pz.needs_canon {
            for st in steps.iter_mut() {
                for m in st.moves.iter_mut() {
                    *m = pz.conj[rot as usize][*m as usize] as u8;
                }
            }
        }
        Ok(steps)
    }

    /// fresh_seed == 0: the fixed held-out test scrambles. Otherwise new random scrambles made from that seed.
    pub fn evaluate(&self, mode: i32, depth: i32, cases: i32, cfg: &SearchConfig, fresh_seed: u64) -> EvalResult {
        let mut result = EvalResult::default();
        let pz = self.puzzle;
        let d = depth.clamp(1, TestSet::MAX_DEPTH);
        let n = if fresh_seed == 0 { cases.clamp(1, TestSet::PER_DEPTH) } else { cases.clamp(1, 500) };
        let mut sum_len = 0.0f64;
        let mut sum_expanded = 0.0f64;
        let mut sum_ms = 0.0f64;
        let mut buf = [0u8; K_MAX_AI_STICKERS];
        for i in 0..n {
            if self.cancel.load(Ordering::SeqCst) {
                result.cancelled = true;
                break;
            }
            let r;
            if fresh_seed == 0 {
                r = self.solve(mode, self.tests.state(d, i), cfg);
            } else {
                let mut rng = Rng::new(
                    fresh_seed.wrapping_add(d as u64 * 1_000_003).wrapping_add(i as u64 * 7919),
                );
                for _ in 0..16 {
                    random_scramble(pz, &mut rng, d, &mut buf);
                    if !pz.is_solved(&buf) {
                        break;
                    }
                }
                r = self.solve(mode, &buf[..pz.stickers], cfg);
            }
            if r.status == K_CANCELLED {
                result.cancelled = true;
                break;
            }
            result.total += 1;
            if r.status == K_SOLVED {
                result.solved += 1;
                sum_len += r.moves.len() as f64;
                sum_expanded += r.expanded as f64;
                sum_ms += r.elapsed_ms as f64;
            }
        }
        if result.solved > 0 {
            result.avg_length = sum_len / result.solved as f64;
            result.avg_expanded = sum_expanded / result.solved as f64;
            result.avg_ms = sum_ms / result.solved as f64;
        }
        result
    }

    /// The network's guess of how many moves are left (-1 when the state is invalid).
    pub fn estimate(&self, state: &[u8]) -> f32 {
        let pz = self.puzzle;
        let mut canon = [0u8; K_MAX_AI_STICKERS];
        let mut s: &[u8] = state;
        if pz.needs_canon {
            let rot = pz.canon_rotation(state);
            if rot < 0 {
                return -1.0;
            }
            pz.rotate(state, rot as usize, &mut canon);
            s = &canon[..pz.stickers];
        }
        let mut probe = [0usize; 64];
        if self.model.enc.encode(s, &mut probe) < 0 {
            return -1.0;
        }
        let snap = self.snapshot();
        estimate_cost(&self.model, &snap[..], s)
    }

    pub fn save(&self, path: &str) -> bool {
        let t = self.trainer.lock().unwrap();
        let tmp = format!("{}.tmp", path);
        let mut f = match File::create(&tmp) {
            Ok(f) => f,
            Err(_) => return false,
        };
        let mut ok = t.save(&mut f);
        ok = f.sync_all().is_ok() && ok;
        drop(f);
        if !ok || std::fs::rename(&tmp, path).is_err() {
            let _ = std::fs::remove_file(&tmp);
            return false;
        }
        true
    }

    pub fn load(&self, path: &str) -> bool {
        let mut t = self.trainer.lock().unwrap();
        let mut f = match File::open(path) {
            Ok(f) => f,
            Err(_) => return false,
        };
        let ok = t.load(&mut f);
        if ok {
            self.publish(&t);
        }
        ok
    }
}
