//! RubikAILab native core, written in Rust. Exposes exactly the JNI surface of the former C++ library
//! (class com.rubikailab.app.core.NativeBridge, library name "rubikcore"), so the Kotlin app is unchanged.
//!
//! Result layouts (see NativeBridge.kt / Models.kt for the matching decoders):
//!   nativeTrain / nativeStats -> double[17]: steps, samples, iterations, depth, loss, mae, accuracy,
//!                                samplesPerSec, learningRate, phase, progress, epoch, threads, batch, pool,
//!                                maxDepth, chunkSteps
//!   nativeSolve    -> int[5 + n]: status, expanded, generated, elapsedMs, n, move_0 .. move_n-1
//!   nativeEvaluate -> double[6]: solved, total, avgLength, avgExpanded, avgMs, cancelled(0/1)
//!   nativePuzzleInfo -> int[13]: valid, stickers, colors, faces, moves, aiSupported, aiMoveCount, needsCanon,
//!                                defaultMaxDepth, bodyPieces, coreTriangles, hidden1, hidden2
//!   nativePuzzleStickers -> float[stickers * 20]: cornerCount, 12 corner coordinates, normal(3), centroid(3), colour
//!   nativePuzzleMoves    -> float[moves * 8]: axis(3), angleDeg, lo, hi, inverse, isSolverMove
//!   nativePuzzleStyle    -> float[4]: bounding radius, sticker inset, sticker lift, sticker corner radius
//!   nativePuzzleBodies   -> float[]: pieceCount, then per piece: classX, classY, classZ, triangleCount, 12 floats
//!                           (3 corners + outward normal) per triangle

#![allow(non_snake_case)]

mod encoder;
mod engine;
mod method;
mod net;
mod puzzle;
mod rng;
mod search;
mod trainer;

use jni::objects::{JByteArray, JObject, JString};
use jni::sys::{jboolean, jdoubleArray, jfloat, jfloatArray, jint, jintArray, jlong, jobjectArray, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use std::ptr;
use std::sync::atomic::AtomicBool;

use engine::Engine;
use puzzle::{puzzle_by_id, K_MAX_STICKERS, K_PUZZLE_COUNT};
use search::{SearchConfig, K_INVALID};
use trainer::TrainStats;

fn eng(handle: jlong) -> Option<&'static Engine> {
    if handle == 0 {
        None
    } else {
        // SAFETY: handles come from nativeCreate (Box::into_raw) and stay valid until nativeDestroy.
        Some(unsafe { &*(handle as *const Engine) })
    }
}

fn pack_ints(env: &mut JNIEnv, v: &[i32]) -> jintArray {
    match env.new_int_array(v.len() as i32) {
        Ok(a) => {
            if !v.is_empty() {
                let _ = env.set_int_array_region(&a, 0, v);
            }
            a.into_raw()
        }
        Err(_) => ptr::null_mut(),
    }
}

fn pack_floats(env: &mut JNIEnv, v: &[f32]) -> jfloatArray {
    match env.new_float_array(v.len() as i32) {
        Ok(a) => {
            if !v.is_empty() {
                let _ = env.set_float_array_region(&a, 0, v);
            }
            a.into_raw()
        }
        Err(_) => ptr::null_mut(),
    }
}

fn pack_doubles(env: &mut JNIEnv, v: &[f64]) -> jdoubleArray {
    match env.new_double_array(v.len() as i32) {
        Ok(a) => {
            if !v.is_empty() {
                let _ = env.set_double_array_region(&a, 0, v);
            }
            a.into_raw()
        }
        Err(_) => ptr::null_mut(),
    }
}

fn pack_stats(env: &mut JNIEnv, s: &TrainStats) -> jdoubleArray {
    let v = [
        s.steps as f64,
        s.samples as f64,
        s.iterations as f64,
        s.depth as f64,
        s.loss as f64,
        s.mae as f64,
        s.accuracy as f64,
        s.samples_per_sec as f64,
        s.lr as f64,
        s.phase as f64,
        s.progress as f64,
        s.epoch as f64,
        s.threads as f64,
        s.batch as f64,
        s.pool as f64,
        s.max_depth as f64,
        s.chunk_steps as f64,
    ];
    pack_doubles(env, &v)
}

/// Copies a Java byte[] holding exactly `expected` stickers; None if the size is wrong.
fn read_state(env: &mut JNIEnv, state: &JByteArray, expected: usize) -> Option<Vec<u8>> {
    if state.as_raw().is_null() || expected > K_MAX_STICKERS {
        return None;
    }
    let bytes = env.convert_byte_array(state).ok()?;
    if bytes.len() != expected {
        return None;
    }
    Some(bytes)
}

fn read_path(env: &mut JNIEnv, path: &JString) -> Option<String> {
    if path.as_raw().is_null() {
        return None;
    }
    let s = env.get_string(path).ok()?;
    Some(String::from(s))
}

// ------------------------------------------------------------------------------------------ puzzles

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleCount<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
) -> jint {
    K_PUZZLE_COUNT
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleInfo<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jintArray {
    let mut out = vec![0i32; 13];
    if let Some(p) = puzzle_by_id(id) {
        out[0] = p.valid as i32;
        out[1] = p.stickers as i32;
        out[2] = p.colors;
        out[3] = p.faces as i32;
        out[4] = p.moves as i32;
        out[5] = p.ai_supported as i32;
        out[6] = p.ai_moves.len() as i32;
        out[7] = p.needs_canon as i32;
        out[8] = p.default_max_depth;
        out[9] = p.bodies.len() as i32;
        out[10] = (p.core.len() / 12) as i32;
        out[11] = p.hidden1 as i32;
        out[12] = p.hidden2 as i32;
    }
    pack_ints(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStrings<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jobjectArray {
    let mut full = "?".to_string();
    let mut short = "?".to_string();
    let mut names = String::new();
    if let Some(p) = puzzle_by_id(id) {
        full = p.name.clone();
        short = p.short_name.clone();
        for (i, m) in p.mv.iter().enumerate() {
            if i > 0 {
                names.push(' ');
            }
            names.push_str(&m.name);
        }
    }
    let arr = match env.new_object_array(3, "java/lang/String", JObject::null()) {
        Ok(a) => a,
        Err(_) => return ptr::null_mut(),
    };
    for (i, text) in [full, short, names].iter().enumerate() {
        if let Ok(js) = env.new_string(text) {
            let _ = env.set_object_array_element(&arr, i as i32, &js);
        }
    }
    arr.into_raw()
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStyle<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jfloatArray {
    let mut out = vec![3.0f32, 0.03, 0.006, 0.1];
    if let Some(p) = puzzle_by_id(id) {
        out = vec![p.radius, p.sticker_inset, p.sticker_lift, p.sticker_round];
    }
    pack_floats(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStickers<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jfloatArray {
    let mut out: Vec<f32> = Vec::new();
    if let Some(p) = puzzle_by_id(id) {
        out.reserve(p.stickers * 20);
        for i in 0..p.stickers {
            out.push(p.vcount[i] as f32);
            for k in 0..12 {
                out.push(p.verts[i * 12 + k]);
            }
            for k in 0..3 {
                out.push(p.normal[i * 3 + k]);
            }
            for k in 0..3 {
                out.push(p.centroid[i * 3 + k]);
            }
            out.push(p.solved[i] as f32);
        }
    }
    pack_floats(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleFaces<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jintArray {
    let mut out: Vec<i32> = Vec::new();
    if let Some(p) = puzzle_by_id(id) {
        for i in 0..p.stickers {
            out.push(p.face_of[i] as i32);
        }
    }
    pack_ints(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleMoves<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jfloatArray {
    let mut out: Vec<f32> = Vec::new();
    if let Some(p) = puzzle_by_id(id) {
        for m in 0..p.moves {
            let mv = &p.mv[m];
            out.push(mv.axis[0]);
            out.push(mv.axis[1]);
            out.push(mv.axis[2]);
            out.push(mv.angle_deg);
            out.push(mv.lo);
            out.push(mv.hi);
            out.push(mv.inverse as f32);
            out.push(if p.ai_move(m) { 1.0 } else { 0.0 });
        }
    }
    pack_floats(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleMoveTable<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jintArray {
    let mut out: Vec<i32> = Vec::new();
    if let Some(p) = puzzle_by_id(id) {
        out.reserve(p.moves * p.stickers);
        for m in 0..p.moves {
            for i in 0..p.stickers {
                out.push(p.perm[m][i] as i32);
            }
        }
    }
    pack_ints(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleBodies<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jfloatArray {
    let mut out: Vec<f32> = Vec::new();
    if let Some(p) = puzzle_by_id(id) {
        out.push(p.bodies.len() as f32);
        for b in p.bodies.iter() {
            out.push(b.cls[0]);
            out.push(b.cls[1]);
            out.push(b.cls[2]);
            out.push((b.tris.len() / 12) as f32);
            out.extend_from_slice(&b.tris);
        }
    }
    pack_floats(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativePuzzleCore<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    id: jint,
) -> jfloatArray {
    let out: Vec<f32> = match puzzle_by_id(id) {
        Some(p) => p.core.clone(),
        None => Vec::new(),
    };
    pack_floats(&mut env, &out)
}

// ------------------------------------------------------------------------------------------ engines

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeCreate<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    puzzle_id: jint,
    seed: jlong,
) -> jlong {
    match Engine::create(puzzle_id, seed as u64) {
        Some(e) => Box::into_raw(Box::new(e)) as jlong,
        None => 0,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeDestroy<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
) {
    if handle != 0 {
        // SAFETY: the handle was produced by Box::into_raw in nativeCreate and is destroyed exactly once.
        unsafe { drop(Box::from_raw(handle as *mut Engine)) };
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeReset<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    seed: jlong,
) {
    if let Some(e) = eng(handle) {
        e.reset(seed as u64);
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeConfigure<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    batch: jint,
    learning_rate: jfloat,
    max_depth: jint,
    threads: jint,
    pool: jint,
    frontier_mix: jfloat,
) {
    if let Some(e) = eng(handle) {
        let mut cfg = e.config();
        cfg.batch = batch;
        cfg.lr = learning_rate;
        cfg.max_depth = max_depth;
        cfg.threads = threads;
        cfg.pool = pool;
        cfg.frontier_mix = frontier_mix;
        e.configure(cfg);
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeTrain<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    budget_ms: jint,
) -> jdoubleArray {
    match eng(handle) {
        Some(e) => {
            let s = e.train(budget_ms);
            pack_stats(&mut env, &s)
        }
        None => pack_stats(&mut env, &TrainStats::default()),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeStats<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
) -> jdoubleArray {
    match eng(handle) {
        Some(e) => {
            let s = e.stats();
            pack_stats(&mut env, &s)
        }
        None => pack_stats(&mut env, &TrainStats::default()),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeSolve<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    mode: jint,
    state: JByteArray<'l>,
    max_expansions: jint,
    lambda: jfloat,
    timeout_ms: jint,
) -> jintArray {
    let e = match eng(handle) {
        Some(e) => e,
        None => return pack_ints(&mut env, &[K_INVALID, 0, 0, 0, 0]),
    };
    let st = match read_state(&mut env, &state, e.puzzle().stickers) {
        Some(s) => s,
        None => return pack_ints(&mut env, &[K_INVALID, 0, 0, 0, 0]),
    };
    let mut cfg = SearchConfig::default();
    cfg.max_expansions = max_expansions;
    cfg.lambda = lambda;
    cfg.timeout_ms = timeout_ms;
    let r = e.solve(mode, &st, &cfg);
    let mut out: Vec<i32> = Vec::with_capacity(5 + r.moves.len());
    out.push(r.status);
    out.push(r.expanded);
    out.push(r.generated);
    out.push(r.elapsed_ms);
    out.push(r.moves.len() as i32);
    for &m in r.moves.iter() {
        out.push(m as i32);
    }
    pack_ints(&mut env, &out)
}

/// Step-by-step lesson for the 3x3: int[2 + ...] = status, stepCount, then per step: stage, maskA, maskB,
/// algorithmId (-1 when the step is a single piece), position of the algorithm inside its phase (1-based),
/// algorithms in that phase, moveCount, move_0 .. move_n-1.
#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeTeach<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    state: JByteArray<'l>,
    method: jint,
    timeout_ms: jint,
) -> jintArray {
    let e = match eng(handle) {
        Some(e) => e,
        None => return pack_ints(&mut env, &[K_INVALID, 0]),
    };
    let st = match read_state(&mut env, &state, e.puzzle().stickers) {
        Some(s) => s,
        None => return pack_ints(&mut env, &[K_INVALID, 0]),
    };
    match e.teach(&st, method, timeout_ms) {
        Err(code) => pack_ints(&mut env, &[code, 0]),
        Ok(steps) => {
            let mut out: Vec<i32> = vec![0, steps.len() as i32];
            let mut i = 0usize;
            while i < steps.len() {
                // Steps of one phase that are all algorithms are numbered "1 of n".
                let mut j = i + 1;
                if steps[i].alg >= 0 {
                    while j < steps.len() && steps[j].stage == steps[i].stage && steps[j].alg >= 0 {
                        j += 1;
                    }
                }
                let total = (j - i) as i32;
                for k in i..j {
                    let s = &steps[k];
                    out.push(s.stage);
                    out.push(s.mask_a as i32);
                    out.push(s.mask_b as i32);
                    out.push(s.alg);
                    out.push((k - i + 1) as i32);
                    out.push(total);
                    out.push(s.moves.len() as i32);
                    for &m in s.moves.iter() {
                        out.push(m as i32);
                    }
                }
                i = j;
            }
            pack_ints(&mut env, &out)
        }
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeEvaluate<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    mode: jint,
    depth: jint,
    cases: jint,
    max_expansions: jint,
    lambda: jfloat,
    timeout_ms: jint,
    fresh_seed: jlong,
) -> jdoubleArray {
    let e = match eng(handle) {
        Some(e) => e,
        None => return pack_doubles(&mut env, &[0.0; 6]),
    };
    let mut cfg = SearchConfig::default();
    cfg.max_expansions = max_expansions;
    cfg.lambda = lambda;
    cfg.timeout_ms = timeout_ms;
    let r = e.evaluate(mode, depth, cases, &cfg, fresh_seed as u64);
    let v = [
        r.solved as f64,
        r.total as f64,
        r.avg_length,
        r.avg_expanded,
        r.avg_ms,
        if r.cancelled { 1.0 } else { 0.0 },
    ];
    pack_doubles(&mut env, &v)
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeEstimate<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    state: JByteArray<'l>,
) -> jfloat {
    let e = match eng(handle) {
        Some(e) => e,
        None => return -1.0,
    };
    match read_state(&mut env, &state, e.puzzle().stickers) {
        Some(st) => e.estimate(&st),
        None => -1.0,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeSetCancel<'l>(
    _env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    cancel: jboolean,
) {
    if let Some(e) = eng(handle) {
        e.set_cancel(cancel == JNI_TRUE);
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeSave<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    path: JString<'l>,
) -> jboolean {
    let e = match eng(handle) {
        Some(e) => e,
        None => return JNI_FALSE,
    };
    match read_path(&mut env, &path) {
        Some(p) if e.save(&p) => JNI_TRUE,
        _ => JNI_FALSE,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rubikailab_app_core_NativeBridge_nativeLoad<'l>(
    mut env: JNIEnv<'l>,
    _this: JObject<'l>,
    handle: jlong,
    path: JString<'l>,
) -> jboolean {
    let e = match eng(handle) {
        Some(e) => e,
        None => return JNI_FALSE,
    };
    match read_path(&mut env, &path) {
        Some(p) if e.load(&p) => JNI_TRUE,
        _ => JNI_FALSE,
    }
}

#[allow(dead_code)]
fn _unused(_: &AtomicBool) {}

#[cfg(test)]
mod tests {
    use super::method::{method_for, Budget};
    use super::puzzle::puzzle_by_id;
    use super::rng::Rng;
    use std::sync::atomic::AtomicBool;

    #[test]
    fn every_puzzle_is_valid() {
        for id in 0..6 {
            let p = puzzle_by_id(id).unwrap();
            assert!(p.valid, "puzzle {} invalid", id);
            assert!(p.stickers > 0 && p.moves > 0);
        }
    }

    fn scramble_and_solve(id: i32, depth: usize) {
        let p = puzzle_by_id(id).unwrap();
        let m = method_for(id).expect("method");
        let mut rng = Rng::new(42 + id as u64);
        for _ in 0..20 {
            let mut s = vec![0u8; p.stickers];
            p.set_solved(&mut s);
            let mut t = vec![0u8; p.stickers];
            for _ in 0..depth {
                let mv = p.ai_moves[rng.below(p.ai_moves.len() as u32) as usize];
                p.apply(&s, &mut t, mv);
                s.copy_from_slice(&t);
            }
            let cancel = AtomicBool::new(false);
            let mut b = Budget::new(60_000, &cancel);
            let sol = m.solve(p, &s, &mut b).expect("solved");
            for &mv in sol.iter() {
                p.apply(&s, &mut t, mv as usize);
                s.copy_from_slice(&t);
            }
            assert!(p.is_solved(&s), "puzzle {} not solved", id);
        }
    }

    #[test]
    fn teach_plans_solve_the_cube() {
        let p = puzzle_by_id(1).unwrap();
        let m = method_for(1).expect("method");
        let mut rng = Rng::new(7);
        for method in [0, 1] {
            for _ in 0..8 {
                let mut s = vec![0u8; p.stickers];
                p.set_solved(&mut s);
                let mut t = vec![0u8; p.stickers];
                for _ in 0..60 {
                    let mv = p.ai_moves[rng.below(p.ai_moves.len() as u32) as usize];
                    p.apply(&s, &mut t, mv);
                    s.copy_from_slice(&t);
                }
                let cancel = AtomicBool::new(false);
                let mut b = Budget::new(60_000, &cancel);
                let steps = m.teach(p, &s, method, &mut b).expect("3x3 teaches").expect("plan");
                assert!(steps.iter().all(|st| !st.moves.is_empty()));
                for st in steps.iter() {
                    for &mv in st.moves.iter() {
                        p.apply(&s, &mut t, mv as usize);
                        s.copy_from_slice(&t);
                    }
                }
                assert!(p.is_solved(&s), "method {} did not solve", method);
            }
        }
    }

    #[test]
    fn method_solves_2x2() {
        scramble_and_solve(0, 40);
    }

    #[test]
    fn method_solves_3x3() {
        scramble_and_solve(1, 60);
    }

    #[test]
    fn method_solves_pyraminx() {
        scramble_and_solve(4, 40);
    }

    #[test]
    fn method_solves_skewb() {
        scramble_and_solve(5, 40);
    }
}
