package com.rubikailab.app.ui

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import com.rubikailab.app.core.TeachStep

/** One step of a lesson with its text and the puzzle states before and after it. */
class LessonStep(
    val title: String,
    val detail: String,
    val moves: IntArray,
    val start: ByteArray,
    val end: ByteArray
)

/** Words and notation for the lessons (3x3 colours: white, red, green, yellow, orange, blue). */
object Lesson {
    const val STAGE_CROSS_EDGE = 1
    const val STAGE_CORNER = 2
    const val STAGE_MIDDLE = 3
    const val STAGE_F2L = 4
    const val STAGE_YCROSS = 5
    const val STAGE_YFACE = 6
    const val STAGE_YCORNERS = 7
    const val STAGE_YEDGES = 8
    const val STAGE_OLL = 9
    const val STAGE_PLL = 10
    const val STAGE_CROSS_ALL = 11
    const val STAGE_SOLUTION = 12

    private val COLORS = arrayOf("white", "red", "green", "yellow", "orange", "blue")

    /** "white-green" for a colour mask. */
    private fun piece(mask: Int): String {
        val parts = ArrayList<String>()
        for (c in COLORS.indices) if ((mask shr c) and 1 != 0) parts.add(COLORS[c])
        return parts.joinToString("-")
    }

    /** The colours of a mask without white: "red and green". */
    private fun centres(mask: Int): String {
        val parts = ArrayList<String>()
        for (c in COLORS.indices) if (c != 0 && (mask shr c) and 1 != 0) parts.add(COLORS[c])
        return parts.joinToString(" and ")
    }

    fun title(s: TeachStep): String = when (s.stage) {
        STAGE_CROSS_EDGE -> "White cross: the " + piece(s.maskA) + " edge"
        STAGE_CROSS_ALL -> "White cross: all four edges"
        STAGE_CORNER -> "White corner: " + piece(s.maskA)
        STAGE_MIDDLE -> "Middle layer: the " + piece(s.maskA) + " edge"
        STAGE_F2L -> "First two layers: " + piece(s.maskA) + " corner and " + piece(s.maskB) + " edge"
        STAGE_YCROSS -> "Yellow cross" + algNote(s)
        STAGE_YFACE -> "Finish the yellow face" + algNote(s)
        STAGE_YCORNERS -> "Place the yellow corners" + algNote(s)
        STAGE_YEDGES -> "Place the yellow edges" + algNote(s)
        STAGE_OLL -> "OLL: finish the yellow face" + algNote(s)
        STAGE_PLL -> "PLL: put the last pieces in place" + algNote(s)
        else -> "AI solution"
    }

    private fun algNote(s: TeachStep): String = if (s.algTotal > 1) " (algorithm " + s.algPos + " of " + s.algTotal + ")" else ""

    fun detail(s: TeachStep): String = when (s.stage) {
        STAGE_CROSS_EDGE -> "Bring this edge to the white face, between the white and " + centres(s.maskA) +
            " centres, with its white sticker on the white face. Edges you already placed stay in place."
        STAGE_CROSS_ALL -> "The whole white cross in the fewest moves."
        STAGE_CORNER -> "Put this corner between the white, " + centres(s.maskA) +
            " centres, white sticker on the white face. The cross stays in place."
        STAGE_MIDDLE -> "Slide this edge into the slot between the " + centres(s.maskA) +
            " centres. The white layer stays in place."
        STAGE_F2L -> "Pair them up and insert them together into the slot between the white, " + centres(s.maskA) +
            " centres. Everything placed before stays in place."
        STAGE_YCROSS -> "Make the cross on the yellow face (the bottom). " + ALG
        STAGE_YFACE -> "Turn every sticker of the yellow face yellow. " + ALG
        STAGE_YCORNERS -> "Move the yellow corners to their own places. " + ALG
        STAGE_YEDGES -> "Move the last edges to their own places. " + ALG
        STAGE_OLL -> "Make the whole yellow face yellow. " + ALG
        STAGE_PLL -> "Move the last pieces to their own places. " + ALG
        else -> "Preview it, play it move by move, or let the AI play it."
    }

    private const val ALG = "The AI found this algorithm by searching: it only changes the last layer and restores everything else."

    fun methodName(method: Int): String = if (method == 0) "CFOP" else "Beginner method"

    /** One printed move: "R", "R'" or "R2" (two identical turns in a row). [count] is how many turns it stands for. */
    class Token(val text: String, val count: Int)

    fun tokens(names: Array<String>, moves: IntArray): List<Token> {
        val out = ArrayList<Token>()
        var i = 0
        while (i < moves.size) {
            val m = moves[i]
            if (i + 1 < moves.size && moves[i + 1] == m) {
                out.add(Token(names[m].removeSuffix("'") + "2", 2))
                i += 2
            } else {
                out.add(Token(names[m], 1))
                i += 1
            }
        }
        return out
    }

    /** The notation with the moves already played dimmed and the next one highlighted. */
    fun spannable(tokens: List<Token>, movesDone: Int): CharSequence {
        val sb = SpannableStringBuilder()
        var played = 0
        var marked = false
        for (t in tokens) {
            if (sb.isNotEmpty()) sb.append("  ")
            val from = sb.length
            sb.append(t.text)
            val to = sb.length
            val done = played + t.count <= movesDone
            if (done) {
                sb.setSpan(ForegroundColorSpan(Theme.MUTED), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else if (!marked) {
                marked = true
                sb.setSpan(ForegroundColorSpan(Theme.ACCENT), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            played += t.count
        }
        return sb
    }
}

/** The card above the buttons that guides a lesson: what to do, the algorithm, and the playback controls. */
class CoachPanel(context: Context) : LinearLayout(context) {
    var onBack: () -> Unit = {}
    var onPreview: () -> Unit = {}
    var onMove: () -> Unit = {}
    var onPlay: () -> Unit = {}
    var onClose: () -> Unit = {}
    var onSpeed: (Float) -> Unit = {}

    private val titleView = context.label("", 14f, Theme.TEXT, true)
    private val detailView = context.label("", 12.5f, Theme.MUTED, false)
    private val algView = TextView(context)
    private val backChip: TextView
    private val previewChip: TextView
    private val moveChip: TextView
    private val playChip: TextView
    private val speedChips = ArrayList<TextView>()
    private val speeds = floatArrayOf(0.35f, 1f, 2.5f)
    private var speedIndex = 1

    init {
        orientation = VERTICAL
        background = context.rounded(Theme.PANEL_HI, 14f)
        setPadding(context.dp(12), context.dp(10), context.dp(12), context.dp(10))

        val head = LinearLayout(context)
        head.orientation = HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(titleView, lp(0, WRAP, 1f))
        val close = context.chip("Close") { onClose() }
        head.addView(close, lp(WRAP, WRAP))
        addView(head, lp(MATCH, WRAP))

        detailView.setPadding(0, context.dp(4), 0, context.dp(6))
        addView(detailView, lp(MATCH, WRAP))

        algView.textSize = 17f
        algView.typeface = Typeface.MONOSPACE
        algView.setTextColor(Theme.TEXT)
        algView.setPadding(context.dp(10), context.dp(8), context.dp(10), context.dp(8))
        algView.background = context.rounded(Theme.SCRIM, 10f)
        addView(algView, lp(MATCH, WRAP))

        val row = LinearLayout(context)
        row.orientation = HORIZONTAL
        backChip = context.chip("Back") { onBack() }
        previewChip = context.chip("Preview") { onPreview() }
        moveChip = context.chip("Move") { onMove() }
        playChip = context.chip("Do step") { onPlay() }
        for (c in listOf(backChip, previewChip, moveChip, playChip)) {
            val p = lp(0, WRAP, 1f)
            p.setMargins(context.dp(2), 0, context.dp(2), 0)
            row.addView(c, p)
        }
        val rp = lp(MATCH, WRAP)
        rp.topMargin = context.dp(8)
        addView(row, rp)

        val speedRow = LinearLayout(context)
        speedRow.orientation = HORIZONTAL
        speedRow.gravity = Gravity.CENTER_VERTICAL
        speedRow.addView(context.muted("Speed"), lp(WRAP, WRAP))
        val names = arrayOf("Slow", "Normal", "Fast")
        for (i in names.indices) {
            val c = context.chip(names[i]) {
                speedIndex = i
                refreshSpeed()
                onSpeed(speeds[i])
            }
            val p = lp(0, WRAP, 1f)
            p.setMargins(context.dp(6), 0, 0, 0)
            speedRow.addView(c, p)
            speedChips.add(c)
        }
        val sp = lp(MATCH, WRAP)
        sp.topMargin = context.dp(6)
        addView(speedRow, sp)
        refreshSpeed()
    }

    val speed: Float get() = speeds[speedIndex]

    private fun refreshSpeed() {
        for (i in speedChips.indices) speedChips[i].background = context.chipBackground(i == speedIndex)
    }

    private fun setOn(v: TextView, on: Boolean) {
        v.isEnabled = on
        v.alpha = if (on) 1f else 0.4f
    }

    fun render(
        title: String,
        detail: String,
        notation: CharSequence,
        stepDone: Boolean,
        isLast: Boolean,
        canBack: Boolean,
        busy: Boolean
    ) {
        titleView.text = title
        detailView.text = detail
        algView.text = notation
        playChip.text = if (!stepDone) "Do step" else if (isLast) "Finish" else "Next step"
        setOn(backChip, canBack && !busy)
        setOn(previewChip, !busy)
        setOn(moveChip, !stepDone && !busy)
        setOn(playChip, !busy)
    }
}
