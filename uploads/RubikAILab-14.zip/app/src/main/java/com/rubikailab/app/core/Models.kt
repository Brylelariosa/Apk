package com.rubikailab.app.core

/** Solver selection understood by the native engine. */
object SolverMode {
    const val LEARNED = 0
    const val BASELINE = 1

    fun label(mode: Int): String = if (mode == BASELINE) "Baseline A*" else "Learned AI"
}

/** Snapshot of the trainer, decoded from the double[17] returned by nativeTrain / nativeStats. */
data class TrainStats(
    val steps: Long,
    val samples: Long,
    val iterations: Int,
    val depth: Int,
    val loss: Double,
    val mae: Double,
    val accuracy: Double,
    val samplesPerSec: Double,
    val learningRate: Double,
    val phase: Int,
    val progress: Double,
    val epoch: Int,
    val threads: Int,
    val batch: Int,
    val pool: Int,
    val maxDepth: Int,
    val chunkSteps: Int
) {
    companion object {
        val EMPTY = TrainStats(0L, 0L, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0, 1, 256, 4096, 12, 0)

        fun decode(a: DoubleArray?): TrainStats {
            if (a == null || a.size < 17) return EMPTY
            return TrainStats(
                a[0].toLong(), a[1].toLong(), a[2].toInt(), a[3].toInt(),
                a[4], a[5], a[6], a[7], a[8],
                a[9].toInt(), a[10], a[11].toInt(),
                a[12].toInt(), a[13].toInt(), a[14].toInt(), a[15].toInt(), a[16].toInt()
            )
        }
    }
}

object SolveStatus {
    const val SOLVED = 0
    const val NODE_LIMIT = 1
    const val TIMEOUT = 2
    const val CANCELLED = 3
    const val INVALID = 4

    fun label(status: Int): String = when (status) {
        SOLVED -> "Solved"
        NODE_LIMIT -> "Stopped: node limit reached"
        TIMEOUT -> "Stopped: time limit reached"
        CANCELLED -> "Cancelled"
        else -> "Not a valid puzzle state"
    }
}

/** Result of one search, decoded from the int[5 + n] returned by nativeSolve. */
class SolveResult(
    val status: Int,
    val expanded: Int,
    val generated: Int,
    val elapsedMs: Int,
    val moves: IntArray
) {
    val solved: Boolean get() = status == SolveStatus.SOLVED

    companion object {
        fun failed(status: Int): SolveResult = SolveResult(status, 0, 0, 0, IntArray(0))

        fun decode(a: IntArray?): SolveResult {
            if (a == null || a.size < 5) return failed(SolveStatus.INVALID)
            val n = maxOf(0, minOf(a[4], a.size - 5))
            return SolveResult(a[0], a[1], a[2], a[3], IntArray(n) { a[5 + it] })
        }
    }
}

/** One step of a lesson: what to place (colour masks) and the moves that do it. */
class TeachStep(
    val stage: Int,
    val maskA: Int,
    val maskB: Int,
    val alg: Int,
    val algPos: Int,
    val algTotal: Int,
    val moves: IntArray
)

/** Result of nativeTeach. */
class TeachResult(val status: Int, val steps: List<TeachStep>) {
    val ok: Boolean get() = status == SolveStatus.SOLVED

    companion object {
        fun failed(status: Int): TeachResult = TeachResult(status, emptyList())

        fun decode(a: IntArray?): TeachResult {
            if (a == null || a.size < 2) return failed(SolveStatus.INVALID)
            if (a[0] != SolveStatus.SOLVED) return failed(a[0])
            val out = ArrayList<TeachStep>()
            var at = 2
            val count = a[1]
            for (k in 0 until count) {
                if (at + 7 > a.size) return failed(SolveStatus.INVALID)
                val n = a[at + 6]
                if (n < 0 || at + 7 + n > a.size) return failed(SolveStatus.INVALID)
                out.add(TeachStep(a[at], a[at + 1], a[at + 2], a[at + 3], a[at + 4], a[at + 5], IntArray(n) { a[at + 7 + it] }))
                at += 7 + n
            }
            return TeachResult(SolveStatus.SOLVED, out)
        }
    }
}

/** Benchmark result, decoded from the double[6] returned by nativeEvaluate. */
data class EvalResult(
    val solved: Int,
    val total: Int,
    val avgLength: Double,
    val avgExpanded: Double,
    val avgMs: Double,
    val cancelled: Boolean
) {
    companion object {
        fun decode(a: DoubleArray?): EvalResult {
            if (a == null || a.size < 6) return EvalResult(0, 0, 0.0, 0.0, 0.0, true)
            return EvalResult(a[0].toInt(), a[1].toInt(), a[2], a[3], a[4], a[5] != 0.0)
        }
    }
}
