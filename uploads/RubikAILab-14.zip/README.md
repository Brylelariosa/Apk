# Rubik AI Lab

Android app (Kotlin views + OpenGL ES 2.0 + native Rust) with six twisty puzzles, a hand-play mode with
swipe controls, and an on-device AI that learns to solve them from nothing but sticker colours.

## Puzzles
| Puzzle | Play | AI |
|---|---|---|
| 2x2 Cube | yes | yes |
| 3x3 Cube (face and middle-layer turns) | yes | yes |
| 4x4 Cube, 5x5 Cube | yes | no (state space far too large for a phone) |
| Pyraminx (triangle, tips included) | yes | yes |
| Skewb (corner-turning cube) | yes | yes |

## Tabs
- **Play** - the puzzle fills the screen and nothing needs scrolling. Swipe a sticker to turn the layer it
  sits in (the layer moves the way your finger moves; on the Skewb a swipe, a tap or a press-and-hold on a
  corner piece turns just that piece, and a swipe on a middle piece twists half the puzzle - Settings > Skewb corners switches the corners back
  to real twists); turning makes a soft cube sound (Settings > Sound switches it off; Settings > Troubleshooting > Show touch info writes what each touch did at the top, for bug reports); drag the background, or switch on "Rotate view", to look around. Everything you tap is in one
  panel at the bottom: puzzle picker, timer and moves, turn pad / rotate view / settings buttons, then
  Scramble, Reset and "AI solve". Timer with personal bests.
- **Train** - watch the AI practise on fresh scrambles at the depth it is currently training on (it sees only
  colours, searches with its learned estimate, then the puzzle plays its solution), round progress, loss /
  accuracy / depth / speed chart, and the effort preset: Cool, Balanced or Fast. A thermal governor keeps the
  phone under the preset's temperature ceiling.
- **Test** - benchmark the AI or the conventional baseline on held-out scrambles (never used for training) or
  on brand-new random ones. Results are saved.

## Source layout
```
rust/                        native core (Rust, built with cargo-ndk by the CI, packaged from app/src/main/jniLibs)
  src/lib.rs                 JNI surface + unit tests
  src/puzzle.rs              generic puzzle model: geometry -> move tables, pieces, symmetries
  src/encoder.rs             state -> sparse "piece P in slot S with orientation O" features
  src/net.rs                 value network (sparse input -> h1 -> h2 -> 1)
  src/trainer.rs             approximate value iteration over pools of random states
  src/search.rs              weighted A* with learned or conventional heuristic
  src/method.rs              learned methods: CFOP and beginner lessons for the 3x3, exact tables for the small puzzles
  src/engine.rs              one engine per puzzle: trainer + held-out tests + search + lessons + checkpoints
app/src/main/java/com/rubikailab/app/
  core/                      Kotlin side of the puzzle model and JNI
  gl/                        renderer, camera, picking and swipe-to-move, cube turn sounds (TurnSound.kt)
  ui/                        Play, Train and Test pages, dialogs, small widgets
  Lab.kt, ThermalGovernor.kt, TrainingService.kt
tests/                       tests/preview/ (host renderer, see BUILD.md), tests/sound/ (turn sound synthesis)
```

See AI_DESIGN.md for how the AI learns and BUILD.md for building and testing.

## Teach me (3x3)
The Play page has a Teach button: pick CFOP or the beginner (layer by layer) method and the AI builds a lesson for
the current cube, step by step: white cross edge by edge, corners, middle layer or F2L pairs, then the last layer
with algorithms the AI discovered itself. Every step shows the algorithm; Preview plays it and rewinds, Move plays
one turn at a time, Do step plays the rest, and Slow/Normal/Fast set the speed. You can also turn the cube yourself:
the card notices when the step is done. AI solve uses the same card, so you can preview a solution before it runs.
