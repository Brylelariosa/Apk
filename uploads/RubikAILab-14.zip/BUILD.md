# Build and test

## Android (the owner's CI)
`./gradlew assembleDebug` (JDK 17, Gradle 8.6). minSdk 24, framework views only (no AndroidX). The native library
is Rust (`rust/`): the CI builds it with cargo-ndk into `app/src/main/jniLibs` before Gradle runs.

## Tests of the native core
`cd rust && cargo test --lib` runs on any computer with Rust (the CI does it too, non-blocking): every puzzle is
valid, and the learned methods solve scrambled 2x2, 3x3 (fast solve and both lessons), Pyraminx and Skewb.

## Rust core
The crate lives in `rust/`. The CI workflow finds `rust/Cargo.toml`, runs `cargo test --lib` (non-blocking) and builds
the library with cargo-ndk into `app/src/main/jniLibs`; Gradle only packages it. Local builds must do the same
(`cargo ndk -t arm64-v8a -o app/src/main/jniLibs build --release` inside `rust/`). The old C++ core was removed.
