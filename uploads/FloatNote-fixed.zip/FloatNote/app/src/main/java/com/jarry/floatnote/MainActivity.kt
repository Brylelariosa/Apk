package com.jarry.floatnote

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.view.marginBottom
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.jarry.floatnote.adapter.NotesAdapter
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityMainBinding
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.dpToPx
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: NoteRepository
    private lateinit var adapter: NotesAdapter
    private var currentQuery: String = ""

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)

        setSupportActionBar(binding.toolbar)
        applyInsets()

        adapter = NotesAdapter(
            onClick = { note -> openNote(note) },
            onLongClick = { note -> togglePin(note); true }
        )
        binding.recyclerNotes.layoutManager =
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        binding.recyclerNotes.adapter = adapter

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val note = adapter.currentList[viewHolder.bindingAdapterPosition]
                deleteNote(note)
            }
        }).attachToRecyclerView(binding.recyclerNotes)

        binding.fabAdd.setOnClickListener { createNewNote() }
    }

    private fun applyInsets() {
        binding.appBar.applyTopSystemBarPadding()
        val fabBaseMargin = binding.fabAdd.marginBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.recyclerNotes) { v, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            v.updatePadding(bottom = bottom + dpToPx(88f))
            (binding.fabAdd.layoutParams as CoordinatorLayout.LayoutParams).bottomMargin =
                fabBaseMargin + bottom
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        loadNotes()
    }

    private fun loadNotes() {
        lifecycleScope.launch {
            val notes = repository.getAll(currentQuery)
            adapter.submitList(notes)
            binding.emptyState.isVisible = notes.isEmpty()
        }
    }

    private fun createNewNote() {
        if (PrefsManager.isFloatingModeEnabled(this)) {
            openFloating(Note())
        } else {
            startActivity(Intent(this, NoteEditorActivity::class.java))
        }
    }

    private fun openNote(note: Note) {
        // Even with Floating Mode off, a note already popped out to a floating
        // window takes priority - it has its own live, possibly-unsaved copy
        // of the note, so opening a second editor here would let the two
        // silently race to save over each other. Bring the floating one
        // forward instead of duplicating it.
        if (PrefsManager.isFloatingModeEnabled(this) || FloatingNoteService.isNoteFloating(note.id)) {
            openFloating(note)
        } else {
            val intent = Intent(this, NoteEditorActivity::class.java)
                .putExtra(NoteEditorActivity.EXTRA_NOTE_ID, note.id)
            startActivity(intent)
        }
    }

    private fun openFloating(note: Note) {
        ensureNotificationPermission()
        if (!OverlayPermission.isGranted(this)) {
            OverlayPermission.request(this, binding.root)
            return
        }
        val intent = Intent(this, FloatingNoteService::class.java)
            .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
            .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
        ContextCompat.startForegroundService(this, intent)
        moveTaskToBack(true)
    }

    private fun togglePin(note: Note) {
        lifecycleScope.launch {
            repository.save(note.copy(isPinned = !note.isPinned))
            loadNotes()
        }
    }

    private fun deleteNote(note: Note) {
        lifecycleScope.launch {
            repository.delete(note.id)
            loadNotes()
            Snackbar.make(binding.root, "Note deleted", Snackbar.LENGTH_LONG)
                .setAction("Undo") {
                    lifecycleScope.launch {
                        repository.save(note.copy(id = 0L))
                        loadNotes()
                    }
                }.show()
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchItem = menu.findItem(R.id.action_search)
        (searchItem.actionView as SearchView).setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                currentQuery = newText.orEmpty()
                loadNotes()
                return true
            }
        })
        menu.findItem(R.id.action_floating_mode).isChecked = PrefsManager.isFloatingModeEnabled(this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_floating_mode) {
            val newState = !item.isChecked
            item.isChecked = newState
            PrefsManager.setFloatingModeEnabled(this, newState)
            return true
        }
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
