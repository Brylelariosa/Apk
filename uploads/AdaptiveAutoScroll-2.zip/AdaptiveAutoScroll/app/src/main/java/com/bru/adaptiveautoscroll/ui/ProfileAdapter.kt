package com.bru.adaptiveautoscroll.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bru.adaptiveautoscroll.R
import com.bru.adaptiveautoscroll.data.Profile

class ProfileAdapter(
    private val profiles: List<Profile>,
    private var activeId: String,
    private val onSelect: (Profile) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    fun setActiveId(id: String) {
        activeId = id
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val colorBar:  View       = view.findViewById(R.id.profile_color_bar)
        val tvName:    TextView   = view.findViewById(R.id.tv_profile_name)
        val tvDesc:    TextView   = view.findViewById(R.id.tv_profile_desc)
        val tvSpeed:   TextView   = view.findViewById(R.id.tv_profile_speed)
        val tvAdapt:   TextView   = view.findViewById(R.id.tv_profile_adaptive)
        val ivCheck:   ImageView  = view.findViewById(R.id.iv_profile_check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false))

    override fun getItemCount() = profiles.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val profile  = profiles[position]
        val isActive = profile.id == activeId

        val color = try { Color.parseColor(profile.colorHex) } catch (_: Exception) { Color.WHITE }

        holder.colorBar.backgroundTintList = ColorStateList.valueOf(color)
        holder.tvName.text = profile.name
        holder.tvDesc.text = profile.description
        holder.tvSpeed.text = "Base: ${profile.baseSpeed}"
        holder.tvAdapt.text = "Adaptive: ${if (profile.adaptiveEnabled) "ON" else "OFF"}"

        holder.ivCheck.visibility = if (isActive) View.VISIBLE else View.INVISIBLE
        holder.itemView.alpha = if (isActive) 1f else 0.75f

        val overlayColor = Color.argb(if (isActive) 30 else 0, Color.red(color), Color.green(color), Color.blue(color))
        holder.itemView.setBackgroundColor(overlayColor)

        holder.itemView.setOnClickListener { onSelect(profile) }
    }
}
