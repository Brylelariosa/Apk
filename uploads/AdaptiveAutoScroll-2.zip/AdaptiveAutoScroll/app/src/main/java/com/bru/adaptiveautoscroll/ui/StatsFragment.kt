package com.bru.adaptiveautoscroll.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.databinding.FragmentStatsBinding
import com.bru.adaptiveautoscroll.engine.ContentType
import java.util.concurrent.TimeUnit

class StatsFragment : Fragment() {

    private var _binding: FragmentStatsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentStatsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())
        loadStats()

        binding.btnResetStats.setOnClickListener {
            prefs.resetStats()
            loadStats()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun loadStats() {
        val totalMs   = prefs.totalScrollTimeMs
        val sessions  = prefs.totalSessions
        val counts    = prefs.contentTypeCounts

        // Format total time
        val hours   = TimeUnit.MILLISECONDS.toHours(totalMs)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(totalMs) % 60
        binding.tvTotalTime.text = when {
            hours > 0   -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else        -> "< 1m"
        }

        binding.tvSessions.text = sessions.toString()

        // Content breakdown
        val breakdown = binding.llContentBreakdown
        breakdown.removeAllViews()

        if (counts.isEmpty()) {
            binding.tvNoStats.visibility = View.VISIBLE
        } else {
            binding.tvNoStats.visibility = View.GONE
            val total = counts.values.sum().toFloat()

            // Sort by count descending
            counts.entries
                .sortedByDescending { it.value }
                .forEach { (typeName, count) ->
                    val ct = try { ContentType.valueOf(typeName) }
                        catch (_: Exception) { ContentType.UNKNOWN }
                    val pct = if (total > 0) count / total * 100 else 0f
                    breakdown.addView(makeStatRow(ct, count, pct))
                }
        }
    }

    private fun makeStatRow(ct: ContentType, count: Int, pct: Float): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 12)
        }

        val labelRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val tvLabel = TextView(ctx).apply {
            text = "${ct.emoji} ${ct.label}"
            textSize = 13f
            setTextColor(Color.parseColor("#CAC4D0"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvPct = TextView(ctx).apply {
            text = "%.1f%%".format(pct)
            textSize = 13f
            setTextColor(Color.parseColor("#6750A4"))
        }

        labelRow.addView(tvLabel)
        labelRow.addView(tvPct)

        // Progress bar
        val progressBg = View(ctx).apply {
            setBackgroundColor(Color.parseColor("#49454F"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 6
            ).apply { topMargin = 4 }
        }

        val progressFill = View(ctx).apply {
            setBackgroundColor(Color.parseColor("#6750A4"))
            layoutParams = LinearLayout.LayoutParams(
                0, 6
            )
        }

        val barContainer = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 0)
        }

        // We simulate the progress bar with two views
        val fillWeight = pct / 100f
        val fillParams = LinearLayout.LayoutParams(0, 6, fillWeight)
        val emptyParams = LinearLayout.LayoutParams(0, 6, 1f - fillWeight)
        val fillView = View(ctx).apply {
            setBackgroundColor(Color.parseColor("#6750A4"))
            layoutParams = fillParams
        }
        val emptyView = View(ctx).apply {
            setBackgroundColor(Color.parseColor("#49454F"))
            layoutParams = emptyParams
        }
        barContainer.addView(fillView)
        barContainer.addView(emptyView)

        row.addView(labelRow)
        row.addView(barContainer)

        return row
    }
}
