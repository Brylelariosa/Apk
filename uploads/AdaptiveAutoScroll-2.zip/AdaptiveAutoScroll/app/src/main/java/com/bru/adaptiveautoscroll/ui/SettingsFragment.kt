package com.bru.adaptiveautoscroll.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.Fragment
import com.bru.adaptiveautoscroll.R
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())
        setupAllRows()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupAllRows() {
        // Speed rows
        setupSlider(
            rowView   = binding.rowBaseSpeed,
            label     = "Base Speed",
            minVal    = 1f, maxVal = 15f,
            current   = prefs.baseSpeed,
            format    = "%.1f"
        ) { prefs.baseSpeed = it }

        setupSlider(
            rowView   = binding.rowMinSpeed,
            label     = "Minimum Speed",
            minVal    = 0.5f, maxVal = 5f,
            current   = prefs.minSpeed,
            format    = "%.1f"
        ) { prefs.minSpeed = it }

        setupSlider(
            rowView   = binding.rowMaxSpeed,
            label     = "Maximum Speed",
            minVal    = 5f, maxVal = 30f,
            current   = prefs.maxSpeed,
            format    = "%.1f"
        ) { prefs.maxSpeed = it }

        setupSlider(
            rowView   = binding.rowAcceleration,
            label     = "Acceleration Rate",
            minVal    = 0.1f, maxVal = 2f,
            current   = prefs.acceleration,
            format    = "%.2f"
        ) { prefs.acceleration = it }

        setupSlider(
            rowView   = binding.rowDeceleration,
            label     = "Deceleration Rate",
            minVal    = 0.1f, maxVal = 2f,
            current   = prefs.deceleration,
            format    = "%.2f"
        ) { prefs.deceleration = it }

        // Adaptive rows
        setupToggle(
            rowView = binding.rowAdaptiveEnabled,
            label   = "Enable Adaptive Speed",
            current = prefs.adaptiveEnabled
        ) { prefs.adaptiveEnabled = it }

        setupSlider(
            rowView   = binding.rowTextSlowdown,
            label     = "Text Slowdown Factor",
            minVal    = 0.1f, maxVal = 1f,
            current   = prefs.textSlowdownFactor,
            format    = "%.2f"
        ) { prefs.textSlowdownFactor = it }

        setupSlider(
            rowView   = binding.rowImageSpeedup,
            label     = "Image Speed Multiplier",
            minVal    = 1f, maxVal = 4f,
            current   = prefs.imageSpeedupFactor,
            format    = "%.2f"
        ) { prefs.imageSpeedupFactor = it }

        setupSlider(
            rowView   = binding.rowBlankSpeedup,
            label     = "Blank Space Multiplier",
            minVal    = 1f, maxVal = 5f,
            current   = prefs.blankSpeedupFactor,
            format    = "%.2f"
        ) { prefs.blankSpeedupFactor = it }

        // Pause rows
        setupToggle(
            rowView = binding.rowPauseLongText,
            label   = "Pause on Long Text",
            current = prefs.pauseOnLongText
        ) { prefs.pauseOnLongText = it }

        setupToggle(
            rowView = binding.rowPauseChapterEnd,
            label   = "Pause at Chapter End",
            current = prefs.pauseAtChapterEnd
        ) { prefs.pauseAtChapterEnd = it }

        setupToggle(
            rowView = binding.rowPauseVideos,
            label   = "Pause on Videos",
            current = prefs.pauseOnVideos
        ) { prefs.pauseOnVideos = it }

        setupSlider(
            rowView   = binding.rowPauseDuration,
            label     = "Auto-Pause Duration",
            minVal    = 500f, maxVal = 15000f,
            current   = prefs.pauseDurationMs.toFloat(),
            format    = "%.0fms"
        ) { prefs.pauseDurationMs = it.toLong() }

        setupSlider(
            rowView   = binding.rowLongTextThreshold,
            label     = "Long Text Threshold (chars)",
            minVal    = 100f, maxVal = 2000f,
            current   = prefs.longTextThreshold.toFloat(),
            format    = "%.0f"
        ) { prefs.longTextThreshold = it.toInt() }

        // Interaction rows
        setupToggle(
            rowView = binding.rowTouchPause,
            label   = "Pause on Touch",
            current = prefs.touchPauseEnabled
        ) { prefs.touchPauseEnabled = it }

        setupSlider(
            rowView   = binding.rowTouchResumeDelay,
            label     = "Touch Resume Delay",
            minVal    = 500f, maxVal = 10000f,
            current   = prefs.touchResumeDelayMs.toFloat(),
            format    = "%.0fms"
        ) { prefs.touchResumeDelayMs = it.toLong() }

        setupToggle(
            rowView = binding.rowVolumeKeys,
            label   = "Volume Key Controls",
            current = prefs.volumeKeysEnabled
        ) { prefs.volumeKeysEnabled = it }
    }

    private fun setupSlider(
        rowView: View, label: String,
        minVal: Float, maxVal: Float,
        current: Float, format: String,
        onChanged: (Float) -> Unit
    ) {
        val tvLabel  = rowView.findViewById<TextView>(R.id.setting_label)
        val tvValue  = rowView.findViewById<TextView>(R.id.setting_value)
        val seekbar  = rowView.findViewById<SeekBar>(R.id.setting_seekbar)

        tvLabel.text = label

        val range    = maxVal - minVal
        val progress = ((current - minVal) / range * 100).toInt().coerceIn(0, 100)
        seekbar.progress = progress
        tvValue.text = format.format(current)

        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val value = minVal + range * p / 100f
                tvValue.text = format.format(value)
                if (fromUser) onChanged(value)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun setupToggle(
        rowView: View, label: String,
        current: Boolean, onChanged: (Boolean) -> Unit
    ) {
        val tvLabel  = rowView.findViewById<TextView>(R.id.setting_label)
        val switch   = rowView.findViewById<SwitchCompat>(R.id.setting_switch)
        tvLabel.text = label
        switch.isChecked = current
        switch.setOnCheckedChangeListener { _, checked -> onChanged(checked) }
    }
}
