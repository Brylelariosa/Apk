package com.bru.adaptiveautoscroll.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.data.ProfileManager
import com.bru.adaptiveautoscroll.databinding.FragmentProfilesBinding
import com.bru.adaptiveautoscroll.service.AdaptiveScrollService
import com.bru.adaptiveautoscroll.ui.ProfileAdapter

class ProfilesFragment : Fragment() {

    private var _binding: FragmentProfilesBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager
    private lateinit var adapter: ProfileAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentProfilesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        adapter = ProfileAdapter(ProfileManager.ALL, prefs.activeProfileId) { profile ->
            prefs.saveFromProfile(profile)
            adapter.setActiveId(profile.id)

            // Notify running service
            requireContext().sendBroadcast(
                Intent(AdaptiveScrollService.ACTION_SET_PROFILE).apply {
                    putExtra(AdaptiveScrollService.EXTRA_PROFILE, profile.id)
                }
            )
        }

        binding.rvProfiles.layoutManager = LinearLayoutManager(requireContext())
        binding.rvProfiles.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
