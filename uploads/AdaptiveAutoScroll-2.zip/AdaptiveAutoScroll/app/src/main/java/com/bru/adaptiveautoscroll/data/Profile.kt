package com.bru.adaptiveautoscroll.data

data class Profile(
    val id: String,
    val name: String,
    val description: String,
    val colorHex: String,
    val baseSpeed: Float,
    val minSpeed: Float,
    val maxSpeed: Float,
    val adaptiveEnabled: Boolean,
    val textSlowdownFactor: Float,
    val imageSpeedupFactor: Float,
    val blankSpeedupFactor: Float,
    val pauseAtChapterEnd: Boolean,
    val pauseOnLongText: Boolean,
    val pauseOnVideos: Boolean,
    val pauseDurationMs: Long,
    val longTextThreshold: Int,
    val isBuiltIn: Boolean = true
)
