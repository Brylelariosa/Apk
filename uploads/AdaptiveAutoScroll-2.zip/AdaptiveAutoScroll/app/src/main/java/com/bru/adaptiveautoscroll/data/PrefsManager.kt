package com.bru.adaptiveautoscroll.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("adaptive_scroll_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    // Active profile
    var activeProfileId: String
        get() = prefs.getString("profile_id", "article") ?: "article"
        set(v) = prefs.edit().putString("profile_id", v).apply()

    // Speed
    var baseSpeed: Float
        get() = prefs.getFloat("base_speed", 5f)
        set(v) = prefs.edit().putFloat("base_speed", v).apply()

    var minSpeed: Float
        get() = prefs.getFloat("min_speed", 1f)
        set(v) = prefs.edit().putFloat("min_speed", v).apply()

    var maxSpeed: Float
        get() = prefs.getFloat("max_speed", 15f)
        set(v) = prefs.edit().putFloat("max_speed", v).apply()

    var acceleration: Float
        get() = prefs.getFloat("acceleration", 0.5f)
        set(v) = prefs.edit().putFloat("acceleration", v).apply()

    var deceleration: Float
        get() = prefs.getFloat("deceleration", 0.8f)
        set(v) = prefs.edit().putFloat("deceleration", v).apply()

    // Adaptive
    var adaptiveEnabled: Boolean
        get() = prefs.getBoolean("adaptive_enabled", true)
        set(v) = prefs.edit().putBoolean("adaptive_enabled", v).apply()

    var textSlowdownFactor: Float
        get() = prefs.getFloat("text_slowdown", 0.55f)
        set(v) = prefs.edit().putFloat("text_slowdown", v).apply()

    var imageSpeedupFactor: Float
        get() = prefs.getFloat("image_speedup", 1.5f)
        set(v) = prefs.edit().putFloat("image_speedup", v).apply()

    var blankSpeedupFactor: Float
        get() = prefs.getFloat("blank_speedup", 2.0f)
        set(v) = prefs.edit().putFloat("blank_speedup", v).apply()

    // Pause
    var pauseAtChapterEnd: Boolean
        get() = prefs.getBoolean("pause_chapter_end", true)
        set(v) = prefs.edit().putBoolean("pause_chapter_end", v).apply()

    var pauseOnLongText: Boolean
        get() = prefs.getBoolean("pause_long_text", true)
        set(v) = prefs.edit().putBoolean("pause_long_text", v).apply()

    var pauseOnVideos: Boolean
        get() = prefs.getBoolean("pause_videos", true)
        set(v) = prefs.edit().putBoolean("pause_videos", v).apply()

    var pauseDurationMs: Long
        get() = prefs.getLong("pause_duration_ms", 4000L)
        set(v) = prefs.edit().putLong("pause_duration_ms", v).apply()

    var longTextThreshold: Int
        get() = prefs.getInt("long_text_threshold", 600)
        set(v) = prefs.edit().putInt("long_text_threshold", v).apply()

    // Interaction
    var touchPauseEnabled: Boolean
        get() = prefs.getBoolean("touch_pause", true)
        set(v) = prefs.edit().putBoolean("touch_pause", v).apply()

    var touchResumeDelayMs: Long
        get() = prefs.getLong("touch_resume_delay", 2000L)
        set(v) = prefs.edit().putLong("touch_resume_delay", v).apply()

    var volumeKeysEnabled: Boolean
        get() = prefs.getBoolean("volume_keys", true)
        set(v) = prefs.edit().putBoolean("volume_keys", v).apply()

    // Stats
    var totalScrollTimeMs: Long
        get() = prefs.getLong("total_scroll_time", 0L)
        set(v) = prefs.edit().putLong("total_scroll_time", v).apply()

    var totalSessions: Int
        get() = prefs.getInt("total_sessions", 0)
        set(v) = prefs.edit().putInt("total_sessions", v).apply()

    var contentTypeCounts: Map<String, Int>
        get() {
            val json = prefs.getString("content_counts", null) ?: return emptyMap()
            return try {
                val type = object : TypeToken<Map<String, Int>>() {}.type
                gson.fromJson(json, type)
            } catch (e: Exception) { emptyMap() }
        }
        set(v) = prefs.edit().putString("content_counts", gson.toJson(v)).apply()

    // Per-site speed overrides
    var siteSpeedOverrides: Map<String, Float>
        get() {
            val json = prefs.getString("site_speeds", null) ?: return emptyMap()
            return try {
                val type = object : TypeToken<Map<String, Float>>() {}.type
                gson.fromJson(json, type)
            } catch (e: Exception) { emptyMap() }
        }
        set(v) = prefs.edit().putString("site_speeds", gson.toJson(v)).apply()

    fun saveFromProfile(profile: Profile) {
        activeProfileId = profile.id
        baseSpeed = profile.baseSpeed
        minSpeed = profile.minSpeed
        maxSpeed = profile.maxSpeed
        adaptiveEnabled = profile.adaptiveEnabled
        textSlowdownFactor = profile.textSlowdownFactor
        imageSpeedupFactor = profile.imageSpeedupFactor
        blankSpeedupFactor = profile.blankSpeedupFactor
        pauseAtChapterEnd = profile.pauseAtChapterEnd
        pauseOnLongText = profile.pauseOnLongText
        pauseOnVideos = profile.pauseOnVideos
        pauseDurationMs = profile.pauseDurationMs
        longTextThreshold = profile.longTextThreshold
    }

    fun incrementContentType(type: String) {
        val counts = contentTypeCounts.toMutableMap()
        counts[type] = (counts[type] ?: 0) + 1
        contentTypeCounts = counts
    }

    fun resetStats() {
        totalScrollTimeMs = 0L
        totalSessions = 0
        contentTypeCounts = emptyMap()
    }

    fun getSiteSpeed(host: String): Float? = siteSpeedOverrides[host]

    fun setSiteSpeed(host: String, speed: Float) {
        val map = siteSpeedOverrides.toMutableMap()
        map[host] = speed
        siteSpeedOverrides = map
    }
}
