package com.bru.adaptiveautoscroll.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bru.adaptiveautoscroll.MainActivity
import com.bru.adaptiveautoscroll.R
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.databinding.FragmentHomeBinding
import com.bru.adaptiveautoscroll.engine.ContentType
import com.bru.adaptiveautoscroll.service.AdaptiveScrollService

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager

    private var isScrolling = false
    private var isPaused    = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != AdaptiveScrollService.ACTION_STATUS_UPDATE) return
            isScrolling  = intent.getBooleanExtra(AdaptiveScrollService.EXTRA_IS_SCROLLING, false)
            isPaused     = intent.getBooleanExtra(AdaptiveScrollService.EXTRA_IS_PAUSED, false)
            val speed    = intent.getFloatExtra(AdaptiveScrollService.EXTRA_CURRENT_SPEED, 5f)
            val ctName   = intent.getStringExtra(AdaptiveScrollService.EXTRA_CONTENT_TYPE)
                ?: ContentType.UNKNOWN.name
            val progress = intent.getIntExtra(AdaptiveScrollService.EXTRA_SLIDER_PROGRESS, 50)
            val ct = try { ContentType.valueOf(ctName) } catch (_: Exception) { ContentType.UNKNOWN }
            updateScrollUI(speed, ct, progress)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())
        setupButtons()
        setupSpeedSeekbar()
        refreshServiceStatus()
    }

    override fun onResume() {
        super.onResume()
        requireContext().registerReceiver(
            statusReceiver,
            IntentFilter(AdaptiveScrollService.ACTION_STATUS_UPDATE)
        )
        refreshServiceStatus()
        // Sync scrolling state from service
        val svc = AdaptiveScrollService.instance
        if (svc != null) {
            isScrolling = svc.isScrolling
            isPaused    = svc.isPaused
            svc.broadcastStatus()
        }
    }

    override fun onPause() {
        super.onPause()
        try { requireContext().unregisterReceiver(statusReceiver) } catch (_: Exception) {}
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun refreshServiceStatus() {
        val act = activity as? MainActivity ?: return
        val b   = _binding ?: return

        val accessOk = act.isAccessibilityEnabled()
        val overlayOk = act.hasOverlayPermission()

        if (accessOk && overlayOk) {
            b.cardPermissions.visibility = View.GONE
            b.tvPermissionsOk.visibility = View.VISIBLE
        } else {
            b.cardPermissions.visibility = View.VISIBLE
            b.tvPermissionsOk.visibility = View.GONE
        }

        b.tvServiceStatus.apply {
            if (AdaptiveScrollService.isRunning()) {
                text = getString(R.string.service_active)
                setTextColor(0xFF4CAF50.toInt())
            } else {
                text = getString(R.string.service_inactive)
                setTextColor(0xFFF2B8B5.toInt())
            }
        }

        b.cardControl.alpha = if (accessOk && overlayOk) 1f else 0.5f
        b.btnStartStop.isEnabled = accessOk && overlayOk
    }

    private fun setupButtons() {
        binding.btnAccessibility.setOnClickListener {
            (activity as? MainActivity)?.openAccessibilitySettings()
        }
        binding.btnOverlay.setOnClickListener {
            (activity as? MainActivity)?.requestOverlayPermission()
        }
        binding.btnStartStop.setOnClickListener {
            if (isScrolling) stopScrolling() else startScrolling()
        }
        binding.btnPauseResume.setOnClickListener {
            if (isPaused) sendAction(AdaptiveScrollService.ACTION_RESUME)
            else          sendAction(AdaptiveScrollService.ACTION_PAUSE)
        }

        // Profile quick buttons
        binding.btnProfileManga.setOnClickListener   { applyProfile("manga") }
        binding.btnProfileWebtoon.setOnClickListener { applyProfile("webtoon") }
        binding.btnProfileNovel.setOnClickListener   { applyProfile("novel") }
        binding.btnProfileArticle.setOnClickListener { applyProfile("article") }

        highlightActiveProfile(prefs.activeProfileId)
    }

    private fun setupSpeedSeekbar() {
        binding.seekbarSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val speed = 1f + 14f * progress / 100f
                binding.tvSpeedValue.text = "%.1f".format(speed)
                sendAction(AdaptiveScrollService.ACTION_SET_SPEED, progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun startScrolling() {
        sendAction(AdaptiveScrollService.ACTION_START)
        isScrolling = true
        isPaused    = false
        updateScrollButtons()
    }

    private fun stopScrolling() {
        sendAction(AdaptiveScrollService.ACTION_STOP)
        isScrolling = false
        isPaused    = false
        updateScrollButtons()
    }

    private fun applyProfile(id: String) {
        prefs.activeProfileId = id
        sendAction(AdaptiveScrollService.ACTION_SET_PROFILE, profileId = id)
        highlightActiveProfile(id)
    }

    private fun highlightActiveProfile(id: String) {
        val b = _binding ?: return
        val alpha = 0.4f
        b.btnProfileManga.alpha   = if (id == "manga")   1f else alpha
        b.btnProfileWebtoon.alpha = if (id == "webtoon") 1f else alpha
        b.btnProfileNovel.alpha   = if (id == "novel")   1f else alpha
        b.btnProfileArticle.alpha = if (id == "article") 1f else alpha
    }

    private fun updateScrollUI(speed: Float, ct: ContentType, sliderProgress: Int) {
        val b = _binding ?: return
        b.tvSpeedValue.text = "%.1f".format(speed)
        b.tvContentType.text = "${ct.emoji} ${ct.label}"
        b.seekbarSpeed.progress = sliderProgress
        updateScrollButtons()
    }

    private fun updateScrollButtons() {
        val b = _binding ?: return
        b.btnStartStop.text = if (isScrolling)
            getString(R.string.stop_scrolling) else getString(R.string.start_scrolling)
        b.btnStartStop.backgroundTintList = if (isScrolling)
            android.content.res.ColorStateList.valueOf(0xFFF2B8B5.toInt())
            else android.content.res.ColorStateList.valueOf(0xFF6750A4.toInt())
        b.btnPauseResume.isEnabled = isScrolling
        b.btnPauseResume.text = if (isPaused)
            getString(R.string.resume_scrolling) else getString(R.string.pause_scrolling)
        b.tvScrollStatus.text = when {
            isScrolling && isPaused -> getString(R.string.scrolling_paused)
            isScrolling             -> getString(R.string.scrolling_active)
            else                    -> getString(R.string.scrolling_stopped)
        }
        b.tvScrollStatus.setTextColor(when {
            isScrolling && isPaused -> 0xFFFFC107.toInt()
            isScrolling             -> 0xFF4CAF50.toInt()
            else                    -> 0xFFCAC4D0.toInt()
        })
    }

    private fun sendAction(action: String, speedProgress: Int = -1, profileId: String? = null) {
        val intent = Intent(action)
        if (speedProgress >= 0) intent.putExtra(AdaptiveScrollService.EXTRA_SPEED_PROGRESS, speedProgress)
        if (profileId != null)  intent.putExtra(AdaptiveScrollService.EXTRA_PROFILE, profileId)
        requireContext().sendBroadcast(intent)
    }
}
