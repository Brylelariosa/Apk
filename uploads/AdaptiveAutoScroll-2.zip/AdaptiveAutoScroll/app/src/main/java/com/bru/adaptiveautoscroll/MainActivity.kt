package com.bru.adaptiveautoscroll

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bru.adaptiveautoscroll.databinding.ActivityMainBinding
import com.bru.adaptiveautoscroll.service.AdaptiveScrollService
import com.bru.adaptiveautoscroll.ui.HomeFragment
import com.bru.adaptiveautoscroll.ui.ProfilesFragment
import com.bru.adaptiveautoscroll.ui.SettingsFragment
import com.bru.adaptiveautoscroll.ui.StatsFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val serviceConnReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            // Notify home fragment service is ready
            supportFragmentManager.fragments
                .filterIsInstance<HomeFragment>()
                .firstOrNull()?.refreshServiceStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        registerReceiver(serviceConnReceiver,
            IntentFilter(AdaptiveScrollService.ACTION_SERVICE_CONN))

        setupBottomNav()
        if (savedInstanceState == null) {
            showFragment(HomeFragment())
        }
    }

    override fun onResume() {
        super.onResume()
        supportFragmentManager.fragments
            .filterIsInstance<HomeFragment>()
            .firstOrNull()?.refreshServiceStatus()
    }

    override fun onDestroy() {
        try { unregisterReceiver(serviceConnReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home      -> { showFragment(HomeFragment()); true }
                R.id.nav_settings  -> { showFragment(SettingsFragment()); true }
                R.id.nav_profiles  -> { showFragment(ProfilesFragment()); true }
                R.id.nav_stats     -> { showFragment(StatsFragment()); true }
                else -> false
            }
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
        }
    }

    fun hasOverlayPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this)
        else true

    fun isAccessibilityEnabled(): Boolean {
        val service = "$packageName/${AdaptiveScrollService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(service)
    }
}
