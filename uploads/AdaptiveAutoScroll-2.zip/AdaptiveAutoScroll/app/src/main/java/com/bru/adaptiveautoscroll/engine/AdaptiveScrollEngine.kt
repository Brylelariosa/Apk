package com.bru.adaptiveautoscroll.engine

import com.bru.adaptiveautoscroll.data.PrefsManager
import kotlin.math.abs
import kotlin.math.roundToInt

class AdaptiveScrollEngine(private val prefs: PrefsManager) {

    companion object {
        const val SCROLL_INTERVAL_MS = 100L
        const val GESTURE_DURATION_MS = 80L
        const val PIXELS_PER_SPEED_UNIT = 3f // px per 100ms per speed unit
    }

    var currentSpeed: Float = prefs.baseSpeed
        private set

    var targetSpeed: Float = prefs.baseSpeed
        private set

    var currentContentType: ContentType = ContentType.UNKNOWN
        private set

    // Manual override
    var manualSpeed: Float = prefs.baseSpeed
    var useManualSpeed: Boolean = false

    // Pause state for auto-pausing
    var autoPauseTriggered: Boolean = false
    var autoPauseEndTime: Long = 0L

    fun setProfile(profileId: String) {
        val profile = com.bru.adaptiveautoscroll.data.ProfileManager.getById(profileId)
        prefs.saveFromProfile(profile)
        manualSpeed = profile.baseSpeed
        currentSpeed = profile.baseSpeed
        targetSpeed = profile.baseSpeed
    }

    fun updateContentType(type: ContentType) {
        if (type == currentContentType) return
        currentContentType = type
        recalculateTargetSpeed()
    }

    fun getScrollPixels(): Int {
        if (!prefs.adaptiveEnabled) {
            val spd = if (useManualSpeed) manualSpeed else prefs.baseSpeed
            return (spd * PIXELS_PER_SPEED_UNIT).roundToInt().coerceAtLeast(1)
        }

        // Smooth speed towards target
        val diff = targetSpeed - currentSpeed
        if (abs(diff) > 0.1f) {
            val step = if (diff > 0) prefs.acceleration else -prefs.deceleration
            currentSpeed = (currentSpeed + step).coerceIn(prefs.minSpeed, prefs.maxSpeed)
        } else {
            currentSpeed = targetSpeed
        }

        return (currentSpeed * PIXELS_PER_SPEED_UNIT).roundToInt().coerceAtLeast(1)
    }

    fun getScrollInterval(): Long = SCROLL_INTERVAL_MS

    fun getGestureDuration(): Long = GESTURE_DURATION_MS

    fun adjustSpeed(delta: Float) {
        manualSpeed = (manualSpeed + delta).coerceIn(prefs.minSpeed, prefs.maxSpeed)
        useManualSpeed = true
        targetSpeed = manualSpeed
    }

    fun setSpeedFromSlider(progress: Int) {
        // progress 0-100 maps to minSpeed - maxSpeed
        val speed = prefs.minSpeed + (prefs.maxSpeed - prefs.minSpeed) * (progress / 100f)
        manualSpeed = speed
        useManualSpeed = true
        targetSpeed = speed
        currentSpeed = speed
    }

    fun getSliderProgress(): Int {
        val range = prefs.maxSpeed - prefs.minSpeed
        if (range <= 0) return 50
        return ((currentSpeed - prefs.minSpeed) / range * 100).roundToInt().coerceIn(0, 100)
    }

    fun shouldAutoPause(): Boolean {
        if (!prefs.adaptiveEnabled) return false
        return when (currentContentType) {
            ContentType.CHAPTER_END -> prefs.pauseAtChapterEnd
            ContentType.DENSE_TEXT -> prefs.pauseOnLongText
            ContentType.VIDEO -> prefs.pauseOnVideos
            else -> false
        }
    }

    fun getAutoPauseDuration(): Long = prefs.pauseDurationMs

    private fun recalculateTargetSpeed() {
        val base = if (useManualSpeed) manualSpeed else prefs.baseSpeed

        targetSpeed = when (currentContentType) {
            ContentType.MANGA_IMAGE   -> (base * prefs.imageSpeedupFactor)
            ContentType.WEBTOON_IMAGE -> (base * (prefs.imageSpeedupFactor * 0.8f))
            ContentType.DENSE_TEXT    -> (base * prefs.textSlowdownFactor)
            ContentType.DIALOGUE      -> (base * (prefs.textSlowdownFactor * 1.2f))
            ContentType.LIGHT_TEXT    -> (base * (prefs.textSlowdownFactor * 1.5f))
            ContentType.BLANK_SPACE   -> (base * prefs.blankSpeedupFactor)
            ContentType.COMMENT_SECTION -> (base * 1.2f)
            ContentType.NAVIGATION    -> (base * 2.0f)
            ContentType.AD            -> (base * 2.5f)
            ContentType.VIDEO         -> 0f
            ContentType.CHAPTER_END   -> 0f
            ContentType.MIXED         -> base
            ContentType.UNKNOWN       -> base
        }.coerceIn(prefs.minSpeed, prefs.maxSpeed)
    }

    fun reset() {
        currentSpeed = prefs.baseSpeed
        targetSpeed = prefs.baseSpeed
        currentContentType = ContentType.UNKNOWN
        useManualSpeed = false
        autoPauseTriggered = false
    }
}
