package com.bru.adaptiveautoscroll.data

object ProfileManager {

    val MANGA = Profile(
        id = "manga",
        name = "Manga",
        description = "Fast image scrolling, slow dialogue, chapter-end pause",
        colorHex = "#EF5350",
        baseSpeed = 7.0f,
        minSpeed = 2.0f,
        maxSpeed = 15.0f,
        adaptiveEnabled = true,
        textSlowdownFactor = 0.4f,
        imageSpeedupFactor = 1.8f,
        blankSpeedupFactor = 2.5f,
        pauseAtChapterEnd = true,
        pauseOnLongText = false,
        pauseOnVideos = false,
        pauseDurationMs = 3000L,
        longTextThreshold = 500
    )

    val WEBTOON = Profile(
        id = "webtoon",
        name = "Webtoon",
        description = "Continuous smooth scrolling with adaptive panel speed",
        colorHex = "#42A5F5",
        baseSpeed = 6.0f,
        minSpeed = 3.0f,
        maxSpeed = 12.0f,
        adaptiveEnabled = true,
        textSlowdownFactor = 0.6f,
        imageSpeedupFactor = 1.4f,
        blankSpeedupFactor = 2.0f,
        pauseAtChapterEnd = false,
        pauseOnLongText = false,
        pauseOnVideos = true,
        pauseDurationMs = 2000L,
        longTextThreshold = 800
    )

    val NOVEL = Profile(
        id = "novel",
        name = "Novel",
        description = "Text-priority reading with intelligent pauses",
        colorHex = "#66BB6A",
        baseSpeed = 4.0f,
        minSpeed = 1.0f,
        maxSpeed = 8.0f,
        adaptiveEnabled = true,
        textSlowdownFactor = 0.7f,
        imageSpeedupFactor = 1.2f,
        blankSpeedupFactor = 1.5f,
        pauseAtChapterEnd = true,
        pauseOnLongText = true,
        pauseOnVideos = false,
        pauseDurationMs = 5000L,
        longTextThreshold = 400
    )

    val ARTICLE = Profile(
        id = "article",
        name = "Article",
        description = "Moderate adaptive speed focused on readability",
        colorHex = "#FFA726",
        baseSpeed = 5.0f,
        minSpeed = 2.0f,
        maxSpeed = 10.0f,
        adaptiveEnabled = true,
        textSlowdownFactor = 0.55f,
        imageSpeedupFactor = 1.5f,
        blankSpeedupFactor = 2.0f,
        pauseAtChapterEnd = false,
        pauseOnLongText = true,
        pauseOnVideos = true,
        pauseDurationMs = 4000L,
        longTextThreshold = 600
    )

    val ALL: List<Profile> = listOf(MANGA, WEBTOON, NOVEL, ARTICLE)

    fun getById(id: String): Profile = ALL.find { it.id == id } ?: ARTICLE
}
