package com.bru.adaptiveautoscroll.engine

import android.view.accessibility.AccessibilityNodeInfo

enum class ContentType(val label: String, val emoji: String) {
    UNKNOWN("Analyzing…", "⏳"),
    MANGA_IMAGE("Manga Images", "📕"),
    WEBTOON_IMAGE("Webtoon Panels", "📱"),
    DENSE_TEXT("Dense Text", "📖"),
    LIGHT_TEXT("Light Text", "📄"),
    DIALOGUE("Dialogue", "💬"),
    BLANK_SPACE("Blank Space", "⬜"),
    MIXED("Mixed Content", "🔀"),
    COMMENT_SECTION("Comments", "💭"),
    VIDEO("Video", "▶️"),
    AD("Advertisement", "🚫"),
    NAVIGATION("Navigation", "🧭"),
    CHAPTER_END("Chapter End", "🏁")
}

data class NodeStats(
    var totalNodes: Int = 0,
    var imageNodes: Int = 0,
    var textNodes: Int = 0,
    var totalTextChars: Int = 0,
    var longTextNodes: Int = 0,     // text > 200 chars
    var dialogueNodes: Int = 0,     // short text segments
    var blankNodes: Int = 0,
    var videoNodes: Int = 0,
    var largeImageNodes: Int = 0,   // height heuristic for manga/webtoon
    var adIndicators: Int = 0,
    var navIndicators: Int = 0,
    var chapterEndIndicators: Int = 0
)

class ContentAnalyzer {

    private val adKeywords = setOf(
        "advertisement", "sponsored", "ad", "promoted", "google_ads", "adsbygoogle"
    )
    private val navKeywords = setOf(
        "navbar", "navigation", "nav-bar", "menu", "header", "footer", "toolbar"
    )
    private val chapterKeywords = setOf(
        "chapter end", "end of chapter", "next chapter", "next episode",
        "load next", "continue reading", "you've reached", "chapter complete"
    )

    fun analyze(root: AccessibilityNodeInfo?): ContentType {
        root ?: return ContentType.UNKNOWN
        val stats = NodeStats()
        traverseTree(root, stats, depth = 0, maxDepth = 10)
        return classify(stats)
    }

    private fun traverseTree(node: AccessibilityNodeInfo, stats: NodeStats, depth: Int, maxDepth: Int) {
        if (depth > maxDepth) return
        stats.totalNodes++

        val className = node.className?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""

        // Detect videos
        if (className.contains("video") || className.contains("mediacontroller") ||
            viewId.contains("video") || viewId.contains("player")) {
            stats.videoNodes++
        }

        // Detect ads
        if (adKeywords.any { viewId.contains(it) || desc.contains(it) }) {
            stats.adIndicators++
        }

        // Detect navigation
        if (navKeywords.any { viewId.contains(it) || className.contains(it) }) {
            stats.navIndicators++
        }

        // Detect chapter end
        val combinedText = (text + " " + desc).lowercase()
        if (chapterKeywords.any { combinedText.contains(it) }) {
            stats.chapterEndIndicators++
        }

        // Images
        if (className.contains("imageview") || className.contains("image") ||
            node.isClickable && desc.contains("image") ||
            className.contains("photo") || className.contains("picture")) {

            stats.imageNodes++
            // Heuristic: large images (checked via bounds)
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)
            val height = bounds.height()
            val width = bounds.width()
            if (height > 300 && width > 200) {
                stats.largeImageNodes++
            }
        }

        // Text
        if (text.isNotBlank()) {
            stats.textNodes++
            val len = text.length
            stats.totalTextChars += len
            when {
                len > 200 -> stats.longTextNodes++
                len < 60 && text.contains(Regex("[""]|—|\.\.\.|said|asked|replied|answered")) ->
                    stats.dialogueNodes++
            }
        }

        // Recurse
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseTree(child, stats, depth + 1, maxDepth)
            child.recycle()
        }
    }

    private fun classify(stats: NodeStats): ContentType {
        if (stats.totalNodes == 0) return ContentType.UNKNOWN
        if (stats.chapterEndIndicators > 0) return ContentType.CHAPTER_END
        if (stats.videoNodes > 0) return ContentType.VIDEO
        if (stats.adIndicators > 0) return ContentType.AD
        if (stats.navIndicators > 2) return ContentType.NAVIGATION

        val totalContentNodes = stats.imageNodes + stats.textNodes
        if (totalContentNodes == 0) {
            return if (stats.totalNodes < 8) ContentType.BLANK_SPACE else ContentType.UNKNOWN
        }

        val imageRatio = stats.imageNodes.toFloat() / totalContentNodes
        val largeImageRatio = if (stats.imageNodes > 0)
            stats.largeImageNodes.toFloat() / stats.imageNodes else 0f

        // Manga: lots of large images, very little text
        if (imageRatio > 0.6f && largeImageRatio > 0.5f && stats.totalTextChars < 200) {
            return ContentType.MANGA_IMAGE
        }

        // Webtoon: images dominant but may have some text
        if (imageRatio > 0.5f && stats.largeImageNodes > 2) {
            return ContentType.WEBTOON_IMAGE
        }

        // Comment section
        if (stats.dialogueNodes > 5 && stats.totalTextChars > 500) {
            return ContentType.COMMENT_SECTION
        }

        // Dialogue heavy
        if (stats.dialogueNodes > stats.longTextNodes * 2 && stats.dialogueNodes > 3) {
            return ContentType.DIALOGUE
        }

        // Dense text
        if (stats.longTextNodes > 2 || stats.totalTextChars > 1000) {
            return ContentType.DENSE_TEXT
        }

        // Light text
        if (stats.textNodes > 0 && stats.totalTextChars > 100) {
            return ContentType.LIGHT_TEXT
        }

        // Blank
        if (stats.totalNodes < 6 && stats.totalTextChars < 50) {
            return ContentType.BLANK_SPACE
        }

        return ContentType.MIXED
    }
}
