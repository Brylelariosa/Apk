# GBA Emulator (Android)

A Game Boy Advance emulator built from scratch for Android — a real ARM7TDMI
interpreter, PPU, APU, and memory system written from the public hardware
specification, not a wrapped copy of an existing emulator core (mGBA,
VBA-M, etc.). No root, no Shizuku, no elevated permissions of any kind:
it's a plain sandboxed Android app. ROMs are opened through the Storage
Access Framework, so it doesn't even need a storage permission.

## Why this is worth reading before you build

A fully accurate GBA emulator — one that passes every hardware test ROM and
runs every commercial game glitch-free — is a multi-year project even for a
dedicated team (that's genuinely how long mGBA, VBA-M, and NanoBoyAdvance
took). What's here is a complete, correctly-architected **first version**:
every subsystem is implemented and wired together, the CPU interpreter
covers the full ARM and THUMB instruction sets, and a real debugger is
built in. It has **not** been run through a compiler (this environment has
no Android SDK/NDK toolchain), so treat the first build as step one of a
normal edit-compile-fix cycle, not a guarantee of a clean build. The
"Known limitations" section below is a deliberately honest list of the
places most likely to need follow-up work.

## Architecture

```
app/src/main/cpp/            Native core (C++17), built as libgbacore.so
  common/types.h             Shared integer types + bit helpers
  scheduler/                 Central event queue driving PPU/timer/APU timing
  irq/                       Interrupt controller (IE/IF/IME)
  timers/                    4 hardware timers, event-driven (not ticked every cycle)
  dma/                       4 DMA channels incl. DirectSound FIFO bursts
  memory/
    bus.*                    The full address map — the only class that
                              knows where every address routes
    cartridge.*               ROM loading, header parsing, save-type detection
    backup.*                  SRAM / Flash / EEPROM emulation
  video/ppu.*                Modes 0-5, backgrounds (text + affine), sprites
                              (regular + affine), windows, blending, mosaic
  audio/apu.*                4 PSG channels (square x2, wave, noise) +
                              2 DirectSound FIFO channels, 32768 Hz output
  cpu/                       ARM7TDMI: registers, mode banking, full ARM +
                              THUMB instruction sets (cpu_core / cpu_arm /
                              cpu_thumb.cpp)
  bios/bios_hle.*            High-level emulation of the BIOS SWI API
                              (Div, CpuSet, VBlankIntrWait, LZ77, ...) — see
                              below for why this exists
  debug/                     Breakpoints/step state + an ARM/THUMB disassembler
  gba.*                      Top-level system: owns and wires up every
                              subsystem, runs the main loop
  jni_bridge.cpp              The only file that touches JNI

app/src/main/java/com/gbaemu/app/
  core/EmulatorCore.kt        Kotlin wrapper over the JNI surface
  emulation/EmulationThread.kt Dedicated thread running the core at ~59.7 fps,
                              decoupled from the UI thread
  audio/AudioEngine.kt        AudioTrack streaming playback
  ui/game/                    Render surface (Canvas blit, nearest-neighbor),
                              on-screen touch controls, GameActivity
  ui/debug/                   The in-app debugger screen
  input/                      Physical gamepad + analog stick mapping
  MainActivity.kt             ROM library (SAF import) + launcher
```

**Design choices worth knowing about:**
- **Scheduler-driven timing**, not a per-cycle tick of every subsystem.
  PPU/timers/APU each schedule their next event and get called back — this
  is what keeps them decoupled from each other and from the CPU loop.
- **Hierarchical instruction decode** (check major bit-fields, dispatch to
  a category handler) rather than a precomputed dispatch table. Slightly
  more readable and maintainable; plenty fast for real-time GBA emulation
  on any modern phone.
- **BIOS HLE by default.** Real GBA BIOS firmware is Nintendo's copyrighted
  code, so it isn't included or reproduced anywhere here. Instead,
  `bios_hle.cpp` reimplements the documented SWI calls (the same public
  calling convention devkitARM/libgba compile against) directly in C++.
  The emulator works out of the box with no BIOS file. If you have a
  legally-dumped BIOS image, `EmulatorCore` can still load one
  (`nativeLoadBios`) for full-fidelity SWI/IRQ dispatch instead.

## Building

This project is meant to go through the GitHub Actions workflow you
already have (`.github/workflows/build-apk.yml`-style): zip the project,
push it to `uploads/`, let CI build the APK.

**One fix your existing workflow needs first:** it pins Gradle to `8.6`,
which is now too old for a current Android Gradle Plugin (AGP 8.10 needs
Gradle 8.11.1+). This project's `gradle-wrapper.properties` already points
at Gradle 8.11.1 — update the two `"8.6"` references in the workflow to
match:

```yaml
- name: Setup Gradle
  uses: gradle/actions/setup-gradle@v3
  with:
    gradle-version: '8.11.1'   # was '8.6'
...
- name: Fetch gradle-wrapper.jar
  run: |
    GRADLE_VERSION="8.11.1"    # was "8.6"
```

Building locally instead: open in Android Studio (Narwhal or newer), or
`./gradlew assembleDebug` with the NDK (25.2.9519653) and CMake (3.22.1)
installed.

**Toolchain versions used:** AGP 8.10.0, Gradle 8.11.1, Kotlin 2.3.20,
Compose BOM 2026.04.01, compileSdk/targetSdk 36, minSdk 24. Chosen to be
current while staying on the well-established AGP 8.x line rather than the
very new AGP 9.x (which requires migrating off the classic Kotlin Android
plugin) — bump when you're ready for that migration.

## The debugger

Tap the gear icon during a game to open it. It has:
- **Registers** — R0-R15 and CPSR (flags + ARM/THUMB mode) live
- **Disassembly** — ~14 lines centered on PC; tap a line to toggle a
  breakpoint (shown as a red dot)
- **Memory viewer** — hex + ASCII, jump to any address
- **Pause / Step / Resume**, backed by real breakpoint support (execution
  stops the instant PC hits a breakpointed address)

All of it is exposed over JNI (`EmulatorCore.debug*`) if you want to build
different UI around the same native debugger state.

## Known limitations (please read before filing this as "broken")

- **Not yet compiled.** See above — expect an edit/fix pass for the first
  build.
- **CPU correctness.** The ARM7TDMI interpreter covers the full ARM and
  THUMB instruction sets and was written carefully against the documented
  semantics, but it has not been validated against hardware-test ROMs
  (ARMWrestler, FuzzARM, and similar homebrew test suites are the standard
  way to do this and are freely available). Treat it as "should be mostly
  right" rather than "verified."
- **PPU:** mosaic is implemented for backgrounds and sprites; affine
  sprites and windows are implemented but are the least-tested code paths.
  Green-swap and a few other rare DISPCNT-adjacent quirks aren't modeled.
- **APU:** all channels are implemented with a real frame sequencer, but
  exact envelope/sweep edge-case timing hasn't been validated against
  hardware recordings — expect it to sound right, not necessarily
  sample-accurate.
- **EEPROM save type:** 4Kbit vs. 64Kbit can't be reliably told apart from
  the ROM's save-type marker string alone; this defaults to 64Kbit, which
  covers the large majority of EEPROM games.
- **Wait states:** cartridge/EWRAM access timing uses fixed defaults
  rather than fully honoring WAITCNT reconfiguration. Affects a small
  number of games that tune WAITCNT for prefetch tricks, not general
  compatibility.
- **BIOS HLE gaps:** `IntrWait`/`VBlankIntrWait` wake on any enabled
  interrupt rather than precisely the awaited one (correct whenever the
  awaited interrupt is the only one enabled, which is the common case).
  Huffman decompression, bit-unpacking, and the diff-filter BIOS calls
  aren't implemented (LZ77 and RLE are). `SoftReset` is a simplified
  approximation.
- **No save states, no rewind, no GL renderer** — none of these were part
  of the ask; the architecture (clean separation between core and I/O)
  should make all three straightforward to add later.

## Suggested next steps

1. Get it compiling (Android Studio will surface anything this review
   missed).
2. Drop in a homebrew test ROM or two and see what renders.
3. Run an ARM test ROM (ARMWrestler is a good first one) to shake out CPU
   bugs before worrying about game compatibility.
4. Iterate from there — happy to help debug specific failures once you
   have build output or a screenshot of what's going wrong.
