# Keep everything the native side calls back into via JNI (fields/methods
# referenced by name from jni_bridge.cpp must survive R8's shrinker).
-keepclasseswithmembers class com.gbaemu.app.core.EmulatorCore {
    native <methods>;
}
-keep class com.gbaemu.app.core.EmulatorCore { *; }
-keep class com.gbaemu.app.core.DebugRegisters { *; }
-keep class com.gbaemu.app.core.DebugBreakpoint { *; }

# Standard Compose/Kotlin metadata keep rules.
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
