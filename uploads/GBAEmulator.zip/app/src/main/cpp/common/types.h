#pragma once
// Shared primitive types and small bit-twiddling helpers used everywhere in
// the core. Kept dependency-free (no other core headers) so every module can
// include it without creating cycles.

#include <cstdint>
#include <cstddef>

namespace gba {

using u8  = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using s8  = int8_t;
using s16 = int16_t;
using s32 = int32_t;
using s64 = int64_t;

// --- bit helpers -----------------------------------------------------------

constexpr u32 Bit(int n) { return 1u << n; }

constexpr bool TestBit(u32 value, int n) { return (value & Bit(n)) != 0; }

// Extract [hi:lo] inclusive, both ends 0-31, hi >= lo.
constexpr u32 BitRange(u32 value, int hi, int lo) {
    u32 width = static_cast<u32>(hi - lo + 1);
    u32 mask = (width >= 32) ? 0xFFFFFFFFu : ((1u << width) - 1u);
    return (value >> lo) & mask;
}

constexpr u32 SignExtend(u32 value, int bits) {
    u32 shift = 32u - static_cast<u32>(bits);
    return static_cast<u32>((static_cast<s32>(value << shift)) >> shift);
}

inline u32 RotateRight32(u32 value, u32 amount) {
    amount &= 31u;
    if (amount == 0) return value;
    return (value >> amount) | (value << (32u - amount));
}

// --- non-owning byte-addressable view over a fixed buffer -------------------
// Used for ROM/RAM regions so bus code doesn't need to care what backs them.
struct MemoryBlock {
    u8* data = nullptr;
    u32 size = 0;

    u8 ReadByte(u32 offset) const {
        return (data && offset < size) ? data[offset] : 0;
    }
    void WriteByte(u32 offset, u8 value) {
        if (data && offset < size) data[offset] = value;
    }
};

} // namespace gba
