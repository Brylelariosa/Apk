#include "gba.h"

namespace gba {

void Gba::Init() {
    scheduler_.Init();
    interrupt_.Reset();
    timer_.Init(&scheduler_, &interrupt_, &apu_);
    dma_.Init(&bus_, &interrupt_);
    ppu_.Init(&scheduler_, &interrupt_, &dma_, bus_.VramRaw(), bus_.OamRaw(), bus_.PaletteRaw());
    apu_.Init(&scheduler_, &dma_);
    bus_.Init(&ppu_, &apu_, &dma_, &timer_, &interrupt_, &cartridge_);
    bus_.SetHaltCallback([this] { halted_ = true; });
    cpu_.Init(&bus_, &biosHle_);
    debugger_.Reset();
}

bool Gba::LoadRom(std::vector<u8> romData) {
    if (!cartridge_.LoadRom(std::move(romData))) return false;
    Reset();
    return true;
}

bool Gba::LoadBios(std::vector<u8> biosData) {
    return bus_.LoadBiosImage(biosData);
}

void Gba::Reset() {
    scheduler_.Reset();
    interrupt_.Reset();
    timer_.Reset();
    dma_.Reset();
    ppu_.Reset();
    apu_.Reset();
    bus_.Reset();
    cartridge_.Reset();
    cpu_.Reset();
    halted_ = false;
    debugger_.Reset();
}

void Gba::Step() {
    if (halted_) {
        u64 skip = scheduler_.CyclesUntilNextEvent();
        if (skip == 0 || skip > 100000) skip = 1232; // one scanline; defensive clamp — PPU always keeps an event armed in practice
        scheduler_.Tick(skip);
        if (interrupt_.HasPendingForHalt()) halted_ = false;
        return;
    }
    u32 cycles = cpu_.Step();
    scheduler_.Tick(cycles);
    if (interrupt_.Pending()) {
        cpu_.HandleIRQ();
    }
}

void Gba::RunFrame() {
    ClearFrameReady();
    while (!FrameReady()) {
        if (debugger_.IsPaused()) return;

        if (!halted_ && debugger_.HasBreakpoint(cpu_.CurrentPC())) {
            debugger_.Pause();
            return;
        }

        Step();

        if (debugger_.ConsumeSingleStepFlag()) {
            debugger_.Pause();
            return;
        }
    }
}

void Gba::DebugStepOne() {
    debugger_.RequestSingleStep();
    RunFrame();
}

} // namespace gba
