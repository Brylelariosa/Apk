#include "dma.h"
#include "../memory/bus.h"

namespace gba {

void DmaController::Init(Bus* bus, InterruptController* irq) {
    bus_ = bus;
    irq_ = irq;
    Reset();
}

void DmaController::Reset() {
    for (auto& c : channels_) c = Channel{};
}

void DmaController::WriteSAD(int ch, u32 value) { channels_[ch].srcAddr = value; }
void DmaController::WriteDAD(int ch, u32 value) { channels_[ch].dstAddr = value; }
void DmaController::WriteCount(int ch, u16 value) { channels_[ch].wordCount = value; }

void DmaController::WriteControl(int ch, u16 value) {
    Channel& c = channels_[ch];
    bool wasEnabled = TestBit(c.control, 15);
    c.control = value;
    bool nowEnabled = TestBit(c.control, 15);

    if (!wasEnabled && nowEnabled) {
        // Arming latches SAD/DAD into the working pointers the transfer loop
        // actually walks, so later writes to SAD/DAD don't disturb a
        // channel that's already running/repeating.
        c.curSrc = c.srcAddr;
        c.curDst = c.dstAddr;
        auto timing = static_cast<DmaStartTiming>((c.control >> 12) & 0x3);
        if (timing == DmaStartTiming::Immediate) {
            RunChannel(ch, false);
        }
    }
}

void DmaController::MaybeRun(int ch, DmaStartTiming timing) {
    Channel& c = channels_[ch];
    if (!TestBit(c.control, 15)) return;
    auto t = static_cast<DmaStartTiming>((c.control >> 12) & 0x3);
    if (t == timing) RunChannel(ch, false);
}

void DmaController::OnHBlank() { for (int i = 0; i < 4; i++) MaybeRun(i, DmaStartTiming::HBlank); }
void DmaController::OnVBlank() { for (int i = 0; i < 4; i++) MaybeRun(i, DmaStartTiming::VBlank); }

void DmaController::NotifyFifoTrigger(int fifoIndex) {
    // FIFO A is refilled by DMA1, FIFO B by DMA2 — fixed by hardware design.
    int ch = (fifoIndex == 0) ? 1 : 2;
    Channel& c = channels_[ch];
    if (!TestBit(c.control, 15)) return;
    auto t = static_cast<DmaStartTiming>((c.control >> 12) & 0x3);
    if (t == DmaStartTiming::Special) RunChannel(ch, true);
}

void DmaController::RunChannel(int ch, bool isFifoBurst) {
    Channel& c = channels_[ch];

    u32 destCtrl = (c.control >> 5) & 0x3;
    u32 srcCtrl = (c.control >> 7) & 0x3;
    bool wordTransfer = TestBit(c.control, 10) || isFifoBurst;
    bool repeat = TestBit(c.control, 9);

    u32 maxCount = (ch == 3) ? 0x10000u : 0x4000u;
    u32 count = isFifoBurst ? 4u : (c.wordCount == 0 ? maxCount : static_cast<u32>(c.wordCount));

    u32 unitSize = wordTransfer ? 4u : 2u;
    auto stepFor = [unitSize](u32 ctrl) -> s32 {
        switch (ctrl) {
            case 0: return static_cast<s32>(unitSize);   // increment
            case 1: return -static_cast<s32>(unitSize);  // decrement
            case 2: return 0;                             // fixed
            default: return static_cast<s32>(unitSize);   // increment+reload (walks as increment)
        }
    };
    s32 srcStep = stepFor(srcCtrl);
    s32 destStep = isFifoBurst ? 0 : stepFor(destCtrl); // FIFO bursts always target a fixed FIFO address

    for (u32 i = 0; i < count; i++) {
        if (wordTransfer) {
            u32 v = bus_->Read32(c.curSrc & ~3u);
            bus_->Write32(c.curDst & ~3u, v);
        } else {
            u16 v = bus_->Read16(c.curSrc & ~1u);
            bus_->Write16(c.curDst & ~1u, v);
        }
        c.curSrc = static_cast<u32>(static_cast<s32>(c.curSrc) + srcStep);
        c.curDst = static_cast<u32>(static_cast<s32>(c.curDst) + destStep);
    }

    if (TestBit(c.control, 14)) {
        static constexpr u16 kIrq[4] = { IRQ_DMA0, IRQ_DMA1, IRQ_DMA2, IRQ_DMA3 };
        irq_->Request(kIrq[ch]);
    }

    auto timing = static_cast<DmaStartTiming>((c.control >> 12) & 0x3);
    if (repeat && timing != DmaStartTiming::Immediate) {
        if (destCtrl == 3 && !isFifoBurst) {
            c.curDst = c.dstAddr; // increment+reload: fresh destination next repeat
        }
        // Channel stays armed (bit 15 untouched) — next matching trigger fires it again.
    } else {
        c.control &= static_cast<u16>(~Bit(15)); // one-shot: disable after firing
    }
}

} // namespace gba
