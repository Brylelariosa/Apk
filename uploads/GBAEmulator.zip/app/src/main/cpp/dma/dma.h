#pragma once
#include "../common/types.h"
#include "../irq/interrupt.h"

namespace gba {

class Bus;
class Scheduler;

enum class DmaStartTiming : u32 { Immediate = 0, VBlank = 1, HBlank = 2, Special = 3 };

// The four DMA channels (DMA0-3). DMA0 can't reach cartridge space, DMA3
// is the only one that can drive game-pak DRQ / large ROM->RAM copies; we
// don't special-case those restrictions in the transfer path itself (a
// misbehaving game asking DMA0 to read ROM would do so on real hardware
// too, just returning garbage) but callers *should* respect them.
class DmaController {
public:
    void Init(Bus* bus, InterruptController* irq);
    void Reset();

    // I/O register access — Bus routes reads/writes in 0x40000B0..0x40000DE here.
    void WriteSAD(int ch, u32 value);
    void WriteDAD(int ch, u32 value);
    void WriteCount(int ch, u16 value);
    void WriteControl(int ch, u16 value);
    u16 ReadControl(int ch) const { return channels_[ch].control; }
    // Read-back of the programmed (not in-flight) addresses/count — needed so
    // Bus can do a correct read-modify-write if a game writes SAD/DAD as two
    // 16-bit halves instead of one 32-bit access.
    u32 SAD(int ch) const { return channels_[ch].srcAddr; }
    u32 DAD(int ch) const { return channels_[ch].dstAddr; }
    u16 Count(int ch) const { return channels_[ch].wordCount; }

    // PPU calls these at the start of HBlank/VBlank; runs any channel armed
    // for that start-timing.
    void OnHBlank();
    void OnVBlank();

    // APU calls this when a DirectSound FIFO (0=A/DMA1, 1=B/DMA2) needs a
    // refill; runs the fixed 4-word burst if that channel is armed for
    // Special timing.
    void NotifyFifoTrigger(int fifoIndex);

private:
    struct Channel {
        u32 srcAddr = 0;
        u32 dstAddr = 0;
        u16 wordCount = 0;
        u16 control = 0;

        // Latched at transfer start; these are what the transfer loop
        // actually walks (so mid-transfer writes to SAD/DAD don't corrupt
        // an in-flight transfer, matching hardware behavior).
        u32 curSrc = 0;
        u32 curDst = 0;
    };

    Channel channels_[4];
    Bus* bus_ = nullptr;
    InterruptController* irq_ = nullptr;

    void RunChannel(int ch, bool isFifoBurst);
    void MaybeRun(int ch, DmaStartTiming timing);
};

} // namespace gba
