#include "cartridge.h"
#include <cstring>

namespace gba {

namespace {
bool ContainsMarker(const std::vector<u8>& rom, const char* needle) {
    size_t len = std::strlen(needle);
    if (rom.size() < len) return false;
    for (size_t i = 0; i + len <= rom.size(); i++) {
        if (std::memcmp(&rom[i], needle, len) == 0) return true;
    }
    return false;
}
} // namespace

BackupType Cartridge::DetectSaveType(const std::vector<u8>& rom) {
    // Commercial ROMs embed one of these ASCII markers verbatim (the same
    // technique flash carts and every mainstream GBA emulator use to pick a
    // save type; it's a devkit convention, not reverse-engineered).
    if (ContainsMarker(rom, "EEPROM_V")) {
        // 4Kbit vs 64Kbit EEPROM can't be told apart from the marker alone;
        // 64Kbit covers the large majority of EEPROM titles, so that's the
        // default here. A handful of older EEPROM games may need this
        // overridden — see the README.
        return BackupType::Eeprom64K;
    }
    if (ContainsMarker(rom, "FLASH1M_V")) return BackupType::Flash128K;
    if (ContainsMarker(rom, "FLASH512_V")) return BackupType::Flash64K;
    if (ContainsMarker(rom, "FLASH_V")) return BackupType::Flash64K;
    if (ContainsMarker(rom, "SRAM_V")) return BackupType::Sram;
    return BackupType::None;
}

void Cartridge::ParseHeader() {
    header_ = CartridgeHeader{};
    if (rom_.size() < 0xC0) return;

    std::string title(reinterpret_cast<const char*>(&rom_[0xA0]), 12);
    while (!title.empty() && (title.back() == '\0' || title.back() == ' ')) title.pop_back();
    header_.title = title;

    header_.gameCode = std::string(reinterpret_cast<const char*>(&rom_[0xAC]), 4);
    header_.version = rom_[0xBC];
}

bool Cartridge::LoadRom(std::vector<u8> romBytes) {
    if (romBytes.empty()) return false;
    rom_ = std::move(romBytes);
    ParseHeader();
    backup_.SetType(DetectSaveType(rom_));
    return true;
}

void Cartridge::Reset() {
    backup_.Reset();
}

u8 Cartridge::ReadRomByte(u32 offset) const {
    if (offset < rom_.size()) return rom_[offset];
    return static_cast<u8>((offset >> 1) & 0xFF);
}

u16 Cartridge::ReadRomHalf(u32 offset) const {
    if (offset + 1 < rom_.size()) {
        return static_cast<u16>(rom_[offset]) | (static_cast<u16>(rom_[offset + 1]) << 8);
    }
    // Past the end of the ROM image, real hardware's open bus reflects the
    // halfword address back — some homebrew relies on this to detect the
    // end of ROM, so it's worth emulating rather than just returning 0.
    return static_cast<u16>((offset >> 1) & 0xFFFF);
}

u32 Cartridge::ReadRomWord(u32 offset) const {
    if (offset + 3 < rom_.size()) {
        return static_cast<u32>(rom_[offset]) |
               (static_cast<u32>(rom_[offset + 1]) << 8) |
               (static_cast<u32>(rom_[offset + 2]) << 16) |
               (static_cast<u32>(rom_[offset + 3]) << 24);
    }
    u32 lo = ReadRomHalf(offset);
    u32 hi = ReadRomHalf(offset + 2);
    return lo | (hi << 16);
}

} // namespace gba
