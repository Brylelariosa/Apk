#include "backup.h"
#include <algorithm>

namespace gba {

namespace {
constexpr size_t SizeFor(BackupType type) {
    switch (type) {
        case BackupType::Sram:      return 32 * 1024;
        case BackupType::Flash64K:  return 64 * 1024;
        case BackupType::Flash128K: return 128 * 1024;
        case BackupType::Eeprom4K:  return 512;
        case BackupType::Eeprom64K: return 8 * 1024;
        default: return 0;
    }
}
} // namespace

void BackupMemory::SetType(BackupType type) {
    type_ = type;
    data_.assign(SizeFor(type), 0xFF); // erased flash/EEPROM reads as 0xFF
    Reset();
}

void BackupMemory::Reset() {
    flashPhase_ = 0;
    flashIdMode_ = false;
    pendingByteProgram_ = false;
    flashBank_ = 0;
    eepromMode_ = EepromMode::Idle;
    eepromShiftReg_ = 0;
    eepromDataBuf_ = 0;
    eepromBitPos_ = 0;
    eepromCommand_ = 0;
    eepromAddress_ = 0;
    eepromPendingRead_ = false;
}

void BackupMemory::LoadRaw(const std::vector<u8>& bytes) {
    if (data_.empty()) return;
    size_t n = std::min(bytes.size(), data_.size());
    std::copy(bytes.begin(), bytes.begin() + static_cast<long>(n), data_.begin());
}

// --- SRAM / Flash ------------------------------------------------------

u8 BackupMemory::ReadByte(u32 offset) {
    if (type_ == BackupType::Sram) {
        return (offset < data_.size()) ? data_[offset] : 0xFF;
    }
    if (type_ == BackupType::Flash64K || type_ == BackupType::Flash128K) {
        if (flashIdMode_ && offset < 2) {
            // Panasonic-style manufacturer/device ID pair — good enough for
            // games that only probe flash size to choose 64K vs 128K layout.
            static const u8 id64[2]  = { 0x32, 0x1B };
            static const u8 id128[2] = { 0x62, 0x13 };
            return (type_ == BackupType::Flash128K) ? id128[offset] : id64[offset];
        }
        u32 addr = offset + (static_cast<u32>(flashBank_) * 0x10000u);
        return (addr < data_.size()) ? data_[addr] : 0xFF;
    }
    return 0xFF;
}

void BackupMemory::WriteByte(u32 offset, u8 value) {
    if (type_ == BackupType::Sram) {
        if (offset < data_.size()) data_[offset] = value;
        return;
    }
    if (type_ != BackupType::Flash64K && type_ != BackupType::Flash128K) return;

    if (pendingByteProgram_) {
        u32 addr = offset + (static_cast<u32>(flashBank_) * 0x10000u);
        if (addr < data_.size()) data_[addr] = value;
        pendingByteProgram_ = false;
        flashPhase_ = 0;
        return;
    }

    switch (flashPhase_) {
        case 0:
            if (offset == 0x5555 && value == 0xAA) flashPhase_ = 1;
            return;
        case 1:
            flashPhase_ = (offset == 0x2AAA && value == 0x55) ? 2 : 0;
            return;
        case 2:
            switch (value) {
                case 0x90: flashIdMode_ = true; break;
                case 0xF0: flashIdMode_ = false; break;
                case 0xA0: pendingByteProgram_ = true; break;
                case 0xB0: flashPhase_ = 3; return; // await bank-select write
                case 0x80: flashPhase_ = 4; return; // erase command prefix
                default: break;
            }
            flashPhase_ = 0;
            return;
        case 3: // bank switch (128KB flash only): value written selects bank 0/1
            flashBank_ = value & 0x1;
            flashPhase_ = 0;
            return;
        case 4:
            flashPhase_ = (offset == 0x5555 && value == 0xAA) ? 5 : 0;
            return;
        case 5:
            flashPhase_ = (offset == 0x2AAA && value == 0x55) ? 6 : 0;
            return;
        case 6:
            if (value == 0x10) {
                std::fill(data_.begin(), data_.end(), 0xFF); // chip erase
            } else if (value == 0x30) {
                u32 sectorBase = (offset & ~0xFFFu) + (static_cast<u32>(flashBank_) * 0x10000u);
                for (u32 i = 0; i < 0x1000 && (sectorBase + i) < data_.size(); i++) {
                    data_[sectorBase + i] = 0xFF; // 4KB sector erase
                }
            }
            flashPhase_ = 0;
            return;
    }
}

// --- EEPROM --------------------------------------------------------------
// Bit-serial protocol: 2 command bits ("11"=read, "10"=write), then a 6-bit
// (4Kbit part) or 14-bit (64Kbit part) row address, then for writes 64 data
// bits (8 bytes, MSB first) and a stop bit, or for reads a stop bit followed
// later by 4 dummy bits and 64 data bits streamed out on subsequent reads.

u16 BackupMemory::EepromRead() {
    if (eepromMode_ != EepromMode::Reading) {
        return 1; // "ready" idle line state
    }
    if (eepromBitPos_ < 4) {
        eepromBitPos_++;
        return 0; // 4 dummy bits precede the real data on a read
    }
    int bitIndex = eepromBitPos_ - 4; // 0..63
    int byteIndex = bitIndex / 8;
    int bitInByte = 7 - (bitIndex % 8); // MSB first
    u32 rowAddr = eepromAddress_ * 8;
    u8 byte = (rowAddr + static_cast<u32>(byteIndex) < data_.size())
                  ? data_[rowAddr + static_cast<u32>(byteIndex)] : 0xFF;
    eepromBitPos_++;
    if (eepromBitPos_ >= 4 + 64) {
        eepromMode_ = EepromMode::Idle;
    }
    return (byte >> bitInByte) & 1;
}

void BackupMemory::EepromWrite(u16 halfword) {
    u32 bit = halfword & 1;
    int addrBits = (type_ == BackupType::Eeprom64K) ? 14 : 6;

    switch (eepromMode_) {
        case EepromMode::Idle:
            eepromShiftReg_ = bit;
            eepromBitPos_ = 1;
            eepromMode_ = EepromMode::ReceivingCommand;
            break;

        case EepromMode::ReceivingCommand:
            eepromShiftReg_ = (eepromShiftReg_ << 1) | bit;
            eepromBitPos_++;
            if (eepromBitPos_ == 2) {
                eepromCommand_ = eepromShiftReg_ & 0x3;
                eepromShiftReg_ = 0;
                eepromBitPos_ = 0;
                eepromMode_ = EepromMode::ReceivingAddress;
            }
            break;

        case EepromMode::ReceivingAddress:
            eepromShiftReg_ = (eepromShiftReg_ << 1) | bit;
            eepromBitPos_++;
            if (eepromBitPos_ == addrBits) {
                eepromAddress_ = eepromShiftReg_ & ((1u << addrBits) - 1u);
                eepromShiftReg_ = 0;
                eepromBitPos_ = 0;
                if (eepromCommand_ == 0x3) { // read request
                    eepromPendingRead_ = true;
                    eepromMode_ = EepromMode::ExpectStopBit;
                } else { // write request
                    eepromDataBuf_ = 0;
                    eepromMode_ = EepromMode::ReceivingData;
                }
            }
            break;

        case EepromMode::ExpectStopBit:
            eepromMode_ = eepromPendingRead_ ? EepromMode::Reading : EepromMode::Idle;
            eepromBitPos_ = 0;
            eepromPendingRead_ = false;
            break;

        case EepromMode::ReceivingData:
            eepromDataBuf_ = (eepromDataBuf_ << 1) | bit;
            eepromBitPos_++;
            if (eepromBitPos_ == 64) {
                u32 rowAddr = eepromAddress_ * 8;
                for (int i = 0; i < 8; i++) {
                    u8 byte = static_cast<u8>(eepromDataBuf_ >> (56 - i * 8));
                    if (rowAddr + static_cast<u32>(i) < data_.size()) {
                        data_[rowAddr + static_cast<u32>(i)] = byte;
                    }
                }
                eepromMode_ = EepromMode::ExpectStopBit;
                eepromPendingRead_ = false;
                eepromBitPos_ = 0;
            }
            break;

        case EepromMode::Reading:
            break; // writes are ignored while a read is streaming out
    }
}

} // namespace gba
