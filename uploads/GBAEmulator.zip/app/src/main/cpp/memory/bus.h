#pragma once
#include <array>
#include <functional>
#include <vector>
#include "../common/types.h"

namespace gba {

class Ppu;
class Apu;
class DmaController;
class TimerController;
class InterruptController;
class Cartridge;

// The GBA's single unified address space. Every other subsystem that needs
// to read or write memory (CPU, DMA) goes through here; Bus in turn owns the
// flat RAM regions directly and forwards register-mapped I/O addresses to
// whichever subsystem owns that register range. This is the one class that
// is allowed to know the whole memory map — everyone else just calls
// Read8/16/32 / Write8/16/32.
class Bus {
public:
    void Init(Ppu* ppu, Apu* apu, DmaController* dma, TimerController* timer,
              InterruptController* irq, Cartridge* cart);
    void Reset();

    u8  Read8(u32 addr);
    u16 Read16(u32 addr);
    u32 Read32(u32 addr);
    void Write8(u32 addr, u8 value);
    void Write16(u32 addr, u16 value);
    void Write32(u32 addr, u32 value);

    // Approximate access cost in cycles — used by the CPU to time
    // instructions. See bus.cpp for the documented simplifications (fixed
    // wait-state defaults rather than fully modeling WAITCNT).
    int AccessCycles(u32 addr, int sizeBytes) const;

    bool LoadBiosImage(const std::vector<u8>& bytes);
    bool HasRealBios() const { return !biosRom_.empty(); }

    void SetHaltCallback(std::function<void()> cb) { onHalt_ = std::move(cb); }
    void RequestHalt() { if (onHalt_) onHalt_(); }
    void SetKeyState(u16 gbaKeyMask, bool pressed);

    // Raw pointers for the debugger / save-state code — never used by the
    // interpreter itself, which always goes through Read/Write above so
    // mirroring and side effects stay correct.
    u8* EwramRaw() { return ewram_.data(); }
    u8* IwramRaw() { return iwram_.data(); }
    u8* PaletteRaw() { return paletteRam_.data(); }
    u8* VramRaw() { return vram_.data(); }
    u8* OamRaw() { return oam_.data(); }

private:
    std::array<u8, 256 * 1024> ewram_{};
    std::array<u8, 32 * 1024> iwram_{};
    std::array<u8, 1024> paletteRam_{};
    std::array<u8, 96 * 1024> vram_{};
    std::array<u8, 1024> oam_{};
    std::vector<u8> biosRom_; // empty unless the user supplies a real BIOS

    u16 keyinput_ = 0x03FF; // all 10 buttons unpressed (active-low)
    u16 keycnt_ = 0;
    u16 waitcnt_ = 0;
    u16 ime_ = 0;
    bool haltPending_ = false;

    Ppu* ppu_ = nullptr;
    Apu* apu_ = nullptr;
    DmaController* dma_ = nullptr;
    TimerController* timer_ = nullptr;
    InterruptController* irq_ = nullptr;
    Cartridge* cart_ = nullptr;
    std::function<void()> onHalt_;

    u16 ReadIo16(u32 addr);
    void WriteIo16(u32 addr, u16 value);
    u8 ReadIo8(u32 addr);
    void WriteIo8(u32 addr, u8 value);
};

} // namespace gba
