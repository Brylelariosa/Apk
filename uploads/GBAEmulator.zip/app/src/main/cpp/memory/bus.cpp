#include "bus.h"
#include "cartridge.h"
#include "../video/ppu.h"
#include "../audio/apu.h"
#include "../dma/dma.h"
#include "../timers/timer.h"
#include "../irq/interrupt.h"

namespace gba {

namespace {
enum class Region { Bios, Ewram, Iwram, Io, Palette, Vram, Oam, Rom, Sram, Unused };

Region Classify(u32 addr, u32& offset) {
    switch (addr >> 24) {
        case 0x00: case 0x01:
            offset = addr & 0x3FFF;
            return Region::Bios;
        case 0x02:
            offset = addr & 0x3FFFF;
            return Region::Ewram;
        case 0x03:
            offset = addr & 0x7FFF;
            return Region::Iwram;
        case 0x04:
            offset = addr & 0x00FFFFFF;
            return Region::Io;
        case 0x05:
            offset = addr & 0x3FF;
            return Region::Palette;
        case 0x06: {
            u32 o = addr & 0x1FFFF;
            if (o >= 0x18000) o -= 0x8000; // last 32K block of the 128K VRAM window mirrors the previous one
            offset = o;
            return Region::Vram;
        }
        case 0x07:
            offset = addr & 0x3FF;
            return Region::Oam;
        case 0x08: case 0x09: case 0x0A: case 0x0B: case 0x0C: case 0x0D:
            offset = addr & 0x01FFFFFF;
            return Region::Rom;
        case 0x0E: case 0x0F:
            offset = addr & 0x0000FFFF;
            return Region::Sram;
        default:
            offset = 0;
            return Region::Unused;
    }
}
} // namespace

void Bus::Init(Ppu* ppu, Apu* apu, DmaController* dma, TimerController* timer,
                InterruptController* irq, Cartridge* cart) {
    ppu_ = ppu; apu_ = apu; dma_ = dma; timer_ = timer; irq_ = irq; cart_ = cart;
    Reset();
}

void Bus::Reset() {
    ewram_.fill(0);
    iwram_.fill(0);
    paletteRam_.fill(0);
    vram_.fill(0);
    oam_.fill(0);
    keyinput_ = 0x03FF;
    keycnt_ = 0;
    waitcnt_ = 0;
    ime_ = 0;
    haltPending_ = false;
}

bool Bus::LoadBiosImage(const std::vector<u8>& bytes) {
    if (bytes.size() < 0x4000) return false;
    biosRom_ = bytes;
    return true;
}

void Bus::SetKeyState(u16 gbaKeyMask, bool pressed) {
    // KEYINPUT is active-low: 0 = pressed, 1 = released.
    if (pressed) keyinput_ &= static_cast<u16>(~gbaKeyMask);
    else keyinput_ |= gbaKeyMask;

    // Keypad IRQ (KEYCNT): fires if enabled and the configured condition
    // (AND of all selected buttons vs. OR of any) currently holds.
    if (TestBit(keycnt_, 14)) {
        u16 selected = keycnt_ & 0x3FF;
        u16 pressedMask = static_cast<u16>(~keyinput_) & 0x3FF;
        bool condIsAnd = TestBit(keycnt_, 15);
        bool fire = condIsAnd ? ((pressedMask & selected) == selected)
                              : ((pressedMask & selected) != 0);
        if (fire && irq_) irq_->Request(IRQ_KEYPAD);
    }
}

// --- 8-bit ------------------------------------------------------------

u8 Bus::Read8(u32 addr) {
    u32 off;
    switch (Classify(addr, off)) {
        case Region::Bios:
            // Real BIOS open-bus protection (returning stale fetched
            // opcodes when PC isn't executing from BIOS) is not emulated —
            // a documented simplification. With no BIOS image supplied at
            // all (the default; SWIs are handled via HLE instead) this
            // region simply reads as 0, which is fine since HLE code never
            // actually executes here.
            return (!biosRom_.empty() && off < biosRom_.size()) ? biosRom_[off] : 0;
        case Region::Ewram: return ewram_[off];
        case Region::Iwram: return iwram_[off];
        case Region::Io: return ReadIo8(off);
        case Region::Palette: return paletteRam_[off];
        case Region::Vram: return vram_[off];
        case Region::Oam: return oam_[off];
        case Region::Rom: return cart_ ? cart_->ReadRomByte(off) : 0xFFu;
        case Region::Sram: return cart_ ? cart_->Backup().ReadByte(off) : 0xFFu;
        default: return 0;
    }
}

void Bus::Write8(u32 addr, u8 value) {
    u32 off;
    switch (Classify(addr, off)) {
        case Region::Ewram: ewram_[off] = value; return;
        case Region::Iwram: iwram_[off] = value; return;
        case Region::Io: WriteIo8(off, value); return;
        case Region::Palette:
            // A byte write to palette RAM writes the same byte into both
            // halves of the containing halfword (matches hardware).
            paletteRam_[off & ~1u] = value;
            paletteRam_[(off & ~1u) + 1] = value;
            return;
        case Region::Vram:
            // Byte writes to OBJ tile VRAM are ignored on real hardware;
            // approximated here as writing both bytes of the halfword like
            // palette RAM, which is correct for BG VRAM (the common case).
            vram_[off & ~1u] = value;
            if ((off & ~1u) + 1 < vram_.size()) vram_[(off & ~1u) + 1] = value;
            return;
        case Region::Oam: return; // byte writes to OAM are ignored on real hardware
        case Region::Sram: if (cart_) cart_->Backup().WriteByte(off, value); return;
        default: return;
    }
}

// --- 16-bit -------------------------------------------------------------

u16 Bus::Read16(u32 addr) {
    addr &= ~1u;
    u32 off;
    Region r = Classify(addr, off);
    switch (r) {
        case Region::Bios: return static_cast<u16>(Read8(addr)) | (static_cast<u16>(Read8(addr + 1)) << 8);
        case Region::Ewram: return static_cast<u16>(ewram_[off]) | (static_cast<u16>(ewram_[off + 1]) << 8);
        case Region::Iwram: return static_cast<u16>(iwram_[off]) | (static_cast<u16>(iwram_[off + 1]) << 8);
        case Region::Io: return ReadIo16(off);
        case Region::Palette: return static_cast<u16>(paletteRam_[off]) | (static_cast<u16>(paletteRam_[off + 1]) << 8);
        case Region::Vram: return static_cast<u16>(vram_[off]) | (static_cast<u16>(off + 1 < vram_.size() ? vram_[off + 1] : 0) << 8);
        case Region::Oam: return static_cast<u16>(oam_[off]) | (static_cast<u16>(oam_[off + 1]) << 8);
        case Region::Rom: {
            // EEPROM shares the WS2 mirror's address space (page 0x0D).
            if (cart_ && cart_->Backup().IsEeprom() && (addr >> 24) == 0x0D) {
                return cart_->Backup().EepromRead();
            }
            return cart_ ? cart_->ReadRomHalf(off) : 0xFFFFu;
        }
        case Region::Sram: {
            u8 b = cart_ ? cart_->Backup().ReadByte(off) : 0xFF;
            return static_cast<u16>(b) | (static_cast<u16>(b) << 8);
        }
        default: return 0;
    }
}

void Bus::Write16(u32 addr, u16 value) {
    addr &= ~1u;
    u32 off;
    Region r = Classify(addr, off);
    switch (r) {
        case Region::Ewram: ewram_[off] = static_cast<u8>(value); ewram_[off + 1] = static_cast<u8>(value >> 8); return;
        case Region::Iwram: iwram_[off] = static_cast<u8>(value); iwram_[off + 1] = static_cast<u8>(value >> 8); return;
        case Region::Io: WriteIo16(off, value); return;
        case Region::Palette: paletteRam_[off] = static_cast<u8>(value); paletteRam_[off + 1] = static_cast<u8>(value >> 8); return;
        case Region::Vram:
            vram_[off] = static_cast<u8>(value);
            if (off + 1 < vram_.size()) vram_[off + 1] = static_cast<u8>(value >> 8);
            return;
        case Region::Oam: oam_[off] = static_cast<u8>(value); oam_[off + 1] = static_cast<u8>(value >> 8); return;
        case Region::Rom:
            if (cart_ && cart_->Backup().IsEeprom() && (addr >> 24) == 0x0D) {
                cart_->Backup().EepromWrite(value);
            }
            return; // writes to plain ROM are no-ops
        case Region::Sram:
            if (cart_) { cart_->Backup().WriteByte(off, static_cast<u8>(value)); }
            return;
        default: return;
    }
}

// --- 32-bit -------------------------------------------------------------

u32 Bus::Read32(u32 addr) {
    addr &= ~3u;
    u32 off;
    Region r = Classify(addr, off);
    switch (r) {
        case Region::Ewram: return static_cast<u32>(ewram_[off]) | (static_cast<u32>(ewram_[off+1])<<8) | (static_cast<u32>(ewram_[off+2])<<16) | (static_cast<u32>(ewram_[off+3])<<24);
        case Region::Iwram: return static_cast<u32>(iwram_[off]) | (static_cast<u32>(iwram_[off+1])<<8) | (static_cast<u32>(iwram_[off+2])<<16) | (static_cast<u32>(iwram_[off+3])<<24);
        case Region::Rom:
            if (cart_ && cart_->Backup().IsEeprom() && (addr >> 24) == 0x0D) {
                u16 lo = cart_->Backup().EepromRead();
                u16 hi = cart_->Backup().EepromRead();
                return static_cast<u32>(lo) | (static_cast<u32>(hi) << 16);
            }
            return cart_ ? cart_->ReadRomWord(off) : 0xFFFFFFFFu;
        default:
            return static_cast<u32>(Read16(addr)) | (static_cast<u32>(Read16(addr + 2)) << 16);
    }
}

void Bus::Write32(u32 addr, u32 value) {
    addr &= ~3u;
    u32 off;
    Region r = Classify(addr, off);
    switch (r) {
        case Region::Ewram:
            ewram_[off]=static_cast<u8>(value); ewram_[off+1]=static_cast<u8>(value>>8);
            ewram_[off+2]=static_cast<u8>(value>>16); ewram_[off+3]=static_cast<u8>(value>>24);
            return;
        case Region::Iwram:
            iwram_[off]=static_cast<u8>(value); iwram_[off+1]=static_cast<u8>(value>>8);
            iwram_[off+2]=static_cast<u8>(value>>16); iwram_[off+3]=static_cast<u8>(value>>24);
            return;
        case Region::Rom:
            if (cart_ && cart_->Backup().IsEeprom() && (addr >> 24) == 0x0D) {
                cart_->Backup().EepromWrite(static_cast<u16>(value));
                cart_->Backup().EepromWrite(static_cast<u16>(value >> 16));
            }
            return;
        default:
            Write16(addr, static_cast<u16>(value));
            Write16(addr + 2, static_cast<u16>(value >> 16));
            return;
    }
}

// --- I/O register dispatch ------------------------------------------------

u16 Bus::ReadIo16(u32 off) {
    if (off < 0x60) return ppu_ ? ppu_->ReadReg16(off) : 0;
    if (off < 0xA8) return apu_ ? apu_->ReadReg16(off - 0x60) : 0;

    switch (off) {
        case 0xB8: return dma_ ? dma_->Count(0) : 0;
        case 0xBA: return dma_ ? dma_->ReadControl(0) : 0;
        case 0xC4: return dma_ ? dma_->Count(1) : 0;
        case 0xC6: return dma_ ? dma_->ReadControl(1) : 0;
        case 0xD0: return dma_ ? dma_->Count(2) : 0;
        case 0xD2: return dma_ ? dma_->ReadControl(2) : 0;
        case 0xDC: return dma_ ? dma_->Count(3) : 0;
        case 0xDE: return dma_ ? dma_->ReadControl(3) : 0;

        case 0x100: return timer_ ? timer_->ReadCounter(0) : 0;
        case 0x102: return timer_ ? timer_->ReadControl(0) : 0;
        case 0x104: return timer_ ? timer_->ReadCounter(1) : 0;
        case 0x106: return timer_ ? timer_->ReadControl(1) : 0;
        case 0x108: return timer_ ? timer_->ReadCounter(2) : 0;
        case 0x10A: return timer_ ? timer_->ReadControl(2) : 0;
        case 0x10C: return timer_ ? timer_->ReadCounter(3) : 0;
        case 0x10E: return timer_ ? timer_->ReadControl(3) : 0;

        case 0x130: return keyinput_;
        case 0x132: return keycnt_;

        case 0x200: return irq_ ? irq_->IE() : 0;
        case 0x202: return irq_ ? irq_->IF() : 0;
        case 0x204: return waitcnt_;
        case 0x208: return ime_;
        default: return 0;
    }
}

void Bus::WriteIo16(u32 off, u16 value) {
    if (off < 0x60) { if (ppu_) ppu_->WriteReg16(off, value); return; }
    if (off < 0xA8) { if (apu_) apu_->WriteReg16(off - 0x60, value); return; }

    switch (off) {
        case 0xB0: if (dma_) dma_->WriteSAD(0, (dma_->SAD(0) & 0xFFFF0000u) | value); return;
        case 0xB2: if (dma_) dma_->WriteSAD(0, (dma_->SAD(0) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xB4: if (dma_) dma_->WriteDAD(0, (dma_->DAD(0) & 0xFFFF0000u) | value); return;
        case 0xB6: if (dma_) dma_->WriteDAD(0, (dma_->DAD(0) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xB8: if (dma_) dma_->WriteCount(0, value); return;
        case 0xBA: if (dma_) dma_->WriteControl(0, value); return;

        case 0xBC: if (dma_) dma_->WriteSAD(1, (dma_->SAD(1) & 0xFFFF0000u) | value); return;
        case 0xBE: if (dma_) dma_->WriteSAD(1, (dma_->SAD(1) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xC0: if (dma_) dma_->WriteDAD(1, (dma_->DAD(1) & 0xFFFF0000u) | value); return;
        case 0xC2: if (dma_) dma_->WriteDAD(1, (dma_->DAD(1) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xC4: if (dma_) dma_->WriteCount(1, value); return;
        case 0xC6: if (dma_) dma_->WriteControl(1, value); return;

        case 0xC8: if (dma_) dma_->WriteSAD(2, (dma_->SAD(2) & 0xFFFF0000u) | value); return;
        case 0xCA: if (dma_) dma_->WriteSAD(2, (dma_->SAD(2) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xCC: if (dma_) dma_->WriteDAD(2, (dma_->DAD(2) & 0xFFFF0000u) | value); return;
        case 0xCE: if (dma_) dma_->WriteDAD(2, (dma_->DAD(2) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xD0: if (dma_) dma_->WriteCount(2, value); return;
        case 0xD2: if (dma_) dma_->WriteControl(2, value); return;

        case 0xD4: if (dma_) dma_->WriteSAD(3, (dma_->SAD(3) & 0xFFFF0000u) | value); return;
        case 0xD6: if (dma_) dma_->WriteSAD(3, (dma_->SAD(3) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xD8: if (dma_) dma_->WriteDAD(3, (dma_->DAD(3) & 0xFFFF0000u) | value); return;
        case 0xDA: if (dma_) dma_->WriteDAD(3, (dma_->DAD(3) & 0x0000FFFFu) | (static_cast<u32>(value) << 16)); return;
        case 0xDC: if (dma_) dma_->WriteCount(3, value); return;
        case 0xDE: if (dma_) dma_->WriteControl(3, value); return;

        case 0x100: if (timer_) timer_->WriteReload(0, value); return;
        case 0x102: if (timer_) timer_->WriteControl(0, value); return;
        case 0x104: if (timer_) timer_->WriteReload(1, value); return;
        case 0x106: if (timer_) timer_->WriteControl(1, value); return;
        case 0x108: if (timer_) timer_->WriteReload(2, value); return;
        case 0x10A: if (timer_) timer_->WriteControl(2, value); return;
        case 0x10C: if (timer_) timer_->WriteReload(3, value); return;
        case 0x10E: if (timer_) timer_->WriteControl(3, value); return;

        case 0x132: keycnt_ = value; return;

        case 0x200: if (irq_) irq_->SetIE(value); return;
        case 0x202: if (irq_) irq_->WriteIF(value); return;
        case 0x204: waitcnt_ = value; return;
        case 0x208: ime_ = value & 1; if (irq_) irq_->SetIME(ime_); return;
        default: return;
    }
}

u8 Bus::ReadIo8(u32 off) {
    u16 reg = ReadIo16(off & ~1u);
    return static_cast<u8>((off & 1) ? (reg >> 8) : reg);
}

void Bus::WriteIo8(u32 off, u8 value) {
    // IF is write-1-to-clear; a generic read-modify-write of the containing
    // halfword would round-trip the untouched byte's currently-set bits
    // back through "clear on 1" and wipe out pending flags the game never
    // meant to touch. Handle its two bytes directly instead.
    if (off == 0x202) { if (irq_) irq_->WriteIF(value); return; }
    if (off == 0x203) { if (irq_) irq_->WriteIF(static_cast<u16>(value) << 8); return; }

    u16 reg = ReadIo16(off & ~1u);
    if (off & 1) reg = static_cast<u16>((reg & 0x00FF) | (static_cast<u16>(value) << 8));
    else reg = static_cast<u16>((reg & 0xFF00) | value);
    WriteIo16(off & ~1u, reg);

    // HALTCNT (0x4000301, byte access only): writing here requests HALT.
    if (off == 0x301) {
        haltPending_ = true;
        RequestHalt();
    }
}

// --- timing ---------------------------------------------------------------

int Bus::AccessCycles(u32 addr, int sizeBytes) const {
    // Simplified, fixed wait-state model using the GBA's power-on defaults
    // rather than fully honoring WAITCNT reconfiguration — see README for
    // what this trades away (a small number of games tune WAITCNT for
    // prefetch/timing tricks that won't be reflected here).
    u32 page = addr >> 24;
    switch (page) {
        case 0x00: case 0x01: return 1;                 // BIOS
        case 0x02: return (sizeBytes >= 4) ? 6 : 3;      // EWRAM
        case 0x03: return 1;                             // IWRAM
        case 0x04: return 1;                             // I/O
        case 0x05: return (sizeBytes >= 4) ? 2 : 1;       // Palette
        case 0x06: return (sizeBytes >= 4) ? 2 : 1;       // VRAM
        case 0x07: return 1;                              // OAM
        case 0x08: case 0x09: case 0x0A: case 0x0B: case 0x0C: case 0x0D:
            return (sizeBytes >= 4) ? 8 : 5;              // ROM (WS0 defaults)
        case 0x0E: case 0x0F: return 5;                   // SRAM/Flash
        default: return 1;
    }
}

} // namespace gba
