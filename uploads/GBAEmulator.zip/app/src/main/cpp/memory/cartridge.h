#pragma once
#include <string>
#include <vector>
#include "../common/types.h"
#include "backup.h"

namespace gba {

struct CartridgeHeader {
    std::string title;     // 12 bytes at 0xA0, trimmed
    std::string gameCode;  // 4 bytes at 0xAC
    u8 version = 0;
};

// Owns the loaded ROM image and its backup (save) memory. Save-type
// detection scans the ROM for the same ASCII marker strings the official
// devkit's linker embeds (games are built with one of these strings present
// verbatim in an unused const somewhere, historically so flash-cart
// hardware could identify the right save type) — the same technique real
// GBA emulators and flash carts use; it isn't a secret Nintendo format.
class Cartridge {
public:
    bool LoadRom(std::vector<u8> romBytes);
    void Reset();

    const CartridgeHeader& Header() const { return header_; }
    u32 RomSize() const { return static_cast<u32>(rom_.size()); }

    u8 ReadRomByte(u32 offset) const;
    u16 ReadRomHalf(u32 offset) const;
    u32 ReadRomWord(u32 offset) const;

    BackupMemory& Backup() { return backup_; }
    const BackupMemory& Backup() const { return backup_; }

    bool IsLoaded() const { return !rom_.empty(); }

private:
    std::vector<u8> rom_;
    CartridgeHeader header_;
    BackupMemory backup_;

    static BackupType DetectSaveType(const std::vector<u8>& rom);
    void ParseHeader();
};

} // namespace gba
