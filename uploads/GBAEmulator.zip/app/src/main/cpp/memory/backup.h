#pragma once
#include <vector>
#include "../common/types.h"

namespace gba {

enum class BackupType {
    None,
    Sram,       // 32KB, flat byte-addressable
    Flash64K,   // 64KB, sector-erase command protocol
    Flash128K,  // 128KB, banked (two 64KB banks) + command protocol
    Eeprom4K,   // 512 bytes, 6-bit row address, bit-serial DMA protocol
    Eeprom64K,  // 8KB, 14-bit row address, bit-serial DMA protocol
};

// Owns whichever single backup type a cartridge uses. SRAM/Flash are
// accessed as ordinary bytes in the 0x0E000000 region; EEPROM is accessed
// through a bit-serial protocol driven by 16-bit DMA reads/writes, which is
// why it gets its own Read/Write entry points instead of ReadByte/WriteByte.
class BackupMemory {
public:
    void SetType(BackupType type);
    BackupType Type() const { return type_; }
    bool IsEeprom() const { return type_ == BackupType::Eeprom4K || type_ == BackupType::Eeprom64K; }

    // SRAM / Flash byte interface (cart address space 0x0E000000-0x0E00FFFF).
    u8 ReadByte(u32 offset);
    void WriteByte(u32 offset, u8 value);

    // EEPROM bit-serial interface. `EepromRead` is polled by the CPU/DMA
    // performing 16-bit reads during a read sequence; `EepromWrite` is fed
    // one bit (in bit 0 of `halfword`) per 16-bit write during a
    // command/address/data sequence.
    u16 EepromRead();
    void EepromWrite(u16 halfword);

    std::vector<u8>& RawData() { return data_; }
    const std::vector<u8>& RawData() const { return data_; }
    void LoadRaw(const std::vector<u8>& bytes);
    void Reset();

private:
    BackupType type_ = BackupType::None;
    std::vector<u8> data_;

    // --- Flash command state machine ---
    int flashPhase_ = 0;
    bool flashIdMode_ = false;
    bool pendingByteProgram_ = false;
    u8 flashBank_ = 0;

    // --- EEPROM bit-serial state machine ---
    enum class EepromMode { Idle, ReceivingCommand, ReceivingAddress, ReceivingData, ExpectStopBit, Reading };
    EepromMode eepromMode_ = EepromMode::Idle;
    u32 eepromShiftReg_ = 0;
    u64 eepromDataBuf_ = 0;
    int eepromBitPos_ = 0;
    u32 eepromCommand_ = 0;
    u32 eepromAddress_ = 0;
    bool eepromPendingRead_ = false;
};

} // namespace gba
