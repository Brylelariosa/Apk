#include <jni.h>
#include <vector>
#include <string>
#include "gba.h"
#include "debug/disassembler.h"

using namespace gba;

namespace {
inline Gba* Handle(jlong ptr) { return reinterpret_cast<Gba*>(ptr); }
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeInit(JNIEnv*, jobject) {
    auto* g = new Gba();
    g->Init();
    return reinterpret_cast<jlong>(g);
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDestroy(JNIEnv*, jobject, jlong ptr) {
    delete Handle(ptr);
}

JNIEXPORT jboolean JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeLoadRom(JNIEnv* env, jobject, jlong ptr, jbyteArray romBytes) {
    Gba* g = Handle(ptr);
    jsize len = env->GetArrayLength(romBytes);
    std::vector<u8> data(static_cast<size_t>(len));
    env->GetByteArrayRegion(romBytes, 0, len, reinterpret_cast<jbyte*>(data.data()));
    return g->LoadRom(std::move(data)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeLoadBios(JNIEnv* env, jobject, jlong ptr, jbyteArray biosBytes) {
    Gba* g = Handle(ptr);
    jsize len = env->GetArrayLength(biosBytes);
    std::vector<u8> data(static_cast<size_t>(len));
    env->GetByteArrayRegion(biosBytes, 0, len, reinterpret_cast<jbyte*>(data.data()));
    return g->LoadBios(data) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeLoadBackup(JNIEnv* env, jobject, jlong ptr, jbyteArray backupBytes) {
    Gba* g = Handle(ptr);
    jsize len = env->GetArrayLength(backupBytes);
    std::vector<u8> data(static_cast<size_t>(len));
    env->GetByteArrayRegion(backupBytes, 0, len, reinterpret_cast<jbyte*>(data.data()));
    g->LoadBackupData(data);
}

JNIEXPORT jbyteArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeGetBackup(JNIEnv* env, jobject, jlong ptr) {
    Gba* g = Handle(ptr);
    auto& data = g->BackupData();
    jbyteArray out = env->NewByteArray(static_cast<jsize>(data.size()));
    if (!data.empty()) {
        env->SetByteArrayRegion(out, 0, static_cast<jsize>(data.size()), reinterpret_cast<const jbyte*>(data.data()));
    }
    return out;
}

JNIEXPORT jboolean JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeHasBackup(JNIEnv*, jobject, jlong ptr) {
    return Handle(ptr)->HasBackup() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeReset(JNIEnv*, jobject, jlong ptr) {
    Handle(ptr)->Reset();
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeRunFrame(JNIEnv*, jobject, jlong ptr) {
    Handle(ptr)->RunFrame();
}

JNIEXPORT jintArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeGetFrameBuffer(JNIEnv* env, jobject, jlong ptr) {
    Gba* g = Handle(ptr);
    const u32* fb = g->FrameBuffer();
    jintArray out = env->NewIntArray(kScreenWidth * kScreenHeight);
    env->SetIntArrayRegion(out, 0, kScreenWidth * kScreenHeight, reinterpret_cast<const jint*>(fb));
    return out;
}

JNIEXPORT jshortArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeGetAudioSamples(JNIEnv* env, jobject, jlong ptr, jint maxFrames) {
    Gba* g = Handle(ptr);
    std::vector<s16> buf(static_cast<size_t>(maxFrames) * 2);
    int frames = g->PullAudioSamples(buf.data(), maxFrames);
    jshortArray out = env->NewShortArray(frames * 2);
    if (frames > 0) {
        env->SetShortArrayRegion(out, 0, frames * 2, reinterpret_cast<const jshort*>(buf.data()));
    }
    return out;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeSetKey(JNIEnv*, jobject, jlong ptr, jint keyIndex, jboolean pressed) {
    Handle(ptr)->SetKeyState(Bit(keyIndex), pressed == JNI_TRUE);
}

JNIEXPORT jstring JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeGetRomTitle(JNIEnv* env, jobject, jlong ptr) {
    return env->NewStringUTF(Handle(ptr)->RomHeader().title.c_str());
}

// --- debugger surface ---

JNIEXPORT jboolean JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugIsPaused(JNIEnv*, jobject, jlong ptr) {
    return Handle(ptr)->DebuggerRef().IsPaused() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugPause(JNIEnv*, jobject, jlong ptr) {
    Handle(ptr)->DebuggerRef().Pause();
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugResume(JNIEnv*, jobject, jlong ptr) {
    Handle(ptr)->DebuggerRef().Resume();
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugStep(JNIEnv*, jobject, jlong ptr) {
    Handle(ptr)->DebugStepOne();
}

JNIEXPORT jintArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugGetRegisters(JNIEnv* env, jobject, jlong ptr) {
    Gba* g = Handle(ptr);
    Cpu& cpu = g->CpuRef();
    jint regs[17];
    for (int i = 0; i < 16; i++) regs[i] = static_cast<jint>(cpu.GetRegister(i));
    regs[16] = static_cast<jint>(cpu.GetCPSR());
    jintArray out = env->NewIntArray(17);
    env->SetIntArrayRegion(out, 0, 17, regs);
    return out;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugSetRegister(JNIEnv*, jobject, jlong ptr, jint index, jint value) {
    Cpu& cpu = Handle(ptr)->CpuRef();
    if (index == 16) cpu.SetCPSR(static_cast<u32>(value));
    else if (index >= 0 && index < 16) cpu.SetRegister(index, static_cast<u32>(value));
}

JNIEXPORT jbyteArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugReadMemory(JNIEnv* env, jobject, jlong ptr, jint addr, jint len) {
    Bus& bus = Handle(ptr)->BusRef();
    std::vector<jbyte> out(static_cast<size_t>(len));
    for (int i = 0; i < len; i++) out[static_cast<size_t>(i)] = static_cast<jbyte>(bus.Read8(static_cast<u32>(addr + i)));
    jbyteArray result = env->NewByteArray(len);
    env->SetByteArrayRegion(result, 0, len, out.data());
    return result;
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugWriteMemory(JNIEnv* env, jobject, jlong ptr, jint addr, jbyteArray data) {
    Bus& bus = Handle(ptr)->BusRef();
    jsize len = env->GetArrayLength(data);
    std::vector<jbyte> buf(static_cast<size_t>(len));
    env->GetByteArrayRegion(data, 0, len, buf.data());
    for (jsize i = 0; i < len; i++) bus.Write8(static_cast<u32>(addr + i), static_cast<u8>(buf[static_cast<size_t>(i)]));
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugAddBreakpoint(JNIEnv*, jobject, jlong ptr, jint addr) {
    Handle(ptr)->DebuggerRef().AddBreakpoint(static_cast<u32>(addr));
}

JNIEXPORT void JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugRemoveBreakpoint(JNIEnv*, jobject, jlong ptr, jint addr) {
    Handle(ptr)->DebuggerRef().RemoveBreakpoint(static_cast<u32>(addr));
}

JNIEXPORT jintArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugGetBreakpoints(JNIEnv* env, jobject, jlong ptr) {
    auto list = Handle(ptr)->DebuggerRef().ListBreakpoints();
    jintArray out = env->NewIntArray(static_cast<jsize>(list.size()));
    if (!list.empty()) {
        std::vector<jint> asJint(list.begin(), list.end());
        env->SetIntArrayRegion(out, 0, static_cast<jsize>(asJint.size()), asJint.data());
    }
    return out;
}

JNIEXPORT jobjectArray JNICALL
Java_com_gbaemu_app_core_EmulatorCore_nativeDebugDisassemble(JNIEnv* env, jobject, jlong ptr, jint addr, jint count) {
    Bus& bus = Handle(ptr)->BusRef();
    bool thumb = Handle(ptr)->CpuRef().IsThumb();
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray out = env->NewObjectArray(count, stringClass, nullptr);

    u32 cur = static_cast<u32>(addr);
    for (int i = 0; i < count; i++) {
        std::string line;
        if (thumb) {
            u16 instr = bus.Read16(cur);
            line = Disassembler::DisassembleThumb(cur, instr);
            cur += 2;
        } else {
            u32 instr = bus.Read32(cur);
            line = Disassembler::DisassembleArm(cur, instr);
            cur += 4;
        }
        env->SetObjectArrayElement(out, i, env->NewStringUTF(line.c_str()));
    }
    return out;
}

} // extern "C"
