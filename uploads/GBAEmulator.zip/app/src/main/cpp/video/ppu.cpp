#include "ppu.h"
#include "../dma/dma.h"
#include <algorithm>

namespace gba {

namespace {
constexpr u32 kVramSize = 96 * 1024;

inline u8 SafeVramRead(const u8* vram, u32 addr) { return (addr < kVramSize) ? vram[addr] : 0; }

u16 BlendAlpha(u16 a, u16 b, int eva, int evb) {
    int ar = a & 0x1F, ag = (a >> 5) & 0x1F, ab = (a >> 10) & 0x1F;
    int br = b & 0x1F, bg = (b >> 5) & 0x1F, bb = (b >> 10) & 0x1F;
    int r = std::min(31, (ar * eva + br * evb) / 16);
    int g = std::min(31, (ag * eva + bg * evb) / 16);
    int bl = std::min(31, (ab * eva + bb * evb) / 16);
    return static_cast<u16>(r | (g << 5) | (bl << 10));
}
u16 BlendBrighten(u16 c, int evy) {
    int r = c & 0x1F, g = (c >> 5) & 0x1F, b = (c >> 10) & 0x1F;
    r += ((31 - r) * evy) / 16; g += ((31 - g) * evy) / 16; b += ((31 - b) * evy) / 16;
    r = std::min(31, r); g = std::min(31, g); b = std::min(31, b);
    return static_cast<u16>(r | (g << 5) | (b << 10));
}
u16 BlendDarken(u16 c, int evy) {
    int r = c & 0x1F, g = (c >> 5) & 0x1F, b = (c >> 10) & 0x1F;
    r -= (r * evy) / 16; g -= (g * evy) / 16; b -= (b * evy) / 16;
    r = std::max(0, r); g = std::max(0, g); b = std::max(0, b);
    return static_cast<u16>(r | (g << 5) | (b << 10));
}
} // namespace

void Ppu::Init(Scheduler* scheduler, InterruptController* irq, DmaController* dma,
                u8* vram, u8* oam, u8* palette) {
    scheduler_ = scheduler;
    irq_ = irq;
    dma_ = dma;
    vram_ = vram;
    oam_ = oam;
    palette_ = palette;

    scheduler_->RegisterHandler(EventType::PpuHBlank, [this](u64 late) { OnHBlankStart(late); });
    scheduler_->RegisterHandler(EventType::PpuVCount, [this](u64 late) { OnScanlineStart(late); });

    Reset();
}

void Ppu::Reset() {
    dispcnt_ = 0x0080;
    dispstat_ = 0;
    vcount_ = 0;
    bgcnt_.fill(0);
    bghofs_.fill(0);
    bgvofs_.fill(0);
    bgpa_ = { 0x100, 0x100 };
    bgpb_ = { 0, 0 };
    bgpc_ = { 0, 0 };
    bgpd_ = { 0x100, 0x100 };
    bgxRef_ = { 0, 0 };
    bgyRef_ = { 0, 0 };
    bgxInternal_ = { 0, 0 };
    bgyInternal_ = { 0, 0 };
    win0h_ = win1h_ = win0v_ = win1v_ = winin_ = winout_ = mosaic_ = 0;
    bldcnt_ = bldalpha_ = bldy_ = 0;
    framebuffer_.fill(0xFF000000u);
    frameReady_ = false;

    if (scheduler_) scheduler_->Schedule(EventType::PpuHBlank, 960);
}

void Ppu::OnHBlankStart(u64 lateCycles) {
    dispstat_ |= Bit(1);
    if (TestBit(dispstat_, 4) && irq_) irq_->Request(IRQ_HBLANK);

    if (vcount_ < kScreenHeight) {
        RenderScanline(vcount_);
    }
    if (dma_) dma_->OnHBlank();

    u64 delay = (272 > lateCycles) ? (272 - lateCycles) : 1;
    scheduler_->Schedule(EventType::PpuVCount, delay);
}

void Ppu::OnScanlineStart(u64 lateCycles) {
    dispstat_ &= static_cast<u16>(~Bit(1));
    vcount_ = static_cast<u16>(vcount_ + 1);
    if (vcount_ >= 228) vcount_ = 0;

    u16 lyc = (dispstat_ >> 8) & 0xFF;
    bool matched = (vcount_ == lyc);
    if (matched) dispstat_ |= Bit(2); else dispstat_ &= static_cast<u16>(~Bit(2));
    if (matched && TestBit(dispstat_, 5) && irq_) irq_->Request(IRQ_VCOUNT);

    if (vcount_ == kScreenHeight) {
        dispstat_ |= Bit(0);
        if (TestBit(dispstat_, 3) && irq_) irq_->Request(IRQ_VBLANK);
        if (dma_) dma_->OnVBlank();
        frameReady_ = true;
    } else if (vcount_ == 0) {
        dispstat_ &= static_cast<u16>(~Bit(0));
    }

    u64 delay = (960 > lateCycles) ? (960 - lateCycles) : 1;
    scheduler_->Schedule(EventType::PpuHBlank, delay);
}

u16 Ppu::ReadReg16(u32 off) const {
    switch (off) {
        case 0x00: return dispcnt_;
        case 0x04: return dispstat_;
        case 0x06: return vcount_;
        case 0x08: case 0x0A: case 0x0C: case 0x0E: return bgcnt_[(off - 0x08) / 2];
        case 0x10: case 0x14: case 0x18: case 0x1C: return bghofs_[(off - 0x10) / 4];
        case 0x12: case 0x16: case 0x1A: case 0x1E: return bgvofs_[(off - 0x12) / 4];
        case 0x20: return static_cast<u16>(bgpa_[0]);
        case 0x22: return static_cast<u16>(bgpb_[0]);
        case 0x24: return static_cast<u16>(bgpc_[0]);
        case 0x26: return static_cast<u16>(bgpd_[0]);
        case 0x28: return static_cast<u16>(bgxRef_[0] & 0xFFFF);
        case 0x2A: return static_cast<u16>((bgxRef_[0] >> 16) & 0xFFFF);
        case 0x2C: return static_cast<u16>(bgyRef_[0] & 0xFFFF);
        case 0x2E: return static_cast<u16>((bgyRef_[0] >> 16) & 0xFFFF);
        case 0x30: return static_cast<u16>(bgpa_[1]);
        case 0x32: return static_cast<u16>(bgpb_[1]);
        case 0x34: return static_cast<u16>(bgpc_[1]);
        case 0x36: return static_cast<u16>(bgpd_[1]);
        case 0x38: return static_cast<u16>(bgxRef_[1] & 0xFFFF);
        case 0x3A: return static_cast<u16>((bgxRef_[1] >> 16) & 0xFFFF);
        case 0x3C: return static_cast<u16>(bgyRef_[1] & 0xFFFF);
        case 0x3E: return static_cast<u16>((bgyRef_[1] >> 16) & 0xFFFF);
        case 0x40: return win0h_;
        case 0x42: return win1h_;
        case 0x44: return win0v_;
        case 0x46: return win1v_;
        case 0x48: return winin_;
        case 0x4A: return winout_;
        case 0x4C: return mosaic_;
        case 0x50: return bldcnt_;
        case 0x52: return bldalpha_;
        case 0x54: return bldy_;
        default: return 0;
    }
}

void Ppu::WriteReg16(u32 off, u16 value) {
    switch (off) {
        case 0x00: dispcnt_ = value; return;
        case 0x04: dispstat_ = (dispstat_ & 0x0007) | (value & 0xFFF8); return; // bits 0-2 stay hardware-owned
        case 0x08: case 0x0A: case 0x0C: case 0x0E: bgcnt_[(off - 0x08) / 2] = value; return;
        case 0x10: case 0x14: case 0x18: case 0x1C: bghofs_[(off - 0x10) / 4] = value & 0x01FF; return;
        case 0x12: case 0x16: case 0x1A: case 0x1E: bgvofs_[(off - 0x12) / 4] = value & 0x01FF; return;
        case 0x20: bgpa_[0] = static_cast<s16>(value); return;
        case 0x22: bgpb_[0] = static_cast<s16>(value); return;
        case 0x24: bgpc_[0] = static_cast<s16>(value); return;
        case 0x26: bgpd_[0] = static_cast<s16>(value); return;
        case 0x28: bgxRef_[0] = SignExtend((static_cast<u32>(bgxRef_[0]) & 0xFFFF0000u) | value, 28); bgxInternal_[0] = bgxRef_[0]; return;
        case 0x2A: bgxRef_[0] = SignExtend((static_cast<u32>(bgxRef_[0]) & 0x0000FFFFu) | (static_cast<u32>(value) << 16), 28); bgxInternal_[0] = bgxRef_[0]; return;
        case 0x2C: bgyRef_[0] = SignExtend((static_cast<u32>(bgyRef_[0]) & 0xFFFF0000u) | value, 28); bgyInternal_[0] = bgyRef_[0]; return;
        case 0x2E: bgyRef_[0] = SignExtend((static_cast<u32>(bgyRef_[0]) & 0x0000FFFFu) | (static_cast<u32>(value) << 16), 28); bgyInternal_[0] = bgyRef_[0]; return;
        case 0x30: bgpa_[1] = static_cast<s16>(value); return;
        case 0x32: bgpb_[1] = static_cast<s16>(value); return;
        case 0x34: bgpc_[1] = static_cast<s16>(value); return;
        case 0x36: bgpd_[1] = static_cast<s16>(value); return;
        case 0x38: bgxRef_[1] = SignExtend((static_cast<u32>(bgxRef_[1]) & 0xFFFF0000u) | value, 28); bgxInternal_[1] = bgxRef_[1]; return;
        case 0x3A: bgxRef_[1] = SignExtend((static_cast<u32>(bgxRef_[1]) & 0x0000FFFFu) | (static_cast<u32>(value) << 16), 28); bgxInternal_[1] = bgxRef_[1]; return;
        case 0x3C: bgyRef_[1] = SignExtend((static_cast<u32>(bgyRef_[1]) & 0xFFFF0000u) | value, 28); bgyInternal_[1] = bgyRef_[1]; return;
        case 0x3E: bgyRef_[1] = SignExtend((static_cast<u32>(bgyRef_[1]) & 0x0000FFFFu) | (static_cast<u32>(value) << 16), 28); bgyInternal_[1] = bgyRef_[1]; return;
        case 0x40: win0h_ = value; return;
        case 0x42: win1h_ = value; return;
        case 0x44: win0v_ = value; return;
        case 0x46: win1v_ = value; return;
        case 0x48: winin_ = value; return;
        case 0x4A: winout_ = value; return;
        case 0x4C: mosaic_ = value; return;
        case 0x50: bldcnt_ = value; return;
        case 0x52: bldalpha_ = value; return;
        case 0x54: bldy_ = value; return;
        default: return;
    }
}

u16 Ppu::ReadPalette(int index) const {
    u32 byteOffset = (index < 256) ? static_cast<u32>(index) * 2u
                                    : 0x200u + static_cast<u32>(index - 256) * 2u;
    if (byteOffset + 1 >= 1024) return 0;
    return static_cast<u16>(palette_[byteOffset]) | (static_cast<u16>(palette_[byteOffset + 1]) << 8);
}

u32 Ppu::Rgb555ToArgb8888(u16 c) {
    u32 r = c & 0x1F, g = (c >> 5) & 0x1F, b = (c >> 10) & 0x1F;
    r = (r << 3) | (r >> 2);
    g = (g << 3) | (g >> 2);
    b = (b << 3) | (b >> 2);
    return 0xFF000000u | (r << 16) | (g << 8) | b;
}

void Ppu::RenderScanline(int line) {
    if (TestBit(dispcnt_, 7)) { // forced blank: hardware outputs white, VRAM/OAM freely accessible
        for (int x = 0; x < kScreenWidth; x++) framebuffer_[static_cast<size_t>(line) * kScreenWidth + x] = 0xFFFFFFFFu;
        return;
    }

    for (auto& row : bgLine_) row.fill(BgPixel{ 0, false });
    objLine_.fill(ObjPixel{ 0, 4, false, false });
    objWindowHit_.fill(false);

    u8 mode = dispcnt_ & 0x7;
    switch (mode) {
        case 0:
            for (int bg = 0; bg < 4; bg++) if (TestBit(dispcnt_, 8 + bg)) RenderTextBackground(bg, line);
            break;
        case 1:
            if (TestBit(dispcnt_, 8)) RenderTextBackground(0, line);
            if (TestBit(dispcnt_, 9)) RenderTextBackground(1, line);
            if (TestBit(dispcnt_, 10)) RenderAffineBackground(0, line);
            break;
        case 2:
            if (TestBit(dispcnt_, 10)) RenderAffineBackground(0, line);
            if (TestBit(dispcnt_, 11)) RenderAffineBackground(1, line);
            break;
        case 3: case 4: case 5:
            if (TestBit(dispcnt_, 10)) RenderBitmapBackground(line);
            break;
        default:
            break;
    }

    if (TestBit(dispcnt_, 12)) RenderSprites(line);

    CompositeScanline(line);
}

void Ppu::RenderTextBackground(int bg, int line) {
    u16 cnt = bgcnt_[bg];
    bool mosaicOn = TestBit(cnt, 6);
    int mosaicH = static_cast<int>(mosaic_ & 0xF) + 1;
    int mosaicV = static_cast<int>((mosaic_ >> 4) & 0xF) + 1;

    int effLine = mosaicOn ? (line - (line % mosaicV)) : line;
    int y = effLine + bgvofs_[bg];

    int screenSize = (cnt >> 14) & 0x3;
    int mapWidthTiles = (screenSize == 1 || screenSize == 3) ? 64 : 32;
    int mapHeightTiles = (screenSize == 2 || screenSize == 3) ? 64 : 32;
    int pixelsWide = mapWidthTiles * 8;
    int pixelsHigh = mapHeightTiles * 8;

    y = ((y % pixelsHigh) + pixelsHigh) % pixelsHigh;
    int tileRow = y / 8;
    int withinY = y % 8;

    bool color256 = TestBit(cnt, 7);
    u32 screenBase = ((cnt >> 8) & 0x1F) * 0x800u;
    u32 charBase = ((cnt >> 2) & 0x3) * 0x4000u;

    for (int x = 0; x < kScreenWidth; x++) {
        int effX = mosaicOn ? (x - (x % mosaicH)) : x;
        int xw = effX + bghofs_[bg];
        xw = ((xw % pixelsWide) + pixelsWide) % pixelsWide;
        int tileCol = xw / 8;
        int withinX = xw % 8;

        int localCol = tileCol, localRow = tileRow, block = 0;
        if (mapWidthTiles == 64 && tileCol >= 32) { block += 1; localCol -= 32; }
        if (mapHeightTiles == 64 && tileRow >= 32) { block += 2; localRow -= 32; }

        u32 mapAddr = screenBase + static_cast<u32>(block) * 0x800u +
                      static_cast<u32>(localRow * 32 + localCol) * 2u;
        u16 entry = static_cast<u16>(SafeVramRead(vram_, mapAddr)) |
                    (static_cast<u16>(SafeVramRead(vram_, mapAddr + 1)) << 8);
        int tileIndex = entry & 0x3FF;
        bool hFlip = TestBit(entry, 10);
        bool vFlip = TestBit(entry, 11);
        int paletteBank = (entry >> 12) & 0xF;

        int fx = hFlip ? (7 - withinX) : withinX;
        int fy = vFlip ? (7 - withinY) : withinY;

        if (color256) {
            u32 tileAddr = charBase + static_cast<u32>(tileIndex) * 64u + static_cast<u32>(fy) * 8u + static_cast<u32>(fx);
            u8 idx = SafeVramRead(vram_, tileAddr);
            bgLine_[bg][x] = { idx ? ReadPalette(idx) : static_cast<u16>(0), idx != 0 };
        } else {
            u32 tileAddr = charBase + static_cast<u32>(tileIndex) * 32u + static_cast<u32>(fy) * 4u + static_cast<u32>(fx) / 2u;
            u8 byte = SafeVramRead(vram_, tileAddr);
            u8 nib = (fx & 1) ? (byte >> 4) : (byte & 0xF);
            bgLine_[bg][x] = { nib ? ReadPalette(paletteBank * 16 + nib) : static_cast<u16>(0), nib != 0 };
        }
    }
}

void Ppu::RenderAffineBackground(int idx, int /*line*/) {
    int bg = idx + 2;
    u16 cnt = bgcnt_[bg];
    int screenSizeSel = (cnt >> 14) & 0x3;
    int tilesPerSide = 16 << screenSizeSel; // 16,32,64,128
    int pixelsPerSide = tilesPerSide * 8;
    bool wrap = TestBit(cnt, 13);
    u32 screenBase = ((cnt >> 8) & 0x1F) * 0x800u;
    u32 charBase = ((cnt >> 2) & 0x3) * 0x4000u;

    s32 refX = bgxInternal_[idx];
    s32 refY = bgyInternal_[idx];

    for (int x = 0; x < kScreenWidth; x++) {
        s32 texX = refX + x * bgpa_[idx];
        s32 texY = refY + x * bgpc_[idx];
        s32 px = texX >> 8;
        s32 py = texY >> 8;

        if (wrap) {
            px = ((px % pixelsPerSide) + pixelsPerSide) % pixelsPerSide;
            py = ((py % pixelsPerSide) + pixelsPerSide) % pixelsPerSide;
        } else if (px < 0 || py < 0 || px >= pixelsPerSide || py >= pixelsPerSide) {
            bgLine_[bg][x] = { 0, false };
            continue;
        }

        int tileCol = px / 8, tileRow = py / 8;
        int withinX = px % 8, withinY = py % 8;
        u32 mapAddr = screenBase + static_cast<u32>(tileRow * tilesPerSide + tileCol);
        u8 tileIndex = SafeVramRead(vram_, mapAddr);
        u32 tileAddr = charBase + static_cast<u32>(tileIndex) * 64u + static_cast<u32>(withinY * 8 + withinX);
        u8 colorIndex = SafeVramRead(vram_, tileAddr);
        bgLine_[bg][x] = { colorIndex ? ReadPalette(colorIndex) : static_cast<u16>(0), colorIndex != 0 };
    }

    bgxInternal_[idx] += bgpb_[idx];
    bgyInternal_[idx] += bgpd_[idx];
}

void Ppu::RenderBitmapBackground(int /*line*/) {
    u8 mode = dispcnt_ & 0x7;
    int width = (mode == 5) ? 160 : 240;
    int height = (mode == 5) ? 128 : 160;
    u32 base = (mode == 3) ? 0u : (TestBit(dispcnt_, 4) ? 0xA000u : 0u);

    s32 refX = bgxInternal_[0];
    s32 refY = bgyInternal_[0];

    for (int x = 0; x < kScreenWidth; x++) {
        s32 texX = refX + x * bgpa_[0];
        s32 texY = refY + x * bgpc_[0];
        s32 px = texX >> 8;
        s32 py = texY >> 8;

        if (px < 0 || py < 0 || px >= width || py >= height) {
            bgLine_[2][x] = { 0, false };
            continue;
        }

        if (mode == 4) {
            u32 addr = base + static_cast<u32>(py * width + px);
            u8 idx = SafeVramRead(vram_, addr);
            bgLine_[2][x] = { idx ? ReadPalette(idx) : static_cast<u16>(0), idx != 0 };
        } else {
            u32 addr = base + static_cast<u32>(py * width + px) * 2u;
            u16 raw = static_cast<u16>(SafeVramRead(vram_, addr)) | (static_cast<u16>(SafeVramRead(vram_, addr + 1)) << 8);
            bgLine_[2][x] = { raw, true };
        }
    }

    bgxInternal_[0] += bgpb_[0];
    bgyInternal_[0] += bgpd_[0];
}

void Ppu::RenderSprites(int line) {
    static constexpr int kShapeSize[4][4][2] = {
        { {8,8}, {16,16}, {32,32}, {64,64} },     // square
        { {16,8}, {32,8}, {32,16}, {64,32} },     // wide
        { {8,16}, {8,32}, {16,32}, {32,64} },     // tall
        { {8,8}, {8,8}, {8,8}, {8,8} },           // shape==3 is prohibited; fall back safely
    };
    bool mapping1D = TestBit(dispcnt_, 6);
    int objMosaicH = static_cast<int>((mosaic_ >> 8) & 0xF) + 1;
    int objMosaicV = static_cast<int>((mosaic_ >> 12) & 0xF) + 1;
    constexpr u32 kObjBase = 0x10000;

    for (int i = 0; i < 128; i++) {
        u32 base = static_cast<u32>(i) * 8u;
        u16 attr0 = static_cast<u16>(oam_[base]) | (static_cast<u16>(oam_[base + 1]) << 8);
        int affineMode = (attr0 >> 8) & 0x3;
        if (affineMode == 2) continue; // disabled

        u16 attr1 = static_cast<u16>(oam_[base + 2]) | (static_cast<u16>(oam_[base + 3]) << 8);
        u16 attr2 = static_cast<u16>(oam_[base + 4]) | (static_cast<u16>(oam_[base + 5]) << 8);

        int yCoord = attr0 & 0xFF;
        int gfxMode = (attr0 >> 10) & 0x3;
        bool mosaicOn = TestBit(attr0, 12);
        bool color256 = TestBit(attr0, 13);
        int shape = (attr0 >> 14) & 0x3;
        int sizeSel = (attr1 >> 14) & 0x3;
        int width = kShapeSize[shape][sizeSel][0];
        int height = kShapeSize[shape][sizeSel][1];

        bool doubleSize = (affineMode == 3);
        int boxW = doubleSize ? width * 2 : width;
        int boxH = doubleSize ? height * 2 : height;

        int rely = ((line - yCoord) % 256 + 256) % 256;
        if (mosaicOn) rely -= (rely % objMosaicV);
        if (rely < 0 || rely >= boxH) continue;

        s32 signedX = static_cast<s32>(SignExtend(attr1 & 0x1FF, 9));
        int tileIndex = attr2 & 0x3FF;
        int priority = (attr2 >> 10) & 0x3;
        int paletteBank = (attr2 >> 12) & 0xF;

        if (affineMode == 1 || affineMode == 3) {
            int group = (attr1 >> 9) & 0x1F;
            u32 gBase = static_cast<u32>(group) * 32u; // 4 OAM entries per group, 8 bytes each
            s16 pa = static_cast<s16>(oam_[gBase + 6] | (oam_[gBase + 7] << 8));
            s16 pb = static_cast<s16>(oam_[gBase + 14] | (oam_[gBase + 15] << 8));
            s16 pc = static_cast<s16>(oam_[gBase + 22] | (oam_[gBase + 23] << 8));
            s16 pd = static_cast<s16>(oam_[gBase + 30] | (oam_[gBase + 31] << 8));

            s32 cx = boxW / 2, cy = boxH / 2;
            s32 texCx = width / 2, texCy = height / 2;
            s32 dy = rely - cy;

            for (int sx = 0; sx < boxW; sx++) {
                s32 dx = sx - cx;
                s32 tX = ((pa * dx + pb * dy) >> 8) + texCx;
                s32 tY = ((pc * dx + pd * dy) >> 8) + texCy;
                if (tX < 0 || tY < 0 || tX >= width || tY >= height) continue;
                int screenX = signedX + sx;
                if (screenX < 0 || screenX >= kScreenWidth) continue;

                int tileCol = tX / 8, tileRow = tY / 8, wx = tX % 8, wy = tY % 8;
                u32 charAddr = mapping1D
                    ? kObjBase + static_cast<u32>(tileIndex) * 32u + static_cast<u32>(tileRow * (width / 8) + tileCol) * (color256 ? 64u : 32u)
                    : kObjBase + static_cast<u32>(tileIndex) * 32u + static_cast<u32>(tileRow) * 1024u + static_cast<u32>(tileCol) * (color256 ? 64u : 32u);

                u16 color; bool opaque;
                if (color256) {
                    u8 idx = SafeVramRead(vram_, charAddr + static_cast<u32>(wy) * 8u + static_cast<u32>(wx));
                    opaque = idx != 0;
                    color = opaque ? ReadPalette(256 + idx) : 0;
                } else {
                    u8 byte = SafeVramRead(vram_, charAddr + static_cast<u32>(wy) * 4u + static_cast<u32>(wx) / 2u);
                    u8 nib = (wx & 1) ? (byte >> 4) : (byte & 0xF);
                    opaque = nib != 0;
                    color = opaque ? ReadPalette(256 + paletteBank * 16 + nib) : 0;
                }
                if (!opaque) continue;

                if (gfxMode == 2) { objWindowHit_[screenX] = true; continue; }
                ObjPixel& slot = objLine_[screenX];
                if (!slot.opaque || priority < slot.priority) {
                    slot = { color, static_cast<u8>(priority), true, gfxMode == 1 };
                }
            }
        } else {
            bool hFlip = TestBit(attr1, 12);
            bool vFlip = TestBit(attr1, 13);
            int effY = vFlip ? (height - 1 - rely) : rely;

            for (int sx = 0; sx < width; sx++) {
                int screenX = signedX + sx;
                if (screenX < 0 || screenX >= kScreenWidth) continue;
                int effXlocal = sx;
                if (mosaicOn) effXlocal -= (effXlocal % objMosaicH);
                int effX = hFlip ? (width - 1 - effXlocal) : effXlocal;
                if (effX < 0 || effX >= width) continue;

                int tileCol = effX / 8, tileRow = effY / 8, wx = effX % 8, wy = effY % 8;
                u32 charAddr = mapping1D
                    ? kObjBase + static_cast<u32>(tileIndex) * 32u + static_cast<u32>(tileRow * (width / 8) + tileCol) * (color256 ? 64u : 32u)
                    : kObjBase + static_cast<u32>(tileIndex) * 32u + static_cast<u32>(tileRow) * 1024u + static_cast<u32>(tileCol) * (color256 ? 64u : 32u);

                u16 color; bool opaque;
                if (color256) {
                    u8 idx = SafeVramRead(vram_, charAddr + static_cast<u32>(wy) * 8u + static_cast<u32>(wx));
                    opaque = idx != 0;
                    color = opaque ? ReadPalette(256 + idx) : 0;
                } else {
                    u8 byte = SafeVramRead(vram_, charAddr + static_cast<u32>(wy) * 4u + static_cast<u32>(wx) / 2u);
                    u8 nib = (wx & 1) ? (byte >> 4) : (byte & 0xF);
                    opaque = nib != 0;
                    color = opaque ? ReadPalette(256 + paletteBank * 16 + nib) : 0;
                }
                if (!opaque) continue;

                if (gfxMode == 2) { objWindowHit_[screenX] = true; continue; }
                ObjPixel& slot = objLine_[screenX];
                if (!slot.opaque || priority < slot.priority) {
                    slot = { color, static_cast<u8>(priority), true, gfxMode == 1 };
                }
            }
        }
    }
}

Ppu::WindowResult Ppu::ResolveWindow(int x, int line, bool objWindowHit) const {
    WindowResult r;
    if (!WindowEnabled()) {
        r.bgEnable[0] = r.bgEnable[1] = r.bgEnable[2] = r.bgEnable[3] = true;
        r.objEnable = true;
        r.effectsEnable = true;
        return r;
    }

    bool win0On = TestBit(dispcnt_, 13);
    bool win1On = TestBit(dispcnt_, 14);
    bool objWinOn = TestBit(dispcnt_, 15);

    auto insideH = [x](u16 winH) {
        int x1 = (winH >> 8) & 0xFF, x2 = winH & 0xFF;
        return (x1 <= x2) ? (x >= x1 && x < x2) : (x >= x1 || x < x2);
    };
    auto insideV = [line](u16 winV) {
        int y1 = (winV >> 8) & 0xFF, y2 = winV & 0xFF;
        return (y1 <= y2) ? (line >= y1 && line < y2) : (line >= y1 || line < y2);
    };

    bool inWin0 = win0On && insideH(win0h_) && insideV(win0v_);
    bool inWin1 = win1On && insideH(win1h_) && insideV(win1v_);
    bool inObjWin = objWinOn && objWindowHit;

    u16 src;
    int bgBase, objBit, fxBit;
    if (inWin0) { src = winin_; bgBase = 0; objBit = 4; fxBit = 5; }
    else if (inWin1) { src = winin_; bgBase = 8; objBit = 12; fxBit = 13; }
    else if (inObjWin) { src = winout_; bgBase = 8; objBit = 12; fxBit = 13; }
    else { src = winout_; bgBase = 0; objBit = 4; fxBit = 5; }

    for (int i = 0; i < 4; i++) r.bgEnable[i] = TestBit(src, bgBase + i);
    r.objEnable = TestBit(src, objBit);
    r.effectsEnable = TestBit(src, fxBit);
    return r;
}

void Ppu::CompositeScanline(int line) {
    if (TestBit(dispcnt_, 7)) return;

    u8 mode = dispcnt_ & 0x7;
    bool bgActive[4] = { false, false, false, false };
    switch (mode) {
        case 0:
            for (int i = 0; i < 4; i++) bgActive[i] = TestBit(dispcnt_, 8 + i);
            break;
        case 1:
            bgActive[0] = TestBit(dispcnt_, 8);
            bgActive[1] = TestBit(dispcnt_, 9);
            bgActive[2] = TestBit(dispcnt_, 10);
            break;
        case 2:
            bgActive[2] = TestBit(dispcnt_, 10);
            bgActive[3] = TestBit(dispcnt_, 11);
            break;
        default:
            bgActive[2] = TestBit(dispcnt_, 10);
            break;
    }
    bool objActive = TestBit(dispcnt_, 12);
    int blendMode = (bldcnt_ >> 6) & 0x3;

    struct Candidate { int priority; int sortKey; bool isObj; int bgIndex; u16 color; };

    for (int x = 0; x < kScreenWidth; x++) {
        WindowResult win = ResolveWindow(x, line, objWindowHit_[x]);

        Candidate candidates[5];
        int n = 0;
        if (objActive && win.objEnable && objLine_[x].opaque) {
            candidates[n++] = { objLine_[x].priority, -1, true, -1, objLine_[x].color };
        }
        for (int bg = 0; bg < 4; bg++) {
            if (bgActive[bg] && win.bgEnable[bg] && bgLine_[bg][x].opaque) {
                candidates[n++] = { bgcnt_[bg] & 0x3, bg, false, bg, bgLine_[bg][x].color };
            }
        }
        for (int i = 1; i < n; i++) {
            Candidate c = candidates[i];
            int j = i - 1;
            while (j >= 0 && (candidates[j].priority > c.priority ||
                              (candidates[j].priority == c.priority && candidates[j].sortKey > c.sortKey))) {
                candidates[j + 1] = candidates[j];
                j--;
            }
            candidates[j + 1] = c;
        }

        u16 backdrop = ReadPalette(0);
        u16 topColor = (n > 0) ? candidates[0].color : backdrop;
        u16 secondColor = (n > 1) ? candidates[1].color : backdrop;
        bool topIsObjSemiTransparent = (n > 0) && candidates[0].isObj && objLine_[x].semiTransparent;

        u16 finalColor = topColor;

        auto isFirstTarget = [&](int i) {
            if (i >= n) return TestBit(bldcnt_, 5); // backdrop as 1st target
            return candidates[i].isObj ? TestBit(bldcnt_, 4) : TestBit(bldcnt_, candidates[i].bgIndex);
        };
        auto isSecondTarget = [&](int i) {
            if (i >= n) return TestBit(bldcnt_, 13); // backdrop as 2nd target
            return candidates[i].isObj ? TestBit(bldcnt_, 12) : TestBit(bldcnt_, 8 + candidates[i].bgIndex);
        };

        if (win.effectsEnable) {
            bool doAlpha = topIsObjSemiTransparent || (blendMode == 1 && isFirstTarget(0));
            if (doAlpha && (topIsObjSemiTransparent || isSecondTarget(1))) {
                int eva = std::min(16, static_cast<int>(bldalpha_ & 0x1F));
                int evb = std::min(16, static_cast<int>((bldalpha_ >> 8) & 0x1F));
                finalColor = BlendAlpha(topColor, secondColor, eva, evb);
            } else if (blendMode == 2 && isFirstTarget(0)) {
                finalColor = BlendBrighten(topColor, std::min(16, static_cast<int>(bldy_ & 0x1F)));
            } else if (blendMode == 3 && isFirstTarget(0)) {
                finalColor = BlendDarken(topColor, std::min(16, static_cast<int>(bldy_ & 0x1F)));
            }
        }

        framebuffer_[static_cast<size_t>(line) * kScreenWidth + x] = Rgb555ToArgb8888(finalColor);
    }
}

} // namespace gba
