#pragma once
#include <array>
#include "../common/types.h"
#include "../scheduler/scheduler.h"
#include "../irq/interrupt.h"

namespace gba {

class DmaController;

constexpr int kScreenWidth = 240;
constexpr int kScreenHeight = 160;

// Renders one 240x160 ARGB8888 frame at a time, scanline by scanline, driven
// entirely by scheduler events (HDraw -> HBlank -> next line -> ... ->
// VBlank -> line 0). A scanline's pixels are produced the moment its HBlank
// starts, which is what makes per-scanline raster effects (HBlank-IRQ scroll
// tricks etc.) come out correctly: the game's HBlank handler runs and
// changes registers *after* that line is already committed to the
// framebuffer, exactly like real hardware.
class Ppu {
public:
    void Init(Scheduler* scheduler, InterruptController* irq, DmaController* dma,
              u8* vram, u8* oam, u8* palette);
    void Reset();

    u16 ReadReg16(u32 offset) const;
    void WriteReg16(u32 offset, u16 value);

    const u32* FrameBuffer() const { return framebuffer_.data(); }
    bool FrameReady() const { return frameReady_; }
    void ClearFrameReady() { frameReady_ = false; }

    int CurrentLine() const { return vcount_; }

private:
    Scheduler* scheduler_ = nullptr;
    InterruptController* irq_ = nullptr;
    DmaController* dma_ = nullptr;
    u8* vram_ = nullptr;
    u8* oam_ = nullptr;
    u8* palette_ = nullptr;

    std::array<u32, kScreenWidth * kScreenHeight> framebuffer_{};
    bool frameReady_ = false;

    // --- registers ---
    u16 dispcnt_ = 0x0080; // forced blank on at boot, matches real hardware
    u16 dispstat_ = 0;
    u16 vcount_ = 0;
    std::array<u16, 4> bgcnt_{};
    std::array<u16, 4> bghofs_{};
    std::array<u16, 4> bgvofs_{};
    std::array<s16, 2> bgpa_{ 0x100, 0x100 };
    std::array<s16, 2> bgpb_{ 0, 0 };
    std::array<s16, 2> bgpc_{ 0, 0 };
    std::array<s16, 2> bgpd_{ 0x100, 0x100 };
    std::array<s32, 2> bgxRef_{ 0, 0 };   // BG2X/BG3X as written (24.8 fixed point, sign-extended)
    std::array<s32, 2> bgyRef_{ 0, 0 };
    std::array<s32, 2> bgxInternal_{ 0, 0 }; // running affine reference point, reloaded on BGxX/Y write
    std::array<s32, 2> bgyInternal_{ 0, 0 };
    u16 win0h_ = 0, win1h_ = 0, win0v_ = 0, win1v_ = 0;
    u16 winin_ = 0, winout_ = 0;
    u16 mosaic_ = 0;
    u16 bldcnt_ = 0;
    u16 bldalpha_ = 0;
    u16 bldy_ = 0;

    // --- per-scanline scratch buffers (reused every line, no per-line heap churn) ---
    struct BgPixel { u16 color; bool opaque; };
    std::array<std::array<BgPixel, kScreenWidth>, 4> bgLine_{};
    struct ObjPixel { u16 color; u8 priority; bool opaque; bool semiTransparent; };
    std::array<ObjPixel, kScreenWidth> objLine_{};
    std::array<bool, kScreenWidth> objWindowHit_{}; // set by gfxMode==2 (OBJ window) sprites; they draw no color

    void OnHBlankStart(u64 lateCycles);
    void OnScanlineStart(u64 lateCycles);

    void RenderScanline(int line);
    void RenderTextBackground(int bg, int line);
    void RenderAffineBackground(int bgIndex01, int line); // bgIndex01: 0=BG2, 1=BG3
    void RenderBitmapBackground(int line);
    void RenderSprites(int line);
    void CompositeScanline(int line);

    u16 ReadPalette(int index) const; // index: 0 = backdrop, 1..255 = BG palette, 256..511 = OBJ palette
    static u32 Rgb555ToArgb8888(u16 c);

    bool WindowEnabled() const { return TestBit(dispcnt_, 13) || TestBit(dispcnt_, 14) || TestBit(dispcnt_, 15); }
    // Returns which layers + effects are enabled at pixel (x,line) given the
    // active window configuration; when windows are off, everything is enabled.
    struct WindowResult { bool bgEnable[4]; bool objEnable; bool effectsEnable; };
    WindowResult ResolveWindow(int x, int line, bool objWindowHit) const;
};

} // namespace gba
