#pragma once
#include <vector>
#include "common/types.h"
#include "scheduler/scheduler.h"
#include "irq/interrupt.h"
#include "timers/timer.h"
#include "dma/dma.h"
#include "video/ppu.h"
#include "audio/apu.h"
#include "memory/bus.h"
#include "memory/cartridge.h"
#include "cpu/cpu.h"
#include "bios/bios_hle.h"
#include "debug/debugger.h"

namespace gba {

// Owns every subsystem and wires them together via plain pointers set up
// once in Init(). This is the only class that needs to know everyone —
// Bus/Ppu/Apu/Dma/Timer only know the neighbors they actually talk to,
// which is what keeps each of them independently followable.
class Gba {
public:
    void Init();
    bool LoadRom(std::vector<u8> romData);
    bool LoadBios(std::vector<u8> biosData);
    void Reset();

    // Runs until a full frame is produced, a breakpoint is hit, or the
    // debugger is paused — whichever comes first. Check FrameReady() /
    // debugger state afterward to see which.
    void RunFrame();
    void DebugStepOne(); // executes exactly one instruction, then re-pauses

    const u32* FrameBuffer() const { return ppu_.FrameBuffer(); }
    bool FrameReady() const { return ppu_.FrameReady(); }
    void ClearFrameReady() { ppu_.ClearFrameReady(); }

    int PullAudioSamples(s16* out, int maxFrames) { return apu_.PullSamples(out, maxFrames); }

    void SetKeyState(u16 gbaKeyMask, bool pressed) { bus_.SetKeyState(gbaKeyMask, pressed); }

    std::vector<u8>& BackupData() { return cartridge_.Backup().RawData(); }
    void LoadBackupData(const std::vector<u8>& data) { cartridge_.Backup().LoadRaw(data); }
    bool HasBackup() const { return cartridge_.Backup().Type() != BackupType::None; }

    Cpu& CpuRef() { return cpu_; }
    Bus& BusRef() { return bus_; }
    Debugger& DebuggerRef() { return debugger_; }
    const CartridgeHeader& RomHeader() const { return cartridge_.Header(); }

private:
    Scheduler scheduler_;
    InterruptController interrupt_;
    TimerController timer_;
    DmaController dma_;
    Ppu ppu_;
    Apu apu_;
    Bus bus_;
    Cpu cpu_;
    Cartridge cartridge_;
    BiosHle biosHle_;
    Debugger debugger_;

    bool halted_ = false;

    void Step();
};

} // namespace gba
