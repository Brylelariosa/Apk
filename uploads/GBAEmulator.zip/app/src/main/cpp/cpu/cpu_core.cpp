#include "cpu.h"
#include "../memory/bus.h"
#include "../bios/bios_hle.h"

namespace gba {

void Cpu::Init(Bus* bus, BiosHle* biosHle) {
    bus_ = bus;
    biosHle_ = biosHle;
    Reset();
}

void Cpu::Reset() {
    for (auto& v : r_) v = 0;
    for (auto& bank : bankedRegs_) for (auto& v : bank) v = 0;
    for (auto& s : spsr_) s = 0;
    cpsr_ = MODE_SYS;

    // Standard post-boot stack pointers (what the real BIOS sets up before
    // handing control to the cartridge) — most games never initialize these
    // themselves and rely on this being correct already.
    bankedRegs_[ModeIndex(MODE_SVC)][5] = 0x03007FE0;
    bankedRegs_[ModeIndex(MODE_IRQ)][5] = 0x03007FA0;
    bankedRegs_[ModeIndex(MODE_USR)][5] = 0x03007F00;
    r_[13] = 0x03007F00;

    FlushPipelineArm(0x08000000); // straight to the cartridge entry point (HLE skips the BIOS boot animation)
}

int Cpu::ModeIndex(u32 mode) {
    switch (mode & 0x1F) {
        case MODE_FIQ: return 1;
        case MODE_IRQ: return 2;
        case MODE_SVC: return 3;
        case MODE_ABT: return 4;
        case MODE_UND: return 5;
        default: return 0; // USR/SYS share a bank
    }
}

void Cpu::SwitchMode(u32 newMode) {
    u32 oldMode = cpsr_ & 0x1F;
    newMode &= 0x1F;
    if (oldMode == newMode) return;

    int oldIdx = ModeIndex(oldMode);
    int newIdx = ModeIndex(newMode);
    bool oldIsFiq = (oldMode == MODE_FIQ);
    bool newIsFiq = (newMode == MODE_FIQ);

    if (oldIsFiq != newIsFiq) {
        for (int i = 0; i < 5; i++) {
            if (oldIsFiq) bankedRegs_[1][i] = r_[8 + i];
            else bankedRegs_[0][i] = r_[8 + i];
        }
    }
    bankedRegs_[oldIdx][5] = r_[13];
    bankedRegs_[oldIdx][6] = r_[14];

    if (oldIsFiq != newIsFiq) {
        for (int i = 0; i < 5; i++) {
            r_[8 + i] = newIsFiq ? bankedRegs_[1][i] : bankedRegs_[0][i];
        }
    }
    r_[13] = bankedRegs_[newIdx][5];
    r_[14] = bankedRegs_[newIdx][6];
}

void Cpu::FlushPipelineArm(u32 newPc) {
    r_[15] = newPc & ~3u;
    cpsr_ &= ~Bit(CPSR_T);
}

void Cpu::FlushPipelineThumb(u32 newPc) {
    r_[15] = newPc & ~1u;
    cpsr_ |= Bit(CPSR_T);
}

void Cpu::WriteRegDest(int index, u32 value) {
    if (index == 15) {
        if (TestBit(cpsr_, CPSR_T)) FlushPipelineThumb(value);
        else FlushPipelineArm(value);
        AddCycles(2); // approximate pipeline-refill penalty
    } else {
        r_[index] = value;
    }
}

u32 Cpu::ReadRegSrc(int index) const {
    if (index != 15) return r_[index];
    return TestBit(cpsr_, CPSR_T) ? (r_[15] + 2) : (r_[15] + 4);
}

void Cpu::SetRegister(int index, u32 value) {
    if (index == 15) {
        if (TestBit(cpsr_, CPSR_T)) FlushPipelineThumb(value);
        else FlushPipelineArm(value);
    } else {
        r_[index] = value;
    }
}

void Cpu::SetCPSR(u32 value) {
    SwitchMode(value & 0x1F);
    cpsr_ = value;
}

bool Cpu::ConditionPassed(u32 cond) const {
    bool n = TestBit(cpsr_, CPSR_N), z = TestBit(cpsr_, CPSR_Z);
    bool c = TestBit(cpsr_, CPSR_C), v = TestBit(cpsr_, CPSR_V);
    switch (cond) {
        case 0x0: return z;
        case 0x1: return !z;
        case 0x2: return c;
        case 0x3: return !c;
        case 0x4: return n;
        case 0x5: return !n;
        case 0x6: return v;
        case 0x7: return !v;
        case 0x8: return c && !z;
        case 0x9: return !c || z;
        case 0xA: return n == v;
        case 0xB: return n != v;
        case 0xC: return !z && (n == v);
        case 0xD: return z || (n != v);
        case 0xE: return true;
        default: return false;
    }
}

void Cpu::EnterException(u32 mode, u32 newPc, u32 lrAdjust) {
    u32 oldCpsr = cpsr_;
    u32 returnAddr = r_[15] + lrAdjust;
    SwitchMode(mode);
    r_[14] = returnAddr;
    spsr_[ModeIndex(mode)] = oldCpsr;
    cpsr_ = (cpsr_ & ~0x3Fu) | (mode & 0x1F);
    cpsr_ |= Bit(CPSR_I);
    if (mode == MODE_FIQ) cpsr_ |= Bit(CPSR_F);
    FlushPipelineArm(newPc);
}

void Cpu::HandleIRQ() {
    if (TestBit(cpsr_, CPSR_I)) return;

    if (bus_->HasRealBios()) {
        EnterException(MODE_IRQ, 0x18, 4);
        return;
    }

    // HLE path: there's no real BIOS trampoline to run, so synthesize its
    // effect — save the registers a called C handler is free to clobber,
    // jump straight to the user's installed handler (0x03007FFC), and catch
    // its return via a sentinel PC that RunIrqEpilogue() recognizes.
    u32 returnAddr = r_[15];
    u32 oldCpsr = cpsr_;
    SwitchMode(MODE_IRQ);
    cpsr_ = (cpsr_ & ~0x3Fu) | MODE_IRQ | Bit(CPSR_I);
    spsr_[ModeIndex(MODE_IRQ)] = oldCpsr;

    r_[13] -= 24;
    u32 sp = r_[13];
    bus_->Write32(sp + 0, r_[0]);
    bus_->Write32(sp + 4, r_[1]);
    bus_->Write32(sp + 8, r_[2]);
    bus_->Write32(sp + 12, r_[3]);
    bus_->Write32(sp + 16, r_[12]);
    bus_->Write32(sp + 20, r_[14]);

    irqSavedSp_ = sp;
    irqReturnAddr_ = returnAddr;
    irqSavedCpsr_ = oldCpsr;
    r_[14] = kIrqReturnTrap;

    u32 handlerAddr = bus_->Read32(0x03007FFC);
    FlushPipelineArm(handlerAddr);
}

void Cpu::RunIrqEpilogue() {
    u32 sp = irqSavedSp_;
    r_[0] = bus_->Read32(sp + 0);
    r_[1] = bus_->Read32(sp + 4);
    r_[2] = bus_->Read32(sp + 8);
    r_[3] = bus_->Read32(sp + 12);
    r_[12] = bus_->Read32(sp + 16);
    r_[13] += 24;

    u32 newMode = irqSavedCpsr_ & 0x1F;
    SwitchMode(newMode);
    cpsr_ = irqSavedCpsr_;

    if (TestBit(cpsr_, CPSR_T)) FlushPipelineThumb(irqReturnAddr_);
    else FlushPipelineArm(irqReturnAddr_);
}

u32 Cpu::Shifter(u32 value, int type, u32 amount, bool immediateShift, bool& carryOut) {
    carryOut = TestBit(cpsr_, CPSR_C);
    switch (type) {
        case 0: // LSL
            if (amount == 0) return value;
            if (amount < 32) { carryOut = TestBit(value, static_cast<int>(32 - amount)); return value << amount; }
            if (amount == 32) { carryOut = TestBit(value, 0); return 0; }
            carryOut = false; return 0;
        case 1: // LSR
            if (amount == 0) {
                if (!immediateShift) return value;
                carryOut = TestBit(value, 31); return 0; // LSR#0 encodes LSR#32
            }
            if (amount < 32) { carryOut = TestBit(value, static_cast<int>(amount) - 1); return value >> amount; }
            if (amount == 32) { carryOut = TestBit(value, 31); return 0; }
            carryOut = false; return 0;
        case 2: { // ASR
            if (amount == 0 && !immediateShift) return value;
            u32 amt = (amount == 0) ? 32 : amount; // ASR#0 encodes ASR#32
            if (amt < 32) { carryOut = TestBit(value, static_cast<int>(amt) - 1); return static_cast<u32>(static_cast<s32>(value) >> amt); }
            bool neg = TestBit(value, 31);
            carryOut = neg;
            return neg ? 0xFFFFFFFFu : 0u;
        }
        case 3: // ROR / RRX
            if (amount == 0) {
                if (!immediateShift) return value;
                bool oldCarry = TestBit(cpsr_, CPSR_C); // RRX
                carryOut = TestBit(value, 0);
                return (value >> 1) | (oldCarry ? 0x80000000u : 0u);
            } else {
                u32 amt = amount & 31u;
                if (amt == 0) { carryOut = TestBit(value, 31); return value; }
                carryOut = TestBit(value, static_cast<int>(amt) - 1);
                return RotateRight32(value, amt);
            }
    }
    return value;
}

u32 Cpu::AluAdd(u32 a, u32 b, u32 carryIn, bool setFlags) {
    u64 result64 = static_cast<u64>(a) + static_cast<u64>(b) + carryIn;
    u32 result = static_cast<u32>(result64);
    if (setFlags) {
        bool carry = result64 > 0xFFFFFFFFull;
        bool overflow = ((~(a ^ b)) & (a ^ result) & 0x80000000u) != 0;
        cpsr_ = (cpsr_ & ~0xF0000000u)
              | (TestBit(result, 31) ? Bit(CPSR_N) : 0)
              | (result == 0 ? Bit(CPSR_Z) : 0)
              | (carry ? Bit(CPSR_C) : 0)
              | (overflow ? Bit(CPSR_V) : 0);
    }
    return result;
}

u32 Cpu::AluSub(u32 a, u32 b, u32 carryIn, bool setFlags) {
    u64 result64 = static_cast<u64>(a) + static_cast<u64>(~b) + carryIn;
    u32 result = static_cast<u32>(result64);
    if (setFlags) {
        bool carry = result64 > 0xFFFFFFFFull;
        bool overflow = ((a ^ b) & (a ^ result) & 0x80000000u) != 0;
        cpsr_ = (cpsr_ & ~0xF0000000u)
              | (TestBit(result, 31) ? Bit(CPSR_N) : 0)
              | (result == 0 ? Bit(CPSR_Z) : 0)
              | (carry ? Bit(CPSR_C) : 0)
              | (overflow ? Bit(CPSR_V) : 0);
    }
    return result;
}

void Cpu::SetLogicalFlags(u32 result, bool carry) {
    cpsr_ = (cpsr_ & ~0xE0000000u)
          | (TestBit(result, 31) ? Bit(CPSR_N) : 0)
          | (result == 0 ? Bit(CPSR_Z) : 0)
          | (carry ? Bit(CPSR_C) : 0);
}

u32 Cpu::Step() {
    cycles_ = 0;

    if (r_[15] == kIrqReturnTrap) {
        RunIrqEpilogue();
        return 3;
    }

    if (TestBit(cpsr_, CPSR_T)) {
        u32 pc = r_[15] & ~1u;
        u16 instr = bus_->Read16(pc);
        AddCycles(static_cast<u32>(bus_->AccessCycles(pc, 2)));
        r_[15] = pc + 2;
        ExecuteThumb(instr);
    } else {
        u32 pc = r_[15] & ~3u;
        u32 instr = bus_->Read32(pc);
        AddCycles(static_cast<u32>(bus_->AccessCycles(pc, 4)));
        r_[15] = pc + 4;
        ExecuteArm(instr);
    }
    return cycles_;
}

} // namespace gba
