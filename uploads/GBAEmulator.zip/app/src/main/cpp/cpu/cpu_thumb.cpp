#include "cpu.h"
#include "../memory/bus.h"
#include "../bios/bios_hle.h"

namespace gba {

void Cpu::ExecuteThumb(u16 instr) {
    u16 top3 = (instr >> 13) & 0x7;
    switch (top3) {
        case 0x0:
            if (((instr >> 11) & 0x3) == 0x3) ThumbAddSubtract(instr);
            else ThumbMoveShifted(instr);
            return;
        case 0x1:
            ThumbMovCmpAddSubImm(instr);
            return;
        case 0x2: {
            u16 bits15_10 = (instr >> 10) & 0x3F;
            if (bits15_10 == 0x10) { ThumbAluOp(instr); return; }       // 010000
            if (bits15_10 == 0x11) { ThumbHiRegBx(instr); return; }     // 010001
            u16 bits15_11 = (instr >> 11) & 0x1F;
            if (bits15_11 == 0x09) { ThumbPcRelativeLoad(instr); return; } // 01001
            if (TestBit(instr, 9)) ThumbLoadStoreSignExt(instr);
            else ThumbLoadStoreRegOffset(instr);
            return;
        }
        case 0x3:
            ThumbLoadStoreImmOffset(instr);
            return;
        case 0x4:
            if (!TestBit(instr, 12)) ThumbLoadStoreHalfword(instr);
            else ThumbSpRelativeLoadStore(instr);
            return;
        case 0x5:
            if (!TestBit(instr, 12)) { ThumbLoadAddress(instr); return; }
            if (((instr >> 8) & 0xFF) == 0xB0) { ThumbAddOffsetToSp(instr); return; }
            if (((instr >> 9) & 0x3) == 0x2) { ThumbPushPop(instr); return; }
            return; // unused encoding
        case 0x6:
            if (!TestBit(instr, 12)) { ThumbMultipleLoadStore(instr); return; }
            if (((instr >> 8) & 0xFF) == 0xDF) { ThumbSoftwareInterrupt(instr); return; }
            ThumbConditionalBranch(instr);
            return;
        case 0x7:
            if (TestBit(instr, 12)) { ThumbLongBranchLink(instr); return; }
            if (!TestBit(instr, 11)) { ThumbUnconditionalBranch(instr); return; }
            return; // unused encoding
        default:
            return;
    }
}

void Cpu::ThumbMoveShifted(u16 instr) {
    u32 op = (instr >> 11) & 0x3;
    u32 imm5 = (instr >> 6) & 0x1F;
    u32 rs = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    bool carry;
    u32 result = Shifter(r_[rs], static_cast<int>(op), imm5, true, carry);
    r_[rd] = result;
    SetLogicalFlags(result, carry);
    AddCycles(1);
}

void Cpu::ThumbAddSubtract(u16 instr) {
    bool immediateFlag = TestBit(instr, 10);
    bool subtract = TestBit(instr, 9);
    u32 rnOrImm = (instr >> 6) & 0x7;
    u32 rs = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 operand = immediateFlag ? rnOrImm : r_[rnOrImm];
    u32 result = subtract ? AluSub(r_[rs], operand, 1, true) : AluAdd(r_[rs], operand, 0, true);
    r_[rd] = result;
    AddCycles(1);
}

void Cpu::ThumbMovCmpAddSubImm(u16 instr) {
    u32 op = (instr >> 11) & 0x3;
    u32 rd = (instr >> 8) & 0x7;
    u32 imm = instr & 0xFF;
    switch (op) {
        case 0: r_[rd] = imm; SetLogicalFlags(imm, TestBit(cpsr_, CPSR_C)); break;
        case 1: AluSub(r_[rd], imm, 1, true); break;
        case 2: r_[rd] = AluAdd(r_[rd], imm, 0, true); break;
        case 3: r_[rd] = AluSub(r_[rd], imm, 1, true); break;
        default: break;
    }
    AddCycles(1);
}

void Cpu::ThumbAluOp(u16 instr) {
    u32 op = (instr >> 6) & 0xF;
    u32 rs = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 rdVal = r_[rd];
    u32 rsVal = r_[rs];
    bool carry;
    u32 result = 0;
    bool writeResult = true;

    switch (op) {
        case 0x0: result = rdVal & rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); break;
        case 0x1: result = rdVal ^ rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); break;
        case 0x2: result = Shifter(rdVal, 0, rsVal & 0xFF, false, carry); SetLogicalFlags(result, carry); AddCycles(1); break;
        case 0x3: result = Shifter(rdVal, 1, rsVal & 0xFF, false, carry); SetLogicalFlags(result, carry); AddCycles(1); break;
        case 0x4: result = Shifter(rdVal, 2, rsVal & 0xFF, false, carry); SetLogicalFlags(result, carry); AddCycles(1); break;
        case 0x5: result = AluAdd(rdVal, rsVal, TestBit(cpsr_, CPSR_C) ? 1u : 0u, true); break;
        case 0x6: result = AluSub(rdVal, rsVal, TestBit(cpsr_, CPSR_C) ? 1u : 0u, true); break;
        case 0x7: result = Shifter(rdVal, 3, rsVal & 0xFF, false, carry); SetLogicalFlags(result, carry); AddCycles(1); break;
        case 0x8: result = rdVal & rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); writeResult = false; break;
        case 0x9: result = AluSub(0, rsVal, 1, true); break;
        case 0xA: AluSub(rdVal, rsVal, 1, true); writeResult = false; break;
        case 0xB: AluAdd(rdVal, rsVal, 0, true); writeResult = false; break;
        case 0xC: result = rdVal | rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); break;
        case 0xD: result = rdVal * rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); AddCycles(2); break;
        case 0xE: result = rdVal & ~rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); break;
        case 0xF: result = ~rsVal; SetLogicalFlags(result, TestBit(cpsr_, CPSR_C)); break;
        default: break;
    }
    if (writeResult) r_[rd] = result;
    AddCycles(1);
}

void Cpu::ThumbHiRegBx(u16 instr) {
    u32 op = (instr >> 8) & 0x3;
    bool h1 = TestBit(instr, 7);
    bool h2 = TestBit(instr, 6);
    u32 rs = ((instr >> 3) & 0x7) + (h2 ? 8u : 0u);
    u32 rd = (instr & 0x7) + (h1 ? 8u : 0u);
    u32 rsVal = ReadRegSrc(static_cast<int>(rs));

    switch (op) {
        case 0: { u32 result = ReadRegSrc(static_cast<int>(rd)) + rsVal; WriteRegDest(static_cast<int>(rd), result); break; }
        case 1: AluSub(ReadRegSrc(static_cast<int>(rd)), rsVal, 1, true); break;
        case 2: WriteRegDest(static_cast<int>(rd), rsVal); break;
        case 3:
            if (rsVal & 1) FlushPipelineThumb(rsVal);
            else FlushPipelineArm(rsVal);
            break;
        default: break;
    }
    AddCycles((op == 3 || rd == 15) ? 2u : 1u);
}

void Cpu::ThumbPcRelativeLoad(u16 instr) {
    u32 rd = (instr >> 8) & 0x7;
    u32 imm = (instr & 0xFF) * 4;
    u32 addr = (ReadRegSrc(15) & ~2u) + imm;
    r_[rd] = bus_->Read32(addr);
    AddCycles(1);
}

void Cpu::ThumbLoadStoreRegOffset(u16 instr) {
    bool loadBit = TestBit(instr, 11);
    bool byteBit = TestBit(instr, 10);
    u32 ro = (instr >> 6) & 0x7;
    u32 rb = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 addr = r_[rb] + r_[ro];
    if (loadBit) {
        r_[rd] = byteBit ? bus_->Read8(addr) : RotateRight32(bus_->Read32(addr & ~3u), (addr & 3) * 8);
    } else {
        if (byteBit) bus_->Write8(addr, static_cast<u8>(r_[rd]));
        else bus_->Write32(addr & ~3u, r_[rd]);
    }
    AddCycles(1);
}

void Cpu::ThumbLoadStoreSignExt(u16 instr) {
    u32 hBit = (instr >> 11) & 0x1;
    u32 sBit = (instr >> 10) & 0x1;
    u32 ro = (instr >> 6) & 0x7;
    u32 rb = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 addr = r_[rb] + r_[ro];
    u32 mode = (sBit << 1) | hBit;

    switch (mode) {
        case 0: bus_->Write16(addr & ~1u, static_cast<u16>(r_[rd])); break;
        case 1: r_[rd] = SignExtend(bus_->Read8(addr), 8); break;
        case 2: { u16 h = bus_->Read16(addr & ~1u); r_[rd] = RotateRight32(h, (addr & 1) * 8); break; }
        case 3:
            if (addr & 1) r_[rd] = SignExtend(bus_->Read8(addr), 8);
            else r_[rd] = SignExtend(bus_->Read16(addr), 16);
            break;
        default: break;
    }
    AddCycles(1);
}

void Cpu::ThumbLoadStoreImmOffset(u16 instr) {
    bool byteBit = TestBit(instr, 12);
    bool loadBit = TestBit(instr, 11);
    u32 imm5 = (instr >> 6) & 0x1F;
    u32 rb = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 offset = byteBit ? imm5 : (imm5 * 4);
    u32 addr = r_[rb] + offset;
    if (loadBit) {
        r_[rd] = byteBit ? bus_->Read8(addr) : RotateRight32(bus_->Read32(addr & ~3u), (addr & 3) * 8);
    } else {
        if (byteBit) bus_->Write8(addr, static_cast<u8>(r_[rd]));
        else bus_->Write32(addr & ~3u, r_[rd]);
    }
    AddCycles(1);
}

void Cpu::ThumbLoadStoreHalfword(u16 instr) {
    bool loadBit = TestBit(instr, 11);
    u32 imm5 = (instr >> 6) & 0x1F;
    u32 rb = (instr >> 3) & 0x7;
    u32 rd = instr & 0x7;
    u32 addr = r_[rb] + imm5 * 2;
    if (loadBit) { u16 h = bus_->Read16(addr & ~1u); r_[rd] = RotateRight32(h, (addr & 1) * 8); }
    else bus_->Write16(addr & ~1u, static_cast<u16>(r_[rd]));
    AddCycles(1);
}

void Cpu::ThumbSpRelativeLoadStore(u16 instr) {
    bool loadBit = TestBit(instr, 11);
    u32 rd = (instr >> 8) & 0x7;
    u32 imm = (instr & 0xFF) * 4;
    u32 addr = r_[13] + imm;
    if (loadBit) r_[rd] = RotateRight32(bus_->Read32(addr & ~3u), (addr & 3) * 8);
    else bus_->Write32(addr & ~3u, r_[rd]);
    AddCycles(1);
}

void Cpu::ThumbLoadAddress(u16 instr) {
    bool spBit = TestBit(instr, 11);
    u32 rd = (instr >> 8) & 0x7;
    u32 imm = (instr & 0xFF) * 4;
    u32 base = spBit ? r_[13] : (ReadRegSrc(15) & ~2u);
    r_[rd] = base + imm;
    AddCycles(1);
}

void Cpu::ThumbAddOffsetToSp(u16 instr) {
    bool negative = TestBit(instr, 7);
    u32 imm = (instr & 0x7F) * 4;
    r_[13] = negative ? (r_[13] - imm) : (r_[13] + imm);
    AddCycles(1);
}

void Cpu::ThumbPushPop(u16 instr) {
    bool loadBit = TestBit(instr, 11);
    bool rBit = TestBit(instr, 8);
    u32 rlist = instr & 0xFF;

    int count = 0;
    for (int i = 0; i < 8; i++) if (TestBit(rlist, i)) count++;
    if (rBit) count++;
    if (count == 0) { AddCycles(1); return; }

    if (loadBit) {
        u32 addr = r_[13];
        for (int i = 0; i < 8; i++) {
            if (TestBit(rlist, i)) { r_[i] = bus_->Read32(addr & ~3u); addr += 4; }
        }
        if (rBit) { u32 value = bus_->Read32(addr & ~3u); addr += 4; FlushPipelineThumb(value); }
        r_[13] = addr;
    } else {
        u32 addr = r_[13] - static_cast<u32>(count) * 4;
        r_[13] = addr;
        for (int i = 0; i < 8; i++) {
            if (TestBit(rlist, i)) { bus_->Write32(addr, r_[i]); addr += 4; }
        }
        if (rBit) bus_->Write32(addr, r_[14]);
    }
    AddCycles(static_cast<u32>(count));
}

void Cpu::ThumbMultipleLoadStore(u16 instr) {
    bool loadBit = TestBit(instr, 11);
    u32 rb = (instr >> 8) & 0x7;
    u32 rlist = instr & 0xFF;

    int count = 0;
    for (int i = 0; i < 8; i++) if (TestBit(rlist, i)) count++;
    if (count == 0) { AddCycles(1); return; }

    u32 addr = r_[rb];
    for (int i = 0; i < 8; i++) {
        if (!TestBit(rlist, i)) continue;
        if (loadBit) r_[i] = bus_->Read32(addr & ~3u);
        else bus_->Write32(addr & ~3u, r_[i]);
        addr += 4;
    }
    if (!(loadBit && TestBit(rlist, rb))) r_[rb] = addr;
    AddCycles(static_cast<u32>(count));
}

void Cpu::ThumbConditionalBranch(u16 instr) {
    u32 cond = (instr >> 8) & 0xF;
    if (!ConditionPassed(cond)) return;
    s32 offset = static_cast<s32>(SignExtend(instr & 0xFF, 8)) * 2;
    u32 target = static_cast<u32>(static_cast<s32>(ReadRegSrc(15)) + offset);
    FlushPipelineThumb(target);
    AddCycles(2);
}

void Cpu::ThumbSoftwareInterrupt(u16 instr) {
    if (bus_->HasRealBios()) {
        EnterException(MODE_SVC, 0x08, 0);
        return;
    }
    u8 comment = static_cast<u8>(instr & 0xFF);
    if (biosHle_) biosHle_->HandleSwi(comment, *this, *bus_);
    AddCycles(2);
}

void Cpu::ThumbUnconditionalBranch(u16 instr) {
    s32 offset = static_cast<s32>(SignExtend(instr & 0x7FF, 11)) * 2;
    u32 target = static_cast<u32>(static_cast<s32>(ReadRegSrc(15)) + offset);
    FlushPipelineThumb(target);
    AddCycles(2);
}

void Cpu::ThumbLongBranchLink(u16 instr) {
    bool low = TestBit(instr, 11);
    u32 offset11 = instr & 0x7FF;
    if (!low) {
        s32 signedHigh = static_cast<s32>(SignExtend(offset11, 11)) << 12;
        r_[14] = static_cast<u32>(static_cast<s32>(ReadRegSrc(15)) + signedHigh);
    } else {
        u32 target = r_[14] + (offset11 << 1);
        u32 returnAddr = r_[15] | 1u;
        r_[14] = returnAddr;
        FlushPipelineThumb(target);
    }
    AddCycles(low ? 2u : 1u);
}

} // namespace gba
