#include "cpu.h"
#include "../memory/bus.h"
#include "../bios/bios_hle.h"

namespace gba {

void Cpu::ExecuteArm(u32 instr) {
    u32 cond = instr >> 28;
    if (cond != 0xE && !ConditionPassed(cond)) return;

    if ((instr & 0x0FFFFFF0) == 0x012FFF10) { ArmBranchExchange(instr); return; }

    u32 bits27_25 = (instr >> 25) & 0x7;

    if (bits27_25 == 0x0 || bits27_25 == 0x1) {
        bool immediateOperand2 = TestBit(instr, 25);
        if (!immediateOperand2 && TestBit(instr, 4) && TestBit(instr, 7)) {
            u32 bits7_4 = (instr >> 4) & 0xF;
            u32 bits24_23 = (instr >> 23) & 0x3;
            if (bits7_4 == 0x9) {
                if (bits24_23 == 0x0) { ArmMultiply(instr); return; }
                if (bits24_23 == 0x1) { ArmMultiplyLong(instr); return; }
                if (TestBit(instr, 24) && !TestBit(instr, 23)) { ArmSingleDataSwap(instr); return; }
            } else if (bits7_4 == 0xB || bits7_4 == 0xD || bits7_4 == 0xF) {
                ArmHalfwordTransfer(instr);
                return;
            }
        }
        u32 opcode = (instr >> 21) & 0xF;
        bool sBit = TestBit(instr, 20);
        if (!sBit && opcode >= 0x8 && opcode <= 0xB) { ArmPsrTransfer(instr); return; }
        ArmDataProcessing(instr);
        return;
    }

    switch (bits27_25) {
        case 0x2:
            ArmSingleDataTransfer(instr);
            return;
        case 0x3:
            if (TestBit(instr, 4)) { ArmUndefined(instr); return; }
            ArmSingleDataTransfer(instr);
            return;
        case 0x4:
            ArmBlockDataTransfer(instr);
            return;
        case 0x5:
            ArmBranch(instr);
            return;
        case 0x6:
            ArmUndefined(instr); // coprocessor data transfer — unused on GBA
            return;
        case 0x7:
            if (TestBit(instr, 24)) { ArmSoftwareInterrupt(instr); return; }
            ArmUndefined(instr); // coprocessor data op / register transfer — unused on GBA
            return;
        default:
            return;
    }
}

void Cpu::ArmDataProcessing(u32 instr) {
    u32 opcode = (instr >> 21) & 0xF;
    bool immediateOp2 = TestBit(instr, 25);
    bool sBit = TestBit(instr, 20);
    u32 rn = (instr >> 16) & 0xF;
    u32 rd = (instr >> 12) & 0xF;

    u32 op2;
    bool shifterCarry;
    if (immediateOp2) {
        u32 imm = instr & 0xFF;
        u32 rotate = ((instr >> 8) & 0xF) * 2;
        op2 = RotateRight32(imm, rotate);
        shifterCarry = (rotate == 0) ? TestBit(cpsr_, CPSR_C) : TestBit(op2, 31);
    } else {
        u32 rm = instr & 0xF;
        u32 shiftType = (instr >> 5) & 0x3;
        bool regShift = TestBit(instr, 4);
        u32 amount;
        bool immediateShift;
        if (regShift) {
            u32 rs = (instr >> 8) & 0xF;
            amount = ReadRegSrc(static_cast<int>(rs)) & 0xFF;
            immediateShift = false;
        } else {
            amount = (instr >> 7) & 0x1F;
            immediateShift = true;
        }
        u32 rmVal = ReadRegSrc(static_cast<int>(rm));
        op2 = Shifter(rmVal, static_cast<int>(shiftType), amount, immediateShift, shifterCarry);
    }

    u32 rnVal = ReadRegSrc(static_cast<int>(rn));
    u32 result = 0;
    bool isLogical = false;
    bool writeResult = true;

    switch (opcode) {
        case 0x0: result = rnVal & op2; isLogical = true; break;               // AND
        case 0x1: result = rnVal ^ op2; isLogical = true; break;               // EOR
        case 0x2: result = AluSub(rnVal, op2, 1, sBit); break;                 // SUB
        case 0x3: result = AluSub(op2, rnVal, 1, sBit); break;                 // RSB
        case 0x4: result = AluAdd(rnVal, op2, 0, sBit); break;                 // ADD
        case 0x5: result = AluAdd(rnVal, op2, TestBit(cpsr_, CPSR_C) ? 1u : 0u, sBit); break; // ADC
        case 0x6: result = AluSub(rnVal, op2, TestBit(cpsr_, CPSR_C) ? 1u : 0u, sBit); break; // SBC
        case 0x7: result = AluSub(op2, rnVal, TestBit(cpsr_, CPSR_C) ? 1u : 0u, sBit); break; // RSC
        case 0x8: result = rnVal & op2; SetLogicalFlags(result, shifterCarry); writeResult = false; break; // TST
        case 0x9: result = rnVal ^ op2; SetLogicalFlags(result, shifterCarry); writeResult = false; break; // TEQ
        case 0xA: AluSub(rnVal, op2, 1, true); writeResult = false; break;     // CMP
        case 0xB: AluAdd(rnVal, op2, 0, true); writeResult = false; break;     // CMN
        case 0xC: result = rnVal | op2; isLogical = true; break;               // ORR
        case 0xD: result = op2; isLogical = true; break;                       // MOV
        case 0xE: result = rnVal & ~op2; isLogical = true; break;              // BIC
        case 0xF: result = ~op2; isLogical = true; break;                      // MVN
        default: break;
    }

    if (isLogical && sBit) SetLogicalFlags(result, shifterCarry);

    if (writeResult) {
        if (rd == 15 && sBit && ModeIndex(cpsr_ & 0x1F) != 0) {
            u32 savedSpsr = spsr_[ModeIndex(cpsr_ & 0x1F)];
            WriteRegDest(15, result);
            SetCPSR(savedSpsr);
            return;
        }
        WriteRegDest(static_cast<int>(rd), result);
    }
}

void Cpu::ArmMultiply(u32 instr) {
    u32 rd = (instr >> 16) & 0xF;
    u32 rn = (instr >> 12) & 0xF;
    u32 rs = (instr >> 8) & 0xF;
    u32 rm = instr & 0xF;
    bool accumulate = TestBit(instr, 21);
    bool sBit = TestBit(instr, 20);

    u32 result = r_[rm] * r_[rs];
    if (accumulate) result += r_[rn];
    r_[rd] = result; // Rd=R15 is UNPREDICTABLE per spec; not routed through WriteRegDest
    if (sBit) SetLogicalFlags(result, TestBit(cpsr_, CPSR_C));
    AddCycles(accumulate ? 2u : 1u);
}

void Cpu::ArmMultiplyLong(u32 instr) {
    u32 rdHi = (instr >> 16) & 0xF;
    u32 rdLo = (instr >> 12) & 0xF;
    u32 rs = (instr >> 8) & 0xF;
    u32 rm = instr & 0xF;
    bool signedMul = TestBit(instr, 22);
    bool accumulate = TestBit(instr, 21);
    bool sBit = TestBit(instr, 20);

    u64 result;
    if (signedMul) {
        s64 a = static_cast<s64>(static_cast<s32>(r_[rm]));
        s64 b = static_cast<s64>(static_cast<s32>(r_[rs]));
        result = static_cast<u64>(a * b);
    } else {
        result = static_cast<u64>(r_[rm]) * static_cast<u64>(r_[rs]);
    }
    if (accumulate) {
        u64 acc = (static_cast<u64>(r_[rdHi]) << 32) | r_[rdLo];
        result += acc;
    }
    r_[rdLo] = static_cast<u32>(result);
    r_[rdHi] = static_cast<u32>(result >> 32);
    if (sBit) {
        cpsr_ = (cpsr_ & ~0xC0000000u)
              | (TestBit(r_[rdHi], 31) ? Bit(CPSR_N) : 0)
              | (result == 0 ? Bit(CPSR_Z) : 0);
    }
    AddCycles(accumulate ? 3u : 2u);
}

void Cpu::ArmSingleDataSwap(u32 instr) {
    u32 rn = (instr >> 16) & 0xF;
    u32 rd = (instr >> 12) & 0xF;
    u32 rm = instr & 0xF;
    bool byteSwap = TestBit(instr, 22);
    u32 addr = r_[rn];
    if (byteSwap) {
        u8 old = bus_->Read8(addr);
        bus_->Write8(addr, static_cast<u8>(r_[rm]));
        r_[rd] = old;
    } else {
        u32 old = bus_->Read32(addr & ~3u);
        old = RotateRight32(old, (addr & 3) * 8);
        bus_->Write32(addr & ~3u, r_[rm]);
        r_[rd] = old;
    }
    AddCycles(1);
}

void Cpu::ArmBranchExchange(u32 instr) {
    u32 rm = instr & 0xF;
    u32 target = ReadRegSrc(static_cast<int>(rm));
    if (target & 1) FlushPipelineThumb(target);
    else FlushPipelineArm(target);
    AddCycles(2);
}

void Cpu::ArmHalfwordTransfer(u32 instr) {
    u32 rn = (instr >> 16) & 0xF;
    u32 rd = (instr >> 12) & 0xF;
    bool preIndex = TestBit(instr, 24);
    bool up = TestBit(instr, 23);
    bool immediateOffset = TestBit(instr, 22);
    bool writeBack = TestBit(instr, 21);
    bool isLoad = TestBit(instr, 20);
    u32 sh = (instr >> 5) & 0x3;

    u32 offset = immediateOffset ? (((instr >> 4) & 0xF0) | (instr & 0xF)) : r_[instr & 0xF];

    u32 baseAddr = r_[rn];
    u32 addr = preIndex ? (up ? baseAddr + offset : baseAddr - offset) : baseAddr;

    if (isLoad) {
        u32 value = 0;
        switch (sh) {
            case 1: { u16 h = bus_->Read16(addr & ~1u); value = RotateRight32(h, (addr & 1) * 8); break; }
            case 2: { u8 b = bus_->Read8(addr); value = SignExtend(b, 8); break; }
            case 3: {
                if (addr & 1) { u8 b = bus_->Read8(addr); value = SignExtend(b, 8); }
                else { u16 h = bus_->Read16(addr); value = SignExtend(h, 16); }
                break;
            }
            default: break;
        }
        u32 postAddr = up ? baseAddr + offset : baseAddr - offset;
        if (!preIndex) r_[rn] = postAddr;
        else if (writeBack) r_[rn] = addr;
        WriteRegDest(static_cast<int>(rd), value);
    } else {
        u32 value = (rd == 15) ? (r_[15] + 4) : r_[rd];
        bus_->Write16(addr & ~1u, static_cast<u16>(value));
        u32 postAddr = up ? baseAddr + offset : baseAddr - offset;
        if (!preIndex) r_[rn] = postAddr;
        else if (writeBack) r_[rn] = addr;
    }
    AddCycles(1);
}

void Cpu::ArmSingleDataTransfer(u32 instr) {
    bool registerOffset = TestBit(instr, 25);
    bool preIndex = TestBit(instr, 24);
    bool up = TestBit(instr, 23);
    bool byteTransfer = TestBit(instr, 22);
    bool writeBack = TestBit(instr, 21);
    bool isLoad = TestBit(instr, 20);
    u32 rn = (instr >> 16) & 0xF;
    u32 rd = (instr >> 12) & 0xF;

    u32 offset;
    if (registerOffset) {
        u32 rm = instr & 0xF;
        u32 shiftType = (instr >> 5) & 0x3;
        u32 amount = (instr >> 7) & 0x1F;
        bool dummyCarry;
        offset = Shifter(r_[rm], static_cast<int>(shiftType), amount, true, dummyCarry);
    } else {
        offset = instr & 0xFFF;
    }

    u32 baseAddr = r_[rn];
    u32 addr = preIndex ? (up ? baseAddr + offset : baseAddr - offset) : baseAddr;

    if (isLoad) {
        u32 value;
        if (byteTransfer) value = bus_->Read8(addr);
        else { u32 w = bus_->Read32(addr & ~3u); value = RotateRight32(w, (addr & 3) * 8); }
        u32 postAddr = up ? baseAddr + offset : baseAddr - offset;
        if (!preIndex) r_[rn] = postAddr;
        else if (writeBack) r_[rn] = addr;
        WriteRegDest(static_cast<int>(rd), value);
    } else {
        u32 value = (rd == 15) ? (r_[15] + 4) : r_[rd];
        if (byteTransfer) bus_->Write8(addr, static_cast<u8>(value));
        else bus_->Write32(addr & ~3u, value);
        u32 postAddr = up ? baseAddr + offset : baseAddr - offset;
        if (!preIndex) r_[rn] = postAddr;
        else if (writeBack) r_[rn] = addr;
    }
    AddCycles(isLoad ? 1u : 0u);
}

void Cpu::ArmUndefined(u32) {
    EnterException(MODE_UND, 0x04, 0);
    AddCycles(2);
}

void Cpu::ArmBlockDataTransfer(u32 instr) {
    u32 rn = (instr >> 16) & 0xF;
    bool preIndex = TestBit(instr, 24);
    bool up = TestBit(instr, 23);
    bool sBitPsr = TestBit(instr, 22);
    bool writeBack = TestBit(instr, 21);
    bool isLoad = TestBit(instr, 20);
    u32 regList = instr & 0xFFFF;

    int count = 0;
    for (int i = 0; i < 16; i++) if (TestBit(regList, i)) count++;
    if (count == 0) { AddCycles(1); return; } // documented edge case, rare enough to just skip safely

    u32 baseAddr = r_[rn];
    u32 cur = up ? baseAddr : (baseAddr - static_cast<u32>(count) * 4u);
    if (up && preIndex) cur += 4;
    if (!up && !preIndex) cur += 4;

    bool userBankTransfer = sBitPsr && !(isLoad && TestBit(regList, 15));
    u32 savedMode = cpsr_ & 0x1F;
    if (userBankTransfer) SwitchMode(MODE_USR);

    for (int i = 0; i < 16; i++) {
        if (!TestBit(regList, i)) continue;
        if (isLoad) {
            u32 value = bus_->Read32(cur & ~3u);
            if (i == 15) {
                WriteRegDest(15, value);
                if (sBitPsr && ModeIndex(savedMode) != 0) SetCPSR(spsr_[ModeIndex(savedMode)]);
            } else {
                r_[i] = value;
            }
        } else {
            u32 value = (i == 15) ? (r_[15] + 4) : r_[i];
            bus_->Write32(cur & ~3u, value);
        }
        cur += 4;
    }

    if (userBankTransfer) SwitchMode(savedMode);

    if (writeBack) {
        u32 finalAddr = up ? baseAddr + static_cast<u32>(count) * 4u : baseAddr - static_cast<u32>(count) * 4u;
        if (!(isLoad && TestBit(regList, rn))) r_[rn] = finalAddr;
    }

    AddCycles(static_cast<u32>(count));
}

void Cpu::ArmBranch(u32 instr) {
    bool link = TestBit(instr, 24);
    u32 offset = instr & 0xFFFFFF;
    s32 signedOffset = static_cast<s32>(SignExtend(offset, 24)) * 4;
    u32 target = static_cast<u32>(static_cast<s32>(r_[15] + 4) + signedOffset);
    if (link) r_[14] = r_[15];
    FlushPipelineArm(target);
    AddCycles(2);
}

void Cpu::ArmSoftwareInterrupt(u32 instr) {
    if (bus_->HasRealBios()) {
        EnterException(MODE_SVC, 0x08, 0);
        return;
    }
    u8 comment = static_cast<u8>((instr >> 16) & 0xFF);
    if (biosHle_) biosHle_->HandleSwi(comment, *this, *bus_);
    AddCycles(2);
}

void Cpu::ArmPsrTransfer(u32 instr) {
    bool useSpsr = TestBit(instr, 22);
    bool isMsr = TestBit(instr, 21);

    if (!isMsr) {
        u32 rd = (instr >> 12) & 0xF;
        u32 value = cpsr_;
        if (useSpsr) {
            int idx = ModeIndex(cpsr_ & 0x1F);
            if (idx != 0) value = spsr_[idx];
        }
        WriteRegDest(static_cast<int>(rd), value);
        AddCycles(1);
        return;
    }

    bool immediateOperand = TestBit(instr, 25);
    u32 operand;
    if (immediateOperand) {
        u32 imm = instr & 0xFF;
        u32 rotate = ((instr >> 8) & 0xF) * 2;
        operand = RotateRight32(imm, rotate);
    } else {
        operand = ReadRegSrc(static_cast<int>(instr & 0xF));
    }

    bool writeFlags = TestBit(instr, 19);
    bool writeControl = TestBit(instr, 16);
    u32 mask = 0;
    if (writeFlags) mask |= 0xFF000000u;
    if (writeControl) mask |= 0x000000FFu;

    bool privileged = (cpsr_ & 0x1F) != MODE_USR;
    if (!privileged) mask &= 0xFF000000u;

    if (useSpsr) {
        int idx = ModeIndex(cpsr_ & 0x1F);
        if (idx != 0) spsr_[static_cast<size_t>(idx)] = (spsr_[static_cast<size_t>(idx)] & ~mask) | (operand & mask);
    } else {
        u32 newCpsr = (cpsr_ & ~mask) | (operand & mask);
        if ((mask & 0xFF) != 0 && privileged) SwitchMode(newCpsr & 0x1F);
        cpsr_ = newCpsr;
    }
    AddCycles(1);
}

} // namespace gba
