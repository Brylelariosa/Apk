#pragma once
#include "../common/types.h"

namespace gba {

class Bus;
class BiosHle;

enum CpuMode : u32 {
    MODE_USR = 0x10,
    MODE_FIQ = 0x11,
    MODE_IRQ = 0x12,
    MODE_SVC = 0x13,
    MODE_ABT = 0x17,
    MODE_UND = 0x1B,
    MODE_SYS = 0x1F,
};

enum CpsrBit {
    CPSR_N = 31, CPSR_Z = 30, CPSR_C = 29, CPSR_V = 28,
    CPSR_I = 7, CPSR_F = 6, CPSR_T = 5,
};

// A from-scratch interpreter for the ARM7TDMI: full ARM and THUMB instruction
// sets, mode-banked registers, and the standard exception vectors. Timing is
// modeled as "N/S cycles per bus access as reported by Bus::AccessCycles",
// which is a good, common approximation — not a literal 3-stage pipeline
// simulation (see README for what that trades away).
class Cpu {
public:
    void Init(Bus* bus, BiosHle* biosHle);
    void Reset();

    // Executes exactly one instruction and returns how many cycles it took.
    u32 Step();

    // Called by Gba when InterruptController::Pending() is true.
    void HandleIRQ();

    // --- debugger / save-state surface ---
    u32 GetRegister(int index) const { return r_[index]; }
    void SetRegister(int index, u32 value);
    u32 GetCPSR() const { return cpsr_; }
    void SetCPSR(u32 value);
    bool IsThumb() const { return TestBit(cpsr_, CPSR_T); }
    u32 CurrentPC() const { return r_[15]; } // as fetched (already includes pipeline lookahead)

private:
    u32 r_[16]{};
    u32 cpsr_ = 0;
    // Banked r8-r14 storage. Index 0 = USR/SYS (shared), 1 = FIQ, 2 = IRQ,
    // 3 = SVC, 4 = ABT, 5 = UND. Slots 0-4 hold r8-r12 (only meaningfully
    // distinct for FIQ; everyone else shares slot 0's r8-r12), slots 5-6
    // hold r13/r14 for that mode.
    u32 bankedRegs_[6][7]{};
    u32 spsr_[6]{};

    Bus* bus_ = nullptr;
    BiosHle* biosHle_ = nullptr;

    static int ModeIndex(u32 mode);
    void SwitchMode(u32 newMode);
    void FlushPipelineArm(u32 newPc);
    void FlushPipelineThumb(u32 newPc);

    bool ConditionPassed(u32 cond) const;
    void EnterException(u32 mode, u32 newPc, u32 lrAdjust);

    // HLE has no real BIOS bytes to execute the usual interrupt trampoline
    // (save r0-r3/r12, call the user handler pointer at 0x03007FFC, restore,
    // SUBS PC,LR,#4). Instead, HandleIRQ does the save + jumps straight to
    // the user handler with LR set to this sentinel; when the (real, game)
    // handler code returns via BX LR, Step() sees this PC value and runs
    // RunIrqEpilogue() natively instead of fetching an instruction there.
    static constexpr u32 kIrqReturnTrap = 0xFFFFFFFCu;
    u32 irqSavedSp_ = 0;
    u32 irqReturnAddr_ = 0;
    u32 irqSavedCpsr_ = 0;
    void RunIrqEpilogue();

    // Writes to a general register as an instruction's destination. Index 15
    // is special-cased: on real hardware, ANY write to PC (not just an
    // explicit branch) flushes the pipeline, so every instruction that can
    // target Rd=15 (data processing, LDR, LDM/POP) must route through this
    // rather than writing r_[15] directly.
    void WriteRegDest(int index, u32 value);
    // Reads a register as a source operand; R15 reads as the pipelined PC
    // value (current instruction address + 8 in ARM state, +4 in THUMB),
    // matching real hardware rather than the literal stored r_[15].
    u32 ReadRegSrc(int index) const;

    u32 cycles_ = 0; // accumulated during the instruction currently executing
    void AddCycles(u32 c) { cycles_ += c; }

    // --- ARM ---
    void ExecuteArm(u32 instr);
    void ArmDataProcessing(u32 instr);
    void ArmMultiply(u32 instr);
    void ArmMultiplyLong(u32 instr);
    void ArmSingleDataSwap(u32 instr);
    void ArmBranchExchange(u32 instr);
    void ArmHalfwordTransfer(u32 instr);
    void ArmSingleDataTransfer(u32 instr);
    void ArmUndefined(u32 instr);
    void ArmBlockDataTransfer(u32 instr);
    void ArmBranch(u32 instr);
    void ArmSoftwareInterrupt(u32 instr);
    void ArmPsrTransfer(u32 instr);

    u32 Shifter(u32 value, int type, u32 amount, bool immediateShift, bool& carryOut);

    // --- THUMB ---
    void ExecuteThumb(u16 instr);
    void ThumbMoveShifted(u16 instr);
    void ThumbAddSubtract(u16 instr);
    void ThumbMovCmpAddSubImm(u16 instr);
    void ThumbAluOp(u16 instr);
    void ThumbHiRegBx(u16 instr);
    void ThumbPcRelativeLoad(u16 instr);
    void ThumbLoadStoreRegOffset(u16 instr);
    void ThumbLoadStoreSignExt(u16 instr);
    void ThumbLoadStoreImmOffset(u16 instr);
    void ThumbLoadStoreHalfword(u16 instr);
    void ThumbSpRelativeLoadStore(u16 instr);
    void ThumbLoadAddress(u16 instr);
    void ThumbAddOffsetToSp(u16 instr);
    void ThumbPushPop(u16 instr);
    void ThumbMultipleLoadStore(u16 instr);
    void ThumbConditionalBranch(u16 instr);
    void ThumbSoftwareInterrupt(u16 instr);
    void ThumbUnconditionalBranch(u16 instr);
    void ThumbLongBranchLink(u16 instr);

    // shared ALU helpers (flags updated when `setFlags` is true)
    u32 AluAdd(u32 a, u32 b, u32 carryIn, bool setFlags);
    u32 AluSub(u32 a, u32 b, u32 carryIn, bool setFlags);
    void SetLogicalFlags(u32 result, bool carry);
};

} // namespace gba
