#pragma once
#include <string>
#include "../common/types.h"

namespace gba {

class Disassembler {
public:
    static std::string DisassembleArm(u32 addr, u32 instr);
    static std::string DisassembleThumb(u32 addr, u16 instr);
};

} // namespace gba
