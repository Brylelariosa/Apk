#include "disassembler.h"
#include <cstdio>

namespace gba {

namespace {

std::string Reg(u32 n) {
    if (n == 13) return "SP";
    if (n == 14) return "LR";
    if (n == 15) return "PC";
    return "R" + std::to_string(n);
}

std::string Hex(u32 v) {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "0x%X", v);
    return buf;
}

const char* CondName(u32 cond) {
    static const char* names[16] = { "EQ","NE","CS","CC","MI","PL","VS","VC","HI","LS","GE","LT","GT","LE","","NV" };
    return names[cond & 0xF];
}

const char* DpOpName(u32 op) {
    static const char* names[16] = { "AND","EOR","SUB","RSB","ADD","ADC","SBC","RSC","TST","TEQ","CMP","CMN","ORR","MOV","BIC","MVN" };
    return names[op & 0xF];
}

const char* ShiftName(u32 t) {
    static const char* names[4] = { "LSL", "LSR", "ASR", "ROR" };
    return names[t & 0x3];
}

} // namespace

std::string Disassembler::DisassembleArm(u32 addr, u32 instr) {
    u32 cond = instr >> 28;
    std::string c = (cond == 0xE) ? "" : CondName(cond);

    if ((instr & 0x0FFFFFF0) == 0x012FFF10) {
        return "BX" + c + " " + Reg(instr & 0xF);
    }

    u32 bits27_25 = (instr >> 25) & 0x7;

    if (bits27_25 == 0x0 || bits27_25 == 0x1) {
        bool immediateOperand2 = (bits27_25 == 0x1);
        if (!immediateOperand2 && ((instr >> 4) & 1) && ((instr >> 7) & 1)) {
            u32 bits7_4 = (instr >> 4) & 0xF;
            u32 bits24_23 = (instr >> 23) & 0x3;
            if (bits7_4 == 0x9) {
                if (bits24_23 == 0x0) {
                    u32 rd = (instr >> 16) & 0xF, rs = (instr >> 8) & 0xF, rm = instr & 0xF;
                    return (TestBit(instr, 21) ? "MLA" : "MUL") + c + " " + Reg(rd) + ", " + Reg(rm) + ", " + Reg(rs);
                }
                if (bits24_23 == 0x1) {
                    u32 rdHi = (instr >> 16) & 0xF, rdLo = (instr >> 12) & 0xF, rs = (instr >> 8) & 0xF, rm = instr & 0xF;
                    std::string name = std::string(TestBit(instr, 22) ? "S" : "U") + (TestBit(instr, 21) ? "MLAL" : "MULL");
                    return name + c + " " + Reg(rdLo) + ", " + Reg(rdHi) + ", " + Reg(rm) + ", " + Reg(rs);
                }
                return (TestBit(instr, 22) ? "SWPB" : "SWP") + c + " " + Reg((instr >> 12) & 0xF) + ", " + Reg(instr & 0xF) + ", [" + Reg((instr >> 16) & 0xF) + "]";
            }
            u32 rd = (instr >> 12) & 0xF, rn = (instr >> 16) & 0xF;
            const char* op = (bits7_4 == 0xB) ? "H" : (bits7_4 == 0xD) ? "SB" : "SH";
            return std::string(TestBit(instr, 20) ? "LDR" : "STR") + op + c + " " + Reg(rd) + ", [" + Reg(rn) + "]";
        }
        u32 opcode = (instr >> 21) & 0xF;
        bool sBit = TestBit(instr, 20);
        if (!sBit && opcode >= 0x8 && opcode <= 0xB) {
            if (!TestBit(instr, 21)) return std::string("MRS") + c + " " + Reg((instr >> 12) & 0xF) + ", " + (TestBit(instr, 22) ? "SPSR" : "CPSR");
            return std::string("MSR") + c + " " + (TestBit(instr, 22) ? "SPSR" : "CPSR") + "_flg, ...";
        }
        u32 rd = (instr >> 12) & 0xF, rn = (instr >> 16) & 0xF;
        std::string s = sBit ? "S" : "";
        std::string operand2;
        if (immediateOperand2) {
            u32 imm = instr & 0xFF, rot = ((instr >> 8) & 0xF) * 2;
            operand2 = "#" + Hex(RotateRight32(imm, rot));
        } else {
            u32 rm = instr & 0xF, shiftType = (instr >> 5) & 0x3;
            operand2 = Reg(rm);
            if (TestBit(instr, 4)) operand2 += std::string(", ") + ShiftName(shiftType) + " " + Reg((instr >> 8) & 0xF);
            else {
                u32 amt = (instr >> 7) & 0x1F;
                if (amt != 0) operand2 += std::string(", ") + ShiftName(shiftType) + " #" + std::to_string(amt);
            }
        }
        std::string mnem = DpOpName(opcode) + c + s;
        if (opcode == 0xD || opcode == 0xF) return mnem + " " + Reg(rd) + ", " + operand2;
        if (opcode >= 0x8 && opcode <= 0xB) return mnem + " " + Reg(rn) + ", " + operand2;
        return mnem + " " + Reg(rd) + ", " + Reg(rn) + ", " + operand2;
    }

    switch (bits27_25) {
        case 0x2: case 0x3: {
            bool preIndex = TestBit(instr, 24), up = TestBit(instr, 23), byteT = TestBit(instr, 22);
            bool isLoad = TestBit(instr, 20);
            u32 rd = (instr >> 12) & 0xF, rn = (instr >> 16) & 0xF;
            std::string base = Reg(rn);
            std::string sign = up ? "" : "-";
            std::string offs;
            if (bits27_25 == 0x2) {
                u32 imm = instr & 0xFFF;
                offs = imm ? ("#" + sign + Hex(imm)) : "";
            } else {
                u32 rm = instr & 0xF;
                offs = sign + Reg(rm);
            }
            std::string addrStr = offs.empty() ? ("[" + base + "]") : (preIndex ? ("[" + base + ", " + offs + "]") : ("[" + base + "], " + offs));
            return std::string(isLoad ? "LDR" : "STR") + c + (byteT ? "B" : "") + " " + Reg(rd) + ", " + addrStr;
        }
        case 0x4: {
            bool isLoad = TestBit(instr, 20), up = TestBit(instr, 23), preIndex = TestBit(instr, 24);
            u32 rn = (instr >> 16) & 0xF;
            std::string mode = up ? (preIndex ? "IB" : "IA") : (preIndex ? "DB" : "DA");
            std::string list = "{";
            bool first = true;
            for (int i = 0; i < 16; i++) {
                if (TestBit(instr, i)) { if (!first) list += ","; list += Reg(static_cast<u32>(i)); first = false; }
            }
            list += "}";
            return std::string(isLoad ? "LDM" : "STM") + mode + c + " " + Reg(rn) + (TestBit(instr, 21) ? "!" : "") + ", " + list;
        }
        case 0x5: {
            bool link = TestBit(instr, 24);
            s32 off = static_cast<s32>(SignExtend(instr & 0xFFFFFF, 24)) * 4;
            u32 target = static_cast<u32>(static_cast<s32>(addr + 8) + off);
            return std::string(link ? "BL" : "B") + c + " " + Hex(target);
        }
        case 0x6:
            return "<coprocessor xfer, unused>";
        case 0x7:
            if (TestBit(instr, 24)) return "SWI" + c + " #" + Hex((instr >> 16) & 0xFF);
            return "<coprocessor op, unused>";
        default:
            return "???";
    }
}

std::string Disassembler::DisassembleThumb(u32 addr, u16 instr) {
    u16 top3 = (instr >> 13) & 0x7;

    if (top3 == 0x0) {
        if (((instr >> 11) & 0x3) == 0x3) {
            bool imm = TestBit(instr, 10), sub = TestBit(instr, 9);
            u32 rnOrImm = (instr >> 6) & 0x7, rs = (instr >> 3) & 0x7, rd = instr & 0x7;
            std::string operand = imm ? ("#" + std::to_string(rnOrImm)) : Reg(rnOrImm);
            return std::string(sub ? "SUB " : "ADD ") + Reg(rd) + ", " + Reg(rs) + ", " + operand;
        }
        u32 op = (instr >> 11) & 0x3, imm5 = (instr >> 6) & 0x1F, rs = (instr >> 3) & 0x7, rd = instr & 0x7;
        return std::string(ShiftName(op)) + " " + Reg(rd) + ", " + Reg(rs) + ", #" + std::to_string(imm5);
    }
    if (top3 == 0x1) {
        u32 op = (instr >> 11) & 0x3, rd = (instr >> 8) & 0x7, imm = instr & 0xFF;
        static const char* names[4] = { "MOV", "CMP", "ADD", "SUB" };
        return std::string(names[op]) + " " + Reg(rd) + ", #" + Hex(imm);
    }
    if (top3 == 0x2) {
        u16 bits15_10 = (instr >> 10) & 0x3F;
        if (bits15_10 == 0x10) {
            static const char* names[16] = { "AND","EOR","LSL","LSR","ASR","ADC","SBC","ROR","TST","NEG","CMP","CMN","ORR","MUL","BIC","MVN" };
            u32 op = (instr >> 6) & 0xF, rs = (instr >> 3) & 0x7, rd = instr & 0x7;
            return std::string(names[op]) + " " + Reg(rd) + ", " + Reg(rs);
        }
        if (bits15_10 == 0x11) {
            u32 op = (instr >> 8) & 0x3;
            bool h1 = TestBit(instr, 7), h2 = TestBit(instr, 6);
            u32 rs = ((instr >> 3) & 0x7) + (h2 ? 8u : 0u), rd = (instr & 0x7) + (h1 ? 8u : 0u);
            if (op == 3) return "BX " + Reg(rs);
            static const char* names[3] = { "ADD", "CMP", "MOV" };
            return std::string(names[op]) + " " + Reg(rd) + ", " + Reg(rs);
        }
        if (((instr >> 11) & 0x1F) == 0x09) {
            u32 rd = (instr >> 8) & 0x7, imm = (instr & 0xFF) * 4;
            return "LDR " + Reg(rd) + ", [PC, #" + Hex(imm) + "]";
        }
        u32 rd = instr & 0x7, rb = (instr >> 3) & 0x7, ro = (instr >> 6) & 0x7;
        bool loadBit = TestBit(instr, 11);
        if (TestBit(instr, 9)) {
            static const char* names[4] = { "STRH", "LDSB", "LDRH", "LDSH" };
            u32 mode = (((instr >> 10) & 1) << 1) | ((instr >> 11) & 1);
            return std::string(names[mode & 0x3]) + " " + Reg(rd) + ", [" + Reg(rb) + ", " + Reg(ro) + "]";
        }
        bool byteBit = TestBit(instr, 10);
        return std::string(loadBit ? "LDR" : "STR") + (byteBit ? "B" : "") + " " + Reg(rd) + ", [" + Reg(rb) + ", " + Reg(ro) + "]";
    }
    if (top3 == 0x3) {
        bool byteBit = TestBit(instr, 12), loadBit = TestBit(instr, 11);
        u32 imm5 = (instr >> 6) & 0x1F, rb = (instr >> 3) & 0x7, rd = instr & 0x7;
        u32 offset = byteBit ? imm5 : imm5 * 4;
        return std::string(loadBit ? "LDR" : "STR") + (byteBit ? "B" : "") + " " + Reg(rd) + ", [" + Reg(rb) + ", #" + Hex(offset) + "]";
    }
    if (top3 == 0x4) {
        u32 rd = instr & 0x7;
        if (!TestBit(instr, 12)) {
            bool loadBit = TestBit(instr, 11);
            u32 imm5 = (instr >> 6) & 0x1F, rb = (instr >> 3) & 0x7;
            return std::string(loadBit ? "LDRH" : "STRH") + " " + Reg(rd) + ", [" + Reg(rb) + ", #" + Hex(imm5 * 2) + "]";
        }
        bool loadBit = TestBit(instr, 11);
        u32 rdHi = (instr >> 8) & 0x7, imm = (instr & 0xFF) * 4;
        return std::string(loadBit ? "LDR" : "STR") + " " + Reg(rdHi) + ", [SP, #" + Hex(imm) + "]";
    }
    if (top3 == 0x5) {
        if (!TestBit(instr, 12)) {
            bool spBit = TestBit(instr, 11);
            u32 rd = (instr >> 8) & 0x7, imm = (instr & 0xFF) * 4;
            return "ADD " + Reg(rd) + ", " + std::string(spBit ? "SP" : "PC") + ", #" + Hex(imm);
        }
        if (((instr >> 8) & 0xFF) == 0xB0) {
            bool neg = TestBit(instr, 7);
            return std::string("ADD SP, #") + (neg ? "-" : "") + Hex((instr & 0x7F) * 4);
        }
        if (((instr >> 9) & 0x3) == 0x2) {
            bool loadBit = TestBit(instr, 11), rBit = TestBit(instr, 8);
            std::string list = "{";
            bool first = true;
            for (int i = 0; i < 8; i++) if (TestBit(instr, i)) { if (!first) list += ","; list += Reg(static_cast<u32>(i)); first = false; }
            if (rBit) { if (!first) list += ","; list += loadBit ? "PC" : "LR"; }
            list += "}";
            return std::string(loadBit ? "POP " : "PUSH ") + list;
        }
        return "???";
    }
    if (top3 == 0x6) {
        if (!TestBit(instr, 12)) {
            bool loadBit = TestBit(instr, 11);
            u32 rb = (instr >> 8) & 0x7;
            std::string list = "{";
            bool first = true;
            for (int i = 0; i < 8; i++) if (TestBit(instr, i)) { if (!first) list += ","; list += Reg(static_cast<u32>(i)); first = false; }
            list += "}";
            return std::string(loadBit ? "LDMIA " : "STMIA ") + Reg(rb) + "!, " + list;
        }
        if (((instr >> 8) & 0xFF) == 0xDF) return "SWI #" + Hex(instr & 0xFF);
        u32 cond = (instr >> 8) & 0xF;
        s32 off = static_cast<s32>(SignExtend(instr & 0xFF, 8)) * 2;
        u32 target = static_cast<u32>(static_cast<s32>(addr + 4) + off);
        return std::string("B") + CondName(cond) + " " + Hex(target);
    }
    if (TestBit(instr, 12)) {
        bool low = TestBit(instr, 11);
        return low ? "BL (low)" : "BL (high)";
    }
    if (!TestBit(instr, 11)) {
        s32 off = static_cast<s32>(SignExtend(instr & 0x7FF, 11)) * 2;
        u32 target = static_cast<u32>(static_cast<s32>(addr + 4) + off);
        return "B " + Hex(target);
    }
    return "???";
}

} // namespace gba
