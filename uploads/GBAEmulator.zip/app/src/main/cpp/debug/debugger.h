#pragma once
#include <set>
#include <vector>
#include "../common/types.h"

namespace gba {

// Owns run/pause/step/breakpoint state. Gba's main loop consults this every
// instruction boundary; the JNI bridge exposes it to the Kotlin debugger UI.
// Deliberately just state + predicates — it doesn't touch Cpu/Bus directly,
// so it stays trivial to unit-test and can't accidentally desync from the
// core's own state.
class Debugger {
public:
    void Reset() { paused_ = false; singleStepPending_ = false; breakpoints_.clear(); }

    bool IsPaused() const { return paused_; }
    void Pause() { paused_ = true; }
    void Resume() { paused_ = false; }

    void RequestSingleStep() { singleStepPending_ = true; paused_ = false; }
    bool ConsumeSingleStepFlag() {
        bool v = singleStepPending_;
        singleStepPending_ = false;
        return v;
    }

    void AddBreakpoint(u32 addr) { breakpoints_.insert(addr); }
    void RemoveBreakpoint(u32 addr) { breakpoints_.erase(addr); }
    void ClearBreakpoints() { breakpoints_.clear(); }
    bool HasBreakpoint(u32 addr) const { return breakpoints_.count(addr) != 0; }
    std::vector<u32> ListBreakpoints() const { return std::vector<u32>(breakpoints_.begin(), breakpoints_.end()); }

private:
    bool paused_ = false;
    bool singleStepPending_ = false;
    std::set<u32> breakpoints_;
};

} // namespace gba
