#pragma once
#include "../common/types.h"

namespace gba {

class Cpu;
class Bus;

// High-level emulation of the GBA BIOS's SWI (software interrupt) API.
// These are Nintendo-documented, publicly specified calling conventions
// (the same ones devkitARM/libgba compile calls to) reimplemented in C++
// rather than a dumped BIOS image — no copyrighted BIOS code is involved,
// and the emulator runs perfectly well without one. A real BIOS image can
// still be supplied (see Bus::LoadBiosImage) for full-fidelity SWI/IRQ
// dispatch instead of this layer.
class BiosHle {
public:
    void HandleSwi(u8 comment, Cpu& cpu, Bus& bus);

private:
    void SoftReset(Cpu& cpu);
    void RegisterRamReset(Cpu& cpu, Bus& bus);
    void Halt(Bus& bus);
    void Stop(Bus& bus);
    void IntrWait(Cpu& cpu, Bus& bus);
    void VBlankIntrWait(Bus& bus);
    void Div(Cpu& cpu);
    void DivArm(Cpu& cpu);
    void Sqrt(Cpu& cpu);
    void ArcTan(Cpu& cpu);
    void ArcTan2(Cpu& cpu);
    void CpuSet(Cpu& cpu, Bus& bus);
    void CpuFastSet(Cpu& cpu, Bus& bus);
    void BgAffineSet(Cpu& cpu, Bus& bus);
    void ObjAffineSet(Cpu& cpu, Bus& bus);
    void LZ77UnComp(Cpu& cpu, Bus& bus, int unitSize);
    void RLUnComp(Cpu& cpu, Bus& bus, int unitSize);
};

} // namespace gba
