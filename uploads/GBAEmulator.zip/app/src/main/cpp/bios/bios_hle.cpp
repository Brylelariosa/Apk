#include "bios_hle.h"
#include "../cpu/cpu.h"
#include "../memory/bus.h"
#include <cmath>
#include <cstring>
#include <vector>

namespace gba {

namespace { constexpr double kPi = 3.14159265358979323846; }

void BiosHle::HandleSwi(u8 comment, Cpu& cpu, Bus& bus) {
    switch (comment) {
        case 0x00: SoftReset(cpu); return;
        case 0x01: RegisterRamReset(cpu, bus); return;
        case 0x02: Halt(bus); return;
        case 0x03: Stop(bus); return;
        case 0x04: IntrWait(cpu, bus); return;
        case 0x05: VBlankIntrWait(bus); return;
        case 0x06: Div(cpu); return;
        case 0x07: DivArm(cpu); return;
        case 0x08: Sqrt(cpu); return;
        case 0x09: ArcTan(cpu); return;
        case 0x0A: ArcTan2(cpu); return;
        case 0x0B: CpuSet(cpu, bus); return;
        case 0x0C: CpuFastSet(cpu, bus); return;
        case 0x0E: BgAffineSet(cpu, bus); return;
        case 0x0F: ObjAffineSet(cpu, bus); return;
        case 0x11: LZ77UnComp(cpu, bus, 1); return;
        case 0x12: LZ77UnComp(cpu, bus, 2); return;
        case 0x14: RLUnComp(cpu, bus, 1); return;
        case 0x15: RLUnComp(cpu, bus, 2); return;
        default:
            // Anything else (Huffman decomp, diff filters, sound driver
            // calls, MultiBoot, ...) is unimplemented — a documented gap
            // rather than a crash. Most games never call these.
            return;
    }
}

void BiosHle::SoftReset(Cpu& cpu) { cpu.Reset(); }

void BiosHle::RegisterRamReset(Cpu& cpu, Bus& bus) {
    u32 flags = cpu.GetRegister(0);
    if (TestBit(flags, 0)) std::memset(bus.EwramRaw(), 0, 256 * 1024);
    if (TestBit(flags, 1)) std::memset(bus.IwramRaw(), 0, 32 * 1024 - 0x200); // leave top of IWRAM (stacks) intact
    if (TestBit(flags, 2)) std::memset(bus.PaletteRaw(), 0, 1024);
    if (TestBit(flags, 3)) std::memset(bus.VramRaw(), 0, 96 * 1024);
    if (TestBit(flags, 4)) std::memset(bus.OamRaw(), 0, 1024);
    // SIO/sound/other regs (bits 5-7) aren't modeled — documented gap.
}

void BiosHle::Halt(Bus& bus) { bus.RequestHalt(); }
void BiosHle::Stop(Bus& bus) { bus.RequestHalt(); }

void BiosHle::IntrWait(Cpu&, Bus& bus) {
    // Simplified: real IntrWait loops (via the BIOS interrupt flag mirror at
    // 0x03007FF8) until the *specific* requested flag(s) fire, re-halting if
    // woken by an unrelated interrupt. This just halts and wakes on any
    // enabled interrupt, which is correct whenever the awaited flag is the
    // only one enabled (by far the common case) — documented simplification.
    bus.RequestHalt();
}

void BiosHle::VBlankIntrWait(Bus& bus) { bus.RequestHalt(); }

void BiosHle::Div(Cpu& cpu) {
    s32 num = static_cast<s32>(cpu.GetRegister(0));
    s32 den = static_cast<s32>(cpu.GetRegister(1));
    if (den == 0) {
        // Real hardware's div-by-zero result is a documented quirk; this is
        // a safe fallback rather than an attempt to match it exactly.
        cpu.SetRegister(0, static_cast<u32>(num < 0 ? -1 : 1));
        cpu.SetRegister(1, static_cast<u32>(num));
        cpu.SetRegister(3, static_cast<u32>(num < 0 ? -num : num));
        return;
    }
    s32 quotient = num / den;
    s32 remainder = num % den;
    cpu.SetRegister(0, static_cast<u32>(quotient));
    cpu.SetRegister(1, static_cast<u32>(remainder));
    cpu.SetRegister(3, static_cast<u32>(quotient < 0 ? -quotient : quotient));
}

void BiosHle::DivArm(Cpu& cpu) {
    u32 a = cpu.GetRegister(0);
    u32 b = cpu.GetRegister(1);
    cpu.SetRegister(0, b);
    cpu.SetRegister(1, a);
    Div(cpu);
}

void BiosHle::Sqrt(Cpu& cpu) {
    u32 v = cpu.GetRegister(0);
    cpu.SetRegister(0, static_cast<u32>(std::sqrt(static_cast<double>(v))));
}

void BiosHle::ArcTan(Cpu& cpu) {
    s32 x = static_cast<s32>(static_cast<s16>(cpu.GetRegister(0) & 0xFFFF));
    double val = static_cast<double>(x) / 16384.0;
    double angle = std::atan(val);
    s32 result = static_cast<s32>(angle / (2.0 * kPi) * 65536.0);
    cpu.SetRegister(0, static_cast<u32>(result) & 0xFFFF);
}

void BiosHle::ArcTan2(Cpu& cpu) {
    s32 x = static_cast<s32>(static_cast<s16>(cpu.GetRegister(0) & 0xFFFF));
    s32 y = static_cast<s32>(static_cast<s16>(cpu.GetRegister(1) & 0xFFFF));
    double angle = std::atan2(static_cast<double>(y), static_cast<double>(x));
    if (angle < 0) angle += 2.0 * kPi;
    u32 result = static_cast<u32>(angle / (2.0 * kPi) * 65536.0) & 0xFFFF;
    cpu.SetRegister(0, result);
}

void BiosHle::CpuSet(Cpu& cpu, Bus& bus) {
    u32 src = cpu.GetRegister(0);
    u32 dst = cpu.GetRegister(1);
    u32 ctrl = cpu.GetRegister(2);
    u32 count = ctrl & 0x1FFFFF;
    bool fixedSrc = TestBit(ctrl, 24);
    bool word = TestBit(ctrl, 26);
    u32 unit = word ? 4u : 2u;
    for (u32 i = 0; i < count; i++) {
        if (word) bus.Write32(dst, bus.Read32(src));
        else bus.Write16(dst, bus.Read16(src));
        dst += unit;
        if (!fixedSrc) src += unit;
    }
}

void BiosHle::CpuFastSet(Cpu& cpu, Bus& bus) {
    u32 src = cpu.GetRegister(0);
    u32 dst = cpu.GetRegister(1);
    u32 ctrl = cpu.GetRegister(2);
    u32 count = ctrl & 0x1FFFFF;
    bool fixedSrc = TestBit(ctrl, 24);
    for (u32 i = 0; i < count; i++) {
        bus.Write32(dst, bus.Read32(src));
        dst += 4;
        if (!fixedSrc) src += 4;
    }
}

void BiosHle::BgAffineSet(Cpu& cpu, Bus& bus) {
    u32 srcAddr = cpu.GetRegister(0);
    u32 dstAddr = cpu.GetRegister(1);
    u32 count = cpu.GetRegister(2);

    for (u32 i = 0; i < count; i++) {
        s32 srcX = static_cast<s32>(bus.Read32(srcAddr + 0));
        s32 srcY = static_cast<s32>(bus.Read32(srcAddr + 4));
        s16 dispX = static_cast<s16>(bus.Read16(srcAddr + 8));
        s16 dispY = static_cast<s16>(bus.Read16(srcAddr + 10));
        s16 scaleX = static_cast<s16>(bus.Read16(srcAddr + 12));
        s16 scaleY = static_cast<s16>(bus.Read16(srcAddr + 14));
        u16 angle = bus.Read16(srcAddr + 16);

        double theta = (static_cast<double>(angle >> 8) / 256.0) * 2.0 * kPi;
        double sx = static_cast<double>(scaleX) / 256.0;
        double sy = static_cast<double>(scaleY) / 256.0;
        double c = std::cos(theta), s = std::sin(theta);

        auto toFixed = [](double v) { return static_cast<s16>(std::lround(v * 256.0)); };
        s16 pa = toFixed(c * sx), pb = toFixed(-s * sx), pc = toFixed(s * sy), pd = toFixed(c * sy);

        bus.Write16(dstAddr + 0, static_cast<u16>(pa));
        bus.Write16(dstAddr + 2, static_cast<u16>(pb));
        bus.Write16(dstAddr + 4, static_cast<u16>(pc));
        bus.Write16(dstAddr + 6, static_cast<u16>(pd));

        s32 refX = srcX - static_cast<s32>(std::lround(static_cast<double>(dispX) * c * sx - static_cast<double>(dispY) * s * sx));
        s32 refY = srcY - static_cast<s32>(std::lround(static_cast<double>(dispX) * s * sy + static_cast<double>(dispY) * c * sy));
        bus.Write32(dstAddr + 8, static_cast<u32>(refX));
        bus.Write32(dstAddr + 12, static_cast<u32>(refY));

        srcAddr += 20;
        dstAddr += 16;
    }
}

void BiosHle::ObjAffineSet(Cpu& cpu, Bus& bus) {
    u32 srcAddr = cpu.GetRegister(0);
    u32 dstAddr = cpu.GetRegister(1);
    u32 count = cpu.GetRegister(2);
    u32 stride = cpu.GetRegister(3);

    for (u32 i = 0; i < count; i++) {
        s16 scaleX = static_cast<s16>(bus.Read16(srcAddr + 0));
        s16 scaleY = static_cast<s16>(bus.Read16(srcAddr + 2));
        u16 angle = bus.Read16(srcAddr + 4);

        double theta = (static_cast<double>(angle >> 8) / 256.0) * 2.0 * kPi;
        double sx = static_cast<double>(scaleX) / 256.0;
        double sy = static_cast<double>(scaleY) / 256.0;
        double c = std::cos(theta), s = std::sin(theta);

        auto toFixed = [](double v) { return static_cast<s16>(std::lround(v * 256.0)); };
        bus.Write16(dstAddr + 0 * stride, static_cast<u16>(toFixed(c * sx)));
        bus.Write16(dstAddr + 1 * stride, static_cast<u16>(toFixed(-s * sx)));
        bus.Write16(dstAddr + 2 * stride, static_cast<u16>(toFixed(s * sy)));
        bus.Write16(dstAddr + 3 * stride, static_cast<u16>(toFixed(c * sy)));

        srcAddr += 8;
        dstAddr += 4 * stride;
    }
}

void BiosHle::LZ77UnComp(Cpu& cpu, Bus& bus, int unitSize) {
    u32 srcAddr = cpu.GetRegister(0);
    u32 dstAddr = cpu.GetRegister(1);
    u32 header = bus.Read32(srcAddr);
    u32 size = header >> 8;
    srcAddr += 4;

    std::vector<u8> out;
    out.reserve(size);
    while (out.size() < size) {
        u8 flags = bus.Read8(srcAddr++);
        for (int bit = 7; bit >= 0 && out.size() < size; bit--) {
            if (TestBit(flags, bit)) {
                u8 b0 = bus.Read8(srcAddr++);
                u8 b1 = bus.Read8(srcAddr++);
                int length = (b0 >> 4) + 3;
                size_t disp = static_cast<size_t>(((b0 & 0xF) << 8) | b1) + 1;
                for (int i = 0; i < length && out.size() < size; i++) {
                    size_t pos = out.size() - disp;
                    out.push_back(pos < out.size() ? out[pos] : 0);
                }
            } else {
                out.push_back(bus.Read8(srcAddr++));
            }
        }
    }

    for (size_t i = 0; i < out.size(); i++) {
        if (unitSize == 1) {
            bus.Write8(dstAddr + static_cast<u32>(i), out[i]);
        } else if (i % 2 == 0) {
            u8 hi = (i + 1 < out.size()) ? out[i + 1] : 0;
            bus.Write16(dstAddr + static_cast<u32>(i), static_cast<u16>(out[i] | (hi << 8)));
        }
    }
}

void BiosHle::RLUnComp(Cpu& cpu, Bus& bus, int unitSize) {
    u32 srcAddr = cpu.GetRegister(0);
    u32 dstAddr = cpu.GetRegister(1);
    u32 header = bus.Read32(srcAddr);
    u32 size = header >> 8;
    srcAddr += 4;

    std::vector<u8> out;
    out.reserve(size);
    while (out.size() < size) {
        u8 flag = bus.Read8(srcAddr++);
        if (TestBit(flag, 7)) {
            int length = (flag & 0x7F) + 3;
            u8 value = bus.Read8(srcAddr++);
            for (int i = 0; i < length && out.size() < size; i++) out.push_back(value);
        } else {
            int length = (flag & 0x7F) + 1;
            for (int i = 0; i < length && out.size() < size; i++) out.push_back(bus.Read8(srcAddr++));
        }
    }

    for (size_t i = 0; i < out.size(); i++) {
        if (unitSize == 1) {
            bus.Write8(dstAddr + static_cast<u32>(i), out[i]);
        } else if (i % 2 == 0) {
            u8 hi = (i + 1 < out.size()) ? out[i + 1] : 0;
            bus.Write16(dstAddr + static_cast<u32>(i), static_cast<u16>(out[i] | (hi << 8)));
        }
    }
}

} // namespace gba
