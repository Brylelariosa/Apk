#include "scheduler.h"
#include <limits>

namespace gba {

void Scheduler::Init() {
    Reset();
}

void Scheduler::Reset() {
    now_ = 0;
    for (auto& e : entries_) {
        e.timestamp = 0;
        e.active = false;
    }
}

void Scheduler::Schedule(EventType type, u64 cyclesFromNow) {
    auto& e = entries_[static_cast<size_t>(type)];
    e.timestamp = now_ + cyclesFromNow;
    e.type = type;
    e.active = true;
}

void Scheduler::Cancel(EventType type) {
    entries_[static_cast<size_t>(type)].active = false;
}

bool Scheduler::IsScheduled(EventType type) const {
    return entries_[static_cast<size_t>(type)].active;
}

u64 Scheduler::CyclesUntilNextEvent() const {
    u64 best = std::numeric_limits<u64>::max();
    for (const auto& e : entries_) {
        if (e.active && e.timestamp >= now_) {
            u64 delta = e.timestamp - now_;
            if (delta < best) best = delta;
        }
    }
    return best;
}

void Scheduler::Tick(u64 cycles) {
    now_ += cycles;

    // Fire everything that's now due. A handler is allowed to reschedule its
    // own event (that's how periodic events like HBlank/VBlank re-arm
    // themselves), so we loop until nothing is due rather than doing one pass
    // — that also naturally handles a handler firing more than once if the
    // caller ticked by a large number of cycles in one go.
    bool firedAny = true;
    while (firedAny) {
        firedAny = false;
        for (size_t i = 0; i < entries_.size(); ++i) {
            Entry& e = entries_[i];
            if (e.active && e.timestamp <= now_) {
                e.active = false;
                u64 lateBy = now_ - e.timestamp;
                if (handlers_[i]) {
                    handlers_[i](lateBy);
                }
                firedAny = true;
            }
        }
    }
}

} // namespace gba
