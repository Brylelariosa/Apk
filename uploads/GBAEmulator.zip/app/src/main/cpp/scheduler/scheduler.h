#pragma once
// A single event queue drives every timing-sensitive subsystem (PPU scanline
// stages, timer overflows, the APU frame sequencer). Centralizing this beats
// scattering "cyclesUntilNextX" counters through every module: any subsystem
// can schedule/cancel an event without the others knowing it exists, which is
// what keeps PPU/timers/APU decoupled from each other.
//
// The CPU interpreter drives everything: after executing an instruction it
// reports how many cycles that took, the scheduler advances by that amount,
// and fires any event whose timestamp has been reached.

#include <array>
#include <functional>
#include <vector>
#include "../common/types.h"

namespace gba {

enum class EventType : u32 {
    PpuHBlank = 0,    // start of horizontal blank for the current line
    PpuVCount,        // start of the next scanline (VCOUNT advance / match check)
    Timer0Overflow,
    Timer1Overflow,
    Timer2Overflow,
    Timer3Overflow,
    ApuFrameSequencer,
    ApuSample,
    Count
};

class Scheduler {
public:
    using Callback = std::function<void(u64 lateCycles)>;

    void Init();
    void RegisterHandler(EventType type, Callback cb) {
        handlers_[static_cast<size_t>(type)] = std::move(cb);
    }

    // Schedules `type` to fire `cyclesFromNow` cycles in the future,
    // replacing any existing pending occurrence of the same type.
    void Schedule(EventType type, u64 cyclesFromNow);
    void Cancel(EventType type);
    bool IsScheduled(EventType type) const;

    // Advances the clock by `cycles`, firing any events that become due.
    void Tick(u64 cycles);

    u64 Now() const { return now_; }

    // Cycles until the earliest pending event — lets the CPU loop know how
    // far it can safely run in a batch without missing an event (used by the
    // interpreter to decide when to stop and re-check for interrupts/DMA).
    u64 CyclesUntilNextEvent() const;

    void Reset();

private:
    struct Entry {
        u64 timestamp;
        EventType type;
        bool active;
    };

    u64 now_ = 0;
    std::array<Entry, static_cast<size_t>(EventType::Count)> entries_{};
    std::array<Callback, static_cast<size_t>(EventType::Count)> handlers_{};
};

} // namespace gba
