#pragma once
#include "../common/types.h"

namespace gba {

// Bit positions within IE / IF (0x4000200 / 0x4000202).
enum InterruptFlag : u16 {
    IRQ_VBLANK  = Bit(0),
    IRQ_HBLANK  = Bit(1),
    IRQ_VCOUNT  = Bit(2),
    IRQ_TIMER0  = Bit(3),
    IRQ_TIMER1  = Bit(4),
    IRQ_TIMER2  = Bit(5),
    IRQ_TIMER3  = Bit(6),
    IRQ_SERIAL  = Bit(7),
    IRQ_DMA0    = Bit(8),
    IRQ_DMA1    = Bit(9),
    IRQ_DMA2    = Bit(10),
    IRQ_DMA3    = Bit(11),
    IRQ_KEYPAD  = Bit(12),
    IRQ_GAMEPAK = Bit(13),
};

// IE/IF/IME live at fixed I/O addresses but the CPU only ever needs to know
// "is anything pending", so this class owns the three registers and the one
// predicate the CPU polls each instruction boundary.
class InterruptController {
public:
    void Reset() { ie_ = 0; if_ = 0; ime_ = 0; }

    void Request(u16 flags) { if_ |= flags; }

    u16 IE() const { return ie_; }
    u16 IF() const { return if_; }
    u16 IME() const { return ime_; }

    void SetIE(u16 v) { ie_ = v & 0x3FFF; }
    // Writing to IF clears the bits that are written as 1 (hardware quirk).
    void WriteIF(u16 v) { if_ &= static_cast<u16>(~v); }
    void SetIME(u16 v) { ime_ = v & 1; }

    bool HasPendingForHalt() const { return (ie_ & if_) != 0; }
    bool Pending() const { return ime_ != 0 && (ie_ & if_) != 0; }

private:
    u16 ie_ = 0;
    u16 if_ = 0;
    u16 ime_ = 0;
};

} // namespace gba
