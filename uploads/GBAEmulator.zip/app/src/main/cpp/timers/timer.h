#pragma once
#include "../common/types.h"
#include "../scheduler/scheduler.h"
#include "../irq/interrupt.h"

namespace gba {

class Apu; // fwd decl — timer 0/1 overflow can refill DirectSound FIFOs

// The four GBA timers (TM0CNT..TM3CNT). Rather than decrementing every
// timer every cycle (wasteful — 4 timers x every CPU step), running timers
// are event-driven: we compute exactly how many cycles until a 16-bit
// counter would wrap and schedule a single event for that point. Reads
// between overflows are reconstructed from elapsed cycles, so precision
// isn't lost.
class TimerController {
public:
    void Init(Scheduler* scheduler, InterruptController* irq, Apu* apu);
    void Reset();

    u16 ReadCounter(int index) const;
    void WriteReload(int index, u16 value);

    u16 ReadControl(int index) const { return timers_[index].control; }
    void WriteControl(int index, u16 value);

private:
    struct TimerState {
        u16 reload = 0;
        u16 control = 0;
        u16 counterAtStart = 0;
        u64 startTimestamp = 0;
        bool running = false;
    };

    TimerState timers_[4];
    Scheduler* scheduler_ = nullptr;
    InterruptController* irq_ = nullptr;
    Apu* apu_ = nullptr;

    static int PrescalerShift(u16 control);
    static bool IsCascade(u16 control) { return TestBit(control, 2); }
    static bool IrqEnabled(u16 control) { return TestBit(control, 6); }
    static bool IsEnabled(u16 control) { return TestBit(control, 7); }

    void ArmNonCascade(int index);
    void HandleOverflow(int index, u64 lateCycles);
    // Applies one overflow's worth of side effects (reload/IRQ/APU/cascade)
    // without touching scheduling — shared by the timed path and the
    // cascade-increment path.
    void ApplyOverflowEffects(int index);

    static EventType EventFor(int index);
};

} // namespace gba
