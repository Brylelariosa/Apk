#include "timer.h"
#include "../audio/apu.h"

namespace gba {

int TimerController::PrescalerShift(u16 control) {
    switch (control & 0x3) {
        case 0: return 0;   // F/1
        case 1: return 6;   // F/64
        case 2: return 8;   // F/256
        default: return 10; // F/1024
    }
}

EventType TimerController::EventFor(int index) {
    switch (index) {
        case 0: return EventType::Timer0Overflow;
        case 1: return EventType::Timer1Overflow;
        case 2: return EventType::Timer2Overflow;
        default: return EventType::Timer3Overflow;
    }
}

void TimerController::Init(Scheduler* scheduler, InterruptController* irq, Apu* apu) {
    scheduler_ = scheduler;
    irq_ = irq;
    apu_ = apu;
    for (int i = 0; i < 4; i++) {
        scheduler_->RegisterHandler(EventFor(i), [this, i](u64 late) { HandleOverflow(i, late); });
    }
    Reset();
}

void TimerController::Reset() {
    for (int i = 0; i < 4; i++) {
        timers_[i] = TimerState{};
        if (scheduler_) scheduler_->Cancel(EventFor(i));
    }
}

u16 TimerController::ReadCounter(int index) const {
    const TimerState& t = timers_[index];
    if (!t.running) return t.counterAtStart;
    if (IsCascade(t.control)) {
        // Cascade timers don't advance with elapsed cycles; counterAtStart
        // is kept current by ApplyOverflowEffects on every cascade tick.
        return t.counterAtStart;
    }
    int shift = PrescalerShift(t.control);
    u64 elapsedTicks = (scheduler_->Now() - t.startTimestamp) >> shift;
    u32 value = static_cast<u32>(t.counterAtStart) + static_cast<u32>(elapsedTicks);
    return static_cast<u16>(value & 0xFFFF);
}

void TimerController::WriteReload(int index, u16 value) {
    timers_[index].reload = value;
}

void TimerController::WriteControl(int index, u16 value) {
    TimerState& t = timers_[index];
    bool wasEnabled = IsEnabled(t.control);
    bool nowEnabled = IsEnabled(value);
    t.control = value & 0x00C7; // bits 0-1 prescaler, 2 cascade, 6 irq-enable, 7 start

    if (!wasEnabled && nowEnabled) {
        // Rising edge: counter loads from reload and starts counting now.
        t.counterAtStart = t.reload;
        t.startTimestamp = scheduler_->Now();
        t.running = true;
        if (!IsCascade(t.control)) {
            ArmNonCascade(index);
        } else {
            scheduler_->Cancel(EventFor(index)); // cascade timers have no timed event
        }
    } else if (wasEnabled && !nowEnabled) {
        // Falling edge: freeze the counter at its current value.
        t.counterAtStart = ReadCounter(index);
        t.running = false;
        scheduler_->Cancel(EventFor(index));
    } else if (nowEnabled && !IsCascade(t.control)) {
        // Still running, but prescaler/cascade bits may have changed —
        // resample the current value and re-arm with the new prescaler.
        t.counterAtStart = ReadCounter(index);
        t.startTimestamp = scheduler_->Now();
        ArmNonCascade(index);
    }
}

void TimerController::ArmNonCascade(int index) {
    TimerState& t = timers_[index];
    int shift = PrescalerShift(t.control);
    u64 ticksToOverflow = 0x10000ull - t.counterAtStart;
    u64 cyclesToOverflow = ticksToOverflow << shift;
    scheduler_->Schedule(EventFor(index), cyclesToOverflow);
}

void TimerController::ApplyOverflowEffects(int index) {
    TimerState& t = timers_[index];
    t.counterAtStart = t.reload;

    if (IrqEnabled(t.control)) {
        static constexpr u16 kIrqBit[4] = { IRQ_TIMER0, IRQ_TIMER1, IRQ_TIMER2, IRQ_TIMER3 };
        irq_->Request(kIrqBit[index]);
    }

    if (apu_ && (index == 0 || index == 1)) {
        apu_->OnTimerOverflow(index);
    }

    // Cascade: if the next timer is enabled and configured for cascade mode,
    // bump it by one and, if that wraps, recurse into its own overflow.
    if (index < 3) {
        TimerState& next = timers_[index + 1];
        if (next.running && IsCascade(next.control)) {
            u32 v = static_cast<u32>(next.counterAtStart) + 1;
            if (v > 0xFFFF) {
                ApplyOverflowEffects(index + 1);
            } else {
                next.counterAtStart = static_cast<u16>(v);
            }
        }
    }
}

void TimerController::HandleOverflow(int index, u64 lateCycles) {
    ApplyOverflowEffects(index);
    TimerState& t = timers_[index];
    t.startTimestamp = scheduler_->Now() - lateCycles; // stay phase-accurate
    if (t.running && !IsCascade(t.control)) {
        ArmNonCascade(index);
    }
}

} // namespace gba
