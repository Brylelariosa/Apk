#pragma once
#include <array>
#include <deque>
#include "../common/types.h"
#include "../scheduler/scheduler.h"

namespace gba {

class DmaController;

// Output is generated at a fixed 32768 Hz (16.78MHz / 512 — a clean divide
// of the GBA's clock, avoiding a resampling step for a first version).
constexpr int kAudioSampleRate = 32768;
constexpr int kCyclesPerSample = 512;

class Apu {
public:
    void Init(Scheduler* scheduler, DmaController* dma);
    void Reset();

    u16 ReadReg16(u32 offset) const;   // offset relative to 0x4000060
    void WriteReg16(u32 offset, u16 value);

    void OnTimerOverflow(int timerIndex); // called by TimerController for timers 0/1

    // Pulls up to maxFrames interleaved stereo s16 frames into `out`.
    // Returns how many frames were actually written.
    int PullSamples(s16* out, int maxFrames);

private:
    struct SquareChannel {
        bool enabled = false;
        int duty = 0;              // 0=12.5%,1=25%,2=50%,3=75%
        int dutyPos = 0;
        u32 phaseAcc = 0;
        int freqRaw = 0;           // 11-bit rate value
        int lengthCounter = 0;
        bool lengthEnabled = false;
        int envInitial = 0, envDirection = 0, envPeriod = 0;
        int envCounter = 0, envCurrent = 0;
        // channel 1 only:
        int sweepPeriod = 0, sweepDirection = 0, sweepShift = 0;
        int sweepCounter = 0;
        int sweepShadowFreq = 0;
        bool sweepEnabled = false;

        int Amplitude() const; // -15..+15 (before volume)
    };
    struct WaveChannel {
        bool enabled = false;
        bool dacOn = false;
        int freqRaw = 0;
        int lengthCounter = 0;
        bool lengthEnabled = false;
        int volumeShift = 0; // 0=mute,1=100%,2=50%,3=25%
        bool bank64 = false; // true = play across both 32-sample banks
        int bankSelect = 0;
        u32 phaseAcc = 0;
        int samplePos = 0;
    };
    struct NoiseChannel {
        bool enabled = false;
        int lengthCounter = 0;
        bool lengthEnabled = false;
        int envInitial = 0, envDirection = 0, envPeriod = 0;
        int envCounter = 0, envCurrent = 0;
        int shiftFreq = 0, divRatio = 0;
        bool narrowMode = false;
        u16 lfsr = 0x7FFF;
        u32 phaseAcc = 0;
        int period = 0;
    };
    struct DirectSoundFifo {
        std::array<s8, 32> buffer{};
        int readPos = 0, count = 0;
        s8 current = 0;
        bool volumeFull = true; // false = 50%
        bool enableLeft = false, enableRight = false;
        int timerSelect = 0;

        void Push(s8 sample);
        void Reset();
    };

    SquareChannel ch1_, ch2_;
    WaveChannel ch3_;
    NoiseChannel ch4_;
    DirectSoundFifo fifoA_, fifoB_;
    std::array<u8, 16> waveRam_[2]{}; // two 16-byte (32 x 4-bit sample) banks

    u16 soundcntL_ = 0; // master volume / channel 1-4 L/R enable
    u16 soundcntH_ = 0; // DirectSound volume/enable/timer-select/reset
    u16 soundcntX_ = 0; // master enable + channel-on status (read-only bits)
    u16 soundbias_ = 0x200;

    Scheduler* scheduler_ = nullptr;
    DmaController* dma_ = nullptr;

    int frameSeqCounter_ = 0;
    int frameSeqStep_ = 0;

    std::deque<s16> outputRing_; // interleaved L,R pairs waiting to be pulled

    void OnSampleTick(u64 lateCycles);
    void StepFrameSequencer();
    void ClockLength();
    void ClockEnvelope();
    void ClockSweep();

    void TriggerSquare(SquareChannel& ch, bool isChannel1);
    void TriggerWave();
    void TriggerNoise();

    int SquareFrequencyHz(int freqRaw) const { return 131072 / (2048 - freqRaw); }
    int NoiseFrequencyHz(int ratio, int shift) const;
};

} // namespace gba
