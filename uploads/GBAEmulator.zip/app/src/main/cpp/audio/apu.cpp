#include "apu.h"
#include "../dma/dma.h"
#include <algorithm>

namespace gba {

int Apu::SquareChannel::Amplitude() const {
    static constexpr bool kDutyTable[4][8] = {
        { false, false, false, false, false, false, false, true },  // 12.5%
        { true, false, false, false, false, false, false, true },   // 25%
        { true, false, false, false, false, true, true, true },     // 50%
        { false, true, true, true, true, true, true, false },       // 75%
    };
    return kDutyTable[duty][dutyPos] ? 15 : -15;
}

void Apu::DirectSoundFifo::Push(s8 sample) {
    if (count < 32) {
        int writePos = (readPos + count) % 32;
        buffer[static_cast<size_t>(writePos)] = sample;
        count++;
    }
}

void Apu::DirectSoundFifo::Reset() {
    buffer.fill(0);
    readPos = 0;
    count = 0;
    current = 0;
}

void Apu::Init(Scheduler* scheduler, DmaController* dma) {
    scheduler_ = scheduler;
    dma_ = dma;
    scheduler_->RegisterHandler(EventType::ApuSample, [this](u64 late) { OnSampleTick(late); });
    Reset();
}

void Apu::Reset() {
    ch1_ = SquareChannel{};
    ch2_ = SquareChannel{};
    ch3_ = WaveChannel{};
    ch4_ = NoiseChannel{};
    fifoA_.Reset();
    fifoB_.Reset();
    for (auto& bank : waveRam_) bank.fill(0);
    soundcntL_ = soundcntH_ = soundcntX_ = 0;
    soundbias_ = 0x200;
    frameSeqCounter_ = 0;
    frameSeqStep_ = 0;
    outputRing_.clear();
    if (scheduler_) scheduler_->Schedule(EventType::ApuSample, kCyclesPerSample);
}

u16 Apu::ReadReg16(u32 off) const {
    switch (off) {
        case 0x00: return static_cast<u16>(ch1_.sweepShift | (ch1_.sweepDirection << 3) | (ch1_.sweepPeriod << 4));
        case 0x02: return static_cast<u16>((ch1_.duty << 6) | (ch1_.envPeriod << 8) | (ch1_.envDirection << 11) | (ch1_.envInitial << 12));
        case 0x04: return static_cast<u16>(static_cast<u16>(ch1_.freqRaw) | (ch1_.lengthEnabled ? Bit(14) : 0));
        case 0x08: return static_cast<u16>((ch2_.duty << 6) | (ch2_.envPeriod << 8) | (ch2_.envDirection << 11) | (ch2_.envInitial << 12));
        case 0x0C: return static_cast<u16>(static_cast<u16>(ch2_.freqRaw) | (ch2_.lengthEnabled ? Bit(14) : 0));
        case 0x10: return static_cast<u16>((ch3_.bankSelect << 5) | (ch3_.bank64 ? Bit(6) : 0) | (ch3_.dacOn ? Bit(7) : 0));
        case 0x12: return static_cast<u16>(ch3_.volumeShift << 13);
        case 0x14: return static_cast<u16>(static_cast<u16>(ch3_.freqRaw) | (ch3_.lengthEnabled ? Bit(14) : 0));
        case 0x18: return static_cast<u16>((ch4_.envPeriod << 8) | (ch4_.envDirection << 11) | (ch4_.envInitial << 12));
        case 0x1C: return static_cast<u16>(static_cast<u16>(ch4_.divRatio) | (ch4_.narrowMode ? Bit(3) : 0) |
                                            (ch4_.shiftFreq << 4) | (ch4_.lengthEnabled ? Bit(14) : 0));
        case 0x20: return soundcntL_;
        case 0x22: return soundcntH_;
        case 0x24: {
            u16 status = 0;
            if (ch1_.enabled) status |= Bit(0);
            if (ch2_.enabled) status |= Bit(1);
            if (ch3_.enabled) status |= Bit(2);
            if (ch4_.enabled) status |= Bit(3);
            return static_cast<u16>(status | (soundcntX_ & 0x0080));
        }
        case 0x28: return soundbias_;
        case 0x30: case 0x32: case 0x34: case 0x36:
        case 0x38: case 0x3A: case 0x3C: case 0x3E: {
            u32 i = off - 0x30;
            return static_cast<u16>(waveRam_[static_cast<size_t>(ch3_.bankSelect)][i]) |
                   (static_cast<u16>(waveRam_[static_cast<size_t>(ch3_.bankSelect)][i + 1]) << 8);
        }
        default: return 0;
    }
}

void Apu::WriteReg16(u32 off, u16 value) {
    switch (off) {
        case 0x00:
            ch1_.sweepShift = value & 0x7;
            ch1_.sweepDirection = (value >> 3) & 1;
            ch1_.sweepPeriod = (value >> 4) & 0x7;
            return;
        case 0x02:
            ch1_.lengthCounter = 64 - (value & 0x3F);
            ch1_.duty = (value >> 6) & 0x3;
            ch1_.envPeriod = (value >> 8) & 0x7;
            ch1_.envDirection = (value >> 11) & 1;
            ch1_.envInitial = (value >> 12) & 0xF;
            return;
        case 0x04:
            ch1_.freqRaw = value & 0x7FF;
            ch1_.lengthEnabled = TestBit(value, 14);
            if (TestBit(value, 15)) TriggerSquare(ch1_, true);
            return;

        case 0x08:
            ch2_.lengthCounter = 64 - (value & 0x3F);
            ch2_.duty = (value >> 6) & 0x3;
            ch2_.envPeriod = (value >> 8) & 0x7;
            ch2_.envDirection = (value >> 11) & 1;
            ch2_.envInitial = (value >> 12) & 0xF;
            return;
        case 0x0C:
            ch2_.freqRaw = value & 0x7FF;
            ch2_.lengthEnabled = TestBit(value, 14);
            if (TestBit(value, 15)) TriggerSquare(ch2_, false);
            return;

        case 0x10:
            ch3_.bankSelect = (value >> 5) & 1;
            ch3_.bank64 = TestBit(value, 6);
            ch3_.dacOn = TestBit(value, 7);
            if (!ch3_.dacOn) ch3_.enabled = false;
            return;
        case 0x12:
            ch3_.lengthCounter = 256 - (value & 0xFF);
            ch3_.volumeShift = (value >> 13) & 0x3;
            return;
        case 0x14:
            ch3_.freqRaw = value & 0x7FF;
            ch3_.lengthEnabled = TestBit(value, 14);
            if (TestBit(value, 15)) TriggerWave();
            return;

        case 0x18:
            ch4_.lengthCounter = 64 - (value & 0x3F);
            ch4_.envPeriod = (value >> 8) & 0x7;
            ch4_.envDirection = (value >> 11) & 1;
            ch4_.envInitial = (value >> 12) & 0xF;
            return;
        case 0x1C:
            ch4_.divRatio = value & 0x7;
            ch4_.narrowMode = TestBit(value, 3);
            ch4_.shiftFreq = (value >> 4) & 0xF;
            ch4_.lengthEnabled = TestBit(value, 14);
            if (TestBit(value, 15)) TriggerNoise();
            return;

        case 0x20: soundcntL_ = value; return;
        case 0x22:
            soundcntH_ = value;
            fifoA_.volumeFull = TestBit(value, 2);
            fifoA_.enableRight = TestBit(value, 8);
            fifoA_.enableLeft = TestBit(value, 9);
            fifoA_.timerSelect = TestBit(value, 10) ? 1 : 0;
            if (TestBit(value, 11)) fifoA_.Reset();
            fifoB_.volumeFull = TestBit(value, 3);
            fifoB_.enableRight = TestBit(value, 12);
            fifoB_.enableLeft = TestBit(value, 13);
            fifoB_.timerSelect = TestBit(value, 14) ? 1 : 0;
            if (TestBit(value, 15)) fifoB_.Reset();
            return;
        case 0x24: soundcntX_ = static_cast<u16>((soundcntX_ & 0x000F) | (value & 0x0080)); return;
        case 0x28: soundbias_ = value; return;

        case 0x30: case 0x32: case 0x34: case 0x36:
        case 0x38: case 0x3A: case 0x3C: case 0x3E: {
            u32 i = off - 0x30;
            waveRam_[static_cast<size_t>(ch3_.bankSelect)][i] = static_cast<u8>(value);
            waveRam_[static_cast<size_t>(ch3_.bankSelect)][i + 1] = static_cast<u8>(value >> 8);
            return;
        }

        case 0x40: case 0x42:
            fifoA_.Push(static_cast<s8>(value & 0xFF));
            fifoA_.Push(static_cast<s8>((value >> 8) & 0xFF));
            return;
        case 0x44: case 0x46:
            fifoB_.Push(static_cast<s8>(value & 0xFF));
            fifoB_.Push(static_cast<s8>((value >> 8) & 0xFF));
            return;

        default: return;
    }
}

void Apu::TriggerSquare(SquareChannel& ch, bool isChannel1) {
    ch.enabled = true;
    if (ch.lengthCounter == 0) ch.lengthCounter = 64;
    ch.envCurrent = ch.envInitial;
    ch.envCounter = ch.envPeriod;
    ch.dutyPos = 0;
    ch.phaseAcc = 0;
    if (isChannel1) {
        ch.sweepShadowFreq = ch.freqRaw;
        ch.sweepCounter = ch.sweepPeriod ? ch.sweepPeriod : 8;
        ch.sweepEnabled = (ch.sweepPeriod != 0) || (ch.sweepShift != 0);
        if (ch.sweepShift != 0) {
            int newFreq = ch.sweepShadowFreq + (ch.sweepDirection ? -1 : 1) * (ch.sweepShadowFreq >> ch.sweepShift);
            if (newFreq > 2047) ch.enabled = false;
        }
    }
}

void Apu::TriggerWave() {
    ch3_.enabled = ch3_.dacOn;
    if (ch3_.lengthCounter == 0) ch3_.lengthCounter = 256;
    ch3_.samplePos = 0;
    ch3_.phaseAcc = 0;
}

void Apu::TriggerNoise() {
    ch4_.enabled = true;
    if (ch4_.lengthCounter == 0) ch4_.lengthCounter = 64;
    ch4_.envCurrent = ch4_.envInitial;
    ch4_.envCounter = ch4_.envPeriod;
    ch4_.lfsr = 0x7FFF;
    ch4_.phaseAcc = 0;
}

void Apu::OnTimerOverflow(int timerIndex) {
    if (!TestBit(soundcntX_, 7)) return; // PSG/master sound disabled

    if (fifoA_.timerSelect == timerIndex) {
        if (fifoA_.count > 0) {
            fifoA_.current = fifoA_.buffer[static_cast<size_t>(fifoA_.readPos)];
            fifoA_.readPos = (fifoA_.readPos + 1) % 32;
            fifoA_.count--;
        }
        if (fifoA_.count <= 16 && dma_) dma_->NotifyFifoTrigger(0);
    }
    if (fifoB_.timerSelect == timerIndex) {
        if (fifoB_.count > 0) {
            fifoB_.current = fifoB_.buffer[static_cast<size_t>(fifoB_.readPos)];
            fifoB_.readPos = (fifoB_.readPos + 1) % 32;
            fifoB_.count--;
        }
        if (fifoB_.count <= 16 && dma_) dma_->NotifyFifoTrigger(1);
    }
}

int Apu::NoiseFrequencyHz(int ratio, int shift) const {
    int r2 = (ratio == 0) ? 1 : ratio * 2;
    return 1048576 / r2 / (1 << (shift + 1));
}

void Apu::OnSampleTick(u64 lateCycles) {
    s32 mixL = 0, mixR = 0;

    auto mixPsg = [&](int amp, int chIndexBit) {
        if (amp == 0) return;
        int rightVol = soundcntL_ & 0x7;
        int leftVol = (soundcntL_ >> 4) & 0x7;
        bool r = TestBit(soundcntL_, 8 + chIndexBit);
        bool l = TestBit(soundcntL_, 12 + chIndexBit);
        if (r) mixR += amp * 4 * (rightVol + 1);
        if (l) mixL += amp * 4 * (leftVol + 1);
    };

    if (ch1_.enabled) {
        ch1_.phaseAcc += static_cast<u32>(SquareFrequencyHz(ch1_.freqRaw));
        while (ch1_.phaseAcc >= static_cast<u32>(kAudioSampleRate)) {
            ch1_.phaseAcc -= static_cast<u32>(kAudioSampleRate);
            ch1_.dutyPos = (ch1_.dutyPos + 1) & 7;
        }
        mixPsg(ch1_.Amplitude() * ch1_.envCurrent / 15, 0);
    }
    if (ch2_.enabled) {
        ch2_.phaseAcc += static_cast<u32>(SquareFrequencyHz(ch2_.freqRaw));
        while (ch2_.phaseAcc >= static_cast<u32>(kAudioSampleRate)) {
            ch2_.phaseAcc -= static_cast<u32>(kAudioSampleRate);
            ch2_.dutyPos = (ch2_.dutyPos + 1) & 7;
        }
        mixPsg(ch2_.Amplitude() * ch2_.envCurrent / 15, 1);
    }
    if (ch3_.enabled) {
        int freqHz = 2097152 / (2048 - ch3_.freqRaw);
        ch3_.phaseAcc += static_cast<u32>(freqHz);
        int totalSamples = ch3_.bank64 ? 64 : 32;
        while (ch3_.phaseAcc >= static_cast<u32>(kAudioSampleRate)) {
            ch3_.phaseAcc -= static_cast<u32>(kAudioSampleRate);
            ch3_.samplePos = (ch3_.samplePos + 1) % totalSamples;
        }
        int bank = ch3_.bank64 ? ((ch3_.samplePos / 32) ^ ch3_.bankSelect) : ch3_.bankSelect;
        int idx = ch3_.samplePos % 32;
        u8 byte = waveRam_[static_cast<size_t>(bank & 1)][static_cast<size_t>(idx / 2)];
        u8 nib = (idx & 1) ? (byte & 0xF) : (byte >> 4);
        int sampleVal = static_cast<int>(nib) - 8;
        static constexpr int kShiftDiv[4] = { 1, 1, 2, 4 }; // 0=mute(handled below),1=100%,2=50%,3=25%
        int amp = (ch3_.volumeShift == 0) ? 0 : sampleVal / kShiftDiv[ch3_.volumeShift];
        mixPsg(amp, 2);
    }
    if (ch4_.enabled) {
        int freqHz = std::max(NoiseFrequencyHz(ch4_.divRatio, ch4_.shiftFreq), 1);
        ch4_.phaseAcc += static_cast<u32>(freqHz);
        while (ch4_.phaseAcc >= static_cast<u32>(kAudioSampleRate)) {
            ch4_.phaseAcc -= static_cast<u32>(kAudioSampleRate);
            u16 bit0 = ch4_.lfsr & 1;
            u16 newBit = static_cast<u16>(bit0 ^ ((ch4_.lfsr >> 1) & 1));
            ch4_.lfsr = static_cast<u16>(ch4_.lfsr >> 1);
            if (ch4_.narrowMode) {
                ch4_.lfsr = static_cast<u16>((ch4_.lfsr & ~static_cast<u16>(Bit(6))) | (newBit << 6));
                ch4_.lfsr &= 0x7F;
            } else {
                ch4_.lfsr = static_cast<u16>((ch4_.lfsr & ~static_cast<u16>(Bit(14))) | (newBit << 14));
                ch4_.lfsr &= 0x7FFF;
            }
        }
        int amp = (ch4_.lfsr & 1) ? -15 : 15;
        mixPsg(amp * ch4_.envCurrent / 15, 3);
    }

    int dsaShift = fifoA_.volumeFull ? 1 : 2;
    int dsbShift = fifoB_.volumeFull ? 1 : 2;
    if (fifoA_.enableLeft) mixL += (static_cast<int>(fifoA_.current) << dsaShift);
    if (fifoA_.enableRight) mixR += (static_cast<int>(fifoA_.current) << dsaShift);
    if (fifoB_.enableLeft) mixL += (static_cast<int>(fifoB_.current) << dsbShift);
    if (fifoB_.enableRight) mixR += (static_cast<int>(fifoB_.current) << dsbShift);

    mixL = std::clamp(mixL, -32768, 32767);
    mixR = std::clamp(mixR, -32768, 32767);

    if (outputRing_.size() < 32768) {
        outputRing_.push_back(static_cast<s16>(mixL));
        outputRing_.push_back(static_cast<s16>(mixR));
    }

    frameSeqCounter_++;
    if (frameSeqCounter_ >= 64) { // 32768 Hz / 64 = 512 Hz frame sequencer
        frameSeqCounter_ = 0;
        StepFrameSequencer();
    }

    u64 delay = (static_cast<u64>(kCyclesPerSample) > lateCycles) ? (static_cast<u64>(kCyclesPerSample) - lateCycles) : 1;
    scheduler_->Schedule(EventType::ApuSample, delay);
}

void Apu::StepFrameSequencer() {
    frameSeqStep_ = (frameSeqStep_ + 1) & 7;
    if ((frameSeqStep_ & 1) == 0) ClockLength();
    if (frameSeqStep_ == 7) ClockEnvelope();
    if (frameSeqStep_ == 2 || frameSeqStep_ == 6) ClockSweep();
}

void Apu::ClockLength() {
    auto clock = [](auto& ch) {
        if (ch.lengthEnabled && ch.lengthCounter > 0) {
            ch.lengthCounter--;
            if (ch.lengthCounter == 0) ch.enabled = false;
        }
    };
    clock(ch1_); clock(ch2_); clock(ch3_); clock(ch4_);
}

void Apu::ClockEnvelope() {
    auto clock = [](auto& ch) {
        if (ch.envPeriod == 0) return;
        if (ch.envCounter > 0) {
            ch.envCounter--;
            if (ch.envCounter == 0) {
                ch.envCounter = ch.envPeriod;
                if (ch.envDirection && ch.envCurrent < 15) ch.envCurrent++;
                else if (!ch.envDirection && ch.envCurrent > 0) ch.envCurrent--;
            }
        }
    };
    clock(ch1_); clock(ch2_); clock(ch4_);
}

void Apu::ClockSweep() {
    if (!ch1_.sweepEnabled || ch1_.sweepPeriod == 0) return;
    if (ch1_.sweepCounter > 0) {
        ch1_.sweepCounter--;
        if (ch1_.sweepCounter == 0) {
            ch1_.sweepCounter = ch1_.sweepPeriod ? ch1_.sweepPeriod : 8;
            int newFreq = ch1_.sweepShadowFreq + (ch1_.sweepDirection ? -1 : 1) * (ch1_.sweepShadowFreq >> ch1_.sweepShift);
            if (newFreq > 2047) {
                ch1_.enabled = false;
            } else if (ch1_.sweepShift != 0) {
                ch1_.sweepShadowFreq = newFreq;
                ch1_.freqRaw = newFreq & 0x7FF;
                int check = ch1_.sweepShadowFreq + (ch1_.sweepDirection ? -1 : 1) * (ch1_.sweepShadowFreq >> ch1_.sweepShift);
                if (check > 2047) ch1_.enabled = false;
            }
        }
    }
}

int Apu::PullSamples(s16* out, int maxFrames) {
    int frames = 0;
    while (frames < maxFrames && outputRing_.size() >= 2) {
        out[frames * 2] = outputRing_.front(); outputRing_.pop_front();
        out[frames * 2 + 1] = outputRing_.front(); outputRing_.pop_front();
        frames++;
    }
    return frames;
}

} // namespace gba
