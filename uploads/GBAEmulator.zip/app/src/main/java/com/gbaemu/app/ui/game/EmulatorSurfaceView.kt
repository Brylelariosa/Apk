package com.gbaemu.app.ui.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

private const val GBA_WIDTH = 240
private const val GBA_HEIGHT = 160

/**
 * Renders raw ARGB8888 frames from the core. Deliberately plain
 * Canvas.drawBitmap rather than a GL texture blit — at 240x160 the blit
 * itself is nowhere near the bottleneck, and this keeps the rendering path
 * simple to read and maintain. [submitFrame] is safe to call from the
 * emulation thread directly (SurfaceView's canvas locking is designed for
 * exactly this off-UI-thread producer pattern).
 */
class EmulatorSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    private val bitmap = Bitmap.createBitmap(GBA_WIDTH, GBA_HEIGHT, Bitmap.Config.ARGB_8888)
    private val paint = Paint().apply { isFilterBitmap = false } // nearest-neighbor keeps pixel edges crisp
    private val srcRect = Rect(0, 0, GBA_WIDTH, GBA_HEIGHT)

    @Volatile private var surfaceReady = false

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
    }

    fun submitFrame(pixels: IntArray) {
        if (!surfaceReady || pixels.size != GBA_WIDTH * GBA_HEIGHT) return
        bitmap.setPixels(pixels, 0, GBA_WIDTH, 0, 0, GBA_WIDTH, GBA_HEIGHT)

        val canvas = try {
            holder.lockCanvas()
        } catch (_: Exception) {
            null
        } ?: return

        try {
            val scale = minOf(canvas.width.toFloat() / GBA_WIDTH, canvas.height.toFloat() / GBA_HEIGHT)
            val dstWidth = (GBA_WIDTH * scale).toInt()
            val dstHeight = (GBA_HEIGHT * scale).toInt()
            val left = (canvas.width - dstWidth) / 2
            val top = (canvas.height - dstHeight) / 2
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bitmap, srcRect, Rect(left, top, left + dstWidth, top + dstHeight), paint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }
}
