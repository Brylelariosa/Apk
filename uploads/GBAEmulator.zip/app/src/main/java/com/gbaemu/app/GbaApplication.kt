package com.gbaemu.app

import android.app.Application

class GbaApplication : Application()
