package com.gbaemu.app.ui.game

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.gbaemu.app.core.GbaKey

@Composable
private fun GbaButton(
    label: String,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    onPressChange: (Boolean) -> Unit,
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0x883A2E6E))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        onPressChange(true)
                        try {
                            awaitRelease()
                        } finally {
                            onPressChange(false)
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White)
    }
}

/** Translucent D-pad + A/B + Start/Select + L/R overlay, GBA-standard layout. */
@Composable
fun OnScreenControls(
    onKey: (GbaKey, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.align(Alignment.BottomStart).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GbaButton("\u25B2", Modifier.size(56.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.UP, it) }
            Row {
                GbaButton("\u25C0", Modifier.size(56.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.LEFT, it) }
                Spacer(Modifier.size(56.dp))
                GbaButton("\u25B6", Modifier.size(56.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.RIGHT, it) }
            }
            GbaButton("\u25BC", Modifier.size(56.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.DOWN, it) }
        }

        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(32.dp).size(170.dp, 110.dp)) {
            GbaButton("B", Modifier.align(Alignment.BottomStart).size(64.dp)) { onKey(GbaKey.B, it) }
            GbaButton("A", Modifier.align(Alignment.TopEnd).size(64.dp)) { onKey(GbaKey.A, it) }
        }

        Row(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            GbaButton("SELECT", Modifier.width(76.dp).height(28.dp), RoundedCornerShape(14.dp)) { onKey(GbaKey.SELECT, it) }
            GbaButton("START", Modifier.width(76.dp).height(28.dp), RoundedCornerShape(14.dp)) { onKey(GbaKey.START, it) }
        }

        GbaButton("L", Modifier.align(Alignment.TopStart).padding(16.dp).size(64.dp, 36.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.L, it) }
        GbaButton("R", Modifier.align(Alignment.TopEnd).padding(16.dp).size(64.dp, 36.dp), RoundedCornerShape(8.dp)) { onKey(GbaKey.R, it) }
    }
}
