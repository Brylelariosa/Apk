package com.gbaemu.app.core

/** Bit indices matching KEYINPUT — passed straight through to the native core. */
enum class GbaKey(val bitIndex: Int) {
    A(0), B(1), SELECT(2), START(3),
    RIGHT(4), LEFT(5), UP(6), DOWN(7),
    R(8), L(9),
}

/**
 * Thin Kotlin wrapper around the native `Gba` instance. Owns exactly one
 * native pointer for its lifetime; callers create one per running game
 * (see [com.gbaemu.app.emulation.EmulationThread]) and call [destroy] when
 * done to free the native memory.
 */
class EmulatorCore {
    private var handle: Long = 0L
    val isLoaded: Boolean get() = handle != 0L

    fun init() {
        if (handle == 0L) handle = nativeInit()
    }

    fun destroy() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    fun loadRom(bytes: ByteArray): Boolean = nativeLoadRom(handle, bytes)
    fun loadBios(bytes: ByteArray): Boolean = nativeLoadBios(handle, bytes)
    fun loadBackup(bytes: ByteArray) = nativeLoadBackup(handle, bytes)
    fun getBackup(): ByteArray = nativeGetBackup(handle)
    fun hasBackup(): Boolean = nativeHasBackup(handle)
    fun reset() = nativeReset(handle)
    fun runFrame() = nativeRunFrame(handle)
    fun getFrameBuffer(): IntArray = nativeGetFrameBuffer(handle)
    fun getAudioSamples(maxFrames: Int): ShortArray = nativeGetAudioSamples(handle, maxFrames)
    fun setKey(key: GbaKey, pressed: Boolean) = nativeSetKey(handle, key.bitIndex, pressed)
    fun getRomTitle(): String = nativeGetRomTitle(handle)

    fun debugIsPaused(): Boolean = nativeDebugIsPaused(handle)
    fun debugPause() = nativeDebugPause(handle)
    fun debugResume() = nativeDebugResume(handle)
    fun debugStep() = nativeDebugStep(handle)
    fun debugGetRegisters(): IntArray = nativeDebugGetRegisters(handle)
    fun debugSetRegister(index: Int, value: Int) = nativeDebugSetRegister(handle, index, value)
    fun debugReadMemory(addr: Int, len: Int): ByteArray = nativeDebugReadMemory(handle, addr, len)
    fun debugWriteMemory(addr: Int, data: ByteArray) = nativeDebugWriteMemory(handle, addr, data)
    fun debugAddBreakpoint(addr: Int) = nativeDebugAddBreakpoint(handle, addr)
    fun debugRemoveBreakpoint(addr: Int) = nativeDebugRemoveBreakpoint(handle, addr)
    fun debugGetBreakpoints(): IntArray = nativeDebugGetBreakpoints(handle)
    fun debugDisassemble(addr: Int, count: Int): Array<String> = nativeDebugDisassemble(handle, addr, count)

    private external fun nativeInit(): Long
    private external fun nativeDestroy(ptr: Long)
    private external fun nativeLoadRom(ptr: Long, romBytes: ByteArray): Boolean
    private external fun nativeLoadBios(ptr: Long, biosBytes: ByteArray): Boolean
    private external fun nativeLoadBackup(ptr: Long, data: ByteArray)
    private external fun nativeGetBackup(ptr: Long): ByteArray
    private external fun nativeHasBackup(ptr: Long): Boolean
    private external fun nativeReset(ptr: Long)
    private external fun nativeRunFrame(ptr: Long)
    private external fun nativeGetFrameBuffer(ptr: Long): IntArray
    private external fun nativeGetAudioSamples(ptr: Long, maxFrames: Int): ShortArray
    private external fun nativeSetKey(ptr: Long, keyIndex: Int, pressed: Boolean)
    private external fun nativeGetRomTitle(ptr: Long): String

    private external fun nativeDebugIsPaused(ptr: Long): Boolean
    private external fun nativeDebugPause(ptr: Long)
    private external fun nativeDebugResume(ptr: Long)
    private external fun nativeDebugStep(ptr: Long)
    private external fun nativeDebugGetRegisters(ptr: Long): IntArray
    private external fun nativeDebugSetRegister(ptr: Long, index: Int, value: Int)
    private external fun nativeDebugReadMemory(ptr: Long, addr: Int, len: Int): ByteArray
    private external fun nativeDebugWriteMemory(ptr: Long, addr: Int, data: ByteArray)
    private external fun nativeDebugAddBreakpoint(ptr: Long, addr: Int)
    private external fun nativeDebugRemoveBreakpoint(ptr: Long, addr: Int)
    private external fun nativeDebugGetBreakpoints(ptr: Long): IntArray
    private external fun nativeDebugDisassemble(ptr: Long, addr: Int, count: Int): Array<String>

    companion object {
        init {
            System.loadLibrary("gbacore")
        }
    }
}
