package com.gbaemu.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** Streams interleaved 16-bit stereo PCM at the core's fixed 32768 Hz output rate. */
class AudioEngine {
    private var track: AudioTrack? = null
    private val sampleRate = 32768

    fun start() {
        if (track != null) return
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val bufferSize = (minBufferSize * 2).coerceAtLeast(sampleRate / 4)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
    }

    fun write(samples: ShortArray) {
        if (samples.isEmpty()) return
        track?.write(samples, 0, samples.size, AudioTrack.WRITE_NON_BLOCKING)
    }

    fun stop() {
        track?.apply {
            stop()
            release()
        }
        track = null
    }
}
