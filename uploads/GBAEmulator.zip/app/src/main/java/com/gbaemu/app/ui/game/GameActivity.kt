package com.gbaemu.app.ui.game

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.gbaemu.app.core.EmulatorCore
import com.gbaemu.app.core.GbaKey
import com.gbaemu.app.emulation.EmulationThread
import com.gbaemu.app.input.AnalogAxisToDigital
import com.gbaemu.app.input.GamepadHandler
import com.gbaemu.app.ui.debug.DebuggerScreen
import java.io.File

class GameActivity : ComponentActivity() {
    private lateinit var core: EmulatorCore
    private lateinit var emuThread: EmulationThread
    private lateinit var backupFile: File

    private val leftStickX = AnalogAxisToDigital()
    private val leftStickY = AnalogAxisToDigital()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val romPath = intent.getStringExtra(EXTRA_ROM_PATH)
        if (romPath == null) {
            finish()
            return
        }
        val romFile = File(romPath)

        core = EmulatorCore().apply { init() }
        core.loadRom(romFile.readBytes())

        backupFile = File(filesDir, "saves/${romFile.nameWithoutExtension}.sav")
        if (core.hasBackup() && backupFile.exists()) {
            core.loadBackup(backupFile.readBytes())
        }

        emuThread = EmulationThread(core)

        setContent {
            GameScreen(core = core, emuThread = emuThread)
        }

        emuThread.startRunning()
    }

    override fun onPause() {
        super.onPause()
        persistBackup()
    }

    override fun onDestroy() {
        super.onDestroy()
        emuThread.stopRunning()
        persistBackup()
        core.destroy()
    }

    private fun persistBackup() {
        if (!::core.isInitialized || !core.hasBackup()) return
        backupFile.parentFile?.mkdirs()
        backupFile.writeBytes(core.getBackup())
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val key = GamepadHandler.mapKeyCode(event.keyCode)
        if (key != null) {
            if (event.repeatCount == 0 || event.action == KeyEvent.ACTION_UP) {
                emuThread.setKey(key, event.action == KeyEvent.ACTION_DOWN)
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_MOVE) {
            leftStickX.update(
                event.getAxisValue(MotionEvent.AXIS_X),
                onNegative = { emuThread.setKey(GbaKey.LEFT, it) },
                onPositive = { emuThread.setKey(GbaKey.RIGHT, it) },
            )
            leftStickY.update(
                event.getAxisValue(MotionEvent.AXIS_Y),
                onNegative = { emuThread.setKey(GbaKey.UP, it) },
                onPositive = { emuThread.setKey(GbaKey.DOWN, it) },
            )
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    companion object {
        const val EXTRA_ROM_PATH = "rom_path"
    }
}

@Composable
private fun GameScreen(core: EmulatorCore, emuThread: EmulationThread) {
    var showDebugger by remember { mutableStateOf(false) }
    val paused by emuThread.debugPaused.collectAsState()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                EmulatorSurfaceView(ctx).also { view ->
                    emuThread.frameSink = { pixels -> view.submitFrame(pixels) }
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
        OnScreenControls(
            onKey = { key, pressed -> emuThread.setKey(key, pressed) },
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 8.dp)
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x55000000))
                .clickable { showDebugger = true },
            contentAlignment = Alignment.Center,
        ) {
            Text("\u2699", color = Color.White)
        }
        if (showDebugger) {
            DebuggerScreen(core = core, paused = paused, onClose = { showDebugger = false })
        }
    }
}
