package com.gbaemu.app.emulation

import com.gbaemu.app.audio.AudioEngine
import com.gbaemu.app.core.EmulatorCore
import com.gbaemu.app.core.GbaKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Owns the EmulatorCore and runs it on a dedicated background thread at the
 * GBA's native ~59.7 fps, decoupled from the UI/render thread so frame
 * pacing doesn't depend on Compose recomposition or touch handling.
 */
class EmulationThread(private val core: EmulatorCore) : Thread("EmulationThread") {
    private val audio = AudioEngine()

    @Volatile private var running = false

    private val _frame = MutableStateFlow<IntArray?>(null)
    val frame: StateFlow<IntArray?> = _frame

    /** Set by the game screen once its rendering surface is ready. Called directly
     *  from this thread every frame — the fast path; the StateFlow above is for
     *  lower-frequency consumers that don't need every single frame. */
    @Volatile var frameSink: ((IntArray) -> Unit)? = null

    private val _debugPaused = MutableStateFlow(false)
    val debugPaused: StateFlow<Boolean> = _debugPaused

    fun startRunning() {
        if (running) return
        running = true
        audio.start()
        start()
    }

    fun stopRunning() {
        running = false
        try {
            join(200)
        } catch (_: InterruptedException) {
            // best-effort join; the thread checks `running` every frame regardless
        }
        audio.stop()
    }

    fun setKey(key: GbaKey, pressed: Boolean) = core.setKey(key, pressed)

    override fun run() {
        val frameNanos = (1_000_000_000.0 / 59.7275).toLong()
        var nextFrameTime = System.nanoTime()

        while (running) {
            core.runFrame()

            _debugPaused.value = core.debugIsPaused()
            val fb = core.getFrameBuffer()
            _frame.value = fb
            frameSink?.invoke(fb)
            audio.write(core.getAudioSamples(2048))

            nextFrameTime += frameNanos
            val sleepNanos = nextFrameTime - System.nanoTime()
            if (sleepNanos > 0) {
                try {
                    sleep(sleepNanos / 1_000_000, (sleepNanos % 1_000_000).toInt())
                } catch (_: InterruptedException) {
                    // running flag governs the loop; nothing else to do here
                }
            } else {
                // Fell behind (e.g. debugger was paused) — resync rather than
                // burning through a backlog of frames to "catch up".
                nextFrameTime = System.nanoTime()
            }
        }
    }
}
