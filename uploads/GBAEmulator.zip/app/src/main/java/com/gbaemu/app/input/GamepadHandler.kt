package com.gbaemu.app.input

import android.view.KeyEvent
import com.gbaemu.app.core.GbaKey

/**
 * Maps standard Android gamepad key codes to GBA buttons. Covers face
 * buttons, shoulder buttons, and D-pad-as-buttons; analog stick / hat axis
 * input (which arrives as a MotionEvent, not a KeyEvent) is handled
 * separately in GameActivity since it needs its own small bit of state to
 * turn continuous axis values into discrete press/release events.
 */
object GamepadHandler {
    private val keyMap = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to GbaKey.A,
        KeyEvent.KEYCODE_BUTTON_B to GbaKey.B,
        // Some pads only expose X/Y; treating them as A/B aliases keeps
        // those controllers usable without a separate remapping screen.
        KeyEvent.KEYCODE_BUTTON_X to GbaKey.A,
        KeyEvent.KEYCODE_BUTTON_Y to GbaKey.B,
        KeyEvent.KEYCODE_BUTTON_SELECT to GbaKey.SELECT,
        KeyEvent.KEYCODE_BUTTON_START to GbaKey.START,
        KeyEvent.KEYCODE_BUTTON_L1 to GbaKey.L,
        KeyEvent.KEYCODE_BUTTON_R1 to GbaKey.R,
        KeyEvent.KEYCODE_DPAD_UP to GbaKey.UP,
        KeyEvent.KEYCODE_DPAD_DOWN to GbaKey.DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT to GbaKey.LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT to GbaKey.RIGHT,
    )

    fun mapKeyCode(keyCode: Int): GbaKey? = keyMap[keyCode]
}

/** Turns a continuous analog axis value into discrete UP/DOWN press events, remembering
 *  which side was last pressed so it can send exactly one release when the stick recenters. */
class AnalogAxisToDigital(private val threshold: Float = 0.5f) {
    private var pressedNegative = false
    private var pressedPositive = false

    fun update(value: Float, onNegative: (Boolean) -> Unit, onPositive: (Boolean) -> Unit) {
        val wantNegative = value <= -threshold
        val wantPositive = value >= threshold
        if (wantNegative != pressedNegative) { onNegative(wantNegative); pressedNegative = wantNegative }
        if (wantPositive != pressedPositive) { onPositive(wantPositive); pressedPositive = wantPositive }
    }
}
