@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.mapexplorer

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.worldmap.MapConnectionData
import com.romexplorer.gba.core.worldmap.MapHeaderData
import com.romexplorer.gba.core.worldmap.MapListEntry
import com.romexplorer.gba.core.worldmap.ObjectEventData
import com.romexplorer.gba.core.worldmap.WarpEventData
import com.romexplorer.gba.ui.common.ErrorBanner
import com.romexplorer.gba.ui.common.SectionHeader
import com.romexplorer.gba.ui.common.toImageBitmap
import com.romexplorer.gba.ui.navigation.Screen
import org.koin.androidx.compose.koinViewModel

/** Byte offset of struct ObjectEventTemplate's own `script` pointer field — see FireRedMapTables' class doc. Used to repoint that field if this event's script is edited and grows. */
private const val OBJECT_EVENT_SCRIPT_FIELD_OFFSET = 0x10L

@Composable
fun MapExplorerScreen(navController: NavHostController, viewModel: MapExplorerViewModel = koinViewModel()) {
    LaunchedEffect(Unit) { viewModel.loadMapListIfNeeded() }
    val listState by viewModel.mapList.collectAsState()
    val detail by viewModel.detail.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { MapDetailTitle(detail, viewModel) },
                navigationIcon = {
                    IconButton(onClick = { if (detail != null) viewModel.clearSelection() else navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            val currentDetail = detail
            if (currentDetail != null) {
                MapDetailContent(
                    detail = currentDetail,
                    viewModel = viewModel,
                    onViewScript = { scriptOffset, ownerFieldOffset ->
                        navController.navigate(Screen.PokeScript.routeWithArgs(scriptOffset, ownerFieldOffset))
                    },
                )
            } else {
                MapListContent(listState, viewModel, onSelect = viewModel::selectMap)
            }
        }
    }
}

/**
 * The app bar title for a selected map: its real name once [MapExplorerViewModel.resolveMapName]
 * resolves one (only possible once the header's loaded, for its
 * `regionMapSectionId`), "Bank X, Map Y" until then or if it never
 * resolves — never blank, and never wrong (see [MapNameReader]'s doc).
 */
@Composable
private fun MapDetailTitle(detail: MapDetailState?, viewModel: MapExplorerViewModel) {
    if (detail == null) {
        Text("Map Explorer")
        return
    }
    val bankMapLabel = "Bank ${detail.entry.id.group}, Map ${detail.entry.id.number}"
    val sectionId = detail.header?.regionMapSectionId
    val name by produceState<String?>(initialValue = null, sectionId) {
        value = sectionId?.let { viewModel.resolveMapName(it) }
    }
    Text(name ?: bankMapLabel)
}

@Composable
private fun MapListContent(state: MapListState, viewModel: MapExplorerViewModel, onSelect: (MapListEntry) -> Unit) {
    when (state) {
        is MapListState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        is MapListState.Failed -> ErrorBanner(state.message)
        is MapListState.Loaded -> {
            if (state.maps.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No maps found at the expected map bank table address — this doesn't look like a FireRed ROM with the layout this app knows.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    items(state.maps, key = { "${it.id.group}_${it.id.number}" }) { entry ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onSelect(entry) }) {
                            MapListRow(entry, viewModel)
                        }
                    }
                }
            }
        }
    }
}

/**
 * One map list row. Resolves its real name lazily via `produceState` — see
 * [MapExplorerViewModel.resolveMapName] — so the cost (a header read plus
 * [MapNameReader]'s pointer chase) is only paid for rows actually on
 * screen, same as [EntryIcon] does for table icons in the Pokémon tables
 * screen. Shows "Bank X, Map Y" alone until the name resolves (or if it
 * never does); once it does, "Bank X, Map Y" moves to a smaller line
 * underneath rather than disappearing, since warps and connections
 * elsewhere still refer to maps that way.
 */
@Composable
private fun MapListRow(entry: MapListEntry, viewModel: MapExplorerViewModel) {
    val bankMapLabel = "Bank ${entry.id.group}, Map ${entry.id.number}"
    val name by produceState<String?>(initialValue = null, entry) { value = viewModel.resolveMapName(entry) }
    Column(modifier = Modifier.padding(12.dp)) {
        Text(name ?: bankMapLabel, style = MaterialTheme.typography.bodyLarge)
        if (name != null) {
            Text(bankMapLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MapDetailContent(detail: MapDetailState, viewModel: MapExplorerViewModel, onViewScript: (scriptOffset: Long, ownerFieldOffset: Long) -> Unit) {
    var editingObjectEvent by remember { mutableStateOf<ObjectEventData?>(null) }
    var editingWarpEvent by remember { mutableStateOf<WarpEventData?>(null) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            when {
                detail.isLoading -> Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                detail.image != null -> {
                    val bitmap = remember(detail.image) { detail.image.toImageBitmap() }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .horizontalScroll(rememberScrollState())
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Image(bitmap = bitmap, contentDescription = "Map tiles", filterQuality = FilterQuality.None)
                    }
                }
                else -> Text(
                    "Couldn't render this map's tiles — its tileset data may be missing or at an unreadable address.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 16.dp),
                )
            }
        }

        val header = detail.header
        if (header != null) {
            item { Spacer(Modifier.height(8.dp)); MapInfoSection(header) }

            if (header.events.objectEvents.isNotEmpty()) {
                item { SectionHeader("Objects (${header.events.objectEvents.size})") }
                items(header.events.objectEvents, key = { "obj_${it.index}" }) { event ->
                    Column {
                        EventRow(
                            "Graphics #${event.graphicsId} @ (${event.x}, ${event.y})",
                            "Movement type ${event.movementType} · elevation ${event.elevation}",
                        ) { editingObjectEvent = event }
                        if (event.scriptPointer != 0L) {
                            TextButton(
                                onClick = { onViewScript(event.scriptPointer, event.romOffset + OBJECT_EVENT_SCRIPT_FIELD_OFFSET) },
                                contentPadding = PaddingValues(0.dp),
                            ) { Text("View script →", style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
            }
            if (header.events.warps.isNotEmpty()) {
                item { SectionHeader("Warps (${header.events.warps.size})") }
                items(header.events.warps, key = { "warp_${it.index}" }) { event ->
                    EventRow(
                        "Warp #${event.warpId} @ (${event.x}, ${event.y})",
                        "→ Bank ${event.destinationMapGroup}, Map ${event.destinationMapNum}",
                    ) { editingWarpEvent = event }
                }
            }
            if (header.events.coordEvents.isNotEmpty() || header.events.bgEvents.isNotEmpty()) {
                item {
                    Text(
                        "${header.events.coordEvents.size} trigger event(s) and ${header.events.bgEvents.size} sign/item event(s) on this map — view-only, editing isn't supported yet.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
            if (header.connections.isNotEmpty()) {
                item { SectionHeader("Connections") }
                items(header.connections) { conn -> ConnectionRow(conn) }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    editingObjectEvent?.let { event ->
        ObjectEventEditDialog(
            event = event,
            onDismiss = { editingObjectEvent = null },
            onSave = { x, y, elevation, graphicsId, movementType ->
                viewModel.editObjectEvent(event, x, y, elevation, graphicsId, movementType)
                editingObjectEvent = null
            },
        )
    }
    editingWarpEvent?.let { event ->
        WarpEventEditDialog(
            event = event,
            onDismiss = { editingWarpEvent = null },
            onSave = { x, y, elevation, warpId, destMapNum, destMapGroup ->
                viewModel.editWarpEvent(event, x, y, elevation, warpId, destMapNum, destMapGroup)
                editingWarpEvent = null
            },
        )
    }
}

@Composable
private fun MapInfoSection(header: MapHeaderData) {
    Column {
        SectionHeader("Map info")
        val layout = header.layout
        val dims = if (layout != null) "${layout.width} x ${layout.height} metatiles" else "unknown"
        Text("Layout: $dims", style = MaterialTheme.typography.bodyMedium)
        Text("Music track #${header.music} · weather #${header.weather} · map type #${header.mapType}", style = MaterialTheme.typography.bodyMedium)
        Text(
            "Biking ${if (header.bikingAllowed) "allowed" else "not allowed"} · battle type #${header.battleType}",
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun EventRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ConnectionRow(connection: MapConnectionData) {
    Text(
        "Direction #${connection.direction} → Bank ${connection.mapGroup}, Map ${connection.mapNum} (offset ${connection.offset})",
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(vertical = 2.dp),
    )
}

@Composable
private fun ObjectEventEditDialog(event: ObjectEventData, onDismiss: () -> Unit, onSave: (x: Int, y: Int, elevation: Int, graphicsId: Int, movementType: Int) -> Unit) {
    var x by remember(event) { mutableStateOf(event.x.toString()) }
    var y by remember(event) { mutableStateOf(event.y.toString()) }
    var elevation by remember(event) { mutableStateOf(event.elevation.toString()) }
    var graphicsId by remember(event) { mutableStateOf(event.graphicsId.toString()) }
    var movementType by remember(event) { mutableStateOf(event.movementType.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit object") },
        text = {
            Column {
                IntField("X", x) { x = it }
                IntField("Y", y) { y = it }
                IntField("Elevation", elevation) { elevation = it }
                IntField("Graphics ID", graphicsId) { graphicsId = it }
                IntField("Movement type", movementType) { movementType = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    x.toIntOrNull() ?: event.x,
                    y.toIntOrNull() ?: event.y,
                    elevation.toIntOrNull() ?: event.elevation,
                    graphicsId.toIntOrNull() ?: event.graphicsId,
                    movementType.toIntOrNull() ?: event.movementType,
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun WarpEventEditDialog(
    event: WarpEventData,
    onDismiss: () -> Unit,
    onSave: (x: Int, y: Int, elevation: Int, warpId: Int, destMapNum: Int, destMapGroup: Int) -> Unit,
) {
    var x by remember(event) { mutableStateOf(event.x.toString()) }
    var y by remember(event) { mutableStateOf(event.y.toString()) }
    var elevation by remember(event) { mutableStateOf(event.elevation.toString()) }
    var warpId by remember(event) { mutableStateOf(event.warpId.toString()) }
    var destMapNum by remember(event) { mutableStateOf(event.destinationMapNum.toString()) }
    var destMapGroup by remember(event) { mutableStateOf(event.destinationMapGroup.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit warp") },
        text = {
            Column {
                IntField("X", x) { x = it }
                IntField("Y", y) { y = it }
                IntField("Elevation", elevation) { elevation = it }
                IntField("Destination warp ID", warpId) { warpId = it }
                IntField("Destination map number", destMapNum) { destMapNum = it }
                IntField("Destination map bank", destMapGroup) { destMapGroup = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    x.toIntOrNull() ?: event.x,
                    y.toIntOrNull() ?: event.y,
                    elevation.toIntOrNull() ?: event.elevation,
                    warpId.toIntOrNull() ?: event.warpId,
                    destMapNum.toIntOrNull() ?: event.destinationMapNum,
                    destMapGroup.toIntOrNull() ?: event.destinationMapGroup,
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun IntField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() || c == '-' }.take(6)) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    )
}
