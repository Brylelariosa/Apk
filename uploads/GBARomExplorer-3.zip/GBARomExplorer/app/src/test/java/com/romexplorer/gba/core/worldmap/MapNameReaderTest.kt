package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.pokemon.PokemonTextCodec
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MapNameReaderTest {

    private fun le32Pointer(fileOffset: Long): ByteArray {
        val romAddr = (fileOffset + 0x08000000L).toInt()
        return byteArrayOf(
            (romAddr and 0xFF).toByte(),
            ((romAddr shr 8) and 0xFF).toByte(),
            ((romAddr shr 16) and 0xFF).toByte(),
            ((romAddr shr 24) and 0xFF).toByte(),
        )
    }

    /** Builds a ROM with one name-table entry: [id] -> a pointer to [name], encoded and 0xFF-terminated. */
    private fun romWithMapName(id: Int, name: String, stringOffset: Long = 0x300000L): ByteArray {
        val data = ByteArray(0x400000)
        val pointerOffset = (FireRedMapTables.MAP_NAMES_POINTER_TABLE_OFFSET + id * 4L).toInt()
        le32Pointer(stringOffset).copyInto(data, pointerOffset)
        val encoded = PokemonTextCodec.encode(name, name.length + 1) // + terminator, no padding needed for this test
        encoded.copyInto(data, stringOffset.toInt())
        return data
    }

    @Test
    fun `resolves region map section id 0 to PALLET TOWN, the sourcing thread's own worked example`() = runBlocking {
        val rom = ByteArrayRomAccessor(romWithMapName(0, "PALLET TOWN"))

        assertEquals("PALLET TOWN", MapNameReader.read(rom, 0))
        assertTrue(MapNameReader.verifyAgainstPalletTown(rom))
    }

    @Test
    fun `resolves a different section id to its own name`() = runBlocking {
        val rom = ByteArrayRomAccessor(romWithMapName(id = 12, name = "ROUTE 1", stringOffset = 0x310000L))

        assertEquals("ROUTE 1", MapNameReader.read(rom, 12))
    }

    @Test
    fun `fails closed on a ROM where the offset doesn't hold`() = runBlocking {
        // No real pointer table here at all — just zeroed space, the way a
        // different revision or a ROM this offset doesn't apply to would look.
        val rom = ByteArrayRomAccessor(ByteArray(0x400000))

        assertNull(MapNameReader.read(rom, 0))
        assertFalse(MapNameReader.verifyAgainstPalletTown(rom))
    }

    @Test
    fun `rejects a pointer that dereferences to non-name bytes rather than showing garbage`() = runBlocking {
        val data = ByteArray(0x400000)
        val pointerOffset = FireRedMapTables.MAP_NAMES_POINTER_TABLE_OFFSET.toInt()
        val stringOffset = 0x300000L
        le32Pointer(stringOffset).copyInto(data, pointerOffset)
        // Bytes with no PokemonTextCodec mapping at all (control-code range) —
        // this is what dereferencing the wrong offset tends to land on.
        data[stringOffset.toInt()] = 0x01
        data[stringOffset.toInt() + 1] = 0x02
        val rom = ByteArrayRomAccessor(data)

        assertNull(MapNameReader.read(rom, 0))
    }

    @Test
    fun `rejects an out-of-bounds section id instead of reading past the ROM`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(0x400000))

        assertNull(MapNameReader.read(rom, -1))
        assertNull(MapNameReader.read(rom, Int.MAX_VALUE / 2))
    }
}
