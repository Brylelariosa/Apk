package com.gamepad.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "gamepad_overlay_channel"
        private const val NOTIF_ID = 42
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: FrameLayout? = null

    // Screen dimensions
    private var screenW = 0f
    private var screenH = 0f

    // Joystick control loop
    @Volatile private var joystickActive = false
    private var joystickThread: Thread? = null
    @Volatile private var joyDx = 0f
    @Volatile private var joyDy = 0f

    // Configurable button tap targets (screen %)
    // Each button: Pair(x%, y%) of screen
    private val tapTargets = mutableMapOf(
        "A" to Pair(0.78f, 0.72f),
        "B" to Pair(0.88f, 0.62f),
        "X" to Pair(0.68f, 0.62f),
        "Y" to Pair(0.78f, 0.52f),
        "LB" to Pair(0.15f, 0.08f),
        "RB" to Pair(0.85f, 0.08f),
        "LT" to Pair(0.08f, 0.04f),
        "RT" to Pair(0.92f, 0.04f),
        "START" to Pair(0.60f, 0.08f),
        "SELECT" to Pair(0.40f, 0.08f),
    )

    // Visibility toggle state
    private var controlsVisible = true

    // Overlay drag state
    private var overlayOffsetX = 0
    private var overlayOffsetY = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        resolveScreenSize()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "ACTION_STOP") stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        joystickActive = false
        joystickThread?.interrupt()
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Notification
    // ─────────────────────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gamepad Overlay",
                NotificationManager.IMPORTANCE_LOW).apply {
                description = "Gamepad overlay is active"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).apply { action = "ACTION_STOP" },
            PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Overlay Active")
            .setContentText("Virtual controller is running")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Screen size
    // ─────────────────────────────────────────────────────────────────────────

    private fun resolveScreenSize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenW = bounds.width().toFloat()
            screenH = bounds.height().toFloat()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels.toFloat()
            screenH = dm.heightPixels.toFloat()
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Build overlay
    // ─────────────────────────────────────────────────────────────────────────

    private fun showOverlay() {
        val container = FrameLayout(this)
        overlayView = container

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START

        buildControls(container)
        windowManager.addView(container, lp)
    }

    private fun buildControls(root: FrameLayout) {

        // ── Left joystick ──────────────────────────────────────────────────
        val joystick = JoystickView(this)
        val joySize = dp(160)
        joystick.layoutParams = FrameLayout.LayoutParams(joySize, joySize).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            marginStart = dp(16)
            bottomMargin = dp(60)
        }
        joystick.onMoveListener = { nx, ny ->
            joyDx = nx; joyDy = ny
            if (!joystickActive && (abs(nx) > 0.12f || abs(ny) > 0.12f)) {
                joystickActive = true
                startJoystickLoop()
            } else if (abs(nx) <= 0.12f && abs(ny) <= 0.12f) {
                joystickActive = false
            }
        }
        joystick.onReleaseListener = { joystickActive = false }
        root.addView(joystick)

        // ── D-Pad ──────────────────────────────────────────────────────────
        val dpad = buildDpad()
        dpad.layoutParams = FrameLayout.LayoutParams(dp(130), dp(130)).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            marginStart = dp(180)
            bottomMargin = dp(160)
        }
        root.addView(dpad)

        // ── ABXY buttons ───────────────────────────────────────────────────
        val abxy = buildAbxyPanel()
        abxy.layoutParams = FrameLayout.LayoutParams(dp(140), dp(140)).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            marginEnd = dp(16)
            bottomMargin = dp(60)
        }
        root.addView(abxy)

        // ── Shoulder buttons ───────────────────────────────────────────────
        val lb = makeButton("LB", Color.argb(200, 60, 60, 160)) {
            vibrate(25); tap("LB")
        }
        lb.layoutParams = FrameLayout.LayoutParams(dp(72), dp(36)).apply {
            gravity = Gravity.TOP or Gravity.START
            marginStart = dp(16); topMargin = dp(24)
        }
        root.addView(lb)

        val rb = makeButton("RB", Color.argb(200, 60, 60, 160)) {
            vibrate(25); tap("RB")
        }
        rb.layoutParams = FrameLayout.LayoutParams(dp(72), dp(36)).apply {
            gravity = Gravity.TOP or Gravity.END
            marginEnd = dp(16); topMargin = dp(24)
        }
        root.addView(rb)

        val lt = makeButton("LT", Color.argb(180, 40, 40, 130)) {
            vibrate(35); tap("LT")
        }
        lt.layoutParams = FrameLayout.LayoutParams(dp(60), dp(30)).apply {
            gravity = Gravity.TOP or Gravity.START
            marginStart = dp(94); topMargin = dp(16)
        }
        root.addView(lt)

        val rt = makeButton("RT", Color.argb(180, 40, 40, 130)) {
            vibrate(35); tap("RT")
        }
        rt.layoutParams = FrameLayout.LayoutParams(dp(60), dp(30)).apply {
            gravity = Gravity.TOP or Gravity.END
            marginEnd = dp(94); topMargin = dp(16)
        }
        root.addView(rt)

        // ── Start / Select ─────────────────────────────────────────────────
        val startBtn = makeButton("▶", Color.argb(160, 50, 50, 100)) {
            vibrate(20); tap("START")
        }
        startBtn.layoutParams = FrameLayout.LayoutParams(dp(44), dp(28)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            marginStart = dp(30); topMargin = dp(20)
        }
        root.addView(startBtn)

        val selectBtn = makeButton("☰", Color.argb(160, 50, 50, 100)) {
            vibrate(20); tap("SELECT")
        }
        selectBtn.layoutParams = FrameLayout.LayoutParams(dp(44), dp(28)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            marginStart = dp(-30); topMargin = dp(20)
        }
        root.addView(selectBtn)

        // ── Visibility toggle ──────────────────────────────────────────────
        val toggle = makeButton("👁", Color.argb(180, 30, 30, 60)) {
            controlsVisible = !controlsVisible
            listOf(joystick, dpad, abxy, lb, rb, lt, rt, startBtn, selectBtn).forEach {
                it.visibility = if (controlsVisible) View.VISIBLE else View.INVISIBLE
            }
        }
        toggle.layoutParams = FrameLayout.LayoutParams(dp(46), dp(46)).apply {
            gravity = Gravity.TOP or Gravity.END
            marginEnd = dp(16); topMargin = dp(68)
        }
        root.addView(toggle)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Sub-panels
    // ─────────────────────────────────────────────────────────────────────────

    private fun buildAbxyPanel(): FrameLayout {
        val panel = FrameLayout(this)
        val sz = dp(52)

        val y = makeButton("Y", Color.argb(210, 180, 150, 0)) { vibrate(30); tap("Y") }
        y.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        }

        val a = makeButton("A", Color.argb(210, 0, 150, 70)) { vibrate(40); tap("A") }
        a.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }

        val x = makeButton("X", Color.argb(210, 20, 90, 200)) { vibrate(30); tap("X") }
        x.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
        }

        val b = makeButton("B", Color.argb(210, 200, 40, 40)) { vibrate(30); tap("B") }
        b.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }

        panel.addView(y); panel.addView(a); panel.addView(x); panel.addView(b)
        return panel
    }

    private fun buildDpad(): FrameLayout {
        val panel = FrameLayout(this)
        val sz = dp(40)
        val dpadColor = Color.argb(190, 70, 70, 90)

        val up = makeButton("▲", dpadColor) {
            vibrate(18)
            swipe(screenW * 0.5f, screenH * 0.6f, 0f, -dp(130).toFloat(), 140)
        }
        up.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        }

        val down = makeButton("▼", dpadColor) {
            vibrate(18)
            swipe(screenW * 0.5f, screenH * 0.4f, 0f, dp(130).toFloat(), 140)
        }
        down.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }

        val left = makeButton("◄", dpadColor) {
            vibrate(18)
            swipe(screenW * 0.6f, screenH * 0.5f, -dp(130).toFloat(), 0f, 140)
        }
        left.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
        }

        val right = makeButton("►", dpadColor) {
            vibrate(18)
            swipe(screenW * 0.4f, screenH * 0.5f, dp(130).toFloat(), 0f, 140)
        }
        right.layoutParams = FrameLayout.LayoutParams(sz, sz).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }

        panel.addView(up); panel.addView(down); panel.addView(left); panel.addView(right)
        return panel
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Button factory
    // ─────────────────────────────────────────────────────────────────────────

    private fun makeButton(label: String, bgColor: Int, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = when {
                label.length == 1 && label[0].code > 127 -> 18f // emoji
                label.length == 1 -> 15f
                else -> 11f
            }
            gravity = Gravity.CENTER
            background = oval(bgColor)
            isFocusable = false
            isClickable = true
            setOnClickListener { onClick() }
            // Pressed state visual feedback
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        alpha = 0.7f
                        scaleX = 0.93f; scaleY = 0.93f
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        alpha = 1f
                        scaleX = 1f; scaleY = 1f
                    }
                }
                false
            }
        }
    }

    private fun oval(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(3, Color.argb(120, 200, 200, 255))
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Joystick loop — sends repeated swipe gestures while stick is deflected
    // ─────────────────────────────────────────────────────────────────────────

    private fun startJoystickLoop() {
        joystickThread?.interrupt()
        joystickThread = Thread {
            while (joystickActive && !Thread.currentThread().isInterrupted) {
                val nx = joyDx
                val ny = joyDy
                val mag = sqrt(nx * nx + ny * ny)
                if (mag > 0.15f) {
                    val dist = (mag * 160f).coerceIn(30f, 200f)
                    swipe(
                        screenW * 0.5f, screenH * 0.55f,
                        nx * dist, ny * dist, 90L
                    )
                }
                try { Thread.sleep(110) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Input helpers
    // ─────────────────────────────────────────────────────────────────────────

    private fun tap(button: String) {
        val (px, py) = tapTargets[button] ?: return
        InputService.instance?.performTap(screenW * px, screenH * py)
    }

    private fun swipe(sx: Float, sy: Float, dx: Float, dy: Float, dur: Long) {
        InputService.instance?.performSwipe(sx, sy, dx, dy, dur)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Haptics
    // ─────────────────────────────────────────────────────────────────────────

    private fun vibrate(ms: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) {}
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Util
    // ─────────────────────────────────────────────────────────────────────────

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
