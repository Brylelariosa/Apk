package com.gary.voidsurvivors

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.*

/**
 * Pool-based synthesised audio — zero asset files, zero GC per play.
 * AudioTrack objects are created ONCE at init() and reused via per-sound pools.
 * play() returns in microseconds; the return-to-pool is scheduled automatically.
 */
object SoundManager {

    enum class Sfx {
        SHOOT, HIT_ENEMY, PLAYER_HIT, XP_PICKUP,
        LEVEL_UP, BOSS_APPEAR, EXPLOSION,
        ABILITY_USE, UI_CLICK, CHEST_OPEN, STATUS_APPLY
    }

    private const val SR         = 22050
    private const val POOL_SIZE  = 2          // tracks pre-allocated per sound

    var sfxVolume   = 0.75f
    var musicVolume = 0.40f
    var enabled     = true

    private val pcmMap    = HashMap<Sfx, ShortArray>()
    private val pools     = HashMap<Sfx, ArrayDeque<AudioTrack>>()
    private val poolLocks = HashMap<Sfx, Any>()

    /** Single-thread scheduler to return tracks to pools after playback finishes. */
    private var scheduler: ScheduledExecutorService? = null

    // ─── Lifecycle ───────────────────────────────────────────────

    fun init() {
        scheduler = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "SoundReturn").also { it.isDaemon = true }
        }
        Sfx.values().forEach { sfx ->
            val data = synthesize(sfx)
            pcmMap[sfx]    = data
            poolLocks[sfx] = Any()
            val pool = ArrayDeque<AudioTrack>()
            repeat(POOL_SIZE) {
                try { pool.addLast(buildTrack(data)) } catch (_: Exception) {}
            }
            pools[sfx] = pool
        }
    }

    fun release() {
        scheduler?.shutdownNow(); scheduler = null
        pools.values.forEach { pool ->
            synchronized(pool) { pool.forEach { runCatching { it.release() } } }
        }
        pools.clear(); pcmMap.clear(); poolLocks.clear()
    }

    // ─── Play ────────────────────────────────────────────────────

    /** Non-blocking. Returns immediately after starting playback. */
    fun play(sfx: Sfx) {
        if (!enabled || sfxVolume <= 0f) return
        val lock = poolLocks[sfx] ?: return
        val pool = pools[sfx]    ?: return
        val data = pcmMap[sfx]   ?: return
        val vol  = sfxVolume

        // Grab an idle track; if none free, drop the sound (avoids any blocking)
        val track = synchronized(lock) { pool.removeFirstOrNull() } ?: return

        try {
            track.stop()                        // no-op if already stopped
            track.setPlaybackHeadPosition(0)   // rewind to start
            track.setVolume(vol)
            track.play()
        } catch (_: Exception) {
            synchronized(lock) { pool.addLast(track) }
            return
        }

        // Return track to pool after playback completes (non-blocking)
        val durationMs = data.size * 1000L / SR + 40L
        scheduler?.schedule({
            synchronized(lock) { pool.addLast(track) }
        }, durationMs, TimeUnit.MILLISECONDS)
    }

    // ─── Track builder ───────────────────────────────────────────

    private fun buildTrack(data: ShortArray): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(
            SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSz = maxOf(data.size * 2, minBuf)
        return AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            bufSz, AudioTrack.MODE_STATIC,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        ).also { it.write(data, 0, data.size) }
    }

    // ─── PCM synthesis ───────────────────────────────────────────

    private fun synthesize(sfx: Sfx): ShortArray = when (sfx) {
        Sfx.SHOOT        -> buildShoot()
        Sfx.HIT_ENEMY    -> buildHitEnemy()
        Sfx.PLAYER_HIT   -> buildPlayerHit()
        Sfx.XP_PICKUP    -> buildXpPickup()
        Sfx.LEVEL_UP     -> buildLevelUp()
        Sfx.BOSS_APPEAR  -> buildBossAppear()
        Sfx.EXPLOSION    -> buildExplosion()
        Sfx.ABILITY_USE  -> buildAbility()
        Sfx.UI_CLICK     -> buildClick()
        Sfx.CHEST_OPEN   -> buildChestOpen()
        Sfx.STATUS_APPLY -> buildStatusApply()
    }

    private fun buildShoot(): ShortArray {
        val n = SR * 80 / 1000
        return ShortArray(n) { i ->
            val t = i.toFloat() / SR
            val freq = 1400f - t * 9000f
            val amp  = 14000f * (1f - t * 12f).coerceIn(0f, 1f)
            (if ((t * freq).toInt() % 2 == 0) amp else -amp).toInt().toShort()
        }
    }

    private fun buildHitEnemy(): ShortArray {
        val n = SR * 60 / 1000; val r = java.util.Random(42)
        return ShortArray(n) { i ->
            val t = i.toDouble() / SR
            (r.nextGaussian() * 18000 * exp(-t * 50.0)).toInt().toShort()
        }
    }

    private fun buildPlayerHit(): ShortArray {
        val n = SR * 220 / 1000; val r = java.util.Random(7)
        return ShortArray(n) { i ->
            val t   = i.toDouble() / SR
            val amp = 20000 * exp(-t * 18.0)
            (sin(2 * PI * 120.0 * t) * amp * 0.4 + r.nextGaussian() * amp * 0.6).toInt().toShort()
        }
    }

    private fun buildXpPickup(): ShortArray {
        val n = SR * 100 / 1000
        return ShortArray(n) { i ->
            val t    = i.toDouble() / SR
            val freq = 660.0 + t * 4400.0
            val amp  = 11000 * (1.0 - t * 9.0).coerceIn(0.0, 1.0)
            (sin(2 * PI * freq * t) * amp).toInt().toShort()
        }
    }

    private fun buildLevelUp(): ShortArray {
        val n = SR * 350 / 1000
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.5)
        val seg   = n / notes.size
        return ShortArray(n) { i ->
            val s    = (i / seg).coerceAtMost(notes.size - 1)
            val t    = (i % seg).toDouble() / SR
            val fade = (1.0 - t * notes.size / (n.toDouble() / SR)).coerceIn(0.0, 1.0)
            (sin(2 * PI * notes[s] * t) * 16000 * fade).toInt().toShort()
        }
    }

    private fun buildBossAppear(): ShortArray {
        val n = SR * 600 / 1000; val r = java.util.Random(13)
        return ShortArray(n) { i ->
            val t    = i.toDouble() / SR
            val freq = 55.0 + t * 60.0
            val amp  = 20000 * (if (t < 0.3) t / 0.3 else 1.0 - (t - 0.3) / 0.7).coerceIn(0.0, 1.0)
            (sin(2 * PI * freq * t) * amp * 0.6 + r.nextGaussian() * amp * 0.35).toInt().toShort()
        }
    }

    private fun buildExplosion(): ShortArray {
        val n = SR * 400 / 1000; val r = java.util.Random(99)
        return ShortArray(n) { i ->
            val t = i.toDouble() / SR
            val a = 22000 * exp(-t * 12.0)
            (sin(2 * PI * 80.0 * t) * a * 0.4 + r.nextGaussian() * a * 0.6).toInt().toShort()
        }
    }

    private fun buildAbility(): ShortArray {
        val n = SR * 200 / 1000
        return ShortArray(n) { i ->
            val t    = i.toDouble() / SR
            val freq = 1800.0 - t * 7000.0
            val amp  = 16000 * (1.0 - t * 5.0).coerceIn(0.0, 1.0)
            (sin(2 * PI * freq * t) * amp).toInt().toShort()
        }
    }

    private fun buildClick(): ShortArray {
        val n = SR * 22 / 1000; val r = java.util.Random(3)
        return ShortArray(n) { i ->
            val t = i.toDouble() / SR
            (r.nextGaussian() * 14000 * exp(-t * 200.0)).toInt().toShort()
        }
    }

    private fun buildChestOpen(): ShortArray {
        val n = SR * 280 / 1000
        val notes = doubleArrayOf(880.0, 1108.0, 1318.0, 1760.0)
        val seg   = n / notes.size; val r = java.util.Random(55)
        return ShortArray(n) { i ->
            val s    = (i / seg).coerceAtMost(notes.size - 1)
            val t    = (i % seg).toDouble() / SR
            val fade = (1.0 - t * notes.size / (n.toDouble() / SR)).coerceIn(0.0, 1.0)
            (sin(2 * PI * notes[s] * t) * 14000 * fade + r.nextGaussian() * 2000 * exp(-t * 150.0)).toInt().toShort()
        }
    }

    private fun buildStatusApply(): ShortArray {
        val n = SR * 90 / 1000; val r = java.util.Random(21)
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 2200f + r.nextFloat() * 800f
            val amp  = 12000.0 * exp(-t.toDouble() * 40.0)
            (if ((t * freq).toInt() % 2 == 0) amp else -amp).toInt().toShort()
        }
    }

    // ─── Convenience wrappers ────────────────────────────────────
    fun onShoot()      = play(Sfx.SHOOT)
    fun onHitEnemy()   = play(Sfx.HIT_ENEMY)
    fun onPlayerHit()  = play(Sfx.PLAYER_HIT)
    fun onXpPickup()   = play(Sfx.XP_PICKUP)
    fun onLevelUp()    = play(Sfx.LEVEL_UP)
    fun onBossAppear() = play(Sfx.BOSS_APPEAR)
    fun onExplosion()  = play(Sfx.EXPLOSION)
    fun onAbility()    = play(Sfx.ABILITY_USE)
    fun onUiClick()    = play(Sfx.UI_CLICK)
    fun onChestOpen()  = play(Sfx.CHEST_OPEN)
    fun onStatus()     = play(Sfx.STATUS_APPLY)
    // v6: New event wrappers reuse existing synthesised sounds
    fun onSynergy()    = play(Sfx.LEVEL_UP)     // ascending chime = synergy trigger
    fun onPickup()     = play(Sfx.XP_PICKUP)    // similar feel to XP collection
    fun onEndlessMode()= play(Sfx.BOSS_APPEAR)  // dramatic bass swell
}
