# VoidSurvivors — v6 Devlog
_Upgrade pass: Fun, Juice, Replayability_

---

## Overview
v6 is a non-destructive improvement pass on top of the fully-working v5 codebase.
No existing content was removed. No save data keys were changed. All new gameplay
systems are **additive** and work alongside the existing upgrade, ability, status
effect, combo, and achievement systems.

---

## Files Changed

### `Game.kt` — Major additions
- **New enums**: `EliteModifier`, `ChestRarity`, `PickupType` — three new type
  systems underpinning the main feature additions.
- **New class `Pickup`** — Ground pickup item with bob animation, auto-despawn (18 s),
  pop-in scale animation, and 12-item pool cap.
- **`Enemy`** — Added `eliteModifier`, `regenRate`, `synergyCooldown`,
  `berserkActive`, `berserkCheckDone`, `toxicTimer` for modifier system.
- **`TreasureChest`** — Added `rarity: ChestRarity` constructor param (default
  NORMAL → save compatible).
- **`Player`** — Added `pickupDmgMult/Timer` and `pickupSpeedMult/Timer` for
  temporary pickup boosts.
- **`GameState`** — Added `pickups`, `endlessMode`, `endlessAnnounceTimer`,
  `endlessScore`, `synergyPopup`, `synergyPopupTimer`, `superMagnetTimer`.
- **`RunStats`** — Added `pickupsCollected`, `synergiesTriggered`, `legendaryChests`.
- **Particle pool**: Enlarged from 600 → 800 slots to support new effect volume.

#### New systems in `GameLogic`:

**Elite Modifier System** (`applyEliteModifier`, `tickEliteModifier`):
Each elite enemy is assigned one of 7 random modifiers at spawn. Modifiers stack
cleanly with existing elite stats (3× HP, 4× XP, shoot patterns):
- `GIANT` — 1.6× HP, 0.72× speed. Visually distinct via badge.
- `TOXIC` — Emits continuous green particle trail; on death, poisons all nearby
  enemies (AoE POISON application).
- `SHIELDED` — Adds a regenerating shield (25% recovery threshold) on top of
  base elite HP. Works with existing shield damage absorption logic.
- `EXPLOSIVE` — On death, 140-radius blast damages nearby enemies AND player.
  Bigger particles, screen shake, BOOM float text.
- `REGENERATING` — Regains 1.8% maxHP/sec. Small heal particles as visual cue.
- `BERSERK` — At 50% HP: permanent 1.8× speed + 1.5× contact damage. Flash
  announcement + particle burst on transition.
- `TELEPORTING` — Teleports every 2–3 s (faster than TELEPORTER type's 3–5 s).

**Synergy System** (`checkSynergies`, called from `applyStatusEffect` and `bulletHitEnemies`):
Four auto-triggering synergy combos based on simultaneous status effects.
Per-enemy `synergyCooldown` prevents spam:
- **BURN + SHOCK → PLASMA BURST** — 3.5× DMG AoE nova (130-radius). Consumes both.
- **FREEZE + SHOCK → CHAIN STORM** — 2.2× DMG chains to 4 nearest enemies +
  re-applies SHOCK. Consumes both.
- **BURN + FREEZE → STEAM EXPLOSION** — 2.8× DMG wide slow AoE (110-radius) +
  applies FREEZE to all hit. Consumes both.
- **BLEED + CRIT → HEMORRHAGE** — 5× DMG single-target burst. Consumes BLEED.

**Ground Pickup System** (`spawnPickup`, `tickPickups`, `applyPickup`):
- 7 pickup types dropped from boss kills (guaranteed), elite kills (28% chance),
  random kills (3% chance), and chests.
- DMG_BOOST (+50% damage, 8 s), SPEED_BOOST (+40% speed, 8 s), SHIELD (instant),
  MAGNET (5 s super-magnet pulls all orbs), HEAL (+30% maxHP), GOLD_BURST (+15–34
  coins), NUKE (100×dmgMult AoE all enemies).
- Pickup timers tick in `GameLogic.update`; multipliers are reset to 1× on expiry.
- MAGNET pickup sets `superMagnetTimer` which boosts orb pull speed in `tickOrbs`.

**Chest Rarity System** (updated `tickChests`, `openChest`):
- Four tiers: NORMAL (62%), SILVER (20%), GOLD (13%), LEGENDARY (5%).
- Wave bonus slightly improves odds at higher waves (max +8%).
- Rarity determines: particle count/color, screen shake, slow-mo trigger
  (Legendary), double/triple reward chances, instant evolution chance (Legendary
  20%), extra coins. All chests now drop a bonus pickup.

**Endless Mode** (updated `tickWaves`):
- At wave 20: set `endlessMode = true`, trigger `endlessAnnounceTimer = 5f`,
  large particle burst + screen shake.
- Waves, enemy scaling, and boss spawns continue as normal (wave system already
  had no hard cap). This formalises and announces it.
- Endless kills tracked for post-run display.

**Slow-mo juice** (`triggerSlowMo`, used in `applyUpgrade` / `openChest` / `onEnemyDeath`):
- Boss death, evolution unlock, and legendary chest opening now each trigger 2–2.5 s
  of `timeSlowActive`. Reuses existing TIME_SLOW mechanic (safe without the ability).

**Crit shake** (updated `bulletHitEnemies`):
- Every critical hit now triggers `triggerShake(3.5f, 0.18f)` + bigger orange
  impact particles.

**Pickup boosts applied to bullets and orb** (updated `fireWeapon`, `tickOrbAttack`):
- `p.pickupDmgMult` multiplies bullet damage and orb DPS while `pickupDmgTimer > 0`.
- `p.pickupSpeedMult` multiplies movement speed while `pickupSpeedTimer > 0`.

**`reset()`** — Clears all new runtime state: `pickups`, `endlessMode`,
`endlessScore`, `synergyPopup`, `superMagnetTimer`, pickup timers on Player,
new RunStats fields.

---

### `GameView.kt` — Visual additions

**`drawPickups()`** — New render function called in `drawWorld()` between enemies
and player. Each pickup shows:
- Outer glow circle at 2.2× radius (semi-transparent type color)
- Inner circle (solid type color, alpha fades when life < 4 s as urgency warning)
- White core spot
- Short text label above

**Chest rarity rendering** (updated chest loop in `drawWorld`):
- NORMAL = brown/gold (unchanged), SILVER = grey, GOLD = amber, LEGENDARY = purple.
- Glow color, lid color, body color, and label text/color all vary per rarity.

**Elite modifier badge** (updated `drawEnemies`):
- Small dark circle in the top-right of the enemy with a one-letter code:
  G (Giant), T (Toxic), S (Shielded), X (eXplosive), R (Regenerating),
  B (Berserk, turns red when raging), P (telePorting).
- Shield bar drawn for SHIELDED modifier (on top of existing SHIELD_ENEMY bar).

**Synergy popup** (`drawSynergyPopup`):
- Semi-transparent amber banner at 72% screen height.
- Fades out and slides up over 2.5 s.

**Endless mode announce** (`drawEndlessAnnounce`):
- Full-screen dramatic overlay for 5 s on entering wave 20.
- Pulsing scale + fade-in/fade-out using sin curve.
- "∞ ENDLESS MODE ∞" in large orange text.

**HUD additions** (updated `drawHud`):
- Active pickup boost timers shown in top-right (DMG, SPD, MAGNET with countdown).
- Endless mode kill counter at bottom-center when `endlessMode = true`.

**Post-run stats** (updated `drawDead`):
- Two new stat rows: Pickups / Synergies.
- Endless mode badge shown if wave ≥ 20 reached.

**Settings screen** (updated `drawSettings`):
- "Left Joystick" toggle now shows full layout description:
  "Controls: Joystick LEFT / Skills RIGHT" or "Controls: Skills LEFT / Joystick RIGHT".
- **Default remains `joystickLeft = true`** (joystick on left, skill buttons on right).

**Tutorial text** (updated `drawTutorial`):
- "Drag the LEFT joystick to move" (was "Drag the LEFT side to move")
- "Tap skill buttons on the RIGHT side" (was "Tap ability buttons on the RIGHT")

---

### `SoundManager.kt` — Minor additions
- Added `onSynergy()`, `onPickup()`, `onEndlessMode()` convenience wrappers.
  These reuse existing synthesised sound data (no new AudioTrack allocations):
  - Synergy → `LEVEL_UP` (ascending chime)
  - Pickup → `XP_PICKUP` (light chime)
  - Endless → `BOSS_APPEAR` (bass swell)

---

## Design Principles Maintained
- **Zero GC in hot path** — All new per-frame code uses pre-allocated structures
  (`Pickup` list with 12-cap, particle pool enlarged but not replaced).
- **Save compatibility** — Only new runtime fields added. No existing SharedPrefs
  keys changed or removed. New prefs keys use distinct names.
- **No duplicate logic** — All new systems extend or call existing functions
  (`applyStatusEffect`, `spawnParticles`, `triggerShake`, `addFloatText`,
  `openChest`, `makeElite`, etc.)
- **Low-end performance** — Pickups capped at 12, particle pool at 800.
  New modifier ticks are O(1) per enemy. Synergy check is O(n_enemies) but
  gated by per-enemy cooldown so rarely runs full pass.

---

## Controls Layout (Confirmed Default)
| Element         | Position   |
|-----------------|-----------|
| Joystick        | **LEFT**  |
| Skill buttons   | **RIGHT** |

Toggle in Settings → "Controls: Joystick LEFT / Skills RIGHT".
Flip toggles to "Controls: Skills LEFT / Joystick RIGHT".
