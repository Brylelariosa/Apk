# Voxel Sandbox — Rust edition

A from-scratch Rust rewrite of the Kotlin/OpenGL ES voxel sandbox (v15). The game is one native library
(`libvoxelsandbox.so`) running inside Android's `NativeActivity`; there is no Java or Kotlin code. Gradle only
wraps the library into an APK.

See [`docs/RUST-PORT.md`](docs/RUST-PORT.md) for the architecture, what is ported and what is not yet.

## What is new in 0.8.4

* **A code audit of the drawing path and of the data it draws from, because the screen still glitched for you. It found four
  small defects and one guard was added (listed below), and nothing explains the flash of 25 November, so the flashing is not
  claimed to be fixed.** Read through for defects: `render/` (shaders, fog, composite, targets, GL bindings, programs, drawing of chunks and far
  tiles), the EGL set-up in `platform/`, `lod/mesh.rs`, `ui/batch.rs` and the UI drawing, part of `mesh/occlusion.rs`. The
  mesher itself was checked through its output (the tests below) and read only where they found something, and
  `perf/governor.rs` was searched, not read through. **Not read in this pass:** the world-map drawing (`map_gpu.rs`), the
  clouds, how far tiles hand over to real blocks, world streaming, physics and the rest of the game engine, texture mip levels,
  the menus' own logic, terrain generation. So "full" means the path from block data to pixels, not every one of the 25,000 lines.
* **The data the GPU is given is now checked by tests, on real terrain** (`mesh/audit.rs`, `lod/audit.rs`). For every chunk mesh:
  index count a multiple of 3, every index inside the vertex list, 16-bit indices only when the vertices fit (65,536 tested both
  ways), the four passes' ranges end to end and covering the list, the per-section ranges in order, every number finite, texture
  coordinates within one repeat, texture layer below 55, plants inside their footprint, heights inside the world, and every
  section's vertices inside the box the culler tests (that slack is now one constant, `SECTION_SLACK`, shared by the mesher tests
  and `render/chunks.rs`). For every far tile: at most 65,536 vertices, indices inside, the four quarter ranges in order, every
  quad inside its quarter, heights inside the tile's own min and max. Twelve deliberate damages to a mesh (an index one past the
  end, a range that is too long, a vertex 20 blocks off, ...) and ten to a far tile each make the check fail, so it is not an
  empty check. Run over more than 400 real chunk meshes (seeds 555 and 7; ordinary ground, each of the 11 biomes, a water site;
  with and without merging; with and without loaded neighbours; all four passes seen) and 126 real far tiles (levels 0 to 9, two
  seeds): **no promise was broken except the water coordinates below.** A random-orientation test (300 views, up to the look limit
  of 89 degrees) also shows that chunk culling agrees with the projection: nothing on screen is culled, nothing off screen is kept.
* **Fixed: water side faces carried the world height in their texture coordinates** (up to 64.7 where everything else stays within
  one repeat of 16). They now wrap like the top faces. The coordinates are `highp` in the shaders, so I do not think this was ever
  visible; it is fixed because the audit's rule did not hold there. In the test scenes the picture is unchanged.
* **Fixed: the GPU time in the log could be a memory.** The game's timer queries often give no valid reading (the driver calls them
  "disjoint" when the GPU changes clock or is preempted), and the last good number was kept for as long as none arrived: the
  log you sent shows `gpu-time 37.9 ms` for about four seconds while the frames in between took 28 to 40 ms, and the quality
  controller reads that number. A reading is now offered for 90 frames (about a second and a half) and then withdrawn
  (`perf/gpu_reading.rs`, 5 tests). The timer's queries are also read at the start of a frame and never while a pass is open.
* **Fixed: a run that started at 85 % resolution said nothing.** Auto performance remembers the level where the last run settled
  and starts there; in your log the first frames are at 85 % with no event before them, which looked like the game lowering
  itself at once. The log now says `auto performance: this run starts at ... (where the last run settled); the settings allow ...`
  in the first second.
* **Fixed: the blink probe reported its own cause.** Changing a view setting on the pause screen redraws the kept picture once,
  and the probe reported that expected change as a `BLINK`. It now takes the new picture as the reference.
* **Fixed: a save with a position or look that is not a number** (or a pitch past straight up or down) is no longer put into the
  camera as it is: the look is made valid, and a position that is not a place starts the player at the spawn point with the rest of
  the save (edited blocks, hotbar, flying) kept. I do not know of a way the game could write such a save; this is a guard.
* **What was checked, and how.** 361 host tests pass (339 in 0.8.3, 1 long sweep ignored); the render module type-checks; the real
  `Renderer` ran on this computer under Mesa's software OpenGL ES 3.2 through the same script of scenes as for 0.8.3 (100 %, 85 %,
  70 %, paused, the menu, route switches): 0 GL errors, 0 route-switch problems, and **all 18 pictures it takes are identical
  pixel for pixel to what the 0.8.3 build draws.** **Nothing was run on a phone or on the build server by me**, and Mesa has none of the Mali's tile
  logic, so none of this shows that the flash is gone.
* **If it flashes again**, please note the time and what you were doing, and send the log. The lines to look at: any `HITCH` just
  before it (a frame that took hundreds of milliseconds would point to the GPU being given a frame that was too heavy), the
  `frame route:` lines (does it only happen below 100 %?) and the `auto performance` lines.

## What was new in 0.8.3

* **The flashing screen: the lower-resolution drawing is rebuilt, because your screenshot and log point at it. Not confirmed on
  a phone.** The screenshot of 25 November has only two colours: the clear colour (168, 201, 237, the horizon blue) over two thirds
  of the screen and pure black over the other third (33.5 %), in a staircase whose steps are 16 pixels wide (the size of a tile the
  GPU works on), with no terrain, clouds or HUD anywhere. That is not a badly drawn world, it is a frame the GPU never finished:
  of everything the game sent for that frame only the first command, the clear, reached the screen. In the log of the same minute (`4.06pm_1`) the quality
  controller drops 100 % to 85 % resolution at 4:07:37pm (frames 22 ms, GPU 30 ms), the second you flew up, and from then on every
  frame goes through an off-screen picture. The path used up to 0.8.2 for that was: clear the screen, draw the world into a
  renderbuffer, copy it to the screen with `glBlitFramebuffer`, then tell the GPU with `glInvalidateFramebuffer` that the depth and
  the copied picture are not needed any more; the screen's own work was split in two around the picture's. I found a report of a
  Mali-G76 driver dropping screen tiles after such a split, and your Mali-G52 is the same family. I could not make it happen
  anywhere else, so this is the most likely cause I have, not a proven one. A game at 100 % resolution (no off-screen picture,
  one pass) was not reported glitchy.
  Now: the world is drawn into a **texture** in a pass of its own that starts by clearing everything, and the screen's pass (also
  starting with a clear) puts the picture on the screen by drawing **one triangle that looks the texture up** (`render/composite.rs`,
  `render/target.rs`), which is how post-processing is done in most games. Nothing is blitted, nothing is invalidated, and the
  screen is not touched before its own pass. The picture stays in the texture while the game is paused and is drawn again from
  there. The GPU timer now brackets only the world pass, so a timer query never spans two passes.
* **The decision of how a frame is drawn is its own module, with tests** (`src/frame/plan.rs`): straight to the screen, through an
  off-screen picture, or a kept picture while paused; which sizes the GPU refused; when a kept picture is still valid. 15 tests,
  among them a 30,000-frame pseudo-random course that checks every frame (a kept picture is shown again only if exactly that
  picture was kept, a refused size is never planned, no picture is made for a running game at 100 %). The debug log gets a line
  `frame route: ...` whenever the way of drawing changes, so a glitch you see can be matched to how that stretch was drawn.
* **What was checked, and how.** The 339 host tests pass (324 before, 15 new). The real renderer (`Renderer::new` and `render`,
  the code that runs on the phone) was also built and run on the machine this was written on, against Mesa's software OpenGL ES 3.2,
  through a script of scenes: 100 %, 85 % and 70 % running; paused at 85 %, 100 % and 70 %; the main menu; and 14 switches between
  them in every order. Result: no GL error, the same picture frame after frame, and for every scene a picture **pixel for pixel the
  same** as 0.8.2 draws with its blit (so the new path looks the same); a paused game draws the world once (70 draw calls) and then
  none. With a size refused by the "driver", or with the composite program failing to build, the game falls back to full-size drawing,
  again with no GL error. **What this cannot show is how the Mali-G52 reacts**: nothing was run on a phone or on the build server
  by me. If the screen still flashes, switch auto performance off and set Resolution to 100 % (a single pass, no off-screen picture)
  and send the log: the `frame route:` lines say which way each stretch was drawn.
* **The blink probe is much lighter.** It read four rows back every second frame for 600 frames, and the waiting that causes
  made hitches of its own: the `HITCH ... (MENU on screen) ... other rendering 49 ms` lines and the 42 frames a second on your
  menu are the probe. It now reads every 30th frame for 1800 frames. The three `BLINK` lines in the 25 November logs all come in
  the second you pressed a button that leaves the screen (play, resume), which is the button's highlight changing a row, not a
  glitch.
* **The `gpu-time` figure counts the world pass only** (not the menus and HUD, and not the copy of a smaller picture to the
  screen), so it reads a little lower than in 0.8.2 for the same frame. The quality controller's rules are unchanged.

## What was new in 0.8.2

* **Far forests are the colour of the real forest.** Beyond the block world, every far crown used to get a hand-picked dark
  green per tree kind, with darker walls under it, so a far forest came out about a third darker than the leaf blocks in front of
  you and met them in a hard line (the dark flat pillars in the screenshots). Far crowns are now coloured the way the mesher
  colours a leaf block: the mean of the opaque pixels of the real leaf texture, times the biome tint, times the brightness of
  the top of a leaf; the walls of a leafy column take the same colour, and the dark band at the foot of every far wall is lighter
  (0.20 instead of 0.30). A test builds a real forest tile and the far tile over it and compares them: rainforest, forest and
  taiga come out within about 5 % of the real leaves in brightness (`a_far_forest_is_the_colour_of_the_real_forest_beside_it`
  prints the numbers). Host-rendered pictures of the far terrain (a software renderer on the machine this was written on, not the
  phone) look bright and of one piece with the near leaves in the rainforest, forest, birch forest, taiga, snowy taiga and jungle.
* **Finer far terrain just past the blocks when the block world is big.** The far terrain is a clipmap of square tiles whose cells
  are 4 blocks on the finest level, 8 on the next, and so on. The finest level used to reach a fixed 512 blocks, so with a block
  world of 32 chunks (512 blocks, the most a phone can hold) the strip just past the real blocks was drawn with 8-block cells.
  The windows now follow the detail distance (`lod::tiles::Layout`): the finest level reaches at least 128 blocks past the real
  blocks, so from a detail distance of 25 chunks up the strip is 4-block cells again. At 24 chunks or fewer nothing changes. It
  costs about 100 000 far triangles (469 000 instead of 370 000 in the test world at 32 chunks, 40 more tiles), counted on the
  host, not timed on a phone.
* **Thin gaps where two levels of far terrain meet are closed.** A host audit draws the far terrain alone (camera level; every
  pixel that has terrain above it in its column and nothing drawn on it counts as a hole) from 12 views in each of 136 runs
  (3 seeds x 9 biomes x 4 detail distances, plus 7 hand-picked spots such as tile corners with 2 seeds x 2 detail distances). It
  found real see-through slits at the borders between tiles of different levels (1 to 4 pixels at 600 x 300 in 8 of the 136 runs; they
  stay put when the camera moves a little, so they are gaps in the mesh and not noise). The wall that hides the crack at the edge
  of a tile stopped at the neighbour's top or 32 blocks under its own top, and a coarse cell that stood 34 blocks above a ravine
  floor left a 2-block slit of sky under it. Edge walls now go 64 blocks (more for the biggest cells) below the lower of the two tops, which costs no triangles because the extra
  is under the ground, and their foot shading is spread over the part that shows, so they look like the walls inside a tile. After the change
  none of those 8 runs has a hole. Six other runs (3 places, 2 detail distances) had a single pixel in open ocean near the
  camera before and still have it: it comes and goes with a tiny camera move, and the pixel is one the audit's own software rasteriser
  misses where it clips a huge sea quad against the near plane, not a gap in the mesh. I do not know whether these slits were part of what you saw as blinking.
* **The blinking: not found, and now the log can tell** (0.8.3 found the likeliest cause, see above). I could not make the main menu blink here, and the logs of 22 November
  show a steady 60 frames a second in the menu with no OpenGL error and no lost context, so the cause is still unknown. What changed
  is a probe and two precautions, none of them confirmed on a phone:
  * **Blink probe.** On the main menu, the pause menu and the settings, the renderer reads four rows of the finished picture back
    every second frame for the first 600 frames of each visit (0.8.3: every 30th frame for 1800), adds up the colour bytes of each row, and writes
    `BLINK on MENU: row 2 of the picture went from ... to ...` to the debug log when a row jumps by more than 1.5 % between two
    reads (10 lines at most), and one line when the visit is over:
    `blink probe: MENU picture read 300 times over 600 frames, 0 jumps`. With `0 jumps` and a menu that still blinks on the screen,
    the picture is fine when the game hands it over and the blinking happens after that (the display or the compositor). With
    `BLINK` lines, the rows and frames say where and when it jumped.
  * **`vUv` is `highp`** in the terrain and water shaders. The texture coordinate runs along a merged face, and a 16-bit
    `mediump` float (what this phone's Mali-G52 really uses) keeps less of its fraction the longer the face is, which can make a
    texture shimmer on a long wall of blocks. Nothing in the logs says this happens; it is a hazard removed, not a cause found.
  * **The GPU timer runs only on frames that draw the world**, not on the menus.
* **Slow frames at a big detail distance are a separate problem, and the log says where they come from.** The 22 November log,
  with the real blocks at 31 chunks (about 3,000 meshed chunks), has 17 to 30 frames a second, and its own verdicts are
  `LAG: RENDERING (CPU side)` while flying high and loading (the game thread busy 33 to 46 ms of every frame: visibility culling 9 to 15 ms,
  world draw calls 10 to 20 ms) and `LAG: GPU/DISPLAY` low over the forest (1.3 to 2.4 million triangles in a frame, 1.5 million of
  them leaves, and the game thread waiting inside graphics calls for 47 to 58 ms), with hitches of 50 to 335 ms. This version does
  not change that. The next things to look at are the occlusion search (it runs again whenever chunks arrive) and the leaf
  triangles; auto performance is there for this, and steps the detail distance and the resolution down.

## What was new in 0.8.1

* **The flickering ("z-fighting") on ponds is fixed.** A lily pad used to float 1 cm above the water it lies on. The depth
  buffer cannot tell two surfaces apart when they are that close from about a hundred blocks away (there it resolves about a
  hundredth of a block, and the buffer is shared with the far terrain), so the water and the pad fought for every pixel and the
  pond shimmered and blinked as you moved. Pads now float 0.1 block above the water, which holds steady across the whole block
  world. Pads grow mostly in swamps (about three swamp chunks in four have some, counted over three worlds) and now and then in
  the shallow water of a lake, a beach or a forest where the swamp climate reaches. Nothing in the world data changed, so old
  worlds get the fix as they are.
* **How it was found.** A new test-only audit (`src/mesh/overlap.rs`) looks for faces of chunk meshes that lie on the same
  plane and overlap. Over 192 places in three worlds (close, far and mixed meshes) it found 1,438 such pairs with the old height,
  every one of them a lily pad over water, and finds none now. No other block, biome, cave or border produced any. If something
  else still blinks for you, it is not a pair of block faces on one plane; the debug log (below) is what narrows it down.
* **Far terrain after a lost GL context.** If Android takes the GPU context away (rare), the game rebuilt the chunk meshes but
  still believed the far-terrain tiles were on the GPU, so the far terrain stayed missing (holes and flicker at the edge of the
  block world). It is rebuilt now (`GameEngine::gpu_lost`).
* **The menus are drawn the way they were in 0.7.0 again.** 0.8.0 gave the menu shader a third picture to choose from, for the
  map. The menus now use the exact 0.7.0 shader and call sequence, and the map picture has a program and a texture of its own
  (`render/map_gpu.rs`, `UiBatch::runs`) that are only made when the map is first on screen, so the main menu never touches
  them. This is a precaution for a glitchy main menu that I could not reproduce here; it is unconfirmed on a phone.
* **The debug log says more about the screen.** The `# graphics:` line ends with the screen buffer the phone gave the game
  (`screen buffer: RGBA 8-8-8-8, depth 24, stencil 0, samples 0`; a 16-bit depth would make close surfaces fight at a distance),
  and the first 300 frames are checked for OpenGL errors: each one is written once, with the part of the picture it came from
  (`GL error INVALID_OPERATION (0x0502) after drawing the UI (frame 3 of the run)`). If the main menu is still glitchy, that
  file is what shows why: it is started with the first frame, so it exists even if you never get past the menu (Settings > Debug
  shows where it is).

## What was new in 0.8.0

* **A world map, on and off.** The new **MAP** button (under BIOME) turns a map in the top-left corner on and off; it lights up
  while the map is on, and the choice is remembered (Settings > Controls > *MAP IN CORNER* does the same). The map is a top-down
  picture like a world-map screen: ocean that gets darker with depth, rivers and lakes, a colour for every biome, hills shaded
  from the north-west, snow on the high peaks, and an arrow for you that turns as you turn (north is up). **Tap the map to open
  the large one**: drag it to look around, **+ / -** to zoom (2 to 32 blocks to a pixel), **ON YOU / CENTER** to come back, a
  **MINIMAP** switch, **CLOSE** (or Back). The map is made from the seed alone (`src/map`), like the biome finder, so it shows
  ground you have never visited and costs no chunk generation; it is built in 32 x 32 pixel tiles, a few rows a frame
  (2.5 ms at most), and kept in a cache.
* **Forests are forests.** A Forest, Birch Forest, Taiga or Snowy Taiga used to be thick only where a separate noise said so, so
  most of a "Forest" was open grass (0.3 % of its columns had a trunk). Tree density now follows the biome (about 2 % of columns
  have a trunk in a forest, 9 % in a jungle, 15 % in the rainforest, 0.4 % on plains), so the name and the look agree. The far
  terrain uses the same numbers.
* **Biomes look different.** Forests are a darker green, birch forests a light yellow-green, the rainforest darker than the
  jungle (grass and leaves, near and far). Biome borders are calmer: the wobble that cut them into specks of a few blocks was
  slowed down and weakened, so a biome is a patch you can walk through and not a flicker of names.
* **A much bigger Amazon, with rivers.** A very large, slow "basin" pushes the climate to hot and wet, flattens the land into a
  floodplain, removes mountains, and cuts one great river (many blocks wide, winding) with wider streams running into it and
  lakes around them. About a sixth of the world's area is basin; single basins reach 20 to 25 km².
* **Cave biomes, and caves down to the bottom.** Caves now reach y = 2, just above the bedrock (they stopped at 6), with a new
  deep layer of tunnels and bigger, commoner caverns between y 6 and 30. Caves also have biomes, from the surface climate: *Lush*
  (grass, ferns, flowers and hanging vines) under warm wet country, *Frozen* (snow and gravel) under cold, *Sand* (sand and
  sandstone) under hot dry country, and *Deep* (patches of gravel) at y 18 and below. They change only floors and ceilings.
* **Far trees look like trees.** Far forests are dark, species-coloured roofs of crowns (oak, light birch, bluish spruce) whose
  brightness varies from crown to crown, and the thickness of the far forest is the biome's, so it no longer reads as grass.
* Worlds made with an older version will show seams where new chunks meet old ones (the terrain, the trees and the caves changed).
  Start a new world to see everything as designed.

## What was new in 0.7.0

* **No more going through blocks.** Found by simulating the physics in 32-bit floats: whenever the player's head came to rest
  against a block above (a jump under leaves, a branch or an overhang) the next downward step counted that block as one the
  player was inside of, and threw them up *on top of it* (every time, in every test). Collision now only looks at the blocks
  *ahead* of the moving box, with a little slack for the coarse `f32` positions far from the origin (the slack grows with the
  distance, so it holds ten thousand blocks out too). A player who really is inside blocks (an old save, a tree that grew
  around them) climbs out of them instead of being stuck. The Amazon, where you are always jumping under leaves, is where it
  showed most.
* **Amazon trees stand on the ground.** The thick trunks (giants, Brazil-nut trees, figs) and their roots and buttresses started
  at one height whatever the ground under each corner did, so on a slope a corner hung in the air. They are now carried down to
  the ground.
* **Far terrain (LOD) with Distant-Horizons-like detail.**
  * The finest far cells are **4 blocks** wide (they were 8), the next 8, then 16 and so on (ten levels, reaching 131 km). The
    finest levels keep bigger windows of tiles (9 x 9 and 7 x 7 tiles, then 5 x 5), so the strip just beyond the real blocks is
    drawn with fine detail wherever the block world ends, and the far triangle count stays about what it was.
  * **Every far tree has its own round crown** (a dome, or a cone for spruces, as wide as the real tree's leaves), taken from the
    same tree positions the chunks use. A forest is a lumpy roof of crowns with the ground showing between them, not a field of
    poles. The leaves of single trees are lighter than the carpet used for far forests.
  * The columns of the three finest levels are looked at in a few spots and stand no higher than the real blocks at the edge of
    the block world, so there is no rim of far columns standing above the real ground.
  * With the far terrain as good as this, a smaller **real blocks distance** (10 to 16 chunks instead of 28) is the way to a
    smoother game on a phone: most of the cost in the forest is the leaves of the real chunks.

## What was new in 0.6.0

* **Water.** The three crossing sine waves are gone (at a low angle over the sea they folded into a fine woven pattern). The
  water is now a small pixel-art tile in the water colour, read twice, drifting in two directions a texel at a time, so it
  looks like the blocks around it and settles to one calm colour far away.
* **The jungle no longer flickers.** Leaves and plants are see-through textures, and the plain mip-mapping of a sparse texture
  makes it vanish a few blocks away and flicker in and out as you move. The mip levels are now made so that the leaves and
  plants keep the same share of solid texels at every distance.
* **More Amazon.** Researched from how the real rainforest is layered (emergent giants, closed canopy, understory, dark floor):
  * new trees: **palms** with arching fronds, **cecropias** (umbrella crowns on stilt roots), tall **Brazil-nut trees**, **strangler
    figs** (fluted trunks of aerial roots, broad dome, lianas) and understory **shrubs**, next to the jungle trees, rain trees
    and giants of 0.5.0;
  * trunks are dressed: **lianas climb the bark** and **bromeliads and orchids** sit on it high up;
  * the floor is a thicket of **ferns (two kinds), palm saplings, broad-leaved plants and mushrooms**, with **heliconias (red and
    yellow), orchids, bromeliads and hibiscus** growing in clumps; vines sometimes carry orange flowers; water lilies sometimes
    carry a pink bloom; the canopy and some trunks (pale and mossy, like kapok) have a second look so they are not one tone.
* **Far terrain (LOD) like Distant Horizons.** The far forest is built from the real tree positions the chunks use (so it lines up
  with the real forest, and the finest levels now have trees too); rock is as light as the real stone, with strata; slopes are
  shaded less harshly; the foot of every cliff is darker so stairs of columns read as slopes; and a haze starts at the edge of
  the block world, so far mountains fade towards the horizon instead of staying dark and crisp.
* **Performance.** The finest far tiles that real blocks already cover completely are no longer drawn (they were a large share of
  the far triangles, drawn and then thrown away by the depth test).

## What was new in 0.5.0

* **Jungle and Amazon Rainforest biomes.** Hot, wet country is now jungle (tall trees with lumpy crowns and hanging vines, a
  thicket of ferns, tall grass and hibiscus on the ground, deep green grass); where it is hottest and wettest it is the
  **Amazon Rainforest**: dense, with rainforest trees that close the canopy and **giant emergent trees** (26 to 40 blocks, a
  two-block trunk with buttress roots, side branches and a huge flat crown). New blocks: Jungle Wood, Jungle Leaves, Fern,
  Vine, Hibiscus (all in the creative inventory).
* **Biome finder.** The new **BIOME** button under the pause button opens a menu of biomes. Pick one and the game searches
  the world around you (up to 14 km, a few milliseconds of work per frame) for the nearest one and tells you how far it is and
  in which direction; **TELEPORT** takes you there.
* **Water.** The ripples are worked out per pixel instead of per vertex, so large water surfaces no longer show wide diagonal
  streaks, and deeper water is more opaque.
* **Far terrain looks more like the real thing.** Forests are a raised carpet of crowns (jungle and rainforest much taller), slopes
  that face the sun are lit and the others darker, and the jungle has its own deep green.
* **Caves** are wider, there are more big caverns and more entrances at the surface.

## What was new in 0.4.1

* **Render distance up to 5000 chunks (80 km)** and a **detail distance slider up to 500 chunks** (now a logarithmic slider).
  The far terrain has 9 levels instead of 6 and only builds the levels the render distance needs, so nothing changes at 1000
  chunks or below. The real blocks are still limited by memory: the game builds at most **32 chunks** of them (the slider shows
  `32 OF 500 CHUNKS` when you ask for more), and the far terrain covers everything beyond.
* **The frame is drawn in a better order**, with the same picture:
  * the far terrain is drawn *after* the real blocks, nearest tile first, in its own part of the depth buffer, so the GPU throws
    it away wherever blocks cover it (before it was drawn first, in no particular order, and then painted over);
  * the sky and the clouds are drawn *last* and only reach the pixels that nothing else covers (before, the sky and the clouds
    were shaded over the whole screen and then mostly painted over, which is a lot of work for a phone GPU);
  * no more depth clear in the middle of the frame.
* **Chunk meshes use 16-bit indices** (32-bit only for a mesh with more than 65,536 vertices): half the index memory and traffic.

## What was new in 0.4.0

The 0.3.0 log showed the GPU, not the CPU, was the limit (about 1,650 draw calls and 550 k triangles per frame at 24
chunks, a game thread that was busy only 30-55 % of the time). This version cuts exactly that work, and measures it.

* **Far fewer triangles and draw calls** (same test view, 24 chunks): **550 k → 241 k triangles (−56 %)** and
  **1,658 → 1,168 draw calls (−30 %)**. With *greedy meshing* switched off the same view is 818 k triangles, so the switch
  now shows a clear difference (before, the merged part was only a small share of the picture).
  * Merged (greedy) meshes start 6 chunks from the player, whatever the detail distance is.
  * Far chunks no longer build grass, flowers and lily pads (a few pixels of noise at that distance, four triangles each).
  * Flat water (open sea, calm lakes) is merged into big quads in far chunks: a chunk of sea is 1 quad instead of 256.
    The sea was 35 % of all triangles in the test view and is now under 2 %.
* **The clouds work now.** They were computed for every pixel of the sky (four noise octaves, a lot of GPU work) and then
  drawn completely transparent because of a fade-out bug. They now come from one small repeating noise texture
  (`tex/cloud_noise.rs`), cost a texture lookup, drift with the wind, and are visible.
* **Cheaper shaders.** Half-precision (`mediump`) interpolation, fog worked out per vertex instead of per pixel, no
  `discard` in the solid-block shader (so hidden pixels are rejected early), separate solid / leaf / plant / water passes,
  and all shaders compiled at start-up (no stall the first time grass or water is seen).
* **Auto performance** (Settings → Graphics, on by default). When the phone cannot hold about 60 fps the game lowers the
  *detail distance* first (the far terrain takes over beyond it, still blocky), then the resolution a little, and tries to give
  them back after a long stretch of smooth frames, taking a step back if that was too much. Your own settings are only
  ever the maximum. The level it settles on is remembered for the next launch (`quality.txt`), so there is no stuttery
  minute at every start. Switch it off to get exactly your own settings.
* **A paused game no longer redraws the world** behind the pause menu 60 times a second: the picture is drawn once and
  copied (about 16× less work, cooler phone).
* **The debug log knows more.** Every line has the GPU's own time per frame when the phone can measure it
  (`gpu-time 14.2ms/frame`), and the triangles and draw calls of each pass (`far / solid / leaves / plants / water`).
  EVENT lines say what auto performance did and why (`auto performance: 24 chunks at 100% -> 20 chunks at 100% (frames are
  very slow; frames 31.1 ms)`) and which settings you changed (`setting changed: greedy meshing: on -> off`). The FPS
  overlay shows `AUTO: 12 CHUNKS, 85%` while the quality is lowered.

## What was new in 0.3.0

* **Real full-screen.** The navigation bar and the status bar are hidden (immersive mode). Swiping in from the
  edge shows them for a moment and they hide again by themselves. The game draws behind the camera cut-out.
* **Render distance up to 1000 chunks** (16,000 blocks; 5000 since 0.4.1). Settings → Graphics has a slider, `-` / `+` buttons that
  repeat while you hold them (and speed up), and a **MAX** button. Only the *detail distance* (4–24 chunks, default 10)
  is built from real blocks; everything beyond it is **far terrain**: the same world drawn as big blocky
  columns in 6 coarser levels (9 since 0.4.1), so it still looks like a voxel game and costs very little.
* **Optimisations**, all of them switchable or automatic:
  * greedy meshing (chunks away from the player are built from merged quads: about a quarter fewer triangles),
  * frustum culling (chunks and 16-block sections outside the view are not drawn),
  * occlusion culling (sections that are shut off by rock, such as caves, are not drawn; about 13 % fewer triangles),
  * far-terrain LOD (see above), time-sliced mesh uploads, a render-resolution setting.
* **A debug log in the Download folder** that says what the game was doing every second (below).

## The debug log (send me this when the game lags)

Settings → Debug → *DEBUG LOG FILE* (on by default). The file is `VoxelSandbox-log_<date>_<time>.txt`, for example
`VoxelSandbox-log_2026-11-09_1.20pm.txt`.

* **Where:** the phone's **Download** folder (Android 10 and newer: created through MediaStore, no permission needed).
  On Android 7–9 it is written to Download only if you allow *Storage* for the app in the system settings; otherwise it
  goes to `Android/data/com.voxelsandbox.game/files/`. The Settings → Debug screen always shows where the file is.
* **Format:** one line every second, starting with the phone's clock in 12-hour style (`1:20:05pm`), then fps, the
  milliseconds the game thread spent in *input / update (calculation) / render (drawing work) / swap-wait (waiting for the
  GPU)*, CPU use, world and queue sizes, GPU uploads, draw calls and triangles, and at the end the verdict:
  `=> smooth`, `=> LAG: CALCULATION`, `=> LAG: RENDERING (CPU side)`, `=> LAG: GPU/DISPLAY` or `=> LAG: CPU STARVED`,
  with the part that cost the most. Single slow frames get their own `HITCH` line, and every minute ends with a
  `---- 1:20pm summary ----` block. The top of the file explains every column and lists the phone, the GPU and the settings.
* **It does not cost frames.** The game thread only adds a few numbers to counters (a relaxed atomic add) and hands one
  small record per second to a separate lowest-priority thread that formats and writes the text. If that thread is busy
  the record is dropped, never waited for. The file stops growing at 16 MB. Turn the switch off and nothing is measured.
* **To send it:** open a file manager → Download → share the `VoxelSandbox-log_….txt` file (or open it and copy the part
  around the time it lagged).

## Build (GitHub Actions, as before)

Upload the ZIP to `uploads/` like every other project. The build needs nothing from the workflow except what a GitHub
runner already has (Rust with rustup/cargo, and the Android NDK): Gradle's `buildRust` task (the `rust-android` plugin
in `buildSrc/`, see `docs/RUST-PORT.md`) installs the Rust Android target with rustup if it is missing, compiles the
library with cargo and the NDK's clang for the ABIs in `gradle.properties` (`rustAbis=`), puts it into
`app/src/main/jniLibs`, and then Gradle packages the APK. There is no cargo-ndk to install. If a workflow builds the
library in an earlier step, pass `-PrustPrebuilt=true` to Gradle and `buildRust` is skipped.

The Android crates are `android-activity` 0.6.1 or newer 0.6.x and `jni` 0.21.x; cargo fetches them.

If "Build APK" fails with `Downloading ... gradle-8.6-bin.zip failed: timeout`, it is the network, not the code: re-run
the failed job. (The Gradle wrapper waits up to 2 minutes for its download; see `networkTimeout` in
`gradle/wrapper/gradle-wrapper.properties`. The default of 10 seconds is too short on a slow day.)

## Build locally

```
cargo test --lib                      # the logic tests run on any computer
./gradlew assembleDebug               # cargo + the NDK build the Rust library, then the APK
```

Gradle finds the NDK through `ANDROID_NDK_HOME` (or `ANDROID_NDK_ROOT`), `ndk.dir` in `local.properties`, or the newest
`ndk/<version>` folder of the Android SDK. Options: `-PrustAbis=arm64-v8a,x86_64`, `-PrustProfile=dev`, `-PrustPrebuilt=true`.
