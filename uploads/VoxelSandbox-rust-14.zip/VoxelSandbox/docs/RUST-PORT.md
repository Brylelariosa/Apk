# Rust port notes

## Layout

| Path | What lives there | Builds on a PC? |
|---|---|---|
| `src/core` | maths, Kotlin-exact `Random` (so seeds shuffle noise like before), logging, fast hasher, clock, thread pool | yes |
| `src/world` | blocks, chunks (copy-on-write sections), fluids, world storage, streaming with worker threads | yes |
| `src/gen` | noise, climate, land shape, caves, trees, chunk generator — a 1:1 port of the v15 generator | yes |
| `src/mesh` | chunk mesher (culling, ambient occlusion, cave darkening, biome tint, water, plants, merged "greedy" quads), per-section visibility graph, occlusion culling | yes |
| `src/map` | the world map: palette, 32 x 32 tiles built a few rows a frame, the tile cache, the view (on/off, size, zoom, panning) and the picture the renderer uploads as one texture | yes |
| `src/lod` | far terrain: clip-map tiles, the cell sampler, the blocky tile mesher, the tile manager with its worker threads | yes |
| `src/tex` | the 34 pixel-art tiles (generated from the Kotlin tables by `tools/gen_tiles.py`) + texture array data, and the tileable cloud noise (`cloud_noise`) | yes |
| `src/game` | player, physics, flight, raycast, placement, hotbar, settings, saves, engine | yes |
| `src/ui` | pixel font, 2D batch, touch tracking, HUD, all screens (`ui/app.rs`, `ui/app/settings_screen.rs`) | yes |
| `src/diag` | the debug log: probes, per-second recorder, background writer, verdicts, `/proc` readers | yes |
| `src/frame` | which way a frame's picture of the world gets to the screen (straight, through an off-screen picture, or a kept picture while paused): `plan::Planner`, `Route`, `PictureKey`, `scaled_size`, `RouteLog` | yes |
| `src/perf` | the automatic quality control (`governor`: ladder of block distance / resolution, up and down rules) and its memory (`memory`) | yes |
| `src/render` | OpenGL ES 3.0 renderer (real chunks in four passes, far terrain, sky, clouds, the off-screen target and the triangle that puts it on the screen), shaders, GPU timer, warm-up | Android only |
| `src/platform` | EGL, NativeActivity event loop, touch + back key, full-screen (`sysui`), the log file in Download (`storage`, `device`, `logging`), JNI plumbing (`java`) | Android only |

Everything except `render` and `platform` is plain Rust and is unit-tested on any computer (`cargo test --lib`; it needs
no Android tools). `render` cannot be unit-tested (it is Android-only), so what it decides that can be decided without a GPU lives
in `frame`. For 0.8.3 the real `Renderer` was also built on a computer (the `render` module un-gated, EGL surfaceless + a pbuffer) and
run against Mesa's software OpenGL ES 3.2 through a script of scenes, see "The flashing (0.8.3)" below; `platform` is only
type-checked off the phone.

## Build chain

`app/build.gradle.kts` applies the `rust-android` plugin from `buildSrc/`. It is plain Java, so it needs nothing but the
JDK and Gradle to compile. Its `buildRust` task runs before the APK is packaged and does what `cargo-ndk` would do,
without needing it installed:

| Class (`buildSrc/src/main/java/rustandroid`) | Job |
|---|---|
| `AndroidAbi` | one place for the three names of an ABI: the APK folder (`armeabi-v7a`), the Rust target (`armv7-linux-androideabi`) and the NDK clang prefix (`armv7a-linux-androideabi`) |
| `NdkToolchain` | finds the NDK (`ANDROID_NDK_HOME` and friends, `ndk.dir`, the newest `ndk/<version>` of the SDK), picks the clang wrapper for the app's minSdk, and makes cargo use it: `CARGO_TARGET_<TRIPLE>_LINKER`, `CC_<triple>`, `AR_<triple>` |
| `RustTargets` | `rustup target add <triple>` when the Android standard library is not installed yet |
| `CargoBuildTask` | per ABI: `cargo build --lib --target <triple> --profile <p>`, then copies `lib<name>.so` to `src/main/jniLibs/<abi>/` |
| `RustAndroidPlugin`, `RustAndroidExtension` | the `rustAndroid { libraryName, abis, apiLevel, profile }` block, and making the Android plugin's `preBuild` and `merge*JniLibFolders` tasks wait for `buildRust` |

The plugin knows nothing about this game, so the `buildSrc/` folder can be copied into any other Rust + Android project.
Properties: `rustAbis` (default in `gradle.properties`), `rustProfile` (default `release`), `rustPrebuilt` (skip the Rust build).

## Threads

* The **main thread** owns the world and the GL context and runs the frame: input, update, render, swap.
* **Worker threads** (up to 3) generate chunks, build chunk meshes and build far-terrain tiles from cheap snapshots
  (chunk sections are `Arc`s, so a snapshot is a few pointer copies and an edit copies only the section it touches).
  Results come back through channels; the renderer uploads a time-sliced number of meshes per frame.
* **`vs-log`** is the log writer (`diag::sink`): lowest priority (nice 19), the only thread that touches the log file.

## Render distance, detail distance and far terrain

* **Render distance** is in chunks (16 blocks), 4 to 5000 (= 80,000 blocks). Settings has a logarithmic slider, `-` / `+`
  buttons that repeat while held and accelerate, and a MAX button.
* **Detail distance** (4 to 500 chunks, default 10, never above the render distance) is the radius of real blocks: chunks are
  generated, meshed, edited and collided with. This is the expensive part, so the game never builds more than
  `MAX_REAL_BLOCK_CHUNKS` (32) chunks of real blocks, whatever the slider says: a chunk column takes about 0.3 MB, so 500 chunks
  (some 800,000 columns) cannot fit in a phone. The slider then reads, for example, `32 OF 500 CHUNKS`.
* Beyond the detail distance the world is drawn as **far terrain** (`src/lod`), so a 5000-chunk view does not mean a 5000-chunk
  world in memory. It is a clip map of 9 levels (a render distance of 1000 chunks uses the first 6). A level-`k` cell is
  `8 << k` blocks (8, 16, 32 … 2048), a tile is 32 × 32 cells,
  and each level keeps a 5 × 5 window of tiles around the player (level 8 reaches about 131,000 blocks). A tile is made of four
  quarters, and each quarter is one tile of the next finer level, so a finer tile can take over a quarter without a crack
  (the coarse tile just skips that quarter: a "hole").
* The far terrain **looks like blocks on purpose**. Each cell is one flat-topped column with one height and one colour, taken
  from the same generator as the real world (coarse levels sample fewer noise octaves, level 0 takes the lowest of five probes
  so a far column never pokes above the real blocks). Side walls exist only where the neighbour is lower, and on tile and
  quarter borders they always reach down `clamp(4 × cell, 32, 256)` blocks so two levels never show a gap. Sea cells are merged
  into big flat rectangles. A little per-cell brightness noise (the same on both sides of a tile seam) and the baked
  top / north-south / east-west shading keep the stepped look. There are no smooth normals and no vertex blending.
* A tile is 16-byte vertices (`f32 × 3` position + RGBA8 colour) and `u16` indices, one VAO per tile, one draw call per tile
  (a few more when quarters are holes). Draw order (`Renderer::draw_world`): everything opaque is drawn nearest first, so the GPU
  rejects what is hidden before shading it. The real blocks come first (solid, leaves, plants) in the first 60 % of the depth
  buffer (`glDepthRangef`), then the far terrain, nearest tile first, in the rest (out to the fog end, with a near plane that
  grows with the view distance, so an 80 km view keeps its depth precision), then the sky and clouds at depth exactly 1.0, so
  they are only shaded where nothing else was drawn, then the aim outline and the water. There is no depth clear in the middle
  of the frame. Fog blends blocks and far terrain. Underwater the far pass and the sky are skipped.

## Optimisations

Numbers are from a fixed test world and camera (seed 555, 24 chunks of real blocks, 900 × 405), run headless against Mesa.

| What | Where | Effect |
|---|---|---|
| Greedy ("merged") meshing: chunks 6 or more chunks from the player (`Settings::MERGE_FROM_CHUNKS`, independent of the detail distance, so the quality control can change the detail distance without rebuilding the world) are built from merged quads of up to 8 × 8 blocks; the nearer chunks keep the exact per-block look. Hysteresis stops a chunk being rebuilt back and forth at the border. | `mesh/mesher.rs` | 818 k → 241 k triangles together with the next two rows (1,658 → 1,168 draw calls) |
| Merged chunks leave out plants (grass, flowers, lily pads). | `mesh/mesher.rs` | plants 107 k → 9 k triangles, 539 → 49 draw calls (greedy off → on) |
| Merged chunks join flat water surfaces (all four corners at the same height) into quads of up to 16 × 16 blocks; sloping shore cells keep their own quads. | `mesh/mesher.rs` (`WATER_TOP` layer of the merge masks) | water 144 k → 4 k triangles (greedy off → on) |
| Frustum culling: columns are classified Outside / Partial / Inside, and for Partial ones each 16-block section is tested. | `render/chunks.rs`, `mesh/visibility.rs` | fewer draw calls and triangles |
| Occlusion culling: a section is only visited if a ray from the camera can get into it through the open faces of the sections in front of it (a 15-bit connectivity set per section, a search per octant). Conservative: it may draw a hidden section, it never hides a visible one (checked against an 84,000-ray reference). | `mesh/occlusion.rs` | about 13 % fewer triangles |
| Four passes for the blocks: solid (no `discard`, nearest first, so hidden pixels are rejected early), leaves and plants (alpha-tested), water (blended, far to near). | `render/programs.rs`, `render/shaders.rs`, `render/chunks.rs` (`draw_opaque/cutout/plants/water`) | cheaper pixels, early depth rejection |
| `mediump` varyings, fog per vertex (`render/fog.rs`), water ripple per vertex, cloud shape from a 256 × 256 noise texture instead of four noise octaves per pixel (this also fixed the clouds being drawn invisible), a smaller sky shader. | `render/shaders.rs`, `tex/cloud_noise.rs` | the sky and cloud passes cost a few lookups instead of a few hundred operations per pixel |
| All shaders are compiled at start-up by drawing one tiny triangle with each (`Renderer::warm_up`), so there is no 100-200 ms stall the first time a new shader is used. | `render/renderer.rs` | no first-use hitches |
| Auto performance (`perf/governor.rs`): a ladder of (detail distance, resolution) levels derived from the player's maxima; down after 2 slow seconds (or at once, by 2-3 levels, for very slow ones), up only as an experiment after 20+ smooth seconds, with doubling back-off after a failed try; GPU time (timer queries) shortens the wait when the GPU has room. The settled level is remembered (`perf/memory.rs`). | `perf/*`, `ui/app.rs` (`game_settings()` = player's settings, lowered) | holds ~60 fps on weak phones by itself |
| The paused world is drawn once into an off-screen texture and put back on the screen by one triangle that samples it (`world_frozen`, `frame::PictureKey`). | `frame/plan.rs`, `render/renderer.rs`, `render/target.rs`, `render/composite.rs` | about 16× less work behind the pause menu |
| Far-terrain LOD (above): the part of the view beyond the detail distance costs a few hundred draw calls instead of thousands of chunks. | `src/lod`, `render/far.rs` | what makes 1000 chunks possible |
| Time-sliced GPU uploads, fast hash maps, back-face culling in the far pass, a render-resolution setting (off-screen texture target put on the screen by a full-screen triangle, UI stays at native resolution; up to 0.8.2 the depth was invalidated before a blit so tile-based GPUs would not write it to memory, 0.8.3 left that out on purpose, see "The flashing (0.8.3)"). | `render/*`, `core/fasthash.rs` | smoother frames |

Greedy meshing, occlusion culling and auto performance have switches in Settings → Graphics, so the effect can be compared on the
phone. **Draw calls and triangles** are the GPU cost; if the log says `LAG: GPU/DISPLAY`, look at the `gpu-time` figure and at the
per-pass triangles at the end of the line, and at the `auto performance:` EVENT lines.

### GPU timing

`render/gpu_timer.rs` wraps each frame in a `GL_TIME_ELAPSED_EXT` query (extension `GL_EXT_disjoint_timer_query`, using the
core ES 3.0 query entry points), keeps a ring of four queries so nothing waits for a result, ignores results when the driver
reports a disjoint event, and turns itself off if the driver raises an error on first use. The latest value goes to the log line
(`gpu-time`) and to the governor. On phones without the extension both simply work from the frame times.

## Full-screen

`platform/sysui.rs` hides the status bar and the navigation bar by calling the framework through JNI on the Java UI thread
(no Java code): `WindowInsetsController` on Android 11+, the immersive `setSystemUiVisibility` flags before that. It runs when
the window is created, when focus returns, and when the app resumes (the system shows the bars again after the notification
shade or a dialog). A swipe from the edge shows the bars for a moment and they hide again. The theme also sets
`windowFullscreen` and, on Android 9+, `windowLayoutInDisplayCutoutMode = shortEdges` so the picture goes behind the camera cut-out.

## The debug log (`src/diag`, `platform/{storage,device,logging}.rs`)

Written to the Download folder as `VoxelSandbox-log_<date>_<12-hour time>.txt`, one line per second with the phone's clock
(`1:20:05pm`), then per-stage times of the game thread, worker activity, GPU uploads, draw calls, triangles, far-tile
counts, process CPU, memory and temperature, and a verdict:

| Verdict | Meaning |
|---|---|
| `smooth` | at the display's rate |
| `LAG: CALCULATION` | the game thread was busy with logic, streaming, menus (the biggest part is named) |
| `LAG: RENDERING (CPU side)` | the game thread was busy preparing and submitting drawing work (named: upload, culling, draw calls, UI…) |
| `LAG: GPU/DISPLAY` | the game thread was waiting for the GPU or the screen |
| `LAG: CPU STARVED` | the game thread was neither busy nor waiting: other apps or heat throttling took the CPU |
| `HITCHES` / `HITCH` line | isolated frames over 50 ms, with the stage that took the time and the queue sizes |

Each minute ends with a `---- 1:20pm summary ----` block (average / lowest fps, seconds per verdict, most costly parts).
The top of the file lists the phone, Android version, GPU, screen, settings and a legend.

**Why it does not make the game lag:** the game thread only does relaxed atomic adds (`probe::scope`, `probe::count`) and, once a
second, hands one small record to a bounded channel with `try_send`. A full channel drops the record. The formatting, the file
IO and the `/proc` reads happen on `vs-log` at the lowest priority. Past 12 MB only summaries, hitches and events are written;
past 16 MB nothing more. When the setting is off nothing is measured and no file is made.

**Where the file goes:** Android 10+: `MediaStore.Downloads` through JNI (no permission). Older Android, or if MediaStore
refuses: `<storage>/Download` (needs the Storage permission, declared for Android 9 and older only), then `/sdcard/Download`,
then the app's own folder. Settings → Debug always says where the file really is. A panic is also written to the log
(and to `last_panic.txt` for the main menu) before the app dies.

## Ported

World generation (continents, rivers, lakes, swamps, mountains, climate biomes, caves, ores, trees, plants),
terrain meshing with ambient occlusion and biome-tinted grass/leaves, animated-height water, procedural clouds
and sky, fog, walking + creative flight, double-tap-jump flight, auto-jump, break / place, "laser" tunnel tool,
fluid simulation, hotbar + creative inventory, touch HUD (joystick, look pad, buttons), settings, world saving,
far-terrain LOD, greedy meshing, frustum and occlusion culling, the debug log.

## Not ported yet

* HUD customise mode (drag / resize buttons), break particles, creative-inventory search, a crash *share* screen
  (the main menu shows "VIEW LAST ERROR REPORT" after a panic; the debug log has the same information).
* The region packer (the renderer still uses one mesh per chunk column).
* Far terrain does not show trees, water waves or caves (it is a height field with one colour per cell), and it is not edited
  when you break blocks inside the detail radius (the real chunks cover that part anyway).

## Saves

`world.bin` in the app's private files directory: seed, player, hotbar and every *edited* chunk (run-length coded).
Untouched terrain is regenerated from the seed, and the far terrain is generated from the same seed. The format is new
(v15 saves are not readable).

## Diagnosing a problem on a phone

* **Lag:** the debug log (above). Send the `VoxelSandbox-log_….txt` file from Download.
* A panic anywhere is written to `last_panic.txt`; the main menu then shows "VIEW LAST ERROR REPORT".
* Shader compile errors are drawn on screen.
* CI prints the cargo output and the unit-test summary; on failure the cargo logs are uploaded with the reports.

## Biomes, the finder and the far-terrain look (0.5.0)

* **Jungle and Rainforest** (`gen/climate.rs`): hot (ground temperature >= 0.50) and humid (> 0.30) land is jungle; at >= 0.58 and
  > 0.50 it is the Amazon-style rainforest. Trees: `TreeSpecies::Jungle` (7-13 block trunk, lumpy crown, vines), `RainTree`
  (13-21, wide crown, flared roots) and `Giant` (26-40, a 2x2 trunk, buttress roots, three branches and a crown of stacked discs
  up to 8 blocks from the trunk), all with Jungle Wood / Jungle Leaves and `Block::Vine` strands hanging from the crown. `TREE_REACH`
  is 9 so that a giant's crown is built identically by the chunks it spans. The forest floor gets `Fern`, tall grass and `Hibiscus`.
  Grass turns deep green with `Climate::lushness`; ferns, vines and jungle leaves take the biome tint like grass and leaves do.
  Blocks 26..30 and texture layers 37..42 are new (`tools/gen_jungle_tiles.py` made the tiles).
* **Biome finder** (`game/biome_search.rs`, `ui/app/biomes_screen.rs`): the BIOME HUD button opens a menu of biomes. The search
  samples `TerrainGenerator::biome_guess` (the land form with fewer details, about 20 times cheaper than `biome_at`) on square
  rings every 48 blocks out to 14,000 blocks, a few milliseconds of work per frame, refines the hit with `biome_at`, and TELEPORT
  uses the same mechanism as a new game (`GameEngine::teleport`: wait for the column, then drop the player to the surface).
* **Far terrain** (`lod/sampler.rs`): from level 1 up (beyond the real blocks) a forest is a raised carpet of crowns, 5-8 blocks
  for ordinary forests, 15 for jungle and 24 for rainforest; slopes are lit from a fixed sun direction (flat ground is unchanged);
  the random brightness of a column is smaller (7 %).
* **Water** (`render/shaders.rs`): the ripples are three crossing waves per pixel (wave numbers are multiples of 2 pi / 16 so they
  repeat where the texture coordinates wrap), and deeper water is more opaque.

## Water, Amazon vegetation, mip levels and the far terrain (0.6.0)

* **Water** (`tex/mod.rs::water_pixels`, `render/shaders.rs`): the water layer is a 16x16 tile made in code (value noise that wraps,
  given out in four brightness steps by rank, so it averages to `WATER_RGB`). `WATER_FS` reads it twice with drifts that move in whole
  texels and wrap every block; the mip levels average it with distance, which is what removes the moire the sine waves made.
* **Coverage-preserving mip levels** (`tex::build_mip_chain`, uploaded by `create_block_texture` instead of `glGenerateMipmap`): colour is
  the plain box average; the alpha of a layer with see-through texels is scaled per level so that the share of texels with alpha >= 0.5
  (what `ALPHA_TEST` keeps) stays what it is at level 0. This is the fix for foliage that shimmered or vanished with distance.
* **Plant variants** (`mesh/mesher.rs::plant_layer`): `Fern` is drawn as fern, fern B, broad leaf, palm sapling or mushroom, `Hibiscus` as
  hibiscus, red or yellow heliconia, orchid or bromeliad (high above the ground, `up >= 3`, only orchids and bromeliads: the air plants
  `dress_trunk` places), `Vine` sometimes flowers, `LilyPad` sometimes has a bloom. `jungle_variant` gives jungle leaves and bark a second look per 8x8 / 4x4
  patch of the world (not per block, so merged far chunks still merge). Tiles 43..54 (`tools/gen_amazon_tiles.py`); no new block ids
  (the id space is 5 bits and only 31 is left).
* **Trees** (`gen/trees.rs`): `Palm`, `Cecropia`, `BrazilNut`, `Fig`, `Shrub` join `Jungle`, `RainTree`, `Giant`; `dress_trunk` adds climbing
  lianas and air plants. Every shape stays within `TREE_REACH` (9) of its trunk. `TerrainGenerator::pick_species` sets the mix.
* **Far terrain** (`lod/sampler.rs`, `lod/mesh.rs`, `render/far.rs`): levels 0..3 call `TerrainGenerator::tree_spot` (4 x 4 tree cells per far
  cell at most) for the real tree heights and species brightness, levels 4+ keep the typical-height carpet; `raised_top` never looks at the
  slope so a tile's ring agrees with its neighbour's cells. Rock is the real stone mean with 5-block strata, `SHADE_MIN` is 0.78, walls
  have a darker foot, `FAR_VS` hazes with `t * (2 - t)` from the edge of the block world, and `covered_quarters` leaves out the quarters of
  level-0 tiles that lie inside the block world and whose chunks are all meshed.


## World map (0.8.0)

* `map::palette` colours a column (biome colour, water depth, snow on high rock, hill shading from the north-west).
* `map::tile` builds one 32 x 32 pixel tile from `TerrainGenerator::map_column` (height and biome at a detail level that fits the
  zoom), a few rows at a time, so no frame is held up; a tile is a pure function of the seed and its key.
* `map::cache` keeps built tiles (least recently used goes first). `map::view::MapView` holds what the player asked for (on/off,
  corner or large, zoom, panning), builds missing tiles nearest the middle first within a time budget, composes the picture, and
  raises `serial` when its pixels change.
* The renderer hands the picture to `render/map_gpu.rs` (`MapGpu`): it uploads it to a texture of its own (unit 3) when `serial`
  changes and draws it with a program of its own (`MapProg`, `MAP_FS`). Neither exists until the map has something to show, and a
  driver that refuses them only costs the map (see "The menus and the map picture" below). `ui/map_hud.rs` draws the picture, the
  arrow and the compass; `ui/app/map_screen.rs` is the large map.

## Cave biomes (0.8.0)

`gen/cave_biome.rs` decides the biome of the underground from the surface climate plus a slow noise of its own, on a 4-block
lattice, and dresses the floors and ceilings of what `gen/caves.rs` carved. It only looks up and down, so a chunk decorates
identically alone or next to its neighbours. The deep (y <= 18) is its own biome. `TerrainGenerator::cave_biome_at` and
`CaveCarver::biome_at` read it.

## Z-fighting and the depth buffer (0.8.1)

* **The buffer.** `platform/egl.rs` asks for a 24-bit depth buffer and falls back to 16 bits; the `# graphics:` line of the debug
  log ends with what it got (`Egl::config_summary`: `screen buffer: RGBA 8-8-8-8, depth 24, stencil 0, samples 0`, -1 for what the
  driver did not report). The block world uses the depth range 0 .. 0.6 and the far terrain 0.6 .. 0.9999 (`render/renderer.rs`),
  so far terrain never fights blocks. Inside the block world (near plane 0.1) a 24-bit buffer separates surfaces that are at least
  about `1e-6 * d * d` blocks apart at distance `d` (0.01 at 100 blocks, 0.09 at 300). Keep every deliberate gap between two
  surfaces at 0.1 block or more, and do not put two different faces on one plane.
* **The cause found.** Lily pads were drawn 0.01 above the water (`fy - 0.115`). They are drawn before the water (alpha-tested,
  writing depth) and the water after (depth-tested), so the two fought wherever a pond was a hundred blocks away or more.
  `LILY_PAD_LIFT` in `mesh/mesher.rs` is now 0.1. Pads are placed where `swamp_water` holds (water at most `LILY_MAX_DEPTH` deep
  and `Climate::water_biome` says swamp): in about three swamp chunks in four, about 13 in 100 beach chunks, and fewer than 3 in 100 of
  the chunks of lakes, forests, plains, oceans and the Amazon basin (counted over 3 worlds, sampling 6,400 chunks in each).
* **The detector** (`mesh/overlap.rs`, test-only): `faces_of` turns a chunk mesh into its flat axis-aligned rectangles and
  `fights` pairs the ones on one plane (within a tolerance) that overlap by at least 0.05 block, face the same way (or one is
  water, which is drawn with both sides showing) and do not look alike. Tests: the detector itself, the pad clearance, swamp,
  Amazon and other biome sites with close, far and mixed meshes, and an ignored sweep over 192 places for hunting
  (`cargo test --lib sweep -- --ignored --nocapture`). With the old height the sweep reports 1,438 pairs, all lily pad against
  water; now it reports none. It only sees faces of chunk meshes: far terrain, sky, clouds and the UI are not covered.
* **A lost GL context** (`Shell::reset_gl`) calls `GameEngine::gpu_lost`, which makes every chunk mesh again
  (`WorldManager::invalidate_all_meshes`) and clears the far manager (`FarManager::clear`), because its `present` set means "the
  renderer has this tile".

## The menus and the map picture (0.8.1)

* **One program for the menus.** `UI_FS` is the 0.7.0 shader again (the block-texture array and the font), and `Renderer::draw_ui`
  sets up exactly the textures, uniforms and state it did then. The map picture is the one thing that is not drawn by it: the
  UI batch keeps its vertices in draw order, and `UiBatch::runs` cuts it into `Run`s of `RunKind::Ui` (the UI program) and
  `RunKind::Map` (vertices on `LAYER_MAP`, drawn by `MapGpu::begin_draw`). A batch without a map is one `Ui` run, so a screen
  with no map (the main menu always) makes the same GL calls as 0.7.0. Order is kept, so a button over the map still covers it.
* **Lazy and loseable.** `MapGpu` makes its texture on the first upload and its program on the first draw. If the program does not
  build, it logs that once (`the world map cannot be drawn: ...`) and does not try again; the map vertices are skipped and
  nothing else is affected. After a lost GL context `MapGpu::forget` starts it over.
* **Errors in the log.** `diag::gl_errors::ErrorWatch` (host-tested; the renderer only supplies `glGetError`) reads the GL error
  flag in the first 300 frames, after the start of the frame, the meshes, the world or sky, and the UI. Each (error, stage)
  pair is reported once, at most 24 lines, through `diag::note`, which never waits for the log writer.
* **Not verified on a phone.** Nothing in `render/` or `platform/` runs on the machine this was written on (no OpenGL ES, no
  NDK): the renderer is only type-checked there (`cargo check` with `render` un-gated) and `platform/` is compiled by the build.
  The 0.8.0 glitch on the main menu was reported but could not be reproduced, so this change is a precaution, not a confirmed fix.

## Far terrain: colour and the finest ring (0.8.2)

* **Crown colours come from the leaf tiles.** The far canopy used constants chosen by eye, and a far forest came out about a
  third darker than the leaf blocks beside it, with a hard line where the two met. `lod/sampler.rs` now builds the colour the way the
  mesher does: `LeafColors` holds the mean of the opaque texels of the oak, birch, spruce and jungle leaf tiles (the jungle one
  is a mix of its two tiles), and `FarSampler::leaf_color` tints it with the biome's grass colour over the palette anchor, taken
  `LEAF_STRENGTH` of the way (the mesher keeps the tint in a byte that holds half the value, so it is at most 2).
  `ground()` blends that colour into the top and into the wall of a leafy column: 0.92 of it for a column under the crowns of single
  trees (times how much of it they cover) and for the tropical forests, 0.8 times the tree cover elsewhere. A crown is the full leaf
  colour (the baked brightness of the top of a leaf is 1.0), a carpet of forest `CARPET_SHADE` (0.9) of it; the variation between
  crowns is `CROWN_VARIATION` (0.20) and the ground-tone noise is `TONE_STRENGTH` (0.6) of what it was. The dark band at the foot of a
  tall wall is `FOOT_DARKENING` (`lod/mesh.rs`), now 0.20 (it was 0.30).
* **The check** is the test `a_far_forest_is_the_colour_of_the_real_forest_beside_it`. For a rainforest, a forest and a taiga it
  meshes real chunks over a tile (close and merged), averages the colour of the upward leaf faces as the GPU would draw them
  (tile colour times tint times baked shade), and compares that with the mean colour of the far cells that stand under leaves:
  brightness within 15 % and the same hue ratios (the test prints the numbers; in the run recorded here the brightness (luma) was
  77 against 78 in the rainforest, 83 against 87 in the forest and 65 against 64 in the taiga).
  Host pictures (`examples/viewshot` of the scratch harness, a software rasteriser that is not in the tree) of rainforest, forest,
  birch forest, taiga, snowy taiga and jungle show the far canopy bright and of one piece with the near leaves.
* **`Layout`** (`lod/tiles.rs`) replaces the free functions that gave every level the same window whatever the block world: it holds
  the window (tiles to each side of the player's tile) of every level for one size of block world. The finest level wants
  `ceil((detail_blocks + FINE_RING) / 128)` tiles, at least the base 4 and at most `MAX_FINE_WINDOW` (6), so it reaches `FINE_RING`
  (128) blocks past the real blocks; every level after it keeps its base window or what is needed to cover the one inside it.
  `FarManager::update` takes `detail_blocks` (the engine passes `settings.detail_radius() * 16`), keeps a tile until it is one tile
  past its window (`keep_radius`) so that a smaller block world does not rebuild anything, and `clear` resets the layout. Up to 24 chunks
  of real blocks nothing changes (4 tiles reach 512 blocks); at 32 chunks (512 blocks, the cap, `MAX_REAL_BLOCK_CHUNKS`) the finest ring
  is 5 tiles: 11 x 11 tiles instead of 9 x 9 (40 more) and about 100 000 more far triangles in the test world (469 000 against 370 000,
  `layoutcost` of the scratch harness). The phone has 28 to 31 ms of GPU time a frame at 3,000 meshed chunks (see below), so this is
  paid for only where the picture needs it, and only by the largest block worlds.
* **Cracks between levels (`wall_drop`, `emit_quarter`, `Builder::wall` in `lod/mesh.rs`).** A wall along the edge of a tile (and
  between the quarters of a tile of level 1 or more, where a finer tile may sit) hides the crack between tiles of different
  levels, whose cells are sampled at different sizes and so disagree by the relief inside a cell. It used to stop at the neighbour's
  top or `wall_drop` under its own top, whichever was lower, with a `wall_drop` of 32 blocks for the two finest levels; a coarse cell
  34 blocks above a ravine floor left a 2-block slit of sky under it. It now goes `wall_drop` (64 blocks at least, 4 cells for the
  big ones, at most 256) below the *lower* of the two tops, and the foot darkening is spread over the part that shows
  (`shade_height`; the bottom vertices carry the same rate of darkening on down, up to `MAX_FOOT_DARKENING`), so an edge wall looks
  like the walls inside the tile (test: `the_part_of_an_edge_wall_that_can_be_seen_is_shaded_like_the_walls_inside_the_tile`).
  Nothing is added to the triangle count: the extra length is under the ground.
* **The audit** (`viewshot` of the scratch harness with `CRACKS=1`, not in the tree): the far terrain alone, drawn over a
  background nothing else uses, with the camera looking level from 40 and from 150 blocks above the ground and six headings;
  below the horizon a height field leaves no gap, so every pixel that has terrain above it in its column and nothing drawn on it
  is a hole. It reported thousands of hole pixels when every 17th tile was left out on purpose (it can see), 14 of 136 runs with 1 to 4
  hole pixels before the change, and 6 of 136 after. Eight of the 14 were real (the same world spot in 44 of 51 views with the camera
  moved a little; the ravine above), and are gone. The 6 left are single pixels in open ocean that move with a tiny camera
  change (3 of 45 views): the harness's rasteriser clips the two triangles of a huge sea quad against the near plane separately
  and misses a pixel on their diagonal. A GPU does not clip that way (guard band, fixed-point edges). 600 x 300 pixels is
  coarse: a slit thinner than a pixel at distance would not show, but the geometry that makes it is gone.

## Looking for the blink (0.8.2)

The main menu and the game blinked on the phone with 0.8.0 and still with 0.8.1. The cause is **not known**. What the logs of
22 November (`VoxelSandbox-log_2026-11-22_4.04pm`, `4.05pm`, `4.10pm`, 0.8.1) say:

* The menus run at a steady 60 frames a second (frame 16.6 ms, p95 21 ms), with `render` ~15.4 ms, which is the wait for the screen
  inside the first GL call, and `swap-wait` ~1 ms. No GL error and no lost context is in them (`ErrorWatch`), so the picture is not
  something the driver refused to draw.
* The menu path is `glClear` (colour and depth), the sky (`draw_sky`, one triangle, `highp` everywhere, the view turning at 0.05
  radians a second), the UI. Nothing in it changes between frames except the sky's yaw and the buttons.
* The three logs were written with three different sets of settings (render distance and detail distance 330 and 28 chunks with
  far terrain and auto performance on; 10 and 10 with far terrain off; 240 and 7 at 70 % resolution with auto performance off), so the
  settings were being tried between launches, and the menu runs at 60 frames a second in all three. In the first, the real blocks
  reached only about 10 chunks (441 meshed chunks) although the setting said 28: auto performance starts from the level an
  earlier run settled on (`Governor::start_at`).
* With the detail distance at 31 chunks (about 3,000 meshed chunks, the 4.05pm log) the game ran at 17 to 30 frames a second, and
  the log's own verdicts were `LAG: RENDERING (CPU side)` while flying high (the game thread busy 33 to 46 ms of a frame:
  visibility culling 9 to 15 ms, world draw calls 10 to 20 ms) and `LAG: GPU/DISPLAY` low over the forest (1.3 to 2.4 million
  triangles in a frame, 1.5 million of them leaves; `gpu-time` 24 to 47 ms). The HITCH lines (68 of them, 50 to 335 ms) blame world
  draw calls (54 to 140 ms, the game waiting inside a GL call), visibility culling (15 to 21 ms) and mesh upload (28 to 42 ms).
  That is judder, the likeliest thing to look like blinking at a big detail distance, but it is not evidence of the blink on the menu,
  and this version does not change it. The occlusion search runs again whenever a chunk arrives (`ChunkStore::update_visibility` keys on the set
  of chunks), and leaves are the biggest share of the triangles: the two places to look first.

What 0.8.2 adds, none of it confirmed on a phone:

* **`diag/flicker.rs` (`FlickerProbe`, host-tested) and `Renderer::probe_flicker`.** On the main menu, the pause menu and the
  settings, every second frame of the first 600 of each visit (0.8.3: every 30th of the first 1800) the renderer reads four evenly spaced rows of the finished
  picture back (`glReadPixels`, `render/gl.rs`) just before the swap and adds up the bytes of each row. A row that moves by more than
  1.5 % between two reads is a blink: `BLINK on MENU: row 2 of the picture went from A to B (the sum of its colour bytes) between
  frames X and Y of this screen` (at most 10 lines). The visit ends with `blink probe: MENU picture read 300 times over 600
  frames, 0 jumps` (0.8.3: `read 60 times over 1800 frames`; not for visits of fewer than 10 reads, 0.8.2: 20). `0 jumps` on a menu that blinks to the eye puts the fault after
  the game's last GL call (the display or the compositor); `BLINK` lines say which row and when. A read makes the CPU wait for the GPU, which is why it is
  limited to the menus, to a limited time and to few frames (0.8.2: every other frame of the first 10 seconds, 0.8.3: one frame in 30 for half a minute),
  and it could change the timing of a fault that depends on it: a picture that is wrong only while the GPU's queue is full may not
  show while the queue is drained every other frame, which is the other reason it was made rare. The 1.5 % limit has room: the sky behind the
  menus moved a row by at most 0.12 % between two reads half a second apart and 0.22 % a second apart (main menu and settings at 1800 x 810,
  every phase of a whole turn of the sky, 600 row comparisons each; a measurement of the game's own motion on a computer, not of a phone).
* **`vUv` is `highp`** in the terrain and water shaders (`render/shaders.rs`). On Mali a `mediump` float is 16 bits, and the
  texture coordinate grows along a merged face, so a long face could lose the fraction it needs. No log shows this happening.
* **The GPU timer** (`render/gpu_timer.rs`) now starts and ends only on frames that draw the world (`App::world_visible`),
  so the menus do not touch a timer query (0.8.3: only around the world pass, so a query never spans two passes).
* **Looked at and found fine:** buffer uploads are `glBufferData` (a new store each time; no unsynchronised mapping), state at the start of
  every frame is set before the clear (depth mask, blend, viewport; the scissor test is only on in the warm-up), the far terrain
  is only dropped under blocks whose meshes are on the GPU (`covered_quarters` asks the GPU store), and the audit above.

## The flashing (0.8.3)

**What was seen.** On the Infinix Hot 11 (Mali-G52, r27p0, 1800 x 810) the screen flashed in the game ("if I fly up in the Amazon
biome"). A screenshot of it (25 November, 0.8.2) is two colours only: the clear colour `HORIZON` (168, 201, 237) and (0, 0, 0). The
black part is 33.5 % of the pixels, one connected region reaching the bottom edge, with steps on 16-pixel columns (x 1024-1039
starts at y 340, 1040-1055 at 336, 1056-1071 at 340, 1072-1087 at 336, 1088-1151 at 320, 1152-1535 at 256, 1536-1799 at 0).
Nothing else is on it, not even the HUD. A frame that was drawn badly would still show terrain or HUD somewhere; this one shows
what is left when a frame's work stops after the first clear, tile by tile. No GL error and no lost context are in any log.

**What it correlates with.** In the log of the same minute (`4.06pm_1`) the player starts flying at 4:07:35pm (height 73, then 91,
109, 127, 133 in the next four seconds), and at 4:07:37pm the log says `auto performance: 10 chunks at 100% -> 10 chunks at 85%
(frames are slow; frames 22.4 ms, GPU 29.9 ms)`. Every frame after that goes through the off-screen picture. At 100 % resolution
the frame is one pass with no copy; that was not reported glitchy, nor was the 0.7.0 log (auto performance off). The three
`BLINK` lines of the 25 November logs all fall in the second a button was pressed that leaves the screen (play, resume): a
highlight changing a row of the picture, not a glitch. The `HITCH ... other rendering 49 ms` lines on the menu and its 42 frames
a second are the probe's own reads (the 0.8.1 logs, without the probe, show 60). What this cannot separate: flying up also makes
the frame heavier and changes what is in view, so "the off-screen path" is the best-supported suspect, not the only one.

**The old path (0.8.0 - 0.8.2), per frame below 100 %:** `glClear` of the screen, then the world into a renderbuffer target (clear,
draw), `glInvalidateFramebuffer(depth)`, `glBlitFramebuffer` (linear) to the screen, `glInvalidateFramebuffer(colour of the read
target)`, then the UI. A GPU timer query began before the first command and ended after the last, spanning all of it. So the
screen's work was split in two around the target's, with a copy between buffers and two discards.

**The likeliest cause, unproven.** A tile-based GPU like the Mali defers and merges work per tile and relies on the driver to track
which buffers are valid. A thread on ARM's community forum about a Mali-G76 (r16p0) reports tiles of the screen being discarded
although they differ from memory when a render pass does not redraw the whole screen, which is the situation of the early clear, the
target pass and the later screen pass. A discard that lands on the wrong buffer (the invalidate after the blit names the *read*
target) would leave exactly a frame where only the early clear survived. The timer query spanning three passes is a second suspect.
I could not reproduce either off the phone, and the ARM report is about another chip.

**The new path (0.8.3).** `frame::Planner` decides the route (`Sky`, `Direct`, `Picture { size, Fresh | FreshKeep | Kept }`), the
renderer does it:

1. `SceneTarget::begin_pass` (bind the FBO, viewport, scissor off, depth mask on, blend off, clear colour and depth), then the world.
   The timer begins after the clear and ends before the next pass.
2. `begin_screen_pass` (the same for the screen), `Composite::draw` (one triangle from `gl_VertexID`, the target's texture on its own
   unit `SCENE_UNIT` = 4, `LINEAR` filter, `CLAMP_TO_EDGE`, no mipmaps; the unit is emptied afterwards so the texture is never bound
   while it is the colour buffer of the next frame's pass), then the UI.
3. A kept picture (game paused, same `PictureKey`) skips 1 and does 2 again from the texture that is still there.
4. Straight drawing (100 %, running) is `begin_screen_pass`, the world, the UI, as before.

There is no `glBlitFramebuffer`, no `glInvalidateFramebuffer` and no early clear any more (their declarations are gone from
`render/gl.rs`, so nobody brings them back by accident). The cost is that the target's depth is now written to memory at the end of
its pass too (1530 x 688 x 4 bytes = about 4 MB a frame at 85 %, about 250 MB a second at 60 frames; estimated, not measured);
`target.rs` says why that is accepted and warns against undoing it without a phone to look at the result on. The first three composites after a target is made also check `glGetError`. A failure there, a target the GPU
refuses, or a composite program that does not build makes the planner draw straight to the screen from then on (`Planner::refuse`,
`FrameNeeds::offscreen_ok`).

**What was run, on a computer, not on a phone.** `cargo test --lib`: 339 passed, 1 ignored (a long sweep), 15 of them new in
`frame::plan`. The planner's tests were also mutation-checked (leaving out the reset of the kept picture, comparing no key, letting
`picture_lost` do nothing: each makes a test fail; leaving the reset in `refuse` out changes nothing, because the planner answers
`Direct` for that size anyway). The real `Renderer` ran under Mesa llvmpipe (OpenGL ES 3.2, EGL surfaceless + pbuffer, 800 x 360, a
seeded birch-forest world with 49 chunks and 12 far tiles, flying) through 100 %, 85 % and 70 % running; paused at 85 %, 100 % and
70 %; back; the main menu; and 14 route switches in all orders: 0 GL errors, the same picture in every frame of a scene, the world
drawn once (70 draw calls) and then 0 calls while paused, and for every scene a picture identical pixel for pixel to what the 0.8.2
code draws (the main menu differs by 1 level in about 2,200 pixels: its sky turns with the clock). With the "driver" refusing the 85 %
size, or the composite shader broken on purpose, the game drew at full size with 0 GL errors. llvmpipe has none of the Mali's tile
logic, so this shows that the GL calls are valid and the picture is right, not that the flashing is gone. Its timer queries ran
too, and measure nothing about a Mali.

**If it still flashes**, the log now says how each stretch was drawn (`frame route: ...`). With the flash in a `Picture` stretch and
none at 100 % (auto performance off, Resolution 100 %), the off-screen path is still at fault and the next step is to stop the
quality controller from lowering the resolution (it would only shorten the real-block distance) and to keep the target for the
paused picture alone. With the flash at 100 % too, the cause is in the world's own pass (a vertex or index
range the GPU faults on would look the same: a pass that stops early) and the next step is a bounds audit of the buffers the world
draws from.

Nothing in `platform/` ran on the machine this was written on, and nothing in `render/` ran on a phone; `platform` is type-checked only.

## The audit (0.8.4)

**Why.** After 0.8.3 the screen still glitched on the Infinix Hot 11 ("still glitchy, do a full code audit", log of 27 November
attached, no screenshot). The 0.8.3 notes named the next step if the flash also appeared at 100 % resolution: "a bounds audit of the
buffers the world draws from". This is that audit, extended to the neighbouring code. It is an audit of what can be checked on a
computer. Nothing here ran on a phone, and the Mali's behaviour is still the open question.

**What the log of 27 November shows** (and does not). No flash is described for it. The first frames of the run are at 85 %
resolution with no `auto performance` event before them: the governor's remembered level (`quality.txt`) was restored silently,
which is why the log looked as if the game had lowered itself at once. Later, at the sizes you chose (render distance 220, detail
32 to 38), a frame is up to about 741,000 triangles (leaves alone 428,000) and the game runs at 25 to 45 frames a second, limited
by the GPU: the per-second `drawn N chunks / calls / tris` figures are averages over about 60 frames, not single frames. The
`BLINK` lines in it are the probe reporting the redraw of a paused picture after a view setting changed (see the findings).

### Method

1. Read the code that sits between block data and pixels, looking for a defect that could show as a partial, flashing or
   unstable picture: shaders and their precision, state set before each pass, texture units, buffer and VAO lifetime, EGL
   set-up, the culling maths, the UI batching.
2. For the data that goes to the GPU, write the promises the drawing code relies on as a checker (`mesh/audit.rs`, `lod/audit.rs`,
   plain functions returning a list of problems), prove the checker works by breaking meshes on purpose, then run it over real
   generated terrain.
3. Property-test the culling against the projection (`core::math`).
4. Re-run the real `Renderer` on Mesa and compare its pictures with the 0.8.3 build's.

### Checked, no defect found

* Index and vertex data of chunk meshes (more than 400 real meshes: seeds 555 and 7; ordinary ground, the 11 biomes and a water
  site, 3 x 3 chunks each; merged and not; neighbours loaded and not; the biggest has 64,040 vertices, so the 16-bit index
  narrowing at 65,536 is close but not crossed) and of far tiles (126 real tiles, levels 0, 1, 2, 3, 5, 7, 9; the biggest has
  12,648 vertices). Every index inside its list, every range inside the list and in order, every vertex inside its section box
  (plus `SECTION_SLACK` 0.5, now one shared constant), plants inside their footprint with the documented 0.15 nudge, merged quads
  within `MERGE_GROW` of the column box. The checker's own tests break a mesh in twelve ways and a far tile in ten, and each makes
  it fail.
* The chunk culling against the projection: 300 random orientations up to a pitch of 89 degrees, points spread around the view
  volume, a margin of `0.05 + 0.002 |w|`: nothing on screen is culled, nothing off screen is kept.
* Reading only (no test): the shaders (`highp` in the vertex shaders and for the texture coordinates, `mediump` by default in the fragment shaders), fog, the composite triangle,
  scene target set-up and the order of binds and unbinds, GL bindings and error checks, program building and caching, EGL config
  and surface handling, the UI batcher.
* The real renderer on Mesa (llvmpipe, OpenGL ES 3.2, 800 x 360): 18 pictures, all identical pixel for pixel to the 0.8.3
  build's, 0 GL errors, 0 route-switch problems.

### Found and changed

| What | Effect | Change |
|---|---|---|
| Water side faces: texture coordinates carried the world height (up to 64.67; every other face stays within one repeat of 16) | None that I could show (the coordinates are `highp`, the picture is identical in the scenes) | Wrapped like the top faces (`side_u`, `side_v`); the checker now limits the coordinates to 17.5 |
| GPU time offered for as long as no new reading arrived (`gpu-time 37.9 ms` for four seconds in the log) | The quality controller decided on a stale number | `perf/gpu_reading.rs`: believed only if the driver does not call it disjoint and it is 0 to 2000 ms; withdrawn after 90 frames. The timer is read at the start of a frame (`GpuTimer::poll`) and never while a pass is open |
| A restored quality level was applied without a log line | A run seemed to start by lowering itself | The first second of the log says `auto performance: this run starts at ... ; the settings allow ...` |
| The blink probe took the redraw of a paused picture (after a view setting changed) for a blink | Four false `BLINK` lines in one session | `Renderer::world_redrawn`, `Flicker::feed_after_redraw`: the redraw's rows become the new reference |
| A save's position, yaw or pitch went into the player unchecked | A NaN position or a pitch past 89 degrees would give a camera that draws nothing sensible. I do not know a way the game writes such a save | `Player::restore`: look made valid; a position that is not a place starts the player at the spawn point, rest of the save kept (4 + 2 tests) |

Also changed without effect on behaviour: `MeshContext::for_generator` (the mesher's context built in one place, used by the game and
the tests), `needs_wide_indices` (one function for the 16/32-bit index choice, used by the renderer and the checker),
`mesh/testkit.rs` (shared test set-up).

### Not covered

The world-map drawing (`map_gpu.rs`), the clouds, the hand-over between far tiles and real blocks (`lod` manager), world streaming
and its threads, physics and the rest of the engine, texture mip generation, the menus' logic, terrain generation, and the rest of
the governor beyond the parts above. Not run: anything on a phone or on the build server.

### Ideas considered and not done

* **Delaying `glDeleteBuffers` / `glDeleteVertexArrays` by a few frames** (a graveyard in `shader::delete_buffer`). GL says storage
  that is still in use survives its delete, and I have no sign of a driver that breaks that; a change without evidence is more risk
  than it removes.
* **A robust EGL context** (`EGL_EXT_create_context_robustness`), which would make a GPU reset visible to the game. It changes
  how the context is created on a device I cannot test, so it should wait until there is a reason.
* **Reading pixels of the world to catch a black band** while playing. It would stall the GPU's pipeline every time; the
  `HITCH` lines already show a frame that took long.

### If it flashes again

Send the log and say when. In it: a `HITCH` of hundreds of milliseconds just before the flash would mean the GPU was given a frame
that was too heavy (the driver can stop a job that runs too long and leave a half-drawn frame; that is a theory, not something
this audit showed). The `frame route:` lines say whether the flash only happens below 100 %. With the flash at 100 % as well and no
long frame, the world's own pass is suspect, and the data audit above says the index and range data are not the cause.
