//! Looks for a screen that blinks.
//!
//! On a screen where nothing should change quickly (the main menu, the pause menu, the settings) the finished picture of a
//! frame is nearly the same as the one before it. The renderer reads a few rows of that picture back and adds each row up;
//! if a row's sum jumps between two reads the picture itself blinked, and the debug log says on which screen, which row and
//! by how much. If the log has the "0 jumps" line for a screen that still seemed to blink, the picture was fine when the game
//! handed it over and the blink happens after that (the display or the compositor), which is a different problem to chase.
//!
//! The GL read-back is the renderer's job; this is only the bookkeeping, so it can be tested without a GPU.

/// How many rows of the picture are read back (evenly spread from top to bottom).
pub const ROWS: usize = 4;

/// One read of the picture: for each row, the sum of all its colour bytes.
pub type RowSums = [u64; ROWS];

/// How many frames of one visit to a screen are watched. Reading pixels back makes the CPU wait for the GPU (and drains
/// its queue, which a picture that is wrong only while the queue is full may never show), so it is done rarely and for a
/// limited time: half a minute at 60 frames per second.
pub const WATCHED_FRAMES: u32 = 1800;
/// One frame in this many is read. 0.8.2 read every second frame, and the waiting that caused showed up in the log as
/// hitches of its own (about 50 ms of "other rendering" on the main menu); once per half second it should not (not yet
/// seen on a phone).
pub const READ_EVERY: u32 = 30;
/// A row whose sum changes by more than this many thousandths between two reads has blinked. The sky behind the menus
/// turns slowly: measured over a whole turn of it, on the main menu and the settings screen, two reads half a second
/// apart (`READ_EVERY` frames at 60 a second) differ by about one thousandth at most, and by about two a second apart,
/// so this leaves room even if the menu runs at half speed.
pub const JUMP_PER_MILLE: u64 = 15;
/// The most blink lines one run puts in the log.
const MAX_REPORTS: u32 = 10;
/// A visit with fewer reads than this does not get a summary line (a menu that was on screen for a second says nothing).
const MIN_READS_FOR_SUMMARY: u32 = 10;

/// What the renderer should do with the frame that is starting.
#[derive(Debug, PartialEq, Eq)]
pub struct Frame {
    /// Read the picture back at the end of this frame and `feed` it.
    pub read: bool,
    /// A line for the log (the summary of a visit that has just ended).
    pub note: Option<String>,
}

pub struct FlickerProbe {
    screen: Option<(u8, &'static str)>,
    /// Frames since the screen came up.
    frames: u32,
    reads: u32,
    jumps: u32,
    last: Option<RowSums>,
    summarised: bool,
    reported: u32,
}

impl FlickerProbe {
    pub fn new() -> FlickerProbe {
        FlickerProbe { screen: None, frames: 0, reads: 0, jumps: 0, last: None, summarised: false, reported: 0 }
    }

    /// Call at the start of every frame with the screen that is up (`id` tells screens apart, `name` is for the log) and
    /// whether this kind of screen is one to watch.
    pub fn begin_frame(&mut self, id: u8, name: &'static str, watched: bool) -> Frame {
        let mut note = None;
        if self.screen.map(|s| s.0) != Some(id) {
            note = self.finish_visit();
            self.screen = Some((id, name));
            self.frames = 0;
            self.reads = 0;
            self.jumps = 0;
            // the first read of a new screen must not be compared with the last read of the one before
            self.last = None;
            self.summarised = false;
        }
        self.frames += 1;
        if watched && self.frames == WATCHED_FRAMES + 1 && note.is_none() {
            note = self.finish_visit();
        }
        let read = watched && self.frames <= WATCHED_FRAMES && self.frames % READ_EVERY == 0;
        Frame { read, note }
    }

    /// The picture of the frame that was just drawn, as read back. The line for the log if it differs a lot from the
    /// picture read before it.
    pub fn feed(&mut self, rows: RowSums) -> Option<String> {
        self.reads += 1;
        let before = self.last.replace(rows)?;
        for (i, (&a, &b)) in before.iter().zip(rows.iter()).enumerate() {
            let biggest = a.max(b);
            if biggest > 0 && a.abs_diff(b) * 1000 > biggest * JUMP_PER_MILLE {
                self.jumps += 1;
                if self.reported >= MAX_REPORTS {
                    return None;
                }
                self.reported += 1;
                let name = self.screen.map(|s| s.1).unwrap_or("?");
                return Some(format!(
                    "BLINK on {}: row {} of the picture went from {} to {} (the sum of its colour bytes) between frames {} and {} of this screen",
                    name,
                    i + 1,
                    a,
                    b,
                    self.frames.saturating_sub(READ_EVERY),
                    self.frames
                ));
            }
        }
        None
    }

    /// Like `feed`, for a picture whose world was drawn again since the read before it (a view setting was changed behind the
    /// settings screen, say): it is expected to differ then, so it is no blink. It becomes the picture the next read is
    /// compared with. (The 0.8.3 probe reported such changes as blinks, four of them in one session of moving sliders.)
    pub fn feed_after_redraw(&mut self, rows: RowSums) -> Option<String> {
        self.reads += 1;
        self.last = Some(rows);
        None
    }

    /// The summary of the visit that is ending, once.
    fn finish_visit(&mut self) -> Option<String> {
        let (_, name) = self.screen?;
        if self.summarised || self.reads < MIN_READS_FOR_SUMMARY {
            return None;
        }
        self.summarised = true;
        Some(format!(
            "blink probe: {} picture read {} times over {} frames, {} jumps",
            name,
            self.reads,
            self.frames.min(WATCHED_FRAMES),
            self.jumps
        ))
    }
}

impl Default for FlickerProbe {
    fn default() -> FlickerProbe {
        FlickerProbe::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Runs `frames` frames of a screen and feeds the picture of each read frame from `picture(frame number)`.
    fn run(p: &mut FlickerProbe, name: &'static str, id: u8, frames: u32, picture: impl Fn(u32) -> RowSums) -> Vec<String> {
        let mut lines = Vec::new();
        for f in 1..=frames {
            let frame = p.begin_frame(id, name, true);
            lines.extend(frame.note);
            if frame.read {
                lines.extend(p.feed(picture(f)));
            }
        }
        lines
    }

    fn steady(frame: u32) -> RowSums {
        // a slowly turning sky: every row drifts by a few parts in ten thousand per frame
        let drift = frame as u64 * 40;
        [1_000_000 + drift, 900_000 + drift, 800_000 + drift, 700_000 + drift]
    }

    #[test]
    fn a_steady_screen_reports_no_jumps_and_says_so_once() {
        let mut p = FlickerProbe::new();
        let lines = run(&mut p, "MENU", 0, WATCHED_FRAMES + 100, steady);
        assert!(lines.iter().all(|l| !l.starts_with("BLINK")), "{:?}", lines);
        let summaries: Vec<_> = lines.iter().filter(|l| l.starts_with("blink probe")).collect();
        assert_eq!(summaries.len(), 1, "{:?}", lines);
        let reads = format!("{} times", WATCHED_FRAMES / READ_EVERY);
        let frames = format!("{} frames", WATCHED_FRAMES);
        assert!(summaries[0].contains("MENU") && summaries[0].contains(&reads) && summaries[0].contains(&frames) && summaries[0].contains("0 jumps"), "{}", summaries[0]);
        // leaving the screen later does not say it again
        let after = p.begin_frame(1, "LOADING", false);
        assert_eq!(after.note, None);
    }

    #[test]
    fn a_picture_that_jumps_is_reported_with_the_row_and_the_frames() {
        let mut p = FlickerProbe::new();
        // one of the frames that are read comes out much darker in the second row only
        let at = 3 * READ_EVERY;
        let lines = run(&mut p, "MENU", 0, at + 2 * READ_EVERY, |f| {
            let mut rows = steady(f);
            if f == at {
                rows[1] /= 3;
            }
            rows
        });
        let blinks: Vec<_> = lines.iter().filter(|l| l.starts_with("BLINK")).collect();
        // the jump down at that frame and the jump back up at the next read
        assert_eq!(blinks.len(), 2, "{:?}", lines);
        assert!(blinks[0].contains("MENU") && blinks[0].contains("row 2") && blinks[0].contains(&format!("frames {} and {}", at - READ_EVERY, at)), "{}", blinks[0]);
        assert!(blinks[1].contains("row 2") && blinks[1].contains(&format!("frames {} and {}", at, at + READ_EVERY)), "{}", blinks[1]);
    }

    #[test]
    fn a_small_change_is_not_a_blink_and_a_big_one_in_any_row_is() {
        let mut p = FlickerProbe::new();
        assert!(p.feed([1_000_000, 1_000_000, 1_000_000, 1_000_000]).is_none(), "the first read has nothing to compare with");
        // 1% in every row is a caret or a button changing, not the picture: under the threshold of 1.5%
        assert!(p.feed([1_010_000, 1_010_000, 1_010_000, 1_010_000]).is_none());
        assert!(p.feed([1_010_000, 1_010_000, 1_010_000, 1_200_000]).is_some(), "the last row jumped by 19%");
    }

    #[test]
    fn a_picture_redrawn_in_between_is_no_blink_and_becomes_the_reference() {
        let mut p = FlickerProbe::new();
        assert!(p.feed([1_000_000; ROWS]).is_none());
        // the view distance was changed behind the menu: the world is drawn again and looks quite different
        assert!(p.feed_after_redraw([700_000; ROWS]).is_none());
        assert_eq!(p.jumps, 0);
        // from then on the new picture is what the next read is compared with
        assert!(p.feed([700_500; ROWS]).is_none());
        assert!(p.feed([1_000_000; ROWS]).is_some(), "a jump back is still a jump");
        assert_eq!(p.reads, 4);
    }

    #[test]
    fn the_report_lines_are_capped_but_the_jumps_are_all_counted() {
        let mut p = FlickerProbe::new();
        let mut lines = 0;
        let frame = p.begin_frame(0, "MENU", true);
        assert!(!frame.read);
        let mut shown = 0;
        for i in 0..50u64 {
            let rows = if i % 2 == 0 { [1_000_000; ROWS] } else { [10; ROWS] };
            if p.feed(rows).is_some() {
                shown += 1;
            }
            lines += 1;
        }
        assert_eq!(lines, 50);
        assert_eq!(shown, MAX_REPORTS as usize);
        assert_eq!(p.jumps, 49);
    }

    #[test]
    fn only_one_frame_in_a_few_is_read_and_only_for_a_while() {
        let mut p = FlickerProbe::new();
        let mut reads = 0;
        let mut last_read = 0;
        for f in 1..=2 * WATCHED_FRAMES {
            if p.begin_frame(0, "MENU", true).read {
                reads += 1;
                last_read = f;
            }
        }
        assert_eq!(reads, WATCHED_FRAMES / READ_EVERY);
        assert!(last_read <= WATCHED_FRAMES);
    }

    #[test]
    fn a_screen_that_is_not_watched_is_never_read() {
        let mut p = FlickerProbe::new();
        for _ in 0..1000 {
            assert!(!p.begin_frame(2, "PLAYING", false).read);
        }
    }

    #[test]
    fn a_new_screen_starts_afresh_and_short_visits_say_nothing() {
        let mut p = FlickerProbe::new();
        // a short visit to the menu: one read short of a summary line
        let lines = run(&mut p, "MENU", 0, (MIN_READS_FOR_SUMMARY - 1) * READ_EVERY, steady);
        assert!(lines.is_empty(), "{:?}", lines);
        // the pause menu's first picture is nothing like the menu's last one, and that is no blink
        let lines = run(&mut p, "PAUSED", 3, MIN_READS_FOR_SUMMARY * READ_EVERY, |_| [5; ROWS]);
        assert!(lines.iter().all(|l| !l.starts_with("BLINK")), "{:?}", lines);
        // and the pause menu is summed up when it is left, because that many reads is enough to say something
        let note = p.begin_frame(0, "MENU", true).note.expect("a summary of the pause menu");
        assert!(note.contains("PAUSED") && note.contains(&format!("{} times", MIN_READS_FOR_SUMMARY)) && note.contains("0 jumps"), "{}", note);
    }
}
