//! Draws a frame: sky, clouds, the far terrain, the block world in four passes, the block outline and finally
//! the UI. The pieces live in their own modules: `chunks` (block meshes, culling), `far` (far terrain),
//! `target` and `composite` (drawing the world at a lower resolution, and keeping its picture while the game is
//! paused; `crate::frame::plan` decides which way each frame goes), `programs` and `shaders` (GLSL), `fog`, and
//! `gpu_timer` (how long the GPU needs for the world).

use std::collections::VecDeque;
use std::ffi::CStr;
use std::os::raw::{c_char, c_void};
use std::time::Instant;

use super::chunks::{bind_vertex_layout, ChunkStore, CullStats, DrawList, DrawTotals};
use super::far::{FarDrawn, FarRenderer};
use super::fog::Fog;
use super::gl::*;
use super::gpu_timer::GpuTimer;
use super::map_gpu::MapGpu;
use super::programs::*;
use super::shader::*;
use super::shaders::*;
use super::composite::Composite;
use super::target::{begin_screen_pass, SceneTarget};
use crate::core::math::{mat4_mul, mat4_ortho_pixels, mat4_perspective, mat4_view_dir, Frustum, Vec3};
use crate::diag::flicker::{FlickerProbe, RowSums, ROWS};
use crate::diag::gl_errors::ErrorWatch;
use crate::diag::probe::{self, Counter, Stage};
use crate::diag::sample::ScreenKind;
use crate::frame::{FrameNeeds, PictureKey, PictureSource, Planner, Route, RouteLog};
use crate::mesh::{ChunkMeshData, Vertex};
use crate::tex::{self, cells, cloud_noise};
use crate::ui::app::{App, CameraState, Screen};
use crate::ui::batch::{RunKind, UiBatch, UI_VERTEX_SIZE};
use crate::ui::font;
use crate::world::pos::ChunkPos;

const FOV_DEGREES: f32 = 70.0;
const NEAR_PLANE: f32 = 0.1;
/// The far terrain is only ever seen beyond the block world, so it can use a much larger near plane, which keeps
/// the depth buffer precise over a long view (the near plane grows with the view distance, see `draw_world`).
const FAR_NEAR_PLANE: f32 = 8.0;
/// How the depth buffer is shared (see `draw_world`): the real blocks use `0 .. BLOCK_DEPTH_SPLIT` of it, the far
/// terrain `BLOCK_DEPTH_SPLIT .. FAR_DEPTH_END`, and the sky is drawn at exactly 1.0, behind everything.
const BLOCK_DEPTH_SPLIT: f32 = 0.6;
/// Kept a little below 1.0 so that not even a far-terrain pixel at the far plane can ever count as sky.
const FAR_DEPTH_END: f32 = 0.9999;
const HORIZON: [f32; 3] = [0.66, 0.79, 0.93];
const ZENITH: [f32; 3] = [0.27, 0.48, 0.85];
const UNDERWATER: [f32; 3] = [0.16, 0.36, 0.70];
const SUN: [f32; 3] = [0.5156, 0.4688, -0.6282];
const CLOUD_HEIGHT: f32 = 200.0;
const CLOUD_HALF: f32 = 3000.0;
/// The warm-up draws into a corner this many pixels across.
const WARM_UP_PIXELS: i32 = 1;

/// How much of a frame the renderer may spend copying new meshes to the GPU (more while the loading screen is up).
const UPLOAD_BUDGET_NS: u64 = 2_500_000;
const UPLOAD_BUDGET_LOADING_NS: u64 = 14_000_000;
const UPLOAD_MAX_CHUNKS: usize = 12;
const UPLOAD_MAX_CHUNKS_LOADING: usize = 64;
const UPLOAD_MAX_TILES: usize = 6;
const UPLOAD_MAX_TILES_LOADING: usize = 24;

/// What the renderer knows about the GPU, for the debug log.
#[derive(Clone, Debug, Default)]
pub struct GlInfo {
    pub vendor: String,
    pub renderer: String,
    pub version: String,
}

/// Draw calls and triangles of each pass of the last frame (for the debug log and the tests).
#[derive(Clone, Copy, Debug, Default)]
pub struct PassGauges {
    pub far: DrawTotals,
    pub opaque: DrawTotals,
    pub cutout: DrawTotals,
    pub plants: DrawTotals,
    pub water: DrawTotals,
}

/// Numbers from the last frame for the debug log's one-second lines.
#[derive(Clone, Copy, Debug, Default)]
pub struct RenderGauges {
    pub gpu_chunks: u32,
    pub gpu_tiles: u32,
    /// What the GPU itself needed for the world pass of a recent frame, when the driver can tell (milliseconds).
    pub gpu_ms: Option<f32>,
    pub passes: PassGauges,
    /// The size the 3D world was drawn at (smaller than the screen when the resolution setting is below 100%).
    pub view_w: i32,
    pub view_h: i32,
    pub cull: CullStats,
    pub occlusion_searches: u64,
}

pub struct Renderer {
    ui: UiProg,
    world: Option<WorldGl>,
    far: Option<FarRenderer>,
    error: Option<String>,
    block_tex: GLuint,
    font_tex: GLuint,
    cloud_tex: GLuint,
    /// The world map's texture and program (made when the map is first shown, see `map_gpu`).
    map: MapGpu,
    /// Looks for GL errors in the first frames, for the debug log.
    errors: ErrorWatch,
    /// Looks for a menu picture that blinks (see `probe_flicker`).
    flicker: FlickerProbe,
    /// The world was drawn since the blink probe last read the picture (then the picture may differ for a good reason).
    world_redrawn: bool,
    /// One row of pixels read back for `flicker`.
    probe_row: Vec<u8>,
    gpu_timer: Option<GpuTimer>,
    ui_vao: GLuint,
    ui_vbo: GLuint,
    line_vao: GLuint,
    line_vbo: GLuint,
    dummy_vao: GLuint,
    chunks: ChunkStore,
    draw_list: DrawList,
    pending: VecDeque<(ChunkPos, ChunkMeshData)>,
    /// How each frame's world reaches the screen (see `frame::plan`), and what the off-screen picture holds.
    planner: Planner,
    /// Says in the debug log when the way of drawing changes.
    route_log: RouteLog,
    /// Puts the off-screen picture on the screen; `None` if the driver would not build its program (the world is then
    /// always drawn straight to the screen).
    composite: Option<Composite>,
    target: Option<SceneTarget>,
    /// How many times the picture was put on the screen since `target` was made (the first few are checked for GL errors).
    composites_checked: u32,
    time: f32,
    error_batch: UiBatch,
    info: GlInfo,
    gauges: RenderGauges,
}

fn create_block_texture() -> GLuint {
    let rgba = tex::build_layers_rgba();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D_ARRAY, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage3D(
            GL_TEXTURE_2D_ARRAY,
            0,
            GL_RGBA8,
            tex::TILE_SIZE as GLsizei,
            tex::TILE_SIZE as GLsizei,
            cells::TILE_COUNT as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // the smaller levels are made by hand (see `tex::build_mip_chain`): leaves and plants must keep their
        // see-through texels in the same proportion at every distance, which glGenerateMipmap does not do
        let mips = tex::build_mip_chain(&rgba);
        for (i, level) in mips.iter().enumerate() {
            let size = (tex::TILE_SIZE >> (i + 1)) as GLsizei;
            glTexImage3D(
                GL_TEXTURE_2D_ARRAY,
                (i + 1) as GLint,
                GL_RGBA8,
                size,
                size,
                cells::TILE_COUNT as GLsizei,
                0,
                GL_RGBA,
                GL_UNSIGNED_BYTE,
                level.as_ptr() as *const c_void,
            );
        }
    }
    id
}

/// The cloud shape (see `tex::cloud_noise`) as a repeating single-channel texture.
fn create_cloud_texture() -> GLuint {
    let texels = cloud_noise::generate();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_R8,
            cloud_noise::SIZE as GLsizei,
            cloud_noise::SIZE as GLsizei,
            0,
            GL_RED,
            GL_UNSIGNED_BYTE,
            texels.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    id
}

fn create_font_texture() -> GLuint {
    let rgba = font::build_atlas();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            font::ATLAS_W as GLsizei,
            font::ATLAS_H as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    id
}

/// One triangle in the block vertex format, spanning the whole screen when drawn with the identity matrix, for
/// `Renderer::warm_up`. The buffers live as long as the vertex array that uses them and are freed together.
struct WarmUpMesh {
    vao: GLuint,
    vbo: GLuint,
    ibo: GLuint,
}

impl WarmUpMesh {
    fn new() -> WarmUpMesh {
        let corner = |x: f32, y: f32| Vertex { pos: [x, y, 0.0], uv: [0.5, 0.5], color: [128, 128, 128, 255], info: [0, 0, 0, 0] };
        let vertices = [corner(-1.0, -1.0), corner(1.0, -1.0), corner(-1.0, 1.0)];
        let indices: [u32; 3] = [0, 1, 2];
        let mesh = WarmUpMesh { vao: gen_vertex_array(), vbo: gen_buffer(), ibo: gen_buffer() };
        unsafe {
            glBindVertexArray(mesh.vao);
            glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
            upload_buffer(GL_ARRAY_BUFFER, &vertices, GL_STATIC_DRAW);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ibo);
            upload_buffer(GL_ELEMENT_ARRAY_BUFFER, &indices, GL_STATIC_DRAW);
            bind_vertex_layout();
            glBindVertexArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }
        mesh
    }

    fn delete(self) {
        delete_vertex_array(self.vao);
        delete_buffer(self.vbo);
        delete_buffer(self.ibo);
    }
}

fn gl_string(name: GLenum) -> String {
    unsafe {
        let p = glGetString(name);
        if p.is_null() {
            return String::from("?");
        }
        CStr::from_ptr(p as *const c_char).to_string_lossy().to_string()
    }
}


fn push_box(out: &mut Vec<f32>, min: [f32; 3], max: [f32; 3]) {
    let c = |x: usize, y: usize, z: usize| -> [f32; 3] {
        [if x == 0 { min[0] } else { max[0] }, if y == 0 { min[1] } else { max[1] }, if z == 0 { min[2] } else { max[2] }]
    };
    let faces: [[[usize; 3]; 4]; 6] = [
        [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]],
        [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
        [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
        [[1, 0, 0], [1, 0, 1], [1, 1, 1], [1, 1, 0]],
        [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
        [[0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]],
    ];
    for f in faces.iter() {
        let idx = [0usize, 1, 2, 0, 2, 3];
        for &i in idx.iter() {
            let p = c(f[i][0], f[i][1], f[i][2]);
            out.extend_from_slice(&p);
        }
    }
}

/// The twelve edges of a box as thin boxes (a wireframe that is the same thickness on every screen).
fn outline_vertices(min: [f32; 3], max: [f32; 3], t: f32) -> Vec<f32> {
    let mut out = Vec::with_capacity(12 * 36 * 3);
    for axis in 0..3 {
        for a in 0..2 {
            for b in 0..2 {
                let mut lo = [0.0f32; 3];
                let mut hi = [0.0f32; 3];
                for k in 0..3 {
                    if k == axis {
                        lo[k] = min[k] - t;
                        hi[k] = max[k] + t;
                    } else {
                        let which = if (k + 3 - axis) % 3 == 1 { a } else { b };
                        let v = if which == 0 { min[k] } else { max[k] };
                        lo[k] = v - t;
                        hi[k] = v + t;
                    }
                }
                push_box(&mut out, lo, hi);
            }
        }
    }
    out
}


/// The sky: one big triangle. `masked` is for the sky drawn after everything else, when the caller has already set
/// the depth test up so that it only reaches pixels nothing was drawn on; otherwise it is drawn alone, behind all.
fn draw_sky(wg: &WorldGl, dummy_vao: GLuint, yaw: f32, pitch: f32, aspect: f32, masked: bool) {
    let cp = pitch.cos();
    let f = Vec3::new(cp * yaw.sin(), pitch.sin(), -cp * yaw.cos());
    let right = f.cross(Vec3::new(0.0, 1.0, 0.0)).normalized();
    let up = right.cross(f);
    let tan_half = (FOV_DEGREES.to_radians() * 0.5).tan();
    unsafe {
        if !masked {
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
        }
        glDisable(GL_CULL_FACE);
        wg.sky.prog.use_program();
        glUniform3f(wg.sky.forward, f.x, f.y, f.z);
        glUniform3f(wg.sky.right, right.x, right.y, right.z);
        glUniform3f(wg.sky.up, up.x, up.y, up.z);
        glUniform2f(wg.sky.tan, tan_half * aspect, tan_half);
        glUniform3f(wg.sky.horizon, HORIZON[0], HORIZON[1], HORIZON[2]);
        glUniform3f(wg.sky.zenith, ZENITH[0], ZENITH[1], ZENITH[2]);
        glUniform3f(wg.sky.sun, SUN[0], SUN[1], SUN[2]);
        glBindVertexArray(dummy_vao);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glBindVertexArray(0);
        if !masked {
            glDepthMask(GL_TRUE);
        }
    }
}

/// Makes one build of the terrain shader the current program and gives it what is the same for every chunk.
fn use_terrain(variant: &TerrainVariant, view_proj: &[f32; 16], fog: &Fog) {
    variant.prog.use_program();
    set_mat4(variant.view_proj, view_proj);
    unsafe { glUniform1i(variant.tex, 0) };
    fog.apply(variant.fog_color, variant.fog);
}

/// The cloud layer: one big quad high above the player. Its shape comes from the noise texture on unit 2, so the
/// shader only looks it up; the picture drifts with the wind and wraps around, so nothing needs to be uploaded.
/// The caller sets the depth state up (the clouds are drawn after the terrain, only where nothing else is).
fn draw_clouds(wg: &WorldGl, view_proj: &[f32; 16], cam: &CameraState, time: f64) {
    let c = &wg.cloud;
    let origin = cloud_noise::map_origin(cam.x, cam.z, time);
    let scale = (1.0 / cloud_noise::BLOCKS_PER_REPEAT) as f32;
    unsafe {
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        c.prog.use_program();
        set_mat4(c.view_proj, view_proj);
        glUniform1f(c.height, CLOUD_HEIGHT - cam.y as f32);
        glUniform1f(c.half, CLOUD_HALF);
        glUniform4f(c.map, scale, scale, origin[0], origin[1]);
        glUniform1i(c.noise, 2);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        glDisable(GL_BLEND);
    }
}

fn bind_textures(block_tex: GLuint, font_tex: GLuint, cloud_tex: GLuint) {
    unsafe {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D_ARRAY, block_tex);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, font_tex);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, cloud_tex);
        glActiveTexture(GL_TEXTURE0);
    }
}

impl Renderer {
    /// Needs a current GL context. Fails only if the UI itself cannot be drawn.
    pub fn new() -> Result<Renderer, String> {
        let info = GlInfo { vendor: gl_string(GL_VENDOR), renderer: gl_string(GL_RENDERER), version: gl_string(GL_VERSION) };
        crate::logi!("GL {} on {} ({})", info.version, info.renderer, info.vendor);
        let up = Program::new(UI_VS, UI_FS).map_err(|e| format!("ui {}", e))?;
        let ui = UiProg { proj: up.uniform("uProj"), tex: up.uniform("uTex"), font: up.uniform("uFont"), prog: up };
        let composite = match Composite::new() {
            Ok(c) => Some(c),
            Err(e) => {
                // the game still works, it just cannot draw the world smaller than the screen or keep a paused picture
                crate::loge!("lower resolution disabled: {}", e);
                crate::diag::note(&format!("lower resolution disabled: {}", e));
                None
            }
        };
        let (world, error) = match WorldGl::new() {
            Ok(w) => (Some(w), None),
            Err(e) => {
                crate::loge!("world shaders failed: {}", e);
                (None, Some(e))
            }
        };
        let far = if world.is_some() {
            match FarRenderer::new() {
                Ok(f) => Some(f),
                Err(e) => {
                    // the game still works, it just cannot show anything beyond the block world
                    crate::loge!("far terrain disabled: {}", e);
                    None
                }
            }
        } else {
            None
        };
        let block_tex = create_block_texture();
        let font_tex = create_font_texture();
        let cloud_tex = create_cloud_texture();
        let gpu_timer = GpuTimer::new(&gl_string(GL_EXTENSIONS));
        crate::logi!("GPU timer queries: {}", if gpu_timer.is_some() { "available" } else { "not offered by this driver" });

        let ui_vao = gen_vertex_array();
        let ui_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, ui_vbo);
            let stride = UI_VERTEX_SIZE as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 8 as *const c_void);
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 16 as *const c_void);
            glEnableVertexAttribArray(3);
            glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, 20 as *const c_void);
            glBindVertexArray(0);
        }
        let line_vao = gen_vertex_array();
        let line_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(line_vao);
            glBindBuffer(GL_ARRAY_BUFFER, line_vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 12, 0 as *const c_void);
            glBindVertexArray(0);
        }
        let dummy_vao = gen_vertex_array();

        let mut error_batch = UiBatch::new();
        if let Some(e) = error.as_ref() {
            let mut y = 20.0;
            error_batch.text(20.0, y, 3.0, "SHADER ERROR - WORLD NOT DRAWN", [255, 120, 120, 255]);
            y += 40.0;
            for line in e.lines().take(14) {
                let short: String = line.chars().take(70).collect();
                error_batch.text(20.0, y, 2.0, &short, [255, 255, 255, 255]);
                y += 20.0;
            }
        }

        let mut renderer = Renderer {
            ui,
            world,
            far,
            error,
            block_tex,
            font_tex,
            cloud_tex,
            map: MapGpu::new(),
            errors: ErrorWatch::new(),
            flicker: FlickerProbe::new(),
            world_redrawn: false,
            probe_row: Vec::new(),
            gpu_timer,
            ui_vao,
            ui_vbo,
            line_vao,
            line_vbo,
            dummy_vao,
            chunks: ChunkStore::new(),
            draw_list: DrawList::new(),
            pending: VecDeque::new(),
            planner: Planner::new(),
            route_log: RouteLog::new(),
            composite,
            target: None,
            composites_checked: 0,
            time: 0.0,
            error_batch,
            info,
            gauges: RenderGauges::default(),
        };
        renderer.warm_up();
        Ok(renderer)
    }

    /// Draws every shader once into a corner of the screen. Phone drivers finish building a shader the first time
    /// it is drawn with (which can take 50 to 200 ms and shows up as a freeze when the first leaf or the first
    /// water comes into view); doing it here, before the game starts, moves that to the start-up.
    fn warm_up(&mut self) {
        let (wg, mesh) = match self.world.as_ref() {
            Some(w) => (w, WarmUpMesh::new()),
            None => return,
        };
        let identity: [f32; 16] = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0];
        let fog = Fog { color: [0.5, 0.6, 0.8], start: 10.0, end: 100.0 };
        bind_textures(self.block_tex, self.font_tex, self.cloud_tex);
        unsafe {
            glViewport(0, 0, WARM_UP_PIXELS, WARM_UP_PIXELS);
            glEnable(GL_SCISSOR_TEST);
            glScissor(0, 0, WARM_UP_PIXELS, WARM_UP_PIXELS);
            glDisable(GL_CULL_FACE);
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
            glDisable(GL_BLEND);

            // the block shaders (the state they are used with: solid, then blended water)
            for variant in [&wg.terrain.opaque, &wg.terrain.alpha] {
                variant.prog.use_program();
                set_mat4(variant.view_proj, &identity);
                glUniform3f(variant.offset, 0.0, 0.0, 0.0);
                glUniform1i(variant.tex, 0);
                fog.apply(variant.fog_color, variant.fog);
                glBindVertexArray(mesh.vao);
                glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, std::ptr::null());
            }
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            let w = &wg.water;
            w.prog.use_program();
            set_mat4(w.view_proj, &identity);
            glUniform3f(w.offset, 0.0, 0.0, 0.0);
            glUniform1i(w.tex, 0);
            fog.apply(w.fog_color, w.fog);
            glUniform1f(w.time, 0.0);
            glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, std::ptr::null());
            glBindVertexArray(0);

            // sky and clouds
            glDisable(GL_BLEND);
        }
        draw_sky(wg, self.dummy_vao, 0.0, 0.0, 1.0, false);
        unsafe {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            let c = &wg.cloud;
            c.prog.use_program();
            set_mat4(c.view_proj, &identity);
            glUniform1f(c.height, 1.0);
            glUniform1f(c.half, CLOUD_HALF);
            glUniform4f(c.map, 0.001, 0.001, 0.0, 0.0);
            glUniform1i(c.noise, 2);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

            // the lines
            let l = &wg.line;
            l.prog.use_program();
            set_mat4(l.view_proj, &identity);
            glUniform4f(l.color, 0.0, 0.0, 0.0, 0.5);
            glBindVertexArray(mesh.vao);
            glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, std::ptr::null());
            glBindVertexArray(0);
            glDisable(GL_BLEND);
        }
        // the program that puts an off-screen picture on the screen (any texture will do for building it)
        if let Some(c) = self.composite.as_ref() {
            c.draw(self.font_tex, self.dummy_vao);
        }
        unsafe {
            glDepthMask(GL_TRUE);
            glDisable(GL_SCISSOR_TEST);
        }
        if let Some(f) = self.far.as_mut() {
            f.warm_up();
        }
        mesh.delete();
        // the picture drawn into the corner is thrown away by the first real frame's clear; the shaders stay built
        let error = unsafe { glGetError() };
        if error != 0 {
            crate::logw!("the shader warm-up left GL error 0x{:x} (harmless)", error);
        }
    }

    pub fn has_world_pipeline(&self) -> bool {
        self.world.is_some()
    }

    /// True when far terrain can be drawn (its shader built).
    pub fn has_far_terrain(&self) -> bool {
        self.far.is_some()
    }

    pub fn gl_info(&self) -> &GlInfo {
        &self.info
    }

    /// The numbers of the last frame, for the debug log.
    pub fn gauges(&self) -> RenderGauges {
        self.gauges
    }

    /// The GL context is gone: forget every handle (they are invalid anyway).
    pub fn forget_gpu_objects(&mut self) {
        if let Some(timer) = self.gpu_timer.as_mut() {
            timer.forget();
        }
        self.chunks.forget();
        self.map.forget();
        self.pending.clear();
        if let Some(f) = self.far.as_mut() {
            f.forget();
        }
        // the target's handles died with the context
        self.planner.picture_lost();
        if let Some(t) = self.target.take() {
            std::mem::forget(t);
        }
    }

    /// Makes sure the off-screen target is `size` pixels big, making a new one if it is not. `Some(true)` if a new target
    /// was made (whatever the old one held is gone), `Some(false)` if the one there already has the size, `None` if the GPU
    /// would not make one.
    fn ensure_target(&mut self, size: (i32, i32)) -> Option<bool> {
        if let Some(t) = self.target.as_ref() {
            if t.size() == size {
                return Some(false);
            }
        }
        self.drop_target();
        let made = SceneTarget::create(size.0, size.1)?;
        self.target = Some(made);
        self.composites_checked = 0;
        Some(true)
    }

    /// Frees the off-screen picture (and what it was showing).
    fn drop_target(&mut self) {
        self.planner.picture_lost();
        if let Some(t) = self.target.take() {
            t.delete();
        }
    }

    /// What the paused world looks like right now (see `PictureKey`).
    fn picture_key(&self, app: &App, width: i32, height: i32) -> PictureKey {
        let s = app.game_settings();
        let camera = match app.camera() {
            Some(c) => [c.x.to_bits(), c.y.to_bits(), c.z.to_bits(), (c.yaw as f64).to_bits(), (c.pitch as f64).to_bits()],
            None => [0; 5],
        };
        PictureKey {
            size: (width, height),
            settings: (s.render_distance, s.detail_radius(), s.resolution_percent, s.clouds),
            meshes: (self.chunks.len(), self.far.as_ref().map(|f| f.tile_count()).unwrap_or(0)),
            camera,
        }
    }

    /// Decides how this frame's world reaches the screen (see `frame::plan`) and makes sure the off-screen picture that way
    /// needs is there.
    fn plan_frame(&mut self, app: &App, world_on: bool, width: i32, height: i32) -> Route {
        let frozen = world_on && app.world_frozen();
        let needs = FrameNeeds {
            screen: (width, height),
            world_on,
            frozen,
            percent: app.game_settings().resolution_percent,
            offscreen_ok: self.composite.is_some(),
        };
        let key = if frozen { Some(self.picture_key(app, width, height)) } else { None };
        // Asked again when the answer cannot be used: a size the GPU refuses is not planned again, and a kept picture whose
        // target had to be made anew is not a kept picture any more. Each round settles or refuses one size.
        for _ in 0..3 {
            let route = self.planner.plan(&needs, key);
            let (size, source) = match route {
                Route::Picture { size, source } => (size, source),
                _ => {
                    self.drop_target();
                    return route;
                }
            };
            match self.ensure_target(size) {
                Some(false) => return route,
                Some(true) if source != PictureSource::Kept => return route,
                Some(true) => {}
                None => {
                    crate::logw!("no off-screen picture of {}x{} from this GPU: drawing at full size", size.0, size.1);
                    self.planner.refuse(size);
                }
            }
        }
        self.drop_target();
        Route::Direct
    }

    /// Brings the GPU's copies in line with the game: frees what was dropped and copies new meshes over, but
    /// only as many as fit the time budget so a burst of finished chunks cannot stall a frame.
    fn sync_meshes(&mut self, app: &mut App) {
        let _upload_time = probe::scope(Stage::Upload);
        let loading = app.screen == Screen::Loading;
        let mut uploaded_chunks = 0u64;
        let mut uploaded_bytes = 0u64;
        let mut uploaded_tiles = 0u64;
        match app.engine.as_mut() {
            Some(engine) => {
                // far terrain that the renderer cannot draw is not worth building
                engine.far_available = self.far.is_some();
                for p in engine.manager.take_removed() {
                    self.chunks.remove(p);
                }
                for up in engine.manager.take_uploads() {
                    self.pending.push_back(up);
                }
                if let Some(far) = self.far.as_mut() {
                    for key in engine.far.take_removed() {
                        far.remove(key);
                    }
                }
                let budget = if loading { UPLOAD_BUDGET_LOADING_NS } else { UPLOAD_BUDGET_NS };
                let start = Instant::now();
                let max_chunks = if loading { UPLOAD_MAX_CHUNKS_LOADING } else { UPLOAD_MAX_CHUNKS };
                while let Some((p, m)) = self.pending.pop_front() {
                    if !engine.manager.world.contains(p) {
                        continue; // unloaded while it waited
                    }
                    uploaded_bytes += self.chunks.upload(p, m) as u64;
                    uploaded_chunks += 1;
                    if uploaded_chunks as usize >= max_chunks || start.elapsed().as_nanos() as u64 > budget {
                        break;
                    }
                }
                if let Some(far) = self.far.as_mut() {
                    let max_tiles = if loading { UPLOAD_MAX_TILES_LOADING } else { UPLOAD_MAX_TILES };
                    while (uploaded_tiles as usize) < max_tiles {
                        // one at a time: a tile counts as present (and its parent leaves a hole for it) once taken
                        let mut ready = engine.far.take_ready(1);
                        let tile = match ready.pop() {
                            Some(t) => t,
                            None => break,
                        };
                        far.upload(tile);
                        uploaded_tiles += 1;
                        if start.elapsed().as_nanos() as u64 > budget {
                            break;
                        }
                    }
                }
            }
            None => {
                if !self.chunks.is_empty() {
                    self.chunks.clear();
                }
                if let Some(f) = self.far.as_mut() {
                    if f.tile_count() > 0 {
                        f.clear();
                    }
                }
                self.pending.clear();
            }
        }
        probe::count(Counter::UploadChunks, uploaded_chunks);
        probe::count(Counter::UploadBytes, uploaded_bytes);
        probe::count(Counter::UploadTiles, uploaded_tiles);
    }

    /// Draws one frame of `app` into the current surface (`width` x `height` pixels).
    ///
    /// The frame is whole passes, each starting with a clear of everything it draws into (see `target`): the world (into
    /// the off-screen picture, or straight onto the screen), then, for a picture, the screen's pass that puts it there,
    /// and the UI last.
    pub fn render(&mut self, app: &mut App, width: i32, height: i32, dt: f32) {
        let _render_time = probe::scope(Stage::Render);
        self.time += dt;
        self.gauges.passes = PassGauges::default();
        // the timer's results are read before this frame's first GL command, never while one of its passes is open
        if let Some(timer) = self.gpu_timer.as_mut() {
            timer.poll();
            self.gauges.gpu_ms = timer.latest_ms();
        }
        self.watch("the end of the last frame or the setup");
        self.sync_meshes(app);
        self.watch("the mesh uploads");
        let occlusion = app.game_settings().occlusion_culling;
        self.chunks.set_occlusion(occlusion);

        let cam = app.camera();
        let sky = match cam {
            Some(c) if c.underwater => UNDERWATER,
            _ => HORIZON,
        };
        let world_on = app.world_visible() && cam.is_some() && self.world.is_some();
        let route = self.plan_frame(app, world_on, width, height);
        if let Some(line) = self.route_log.changed(&route, (width, height)) {
            crate::logi!("{}", line);
            crate::diag::note(&line);
        }
        let view = self.draw_route(app, cam, route, sky, width, height);
        self.watch(if world_on { "the world" } else { "the sky" });
        self.gauges.view_w = view.0;
        self.gauges.view_h = view.1;
        self.gauges.gpu_chunks = self.chunks.len() as u32;
        self.gauges.gpu_tiles = self.far.as_ref().map(|f| f.tile_count() as u32).unwrap_or(0);
        self.gauges.occlusion_searches = self.chunks.searches;
        {
            let _ui_time = probe::scope(Stage::DrawUi);
            self.map.sync(&app.map);
            self.draw_ui(&app.ui, width, height);
            if self.error.is_some() {
                let batch = std::mem::take(&mut self.error_batch);
                self.draw_ui(&batch, width, height);
                self.error_batch = batch;
            }
        }
        self.watch("the UI");
        self.errors.end_frame();
        self.probe_flicker(app.screen_kind(), width, height);
    }

    /// Draws the world (or, on the menus, the sky) onto the screen the way `route` says, leaving the screen ready for the UI.
    /// Returns the size the world was drawn at.
    fn draw_route(&mut self, app: &App, cam: Option<CameraState>, route: Route, sky: [f32; 3], width: i32, height: i32) -> (i32, i32) {
        match route {
            Route::Sky => {
                begin_screen_pass(width, height, sky);
                if let Some(wg) = self.world.as_ref() {
                    draw_sky(wg, self.dummy_vao, app.time * 0.05, 0.25, width as f32 / height.max(1) as f32, false);
                }
                (width, height)
            }
            Route::Direct => {
                begin_screen_pass(width, height, sky);
                if let Some(c) = cam {
                    self.draw_timed_world(app, &c, width, height);
                }
                (width, height)
            }
            Route::Picture { size, source } => {
                if source != PictureSource::Kept {
                    let began = match self.target.as_ref() {
                        Some(t) => {
                            t.begin_pass(sky);
                            true
                        }
                        None => false,
                    };
                    if let (true, Some(c)) = (began, cam) {
                        self.draw_timed_world(app, &c, size.0, size.1);
                    }
                    self.watch("the off-screen picture");
                }
                begin_screen_pass(width, height, sky);
                if self.show_picture() {
                    if let PictureSource::FreshKeep(key) = source {
                        self.planner.picture_kept(key);
                    }
                } else {
                    crate::logw!("putting the off-screen picture on the screen failed: drawing at full size from now on");
                    crate::diag::note("putting the off-screen picture on the screen failed: drawing at full size from now on");
                    self.planner.refuse(size);
                    self.drop_target();
                }
                size
            }
        }
    }

    /// Puts the off-screen picture on the screen (which has been cleared and is the surface being drawn to). The first few
    /// times it also looks for a GL error; false means the GPU could not do it.
    fn show_picture(&mut self) -> bool {
        let (composite, target) = match (self.composite.as_ref(), self.target.as_ref()) {
            (Some(c), Some(t)) => (c, t),
            _ => return false,
        };
        let check = self.composites_checked < 3;
        self.composites_checked += 1;
        if check {
            unsafe {
                while glGetError() != 0 {}
            }
        }
        composite.draw(target.texture(), self.dummy_vao);
        !check || unsafe { glGetError() } == 0
    }

    /// The world pass, bracketed by the GPU timer (see `gpu_timer`: it measures this pass and nothing else).
    fn draw_timed_world(&mut self, app: &App, cam: &CameraState, width: i32, height: i32) {
        self.world_redrawn = true;
        if let Some(timer) = self.gpu_timer.as_mut() {
            timer.begin();
        }
        self.draw_world(app, cam, width, height);
        if let Some(timer) = self.gpu_timer.as_mut() {
            timer.end();
        }
    }

    /// On the screens where nothing should change quickly (the menus), reads a few rows of the finished picture back and
    /// lets `FlickerProbe` say if the picture jumped between two frames, so that a blinking menu can be told apart from a
    /// blinking display. It reads only while one of those screens is up, for a few seconds after it came up (the read
    /// makes the CPU wait for the GPU), and the log gets one line per jump and one summary per visit.
    fn probe_flicker(&mut self, kind: ScreenKind, width: i32, height: i32) {
        let watched = matches!(kind, ScreenKind::Menu | ScreenKind::Paused | ScreenKind::Settings);
        let frame = self.flicker.begin_frame(kind as u8, kind.name(), watched);
        if let Some(line) = frame.note {
            crate::logi!("{}", line);
            crate::diag::note(&line);
        }
        if !frame.read || width < 16 || height < 16 {
            return;
        }
        self.probe_row.resize(width as usize * 4, 0);
        let mut rows: RowSums = [0; ROWS];
        for (i, sum) in rows.iter_mut().enumerate() {
            let y = (height as i64 * (2 * i as i64 + 1) / (2 * ROWS as i64)) as i32;
            unsafe {
                glReadPixels(0, y, width, 1, GL_RGBA, GL_UNSIGNED_BYTE, self.probe_row.as_mut_ptr() as *mut c_void);
            }
            *sum = self.probe_row.chunks_exact(4).map(|p| p[0] as u64 + p[1] as u64 + p[2] as u64).sum();
        }
        // a world drawn again since the last read (a view setting changed behind the settings screen) is no blink
        let line = if std::mem::take(&mut self.world_redrawn) { self.flicker.feed_after_redraw(rows) } else { self.flicker.feed(rows) };
        if let Some(line) = line {
            crate::logw!("{}", line);
            crate::diag::note(&line);
        }
    }

    /// The world: the blocks, the far terrain behind them, the sky and clouds where nothing else was drawn, the aim
    /// outline and the water. `width` x `height` is the size of the surface being drawn into.
    ///
    /// Everything that is opaque is drawn nearest first and the sky is drawn last, so the GPU never shades a pixel
    /// that something nearer covers: the far terrain is thrown away wherever blocks are, and the sky and clouds
    /// (which used to be shaded over the whole screen and then painted over) only where nothing is.
    fn draw_world(&mut self, app: &App, cam: &CameraState, width: i32, height: i32) {
        let wg = match self.world.as_ref() {
            Some(w) => w,
            None => return,
        };
        let settings = app.game_settings();
        let aspect = width as f32 / height.max(1) as f32;
        let fov = FOV_DEGREES.to_radians();
        let view_chunks = settings.render_distance as f32;
        let fog_end_clear = (view_chunks * 16.0 - 8.0).max(48.0);
        let fog = if cam.underwater {
            Fog { color: UNDERWATER, start: 0.0, end: 26.0 }
        } else {
            Fog { color: HORIZON, start: fog_end_clear * 0.55, end: fog_end_clear }
        };
        // far terrain is only drawn when the render distance reaches beyond the block world, and not under water
        let far_terrain = match app.engine.as_ref() {
            Some(e) => !cam.underwater && self.far.is_some() && e.far.active() && settings.far_terrain_wanted(),
            None => false,
        };
        // the block world only needs a depth range as deep as the real blocks go (see below), the rest is far terrain
        let far_plane = if far_terrain {
            let detail_blocks = settings.detail_radius() as f32 * 16.0;
            // farthest corner of the farthest chunk, counting the height the world can have
            ((detail_blocks + 16.0).powi(2) + 160.0 * 160.0).sqrt().max(96.0)
        } else {
            (fog.end * 1.08 + 24.0).max(64.0)
        };

        let cp = cam.pitch.cos();
        let forward = Vec3::new(cp * cam.yaw.sin(), cam.pitch.sin(), -cp * cam.yaw.cos());
        let view = mat4_view_dir(forward, Vec3::new(0.0, 1.0, 0.0));
        let vp = mat4_mul(&mat4_perspective(fov, aspect, NEAR_PLANE, far_plane), &view);
        let frustum = Frustum::from_matrix(&vp);
        bind_textures(self.block_tex, self.font_tex, self.cloud_tex);

        // The depth buffer is shared: the real blocks get its first part and the far terrain the rest (so the blocks
        // are always in front of it, with no clear of the depth buffer in between), and the sky is drawn at the very
        // back, only where nothing else was.
        let block_depth_end = if far_terrain { BLOCK_DEPTH_SPLIT } else { FAR_DEPTH_END };
        let mut passes = PassGauges::default();

        // what to draw, nearest first
        let stats = {
            let _cull_time = probe::scope(Stage::Cull);
            self.chunks.update_visibility(cam.x, cam.y, cam.z);
            self.draw_list.collect(&self.chunks, &frustum, [cam.x, cam.y, cam.z], far_plane + 24.0)
        };
        self.gauges.cull = stats;


        {
            let _world_time = probe::scope(Stage::DrawWorld);
            unsafe {
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LEQUAL);
                glDepthMask(GL_TRUE);
                glDepthRangef(0.0, block_depth_end);
                glEnable(GL_CULL_FACE);
                glCullFace(GL_BACK);
                glFrontFace(GL_CCW);
                glDisable(GL_BLEND);
            }
            // solid blocks first, nearest first: no discard in their shader, so whatever is hidden behind them is
            // thrown away before it is shaded
            let solid = &wg.terrain.opaque;
            use_terrain(solid, &vp, &fog);
            passes.opaque = self.draw_list.draw_opaque(solid.offset);

            // leaves, then plants (seen from both sides): these shaders discard see-through pixels
            let cutout = &wg.terrain.alpha;
            use_terrain(cutout, &vp, &fog);
            passes.cutout = self.draw_list.draw_cutout(cutout.offset);
            unsafe { glDisable(GL_CULL_FACE) };
            passes.plants = self.draw_list.draw_plants(cutout.offset);
        }

        // far terrain: after the blocks, nearest tile first, in the part of the depth buffer behind the blocks'
        if far_terrain {
            if let (Some(far), Some(engine)) = (self.far.as_mut(), app.engine.as_ref()) {
                let _far_time = probe::scope(Stage::DrawFar);
                let far_end = fog.end * 1.05 + 64.0;
                // the nearest far terrain is at least the detail radius away, so with a very long view the near plane
                // can move out; that keeps the depth buffer precise enough over tens of kilometres
                let far_near = (far_end / 2000.0).max(FAR_NEAR_PLANE).min(64.0);
                let vp_far = mat4_mul(&mat4_perspective(fov, aspect, far_near, far_end), &view);
                let far_frustum = Frustum::from_matrix(&vp_far);
                unsafe {
                    glDepthRangef(BLOCK_DEPTH_SPLIT, FAR_DEPTH_END);
                    glDepthMask(GL_TRUE);
                }
                // the haze of the far terrain starts at the edge of the block world (under water the heavier fog stays)
                let detail_blocks = settings.detail_radius() as f32 * 16.0;
                let far_fog = Fog { start: fog.start.min(detail_blocks.max(64.0)), ..fog };
                // real blocks hide the finest far tiles inside the block world, so those are not drawn
                let covered_radius = (detail_blocks - 40.0).max(0.0) as f64;
                let drawn: FarDrawn = far.draw(&engine.far, &vp_far, &far_frustum, [cam.x, cam.y, cam.z], &far_fog, &self.chunks, covered_radius);
                probe::count(Counter::TilesDrawn, drawn.tiles as u64);
                probe::count(Counter::DrawCalls, drawn.calls as u64);
                probe::count(Counter::Triangles, drawn.triangles);
                passes.far = DrawTotals { calls: drawn.calls, triangles: drawn.triangles };
                unsafe {
                    glDepthRangef(0.0, block_depth_end);
                    glDisable(GL_CULL_FACE);
                }
            }
        }

        {
            let _world_time = probe::scope(Stage::DrawWorld);
            // sky and clouds last: drawn at depth 1.0 (range 1..1), so the depth test lets them through only where
            // the depth buffer is still empty. Nothing that terrain covers is ever shaded for them.
            if !cam.underwater {
                unsafe {
                    glEnable(GL_DEPTH_TEST);
                    glDepthFunc(GL_LEQUAL);
                    glDepthMask(GL_FALSE);
                    glDepthRangef(1.0, 1.0);
                }
                draw_sky(wg, self.dummy_vao, cam.yaw, cam.pitch, aspect, true);
                if settings.clouds {
                    let vp_clouds = mat4_mul(&mat4_perspective(fov, aspect, 1.0, 9000.0), &view);
                    draw_clouds(wg, &vp_clouds, cam, self.time as f64);
                }
                unsafe {
                    glDepthRangef(0.0, block_depth_end);
                    glDepthMask(GL_TRUE);
                }
            }

            // the block the player is aiming at
            if let Some(engine) = app.engine.as_ref() {
                if let Some(hit) = engine.last_hit {
                    if app.screen == Screen::Playing {
                        let min = [hit.bx as f32 - cam.x as f32 - 0.003, hit.by as f32 - cam.y as f32 - 0.003, hit.bz as f32 - cam.z as f32 - 0.003];
                        let max = [min[0] + 1.006, min[1] + 1.006, min[2] + 1.006];
                        let verts = outline_vertices(min, max, 0.012);
                        unsafe {
                            glEnable(GL_BLEND);
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                            glDepthMask(GL_FALSE);
                            wg.line.prog.use_program();
                            set_mat4(wg.line.view_proj, &vp);
                            glUniform4f(wg.line.color, 0.0, 0.0, 0.0, 0.78);
                            glBindVertexArray(self.line_vao);
                            glBindBuffer(GL_ARRAY_BUFFER, self.line_vbo);
                            upload_buffer(GL_ARRAY_BUFFER, &verts, GL_STREAM_DRAW);
                            glDrawArrays(GL_TRIANGLES, 0, (verts.len() / 3) as GLsizei);
                            glBindVertexArray(0);
                            glDepthMask(GL_TRUE);
                            glDisable(GL_BLEND);
                        }
                    }
                }
            }

            // water last, far to near
            unsafe {
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                glDepthMask(GL_FALSE);
                glDisable(GL_CULL_FACE);
                let w = &wg.water;
                w.prog.use_program();
                set_mat4(w.view_proj, &vp);
                glUniform1i(w.tex, 0);
                fog.apply(w.fog_color, w.fog);
                glUniform1f(w.time, self.time);
            }
            passes.water = self.draw_list.draw_water(wg.water.offset);
            unsafe {
                glBindVertexArray(0);
                glDepthMask(GL_TRUE);
                glDisable(GL_BLEND);
            }
        }
        unsafe { glDepthRangef(0.0, 1.0) };
        let mut totals = passes.opaque;
        totals.add(passes.cutout);
        totals.add(passes.plants);
        totals.add(passes.water);
        self.gauges.passes = passes;
        probe::count(Counter::ChunksDrawn, stats.drawn as u64);
        probe::count(Counter::DrawCalls, totals.calls as u64);
        probe::count(Counter::Triangles, totals.triangles);
    }

    /// Draws a batch of 2D triangles over the screen, in the order they were added. The UI program draws all of it, in one
    /// go for most screens; the world map picture, if the batch has one, is cut out and drawn by the map's own program (see
    /// `UiBatch::runs` and `map_gpu`).
    fn draw_ui(&mut self, batch: &UiBatch, width: i32, height: i32) {
        if batch.verts.is_empty() {
            return;
        }
        bind_textures(self.block_tex, self.font_tex, self.cloud_tex);
        let proj = mat4_ortho_pixels(width as f32, height as f32);
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_CULL_FACE);
            glDepthMask(GL_FALSE);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            self.ui.prog.use_program();
            set_mat4(self.ui.proj, &proj);
            glUniform1i(self.ui.tex, 0);
            glUniform1i(self.ui.font, 1);
            glBindVertexArray(self.ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, self.ui_vbo);
            upload_buffer(GL_ARRAY_BUFFER, &batch.verts, GL_STREAM_DRAW);
        }
        let mut current = RunKind::Ui;
        for run in batch.runs() {
            match run.kind {
                RunKind::Ui => {
                    if current != RunKind::Ui {
                        self.ui.prog.use_program();
                        current = RunKind::Ui;
                    }
                }
                RunKind::Map => {
                    // nothing to draw the picture with (yet, or at all): it is left out and the program stays as it was
                    if !self.map.begin_draw(&proj) {
                        continue;
                    }
                    current = RunKind::Map;
                }
            }
            unsafe { glDrawArrays(GL_TRIANGLES, run.first as GLint, run.count as GLsizei) };
        }
        unsafe {
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }
    }

    /// Reads the GL error flag (in the first frames only) and puts what it finds in the debug log together with the
    /// part of the frame that was just drawn, so that a driver's objection can be traced.
    fn watch(&mut self, stage: &'static str) {
        if !self.errors.active() {
            return;
        }
        for _ in 0..4 {
            let code = unsafe { glGetError() };
            if code == 0 {
                break;
            }
            if let Some(line) = self.errors.report(code, stage) {
                crate::logw!("{}", line);
                crate::diag::note(&line);
            }
        }
    }
}
