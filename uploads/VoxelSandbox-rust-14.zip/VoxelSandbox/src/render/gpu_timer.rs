//! How long the GPU really takes for the 3D world, from the driver's timer queries (`GL_EXT_disjoint_timer_query`).
//!
//! The CPU cannot see this: it hands the frame over and moves on, and the time shows up later as waiting in some
//! GL call. With the GPU's own number the debug log can say "the GPU needs 22 ms per frame" and the automatic
//! quality control can tell whether there is room to spare even when vertical sync holds the frame rate at 60.
//!
//! One query brackets the pass that draws the world, and nothing else: it begins after that pass has started and ends before
//! another pass (the screen's, with the UI) begins. A query that is begun in one render pass and ended in another is the case
//! phone drivers handle worst, so it is avoided. The UI and the copy of a smaller picture to the screen are not counted; they
//! are a small, steady part of the frame.
//!
//! The results are collected a few frames later, so nothing ever waits for the GPU, and they are collected by `poll`, which
//! the renderer calls at the very start of a frame, before the first GL command of it: asking a driver about a query in the
//! middle of a frame (after a pass has been started) is another thing phone drivers may answer by flushing the work so far,
//! and a tile-based GPU does not like having a pass cut in two. `begin` and `end` only ever issue commands. What a result is
//! worth, and for how long the latest one is offered, is `perf::gpu_reading`. The ES 3.0 query functions accept the
//! extension's `TIME_ELAPSED` target, so no extension function pointers are needed. Any sign of trouble switches the timer off
//! for good.

use super::gl::*;
use crate::perf::gpu_reading::{believable_ms, Reading};

/// Frames that may be in flight at once; a new query is skipped while all are waiting for their result.
const RING: usize = 4;

pub struct GpuTimer {
    queries: [GLuint; RING],
    pending: [bool; RING],
    next: usize,
    running: bool,
    reading: Reading,
    checked_first: bool,
    broken: bool,
}

impl GpuTimer {
    /// `None` unless `extensions` (the `GL_EXTENSIONS` string) lists timer queries.
    pub fn new(extensions: &str) -> Option<GpuTimer> {
        if !extensions.split_whitespace().any(|e| e == "GL_EXT_disjoint_timer_query") {
            return None;
        }
        let mut queries = [0 as GLuint; RING];
        unsafe {
            glGenQueries(RING as GLsizei, queries.as_mut_ptr());
        }
        if queries.iter().any(|&q| q == 0) {
            return None;
        }
        Some(GpuTimer { queries, pending: [false; RING], next: 0, running: false, reading: Reading::new(), checked_first: false, broken: false })
    }

    /// Call once at the start of every frame, before any GL command of it: reads the queries that have finished.
    pub fn poll(&mut self) {
        if self.broken {
            return;
        }
        self.reading.next_frame();
        self.collect();
    }

    /// Call after the world pass has started (its target is bound and cleared), before its first draw call.
    pub fn begin(&mut self) {
        if self.broken || self.running {
            return;
        }
        if self.pending[self.next] {
            return; // every query is still waiting for the GPU: skip this frame
        }
        unsafe {
            glBeginQuery(GL_TIME_ELAPSED_EXT, self.queries[self.next]);
        }
        self.running = true;
    }

    /// Call after the world pass's last draw call, before anything is drawn to another target.
    pub fn end(&mut self) {
        if !self.running {
            return;
        }
        unsafe {
            glEndQuery(GL_TIME_ELAPSED_EXT);
        }
        self.pending[self.next] = true;
        self.next = (self.next + 1) % RING;
        self.running = false;
        if !self.checked_first {
            self.checked_first = true;
            // an error here means the driver does not really support what it advertises
            let error = unsafe { glGetError() };
            if error != 0 {
                crate::logw!("GPU timer queries are not usable (GL error 0x{:x}); the GPU time will not be measured", error);
                self.broken = true;
            }
        }
    }

    /// The GPU time of the most recent frame whose result has arrived, in milliseconds (nothing once that is too long
    /// ago to say anything about the frames now, see `perf::gpu_reading`).
    pub fn latest_ms(&self) -> Option<f32> {
        if self.broken {
            None
        } else {
            self.reading.latest()
        }
    }

    /// Reads the finished queries, oldest first.
    fn collect(&mut self) {
        for i in 0..RING {
            let slot = (self.next + i) % RING;
            if !self.pending[slot] {
                continue;
            }
            let mut available: GLuint = 0;
            unsafe { glGetQueryObjectuiv(self.queries[slot], GL_QUERY_RESULT_AVAILABLE, &mut available) };
            if available == 0 {
                break; // the later ones were issued later and are not ready either
            }
            let mut nanos: GLuint = 0;
            unsafe { glGetQueryObjectuiv(self.queries[slot], GL_QUERY_RESULT, &mut nanos) };
            self.pending[slot] = false;
            let mut disjoint: GLint = 0;
            unsafe { glGetIntegerv(GL_GPU_DISJOINT_EXT, &mut disjoint) };
            if let Some(ms) = believable_ms(nanos, disjoint != 0) {
                self.reading.record(ms);
            }
        }
    }

    /// The GL context is gone: the handles are invalid.
    pub fn forget(&mut self) {
        self.broken = true;
    }
}

impl Drop for GpuTimer {
    fn drop(&mut self) {
        if !self.broken {
            unsafe { glDeleteQueries(RING as GLsizei, self.queries.as_ptr()) };
        }
    }
}
