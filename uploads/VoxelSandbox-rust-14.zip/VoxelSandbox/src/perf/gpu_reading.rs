//! The GPU time that can still be believed.
//!
//! The renderer's timer queries (see `render::gpu_timer`) give one reading per frame at best, and often none: a driver that
//! reports "disjoint" (the GPU changed its clock, was preempted, was suspended) invalidates the reading, and a phone that is
//! hot and busy does that again and again. The rule here is the whole policy: a reading counts if the driver stands behind
//! it, and the latest one is only offered for a short while. Before this existed the last good number was offered for as
//! long as no new one arrived; a debug log showed the same "gpu-time 37.9 ms" for four seconds while the frames in between
//! took anything from 28 to 40 ms, and the quality control was making decisions on a number that was only a memory.
//!
//! Pure logic, no GL, so it is tested on any computer.

/// A reading older than this many frames is no longer offered (about a second and a half at 60 frames per second).
pub const STALE_AFTER_FRAMES: u32 = 90;
/// A reading above this is nonsense (the GPU was reset, the app was suspended, ...), in milliseconds.
pub const MAX_PLAUSIBLE_MS: f32 = 2000.0;

/// What a finished timer query says, in milliseconds, if it can be believed: the driver did not call it disjoint and the
/// time is positive and not absurd.
pub fn believable_ms(nanos: u32, disjoint: bool) -> Option<f32> {
    let ms = nanos as f32 / 1_000_000.0;
    (!disjoint && ms > 0.0 && ms < MAX_PLAUSIBLE_MS).then_some(ms)
}

/// The latest believable reading and how many frames ago it arrived.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Reading {
    ms: Option<f32>,
    age: u32,
}

impl Reading {
    pub fn new() -> Reading {
        Reading::default()
    }

    /// A frame is starting (call once per frame, before `record`ing what finished during it).
    pub fn next_frame(&mut self) {
        self.age = self.age.saturating_add(1);
    }

    /// A believable reading has arrived.
    pub fn record(&mut self, ms: f32) {
        self.ms = Some(ms);
        self.age = 0;
    }

    /// The latest reading, unless it is stale or there never was one.
    pub fn latest(&self) -> Option<f32> {
        if self.age > STALE_AFTER_FRAMES {
            None
        } else {
            self.ms
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_reading_is_believed_only_when_the_driver_stands_behind_it() {
        assert_eq!(believable_ms(22_500_000, false), Some(22.5));
        assert_eq!(believable_ms(22_500_000, true), None, "disjoint: the clock changed or the GPU was preempted");
        assert_eq!(believable_ms(0, false), None, "nothing was measured");
        assert_eq!(believable_ms(2_000_000_000, false), None, "two seconds for a frame is a suspended app");
        assert_eq!(believable_ms(u32::MAX, false), None);
    }

    #[test]
    fn there_is_nothing_to_offer_before_the_first_reading() {
        let mut r = Reading::new();
        assert_eq!(r.latest(), None);
        r.next_frame();
        assert_eq!(r.latest(), None);
    }

    #[test]
    fn a_fresh_reading_is_offered_and_then_replaced() {
        let mut r = Reading::new();
        r.record(21.0);
        assert_eq!(r.latest(), Some(21.0));
        r.next_frame();
        r.record(25.0);
        assert_eq!(r.latest(), Some(25.0));
    }

    #[test]
    fn a_reading_that_stops_being_refreshed_is_withdrawn() {
        let mut r = Reading::new();
        r.record(37.9);
        for _ in 0..STALE_AFTER_FRAMES {
            r.next_frame();
            assert_eq!(r.latest(), Some(37.9), "still believable for {} frames", STALE_AFTER_FRAMES);
        }
        r.next_frame();
        assert_eq!(r.latest(), None, "one frame later it is a memory, not a measurement");
        // and a new one brings it back
        r.record(30.0);
        assert_eq!(r.latest(), Some(30.0));
    }

    #[test]
    fn the_age_does_not_overflow() {
        let mut r = Reading::new();
        r.record(10.0);
        r.age = u32::MAX;
        r.next_frame();
        assert_eq!(r.latest(), None);
    }
}
