//! Test helper: finds faces of chunk meshes that lie on top of each other.
//!
//! The depth buffer cannot tell two faces apart when they share a plane and look the same way: the one drawn last
//! wins pixel by pixel and the picture flickers while the camera moves (z-fighting). The water pass is drawn with
//! both sides showing, so a water face also fights with a block face that only shares its plane from the other side.
//! Faces that look exactly alike can overlap without anyone noticing, so only faces that differ are reported.
//!
//! "Share a plane" means closer than a tolerance, because the depth buffer has a limited resolution too: at distance
//! `d` it cannot separate surfaces closer than about `d * d / 1_000_000` blocks (see `LILY_PAD_LIFT` in the mesher).

use super::{ChunkMeshData, PASS_COUNT, PASS_WATER};
use std::collections::{HashMap, HashSet};

/// Overlaps thinner than this (in blocks) are not reported: merged quads are grown by a hair so that no crack shows
/// between them, and that hair is far too thin to see.
const MIN_OVERLAP: f32 = 0.05;
/// Width of the cells of the grid that keeps the pair search fast.
const GRID: f32 = 4.0;

/// A flat, axis-aligned rectangle of a mesh in world coordinates.
#[derive(Clone, Copy, Debug)]
pub struct Face {
    pub pass: usize,
    /// The axis the face is flat in (0 = x, 1 = y, 2 = z).
    pub axis: usize,
    /// Which way it looks along that axis, +1 or -1.
    pub facing: i8,
    /// Where it lies along that axis.
    pub plane: f32,
    /// Its extent along the other two axes (in axis order), low and high corners.
    pub lo: [f32; 2],
    pub hi: [f32; 2],
    pub layer: u8,
    pub color: [u8; 4],
}

impl Face {
    fn looks_like(&self, other: &Face) -> bool {
        self.pass == other.pass && self.layer == other.layer && self.color == other.color
    }
}

fn across(axis: usize) -> (usize, usize) {
    match axis {
        0 => (1, 2),
        1 => (0, 2),
        _ => (0, 1),
    }
}

/// Every flat axis-aligned quad of `mesh` (plants, which are crossed diagonally, and sloping water are left out).
pub fn faces_of(mesh: &ChunkMeshData, origin_x: f32, origin_z: f32) -> Vec<Face> {
    let mut out = Vec::new();
    for pass in 0..PASS_COUNT {
        let (first, count) = mesh.ranges[pass];
        let end = (first + count) as usize;
        let mut k = first as usize;
        while k + 6 <= end {
            let six = &mesh.indices[k..k + 6];
            k += 6;
            let mut ids: Vec<u32> = Vec::with_capacity(4);
            for &i in six {
                if !ids.contains(&i) {
                    ids.push(i);
                }
            }
            if ids.len() != 4 {
                continue;
            }
            let at = |i: u32| {
                let p = mesh.vertices[i as usize].pos;
                [p[0] + origin_x, p[1], p[2] + origin_z]
            };
            let corners: Vec<[f32; 3]> = ids.iter().map(|&i| at(i)).collect();
            let axis = match (0..3).find(|&a| corners.iter().all(|c| (c[a] - corners[0][a]).abs() < 1e-4)) {
                Some(a) => a,
                None => continue,
            };
            let (a, b, c) = (at(six[0]), at(six[1]), at(six[2]));
            let normal = [
                (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]),
                (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]),
                (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]),
            ];
            let (u, v) = across(axis);
            let low = |d: usize| corners.iter().map(|p| p[d]).fold(f32::MAX, f32::min);
            let high = |d: usize| corners.iter().map(|p| p[d]).fold(f32::MIN, f32::max);
            let first_vertex = mesh.vertices[ids[0] as usize];
            out.push(Face {
                pass,
                axis,
                facing: if normal[axis] >= 0.0 { 1 } else { -1 },
                plane: corners[0][axis],
                lo: [low(u), low(v)],
                hi: [high(u), high(v)],
                layer: first_vertex.info[0],
                color: first_vertex.color,
            });
        }
    }
    out
}

/// Pairs of faces that fight: the same plane (within `tolerance`), overlapping, seen from the same side (or one of
/// them water), and not looking alike.
pub fn fights(faces: &[Face], tolerance: f32) -> Vec<(Face, Face)> {
    let mut cells: HashMap<(usize, i32, i32), Vec<usize>> = HashMap::new();
    for (n, f) in faces.iter().enumerate() {
        for cz in (f.lo[1] / GRID).floor() as i32..=(f.hi[1] / GRID).floor() as i32 {
            for cx in (f.lo[0] / GRID).floor() as i32..=(f.hi[0] / GRID).floor() as i32 {
                cells.entry((f.axis, cx, cz)).or_default().push(n);
            }
        }
    }
    let mut seen: HashSet<(usize, usize)> = HashSet::new();
    let mut out = Vec::new();
    for list in cells.values() {
        for (i, &a) in list.iter().enumerate() {
            for &b in &list[i + 1..] {
                let key = (a.min(b), a.max(b));
                if !seen.insert(key) {
                    continue;
                }
                let (fa, fb) = (&faces[key.0], &faces[key.1]);
                let water = (fa.pass == PASS_WATER) != (fb.pass == PASS_WATER);
                let same_side = fa.facing == fb.facing && fa.pass != PASS_WATER && fb.pass != PASS_WATER
                    || fa.facing == fb.facing && fa.pass == PASS_WATER && fb.pass == PASS_WATER;
                if !(water || same_side) || fa.looks_like(fb) || (fa.plane - fb.plane).abs() > tolerance {
                    continue;
                }
                let wide = fa.hi[0].min(fb.hi[0]) - fa.lo[0].max(fb.lo[0]);
                let deep = fa.hi[1].min(fb.hi[1]) - fa.lo[1].max(fb.lo[1]);
                if wide >= MIN_OVERLAP && deep >= MIN_OVERLAP {
                    out.push((*fa, *fb));
                }
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::climate::Biome;
    use crate::gen::terrain::TerrainGenerator;
    use crate::mesh::mesher::{build_chunk_mesh, MeshContext, MeshInput};
    use crate::mesh::testkit::{chunks_around, mesh_at};
    use crate::mesh::PASS_DOUBLE;
    use crate::world::block::Block;
    use crate::world::chunk::ChunkData;
    use crate::world::config::SEA_LEVEL;
    use crate::world::pos::ChunkPos;

    fn face(pass: usize, axis: usize, facing: i8, plane: f32, lo: [f32; 2], hi: [f32; 2], layer: u8) -> Face {
        Face { pass, axis, facing, plane, lo, hi, layer, color: [128; 4] }
    }

    #[test]
    fn faces_on_one_plane_that_overlap_and_differ_are_found() {
        let a = face(0, 1, 1, 10.0, [0.0, 0.0], [2.0, 2.0], 1);
        let b = face(0, 1, 1, 10.005, [1.0, 1.0], [3.0, 3.0], 2);
        assert_eq!(fights(&[a, b], 0.02).len(), 1);
    }

    #[test]
    fn faces_that_cannot_fight_are_left_alone() {
        let a = face(0, 1, 1, 10.0, [0.0, 0.0], [2.0, 2.0], 1);
        let cases = [
            ("looking alike", face(0, 1, 1, 10.0, [1.0, 1.0], [3.0, 3.0], 1)),
            ("only touching", face(0, 1, 1, 10.0, [2.0, 0.0], [4.0, 2.0], 2)),
            ("a hair of overlap", face(0, 1, 1, 10.0, [1.98, 0.0], [4.0, 2.0], 2)),
            ("far apart along the axis", face(0, 1, 1, 10.5, [0.0, 0.0], [2.0, 2.0], 2)),
            ("looking the other way", face(0, 1, -1, 10.0, [0.0, 0.0], [2.0, 2.0], 2)),
            ("on another axis", face(0, 0, 1, 10.0, [0.0, 0.0], [2.0, 2.0], 2)),
        ];
        for (what, other) in cases {
            assert!(fights(&[a, other], 0.02).is_empty(), "{} must not count", what);
        }
    }

    #[test]
    fn water_fights_with_a_block_face_from_either_side() {
        let block = face(0, 0, 1, 5.0, [0.0, 0.0], [1.0, 1.0], 3);
        let water_same_side = face(PASS_WATER, 0, 1, 5.0, [0.0, 0.0], [1.0, 1.0], 9);
        let water_other_side = face(PASS_WATER, 0, -1, 5.0, [0.0, 0.0], [1.0, 1.0], 9);
        assert_eq!(fights(&[block, water_same_side], 0.02).len(), 1);
        assert_eq!(fights(&[block, water_other_side], 0.02).len(), 1, "water is drawn with both sides showing");
    }

    fn context(gen: &TerrainGenerator) -> MeshContext {
        MeshContext::for_generator(gen)
    }

    /// The faces of the (2 * radius + 1)^2 chunks around `centre`, each meshed the way `merge_of(dx, dz)` says.
    fn faces_in(
        ctx: &MeshContext,
        chunks: &HashMap<(i32, i32), ChunkData>,
        centre: ChunkPos,
        radius: i32,
        merge_of: impl Fn(i32, i32) -> bool,
    ) -> Vec<Face> {
        let mut faces = Vec::new();
        for dz in -radius..=radius {
            for dx in -radius..=radius {
                let mesh = mesh_at(ctx, chunks, centre, (dx, dz), merge_of(dx, dz), true);
                faces.extend(faces_of(&mesh, ((centre.x + dx) * 16) as f32, ((centre.z + dz) * 16) as f32));
            }
        }
        faces
    }

    /// How a block of chunks is meshed: all in detail (near the player), all merged (far away), or the middle chunk in
    /// detail with merged chunks around it (the border between the two kinds).
    type Meshing = (&'static str, fn(i32, i32) -> bool);
    const MESHINGS: [Meshing; 3] = [("near", |_, _| false), ("far", |_, _| true), ("mixed", |dx, dz| dx != 0 || dz != 0)];

    #[test]
    fn a_lily_pad_floats_clear_of_the_water() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        for c in chunks.iter_mut().flatten() {
            for x in 0..16 {
                for z in 0..16 {
                    for y in 0..=30 {
                        c.set(x, y, z, Block::Stone);
                    }
                }
            }
        }
        if let Some(c) = chunks[4].as_mut() {
            for x in 4..12 {
                for z in 4..12 {
                    c.set(x, 31, z, Block::Water);
                }
            }
            c.set(7, 32, 7, Block::LilyPad);
        }
        let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: false }, &ctx);
        let faces = faces_of(&mesh, 0.0, 0.0);
        let pad = faces.iter().find(|f| f.pass == PASS_DOUBLE && f.axis == 1).expect("the lily pad is a flat quad");
        let water = faces
            .iter()
            .find(|f| f.pass == PASS_WATER && f.axis == 1 && f.lo[0] <= 7.0 && f.hi[0] >= 8.0 && f.lo[1] <= 7.0 && f.hi[1] >= 8.0)
            .expect("the water surface under the pad");
        let gap = pad.plane - water.plane;
        assert!(gap >= 0.09, "the pad floats {} above the water: the depth buffer cannot separate that at a distance", gap);
        assert!(gap <= 0.2, "and it still looks like it lies on the water ({} above it)", gap);
        assert!(fights(&faces, 0.09).is_empty(), "nothing in the pond may share a plane with the water");
    }

    /// Chunks around spots of shallow swamp water (where lily pads grow), found by looking for the pads themselves.
    fn lily_pad_chunks(gen: &TerrainGenerator, wanted: usize) -> Vec<ChunkPos> {
        let mut found: Vec<ChunkPos> = Vec::new();
        'search: for ring in 1..60 {
            for k in 0..16 {
                let a = (k as f64 / 16.0 + ring as f64 * 0.13) * std::f64::consts::TAU;
                let (x, z) = ((ring as f64 * 160.0 * a.cos()) as i32, (ring as f64 * 160.0 * a.sin()) as i32);
                let depth = SEA_LEVEL - gen.surface_height(x, z);
                if !(1..=5).contains(&depth) {
                    continue;
                }
                let pos = ChunkPos::of_block(x, z);
                if found.iter().any(|p| (p.x - pos.x).abs() < 6 && (p.z - pos.z).abs() < 6) {
                    continue;
                }
                let chunk = gen.generate(pos);
                let has_pad = (0..16).any(|lx| (0..16).any(|lz| chunk.get(lx, SEA_LEVEL + 1, lz) == Block::LilyPad));
                if has_pad {
                    found.push(pos);
                    if found.len() >= wanted {
                        break 'search;
                    }
                }
            }
        }
        found
    }

    #[test]
    fn no_faces_fight_in_swamps_ponds_and_the_amazon() {
        let gen = TerrainGenerator::new(555);
        let mut sites = lily_pad_chunks(&gen, 3);
        // the great river of the Amazon basin and its lakes
        'basin: for ring in 1..80 {
            for k in 0..24 {
                let a = (k as f64 / 24.0 + ring as f64 * 0.37) * std::f64::consts::TAU;
                let (x, z) = ((ring as f64 * 120.0 * a.cos()) as i32, (ring as f64 * 120.0 * a.sin()) as i32);
                if gen.climate.amazon(x as f64, z as f64) > 0.55 && gen.surface_height(x, z) < SEA_LEVEL - 2 {
                    sites.push(ChunkPos::of_block(x, z));
                    break 'basin;
                }
            }
        }
        assert!(sites.len() >= 2, "the test world must have lily pad water and an Amazon river: {:?}", sites);
        let ctx = context(&gen);
        let mut pads = 0;
        for site in sites {
            let chunks = chunks_around(&gen, site, 1);
            for (name, merge_of) in MESHINGS {
                let faces = faces_in(&ctx, &chunks, site, 1, merge_of);
                pads += faces.iter().filter(|f| f.pass == PASS_DOUBLE && f.axis == 1).count();
                let fighting = fights(&faces, 0.09);
                assert!(fighting.is_empty(), "{} chunks at {:?}: {} pairs of faces fight, e.g. {:?}", name, site, fighting.len(), fighting.first());
            }
        }
        assert!(pads > 0, "the test must have seen lily pads");
    }

    #[test]
    fn no_faces_fight_in_other_biomes_either() {
        let gen = TerrainGenerator::new(555);
        let ctx = context(&gen);
        let mut checked = 0;
        for want in [Biome::Forest, Biome::Jungle, Biome::Rainforest, Biome::Desert, Biome::Taiga] {
            let site = (1..60).find_map(|ring| {
                (0..24).find_map(|k| {
                    let a = (k as f64 / 24.0 + ring as f64) * std::f64::consts::TAU;
                    let (x, z) = ((ring as f64 * 400.0 * a.cos()) as i32, (ring as f64 * 400.0 * a.sin()) as i32);
                    (gen.biome_at(x, z) == want).then(|| ChunkPos::of_block(x, z))
                })
            });
            let Some(site) = site else { continue };
            let chunks = chunks_around(&gen, site, 1);
            for (name, merge_of) in MESHINGS {
                let faces = faces_in(&ctx, &chunks, site, 1, merge_of);
                let fighting = fights(&faces, 0.09);
                assert!(fighting.is_empty(), "{} {:?} at {:?}: {} pairs of faces fight, e.g. {:?}", name, want, site, fighting.len(), fighting.first());
            }
            checked += 1;
        }
        assert!(checked >= 3, "only {} biomes could be checked", checked);
    }

    /// A long sweep over many spots of several worlds (caves, rivers, every biome), for hunting: it prints what it
    /// finds, grouped by kind. `cargo test --lib sweep -- --ignored --nocapture`
    #[test]
    #[ignore = "a long sweep; run it by hand"]
    fn sweep_many_sites_for_fighting_faces() {
        let mut kinds: HashMap<(usize, usize, u8, u8, &str), (usize, ChunkPos)> = HashMap::new();
        let (mut sites, mut pairs) = (0, 0);
        for seed in [555i64, 7, 1234] {
            let gen = TerrainGenerator::new(seed);
            let ctx = context(&gen);
            for gz in -4..4 {
                for gx in -4..4 {
                    let site = ChunkPos::new(gx * 29 + 3, gz * 31 - 5);
                    let chunks = chunks_around(&gen, site, 1);
                    for (name, merge_of) in MESHINGS {
                        let faces = faces_in(&ctx, &chunks, site, 1, merge_of);
                        for (a, b) in fights(&faces, 0.09) {
                            pairs += 1;
                            let key = (a.pass.min(b.pass), a.pass.max(b.pass), a.layer.min(b.layer), a.layer.max(b.layer), name);
                            kinds.entry(key).or_insert((0, site)).0 += 1;
                        }
                    }
                    sites += 1;
                }
            }
        }
        let mut list: Vec<_> = kinds.into_iter().collect();
        list.sort_by_key(|(_, (n, _))| std::cmp::Reverse(*n));
        for ((pa, pb, la, lb, name), (n, site)) in &list {
            println!("{:>6} x passes {}/{} layers {}/{} ({} meshes), first near chunk {:?}", n, pa, pb, la, lb, name, site);
        }
        println!("{} sites, {} fighting pairs in {} kinds", sites, pairs, list.len());
        assert!(list.is_empty());
    }
}
