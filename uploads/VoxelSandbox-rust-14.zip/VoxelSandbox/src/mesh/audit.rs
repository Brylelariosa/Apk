//! Test-only audit of what the mesher hands to the GPU code.
//!
//! The renderer trusts a `ChunkMeshData` completely. It uploads `vertices` and `indices` as they are (as 16-bit indices
//! when the mesh has few enough vertices), draws `ranges` and the runs of `section_starts` with `glDrawElements`, decides
//! from a box around a section (`SECTION_SLACK`) or around the whole column (`min_y`, `max_y`) whether anything of it can be
//! on screen, and picks the texture layer straight out of `info`. A mesh that breaks one of those assumptions fails nowhere
//! on the CPU: the GPU reads past the end of a buffer, a section is dropped from the frame while its faces are still in
//! view, or a texture lookup runs off the end of the array.
//!
//! `problems` lists what is wrong with one mesh. The tests run it over real generated terrain (every biome that can be
//! found, rivers, lakes, caves; merged and detailed meshes; with all neighbours loaded and with none), and over a mesh that
//! has been damaged on purpose, so that a check that never fires cannot go unnoticed.

use super::{needs_wide_indices, ChunkMeshData, PASS_COUNT, SECTION_SLACK};
use crate::world::config::{SECTIONS, WORLD_HEIGHT};

/// How far past the chunk's footprint a vertex may lie: a plant is nudged by up to 0.15 of a block inside its cell and its
/// quads span 0.1..0.9, so one in an edge cell sticks out by 0.05 (merged quads are grown by a hair too, `MERGE_GROW` in
/// the mesher). The renderer culls a column by its footprint without any slack; that much is too little to be seen.
const FOOTPRINT_SLACK: f32 = 0.06;
/// Merged quads are grown by a hair along their plane (`MERGE_GROW` in the mesher), so a face may lie that far outside the
/// box of its section or its column.
const GROW: f32 = 0.01;
/// The biggest texture coordinate a vertex may have. Water wraps its coordinates every 16 blocks (the tile repeats per
/// block, so a whole number of blocks changes nothing) and its side faces add up to two more; the other passes stay below
/// the 8 of a merged quad. Anything bigger is a coordinate that carries a world position, which the half-precision
/// interpolation of a phone GPU cannot keep steady.
const MAX_UV: f32 = 17.5;
/// The most any vertex may stand above the world's last block row (a plant on the top row).
const CEILING: f32 = WORLD_HEIGHT as f32 + 2.0;

/// One line for everything wrong with `mesh` (empty when it keeps every promise the renderer relies on).
pub fn problems(mesh: &ChunkMeshData) -> Vec<String> {
    let mut out = Vec::new();
    let vertex_count = mesh.vertices.len();

    // the index list
    if mesh.indices.len() % 3 != 0 {
        out.push(format!("{} indices are not a whole number of triangles", mesh.indices.len()));
    }
    if let Some(&bad) = mesh.indices.iter().find(|&&i| i as usize >= vertex_count) {
        out.push(format!("index {} points past the {} vertices", bad, vertex_count));
    }
    if !needs_wide_indices(vertex_count) {
        if let Some(&bad) = mesh.indices.iter().find(|&&i| i > u16::MAX as u32) {
            out.push(format!("index {} does not fit the 16-bit index buffer a mesh of {} vertices gets", bad, vertex_count));
        }
    }

    // the passes follow each other and cover the whole list
    let mut at = 0u32;
    for (p, &(first, count)) in mesh.ranges.iter().enumerate() {
        if first != at {
            out.push(format!("pass {} starts at index {} but the pass before it ends at {}", p, first, at));
        }
        if count % 3 != 0 {
            out.push(format!("pass {} has {} indices, not a whole number of triangles", p, count));
        }
        at = first + count;
    }
    if at as usize != mesh.indices.len() {
        out.push(format!("the passes end at index {} but there are {} indices", at, mesh.indices.len()));
    }

    // the sections cut every pass into consecutive runs
    for p in 0..PASS_COUNT {
        let (first, count) = mesh.ranges[p];
        let starts = &mesh.section_starts[p];
        if starts[0] != first {
            out.push(format!("pass {}: section 0 starts at {} but the pass starts at {}", p, starts[0], first));
        }
        if starts[SECTIONS] != first + count {
            out.push(format!("pass {}: the last section ends at {} but the pass ends at {}", p, starts[SECTIONS], first + count));
        }
        for s in 0..SECTIONS {
            if starts[s + 1] < starts[s] {
                out.push(format!("pass {}: section {} ends at {} before it starts at {}", p, s, starts[s + 1], starts[s]));
            } else if (starts[s + 1] - starts[s]) % 3 != 0 {
                out.push(format!("pass {}: section {} has {} indices, not a whole number of triangles", p, s, starts[s + 1] - starts[s]));
            }
        }
    }

    // the vertices
    for (n, v) in mesh.vertices.iter().enumerate() {
        if !v.pos.iter().chain(v.uv.iter()).all(|c| c.is_finite()) {
            out.push(format!("vertex {} is not finite: {:?}", n, v));
            continue;
        }
        if v.uv.iter().any(|c| c.abs() > MAX_UV) {
            out.push(format!("vertex {} has texture coordinates {:?}", n, v.uv));
        }
        if v.pos[0] < -FOOTPRINT_SLACK || v.pos[0] > 16.0 + FOOTPRINT_SLACK || v.pos[2] < -FOOTPRINT_SLACK || v.pos[2] > 16.0 + FOOTPRINT_SLACK {
            out.push(format!("vertex {} lies outside its chunk: {:?}", n, v.pos));
        }
        if v.pos[1] < -FOOTPRINT_SLACK || v.pos[1] > CEILING {
            out.push(format!("vertex {} is {} blocks high, outside the world", n, v.pos[1]));
        }
        if v.info[0] as usize >= crate::tex::cells::TILE_COUNT {
            out.push(format!("vertex {} asks for texture layer {} of {}", n, v.info[0], crate::tex::cells::TILE_COUNT));
        }
        if v.info[1] > 2 {
            out.push(format!("vertex {} has the unknown tint mode {}", n, v.info[1]));
        }
    }

    // the boxes the renderer culls by: only meaningful once the lists above hold together
    if out.is_empty() {
        for p in 0..PASS_COUNT {
            for s in 0..SECTIONS {
                let (from, to) = (mesh.section_starts[p][s] as usize, mesh.section_starts[p][s + 1] as usize);
                let (low, high) = (s as f32 * 16.0 - SECTION_SLACK, s as f32 * 16.0 + 16.0 + SECTION_SLACK);
                for &i in &mesh.indices[from..to] {
                    let y = mesh.vertices[i as usize].pos[1];
                    if y < low - GROW || y > high + GROW {
                        out.push(format!(
                            "pass {}: a vertex of section {} is at height {}, outside {}..{} (the box the section is culled by)",
                            p, s, y, low, high
                        ));
                        break;
                    }
                    if y < mesh.min_y - GROW || y > mesh.max_y + GROW {
                        out.push(format!("pass {}: a vertex of section {} is at height {}, outside the column's {}..{}", p, s, y, mesh.min_y, mesh.max_y));
                        break;
                    }
                }
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::mesher::{build_chunk_mesh, MeshContext, MeshInput};
    use crate::mesh::testkit::{biome_site, chunks_around, mesh_at};
    use crate::gen::climate::Biome;
    use crate::gen::terrain::TerrainGenerator;
    use crate::mesh::{PASS_CUTOUT, PASS_DOUBLE, PASS_OPAQUE, PASS_WATER};
    use crate::tex::cells::TILE_COUNT;
    use crate::world::block::{Block, Face, ALL_BLOCKS};
    use crate::world::chunk::ChunkData;
    use crate::world::config::SEA_LEVEL;
    use crate::world::pos::ChunkPos;

    /// A stone block floating in the air of section 6.
    fn one_block() -> ChunkMeshData {
        let gen = TerrainGenerator::new(1);
        let ctx = MeshContext::for_generator(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        if let Some(c) = chunks[4].as_mut() {
            c.set(5, 100, 5, Block::Stone);
        }
        build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: false }, &ctx)
    }

    #[test]
    fn a_plain_mesh_has_no_problems() {
        let mesh = one_block();
        assert_eq!(mesh.vertices.len(), 24);
        assert_eq!(problems(&mesh), Vec::<String>::new());
        assert_eq!(problems(&ChunkMeshData::empty()), Vec::<String>::new(), "a column with nothing in it is fine too");
    }

    #[test]
    fn every_check_fires_when_its_promise_is_broken() {
        type Damage = (&'static str, fn(&mut ChunkMeshData), &'static str);
        let damages: [Damage; 12] = [
            ("an index past the vertices", |m| m.indices[7] = m.vertices.len() as u32, "points past"),
            ("a cut triangle", |m| { m.indices.pop(); }, "whole number of triangles"),
            ("a gap between passes", |m| m.ranges[1].0 += 3, "starts at index"),
            ("passes that go on too long", |m| m.ranges[3].1 += 3, "the passes end at"),
            ("sections that do not start with the pass", |m| m.section_starts[0][0] += 3, "section 0 starts"),
            ("sections that stop short", |m| m.section_starts[0][SECTIONS] -= 3, "last section ends"),
            ("a section that ends before it starts", |m| m.section_starts[0][5] = m.section_starts[0][6] + 3, "before it starts"),
            ("a vertex that is not a number", |m| m.vertices[0].pos[1] = f32::NAN, "not finite"),
            ("a vertex in another chunk", |m| m.vertices[0].pos[0] = 40.0, "outside its chunk"),
            ("a texture layer past the array", |m| m.vertices[0].info[0] = TILE_COUNT as u8, "texture layer"),
            ("a vertex above its section", |m| m.vertices[0].pos[1] += 20.0, "culled by"),
            ("a vertex above the column", |m| m.max_y = 100.5, "outside the column"),
        ];
        for (what, damage, expected) in damages {
            let mut mesh = one_block();
            damage(&mut mesh);
            let found = problems(&mesh);
            assert!(found.iter().any(|line| line.contains(expected)), "{}: expected a line with {:?}, got {:?}", what, expected, found);
        }
    }

    #[test]
    fn sixteen_bit_indices_are_used_only_while_they_fit() {
        assert!(!needs_wide_indices(0));
        assert!(!needs_wide_indices(65_536), "the largest index of 65 536 vertices is 65 535");
        assert!(needs_wide_indices(65_537));
    }

    #[test]
    fn every_face_of_every_block_names_a_layer_the_texture_array_has() {
        for block in ALL_BLOCKS {
            for face in Face::ALL {
                let layer = block.cell_for(face);
                assert!(layer < TILE_COUNT as i32, "{:?} {:?} asks for layer {} of {}", block, face, layer, TILE_COUNT);
            }
        }
    }

    /// A spot in the world where there is water to mesh: a lake, a river or the sea.
    fn water_site(gen: &TerrainGenerator) -> Option<ChunkPos> {
        (1..80).find_map(|ring| {
            (0..24).find_map(|k| {
                let a = (k as f64 / 24.0 + ring as f64 * 0.37) * std::f64::consts::TAU;
                let (x, z) = ((ring as f64 * 120.0 * a.cos()) as i32, (ring as f64 * 120.0 * a.sin()) as i32);
                (gen.surface_height(x, z) < SEA_LEVEL - 2).then(|| ChunkPos::of_block(x, z))
            })
        })
    }

    #[test]
    fn meshes_of_generated_terrain_keep_every_promise_the_renderer_relies_on() {
        let mut checked = 0;
        let mut passes_seen = [false; PASS_COUNT];
        let (mut most_vertices, mut most_at) = (0, ChunkPos::new(0, 0));
        for seed in [555i64, 7] {
            let gen = TerrainGenerator::new(seed);
            let ctx = MeshContext::for_generator(&gen);
            // a spread of places, and one of every biome the world has within reach, and some water
            let mut sites: Vec<ChunkPos> = (0..6).map(|k| ChunkPos::new(k * 29 + 3, (k % 3) * 31 - 40)).collect();
            for want in [
                Biome::Forest,
                Biome::BirchForest,
                Biome::Jungle,
                Biome::Rainforest,
                Biome::Swamp,
                Biome::Desert,
                Biome::Savanna,
                Biome::Taiga,
                Biome::Mountains,
                Biome::SnowyPeaks,
                Biome::Beach,
            ] {
                sites.extend(biome_site(&gen, want, 400.0));
            }
            sites.extend(water_site(&gen));
            for site in sites {
                let chunks = chunks_around(&gen, site, 1);
                for dz in -1..=1 {
                    for dx in -1..=1 {
                        for (merge, neighbours) in [(false, true), (true, true), (false, false), (true, false)] {
                            let mesh = mesh_at(&ctx, &chunks, site, (dx, dz), merge, neighbours);
                            let found = problems(&mesh);
                            assert!(
                                found.is_empty(),
                                "seed {} chunk {:?} (merged: {}, neighbours: {}): {} problems, e.g. {:#?}",
                                seed,
                                (site.x + dx, site.z + dz),
                                merge,
                                neighbours,
                                found.len(),
                                &found[..found.len().min(4)]
                            );
                            checked += 1;
                            for (p, seen) in passes_seen.iter_mut().enumerate() {
                                *seen |= mesh.ranges[p].1 > 0;
                            }
                            if mesh.vertices.len() > most_vertices {
                                most_vertices = mesh.vertices.len();
                                most_at = ChunkPos::new(site.x + dx, site.z + dz);
                            }
                        }
                    }
                }
            }
        }
        println!("{} meshes checked; the biggest has {} vertices (chunk {:?})", checked, most_vertices, most_at);
        assert!(checked >= 400, "only {} meshes were checked", checked);
        for (pass, name) in [(PASS_OPAQUE, "opaque"), (PASS_CUTOUT, "leaf"), (PASS_DOUBLE, "plant"), (PASS_WATER, "water")] {
            assert!(passes_seen[pass], "no {} faces came up in the sample, so that pass was not checked", name);
        }
    }
}
