//! Test scaffolding shared by the mesh tests: a mesher context for a world, generated chunks together with their
//! neighbours, and a chunk meshed from them.

use super::mesher::{build_chunk_mesh, MeshContext, MeshInput};
use super::ChunkMeshData;
use crate::gen::climate::Biome;
use crate::gen::terrain::TerrainGenerator;
use crate::world::chunk::ChunkData;
use crate::world::pos::ChunkPos;
use std::collections::HashMap;

/// The generated chunks of the (2 * radius + 3)^2 block of chunks around `centre`, by offset from it (the outer ring is
/// only there so that the chunks inside it have all their neighbours).
pub fn chunks_around(gen: &TerrainGenerator, centre: ChunkPos, radius: i32) -> HashMap<(i32, i32), ChunkData> {
    let mut chunks = HashMap::new();
    for dz in -(radius + 1)..=radius + 1 {
        for dx in -(radius + 1)..=radius + 1 {
            chunks.insert((dx, dz), gen.generate(ChunkPos::new(centre.x + dx, centre.z + dz)));
        }
    }
    chunks
}

/// The chunk at offset `(dx, dz)` from `centre` and the eight around it, in the order the mesher wants them (index
/// `(dz + 1) * 3 + (dx + 1)`). With `neighbours` false only the middle one is there, the way a chunk whose neighbours are
/// not loaded yet is meshed.
pub fn neighbourhood(chunks: &HashMap<(i32, i32), ChunkData>, dx: i32, dz: i32, neighbours: bool) -> [Option<ChunkData>; 9] {
    let mut around: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
    for az in -1..=1 {
        for ax in -1..=1 {
            if neighbours || (ax == 0 && az == 0) {
                around[((az + 1) * 3 + (ax + 1)) as usize] = chunks.get(&(dx + ax, dz + az)).cloned();
            }
        }
    }
    around
}

/// The mesh of the chunk at offset `(dx, dz)` from `centre`.
pub fn mesh_at(
    ctx: &MeshContext,
    chunks: &HashMap<(i32, i32), ChunkData>,
    centre: ChunkPos,
    (dx, dz): (i32, i32),
    merge: bool,
    neighbours: bool,
) -> ChunkMeshData {
    let pos = ChunkPos::new(centre.x + dx, centre.z + dz);
    build_chunk_mesh(&MeshInput { pos, chunks: neighbourhood(chunks, dx, dz, neighbours), merge }, ctx)
}

/// A chunk in the first spot of biome `want` that a walk outwards from the origin comes across, going round in rings
/// `step` blocks apart (`None` if the world has none within 60 rings).
pub fn biome_site(gen: &TerrainGenerator, want: Biome, step: f64) -> Option<ChunkPos> {
    (1..60).find_map(|ring| {
        (0..24).find_map(|k| {
            let a = (k as f64 / 24.0 + ring as f64) * std::f64::consts::TAU;
            let (x, z) = ((ring as f64 * step * a.cos()) as i32, (ring as f64 * step * a.sin()) as i32);
            (gen.biome_at(x, z) == want).then(|| ChunkPos::of_block(x, z))
        })
    })
}
