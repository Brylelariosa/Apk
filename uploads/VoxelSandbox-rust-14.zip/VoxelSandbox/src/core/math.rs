//! Vectors, 4x4 matrices (column-major, like OpenGL) and the view frustum.

pub type Mat4 = [f32; 16];

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Vec3 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl Vec3 {
    pub const ZERO: Vec3 = Vec3 { x: 0.0, y: 0.0, z: 0.0 };

    pub const fn new(x: f32, y: f32, z: f32) -> Vec3 {
        Vec3 { x, y, z }
    }

    pub fn set(&mut self, x: f32, y: f32, z: f32) {
        self.x = x;
        self.y = y;
        self.z = z;
    }

    pub fn add(&mut self, dx: f32, dy: f32, dz: f32) {
        self.x += dx;
        self.y += dy;
        self.z += dz;
    }

    pub fn dot(self, o: Vec3) -> f32 {
        self.x * o.x + self.y * o.y + self.z * o.z
    }

    pub fn cross(self, o: Vec3) -> Vec3 {
        Vec3 {
            x: self.y * o.z - self.z * o.y,
            y: self.z * o.x - self.x * o.z,
            z: self.x * o.y - self.y * o.x,
        }
    }

    pub fn length(self) -> f32 {
        self.dot(self).sqrt()
    }

    pub fn normalized(self) -> Vec3 {
        let len = self.length();
        if len < 1e-8 {
            return Vec3::new(0.0, 0.0, 0.0);
        }
        Vec3::new(self.x / len, self.y / len, self.z / len)
    }
}

/// Axis-aligned box.
#[derive(Clone, Copy, Debug)]
pub struct Aabb {
    pub min_x: f32,
    pub min_y: f32,
    pub min_z: f32,
    pub max_x: f32,
    pub max_y: f32,
    pub max_z: f32,
}

impl Aabb {
    pub fn new(min_x: f32, min_y: f32, min_z: f32, max_x: f32, max_y: f32, max_z: f32) -> Aabb {
        Aabb { min_x, min_y, min_z, max_x, max_y, max_z }
    }

    pub fn offset(&self, dx: f32, dy: f32, dz: f32) -> Aabb {
        Aabb {
            min_x: self.min_x + dx,
            min_y: self.min_y + dy,
            min_z: self.min_z + dz,
            max_x: self.max_x + dx,
            max_y: self.max_y + dy,
            max_z: self.max_z + dz,
        }
    }
}

pub fn clampf(v: f32, lo: f32, hi: f32) -> f32 {
    if v < lo {
        lo
    } else if v > hi {
        hi
    } else {
        v
    }
}

pub fn clampd(v: f64, lo: f64, hi: f64) -> f64 {
    if v < lo {
        lo
    } else if v > hi {
        hi
    } else {
        v
    }
}

pub fn clampi(v: i32, lo: i32, hi: i32) -> i32 {
    if v < lo {
        lo
    } else if v > hi {
        hi
    } else {
        v
    }
}

pub fn lerpf(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

pub fn floor_i(v: f32) -> i32 {
    v.floor() as i32
}

pub fn floor_d(v: f64) -> i32 {
    v.floor() as i32
}

/// Floor division for a positive divisor (what `Math.floorDiv` does in Kotlin).
pub fn floor_div(a: i32, b: i32) -> i32 {
    a.div_euclid(b)
}

pub fn floor_mod(a: i32, b: i32) -> i32 {
    a.rem_euclid(b)
}

pub fn mat4_identity() -> Mat4 {
    let mut m = [0.0f32; 16];
    m[0] = 1.0;
    m[5] = 1.0;
    m[10] = 1.0;
    m[15] = 1.0;
    m
}

/// `a * b` for column-major matrices.
pub fn mat4_mul(a: &Mat4, b: &Mat4) -> Mat4 {
    let mut r = [0.0f32; 16];
    for col in 0..4 {
        for row in 0..4 {
            let mut sum = 0.0f32;
            for k in 0..4 {
                sum += a[k * 4 + row] * b[col * 4 + k];
            }
            r[col * 4 + row] = sum;
        }
    }
    r
}

/// Perspective projection (same convention as `android.opengl.Matrix.perspectiveM`).
pub fn mat4_perspective(fovy_rad: f32, aspect: f32, near: f32, far: f32) -> Mat4 {
    let f = 1.0 / (fovy_rad * 0.5).tan();
    let mut m = [0.0f32; 16];
    m[0] = f / aspect;
    m[5] = f;
    m[10] = (far + near) / (near - far);
    m[11] = -1.0;
    m[14] = 2.0 * far * near / (near - far);
    m
}

/// A view matrix for an eye at the origin looking along `forward` (rotation only: the renderer works
/// camera-relative, so large world coordinates never reach the GPU).
pub fn mat4_view_dir(forward: Vec3, up: Vec3) -> Mat4 {
    let f = forward.normalized();
    let s = f.cross(up).normalized();
    let u = s.cross(f);
    let mut m = [0.0f32; 16];
    m[0] = s.x;
    m[1] = u.x;
    m[2] = -f.x;
    m[4] = s.y;
    m[5] = u.y;
    m[6] = -f.y;
    m[8] = s.z;
    m[9] = u.z;
    m[10] = -f.z;
    m[15] = 1.0;
    m
}

/// Orthographic projection mapping pixel coordinates (origin top-left, y down) to clip space.
pub fn mat4_ortho_pixels(width: f32, height: f32) -> Mat4 {
    let mut m = [0.0f32; 16];
    m[0] = 2.0 / width;
    m[5] = -2.0 / height;
    m[10] = -1.0;
    m[12] = -1.0;
    m[13] = 1.0;
    m[15] = 1.0;
    m
}

/// The six planes of a view frustum, for skipping chunks that cannot be on screen.
pub struct Frustum {
    planes: [[f32; 4]; 6],
}

impl Frustum {
    /// `m` is a view-projection matrix (column-major). Boxes tested later must be given in the space `m`
    /// maps from (here: camera-relative world coordinates).
    pub fn from_matrix(m: &Mat4) -> Frustum {
        let r0 = [m[0], m[4], m[8], m[12]];
        let r1 = [m[1], m[5], m[9], m[13]];
        let r2 = [m[2], m[6], m[10], m[14]];
        let r3 = [m[3], m[7], m[11], m[15]];
        let mut planes = [[0.0f32; 4]; 6];
        let combos: [(&[f32; 4], f32); 6] = [(&r0, 1.0), (&r0, -1.0), (&r1, 1.0), (&r1, -1.0), (&r2, 1.0), (&r2, -1.0)];
        for (i, (row, sign)) in combos.iter().enumerate() {
            let mut p = [0.0f32; 4];
            for k in 0..4 {
                p[k] = r3[k] + sign * row[k];
            }
            let len = (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]).sqrt();
            if len > 1e-6 {
                for k in 0..4 {
                    p[k] /= len;
                }
            }
            planes[i] = p;
        }
        Frustum { planes }
    }

    /// False only when the box is certainly outside at least one plane.
    pub fn box_visible(&self, min: [f32; 3], max: [f32; 3]) -> bool {
        self.classify(min, max) != Overlap::Outside
    }

    /// Where the box is relative to the frustum: certainly outside, certainly completely inside, or in between
    /// (touching a plane, or too close to tell). Boxes that are completely inside need no finer tests.
    pub fn classify(&self, min: [f32; 3], max: [f32; 3]) -> Overlap {
        let mut inside = true;
        for p in self.planes.iter() {
            // the corner furthest along the plane's normal, and the one furthest against it
            let (hx, lx) = if p[0] >= 0.0 { (max[0], min[0]) } else { (min[0], max[0]) };
            let (hy, ly) = if p[1] >= 0.0 { (max[1], min[1]) } else { (min[1], max[1]) };
            let (hz, lz) = if p[2] >= 0.0 { (max[2], min[2]) } else { (min[2], max[2]) };
            if p[0] * hx + p[1] * hy + p[2] * hz + p[3] < 0.0 {
                return Overlap::Outside;
            }
            if p[0] * lx + p[1] * ly + p[2] * lz + p[3] < 0.0 {
                inside = false;
            }
        }
        if inside {
            Overlap::Inside
        } else {
            Overlap::Partial
        }
    }
}

/// See `Frustum::classify`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Overlap {
    Outside,
    Partial,
    Inside,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn floor_helpers_handle_negatives() {
        assert_eq!(floor_div(-1, 16), -1);
        assert_eq!(floor_mod(-1, 16), 15);
        assert_eq!(floor_div(16, 16), 1);
        assert_eq!(floor_i(-0.5), -1);
    }

    #[test]
    fn identity_multiplication_is_neutral() {
        let p = mat4_perspective(1.2, 1.5, 0.1, 100.0);
        let r = mat4_mul(&mat4_identity(), &p);
        for i in 0..16 {
            assert!((r[i] - p[i]).abs() < 1e-6);
        }
    }

    #[test]
    fn frustum_sees_box_in_front_not_behind() {
        let proj = mat4_perspective(1.2, 1.5, 0.1, 100.0);
        let view = mat4_view_dir(Vec3::new(0.0, 0.0, -1.0), Vec3::new(0.0, 1.0, 0.0));
        let fr = Frustum::from_matrix(&mat4_mul(&proj, &view));
        assert!(fr.box_visible([-1.0, -1.0, -11.0], [1.0, 1.0, -9.0]));
        assert!(!fr.box_visible([-1.0, -1.0, 9.0], [1.0, 1.0, 11.0]));
    }

    /// A point's clip coordinates (x, y, z, w) under the column-major matrix `m`.
    fn clip(m: &Mat4, p: [f32; 3]) -> [f32; 4] {
        let mut out = [0.0f32; 4];
        for (row, o) in out.iter_mut().enumerate() {
            *o = m[row] * p[0] + m[4 + row] * p[1] + m[8 + row] * p[2] + m[12 + row];
        }
        out
    }

    /// The culling must agree with the projection for every way the camera can be turned, looking almost straight up or
    /// down included: a point the projection puts on the screen is never culled (a chunk that vanishes at the edge of the
    /// screen), and a point it puts off the screen is culled (the planes are exact, no chunk is drawn for nothing).
    #[test]
    fn culling_agrees_with_the_projection_at_every_orientation() {
        let mut state = 0x2545_F491u32;
        let mut rnd = move || {
            state = state.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
            (state >> 8) as f32 / 16_777_216.0
        };
        let (mut seen_on, mut seen_off) = (0, 0);
        for _ in 0..300 {
            let yaw = rnd() * std::f32::consts::TAU;
            // the player's pitch limit is 1.5533 (89 degrees); the extremes are tested on purpose
            let pitch = match (rnd() * 8.0) as u32 {
                0 => 1.5533,
                1 => -1.5533,
                _ => (rnd() * 2.0 - 1.0) * 1.5533,
            };
            let cp = pitch.cos();
            let forward = Vec3::new(cp * yaw.sin(), pitch.sin(), -cp * yaw.cos());
            let vp = mat4_mul(&mat4_perspective(70f32.to_radians(), 1800.0 / 810.0, 0.1, 600.0), &mat4_view_dir(forward, Vec3::new(0.0, 1.0, 0.0)));
            let fr = Frustum::from_matrix(&vp);
            let right = forward.cross(Vec3::new(0.0, 1.0, 0.0)).normalized();
            let up = right.cross(forward);
            let (half_h, half_w) = ((70f32.to_radians() * 0.5).tan(), (70f32.to_radians() * 0.5).tan() * 1800.0 / 810.0);
            for _ in 0..200 {
                // points in front of, beside and behind the camera, spread so that about half of them are on the screen
                let d = (rnd() * 1.1 - 0.05) * 600.0;
                let (sx, sy) = ((rnd() * 2.0 - 1.0) * 1.3 * half_w * d.abs(), (rnd() * 2.0 - 1.0) * 1.3 * half_h * d.abs());
                let p = [
                    forward.x * d + right.x * sx + up.x * sy,
                    forward.y * d + right.y * sx + up.y * sy,
                    forward.z * d + right.z * sx + up.z * sy,
                ];
                let c = clip(&vp, p);
                // how far inside the volume the point is, as a fraction of w (negative: outside)
                let depth = c[3] - c[0].abs().max(c[1].abs()).max(c[2].abs());
                // (the box is a hundredth of a block wide, so points closer to a plane than a few hundredths are left out)
                let margin = 0.05 + 0.002 * c[3].abs();
                // a box of a hundredth of a block around the point
                let (lo, hi) = ([p[0] - 0.005, p[1] - 0.005, p[2] - 0.005], [p[0] + 0.005, p[1] + 0.005, p[2] + 0.005]);
                if depth > margin {
                    seen_on += 1;
                    assert!(fr.box_visible(lo, hi), "culled although it is on the screen: yaw {} pitch {} point {:?} clip {:?}", yaw, pitch, p, c);
                } else if depth < -margin {
                    seen_off += 1;
                    assert!(!fr.box_visible(lo, hi), "drawn although it is off the screen: yaw {} pitch {} point {:?} clip {:?}", yaw, pitch, p, c);
                }
            }
        }
        assert!(seen_on > 500 && seen_off > 500, "the sample must have both kinds of points: {} on, {} off", seen_on, seen_off);
    }

    #[test]
    fn classify_tells_inside_from_crossing_from_outside() {
        let proj = mat4_perspective(1.2, 1.5, 0.1, 100.0);
        let view = mat4_view_dir(Vec3::new(0.0, 0.0, -1.0), Vec3::new(0.0, 1.0, 0.0));
        let fr = Frustum::from_matrix(&mat4_mul(&proj, &view));
        assert_eq!(fr.classify([-0.5, -0.5, -21.0], [0.5, 0.5, -20.0]), Overlap::Inside);
        assert_eq!(fr.classify([-1.0, -1.0, 9.0], [1.0, 1.0, 11.0]), Overlap::Outside);
        // a wide slab across the whole view sticks out on both sides
        assert_eq!(fr.classify([-500.0, -1.0, -21.0], [500.0, 1.0, -20.0]), Overlap::Partial);
        assert_eq!(fr.classify([-500.0, -1.0, -21.0], [500.0, 1.0, -20.0]) != Overlap::Outside, fr.box_visible([-500.0, -1.0, -21.0], [500.0, 1.0, -20.0]));
    }
}
