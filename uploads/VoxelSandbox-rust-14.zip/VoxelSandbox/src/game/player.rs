//! The player: position, look direction and movement mode.

use crate::core::math::{clampf, Vec3};

pub const WIDTH: f32 = 0.6;
pub const HEIGHT: f32 = 1.8;
pub const EYE_HEIGHT: f32 = 1.62;
/// About 89 degrees; avoids a camera flip at the poles.
pub const MAX_PITCH: f32 = 1.5533;

pub struct Player {
    /// Feet position (centre of the footprint).
    pub position: Vec3,
    pub velocity: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub on_ground: bool,
    pub flying: bool,
    /// Held in place until the ground under the spawn point exists.
    pub waiting_for_spawn: bool,
}

impl Player {
    pub fn new() -> Player {
        Player {
            position: Vec3::new(0.0, 48.0, 0.0),
            velocity: Vec3::ZERO,
            yaw: 0.0,
            pitch: 0.0,
            on_ground: false,
            flying: false,
            waiting_for_spawn: true,
        }
    }

    pub fn add_look(&mut self, d_yaw: f32, d_pitch: f32) {
        self.yaw += d_yaw;
        self.pitch = clampf(self.pitch + d_pitch, -MAX_PITCH, MAX_PITCH);
    }

    /// Puts the player where a save says. A look direction that is not a direction (not finite, or looking past straight
    /// up or down) is made one, because a camera built from it would draw nothing sensible. Returns false, and changes
    /// nothing, if the position is not a place at all (not finite): the caller then has to find the player a place.
    pub fn restore(&mut self, x: f32, y: f32, z: f32, yaw: f32, pitch: f32) -> bool {
        if !(x.is_finite() && y.is_finite() && z.is_finite()) {
            return false;
        }
        self.position.set(x, y, z);
        self.yaw = if yaw.is_finite() { yaw } else { 0.0 };
        self.pitch = if pitch.is_finite() { clampf(pitch, -MAX_PITCH, MAX_PITCH) } else { 0.0 };
        true
    }

    pub fn eye_x(&self) -> f32 {
        self.position.x
    }

    pub fn eye_y(&self) -> f32 {
        self.position.y + EYE_HEIGHT
    }

    pub fn eye_z(&self) -> f32 {
        self.position.z
    }

    /// Unit vector the player looks along.
    pub fn look_dir(&self) -> Vec3 {
        let cp = self.pitch.cos();
        Vec3::new(cp * self.yaw.sin(), self.pitch.sin(), -cp * self.yaw.cos())
    }
}

impl Default for Player {
    fn default() -> Player {
        Player::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_saved_place_and_look_are_restored_as_they_were() {
        let mut p = Player::new();
        assert!(p.restore(10.5, 70.0, -3.25, 2.0, -0.4));
        assert_eq!((p.position.x, p.position.y, p.position.z), (10.5, 70.0, -3.25));
        assert_eq!((p.yaw, p.pitch), (2.0, -0.4));
    }

    #[test]
    fn a_saved_pitch_past_straight_up_or_down_is_brought_back_in_range() {
        let mut p = Player::new();
        assert!(p.restore(0.0, 60.0, 0.0, 0.0, 3.0));
        assert_eq!(p.pitch, MAX_PITCH);
        assert!(p.restore(0.0, 60.0, 0.0, 0.0, -9.0));
        assert_eq!(p.pitch, -MAX_PITCH);
    }

    #[test]
    fn a_look_that_is_not_a_number_becomes_straight_ahead() {
        let mut p = Player::new();
        assert!(p.restore(0.0, 60.0, 0.0, f32::NAN, f32::INFINITY));
        assert_eq!((p.yaw, p.pitch), (0.0, 0.0));
        let d = p.look_dir();
        assert!(d.x.is_finite() && d.y.is_finite() && d.z.is_finite());
    }

    #[test]
    fn a_position_that_is_not_a_place_is_refused_and_nothing_changes() {
        for bad in [(f32::NAN, 60.0, 0.0), (0.0, f32::INFINITY, 0.0), (0.0, 60.0, f32::NEG_INFINITY)] {
            let mut p = Player::new();
            let before = (p.position.x, p.position.y, p.position.z, p.yaw, p.pitch);
            assert!(!p.restore(bad.0, bad.1, bad.2, 1.0, 0.5));
            assert_eq!(before, (p.position.x, p.position.y, p.position.z, p.yaw, p.pitch));
        }
    }
}
