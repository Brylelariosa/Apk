//! Test-only audit of the far-terrain tile meshes the renderer draws, the counterpart of `mesh::audit` for the block
//! chunks.
//!
//! The renderer uploads a tile's vertices and its 16-bit indices as they are, draws the runs of `quarter_starts` that
//! `draw_runs` makes of them, and culls the tile by the box `min_y..max_y` over its footprint. `problems` lists what is
//! wrong with one tile; the tests run it over tiles of every level from real terrain and over a tile that has been damaged
//! on purpose, so that a check that never fires cannot go unnoticed.

use super::mesh::{sea_grow, FarTileData};
use super::tiles::tile_size;

/// The most vertices 16-bit indices can address.
const MAX_VERTICES: usize = 1 << 16;
/// Heights outside this are not terrain: the world is 256 blocks high and the deepest wall drops 256 below a top.
const LOWEST: f32 = -300.0;
const HIGHEST: f32 = 600.0;

/// One line for everything wrong with `t` (empty when it keeps every promise the renderer relies on).
pub fn problems(t: &FarTileData) -> Vec<String> {
    let mut out = Vec::new();
    let size = tile_size(t.key.level()) as f32;
    // sea quads are grown a little past their cells (see `mesh::sea_grow`), everything else is on the grid
    let slack = sea_grow(t.key.cell() as f32) + 0.01;
    if t.vertices.len() > MAX_VERTICES {
        out.push(format!("{} vertices do not fit 16-bit indices", t.vertices.len()));
    }
    if t.indices.len() % 3 != 0 {
        out.push(format!("{} indices are not a whole number of triangles", t.indices.len()));
    }
    if let Some(&bad) = t.indices.iter().find(|&&i| i as usize >= t.vertices.len()) {
        out.push(format!("index {} points past the {} vertices", bad, t.vertices.len()));
    }
    let q = &t.quarter_starts;
    if q[0] != 0 {
        out.push(format!("the first quarter starts at index {}", q[0]));
    }
    if q[4] as usize != t.indices.len() {
        out.push(format!("the last quarter ends at index {} but there are {} indices", q[4], t.indices.len()));
    }
    for i in 0..4 {
        if q[i + 1] < q[i] {
            out.push(format!("quarter {} ends at {} before it starts at {}", i, q[i + 1], q[i]));
        } else if (q[i + 1] - q[i]) % 3 != 0 {
            out.push(format!("quarter {} has {} indices, not a whole number of triangles", i, q[i + 1] - q[i]));
        }
    }
    if t.min_y > t.max_y {
        out.push(format!("the tile's height range {}..{} is upside down", t.min_y, t.max_y));
    }
    for (n, v) in t.vertices.iter().enumerate() {
        if !v.pos.iter().all(|c| c.is_finite()) {
            out.push(format!("vertex {} is not finite: {:?}", n, v));
            continue;
        }
        if v.pos[0] < -slack || v.pos[0] > size + slack || v.pos[2] < -slack || v.pos[2] > size + slack {
            out.push(format!("vertex {} lies outside its tile: {:?}", n, v.pos));
        }
        if v.pos[1] < LOWEST || v.pos[1] > HIGHEST {
            out.push(format!("vertex {} is at height {}", n, v.pos[1]));
        } else if v.pos[1] < t.min_y || v.pos[1] > t.max_y {
            out.push(format!("vertex {} at height {} is outside the {}..{} the tile is culled by", n, v.pos[1], t.min_y, t.max_y));
        }
        if v.color[3] != 255 {
            out.push(format!("vertex {} is see-through ({})", n, v.color[3]));
        }
    }
    // each quarter's triangles stay in the quarter's own area (a quarter can be left out of the frame when a finer tile
    // covers it, and the part that sticks out would be left out with it)
    if out.is_empty() {
        let half = size / 2.0;
        for quarter in 0..4usize {
            let (x0, z0) = ((quarter & 1) as f32 * half, (quarter >> 1) as f32 * half);
            for &i in &t.indices[q[quarter] as usize..q[quarter + 1] as usize] {
                let p = t.vertices[i as usize].pos;
                if p[0] < x0 - slack || p[0] > x0 + half + slack || p[2] < z0 - slack || p[2] > z0 + half + slack {
                    out.push(format!("quarter {} has a vertex at {:?}, outside its area", quarter, p));
                    break;
                }
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::climate::Biome;
    use crate::gen::terrain::TerrainGenerator;
    use crate::lod::sampler::FarSampler;
    use crate::lod::tiles::{TileKey, LEVELS};
    use crate::mesh::testkit::biome_site;
    use std::sync::Arc;

    #[test]
    fn a_flat_tile_has_no_problems() {
        let t = FarTileData::flat(TileKey::new(2, -3, 5), 70.0);
        assert_eq!(problems(&t), Vec::<String>::new());
    }

    #[test]
    fn every_check_fires_when_its_promise_is_broken() {
        type Damage = (&'static str, fn(&mut FarTileData), &'static str);
        let damages: [Damage; 9] = [
            ("an index past the vertices", |t| t.indices[4] = t.vertices.len() as u16, "points past"),
            ("a cut triangle", |t| { t.indices.pop(); }, "whole number of triangles"),
            ("quarters that stop short", |t| t.quarter_starts[4] -= 3, "the last quarter ends"),
            ("a quarter that ends before it starts", |t| t.quarter_starts[2] = t.quarter_starts[1] - 3, "before it starts"),
            ("a vertex that is not a number", |t| t.vertices[0].pos[0] = f32::NAN, "not finite"),
            ("a vertex outside its tile", |t| t.vertices[0].pos[2] = 5000.0, "outside its tile"),
            ("a vertex above the culling box", |t| t.vertices[0].pos[1] = t.max_y + 5.0, "culled by"),
            ("a see-through vertex", |t| t.vertices[0].color[3] = 200, "see-through"),
            ("a height range upside down", |t| std::mem::swap(&mut t.min_y, &mut t.max_y), "upside down"),
        ];
        for (what, damage, expected) in damages {
            let mut t = FarTileData::flat(TileKey::new(0, 0, 0), 70.0);
            // (the flat tile has height range 70..70 plus its walls, so make sure both ends differ)
            assert!(t.min_y < t.max_y, "the test needs a tile with a height range");
            damage(&mut t);
            let found = problems(&t);
            assert!(found.iter().any(|line| line.contains(expected)), "{}: expected a line with {:?}, got {:?}", what, expected, found);
        }
    }

    #[test]
    fn a_vertex_in_the_wrong_quarter_is_found() {
        let mut t = FarTileData::flat(TileKey::new(0, 0, 0), 70.0);
        // move one corner of the first quarter's first triangle into the far corner of the tile
        let i = t.indices[t.quarter_starts[0] as usize] as usize;
        t.vertices[i].pos[0] = 127.0;
        t.vertices[i].pos[2] = 127.0;
        let found = problems(&t);
        assert!(found.iter().any(|l| l.contains("outside its area")), "{:?}", found);
    }

    #[test]
    fn tiles_of_every_level_from_real_terrain_keep_every_promise_the_renderer_relies_on() {
        let mut checked = 0;
        let (mut most_vertices, mut most_at) = (0, TileKey::new(0, 0, 0));
        for seed in [555i64, 3] {
            let gen = Arc::new(TerrainGenerator::new(seed));
            let sampler = FarSampler::new(gen.clone());
            // the origin, some neighbours and the first spot of a few biomes
            let mut spots: Vec<(i64, i64)> = vec![(0, 0), (-300, 700), (2500, -1800), (-9000, -4000)];
            for want in [Biome::Jungle, Biome::Mountains, Biome::Desert, Biome::Swamp, Biome::Beach] {
                if let Some(c) = biome_site(&gen, want, 400.0) {
                    spots.push((c.x as i64 * 16, c.z as i64 * 16));
                }
            }
            for level in [0usize, 1, 2, 3, 5, 7, LEVELS - 1] {
                let size = tile_size(level) as i64;
                for &(x, z) in &spots {
                    let key = TileKey::new(level, x.div_euclid(size) as i32, z.div_euclid(size) as i32);
                    let tile = sampler.build_tile(key);
                    let found = problems(&tile);
                    assert!(found.is_empty(), "seed {} tile {:?}: {} problems, e.g. {:#?}", seed, key, found.len(), &found[..found.len().min(4)]);
                    checked += 1;
                    if tile.vertices.len() > most_vertices {
                        most_vertices = tile.vertices.len();
                        most_at = key;
                    }
                }
            }
        }
        println!("{} tiles checked; the biggest has {} vertices ({:?})", checked, most_vertices, most_at);
        assert!(checked >= 60, "only {} tiles were checked", checked);
    }
}
