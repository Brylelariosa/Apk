// track.h - procedural mountain road: centre line, frames, curvature, terrain profile.
#pragma once

#include <cstdint>
#include <vector>

#include "config.h"
#include "math3d.h"
#include "rng.h"

namespace sd {

struct TrackSample {
    Vec3 pos;          // road centre line (road surface)
    Vec3 fwd;          // unit tangent, includes pitch
    Vec3 right0;       // horizontal right vector (unbanked)
    Vec3 up0;          // unbanked surface normal
    Vec3 right, up;    // banked frame
    float s = 0.0f;
    float heading = 0.0f;    // yaw, + turns right
    float pitch = 0.0f;      // + descends
    float curvature = 0.0f;  // 1/m, + right turn
    float bank = 0.0f;       // + lowers the right edge
};

// A gorge jump. Where one side of the road is the downhill side, the road makes a U-shaped detour round a gorge: a sharp bend away from
// the straight, a leg going down the rim, a hairpin round the head of the gorge, a leg coming back up the other rim and a sharp bend
// back onto the original line. There is only ever the one road. A kicker at the cliff edge where the detour begins lets a rider who
// has the speed fly straight across the mouth of the gorge and land on the road beyond it, skipping the whole detour; everybody else
// rides the detour. Everything is a pure function of the seed, so every phone in a LAN race has the same ones.
struct ShortcutZone {
    float side = 1.0f;                    // +1 right, -1 left: the side the gorge is on (the kicker is at that edge of the road)
    float sRamp0 = 0.0f, sLip = 0.0f;     // the kicker: where it starts and its lip
    float rampX0 = 2.0f, rampX1 = 4.9f;   // its lateral extent (measured toward the gorge side)
    float lipHeight = 1.25f;
    float sBend0 = 0.0f, sBend1 = 0.0f;   // the detour: from the first bend to where the road is straight again on its original line
    float sLand = 0.0f;                   // where the flight touches down: on the road, just after the detour
    float sGorge0 = 0.0f, sGorge1 = 0.0f; // the stretch of road with the gorge cut into the ground beside it
    float xsFlight = 2.9f;                // lateral line of the flight (toward the gorge side): the same at the lip and at the landing
    float climb = 0.20f;                  // how steeply the flight leaves the lip (rise per metre)
    float floorY = 0.0f;                  // the gorge floor, in the same reference as roadY
    int baseIndex = 0;                    // sample index of roadY[0]
    std::vector<float> roadY;             // per sample: height of the road relative to the first one (the descent of the detour)
    float roadYAt(float s) const;
    float rampHeight(float s, float xs) const;   // xs = lateral position toward the gorge side
};

class Track {
public:
    enum Surface { kVoid = 0, kRoad = 1, kKicker = 2 };

    explicit Track(uint32_t seed = 1u);
    void reset(uint32_t seed);
    uint32_t seed() const { return seed_; }

    void ensureGenerated(float sMax);
    float generatedLength() const { return samples_.empty() ? 0.0f : samples_.back().s; }
    int sampleCount() const { return static_cast<int>(samples_.size()); }
    const TrackSample& sampleAt(int i) const { return samples_[static_cast<size_t>(i)]; }

    // Interpolated frame at distance s (clamped to the generated range).
    TrackSample at(float s) const;

    float curvatureAt(float s) const;
    float pitchAt(float s) const;
    float difficultyAt(float s) const;
    float hillBias(float s) const;   // -1..1, + means the right side is the uphill side

    static float bankDrop(float lateral, float bank);
    static float insideLimit(float curvature);

    // Height of the terrain above the road plane at lateral offset d.
    float terrainHeight(float s, float d) const;
    // World position of terrain-mesh vertex (ring, column).
    Vec3 ringVertex(int ring, int col) const;
    // World position on the terrain mesh at (s, d), consistent with the rendered mesh.
    Vec3 terrainPoint(float s, float d) const;
    // Point on the banked road surface at lateral offset, plus a height above it.
    static Vec3 surfacePoint(const TrackSample& f, float lateral, float height = 0.0f);

    // ---- gorge jumps (see ShortcutZone)
    const std::vector<ShortcutZone>& shortcuts() const { return zones_; }
    const ShortcutZone* zoneAt(float s) const;   // the zone whose kicker / detour is near s, or null
    int zoneIndexAt(float s) const;              // ... and its index, or -1
    // Height (above the road plane) of whatever carries a rider at (s, x); `kind` says what it is. Where nothing does, the terrain.
    float supportHeight(float s, float x, int* kind = nullptr) const;
    // How far a grounded rider may go to either side (the rails), including the gap at the kicker.
    void lateralWindow(float s, int kind, float* lo, float* hi) const;
    bool railGap(float s, float side) const;   // no guard rail here on that side (the kicker)
    bool shortcutBlocks(float s, float d, float margin) const;   // trees and rocks keep out of the kicker and the start of the flight
    int gorgeSide(float s) const;              // +1 / -1: the side of the road the gorge is on at s; 0 where there is none
    // The flight over the gorge: world position and direction of travel at progress u (0 at the lip, 1 at touchdown).
    void gapFlight(const ShortcutZone& z, float u, Vec3* pos, Vec3* dir) const;
    float gapChord(const ShortcutZone& z) const;   // length of the flight path (m)
    // The flight is steerable: the reference path above is the line a rider who just lets go flies. A rider is `b` metres to the right of
    // it with the board turned `rel` radians (+ right) from it, and `arc` metres off its height at mid-flight (+ higher).
    struct GapFrame {
        Vec3 p0, p1;           // the lip and the touchdown (world)
        Vec3 e0, r0;           // horizontal unit vectors: along the reference line and to its right
        float chordH = 1.0f;   // its horizontal length (m)
        float heading = 0.0f;  // heading of e0 (yaw, + turns right)
    };
    GapFrame gapFrameOf(const ShortcutZone& z) const;
    void gapFlightAt(const ShortcutZone& z, float u, float b, float rel, float arc, Vec3* pos, Vec3* dir) const;
    // The ground under a world point somewhere over a detour: the road position (s, lateral d) of the nearest part of the road and the
    // height of the terrain / road surface there. False where there is no road to measure from.
    bool groundNear(const ShortcutZone& z, const Vec3& p, float* s, float* d, float* groundY) const;

private:
    struct Segment {
        float s0, len, k;   // start, length, peak curvature (0 = straight)
    };

    void generateNext();
    void planUntil(float sTarget);
    bool planGorge();      // tries to plan a gorge detour (see ShortcutZone) at the end of the plan
    float detourWeight(float s) const;   // 1 inside a detour (it goes down at a steady slope), easing out over 40 m either side
    float carve(float s, float d, float h) const;
    static void buildFrame(TrackSample& t);

    uint32_t seed_ = 1u;
    Rng rng_;
    std::vector<TrackSample> samples_;
    std::vector<Segment> segments_;
    std::vector<ShortcutZone> zones_;
    float lastJumpBend_ = -1e6f;
    float planEnd_ = 0.0f;
    float planHeading_ = 0.0f;
    float lastDir_ = 1.0f;
    bool lastWasStraight_ = true;
    float phase_[6] = {0, 0, 0, 0, 0, 0};
};

}  // namespace sd
