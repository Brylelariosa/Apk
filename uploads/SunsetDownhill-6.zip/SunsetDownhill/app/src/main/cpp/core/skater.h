// skater.h - downhill longboard physics in road space (Frenet frame).
#pragma once

#include "math3d.h"
#include "track.h"

namespace sd {

struct SkaterInput {
    float steer = 0.0f;   // -1 (left) .. +1 (right)
    bool tuck = false;
    bool slide = false;
};

enum class SkaterEvent : uint8_t { None = 0, Scrape, Crash };
enum class CrashCause : uint8_t { None = 0, Rail, Obstacle, Stall, Fall };

struct Skater {
    // kinematics in road space
    float s = 0.0f;       // distance along the road
    float x = 0.0f;       // lateral offset (+ right)
    float alpha = 0.0f;   // travel heading relative to the road tangent
    float speed = 0.0f;   // m/s

    // smoothed controls
    float steer = 0.0f, tuck = 0.0f, slide = 0.0f;

    // visual state
    float yawVis = 0.0f;      // board angle to the travel direction while sliding (+ = nose to the right)
    float yawVel = 0.0f;      // (spring state for yawVis)
    float lean = 0.0f;        // roll toward the turn
    float slideDir = 1.0f;    // side the Coleman slide is kicked out to
    float pushPhase = 0.0f;   // kick cycles since the push began (0 .. cfg::kPushStrokes)
    float pushAmount = 0.0f;  // 0..1 weight of the kick-push pose
    int pushSteps = 0;        // counts kicks (foot plants) - drives the push sound
    int pushLands = 0;        // counts "foot back on the deck" - drives the landing sound
    float scrape = 0.0f;      // recent rail contact intensity (0..1)
    float railTime = 0.0f;    // accumulated rail contact (decays after a clear spell)
    float railClear = 0.0f;   // time since the last rail contact
    float stallTime = 0.0f;   // time spent (almost) stopped

    // status
    bool crashed = false;
    CrashCause crashCause = CrashCause::None;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
    bool onShoulder = false;

    // vertical state (kicker hops): height above the road plane at the current s
    float yRel = 0.0f;
    float vy = 0.0f;           // vertical speed relative to the road plane
    bool airborne = false;
    float airTime = 0.0f;      // duration of the current / last flight
    float airPeak = 0.0f;      // its highest point
    int surface = 1;           // Track::kRoad / kKicker: what carries the board
    int takeoffs = 0, landings = 0;
    float lastLandVy = 0.0f;   // vertical speed at the last landing (negative = falling)
    int lastLandKind = 0;
    float pushTimer = 0.0f;
    float distance = 0.0f;
    float topSpeed = 0.0f;

    // Gorge jump (see ShortcutZone): a rider who leaves the kicker with enough speed glides over the gorge to the road beyond it, and
    // steers while doing so. The height of the flight follows a fixed arc, so any entry speed gets across; sideways the rider is free:
    // steering turns the board and the flight drifts with it, TUCK dives the arc and SLIDE floats it. Come down on the road, reasonably
    // straight, and the run goes on; miss it and the rider falls into the gorge (or hits the slope). While this lasts s / x / alpha carry
    // the flight in the shape the network sends (s along the detour, x = gapB, alpha = gapRel); the world position comes from
    // Track::gapFlightAt.
    bool gapFlight = false;
    float gapU = 0.0f;         // progress along the flight, 0 .. 1
    float gapRate = 20.0f;     // m/s along the reference line
    float gapTime = 0.0f;
    float gapB = 0.0f;         // metres to the right of the reference line (the line a rider who lets go flies)
    float gapRel = 0.0f;       // board heading relative to it (rad, + right)
    float gapB0 = 0.0f, gapRel0 = 0.0f;   // the part of those two carried over from the lip: it fades out in the first second
    float gapBs = 0.0f, gapRels = 0.0f;   // the part the rider steers
    float gapArc = 0.0f;       // bend of the arc (m): + higher, - lower
    float gapFocus = 0.0f;     // the part of the road the world is built around during the flight
    int gapZone = -1;
    int gapJumps = 0;          // gorge jumps completed
    float focusS() const { return gapFlight ? gapFocus : s; }

    void reset(float s0, float speed0 = 0.0f);
    void startPush();
    SkaterEvent step(const SkaterInput& in, const Track& track, float dt);
    void crash(CrashCause cause);
    float speedKmh() const { return speed * 3.6f; }
    // lateral acceleration capacity at the current state (m/s^2)
    float gripNow() const;

private:
    SkaterEvent stepAir(const SkaterInput& in, const Track& track, float dt);
    SkaterEvent stepGap(const SkaterInput& in, const Track& track, float dt);
    bool beginGapFlight(const Track& track);   // at the lip of a kicker: starts the flight over the gorge if there is the speed
};

}  // namespace sd
