# Changelog

## Update 6 (from SunsetDownhill-5): steerable gorge jump, new wheels / board / rider / cloth, real trees, W-beam guard rail, matte road

**You steer the gorge jump** (`skater.*`, `track.*`, `camera.cpp`, `game.cpp`, `autopilot.cpp`, `config.h`)
- Before, a rider who took the kicker was carried along a fixed path with no say in it. Now the flight is steerable
  (`Skater::stepGap`): the arc (height) is still fixed so every entry speed gets across, but sideways the rider is free. Steering turns
  the board (`kGapYawRate`) and the flight drifts with it; the board settles back toward the line to the landing when you let go
  (`kGapCentering`). **TUCK** dives the arc and flies it a little faster, **SLIDE** lifts it and flies it slower (`kGapArcLift`,
  `kGapRangeGain`). The angle and the offset you had at the lip fade out in the first second, so a rider who just lets go lands on the
  line (checked: 0.02 m off, 93 of 93 flights).
- There is something to lose: come down beside the road (the gorge on one side, the slope on the other), land more crooked than 0.85 rad
  to the road, or steer into the slope on the way, and the rider crashes (falling into the gorge if that is what is below). Holding full
  lock the whole flight always misses. A small correction still lands (`test_race`: 93 flights, every check passes).
- Ordinary kicker hops can be steered a little too (`kHopYawRate`).
- `Track::gapFlightAt` is the flight at an offset, a heading and an arc bend, a pure function of them; `Track::groundNear` finds the
  ground under a point over a detour. The LAN needs no new field: a rider in the air still sends `yRel = 100` and `s`, and now `x` (metres
  off the reference line) and `alpha` (how far the board is turned from it) say how they steered, so every phone draws the same flight.
- The autopilot lets go of the controls in the air; `Track::gapFlight` / `gapChord` (the reference line) are unchanged.

**Wheels** (`skater_model.cpp`)
- The wheels were glowing cyan (emissive urethane): that was the blue. They are now plain satin urethane in a natural colour per rider
  style (butterscotch for the sunset rider, white with red cores, lime, pink, yellow) with a bright core, a dark bearing seat and a steel nut.
  The neon underglow, the tail light and the nose light are gone, and so is everything on the road that looked like a reflection of them.

**Board** (`skater_model.cpp`)
- Natural lacquered maple edge, black grip tape, painted underside, three bold sunset stripes at nose and tail instead of four thin ones,
  truck bolts through the grip, black baseplates, polished hangers, coloured bushings, a steel axle nut.

**Road** (`shaders.cpp`)
- The asphalt looked like glass: a mirror-like reflection of the sky at grazing angles plus a sharp sun streak. Now it is dry asphalt with
  a faint broad sheen that only shows in the polished wheel tracks.
- Meshes got a general `gloss` (stored in the vertex alpha, 255 = matte): a sun highlight and a hint of sky, used on the helmet, visor,
  wheels, trucks, deck edge and guard rail.

**Rider** (`skater_model.cpp`, `skater_model.h`, `game.cpp`)
- Helmet: a proper full-face helmet - glossy dome, two racing stripes, a coloured chin bar, a tinted shield that follows the shell from ear
  to ear and a rear spoiler (the old one had black ear pads that read as eyes in a skull).
- Thicker legs, arms and sleeves in the jacket colour with a cream cuff, smaller shoulder / elbow joints and gloves, lighter denim-blue
  pants so the legs show against the dark road (every style's pants are lighter).
- **The cloth no longer goes through the rider.** The neck gaiter tail is now a flat ribbon with some thickness that streams along the
  airflow (`SkaterPose::speed`) blended with the direction the rider's back faces, so it clears the shoulders when the body is twisted in a
  tuck, and every point of it is pushed out of both arms, the hands and the back (`pushOutOfSegment`), whatever the pose.
- `RiderStyle::hub` is the wheel core colour; `SkaterPose::speed` is new.

**Trees** (`mesh_library.cpp`)
- Spruce: nine tiers of jagged boughs (long and short boughs alternate), each turned against the one below and ringed by a drooping skirt
  and a dark underside, dark inside and lit at the tips: a ragged, layered silhouette instead of smooth cones.
- Autumn tree: forked trunk and a crown of eight smooth puffy lobes in different golds, oranges and reds, dark red-brown below.
- Birch: airy golden crown of five lobes, dark bark bands. Undergrowth: four lumps per bush.

**Guard rail** (`mesh_library.cpp`)
- A galvanised steel **W-beam** with two corrugations, steel C-posts every 2 m (the old posts were 3.4 m and 0.6 m apart), offset blocks,
  soil plates and an amber reflector on the beam.

**Tools**
- `tools/render_look.cpp`: close-ups of the rider, board, trees and rail, frames of a real run, and a gorge flight with a steering input.
- `test_race` has `steering over the gorge` (let go lands on the line, nudges move the landing both ways, full lock misses, tuck is faster
  than slide) and only rides zones that are fully generated.

## Update 5 (from SunsetDownhill-4): gorge jump on the existing road, gentler sunset, predictable traffic, new board / rider / trees / road

**Shortcut: no more second road** (`track.*`, `skater.*`, `camera.*`, `game.cpp`, `world.cpp`)
- The shortcut deck on stilts is gone. Now there is only the one road. About once a kilometre it makes a **U-shaped detour round a
  gorge** (sharp bend, leg down the rim, hairpin, leg up the other rim, sharp bend back onto the original line; the road goes down at a
  steady slope all the way). A **kicker** at the cliff edge where the detour starts lets a rider with enough speed (14 m/s, about
  50 km/h) fly **straight across the mouth of the gorge and land on the road beyond it**: the whole detour (about 240 m of road, a good
  20 seconds) is skipped for +500 points. Slower than that it is only a hop.
- The detour is planned so it closes exactly (the exit lies on the line of the entry, heading the same way, checked by `test_race` on
  115 detours). The gorge side has to be the downhill side all along, which also decides which way it turns; the ground beside the road is
  cut away down to a flat floor well below the lowest road (`Track::carve`), the cliff always has its guard rail, the hill side is a cut slope.
- The flight is a fixed parabola from the lip to the landing (`Track::gapFlight`), a pure function of the zone, so the rider, the camera
  and the other phones in a LAN race all draw the same path (a remote rider in the air is recognised by `yRel = 100` and its `s`). The
  camera follows it in world space and blends back to the road camera on touchdown; the world stays built around the gorge mouth while you
  are in the air (`Skater::focusS`). Nothing can hit you up there.
- `aimJump`, the deck, its lateral windows and `kDeck` are removed.

**Sunset** (`atmosphere.cpp`, `shaders.cpp`)
- The sun, its glow, the glare and the sun-lit haze and clouds were too bright and washed the sky out. Sun disc smaller and dimmer, glow
  and glare roughly halved, haze / cloud / mountain colours a bit darker and less hot, less sheen on the asphalt.

**Cars no longer swerve for no reason** (`traffic.*`)
- Measured on the old code: 40% of all cars crossed the centre line, mostly (22 of 36) to dodge a plastic traffic cone - which the rider
  just drives through - and others to overtake slower cars or to dodge the rider. Now: cones are driven over and knocked flying, cars follow
  slower cars instead of overtaking them, they do not steer around the rider, they react to what is about 3 seconds ahead instead of 5-6,
  and the indicator comes a full second before a move. Left: boulders (the only reason to leave your half of the road). Only 11% of cars
  now cross the centre line, all for a boulder; `test_traffic` fails on anything else.

**Looks** (`skater_model.cpp`, `mesh_library.cpp`, `shaders.cpp`, `world.cpp`)
- Rider: sunset-orange jacket with navy sleeves / pants and cream trim (the old one was charcoal on dark asphalt and disappeared), helmet
  stripe in the jacket colour, glowing reflective tape, a neck gaiter tail that streams and flutters. All six rider colours are brighter.
- Board: bigger wheels, a taller deck and riser pads, a setting sun on the grip at nose and tail (gold to violet bars), a glowing tail
  light and nose light, neon underglow along both edges of the deck in the wheel colour.
- Trees: seven-tier spruces with drooping skirts and turned tiers, round autumn trees with a forked trunk and six lobes in gold / orange
  / red, new white birches with golden crowns, and green and autumn shrubs along the verge.
- Road: tar seams every 17 m, hairline cracks, patches of newer asphalt, patchy sheen, reflective road studs along the centre line,
  fallen-leaf litter and stratified rock on cliff faces.

**Tests**: `tools/test_race` (gorge zones, 255 simulated kicker jumps over different detours and speeds, slow riders only hop),
`tools/test_traffic` (new predictability checks, fail on the old traffic code), all other tests unchanged and green.

## Update 4 (from SunsetDownhill-3): sharper picture, new board / wheels / rider, race goal, cliff jumps, multiplayer sync

**Why the picture was soft (and what changed)**
- The 3D scene is drawn into an offscreen target and stretched to the screen. It used 55 / 70 / 85 / 100 % of the display
  resolution, started at 85 %, dropped a step whenever frames averaged slower than 24 ms, and a hard cap of 1920 px on the long side
  meant a typical 2400 px wide phone could never get above 80 %. Wheels and board are only a few pixels across at the chase camera,
  so a soft upscale and hard jagged edges (no multisampling, FXAA only on the middle tiers) hit them first.
- Presets are now 60 / 75 / 90 / 100 % and the cap is 2560 px. The top tier renders at the full display resolution with **4x MSAA**
  (`gl_util.*`, `renderer.*`: a multisampled twin of the scene target that is resolved into the texture the post pass reads; if the
  device can't do it the scene falls back to FXAA). The post pass has a small clamped **sharpen** that grows with the amount of upscaling.
  The governor is unchanged: it still steps down when frames get slow and back up when they are fast.

**Models** (`skater_model.cpp`, `model_kit.*`)
- New `kit::addLathe` (surface of revolution with smooth or creased normals).
- Wheels: rounded urethane tyre with shoulders and a slightly crowned tread (it was a 10-sided puck), dark groove, bright hub with an
  axle recess and a steel nut. Trucks: riser pad, rounded baseplate, tapered hanger, two coloured bushings, axle.
- Deck: concave, rounded rails, a real grip-tape top (the old one was never visible), centre and flank stripes, tip bands.
- Rider: smoother limbs and joints, lofted shoes (gum sole, toe bumper, laces, heel tab), smoother helmet, a glowing sunset badge on the
  back (the part you look at all run). Remote riders use a cheaper model (`SkaterPose::lowDetail`) and are skipped if the 16-bit index
  range of the dynamic mesh would overflow (`scene_builder.cpp`).

**Race goal (multiplayer)**
- The host picks the race length in the room (**GOAL 1 / 2 / 3 / 5 KM or ENDLESS**, default 2 km). First across the line wins; the
  standings show metres to go or the finish time; crossing the line gives FINISH banner, +500 and the results with times.
  Finish times are measured from GO on a shared clock. A rider who crashes is out (DNF) as before. Single-player stays endless.

**Cliff jumps** (`track.*`, `skater.*`, `world.*`)
- Some bends are now tight (about 55 m radius, 95-118 degrees) on stretches where the inside is the downhill side. There the road has a
  wooden **kicker** at the cliff edge (warning sign before it, no guard rail beside it). Hit it and you fly out over the cliff and land
  on a wide platform that continues as a **shortcut road on stilts** on the inside of the bend and merges back into the road.
  The inside lane covers the bend in less road: about 1 s saved on average in the tests. The board is aimed at the platform by the
  kicker (`Skater::aimJump` simulates the flight for the current speed and bend), landing on the deck gives +300, flights over 0.6 s
  give "AIR TIME", missing the deck or landing from a great height is a crash.
- Physics: height above the road (`yRel`, `vy`), flight with arcade gravity, lateral rail windows that follow the deck, terrain carved
  away under the deck so it really stands above a drop. Zones are a pure function of the seed (same on every phone) and show up about
  once a kilometre. The autopilot keeps off the kicker.

**Multiplayer: delay and sync** (`net.*`)
- Other riders used to be drawn by *arrival* time 120 ms in the past at 20 Hz, so Wi-Fi jitter and bursts of packets showed up
  directly as stutter and lag. Now every state carries the sender's race time; receivers play it back by that timestamp with a
  jitter-adaptive delay (about 60 ms on a quiet network, up to 220 ms on a bad one) and a short extrapolation. 30 updates per second.
- **Clock sync:** clients ping the host (round trip + host clock), keep the best of the last 8, and the START message carries the host's
  clock. A phone that gets START late fast-forwards its countdown by the difference, so **GO is the same moment everywhere**
  (before, each phone counted down from whenever its START packet arrived; lost packets made it worse).
- Android: a **Wi-Fi low-latency lock** (`LanSupport.kt`, `WAKE_LOCK` permission). Wi-Fi power saving batches packets and delivers
  them 100-200 ms late - a big part of "multiplayer is delayed".
- Protocol is now "SDH2" (an old build can't join a new one). New: pong, finish line distance in START, height / airborne / finish
  fields in the state. `tools/test_net` covers clock sync, goal sharing, finish reporting and playback of a burst of packets.

**Tests**: `tools/test_race` (mesh budget, cliff jump zones, 196 simulated kicker jumps, finish line, simultaneous start).

## Update 3 (from SunsetDownhill-2): HUD text, new models, drivers, LAN multiplayer

**HUD text (the "overlapping strokes / fading" problem)**
- The stroke font used to be built from many overlapping translucent quads per glyph, so any text that was not fully opaque (the
  drop shadow, the fading popups and countdown, the distance readout) showed the strokes through each other and looked patchy.
  Every glyph is now a single quad sampled from a signed-distance atlas (`ui_font.cpp`, `ui_atlas.h`): even opacity, crisp edges at
  any size, and a soft dark halo instead of the offset shadow.
- `textWidth` used to leave out the stroke thickness, so the "KM/H" label sat on top of the last digit. It now returns the exact ink
  width, and the label shares the baseline of the digits.
- `UiVertex` grew texture coordinates and a halo strength (24 bytes); the UI shader samples the atlas (`shaders.cpp`, `renderer.cpp`).

**Models**
- Rider: full-face helmet with visor, chin bar, stripe and spoiler; lofted jacket with accent band and reflective stripe; hood;
  round limbs with joint balls; knee pads; cuffs; slide gloves with pucks; skate shoes. Same rig and poses as before (`skater_model.cpp`).
  Six colour styles (one per LAN slot).
- Longboard: pintail outline with kicked nose and tail, grip tape with centre stripe, trucks (baseplate, hanger, axle, bushing) and
  glowing wheels with cores. Built once per style and re-posed with a matrix.
- Cars: five lofted body styles - sedan, hatchback, SUV, pickup, van - with wheels, rims, arches, lamps, mirrors, plates and door
  seams (`car_models.cpp`). New helpers in `model_kit.*` (loft, tube, ellipsoid); `addBlob` now caches the icosphere topology.

**Traffic**
- Cars used to drive straight through cones and rocks. `traffic.cpp` gives every car a driver: lane keeping, Intelligent Driver Model
  speed control, curve speed limit, brake lights, indicators, mirror checks, gap acceptance, steering around obstacles through free
  lanes, waiting for a gap with room to pull out, keeping clear of the rider. `tools/test_traffic`: zero overlaps with cones, rocks or
  other cars on many seeds, also with a rider weaving across both lanes.
- Cones and rocks are a pure function of the seed (cars no longer influence where they appear).

**LAN multiplayer** (see README): `net.*` (UDP protocol, polled from the game thread), `hud_mp.*` (lobby, standings, name tags,
results), engine integration, `LanSupport.kt` (multicast lock, Wi-Fi binding, device name), new permissions in the manifest.
`tools/test_net` (protocol, spoofing, garbage) and `tools/test_mp_engine` (three engines play a race through the lobby screens).

**Tools**: `test_traffic`, `test_net`, `test_mp_engine`, `render_models`, `render_traffic`, `render_lan`; `dump_ui` renders the font sheet
and the LAN screens.
