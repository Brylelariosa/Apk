// Race rules and the gorge jump (no GPU needed):
//  - the rider meshes stay inside the 16-bit index budget of the dynamic mesh, six riders at once
//  - gorge zones: the U-shaped detour closes onto the original line, the ground is cut away beside it, support / rail rules are consistent
//  - the kicker flies the rider across the gorge onto the road beyond at any sensible speed, and the jump is a real shortcut
//  - the finish line ends a race, and a late START message fast-forwards the countdown so that GO is simultaneous
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "game.h"
#include "skater_model.h"
#include "track.h"

using namespace sd;

static int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

static void testMeshBudget() {
    std::printf("rider mesh budget\n");
    size_t worst = 0, worstLow = 0;
    for (int style = 0; style < kRiderStyleCount; ++style) {
        for (int pose = 0; pose < 6; ++pose) {
            SkaterPose p;
            p.origin = Vec3(0, 0, 0); p.right = Vec3(1, 0, 0); p.up = Vec3(0, 1, 0); p.fwd = Vec3(0, 0, 1); p.time = 1.3f;
            if (pose == 1) p.tuck = 1.0f;
            if (pose == 2) { p.push = 1.0f; p.pushPhase = 0.4f; }
            if (pose == 3) { p.slide = 1.0f; p.slip = 1.1f; p.slideDir = -1.0f; }
            if (pose == 4) { p.crashed = true; p.crashTime = 0.7f; p.crashSpeed = 14.0f; }
            if (pose == 5) { p.lean = 0.5f; p.tuck = 0.5f; }
            MeshData full, low;
            p.lowDetail = false; buildSkaterMesh(p, full, riderStyle(style));
            p.lowDetail = true; buildSkaterMesh(p, low, riderStyle(style));
            worst = std::max(worst, full.vertices.size());
            worstLow = std::max(worstLow, low.vertices.size());
        }
    }
    std::printf("  full detail %zu vertices, low detail %zu\n", worst, worstLow);
    CHECK(worst <= kRiderVertexBudget, "full detail rider %zu > budget %zu", worst, kRiderVertexBudget);
    CHECK(worstLow <= kRemoteRiderVertexBudget, "low detail rider %zu > budget %zu", worstLow, kRemoteRiderVertexBudget);
    CHECK(worst + 5 * worstLow + 8000 <= kDynamicMeshVertexLimit, "the local rider + five remote riders + the world's own dynamic geometry must fit 16-bit indices");
}

static void testZones() {
    std::printf("gorge zones\n");
    int zones = 0;
    float minChord = 1e9f, maxChord = 0.0f, minDrop = 1e9f, maxDrop = 0.0f, minRadius = 1e9f, worstClosure = 0.0f, worstHeading = 0.0f;
    for (uint32_t seed = 1; seed <= 30; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        const auto& list = tr.shortcuts();
        for (size_t zi = 0; zi < list.size(); ++zi) {
            const ShortcutZone& z = list[zi];
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;   // (the last one is only planned, not yet generated)
            ++zones;
            CHECK(z.sRamp0 < z.sLip && z.sBend0 < z.sLip && z.sLip < z.sBend1 && z.sBend1 < z.sLand && z.sLand < z.sGorge1 && z.sGorge0 < z.sRamp0 + 9.0f, "ordering seed %u", seed);
            CHECK(zi == 0 || list[zi - 1].sGorge1 + 300.0f < z.sRamp0, "zones are spaced");
            CHECK(z.side == 1.0f || z.side == -1.0f, "side");

            // the detour closes: the road is back on its original line, heading the same way, so the flight is a straight jump across the mouth
            const TrackSample a = tr.at(z.sLip - 8.0f), b = tr.at(z.sLand);
            const Vec3 d = b.pos - a.pos;
            const float along = d.x * a.fwd.x + d.z * a.fwd.z;
            const float across = std::fabs(d.x * a.right0.x + d.z * a.right0.z);
            float dh = std::fabs(b.heading - a.heading);
            worstClosure = std::max(worstClosure, across);
            worstHeading = std::max(worstHeading, dh);
            CHECK(across < 2.5f, "the exit is on the entry line, off by %.2f m (seed %u)", across, seed);
            CHECK(dh < 3.0f * kDeg2Rad, "the exit heads the way the entry did, off by %.1f deg", dh / kDeg2Rad);
            const float chord = tr.gapChord(z);
            minChord = std::min(minChord, chord);
            maxChord = std::max(maxChord, chord);
            CHECK(along > 60.0f && along < 115.0f, "the jump is %.0f m across", along);
            CHECK(chord > 60.0f && chord < 125.0f, "flight path %.0f m", chord);
            const float drop = z.roadYAt(z.sLip) - z.roadYAt(z.sLand);
            minDrop = std::min(minDrop, drop);
            maxDrop = std::max(maxDrop, drop);
            CHECK(drop > 14.0f && drop < 36.0f, "the road goes down %.1f m over the detour", drop);

            // the detour itself: sharp, but never absurdly so, and the gorge side is the downhill side all along
            float roadMin = 1e9f;
            bool downhill = true;
            for (float s = z.sBend0; s <= z.sBend1; s += 1.0f) {
                const float k = std::fabs(tr.curvatureAt(s));
                if (k > 1e-4f) roadMin = std::min(roadMin, 1.0f / k);
                if (tr.hillBias(s) * z.side > -0.06f) downhill = false;
            }
            minRadius = std::min(minRadius, roadMin);
            CHECK(roadMin > 14.0f && roadMin < 20.0f, "tightest radius %.1f m", roadMin);
            CHECK(downhill, "the gorge side is the downhill side (seed %u)", seed);

            // the ground: a flat floor well below the lowest road, on the gorge side only, and the flight stays well above it
            const float sMid = 0.5f * (z.sBend0 + z.sBend1);
            CHECK(tr.terrainHeight(z.sLip + 20.0f, z.side * 12.5f) < -12.0f, "gorge floor beside the first leg: %.1f", tr.terrainHeight(z.sLip + 20.0f, z.side * 12.5f));
            CHECK(tr.terrainHeight(sMid, z.side * 21.0f) < -9.0f, "gorge floor at the hairpin: %.1f", tr.terrainHeight(sMid, z.side * 21.0f));
            CHECK(tr.terrainHeight(z.sLip - 40.0f, z.side * 12.5f) > -30.0f, "no gorge before the kicker");
            CHECK(tr.terrainHeight(sMid, z.side * 5.0f) > -0.5f, "the shoulder is still there: %.2f", tr.terrainHeight(sMid, z.side * 5.0f));
            bool clear = true;
            for (int i = 0; i <= 20; ++i) {
                const float u = static_cast<float>(i) / 20.0f;
                Vec3 p, dir;
                tr.gapFlight(z, u, &p, &dir);
                // height of the path above the gorge floor, measured along the road's own descent
                if (!(dir.x == dir.x)) clear = false;
            }
            CHECK(clear, "flight path is finite");
            Vec3 p0, p1, pm;
            tr.gapFlight(z, 0.0f, &p0, nullptr);
            tr.gapFlight(z, 1.0f, &p1, nullptr);
            tr.gapFlight(z, 0.5f, &pm, nullptr);
            const Vec3 land = Track::surfacePoint(tr.at(z.sLand), z.side * z.xsFlight, 0.0f);
            CHECK(length(p1 - land) < 0.01f, "the flight ends on the road");
            CHECK(pm.y > std::min(p0.y, p1.y) - 1.0f && z.floorY < z.roadYAt(z.sLand) - 8.0f, "the floor lies well below the landing");

            int kind = -1;
            const float sk = z.sRamp0 + 5.0f;
            CHECK(tr.supportHeight(sk, z.side * 3.4f, &kind) > 0.1f && kind == Track::kKicker, "kicker carries the rider");
            CHECK(tr.supportHeight(z.sLip + 3.0f, z.side * 3.4f, &kind) == 0.0f && kind == Track::kRoad, "road after the lip");
            tr.supportHeight(z.sLip + 3.0f, z.side * 12.0f, &kind);
            CHECK(kind == Track::kVoid, "nothing carries a rider off the road");
            CHECK(tr.railGap(z.sLip, z.side) && !tr.railGap(z.sLip, -z.side) && !tr.railGap(z.sRamp0 - 20.0f, z.side) && !tr.railGap(z.sLip + 12.0f, z.side), "rail gap at the kicker only");
            float lo, hi;
            tr.lateralWindow(z.sLip, Track::kKicker, &lo, &hi);
            CHECK((z.side > 0 ? hi : -lo) > 100.0f, "no rail beside the kicker");
            tr.lateralWindow(z.sLip + 20.0f, Track::kRoad, &lo, &hi);
            CHECK(hi - lo < 11.0f, "rails again after the kicker");
            CHECK(tr.gorgeSide(z.sLip + 20.0f) == static_cast<int>(z.side) && tr.gorgeSide(z.sRamp0 - 60.0f) == 0 && tr.gorgeSide(z.sGorge1 + 20.0f) == 0, "gorge side");
            CHECK(tr.shortcutBlocks(z.sLip - 3.0f, z.side * 6.0f, 4.0f) && !tr.shortcutBlocks(z.sLip - 3.0f, -z.side * 6.0f, 4.0f), "scenery keeps off the kicker, not the other side of the road");
        }
    }
    std::printf("  %d zones over 30 seeds x 4.6 km; jump %.0f..%.0f m, descent %.0f..%.0f m, tightest radius %.1f m, worst closure %.2f m / %.2f deg\n",
                zones, minChord, maxChord, minDrop, maxDrop, minRadius, worstClosure, worstHeading / kDeg2Rad);
    CHECK(zones >= 30, "zones are common enough: %d", zones);
}

struct JumpResult { bool flew = false, crashed = false; float t = 0.0f; float top = 0.0f; };

// Rides from 110 m before the kicker to 40 m past the landing. With takeKicker the rider leaves the lip at exactly v0.
static JumpResult ride(const Track& tr, const ShortcutZone& z, float v0, bool takeKicker, bool* crashedBefore = nullptr) {
    Skater sk;
    sk.reset(z.sRamp0 - 110.0f, v0);
    if (takeKicker) sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
    AutoPilot ap;
    std::vector<Obstacle> none;
    JumpResult r;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 90 && sk.s < z.sLand + 40.0f; ++i) {
        if (takeKicker && sk.s < z.sLip - 0.5f) { sk.speed = v0; ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side; }   // the entry speed is the test's input
        else ap.forcedX = 1e9f;
        sk.step(ap.compute(tr, none, sk), tr, dt);
        r.top = std::max(r.top, sk.speed);
        r.t += dt;
        if (sk.gapJumps > 0) r.flew = true;
        if (sk.crashed) { r.crashed = true; break; }
    }
    (void)crashedBefore;
    return r;
}

static void testJumps() {
    std::printf("gorge jumps\n");
    int total = 0, good = 0, compared = 0, hopsOk = 0, hops = 0, detoursOk = 0, detours = 0;
    double saved = 0.0;
    for (uint32_t seed = 1; seed <= 12; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;   // (the last one is only planned, not yet generated)
            for (float v : {16.0f, 20.0f, 24.0f, 28.0f, 32.0f}) {
                const JumpResult a = ride(tr, z, v, true), b = ride(tr, z, v, false);
                ++total;
                if (a.flew && !a.crashed) {
                    ++good;
                    if (!b.crashed) { saved += b.t - a.t; ++compared; }
                }
                ++detours;
                if (!b.crashed) ++detoursOk;
            }
            // too slow for the gorge: the kicker is only a hop, and the rider does not fly across
            ++hops;
            const JumpResult h = ride(tr, z, 9.0f, true);
            if (!h.flew) ++hopsOk;
        }
    }
    const double rate = total ? static_cast<double>(good) / total : 0.0;
    const double mean = compared ? saved / compared : 0.0;
    std::printf("  %d/%d jumps flew over the gorge and rode on; the jump saves %.1f s on average over the detour; %d/%d detour rides came through; %d/%d slow kicker rides only hopped\n",
                good, total, mean, detoursOk, detours, hopsOk, hops);
    CHECK(total >= 100, "enough jumps tested: %d", total);
    CHECK(rate >= 0.97, "jump rate %.3f", rate);
    CHECK(mean > 4.0, "the jump must be a real shortcut: %.2f s", mean);
    CHECK(detoursOk >= detours * 0.9, "the autopilot comes through the detour: %d/%d", detoursOk, detours);
    CHECK(hopsOk == hops, "slow riders do not fly: %d/%d", hopsOk, hops);
}

// ---- steering over the gorge: where the rider comes down is the rider's call
struct FlightResult { bool landed = false, crashed = false; float xLand = 0.0f, t = 0.0f; };

// Leaves the lip at v0 from the middle of the kicker and steers with steerFn(time in the air) / tuck / slide until the landing.
template <class F>
static FlightResult fly(const Track& tr, const ShortcutZone& z, float v0, F steerFn, bool tuck = false, bool slide = false) {
    Skater sk;
    sk.reset(z.sRamp0 - 110.0f, v0);
    sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
    AutoPilot ap;
    std::vector<Obstacle> none;
    FlightResult r;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 90 && sk.s < z.sLand + 30.0f; ++i) {
        SkaterInput in;
        if (sk.gapFlight) {
            in.steer = steerFn(sk.gapTime);
            in.tuck = tuck;
            in.slide = slide;
        } else {
            if (sk.s < z.sLip - 0.5f) { sk.speed = v0; ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side; }
            else ap.forcedX = 1e9f;
            in = ap.compute(tr, none, sk);
        }
        const int jumps = sk.gapJumps;
        sk.step(in, tr, dt);
        if (sk.gapJumps > jumps) { r.landed = true; r.xLand = sk.x; r.t = sk.gapTime; }
        if (sk.crashed) { r.crashed = true; break; }
    }
    return r;
}

static void testSteeredFlight() {
    std::printf("steering over the gorge\n");
    int n = 0, letGoLands = 0, centred = 0, rightMoves = 0, leftMoves = 0, nudgeLands = 0, hardMisses = 0, tuckFaster = 0;
    float worstCentre = 0.0f;
    for (uint32_t seed = 1; seed <= 8; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4600.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            if (z.sGorge1 + 10.0f > tr.generatedLength()) continue;
            for (float v : {18.0f, 24.0f, 30.0f}) {
                ++n;
                const FlightResult let = fly(tr, z, v, [](float) { return 0.0f; });
                if (let.landed && !let.crashed) {
                    ++letGoLands;
                    const float off = std::fabs(let.xLand - z.side * z.xsFlight);
                    worstCentre = std::max(worstCentre, off);
                    if (off < 1.6f) ++centred;
                }
                // a short nudge to the right / to the left: it lands that much further over (in road-right terms) and still lands
                const FlightResult r = fly(tr, z, v, [](float t) { return t < 0.4f ? 0.5f : 0.0f; });
                const FlightResult l = fly(tr, z, v, [](float t) { return t < 0.4f ? -0.5f : 0.0f; });
                if (r.landed && !r.crashed && let.landed && r.xLand > let.xLand + 1.0f) ++rightMoves;
                if (l.landed && !l.crashed && let.landed && l.xLand < let.xLand - 1.0f) ++leftMoves;
                if (r.landed && l.landed) ++nudgeLands;
                // full lock for the whole flight sails off the road: freedom has a price
                const FlightResult hard = fly(tr, z, v, [](float) { return 1.0f; });
                if (hard.crashed && !hard.landed) ++hardMisses;
                // TUCK dives the flight (it is over sooner), SLIDE floats it, and both still land
                const FlightResult tk = fly(tr, z, v, [](float) { return 0.0f; }, true, false), sl = fly(tr, z, v, [](float) { return 0.0f; }, false, true);
                if (tk.landed && sl.landed && tk.t < sl.t - 0.1f) ++tuckFaster;
            }
        }
    }
    std::printf("  %d flights: %d landed when the rider let go (worst %.2f m off the line); %d/%d nudges right and %d/%d left moved the landing; %d/%d full-lock flights missed; %d/%d tuck faster than slide\n",
                n, letGoLands, worstCentre, rightMoves, n, leftMoves, n, hardMisses, n, tuckFaster, n);
    CHECK(n >= 60, "enough flights tested: %d", n);
    CHECK(letGoLands >= n * 0.97, "letting go lands: %d/%d", letGoLands, n);
    CHECK(centred >= letGoLands * 0.97, "letting go lands near the line: %d/%d", centred, letGoLands);
    CHECK(rightMoves >= n * 0.95 && leftMoves >= n * 0.95, "steering moves the landing: right %d left %d of %d", rightMoves, leftMoves, n);
    CHECK(nudgeLands >= n * 0.95, "small corrections still land: %d/%d", nudgeLands, n);
    CHECK(hardMisses >= n * 0.95, "holding full lock misses the road: %d/%d", hardMisses, n);
    CHECK(tuckFaster >= n * 0.95, "tuck flies the arc faster than slide: %d/%d", tuckFaster, n);
}

static void testFinishLine() {
    std::printf("finish line and simultaneous start\n");
    int finished = 0;
    for (uint32_t seed = 1; seed <= 4; ++seed) {
        Game g;
        g.startRunSeeded(seed, 0.0f, 400.0f);
        g.autopilot() = AutoPilot();
        const float dt = 1.0f / 60.0f;
        float t = 0.0f;
        bool wasFinished = false;
        while (t < 120.0f && g.phase() != Phase::GameOver) {
            SkaterInput in;
            if (g.phase() == Phase::Running) in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
            g.update(dt, in);
            if (g.finished()) wasFinished = true;
            t += dt;
        }
        if (wasFinished) {
            ++finished;
            CHECK(g.goalMeters() == 400.0f && g.finishTime() > 12.0f && g.finishTime() < 90.0f, "finish time %.1f", g.finishTime());
            CHECK(g.riderNet().finished && std::fabs(g.riderNet().finishTime - g.finishTime()) < 1e-3f, "the finish travels with the rider's network state");
            CHECK(g.phase() == Phase::GameOver && !g.skater().crashed, "the standings come up after the finish");
        }
    }
    CHECK(finished >= 3, "%d of 4 autopilot runs reached a 400 m finish line", finished);

    // A START that arrives 1.2 s late: that phone's countdown is fast-forwarded and its GO is simultaneous with the host's
    Game host, late;
    host.startRunSeeded(5, 0.0f, 1000.0f);
    late.startRunSeeded(5, 1.2f, 1000.0f);
    const float dt = 1.0f / 60.0f;
    int goHost = -1, goLate = -1;
    for (int i = 0; i < 60 * 6; ++i) {
        host.update(dt, SkaterInput());
        late.update(dt, SkaterInput());
        if (goHost < 0 && host.phase() == Phase::Running) goHost = i;
        if (goLate < 0 && late.phase() == Phase::Running) goLate = i;
    }
    CHECK(goHost > 0 && goLate > 0, "both reach GO");
    CHECK(std::fabs(static_cast<float>(goHost - goLate) * dt - 1.2f) < 0.05f, "GO of the late phone is 1.2 s earlier than a phone that started on time: %d vs %d frames", goLate, goHost);
    Game absurd;
    absurd.startRunSeeded(5, 500.0f, 0.0f);   // a lag outside any sane range is clamped
    absurd.update(dt, SkaterInput());
    CHECK(absurd.phase() == Phase::Countdown || absurd.phase() == Phase::Running, "absurd lag is harmless");
}

int main() {
    testMeshBudget();
    testZones();
    testJumps();
    testSteeredFlight();
    testFinishLine();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
