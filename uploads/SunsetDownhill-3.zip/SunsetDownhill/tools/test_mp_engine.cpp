// test_mp_engine: three complete engines (a host and two clients) play a LAN race against each other over loopback, driven only by
// taps on the lobby screens, exactly as three phones would: find the room, join, start, ride the same road, see each other, finish,
// return to the lobby, start again, leave. No GPU is needed (the renderer is simply not initialised).
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <tuple>
#include <vector>

#include "engine.h"

using namespace sd;

namespace {

int failures = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

constexpr uint32_t kLoopback = 0x7F000001u;

struct Phone {
    std::unique_ptr<Engine> e;
    Phone(uint16_t port, std::initializer_list<uint16_t> beaconTo, const char* name) {
        NetConfig c;
        c.port = port;
        for (uint16_t p : beaconTo) c.discoveryTargets.push_back({kLoopback, p});
        e = std::make_unique<Engine>(c);
        e->setPlayerName(name);
        e->onSurfaceChanged(1920, 1080);
    }
    void tapAt(float x, float y) {
        e->onTouch(0, 1, x, y);
        e->onTouch(2, 1, x, y);
    }
    void tap(const Rect& r) { tapAt(r.x + r.w * 0.5f, r.y + r.h * 0.5f); }
    const UiLayout& layout() const { return e->controls().layout(); }
    Phase phase() const { return e->game().phase(); }
    MpModel mp() const { return e->hudModel().mp; }
};

void frames(int n, const std::vector<Phone*>& phones) {
    for (int i = 0; i < n; ++i)
        for (Phone* p : phones) p->e->stepFrame(1.0f / 60.0f);
}

using Statics = std::vector<std::tuple<int, float, float>>;
Statics staticsUpTo(Phone& p, float s) {
    Statics v;
    for (const Obstacle& o : p.e->game().world().obstacles())
        if (o.kind != ObstacleKind::Car && o.s < s) v.emplace_back(static_cast<int>(o.kind), o.s, o.x);
    std::sort(v.begin(), v.end());
    return v;
}

int filledRows(const MpModel& mp) {
    int n = 0;
    for (int i = 0; i < mp.rowCount; ++i) n += mp.rows[i].name[0] != '\0' ? 1 : 0;
    return n;
}

bool allIn(const std::vector<Phone*>& phones, Phase ph) {
    for (Phone* p : phones)
        if (p->phase() != ph) return false;
    return true;
}

}  // namespace

int main() {
    Phone host(47900, {47901, 47902}, "Host Phone"), a(47901, {}, "Alice Phone"), b(47902, {}, "Bob");
    const std::vector<Phone*> all = {&host, &a, &b};
    frames(10, all);

    // ---- the multiplayer screens
    for (Phone* p : all) p->tap(p->layout().multiMenu);
    frames(5, all);
    for (Phone* p : all) CHECK(p->mp().screen == MpModel::Screen::Choose, "choice screen");

    host.tap(lobbyRects(host.layout()).host);
    a.tap(lobbyRects(a.layout()).search);
    b.tap(lobbyRects(b.layout()).search);
    frames(150, all);
    CHECK(host.mp().screen == MpModel::Screen::Room && host.mp().isHost, "host is in its room");
    CHECK(a.mp().screen == MpModel::Screen::Search && a.mp().rowCount == 1 && std::strcmp(a.mp().rows[0].name, "HOST PHONE") == 0, "alice finds the race: %d rows '%s'",
          a.mp().rowCount, a.mp().rows[0].name);

    a.tap(lobbyRects(a.layout()).rows[0]);
    b.tap(lobbyRects(b.layout()).rows[0]);
    frames(60, all);
    for (Phone* p : all) CHECK(p->mp().screen == MpModel::Screen::Room && filledRows(p->mp()) == 3, "room of three: %d", filledRows(p->mp()));
    CHECK(std::strcmp(host.mp().rows[1].name, "ALICE PHONE") == 0 && std::strcmp(host.mp().rows[2].name, "BOB") == 0, "roster '%s' '%s'", host.mp().rows[1].name,
          host.mp().rows[2].name);
    CHECK(host.mp().canStart && !a.mp().isHost, "only the host can start");
    a.tap(lobbyRects(a.layout()).start);   // a client's tap on that spot does nothing
    frames(10, all);
    CHECK(allIn(all, Phase::Menu), "nobody started yet");

    // ---- race one
    host.tap(lobbyRects(host.layout()).start);
    frames(30, all);
    CHECK(allIn(all, Phase::Countdown), "all three are counting down: %d %d %d", static_cast<int>(host.phase()), static_cast<int>(a.phase()), static_cast<int>(b.phase()));
    CHECK(host.mp().racing && a.mp().racing && b.mp().racing, "LAN race flag");
    const Vec3 p0 = host.e->game().world().track().at(500.0f).pos, p1 = a.e->game().world().track().at(500.0f).pos, p2 = b.e->game().world().track().at(500.0f).pos;
    CHECK(length(p0 - p1) < 1e-3f && length(p0 - p2) < 1e-3f, "same road everywhere");
    const Statics s0 = staticsUpTo(host, 430.0f);
    CHECK(!s0.empty() && s0 == staticsUpTo(a, 430.0f) && s0 == staticsUpTo(b, 430.0f), "same cones and rocks everywhere (%zu of them)", s0.size());

    frames(60 * 12, all);   // the countdown, then ride (nobody steers: the road will bite sooner or later)
    for (Phone* p : all) CHECK(p->e->remoteRiders().size() == 2, "each phone draws the two others: %zu", p->e->remoteRiders().size());
    for (Phone* p : all) {
        const MpModel mp = p->mp();
        CHECK(mp.racing && mp.rowCount == 3 && mp.rank >= 1 && mp.rank <= 3, "standings: %d rows, rank %d", mp.rowCount, mp.rank);
    }
    {   // the host's picture of Alice matches Alice's own rider (within the interpolation delay)
        const RiderNet mine = a.e->game().riderNet();
        const RemoteRider* seen = nullptr;
        for (const RemoteRider& r : host.e->remoteRiders())
            if (r.style == 1) seen = &r;
        CHECK(seen != nullptr, "host sees slot 1");
        if (seen) CHECK(std::fabs(seen->net.s - mine.s) < std::max(6.0f, mine.speed * 0.4f), "alice at %.1f m, host sees %.1f m", mine.s, seen->net.s);
    }

    bool over = false;
    for (int i = 0; i < 60 * 240 && !over; ++i) {
        frames(1, all);
        over = allIn(all, Phase::GameOver);
    }
    CHECK(over, "everybody's run ended: %d %d %d", static_cast<int>(host.phase()), static_cast<int>(a.phase()), static_cast<int>(b.phase()));
    frames(90, all);
    for (Phone* p : all) {
        const MpModel mp = p->mp();
        CHECK(mp.allDone, "results are final");
        bool sorted = true;
        for (int i = 1; i < mp.rowCount; ++i) sorted = sorted && mp.rows[i - 1].score >= mp.rows[i].score;
        CHECK(sorted && mp.rowCount == 3, "results sorted best first");
    }
    {   // everybody sees the same final scores
        const MpModel m0 = host.mp(), m1 = a.mp();
        bool same = m0.rowCount == m1.rowCount;
        for (int i = 0; same && i < m0.rowCount; ++i) same = std::strcmp(m0.rows[i].name, m1.rows[i].name) == 0 && std::abs(m0.rows[i].score - m1.rows[i].score) <= 40;
        CHECK(same, "host and alice agree on the standings");
    }

    // ---- back to the lobby with a tap, then race two with a different road
    for (Phone* p : all) p->tapAt(200.0f, 540.0f);
    frames(20, all);
    for (Phone* p : all) CHECK(p->phase() == Phase::Menu && p->mp().screen == MpModel::Screen::Room && !p->mp().racing, "back in the lobby");
    frames(150, all);
    CHECK(host.mp().canStart, "the room opened again");
    host.tap(lobbyRects(host.layout()).start);
    frames(30, all);
    CHECK(allIn(all, Phase::Countdown), "second race started");
    const Statics s1 = staticsUpTo(host, 430.0f);
    CHECK(s1 != s0 && s1 == staticsUpTo(b, 430.0f), "a new race has a new road, the same for everybody");

    // ---- the host bails out in the middle of a race: the others carry on alone
    frames(60 * 6, all);
    host.e->requestBack();
    frames(10, all);
    CHECK(host.phase() == Phase::Menu && host.mp().screen == MpModel::Screen::Off && !host.mp().racing, "host is back on the main menu");
    frames(30, all);
    for (Phone* p : {&a, &b}) {
        CHECK(!p->mp().racing && !p->e->net().inRoom(), "client left alone: racing=%d inRoom=%d", p->mp().racing, p->e->net().inRoom());
        CHECK(p->phase() != Phase::Menu, "client's run goes on (phase %d)", static_cast<int>(p->phase()));
    }

    std::printf(failures == 0 ? "multiplayer engine OK\n" : "multiplayer engine FAILED (%d)\n", failures);
    return failures == 0 ? 0 : 1;
}
