package com.sunsetdownhill.game

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build

/**
 * Android-side helpers for LAN races (the sockets themselves live in the native engine):
 *  - a multicast lock: many phones silently drop broadcast packets - the lobby's beacon - without one,
 *  - binding the process to the Wi-Fi network, so the race still works when Android prefers mobile data
 *    because the Wi-Fi it is on has no internet (a phone hotspot without data, a router without a line),
 *  - the name the other riders see: the device model.
 * Everything is best effort; if something is refused the single-player game is unaffected.
 */
class LanSupport(context: Context) {
    private val app = context.applicationContext
    private var lock: WifiManager.MulticastLock? = null
    private var bound = false

    /** What the other riders see in the lobby and the standings. */
    val playerName: String = (Build.MODEL ?: "").trim().ifEmpty { "RIDER" }

    fun start() {
        try {
            val wifi = app.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (lock == null) {
                lock = wifi?.createMulticastLock("sunset-downhill-lan")
                lock?.setReferenceCounted(false)
            }
            lock?.acquire()
        } catch (e: Exception) {
            // no permission or no Wi-Fi hardware: LAN races simply will not find anybody
        }
        bindToWifi()
    }

    fun stop() {
        try {
            if (lock?.isHeld == true) lock?.release()
        } catch (e: Exception) {
            // already released
        }
        unbindFromWifi()
    }

    @Suppress("DEPRECATION")
    private fun bindToWifi() {
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            val wifi = cm.allNetworks.firstOrNull { network ->
                cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            } ?: return   // not a Wi-Fi client (for example the phone that hosts the hotspot): nothing to bind
            bound = cm.bindProcessToNetwork(wifi)
        } catch (e: Exception) {
            bound = false
        }
    }

    private fun unbindFromWifi() {
        if (!bound) return
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            cm?.bindProcessToNetwork(null)
        } catch (e: Exception) {
            // ignore
        }
        bound = false
    }
}
