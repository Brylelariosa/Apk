#include "skater_model.h"

#include <algorithm>
#include <cmath>

#include "config.h"
#include "model_kit.h"

namespace sd {
namespace {

const RiderStyle kStyles[kRiderStyleCount] = {
    // 0: the classic look - charcoal jacket, orange accents, white helmet
    {rgba(0.08f, 0.08f, 0.11f), rgba(0.19f, 0.19f, 0.25f), rgba(0.12f, 0.12f, 0.16f), rgba(1.00f, 0.46f, 0.12f), rgba(0.11f, 0.15f, 0.27f),
     rgba(0.96f, 0.96f, 0.98f), rgba(1.00f, 0.46f, 0.12f), rgba(0.25f, 0.95f, 1.00f)},
    // 1: red racer
    {rgba(0.50f, 0.07f, 0.10f), rgba(0.78f, 0.15f, 0.17f), rgba(0.16f, 0.16f, 0.20f), rgba(0.97f, 0.97f, 0.97f), rgba(0.12f, 0.12f, 0.16f),
     rgba(0.88f, 0.12f, 0.12f), rgba(0.90f, 0.14f, 0.14f), rgba(1.00f, 0.38f, 0.28f)},
    // 2: teal
    {rgba(0.05f, 0.34f, 0.38f), rgba(0.10f, 0.60f, 0.62f), rgba(0.09f, 0.13f, 0.17f), rgba(1.00f, 0.86f, 0.22f), rgba(0.14f, 0.14f, 0.18f),
     rgba(0.94f, 0.97f, 0.97f), rgba(0.10f, 0.62f, 0.64f), rgba(0.55f, 1.00f, 0.62f)},
    // 3: purple
    {rgba(0.26f, 0.11f, 0.44f), rgba(0.46f, 0.24f, 0.70f), rgba(0.12f, 0.10f, 0.20f), rgba(1.00f, 0.48f, 0.82f), rgba(0.10f, 0.12f, 0.26f),
     rgba(0.80f, 0.74f, 0.96f), rgba(0.55f, 0.25f, 0.80f), rgba(0.92f, 0.55f, 1.00f)},
    // 4: lime
    {rgba(0.27f, 0.42f, 0.09f), rgba(0.56f, 0.76f, 0.18f), rgba(0.12f, 0.14f, 0.10f), rgba(0.10f, 0.10f, 0.10f), rgba(0.30f, 0.27f, 0.18f),
     rgba(0.98f, 0.92f, 0.30f), rgba(0.62f, 0.85f, 0.18f), rgba(0.92f, 1.00f, 0.30f)},
    // 5: pink and white
    {rgba(0.86f, 0.86f, 0.90f), rgba(1.00f, 1.00f, 1.00f), rgba(0.30f, 0.30f, 0.38f), rgba(1.00f, 0.28f, 0.60f), rgba(0.20f, 0.20f, 0.28f),
     rgba(1.00f, 0.62f, 0.78f), rgba(1.00f, 0.34f, 0.62f), rgba(1.00f, 0.52f, 0.78f)},
};

const Rgba8 kShoe = rgba(0.94f, 0.94f, 0.96f), kSole = rgba(0.86f, 0.80f, 0.66f), kLace = rgba(0.10f, 0.10f, 0.12f);
const Rgba8 kGlove = rgba(0.09f, 0.09f, 0.11f), kPad = rgba(0.10f, 0.10f, 0.12f), kVisorLo = rgba(0.03f, 0.05f, 0.09f), kVisorHi = rgba(0.16f, 0.22f, 0.32f);
const Rgba8 kReflective = rgba(0.82f, 0.84f, 0.88f), kGrip = rgba(0.05f, 0.05f, 0.06f), kTruck = rgba(0.68f, 0.70f, 0.74f);

Rgba8 shade(Rgba8 c, float k) {
    return {static_cast<uint8_t>(std::min(255.0f, c.r * k)), static_cast<uint8_t>(std::min(255.0f, c.g * k)), static_cast<uint8_t>(std::min(255.0f, c.b * k)), c.a};
}

struct Rig {
    const SkaterPose& p;
    MeshData& out;
    Vec3 o, r, u, f;
    const RiderStyle& st;

    Vec3 W(float x, float y, float z) const { return o + r * x + u * y + f * z; }

    void box(const Vec3& centre, const Vec3& axisX, const Vec3& axisY, const Vec3& axisZ, const Vec3& half, Rgba8 c0, Rgba8 c1,
             Material m = {}) const {
        out.addBox(Mat4::fromBasis(axisX, axisY, axisZ, centre), half, c0, c1, m);
    }
    // Round limb segment; the open ends are hidden by joint balls.
    void tube(const Vec3& a, const Vec3& b, float rA, float rB, Rgba8 cA, Rgba8 cB, const Vec3& hint) const {
        kit::addTube(out, a, b, rA, rB, 8, cA, cB, Material{}, false, false, hint);
    }
    void ball(const Vec3& c, float radius, Rgba8 col) const {
        kit::addEllipsoid(out, Mat4::translation(c), Vec3(radius, radius, radius), 1, col, col);
    }
    void blob(const Vec3& c, const Vec3& ax, const Vec3& ay, const Vec3& az, const Vec3& radii, Rgba8 lo, Rgba8 hi, int subdiv = 1) const {
        kit::addEllipsoid(out, Mat4::fromBasis(ax, ay, az, c), radii, subdiv, lo, hi);
    }
};

Vec3 solveJoint(const Vec3& root, const Vec3& target, float l1, float l2, const Vec3& pole, Vec3& endOut) {
    const Vec3 d = target - root;
    float dist = length(d);
    const float maxD = (l1 + l2) * 0.998f, minD = std::fabs(l1 - l2) * 1.002f + 0.01f;
    dist = clampf(dist, minD, maxD);
    const Vec3 dir = dist > 1e-5f ? normalize(d) : Vec3(0.0f, -1.0f, 0.0f);
    endOut = root + dir * dist;
    const float a = (l1 * l1 - l2 * l2 + dist * dist) / (2.0f * dist);
    const float h = std::sqrt(std::max(0.0f, l1 * l1 - a * a));
    Vec3 pv = pole - dir * dot(pole, dir);
    if (dot(pv, pv) < 1e-6f) pv = Vec3(0.0f, 0.0f, 1.0f) - dir * dot(Vec3(0.0f, 0.0f, 1.0f), dir);
    return root + dir * a + normalize(pv) * h;
}

// ---- the longboard (a rigid mesh built once per style and re-posed with a matrix) --------------------------------------
float deckHalfWidth(float z) {
    static const float zs[] = {-0.56f, -0.52f, -0.44f, -0.34f, -0.18f, 0.0f, 0.18f, 0.34f, 0.44f, 0.52f, 0.56f};
    static const float ws[] = {0.040f, 0.075f, 0.112f, 0.128f, 0.133f, 0.134f, 0.133f, 0.128f, 0.112f, 0.075f, 0.040f};
    const float az = std::fabs(z);
    for (int i = 5; i < 10; ++i) {
        if (az <= zs[i + 1]) return lerpf(ws[i], ws[i + 1], (az - zs[i]) / (zs[i + 1] - zs[i]));
    }
    return ws[10];
}

float deckKick(float z) {
    const float k = saturate((std::fabs(z) - 0.30f) / 0.26f);
    return 0.064f * k * k;
}

MeshData makeBoard(const RiderStyle& st) {
    MeshData m;
    const Rgba8 deckLo = shade(st.deck, 0.72f);
    // deck: a pintail-style outline with kicked nose and tail
    std::vector<kit::Ring> rings;
    const int n = 17;
    for (int i = 0; i < n; ++i) {
        const float z = -0.56f + 1.12f * static_cast<float>(i) / static_cast<float>(n - 1);
        const float y0 = 0.108f + deckKick(z), w = deckHalfWidth(z);
        rings.push_back(kit::roundedSection(z, y0 - 0.014f, y0 + 0.014f, w, w, 0.013f, 0.013f, 2));
    }
    kit::addLoft(m, Mat4::identity(), rings, [&](const Vec3& p, const Vec3& nrm, Material&) {
        if (nrm.y > 0.55f && std::fabs(p.x) < deckHalfWidth(p.z) - 0.016f) return kGrip;      // grip tape, inset from the edge
        return mix(deckLo, st.deck, saturate(nrm.y * 0.5f + 0.5f));
    }, Material{});
    m.addBox(Mat4::translation(Vec3(0.0f, 0.1235f, 0.0f)), Vec3(0.0085f, 0.0012f, 0.31f), st.accent, st.accent);   // centre stripe on the grip

    const Material glow{0, 170, 0, 0}, glowCore{0, 220, 0, 0};
    for (int i = 0; i < 2; ++i) {
        const float z = i == 0 ? 0.31f : -0.31f;
        m.addBox(Mat4::translation(Vec3(0.0f, 0.087f, z)), Vec3(0.050f, 0.009f, 0.066f), shade(kTruck, 0.55f), shade(kTruck, 0.75f));   // baseplate
        m.addBox(Mat4::translation(Vec3(0.0f, 0.066f, z)), Vec3(0.070f, 0.019f, 0.030f), shade(kTruck, 0.85f), kTruck);                    // hanger
        kit::addTube(m, Vec3(-0.168f, 0.050f, z), Vec3(0.168f, 0.050f, z), 0.0085f, 0.0085f, 6, shade(kTruck, 0.5f), shade(kTruck, 0.5f), Material{}, true, true);   // axle
        m.addFrustum(Mat4::translation(Vec3(0.0f, 0.073f, z)), 0.021f, 0.018f, 0.020f, 8, st.accent, st.accent, Material{}, 0.0f, true, true);   // bushing
        for (int side = -1; side <= 1; side += 2) {
            const float s = static_cast<float>(side);
            const Vec3 ax(s, 0.0f, 0.0f), fw(0.0f, 0.0f, 1.0f);
            const Vec3 third = cross(fw, ax);
            const float x = s * 0.146f, w = 0.050f, rad = 0.050f;
            m.addFrustum(Mat4::fromBasis(fw, ax, third, Vec3(x - s * w * 0.5f, rad, z)), rad, rad, w, 10, st.wheel, st.wheel, glow, 0.0f, true, true);
            m.addFrustum(Mat4::fromBasis(fw, ax, third, Vec3(x + s * (w * 0.5f - 0.003f), rad, z)), 0.027f, 0.027f, 0.006f, 8,
                         rgba(1.0f, 1.0f, 1.0f), rgba(1.0f, 1.0f, 1.0f), glowCore, 0.0f, true, true);
        }
    }
    return m;
}

const MeshData& boardMesh(const RiderStyle& st) {
    static const struct Boards {
        MeshData m[kRiderStyleCount];
        Boards() { for (int i = 0; i < kRiderStyleCount; ++i) m[i] = makeBoard(kStyles[i]); }
    } boards;
    const long idx = &st - kStyles;
    if (idx >= 0 && idx < kRiderStyleCount) return boards.m[idx];
    static thread_local MeshData custom;
    custom = makeBoard(st);
    return custom;
}

void buildBoard(const Rig& g, float spin, const Vec3& offset, float hop) {
    // Optionally detached board (crash): rotate its basis around the up vector by `spin`.
    const Vec3 o = g.o + offset + g.u * hop;
    const Vec3 f = rotateAround(g.f, g.u, spin), r = rotateAround(g.r, g.u, spin);
    g.out.append(boardMesh(g.st), Mat4::fromBasis(r, g.u, f, o));
}

// ---- body parts -------------------------------------------------------------------------------------------------------
void drawLeg(const Rig& g, const Vec3& hip, const Vec3& knee, const Vec3& ankle, const Vec3& pole) {
    const RiderStyle& st = g.st;
    const Rgba8 lo = shade(st.pants, 0.80f);
    g.tube(hip, knee, 0.084f, 0.068f, st.pants, st.pants, pole);
    g.tube(knee, ankle, 0.068f, 0.050f, st.pants, lo, pole);
    g.ball(hip, 0.084f, st.pants);
    g.ball(knee, 0.070f, st.pants);
    g.ball(ankle, 0.052f, lo);
    // knee pad on the front of the knee
    const Vec3 axis = normalize(ankle - hip);
    Vec3 kd = pole - axis * dot(pole, axis);
    kd = dot(kd, kd) > 1e-6f ? normalize(kd) : g.f;
    const Vec3 side = normalize(cross(kd, axis));
    g.blob(knee + kd * 0.052f, side, axis, kd, Vec3(0.080f, 0.094f, 0.046f), kPad, shade(kPad, 1.6f), 1);
    g.blob(knee + kd * 0.090f, side, axis, kd, Vec3(0.040f, 0.042f, 0.014f), st.accent, st.accent, 1);
}

// Skate shoe: toes along `dir`, `up` is the shoe's up axis.
void drawShoe(const Rig& g, const Vec3& ankle, const Vec3& dir, const Vec3& up) {
    const Vec3 side = cross(up, dir);
    g.box(ankle - up * 0.030f + dir * 0.050f, side, up, dir, Vec3(0.060f, 0.017f, 0.150f), kSole, kSole);                     // gum sole
    g.blob(ankle + up * 0.018f + dir * 0.045f, side, up, dir, Vec3(0.056f, 0.046f, 0.135f), shade(kShoe, 0.85f), kShoe, 1);     // upper
    g.blob(ankle + up * 0.000f + dir * 0.128f, side, up, dir, Vec3(0.054f, 0.034f, 0.062f), kSole, shade(kSole, 1.1f), 1);      // toe cap
    g.box(ankle + up * 0.060f + dir * 0.062f, side, up, dir, Vec3(0.030f, 0.006f, 0.052f), kLace, kLace);                      // laces
}

// Jacket: a lofted torso from the hips to the collar, with an accent band and a reflective stripe that wrap around it, and a hood.
void drawTorso(const Rig& g, const Vec3& base, const Vec3& up, const Vec3& facing) {
    const RiderStyle& st = g.st;
    const Vec3 fw = normalize(facing - up * dot(facing, up));
    const Vec3 lat = normalize(cross(fw, up));
    const Mat4 xf = Mat4::fromBasis(lat, fw, up, base);   // loft space: x across the chest, y front/back, z up the spine
    struct Key { float z, w, d; };
    static const Key keys[] = {{0.00f, 0.165f, 0.105f}, {0.15f, 0.155f, 0.100f}, {0.31f, 0.190f, 0.115f}, {0.46f, 0.212f, 0.108f}, {0.545f, 0.100f, 0.080f}};
    auto profile = [&](float z, float& w, float& d) {
        for (int i = 0; i < 4; ++i) {
            if (z <= keys[i + 1].z) {
                const float t = (z - keys[i].z) / (keys[i + 1].z - keys[i].z);
                w = lerpf(keys[i].w, keys[i + 1].w, t);
                d = lerpf(keys[i].d, keys[i + 1].d, t);
                return;
            }
        }
        w = keys[4].w;
        d = keys[4].d;
    };
    // extra rings at the edges of the stripes keep their colour boundaries crisp
    static const float zs[] = {0.0f, 0.15f, 0.26f, 0.275f, 0.335f, 0.35f, 0.355f, 0.375f, 0.39f, 0.46f, 0.52f, 0.545f};
    std::vector<kit::Ring> rings;
    for (float z : zs) {
        float w, d;
        profile(z, w, d);
        const float r = std::min(w, d) * 0.85f;
        rings.push_back(kit::roundedSection(z, -d, d, w, w, r, r, 2));
    }
    kit::addLoft(g.out, xf, rings, [&](const Vec3& p, const Vec3&, Material&) -> Rgba8 {
        if (p.z > 0.27f && p.z < 0.34f) return st.accent;
        if (p.z > 0.35f && p.z < 0.38f) return kReflective;
        if (p.z > 0.50f) return shade(st.jacket, 0.80f);   // collar
        return mix(st.jacket, st.jacketHi, saturate(p.z / 0.46f));
    }, Material{});
    g.blob(base + up * 0.50f - fw * 0.075f, lat, up, fw, Vec3(0.120f, 0.075f, 0.085f), st.jacket, st.jacketHi);   // hood bunched at the neck
}

// Full-face downhill helmet: rounded shell, racing stripe, chin bar, dark visor, rear spoiler.
void drawHelmet(const Rig& g, const Vec3& c, const Vec3& hr, const Vec3& u, const Vec3& hf) {
    const RiderStyle& st = g.st;
    const Rgba8 shellLo = shade(st.helmet, 0.74f), shellHi = st.helmet;
    g.blob(c + u * 0.010f, hr, u, hf, Vec3(0.154f, 0.150f, 0.170f), shellLo, shellHi, 2);                                  // shell
    g.blob(c + u * 0.014f, hr, u, hf, Vec3(0.022f, 0.156f, 0.176f), st.accent, st.accent, 1);                              // racing stripe
    g.blob(c - u * 0.080f + hf * 0.100f, hr, u, hf, Vec3(0.108f, 0.062f, 0.088f), shade(shellHi, 0.88f), shellHi, 1);      // chin bar
    g.blob(c + u * 0.012f + hf * 0.118f, hr, u, hf, Vec3(0.120f, 0.050f, 0.062f), kVisorLo, kVisorHi, 1);                  // visor
    g.box(c - u * 0.082f + hf * 0.182f, hr, u, hf, Vec3(0.040f, 0.012f, 0.012f), kLace, kLace);                            // mouth vent
    g.box(c - hf * 0.158f + u * 0.056f, hr, u, hf, Vec3(0.042f, 0.010f, 0.028f), shade(st.helmet, 0.55f), shade(st.helmet, 0.45f));   // rear spoiler
    for (int s = -1; s <= 1; s += 2)                                                                                      // ear pads
        g.blob(c + hr * (0.152f * static_cast<float>(s)) - u * 0.012f, hr, u, hf, Vec3(0.022f, 0.052f, 0.056f), kLace, kLace, 1);
}

// Sleeve, cuff and slide glove with a puck on the palm; `palmDir` is where the palm faces.
void drawArm(const Rig& g, const Vec3& sh, const Vec3& elbow, const Vec3& hand, const Vec3& palmDir, const Vec3& hint) {
    const RiderStyle& st = g.st;
    g.tube(sh, elbow, 0.064f, 0.054f, st.jacketHi, st.sleeve, hint);
    g.tube(elbow, hand, 0.054f, 0.046f, st.sleeve, st.sleeve, hint);
    g.ball(sh, 0.068f, st.jacketHi);
    g.ball(elbow, 0.056f, st.sleeve);
    const Vec3 fd = normalize(hand - elbow);
    g.tube(hand - fd * 0.085f, hand - fd * 0.050f, 0.050f, 0.050f, st.accent, st.accent, hint);   // cuff
    Vec3 pd = palmDir - fd * dot(palmDir, fd);
    pd = dot(pd, pd) > 1e-6f ? normalize(pd) : -g.u;
    const Vec3 ax = normalize(cross(pd, fd));
    const Vec3 c = hand + fd * 0.040f;
    g.blob(c, ax, fd, pd, Vec3(0.050f, 0.062f, 0.036f), kGlove, shade(kGlove, 1.5f), 1);
    kit::addTube(g.out, c + pd * 0.030f, c + pd * 0.047f, 0.037f, 0.034f, 8, st.accent, st.accent, Material{}, true, true, fd);   // slide puck
}

// Rider on the board. Three poses are blended by weight:
//   riding stance (stand <-> tuck), kick-push (foot plants, drives back, swings forward) and Coleman slide
//   (board kicked out sideways, deep crouch, inside hand on the road, free arm out for balance).
void buildStanding(const Rig& g, const SkaterPose& p) {
    const float t = p.tuck;
    const float L = p.lean;
    const float sd = p.slideDir;
    const float pw = saturate(p.push);
    const float cw = saturate(p.slide) * (1.0f - pw);
    const Vec3 roadUp = normalize(p.roadUp);
    auto mixv = [](const Vec3& a, const Vec3& b, float k) { return a + (b - a) * k; };
    // point `pt` moved along the road normal so that it sits `h` above the road surface
    auto onRoad = [&](const Vec3& pt, float h) { return pt - roadUp * (dot(pt - g.o, roadUp) - h); };

    // axes aligned with the travel direction: the rider keeps looking where the road goes while the board kicks out
    const float cs = std::cos(p.slip), sn = std::sin(p.slip);
    const Vec3 fT = g.f * cs - g.r * sn;
    const Vec3 rT = g.r * cs + g.f * sn;

    // ---- riding stance
    Vec3 ankleL = g.W(0.0f, 0.15f, 0.20f);    // left leg = front foot
    Vec3 ankleR = g.W(0.0f, 0.15f, -0.20f);   // right leg = back (kicking) foot
    const float hipY = lerpf(0.78f, 0.48f, t);
    Vec3 hip = g.W(L * 0.10f, hipY, lerpf(0.0f, -0.03f, t));
    const float twist = lerpf(0.40f, 0.95f, t);
    Vec3 facing = normalize(g.r * std::cos(twist) + g.f * std::sin(twist));
    const float pitchT = lerpf(0.12f, 1.02f, t);
    Vec3 td = normalize(g.u * std::cos(pitchT) + facing * std::sin(pitchT) + g.r * (L * 0.30f));
    float toeL = 0.0f, toeR = 0.0f;           // shoe yaw: 0 = across the board, pi/2 = pointing at the nose
    Vec3 headFace = g.f;
    float armSwing = 0.0f;                    // kick-push arm swing, +1 = left arm forward

    // ---- kick-push
    if (pw > 0.001f) {
        const float N = static_cast<float>(cfg::kPushStrokes);
        const float cyc = std::min(p.pushPhase, N);
        const float u = cyc - std::floor(cyc);
        const float c = cfg::kPushContact;
        float fx, fy, fz, kp;   // kicking foot (board space x right / z forward, height above the road) and kick progress 0..1
        if (u < c) {            // drive: the foot is on the road and slides back past the board
            const float s = u / c;
            fz = lerpf(0.10f, -0.50f, s);
            fx = lerpf(0.34f, 0.25f, s);
            fy = lerpf(0.050f, 0.090f, s * s);   // heel comes up at the end of the drive
            kp = s;
        } else {                // recovery: lift the foot and swing it forward to the next plant
            const float s = (u - c) / (1.0f - c);
            const float e = s * s * (3.0f - 2.0f * s);
            fz = lerpf(-0.50f, 0.10f, e);
            fx = lerpf(0.25f, 0.34f, e) + 0.03f * std::sin(kPi * s);
            fy = lerpf(0.090f, 0.050f, s) + 0.17f * std::sin(kPi * s);
            kp = 1.0f - e;
        }
        Vec3 kick = onRoad(g.o + g.r * fx + g.f * fz, fy);
        // the last recovery brings the foot back onto the deck instead of planting again
        const float landing = smoothstep(N - 0.55f, N, cyc);
        kick = mixv(kick, g.W(0.0f, 0.15f, -0.20f), landing);
        const float lunge = kp * (1.0f - landing);

        const Vec3 hipP = g.W(0.08f, 0.64f - 0.03f * lunge, lerpf(-0.04f, 0.05f, lunge));
        const Vec3 facingP = normalize(g.r * std::cos(1.0f) + g.f * std::sin(1.0f));
        const float pitchP = 0.36f + 0.12f * lunge;
        const Vec3 tdP = normalize(g.u * std::cos(pitchP) + facingP * std::sin(pitchP));
        ankleR = mixv(ankleR, kick, pw);
        hip = mixv(hip, hipP, pw);
        facing = normalize(mixv(facing, facingP, pw));
        td = normalize(mixv(td, tdP, pw));
        toeL = lerpf(toeL, 0.95f, pw);
        toeR = lerpf(toeR, lerpf(1.30f, 0.0f, landing), pw);
        armSwing = (lunge * 2.0f - 1.0f) * (1.0f - landing) * pw;
    }

    // ---- Coleman slide
    if (cw > 0.001f) {
        const float mag = saturate((std::fabs(p.slip) - 0.80f) / 0.5f);
        const Vec3 hipC = g.o + g.u * 0.38f - g.f * 0.10f + rT * (sd * 0.04f);
        const Vec3 facingC = normalize(fT * 0.85f + rT * (sd * 0.55f));
        const float phi = lerpf(0.85f, 1.10f, mag);
        const Vec3 leanDir = normalize(rT * (sd * 0.9f) + fT * 0.35f);
        const Vec3 tdC = normalize(g.u * std::cos(phi) + leanDir * std::sin(phi));
        // each foot stays on its own side of the board so the legs never cross
        const Vec3 aF = g.W(0.0f, 0.15f, 0.22f), aB = g.W(0.0f, 0.15f, -0.22f);
        const bool frontOnLeft = dot(aF - aB, rT) < 0.0f;
        ankleL = mixv(ankleL, frontOnLeft ? aF : aB, cw);
        ankleR = mixv(ankleR, frontOnLeft ? aB : aF, cw);
        hip = mixv(hip, hipC, cw);
        facing = normalize(mixv(facing, facingC, cw));
        td = normalize(mixv(td, tdC, cw));
        headFace = normalize(mixv(headFace, normalize(fT + rT * (sd * 0.40f)), cw));
    }

    const Vec3 left = normalize(cross(g.u, facing));     // rider's left
    const Vec3 neck = hip + td * 0.50f;

    // ---- legs
    const Vec3 hipL = hip + left * 0.085f, hipR = hip - left * 0.085f;
    Vec3 endL, endR;
    // knees point along the board when riding (unchanged), and along the chest direction while kicking / sliding
    Vec3 poleL = normalize(g.r * 1.0f + g.u * 0.15f + g.f * 0.1f);
    Vec3 poleR = normalize(g.r * 1.0f + g.u * 0.15f - g.f * 0.1f);
    const float wMode = std::max(pw, cw);
    if (wMode > 0.001f) {
        poleL = normalize(mixv(poleL, normalize(facing + g.u * 0.15f + left * 0.10f), wMode));
        poleR = normalize(mixv(poleR, normalize(facing + g.u * 0.15f - left * 0.10f), wMode));
    }
    const Vec3 kneeL = solveJoint(hipL, ankleL, 0.38f, 0.38f, poleL, endL);
    const Vec3 kneeR = solveJoint(hipR, ankleR, 0.38f, 0.38f, poleR, endR);
    drawLeg(g, hipL, kneeL, endL, poleL);
    drawLeg(g, hipR, kneeR, endR, poleR);
    // shoes: toes along `dir` (yaw measured from "across the board" toward the nose)
    for (int i = 0; i < 2; ++i) {
        const Vec3 a = i == 0 ? endL : endR;
        const float yaw = i == 0 ? toeL : toeR;
        const Vec3 dir = normalize(g.r * std::cos(yaw) + g.f * std::sin(yaw));
        drawShoe(g, a, dir, g.u);
    }

    // ---- pelvis + jacket
    const Basis pb = basisFromY(normalize(g.u * 1.0f + td * 0.25f), facing);
    g.blob(hip + g.u * 0.02f, pb.x, pb.y, pb.z, Vec3(0.178f, 0.105f, 0.112f), g.st.pants, g.st.jacket);
    drawTorso(g, hip, td, facing);

    // ---- head + helmet (looks along the board, or along the road while sliding)
    const Vec3 headUp = normalize(td + g.u * (1.2f * cw));
    const Vec3 headC = neck + headUp * 0.17f + g.u * 0.03f;
    const Vec3 hf = normalize(headFace - g.u * dot(headFace, g.u));
    const Vec3 hr = cross(hf, g.u);
    g.tube(neck - td * 0.02f, headC - g.u * 0.08f, 0.056f, 0.052f, shade(g.st.jacket, 0.8f), shade(g.st.jacket, 0.6f), hf);
    drawHelmet(g, headC, hr, g.u, hf);

    // ---- arms: relaxed -> hands behind the back (tuck) -> swinging (kick-push) -> inside hand on the road (Coleman)
    const Vec3 shL = neck + left * 0.235f - td * 0.04f, shR = neck - left * 0.235f - td * 0.04f;
    auto handFor = [&](int side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        const float sway = std::sin(p.time * 2.3f + sgn) * 0.04f;
        Vec3 relaxed = sh + left * (sgn * 0.17f) - td * 0.46f + facing * 0.12f + g.r * (L * 0.2f) + g.u * sway;
        // balance arms swing wide when carving
        relaxed += left * (sgn * 0.10f * std::fabs(L) * 2.0f);
        const Vec3 back = hip - facing * 0.17f + left * (sgn * 0.16f) + g.u * 0.06f;
        Vec3 h = relaxed + (back - relaxed) * t;
        if (pw > 0.001f) {
            const float swing = side == 0 ? armSwing : -armSwing;   // opposite arm to the kicking leg swings forward
            h += g.f * (swing * 0.34f) + g.u * (0.10f * pw);
        }
        if (cw > 0.001f) {
            const bool inside = dot(sh - neck, rT * sd) > 0.0f;    // the shoulder on the side we slide toward
            Vec3 target;
            if (inside) {
                // hand flat on the road under the shoulder, as far out as the arm reaches
                const float drop = dot(sh - g.o, roadUp) - 0.05f;
                const float reach = 0.56f;
                const float horiz = std::sqrt(std::max(0.0f, reach * reach - drop * drop));
                const Vec3 outDir = normalize(rT * (sd * 0.85f) - fT * 0.30f);
                target = onRoad(sh + outDir * horiz, 0.05f);
            } else {
                // free arm thrown out behind and up for balance
                target = sh + rT * (-sd * 0.55f) + g.u * 0.12f - fT * 0.30f;
            }
            h += (target - h) * cw;
        }
        return h;
    };
    for (int side = 0; side < 2; ++side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        Vec3 hand = handFor(side), end;
        const Vec3 pole = normalize(-td * 0.4f - facing * 0.4f + left * (sgn * 0.5f) - g.u * 0.3f);
        const Vec3 elbow = solveJoint(sh, hand, 0.30f, 0.29f, pole, end);
        // palms face the body when relaxed and the road when a hand is down for the slide
        const Vec3 inward = normalize(hip + td * 0.28f - end);
        const Vec3 palm = normalize(mixv(inward, -roadUp, cw));
        drawArm(g, sh, elbow, end, palm, facing);
    }
}

void buildCrashed(const Rig& g, const SkaterPose& p) {
    const float t = p.crashTime;
    const float u1 = saturate(t / 1.4f);
    const float ease = 1.0f - (1.0f - u1) * (1.0f - u1);
    const float phi = ease * (kPi * 0.5f + kTwoPi);            // somersault then land on the back
    const float hopT = saturate(t / 0.95f);
    const float hop = 1.0f * std::sin(hopT * kPi) * (1.0f - u1 * 0.6f);
    const float restY = 0.20f;

    // board flies ahead and spins
    const float ahead = p.crashSpeed * 0.55f * (1.0f - std::exp(-1.4f * t)) / 1.4f;
    buildBoard(g, 7.0f * (1.0f - std::exp(-1.4f * t)), g.f * ahead + g.r * (0.7f * (1.0f - std::exp(-2.0f * t))),
               0.35f * std::sin(saturate(t / 0.8f) * kPi));

    // limp rider rotating around the board-right axis
    const Vec3 axis = g.r;
    auto R = [&](const Vec3& v) { return rotateAround(v, axis, phi); };
    const Vec3 pivot = g.o + g.u * (restY + hop) - g.f * 0.1f;
    const float splay = 0.5f + 0.5f * saturate(t / 0.8f);
    const Vec3 up = R(g.u), fw = R(g.f), rt = g.r;
    auto P = [&](float x, float y, float z) { return pivot + rt * x + up * y + fw * z; };
    const RiderStyle& st = g.st;

    // pelvis, jacket, neck, helmet
    const Vec3 hip = P(0.0f, 0.02f, 0.0f);
    g.blob(hip, rt, up, fw, Vec3(0.178f, 0.105f, 0.112f), st.pants, st.jacket);
    drawTorso(g, hip, up, fw);
    g.tube(P(0.0f, 0.55f, 0.0f), P(0.0f, 0.66f, 0.01f), 0.056f, 0.052f, shade(st.jacket, 0.8f), shade(st.jacket, 0.6f), fw);
    drawHelmet(g, P(0.0f, 0.73f, 0.02f), rt, up, fw);
    // legs and arms (rigid, splayed)
    for (int s = -1; s <= 1; s += 2) {
        const float sg = static_cast<float>(s);
        const Vec3 knee = P(0.16f * sg * splay, -0.42f, 0.05f * sg), ankle = P(0.27f * sg * splay, -0.84f, 0.02f);
        drawLeg(g, P(0.09f * sg, 0.0f, 0.0f), knee, ankle, fw + rt * (0.2f * sg));
        drawShoe(g, ankle, normalize(fw + rt * (0.5f * sg)), up);
        drawArm(g, P(0.24f * sg, 0.50f, 0.0f), P(0.50f * sg * splay, 0.36f, -0.05f * sg), P(0.76f * sg * splay, 0.22f, -0.12f * sg), -up, fw);
    }
}

}  // namespace

const RiderStyle& riderStyle(int index) {
    const int n = kRiderStyleCount;
    return kStyles[((index % n) + n) % n];
}

void buildSkaterMesh(const SkaterPose& pose, MeshData& out, const RiderStyle& style) {
    // Build at natural size, then scale up around the board so the rider reads well on a phone screen.
    constexpr float kRiderScale = 1.2f;
    MeshData tmp;
    Rig g{pose, tmp, pose.origin, pose.right, pose.up, pose.fwd, style};
    if (pose.crashed) {
        buildCrashed(g, pose);
    } else {
        buildBoard(g, 0.0f, Vec3(), 0.0f);
        buildStanding(g, pose);
    }
    const Mat4 xf = Mat4::translation(pose.origin) * Mat4::scaling(Vec3(kRiderScale, kRiderScale, kRiderScale)) *
                    Mat4::translation(-pose.origin);
    out.append(tmp, xf);
}

}  // namespace sd
