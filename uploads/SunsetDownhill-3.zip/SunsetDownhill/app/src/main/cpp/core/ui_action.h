// ui_action.h - what a tap on the HUD / menus asks the engine to do.
#pragma once

namespace sd {

enum class UiAction {
    None, Start, Pause, Resume, Menu, Retry, ToggleSound, OpenControls,
    // LAN multiplayer
    OpenLobby, LobbyHost, LobbySearch, LobbyJoin, LobbyStart, LobbyLeave, LobbyBack
};

}  // namespace sd
