// engine.h - the single object the platform shell talks to.
// Owns the game simulation, input, HUD and renderer and runs one frame at a time.
#pragma once

#include <atomic>
#include <chrono>
#include <string>
#include <vector>

#include "controls.h"
#include "game.h"
#include "hud.h"
#include "net.h"
#include "renderer.h"
#include "scene_builder.h"
#include "ui_batch.h"

namespace sd {

class Engine {
public:
    explicit Engine(const NetConfig& netConfig = NetConfig());

    // ---- configuration (before the first frame)
    void setSettings(int bestScore, bool soundOn);
    void setControls(const std::string& text);   // the string from controlsString(); empty / unreadable = factory layout
    void setPlayerName(const std::string& name) { playerName_ = name; }   // shown to the others in a LAN race (the device name)

    // ---- GL thread
    void onSurfaceCreated();
    void onSurfaceChanged(int width, int height);
    void onDrawFrame();                 // uses the wall clock
    void stepFrame(float dt);           // explicit time step (tests)
    void onTouch(int action, int pointerId, float x, float y);

    // ---- any thread
    void requestPause() { pauseRequested_.store(true); }
    bool requestBack();                 // true if the press was consumed by the game
    int bestScore() const { return best_.load(); }
    bool soundEnabled() const { return soundOn_.load(); }
    // Phone tilt: the direction of "up" in the screen plane (see TiltSteer::setGravity) and whether there is a sensor.
    void setTilt(float x, float y) { controls_.setTiltGravity(x, y); }
    void setTiltAvailable(bool available) { controls_.setTiltAvailable(available); }
    // Counts up whenever something worth saving changed (best score, sound, controls): the shell polls this one number.
    int settingsRevision() const { return settingsRev_.load(); }
    // Read it from the GL thread, right after a frame, when settingsRevision() has moved.
    std::string controlsString() const { return controls_.config().serialize(); }

    Game& game() { return game_; }
    Renderer& renderer() { return renderer_; }
    Controls& controls() { return controls_; }
    LanSession& net() { return net_; }
    HudModel hudModel() const { return makeHudModel(); }                 // what the HUD is drawing (tests, tools)
    const std::vector<RemoteRider>& remoteRiders() const { return remotes_; }

private:
    enum class MpScreen { Off, Lobby };   // Lobby: the multiplayer screens are open over the menu

    void applyAction(UiAction action, int index = 0);
    HudModel makeHudModel() const;
    void fillMultiplayer(HudModel& m) const;
    void beginLanRace(uint32_t seed);
    void updateMultiplayer(float dt);
    void updateQuality(float dt);
    void updateAudio(const GameEvents& ev);
    void markSettingsChanged() { settingsRev_.fetch_add(1); }

    Game game_;
    Controls controls_;
    LanSession net_;
    std::string playerName_ = "RIDER";
    MpScreen mpScreen_ = MpScreen::Off;
    bool mpRace_ = false;                  // the current run is a LAN race
    std::string mpStatus_;                 // message shown on the lobby screens
    std::string mpAddress_;                // this phone's Wi-Fi address (refreshed once a second)
    float mpAddrTimer_ = 0.0f;
    std::vector<RemoteRider> remotes_;
    std::atomic<bool> mpOpen_{false};      // lobby open or LAN race running (for the Back button, any thread)
    Renderer renderer_;
    SceneGeometry geo_;
    UiBatch ui_;

    std::atomic<int> best_{0};
    std::atomic<bool> soundOn_{true};
    std::atomic<bool> pauseRequested_{false};
    std::atomic<bool> backRequested_{false};
    std::atomic<int> phase_{0};
    std::atomic<bool> editorOpen_{false};
    std::atomic<int> settingsRev_{0};

    std::chrono::steady_clock::time_point last_;
    bool haveLast_ = false;
    int width_ = 0, height_ = 0;

    // adaptive quality
    float govTimer_ = 0.0f, govFrameTime_ = 0.0f;
    int govFrames_ = 0;
    float warmup_ = 4.0f, stableTime_ = 0.0f, raiseLockout_ = 0.0f, sinceRaise_ = 999.0f;
    bool noRaise_ = false;   // set when a quality increase immediately proved too heavy
};

}  // namespace sd
