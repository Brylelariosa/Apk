#include "renderer.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <vector>

#include "config.h"
#include "log.h"
#include "mesh_library.h"
#include "shaders.h"
#include "ui_font.h"

namespace sd {

namespace {

const QualitySettings kPresets[kQualityTiers] = {
    {0.55f, 0, 0.45f, false, 4},
    {0.70f, 512, 0.70f, false, 6},
    {0.85f, 1024, 1.00f, true, 8},
    {1.00f, 1024, 1.00f, true, 8},
};

constexpr float kShadowExtent = 44.0f;
constexpr float kNearZ = 0.25f;
constexpr float kFarZ = 700.0f;

void* off(size_t bytes) { return reinterpret_cast<void*>(bytes); }

}  // namespace

const QualitySettings& qualityPreset(int tier) {
    return kPresets[std::max(0, std::min(tier, kQualityTiers - 1))];
}

// --------------------------------------------------------------------------------------
// Setup
// --------------------------------------------------------------------------------------

void Renderer::forgetAll() {
    sky_.forget(); terrain_.forget(); mesh_.forget(); shadowProg_.forget();
    particle_.forget(); post_.forget(); ui_.forget();
    for (GpuMesh& m : batches_) m = GpuMesh();
    terrainVao_ = terrainVbo_ = terrainIbo_ = 0;
    dynVao_ = dynVbo_ = dynIbo_ = 0;
    quadVbo_ = smokeVao_ = smokeVbo_ = sparkVao_ = sparkVbo_ = 0;
    uiVao_ = uiVbo_ = uiAtlasTex_ = emptyVao_ = dummyDepthTex_ = 0;
    forgetTarget(scene_);
    forgetShadowTarget(shadow_);
    terrainIndexCount_ = terrainVertexCount_ = dynIndexCount_ = smokeCount_ = sparkCount_ = uiCount_ = 0;
    for (GLsizei& c : instanceCount_) c = 0;
    direct_ = false;
    ready_ = false;
}

bool Renderer::buildPrograms() {
    bool ok = true;
    ok &= sky_.build("sky", shaders::skyVertex().c_str(), shaders::skyFragment().c_str());
    ok &= terrain_.build("terrain", shaders::terrainVertex().c_str(), shaders::terrainFragment().c_str());
    ok &= mesh_.build("mesh", shaders::meshVertex().c_str(), shaders::meshFragment().c_str());
    ok &= shadowProg_.build("shadow", shaders::shadowVertex().c_str(), shaders::shadowFragment().c_str());
    ok &= particle_.build("particle", shaders::particleVertex().c_str(), shaders::particleFragment().c_str());
    ok &= post_.build("post", shaders::postVertex().c_str(), shaders::postFragment().c_str());
    ok &= ui_.build("ui", shaders::uiVertex().c_str(), shaders::uiFragment().c_str());
    return ok;
}

void Renderer::setupMeshAttribs(GLuint vao, GLuint vbo, GLuint ibo, GLuint instanceVbo) {
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(MeshVertex), off(offsetof(MeshVertex, px)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(MeshVertex), off(offsetof(MeshVertex, nx)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(MeshVertex), off(offsetof(MeshVertex, r)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(MeshVertex), off(offsetof(MeshVertex, tint)));
    if (instanceVbo) {
        glBindBuffer(GL_ARRAY_BUFFER, instanceVbo);
        glEnableVertexAttribArray(4);
        glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, sizeof(Instance), off(offsetof(Instance, x)));
        glVertexAttribDivisor(4, 1);
        glEnableVertexAttribArray(5);
        glVertexAttribPointer(5, 4, GL_FLOAT, GL_FALSE, sizeof(Instance), off(offsetof(Instance, sx)));
        glVertexAttribDivisor(5, 1);
        glEnableVertexAttribArray(6);
        glVertexAttribPointer(6, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Instance), off(offsetof(Instance, r)));
        glVertexAttribDivisor(6, 1);
    }
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBindVertexArray(0);
}

void Renderer::buildGeometry() {
    // static scenery meshes + instance buffers
    for (int b = 0; b < kBatchCount; ++b) {
        const MeshData mesh = buildBatchMesh(static_cast<Batch>(b));
        GpuMesh& g = batches_[b];
        glGenVertexArrays(1, &g.vao);
        glGenBuffers(1, &g.vbo);
        glGenBuffers(1, &g.ibo);
        glGenBuffers(1, &g.instanceVbo);
        glBindBuffer(GL_ARRAY_BUFFER, g.vbo);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(mesh.vertices.size() * sizeof(MeshVertex)), mesh.vertices.data(), GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(mesh.indices.size() * sizeof(uint16_t)), mesh.indices.data(), GL_STATIC_DRAW);
        g.indexCount = static_cast<GLsizei>(mesh.indices.size());
        glBindBuffer(GL_ARRAY_BUFFER, g.instanceVbo);
        glBufferData(GL_ARRAY_BUFFER, 4096, nullptr, GL_STREAM_DRAW);
        setupMeshAttribs(g.vao, g.vbo, g.ibo, g.instanceVbo);
    }

    // terrain: dynamic vertices, static index buffer
    constexpr int cols = cfg::kTerrainCols, rings = cfg::kTerrainRings;
    std::vector<uint16_t> idx;
    idx.reserve(static_cast<size_t>(rings - 1) * (cols - 1) * 6);
    for (int r = 0; r < rings - 1; ++r) {
        for (int c = 0; c < cols - 1; ++c) {
            const uint16_t a = static_cast<uint16_t>(r * cols + c), b = static_cast<uint16_t>(r * cols + c + 1);
            const uint16_t d = static_cast<uint16_t>((r + 1) * cols + c), e = static_cast<uint16_t>((r + 1) * cols + c + 1);
            idx.push_back(a); idx.push_back(b); idx.push_back(d);
            idx.push_back(b); idx.push_back(e); idx.push_back(d);
        }
    }
    terrainIndexCount_ = static_cast<GLsizei>(idx.size());
    terrainVertexCount_ = rings * cols;
    glGenVertexArrays(1, &terrainVao_);
    glGenBuffers(1, &terrainVbo_);
    glGenBuffers(1, &terrainIbo_);
    glBindVertexArray(terrainVao_);
    glBindBuffer(GL_ARRAY_BUFFER, terrainVbo_);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(sizeof(TerrainVertex)) * terrainVertexCount_, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(TerrainVertex), off(offsetof(TerrainVertex, px)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(TerrainVertex), off(offsetof(TerrainVertex, nx)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(TerrainVertex), off(offsetof(TerrainVertex, d)));
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, terrainIbo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(idx.size() * sizeof(uint16_t)), idx.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);

    // dynamic mesh (rider, start gate)
    glGenVertexArrays(1, &dynVao_);
    glGenBuffers(1, &dynVbo_);
    glGenBuffers(1, &dynIbo_);
    glBindBuffer(GL_ARRAY_BUFFER, dynVbo_);
    glBufferData(GL_ARRAY_BUFFER, 4096, nullptr, GL_STREAM_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, dynIbo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, 4096, nullptr, GL_STREAM_DRAW);
    setupMeshAttribs(dynVao_, dynVbo_, dynIbo_, 0);

    // particles
    const float quad[8] = {-1, -1, 1, -1, -1, 1, 1, 1};
    glGenBuffers(1, &quadVbo_);
    glBindBuffer(GL_ARRAY_BUFFER, quadVbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    GLuint* vaos[2] = {&smokeVao_, &sparkVao_};
    GLuint* vbos[2] = {&smokeVbo_, &sparkVbo_};
    for (int i = 0; i < 2; ++i) {
        glGenVertexArrays(1, vaos[i]);
        glGenBuffers(1, vbos[i]);
        glBindVertexArray(*vaos[i]);
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo_);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, off(0));
        glBindBuffer(GL_ARRAY_BUFFER, *vbos[i]);
        glBufferData(GL_ARRAY_BUFFER, 1024, nullptr, GL_STREAM_DRAW);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(ParticleInstance), off(offsetof(ParticleInstance, x)));
        glVertexAttribDivisor(1, 1);
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(ParticleInstance), off(offsetof(ParticleInstance, r)));
        glVertexAttribDivisor(2, 1);
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(ParticleInstance), off(offsetof(ParticleInstance, vx)));
        glVertexAttribDivisor(3, 1);
        glBindVertexArray(0);
    }

    // UI
    glGenVertexArrays(1, &uiVao_);
    glGenBuffers(1, &uiVbo_);
    glBindVertexArray(uiVao_);
    glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
    glBufferData(GL_ARRAY_BUFFER, 4096, nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UiVertex), off(offsetof(UiVertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(UiVertex), off(offsetof(UiVertex, u)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(UiVertex), off(offsetof(UiVertex, r)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 1, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(UiVertex), off(offsetof(UiVertex, halo)));
    glBindVertexArray(0);

    // UI atlas: signed-distance glyphs plus a solid block that plain shapes sample
    glGenTextures(1, &uiAtlasTex_);
    glBindTexture(GL_TEXTURE_2D, uiAtlasTex_);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, kAtlasSize, kAtlasSize, 0, GL_RED, GL_UNSIGNED_BYTE, fontAtlasPixels().data());
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);

    glGenVertexArrays(1, &emptyVao_);

    // 1x1 depth texture so the shadow sampler is always valid
    glGenTextures(1, &dummyDepthTex_);
    glBindTexture(GL_TEXTURE_2D, dummyDepthTex_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, 1, 1, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
}

void Renderer::onContextCreated() {
    forgetAll();
    SD_LOGI("GL: %s | %s", reinterpret_cast<const char*>(glGetString(GL_RENDERER)), reinterpret_cast<const char*>(glGetString(GL_VERSION)));
    if (!buildPrograms()) {
        SD_LOGE("shader build failed; rendering disabled");
        return;
    }
    buildGeometry();
    ready_ = true;
    if (width_ > 0 && height_ > 0) applyQuality();
}

void Renderer::onResize(int width, int height) {
    width_ = std::max(1, width);
    height_ = std::max(1, height);
    if (ready_) applyQuality();
}

void Renderer::setQualityTier(int tier) {
    tier = std::max(0, std::min(tier, kQualityTiers - 1));
    if (tier == tier_) return;
    tier_ = tier;
    if (ready_ && width_ > 0) applyQuality();
}

void Renderer::applyQuality() {
    const QualitySettings& q = qualityPreset(tier_);
    const float longSide = static_cast<float>(std::max(width_, height_));
    const float scale = std::max(0.35f, std::min(q.renderScale, 1920.0f / longSide));
    const int sw = std::max(64, static_cast<int>(static_cast<float>(width_) * scale));
    const int sh = std::max(64, static_cast<int>(static_cast<float>(height_) * scale));
    if (!scene_.valid() || scene_.width != sw || scene_.height != sh) {
        direct_ = !createColorTarget(scene_, sw, sh);
#ifdef SD_TEST_FORCE_DIRECT
        direct_ = true;   // test hook: exercise the "no offscreen target" fallback path
#endif
    }
    if (q.shadowSize > 0) {
        if (!shadow_.valid() || shadow_.size != q.shadowSize) createShadowTarget(shadow_, q.shadowSize);
    }
}

// --------------------------------------------------------------------------------------
// Per-frame
// --------------------------------------------------------------------------------------

void Renderer::uploadFrame(const SceneGeometry& geo, const UiBatch& ui) {
    glBindBuffer(GL_ARRAY_BUFFER, terrainVbo_);
    const GLsizeiptr tbytes = static_cast<GLsizeiptr>(std::min<size_t>(geo.terrain.size(), static_cast<size_t>(terrainVertexCount_)) * sizeof(TerrainVertex));
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(sizeof(TerrainVertex)) * terrainVertexCount_, nullptr, GL_STREAM_DRAW);
    if (tbytes > 0) glBufferSubData(GL_ARRAY_BUFFER, 0, tbytes, geo.terrain.data());

    for (int b = 0; b < kBatchCount; ++b) {
        instanceCount_[b] = static_cast<GLsizei>(geo.instances[b].size());
        if (instanceCount_[b] == 0) continue;
        glBindBuffer(GL_ARRAY_BUFFER, batches_[b].instanceVbo);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(geo.instances[b].size() * sizeof(Instance)), geo.instances[b].data(), GL_STREAM_DRAW);
    }

    dynIndexCount_ = static_cast<GLsizei>(geo.dynamicMesh.indices.size());
    if (dynIndexCount_ > 0) {
        glBindBuffer(GL_ARRAY_BUFFER, dynVbo_);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(geo.dynamicMesh.vertices.size() * sizeof(MeshVertex)), geo.dynamicMesh.vertices.data(), GL_STREAM_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, dynIbo_);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(geo.dynamicMesh.indices.size() * sizeof(uint16_t)), geo.dynamicMesh.indices.data(), GL_STREAM_DRAW);
    }

    smokeCount_ = static_cast<GLsizei>(geo.smoke.size());
    if (smokeCount_ > 0) {
        glBindBuffer(GL_ARRAY_BUFFER, smokeVbo_);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(geo.smoke.size() * sizeof(ParticleInstance)), geo.smoke.data(), GL_STREAM_DRAW);
    }
    sparkCount_ = static_cast<GLsizei>(geo.sparks.size());
    if (sparkCount_ > 0) {
        glBindBuffer(GL_ARRAY_BUFFER, sparkVbo_);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(geo.sparks.size() * sizeof(ParticleInstance)), geo.sparks.data(), GL_STREAM_DRAW);
    }

    uiCount_ = static_cast<GLsizei>(ui.vertexCount());
    if (uiCount_ > 0) {
        glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
        glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(ui.vertexCount() * sizeof(UiVertex)), ui.data(), GL_STREAM_DRAW);
    }
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void Renderer::computeShadow(const FrameParams& fp, Mat4& lightVP, Mat4& shadowMat) const {
    const Vec3 L = fp.atmo.sunDir;
    const Vec3 lf = -L;
    const Vec3 lr = normalize(cross(lf, Vec3(0.0f, 1.0f, 0.0f)));
    const Vec3 lu = cross(lr, lf);
    const float texel = 2.0f * kShadowExtent / static_cast<float>(std::max(1, shadow_.size));
    // snap the focus (absolute coordinates) to the shadow-map texel grid so shadows do not shimmer
    float cu = dot(fp.shadowFocus, lr), cv = dot(fp.shadowFocus, lu);
    const float cd = dot(fp.shadowFocus, lf);
    cu = std::floor(cu / texel) * texel;
    cv = std::floor(cv / texel) * texel;
    const Vec3 centreAbs = lr * cu + lu * cv + lf * cd;
    const Vec3 centre = centreAbs - fp.cam.pos;
    const Vec3 eye = centre + L * 130.0f;
    const Mat4 view = Mat4::lookAt(eye, centre, Vec3(0.0f, 1.0f, 0.0f));
    const Mat4 proj = Mat4::ortho(-kShadowExtent, kShadowExtent, -kShadowExtent, kShadowExtent, 1.0f, 260.0f);
    lightVP = proj * view;
    const Mat4 bias = Mat4::translation(Vec3(0.5f, 0.5f, 0.5f)) * Mat4::scaling(Vec3(0.5f, 0.5f, 0.5f));
    shadowMat = bias * lightVP;
}

void Renderer::drawDynamicMesh() {
    if (dynIndexCount_ <= 0) return;
    glVertexAttrib4f(4, 0.0f, 0.0f, 0.0f, 0.0f);
    glVertexAttrib4f(5, 1.0f, 1.0f, 0.0f, 0.0f);
    glVertexAttrib4f(6, 1.0f, 1.0f, 1.0f, 0.0f);
    glBindVertexArray(dynVao_);
    glDrawElements(GL_TRIANGLES, dynIndexCount_, GL_UNSIGNED_SHORT, nullptr);
}

void Renderer::drawShadowPass(const FrameParams& fp, const Mat4& lightVP, const SceneGeometry&) {
    glBindFramebuffer(GL_FRAMEBUFFER, shadow_.fbo);
    glViewport(0, 0, shadow_.size, shadow_.size);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDepthMask(GL_TRUE);
    glClearDepthf(1.0f);
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(2.0f, 4.0f);

    shadowProg_.use();
    shadowProg_.setMat4("u_lightVP", lightVP);
    shadowProg_.set1f("u_time", fp.time);
    for (int b = 0; b < kBatchCount; ++b) {
        if (instanceCount_[b] == 0) continue;
        glBindVertexArray(batches_[b].vao);
        glDrawElementsInstanced(GL_TRIANGLES, batches_[b].indexCount, GL_UNSIGNED_SHORT, nullptr, instanceCount_[b]);
    }
    drawDynamicMesh();
    glDisable(GL_POLYGON_OFFSET_FILL);
}

void Renderer::setLitUniforms(ShaderProgram& p, const FrameParams& fp, bool shadowOn, const Mat4& shadowMat) {
    const Atmosphere& a = fp.atmo;
    p.set3f("u_sunDir", a.sunDir);
    p.set3f("u_sunColor", a.sunColor);
    p.set3f("u_ambSky", a.ambSky);
    p.set3f("u_ambGround", a.ambGround);
    p.set3f("u_fogColor", a.fogColor);
    p.set3f("u_fogSun", a.fogSun);
    p.set1f("u_fogDensity", a.fogDensity);
    p.set1f("u_time", fp.time);
    p.set1f("u_shadowOn", shadowOn ? 1.0f : 0.0f);
    const float texel = 1.0f / static_cast<float>(std::max(1, shadow_.size));
    p.set2f("u_shadowTexel", texel, texel);
    p.setMat4("u_shadowMat", shadowMat);
    p.set1i("u_shadowMap", 1);
}

void Renderer::render(const FrameParams& fp, const SceneGeometry& geo, const UiBatch& ui) {
    if (!ready_) return;
    const QualitySettings& q = qualityPreset(tier_);
    const float aspect = this->aspect();
    const Mat4 view = Mat4::lookAt(Vec3(0.0f, 0.0f, 0.0f), fp.cam.fwd, fp.cam.up);
    const Mat4 proj = Mat4::perspective(fp.cam.fovY, aspect, kNearZ, kFarZ);
    const Mat4 viewProj = proj * view;

    uploadFrame(geo, ui);

    // ---- shadow pass
    const bool shadowOn = shadow_.valid() && q.shadowSize > 0;
    Mat4 lightVP = Mat4::identity(), shadowMat = Mat4::identity();
    if (shadowOn) {
        computeShadow(fp, lightVP, shadowMat);
        drawShadowPass(fp, lightVP, geo);
    }

    // ---- scene pass
    const bool useTarget = scene_.valid() && !direct_;
    glBindFramebuffer(GL_FRAMEBUFFER, useTarget ? scene_.fbo : 0);
    glViewport(0, 0, useTarget ? scene_.width : width_, useTarget ? scene_.height : height_);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
    glClearDepthf(1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, shadowOn ? shadow_.depthTex : dummyDepthTex_);
    glActiveTexture(GL_TEXTURE0);

    // sky
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    sky_.use();
    const float th = std::tan(fp.cam.fovY * 0.5f);
    sky_.set3f("u_camRight", fp.cam.right);
    sky_.set3f("u_camUp", fp.cam.up);
    sky_.set3f("u_camFwd", fp.cam.fwd);
    sky_.set2f("u_tanFov", th * aspect, th);
    sky_.set1f("u_time", fp.time);
    sky_.set3f("u_sunDir", fp.atmo.sunDir);
    sky_.set3f("u_sunColor", fp.atmo.sunColor);
    sky_.set3f("u_skyTop", fp.atmo.skyTop);
    sky_.set3f("u_skyMid", fp.atmo.skyMid);
    sky_.set3f("u_fogColor", fp.atmo.fogColor);
    sky_.set3f("u_fogSun", fp.atmo.fogSun);
    sky_.set3f("u_cloudLit", fp.atmo.cloudLit);
    sky_.set3f("u_cloudShade", fp.atmo.cloudShade);
    sky_.set3f("u_mtnNear", fp.atmo.mountainNear);
    sky_.set3f("u_mtnFar", fp.atmo.mountainFar);
    glBindVertexArray(emptyVao_);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    // terrain + road
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE);
    if (!geo.terrain.empty()) {
        terrain_.use();
        terrain_.setMat4("u_viewProj", viewProj);
        setLitUniforms(terrain_, fp, shadowOn, shadowMat);
        glBindVertexArray(terrainVao_);
        glDrawElements(GL_TRIANGLES, terrainIndexCount_, GL_UNSIGNED_SHORT, nullptr);
    }

    // scenery batches + dynamic mesh
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    mesh_.use();
    mesh_.setMat4("u_viewProj", viewProj);
    setLitUniforms(mesh_, fp, shadowOn, shadowMat);
    for (int b = 0; b < kBatchCount; ++b) {
        if (instanceCount_[b] == 0) continue;
        glBindVertexArray(batches_[b].vao);
        glDrawElementsInstanced(GL_TRIANGLES, batches_[b].indexCount, GL_UNSIGNED_SHORT, nullptr, instanceCount_[b]);
    }
    drawDynamicMesh();

    // particles
    if (smokeCount_ > 0 || sparkCount_ > 0) {
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glDepthMask(GL_FALSE);
        particle_.use();
        particle_.setMat4("u_view", view);
        particle_.setMat4("u_proj", proj);
        const Vec3 light = fp.atmo.ambSky * 0.6f + fp.atmo.sunColor * 0.35f;
        particle_.set3f("u_light", light);
        if (smokeCount_ > 0) {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            particle_.set1f("u_additive", 0.0f);
            glBindVertexArray(smokeVao_);
            glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, smokeCount_);
        }
        if (sparkCount_ > 0) {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            particle_.set1f("u_additive", 1.0f);
            glBindVertexArray(sparkVao_);
            glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, sparkCount_);
        }
        glDepthMask(GL_TRUE);
        glDisable(GL_BLEND);
    }

    // ---- post processing to the screen
    if (useTarget) {
        const GLenum att = GL_DEPTH_ATTACHMENT;
        glInvalidateFramebuffer(GL_FRAMEBUFFER, 1, &att);
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glViewport(0, 0, width_, height_);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, scene_.colorTex);
        post_.use();
        post_.set1i("u_scene", 0);
        post_.set2f("u_texel", 1.0f / static_cast<float>(scene_.width), 1.0f / static_cast<float>(scene_.height));
        post_.set1f("u_aspect", aspect);
        post_.set1f("u_speed", fp.speed01);
        post_.set1f("u_slide", fp.slide);
        post_.set1f("u_flash", fp.flash);
        post_.set1f("u_time", fp.time);
        post_.set2f("u_center", 0.5f, 0.52f);
        const Vec3 s = fp.atmo.sunDir;
        const float cx = viewProj.m[0] * s.x + viewProj.m[4] * s.y + viewProj.m[8] * s.z;
        const float cy = viewProj.m[1] * s.x + viewProj.m[5] * s.y + viewProj.m[9] * s.z;
        const float cw = viewProj.m[3] * s.x + viewProj.m[7] * s.y + viewProj.m[11] * s.z;
        const bool sunFront = cw > 0.01f;
        post_.set2f("u_sunUv", sunFront ? cx / cw * 0.5f + 0.5f : -1.0f, sunFront ? cy / cw * 0.5f + 0.5f : -1.0f);
        post_.set1f("u_sunVis", sunFront ? 1.0f : 0.0f);
        post_.set3f("u_sunColor", fp.atmo.sunColor);
        post_.set1f("u_fxaa", q.fxaa ? 1.0f : 0.0f);
        post_.set1i("u_taps", q.blurTaps);
        glBindVertexArray(emptyVao_);
        glDrawArrays(GL_TRIANGLES, 0, 3);
    }

    // ---- UI overlay
    if (uiCount_ > 0) {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        ui_.use();
        ui_.set2f("u_screen", static_cast<float>(width_), static_cast<float>(height_));
        ui_.set1i("u_atlas", 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, uiAtlasTex_);
        glBindVertexArray(uiVao_);
        glDrawArrays(GL_TRIANGLES, 0, uiCount_);
        glDisable(GL_BLEND);
    }
    glBindVertexArray(0);
}

}  // namespace sd
