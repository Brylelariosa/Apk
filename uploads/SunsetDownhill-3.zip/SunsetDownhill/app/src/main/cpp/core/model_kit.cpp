#include "model_kit.h"

#include <algorithm>
#include <cmath>

namespace sd {
namespace kit {

Ring roundedSection(float z, float yBottom, float yTop, float halfWBottom, float halfWTop, float rBottom, float rTop, int cornerSegments,
                    float xCentre) {
    const float halfH = std::max(0.0005f, (yTop - yBottom) * 0.5f);
    const float rb = std::max(0.0f, std::min({rBottom, halfWBottom, halfH}));
    const float rt = std::max(0.0f, std::min({rTop, halfWTop, halfH}));
    const int segs = std::max(1, cornerSegments);
    // corner centres: bottom-right, top-right, top-left, bottom-left; each arc sweeps 90 degrees counter-clockwise
    const float cx[4] = {xCentre + halfWBottom - rb, xCentre + halfWTop - rt, xCentre - halfWTop + rt, xCentre - halfWBottom + rb};
    const float cy[4] = {yBottom + rb, yTop - rt, yTop - rt, yBottom + rb};
    const float rad[4] = {rb, rt, rt, rb};
    Ring ring;
    ring.reserve(static_cast<size_t>(4 * (segs + 1)));
    for (int k = 0; k < 4; ++k) {
        const float a0 = -kPi * 0.5f + kPi * 0.5f * static_cast<float>(k);
        for (int s = 0; s <= segs; ++s) {
            const float a = a0 + kPi * 0.5f * static_cast<float>(s) / static_cast<float>(segs);
            ring.push_back(Vec3(cx[k] + rad[k] * std::cos(a), cy[k] + rad[k] * std::sin(a), z));
        }
    }
    return ring;
}

namespace {

Vec3 centroid(const Ring& r) {
    Vec3 c(0.0f, 0.0f, 0.0f);
    for (const Vec3& p : r) c += p;
    return c * (1.0f / static_cast<float>(std::max<size_t>(1, r.size())));
}

}  // namespace

void addLoft(MeshData& m, const Mat4& xf, const std::vector<Ring>& st, const Painter& paint, Material mat, bool capStart, bool capEnd) {
    const size_t S = st.size();
    if (S < 2) return;
    const size_t N = st[0].size();
    if (N < 3) return;
    for (const Ring& r : st)
        if (r.size() != N) return;

    std::vector<Vec3> ctr(S);
    for (size_t i = 0; i < S; ++i) ctr[i] = centroid(st[i]);

    // smooth vertex normals: sum of the (outward-oriented) quad normals around each vertex
    std::vector<Vec3> nrm(S * N, Vec3(0.0f, 0.0f, 0.0f));
    for (size_t i = 0; i + 1 < S; ++i) {
        for (size_t j = 0; j < N; ++j) {
            const size_t j1 = (j + 1) % N;
            const Vec3 &a = st[i][j], &b = st[i][j1], &c = st[i + 1][j1], &d = st[i + 1][j];
            Vec3 n = cross(c - a, d - b);
            const Vec3 centre = (a + b + c + d) * 0.25f;
            const Vec3 mid = (ctr[i] + ctr[i + 1]) * 0.5f;
            if (dot(n, centre - mid) < 0.0f) n = -n;
            nrm[i * N + j] += n;
            nrm[i * N + j1] += n;
            nrm[(i + 1) * N + j1] += n;
            nrm[(i + 1) * N + j] += n;
        }
    }
    std::vector<uint16_t> ids(S * N);
    for (size_t i = 0; i < S; ++i) {
        for (size_t j = 0; j < N; ++j) {
            const Vec3 ln = dot(nrm[i * N + j], nrm[i * N + j]) > 1e-14f ? normalize(nrm[i * N + j]) : Vec3(0.0f, 1.0f, 0.0f);
            Material vm = mat;
            const Rgba8 col = paint(st[i][j], ln, vm);
            ids[i * N + j] = m.addVertex(xf.transformPoint(st[i][j]), normalize(xf.transformDir(ln)), col, vm);
        }
    }
    for (size_t i = 0; i + 1 < S; ++i)
        for (size_t j = 0; j < N; ++j) {
            const size_t j1 = (j + 1) % N;
            m.addQuad(ids[i * N + j], ids[i * N + j1], ids[(i + 1) * N + j1], ids[(i + 1) * N + j]);
        }

    auto cap = [&](size_t i, const Vec3& axisDir) {
        const Vec3 ln = normalize(axisDir);
        const Vec3 wn = normalize(xf.transformDir(ln));
        Material cm = mat;
        const Rgba8 cc = paint(ctr[i], ln, cm);
        const uint16_t centre = m.addVertex(xf.transformPoint(ctr[i]), wn, cc, cm);
        std::vector<uint16_t> ring(N);
        for (size_t j = 0; j < N; ++j) {
            Material vm = mat;
            const Rgba8 col = paint(st[i][j], ln, vm);
            ring[j] = m.addVertex(xf.transformPoint(st[i][j]), wn, col, vm);
        }
        for (size_t j = 0; j < N; ++j) m.addTriangle(centre, ring[j], ring[(j + 1) % N]);
    };
    if (capStart) cap(0, ctr[0] - ctr[1]);
    if (capEnd) cap(S - 1, ctr[S - 1] - ctr[S - 2]);
}

void addTube(MeshData& m, const Vec3& a, const Vec3& b, float rA, float rB, int segments, Rgba8 cA, Rgba8 cB, Material mat, bool capA, bool capB,
             const Vec3& hint) {
    const Vec3 d = b - a;
    const float len = length(d);
    if (len < 1e-5f) return;
    const Basis ba = basisFromY(d, hint);
    m.addFrustum(Mat4::fromBasis(ba.x, ba.y, ba.z, a), rA, rB, len, segments, cA, cB, mat, 0.0f, capA, capB);
}

void addEllipsoid(MeshData& m, const Mat4& xf, const Vec3& radii, int subdiv, Rgba8 bottom, Rgba8 top, Material mat) {
    m.addBlob(xf, radii, 0u, subdiv, 0.0f, false, bottom, top, mat, 0.0f);
}

}  // namespace kit
}  // namespace sd
