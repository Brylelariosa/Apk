// rider_net.h - what one rider tells the others about itself in a LAN race. Plain data: no sockets in here.
#pragma once

#include <cstdint>

namespace sd {

struct RiderNet {
    float s = 0.0f, x = 0.0f;            // position on the road
    float alpha = 0.0f, yawVis = 0.0f;   // body heading relative to the road
    float speed = 0.0f;
    float lean = 0.0f, tuck = 0.0f, slide = 0.0f, slideDir = 1.0f, pushAmount = 0.0f, pushPhase = 0.0f;
    float crashTime = 0.0f, crashSpeed = 0.0f;
    float distance = 0.0f;
    int32_t score = 0;
    bool crashed = false;
};

}  // namespace sd
