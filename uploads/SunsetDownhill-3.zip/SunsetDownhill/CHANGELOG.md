# Changelog

## Update 3 (from SunsetDownhill-2): HUD text, new models, drivers, LAN multiplayer

**HUD text (the "overlapping strokes / fading" problem)**
- The stroke font used to be built from many overlapping translucent quads per glyph, so any text that was not fully opaque (the
  drop shadow, the fading popups and countdown, the distance readout) showed the strokes through each other and looked patchy.
  Every glyph is now a single quad sampled from a signed-distance atlas (`ui_font.cpp`, `ui_atlas.h`): even opacity, crisp edges at
  any size, and a soft dark halo instead of the offset shadow.
- `textWidth` used to leave out the stroke thickness, so the "KM/H" label sat on top of the last digit. It now returns the exact ink
  width, and the label shares the baseline of the digits.
- `UiVertex` grew texture coordinates and a halo strength (24 bytes); the UI shader samples the atlas (`shaders.cpp`, `renderer.cpp`).

**Models**
- Rider: full-face helmet with visor, chin bar, stripe and spoiler; lofted jacket with accent band and reflective stripe; hood;
  round limbs with joint balls; knee pads; cuffs; slide gloves with pucks; skate shoes. Same rig and poses as before (`skater_model.cpp`).
  Six colour styles (one per LAN slot).
- Longboard: pintail outline with kicked nose and tail, grip tape with centre stripe, trucks (baseplate, hanger, axle, bushing) and
  glowing wheels with cores. Built once per style and re-posed with a matrix.
- Cars: five lofted body styles - sedan, hatchback, SUV, pickup, van - with wheels, rims, arches, lamps, mirrors, plates and door
  seams (`car_models.cpp`). New helpers in `model_kit.*` (loft, tube, ellipsoid); `addBlob` now caches the icosphere topology.

**Traffic**
- Cars used to drive straight through cones and rocks. `traffic.cpp` gives every car a driver: lane keeping, Intelligent Driver Model
  speed control, curve speed limit, brake lights, indicators, mirror checks, gap acceptance, steering around obstacles through free
  lanes, waiting for a gap with room to pull out, keeping clear of the rider. `tools/test_traffic`: zero overlaps with cones, rocks or
  other cars on many seeds, also with a rider weaving across both lanes.
- Cones and rocks are a pure function of the seed (cars no longer influence where they appear).

**LAN multiplayer** (see README): `net.*` (UDP protocol, polled from the game thread), `hud_mp.*` (lobby, standings, name tags,
results), engine integration, `LanSupport.kt` (multicast lock, Wi-Fi binding, device name), new permissions in the manifest.
`tools/test_net` (protocol, spoofing, garbage) and `tools/test_mp_engine` (three engines play a race through the lobby screens).

**Tools**: `test_traffic`, `test_net`, `test_mp_engine`, `render_models`, `render_traffic`, `render_lan`; `dump_ui` renders the font sheet
and the LAN screens.
