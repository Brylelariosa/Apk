# Changelog

## 1.3
### Fixed
- **Crash when tapping a song to play.** As soon as lyrics were found for the song, the app died with
  `PatternSyntaxException: Syntax error in regexp pattern near index 8  \{[^}]*}`. Android's regex engine
  (ICU) rejects an unescaped `}`, which a desktop JVM accepts. The pattern in `LyricsCleanup` now escapes it
  (`\{[^\}]*\}`), and the two neighbouring patterns escape their `]` the same way. Every other regex in the
  project was checked against a real ICU engine and compiles.
- **Lyrics can no longer crash the app.** The lyrics loader only caught `Exception`, so an `Error` (such as a
  class failing to initialise) escaped and killed the whole app. It now catches everything except
  cancellation, saves an error log, and shows a new *Couldn't load lyrics* state with a *Try again* button
  while the music keeps playing. (Before, any unexpected failure was shown as "Can't reach the lyrics
  service", which was misleading.)

### Changed
- The "message + Try again" layout used by the *offline* and *couldn't load* lyrics states is now one shared
  composable instead of two copies.

## 1.1
### Fixed
- **Lyrics never loaded for songs without an artist tag.** MediaStore reports a missing artist as the text
  `<unknown>`; that was sent to the lyrics service as if it were a real artist. Missing tags are now
  recognised, and lyrics are searched by title + length instead (see HOW_IT_WORKS.md §3).
- Lyrics failures caused by being offline were cached as "not found" for a day. Network errors are no
  longer cached and show a *Try again* button.
- **Player stopped responding after leaving Now Playing.** Every screen created its own PlayerViewModel and
  clearing any one of them disconnected the shared player. There is now one PlayerViewModel for the app and the
  controller is never released by a screen.
- Tapping a song before the player service had connected did nothing; the request is now queued.
- Sleep timer restarted the music if it was already paused, and stopped counting when the app was closed.
- Favouriting a song in a list changed the song shown in the mini player.
- Without audio permission the app showed an empty library; it now shows an *Allow access* screen
  (and re-checks when you return from Settings).
- The gradient background recomposed the whole app 60×/second; the song position recomposed every list 5×/second.
  Both are now draw-phase / isolated.

### Changed
- All emoji and text-glyph icons replaced with vector drawables; real buttons everywhere
  (Play all, Shuffle, Scan library, Lyrics, Sleep timer, Try again, Search manually, Allow access).
- Songs without artwork show a music-note cover instead of an empty box.
- Now Playing: lyrics/sleep timer are labelled buttons; the cover stops turning where it is when paused.
- Song rows show an animated equalizer on the current song.
- Scans SD cards too (Android 10+).

### Removed
- `material-icons-extended` dependency (large; every icon is now our own vector) — faster CI builds.
- Unused permissions `SYSTEM_ALERT_WINDOW` and `RECEIVE_BOOT_COMPLETED`.
