# How Melodiq works

## 1. Finding your songs
1. On first launch Melodiq asks for permission to read audio files
   (`READ_MEDIA_AUDIO` on Android 13+, `READ_EXTERNAL_STORAGE` on older versions).
   If you deny it, a screen with **Allow access** and **Open app settings** buttons is shown.
2. `MusicRepository.syncLibrary()` asks Android's MediaStore for every music file of 30 s or longer
   and saves them in a local Room database (`songs` table). Songs that no longer exist are removed.
3. Screens never read MediaStore directly — they observe the database, so lists update by themselves.
4. If a file has no artist/album tag, MediaStore returns the text `<unknown>` (not null).
   `util/MediaTags.kt` turns that into "Unknown artist" / "Unknown album" everywhere.

## 2. Playing music
```
UI buttons ─▶ PlayerViewModel ─▶ PlayerManager ─▶ MediaController ─▶ MusicService ─▶ ExoPlayer
 (one copy         (state for         (one connection        (background service,
  for the app)      the screens)        for the app)           notification, audio focus)
```
* **MusicService** owns ExoPlayer and keeps playing when the app is closed.
* **PlayerManager** is connected once and never released while the app process lives. A tap that
  arrives before the connection is ready is remembered and played as soon as it connects.
* **PlayerViewModel** is created once in `AppRoot` and passed to every screen, so the mini player,
  the song lists and Now Playing always agree.
* Song position changes 5×/second, so it lives in its own flow (`progress`). Only the seek bar and the
  mini-player bar read it; song lists don't recompose while music plays.
* **Sleep timer** lives in `SleepTimerManager` (a singleton), so it still pauses the music after you
  close the app. It calls `pause()` — it never restarts music you already paused.

## 3. Lyrics
Lyrics come from the free LRCLIB service. `LyricsRepository` tries, in order, and stops at the first hit:

| Step | Request | Used when |
|------|---------|-----------|
| 1 | exact lookup `/api/get` (title + artist + album + length) | song has an artist tag |
| 2 | field search `/api/search?track_name=…` | always — works with the title alone |
| 3 | free-text search `/api/search?q=…` | last resort |

* Every step is tried with a **cleaned title** (`(Official Video)`, `[Lyrics]`, `01 - ` removed) and, for
  file-name style titles like `Artist - Title`, with that split as well.
* Search results are accepted only with real evidence: same title **and** length within 5 s when there is
  no artist, or matching artist. A title that merely contains your words never counts, so "Love" will
  not pull the lyrics of "Love Story".
* Found lyrics are cached 30 days, "not found" 1 day. A network failure is **never** cached, and shows a
  *Try again* button instead of "No lyrics".
* On the lyrics screen: **Try again** re-asks the service, **Search manually** lets you type the title and
  artist yourself (this is the fix for songs that have no artist name).
* Synced lyrics (`[mm:ss.xx]` lines) are highlighted by polling the player position every 100 ms.

## 4. Buttons and icons
Every icon is a vector drawable in `app/src/main/res/drawable/ic_*.xml` (24×24, white fill, tinted in code).
No emoji and no text glyphs are used as icons.

| Component | File | Use |
|-----------|------|-----|
| `VectorIcon` | `ui/components/VectorIcon.kt` | draw any `ic_*` drawable with a tint |
| `IconActionButton` | `ui/components/Buttons.kt` | round icon-only button with ripple + accessibility label |
| `MelodiqButton` | `ui/components/Buttons.kt` | labelled button, optional icon, `Filled` / `Tonal` / `Outlined` |
| `EmptyState` | `ui/components/EmptyState.kt` | icon + title + hint + action buttons |
| `ArtworkImage` | `ui/components/ArtworkImage.kt` | album art with a built-in music-note fallback |
| `EqualizerBars` | `ui/components/EqualizerBars.kt` | animated "now playing" bars |

To add an icon: save a 24×24 vector as `res/drawable/ic_name.xml` (`android:fillColor="#FFFFFFFF"`), then
`VectorIcon(id = R.drawable.ic_name)` or `IconActionButton(icon = R.drawable.ic_name, …)`.

## 5. Project map
```
data/        model, Room database, LRCLIB service, repositories (music, lyrics, playlists)
player/      MusicService (ExoPlayer) + PlayerManager (app-wide controller)
ui/          AppNavigation (AppRoot), screens, components, view models, theme
util/        MediaTags, TrackMatcher/TitleCleaner, LrcParser, SleepTimerManager, helpers
```
