# How Melodiq works

## 1. Finding your songs
1. On first launch Melodiq asks for permission to read audio files
   (`READ_MEDIA_AUDIO` on Android 13+, `READ_EXTERNAL_STORAGE` on older versions).
   If you deny it, a screen with **Allow access** and **Open app settings** buttons is shown.
2. `MusicRepository.syncLibrary()` asks Android's MediaStore for every music file of 30 s or longer
   and saves them in a local Room database (`songs` table). Songs that no longer exist are removed.
3. Screens never read MediaStore directly — they observe the database, so lists update by themselves.
4. If a file has no artist/album tag, MediaStore returns the text `<unknown>` (not null).
   `util/MediaTags.kt` turns that into "Unknown artist" / "Unknown album" everywhere.

## 2. Playing music
```
UI buttons ─▶ PlayerViewModel ─▶ PlayerManager ─▶ MediaController ─▶ MusicService ─▶ ExoPlayer
 (one copy         (state for         (one connection        (background service,
  for the app)      the screens)        for the app)           notification, audio focus)
```
* **MusicService** owns ExoPlayer and keeps playing when the app is closed.
* **PlayerManager** is connected once and never released while the app process lives. A tap that
  arrives before the connection is ready is remembered and played as soon as it connects.
* **PlayerViewModel** is created once in `AppRoot` and passed to every screen, so the mini player,
  the song lists and Now Playing always agree.
* Song position changes 5×/second, so it lives in its own flow (`progress`). Only the seek bar and the
  mini-player bar read it; song lists don't recompose while music plays.
* **Shuffle** is handled by `ShuffleCoordinator` (inside the service, next to ExoPlayer). It replaces ExoPlayer's
  random order with a *deck* (`ShuffleDeck`): a permutation of every song in the queue, the playing song first.
  - Each song appears exactly once per pass, so none is skipped and none repeats before the pass is over.
  - Turning shuffle on mid-way: songs already played stay behind the current one (that is what *Previous*
    walks back through) and only the unplayed songs are shuffled. If everything was played, a new pass starts.
  - *Repeat off* stops after the last song. *Repeat all* builds a new random deck when the last song starts.
  - The *Shuffle* buttons start shuffle mode with a random first song (`PlayerManager.playSongs(..., shuffle = true)`).
* **Notification / lock screen / headset buttons.** The media session is given `SkippablePlayer` (a
  `ForwardingPlayer` around ExoPlayer) that keeps *previous* and *next* available at all times. ExoPlayer withdraws
  *next* on the last song, which made the notification lose a button exactly when a queue ended (play jumped across;
  Android 13+ left an empty slot). *Next* on the last song just does nothing. The status-bar icon is
  `ic_stat_melodiq` (set on `DefaultMediaNotificationProvider`); the title comes from the media item's metadata.
* **Sleep timer** lives in `SleepTimerManager` (a singleton), so it still pauses the music after you
  close the app. It calls `pause()` — it never restarts music you already paused.

## 3. Lyrics
Lyrics come from the free LRCLIB service. `LyricsRepository` tries, in order, and stops at the first hit:

| Step | Request | Used when |
|------|---------|-----------|
| 1 | exact lookup `/api/get` (title + artist + album + length) | song has an artist tag |
| 2 | field search `/api/search?track_name=…` | always — works with the title alone |
| 3 | free-text search `/api/search?q=…` | last resort |

* Every step is tried with a **cleaned title** (`(Official Video)`, `[Lyrics]`, `01 - ` removed) and, for
  file-name style titles like `Artist - Title`, with that split as well.
* Search results are accepted only with real evidence: same title **and** length within 5 s when there is
  no artist, or matching artist. A title that merely contains your words never counts, so "Love" will
  not pull the lyrics of "Love Story".
* **Saved on the phone for good.** Found lyrics are stored in Room and never expire, so once a song's lyrics have
  loaded that song never needs the internet again (only *Try again* asks the service anew). "Not found" is retried
  after 1 day. A network failure is **never** saved, and shows a *Try again* button instead of "No lyrics". On top
  of that `LyricsManager` keeps the last 12 results in memory, so returning to a song shows its lyrics without the
  spinner. (There is no purge: nothing would ever delete found lyrics.)
* **Fullest wins.** LRCLIB often has several uploads of one song and some stop halfway. Among the trusted
  matches the one with the most lines is chosen (`TrackMatcher.pickBest`); a hit that looks cut short
  (`LyricsQuality.assess`: synced lines < 80 % of the plain lines, or the timing ends long before the song)
  is only kept as a fallback while the other steps look for a fuller one.
* **Missing tail.** If the synced lines are a prefix of the plain text, the remaining plain lines are appended
  without timing (`LyricsQuality.withMissingTail`) and shown dimmed, so nothing is missing from the screen.
  Lyrics that still look incomplete get a notice with a button to the version list.
* **Your own lyrics** (lyrics options, ⋮ above the lyrics): *Choose another version* (list of everything found,
  `LyricsRepository.findVersions`), *Edit or paste lyrics*, *Import .lrc/.txt*, *Back to automatic*, and *Sync
  timing*. Your choice and offset are stored per song as small JSON files (`CustomLyricsStore`, in the app's private
  `files/lyrics` folder) — deliberately not in Room, so they never expire and the database schema is untouched.
  Text with `[mm:ss.xx]` lines becomes synced lyrics, anything else plain lyrics.
* **Sync timing** is a panel above the lyrics (`LyricsSyncPanel`, opened by the *Sync* chip or from the lyrics
  options), not a dialog, so the lines can be watched moving while you adjust. Slider ±10 s, ±1 s buttons, ±0.1 s
  buttons that repeat while held; every change is saved at once (`LyricsTiming.MAX_OFFSET_MS` = ±30 s).
* **Edit lyrics** is a full screen (`LyricsEditorScreen`) laid over Now Playing, with `systemBarsPadding().imePadding()`:
  the keyboard pushes it up so the text field shrinks instead of being covered. Back closes the editor only.
* **Choose lyrics** marks the version already in use (`LyricsFingerprint` compares the first letters of the text,
  ignoring timestamps) and keeps the last 8 searches in memory (the *Search* button always asks again).
* **Auto-scroll** (`SyncedLyricsContent` / `centerLine`): the current line is scrolled to the middle of the list.
  The list has half a screen of padding above and below, and a line's `offset` is measured from the start of the
  *content* (below the padding), so the middle is `(viewportStartOffset + viewportEndOffset) / 2` — **not**
  `viewportSize / 2`, which put the line at the bottom edge. While a finger is on the list nothing scrolls; 3.5 s
  after it lets go the list glides back to the current line. Before the first line it returns to the top.
* **Try again** re-asks the service ignoring the cache.
* `LyricsManager` (singleton) holds the lyrics of the current song and the current line. Lyrics are only looked up
  when the Now Playing screen or the floating window asks, and the 100 ms position polling runs only while
  something is observing `activeLine` — a closed app with no floating window does no lyrics work.
* Lyrics are optional, so they are fenced off from the player: if anything unexpected fails while loading
  them, the app saves an error log, shows *Couldn't load lyrics* with a *Try again* button, and the music
  keeps playing.
* **Regex rule for Android:** the phone's regex engine (ICU) is stricter than a desktop JVM. Always escape
  literal `{ } [ ] ( )` with a backslash (`\{[^\}]*\}`, not `\{[^}]*}`), or the app crashes the first time
  the pattern is built.

## 4. Look, settings and floating lyrics
* **Settings** (`ui/screen/SettingsScreen.kt`, reached from the gear on Home / Now Playing). All options are
  data classes in `data/model/AppSettings.kt`, stored in DataStore by `SettingsRepository`. `settings` is a
  `StateFlow` rebuilt from the stored values, so Settings, Now Playing and the floating window (inside the
  service) always agree; `update { … }` changes the stored values atomically.
* **Now Playing look**: `AmbientBackground` (aurora / pulse / still / plain) and `NowPlayingCover` (rounded or
  circle, breathe / float / spin / none, halo). Both drive their animation from one float clock that only the
  draw / graphics-layer phase reads, capped at 30 fps for the background, and stopped while paused.
* **Now Playing picture** (Settings → *Picture*): `MusicVisualizer` (default; Ring / Bars / Waves), the album cover
  (`NowPlayingCover`), or *Auto* (cover only when the song has art; the screen learns that while it loads the art
  for the accent colour). The visualizer is a pretend spectrum — three sine waves per bar plus a steady beat — so it
  needs no audio permission; it settles when paused. One float clock, read only by the draw phase, 30 fps, stopped
  while paused (unless *Animate only while playing* is off).
* **Lyrics view** (`LyricsView.kt`): size, alignment, font, weight, current-line scale, dimming, distance fade,
  highlight colour (or album colour), glow, smooth scroll, tap to seek, keep screen on.
* **Floating lyrics** (`overlay/`): `FloatingLyricsOverlay` is created by `MusicService` (a foreground service
  while music plays, so Android keeps the window alive). It adds a `ComposeView` to `WindowManager`
  (`TYPE_APPLICATION_OVERLAY`) and draws `FloatingLyricsCard` — the same composable as the live preview in
  Settings. A window added from a service has no Activity, so `OverlayLifecycleOwner` supplies the lifecycle and
  saved-state owners the ComposeView needs. `OverlayDragLayout` moves the window using raw screen coordinates (the
  window moves under the finger, so view coordinates would jitter) and only after the touch slop, so the buttons
  inside still work. It shows only when: enabled + permission granted + a song is loaded (+ playing, unless you
  chose otherwise) + Melodiq is not on screen (`AppForeground`, optional) + synced lyrics exist (optional).
  The permission is *Display over other apps* (`SYSTEM_ALERT_WINDOW`); `OverlayPermission` opens the system page.

## 5. Buttons and icons
Every icon is a vector drawable in `app/src/main/res/drawable/ic_*.xml` (24×24, white fill, tinted in code).
No emoji and no text glyphs are used as icons.

| Component | File | Use |
|-----------|------|-----|
| `VectorIcon` | `ui/components/VectorIcon.kt` | draw any `ic_*` drawable with a tint |
| `IconActionButton` | `ui/components/Buttons.kt` | round icon-only button with ripple + accessibility label |
| `MelodiqButton` | `ui/components/Buttons.kt` | labelled button, optional icon, `Filled` / `Tonal` / `Outlined` |
| `EmptyState` | `ui/components/EmptyState.kt` | icon + title + hint + action buttons |
| `ArtworkImage` | `ui/components/ArtworkImage.kt` | album art with a built-in music-note fallback |
| `EqualizerBars` | `ui/components/EqualizerBars.kt` | animated "now playing" bars |

To add an icon: save a 24×24 vector as `res/drawable/ic_name.xml` (`android:fillColor="#FFFFFFFF"`), then
`VectorIcon(id = R.drawable.ic_name)` or `IconActionButton(icon = R.drawable.ic_name, …)`.

## 6. Playlists
* Stored in the `playlists` table that has always existed (`PlaylistEntity`: id, name, `songIdsJson`, createdAt), so
  no migration. A playlist is a name plus song ids in the order they were added; the songs stay in the library, and
  ids that no longer exist are skipped when a playlist is shown.
* `PlaylistRepository` serialises every change behind a mutex (two quick taps never overwrite each other).
  `PlaylistNames` trims / collapses spaces / caps at 40 characters and rejects blank or duplicate names.
* `PlaylistsViewModel` is created once in `AppRoot` (like the player and library view models). It combines the
  playlists with the library songs into `PlaylistItem`s; `uiState.loaded` stops the empty message flashing.
* Screens: `PlaylistsScreen` (the tab), `PlaylistDetailScreen` (route `playlist/{playlistId}`). Dialogs in
  `PlaylistDialogs.kt`: name (create / rename), confirm, add-to-playlist, multi-song picker.
* **⋮ on a song** = `SongMenuHost` (menu → pick a playlist → new playlist name). Put it *outside* a `LazyColumn`
  (a dialog inside a lazy item disappears when the item scrolls away). Extra rows can be added with `extraActions`.
* **Warning:** `fallbackToDestructiveMigration()` wipes playlists, favourites and saved lyrics when the Room schema
  version changes. Write a `Migration` before ever touching a table.

## 7. Project map
```
data/        model, Room database, LRCLIB service, repositories (music, lyrics, playlists, settings, custom lyrics)
player/      MusicService (ExoPlayer) + SkippablePlayer + PlayerManager (app-wide controller) + ShuffleCoordinator
lyrics/      LyricsManager — lyrics + current line of the playing song, shared by screen and floating window
overlay/     FloatingLyricsOverlay, OverlayLifecycleOwner, OverlayPermission, AppForeground
ui/          AppNavigation (AppRoot), screens (incl. Settings), components, view models, theme
util/        MediaTags, TrackMatcher/TitleCleaner, LrcParser, LyricsQuality, LyricsCleanup, ShuffleDeck, helpers
```
