package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.melodiq.ui.theme.DeepPurple
import com.melodiq.ui.theme.MidnightBlue

@Composable
fun AnimatedGradientBackground(
    color1: Color = DeepPurple,
    color2: Color = MidnightBlue,
    color3: Color = Color(0xFF0D0D1A),
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val animColor1 = animateColorAsState(
        targetValue   = color1,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label         = "bg_color1"
    )
    val animColor2 = animateColorAsState(
        targetValue   = color2,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label         = "bg_color2"
    )
    val animColor3 = animateColorAsState(
        targetValue   = color3,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label         = "bg_color3"
    )
    val shift = rememberInfiniteTransition(label = "bg_gradient").animateFloat(
        initialValue  = 0f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bg_shift"
    )

    // The three colours and the shift are read inside drawBehind (draw phase), so the
    // gradient animates by redrawing only — the whole app below is NOT recomposed 60×/s.
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val t = shift.value
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(animColor1.value, animColor2.value, animColor3.value),
                        start  = Offset(t * 600f, 0f),
                        end    = Offset(600f, t * 1200f)
                    )
                )
            },
        content = content
    )
}
