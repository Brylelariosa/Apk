package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.PlayerState
import com.melodiq.data.model.SleepTimer
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import com.melodiq.player.PlayerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val playerManager: PlayerManager,
    private val musicRepository: MusicRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _sleepTimer = MutableStateFlow<SleepTimer?>(null)
    val sleepTimer: StateFlow<SleepTimer?> = _sleepTimer.asStateFlow()

    private var positionPollingJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        playerManager.connect()
        observePlayerState()
        startPositionPolling()
    }

    private fun observePlayerState() {
        // FIX: removed currentMediaItem from combine — it was passed in but never used
        // in the lambda, causing dead combine re-runs. currentSong is now handled
        // exclusively in the collectLatest block below.
        viewModelScope.launch {
            combine(
                playerManager.isPlaying,
                playerManager.shuffleEnabled,
                playerManager.repeatMode
            ) { isPlaying, shuffle, repeat ->
                _state.update { current ->
                    current.copy(
                        isPlaying      = isPlaying,
                        shuffleEnabled = shuffle,
                        repeatMode     = repeat
                    )
                }
            }.collect()
        }

        // FIX: look up the full Song object and update currentSong whenever
        // ExoPlayer transitions to a new media item (next, previous, auto-advance).
        viewModelScope.launch {
            playerManager.currentMediaItem.collectLatest { item ->
                if (item != null) {
                    val songId = item.mediaId.toLongOrNull() ?: return@collectLatest
                    // Hydrate the Song from the local DB so currentSong is always valid
                    val song = musicRepository.getSongById(songId)
                    _state.update { it.copy(
                        currentSong = song,
                        duration    = playerManager.getDuration()
                    )}
                    musicRepository.markRecentlyPlayed(songId)
                } else {
                    // Player stopped / queue cleared
                    _state.update { it.copy(currentSong = null) }
                }
            }
        }
    }

    private fun startPositionPolling() {
        positionPollingJob?.cancel()
        positionPollingJob = viewModelScope.launch {
            while (isActive) {
                _state.update { it.copy(
                    currentPosition = playerManager.getCurrentPosition(),
                    duration        = playerManager.getDuration()
                )}
                delay(200L)
            }
        }
    }

    // ── Public actions ───────────────────────────────────────────────────────

    fun playSongs(songs: List<Song>, startIndex: Int = 0) {
        // FIX: set currentSong immediately so the UI reflects the new song
        // without waiting for the async onMediaItemTransition callback.
        _state.update { it.copy(
            queue        = songs,
            currentIndex = startIndex,
            currentSong  = songs.getOrNull(startIndex)
        )}
        playerManager.playSongs(songs, startIndex)
    }

    fun togglePlayPause()    = playerManager.togglePlayPause()
    fun seekToNext()         = playerManager.seekToNext()
    fun seekToPrevious()     = playerManager.seekToPrevious()
    fun seekTo(ms: Long)     = playerManager.seekTo(ms)
    fun toggleShuffle()      = playerManager.toggleShuffle()
    fun cycleRepeatMode()    = playerManager.cycleRepeatMode()

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(song.id, !song.isFavorite)
            // Refresh currentSong so the heart icon updates without a restart
            val updated = musicRepository.getSongById(song.id)
            _state.update { it.copy(currentSong = updated) }
        }
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimer.value = null
            return
        }
        val timer = SleepTimer(durationMinutes = minutes)
        _sleepTimer.value = timer
        sleepTimerJob = viewModelScope.launch {
            delay(timer.durationMinutes * 60_000L)
            playerManager.togglePlayPause()
            _sleepTimer.value = null
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimer.value = null
    }

    override fun onCleared() {
        positionPollingJob?.cancel()
        sleepTimerJob?.cancel()
        playerManager.release()
        super.onCleared()
    }
}
