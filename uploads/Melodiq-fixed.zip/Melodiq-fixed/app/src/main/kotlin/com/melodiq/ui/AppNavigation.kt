package com.melodiq.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.melodiq.R
import com.melodiq.ui.components.AnimatedGradientBackground
import com.melodiq.ui.components.MiniPlayer
import com.melodiq.ui.components.PermissionScreen
import com.melodiq.ui.components.VectorIcon
import com.melodiq.ui.screen.HomeScreen
import com.melodiq.ui.screen.LibraryScreen
import com.melodiq.ui.screen.NowPlayingScreen
import com.melodiq.ui.screen.SearchScreen
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.util.hasAudioPermission
import com.melodiq.util.requiredRuntimePermissions

sealed class NavRoute(val route: String) {
    object Home       : NavRoute("home")
    object Library    : NavRoute("library")
    object Search     : NavRoute("search")
    object NowPlaying : NavRoute("now_playing")
}

data class BottomNavItem(val route: NavRoute, val label: String, @DrawableRes val icon: Int)

private val bottomNavItems = listOf(
    BottomNavItem(NavRoute.Home,    "Home",    R.drawable.ic_home),
    BottomNavItem(NavRoute.Library, "Library", R.drawable.ic_library_music),
    BottomNavItem(NavRoute.Search,  "Search",  R.drawable.ic_search)
)

/**
 * App entry point. Owns the two app-wide ViewModels and the audio permission, then shows either
 * the permission screen or the real app. The PlayerViewModel is created ONCE here and passed down
 * (screens used to create their own copies, and clearing any one of them disconnected the player).
 */
@Composable
fun AppRoot() {
    val context        = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val playerVm: PlayerViewModel   = hiltViewModel()
    val libraryVm: LibraryViewModel = hiltViewModel()

    var permissionGranted by remember { mutableStateOf(context.hasAudioPermission()) }
    var askedForPermission by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        permissionGranted = context.hasAudioPermission()
    }

    // Re-check when the user comes back from system Settings.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionGranted = context.hasAudioPermission()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Scan the library as soon as we are allowed to; ask once if we are not.
    LaunchedEffect(permissionGranted) {
        if (permissionGranted) {
            libraryVm.syncLibrary()
        } else if (!askedForPermission) {
            askedForPermission = true
            permissionLauncher.launch(requiredRuntimePermissions())
        }
    }

    AnimatedGradientBackground {
        if (permissionGranted) {
            MainContent(playerVm = playerVm, libraryVm = libraryVm)
        } else {
            PermissionScreen(
                onRequestPermission = { permissionLauncher.launch(requiredRuntimePermissions()) },
                onOpenSettings      = { openAppSettings(context) }
            )
        }
    }
}

@Composable
private fun MainContent(playerVm: PlayerViewModel, libraryVm: LibraryViewModel) {
    val playerState   by playerVm.state.collectAsStateWithLifecycle()
    val progressState = playerVm.progress.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute  = backStackEntry?.destination?.route

    val onNowPlaying   = currentRoute == NavRoute.NowPlaying.route
    val showMiniPlayer = playerState.currentSong != null && !onNowPlaying

    val openNowPlaying: () -> Unit = {
        navController.navigate(NavRoute.NowPlaying.route) { launchSingleTop = true }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            if (!onNowPlaying) {
                Column {
                    AnimatedVisibility(
                        visible = showMiniPlayer,
                        enter   = slideInVertically { it } + fadeIn(),
                        exit    = slideOutVertically { it } + fadeOut()
                    ) {
                        MiniPlayer(
                            state             = playerState,
                            progress          = { progressState.value },
                            onTogglePlayPause = playerVm::togglePlayPause,
                            onSkipNext        = playerVm::seekToNext,
                            onClick           = openNowPlaying
                        )
                    }
                    AppNavigationBar(
                        currentRoute = currentRoute,
                        onSelect     = { route ->
                            navController.navigate(route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        }
                    )
                }
            }
        }
    ) { padding ->
        // The tab screens sit inside the Scaffold padding (status bar / mini player / nav bar).
        // Now Playing ignores it and draws edge-to-edge, handling system bars itself.
        NavHost(
            navController      = navController,
            startDestination   = NavRoute.Home.route,
            enterTransition    = { fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.96f) },
            exitTransition     = { fadeOut(tween(180)) },
            popEnterTransition = { fadeIn(tween(220)) },
            popExitTransition  = { fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.96f) }
        ) {
            composable(NavRoute.Home.route) {
                Box(Modifier.padding(padding)) {
                    HomeScreen(
                        onNavigateToNowPlaying = openNowPlaying,
                        libraryVm              = libraryVm,
                        playerVm               = playerVm
                    )
                }
            }
            composable(NavRoute.Library.route) {
                Box(Modifier.padding(padding)) {
                    LibraryScreen(
                        onNavigateToNowPlaying = openNowPlaying,
                        libraryVm              = libraryVm,
                        playerVm               = playerVm
                    )
                }
            }
            composable(NavRoute.Search.route) {
                Box(Modifier.padding(padding)) {
                    SearchScreen(
                        onNavigateToNowPlaying = openNowPlaying,
                        playerVm               = playerVm
                    )
                }
            }
            composable(
                route             = NavRoute.NowPlaying.route,
                enterTransition   = { slideInVertically { it } + fadeIn(tween(300)) },
                exitTransition    = { fadeOut(tween(200)) },
                popExitTransition = { slideOutVertically { it } + fadeOut(tween(300)) }
            ) {
                NowPlayingScreen(
                    onBack   = { navController.popBackStack() },
                    playerVm = playerVm
                )
            }
        }
    }
}

@Composable
private fun AppNavigationBar(currentRoute: String?, onSelect: (String) -> Unit) {
    NavigationBar(
        containerColor = SurfaceCard.copy(alpha = 0.85f),
        tonalElevation = 0.dp
    ) {
        bottomNavItems.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route.route,
                onClick  = { onSelect(item.route.route) },
                icon     = { VectorIcon(id = item.icon, size = 24.dp) },
                label    = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                colors   = NavigationBarItemDefaults.colors(
                    selectedIconColor   = PrimaryPurple,
                    selectedTextColor   = PrimaryPurple,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor      = PrimaryPurple.copy(alpha = 0.15f)
                )
            )
        }
    }
}

private fun openAppSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null)
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
