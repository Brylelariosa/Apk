package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.R
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsResult
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.util.LyricsCleanup
import com.melodiq.util.ProcessedLyric

/**
 * @param hasArtist false when the song has no artist tag — the "not found" state then explains
 *                  that and nudges the user towards "Search manually".
 */
@Composable
fun LyricsView(
    result: LyricsResult,
    currentIndex: Int,
    hasArtist: Boolean,
    onRetry: () -> Unit,
    onSearchManually: () -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = PrimaryPurple
) {
    when (result) {
        is LyricsResult.Loading  -> LyricsLoading(modifier)
        is LyricsResult.NotFound -> LyricsNotFound(hasArtist, onRetry, onSearchManually, modifier)
        is LyricsResult.Offline  -> LyricsRetryState(
            icon    = R.drawable.ic_refresh,
            title   = "Can't reach the lyrics service",
            message = "Check your internet connection, then try again.",
            onRetry = onRetry,
            modifier = modifier
        )
        is LyricsResult.Failed   -> LyricsRetryState(
            icon    = R.drawable.ic_lyrics,
            title   = "Couldn't load lyrics",
            message = "Something went wrong while loading the lyrics for this song. Try again.",
            onRetry = onRetry,
            modifier = modifier
        )
        is LyricsResult.Synced   -> SyncedLyricsContent(result.lines, currentIndex, accentColor, modifier)
        is LyricsResult.Plain    -> PlainLyricsContent(result.text, modifier)
    }
}

// ── Synced lyrics ─────────────────────────────────────────────────────────────
@Composable
private fun SyncedLyricsContent(
    lines: List<LyricLine>,
    activeIndex: Int,
    accentColor: Color,
    modifier: Modifier
) {
    val listState = rememberLazyListState()

    // keep the active line near the top third, with a little context above it
    LaunchedEffect(activeIndex) {
        if (activeIndex >= 0 && lines.isNotEmpty()) {
            listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
        }
    }

    LazyColumn(
        state               = listState,
        modifier            = modifier.fillMaxSize(),
        contentPadding      = PaddingValues(horizontal = 24.dp, vertical = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        itemsIndexed(items = lines, key = { idx, _ -> idx }) { index, line ->
            SyncedLyricLine(
                text        = line.text,
                isActive    = index == activeIndex,
                accentColor = accentColor
            )
        }
    }
}

@Composable
private fun SyncedLyricLine(
    text: String,
    isActive: Boolean,
    accentColor: Color
) {
    val scale by animateFloatAsState(
        targetValue   = if (isActive) 1.08f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label         = "lyric_scale"
    )
    val textColor by animateColorAsState(
        targetValue   = if (isActive) Color.White else TextMuted,
        animationSpec = tween(250),
        label         = "lyric_color"
    )
    val glowAlpha by animateFloatAsState(
        targetValue   = if (isActive) 1f else 0f,
        animationSpec = tween(300),
        label         = "lyric_glow"
    )

    Text(
        text       = text,
        color      = textColor,
        fontSize   = if (isActive) 18.sp else 16.sp,
        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
        textAlign  = TextAlign.Center,
        lineHeight = 28.sp,
        modifier   = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .drawBehind {
                if (glowAlpha > 0f) {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                accentColor.copy(alpha = 0.15f * glowAlpha),
                                Color.Transparent
                            ),
                            radius = size.width * 0.7f
                        ),
                        blendMode = BlendMode.Screen
                    )
                }
            }
    )
}

// ── Plain lyrics ──────────────────────────────────────────────────────────────
@Composable
private fun PlainLyricsContent(text: String, modifier: Modifier) {
    val processed = remember(text) { LyricsCleanup.processPlainLyrics(text) }
    LazyColumn(
        modifier            = modifier.fillMaxSize(),
        contentPadding      = PaddingValues(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        itemsIndexed(processed, key = { i, _ -> i }) { _, item: ProcessedLyric ->
            if (item.isSection) {
                SectionLabel(item.text)
            } else {
                Text(
                    text       = item.text,
                    color      = TextSecondary,
                    fontSize   = 16.sp,
                    textAlign  = TextAlign.Center,
                    lineHeight = 26.sp,
                    modifier   = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text          = text.uppercase(),
        color         = PrimaryPurple,
        style         = MaterialTheme.typography.labelSmall,
        letterSpacing = 3.sp,
        modifier      = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

// ── States ────────────────────────────────────────────────────────────────────
@Composable
private fun LyricsLoading(modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = PrimaryPurple, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(16.dp))
            Text("Fetching lyrics…", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LyricsNotFound(
    hasArtist: Boolean,
    onRetry: () -> Unit,
    onSearchManually: () -> Unit,
    modifier: Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        EmptyState(
            icon    = R.drawable.ic_lyrics,
            title   = "No lyrics found",
            message = if (hasArtist) {
                "We couldn't find lyrics for this song. Try searching with different words."
            } else {
                "This song has no artist name saved in its file, so the search used the title only. " +
                    "Type the artist yourself to search more accurately."
            }
        ) {
            MelodiqButton(
                text    = "Search manually",
                onClick = onSearchManually,
                icon    = R.drawable.ic_search
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(
                text    = "Try again",
                onClick = onRetry,
                icon    = R.drawable.ic_refresh,
                style   = ButtonStyle.Outlined
            )
        }
    }
}

/** A centred message with a single "Try again" button — used for every retryable failure. */
@Composable
private fun LyricsRetryState(
    @DrawableRes icon: Int,
    title: String,
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        EmptyState(
            icon    = icon,
            title   = title,
            message = message
        ) {
            MelodiqButton(
                text    = "Try again",
                onClick = onRetry,
                icon    = R.drawable.ic_refresh
            )
        }
    }
}
