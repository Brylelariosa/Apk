package com.melodiq.util

import com.melodiq.data.model.Song
import com.melodiq.data.network.LrcLibResponse
import kotlin.math.abs

/** What we ask LRCLIB for. [artist] and [album] are null when unknown. */
data class TrackQuery(
    val title: String,
    val artist: String? = null,
    val album: String? = null
)

/** Turns messy file-name style titles into something LRCLIB can match. */
object TitleCleaner {
    // "(Official Video)", "[Lyrics]", "(Remastered 2011)", "(HD)" ...
    private val NOISE_BRACKETS = Regex(
        """[(\[]\s*(official|lyric|lyrics|audio|video|music video|visuali[sz]er|hd|hq|4k|remaster|explicit|clean|full song|full audio)[^)\]]*[)\]]""",
        RegexOption.IGNORE_CASE
    )
    private val LEADING_TRACK_NUMBER = Regex("""^\s*\d{1,3}\s*[-.)]\s*""")
    private val ARTIST_TITLE_SPLIT   = Regex("""^(.{2,60}?)\s+[-–—]\s+(.{2,})$""")
    private val EXTRA_SPACES         = Regex("""\s+""")

    fun clean(raw: String): String = raw
        .replace('_', ' ')
        .replace(NOISE_BRACKETS, " ")
        .replace(LEADING_TRACK_NUMBER, "")
        .replace(EXTRA_SPACES, " ")
        .trim()

    /** "Artist - Title" → ("Artist", "Title"); null when the text has no such shape. */
    fun splitArtistTitle(cleaned: String): Pair<String, String>? {
        val match = ARTIST_TITLE_SPLIT.find(cleaned) ?: return null
        return match.groupValues[1].trim() to match.groupValues[2].trim()
    }
}

/** Pure functions (no Android, no network) that decide what to ask for and which answer to trust. */
object TrackMatcher {
    private const val MAX_DURATION_DIFF_SEC = 5.0
    private const val CLOSE_DURATION_SEC = 2.0

    private enum class ArtistMatch { EXACT, PARTIAL, UNKNOWN, MISMATCH }

    private val BRACKETED = Regex("""\(.*?\)|\[.*?\]""")
    private val NON_ALNUM = Regex("""[^\p{L}\p{N}]+""")

    fun normalize(text: String): String =
        text.lowercase().replace(BRACKETED, " ").replace(NON_ALNUM, " ").trim()

    /**
     * Ordered list of lookups to try, most specific first. A song without an artist tag
     * still gets a title-only query, plus an "Artist - Title" split when the file name
     * (which MediaStore uses as the title) contains one.
     */
    fun buildQueries(song: Song): List<TrackQuery> {
        val artist   = song.artist.takeIf { MediaTags.isKnown(it) }?.trim()
        val album    = song.album.takeIf { MediaTags.isKnown(it) }?.trim()
        val rawTitle = song.title.trim()
        val cleaned  = TitleCleaner.clean(rawTitle).ifBlank { rawTitle }

        val queries = LinkedHashSet<TrackQuery>()
        queries += TrackQuery(cleaned, artist, album)
        TitleCleaner.splitArtistTitle(cleaned)?.let { (a, t) -> queries += TrackQuery(t, a) }
        if (rawTitle.isNotEmpty() && rawTitle != cleaned) queries += TrackQuery(rawTitle, artist, album)
        return queries.toList()
    }

    /**
     * Picks the search result most likely to be the same recording, or null.
     *
     * Automatic mode ([lenient] = false) only accepts a result when there is real evidence:
     *  - artist matches and the title is the same (or the length is within 2 s), or
     *  - the artist is unknown/untagged, the title is exactly the same AND the length is within 5 s.
     * A title that merely *contains* the wanted words ("Love" vs "Love Story") is never enough
     * on its own. Manual mode ([lenient] = true) trusts the title the user typed.
     */
    fun pickBest(
        candidates: List<LrcLibResponse>,
        query: TrackQuery,
        durationSec: Int?,
        lenient: Boolean = false
    ): LrcLibResponse? {
        val wantedTitle  = normalize(query.title)
        val wantedArtist = query.artist?.let { normalize(it) }?.takeIf { it.isNotEmpty() }
        if (wantedTitle.isEmpty()) return null

        var best: LrcLibResponse? = null
        var bestScore = Int.MIN_VALUE
        for (record in candidates) {
            if (!record.hasLyrics()) continue
            val score = scoreRecord(record, wantedTitle, wantedArtist, durationSec, lenient) ?: continue
            if (score > bestScore) {
                best = record
                bestScore = score
            }
        }
        return best
    }

    /** Null means "not the same song"; otherwise a score used only to rank the accepted results. */
    private fun scoreRecord(
        record: LrcLibResponse,
        wantedTitle: String,
        wantedArtist: String?,
        durationSec: Int?,
        lenient: Boolean
    ): Int? {
        val title = normalize(record.trackName.orEmpty())
        if (title.isEmpty()) return null
        val titleExact = title == wantedTitle
        if (!titleExact && !partialMatch(title, wantedTitle)) return null

        val artistMatch = matchArtist(record.artistName, wantedArtist)

        val recordDuration = record.duration
        val diff: Double? =
            if (durationSec != null && recordDuration != null) abs(recordDuration - durationSec) else null
        if (diff != null && diff > MAX_DURATION_DIFF_SEC) return null

        if (!lenient) {
            val trusted = when (artistMatch) {
                ArtistMatch.EXACT    -> titleExact || (diff != null && diff <= CLOSE_DURATION_SEC)
                ArtistMatch.PARTIAL  -> titleExact
                ArtistMatch.UNKNOWN  -> titleExact && diff != null
                ArtistMatch.MISMATCH -> titleExact && diff != null && diff <= CLOSE_DURATION_SEC
            }
            if (!trusted) return null
        }

        var score = if (titleExact) 4 else 1
        score += when (artistMatch) {
            ArtistMatch.EXACT    -> 3
            ArtistMatch.PARTIAL  -> 1
            ArtistMatch.UNKNOWN  -> 0
            ArtistMatch.MISMATCH -> -3
        }
        if (diff != null) score += if (diff <= CLOSE_DURATION_SEC) 3 else 1
        if (!record.syncedLyrics.isNullOrBlank()) score += 1
        return score
    }

    private fun matchArtist(recordArtist: String?, wantedArtist: String?): ArtistMatch {
        if (wantedArtist == null) return ArtistMatch.UNKNOWN
        val artist = normalize(recordArtist.orEmpty())
        return when {
            artist.isEmpty()                   -> ArtistMatch.UNKNOWN
            artist == wantedArtist             -> ArtistMatch.EXACT
            partialMatch(artist, wantedArtist) -> ArtistMatch.PARTIAL
            else                               -> ArtistMatch.MISMATCH
        }
    }

    private fun partialMatch(a: String, b: String): Boolean {
        val shorter = if (a.length < b.length) a else b
        return shorter.length >= 3 && (a.contains(b) || b.contains(a))
    }
}
