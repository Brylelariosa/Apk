package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.repository.LyricsRepository
import com.melodiq.player.PlayerManager
import com.melodiq.util.LrcParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException   // FIX: explicit import for rethrow
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LyricsViewModel @Inject constructor(
    private val lyricsRepository: LyricsRepository,
    private val playerManager: PlayerManager
) : ViewModel() {

    private val _lyricsResult = MutableStateFlow<LyricsResult>(LyricsResult.Loading)
    val lyricsResult: StateFlow<LyricsResult> = _lyricsResult.asStateFlow()

    private val _currentLineIndex = MutableStateFlow(-1)
    val currentLineIndex: StateFlow<Int> = _currentLineIndex.asStateFlow()

    private val _lyricOffset = MutableStateFlow(0L)
    val lyricOffset: StateFlow<Long> = _lyricOffset.asStateFlow()

    private var syncJob: Job? = null
    private var fetchJob: Job? = null
    private var currentSong: Song? = null

    fun loadLyrics(song: Song) {
        if (song.id == currentSong?.id) return
        currentSong = song
        syncJob?.cancel()
        fetchJob?.cancel()
        _lyricsResult.value = LyricsResult.Loading
        _currentLineIndex.value = -1

        fetchJob = viewModelScope.launch {
            val result = try {
                lyricsRepository.getLyrics(song, _lyricOffset.value)
            } catch (e: CancellationException) {
                // FIX: the original code used catch (e: Exception) which also catches
                // CancellationException (it extends RuntimeException → Exception).
                // When the previous fetchJob was cancelled via fetchJob?.cancel(), the
                // CancellationException propagated up from withContext(IO), was swallowed
                // here, and the cancelled job went on to set _lyricsResult = NotFound —
                // overwriting the Loading state the new job had just written.
                // Always rethrow CancellationException so the coroutine machinery can
                // clean up properly and the job truly stops here.
                throw e
            } catch (e: Exception) {
                LyricsResult.NotFound
            }
            _lyricsResult.value = result
            if (result is LyricsResult.Synced) {
                startSyncLoop(result)
            }
        }
    }

    fun setOffset(offsetMs: Long) {
        _lyricOffset.value = offsetMs
        currentSong?.let { song ->
            currentSong = null   // force reload
            loadLyrics(song)
        }
    }

    private fun startSyncLoop(synced: LyricsResult.Synced) {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            while (isActive) {
                val position = playerManager.getCurrentPosition()
                val idx = LrcParser.activeIndex(synced.lines, position)
                if (_currentLineIndex.value != idx) {
                    _currentLineIndex.value = idx
                }
                delay(100L)
            }
        }
    }

    override fun onCleared() {
        syncJob?.cancel()
        fetchJob?.cancel()
        super.onCleared()
    }
}
