package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.repository.LyricsRepository
import com.melodiq.player.PlayerManager
import com.melodiq.util.LrcParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LyricsViewModel @Inject constructor(
    private val lyricsRepository: LyricsRepository,
    private val playerManager: PlayerManager
) : ViewModel() {

    private val _lyricsResult = MutableStateFlow<LyricsResult>(LyricsResult.Loading)
    val lyricsResult: StateFlow<LyricsResult> = _lyricsResult.asStateFlow()

    private val _currentLineIndex = MutableStateFlow(-1)
    val currentLineIndex: StateFlow<Int> = _currentLineIndex.asStateFlow()

    private val _lyricOffset = MutableStateFlow(0L)
    val lyricOffset: StateFlow<Long> = _lyricOffset.asStateFlow()

    private var syncJob: Job? = null
    private var fetchJob: Job? = null
    private var currentSong: Song? = null

    /** Loads lyrics for [song]; does nothing if they are already loaded for the same song. */
    fun loadLyrics(song: Song) {
        if (song.id == currentSong?.id) return
        currentSong = song
        runFetch { lyricsRepository.getLyrics(song, _lyricOffset.value) }
    }

    /** "Try again" button: skips the cache and asks the service again. */
    fun retry() {
        val song = currentSong ?: return
        runFetch { lyricsRepository.getLyrics(song, _lyricOffset.value, forceRefresh = true) }
    }

    /** "Search manually" button: the user typed a title and/or artist themselves. */
    fun searchManually(title: String, artist: String) {
        val song = currentSong ?: return
        runFetch { lyricsRepository.searchManually(song, title, artist, _lyricOffset.value) }
    }

    fun setOffset(offsetMs: Long) {
        _lyricOffset.value = offsetMs
        val song = currentSong ?: return
        runFetch { lyricsRepository.getLyrics(song, offsetMs) }   // served from cache
    }

    private fun runFetch(fetch: suspend () -> LyricsResult) {
        syncJob?.cancel()
        fetchJob?.cancel()
        _lyricsResult.value = LyricsResult.Loading
        _currentLineIndex.value = -1

        fetchJob = viewModelScope.launch {
            val result = try {
                fetch()
            } catch (e: CancellationException) {
                // Never swallow cancellation: a cancelled job must not overwrite the
                // Loading state the newer job just wrote.
                throw e
            } catch (e: Exception) {
                LyricsResult.Offline
            }
            _lyricsResult.value = result
            if (result is LyricsResult.Synced) startSyncLoop(result)
        }
    }

    private fun startSyncLoop(synced: LyricsResult.Synced) {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            while (isActive) {
                val position = playerManager.getCurrentPosition()
                val idx = LrcParser.activeIndex(synced.lines, position)
                if (_currentLineIndex.value != idx) {
                    _currentLineIndex.value = idx
                }
                delay(100L)
            }
        }
    }

    override fun onCleared() {
        syncJob?.cancel()
        fetchJob?.cancel()
        super.onCleared()
    }
}
