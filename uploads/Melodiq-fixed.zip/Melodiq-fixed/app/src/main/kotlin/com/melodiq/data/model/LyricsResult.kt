package com.melodiq.data.model

sealed class LyricsResult {
    object Loading : LyricsResult()
    /** The service answered, but has no lyrics for this song. */
    object NotFound : LyricsResult()
    /** We could not reach the service (offline, timeout, server error). Worth retrying. */
    object Offline : LyricsResult()
    data class Synced(val lines: List<LyricLine>) : LyricsResult()
    data class Plain(val text: String) : LyricsResult()
}
