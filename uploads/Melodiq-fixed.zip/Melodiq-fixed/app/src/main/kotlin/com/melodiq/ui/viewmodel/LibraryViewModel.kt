package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val allSongs:       List<Song> = emptyList(),
    val recentSongs:    List<Song> = emptyList(),
    val favoriteSongs:  List<Song> = emptyList(),
    val isLoading:      Boolean    = false,
    val permissionGranted: Boolean = false,
    val syncCount:      Int        = 0,
    // BUG FIX C: surface scan errors so the UI can show a helpful message
    // instead of silently staying empty forever.
    val scanError:      String?    = null
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val musicRepository: MusicRepository
) : ViewModel() {

    private val _isLoading  = MutableStateFlow(false)
    private val _scanError  = MutableStateFlow<String?>(null)

    val uiState: StateFlow<LibraryUiState> = combine(
        musicRepository.allSongs,
        musicRepository.recentSongs,
        musicRepository.favoriteSongs,
        _isLoading,
        _scanError
    ) { all, recent, fav, loading, error ->
        LibraryUiState(
            allSongs      = all,
            recentSongs   = recent,
            favoriteSongs = fav,
            isLoading     = loading,
            scanError     = error
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryUiState())

    fun syncLibrary() {
        if (_isLoading.value) return          // prevent concurrent scans
        viewModelScope.launch {
            _isLoading.value = true
            _scanError.value = null
            try {
                musicRepository.syncLibrary()
            } catch (e: SecurityException) {
                // BUG FIX C: the original syncLibrary() had no try/catch.
                // If Android throws SecurityException during the OS permission
                // propagation window (permission check passes but ContentProvider
                // isn't ready yet), the coroutine died silently, _isLoading stayed
                // true forever, and the app showed an infinite loading spinner.
                _scanError.value = "Storage permission error — please try again."
            } catch (e: Exception) {
                _scanError.value = "Could not scan library: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
}
