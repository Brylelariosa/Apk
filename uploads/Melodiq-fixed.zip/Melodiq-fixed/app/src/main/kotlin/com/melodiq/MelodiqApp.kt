package com.melodiq

import android.app.Application
import android.content.Context
import com.melodiq.crash.CrashReporter
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MelodiqApp : Application() {

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // Earliest hook the app has: a crash while Hilt or Room are starting up is logged too.
        CrashReporter.install(this)
    }
}
