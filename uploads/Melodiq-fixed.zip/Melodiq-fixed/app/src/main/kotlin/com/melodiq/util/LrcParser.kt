package com.melodiq.util

import com.melodiq.data.model.LyricLine

object LrcParser {
    // [mm:ss.xx]  [mm:ss.xxx]  [m:ss]  [mm:ss:xx]  — fraction is optional
    private val TIMESTAMP_REGEX = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")
    // Metadata tags like [ar:Artist], [ti:Title], [offset:+300] ...
    private val METADATA_REGEX = Regex("""\[[a-zA-Z]+:.*?\]""")
    // Enhanced-LRC word timings such as <00:12.34>
    private val WORD_TAG_REGEX = Regex("""<\d{1,3}:\d{2}(?:[.:]\d{1,3})?>""")

    fun parse(lrc: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        lrc.lines().forEach { line ->
            val trimmed = line.trim()
            if (METADATA_REGEX.matches(trimmed)) return@forEach
            val timestamps = TIMESTAMP_REGEX.findAll(trimmed).toList()
            if (timestamps.isEmpty()) return@forEach

            val text = WORD_TAG_REGEX
                .replace(TIMESTAMP_REGEX.replace(trimmed, ""), "")
                .trim()
            if (text.isEmpty()) return@forEach

            timestamps.forEach { match ->
                val minutes  = match.groupValues[1].toLong()
                val seconds  = match.groupValues[2].toLong()
                val fraction = match.groupValues[3]            // "" when absent
                val millis = when (fraction.length) {
                    0    -> 0L
                    1    -> fraction.toLong() * 100L
                    2    -> fraction.toLong() * 10L             // centiseconds → ms
                    else -> fraction.take(3).toLong()
                }
                lines.add(LyricLine(minutes * 60_000L + seconds * 1_000L + millis, text))
            }
        }
        return lines.sortedBy { it.timeMs }
    }

    /** Binary search: returns index of the active lyric for [positionMs]. */
    fun activeIndex(lines: List<LyricLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var lo = 0
        var hi = lines.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (lines[mid].timeMs <= positionMs) lo = mid else hi = mid - 1
        }
        return if (lines[lo].timeMs <= positionMs) lo else -1
    }
}
