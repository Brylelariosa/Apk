package com.melodiq.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.components.ArtworkImage
import com.melodiq.ui.components.EmptyState
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.components.VectorIcon
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel

@Composable
fun HomeScreen(
    onNavigateToNowPlaying: () -> Unit,
    libraryVm: LibraryViewModel,
    playerVm: PlayerViewModel
) {
    val uiState     by libraryVm.uiState.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()
    val currentId   = playerState.currentSong?.id

    LazyColumn(
        modifier       = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item { HomeHeader() }

        // Recently Played
        if (uiState.recentSongs.isNotEmpty()) {
            item { SectionHeader("Recently played") }
            item {
                LazyRow(
                    contentPadding        = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(uiState.recentSongs, key = { _, s -> "rec_${s.id}" }) { idx, song ->
                        RecentSongCard(
                            song      = song,
                            isCurrent = currentId == song.id,
                            onClick   = {
                                playerVm.playSongs(uiState.recentSongs, idx)
                                onNavigateToNowPlaying()
                            }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // Favorites
        if (uiState.favoriteSongs.isNotEmpty()) {
            item { SectionHeader("Favorites") }
            itemsIndexed(
                uiState.favoriteSongs.take(8),
                key = { _, s -> "fav_${s.id}" }
            ) { idx, song ->
                SongItem(
                    song            = song,
                    isCurrent       = currentId == song.id,
                    isPlaying       = playerState.isPlaying,
                    onClick         = {
                        playerVm.playSongs(uiState.favoriteSongs, idx)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) }
                )
            }
        }

        // All Songs preview
        if (uiState.allSongs.isNotEmpty()) {
            item { SectionHeader("All songs") }
            itemsIndexed(
                uiState.allSongs.take(20),
                key = { _, s -> "all_${s.id}" }
            ) { idx, song ->
                SongItem(
                    song            = song,
                    isCurrent       = currentId == song.id,
                    isPlaying       = playerState.isPlaying,
                    onClick         = {
                        playerVm.playSongs(uiState.allSongs, idx)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) }
                )
            }
        }

        // Empty / error state
        if (uiState.allSongs.isEmpty() && !uiState.isLoading) {
            item {
                EmptyState(
                    icon    = R.drawable.ic_library_music,
                    title   = "No music found",
                    message = uiState.scanError
                        ?: "Add songs to your phone, then scan again. Only audio files of 30 seconds or more are listed.",
                    modifier = Modifier.padding(top = 64.dp)
                ) {
                    MelodiqButton(
                        text    = "Scan library",
                        onClick = libraryVm::syncLibrary,
                        icon    = R.drawable.ic_refresh
                    )
                }
            }
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier         = Modifier
                        .fillMaxWidth()
                        .padding(top = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PrimaryPurple)
                }
            }
        }
    }
}

@Composable
private fun HomeHeader() {
    Row(
        modifier          = Modifier.padding(horizontal = 20.dp, vertical = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(PrimaryPurple, AccentViolet))),
            contentAlignment = Alignment.Center
        ) {
            VectorIcon(id = R.drawable.ic_music_note, tint = androidx.compose.ui.graphics.Color.White, size = 28.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(
                text  = "Good ${greeting()},",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Text(
                text  = "Melodiq",
                style = MaterialTheme.typography.displaySmall,
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun RecentSongCard(song: Song, isCurrent: Boolean, onClick: () -> Unit) {
    Column(
        modifier            = Modifier
            .width(120.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ArtworkImage(
            uri                = song.artworkUri,
            contentDescription = song.title,
            shape              = RoundedCornerShape(14.dp),
            modifier           = Modifier.size(108.dp)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text     = song.title,
            style    = MaterialTheme.typography.labelMedium,
            color    = if (isCurrent) PrimaryPurple else TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text     = song.artist,
            style    = MaterialTheme.typography.labelSmall,
            color    = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text     = title,
        style    = MaterialTheme.typography.titleMedium,
        color    = TextPrimary,
        modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 4.dp, end = 16.dp)
    )
}

private fun greeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "morning"
        hour < 17 -> "afternoon"
        else      -> "evening"
    }
}
