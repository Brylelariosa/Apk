package com.melodiq.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.melodiq.data.model.Song
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.theme.*
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel

@Composable
fun HomeScreen(
    onNavigateToNowPlaying: () -> Unit,
    libraryVm: LibraryViewModel = hiltViewModel(),
    playerVm:  PlayerViewModel  = hiltViewModel()
) {
    val uiState     by libraryVm.uiState.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()

    // BUG FIX: HomeScreen had no sync trigger and no retry button in its empty state.
    // LibraryScreen had both; HomeScreen had neither — so if the initial AppRoot sync
    // failed (e.g. the deleteOrphans race or a transient SecurityException), HomeScreen
    // would forever show "No music found" with no way out except discovering the hidden
    // refresh icon in the Library tab.
    //
    // Fix: mirror LibraryScreen's LaunchedEffect so HomeScreen self-heals on the next
    // composition after a failed sync. The scan is cheap (Room is already warm) and the
    // isNotEmpty() guard in syncLibrary() prevents the deleteOrphans wipe if MediaStore
    // still returns 0 at this exact moment.
    LaunchedEffect(Unit) {
        if (uiState.allSongs.isEmpty()) libraryVm.syncLibrary()
    }

    LazyColumn(
        modifier       = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Greeting header
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 24.dp)) {
                Text(
                    text  = "Good ${greeting()},",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Text(
                    text  = "Melodiq",
                    style = MaterialTheme.typography.displaySmall,
                    color = TextPrimary
                )
            }
        }

        // Recently Played
        if (uiState.recentSongs.isNotEmpty()) {
            item { SectionHeader("Recently Played") }
            item {
                LazyRow(
                    contentPadding        = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(uiState.recentSongs, key = { _, s -> "rec_${s.id}" }) { idx, song ->
                        RecentSongCard(
                            song      = song,
                            isPlaying = playerState.currentSong?.id == song.id && playerState.isPlaying,
                            onClick   = {
                                playerVm.playSongs(uiState.recentSongs, idx)
                                onNavigateToNowPlaying()
                            }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // Favorites
        if (uiState.favoriteSongs.isNotEmpty()) {
            item { SectionHeader("Favorites") }
            itemsIndexed(
                uiState.favoriteSongs.take(8),
                key = { _, s -> "fav_${s.id}" }
            ) { idx, song ->
                SongItem(
                    song            = song,
                    isPlaying       = playerState.currentSong?.id == song.id && playerState.isPlaying,
                    onClick         = {
                        playerVm.playSongs(uiState.favoriteSongs, idx)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) }
                )
            }
        }

        // All Songs preview
        if (uiState.allSongs.isNotEmpty()) {
            item { SectionHeader("All Songs") }
            itemsIndexed(
                uiState.allSongs.take(20),
                key = { _, s -> "all_${s.id}" }
            ) { idx, song ->
                SongItem(
                    song            = song,
                    isPlaying       = playerState.currentSong?.id == song.id && playerState.isPlaying,
                    onClick         = {
                        playerVm.playSongs(uiState.allSongs, idx)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) }
                )
            }
        }

        // Empty / error state
        if (uiState.allSongs.isEmpty() && !uiState.isLoading) {
            item {
                Box(
                    modifier         = Modifier
                        .fillMaxWidth()
                        .padding(top = 64.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎵", style = MaterialTheme.typography.displayLarge)
                        Spacer(Modifier.height(16.dp))

                        if (uiState.scanError != null) {
                            Text(
                                uiState.scanError,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            Text(
                                "No music found",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Grant storage permission and add music to your device",
                                color = TextMuted,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Spacer(Modifier.height(20.dp))
                        // BUG FIX: give users a visible retry path on HomeScreen,
                        // not just the hidden refresh icon buried in the Library tab.
                        Button(
                            onClick = { libraryVm.syncLibrary() },
                            colors  = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                        ) {
                            Text(
                                "Scan Library",
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Loading indicator
        if (uiState.isLoading) {
            item {
                Box(
                    modifier         = Modifier.fillMaxWidth().padding(top = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PrimaryPurple)
                }
            }
        }
    }
}

@Composable
private fun RecentSongCard(song: Song, isPlaying: Boolean, onClick: () -> Unit) {
    Column(
        modifier            = Modifier
            .width(120.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AsyncImage(
            model              = song.artworkUri,
            contentDescription = song.title,
            contentScale       = ContentScale.Crop,
            modifier           = Modifier
                .size(108.dp)
                .clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text     = song.title,
            style    = MaterialTheme.typography.labelMedium,
            color    = if (isPlaying) PrimaryPurple else TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text     = song.artist,
            style    = MaterialTheme.typography.labelSmall,
            color    = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text     = title,
        style    = MaterialTheme.typography.titleMedium,
        color    = TextPrimary,
        modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 4.dp, end = 16.dp)
    )
}

private fun greeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "morning"
        hour < 17 -> "afternoon"
        else      -> "evening"
    }
}
