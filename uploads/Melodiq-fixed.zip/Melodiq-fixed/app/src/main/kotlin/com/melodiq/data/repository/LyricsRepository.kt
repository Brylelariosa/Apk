package com.melodiq.data.repository

import com.melodiq.data.db.dao.LyricsDao
import com.melodiq.data.db.entity.LyricsEntity
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.network.LrcLibResponse
import com.melodiq.data.network.LrcLibService
import com.melodiq.util.LrcParser
import com.melodiq.util.LyricsCleanup
import com.melodiq.util.MediaTags
import com.melodiq.util.TitleCleaner
import com.melodiq.util.TrackMatcher
import com.melodiq.util.TrackQuery
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Finds lyrics for a song.
 *
 * Lookup order (stops at the first hit):
 *  1. LRCLIB exact lookup  (/api/get)     — only when the song has an artist tag
 *  2. LRCLIB field search  (/api/search)  — works with title only, results are scored
 *     by title + duration (+ artist when known) so untagged songs can still match
 *  3. LRCLIB free-text search (q=…)       — last resort
 *
 * Each step is tried for every query from [TrackMatcher.buildQueries] (cleaned title,
 * "Artist - Title" split, raw title). Hits are cached 30 days, misses 1 day, and
 * network failures are never cached.
 */
@Singleton
class LyricsRepository @Inject constructor(
    private val lrcLibService: LrcLibService,
    private val lyricsDao: LyricsDao
) {
    companion object {
        private const val HIT_TTL_MS  = 30L * 24 * 60 * 60 * 1000   // 30 days — found lyrics
        private const val MISS_TTL_MS = 24L * 60 * 60 * 1000        // 1 day  — not found
        // Bumping this invalidates every cached entry (old versions cached misses caused by the
        // "<unknown>" artist bug, which would otherwise hide lyrics for up to a day).
        private const val CACHE_VERSION = "v2"
    }

    private sealed interface Lookup {
        data class Found(val record: LrcLibResponse) : Lookup
        object Missing : Lookup        // service answered: nothing there
        object Unavailable : Lookup    // offline / timeout / server error: never cache
    }

    private sealed interface Reply<out T> {
        data class Body<T>(val value: T?) : Reply<T>
        object NotFound : Reply<Nothing>
        object Failed : Reply<Nothing>
    }

    suspend fun getLyrics(
        song: Song,
        offsetMs: Long = 0L,
        forceRefresh: Boolean = false
    ): LyricsResult = withContext(Dispatchers.IO) {
        val key    = cacheKey(song)
        val cached = lyricsDao.getByKey(key)

        if (cached != null && !forceRefresh && !cached.isStale()) {
            return@withContext parseCached(cached, offsetMs)
        }

        when (val lookup = lookUp(TrackMatcher.buildQueries(song), durationSeconds(song))) {
            is Lookup.Found -> {
                val entity = song.toEntity(key, lookup.record)
                lyricsDao.upsert(entity)
                parseCached(entity, offsetMs)
            }
            Lookup.Missing -> {
                lyricsDao.upsert(song.toEntity(key, record = null))
                LyricsResult.NotFound
            }
            Lookup.Unavailable -> {
                val fallback = cached?.let { parseCached(it, offsetMs) }
                if (fallback != null && fallback !is LyricsResult.NotFound) fallback
                else LyricsResult.Offline
            }
        }
    }

    /**
     * Lets the user type the title/artist themselves (e.g. a song with no artist tag).
     * Duration is ignored here because the user is deliberately choosing a version.
     */
    suspend fun searchManually(
        song: Song,
        title: String,
        artist: String,
        offsetMs: Long = 0L
    ): LyricsResult = withContext(Dispatchers.IO) {
        val cleanTitle = TitleCleaner.clean(title).ifBlank { title.trim() }
        if (cleanTitle.isBlank()) return@withContext LyricsResult.NotFound

        val query = TrackQuery(
            title  = cleanTitle,
            artist = artist.trim().takeIf { MediaTags.isKnown(it) }
        )
        when (val lookup = lookUp(listOf(query), durationSec = null, lenient = true)) {
            is Lookup.Found -> {
                val entity = song.toEntity(cacheKey(song), lookup.record)
                lyricsDao.upsert(entity)
                parseCached(entity, offsetMs)
            }
            Lookup.Missing     -> LyricsResult.NotFound
            Lookup.Unavailable -> LyricsResult.Offline
        }
    }

    suspend fun storeLrcFile(song: Song, lrcContent: String) = withContext(Dispatchers.IO) {
        lyricsDao.upsert(
            LyricsEntity(
                cacheKey     = cacheKey(song),
                syncedLyrics = lrcContent,
                plainLyrics  = null,
                trackTitle   = song.title,
                artistName   = song.artist,
                albumName    = song.album
            )
        )
    }

    suspend fun purgeOldCache() = withContext(Dispatchers.IO) {
        lyricsDao.purgeOlderThan(System.currentTimeMillis() - HIT_TTL_MS)
    }

    // ── Network ──────────────────────────────────────────────────────────────

    private suspend fun lookUp(
        queries: List<TrackQuery>,
        durationSec: Int?,
        lenient: Boolean = false
    ): Lookup {
        for (query in queries) {
            // 1) exact signature — needs an artist
            if (query.artist != null) {
                val reply = call {
                    lrcLibService.getLyrics(query.artist, query.title, query.album, durationSec)
                }
                when (reply) {
                    is Reply.Body  -> reply.value?.takeIf { it.hasLyrics() }?.let { return Lookup.Found(it) }
                    Reply.NotFound -> Unit
                    Reply.Failed   -> return Lookup.Unavailable
                }
            }

            // 2) field search — title only is fine
            val search = call {
                lrcLibService.search(trackName = query.title, artistName = query.artist)
            }
            when (search) {
                is Reply.Body -> {
                    val best = TrackMatcher.pickBest(search.value.orEmpty(), query, durationSec, lenient)
                    if (best != null) return Lookup.Found(best)
                }
                Reply.NotFound -> Unit
                Reply.Failed   -> return Lookup.Unavailable
            }
        }

        // 3) free-text search with the most specific query
        val first = queries.firstOrNull() ?: return Lookup.Missing
        val text  = listOfNotNull(first.artist, first.title).joinToString(" ")
        val free  = call { lrcLibService.search(query = text) }
        when (free) {
            is Reply.Body -> {
                val best = TrackMatcher.pickBest(free.value.orEmpty(), first, durationSec, lenient)
                if (best != null) return Lookup.Found(best)
            }
            Reply.NotFound -> Unit
            Reply.Failed   -> return Lookup.Unavailable
        }
        return Lookup.Missing
    }

    private suspend fun <T> call(block: suspend () -> Response<T>): Reply<T> = try {
        val response = block()
        when {
            response.isSuccessful  -> Reply.Body(response.body())
            response.code() == 404 -> Reply.NotFound
            else                   -> Reply.Failed          // 429 / 5xx — try again later
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Reply.Failed                                        // offline, DNS, timeout, bad JSON
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun durationSeconds(song: Song): Int? =
        (song.duration / 1000).toInt().takeIf { it > 0 }

    private fun cacheKey(song: Song): String =
        "$CACHE_VERSION|${song.title.lowercase()}|${song.artist.lowercase()}|${song.duration / 1000}"

    private fun LyricsEntity.isStale(): Boolean {
        val isHit = !syncedLyrics.isNullOrBlank() || !plainLyrics.isNullOrBlank()
        val ttl   = if (isHit) HIT_TTL_MS else MISS_TTL_MS
        return System.currentTimeMillis() - fetchedAt >= ttl
    }

    private fun Song.toEntity(key: String, record: LrcLibResponse?) = LyricsEntity(
        cacheKey     = key,
        syncedLyrics = record?.syncedLyrics,
        plainLyrics  = record?.plainLyrics,
        trackTitle   = title,
        artistName   = artist,
        albumName    = album
    )

    private fun parseCached(entity: LyricsEntity, offsetMs: Long): LyricsResult {
        val synced = entity.syncedLyrics
        if (!synced.isNullOrBlank()) {
            val lines = LrcParser.parse(synced).map { line ->
                line.copy(
                    text   = LyricsCleanup.clean(line.text),
                    timeMs = (line.timeMs + offsetMs).coerceAtLeast(0L)
                )
            }.filter { it.text.isNotBlank() }
            if (lines.isNotEmpty()) return LyricsResult.Synced(lines)
        }

        val plain = entity.plainLyrics
        if (!plain.isNullOrBlank()) return LyricsResult.Plain(plain)

        return LyricsResult.NotFound
    }
}
