package com.melodiq.data.repository

import com.melodiq.data.db.dao.LyricsDao
import com.melodiq.data.db.entity.LyricsEntity
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.network.LrcLibService
import com.melodiq.util.LrcParser
import com.melodiq.util.LyricsCleanup
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LyricsRepository @Inject constructor(
    private val lrcLibService: LrcLibService,
    private val lyricsDao: LyricsDao
) {
    companion object {
        // FIX: the original code used a single 30-day CACHE_TTL_MS for both hits
        // and misses. A transient failure (brief network outage, missing User-Agent
        // causing a 403, LRCLIB being temporarily down) would cache a "not found"
        // result for a full month with no way to retry short of clearing app data.
        //
        // Solution: use a short TTL for misses (1 day) and a long TTL for confirmed
        // hits (30 days). A miss is any cache entry where both lyric fields are null/blank.
        private const val HIT_TTL_MS  = 30L * 24 * 60 * 60 * 1000   // 30 days — found lyrics
        private const val MISS_TTL_MS =       24 * 60 * 60 * 1000L  // 1 day  — not found
        // MediaStore placeholder when tags are absent
        private const val UNKNOWN_TAG = "<unknown>"
    }

    suspend fun getLyrics(song: Song, offsetMs: Long = 0L): LyricsResult =
        withContext(Dispatchers.IO) {
            val key = cacheKey(song)

            // 1. Check cache with TTL differentiated by hit vs miss
            val cached = lyricsDao.getByKey(key)
            if (cached != null) {
                val age   = System.currentTimeMillis() - cached.fetchedAt
                val isHit = !cached.syncedLyrics.isNullOrBlank() || !cached.plainLyrics.isNullOrBlank()
                val ttl   = if (isHit) HIT_TTL_MS else MISS_TTL_MS
                if (age < ttl) return@withContext parseCached(cached, offsetMs)
                // Cache expired — fall through to fetch a fresh result
            }

            // 2. Fetch from LRCLIB
            return@withContext try {
                // MediaStore uses "<unknown>" when tags are missing — omit those fields
                // so LRCLIB can match on title + duration alone
                val cleanArtist = song.artist.takeIf { it.isNotBlank() && it != UNKNOWN_TAG }
                val cleanAlbum  = song.album.takeIf  { it.isNotBlank() && it != UNKNOWN_TAG }
                val httpResp = lrcLibService.getLyrics(
                    artistName = cleanArtist,
                    trackName  = song.title,
                    albumName  = cleanAlbum,
                    duration   = (song.duration / 1000).toInt().takeIf { it > 0 }
                )
                val response = if (httpResp.isSuccessful) httpResp.body() else null

                if (response != null) {
                    val entity = LyricsEntity(
                        cacheKey     = key,
                        syncedLyrics = response.syncedLyrics,
                        plainLyrics  = response.plainLyrics,
                        trackTitle   = song.title,
                        artistName   = song.artist,
                        albumName    = song.album
                    )
                    lyricsDao.upsert(entity)
                    parseCached(entity, offsetMs)
                } else {
                    // Cache the miss — will be retried after MISS_TTL_MS (1 day)
                    lyricsDao.upsert(
                        LyricsEntity(
                            cacheKey     = key,
                            syncedLyrics = null,
                            plainLyrics  = null,
                            trackTitle   = song.title,
                            artistName   = song.artist,
                            albumName    = song.album
                        )
                    )
                    LyricsResult.NotFound
                }
            } catch (e: CancellationException) {
                throw e   // never swallow — lets the cancelled coroutine stop cleanly
            } catch (e: Exception) {
                // Network / IO error — serve from cache if available, else NotFound
                cached?.let { parseCached(it, offsetMs) } ?: LyricsResult.NotFound
            }
        }

    suspend fun storeLrcFile(song: Song, lrcContent: String) = withContext(Dispatchers.IO) {
        val key = cacheKey(song)
        lyricsDao.upsert(
            LyricsEntity(
                cacheKey     = key,
                syncedLyrics = lrcContent,
                plainLyrics  = null,
                trackTitle   = song.title,
                artistName   = song.artist,
                albumName    = song.album
            )
        )
    }

    suspend fun purgeOldCache() = withContext(Dispatchers.IO) {
        // Purge any entry older than the longest possible TTL
        lyricsDao.purgeOlderThan(System.currentTimeMillis() - HIT_TTL_MS)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun cacheKey(song: Song): String {
        val durationSec = song.duration / 1000
        return "${song.title.lowercase()}|${song.artist.lowercase()}|$durationSec"
    }

    private fun parseCached(entity: LyricsEntity, offsetMs: Long): LyricsResult {
        val synced = entity.syncedLyrics
        if (!synced.isNullOrBlank()) {
            val lines = LrcParser.parse(synced).map { line ->
                line.copy(
                    text   = LyricsCleanup.clean(line.text),
                    timeMs = (line.timeMs + offsetMs).coerceAtLeast(0L)
                )
            }.filter { it.text.isNotBlank() }
            if (lines.isNotEmpty()) return LyricsResult.Synced(lines)
        }

        val plain = entity.plainLyrics
        if (!plain.isNullOrBlank()) {
            return LyricsResult.Plain(plain)
        }

        return LyricsResult.NotFound
    }
}
