package com.melodiq.ui.screen

import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.components.AnimatedGradientBackground
import com.melodiq.ui.components.ArtworkImage
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.LyricsSearchDialog
import com.melodiq.ui.components.LyricsView
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.PlayerControls
import com.melodiq.ui.components.SleepTimerDialog
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LyricsViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.util.ColorExtractor
import com.melodiq.util.ExtractedColors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.isActive

@Composable
fun NowPlayingScreen(
    onBack: () -> Unit,
    playerVm: PlayerViewModel,
    lyricsVm: LyricsViewModel = hiltViewModel()
) {
    val state         by playerVm.state.collectAsStateWithLifecycle()
    val progressState = playerVm.progress.collectAsStateWithLifecycle()
    val lyricsResult  by lyricsVm.lyricsResult.collectAsStateWithLifecycle()
    val currentIndex  by lyricsVm.currentLineIndex.collectAsStateWithLifecycle()
    val sleepTimer    by playerVm.sleepTimer.collectAsStateWithLifecycle()

    var extractedColors  by remember { mutableStateOf(ExtractedColors()) }
    var showLyrics       by rememberSaveable { mutableStateOf(false) }
    var showSleepTimer   by remember { mutableStateOf(false) }
    var showLyricsSearch by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val song    = state.currentSong
    val accent  = extractedColors.vibrant

    // Pull accent colours out of the album art. Songs without art fall back to the default palette.
    LaunchedEffect(song?.artworkUri) {
        val uri = song?.artworkUri
        if (uri == null) {
            extractedColors = ExtractedColors()
            return@LaunchedEffect
        }
        try {
            val request = ImageRequest.Builder(context).data(uri).allowHardware(false).build()
            val result  = context.imageLoader.execute(request)
            val bitmap  = (result.drawable as? BitmapDrawable)?.bitmap
            extractedColors = if (result is SuccessResult && bitmap != null) {
                ColorExtractor.extract(bitmap)
            } else {
                ExtractedColors()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            extractedColors = ExtractedColors()
        }
    }

    // Load lyrics whenever the song changes
    LaunchedEffect(song?.id) {
        song?.let { lyricsVm.loadLyrics(it) }
    }

    val bg1 = ColorExtractor.darken(extractedColors.dominant, 0.4f)
    val bg2 = ColorExtractor.darken(extractedColors.vibrant, 0.35f)
    val bg3 = Color(0xFF0D0D1A)

    AnimatedGradientBackground(color1 = bg1, color2 = bg2, color3 = bg3) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopBar(onBack = onBack)

            AnimatedContent(
                targetState    = showLyrics,
                modifier       = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                transitionSpec = {
                    (slideInHorizontally { if (targetState) it else -it } + fadeIn()) togetherWith
                        (slideOutHorizontally { if (targetState) -it else it } + fadeOut())
                },
                label = "now_playing_panels"
            ) { lyricsMode ->
                if (lyricsMode) {
                    LyricsView(
                        result           = lyricsResult,
                        currentIndex     = currentIndex,
                        hasArtist        = song?.hasArtist ?: true,
                        onRetry          = lyricsVm::retry,
                        onSearchManually = { showLyricsSearch = true },
                        accentColor      = accent,
                        modifier         = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier            = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AlbumArtSection(
                            song      = song,
                            isPlaying = state.isPlaying,
                            modifier  = Modifier.weight(1f)
                        )
                        SongInfoSection(
                            song       = song,
                            onFavorite = { song?.let { playerVm.toggleFavorite(it) } }
                        )
                    }
                }
            }

            PlayerControls(
                state             = state,
                progress          = { progressState.value },
                onTogglePlayPause = playerVm::togglePlayPause,
                onSeekToNext      = playerVm::seekToNext,
                onSeekToPrevious  = playerVm::seekToPrevious,
                onSeekTo          = playerVm::seekTo,
                onToggleShuffle   = playerVm::toggleShuffle,
                onCycleRepeat     = playerVm::cycleRepeatMode,
                accentColor       = accent,
                modifier          = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            )

            ActionRow(
                showingLyrics  = showLyrics,
                sleepActive    = sleepTimer != null,
                accent         = accent,
                onToggleLyrics = { showLyrics = !showLyrics },
                onSleepTimer   = { showSleepTimer = true }
            )
        }
    }

    if (showSleepTimer) {
        SleepTimerDialog(
            timer         = sleepTimer,
            onDismiss     = { showSleepTimer = false },
            onSetTimer    = { minutes ->
                playerVm.setSleepTimer(minutes)
                showSleepTimer = false
            },
            onCancelTimer = {
                playerVm.cancelSleepTimer()
                showSleepTimer = false
            }
        )
    }

    if (showLyricsSearch && song != null) {
        LyricsSearchDialog(
            initialTitle  = song.title,
            initialArtist = if (song.hasArtist) song.artist else "",
            onDismiss     = { showLyricsSearch = false },
            onSearch      = { title, artist ->
                showLyricsSearch = false
                lyricsVm.searchManually(title, artist)
            }
        )
    }
}

@Composable
private fun TopBar(onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconActionButton(
            icon               = R.drawable.ic_chevron_down,
            contentDescription = "Close player",
            onClick            = onBack,
            tint               = Color.White,
            buttonSize         = 48.dp,
            iconSize           = 28.dp
        )
        Text(
            text      = "Now playing",
            style     = MaterialTheme.typography.titleMedium,
            color     = Color.White,
            textAlign = TextAlign.Center,
            modifier  = Modifier.weight(1f)
        )
        Spacer(Modifier.size(48.dp))   // balances the close button so the title stays centred
    }
}

@Composable
private fun AlbumArtSection(song: Song?, isPlaying: Boolean, modifier: Modifier) {
    // The cover turns while music plays and stops exactly where it is when paused.
    val angle = remember { Animatable(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isActive) {
                angle.snapTo(angle.value % 360f)
                angle.animateTo(angle.value + 360f, tween(durationMillis = 20_000, easing = LinearEasing))
            }
        }
    }

    Box(modifier = modifier.padding(horizontal = 32.dp), contentAlignment = Alignment.Center) {
        ArtworkImage(
            uri      = song?.artworkUri,
            shape    = CircleShape,
            modifier = Modifier
                .size(280.dp)
                .graphicsLayer { rotationZ = angle.value }
        )
    }
}

@Composable
private fun SongInfoSection(song: Song?, onFavorite: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = song?.title ?: "No track",
                style    = MaterialTheme.typography.headlineSmall,
                color    = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text     = song?.artist ?: "",
                style    = MaterialTheme.typography.bodyMedium,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        val isFavorite = song?.isFavorite == true
        IconActionButton(
            icon               = if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border,
            contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
            onClick            = onFavorite,
            tint               = if (isFavorite) AccentPink else TextSecondary,
            buttonSize         = 48.dp,
            iconSize           = 26.dp
        )
    }
}

@Composable
private fun ActionRow(
    showingLyrics: Boolean,
    sleepActive: Boolean,
    accent: Color,
    onToggleLyrics: () -> Unit,
    onSleepTimer: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
    ) {
        MelodiqButton(
            text    = if (showingLyrics) "Hide lyrics" else "Lyrics",
            onClick = onToggleLyrics,
            icon    = R.drawable.ic_lyrics,
            style   = if (showingLyrics) ButtonStyle.Filled else ButtonStyle.Tonal,
            accent  = accent
        )
        MelodiqButton(
            text    = "Sleep timer",
            onClick = onSleepTimer,
            icon    = R.drawable.ic_sleep,
            style   = if (sleepActive) ButtonStyle.Filled else ButtonStyle.Tonal,
            accent  = accent
        )
    }
}
