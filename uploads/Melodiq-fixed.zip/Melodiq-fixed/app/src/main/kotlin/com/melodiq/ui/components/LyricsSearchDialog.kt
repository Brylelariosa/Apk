package com.melodiq.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary

/** Lets the user type the title/artist themselves — the fix for songs with no artist tag. */
@Composable
fun LyricsSearchDialog(
    initialTitle: String,
    initialArtist: String,
    onDismiss: () -> Unit,
    onSearch: (title: String, artist: String) -> Unit
) {
    var title  by rememberSaveable { mutableStateOf(initialTitle) }
    var artist by rememberSaveable { mutableStateOf(initialArtist) }
    val canSearch = title.isNotBlank()

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor   = PrimaryPurple,
        unfocusedBorderColor = Divider,
        cursorColor          = PrimaryPurple,
        focusedTextColor     = TextPrimary,
        unfocusedTextColor   = TextPrimary,
        focusedLabelColor    = PrimaryPurple,
        unfocusedLabelColor  = TextSecondary
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_search, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Search lyrics") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Type the song title and artist the way they appear online.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value           = title,
                    onValueChange   = { title = it },
                    label           = { Text("Song title") },
                    singleLine      = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors          = fieldColors
                )
                OutlinedTextField(
                    value           = artist,
                    onValueChange   = { artist = it },
                    label           = { Text("Artist (optional)") },
                    singleLine      = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (canSearch) onSearch(title, artist) }),
                    colors          = fieldColors
                )
            }
        },
        confirmButton = {
            MelodiqButton(
                text    = "Search",
                onClick = { onSearch(title, artist) },
                icon    = R.drawable.ic_search,
                enabled = canSearch
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}
