#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <ctime>
#include <memory>

#include "core/Renderer.h"

#define TAG  "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Global renderer instance ───────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;

// ── Timing helpers ─────────────────────────────────────────────────────────────
static long long getTimeNs() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static long long g_lastTimeNs = 0;

static float getDeltaTime() {
    long long now = getTimeNs();
    if (g_lastTimeNs == 0) { g_lastTimeNs = now; return 0.016f; }
    float dt = (float)((now - g_lastTimeNs) * 1e-9);
    g_lastTimeNs = now;
    return (dt > 0.1f) ? 0.1f : dt; // cap at 100ms to avoid spiral of death
}

// ── JNI exports ───────────────────────────────────────────────────────────────
extern "C" {

JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit");
    g_lastTimeNs = 0;
    g_renderer   = std::make_unique<Renderer>();
    g_renderer->init();
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    LOGI("nativeResize %d x %d", w, h);
    if (g_renderer) g_renderer->resize(w, h);
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (!g_renderer) return;
    float dt = getDeltaTime();
    g_renderer->render(dt);
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetMovement(JNIEnv*, jobject,
                                                      jfloat x, jfloat y) {
    if (g_renderer) g_renderer->camera.setMovement(x, y);
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetLook(JNIEnv*, jobject,
                                                  jfloat dx, jfloat dy) {
    if (g_renderer) g_renderer->camera.setLookDelta(dx, dy);
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeJump(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.jumpRequested.store(true);
}

JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeToggleFly(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.flyToggleRequested.store(true);
}

} // extern "C"
