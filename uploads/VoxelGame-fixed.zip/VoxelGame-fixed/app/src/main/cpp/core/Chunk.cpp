#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>

#define TAG "VoxelChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

BlockType Chunk::getBlock(int x, int y, int z) const {
    if (x < 0 || x >= CHUNK_W || y < 0 || y >= CHUNK_H || z < 0 || z >= CHUNK_D)
        return BLOCK_AIR;
    return blocks[blockIdx(x, y, z)];
}

void Chunk::setBlock(int x, int y, int z, BlockType t) {
    if (x < 0 || x >= CHUNK_W || y < 0 || y >= CHUNK_H || z < 0 || z >= CHUNK_D) return;
    blocks[blockIdx(x, y, z)] = t;
}

// ── Terrain generation ────────────────────────────────────────────────────────
void Chunk::generate(const Noise& noise) {
    const float SCALE  = 0.035f;
    const int   BASE_H = 32;
    const int   RANGE  = 20;

    for (int lz = 0; lz < CHUNK_D; lz++) {
        for (int lx = 0; lx < CHUNK_W; lx++) {
            float wx = (float)(cx * CHUNK_W + lx);
            float wz = (float)(cz * CHUNK_D + lz);

            // Height from fbm noise
            float n   = noise.fbm(wx * SCALE, wz * SCALE, 5);
            int   h   = BASE_H + (int)(n * RANGE);
            h = std::max(1, std::min(CHUNK_H - 4, h));

            // Biome: use a separate noise channel
            float biomeN = noise.noise2D(wx * 0.008f + 500.f, wz * 0.008f + 500.f);

            BlockType surfBlock = BLOCK_GRASS;
            if (biomeN > 0.35f)       surfBlock = BLOCK_SNOW;
            else if (biomeN < -0.35f) surfBlock = BLOCK_SAND;

            for (int ly = 0; ly < CHUNK_H; ly++) {
                BlockType bt = BLOCK_AIR;
                if (ly == 0) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 4) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 1) {
                    bt = (surfBlock == BLOCK_SAND) ? BLOCK_SAND : BLOCK_DIRT;
                } else if (ly == h) {
                    bt = surfBlock;
                } else if (ly <= 28 && h < 28 && surfBlock == BLOCK_SAND) {
                    // Water only near sandy beaches.  Previously it was placed
                    // above snow and grass surfaces too, showing as blue patches.
                    bt = BLOCK_WATER;
                }
                setBlock(lx, ly, lz, bt);
            }

            // Add a tree with some probability (only on grass biome)
            if (surfBlock == BLOCK_GRASS && h < CHUNK_H - 10) {
                // Simple LCG per-column to decide tree
                unsigned int seed = (unsigned int)(cx * 7919 + lx * 131 + cz * 4001 + lz * 37);
                seed = seed * 1664525u + 1013904223u;
                if ((seed & 0xFFu) < 8) { // ~3% chance
                    int treeH = 4 + (int)((seed >> 8) & 3);
                    // Trunk
                    for (int ty = h+1; ty <= h + treeH; ty++)
                        if (ty < CHUNK_H) setBlock(lx, ty, lz, BLOCK_WOOD);
                    // Leaves (3x3 top 2 layers, then 5x5 below)
                    int top = h + treeH;
                    for (int ly2 = top - 1; ly2 <= top + 1; ly2++) {
                        int r = (ly2 >= top) ? 1 : 2;
                        for (int dx = -r; dx <= r; dx++) {
                            for (int dz2 = -r; dz2 <= r; dz2++) {
                                int lx2 = lx + dx, lz2 = lz + dz2;
                                if (lx2 >= 0 && lx2 < CHUNK_W && lz2 >= 0 && lz2 < CHUNK_D && ly2 < CHUNK_H)
                                    if (getBlock(lx2, ly2, lz2) == BLOCK_AIR)
                                        setBlock(lx2, ly2, lz2, BLOCK_LEAVES);
                            }
                        }
                    }
                }
            }

            // Gravel patches underground
            {
                unsigned int seed2 = (unsigned int)(cx * 1231 + lx * 53 + cz * 9973 + lz * 73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFFu) < 20) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h - 4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    state.store(ChunkState::GENERATED, std::memory_order_release);
}

// ── Neighbor block lookup ─────────────────────────────────────────────────────
BlockType Chunk::neighborBlock(int x, int y, int z,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC) const {
    if (y < 0) return BLOCK_STONE;
    if (y >= CHUNK_H) return BLOCK_AIR;

    if (x < 0) {
        return nxC ? nxC->getBlock(x + CHUNK_W, y, z) : BLOCK_AIR;
    }
    if (x >= CHUNK_W) {
        return pxC ? pxC->getBlock(x - CHUNK_W, y, z) : BLOCK_AIR;
    }
    if (z < 0) {
        return nzC ? nzC->getBlock(x, y, z + CHUNK_D) : BLOCK_AIR;
    }
    if (z >= CHUNK_D) {
        return pzC ? pzC->getBlock(x, y, z - CHUNK_D) : BLOCK_AIR;
    }
    return getBlock(x, y, z);
}

// ── Add a quad ────────────────────────────────────────────────────────────────
void Chunk::addQuad(float ox, float oy, float oz,
                    float dx1, float dy1, float dz1,   // first edge
                    float dx2, float dy2, float dz2,   // second edge
                    BlockType type, int face,
                    std::vector<Vertex>& verts,
                    std::vector<uint32_t>& inds) const
{
    BlockColor col = getBlockColor(type, face);
    float lit = FACE_LIGHT[face];
    float r = col.r * lit;
    float g = col.g * lit;
    float b = col.b * lit;

    // World offset from chunk origin
    float baseX = (float)(cx * CHUNK_W);
    float baseZ = (float)(cz * CHUNK_D);

    uint32_t base = (uint32_t)verts.size();

    verts.push_back({baseX + ox,             oy,             baseZ + oz,             r, g, b});
    verts.push_back({baseX + ox + dx1,       oy + dy1,       baseZ + oz + dz1,       r, g, b});
    verts.push_back({baseX + ox + dx1 + dx2, oy + dy1 + dy2, baseZ + oz + dz1 + dz2, r, g, b});
    verts.push_back({baseX + ox + dx2,       oy + dy2,       baseZ + oz + dz2,       r, g, b});

    inds.push_back(base + 0);
    inds.push_back(base + 1);
    inds.push_back(base + 2);
    inds.push_back(base + 0);
    inds.push_back(base + 2);
    inds.push_back(base + 3);
}

// ── Greedy Meshing ─────────────────────────────────────────────────────────────
//
//  For each of 6 axis-aligned directions we sweep slice-by-slice.
//  In each slice we build a mask of which cells need a face, then
//  greedily merge adjacent equal cells into one big quad.
//
void Chunk::buildMesh(const Chunk* nxC, const Chunk* pxC,
                      const Chunk* nzC, const Chunk* pzC) {
    std::vector<Vertex>   localVerts;
    std::vector<uint32_t> localInds;
    localVerts.reserve(4096);
    localInds.reserve(6144);

    // dims[3]: size in each axis
    const int dims[3] = {CHUNK_W, CHUNK_H, CHUNK_D};

    // We use a simple struct to represent a mask entry:
    //   type == BLOCK_AIR → no face here
    //   backFace: whether we're looking at the back of a block
    struct MaskEntry {
        BlockType type;
        bool      backFace;
        bool operator==(const MaskEntry& o) const {
            return type == o.type && backFace == o.backFace;
        }
        bool operator!=(const MaskEntry& o) const { return !(*this == o); }
    };

    // Working mask buffer (largest slice)
    std::vector<MaskEntry> mask;
    mask.resize(CHUNK_W * CHUNK_H); // max slice is W*H (for d=Z)

    // Loop over 3 dimensions
    for (int d = 0; d < 3; d++) {
        int u = (d + 1) % 3;  // first tangent
        int v = (d + 2) % 3;  // second tangent

        int pos[3] = {0, 0, 0};

        // sweep each slice along d
        for (pos[d] = 0; pos[d] < dims[d]; pos[d]++) {
            // Build mask for this slice
            int n = 0;
            for (pos[v] = 0; pos[v] < dims[v]; pos[v]++) {
                for (pos[u] = 0; pos[u] < dims[u]; pos[u]++, n++) {
                    int ax = pos[0], ay = pos[1], az = pos[2];

                    // forward neighbour
                    int fx = ax, fy = ay, fz = az;
                    if (d == 0) fx++;
                    else if (d == 1) fy++;
                    else fz++;

                    BlockType b0 = neighborBlock(ax, ay, az, nxC, pxC, nzC, pzC);
                    BlockType b1 = neighborBlock(fx, fy, fz, nxC, pxC, nzC, pzC);

                    bool op0 = blockIsOpaque(b0);
                    bool op1 = blockIsOpaque(b1);

                    if (op0 == op1) {
                        mask[n] = {BLOCK_AIR, false};
                    } else if (op0) {
                        mask[n] = {b0, false}; // front face (visible from + direction)
                    } else {
                        mask[n] = {b1, true};  // back face (visible from - direction)
                    }
                }
            }

            // Greedy merge and emit quads
            n = 0;
            for (int j = 0; j < dims[v]; j++) {
                for (int i = 0; i < dims[u]; ) {
                    MaskEntry entry = mask[n];

                    if (entry.type == BLOCK_AIR) {
                        i++; n++;
                        continue;
                    }

                    // Find width (w): how far right we can extend this entry
                    int w = 1;
                    while (i + w < dims[u] && mask[n + w] == entry) w++;

                    // Find height (h): how many rows below we can extend
                    int h = 1;
                    bool done = false;
                    while (!done && j + h < dims[v]) {
                        for (int k = 0; k < w; k++) {
                            if (mask[(j + h) * dims[u] + i + k] != entry) {
                                done = true;
                                break;
                            }
                        }
                        if (!done) h++;
                    }

                    // Determine face index and quad geometry
                    // d=0(X axis): face +X(0) or -X(1)
                    // d=1(Y axis): face +Y(2) or -Y(3)
                    // d=2(Z axis): face +Z(4) or -Z(5)
                    int faceIdx = d * 2 + (entry.backFace ? 1 : 0);

                    // Origin of the quad in local chunk coords
                    float qx = 0, qy = 0, qz = 0;
                    // u maps to which local axis, v to which
                    // d: the perpendicular dimension; value = pos[d] (for front face) or pos[d]+1 for back
                    // Both front and back faces occupy the same geometric boundary
                    // between pos[d] and pos[d]+1.  Only the winding (e1/e2 swap)
                    // determines which direction the face is visible from.
                    int slice = pos[d] + 1;

                    // We need to map (d, u, v) back to (x, y, z)
                    // d=0→x, u=1→y, v=2→z
                    // d=1→y, u=2→z, v=0→x
                    // d=2→z, u=0→x, v=1→y
                    float o[3], e1[3], e2[3];
                    o[d] = (float)slice;
                    o[u] = (float)i;
                    o[v] = (float)j;

                    // Edge vectors (w in u direction, h in v direction)
                    // For back faces we flip the winding
                    e1[d] = 0; e1[u] = (float)w; e1[v] = 0;
                    e2[d] = 0; e2[u] = 0;         e2[v] = (float)h;

                    if (entry.backFace) {
                        // Swap e1 and e2 to flip winding
                        float tmp[3];
                        for (int k=0;k<3;k++){tmp[k]=e1[k];e1[k]=e2[k];e2[k]=tmp[k];}
                    }

                    addQuad(o[0], o[1], o[2],
                            e1[0], e1[1], e1[2],
                            e2[0], e2[1], e2[2],
                            entry.type, faceIdx,
                            localVerts, localInds);

                    // Clear the mask rectangle we just emitted
                    for (int jj = j; jj < j + h; jj++)
                        for (int ii = i; ii < i + w; ii++)
                            mask[jj * dims[u] + ii] = {BLOCK_AIR, false};

                    i += w;
                    n += w;
                }
            }
        }
    }

    // Swap into member with lock (upload thread will consume these)
    {
        std::lock_guard<std::mutex> lock(meshMutex);
        vertices = std::move(localVerts);
        indices  = std::move(localInds);
    }
    state.store(ChunkState::MESHED, std::memory_order_release);
}

// ── GPU upload (GL thread) ─────────────────────────────────────────────────────
void Chunk::uploadMesh() {
    std::lock_guard<std::mutex> lock(meshMutex);

    if (vertices.empty()) {
        indexCount = 0;
        state.store(ChunkState::READY, std::memory_order_release);
        return;
    }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertices.size() * sizeof(Vertex)),
                 vertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(indices.size() * sizeof(uint32_t)),
                 indices.data(), GL_STATIC_DRAW);

    // layout(location=0) vec3 position
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          (void*)offsetof(Vertex, x));

    // layout(location=1) vec3 color
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          (void*)offsetof(Vertex, r));

    glBindVertexArray(0);

    indexCount = (int)indices.size();

    // Free CPU copies
    vertices.clear(); vertices.shrink_to_fit();
    indices.clear();  indices.shrink_to_fit();

    state.store(ChunkState::READY, std::memory_order_release);
}

// ── Render ─────────────────────────────────────────────────────────────────────
void Chunk::render() const {
    if (indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                    float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W);
    mnY = 0.f;
    mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;
    mxY = (float)CHUNK_H;
    mxZ = mnZ + CHUNK_D;
}
