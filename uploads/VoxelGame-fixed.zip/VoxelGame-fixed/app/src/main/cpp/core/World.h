#pragma once
#include <unordered_map>
#include <memory>
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <shared_mutex>
#include <functional>
#include <set>
#include "Chunk.h"
#include "Noise.h"
#include "Math3D.h"

struct ChunkKey {
    int cx, cz;
    bool operator==(const ChunkKey& o) const { return cx == o.cx && cz == o.cz; }
    bool operator<(const ChunkKey& o)  const {
        return cx < o.cx || (cx == o.cx && cz < o.cz);
    }
};

struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int>()(k.cx) ^ (std::hash<int>()(k.cz) * 2654435761u);
    }
};

class World {
public:
    // Chunk streaming radii (in chunks)
    static constexpr int RENDER_RADIUS = 6;   // load/mesh within this ring
    static constexpr int UNLOAD_RADIUS = 9;   // free chunks beyond this ring

    World();
    ~World();

    // Initialise noise + worker threads, seed the area around the origin.
    void init(int seed = 42);

    // ── Per-frame calls (ALL on the GL thread) ─────────────────────────────
    // Stream in/out chunks around the camera position.
    void update(float camX, float camZ);

    // Upload up to N newly-meshed chunks to the GPU.
    void updateGPU();

    // Render all READY chunks visible in the frustum.
    void render(const Frustum& frustum);

    // ── Block / chunk accessors ────────────────────────────────────────────
    BlockType getBlock(int wx, int wy, int wz) const;
    Chunk*    getChunk(int cx, int cz) const;

    int getChunkCount()   const;
    int getVisibleCount() const { return lastVisibleCount; }

private:
    Noise noise;

    // Chunks map – write-locked only on the GL thread (add / erase).
    // Worker threads hold a shared (read) lock when calling getChunk().
    mutable std::shared_mutex chunksMutex;
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkKeyHash> chunks;

    // Set of chunk coords already submitted for generation so we never
    // double-submit.  Accessed only on the GL thread -> no extra lock needed.
    std::set<ChunkKey> submitted;

    // Last camera chunk position - used to skip work when the camera
    // hasn't crossed a chunk boundary.
    int lastCamCX = INT_MIN;
    int lastCamCZ = INT_MIN;

    // ── Thread pool ────────────────────────────────────────────────────────
    std::vector<std::thread> workers;

    mutable int lastVisibleCount = 0;

    void workerLoop();
    void enqueueTask(std::function<void()> task);
    void rebuildChunkMesh(Chunk* chunk);
    void triggerRemeshForNeighbors(int cx, int cz);
};
