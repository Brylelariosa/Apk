#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <condition_variable>
#include <cmath>
#include <climits>

#define TAG  "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Thread pool (global, shared across the single World instance) ──────────────
namespace {
struct Pool {
    std::queue<std::function<void()>> q;
    std::mutex                        mtx;
    std::condition_variable           cv;
    bool                              stop = false;
};
Pool g_pool;
} // anon

// ─────────────────────────────────────────────────────────────────────────────
World::World() : noise(0) {}

World::~World() {
    {
        std::unique_lock<std::mutex> lock(g_pool.mtx);
        g_pool.stop = true;
    }
    g_pool.cv.notify_all();
    for (auto& t : workers) if (t.joinable()) t.join();
}

void World::workerLoop() {
    while (true) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(g_pool.mtx);
            g_pool.cv.wait(lock, [&]{ return g_pool.stop || !g_pool.q.empty(); });
            if (g_pool.stop && g_pool.q.empty()) return;
            task = std::move(g_pool.q.front());
            g_pool.q.pop();
        }
        task();
    }
}

void World::enqueueTask(std::function<void()> task) {
    {
        std::unique_lock<std::mutex> lock(g_pool.mtx);
        g_pool.q.push(std::move(task));
    }
    g_pool.cv.notify_one();
}

// ── Init ───────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    noise = Noise(seed);

    // Reset pool so re-init after EGL context loss works correctly.
    {
        std::unique_lock<std::mutex> lock(g_pool.mtx);
        g_pool.stop = false;
        while (!g_pool.q.empty()) g_pool.q.pop();
    }
    {
        std::unique_lock<std::shared_mutex> lock(chunksMutex);
        chunks.clear();
    }
    submitted.clear();
    lastCamCX = INT_MIN;
    lastCamCZ = INT_MIN;

    // Start worker threads
    int numThreads = std::max(2, (int)std::thread::hardware_concurrency());
    LOGI("Starting %d worker threads", numThreads);
    for (int i = 0; i < numThreads; i++)
        workers.emplace_back([this]{ workerLoop(); });

    // Seed the initial area around the origin
    update(0.f, 0.f);
    LOGI("init complete – initial chunks submitted");
}

// ── Infinite chunk streaming ───────────────────────────────────────────────────
void World::update(float camX, float camZ) {
    // Which chunk is the camera in?
    int camCX = (int)floorf(camX / (float)CHUNK_W);
    int camCZ = (int)floorf(camZ / (float)CHUNK_D);

    // Only do heavy work when the camera crosses a chunk boundary
    if (camCX == lastCamCX && camCZ == lastCamCZ) return;
    lastCamCX = camCX;
    lastCamCZ = camCZ;

    // ── 1. Unload chunks outside the unload radius ────────────────────────
    // We only unload READY chunks – chunks still being generated or meshed
    // have live worker tasks pointing at their memory, so we must not free them.
    {
        std::unique_lock<std::shared_mutex> lock(chunksMutex);
        auto it = chunks.begin();
        while (it != chunks.end()) {
            int dx = it->first.cx - camCX;
            int dz = it->first.cz - camCZ;
            bool tooFar = (dx < -UNLOAD_RADIUS || dx > UNLOAD_RADIUS ||
                           dz < -UNLOAD_RADIUS || dz > UNLOAD_RADIUS);
            ChunkState st = it->second->state.load(std::memory_order_acquire);
            if (tooFar && st == ChunkState::READY) {
                // Remove from the submitted set so we can re-load it later
                submitted.erase({it->first.cx, it->first.cz});
                // ~Chunk() deletes GL objects – safe because we're on the GL thread
                it = chunks.erase(it);
            } else {
                ++it;
            }
        }
    }

    // ── 2. Submit new chunks inside the load radius ───────────────────────
    // Submit from nearest to farthest (improves visual load-in order).
    for (int dist = 0; dist <= RENDER_RADIUS; dist++) {
        for (int dz = -dist; dz <= dist; dz++) {
            for (int dx = -dist; dx <= dist; dx++) {
                // Only process the ring at distance == dist
                if (std::max(std::abs(dx), std::abs(dz)) != dist) continue;

                int cx = camCX + dx;
                int cz = camCZ + dz;
                ChunkKey key{cx, cz};

                // Already submitted?
                if (submitted.count(key)) continue;
                submitted.insert(key);

                // Add to the map (write lock)
                Chunk* ptr;
                {
                    std::unique_lock<std::shared_mutex> lock(chunksMutex);
                    auto chunk = std::make_unique<Chunk>(cx, cz);
                    ptr = chunk.get();
                    chunks[key] = std::move(chunk);
                }

                // Generate + mesh on a worker thread.
                // Note: buildMesh will call getChunk() for neighbours; if a
                // neighbour isn't loaded yet it gets nullptr, which buildMesh
                // treats as "no solid blocks" – a minor seam that disappears
                // once the neighbour loads.
                enqueueTask([this, ptr]() {
                    ptr->generate(noise);
                    rebuildChunkMesh(ptr);
                    // Re-mesh any already-loaded neighbours so their border faces
                    // are correct now that this chunk's block data is available.
                    triggerRemeshForNeighbors(ptr->cx, ptr->cz);
                });
            }
        }
    }
}

// ── Mesh helper ────────────────────────────────────────────────────────────────
void World::rebuildChunkMesh(Chunk* chunk) {
    int cx = chunk->cx, cz = chunk->cz;
    // Shared (read) lock – safe to run from multiple worker threads
    std::shared_lock<std::shared_mutex> lock(chunksMutex);
    const Chunk* nxC = getChunk(cx - 1, cz);
    const Chunk* pxC = getChunk(cx + 1, cz);
    const Chunk* nzC = getChunk(cx, cz - 1);
    const Chunk* pzC = getChunk(cx, cz + 1);
    chunk->buildMesh(nxC, pxC, nzC, pzC);
}

// ── Trigger re-mesh for already-loaded neighbours ──────────────────────────────
// Called after a new chunk finishes generating so that border faces in
// adjacent READY chunks are rebuilt with the correct neighbour data.
// Crucially, we do NOT change the neighbour's state to GENERATED — that would
// make it invisible for 1-2 frames.  We just enqueue the rebuild; the chunk
// keeps rendering its old VAO while the worker builds the new CPU mesh, and
// the GL thread re-uploads it on the next updateGPU pass (state: MESHED→READY).
void World::triggerRemeshForNeighbors(int cx, int cz) {
    static const int dirs[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};

    std::vector<Chunk*> toRemesh;
    {
        std::shared_lock<std::shared_mutex> lock(chunksMutex);
        for (auto& d : dirs) {
            Chunk* nb = getChunk(cx + d[0], cz + d[1]);
            if (!nb) continue;
            ChunkState st = nb->state.load(std::memory_order_acquire);
            // Only queue if READY; skip if already mid-mesh (GENERATED / MESHED)
            if (st == ChunkState::READY)
                toRemesh.push_back(nb);
        }
    }
    for (Chunk* nb : toRemesh)
        enqueueTask([this, nb]() { rebuildChunkMesh(nb); });
}

// ── updateGPU (GL thread) ──────────────────────────────────────────────────────
void World::updateGPU() {
    // Upload up to 4 meshed chunks per frame to avoid hitches
    int uploaded = 0;
    std::shared_lock<std::shared_mutex> lock(chunksMutex);
    for (auto& kv : chunks) {
        if (kv.second->state.load(std::memory_order_acquire) == ChunkState::MESHED) {
            kv.second->uploadMesh();
            if (++uploaded >= 4) break;
        }
    }
}

// ── Render ─────────────────────────────────────────────────────────────────────
void World::render(const Frustum& frustum) {
    int visible = 0;
    std::shared_lock<std::shared_mutex> lock(chunksMutex);
    for (auto& kv : chunks) {
        Chunk* ch = kv.second.get();
        if (ch->state.load(std::memory_order_acquire) != ChunkState::READY) continue;

        float mnX, mnY, mnZ, mxX, mxY, mxZ;
        ch->getAABB(mnX, mnY, mnZ, mxX, mxY, mxZ);

        if (!frustum.testAABB({mnX, mnY, mnZ}, {mxX, mxY, mxZ})) continue;

        ch->render();
        visible++;
    }
    lastVisibleCount = visible;
}

// ── Accessors ──────────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    // Assumes the caller already holds at least a shared lock on chunksMutex
    auto it = chunks.find({cx, cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

BlockType World::getBlock(int wx, int wy, int wz) const {
    if (wy < 0 || wy >= CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx * CHUNK_W;
    int lz = wz - cz * CHUNK_D;
    std::shared_lock<std::shared_mutex> lock(chunksMutex);
    const Chunk* ch = getChunk(cx, cz);
    return ch ? ch->getBlock(lx, wy, lz) : BLOCK_AIR;
}

int World::getChunkCount() const {
    std::shared_lock<std::shared_mutex> lock(chunksMutex);
    return (int)chunks.size();
}
