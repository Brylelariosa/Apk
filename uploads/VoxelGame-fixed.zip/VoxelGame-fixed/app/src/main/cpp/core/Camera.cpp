#include "Camera.h"
#include "World.h"
#include "Block.h"
#include <cmath>
#include <algorithm>

static constexpr float PI      = 3.14159265f;
static constexpr float HALF_PI = PI * 0.5f;

// Player body constants
static constexpr float EYE_H      = 1.62f;  // eye height above feet
static constexpr float PLAYER_H   = 1.80f;  // total height
static constexpr float PLAYER_W   = 0.30f;  // half-width for collision box
static constexpr float FLY_SPEED  = 12.0f;
static constexpr float WALK_SPEED =  5.0f;
static constexpr float GRAVITY    = 30.0f;
static constexpr float JUMP_VEL   = 11.0f;

Vec3 Camera::getForward() const {
    float cosPitch = cosf(pitch);
    return Vec3(cosf(yaw)*cosPitch, sinf(pitch), sinf(yaw)*cosPitch).normalize();
}

Vec3 Camera::getRight() const {
    return getForward().cross({0,1,0}).normalize();
}

Mat4 Camera::getView()       const { return Mat4::lookAt(position, position+getForward(), {0,1,0}); }
Mat4 Camera::getProjection() const { return Mat4::perspective(fovY, aspect, nearPlane, farPlane); }
Mat4 Camera::getVP()         const { return getProjection() * getView(); }
Frustum Camera::getFrustum() const { Frustum f; f.extractFromVP(getVP()); return f; }

// Returns true if the axis-aligned column at (px, pz) between worldY lo..hi
// contains any opaque block.
static bool columnBlocked(const World* w, float px, float pz, int yLo, int yHi) {
    if (!w) return false;
    int bx = (int)floorf(px);
    int bz = (int)floorf(pz);
    for (int by = yLo; by <= yHi; by++)
        if (blockIsOpaque(w->getBlock(bx, by, bz))) return true;
    return false;
}

void Camera::update(float dt, const World* world) {
    // ── Look ──────────────────────────────────────────────────────────────────
    float dy = 0, dp = 0;
    { std::lock_guard<std::mutex> lk(lookMutex);
      dy = lookDyaw; lookDyaw = 0;
      dp = lookDpitch; lookDpitch = 0; }
    yaw   += dy;
    pitch -= dp;
    pitch  = std::max(-HALF_PI*0.99f, std::min(HALF_PI*0.99f, pitch));
    while (yaw >  PI*2.f) yaw -= PI*2.f;
    while (yaw < -PI*2.f) yaw += PI*2.f;

    // ── Fly / walk toggle ─────────────────────────────────────────────────────
    if (flyToggleRequested.exchange(false)) {
        flyMode  = !flyMode;
        velY     = 0.f;
        onGround = false;
    }

    // ── Movement inputs ───────────────────────────────────────────────────────
    float fwd    = inputForward.load(std::memory_order_relaxed);
    float strafe = inputStrafe.load(std::memory_order_relaxed);
    Vec3 forward = getForward();
    Vec3 right   = getRight();

    if (flyMode) {
        // ── Fly mode: pitch steers vertical (creative-style) ──────────────────
        position += forward * (fwd    * FLY_SPEED * dt);
        position += right   * (strafe * FLY_SPEED * dt);

    } else {
        // ── Walk mode ─────────────────────────────────────────────────────────

        // Horizontal flat direction ignoring pitch
        Vec3 flatFwd = {forward.x, 0.f, forward.z};
        float fl = flatFwd.length();
        if (fl > 1e-4f) flatFwd = flatFwd * (1.f / fl);

        float dx = (flatFwd.x * fwd + right.x * strafe) * WALK_SPEED * dt;
        float dz = (flatFwd.z * fwd + right.z * strafe) * WALK_SPEED * dt;

        // Body Y range for horizontal collision checks
        float footY = position.y - EYE_H;
        int yLo = (int)floorf(footY + 0.05f);
        int yHi = (int)floorf(position.y - 0.05f);

        // Slide along walls by trying X and Z independently
        float nx = position.x + dx;
        if (!columnBlocked(world, nx, position.z, yLo, yHi))
            position.x = nx;

        float nz = position.z + dz;
        if (!columnBlocked(world, position.x, nz, yLo, yHi))
            position.z = nz;

        // ── Gravity & jump ────────────────────────────────────────────────────
        if (jumpRequested.exchange(false) && onGround) {
            velY     = JUMP_VEL;
            onGround = false;
        }

        velY -= GRAVITY * dt;
        velY  = std::max(velY, -50.f);   // terminal velocity

        position.y += velY * dt;

        // ── Ground / ceiling collision ────────────────────────────────────────
        if (world) {
            int bx = (int)floorf(position.x);
            int bz = (int)floorf(position.z);
            footY = position.y - EYE_H;

            // Ground: block that the feet are currently inside
            int groundBlock = (int)floorf(footY - 0.01f);
            if (blockIsOpaque(world->getBlock(bx, groundBlock, bz)) && velY <= 0.f) {
                position.y = (float)(groundBlock + 1) + EYE_H;
                velY       = 0.f;
                onGround   = true;
            } else {
                // Are we resting on top of a block?
                int standBlock = (int)floorf(footY) - 1;
                onGround = blockIsOpaque(world->getBlock(bx, standBlock, bz))
                           && (footY <= (float)(standBlock + 1) + 0.05f);
            }

            // Ceiling: block the head is inside
            int headBlock = (int)floorf(position.y + 0.1f);
            if (blockIsOpaque(world->getBlock(bx, headBlock, bz)) && velY > 0.f) {
                position.y = (float)headBlock - 0.1f;
                velY       = 0.f;
            }
        }
    }
}

void Camera::setLookDelta(float dyaw, float dpitch) {
    std::lock_guard<std::mutex> lk(lookMutex);
    lookDyaw   += dyaw;
    lookDpitch += dpitch;
}

void Camera::setMovement(float forward, float strafe) {
    inputForward.store(forward, std::memory_order_relaxed);
    inputStrafe.store(strafe,  std::memory_order_relaxed);
}
