#include "Renderer.h"
#include <android/log.h>
#include <cstring>
#include <cmath>

#define TAG  "VoxelRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Shaders ───────────────────────────────────────────────────────────────────
static const char* VERT_SRC = R"(#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aColor;

uniform mat4 uMVP;
uniform vec3 uCamPos;   // camera world-space position for fog

out vec3 vColor;
out float vFog;

void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
    vColor = aColor;

    // Linear fog in true world-space distance from the camera
    float dist     = length(aPos - uCamPos);
    float fogStart = 80.0;
    float fogEnd   = 170.0;
    vFog = clamp((dist - fogStart) / (fogEnd - fogStart), 0.0, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 300 es
precision mediump float;

in  vec3  vColor;
in  float vFog;

out vec4 fragColor;

const vec3 SKY = vec3(0.52, 0.77, 0.95);

void main() {
    vec3 col = mix(vColor, SKY, vFog);
    fragColor = vec4(col, 1.0);
}
)";

// ── HUD (crosshair) shaders ────────────────────────────────────────────────────
static const char* HUD_VERT_SRC = R"(#version 300 es
layout(location = 0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)";

static const char* HUD_FRAG_SRC = R"(#version 300 es
precision mediump float;
out vec4 fragColor;
void main() { fragColor = vec4(1.0, 1.0, 1.0, 0.8); }
)";

// ── Helpers ────────────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader compile error: %s", log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

GLuint Renderer::linkProgram(GLuint vert, GLuint frag) {
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vert);
    glAttachShader(prog, frag);
    glLinkProgram(prog);
    GLint ok;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetProgramInfoLog(prog, sizeof(log), nullptr, log);
        LOGE("Program link error: %s", log);
        glDeleteProgram(prog);
        return 0;
    }
    glDeleteShader(vert);
    glDeleteShader(frag);
    return prog;
}

// ── Init ───────────────────────────────────────────────────────────────────────
void Renderer::init() {
    LOGI("Renderer::init()");

    // Main shader
    GLuint v = compileShader(GL_VERTEX_SHADER,   VERT_SRC);
    GLuint f = compileShader(GL_FRAGMENT_SHADER, FRAG_SRC);
    shaderProgram = linkProgram(v, f);
    uMVP    = glGetUniformLocation(shaderProgram, "uMVP");
    uCamPos = glGetUniformLocation(shaderProgram, "uCamPos");

    // HUD
    initHUD();

    // GL state
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glDepthFunc(GL_LEQUAL);

    glClearColor(SKY_R, SKY_G, SKY_B, 1.f);

    // World generation (blocks + mesh on background threads)
    LOGI("Starting world generation...");
    world.init(42);
    LOGI("World init done, waiting for meshes on GPU upload...");

    initialized = true;
    LOGI("Renderer initialized. Chunks: %d", world.getChunkCount());
}

void Renderer::initHUD() {
    GLuint hv = compileShader(GL_VERTEX_SHADER,   HUD_VERT_SRC);
    GLuint hf = compileShader(GL_FRAGMENT_SHADER, HUD_FRAG_SRC);
    hudShader  = linkProgram(hv, hf);

    float s = 0.02f, t = 0.002f; // crosshair size, thickness
    float verts[] = {
        // horizontal bar
        -s, -t,   s, -t,   s,  t,
        -s, -t,   s,  t,  -s,  t,
        // vertical bar
        -t, -s,   t, -s,   t,  s,
        -t, -s,   t,  s,  -t,  s,
    };
    glGenVertexArrays(1, &hudVao);
    glGenBuffers(1, &hudVbo);
    glBindVertexArray(hudVao);
    glBindBuffer(GL_ARRAY_BUFFER, hudVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), nullptr);
    glBindVertexArray(0);
}

// ── Resize ─────────────────────────────────────────────────────────────────────
void Renderer::resize(int width, int height) {
    glViewport(0, 0, width, height);
    camera.aspect = (float)width / (float)height;
    LOGI("Resize %d x %d, aspect %.2f", width, height, camera.aspect);
}

// ── Render ─────────────────────────────────────────────────────────────────────
void Renderer::render(float dt) {
    if (!initialized) return;

    // Update camera (apply input, move)
    camera.update(dt, &world);

    // Stream chunks in/out based on camera position
    world.update(camera.position.x, camera.position.z);

    // Upload pending chunk meshes (up to 4 per frame)
    world.updateGPU();

    // Clear
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Build VP matrix + frustum
    Mat4    vp      = camera.getVP();
    Frustum frustum = camera.getFrustum();

    // Draw world
    glUseProgram(shaderProgram);
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, vp.m);
    glUniform3fv(uCamPos, 1, &camera.position.x);
    world.render(frustum);

    // Draw HUD (no depth test)
    renderHUD();
}

void Renderer::renderHUD() {
    glDisable(GL_DEPTH_TEST);
    glUseProgram(hudShader);
    glBindVertexArray(hudVao);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Destructor ─────────────────────────────────────────────────────────────────
Renderer::~Renderer() {
    if (shaderProgram) glDeleteProgram(shaderProgram);
    if (hudShader)     glDeleteProgram(hudShader);
    if (hudVao)        glDeleteVertexArrays(1, &hudVao);
    if (hudVbo)        glDeleteBuffers(1, &hudVbo);
}
