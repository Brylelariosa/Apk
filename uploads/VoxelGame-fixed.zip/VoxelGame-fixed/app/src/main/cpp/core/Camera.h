#pragma once
#include "Math3D.h"
#include <atomic>
#include <mutex>

class Camera {
public:
    Vec3  position   = {0.f, 72.f, 0.f};  // above max terrain height (BASE_H+RANGE = 52)
    float yaw        = 0.f;   // radians; 0 = looking toward +X
    float pitch      = 0.f;   // radians; clamped to ±89°

    float fovY       = 70.f * 3.14159265f / 180.f;
    float aspect     = 16.f / 9.f;
    float nearPlane  = 0.15f;
    float farPlane   = 400.f;

    // Movement input (set from touch/JNI, consumed each frame)
    std::atomic<float> inputForward{0.f};
    std::atomic<float> inputStrafe{0.f};
    float              lookDyaw   = 0.f;
    float              lookDpitch = 0.f;
    std::mutex         lookMutex;

    Vec3 getForward() const;
    Vec3 getRight()   const;
    Vec3 getUp()      const { return {0,1,0}; }

    Mat4 getView()       const;
    Mat4 getProjection() const;
    Mat4 getVP()         const;

    Frustum getFrustum() const;

    // Update position and orientation from pending inputs
    void update(float dt, float speedMultiplier = 12.f);

    void setLookDelta(float dyaw, float dpitch);
    void setMovement(float forward, float strafe);
};
