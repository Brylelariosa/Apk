#pragma once
#include "Math3D.h"
#include <atomic>
#include <mutex>

class World; // forward-declare to avoid circular include

class Camera {
public:
    Vec3  position   = {0.f, 72.f, 0.f};
    float yaw        = 0.f;
    float pitch      = 0.f;

    float fovY       = 70.f * 3.14159265f / 180.f;
    float aspect     = 16.f / 9.f;
    float nearPlane  = 0.15f;
    float farPlane   = 400.f;

    // ── Movement inputs (written from JNI/touch thread) ───────────────────────
    std::atomic<float> inputForward{0.f};
    std::atomic<float> inputStrafe{0.f};
    float              lookDyaw   = 0.f;
    float              lookDpitch = 0.f;
    std::mutex         lookMutex;

    // ── Walk / fly mode ───────────────────────────────────────────────────────
    bool  flyMode  = true;   // true = creative fly; false = walk with gravity
    float velY     = 0.f;    // vertical velocity (walk mode only)
    bool  onGround = false;

    std::atomic<bool> jumpRequested{false};
    std::atomic<bool> flyToggleRequested{false};

    // ── Camera maths ──────────────────────────────────────────────────────────
    Vec3 getForward() const;
    Vec3 getRight()   const;
    Vec3 getUp()      const { return {0,1,0}; }

    Mat4 getView()       const;
    Mat4 getProjection() const;
    Mat4 getVP()         const;
    Frustum getFrustum() const;

    // Pass world so walk mode can do block collision queries
    void update(float dt, const World* world = nullptr);

    void setLookDelta(float dyaw, float dpitch);
    void setMovement(float forward, float strafe);
};
