package com.voxelgame;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

/**
 * Left half  = movement joystick (fixed-base, infinite radius).
 * Right half = look swipe.
 *              • Quick tap (< TAP_MOVE_PX movement) in walk mode → Jump
 *              • Double-tap (two taps < DOUBLE_TAP_MS apart)     → Toggle fly/walk
 */
public class GameSurfaceView extends GLSurfaceView {

    private final GameRenderer renderer;
    private JoystickOverlay joystickOverlay;

    // ── Fixed joystick ────────────────────────────────────────────────────────
    private float joyCX = 0f, joyCY = 0f;
    private static final float VISUAL_RADIUS   = 100f;
    private static final float DEAD_ZONE       =  12f;

    // ── Touch state ───────────────────────────────────────────────────────────
    private int   leftPid  = -1;
    private int   rightPid = -1;
    private float rightPrevX, rightPrevY;
    private float rightDownX, rightDownY;   // position at finger-down for tap detection
    private static final float LOOK_SENS         = 0.003f;
    private static final float TAP_MOVE_PX       = 12f;   // max drift to count as a tap
    private static final long  DOUBLE_TAP_MS     = 280;   // ms window for double-tap

    private long lastRightTapMs = 0;   // time of last qualifying tap on right side

    // ── Fly mode state (mirrors C++ side, local copy for the overlay) ─────────
    private boolean flyMode = true;

    public GameSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        setPreserveEGLContextOnPause(true);
        renderer = new GameRenderer();
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    public void setJoystickOverlay(JoystickOverlay overlay) {
        joystickOverlay = overlay;
        if (joyCX > 0) overlay.setCenter(joyCX, joyCY);
        overlay.setFlyMode(flyMode);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        joyCX = w * 0.14f;
        joyCY = h * 0.75f;
        if (joystickOverlay != null) joystickOverlay.setCenter(joyCX, joyCY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int action    = event.getActionMasked();
        final int actionIdx = event.getActionIndex();
        final int pid       = event.getPointerId(actionIdx);
        final float x       = event.getX(actionIdx);
        final float y       = event.getY(actionIdx);
        final float halfW   = getWidth() * 0.5f;

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < halfW && leftPid == -1) {
                    leftPid = pid;
                    handleMovement(x, y);
                } else if (x >= halfW && rightPid == -1) {
                    rightPid   = pid;
                    rightPrevX = x;
                    rightPrevY = y;
                    rightDownX = x;
                    rightDownY = y;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int   p  = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (p == leftPid) {
                        handleMovement(px, py);
                    } else if (p == rightPid) {
                        float dx = px - rightPrevX;
                        float dy = py - rightPrevY;
                        rightPrevX = px;
                        rightPrevY = py;
                        nativeSetLook(dx * LOOK_SENS, dy * LOOK_SENS);
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pid == leftPid) {
                    leftPid = -1;
                    nativeSetMovement(0f, 0f);
                    if (joystickOverlay != null)
                        joystickOverlay.update(false, joyCX, joyCY);
                } else if (pid == rightPid) {
                    rightPid = -1;

                    // Classify as tap if finger barely moved
                    float ddx = x - rightDownX;
                    float ddy = y - rightDownY;
                    float dist = (float) Math.sqrt(ddx*ddx + ddy*ddy);
                    if (dist < TAP_MOVE_PX) {
                        long now = System.currentTimeMillis();
                        if (now - lastRightTapMs < DOUBLE_TAP_MS) {
                            // Double tap → toggle fly / walk
                            flyMode = !flyMode;
                            nativeToggleFly();
                            if (joystickOverlay != null)
                                joystickOverlay.setFlyMode(flyMode);
                            lastRightTapMs = 0;  // reset so next tap starts fresh
                        } else {
                            // Single tap → jump (only meaningful in walk mode)
                            nativeJump();
                            lastRightTapMs = now;
                        }
                    }
                }
                break;
        }
        return true;
    }

    private void handleMovement(float fx, float fy) {
        float dx   = fx - joyCX;
        float dy   = fy - joyCY;
        float dist = (float) Math.sqrt(dx*dx + dy*dy);
        float fwd = 0f, strafe = 0f;
        if (dist > DEAD_ZONE) {
            fwd    = -dy / dist;
            strafe =  dx / dist;
        }
        nativeSetMovement(fwd, strafe);
        float vx = joyCX, vy = joyCY;
        if (dist > DEAD_ZONE) {
            float clamp = Math.min(dist, VISUAL_RADIUS);
            vx = joyCX + dx / dist * clamp;
            vy = joyCY + dy / dist * clamp;
        }
        if (joystickOverlay != null)
            joystickOverlay.update(true, vx, vy);
    }

    // ── JNI ───────────────────────────────────────────────────────────────────
    public native void nativeSetMovement(float forward, float strafe);
    public native void nativeSetLook(float dyaw, float dpitch);
    public native void nativeJump();
    public native void nativeToggleFly();
}
