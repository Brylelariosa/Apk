package com.voxelgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Transparent overlay that draws ONE fixed movement joystick.
 * The right side of the screen is a free-look zone with no visuals.
 * All touch events pass through to the GLSurfaceView below.
 */
public class JoystickOverlay extends View {

    private static final float BASE_RADIUS  = 100f;
    private static final float THUMB_RADIUS =  44f;
    private static final float STROKE_W     =   5f;

    private final Paint ringPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint modePaint  = new Paint(Paint.ANTI_ALIAS_FLAG);

    private boolean isFlyMode = true;

    // Fixed joystick centre (set once screen size is known)
    private float centerX = -1f, centerY = -1f;

    // Thumb position (updated while left finger is down)
    private boolean active;
    private float thumbX, thumbY;

    public JoystickOverlay(Context context) {
        super(context);
        setFocusable(false);
        setClickable(false);

        // Outer ring
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(STROKE_W);
        ringPaint.setColor(Color.argb(170, 255, 255, 255));

        // Inner fill of ring (translucent)
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(Color.argb(30, 255, 255, 255));

        // Thumb knob
        thumbPaint.setStyle(Paint.Style.FILL);
        thumbPaint.setColor(Color.argb(180, 255, 255, 255));

        // Mode label (top-right area)
        modePaint.setStyle(Paint.Style.FILL);
        modePaint.setColor(Color.argb(200, 255, 255, 255));
        modePaint.setTextSize(42f);
        modePaint.setTextAlign(Paint.Align.RIGHT);
    }

    public void setFlyMode(boolean fly) {
        isFlyMode = fly;
        postInvalidate();
    }

    /** Called by GameSurfaceView when it knows its dimensions. */
    public void setCenter(float cx, float cy) {
        centerX = cx;
        centerY = cy;
        thumbX  = cx;
        thumbY  = cy;
        postInvalidate();
    }

    /** Update thumb direction from GameSurfaceView's touch handler. */
    public void update(boolean isActive, float tx, float ty) {
        active = isActive;
        thumbX = tx;
        thumbY = ty;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (centerX < 0) return; // not initialised yet

        // Always draw the base ring (greyed out when idle)
        canvas.drawCircle(centerX, centerY, BASE_RADIUS, fillPaint);
        canvas.drawCircle(centerX, centerY, BASE_RADIUS, ringPaint);

        // Centre dot
        canvas.drawCircle(centerX, centerY, 8f, ringPaint);

        // Thumb knob – only when a finger is down
        if (active) {
            canvas.drawCircle(thumbX, thumbY, THUMB_RADIUS, thumbPaint);
        }

        // Mode label – top-right corner
        String label = isFlyMode ? "✈ FLY" : "🚶 WALK";
        canvas.drawText(label, getWidth() - 30f, 70f, modePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return false; // pass all touches through
    }
}
