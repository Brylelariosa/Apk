package com.rubikailab.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.rubikailab.app.core.NativeBridge
import com.rubikailab.app.ui.MATCH
import com.rubikailab.app.ui.PageView
import com.rubikailab.app.ui.PlayPage
import com.rubikailab.app.ui.TestPage
import com.rubikailab.app.ui.Theme
import com.rubikailab.app.ui.TrainPage
import com.rubikailab.app.ui.WRAP
import com.rubikailab.app.ui.dp
import com.rubikailab.app.ui.heading
import com.rubikailab.app.ui.label
import com.rubikailab.app.ui.lp
import com.rubikailab.app.ui.muted

/**
 * Single activity with three tabs (Play, Train, Test). Only the selected page is attached to the window;
 * the pages themselves live as long as the activity, so their state survives tab switches.
 * Training is not tied to this activity: [TrainingService] keeps running when it is closed.
 */
class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val tabIcons = ArrayList<ImageView>()
    private val tabLabels = ArrayList<TextView>()
    private val tabViews = ArrayList<LinearLayout>()
    private val pages = arrayOfNulls<PageView>(TAB_NAMES.size)
    private var selected = -1
    private var resumed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        goFullscreen()
        if (!NativeBridge.ensureLoaded()) {
            showFailure(NativeBridge.loadError)
            return
        }
        buildUi()
        select(savedInstanceState?.getInt(KEY_TAB, 0) ?: 0)
        askForNotifications()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    /** Hides the status and navigation bars and lets the window run under a camera hole or notch. */
    @Suppress("DEPRECATION")
    private fun goFullscreen() {
        if (Build.VERSION.SDK_INT >= 28) {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = attrs
        }
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (selected >= 0) pageAt(selected).onShow()
    }

    override fun onPause() {
        if (selected >= 0) pageAt(selected).onHide()
        resumed = false
        super.onPause()
    }

    override fun onStop() {
        Lab.saveAll()
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, selected)
    }

    // ------------------------------------------------------------------ layout

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.BG)
        // The dark background runs under the camera hole; the controls stay clear of it.
        root.setOnApplyWindowInsetsListener { v, insets ->
            var l = 0
            var t = 0
            var r = 0
            var b = 0
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = insets.displayCutout
                if (cut != null) {
                    l = cut.safeInsetLeft
                    t = cut.safeInsetTop
                    r = cut.safeInsetRight
                    b = cut.safeInsetBottom
                }
            }
            v.setPadding(l, t, r, b)
            insets
        }

        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Theme.NAV)
        for (i in TAB_NAMES.indices) {
            val tab = LinearLayout(this)
            tab.orientation = LinearLayout.VERTICAL
            tab.gravity = Gravity.CENTER
            tab.setPadding(0, dp(8), 0, dp(8))
            val icon = ImageView(this)
            icon.setImageResource(TAB_ICONS[i])
            tab.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            val caption = label(TAB_NAMES[i], 11.5f, Theme.MUTED, true)
            caption.gravity = Gravity.CENTER
            val cp = LinearLayout.LayoutParams(WRAP, WRAP)
            cp.topMargin = dp(2)
            tab.addView(caption, cp)
            tab.setOnClickListener { select(i) }
            nav.addView(tab, lp(0, WRAP, 1f))
            tabViews.add(tab)
            tabIcons.add(icon)
            tabLabels.add(caption)
        }
        root.addView(nav, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun select(index: Int) {
        val target = index.coerceIn(0, TAB_NAMES.size - 1)
        if (target == selected && content.childCount > 0) return
        if (selected >= 0 && resumed) pageAt(selected).onHide()
        selected = target
        val page = pageAt(target)
        content.removeAllViews()
        content.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        for (i in tabViews.indices) styleTab(i, i == target)
        if (resumed) page.onShow()
    }

    private fun styleTab(i: Int, on: Boolean) {
        val color = if (on) Theme.ACCENT else Theme.MUTED
        tabIcons[i].setColorFilter(color)
        tabLabels[i].setTextColor(color)
        tabViews[i].setBackgroundColor(if (on) Theme.PANEL else Theme.NAV)
    }

    private fun pageAt(i: Int): PageView {
        val existing = pages[i]
        if (existing != null) return existing
        val created: PageView = when (i) {
            0 -> PlayPage(this)
            1 -> TrainPage(this)
            else -> TestPage(this)
        }
        pages[i] = created
        return created
    }

    /** Android 13+ asks before a foreground service may show its notification. Training works either way. */
    private fun askForNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun showFailure(message: String?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(Theme.BG)
        box.setPadding(dp(24), dp(24), dp(24), dp(24))
        box.addView(heading("Rubik AI Lab cannot start"))
        val detail = muted(message ?: "The native engine is not available on this device.")
        detail.setPadding(0, dp(12), 0, 0)
        box.addView(detail)
        setContentView(box)
    }

    private companion object {
        val TAB_NAMES = arrayOf("Play", "Train", "Test")
        val TAB_ICONS = intArrayOf(R.drawable.ic_cube, R.drawable.ic_chip, R.drawable.ic_chart)
        const val KEY_TAB = "tab"
    }
}
