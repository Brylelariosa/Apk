package com.livingworld.simulator

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.security.SecureRandom
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var glView: GlobeView
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())

    private var seed = "EARTH-7F42A91C"
    private val params = DoubleArray(12)
    private var running = false
    private var speedIdx = 2
    private var debugOn = false
    private var tickCount = 0
    private var pssMb = 0L
    private var lastPssMs = 0L
    private val st = DoubleArray(Native.STATE_LEN)

    private val scaleNames = arrayOf("1 hour", "1 day", "1 month", "1 year", "10 years", "100 years", "1,000 years", "1 million years")
    private val scaleYears = doubleArrayOf(1.0 / 8766.0, 1.0 / 365.25, 1.0 / 12.0, 1.0, 10.0, 100.0, 1000.0, 1.0e6)

    /** Planet presets, same order as the parameter rows: radius, gravity, rotation h, orbit d, tilt, sun, pressure, ocean, CO2, salinity, geothermal, sea level. */
    private class Preset(val name: String, val values: DoubleArray)

    private val presets = listOf(
        Preset("Earth", doubleArrayOf(6371.0, 9.80665, 24.0, 365.25, 23.44, 1.0, 1.0, 0.71, 420.0, 35.0, 1.0, 0.0)),
        Preset("Ice age", doubleArrayOf(6371.0, 9.80665, 24.0, 365.25, 23.44, 0.93, 1.0, 0.71, 180.0, 35.0, 1.0, 0.0)),
        Preset("Hothouse", doubleArrayOf(6371.0, 9.80665, 24.0, 365.25, 23.44, 1.10, 1.0, 0.71, 2000.0, 35.0, 1.0, 0.0)),
        Preset("Extreme seasons", doubleArrayOf(6371.0, 9.80665, 24.0, 500.0, 60.0, 1.0, 1.0, 0.71, 420.0, 35.0, 1.0, 0.0)),
        Preset("Long days", doubleArrayOf(6371.0, 9.80665, 72.0, 365.25, 23.44, 1.0, 1.0, 0.71, 420.0, 35.0, 1.0, 0.0)),
        Preset("Waterworld", doubleArrayOf(6371.0, 9.80665, 24.0, 365.25, 23.44, 1.0, 1.0, 0.93, 420.0, 35.0, 1.0, 0.0)),
        Preset("Dry world", doubleArrayOf(6371.0, 9.80665, 24.0, 365.25, 23.44, 1.05, 0.9, 0.28, 420.0, 35.0, 1.0, 0.0)),
        Preset("Giant world", doubleArrayOf(9000.0, 15.5, 24.0, 365.25, 23.44, 1.0, 1.0, 0.71, 420.0, 35.0, 1.4, 0.0))
    )

    // widgets
    private lateinit var tvSeed: TextView
    private lateinit var tvYear: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvPress: TextView
    private lateinit var tvOcean: TextView
    private lateinit var tvTilt: TextView
    private lateinit var tvRot: TextView
    private lateinit var btnSimulate: TextView
    private lateinit var btnPause: TextView
    private lateinit var btnSpeed: TextView
    private lateinit var tvDebug: TextView
    private lateinit var layerBox: ScrollView
    private lateinit var layerList: LinearLayout
    private lateinit var reticle: TextView
    private lateinit var loading: FrameLayout
    private lateinit var loadTitle: TextView
    private lateinit var loadStage: TextView
    private lateinit var loadBar: ProgressBar
    private lateinit var tvError: TextView
    private lateinit var softPill: TextView
    private lateinit var tvCiv: TextView
    private lateinit var toast: TextView
    private var lastMsgSeq = -1L
    private var toastUntil = 0L
    private val layerViews = ArrayList<TextView>()
    private var layerIdx = 0

    private fun dp(v: Float): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun pill(text: String, sp: Float = 12f): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(190, 18, 28, 52))
        bg.setStroke(dp(1f), Color.argb(120, 140, 170, 230))
        bg.cornerRadius = dp(9f).toFloat()
        t.background = bg
        t.isClickable = true
        return t
    }

    private fun label(text: String, sp: Float = 12f, mono: Boolean = false, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (mono) t.typeface = Typeface.MONOSPACE
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun panelBg(): GradientDrawable {
        val bg = GradientDrawable()
        bg.setColor(Color.argb(150, 6, 12, 28))
        bg.cornerRadius = dp(10f).toFloat()
        return bg
    }

    private fun randomSeed(): String {
        val r = SecureRandom()
        return String.format(Locale.US, "EARTH-%08X", r.nextInt())
    }

    private fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = java.io.StringWriter()
                error.printStackTrace(java.io.PrintWriter(sw))
                File(filesDir, "crash.log").appendText("Java exception in thread '" + thread.name + "':\n" + sw.toString().take(4000) + "\n")
            } catch (e: Throwable) {
            }
            if (previous != null) previous.uncaughtException(thread, error)
        }
    }

    private fun showPreviousCrash() {
        val text = Native.nTakeCrash()
        if (text.isEmpty()) return
        val tv = TextView(this)
        tv.text = text.take(3500)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(16f), dp(8f), dp(16f), dp(8f))
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Diagnostics from the previous session")
            .setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Living World diagnostics", text))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashHandler()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Native.nInit(filesDir.absolutePath)
        prefs = getSharedPreferences("lw", Context.MODE_PRIVATE)
        Native.nDefaultParams(params)
        val saved = prefs.getString("params", null)
        if (saved != null) {
            val parts = saved.split(",")
            if (parts.size == params.size) for (i in params.indices) parts[i].toDoubleOrNull()?.let { params[i] = it }
        }
        seed = prefs.getString("seed", seed) ?: seed
        speedIdx = prefs.getInt("speed", speedIdx).coerceIn(0, scaleNames.size - 1)

        glView = GlobeView(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(glView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildInfoPanel(root)
        buildDebugPanel(root)
        buildBottomBar(root)
        buildToast(root)
        buildLoading(root)
        setContentView(root)
        showPreviousCrash()
        Native.nGetState(st)
        // when the activity is recreated while the native world is alive, keep it instead of regenerating
        if (st[S.READY] < 0.5 && st[S.BUSY] < 0.5) startGenerate(false)
    }

    // ------------------------------------------------------------------------------------------ UI
    private fun buildInfoPanel(root: FrameLayout) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = panelBg()
        box.setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
        box.addView(label("PLANET", 13f, bold = true))
        tvSeed = label("", 11f); box.addView(tvSeed)
        tvYear = label("", 11f); box.addView(tvYear)
        tvTemp = label("", 11f); box.addView(tvTemp)
        tvPress = label("", 11f); box.addView(tvPress)
        tvOcean = label("", 11f); box.addView(tvOcean)
        tvTilt = label("", 11f); box.addView(tvTilt)
        tvRot = label("", 11f); box.addView(tvRot)
        tvCiv = label("", 11f)
        tvCiv.setTextColor(Color.rgb(255, 214, 140))
        val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.topMargin = dp(5f)
        box.addView(tvCiv, clp)
        btnSimulate = pill("SIMULATE", 12f)
        btnSimulate.setOnClickListener { setRunning(!running) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6f)
        box.addView(btnSimulate, lp)
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        flp.setMargins(dp(10f), dp(26f), 0, 0)
        root.addView(box, flp)

        softPill = label("", 11f)
        softPill.background = panelBg()
        softPill.setPadding(dp(10f), dp(5f), dp(10f), dp(5f))
        softPill.visibility = View.GONE
        val splp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        splp.topMargin = dp(26f)
        root.addView(softPill, splp)
    }

    private fun buildDebugPanel(root: FrameLayout) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.END
        val dbg = pill("DEBUG", 11f)
        dbg.setOnClickListener { setDebug(!debugOn) }
        col.addView(dbg)
        tvDebug = label("", 9f, mono = true)
        tvDebug.background = panelBg()
        tvDebug.setPadding(dp(6f), dp(4f), dp(6f), dp(4f))
        tvDebug.visibility = View.GONE
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = dp(4f)
        col.addView(tvDebug, dlp)
        layerBox = ScrollView(this)
        layerList = LinearLayout(this)
        layerList.orientation = LinearLayout.VERTICAL
        layerBox.addView(layerList)
        layerBox.visibility = View.GONE
        for (i in Layers.names.indices) {
            val t = pill(Layers.names[i], 10f)
            t.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            t.setOnClickListener { selectLayer(i) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(3f)
            layerList.addView(t, lp)
            layerViews.add(t)
        }
        selectLayer(0)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(210f))
        llp.topMargin = dp(4f)
        col.addView(layerBox, llp)
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        flp.setMargins(0, dp(26f), dp(10f), 0)
        root.addView(col, flp)

        reticle = label("+", 22f)
        reticle.alpha = 0.55f
        root.addView(reticle, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        tvError = label("", 10f, mono = true)
        tvError.setTextColor(Color.rgb(255, 120, 120))
        tvError.visibility = View.GONE
        val elp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        elp.bottomMargin = dp(62f)
        root.addView(tvError, elp)
    }

    private fun buildBottomBar(root: FrameLayout) {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8f), dp(4f), dp(8f), dp(8f))
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(6f)
            bar.addView(v, lp)
        }
        val bSettle = pill("Settle here")
        bSettle.setOnClickListener { settleHere() }
        add(bSettle)
        val bChron = pill("Chronicle")
        bChron.setOnClickListener { chronicleDialog() }
        add(bChron)
        btnSpeed = pill("")
        btnSpeed.setOnClickListener {
            speedIdx = (speedIdx + 1) % scaleNames.size
            Native.nSetSpeed(scaleYears[speedIdx])
            prefs.edit().putInt("speed", speedIdx).apply()
            updateSpeedLabel()
        }
        add(btnSpeed)
        btnPause = pill("Pause")
        btnPause.setOnClickListener { setRunning(false) }
        add(btnPause)
        val bStep = pill("Step")
        bStep.setOnClickListener { Native.nStep(scaleYears[speedIdx]) }
        add(bStep)
        val bSun = pill("Sun +6h")
        bSun.setOnClickListener { Native.nShiftHours(6.0) }
        add(bSun)
        val bView = pill("Reset view")
        bView.setOnClickListener { Native.nResetView() }
        add(bView)
        val bWhy = pill("Why?")
        bWhy.setOnClickListener { whyDialog() }
        add(bWhy)
        val bPar = pill("Planet parameters")
        bPar.setOnClickListener { paramsDialog() }
        add(bPar)
        val bNew = pill("Generate New Planet")
        bNew.setOnClickListener { seed = randomSeed(); startGenerate(true) }
        add(bNew)
        val bRegen = pill("Regenerate From Seed")
        bRegen.setOnClickListener { startGenerate(true) }
        add(bRegen)
        val bSeed = pill("Seed")
        bSeed.setOnClickListener { seedDialog() }
        add(bSeed)
        scroll.addView(bar)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        Native.nSetSpeed(scaleYears[speedIdx])
        updateSpeedLabel()
        setRunning(false)
    }

    private fun buildToast(root: FrameLayout) {
        toast = label("", 12f)
        toast.background = panelBg()
        toast.setPadding(dp(12f), dp(7f), dp(12f), dp(7f))
        toast.gravity = Gravity.CENTER
        toast.visibility = View.GONE
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(104f)
        lp.leftMargin = dp(12f)
        lp.rightMargin = dp(12f)
        root.addView(toast, lp)
    }

    private fun buildLoading(root: FrameLayout) {
        loading = FrameLayout(this)
        loading.setBackgroundColor(Color.argb(215, 2, 6, 16))
        loading.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        loadTitle = label("Generating planet", 18f, bold = true)
        col.addView(loadTitle)
        loadStage = label("", 12f)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(8f)
        col.addView(loadStage, slp)
        loadBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        loadBar.max = 1000
        val blp = LinearLayout.LayoutParams(dp(240f), dp(10f))
        blp.topMargin = dp(12f)
        col.addView(loadBar, blp)
        val hint = label("Drag: rotate  -  Pinch: zoom  -  Double tap: zoom in  -  Two-finger drag: tilt / twist\nThe + marks the spot: Settle here starts a civilization there", 11f)
        hint.setTextColor(Color.argb(200, 170, 190, 230))
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(18f)
        col.addView(hint, hlp)
        loading.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(loading, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------------------------------ actions
    private fun startGenerate(save: Boolean) {
        Native.nGetState(st)
        if (st[S.BUSY] > 0.5) return
        if (save) saveState()
        prefs.edit().putString("seed", seed).apply()
        setRunning(false)
        Native.nGenerate(seed, params.copyOf())
        loading.visibility = View.VISIBLE
        loadTitle.text = "Generating planet"
    }

    private fun startRetune() {
        Native.nGetState(st)
        if (st[S.BUSY] > 0.5) return
        saveState()
        setRunning(false)
        Native.nRetune(params.copyOf())
        loading.visibility = View.VISIBLE
        loadTitle.text = "Re-tuning the climate"
    }

    private fun showToast(text: String, ms: Long) {
        toast.text = text
        toast.visibility = View.VISIBLE
        toastUntil = System.currentTimeMillis() + ms
    }

    private fun fmtPeople(x: Double): String = when {
        x >= 1.0e9 -> String.format(Locale.US, "%.2f billion", x / 1.0e9)
        x >= 1.0e6 -> String.format(Locale.US, "%.1f million", x / 1.0e6)
        x >= 1.0e3 -> String.format(Locale.US, "%.0fk", x / 1.0e3)
        else -> String.format(Locale.US, "%.0f", x)
    }

    /** Put settlers on the land under the crosshair. The first time, start the clock at 10 years per second. */
    private fun settleHere() {
        Native.nGetState(st)
        if (st[S.READY] < 0.5 || st[S.BUSY] > 0.5) return
        val first = st[S.CIV] < 0.5
        Native.nSettle(st[S.CAM_LAT], st[S.CAM_LON])
        if (first && !running) {
            if (speedIdx < 4) {
                speedIdx = 4
                Native.nSetSpeed(scaleYears[speedIdx])
                prefs.edit().putInt("speed", speedIdx).apply()
                updateSpeedLabel()
            }
            setRunning(true)
        }
    }

    private fun chronicleDialog() {
        val text = Native.nString(6)
        val tv = TextView(this)
        tv.text = if (text.isEmpty()) "Nothing has happened yet.\n\nMove the + onto fertile land (green, near water), tap \"Settle here\" and let time run. Raise the speed to watch people spread, found cities and meet disasters." else text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle("Chronicle").setView(sv).setPositiveButton("Close", null).show()
    }

    private fun saveState() {
        prefs.edit().putString("seed", seed).putString("params", params.joinToString(",") { String.format(Locale.US, "%.6f", it) }).apply()
    }

    private fun setRunning(on: Boolean) {
        running = on
        Native.nSetRunning(on)
        btnSimulate.text = if (on) "PAUSE" else "SIMULATE"
        btnPause.alpha = if (on) 1.0f else 0.5f
    }

    private fun updateSpeedLabel() {
        btnSpeed.text = "Speed: " + scaleNames[speedIdx] + "/s"
    }

    private fun setDebug(on: Boolean) {
        debugOn = on
        val v = if (on) View.VISIBLE else View.GONE
        tvDebug.visibility = v
        layerBox.visibility = v
    }

    private fun selectLayer(i: Int) {
        layerIdx = i
        Native.nSetLayer(i)
        for (k in layerViews.indices) layerViews[k].alpha = if (k == i) 1.0f else 0.62f
    }

    private fun seedDialog() {
        val et = EditText(this)
        et.setText(seed)
        et.setSelectAllOnFocus(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        AlertDialog.Builder(this)
            .setTitle("World seed")
            .setMessage("The same seed always rebuilds the same planet (with the same planet parameters).")
            .setView(et)
            .setPositiveButton("Regenerate") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) { seed = s; startGenerate(true) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun whyDialog() {
        val text = Native.nString(5)
        val lat = st[S.CAM_LAT]
        val lon = st[S.CAM_LON]
        val tv = TextView(this)
        tv.text = if (text.isEmpty()) "Nothing to explain yet - the planet is still being built." else text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
        val sv = ScrollView(this)
        sv.addView(tv)
        val title = String.format(Locale.US, "Why is this here?  %.1f%s %.1f%s", Math.abs(lat), if (lat >= 0) "N" else "S", Math.abs(lon), if (lon >= 0) "E" else "W")
        AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show()
    }

    private class PRow(val name: String, val idx: Int, val min: Double, val max: Double, val step: Double, val fmt: String)

    /** true when only climate-side settings differ from the current planet (then the continents can be kept) */
    private fun terrainSame(w: DoubleArray): Boolean {
        val keys = intArrayOf(0, 1, 7, 10, 11)
        for (k in keys) if (Math.abs(w[k] - params[k]) > 1e-9) return false
        return true
    }

    private fun paramsDialog() {
        val rows = listOf(
            PRow("Radius (km)", 0, 2000.0, 12000.0, 250.0, "%.0f"),
            PRow("Gravity (m/s2)", 1, 3.0, 30.0, 0.5, "%.1f"),
            PRow("Rotation (hours)", 2, 6.0, 96.0, 2.0, "%.0f"),
            PRow("Orbit (days)", 3, 100.0, 1500.0, 20.0, "%.0f"),
            PRow("Axial tilt (deg)", 4, 0.0, 85.0, 2.5, "%.1f"),
            PRow("Solar intensity (x)", 5, 0.6, 1.5, 0.05, "%.2f"),
            PRow("Pressure (atm)", 6, 0.3, 3.0, 0.1, "%.1f"),
            PRow("Ocean coverage", 7, 0.2, 0.95, 0.05, "%.2f"),
            PRow("CO2 (ppm)", 8, 100.0, 4000.0, 100.0, "%.0f"),
            PRow("Salinity (PSU)", 9, 0.0, 50.0, 2.5, "%.1f"),
            PRow("Geothermal (x)", 10, 0.4, 3.0, 0.1, "%.1f"),
            PRow("Sea level offset (m)", 11, -200.0, 200.0, 25.0, "%.0f")
        )
        val work = params.copyOf()
        val valueViews = ArrayList<TextView>()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14f), dp(8f), dp(14f), dp(4f))
        val hint = TextView(this)
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        hint.setTextColor(Color.rgb(150, 190, 120))
        hint.setPadding(0, 0, 0, dp(8f))
        fun refresh() {
            for (i in rows.indices) valueViews[i].text = String.format(Locale.US, rows[i].fmt, work[rows[i].idx])
            hint.text = if (terrainSame(work) && st[S.READY] > 0.5) {
                "Only the climate changes: your continents and people stay."
            } else {
                "Terrain settings changed: a brand new planet will be built."
            }
        }
        val reset = TextView(this)
        reset.text = "Reset to Earth"
        reset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        reset.setTextColor(Color.rgb(40, 110, 200))
        reset.setPadding(0, dp(4f), 0, dp(8f))
        reset.setOnClickListener { Native.nDefaultParams(work); refresh() }
        col.addView(reset)
        val presetScroll = HorizontalScrollView(this)
        presetScroll.isHorizontalScrollBarEnabled = false
        val presetRow = LinearLayout(this)
        presetRow.orientation = LinearLayout.HORIZONTAL
        for (pr in presets) {
            val chip = TextView(this)
            chip.text = pr.name
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            chip.setTextColor(Color.rgb(40, 110, 200))
            chip.setPadding(0, dp(2f), dp(16f), dp(8f))
            chip.setOnClickListener {
                for (i in work.indices) work[i] = pr.values[i]
                refresh()
            }
            presetRow.addView(chip)
        }
        presetScroll.addView(presetRow)
        col.addView(presetScroll)
        col.addView(hint)
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val name = TextView(this)
            name.text = r.name
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val minus = TextView(this)
            minus.text = "  -  "
            minus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            val value = TextView(this)
            value.gravity = Gravity.CENTER
            value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            val plus = TextView(this)
            plus.text = "  +  "
            plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            minus.setOnClickListener { work[r.idx] = (work[r.idx] - r.step).coerceIn(r.min, r.max); refresh() }
            plus.setOnClickListener { work[r.idx] = (work[r.idx] + r.step).coerceIn(r.min, r.max); refresh() }
            row.addView(minus)
            row.addView(value, LinearLayout.LayoutParams(dp(64f), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(plus)
            valueViews.add(value)
            col.addView(row)
        }
        refresh()
        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Planet parameters")
            .setView(sv)
            .setPositiveButton("Apply") { _, _ ->
                val keep = terrainSame(work) && st[S.READY] > 0.5
                for (i in params.indices) params[i] = work[i]
                if (keep) startRetune() else startGenerate(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------------------------------ periodic updates
    private val tick = object : Runnable {
        override fun run() {
            tickCount++
            Native.nGetState(st)
            updateLoading()
            pollMessages()
            if (tickCount % 3 == 0) updatePanels()
            ui.postDelayed(this, 100L)
        }
    }

    /** Civilization news (settlers, new ages, disasters ...) appears as a short message above the bottom bar. */
    private fun pollMessages() {
        val seq = st[S.CIV + 6].toLong()
        if (seq != lastMsgSeq) {
            lastMsgSeq = seq
            val m = Native.nString(7)
            if (m.isNotEmpty()) showToast(m, 7000L)
        }
        if (toast.visibility == View.VISIBLE && System.currentTimeMillis() > toastUntil) toast.visibility = View.GONE
    }

    private fun updateLoading() {
        val ready = st[S.READY] > 0.5
        val busy = st[S.BUSY] > 0.5
        val roots = st[S.ROOTS] > 0.5
        if (busy || !ready || !roots) {
            loading.visibility = View.VISIBLE
            softPill.visibility = View.GONE
            if (busy) {
                loadTitle.text = Native.nString(0)
                loadStage.text = Native.nString(1)
                loadBar.isIndeterminate = false
                loadBar.progress = (st[S.PROGRESS] * 1000.0).toInt().coerceIn(0, 1000)
            } else if (!ready) {
                val err = Native.nString(2)
                if (err.isNotEmpty()) {
                    loadTitle.text = "Generation failed"
                    loadStage.text = err
                    loadBar.isIndeterminate = false
                } else {
                    loadTitle.text = "Generating planet"
                    loadStage.text = ""
                    loadBar.isIndeterminate = true
                }
            } else {
                loadTitle.text = "Building terrain tiles"
                loadStage.text = String.format(Locale.US, "%d of 6 base tiles ready", st[S.ROOTS_DONE].toInt())
                loadBar.isIndeterminate = true
            }
        } else {
            loading.visibility = View.GONE
            if (st[S.SOFT] > 0.5) {
                softPill.visibility = View.VISIBLE
                softPill.text = "Slow processes (ice, soils, vegetation): " + Native.nString(1)
            } else {
                softPill.visibility = View.GONE
            }
        }
    }

    private fun fmtYears(y: Double): String {
        return if (y < 1.0e5) String.format(Locale.US, "%,d", y.toLong()) else String.format(Locale.US, "%.2f Myr", y / 1.0e6)
    }

    private fun updatePanels() {
        val i0 = S.INFO
        val day = (st[i0 + 1] * st[i0 + 10]).toInt() + 1
        tvSeed.text = "Seed: " + seed
        tvYear.text = "Year: " + fmtYears(Math.floor(st[i0])) + "  -  Day " + day
        tvTemp.text = String.format(Locale.US, "Temperature: %.1f C (global mean)", st[i0 + 3])
        tvPress.text = String.format(Locale.US, "Atmospheric Pressure: %.2f atm", st[i0 + 4])
        tvOcean.text = String.format(Locale.US, "Ocean Coverage: %.0f %%", st[i0 + 5] * 100.0)
        tvTilt.text = String.format(Locale.US, "Axial Tilt: %.1f deg", st[i0 + 6])
        tvRot.text = String.format(Locale.US, "Rotation: %.1f h", st[i0 + 7])
        if (st[S.CIV] > 0.5) {
            tvCiv.text = String.format(Locale.US, "People: %s  -  Cities: %d\n%s  (%d%%)", fmtPeople(st[S.CIV + 1]), st[S.CIV + 2].toInt(), Native.nString(8), (st[S.CIV + 4] * 100.0).toInt())
        } else {
            tvCiv.text = "No people yet - tap \"Settle here\""
        }
        val err = Native.nString(2)
        if (err.isNotEmpty() && st[S.READY] > 0.5) {
            tvError.text = err
            tvError.visibility = View.VISIBLE
        } else {
            tvError.visibility = View.GONE
        }
        if (debugOn) updateDebug()
    }

    private fun updateDebug() {
        val now = System.currentTimeMillis()
        if (now - lastPssMs > 2000L) {
            val mi = Debug.MemoryInfo()
            Debug.getMemoryInfo(mi)
            pssMb = mi.totalPss / 1024L
            lastPssMs = now
        }
        val rt = Runtime.getRuntime()
        val javaMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L
        val nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576L
        val t = S.TIMING
        val sb = StringBuilder()
        sb.append(String.format(Locale.US, "FPS %.1f  frame %.1f ms\n", st[S.FPS], st[S.FRAME_MS]))
        sb.append(String.format(Locale.US, "RAM pss %d MB  native %d  java %d\n", pssMb, nativeMb, javaMb))
        sb.append(String.format(Locale.US, "Chunks loaded %d  visible %d\n", st[S.GPU_CHUNKS].toInt(), st[S.VISIBLE].toInt()))
        sb.append(String.format(Locale.US, "Gen queue %d  workers %d/%d  up %d/f\n", st[S.QUEUED].toInt(), st[S.ACTIVE].toInt(), st[S.WORKERS].toInt(), st[S.UPLOADS].toInt()))
        sb.append(String.format(Locale.US, "Mesh+tex avg %.1f ms (n=%d)\n", st[t + 8], st[t + 9].toLong()))
        sb.append(String.format(Locale.US, "Sim step %.0f ms  climate %.0f ms/step\n", st[t + 4], st[t + 5]))
        sb.append(String.format(Locale.US, "Gen %.1f s: terrain %.1f climate %.1f\n", st[t] / 1000.0, st[t + 1] / 1000.0, st[t + 2] / 1000.0))
        sb.append(String.format(Locale.US, "  rivers/soil/biomes %.1f s\n", st[t + 3] / 1000.0))
        sb.append(String.format(Locale.US, "GPU tris %dk draws %d\n", st[S.TRIS].toInt() / 1000, st[S.DRAWS].toInt()))
        sb.append(Native.nString(3).take(44)).append('\n')
        sb.append(String.format(Locale.US, "Cam alt %s  layer %s\n", fmtAlt(st[S.CAM_ALT]), Layers.names[layerIdx]))
        sb.append(String.format(Locale.US, "Water budget error %.1f%%\n", st[S.INFO + 12] * 100.0))
        sb.append(Native.nString(4))
        tvDebug.text = sb.toString()
    }

    private fun fmtAlt(m: Double): String = if (m >= 1.0e6) String.format(Locale.US, "%.0f km", m / 1000.0) else if (m >= 1.0e4) String.format(Locale.US, "%.1f km", m / 1000.0) else String.format(Locale.US, "%.0f m", m)

    // ------------------------------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        glView.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        glView.onPause()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
}
