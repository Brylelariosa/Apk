package com.livingworld.simulator

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** OpenGL ES 3 surface. Rendering and gesture maths live in Rust; this class only forwards events. */
class GlobeView(context: Context) : GLSurfaceView(context) {
    private val glRenderer = object : GLSurfaceView.Renderer {
        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            Native.nSurfaceCreated()
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            Native.nSurfaceChanged(width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            Native.nDrawFrame()
        }
    }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 0, 24, 0)
        setRenderer(glRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val n = e.pointerCount
        val t = e.eventTime
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                Native.nTouch(0, 1, e.getX(0).toDouble(), e.getY(0).toDouble(), 0.0, 0.0, t)
            MotionEvent.ACTION_POINTER_DOWN ->
                if (n >= 2) Native.nTouch(4, 2, e.getX(0).toDouble(), e.getY(0).toDouble(), e.getX(1).toDouble(), e.getY(1).toDouble(), t)
            MotionEvent.ACTION_MOVE ->
                if (n >= 2) Native.nTouch(1, 2, e.getX(0).toDouble(), e.getY(0).toDouble(), e.getX(1).toDouble(), e.getY(1).toDouble(), t)
                else Native.nTouch(1, 1, e.getX(0).toDouble(), e.getY(0).toDouble(), 0.0, 0.0, t)
            MotionEvent.ACTION_POINTER_UP -> {
                val up = e.actionIndex
                val keep = ArrayList<Int>()
                for (i in 0 until n) if (i != up) keep.add(i)
                if (keep.size == 1) {
                    Native.nTouch(5, 1, e.getX(keep[0]).toDouble(), e.getY(keep[0]).toDouble(), 0.0, 0.0, t)
                } else if (keep.size >= 2) {
                    Native.nTouch(4, 2, e.getX(keep[0]).toDouble(), e.getY(keep[0]).toDouble(), e.getX(keep[1]).toDouble(), e.getY(keep[1]).toDouble(), t)
                }
            }
            MotionEvent.ACTION_UP ->
                Native.nTouch(2, 1, e.getX(0).toDouble(), e.getY(0).toDouble(), 0.0, 0.0, t)
            MotionEvent.ACTION_CANCEL ->
                Native.nTouch(3, 0, 0.0, 0.0, 0.0, 0.0, t)
            else -> {}
        }
        return true
    }
}
