//! 3D simplex noise with analytic gradient. Deterministic per seed.

use crate::mathx::*;

const GRAD: [[f32; 3]; 12] = [
    [1.0, 1.0, 0.0],
    [-1.0, 1.0, 0.0],
    [1.0, -1.0, 0.0],
    [-1.0, -1.0, 0.0],
    [1.0, 0.0, 1.0],
    [-1.0, 0.0, 1.0],
    [1.0, 0.0, -1.0],
    [-1.0, 0.0, -1.0],
    [0.0, 1.0, 1.0],
    [0.0, -1.0, 1.0],
    [0.0, 1.0, -1.0],
    [0.0, -1.0, -1.0],
];

#[derive(Clone)]
pub struct Noise {
    perm: [u8; 512],
    pm12: [u8; 512],
}

#[inline(always)]
fn ffloor(x: f32) -> i32 {
    let i = x as i32;
    if x < (i as f32) {
        i - 1
    } else {
        i
    }
}

#[inline(always)]
fn corner(gg: &[f32; 3], x: f32, y: f32, z: f32, n: &mut f32, gx: &mut f32, gy: &mut f32, gz: &mut f32, want_g: bool) {
    let t0 = 0.6f32 - x * x - y * y - z * z;
    if t0 > 0.0 {
        let t2 = t0 * t0;
        let t4 = t2 * t2;
        let gd = gg[0] * x + gg[1] * y + gg[2] * z;
        *n += t4 * gd;
        if want_g {
            let t3 = t2 * t0;
            *gx += t4 * gg[0] - 8.0 * t3 * gd * x;
            *gy += t4 * gg[1] - 8.0 * t3 * gd * y;
            *gz += t4 * gg[2] - 8.0 * t3 * gd * z;
        }
    }
}

impl Noise {
    pub fn new(seed: u64) -> Noise {
        let mut n = Noise { perm: [0u8; 512], pm12: [0u8; 512] };
        n.init(seed);
        n
    }

    pub fn init(&mut self, seed: u64) {
        let mut p = [0u8; 256];
        for i in 0..256usize {
            p[i] = i as u8;
        }
        let mut r = Rng::new(seed ^ 0xA5A5A5A5DEADBEEFu64);
        let mut i = 255usize;
        while i > 0 {
            let j = (r.next() % ((i as u64) + 1)) as usize;
            let t = p[i];
            p[i] = p[j];
            p[j] = t;
            i -= 1;
        }
        for i in 0..512usize {
            self.perm[i] = p[i & 255];
            self.pm12[i] = self.perm[i] % 12;
        }
    }

    #[inline(always)]
    fn eval(&self, xin: f32, yin: f32, zin: f32, want_g: bool) -> (f32, f32, f32, f32) {
        let f3 = 1.0f32 / 3.0;
        let g3 = 1.0f32 / 6.0;
        let s = (xin + yin + zin) * f3;
        let i = ffloor(xin + s);
        let j = ffloor(yin + s);
        let k = ffloor(zin + s);
        let t = ((i + j + k) as f32) * g3;
        let x0 = xin - ((i as f32) - t);
        let y0 = yin - ((j as f32) - t);
        let z0 = zin - ((k as f32) - t);
        let a = (x0 >= y0) as i32;
        let b = (y0 >= z0) as i32;
        let c = (x0 >= z0) as i32;
        let i1 = a & (b | c);
        let j1 = (1 - a) & b;
        let k1 = (1 - b) & (1 - (a & c));
        let i2 = a | (b & c);
        let j2 = (1 - a) | b;
        let k2 = (1 - b) | ((1 - a) & (1 - c));
        let x1 = x0 - (i1 as f32) + g3;
        let y1 = y0 - (j1 as f32) + g3;
        let z1 = z0 - (k1 as f32) + g3;
        let x2 = x0 - (i2 as f32) + 2.0 * g3;
        let y2 = y0 - (j2 as f32) + 2.0 * g3;
        let z2 = z0 - (k2 as f32) + 2.0 * g3;
        let x3 = x0 - 1.0 + 3.0 * g3;
        let y3 = y0 - 1.0 + 3.0 * g3;
        let z3 = z0 - 1.0 + 3.0 * g3;
        let ii = (i & 255) as usize;
        let jj = (j & 255) as usize;
        let kk = (k & 255) as usize;
        let (i1u, j1u, k1u) = (i1 as usize, j1 as usize, k1 as usize);
        let (i2u, j2u, k2u) = (i2 as usize, j2 as usize, k2 as usize);
        let gi0 = self.pm12[ii + self.perm[jj + self.perm[kk] as usize] as usize] as usize;
        let gi1 = self.pm12[ii + i1u + self.perm[jj + j1u + self.perm[kk + k1u] as usize] as usize] as usize;
        let gi2 = self.pm12[ii + i2u + self.perm[jj + j2u + self.perm[kk + k2u] as usize] as usize] as usize;
        let gi3 = self.pm12[ii + 1 + self.perm[jj + 1 + self.perm[kk + 1] as usize] as usize] as usize;
        let mut n = 0.0f32;
        let mut gx = 0.0f32;
        let mut gy = 0.0f32;
        let mut gz = 0.0f32;
        corner(&GRAD[gi0], x0, y0, z0, &mut n, &mut gx, &mut gy, &mut gz, want_g);
        corner(&GRAD[gi1], x1, y1, z1, &mut n, &mut gx, &mut gy, &mut gz, want_g);
        corner(&GRAD[gi2], x2, y2, z2, &mut n, &mut gx, &mut gy, &mut gz, want_g);
        corner(&GRAD[gi3], x3, y3, z3, &mut n, &mut gx, &mut gy, &mut gz, want_g);
        (32.0 * n, 32.0 * gx, 32.0 * gy, 32.0 * gz)
    }

    /// value in about [-1,1]
    #[inline]
    pub fn n3(&self, x: f32, y: f32, z: f32) -> f32 {
        self.eval(x, y, z, false).0
    }

    /// value and d(value)/d(x,y,z)
    #[inline]
    pub fn n3d(&self, x: f32, y: f32, z: f32) -> (f32, [f32; 3]) {
        let r = self.eval(x, y, z, true);
        (r.0, [r.1, r.2, r.3])
    }

    /// fractal Brownian motion, normalised to about [-1,1]
    pub fn fbm(&self, x: f32, y: f32, z: f32, oct: i32) -> f32 {
        self.fbm_lg(x, y, z, oct, 2.0, 0.5)
    }
    pub fn fbm_lg(&self, x: f32, y: f32, z: f32, oct: i32, lac: f32, gain: f32) -> f32 {
        let mut sum = 0.0f32;
        let mut amp = 1.0f32;
        let mut norm = 0.0f32;
        let mut f = 1.0f32;
        for o in 0..oct {
            let of = o as f32;
            sum += amp * self.n3(x * f + 17.3 * of, y * f - 9.1 * of, z * f + 5.7 * of);
            norm += amp;
            amp *= gain;
            f *= lac;
        }
        sum / norm
    }
    /// ridged multifractal in [0,1] (sharp crests)
    pub fn ridged(&self, x: f32, y: f32, z: f32, oct: i32) -> f32 {
        self.ridged_lg(x, y, z, oct, 2.0, 0.5)
    }
    pub fn ridged_lg(&self, x: f32, y: f32, z: f32, oct: i32, lac: f32, gain: f32) -> f32 {
        let mut sum = 0.0f32;
        let mut amp = 1.0f32;
        let mut norm = 0.0f32;
        let mut f = 1.0f32;
        let mut w = 1.0f32;
        for o in 0..oct {
            let of = o as f32;
            let mut n = 1.0 - self.n3(x * f + 31.7 * of, y * f + 3.3 * of, z * f - 11.9 * of).abs();
            n *= n;
            n *= w;
            w = clampv(n * 1.6, 0.0, 1.0);
            sum += amp * n;
            norm += amp;
            amp *= gain;
            f *= lac;
        }
        sum / norm
    }
}
