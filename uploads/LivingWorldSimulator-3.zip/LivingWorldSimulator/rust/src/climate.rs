//! Coupled seasonal climate on the coarse grid:
//!   sun -> insolation -> surface/air energy balance (+ ocean currents, upwelling, sea ice, snow)
//!   -> pressure belts (Hadley/Ferrel/polar cells that follow the thermal equator) -> winds
//!   -> wind-driven ocean gyres -> moisture transport, orographic lift, rain shadows
//!   -> clouds, precipitation, snow, soil moisture, runoff.

use crate::grid::*;
use crate::mathx::*;
use crate::params::*;
use crate::world_data::*;
use std::sync::Arc;

const LV: f64 = 2.5e6;
const RV: f64 = 461.5;
const RHO_W: f64 = 1025.0;
const CW: f64 = 4000.0;

#[inline]
fn sgn(x: f64) -> f64 {
    if x < 0.0 {
        -1.0
    } else {
        1.0
    }
}

pub fn solar_geometry(dv: &Derived, yf: f64) -> (f64, f64) {
    let varpi = 282.94 * DEG2RAD;
    let e = dv.ecc;
    let nu0 = -varpi;
    let e0 = 2.0 * datan2((1.0 - e).sqrt() * dsin(nu0 / 2.0), (1.0 + e).sqrt() * dcos(nu0 / 2.0));
    let m = (e0 - e * dsin(e0)) + TAU * yf;
    let mut ee = m;
    for _ in 0..7 {
        ee = m + e * dsin(ee);
    }
    let nu = 2.0 * datan2((1.0 + e).sqrt() * dsin(ee / 2.0), (1.0 - e).sqrt() * dcos(ee / 2.0));
    let r = 1.0 - e * dcos(ee);
    let lam = nu + varpi;
    let decl = dasin(dsin(dv.tilt) * dsin(lam));
    (decl, 1.0 / (r * r))
}

#[inline]
fn lut(tab: &[f32], tk: f64) -> f64 {
    let mut x = (tk - 150.0) * 4.0;
    if x < 0.0 {
        x = 0.0;
    }
    let lim = (tab.len() as f64) - 2.0;
    if x > lim {
        x = lim;
    }
    let i = x as usize;
    let f = x - (i as f64);
    (tab[i] as f64) * (1.0 - f) + (tab[i + 1] as f64) * f
}

struct LocalCtx<'a> {
    cg: &'a CubeGrid,
    lf: &'a [f32],
    lw_u: &'a [f32],
    edge_dir: &'a [f32],
    edge_inv_l: &'a [f32],
    wind: &'a [f32],
    cur: &'a [f32],
    cs: &'a [f32],
    lam: &'a [f32],
    sws: &'a [f32],
    swa: &'a [f32],
    ta_old: &'a [f32],
    ts_old: &'a [f32],
    up_s: &'a [f32],
    up_mean: f64,
    dt: f64,
    ca: f64,
    cadv: f64,
    b: f64,
    a: f64,
    dd: f64,
    kap: f64,
    cocean: f64,
    t_freeze: f64,
}

/// Local implicit update of (air, surface) temperature in one cell. Surface temperature is eliminated.
/// returns (Tan, Tsn, dEff, eLoc)
fn local_update(x: &LocalCtx, c: usize, ta: &[f32], ts: &[f32]) -> (f64, f64, f64, f64) {
    let cg = x.cg;
    let nb = &cg.nbr[c * 8..c * 8 + 8];
    let mut dsum = 0.0f64;
    let mut dnb = 0.0f64;
    for k in 0..8usize {
        let q = nb[k];
        if q < 0 {
            continue;
        }
        let w = x.dd * (x.lw_u[c * 8 + k] as f64);
        dsum += w;
        dnb += w * (ta[q as usize] as f64);
    }
    let mut asum = 0.0f64;
    let mut anb = 0.0f64;
    let mut osum = 0.0f64;
    let mut onb = 0.0f64;
    let lf = x.lf[c] as f64;
    let co = (1.0 - lf) * x.cocean * x.kap;
    for k in 0..4usize {
        let q = nb[k];
        if q < 0 {
            continue;
        }
        let qu = q as usize;
        let eo = (c * 4 + k) * 3;
        let d0 = x.edge_dir[eo];
        let d1 = x.edge_dir[eo + 1];
        let d2 = x.edge_dir[eo + 2];
        let il = x.edge_inv_l[c * 4 + k] as f64;
        let vd = (x.wind[c * 3] * d0 + x.wind[c * 3 + 1] * d1 + x.wind[c * 3 + 2] * d2) as f64;
        if vd < 0.0 {
            let a = x.cadv * (-vd) * il;
            asum += a;
            anb += a * (ta[qu] as f64);
        }
        if co > 0.0 {
            let cd = (x.cur[c * 3] * d0 + x.cur[c * 3 + 1] * d1 + x.cur[c * 3 + 2] * d2) as f64;
            if cd < 0.0 {
                let a = co * (-cd) * il;
                osum += a;
                onb += a * (ts[qu] as f64);
            }
        }
    }
    let lamc = x.lam[c] as f64;
    let csc = x.cs[c] as f64;
    let a1 = csc / x.dt + lamc + osum;
    let up_term = if lf < 0.5 { (x.up_s[c] as f64) - x.up_mean } else { 0.0 };
    let b1 = csc / x.dt * (x.ts_old[c] as f64) + (x.sws[c] as f64) + onb - up_term;
    let a2 = x.ca / x.dt + lamc + x.b + dsum + asum;
    let b2 = x.ca / x.dt * (x.ta_old[c] as f64) + (x.swa[c] as f64) - x.a + x.b * 273.15 + dnb + anb;
    let lam2 = (x.lam[c] * x.lam[c]) as f64;
    let d_eff = a2 - lam2 / a1;
    let tan = (b2 + lamc * b1 / a1) / d_eff;
    let mut tsn = (b1 + lamc * tan) / a1;
    if lf < 0.5 && tsn < x.t_freeze - 1.5 {
        tsn = x.t_freeze - 1.5;
    }
    let e_loc = x.ca / x.dt + x.b + lamc * (csc / x.dt + osum) / a1;
    (tan, tsn, d_eff, e_loc)
}

pub struct Climate {
    pp: PlanetParams,
    dv: Derived,
    cg: Arc<CubeGrid>,
    fg: Arc<CubeGrid>,
    t: Arc<TerrainData>,
    n: usize,
    rm: f64,

    // static geometry
    sin_lat: Vec<f32>,
    cos_lat: Vec<f32>,
    fcor: Vec<f32>,
    east_v: Vec<f32>,
    north_v: Vec<f32>,
    edge_dir: Vec<f32>,
    edge_inv_l: Vec<f32>,
    lw_u: Vec<f32>,
    oro_vec: Vec<f32>, // per fine cell: surface gradient (3)
    z_eff: Vec<f32>,
    lf: Vec<f32>,
    glac: Vec<f32>,
    veg: Vec<f32>,
    soil_cap: Vec<f32>,
    alb_l: Vec<f32>,
    wsat_tab: Vec<f32>,
    es_tab: Vec<f32>,
    // prognostic state
    ta: Vec<f32>,
    ts: Vec<f32>,
    w: Vec<f32>,
    sm: Vec<f32>,
    snow: Vec<f32>,
    cloud: Vec<f32>,
    psi: Vec<f32>,
    fi: Vec<f32>,
    itcz: Vec<f32>,
    wind: Vec<f32>,
    cur: Vec<f32>,
    pres: Vec<f32>,
    divg: Vec<f32>,
    upw: Vec<f32>,
    taux: Vec<f32>,
    p: Vec<f32>,
    e: Vec<f32>,
    el: Vec<f32>,
    runoff_s: Vec<f32>,
    w_oro: Vec<f32>,
    stom_c: Vec<f32>,
    stom_s: Vec<f32>,
    acc: Vec<f32>, // annual accumulators for diagnostics
    warm: bool,
    evap_scale: f64,

    pub sl: ClimateSlices,
    pub st: ClimateStatic,
    pub ms_per_step: f64,
}

impl Climate {
    pub fn new(pp: &PlanetParams, dv: &Derived, cg: Arc<CubeGrid>, fg: Arc<CubeGrid>, t: Arc<TerrainData>) -> Climate {
        let n = cg.count;
        let rm = dv.r;
        let mut st = ClimateStatic::default();
        // saturation tables
        let nt = (((380.0 - 150.0) * 4.0) as usize) + 2;
        let mut es_tab = vec![0f32; nt];
        let mut wsat_tab = vec![0f32; nt];
        for i in 0..nt {
            let tk = 150.0 + (i as f64) * 0.25;
            let tc = tk - 273.15;
            let mut e = 100.0 * 6.112 * dexp(17.67 * tc / (tc + 243.5)); // Pa (Bolton)
            if tc < -60.0 {
                e = 100.0 * 6.112 * dexp(17.67 * -60.0 / (-60.0 + 243.5)) * dexp((tc + 60.0) * 0.12);
            }
            es_tab[i] = e as f32;
            let hw = clampv(RV * tk * tk / (LV * dv.lapse), 700.0, 7000.0);
            wsat_tab[i] = (e / (RV * tk) * hw) as f32; // kg/m^2 == mm
        }
        let mut sin_lat = vec![0f32; n];
        let mut cos_lat = vec![0f32; n];
        let mut fcor = vec![0f32; n];
        let mut east_v = vec![0f32; n * 3];
        let mut north_v = vec![0f32; n * 3];
        let mut edge_dir = vec![0f32; n * 12];
        let mut edge_inv_l = vec![0f32; n * 4];
        let mut lw_u = vec![0f32; n * 8];
        for c in 0..n {
            let p = cg.pos[c];
            sin_lat[c] = p.z as f32;
            cos_lat[c] = ((1.0 - p.z * p.z).max(0.0)).sqrt() as f32;
            fcor[c] = (dv.f_cor0 * p.z) as f32;
            let (e, nn) = east_north(p);
            east_v[c * 3] = e.x as f32;
            east_v[c * 3 + 1] = e.y as f32;
            east_v[c * 3 + 2] = e.z as f32;
            north_v[c * 3] = nn.x as f32;
            north_v[c * 3 + 1] = nn.y as f32;
            north_v[c * 3 + 2] = nn.z as f32;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                let dvv = cg.pos[qu] - p;
                if k < 4 {
                    let d = normalize(tangent_part(dvv, p));
                    edge_dir[(c * 4 + k) * 3] = d.x as f32;
                    edge_dir[(c * 4 + k) * 3 + 1] = d.y as f32;
                    edge_dir[(c * 4 + k) * 3 + 2] = d.z as f32;
                    edge_inv_l[c * 4 + k] = (1.0 / (length(dvv) * rm)) as f32;
                }
                let aavg = 0.5 * ((cg.area[c] as f64) + (cg.area[qu] as f64));
                let kk: f64 = if k < 4 { 2.0 / 3.0 } else { 1.0 / 6.0 };
                lw_u[c * 8 + k] = (kk / aavg) as f32;
            }
        }
        // fine -> coarse aggregates
        let mut z_eff = vec![0f32; n];
        let mut lf = vec![0f32; n];
        st.z_max = vec![0f32; n];
        st.relief = vec![0f32; n];
        {
            let mut sa = vec![0f64; n];
            let mut sl = vec![0f64; n];
            let mut sz = vec![0f64; n];
            let mut mn = vec![1e9f32; n];
            let ratio = fg.n / cg.n;
            for c in 0..fg.count {
                let (f, i, j) = fg.unpack(c);
                let cc = cg.idx(f, i / ratio, j / ratio);
                let a = fg.area[c] as f64;
                let h = t.height[c] as f64;
                sa[cc] += a;
                if h > 0.0 {
                    sl[cc] += a;
                    sz[cc] += a * h;
                    if (h as f32) > st.z_max[cc] {
                        st.z_max[cc] = h as f32;
                    }
                }
                let hm = (h.max(0.0)) as f32;
                if hm < mn[cc] {
                    mn[cc] = hm;
                }
            }
            for c in 0..n {
                lf[c] = (sl[c] / sa[c]) as f32;
                z_eff[c] = (sz[c] / sa[c]) as f32;
                st.relief[c] = st.z_max[c] - (if lf[c] > 0.0 { mn[c] } else { 0.0 });
            }
        }
        // fine-grid surface gradient (for orographic lift)
        let fgc = &*fg;
        let tt = &*t;
        let g3: Vec<[f32; 3]> = par_map(fgc.count, |c| {
            let p = fgc.pos[c];
            let (e, nn) = east_north(p);
            let hs = (tt.height[c] as f64).max(0.0);
            let mut sxx = 0.0f64;
            let mut sxy = 0.0f64;
            let mut syy = 0.0f64;
            let mut bx = 0.0f64;
            let mut by = 0.0f64;
            for k in 0..8usize {
                let q = fgc.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                let dvv = fgc.pos[qu] - p;
                let dx = dot(dvv, e);
                let dy = dot(dvv, nn);
                let w = 1.0 / (dx * dx + dy * dy);
                let dh = (tt.height[qu] as f64).max(0.0) - hs;
                sxx += w * dx * dx;
                sxy += w * dx * dy;
                syy += w * dy * dy;
                bx += w * dx * dh;
                by += w * dy * dh;
            }
            let det = sxx * syy - sxy * sxy;
            if det.abs() < 1e-30 {
                return [0.0f32, 0.0, 0.0];
            }
            let gx = (syy * bx - sxy * by) / det;
            let gy = (-sxy * bx + sxx * by) / det; // metres per radian
            let g = (e * gx + nn * gy) * (1.0 / rm);
            [g.x as f32, g.y as f32, g.z as f32]
        });
        let mut oro_vec = vec![0f32; fgc.count * 3];
        for c in 0..fgc.count {
            oro_vec[c * 3] = g3[c][0];
            oro_vec[c * 3 + 1] = g3[c][1];
            oro_vec[c * 3 + 2] = g3[c][2];
        }
        drop(g3);
        // state
        let mut ta = vec![0f32; n];
        let mut ts = vec![0f32; n];
        let mut w = vec![0f32; n];
        for c in 0..n {
            let s = cg.pos[c].z;
            let v = (301.0 - 50.0 * s * s) as f32;
            ta[c] = v;
            ts[c] = v;
            w[c] = (0.7 * lut(&wsat_tab, ta[c] as f64)) as f32;
        }
        // Stommel operator coefficients (static)
        let mut stom_c = vec![0f32; n * 8];
        let mut stom_s = vec![1f32; n];
        let rs = 4.0e-6 * (if dv.omega / 7.2921e-5 > 0.3 { 1.0 } else { 0.6 });
        for c in 0..n {
            let beta = 2.0 * dv.omega * (cos_lat[c] as f64) / rm;
            let e = V3::new(east_v[c * 3] as f64, east_v[c * 3 + 1] as f64, east_v[c * 3 + 2] as f64);
            let mut s = 0.0f64;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let g = V3::new(
                    cg.gw[c * 24 + k * 3] as f64,
                    cg.gw[c * 24 + k * 3 + 1] as f64,
                    cg.gw[c * 24 + k * 3 + 2] as f64,
                );
                let cc = beta * dot(e, g) / rm + rs * (lw_u[c * 8 + k] as f64) / (rm * rm);
                stom_c[c * 8 + k] = cc as f32;
                s += cc;
            }
            stom_s[c] = (if s > 1e-30 { s } else { 1e-30 }) as f32;
        }
        Climate {
            pp: pp.clone(),
            dv: dv.clone(),
            cg,
            fg,
            t,
            n,
            rm,
            sin_lat,
            cos_lat,
            fcor,
            east_v,
            north_v,
            edge_dir,
            edge_inv_l,
            lw_u,
            oro_vec,
            z_eff,
            lf,
            glac: vec![0f32; n],
            veg: vec![0.4f32; n],
            soil_cap: vec![150f32; n],
            alb_l: vec![0.22f32; n],
            wsat_tab,
            es_tab,
            ta,
            ts,
            w,
            sm: vec![0.4f32; n],
            snow: vec![0f32; n],
            cloud: vec![0.6f32; n],
            psi: vec![0f32; n],
            fi: vec![0f32; n],
            itcz: vec![0f32; 36],
            wind: vec![0f32; n * 3],
            cur: vec![0f32; n * 3],
            pres: vec![1013f32; n],
            divg: vec![0f32; n],
            upw: vec![0f32; n],
            taux: vec![0f32; n * 3],
            p: vec![0f32; n],
            e: vec![0f32; n],
            el: vec![0f32; n],
            runoff_s: vec![0f32; n],
            w_oro: vec![0f32; n],
            stom_c,
            stom_s,
            acc: vec![0f32; n * 4],
            warm: false,
            evap_scale: 1.25,
            sl: ClimateSlices::default(),
            st,
            ms_per_step: 0.0,
        }
    }

    pub fn ncell(&self) -> usize {
        self.n
    }
    pub fn oro_vec(&self) -> &Vec<f32> {
        &self.oro_vec
    }

    /// surface properties fed back from ecology / ice (coarse resolution)
    pub fn set_surface(&mut self, veg: &[f32], soil_cap_mm: &[f32], glacier_m: &[f32]) {
        let n = self.n;
        if veg.len() == n {
            self.veg = veg.to_vec();
            for c in 0..n {
                self.alb_l[c] = clampv(0.36 - 0.24 * (self.veg[c] as f64), 0.10, 0.40) as f32;
            }
        }
        if soil_cap_mm.len() == n {
            self.soil_cap = soil_cap_mm.to_vec();
        }
        if glacier_m.len() == n {
            self.glac = glacier_m.to_vec();
        }
    }

    /// reuse the atmosphere/ocean state of a previous climate (after a geological step) so spin-up is short
    pub fn warm_start_from(&mut self, o: &Climate) {
        if o.n != self.n {
            return;
        }
        self.ta = o.ta.clone();
        self.ts = o.ts.clone();
        self.w = o.w.clone();
        self.sm = o.sm.clone();
        self.snow = o.snow.clone();
        self.cloud = o.cloud.clone();
        self.psi = o.psi.clone();
        self.fi = o.fi.clone();
        self.itcz = o.itcz.clone();
        self.evap_scale = o.evap_scale;
        for c in 0..self.n {
            if self.lf[c] < 0.02 {
                self.snow[c] = 0.0;
            }
        }
        self.warm = true;
    }

    fn insolation(&self, m: usize, q: &mut Vec<f32>) {
        let yf = ((m as f64) + 0.5) / (NSLICE as f64);
        let (decl, rinv2) = solar_geometry(&self.dv, yf);
        let (sd, mut cd) = dsincos(decl);
        if cd.abs() < 1e-4 {
            cd = 1e-4;
        }
        let k = self.dv.s0 * rinv2 / PI;
        for c in 0..self.n {
            let sp = self.sin_lat[c] as f64;
            let cp = (1e-6f64).max(self.cos_lat[c] as f64);
            let ch = -(sp / cp) * (sd / cd);
            let h0: f64;
            let sh: f64;
            if ch >= 1.0 {
                h0 = 0.0;
                sh = 0.0;
            } else if ch <= -1.0 {
                h0 = PI;
                sh = 0.0;
            } else {
                h0 = dacos(ch);
                sh = (1.0 - ch * ch).sqrt();
            }
            q[c] = (k * (h0 * sp * sd + cp * cd * sh)) as f32;
        }
    }

    fn compute_winds(&mut self) {
        let cg = Arc::clone(&self.cg);
        let n = self.n;
        let rm = self.rm;
        // --- thermal equator (ITCZ): follows the maximum of moist static energy, not of temperature ---
        const NL: usize = 40;
        const NLON: usize = 36;
        let mut sum = vec![0f64; NLON * NL];
        let mut cnt = vec![0f64; NLON * NL];
        for c in 0..n {
            let lat = (cg.lat[c] as f64) * RAD2DEG;
            if lat.abs() >= 40.0 {
                continue;
            }
            let lb = clampv(((lat + 40.0) / 2.0) as i32, 0, (NL as i32) - 1) as usize;
            let ob = clampv((((cg.lon[c] as f64) * RAD2DEG + 180.0) / 10.0) as i32, 0, (NLON as i32) - 1) as usize;
            let h = (self.ta[c] as f64) + 0.86 * (self.w[c] as f64);
            let a = cg.area[c] as f64;
            sum[ob * NL + lb] += h * a;
            cnt[ob * NL + lb] += a;
        }
        let lim = clampv(6.0 + 0.9 * (self.dv.tilt * RAD2DEG), 6.0, 40.0);
        let mut new_itcz = vec![0f64; NLON];
        for o in 0..NLON {
            let mut s = [0f64; NL];
            for l in 0..NL {
                s[l] = if cnt[o * NL + l] > 0.0 { sum[o * NL + l] / cnt[o * NL + l] } else { 0.0 };
            }
            let mut sm = [0f64; NL];
            for l in 0..NL {
                let a = s[if l > 0 { l - 1 } else { 0 }];
                let b = s[l];
                let d = s[if l + 1 < NL { l + 1 } else { NL - 1 }];
                sm[l] = 0.25 * a + 0.5 * b + 0.25 * d;
            }
            let mut best = 0usize;
            for l in 1..NL {
                if sm[l] > sm[best] {
                    best = l;
                }
            }
            let mut off = 0.0f64;
            if best > 0 && best < NL - 1 {
                let a = sm[best - 1];
                let b = sm[best];
                let d = sm[best + 1];
                let den = a - 2.0 * b + d;
                if den.abs() > 1e-9 {
                    off = clampv(0.5 * (a - d) / den, -0.5, 0.5);
                }
            }
            new_itcz[o] = clampv(-40.0 + ((best as f64) + 0.5 + off) * 2.0, -lim, lim);
        }
        for _pass in 0..3 {
            let mut tmp = [0f64; NLON];
            for o in 0..NLON {
                tmp[o] = 0.25 * new_itcz[(o + NLON - 1) % NLON] + 0.5 * new_itcz[o] + 0.25 * new_itcz[(o + 1) % NLON];
            }
            for o in 0..NLON {
                new_itcz[o] = tmp[o];
            }
        }
        for o in 0..NLON {
            self.itcz[o] = (0.5 * (self.itcz[o] as f64) + 0.5 * new_itcz[o]) as f32;
        }

        // --- zonal-mean reference and hemispheric contrast ---
        const NB: usize = 90;
        let mut zs = vec![0f64; NB];
        let mut zc = vec![0f64; NB];
        let mut eq_s = [0f64; 2];
        let mut eq_c = [0f64; 2];
        let mut po_s = [0f64; 2];
        let mut po_c = [0f64; 2];
        for c in 0..n {
            let lat = (cg.lat[c] as f64) * RAD2DEG;
            let b = clampv(((lat + 90.0) / 2.0) as i32, 0, (NB as i32) - 1) as usize;
            let a = cg.area[c] as f64;
            let ta_a = (self.ta[c] * cg.area[c]) as f64;
            zs[b] += ta_a;
            zc[b] += a;
            let hs = if lat >= 0.0 { 0usize } else { 1usize };
            if lat.abs() < 15.0 {
                eq_s[hs] += ta_a;
                eq_c[hs] += a;
            }
            if lat.abs() > 60.0 {
                po_s[hs] += ta_a;
                po_c[hs] += a;
            }
        }
        let mut amp = [0f64; 2];
        for h in 0..2usize {
            let d_t = if eq_c[h] > 0.0 && po_c[h] > 0.0 { eq_s[h] / eq_c[h] - po_s[h] / po_c[h] } else { 38.0 };
            amp[h] = clampv(d_t / 38.0, 0.45, 1.8) * self.dv.press_scale;
        }
        // --- sea-level pressure: belts relative to the ITCZ + thermal lows/highs ---
        let th_h = self.dv.hadley_deg;
        let th_f = th_h + 0.5 * (90.0 - th_h);
        let p0 = self.dv.p0 / 100.0;
        let mut anom = vec![0f32; n];
        let mut sm1 = vec![0f32; n];
        for c in 0..n {
            let lat = (cg.lat[c] as f64) * RAD2DEG;
            let lon = (cg.lon[c] as f64) * RAD2DEG;
            let fo = (lon + 180.0) / 10.0 - 0.5;
            let o0 = fo.floor() as i32;
            let t = fo - (o0 as f64);
            let i0 = ((o0 + (NLON as i32) * 4) as usize) % NLON;
            let i1 = ((o0 + 1 + (NLON as i32) * 4) as usize) % NLON;
            let it = (1.0 - t) * (self.itcz[i0] as f64) + t * (self.itcz[i1] as f64);
            let d = lat - it;
            let th = d.abs();
            let hem = if d >= 0.0 { 0usize } else { 1usize };
            let belts = -2.6 * dexp(-sqr(th / 11.0)) + 8.0 * dexp(-sqr((th - th_h) / 11.0)) - 12.5 * dexp(-sqr((th - th_f) / 10.0));
            let pol = 5.0 * dexp(-sqr((90.0 - lat.abs()) / 22.0));
            let hl = if lat >= 0.0 { 0usize } else { 1usize };
            let b = clampv(((lat + 90.0) / 2.0) as i32, 0, (NB as i32) - 1) as usize;
            let tref = if zc[b] > 0.0 { zs[b] / zc[b] } else { self.ta[c] as f64 };
            anom[c] = (-0.55 * ((self.ta[c] as f64) - tref)) as f32;
            self.pres[c] = (p0 + belts * amp[hem] + pol * amp[hl]) as f32;
        }
        for _pass in 0..2 {
            for c in 0..n {
                let mut s = 0.0f64;
                let mut k = 0i32;
                for j in 0..8usize {
                    let q = cg.nbr[c * 8 + j];
                    if q >= 0 {
                        s += anom[q as usize] as f64;
                        k += 1;
                    }
                }
                let kk = if k > 1 { k } else { 1 };
                sm1[c] = (0.5 * (anom[c] as f64) + 0.5 * s / (kk as f64)) as f32;
            }
            std::mem::swap(&mut anom, &mut sm1);
        }
        for c in 0..n {
            self.pres[c] += anom[c];
        }
        // --- winds: pressure gradient + Coriolis + surface friction ---
        for c in 0..n {
            let mut gx = 0.0f64;
            let mut gy = 0.0f64;
            let mut gz = 0.0f64;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let dp = (self.pres[q as usize] - self.pres[c]) as f64;
                gx += (cg.gw[c * 24 + k * 3] as f64) * dp;
                gy += (cg.gw[c * 24 + k * 3 + 1] as f64) * dp;
                gz += (cg.gw[c * 24 + k * 3 + 2] as f64) * dp;
            }
            let rho = (self.pres[c] as f64) * 100.0 / (self.dv.rspec * (self.ta[c] as f64));
            let s = -100.0 / (rm * rho);
            let gv = V3::new(gx * s, gy * s, gz * s);
            let lf = self.lf[c] as f64;
            let r = lf * 2.6e-5 + (1.0 - lf) * 1.3e-5;
            let mut f = self.fcor[c] as f64;
            let ff = if f.abs() < 5.0e-5 { 5.0e-5 * (if cg.lat[c] >= 0.0 { 1.0 } else { -1.0 }) } else { f };
            f = ff;
            let kxg = cross(cg.pos[c], gv);
            let den = r * r + f * f;
            let u = (gv * r - kxg * f) * (1.0 / den);
            let z = (self.z_eff[c] as f64) + 0.8 * (self.glac[c] as f64);
            let damp = 1.0 - 0.35 * smoothstep(1500.0, 4500.0, z);
            self.wind[c * 3] = (u.x * damp) as f32;
            self.wind[c * 3 + 1] = (u.y * damp) as f32;
            self.wind[c * 3 + 2] = (u.z * damp) as f32;
        }
        {
            let mut w2 = self.wind.clone();
            for c in 0..n {
                let mut sx = 0.0f64;
                let mut sy = 0.0f64;
                let mut sz = 0.0f64;
                let mut k = 0i32;
                for j in 0..8usize {
                    let q = cg.nbr[c * 8 + j];
                    if q < 0 {
                        continue;
                    }
                    let qu = q as usize;
                    sx += self.wind[qu * 3] as f64;
                    sy += self.wind[qu * 3 + 1] as f64;
                    sz += self.wind[qu * 3 + 2] as f64;
                    k += 1;
                }
                if k == 0 {
                    continue;
                }
                let kf = k as f64;
                let v = V3::new(
                    0.5 * (self.wind[c * 3] as f64) + 0.5 * sx / kf,
                    0.5 * (self.wind[c * 3 + 1] as f64) + 0.5 * sy / kf,
                    0.5 * (self.wind[c * 3 + 2] as f64) + 0.5 * sz / kf,
                );
                let v = tangent_part(v, cg.pos[c]);
                w2[c * 3] = v.x as f32;
                w2[c * 3 + 1] = v.y as f32;
                w2[c * 3 + 2] = v.z as f32;
            }
            self.wind = w2;
        }
        for c in 0..n {
            let mut d = 0.0f64;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                for a in 0..3usize {
                    d += (cg.gw[c * 24 + k * 3 + a] * (self.wind[qu * 3 + a] - self.wind[c * 3 + a])) as f64;
                }
            }
            self.divg[c] = (d / rm) as f32;
        }
    }

    fn compute_ocean(&mut self, sweeps: i32) {
        let cg = Arc::clone(&self.cg);
        let n = self.n;
        let rm = self.rm;
        // wind stress
        for c in 0..n {
            let u0 = self.wind[c * 3] as f64;
            let u1 = self.wind[c * 3 + 1] as f64;
            let u2 = self.wind[c * 3 + 2] as f64;
            let sp = (u0 * u0 + u1 * u1 + u2 * u2).sqrt();
            let k = 1.2 * 1.3e-3 * sp;
            self.taux[c * 3] = (k * u0) as f32;
            self.taux[c * 3 + 1] = (k * u1) as f32;
            self.taux[c * 3 + 2] = (k * u2) as f32;
        }
        let mut rhs = vec![0f32; n];
        for c in 0..n {
            if self.lf[c] >= 0.5 {
                continue;
            }
            let mut curl = V3::new(0.0, 0.0, 0.0);
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                let g = V3::new(
                    cg.gw[c * 24 + k * 3] as f64,
                    cg.gw[c * 24 + k * 3 + 1] as f64,
                    cg.gw[c * 24 + k * 3 + 2] as f64,
                );
                let dt = V3::new(
                    (self.taux[qu * 3] - self.taux[c * 3]) as f64,
                    (self.taux[qu * 3 + 1] - self.taux[c * 3 + 1]) as f64,
                    (self.taux[qu * 3 + 2] - self.taux[c * 3 + 2]) as f64,
                );
                curl += cross(g, dt);
            }
            rhs[c] = (dot(curl, cg.pos[c]) / rm / RHO_W) as f32;
        }
        let omg = 1.75f64;
        for sw in 0..sweeps {
            for ci in 0..n {
                let c = if (sw & 1) == 1 { n - 1 - ci } else { ci };
                if self.lf[c] >= 0.5 {
                    self.psi[c] = 0.0;
                    continue;
                }
                let mut s = 0.0f64;
                for k in 0..8usize {
                    let q = cg.nbr[c * 8 + k];
                    if q >= 0 {
                        s += (self.stom_c[c * 8 + k] * self.psi[q as usize]) as f64;
                    }
                }
                let pn = (s - (rhs[c] as f64)) / (self.stom_s[c] as f64);
                let pc = self.psi[c] as f64;
                self.psi[c] = (pc + omg * (pn - pc)) as f32;
            }
        }
        // geostrophic-like surface currents from the transport stream function
        let he = 400.0f64;
        for c in 0..n {
            self.cur[c * 3] = 0.0;
            self.cur[c * 3 + 1] = 0.0;
            self.cur[c * 3 + 2] = 0.0;
            if self.lf[c] >= 0.5 {
                continue;
            }
            let mut g = V3::new(0.0, 0.0, 0.0);
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let dpsi = (self.psi[q as usize] - self.psi[c]) as f64;
                g += V3::new(
                    cg.gw[c * 24 + k * 3] as f64,
                    cg.gw[c * 24 + k * 3 + 1] as f64,
                    cg.gw[c * 24 + k * 3 + 2] as f64,
                ) * dpsi;
            }
            let u = cross(cg.pos[c], g) * (14.0 / (rm * he));
            self.cur[c * 3] = u.x as f32;
            self.cur[c * 3 + 1] = u.y as f32;
            self.cur[c * 3 + 2] = u.z as f32;
        }
        // Ekman transport divergence -> upwelling (coastal and equatorial)
        let mut me = vec![0f32; n * 3];
        for c in 0..n {
            if self.lf[c] >= 0.5 {
                continue;
            }
            let f = self.fcor[c] as f64;
            let fe = if f.abs() > 3e-5 { f } else { 3e-5 * sgn(cg.lat[c] as f64) };
            let tau = V3::new(self.taux[c * 3] as f64, self.taux[c * 3 + 1] as f64, self.taux[c * 3 + 2] as f64);
            let mut mm = cross(tau, cg.pos[c]) * (1.0 / (RHO_W * fe));
            let l = length(mm);
            if l > 15.0 {
                mm = mm * (15.0 / l);
            }
            me[c * 3] = mm.x as f32;
            me[c * 3 + 1] = mm.y as f32;
            me[c * 3 + 2] = mm.z as f32;
        }
        for c in 0..n {
            self.upw[c] = 0.0;
            if self.lf[c] >= 0.5 {
                continue;
            }
            let mut d = 0.0f64;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                for a in 0..3usize {
                    d += (cg.gw[c * 24 + k * 3 + a] * (me[qu * 3 + a] - me[c * 3 + a])) as f64;
                }
            }
            self.upw[c] = clampv(0.1 * d / rm, 0.0, 1.0e-6) as f32;
        }
    }

    fn solve_moisture(&mut self, sweeps: i32) {
        let cg = Arc::clone(&self.cg);
        let fg = Arc::clone(&self.fg);
        let n = self.n;
        let rm = self.rm;
        let rm2 = rm * rm;
        let kh = 1.2e6f64;
        let tau_s = 14400.0f64;
        let eps = 0.6f64;
        let hbl = 1200.0f64;
        let gam = self.dv.lapse;
        let mut e0o = vec![0f32; n];
        let mut e0l = vec![0f32; n];
        let mut wsa = vec![0f32; n];
        let mut wss = vec![0f32; n];
        let mut kl = vec![0f32; n];
        let mut wc = vec![0f32; n];
        let mut lam = vec![0f32; n * 4];
        let mut lam_out = vec![0f32; n];
        // orographic lift from sub-grid slopes (fine children) and wind
        let ratio = fg.n / cg.n;
        for c in 0..n {
            let (f, ci, cj) = cg.unpack(c);
            let w0 = (self.wind[c * 3] as f64) * 1.3;
            let w1 = (self.wind[c * 3 + 1] as f64) * 1.3;
            let w2 = (self.wind[c * 3 + 2] as f64) * 1.3;
            let mut s = 0.0f64;
            for b in 0..ratio {
                for a in 0..ratio {
                    let fc = fg.idx(f, ci * ratio + a, cj * ratio + b);
                    let up = w0 * (self.oro_vec[fc * 3] as f64) + w1 * (self.oro_vec[fc * 3 + 1] as f64) + w2 * (self.oro_vec[fc * 3 + 2] as f64);
                    if up > 0.0 {
                        s += up;
                    }
                }
            }
            self.w_oro[c] = (s / ((ratio * ratio) as f64)) as f32;
        }
        for c in 0..n {
            let lf = self.lf[c] as f64;
            let z = (self.z_eff[c] as f64) + 0.8 * (self.glac[c] as f64);
            let tact = (self.ta[c] as f64) - gam * z;
            let wx = self.wind[c * 3] as f64;
            let wy = self.wind[c * 3 + 1] as f64;
            let wz = self.wind[c * 3 + 2] as f64;
            let sp = (wx * wx + wy * wy + wz * wz).sqrt();
            let ts = self.ts[c] as f64;
            let wa = lut(&self.wsat_tab, tact);
            wsa[c] = wa as f32;
            wss[c] = (lf * wa + (1.0 - lf) * lut(&self.wsat_tab, ts)) as f32;
            wc[c] = (0.92 * wa) as f32;
            // evaporation (kg/m^2/s)
            let eo = self.evap_scale * 1.1e-3 * (sp + 1.5) * 0.622 * lut(&self.es_tab, ts) / (self.dv.rspec * ts) * (1.0 - 0.85 * (self.fi[c] as f64));
            let beta = (0.10 + 0.90 * clampv((self.sm[c] as f64) / 0.6, 0.0, 1.0)) * (0.55 + 0.45 * (self.veg[c] as f64));
            let snowc = clampv((self.snow[c] as f64) / 40.0, 0.0, 1.0);
            let mut el = self.evap_scale * 1.1e-3 * (sp + 1.5) * 0.622 * lut(&self.es_tab, tact) / (self.dv.rspec * tact) * beta * (1.0 - 0.9 * snowc);
            // el[] temporarily holds the energy cap (kg/m^2/s)
            el = el.min((0.0f64).max(self.el[c] as f64));
            e0o[c] = eo as f32;
            e0l[c] = el as f32;
            let hw = clampv(RV * tact * tact / (LV * gam), 700.0, 7000.0);
            let wconv = (0.012f64).min((0.0f64).max(-(self.divg[c] as f64) * hbl));
            let latd = (cg.lat[c] as f64).abs() * RAD2DEG;
            let mut gx = 0.0f64;
            let mut gy = 0.0f64;
            let mut gz = 0.0f64;
            for k in 0..8usize {
                let q = cg.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let dt = (self.ta[q as usize] - self.ta[c]) as f64;
                gx += (cg.gw[c * 24 + k * 3] as f64) * dt;
                gy += (cg.gw[c * 24 + k * 3 + 1] as f64) * dt;
                gz += (cg.gw[c * 24 + k * 3 + 2] as f64) * dt;
            }
            let g_t = (gx * gx + gy * gy + gz * gz).sqrt() / rm;
            let wsyn = 0.014 * clampv(g_t / 5.0e-6, 0.0, 1.6) * smoothstep(18.0, 38.0, latd);
            kl[c] = ((0.26 * (self.w_oro[c] as f64) + 0.10 * wconv + 0.16 * wsyn * (1.0 + 0.0 * eps)) / hw) as f32;
            let mut lo = 0.0f64;
            for k in 0..4usize {
                let q = cg.nbr[c * 8 + k];
                let mut qd = 0.0f64;
                if q >= 0 {
                    let qu = q as usize;
                    let eo2 = (c * 4 + k) * 3;
                    let d0 = self.edge_dir[eo2];
                    let d1 = self.edge_dir[eo2 + 1];
                    let d2 = self.edge_dir[eo2 + 2];
                    let sacc = (self.wind[c * 3] + self.wind[qu * 3]) * d0
                        + (self.wind[c * 3 + 1] + self.wind[qu * 3 + 1]) * d1
                        + (self.wind[c * 3 + 2] + self.wind[qu * 3 + 2]) * d2;
                    qd = 0.5 * (sacc as f64);
                }
                let il = self.edge_inv_l[c * 4 + k] as f64;
                lam[c * 4 + k] = if qd < 0.0 { (-qd * il) as f32 } else { 0.0 };
                if qd > 0.0 {
                    lo += qd * il;
                }
            }
            let mut li = 0.0f64;
            for k in 0..4usize {
                li += lam[c * 4 + k] as f64;
            }
            lam_out[c] = (li + 1.0 * (lo - li)) as f32;
        }
        for sw in 0..sweeps {
            for ci in 0..n {
                let c = if (sw & 1) == 1 { n - 1 - ci } else { ci };
                let lf = self.lf[c] as f64;
                let lv = lam_out[c] as f64;
                let mut wup = 0.0f64;
                for k in 0..4usize {
                    let l = lam[c * 4 + k] as f64;
                    if l > 0.0 {
                        let q = cg.nbr[c * 8 + k];
                        if q >= 0 {
                            wup += l * (self.w[q as usize] as f64);
                        }
                    }
                }
                let mut mu = 0.0f64;
                let mut wm = 0.0f64;
                for k in 0..8usize {
                    let q = cg.nbr[c * 8 + k];
                    if q < 0 {
                        continue;
                    }
                    let m = kh * (self.lw_u[c * 8 + k] as f64) / rm2;
                    mu += m;
                    wm += m * (self.w[q as usize] as f64);
                }
                let e0 = lf * (e0l[c] as f64) + (1.0 - lf) * (e0o[c] as f64);
                let a = lv + mu + e0 / (1.0f64).max(wss[c] as f64) + (kl[c] as f64);
                let b = wup + wm + e0;
                let w1 = b / a;
                let wcc = wc[c] as f64;
                let w = if w1 > wcc { (b + wcc / tau_s) / (a + 1.0 / tau_s) } else { w1 };
                self.w[c] = clampv(w, 0.0, 1.2 * (wsa[c] as f64)) as f32;
            }
        }
        for c in 0..n {
            let lf = self.lf[c] as f64;
            let w = self.w[c] as f64;
            let pr = (kl[c] as f64) * w + (0.0f64).max(w - (wc[c] as f64)) / tau_s;
            let dry = (0.0f64).max(1.0 - w / (1.0f64).max(wss[c] as f64));
            let eo = (e0o[c] as f64) * dry;
            let el = (e0l[c] as f64) * dry;
            self.p[c] = (pr * 86400.0) as f32;
            self.el[c] = (el * 86400.0) as f32;
            self.e[c] = ((lf * el + (1.0 - lf) * eo) * 86400.0) as f32;
        }
    }

    /// Close the global water budget: every kilogram that evaporates must fall again. The residual goes to
    /// ocean rain, so land hydrology (rivers, soils, biomes) is untouched.
    fn close_water_budget(&mut self) {
        let cg = Arc::clone(&self.cg);
        let n = self.n;
        let mut s_p = 0.0f64;
        let mut s_e = 0.0f64;
        let mut s_po = 0.0f64;
        for c in 0..n {
            let a = cg.area[c] as f64;
            s_p += (self.p[c] as f64) * a;
            s_e += (self.e[c] as f64) * a;
            if self.lf[c] < 0.02 {
                s_po += (self.p[c] as f64) * a;
            }
        }
        if s_po > 1e-9 && s_e > 0.0 {
            let f = clampv(1.0 + (s_e - s_p) / s_po, 0.6, 1.8);
            for c in 0..n {
                if self.lf[c] < 0.02 {
                    self.p[c] = ((self.p[c] as f64) * f) as f32;
                }
            }
        }
    }

    fn land_surface(&mut self, dt: f64) {
        let n = self.n;
        let days = dt / 86400.0;
        let ddf = 3.5f64;
        let gam = self.dv.lapse;
        for c in 0..n {
            let lf = self.lf[c] as f64;
            let z = (self.z_eff[c] as f64) + 0.8 * (self.glac[c] as f64);
            let tc = (self.ta[c] as f64) - gam * z - 273.15;
            let pm = (self.p[c] as f64) * days;
            let fs = clampv((2.0 - tc) / 3.0, 0.0, 1.0);
            let ps = pm * fs;
            let pl = pm - ps;
            let pot_melt = ddf * (0.0f64).max(tc) * days;
            self.acc[c * 4] += ps as f32;
            self.acc[c * 4 + 1] += pot_melt as f32;
            self.acc[c * 4 + 2] += pm as f32;
            self.acc[c * 4 + 3] += ((self.e[c] as f64) * days) as f32;
            if lf < 0.02 {
                self.snow[c] = 0.0;
                self.runoff_s[c] = 0.0;
                continue;
            }
            let mut sn = self.snow[c] as f64;
            let melt = (sn + ps).min(pot_melt);
            sn = (0.0f64).max(sn + ps - melt);
            self.snow[c] = sn.min(6000.0) as f32;
            let cap = self.soil_cap[c] as f64;
            let mut sm = (self.sm[c] as f64) * cap;
            let inn = pl + melt;
            let ea = ((self.el[c] as f64) * days).min(sm + inn);
            sm += inn - ea;
            let mut rs = (0.0f64).max(sm - cap);
            sm -= rs;
            let mut r2 = 0.22 * inn * sqr(sm / cap);
            sm = (0.0f64).max(sm - r2);
            if tc < -3.0 {
                rs = 0.0;
                r2 = 0.0;
            }
            self.sm[c] = (sm / cap) as f32;
            self.runoff_s[c] = ((rs + r2) / days) as f32;
        }
    }

    fn step_slice(&mut self, m: usize, sweeps_t: i32, sweeps_w: i32, sweeps_p: i32, store: bool) {
        let cg = Arc::clone(&self.cg);
        let n = self.n;
        let dt = self.dv.year_days * 86400.0 / (NSLICE as f64);
        let gam = self.dv.lapse;
        let mut q = vec![0f32; n];
        let mut cs = vec![0f32; n];
        let mut lam = vec![0f32; n];
        let mut sws = vec![0f32; n];
        let mut swa = vec![0f32; n];
        let ta_old = self.ta.clone();
        let ts_old = self.ts.clone();
        self.insolation(m, &mut q);
        let mut a_glob = 0.0f64;
        let mut w_glob = 0.0f64;
        for c in 0..n {
            let lf = self.lf[c] as f64;
            let lat = (cg.lat[c] as f64).abs() * RAD2DEG;
            let fi = self.fi[c] as f64;
            let mut a_oc = 0.06 + 0.12 * smoothstep(40.0, 80.0, lat);
            a_oc = (1.0 - fi) * a_oc + fi * 0.62;
            let mut al = self.alb_l[c] as f64;
            let fs = clampv((self.snow[c] as f64) / 40.0, 0.0, 1.0);
            let a_sn = 0.72 - 0.30 * sqr(self.veg[c] as f64);
            al = (1.0 - fs) * al + fs * a_sn;
            if self.glac[c] > 20.0 {
                al = 0.70;
            }
            let as_ = lf * al + (1.0 - lf) * a_oc;
            let cl = self.cloud[c] as f64;
            let ap = clampv(0.04 + (1.0 - cl) * 0.9 * as_ + cl * 0.30, 0.05, 0.92);
            let qc = q[c] as f64;
            let sw = qc * (1.0 - ap);
            sws[c] = (0.78 * sw) as f32;
            swa[c] = (0.22 * sw) as f32;
            let cl_cap = 8.0e6 * (1.0 + 0.6 * clampv((self.snow[c] as f64) / 200.0, 0.0, 1.0));
            let mut co = self.dv.cocean;
            let tso = ts_old[c] as f64;
            if lf < 0.5 && tso > self.dv.t_freeze_k - 1.0 && tso < self.dv.t_freeze_k + 0.8 {
                co += 1.3e8;
            }
            cs[c] = (lf * cl_cap + (1.0 - lf) * co) as f32;
            lam[c] = (lf * 35.0 + (1.0 - lf) * 60.0 * (1.0 - 0.8 * fi)) as f32;
            let a = cg.area[c] as f64;
            a_glob += ap * qc * a;
            w_glob += qc * a;
        }
        self.st.albedo_p = if w_glob > 0.0 { a_glob / w_glob } else { 0.3 };
        let ca = self.dv.ca;
        let cadv = self.dv.ca * 0.10;
        let b_olr = self.dv.olr_b;
        let a_olr = self.dv.olr_a;
        let dd = self.dv.diff_d * 0.62;
        let kap = 2.0f64;
        // upwelling brings cold deep water up; the same heat is returned uniformly so the global budget closes
        let mut up_s = vec![0f32; n];
        let mut up_mean = 0.0f64;
        let mut up_area = 0.0f64;
        for c in 0..n {
            if self.lf[c] >= 0.5 {
                continue;
            }
            let d_t_up = clampv(((ts_old[c] as f64) - 275.15) * 0.30, 0.0, 6.0);
            up_s[c] = (RHO_W * CW * (self.upw[c] as f64) * d_t_up) as f32;
            up_mean += (up_s[c] * cg.area[c]) as f64;
            up_area += cg.area[c] as f64;
        }
        up_mean = if up_area > 0.0 { up_mean / up_area } else { 0.0 };

        const NB: usize = 48;
        let mut band = vec![0usize; n];
        let mut band_area = vec![0f64; NB];
        for c in 0..n {
            band[c] = clampv((((self.sin_lat[c] as f64) + 1.0) * 0.5 * (NB as f64)) as i32, 0, (NB as i32) - 1) as usize;
            band_area[band[c]] += cg.area[c] as f64;
        }
        let dx = 2.0 / (NB as f64);
        let cycles = if sweeps_t >= 30 { 8 } else { 2 };
        let mut parity = 0i32;
        {
            let ctx = LocalCtx {
                cg: &*cg,
                lf: &self.lf,
                lw_u: &self.lw_u,
                edge_dir: &self.edge_dir,
                edge_inv_l: &self.edge_inv_l,
                wind: &self.wind,
                cur: &self.cur,
                cs: &cs,
                lam: &lam,
                sws: &sws,
                swa: &swa,
                ta_old: &ta_old,
                ts_old: &ts_old,
                up_s: &up_s,
                up_mean,
                dt,
                ca,
                cadv,
                b: b_olr,
                a: a_olr,
                dd,
                kap,
                cocean: self.dv.cocean,
                t_freeze: self.dv.t_freeze_k,
            };
            for _cyc in 0..cycles {
                for _s in 0..2 {
                    for ci in 0..n {
                        let c = if (parity & 1) == 1 { n - 1 - ci } else { ci };
                        let (tan, tsn, _d, _e) = local_update(&ctx, c, &self.ta, &self.ts);
                        self.ta[c] = tan as f32;
                        self.ts[c] = tsn as f32;
                    }
                    parity += 1;
                }
                let mut rb = vec![0f64; NB];
                let mut eb = vec![0f64; NB];
                for c in 0..n {
                    let (tan, _tsn, d, e) = local_update(&ctx, c, &self.ta, &self.ts);
                    let a = cg.area[c] as f64;
                    rb[band[c]] += a * d * (tan - (self.ta[c] as f64));
                    eb[band[c]] += a * e;
                }
                let mut lo = vec![0f64; NB];
                let mut di = vec![0f64; NB];
                let mut up = vec![0f64; NB];
                let mut rr = vec![0f64; NB];
                let mut cpv = vec![0f64; NB];
                let mut dpv = vec![0f64; NB];
                for b in 0..NB {
                    let xm = -1.0 + (b as f64) * dx;
                    let xp = xm + dx;
                    let cm = (1.0 - xm * xm) * dd / (dx * dx);
                    let cpl = (1.0 - xp * xp) * dd / (dx * dx);
                    let ba = (1e-12f64).max(band_area[b]);
                    di[b] = eb[b] / ba + cm + cpl;
                    lo[b] = -cm;
                    up[b] = -cpl;
                    rr[b] = rb[b] / ba;
                }
                cpv[0] = up[0] / di[0];
                dpv[0] = rr[0] / di[0];
                for b in 1..NB {
                    let den = di[b] - lo[b] * cpv[b - 1];
                    cpv[b] = up[b] / den;
                    dpv[b] = (rr[b] - lo[b] * dpv[b - 1]) / den;
                }
                let mut eb2 = vec![0f64; NB];
                eb2[NB - 1] = dpv[NB - 1];
                let mut b = NB - 1;
                while b > 0 {
                    b -= 1;
                    eb2[b] = dpv[b] - cpv[b] * eb2[b + 1];
                }
                for c in 0..n {
                    self.ta[c] += eb2[band[c]] as f32;
                }
                for _s in 0..2 {
                    for ci in 0..n {
                        let c = if (parity & 1) == 1 { n - 1 - ci } else { ci };
                        let (tan, tsn, _d, _e) = local_update(&ctx, c, &self.ta, &self.ts);
                        self.ta[c] = tan as f32;
                        self.ts[c] = tsn as f32;
                    }
                    parity += 1;
                }
            }
        }
        // sea ice from surface temperature
        for c in 0..n {
            let f = clampv((self.dv.t_freeze_k + 0.8 - (self.ts[c] as f64)) / 1.8, 0.0, 1.0);
            let ocean_flag = if self.lf[c] < 0.5 { 1.0 } else { 0.0 };
            self.fi[c] = (f * (1.0 - (self.lf[c] as f64)) * ocean_flag) as f32;
        }
        self.compute_winds();
        self.compute_ocean(sweeps_p);
        // energy cap for land evaporation (absorbed surface shortwave / latent heat)
        for c in 0..n {
            self.el[c] = ((0.0f64).max(sws[c] as f64) / LV) as f32;
        }
        self.solve_moisture(sweeps_w);
        self.close_water_budget();
        self.land_surface(dt);
        // clouds
        for c in 0..n {
            let z = (self.z_eff[c] as f64) + 0.8 * (self.glac[c] as f64);
            let wa = lut(&self.wsat_tab, (self.ta[c] as f64) - gam * z);
            let rh = clampv((self.w[c] as f64) / (1.0f64).max(wa), 0.0, 1.2);
            let pm = self.p[c] as f64;
            let lf = self.lf[c] as f64;
            let sc = (1.0 - lf)
                * clampv(((self.ta[c] - self.ts[c]) as f64) / 3.0, 0.0, 1.0)
                * clampv((self.divg[c] as f64) / 4e-6, 0.0, 1.0)
                * 0.30;
            self.cloud[c] = clampv(
                0.12 + 0.48 * smoothstep(0.30, 0.85, rh) + 0.25 * (1.0 - dexp(-pm / 2.0)) + 0.12 * (1.0 - lf) + sc,
                0.0,
                0.95,
            ) as f32;
        }
        if store {
            let o = m * n;
            for c in 0..n {
                let z = (self.z_eff[c] as f64) + 0.8 * (self.glac[c] as f64);
                let lf = self.lf[c] as f64;
                self.sl.ta[o + c] = ((self.ta[c] as f64) - gam * z) as f32;
                self.sl.ts[o + c] = (if lf > 0.5 { (self.ts[c] as f64) - gam * z } else { self.ts[c] as f64 }) as f32;
                self.sl.precip[o + c] = self.p[c];
                self.sl.wvap[o + c] = self.w[c];
                self.sl.cloud[o + c] = self.cloud[c];
                self.sl.snow[o + c] = self.snow[c];
                self.sl.ice[o + c] = self.fi[c];
                let u0 = self.wind[c * 3] as f64;
                let u1 = self.wind[c * 3 + 1] as f64;
                let u2 = self.wind[c * 3 + 2] as f64;
                self.sl.wu[o + c] = (u0 * (self.east_v[c * 3] as f64) + u1 * (self.east_v[c * 3 + 1] as f64) + u2 * (self.east_v[c * 3 + 2] as f64)) as f32;
                self.sl.wv[o + c] = (u0 * (self.north_v[c * 3] as f64) + u1 * (self.north_v[c * 3 + 1] as f64) + u2 * (self.north_v[c * 3 + 2] as f64)) as f32;
                self.sl.pres[o + c] = self.pres[c];
                self.sl.runoff[o + c] = self.runoff_s[c];
            }
        }
    }

    /// run `years` seasonal cycles; the last cycle is stored in `sl`
    pub fn run(&mut self, years: i32, progress: Progress) {
        let tm = Timer::new();
        let tot = NSLICE * self.n;
        self.sl.ta = vec![0f32; tot];
        self.sl.ts = vec![0f32; tot];
        self.sl.precip = vec![0f32; tot];
        self.sl.wvap = vec![0f32; tot];
        self.sl.cloud = vec![0f32; tot];
        self.sl.snow = vec![0f32; tot];
        self.sl.ice = vec![0f32; tot];
        self.sl.wu = vec![0f32; tot];
        self.sl.wv = vec![0f32; tot];
        self.sl.pres = vec![0f32; tot];
        self.sl.runoff = vec![0f32; tot];
        let mut steps = 0i32;
        for y in 0..years {
            for v in self.acc.iter_mut() {
                *v = 0.0;
            }
            for m in 0..NSLICE {
                let first = !self.warm && y == 0;
                let sw_t = if first { 40 } else { 10 };
                let sw_w = if first { 40 } else { 14 };
                let sw_p = if first { 40 } else { 12 };
                self.step_slice(m, sw_t, sw_w, sw_p, y == years - 1);
                steps += 1;
            }
            progress("Climate", ((y + 1) as f32) / (years as f32));
        }
        self.warm = true;
        self.ms_per_step = tm.ms() / (if steps > 1 { steps as f64 } else { 1.0 });
        self.finalize();
    }

    fn finalize(&mut self) {
        let cg = Arc::clone(&self.cg);
        let n = self.n;
        self.st.land_frac = self.lf.clone();
        self.st.z_mean = self.z_eff.clone();
        self.st.ocean = vec![0f32; n];
        for c in 0..n {
            self.st.ocean[c] = 1.0 - self.lf[c];
        }
        self.st.veg = self.veg.clone();
        self.st.albedo_land = self.alb_l.clone();
        self.st.soil_cap = self.soil_cap.clone();
        self.st.psi = self.psi.clone();
        self.st.cu = vec![0f32; n];
        self.st.cv = vec![0f32; n];
        for c in 0..n {
            self.st.cu[c] = self.cur[c * 3] * self.east_v[c * 3] + self.cur[c * 3 + 1] * self.east_v[c * 3 + 1] + self.cur[c * 3 + 2] * self.east_v[c * 3 + 2];
            self.st.cv[c] = self.cur[c * 3] * self.north_v[c * 3] + self.cur[c * 3 + 1] * self.north_v[c * 3 + 1] + self.cur[c * 3 + 2] * self.north_v[c * 3 + 2];
        }
        self.st.upwell = self.upw.clone();
        self.st.itcz_lat = self.itcz.clone();
        self.st.hadley_deg = self.dv.hadley_deg;
        // global diagnostics (last cycle)
        let mut a_t = 0.0f64;
        let mut a_p = 0.0f64;
        let mut a_e = 0.0f64;
        let mut aw = 0.0f64;
        let mut imb = 0.0f64;
        for c in 0..n {
            let a = cg.area[c] as f64;
            let mut t = 0.0f64;
            for m in 0..NSLICE {
                t += self.sl.ta[m * n + c] as f64;
            }
            a_t += a * t / (NSLICE as f64);
            a_p += a * (self.acc[c * 4 + 2] as f64) / 365.25;
            a_e += a * (self.acc[c * 4 + 3] as f64) / 365.25;
            aw += a;
            imb += a * ((self.acc[c * 4 + 2] as f64) - (self.acc[c * 4 + 3] as f64));
        }
        self.st.global_mean_t = a_t / aw;
        self.st.global_mean_p = a_p / aw;
        self.st.global_mean_e = a_e / aw;
        self.st.water_imbalance = imb / aw / (1.0f64).max(a_p / aw * 365.25);
        // perennial snow -> glacier thickness from the annual balance
        let mut h = vec![0f32; n];
        for c in 0..n {
            if self.lf[c] < 0.5 {
                continue;
            }
            let bal = (self.acc[c * 4] as f64) - (self.acc[c * 4 + 1] as f64);
            let mut mn = 1e9f64;
            for m in 0..NSLICE {
                mn = mn.min(self.sl.snow[m * n + c] as f64);
            }
            if bal > 10.0 && mn > 30.0 {
                h[c] = (3300.0 * (1.0 - dexp(-bal / 60.0))) as f32;
            }
        }
        for _pass in 0..2 {
            let mut h2 = h.clone();
            for c in 0..n {
                if self.lf[c] < 0.5 || h[c] <= 0.0 {
                    h2[c] = 0.0;
                    continue;
                }
                let mut sum = 0.0f64;
                let mut k = 0i32;
                for j in 0..4usize {
                    let q = cg.nbr[c * 8 + j];
                    if q >= 0 {
                        let qu = q as usize;
                        if self.lf[qu] >= 0.5 && h[qu] > 0.0 {
                            sum += h[qu] as f64;
                            k += 1;
                        }
                    }
                }
                let avg = if k > 0 { sum / (k as f64) } else { h[c] as f64 };
                h2[c] = (0.7 * (h[c] as f64) + 0.3 * avg) as f32;
            }
            h = h2;
        }
        self.sl.glacier = h;
    }
}
