//! Plate tectonics model. Plates are weighted, noise-warped Voronoi regions whose
//! centres move along Euler-pole rotations. Boundary geometry, relative motion and
//! crust content are evaluated analytically at any point and any geological time.

use crate::mathx::*;
use crate::noise::Noise;
use crate::params::*;

#[derive(Clone, Debug, Default)]
pub struct Plate {
    pub id: usize,
    pub seed: V3,        // present-day centre
    pub weight: f64,     // size weight (bigger = larger plate)
    pub pole: V3,        // Euler pole
    pub omega: f64,      // rad / Myr
    pub cont: f64,       // continentalness of the plate's crust (0 oceanic .. 1 continental)
    pub base_age: f64,   // typical age (Myr) of oceanic crust on this plate
}

#[derive(Clone, Copy, Debug)]
pub struct TectSample {
    pub plate: usize,
    pub other: usize,
    pub dist_km: f64,    // distance to the nearest plate boundary
    pub n: V3,           // tangent unit vector pointing toward the other plate
    pub conv: f64,       // cm/yr, + converging, - diverging
    pub shear: f64,      // cm/yr along the boundary
    pub kind: i32,       // 0 interior, 1 convergent, 2 divergent, 3 transform
}

impl Default for TectSample {
    fn default() -> TectSample {
        TectSample { plate: 0, other: 0, dist_km: 1e9, n: V3::default(), conv: 0.0, shear: 0.0, kind: 0 }
    }
}

#[derive(Clone, Debug, Default)]
pub struct TectFrame {
    pub t: f64, // Myr relative to the present
    pub seed: Vec<V3>,
}

#[derive(Clone)]
pub struct Tectonics {
    pub plates: Vec<Plate>,
    pub cont_threshold: f64,
    pub radius_km: f64,
    pub noise: Noise,
    pub frame0: TectFrame,
}

impl Tectonics {
    pub fn new(noise: &Noise) -> Tectonics {
        Tectonics {
            plates: Vec::new(),
            cont_threshold: 0.5,
            radius_km: 6371.0,
            noise: noise.clone(),
            frame0: TectFrame::default(),
        }
    }

    pub fn init(&mut self, seed: u64, pp: &PlanetParams, dv: &Derived, nz: &Noise) {
        self.noise = nz.clone();
        self.radius_km = pp.radius_km;
        let mut rng = Rng::new(seed ^ 0x7EC70011u64);
        let pf = (15.0 * pp.radius_km / 6371.0 + (rng.irange(-2, 2) as f64) + 0.5).floor() as i32;
        let pn = clampv(pf, 8, 26) as usize;
        self.plates = vec![Plate::default(); pn];
        // blue-noise-ish plate centres (best candidate)
        for i in 0..pn {
            let mut best = rng.unit_vec();
            let mut best_score = 1e9f64;
            let tries = if i == 0 { 1 } else { 24 };
            for _k in 0..tries {
                let c = rng.unit_vec();
                let mut mx = -2.0f64;
                for j in 0..i {
                    mx = mx.max(dot(c, self.plates[j].seed));
                }
                if mx < best_score {
                    best_score = mx;
                    best = c;
                }
            }
            let w = dexp(rng.range(-0.35, 0.45));
            let pole = rng.unit_vec();
            let om = rng.range(0.15, 0.85) * DEG2RAD * dv.plate_scale;
            let age = rng.range(60.0, 170.0);
            let pl = &mut self.plates[i];
            pl.id = i;
            pl.seed = best;
            pl.weight = w;
            pl.pole = pole;
            pl.omega = om;
            pl.base_age = age;
        }
        // choose which plates are continental
        let mut order: Vec<usize> = (0..pn).collect();
        let mut i = pn - 1;
        while i > 0 {
            let j = rng.irange(0, i as i32) as usize;
            order.swap(i, j);
            i -= 1;
        }
        let nc = (((pn as f64) * (0.10 + 0.55 * dv.cont_fraction) + 0.5).floor()) as i32;
        let n_cont = clampv(nc, 1, (pn as i32) - 1) as usize;
        for k in 0..pn {
            let c = if k < n_cont { rng.range(0.80, 1.20) } else { rng.range(-0.30, 0.10) };
            self.plates[order[k]].cont = c;
        }
        let f0 = self.make_frame(0.0);
        self.frame0 = f0;
        // continental threshold from a global quantile so the crust fraction matches the ocean parameter
        let m: usize = 16000;
        let mut mv: Vec<f64> = vec![0.0; m];
        let mut r2 = Rng::new(seed ^ 0x51ED270Bu64);
        for i in 0..m {
            let x = r2.unit_vec();
            let s = self.sample(&self.frame0, x);
            mv[i] = self.mask_value(x, &s);
        }
        mv.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let q = clampv(((1.0 - dv.cont_fraction) * (m as f64)) as i32, 0, (m as i32) - 1) as usize;
        self.cont_threshold = mv[q];
    }

    pub fn make_frame(&self, t_myr: f64) -> TectFrame {
        let mut seeds: Vec<V3> = Vec::with_capacity(self.plates.len());
        for p in self.plates.iter() {
            if t_myr == 0.0 {
                seeds.push(p.seed);
            } else {
                seeds.push(normalize(rotate_axis(p.seed, p.pole, p.omega * t_myr)));
            }
        }
        TectFrame { t: t_myr, seed: seeds }
    }

    fn warp(&self, x: V3) -> V3 {
        let nz = &self.noise;
        let px = x.x as f32;
        let py = x.y as f32;
        let pz = x.z as f32;
        let a = 2.0f32;
        let b = 5.2f32;
        let d = V3::new(
            (nz.n3(px * a + 13.1, py * a, pz * a) as f64) * 0.20 + (nz.n3(px * b + 3.7, py * b, pz * b) as f64) * 0.045,
            (nz.n3(px * a, py * a + 71.7, pz * a) as f64) * 0.20 + (nz.n3(px * b, py * b + 9.1, pz * b) as f64) * 0.045,
            (nz.n3(px * a, py * a, pz * a + 37.3) as f64) * 0.20 + (nz.n3(px * b, py * b, pz * b + 21.9) as f64) * 0.045,
        );
        normalize(x + d)
    }

    pub fn velocity_cm_yr(&self, p: usize, x: V3) -> V3 {
        let pl = &self.plates[p];
        cross(pl.pole, x) * (pl.omega * self.radius_km * 0.1)
    }

    pub fn sample(&self, fr: &TectFrame, x: V3) -> TectSample {
        let w = self.warp(x);
        let np = self.plates.len();
        let mut d1 = 1e30f64;
        let mut d2 = 1e30f64;
        let mut c1 = 1.0f64;
        let mut c2 = 1.0f64;
        let mut i1 = 0usize;
        let mut i2 = 0usize;
        for i in 0..np {
            let dt = dot(w, fr.seed[i]);
            let chord = (2.0 - 2.0 * dt).max(1e-12).sqrt();
            let d = chord / self.plates[i].weight;
            if d < d1 {
                d2 = d1;
                i2 = i1;
                c2 = c1;
                d1 = d;
                i1 = i;
                c1 = chord;
            } else if d < d2 {
                d2 = d;
                i2 = i;
                c2 = chord;
            }
        }
        let mut s = TectSample::default();
        s.plate = i1;
        s.other = i2;
        let p1 = tangent_part(fr.seed[i1], w);
        let p2 = tangent_part(fr.seed[i2], w);
        let g_f = p2 * (1.0 / (c2 * self.plates[i2].weight)) - p1 * (1.0 / (c1 * self.plates[i1].weight));
        let gl = length(g_f);
        let f = d2 - d1;
        s.dist_km = (if gl > 1e-9 { f / gl } else { 1.0 }) * self.radius_km;
        s.n = normalize(tangent_part(g_f, x));
        let vr = self.velocity_cm_yr(i2, x) - self.velocity_cm_yr(i1, x);
        s.conv = -dot(vr, s.n);
        s.shear = dot(vr, cross(x, s.n));
        let sp = length(vr);
        let a_s = s.shear.abs();
        s.kind = if sp < 0.4 {
            0
        } else if s.conv > 0.6 * a_s {
            1
        } else if s.conv < -0.6 * a_s {
            2
        } else {
            3
        };
        s
    }

    pub fn mask_value(&self, y: V3, s0: &TectSample) -> f64 {
        let nz = &self.noise;
        let px = y.x as f32;
        let py = y.y as f32;
        let pz = y.z as f32;
        let m = self.plates[s0.plate].cont
            + 0.50 * (nz.fbm(px * 1.6 + 5.5, py * 1.6, pz * 1.6, 4) as f64)
            + 0.15 * (nz.fbm(px * 4.2, py * 4.2 + 9.3, pz * 4.2, 3) as f64);
        let bias = (self.plates[s0.plate].cont - self.plates[s0.other].cont) * 1.1 * dexp(-s0.dist_km / 350.0);
        m + bias
    }

    /// continental fraction (0..1) of the crust that plate s.plate carries at x in frame fr
    pub fn crust_frac(&self, fr: &TectFrame, x: V3, s: &TectSample) -> f64 {
        let m: f64;
        if fr.t == 0.0 {
            m = self.mask_value(x, s);
        } else {
            let pl = &self.plates[s.plate];
            let y = rotate_axis(x, pl.pole, -pl.omega * fr.t);
            let s0 = self.sample(&self.frame0, y);
            if s0.plate != s.plate {
                return 0.0; // newly created crust
            }
            m = self.mask_value(y, &s0);
        }
        smoothstep(self.cont_threshold - 0.06, self.cont_threshold + 0.06, m)
    }
}
