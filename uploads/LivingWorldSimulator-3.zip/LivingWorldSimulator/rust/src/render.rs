//! OpenGL ES renderer: cube-sphere quadtree of streamed chunks with camera-relative coordinates, frustum +
//! horizon culling, screen-space LOD, skirts for crack-free LOD borders, plus a cloud shell, atmosphere glow
//! and a star field. Chunk meshes/textures are built on worker threads and uploaded a few per frame.

use crate::camera::Camera;
use crate::chunk::*;
use crate::civ::CityMark;
use crate::gl::*;
use crate::grid::{face_dir, face_axes};
use crate::mathx::*;
use crate::world::*;
use std::cmp::Ordering as CmpOrdering;
use std::collections::BinaryHeap;
use std::ffi::c_void;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Condvar, Mutex};
use std::time::Instant;

// ---------------------------------------------------------------------------------------------------
// shaders
// ---------------------------------------------------------------------------------------------------
const TERRAIN_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uVP;
uniform vec3 uOffset;
uniform vec3 uCenter;
out vec2 vUV;
out vec3 vN;
out vec3 vRel;
void main() {
    vec3 rel = aPos + uOffset;
    gl_Position = uVP * vec4(rel, 1.0);
    vUV = aUV;
    vN = normalize(uCenter + aPos);
    vRel = rel;
}
"#;

const TERRAIN_FS: &str = r#"#version 300 es
precision highp float;
in vec2 vUV;
in vec3 vN;
in vec3 vRel;
uniform sampler2D uAlbedo;
uniform sampler2D uNormal;
uniform vec3 uAxis1;
uniform vec3 uSun;
uniform float uHazeK;
uniform float uHazeAmt;
uniform vec3 uHazeColor;
uniform float uTexT;
uniform float uTexD;
out vec4 fragColor;
void main() {
    vec2 st = (vUV * uTexT + 1.0) / uTexD;
    vec4 al = texture(uAlbedo, st);
    vec2 nm = texture(uNormal, st).rg * 2.0 - 1.0;
    float nz = sqrt(max(0.0, 1.0 - dot(nm, nm)));
    vec3 N = normalize(vN);
    vec3 T1 = normalize(uAxis1 - N * dot(uAxis1, N));
    vec3 T2 = cross(N, T1);
    vec3 n = normalize(T1 * nm.x + T2 * nm.y + N * nz);
    vec3 L = normalize(uSun);
    float geo = dot(N, L);
    float day = smoothstep(-0.07, 0.10, geo);
    float diff = max(dot(n, L), 0.0);
    float dist = length(vRel);
    vec3 V = -vRel / max(dist, 0.001);
    vec3 H = normalize(L + V);
    float nh = max(dot(n, H), 0.0);
    float water = al.a;
    float spec = (pow(nh, 140.0) * 0.9 + pow(nh, 22.0) * 0.10) * water * day;
    float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0) * water;
    vec3 alb = al.rgb * al.rgb;
    vec3 ambient = vec3(0.020, 0.028, 0.050) + vec3(0.075, 0.095, 0.135) * day;
    vec3 col = alb * (ambient + vec3(1.10, 1.04, 0.96) * diff * day);
    col += vec3(spec) + fres * vec3(0.12, 0.20, 0.34) * day;
    float haze = (1.0 - exp(-dist * uHazeK)) * uHazeAmt;
    col = mix(col, uHazeColor * (0.25 + 0.75 * day), clamp(haze, 0.0, 0.92));
    col = col / (1.0 + 0.18 * col);
    fragColor = vec4(sqrt(max(col, 0.0)), 1.0);
}
"#;

const SHELL_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aDir;
uniform mat4 uVP;
uniform vec3 uCenterRel;
uniform float uRadius;
out vec3 vDir;
out vec3 vRel;
void main() {
    vec3 rel = uCenterRel + aDir * uRadius;
    gl_Position = uVP * vec4(rel, 1.0);
    vDir = aDir;
    vRel = rel;
}
"#;

const CLOUD_FS: &str = r#"#version 300 es
precision highp float;
in vec3 vDir;
in vec3 vRel;
uniform sampler2D uCloud;
uniform vec3 uSun;
uniform float uAlpha;
uniform float uShift;
out vec4 fragColor;
void main() {
    vec3 d = normalize(vDir);
    float u = atan(d.y, d.x) * 0.15915494 + 0.5 + uShift;
    float v = 0.5 - asin(clamp(d.z, -1.0, 1.0)) * 0.31830989;
    float c = texture(uCloud, vec2(u, v)).r;
    float geo = dot(d, normalize(uSun));
    float lit = smoothstep(-0.12, 0.28, geo);
    vec3 col = mix(vec3(0.04, 0.05, 0.08), vec3(1.0, 0.99, 0.97), lit);
    float shade = 0.74 + 0.26 * smoothstep(0.25, 1.0, c);
    fragColor = vec4(col * shade, c * uAlpha);
}
"#;

const ATMO_FS: &str = r#"#version 300 es
precision highp float;
in vec3 vDir;
in vec3 vRel;
uniform vec3 uSun;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    vec3 N = normalize(vDir);
    vec3 V = normalize(-vRel);
    float ndv = clamp(dot(N, V), 0.0, 1.0);
    float glow = smoothstep(0.0, 0.10, ndv) * (1.0 - smoothstep(0.15, 0.50, ndv)) * 1.1 + 0.10 * pow(1.0 - ndv, 3.0);
    float geo = dot(N, normalize(uSun));
    float day = smoothstep(-0.30, 0.35, geo);
    vec3 col = mix(vec3(0.95, 0.45, 0.22), vec3(0.28, 0.55, 1.0), smoothstep(-0.05, 0.40, geo));
    fragColor = vec4(col, glow * day * uAlpha);
}
"#;

const STAR_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec4 aStar;
uniform mat4 uVP;
out float vB;
void main() {
    vec4 p = uVP * vec4(aStar.xyz, 0.0);
    gl_Position = p.xyww;
    gl_PointSize = 1.2 + 1.8 * aStar.w;
    vB = aStar.w;
}
"#;

const STAR_FS: &str = r#"#version 300 es
precision mediump float;
in float vB;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    float b = 0.45 + 0.55 * vB;
    fragColor = vec4(vec3(b, b, b * 1.05), uAlpha);
}
"#;

const CITY_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec4 aRel;
layout(location = 1) in vec4 aDir;
uniform mat4 uVP;
uniform vec3 uSun;
uniform float uScale;
out float vNight;
void main() {
    vec4 p = uVP * vec4(aRel.xyz, 1.0);
    p.z -= 0.004 * p.w;
    gl_Position = p;
    gl_PointSize = (4.0 + 9.0 * aRel.w) * uScale;
    float geo = dot(normalize(aDir.xyz), normalize(uSun));
    vNight = 1.0 - smoothstep(-0.10, 0.14, geo);
}
"#;

const CITY_FS: &str = r#"#version 300 es
precision mediump float;
in float vNight;
out vec4 fragColor;
void main() {
    vec2 d = gl_PointCoord * 2.0 - 1.0;
    float r2 = dot(d, d);
    if (r2 > 1.0) {
        discard;
    }
    float core = smoothstep(1.0, 0.25, r2);
    vec3 dayCol = vec3(0.92, 0.30, 0.18);
    vec3 nightCol = vec3(1.0, 0.82, 0.42);
    vec3 col = mix(dayCol, nightCol, vNight);
    fragColor = vec4(col, core * mix(0.80, 1.0, vNight));
}
"#;

const MAX_LEVEL_USED: i32 = 15;
const SPLIT_PX: f64 = 1.7;
const INDEX_COUNT: usize = (KG * KG * 6 + 4 * KG * 6) as usize;
const NONE: usize = usize::MAX;

// ---------------------------------------------------------------------------------------------------
// chunk tree + streaming
// ---------------------------------------------------------------------------------------------------
pub struct Flags {
    pub wanted: AtomicU64,
    pub discarded: AtomicBool,
}

pub struct Node {
    alive: bool,
    slot_gen: u32,
    face: usize,
    level: i32,
    x: i32,
    y: i32,
    kids: [usize; 4],
    cx: f64,
    cy: f64,
    cz: f64,
    radius: f64,
    edge_m: f64,
    state: u8, // 0 idle, 1 queued/building
    retry_at: u64,
    last_used: u64,
    has_gpu: bool,
    vao: u32,
    vbo: u32,
    tex_a: u32,
    tex_n: u32,
    built_gen: i64,
    built_stamp: i64,
    built_layer: i64,
    flags: Arc<Flags>,
}

fn make_node(face: usize, level: i32, x: i32, y: i32, r: f64) -> Node {
    let n = 1i32 << level;
    let size = 2.0 / (n as f64);
    let u0 = -1.0 + (x as f64) * size;
    let v0 = -1.0 + (y as f64) * size;
    let c = face_dir(face, u0 + size * 0.5, v0 + size * 0.5);
    let mut far = 0.0f64;
    for k in 0..4i32 {
        let q = face_dir(face, u0 + ((k & 1) as f64) * size, v0 + ((k >> 1) as f64) * size);
        far = far.max(length(q - c));
    }
    let radius = far * r * 1.02 + 12000.0;
    let a = face_dir(face, u0, v0 + size * 0.5);
    let b = face_dir(face, u0 + size, v0 + size * 0.5);
    let edge_m = length(a - b) * r;
    Node {
        alive: true,
        slot_gen: 0,
        face,
        level,
        x,
        y,
        kids: [NONE; 4],
        cx: c.x,
        cy: c.y,
        cz: c.z,
        radius,
        edge_m,
        state: 0,
        retry_at: 0,
        last_used: 0,
        has_gpu: false,
        vao: 0,
        vbo: 0,
        tex_a: 0,
        tex_n: 0,
        built_gen: -1,
        built_stamp: -1,
        built_layer: -1,
        flags: Arc::new(Flags { wanted: AtomicU64::new(0), discarded: AtomicBool::new(false) }),
    }
}

struct Job {
    prio: f64,
    seq: u64,
    idx: usize,
    slot_gen: u32,
    tree_epoch: u32,
    face: usize,
    level: i32,
    x: i32,
    y: i32,
    layer: i32,
    gen: i64,
    stamp: i64,
    flags: Arc<Flags>,
}
impl PartialEq for Job {
    fn eq(&self, o: &Job) -> bool {
        self.seq == o.seq
    }
}
impl Eq for Job {}
impl PartialOrd for Job {
    fn partial_cmp(&self, o: &Job) -> Option<CmpOrdering> {
        Some(self.cmp(o))
    }
}
impl Ord for Job {
    fn cmp(&self, o: &Job) -> CmpOrdering {
        // BinaryHeap pops the greatest: make the smallest priority value (most urgent) the greatest
        match o.prio.partial_cmp(&self.prio) {
            Some(CmpOrdering::Equal) | None => o.seq.cmp(&self.seq),
            Some(x) => x,
        }
    }
}

struct Done {
    idx: usize,
    slot_gen: u32,
    tree_epoch: u32,
    gen: i64,
    stamp: i64,
    layer: i32,
    failed: bool,
    out: Option<Box<ChunkOut>>,
}

struct WorkQueue {
    heap: Mutex<BinaryHeap<Job>>,
    cv: Condvar,
    stop: AtomicBool,
    frame: AtomicU64,
    queued: AtomicUsize,
    active: AtomicUsize,
    built: AtomicU64,
    micros: AtomicU64,
}

type Pool = Arc<Mutex<Vec<Box<ChunkOut>>>>;

fn worker_main(q: Arc<WorkQueue>, world: Arc<World>, tx: Sender<Done>, pool: Pool) {
    let mut scratch = Scratch::new();
    loop {
        let job: Job = {
            let mut h = lk(&q.heap);
            loop {
                if q.stop.load(Ordering::SeqCst) {
                    return;
                }
                if let Some(j) = h.pop() {
                    break j;
                }
                h = q.cv.wait(h).unwrap_or_else(|e| e.into_inner());
            }
        };
        q.queued.fetch_sub(1, Ordering::SeqCst);
        let frame_now = q.frame.load(Ordering::SeqCst);
        let stale = job.flags.discarded.load(Ordering::SeqCst) || frame_now.saturating_sub(job.flags.wanted.load(Ordering::SeqCst)) > 45;
        let mk = |failed: bool, out: Option<Box<ChunkOut>>| Done {
            idx: job.idx,
            slot_gen: job.slot_gen,
            tree_epoch: job.tree_epoch,
            gen: job.gen,
            stamp: job.stamp,
            layer: job.layer,
            failed,
            out,
        };
        if stale {
            if tx.send(mk(false, None)).is_err() {
                return;
            }
            continue;
        }
        let view = match world.view() {
            Some(v) => v,
            None => {
                if tx.send(mk(true, None)).is_err() {
                    return;
                }
                continue;
            }
        };
        let mut out: Box<ChunkOut> = match lk(&pool).pop() {
            Some(o) => o,
            None => Box::new(ChunkOut::new()),
        };
        q.active.fetch_add(1, Ordering::SeqCst);
        let t0 = Instant::now();
        let res = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            build_chunk(&view, job.face, job.level, job.x, job.y, job.layer, &mut scratch, &mut out)
        }));
        q.active.fetch_sub(1, Ordering::SeqCst);
        let ok = match res {
            Ok(b) => b,
            Err(_) => false,
        };
        if ok {
            q.built.fetch_add(1, Ordering::SeqCst);
            q.micros.fetch_add(t0.elapsed().as_micros() as u64, Ordering::SeqCst);
            if tx.send(mk(false, Some(out))).is_err() {
                return;
            }
        } else {
            lk(&pool).push(out);
            if tx.send(mk(true, None)).is_err() {
                return;
            }
        }
    }
}

pub struct ChunkMgr {
    nodes: Vec<Node>,
    free: Vec<usize>,
    roots: [usize; 6],
    gpu_list: Vec<usize>,
    pub radius_m: f64,
    pub gen: i64,
    pub stamp: i64,
    pub layer: i32,
    pub frame: u64,
    tree_epoch: u32,
    ibo: u32,
    pub max_gpu_chunks: usize,
    queue: Arc<WorkQueue>,
    rx: Receiver<Done>,
    pool: Pool,
    seq: u64,
    pub uploads_this_frame: usize,
    pub workers: usize,
    threads: Vec<std::thread::JoinHandle<()>>,
}

fn tex_params() {
    unsafe {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR as i32);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR as i32);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE as i32);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE as i32);
    }
}

impl ChunkMgr {
    pub fn new(world: Arc<World>) -> ChunkMgr {
        let cores = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(4);
        let workers = clampv(cores / 2, 1, 3);
        let queue = Arc::new(WorkQueue {
            heap: Mutex::new(BinaryHeap::new()),
            cv: Condvar::new(),
            stop: AtomicBool::new(false),
            frame: AtomicU64::new(0),
            queued: AtomicUsize::new(0),
            active: AtomicUsize::new(0),
            built: AtomicU64::new(0),
            micros: AtomicU64::new(0),
        });
        let (tx, rx) = channel::<Done>();
        let pool: Pool = Arc::new(Mutex::new(Vec::new()));
        let mut threads = Vec::new();
        for _ in 0..workers {
            let q = Arc::clone(&queue);
            let w = Arc::clone(&world);
            let t = tx.clone();
            let p = Arc::clone(&pool);
            let builder = std::thread::Builder::new().name(String::from("lw-chunk")).stack_size(4 * 1024 * 1024);
            if let Ok(h) = builder.spawn(move || worker_main(q, w, t, p)) {
                threads.push(h);
            }
        }
        ChunkMgr {
            nodes: Vec::new(),
            free: Vec::new(),
            roots: [NONE; 6],
            gpu_list: Vec::new(),
            radius_m: 6371000.0,
            gen: -1,
            stamp: 0,
            layer: 0,
            frame: 0,
            tree_epoch: 0,
            ibo: 0,
            max_gpu_chunks: 420,
            queue,
            rx,
            pool,
            seq: 0,
            uploads_this_frame: 0,
            workers,
            threads,
        }
    }

    pub fn set_ibo(&mut self, ibo: u32) {
        self.ibo = ibo;
    }
    pub fn gpu_chunk_count(&self) -> usize {
        self.gpu_list.len()
    }
    pub fn queued_jobs(&self) -> usize {
        self.queue.queued.load(Ordering::SeqCst)
    }
    pub fn active_jobs(&self) -> usize {
        self.queue.active.load(Ordering::SeqCst)
    }
    pub fn build_stats(&self) -> (f64, u64) {
        let n = self.queue.built.load(Ordering::SeqCst);
        let us = self.queue.micros.load(Ordering::SeqCst);
        (if n > 0 { (us as f64) / 1000.0 / (n as f64) } else { 0.0 }, n)
    }

    fn alloc_node(&mut self, node: Node) -> usize {
        if let Some(i) = self.free.pop() {
            let sg = self.nodes[i].slot_gen;
            let mut n = node;
            n.slot_gen = sg;
            self.nodes[i] = n;
            i
        } else {
            self.nodes.push(node);
            self.nodes.len() - 1
        }
    }

    fn free_node(&mut self, i: usize) {
        let n = &mut self.nodes[i];
        n.flags.discarded.store(true, Ordering::SeqCst);
        n.alive = false;
        n.slot_gen = n.slot_gen.wrapping_add(1);
        n.kids = [NONE; 4];
        self.free.push(i);
    }

    pub fn root(&mut self, face: usize) -> usize {
        if self.roots[face] == NONE {
            let node = make_node(face, 0, 0, 0, self.radius_m);
            let i = self.alloc_node(node);
            self.roots[face] = i;
        }
        self.roots[face]
    }

    fn child(&mut self, p: usize, i: usize) -> usize {
        let k = self.nodes[p].kids[i];
        if k != NONE {
            return k;
        }
        let (face, level, x, y) = {
            let n = &self.nodes[p];
            (n.face, n.level, n.x, n.y)
        };
        let node = make_node(face, level + 1, x * 2 + ((i as i32) & 1), y * 2 + ((i as i32) >> 1), self.radius_m);
        let idx = self.alloc_node(node);
        self.nodes[p].kids[i] = idx;
        idx
    }

    fn is_stale(&self, i: usize) -> bool {
        let n = &self.nodes[i];
        n.built_gen != self.gen || n.built_stamp != self.stamp || n.built_layer != (self.layer as i64)
    }

    fn request(&mut self, i: usize, prio: f64) {
        let frame = self.frame;
        let (state, retry_at, discarded) = {
            let n = &self.nodes[i];
            (n.state, n.retry_at, n.flags.discarded.load(Ordering::SeqCst))
        };
        if state != 0 || discarded || frame < retry_at {
            return;
        }
        let job = {
            let n = &mut self.nodes[i];
            n.state = 1;
            n.flags.wanted.store(frame, Ordering::SeqCst);
            Job {
                prio,
                seq: 0,
                idx: i,
                slot_gen: n.slot_gen,
                tree_epoch: 0,
                face: n.face,
                level: n.level,
                x: n.x,
                y: n.y,
                layer: 0,
                gen: 0,
                stamp: 0,
                flags: Arc::clone(&n.flags),
            }
        };
        self.seq += 1;
        let mut job = job;
        job.seq = self.seq;
        job.tree_epoch = self.tree_epoch;
        job.layer = self.layer;
        job.gen = self.gen;
        job.stamp = self.stamp;
        self.queue.queued.fetch_add(1, Ordering::SeqCst);
        lk(&self.queue.heap).push(job);
        self.queue.cv.notify_one();
    }

    /// GL thread: take finished chunks from the workers and upload a few per frame
    pub fn process_uploads(&mut self, budget_ns: u128) {
        let t0 = Instant::now();
        self.uploads_this_frame = 0;
        self.queue.frame.store(self.frame, Ordering::SeqCst);
        loop {
            let done = match self.rx.try_recv() {
                Ok(d) => d,
                Err(_) => break,
            };
            if done.tree_epoch != self.tree_epoch {
                if let Some(o) = done.out {
                    lk(&self.pool).push(o);
                }
                continue;
            }
            let idx = done.idx;
            if idx >= self.nodes.len() || !self.nodes[idx].alive || self.nodes[idx].slot_gen != done.slot_gen {
                if let Some(o) = done.out {
                    lk(&self.pool).push(o);
                }
                continue;
            }
            match done.out {
                None => {
                    let frame = self.frame;
                    let n = &mut self.nodes[idx];
                    n.state = 0;
                    if done.failed {
                        n.retry_at = frame + 90;
                    }
                }
                Some(out) => {
                    if self.nodes[idx].flags.discarded.load(Ordering::SeqCst) {
                        self.nodes[idx].state = 0;
                        lk(&self.pool).push(out);
                        continue;
                    }
                    self.upload(idx, &out);
                    lk(&self.pool).push(out);
                    let n = &mut self.nodes[idx];
                    n.built_gen = done.gen;
                    n.built_stamp = done.stamp;
                    n.built_layer = done.layer as i64;
                    n.state = 0;
                    self.uploads_this_frame += 1;
                }
            }
            if t0.elapsed().as_nanos() > budget_ns {
                break;
            }
        }
    }

    fn upload(&mut self, idx: usize, out: &ChunkOut) {
        let ibo = self.ibo;
        let first = !self.nodes[idx].has_gpu;
        {
            let n = &mut self.nodes[idx];
            unsafe {
                if first {
                    glGenVertexArrays(1, &mut n.vao);
                    glGenBuffers(1, &mut n.vbo);
                    glGenTextures(1, &mut n.tex_a);
                    glGenTextures(1, &mut n.tex_n);
                }
                glBindVertexArray(n.vao);
                glBindBuffer(GL_ARRAY_BUFFER, n.vbo);
                glBufferData(GL_ARRAY_BUFFER, (KVERT_COUNT * KVERT_BYTES) as isize, out.vtx.as_ptr() as *const c_void, GL_STATIC_DRAW);
                if first {
                    glEnableVertexAttribArray(0);
                    glVertexAttribPointer(0, 3, GL_FLOAT, 0, KVERT_BYTES as i32, std::ptr::null());
                    glEnableVertexAttribArray(1);
                    glVertexAttribPointer(1, 2, GL_UNSIGNED_SHORT, 1, KVERT_BYTES as i32, 12usize as *const c_void);
                    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
                }
                glBindVertexArray(0);
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, n.tex_a);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8 as i32, KD, KD, 0, GL_RGBA, GL_UNSIGNED_BYTE, out.albedo.as_ptr() as *const c_void);
                if first {
                    tex_params();
                }
                glGenerateMipmap(GL_TEXTURE_2D);
                glBindTexture(GL_TEXTURE_2D, n.tex_n);
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RG8 as i32, KD, KD, 0, GL_RG, GL_UNSIGNED_BYTE, out.normal.as_ptr() as *const c_void);
                if first {
                    tex_params();
                }
                glGenerateMipmap(GL_TEXTURE_2D);
            }
        }
        if first {
            self.nodes[idx].has_gpu = true;
            self.gpu_list.push(idx);
        }
    }

    fn free_gpu(&mut self, idx: usize, context_alive: bool) {
        let n = &mut self.nodes[idx];
        if context_alive && n.has_gpu {
            unsafe {
                glDeleteVertexArrays(1, &n.vao);
                glDeleteBuffers(1, &n.vbo);
                glDeleteTextures(1, &n.tex_a);
                glDeleteTextures(1, &n.tex_n);
            }
        }
        n.has_gpu = false;
        n.vao = 0;
        n.vbo = 0;
        n.tex_a = 0;
        n.tex_n = 0;
        n.built_gen = -1;
    }

    /// new planet / geological step / lost GL context: drop everything and start a fresh tree
    pub fn hard_reset(&mut self, new_gen: i64, context_alive: bool) {
        let list: Vec<usize> = self.gpu_list.clone();
        for i in list {
            self.free_gpu(i, context_alive);
        }
        self.gpu_list.clear();
        for n in self.nodes.iter() {
            n.flags.discarded.store(true, Ordering::SeqCst);
        }
        self.nodes.clear();
        self.free.clear();
        self.roots = [NONE; 6];
        self.tree_epoch = self.tree_epoch.wrapping_add(1);
        self.gen = new_gen;
    }

    /// LRU eviction of GPU chunks and pruning of unused tree nodes
    pub fn evict(&mut self) {
        if self.gpu_list.len() > self.max_gpu_chunks {
            let mut cand: Vec<usize> = Vec::new();
            for &i in self.gpu_list.iter() {
                let n = &self.nodes[i];
                if n.level > 1 && self.frame.saturating_sub(n.last_used) > 4 {
                    cand.push(i);
                }
            }
            cand.sort_by(|&a, &b| self.nodes[a].last_used.cmp(&self.nodes[b].last_used));
            let mut excess = self.gpu_list.len() - self.max_gpu_chunks;
            let mut k = 0usize;
            while excess > 0 && k < cand.len() {
                let i = cand[k];
                k += 1;
                self.gpu_list.retain(|&x| x != i);
                self.free_gpu(i, true);
                excess -= 1;
            }
        }
        if self.frame % 240 == 0 {
            for f in 0..6usize {
                let r = self.roots[f];
                if r != NONE {
                    self.prune(r);
                }
            }
        }
    }

    fn prune(&mut self, idx: usize) -> bool {
        let (mut keep, kids) = {
            let n = &self.nodes[idx];
            (n.has_gpu || n.state != 0 || self.frame.saturating_sub(n.last_used) < 600, n.kids)
        };
        for i in 0..4usize {
            let k = kids[i];
            if k == NONE {
                continue;
            }
            if self.prune(k) {
                keep = true;
            } else {
                self.free_node(k);
                self.nodes[idx].kids[i] = NONE;
            }
        }
        keep
    }

    pub fn shutdown(&mut self) {
        self.queue.stop.store(true, Ordering::SeqCst);
        self.queue.cv.notify_all();
        let hs: Vec<std::thread::JoinHandle<()>> = self.threads.drain(..).collect();
        for h in hs {
            let _ = h.join();
        }
    }
}

// ---------------------------------------------------------------------------------------------------
// renderer
// ---------------------------------------------------------------------------------------------------
pub struct FrameInput {
    pub ready: bool,
    pub epoch: i64,
    pub stamp: i64,
    pub layer: i32,
    pub sun: [f64; 3],
    pub radius_m: f64,
    pub cloud: Option<(Vec<u8>, i32, i32)>,
    /// bumped only when slow ecosystem data changed (rivers, lakes, biomes, glaciers): layers that do not show the
    /// current weather/season rebuild their tiles on this instead of on every climate stamp
    pub slow_stamp: i64,
    pub marks: Vec<CityMark>,
}

pub struct Renderer {
    pub mgr: ChunkMgr,
    prog_terrain: u32,
    prog_cloud: u32,
    prog_atmo: u32,
    prog_star: u32,
    prog_city: u32,
    u_t: [i32; 12],
    u_c: [i32; 7],
    u_a: [i32; 5],
    u_s: [i32; 2],
    u_city: [i32; 3],
    city_vbo: u32,
    ibo: u32,
    shell_vbo: u32,
    shell_ibo: u32,
    shell_idx: i32,
    star_vbo: u32,
    star_count: i32,
    cloud_tex: u32,
    clouds_ready: bool,
    pub view_w: i32,
    pub view_h: i32,
    context_lost: bool,
    have_planet: bool,
    frame_no: u64,
    last: Option<Instant>,
    cloud_shift: f32,
    visible: Vec<usize>,
    refresh_budget: i32,
    cam_x: f64,
    cam_y: f64,
    cam_z: f64,
    cam_len: f64,
    radius: f64,
    horizon_margin: f64,
    sun: [f64; 3],
    // statistics
    pub fps: f64,
    pub frame_ms: f64,
    pub visible_chunks: usize,
    pub tris: usize,
    pub draws: usize,
    pub gpu_info: String,
    pub shader_error: String,
    pub roots_ready: bool,
    pub roots_done: usize,
    pub uploads_per_frame: usize,
    pub planet_radius: f64,
}

fn smooth(a: f64, b: f64, x: f64) -> f64 {
    smoothstep(a, b, x)
}

/// Layers whose pixels depend on the current weather / season (snow, sea ice, temperature, pressure, wind). Every other
/// layer (elevation, rainfall, plates, soil, ocean depth) only changes when the slow ecosystem data changes, so its
/// tiles are not rebuilt on every climate stamp.
fn layer_is_dynamic(l: i32) -> bool {
    l == L_VISUAL || l == L_TEMPERATURE || l == L_PRESSURE || l == L_WIND || l == L_RIVERS || l == L_BIOMES
}

/// cube-sphere shell mesh. Vertices are pushed out so that the flat triangles never dip below the true sphere
/// (a plain low-poly sphere sinks into the terrain between its vertices and punches holes in the clouds).
fn build_shell_mesh() -> (Vec<f32>, Vec<u16>) {
    let n = 24usize;
    let scale = 1.0 / dcos(3.0 * DEG2RAD);
    let mut verts: Vec<f32> = Vec::with_capacity(6 * (n + 1) * (n + 1) * 3);
    let mut idx: Vec<u16> = Vec::with_capacity(6 * n * n * 6);
    for f in 0..6usize {
        let base = verts.len() / 3;
        for j in 0..=n {
            for i in 0..=n {
                let u = -1.0 + 2.0 * (i as f64) / (n as f64);
                let v = -1.0 + 2.0 * (j as f64) / (n as f64);
                let p = face_dir(f, u, v) * scale;
                verts.push(p.x as f32);
                verts.push(p.y as f32);
                verts.push(p.z as f32);
            }
        }
        for j in 0..n {
            for i in 0..n {
                let a = base + j * (n + 1) + i;
                let b = a + 1;
                let c = a + n + 1;
                let d = c + 1;
                idx.push(a as u16);
                idx.push(c as u16);
                idx.push(b as u16);
                idx.push(b as u16);
                idx.push(c as u16);
                idx.push(d as u16);
            }
        }
    }
    (verts, idx)
}

impl Renderer {
    pub fn new(world: Arc<World>) -> Renderer {
        Renderer {
            mgr: ChunkMgr::new(world),
            prog_terrain: 0,
            prog_cloud: 0,
            prog_atmo: 0,
            prog_star: 0,
            prog_city: 0,
            u_t: [-1; 12],
            u_c: [-1; 7],
            u_a: [-1; 5],
            u_s: [-1; 2],
            u_city: [-1; 3],
            city_vbo: 0,
            ibo: 0,
            shell_vbo: 0,
            shell_ibo: 0,
            shell_idx: 0,
            star_vbo: 0,
            star_count: 900,
            cloud_tex: 0,
            clouds_ready: false,
            view_w: 1,
            view_h: 1,
            context_lost: true,
            have_planet: false,
            frame_no: 0,
            last: None,
            cloud_shift: 0.0,
            visible: Vec::with_capacity(512),
            refresh_budget: 0,
            cam_x: 0.0,
            cam_y: 0.0,
            cam_z: 0.0,
            cam_len: 0.0,
            radius: 6371000.0,
            horizon_margin: 0.0,
            sun: [1.0, 0.0, 0.0],
            fps: 0.0,
            frame_ms: 0.0,
            visible_chunks: 0,
            tris: 0,
            draws: 0,
            gpu_info: String::new(),
            shader_error: String::new(),
            roots_ready: false,
            roots_done: 0,
            uploads_per_frame: 0,
            planet_radius: 6371000.0,
        }
    }

    pub fn on_surface_created(&mut self) {
        self.gpu_info = format!("{} / {}", get_string(GL_RENDERER), get_string(GL_VERSION));
        self.shader_error.clear();
        self.prog_terrain = self.compile("terrain", TERRAIN_VS, TERRAIN_FS);
        self.prog_cloud = self.compile("cloud", SHELL_VS, CLOUD_FS);
        self.prog_atmo = self.compile("atmosphere", SHELL_VS, ATMO_FS);
        self.prog_star = self.compile("stars", STAR_VS, STAR_FS);
        self.prog_city = self.compile("cities", CITY_VS, CITY_FS);
        if self.prog_terrain != 0 {
            let names = ["uVP", "uOffset", "uCenter", "uAxis1", "uSun", "uHazeK", "uHazeAmt", "uHazeColor", "uTexT", "uTexD", "uAlbedo", "uNormal"];
            for i in 0..names.len() {
                self.u_t[i] = uniform_loc(self.prog_terrain, names[i]);
            }
        }
        if self.prog_cloud != 0 {
            let names = ["uVP", "uCenterRel", "uRadius", "uCloud", "uSun", "uAlpha", "uShift"];
            for i in 0..names.len() {
                self.u_c[i] = uniform_loc(self.prog_cloud, names[i]);
            }
        }
        if self.prog_atmo != 0 {
            let names = ["uVP", "uCenterRel", "uRadius", "uSun", "uAlpha"];
            for i in 0..names.len() {
                self.u_a[i] = uniform_loc(self.prog_atmo, names[i]);
            }
        }
        if self.prog_star != 0 {
            let names = ["uVP", "uAlpha"];
            for i in 0..names.len() {
                self.u_s[i] = uniform_loc(self.prog_star, names[i]);
            }
        }
        if self.prog_city != 0 {
            let names = ["uVP", "uSun", "uScale"];
            for i in 0..names.len() {
                self.u_city[i] = uniform_loc(self.prog_city, names[i]);
            }
        }
        self.build_shared_buffers();
        self.clouds_ready = false;
        self.cloud_tex = 0;
        self.context_lost = true;
        unsafe {
            glEnable(GL_DEPTH_TEST);
            glDepthFunc(GL_LEQUAL);
            glDisable(GL_CULL_FACE);
        }
    }

    fn compile(&mut self, what: &str, vs: &str, fs: &str) -> u32 {
        match compile_program(vs, fs) {
            Ok(p) => p,
            Err(e) => {
                let msg = format!("{} shader {}", what, e);
                log(&msg);
                if self.shader_error.is_empty() {
                    self.shader_error = msg;
                }
                0
            }
        }
    }

    pub fn on_surface_changed(&mut self, w: i32, h: i32) {
        self.view_w = if w < 1 { 1 } else { w };
        self.view_h = if h < 1 { 1 } else { h };
        unsafe {
            glViewport(0, 0, w, h);
        }
    }

    fn build_shared_buffers(&mut self) {
        // shared terrain index buffer: grid + 4 skirts
        let g = KG as usize;
        let vg = KVG as usize;
        let mut idx: Vec<u16> = Vec::with_capacity(INDEX_COUNT);
        for j in 0..g {
            for i in 0..g {
                let a = j * vg + i;
                let b = a + 1;
                let c = a + vg;
                let d = c + 1;
                idx.push(a as u16);
                idx.push(b as u16);
                idx.push(c as u16);
                idx.push(b as u16);
                idx.push(d as u16);
                idx.push(c as u16);
            }
        }
        let base = vg * vg;
        for e in 0..4usize {
            for i in 0..g {
                let (ga, gb) = match e {
                    0 => (i, i + 1),
                    1 => (g * vg + i, g * vg + i + 1),
                    2 => (i * vg, (i + 1) * vg),
                    _ => (i * vg + g, (i + 1) * vg + g),
                };
                let sa = base + e * vg + i;
                let sb = sa + 1;
                idx.push(ga as u16);
                idx.push(sa as u16);
                idx.push(gb as u16);
                idx.push(gb as u16);
                idx.push(sa as u16);
                idx.push(sb as u16);
            }
        }
        unsafe {
            glBindVertexArray(0);
            let mut id = 0u32;
            glGenBuffers(1, &mut id);
            self.ibo = id;
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, (idx.len() * 2) as isize, idx.as_ptr() as *const c_void, GL_STATIC_DRAW);
        }
        self.mgr.set_ibo(self.ibo);

        // unit shell for clouds / atmosphere
        let (sv, si) = build_shell_mesh();
        self.shell_idx = si.len() as i32;
        unsafe {
            let mut id = 0u32;
            glGenBuffers(1, &mut id);
            self.shell_vbo = id;
            glBindBuffer(GL_ARRAY_BUFFER, id);
            glBufferData(GL_ARRAY_BUFFER, (sv.len() * 4) as isize, sv.as_ptr() as *const c_void, GL_STATIC_DRAW);
            let mut id2 = 0u32;
            glGenBuffers(1, &mut id2);
            self.shell_ibo = id2;
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id2);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, (si.len() * 2) as isize, si.as_ptr() as *const c_void, GL_STATIC_DRAW);
        }

        // stars
        let mut rng = Rng::new(12345);
        let n = self.star_count as usize;
        let mut st: Vec<f32> = Vec::with_capacity(n * 4);
        for _ in 0..n {
            let v = rng.unit_vec();
            let r = rng.uni();
            st.push(v.x as f32);
            st.push(v.y as f32);
            st.push(v.z as f32);
            st.push((r * r * r) as f32);
        }
        unsafe {
            let mut id = 0u32;
            glGenBuffers(1, &mut id);
            self.star_vbo = id;
            glBindBuffer(GL_ARRAY_BUFFER, id);
            glBufferData(GL_ARRAY_BUFFER, (st.len() * 4) as isize, st.as_ptr() as *const c_void, GL_STATIC_DRAW);
            let mut id3 = 0u32;
            glGenBuffers(1, &mut id3);
            self.city_vbo = id3;
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }
    }

    /// call once at the start of a frame; returns the frame time in seconds
    pub fn begin_frame(&mut self) -> f64 {
        let now = Instant::now();
        let dt = match self.last {
            Some(t) => now.duration_since(t).as_secs_f64().min(0.1),
            None => 0.016,
        };
        if self.last.is_some() {
            self.frame_ms = self.frame_ms * 0.9 + dt * 1000.0 * 0.1;
            self.fps = if self.frame_ms > 0.01 { 1000.0 / self.frame_ms } else { 0.0 };
        }
        self.last = Some(now);
        self.frame_no += 1;
        self.mgr.frame = self.frame_no;
        dt
    }

    pub fn draw_frame(&mut self, cam: &Camera, inp: &FrameInput) {
        if self.context_lost {
            self.mgr.hard_reset(inp.epoch, false);
            self.have_planet = false;
            self.context_lost = false;
        }
        if !inp.ready {
            unsafe {
                glClearColor(0.01, 0.01, 0.03, 1.0);
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            }
            return;
        }
        if !self.have_planet || inp.epoch != self.mgr.gen {
            self.mgr.radius_m = inp.radius_m;
            self.mgr.hard_reset(inp.epoch, true);
            self.radius = inp.radius_m;
            self.planet_radius = inp.radius_m;
            self.have_planet = true;
        }
        self.mgr.stamp = if layer_is_dynamic(inp.layer) { inp.stamp } else { inp.slow_stamp };
        self.mgr.layer = inp.layer;
        self.sun = inp.sun;
        self.radius = inp.radius_m;
        self.cam_x = cam.pos.x;
        self.cam_y = cam.pos.y;
        self.cam_z = cam.pos.z;
        self.cam_len = cam.pos_len;
        self.horizon_margin = 2.0 * self.radius * ((self.cam_len - self.radius).max(0.0) * 9500.0).sqrt();

        self.mgr.process_uploads(4_000_000u128);
        self.uploads_per_frame = self.mgr.uploads_this_frame;
        if let Some((buf, w, h)) = inp.cloud.as_ref() {
            self.upload_clouds(buf, *w, *h);
        }

        // sky
        let cd = cam.center_dir();
        let day_cam = cd.x * self.sun[0] + cd.y * self.sun[1] + cd.z * self.sun[2];
        let alt = cam.altitude;
        let sky_amt = 1.0 - smooth(30_000.0, 260_000.0, alt);
        let day_f = smooth(-0.12, 0.25, day_cam);
        let sr = (0.01 + 0.34 * day_f) * sky_amt;
        let sg = (0.012 + 0.55 * day_f) * sky_amt;
        let sb = (0.025 + 0.88 * day_f) * sky_amt;
        unsafe {
            glClearColor(sr as f32, sg as f32, sb as f32, 1.0);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        }
        self.draw_stars(cam, alt, day_f);

        // terrain
        self.visible.clear();
        self.refresh_budget = 6;
        for f in 0..6usize {
            let r = self.mgr.root(f);
            self.select(r, cam);
        }
        // the globe counts as ready only when all six root tiles exist (roots on the far side are culled by select())
        let mut rr = true;
        let mut rd = 0usize;
        for f in 0..6usize {
            let r = self.mgr.root(f);
            if !self.mgr.nodes[r].has_gpu {
                rr = false;
                let fno = self.frame_no;
                self.mgr.nodes[r].flags.wanted.store(fno, Ordering::SeqCst);
                self.mgr.request(r, 5.0e7 + (f as f64));
            } else {
                rd += 1;
            }
        }
        self.roots_ready = rr;
        self.roots_done = rd;
        self.draw_terrain(cam, alt);

        // shells
        unsafe {
            glEnable(GL_BLEND);
            glDepthMask(0);
        }
        self.draw_cities(cam, &inp.marks);
        self.draw_clouds(cam, alt);
        self.draw_atmosphere(cam, alt);
        unsafe {
            glDepthMask(1);
            glDisable(GL_BLEND);
        }
        self.mgr.evict();
        self.visible_chunks = self.visible.len();
        self.tris = self.visible.len() * (INDEX_COUNT / 3);
        self.draws = self.visible.len();
    }

    fn select(&mut self, idx: usize, cam: &Camera) {
        let r = self.radius;
        let (cx, cy, cz, crad, edge_m, level, has_gpu, state) = {
            let n = &self.mgr.nodes[idx];
            (n.cx, n.cy, n.cz, n.radius, n.edge_m, n.level, n.has_gpu, n.state)
        };
        let rx = cx * r - self.cam_x;
        let ry = cy * r - self.cam_y;
        let rz = cz * r - self.cam_z;
        if !cam.sphere_visible(rx, ry, rz, crad) {
            return;
        }
        let dotc = (cx * self.cam_x + cy * self.cam_y + cz * self.cam_z) * r;
        if dotc + crad * self.cam_len < r * r - self.horizon_margin {
            return;
        }
        let fno = self.frame_no;
        {
            let n = &mut self.mgr.nodes[idx];
            n.last_used = fno;
            n.flags.wanted.store(fno, Ordering::SeqCst);
        }
        let dist = (rx * rx + ry * ry + rz * rz).sqrt();
        let d = (dist - crad * 0.55).max(1.0);
        let tex_px = (edge_m / (KT as f64)) / d * cam.focal_px;
        if level < MAX_LEVEL_USED && tex_px > SPLIT_PX {
            let mut all_ready = true;
            let mut kids = [0usize; 4];
            for i in 0..4usize {
                let k = self.mgr.child(idx, i);
                kids[i] = k;
                if !self.mgr.nodes[k].has_gpu {
                    all_ready = false;
                    self.mgr.request(k, ((level + 1) as f64) * 1.0e9 + dist);
                }
            }
            if all_ready {
                for i in 0..4usize {
                    self.select(kids[i], cam);
                }
                return;
            }
        }
        if has_gpu {
            self.visible.push(idx);
            if self.refresh_budget > 0 && state == 0 && self.mgr.is_stale(idx) {
                self.mgr.request(idx, (level as f64) * 1.0e9 + dist);
                self.refresh_budget -= 1;
            }
        } else {
            self.mgr.request(idx, (level as f64) * 1.0e9 + dist);
        }
    }

    fn draw_terrain(&mut self, cam: &Camera, alt: f64) {
        if self.prog_terrain == 0 {
            return;
        }
        let u = self.u_t;
        let r = self.radius;
        unsafe {
            glUseProgram(self.prog_terrain);
            glUniformMatrix4fv(u[0], 1, 0, cam.vp.as_ptr());
            glUniform3f(u[4], self.sun[0] as f32, self.sun[1] as f32, self.sun[2] as f32);
            glUniform1f(u[5], 5.0e-7);
            let haze_amt = 1.0 - smooth(600_000.0, 2_500_000.0, alt);
            glUniform1f(u[6], haze_amt as f32);
            glUniform3f(u[7], 0.55, 0.72, 0.95);
            glUniform1f(u[8], KT as f32);
            glUniform1f(u[9], KD as f32);
            glUniform1i(u[10], 0);
            glUniform1i(u[11], 1);
            for vi in 0..self.visible.len() {
                let n = &self.mgr.nodes[self.visible[vi]];
                glUniform3f(u[1], (n.cx * r - self.cam_x) as f32, (n.cy * r - self.cam_y) as f32, (n.cz * r - self.cam_z) as f32);
                glUniform3f(u[2], (n.cx * r) as f32, (n.cy * r) as f32, (n.cz * r) as f32);
                let (_nv, t1, _t2) = face_axes(n.face);
                glUniform3f(u[3], t1.x as f32, t1.y as f32, t1.z as f32);
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, n.tex_a);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, n.tex_n);
                glBindVertexArray(n.vao);
                glDrawElements(GL_TRIANGLES, INDEX_COUNT as i32, GL_UNSIGNED_SHORT, std::ptr::null());
            }
            glBindVertexArray(0);
            glActiveTexture(GL_TEXTURE0);
        }
    }

    /// city markers: warm dots on the day side, glowing lights on the night side
    fn draw_cities(&mut self, cam: &Camera, marks: &[CityMark]) {
        if self.prog_city == 0 || marks.is_empty() {
            return;
        }
        let r = self.radius;
        let mut data: Vec<f32> = Vec::with_capacity(marks.len() * 8);
        let mut n = 0i32;
        for m in marks.iter() {
            let cosang = m.dir.x * self.cam_x + m.dir.y * self.cam_y + m.dir.z * self.cam_z;
            if cosang < r * 0.9995 {
                continue; // below the horizon
            }
            let rad = r + (m.h as f64);
            data.push((m.dir.x * rad - self.cam_x) as f32);
            data.push((m.dir.y * rad - self.cam_y) as f32);
            data.push((m.dir.z * rad - self.cam_z) as f32);
            data.push(m.size);
            data.push(m.dir.x as f32);
            data.push(m.dir.y as f32);
            data.push(m.dir.z as f32);
            data.push(0.0);
            n += 1;
        }
        if n == 0 {
            return;
        }
        let u = self.u_city;
        let scale = clampv(cam.focal_px / 1400.0, 0.8, 2.0) as f32;
        unsafe {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glUseProgram(self.prog_city);
            glUniformMatrix4fv(u[0], 1, 0, cam.vp.as_ptr());
            glUniform3f(u[1], self.sun[0] as f32, self.sun[1] as f32, self.sun[2] as f32);
            glUniform1f(u[2], scale);
            glBindBuffer(GL_ARRAY_BUFFER, self.city_vbo);
            glBufferData(GL_ARRAY_BUFFER, (data.len() * 4) as isize, data.as_ptr() as *const c_void, GL_DYNAMIC_DRAW);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 4, GL_FLOAT, 0, 32, std::ptr::null());
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 4, GL_FLOAT, 0, 32, 16usize as *const c_void);
            glDrawArrays(GL_POINTS, 0, n);
            glDisableVertexAttribArray(0);
            glDisableVertexAttribArray(1);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }
    }

    fn draw_stars(&mut self, cam: &Camera, alt: f64, day_f: f64) {
        if self.prog_star == 0 {
            return;
        }
        let a = clampv(1.0 - day_f * (1.0 - smooth(40_000.0, 500_000.0, alt)), 0.0, 1.0);
        if a < 0.02 {
            return;
        }
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glUseProgram(self.prog_star);
            glUniformMatrix4fv(self.u_s[0], 1, 0, cam.vp.as_ptr());
            glUniform1f(self.u_s[1], a as f32);
            glBindBuffer(GL_ARRAY_BUFFER, self.star_vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 4, GL_FLOAT, 0, 16, std::ptr::null());
            glDrawArrays(GL_POINTS, 0, self.star_count);
            glDisableVertexAttribArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glDisable(GL_BLEND);
            glEnable(GL_DEPTH_TEST);
        }
    }

    fn draw_shell(&self) {
        unsafe {
            glBindBuffer(GL_ARRAY_BUFFER, self.shell_vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, 0, 12, std::ptr::null());
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.shell_ibo);
            glDrawElements(GL_TRIANGLES, self.shell_idx, GL_UNSIGNED_SHORT, std::ptr::null());
            glDisableVertexAttribArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }
    }

    fn draw_clouds(&mut self, cam: &Camera, alt: f64) {
        if self.prog_cloud == 0 || !self.clouds_ready {
            return;
        }
        let a = smooth(25_000.0, 160_000.0, alt);
        if a < 0.01 {
            return;
        }
        self.cloud_shift += 0.00002;
        let u = self.u_c;
        unsafe {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glUseProgram(self.prog_cloud);
            glUniformMatrix4fv(u[0], 1, 0, cam.vp.as_ptr());
            glUniform3f(u[1], (-self.cam_x) as f32, (-self.cam_y) as f32, (-self.cam_z) as f32);
            glUniform1f(u[2], (self.radius + 12_000.0) as f32);
            glUniform1i(u[3], 0);
            glUniform3f(u[4], self.sun[0] as f32, self.sun[1] as f32, self.sun[2] as f32);
            glUniform1f(u[5], (0.88 * a) as f32);
            glUniform1f(u[6], self.cloud_shift);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, self.cloud_tex);
        }
        self.draw_shell();
    }

    fn draw_atmosphere(&mut self, cam: &Camera, alt: f64) {
        if self.prog_atmo == 0 {
            return;
        }
        let a = smooth(120_000.0, 700_000.0, alt);
        if a < 0.01 {
            return;
        }
        let u = self.u_a;
        unsafe {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glUseProgram(self.prog_atmo);
            glUniformMatrix4fv(u[0], 1, 0, cam.vp.as_ptr());
            glUniform3f(u[1], (-self.cam_x) as f32, (-self.cam_y) as f32, (-self.cam_z) as f32);
            glUniform1f(u[2], (self.radius + 100_000.0) as f32);
            glUniform3f(u[3], self.sun[0] as f32, self.sun[1] as f32, self.sun[2] as f32);
            glUniform1f(u[4], a as f32);
        }
        self.draw_shell();
    }

    fn upload_clouds(&mut self, buf: &Vec<u8>, w: i32, h: i32) {
        if (buf.len() as i32) < w * h {
            return;
        }
        unsafe {
            if self.cloud_tex == 0 {
                let mut id = 0u32;
                glGenTextures(1, &mut id);
                self.cloud_tex = id;
                glBindTexture(GL_TEXTURE_2D, id);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR as i32);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR as i32);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT as i32);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE as i32);
            }
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, self.cloud_tex);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_R8 as i32, w, h, 0, GL_RED, GL_UNSIGNED_BYTE, buf.as_ptr() as *const c_void);
        }
        self.clouds_ready = true;
    }

    pub fn shutdown(&mut self) {
        self.mgr.shutdown();
    }
}
