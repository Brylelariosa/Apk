//! JNI exports (hand-written, no external crates). The JNI function-table indices below were verified
//! against a real JVM: NewStringUTF 167, GetStringUTFChars 169, ReleaseStringUTFChars 170,
//! GetArrayLength 171, NewDoubleArray 182, GetDoubleArrayRegion 206, SetDoubleArrayRegion 214.

use crate::app::*;
use crate::gl::log;
use crate::params::*;
use crate::world::lk;
use std::ffi::{c_void, CStr, CString};
use std::os::raw::c_char;
use std::sync::atomic::Ordering;
use std::sync::Mutex;

type JEnv = *mut c_void;
type JObj = *mut c_void;

const JNI_NEW_STRING_UTF: usize = 167;
const JNI_GET_STRING_UTF_CHARS: usize = 169;
const JNI_RELEASE_STRING_UTF_CHARS: usize = 170;
const JNI_GET_DOUBLE_ARRAY_REGION: usize = 206;
const JNI_SET_DOUBLE_ARRAY_REGION: usize = 214;

static CRASH_PATH: Mutex<String> = Mutex::new(String::new());

unsafe fn fn_ptr(env: JEnv, idx: usize) -> *const c_void {
    let table = *(env as *const *const *const c_void);
    *table.add(idx)
}

unsafe fn new_jstring(env: JEnv, s: &str) -> JObj {
    let clean: String = s.chars().map(|c| if c == '\0' { ' ' } else { c }).collect();
    let c = match CString::new(clean) {
        Ok(c) => c,
        Err(_) => CString::new("").unwrap_or_default(),
    };
    let f: extern "C" fn(JEnv, *const c_char) -> JObj = std::mem::transmute(fn_ptr(env, JNI_NEW_STRING_UTF));
    f(env, c.as_ptr())
}

unsafe fn rust_string(env: JEnv, s: JObj) -> String {
    if s.is_null() {
        return String::new();
    }
    let get: extern "C" fn(JEnv, JObj, *mut u8) -> *const c_char = std::mem::transmute(fn_ptr(env, JNI_GET_STRING_UTF_CHARS));
    let rel: extern "C" fn(JEnv, JObj, *const c_char) = std::mem::transmute(fn_ptr(env, JNI_RELEASE_STRING_UTF_CHARS));
    let p = get(env, s, std::ptr::null_mut());
    if p.is_null() {
        return String::new();
    }
    let r = CStr::from_ptr(p).to_string_lossy().to_string();
    rel(env, s, p);
    r
}

unsafe fn read_doubles(env: JEnv, arr: JObj, n: usize) -> Vec<f64> {
    let mut v = vec![0.0f64; n];
    if arr.is_null() {
        return v;
    }
    let f: extern "C" fn(JEnv, JObj, i32, i32, *mut f64) = std::mem::transmute(fn_ptr(env, JNI_GET_DOUBLE_ARRAY_REGION));
    f(env, arr, 0, n as i32, v.as_mut_ptr());
    v
}

unsafe fn write_doubles(env: JEnv, arr: JObj, v: &[f64]) {
    if arr.is_null() {
        return;
    }
    let f: extern "C" fn(JEnv, JObj, i32, i32, *const f64) = std::mem::transmute(fn_ptr(env, JNI_SET_DOUBLE_ARRAY_REGION));
    f(env, arr, 0, v.len() as i32, v.as_ptr());
}

fn append_crash(text: &str) {
    use std::io::Write;
    let p = lk(&CRASH_PATH).clone();
    if p.is_empty() {
        return;
    }
    if let Ok(md) = std::fs::metadata(&p) {
        if md.len() > 60_000 {
            return;
        }
    }
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(&p) {
        let _ = f.write_all(text.as_bytes());
    }
}

fn install_panic_hook() {
    std::panic::set_hook(Box::new(|info| {
        let thread = std::thread::current();
        let name = thread.name().unwrap_or("?").to_string();
        let loc = match info.location() {
            Some(l) => format!("{}:{}", l.file(), l.line()),
            None => String::from("?"),
        };
        let payload = info.payload();
        let msg = if let Some(s) = payload.downcast_ref::<&str>() {
            s.to_string()
        } else if let Some(s) = payload.downcast_ref::<String>() {
            s.clone()
        } else {
            String::from("panic")
        };
        let text = format!("Rust panic in thread '{}' at {}: {}\n", name, loc, msg);
        log(&text);
        append_crash(&text);
    }));
}

macro_rules! guarded {
    ($default:expr, $body:block) => {
        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| $body)) {
            Ok(v) => v,
            Err(_) => $default,
        }
    };
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nInit(env: JEnv, _this: JObj, files_dir: JObj) {
    guarded!((), {
        let dir = unsafe { rust_string(env, files_dir) };
        if !dir.is_empty() {
            *lk(&CRASH_PATH) = format!("{}/crash.log", dir);
        }
        install_panic_hook();
        let _ = app_init();
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nGenerate(env: JEnv, _this: JObj, seed: JObj, params: JObj) {
    guarded!((), {
        let s = unsafe { rust_string(env, seed) };
        let p = unsafe { read_doubles(env, params, PARAM_COUNT) };
        if let Some(a) = app() {
            // flip the flags immediately so the UI never flashes a stale "ready" state
            a.busy.store(true, Ordering::SeqCst);
            a.ready.store(false, Ordering::SeqCst);
            a.send(Cmd::Generate(s, p));
        }
    })
}

/// climate-only change (keeps continents and people); falls back to a full regeneration if terrain settings differ
#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nRetune(env: JEnv, _this: JObj, params: JObj) {
    guarded!((), {
        let p = unsafe { read_doubles(env, params, PARAM_COUNT) };
        if let Some(a) = app() {
            a.busy.store(true, Ordering::SeqCst);
            a.send(Cmd::Retune(p));
        }
    })
}

/// put settlers on the land at the given latitude / longitude (degrees)
#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSettle(_env: JEnv, _this: JObj, lat: f64, lon: f64) {
    guarded!((), {
        if let Some(a) = app() {
            a.send(Cmd::Settle(lat, lon));
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSetRunning(_env: JEnv, _this: JObj, on: u8) {
    guarded!((), {
        if let Some(a) = app() {
            a.running.store(on != 0, Ordering::SeqCst);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSetSpeed(_env: JEnv, _this: JObj, years_per_second: f64) {
    guarded!((), {
        if let Some(a) = app() {
            a.speed_bits.store(years_per_second.to_bits(), Ordering::SeqCst);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nStep(_env: JEnv, _this: JObj, years: f64) {
    guarded!((), {
        if let Some(a) = app() {
            a.send(Cmd::Step(years));
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nShiftHours(_env: JEnv, _this: JObj, hours: f64) {
    guarded!((), {
        if let Some(a) = app() {
            a.send(Cmd::ShiftHours(hours));
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSetLayer(_env: JEnv, _this: JObj, layer: i32) {
    guarded!((), {
        if let Some(a) = app() {
            a.layer.store(layer, Ordering::SeqCst);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nResetView(_env: JEnv, _this: JObj) {
    guarded!((), {
        if let Some(a) = app() {
            a.reset_view();
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nDefaultParams(env: JEnv, _this: JObj, out: JObj) {
    guarded!((), {
        let a = PlanetParams::default().to_array();
        unsafe { write_doubles(env, out, &a) };
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSurfaceCreated(_env: JEnv, _this: JObj) {
    guarded!((), {
        if let Some(a) = app() {
            a.on_surface_created();
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nSurfaceChanged(_env: JEnv, _this: JObj, w: i32, h: i32) {
    guarded!((), {
        if let Some(a) = app() {
            a.on_surface_changed(w, h);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nDrawFrame(_env: JEnv, _this: JObj) {
    guarded!((), {
        if let Some(a) = app() {
            a.on_draw();
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nTouch(
    _env: JEnv,
    _this: JObj,
    action: i32,
    n: i32,
    x0: f64,
    y0: f64,
    x1: f64,
    y1: f64,
    time_ms: i64,
) {
    guarded!((), {
        if let Some(a) = app() {
            a.on_touch(action, n, x0, y0, x1, y1, time_ms);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nGetState(env: JEnv, _this: JObj, out: JObj) {
    guarded!((), {
        let mut buf = vec![0.0f64; STATE_LEN];
        if let Some(a) = app() {
            a.fill_state(&mut buf);
        }
        unsafe { write_doubles(env, out, &buf) };
    })
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nString(env: JEnv, _this: JObj, which: i32) -> JObj {
    let text: String = guarded!(String::new(), {
        match app() {
            Some(a) => a.text(which),
            None => String::new(),
        }
    });
    unsafe { new_jstring(env, &text) }
}

#[no_mangle]
pub extern "system" fn Java_com_livingworld_simulator_Native_nTakeCrash(env: JEnv, _this: JObj) -> JObj {
    let text: String = guarded!(String::new(), {
        let p = lk(&CRASH_PATH).clone();
        if p.is_empty() {
            String::new()
        } else {
            let t = std::fs::read_to_string(&p).unwrap_or_default();
            let _ = std::fs::remove_file(&p);
            t
        }
    });
    unsafe { new_jstring(env, &text) }
}
