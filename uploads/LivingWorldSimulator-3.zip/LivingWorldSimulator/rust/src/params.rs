//! Central planet parameters. Every system reads from here (via Derived) so
//! changing a parameter genuinely changes the simulation.

use crate::mathx::*;

#[derive(Clone, Debug)]
pub struct PlanetParams {
    pub radius_km: f64,
    pub gravity: f64,         // m/s^2
    pub rotation_hours: f64,  // length of one local solar day
    pub orbit_days: f64,      // orbital period in 24 h days
    pub axial_tilt_deg: f64,
    pub eccentricity: f64,
    pub solar_intensity: f64, // x 1361 W/m^2
    pub pressure_atm: f64,    // surface pressure
    pub ocean_fraction: f64,  // fraction of surface below sea level
    pub sea_level_offset_m: f64,
    pub n2: f64,
    pub o2: f64,
    pub ar: f64,
    pub co2ppm: f64,
    pub salinity_psu: f64,
    pub geothermal: f64,      // x Earth (plate speed, volcanism, uplift)
}

pub const PARAM_COUNT: usize = 12;

impl Default for PlanetParams {
    fn default() -> PlanetParams {
        PlanetParams {
            radius_km: 6371.0,
            gravity: 9.80665,
            rotation_hours: 24.0,
            orbit_days: 365.25,
            axial_tilt_deg: 23.44,
            eccentricity: 0.0167,
            solar_intensity: 1.0,
            pressure_atm: 1.0,
            ocean_fraction: 0.71,
            sea_level_offset_m: 0.0,
            n2: 0.7808,
            o2: 0.2095,
            ar: 0.0093,
            co2ppm: 420.0,
            salinity_psu: 35.0,
            geothermal: 1.0,
        }
    }
}

impl PlanetParams {
    /// flat view used by the UI (index order is stable)
    pub fn to_array(&self) -> [f64; PARAM_COUNT] {
        [
            self.radius_km,
            self.gravity,
            self.rotation_hours,
            self.orbit_days,
            self.axial_tilt_deg,
            self.solar_intensity,
            self.pressure_atm,
            self.ocean_fraction,
            self.co2ppm,
            self.salinity_psu,
            self.geothermal,
            self.sea_level_offset_m,
        ]
    }
    pub fn from_array(&mut self, a: &[f64]) {
        if a.len() < PARAM_COUNT {
            return;
        }
        self.radius_km = a[0];
        self.gravity = a[1];
        self.rotation_hours = a[2];
        self.orbit_days = a[3];
        self.axial_tilt_deg = a[4];
        self.solar_intensity = a[5];
        self.pressure_atm = a[6];
        self.ocean_fraction = a[7];
        self.co2ppm = a[8];
        self.salinity_psu = a[9];
        self.geothermal = a[10];
        self.sea_level_offset_m = a[11];
    }
    pub fn sanitize(&mut self) {
        self.radius_km = clampv(self.radius_km, 1500.0, 20000.0);
        self.gravity = clampv(self.gravity, 2.0, 40.0);
        self.rotation_hours = clampv(self.rotation_hours, 4.0, 2000.0);
        self.orbit_days = clampv(self.orbit_days, 30.0, 20000.0);
        self.axial_tilt_deg = clampv(self.axial_tilt_deg, 0.0, 85.0);
        self.eccentricity = clampv(self.eccentricity, 0.0, 0.3);
        self.solar_intensity = clampv(self.solar_intensity, 0.4, 1.8);
        self.pressure_atm = clampv(self.pressure_atm, 0.2, 5.0);
        self.ocean_fraction = clampv(self.ocean_fraction, 0.1, 0.97);
        self.sea_level_offset_m = clampv(self.sea_level_offset_m, -300.0, 300.0);
        self.co2ppm = clampv(self.co2ppm, 50.0, 20000.0);
        self.salinity_psu = clampv(self.salinity_psu, 0.0, 60.0);
        self.geothermal = clampv(self.geothermal, 0.2, 4.0);
    }
}

#[derive(Clone, Debug)]
pub struct Derived {
    pub r: f64,                  // m
    pub g: f64,
    pub omega: f64,              // rad/s
    pub day_hours: f64,
    pub year_days: f64,          // 24 h days
    pub solar_days_per_year: f64,
    pub s0: f64,                 // W/m^2
    pub tilt: f64,               // rad
    pub ecc: f64,
    pub p0: f64,                 // Pa
    pub rspec: f64,              // J/kg/K
    pub cp: f64,
    pub lapse: f64,              // environmental lapse rate K/m
    pub col_mass: f64,           // kg/m^2
    pub ca: f64,                 // atmospheric column heat capacity J/m^2/K
    pub hscale: f64,             // m
    pub olr_a: f64,              // W/m^2 (linearised OLR = A + B*T_C)
    pub olr_b: f64,
    pub diff_d: f64,             // W/m^2/K meridional eddy transport
    pub hadley_deg: f64,         // poleward edge of the Hadley cell
    pub max_relief_m: f64,       // gravity-limited mountain height
    pub t_freeze_k: f64,         // sea water freezing point
    pub cocean: f64,             // mixed layer heat capacity
    pub plate_scale: f64,
    pub cont_fraction: f64,      // continental crust area fraction
    pub vapor_scale: f64,        // column vapour scale (gravity dependent)
    pub f_cor0: f64,             // 2*Omega
    pub press_scale: f64,
    pub geo_scale: f64,
}

impl Default for Derived {
    fn default() -> Derived {
        Derived {
            r: 6.371e6,
            g: 9.80665,
            omega: 7.2921e-5,
            day_hours: 24.0,
            year_days: 365.25,
            solar_days_per_year: 365.25,
            s0: 1361.0,
            tilt: 0.4091,
            ecc: 0.0167,
            p0: 101325.0,
            rspec: 287.0,
            cp: 1004.0,
            lapse: 0.0065,
            col_mass: 10330.0,
            ca: 1.0e7,
            hscale: 7300.0,
            olr_a: 203.3,
            olr_b: 2.09,
            diff_d: 0.65,
            hadley_deg: 30.0,
            max_relief_m: 9500.0,
            t_freeze_k: 271.23,
            cocean: 2.5e8,
            plate_scale: 1.0,
            cont_fraction: 0.40,
            vapor_scale: 1.0,
            f_cor0: 1.4584e-4,
            press_scale: 1.0,
            geo_scale: 1.0,
        }
    }
}

pub fn derive(p: &PlanetParams) -> Derived {
    let mut d = Derived::default();
    let g0 = 9.80665;
    let om0 = 7.2921e-5;
    let r0 = 6.371e6;
    d.r = p.radius_km * 1000.0;
    d.g = p.gravity;
    d.omega = TAU / (p.rotation_hours * 3600.0);
    d.day_hours = p.rotation_hours;
    d.year_days = p.orbit_days;
    d.solar_days_per_year = p.orbit_days * 24.0 / p.rotation_hours;
    d.s0 = 1361.0 * p.solar_intensity;
    d.tilt = p.axial_tilt_deg * DEG2RAD;
    d.ecc = p.eccentricity;
    d.p0 = 101325.0 * p.pressure_atm;
    let tot = p.n2 + p.o2 + p.ar + p.co2ppm * 1e-6;
    let m = (p.n2 * 28.013 + p.o2 * 31.999 + p.ar * 39.948 + p.co2ppm * 1e-6 * 44.01) / (if tot > 0.0 { tot } else { 1.0 });
    d.rspec = 8.314462 / (m * 1e-3);
    d.cp = 1004.0;
    d.lapse = 0.665 * p.gravity / d.cp;
    d.col_mass = d.p0 / d.g;
    d.ca = d.cp * d.col_mass;
    d.hscale = d.rspec * 250.0 / d.g;
    // greenhouse: CO2 forcing 5.35 ln(C/C0) and a weak pressure-broadening term
    d.olr_a = 203.3 + 5.0 - 5.35 * dlog(p.co2ppm / 340.0) - 4.0 * dlog((0.05f64).max(p.pressure_atm));
    d.olr_b = 2.09;
    let dd = 0.65 * p.pressure_atm * (g0 / p.gravity) * sqr(r0 / d.r) * (om0 / d.omega);
    d.diff_d = clampv(dd, 0.15, 2.5);
    let hd = 30.0 * (om0 * r0) / (d.omega * d.r) * (d.rspec / 287.0).sqrt();
    d.hadley_deg = clampv(hd, 9.0, 80.0);
    d.max_relief_m = 9500.0 * (g0 / p.gravity);
    let s = p.salinity_psu;
    d.t_freeze_k = 273.15 + (-0.0575 * s + 1.710523e-3 * s * s.sqrt() - 2.154996e-4 * s * s);
    d.cocean = 2.5e8;
    d.plate_scale = p.geothermal.sqrt();
    d.geo_scale = p.geothermal;
    d.cont_fraction = clampv((1.0 - p.ocean_fraction) + 0.11, 0.15, 0.95);
    d.vapor_scale = g0 / p.gravity;
    d.f_cor0 = 2.0 * d.omega;
    d.press_scale = p.pressure_atm;
    d
}
