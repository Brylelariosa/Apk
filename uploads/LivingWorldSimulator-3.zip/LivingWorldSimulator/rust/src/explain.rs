//! "Why is this here?" - walks the simulation's actual cause-and-effect data for a location.

use crate::biome::*;
use crate::mathx::*;
use crate::sampler::*;
use crate::world::*;
use crate::world_data::*;

fn annual_wind(s: &Sampler, p: V3) -> (f64, f64) {
    let (ids, w) = s.cg.locate(p);
    let sl = s.s.sl();
    let n = s.cg.count;
    let mut u = 0.0f64;
    let mut v = 0.0f64;
    for m in 0..NSLICE {
        for k in 0..4usize {
            u += (w[k] * sl.wu[m * n + ids[k]]) as f64;
            v += (w[k] * sl.wv[m * n + ids[k]]) as f64;
        }
    }
    (u / (NSLICE as f64), v / (NSLICE as f64))
}

fn compass(from_deg: f64) -> &'static str {
    const C: [&str; 8] = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"];
    C[(((from_deg + 22.5) / 45.0) as usize) % 8]
}

fn dir8(from_deg: f64) -> &'static str {
    const C: [&str; 8] = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    C[(((from_deg + 22.5) / 45.0) as usize) % 8]
}

pub fn height_at_lat_lon(v: &View, lat_deg: f64, lon_deg: f64) -> f64 {
    let s = Sampler::new(v);
    let p = from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD);
    let mut h = s.height(p, 30.0);
    let ll = s.fg.sample(&s.h.lake_level, p) as f64;
    if ll > h + 0.5 && ll > 0.5 {
        h = ll;
    }
    h.max(0.0)
}

pub fn inspect_text(v: &View, lat_deg: f64, lon_deg: f64) -> String {
    let s = Sampler::new(v);
    let p = from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD);
    let h = s.height(p, 60.0);
    let fc = s.fg.cell_of(p);
    let ocean = h <= 0.0;
    let zm = s.cg.sample(&s.s.st().z_mean, p) as f64;
    let mut tcur = (s.cur(&s.d.ta, p) as f64) - 273.15 - (if ocean { 0.0 } else { s.gam * (h - zm) });
    if ocean {
        tcur = (s.cur(&s.d.ts, p) as f64) - 273.15;
    }
    let wu = s.cur(&s.d.wu, p) as f64;
    let wv = s.cur(&s.d.wv, p) as f64;
    let sp = (wu * wu + wv * wv).sqrt();
    let dir_from = (datan2(-wu, -wv) * RAD2DEG + 360.0) % 360.0;
    let cdir = dir8(dir_from);
    let fr = s.s.tect.make_frame(s.s.tect_time_myr);
    let ts = s.s.tect.sample(&fr, p);
    const BT: [&str; 4] = ["interior", "convergent", "divergent", "transform"];
    let mut out = String::new();
    out.push_str(&format!(
        "{:.2}{} {:.2}{}\n",
        lat_deg.abs(),
        if lat_deg >= 0.0 { 'N' } else { 'S' },
        lon_deg.abs(),
        if lon_deg >= 0.0 { 'E' } else { 'W' }
    ));
    if ocean {
        out.push_str(&format!("Ocean depth {:.0} m\n", -h));
    } else {
        out.push_str(&format!("Elevation {:.0} m\n", h));
    }
    out.push_str(&format!("Temp {:.1} C (annual {:.1})\n", tcur, s.fg.sample(&s.e.t_ann, p)));
    out.push_str(&format!("Rain {:.0} mm/yr (now {:.1} mm/d)\n", s.fg.sample(&s.e.p_ann, p), s.cur(&s.d.precip, p)));
    out.push_str(&format!("Biome {}\n", if ocean { "Ocean" } else { biome_name(s.e.biome[fc] as i32) }));
    out.push_str(&format!("Fertility {:.2}  Moisture {:.2}\n", s.e.fertility[fc], s.e.soil_moist[fc]));
    out.push_str(&format!("Wind {:.1} m/s from {}  Pres {:.0} hPa\n", sp, cdir, s.cur(&s.d.pres, p)));
    out.push_str(&format!("Plate {} / {}  {} {:.0} km ({:.1} cm/yr)\n", ts.plate, ts.other, BT[(ts.kind as usize) & 3], ts.dist_km, ts.conv));
    if !ocean && s.h.discharge[fc] > 1.0 {
        out.push_str(&format!("River {:.0} m3/s\n", s.h.discharge[fc]));
    }
    out
}

pub fn explain_text(v: &View, lat_deg: f64, lon_deg: f64) -> String {
    let s = Sampler::new(v);
    let rkm = s.rm / 1000.0;
    let p = from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD);
    let fc = s.fg.cell_of(p);
    let h = s.height(p, 80.0);
    let t = s.t;
    let e = s.e;
    let hy = s.h;
    let mut out = String::new();
    let fr = s.s.tect.make_frame(s.s.tect_time_myr);
    let ts = s.s.tect.sample(&fr, p);

    if h <= 0.0 {
        out.push_str(&format!("OCEAN, {:.0} m deep.\n", -h));
        let age = s.fg.sample(&t.crust_age, p);
        out.push_str(&format!(
            "Depth: oceanic crust ~{:.0} Myr old. New crust forms hot and high at spreading ridges, then cools and sinks as it drifts away.\n",
            age
        ));
        if t.btype[fc] == 1 && t.bdist[fc] < 250.0 {
            out.push_str(&format!(
                "A subduction trench: plate {} dives under plate {} here ({:.1} cm/yr), pulling the seafloor down.\n",
                ts.plate, ts.other, ts.conv
            ));
        } else if t.btype[fc] == 2 && t.bdist[fc] < 300.0 {
            out.push_str(&format!(
                "Mid-ocean ridge: plates {} and {} spread apart at {:.1} cm/yr and new crust wells up.\n",
                ts.plate, ts.other, -ts.conv
            ));
        } else if t.sediment[fc] > 30.0 {
            out.push_str(&format!("Continental shelf: river sediment ({:.0} m) has built a shallow shelf.\n", t.sediment[fc]));
        }
        let cc = s.cg.cell_of(p);
        let cu = s.s.st().cu[cc] as f64;
        let cv = s.s.st().cv[cc] as f64;
        let sp = (cu * cu + cv * cv).sqrt();
        let sst = if s.s.sl().ts.is_empty() { 0.0 } else { (s.cur(&s.d.ts, p) as f64) - 273.15 };
        out.push_str(&format!(
            "Surface water {:.1} C. Wind-driven gyre current {:.2} m/s{}.\n",
            sst,
            sp,
            if s.s.st().upwell[cc] > 2e-7 { "; upwelling brings cold deep water here" } else { "" }
        ));
        return out;
    }

    // ---------------- land ----------------
    let bi = e.biome[fc] as i32;
    out.push_str(&format!("{} at {:.0} m.\n", biome_name(bi), h));
    let orog = t.orogeny[fc] as f64;
    let volc = t.volcanism[fc] as f64;
    if orog > 0.25 && h > 700.0 {
        if ts.kind == 1 && ts.dist_km < 700.0 {
            out.push_str(&format!(
                "MOUNTAINS: plates {} and {} are closing at {:.1} cm/yr, {:.0} km from here. Crust crumples, thickens and floats high (isostasy); erosion carves it.\n",
                ts.plate, ts.other, ts.conv, ts.dist_km
            ));
        } else {
            out.push_str(&format!(
                "MOUNTAINS: an old collision belt from an earlier plate boundary, now carried inland by plate {} and worn down by erosion.\n",
                ts.plate
            ));
        }
    } else if volc > 0.35 {
        let why = if t.btype[fc] == 1 {
            "magma from the subducting plate rises through the overriding plate (volcanic arc).".to_string()
        } else if t.btype[fc] == 2 {
            "rifting crust lets magma reach the surface.".to_string()
        } else {
            format!("a mantle hotspot under plate {} builds volcanoes.", ts.plate)
        };
        out.push_str(&format!("VOLCANIC: {}\n", why));
    } else if h < 250.0 {
        out.push_str(&format!(
            "LOWLAND: {}\n",
            if t.sediment[fc] > 40.0 {
                "sediment eroded from uplands has been dumped here, building a flat plain."
            } else {
                "stable crust far from active plate boundaries."
            }
        ));
    } else {
        out.push_str("UPLAND: continental crust lifted by plate motion and shaped by river erosion.\n");
    }
    // river chain
    let q = hy.discharge[fc] as f64;
    if q > 5.0 {
        let mut cur = fc as i32;
        let mut steps = 0i32;
        while cur >= 0 && t.height[cur as usize] > 0.0 && steps < 4000 {
            let r = hy.rec[cur as usize];
            if r < 0 || t.height[r as usize] <= 0.0 {
                break;
            }
            cur = r;
            steps += 1;
        }
        let cu = if cur >= 0 { cur as usize } else { fc };
        let to_sea = hy.rec[cu] >= 0 && t.height[hy.rec[cu] as usize] <= 0.0;
        let drop_m = (0.0f64).max(h - (0.0f64).max(t.height[cu] as f64));
        out.push_str(&format!(
            "RIVER {:.0} m3/s: gathers rain and snowmelt from its whole watershed (local runoff {:.0} mm/yr, {:.0}% of the flow is snowmelt) and runs downhill ~{:.0} km, losing {:.0} m of height, {}.\n",
            q,
            hy.runoff[fc] as f64,
            100.0 * (hy.snowmelt_frac[fc] as f64),
            (steps as f64) * 52.0,
            drop_m,
            if to_sea { "to the ocean" } else { "into a closed basin or lake" }
        ));
    }
    if hy.lake_depth[fc] > 8.0 {
        out.push_str(&format!(
            "LAKE: a basin {:.0} m deep fills from inflowing rivers; {}\n",
            hy.lake_depth[fc],
            if hy.lake_kind[fc] == 1 {
                "it overflows at the lowest rim, feeding a river."
            } else if hy.lake_kind[fc] == 3 {
                "evaporation exceeds inflow so only a salt flat remains."
            } else {
                "it has no outlet, so evaporation sets its level."
            }
        ));
    }
    // climate chain
    let t_ann = e.t_ann[fc] as f64;
    let p_ann = e.p_ann[fc] as f64;
    let ai = e.aridity[fc] as f64;
    out.push_str(&format!("Climate: {:.1} C mean, {:.0} mm/yr rain, aridity index {:.2} (rain / evaporation demand).\n", t_ann, p_ann, ai));
    let itcz_idx = clampv((lon_deg + 180.0) / 10.0, 0.0, 35.0) as usize;
    if ai < 0.30 {
        // trace the moisture source upwind
        let (wu, wv) = annual_wind(&s, p);
        let sp = (wu * wu + wv * wv).sqrt();
        if sp < 0.3 {
            out.push_str("DRY: air is nearly still here, so little moisture arrives.\n");
        } else {
            let toward = datan2(wu, wv); // direction the wind blows towards (from north, clockwise)
            let from = (toward * RAD2DEG + 180.0) % 360.0;
            let (ev, nv) = east_north(p);
            let mut dir_up = ev * (-wu / sp) + nv * (-wv / sp);
            let mut q2 = p;
            let mut ridge = 0.0f64;
            let mut ridge_at = 0.0f64;
            let mut ocean_at = -1.0f64;
            for st in 1..=30i32 {
                let a = 100.0 / rkm;
                let tdir = normalize(tangent_part(dir_up, q2));
                q2 = normalize(q2 * dcos(a) + tdir * dsin(a));
                let c2 = s.fg.cell_of(q2);
                let hh = t.height[c2] as f64;
                if hh <= 0.0 {
                    ocean_at = (st as f64) * 100.0;
                    break;
                }
                if hh - h > ridge && (st as f64) * 100.0 <= 1500.0 {
                    ridge = hh - h;
                    ridge_at = (st as f64) * 100.0;
                }
                let (wu2, wv2) = annual_wind(&s, q2);
                let sp2 = (wu2 * wu2 + wv2 * wv2).sqrt();
                if sp2 > 0.3 {
                    let (e2, n2) = east_north(q2);
                    dir_up = e2 * (-wu2 / sp2) + n2 * (-wv2 / sp2);
                }
            }
            let itcz = s.s.st().itcz_lat[itcz_idx] as f64;
            if ridge > 1000.0 {
                out.push_str(&format!(
                    "RAIN SHADOW: prevailing wind blows from the {} ({:.1} m/s). {:.0} km upwind a range stands {:.0} m higher; air forced up it cools, rains out, and arrives here dry.\n",
                    compass(from), sp, ridge_at, ridge
                ));
            } else if ocean_at < 0.0 || ocean_at > 1500.0 {
                out.push_str(&format!(
                    "FAR FROM THE SEA: wind from the {} has travelled {} over land, losing moisture to every basin and slope on the way.\n",
                    compass(from),
                    if ocean_at < 0.0 { ">3000 km" } else { ">1500 km" }
                ));
            } else if lat_deg.abs() > 15.0 && lat_deg.abs() < 40.0 && (lat_deg - itcz).abs() > 12.0 {
                out.push_str(&format!(
                    "SUBTROPICAL HIGH: air rises at the equatorial trough (near {:.0} deg), flows poleward and sinks near {:.0} deg latitude. Sinking air warms and dries, suppressing cloud (Hadley cell).\n",
                    itcz,
                    s.s.st().hadley_deg
                ));
            } else {
                out.push_str(&format!(
                    "DRY: wind from the {} reaches the ocean {:.0} km away but is too weak and cool-surfaced to load enough moisture.\n",
                    compass(from),
                    ocean_at
                ));
            }
            let evap_demand = p_ann / (0.02f64).max(ai);
            out.push_str(&format!(
                "Evaporation demand {:.0} mm/yr is {:.1}x the rainfall, so soil dries out.\n",
                evap_demand,
                evap_demand / (1.0f64).max(p_ann)
            ));
        }
    } else if ai > 1.3 && p_ann > 1400.0 {
        let itcz = s.s.st().itcz_lat[itcz_idx] as f64;
        if (lat_deg - itcz).abs() < 14.0 {
            out.push_str(&format!(
                "WET: the Intertropical Convergence Zone (thermal equator near {:.0} deg) draws warm humid ocean air together; it rises and rains daily.\n",
                itcz
            ));
        } else {
            out.push_str(&format!("WET: moist ocean air is forced up slopes or meets cooler air, condensing into {:.0} mm of rain a year.\n", p_ann));
        }
    }
    if bi == B_ICE as i32 || bi == B_TUNDRA as i32 || bi == B_ALPINE as i32 {
        out.push_str(&format!(
            "Cold: {:.1} C annual mean, warmest month only {:.1} C; temperature falls ~6.5 C per km of altitude and with distance from the equator.\n",
            t_ann, e.t_max[fc]
        ));
    }
    out.push_str(&format!(
        "Soil fertility {:.2} from parent rock {:.2}, organic matter {:.2} and drainage.\n",
        e.fertility[fc], e.mineral[fc], e.organic[fc]
    ));
    out
}
