//! Application layer: owns the world, the simulation thread (continuous, smooth time), camera + gesture
//! handling, and the numbers/strings the Android UI polls.

use crate::camera::Camera;
use crate::chunk::build_cloud_texture;
use crate::civ::*;
use crate::explain::*;
use crate::gl::log;
use crate::mathx::*;
use crate::params::*;
use crate::render::*;
use crate::world::*;
use std::sync::atomic::{AtomicBool, AtomicI32, AtomicI64, AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver, RecvTimeoutError, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

pub const STATE_LEN: usize = 64;
pub const S_READY: usize = 0;
pub const S_BUSY: usize = 1;
pub const S_SOFT: usize = 2;
pub const S_PROGRESS: usize = 3;
pub const S_ROOTS: usize = 4;
pub const S_RUNNING: usize = 5;
pub const S_EPOCH: usize = 6;
pub const S_INFO: usize = 8; // 16 values
pub const S_FPS: usize = 24;
pub const S_FRAME_MS: usize = 25;
pub const S_VISIBLE: usize = 26;
pub const S_GPU_CHUNKS: usize = 27;
pub const S_QUEUED: usize = 28;
pub const S_ACTIVE: usize = 29;
pub const S_WORKERS: usize = 30;
pub const S_UPLOADS: usize = 31;
pub const S_TRIS: usize = 32;
pub const S_DRAWS: usize = 33;
pub const S_CAM_LAT: usize = 34;
pub const S_CAM_LON: usize = 35;
pub const S_CAM_ALT: usize = 36;
pub const S_ROOTS_DONE: usize = 37;
pub const S_TIMING: usize = 38; // 10 values
pub const S_LAYER: usize = 48;
pub const S_CIV: usize = 56; // 8 values: started, people, cities, era, era progress, year, message counter

const STAMP_YEARS: f64 = 1.0 / 20.0;

/// Wall-clock throttle for the "visual refresh" (new cloud texture + re-texturing of every visible terrain tile).
/// Re-texturing is by far the most expensive thing the app does while the simulation runs, and seasons that flip
/// faster than the tiles can be rebuilt are not visible anyway, so refreshes are paced by real time and by speed;
/// whenever the simulation pauses or slows down, the latest state is shown right away.
pub struct Vis {
    pub stamp_years: f64,
    pub last: Instant,
    pub dirty: bool,
    pub slow_dirty: bool,
}

impl Vis {
    pub fn new() -> Vis {
        Vis { stamp_years: 0.0, last: Instant::now(), dirty: false, slow_dirty: false }
    }
}

fn vis_interval_ms(speed_years_per_s: f64) -> u64 {
    if speed_years_per_s >= 100.0 {
        4000
    } else if speed_years_per_s >= 5.0 {
        2500
    } else if speed_years_per_s >= 0.5 {
        1800
    } else {
        1000
    }
}

pub enum Cmd {
    Generate(String, Vec<f64>),
    Retune(Vec<f64>),
    Settle(f64, f64),
    Step(f64),
    ShiftHours(f64),
    Quit,
}

#[derive(Default, Clone)]
pub struct Status {
    pub title: String,
    pub stage: String,
    pub progress: f32,
    pub error: String,
}

#[derive(Default, Clone, Copy)]
pub struct RenderStats {
    pub fps: f64,
    pub frame_ms: f64,
    pub visible: usize,
    pub gpu_chunks: usize,
    pub queued: usize,
    pub active: usize,
    pub workers: usize,
    pub uploads: usize,
    pub tris: usize,
    pub draws: usize,
    pub roots_ready: bool,
    pub roots_done: usize,
    pub build_ms: f64,
    pub build_n: u64,
}

pub struct TouchState {
    mode: u8, // 0 none, 1 one finger, 2 two fingers
    last: (f64, f64),
    down: (f64, f64),
    down_t: f64,
    moved: f64,
    last_t: f64,
    omega: V3,
    last_dist: f64,
    last_ang: f64,
    last_cy: f64,
    last_tap_t: f64,
    last_tap: (f64, f64),
}

impl TouchState {
    pub fn new() -> TouchState {
        TouchState {
            mode: 0,
            last: (0.0, 0.0),
            down: (0.0, 0.0),
            down_t: 0.0,
            moved: 0.0,
            last_t: 0.0,
            omega: V3::default(),
            last_dist: 0.0,
            last_ang: 0.0,
            last_cy: 0.0,
            last_tap_t: -10.0,
            last_tap: (0.0, 0.0),
        }
    }

    /// action: 0 down, 1 move, 2 up, 3 cancel, 4 second finger down, 5 a finger lifted (x0,y0 = remaining finger)
    pub fn handle(&mut self, cam: &mut Camera, action: i32, n: i32, x0: f64, y0: f64, x1: f64, y1: f64, t: f64) {
        match action {
            0 => {
                self.mode = 1;
                self.last = (x0, y0);
                self.down = (x0, y0);
                self.down_t = t;
                self.moved = 0.0;
                self.last_t = t;
                self.omega = V3::default();
                cam.stop_motion();
            }
            4 => {
                if n >= 2 {
                    self.mode = 2;
                    self.omega = V3::default();
                    cam.stop_motion();
                    self.last_dist = ((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0)).sqrt();
                    self.last_ang = (y1 - y0).atan2(x1 - x0);
                    self.last_cy = 0.5 * (y0 + y1);
                }
            }
            1 => {
                if self.mode == 1 && n == 1 {
                    let dt = (t - self.last_t).max(1e-3);
                    let (axis, ang) = cam.drag(self.last.0, self.last.1, x0, y0);
                    let dx = x0 - self.last.0;
                    let dy = y0 - self.last.1;
                    self.moved += (dx * dx + dy * dy).sqrt();
                    if ang != 0.0 {
                        let w_new = axis * (ang / dt);
                        self.omega = self.omega * 0.45 + w_new * 0.55;
                    } else {
                        self.omega = self.omega * 0.45;
                    }
                    self.last = (x0, y0);
                    self.last_t = t;
                } else if self.mode == 2 && n >= 2 {
                    let dist = ((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0)).sqrt();
                    let ang = (y1 - y0).atan2(x1 - x0);
                    let cy = 0.5 * (y0 + y1);
                    if self.last_dist > 8.0 && dist > 8.0 {
                        cam.zoom_by(self.last_dist / dist);
                        let mut da = ang - self.last_ang;
                        while da > PI {
                            da -= TAU;
                        }
                        while da < -PI {
                            da += TAU;
                        }
                        cam.rotate_heading(-da);
                        cam.tilt_by(-((cy - self.last_cy) / cam.view_h) * 1.6);
                    }
                    self.last_dist = dist;
                    self.last_ang = ang;
                    self.last_cy = cy;
                }
            }
            5 => {
                // one finger left: continue as a single-finger drag from its current position
                self.mode = 1;
                self.last = (x0, y0);
                self.last_t = t;
                self.omega = V3::default();
                self.moved = 1000.0; // not a tap
            }
            2 => {
                if self.mode == 1 {
                    if t - self.last_t < 0.07 && length(self.omega) > 0.04 {
                        cam.start_spin(self.omega * 0.8, 2.0);
                    }
                    let is_tap = self.moved < 16.0 && (t - self.down_t) < 0.30;
                    if is_tap {
                        let dxx = x0 - self.last_tap.0;
                        let dyy = y0 - self.last_tap.1;
                        if t - self.last_tap_t < 0.35 && (dxx * dxx + dyy * dyy).sqrt() < 70.0 {
                            cam.compute_pose();
                            let dir = cam.grab_dir(x0, y0);
                            let goal = if cam.dist_goal() < cam.radius * 0.03 { cam.radius * 0.5 } else { cam.dist_goal() * 0.38 };
                            cam.fly_to(dir, goal, 0.7);
                            self.last_tap_t = -10.0;
                        } else {
                            self.last_tap_t = t;
                            self.last_tap = (x0, y0);
                        }
                    }
                }
                self.mode = 0;
            }
            _ => {
                self.mode = 0;
                cam.stop_motion();
            }
        }
    }
}

pub struct App {
    pub world: Arc<World>,
    pub cam: Mutex<Camera>,
    touch: Mutex<TouchState>,
    pub renderer: Mutex<Option<Renderer>>,
    tx: Mutex<Sender<Cmd>>,
    pub busy: AtomicBool,
    pub soft: AtomicBool,
    pub ready: AtomicBool,
    pub epoch: AtomicI64,
    pub stamp: AtomicI64,
    pub slow_stamp: AtomicI64,
    pub layer: AtomicI32,
    pub running: AtomicBool,
    pub speed_bits: AtomicU64,
    pub status: Mutex<Status>,
    sun: Mutex<[f64; 4]>,
    info: Mutex<[f64; 16]>,
    timing: Mutex<[f64; 10]>,
    radius_bits: AtomicU64,
    cloud: Mutex<Option<Vec<u8>>>,
    civ: Mutex<Civ>,
    civ_pub: Mutex<CivPublic>,
    pub shutdown: AtomicBool,
    cam_epoch: AtomicI64,
    cam_init: AtomicBool,
    frame_no: AtomicU64,
    render_stats: Mutex<RenderStats>,
    sim_thread: Mutex<Option<std::thread::JoinHandle<()>>>,
}

static APP: Mutex<Option<Arc<App>>> = Mutex::new(None);

pub fn app() -> Option<Arc<App>> {
    lk(&APP).clone()
}

pub fn app_init() -> Arc<App> {
    let mut g = lk(&APP);
    if let Some(a) = g.as_ref() {
        return Arc::clone(a);
    }
    let (tx, rx) = channel::<Cmd>();
    let a = Arc::new(App {
        world: Arc::new(World::new()),
        cam: Mutex::new(Camera::new()),
        touch: Mutex::new(TouchState::new()),
        renderer: Mutex::new(None),
        tx: Mutex::new(tx),
        busy: AtomicBool::new(false),
        soft: AtomicBool::new(false),
        ready: AtomicBool::new(false),
        epoch: AtomicI64::new(0),
        stamp: AtomicI64::new(0),
        slow_stamp: AtomicI64::new(0),
        layer: AtomicI32::new(0),
        running: AtomicBool::new(false),
        speed_bits: AtomicU64::new((1.0f64 / 12.0).to_bits()),
        status: Mutex::new(Status::default()),
        sun: Mutex::new([1.0, 0.0, 0.0, 0.0]),
        info: Mutex::new([0.0; 16]),
        timing: Mutex::new([0.0; 10]),
        radius_bits: AtomicU64::new(6371000.0f64.to_bits()),
        cloud: Mutex::new(None),
        civ: Mutex::new(Civ::new()),
        civ_pub: Mutex::new(CivPublic::default()),
        shutdown: AtomicBool::new(false),
        cam_epoch: AtomicI64::new(-1),
        cam_init: AtomicBool::new(false),
        frame_no: AtomicU64::new(0),
        render_stats: Mutex::new(RenderStats::default()),
        sim_thread: Mutex::new(None),
    });
    let a2 = Arc::clone(&a);
    let builder = std::thread::Builder::new().name(String::from("lw-sim")).stack_size(16 * 1024 * 1024);
    match builder.spawn(move || sim_main(a2, rx)) {
        Ok(h) => {
            *lk(&a.sim_thread) = Some(h);
        }
        Err(e) => {
            log(&format!("cannot start simulation thread: {}", e));
        }
    }
    *g = Some(Arc::clone(&a));
    a
}

fn panic_text(e: &Box<dyn std::any::Any + Send>) -> String {
    if let Some(s) = e.downcast_ref::<&str>() {
        return s.to_string();
    }
    if let Some(s) = e.downcast_ref::<String>() {
        return s.clone();
    }
    String::from("unknown panic")
}

impl App {
    pub fn send(&self, c: Cmd) {
        let _ = lk(&self.tx).send(c);
    }

    pub fn radius_m(&self) -> f64 {
        f64::from_bits(self.radius_bits.load(Ordering::SeqCst))
    }
    pub fn speed(&self) -> f64 {
        f64::from_bits(self.speed_bits.load(Ordering::SeqCst))
    }

    fn set_progress(&self, stage: &str, f: f32) {
        let mut s = lk(&self.status);
        s.stage = stage.to_string();
        s.progress = f;
    }
    fn set_error(&self, msg: &str) {
        log(msg);
        lk(&self.status).error = msg.to_string();
    }

    /// sim thread: recompute sun / info (cheap) and optionally the cloud texture
    fn refresh(&self, clouds: bool) {
        let v = match self.world.view() {
            Some(v) => v,
            None => return,
        };
        let d = &v.d;
        let s = &v.s;
        *lk(&self.sun) = [d.sun_dir.x, d.sun_dir.y, d.sun_dir.z, d.decl_deg];
        self.radius_bits.store(s.dv.r.to_bits(), Ordering::SeqCst);
        let st = s.st();
        let mut info = [0.0f64; 16];
        info[0] = d.time_years;
        info[1] = d.frac_year;
        info[2] = d.day_frac;
        info[3] = d.global_t - 273.15;
        info[4] = s.pp.pressure_atm;
        info[5] = 1.0 - s.t().land_fraction;
        info[6] = s.pp.axial_tilt_deg;
        info[7] = s.pp.rotation_hours;
        info[8] = s.pp.radius_km;
        info[9] = d.decl_deg;
        info[10] = s.dv.solar_days_per_year;
        info[11] = s.dv.year_days;
        info[12] = st.water_imbalance;
        info[13] = st.global_mean_p;
        info[14] = s.t().land_fraction;
        *lk(&self.info) = info;
        let tm = self.world.timings();
        let mut t = [0.0f64; 10];
        t[0] = tm.gen_total_ms;
        t[1] = tm.terrain_ms;
        t[2] = tm.climate_ms;
        t[3] = tm.eco_ms;
        t[4] = tm.step_ms;
        t[5] = tm.climate_step_ms;
        t[6] = tm.river_ms;
        *lk(&self.timing) = t;
        if clouds {
            let mut buf: Vec<u8> = Vec::new();
            build_cloud_texture(&v, 512, 256, &mut buf);
            *lk(&self.cloud) = Some(buf);
        }
    }

    fn do_generate(&self, seed: &str, params: &[f64]) {
        self.busy.store(true, Ordering::SeqCst);
        self.ready.store(false, Ordering::SeqCst);
        {
            let mut s = lk(&self.status);
            s.title = String::from("Generating planet");
            s.stage = String::from("Starting");
            s.progress = 0.0;
            s.error.clear();
        }
        let mut pp = PlanetParams::default();
        pp.from_array(params);
        let res = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let cb = |s: &str, f: f32| self.set_progress(s, f);
            self.world.generate(seed, &pp, &cb);
        }));
        match res {
            Ok(()) => {
                lk(&self.civ).reset("");
                self.civ_publish();
                self.refresh(true);
                self.stamp.fetch_add(1, Ordering::SeqCst);
                self.slow_stamp.fetch_add(1, Ordering::SeqCst);
                self.epoch.fetch_add(1, Ordering::SeqCst);
                self.ready.store(true, Ordering::SeqCst);
            }
            Err(e) => {
                self.set_error(&format!("Planet generation failed: {}", panic_text(&e)));
            }
        }
        self.busy.store(false, Ordering::SeqCst);
    }

    fn civ_publish(&self) {
        let p = lk(&self.civ).publish();
        *lk(&self.civ_pub) = p;
    }

    fn do_settle(&self, lat: f64, lon: f64) {
        if !self.ready.load(Ordering::SeqCst) {
            return;
        }
        let v = match self.world.view() {
            Some(v) => v,
            None => return,
        };
        lk(&self.civ).settle(&v, lat, lon);
        self.civ_publish();
    }

    /// the climate-driven look of the planet changed: new clouds are already built, so re-texture the tiles (stamp);
    /// after a slow ecosystem update also rebuild the layers that only depend on that (slow stamp)
    fn bump_visual(&self, vs: &mut Vis, t: f64) {
        self.stamp.fetch_add(1, Ordering::SeqCst);
        if vs.slow_dirty {
            self.slow_stamp.fetch_add(1, Ordering::SeqCst);
            vs.slow_dirty = false;
        }
        vs.stamp_years = t;
        vs.last = Instant::now();
        vs.dirty = false;
    }

    /// idle catch-up: show the latest climate state once the simulation paused or slowed down
    fn flush_visual(&self, vs: &mut Vis) {
        self.refresh(true);
        let t = self.world.time_years();
        self.bump_visual(vs, t);
    }

    fn do_advance(&self, years: f64, vs: &mut Vis, manual: bool) {
        if !self.ready.load(Ordering::SeqCst) || years <= 0.0 {
            return;
        }
        let blocking = years >= 4.0e5;
        if blocking {
            self.busy.store(true, Ordering::SeqCst);
            let mut s = lk(&self.status);
            s.title = String::from("Moving continents (plate tectonics)");
            s.stage = String::from("Starting");
            s.progress = 0.0;
        }
        let gen0 = self.world.generation();
        let res = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let cb = |s: &str, f: f32| {
                self.soft.store(true, Ordering::SeqCst);
                self.set_progress(s, f);
            };
            self.world.advance(years, &cb);
        }));
        self.soft.store(false, Ordering::SeqCst);
        if let Err(e) = res {
            self.set_error(&format!("Simulation step failed: {}", panic_text(&e)));
        }
        let gen_changed = self.world.generation() != gen0;
        if gen_changed {
            vs.slow_dirty = true;
        }
        // the people of the planet live through the same years
        let mut civ_changed = false;
        if years >= 4.0e5 {
            lk(&self.civ).reset("The continents drifted and the climate changed beyond recognition: every civilization is gone.");
            civ_changed = true;
        } else if let Some(v) = self.world.view() {
            civ_changed = lk(&self.civ).advance(&v, years);
        }
        if civ_changed {
            self.civ_publish();
        }
        let t = self.world.time_years();
        let due = years >= 1.0 || gen_changed || (t - vs.stamp_years).abs() >= STAMP_YEARS;
        let wall_ok = manual || blocking || vs.last.elapsed() >= Duration::from_millis(vis_interval_ms(self.speed()));
        let big = due && wall_ok;
        if due && !wall_ok {
            vs.dirty = true;
        }
        self.refresh(big);
        if years >= 4.0e5 {
            self.epoch.fetch_add(1, Ordering::SeqCst);
        }
        if big {
            self.bump_visual(vs, t);
        }
        if blocking {
            self.busy.store(false, Ordering::SeqCst);
        }
    }

    /// change climate-side parameters but keep the continents (and the people); regenerates only if terrain settings differ
    fn do_retune(&self, params: &[f64], vs: &mut Vis) {
        self.busy.store(true, Ordering::SeqCst);
        {
            let mut s = lk(&self.status);
            s.title = String::from("Re-tuning the climate");
            s.stage = String::from("Starting");
            s.progress = 0.0;
            s.error.clear();
        }
        let mut pp = PlanetParams::default();
        pp.from_array(params);
        let res = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let cb = |s: &str, f: f32| self.set_progress(s, f);
            self.world.retune(&pp, &cb)
        }));
        match res {
            Ok(true) => {
                self.refresh(true);
                let t = self.world.time_years();
                vs.slow_dirty = true;
                self.bump_visual(vs, t);
                self.civ_publish();
            }
            Ok(false) => {
                // a terrain parameter changed too: build a whole new planet from the same seed
                let seed = match self.world.view() {
                    Some(v) => v.s.seed_str.clone(),
                    None => String::new(),
                };
                self.do_generate(&seed, params);
                vs.stamp_years = self.world.time_years();
                vs.last = Instant::now();
                vs.dirty = false;
                vs.slow_dirty = false;
                return;
            }
            Err(e) => {
                self.set_error(&format!("Climate re-tune failed: {}", panic_text(&e)));
            }
        }
        self.busy.store(false, Ordering::SeqCst);
    }

    // ------------------------------------------------------------------------------------------------
    // GL thread
    // ------------------------------------------------------------------------------------------------
    pub fn on_surface_created(&self) {
        let mut g = lk(&self.renderer);
        if g.is_none() {
            *g = Some(Renderer::new(Arc::clone(&self.world)));
        }
        if let Some(r) = g.as_mut() {
            r.on_surface_created();
        }
    }

    pub fn on_surface_changed(&self, w: i32, h: i32) {
        if let Some(r) = lk(&self.renderer).as_mut() {
            r.on_surface_changed(w, h);
        }
        lk(&self.cam).set_viewport(w as f64, h as f64);
    }

    pub fn on_draw(&self) {
        let mut g = lk(&self.renderer);
        let r = match g.as_mut() {
            Some(r) => r,
            None => return,
        };
        let dt = r.begin_frame();
        let ready = self.ready.load(Ordering::SeqCst);
        let epoch = self.epoch.load(Ordering::SeqCst);
        let radius = self.radius_m();
        let frame = self.frame_no.fetch_add(1, Ordering::SeqCst) + 1;
        let snap: Camera = {
            let mut c = lk(&self.cam);
            if ready && self.cam_epoch.load(Ordering::SeqCst) != epoch {
                if !self.cam_init.load(Ordering::SeqCst) || (c.radius - radius).abs() > 1.0 {
                    c.reset(radius);
                    c.set_center(18.0, 12.0);
                    self.cam_init.store(true, Ordering::SeqCst);
                }
                self.cam_epoch.store(epoch, Ordering::SeqCst);
            }
            c.set_viewport(r.view_w as f64, r.view_h as f64);
            c.step(dt);
            c.update();
            c.clone()
        };
        if ready && frame % 6 == 0 {
            if let Some(v) = self.world.view() {
                let h = height_at_lat_lon(&v, snap.lat_deg(), snap.lon_deg());
                let mut c = lk(&self.cam);
                c.target_height += (h - c.target_height) * 0.4;
            }
        }
        let sun = *lk(&self.sun);
        let cloud = lk(&self.cloud).take().map(|b| (b, 512i32, 256i32));
        let inp = FrameInput {
            ready,
            epoch,
            stamp: self.stamp.load(Ordering::SeqCst),
            layer: self.layer.load(Ordering::SeqCst),
            sun: [sun[0], sun[1], sun[2]],
            radius_m: radius,
            cloud,
            slow_stamp: self.slow_stamp.load(Ordering::SeqCst),
            marks: lk(&self.civ_pub).marks.clone(),
        };
        r.draw_frame(&snap, &inp);
        if frame % 10 == 0 {
            let (bms, bn) = r.mgr.build_stats();
            *lk(&self.render_stats) = RenderStats {
                fps: r.fps,
                frame_ms: r.frame_ms,
                visible: r.visible_chunks,
                gpu_chunks: r.mgr.gpu_chunk_count(),
                queued: r.mgr.queued_jobs(),
                active: r.mgr.active_jobs(),
                workers: r.mgr.workers,
                uploads: r.uploads_per_frame,
                tris: r.tris,
                draws: r.draws,
                roots_ready: r.roots_ready,
                roots_done: r.roots_done,
                build_ms: bms,
                build_n: bn,
            };
            if !r.shader_error.is_empty() {
                let e = r.shader_error.clone();
                let mut s = lk(&self.status);
                if s.error.is_empty() {
                    s.error = e;
                }
            }
        }
    }

    pub fn on_touch(&self, action: i32, n: i32, x0: f64, y0: f64, x1: f64, y1: f64, t_ms: i64) {
        let t = (t_ms as f64) * 0.001;
        let mut ts = lk(&self.touch);
        let mut c = lk(&self.cam);
        ts.handle(&mut c, action, n, x0, y0, x1, y1, t);
    }

    // ------------------------------------------------------------------------------------------------
    // UI polling
    // ------------------------------------------------------------------------------------------------
    pub fn fill_state(&self, out: &mut [f64]) {
        for v in out.iter_mut() {
            *v = 0.0;
        }
        if out.len() < STATE_LEN {
            return;
        }
        out[S_READY] = if self.ready.load(Ordering::SeqCst) { 1.0 } else { 0.0 };
        out[S_BUSY] = if self.busy.load(Ordering::SeqCst) { 1.0 } else { 0.0 };
        out[S_SOFT] = if self.soft.load(Ordering::SeqCst) { 1.0 } else { 0.0 };
        out[S_PROGRESS] = lk(&self.status).progress as f64;
        out[S_RUNNING] = if self.running.load(Ordering::SeqCst) { 1.0 } else { 0.0 };
        out[S_EPOCH] = self.epoch.load(Ordering::SeqCst) as f64;
        let info = *lk(&self.info);
        for i in 0..16usize {
            out[S_INFO + i] = info[i];
        }
        let rs = *lk(&self.render_stats);
        out[S_ROOTS] = if rs.roots_ready { 1.0 } else { 0.0 };
        out[S_FPS] = rs.fps;
        out[S_FRAME_MS] = rs.frame_ms;
        out[S_VISIBLE] = rs.visible as f64;
        out[S_GPU_CHUNKS] = rs.gpu_chunks as f64;
        out[S_QUEUED] = rs.queued as f64;
        out[S_ACTIVE] = rs.active as f64;
        out[S_WORKERS] = rs.workers as f64;
        out[S_UPLOADS] = rs.uploads as f64;
        out[S_TRIS] = rs.tris as f64;
        out[S_DRAWS] = rs.draws as f64;
        {
            let c = lk(&self.cam);
            out[S_CAM_LAT] = c.lat_deg();
            out[S_CAM_LON] = c.lon_deg();
            out[S_CAM_ALT] = c.altitude;
        }
        let tm = *lk(&self.timing);
        for i in 0..10usize {
            out[S_TIMING + i] = tm[i];
        }
        out[S_TIMING + 7] = rs.workers as f64;
        out[S_TIMING + 8] = rs.build_ms;
        out[S_TIMING + 9] = rs.build_n as f64;
        out[S_LAYER] = self.layer.load(Ordering::SeqCst) as f64;
        out[S_ROOTS_DONE] = rs.roots_done as f64;
        {
            let cp = lk(&self.civ_pub);
            out[S_CIV] = if cp.started { 1.0 } else { 0.0 };
            out[S_CIV + 1] = cp.total;
            out[S_CIV + 2] = cp.cities as f64;
            out[S_CIV + 3] = cp.tech.floor().min(5.0).max(0.0);
            out[S_CIV + 4] = if cp.tech >= 5.0 { 1.0 } else { cp.tech - cp.tech.floor() };
            out[S_CIV + 5] = cp.year;
            out[S_CIV + 6] = cp.msg_seq as f64;
        }
    }

    pub fn text(&self, which: i32) -> String {
        match which {
            0 => lk(&self.status).title.clone(),
            1 => lk(&self.status).stage.clone(),
            2 => lk(&self.status).error.clone(),
            3 => match lk(&self.renderer).as_ref() {
                Some(r) => r.gpu_info.clone(),
                None => String::new(),
            },
            4 | 5 => {
                if !self.ready.load(Ordering::SeqCst) {
                    return String::new();
                }
                let v = match self.world.view() {
                    Some(v) => v,
                    None => return String::new(),
                };
                let (lat, lon) = {
                    let c = lk(&self.cam);
                    (c.lat_deg(), c.lon_deg())
                };
                if which == 4 {
                    inspect_text(&v, lat, lon)
                } else {
                    let mut t = explain_text(&v, lat, lon);
                    if let Ok(c) = self.civ.try_lock() {
                        t.push_str(&c.cell_info(&v, lat, lon));
                    }
                    t
                }
            }
            6 => lk(&self.civ_pub).chronicle.clone(),
            7 => lk(&self.civ_pub).msg.clone(),
            8 => {
                let tech = lk(&self.civ_pub).tech;
                era_name(tech).to_string()
            }
            _ => String::new(),
        }
    }

    pub fn reset_view(&self) {
        let r = self.radius_m();
        let mut c = lk(&self.cam);
        c.reset(r);
        c.set_center(18.0, 12.0);
    }

    pub fn shutdown_all(&self) {
        self.shutdown.store(true, Ordering::SeqCst);
        self.send(Cmd::Quit);
    }
}

fn sim_main(app: Arc<App>, rx: Receiver<Cmd>) {
    let mut last = Instant::now();
    let mut vs = Vis::new();
    loop {
        if app.shutdown.load(Ordering::SeqCst) {
            break;
        }
        let mut handled = false;
        match rx.recv_timeout(Duration::from_millis(40)) {
            Ok(Cmd::Quit) => break,
            Ok(Cmd::Generate(seed, params)) => {
                app.do_generate(&seed, &params);
                vs = Vis::new();
                vs.stamp_years = app.world.time_years();
                last = Instant::now();
                handled = true;
            }
            Ok(Cmd::Retune(params)) => {
                app.do_retune(&params, &mut vs);
                last = Instant::now();
                handled = true;
            }
            Ok(Cmd::Settle(lat, lon)) => {
                app.do_settle(lat, lon);
                handled = true;
            }
            Ok(Cmd::Step(y)) => {
                app.do_advance(y, &mut vs, true);
                last = Instant::now();
                handled = true;
            }
            Ok(Cmd::ShiftHours(h)) => {
                app.world.add_day_hours(h);
                app.refresh(false);
                handled = true;
            }
            Err(RecvTimeoutError::Timeout) => {}
            Err(RecvTimeoutError::Disconnected) => break,
        }
        let now = Instant::now();
        let dt = now.duration_since(last).as_secs_f64().min(2.0);
        last = now;
        if handled {
            continue;
        }
        let idle_ok = app.ready.load(Ordering::SeqCst) && !app.busy.load(Ordering::SeqCst);
        if app.running.load(Ordering::SeqCst) && idle_ok {
            let sp = app.speed();
            let step = (sp * dt).min(sp * 2.0);
            if step > 0.0 {
                app.do_advance(step, &mut vs, false);
                last = Instant::now();
            }
        } else if vs.dirty && idle_ok && vs.last.elapsed() >= Duration::from_millis(250) {
            app.flush_visual(&mut vs);
        }
    }
}
