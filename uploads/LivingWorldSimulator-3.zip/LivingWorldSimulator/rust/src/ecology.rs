//! Hydrology, soil, vegetation, biomes, resources and hazards on the fine grid.

use crate::biome::*;
use crate::climate::solar_geometry;
use crate::grid::*;
use crate::mathx::*;
use crate::noise::Noise;
use crate::params::*;
use crate::terrain::{compute_flow, FlowGraph};
use crate::world_data::*;

fn day_length_frac(lat: f64, decl: f64) -> f64 {
    let x = -dtan(lat) * dtan(decl);
    if x >= 1.0 {
        return 0.0;
    }
    if x <= -1.0 {
        return 1.0;
    }
    dacos(x) / PI
}

struct S1 {
    t_ann: f32,
    t_min: f32,
    t_max: f32,
    p_ann: f32,
    p_dry: f32,
    arid: f32,
    soil_m: f32,
    runoff: f32,
    run_max: f32,
    run_melt: f32,
    pet: f32,
}

struct S3 {
    npp: f32,
    biome: u8,
    veg: f32,
    mineral: f32,
    depth: f32,
    organic: f32,
    fert: f32,
    drain: f32,
    gw: f32,
    delta: f32,
    flood: f32,
}

struct S4 {
    res: [u8; R_COUNT],
    seis: f32,
    volc: f32,
    slide: f32,
    drought: f32,
}

/// Downscale the coarse climate cycle to the fine terrain grid, route water, build rivers/lakes, soils, biomes.
/// Also returns the coarse vegetation / soil-capacity / glacier fields that feed back into the climate.
pub fn build_hydro_eco(
    pp: &PlanetParams,
    dv: &Derived,
    nz: &Noise,
    cg: &CubeGrid,
    fg: &CubeGrid,
    t: &TerrainData,
    sl: &ClimateSlices,
    st: &ClimateStatic,
    oro_vec: &[f32],
    h: &mut HydroData,
    e: &mut EcoData,
    veg_coarse: &mut Vec<f32>,
    soil_cap_coarse: &mut Vec<f32>,
    glacier_coarse: &mut Vec<f32>,
    progress: Progress,
) {
    let n = fg.count;
    let nc = cg.count;
    let gam = dv.lapse;
    let rm = dv.r;
    let _ = pp;

    e.t_ann = vec![0f32; n];
    e.t_min = vec![0f32; n];
    e.t_max = vec![0f32; n];
    e.p_ann = vec![0f32; n];
    e.p_dry_frac = vec![0f32; n];
    e.aridity = vec![0f32; n];
    e.soil_moist = vec![0f32; n];
    e.npp = vec![0f32; n];
    e.fertility = vec![0f32; n];
    e.soil_depth = vec![0f32; n];
    e.mineral = vec![0f32; n];
    e.organic = vec![0f32; n];
    e.drainage = vec![0f32; n];
    e.seismic_haz = vec![0f32; n];
    e.volc_haz = vec![0f32; n];
    e.flood_haz = vec![0f32; n];
    e.slide_haz = vec![0f32; n];
    e.drought_haz = vec![0f32; n];
    h.fill = vec![0f32; n];
    h.lake_level = vec![0f32; n];
    h.lake_depth = vec![0f32; n];
    h.discharge = vec![0f32; n];
    h.discharge_max = vec![0f32; n];
    h.runoff = vec![0f32; n];
    h.snowmelt_frac = vec![0f32; n];
    h.gw = vec![0f32; n];
    h.delta = vec![0f32; n];
    h.flood = vec![0f32; n];
    h.global_discharge = 0.0;
    e.biome = vec![B_OCEAN; n];
    for r in 0..R_COUNT {
        e.res[r] = vec![0u8; n];
    }
    h.river_order = vec![0u8; n];
    h.lake_kind = vec![0u8; n];

    // ------------------------------------------------------------------ downscale climate + monthly water balance
    progress("Downscaling climate", 0.0);
    let mut decl = [0f64; NSLICE];
    for m in 0..NSLICE {
        let (d, _r) = solar_geometry(dv, ((m as f64) + 0.5) / (NSLICE as f64));
        decl[m] = d;
    }
    let day_m = dv.year_days / (NSLICE as f64);
    let s1: Vec<S1> = par_map(n, |c| {
        let hh = t.height[c] as f64;
        let (ids, w) = cg.locate(fg.pos[c]);
        let lat = fg.lat[c] as f64;
        if hh <= 0.0 {
            let mut ta = 0.0f64;
            let mut pr = 0.0f64;
            let mut mn = 1e9f64;
            let mut mx = -1e9f64;
            let mut dry = 0.0f64;
            for m in 0..NSLICE {
                let mut tt = 0.0f64;
                let mut p = 0.0f64;
                for k in 0..4usize {
                    tt += (w[k] * sl.ts[m * nc + ids[k]]) as f64;
                    p += (w[k] * sl.precip[m * nc + ids[k]]) as f64;
                }
                ta += tt;
                pr += p * day_m;
                mn = mn.min(tt);
                mx = mx.max(tt);
                if p * day_m < 60.0 {
                    dry += 1.0;
                }
            }
            return S1 {
                t_ann: (ta / (NSLICE as f64) - 273.15) as f32,
                t_min: (mn - 273.15) as f32,
                t_max: (mx - 273.15) as f32,
                p_ann: pr as f32,
                p_dry: (dry / (NSLICE as f64)) as f32,
                arid: 2.0,
                soil_m: 0.0,
                runoff: 0.0,
                run_max: 0.0,
                run_melt: 0.0,
                pet: 0.0,
            };
        }
        let mut zc = 0.0f64;
        for k in 0..4usize {
            zc += (w[k] * st.z_mean[ids[k]]) as f64;
        }
        let whc = 120.0
            + 80.0 * clampv((t.sediment[c] as f64) / 150.0, 0.0, 1.0)
            + 40.0 * (1.0 - clampv((t.slope[c] as f64) / 0.01, 0.0, 1.0));
        let mut snow_s = 0.0f64;
        let mut soil = 0.5 * whc;
        let mut sm_sum = 0.0f64;
        let mut tm = [0f64; NSLICE];
        let mut pm = [0f64; NSLICE];
        let mut petm = [0f64; NSLICE];
        let mut run_m = [0f64; NSLICE];
        let mut melt_m = [0f64; NSLICE];
        let op0 = oro_vec[c * 3] as f64;
        let op1 = oro_vec[c * 3 + 1] as f64;
        let op2 = oro_vec[c * 3 + 2] as f64;
        let (ev, nn) = east_north(fg.pos[c]);
        for m in 0..NSLICE {
            let mut tt = 0.0f64;
            let mut p = 0.0f64;
            let mut wu = 0.0f64;
            let mut wv = 0.0f64;
            for k in 0..4usize {
                let o = m * nc + ids[k];
                tt += (w[k] * sl.ta[o]) as f64;
                p += (w[k] * sl.precip[o]) as f64;
                wu += (w[k] * sl.wu[o]) as f64;
                wv += (w[k] * sl.wv[o]) as f64;
            }
            tt += gam * (zc - hh);
            let up = 1.3 * ((wu * ev.x + wv * nn.x) * op0 + (wu * ev.y + wv * nn.y) * op1 + (wu * ev.z + wv * nn.z) * op2);
            let of = clampv(1.0 + 0.55 * dtanh(up / 0.05), 0.45, 1.8);
            tm[m] = tt - 273.15;
            pm[m] = p * of * day_m;
            let ld = day_length_frac(lat, decl[m]) * 2.0;
            let es = 6.108 * dexp(17.27 * tm[m] / (tm[m] + 237.3));
            petm[m] = if tm[m] > 0.0 { 0.1651 * ld * 216.7 * es / (tm[m] + 273.3) * day_m * 0.82 } else { 0.0 };
        }
        for pass in 0..2 {
            for m in 0..NSLICE {
                let fs = clampv((2.0 - tm[m]) / 3.0, 0.0, 1.0);
                let snowfall = pm[m] * fs;
                let rain = pm[m] - snowfall;
                let melt = (snow_s + snowfall).min(3.5 * (0.0f64).max(tm[m]) * day_m);
                snow_s = (snow_s + snowfall - melt).min(8000.0);
                let inn = rain + melt;
                let aet = petm[m].min(soil + inn);
                soil += inn - aet;
                let sur = (0.0f64).max(soil - whc);
                soil -= sur;
                let r2 = 0.12 * inn * sqr(soil / whc);
                soil = (0.0f64).max(soil - r2);
                run_m[m] = sur + r2;
                melt_m[m] = if inn > 1e-6 { run_m[m] * melt / inn } else { 0.0 };
                if pass == 1 {
                    sm_sum += clampv(soil / whc, 0.0, 1.0);
                }
            }
        }
        let mut ra = 0.0f64;
        let mut rmx = 0.0f64;
        let mut rme = 0.0f64;
        let mut pa = 0.0f64;
        let mut pe = 0.0f64;
        let mut mn = 1e9f64;
        let mut mx = -1e9f64;
        let mut ta = 0.0f64;
        let mut dry = 0.0f64;
        let sm = sm_sum / (NSLICE as f64);
        for m in 0..NSLICE {
            ra += run_m[m];
            rmx = rmx.max(run_m[m]);
            rme += melt_m[m];
            pa += pm[m];
            pe += petm[m];
            mn = mn.min(tm[m]);
            mx = mx.max(tm[m]);
            ta += tm[m];
            if pm[m] < 60.0 {
                dry += 1.0;
            }
        }
        let arid_f = (pa / (30.0f64).max(pe)) as f32;
        S1 {
            t_ann: (ta / (NSLICE as f64)) as f32,
            t_min: mn as f32,
            t_max: mx as f32,
            p_ann: pa as f32,
            p_dry: (dry / (NSLICE as f64)) as f32,
            arid: arid_f,
            soil_m: clampv((1.0f64).min(sm * 0.5 + 0.5 * (1.0f64).min(arid_f as f64)), 0.0, 1.0) as f32,
            runoff: ra as f32,
            run_max: (rmx * 12.0) as f32,
            run_melt: rme as f32,
            pet: pe as f32,
        }
    });
    let mut run_max = vec![0f32; n];
    let mut run_melt = vec![0f32; n];
    let mut pet_ann = vec![0f32; n];
    for c in 0..n {
        let s = &s1[c];
        e.t_ann[c] = s.t_ann;
        e.t_min[c] = s.t_min;
        e.t_max[c] = s.t_max;
        e.p_ann[c] = s.p_ann;
        e.p_dry_frac[c] = s.p_dry;
        e.aridity[c] = s.arid;
        e.soil_moist[c] = s.soil_m;
        h.runoff[c] = s.runoff;
        run_max[c] = s.run_max;
        run_melt[c] = s.run_melt;
        pet_ann[c] = s.pet;
    }
    drop(s1);

    // ------------------------------------------------------------------ flow routing, lakes, discharge
    progress("Rivers and lakes", 0.25);
    let mut fl = FlowGraph::default();
    compute_flow(fg, &t.height, 0.0, &mut fl);
    h.rec = fl.rec.clone();
    let mut area_m2 = vec![0f64; n];
    for c in 0..n {
        area_m2[c] = (fg.area[c] as f64) * rm * rm;
    }
    let sec_yr = dv.year_days * 86400.0;
    let mut q = vec![0f64; n];
    let mut qm = vec![0f64; n];
    let mut qmelt = vec![0f64; n];
    for c in 0..n {
        if t.height[c] <= 0.0 {
            continue;
        }
        let k = area_m2[c] / 1000.0 / sec_yr;
        q[c] = (h.runoff[c] as f64) * k;
        qm[c] = (run_max[c] as f64) * k;
        qmelt[c] = (run_melt[c] as f64) * k;
    }
    for c in 0..n {
        h.fill[c] = fl.fill[c];
        let pit = t.height[c] > 0.0 && fl.fill[c] > t.height[c] + 2.0;
        h.lake_depth[c] = if pit { fl.fill[c] - t.height[c] } else { 0.0 };
        h.lake_level[c] = if pit { fl.fill[c] } else { t.height[c] };
    }
    // accumulate downstream; lakes lose water to evaporation (closed basins end up dry / salty)
    for i in (0..fl.order.len()).rev() {
        let c = fl.order[i] as usize;
        let r = fl.rec[c];
        if h.lake_depth[c] > 0.0 {
            let evap = (0.0f64).max((pet_ann[c] as f64) * 0.9 - (e.p_ann[c] as f64)) / 1000.0 / sec_yr * area_m2[c] * 0.5;
            let q0 = q[c];
            let q1 = (0.0f64).max(q0 - evap);
            let sc = if q0 > 0.0 { q1 / q0 } else { 0.0 };
            q[c] = q1;
            qm[c] *= sc;
            qmelt[c] *= sc;
            if q1 <= 0.0 {
                h.lake_kind[c] = if e.aridity[c] < 0.35 { 3 } else { 2 };
            } else {
                h.lake_kind[c] = 1;
            }
        }
        if r >= 0 && t.height[r as usize] > 0.0 {
            let ru = r as usize;
            let (a, b, d) = (q[c], qm[c], qmelt[c]);
            q[ru] += a;
            qm[ru] += b;
            qmelt[ru] += d;
        } else if r >= 0 {
            h.global_discharge += q[c];
        }
    }
    for c in 0..n {
        h.discharge[c] = q[c] as f32;
        h.discharge_max[c] = qm[c] as f32;
        h.snowmelt_frac[c] = if q[c] > 1e-6 { clampv(qmelt[c] / q[c], 0.0, 1.0) as f32 } else { 0.0 };
    }
    // Strahler-like river order
    {
        let mut mx = vec![0u8; n];
        let mut cnt = vec![0u8; n];
        for i in (0..fl.order.len()).rev() {
            let c = fl.order[i] as usize;
            let ord: u8 = if mx[c] == 0 {
                1
            } else if cnt[c] >= 2 {
                mx[c].saturating_add(1)
            } else {
                mx[c]
            };
            h.river_order[c] = if q[c] > 3.0 { ord } else { 0 };
            let r = fl.rec[c];
            if r >= 0 && t.height[r as usize] > 0.0 && h.river_order[c] != 0 {
                let ru = r as usize;
                if ord > mx[ru] {
                    mx[ru] = ord;
                    cnt[ru] = 1;
                } else if ord == mx[ru] {
                    cnt[ru] = cnt[ru].saturating_add(1);
                }
            }
        }
    }

    // ------------------------------------------------------------------ soil, NPP, biomes
    progress("Soils and vegetation", 0.5);
    let s3: Vec<S3> = {
        let ee: &EcoData = &*e;
        let hh: &HydroData = &*h;
        let qr = &q;
        let qmr = &qm;
        par_map(n, |c| {
            let mut o = S3 {
                npp: 0.0,
                biome: B_OCEAN,
                veg: 0.0,
                mineral: 0.0,
                depth: 0.0,
                organic: 0.0,
                fert: 0.0,
                drain: 0.0,
                gw: 0.0,
                delta: 0.0,
                flood: 0.0,
            };
            let ht = t.height[c] as f64;
            if ht <= 0.0 {
                return o;
            }
            let px = fg.pos[c].x as f32;
            let py = fg.pos[c].y as f32;
            let pz = fg.pos[c].z as f32;
            let tc = ee.t_ann[c] as f64;
            let p = ee.p_ann[c] as f64;
            let ai = ee.aridity[c] as f64;
            let qq = qr[c];
            let rip = clampv(dlog(qq.max(1.0)) / 9.210340371976184, 0.0, 1.0);
            let peff = p * (1.0 + 0.5 * rip * (if ai < 0.6 { 1.0 } else { 0.3 }));
            let n_t = 3000.0 / (1.0 + dexp(1.315 - 0.119 * tc));
            let n_p = 3000.0 * (1.0 - dexp(-0.000664 * peff));
            let mut npp = n_t.min(n_p);
            if (ee.t_max[c] as f64) < 8.0 {
                npp *= 0.5;
            }
            o.npp = npp as f32;
            let slope = t.slope[c] as f64;
            // water table / wetness: flat low ground fed by rivers or standing water
            let flat = 1.0 - clampv(slope / 0.003, 0.0, 1.0);
            let wet = clampv(
                0.55 * flat + 0.5 * rip + (if hh.lake_depth[c] > 0.0 { 0.6 } else { 0.0 }) + 0.3 * clampv(ai - 1.0, 0.0, 1.0) - 0.4,
                0.0,
                1.0,
            );
            let mut coastal = false;
            for k in 0..4usize {
                let qn = fg.nbr[c * 8 + k];
                if qn >= 0 && t.height[qn as usize] <= 0.0 {
                    coastal = true;
                }
            }
            let bi = BiomeIn {
                t_ann: tc,
                t_min: ee.t_min[c] as f64,
                t_max: ee.t_max[c] as f64,
                p_ann: p,
                aridity: ai,
                dry_months: (ee.p_dry_frac[c] as f64) * 12.0,
                elev: ht,
                slope,
                wetness: wet,
                lat_abs: (fg.lat[c] as f64).abs() * RAD2DEG,
                coastal,
            };
            let b = classify_biome(&bi);
            o.biome = b;
            if hh.lake_depth[c] > 8.0 && hh.lake_kind[c] != 3 {
                o.biome = B_LAKE;
            }
            let mut veg = clampv(npp / 1400.0, 0.0, 1.0);
            if b == B_ICE {
                veg = 0.0;
            }
            o.veg = veg as f32;
            // parent material richness
            let volc = t.volcanism[c] as f64;
            let alluv = clampv((t.sediment[c] as f64) / 250.0, 0.0, 1.0);
            let mineral = clampv(
                0.30 + 0.9 * volc + 0.5 * alluv + 0.15 * (nz.fbm(px * 7.0, py * 7.0, pz * 7.0, 2) as f64)
                    - 0.25 * ((t.rock_hard[c] as f64) - 0.5) * (1.0 - alluv) * 0.6,
                0.05,
                1.0,
            );
            // weathering and depth
            let weather = clampv(dexp(-sqr((tc - 25.0) / 20.0)) * (1.0 - dexp(-p / 700.0)), 0.0, 1.0);
            let steep = clampv(slope / 0.03, 0.0, 1.0);
            let depth = clampv((0.15 + 2.6 * weather) * (1.0 - 0.85 * steep) + 3.0 * alluv * (1.0 - steep), 0.04, 8.0);
            let decomp = dexp(-(tc - 5.0) / 14.0);
            let om = clampv(npp / 900.0 * clampv(decomp, 0.5, 2.0) * 0.7 + (if b == B_WETLAND { 0.5 } else { 0.0 }), 0.0, 1.0);
            let leach = clampv((p - 2200.0) / 2500.0, 0.0, 1.0) * clampv((tc - 18.0) / 8.0, 0.0, 1.0);
            let dry = clampv(1.0 - ai / 0.35, 0.0, 1.0);
            let mut fert = 0.34 * mineral
                + 0.30 * om
                + 0.14 * clampv(depth / 1.5, 0.0, 1.0)
                + 0.22 * clampv(ee.soil_moist[c] as f64, 0.0, 1.0)
                - 0.30 * leach
                - 0.25 * dry;
            if b == B_ICE {
                fert = 0.0;
            }
            o.mineral = mineral as f32;
            o.depth = depth as f32;
            o.organic = om as f32;
            o.fert = clampv(fert, 0.0, 1.0) as f32;
            o.drain = clampv(0.25 + 0.75 * steep + 0.3 * (1.0 - alluv) - 0.5 * wet, 0.0, 1.0) as f32;
            o.gw = clampv(
                0.5 * clampv(ai, 0.0, 1.5) / 1.5 + 0.5 * (1.0 - steep) * clampv((t.sediment[c] as f64) / 120.0 + 0.3, 0.0, 1.0),
                0.0,
                1.0,
            ) as f32;
            // deltas / floodplains
            let mut dl = 0.0f64;
            if coastal && qq > 50.0 && slope < 0.0015 {
                dl = clampv(dlog(qq / 50.0) / 4.605170185988092, 0.0, 1.0);
            }
            o.delta = dl.max(alluv * 0.5 * flat * rip) as f32;
            let fl2 = clampv(dlog((1.0f64).max(qmr[c])) / 12.664370, 0.0, 1.0) * flat * (0.4 + 0.6 * clampv(p / 1500.0, 0.0, 1.0));
            o.flood = clampv(fl2, 0.0, 1.0) as f32;
            o
        })
    };
    let mut veg_f = vec![0f32; n];
    for c in 0..n {
        let s = &s3[c];
        e.npp[c] = s.npp;
        e.biome[c] = s.biome;
        veg_f[c] = s.veg;
        e.mineral[c] = s.mineral;
        e.soil_depth[c] = s.depth;
        e.organic[c] = s.organic;
        e.fertility[c] = s.fert;
        e.drainage[c] = s.drain;
        h.gw[c] = s.gw;
        h.delta[c] = s.delta;
        h.flood[c] = s.flood;
    }
    drop(s3);

    // ------------------------------------------------------------------ resources and hazards
    progress("Resources and hazards", 0.75);
    let s4: Vec<S4> = {
        let ee: &EcoData = &*e;
        let hh: &HydroData = &*h;
        par_map(n, |c| {
            let px = fg.pos[c].x as f32;
            let py = fg.pos[c].y as f32;
            let pz = fg.pos[c].z as f32;
            let ht = t.height[c] as f64;
            let land = ht > 0.0;
            let sed = clampv((t.sediment[c] as f64) / 300.0, 0.0, 1.0);
            let orog = t.orogeny[c] as f64;
            let volc = t.volcanism[c] as f64;
            let cf = t.cf[c] as f64;
            let patch = |f: f32, off: f32| -> f64 {
                let v = nz.fbm(px * f + off, py * f, pz * f - off, 3) as f64;
                smoothstep(-0.05, 0.45, v)
            };
            let rh = t.rock_hard[c] as f64;
            let shield = clampv((cf - 0.8) * 5.0, 0.0, 1.0) * (1.0 - orog) * (0.4 + 0.6 * rh) * (1.0 - sed);
            let iron = 0.9 * shield * patch(14.0, 1.0) + 0.5 * orog * patch(20.0, 5.0) + 0.4 * volc * patch(25.0, 9.0);
            let arc = t.btype[c] == 1 && (t.bdist[c] as f64) < 500.0;
            let copper = (if arc { 1.0 } else { 0.25 }) * clampv(1.4 * volc + 0.9 * orog, 0.0, 1.0) * patch(22.0, 3.0);
            let humid = if land { smoothstep(600.0, 1400.0, ee.p_ann[c] as f64) } else { 0.5 };
            let coal = clampv(sed * 1.3, 0.0, 1.0) * (0.35 + 0.65 * humid) * (if cf > 0.5 { 1.0 } else { 0.0 }) * patch(12.0, 7.0) * (1.0 - 0.7 * orog);
            let shelf = ht > -400.0 && ht < 250.0 && cf > 0.3;
            let oil = clampv(sed * 1.5, 0.0, 1.0) * (if shelf { 1.0 } else { 0.3 }) * patch(11.0, 2.0);
            let gas = clampv(0.55 * oil + 0.5 * coal * patch(16.0, 4.0), 0.0, 1.0);
            let gold = clampv(0.9 * orog + 0.8 * volc + 0.3 * shield, 0.0, 1.0) * sqr(patch(30.0, 6.0));
            let mut salt = 0.0f64;
            if land {
                salt = (if hh.lake_kind[c] == 3 { 1.0 } else { 0.0 })
                    + (if ee.aridity[c] < 0.25 { 0.8 } else { 0.0 })
                        * (if t.slope[c] < 0.002 { 1.0 } else { 0.2 })
                        * (0.3 + sed)
                        * patch(10.0, 8.0);
            } else if ht > -200.0 && ee.aridity[c] < 0.3 {
                salt = 0.5;
            }
            let mut timber = 0.0f64;
            let b = ee.biome[c];
            if b == B_RAINFOREST || b == B_SEASONAL_FOREST || b == B_TEMP_FOREST || b == B_BOREAL || b == B_MANGROVE {
                timber = clampv((ee.npp[c] as f64) / 1300.0, 0.0, 1.0);
            }
            let v = [iron, copper, coal, oil, gas, gold, salt, timber];
            let mut res = [0u8; R_COUNT];
            for r in 0..R_COUNT {
                let mut x = v[r];
                if !land && (r == R_COAL || r == R_IRON || r == R_TIMBER || r == R_COPPER) {
                    x = 0.0;
                }
                res[r] = clampv(x * 255.0, 0.0, 255.0) as u8;
            }
            // hazards
            let seis = clampv((t.seismic[c] as f64) * 1.2 + 0.02, 0.0, 1.0);
            let sat = clampv(ee.soil_moist[c] as f64, 0.0, 1.0);
            let steep = clampv((t.slope[c] as f64) / 0.04, 0.0, 1.0);
            let slide = if land {
                clampv(
                    steep * (0.35 + 0.65 * sat) * (0.5 + 0.5 * clampv((ee.p_ann[c] as f64) / 1500.0, 0.0, 1.0)) * (1.0 - 0.4 * rh)
                        + 0.3 * seis * steep,
                    0.0,
                    1.0,
                ) as f32
            } else {
                0.0
            };
            let dr = clampv(1.0 - (ee.aridity[c] as f64) / 0.9, 0.0, 1.0) * (0.5 + 0.5 * clampv((ee.p_dry_frac[c] as f64) * 2.0, 0.0, 1.0));
            S4 {
                res,
                seis: seis as f32,
                volc: clampv((t.volcanism[c] as f64) * 1.3, 0.0, 1.0) as f32,
                slide,
                drought: if land { dr as f32 } else { 0.0 },
            }
        })
    };
    for c in 0..n {
        let s = &s4[c];
        for r in 0..R_COUNT {
            e.res[r][c] = s.res[r];
        }
        e.seismic_haz[c] = s.seis;
        e.volc_haz[c] = s.volc;
        e.slide_haz[c] = s.slide;
        e.flood_haz[c] = h.flood[c];
        e.drought_haz[c] = s.drought;
    }
    drop(s4);

    // ------------------------------------------------------------------ feedback fields for the climate (coarse)
    *veg_coarse = vec![0f32; nc];
    *soil_cap_coarse = vec![150f32; nc];
    *glacier_coarse = vec![0f32; nc];
    {
        let mut sv = vec![0f64; nc];
        let mut sa = vec![0f64; nc];
        let mut sc = vec![0f64; nc];
        let ratio = fg.n / cg.n;
        for c in 0..n {
            if t.height[c] <= 0.0 {
                continue;
            }
            let (f, i, j) = fg.unpack(c);
            let cc = cg.idx(f, i / ratio, j / ratio);
            let a = fg.area[c] as f64;
            sv[cc] += a * (veg_f[c] as f64);
            sc[cc] += a * (60.0 + 90.0 * (e.soil_depth[c] as f64));
            sa[cc] += a;
        }
        for c in 0..nc {
            veg_coarse[c] = if sa[c] > 0.0 { (sv[c] / sa[c]) as f32 } else { 0.0 };
            soil_cap_coarse[c] = if sa[c] > 0.0 { clampv(sc[c] / sa[c], 60.0, 400.0) as f32 } else { 150.0 };
            glacier_coarse[c] = if sl.glacier.len() == nc { sl.glacier[c] } else { 0.0 };
        }
    }
    progress("Ecosystems complete", 1.0);
}
