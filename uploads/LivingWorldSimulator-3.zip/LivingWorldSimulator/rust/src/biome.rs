//! Biomes are never painted: they are derived from the simulated climate, soil water and terrain.

use crate::world_data::*;

#[derive(Clone, Copy, Debug)]
pub struct BiomeIn {
    pub t_ann: f64,      // mean annual temperature (C)
    pub t_min: f64,      // coldest month (C)
    pub t_max: f64,      // warmest month (C)
    pub p_ann: f64,      // mm / yr
    pub aridity: f64,    // precipitation / potential evapotranspiration
    pub dry_months: f64, // months with < 60 mm
    pub elev: f64,       // m above sea level
    pub slope: f64,      // m/m
    pub wetness: f64,    // 0..1 water table / river proximity
    pub lat_abs: f64,    // degrees
    pub coastal: bool,
}

/// lat_abs_fn() supplies |latitude| in degrees only when a rule actually needs it (it is expensive per texel).
pub fn classify_biome_lazy<F: Fn() -> f64>(b: &BiomeIn, lat_abs_fn: F) -> u8 {
    if b.t_max < -2.0 || b.t_ann < -16.0 {
        return B_ICE;
    }
    if b.aridity < 0.10 || b.p_ann < 130.0 {
        return B_DESERT;
    }
    if b.t_max < 10.0 {
        return if b.elev > 1400.0 && lat_abs_fn() < 62.0 { B_ALPINE } else { B_TUNDRA };
    }
    if b.wetness > 0.82 && b.aridity > 0.9 && b.slope < 0.0015 && b.elev < 1800.0 {
        if b.coastal && b.t_min > 14.0 && b.elev < 12.0 {
            return B_MANGROVE;
        }
        return B_WETLAND;
    }
    if b.t_min >= 15.0 {
        if b.p_ann > 1900.0 && b.dry_months <= 2.5 {
            return B_RAINFOREST;
        }
        if b.aridity > 0.85 {
            return B_SEASONAL_FOREST;
        }
        if b.aridity > 0.40 {
            return B_SAVANNA;
        }
        if b.aridity > 0.18 {
            return B_SEMIARID;
        }
        return B_DESERT;
    }
    if b.t_ann < 3.5 {
        if b.aridity > 0.45 && b.t_max >= 10.0 {
            return B_BOREAL;
        }
        if b.aridity > 0.25 {
            return B_TUNDRA;
        }
        return B_DESERT;
    }
    if b.t_ann >= 18.0 {
        if b.aridity > 0.85 {
            return B_TEMP_FOREST;
        }
        if b.aridity > 0.45 {
            return B_SAVANNA;
        }
        if b.aridity > 0.20 {
            return B_SEMIARID;
        }
        return B_DESERT;
    }
    if b.aridity > 0.80 && b.p_ann > 600.0 {
        return B_TEMP_FOREST;
    }
    if b.aridity > 0.45 {
        return B_GRASSLAND;
    }
    if b.aridity > 0.22 {
        return B_SEMIARID;
    }
    B_DESERT
}

pub fn classify_biome(b: &BiomeIn) -> u8 {
    let l = b.lat_abs;
    classify_biome_lazy(b, || l)
}

const NAMES: [&str; 15] = [
    "Ocean",
    "Tropical rainforest",
    "Tropical seasonal forest",
    "Savanna",
    "Desert",
    "Semi-arid steppe",
    "Temperate grassland",
    "Temperate forest",
    "Boreal forest",
    "Tundra",
    "Alpine",
    "Wetland",
    "Mangrove",
    "Ice / polar desert",
    "Lake",
];

pub fn biome_name(b: i32) -> &'static str {
    if b < 0 || b >= 15 {
        NAMES[0]
    } else {
        NAMES[b as usize]
    }
}

const COLORS: [[f32; 3]; 15] = [
    [0.02, 0.10, 0.25],
    [0.07, 0.35, 0.10],
    [0.22, 0.45, 0.14],
    [0.62, 0.58, 0.24],
    [0.80, 0.68, 0.45],
    [0.66, 0.60, 0.34],
    [0.46, 0.60, 0.22],
    [0.14, 0.38, 0.14],
    [0.12, 0.30, 0.20],
    [0.52, 0.52, 0.42],
    [0.48, 0.46, 0.42],
    [0.20, 0.42, 0.34],
    [0.12, 0.34, 0.24],
    [0.93, 0.95, 0.97],
    [0.10, 0.25, 0.45],
];

pub fn biome_color(b: i32) -> (f32, f32, f32) {
    let i = if b < 0 || b >= 15 { 0usize } else { b as usize };
    (COLORS[i][0], COLORS[i][1], COLORS[i][2])
}
