//! Data containers shared by all simulation stages.
//! Fine grid  (terrain / hydrology / ecology): NT x NT cells per cube face.
//! Coarse grid (climate): NC x NC cells per cube face.

use crate::mathx::*;

pub const NT: i32 = 192; // fine terrain grid resolution (6*192^2 = 221k cells, ~52 km)
pub const NC: i32 = 64; // coarse climate grid resolution (6*64^2 = 24.6k cells, ~157 km)
pub const NSLICE: usize = 12; // climate slices per orbital year

pub const B_OCEAN: u8 = 0;
pub const B_RAINFOREST: u8 = 1;
pub const B_SEASONAL_FOREST: u8 = 2;
pub const B_SAVANNA: u8 = 3;
pub const B_DESERT: u8 = 4;
pub const B_SEMIARID: u8 = 5;
pub const B_GRASSLAND: u8 = 6;
pub const B_TEMP_FOREST: u8 = 7;
pub const B_BOREAL: u8 = 8;
pub const B_TUNDRA: u8 = 9;
pub const B_ALPINE: u8 = 10;
pub const B_WETLAND: u8 = 11;
pub const B_MANGROVE: u8 = 12;
pub const B_ICE: u8 = 13;
pub const B_LAKE: u8 = 14;
pub const B_COUNT: u8 = 15;

pub const R_IRON: usize = 0;
pub const R_COPPER: usize = 1;
pub const R_COAL: usize = 2;
pub const R_OIL: usize = 3;
pub const R_GAS: usize = 4;
pub const R_GOLD: usize = 5;
pub const R_SALT: usize = 6;
pub const R_TIMBER: usize = 7;
pub const R_COUNT: usize = 8;

/// progress callback: (stage text, 0..1)
pub type Progress<'a> = &'a dyn Fn(&str, f32);

// ---- geology / terrain (fine grid) -------------------------------------------------
#[derive(Default, Clone)]
pub struct TerrainData {
    pub n: i32,
    // tectonic context
    pub plate: Vec<u8>,
    pub plate2: Vec<u8>,
    pub btype: Vec<u8>,
    pub bdist: Vec<f32>,
    pub conv: Vec<f32>,
    pub cf: Vec<f32>,
    pub crust_age: Vec<f32>,
    pub thickness: Vec<f32>,
    pub volcanism: Vec<f32>,
    pub seismic: Vec<f32>,
    pub orogeny: Vec<f32>,
    pub target: Vec<f32>,
    // surface
    pub height: Vec<f32>,   // metres above sea level (sea level = 0)
    pub sediment: Vec<f32>, // metres of sediment laid down during erosion
    pub rough: Vec<f32>,    // 0..1 roughness used for detail synthesis
    pub slope: Vec<f32>,    // m / m
    pub rock_hard: Vec<f32>, // 0..1
    pub sea_level_raw: f64, // pre-shift elevation (m) that became sea level
    pub land_fraction: f64,
    pub volcanoes: Vec<i32>, // fine-cell indices of notable volcanoes
}

// ---- hydrology (fine grid, uses climate) -------------------------------------------
#[derive(Default, Clone)]
pub struct HydroData {
    pub rec: Vec<i32>,           // flow receiver (-1 for ocean)
    pub fill: Vec<f32>,          // filled elevation (metres); > height inside lakes
    pub lake_level: Vec<f32>,    // surface elevation of standing water (== height where none)
    pub lake_depth: Vec<f32>,    // metres
    pub discharge: Vec<f32>,     // mean annual discharge m^3/s
    pub discharge_max: Vec<f32>, // peak-month discharge m^3/s
    pub runoff: Vec<f32>,        // mean annual runoff mm/yr
    pub snowmelt_frac: Vec<f32>, // share of discharge from snow/ice melt
    pub gw: Vec<f32>,            // groundwater storage index 0..1
    pub river_order: Vec<u8>,    // Strahler-like order (0 = not a river)
    pub lake_kind: Vec<u8>,      // 0 none, 1 through-flow, 2 closed (terminal), 3 salt flat
    pub delta: Vec<f32>,         // delta / alluvial index 0..1
    pub flood: Vec<f32>,         // 0..1
    pub global_discharge: f64,   // m^3/s into oceans
}

// ---- ecology (fine grid) -----------------------------------------------------------
#[derive(Default, Clone)]
pub struct EcoData {
    pub t_ann: Vec<f32>,
    pub t_min: Vec<f32>,
    pub t_max: Vec<f32>,
    pub p_ann: Vec<f32>,
    pub p_dry_frac: Vec<f32>,
    pub aridity: Vec<f32>,
    pub soil_moist: Vec<f32>,
    pub npp: Vec<f32>, // climate summaries (downscaled)
    pub fertility: Vec<f32>,
    pub soil_depth: Vec<f32>,
    pub mineral: Vec<f32>,
    pub organic: Vec<f32>,
    pub drainage: Vec<f32>, // soil (0..1 except depth m)
    pub biome: Vec<u8>,
    pub res: [Vec<u8>; R_COUNT], // resource potential 0..255
    pub seismic_haz: Vec<f32>,
    pub volc_haz: Vec<f32>,
    pub flood_haz: Vec<f32>,
    pub slide_haz: Vec<f32>,
    pub drought_haz: Vec<f32>, // 0..1
}

// ---- climate (coarse grid) ---------------------------------------------------------
#[derive(Default, Clone)]
pub struct ClimateSlices {
    // all arrays: NSLICE * ncell
    pub ta: Vec<f32>,
    pub ts: Vec<f32>,
    pub precip: Vec<f32>,
    pub wvap: Vec<f32>,
    pub cloud: Vec<f32>,
    pub snow: Vec<f32>,
    pub ice: Vec<f32>,
    pub wu: Vec<f32>,
    pub wv: Vec<f32>,
    pub pres: Vec<f32>,
    pub runoff: Vec<f32>,
    pub glacier: Vec<f32>, // thickness (m) of permanent land ice, annual
}

#[derive(Clone)]
pub struct ClimateStatic {
    pub z_mean: Vec<f32>,
    pub land_frac: Vec<f32>,
    pub z_max: Vec<f32>,
    pub relief: Vec<f32>,
    pub ocean: Vec<f32>,
    pub veg: Vec<f32>,
    pub albedo_land: Vec<f32>,
    pub soil_cap: Vec<f32>,
    pub psi: Vec<f32>, // ocean stream function and surface currents (east/north m/s), annual mean
    pub cu: Vec<f32>,
    pub cv: Vec<f32>,
    pub upwell: Vec<f32>,   // upwelling rate m/s
    pub itcz_lat: Vec<f32>, // per longitude bin (36)
    pub hadley_deg: f64,
    pub global_mean_t: f64,
    pub global_mean_p: f64,
    pub global_mean_e: f64,
    pub albedo_p: f64,
    pub water_imbalance: f64,
}

impl Default for ClimateStatic {
    fn default() -> ClimateStatic {
        ClimateStatic {
            z_mean: Vec::new(),
            land_frac: Vec::new(),
            z_max: Vec::new(),
            relief: Vec::new(),
            ocean: Vec::new(),
            veg: Vec::new(),
            albedo_land: Vec::new(),
            soil_cap: Vec::new(),
            psi: Vec::new(),
            cu: Vec::new(),
            cv: Vec::new(),
            upwell: Vec::new(),
            itcz_lat: Vec::new(),
            hadley_deg: 30.0,
            global_mean_t: 288.0,
            global_mean_p: 0.0,
            global_mean_e: 0.0,
            albedo_p: 0.3,
            water_imbalance: 0.0,
        }
    }
}

// ---------------------------------------------------------------------------
// tiny parallel helpers (std only)
// ---------------------------------------------------------------------------
pub fn num_threads() -> usize {
    let n = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(2);
    // leave one core for the UI / render thread while the planet is generated or updated
    clampv(if n > 2 { n - 1 } else { n }, 1, 6)
}

/// Compute f(0..n) on all cores and return the results in index order (deterministic).
pub fn par_map<T: Send, F: Fn(usize) -> T + Sync>(n: usize, f: F) -> Vec<T> {
    let nt = num_threads();
    if nt <= 1 || n < 512 {
        let mut out: Vec<T> = Vec::with_capacity(n);
        for i in 0..n {
            out.push(f(i));
        }
        return out;
    }
    let chunk = (n + nt - 1) / nt;
    let mut parts: Vec<Vec<T>> = Vec::new();
    std::thread::scope(|s| {
        let mut handles = Vec::new();
        for t in 0..nt {
            let lo = t * chunk;
            let hi = std::cmp::min((t + 1) * chunk, n);
            if lo >= hi {
                break;
            }
            let fr = &f;
            handles.push(s.spawn(move || {
                let mut v: Vec<T> = Vec::with_capacity(hi - lo);
                for i in lo..hi {
                    v.push(fr(i));
                }
                v
            }));
        }
        for h in handles {
            match h.join() {
                Ok(v) => parts.push(v),
                Err(e) => std::panic::resume_unwind(e),
            }
        }
    });
    let mut out: Vec<T> = Vec::with_capacity(n);
    for p in parts {
        out.extend(p);
    }
    out
}

/// Run f(lo, hi) over index ranges on all cores (for jobs that write through their own channels).
pub fn par_ranges<F: Fn(usize, usize) + Sync>(n: usize, f: F) {
    let nt = num_threads();
    if nt <= 1 || n < 512 {
        f(0, n);
        return;
    }
    let chunk = (n + nt - 1) / nt;
    std::thread::scope(|s| {
        let mut handles = Vec::new();
        for t in 0..nt {
            let lo = t * chunk;
            let hi = std::cmp::min((t + 1) * chunk, n);
            if lo >= hi {
                break;
            }
            let fr = &f;
            handles.push(s.spawn(move || {
                fr(lo, hi);
            }));
        }
        for h in handles {
            if let Err(e) = h.join() {
                std::panic::resume_unwind(e);
            }
        }
    });
}
