//! Orbit camera around a point on the globe. Everything is kept in double precision and the view is
//! rendered camera-relative, so there is no jitter from planet-scale coordinates down to metres.
//!
//! Dragging is "grab the globe": the surface point under the finger stays under the finger (scaled down
//! when the planet is small on screen), so rotation speed is natural at every zoom level. Releasing a
//! drag starts a gentle angular inertia that is capped and fades quickly.

use crate::mathx::*;

#[derive(Clone)]
pub struct Camera {
    pub radius: f64,
    c: V3,
    heading: f64,
    tilt: f64,
    dist: f64,
    dist_goal: f64,
    pub target_height: f64,
    spin_axis: V3,
    spin_speed: f64,
    fly_axis: V3,
    fly_total: f64,
    fly_t: f64,
    fly_dur: f64,
    fly_active: bool,
    pub fov_y: f64,
    pub view_w: f64,
    pub view_h: f64,
    // derived
    pub pos: V3,
    pub fwd: V3,
    pub up: V3,
    pub right: V3,
    pub altitude: f64,
    pub pos_len: f64,
    pub near: f32,
    pub far: f32,
    pub vp: [f32; 16],
    planes: [f32; 24],
    pub focal_px: f64,
}

fn smooth(a: f64, b: f64, x: f64) -> f64 {
    smoothstep(a, b, x)
}

impl Camera {
    pub fn new() -> Camera {
        let mut c = Camera {
            radius: 6371000.0,
            c: V3::new(1.0, 0.0, 0.0),
            heading: 0.0,
            tilt: 0.0,
            dist: 2.6e7,
            dist_goal: 2.6e7,
            target_height: 0.0,
            spin_axis: V3::new(0.0, 0.0, 1.0),
            spin_speed: 0.0,
            fly_axis: V3::new(0.0, 0.0, 1.0),
            fly_total: 0.0,
            fly_t: 0.0,
            fly_dur: 1.0,
            fly_active: false,
            fov_y: 50.0 * DEG2RAD,
            view_w: 1.0,
            view_h: 1.0,
            pos: V3::new(0.0, 0.0, 0.0),
            fwd: V3::new(-1.0, 0.0, 0.0),
            up: V3::new(0.0, 0.0, 1.0),
            right: V3::new(0.0, 1.0, 0.0),
            altitude: 1.0,
            pos_len: 1.0,
            near: 1.0,
            far: 1.0e7,
            vp: [0.0; 16],
            planes: [0.0; 24],
            focal_px: 1000.0,
        };
        c.compute_pose();
        c
    }

    pub fn set_viewport(&mut self, w: f64, h: f64) {
        self.view_w = if w < 1.0 { 1.0 } else { w };
        self.view_h = if h < 1.0 { 1.0 } else { h };
        self.focal_px = self.view_h / (2.0 * (self.fov_y / 2.0).tan());
    }

    pub fn reset(&mut self, radius: f64) {
        self.radius = radius;
        self.dist = radius * 4.0;
        self.dist_goal = self.dist;
        self.tilt = 0.0;
        self.heading = 0.0;
        self.stop_motion();
    }

    pub fn set_center(&mut self, lat_deg: f64, lon_deg: f64) {
        self.c = from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD);
    }

    pub fn lat_deg(&self) -> f64 {
        lat_of(self.c) * RAD2DEG
    }
    pub fn lon_deg(&self) -> f64 {
        lon_of(self.c) * RAD2DEG
    }
    pub fn center_dir(&self) -> V3 {
        self.c
    }
    pub fn dist(&self) -> f64 {
        self.dist
    }

    pub fn stop_motion(&mut self) {
        self.spin_speed = 0.0;
        self.fly_active = false;
    }

    // ------------------------------------------------------------------ pose

    fn heading_dir(&self) -> V3 {
        let (e, n) = east_north(self.c);
        let (sh, ch) = dsincos(self.heading);
        e * sh + n * ch
    }

    pub fn compute_pose(&mut self) {
        let h = self.heading_dir();
        let (st, ct) = dsincos(self.tilt);
        let tr = self.radius + self.target_height;
        let t = self.c * tr;
        self.pos = t + (self.c * ct - h * st) * self.dist;
        self.fwd = self.c * (-ct) + h * st;
        self.up = self.c * st + h * ct;
        self.right = cross(self.fwd, self.up);
        self.pos_len = length(self.pos);
        self.altitude = (1.0f64).max(self.pos_len - tr);
    }

    /// ray through a screen pixel (origin top-left)
    fn ray_dir(&self, x: f64, y: f64) -> V3 {
        let nx = (x / self.view_w) * 2.0 - 1.0;
        let ny = 1.0 - (y / self.view_h) * 2.0;
        let th = (self.fov_y / 2.0).tan();
        let aspect = self.view_w / self.view_h;
        normalize(self.fwd + self.right * (nx * th * aspect) + self.up * (ny * th))
    }

    /// unit direction (from the planet centre) of the surface point under a pixel; if the ray misses the globe
    /// the nearest point of the silhouette is used, so dragging beyond the limb still spins the planet smoothly
    pub fn grab_dir(&self, x: f64, y: f64) -> V3 {
        let d = self.ray_dir(x, y);
        let rs = self.radius + self.target_height;
        let b = dot(self.pos, d);
        let cc = dot(self.pos, self.pos) - rs * rs;
        let disc = b * b - cc;
        if disc >= 0.0 {
            let t = -b - disc.sqrt();
            if t > 0.0 {
                return normalize(self.pos + d * t);
            }
        }
        // closest approach of the ray to the planet centre, pushed out to the silhouette
        normalize(self.pos + d * (-b))
    }

    fn drag_gain(&self) -> f64 {
        let a = self.dist / self.radius;
        lerpd(1.0, 0.42, smooth(0.12, 1.5, a))
    }

    /// Move the camera so the surface under (x0,y0) follows the finger to (x1,y1). Returns (axis, angle) applied.
    pub fn drag(&mut self, x0: f64, y0: f64, x1: f64, y1: f64) -> (V3, f64) {
        self.compute_pose();
        let p0 = self.grab_dir(x0, y0);
        let p1 = self.grab_dir(x1, y1);
        let ax = cross(p1, p0);
        let s = length(ax);
        if s < 1e-13 {
            return (V3::new(0.0, 0.0, 1.0), 0.0);
        }
        let ang = datan2(s, dot(p1, p0)) * self.drag_gain();
        let axis = ax * (1.0 / s);
        self.rotate_by(axis, ang);
        self.compute_pose();
        (axis, ang)
    }

    /// rigid rotation of the whole view about the planet centre
    pub fn rotate_by(&mut self, axis: V3, ang: f64) {
        if ang == 0.0 {
            return;
        }
        let h = self.heading_dir();
        let c2 = normalize(rotate_axis(self.c, axis, ang));
        let h2 = rotate_axis(h, axis, ang);
        self.c = c2;
        let (e2, n2) = east_north(c2);
        self.heading = datan2(dot(h2, e2), dot(h2, n2));
    }

    pub fn zoom_by(&mut self, factor: f64) {
        self.dist_goal = clampv(self.dist_goal * factor, self.min_dist(), self.radius * 4.6);
    }

    pub fn rotate_heading(&mut self, d: f64) {
        self.heading += d;
    }

    pub fn tilt_by(&mut self, d: f64) {
        self.tilt = clampv(self.tilt + d, 0.0, 1.35);
    }

    fn min_dist(&self) -> f64 {
        60.0
    }

    pub fn start_spin(&mut self, omega: V3, cap: f64) {
        let sp = length(omega);
        if sp < 1e-6 {
            self.spin_speed = 0.0;
            return;
        }
        self.spin_axis = omega * (1.0 / sp);
        self.spin_speed = if sp > cap { cap } else { sp };
    }

    /// glide to a surface point and zoom (double tap)
    pub fn fly_to(&mut self, dir: V3, goal_dist: f64, dur: f64) {
        let ax = cross(self.c, dir);
        let s = length(ax);
        let ang = datan2(s, dot(self.c, dir));
        if s > 1e-12 {
            self.fly_axis = ax * (1.0 / s);
            self.fly_total = ang;
        } else {
            self.fly_axis = V3::new(0.0, 0.0, 1.0);
            self.fly_total = 0.0;
        }
        self.fly_t = 0.0;
        self.fly_dur = if dur < 0.05 { 0.05 } else { dur };
        self.fly_active = true;
        self.spin_speed = 0.0;
        self.dist_goal = clampv(goal_dist, self.min_dist(), self.radius * 4.6);
    }

    pub fn dist_goal(&self) -> f64 {
        self.dist_goal
    }

    /// per-frame motion: inertia, glide animation, smooth zoom
    pub fn step(&mut self, dt: f64) {
        if self.fly_active {
            let t0 = self.fly_t / self.fly_dur;
            self.fly_t += dt;
            let t1 = if self.fly_t >= self.fly_dur { 1.0 } else { self.fly_t / self.fly_dur };
            let e0 = t0 * t0 * (3.0 - 2.0 * t0);
            let e1 = t1 * t1 * (3.0 - 2.0 * t1);
            let ax = self.fly_axis;
            let da = self.fly_total * (e1 - e0);
            self.rotate_by(ax, da);
            if t1 >= 1.0 {
                self.fly_active = false;
            }
        } else if self.spin_speed > 0.0 {
            if self.spin_speed < 0.004 {
                self.spin_speed = 0.0;
            } else {
                let ax = self.spin_axis;
                let a = self.spin_speed * dt;
                self.rotate_by(ax, a);
                self.spin_speed *= dexp(-4.2 * dt);
            }
        }
        if (self.dist - self.dist_goal).abs() > 1e-6 * self.dist {
            let k = 1.0 - dexp(-14.0 * dt);
            let l = dlog(self.dist) + (dlog(self.dist_goal) - dlog(self.dist)) * k;
            self.dist = dexp(l);
        } else {
            self.dist = self.dist_goal;
        }
    }

    pub fn update(&mut self) {
        // tilt is only meaningful when close to the ground
        let tilt_max = 1.35 * (1.0 - smooth(0.4 * self.radius, 1.6 * self.radius, self.dist));
        if self.tilt > tilt_max {
            self.tilt += (tilt_max - self.tilt) * 0.2;
        }
        self.compute_pose();
        let tr = self.radius + self.target_height;
        let horizon = (self.pos_len * self.pos_len - self.radius * self.radius).max(0.0).sqrt();
        let near = (1.0f64).max((self.altitude * 0.12).min(3.0e6));
        let far = (horizon + 400000.0).min(self.pos_len + self.radius).max(near * 20.0);
        let _ = tr;
        self.near = near as f32;
        self.far = far as f32;
        // view rotation (camera-relative, column-major) and projection
        let mut view = [0f32; 16];
        view[0] = self.right.x as f32;
        view[4] = self.right.y as f32;
        view[8] = self.right.z as f32;
        view[1] = self.up.x as f32;
        view[5] = self.up.y as f32;
        view[9] = self.up.z as f32;
        view[2] = (-self.fwd.x) as f32;
        view[6] = (-self.fwd.y) as f32;
        view[10] = (-self.fwd.z) as f32;
        view[15] = 1.0;
        let aspect = self.view_w / self.view_h;
        let f = 1.0 / (self.fov_y / 2.0).tan();
        let nr = self.near as f64;
        let fr = self.far as f64;
        let mut proj = [0f32; 16];
        proj[0] = (f / aspect) as f32;
        proj[5] = f as f32;
        proj[10] = ((fr + nr) / (nr - fr)) as f32;
        proj[11] = -1.0;
        proj[14] = (2.0 * fr * nr / (nr - fr)) as f32;
        // vp = proj * view (column-major)
        let mut vp = [0f32; 16];
        for col in 0..4usize {
            for row in 0..4usize {
                let mut s = 0.0f32;
                for k in 0..4usize {
                    s += proj[k * 4 + row] * view[col * 4 + k];
                }
                vp[col * 4 + row] = s;
            }
        }
        self.vp = vp;
        // frustum planes (camera-relative space)
        for i in 0..4usize {
            let s: f32 = if i % 2 == 0 { 1.0 } else { -1.0 };
            let r = i / 2;
            for k in 0..4usize {
                self.planes[i * 4 + k] = vp[k * 4 + 3] + s * vp[k * 4 + r];
            }
        }
        for k in 0..4usize {
            self.planes[16 + k] = vp[k * 4 + 3] + vp[k * 4 + 2];
            self.planes[20 + k] = vp[k * 4 + 3] - vp[k * 4 + 2];
        }
        for i in 0..6usize {
            let a = self.planes[i * 4];
            let b = self.planes[i * 4 + 1];
            let c = self.planes[i * 4 + 2];
            let l = (a * a + b * b + c * c).sqrt();
            if l > 0.0 {
                self.planes[i * 4] /= l;
                self.planes[i * 4 + 1] /= l;
                self.planes[i * 4 + 2] /= l;
                self.planes[i * 4 + 3] /= l;
            }
        }
    }

    /// Is a sphere (centre relative to the camera, radius in metres) possibly inside the frustum?
    pub fn sphere_visible(&self, x: f64, y: f64, z: f64, r: f64) -> bool {
        for i in 0..6usize {
            let d = (self.planes[i * 4] as f64) * x
                + (self.planes[i * 4 + 1] as f64) * y
                + (self.planes[i * 4 + 2] as f64) * z
                + (self.planes[i * 4 + 3] as f64);
            if d < -r {
                return false;
            }
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grab_keeps_surface_under_finger_when_close() {
        let mut c = Camera::new();
        c.set_viewport(1800.0, 810.0);
        c.reset(6371000.0);
        c.zoom_by(0.05);
        for _ in 0..200 {
            c.step(0.016);
        }
        c.compute_pose();
        let before = c.grab_dir(900.0, 405.0);
        let (_ax, _ang) = c.drag(900.0, 405.0, 1000.0, 405.0);
        c.compute_pose();
        let after = c.grab_dir(1000.0, 405.0);
        // with gain < 1 the point is not exactly under the finger, but it must have moved the right way
        assert!(dot(before, after) > 0.99);
    }

    #[test]
    fn far_drag_is_slower_than_close_drag() {
        let mut far = Camera::new();
        far.set_viewport(1800.0, 810.0);
        far.reset(6371000.0);
        let (_a, ang_far) = far.drag(900.0, 405.0, 1000.0, 405.0);
        let mut near = Camera::new();
        near.set_viewport(1800.0, 810.0);
        near.reset(6371000.0);
        near.zoom_by(0.06);
        for _ in 0..300 {
            near.step(0.016);
        }
        let (_b, ang_near) = near.drag(900.0, 405.0, 1000.0, 405.0);
        assert!(ang_far.abs() > 0.0 && ang_near.abs() > 0.0);
        assert!(ang_far.abs() < 0.5);
    }
}
