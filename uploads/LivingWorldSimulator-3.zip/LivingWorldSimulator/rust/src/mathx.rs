//! Deterministic math (IEEE basic operations only), vectors, RNG and hashing.
//! The generation path never calls libm trig/exp/log, so a seed produces the same planet on every device.

use std::ops::{Add, AddAssign, Mul, MulAssign, Neg, Sub, SubAssign};

pub const PI: f64 = 3.14159265358979323846;
pub const TAU: f64 = 6.28318530717958647692;
pub const DEG2RAD: f64 = PI / 180.0;
pub const RAD2DEG: f64 = 180.0 / PI;

// ---------------------------------------------------------------------------
// exact 2^k and mantissa/exponent split (no libm)
// ---------------------------------------------------------------------------
#[inline]
pub fn pow2i(k: i32) -> f64 {
    let kk = if k < -1022 { -1022 } else if k > 1023 { 1023 } else { k };
    f64::from_bits(((kk + 1023) as u64) << 52)
}

#[inline]
pub fn ldexp(x: f64, k: i32) -> f64 {
    // split in two steps so |k| up to ~2000 never overflows the 2^k construction
    let k1 = k / 2;
    let k2 = k - k1;
    x * pow2i(k1) * pow2i(k2)
}

/// x = m * 2^e with m in [0.5, 1). x must be finite and > 0.
pub fn frexp(x: f64) -> (f64, i32) {
    let mut v = x;
    let mut adj = 0i32;
    if v < 2.2250738585072014e-308 {
        v *= 18014398509481984.0; // 2^54
        adj = -54;
    }
    let bits = v.to_bits();
    let e = (((bits >> 52) & 0x7ff) as i32) - 1022;
    let mbits = (bits & 0x800f_ffff_ffff_ffffu64) | (1022u64 << 52);
    (f64::from_bits(mbits), e + adj)
}

// ---------------------------------------------------------------------------
// trig / exp / log
// ---------------------------------------------------------------------------
pub fn dsincos(x: f64) -> (f64, f64) {
    let invpio2 = 6.36619772367581382433e-01;
    let pio2_1 = 1.57079632673412561417e+00;
    let pio2_1t = 6.07710050650619224932e-11;
    let kf = (x * invpio2 + 0.5).floor();
    let r = (x - kf * pio2_1) - kf * pio2_1t;
    let k = kf as i64;
    let z = r * r;
    let sn = r
        + r * z
            * (-1.66666666666666324348e-01
                + z * (8.33333333332248946124e-03
                    + z * (-1.98412698298579493134e-04
                        + z * (2.75573137070700676789e-06
                            + z * (-2.50507602534068634195e-08 + z * 1.58969099521155010221e-10)))));
    let cs = 1.0 - 0.5 * z
        + z * z
            * (4.16666666666666019037e-02
                + z * (-1.38888888888741095749e-03
                    + z * (2.48015872894767294178e-05
                        + z * (-2.75573143513906633035e-07
                            + z * (2.08757232129817482790e-09 + z * -1.13596475577881948265e-11)))));
    match k & 3 {
        0 => (sn, cs),
        1 => (cs, -sn),
        2 => (-sn, -cs),
        _ => (-cs, sn),
    }
}
#[inline]
pub fn dsin(x: f64) -> f64 {
    dsincos(x).0
}
#[inline]
pub fn dcos(x: f64) -> f64 {
    dsincos(x).1
}
#[inline]
pub fn dtan(x: f64) -> f64 {
    let (s, c) = dsincos(x);
    s / c
}

pub fn dexp(xin: f64) -> f64 {
    let mut x = xin;
    if x > 700.0 {
        x = 700.0;
    }
    if x < -700.0 {
        return 0.0;
    }
    let ln2hi = 6.93147180369123816490e-01;
    let ln2lo = 1.90821492927058770002e-10;
    let invln2 = 1.44269504088896338700e+00;
    let kf = (x * invln2 + 0.5).floor();
    let r = (x - kf * ln2hi) - kf * ln2lo;
    let p = 1.0
        + r * (1.0
            + r * (1.0 / 2.0
                + r * (1.0 / 6.0
                    + r * (1.0 / 24.0
                        + r * (1.0 / 120.0
                            + r * (1.0 / 720.0
                                + r * (1.0 / 5040.0
                                    + r * (1.0 / 40320.0
                                        + r * (1.0 / 362880.0
                                            + r * (1.0 / 3628800.0
                                                + r * (1.0 / 39916800.0
                                                    + r * (1.0 / 479001600.0 + r * (1.0 / 6227020800.0)))))))))))));
    ldexp(p, kf as i32)
}

pub fn dlog(x: f64) -> f64 {
    if !(x > 0.0) {
        return -1e300;
    }
    let (mut m, mut e) = frexp(x);
    if m < 0.70710678118654752440 {
        m *= 2.0;
        e -= 1;
    }
    let s = (m - 1.0) / (m + 1.0);
    let z = s * s;
    let r = s
        * (2.0
            + z * (2.0 / 3.0
                + z * (2.0 / 5.0
                    + z * (2.0 / 7.0
                        + z * (2.0 / 9.0
                            + z * (2.0 / 11.0
                                + z * (2.0 / 13.0
                                    + z * (2.0 / 15.0 + z * (2.0 / 17.0 + z * (2.0 / 19.0 + z * (2.0 / 21.0)))))))))));
    r + (e as f64) * 0.693147180559945309417232
}
#[inline]
pub fn dpow(x: f64, y: f64) -> f64 {
    if x <= 0.0 {
        0.0
    } else {
        dexp(y * dlog(x))
    }
}

pub fn datan(xin: f64) -> f64 {
    let mut x = xin;
    let mut sgn = 1.0;
    if x < 0.0 {
        x = -x;
        sgn = -1.0;
    }
    let mut inv = false;
    if x > 1.0 {
        x = 1.0 / x;
        inv = true;
    }
    x = x / (1.0 + (1.0 + x * x).sqrt());
    x = x / (1.0 + (1.0 + x * x).sqrt());
    x = x / (1.0 + (1.0 + x * x).sqrt());
    let z = x * x;
    let mut r = x
        * (1.0
            + z * (-1.0 / 3.0
                + z * (1.0 / 5.0 + z * (-1.0 / 7.0 + z * (1.0 / 9.0 + z * (-1.0 / 11.0 + z * (1.0 / 13.0)))))));
    r *= 8.0;
    if inv {
        r = PI / 2.0 - r;
    }
    sgn * r
}
pub fn datan2(y: f64, x: f64) -> f64 {
    if x == 0.0 && y == 0.0 {
        return 0.0;
    }
    if x.abs() >= y.abs() {
        let mut a = datan(y / x);
        if x < 0.0 {
            a += if y >= 0.0 { PI } else { -PI };
        }
        return a;
    }
    let a = datan(x / y);
    (if y > 0.0 { PI / 2.0 } else { -PI / 2.0 }) - a
}
pub fn dacos(x: f64) -> f64 {
    let xc = if x < -1.0 { -1.0 } else if x > 1.0 { 1.0 } else { x };
    datan2((1.0 - xc * xc).max(0.0).sqrt(), xc)
}
pub fn dasin(x: f64) -> f64 {
    let xc = if x < -1.0 { -1.0 } else if x > 1.0 { 1.0 } else { x };
    datan2(xc, (1.0 - xc * xc).max(0.0).sqrt())
}
pub fn dtanh(x: f64) -> f64 {
    if x > 20.0 {
        return 1.0;
    }
    if x < -20.0 {
        return -1.0;
    }
    let e = dexp(2.0 * x);
    (e - 1.0) / (e + 1.0)
}

// ---------------------------------------------------------------------------
// scalar helpers
// ---------------------------------------------------------------------------
#[inline]
pub fn clampv<T: PartialOrd>(v: T, lo: T, hi: T) -> T {
    if v < lo {
        lo
    } else if v > hi {
        hi
    } else {
        v
    }
}
#[inline]
pub fn lerpd(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}
#[inline]
pub fn lerpf(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}
#[inline]
pub fn smoothstep(a: f64, b: f64, x: f64) -> f64 {
    let mut t = (x - a) / (b - a);
    t = if t < 0.0 { 0.0 } else if t > 1.0 { 1.0 } else { t };
    t * t * (3.0 - 2.0 * t)
}
#[inline]
pub fn sqr(x: f64) -> f64 {
    x * x
}

// ---------------------------------------------------------------------------
// vectors
// ---------------------------------------------------------------------------
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct V3 {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}
impl V3 {
    #[inline]
    pub fn new(x: f64, y: f64, z: f64) -> V3 {
        V3 { x, y, z }
    }
}
impl Add for V3 {
    type Output = V3;
    #[inline]
    fn add(self, o: V3) -> V3 {
        V3::new(self.x + o.x, self.y + o.y, self.z + o.z)
    }
}
impl Sub for V3 {
    type Output = V3;
    #[inline]
    fn sub(self, o: V3) -> V3 {
        V3::new(self.x - o.x, self.y - o.y, self.z - o.z)
    }
}
impl Mul<f64> for V3 {
    type Output = V3;
    #[inline]
    fn mul(self, s: f64) -> V3 {
        V3::new(self.x * s, self.y * s, self.z * s)
    }
}
impl Neg for V3 {
    type Output = V3;
    #[inline]
    fn neg(self) -> V3 {
        V3::new(-self.x, -self.y, -self.z)
    }
}
impl AddAssign for V3 {
    #[inline]
    fn add_assign(&mut self, o: V3) {
        self.x += o.x;
        self.y += o.y;
        self.z += o.z;
    }
}
impl SubAssign for V3 {
    #[inline]
    fn sub_assign(&mut self, o: V3) {
        self.x -= o.x;
        self.y -= o.y;
        self.z -= o.z;
    }
}
impl MulAssign<f64> for V3 {
    #[inline]
    fn mul_assign(&mut self, s: f64) {
        self.x *= s;
        self.y *= s;
        self.z *= s;
    }
}

#[inline]
pub fn dot(a: V3, b: V3) -> f64 {
    a.x * b.x + a.y * b.y + a.z * b.z
}
#[inline]
pub fn cross(a: V3, b: V3) -> V3 {
    V3::new(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
}
#[inline]
pub fn length(a: V3) -> f64 {
    dot(a, a).sqrt()
}
#[inline]
pub fn normalize(a: V3) -> V3 {
    let l = length(a);
    if l > 1e-300 {
        a * (1.0 / l)
    } else {
        V3::new(0.0, 0.0, 1.0)
    }
}
/// rotate v about unit axis by angle (radians)
pub fn rotate_axis(v: V3, axis: V3, ang: f64) -> V3 {
    let (s, c) = dsincos(ang);
    v * c + cross(axis, v) * s + axis * (dot(axis, v) * (1.0 - c))
}
#[inline]
pub fn lat_of(d: V3) -> f64 {
    dasin(d.z)
}
#[inline]
pub fn lon_of(d: V3) -> f64 {
    datan2(d.y, d.x)
}
pub fn from_lat_lon(lat: f64, lon: f64) -> V3 {
    let (sl, cl) = dsincos(lat);
    let (so, co) = dsincos(lon);
    V3::new(cl * co, cl * so, sl)
}
/// local east / north at unit position p (north pole = +Z)
pub fn east_north(p: V3) -> (V3, V3) {
    let mut ee = cross(V3::new(0.0, 0.0, 1.0), p);
    let l = length(ee);
    if l < 1e-9 {
        ee = V3::new(0.0, 1.0, 0.0);
    } else {
        ee = ee * (1.0 / l);
    }
    let n = cross(p, ee);
    (ee, n)
}
#[inline]
pub fn tangent_part(v: V3, p: V3) -> V3 {
    v - p * dot(v, p)
}

// ---------------------------------------------------------------------------
// RNG / hashing
// ---------------------------------------------------------------------------
#[inline]
pub fn mix64(z0: u64) -> u64 {
    let mut z = z0;
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9u64);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EBu64);
    z ^ (z >> 31)
}

#[derive(Clone, Debug)]
pub struct Rng {
    pub s: u64,
}
impl Rng {
    pub fn new(seed: u64) -> Rng {
        Rng { s: seed }
    }
    pub fn next(&mut self) -> u64 {
        self.s = self.s.wrapping_add(0x9E3779B97F4A7C15u64);
        mix64(self.s)
    }
    pub fn uni(&mut self) -> f64 {
        ((self.next() >> 11) as f64) * (1.0 / 9007199254740992.0)
    }
    pub fn range(&mut self, a: f64, b: f64) -> f64 {
        a + (b - a) * self.uni()
    }
    pub fn irange(&mut self, a: i32, b: i32) -> i32 {
        let span = (b - a + 1) as u64;
        a + (self.next() % span) as i32
    }
    pub fn unit_vec(&mut self) -> V3 {
        let z = self.range(-1.0, 1.0);
        let t = self.range(0.0, TAU);
        let r = (1.0 - z * z).max(0.0).sqrt();
        let (sn, cs) = dsincos(t);
        V3::new(r * cs, r * sn, z)
    }
}

pub fn hash_str(s: &str) -> u64 {
    let mut h: u64 = 1469598103934665603u64;
    for c in s.bytes() {
        h ^= c as u64;
        h = h.wrapping_mul(1099511628211u64);
    }
    mix64(h)
}

pub struct Timer {
    t0: std::time::Instant,
}
impl Timer {
    pub fn new() -> Timer {
        Timer { t0: std::time::Instant::now() }
    }
    pub fn reset(&mut self) {
        self.t0 = std::time::Instant::now();
    }
    pub fn ms(&self) -> f64 {
        self.t0.elapsed().as_secs_f64() * 1000.0
    }
}

#[inline]
pub fn u8c(v: f64) -> u8 {
    let x = v * 255.0 + 0.5;
    if x <= 0.0 {
        0
    } else if x >= 255.0 {
        255
    } else {
        x as u8
    }
}
