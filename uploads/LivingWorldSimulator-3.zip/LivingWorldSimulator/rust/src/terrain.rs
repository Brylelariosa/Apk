//! Solid-earth foundation: tectonic context, crust, elevation, bathymetry, erosion and sedimentation.
//! Heights end up relative to sea level (ocean% honoured).

use crate::grid::*;
use crate::mathx::*;
use crate::noise::Noise;
use crate::params::*;
use crate::tectonics::*;
use crate::world_data::*;
use std::cmp::Ordering;
use std::collections::BinaryHeap;

/// Min-heap item (smallest key first, ties by smallest index) for BinaryHeap.
#[derive(Copy, Clone)]
pub struct MinItem {
    pub key: f32,
    pub idx: u32,
}
impl PartialEq for MinItem {
    fn eq(&self, o: &MinItem) -> bool {
        self.key == o.key && self.idx == o.idx
    }
}
impl Eq for MinItem {}
impl PartialOrd for MinItem {
    fn partial_cmp(&self, o: &MinItem) -> Option<Ordering> {
        Some(self.cmp(o))
    }
}
impl Ord for MinItem {
    fn cmp(&self, o: &MinItem) -> Ordering {
        match o.key.partial_cmp(&self.key) {
            Some(Ordering::Equal) | None => o.idx.cmp(&self.idx),
            Some(ord) => ord,
        }
    }
}

/// Flow routing graph on the fine grid (priority-flood so depressions become lakes)
#[derive(Default)]
pub struct FlowGraph {
    pub rec: Vec<i32>,   // receiver, -1 for ocean cells
    pub order: Vec<i32>, // land cells, receivers before donors
    pub fill: Vec<f32>,  // filled elevation
}

pub fn compute_flow(g: &CubeGrid, h: &[f32], sea: f32, fl: &mut FlowGraph) {
    let n = g.count;
    fl.rec.clear();
    fl.rec.resize(n, -1);
    fl.fill.clear();
    fl.fill.resize(n, 0.0);
    fl.order.clear();
    fl.order.reserve(n);
    let mut closed = vec![0u8; n];
    let mut open: BinaryHeap<MinItem> = BinaryHeap::new();
    for c in 0..n {
        if h[c] <= sea {
            closed[c] = 1;
            fl.fill[c] = h[c];
        }
    }
    for c in 0..n {
        if h[c] > sea {
            continue;
        }
        for k in 0..8usize {
            let q = g.nbr[c * 8 + k];
            if q < 0 {
                continue;
            }
            let qu = q as usize;
            if closed[qu] != 0 {
                continue;
            }
            closed[qu] = 1;
            fl.rec[qu] = c as i32;
            fl.fill[qu] = h[qu];
            open.push(MinItem { key: h[qu], idx: qu as u32 });
        }
    }
    let eps = 0.02f32;
    while let Some(top) = open.pop() {
        let c = top.idx as usize;
        let fc = top.key;
        fl.order.push(c as i32);
        for k in 0..8usize {
            let q = g.nbr[c * 8 + k];
            if q < 0 {
                continue;
            }
            let qu = q as usize;
            if closed[qu] != 0 {
                continue;
            }
            closed[qu] = 1;
            fl.rec[qu] = c as i32;
            let f = if h[qu] > fc { h[qu] } else { fc + eps };
            fl.fill[qu] = f;
            open.push(MinItem { key: f, idx: qu as u32 });
        }
    }
}

struct BumpCtx<'a> {
    g: &'a CubeGrid,
    r_km: f64,
    stamp: Vec<i32>,
    cur: i32,
    q: Vec<usize>,
}
impl<'a> BumpCtx<'a> {
    fn new(g: &'a CubeGrid, r_km: f64) -> BumpCtx<'a> {
        BumpCtx { g, r_km, stamp: vec![0; g.count], cur: 0, q: Vec::with_capacity(4096) }
    }
    fn run<F: FnMut(usize, f64)>(&mut self, center: V3, reach_km: f64, mut f: F) {
        self.cur += 1;
        let g = self.g;
        let c0 = g.cell_of(center);
        self.q.clear();
        self.q.push(c0);
        self.stamp[c0] = self.cur;
        let mut h = 0usize;
        while h < self.q.len() {
            let c = self.q[h];
            f(c, length(g.pos[c] - center) * self.r_km);
            for k in 0..8usize {
                let nb = g.nbr[c * 8 + k];
                if nb < 0 {
                    continue;
                }
                let nu = nb as usize;
                if self.stamp[nu] == self.cur {
                    continue;
                }
                if length(g.pos[nu] - center) * self.r_km > reach_km {
                    continue;
                }
                self.stamp[nu] = self.cur;
                self.q.push(nu);
            }
            h += 1;
        }
    }
}

fn margin(cf: f64, eoc: f64, econt: f64) -> f64 {
    if cf < 0.10 {
        return eoc;
    }
    if cf < 0.40 {
        return lerpd(eoc, -0.25, smoothstep(0.10, 0.40, cf));
    }
    if cf < 0.62 {
        return lerpd(-0.25, -0.05, (cf - 0.40) / 0.22);
    }
    lerpd(-0.05, econt, smoothstep(0.62, 0.85, cf))
}

#[inline]
fn gauss(d: f64, c: f64, w: f64) -> f64 {
    let t = (d - c) / w;
    dexp(-t * t)
}

struct CellA {
    plate: u8,
    plate2: u8,
    btype: u8,
    bdist: f32,
    conv: f32,
    shear: f32,
    cf: f32,
    cf_o: f32,
}

struct CellD {
    e: f32,
    orog: f32,
    volc: f32,
    seis: f32,
    thick: f32,
}

fn find_sea(g: &CubeGrid, hv: &[f32], frac: f64) -> f64 {
    let n = g.count;
    let mut ord: Vec<u32> = (0..(n as u32)).collect();
    ord.sort_by(|&a, &b| {
        let ha = hv[a as usize];
        let hb = hv[b as usize];
        match ha.partial_cmp(&hb) {
            Some(Ordering::Equal) | None => a.cmp(&b),
            Some(o) => o,
        }
    });
    let mut total = 0.0f64;
    for i in 0..n {
        total += g.area[i] as f64;
    }
    let mut acc = 0.0f64;
    for i in 0..n {
        acc += g.area[ord[i] as usize] as f64;
        if acc >= total * frac {
            return hv[ord[i] as usize] as f64;
        }
    }
    hv[ord[n - 1] as usize] as f64
}

pub fn generate_terrain(
    pp: &PlanetParams,
    dv: &Derived,
    seed: u64,
    nz: &Noise,
    tect: &Tectonics,
    g: &CubeGrid,
    t_myr: f64,
    td: &mut TerrainData,
    progress: Progress,
) {
    let n = g.count;
    let r_km = pp.radius_km;
    let r_m = dv.r;
    td.n = g.n;
    td.plate = vec![0u8; n];
    td.plate2 = vec![0u8; n];
    td.btype = vec![0u8; n];
    td.bdist = vec![0.0; n];
    td.conv = vec![0.0; n];
    td.cf = vec![0.0; n];
    td.crust_age = vec![0.0; n];
    td.thickness = vec![0.0; n];
    td.volcanism = vec![0.0; n];
    td.seismic = vec![0.0; n];
    td.orogeny = vec![0.0; n];
    td.target = vec![0.0; n];
    td.height = vec![0.0; n];
    td.sediment = vec![0.0; n];
    td.rough = vec![0.0; n];
    td.slope = vec![0.0; n];
    td.rock_hard = vec![0.0; n];
    td.volcanoes.clear();

    // ---------------- A. tectonic context per cell ----------------
    progress("Tectonic plates", 0.0);
    let fr = tect.make_frame(t_myr);
    let cells_a: Vec<CellA> = par_map(n, |c| {
        let x = g.pos[c];
        let s = tect.sample(&fr, x);
        let cf_s = tect.crust_frac(&fr, x, &s);
        let mut cf_oth = cf_s;
        if s.dist_km < 900.0 {
            let ang = 2.0 * s.dist_km / r_km + 4e-4;
            let xm = normalize(x * dcos(ang) + s.n * dsin(ang));
            let sm = tect.sample(&fr, xm);
            cf_oth = tect.crust_frac(&fr, xm, &sm);
        }
        CellA {
            plate: s.plate as u8,
            plate2: s.other as u8,
            btype: s.kind as u8,
            bdist: s.dist_km as f32,
            conv: s.conv as f32,
            shear: s.shear as f32,
            cf: cf_s as f32,
            cf_o: cf_oth as f32,
        }
    });
    let mut cf_o = vec![0f32; n];
    for c in 0..n {
        let a = &cells_a[c];
        td.plate[c] = a.plate;
        td.plate2[c] = a.plate2;
        td.btype[c] = a.btype;
        td.bdist[c] = a.bdist;
        td.conv[c] = a.conv;
        td.cf[c] = a.cf;
        cf_o[c] = a.cf_o;
    }
    drop(cells_a);

    // ---------------- B. oceanic crust age (distance from spreading ridges within a plate) ----------------
    progress("Crust age", 0.12);
    {
        let mut dist = vec![1e30f32; n];
        let mut rate = vec![20.0f32; n];
        let mut pq: BinaryHeap<MinItem> = BinaryHeap::new();
        let cell_km = (g.area[0] as f64).sqrt() * r_km;
        for c in 0..n {
            if td.btype[c] == 2 && (td.bdist[c] as f64) < 0.9 * cell_km {
                dist[c] = 0.0;
                rate[c] = ((10.0f64).max(((td.conv[c] as f64).abs()) * 5.0)) as f32;
                pq.push(MinItem { key: 0.0, idx: c as u32 });
            }
        }
        while let Some(tp) = pq.pop() {
            let c = tp.idx as usize;
            if tp.key > dist[c] {
                continue;
            }
            for k in 0..8usize {
                let q = g.nbr[c * 8 + k];
                if q < 0 {
                    continue;
                }
                let qu = q as usize;
                if td.plate[qu] != td.plate[c] {
                    continue;
                }
                let nd = tp.key + (length(g.pos[qu] - g.pos[c]) * r_km) as f32;
                if nd < dist[qu] {
                    dist[qu] = nd;
                    rate[qu] = rate[c];
                    pq.push(MinItem { key: nd, idx: qu as u32 });
                }
            }
        }
        for c in 0..n {
            let base = tect.plates[td.plate[c] as usize].base_age;
            let a: f64 = if dist[c] < 1e29f32 { (dist[c] / rate[c]) as f64 } else { base };
            td.crust_age[c] = clampv(a, 0.0, 185.0) as f32;
        }
    }

    // ---------------- C. inherited orogens (older collision belts, carried with their plates) ----------------
    progress("Ancient mountain belts", 0.2);
    let mut pg = CubeGrid::default();
    pg.build(48, false);
    const TIMES: [f64; 3] = [-40.0, -100.0, -180.0];
    let mut ft: Vec<TectFrame> = Vec::new();
    for k in 0..3usize {
        ft.push(tect.make_frame(t_myr + TIMES[k]));
    }
    let paleo: Vec<f32> = par_map(pg.count, |c| {
        let x = pg.pos[c];
        let s = tect.sample(&fr, x);
        if tect.crust_frac(&fr, x, &s) < 0.5 {
            return 0.0f32;
        }
        let pl = &tect.plates[s.plate];
        let mut sum = 0.0f64;
        for k in 0..3usize {
            let xp = normalize(rotate_axis(x, pl.pole, pl.omega * TIMES[k]));
            let sp = tect.sample(&ft[k], xp);
            if sp.plate != s.plate || sp.kind != 1 || sp.conv < 1.0 {
                continue;
            }
            let ang = 2.0 * sp.dist_km / r_km + 4e-4;
            let xm = normalize(xp * dcos(ang) + sp.n * dsin(ang));
            let sm = tect.sample(&ft[k], xm);
            let co = tect.crust_frac(&ft[k], xm, &sm);
            let sc = clampv(sp.conv / 6.0, 0.2, 1.3);
            let age = -TIMES[k];
            let amp: f64 = if co > 0.5 { 5.2 } else { 2.2 };
            sum += amp * sc * dexp(-sqr(sp.dist_km / 400.0)) * dexp(-age / 230.0);
        }
        sum as f32
    });

    // ---------------- D. base elevation from isostasy / boundary processes ----------------
    progress("Crust and elevation", 0.3);
    let cells_d: Vec<CellD> = {
        let tt: &TerrainData = &*td;
        par_map(n, |c| {
            let x = g.pos[c];
            let px = x.x as f32;
            let py = x.y as f32;
            let pz = x.z as f32;
            let cf = tt.cf[c] as f64;
            let co = cf_o[c] as f64;
            let d = tt.bdist[c] as f64;
            let age = tt.crust_age[c] as f64;
            let eoc = -(2.6 + 3.0 * (1.0 - dexp(-age / 32.0)));
            let econt = 1.05
                + 0.50 * (nz.fbm(px * 1.1 + 3.3, py * 1.1, pz * 1.1, 3) as f64)
                + 0.30 * (nz.fbm(px * 3.1, py * 3.1 + 1.7, pz * 3.1, 3) as f64);
            let mut e = margin(cf, eoc, econt);
            let mut d_e = 0.0f64;
            let mut orog = 0.0f64;
            let sc = clampv((tt.conv[c] as f64) / 4.5, 0.2, 1.5);
            let self_c = cf > 0.5;
            let oth_c = co > 0.5;
            let modv = clampv(0.7 + 0.6 * (nz.fbm(px * 7.0, py * 7.0 + 4.4, pz * 7.0, 2) as f64), 0.25, 1.35);
            let kind = tt.btype[c];
            let mut volc = 0.0f64;
            let mut seis = 0.02f64;
            if kind == 1 {
                seis = clampv(sc * dexp(-d / 200.0), 0.0, 1.0);
                if self_c && oth_c {
                    d_e = 7.0 * sc * modv * gauss(d, 0.0, 450.0) + 1.6 * sc * gauss(d, 720.0, 450.0);
                    orog = clampv(d_e / 4.5, 0.0, 1.0);
                } else if !self_c && oth_c {
                    let s2 = clampv(sc, 0.5, 1.2);
                    d_e = -3.8 * s2 * gauss(d, 55.0, 55.0) + 0.35 * gauss(d, 190.0, 70.0);
                } else if self_c && !oth_c {
                    d_e = 4.6 * sc * modv * gauss(d, 170.0, 130.0)
                        + 1.1 * clampv(sc - 0.6, 0.0, 1.0) * gauss(d, 480.0, 260.0)
                        - 0.7 * gauss(d, 35.0, 40.0);
                    orog = clampv(d_e / 3.5, 0.0, 1.0);
                    volc = sc * gauss(d, 170.0, 90.0);
                } else {
                    let sub = tect.plates[tt.plate[c] as usize].base_age > tect.plates[tt.plate2[c] as usize].base_age;
                    let s2 = clampv(sc, 0.5, 1.2);
                    if sub {
                        d_e = -2.9 * s2 * gauss(d, 55.0, 55.0) + 0.3 * gauss(d, 190.0, 70.0);
                    } else {
                        d_e = 4.8 * sc * modv * gauss(d, 125.0, 75.0) - 0.4 * gauss(d, 380.0, 160.0);
                        orog = clampv(d_e / 4.0, 0.0, 1.0);
                        volc = sc * gauss(d, 125.0, 70.0);
                    }
                }
            } else if kind == 2 {
                let sp = clampv(((tt.conv[c] as f64).abs()) / 3.0, 0.2, 1.0);
                seis = 0.35 * gauss(d, 0.0, 90.0);
                if !self_c && !oth_c {
                    d_e = -0.25 * gauss(d, 0.0, 30.0);
                    volc = 0.18 * gauss(d, 0.0, 60.0);
                } else {
                    d_e = -1.3 * sp * gauss(d, 0.0, 75.0) + 0.9 * gauss(d, 0.0, 380.0);
                    volc = 0.55 * sp * gauss(d, 0.0, 100.0);
                    orog = 0.2 * gauss(d, 0.0, 300.0);
                }
            } else if kind == 3 {
                d_e = 0.12 * (nz.fbm(px * 12.0, py * 12.0, pz * 12.0, 2) as f64) - 0.15 * gauss(d, 0.0, 28.0);
                seis = clampv(0.8 * gauss(d, 0.0, 100.0), 0.0, 1.0);
            }
            let pal = pg.sample(&paleo, x);
            if pal > 0.0 {
                d_e += pal as f64;
                orog = orog.max(clampv((pal as f64) / 3.0, 0.0, 0.8));
            }
            e += d_e;
            // large-scale relief of the mountain belts, abyssal hills, and seeding noise for the river network
            if orog > 0.02 {
                e += orog * 0.9 * ((nz.ridged(px * 8.0, py * 8.0, pz * 8.0, 4) as f64) - 0.42);
            }
            if e < -1.0 {
                e += 0.10 * (nz.fbm(px * 30.0, py * 30.0, pz * 30.0, 3) as f64);
            }
            e += 0.045 * (nz.n3(px * 64.0, py * 64.0 + 7.0, pz * 64.0) as f64)
                + 0.025 * (nz.n3(px * 150.0 + 9.0, py * 150.0, pz * 150.0) as f64);
            CellD {
                e: e as f32,
                orog: orog as f32,
                volc: volc as f32,
                seis: seis as f32,
                thick: (7.0 + 28.0 * cf + (0.0f64).max(d_e) * 6.6) as f32,
            }
        })
    };
    let mut e_arr = vec![0f32; n];
    for c in 0..n {
        let cd = &cells_d[c];
        e_arr[c] = cd.e;
        td.orogeny[c] = cd.orog;
        td.volcanism[c] = cd.volc;
        td.seismic[c] = cd.seis;
        td.thickness[c] = cd.thick;
    }
    drop(cells_d);

    // ---------------- E. hotspot chains and volcanic arcs ----------------
    progress("Volcanoes", 0.5);
    {
        let mut bc = BumpCtx::new(g, r_km);
        let mut rng = Rng::new(seed ^ 0x40750707u64);
        let nhot = clampv(((4.0 * dpow(dv.geo_scale, 0.7) + rng.range(-1.0, 1.5) + 0.5).floor()) as i32, 1, 9);
        for _hnum in 0..nhot {
            let h0 = rng.unit_vec();
            let s = tect.sample(&fr, h0);
            let pl = &tect.plates[s.plate];
            for k in 0..44i32 {
                let tau = (k as f64) * 1.25;
                let p = normalize(rotate_axis(h0, pl.pole, pl.omega * tau));
                let amp = 6.0 * dexp(-tau / 9.0) * (1.0f64).min(0.6 + 0.4 * dv.geo_scale);
                let rad = 55.0 + 30.0 * dexp(-tau / 12.0);
                let act = dexp(-tau / 3.0);
                bc.run(p, rad * 2.2, |c, dd| {
                    let w = dexp(-sqr(dd / rad));
                    e_arr[c] += (amp * w) as f32;
                    let v = (act * w) as f32;
                    if v > td.volcanism[c] {
                        td.volcanism[c] = v;
                    }
                });
                if k == 0 {
                    bc.run(p, 1300.0, |c, dd| {
                        e_arr[c] += (0.7 * dexp(-sqr(dd / 650.0))) as f32;
                    });
                    td.volcanoes.push(g.cell_of(p) as i32);
                }
            }
        }
        // stratovolcano cones strung along volcanic arcs
        for c in 0..n {
            if td.volcanism[c] < 0.35 || td.btype[c] != 1 {
                continue;
            }
            let hh = mix64((c as u64).wrapping_mul(2654435761u64).wrapping_add(seed));
            if (hh & 1023) > 150 {
                continue;
            }
            let amp = 1.2 + 1.2 * (((hh >> 12) & 255) as f64) / 255.0;
            let p = g.pos[c];
            bc.run(p, 90.0, |cc, dd| {
                e_arr[cc] += (amp * dexp(-sqr(dd / 32.0))) as f32;
            });
            td.volcanoes.push(c as i32);
        }
    }

    // gravity limits how high crust can stand: soft cap on everything above the datum (volcanoes included)
    {
        let cap_max = dv.max_relief_m / 1000.0 + 0.7;
        let knee = 0.54 * cap_max;
        for c in 0..n {
            let ec = e_arr[c] as f64;
            if ec > knee {
                e_arr[c] = (knee + (cap_max - knee) * dtanh((ec - knee) / (cap_max - knee))) as f32;
            }
        }
    }

    // ---------------- F. sea level so that ocean% is honoured ----------------
    progress("Ocean basins", 0.58);
    let mut h: Vec<f32> = vec![0.0; n];
    for c in 0..n {
        h[c] = e_arr[c] * 1000.0f32;
    }
    drop(e_arr);
    let sea0 = find_sea(g, &h, pp.ocean_fraction);
    for c in 0..n {
        h[c] -= sea0 as f32;
        td.target[c] = h[c];
    }

    // ---------------- G. fluvial erosion + sediment transport (stream-power, implicit) ----------------
    progress("Erosion", 0.62);
    {
        let mut fl = FlowGraph::default();
        let mut a_arr = vec![0f32; n];
        let mut eroded = vec![0f32; n];
        let mut qs = vec![0f32; n];
        let mut nb = vec![0f32; n];
        let mut area_m2 = vec![0f64; n];
        for c in 0..n {
            area_m2[c] = (g.area[c] as f64) * r_m * r_m;
        }
        const ITER: usize = 9;
        let dt = 2.5e5f64;
        let kk = 1.5e-6 / ((0.3f64).max(dv.g / 9.80665)).sqrt();
        let tau_up = 2.5e6f64;
        let up_frac = 1.0 - dexp(-dt / tau_up);
        for it in 0..ITER {
            compute_flow(g, &h, 0.0, &mut fl);
            for c in 0..n {
                a_arr[c] = area_m2[c] as f32;
            }
            for i in (0..fl.order.len()).rev() {
                let c = fl.order[i] as usize;
                let r = fl.rec[c];
                if r >= 0 {
                    let add = a_arr[c];
                    a_arr[r as usize] += add;
                }
            }
            for c in 0..n {
                if h[c] > 0.0 && td.target[c] > h[c] {
                    h[c] += (((td.target[c] - h[c]) as f64) * up_frac) as f32;
                }
            }
            for v in eroded.iter_mut() {
                *v = 0.0;
            }
            for i in 0..fl.order.len() {
                let c = fl.order[i] as usize;
                if fl.fill[c] > h[c] + 0.5 {
                    continue;
                }
                let r = fl.rec[c];
                if r < 0 {
                    continue;
                }
                let ru = r as usize;
                let hr: f64 = if h[ru] > 0.0 { h[ru] as f64 } else { 0.0 };
                let l = length(g.pos[c] - g.pos[ru]) * r_m;
                let f = kk * dt * (a_arr[c] as f64).sqrt() / l;
                let hn = ((h[c] as f64) + f * hr) / (1.0 + f);
                if hn < (h[c] as f64) {
                    eroded[c] = ((h[c] as f64) - hn) as f32;
                    h[c] = hn as f32;
                }
            }
            // sediment: carried downstream, deposited where gradient is low, in lakes and at river mouths
            for v in qs.iter_mut() {
                *v = 0.0;
            }
            let sed_eff = 0.35f64;
            for i in (0..fl.order.len()).rev() {
                let c = fl.order[i] as usize;
                let r = fl.rec[c];
                if r < 0 {
                    continue;
                }
                let ru = r as usize;
                let vin = (qs[c] as f64) + (eroded[c] as f64) * area_m2[c] * sed_eff;
                if vin <= 0.0 {
                    continue;
                }
                let hr: f64 = if h[ru] > 0.0 { h[ru] as f64 } else { 0.0 };
                let l = length(g.pos[c] - g.pos[ru]) * r_m;
                let s = ((h[c] as f64) - hr) / l;
                let lake = fl.fill[c] > h[c] + 0.5;
                let frac: f64 = if lake { 0.9 } else { clampv(1.0 - s / 0.004, 0.0, 0.8) };
                let dep = vin * frac;
                h[c] += (dep / area_m2[c]) as f32;
                td.sediment[c] += (dep / area_m2[c]) as f32;
                qs[ru] += (vin - dep) as f32;
            }
            // river mouths: deltas and shelf building in the ocean
            for c in 0..n {
                if h[c] > 0.0 || qs[c] <= 0.0 {
                    continue;
                }
                let mut vol = qs[c] as f64;
                let mut cur = c;
                let mut hop = 0;
                while hop < 10 && vol > 0.0 {
                    let room = (0.0f64).max((60.0f64).min(30.0 - (h[cur] as f64))) * area_m2[cur];
                    let dep = (vol * 0.5).min(room);
                    h[cur] += (dep / area_m2[cur]) as f32;
                    td.sediment[cur] += (dep / area_m2[cur]) as f32;
                    vol -= dep;
                    let mut best: i32 = -1;
                    let mut bh = h[cur];
                    for k in 0..4usize {
                        let q = g.nbr[cur * 8 + k];
                        if q >= 0 && h[q as usize] < bh {
                            bh = h[q as usize];
                            best = q;
                        }
                    }
                    if best < 0 {
                        break;
                    }
                    cur = best as usize;
                    hop += 1;
                }
            }
            // hillslope diffusion
            for c in 0..n {
                let mut s = 0.0f32;
                let mut m = 0i32;
                for k in 0..4usize {
                    let q = g.nbr[c * 8 + k];
                    if q >= 0 {
                        s += h[q as usize];
                        m += 1;
                    }
                }
                nb[c] = if m > 0 && h[c] > 0.0 { s / (m as f32) } else { h[c] };
            }
            for c in 0..n {
                if h[c] > 0.0 {
                    h[c] += 0.05 * (nb[c] - h[c]);
                }
            }
            if it % 3 == 0 {
                progress("Erosion", 0.62 + 0.18 * (it as f32) / (ITER as f32));
            }
        }
        // coastal planation: waves flatten the shelf edge and create beaches/lagoons
        for _pass in 0..4 {
            for c in 0..n {
                let mut s = 0.0f32;
                let mut m = 0i32;
                for k in 0..8usize {
                    let q = g.nbr[c * 8 + k];
                    if q >= 0 {
                        s += h[q as usize];
                        m += 1;
                    }
                }
                nb[c] = if m > 0 { s / (m as f32) } else { h[c] };
            }
            for c in 0..n {
                if h[c] > -130.0 && h[c] < 90.0 {
                    h[c] += 0.25 * (nb[c] - h[c]);
                }
            }
        }
    }

    // ---------------- H. final sea level + derived surface fields ----------------
    progress("Coastlines", 0.82);
    let mut sea1 = 0.0f64;
    let mut target = pp.ocean_fraction;
    for _iter in 0..3 {
        sea1 = find_sea(g, &h, target) + pp.sea_level_offset_m;
        for c in 0..n {
            td.height[c] = h[c] - (sea1 as f32);
        }
        // landlocked below-sea-level basins are not ocean: turn them into low basins (lakes form later if water allows)
        let mut lab = vec![-1i32; n];
        let mut stack: Vec<usize> = Vec::new();
        let mut comp_size: Vec<i32> = Vec::new();
        let mut ncomp = 0i32;
        for c0 in 0..n {
            if td.height[c0] > 0.0 || lab[c0] >= 0 {
                continue;
            }
            let mut sz = 0i32;
            stack.clear();
            stack.push(c0);
            lab[c0] = ncomp;
            while let Some(c) = stack.pop() {
                sz += 1;
                for k in 0..8usize {
                    let q = g.nbr[c * 8 + k];
                    if q >= 0 {
                        let qu = q as usize;
                        if lab[qu] < 0 && td.height[qu] <= 0.0 {
                            lab[qu] = ncomp;
                            stack.push(qu);
                        }
                    }
                }
            }
            comp_size.push(sz);
            ncomp += 1;
        }
        let mut big = 0usize;
        for i in 1..(ncomp as usize) {
            if comp_size[i] > comp_size[big] {
                big = i;
            }
        }
        for c in 0..n {
            if lab[c] >= 0 && (lab[c] as usize) != big {
                let hv = (td.height[c] * 0.02f32).max(-60.0f32) + 4.0f32;
                td.height[c] = if hv <= 0.0 { 1.0 } else { hv };
            }
        }
        let mut land = 0.0f64;
        let mut total = 0.0f64;
        for c in 0..n {
            total += g.area[c] as f64;
            if td.height[c] > 0.0 {
                land += g.area[c] as f64;
            }
        }
        td.land_fraction = land / total;
        let ocean_now = 1.0 - td.land_fraction;
        if pp.sea_level_offset_m != 0.0 || (ocean_now - pp.ocean_fraction).abs() < 0.004 {
            break;
        }
        target += pp.ocean_fraction - ocean_now;
    }
    td.sea_level_raw = sea0 + sea1;
    for c in 0..n {
        let mut best = 0.0f64;
        let mut mn = td.height[c] as f64;
        let mut mx = mn;
        for k in 0..8usize {
            let q = g.nbr[c * 8 + k];
            if q < 0 {
                continue;
            }
            let qu = q as usize;
            let l = length(g.pos[qu] - g.pos[c]) * r_m;
            best = best.max(((td.height[c] as f64) - (td.height[qu] as f64)) / l);
            mn = mn.min(td.height[qu] as f64);
            mx = mx.max(td.height[qu] as f64);
        }
        td.slope[c] = best as f32;
        let relief = (mx - mn) / 2000.0;
        let ocean: f64 = if td.height[c] < 0.0 { 0.25 } else { 1.0 };
        td.rough[c] = clampv((0.08 + 0.55 * relief + 0.55 * (td.orogeny[c] as f64)) * ocean, 0.04, 1.0) as f32;
        let px = g.pos[c].x as f32;
        let py = g.pos[c].y as f32;
        let pz = g.pos[c].z as f32;
        let rh = 0.40 + 0.45 * (td.orogeny[c] as f64)
            - 0.30 * clampv((td.sediment[c] as f64) / 400.0, 0.0, 1.0)
            + 0.10 * (nz.fbm(px * 5.0, py * 5.0, pz * 5.0 + 2.2, 2) as f64);
        td.rock_hard[c] = clampv(rh, 0.05, 1.0) as f32;
    }
    progress("Terrain complete", 0.85);
}
