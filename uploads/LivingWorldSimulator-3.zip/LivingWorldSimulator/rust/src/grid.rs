//! Cube-sphere grid (6 faces x N x N cells), tan-warped for near-uniform cells.
//! Used at two resolutions: coarse climate grid and fine terrain grid.

use crate::mathx::*;

const FN: [V3; 6] = [
    V3 { x: 1.0, y: 0.0, z: 0.0 },
    V3 { x: -1.0, y: 0.0, z: 0.0 },
    V3 { x: 0.0, y: 1.0, z: 0.0 },
    V3 { x: 0.0, y: -1.0, z: 0.0 },
    V3 { x: 0.0, y: 0.0, z: 1.0 },
    V3 { x: 0.0, y: 0.0, z: -1.0 },
];
const FT1: [V3; 6] = [
    V3 { x: 0.0, y: 1.0, z: 0.0 },
    V3 { x: 0.0, y: -1.0, z: 0.0 },
    V3 { x: -1.0, y: 0.0, z: 0.0 },
    V3 { x: 1.0, y: 0.0, z: 0.0 },
    V3 { x: 1.0, y: 0.0, z: 0.0 },
    V3 { x: 1.0, y: 0.0, z: 0.0 },
];
const FT2: [V3; 6] = [
    V3 { x: 0.0, y: 0.0, z: 1.0 },
    V3 { x: 0.0, y: 0.0, z: 1.0 },
    V3 { x: 0.0, y: 0.0, z: 1.0 },
    V3 { x: 0.0, y: 0.0, z: 1.0 },
    V3 { x: 0.0, y: 1.0, z: 0.0 },
    V3 { x: 0.0, y: -1.0, z: 0.0 },
];

fn tri_area(a: V3, b: V3, c: V3) -> f64 {
    let tr = dot(a, cross(b, c)).abs();
    let den = 1.0 + dot(a, b) + dot(b, c) + dot(c, a);
    2.0 * datan2(tr, den)
}

pub const K_RING: i32 = 4;

#[derive(Default)]
pub struct CubeGrid {
    pub n: i32,
    pub count: usize,
    pub pos: Vec<V3>,       // unit vectors of cell centres
    pub lat: Vec<f32>,      // radians
    pub lon: Vec<f32>,      // radians
    pub area: Vec<f32>,     // steradians
    pub nbr: Vec<i32>,      // 8 per cell: -i,+i,-j,+j,-i-j,+i-j,-i+j,+i+j (-1 = missing)
    pub gw: Vec<f32>,       // 24 per cell: least-squares gradient weights (per radian), optional
    pub has_grad: bool,
    ring: Vec<i32>,
    ring_per_face: usize,
}

pub fn face_axes(f: usize) -> (V3, V3, V3) {
    (FN[f], FT1[f], FT2[f])
}

pub fn dir_from_tan(f: usize, a: f64, b: f64) -> V3 {
    normalize(FN[f] + FT1[f] * a + FT2[f] * b)
}

pub fn face_dir(f: usize, u: f64, v: f64) -> V3 {
    let a = dtan(u * (PI / 4.0));
    let b = dtan(v * (PI / 4.0));
    dir_from_tan(f, a, b)
}

/// returns (face, u, v) with u,v in [-1,1]
pub fn dir_to_face(d: V3) -> (usize, f64, f64) {
    let ax = d.x.abs();
    let ay = d.y.abs();
    let az = d.z.abs();
    let f: usize = if ax >= ay && ax >= az {
        if d.x > 0.0 { 0 } else { 1 }
    } else if ay >= az {
        if d.y > 0.0 { 2 } else { 3 }
    } else {
        if d.z > 0.0 { 4 } else { 5 }
    };
    let dn = dot(d, FN[f]);
    let a = dot(d, FT1[f]) / dn;
    let b = dot(d, FT2[f]) / dn;
    (f, datan(a) * (4.0 / PI), datan(b) * (4.0 / PI))
}

impl CubeGrid {
    #[inline]
    pub fn idx(&self, f: usize, i: i32, j: i32) -> usize {
        (f * (self.n as usize) + (j as usize)) * (self.n as usize) + (i as usize)
    }
    #[inline]
    pub fn unpack(&self, c: usize) -> (usize, i32, i32) {
        let nn = (self.n as usize) * (self.n as usize);
        let f = c / nn;
        let r = c - f * nn;
        let j = r / (self.n as usize);
        let i = r - j * (self.n as usize);
        (f, i as i32, j as i32)
    }

    pub fn cell_of(&self, d: V3) -> usize {
        let (f, u, v) = dir_to_face(d);
        let n = self.n;
        let mut i = ((u + 1.0) * 0.5 * (n as f64)) as i32;
        let mut j = ((v + 1.0) * 0.5 * (n as f64)) as i32;
        i = clampv(i, 0, n - 1);
        j = clampv(j, 0, n - 1);
        self.idx(f, i, j)
    }

    /// handles indices outside the face (up to ~N/2 away)
    #[inline]
    pub fn cell_ext(&self, f: usize, i: i32, j: i32) -> usize {
        if i >= 0 && i < self.n && j >= 0 && j < self.n {
            return self.idx(f, i, j);
        }
        self.cell_ext_out(f, i, j)
    }

    fn cell_ext_slow(&self, f: usize, i: i32, j: i32) -> usize {
        if i >= 0 && i < self.n && j >= 0 && j < self.n {
            return self.idx(f, i, j);
        }
        let nf = self.n as f64;
        let u = 2.0 * ((i as f64) + 0.5) / nf - 1.0;
        let v = 2.0 * ((j as f64) + 0.5) / nf - 1.0;
        self.cell_of(face_dir(f, u, v))
    }

    fn ring_slot(&self, i: i32, j: i32) -> usize {
        let n = self.n;
        let w = n + 2 * K_RING;
        let s: i32 = if j < 0 {
            (j + K_RING) * w + (i + K_RING)
        } else if j >= n {
            K_RING * w + (j - n) * w + (i + K_RING)
        } else {
            2 * K_RING * w + j * (2 * K_RING) + (if i < 0 { i + K_RING } else { i - n + K_RING })
        };
        s as usize
    }

    fn cell_ext_out(&self, f: usize, i: i32, j: i32) -> usize {
        let n = self.n;
        if !self.ring.is_empty() && i >= -K_RING && i < n + K_RING && j >= -K_RING && j < n + K_RING {
            let v = self.ring[f * self.ring_per_face + self.ring_slot(i, j)];
            if v >= 0 {
                return v as usize;
            }
        }
        self.cell_ext_slow(f, i, j)
    }

    pub fn build(&mut self, n: i32, with_grad: bool) {
        self.n = n;
        let nu = n as usize;
        self.count = 6 * nu * nu;
        self.ring.clear();
        self.ring_per_face = (2 * K_RING as usize) * (nu + 2 * K_RING as usize) + (2 * K_RING as usize) * nu;
        {
            let mut rt: Vec<i32> = vec![-1; 6 * self.ring_per_face];
            for f in 0..6usize {
                for j in -K_RING..(n + K_RING) {
                    for i in -K_RING..(n + K_RING) {
                        if i >= 0 && i < n && j >= 0 && j < n {
                            continue;
                        }
                        let slot = self.ring_slot(i, j);
                        rt[f * self.ring_per_face + slot] = self.cell_ext_slow(f, i, j) as i32;
                    }
                }
            }
            self.ring = rt;
        }
        let count = self.count;
        self.pos = vec![V3::default(); count];
        self.lat = vec![0.0; count];
        self.lon = vec![0.0; count];
        self.area = vec![0.0; count];
        let nf = n as f64;
        for f in 0..6usize {
            for j in 0..n {
                for i in 0..n {
                    let c = self.idx(f, i, j);
                    let u = 2.0 * ((i as f64) + 0.5) / nf - 1.0;
                    let v = 2.0 * ((j as f64) + 0.5) / nf - 1.0;
                    let p = face_dir(f, u, v);
                    self.pos[c] = p;
                    self.lat[c] = lat_of(p) as f32;
                    self.lon[c] = lon_of(p) as f32;
                    let u0 = 2.0 * (i as f64) / nf - 1.0;
                    let u1 = 2.0 * ((i + 1) as f64) / nf - 1.0;
                    let v0 = 2.0 * (j as f64) / nf - 1.0;
                    let v1 = 2.0 * ((j + 1) as f64) / nf - 1.0;
                    let c00 = face_dir(f, u0, v0);
                    let c10 = face_dir(f, u1, v0);
                    let c11 = face_dir(f, u1, v1);
                    let c01 = face_dir(f, u0, v1);
                    self.area[c] = (tri_area(c00, c10, c11) + tri_area(c00, c11, c01)) as f32;
                }
            }
        }
        self.nbr = vec![-1; count * 8];
        const DI: [i32; 8] = [-1, 1, 0, 0, -1, 1, -1, 1];
        const DJ: [i32; 8] = [0, 0, -1, 1, -1, -1, 1, 1];
        for f in 0..6usize {
            for j in 0..n {
                for i in 0..n {
                    let c = self.idx(f, i, j);
                    let mut o = [-1i32; 8];
                    for k in 0..8usize {
                        let q = self.cell_ext(f, i + DI[k], j + DJ[k]) as i32;
                        let mut dup = q == (c as i32);
                        let mut m = 0usize;
                        while m < k && !dup {
                            dup = o[m] == q;
                            m += 1;
                        }
                        o[k] = if dup { -1 } else { q };
                    }
                    for k in 0..8usize {
                        self.nbr[c * 8 + k] = o[k];
                    }
                }
            }
        }
        self.has_grad = with_grad;
        if !with_grad {
            return;
        }
        self.gw = vec![0.0; count * 24];
        for c in 0..count {
            let (e, nn) = east_north(self.pos[c]);
            let mut dx = [0.0f64; 8];
            let mut dy = [0.0f64; 8];
            let mut w = [0.0f64; 8];
            let mut sxx = 0.0f64;
            let mut sxy = 0.0f64;
            let mut syy = 0.0f64;
            for k in 0..8usize {
                let q = self.nbr[c * 8 + k];
                if q < 0 {
                    w[k] = 0.0;
                    dx[k] = 0.0;
                    dy[k] = 0.0;
                    continue;
                }
                let dv = self.pos[q as usize] - self.pos[c];
                dx[k] = dot(dv, e);
                dy[k] = dot(dv, nn);
                w[k] = 1.0 / (dx[k] * dx[k] + dy[k] * dy[k]);
                sxx += w[k] * dx[k] * dx[k];
                sxy += w[k] * dx[k] * dy[k];
                syy += w[k] * dy[k] * dy[k];
            }
            let det = sxx * syy - sxy * sxy;
            if det.abs() < 1e-30 {
                continue;
            }
            let i00 = syy / det;
            let i01 = -sxy / det;
            let i11 = sxx / det;
            for k in 0..8usize {
                if w[k] == 0.0 {
                    continue;
                }
                let wx = w[k] * (i00 * dx[k] + i01 * dy[k]);
                let wy = w[k] * (i01 * dx[k] + i11 * dy[k]);
                let g = e * wx + nn * wy;
                self.gw[c * 24 + k * 3 + 0] = g.x as f32;
                self.gw[c * 24 + k * 3 + 1] = g.y as f32;
                self.gw[c * 24 + k * 3 + 2] = g.z as f32;
            }
        }
    }

    /// bilinear stencil
    #[inline]
    pub fn locate(&self, d: V3) -> ([usize; 4], [f32; 4]) {
        let (f, u, v) = dir_to_face(d);
        let nf = self.n as f64;
        let fu = (u + 1.0) * 0.5 * nf - 0.5;
        let fv = (v + 1.0) * 0.5 * nf - 0.5;
        let i0 = fu.floor() as i32;
        let j0 = fv.floor() as i32;
        let tx = (fu - (i0 as f64)) as f32;
        let ty = (fv - (j0 as f64)) as f32;
        let ids = [
            self.cell_ext(f, i0, j0),
            self.cell_ext(f, i0 + 1, j0),
            self.cell_ext(f, i0, j0 + 1),
            self.cell_ext(f, i0 + 1, j0 + 1),
        ];
        let w = [(1.0 - tx) * (1.0 - ty), tx * (1.0 - ty), (1.0 - tx) * ty, tx * ty];
        (ids, w)
    }

    /// bilinear
    #[inline]
    pub fn sample(&self, field: &[f32], d: V3) -> f32 {
        let (ids, w) = self.locate(d);
        field[ids[0]] * w[0] + field[ids[1]] * w[1] + field[ids[2]] * w[2] + field[ids[3]] * w[3]
    }

    /// Catmull-Rom
    pub fn sample_cubic(&self, field: &[f32], d: V3) -> f32 {
        let (f, u, v) = dir_to_face(d);
        let n = self.n;
        let nf = n as f64;
        let fu = (u + 1.0) * 0.5 * nf - 0.5;
        let fv = (v + 1.0) * 0.5 * nf - 0.5;
        let i0 = fu.floor() as i32;
        let j0 = fv.floor() as i32;
        let tx = (fu - (i0 as f64)) as f32;
        let ty = (fv - (j0 as f64)) as f32;
        let mut wx = [0.0f32; 4];
        let mut wy = [0.0f32; 4];
        cr_weights(tx, &mut wx);
        cr_weights(ty, &mut wy);
        let mut sum = 0.0f32;
        let inside = i0 >= 1 && i0 + 2 < n && j0 >= 1 && j0 + 2 < n;
        for b in 0..4i32 {
            let mut row = 0.0f32;
            for a in 0..4i32 {
                let c = if inside {
                    self.idx(f, i0 - 1 + a, j0 - 1 + b)
                } else {
                    self.cell_ext(f, i0 - 1 + a, j0 - 1 + b)
                };
                row += wx[a as usize] * field[c];
            }
            sum += wy[b as usize] * row;
        }
        sum
    }

    #[inline]
    pub fn cell_km(&self, c: usize, r_km: f64) -> f64 {
        (self.area[c] as f64).sqrt() * r_km
    }
    #[inline]
    pub fn dist_km(&self, a: usize, b: usize, r_km: f64) -> f64 {
        length(self.pos[a] - self.pos[b]) * r_km
    }
}

#[inline]
fn cr_weights(t: f32, w: &mut [f32; 4]) {
    let t2 = t * t;
    let t3 = t2 * t;
    w[0] = -0.5 * t3 + t2 - 0.5 * t;
    w[1] = 1.5 * t3 - 2.5 * t2 + 1.0;
    w[2] = -1.5 * t3 + 2.0 * t2 + 0.5 * t;
    w[3] = 0.5 * t3 - 0.5 * t2;
}
