//! Read-only access to the simulated planet at arbitrary positions and any level of detail.
//! Large scales come from the simulation grids; small scales are fractal detail whose amplitude
//! is steered by simulated roughness (tectonic activity, relief), so detail is consistent with the
//! geology instead of being random noise.

use crate::grid::*;
use crate::mathx::*;
use crate::world::*;
use crate::world_data::*;

pub struct DetailTab {
    pub n: usize,
    pub sc: [f64; 14],
    pub o1: [f64; 14],
    pub o2: [f64; 14],
    pub o3: [f64; 14],
}

pub struct Sampler<'a> {
    pub s: &'a StaticData,
    pub d: &'a DynamicData,
    pub fg: &'a CubeGrid,
    pub cg: &'a CubeGrid,
    pub t: &'a TerrainData,
    pub h: &'a HydroData,
    pub e: &'a EcoData,
    pub rm: f64,
    pub gam: f64,
}

impl<'a> Sampler<'a> {
    pub fn new(v: &'a View) -> Sampler<'a> {
        Sampler {
            s: &v.s,
            d: &v.d,
            fg: &v.s.fg,
            cg: &v.s.cg,
            t: v.s.t(),
            h: v.s.h(),
            e: v.s.e(),
            rm: v.s.dv.r,
            gam: v.s.dv.lapse,
        }
    }

    pub fn base_height(&self, p: V3) -> f64 {
        let mut h = self.fg.sample_cubic(&self.t.height, p) as f64;
        let gl = self.cg.sample(&self.d.glacier, p);
        if gl > 1.0 && h > 0.0 {
            h += 0.85 * (gl as f64);
        }
        h
    }

    pub fn rough_at(&self, p: V3) -> f64 {
        self.fg.sample(&self.t.rough, p) as f64
    }

    /// Per-octave constants of the fractal detail. They depend only on the planet radius and lam_min (not on the
    /// position), so a chunk builds this once instead of redoing a division per octave per sample.
    pub fn make_detail_tab(&self, lam_min: f64) -> DetailTab {
        let mut t = DetailTab { n: 0, sc: [0.0; 14], o1: [0.0; 14], o2: [0.0; 14], o3: [0.0; 14] };
        let mut lam = 62000.0f64;
        let mut j = 0usize;
        while j < 14 && lam >= lam_min {
            t.sc[j] = self.rm / lam;
            t.o1[j] = 17.3 * (j as f64);
            t.o2[j] = 9.1 * (j as f64);
            t.o3[j] = 5.7 * (j as f64);
            t.n = j + 1;
            j += 1;
            lam *= 0.5;
        }
        t
    }

    /// fractal detail (metres) from a prepared table.
    pub fn detail_t(&self, p: V3, rough: f64, base: f64, tb: &DetailTab) -> f64 {
        let nz = &self.s.noise;
        let mut sum = 0.0f64;
        let land = if base > -30.0 { 1.0 } else { 0.16 };
        let mut amp = 560.0 * rough * land;
        let mut gx = 0.0f32;
        let mut gy = 0.0f32;
        let mut gz = 0.0f32;
        for j in 0..tb.n {
            let sc = tb.sc[j];
            let (n, g) = nz.n3d((p.x * sc + tb.o1[j]) as f32, (p.y * sc - tb.o2[j]) as f32, (p.z * sc + tb.o3[j]) as f32);
            gx += g[0];
            gy += g[1];
            gz += g[2];
            let damp = 1.0 / (1.0 + 0.55 * ((gx * gx + gy * gy + gz * gz) as f64));
            let v: f32 = if j < 4 { (1.0f32 - n.abs()) * 1.6f32 - 0.8f32 } else { n };
            sum += amp * (v as f64) * damp;
            amp *= 0.5359;
        }
        sum
    }

    /// fractal detail (metres). lam_min = smallest wavelength worth synthesising.
    pub fn detail(&self, p: V3, rough: f64, base: f64, lam_min: f64) -> f64 {
        let tb = self.make_detail_tab(lam_min);
        self.detail_t(p, rough, base, &tb)
    }

    pub fn height(&self, p: V3, lam_min: f64) -> f64 {
        let b = self.base_height(p);
        b + self.detail(p, self.rough_at(p), b, lam_min)
    }

    /// current-date climate at coarse resolution (bilinear)
    pub fn cur(&self, f: &[f32], p: V3) -> f32 {
        self.cg.sample(f, p)
    }
}
