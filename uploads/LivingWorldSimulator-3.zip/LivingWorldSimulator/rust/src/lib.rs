//! Living World Simulator engine (Rust). Planet generation, climate/ecology simulation, terrain streaming,
//! OpenGL ES rendering, camera and gestures. No external crates.
//!
//! The shared library is called `libvoxelsandbox.so` only because the CI workflow checks for that file name.

#![allow(
    dead_code,
    unused_variables,
    unused_mut,
    unused_assignments,
    unused_imports,
    non_snake_case,
    non_camel_case_types,
    non_upper_case_globals,
    unused_parens,
    clippy::all
)]

pub mod app;
pub mod biome;
pub mod camera;
pub mod chunk;
pub mod civ;
pub mod climate;
pub mod ecology;
pub mod explain;
pub mod gl;
pub mod grid;
pub mod jni_bridge;
pub mod mathx;
pub mod noise;
pub mod params;
pub mod render;
pub mod sampler;
pub mod tectonics;
pub mod terrain;
pub mod world;
pub mod world_data;

#[cfg(test)]
mod tests {
    use crate::grid::*;
    use crate::mathx::*;
    use crate::noise::Noise;
    use crate::world::parse_seed;

    #[test]
    fn deterministic_math_matches_std() {
        for i in -50..50 {
            let x = (i as f64) * 0.37;
            assert!((dsin(x) - x.sin()).abs() < 1e-9);
            assert!((dcos(x) - x.cos()).abs() < 1e-9);
            assert!((dexp(x * 0.2) - (x * 0.2).exp()).abs() < 1e-9 * (x * 0.2).exp().max(1.0));
        }
        assert!((dlog(12.5) - 12.5f64.ln()).abs() < 1e-12);
        assert!((datan2(1.0, -2.0) - (1.0f64).atan2(-2.0)).abs() < 1e-9);
        assert!((dacos(0.3) - 0.3f64.acos()).abs() < 1e-9);
    }

    #[test]
    fn noise_is_bounded_and_seeded() {
        let a = Noise::new(42);
        let b = Noise::new(42);
        let c = Noise::new(43);
        let mut differs = false;
        for i in 0..200 {
            let x = (i as f32) * 0.173;
            let va = a.n3(x, x * 0.5, 1.3);
            assert!(va.abs() < 1.3);
            assert_eq!(va, b.n3(x, x * 0.5, 1.3));
            if (va - c.n3(x, x * 0.5, 1.3)).abs() > 1e-6 {
                differs = true;
            }
        }
        assert!(differs);
    }

    #[test]
    fn grid_cell_lookup_roundtrip() {
        let mut g = CubeGrid::default();
        g.build(24, true);
        for c in (0..g.count).step_by(7) {
            assert_eq!(g.cell_of(g.pos[c]), c);
        }
        let field: Vec<f32> = (0..g.count).map(|_| 3.5f32).collect();
        let v = g.sample(&field, normalize(V3::new(0.3, -0.7, 0.2)));
        assert!((v - 3.5).abs() < 1e-5);
    }

    #[test]
    fn seeds_parse_stably() {
        assert_eq!(parse_seed("EARTH-7F42A91C"), parse_seed("EARTH-7F42A91C"));
        assert_ne!(parse_seed("EARTH-7F42A91C"), parse_seed("EARTH-7F42A91D"));
        assert_ne!(parse_seed("hello"), parse_seed("hellp"));
    }
}
