//! Civilization layer. People settle the simulated planet, spread along rivers and coasts over fertile land, learn
//! new technologies and are shaped by the planet's real climate, soils, water, resources and hazards.
//! Nothing here is painted: carrying capacity comes straight from the ecology fields (biome, fertility, NPP,
//! rivers, coasts, aridity, slope, elevation) and from the resource potentials (coal, iron, oil, ...), so changing
//! the climate (planet parameters) changes where people can live, and they react.
//!
//! The model is a population field on the fine terrain grid: logistic growth towards the local carrying capacity,
//! migration from crowded cells into emptier neighbours, technology that raises the capacity (farming, metals,
//! industry - the last two need resources nearby), and rare disasters taken from the hazard maps.

use crate::biome::*;
use crate::grid::*;
use crate::mathx::*;
use crate::world::*;
use crate::world_data::*;

pub const ERA_NAMES: [&str; 6] = ["Hunter-gatherers", "Early farming", "Bronze & Iron Age", "Industrial Age", "Modern Age", "Information Age"];

pub fn era_name(tech: f64) -> &'static str {
    let i = if tech < 0.0 { 0usize } else { (tech.floor() as usize).min(5) };
    ERA_NAMES[i]
}

/// how liveable each biome is for people (index = biome id: ocean, rainforest, seasonal forest, savanna, desert,
/// semi-arid, grassland, temperate forest, boreal, tundra, alpine, wetland, mangrove, ice, lake)
const BIOME_HAB: [f64; 15] = [0.0, 0.55, 0.85, 0.80, 0.05, 0.35, 1.0, 0.95, 0.28, 0.08, 0.06, 0.40, 0.35, 0.0, 0.0];

const PLAGUES: [&str; 4] = ["The Grey Fever", "The Red Plague", "A great pandemic", "The Sweating Sickness"];

const POP_MIN: f32 = 0.3;
const SETTLERS: f32 = 400.0;

/// A city marker handed to the renderer.
#[derive(Clone, Copy, Default)]
pub struct CityMark {
    pub dir: V3,
    pub h: f32,
    pub size: f32,
}

/// Snapshot published for the UI / renderer (cheap to read from any thread).
#[derive(Clone, Default)]
pub struct CivPublic {
    pub marks: Vec<CityMark>,
    pub total: f64,
    pub cities: usize,
    pub tech: f64,
    pub year: f64,
    pub started: bool,
    pub msg_seq: u64,
    pub msg: String,
    pub chronicle: String,
}

fn pl(x: f64, xs: &[f64], ys: &[f64]) -> f64 {
    let n = xs.len();
    if x <= xs[0] {
        return ys[0];
    }
    for i in 1..n {
        if x <= xs[i] {
            let t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
            return ys[i - 1] + (ys[i] - ys[i - 1]) * t;
        }
    }
    ys[n - 1]
}

/// (subsistence density, industrial density) in people per km2 on perfect land at this technology level
fn densities(t: f64) -> (f64, f64) {
    let xs = [0.0f64, 1.0, 2.0, 3.0];
    let ys = [0.25f64, 2.5, 10.0, 22.0];
    let xi = [3.0f64, 4.0, 5.0];
    let yi = [0.0f64, 60.0, 120.0];
    (pl(t, &xs, &ys), pl(t, &xi, &yi))
}

#[inline]
fn cap_cell(hab: f32, rich: f32, area_sr: f32, r_km2: f64, d_base: f64, d_ind: f64) -> f64 {
    if hab <= 0.0 {
        return 0.0;
    }
    (hab as f64) * (area_sr as f64) * r_km2 * (d_base + d_ind * (0.25 + 0.75 * (rich as f64)))
}

fn fmt_people(x: f64) -> String {
    if x >= 1.0e9 {
        format!("{:.2} billion", x / 1.0e9)
    } else if x >= 1.0e6 {
        format!("{:.1} million", x / 1.0e6)
    } else if x >= 1.0e3 {
        format!("{:.0}k", x / 1.0e3)
    } else {
        format!("{:.0}", x)
    }
}

fn fmt_int(v: i64) -> String {
    let s = format!("{}", v.abs());
    let len = s.len();
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i > 0 && (len - i) % 3 == 0 {
            out.push(',');
        }
        out.push(ch);
    }
    if v < 0 {
        format!("-{}", out)
    } else {
        out
    }
}

/// disaster rate (events per year) of one cell from the simulated hazard maps
fn hazard_weights(e: &EcoData, c: usize) -> [f64; 4] {
    let sz = e.seismic_haz[c] as f64;
    let vc = e.volc_haz[c] as f64;
    let fl = e.flood_haz[c] as f64;
    let dr = e.drought_haz[c] as f64;
    [8.0e-5 * sz * sz, 5.0e-5 * vc * vc, 2.5e-4 * fl * fl, 1.5e-4 * dr * dr]
}

pub struct Civ {
    pop: Vec<f32>,
    delta: Vec<f32>,
    hab: Vec<f32>,
    rich: Vec<f32>,
    act: Vec<u32>,
    sid: u32,
    r_km2: f64,
    tech: f64,
    year: f64,
    total: f64,
    peak: f64,
    started: bool,
    pending: f64,
    last_era: usize,
    next_ms: f64,
    first_city: bool,
    last_total: f64,
    last_check: f64,
    last_big_event: f64,
    nsea: u32,
    events: Vec<String>,
    msg: String,
    msg_seq: u64,
    rng: Rng,
    marks: Vec<CityMark>,
    ncities: usize,
}

impl Civ {
    pub fn new() -> Civ {
        Civ {
            pop: Vec::new(),
            delta: Vec::new(),
            hab: Vec::new(),
            rich: Vec::new(),
            act: Vec::new(),
            sid: 0,
            r_km2: 4.06e7,
            tech: 0.0,
            year: 0.0,
            total: 0.0,
            peak: 0.0,
            started: false,
            pending: 0.0,
            last_era: 0,
            next_ms: 1.0e4,
            first_city: false,
            last_total: 0.0,
            last_check: 0.0,
            last_big_event: -1.0e9,
            nsea: 0,
            events: Vec::new(),
            msg: String::new(),
            msg_seq: 0,
            rng: Rng::new(0xC1B1CAFEu64),
            marks: Vec::new(),
            ncities: 0,
        }
    }

    /// a new planet (or a geological step that remade the continents): everything starts over
    pub fn reset(&mut self, note: &str) {
        let was = self.started;
        for x in self.pop.iter_mut() {
            *x = 0.0;
        }
        self.tech = 0.0;
        self.year = 0.0;
        self.total = 0.0;
        self.peak = 0.0;
        self.started = false;
        self.pending = 0.0;
        self.last_era = 0;
        self.next_ms = 1.0e4;
        self.first_city = false;
        self.last_total = 0.0;
        self.last_check = 0.0;
        self.last_big_event = -1.0e9;
        self.nsea = 0;
        self.marks.clear();
        self.ncities = 0;
        self.events.clear();
        self.sid = 0;
        self.hab.clear();
        self.rich.clear();
        if was && !note.is_empty() {
            self.msg = note.to_string();
            self.msg_seq += 1;
            self.events.push(note.to_string());
        }
    }

    pub fn publish(&self) -> CivPublic {
        let mut text = String::new();
        for e in self.events.iter().rev() {
            text.push_str(e);
            text.push('\n');
        }
        CivPublic {
            marks: self.marks.clone(),
            total: self.total,
            cities: self.ncities,
            tech: self.tech,
            year: self.year,
            started: self.started,
            msg_seq: self.msg_seq,
            msg: self.msg.clone(),
            chronicle: text,
        }
    }

    fn toast(&mut self, text: String) {
        self.msg = text;
        self.msg_seq += 1;
    }

    fn say(&mut self, text: String) {
        let line = format!("Year {}: {}", fmt_int(self.year.floor() as i64), text);
        self.events.push(line.clone());
        if self.events.len() > 80 {
            self.events.remove(0);
        }
        self.toast(line);
    }

    fn loc_text(&self, v: &View, c: usize) -> String {
        let fg: &CubeGrid = &*v.s.fg;
        let lat = (fg.lat[c] as f64) * RAD2DEG;
        let lon = (fg.lon[c] as f64) * RAD2DEG;
        format!(
            "{:.0}{} {:.0}{} ({})",
            lat.abs(),
            if lat >= 0.0 { "N" } else { "S" },
            lon.abs(),
            if lon >= 0.0 { "E" } else { "W" },
            biome_name(v.s.e().biome[c] as i32)
        )
    }

    /// allocate the population field and (re)derive habitability / resource richness whenever the planet snapshot changed
    fn ensure(&mut self, v: &View) {
        let n = v.s.fg.count;
        if self.pop.len() != n {
            self.pop = vec![0.0; n];
            self.delta = vec![0.0; n];
            self.hab.clear();
            self.rich.clear();
            self.sid = 0;
        }
        if self.sid != v.s.id || self.hab.len() != n {
            self.rebuild_caches(v);
        }
    }

    fn rebuild_caches(&mut self, v: &View) {
        let s = &v.s;
        let t: &TerrainData = s.t();
        let h: &HydroData = s.h();
        let e: &EcoData = s.e();
        let fg: &CubeGrid = &*s.fg;
        let n = fg.count;
        let rkm = s.dv.r / 1000.0;
        self.r_km2 = rkm * rkm;
        let both: Vec<[f32; 2]> = par_map(n, |c: usize| -> [f32; 2] {
            let ht = t.height[c] as f64;
            if ht <= 0.0 {
                return [0.0, 0.0];
            }
            // resources that matter for industry
            let coal = e.res[R_COAL][c] as f64;
            let iron = e.res[R_IRON][c] as f64;
            let oil = e.res[R_OIL][c] as f64;
            let cu = e.res[R_COPPER][c] as f64;
            let gas = e.res[R_GAS][c] as f64;
            let rich = clampv((coal + 0.8 * iron + 0.5 * oil + 0.4 * cu + 0.2 * gas) / (255.0 * 1.6), 0.0, 1.0);
            let bf = BIOME_HAB[(e.biome[c] as usize).min(14)];
            if bf <= 0.0 {
                return [0.0, rich as f32];
            }
            let f = clampv(e.fertility[c] as f64, 0.0, 1.0);
            let np = clampv((e.npp[c] as f64) / 1500.0, 0.0, 1.0);
            // fresh water: rivers and coasts
            let q = h.discharge[c] as f64;
            let river = clampv(dlog(q.max(1.0)) / 9.210340371976184, 0.0, 1.0);
            let mut coast = false;
            for k in 0..4usize {
                let nb = fg.nbr[c * 8 + k];
                if nb >= 0 && t.height[nb as usize] <= 0.0 {
                    coast = true;
                }
            }
            let wet = if coast { river.max(0.8) } else { river };
            let rain = clampv((e.aridity[c] as f64) / 0.5, 0.0, 1.0);
            let water = 0.45 + 0.55 * wet.max(rain);
            let tc = e.t_ann[c] as f64;
            let comfort = 0.55 + 0.45 * dexp(-sqr((tc - 17.0) / 15.0));
            let slope = clampv(1.0 - (t.slope[c] as f64) / 0.08, 0.15, 1.0);
            let elev = clampv(1.0 - (ht - 1500.0) / 3500.0, 0.1, 1.0);
            let hab = bf * (0.30 + 0.70 * f) * (0.40 + 0.60 * np) * water * comfort * slope * elev;
            [clampv(hab, 0.0, 1.0) as f32, rich as f32]
        });
        let mut hab: Vec<f32> = Vec::with_capacity(n);
        let mut rich: Vec<f32> = Vec::with_capacity(n);
        for b in both.iter() {
            hab.push(b[0]);
            rich.push(b[1]);
        }
        self.hab = hab;
        self.rich = rich;
        self.sid = s.id;
    }

    /// put settlers on the land near the given point (the camera centre)
    pub fn settle(&mut self, v: &View, lat_deg: f64, lon_deg: f64) {
        self.ensure(v);
        let fg: &CubeGrid = &*v.s.fg;
        let d = from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD);
        let c0 = fg.cell_of(d);
        let mut best = usize::MAX;
        if self.hab[c0] >= 0.08 {
            best = c0;
        } else {
            let mut bh = 0.08f32;
            for k in 0..8usize {
                let nb = fg.nbr[c0 * 8 + k];
                if nb < 0 {
                    continue;
                }
                let q = nb as usize;
                if self.hab[q] > bh {
                    bh = self.hab[q];
                    best = q;
                }
                for k2 in 0..8usize {
                    let nb2 = fg.nbr[q * 8 + k2];
                    if nb2 < 0 {
                        continue;
                    }
                    let q2 = nb2 as usize;
                    if self.hab[q2] > bh {
                        bh = self.hab[q2];
                        best = q2;
                    }
                }
            }
        }
        if best == usize::MAX {
            self.toast(String::from("Settlers cannot survive here. Pick fertile land (green, near water)."));
            return;
        }
        if !self.started {
            self.started = true;
            self.tech = 0.0;
            self.last_era = 0;
            self.pending = 0.0;
            self.last_total = 0.0;
            self.last_check = self.year;
            self.rng = Rng::new(mix64(v.s.seed ^ 0xC1B1CAFEu64));
        }
        self.pop[best] += SETTLERS;
        let loc = self.loc_text(v, best);
        self.say(format!("Settlers ({} people) arrive near {}", SETTLERS as i32, loc));
        self.refresh_marks(v);
    }

    /// advance the civilization by `years`; returns true when the state changed (something to publish)
    pub fn advance(&mut self, v: &View, years: f64) -> bool {
        if !self.started || years <= 0.0 {
            return false;
        }
        self.year += years;
        self.pending += years;
        if self.pending < 2.0 {
            return false;
        }
        self.ensure(v);
        let mut n_steps = (self.pending / 20.0).ceil() as usize;
        if n_steps < 1 {
            n_steps = 1;
        }
        if n_steps > 48 {
            n_steps = 48;
        }
        let dt = self.pending / (n_steps as f64);
        self.pending = 0.0;
        for _ in 0..n_steps {
            if !self.started {
                break;
            }
            self.micro(v, dt);
        }
        self.refresh_marks(v);
        true
    }

    fn micro(&mut self, v: &View, dt: f64) {
        let s = &v.s;
        let fg: &CubeGrid = &*s.fg;
        let e: &EcoData = s.e();
        let n = fg.count;
        let (d_base, d_ind) = densities(self.tech);
        let r2 = self.r_km2;
        let r_gr = 0.012 + 0.008 * clampv(self.tech / 4.0, 0.0, 1.0);
        let grow_f = dexp(-r_gr * dt);
        let die_f = dexp(-0.05 * dt);
        let mm = 0.08 * (1.0 + 0.4 * self.tech) * dt;

        // populated cells
        self.act.clear();
        for c in 0..n {
            if self.pop[c] >= POP_MIN {
                self.act.push(c as u32);
            }
        }

        // logistic growth towards (or decline to) the carrying capacity, which follows the simulated climate
        for i in 0..self.act.len() {
            let c = self.act[i] as usize;
            let p = self.pop[c] as f64;
            let k = cap_cell(self.hab[c], self.rich[c], fg.area[c], r2, d_base, d_ind);
            let pn = if k > 1.0 { k / (1.0 + (k / p - 1.0) * grow_f) } else { p * die_f };
            self.pop[c] = pn as f32;
        }

        // migration: people move from crowded cells to emptier neighbours (population is conserved)
        for x in self.delta.iter_mut() {
            *x = 0.0;
        }
        for i in 0..self.act.len() {
            let c = self.act[i] as usize;
            let p = self.pop[c] as f64;
            let kc = cap_cell(self.hab[c], self.rich[c], fg.area[c], r2, d_base, d_ind);
            let uc = p / kc.max(50.0);
            for k in 0..8usize {
                let nb = fg.nbr[c * 8 + k];
                if nb < 0 {
                    continue;
                }
                let q = nb as usize;
                if self.hab[q] <= 0.0 {
                    continue;
                }
                let kq = cap_cell(self.hab[q], self.rich[q], fg.area[q], r2, d_base, d_ind);
                let uq = (self.pop[q] as f64) / kq.max(50.0);
                let du = uc - uq;
                if du <= 0.0 {
                    continue;
                }
                let w = if k < 4 { 1.0 } else { 0.7 };
                let mut fl = mm * du * w / 6.8;
                if fl > 0.1 {
                    fl = 0.1;
                }
                let out = (p * fl) as f32;
                self.delta[c] -= out;
                self.delta[q] += out;
            }
        }
        for c in 0..n {
            let d = self.delta[c];
            if d != 0.0 {
                let mut nv = self.pop[c] + d;
                if nv < POP_MIN {
                    nv = 0.0;
                }
                self.pop[c] = nv;
            }
        }

        // disasters from the simulated hazard maps (earthquakes, eruptions, floods, droughts)
        let mut sum_lam = 0.0f64;
        for i in 0..self.act.len() {
            let c = self.act[i] as usize;
            if self.pop[c] < 800.0 {
                continue;
            }
            let w = hazard_weights(e, c);
            sum_lam += w[0] + w[1] + w[2] + w[3];
        }
        if sum_lam > 0.0 && self.rng.uni() < 1.0 - dexp(-sum_lam * dt) {
            let target = self.rng.uni() * sum_lam;
            let mut acc = 0.0f64;
            let mut pick = usize::MAX;
            for i in 0..self.act.len() {
                let c = self.act[i] as usize;
                if self.pop[c] < 800.0 {
                    continue;
                }
                let w = hazard_weights(e, c);
                acc += w[0] + w[1] + w[2] + w[3];
                if acc >= target {
                    pick = c;
                    break;
                }
            }
            if pick != usize::MAX {
                self.disaster(v, pick);
            }
        }

        // pandemics: more likely when the world is crowded and connected
        let lam_pl = (1.0 / 300.0) * clampv(self.total / 2.0e5, 0.0, 1.0) * (if self.tech >= 1.0 { 1.0 } else { 0.25 });
        if self.rng.uni() < 1.0 - dexp(-lam_pl * dt) {
            let sev = self.rng.range(0.06, 0.28);
            let mut killed = 0.0f64;
            for i in 0..self.act.len() {
                let c = self.act[i] as usize;
                let p = self.pop[c] as f64;
                if p < 200.0 {
                    continue;
                }
                let kc = cap_cell(self.hab[c], self.rich[c], fg.area[c], r2, d_base, d_ind);
                let u = clampv(p / kc.max(50.0) * 1.1, 0.0, 1.0);
                let loss = p * sev * u;
                self.pop[c] = (p - loss) as f32;
                killed += loss;
            }
            if killed > 1000.0 {
                let name = PLAGUES[self.rng.irange(0, 3) as usize];
                self.say(format!("{} sweeps the world: {} perished", name, fmt_people(killed)));
                self.last_big_event = self.year;
            }
        }

        // seafaring: once ships exist, groups cross the sea and found colonies on other shores
        if self.tech >= 1.2 && !self.act.is_empty() {
            let lam = dt / 80.0;
            let mut tries = lam.floor() as usize;
            if self.rng.uni() < lam - lam.floor() {
                tries += 1;
            }
            if tries > 8 {
                tries = 8;
            }
            let reach = 2500.0 + 1500.0 * clampv(self.tech - 1.2, 0.0, 1.0);
            let rkm = s.dv.r / 1000.0;
            for _ in 0..tries {
                let idx = self.rng.irange(0, (self.act.len() as i32) - 1) as usize;
                let c0 = self.act[idx] as usize;
                if (self.pop[c0] as f64) < 2000.0 {
                    continue;
                }
                let d0 = fg.pos[c0];
                let (ee, nn) = east_north(d0);
                let th = self.rng.range(0.0, TAU);
                let (st, ct) = dsincos(th);
                let tang = ee * ct + nn * st;
                let a = self.rng.range(500.0, reach) / rkm;
                let (sa, ca) = dsincos(a);
                let d1 = normalize(d0 * ca + tang * sa);
                let c1 = fg.cell_of(d1);
                if self.hab[c1] > 0.18 && self.pop[c1] < 1.0 {
                    let mv = 150.0f32;
                    self.pop[c0] = (self.pop[c0] - mv).max(0.0);
                    self.pop[c1] = mv;
                    self.nsea += 1;
                    if self.nsea <= 8 || self.nsea % 10 == 0 {
                        let la = self.loc_text(v, c0);
                        let lb = self.loc_text(v, c1);
                        self.say(format!("Seafarers from {} found a colony near {}", la, lb));
                    }
                }
            }
        }

        // totals, resource access
        let mut total = 0.0f64;
        let mut rsum = 0.0f64;
        for c in 0..n {
            let p = self.pop[c];
            if p > 0.0 {
                total += p as f64;
                rsum += (p as f64) * (self.rich[c] as f64);
            }
        }
        self.total = total;
        if total > self.peak {
            self.peak = total;
        }
        if total < 1.0 {
            for x in self.pop.iter_mut() {
                *x = 0.0;
            }
            self.started = false;
            self.tech = 0.0;
            self.last_era = 0;
            self.next_ms = 1.0e4;
            self.first_city = false;
            self.last_total = 0.0;
            self.total = 0.0;
            self.marks.clear();
            self.ncities = 0;
            self.say(String::from("The last of your people have died out. Settle again to start over."));
            return;
        }
        let ra = rsum / total;

        // technology grows with the number of minds; industry stalls on worlds without coal, iron and oil
        let mut inc = dt * 1.0e-4 * (total / 1.0e5 + 0.05).sqrt();
        if self.tech >= 3.0 {
            inc *= 0.15 + 0.85 * clampv(ra * 2.0, 0.0, 1.0);
        }
        self.tech = (self.tech + inc).min(5.0);
        let era = (self.tech.floor() as usize).min(5);
        if era > self.last_era {
            self.last_era = era;
            self.say(format!("A new age begins: {}", ERA_NAMES[era]));
        }
        while self.total >= self.next_ms && self.next_ms < 1.0e11 {
            let m = self.next_ms;
            self.next_ms *= 10.0;
            self.say(format!("World population passes {}", fmt_people(m)));
        }
        if self.year - self.last_check >= 30.0 {
            if self.last_total > 20000.0 && self.total < 0.88 * self.last_total && self.year - self.last_big_event > 60.0 {
                let a = self.last_total;
                let b = self.total;
                self.say(format!("Great famine: world population fell from {} to {}", fmt_people(a), fmt_people(b)));
                self.last_big_event = self.year;
            }
            self.last_total = self.total;
            self.last_check = self.year;
        }
    }

    fn disaster(&mut self, v: &View, c: usize) {
        let e: &EcoData = v.s.e();
        let fg: &CubeGrid = &*v.s.fg;
        let w = hazard_weights(e, c);
        let tot = w[0] + w[1] + w[2] + w[3];
        let tgt = self.rng.uni() * tot;
        let mut kind = 3usize;
        let mut acc = 0.0f64;
        for k in 0..4usize {
            acc += w[k];
            if tgt <= acc {
                kind = k;
                break;
            }
        }
        let fc = match kind {
            0 => self.rng.range(0.12, 0.40),
            1 => self.rng.range(0.35, 0.80),
            2 => self.rng.range(0.10, 0.30),
            _ => self.rng.range(0.15, 0.40),
        };
        let fnb = match kind {
            0 => fc * 0.4,
            1 => fc * 0.35,
            2 => fc * 0.4,
            _ => fc * 0.6,
        };
        let p = self.pop[c] as f64;
        let mut killed = p * fc;
        self.pop[c] = (p - killed) as f32;
        for k in 0..8usize {
            let nb = fg.nbr[c * 8 + k];
            if nb < 0 {
                continue;
            }
            let q = nb as usize;
            let pq = self.pop[q] as f64;
            let loss = pq * fnb;
            killed += loss;
            self.pop[q] = (pq - loss) as f32;
        }
        if killed >= (4000.0f64).max(0.003 * self.total) {
            let name = match kind {
                0 => "A great earthquake strikes",
                1 => "A volcano erupts",
                2 => "A catastrophic flood hits",
                _ => "Drought and famine grip",
            };
            let loc = self.loc_text(v, c);
            self.say(format!("{} near {}: about {} perished", name, loc, fmt_people(killed)));
            self.last_big_event = self.year;
        }
    }

    /// cities = local population maxima above a threshold that grows with technology
    fn refresh_marks(&mut self, v: &View) {
        self.marks.clear();
        self.ncities = 0;
        if !self.started || self.pop.is_empty() {
            return;
        }
        let fg: &CubeGrid = &*v.s.fg;
        let t: &TerrainData = v.s.t();
        let n = fg.count;
        let thr = (1500.0 * (1.0 + 1.5 * self.tech)) as f32;
        let mut cand: Vec<(f32, u32)> = Vec::new();
        for c in 0..n {
            let p = self.pop[c];
            if p < thr {
                continue;
            }
            let mut top = true;
            for k in 0..8usize {
                let nb = fg.nbr[c * 8 + k];
                if nb >= 0 && self.pop[nb as usize] > p {
                    top = false;
                    break;
                }
            }
            if top {
                cand.push((p, c as u32));
            }
        }
        self.ncities = cand.len();
        cand.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        cand.truncate(96);
        for i in 0..cand.len() {
            let p = cand[i].0;
            let c = cand[i].1 as usize;
            let size = clampv(0.15 + 0.85 * (dlog((p / thr) as f64) / 4.605170185988092), 0.0, 1.0);
            self.marks.push(CityMark { dir: fg.pos[c], h: t.height[c].max(0.0) + 120.0, size: size as f32 });
        }
        if !self.first_city && !cand.is_empty() {
            self.first_city = true;
            let loc = self.loc_text(v, cand[0].1 as usize);
            self.say(format!("The first city rises near {}", loc));
        }
    }

    /// short text for the "Why is this here?" dialog
    pub fn cell_info(&self, v: &View, lat_deg: f64, lon_deg: f64) -> String {
        let n = v.s.fg.count;
        if self.pop.len() != n || self.hab.len() != n {
            return String::new();
        }
        let fg: &CubeGrid = &*v.s.fg;
        let c = fg.cell_of(from_lat_lon(lat_deg * DEG2RAD, lon_deg * DEG2RAD));
        let p = self.pop[c] as f64;
        let hab = self.hab[c] as f64;
        let mut out = String::new();
        if hab > 0.0 {
            out.push_str(&format!("\nHABITABILITY: {:.0}% for people (fertility, water, climate and terrain).", hab * 100.0));
        } else if v.s.t().height[c] > 0.0 {
            out.push_str("\nHABITABILITY: people cannot live here (too cold, too dry or covered by water or ice).");
        }
        if p >= 1.0 {
            out.push_str(&format!("\nPEOPLE: about {} live in this region.", fmt_people(p)));
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn piecewise_linear_is_clamped() {
        let xs = [0.0f64, 1.0, 2.0];
        let ys = [1.0f64, 3.0, 7.0];
        assert!((pl(-1.0, &xs, &ys) - 1.0).abs() < 1e-12);
        assert!((pl(0.5, &xs, &ys) - 2.0).abs() < 1e-12);
        assert!((pl(5.0, &xs, &ys) - 7.0).abs() < 1e-12);
    }

    #[test]
    fn numbers_are_formatted() {
        assert_eq!(fmt_int(1234567), "1,234,567");
        assert_eq!(fmt_int(12), "12");
        assert_eq!(fmt_people(2_500_000.0), "2.5 million");
    }
}
