//! Streaming terrain chunks. A chunk is a quadtree node of a cube-face: a 33x33 vertex mesh (+skirts)
//! and two small textures (albedo+water mask, tangent-space normal), generated on worker threads.

use crate::biome::*;
use crate::grid::*;
use crate::mathx::*;
use crate::sampler::*;
use crate::tectonics::*;
use crate::world::*;
use crate::world_data::*;

pub const KG: i32 = 32; // mesh cells per chunk edge
pub const KVG: i32 = KG + 1; // vertices per edge
pub const KVERT_COUNT: usize = (KVG * KVG + 4 * KVG) as usize; // grid + 4 skirts
pub const KVERT_BYTES: usize = 16; // float3 position + 2x uint16 uv
pub const KT: i32 = 96; // texels per chunk edge
pub const KD: i32 = KT + 2; // texture size incl. 1 texel border
pub const KALBEDO_BYTES: usize = (KD * KD * 4) as usize;
pub const KNORMAL_BYTES: usize = (KD * KD * 2) as usize;
pub const KMAX_LEVEL: i32 = 16;
const KLN: usize = (KT + 3) as usize; // lattice samples per edge (1 border + 1 spare each side)

pub const L_VISUAL: i32 = 0;
pub const L_ELEVATION: i32 = 1;
pub const L_TEMPERATURE: i32 = 2;
pub const L_RAINFALL: i32 = 3;
pub const L_WIND: i32 = 4;
pub const L_PRESSURE: i32 = 5;
pub const L_RIVERS: i32 = 6;
pub const L_PLATES: i32 = 7;
pub const L_BOUNDARIES: i32 = 8;
pub const L_BIOMES: i32 = 9;
pub const L_SOIL: i32 = 10;
pub const L_OCEAN_DEPTH: i32 = 11;
pub const L_COUNT: i32 = 12;

struct Stop {
    v: f32,
    r: f32,
    g: f32,
    b: f32,
}
const fn st(v: f32, r: f32, g: f32, b: f32) -> Stop {
    Stop { v, r, g, b }
}

fn ramp_color(tbl: &[Stop], v: f32) -> (f32, f32, f32) {
    let n = tbl.len();
    if v <= tbl[0].v {
        return (tbl[0].r, tbl[0].g, tbl[0].b);
    }
    for i in 1..n {
        if v <= tbl[i].v {
            let t = (v - tbl[i - 1].v) / (tbl[i].v - tbl[i - 1].v);
            return (
                tbl[i - 1].r + (tbl[i].r - tbl[i - 1].r) * t,
                tbl[i - 1].g + (tbl[i].g - tbl[i - 1].g) * t,
                tbl[i - 1].b + (tbl[i].b - tbl[i - 1].b) * t,
            );
        }
    }
    (tbl[n - 1].r, tbl[n - 1].g, tbl[n - 1].b)
}

const K_ELEV: [Stop; 11] = [
    st(-8000.0, 0.02, 0.05, 0.25),
    st(-4000.0, 0.04, 0.15, 0.45),
    st(-1000.0, 0.10, 0.35, 0.65),
    st(-100.0, 0.30, 0.65, 0.85),
    st(0.0, 0.55, 0.85, 0.90),
    st(1.0, 0.20, 0.55, 0.20),
    st(300.0, 0.45, 0.65, 0.25),
    st(800.0, 0.75, 0.72, 0.35),
    st(1800.0, 0.62, 0.45, 0.28),
    st(3500.0, 0.55, 0.45, 0.42),
    st(5500.0, 0.97, 0.97, 0.97),
];
const K_TEMP: [Stop; 7] = [
    st(-40.0, 0.45, 0.20, 0.65),
    st(-20.0, 0.20, 0.30, 0.85),
    st(0.0, 0.40, 0.80, 0.90),
    st(10.0, 0.40, 0.80, 0.40),
    st(20.0, 0.95, 0.90, 0.30),
    st(30.0, 0.95, 0.50, 0.15),
    st(40.0, 0.85, 0.10, 0.10),
];
const K_RAIN: [Stop; 6] = [
    st(0.0, 0.90, 0.80, 0.50),
    st(250.0, 0.90, 0.90, 0.55),
    st(800.0, 0.50, 0.80, 0.40),
    st(1600.0, 0.20, 0.60, 0.50),
    st(3000.0, 0.15, 0.40, 0.80),
    st(5000.0, 0.40, 0.15, 0.65),
];
const K_PRES: [Stop; 3] = [st(985.0, 0.20, 0.30, 0.85), st(1013.0, 0.90, 0.90, 0.90), st(1040.0, 0.85, 0.20, 0.15)];
const K_FERT: [Stop; 4] = [st(0.0, 0.78, 0.66, 0.45), st(0.4, 0.60, 0.65, 0.25), st(0.7, 0.25, 0.60, 0.20), st(1.0, 0.05, 0.35, 0.10)];
const K_DEPTH: [Stop; 5] = [
    st(0.0, 0.60, 0.90, 0.95),
    st(200.0, 0.25, 0.65, 0.85),
    st(1000.0, 0.10, 0.40, 0.70),
    st(4000.0, 0.05, 0.15, 0.45),
    st(8000.0, 0.01, 0.02, 0.15),
];
const K_SPEED: [Stop; 4] = [st(0.0, 0.10, 0.15, 0.40), st(5.0, 0.20, 0.70, 0.85), st(10.0, 0.95, 0.90, 0.30), st(20.0, 1.0, 0.30, 0.15)];

/// Chunk samples sit on a regular (u,v) lattice, so everything that depends on only one of u / v (cell index,
/// fraction, spline weights, tan()) is computed once per column / row instead of once per sample.
#[derive(Clone, Copy, Default)]
struct Axis {
    i0: i32,
    t: f32,
    w: [f32; 4], // Catmull-Rom weights (filled when cubic_w)
}

fn axis_at(n: i32, uv: f64, cubic_w: bool) -> Axis {
    let fu = (uv + 1.0) * 0.5 * (n as f64) - 0.5;
    let i0 = fu.floor() as i32;
    let t = (fu - (i0 as f64)) as f32;
    let mut a = Axis { i0, t, w: [0.0; 4] };
    if cubic_w {
        let t2 = t * t;
        let t3 = t2 * t;
        a.w[0] = -0.5 * t3 + t2 - 0.5 * t;
        a.w[1] = 1.5 * t3 - 2.5 * t2 + 1.0;
        a.w[2] = -1.5 * t3 + 2.0 * t2 + 0.5 * t;
        a.w[3] = 0.5 * t3 - 0.5 * t2;
    }
    a
}

#[inline]
fn locate_ax(g: &CubeGrid, face: usize, x: &Axis, y: &Axis) -> ([usize; 4], [f32; 4]) {
    let ids = [
        g.cell_ext(face, x.i0, y.i0),
        g.cell_ext(face, x.i0 + 1, y.i0),
        g.cell_ext(face, x.i0, y.i0 + 1),
        g.cell_ext(face, x.i0 + 1, y.i0 + 1),
    ];
    let w = [(1.0 - x.t) * (1.0 - y.t), x.t * (1.0 - y.t), (1.0 - x.t) * y.t, x.t * y.t];
    (ids, w)
}

#[inline]
fn cubic_ax(g: &CubeGrid, face: usize, f: &[f32], x: &Axis, y: &Axis) -> f32 {
    let inside = x.i0 >= 1 && x.i0 + 2 < g.n && y.i0 >= 1 && y.i0 + 2 < g.n;
    let mut sum = 0.0f32;
    for b in 0..4i32 {
        let mut row = 0.0f32;
        for a in 0..4i32 {
            let c = if inside { g.idx(face, x.i0 - 1 + a, y.i0 - 1 + b) } else { g.cell_ext(face, x.i0 - 1 + a, y.i0 - 1 + b) };
            row += x.w[a as usize] * f[c];
        }
        sum += y.w[b as usize] * row;
    }
    sum
}

/// per-thread scratch memory, reused for every chunk a worker builds
pub struct Scratch {
    dir: Vec<V3>,
    h: Vec<f32>,
    wl: Vec<f32>,
    p: Vec<V3>,
    riv: Vec<f32>,
    lat_fx: Vec<Axis>,
    lat_fy: Vec<Axis>,
    lat_cx: Vec<Axis>,
    lat_cy: Vec<Axis>,
    tan_u: Vec<f64>,
    tan_v: Vec<f64>,
    tex_fx: Vec<Axis>,
    tex_fy: Vec<Axis>,
    tex_cx: Vec<Axis>,
    tex_cy: Vec<Axis>,
}
impl Scratch {
    pub fn new() -> Scratch {
        let ln = KLN;
        let kd = KD as usize;
        Scratch {
            dir: vec![V3::default(); ln * ln],
            h: vec![0.0; ln * ln],
            wl: vec![0.0; ln * ln],
            p: vec![V3::default(); ln * ln],
            riv: vec![0.0; kd * kd],
            lat_fx: vec![Axis::default(); ln],
            lat_fy: vec![Axis::default(); ln],
            lat_cx: vec![Axis::default(); ln],
            lat_cy: vec![Axis::default(); ln],
            tan_u: vec![0.0; ln],
            tan_v: vec![0.0; ln],
            tex_fx: vec![Axis::default(); kd],
            tex_fy: vec![Axis::default(); kd],
            tex_cx: vec![Axis::default(); kd],
            tex_cy: vec![Axis::default(); kd],
        }
    }
}

pub struct ChunkOut {
    pub vtx: Vec<u8>,
    pub albedo: Vec<u8>,
    pub normal: Vec<u8>,
    /// [0..3] origin (chunk centre at sea level, metres from planet centre), [3] bounding radius, [4] min height, [5] max height
    pub meta: [f64; 9],
}
impl ChunkOut {
    pub fn new() -> ChunkOut {
        ChunkOut { vtx: vec![0u8; KVERT_COUNT * KVERT_BYTES], albedo: vec![0u8; KALBEDO_BYTES], normal: vec![0u8; KNORMAL_BYTES], meta: [0.0; 9] }
    }
}

/// rasterise river segments of the fine-grid flow network into riv[KD*KD]
fn raster_rivers(s: &Sampler, face: usize, u0: f64, v0: f64, size: f64, tex_m: f64, fnv: V3, t1: V3, t2: V3, riv: &mut [f32]) {
    let g = s.fg;
    let n = g.n;
    let kd = KD as usize;
    let q_thr = (3.0f64).max(40.0 * tex_m / 1000.0);
    let i0 = clampv((((u0 + 1.0) * 0.5 * (n as f64)).floor() as i32) - 2, 0, n - 1);
    let i1 = clampv((((u0 + size + 1.0) * 0.5 * (n as f64)).floor() as i32) + 2, 0, n - 1);
    let j0 = clampv((((v0 + 1.0) * 0.5 * (n as f64)).floor() as i32) - 2, 0, n - 1);
    let j1 = clampv((((v0 + size + 1.0) * 0.5 * (n as f64)).floor() as i32) + 2, 0, n - 1);
    let to_xy = |p: V3| -> (f64, f64) {
        let dn = dot(p, fnv);
        let a = dot(p, t1) / dn;
        let b = dot(p, t2) / dn;
        let x = (datan(a) * (4.0 / PI) - u0) / size * (KT as f64);
        let y = (datan(b) * (4.0 / PI) - v0) / size * (KT as f64);
        (x, y)
    };
    for j in j0..=j1 {
        for i in i0..=i1 {
            let c = g.idx(face, i, j);
            let q = s.h.discharge[c] as f64;
            if q < q_thr || s.t.height[c] <= 0.0 {
                continue;
            }
            let r = s.h.rec[c];
            if r < 0 || dot(g.pos[r as usize], fnv) < 0.2 {
                continue;
            }
            let ru = r as usize;
            let p0 = g.pos[c];
            let p1 = g.pos[ru];
            let mut wm = 2.5 * q.sqrt();
            if s.t.height[ru] <= 0.0 {
                wm *= 1.8;
            }
            let wpx = clampv(wm / tex_m, 1.15, 40.0);
            let dvv = p1 - p0;
            let len = length(dvv);
            let mut x0 = 0.0f64;
            let mut y0 = 0.0f64;
            const M: i32 = 6;
            for k in 0..=M {
                let sf = (k as f64) / (M as f64);
                let mut p = normalize(p0 * (1.0 - sf) + p1 * sf);
                let nse = s.s.noise.n3(((c % 997) as f32) * 0.731 + (sf as f32) * 2.3, ((c / 997) as f32) * 0.377, 3.1) as f64;
                let perp = normalize(cross(p, dvv));
                p = normalize(p + perp * (0.34 * len * dsin(PI * sf) * nse));
                let (x, y) = to_xy(p);
                if k > 0 {
                    let minx = x.min(x0) - wpx - 1.0;
                    let maxx = x.max(x0) + wpx + 1.0;
                    let miny = y.min(y0) - wpx - 1.0;
                    let maxy = y.max(y0) + wpx + 1.0;
                    let tx0 = clampv((minx.floor() as i32) + 1, 0, KD - 1);
                    let tx1 = clampv((maxx.ceil() as i32) + 1, 0, KD - 1);
                    let ty0 = clampv((miny.floor() as i32) + 1, 0, KD - 1);
                    let ty1 = clampv((maxy.ceil() as i32) + 1, 0, KD - 1);
                    let ex = x - x0;
                    let ey = y - y0;
                    let el2 = ex * ex + ey * ey;
                    for ty in ty0..=ty1 {
                        for tx in tx0..=tx1 {
                            let cx = (tx as f64) - 0.5;
                            let cy = (ty as f64) - 0.5;
                            let tt = if el2 > 1e-12 { clampv(((cx - x0) * ex + (cy - y0) * ey) / el2, 0.0, 1.0) } else { 0.0 };
                            let dx = cx - (x0 + ex * tt);
                            let dy = cy - (y0 + ey * tt);
                            let dd = (dx * dx + dy * dy).sqrt();
                            let a = clampv(wpx * 0.5 + 0.75 - dd, 0.0, 1.0) as f32;
                            let o = &mut riv[(ty as usize) * kd + (tx as usize)];
                            if a > *o {
                                *o = a;
                            }
                        }
                    }
                }
                x0 = x;
                y0 = y;
            }
        }
    }
}

pub fn build_chunk(v: &View, face: usize, level: i32, cx: i32, cy: i32, layer: i32, scr: &mut Scratch, out: &mut ChunkOut) -> bool {
    let s = Sampler::new(v);
    let r = s.rm;
    let n_tiles = 1i32 << level;
    let size = 2.0 / (n_tiles as f64);
    let u0 = -1.0 + (cx as f64) * size;
    let v0 = -1.0 + (cy as f64) * size;
    let (fnv, t1, t2) = face_axes(face);
    let cdir = face_dir(face, u0 + size * 0.5, v0 + size * 0.5);
    let c0 = cdir * r;
    let edge_m = length(face_dir(face, u0, v0 + size * 0.5) - face_dir(face, u0 + size, v0 + size * 0.5)) * r;
    let tex_m = edge_m / (KT as f64);
    let lam_min = (5.0f64).max(2.2 * tex_m);
    let ln = KLN;
    let kd = KD as usize;
    let fg = s.fg;
    let cgr = s.cg;
    let t = s.t;
    let hy = s.h;
    let e = s.e;
    let d = s.d;
    let Scratch { dir, h, wl, p: pp, riv, lat_fx, lat_fy, lat_cx, lat_cy, tan_u, tan_v, tex_fx, tex_fy, tex_cx, tex_cy } = scr;
    for x in riv.iter_mut() {
        *x = 0.0;
    }

    // ---- lattice of positions and heights ----------------------------------------------------------
    {
        let kt = KT as f64;
        for li in 0..ln {
            let u = u0 + ((li as f64) - 1.0) * size / kt;
            lat_fx[li] = axis_at(fg.n, u, true);
            lat_cx[li] = axis_at(cgr.n, u, false);
            tan_u[li] = dtan(u * (PI / 4.0));
        }
        for lj in 0..ln {
            let vv = v0 + ((lj as f64) - 1.0) * size / kt;
            lat_fy[lj] = axis_at(fg.n, vv, true);
            lat_cy[lj] = axis_at(cgr.n, vv, false);
            tan_v[lj] = dtan(vv * (PI / 4.0));
        }
        let dtab = s.make_detail_tab(lam_min);
        let height_p: &[f32] = &t.height;
        let glacier_p: &[f32] = &d.glacier;
        let rough_p: &[f32] = &t.rough;
        let lake_p: &[f32] = &hy.lake_level;
        for lj in 0..ln {
            let yf = lat_fy[lj];
            let yc = lat_cy[lj];
            for li in 0..ln {
                let xf = lat_fx[li];
                let xc = lat_cx[li];
                let p = dir_from_tan(face, tan_u[li], tan_v[lj]);
                let k = lj * ln + li;
                dir[k] = p;
                let mut base = cubic_ax(fg, face, height_p, &xf, &yf) as f64;
                let (ids, w) = locate_ax(cgr, face, &xc, &yc);
                let mut gl = 0.0f32;
                for q in 0..4usize {
                    gl += w[q] * glacier_p[ids[q]];
                }
                if gl > 1.0 && base > 0.0 {
                    base += 0.85 * (gl as f64);
                }
                let (ids, w) = locate_ax(fg, face, &xf, &yf);
                let mut rough = 0.0f32;
                let mut ll = 0.0f32;
                for q in 0..4usize {
                    rough += w[q] * rough_p[ids[q]];
                    ll += w[q] * lake_p[ids[q]];
                }
                let hh = base + s.detail_t(p, rough as f64, base, &dtab);
                h[k] = hh as f32;
                let lake = (ll as f64) > hh + 0.5 && ll > 0.5 && base > -5.0;
                wl[k] = if lake {
                    ll
                } else if hh < 0.0 {
                    0.0
                } else {
                    -1e5
                };
                let surf = hh.max(wl[k] as f64);
                pp[k] = p * (r + (if hh < 0.0 { hh } else { surf }));
            }
        }
    }

    // ---- vertex buffer ------------------------------------------------------------------------------
    {
        let skirt = clampv(edge_m * 0.03, 8.0, 8000.0) as f32;
        let mut maxr = 0.0f64;
        let mut hmin = 1e9f64;
        let mut hmax = -1e9f64;
        let vtx = &mut out.vtx;
        let mut put = |idx: usize, gi: i32, gj: i32, sk: bool| {
            let li = (1 + gi * (KT / KG)) as usize;
            let lj = (1 + gj * (KT / KG)) as usize;
            let k = lj * ln + li;
            let mut surf = (h[k] as f64).max(wl[k] as f64);
            if surf < 0.0 {
                surf = 0.0;
            }
            hmin = hmin.min(surf);
            hmax = hmax.max(surf);
            let pos = dir[k] * (r + surf - (if sk { skirt as f64 } else { 0.0 })) - c0;
            let o = idx * KVERT_BYTES;
            vtx[o..o + 4].copy_from_slice(&(pos.x as f32).to_le_bytes());
            vtx[o + 4..o + 8].copy_from_slice(&(pos.y as f32).to_le_bytes());
            vtx[o + 8..o + 12].copy_from_slice(&(pos.z as f32).to_le_bytes());
            maxr = maxr.max(length(pos));
            let ug = clampv((65535.0 * (gi as f64) / (KG as f64)).round() as i32, 0, 65535) as u16;
            let vg = clampv((65535.0 * (gj as f64) / (KG as f64)).round() as i32, 0, 65535) as u16;
            vtx[o + 12..o + 14].copy_from_slice(&ug.to_le_bytes());
            vtx[o + 14..o + 16].copy_from_slice(&vg.to_le_bytes());
        };
        for gj in 0..KVG {
            for gi in 0..KVG {
                put((gj * KVG + gi) as usize, gi, gj, false);
            }
        }
        let base = KVG * KVG;
        for i in 0..KVG {
            put((base + i) as usize, i, 0, true);
        }
        for i in 0..KVG {
            put((base + KVG + i) as usize, i, KG, true);
        }
        for j in 0..KVG {
            put((base + 2 * KVG + j) as usize, 0, j, true);
        }
        for j in 0..KVG {
            put((base + 3 * KVG + j) as usize, KG, j, true);
        }
        out.meta[0] = c0.x;
        out.meta[1] = c0.y;
        out.meta[2] = c0.z;
        out.meta[3] = maxr + 1.0;
        out.meta[4] = hmin;
        out.meta[5] = hmax;
        out.meta[6] = t1.x;
        out.meta[7] = t1.y;
        out.meta[8] = t1.z;
    }

    // ---- rivers ---------------------------------------------------------------------------------------
    if layer == L_VISUAL || layer == L_RIVERS || layer == L_BIOMES {
        raster_rivers(&s, face, u0, v0, size, tex_m, fnv, t1, t2, riv.as_mut_slice());
    }

    // ---- per-texel textures -----------------------------------------------------------------------------
    let gam = s.gam;
    let mut tf = TectFrame::default();
    if layer == L_PLATES || layer == L_BOUNDARIES {
        tf = s.s.tect.make_frame(s.s.tect_time_myr);
    }
    let det_sc = (40.0f64).max(r / (9.0 * tex_m));
    let light_fixed = normalize(V3::new(-0.5, 0.6, 0.62));
    for ti in 0..kd {
        let u = u0 + ((ti as f64) - 0.5) * size / (KT as f64);
        tex_fx[ti] = axis_at(fg.n, u, false);
        tex_cx[ti] = axis_at(cgr.n, u, false);
    }
    for tj in 0..kd {
        let vv = v0 + ((tj as f64) - 0.5) * size / (KT as f64);
        tex_fy[tj] = axis_at(fg.n, vv, false);
        tex_cy[tj] = axis_at(cgr.n, vv, false);
    }
    let nz = &s.s.noise;
    for tj in 0..kd {
        for ti in 0..kd {
            let k00 = tj * ln + ti;
            let k10 = k00 + 1;
            let k01 = k00 + ln;
            let k11 = k01 + 1;
            let nrm_c = normalize(dir[k00] + dir[k10] + dir[k01] + dir[k11]);
            let hh = 0.25 * ((h[k00] as f64) + (h[k10] as f64) + (h[k01] as f64) + (h[k11] as f64));
            let wlv = 0.25 * ((wl[k00] as f64) + (wl[k10] as f64) + (wl[k01] as f64) + (wl[k11] as f64));
            let lake_t = wlv > hh + 0.5 && wlv > 0.5 && (wl[k00] > 0.0 || wl[k11] > 0.0);
            let ocean_t = !lake_t && hh < 0.0;
            let water = lake_t || ocean_t;
            // surface normal from the lattice
            let tx = (pp[k10] + pp[k11] - pp[k00] - pp[k01]) * 0.5;
            let ty = (pp[k01] + pp[k11] - pp[k00] - pp[k10]) * 0.5;
            let mut nrm = normalize(cross(tx, ty));
            if dot(nrm, nrm_c) < 0.0 {
                nrm = -nrm;
            }
            // tangent-space normal (water is flat) and slope: only derived where they are used
            let mut nx = 0.0f64;
            let mut ny = 0.0f64;
            if !water {
                let tt1 = normalize(t1 - nrm_c * dot(t1, nrm_c));
                let tt2 = cross(nrm_c, tt1);
                nx = dot(nrm, tt1);
                ny = dot(nrm, tt2);
            }
            let nz_f = dot(nrm, nrm_c);
            let slope_tan = (0.0f64).max(1.0 - nz_f * nz_f).sqrt() / (0.05f64).max(nz_f);
            {
                let o = (tj * kd + ti) * 2;
                out.normal[o] = u8c(nx * 0.5 + 0.5);
                out.normal[o + 1] = u8c(ny * 0.5 + 0.5);
            }
            // fine-grid climate fields
            let (ids, w) = locate_ax(fg, face, &tex_fx[ti], &tex_fy[tj]);
            let f_at = |f: &Vec<f32>| -> f64 { (w[0] * f[ids[0]] + w[1] * f[ids[1]] + w[2] * f[ids[2]] + w[3] * f[ids[3]]) as f64 };
            let hb = f_at(&t.height);
            let mut cs = ids[0];
            {
                let mut mx = w[0];
                for q in 1..4usize {
                    if w[q] > mx {
                        mx = w[q];
                        cs = ids[q];
                    }
                }
            }
            let mut rr = 0.0f64;
            let mut gg = 0.0f64;
            let mut bb = 0.0f64;
            let mut aw = 0.0f64;
            if layer == L_ELEVATION {
                let h2 = if water { if lake_t { wlv } else { hh } } else { hh };
                let (a, b, c) = ramp_color(&K_ELEV, h2 as f32);
                rr = a as f64;
                gg = b as f64;
                bb = c as f64;
            } else if layer == L_OCEAN_DEPTH {
                if ocean_t {
                    let (a, b, c) = ramp_color(&K_DEPTH, (-hh) as f32);
                    rr = a as f64;
                    gg = b as f64;
                    bb = c as f64;
                } else if lake_t {
                    rr = 0.3;
                    gg = 0.6;
                    bb = 0.7;
                } else {
                    let c = clampv(0.25 + hh / 6000.0, 0.15, 0.6);
                    rr = c;
                    gg = c * 0.95;
                    bb = c * 0.9;
                }
            } else if layer == L_TEMPERATURE {
                let (cid, cw) = locate_ax(cgr, face, &tex_cx[ti], &tex_cy[tj]);
                let mut ta = 0.0f64;
                let mut zm = 0.0f64;
                for q in 0..4usize {
                    let src = if ocean_t { d.ts[cid[q]] } else { d.ta[cid[q]] };
                    ta += (cw[q] * src) as f64;
                    zm += (cw[q] * s.s.st().z_mean[cid[q]]) as f64;
                }
                let mut tcur = ta - 273.15;
                if !ocean_t {
                    tcur -= gam * (hh.max(0.0) - zm);
                }
                let (a, b, c) = ramp_color(&K_TEMP, tcur as f32);
                rr = a as f64;
                gg = b as f64;
                bb = c as f64;
            } else if layer == L_RAINFALL {
                let (a, b, c) = ramp_color(&K_RAIN, f_at(&e.p_ann) as f32);
                rr = a as f64;
                gg = b as f64;
                bb = c as f64;
            } else if layer == L_PRESSURE {
                let (cid, cw) = locate_ax(cgr, face, &tex_cx[ti], &tex_cy[tj]);
                let mut p = 0.0f64;
                for q in 0..4usize {
                    p += (cw[q] * d.pres[cid[q]]) as f64;
                }
                let (a, b, c) = ramp_color(&K_PRES, p as f32);
                rr = a as f64;
                gg = b as f64;
                bb = c as f64;
                let ph = p / 4.0;
                let fr = ph - ph.floor();
                let iso = smoothstep(0.10, 0.0, fr.min(1.0 - fr) * 4.0 * 0.5);
                rr *= 1.0 - 0.35 * iso;
                gg *= 1.0 - 0.35 * iso;
                bb *= 1.0 - 0.35 * iso;
            } else if layer == L_WIND {
                let cc = cgr.cell_of(nrm_c);
                let wu = d.wu[cc] as f64;
                let wv = d.wv[cc] as f64;
                let sp = (wu * wu + wv * wv).sqrt();
                let (ev, nv) = east_north(cgr.pos[cc]);
                let dvv = nrm_c - cgr.pos[cc];
                let xx = dot(dvv, ev) * r / 1000.0;
                let yy = dot(dvv, nv) * r / 1000.0;
                let cell_km = cgr.cell_km(cc, r / 1000.0);
                let ux = if sp > 1e-6 { wu / sp } else { 1.0 };
                let uy = if sp > 1e-6 { wv / sp } else { 0.0 };
                let l = cell_km * clampv(0.15 + 0.035 * sp, 0.15, 0.46);
                let hl = l * 0.5;
                let a = xx * ux + yy * uy;
                let bq = -xx * uy + yy * ux;
                let base = if water { 0.10 } else { 0.16 };
                rr = base * 0.6;
                gg = base * 0.8;
                bb = base + (if ocean_t { 0.10 } else { 0.0 });
                let wb = cell_km * 0.035;
                let body = a.abs() <= hl && bq.abs() < wb;
                let head = a > hl - 0.32 * l && a <= hl + 0.08 * l && bq.abs() < (hl + 0.08 * l - a) * 0.55;
                if body || head {
                    let (x1, y1, z1) = ramp_color(&K_SPEED, sp as f32);
                    rr = x1 as f64;
                    gg = y1 as f64;
                    bb = z1 as f64;
                }
            } else if layer == L_PLATES || layer == L_BOUNDARIES {
                let ts = s.s.tect.sample(&tf, nrm_c);
                let hsh = mix64((ts.plate as u64) * 977 + 5);
                let mut pr = 0.35 + 0.5 * ((hsh & 255) as f64) / 255.0;
                let mut pg = 0.35 + 0.5 * (((hsh >> 8) & 255) as f64) / 255.0;
                let mut pb = 0.35 + 0.5 * (((hsh >> 16) & 255) as f64) / 255.0;
                let mut dim = if water { 0.55 } else { 1.0 };
                if layer == L_BOUNDARIES {
                    let v = if water { 0.10 } else { 0.22 };
                    pr = v;
                    pg = v;
                    pb = v + (if water { 0.12 } else { 0.0 });
                    dim = 1.0;
                }
                rr = pr * dim;
                gg = pg * dim;
                bb = pb * dim;
                let wk = (tex_m * 1.0).max(if layer == L_BOUNDARIES { 22.0 } else { 10.0 }) / 1000.0;
                let thr2 = tex_m.max(14.0) / 1000.0 * (if layer == L_BOUNDARIES { 1.6 } else { 1.0 });
                if ts.dist_km < wk * 1.0 || ts.dist_km < thr2 {
                    if ts.kind == 1 {
                        rr = 1.0;
                        gg = 0.2;
                        bb = 0.15;
                    } else if ts.kind == 2 {
                        rr = 0.25;
                        gg = 0.5;
                        bb = 1.0;
                    } else if ts.kind == 3 {
                        rr = 0.3;
                        gg = 0.95;
                        bb = 0.3;
                    } else {
                        rr = 0.9;
                        gg = 0.9;
                        bb = 0.9;
                    }
                }
            } else if layer == L_SOIL {
                if water {
                    rr = 0.06;
                    gg = 0.10;
                    bb = 0.20;
                } else {
                    let (a, b, c) = ramp_color(&K_FERT, f_at(&e.fertility) as f32);
                    rr = a as f64;
                    gg = b as f64;
                    bb = c as f64;
                }
            } else {
                // ---------------- visual / biome / rivers ----------------
                let (cid, cw) = locate_ax(cgr, face, &tex_cx[ti], &tex_cy[tj]);
                let cc_at = |f: &Vec<f32>| -> f64 { (cw[0] * f[cid[0]] + cw[1] * f[cid[1]] + cw[2] * f[cid[2]] + cw[3] * f[cid[3]]) as f64 };
                let px = (nrm_c.x * det_sc) as f32;
                let py = (nrm_c.y * det_sc) as f32;
                let pz = (nrm_c.z * det_sc) as f32;
                let nz1 = nz.fbm(px, py, pz, 3) as f64;
                let tint = 1.0 + 0.10 * nz1;
                if ocean_t {
                    let depth = -hh;
                    let zz = clampv(depth, 0.0, 9000.0);
                    let (a, b, c) = ramp_color(&K_DEPTH, zz as f32);
                    rr = a as f64;
                    gg = b as f64;
                    bb = c as f64;
                    let sh = dot(nrm, light_fixed) - 0.55;
                    let fdepth = dexp(-depth / 500.0);
                    let fac = 1.0 + 0.9 * fdepth * clampv(sh, -0.6, 0.6);
                    rr *= fac;
                    gg *= fac;
                    bb *= fac;
                    let ice = cc_at(&d.ice);
                    let ic = smoothstep(0.30 + 0.25 * nz1, 0.75 + 0.25 * nz1, ice);
                    if ic > 0.0 {
                        rr = rr + (0.86 - rr) * ic;
                        gg = gg + (0.92 - gg) * ic;
                        bb = bb + (0.96 - bb) * ic;
                    }
                    aw = 1.0 - 0.75 * ic;
                } else if lake_t {
                    let depth = (0.0f64).max(wlv - hh);
                    let tt = clampv(depth / 60.0, 0.0, 1.0);
                    rr = 0.10 - 0.04 * tt;
                    gg = 0.36 - 0.14 * tt;
                    bb = 0.45 - 0.12 * tt;
                    let lk2 = hy.lake_kind[cs];
                    if lk2 == 3 {
                        rr = 0.82;
                        gg = 0.82;
                        bb = 0.78;
                        aw = 0.2;
                    } else {
                        aw = 1.0;
                    }
                } else {
                    // land: derive biome from local climate (lapse-corrected for the fine terrain)
                    let dh = hh - hb;
                    let t_ann = f_at(&e.t_ann) - gam * dh;
                    let t_min = f_at(&e.t_min) - gam * dh;
                    let t_max = f_at(&e.t_max) - gam * dh;
                    let p_ann = f_at(&e.p_ann);
                    let ai = f_at(&e.aridity);
                    let rv = riv[tj * kd + ti] as f64;
                    let wet = clampv(f_at(&e.soil_moist) * (1.0 - clampv(slope_tan / 0.1, 0.0, 1.0)) * 0.9 + 0.4 * rv - 0.2, 0.0, 1.0);
                    let coastal = hb < 14.0;
                    let bi = BiomeIn {
                        t_ann,
                        t_min,
                        t_max,
                        p_ann,
                        aridity: ai,
                        dry_months: f_at(&e.p_dry_frac) * 12.0,
                        elev: hh,
                        slope: slope_tan * 0.25,
                        wetness: wet,
                        lat_abs: 0.0,
                        coastal,
                    };
                    let bio = classify_biome_lazy(&bi, || lat_of(nrm_c).abs() * RAD2DEG);
                    let (cr, cg2, cb) = biome_color(bio as i32);
                    rr = cr as f64;
                    gg = cg2 as f64;
                    bb = cb as f64;
                    if layer == L_VISUAL {
                        let veg = if bio == B_DESERT || bio == B_ICE || bio == B_ALPINE { 0.25 } else { 1.0 };
                        // patchiness & soil tone
                        let n2 = nz.fbm(px * 0.21 + 7.0, py * 0.21, pz * 0.21, 3) as f64;
                        let soil_tone = 1.0 + 0.16 * n2;
                        rr *= tint * soil_tone;
                        gg *= tint * soil_tone * (1.0 + 0.05 * n2 * veg);
                        bb *= tint * soil_tone;
                        // exposed rock on steep ground and above the vegetation limit
                        let steep = smoothstep(0.45, 1.1, slope_tan);
                        let mut bare = steep.max(smoothstep(9.0, 3.0, t_max) * 0.8);
                        if bio == B_DESERT {
                            bare *= 0.6;
                        }
                        let rk = 0.34 + 0.12 * nz1;
                        rr += (rk * 1.05 - rr) * bare;
                        gg += (rk * 0.98 - gg) * bare;
                        bb += (rk * 0.90 - bb) * bare;
                        // snow: seasonal cover from the simulated snow depth + permanent snow above the snow line
                        let tcur = cc_at(&d.ta) - 273.15 - gam * (hh - cc_at(&s.s.st().z_mean));
                        let sdepth = cc_at(&d.snow);
                        let snow_season = smoothstep(1.0, -3.0, tcur) * clampv(0.15 + sdepth / 50.0, 0.0, 1.0);
                        let glc = cc_at(&d.glacier);
                        let gk = smoothstep(2.0, 70.0, glc + 30.0 * nz1);
                        let snow_perm = smoothstep(2.0, -1.0, t_max).max(gk * smoothstep(9.0, 0.0, t_max));
                        let mut snow = snow_season.max(snow_perm);
                        snow *= 1.0 - 0.55 * steep;
                        if bio == B_ICE {
                            snow = 1.0;
                        }
                        let sn = snow * (0.9 + 0.1 * nz1);
                        rr += (0.93 - rr) * sn;
                        gg += (0.95 - gg) * sn;
                        bb += (0.98 - bb) * sn;
                        // beaches
                        if hh < 4.0 && coastal && wet < 0.8 {
                            let bt = smoothstep(4.0, 0.0, hh) * 0.75;
                            rr += (0.80 - rr) * bt;
                            gg += (0.74 - gg) * bt;
                            bb += (0.55 - bb) * bt;
                        }
                    }
                    if layer == L_RIVERS {
                        rr *= 0.45;
                        gg *= 0.45;
                        bb *= 0.45;
                    }
                }
                let rv = riv[tj * kd + ti];
                if rv > 0.0 && !ocean_t && (layer == L_VISUAL || layer == L_RIVERS || layer == L_BIOMES) {
                    let cr = if layer == L_RIVERS { 0.10 } else { 0.12 };
                    let cg2 = if layer == L_RIVERS { 0.55 } else { 0.34 };
                    let cb = if layer == L_RIVERS { 1.0 } else { 0.52 };
                    let rvd = rv as f64;
                    rr += (cr - rr) * rvd;
                    gg += (cg2 - gg) * rvd;
                    bb += (cb - bb) * rvd;
                    aw = aw.max(rvd * 0.8);
                }
                if layer == L_RIVERS && lake_t {
                    rr = 0.2;
                    gg = 0.7;
                    bb = 1.0;
                }
                if layer == L_RIVERS && ocean_t {
                    rr *= 0.35;
                    gg *= 0.4;
                    bb *= 0.6;
                }
                if layer == L_BIOMES && !water {
                    // flat biome colours, without photographic variation
                    let dh = hh - hb;
                    let t_ann = f_at(&e.t_ann) - gam * dh;
                    let wet = clampv(f_at(&e.soil_moist) * (1.0 - clampv(slope_tan / 0.1, 0.0, 1.0)) * 0.9 - 0.2, 0.0, 1.0);
                    let bi = BiomeIn {
                        t_ann,
                        t_min: f_at(&e.t_min) - gam * dh,
                        t_max: f_at(&e.t_max) - gam * dh,
                        p_ann: f_at(&e.p_ann),
                        aridity: f_at(&e.aridity),
                        dry_months: f_at(&e.p_dry_frac) * 12.0,
                        elev: hh,
                        slope: slope_tan * 0.25,
                        wetness: wet,
                        lat_abs: 0.0,
                        coastal: hb < 14.0,
                    };
                    let (cr, cg2, cb) = biome_color(classify_biome_lazy(&bi, || lat_of(nrm_c).abs() * RAD2DEG) as i32);
                    rr = cr as f64;
                    gg = cg2 as f64;
                    bb = cb as f64;
                }
            }
            let o = (tj * kd + ti) * 4;
            out.albedo[o] = u8c(rr);
            out.albedo[o + 1] = u8c(gg);
            out.albedo[o + 2] = u8c(bb);
            out.albedo[o + 3] = u8c(if layer == L_VISUAL || layer == L_RIVERS { aw } else { 0.0 });
        }
    }
    true
}

/// Equirectangular cloud opacity (R8). The simulated cloud cover decides *where* the sky is cloudy; fractal noise
/// (domain-warped, so systems look frontal and swirling) decides the shape. A soft threshold keeps the sky
/// statistically as cloudy as the simulation says, with clear gaps that show the land and sea below.
pub fn build_cloud_texture(v: &View, w: usize, h: usize, out: &mut Vec<u8>) {
    out.clear();
    out.resize(w * h, 0);
    let cg: &CubeGrid = &v.s.cg;
    let nz = &v.s.noise;
    let cloud: &Vec<f32> = &v.d.cloud;
    let rows: Vec<Vec<u8>> = par_map(h, |y| {
        let lat = (0.5 - ((y as f64) + 0.5) / (h as f64)) * PI;
        let mut row = vec![0u8; w];
        for x in 0..w {
            let lon = (((x as f64) + 0.5) / (w as f64) - 0.5) * TAU;
            let p = from_lat_lon(lat, lon);
            let cover = cg.sample(cloud, p) as f64;
            let px = p.x as f32;
            let py = p.y as f32;
            let pz = p.z as f32;
            // domain warp -> swirling, frontal shapes
            let wx = nz.fbm(px * 2.1 + 11.0, py * 2.1, pz * 2.1, 3);
            let wy = nz.fbm(px * 2.1, py * 2.1 + 5.0, pz * 2.1, 3);
            let wz = nz.fbm(px * 2.1, py * 2.1, pz * 2.1 + 9.0, 3);
            let qx = px + 0.14 * wx;
            let qy = py + 0.14 * wy;
            let qz = pz + 0.14 * wz;
            let big = nz.fbm(qx * 2.4 + 3.0, qy * 2.4, qz * 2.4, 4);
            let mid = nz.fbm(qx * 6.5, qy * 6.5 + 2.0, qz * 6.5, 3);
            let fin = nz.fbm(qx * 19.0, qy * 19.0, qz * 19.0 + 4.0, 2);
            let nn = 0.64 * (big as f64) + 0.28 * (mid as f64) + 0.08 * (fin as f64);
            // logistic approximation of the noise CDF -> uniform in [0,1]
            let sigma = 0.185f64;
            let u = 1.0 / (1.0 + dexp(-nn / (sigma * 0.5882)));
            let dd = cover - u;
            let mut a = smoothstep(-0.17, 0.25, dd);
            a *= 0.76 + 0.24 * smoothstep(0.05, 0.55, dd);
            row[x] = u8c(a);
        }
        row
    });
    for y in 0..h {
        out[y * w..(y + 1) * w].copy_from_slice(&rows[y]);
    }
}
