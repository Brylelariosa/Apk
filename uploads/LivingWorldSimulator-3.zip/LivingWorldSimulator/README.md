# Living World Simulator 2.1 (Rust engine)

A procedurally generated planet that is simulated, not painted: plate tectonics build the crust, erosion carves it,
a coupled seasonal climate (sun, pressure belts, winds, ocean gyres, moisture, rain shadows, snow, ice) drives rivers,
lakes, soils and biomes. Everything is rendered live as a streamed, level-of-detail globe from orbit down to the ground.

## Architecture

| Part | Language | Where |
|---|---|---|
| Simulation (noise, tectonics, terrain, climate, hydrology, ecology, "Why?" explanations) | Rust | `rust/src/*.rs` |
| Renderer (OpenGL ES 3, chunk streaming, LOD, clouds, atmosphere), camera, gestures, sim thread | Rust | `render.rs`, `camera.rs`, `app.rs` |
| JNI bridge | Rust (hand-written, no crates) | `jni_bridge.rs` |
| Android shell (window, widgets, dialogs) | Kotlin | `app/src/main/java/...` (3 small files) |

The Rust crate has **no external dependencies**. The CI workflow builds it with `cargo-ndk` (ABIs from `rustAbis=` in
`gradle.properties`) into `app/src/main/jniLibs`, and Gradle only packages the result.

The shared library is named `libvoxelsandbox.so` because the workflow's Rust step looks for exactly that file name.
If you ever want a different name, change both `[lib] name` in `rust/Cargo.toml` + `System.loadLibrary` in `Native.kt`
and the `libvoxelsandbox.so` check in the workflow.

## Controls

* one finger drag - grab the globe (the surface under the finger follows it; slower when the planet is small on screen)
* release - gentle inertia, capped and quickly fading
* pinch - zoom, two-finger twist - rotate the view, two-finger vertical drag - tilt
* double tap - glide to that point and zoom in (zooms back out when already close)
* the **+** in the middle of the screen marks the spot that **Settle here** and **Why?** refer to
* Reset view, Sun +6h, Step, speed (1 hour/s ... 1 million years/s), SIMULATE/PAUSE, layers (DEBUG), "Why?" explains the point under the crosshair

## Play: a living world (new in 2.1)

* **Settle here** puts 400 settlers on the land under the + (it picks the nearest liveable cell if you are on water or ice). The first
  time, the clock starts at 10 years/s so you can watch. People grow, spread along rivers and coasts, found cities, cross seas and
  suffer the planet's real earthquakes, eruptions, floods, droughts and pandemics. Cities show as dots on the day side and glow
  at night.
* Carrying capacity is computed from the simulated planet, not painted: biome, soil fertility, NPP, rivers, coasts, aridity,
  temperature comfort, slope and elevation. Technology (farming -> metals -> industry) raises it; industry stalls on worlds
  without coal, iron and oil, so every planet tells a different story.
* **Chronicle** lists the history (settlements, ages, population milestones, disasters, famines); important events also pop up above the
  bottom bar. "Why?" now also shows habitability and the people living at the crosshair.
* **Climate is the game:** open *Planet parameters*, pick a preset (Ice age, Hothouse, Extreme seasons, ...) or move the dials, and
  tap *Apply*. When only climate settings changed (CO2, sunlight, pressure, tilt, rotation, orbit, salinity) the **continents and your
  people are kept** and only the climate and ecosystems are recomputed from the current state (a few seconds instead of a full planet
  build). Watch deserts spread, ice advance and your civilization react. Changing radius, gravity, ocean cover, geothermal or sea
  level builds a new planet.
* A geological step (1 million years/s) remakes the continents, so every civilization is lost - by design.

## Performance (2.1)

* **Visual refresh is paced by real time.** While the simulation ran, every ~18 simulated days all visible terrain tiles were rebuilt
  and the cloud texture regenerated, which kept every worker thread busy forever at month/year-per-second speeds. Refreshes are now
  spaced 1-4 s apart depending on speed, and when the simulation pauses or slows down the latest state is shown immediately.
* **Layers only rebuild when their data changed.** Elevation, rainfall, plates, soil and ocean-depth tiles no longer rebuild on weather
  stamps, only after a slow ecosystem update.
* Loading screen shows how many of the 6 base tiles are ready ("3 of 6 base tiles ready") to make a stuck build visible.
* Same planet, same pixels: nothing about generation, terrain detail or rendering quality was reduced.

## What changed from 1.x

* **Net / perforated look on the planet fixed.** The cloud shell was a 64x32 low-poly sphere: between its vertices the flat
  triangles dip a few kilometres *below* the surface, so the depth test cut a regular lattice of holes into it. The shell is now a
  denser cube-sphere whose vertices are pushed outward so the faceted surface can never sink below the true sphere.
* **Clouds follow the simulation.** Cloud opacity is generated from the simulated cloud cover with a soft threshold on
  domain-warped noise: mean coverage is ~59% with clear gaps (the old mapping was ~88% opaque, a white ball).
* **Swipe rotation fixed.** The old pan moved the globe a fixed distance per pixel (huge when zoomed out, so one swipe could
  spin the planet 300 degrees) and flings carried it much further. Now it is a true "grab the globe" drag with altitude-aware
  gain and a capped, quickly damped inertia.
* **Water budget closes.** Evaporation exceeded precipitation by ~22%; the residual is now returned as ocean rain each month
  (land hydrology and biomes are untouched). Debug panel shows the remaining error (~0%).
* **Smooth simulation time.** Time advances continuously (not one jump per second), keeps accumulating while a slow update runs,
  and slow ecosystem updates no longer block the screen with a loading overlay.
* **Faster generation.** Terrain, climate downscaling, soils/biomes and resources run on all cores (deterministic: the same seed
  gives the same planet on every device and thread count).
* Crash/diagnostic log: Rust panics and Java exceptions are written to `files/crash.log` and shown (with a Copy button) on the next
  launch, since device logs are not readable without a PC.

## Tests

`cargo test --lib` (run by the CI workflow, non-blocking) checks the deterministic math, noise, grid lookups, seed parsing and camera.
