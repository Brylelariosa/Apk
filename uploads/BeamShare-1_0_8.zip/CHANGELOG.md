# Changelog

All notable changes to BeamShare are tracked here. Version numbers match
`versionCode` / `versionName` in `app/build.gradle.kts`. See BUGS_FIXED.md
for user-reported bugs specifically, and KNOWN_LIMITATIONS.md for what's
genuinely unverified.

## [1.0.8] - 2026-11-09

Reported against 1.0.7: transfers should be faster, the sent/received speeds were wrong, some
graphics climbed into the status-bar area, and a ~6 GB file arrived as ~4 GB.

### Fixed
- **Speed readouts were wildly off.** The meter averaged the rate of each 96 KB chunk. Chunks
  arrive in bursts, so a few milliseconds of burst outweighed a long stall and the number came
  out many times too high and jumpy (a simulated 18 MB/s link read about 900 MB/s). Speed is now
  bytes moved over a sliding 3-second window - what a stopwatch would show. The ETA uses it too.
- **Session header.** "Sent" and "Received" only counted finished files, so a big transfer read
  0 until the last byte; they now include what an active transfer has moved. "Speed" used to add
  the upload and download together; it now shows ↑ and ↓ separately.
- **Graphics under the status bar.** `ReadinessGate` dropped the Scaffold's padding as soon as
  everything was ready, so the Receive and Discover screens (QR card, radar, connecting
  animation) were laid out from the very top of the screen, under the status bar and top bar.
  It now applies it. The duplicate navigation-bar inset on the Discover screen's bottom button
  went with it.
- **Large files.** Every size in the code was already 64-bit, so there was no 4 GB limit to
  remove; what could produce one is fixed or now reported:
  - The receiver checks free space before accepting and turns a file away that cannot fit
    ("Not enough free storage" on both phones), instead of filling the storage and failing at
    whatever size that happened to be.
  - A transfer that fails now says why on its row - storage full, storage can't hold a file that
    big (FAT32 cards cap at 4 GB), connection lost, file changed - and how far it got
    ("Connection lost · 4.0 GB of 6.0 GB").
  - The file's size now comes from fstat on its descriptor rather than the provider's reported
    size, and it is read through a plain descriptor stream rather than `AssetFileDescriptor`'s,
    which keeps its remaining length in an int.

### Changed (speed)
- **Reading and writing overlap** (`PipelinedCopy`): a reader and a writer share a pool of
  256 KB blocks, so a slow flash write no longer stops the socket draining (which closes the TCP
  window and throttles the sender) and a busy socket no longer stops the file being read.
- **Far fewer UI updates.** Progress used to be published every 96 KB - several hundred times a
  second at WiFi speed, each rebuilding the list, the screen and the notification - which costs
  real CPU on a mid-range phone. It is now about four times a second.
- **CPU and WiFi kept awake while bytes move** (`TransferPowerLocks`, new `WAKE_LOCK`
  permission), and the screen stays on during a transfer, so a long transfer isn't throttled when
  the screen turns off.

### Not changed
- The protocol version. A rejection now carries an optional reason after the offer id; peers that
  don't send or understand it still interoperate (an older sender just sees a plain decline, or in
  one mixed-version case waits out the 2-minute offer timeout).

## [1.0.7] - 2026-10-29

### Added
- **Images tab, between Files and Apps** - small square previews of the pictures on the
  phone, newest first. Tap as many as you like (a ring, tint and tick mark the picked
  ones, and the tab shows a count), then send them with the same "Next" bar as files and
  apps. Pictures go out in the order they were tapped. The grid keeps its scroll position
  while you look at the other tabs.
  - Access is asked for the first time the tab is opened: `READ_MEDIA_IMAGES` on Android
    13+, `READ_EXTERNAL_STORAGE` before that. On Android 14+ "share only some pictures"
    works too (`READ_MEDIA_VISUAL_USER_SELECTED`): the tab shows what was shared and a
    "Choose more" button. After two refusals the prompt offers the app settings page.
  - Previews come from the system's own thumbnails (`ContentResolver.loadThumbnail`, or a
    down-sampled decode on Android 9 and older) with a small memory cache, at most four
    loading at once and none for tiles that scrolled away before their turn. No image
    library was added, so the APK size is unchanged by this feature.

### Changed
- **Text and buttons no longer follow the device font size.** The theme pins the font
  scale to 1, so a large (or small) system font setting can't enlarge text, stretch
  buttons or push the three tabs out of the row. The activity also handles the font-size
  change itself instead of restarting. Screen density still applies as before. This also
  means the accessibility font-size setting has no effect inside BeamShare.

### APK size (no change needed)
- Already in place and untouched: R8 minification with full mode, resource shrinking,
  English-only resources, `material-icons-extended` removed, one universal APK (no ABI
  split). The biggest remaining item is the bundled ML Kit barcode model; see
  KNOWN_LIMITATIONS.md.

## [1.0.6] - 2026-10-25

A "make it actually work, and make it look better" pass. Nothing here was
reported as a specific bug; it comes from reading the whole pairing and transfer
path end to end. See BUGS_FIXED.md for the reasoning and confidence on each fix.

### Fixed
- **"Send an app" listed almost nothing** - the launcher query used
  `MATCH_DEFAULT_ONLY`, which drops every launcher activity that doesn't also
  declare `CATEGORY_DEFAULT` (nearly all of them).
- **First connection attempt could fail on timing alone** - the dialling end tried
  once, with no retry, while the other end might not be listening yet; the
  listening end's `accept()` had no timeout and couldn't be cancelled, leaving the
  port bound after a failed attempt. New `GroupSocket` retries and cancels cleanly.
- **QR pairing relied on an address Android hides** - the code carried the
  receiver's own P2P MAC (replaced by a placeholder on newer Android), and
  `connect()` only works for peers discovery has already seen. The code now carries
  the device name; the scanner waits for discovery to see that device, then connects
  using the address *it* discovered.
- **Discovery silently needs Location on Android 12 and older** - the app now checks
  Location and WiFi before starting and says exactly what to switch on.
- **The sender looked "connected" before the receiver accepted, and the receiver
  accepted files before its user did** - explicit approval step in the protocol
  (v2); offers are refused until the receiver's user accepts.
- **"Connecting..." could spin forever** - added a timeout, a Cancel button, and
  detection of a declined invitation.
- **A cut-off transfer could be reported as completed**, an unknown-size file could
  desynchronise the stream, and partial files were left behind - transfers are now
  exact-length, failures are marked per file, and partial files are removed.
- **Discovery stopped on its own after about two minutes** - it is re-armed while a
  screen still wants it, without disturbing a connection that is forming.
- Going Back from a live session left it running with no way to reach it - Back now
  asks whether to disconnect.
- QR scanner: one non-BeamShare code ended scanning for good; camera-denied text was
  white on a light background; scanner and camera executor were never released.

### Changed
- **UI redesign** (all screens): new colour system and gradient accents, a radar
  animation while searching, a connection tracker (reach / link / approval), file-type
  badges, live speed and time-remaining, a session summary header, a rounded scanner
  overlay with a torch button, light/dark-aware window background, and a proper
  monochrome notification icon. App icon has a gradient background and stays inside
  the adaptive-icon safe zone.
- `SessionManager` now runs on the main dispatcher (no cross-thread state) and owns
  sending (`sendItems`), so transfers survive navigating between screens.
- `WifiDirectManager` serialises every P2P command through one FIFO queue with a
  watchdog, and retries BUSY after clearing a half-finished connect.
- Notification shows the connected device and live transfer progress.

### Added
- File picker handles providers that don't report a size; app icons are drawn at
  list size (much lower memory on large app lists); split-APK apps are flagged.
- Protocol version in the greeting: a phone on an older BeamShare gets a clear
  message instead of hanging.

## [1.0.5] - 2026-08-23

### Fixed (see BUGS_FIXED.md for full detail)
- "WiFi Direct is busy" still appearing specifically after a QR scan -
  traced to `DiscoverDevicesScreen` re-arming general discovery at the
  same instant it was connecting to the scanned payload, racing two P2P
  commands against each other. `WifiDirectManager` also now serializes
  all its P2P commands as defense in depth.
- "BeamShare session active" notification outliving the app being closed
  - the foreground service had no `onTaskRemoved()` handling and no path
  to stop for a session that never got past its initial state.

### Changed (size optimization, no feature removed, no ABI split)
- Restricted packaged resource locales to English (`resourceConfigurations`
  in `defaultConfig`) - drops other-locale strings bundled by AndroidX/
  Compose/CameraX/ML Kit; this app has no translations of its own to lose.
- See KNOWN_LIMITATIONS.md for a further size lever (native-library ABI
  filtering within a single universal APK) surfaced but not applied this
  pass, and why.

## [1.0.4] - 2026-08-21

### Fixed (see BUGS_FIXED.md for full detail)
- QR scanner showing a black screen - CAMERA permission was never actually
  requested anywhere in the app.
- Receive screen never showing its own QR code - `thisDevice` only
  populated from a change broadcast that may never fire.
- "WiFi Direct is busy" - no guard against a redundant concurrent
  `discoverPeers()` call, and BUSY was treated as a hard failure instead
  of the expected transient response it usually is.

### Changed (size optimization, no feature removed, no ABI split)
- Replaced `material-icons-extended` with 13 hand-authored vector
  drawables - the only icons the app actually uses. That dependency ships
  on the order of ~2,000 icons; R8 tree-shaking a Compose icon library
  down to just what's referenced has historically been inconsistent, so
  removing it outright is the reliable way to actually capture the win.
- Explicit R8 full mode in `gradle.properties` (matches AGP 8.x's default,
  stated explicitly rather than left implicit).
- See KNOWN_LIMITATIONS.md for a size lever that was deliberately *not*
  taken this pass, and why.

## [1.0.3] - 2026-08-20

### Fixed
- `QrScannerScreen.kt`: `it.surfaceProvider = previewView.surfaceProvider` didn't compile
  (`Unresolved reference`) - CameraX's `Preview` only exposes `setSurfaceProvider(...)` as a
  method, with no matching getter, so Kotlin won't synthesize an assignable property for it.
  Changed to an explicit `it.setSurfaceProvider(...)` call.
- Four screens (`ReceiveScreen`, `DiscoverDevicesScreen`, `SelectContentScreen`,
  `ConnectedSessionScreen`) failed to compile on `TopAppBar(...)` - it's still gated behind
  `@ExperimentalMaterial3Api` in this Compose Material3 version. Opted in at the module level
  in `app/build.gradle.kts` instead of annotating each call site, since it's the standard way
  to build an app bar in M3 and more screens will use it going forward.
- Both were confirmed against **build #1589**'s actual `compileReleaseKotlin` error output
  (`e: ... Unresolved reference 'surfaceProvider'` / `e: ... This material API is
  experimental`), not guessed at.

## [1.0.2] - 2026-08-20

### Fixed
- `gradlew`'s `CLASSPATH` line had a stray backslash escaping `\$APP_HOME`, so the
  variable never expanded - Java received the literal text `$APP_HOME/gradle/...` as
  the classpath instead of a real path, and couldn't find `GradleWrapperMain` even
  though `gradle-wrapper.jar` had downloaded correctly. This is what broke **build
  #1586** (`Could not find or load main class org.gradle.wrapper.GradleWrapperMain`).
  Verified this time by actually expanding the variable, not just a syntax check.

## [1.0.1] - 2026-08-20

### Fixed
- `gradlew` / `gradlew.bat` were missing entirely. The CI pipeline's "Fetch
  gradle-wrapper.jar" step only downloads the binary jar and assumes the wrapper
  *script* already ships with the project. This is what broke **build #1585**
  (`chmod: cannot access 'gradlew': No such file or directory`).

## [1.0.0] - 2026-08-19

### Added
- Initial BeamShare implementation:
  - WiFi Direct peer discovery and QR-code direct connect (encodes the receiver's MAC
    so the sender can connect without waiting on a scan)
  - Symmetric post-pairing session - either phone can send files/apps afterward with
    no re-pairing
  - File and installed-app transfer: streamed I/O, throttled progress, base-APK
    extraction for "send an app"
  - Material 3 UI, vector iconography only, custom-styled QR scanner (CameraX + ML
    Kit) instead of a bolted-on scanning library UI
  - Foreground service to keep an active session alive if the app is backgrounded
