# Changelog

All notable changes to BeamShare are tracked here. Version numbers match
`versionCode` / `versionName` in `app/build.gradle.kts`.

## [1.0.3] - 2026-08-20

### Fixed
- `QrScannerScreen.kt`: `it.surfaceProvider = previewView.surfaceProvider` didn't compile
  (`Unresolved reference`) - CameraX's `Preview` only exposes `setSurfaceProvider(...)` as a
  method, with no matching getter, so Kotlin won't synthesize an assignable property for it.
  Changed to an explicit `it.setSurfaceProvider(...)` call.
- Four screens (`ReceiveScreen`, `DiscoverDevicesScreen`, `SelectContentScreen`,
  `ConnectedSessionScreen`) failed to compile on `TopAppBar(...)` - it's still gated behind
  `@ExperimentalMaterial3Api` in this Compose Material3 version. Opted in at the module level
  in `app/build.gradle.kts` instead of annotating each call site, since it's the standard way
  to build an app bar in M3 and more screens will use it going forward.
- Both were confirmed against **build #1589**'s actual `compileReleaseKotlin` error output
  (`e: ... Unresolved reference 'surfaceProvider'` / `e: ... This material API is
  experimental`), not guessed at.

## [1.0.2] - 2026-08-20

### Fixed
- `gradlew`'s `CLASSPATH` line had a stray backslash escaping `\$APP_HOME`, so the
  variable never expanded - Java received the literal text `$APP_HOME/gradle/...` as
  the classpath instead of a real path, and couldn't find `GradleWrapperMain` even
  though `gradle-wrapper.jar` had downloaded correctly. This is what broke **build
  #1586** (`Could not find or load main class org.gradle.wrapper.GradleWrapperMain`).
  Verified this time by actually expanding the variable, not just a syntax check.

## [1.0.1] - 2026-08-20

### Fixed
- `gradlew` / `gradlew.bat` were missing entirely. The CI pipeline's "Fetch
  gradle-wrapper.jar" step only downloads the binary jar and assumes the wrapper
  *script* already ships with the project. This is what broke **build #1585**
  (`chmod: cannot access 'gradlew': No such file or directory`).

## [1.0.0] - 2026-08-19

### Added
- Initial BeamShare implementation:
  - WiFi Direct peer discovery and QR-code direct connect (encodes the receiver's MAC
    so the sender can connect without waiting on a scan)
  - Symmetric post-pairing session - either phone can send files/apps afterward with
    no re-pairing
  - File and installed-app transfer: streamed I/O, throttled progress, base-APK
    extraction for "send an app"
  - Material 3 UI, vector iconography only, custom-styled QR scanner (CameraX + ML
    Kit) instead of a bolted-on scanning library UI
  - Foreground service to keep an active session alive if the app is backgrounded
