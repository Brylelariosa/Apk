#!/usr/bin/env bash
# Builds the zipsync engine for Android and copies it to  <out-dir>/<abi>/libzipsync.so
#
#   usage: build-android.sh <out-dir>
#
# Called by Gradle (task :app:buildRustEngine) before every build; the crate is the folder this
# script sits in (app/src/main/rust/zipsync), wherever the project is. It NEVER fails the build:
# when Rust is missing, the NDK can't be found, or the code doesn't compile, it says so loudly
# and exits 0 - the app is then built without the engine, and "Sync changes into repo" tells you
# so instead of the whole APK being lost.
#
#   ZAB_RUST_ABIS   ABIs to build, space separated (default: "arm64-v8a armeabi-v7a")
#   ANDROID_NDK_HOME / ANDROID_NDK_ROOT / ANDROID_SDK_ROOT   where to find the NDK

set -u

OUT="${1:-}"
if [ -z "$OUT" ]; then
  echo "[zipsync] usage: build-android.sh <out-dir>"
  exit 0
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
ABIS="${ZAB_RUST_ABIS:-arm64-v8a armeabi-v7a}"
API=24   # the app's minSdk

mkdir -p "$OUT"

# A Gradle daemon sometimes starts with a trimmed PATH that lacks rustup's folder; add it.
CARGO_BIN="${CARGO_HOME:-${HOME:-}/.cargo}/bin"
if [ -d "$CARGO_BIN" ]; then
  case ":$PATH:" in
    *":$CARGO_BIN:"*) ;;
    *) export PATH="$CARGO_BIN:$PATH" ;;
  esac
fi

warn() {
  echo "[zipsync] WARNING: $*"
  echo "::warning::zipsync engine: $*"
}

if ! command -v cargo >/dev/null 2>&1 || ! command -v rustup >/dev/null 2>&1; then
  warn "cargo/rustup not found - building the app WITHOUT the Rust sync engine"
  exit 0
fi

find_ndk() {
  local v
  for v in "${ANDROID_NDK_HOME:-}" "${ANDROID_NDK_ROOT:-}" "${ANDROID_NDK:-}"; do
    if [ -n "$v" ] && [ -d "$v/toolchains/llvm/prebuilt" ]; then
      echo "$v"
      return 0
    fi
  done
  local sdk best
  for sdk in "${ANDROID_SDK_ROOT:-}" "${ANDROID_HOME:-}"; do
    if [ -n "$sdk" ] && [ -d "$sdk/ndk" ]; then
      best="$(ls -1 "$sdk/ndk" 2>/dev/null | sort -V | tail -n 1)"
      if [ -n "$best" ] && [ -d "$sdk/ndk/$best/toolchains/llvm/prebuilt" ]; then
        echo "$sdk/ndk/$best"
        return 0
      fi
    fi
  done
  return 1
}

NDK="$(find_ndk)"
if [ -z "$NDK" ]; then
  warn "Android NDK not found (set ANDROID_NDK_HOME) - building the app WITHOUT the Rust sync engine"
  exit 0
fi

HOST_TAG="$(ls -1 "$NDK/toolchains/llvm/prebuilt" 2>/dev/null | head -n 1)"
TOOLBIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin"
if [ -z "$HOST_TAG" ] || [ ! -d "$TOOLBIN" ]; then
  warn "NDK toolchain not found under $NDK - building the app WITHOUT the Rust sync engine"
  exit 0
fi

echo "[zipsync] NDK: $NDK"
built=0

for ABI in $ABIS; do
  case "$ABI" in
    arm64-v8a)
      TRIPLE="aarch64-linux-android"
      CLANG="aarch64-linux-android${API}-clang"
      ;;
    armeabi-v7a)
      TRIPLE="armv7-linux-androideabi"
      CLANG="armv7a-linux-androideabi${API}-clang"
      ;;
    *)
      warn "unknown ABI '$ABI' - skipped"
      continue
      ;;
  esac

  if [ ! -x "$TOOLBIN/$CLANG" ]; then
    warn "$CLANG not found in the NDK - skipped $ABI"
    continue
  fi

  ENVSUF="${TRIPLE//-/_}"
  UPPER="$(echo "$ENVSUF" | tr 'a-z' 'A-Z')"

  echo "[zipsync] ---- $ABI ($TRIPLE) ----"
  if ! rustup target add "$TRIPLE"; then
    warn "could not add the Rust target $TRIPLE - skipped $ABI"
    continue
  fi

  export "CC_${ENVSUF}=$TOOLBIN/$CLANG"
  export "AR_${ENVSUF}=$TOOLBIN/llvm-ar"
  export "CARGO_TARGET_${UPPER}_LINKER=$TOOLBIN/$CLANG"

  if ( cd "$HERE" && cargo build --release --target "$TRIPLE" ); then
    if [ -f "$HERE/target/$TRIPLE/release/zipsync" ]; then
      mkdir -p "$OUT/$ABI"
      cp "$HERE/target/$TRIPLE/release/zipsync" "$OUT/$ABI/libzipsync.so"
      echo "[zipsync] built $OUT/$ABI/libzipsync.so"
      built=$((built + 1))
    else
      warn "cargo reported success but target/$TRIPLE/release/zipsync is missing - skipped $ABI"
    fi
  else
    warn "cargo build FAILED for $ABI - see the error above. The app is built without the engine for this CPU."
  fi
done

if [ "$built" -eq 0 ]; then
  warn "no engine was built - the APK will not contain the Rust sync engine"
else
  echo "[zipsync] engine ready for $built ABI(s)"
fi
exit 0
