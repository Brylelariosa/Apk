# zipsync — the Rust sync engine

`app/src/main/rust/zipsync/` is a small Rust program that makes a GitHub repo match a ZIP **by
sending only what differs**. The app uses it for *Upload to › Sync changes into repo*; it also runs on its own.

## What it does (in order)
1. Lists the ZIP's files and cleans their paths (`..`, drive letters, `__MACOSX/`, `.DS_Store`,
   `.git/`, symlinks are dropped).
2. Reads the branch from GitHub: its commit, and the whole file tree in one request.
3. Decides whether a folder wrapping the whole ZIP (`repo-main/…`) must be cut off. It counts how
   many files line up with the repo with and without the cut and takes the better one; on a tie a
   Gradle project directly inside the wrapper (`settings.gradle`) counts as the repo root.
4. Reads every file once and computes its Git blob id (`sha1("blob <size>\0" + bytes)`), so
   "same content" is decided exactly like Git decides it.
5. Compares: same path + same id → untouched; same path + other id → **replaced**; new path →
   **added**. A mode-only difference (executable bit) is also a change. A file only the repo has is
   never touched.
6. Uploads what changed: text files up to 256 KB ride inside the tree request (4 MB in total),
   everything else is uploaded as its own blob, 4 at a time. Every request retries on network
   errors, 5xx and rate limits with a growing pause.
7. Creates **one** tree on top of the current tree, **one** commit, and moves the branch (never
   forced). If the branch moved meanwhile it re-reads and tries again, up to 3 times.
   If the new tree equals the old one, no commit is made.

`.github/workflows/*` in the ZIP is skipped unless `--include-workflows` is given.

## Using it from a terminal (Termux, a PC, CI)
```
export ZIPSYNC_TOKEN=ghp_xxx          # needs the 'repo' scope
zipsync sync --zip update.zip --repo me/my-app --branch main --dry-run
zipsync sync --zip update.zip --repo me/my-app --branch main
```
Options: `--message TEXT`, `--prefix DIR` (the ZIP's root maps to this folder), `--strip
auto|none|DIR`, `--jobs 1-8`, `--include-workflows`, `--dry-run`, `--json`.

## How the app talks to it
The engine is shipped as `libzipsync.so` (an executable; Gradle `useLegacyPackaging` makes Android
extract it) and started as a child process with `--json`. The token is passed in the environment
variable `ZIPSYNC_TOKEN`. It prints one JSON object per line:
```
{"t":"log","m":"…"}
{"t":"progress","phase":"read"|"upload","done":12,"total":240}
{"t":"result","ok":true,"commit":"<sha>"|null,"added":3,"modified":4,"unchanged":233,
 "skipped":0,"uploaded_bytes":18234,"strip":"repo-main/","dry_run":false,"changed":["…"]}
{"t":"result","ok":false,"error":"…"}
```
Cancelling = killing the process; blobs uploaded so far are harmless leftovers on GitHub.

## Build
`app/src/main/rust/zipsync/build-android.sh <out-dir>` (called by Gradle's `buildRustEngine`) installs the Rust targets,
points Cargo at the NDK's clang and builds `--release` for arm64-v8a and armeabi-v7a
(`ZAB_RUST_ABIS="arm64-v8a"` builds only the first). It always exits 0; problems are printed as
`zipsync engine: …` with a `::warning::` annotation. Needs `cargo`/`rustup` (preinstalled on
GitHub's Ubuntu runners) and the NDK that the workflow already installs.

Dependencies: `zip` (deflate only), `ureq` (HTTPS with rustls and built-in root certificates),
`serde_json`, `sha1`, `base64`.

## Where it lives, and why
The crate sits inside the app module (`app/src/main/rust/zipsync/`), deeper than the CI workflow
looks. That is on purpose. A workflow with Rust support (the "Detect Rust project" step) searches
two levels down from the project root for a `Cargo.toml` and builds what it finds with `cargo ndk`
as a **JNI library** (`crate-type = ["cdylib"]`, copied into `jniLibs`). zipsync is the opposite: an
executable that Gradle's `buildRustEngine` builds itself. When it sat in `rust/`, the workflow
picked it up, cargo compiled it, and cargo-ndk then stopped with *No usable artifacts produced by
cargo* (run 1962, v62).

Rule of thumb: Rust that **Gradle** builds itself goes deeper than two levels (like here); Rust
meant for the workflow's cargo-ndk step goes in `rust/` at the project root. `app/build.gradle`
names the folder once (`rustEngineDir`); the build script finds the crate from its own location.

## Layout (relative to `app/src/main/rust/zipsync/`)
| File | Job |
|---|---|
| `src/main.rs` | command line |
| `src/sync.rs` | the algorithm above |
| `src/github.rs` | GitHub REST calls, retries, rate limits |
| `src/zipscan.rs` | reading the ZIP, path cleaning |
| `src/out.rs` | JSON lines / plain text output |
| `build-android.sh` | cross-compiling for Android, never fails the build |

## Not done yet / ideas
- Deleting files that disappeared from a new ZIP (a `--prune` that is off by default).
- Resumable upload of one very large single file (today such a file is one request of its own).
- A "preview changes" screen using `--dry-run`.
