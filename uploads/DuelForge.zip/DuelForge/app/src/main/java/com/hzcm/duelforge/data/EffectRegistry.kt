package com.hzcm.duelforge.data

import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/**
 * Maps a card's [Card.id] to the [CardEffect]s it has. cards.json stays pure data
 * (name/stats/image); all gameplay logic lives here. To give a card an effect:
 *  1. Set its `monsterCategory` to "EFFECT" (or leave Spells/Traps as-is) in cards.json.
 *  2. Add an entry below keyed by the card's id, with one [CardEffect] per ability.
 *
 * [CardEffect.id] (distinct from the card's id) is only used for once-per-turn tracking
 * via [CardInstance.effectUsedThisTurn] - it just needs to be unique per ability.
 */
object EffectRegistry {

    private val registry: Map<String, List<CardEffect>> = mapOf(

        // --- Ironclad Defender: FLIP - gain 1000 LP -------------------------------------
        "ironclad_defender" to listOf(
            CardEffect(
                id = "ironclad_defender_flip",
                timing = EffectTiming.FLIP,
                description = "Gain 1000 Life Points.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    val field = engine.state.field(source.controller)
                    field.lifePoints += 1000
                    engine.state.addLog("${engine.displayName(source.controller)} gains 1000 Life Points. (LP: ${field.lifePoints})")
                }
            )
        ),

        // --- Stormcaller Falcon: Trigger - draw 1 on Normal Summon ----------------------
        "stormcaller_falcon" to listOf(
            CardEffect(
                id = "stormcaller_falcon_trigger",
                timing = EffectTiming.TRIGGER,
                description = "Draw 1 card.",
                canActivate = { engine, source ->
                    val event = engine.state.lastEvent
                    event is GameEvent.NormalSummon && event.card === source
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 1)
                    engine.state.addLog("${engine.displayName(source.controller)} draws a card.")
                }
            )
        ),

        // --- Crimson War Wyrm: Ignition - halve an opponent monster's ATK until EOT -----
        "crimson_war_wyrm" to listOf(
            CardEffect(
                id = "crimson_war_wyrm_ignition",
                timing = EffectTiming.IGNITION,
                description = "Target 1 monster your opponent controls; halve its ATK until the end of this turn.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller.opponent()).monsters().isNotEmpty()
                },
                targetSelector = { engine, source -> engine.state.field(source.controller.opponent()).monsters() },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        val halved = engine.computeAtk(target) / 2
                        target.atkModifier -= halved
                        engine.state.addLog("${target.card.name}'s ATK is halved until the end of this turn!")
                    }
                }
            )
        ),

        // --- Tactical Reinforcement: Normal Spell - draw 2, discard 1 -------------------
        "tactical_reinforcement" to listOf(
            CardEffect(
                id = "tactical_reinforcement_effect",
                timing = EffectTiming.NORMAL,
                description = "Draw 2 cards, then discard 1 card.",
                canActivate = { engine, source -> engine.state.field(source.controller).deck.size >= 2 },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    engine.drawCards(controller, 2)
                    val hand = engine.state.field(controller).hand
                    if (hand.isNotEmpty()) {
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(controller)} discards ${discard.card.name}.")
                    }
                }
            )
        ),

        // --- Fusion Catalyst: Normal Spell - Fusion Summon from the Extra Deck ----------
        "fusion_catalyst" to listOf(
            CardEffect(
                id = "fusion_catalyst_effect",
                timing = EffectTiming.NORMAL,
                description = "Fusion Summon 1 Fusion Monster from your Extra Deck using monsters you control as material.",
                canActivate = { engine, source -> engine.canFusionSummon(source.controller) },
                resolve = { engine, source, _ -> engine.performFusionSummon(source.controller) }
            )
        ),

        // --- Battlefield Overgrowth: Field Spell - all EARTH monsters +200 ATK ----------
        // The static buff itself is applied in GameEngine.computeAtk(); this entry just
        // represents "activating" the Field Spell card from hand.
        "battlefield_overgrowth" to listOf(
            CardEffect(
                id = "battlefield_overgrowth_effect",
                timing = EffectTiming.NORMAL,
                description = "All EARTH monsters on the field gain 200 ATK.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${engine.displayName(source.controller)}'s Field Spell empowers all EARTH monsters!")
                }
            )
        ),

        // --- Rapid Strike: Quick-Play Spell - grant a monster a second attack -----------
        "rapid_strike" to listOf(
            CardEffect(
                id = "rapid_strike_effect",
                timing = EffectTiming.QUICK,
                description = "Target 1 of your face-up Attack Position monsters that has already attacked this turn; it can attack again this Battle Phase.",
                canActivate = { engine, source -> engine.state.phase == Phase.BATTLE && rapidStrikeTargets(engine, source).isNotEmpty() },
                targetSelector = { engine, source -> rapidStrikeTargets(engine, source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.extraAttacksAllowed += 1
                        engine.state.addLog("${target.card.name} can attack again this Battle Phase!")
                    }
                }
            )
        ),

        // --- Shield Wall: Continuous Trap - once per turn, force the attacked monster to Defense ---
        "shield_wall" to listOf(
            CardEffect(
                id = "shield_wall_activate",
                timing = EffectTiming.QUICK,
                description = "Activate this card.",
                canActivate = { _, source -> !source.faceUp },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${source.card.name} is activated and remains face-up on the field.")
                }
            ),
            CardEffect(
                id = "shield_wall_effect",
                timing = EffectTiming.QUICK,
                description = "Change the attacked monster to Defense Position.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.faceUp && shieldWallTarget(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(shieldWallTarget(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.battlePosition = BattlePosition.DEFENSE
                        engine.state.addLog("${target.card.name} is switched to Defense Position!")
                    }
                }
            )
        ),

        // --- Reversal Ambush: Normal Trap - destroy the attacking monster ---------------
        "reversal_ambush" to listOf(
            CardEffect(
                id = "reversal_ambush_effect",
                timing = EffectTiming.QUICK,
                description = "Destroy the attacking monster.",
                canActivate = { engine, source ->
                    !source.faceUp && attackingMonster(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(attackingMonster(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target -> engine.destroyCard(target) }
                }
            )
        ),

        // --- Negation Barrier: Counter Trap - negate and destroy a Spell/Monster Effect activation ---
        "negation_barrier" to listOf(
            CardEffect(
                id = "negation_barrier_effect",
                timing = EffectTiming.QUICK,
                description = "Negate the activation of a Spell Card or Monster Effect, then destroy it.",
                canActivate = { engine, source ->
                    !source.faceUp && engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType != CardType.TRAP
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // --- Sentinel of the Sealed Gate: Quick Effect - discard to negate+destroy a Trap ---
        "sentinel_of_the_sealed_gate" to listOf(
            CardEffect(
                id = "sentinel_quick",
                timing = EffectTiming.QUICK,
                description = "Discard 1 card to negate the activation of a Trap Card, then destroy it.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType == CardType.TRAP &&
                        engine.state.field(source.controller).hand.isNotEmpty()
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                payCost = { engine, source ->
                    val hand = engine.state.field(source.controller).hand
                    if (hand.isEmpty()) {
                        false
                    } else {
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(source.controller)} discards ${discard.card.name}.")
                        true
                    }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // --- Spark Imp: Ignition - tribute self to inflict 500 damage ------------------
        "spark_imp" to listOf(
            CardEffect(
                id = "spark_imp_ignition",
                timing = EffectTiming.IGNITION,
                description = "Tribute this card to inflict 500 damage to your opponent.",
                canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
                payCost = { engine, source ->
                    engine.sendToGraveyard(source)
                    true
                },
                resolve = { engine, source, _ ->
                    val opponent = source.controller.opponent()
                    val field = engine.state.field(opponent)
                    field.lifePoints -= 500
                    engine.state.addLog("${engine.displayName(opponent)} takes 500 damage! (LP: ${field.lifePoints})")
                    engine.checkWinConditions()
                }
            )
        ),

        // --- Glacier Hound: Trigger - draw 1 if destroyed by battle ---------------------
        "glacier_hound" to listOf(
            CardEffect(
                id = "glacier_hound_trigger",
                timing = EffectTiming.TRIGGER,
                description = "Draw 1 card.",
                canActivate = { engine, _ -> engine.lastDestructionWasBattle },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 1)
                    engine.state.addLog("${engine.displayName(source.controller)} draws a card.")
                }
            )
        )
    )

    fun effectsFor(cardId: String): List<CardEffect> = registry[cardId] ?: emptyList()

    // ------------------------------------------------------------------
    // Shared target-finding helpers
    // ------------------------------------------------------------------

    /** For Rapid Strike: your face-up Attack Position monsters that attacked but have no extra attack pending. */
    private fun rapidStrikeTargets(engine: GameEngine, source: CardInstance): List<CardInstance> =
        engine.state.field(source.controller).monsters().filter {
            it.faceUp && it.battlePosition == BattlePosition.ATTACK &&
                it.hasAttackedThisTurn && it.extraAttacksAllowed <= 0
        }

    /** For Shield Wall: the monster of [source]'s controller currently being attacked, if any. */
    private fun shieldWallTarget(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        val target = event.target ?: return null
        if (target.controller != source.controller) return null
        if (target.battlePosition != BattlePosition.ATTACK) return null
        if (event.attacker.controller == source.controller) return null
        return target
    }

    /** For Reversal Ambush: the opponent's monster that just declared an attack, if any. */
    private fun attackingMonster(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        if (event.attacker.controller == source.controller) return null
        return event.attacker
    }
}
