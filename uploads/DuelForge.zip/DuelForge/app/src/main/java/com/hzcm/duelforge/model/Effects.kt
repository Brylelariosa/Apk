package com.hzcm.duelforge.model

import com.hzcm.duelforge.engine.GameEngine

/**
 * Effects are plain Kotlin lambdas registered per-card in EffectRegistry.kt. This keeps
 * cards.json pure data (name/stats/image) while gameplay logic lives in code.
 *
 * - [canActivate]: is this effect legal to activate / does its Trigger condition currently hold?
 * - [targetSelector]: if the effect needs a target, return the list of legal targets
 *   (engine will ask the controller to choose one when there's more than one option).
 * - [payCost]: pay any cost (discard, tribute self, etc). Return false to abort activation.
 * - [resolve]: the actual effect. Runs when the chain link resolves.
 */
typealias EffectCondition = (engine: GameEngine, source: CardInstance) -> Boolean
typealias EffectCost = (engine: GameEngine, source: CardInstance) -> Boolean
typealias TargetSelector = (engine: GameEngine, source: CardInstance) -> List<CardInstance>
typealias EffectResolve = (engine: GameEngine, source: CardInstance, targets: List<CardInstance>) -> Unit

data class CardEffect(
    val id: String,
    val timing: EffectTiming,
    val description: String,
    /** Most Ignition/Quick effects are hard-once-per-turn per card. */
    val oncePerTurn: Boolean = false,
    val canActivate: EffectCondition,
    val targetSelector: TargetSelector? = null,
    val payCost: EffectCost? = null,
    val resolve: EffectResolve
)
