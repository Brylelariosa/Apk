# DuelForge - Development Log

A Yu-Gi-Oh-style TCG engine for Android (Kotlin + Jetpack Compose), built for the
GitHub Actions APK pipeline workflow. vs AI opponent, full rules including chains
and priority (with documented v1 simplifications).

---

## Session 1 - Initial build

### Project setup
- `settings.gradle.kts`, root `build.gradle.kts` (AGP 8.2.2, Kotlin 1.9.22)
- `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.6, matches CI)
- `gradlew` (Unix wrapper script, made executable, fixed a CLASSPATH typo)
- `app/build.gradle.kts` - compileSdk/targetSdk 34, minSdk 24, Compose enabled,
  compose-bom 2024.02.01, compose compiler ext 1.5.8, JVM target 17
- `AndroidManifest.xml` - uses `@android:drawable/sym_def_app_icon` (no custom icon
  needed), MainActivity locked to landscape
- `strings.xml`, `themes.xml` - basic dark theme

### Model layer (`model/`)
- `Enums.kt` - PlayerId (+ `.opponent()`), CardType, MonsterCategory, SpellType,
  TrapType, Attribute, Race, Phase, Location, BattlePosition, EffectTiming
  (NORMAL/IGNITION/TRIGGER/QUICK/CONTINUOUS/FLIP), sealed `FusionMaterial`
  (Specific/AnyOfRace/AnyMonster)
- `Card.kt` - static card definition (immutable), `tributesRequired` computed from level
  (1-4: 0, 5-6: 1, 7+: 2)
- `CardInstance.kt` - mutable per-duel copy of a card: location, zone index, battle
  position, face-up state, per-turn flags, stat modifiers, `isNegated` flag (for Counter
  Traps), `effectiveAtk`/`effectiveDef`
- `GameState.kt` - `PlayerField` (zones, hand/deck/GY/banished/extra deck, LP, normal
  summon tracking), `ChainLink`, sealed `GameEvent` (what just happened, drives
  Trigger/Quick conditions), `GameState`, `PriorityPrompt`
- `Effects.kt` - `CardEffect` data class + typealiases for condition/cost/target/resolve
  lambdas

### Engine layer (`engine/`)
- **GameEngine.kt** - core class: owns `GameState` + `CardDatabase`, zone management
  (draw/destroy/banish/GY/extra-deck moves), turn/phase state machine (`advancePhase`),
  win condition checks, and `computeAtk`/`computeDef` (stat queries that fold in
  continuous field-wide effects).
- **ChainManager.kt** - the heart of "full rules": `openPriorityWindow` (checks the
  acting player's own Trigger effects first, then the responder's Quick/Trap/Trigger
  options - recursing if they chain something), `submitPriorityChoice` (UI resume
  point for human responses), `pushChainLink` (pays costs, moves/flips cards, handles
  Field Spell placement), `resolveChain` (LIFO resolution, respects `isNegated`),
  `getActivatableEffects`, `resolveTargets`, plus `canActivateEffect`/`activateEffect`
  (the player-initiated entry point for Normal Spells / Ignition / proactive Quick).
- **SummonManager.kt** - Normal Summon / Set (with tribute validation), Flip Summon +
  `triggerFlipEffects`, battle position changes, generic `specialSummon`, and the
  Fusion Summon pathway (`findFusionCombo` greedily matches `FusionMaterial`
  requirements, `performFusionSummon` sends materials to GY and special-summons the
  Fusion Monster).
- **BattleManager.kt** - `canDeclareAttack`/`declareAttack` (CPS, opens a priority
  window before damage), `resolveBattleDamage` implementing ATK-vs-ATK, ATK-vs-DEF, and
  direct attack rules, including flipping face-down defenders (and firing their FLIP
  effects) before computing damage.
- **AIController.kt** - `aiRunTurn` drives the AI's entire turn via nested CPS
  callbacks (so a human priority prompt mid-AI-turn pauses cleanly); `aiMainPhaseStep`
  picks summons (greedy ATK-vs-tribute-cost heuristic) and activations; `aiBattleStep`
  attacks only into "safe" trades; `aiChooseResponse`/`aiChooseTargets` for chain
  decisions.

### Data layer (`data/`)
- **cards.json** - 17 main-deck cards + 2 Extra Deck Fusion Monsters, all original
  names/stats. Deck = ~33 cards via per-card `count`. Fusion materials encoded as
  strings (`SPECIFIC:id`, `RACE:NAME:count`, `ANY:count`).
- **CardDatabase.kt** - loads/parses cards.json, builds main + extra decks.
- **EffectRegistry.kt** - implements all 10 effect cards (see card list below).

### Key architecture decisions
- Long sequences (AI turns, chain resolution, battles) use continuation-passing style
  (`onDone: () -> Unit`) so a human priority prompt can pause mid-sequence and resume via
  `submitPriorityChoice()`.
- `advancePhase()` only triggers `aiRunTurn()` from its `Phase.END -> endTurn()` branch
  (the one place control can switch to the AI) - this avoids infinite recursion since
  `aiRunTurn` itself calls `advancePhase()` repeatedly for the AI's own phases.
- Continuous field-wide effects (Battlefield Overgrowth: all EARTH +200 ATK) are
  hand-coded in `GameEngine.computeAtk()` rather than via a generic registry - documented
  v1 simplification.
- "Destroyed by battle" Trigger effects (Glacier Hound) auto-resolve directly inside
  `destroyCard()` rather than joining the chain, since the card has already left the
  field by the time it would be considered.
- Avoided `return@CardEffect` inside lambda arguments to `CardEffect(...)` (ambiguous
  whether constructors get implicit labels without a compiler to verify) - used
  `.let { }` blocks instead throughout EffectRegistry.

### Card list (17 main deck + 2 Extra Deck)
| Card | Type | Stats | Effect |
|---|---|---|---|
| Squire of the Vale | Normal Monster | 800/500 LIGHT Warrior Lv2 | - |
| Wildclaw Tiger | Normal Monster | 1700/1000 EARTH Beast Lv4 | - |
| Ironclad Defender | Effect Monster | 1200/2000 EARTH Machine Lv4 | FLIP: gain 1000 LP |
| Stormcaller Falcon | Effect Monster | 1600/1200 WIND Winged Beast Lv4 | On Normal Summon: draw 1 |
| Crimson War Wyrm | Effect Monster | 2300/1700 FIRE Dragon Lv6 (1 tribute) | Ignition, once/turn: halve an opponent monster's ATK until EOT |
| Tidal Leviathan | Normal Monster | 2400/1000 WATER Aqua Lv6 (1 tribute) | - |
| Obsidian Golem Titan | Normal Monster | 2900/2800 EARTH Rock Lv8 (2 tributes) | - |
| Sentinel of the Sealed Gate | Effect Monster | 2500/2100 DARK Fiend Lv7 (2 tributes) | Quick, once/turn: discard 1 to negate+destroy a Trap activation |
| Spark Imp | Effect Monster | 300/200 FIRE Fiend Lv1 | (see "Not yet implemented" below) |
| Glacier Hound | Effect Monster | 1000/800 WATER Beast Lv3 | If destroyed by battle: draw 1 |
| Tactical Reinforcement | Normal Spell | - | Draw 2, discard 1 |
| Fusion Catalyst | Normal Spell | - | Fusion Summon from Extra Deck |
| Battlefield Overgrowth | Field Spell | - | All EARTH monsters +200 ATK |
| Rapid Strike | Quick-Play Spell | - | Target your monster that attacked: it can attack again |
| Shield Wall | Continuous Trap | - | Once/turn: switch the attacked monster to Defense |
| Reversal Ambush | Normal Trap | - | Destroy the attacking monster |
| Negation Barrier | Counter Trap | - | Negate + destroy a Spell/Monster Effect activation |
| Twin-Fang Chimera | Fusion Monster (Extra Deck) | 2600/2100 DARK Beast Lv6 | 2x BEAST material |
| Inferno Dragon Overlord | Fusion Monster (Extra Deck) | 3000/2500 FIRE Dragon Lv8 | Crimson War Wyrm + 1 monster |

### Known v1 simplifications (to document in final README)
- No Synchro/Xyz/Pendulum/Link (architecture supports adding via Extra Deck + special
  summon pathway later).
- Fusion Summon auto-picks the first valid material combination (no manual material
  selection UI).
- Trigger and FLIP effects auto-activate without an "activate?" prompt.
- Chain resolves fully top-to-bottom once both sides pass once (no re-opening priority
  after each individual link resolves).
- No hand-size limit at End Phase.
- AI doesn't use Quick-Play Spells during the Battle Phase (Rapid Strike is
  human-only in practice).
- Set monsters can't be Flip Summoned the same turn they're Set.

### Spark Imp - added
- `spark_imp_ignition`: payCost sends Spark Imp itself to the GY (self-tribute as cost,
  paid even if later negated by a Counter Trap - matches real rules), resolve deals 500
  damage to the opponent and checks win conditions.

### UI layer (`ui/`) - completed
- **ImageLoader.kt** - loads `assets/cards/<imageId>.{png,jpg,jpeg,webp}` with an
  in-memory cache; returns null (triggering the placeholder) if nothing found.
- **CardView.kt** - renders a card: empty-zone outline, card back (face-down, unless
  `revealFaceDown` for the human's own set cards), artwork + ATK/DEF/position overlay,
  or a generated placeholder (colored by card type/category) with name, attribute/race,
  Lv/ATK/DEF.
- **GameViewModel.kt** - wraps `GameEngine`, exposes `refresh` (bumped after every
  engine mutation to drive recomposition), `selectedCard`/`tributeSelection`/
  `attackerSelection` selection state, and action methods (`onHandCardTapped`,
  `onOwnMonsterTapped`, `onOwnSpellTrapTapped`, `onOpponentMonsterTapped`,
  `beginSummon`/`confirmTributeSummon`, `setTrap`, `activateEffect`, `flipSummon`,
  `changeBattlePosition`, `declareDirectAttack`, `advancePhase`, `submitPriorityChoice`,
  `restart`).
- **GameScreen.kt** - full landscape layout: opponent field (field zone, 5 monster
  zones, 5 spell/trap zones, LP/counts), turn/phase bar with Next Phase/End Turn
  button, scrollable battle log + context-sensitive action panel side by side, player
  field (mirrored, with own face-down cards revealed to the player), scrollable hand.
  Plus a priority-response `AlertDialog` and a game-over overlay with "New Duel".
- **MainActivity.kt** - hosts `GameScreen()` inside a `MaterialTheme`/`Surface`.

### Added during review
- **Set Spell/Trap action** (`SummonManager.canSetSpellOrTrap`/`setSpellOrTrap`) - this
  was missing entirely from the original plan; without it Trap cards could never reach
  the Spell/Trap Zone. Restricted to Trap cards only (Quick-Play Spells are activated
  directly from hand instead - a Set Quick-Play Spell would have no activation path
  given the priority-window design, so Setting one is disallowed to avoid a dead card).
- **Rapid Strike's `canActivate`** now requires `state.phase == Phase.BATTLE`, so the
  AI doesn't waste it responding outside the Battle Phase (the granted extra attack
  would just get reset away before ever being used).
- Traced through a "Negation Barrier negates a Trigger effect, which destroys the
  Trigger's source, which opens a nested priority window" scenario by hand (no compiler
  available) - confirmed `resolveChain()`'s recursive-via-nested-`destroyCard` pattern
  correctly drains `state.chain` and calls `onDone()` exactly once, GIVEN that no
  Quick/Trap effect in this card pool reacts to `GameEvent.Destroyed` for the human
  player (documented as a structural limitation: such a reaction would surface a
  priority prompt out of order relative to `resolveChain`'s loop).

### Known gaps not fixed this session (acceptable for v1)
- AI never Flip Summons its own face-down monsters (only the human can).
- AI may occasionally hold onto Rapid Strike longer than ideal but won't waste it
  outside Battle Phase anymore.

### Final file list
```
DuelForge/
  README.md, devlog.md
  settings.gradle.kts, build.gradle.kts, gradle.properties
  gradlew, gradle/wrapper/gradle-wrapper.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/res/values/{strings,themes}.xml
  app/src/main/assets/cards.json
  app/src/main/assets/cards/README.md
  app/src/main/java/com/hzcm/duelforge/
    MainActivity.kt
    model/{Enums,Card,CardInstance,GameState,Effects}.kt
    data/{CardDatabase,EffectRegistry}.kt
    engine/{GameEngine,ChainManager,SummonManager,BattleManager,AIController}.kt
    ui/{ImageLoader,CardView,GameViewModel,GameScreen}.kt
```

### Status: feature-complete for v1, ready to zip and push to the build pipeline.

