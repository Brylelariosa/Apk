# Storage Map 3D

An Android storage analyzer that shows internal storage as an interactive 3D treemap, next to a normal
file explorer and a set of analysis pages. Everything runs on the device: no network, no account, no root.

* Kotlin + Jetpack Compose for the app, OpenGL ES 3.0 for the map (no game engine)
* Rust (`rust/`) for the heavy work, reached through JNI: the directory scanner, SHA-256 hashing for the
  duplicate finder, the squarified treemap layout, directory listing and file categories
* SQLite (Android's built-in) for the scan index, duplicate results and storage history

## Screens

| Tab | What it does |
| --- | --- |
| Overview | Available and used space as a "core sample" bar split by file category, scan control with live progress, largest files and folders |
| 3D Map | Folders are containers (floor + walls) sized by what they hold, files and sub-folders are blocks inside them, tall = big. Orbit with one finger, pan with two, pinch to zoom, tap to select, open a folder to go one level deeper. Names and sizes are drawn above the blocks and thin out when zoomed away |
| Explorer | Live folder listing: navigate, search the scan index, sort by name / size / date, filter by type, open, share, delete with confirmation, properties (with an on-demand SHA-256) |
| Analysis | Largest files and folders, duplicate finder, storage distribution, old files, empty folders, storage history |
| Settings | Storage access, hidden files, 3D detail level, reduced motion, daily snapshot, clearing data |

Nothing is ever deleted without a confirmation dialog, and the duplicate finder refuses to delete every
copy of a file.

## Storage access (Android 11+)

* **All files access** (`MANAGE_EXTERNAL_STORAGE`) is the main mode: the Rust scanner reads real paths.
* **Limited mode** uses the Storage Access Framework folder picker. Scanning, browsing, hashing, opening,
  sharing and deleting all work through content URIs. It is slower because every folder is a provider query.
* `Android/data` and `Android/obb` cannot be read by any app on Android 11+. They are shown as protected,
  never entered, never counted, and never reported as "empty". The overview shows how much used space
  therefore cannot be measured (used space minus scanned bytes).

## Building

Push a ZIP of this folder to `uploads/` of the repository that has the "Build APK" workflow.
The workflow detects `rust/Cargo.toml`, builds the library with cargo-ndk for the ABIs in `gradle.properties`
(`rustAbis=arm64-v8a,armeabi-v7a`), then runs Gradle with `-PrustPrebuilt=true`.

The Rust library is named `voxelsandbox` (`libvoxelsandbox.so`) on purpose: the shared workflow's Rust step
fails unless it finds that exact file name. If you change that check to `-name '*.so'`, rename
`[lib] name` in `rust/Cargo.toml` and the `System.loadLibrary(...)` call in `core/Native.kt`.

Local build: install `cargo-ndk`, run `./gradlew assembleDebug` (a Gradle task builds the Rust library first
unless `-PrustPrebuilt=true` is given). `gradle-wrapper.jar` is not included; the workflow downloads it and
Android Studio restores it.

Rust tests (hashing against known vectors, treemap invariants, scanner totals on a generated tree):
`cd rust && cargo test --lib`

## APK size

The release build is one universal APK with every ABI from `rustAbis` inside it. There are no ABI splits.
What keeps it small:

* R8 minification and resource shrinking, with classes repackaged into one package
* English only (`resourceConfigurations`): the translations that Compose and AndroidX bundle are left out
  of `resources.arsc`, which is stored uncompressed
* Native libraries are compressed inside the APK (`useLegacyPackaging`); the Rust crate is built with
  `opt-level = "s"`, fat LTO and stripped symbols
* The daily snapshot is a plain `JobScheduler` job (`core/SnapshotWorker.kt`), so WorkManager and Room are
  not bundled
* No `BuildConfig`, Kotlin's parameter null checks are off, license and metadata files are excluded, and the
  dependency list is kept out of the signing block

The Rust crate keeps `panic = "unwind"` on purpose: every JNI entry point catches panics, so a bug there
cannot kill the app. To drop 32-bit devices as well, set `rustAbis=arm64-v8a` in `gradle.properties`.

## Layout

```
rust/src/scanner.rs   iterative scanner, streams packed records, never holds the file list in memory
rust/src/hash.rs      SHA-256 + sampled/full file hashing
rust/src/treemap.rs   squarified treemap
rust/src/jni_api.rs   the only JNI surface (12 functions, primitives / String / byte[])
app/.../core/         SQLite (Db), scan orchestration, duplicate engine, file actions, SAF support
app/.../gl/           scene builder, OpenGL renderer, camera, touch + labels
app/.../ui/           Compose screens and components
```

How scanning stays light: the Rust thread walks the tree with an explicit stack and sends 256 KB batches over
a small bounded queue; the app writes each batch into a staging table in one transaction. The finished scan
replaces the live index atomically, so cancelling or failing never loses the previous results. Screens only
query the few rows they show (top-N, children of one folder, and so on).
