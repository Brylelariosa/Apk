# JNI: the Rust library looks these methods up by name.
-keep class com.storagemap3d.app.core.Native { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Created by name at runtime (ViewModelProvider).
-keep class com.storagemap3d.app.MainViewModel { <init>(android.app.Application); }

# Size: put every renamed class in one package and let R8 widen access where that saves code.
-repackageclasses ''
-allowaccessmodification
