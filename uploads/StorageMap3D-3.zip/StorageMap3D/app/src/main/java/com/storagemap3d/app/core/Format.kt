package com.storagemap3d.app.core

import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

object Fmt {
    private fun num(x: Double): String = when {
        x >= 100.0 -> String.format(Locale.getDefault(), "%.0f", x)
        x >= 10.0 -> String.format(Locale.getDefault(), "%.1f", x)
        else -> String.format(Locale.getDefault(), "%.2f", x)
    }

    /** Decimal units, like Android's own storage settings. */
    fun bytes(b: Long): String {
        if (b < 0L) return "-"
        val v = b.toDouble()
        return when {
            b < 1000L -> "$b B"
            v < 1e6 -> num(v / 1e3) + " KB"
            v < 1e9 -> num(v / 1e6) + " MB"
            v < 1e12 -> num(v / 1e9) + " GB"
            else -> num(v / 1e12) + " TB"
        }
    }

    fun count(n: Long): String = NumberFormat.getIntegerInstance().format(n)

    fun percent(part: Long, whole: Long): String {
        if (whole <= 0L) return "0%"
        val p = part.toDouble() * 100.0 / whole.toDouble()
        return if (p > 0.0 && p < 1.0) "<1%" else String.format(Locale.getDefault(), "%.0f%%", p)
    }

    fun date(epochSeconds: Long): String {
        if (epochSeconds <= 0L) return "Unknown"
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(epochSeconds * 1000L))
    }

    fun dateTime(epochMillis: Long): String {
        if (epochMillis <= 0L) return "Unknown"
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(epochMillis))
    }

    /** "3 days ago", "1 month ago", "5 months ago" ... for a modification time in epoch seconds. */
    fun ago(epochSeconds: Long, nowMillis: Long = System.currentTimeMillis()): String {
        if (epochSeconds <= 0L) return "Unknown"
        val days = ((nowMillis / 1000L) - epochSeconds) / 86400L
        return when {
            days < 1L -> "Today"
            days < 2L -> "Yesterday"
            days < 30L -> "$days days ago"
            days < 365L -> unitsAgo(days / 30L, "month")
            else -> unitsAgo(days / 365L, "year")
        }
    }

    private fun unitsAgo(n: Long, unit: String): String = if (n == 1L) "1 $unit ago" else "$n ${unit}s ago"

    fun duration(ms: Long): String {
        val s = ms / 1000L
        return if (s < 60L) "${s}s" else "${s / 60L}m ${s % 60L}s"
    }
}
