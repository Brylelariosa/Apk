package com.storagemap3d.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.SortMode
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.FileRef
import com.storagemap3d.app.core.Fmt

private fun sortAndFilter(
    list: List<FileRef>,
    sort: SortMode,
    ascending: Boolean,
    cat: Int,
    showHidden: Boolean,
): List<FileRef> {
    var l = list
    if (!showHidden) l = l.filter { !it.name.startsWith(".") }
    if (cat >= 0) l = l.filter { it.isDir || it.cat == cat }
    val byName: Comparator<FileRef> = compareBy<FileRef> { it.name.lowercase() }
    val primary: Comparator<FileRef> = when (sort) {
        SortMode.Name -> byName
        SortMode.Size -> compareBy<FileRef> { it.size }
        SortMode.Date -> compareBy<FileRef> { it.mtime }
    }
    val directed: Comparator<FileRef> = if (ascending) primary else primary.reversed()
    // Items with the same size or date stay in A to Z order, whichever way the list runs.
    val ordered: Comparator<FileRef> = if (sort == SortMode.Name) directed else directed.then(byName)
    val foldersFirst: Comparator<FileRef> = compareBy<FileRef> { !it.isDir }
    return l.sortedWith(foldersFirst.then(ordered))
}

private fun sortHint(mode: SortMode, ascending: Boolean): String = when (mode) {
    SortMode.Name -> if (ascending) "A to Z" else "Z to A"
    SortMode.Size -> if (ascending) "Smallest first" else "Largest first"
    SortMode.Date -> if (ascending) "Oldest first" else "Newest first"
}

@Composable
fun ExplorerScreen(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    if (vm.access == AccessMode.None) {
        NeedAccess("The explorer needs storage access", onGrantAll, onPickFolder)
        return
    }
    LaunchedEffect(vm.access) { vm.explorerInit() }

    var searchOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    val searching = searchOpen || vm.exQuery.isNotEmpty()
    val listState = rememberLazyListState()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Explorer",
            subtitle = if (searching) "Search the last scan" else vm.exStack.lastOrNull()?.name,
        ) {
            IconBtn(Ico.Search, "Search", { searchOpen = true }, tint = if (searching) Pal.Amber else Pal.Dim)
            Box {
                IconBtn(Ico.Sort, "Sort", { sortOpen = true })
                DropdownMenu(
                    expanded = sortOpen,
                    onDismissRequest = { sortOpen = false },
                    modifier = Modifier.background(Pal.Raised),
                ) {
                    for (mode in SortMode.values()) {
                        val label = when (mode) {
                            SortMode.Name -> "Name"
                            SortMode.Size -> "Size"
                            SortMode.Date -> "Date modified"
                        }
                        val selected = vm.exSort == mode
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(label, color = if (selected) Pal.Amber else Pal.Text)
                                    if (selected) {
                                        Text(sortHint(mode, vm.exAscending), style = Type.Small, color = Pal.Dim)
                                    }
                                }
                            },
                            onClick = {
                                vm.chooseSort(mode)
                                sortOpen = false
                            },
                            trailingIcon = {
                                if (selected) IconMark(Ico.Check, tint = Pal.Amber, boxSize = 18.dp)
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Reverse order", color = Pal.Text) },
                        onClick = {
                            vm.reverseSort()
                            sortOpen = false
                        },
                    )
                }
            }
        }

        if (searching) {
            SearchField(
                value = vm.exQuery,
                onChange = { vm.changeExQuery(it) },
                onClose = {
                    searchOpen = false
                    vm.changeExQuery("")
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            )
        } else {
            CrumbRow(vm)
        }

        FilterRow(vm)

        if (searching) {
            SearchResults(vm)
        } else {
            FolderList(vm, listState)
        }
    }
}

@Composable
private fun CrumbRow(vm: MainViewModel) {
    val stack = vm.exStack
    val scroll = rememberScrollState()
    LaunchedEffect(stack) { scroll.scrollTo(scroll.maxValue) }
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(scroll)
            .padding(horizontal = 14.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        stack.forEachIndexed { i, c ->
            if (i > 0) IconMark(Ico.Chevron, tint = Pal.Faint, boxSize = 14.dp, modifier = Modifier.padding(horizontal = 2.dp))
            val last = i == stack.size - 1
            Text(
                c.name,
                style = if (last) Type.BodyStrong else Type.Body,
                color = if (last) Pal.Text else Pal.Dim,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = !last) { vm.exJump(i) }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun FilterRow(vm: MainViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Chip("All", vm.exFilter < 0, { vm.changeExFilter(-1) })
        for (c in Cat.order) {
            Chip(Cat.label(c), vm.exFilter == c, { vm.changeExFilter(c) }, dot = Color(Cat.color(c)))
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, onClose: () -> Unit, modifier: Modifier) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    LaunchedEffect(Unit) { focus.requestFocus() }
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.Raised)
            .border(1.dp, Pal.Line, shape)
            .padding(start = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconMark(Ico.Search, tint = Pal.Dim, boxSize = 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text("Search names in the last scan", style = Type.Body, color = Pal.Faint)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = Type.Body.copy(color = Pal.Text),
                cursorBrush = SolidColor(Pal.Amber),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        IconBtn(Ico.Close, "Close search", onClose)
    }
}

@Composable
private fun SearchResults(vm: MainViewModel) {
    val query = vm.exQuery
    val results = vm.exResults
    if (!vm.indexUsable) {
        NeedScan(vm, "Search needs a scan")
        return
    }
    if (query.isBlank()) {
        EmptyState("Type to search", "Names are matched anywhere in the last scan, including inside folders.")
        return
    }
    if (results == null) {
        EmptyState("Searching\u2026", "")
        return
    }
    if (results.isEmpty()) {
        EmptyState("No matches", "Nothing in the last scan matches \u201c" + query.trim() + "\u201d.")
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 20.dp),
    ) {
        item {
            Text(
                (if (results.size >= 300) "300+ results" else results.size.toString() + " results") +
                    "  \u00b7  from the last scan",
                style = Type.Small,
                color = Pal.Dim,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
        items(results, key = { it.key + "#" + it.nodeId }) { f ->
            FileRow(
                ref = f,
                subtitle = f.place,
                trailing = if (f.size >= 0L) Fmt.bytes(f.size) else "",
                onClick = {
                    if (f.isDir) vm.showInExplorer(f) else vm.openFile(f)
                },
                onMore = { vm.actionTarget = f },
            )
        }
    }
}

@Composable
private fun FolderList(vm: MainViewModel, listState: androidx.compose.foundation.lazy.LazyListState) {
    val entries = vm.exEntries
    val sorted = remember(entries, vm.exSort, vm.exAscending, vm.exFilter, vm.showHidden) {
        sortAndFilter(entries, vm.exSort, vm.exAscending, vm.exFilter, vm.showHidden)
    }
    val focusKey = vm.exFocusKey
    LaunchedEffect(focusKey, sorted) {
        if (focusKey != null) {
            val idx = sorted.indexOfFirst { it.key == focusKey }
            if (idx >= 0) listState.scrollToItem(idx)
        }
    }

    val error = vm.exError
    if (error != null) {
        EmptyState("Can't open this folder", error)
        return
    }
    if (vm.exLoading && entries.isEmpty()) {
        EmptyState("Loading\u2026", "")
        return
    }
    if (sorted.isEmpty()) {
        EmptyState(
            if (entries.isEmpty()) "This folder is empty" else "Nothing to show",
            if (entries.isEmpty()) "" else "No items match the current filter.",
        )
        return
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 20.dp),
    ) {
        if (!vm.indexUsable) {
            item {
                Notice(
                    "Folder sizes appear after you scan storage.",
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                    ico = Ico.Info,
                )
            }
        }
        if (vm.exTruncated) {
            item {
                Notice(
                    "This folder is very large. Only the first 100,000 items are listed.",
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                    tone = Tone.Warn,
                    ico = Ico.Warning,
                )
            }
        }
        items(sorted, key = { it.key }) { f ->
            val subtitle: String
            val trailing: String
            if (f.isDir) {
                subtitle = if (f.mtime > 0L) "Folder  \u00b7  " + Fmt.ago(f.mtime) else "Folder"
                trailing = if (f.size >= 0L) Fmt.bytes(f.size) else ""
            } else {
                subtitle = Cat.label(f.cat) + "  \u00b7  " + Fmt.ago(f.mtime)
                trailing = Fmt.bytes(f.size)
            }
            FileRow(
                ref = f,
                subtitle = subtitle,
                trailing = trailing,
                onClick = {
                    if (f.isDir) vm.exOpen(f) else vm.openFile(f)
                },
                onMore = { vm.actionTarget = f },
                highlighted = f.key == focusKey,
            )
        }
    }
}
