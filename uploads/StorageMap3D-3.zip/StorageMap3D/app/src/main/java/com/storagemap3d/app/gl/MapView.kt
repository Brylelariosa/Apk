package com.storagemap3d.app.gl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.hypot
import kotlin.math.max

/**
 * Draws folder and file names above the 3D boxes. Labels are projected with the same camera the
 * renderer uses, sorted by importance, skipped when their box is too small on screen (level of
 * detail) and never allowed to overlap each other.
 */
class LabelView(context: Context, private val camera: OrbitCamera) : View(context) {
    var scene: SceneData? = null
    var selectedNode: Long = -1L

    private val metrics = resources.displayMetrics
    private val vp = FloatArray(16)
    private val tmp = FloatArray(4)
    private val projected = FloatArray(4)
    private var px = 0f
    private var py = 0f
    private val rects = Array(64) { RectF() }
    private var rectCount = 0

    private fun sp(v: Float): Float = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, metrics)
    private fun dp(v: Float): Float = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, metrics)

    private val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFEAF2F9.toInt()
        textSize = sp(11.5f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9FB3C8.toInt()
        textSize = sp(10f)
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xD00B1520.toInt()
        style = Paint.Style.FILL
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF2B4258.toInt()
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF4B860.toInt()
        style = Paint.Style.STROKE
        strokeWidth = dp(1.6f)
    }

    override fun onDraw(canvas: Canvas) {
        val s = scene ?: return
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        camera.viewProj(w, h, vp)
        rectCount = 0

        if (selectedNode >= 0L) {
            for (lab in s.labels) {
                if (lab.nodeId == selectedNode) {
                    drawLabel(canvas, lab, w, h, true)
                    break
                }
            }
        }
        var drawn = 0
        for (lab in s.labels) {
            if (drawn >= 28) break
            if (lab.nodeId == selectedNode) continue
            if (drawLabel(canvas, lab, w, h, false)) drawn++
        }
    }

    private fun project(x: Float, y: Float, z: Float, w: Int, h: Int): Boolean {
        tmp[0] = x
        tmp[1] = y
        tmp[2] = z
        tmp[3] = 1f
        Matrix.multiplyMV(projected, 0, vp, 0, tmp, 0)
        if (projected[3] <= 0.01f) return false
        val nx = projected[0] / projected[3]
        val ny = projected[1] / projected[3]
        px = (nx * 0.5f + 0.5f) * w
        py = (1f - (ny * 0.5f + 0.5f)) * h
        return true
    }

    private fun drawLabel(canvas: Canvas, lab: LabelInfo, w: Int, h: Int, force: Boolean): Boolean {
        if (!project(lab.x, lab.y, lab.z, w, h)) return false
        val cx = px
        val cy = py

        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        for (i in 0 until 4) {
            val sx = lab.x + (if ((i and 1) == 0) -lab.halfW else lab.halfW)
            val sz = lab.z + (if ((i and 2) == 0) -lab.halfD else lab.halfD)
            if (!project(sx, lab.y, sz, w, h)) return false
            if (px < minX) minX = px
            if (px > maxX) maxX = px
        }
        val footprint = maxX - minX
        if (!force && footprint < dp(lab.minPx)) return false

        val available = (footprint - dp(10f)).coerceIn(dp(56f), dp(200f))
        val name = TextUtils.ellipsize(lab.name, namePaint, available, TextUtils.TruncateAt.END).toString()
        val textW = max(namePaint.measureText(name), subPaint.measureText(lab.sizeText))
        val nameMetrics = namePaint.fontMetrics
        val subMetrics = subPaint.fontMetrics
        val nameH = nameMetrics.descent - nameMetrics.ascent
        val subH = subMetrics.descent - subMetrics.ascent
        val padX = dp(7f)
        val padY = dp(4f)
        val boxW = textW + 2f * padX
        val boxH = nameH + subH + 2f * padY
        val left = cx - boxW / 2f
        val top = cy - boxH / 2f
        if (left > w || left + boxW < 0f || top > h || top + boxH < 0f) return false

        val slot = if (rectCount < rects.size) rectCount else rects.size - 1
        val r = rects[slot]
        r.set(left, top, left + boxW, top + boxH)
        if (!force) {
            for (i in 0 until rectCount) {
                if (RectF.intersects(rects[i], r)) return false
            }
        }
        if (rectCount < rects.size) rectCount++

        val radius = dp(6f)
        canvas.drawRoundRect(r, radius, radius, bgPaint)
        canvas.drawRoundRect(r, radius, radius, if (force) selectedPaint else linePaint)
        canvas.drawText(name, left + padX, top + padY - nameMetrics.ascent, namePaint)
        canvas.drawText(lab.sizeText, left + padX, top + padY + nameH - subMetrics.ascent, subPaint)
        return true
    }
}

/**
 * The interactive 3D map: an OpenGL ES 3.0 surface with a label overlay on top. One finger orbits,
 * two fingers pan and pinch zooms, a tap selects the box under the finger.
 */
class MapView(context: Context, val camera: OrbitCamera) : FrameLayout(context) {
    private val glView = GLSurfaceView(context)
    private val renderer = MapRenderer(camera)
    private val labels = LabelView(context, camera)

    var scene: SceneData? = null
        private set

    /** Called with the index of the tapped box in [SceneData.picks], or -1 when nothing was hit. */
    var onPick: ((Int) -> Unit)? = null

    /** Called when OpenGL could not be initialised (message for the user). */
    var onError: ((String) -> Unit)? = null

    /** When false the scene appears instantly instead of growing in. */
    var animate: Boolean = true

    private val vp = FloatArray(16)
    private val centre = FloatArray(2)
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var growStart = 0L

    /** True once the user has changed the camera, so a resize must not frame the scene again. */
    private var userMoved = false

    /** True when the scene asked for framing before the view had a size. */
    private var framePending = false

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val f = detector.scaleFactor
                if (f > 0.01f) {
                    camera.zoom(1f / f)
                    cameraChanged()
                }
                return true
            }
        },
    )

    private val growStep = object : Runnable {
        override fun run() {
            val t = ((SystemClock.uptimeMillis() - growStart).toFloat() / 420f).coerceIn(0f, 1f)
            val eased = 1f - (1f - t) * (1f - t) * (1f - t)
            renderer.grow = eased
            glView.requestRender()
            if (t < 1f) postOnAnimation(this)
        }
    }

    init {
        glView.setEGLContextClientVersion(3)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        addView(
            glView,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        addView(
            labels,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
    }

    fun resumeGl() {
        glView.onResume()
        glView.requestRender()
    }

    fun pauseGl() {
        glView.onPause()
    }

    /** Show a freshly built scene. The camera is re-framed only when [resetCamera] is true. */
    fun showScene(s: SceneData, resetCamera: Boolean) {
        scene = s
        labels.scene = s
        if (resetCamera) {
            frame()
        } else if (!framePending) {
            // A view that is re-created (tab switch) or a rebuilt scene keeps the camera as the user left it.
            userMoved = true
        }
        s.setSelected(labels.selectedNode)
        renderer.setScene(s.data, s.count)
        removeCallbacks(growStep)
        if (animate) {
            renderer.grow = 0f
            growStart = SystemClock.uptimeMillis()
            postOnAnimation(growStep)
        } else {
            renderer.grow = 1f
        }
        glView.requestRender()
        labels.invalidate()
        postDelayed({
            val e = renderer.error
            if (e != null) onError?.invoke(e)
        }, 900L)
    }

    /** Highlight the boxes of a node (or clear with -1). */
    fun setSelected(nodeId: Long) {
        val s = scene
        if (labels.selectedNode == nodeId) return
        labels.selectedNode = nodeId
        if (s != null) {
            s.setSelected(nodeId)
            renderer.setScene(s.data, s.count)
            glView.requestRender()
        }
        labels.invalidate()
    }

    fun resetView() {
        if (scene == null) return
        frame()
        cameraChanged()
    }

    fun zoomBy(factor: Float) {
        userMoved = true
        camera.zoom(factor)
        cameraChanged()
    }

    /**
     * Fits the whole scene between the top bar and the legend. Before the first layout the view has no
     * size yet, so the request is kept and carried out in [onSizeChanged].
     */
    private fun frame() {
        val s = scene ?: return
        if (width <= 0 || height <= 0) {
            framePending = true
            return
        }
        val density = resources.displayMetrics.density
        camera.frame(s.extent, width, height, OVERLAY_TOP_DP * density, OVERLAY_BOTTOM_DP * density)
        framePending = false
        userMoved = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (scene != null && (framePending || !userMoved)) {
            frame()
            cameraChanged()
        }
    }

    private fun cameraChanged() {
        glView.requestRender()
        labels.invalidate()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(growStep)
        super.onDetachedFromWindow()
    }

    private fun updateCentre(ev: MotionEvent, skip: Int) {
        var sx = 0f
        var sy = 0f
        var n = 0
        for (i in 0 until ev.pointerCount) {
            if (i == skip) continue
            sx += ev.getX(i)
            sy += ev.getY(i)
            n++
        }
        if (n > 0) {
            centre[0] = sx / n
            centre[1] = sy / n
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                downTime = ev.eventTime
                lastX = ev.x
                lastY = ev.y
                moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                moved = true
                val skip = if (ev.actionMasked == MotionEvent.ACTION_POINTER_UP) ev.actionIndex else -1
                updateCentre(ev, skip)
                lastX = centre[0]
                lastY = centre[1]
            }
            MotionEvent.ACTION_MOVE -> {
                updateCentre(ev, -1)
                val cx = centre[0]
                val cy = centre[1]
                if (!moved && hypot(cx - downX, cy - downY) > touchSlop) moved = true
                if (moved) {
                    val dx = cx - lastX
                    val dy = cy - lastY
                    if (ev.pointerCount >= 2) {
                        camera.pan(dx, dy, height)
                    } else {
                        camera.rotate(dx, dy)
                    }
                    userMoved = true
                    cameraChanged()
                }
                lastX = cx
                lastY = cy
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && ev.eventTime - downTime < 400L) {
                    pickAt(ev.x, ev.y)
                    performClick()
                }
            }
            else -> {}
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun pickAt(sx: Float, sy: Float) {
        val s = scene ?: return
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        camera.viewProj(w, h, vp)
        onPick?.invoke(Picker.pick(s, vp, sx, sy, w, h))
    }

    private companion object {
        /** Height of the crumb bar and the item count above the map (see MapScreen), in dp. */
        const val OVERLAY_TOP_DP = 92f

        /** Height of the hint line and the legend below the map, in dp. */
        const val OVERLAY_BOTTOM_DP = 96f
    }
}
