package com.storagemap3d.app.gl

import android.opengl.Matrix
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

/**
 * Orbit camera around a point on the ground plane. The UI thread changes it from touch gestures and
 * the GL thread reads it every frame, so the fields are volatile.
 */
class OrbitCamera {
    @Volatile var yaw = 0.62f
    @Volatile var pitch = 0.92f
    @Volatile var dist = 160f
    @Volatile var tx = 50f
    @Volatile var tz = 50f
    @Volatile var extent = 100f

    /**
     * Where the middle of the scene lands on screen, as an offset in normalised device coordinates
     * (the whole screen is -1..1). [frame] uses it to centre the map in the part of the view that no
     * overlay covers.
     */
    @Volatile var shiftX = 0f
    @Volatile var shiftY = 0f

    private val fovY = 45f

    /** Frame a square scene of the given size, centred on the whole view. */
    fun reset(sceneExtent: Float) {
        extent = sceneExtent
        yaw = 0.62f
        pitch = 0.92f
        dist = sceneExtent * 1.6f
        tx = sceneExtent / 2f
        tz = sceneExtent / 2f
        shiftX = 0f
        shiftY = 0f
    }

    /**
     * Frame a square scene so that all of it, including the tallest blocks, fits in the part of the
     * view between the overlays at the top ([topPx]) and at the bottom ([bottomPx]). Tall, narrow
     * screens get a steeper and straighter view, because the width runs out first there.
     */
    fun frame(sceneExtent: Float, viewW: Int, viewH: Int, topPx: Float, bottomPx: Float) {
        reset(sceneExtent)
        if (viewW <= 0 || viewH <= 0) return
        val h = viewH.toFloat()
        if (viewW.toFloat() / h < 0.9f) {
            yaw = 0.14f
            pitch = 1.0f
        }
        // Overlays never get to take more than a quarter of the height each (landscape screens).
        val top = min(topPx, h * 0.25f)
        val bottom = min(bottomPx, h * 0.25f)
        val free = h - top - bottom
        val halfW = 0.94f
        val halfH = free / h * 0.97f
        val centreY = 1f - 2f * (top + free / 2f) / h

        // The projected size shrinks roughly in step with the distance, so a few corrections settle it.
        val bounds = FloatArray(4)
        var d = sceneExtent * 1.6f
        for (pass in 0 until 6) {
            dist = d
            if (!projectedBounds(viewW, viewH, bounds)) break
            val needX = (bounds[1] - bounds[0]) / 2f / halfW
            val needY = (bounds[3] - bounds[2]) / 2f / halfH
            val k = max(needX, needY)
            if (k < 0.01f) break
            d = (d * k).coerceIn(sceneExtent * 0.5f, sceneExtent * 3.6f)
        }
        dist = d
        if (projectedBounds(viewW, viewH, bounds)) {
            shiftX = -(bounds[0] + bounds[1]) / 2f
            shiftY = centreY - (bounds[2] + bounds[3]) / 2f
        }
    }

    /**
     * Screen bounds of the scene's bounding box as minX, maxX, minY, maxY in normalised device
     * coordinates. Returns false when part of the box is behind the camera.
     */
    private fun projectedBounds(viewW: Int, viewH: Int, out: FloatArray): Boolean {
        val vp = FloatArray(16)
        viewProj(viewW, viewH, vp)
        val p = FloatArray(4)
        val q = FloatArray(4)
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val lo = -EDGE
        val hi = extent + EDGE
        for (i in 0 until 8) {
            p[0] = if ((i and 1) == 0) lo else hi
            p[1] = if ((i and 2) == 0) 0f else TALLEST
            p[2] = if ((i and 4) == 0) lo else hi
            p[3] = 1f
            Matrix.multiplyMV(q, 0, vp, 0, p, 0)
            if (q[3] <= 0.01f) return false
            val nx = q[0] / q[3]
            val ny = q[1] / q[3]
            if (nx < minX) minX = nx
            if (nx > maxX) maxX = nx
            if (ny < minY) minY = ny
            if (ny > maxY) maxY = ny
        }
        out[0] = minX
        out[1] = maxX
        out[2] = minY
        out[3] = maxY
        return true
    }

    fun eye(out: FloatArray) {
        val cp = cos(pitch)
        out[0] = tx + dist * cp * sin(yaw)
        out[1] = dist * sin(pitch)
        out[2] = tz + dist * cp * cos(yaw)
    }

    fun viewProj(width: Int, height: Int, out: FloatArray) {
        val view = FloatArray(16)
        val proj = FloatArray(16)
        val e = FloatArray(3)
        eye(e)
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], tx, 0f, tz, 0f, 1f, 0f)
        val aspect = if (height <= 0) 1f else width.toFloat() / height.toFloat()
        Matrix.perspectiveM(proj, 0, fovY, aspect, 4f, 1400f)
        // A plain perspective matrix keeps the look-at point in the middle of the screen. These two
        // entries (the third column is multiplied by the eye-space depth) slide it by shiftX / shiftY.
        proj[8] = -shiftX
        proj[9] = -shiftY
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }

    /** Drag with one finger: orbit. */
    fun rotate(dxPx: Float, dyPx: Float) {
        yaw -= dxPx * 0.0055f
        pitch = (pitch + dyPx * 0.0045f).coerceIn(0.22f, 1.5f)
    }

    /** Pinch: positive factor below 1 zooms in. */
    fun zoom(factor: Float) {
        dist = (dist * factor).coerceIn(extent * 0.22f, extent * 3.6f)
    }

    /** Drag with two fingers: slide the scene under the camera. */
    fun pan(dxPx: Float, dyPx: Float, viewHeightPx: Int) {
        val h = max(viewHeightPx, 1).toFloat()
        val perPixel = 2f * dist * tan(Math.toRadians((fovY / 2f).toDouble())).toFloat() / h
        val s = max(sin(pitch), 0.35f)
        val sy = sin(yaw)
        val cy = cos(yaw)
        tx += (-cy * dxPx - sy * dyPx / s) * perPixel
        tz += (sy * dxPx - cy * dyPx / s) * perPixel
        tx = tx.coerceIn(-extent * 0.3f, extent * 1.3f)
        tz = tz.coerceIn(-extent * 0.3f, extent * 1.3f)
    }

    private companion object {
        /** How far past the map's edge the framing box reaches, in scene units. */
        const val EDGE = 3f

        /** Taller than any block the scene builder emits. */
        const val TALLEST = 12f
    }
}
