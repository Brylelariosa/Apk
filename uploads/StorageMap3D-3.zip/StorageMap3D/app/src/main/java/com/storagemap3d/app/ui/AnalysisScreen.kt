package com.storagemap3d.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.AnalysisPage
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.DupGroup
import com.storagemap3d.app.core.DupPhase
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.core.HistoryPoint

@Composable
fun AnalysisScreen(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    if (vm.access == AccessMode.None) {
        NeedAccess("Analysis needs storage access", onGrantAll, onPickFolder)
        return
    }
    val page = vm.analysisPage
    if (page == null) {
        AnalysisHome(vm)
        return
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBtn(Ico.Back, "Back to all analysis", { vm.openAnalysis(null) }, tint = Pal.Text)
            Text(pageTitle(page), style = Type.Title, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (page != AnalysisPage.History && !vm.indexUsable) {
            NeedScan(vm, "This page needs a scan")
        } else {
            when (page) {
                AnalysisPage.Largest -> LargestPage(vm)
                AnalysisPage.Duplicates -> DuplicatesPage(vm)
                AnalysisPage.Distribution -> DistributionPage(vm)
                AnalysisPage.Old -> OldFilesPage(vm)
                AnalysisPage.Empty -> EmptyFoldersPage(vm)
                AnalysisPage.History -> HistoryPage(vm)
            }
        }
    }
}

private fun pageTitle(p: AnalysisPage): String = when (p) {
    AnalysisPage.Largest -> "Largest files"
    AnalysisPage.Duplicates -> "Duplicate finder"
    AnalysisPage.Distribution -> "Storage distribution"
    AnalysisPage.Old -> "Old files"
    AnalysisPage.Empty -> "Empty folders"
    AnalysisPage.History -> "Storage history"
}

@Composable
private fun AnalysisHome(vm: MainViewModel) {
    val top = vm.summary.topFiles.firstOrNull()
    val needsScan = if (vm.indexUsable) "" else "  \u00b7  needs a scan"
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader(title = "Analysis", subtitle = "Find what is using your space. Nothing is deleted unless you confirm it.", startPadding = 4.dp) }
        item {
            AnalysisCard(
                Ico.File, "Largest files",
                if (top != null) "Biggest: " + top.name + "  \u00b7  " + Fmt.bytes(top.size) else "Files and folders using the most space" + needsScan,
            ) { vm.openAnalysis(AnalysisPage.Largest) }
        }
        item {
            AnalysisCard(Ico.Copy, "Duplicate finder", "Identical files, confirmed with SHA-256 checksums" + needsScan) {
                vm.openAnalysis(AnalysisPage.Duplicates)
            }
        }
        item {
            AnalysisCard(Ico.Pie, "Storage distribution", "Space used by images, video, audio, documents and more" + needsScan) {
                vm.openAnalysis(AnalysisPage.Distribution)
            }
        }
        item {
            AnalysisCard(Ico.Clock, "Old files", "Large files that have not been modified in a long time" + needsScan) {
                vm.openAnalysis(AnalysisPage.Old)
            }
        }
        item {
            AnalysisCard(Ico.Folder, "Empty folders", "Folders that hold no files at all" + needsScan) {
                vm.openAnalysis(AnalysisPage.Empty)
            }
        }
        item {
            AnalysisCard(Ico.Chart, "Storage history", "How used space changes from one snapshot to the next") {
                vm.openAnalysis(AnalysisPage.History)
            }
        }
    }
}

@Composable
private fun AnalysisCard(ico: Ico, title: String, body: String, onClick: () -> Unit) {
    Panel(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Pal.AmberSoft),
                contentAlignment = Alignment.Center,
            ) {
                IconMark(ico, tint = Pal.Amber, boxSize = 22.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = Type.Heading, color = Pal.Text)
                Text(body, style = Type.Small, color = Pal.Dim, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            IconMark(Ico.Chevron, tint = Pal.Faint)
        }
    }
}

@Composable
private fun SelectionBar(text: String, button: String, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clip(shape)
            .background(Pal.Panel)
            .border(1.dp, Pal.Line, shape)
            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, style = Type.BodyStrong, color = Pal.Text, modifier = Modifier.weight(1f))
        AppButton(button, onClick, kind = BtnKind.Danger)
    }
}

// ------------------------------------------------------------------------------------------------
// Largest files
// ------------------------------------------------------------------------------------------------

@Composable
private fun LargestPage(vm: MainViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
    ) {
        item {
            Segmented(
                listOf("Files", "Folders"),
                vm.largestMode,
                { vm.largestMode = it },
                Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            )
        }
        if (vm.largestMode == 0) {
            if (vm.largestFiles.isEmpty()) {
                item { EmptyState("No files found", "The last scan did not find any files.") }
            }
            items(vm.largestFiles, key = { it.key + "#" + it.nodeId }) { f ->
                FileRow(
                    ref = f,
                    subtitle = f.place + "  \u00b7  " + Fmt.ago(f.mtime),
                    trailing = Fmt.bytes(f.size),
                    onClick = { vm.actionTarget = f },
                )
            }
        } else {
            item {
                Text(
                    "Ranked by the files directly inside each folder, so a big parent folder does not hide the folder that really holds the data.",
                    style = Type.Small,
                    color = Pal.Dim,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            if (vm.largestFolders.isEmpty()) {
                item { EmptyState("No folders found", "The last scan did not find any readable folders.") }
            }
            items(vm.largestFolders, key = { it.ref.key + "#" + it.ref.nodeId }) { row ->
                FileRow(
                    ref = row.ref,
                    subtitle = row.ref.place + "  \u00b7  " + Fmt.bytes(row.ref.size) + " with subfolders",
                    trailing = Fmt.bytes(row.own),
                    onClick = { vm.actionTarget = row.ref },
                )
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Duplicates
// ------------------------------------------------------------------------------------------------

private val DUP_SIZES = listOf(10 to "10 KB", 100 to "100 KB", 1000 to "1 MB", 10000 to "10 MB")

@Composable
private fun DuplicatesPage(vm: MainViewModel) {
    val ui = vm.dups.ui
    val running = ui.phase == DupPhase.Running
    var selectedBytes = 0L
    for ((_, members) in vm.dupMembers) {
        for (m in members) if (vm.dupSelected.contains(m.nodeId)) selectedBytes += m.size
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Panel {
                    Text(
                        "Finds files with exactly the same content. Files are grouped by size, then compared with SHA-256 checksums calculated on this device. Nothing is deleted unless you select files and confirm.",
                        style = Type.Body,
                        color = Pal.Dim,
                    )
                    Spacer(Modifier.height(14.dp))
                    Text("Ignore files smaller than", style = Type.Label, color = Pal.Dim)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((kb, label) in DUP_SIZES) {
                            Chip(label, vm.dupMinKb == kb, { if (!running) vm.changeDupMinKb(kb) })
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    if (running) {
                        AppButton("Cancel", { vm.cancelDuplicates() }, Modifier.fillMaxWidth(), kind = BtnKind.Secondary, ico = Ico.Stop)
                    } else {
                        AppButton("Find duplicates", { vm.findDuplicates() }, Modifier.fillMaxWidth(), ico = Ico.Search)
                    }
                }
            }

            if (ui.phase != DupPhase.Idle) {
                item {
                    Panel {
                        val title = when (ui.phase) {
                            DupPhase.Running -> "Comparing files"
                            DupPhase.Done -> "Finished"
                            DupPhase.Cancelled -> "Cancelled"
                            DupPhase.Failed -> "Could not finish"
                            DupPhase.Idle -> ""
                        }
                        Text(title, style = Type.Heading, color = Pal.Text)
                        Spacer(Modifier.height(8.dp))
                        if (ui.phase == DupPhase.Failed) {
                            Notice(ui.message, tone = Tone.Bad, ico = Ico.Warning)
                        } else {
                            val fraction = if (ui.candidates > 0L) ui.checked.toFloat() / ui.candidates.toFloat() else 0f
                            if (running) Meter(fraction, Pal.Amber)
                            if (running) Spacer(Modifier.height(8.dp))
                            Text(
                                "Checked " + Fmt.count(ui.checked) + " of " + Fmt.count(ui.candidates) +
                                    " files with a matching size  \u00b7  " + Fmt.bytes(ui.hashedBytes) + " read",
                                style = Type.Small,
                                color = Pal.Dim,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                Fmt.count(ui.groups.toLong()) + " groups found  \u00b7  " + Fmt.bytes(ui.wasted) + " could be freed",
                                style = Type.BodyStrong,
                                color = Pal.Text,
                            )
                        }
                    }
                }
            }

            if (!running && vm.dupGroups.isEmpty() && ui.phase == DupPhase.Done) {
                item { EmptyState("No duplicates", "No two files of at least this size have the same content.") }
            }
            items(vm.dupGroups, key = { it.gid }) { g -> DupGroupCard(vm, g) }
        }

        if (vm.dupSelected.isNotEmpty()) {
            SelectionBar(
                text = vm.dupSelected.size.toString() + " selected  \u00b7  " + Fmt.bytes(selectedBytes),
                button = "Delete\u2026",
                onClick = { vm.deleteSelectedDuplicates() },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

@Composable
private fun DupGroupCard(vm: MainViewModel, g: DupGroup) {
    val expanded = vm.dupExpanded == g.gid
    val members = vm.dupMembers[g.gid]
    Panel(padding = 0.dp) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { vm.toggleDupGroup(g.gid) }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(g.count.toString() + " copies  \u00b7  " + Fmt.bytes(g.size) + " each", style = Type.Heading, color = Pal.Text)
                Text(
                    "Keeping one frees " + Fmt.bytes(g.size * (g.count - 1).toLong()),
                    style = Type.Small,
                    color = Pal.Dim,
                )
            }
            IconMark(if (expanded) Ico.Up else Ico.Chevron, tint = Pal.Faint)
        }
        if (expanded) {
            if (members == null) {
                Text("Loading\u2026", style = Type.Small, color = Pal.Dim, modifier = Modifier.padding(14.dp))
            } else {
                Column(Modifier.padding(horizontal = 6.dp)) {
                    for (m in members) {
                        FileRow(
                            ref = m,
                            subtitle = m.place + "  \u00b7  " + Fmt.date(m.mtime),
                            trailing = "",
                            onClick = { vm.toggleDupSelect(m.nodeId) },
                            onMore = { vm.actionTarget = m },
                            leading = { CheckMark(vm.dupSelected.contains(m.nodeId)) },
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    AppButton("Keep the oldest", { vm.dupKeepOldest(g.gid) }, Modifier.weight(1f), kind = BtnKind.Secondary)
                    AppButton("Clear", { vm.dupClearSelection() }, Modifier.weight(1f), kind = BtnKind.Ghost)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Distribution
// ------------------------------------------------------------------------------------------------

@Composable
private fun DistributionPage(vm: MainViewModel) {
    val cats = vm.summary.cats
    var total = 0L
    for (c in cats) total += c.bytes
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (total <= 0L) {
            item { EmptyState("Nothing to show", "The last scan did not find any files.") }
            return@LazyColumn
        }
        item {
            Panel {
                Text(Fmt.bytes(total), style = Type.Display, color = Pal.Text)
                Text("in " + Fmt.count(cats.sumOf { it.files }) + " files", style = Type.Small, color = Pal.Dim)
                Spacer(Modifier.height(16.dp))
                val parts = ArrayList<Pair<Float, Color>>()
                for (cat in Cat.order) {
                    for (c in cats) if (c.cat == cat && c.bytes > 0L) parts.add(Pair(c.bytes.toFloat(), Color(Cat.color(cat))))
                }
                StackBar(parts, height = 18.dp)
            }
        }
        for (cat in Cat.order) {
            var stat: com.storagemap3d.app.core.CatStat? = null
            for (c in cats) if (c.cat == cat) stat = c
            val s = stat
            if (s == null || s.files == 0L) continue
            item(key = "cat" + cat) {
                val open = vm.distCat == cat
                val color = Color(Cat.color(cat))
                Panel(padding = 0.dp) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.selectCategory(cat) }
                            .padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(Cat.label(cat), style = Type.Heading, color = Pal.Text)
                                Text(Fmt.count(s.files) + " files", style = Type.Small, color = Pal.Dim)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Fmt.bytes(s.bytes), style = Type.Num, color = Pal.Text)
                                Text(Fmt.percent(s.bytes, total), style = Type.Small, color = Pal.Dim)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Meter(s.bytes.toFloat() / total.toFloat(), color)
                    }
                    if (open) {
                        Text(
                            if (cat == Cat.OTHER) "Largest files" else "Largest " + Cat.label(cat).lowercase(),
                            style = Type.Label,
                            color = Pal.Dim,
                            modifier = Modifier.padding(start = 14.dp, bottom = 4.dp),
                        )
                        Column(Modifier.padding(start = 6.dp, end = 6.dp, bottom = 10.dp)) {
                            for (f in vm.distFiles) {
                                FileRow(f, f.place, Fmt.bytes(f.size), onClick = { vm.actionTarget = f })
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Old files
// ------------------------------------------------------------------------------------------------

private val OLD_CHOICES = listOf(6 to "6 months", 12 to "1 year", 24 to "2 years", 36 to "3 years")

@Composable
private fun OldFilesPage(vm: MainViewModel) {
    val label = OLD_CHOICES.firstOrNull { it.first == vm.oldMonths }?.second ?: (vm.oldMonths.toString() + " months")
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
                Text("Not modified for at least", style = Type.Label, color = Pal.Dim)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((months, text) in OLD_CHOICES) {
                        Chip(text, vm.oldMonths == months, { vm.changeOldMonths(months) })
                    }
                }
                Spacer(Modifier.height(14.dp))
                Panel {
                    Text(Fmt.bytes(vm.oldBytes), style = Type.Display, color = Pal.Text)
                    Text(
                        Fmt.count(vm.oldCount) + " files untouched for " + label + " or more",
                        style = Type.Small,
                        color = Pal.Dim,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("The largest ones are listed first. Tap a file to open it, share it or delete it.", style = Type.Small, color = Pal.Dim)
            }
        }
        if (vm.oldFiles.isEmpty()) {
            item { EmptyState("Nothing this old", "No file has gone unmodified for " + label + " or longer.") }
        }
        items(vm.oldFiles, key = { it.key + "#" + it.nodeId }) { f ->
            FileRow(
                ref = f,
                subtitle = f.place + "  \u00b7  " + Fmt.ago(f.mtime),
                trailing = Fmt.bytes(f.size),
                onClick = { vm.actionTarget = f },
            )
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Empty folders
// ------------------------------------------------------------------------------------------------

@Composable
private fun EmptyFoldersPage(vm: MainViewModel) {
    val all = vm.emptyFolders
    val allSelected = all.isNotEmpty() && vm.emptySelected.size == all.size
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 100.dp),
        ) {
            item {
                Column(Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
                    Text(
                        "Top-most folders that contain no files at all. Folders Android does not let this app read are never listed, because their contents are unknown.",
                        style = Type.Body,
                        color = Pal.Dim,
                    )
                    if (all.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                Fmt.count(all.size.toLong()) + (if (all.size >= 500) "+" else "") + " empty folders",
                                style = Type.BodyStrong,
                                color = Pal.Text,
                                modifier = Modifier.weight(1f),
                            )
                            AppButton(
                                if (allSelected) "Select none" else "Select all",
                                { vm.selectAllEmpty(!allSelected) },
                                kind = BtnKind.Ghost,
                            )
                        }
                    }
                }
            }
            if (all.isEmpty()) {
                item { EmptyState("No empty folders", "Every readable folder in the last scan holds at least one file.") }
            }
            items(all, key = { it.key + "#" + it.nodeId }) { f ->
                FileRow(
                    ref = f,
                    subtitle = f.place,
                    trailing = "",
                    onClick = { vm.toggleEmpty(f.nodeId) },
                    onMore = { vm.actionTarget = f },
                    leading = { CheckMark(vm.emptySelected.contains(f.nodeId)) },
                )
            }
        }
        if (vm.emptySelected.isNotEmpty()) {
            SelectionBar(
                text = vm.emptySelected.size.toString() + " selected",
                button = "Delete\u2026",
                onClick = { vm.deleteSelectedEmpty() },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

// ------------------------------------------------------------------------------------------------
// History
// ------------------------------------------------------------------------------------------------

@Composable
private fun HistoryPage(vm: MainViewModel) {
    val points = vm.history
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Panel {
                if (points.size < 2) {
                    Text(
                        if (points.isEmpty()) "No snapshots yet." else "One snapshot so far.",
                        style = Type.Heading,
                        color = Pal.Text,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "A snapshot is saved after every scan, when you open the app (at most every six hours) and once a day in the background if that is switched on in Settings. The chart appears once there are two.",
                        style = Type.Body,
                        color = Pal.Dim,
                    )
                } else {
                    val first = points.first()
                    val last = points.last()
                    val delta = last.used - first.used
                    Text(
                        (if (delta >= 0L) "+" else "-") + Fmt.bytes(if (delta >= 0L) delta else -delta),
                        style = Type.Display,
                        color = if (delta > 0L) Pal.Amber else Pal.Ok,
                    )
                    Text(
                        "used space since " + Fmt.dateTime(first.ts),
                        style = Type.Small,
                        color = Pal.Dim,
                    )
                    Spacer(Modifier.height(16.dp))
                    UsedChart(points)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Text(Fmt.date(first.ts / 1000L), style = Type.Small, color = Pal.Faint, modifier = Modifier.weight(1f))
                        Text(Fmt.date(last.ts / 1000L), style = Type.Small, color = Pal.Faint)
                    }
                }
                Spacer(Modifier.height(14.dp))
                AppButton("Save a snapshot now", { vm.saveSnapshotNow() }, Modifier.fillMaxWidth(), kind = BtnKind.Secondary)
            }
        }
        if (points.isNotEmpty()) {
            item {
                Panel(padding = 8.dp) {
                    Text("Snapshots", style = Type.Heading, color = Pal.Text, modifier = Modifier.padding(start = 8.dp, top = 6.dp, bottom = 6.dp))
                    val newestFirst = points.reversed()
                    for ((i, p) in newestFirst.withIndex()) {
                        val older = newestFirst.getOrNull(i + 1)
                        SnapshotRow(p, older)
                    }
                }
            }
        }
    }
}

@Composable
private fun SnapshotRow(p: HistoryPoint, older: HistoryPoint?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(Fmt.dateTime(p.ts), style = Type.Body, color = Pal.Text)
            Text("Free " + Fmt.bytes(p.free) + "  \u00b7  Used " + Fmt.bytes(p.used), style = Type.Small, color = Pal.Dim)
        }
        if (older != null) {
            val d = p.used - older.used
            Text(
                (if (d >= 0L) "+" else "-") + Fmt.bytes(if (d >= 0L) d else -d),
                style = Type.Num,
                color = if (d > 0L) Pal.Amber else if (d < 0L) Pal.Ok else Pal.Dim,
            )
        }
    }
}

@Composable
private fun UsedChart(points: List<HistoryPoint>) {
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        if (points.size < 2) return@Canvas
        val w = size.width
        val h = size.height
        val minT = points.first().ts
        val maxT = points.last().ts
        var lo = Long.MAX_VALUE
        var hi = Long.MIN_VALUE
        for (p in points) {
            if (p.used < lo) lo = p.used
            if (p.used > hi) hi = p.used
        }
        if (hi == lo) {
            hi += 1L
            lo -= 1L
        }
        val pad = (hi - lo).toFloat() * 0.18f
        val lo2 = lo.toFloat() - pad
        val span = (hi.toFloat() + pad) - lo2

        fun px(t: Long): Float = if (maxT == minT) 0f else ((t - minT).toFloat() / (maxT - minT).toFloat()) * w
        fun py(v: Long): Float = h - ((v.toFloat() - lo2) / span) * h

        for (i in 0..3) {
            val y = h * i / 3f
            drawLine(Pal.Line, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
        }
        val line = Path()
        val fill = Path()
        for ((i, p) in points.withIndex()) {
            val x = px(p.ts)
            val y = py(p.used)
            if (i == 0) {
                line.moveTo(x, y)
                fill.moveTo(x, h)
                fill.lineTo(x, y)
            } else {
                line.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(px(maxT), h)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(Pal.Amber.copy(alpha = 0.28f), Color.Transparent)))
        drawPath(line, Pal.Amber, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        val lastP = points.last()
        drawCircle(Pal.Ink, radius = 6.dp.toPx(), center = Offset(px(lastP.ts), py(lastP.used)))
        drawCircle(Pal.Amber, radius = 4.dp.toPx(), center = Offset(px(lastP.ts), py(lastP.used)))
    }
}
