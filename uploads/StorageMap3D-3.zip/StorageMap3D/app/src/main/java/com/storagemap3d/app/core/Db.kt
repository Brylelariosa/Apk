package com.storagemap3d.app.core

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement
import android.util.LruCache
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * SQLite index of the last scan plus storage history and duplicate results.
 *
 * Scans are written into a staging table and swapped in only when they finish, so cancelling or
 * failing a scan never destroys the previous results. Files are never all held in memory: the app
 * asks the index for the few rows each screen needs.
 *
 * Folder sizes in `nodes` are recursive totals; `files` and `dirs` are recursive counts.
 */
class Db private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "storagemap.db", null, 1) {

    companion object {
        @Volatile
        private var instance: Db? = null

        fun get(context: Context): Db {
            val existing = instance
            if (existing != null) return existing
            return synchronized(this) {
                val again = instance
                if (again != null) {
                    again
                } else {
                    val created = Db(context)
                    instance = created
                    created
                }
            }
        }

        private const val COLS = "id,parent,name,is_dir,size,mtime,cat,files,dirs,flags,doc"

        private fun cols(alias: String): String {
            val parts = COLS.split(",")
            return parts.joinToString(",") { "$alias.$it" }
        }

        private fun nodesDdl(table: String): String =
            "CREATE TABLE $table(" +
                "id INTEGER PRIMARY KEY, parent INTEGER NOT NULL, name TEXT NOT NULL, " +
                "is_dir INTEGER NOT NULL, size INTEGER NOT NULL, mtime INTEGER NOT NULL, " +
                "cat INTEGER NOT NULL, files INTEGER NOT NULL DEFAULT 0, dirs INTEGER NOT NULL DEFAULT 0, " +
                "flags INTEGER NOT NULL DEFAULT 0, doc TEXT)"

        private fun createNodeIndexes(db: SQLiteDatabase) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_nodes_parent ON nodes(parent, size DESC)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_nodes_file_size ON nodes(size DESC) WHERE is_dir = 0")
        }
    }

    private class Link(val parent: Long, val name: String)

    private val links = LruCache<Long, Link>(8192)
    private var stageStmt: SQLiteStatement? = null

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(nodesDdl("nodes"))
        createNodeIndexes(db)
        db.execSQL(
            "CREATE TABLE scans(id INTEGER PRIMARY KEY AUTOINCREMENT, root TEXT NOT NULL, mode TEXT NOT NULL, " +
                "started INTEGER NOT NULL, finished INTEGER NOT NULL, files INTEGER NOT NULL, dirs INTEGER NOT NULL, " +
                "bytes INTEGER NOT NULL, restricted INTEGER NOT NULL, errors INTEGER NOT NULL)"
        )
        db.execSQL("CREATE TABLE cat_stats(cat INTEGER PRIMARY KEY, files INTEGER NOT NULL, bytes INTEGER NOT NULL)")
        db.execSQL(
            "CREATE TABLE history(ts INTEGER PRIMARY KEY, total INTEGER NOT NULL, used INTEGER NOT NULL, " +
                "free INTEGER NOT NULL, scanned INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE dup_groups(gid INTEGER PRIMARY KEY AUTOINCREMENT, size INTEGER NOT NULL, " +
                "hash TEXT NOT NULL, cnt INTEGER NOT NULL)"
        )
        db.execSQL("CREATE TABLE dup_members(gid INTEGER NOT NULL, node INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_dup_members ON dup_members(gid)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 is the first schema.
    }

    // ------------------------------------------------------------------------------------------
    // Small query helpers
    // ------------------------------------------------------------------------------------------

    private fun <T> list(sql: String, args: Array<String>? = null, map: (Cursor) -> T): List<T> {
        val out = ArrayList<T>()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out.add(map(c))
        }
        return out
    }

    private fun scalar(sql: String, default: Long = 0L): Long {
        return readableDatabase.rawQuery(sql, null).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else default
        }
    }

    private fun row(c: Cursor): NodeRow = NodeRow(
        id = c.getLong(0),
        parent = c.getLong(1),
        name = c.getString(2) ?: "",
        isDir = c.getInt(3) == 1,
        size = c.getLong(4),
        mtime = c.getLong(5),
        cat = c.getInt(6),
        files = c.getLong(7),
        dirs = c.getLong(8),
        flags = c.getInt(9),
        doc = if (c.isNull(10)) null else c.getString(10),
    )

    // ------------------------------------------------------------------------------------------
    // Staging a new scan
    // ------------------------------------------------------------------------------------------

    fun beginStage() {
        val db = writableDatabase
        stageStmt?.close()
        stageStmt = null
        db.execSQL("DROP TABLE IF EXISTS nodes_stage")
        db.execSQL(nodesDdl("nodes_stage"))
        stageStmt = db.compileStatement(
            "INSERT INTO nodes_stage(id,parent,name,is_dir,size,mtime,cat,files,dirs,flags,doc) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?)"
        )
    }

    /** Insert one batch of packed records produced by the Rust scanner (layout in scanner.rs). */
    fun ingestNative(batch: ByteArray) {
        val stmt = stageStmt ?: return
        val db = writableDatabase
        val bb = ByteBuffer.wrap(batch).order(ByteOrder.LITTLE_ENDIAN)
        db.beginTransaction()
        try {
            while (bb.remaining() > 0) {
                val kind = bb.get().toInt()
                val id = bb.getInt().toLong()
                val parent = bb.getInt().toLong() // 0xFFFFFFFF reads as -1 = no parent
                val size = bb.getLong()
                val mtime = bb.getLong()
                var files = 0L
                var dirs = 0L
                var flags = 0
                var cat = 0
                if (kind == 1) {
                    cat = bb.get().toInt() and 0xFF
                } else {
                    files = bb.getInt().toLong() and 0xFFFFFFFFL
                    dirs = bb.getInt().toLong() and 0xFFFFFFFFL
                    flags = bb.get().toInt() and 0xFF
                }
                val n = bb.getShort().toInt() and 0xFFFF
                val name = String(batch, bb.position(), n, Charsets.UTF_8)
                bb.position(bb.position() + n)

                stmt.clearBindings()
                stmt.bindLong(1, id)
                stmt.bindLong(2, parent)
                stmt.bindString(3, name)
                stmt.bindLong(4, if (kind == 2) 1L else 0L)
                stmt.bindLong(5, size)
                stmt.bindLong(6, mtime)
                stmt.bindLong(7, cat.toLong())
                stmt.bindLong(8, files)
                stmt.bindLong(9, dirs)
                stmt.bindLong(10, flags.toLong())
                stmt.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Insert already decoded rows (used by the Storage Access Framework scanner). */
    fun stageMany(rows: List<NodeRow>) {
        val stmt = stageStmt ?: return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (r in rows) {
                stmt.clearBindings()
                stmt.bindLong(1, r.id)
                stmt.bindLong(2, r.parent)
                stmt.bindString(3, r.name)
                stmt.bindLong(4, if (r.isDir) 1L else 0L)
                stmt.bindLong(5, r.size)
                stmt.bindLong(6, r.mtime)
                stmt.bindLong(7, r.cat.toLong())
                stmt.bindLong(8, r.files)
                stmt.bindLong(9, r.dirs)
                stmt.bindLong(10, r.flags.toLong())
                if (r.doc != null) stmt.bindString(11, r.doc)
                stmt.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Swap the staged scan in as the live index and record it. */
    fun commitStage(info: ScanInfo) {
        val db = writableDatabase
        stageStmt?.close()
        stageStmt = null
        db.beginTransaction()
        try {
            db.execSQL("DROP TABLE IF EXISTS nodes")
            db.execSQL("ALTER TABLE nodes_stage RENAME TO nodes")
            createNodeIndexes(db)
            db.execSQL("DELETE FROM cat_stats")
            db.execSQL(
                "INSERT INTO cat_stats(cat, files, bytes) " +
                    "SELECT cat, COUNT(*), SUM(size) FROM nodes WHERE is_dir = 0 GROUP BY cat"
            )
            db.execSQL("DELETE FROM dup_members")
            db.execSQL("DELETE FROM dup_groups")
            db.execSQL(
                "INSERT INTO scans(root, mode, started, finished, files, dirs, bytes, restricted, errors) " +
                    "VALUES(?,?,?,?,?,?,?,?,?)",
                arrayOf<Any>(
                    info.root, info.mode, info.started, info.finished, info.files,
                    info.dirs, info.bytes, info.restricted, info.errors,
                ),
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        links.evictAll()
    }

    fun dropStage() {
        stageStmt?.close()
        stageStmt = null
        try {
            writableDatabase.execSQL("DROP TABLE IF EXISTS nodes_stage")
        } catch (e: Exception) {
            // Nothing useful to do; the next scan drops it again.
        }
    }

    // ------------------------------------------------------------------------------------------
    // Reads
    // ------------------------------------------------------------------------------------------

    fun lastScan(): ScanInfo? {
        val rows = list(
            "SELECT id,root,mode,started,finished,files,dirs,bytes,restricted,errors FROM scans ORDER BY id DESC LIMIT 1"
        ) { c ->
            ScanInfo(
                c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), c.getLong(4),
                c.getLong(5), c.getLong(6), c.getLong(7), c.getLong(8), c.getLong(9),
            )
        }
        return rows.firstOrNull()
    }

    fun rootId(): Long = scalar("SELECT id FROM nodes WHERE parent = -1 LIMIT 1", -1L)

    fun rootNode(): NodeRow? {
        val id = rootId()
        return if (id < 0L) null else node(id)
    }

    fun node(id: Long): NodeRow? {
        val rows = list("SELECT $COLS FROM nodes WHERE id = $id") { row(it) }
        return rows.firstOrNull()
    }

    fun nodeByDoc(doc: String): NodeRow? {
        val rows = list("SELECT $COLS FROM nodes WHERE doc = ? LIMIT 1", arrayOf(doc)) { row(it) }
        return rows.firstOrNull()
    }

    /** Largest children first; empty items are skipped. */
    fun children(parent: Long, limit: Int): List<NodeRow> =
        list("SELECT $COLS FROM nodes WHERE parent = $parent AND size > 0 ORDER BY size DESC LIMIT $limit") { row(it) }

    /** Number of non-empty children of [parent]. */
    fun childCount(parent: Long): Long =
        scalar("SELECT COUNT(*) FROM nodes WHERE parent = $parent AND size > 0")

    /** Recursive sizes of the sub-folders of [parent], by folder name. */
    fun childDirSizes(parent: Long): Map<String, Long> {
        val out = HashMap<String, Long>()
        readableDatabase.rawQuery("SELECT name, size FROM nodes WHERE parent = $parent AND is_dir = 1", null).use { c ->
            while (c.moveToNext()) out[c.getString(0) ?: ""] = c.getLong(1)
        }
        return out
    }

    fun childByName(parent: Long, name: String): Long {
        return readableDatabase.rawQuery(
            "SELECT id FROM nodes WHERE parent = $parent AND name = ? LIMIT 1", arrayOf(name)
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
    }

    fun catStats(): List<CatStat> =
        list("SELECT cat, files, bytes FROM cat_stats") { CatStat(it.getInt(0), it.getLong(1), it.getLong(2)) }

    fun topFiles(limit: Int, cat: Int = -1): List<NodeRow> {
        val filter = if (cat >= 0) " AND cat = $cat" else ""
        return list("SELECT $COLS FROM nodes WHERE is_dir = 0$filter ORDER BY size DESC LIMIT $limit") { row(it) }
    }

    /** Folders ranked by the size of the files directly inside them (sub-folders not included). */
    fun topFolders(limit: Int): List<FolderStat> = list(
        "SELECT ${cols("d")}, " +
            "d.size - COALESCE((SELECT SUM(c.size) FROM nodes c WHERE c.parent = d.id AND c.is_dir = 1), 0) AS own " +
            "FROM nodes d WHERE d.is_dir = 1 AND d.parent <> -1 AND (d.flags & 3) = 0 " +
            "ORDER BY own DESC LIMIT $limit"
    ) { FolderStat(row(it), it.getLong(11)) }

    fun oldFiles(cutoffSec: Long, limit: Int): List<NodeRow> = list(
        "SELECT $COLS FROM nodes WHERE is_dir = 0 AND mtime > 0 AND mtime < $cutoffSec " +
            "ORDER BY size DESC LIMIT $limit"
    ) { row(it) }

    /** Number of files and their total bytes that were last modified before [cutoffSec]. */
    fun oldTotals(cutoffSec: Long): Pair<Long, Long> {
        return readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(size), 0) FROM nodes WHERE is_dir = 0 AND mtime > 0 AND mtime < $cutoffSec",
            null,
        ).use { c -> if (c.moveToFirst()) Pair(c.getLong(0), c.getLong(1)) else Pair(0L, 0L) }
    }

    /**
     * Top-most folders that hold no files at all. Folders Android would not let us read are never
     * listed, because their contents are unknown.
     */
    fun emptyDirs(limit: Int): List<NodeRow> = list(
        "SELECT ${cols("n")} FROM nodes n WHERE n.is_dir = 1 AND n.files = 0 AND (n.flags & 7) = 0 " +
            "AND n.parent <> -1 AND EXISTS (SELECT 1 FROM nodes p WHERE p.id = n.parent AND p.files > 0) " +
            "ORDER BY n.name COLLATE NOCASE LIMIT $limit"
    ) { row(it) }

    fun search(query: String, cat: Int, limit: Int): List<NodeRow> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val escaped = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        val filter = if (cat >= 0) " AND is_dir = 0 AND cat = $cat" else ""
        return list(
            "SELECT $COLS FROM nodes WHERE name LIKE ? ESCAPE '\\' AND parent <> -1$filter " +
                "ORDER BY is_dir DESC, size DESC LIMIT $limit",
            arrayOf("%$escaped%"),
        ) { row(it) }
    }

    // ------------------------------------------------------------------------------------------
    // Paths
    // ------------------------------------------------------------------------------------------

    private fun link(id: Long): Link? {
        val cached = links.get(id)
        if (cached != null) return cached
        val found = readableDatabase.rawQuery("SELECT parent, name FROM nodes WHERE id = $id", null).use { c ->
            if (c.moveToFirst()) Link(c.getLong(0), c.getString(1) ?: "") else null
        }
        if (found != null) links.put(id, found)
        return found
    }

    private fun chain(id: Long): ArrayList<String> {
        val parts = ArrayList<String>()
        var cur = id
        var guard = 0
        while (cur >= 0L && guard < 1024) {
            val l = link(cur) ?: break
            parts.add(l.name)
            cur = l.parent
            guard++
        }
        parts.reverse()
        return parts
    }

    /** Absolute path of a node (root name is the scanned directory itself). */
    fun pathOf(id: Long): String {
        val parts = chain(id)
        if (parts.isEmpty()) return ""
        val sb = StringBuilder(parts[0])
        for (i in 1 until parts.size) {
            if (!sb.endsWith("/")) sb.append('/')
            sb.append(parts[i])
        }
        return sb.toString()
    }

    /** Path below the scan root, for example "DCIM/Camera" (empty for the root itself). */
    fun relPathOf(id: Long): String {
        val parts = chain(id)
        if (parts.size <= 1) return ""
        return parts.subList(1, parts.size).joinToString("/")
    }

    /** Nodes from the scan root down to [id] (inclusive). */
    fun trail(id: Long): List<NodeRow> {
        val out = ArrayList<NodeRow>()
        var cur = id
        var guard = 0
        while (cur >= 0L && guard < 1024) {
            val n = node(cur) ?: break
            out.add(n)
            cur = n.parent
            guard++
        }
        out.reverse()
        return out
    }

    /** Index node for an absolute path below the scan root, or -1. */
    fun findByPath(path: String): Long {
        val rid = rootId()
        if (rid < 0L) return -1L
        val rootName = link(rid)?.name ?: return -1L
        if (path == rootName) return rid
        val prefix = rootName.trimEnd('/') + "/"
        if (!path.startsWith(prefix)) return -1L
        var cur = rid
        for (seg in path.substring(prefix.length).split('/')) {
            if (seg.isEmpty()) continue
            cur = childByName(cur, seg)
            if (cur < 0L) return -1L
        }
        return cur
    }

    // ------------------------------------------------------------------------------------------
    // History
    // ------------------------------------------------------------------------------------------

    fun addHistory(p: HistoryPoint) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO history(ts, total, used, free, scanned) VALUES(?,?,?,?,?)",
            arrayOf<Any>(p.ts, p.total, p.used, p.free, p.scanned),
        )
    }

    /** Oldest first. */
    fun history(limit: Int): List<HistoryPoint> = list(
        "SELECT ts,total,used,free,scanned FROM (SELECT * FROM history ORDER BY ts DESC LIMIT $limit) ORDER BY ts ASC"
    ) { HistoryPoint(it.getLong(0), it.getLong(1), it.getLong(2), it.getLong(3), it.getLong(4)) }

    fun clearHistory() {
        writableDatabase.execSQL("DELETE FROM history")
    }

    // ------------------------------------------------------------------------------------------
    // Duplicates
    // ------------------------------------------------------------------------------------------

    fun clearDups() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM dup_members")
            db.execSQL("DELETE FROM dup_groups")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Sizes shared by at least two files, biggest first. */
    fun dupSizeGroups(minSize: Long): List<SizeGroup> = list(
        "SELECT size, COUNT(*) FROM nodes WHERE is_dir = 0 AND size >= $minSize " +
            "GROUP BY size HAVING COUNT(*) > 1 ORDER BY size DESC"
    ) { SizeGroup(it.getLong(0), it.getInt(1)) }

    fun nodeIdsOfSize(size: Long): List<Long> =
        list("SELECT id FROM nodes WHERE is_dir = 0 AND size = $size") { it.getLong(0) }

    fun addDupGroup(size: Long, hash: String, nodeIds: List<Long>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL(
                "INSERT INTO dup_groups(size, hash, cnt) VALUES(?,?,?)",
                arrayOf<Any>(size, hash, nodeIds.size),
            )
            val gid = scalar("SELECT last_insert_rowid()")
            for (id in nodeIds) {
                db.execSQL("INSERT INTO dup_members(gid, node) VALUES($gid, $id)")
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Groups ordered by the space that deleting all but one copy would free. */
    fun dupGroups(limit: Int): List<DupGroup> = list(
        "SELECT gid, size, cnt FROM dup_groups ORDER BY (cnt - 1) * size DESC LIMIT $limit"
    ) { DupGroup(it.getLong(0), it.getLong(1), it.getInt(2)) }

    /** Members of a group, oldest first. */
    fun dupMembers(gid: Long): List<NodeRow> = list(
        "SELECT $COLS FROM nodes WHERE id IN (SELECT node FROM dup_members WHERE gid = $gid) " +
            "ORDER BY mtime ASC, id ASC"
    ) { row(it) }

    /** Number of duplicate groups and the bytes that removing every extra copy would free. */
    fun dupTotals(): Pair<Int, Long> {
        return readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM((cnt - 1) * size), 0) FROM dup_groups", null
        ).use { c -> if (c.moveToFirst()) Pair(c.getInt(0), c.getLong(1)) else Pair(0, 0L) }
    }

    // ------------------------------------------------------------------------------------------
    // Edits after the user deletes something
    // ------------------------------------------------------------------------------------------

    /** Remove a node (and everything below it) from the index and fix the totals of its ancestors. */
    fun removeNode(id: Long) {
        val n = node(id) ?: return
        val db = writableDatabase
        db.beginTransaction()
        try {
            if (n.isDir) {
                val sub = "WITH RECURSIVE sub(id) AS (SELECT $id UNION ALL " +
                    "SELECT x.id FROM nodes x JOIN sub ON x.parent = sub.id) SELECT id FROM sub"
                db.execSQL("DELETE FROM dup_members WHERE node IN ($sub)")
                db.execSQL("DELETE FROM nodes WHERE id IN ($sub)")
            } else {
                db.execSQL("DELETE FROM dup_members WHERE node = $id")
                db.execSQL("DELETE FROM nodes WHERE id = $id")
            }
            val removedFiles = if (n.isDir) n.files else 1L
            val removedDirs = if (n.isDir) n.dirs + 1L else 0L
            var p = n.parent
            var guard = 0
            while (p >= 0L && guard < 1024) {
                val next = scalar("SELECT parent FROM nodes WHERE id = $p", -1L)
                db.execSQL(
                    "UPDATE nodes SET size = MAX(size - ?, 0), files = MAX(files - ?, 0), dirs = MAX(dirs - ?, 0) WHERE id = ?",
                    arrayOf<Any>(n.size, removedFiles, removedDirs, p),
                )
                p = next
                guard++
            }
            // The "last scan" line on the overview must not keep counting what was just deleted.
            db.execSQL(
                "UPDATE scans SET files = MAX(files - ?, 0), dirs = MAX(dirs - ?, 0), bytes = MAX(bytes - ?, 0) " +
                    "WHERE id = (SELECT MAX(id) FROM scans)",
                arrayOf<Any>(removedFiles, removedDirs, n.size),
            )
            db.execSQL(
                "DELETE FROM dup_groups WHERE gid NOT IN " +
                    "(SELECT gid FROM dup_members GROUP BY gid HAVING COUNT(*) > 1)"
            )
            db.execSQL(
                "UPDATE dup_groups SET cnt = (SELECT COUNT(*) FROM dup_members m WHERE m.gid = dup_groups.gid)"
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        links.evictAll()
    }

    fun recomputeCatStats() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM cat_stats")
            db.execSQL(
                "INSERT INTO cat_stats(cat, files, bytes) " +
                    "SELECT cat, COUNT(*), SUM(size) FROM nodes WHERE is_dir = 0 GROUP BY cat"
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearScanData() {
        val db = writableDatabase
        stageStmt?.close()
        stageStmt = null
        db.beginTransaction()
        try {
            db.execSQL("DROP TABLE IF EXISTS nodes_stage")
            db.execSQL("DELETE FROM nodes")
            db.execSQL("DELETE FROM cat_stats")
            db.execSQL("DELETE FROM scans")
            db.execSQL("DELETE FROM dup_members")
            db.execSQL("DELETE FROM dup_groups")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        links.evictAll()
    }
}
