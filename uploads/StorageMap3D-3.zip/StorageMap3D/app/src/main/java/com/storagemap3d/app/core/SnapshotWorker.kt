package com.storagemap3d.app.core

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import java.util.concurrent.TimeUnit

/**
 * Records free and used space once a day so the history chart has data even between scans.
 *
 * This runs as a plain system job. WorkManager (with Room and its other dependencies) would do the
 * same for one daily task, but it adds a few hundred KB to the APK.
 */
object SnapshotWorker {
    private const val JOB_ID = 4201

    /**
     * Schedules the daily snapshot, or cancels it. A schedule that already exists is kept, so opening
     * the app does not push the next run back every time.
     */
    fun apply(context: Context, enabled: Boolean) {
        val app = context.applicationContext
        val scheduler = app.getSystemService(JobScheduler::class.java) ?: return
        try {
            if (!enabled) {
                scheduler.cancel(JOB_ID)
            } else if (scheduler.getPendingJob(JOB_ID) == null) {
                val job = JobInfo.Builder(JOB_ID, ComponentName(app, SnapshotJobService::class.java))
                    .setPeriodic(TimeUnit.DAYS.toMillis(1L))
                    .setRequiresBatteryNotLow(true)
                    .setPersisted(true)
                    .build()
                scheduler.schedule(job)
            }
        } catch (e: Exception) {
            // A missing background snapshot is not worth bothering the user about; the app also saves
            // one whenever it is opened (at most every six hours).
        }
    }

    /** Writes one history point from the current state of the storage volume. */
    fun record(context: Context) {
        val db = Db.get(context.applicationContext)
        val v = Volume.read()
        if (v.total > 0L) {
            val scanned = db.rootNode()?.size ?: 0L
            db.addHistory(HistoryPoint(System.currentTimeMillis(), v.total, v.used, v.free, scanned))
        }
    }
}

/** Started by the system for the daily job; does the work on its own thread, never the main one. */
class SnapshotJobService : JobService() {

    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            var retry = false
            try {
                SnapshotWorker.record(applicationContext)
            } catch (e: Exception) {
                retry = true
            }
            jobFinished(params, retry)
        }.start()
        return true
    }

    /** The system is stopping the job early: ask for another run later. */
    override fun onStopJob(params: JobParameters): Boolean = true
}
