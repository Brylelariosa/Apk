package com.storagemap3d.app.core

import android.content.Context

/** Small settings store (SharedPreferences). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("storagemap", Context.MODE_PRIVATE)

    /** 0 = low, 1 = balanced, 2 = detailed (how many objects the 3D map may draw). */
    var quality: Int
        get() = sp.getInt("quality", 1)
        set(v) {
            sp.edit().putInt("quality", v).apply()
        }

    var reduceMotion: Boolean
        get() = sp.getBoolean("reduce_motion", false)
        set(v) {
            sp.edit().putBoolean("reduce_motion", v).apply()
        }

    var dailySnapshot: Boolean
        get() = sp.getBoolean("daily_snapshot", true)
        set(v) {
            sp.edit().putBoolean("daily_snapshot", v).apply()
        }

    var showHidden: Boolean
        get() = sp.getBoolean("show_hidden", true)
        set(v) {
            sp.edit().putBoolean("show_hidden", v).apply()
        }

    /** Explorer sort: ordinal of SortMode (0 = name, 1 = size, 2 = date). */
    var sortMode: Int
        get() = sp.getInt("sort_mode", 0)
        set(v) {
            sp.edit().putInt("sort_mode", v).apply()
        }

    var sortAscending: Boolean
        get() = sp.getBoolean("sort_ascending", true)
        set(v) {
            sp.edit().putBoolean("sort_ascending", v).apply()
        }

    var oldMonths: Int
        get() = sp.getInt("old_months", 12)
        set(v) {
            sp.edit().putInt("old_months", v).apply()
        }

    /** Smallest file size (in KB) the duplicate finder looks at. */
    var dupMinKb: Int
        get() = sp.getInt("dup_min_kb", 100)
        set(v) {
            sp.edit().putInt("dup_min_kb", v).apply()
        }

    /** Tree URI of the folder picked with the Storage Access Framework (limited mode), if any. */
    var safTree: String?
        get() = sp.getString("saf_tree", null)
        set(v) {
            sp.edit().putString("saf_tree", v).apply()
        }

    var lastSnapshotMs: Long
        get() = sp.getLong("last_snapshot_ms", 0L)
        set(v) {
            sp.edit().putLong("last_snapshot_ms", v).apply()
        }
}
