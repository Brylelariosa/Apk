package com.storagemap3d.app.core

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.nio.file.Files

data class SafEntry(
    val docId: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val mtime: Long,
)

/** Storage Access Framework helpers for a folder the user picked (limited mode). */
object SafTree {
    private val COLUMNS = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
    )

    /** Children of a document, or null when the provider refuses to list it. */
    fun children(resolver: ContentResolver, tree: Uri, parentDocId: String): List<SafEntry>? {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        val cursor: Cursor? = try {
            resolver.query(uri, COLUMNS, null, null, null)
        } catch (e: Exception) {
            null
        }
        if (cursor == null) return null
        val out = ArrayList<SafEntry>()
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                if (id != null) {
                    val mime = c.getString(2) ?: ""
                    out.add(
                        SafEntry(
                            docId = id,
                            name = c.getString(1) ?: id,
                            isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                            size = if (c.isNull(3)) 0L else c.getLong(3),
                            mtime = if (c.isNull(4)) 0L else c.getLong(4) / 1000L,
                        )
                    )
                }
            }
        }
        return out
    }

    /** True when the document tree below [docId] contains no files at all. */
    fun hasNoFiles(resolver: ContentResolver, tree: Uri, docId: String, depth: Int = 0): Boolean {
        if (depth > 64) return false
        val kids = children(resolver, tree, docId) ?: return false
        for (k in kids) {
            if (!k.isDir) return false
            if (!hasNoFiles(resolver, tree, k.docId, depth + 1)) return false
        }
        return true
    }
}

class Listing(val entries: List<FileRef>, val truncated: Boolean, val error: String?)

/**
 * Everything that touches real files: listing, opening, sharing, deleting and hashing. In full-access
 * mode a [FileRef.key] is an absolute path; in limited mode it is a document id inside the folder the
 * user picked with the Storage Access Framework.
 */
class Backend(context: Context, private val db: Db, private val prefs: Prefs) {
    private val app: Context = context.applicationContext

    @Volatile
    private var cached: AccessMode = AccessMode.None

    init {
        refresh()
    }

    /** Re-check permissions (call when the app comes back to the foreground). */
    fun refresh(): AccessMode {
        val m = computeMode()
        cached = m
        return m
    }

    fun mode(): AccessMode = cached

    private fun computeMode(): AccessMode {
        if (Environment.isExternalStorageManager()) return AccessMode.Full
        val tree = prefs.safTree
        if (tree != null && hasGrant(tree)) return AccessMode.Saf
        return AccessMode.None
    }

    private fun hasGrant(tree: String): Boolean {
        return app.contentResolver.persistedUriPermissions.any { it.uri.toString() == tree && it.isReadPermission }
    }

    fun rootPath(): String = Environment.getExternalStorageDirectory().absolutePath

    fun treeUri(): Uri? {
        val t = prefs.safTree ?: return null
        return Uri.parse(t)
    }

    /** Remember a folder picked with the system folder picker. */
    fun adoptTree(uri: Uri) {
        try {
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (e: Exception) {
            try {
                app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e2: Exception) {
                // The grant may still work for this session.
            }
        }
        prefs.safTree = uri.toString()
        refresh()
    }

    fun forgetTree() {
        val t = prefs.safTree
        if (t != null) {
            try {
                app.contentResolver.releasePersistableUriPermission(
                    Uri.parse(t),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            } catch (e: Exception) {
                // Already released.
            }
        }
        prefs.safTree = null
        refresh()
    }

    /** Key of the folder the explorer and the scanner start from. */
    fun rootKey(): String {
        if (mode() == AccessMode.Saf) {
            val t = treeUri()
            return if (t != null) DocumentsContract.getTreeDocumentId(t) else ""
        }
        return rootPath()
    }

    fun rootLabel(): String {
        if (mode() == AccessMode.Saf) {
            val t = treeUri() ?: return "Selected folder"
            val id = DocumentsContract.getTreeDocumentId(t)
            val tail = id.substringAfter(':', id).substringAfterLast('/')
            return if (tail.isEmpty()) "Selected folder" else tail
        }
        return "Internal storage"
    }

    // ------------------------------------------------------------------------------------------
    // Listing
    // ------------------------------------------------------------------------------------------

    fun list(dirKey: String): Listing {
        return if (mode() == AccessMode.Saf) listSaf(dirKey) else listFull(dirKey)
    }

    private fun listFull(dir: String): Listing {
        if (!Native.loaded) return Listing(emptyList(), false, "The native library did not load.")
        val raw = Native.listDir(dir)
            ?: return Listing(emptyList(), false, "This folder can't be read. Android may be restricting it.")
        val dirId = db.findByPath(dir)
        val sizes: Map<String, Long> = if (dirId >= 0L) db.childDirSizes(dirId) else emptyMap()
        val prefix = if (dir.endsWith("/")) dir else "$dir/"
        val out = ArrayList<FileRef>()
        var truncated = false
        for (e in Native.decodeEntries(raw)) {
            if (e.kind == Native.KIND_TRUNCATED) {
                truncated = true
                continue
            }
            val isDir = e.kind == Native.KIND_DIR
            out.add(
                FileRef(
                    key = prefix + e.name,
                    name = e.name,
                    isDir = isDir,
                    size = if (isDir) (sizes[e.name] ?: -1L) else e.size,
                    mtime = e.mtime,
                    cat = e.cat,
                )
            )
        }
        return Listing(out, truncated, null)
    }

    private fun listSaf(docId: String): Listing {
        val tree = treeUri() ?: return Listing(emptyList(), false, "No folder selected.")
        val kids = SafTree.children(app.contentResolver, tree, docId)
            ?: return Listing(emptyList(), false, "This folder can't be read.")
        val node = db.nodeByDoc(docId)
        val sizes: Map<String, Long> = if (node != null) db.childDirSizes(node.id) else emptyMap()
        val out = ArrayList<FileRef>()
        for (k in kids) {
            val cat = if (k.isDir || !Native.loaded) 0 else Native.classify(k.name)
            out.add(
                FileRef(
                    key = k.docId,
                    name = k.name,
                    isDir = k.isDir,
                    size = if (k.isDir) (sizes[k.name] ?: -1L) else k.size,
                    mtime = k.mtime,
                    cat = cat,
                )
            )
        }
        return Listing(out, false, null)
    }

    // ------------------------------------------------------------------------------------------
    // Index rows to actionable references
    // ------------------------------------------------------------------------------------------

    fun keyOf(r: NodeRow): String = if (mode() == AccessMode.Saf) (r.doc ?: "") else db.pathOf(r.id)

    fun placeOf(r: NodeRow): String {
        val rel = db.relPathOf(r.parent)
        return if (rel.isEmpty()) rootLabel() else rel
    }

    fun refOf(r: NodeRow): FileRef = FileRef(
        key = keyOf(r),
        name = r.name,
        isDir = r.isDir,
        size = r.size,
        mtime = r.mtime,
        cat = r.cat,
        nodeId = r.id,
        place = placeOf(r),
    )

    fun nodeIdFor(ref: FileRef): Long {
        if (ref.nodeId >= 0L) return ref.nodeId
        return if (mode() == AccessMode.Saf) (db.nodeByDoc(ref.key)?.id ?: -1L) else db.findByPath(ref.key)
    }

    // ------------------------------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------------------------------

    private fun uriFor(ref: FileRef): Uri? {
        if (mode() == AccessMode.Saf) {
            val t = treeUri() ?: return null
            return DocumentsContract.buildDocumentUriUsingTree(t, ref.key)
        }
        return try {
            FileProvider.getUriForFile(app, app.packageName + ".fileprovider", File(ref.key))
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    fun mimeFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = if (ext.isEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        return mime ?: "*/*"
    }

    /** Returns an error message, or null when the viewer was launched. */
    fun open(ref: FileRef): String? {
        val uri = uriFor(ref) ?: return "This file can't be opened from here."
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(uri, mimeFor(ref.name))
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            app.startActivity(intent)
            null
        } catch (e: ActivityNotFoundException) {
            "No app on this device can open ${ref.name}."
        } catch (e: Exception) {
            e.message ?: "Couldn't open the file."
        }
    }

    /** Returns an error message, or null when the share sheet was launched. */
    fun share(ref: FileRef): String? {
        val uri = uriFor(ref) ?: return "This file can't be shared from here."
        val send = Intent(Intent.ACTION_SEND)
        send.type = mimeFor(ref.name)
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.clipData = ClipData.newRawUri(ref.name, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = Intent.createChooser(send, "Share " + ref.name)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            app.startActivity(chooser)
            null
        } catch (e: Exception) {
            e.message ?: "Couldn't open the share sheet."
        }
    }

    /** Deletes a file or folder the user confirmed, then updates the index. Returns true on success. */
    fun delete(ref: FileRef): Boolean {
        val ok: Boolean
        if (mode() == AccessMode.Saf) {
            val t = treeUri()
            ok = try {
                t != null && DocumentsContract.deleteDocument(
                    app.contentResolver,
                    DocumentsContract.buildDocumentUriUsingTree(t, ref.key),
                )
            } catch (e: Exception) {
                false
            }
        } else {
            val f = File(ref.key)
            ok = deleteTree(f)
            if (ok && !ref.isDir) {
                MediaScannerConnection.scanFile(app, arrayOf(ref.key), null, null)
            }
        }
        if (ok) afterRemoval(ref)
        return ok
    }

    /**
     * Deletes a folder only if it still contains no files (nested empty folders are fine). The check
     * is repeated against the live file system, so nothing the index does not know about is lost.
     */
    fun deleteEmptyFolder(ref: FileRef): Boolean {
        val ok: Boolean
        if (mode() == AccessMode.Saf) {
            val t = treeUri()
            ok = if (t == null) {
                false
            } else if (!SafTree.hasNoFiles(app.contentResolver, t, ref.key)) {
                false
            } else {
                try {
                    DocumentsContract.deleteDocument(
                        app.contentResolver,
                        DocumentsContract.buildDocumentUriUsingTree(t, ref.key),
                    )
                } catch (e: Exception) {
                    false
                }
            }
        } else {
            ok = deleteIfOnlyEmptyFolders(File(ref.key))
        }
        if (ok) afterRemoval(ref)
        return ok
    }

    /**
     * Drops the removed item from the index. Category totals are not touched here: a deleted folder
     * can hold files of any category, and a batch of deletions should recompute them only once, so
     * the caller does that with [Db.recomputeCatStats] after the last item.
     */
    private fun afterRemoval(ref: FileRef) {
        val id = nodeIdFor(ref)
        if (id >= 0L) db.removeNode(id)
    }

    private fun isLink(f: File): Boolean {
        return try {
            Files.isSymbolicLink(f.toPath())
        } catch (e: Exception) {
            false
        }
    }

    /** Recursive delete that never follows symbolic links. */
    private fun deleteTree(f: File): Boolean {
        if (!isLink(f) && f.isDirectory) {
            val kids = f.listFiles()
            if (kids != null) {
                for (k in kids) deleteTree(k)
            }
        }
        return f.delete()
    }

    private fun deleteIfOnlyEmptyFolders(dir: File): Boolean {
        if (isLink(dir) || !dir.isDirectory) return false
        val kids = dir.listFiles() ?: return false
        for (k in kids) {
            if (isLink(k) || !k.isDirectory) return false
            if (!deleteIfOnlyEmptyFolders(k)) return false
        }
        return dir.delete()
    }

    /** SHA-256 digest: hashMode 0 = sampled (head, middle, tail), 1 = full. Null when unreadable or cancelled. */
    fun hash(ref: FileRef, hashMode: Int): ByteArray? {
        if (!Native.loaded) return null
        if (mode() == AccessMode.Saf) {
            val t = treeUri() ?: return null
            val uri = DocumentsContract.buildDocumentUriUsingTree(t, ref.key)
            return try {
                app.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    Native.hashFd(pfd.detachFd(), hashMode)
                }
            } catch (e: Exception) {
                null
            }
        }
        return Native.hashFile(ref.key, hashMode)
    }
}
