plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Same list the CI workflow reads from gradle.properties (rustAbis=arm64-v8a,armeabi-v7a).
val rustAbis: List<String> = ((findProperty("rustAbis") as String?) ?: "arm64-v8a")
    .split(",")
    .map { it.trim() }
    .filter { it.isNotEmpty() }

android {
    namespace = "com.storagemap3d.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.storagemap3d.app"
        minSdk = 30
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"

        // The app is English only, but Compose and AndroidX ship their strings in dozens of languages.
        // resources.arsc is stored uncompressed in the APK, so every extra language costs real size.
        resourceConfigurations += listOf("en")

        // One universal APK: every ABI in rustAbis sits side by side in it. There are no ABI splits.
        ndk {
            abiFilters.addAll(rustAbis)
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    // Leave the list of dependencies out of the APK's signing block (nobody reads it on a sideloaded app).
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // Kotlin adds a null check for every parameter of every public function. They only guard against
        // callers outside Kotlin, which this app does not have, so they are just extra bytecode.
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }

    buildFeatures {
        compose = true
        buildConfig = false
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.10"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/DEPENDENCIES",
                "/META-INF/*.version",
                "/META-INF/*.kotlin_module",
                "/kotlin/**",
                "/kotlin-tooling-metadata.json",
                "/DebugProbesKt.bin",
            )
        }
        // Keep the Rust libraries compressed inside the APK (they are extracted when the app is installed).
        // The default stores them uncompressed, which makes the APK a few hundred KB larger.
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}

// Local builds (Android Studio / command line without CI): compile the Rust library with cargo-ndk first.
// The CI workflow builds it in its own step and passes -PrustPrebuilt=true, so nothing happens there.
if ((findProperty("rustPrebuilt") as String?) != "true") {
    val buildRustLibrary = tasks.register<Exec>("buildRustLibrary") {
        workingDir = rootProject.file("rust")
        val command = mutableListOf("cargo", "ndk")
        for (abi in rustAbis) {
            command.add("-t")
            command.add(abi)
        }
        command.addAll(listOf("-o", file("src/main/jniLibs").absolutePath, "build", "--release"))
        commandLine(command)
    }
    tasks.matching { it.name == "preBuild" }.configureEach {
        dependsOn(buildRustLibrary)
    }
}
