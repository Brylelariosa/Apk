# mGBA Android

Built and distributed via GitHub Actions.  
Push this ZIP to your `uploads/` folder in the repo — the workflow handles everything else.

---

## How to build

### Via GitHub Actions (normal workflow)

```
uploads/
└── mgba-android.zip   ← push this file; workflow triggers automatically
```

The workflow:
1. Extracts the ZIP, finds `settings.gradle.kts`
2. Downloads `gradle-wrapper.jar` for Gradle 8.6
3. Installs NDK 25.2.9519653 + CMake 3.22.1
4. Runs `./gradlew assembleDebug`

CMake auto-fetches the mGBA 0.10.3 source from GitHub on the first build
(via `FetchContent_Declare`).  The downloaded source lands in `app/.cxx/`
which the workflow caches, so subsequent builds skip the download entirely.

The APK is uploaded as a workflow artifact (retained 30 days).

### Locally (Android Studio)

1. Clone mGBA alongside the project:
   ```bash
   git clone --depth 1 --branch 0.10.3 https://github.com/mgba-emu/mgba.git mgba-core
   ```
   CMakeLists.txt checks for this folder first and skips the FetchContent download.

2. Open the project in Android Studio (Hedgehog+) and hit Run.

---

## Fixes applied vs the original

| File | Change |
|------|--------|
| `MainActivity.kt` | `catch (e: Throwable)` — was `Exception`, which silently missed `UnsatisfiedLinkError` |
| `MainActivity.kt` | Game loop body wrapped in try/catch; surface-recreate restarts the loop |
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` — required alongside `useLegacyPackaging=true` |
| `mgba_jni.c` | `pthread_mutex_t` guards `g_core`/`g_fb` — eliminates race with `nativeDestroy` |
| `mgba_jni.c` | `core->loadConfig(core)` replaces `mCoreLoadConfig(core)` — opts actually applied now |
| `mgba_jni.c` | Stride-correct pixel copy in `nativeRunFrame` — no more row-shift on padded bitmaps |
| `CMakeLists.txt` | FetchContent fallback auto-downloads mGBA 0.10.3 when no local clone is present |
| `CMakeLists.txt` | `--strip-debug` replaces `--strip-all`; `pthread` added to link targets |
| `app/build.gradle.kts` | Removed `-DM_CORE_GB=ON` (was a no-op; FORCE in CMakeLists always won) |
| `gradle-wrapper.properties` | Gradle 8.6 to match the workflow's hard-coded `GRADLE_VERSION="8.6"` |

### Second pass (this audit)

| File | Change |
|------|--------|
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` is now *actually* declared — the row above claimed this but the attribute was never present in the file; AGP's implicit default happened to match, but the doc/code mismatch was real |
| `MainActivity.kt` | Added `onPause()`/`onResume()` — previously absent entirely, so the emulation thread and `AudioTrack` kept running/playing after the app was backgrounded (battery drain, audio leaking behind other apps) until the `Surface` happened to be destroyed, which isn't prompt or guaranteed |
| `MainActivity.kt` | Added a persistent "📂 Change ROM" button — previously `loadRomBtn` was hidden forever after the first successful load with no other UI path to load a different game; switching titles required force-killing the app |
| `MainActivity.kt` / `LinkMultiplayer.kt` | `BLUETOOTH_CONNECT` is a runtime-dangerous permission on API 31+. It was declared in the manifest but never requested, so tapping "Host — Bluetooth", "Join — Bluetooth", or opening the paired-devices list crashed with an uncaught `SecurityException` on every Android 12+ device. Added `ensureBluetoothPermission()` + a permission launcher that requests it on demand and resumes the action once granted |

**Known residual risk (not fixed in this pass):** `nativeLoadROM()` destroys the previous native core unconditionally *before* attempting to load the new file. If a "Change ROM" attempt picks an invalid/corrupt file, the in-progress game session is already gone rather than restored. A full fix needs the native core-swap to hold the old core until the new one loads successfully — flagged here rather than silently left undocumented.

### Third pass — feature build-out (My Boy!/Pizza Boy/RetroArch-parity roadmap)

**#1 Audio — root-caused and rebuilt, not patched.** The old pipeline paced the
game loop with a fixed `Thread.sleep(1/60s)`, which doesn't match the GBA's real
59.7275 Hz refresh rate, and wrote PCM with `WRITE_NON_BLOCKING` while discarding
the return value — so the ~0.46% surplus this mismatch produced was silently
dropped by AudioTrack every few seconds (a periodic stutter, not the "no sound
at all" the brief assumed — this codebase's audio was never fully silent, just
subtly wrong). Rebuilt as an **audio-locked** loop: PCM is now written with a
genuine blocking `AudioTrack.write()`, and that blocking call *is* the frame
pacer for normal-speed play — no `Thread.sleep()` at all, so no drift can
accumulate. A short fallback sleep (using the *correct* GBA frame period, not
1/60s) only covers frames that produce zero audio. Also added: low-latency
performance mode (API 26+) with a graceful single retry if a device's audio HAL
rejects it, dead-object detection + automatic `AudioTrack` recreation, a
symmetric-channel defensive fix in `mgba_jni.c`'s blip-buffer drain, and a
`flush()` on pause so resuming after a long background period doesn't play a
blip of stale audio. Fast-forward still drops audio outright rather than
pitch-shifting it — a deliberate scope decision (see the in-code comment for
why), not an oversight.

**#2 Control layout editor — new subsystem.** Every on-screen button (D-pad ×4,
A, B, Start, Select, L, R, Fast-Forward) is now individually draggable and
resizable via a corner handle, with a per-button opacity override and lock,
live-previewed over the actual running game and persisted to SharedPreferences
as JSON. Reached from ⚙ Settings → "Edit Button Layout…". Positions are stored
as *fractions* of screen size (not raw pixels) and keyed per orientation, so
the storage format is ready for a future portrait mode even though the
activity is currently locked to landscape. Explicitly out of scope for this
pass (documented in-code rather than silently omitted): per-button rotation/
mirroring, snap-to-guides/alignment grid, and named/duplicatable layout
profiles or true per-game layouts (the latter needs a ROM-identity concept —
hash or path — this codebase doesn't have yet).
