# mGBA Android — ProGuard / R8 rules
#
# Keep all JNI-called classes and their native method declarations so R8
# does not rename or strip them.  The native side resolves methods by
# their mangled Java names at runtime; any rename → UnsatisfiedLinkError.

-keep class com.mgba.android.EmulatorEngine {
    native <methods>;
    public static final int KEY_*;
}

# Keep MainActivity so the OS can instantiate it via the manifest class name.
-keep class com.mgba.android.MainActivity { *; }

# Preserve line numbers in stack traces for production crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
