plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace  = "com.mgba.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mgba.android"
        minSdk    = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // Pin to the primary NDK the workflow installs.  Without an explicit
            // ndkVersion, AGP may pick up a stale 25.1 toolchain from the .cxx
            // cache of a previous build, which causes strtof_l redefinition
            // errors (NDK 25.1 exposes it as an inline that check_function_exists
            // misses, so mGBA compiles its own copy and clang rejects the duplicate).
            ndkVersion = "25.2.9519653"
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments(
                    "-DLIBMGBA_ONLY=ON",
                    "-DM_CORE_GBA=ON",
                    // FIX: removed "-DM_CORE_GB=ON".
                    //
                    // CMakeLists.txt uses  set(M_CORE_GB OFF CACHE BOOL "" FORCE).
                    // CMake CACHE FORCE overwrites the cache variable even when the
                    // same variable is supplied on the command line (-D flag).
                    // Passing -DM_CORE_GB=ON here therefore had no effect — the FORCE
                    // in CMakeLists.txt won unconditionally — while creating a false
                    // impression that GB/GBC support was enabled.  Removed to match
                    // actual build behaviour (GBA-only).  If GB/GBC is ever needed,
                    // remove the FORCE from CMakeLists.txt and re-add this argument.
                    "-DBUILD_STATIC=ON",
                    "-DBUILD_SHARED=OFF",
                    "-DDISABLE_FRONTENDS=ON",
                    "-DDISABLE_DEPS=ON"
                )
                // Compiler flags applied to our JNI wrapper (mgba_jni.c) and,
                // via add_subdirectory, to the mGBA core itself.
                // -Os              = optimise for size (smaller than -O2 for this workload)
                // -ffunction/data-sections + --gc-sections at link time dead-strips
                //   any mGBA code paths that our JNI bridge never calls.
                // -fvisibility=hidden hides internal symbols; JNIEXPORT overrides per-function.
                cFlags  ("-Os -ffunction-sections -fdata-sections -fvisibility=hidden")
                cppFlags("-Os -ffunction-sections -fdata-sections -fvisibility=hidden -std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled   = false  // R8 for Kotlin; native is stripped at link time
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    packaging {
        jniLibs {
            // useLegacyPackaging = true stores the .so compressed inside the APK
            // (smaller download).  This requires android:extractNativeLibs="true"
            // in AndroidManifest.xml so the system extracts the .so at install
            // time — see the comment in AndroidManifest.xml for the full
            // explanation.  AGP 7+ auto-merges that attribute into the merged
            // manifest, but we declare it explicitly in the source manifest as
            // defence-in-depth.
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
