package com.mgba.android

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * GBA Link Cable multiplayer over Wi-Fi (UDP) or Bluetooth (RFCOMM).
 *
 * Wi-Fi protocol — two UDP sockets:
 *   Port 55798  broadcast discovery  (host announces itself every 300 ms)
 *   Port 55799  SIO data exchange    (used only by the game loop thread)
 *
 * Packet layout (8 bytes):
 *   [0..1] magic  "GK"
 *   [2]    type   0=HANDSHAKE 1=DATA 2=KEEPALIVE 3=BYE
 *   [3]    seq    (uint8, wrapping — for out-of-order discard)
 *   [4..7] data   (uint32 LE — GBA SIO payload)
 *
 * jniExchangeData() is the hot path: called by the C SIO driver every time
 * the GBA game initiates a serial transfer.  It sends our data and blocks
 * until the peer replies (≤ 30 ms on local Wi-Fi, ≤ 50 ms on Bluetooth).
 * A timeout returns -1 which the driver maps to 0xFFFF (disconnected peer).
 *
 * ── BT FIX ──────────────────────────────────────────────────────────────────
 * Android's BluetoothSocket InputStream.available() always returns 0 on many
 * phones regardless of data availability. The old poll loop therefore timed
 * out on every exchange, making BT link cable completely non-functional.
 * Fix: a dedicated btReaderThread does true blocking reads and pushes 5-byte
 * frames into btReceiveQueue. btExchange() polls the queue with a deadline.
 *
 * ── Wi-Fi FIX ───────────────────────────────────────────────────────────────
 * Three root causes of Wi-Fi connection failures:
 * 1. Missing CHANGE_WIFI_MULTICAST_STATE permission (fixed in manifest).
 * 2. Sockets not setting SO_REUSEADDR — port 55799 stays in TIME_WAIT after
 *    app restart causing "address already in use" on the host side.
 * 3. Client used repeat(5) with a 3-second timeout per attempt. Host only
 *    opened a 100 ms receive window per 500 ms broadcast cycle — the two
 *    windows almost never overlapped. Fix: host uses 200 ms window per
 *    300 ms cycle; client retries every 300 ms over 15 s total.
 */
class LinkMultiplayer(private val context: Context) {

    // ── Constants ─────────────────────────────────────────────────────────

    companion object {
        private const val TAG              = "mGBA-Link"
        private const val DISC_PORT        = 55798            // discovery broadcast
        private const val DATA_PORT        = 55799            // SIO data exchange
        private const val MAGIC_G          = 'G'.code.toByte()
        private const val MAGIC_K          = 'K'.code.toByte()
        private const val TYPE_HANDSHAKE   = 0.toByte()
        private const val TYPE_DATA        = 1.toByte()
        private const val TYPE_KEEPALIVE   = 2.toByte()
        private const val TYPE_BYE         = 3.toByte()
        private const val PKT              = 8
        private const val WIFI_XCHG_MS     = 30L
        private const val BT_XCHG_MS       = 50L
        private val BT_UUID                = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val DISC_INTERVAL_MS = 300L             // host broadcast interval
        private const val HOST_RCV_MS      = 200              // host receive window per cycle
        private const val CLIENT_RETRY_MS  = 300              // client handshake retry period
        private const val HANDSHAKE_TIMEOUT = 15_000L
    }

    // ── State ─────────────────────────────────────────────────────────────

    enum class Mode { NONE, WIFI, BLUETOOTH }

    @Volatile var isConnected  = false
    @Volatile var isHost       = false
    @Volatile var mode         = Mode.NONE

    // Wi-Fi
    private var discSocket:  DatagramSocket? = null
    private var dataSocket:  DatagramSocket? = null
    private var peerAddr:    InetAddress?    = null
    private var peerDataPort = DATA_PORT
    @Volatile private var txSeq = 0

    // Bluetooth
    private var btSocket:       BluetoothSocket?       = null
    private var btServer:       BluetoothServerSocket?  = null
    private var btIn:           InputStream?            = null
    private var btOut:          OutputStream?           = null
    // FIX: dedicated reader thread + blocking queue replaces inp.available() polling
    private val btReceiveQueue  = LinkedBlockingQueue<ByteArray>()
    private var btReaderThread: Thread? = null

    // Background threads
    private var discThread:      Thread? = null
    private var keepAliveThread: Thread? = null

    // ── Wi-Fi: Host ───────────────────────────────────────────────────────

    fun startWifiHost(
        onReady:     (myIp: String) -> Unit,
        onConnected: () -> Unit,
        onError:     (String)  -> Unit
    ) {
        isHost = true
        mode   = Mode.WIFI

        try {
            // FIX: SO_REUSEADDR prevents "address already in use" on app restart
            val dataSock = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(DATA_PORT))
            }
            dataSocket = dataSock

            val myIp = localIp()
            Handler(Looper.getMainLooper()).post { onReady(myIp) }

            discThread = Thread {
                try {
                    // FIX: broadcast = true + reuseAddress on discovery socket
                    val bcast = DatagramSocket(null).apply {
                        reuseAddress = true
                        broadcast    = true
                        bind(InetSocketAddress(DISC_PORT))
                    }
                    val ann      = "MGBA_HOST $myIp".toByteArray()
                    val bcastDst = InetAddress.getByName(subnetBroadcast())
                    val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT

                    dataSock.soTimeout = HOST_RCV_MS   // 200 ms receive window per cycle

                    while (!Thread.currentThread().isInterrupted && !isConnected
                        && System.currentTimeMillis() < deadline) {

                        // Broadcast host announcement
                        try {
                            bcast.send(DatagramPacket(ann, ann.size, bcastDst, DISC_PORT))
                        } catch (_: Exception) { }

                        // Check for client handshake
                        val buf = ByteArray(PKT)
                        val pkt = DatagramPacket(buf, PKT)
                        try {
                            dataSock.receive(pkt)
                            if (isHandshake(buf)) {
                                peerAddr     = pkt.address
                                peerDataPort = pkt.port
                                sendPkt(dataSock, TYPE_HANDSHAKE, 0, 0L, pkt.address, pkt.port)
                                isConnected = true
                                startKeepalive()
                                Handler(Looper.getMainLooper()).post { onConnected() }
                            }
                        } catch (_: SocketTimeoutException) {
                            // No client yet — loop back and broadcast again after brief pause
                            val remaining = (DISC_INTERVAL_MS - HOST_RCV_MS).coerceAtLeast(50L)
                            Thread.sleep(remaining)
                        }
                    }
                    bcast.close()
                    if (!isConnected)
                        Handler(Looper.getMainLooper()).post { onError("No client connected within 15 s") }
                } catch (e: Exception) {
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "Host thread error") }
                }
            }.also { it.name = "link-host-disc"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Wi-Fi: discover hosts ─────────────────────────────────────────────

    fun discoverWifiHosts(
        onFound: (List<String>) -> Unit,
        onError: (String) -> Unit
    ) {
        val found = mutableListOf<String>()
        discThread = Thread {
            try {
                // FIX: broadcast = true so the socket can receive broadcast packets
                val sock = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast    = true
                    bind(InetSocketAddress(DISC_PORT))
                    soTimeout    = 4000
                }
                val buf = ByteArray(64)
                val pkt = DatagramPacket(buf, 64)
                val deadline = System.currentTimeMillis() + 4000L
                while (System.currentTimeMillis() < deadline) {
                    try {
                        sock.receive(pkt)
                        val msg = String(buf, 0, pkt.length)
                        if (msg.startsWith("MGBA_HOST ")) {
                            val ip = msg.removePrefix("MGBA_HOST ").trim()
                            if (ip !in found) found += ip
                        }
                    } catch (_: SocketTimeoutException) { break }
                }
                sock.close()
                Handler(Looper.getMainLooper()).post { onFound(found) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "Scan error") }
            }
        }.also { it.name = "link-disc"; it.isDaemon = true; it.start() }
    }

    // ── Wi-Fi: Client ─────────────────────────────────────────────────────

    fun connectWifi(
        hostIp:      String,
        onConnected: () -> Unit,
        onError:     (String) -> Unit
    ) {
        isHost = false
        mode   = Mode.WIFI
        try {
            // FIX: reuseAddress + shorter per-attempt timeout with continuous retry
            val sock = DatagramSocket(null).apply { reuseAddress = true }
            sock.soTimeout = CLIENT_RETRY_MS.toInt()   // 300 ms timeout per attempt
            dataSocket   = sock
            val host     = InetAddress.getByName(hostIp)
            peerAddr     = host
            peerDataPort = DATA_PORT

            Thread {
                try {
                    val buf      = ByteArray(PKT)
                    val pkt      = DatagramPacket(buf, PKT)
                    val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT

                    // FIX: retry every CLIENT_RETRY_MS instead of waiting 3 s between attempts.
                    // This ensures we hit the host's 200 ms receive window reliably.
                    while (System.currentTimeMillis() < deadline
                        && !Thread.currentThread().isInterrupted) {
                        sendPkt(sock, TYPE_HANDSHAKE, 0, 0L, host, DATA_PORT)
                        try {
                            sock.receive(pkt)
                            if (isHandshake(buf)) {
                                isConnected = true
                                startKeepalive()
                                Handler(Looper.getMainLooper()).post { onConnected() }
                                return@Thread
                            }
                        } catch (_: SocketTimeoutException) { }   // retry immediately
                    }
                    Handler(Looper.getMainLooper()).post { onError("Host not responding (15 s)") }
                } catch (e: Exception) {
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "Connect error") }
                }
            }.also { it.name = "link-client"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────

    fun getBluetoothAdapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun getBondedDevices(): List<BluetoothDevice> =
        getBluetoothAdapter()?.bondedDevices?.toList() ?: emptyList()

    fun startBluetoothHost(onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = true
        mode   = Mode.BLUETOOTH
        Thread {
            try {
                val adapter = getBluetoothAdapter() ?: throw IOException("No BT adapter")
                val server  = adapter.listenUsingInsecureRfcommWithServiceRecord("mGBA-Link", BT_UUID)
                btServer = server
                val sock   = server.accept(HANDSHAKE_TIMEOUT.toInt())
                server.close()
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                startBtReader()     // FIX: start the dedicated reader thread
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT host error") }
            }
        }.also { it.name = "link-bt-host"; it.isDaemon = true; it.start() }
    }

    fun connectBluetooth(device: BluetoothDevice, onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = false
        mode   = Mode.BLUETOOTH
        Thread {
            try {
                val sock = device.createInsecureRfcommSocketToServiceRecord(BT_UUID)
                sock.connect()
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                startBtReader()     // FIX: start the dedicated reader thread
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT connect error") }
            }
        }.also { it.name = "link-bt-client"; it.isDaemon = true; it.start() }
    }

    /**
     * FIX — BT reader thread.
     *
     * Android's BluetoothSocket InputStream.available() is broken on most phones
     * (always returns 0), so the old poll loop in btExchange() timed out on every
     * single exchange, making the link cable completely non-functional in-game.
     *
     * This thread does a true blocking read (how the stream is meant to be used)
     * and places complete 5-byte frames into btReceiveQueue. btExchange() then
     * just calls Queue.poll(timeout) — reliable and not CPU-spinning.
     */
    private fun startBtReader() {
        btReceiveQueue.clear()
        btReaderThread = Thread {
            try {
                val buf = ByteArray(5)
                while (!Thread.currentThread().isInterrupted) {
                    var n = 0
                    while (n < 5) {
                        val r = (btIn ?: return@Thread).read(buf, n, 5 - n)
                        if (r < 0) return@Thread    // stream closed
                        n += r
                    }
                    btReceiveQueue.put(buf.copyOf())
                }
            } catch (_: Exception) { /* socket closed or interrupted — exit cleanly */ }
        }.also { it.name = "link-bt-reader"; it.isDaemon = true; it.start() }
    }

    // ── jniExchangeData — HOT PATH, called from C on the game loop thread ─

    @Suppress("unused") // called from JNI via g_link_xchg_mid
    fun jniExchangeData(localData: Int): Int {
        return when (mode) {
            Mode.WIFI      -> wifiExchange(localData)
            Mode.BLUETOOTH -> btExchange(localData)
            Mode.NONE      -> -1
        }
    }

    private fun wifiExchange(localData: Int): Int {
        val sock = dataSocket ?: return -1
        val peer = peerAddr   ?: return -1
        val seq  = (txSeq++ and 0xFF).toByte()
        return try {
            sendPkt(sock, TYPE_DATA, seq.toInt(), localData.toLong(), peer, peerDataPort)
            sock.soTimeout = WIFI_XCHG_MS.toInt()
            val buf = ByteArray(PKT)
            val pkt = DatagramPacket(buf, PKT)
            sock.receive(pkt)
            if (buf[0] != MAGIC_G || buf[1] != MAGIC_K || buf[2] != TYPE_DATA) -1
            else ByteBuffer.wrap(buf, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: SocketTimeoutException) { -1 }
        catch (_: Exception)                { -1 }
    }

    private fun btExchange(localData: Int): Int {
        val out = btOut ?: return -1
        return try {
            val send = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                .put(TYPE_DATA).putInt(localData).array()
            out.write(send); out.flush()

            // FIX: poll the blocking-read queue instead of inp.available() spinning
            val recv = btReceiveQueue.poll(BT_XCHG_MS, TimeUnit.MILLISECONDS) ?: return -1
            if (recv[0] != TYPE_DATA) -1
            else ByteBuffer.wrap(recv, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: Exception) { -1 }
    }

    // ── Disconnect ────────────────────────────────────────────────────────

    fun disconnect() {
        isConnected = false
        discThread?.interrupt();      discThread = null
        keepAliveThread?.interrupt(); keepAliveThread = null
        // FIX: stop BT reader thread and drain its queue
        btReaderThread?.interrupt();  btReaderThread = null
        btReceiveQueue.clear()

        try { dataSocket?.close() }  catch (_: Exception) {}
        try { discSocket?.close() }  catch (_: Exception) {}
        try { btSocket?.close() }    catch (_: Exception) {}
        try { btServer?.close() }    catch (_: Exception) {}

        dataSocket = null; discSocket = null
        btSocket   = null; btServer   = null
        btIn = null; btOut = null
        peerAddr = null
        mode = Mode.NONE
        Log.i(TAG, "Disconnected")
    }

    // ── Keepalive (prevents UDP NAT timeout on routers) ───────────────────

    private fun startKeepalive() {
        keepAliveThread = Thread {
            while (!Thread.currentThread().isInterrupted && isConnected) {
                try {
                    val sock = dataSocket
                    val peer = peerAddr
                    if (sock != null && peer != null && mode == Mode.WIFI) {
                        sendPkt(sock, TYPE_KEEPALIVE, 0, 0L, peer, peerDataPort)
                    }
                    Thread.sleep(2000)
                } catch (_: Exception) { break }
            }
        }.also { it.name = "link-keepalive"; it.isDaemon = true; it.start() }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    fun localIp(): String {
        @Suppress("DEPRECATION")
        val wm = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val ip = wm?.connectionInfo?.ipAddress ?: 0
        if (ip == 0) return "0.0.0.0"
        return "%d.%d.%d.%d".format(ip and 0xFF, ip shr 8 and 0xFF,
            ip shr 16 and 0xFF, ip shr 24 and 0xFF)
    }

    /**
     * FIX: compute the subnet broadcast address (e.g. 192.168.43.255) instead
     * of always using 255.255.255.255. Some Android Wi-Fi drivers drop the
     * "limited broadcast" (255.255.255.255) from certain hotspot configurations.
     * The directed broadcast (subnet's last address) reaches all hosts reliably.
     */
    private fun subnetBroadcast(): String {
        @Suppress("DEPRECATION")
        val wm   = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val info = wm?.dhcpInfo ?: return "255.255.255.255"
        @Suppress("DEPRECATION")
        val ipRaw = wm.connectionInfo?.ipAddress ?: 0
        val mask  = info.netmask
        if (ipRaw == 0 || mask == 0) return "255.255.255.255"
        val bcast = (ipRaw and mask) or mask.inv()
        return "%d.%d.%d.%d".format(
            bcast and 0xFF, bcast shr 8 and 0xFF,
            bcast shr 16 and 0xFF, bcast shr 24 and 0xFF)
    }

    private fun sendPkt(
        sock: DatagramSocket, type: Byte, seq: Int, data: Long,
        addr: InetAddress, port: Int
    ) {
        val buf = ByteBuffer.allocate(PKT).order(ByteOrder.LITTLE_ENDIAN)
            .put(MAGIC_G).put(MAGIC_K)
            .put(type).put(seq.toByte())
            .putInt(data.toInt())
            .array()
        try { sock.send(DatagramPacket(buf, PKT, addr, port)) } catch (_: Exception) {}
    }

    private fun isHandshake(buf: ByteArray) =
        buf.size >= 3 && buf[0] == MAGIC_G && buf[1] == MAGIC_K && buf[2] == TYPE_HANDSHAKE
}
