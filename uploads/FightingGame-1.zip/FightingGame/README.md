# Fighting Game (prototype)

A from-scratch 2D fighting game for Android — Kotlin + Canvas/SurfaceView.
No MUGEN, no external character-file format: fighters and moves are plain
Kotlin data, so you can read and edit everything directly.

## What's in this build
- 2 fighters: **Ronin** (fast, lower damage) vs **Brawler** (slow, hard-hitting)
- Moves: light/heavy punch, light/heavy kick, block (hold back), crouch, jump
- Frame-based hitboxes/hurtboxes (startup / active / recovery per move)
- Health bars, 60s round timer, best-of-3 rounds, K.O. / Time Over / Match Over
- Basic CPU opponent (approaches, attacks, occasionally blocks) so you can test solo
- On-screen touch controls: D-pad bottom-left, 4 attack buttons bottom-right
- Landscape-locked, fullscreen, single Activity, no XML layouts needed

## Structure
| File | Responsibility |
|---|---|
| `GameModels.kt` | Intent, FighterArchetype, AttackType/AttackDef, move data table |
| `Fighter.kt` | State machine, physics, hit/hurtboxes, drawing |
| `CombatResolver.kt` | Hit detection between two fighters |
| `CpuBrain.kt` | Simple opponent AI |
| `TouchControls.kt` | On-screen button layout + multitouch handling |
| `MatchManager.kt` | Rounds, timer, win conditions, HUD |
| `GameView.kt` | Game loop (dedicated thread), draw dispatch, touch routing |
| `MainActivity.kt` | Hosts GameView fullscreen |

## Build
Drop this whole folder into your usual `uploads/` ZIP flow as-is. It's a
standard Gradle/AGP project (Gradle 8.6, AGP 8.4.0, Kotlin 2.1.10) with
**no NDK/native code** — the NDK/CMake cache-and-install steps in your
workflow will just no-op for this one since nothing references them.

Not compiled locally before handing this off (no Android SDK / network in
the sandbox this was built in) — written and reviewed carefully by hand, but
your CI run plus on-device testing is the first real compile, same as your
other projects.

## Known v1 limits (easy to extend)
- No air attacks yet — jump is movement/evasion only for now
- Fighters are simple geometric shapes, not sprites — swap in bitmaps
  inside `Fighter.draw()` whenever you have art
- No combo strings or special moves yet — `AttackTable` in `GameModels.kt`
  is the place to add them
- CPU can repeat the same move a couple of times in a row — fine for
  testing, worth tightening later if you want a tougher opponent

Package name is `com.tom.fightinggame` — rename freely.
