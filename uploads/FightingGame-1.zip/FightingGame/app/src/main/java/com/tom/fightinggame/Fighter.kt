package com.tom.fightinggame

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.max

enum class FighterState {
    IDLE, WALK_FORWARD, CROUCH, JUMP, BLOCK, BLOCK_CROUCH,
    ATTACK, HIT_STUN, KNOCKED_DOWN, ROUND_WIN, ROUND_LOSE
}

/**
 * One fighter on screen. Owns its own position, health and state machine.
 * Doesn't know about its opponent's internals — CombatResolver is the only
 * thing that connects two Fighters together.
 */
class Fighter(
    val archetype: FighterArchetype,
    startX: Float,
    val groundY: Float,
    val isPlayerOne: Boolean
) {
    var x: Float = startX
        private set
    var y: Float = groundY
        private set
    private var velocityY: Float = 0f

    var facingRight: Boolean = isPlayerOne
        private set

    var health: Int = archetype.maxHealth
        private set

    var state: FighterState = FighterState.IDLE
        private set

    private var stateFrame = 0
    private var currentAttackType: AttackType? = null
    private var currentAttackDef: AttackDef? = null
    private var hasHitThisAttack = false
    private var hitStunFramesRemaining = 0
    private var pendingIntent = Intent()
    private var lastDt = 1f / 60f

    private val bodyWidth = 70f
    private val bodyHeight = 150f
    private val crouchScale = 0.7f

    fun applyIntent(intent: Intent) {
        pendingIntent = intent
    }

    fun currentHurtbox(): RectF {
        val h = if (state == FighterState.CROUCH || state == FighterState.BLOCK_CROUCH) bodyHeight * crouchScale else bodyHeight
        val top = y - h
        return RectF(x - bodyWidth / 2f, top, x + bodyWidth / 2f, y)
    }

    fun currentHitbox(): RectF? {
        val def = currentAttackDef ?: return null
        if (state != FighterState.ATTACK) return null
        val activeStart = def.startupFrames
        val activeEnd = def.startupFrames + def.activeFrames
        if (stateFrame < activeStart || stateFrame >= activeEnd) return null
        val dir = if (facingRight) 1f else -1f
        val centerX = x + dir * def.hitboxForwardOffset
        val centerY = y - bodyHeight * 0.5f
        return RectF(
            centerX - def.hitboxWidth / 2f,
            centerY - def.hitboxHeight / 2f,
            centerX + def.hitboxWidth / 2f,
            centerY + def.hitboxHeight / 2f
        )
    }

    fun canRegisterHit(): Boolean = state == FighterState.ATTACK && !hasHitThisAttack

    fun markHitRegistered() {
        hasHitThisAttack = true
    }

    fun currentAttackDefOrNull(): AttackDef? = currentAttackDef

    /** Called on this fighter when an opponent's attack connects. */
    fun receiveHit(def: AttackDef, attackerFacingRight: Boolean) {
        val blocking = state == FighterState.BLOCK || state == FighterState.BLOCK_CROUCH
        val pushDir = if (attackerFacingRight) 1f else -1f

        if (blocking) {
            health = max(0, health - (def.damage / 10))
            hitStunFramesRemaining = def.blockStunFrames
            x += pushDir * (def.knockback * 0.3f)
        } else {
            health = max(0, health - def.damage)
            hitStunFramesRemaining = def.hitStunFrames
            x += pushDir * def.knockback
        }

        state = FighterState.HIT_STUN
        stateFrame = 0
        currentAttackType = null
        currentAttackDef = null
    }

    fun update(dt: Float, opponent: Fighter) {
        lastDt = dt

        val canAutoFace = state != FighterState.ATTACK && state != FighterState.HIT_STUN &&
            state != FighterState.KNOCKED_DOWN && state != FighterState.ROUND_WIN && state != FighterState.ROUND_LOSE
        if (canAutoFace) {
            facingRight = opponent.x >= x
        }

        stateFrame++

        when (state) {
            FighterState.HIT_STUN -> {
                hitStunFramesRemaining--
                if (hitStunFramesRemaining <= 0) {
                    state = FighterState.IDLE
                    stateFrame = 0
                }
            }
            FighterState.ATTACK -> {
                val def = currentAttackDef
                if (def != null) {
                    val totalFrames = def.startupFrames + def.activeFrames + def.recoveryFrames
                    if (stateFrame >= totalFrames) {
                        state = FighterState.IDLE
                        stateFrame = 0
                        currentAttackType = null
                        currentAttackDef = null
                    }
                }
            }
            FighterState.JUMP -> {
                velocityY += GRAVITY * dt
                y += velocityY * dt
                if (y >= groundY) {
                    y = groundY
                    velocityY = 0f
                    state = FighterState.IDLE
                    stateFrame = 0
                }
            }
            FighterState.KNOCKED_DOWN, FighterState.ROUND_WIN, FighterState.ROUND_LOSE -> {
                // No input handling here — MatchManager drives transitions out of these.
            }
            else -> handleGroundedState()
        }
    }

    private fun handleGroundedState() {
        if (handleAttackInput()) return

        val intent = pendingIntent
        val holdingBack = if (facingRight) intent.left else intent.right
        val holdingForward = if (facingRight) intent.right else intent.left

        when {
            intent.up -> {
                state = FighterState.JUMP
                stateFrame = 0
                velocityY = -archetype.jumpVelocity
            }
            intent.down && holdingBack -> {
                state = FighterState.BLOCK_CROUCH
                stateFrame = 0
            }
            intent.down -> {
                state = FighterState.CROUCH
                stateFrame = 0
            }
            holdingBack -> {
                state = FighterState.BLOCK
                stateFrame = 0
            }
            holdingForward -> {
                state = FighterState.WALK_FORWARD
                stateFrame = 0
                x += (if (facingRight) 1f else -1f) * archetype.walkSpeed * lastDt
            }
            else -> {
                state = FighterState.IDLE
                stateFrame = 0
            }
        }
    }

    /** Returns true if a new attack was started this frame (no air attacks in v1). */
    private fun handleAttackInput(): Boolean {
        val intent = pendingIntent
        val type = when {
            intent.heavyPunch -> AttackType.HEAVY_PUNCH
            intent.lightPunch -> AttackType.LIGHT_PUNCH
            intent.heavyKick -> AttackType.HEAVY_KICK
            intent.lightKick -> AttackType.LIGHT_KICK
            else -> null
        } ?: return false

        currentAttackType = type
        currentAttackDef = AttackTable.get(archetype, type)
        state = FighterState.ATTACK
        stateFrame = 0
        hasHitThisAttack = false
        return true
    }

    fun resetForNewRound(startX: Float) {
        x = startX
        y = groundY
        velocityY = 0f
        health = archetype.maxHealth
        state = FighterState.IDLE
        stateFrame = 0
        currentAttackType = null
        currentAttackDef = null
        hasHitThisAttack = false
        facingRight = isPlayerOne
    }

    fun draw(canvas: Canvas) {
        val paint = Paint()
        val h = if (state == FighterState.CROUCH || state == FighterState.BLOCK_CROUCH) bodyHeight * crouchScale else bodyHeight
        val top = y - h
        val headRadius = bodyWidth * 0.35f
        val headCenterY = top - headRadius * 0.2f

        paint.color = archetype.colorBody
        canvas.drawRect(x - bodyWidth / 2f, top, x + bodyWidth / 2f, y, paint)

        paint.color = archetype.colorAccent
        canvas.drawCircle(x, headCenterY, headRadius, paint)

        if (state == FighterState.ATTACK) {
            val def = currentAttackDef
            if (def != null) {
                val activeStart = def.startupFrames
                val activeEnd = def.startupFrames + def.activeFrames
                if (stateFrame in activeStart until activeEnd) {
                    val dir = if (facingRight) 1f else -1f
                    paint.color = Color.YELLOW
                    val armY = top + h * 0.35f
                    val armTipX = x + dir * def.hitboxForwardOffset
                    canvas.drawRect(
                        minOf(x, armTipX), armY - 10f,
                        maxOf(x, armTipX), armY + 10f,
                        paint
                    )
                }
            }
        }

        if (state == FighterState.BLOCK || state == FighterState.BLOCK_CROUCH) {
            paint.color = Color.rgb(120, 170, 255)
            val dir = if (facingRight) 1f else -1f
            val edgeX = x + dir * bodyWidth / 2f
            val outerX = edgeX + dir * 10f
            canvas.drawRect(minOf(edgeX, outerX), top, maxOf(edgeX, outerX), y, paint)
        }

        paint.color = Color.WHITE
        val faceDir = if (facingRight) 1f else -1f
        canvas.drawCircle(x + faceDir * (bodyWidth * 0.3f), headCenterY, 6f, paint)
    }

    companion object {
        const val GRAVITY = 2200f
    }
}
