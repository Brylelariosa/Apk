package com.tom.fightinggame

import android.graphics.RectF

/**
 * Checks one attacker's active hitbox against one defender's hurtbox.
 * Call once per (attacker, defender) ordered pair, each frame.
 */
object CombatResolver {
    fun resolve(attacker: Fighter, defender: Fighter) {
        if (!attacker.canRegisterHit()) return
        val hitbox = attacker.currentHitbox() ?: return
        val hurtbox = defender.currentHurtbox()

        if (RectF.intersects(hitbox, hurtbox)) {
            val def = attacker.currentAttackDefOrNull() ?: return
            defender.receiveHit(def, attackerFacingRight = attacker.facingRight)
            attacker.markHitRegistered()
        }
    }
}
