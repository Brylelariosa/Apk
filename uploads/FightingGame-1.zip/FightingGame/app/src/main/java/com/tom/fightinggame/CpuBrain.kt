package com.tom.fightinggame

import kotlin.math.abs
import kotlin.random.Random

/**
 * A simple reactive opponent: closes distance, throws attacks with some
 * randomness once in range, and occasionally holds block. Not meant to be
 * "smart" — just enough of a pulse to test combat against, solo, on device.
 */
class CpuBrain {
    private var decisionCooldown = 0f
    private var currentIntent = Intent()

    fun decide(cpu: Fighter, player: Fighter, dt: Float): Intent {
        decisionCooldown -= dt
        if (decisionCooldown > 0f) return currentIntent

        decisionCooldown = 0.22f + Random.nextFloat() * 0.35f

        val distance = abs(player.x - cpu.x)
        val attackRange = 95f

        currentIntent = when {
            distance > attackRange * 1.6f -> {
                if (player.x > cpu.x) Intent(right = true) else Intent(left = true)
            }
            distance > attackRange -> {
                if (Random.nextFloat() < 0.35f) {
                    if (player.x > cpu.x) Intent(right = true) else Intent(left = true)
                } else {
                    Intent()
                }
            }
            else -> {
                val roll = Random.nextFloat()
                when {
                    roll < 0.30f -> Intent(lightPunch = true)
                    roll < 0.50f -> Intent(lightKick = true)
                    roll < 0.65f -> Intent(heavyPunch = true)
                    roll < 0.75f -> Intent(heavyKick = true)
                    roll < 0.90f -> {
                        val holdBackLeft = player.x >= cpu.x
                        Intent(left = holdBackLeft, right = !holdBackLeft)
                    }
                    else -> Intent()
                }
            }
        }
        return currentIntent
    }
}
