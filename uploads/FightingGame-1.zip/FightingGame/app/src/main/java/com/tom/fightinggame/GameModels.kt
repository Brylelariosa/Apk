package com.tom.fightinggame

import android.graphics.Color

/**
 * Snapshot of "what buttons are currently held" for one fighter, for one frame.
 */
data class Intent(
    val left: Boolean = false,
    val right: Boolean = false,
    val up: Boolean = false,
    val down: Boolean = false,
    val lightPunch: Boolean = false,
    val heavyPunch: Boolean = false,
    val lightKick: Boolean = false,
    val heavyKick: Boolean = false
)

/**
 * A selectable fighter type. Add more entries here to add more characters —
 * everything else (state machine, rendering, AI) reads from this table.
 */
enum class FighterArchetype(
    val displayName: String,
    val maxHealth: Int,
    val walkSpeed: Float,
    val jumpVelocity: Float,
    val colorBody: Int,
    val colorAccent: Int
) {
    RONIN("Ronin", 100, 240f, 900f, Color.rgb(200, 60, 60), Color.rgb(240, 200, 80)),
    BRAWLER("Brawler", 120, 170f, 820f, Color.rgb(60, 90, 200), Color.rgb(220, 220, 220))
}

enum class AttackType { LIGHT_PUNCH, HEAVY_PUNCH, LIGHT_KICK, HEAVY_KICK }

/**
 * Frame data for a single move. Frame counts are at ~60 updates/second.
 */
data class AttackDef(
    val damage: Int,
    val startupFrames: Int,
    val activeFrames: Int,
    val recoveryFrames: Int,
    val hitStunFrames: Int,
    val blockStunFrames: Int,
    val knockback: Float,
    val hitboxWidth: Float,
    val hitboxHeight: Float,
    val hitboxForwardOffset: Float
)

/**
 * Move data per archetype. This is the file to edit when tuning balance or
 * adding new moves — nothing elsewhere needs to change.
 */
object AttackTable {
    fun get(archetype: FighterArchetype, type: AttackType): AttackDef = when (archetype) {
        FighterArchetype.RONIN -> when (type) {
            AttackType.LIGHT_PUNCH -> AttackDef(4, 4, 3, 8, 14, 6, 10f, 60f, 50f, 50f)
            AttackType.HEAVY_PUNCH -> AttackDef(10, 10, 4, 16, 22, 10, 28f, 70f, 55f, 55f)
            AttackType.LIGHT_KICK -> AttackDef(5, 6, 3, 10, 16, 7, 14f, 65f, 45f, 55f)
            AttackType.HEAVY_KICK -> AttackDef(12, 12, 4, 18, 24, 11, 32f, 75f, 50f, 60f)
        }
        FighterArchetype.BRAWLER -> when (type) {
            AttackType.LIGHT_PUNCH -> AttackDef(5, 5, 3, 9, 15, 6, 12f, 65f, 55f, 55f)
            AttackType.HEAVY_PUNCH -> AttackDef(14, 13, 4, 20, 26, 12, 34f, 80f, 60f, 60f)
            AttackType.LIGHT_KICK -> AttackDef(6, 7, 3, 11, 17, 7, 16f, 70f, 50f, 58f)
            AttackType.HEAVY_KICK -> AttackDef(15, 14, 4, 22, 27, 12, 36f, 80f, 55f, 62f)
        }
    }
}
