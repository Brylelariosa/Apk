package com.tom.fightinggame

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent

private enum class ButtonId { LEFT, RIGHT, UP, DOWN, LP, HP, LK, HK }

/**
 * Renders and reads the on-screen D-pad + attack buttons. Tracks each
 * touch pointer independently so movement and an attack can be held
 * down at the same time.
 */
class TouchControls(private val screenWidth: Int, private val screenHeight: Int) {

    private val buttonRadius = minOf(screenWidth, screenHeight) * 0.09f

    private val padCenterX = screenWidth * 0.14f
    private val padCenterY = screenHeight * 0.68f
    private val padSpacing = buttonRadius * 1.25f

    private val btnLeft = circleRect(padCenterX - padSpacing, padCenterY)
    private val btnRight = circleRect(padCenterX + padSpacing, padCenterY)
    private val btnUp = circleRect(padCenterX, padCenterY - padSpacing)
    private val btnDown = circleRect(padCenterX, padCenterY + padSpacing)

    private val atkCenterX = screenWidth * 0.86f
    private val atkCenterY = screenHeight * 0.66f
    private val atkSpacing = buttonRadius * 1.35f

    private val btnLightPunch = circleRect(atkCenterX - atkSpacing, atkCenterY - atkSpacing * 0.6f)
    private val btnHeavyPunch = circleRect(atkCenterX + atkSpacing, atkCenterY - atkSpacing * 0.6f)
    private val btnLightKick = circleRect(atkCenterX - atkSpacing, atkCenterY + atkSpacing * 0.6f)
    private val btnHeavyKick = circleRect(atkCenterX + atkSpacing, atkCenterY + atkSpacing * 0.6f)

    private val activePointers = mutableMapOf<Int, ButtonId>()
    private var current = Intent()
    @Volatile private var restartFlag = false

    private fun circleRect(cx: Float, cy: Float): RectF =
        RectF(cx - buttonRadius, cy - buttonRadius, cx + buttonRadius, cy + buttonRadius)

    private fun buttonAt(px: Float, py: Float): ButtonId? = when {
        btnLeft.contains(px, py) -> ButtonId.LEFT
        btnRight.contains(px, py) -> ButtonId.RIGHT
        btnUp.contains(px, py) -> ButtonId.UP
        btnDown.contains(px, py) -> ButtonId.DOWN
        btnLightPunch.contains(px, py) -> ButtonId.LP
        btnHeavyPunch.contains(px, py) -> ButtonId.HP
        btnLightKick.contains(px, py) -> ButtonId.LK
        btnHeavyKick.contains(px, py) -> ButtonId.HK
        else -> null
    }

    fun onTouchEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val index = event.actionIndex
                val id = event.getPointerId(index)
                val btn = buttonAt(event.getX(index), event.getY(index))
                if (btn != null) {
                    activePointers[id] = btn
                }
                restartFlag = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val index = event.actionIndex
                val id = event.getPointerId(index)
                activePointers.remove(id)
            }
        }
        recomputeIntent()
    }

    private fun recomputeIntent() {
        val pressed = activePointers.values.toSet()
        current = Intent(
            left = ButtonId.LEFT in pressed,
            right = ButtonId.RIGHT in pressed,
            up = ButtonId.UP in pressed,
            down = ButtonId.DOWN in pressed,
            lightPunch = ButtonId.LP in pressed,
            heavyPunch = ButtonId.HP in pressed,
            lightKick = ButtonId.LK in pressed,
            heavyKick = ButtonId.HK in pressed
        )
    }

    fun currentIntent(): Intent = current

    /** One-shot flag, drained every frame regardless of game state. */
    fun consumeRestartTap(): Boolean {
        val r = restartFlag
        restartFlag = false
        return r
    }

    fun draw(canvas: Canvas) {
        val dim = Paint().apply { color = Color.argb(80, 255, 255, 255) }
        val atk = Paint().apply { color = Color.argb(80, 255, 190, 110) }
        val label = Paint().apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = buttonRadius * 0.6f
        }

        drawButton(canvas, btnLeft, "\u25C0", dim, label)
        drawButton(canvas, btnRight, "\u25B6", dim, label)
        drawButton(canvas, btnUp, "\u25B2", dim, label)
        drawButton(canvas, btnDown, "\u25BC", dim, label)
        drawButton(canvas, btnLightPunch, "LP", atk, label)
        drawButton(canvas, btnHeavyPunch, "HP", atk, label)
        drawButton(canvas, btnLightKick, "LK", atk, label)
        drawButton(canvas, btnHeavyKick, "HK", atk, label)
    }

    private fun drawButton(canvas: Canvas, rect: RectF, text: String, bg: Paint, label: Paint) {
        canvas.drawOval(rect, bg)
        canvas.drawText(text, rect.centerX(), rect.centerY() + label.textSize / 3f, label)
    }
}
