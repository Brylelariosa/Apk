package com.tom.fightinggame

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.ceil

enum class MatchState { ROUND_INTRO, FIGHTING, ROUND_END, MATCH_OVER }

/**
 * Owns everything about a match that isn't "one fighter's own state":
 * round timer, round wins, transitions between rounds, and the HUD.
 */
class MatchManager(
    private val player: Fighter,
    private val cpu: Fighter,
    private val playerStartX: Float,
    private val cpuStartX: Float
) {
    var state = MatchState.ROUND_INTRO
        private set

    private var roundTimer = ROUND_SECONDS
    private var stateTimer = 0f
    private var playerRoundWins = 0
    private var cpuRoundWins = 0
    private var roundNumber = 1
    private var roundEndMessage = ""
    private var matchEndMessage = ""

    fun update(dt: Float) {
        stateTimer += dt
        when (state) {
            MatchState.ROUND_INTRO -> {
                if (stateTimer >= 1.5f) {
                    state = MatchState.FIGHTING
                    stateTimer = 0f
                }
            }
            MatchState.FIGHTING -> {
                roundTimer -= dt
                if (player.health <= 0 || cpu.health <= 0 || roundTimer <= 0f) {
                    endRound()
                }
            }
            MatchState.ROUND_END -> {
                if (stateTimer >= 2f) {
                    if (playerRoundWins >= ROUNDS_TO_WIN || cpuRoundWins >= ROUNDS_TO_WIN) {
                        state = MatchState.MATCH_OVER
                        matchEndMessage = if (playerRoundWins > cpuRoundWins) "YOU WIN THE MATCH!" else "CPU WINS THE MATCH"
                    } else {
                        roundNumber++
                        startRound()
                    }
                    stateTimer = 0f
                }
            }
            MatchState.MATCH_OVER -> {
                // Waiting for a restart tap, handled by GameView.
            }
        }
    }

    private fun endRound() {
        state = MatchState.ROUND_END
        stateTimer = 0f
        when {
            player.health <= 0 && cpu.health <= 0 -> {
                roundEndMessage = "DOUBLE K.O."
            }
            player.health <= 0 -> {
                cpuRoundWins++
                roundEndMessage = "K.O.!"
            }
            cpu.health <= 0 -> {
                playerRoundWins++
                roundEndMessage = "K.O.!"
            }
            player.health > cpu.health -> {
                playerRoundWins++
                roundEndMessage = "TIME OVER"
            }
            cpu.health > player.health -> {
                cpuRoundWins++
                roundEndMessage = "TIME OVER"
            }
            else -> {
                roundEndMessage = "DRAW"
            }
        }
    }

    private fun startRound() {
        roundTimer = ROUND_SECONDS
        player.resetForNewRound(playerStartX)
        cpu.resetForNewRound(cpuStartX)
        state = MatchState.ROUND_INTRO
    }

    fun drawHud(canvas: Canvas, screenWidth: Int, screenHeight: Int) {
        drawHealthBar(canvas, player, isLeft = true, screenWidth)
        drawHealthBar(canvas, cpu, isLeft = false, screenWidth)
        drawRoundPips(canvas, playerRoundWins, screenWidth * 0.08f, screenHeight * 0.12f, growRight = true)
        drawRoundPips(canvas, cpuRoundWins, screenWidth * 0.92f, screenHeight * 0.12f, growRight = false)

        val timerPaint = Paint().apply {
            color = Color.WHITE
            textSize = screenHeight * 0.07f
            textAlign = Paint.Align.CENTER
        }
        val secondsLeft = ceil(roundTimer.coerceAtLeast(0f)).toInt()
        canvas.drawText(secondsLeft.toString(), screenWidth / 2f, screenHeight * 0.09f, timerPaint)

        val bigTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = screenHeight * 0.09f
            textAlign = Paint.Align.CENTER
        }
        when (state) {
            MatchState.ROUND_INTRO -> canvas.drawText("ROUND $roundNumber", screenWidth / 2f, screenHeight * 0.4f, bigTextPaint)
            MatchState.ROUND_END -> canvas.drawText(roundEndMessage, screenWidth / 2f, screenHeight * 0.4f, bigTextPaint)
            MatchState.MATCH_OVER -> {
                canvas.drawText(matchEndMessage, screenWidth / 2f, screenHeight * 0.4f, bigTextPaint)
                val subPaint = Paint().apply {
                    color = Color.LTGRAY
                    textSize = screenHeight * 0.045f
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("Tap to play again", screenWidth / 2f, screenHeight * 0.5f, subPaint)
            }
            else -> {
            }
        }
    }

    private fun drawHealthBar(canvas: Canvas, fighter: Fighter, isLeft: Boolean, screenWidth: Int) {
        val barWidth = screenWidth * 0.38f
        val barHeight = 34f
        val x = if (isLeft) screenWidth * 0.04f else screenWidth * 0.96f - barWidth
        val y = 40f

        val bg = Paint().apply { color = Color.rgb(40, 40, 40) }
        canvas.drawRect(x, y, x + barWidth, y + barHeight, bg)

        val pct = (fighter.health.toFloat() / fighter.archetype.maxHealth.toFloat()).coerceIn(0f, 1f)
        val fillColor = when {
            pct > 0.5f -> Color.rgb(80, 200, 90)
            pct > 0.25f -> Color.rgb(230, 200, 60)
            else -> Color.rgb(220, 60, 60)
        }
        val fillPaint = Paint().apply { color = fillColor }
        val fillWidth = barWidth * pct
        if (isLeft) {
            canvas.drawRect(x, y, x + fillWidth, y + barHeight, fillPaint)
        } else {
            canvas.drawRect(x + barWidth - fillWidth, y, x + barWidth, y + barHeight, fillPaint)
        }
    }

    private fun drawRoundPips(canvas: Canvas, wins: Int, startX: Float, yPos: Float, growRight: Boolean) {
        val paint = Paint()
        for (i in 0 until ROUNDS_TO_WIN) {
            paint.color = if (i < wins) Color.rgb(240, 210, 60) else Color.rgb(70, 70, 70)
            val cx = if (growRight) startX + i * 26f else startX - i * 26f
            canvas.drawCircle(cx, yPos, 9f, paint)
        }
    }

    companion object {
        const val ROUND_SECONDS = 60f
        const val ROUNDS_TO_WIN = 2
    }
}
