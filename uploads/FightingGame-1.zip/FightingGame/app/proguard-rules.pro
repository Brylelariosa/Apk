# Nothing to keep here on purpose.
#
# MainActivity is referenced from AndroidManifest.xml, so AGP's automatic
# manifest-component keep rules already protect it — no -keep needed.
#
# Everything else (Fighter, GameView, MatchManager, TouchControls, CpuBrain,
# CombatResolver, GameModels) is plain Kotlin: no reflection, no annotation
# processing, no JSON/serialization, no DI framework. R8 can safely shrink
# and rename all of it.
#
# If you add a library later that uses reflection (Gson, Retrofit, Room,
# Hilt, etc.), add its recommended -keep rules here — most of those
# libraries ship a consumer-rules.pro that handles this automatically.
