package com.browser.app

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * WebView subclass that:
 *  1. Exposes onScrollChanged as a callback for MainActivity.
 *  2. Fixes the immersive-mode keyboard bug by requesting IME in
 *     onCreateInputConnection — the earliest reliable moment, right after
 *     the system has set up the input connection for a focused web input.
 */
class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    /**
     * Called by the IME framework when a text input inside the WebView gains
     * focus. In immersive/full-screen mode the OS never shows the keyboard
     * automatically, so we must request it explicitly here.
     *
     * This is the correct hook: the InputConnection is live, the WebView is
     * already focused as a text editor, and the window has input focus.
     * Using WindowInsetsControllerCompat.show(ime()) is the only method that
     * works reliably in immersive mode (showSoftInput is ignored there).
     */
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        if (ic != null) {
            post {
                val activity = context as? Activity ?: return@post
                WindowInsetsControllerCompat(activity.window, this)
                    .show(WindowInsetsCompat.Type.ime())
            }
        }
        return ic
    }
}
