package com.game.topdown;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Manages and renders all visual-only particle / FX effects.
 *
 * Owned by GameView. Call draw() inside the world-space canvas transform
 * (after scale + translate, before restore).
 */
class EffectsManager {

    // ── Lifetimes ─────────────────────────────────────────────────────────────
    static final long GHOST_LIFE_MS   = 420;
    static final long DASH_ANIM_MS    = 160;

    // ── Epoch reference for float-safe timestamps ──────────────────────────────
    // System.currentTimeMillis() is ~1.7 trillion ms — too large for float (ULP ≈ 131 s).
    // Store (absoluteMs - FX_EPOCH) instead; values stay < 16M ms → float ULP = 1 ms.
    static final long FX_EPOCH = System.currentTimeMillis();

    // ── Explosion rings  [x, y, spawnMs] ─────────────────────────────────────
    final List<long[]>  explosionFx    = new ArrayList<>();

    // ── Client-side bullet hit flash  [x, y, spawnMs] ─────────────────────────
    final List<long[]>  predictedHitFx = new ArrayList<>();

    // ── Shadow Blade slash arc trails  [cx, cy, r, spawnMs, angle, slot] ──────
    final List<float[]> slashTrails    = new ArrayList<>();

    // ── Shadow Blade crescent effect  [cx, cy, angle, spawnMs] ───────────────
    final List<float[]> crescentFx     = new ArrayList<>();

    // ── Local player dash ghost afterimages  [x, y, spawnMs] ─────────────────
    final List<float[]> dashGhosts     = new ArrayList<>();

    // ── Bot dash ghost afterimages  [x, y, spawnMs] ───────────────────────────
    final List<float[]> botDashGhosts  = new ArrayList<>();

    // ── Local player dash animation ───────────────────────────────────────────
    boolean dashAnimating;
    float   dashAnimStartX, dashAnimStartY;
    float   dashAnimEndX,   dashAnimEndY;
    long    dashAnimBegin;

    // ═════════════════════════════════════════════════════════════════════════
    // Spawn helpers
    // ═════════════════════════════════════════════════════════════════════════

    void spawnExplosion(float x, float y) {
        explosionFx.add(new long[]{ (long) x, (long) y, System.currentTimeMillis() });
    }

    void spawnHitFlash(float x, float y) {
        predictedHitFx.add(new long[]{ (long) x, (long) y, System.currentTimeMillis() });
    }

    void spawnCrescent(float x, float y, float angle) {
        crescentFx.add(new float[]{ x, y, angle, (float)(System.currentTimeMillis() - FX_EPOCH) });
    }

    void spawnDashGhost(float x, float y) {
        dashGhosts.add(new float[]{ x, y, (float)(System.currentTimeMillis() - FX_EPOCH) });
    }

    void spawnBotDashGhosts(float fromX, float fromY, float toX, float toY) {
        int numGhosts = 3;
        float dx = toX - fromX, dy = toY - fromY;
        long nowRel = System.currentTimeMillis() - FX_EPOCH;
        for (int i = 0; i <= numGhosts; i++) {
            float t = (float) i / numGhosts;
            botDashGhosts.add(new float[]{
                fromX + dx * t,
                fromY + dy * t,
                (float)(nowRel - (long)(t * 60f))
            });
        }
    }

    void beginDash(float startX, float startY, float endX, float endY) {
        dashAnimStartX = startX; dashAnimStartY = startY;
        dashAnimEndX   = endX;   dashAnimEndY   = endY;
        dashAnimBegin  = System.currentTimeMillis();
        dashAnimating  = true;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Draw — call once per frame inside world-space canvas transform
    // ═════════════════════════════════════════════════════════════════════════

    /** Call BEFORE drawing players — explosions, hit flashes, dash ghost trails. */
    void drawBehindPlayers(Canvas c) {
        drawExplosions(c);
        drawHitFlashes(c);
        drawSlashTrails(c);
        drawDashGhosts(c);
        drawBotDashGhosts(c);
    }

    /** Call AFTER drawing players — crescent appears on top of the player body. */
    void drawInFrontOfPlayers(Canvas c) {
        drawCrescents(c);
    }

    /** Legacy all-in-one call (kept for compatibility). */
    void draw(Canvas c) {
        drawBehindPlayers(c);
        drawInFrontOfPlayers(c);
    }

    // ── Explosion rings ───────────────────────────────────────────────────────
    private void drawExplosions(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<long[]> it = explosionFx.iterator();
        while (it.hasNext()) {
            long[] fx = it.next();
            float age = (now - fx[2]) / 400f;
            if (age >= 1f) { it.remove(); continue; }
            float r = 120f * age;
            int alpha = (int)((1f - age) * 200);
            Paint ep = new Paint(Paint.ANTI_ALIAS_FLAG);
            ep.setStyle(Paint.Style.FILL);
            ep.setColor(Color.argb(alpha, 255, 200, 50));
            c.drawCircle(fx[0], fx[1], r, ep);
            Paint ep2 = new Paint(Paint.ANTI_ALIAS_FLAG);
            ep2.setStyle(Paint.Style.FILL);
            ep2.setColor(Color.argb(alpha / 2, 255, 100, 0));
            c.drawCircle(fx[0], fx[1], r * 0.5f, ep2);
        }
    }

    // ── Client-side bullet hit flash ──────────────────────────────────────────
    private void drawHitFlashes(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<long[]> it = predictedHitFx.iterator();
        while (it.hasNext()) {
            long[] ph = it.next();
            float age = (now - ph[2]) / 180f;
            if (age >= 1f) { it.remove(); continue; }
            float r = GameView.PR * (0.6f + age * 0.8f);
            int alpha = (int)((1f - age) * 220);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 255, 255, 255));
            c.drawCircle(ph[0], ph[1], r, p);
        }
    }

    // ── Shadow Blade slash arc trails ─────────────────────────────────────────
    private void drawSlashTrails(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<float[]> it = slashTrails.iterator();
        while (it.hasNext()) {
            float[] st = it.next();
            long age = now - (long) st[3];
            final long SLASH_LIFE = 420L;
            if (age > SLASH_LIFE) { it.remove(); continue; }
            float frac = 1f - (float) age / SLASH_LIFE;
            float easedFrac = frac * frac;

            float cx = st[0], cy = st[1], r = st[2];
            float slashAngle = st[4];
            int slot = (int) st[5];
            float sweepDeg = 110f;
            float startDeg = (float) Math.toDegrees(slashAngle) - sweepDeg * 0.5f;
            RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);

            if (slot == 0) {
                Paint haloP = new Paint(Paint.ANTI_ALIAS_FLAG);
                haloP.setStyle(Paint.Style.STROKE);
                haloP.setStrokeWidth(26f * frac);
                haloP.setColor(Color.argb((int)(55 * easedFrac), 180, 0, 255));
                c.drawArc(oval, startDeg, sweepDeg, false, haloP);

                Paint midP = new Paint(Paint.ANTI_ALIAS_FLAG);
                midP.setStyle(Paint.Style.STROKE);
                midP.setStrokeWidth(10f * frac);
                midP.setColor(Color.argb((int)(160 * frac), 255, 60, 200));
                c.drawArc(oval, startDeg, sweepDeg, false, midP);

                Paint coreP = new Paint(Paint.ANTI_ALIAS_FLAG);
                coreP.setStyle(Paint.Style.STROKE);
                coreP.setStrokeWidth(4f * frac);
                coreP.setColor(Color.argb((int)(255 * frac), 255, 220, 255));
                c.drawArc(oval, startDeg, sweepDeg, false, coreP);

                if (age < 180L) {
                    float bf = 1f - age / 180f;
                    float tipX = cx + (float) Math.cos(slashAngle) * r;
                    float tipY = cy + (float) Math.sin(slashAngle) * r;
                    Paint burstP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    burstP.setStyle(Paint.Style.FILL);
                    burstP.setColor(Color.argb((int)(200 * bf), 255, 180, 255));
                    c.drawCircle(tipX, tipY, 20f * bf, burstP);
                    Paint sparkP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    sparkP.setStyle(Paint.Style.STROKE);
                    sparkP.setStrokeWidth(2.5f * bf);
                    sparkP.setColor(Color.argb((int)(230 * bf), 255, 255, 255));
                    for (int k = 0; k < 4; k++) {
                        float sa = slashAngle + (float)(k * Math.PI / 2.0);
                        c.drawLine(tipX, tipY,
                                tipX + (float) Math.cos(sa) * 18f * bf,
                                tipY + (float) Math.sin(sa) * 18f * bf, sparkP);
                    }
                    float perpX = -(float) Math.sin(slashAngle) * 12f * bf;
                    float perpY =  (float) Math.cos(slashAngle) * 12f * bf;
                    c.drawLine(tipX - perpX, tipY - perpY, tipX + perpX, tipY + perpY, sparkP);
                }
            } else if (slot == 1 || slot == 3) {
                Paint innerP = new Paint(Paint.ANTI_ALIAS_FLAG);
                innerP.setStyle(Paint.Style.STROKE);
                innerP.setStrokeWidth(3.5f * easedFrac);
                innerP.setColor(Color.argb((int)(200 * easedFrac), 255, 50, 110));
                c.drawArc(oval, startDeg + 8f, sweepDeg - 16f, false, innerP);
            } else {
                float outerFrac = easedFrac * frac;
                Paint outerP = new Paint(Paint.ANTI_ALIAS_FLAG);
                outerP.setStyle(Paint.Style.STROKE);
                outerP.setStrokeWidth(2f * outerFrac);
                outerP.setColor(Color.argb((int)(140 * outerFrac), 160, 0, 220));
                c.drawArc(oval, startDeg - 12f, sweepDeg + 24f, false, outerP);
            }
        }
    }

    // ── Shadow Blade crescent effect ──────────────────────────────────────────
    private void drawCrescents(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = crescentFx.iterator();
        while (it.hasNext()) {
            float[] cr = it.next();
            long age = now - (long) cr[3];
            final long CRESCENT_LIFE = 380L;
            if (age < 0 || age > CRESCENT_LIFE) { it.remove(); continue; }
            float frac  = 1f - (float) age / CRESCENT_LIFE;
            float eased = frac * frac;

            c.save();
            c.translate(cr[0], cr[1]);
            c.rotate((float) Math.toDegrees(cr[2])); // +X = slash direction

            float outerR = 38f + (1f - frac) * 18f;
            float innerR = outerR * 0.68f;
            float offset = outerR * 0.42f;

            Path crescent = new Path();
            crescent.setFillType(Path.FillType.EVEN_ODD);
            crescent.addCircle(0f, 0f, outerR, Path.Direction.CW);
            crescent.addCircle(-offset, 0f, innerR, Path.Direction.CW);

            Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
            fillP.setStyle(Paint.Style.FILL);
            fillP.setColor(Color.argb((int)(255 * eased), 255, 255, 255));
            c.drawPath(crescent, fillP);

            Paint edgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
            edgeP.setStyle(Paint.Style.STROKE);
            edgeP.setStrokeWidth(2.5f * frac);
            edgeP.setColor(Color.argb((int)(180 * eased), 180, 225, 255));
            c.drawPath(crescent, edgeP);

            c.restore();
        }
    }

    // ── Local player dash ghost afterimages ───────────────────────────────────
    private void drawDashGhosts(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = dashGhosts.iterator();
        while (it.hasNext()) {
            float[] ghost = it.next();
            long age = now - (long) ghost[2];
            if (age < 0 || age > GHOST_LIFE_MS) { it.remove(); continue; }
            float frac  = (float) age / GHOST_LIFE_MS;
            float alpha = 1f - frac;
            float scale = 1f - frac * 0.35f;

            Paint gFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            gFill.setStyle(Paint.Style.FILL);
            gFill.setColor(Color.argb((int)(100 * alpha), 80, 200, 255));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, gFill);

            Paint gRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            gRing.setStyle(Paint.Style.STROKE);
            gRing.setStrokeWidth(3.5f * alpha);
            gRing.setColor(Color.argb((int)(230 * alpha), 140, 230, 255));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, gRing);

            if (frac < 0.15f && dashGhosts.size() > 1) {
                Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
                streak.setStyle(Paint.Style.STROKE);
                streak.setStrokeWidth(2f * alpha);
                streak.setColor(Color.argb((int)(160 * alpha), 100, 210, 255));
                streak.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f, 6f}, 0f));
                c.drawLine(ghost[0], ghost[1], dashAnimEndX, dashAnimEndY, streak);
            }
        }
    }

    // ── Bot dash ghost afterimages ─────────────────────────────────────────────
    private void drawBotDashGhosts(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = botDashGhosts.iterator();
        while (it.hasNext()) {
            float[] ghost = it.next();
            long age = now - (long) ghost[2];
            if (age < 0 || age > GHOST_LIFE_MS) { it.remove(); continue; }
            float frac  = (float) age / GHOST_LIFE_MS;
            float alpha = 1f - frac;
            float scale = 1f - frac * 0.35f;

            Paint bgFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgFill.setStyle(Paint.Style.FILL);
            bgFill.setColor(Color.argb((int)(110 * alpha), 255, 120, 30));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, bgFill);

            Paint bgRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgRing.setStyle(Paint.Style.STROKE);
            bgRing.setStrokeWidth(3.5f * alpha);
            bgRing.setColor(Color.argb((int)(230 * alpha), 255, 80, 0));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, bgRing);
        }
    }
}
