package com.claudemanager.app.util

import com.claudemanager.app.data.ActivityStatus
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResetPromptTest {

    @Test
    fun runningToWaitingAsksForTheResetTime() {
        assertTrue(ResetPrompt.shouldAsk(ActivityStatus.RUNNING, ActivityStatus.WAITING))
    }

    @Test
    fun waitingFromAnyOtherStatusDoesNotAsk() {
        for (from in ActivityStatus.values()) {
            if (from == ActivityStatus.RUNNING) continue
            assertFalse(from.name, ResetPrompt.shouldAsk(from, ActivityStatus.WAITING))
        }
    }

    @Test
    fun leavingRunningForAnythingButWaitingDoesNotAsk() {
        for (to in ActivityStatus.values()) {
            if (to == ActivityStatus.WAITING) continue
            assertFalse(to.name, ResetPrompt.shouldAsk(ActivityStatus.RUNNING, to))
        }
    }
}
