package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HoldRuleTest {

    private val hour = 60L * 60L * 1000L
    private val now = 100L * hour
    private val window = 5L * hour

    private val old = Account(id = 1L, email = "old@example.com")
    private val next = Account(id = 2L, email = "next@example.com")

    private fun project(
        status: ActivityStatus,
        timerEndTimestamp: Long? = null,
        defaultDurationMillis: Long = window
    ) = Project(
        id = 7L,
        name = "Demo",
        accountId = old.id,
        defaultDurationMillis = defaultDurationMillis,
        timerEndTimestamp = timerEndTimestamp,
        activityStatus = status,
        createdAt = 0L,
        lastActivityChangeAt = now - hour
    )

    private val working = listOf(
        ActivityStatus.RUNNING,
        ActivityStatus.BUILDING,
        ActivityStatus.TESTING,
        ActivityStatus.CUSTOM
    )
    private val quiet = listOf(ActivityStatus.READY, ActivityStatus.FINISHED, ActivityStatus.ERROR)

    // ---- Deleting ----

    @Test
    fun deletingHoldsOneWindowWhateverTheProjectWasDoing() {
        for (status in ActivityStatus.values()) {
            assertEquals(
                status.name,
                now + HoldRule.DELETE_HOLD_MILLIS,
                HoldRule.afterDelete(project(status), now)
            )
        }
    }

    @Test
    fun deletingKeepsALaterResetTimeAndIgnoresAnEarlierOne() {
        val later = now + 8 * hour
        assertEquals(later, HoldRule.afterDelete(project(ActivityStatus.FINISHED, later), now))

        val sooner = now + 1 * hour
        assertEquals(
            now + HoldRule.DELETE_HOLD_MILLIS,
            HoldRule.afterDelete(project(ActivityStatus.FINISHED, sooner), now)
        )
        assertEquals(
            now + HoldRule.DELETE_HOLD_MILLIS,
            HoldRule.afterDelete(project(ActivityStatus.FINISHED, now - 2 * hour), now)
        )
    }

    // ---- Moving a project that is working ----

    @Test
    fun movingAWorkingProjectHoldsAFullWindowFromTheMove() {
        for (status in working) {
            assertEquals(status.name, now + window, HoldRule.afterMove(project(status), now))
        }
    }

    @Test
    fun aBuildingProjectWhoseResetTimeAlreadyPassedStillHoldsAFullWindow() {
        // The timer ran out while the build was still going: the account was running a second ago.
        for (end in listOf(now - 3 * hour, now - 1L, now)) {
            assertEquals(
                "end=$end",
                now + window,
                HoldRule.afterMove(project(ActivityStatus.BUILDING, end), now)
            )
        }
    }

    @Test
    fun aWorkingProjectKeepsALaterResetTimeButNeverLessThanAWindow() {
        val later = now + 8 * hour
        assertEquals(later, HoldRule.afterMove(project(ActivityStatus.BUILDING, later), now))

        val sooner = now + 1 * hour
        assertEquals(now + window, HoldRule.afterMove(project(ActivityStatus.BUILDING, sooner), now))
    }

    @Test
    fun theWindowIsTheLengthTheProjectIsSetTo() {
        val p = project(ActivityStatus.BUILDING, defaultDurationMillis = 3 * hour)
        assertEquals(now + 3 * hour, HoldRule.afterMove(p, now))
    }

    // ---- Moving a project that is waiting or finished ----

    @Test
    fun waitingHoldsUntilItsResetTimeOrAFullWindowWhenItHasNone() {
        val resetAt = now + 2 * hour
        assertEquals(resetAt, HoldRule.afterMove(project(ActivityStatus.WAITING, resetAt), now))
        assertEquals(now + window, HoldRule.afterMove(project(ActivityStatus.WAITING), now))
    }

    @Test
    fun aWaitThatIsOverNeedsNoHold() {
        assertNull(HoldRule.afterMove(project(ActivityStatus.WAITING, now), now))
        assertNull(HoldRule.afterMove(project(ActivityStatus.WAITING, now - 1 * hour), now))
    }

    @Test
    fun aResetTimeStillAheadIsHeldUntilItEnds() {
        val resetAt = now + 3 * hour
        for (status in quiet) {
            assertEquals(status.name, resetAt, HoldRule.afterMove(project(status, resetAt), now))
        }
    }

    @Test
    fun aProjectThatWasNotKeepingTheAccountInUseNeedsNoHold() {
        for (status in quiet) {
            assertNull(status.name, HoldRule.afterMove(project(status), now))
            assertNull(status.name, HoldRule.afterMove(project(status, now), now))
            assertNull(status.name, HoldRule.afterMove(project(status, now - 1 * hour), now))
        }
    }

    // ---- The hold and the idle check agree ----

    @Test
    fun theHoldIsThereExactlyWhenTheProjectWasKeepingTheAccountInUse() {
        val ends = listOf<Long?>(null, now - 2 * hour, now, now + 2 * hour, now + 9 * hour)
        for (status in ActivityStatus.values()) {
            for (end in ends) {
                val p = project(status, end)
                val wasInUse = !IdleCheck.report(old, listOf(p), now).isIdle
                assertEquals("$status end=$end", wasInUse, HoldRule.afterMove(p, now) != null)
            }
        }
    }

    @Test
    fun theOldAccountStaysInUseExactlyUntilTheHoldEnds() {
        val ends = listOf<Long?>(null, now - 2 * hour, now, now + 2 * hour, now + 9 * hour)
        for (status in ActivityStatus.values()) {
            for (end in ends) {
                val p = project(status, end)
                val until = HoldRule.afterMove(p, now) ?: continue
                val label = "$status end=$end"

                // Held: still in use now, and idle again exactly when the hold ends.
                val held = old.copy(holdUntil = until)
                assertFalse(label, IdleCheck.report(held, emptyList(), now).isIdle)
                assertTrue(label, IdleCheck.report(held, emptyList(), until).isIdle)

                // Never freed sooner than the project's own reset time would have freed it.
                val reset = IdleCheck.pendingReset(p, now)
                if (reset != null) assertTrue(label, until >= reset)
            }
        }
    }

    // ---- The reported case, end to end ----

    @Test
    fun movingABuildingProjectDoesNotMakeItsOldAccountIdle() {
        val building = project(ActivityStatus.BUILDING, timerEndTimestamp = now - 1 * hour)
        assertFalse(IdleCheck.report(old, listOf(building), now).isIdle)

        // Without a hold the old account has nothing left that keeps it in use.
        val moved = building.copy(accountId = next.id)
        assertTrue(IdleCheck.report(old, listOf(moved), now).isIdle)

        // With the hold it stays in use for a window, and the new account is in use too.
        val held = old.copy(holdUntil = HoldRule.afterMove(building, now))
        val report = IdleCheck.report(held, listOf(moved), now)
        assertFalse(report.isIdle)
        assertEquals(now + window, report.idleAt)
        assertTrue(report.reasons.single() is IdleReason.Hold)
        assertFalse(IdleCheck.report(next, listOf(moved), now).isIdle)
    }

    @Test
    fun aHeldAccountIsNotOfferedToANewProjectUntilTheHoldEnds() {
        val building = project(ActivityStatus.BUILDING)
        val moved = building.copy(accountId = next.id)
        val held = old.copy(holdUntil = HoldRule.afterMove(building, now))

        val during = AccountChoices.forNewProject(listOf(held, next), listOf(moved), now)
        assertFalse(during.canPick(held.id))

        val after = AccountChoices.forNewProject(listOf(held, next), listOf(moved), now + window)
        assertTrue(after.canPick(held.id))
    }
}
