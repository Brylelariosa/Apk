package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AccountLockTest {

    private val hour = 60L * 60L * 1000L
    private val now = 100L * hour
    private val account = Account(id = 1L, email = "me@example.com")

    private fun project(
        status: ActivityStatus,
        id: Long = 0L,
        accountId: Long? = account.id,
        timerEndTimestamp: Long? = null
    ) = Project(
        id = id,
        name = "Demo",
        accountId = accountId,
        defaultDurationMillis = 5L * hour,
        timerEndTimestamp = timerEndTimestamp,
        activityStatus = status,
        createdAt = 0L,
        lastActivityChangeAt = now
    )

    private fun blocked(vararg projects: Project, except: Long? = null): Project? =
        AccountLock.blockedBy(account.id, projects.toList(), now, except)

    @Test
    fun everyWorkingStatusBlocksTheAccount() {
        val working = listOf(
            ActivityStatus.RUNNING,
            ActivityStatus.BUILDING,
            ActivityStatus.TESTING,
            ActivityStatus.CUSTOM
        )
        for (status in working) {
            assertNotNull(status.name, blocked(project(status)))
        }
    }

    @Test
    fun waitingBlocksWithoutAResetTimeAndUntilItIsReached() {
        assertNotNull(blocked(project(ActivityStatus.WAITING)))
        assertNotNull(blocked(project(ActivityStatus.WAITING, timerEndTimestamp = now + 1L)))
        assertNull(blocked(project(ActivityStatus.WAITING, timerEndTimestamp = now)))
        assertNull(blocked(project(ActivityStatus.WAITING, timerEndTimestamp = now - 1 * hour)))
    }

    @Test
    fun readyFinishedAndErrorDoNotBlock() {
        for (status in listOf(ActivityStatus.READY, ActivityStatus.FINISHED, ActivityStatus.ERROR)) {
            assertNull(status.name, blocked(project(status)))
        }
        // A finished project's reset window keeps the account in use, but it is not "running".
        assertNull(blocked(project(ActivityStatus.FINISHED, timerEndTimestamp = now + 3 * hour)))
    }

    @Test
    fun projectsOfOtherAccountsAreIgnored() {
        assertNull(blocked(project(ActivityStatus.RUNNING, accountId = 2L)))
        assertNull(blocked(project(ActivityStatus.RUNNING, accountId = null)))
    }

    @Test
    fun theEditedProjectNeverBlocksItsOwnAccount() {
        val mine = project(ActivityStatus.RUNNING, id = 7L)
        assertNull(blocked(mine, except = 7L))

        val other = project(ActivityStatus.WAITING, id = 8L)
        assertEquals(other, blocked(mine, other, except = 7L))
    }

    @Test
    fun aBusyAccountIsNeverReportedIdle() {
        val ends = listOf<Long?>(null, now + 2 * hour, now - 2 * hour)
        for (status in ActivityStatus.values()) {
            for (end in ends) {
                val p = project(status, timerEndTimestamp = end)
                if (AccountLock.isRunningOrWaiting(p, now)) {
                    val report = IdleCheck.report(account, listOf(p), now)
                    assertFalse("$status end=$end", report.isIdle)
                }
            }
        }
    }

    @Test
    fun anAccountWithNoBusyProjectCanBePicked() {
        assertTrue(AccountLock.blockedBy(account.id, emptyList(), now) == null)
    }
}
