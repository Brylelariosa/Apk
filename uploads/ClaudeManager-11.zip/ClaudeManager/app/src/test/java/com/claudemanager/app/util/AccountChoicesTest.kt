package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AccountChoicesTest {

    private val hour = 60L * 60L * 1000L
    private val now = 100L * hour

    private fun account(id: Long, holdUntil: Long? = null) =
        Account(id = id, email = "account$id@example.com", holdUntil = holdUntil)

    private fun project(
        status: ActivityStatus,
        accountId: Long?,
        id: Long = 0L,
        timerEndTimestamp: Long? = null
    ) = Project(
        id = id,
        name = "Demo",
        accountId = accountId,
        defaultDurationMillis = 5L * hour,
        timerEndTimestamp = timerEndTimestamp,
        activityStatus = status,
        createdAt = 0L,
        lastActivityChangeAt = now
    )

    // One account for each way of being idle, and for each way of being in use.
    private val untouched = account(1)                              // idle: no projects at all
    private val ready = account(2)                                  // idle: a READY project
    private val running = account(3)                                // in use: RUNNING
    private val resetAhead = account(4)                             // in use: reset 3h away
    private val justDeleted = account(5, holdUntil = now + hour)    // in use: delete hold
    private val resetPassed = account(6)                            // idle: reset already over
    private val waitingNoTime = account(7)                          // in use: WAITING, no reset time
    private val holdOver = account(8, holdUntil = now - 1L)         // idle: delete hold is over

    private val accounts = listOf(
        untouched, ready, running, resetAhead, justDeleted, resetPassed, waitingNoTime, holdOver
    )
    private val idleIds = listOf(1L, 2L, 6L, 8L)
    private val inUseIds = listOf(3L, 4L, 5L, 7L)

    private val projects = listOf(
        project(ActivityStatus.READY, accountId = 2L),
        project(ActivityStatus.RUNNING, accountId = 3L),
        project(ActivityStatus.FINISHED, accountId = 4L, timerEndTimestamp = now + 3 * hour),
        project(ActivityStatus.FINISHED, accountId = 6L, timerEndTimestamp = now - 1 * hour),
        project(ActivityStatus.WAITING, accountId = 7L)
    )

    // ---- New project: idle accounts only ----

    @Test
    fun aNewProjectListsOnlyIdleAccounts() {
        val choices = AccountChoices.forNewProject(accounts, projects, now)
        assertEquals(idleIds, choices.listed.map { it.id })
    }

    @Test
    fun theListKeepsTheOrderItWasGiven() {
        val choices = AccountChoices.forNewProject(accounts.reversed(), projects, now)
        assertEquals(idleIds.reversed(), choices.listed.map { it.id })
    }

    @Test
    fun hiddenCountIsTheNumberOfAccountsInUse() {
        val choices = AccountChoices.forNewProject(accounts, projects, now)
        assertEquals(inUseIds.size, choices.hiddenCount)
        assertTrue(choices.busy.isEmpty())
    }

    @Test
    fun onlyIdleAccountsCanBePickedForANewProject() {
        val choices = AccountChoices.forNewProject(accounts, projects, now)
        for (id in idleIds) assertTrue("account $id", choices.canPick(id))
        for (id in inUseIds) assertFalse("account $id", choices.canPick(id))
        assertFalse("unknown account", choices.canPick(99L))
    }

    @Test
    fun anAccountJoinsTheListWhenItsResetTimeIsReached() {
        // resetAhead ends at now + 3h, justDeleted is held until now + 1h.
        val before = AccountChoices.forNewProject(accounts, projects, now + 3 * hour - 1L)
        assertFalse(before.canPick(resetAhead.id))
        assertTrue(before.canPick(justDeleted.id))

        val at = AccountChoices.forNewProject(accounts, projects, now + 3 * hour)
        assertEquals(listOf(1L, 2L, 4L, 5L, 6L, 8L), at.listed.map { it.id })
        // Still running, and still waiting with no reset time: only a status change frees those.
        assertFalse(at.canPick(running.id))
        assertFalse(at.canPick(waitingNoTime.id))
    }

    @Test
    fun noAccountsMeansAnEmptyList() {
        val choices = AccountChoices.forNewProject(emptyList(), projects, now)
        assertTrue(choices.listed.isEmpty())
        assertEquals(0, choices.hiddenCount)
    }

    @Test
    fun noIdleAccountMeansAnEmptyListAndEveryoneHidden() {
        val choices = AccountChoices.forNewProject(listOf(running, resetAhead), projects, now)
        assertTrue(choices.listed.isEmpty())
        assertEquals(2, choices.hiddenCount)
    }

    @Test
    fun projectsWithoutAnAccountHideNothing() {
        val orphan = project(ActivityStatus.RUNNING, accountId = null)
        val choices = AccountChoices.forNewProject(listOf(untouched), listOf(orphan), now)
        assertEquals(listOf(untouched.id), choices.listed.map { it.id })
    }

    @Test
    fun theListNeverDisagreesWithTheIdleCheck() {
        val ends = listOf<Long?>(null, now + 2 * hour, now, now - 2 * hour)
        val holds = listOf<Long?>(null, now + hour, now - hour)
        for (status in ActivityStatus.values()) {
            for (end in ends) {
                for (hold in holds) {
                    val a = account(1L, holdUntil = hold)
                    val ps = listOf(project(status, accountId = a.id, timerEndTimestamp = end))
                    val idle = IdleCheck.report(a, ps, now).isIdle
                    val choices = AccountChoices.forNewProject(listOf(a), ps, now)
                    assertEquals("$status end=$end hold=$hold", idle, choices.canPick(a.id))
                    assertEquals("$status end=$end hold=$hold", idle, choices.listed.isNotEmpty())
                }
            }
        }
    }

    // ---- Editing: only a running or waiting project greys an account out ----

    @Test
    fun editingListsEveryAccountAndGreysOutTheBusyOnes() {
        val edited = project(ActivityStatus.READY, accountId = 1L, id = 10L)
        val choices = AccountChoices.forEdit(edited, accounts, projects + edited, now)

        assertEquals(accounts.map { it.id }, choices.listed.map { it.id })
        assertEquals(0, choices.hiddenCount)
        assertEquals(setOf(3L, 7L), choices.busy.keys)
        assertEquals(ActivityStatus.RUNNING, choices.busy.getValue(3L).activityStatus)
        assertFalse(choices.canPick(3L))
        assertFalse(choices.canPick(7L))
        assertTrue(choices.canPick(2L))
    }

    @Test
    fun editingKeepsTheLooserRuleForAPendingResetOrHold() {
        // Hidden for a new project, but nothing is running or waiting there, so it can be picked
        // when editing an existing project.
        val edited = project(ActivityStatus.READY, accountId = 1L, id = 10L)
        val forEdit = AccountChoices.forEdit(edited, accounts, projects + edited, now)
        val forNew = AccountChoices.forNewProject(accounts, projects + edited, now)
        for (a in listOf(resetAhead, justDeleted)) {
            assertTrue("edit ${a.id}", forEdit.canPick(a.id))
            assertFalse("new ${a.id}", forNew.canPick(a.id))
        }
    }

    @Test
    fun theEditedProjectsOwnAccountIsNeverGreyedOut() {
        val edited = project(ActivityStatus.RUNNING, accountId = 3L, id = 10L)
        val sibling = project(ActivityStatus.WAITING, accountId = 3L, id = 11L)
        val choices = AccountChoices.forEdit(edited, accounts, projects + edited + sibling, now)
        assertNull(choices.busy[3L])
        assertTrue(choices.canPick(3L))
    }

    @Test
    fun ofPicksTheRuleByWhetherAProjectIsGiven() {
        val edited = project(ActivityStatus.READY, accountId = 1L, id = 10L)
        assertEquals(
            idleIds,
            AccountChoices.of(null, accounts, projects, now).listed.map { it.id }
        )
        assertEquals(
            accounts.map { it.id },
            AccountChoices.of(edited, accounts, projects, now).listed.map { it.id }
        )
    }

    // ---- Saving: the same rules, enforced ----

    @Test
    fun noAccountIsAlwaysAllowed() {
        val edited = project(ActivityStatus.READY, accountId = 3L, id = 10L)
        val forNew = AccountChoices.forNewProject(accounts, projects, now)
        val forEdit = AccountChoices.forEdit(edited, accounts, projects, now)
        assertNull(forNew.resolve(wanted = null, current = null))
        assertNull(forEdit.resolve(wanted = null, current = 3L))
    }

    @Test
    fun theAccountAProjectAlreadyHasStaysEvenWhenItIsBusy() {
        // Account 3 has a running project besides the edited one.
        val edited = project(ActivityStatus.READY, accountId = 3L, id = 10L)
        val choices = AccountChoices.forEdit(edited, accounts, projects + edited, now)
        assertEquals(3L, choices.resolve(wanted = 3L, current = 3L))
    }

    @Test
    fun aNewProjectOnAnAccountInUseEndsUpWithoutAnAccount() {
        val choices = AccountChoices.forNewProject(accounts, projects, now)
        for (id in inUseIds) assertNull("account $id", choices.resolve(wanted = id, current = null))
        assertNull("unknown account", choices.resolve(wanted = 99L, current = null))
    }

    @Test
    fun aNewProjectOnAnIdleAccountKeepsIt() {
        val choices = AccountChoices.forNewProject(accounts, projects, now)
        for (id in idleIds) assertEquals("account $id", id, choices.resolve(wanted = id, current = null))
    }

    @Test
    fun anEditedProjectKeepsItsAccountWhenTheNewOneIsBusy() {
        val edited = project(ActivityStatus.READY, accountId = 1L, id = 10L)
        val choices = AccountChoices.forEdit(edited, accounts, projects + edited, now)
        assertEquals(1L, choices.resolve(wanted = 3L, current = 1L))
        assertEquals(1L, choices.resolve(wanted = 7L, current = 1L))
        assertEquals(2L, choices.resolve(wanted = 2L, current = 1L))
    }
}
