package com.claudemanager.app.util

import com.claudemanager.app.data.Project

/**
 * How long an account stays in use after a project lets go of it.
 *
 * A project that is deleted, or moved to another account, was using its account, so that account
 * must not look free the moment the project is gone. It is held instead (Account.holdUntil), and
 * IdleCheck keeps it in use until the hold ends. Without this, moving a BUILDING project to another
 * account showed the old account as IDLE at once, although it had been running a second earlier.
 *
 *  - Deleting always holds: one usage window, or the project's reset time if that is later.
 *  - Moving holds what the project was keeping the account in use with, and nothing else:
 *      - A working project (see IdleCheck.isWorking) holds a full window counted from the move, the
 *        same way DONE does (see FinishRule), whatever its timer says. A reset time that has
 *        already passed frees nothing, because the project was still running.
 *      - A reset time that is still ahead holds until that time.
 *      - Any other project was not keeping the account in use, so there is nothing to hold.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object HoldRule {

    /** One Claude usage window: how long deleting a project holds its account. */
    const val DELETE_HOLD_MILLIS: Long = 5L * 60L * 60L * 1000L

    /**
     * When the account of the deleted [project] stops being in use: one window from [now], or the
     * project's reset time when that is later.
     */
    fun afterDelete(project: Project, now: Long): Long =
        maxOf(now + DELETE_HOLD_MILLIS, project.timerEndTimestamp ?: 0L)

    /**
     * When the account [project] is moved off stops being in use, or null when the project was not
     * keeping it in use and the account may turn idle at once. A working project holds a window of
     * its own length (the project's default, 5h unless changed), as in FinishRule.
     */
    fun afterMove(project: Project, now: Long): Long? {
        val reset = IdleCheck.pendingReset(project, now)
        if (!IdleCheck.isWorking(project)) return reset
        return maxOf(now + project.defaultDurationMillis, reset ?: 0L)
    }
}
