package com.claudemanager.app.data

import android.content.Context

data class Settings(
    val historyLimit: Int = 50,
    val defaultDurationMillis: Long = 5L * 60L * 60L * 1000L,
    val notificationsEnabled: Boolean = true,
    val sort: SortConfig = SortConfig()
)

class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("claude_manager_settings", Context.MODE_PRIVATE)

    fun load(): Settings {
        val d = Settings()
        return Settings(
            historyLimit = sp.getInt(KEY_HISTORY, d.historyLimit),
            defaultDurationMillis = sp.getLong(KEY_DURATION, d.defaultDurationMillis),
            notificationsEnabled = sp.getBoolean(KEY_NOTIFY, d.notificationsEnabled),
            sort = SortConfig.fromStorage(
                order = sp.getString(KEY_SORT_ORDER, null),
                disabled = sp.getString(KEY_SORT_OFF, null),
                almostResetMinutes = sp.getInt(KEY_SORT_ALMOST, d.sort.almostResetMinutes)
            )
        )
    }

    fun save(s: Settings) {
        sp.edit()
            .putInt(KEY_HISTORY, s.historyLimit)
            .putLong(KEY_DURATION, s.defaultDurationMillis)
            .putBoolean(KEY_NOTIFY, s.notificationsEnabled)
            .putString(KEY_SORT_ORDER, s.sort.orderToStorage())
            .putString(KEY_SORT_OFF, s.sort.disabledToStorage())
            .putInt(KEY_SORT_ALMOST, s.sort.almostResetMinutes)
            .apply()
    }

    private companion object {
        const val KEY_HISTORY = "history_limit"
        const val KEY_DURATION = "default_duration_ms"
        const val KEY_NOTIFY = "notifications_enabled"
        const val KEY_SORT_ORDER = "sort_order"
        const val KEY_SORT_OFF = "sort_disabled"
        const val KEY_SORT_ALMOST = "sort_almost_reset_min"
    }
}
