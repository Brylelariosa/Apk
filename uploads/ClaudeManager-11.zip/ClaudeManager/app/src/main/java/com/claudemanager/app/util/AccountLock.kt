package com.claudemanager.app.util

import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project

/**
 * Which accounts a project may be moved to. An account that has a project running or waiting is
 * busy and cannot be picked.
 *
 * "Running" is every status that means the account is being worked on (RUNNING, BUILDING, TESTING
 * or a custom status). "Waiting" is WAITING until its reset time is reached; with no reset time
 * set it lasts until the status changes. This is the same rule IdleCheck uses to keep an account
 * from showing IDLE, so a busy account is never idle.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object AccountLock {

    /** True while [project] is being worked on, or is still waiting for its reset time. */
    fun isRunningOrWaiting(project: Project, now: Long): Boolean = when (project.activityStatus) {
        ActivityStatus.RUNNING,
        ActivityStatus.BUILDING,
        ActivityStatus.TESTING,
        ActivityStatus.CUSTOM -> true

        ActivityStatus.WAITING -> project.timerEndTimestamp.let { it == null || it > now }

        ActivityStatus.READY,
        ActivityStatus.FINISHED,
        ActivityStatus.ERROR -> false
    }

    /**
     * The project that makes [accountId] busy, or null when the account is free to pick.
     * [exceptProjectId] is the project being edited: it never counts against an account.
     */
    fun blockedBy(
        accountId: Long,
        projects: List<Project>,
        now: Long,
        exceptProjectId: Long? = null
    ): Project? = projects.firstOrNull { p ->
        p.accountId == accountId && p.id != exceptProjectId && isRunningOrWaiting(p, now)
    }
}
