package com.claudemanager.app.util

import com.claudemanager.app.data.Project

/**
 * What marking a project DONE does to its reset time.
 *
 * DONE does not mean "the account is free": the run just used the account, so it stays in use for
 * a full window (the project's default length, 5h unless changed) counted from the moment of DONE.
 * Without this the account showed IDLE the second the run was finished.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object FinishRule {

    /**
     * [project] with a fresh reset window that starts at [now]. A reset time that is already later
     * than that (set by hand, say) is kept: finishing never frees an account sooner.
     */
    fun onFinish(project: Project, now: Long): Project {
        val end = now + project.defaultDurationMillis
        val current = project.timerEndTimestamp
        if (current != null && current > end) return project
        return project.copy(timerStartTimestamp = now, timerEndTimestamp = end)
    }
}
