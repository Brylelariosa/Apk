package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.Project

/**
 * The account dropdown of the project dialog: which accounts it lists, and which of those can be
 * picked.
 *
 *  - New project: only IDLE accounts are listed, judged by the same check that puts IDLE on the
 *    Accounts screen (see [IdleCheck]). An account that is in use, for whatever reason, is left out
 *    of the list instead of being greyed out.
 *  - Editing: every account is listed, but one that has ANOTHER project running or waiting is
 *    greyed out, with that project as the reason (see [AccountLock]). The edited project's own
 *    account always stays pickable.
 *
 * The dialog shows these choices and [resolve] enforces them when a project is saved, so the two
 * always agree.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
class AccountChoices private constructor(
    /** The accounts the dropdown lists, in the order they were given. */
    val listed: List<Account>,
    /** Listed accounts that cannot be picked, each with the project that keeps it busy. Editing only. */
    val busy: Map<Long, Project>,
    /** How many accounts the list leaves out because they are in use. New project only. */
    val hiddenCount: Int
) {
    private val listedIds: Set<Long> = listed.mapTo(HashSet()) { it.id }

    /** True when [accountId] is in the list and not greyed out. */
    fun canPick(accountId: Long): Boolean = accountId in listedIds && accountId !in busy

    /**
     * The account a saved project ends up on. [wanted] is what the dialog asked for, [current] is
     * what the project has now (null for a new project).
     *  - No account is always allowed.
     *  - The account the project already has always stays.
     *  - Any other account is taken only when it can be picked; otherwise [current] is kept, so a
     *    new project then simply has no account.
     */
    fun resolve(wanted: Long?, current: Long?): Long? = when {
        wanted == null -> null
        wanted == current -> wanted
        canPick(wanted) -> wanted
        else -> current
    }

    companion object {

        /** The choices for editing [project], or for a new project when it is null. */
        fun of(
            project: Project?,
            accounts: List<Account>,
            projects: List<Project>,
            now: Long
        ): AccountChoices =
            if (project == null) {
                forNewProject(accounts, projects, now)
            } else {
                forEdit(project, accounts, projects, now)
            }

        fun forNewProject(accounts: List<Account>, projects: List<Project>, now: Long): AccountChoices {
            val idle = IdleCheck.idleAccounts(accounts, projects, now)
            return AccountChoices(
                listed = idle,
                busy = emptyMap(),
                hiddenCount = accounts.size - idle.size
            )
        }

        fun forEdit(
            project: Project,
            accounts: List<Account>,
            projects: List<Project>,
            now: Long
        ): AccountChoices {
            val byAccount = projects.groupBy { it.accountId }
            val busy = HashMap<Long, Project>()
            for (a in accounts) {
                if (a.id == project.accountId) continue
                val blocker = AccountLock.blockedBy(a.id, byAccount[a.id].orEmpty(), now, project.id)
                if (blocker != null) busy[a.id] = blocker
            }
            return AccountChoices(listed = accounts, busy = busy, hiddenCount = 0)
        }
    }
}
