package com.claudemanager.app.util

import com.claudemanager.app.data.ActivityStatus

/**
 * When a status change leads straight on to asking for the reset time.
 *
 * Changing a project from RUNNING to WAITING opens the same reset-time picker as "Set timer"
 * (ResetTimeDialog), so the time is set at the moment of the change instead of from the menu
 * afterwards. Every other change just saves the status.
 *
 * Pure Kotlin on purpose: only the two statuses decide the answer, so it is easy to test, and a
 * future change to the rule (for example, asking on every change to WAITING) happens here only.
 */
object ResetPrompt {

    /** True when changing a project from status [from] to status [to] should also ask for the reset time. */
    fun shouldAsk(from: ActivityStatus, to: ActivityStatus): Boolean =
        from == ActivityStatus.RUNNING && to == ActivityStatus.WAITING
}
