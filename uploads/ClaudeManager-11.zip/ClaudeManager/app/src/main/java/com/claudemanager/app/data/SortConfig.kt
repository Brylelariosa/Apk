package com.claudemanager.app.data

/**
 * One group of the project list. A project is listed in the first group (in the user's order)
 * that fits it. The two reset groups look at the reset time, every other group at the status.
 *
 * The declaration order is the default order.
 */
enum class SortGroup(val status: ActivityStatus? = null) {
    /** The reset time has passed, so the account can be used again. */
    RESET_DONE,

    /** The reset time is close (see [SortConfig.almostResetMinutes]). */
    RESET_SOON,

    TESTING(ActivityStatus.TESTING),
    BUILDING(ActivityStatus.BUILDING),
    RUNNING(ActivityStatus.RUNNING),
    CUSTOM(ActivityStatus.CUSTOM),
    ERROR(ActivityStatus.ERROR),
    WAITING(ActivityStatus.WAITING),
    READY(ActivityStatus.READY),
    FINISHED(ActivityStatus.FINISHED)
}

/**
 * How the project list is ordered. [order] holds every group, top to bottom. A group in
 * [disabled] is skipped: its projects drop into the next group that fits them, or to the end of
 * the list when none does. See ProjectSort for how the groups are applied.
 */
data class SortConfig(
    val order: List<SortGroup> = SortGroup.values().toList(),
    val disabled: Set<SortGroup> = emptySet(),
    val almostResetMinutes: Int = DEFAULT_ALMOST_RESET_MINUTES
) {

    /** The groups that count, in order. */
    val active: List<SortGroup>
        get() = order.filter { it !in disabled }

    /** [group] moved [offset] places (-1 = up, 1 = down); unchanged at the edge of the list. */
    fun moved(group: SortGroup, offset: Int): SortConfig {
        val from = order.indexOf(group)
        val to = from + offset
        if (from < 0 || to < 0 || to >= order.size) return this
        val next = order.toMutableList()
        next.removeAt(from)
        next.add(to, group)
        return copy(order = next)
    }

    fun toggled(group: SortGroup): SortConfig =
        copy(disabled = if (group in disabled) disabled - group else disabled + group)

    fun orderToStorage(): String = order.joinToString(",") { it.name }

    fun disabledToStorage(): String = disabled.joinToString(",") { it.name }

    companion object {
        const val DEFAULT_ALMOST_RESET_MINUTES = 60

        /** What the "almost reset" window can be set to, in minutes. */
        val ALMOST_RESET_CHOICES: List<Int> = listOf(30, 60, 120, 180)

        /**
         * Rebuilds a saved config. Unknown names are ignored, and groups missing from the save
         * (added by a later update) are appended in their default order.
         */
        fun fromStorage(order: String?, disabled: String?, almostResetMinutes: Int): SortConfig {
            val saved = groupsOf(order)
            return SortConfig(
                order = saved + SortGroup.values().filter { it !in saved },
                disabled = groupsOf(disabled).toSet(),
                almostResetMinutes = almostResetMinutes.coerceIn(1, 24 * 60)
            )
        }

        private fun groupsOf(raw: String?): List<SortGroup> =
            raw.orEmpty()
                .split(',')
                .mapNotNull { name -> SortGroup.values().firstOrNull { it.name == name.trim() } }
                .distinct()
    }
}
