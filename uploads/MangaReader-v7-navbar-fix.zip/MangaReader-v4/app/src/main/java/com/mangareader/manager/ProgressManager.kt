package com.mangareader.manager

import android.content.Context
import com.google.gson.Gson
import com.mangareader.data.ReadingProgress

/**
 * Persists reading progress and tracks which chapters have been completed.
 *
 * Storage layout (SharedPreferences keys):
 *   "p_<seriesId>"           → current [ReadingProgress] for a series (JSON)
 *   "read_<seriesId>"        → comma-separated set of completed chapter IDs
 *   "history"                → JSON array of the last [MAX_HISTORY] seriesIds
 *                              in most-recently-read order
 */
class ProgressManager(private val context: Context) {

    companion object {
        private const val MAX_HISTORY = 20
    }

    private val prefs = context.getSharedPreferences("manga_progress", Context.MODE_PRIVATE)
    private val gson  = Gson()

    // ── Current progress ───────────────────────────────────────────────────────

    fun getProgress(seriesId: String): ReadingProgress? {
        val json = prefs.getString("p_$seriesId", null) ?: return null
        return runCatching { gson.fromJson(json, ReadingProgress::class.java) }.getOrNull()
    }

    fun saveProgress(progress: ReadingProgress) {
        prefs.edit()
            .putString("p_${progress.seriesId}", gson.toJson(progress))
            .apply()
        // Push to reading history whenever progress is saved
        pushHistory(progress.seriesId)
    }

    fun clearProgress(seriesId: String) {
        prefs.edit()
            .remove("p_$seriesId")
            .remove("read_$seriesId")
            .apply()
        removeFromHistory(seriesId)
    }

    // ── Chapter completion tracking ────────────────────────────────────────────

    /**
     * Marks [chapterId] as fully read for the given series.
     * Called automatically when the reader reaches the last page and
     * [SettingsManager.autoMarkRead] is enabled.
     */
    fun markChapterRead(seriesId: String, chapterId: String) {
        val current = getReadChapterIds(seriesId).toMutableSet()
        if (current.add(chapterId)) {
            prefs.edit()
                .putString("read_$seriesId", current.joinToString(","))
                .apply()
        }
    }

    /** Returns the set of chapter IDs that have been completed for [seriesId]. */
    fun getReadChapterIds(seriesId: String): Set<String> {
        val raw = prefs.getString("read_$seriesId", "") ?: return emptySet()
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }

    // ── Reading history ────────────────────────────────────────────────────────

    /**
     * Returns the [MAX_HISTORY] most-recently-read series IDs, newest first.
     * Used to sort the library by "Last Read" and to power a "Recently Read"
     * section without touching the heavy JSON library list.
     */
    fun getRecentSeriesIds(): List<String> {
        val json = prefs.getString("history", "[]") ?: "[]"
        return runCatching {
            gson.fromJson(json, Array<String>::class.java)?.toList()
        }.getOrNull() ?: emptyList()
    }

    private fun pushHistory(seriesId: String) {
        val list = getRecentSeriesIds().toMutableList()
        list.remove(seriesId)   // remove existing entry to avoid duplicates
        list.add(0, seriesId)   // add at front (most recent)
        if (list.size > MAX_HISTORY) list.subList(MAX_HISTORY, list.size).clear()
        prefs.edit().putString("history", gson.toJson(list)).apply()
    }

    private fun removeFromHistory(seriesId: String) {
        val list = getRecentSeriesIds().toMutableList()
        if (list.remove(seriesId)) {
            prefs.edit().putString("history", gson.toJson(list)).apply()
        }
    }
}
