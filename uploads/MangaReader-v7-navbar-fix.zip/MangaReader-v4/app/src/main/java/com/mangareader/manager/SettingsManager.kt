package com.mangareader.manager

import android.content.Context
import com.mangareader.data.LibrarySortOrder
import com.mangareader.data.ReadingMode

/**
 * Single source of truth for all user-configurable preferences.
 * Every property delegates directly to SharedPreferences so values persist
 * across process restarts without a separate save call.
 */
class SettingsManager(context: Context) {

    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    // ── Reader: scroll ─────────────────────────────────────────────────────────

    /** Fling velocity multiplier (1.0 = stock Compose, higher = snappier). */
    var scrollSpeed: Float
        get() = prefs.getFloat("scroll_speed", 1.5f)
        set(v) { prefs.edit().putFloat("scroll_speed", v).apply() }

    // ── Reader: layout ─────────────────────────────────────────────────────────

    /**
     * Active reading mode. See [ReadingMode] for descriptions.
     * Stored as the ordinal Int for Gson compatibility.
     */
    var readingMode: ReadingMode
        get() = ReadingMode.entries.getOrElse(
            prefs.getInt("reading_mode", ReadingMode.VERTICAL.ordinal)
        ) { ReadingMode.VERTICAL }
        set(v) { prefs.edit().putInt("reading_mode", v.ordinal).apply() }

    // ── Reader: image filtering ────────────────────────────────────────────────

    /**
     * Minimum pixel dimension an image must have to be kept as a manga page.
     * Images smaller than this in either width or height are silently dropped.
     * 0 = disabled. Takes effect when a chapter is re-extracted.
     */
    var minImageDimension: Int
        get() = prefs.getInt("min_image_dim", 120)
        set(v) { prefs.edit().putInt("min_image_dim", v).apply() }

    // ── Reader: page ordering ──────────────────────────────────────────────────

    /**
     * Controls how pages are ordered within a chapter after extraction.
     * AUTO uses HTML document order (most reliable); ENCOUNTER and URL_PAGE
     * are manual overrides for unusual sites.
     * Takes effect when a chapter is re-extracted.
     */
    var sortOrder: SortOrder
        get() = SortOrder.from(prefs.getInt("sort_order", SortOrder.AUTO.value))
        set(v) { prefs.edit().putInt("sort_order", v.value).apply() }

    /** Page-ordering strategy used by [com.mangareader.parser.MhtmlParser]. */
    enum class SortOrder(val value: Int) {
        AUTO(0),
        ENCOUNTER(1),
        URL_PAGE(2);

        companion object {
            fun from(v: Int) = entries.firstOrNull { it.value == v } ?: AUTO
        }
    }

    // ── Reader: behaviour ─────────────────────────────────────────────────────

    /** Preload the next chapter while reading the current one. */
    var preloadNextChapter: Boolean
        get() = prefs.getBoolean("preload_next", true)
        set(v) { prefs.edit().putBoolean("preload_next", v).apply() }

    /** Automatically mark a chapter as read when the last page is reached. */
    var autoMarkRead: Boolean
        get() = prefs.getBoolean("auto_mark_read", true)
        set(v) { prefs.edit().putBoolean("auto_mark_read", v).apply() }

    /** Keep the screen awake while reading. */
    var keepScreenAwake: Boolean
        get() = prefs.getBoolean("keep_awake", true)
        set(v) { prefs.edit().putBoolean("keep_awake", v).apply() }

    // ── Library ────────────────────────────────────────────────────────────────

    /** How series are ordered in the library grid. */
    var librarySortOrder: LibrarySortOrder
        get() = LibrarySortOrder.entries.getOrElse(
            prefs.getInt("lib_sort", LibrarySortOrder.RECENTLY_ADDED.ordinal)
        ) { LibrarySortOrder.RECENTLY_ADDED }
        set(v) { prefs.edit().putInt("lib_sort", v.ordinal).apply() }

    // ── Cache ──────────────────────────────────────────────────────────────────

    /** Maximum number of decoded chapter image sets to keep on disk per series. */
    var maxCachedChaptersPerSeries: Int
        get() = prefs.getInt("cache_chapters", 3)
        set(v) { prefs.edit().putInt("cache_chapters", v).apply() }
}
