package com.mangareader.ui

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import kotlin.math.abs

/**
 * Multiplier applied to a flick's velocity before it's handed off to the
 * normal physics-based deceleration. 1.0 = stock Compose behaviour.
 *
 * Bump this up for "the faster you flick, the further/faster it goes"
 * momentum scrolling; turn it down for gentler, more controlled scrolling.
 * This is the one knob to tune if the feel isn't quite right.
 */
private const val FLING_VELOCITY_MULTIPLIER = 1.7f

/**
 * A [FlingBehavior] that boosts scroll momentum: the same flick speed travels
 * noticeably further/faster than Compose's default, while slow drags still
 * feel completely normal since only the *fling* (post-release) velocity is
 * scaled, not finger-tracking during the drag itself.
 */
@Composable
fun rememberMomentumFlingBehavior(
    velocityMultiplier: Float = FLING_VELOCITY_MULTIPLIER
): FlingBehavior {
    val flingSpec = rememberSplineBasedDecay<Float>()
    return remember(flingSpec, velocityMultiplier) {
        object : FlingBehavior {
            override suspend fun ScrollScope.performFling(initialVelocity: Float): Float {
                val boosted = initialVelocity * velocityMultiplier
                var velocityLeft = boosted
                var lastValue = 0f
                AnimationState(initialValue = 0f, initialVelocity = boosted).animateDecay(flingSpec) {
                    val delta = value - lastValue
                    val consumed = scrollBy(delta)
                    lastValue = value
                    velocityLeft = this.velocity
                    // Stop early if the list can't consume any more (e.g. it
                    // hit the top/bottom) instead of spinning uselessly.
                    if (abs(delta - consumed) > 0.5f) {
                        this.cancelAnimation()
                    }
                }
                return velocityLeft
            }
        }
    }
}
