package com.mangareader.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.LibrarySortOrder
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.manager.CacheManager
import com.mangareader.manager.LibraryManager
import com.mangareader.manager.ProgressManager
import com.mangareader.manager.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val libraryManager  = LibraryManager(app)
    private val progressManager = ProgressManager(app)
    private val settingsManager = SettingsManager(app)
    val cacheManager            = CacheManager(app)

    // ── Raw state ──────────────────────────────────────────────────────────────

    private val _allSeries  = MutableStateFlow<List<Series>>(emptyList())
    private val _loading    = MutableStateFlow(false)
    private val _error      = MutableStateFlow<String?>(null)

    /** Progress snapshot keyed by seriesId — refreshed in [reload] so the
     *  library grid doesn't call SharedPreferences per card during composition. */
    private val _progressMap = MutableStateFlow<Map<String, ReadingProgress>>(emptyMap())

    /** Set of chapter IDs that have been read, keyed by seriesId. */
    private val _readChaptersMap = MutableStateFlow<Map<String, Set<String>>>(emptyMap())

    // ── Filter / sort state ────────────────────────────────────────────────────

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _sortOrder = MutableStateFlow(settingsManager.librarySortOrder)
    val sortOrder: StateFlow<LibrarySortOrder> = _sortOrder

    // ── Derived: filtered + sorted series ─────────────────────────────────────

    /**
     * The series list exposed to the UI, filtered by [_searchQuery] and
     * sorted by [_sortOrder].  Computed reactively so the UI never has to
     * sort/filter manually.
     */
    val series: StateFlow<List<Series>> = combine(
        _allSeries, _searchQuery, _sortOrder, _progressMap
    ) { all, query, sort, progress ->
        val filtered = if (query.isBlank()) all
            else all.filter { it.title.contains(query, ignoreCase = true) }

        val recentIds = progressManager.getRecentSeriesIds()

        filtered.sortedWith(Comparator { a, b ->
            when (sort) {
                LibrarySortOrder.TITLE_AZ       -> a.title.compareTo(b.title, ignoreCase = true)
                LibrarySortOrder.TITLE_ZA       -> b.title.compareTo(a.title, ignoreCase = true)
                LibrarySortOrder.RECENTLY_ADDED -> b.addedAt.compareTo(a.addedAt)
                LibrarySortOrder.CHAPTER_COUNT  -> b.chapters.size.compareTo(a.chapters.size)
                LibrarySortOrder.LAST_READ      -> {
                    val ai = recentIds.indexOf(a.id).let { if (it == -1) Int.MAX_VALUE else it }
                    val bi = recentIds.indexOf(b.id).let { if (it == -1) Int.MAX_VALUE else it }
                    ai.compareTo(bi)
                }
            }
        })
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val loading: StateFlow<Boolean> = _loading
    val error:   StateFlow<String?> = _error

    // ── Thumbnails ─────────────────────────────────────────────────────────────

    private val _thumbnails       = MutableStateFlow<Map<String, File>>(emptyMap())
    val thumbnails: StateFlow<Map<String, File>> = _thumbnails

    /**
     * Guard against launching duplicate thumbnail jobs for the same series.
     * Accessed only from the main thread (LaunchedEffect → viewModelScope.launch
     * always dispatches to main), so a plain HashSet is safe.
     */
    private val thumbnailsInFlight = HashSet<String>()

    // ── Cache size for settings display ───────────────────────────────────────

    private val _cacheBytes = MutableStateFlow(0L)
    val cacheBytes: StateFlow<Long> = _cacheBytes

    init {
        reload()
        refreshCacheSize()
    }

    // ── Data loading ───────────────────────────────────────────────────────────

    /**
     * Reloads the series list and progress snapshot from disk.
     * Must be called after any library mutation and when returning from the reader
     * so that progress bars in library cards reflect the latest read position.
     */
    fun reload() {
        val allSeries = libraryManager.getAllSeries()
        _allSeries.value = allSeries

        // Snapshot all progress at once (one SharedPreferences read per series)
        // rather than hitting SharedPreferences per card during composition.
        val progMap = allSeries.associate { s ->
            s.id to progressManager.getProgress(s.id)
        }.filterValues { it != null }.mapValues { it.value!! }
        _progressMap.value = progMap

        // Snapshot read chapters
        val readMap = allSeries.associate { s ->
            s.id to progressManager.getReadChapterIds(s.id)
        }
        _readChaptersMap.value = readMap
    }

    // ── Mutations ──────────────────────────────────────────────────────────────

    fun addFolder(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addFolder(uri) }
            .onFailure { _error.value = "Could not add folder: ${it.message}" }
        reload(); _loading.value = false
    }

    fun addZip(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addZip(uri) }
            .onFailure { _error.value = "Could not add ZIP: ${it.message}" }
        reload(); _loading.value = false
    }

    fun deleteSeries(seriesId: String) {
        libraryManager.deleteSeries(seriesId)
        progressManager.clearProgress(seriesId)
        // Remove thumbnail from in-memory map immediately for snappy UI feedback
        _thumbnails.value = _thumbnails.value - seriesId
        reload()
        refreshCacheSize()
    }

    fun refreshSeries(series: Series) = viewModelScope.launch {
        _loading.value = true
        runCatching { libraryManager.refreshSeries(series) }
            .onFailure { _error.value = "Refresh failed: ${it.message}" }
        reload(); _loading.value = false
    }

    // ── Progress ───────────────────────────────────────────────────────────────

    /** Returns the cached progress for [seriesId] — does NOT hit disk. */
    fun getProgress(seriesId: String): ReadingProgress? = _progressMap.value[seriesId]

    /**
     * Re-reads just [seriesId]'s progress from disk and updates the cached
     * snapshot — much cheaper than a full [reload] (no folder rescan).
     *
     * Call this whenever leaving the Reader: [_progressMap] is only otherwise
     * refreshed when the Library screen is (re)shown, so without this, the
     * chapter list / "Continue Reading" can still point at whatever chapter
     * was current *before* the just-finished reading session — e.g. showing
     * chapter 1 again after the user actually read all the way to chapter 18.
     */
    fun refreshProgress(seriesId: String) {
        val latest = progressManager.getProgress(seriesId) ?: return
        _progressMap.value = _progressMap.value + (seriesId to latest)
    }

    /** Returns the set of completed chapter IDs for [seriesId]. */
    fun getReadChapterIds(seriesId: String): Set<String> =
        _readChaptersMap.value[seriesId] ?: emptySet()

    /**
     * Returns the series recently read, in most-recently-read order.
     * Used for the "Continue Reading" strip in the library.
     */
    fun getRecentSeries(limit: Int = 5): List<Pair<Series, ReadingProgress>> {
        val recentIds = progressManager.getRecentSeriesIds().take(limit)
        val byId      = _allSeries.value.associateBy { it.id }
        return recentIds.mapNotNull { id ->
            val s = byId[id] ?: return@mapNotNull null
            val p = _progressMap.value[id] ?: return@mapNotNull null
            s to p
        }
    }

    // ── Thumbnails ─────────────────────────────────────────────────────────────

    /**
     * Lazily generates (once) and caches a cover thumbnail for [series].
     * Safe to call repeatedly — duplicate in-flight jobs are prevented by
     * [thumbnailsInFlight].
     */
    fun ensureThumbnail(series: Series) {
        if (_thumbnails.value.containsKey(series.id)) return
        if (!thumbnailsInFlight.add(series.id)) return   // already in-flight

        viewModelScope.launch {
            val file = runCatching {
                libraryManager.ensureThumbnail(series)
            }.getOrNull()

            if (file != null) {
                _thumbnails.value = _thumbnails.value + (series.id to file)
            }
            thumbnailsInFlight.remove(series.id)
        }
    }

    // ── Search / sort ──────────────────────────────────────────────────────────

    fun setSearchQuery(q: String) { _searchQuery.value = q }

    fun setSortOrder(order: LibrarySortOrder) {
        settingsManager.librarySortOrder = order
        _sortOrder.value = order
    }

    // ── Cache ──────────────────────────────────────────────────────────────────

    fun refreshCacheSize() {
        viewModelScope.launch(Dispatchers.IO) {
            _cacheBytes.value = cacheManager.totalCacheSizeBytes()
        }
    }

    fun clearAllCaches() = viewModelScope.launch(Dispatchers.IO) {
        cacheManager.clearAll()
        withContext(Dispatchers.Main) {
            _thumbnails.value = emptyMap()
            thumbnailsInFlight.clear()
            refreshCacheSize()
        }
    }

    fun clearError() { _error.value = null }
}
