package com.mangareader.parser

object ChapterParser {

    /** Extract numeric chapter number from a filename for sorting. */
    fun extractNumber(filename: String): Float {
        val name = filename.substringBeforeLast(".")

        // Match "chapter 1", "ch001", "ep 3", "vol 2", etc.
        val wordNum = Regex(
            """(?:chapter|ch|episode|ep|vol|v)\s*(\d+(?:\.\d+)?)""",
            RegexOption.IGNORE_CASE
        ).find(name)
        if (wordNum != null) return wordNum.groupValues[1].toFloatOrNull() ?: 0f

        // Fall back to last number in the filename
        val nums = Regex("""(\d+(?:\.\d+)?)""").findAll(name)
            .mapNotNull { it.groupValues[1].toFloatOrNull() }
            .toList()
        return nums.lastOrNull() ?: 0f
    }

    /** Produce a clean display title from a raw filename. */
    fun formatTitle(filename: String): String =
        filename.substringBeforeLast(".").replace("_", " ").trim()

    /** Produce a clean series name from a folder/zip name. */
    fun extractSeriesName(rawName: String): String =
        rawName.substringBeforeLast(".").replace("_", " ").trim()

    /** Comparator that sorts filenames by embedded chapter number. */
    val byNumber: Comparator<String> = Comparator { a, b ->
        val diff = extractNumber(a).compareTo(extractNumber(b))
        if (diff != 0) diff else a.compareTo(b)
    }
}
