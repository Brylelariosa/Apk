package com.beamshare.app.ui.send

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.apps.InstalledApp
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.components.BeamSecondaryButton
import com.beamshare.app.ui.components.EmptyState
import com.beamshare.app.ui.util.beamViewModel
import com.beamshare.app.util.FormatUtils

private enum class ContentTab { FILES, APPS }

@Composable
fun SelectContentScreen(
    onContinue: (List<TransferItem>) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: SelectContentViewModel = beamViewModel {
        SelectContentViewModel(ServiceLocator.installedAppsRepository, ServiceLocator.fileRepository)
    }
    var tab by remember { mutableStateOf(ContentTab.FILES) }

    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val selectedPackages by viewModel.selectedPackages.collectAsState()
    val totalCount by viewModel.totalSelectedCount.collectAsState()
    val totalBytes by viewModel.totalSelectedBytes.collectAsState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addFileUris(uris)
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.home_send_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(ImageVector.vectorResource(R.drawable.ic_arrow_back), contentDescription = null)
                    }
                }
            )
        },
        bottomBar = {
            SelectContentBottomBar(
                count = totalCount,
                bytes = totalBytes,
                enabled = totalCount > 0,
                onContinue = { onContinue(viewModel.buildTransferItems()) }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab.ordinal) {
                Tab(
                    selected = tab == ContentTab.FILES,
                    onClick = { tab = ContentTab.FILES },
                    text = { Text(stringResource(R.string.select_files_tab)) }
                )
                Tab(
                    selected = tab == ContentTab.APPS,
                    onClick = { tab = ContentTab.APPS; viewModel.loadAppsIfNeeded() },
                    text = { Text(stringResource(R.string.select_apps_tab)) }
                )
            }
            when (tab) {
                ContentTab.FILES -> FilesTab(
                    files = selectedFiles,
                    onChooseFiles = { filePicker.launch(arrayOf("*/*")) },
                    onRemove = viewModel::removeFile
                )
                ContentTab.APPS -> AppsTab(viewModel, selectedPackages)
            }
        }
    }
}

@Composable
private fun FilesTab(
    files: List<TransferItem>,
    onChooseFiles: () -> Unit,
    onRemove: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        BeamSecondaryButton(
            text = stringResource(R.string.select_choose_files),
            onClick = onChooseFiles,
            icon = ImageVector.vectorResource(R.drawable.ic_folder_open),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        if (files.isEmpty()) {
            EmptyState(
                icon = ImageVector.vectorResource(R.drawable.ic_insert_drive_file),
                title = stringResource(R.string.select_no_files_title),
                subtitle = stringResource(R.string.select_no_files_subtitle),
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(files, key = { it.id }) { file ->
                    FileRow(file, onRemove = { onRemove(file.id) })
                }
            }
        }
    }
}

@Composable
private fun FileRow(file: TransferItem, onRemove: () -> Unit) {
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(ImageVector.vectorResource(R.drawable.ic_insert_drive_file), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(file.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                Text(
                    FormatUtils.formatBytes(file.sizeBytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRemove) {
                Icon(ImageVector.vectorResource(R.drawable.ic_close), contentDescription = stringResource(R.string.select_remove))
            }
        }
    }
}

@Composable
private fun AppsTab(viewModel: SelectContentViewModel, selectedPackages: Set<String>) {
    val query by viewModel.searchQuery.collectAsState()
    val apps by viewModel.filteredApps.collectAsState()
    val loading by viewModel.loadingApps.collectAsState()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = viewModel::onSearchQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.select_search_apps)) },
            singleLine = true,
            shape = MaterialTheme.shapes.medium
        )
        Spacer(Modifier.height(12.dp))
        when {
            loading && apps.isEmpty() -> Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(48.dp))
                CircularProgressIndicator()
            }
            apps.isEmpty() -> EmptyState(
                icon = ImageVector.vectorResource(R.drawable.ic_folder_open),
                title = stringResource(R.string.select_no_apps_found),
                subtitle = "",
                modifier = Modifier.fillMaxWidth()
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(apps, key = { it.packageName }) { app ->
                    AppRow(
                        app = app,
                        checked = app.packageName in selectedPackages,
                        onToggle = { viewModel.toggleApp(app.packageName) }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                }
            }
        }
    }
}

@Composable
private fun AppRow(app: InstalledApp, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = null,
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
        )
        Text(app.label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun SelectContentBottomBar(count: Int, bytes: Long, enabled: Boolean, onContinue: () -> Unit) {
    Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.select_items_selected, count, FormatUtils.formatBytes(bytes)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            BeamPrimaryButton(text = stringResource(R.string.select_continue), onClick = onContinue, enabled = enabled)
        }
    }
}
