package com.beamshare.app.ui.session

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.apps.ApkInstaller
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.ui.components.EmptyState
import com.beamshare.app.ui.components.TransferProgressRow
import com.beamshare.app.ui.util.beamViewModel

@Composable
fun ConnectedSessionScreen(
    pendingItems: List<TransferItem>,
    onSendMore: () -> Unit,
    onDisconnected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: SessionViewModel = beamViewModel { SessionViewModel(ServiceLocator.sessionManager) }
    val context = LocalContext.current
    val sessionState by viewModel.sessionState.collectAsState()
    val progress by viewModel.progress.collectAsState()
    var showDisconnectConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(pendingItems) { viewModel.sendPendingOnce(pendingItems) }
    LaunchedEffect(sessionState) { if (sessionState is SessionState.Disconnected) onDisconnected() }

    val peerName = (sessionState as? SessionState.Connected)?.peerName.orEmpty()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.session_connected_to, peerName)) },
                actions = {
                    IconButton(onClick = { showDisconnectConfirm = true }) {
                        Icon(ImageVector.vectorResource(R.drawable.ic_link_off), contentDescription = stringResource(R.string.session_disconnect))
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onSendMore,
                icon = { Icon(ImageVector.vectorResource(R.drawable.ic_add), contentDescription = null) },
                text = { Text(stringResource(R.string.session_send_more)) }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (progress.isEmpty()) {
                EmptyState(
                    icon = ImageVector.vectorResource(R.drawable.ic_insert_drive_file),
                    title = stringResource(R.string.session_empty_state),
                    subtitle = "",
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth()
                )
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(progress, key = { it.itemId }) { item ->
                        TransferActionRow(
                            item = item,
                            onOpen = { openReceivedItem(context, item) }
                        )
                    }
                }
            }
        }
    }

    if (showDisconnectConfirm) {
        AlertDialog(
            onDismissRequest = { showDisconnectConfirm = false },
            title = { Text(stringResource(R.string.session_disconnect_confirm_title)) },
            text = { Text(stringResource(R.string.session_disconnect_confirm_body, peerName)) },
            confirmButton = {
                TextButton(onClick = { showDisconnectConfirm = false; viewModel.disconnect() }) {
                    Text(stringResource(R.string.session_disconnect))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun TransferActionRow(item: TransferProgress, onOpen: () -> Unit) {
    Column {
        TransferProgressRow(progress = item)
        val canOpen = item.state == TransferState.COMPLETED && item.direction == TransferDirection.RECEIVE && item.savedUri != null
        if (canOpen) {
            Spacer(Modifier.height(2.dp))
            TextButton(onClick = onOpen, modifier = Modifier.align(Alignment.End)) {
                Text(stringResource(if (item.isApk) R.string.transfer_install else R.string.transfer_open))
            }
        }
    }
}

private fun openReceivedItem(context: android.content.Context, item: TransferProgress) {
    val uri = item.savedUri ?: return
    val intent = if (item.isApk) {
        ApkInstaller.installIntent(uri)
    } else {
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
    runCatching { context.startActivity(intent) }
}
