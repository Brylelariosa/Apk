package com.beamshare.app.ui.send

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.service.BeamShareService
import com.beamshare.app.ui.components.BeamPrimaryButton
import com.beamshare.app.ui.components.DeviceListItem
import com.beamshare.app.ui.components.PermissionRationale
import com.beamshare.app.ui.util.beamViewModel
import com.beamshare.app.util.PermissionHelper

@Composable
fun DiscoverDevicesScreen(
    qrPayloadToConnect: ConnectPayload?,
    onQrPayloadConsumed: () -> Unit,
    onConnected: () -> Unit,
    onScanQr: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: DiscoverViewModel = beamViewModel {
        DiscoverViewModel(ServiceLocator.wifiDirectManager, ServiceLocator.sessionManager)
    }
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(viewModel.hasPermission()) }
    var connectingToName by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            BeamShareService.start(context)
            viewModel.startDiscovery()
        }
    }

    LaunchedEffect(qrPayloadToConnect) {
        qrPayloadToConnect?.let {
            connectingToName = it.deviceName
            viewModel.connectToQrPayload(it)
            onQrPayloadConsumed()
        }
    }

    val peers by viewModel.peers.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val sessionState by viewModel.sessionState.collectAsState()

    LaunchedEffect(connectionState) {
        (connectionState as? ConnectionState.Connecting)?.let { connectingToName = it.target.name }
    }
    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.Connected) onConnected()
    }

    val isConnecting = connectionState is ConnectionState.Connecting || sessionState is SessionState.AwaitingHandshake
    val failure = (connectionState as? ConnectionState.Failed)?.reason

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.discover_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(ImageVector.vectorResource(R.drawable.ic_arrow_back), contentDescription = null) }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            when {
                !hasPermission -> PermissionRationale(
                    title = stringResource(R.string.discover_permission_title),
                    body = stringResource(R.string.discover_permission_body),
                    actionLabel = stringResource(R.string.discover_permission_grant),
                    onGrant = { permissionLauncher.launch(PermissionHelper.nearbyPermission()) },
                    modifier = Modifier.fillMaxWidth().padding(top = 32.dp)
                )
                isConnecting -> ConnectingIndicator(connectingToName)
                else -> {
                    BeamPrimaryButton(
                        text = stringResource(R.string.discover_scan_qr),
                        onClick = onScanQr,
                        icon = ImageVector.vectorResource(R.drawable.ic_qr_code_scanner),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    if (failure != null) {
                        ErrorNotice(failure) { viewModel.startDiscovery() }
                    } else {
                        DeviceList(peers = peers, onSelect = viewModel::connectToDevice)
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceList(peers: List<PeerDevice>, onSelect: (PeerDevice) -> Unit) {
    if (peers.isEmpty()) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(32.dp))
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.discover_scanning), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(peers, key = { it.macAddress }) { device ->
                DeviceListItem(device = device, onClick = { onSelect(device) })
            }
        }
    }
}

@Composable
private fun ConnectingIndicator(deviceName: String?) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator()
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.discover_connecting, deviceName ?: "…"), style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun ErrorNotice(reason: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(reason, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        BeamPrimaryButton(text = stringResource(R.string.action_retry), onClick = onRetry)
    }
}
