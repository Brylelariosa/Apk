package com.beamshare.app.core.discovery

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.NetworkInfo
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Looper
import android.os.Parcelable
import androidx.core.content.ContextCompat
import com.beamshare.app.core.model.ConnectionState
import com.beamshare.app.core.model.PeerDevice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Thin, lifecycle-aware wrapper around [WifiP2pManager]. Owns the broadcast receiver and
 * channel, and exposes everything else as [StateFlow]s so the UI layer never touches the
 * framework callback API directly.
 */
class WifiDirectManager(private val context: Context) {

    private val manager: WifiP2pManager? =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private val retryHandler = android.os.Handler(Looper.getMainLooper())
    private var isDiscovering = false
    private var discoveryBusyRetries = 0
    private var connectBusyRetries = 0

    private val _peers = MutableStateFlow<List<PeerDevice>>(emptyList())
    val peers: StateFlow<List<PeerDevice>> = _peers.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _thisDevice = MutableStateFlow<PeerDevice?>(null)
    val thisDevice: StateFlow<PeerDevice?> = _thisDevice.asStateFlow()

    val isSupported: Boolean get() = manager != null

    fun start() {
        val mgr = manager ?: return
        if (channel != null) return
        channel = mgr.initialize(context, Looper.getMainLooper()) {
            // Framework-level channel loss (e.g. Wi-Fi service restart). Surface as a failure;
            // the caller can decide whether to call start() again.
            _connectionState.value = ConnectionState.Failed("WiFi Direct channel lost")
            channel = null
        }
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        val r = buildReceiver(mgr)
        receiver = r
        ContextCompat.registerReceiver(context, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        requestThisDeviceInfo()
    }

    /**
     * Actively queries this device's P2P info instead of relying only on
     * WIFI_P2P_THIS_DEVICE_CHANGED_ACTION, which fires on a *change* - if WiFi Direct was
     * already active before this receiver registered, that broadcast may never fire and
     * [thisDevice] would stay null indefinitely. This was the actual cause of the receive
     * screen never showing its own QR code: nothing was ever wrong with generating the QR
     * bitmap, there was simply never a device to encode.
     */
    @SuppressLint("MissingPermission")
    fun requestThisDeviceInfo() {
        val mgr = manager ?: return
        val ch = channel ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mgr.requestDeviceInfo(ch) { device -> device?.let { _thisDevice.value = it.toPeerDevice() } }
        }
        // Pre-API 29 has no direct query; WIFI_P2P_THIS_DEVICE_CHANGED_ACTION is the only
        // source there, requested again below once state confirms P2P is actually enabled.
    }

    fun stop() {
        stopDiscovery()
        retryHandler.removeCallbacksAndMessages(null)
        receiver?.let { runCatching { context.unregisterReceiver(it) } }
        receiver = null
        channel = null
        _peers.value = emptyList()
        _connectionState.value = ConnectionState.Idle
    }

    @SuppressLint("MissingPermission") // presence enforced by hasNearbyPermission() below
    fun startDiscovery() {
        val mgr = manager ?: return
        val ch = channel ?: return
        if (!hasNearbyPermission()) return
        if (isDiscovering) return // avoid a redundant concurrent call that could itself trigger BUSY
        isDiscovering = true
        _connectionState.value = ConnectionState.Discovering
        mgr.discoverPeers(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                isDiscovering = false
                discoveryBusyRetries = 0
            }
            override fun onFailure(reason: Int) {
                isDiscovering = false
                if (reason == WifiP2pManager.BUSY && discoveryBusyRetries < MAX_BUSY_RETRIES) {
                    // The framework is still finishing a just-issued previous command; this is
                    // expected and transient far more often than it's a real problem.
                    discoveryBusyRetries++
                    retryHandler.postDelayed({ startDiscovery() }, BUSY_RETRY_DELAY_MS)
                } else {
                    discoveryBusyRetries = 0
                    _connectionState.value = ConnectionState.Failed(reasonToMessage(reason))
                }
            }
        })
    }

    fun stopDiscovery() {
        val mgr = manager ?: return
        val ch = channel ?: return
        runCatching { mgr.stopPeerDiscovery(ch, null) }
    }

    fun connect(device: PeerDevice) = connectToAddress(device.macAddress, device.name)

    @SuppressLint("MissingPermission")
    fun connectToAddress(macAddress: String, displayName: String = macAddress) {
        val mgr = manager ?: return
        val ch = channel ?: return
        if (!hasNearbyPermission()) return
        val config = WifiP2pConfig().apply {
            deviceAddress = macAddress
            wps.setup = WpsInfo.PBC
        }
        _connectionState.value = ConnectionState.Connecting(PeerDevice(macAddress, displayName))
        mgr.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                connectBusyRetries = 0
            }
            override fun onFailure(reason: Int) {
                if (reason == WifiP2pManager.BUSY && connectBusyRetries < MAX_BUSY_RETRIES) {
                    connectBusyRetries++
                    retryHandler.postDelayed({ connectToAddress(macAddress, displayName) }, BUSY_RETRY_DELAY_MS)
                } else {
                    connectBusyRetries = 0
                    _connectionState.value = ConnectionState.Failed(reasonToMessage(reason))
                }
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        val mgr = manager ?: return
        val ch = channel ?: return
        mgr.removeGroup(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { _connectionState.value = ConnectionState.Idle }
            override fun onFailure(reason: Int) { _connectionState.value = ConnectionState.Idle }
        })
    }

    fun hasNearbyPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    private fun buildReceiver(mgr: WifiP2pManager) = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    val ch = channel ?: return
                    if (!hasNearbyPermission()) return
                    mgr.requestPeers(ch) { peerList ->
                        _peers.value = peerList.deviceList.map { it.toPeerDevice() }
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    val ch = channel ?: return
                    @Suppress("DEPRECATION")
                    val networkInfo = intent.getParcelableExtraCompat<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    if (networkInfo?.isConnected == true) {
                        mgr.requestConnectionInfo(ch) { info ->
                            if (info.groupFormed) {
                                _connectionState.value = ConnectionState.LinkEstablished(
                                    isGroupOwner = info.isGroupOwner,
                                    groupOwnerAddress = info.groupOwnerAddress?.hostAddress.orEmpty()
                                )
                            }
                        }
                    } else if (_connectionState.value is ConnectionState.LinkEstablished) {
                        _connectionState.value = ConnectionState.Idle
                    }
                }
                WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                    val device = intent.getParcelableExtraCompat<WifiP2pDevice>(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE)
                    _thisDevice.value = device?.toPeerDevice()
                }
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val enabled = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) ==
                        WifiP2pManager.WIFI_P2P_STATE_ENABLED
                    if (enabled) {
                        requestThisDeviceInfo()
                    } else {
                        _connectionState.value = ConnectionState.Failed("WiFi Direct is off")
                    }
                }
            }
        }
    }

    private fun WifiP2pDevice.toPeerDevice() = PeerDevice(
        macAddress = deviceAddress,
        name = deviceName.ifBlank { deviceAddress },
        isGroupOwner = false // per-peer GO role isn't knowable until a link is actually formed
    )

    private fun reasonToMessage(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct isn't supported on this device"
        WifiP2pManager.BUSY -> "WiFi Direct is busy, try again"
        else -> "WiFi Direct error ($reason)"
    }

    companion object {
        private const val BUSY_RETRY_DELAY_MS = 1_200L
        private const val MAX_BUSY_RETRIES = 3
    }
}

private inline fun <reified T : Parcelable> Intent.getParcelableExtraCompat(key: String): T? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getParcelableExtra(key, T::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(key)
    }
