# Known Limitations

No compiler, Android SDK, or physical device is available in this
sandbox for any pass of this project. Every fix is checked by hand-
tracing against documented Android/Kotlin/Compose API behavior, XML
validation, and static balance/reference checks - real, but not a
substitute for an actual build and a real WiFi Direct exchange between
two phones. This file is where that gap is spelled out per-topic,
rather than left as a blanket disclaimer.

## WiFi Direct

- **`thisDevice` (own QR code) on API 26-28.** The fix in BUGS_FIXED.md
  #2 adds an active `requestDeviceInfo()` query, but that API only
  exists from API 29 onward. On API 26-28 specifically, populating the
  Receive screen's QR code still depends entirely on
  `WIFI_P2P_THIS_DEVICE_CHANGED_ACTION` firing, which is the same
  broadcast-only behavior that caused the original bug. Given how rare
  Android 8.0/8.1 devices are at this point, this is an accepted gap
  rather than one worth more code to close - but it's a real, known one,
  not silently assumed fixed everywhere.
- **The exact trigger behind "WiFi Direct is busy."** No log was
  attached for this report (unlike the two build-log-driven passes
  before it), so the fix addresses a real, confirmed gap in this
  codebase (a redundant concurrent `discoverPeers()` call was possible)
  plus correct, defensive `BUSY` retry handling - but whether that
  redundant-call path is *the* specific thing that produced this user's
  report, versus some other transient busy state, isn't something a
  read-through alone can confirm. If "busy" still appears after this
  fix, the next useful step would be a logcat capture around the moment
  it happens (`WifiP2pManager`/`WifiP2pService` tags), the same
  build-log-style evidence that made the two Gradle fixes in this
  project fast and certain instead of guesses.
- **Two-device testing.** Every fix in this project so far has been
  checked against one device's code path at a time - the actual
  session handshake, offer/accept, and file streaming between two real
  paired phones has never been observed running. The protocol design
  (see `TransferProtocol.kt`'s own doc comment) is reasoned through
  carefully, but "reasoned through" and "watched two phones actually do
  it" are different confidence levels, worth being honest about.

## Size optimization

- **ML Kit barcode scanning: bundled, not switched to Play-Services-
  unbundled.** `com.google.mlkit:barcode-scanning` ships its model
  inside the APK; a Play-Services-backed unbundled variant
  (`com.google.android.gms:play-services-mlkit-barcode-scanning`) would
  likely cut a further meaningful chunk of size by downloading that
  model on first use instead. Deliberately not switched this pass: it's
  designed to be close to a drop-in API replacement, but "close to" is
  doing real work in that sentence without a compiler here to confirm
  it, it adds a hard Google-Play-Services dependency (a real constraint
  on some device forks) and a network requirement before the *first*
  scan specifically, and this project has already had two build-log-
  driven fix cycles in a row - better to bank the confirmed,
  zero-behavior-change icon-library win this pass than risk a third
  cycle chasing a second, less certain one. Worth revisiting if more
  size reduction is needed and a real build is available to confirm the
  swap compiles and scans correctly before shipping it.
- **The hand-authored vector icons are not pixel-identical to Google's
  Material Symbols glyphs** they replace - they're clean, simple
  geometric reconstructions of the same concept (an arrow is an arrow,
  a folder is a folder), not a byte-for-byte copy of the original path
  data. Worth a glance once a device/emulator is available, since a
  vector path rendering slightly differently than intended is a
  cosmetic risk this sandbox's XML-validity checks can't catch - the
  icons are syntactically valid and geometrically reasoned through, but
  never actually rendered.
