# Media3, OkHttp, Retrofit, Coil, Palette, Compose, Lifecycle, Activity, SavedState and Hilt/Dagger
# ship their own rules inside their libraries, so nothing is kept for them by hand here.

# Generic types, annotations and inner-class info that Gson, Retrofit and Room read at run time.
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod

# ── Gson models ───────────────────────────────────────────────────────────────
# Gson reads and writes these classes by field name, so their names must stay.
-keep class com.melodiq.data.model.** { *; }
-keep class com.melodiq.data.network.** { *; }
-keep class com.melodiq.data.db.entity.** { *; }

# Keep Gson
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *
-dontwarn androidx.room.**

# ── Hilt (the rest of the old rules; the library-wide keeps were removed) ────
-keep @dagger.hilt.android.HiltAndroidApp class *
-keep @dagger.hilt.android.AndroidEntryPoint class *
-dontwarn dagger.hilt.**
-keep class **_HiltModules* { *; }
-keep class **_HiltComponents* { *; }
-keep class **_GeneratedInjector { *; }
-keep class **_ComponentTreeDeps { *; }

-keep @dagger.hilt.InstallIn class * { *; }
-keep @dagger.hilt.EntryPoint class * { *; }
-keepclasseswithmembers class * {
    @javax.inject.Inject <init>(...);
}

# ── ViewModel ─────────────────────────────────────────────────────────────────
-keep class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}

# Warnings only (these are not keeps): classes the libraries mention but do not need.
-dontwarn androidx.media3.**
-dontwarn androidx.savedstate.**
-dontwarn coil.**

# ── Kotlin Coroutines ─────────────────────────────────────────────────────────
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keep class kotlinx.coroutines.android.** { *; }

# ── General ───────────────────────────────────────────────────────────────────
-keepattributes SourceFile,LineNumberTable

# ── Readable crash logs ───────────────────────────────────────────────────────
# The in-app crash logger saves stack traces as text. Without a mapping file a release
# build would print them as a.b.c, so class and method names are kept. Shrinking still
# removes unused code; only the renaming is switched off.
-dontobfuscate
