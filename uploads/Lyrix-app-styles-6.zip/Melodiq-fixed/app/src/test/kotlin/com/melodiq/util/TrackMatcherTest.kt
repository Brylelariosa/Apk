package com.melodiq.util

import com.melodiq.data.network.LrcLibResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackMatcherTest {

    /** [lines] timed lyric lines as LRC text. */
    private fun lrc(lines: Int): String =
        (0 until lines).joinToString("\n") { i -> "[00:" + i.toString().padStart(2, '0') + ".00]line " + i }

    private fun record(
        id: Int,
        title: String?,
        artist: String?,
        duration: Double? = null,
        synced: String? = null,
        plain: String? = null,
        instrumental: Boolean? = null
    ) = LrcLibResponse(
        id = id,
        trackName = title,
        artistName = artist,
        duration = duration,
        syncedLyrics = synced,
        plainLyrics = plain,
        instrumental = instrumental
    )

    // ── normalize ─────────────────────────────────────────────────────────────

    @Test
    fun normalizeLowercasesAndDropsPunctuation() {
        assertEquals("hello world", TrackMatcher.normalize("Hello, World!"))
        assertEquals("ac dc", TrackMatcher.normalize("AC/DC"))
        assertEquals("track 01 intro", TrackMatcher.normalize("Track 01 - Intro"))
    }

    @Test
    fun normalizeDropsBracketedNotes() {
        assertEquals("song", TrackMatcher.normalize("Song (Official Video)"))
        assertEquals("title", TrackMatcher.normalize("Title [Remastered 2011]"))
    }

    @Test
    fun normalizeKeepsLettersWithAccents() {
        assertEquals("beyoncé", TrackMatcher.normalize("Beyoncé"))
    }

    @Test
    fun normalizeOfNothingIsEmpty() {
        assertEquals("", TrackMatcher.normalize("   "))
        assertEquals("", TrackMatcher.normalize("(live)"))
    }

    // ── pickBest ──────────────────────────────────────────────────────────────

    @Test
    fun sameTitleSameArtistAndLengthIsAccepted() {
        val match = record(1, "Yesterday", "The Beatles", 125.0, plain = "la")
        val best = TrackMatcher.pickBest(listOf(match), TrackQuery("Yesterday", "The Beatles"), 125)
        assertSame(match, best)
    }

    @Test
    fun aTitleThatOnlyContainsTheWantedWordsIsRejected() {
        // "Love Story" is not "Love": the length is 30 s off, so there is no real evidence.
        val other = record(1, "Love Story", "Artist A", 230.0, plain = "la")
        assertNull(TrackMatcher.pickBest(listOf(other), TrackQuery("Love", "Artist A"), 200))
    }

    @Test
    fun aResultWithAnotherLengthIsRejectedEvenWithTheRightTitle() {
        val longer = record(1, "Hello", "Adele", 260.0, plain = "la")
        assertNull(TrackMatcher.pickBest(listOf(longer), TrackQuery("Hello", "Adele"), 200))
    }

    @Test
    fun withoutAnArtistTheTitleAndTheLengthMustBothMatch() {
        val hello = record(1, "Hello", "Adele", 200.0, plain = "la")
        assertSame(hello, TrackMatcher.pickBest(listOf(hello), TrackQuery("Hello"), 200))
        // length of the song unknown: not enough evidence
        assertNull(TrackMatcher.pickBest(listOf(hello), TrackQuery("Hello"), null))
    }

    @Test
    fun recordsWithoutLyricsAreIgnored() {
        val empty = record(1, "Hello", "Adele", 200.0)
        val instrumental = record(2, "Hello", "Adele", 200.0, plain = "la", instrumental = true)
        assertNull(TrackMatcher.pickBest(listOf(empty, instrumental), TrackQuery("Hello", "Adele"), 200))
    }

    @Test
    fun anEmptyWantedTitleMatchesNothing() {
        val any = record(1, "Hello", "Adele", 200.0, plain = "la")
        assertNull(TrackMatcher.pickBest(listOf(any), TrackQuery("(live)", "Adele"), 200))
    }

    @Test
    fun theFullestLyricsWinOverABetterScore() {
        // A matches the length exactly but has 4 lines; B is 3 s off but has 40 lines.
        val short = record(1, "Song", "Band", 200.0, synced = lrc(4))
        val full  = record(2, "Song", "Band", 203.0, synced = lrc(40))
        val best = TrackMatcher.pickBest(listOf(short, full), TrackQuery("Song", "Band"), 200)
        assertSame(full, best)
    }

    @Test
    fun insideTheSameCompletenessTierTheBetterMatchWins() {
        // 40 and 38 lines are both "full"; the one with the exact length wins.
        val offBy4  = record(1, "Song", "Band", 204.0, synced = lrc(40))
        val exact   = record(2, "Song", "Band", 200.0, synced = lrc(38))
        val best = TrackMatcher.pickBest(listOf(offBy4, exact), TrackQuery("Song", "Band"), 200)
        assertSame(exact, best)
    }

    @Test
    fun manualModeTrustsTheTitleButStillChecksTheLength() {
        val otherArtist = record(1, "Some Song", "Other Person", null, plain = "la")
        val query = TrackQuery("Some Song", "Someone")
        assertNull(TrackMatcher.pickBest(listOf(otherArtist), query, null))
        assertSame(otherArtist, TrackMatcher.pickBest(listOf(otherArtist), query, null, lenient = true))

        val tooLong = record(2, "Some Song", "Someone", 206.0, plain = "la")
        assertNull(TrackMatcher.pickBest(listOf(tooLong), query, 200, lenient = true))
    }

    // ── lineCount / rankLoosely ───────────────────────────────────────────────

    @Test
    fun lineCountIsTheLargerOfTheSyncedAndPlainVersions() {
        assertEquals(5, TrackMatcher.lineCount(record(1, "A", "B", synced = lrc(3), plain = "a\nb\nc\nd\ne")))
        assertEquals(3, TrackMatcher.lineCount(record(2, "A", "B", synced = lrc(3))))
        assertEquals(0, TrackMatcher.lineCount(record(3, "A", "B")))
    }

    @Test
    fun rankLooselyPutsTheBestMatchFirst() {
        val exact   = record(1, "Love", "Artist A", 200.0, synced = lrc(10))
        val partial = record(2, "Love Story", "Artist A", 200.0, synced = lrc(10))
        val unrelated = record(3, "Other", "Someone else", 200.0, synced = lrc(10))
        val a = TrackMatcher.rankLoosely(exact, "Love", "Artist A", 200)
        val b = TrackMatcher.rankLoosely(partial, "Love", "Artist A", 200)
        val c = TrackMatcher.rankLoosely(unrelated, "Love", "Artist A", 200)
        assertTrue(a > b)
        assertTrue(b > c)
    }
}
