package com.melodiq.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaTagsTest {

    @Test
    fun missingOrBlankTagsAreNotKnown() {
        assertFalse(MediaTags.isKnown(null))
        assertFalse(MediaTags.isKnown(""))
        assertFalse(MediaTags.isKnown("   "))
    }

    @Test
    fun placeholdersAreNotKnown() {
        assertFalse(MediaTags.isKnown("<unknown>"))
        assertFalse(MediaTags.isKnown("Unknown"))
        assertFalse(MediaTags.isKnown("  UNKNOWN ARTIST "))
        assertFalse(MediaTags.isKnown("unknown album"))
    }

    @Test
    fun realNamesAreKnown() {
        assertTrue(MediaTags.isKnown("Queen"))
        assertTrue(MediaTags.isKnown("  Queen  "))
    }

    @Test
    fun cleanReturnsTheFallbackForMissingTags() {
        assertEquals(MediaTags.UNKNOWN_ARTIST, MediaTags.clean(null, MediaTags.UNKNOWN_ARTIST))
        assertEquals(MediaTags.UNKNOWN_ARTIST, MediaTags.clean("<unknown>", MediaTags.UNKNOWN_ARTIST))
        assertEquals(MediaTags.UNKNOWN_ALBUM, MediaTags.clean("", MediaTags.UNKNOWN_ALBUM))
    }

    @Test
    fun cleanTrimsRealTags() {
        assertEquals("Queen", MediaTags.clean("  Queen ", MediaTags.UNKNOWN_ARTIST))
    }
}
