package com.melodiq.util

import com.melodiq.data.model.LyricLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricsQualityTest {

    private fun timed(count: Int, stepMs: Long = 9_000L): List<LyricLine> =
        List(count) { i -> LyricLine(i * stepMs, "line $i") }

    private fun plain(count: Int): String =
        (0 until count).joinToString("\n") { i -> "line $i" }

    // ── plainLines ────────────────────────────────────────────────────────────

    @Test
    fun plainLinesSkipBlanksAndSectionTags() {
        val lines = LyricsQuality.plainLines("Line one\n\n[Chorus]\nLine two\n  \nLine three  ")
        assertEquals(listOf("Line one", "Line two", "Line three"), lines)
    }

    @Test
    fun aTagFollowedByWordsIsStillALine() {
        assertEquals(listOf("[Verse 1] la la"), LyricsQuality.plainLines("[Verse 1] la la"))
    }

    @Test
    fun noPlainTextMeansNoLines() {
        assertTrue(LyricsQuality.plainLines(null).isEmpty())
        assertTrue(LyricsQuality.plainLines("   ").isEmpty())
        assertEquals(0, LyricsQuality.plainLineCount(null))
        assertEquals(3, LyricsQuality.plainLineCount("a\nb\nc"))
    }

    // ── assess ────────────────────────────────────────────────────────────────

    @Test
    fun syncedThatCoversThePlainTextIsComplete() {
        assertFalse(LyricsQuality.assess(timed(10), plain(10), 200_000L).possiblyIncomplete)
        assertFalse(LyricsQuality.assess(timed(9), plain(10), 200_000L).possiblyIncomplete)
    }

    @Test
    fun syncedThatStopsEarlyComparedWithThePlainTextIsIncomplete() {
        assertTrue(LyricsQuality.assess(timed(5), plain(12), 200_000L).possiblyIncomplete)
        assertTrue(LyricsQuality.assess(timed(7), plain(10), 200_000L).possiblyIncomplete)
    }

    @Test
    fun theAssessmentReportsTheLineCounts() {
        val assessment = LyricsQuality.assess(timed(5), plain(12), 200_000L)
        assertEquals(5, assessment.syncedLines)
        assertEquals(12, assessment.plainLines)
    }

    @Test
    fun syncedOnlyIsJudgedByHowMuchOfTheSongItCovers() {
        // 3 lines for a 200 s song: too few
        assertTrue(LyricsQuality.assess(timed(3), null, 200_000L).possiblyIncomplete)
        // 20 lines up to 171 s of 200 s: fine
        assertFalse(LyricsQuality.assess(timed(20), null, 200_000L).possiblyIncomplete)
        // 20 lines but they end at 60 s of a 240 s song: only a quarter covered
        assertTrue(LyricsQuality.assess(timed(20, 3_000L), null, 240_000L).possiblyIncomplete)
    }

    @Test
    fun shortOrUnknownLengthSongsAreNotJudgedBySyncedCoverage() {
        assertFalse(LyricsQuality.assess(timed(3), null, 100_000L).possiblyIncomplete)
        assertFalse(LyricsQuality.assess(timed(3), null, 0L).possiblyIncomplete)
    }

    @Test
    fun plainOnlyIsSuspiciousWhenTooShortForALongSong() {
        assertTrue(LyricsQuality.assess(emptyList(), plain(5), 200_000L).possiblyIncomplete)
        assertFalse(LyricsQuality.assess(emptyList(), plain(10), 200_000L).possiblyIncomplete)
        assertFalse(LyricsQuality.assess(emptyList(), plain(5), 100_000L).possiblyIncomplete)
    }

    @Test
    fun noLyricsAtAllIsNotIncomplete() {
        assertFalse(LyricsQuality.assess(emptyList(), null, 200_000L).possiblyIncomplete)
        val untimedOnly = listOf(LyricLine(Long.MAX_VALUE, "tail", isTimed = false))
        assertFalse(LyricsQuality.assess(untimedOnly, null, 200_000L).possiblyIncomplete)
    }

    // ── withMissingTail ───────────────────────────────────────────────────────

    @Test
    fun theMissingPlainLinesAreAppendedWithoutTiming() {
        val synced = listOf(
            LyricLine(1_000L, "one"),
            LyricLine(2_000L, "two"),
            LyricLine(3_000L, "three")
        )
        val result = LyricsQuality.withMissingTail(synced, "one\ntwo\nthree\nfour\nfive")
        assertEquals(5, result.size)
        assertEquals(listOf("four", "five"), result.drop(3).map { it.text })
        assertTrue(result.drop(3).none { it.isTimed })
        assertTrue(result.take(3).all { it.isTimed })
    }

    @Test
    fun nothingIsAddedWhenThePlainTextIsNotLonger() {
        val synced = listOf(LyricLine(1_000L, "one"), LyricLine(2_000L, "two"))
        assertSame(synced, LyricsQuality.withMissingTail(synced, "one\ntwo"))
    }

    @Test
    fun nothingIsAddedWhenTheVersionsDoNotLineUp() {
        val synced = listOf(LyricLine(1_000L, "aaa"), LyricLine(2_000L, "bbb"))
        assertSame(synced, LyricsQuality.withMissingTail(synced, "xxx\nyyy\nzzz"))
    }

    @Test
    fun noSyncedLinesStayNoSyncedLines() {
        val none = emptyList<LyricLine>()
        assertSame(none, LyricsQuality.withMissingTail(none, "one\ntwo"))
    }
}
