package com.melodiq.util

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ShuffleDeckTest {

    @Test
    fun freshDeckHasEverySongOnceAndTheCurrentOneFirst() {
        val order = ShuffleDeck.fresh(10, 3, Random(42))
        assertEquals(3, order[0])
        assertEquals((0 until 10).toList(), order.sorted())
    }

    @Test
    fun freshDeckWithoutAValidFirstSongIsStillAPermutation() {
        assertEquals((0 until 5).toList(), ShuffleDeck.fresh(5, -1, Random(1)).sorted())
        assertEquals((0 until 5).toList(), ShuffleDeck.fresh(5, 5, Random(1)).sorted())
    }

    @Test
    fun freshDeckHandlesTinyQueues() {
        assertEquals(0, ShuffleDeck.fresh(0, 0, Random(1)).size)
        assertArrayEquals(intArrayOf(0), ShuffleDeck.fresh(1, 0, Random(1)))
    }

    @Test
    fun theSameSeedGivesTheSameDeck() {
        assertArrayEquals(
            ShuffleDeck.fresh(20, 0, Random(7)),
            ShuffleDeck.fresh(20, 0, Random(7))
        )
    }

    @Test
    fun resumeKeepsPlayedSongsBehindTheCurrentOne() {
        val deck = ShuffleDeck.resume(6, 2, listOf(4, 0), Random(5))
        assertFalse(deck.newPass)
        assertEquals(listOf(4, 0, 2), deck.order.take(3))
        assertEquals(listOf(1, 3, 5), deck.order.drop(3).sorted())
    }

    @Test
    fun resumeIgnoresDuplicatesInvalidPositionsAndTheCurrentSong() {
        val deck = ShuffleDeck.resume(4, 1, listOf(1, 9, -1, 0, 0), Random(3))
        assertFalse(deck.newPass)
        assertEquals(0, deck.order[0])
        assertEquals(1, deck.order[1])
        assertEquals(listOf(2, 3), deck.order.drop(2).sorted())
    }

    @Test
    fun resumeStartsANewPassWhenEverythingWasPlayed() {
        val deck = ShuffleDeck.resume(3, 1, listOf(0, 2), Random(9))
        assertTrue(deck.newPass)
        assertEquals(1, deck.order[0])
        assertEquals(listOf(0, 1, 2), deck.order.sorted())
    }

    @Test
    fun aSingleSongIsNotANewPass() {
        val deck = ShuffleDeck.resume(1, 0, emptyList(), Random(1))
        assertFalse(deck.newPass)
        assertArrayEquals(intArrayOf(0), deck.order)
    }

    @Test
    fun resumeAlwaysGivesAPermutation() {
        for (seed in 0 until 50) {
            val deck = ShuffleDeck.resume(8, 3, listOf(5, 1), Random(seed))
            assertEquals((0 until 8).toList(), deck.order.sorted())
            assertEquals(3, deck.order[2])
        }
    }
}
