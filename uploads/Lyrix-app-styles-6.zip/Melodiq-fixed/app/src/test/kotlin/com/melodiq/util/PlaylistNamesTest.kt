package com.melodiq.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PlaylistNamesTest {

    @Test
    fun normalizeTrimsAndCollapsesWhitespace() {
        assertEquals("My playlist", PlaylistNames.normalize("  My   playlist \n"))
        assertEquals("a b", PlaylistNames.normalize("a\n\nb"))
        assertEquals("", PlaylistNames.normalize("   "))
    }

    @Test
    fun normalizeCapsTheLength() {
        assertEquals(PlaylistNames.MAX_LENGTH, PlaylistNames.normalize("x".repeat(60)).length)
        // The cap may cut right after a space; that space must not stay at the end.
        val cut = PlaylistNames.normalize("a".repeat(PlaylistNames.MAX_LENGTH - 1) + " b")
        assertEquals("a".repeat(PlaylistNames.MAX_LENGTH - 1), cut)
    }

    @Test
    fun anEmptyNameIsRejected() {
        assertEquals("Give the playlist a name", PlaylistNames.error("   ", emptyList()))
    }

    @Test
    fun aDuplicateNameIsRejectedIgnoringCase() {
        val message = "You already have a playlist with this name"
        assertEquals(message, PlaylistNames.error("Rock", listOf("Pop", "rock")))
        assertEquals(message, PlaylistNames.error("  Rock  ", listOf("ROCK")))
    }

    @Test
    fun aDuplicateIsFoundAfterTheLengthCap() {
        val long = "x".repeat(60)
        val message = "You already have a playlist with this name"
        assertEquals(message, PlaylistNames.error(long, listOf("x".repeat(PlaylistNames.MAX_LENGTH))))
    }

    @Test
    fun aFreeNameIsAccepted() {
        assertNull(PlaylistNames.error("Rock", listOf("Pop")))
        assertNull(PlaylistNames.error("Rock", emptyList()))
    }
}
