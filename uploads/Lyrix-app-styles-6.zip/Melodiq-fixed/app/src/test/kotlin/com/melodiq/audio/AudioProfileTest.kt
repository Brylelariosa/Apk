package com.melodiq.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioProfileTest {

    private fun profileWithLows(vararg lows: Float): AudioProfile {
        val profile = AudioProfile(songId = 1L, durationMs = 60_000L)
        for (low in lows) profile.addHop(low, 0f, 0f)
        return profile
    }

    @Test
    fun aLevelBetweenTwoStepsIsInterpolated() {
        // Steps are 20 ms apart: 0, 20, 40, 60 ms.
        val profile = profileWithLows(0f, 1f, 0f, 0f)
        assertEquals(0.5f, profile.level(Band.LOW, 10L), 0.01f)
        assertEquals(1f, profile.level(Band.LOW, 20L), 0.01f)
        assertEquals(0.5f, profile.level(Band.LOW, 30L), 0.01f)
    }

    @Test
    fun aSongIsCoveredOnlyWhereTheAnalysisHasBeen() {
        val profile = profileWithLows(0f, 0f, 0f, 0f, 0f, 0f)
        assertTrue(profile.covers(0L))
        assertTrue(profile.covers(60L))
        assertFalse(profile.covers(80L))
        assertFalse(profile.covers(-1L))
    }

    @Test
    fun msSinceBeatFindsTheLastBeatNotAfterThePosition() {
        val profile = AudioProfile(songId = 1L, durationMs = 60_000L)
        profile.addBeat(500)
        profile.addBeat(1_000)
        profile.addBeat(1_500)
        assertEquals(NO_BEAT, profile.msSinceBeat(400L))
        assertEquals(0, profile.msSinceBeat(500L))
        assertEquals(250, profile.msSinceBeat(750L))
        assertEquals(100, profile.msSinceBeat(1_600L))
    }

    @Test
    fun noBeatsMeansNoBeat() {
        assertEquals(NO_BEAT, AudioProfile(songId = 1L, durationMs = 60_000L).msSinceBeat(5_000L))
    }
}
