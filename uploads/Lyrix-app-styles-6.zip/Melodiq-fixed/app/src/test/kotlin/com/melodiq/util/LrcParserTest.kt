package com.melodiq.util

import com.melodiq.data.model.LyricLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {

    @Test
    fun centisecondTimestampsBecomeMilliseconds() {
        val lines = LrcParser.parse("[00:12.34]Hello\n[01:02.50]World")
        assertEquals(listOf(12_340L, 62_500L), lines.map { it.timeMs })
        assertEquals(listOf("Hello", "World"), lines.map { it.text })
    }

    @Test
    fun otherFractionLengthsAreUnderstood() {
        assertEquals(5_123L, LrcParser.parse("[00:05.123]a").single().timeMs)  // milliseconds
        assertEquals(5_500L, LrcParser.parse("[00:05.5]a").single().timeMs)    // tenths
        assertEquals(7_000L, LrcParser.parse("[00:07]a").single().timeMs)      // no fraction
        assertEquals(7_250L, LrcParser.parse("[00:07:25]a").single().timeMs)   // colon before the fraction
        assertEquals(605_000L, LrcParser.parse("[10:05.00]a").single().timeMs) // minutes past 9
    }

    @Test
    fun linesAreSortedByTime() {
        val lines = LrcParser.parse("[00:20.00]second\n[00:10.00]first")
        assertEquals(listOf("first", "second"), lines.map { it.text })
    }

    @Test
    fun aLineWithSeveralTimestampsIsRepeated() {
        val lines = LrcParser.parse("[00:10.00][01:30.00]Chorus")
        assertEquals(listOf(10_000L, 90_000L), lines.map { it.timeMs })
        assertEquals(listOf("Chorus", "Chorus"), lines.map { it.text })
    }

    @Test
    fun metadataTagsAreIgnored() {
        val lines = LrcParser.parse("[ar:Artist]\n[ti:Title]\n[offset:+300]\n[00:01.00]Hi")
        assertEquals(1, lines.size)
        assertEquals("Hi", lines[0].text)
    }

    @Test
    fun wordTimingTagsAreStripped() {
        val lines = LrcParser.parse("[00:12.00]<00:12.00>Hel<00:12.40>lo")
        assertEquals("Hello", lines.single().text)
    }

    @Test
    fun blankAndUntimedLinesAreSkipped() {
        val lines = LrcParser.parse("[00:05.00]\nJust text\n[00:06.00]Line")
        assertEquals(1, lines.size)
        assertEquals(6_000L, lines[0].timeMs)
    }

    @Test
    fun windowsLineEndingsWork() {
        assertEquals(2, LrcParser.parse("[00:01.00]A\r\n[00:02.00]B").size)
    }

    @Test
    fun emptyInputGivesNoLines() {
        assertTrue(LrcParser.parse("").isEmpty())
    }

    // ── activeIndex ───────────────────────────────────────────────────────────

    private val lines = listOf(
        LyricLine(1_000L, "a"),
        LyricLine(2_000L, "b"),
        LyricLine(3_000L, "c")
    )

    @Test
    fun noLineIsActiveBeforeTheFirstOne() {
        assertEquals(-1, LrcParser.activeIndex(lines, 0L))
        assertEquals(-1, LrcParser.activeIndex(lines, 999L))
    }

    @Test
    fun aLineBecomesActiveExactlyAtItsTime() {
        assertEquals(0, LrcParser.activeIndex(lines, 1_000L))
        assertEquals(0, LrcParser.activeIndex(lines, 1_999L))
        assertEquals(1, LrcParser.activeIndex(lines, 2_000L))
        assertEquals(2, LrcParser.activeIndex(lines, 10_000L))
    }

    @Test
    fun seekingBackwardsGivesAnEarlierLine() {
        assertEquals(2, LrcParser.activeIndex(lines, 3_500L))
        assertEquals(0, LrcParser.activeIndex(lines, 1_200L))
    }

    @Test
    fun emptyListHasNoActiveLine() {
        assertEquals(-1, LrcParser.activeIndex(emptyList(), 500L))
    }

    @Test
    fun untimedLinesAreNeverActive() {
        val withTail = listOf(
            LyricLine(1_000L, "a"),
            LyricLine(Long.MAX_VALUE, "tail", isTimed = false)
        )
        assertEquals(0, LrcParser.activeIndex(withTail, 5_000L))
        assertEquals(0, LrcParser.activeIndex(withTail, Long.MAX_VALUE - 1))
    }
}
