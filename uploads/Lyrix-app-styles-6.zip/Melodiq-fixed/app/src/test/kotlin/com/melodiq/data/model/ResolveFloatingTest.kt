package com.melodiq.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResolveFloatingTest {

    private val default = FloatingLyricsSettings(enabled = true, textSizeSp = 18f, posX = 0.5f, posY = 0.14f)

    private fun profile(packageName: String, posY: Float, visible: Boolean = true) = AppLyricsProfile(
        packageName = packageName,
        label       = packageName,
        visible     = visible,
        style       = FloatingLyricsSettings(textSizeSp = 24f, posX = 0.2f, posY = posY)
    )

    private val profiles = AppProfiles(
        enabled = true,
        apps    = listOf(profile("com.instagram", 0.8f), profile("com.hidden", 0.3f, visible = false))
    )

    @Test
    fun anAppOnTheListUsesItsOwnStyleAndSpot() {
        val resolved = resolveFloating(default, profiles, "com.instagram")
        assertEquals(24f, resolved.style.textSizeSp, 0f)
        assertEquals(0.8f, resolved.style.posY, 0f)
        assertEquals("com.instagram", resolved.packageName)
        assertTrue(resolved.visible)
    }

    @Test
    fun anAppOnTheListCanAskForNoFloatingWindow() {
        assertFalse(resolveFloating(default, profiles, "com.hidden").visible)
    }

    @Test
    fun anAppNotOnTheListUsesTheDefaultStyleAndSpot() {
        val resolved = resolveFloating(default, profiles, "com.android.chrome")
        assertEquals(default, resolved.style)
        assertTrue(resolved.visible)
    }

    @Test
    fun aDragInAnAppNotOnTheListChangesTheDefaultAndNeverAddsTheApp() {
        // packageName null = "the default is in use": the overlay then saves a drag as the default position
        assertNull(resolveFloating(default, profiles, "com.android.chrome").packageName)
    }

    @Test
    fun everyAppNotOnTheListResolvesToTheSameThing() {
        // Equal results mean the window is not placed again when going from one such app to another.
        val chrome   = resolveFloating(default, profiles, "com.android.chrome")
        val whatsapp = resolveFloating(default, profiles, "com.whatsapp")
        assertEquals(chrome, whatsapp)
    }

    @Test
    fun theHomeScreenAndMenuUseTheDefaultStyleLikeAnyOtherApp() {
        // They have no style of their own: the same style and the same spot as every app not on the list,
        // and a drag there changes the default (packageName null), it never starts a style of its own.
        val home = resolveFloating(default, profiles, HOME_SCREEN_KEY)
        assertEquals(default, home.style)
        assertNull(home.packageName)
        assertTrue(home.visible)
        assertEquals(resolveFloating(default, profiles, "com.android.chrome"), home)
    }

    @Test
    fun aHomeScreenStyleStoredByAnOlderVersionIsIgnored() {
        val withOldHome = profiles.copy(apps = profiles.apps + profile(HOME_SCREEN_KEY, 0.6f))
        val home = resolveFloating(default, withOldHome, HOME_SCREEN_KEY)
        assertEquals(default, home.style)
        assertNull(home.packageName)
    }

    @Test
    fun withStylesPerAppSwitchedOffEveryAppUsesTheDefault() {
        val off = profiles.copy(enabled = false)
        val resolved = resolveFloating(default, off, "com.instagram")
        assertEquals(default, resolved.style)
        assertNull(resolved.packageName)
        assertTrue(resolved.visible)
    }

    @Test
    fun whenTheAppOnScreenIsUnknownTheDefaultIsUsed() {
        val resolved = resolveFloating(default, profiles, null)
        assertEquals(default, resolved.style)
        assertNull(resolved.packageName)
    }

    @Test
    fun theWhenToShowSwitchesStayTheSameForEveryApp() {
        // The profile was made with the switches at their defaults (enabled = false); the default style rules.
        val resolved = resolveFloating(default, profiles, "com.instagram")
        assertTrue(resolved.style.enabled)
        assertEquals(default.hideInApp, resolved.style.hideInApp)
        assertEquals(default.hideWhenNoLyrics, resolved.style.hideWhenNoLyrics)
    }
}
