package com.melodiq.util

import android.content.Context
import android.net.Uri
import com.melodiq.crash.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Reads a small text file (an .lrc or .txt the user picked) from a content:// uri. */
object TextFileReader {

    private const val MAX_BYTES = 1_000_000

    /** Returns the text, or null when the file is too big, empty or unreadable. */
    suspend fun read(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val bytes = readLimited(input)
                if (bytes == null || bytes.isEmpty()) null else decode(bytes)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppLog.w("TextFileReader", "could not read $uri", e)
            null
        }
    }

    /**
     * Reads the stream piece by piece and gives up (null) as soon as more than [MAX_BYTES] have come in,
     * so a huge file picked by mistake is never loaded into memory.
     */
    private fun readLimited(input: InputStream): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > MAX_BYTES) return null
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    private fun decode(bytes: ByteArray): String {
        // skip a UTF-8 byte-order mark
        var start = 0
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
        ) {
            start = 3
        }
        val utf8 = String(bytes, start, bytes.size - start, Charsets.UTF_8)
        // Old .lrc files are often saved in a legacy 8-bit encoding; UTF-8 then shows replacement characters.
        return if (utf8.contains('\uFFFD')) {
            String(bytes, start, bytes.size - start, Charsets.ISO_8859_1)
        } else {
            utf8
        }
    }
}
