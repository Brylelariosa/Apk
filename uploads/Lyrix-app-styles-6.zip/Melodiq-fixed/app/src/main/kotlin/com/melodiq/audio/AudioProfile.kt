package com.melodiq.audio

/** How long one step of the analysis is. Everything in an [AudioProfile] is one value per step. */
const val HOP_MS = 20

/** What [AudioProfile.msSinceBeat] returns while no beat has been found yet. */
const val NO_BEAT = Int.MAX_VALUE

/** The three parts of the music the floating lyrics move with. */
enum class Band { LOW, MID, HIGH }

/**
 * What one song is doing, step by step: how strong its low (drums, bass), middle (voice, guitars) and high
 * (hats, air) parts are, and when its beats fall. [BeatAnalyzer] fills it in from the song file while the
 * song is already playing, so the first seconds can be read before the rest exists.
 *
 * Everything is indexed by the position in the song, not by the clock, so seeking, pausing and a slow phone
 * can not put it out of step with the music.
 *
 * One thread writes (the analyzer), another reads (the UI). The write order (data first, then the counter)
 * and the volatile counters make that safe without a lock.
 */
class AudioProfile(val songId: Long, durationMs: Long) {

    private val capacity: Int =
        (durationMs.coerceIn(MIN_CAPACITY_MS, MAX_ANALYSED_MS) / HOP_MS).toInt() + 64

    private val low = ByteArray(capacity)
    private val mid = ByteArray(capacity)
    private val high = ByteArray(capacity)
    private val beats = IntArray(capacity / 8 + 16)

    /** How many steps are filled in so far. */
    @Volatile
    var hops: Int = 0
        private set

    /** How many beats were found so far. */
    @Volatile
    var beatCount: Int = 0
        private set

    /** True once the analysis is over (done, failed or stopped): nothing more will be added. */
    @Volatile
    var finished: Boolean = false
        internal set

    internal fun addHop(lowLevel: Float, midLevel: Float, highLevel: Float): Boolean {
        val n = hops
        if (n >= capacity) return false
        low[n] = quantize(lowLevel)
        mid[n] = quantize(midLevel)
        high[n] = quantize(highLevel)
        hops = n + 1
        return true
    }

    internal fun addBeat(positionMs: Int) {
        val n = beatCount
        if (n >= beats.size) return
        beats[n] = positionMs
        beatCount = n + 1
    }

    /** True when the analysis has got far enough to describe the music at [positionMs]. */
    fun covers(positionMs: Long): Boolean {
        if (positionMs < 0L) return false
        return positionMs / HOP_MS + 2 < hops
    }

    /** How strong [band] is at [positionMs], from 0 (nothing) to 1 (as loud as this song gets). */
    fun level(band: Band, positionMs: Long): Float {
        val data = when (band) {
            Band.LOW  -> low
            Band.MID  -> mid
            Band.HIGH -> high
        }
        val n = hops
        if (n == 0) return 0f
        val exact = positionMs.coerceAtLeast(0L).toFloat() / HOP_MS
        val i = exact.toInt()
        if (i >= n - 1) return (data[n - 1].toInt() and 0xFF) / 255f
        val frac = exact - i
        val a = data[i].toInt() and 0xFF
        val b = data[i + 1].toInt() and 0xFF
        return (a + (b - a) * frac) / 255f
    }

    /** Milliseconds since the last beat at or before [positionMs], or [NO_BEAT] when there was none. */
    fun msSinceBeat(positionMs: Long): Int {
        val n = beatCount
        if (n == 0) return NO_BEAT
        val position = positionMs.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
        var lo = 0
        var hi = n - 1
        var found = -1
        while (lo <= hi) {
            val middle = (lo + hi) ushr 1
            if (beats[middle] <= position) {
                found = middle
                lo = middle + 1
            } else {
                hi = middle - 1
            }
        }
        return if (found < 0) NO_BEAT else position - beats[found]
    }

    private fun quantize(value: Float): Byte =
        (value.coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()

    private companion object {
        const val MIN_CAPACITY_MS = 60_000L
        /** Nothing past this is analysed: it keeps a very long mix from taking minutes and memory. */
        const val MAX_ANALYSED_MS = 45 * 60_000L
    }
}
