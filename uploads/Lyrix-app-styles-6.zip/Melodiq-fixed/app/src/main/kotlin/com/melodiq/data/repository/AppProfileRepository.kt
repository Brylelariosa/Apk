package com.melodiq.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.melodiq.crash.AppLog
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.AppProfiles
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.HOME_SCREEN_KEY
import com.melodiq.data.model.sanitized
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "AppProfiles"

/**
 * The floating-lyrics style of each app, kept in DataStore so it is already set the next time the
 * app is on screen.
 *
 * The profiles are one JSON text (a list of objects) under a single key. A value that is missing or
 * out of range falls back to the default, so a profile written by an older or newer version of the
 * app can always be read. [state] is the single source of truth, exactly like
 * [SettingsRepository.settings]: the music service (floating window) and the Settings screen both
 * read it.
 */
@Singleton
class AppProfileRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // A failed read (an IOException) is tried again after a short wait, so one bad moment does not freeze
    // the styles until the app restarts. Anything else falls back to no profiles.
    val state: StateFlow<AppProfiles> = dataStore.data
        .retryWhen { cause, attempt ->
            if (cause is IOException) {
                delay(1000L * minOf(attempt + 1, 5L))
                true
            } else {
                false
            }
        }
        .map { decode(it) }
        .catch { emit(AppProfiles()) }
        .stateIn(scope, SharingStarted.Eagerly, AppProfiles())

    /** Applies [transform] to the stored profiles. Safe to call from any thread. */
    fun update(transform: (AppProfiles) -> AppProfiles) {
        scope.launch {
            try {
                dataStore.edit { prefs -> encode(prefs, transform(decode(prefs))) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppLog.w(TAG, "could not save the per-app styles", e)
            }
        }
    }

    fun setEnabled(on: Boolean) = update { it.copy(enabled = on) }

    /** Adds the profile, or replaces the one the app already has. */
    fun upsert(profile: AppLyricsProfile) = update { it.copy(apps = it.apps.withProfile(profile)) }

    /**
     * Changes the profile of [key] (an app's package name, or HOME_SCREEN_KEY). A slot that has no profile
     * yet gets one first, made from [defaults] (the default style), so the first change starts from what the
     * user saw on screen.
     */
    fun change(
        key: String,
        label: String,
        defaults: FloatingLyricsSettings,
        transform: (AppLyricsProfile) -> AppLyricsProfile
    ) = update { current ->
        val base = current.find(key) ?: AppLyricsProfile(key, label, visible = true, style = defaults)
        current.copy(apps = current.apps.withProfile(transform(base)))
    }

    fun remove(packageName: String) = update { current ->
        current.copy(apps = current.apps.filterNot { it.packageName == packageName })
    }

    /**
     * Remembers where the user dropped the window in [packageName]. Only an app that is on the list can
     * remember a spot. Any other app is left alone: dragging in an app that is not on the list never adds
     * it, it keeps the default style (the overlay saves that position as the default one).
     */
    fun savePosition(
        packageName: String,
        posX: Float,
        posY: Float
    ) = update { current ->
        val existing = current.find(packageName) ?: return@update current
        val saved = existing.copy(style = existing.style.copy(posX = posX, posY = posY))
        current.copy(apps = current.apps.withProfile(saved))
    }

    private fun List<AppLyricsProfile>.withProfile(profile: AppLyricsProfile): List<AppLyricsProfile> {
        val index = indexOfFirst { it.packageName == profile.packageName }
        return if (index < 0) this + profile else toMutableList().also { it[index] = profile }
    }

    // ── Keys ─────────────────────────────────────────────────────────────────

    private object K {
        val enabled  = booleanPreferencesKey("fl_per_app")
        val profiles = stringPreferencesKey("fl_app_profiles")
    }

    // The home screen & menu used to have a style slot of their own. They use the default style now, so a
    // slot stored by an older version is dropped here (it is gone from the stored text with the next save).
    private fun decode(p: Preferences): AppProfiles = AppProfiles(
        enabled = p[K.enabled] ?: true,
        apps    = Json.decodeAll(p[K.profiles]).filter { it.packageName != HOME_SCREEN_KEY }
    )

    private fun encode(p: MutablePreferences, s: AppProfiles) {
        p[K.enabled]  = s.enabled
        p[K.profiles] = Json.encodeAll(s.apps)
    }

    // ── JSON ─────────────────────────────────────────────────────────────────

    private object Json {

        fun encodeAll(apps: List<AppLyricsProfile>): String {
            val array = JSONArray()
            for (app in apps) array.put(encode(app))
            return array.toString()
        }

        fun decodeAll(text: String?): List<AppLyricsProfile> {
            if (text.isNullOrBlank()) return emptyList()
            return try {
                val array = JSONArray(text)
                val result = ArrayList<AppLyricsProfile>(array.length())
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val profile = decode(item) ?: continue
                    if (result.none { it.packageName == profile.packageName }) result.add(profile)
                }
                result
            } catch (e: JSONException) {
                AppLog.w(TAG, "the stored per-app styles are unreadable", e)
                emptyList()
            }
        }

        private fun encode(app: AppLyricsProfile): JSONObject {
            val s = app.style
            val o = JSONObject()
            o.put("pkg", app.packageName)
            o.put("label", app.label)
            o.put("visible", app.visible)
            o.put("lines", s.lines)
            o.put("size", s.textSizeSp.toDouble())
            o.put("color", s.textColor)
            o.put("dim", s.inactiveAlpha.toDouble())
            o.put("font", s.font.name)
            o.put("weight", s.weight.name)
            o.put("align", s.alignment.name)
            o.put("shadow", s.textShadow)
            o.put("bg", s.backgroundColor)
            o.put("bgAlpha", s.backgroundAlpha.toDouble())
            o.put("radius", s.cornerRadiusDp)
            o.put("alpha", s.windowAlpha.toDouble())
            o.put("width", s.widthFraction.toDouble())
            o.put("locked", s.locked)
            o.put("x", s.posX.toDouble())
            o.put("y", s.posY.toDouble())
            o.put("anim", s.animation.name)
            o.put("animMs", s.animationMs)
            o.put("backdrop", s.backdrop.name)
            o.put("beat", s.beatPulse)
            o.put("title", s.showTitle)
            o.put("controls", s.showControls)
            return o
        }

        private fun decode(o: JSONObject): AppLyricsProfile? {
            val pkg = o.optString("pkg", "")
            if (pkg.isBlank()) return null
            val d = FloatingLyricsSettings()
            val style = FloatingLyricsSettings(
                lines           = o.optInt("lines", d.lines),
                textSizeSp      = o.optDouble("size", d.textSizeSp.toDouble()).toFloat(),
                textColor       = o.optInt("color", d.textColor),
                inactiveAlpha   = o.optDouble("dim", d.inactiveAlpha.toDouble()).toFloat(),
                font            = enumOf(o, "font", d.font),
                weight          = enumOf(o, "weight", d.weight),
                alignment       = enumOf(o, "align", d.alignment),
                textShadow      = o.optBoolean("shadow", d.textShadow),
                backgroundColor = o.optInt("bg", d.backgroundColor),
                backgroundAlpha = o.optDouble("bgAlpha", d.backgroundAlpha.toDouble()).toFloat(),
                cornerRadiusDp  = o.optInt("radius", d.cornerRadiusDp),
                windowAlpha     = o.optDouble("alpha", d.windowAlpha.toDouble()).toFloat(),
                widthFraction   = o.optDouble("width", d.widthFraction.toDouble()).toFloat(),
                locked          = o.optBoolean("locked", d.locked),
                posX            = o.optDouble("x", d.posX.toDouble()).toFloat(),
                posY            = o.optDouble("y", d.posY.toDouble()).toFloat(),
                animation       = enumOf(o, "anim", d.animation),
                animationMs     = o.optInt("animMs", d.animationMs),
                backdrop        = enumOf(o, "backdrop", d.backdrop),
                beatPulse       = o.optBoolean("beat", d.beatPulse),
                showTitle       = o.optBoolean("title", d.showTitle),
                showControls    = o.optBoolean("controls", d.showControls)
            ).sanitized()
            return AppLyricsProfile(
                packageName = pkg,
                label       = o.optString("label", pkg).ifBlank { pkg },
                visible     = o.optBoolean("visible", true),
                style       = style
            )
        }

        private inline fun <reified E : Enum<E>> enumOf(o: JSONObject, key: String, default: E): E {
            val name = o.optString(key, "")
            return enumValues<E>().firstOrNull { it.name == name } ?: default
        }
    }
}
