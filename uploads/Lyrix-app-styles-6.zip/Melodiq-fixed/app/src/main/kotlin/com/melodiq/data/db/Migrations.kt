package com.melodiq.data.db

import androidx.room.migration.Migration

/**
 * Every migration of the database, oldest first. It is empty while the schema is at version 1.
 *
 * To change a table:
 *  1. raise `version` in [AppDatabase];
 *  2. add a Migration here, for example
 *
 *         private val MIGRATION_1_2 = object : Migration(1, 2) {
 *             override fun migrate(db: SupportSQLiteDatabase) {
 *                 db.execSQL("ALTER TABLE songs ADD COLUMN genre TEXT NOT NULL DEFAULT ''")
 *             }
 *         }
 *         val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)
 *
 *     (SupportSQLiteDatabase is androidx.sqlite.db.SupportSQLiteDatabase);
 *  3. build once and keep the new file from app/schemas (the CI run uploads that folder), so the next
 *     migration can be checked against it.
 *
 * Playlists, favourites and the saved lyrics live in this database, so a missing migration must never
 * be "fixed" by wiping it: without one Room stops with an error instead.
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
