package com.melodiq.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.melodiq.data.db.dao.FavoriteDao
import com.melodiq.data.db.dao.RecentlyPlayedDao
import com.melodiq.data.db.dao.SongDao
import com.melodiq.data.db.entity.FavoriteEntity
import com.melodiq.data.db.entity.RecentlyPlayedEntity
import com.melodiq.data.db.entity.SongEntity
import com.melodiq.data.model.Song
import com.melodiq.util.MediaTags
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.withContext
import java.text.Collator
import java.text.Normalizer
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MusicRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val songDao: SongDao,
    private val recentlyPlayedDao: RecentlyPlayedDao,
    private val favoriteDao: FavoriteDao
) {
    private val albumArtBaseUri = Uri.parse("content://media/external/audio/albumart")

    // VOLUME_EXTERNAL covers the SD card as well as internal storage (Android 10+).
    private val audioCollection: Uri =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

    // The shared flows below live as long as the repository (a singleton), not as long as one screen.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * The songs table, sorted by title once per change of the table. Every list below is built from this
     * one flow, so the table is watched once and sorted once, however many screens are open.
     */
    private val sortedEntities: Flow<List<SongEntity>> = songDao.observeAll()
        .map { entities -> sortByTitle(entities) }
        .shareIn(scope, SharingStarted.WhileSubscribed(5_000), replay = 1)

    /** The favourite song ids (newest first), watched once. */
    private val favoriteIds: Flow<List<Long>> = favoriteDao.observeAll()
        .shareIn(scope, SharingStarted.WhileSubscribed(5_000), replay = 1)

    val allSongs: Flow<List<Song>> = combine(sortedEntities, favoriteIds) { entities, favorites ->
        val favSet = favorites.toSet()
        entities.map { it.toSong(favSet.contains(it.id)) }
    }.flowOn(Dispatchers.Default)

    val recentSongs: Flow<List<Song>> = combine(
        recentlyPlayedDao.observeRecentIds(),
        sortedEntities,
        favoriteIds
    ) { recentIds, entities, favorites ->
        val map    = entities.associateBy { it.id }
        val favSet = favorites.toSet()
        recentIds.mapNotNull { id -> map[id]?.toSong(favSet.contains(id)) }
    }.flowOn(Dispatchers.Default)

    val favoriteSongs: Flow<List<Song>> = combine(favoriteIds, sortedEntities) { favorites, entities ->
        val map = entities.associateBy { it.id }
        favorites.mapNotNull { id -> map[id]?.toSong(true) }
    }.flowOn(Dispatchers.Default)

    /**
     * Songs whose title, artist or album contains [query]. It looks through the songs already in memory;
     * capitals and accents are ignored on both sides ("beyonce" finds "Beyoncé").
     */
    fun searchSongs(query: String): Flow<List<Song>> {
        val needle = foldForSearch(query)
        return allSongs.map { songs ->
            songs.filter { song ->
                foldForSearch(song.title).contains(needle) ||
                    foldForSearch(song.artist).contains(needle) ||
                    foldForSearch(song.album).contains(needle)
            }
        }.flowOn(Dispatchers.Default)
    }

    suspend fun syncLibrary(): Int = withContext(Dispatchers.IO) {
        val songs = scanMediaStore()

        // Write only the rows that are new or different. An unchanged library then leaves the songs
        // table alone, so nothing that watches the table wakes up for no reason.
        val known   = songDao.getAll().associateBy { it.id }
        val changed = songs.map { it.toEntity() }.filter { known[it.id] != it }
        if (changed.isNotEmpty()) {
            songDao.upsertAll(changed)
        }

        // BUG FIX A: only remove songs that are gone when the scan found something.
        //
        // scanMediaStore() legitimately returns 0 results for a brief window right after Android grants
        // the storage permission — the OS hasn't finished propagating the permission to MediaStore's
        // ContentProvider yet. Treating that as "every song was deleted" would erase all previously
        // synced songs.
        if (songs.isNotEmpty()) {
            val scanned = HashSet<Long>(songs.size * 2)
            for (song in songs) scanned.add(song.id)
            // Songs in the table that the scan did not return. Deleted in chunks: SQLite takes at most
            // 999 values in one IN (...) on Android 11 and older.
            val gone = songDao.getAllIds().filter { it !in scanned }
            for (chunk in gone.chunked(DELETE_CHUNK_SIZE)) {
                songDao.deleteByIds(chunk)
            }
        }

        songs.size
    }

    suspend fun getSongById(id: Long): Song? = withContext(Dispatchers.IO) {
        val entity = songDao.getById(id) ?: return@withContext null
        // BUG FIX B: the original code did:
        //   favoriteDao.observeAll().let { emptySet<Long>() }
        // which discards the Flow and always returns an empty set.
        // Fix: collect one emission with .first().
        val isFav = favoriteDao.isFavorite(entity.id).first()
        entity.toSong(isFav)
    }

    suspend fun markRecentlyPlayed(songId: Long) = withContext(Dispatchers.IO) {
        recentlyPlayedDao.upsert(RecentlyPlayedEntity(songId = songId))
        recentlyPlayedDao.trimToMax()
    }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        if (isFavorite) favoriteDao.upsert(FavoriteEntity(songId = songId))
        else favoriteDao.delete(songId)
    }

    fun isFavorite(songId: Long): Flow<Boolean> = favoriteDao.isFavorite(songId)

    // ── MediaStore scan ──────────────────────────────────────────────────────

    private fun scanMediaStore(): List<Song> {
        val songs      = mutableListOf<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 " +
                        "AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            audioCollection,
            projection, selection, null, sortOrder
        )?.use { cursor ->
            val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val albumIdCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (cursor.moveToNext()) {
                val id      = cursor.getLong(idCol)
                val albumId = cursor.getLong(albumIdCol)
                songs.add(
                    Song(
                        id         = id,
                        title      = cursor.getString(titleCol)?.trim()?.takeIf { it.isNotEmpty() }
                                         ?: MediaTags.UNKNOWN_TITLE,
                        // MediaStore returns "<unknown>" (not null) when a tag is missing.
                        artist     = MediaTags.clean(cursor.getString(artistCol), MediaTags.UNKNOWN_ARTIST),
                        album      = MediaTags.clean(cursor.getString(albumCol),  MediaTags.UNKNOWN_ALBUM),
                        duration   = cursor.getLong(durationCol),
                        uri        = ContentUris.withAppendedId(audioCollection, id),
                        artworkUri = ContentUris.withAppendedId(albumArtBaseUri, albumId),
                        size       = cursor.getLong(sizeCol),
                        dateAdded  = cursor.getLong(dateCol),
                        albumId    = albumId
                    )
                )
            }
        }
        return songs
    }

    // ── Mappers ──────────────────────────────────────────────────────────────

    private fun Song.toEntity() = SongEntity(
        id = id, title = title, artist = artist, album = album,
        duration = duration, uriString = uri.toString(),
        artworkUriString = artworkUri?.toString(),
        size = size, dateAdded = dateAdded, albumId = albumId
    )

    private fun SongEntity.toSong(isFav: Boolean) = Song(
        id = id, title = title,
        // rows saved by older versions may still contain MediaStore's "<unknown>"
        artist = MediaTags.clean(artist, MediaTags.UNKNOWN_ARTIST),
        album  = MediaTags.clean(album,  MediaTags.UNKNOWN_ALBUM),
        duration = duration,
        uri        = Uri.parse(uriString),
        artworkUri = artworkUriString?.let { Uri.parse(it) },
        size = size, dateAdded = dateAdded, albumId = albumId,
        isFavorite = isFav
    )

    // ── Sorting and searching ────────────────────────────────────────────────

    /** Title order that follows the phone's language (accents and capitals do not decide it); the id breaks ties. */
    private fun sortByTitle(entities: List<SongEntity>): List<SongEntity> {
        val collator = Collator.getInstance().apply { strength = Collator.PRIMARY }
        return entities.sortedWith(Comparator<SongEntity> { a, b ->
            val byTitle = collator.compare(a.title, b.title)
            if (byTitle != 0) byTitle else a.id.compareTo(b.id)
        })
    }

    /** Lower case, accents removed: "Beyoncé" becomes "beyonce". */
    private fun foldForSearch(text: String): String =
        COMBINING_MARKS.replace(Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD), "")

    private companion object {
        /** How many ids one DELETE ... IN (...) gets. */
        const val DELETE_CHUNK_SIZE = 500

        /** The accent marks left over after Normalizer splits "é" into "e" and a mark. */
        val COMBINING_MARKS = Regex("\\p{M}+")
    }
}
