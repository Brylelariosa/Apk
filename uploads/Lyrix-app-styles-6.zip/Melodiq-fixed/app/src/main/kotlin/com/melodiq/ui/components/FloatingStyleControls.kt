package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.FloatingBackdrop
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsWeight
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/*
 * The options that decide how the floating lyrics look, in four groups. The Floating lyrics page shows one
 * group at a time under a live preview, so nothing needs a long scroll. They are used for the default
 * style and for the style of one app alike, so both always offer the same choices.
 *
 * [update] changes the style being edited, whichever one it is. The "when to show" switches are not here:
 * they are the same for every app.
 */

/** The groups of options on the Floating lyrics page. */
enum class StyleTab(val label: String) {
    TEXT("Text"),
    WINDOW("Window"),
    MOTION("Motion"),
    MORE("More")
}

/** How the words look. */
@Composable
fun TextStyleControls(
    floating: FloatingLyricsSettings,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit
) {
    ChoiceRow(
        title    = "Lines shown",
        options  = listOf(1, 2, 3, 4, 5),
        selected = floating.lines,
        label    = { it.toString() },
        onSelect = { choice -> update { it.copy(lines = choice) } }
    )
    SliderRow(
        title      = "Text size",
        value      = floating.textSizeSp,
        range      = 10f..40f,
        valueLabel = { it.toInt().toString() + " sp" },
        onCommit   = { v -> update { it.copy(textSizeSp = v) } }
    )
    ChoiceRow(
        title    = "Font",
        options  = LyricsFont.values().toList(),
        selected = floating.font,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(font = choice) } }
    )
    ChoiceRow(
        title    = "Weight",
        options  = LyricsWeight.values().toList(),
        selected = floating.weight,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(weight = choice) } }
    )
    ChoiceRow(
        title    = "Alignment",
        options  = LyricsAlign.values().toList(),
        selected = floating.alignment,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(alignment = choice) } }
    )
    ColorRow(
        title    = "Text colour",
        selected = floating.textColor,
        onSelect = { argb -> update { it.copy(textColor = argb) } }
    )
    SliderRow(
        title      = "Other lines brightness",
        value      = floating.inactiveAlpha,
        range      = 0.1f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
    )
    SwitchRow(
        title    = "Text shadow",
        subtitle = "Keeps the words readable on any background.",
        checked  = floating.textShadow,
        onChange = { on -> update { it.copy(textShadow = on) } }
    )
}

/** How the window itself looks. Where it is on the screen is set on the little phone above. */
@Composable
fun WindowStyleControls(
    floating: FloatingLyricsSettings,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit
) {
    SliderRow(
        title      = "Width",
        value      = floating.widthFraction,
        range      = 0.4f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(widthFraction = v) } }
    )
    SliderRow(
        title      = "Background opacity",
        value      = floating.backgroundAlpha,
        range      = 0f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(backgroundAlpha = v) } }
    )
    SliderRow(
        title      = "Window opacity",
        value      = floating.windowAlpha,
        range      = 0.2f..1f,
        valueLabel = { percent(it) },
        onCommit   = { v -> update { it.copy(windowAlpha = v) } }
    )
    SliderRow(
        title      = "Corner radius",
        value      = floating.cornerRadiusDp.toFloat(),
        range      = 0f..40f,
        valueLabel = { it.toInt().toString() + " dp" },
        onCommit   = { v -> update { it.copy(cornerRadiusDp = v.toInt()) } }
    )
    ColorRow(
        title    = "Background colour",
        selected = floating.backgroundColor,
        onSelect = { argb -> update { it.copy(backgroundColor = argb) } }
    )
    ResetRow(
        text    = "Reset position",
        onReset = {
            val start = FloatingLyricsSettings()
            update { it.copy(posX = start.posX, posY = start.posY) }
        }
    )
}

/** How the window moves: the change from one line to the next, and the picture that follows the music. */
@Composable
fun MotionStyleControls(
    floating: FloatingLyricsSettings,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit
) {
    ChoiceRow(
        title    = "When the line changes",
        options  = LineAnimation.values().toList(),
        selected = floating.animation,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(animation = choice) } }
    )
    SliderRow(
        title      = "Animation length",
        value      = floating.animationMs.toFloat(),
        range      = 100f..800f,
        valueLabel = { it.toInt().toString() + " ms" },
        onCommit   = { v -> update { it.copy(animationMs = v.toInt()) } }
    )
    ChoiceRow(
        title    = "Moving background",
        options  = FloatingBackdrop.values().toList(),
        selected = floating.backdrop,
        label    = { it.label },
        onSelect = { choice -> update { it.copy(backdrop = choice) } }
    )
    SwitchRow(
        title    = "Swell on the beat",
        subtitle = "The sung line and the background grow a little on every beat.",
        checked  = floating.beatPulse,
        onChange = { on -> update { it.copy(beatPulse = on) } }
    )
}

/** What else is in the window. */
@Composable
fun ExtraStyleControls(
    floating: FloatingLyricsSettings,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit
) {
    SwitchRow(
        title    = "Show song title",
        checked  = floating.showTitle,
        onChange = { on -> update { it.copy(showTitle = on) } }
    )
    SwitchRow(
        title    = "Show playback buttons",
        checked  = floating.showControls,
        onChange = { on -> update { it.copy(showControls = on) } }
    )
    SwitchRow(
        title    = "Lock position",
        subtitle = "Touches pass through the window to the app below. Unlock it here to move it again.",
        checked  = floating.locked,
        onChange = { on -> update { it.copy(locked = on) } }
    )
}

/**
 * The real floating window, drawn with the settings as they are right now, advancing by itself and moving
 * to a made-up groove. It is laid out at the width it really has on a phone and then shrunk to fit the
 * space it is given, so the words wrap exactly like they will in the real window. One of the sample lines is
 * long on purpose, to show what a long line does.
 *
 * When the animation or its length is changed the line moves on at once, so the change can be seen.
 */
@Composable
fun FloatingPreview(floating: FloatingLyricsSettings, modifier: Modifier = Modifier) {
    val sample = remember {
        listOf(
            "Walking down the quiet street",
            "Streetlights painting gold on glass",
            "Every little thing I need is right here while the moments pass us by",
            "So play the song again",
            "And let the night go slow",
            "Hold on to this feeling"
        ).mapIndexed { index, text -> LyricLine(timeMs = index * 4_000L, text = text) }
    }
    val sampleLines = remember(sample) { sample.map { it.text } }
    var index by remember { mutableIntStateOf(1) }
    LaunchedEffect(floating.animation, floating.animationMs) {
        index = (index + 1) % sample.size
        while (true) {
            delay(4_000L)
            index = (index + 1) % sample.size
        }
    }
    val window = remember(index, floating.lines) { buildLyricWindow(sample, index, floating.lines) }
    val motion = rememberMusicMotion(running = true)
    val screenWidthDp = LocalConfiguration.current.screenWidthDp

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3A2A6B), Color(0xFF1B6B7A))))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        FloatingLyricsCard(
            window    = window,
            settings  = floating,
            modifier  = Modifier.fitScaled(screenWidthDp * floating.widthFraction),
            title     = if (floating.showTitle) "Song title \u2014 Artist" else null,
            isPlaying = true,
            songLines = sampleLines,
            motion    = motion
        )
    }
}

/**
 * Lays the content out [widthDp] wide and as tall as it needs, then shrinks it (never enlarges it) until it
 * fits the space this modifier is given. The shrinking is a drawing scale, so the text wraps the way it
 * would at full size.
 */
private fun Modifier.fitScaled(widthDp: Float): Modifier = layout { measurable, constraints ->
    val widthPx = widthDp.dp.roundToPx().coerceAtLeast(1)
    val placeable = measurable.measure(
        Constraints(minWidth = widthPx, maxWidth = widthPx, minHeight = 0, maxHeight = Constraints.Infinity)
    )
    val fitWidth = if (constraints.hasBoundedWidth) constraints.maxWidth / widthPx.toFloat() else 1f
    val fitHeight = if (constraints.hasBoundedHeight && placeable.height > 0) {
        constraints.maxHeight / placeable.height.toFloat()
    } else {
        1f
    }
    val scale = minOf(1f, fitWidth, fitHeight)
    layout((placeable.width * scale).roundToInt(), (placeable.height * scale).roundToInt()) {
        placeable.placeWithLayer(0, 0) {
            scaleX = scale
            scaleY = scale
            transformOrigin = TransformOrigin(0f, 0f)
        }
    }
}
