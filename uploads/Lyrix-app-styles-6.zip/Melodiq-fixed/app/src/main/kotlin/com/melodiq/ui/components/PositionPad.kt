package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.White20
import kotlin.math.roundToInt

/**
 * A little phone screen that shows where the floating lyrics are and lets you put them anywhere: touch the
 * spot, or drag the window. The window is drawn as wide as it really is (the width setting) and about as
 * tall as it really is (the lines and text size), so what you see is what you get.
 *
 * The position is stored as fractions: [FloatingLyricsSettings.posX] is how far along the free width the
 * window is, [FloatingLyricsSettings.posY] how far down the screen its top is. This pad uses the same
 * formulas as the real window, so both end up in the same place.
 *
 * [onPlace] is called when the finger is lifted (or on a tap), not on every pixel, so nothing is written
 * while dragging.
 */
@Composable
fun PositionPad(
    floating: FloatingLyricsSettings,
    onPlace: (posX: Float, posY: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val screenHeightDp = LocalConfiguration.current.screenHeightDp.coerceAtLeast(1)
    val windowHeightShare = remember(
        floating.lines, floating.textSizeSp, floating.showTitle, floating.showControls, screenHeightDp
    ) {
        (estimatedWindowHeightDp(floating) / screenHeightDp).coerceIn(0.03f, 0.5f)
    }
    val latestOnPlace by rememberUpdatedState(onPlace)

    // Where the window is while it is being placed. Null: where it is stored. It is cleared when the stored
    // position changes, which is the moment the new one has arrived, so the window never jumps back.
    var placed by remember { mutableStateOf<Offset?>(null) }
    LaunchedEffect(floating.posX, floating.posY) { placed = null }
    val posX = placed?.x ?: floating.posX
    val posY = placed?.y ?: floating.posY

    val shape = RoundedCornerShape(14.dp)
    BoxWithConstraints(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2B2250), Color(0xFF120E26))))
            .border(1.dp, White20, shape)
            .semantics { contentDescription = "Where the floating lyrics appear. Touch or drag to move them." }
    ) {
        val padWidth = constraints.maxWidth.toFloat()
        val padHeight = constraints.maxHeight.toFloat()
        val windowWidth = padWidth * floating.widthFraction
        val windowHeight = padHeight * windowHeightShare
        val density = LocalDensity.current

        // A touch puts the CENTRE of the window under the finger, as far as the screen allows.
        fun placeAt(touch: Offset): Offset {
            val freeX = (padWidth - windowWidth).coerceAtLeast(1f)
            val freeY = (padHeight - windowHeight).coerceAtLeast(1f)
            val x = ((touch.x - windowWidth / 2f) / freeX).coerceIn(0f, 1f)
            val y = ((touch.y - windowHeight / 2f) / padHeight).coerceIn(0f, freeY / padHeight)
            return Offset(x, y)
        }

        // The notch and the bar at the bottom: just enough to read as a phone.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 5.dp)
                .size(width = 18.dp, height = 3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.18f))
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 5.dp)
                .size(width = 26.dp, height = 3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.18f))
        )

        val left = posX * (padWidth - windowWidth).coerceAtLeast(0f)
        val top = (posY * padHeight).coerceAtMost((padHeight - windowHeight).coerceAtLeast(0f))
        Box(
            modifier = Modifier
                .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
                .size(
                    width = with(density) { windowWidth.toDp() },
                    height = with(density) { windowHeight.toDp() }
                )
                .clip(RoundedCornerShape(5.dp))
                .background(Brush.horizontalGradient(listOf(PrimaryPurple, AccentPink)))
                .border(1.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(5.dp))
        )

        // The touch layer is on top of everything, so a touch on the window itself works too.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(padWidth, padHeight, windowWidth, windowHeight) {
                    detectTapGestures(
                        onTap = { touch ->
                            val spot = placeAt(touch)
                            placed = spot
                            latestOnPlace(spot.x, spot.y)
                        }
                    )
                }
                .pointerInput(padWidth, padHeight, windowWidth, windowHeight) {
                    detectDragGestures(
                        onDragStart = { touch -> placed = placeAt(touch) },
                        onDrag = { change, _ ->
                            change.consume()
                            placed = placeAt(change.position)
                        },
                        onDragEnd = {
                            val spot = placed
                            if (spot != null) latestOnPlace(spot.x, spot.y)
                        },
                        onDragCancel = {
                            val spot = placed
                            if (spot != null) latestOnPlace(spot.x, spot.y)
                        }
                    )
                }
        )
    }
}

/** About how tall the real window is, in dp: its padding, the optional title and buttons, and the rows. */
private fun estimatedWindowHeightDp(f: FloatingLyricsSettings): Float {
    val size = f.textSizeSp
    val sungLine = size * 1.25f * 1.4f
    val otherLines = (f.lines - 1) * size * 0.82f * 1.25f
    val gaps = f.lines * 4f
    val title = if (f.showTitle) 18f else 0f
    val buttons = if (f.showControls) 56f else 0f
    return 24f + title + sungLine + otherLines + gaps + buttons
}
