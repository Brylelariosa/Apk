package com.melodiq

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.melodiq.ui.theme.MelodiqTheme
import com.melodiq.ui.AppRoot
import com.melodiq.ui.components.CrashReportPrompt
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The UI is always dark, so the bars always get light icons (the default picks dark icons when the
        // phone is in light mode, and they vanish on the dark UI).
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            MelodiqTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                    CrashReportPrompt()
                }
            }
        }
    }
}
