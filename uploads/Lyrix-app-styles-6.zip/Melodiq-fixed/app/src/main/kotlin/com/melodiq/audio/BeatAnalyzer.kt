package com.melodiq.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Process
import android.util.LruCache
import com.melodiq.crash.AppLog
import com.melodiq.data.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.coroutineContext
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Listens to the song FILE (not to the speaker or the microphone, so no permission is needed) and builds an
 * [AudioProfile]: how loud its low, middle and high parts are and where its beats fall. The floating lyrics
 * use it to move with the music.
 *
 * The file is decoded once, on a low-priority thread of its own, a good deal faster than it plays, and the
 * result is kept for the last few songs. The profile can be read while it is still being built, so the
 * start of the song is usable after a moment. If the file can not be decoded for any reason the profile
 * simply stays short and the animation falls back to a steady made-up beat: nothing ever fails loudly.
 */
@Singleton
class BeatAnalyzer @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val worker = Executors.newSingleThreadExecutor(ThreadFactory { task ->
        Thread({
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            } catch (ignored: Throwable) {
            }
            task.run()
        }, "lyrix-beats").apply { isDaemon = true }
    })
    private val scope = CoroutineScope(SupervisorJob() + worker.asCoroutineDispatcher())

    private val cache = LruCache<Long, AudioProfile>(CACHE_SIZE)
    private val _current = MutableStateFlow<AudioProfile?>(null)

    /** The profile of the song that is [prepare]d, or null. It may still be growing. */
    val current: StateFlow<AudioProfile?> = _current.asStateFlow()

    private var job: Job? = null
    private var currentId = -1L

    /**
     * Starts listening to [song] (or does nothing when it is already done or under way). Null stops
     * everything. Call it from one thread, the main thread.
     */
    fun prepare(song: Song?) {
        if (song == null) {
            cancelRunning()
            currentId = -1L
            _current.value = null
            return
        }
        if (song.id == currentId) return
        cancelRunning()
        currentId = song.id

        val known = cache.get(song.id)
        if (known != null) {
            _current.value = known
            return
        }
        val profile = AudioProfile(song.id, song.duration)
        cache.put(song.id, profile)
        _current.value = profile
        job = scope.launch {
            try {
                analyze(song.uri, profile)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                AppLog.w(TAG, "could not analyse song ${song.id}", e)
            } finally {
                profile.finished = true
            }
        }
    }

    private fun cancelRunning() {
        val running = job
        if (running != null && running.isActive) {
            // What it has is only the start of that song: listen to it again the next time.
            cache.remove(currentId)
            running.cancel()
        }
        job = null
    }

    private suspend fun analyze(uri: Uri, profile: AudioProfile) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) return
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return
            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(format, null, null, 0)
            decoder.start()
            decode(extractor, decoder, format, profile)
        } finally {
            try {
                codec?.stop()
            } catch (ignored: Throwable) {
            }
            try {
                codec?.release()
            } catch (ignored: Throwable) {
            }
            try {
                extractor.release()
            } catch (ignored: Throwable) {
            }
        }
    }

    private suspend fun decode(
        extractor: MediaExtractor,
        decoder: MediaCodec,
        inputFormat: MediaFormat,
        profile: AudioProfile
    ) {
        val dsp = HopAnalyzer(profile)
        dsp.configure(
            sampleRate = intOf(inputFormat, MediaFormat.KEY_SAMPLE_RATE, 44_100),
            channels   = intOf(inputFormat, MediaFormat.KEY_CHANNEL_COUNT, 2),
            floatPcm   = false
        )
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var idleRounds = 0
        var rounds = 0

        while (!outputDone && !dsp.full) {
            rounds++
            if (rounds % CANCEL_CHECK_EVERY == 0) coroutineContext.ensureActive()

            if (!inputDone) {
                val index = decoder.dequeueInputBuffer(TIMEOUT_US)
                if (index >= 0) {
                    val input = decoder.getInputBuffer(index)
                    val size = if (input != null) extractor.readSampleData(input, 0) else -1
                    if (size < 0) {
                        decoder.queueInputBuffer(index, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        decoder.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            val out = decoder.dequeueOutputBuffer(info, TIMEOUT_US)
            when {
                out >= 0 -> {
                    idleRounds = 0
                    val buffer = decoder.getOutputBuffer(out)
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        dsp.feed(buffer)
                    }
                    decoder.releaseOutputBuffer(out, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
                out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val changed = decoder.outputFormat
                    dsp.configure(
                        sampleRate = intOf(changed, MediaFormat.KEY_SAMPLE_RATE, 44_100),
                        channels   = intOf(changed, MediaFormat.KEY_CHANNEL_COUNT, 2),
                        floatPcm   = isFloat(changed)
                    )
                }
                else -> {
                    // Nothing ready yet. Once the whole file was handed over, do not wait forever.
                    if (inputDone) {
                        idleRounds++
                        if (idleRounds > MAX_IDLE_ROUNDS) outputDone = true
                    }
                }
            }
        }
    }

    private fun intOf(format: MediaFormat, key: String, fallback: Int): Int =
        if (format.containsKey(key)) format.getInteger(key) else fallback

    private fun isFloat(format: MediaFormat): Boolean =
        format.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
            format.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT

    private companion object {
        const val TAG = "BeatAnalyzer"
        const val CACHE_SIZE = 6
        const val TIMEOUT_US = 10_000L
        const val CANCEL_CHECK_EVERY = 32
        const val MAX_IDLE_ROUNDS = 300
    }
}

/**
 * Turns decoded sound into one set of numbers per [HOP_MS] and finds the beats.
 *
 * To stay cheap it looks at about a quarter of the samples (it averages four into one) and splits the sound
 * into three bands with simple one-pole filters instead of a Fourier transform: a few multiplications per
 * sample, no allocation. That is plenty to see where the drums hit and how the music swells.
 */
private class HopAnalyzer(private val profile: AudioProfile) {

    private var channels = 2
    private var floatPcm = false
    private var aLow = 0.05f
    private var aMid = 0.4f
    private var hopSamples = 220

    // Filter memory: the low band is two one-pole stages, the others one.
    private var lp1 = 0f
    private var lp1b = 0f
    private var lp2 = 0f

    // Averages four samples into one.
    private var acc = 0f
    private var accCount = 0

    // The energy of the hop being built.
    private var sumLow = 0f
    private var sumMid = 0f
    private var sumHigh = 0f
    private var hopCount = 0

    // The loudest recent value of each band, which slowly forgets so a quiet part still moves things.
    private var refLow = MIN_REF
    private var refMid = MIN_REF
    private var refHigh = MIN_REF

    // Beat finding: the low band over the last moments, and the two hops before the current one.
    private val history = FloatArray(HISTORY_HOPS)
    private var historyFill = 0
    private var historyPos = 0
    private var historySum = 0.0
    private var prev1 = 0f
    private var prev2 = 0f
    private var hopIndex = 0
    private var lastBeatMs = -10_000

    /** True once the profile has no room left. */
    var full = false
        private set

    fun configure(sampleRate: Int, channels: Int, floatPcm: Boolean) {
        this.channels = max(1, channels)
        this.floatPcm = floatPcm
        val rate = max(8_000, sampleRate) / DECIMATE.toFloat()
        aLow = 1f - exp(-TWO_PI * LOW_CUTOFF_HZ / rate)
        aMid = 1f - exp(-TWO_PI * MID_CUTOFF_HZ / rate)
        hopSamples = max(1, (rate * HOP_MS / 1000f).toInt())
    }

    /** Takes one buffer of decoded sound (16-bit, or float when [configure] said so). */
    fun feed(buffer: ByteBuffer) {
        buffer.order(ByteOrder.nativeOrder())
        val used = if (channels > 1) 2 else 1
        if (floatPcm) {
            val samples = buffer.asFloatBuffer()
            val frames = samples.remaining() / channels
            for (frame in 0 until frames) {
                var sum = 0f
                for (c in 0 until channels) {
                    val s = samples.get()
                    if (c < used) sum += s
                }
                push(sum / used)
                if (full) return
            }
        } else {
            val samples = buffer.asShortBuffer()
            val frames = samples.remaining() / channels
            for (frame in 0 until frames) {
                var sum = 0f
                for (c in 0 until channels) {
                    val s = samples.get().toInt()
                    if (c < used) sum += s
                }
                push(sum / (used * 32_768f))
                if (full) return
            }
        }
    }

    private fun push(sample: Float) {
        acc += sample
        accCount++
        if (accCount < DECIMATE) return
        val x = acc / DECIMATE
        acc = 0f
        accCount = 0

        lp1 += aLow * (x - lp1)
        lp1b += aLow * (lp1 - lp1b)
        lp2 += aMid * (x - lp2)
        val lowSignal = lp1b
        val midSignal = lp2 - lp1
        val highSignal = x - lp2
        sumLow += lowSignal * lowSignal
        sumMid += midSignal * midSignal
        sumHigh += highSignal * highSignal
        hopCount++
        if (hopCount >= hopSamples) endHop()
    }

    private fun endHop() {
        val n = hopSamples.toFloat()
        val rmsLow = sqrt(sumLow / n)
        val rmsMid = sqrt(sumMid / n)
        val rmsHigh = sqrt(sumHigh / n)
        sumLow = 0f
        sumMid = 0f
        sumHigh = 0f
        hopCount = 0

        refLow = max(max(refLow * REF_DECAY, rmsLow), MIN_REF)
        refMid = max(max(refMid * REF_DECAY, rmsMid), MIN_REF)
        refHigh = max(max(refHigh * REF_DECAY, rmsHigh), MIN_REF)

        val added = profile.addHop(
            shape(rmsLow / refLow),
            shape(rmsMid / refMid),
            shape(rmsHigh / refHigh)
        )
        if (!added) {
            full = true
            return
        }
        detectBeat(rmsLow)
        hopIndex++
    }

    /** Quiet parts count as nothing, the loudest as everything. */
    private fun shape(ratio: Float): Float =
        ((ratio - LEVEL_FLOOR) / (1f - LEVEL_FLOOR)).coerceIn(0f, 1f)

    /**
     * A beat is a short rise of the low band: a peak that is clearly above the recent average, not tiny
     * next to the loudest recent low sound, and not right after another beat. The peak is only known one
     * hop later, so the hop BEFORE this one is the candidate; the hit itself began a little before it.
     */
    private fun detectBeat(current: Float) {
        val average = if (historyFill > 0) (historySum / historyFill).toFloat() else 0f
        if (hopIndex >= 2) {
            val peakMs = (hopIndex - 1) * HOP_MS
            // The filtered peak comes about two hops after the hit itself (measured on test music).
            val onsetMs = max(0, peakMs - 2 * HOP_MS)
            if (prev1 > average * BEAT_RATIO &&
                prev1 > refLow * BEAT_FLOOR &&
                prev1 >= prev2 &&
                prev1 > current &&
                onsetMs - lastBeatMs >= MIN_BEAT_GAP_MS
            ) {
                profile.addBeat(onsetMs)
                lastBeatMs = onsetMs
            }
        }
        if (historyFill == HISTORY_HOPS) {
            historySum -= history[historyPos]
        } else {
            historyFill++
        }
        history[historyPos] = current
        historySum += current
        historyPos = (historyPos + 1) % HISTORY_HOPS
        prev2 = prev1
        prev1 = current
    }

    private companion object {
        const val DECIMATE = 4
        const val LOW_CUTOFF_HZ = 140f
        const val MID_CUTOFF_HZ = 2_200f
        const val TWO_PI = 6.2831855f
        const val MIN_REF = 1e-4f
        const val REF_DECAY = 0.9994f
        const val LEVEL_FLOOR = 0.22f
        const val HISTORY_HOPS = 40
        const val BEAT_RATIO = 1.32f
        const val BEAT_FLOOR = 0.28f
        const val MIN_BEAT_GAP_MS = 290
    }
}
