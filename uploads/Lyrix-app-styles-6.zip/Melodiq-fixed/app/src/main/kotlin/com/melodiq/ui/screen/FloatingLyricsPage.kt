package com.melodiq.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.overlay.UsageAccessPermission
import com.melodiq.ui.components.AppIcon
import com.melodiq.ui.components.AppPickerDialog
import com.melodiq.ui.components.ExtraStyleControls
import com.melodiq.ui.components.FloatingPreview
import com.melodiq.ui.components.GlassCard
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.MotionStyleControls
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.OptionChip
import com.melodiq.ui.components.PositionPad
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.StyleTab
import com.melodiq.ui.components.SubHeading
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.TextStyleControls
import com.melodiq.ui.components.UsageAccessDialog
import com.melodiq.ui.components.WindowStyleControls
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White10
import com.melodiq.ui.viewmodel.AppProfilesViewModel

/** The height of the live preview and of the little phone next to it. */
private val PreviewHeight = 176.dp

/** The shape of a phone screen: width divided by height. */
private const val PHONE_ASPECT = 9f / 19.5f

/**
 * On a screen at least this tall (in dp) the top of the page stays in view and only the options scroll.
 * On a shorter one there would be no room left for the options, so the whole page scrolls instead.
 */
private const val PINNED_MIN_HEIGHT_DP = 720

/**
 * Everything about the floating lyrics on ONE page that does not need a long scroll.
 *
 * At the top, always in view: the switch, the style being edited ("All apps", which is also the home screen &
 * menu, or one app that has a look of its own), a live preview and a little phone to place the window on.
 * Under them four short groups of options (Text, Window, Motion, More), one at a time. A change shows in the
 * preview at once, and is saved at once.
 */
@Composable
fun FloatingLyricsPage(
    overlayAllowed: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onAskPermission: () -> Unit,
    onResetDefault: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AppProfilesViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val defaultStyle by viewModel.defaultStyle.collectAsStateWithLifecycle()

    // The style being edited: null is the default one, an app's package name is that app's own style.
    var target by rememberSaveable { mutableStateOf<String?>(null) }
    var tab by rememberSaveable { mutableStateOf(StyleTab.TEXT.ordinal) }
    var pickingApp by remember { mutableStateOf(false) }
    var showUsageDialog by remember { mutableStateOf(false) }
    var usageAllowed by remember { mutableStateOf(UsageAccessPermission.isGranted(context)) }
    OnResumeEffect { usageAllowed = UsageAccessPermission.isGranted(context) }

    val apps = remember(profiles.apps) { profiles.appsOnly.sortedBy { it.label.lowercase() } }
    val app = target?.let { profiles.find(it) }
    val style = app?.style ?: defaultStyle
    val update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit = { transform ->
        if (app != null) {
            viewModel.updateStyle(app.packageName, app.label, transform)
        } else {
            viewModel.updateDefaultStyle(transform)
        }
    }

    if (pickingApp) {
        AppPickerDialog(
            alreadyAdded = apps.map { it.packageName }.toSet(),
            loadApps     = { viewModel.launchableApps() },
            onPick       = { picked ->
                pickingApp = false
                viewModel.addApp(picked)
                target = picked.packageName
                if (!usageAllowed) showUsageDialog = true
            },
            onDismiss    = { pickingApp = false }
        )
    }
    if (showUsageDialog) {
        UsageAccessDialog(
            onDismiss      = { showUsageDialog = false },
            onOpenSettings = {
                showUsageDialog = false
                UsageAccessPermission.openSettings(context)
            }
        )
    }

    val pinned = LocalConfiguration.current.screenHeightDp >= PINNED_MIN_HEIGHT_DP
    val pageScroll = rememberScrollState()

    // The options of the chosen group, in one card. The same in both layouts below.
    val options: @Composable () -> Unit = {
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                when (StyleTab.values()[tab.coerceIn(0, StyleTab.values().size - 1)]) {
                    StyleTab.TEXT   -> TextStyleControls(style, update)
                    StyleTab.WINDOW -> WindowStyleControls(style, update)
                    StyleTab.MOTION -> MotionStyleControls(style, update)
                    StyleTab.MORE   -> {
                        ExtraStyleControls(style, update)
                        MoreOptions(
                            app             = app,
                            appCount        = apps.size,
                            defaultStyle    = defaultStyle,
                            perAppEnabled   = profiles.enabled,
                            onGlobal        = { transform -> viewModel.updateDefaultStyle(transform) },
                            onPerApp        = { on -> viewModel.setEnabled(on) },
                            onShowHere      = { on ->
                                if (app != null) viewModel.setVisible(app.packageName, app.label, on)
                            },
                            onUseDefault    = {
                                if (app != null) viewModel.useDefaultStyle(app.packageName, app.label)
                            },
                            onRemove        = {
                                if (app != null) {
                                    viewModel.remove(app.packageName)
                                    target = null
                                }
                            },
                            onRemoveAll     = {
                                viewModel.removeAllApps()
                                target = null
                            },
                            onResetDefault  = onResetDefault
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(if (pinned) Modifier else Modifier.verticalScroll(pageScroll))
    ) {
        // ── The switch ──
        GlassCard(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            Column {
                SwitchRow(
                    title    = "Show floating lyrics",
                    subtitle = if (overlayAllowed) {
                        "The current line in a small window on top of other apps."
                    } else {
                        "Needs permission to show a window above other apps."
                    },
                    checked  = defaultStyle.enabled,
                    onChange = onToggleEnabled
                )
                if (!overlayAllowed) {
                    Box(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        MelodiqButton(text = "Allow display over other apps", onClick = onAskPermission)
                    }
                }
            }
        }

        // ── Which style: all apps, or one app ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TargetChip(label = "All apps", packageName = null, selected = app == null) { target = null }
            if (profiles.enabled) {
                for (item in apps) {
                    TargetChip(
                        label       = item.label,
                        packageName = item.packageName,
                        selected    = app?.packageName == item.packageName
                    ) { target = item.packageName }
                }
                OptionChip(text = "+ Add app", selected = false, onClick = { pickingApp = true })
            }
        }
        if (app == null && profiles.enabled && apps.isEmpty()) {
            Hint("The home screen, the app menu and every other app use this style.")
        } else if (app != null) {
            Hint("Only " + app.label + " uses this style. Everything else uses \"All apps\".")
        }
        if (profiles.enabled && apps.isNotEmpty() && !usageAllowed) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text     = "Lyrix needs usage access to tell which app is open.",
                    color    = TextSecondary,
                    style    = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text       = "Allow",
                    color      = PrimaryPurple,
                    style      = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier   = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { showUsageDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        // ── The live preview and the little phone ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(PreviewHeight)
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PositionPad(
                floating = style,
                onPlace  = { x, y -> update { it.copy(posX = x, posY = y) } },
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(PHONE_ASPECT, matchHeightConstraintsFirst = true)
            )
            FloatingPreview(
                floating = style,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
        }
        Hint("Touch or drag the little phone to place the lyrics.")

        // ── The options, one group at a time ──
        SegmentedTabs(
            labels   = StyleTab.values().map { it.label },
            selected = tab,
            onSelect = { tab = it }
        )

        if (pinned) {
            val scroll = rememberScrollState()
            LaunchedEffect(tab) { scroll.scrollTo(0) }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scroll)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                options()
                Spacer(Modifier.height(24.dp))
            }
        } else {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                options()
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

/** What the "More" group adds to the shared options: when to show, and what belongs to apps. */
@Composable
private fun MoreOptions(
    app: AppLyricsProfile?,
    appCount: Int,
    defaultStyle: FloatingLyricsSettings,
    perAppEnabled: Boolean,
    onGlobal: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit,
    onPerApp: (Boolean) -> Unit,
    onShowHere: (Boolean) -> Unit,
    onUseDefault: () -> Unit,
    onRemove: () -> Unit,
    onRemoveAll: () -> Unit,
    onResetDefault: () -> Unit
) {
    if (app != null) {
        SubHeading(app.label)
        SwitchRow(
            title    = "Show floating lyrics here",
            subtitle = "Off keeps the window away while " + app.label + " is open.",
            checked  = app.visible,
            onChange = onShowHere
        )
        ResetRow(text = "Use the \"All apps\" style here", onReset = onUseDefault)
        ResetRow(text = "Remove " + app.label, onReset = onRemove)
        return
    }

    SubHeading("When to show (every app)")
    SwitchRow(
        title    = "Hide while Lyrix is open",
        subtitle = "The lyrics are already on the Now Playing screen.",
        checked  = defaultStyle.hideInApp,
        onChange = { on -> onGlobal { it.copy(hideInApp = on) } }
    )
    SwitchRow(
        title    = "Hide when the song has no lyrics",
        subtitle = "Off: a song without lyrics still shows its name over the moving background.",
        checked  = defaultStyle.hideWhenNoLyrics,
        onChange = { on -> onGlobal { it.copy(hideWhenNoLyrics = on) } }
    )

    SubHeading("Apps")
    SwitchRow(
        title    = "A different style for some apps",
        subtitle = "Add an app with \"+ Add app\" above to give it its own look and place.",
        checked  = perAppEnabled,
        onChange = onPerApp
    )
    if (perAppEnabled && appCount > 0) {
        ResetRow(text = "Remove all app styles", onReset = onRemoveAll)
    }
    ResetRow(text = "Reset floating lyrics", onReset = onResetDefault)
}

/** A short grey line of explanation under a group. */
@Composable
private fun Hint(text: String) {
    Text(
        text     = text,
        color    = TextMuted,
        style    = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)
    )
}

/** A chip that picks which style is being edited: "All apps" or one app, with its icon. */
@Composable
private fun TargetChip(label: String, packageName: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) PrimaryPurple.copy(alpha = 0.55f) else White10)
            .clickable(onClick = onClick)
            .padding(
                start  = if (packageName != null) 8.dp else 16.dp,
                end    = 16.dp,
                top    = 7.dp,
                bottom = 7.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (packageName != null) {
            AppIcon(packageName = packageName, size = 22.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text       = label,
            color      = if (selected) Color.White else TextSecondary,
            style      = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines   = 1,
            overflow   = TextOverflow.Ellipsis
        )
    }
}

/** A row of tabs that look like one pill with the chosen one lit. */
@Composable
private fun SegmentedTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(White10)
            .padding(3.dp)
    ) {
        labels.forEachIndexed { index, label ->
            val on = index == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (on) PrimaryPurple.copy(alpha = 0.55f) else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text       = label,
                    color      = if (on) Color.White else TextSecondary,
                    style      = MaterialTheme.typography.labelLarge,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}
