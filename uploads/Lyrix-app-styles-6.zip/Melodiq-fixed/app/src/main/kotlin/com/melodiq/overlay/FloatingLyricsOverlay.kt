package com.melodiq.overlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.melodiq.audio.BeatAnalyzer
import com.melodiq.crash.AppLog
import com.melodiq.crash.CrashReporter
import com.melodiq.data.model.FloatingBackdrop
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.ResolvedFloating
import com.melodiq.data.model.resolveFloating
import com.melodiq.data.repository.AppProfileRepository
import com.melodiq.data.repository.MusicRepository
import com.melodiq.data.repository.SettingsRepository
import com.melodiq.lyrics.LyricsManager
import com.melodiq.player.PlayerManager
import com.melodiq.ui.components.FloatingLyricsCard
import com.melodiq.ui.components.LyricWindow
import com.melodiq.ui.components.buildLyricWindow
import com.melodiq.ui.components.rememberMusicMotion
import com.melodiq.ui.theme.MelodiqTheme
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/**
 * The lyrics window that floats above other apps.
 *
 * It is owned by [com.melodiq.player.MusicService]: that service is a foreground service while music
 * plays, so the window keeps working after the app is closed and Android does not kill it.
 *
 * The window is shown only when every condition holds: the user turned it on, "display over other
 * apps" is allowed, a song is playing (pause, stop, a dismissed notification and a swiped-away app
 * all remove the window), Lyrix itself is not on screen (optional) and the song has synced lyrics
 * (optional). Everything about how it looks comes from [SettingsRepository], so changes in Settings
 * apply immediately.
 *
 * Each app on the list can have its own look and position ([AppProfileRepository]): [resolved] holds the
 * style of the app on screen right now ([ForegroundAppTracker]). An app that is not on the list always gets
 * the default style, and so do the home screen & menu, so the window stays where it is while the user moves
 * between them. Dragging the window saves its position for the app on the list that is on screen, or as
 * the default position otherwise.
 *
 * Behind the words a picture moves with the music ([BeatAnalyzer] listens to the song file ahead of the
 * playback; the card draws it). A song without lyrics shows its name over that picture when the window is
 * not set to hide then.
 */
@Singleton
class FloatingLyricsOverlay @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val playerManager: PlayerManager,
    private val lyricsManager: LyricsManager,
    private val musicRepository: MusicRepository,
    private val appProfileRepository: AppProfileRepository,
    private val foregroundTracker: ForegroundAppTracker,
    private val beatAnalyzer: BeatAnalyzer
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var scope: CoroutineScope? = null
    private var root: OverlayDragLayout? = null
    private var owner: OverlayLifecycleOwner? = null
    private var params: WindowManager.LayoutParams? = null

    /** The style in use right now: the default, or the one of the app on screen. Everything below reads this. */
    private val resolved = MutableStateFlow(
        ResolvedFloating(style = settingsRepository.settings.value.floating, packageName = null, visible = true)
    )

    /** True while the screen is on. With the screen off nothing can be seen, so the window is taken away. */
    private val screenOn = MutableStateFlow(true)
    private var screenReceiverRegistered = false
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(receiverContext: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> screenOn.value = false
                Intent.ACTION_SCREEN_ON  -> screenOn.value = true
            }
        }
    }

    // ── Lifecycle (called by MusicService) ───────────────────────────────────

    fun start() {
        if (scope != null) return
        // Floating lyrics are a bonus: whatever goes wrong in here is logged, never allowed to crash the app.
        val safely = CoroutineExceptionHandler { _, error ->
            AppLog.w(TAG, "floating lyrics failed", error)
            CrashReporter.recordNonFatal("Floating lyrics failed", error)
        }
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + safely)
        scope = newScope
        // The service can be started by a media button before any screen opened the controller.
        playerManager.connect()

        watchScreen()

        newScope.launch { followCurrentSong() }
        newScope.launch { followVisibility() }
        newScope.launch { followStyle() }
    }

    fun stop() {
        scope?.cancel()
        scope = null
        beatAnalyzer.prepare(null)
        unwatchScreen()
        hide()
    }

    /** Starts following the screen: it begins with the current state, then every ON / OFF broadcast. */
    private fun watchScreen() {
        if (screenReceiverRegistered) return
        val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        screenOn.value = power?.isInteractive ?: true
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        try {
            // Screen ON / OFF are only delivered to a receiver registered in code, never to one in the manifest.
            context.registerReceiver(screenReceiver, filter)
            screenReceiverRegistered = true
        } catch (e: Exception) {
            AppLog.w(TAG, "could not watch the screen, the window stays as it is", e)
            screenOn.value = true
        }
    }

    private fun unwatchScreen() {
        if (!screenReceiverRegistered) return
        screenReceiverRegistered = false
        try {
            context.unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            AppLog.w(TAG, "could not stop watching the screen", e)
        }
    }

    /** The screen size changed (rotation, split screen): place the window again. */
    fun refreshLayout() {
        if (root != null) applyLayout(resolved.value.style)
    }

    // ── What to show, and when ───────────────────────────────────────────────

    /**
     * While the floating window is switched on: loads the lyrics of the playing song, and (when some style
     * moves with the music and the screen is on) starts listening to the song's file for the moving
     * background. Nothing is analysed while nobody could see the result.
     */
    private suspend fun followCurrentSong() {
        val wanted = combine(
            settingsRepository.settings.map { it.floating }.distinctUntilChanged(),
            appProfileRepository.state
        ) { global, profiles ->
            val moves = global.backdrop != FloatingBackdrop.OFF || global.beatPulse ||
                (profiles.enabled &&
                    profiles.apps.any { it.style.backdrop != FloatingBackdrop.OFF || it.style.beatPulse })
            when {
                !global.enabled -> Wanted.NOTHING
                moves           -> Wanted.LYRICS_AND_MOTION
                else            -> Wanted.LYRICS
            }
        }.distinctUntilChanged()

        combine(wanted, playerManager.currentMediaItem, screenOn) { what, item, on ->
            Request(
                songId = if (what != Wanted.NOTHING) item?.mediaId?.toLongOrNull() else null,
                motion = what == Wanted.LYRICS_AND_MOTION && on
            )
        }.distinctUntilChanged().collect { request ->
            val songId = request.songId
            val song = if (songId != null) musicRepository.getSongById(songId) else null
            if (song != null) lyricsManager.ensureLoaded(song)
            beatAnalyzer.prepare(if (song != null && request.motion) song else null)
        }
    }

    private suspend fun followVisibility() {
        // Screen off counts like "not playing": the window is removed, and with it the one thing that
        // makes the line ticker of LyricsManager run, so nothing is polled while nobody can look.
        val playingWithScreenOn = combine(playerManager.isPlaying, screenOn) { playing, on -> playing && on }
        combine(
            resolved,
            playingWithScreenOn,
            AppForeground.inForeground,
            lyricsManager.state,
            playerManager.currentMediaItem
        ) { current, playing, appOnScreen, lyrics, item ->
            val floating = current.style
            val allowed = floating.enabled &&
                current.visible &&          // the app on screen may ask for no floating window
                item != null &&
                playing &&                  // paused, stopped or ended: the window goes away
                !(appOnScreen && floating.hideInApp)
            when {
                !allowed                         -> false
                !floating.hideWhenNoLyrics       -> true
                lyrics is LyricsResult.Synced    -> true
                // lyrics are being (re)loaded: keep the window as it is instead of flickering
                lyrics is LyricsResult.Loading   -> null
                else                             -> false
            }
        }.filterNotNull().distinctUntilChanged().collectLatest { visible ->
            if (visible) {
                show()
            } else {
                // A short grace period: between two songs the player is "not playing" for a moment and the
                // window should not blink off and on. A newer value cancels this wait.
                delay(HIDE_GRACE_MS)
                hide()
            }
        }
    }

    /** Works out which style applies (the default, or the one of the app on screen) and puts it on the window. */
    private suspend fun followStyle() {
        combine(
            settingsRepository.settings.map { it.floating }.distinctUntilChanged(),
            appProfileRepository.state,
            foregroundApp()
        ) { global, profiles, packageName ->
            resolveFloating(global, profiles, packageName)
        }.distinctUntilChanged().collect { next ->
            val previous = resolved.value
            resolved.value = next
            // Going from one app to another that looks the same (every app that is not on the list) changes
            // nothing on screen, so the window is not placed again: it stays exactly where it is.
            if (next.style != previous.style) applyLayout(next.style)
        }
    }

    /**
     * The app on screen. It is only looked up while it can matter: the floating lyrics are on, per-app
     * styles are on, at least one app has a style of its own, and something is
     * playing. While the music is paused (or between two songs) the last answer is kept, so the window
     * does not jump to the default style and back for that moment. When the lookup is not needed at all
     * nothing is polled and the answer is null.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    private fun foregroundApp(): Flow<String?> = combine(
        settingsRepository.settings.map { it.floating.enabled }.distinctUntilChanged(),
        appProfileRepository.state.map { it.enabled && it.apps.isNotEmpty() }.distinctUntilChanged(),
        playerManager.isPlaying,
        playerManager.currentMediaItem.map { it != null }.distinctUntilChanged()
    ) { floating, perApp, playing, hasSong ->
        when {
            !(floating && perApp) -> Tracking.OFF
            hasSong && playing    -> Tracking.RUNNING
            else                  -> Tracking.PAUSED
        }
    }.distinctUntilChanged().flatMapLatest { mode ->
        when (mode) {
            Tracking.RUNNING -> foregroundTracker.observe()
            Tracking.PAUSED  -> emptyFlow<String?>()    // nothing new, the last answer stays
            Tracking.OFF     -> flowOf<String?>(null)
        }
    }.onStart { emit(null) }

    // ── The window ───────────────────────────────────────────────────────────

    private fun show() {
        if (root != null) return
        if (!OverlayPermission.isGranted(context)) {
            AppLog.i(TAG, "not shown: 'Display over other apps' is not allowed")
            return
        }
        var lifecycleOwner: OverlayLifecycleOwner? = null
        try {
            val newOwner = OverlayLifecycleOwner()
            lifecycleOwner = newOwner
            newOwner.start()

            val container = OverlayDragLayout(
                context   = context,
                onDrag    = { dx, dy -> moveBy(dx, dy) },
                onDragEnd = { saveDraggedPosition() }
            )
            // A window added from a service has no Activity to take these from.
            container.setViewTreeLifecycleOwner(newOwner)
            container.setViewTreeSavedStateRegistryOwner(newOwner)

            val content = ComposeView(context)
            content.setContent { OverlayContent() }
            container.addView(
                content,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            val settings = resolved.value.style
            val layout = buildLayoutParams(settings)
            container.draggable = !settings.locked
            windowManager.addView(container, layout)

            root = container
            owner = newOwner
            params = layout
        } catch (e: Exception) {
            AppLog.w(TAG, "could not show the floating lyrics", e)
            CrashReporter.recordNonFatal("Floating lyrics could not be shown", e)
            lifecycleOwner?.stop()
        }
    }

    private fun hide() {
        val view = root
        if (view != null) {
            try {
                windowManager.removeViewImmediate(view)
            } catch (e: Exception) {
                AppLog.w(TAG, "could not remove the floating lyrics", e)
            }
        }
        owner?.stop()
        root = null
        owner = null
        params = null
    }

    private fun applyLayout(floating: FloatingLyricsSettings) {
        val view = root ?: return
        val layout = buildLayoutParams(floating)
        params = layout
        view.draggable = !floating.locked
        try {
            windowManager.updateViewLayout(view, layout)
        } catch (e: Exception) {
            AppLog.w(TAG, "could not update the floating lyrics", e)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildLayoutParams(floating: FloatingLyricsSettings): WindowManager.LayoutParams {
        val metrics = context.resources.displayMetrics
        val width = (metrics.widthPixels * floating.widthFraction).toInt().coerceAtLeast(1)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        // a locked window lets every touch through to the app underneath
        if (floating.locked) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

        val layout = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        )
        layout.gravity = Gravity.TOP or Gravity.START
        layout.x = (floating.posX * (metrics.widthPixels - width).coerceAtLeast(0)).toInt()
        val maxY = (metrics.heightPixels - (root?.height ?: 0)).coerceAtLeast(0)
        layout.y = (floating.posY * metrics.heightPixels).toInt().coerceIn(0, maxY)
        return layout
    }

    // ── Dragging ─────────────────────────────────────────────────────────────

    private fun moveBy(dx: Int, dy: Int) {
        val view = root ?: return
        val layout = params ?: return
        val metrics = context.resources.displayMetrics
        layout.x = (layout.x + dx).coerceIn(0, (metrics.widthPixels - layout.width).coerceAtLeast(0))
        layout.y = (layout.y + dy).coerceIn(0, (metrics.heightPixels - view.height).coerceAtLeast(0))
        try {
            windowManager.updateViewLayout(view, layout)
        } catch (e: Exception) {
            AppLog.w(TAG, "could not move the floating lyrics", e)
        }
    }

    /**
     * Remembers where the user dropped the window (as fractions, so it survives rotation): for the app
     * on screen when that app is on the list, otherwise as the default position (which is also the one of
     * the home screen & menu). An app that is not on the list is never added by a drag: it keeps using the
     * default style.
     */
    private fun saveDraggedPosition() {
        val layout = params ?: return
        val metrics = context.resources.displayMetrics
        val freeX = (metrics.widthPixels - layout.width).coerceAtLeast(1)
        val posX = (layout.x.toFloat() / freeX).coerceIn(0f, 1f)
        val posY = (layout.y.toFloat() / metrics.heightPixels.coerceAtLeast(1)).coerceIn(0f, 1f)

        val target = resolved.value
        val app = target.packageName
        if (app != null) {
            appProfileRepository.savePosition(packageName = app, posX = posX, posY = posY)
        } else {
            settingsRepository.update { it.copy(floating = it.floating.copy(posX = posX, posY = posY)) }
        }
    }

    // ── Content ──────────────────────────────────────────────────────────────

    @Composable
    private fun OverlayContent() {
        val current by resolved.collectAsState()
        val lyrics by lyricsManager.state.collectAsState()
        val active by lyricsManager.activeLine.collectAsState()
        val playing by playerManager.isPlaying.collectAsState()
        val item by playerManager.currentMediaItem.collectAsState()
        val profile by beatAnalyzer.current.collectAsState()

        val floating = current.style
        // What the music is doing, for the moving background and the swell on every beat. It does not run
        // while the style uses neither, or while nothing plays.
        val motion = rememberMusicMotion(
            running    = playing && (floating.backdrop != FloatingBackdrop.OFF || floating.beatPulse),
            profile    = profile,
            positionMs = { playerManager.getCurrentPosition() }
        )

        val synced = lyrics as? LyricsResult.Synced
        if (synced != null) {
            val window = remember(synced, active, floating.lines) {
                buildLyricWindow(synced.lines, active, floating.lines)
            }
            // Every line of the song: the card looks at them to keep one size for the whole song.
            val songLines = remember(synced) { synced.lines.filter { it.isTimed }.map { it.text } }
            MelodiqTheme {
                FloatingLyricsCard(
                    window      = window,
                    settings    = floating,
                    modifier    = Modifier.fillMaxWidth(),
                    songLines   = songLines,
                    title       = if (floating.showTitle) titleOf(item) else null,
                    isPlaying   = playing,
                    motion      = motion,
                    onPrevious  = { playerManager.seekToPrevious() },
                    onPlayPause = { playerManager.togglePlayPause() },
                    onNext      = { playerManager.seekToNext() }
                )
            }
        } else if (!floating.hideWhenNoLyrics) {
            // No synced lyrics (none exist, or they are still loading) and the window is not set to hide
            // then: show the name of the song over the moving background, not an invisible empty window.
            val line = titleOf(item) ?: "\u266A"
            val window = remember(line) { LyricWindow(key = -2, lines = listOf(line), active = 0) }
            MelodiqTheme {
                FloatingLyricsCard(
                    window      = window,
                    settings    = floating.copy(lines = 1),
                    modifier    = Modifier.fillMaxWidth(),
                    songLines   = listOf(line),
                    title       = null,
                    isPlaying   = playing,
                    motion      = motion,
                    onPrevious  = { playerManager.seekToPrevious() },
                    onPlayPause = { playerManager.togglePlayPause() },
                    onNext      = { playerManager.seekToNext() }
                )
            }
        }
    }

    private fun titleOf(item: MediaItem?): String? {
        val metadata = item?.mediaMetadata ?: return null
        val text = listOfNotNull(metadata.title?.toString(), metadata.artist?.toString())
            .filter { it.isNotBlank() }
            .joinToString(" \u2014 ")
        return text.ifBlank { null }
    }

    private companion object {
        const val TAG = "FloatingLyrics"
        const val HIDE_GRACE_MS = 400L
    }
}

/** What the floating window needs to know about the playing song. */
private enum class Wanted {
    /** The floating window is off. */
    NOTHING,
    /** Only the lyrics. */
    LYRICS,
    /** The lyrics, and the song's file listened to for the moving background. */
    LYRICS_AND_MOTION
}

/** The song to prepare (null: none) and whether its file should be listened to. */
private data class Request(val songId: Long?, val motion: Boolean)

/** What [FloatingLyricsOverlay] needs from the foreground-app lookup right now. */
private enum class Tracking {
    /** Not needed (floating lyrics off, per-app styles off, or no app has a style): nothing is polled. */
    OFF,
    /** Needed, but nothing is playing: not polled, the last answer is kept. */
    PAUSED,
    /** Needed and playing: polled about once a second. */
    RUNNING
}

/**
 * Root view of the floating window. It moves the window when the user drags it. It only takes over
 * a touch after the finger has moved past the touch slop, so the buttons inside still work.
 * Raw screen coordinates are used because the view itself moves under the finger.
 */
internal class OverlayDragLayout(
    context: Context,
    private val onDrag: (dx: Int, dy: Int) -> Unit,
    private val onDragEnd: () -> Unit
) : FrameLayout(context) {

    /** False while the window is locked (it is then not touchable at all). */
    var draggable: Boolean = true

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        if (!draggable) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> startDraggingIfMoved(event)
        }
        return dragging
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!draggable) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                startDraggingIfMoved(event)
                if (dragging) {
                    val dx = (event.rawX - lastX).toInt()
                    val dy = (event.rawY - lastY).toInt()
                    if (dx != 0 || dy != 0) {
                        // keep the sub-pixel remainder for the next event
                        lastX += dx
                        lastY += dy
                        onDrag(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) onDragEnd()
                dragging = false
            }
        }
        return true
    }

    private fun startDraggingIfMoved(event: MotionEvent) {
        if (dragging) return
        if (abs(event.rawX - downX) > touchSlop || abs(event.rawY - downY) > touchSlop) {
            dragging = true
            lastX = event.rawX
            lastY = event.rawY
        }
    }
}
