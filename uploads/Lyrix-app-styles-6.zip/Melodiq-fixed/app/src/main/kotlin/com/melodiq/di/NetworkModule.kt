package com.melodiq.di

import com.melodiq.BuildConfig
import com.melodiq.data.network.LrcLibService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            // FIX: LRCLIB's API documentation explicitly requires a descriptive
            // User-Agent header. Requests without one may be rate-limited or blocked.
            // OkHttp's default agent ("okhttp/x.x.x") is not considered acceptable.
            // This interceptor is placed BEFORE the logger so the header appears in
            // outgoing request logs. It carries the app's real version number.
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "Lyrix/${BuildConfig.VERSION_NAME} (Android Music Player)")
                        .build()
                )
            }
        // The request logger writes every address (so every song title) into the log, so only debug
        // builds get it.
        if (BuildConfig.DEBUG) {
            builder.addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BASIC
                }
            )
        }
        return builder.build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://lrclib.net/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides
    @Singleton
    fun provideLrcLibService(retrofit: Retrofit): LrcLibService =
        retrofit.create(LrcLibService::class.java)
}
