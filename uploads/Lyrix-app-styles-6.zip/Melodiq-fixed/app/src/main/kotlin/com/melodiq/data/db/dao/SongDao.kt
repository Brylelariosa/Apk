package com.melodiq.data.db.dao

import androidx.room.*
import com.melodiq.data.db.entity.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    @Upsert
    suspend fun upsertAll(songs: List<SongEntity>)

    // No ORDER BY on purpose: MusicRepository sorts by title (language-aware) once per change.
    @Query("SELECT * FROM songs")
    fun observeAll(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs")
    suspend fun getAll(): List<SongEntity>

    @Query("SELECT * FROM songs WHERE id = :id")
    suspend fun getById(id: Long): SongEntity?

    @Query("SELECT id FROM songs")
    suspend fun getAllIds(): List<Long>

    // SQLite takes at most 999 values in one IN (...) on Android 11 and older, so callers pass 500 at a time.
    @Query("DELETE FROM songs WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)
}
