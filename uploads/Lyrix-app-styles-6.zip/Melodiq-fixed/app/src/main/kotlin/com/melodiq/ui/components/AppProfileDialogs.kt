package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.overlay.InstalledApp
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White10

/*
 * The small pieces the Settings screen shares: a row with an icon and two lines of text, the one-line
 * description of a style, the app picker, and the explanation of "Usage access".
 */

// ── Rows ─────────────────────────────────────────────────────────────────────

/** One row: an icon, a title and a short line under it. */
@Composable
fun StyleRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = title,
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = subtitle,
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** A rounded tile with a symbol, for the rows that are not an app. */
@Composable
fun StyleSlotIcon(iconRes: Int) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .background(White10, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        VectorIcon(id = iconRes, tint = AccentViolet, size = 22.dp)
    }
}

/** A short line about a style: where the window sits, how many lines, how big the text is. */
fun describeStyle(style: FloatingLyricsSettings, visible: Boolean = true): String {
    if (!visible) return "Hidden here"
    val lines = if (style.lines == 1) "1 line" else style.lines.toString() + " lines"
    return positionName(style.posX, style.posY) + " \u00B7 " + lines + " \u00B7 " + style.textSizeSp.toInt() + " sp"
}

private fun positionName(x: Float, y: Float): String {
    val vertical = when {
        y < 0.34f -> "Top"
        y < 0.67f -> "Middle"
        else      -> "Bottom"
    }
    val horizontal = when {
        x < 0.34f -> "left"
        x < 0.67f -> "centre"
        else      -> "right"
    }
    return if (vertical == "Middle" && horizontal == "centre") "Centre of the screen" else "$vertical $horizontal"
}

// ── Usage access ─────────────────────────────────────────────────────────────

/** Explains why Lyrix needs "Usage access" before sending the user to the system screen. */
@Composable
fun UsageAccessDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_floating, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Allow usage access") },
        text  = {
            Text(
                "To give every app its own floating lyrics, Lyrix has to know which app is on screen. " +
                    "It only sees the name of the app in front, never what is inside it. " +
                    "On the next screen, choose Lyrix and switch on \"Allow usage access\", then come back."
            )
        },
        confirmButton = {
            TextButton(onClick = onOpenSettings) { Text("Open settings", color = AccentViolet) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not now", color = TextSecondary) }
        }
    )
}

// ── Choosing an app ──────────────────────────────────────────────────────────

/** A searchable list of the apps on the phone. [alreadyAdded] are marked, tapping any of them calls [onPick]. */
@Composable
fun AppPickerDialog(
    alreadyAdded: Set<String>,
    loadApps: suspend () -> List<InstalledApp>,
    onPick: (InstalledApp) -> Unit,
    onDismiss: () -> Unit
) {
    val apps by produceState<List<InstalledApp>?>(initialValue = null) { value = loadApps() }
    var query by remember { mutableStateOf("") }

    MelodiqDialog(onDismiss = onDismiss, tall = true) {
        Text(
            text     = "Choose an app",
            color    = TextPrimary,
            style    = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )
        OutlinedTextField(
            value         = query,
            onValueChange = { query = it },
            singleLine    = true,
            placeholder   = { Text("Search apps", color = TextMuted) },
            colors        = melodiqFieldColors(),
            modifier      = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        val all = apps
        if (all == null) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryPurple)
            }
        } else {
            val shown = remember(all, query) {
                val needle = query.trim()
                all.filter { it.label.contains(needle, ignoreCase = true) }
            }
            if (shown.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No app found", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(shown, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(packageName = app.packageName, size = 40.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(
                                text     = app.label,
                                color    = TextPrimary,
                                style    = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (app.packageName in alreadyAdded) {
                                Text(
                                    text  = "Has a style",
                                    color = TextMuted,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
