package com.melodiq.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.FloatingBackdrop
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * Draws the picture that moves behind the floating lyrics. It reads [motion] while drawing, so it is
 * redrawn by every step of the music and nothing else has to be recomposed.
 *
 * It stays faint on purpose: the words are always the loudest thing in the window.
 */
internal fun DrawScope.drawBackdrop(
    kind: FloatingBackdrop,
    motion: MusicMotion,
    primary: Color,
    secondary: Color,
    pulseOn: Boolean
) {
    when (kind) {
        FloatingBackdrop.OFF  -> Unit
        FloatingBackdrop.GLOW -> drawGlow(motion, primary, secondary, pulseOn)
        FloatingBackdrop.BARS -> drawBars(motion, primary, secondary, pulseOn)
    }
}

private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Two soft colour clouds that drift, and swell with the music (the low part) and on every beat. */
private fun DrawScope.drawGlow(motion: MusicMotion, primary: Color, secondary: Color, pulseOn: Boolean) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    val pump = if (pulseOn) motion.pulse else 0f
    val t = motion.clock
    val reach = max(w, h)

    val firstRadius = reach * (0.60f + 0.10f * motion.low + 0.14f * pump)
    val firstCenter = Offset(w * (0.20f + 0.12f * sin(t * 0.31f)), h * (0.90f + 0.08f * sin(t * 0.47f)))
    val firstAlpha = (0.18f + 0.30f * motion.low + 0.10f * pump).coerceAtMost(0.6f)
    drawCircle(
        brush  = Brush.radialGradient(
            colors = listOf(primary.copy(alpha = firstAlpha), Color.Transparent),
            center = firstCenter,
            radius = firstRadius
        ),
        radius = firstRadius,
        center = firstCenter
    )

    val secondRadius = reach * (0.50f + 0.10f * motion.mid + 0.10f * pump)
    val secondCenter = Offset(w * (0.80f + 0.12f * sin(t * 0.37f + 1f)), h * (0.10f + 0.10f * sin(t * 0.53f)))
    val secondAlpha = (0.12f + 0.26f * motion.mid + 0.08f * pump).coerceAtMost(0.5f)
    drawCircle(
        brush  = Brush.radialGradient(
            colors = listOf(secondary.copy(alpha = secondAlpha), Color.Transparent),
            center = secondCenter,
            radius = secondRadius
        ),
        radius = secondRadius,
        center = secondCenter
    )
}

/**
 * A row of rounded bars, centred, like the animation on Now Playing: the left ones follow the low part of
 * the music, the right ones the high part, and every bar wobbles a little on its own. Each is drawn twice,
 * a wide faint stroke under a narrower stronger one, which gives it a soft edge.
 */
private fun DrawScope.drawBars(motion: MusicMotion, primary: Color, secondary: Color, pulseOn: Boolean) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    val count = (w / 7.dp.toPx()).toInt().coerceIn(10, 32)
    val usable = w * 0.94f
    val left = (w - usable) / 2f
    val slot = usable / count
    val thickness = slot * 0.54f
    val midY = h / 2f
    val maxHeight = h * 0.80f
    val pump = if (pulseOn) motion.pulse else 0f
    val t = motion.clock

    for (i in 0 until count) {
        val u = if (count > 1) i / (count - 1f) else 0.5f
        val band = if (u < 0.5f) {
            mix(motion.low, motion.mid, u * 2f)
        } else {
            mix(motion.mid, motion.high, (u - 0.5f) * 2f)
        }
        val wobble = 0.72f + 0.28f * sin(t * (2.4f + 0.31f * i) + i * 1.7f)
        val envelope = 1f - 0.38f * abs(u - 0.5f) * 2f
        val barHeight = thickness + (maxHeight - thickness) * (band * wobble * envelope) * (1f + 0.20f * pump)
        // The round caps add half a stroke at each end, so the line itself is shorter than the bar.
        val half = (barHeight.coerceAtMost(h) - thickness).coerceAtLeast(0f) / 2f
        val x = left + slot * (i + 0.5f)
        val tint = lerp(primary, secondary, u)
        drawLine(
            color       = tint.copy(alpha = 0.10f),
            start       = Offset(x, midY - half),
            end         = Offset(x, midY + half),
            strokeWidth = thickness * 2.1f,
            cap         = StrokeCap.Round
        )
        drawLine(
            color       = tint.copy(alpha = 0.30f),
            start       = Offset(x, midY - half),
            end         = Offset(x, midY + half),
            strokeWidth = thickness,
            cap         = StrokeCap.Round
        )
    }
}
