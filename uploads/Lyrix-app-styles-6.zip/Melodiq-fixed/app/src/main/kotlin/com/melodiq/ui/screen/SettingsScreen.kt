package com.melodiq.ui.screen

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.AppSettings
import com.melodiq.data.model.BackgroundStyle
import com.melodiq.data.model.CoverMotion
import com.melodiq.data.model.CoverStyle
import com.melodiq.data.model.LookSettings
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.data.model.LyricsWeight
import com.melodiq.data.model.NowPlayingVisual
import com.melodiq.data.model.VisualizerStyle
import com.melodiq.overlay.OverlayPermission
import com.melodiq.ui.components.ChoiceRow
import com.melodiq.ui.components.ColorRow
import com.melodiq.ui.components.GlassCard
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.OverlayPermissionDialog
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.SliderRow
import com.melodiq.ui.components.StyleSlotIcon
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.VectorIcon
import com.melodiq.ui.components.describeStyle
import com.melodiq.ui.components.percent
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.SettingsViewModel
import java.util.Locale

/** The pages of Settings. The first one is a short list that leads to the others, so nothing is a long scroll. */
private enum class SettingsPage(val title: String) {
    HUB("Settings"),
    FLOATING("Floating lyrics"),
    LYRICS("Lyrics"),
    LOOK("Now Playing look")
}

/**
 * How Now Playing, the lyrics and the floating lyrics look and behave. Every change applies immediately.
 *
 * Settings opens on a short list of three entries; each opens a page of its own. Back (the arrow or the
 * system button) goes from a page to the list, and from the list out of Settings.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var page by rememberSaveable { mutableStateOf(SettingsPage.HUB) }

    var overlayAllowed by remember { mutableStateOf(OverlayPermission.isGranted(context)) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var waitingForPermission by remember { mutableStateOf(false) }

    // Back from the system "Display over other apps" screen: pick up the new permission and, if
    // that is why the user went there, finish switching the floating lyrics on.
    OnResumeEffect {
        overlayAllowed = OverlayPermission.isGranted(context)
        if (waitingForPermission && overlayAllowed) {
            waitingForPermission = false
            viewModel.updateFloating { it.copy(enabled = true) }
        }
    }

    BackHandler(enabled = page != SettingsPage.HUB) { page = SettingsPage.HUB }

    if (showPermissionDialog) {
        OverlayPermissionDialog(
            onDismiss = { showPermissionDialog = false },
            onOpenSettings = {
                showPermissionDialog = false
                waitingForPermission = true
                OverlayPermission.openSettings(context)
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconActionButton(
                icon               = R.drawable.ic_arrow_back,
                contentDescription = "Back",
                onClick            = { if (page == SettingsPage.HUB) onBack() else page = SettingsPage.HUB },
                tint               = Color.White,
                buttonSize         = 48.dp,
                iconSize           = 24.dp
            )
            Text(
                text     = page.title,
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        when (page) {
            SettingsPage.HUB -> SettingsHub(settings = settings, onOpen = { page = it })
            SettingsPage.FLOATING -> FloatingLyricsPage(
                overlayAllowed  = overlayAllowed,
                onToggleEnabled = { on ->
                    if (on && !overlayAllowed) {
                        showPermissionDialog = true
                    } else {
                        viewModel.updateFloating { it.copy(enabled = on) }
                    }
                },
                onAskPermission = { showPermissionDialog = true },
                onResetDefault  = { viewModel.resetFloating() },
                modifier        = Modifier.weight(1f)
            )
            SettingsPage.LYRICS -> ScrollPage {
                LyricsSection(
                    style   = settings.lyrics,
                    update  = { transform -> viewModel.updateLyrics(transform) },
                    onReset = { viewModel.resetLyrics() }
                )
            }
            SettingsPage.LOOK -> ScrollPage {
                LookSection(
                    look    = settings.look,
                    update  = { transform -> viewModel.updateLook(transform) },
                    onReset = { viewModel.resetLook() }
                )
            }
        }
    }
}

// ── The list ──────────────────────────────────────────────────────────────────

@Composable
private fun SettingsHub(settings: AppSettings, onOpen: (SettingsPage) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HubEntry(
            icon     = R.drawable.ic_floating,
            title    = "Floating lyrics",
            subtitle = (if (settings.floating.enabled) "On" else "Off") +
                " \u00B7 " + describeStyle(settings.floating),
            onClick  = { onOpen(SettingsPage.FLOATING) }
        )
        HubEntry(
            icon     = R.drawable.ic_lyrics,
            title    = "Lyrics",
            subtitle = settings.lyrics.textSizeSp.toInt().toString() + " sp \u00B7 " + settings.lyrics.font.label,
            onClick  = { onOpen(SettingsPage.LYRICS) }
        )
        HubEntry(
            icon     = R.drawable.ic_tune,
            title    = "Now Playing look",
            subtitle = settings.look.visualizerStyle.label + " \u00B7 " + settings.look.backgroundStyle.label,
            onClick  = { onOpen(SettingsPage.LOOK) }
        )
    }
}

/** One entry of the list: an icon, a title, a line about the current choices and an arrow. */
@Composable
private fun HubEntry(icon: Int, title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StyleSlotIcon(iconRes = icon)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text  = title,
                    color = TextPrimary,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text     = subtitle,
                    color    = TextSecondary,
                    style    = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            VectorIcon(
                id       = R.drawable.ic_chevron_down,
                tint     = TextMuted,
                size     = 20.dp,
                modifier = Modifier.graphicsLayer { rotationZ = -90f }
            )
        }
    }
}

/** A page that is one scrolling column. */
@Composable
private fun ColumnScope.ScrollPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
        content  = content
    )
}

/** The glass card that holds the rows of a page. */
@Composable
private fun PageCard(content: @Composable ColumnScope.() -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            content  = content
        )
    }
}

// ── Now Playing look ──────────────────────────────────────────────────────────

@Composable
private fun LookSection(
    look: LookSettings,
    update: ((LookSettings) -> LookSettings) -> Unit,
    onReset: () -> Unit
) {
    PageCard {
        ChoiceRow(
            title    = "Picture",
            options  = NowPlayingVisual.values().toList(),
            selected = look.visual,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(visual = choice) } }
        )
        ChoiceRow(
            title    = "Animation style",
            options  = VisualizerStyle.values().toList(),
            selected = look.visualizerStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(visualizerStyle = choice) } }
        )
        ChoiceRow(
            title    = "Background",
            options  = BackgroundStyle.values().toList(),
            selected = look.backgroundStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(backgroundStyle = choice) } }
        )
        SliderRow(
            title      = "Glow strength",
            value      = look.backgroundIntensity,
            range      = 0f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(backgroundIntensity = v) } }
        )
        SliderRow(
            title      = "Animation speed",
            value      = look.animationSpeed,
            range      = 0.25f..2f,
            valueLabel = { String.format(Locale.US, "%.2fx", it) },
            onCommit   = { v -> update { it.copy(animationSpeed = v) } }
        )
        SwitchRow(
            title    = "Animate only while playing",
            subtitle = "Everything holds still when the music is paused, which saves battery.",
            checked  = look.animateOnlyWhilePlaying,
            onChange = { on -> update { it.copy(animateOnlyWhilePlaying = on) } }
        )
        ChoiceRow(
            title    = "Cover shape",
            options  = CoverStyle.values().toList(),
            selected = look.coverStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverStyle = choice) } }
        )
        ChoiceRow(
            title    = "Cover motion",
            options  = CoverMotion.values().toList(),
            selected = look.coverMotion,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverMotion = choice) } }
        )
        SwitchRow(
            title    = "Cover glow",
            checked  = look.coverGlow,
            onChange = { on -> update { it.copy(coverGlow = on) } }
        )
        SliderRow(
            title      = "Cover size",
            value      = look.coverSizeDp.toFloat(),
            range      = 160f..360f,
            valueLabel = { it.toInt().toString() + " dp" },
            onCommit   = { v -> update { it.copy(coverSizeDp = v.toInt()) } }
        )
        ResetRow(text = "Reset look", onReset = onReset)
    }
}

// ── Lyrics in the app ─────────────────────────────────────────────────────────

@Composable
private fun LyricsSection(
    style: LyricsStyleSettings,
    update: ((LyricsStyleSettings) -> LyricsStyleSettings) -> Unit,
    onReset: () -> Unit
) {
    PageCard {
        SliderRow(
            title      = "Text size",
            value      = style.textSizeSp,
            range      = 14f..40f,
            valueLabel = { it.toInt().toString() + " sp" },
            onCommit   = { v -> update { it.copy(textSizeSp = v) } }
        )
        ChoiceRow(
            title    = "Alignment",
            options  = LyricsAlign.values().toList(),
            selected = style.alignment,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(alignment = choice) } }
        )
        ChoiceRow(
            title    = "Font",
            options  = LyricsFont.values().toList(),
            selected = style.font,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(font = choice) } }
        )
        ChoiceRow(
            title    = "Weight",
            options  = LyricsWeight.values().toList(),
            selected = style.weight,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(weight = choice) } }
        )
        SliderRow(
            title      = "Current line size",
            value      = style.activeScale,
            range      = 1f..1.3f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(activeScale = v) } }
        )
        SliderRow(
            title      = "Other lines brightness",
            value      = style.inactiveAlpha,
            range      = 0.1f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
        )
        SwitchRow(
            title    = "Fade distant lines",
            checked  = style.fadeDistant,
            onChange = { on -> update { it.copy(fadeDistant = on) } }
        )
        ColorRow(
            title           = "Current line colour",
            selected        = style.highlightColor,
            allowAlbumColor = true,
            onSelect        = { argb -> update { it.copy(highlightColor = argb) } }
        )
        SwitchRow(
            title    = "Glow behind the current line",
            checked  = style.glow,
            onChange = { on -> update { it.copy(glow = on) } }
        )
        SwitchRow(
            title    = "Smooth scrolling",
            subtitle = "Off makes the lyrics jump to each line instead of gliding.",
            checked  = style.smoothScroll,
            onChange = { on -> update { it.copy(smoothScroll = on) } }
        )
        SwitchRow(
            title    = "Tap a line to jump to it",
            checked  = style.tapToSeek,
            onChange = { on -> update { it.copy(tapToSeek = on) } }
        )
        SwitchRow(
            title    = "Keep the screen on",
            subtitle = "While the lyrics are showing.",
            checked  = style.keepScreenOn,
            onChange = { on -> update { it.copy(keepScreenOn = on) } }
        )
        SwitchRow(
            title    = "Online lyrics lookup",
            subtitle = "Sends a song's title, artist, album and length to lrclib.net to find its lyrics. " +
                "Off: no request is made and only lyrics already saved on this phone are shown.",
            checked  = style.onlineLyrics,
            onChange = { on -> update { it.copy(onlineLyrics = on) } }
        )
        ResetRow(text = "Reset lyrics style", onReset = onReset)
    }
}
