@file:OptIn(ExperimentalTextApi::class)

package com.melodiq.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.R
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LyricLine
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.DeepPurple
import kotlinx.coroutines.delay

/** The few lines shown in the floating window: [lines] with the current one at [active]. */
data class LyricWindow(
    /** Changes whenever the current line changes — what the line animation reacts to. */
    val key: Int,
    val lines: List<String>,
    val active: Int,
    /** How long the current line lasts (until the next one starts); a line too long for its row scrolls over it. */
    val durationMs: Long = DEFAULT_LINE_MS
)

/**
 * Cuts [count] lines (1..5) out of the lyrics around [activeIndex]. Missing neighbours at the start
 * or end of the song are blank lines, so the window keeps the same height all the time.
 * Before the first line the current line shows a note symbol.
 */
fun buildLyricWindow(lines: List<LyricLine>, activeIndex: Int, count: Int): LyricWindow {
    val timedCount = lines.count { it.isTimed }
    val total  = count.coerceIn(1, 5)
    val before = (total - 1) / 2
    val after  = total - 1 - before

    val texts = ArrayList<String>(total)
    var activePosition = 0
    for (i in (activeIndex - before)..(activeIndex + after)) {
        if (i == activeIndex) activePosition = texts.size
        val text = when {
            i in 0 until timedCount -> lines[i].text
            i == activeIndex        -> "♪"
            else                    -> " "
        }
        texts.add(text)
    }
    return LyricWindow(
        key        = activeIndex,
        lines      = texts,
        active     = activePosition,
        durationMs = lineDurationMs(lines, activeIndex, timedCount)
    )
}

/** Time from the start of line [index] to the start of the next one, or a default when it is not known. */
private fun lineDurationMs(lines: List<LyricLine>, index: Int, timedCount: Int): Long {
    if (index < 0 || index + 1 >= timedCount) return DEFAULT_LINE_MS
    val gap = lines[index + 1].timeMs - lines[index].timeMs
    return if (gap > 0L) gap else DEFAULT_LINE_MS
}

// ── One size, always ─────────────────────────────────────────────────────────
//
// The floating window is as tall as its content (WRAP_CONTENT), so every change of the content's height
// is a real resize of an Android window: the background grew and shrank with every long line, and the
// resize happened frame by frame while the line animation ran, which looked like flicker. So the card
// never lets the words decide its size:
//
//  - every line has a row of a fixed height (text size x ROW_HEIGHT_FACTOR); the lines around the sung
//    one get one row, the sung line gets one row or two, the same for the WHOLE song;
//  - a line that is too long for its rows is drawn a little smaller until it fits (never below a readable
//    size);
//  - the sung line that still does not fit is NOT cut off and does not make its row taller: it stays on
//    one line and slides sideways while it is sung, so all of it can be read in the same row;
//  - the other lines show what fits and end in "…" (they are the sung line a moment later);
//  - when the line changes the window size is not animated, only the text.

/** Height of a row compared to its text size. */
private const val ROW_HEIGHT_FACTOR = 1.25f

/** The lines around the sung one are drawn a little smaller. */
private const val NEIGHBOUR_SCALE = 0.82f

/** Sizes tried, biggest first, to make a line fit its rows (1 = the size set in Settings). */
private val FIT_STEPS = floatArrayOf(1f, 0.9f, 0.8f, 0.7f)

/**
 * The smallest size a line may be shrunk to when it only has ONE row. A song gets two rows for its sung
 * line as soon as one of its lines needs more than this.
 */
private const val ONE_ROW_MIN_SCALE = 0.8f

/** Text is never shrunk below this (in sp) just to fit, unless the size set in Settings is smaller still. */
private const val MIN_READABLE_SP = 9f

/** No glyph is wider than this many times the text size (full-width letters are the widest). */
private const val WIDEST_GLYPH_EM = 1.2f

/** A sung line that slides is drawn at this share of the size set in Settings. */
private const val TICKER_SCALE = 0.92f

/** The line waits this long before it starts to slide, so its beginning can be read. */
private const val TICKER_HOLD_MS = 600L

/** The slide takes this share of the time the line lasts, so the end is there a little before the next line. */
private const val TICKER_SHARE = 0.85f
private const val TICKER_MIN_MS = 1_200L
private const val TICKER_MAX_MS = 9_000L

/** The soft fade at both ends of a sliding line. */
private const val TICKER_EDGE_DP = 14f

/** How much the sung line swells on a beat (3.5 %). */
private const val PULSE_SCALE = 0.035f

private const val DEFAULT_LINE_MS = 5_000L

private val EaseOutQuint = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
private val EaseOutBack = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)

private val RowLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim      = LineHeightStyle.Trim.None
)

/** The style that decides how a line breaks. The same one measures a line and draws it. */
private fun rowStyle(family: FontFamily, weight: FontWeight, sizeSp: Float): TextStyle = TextStyle(
    fontFamily      = family,
    fontWeight      = weight,
    fontSize        = sizeSp.sp,
    lineHeight      = (sizeSp * ROW_HEIGHT_FACTOR).sp,
    lineHeightStyle = RowLineHeight
)

/** How many lines [text] takes in a row [availablePx] wide. */
private fun lineCountOf(measurer: TextMeasurer, text: String, style: TextStyle, availablePx: Int): Int =
    measurer.measure(
        text        = AnnotatedString(text),
        style       = style,
        constraints = Constraints(maxWidth = availablePx)
    ).lineCount

/** The smallest size a line may be drawn at: [minScale] of [baseSp], but never below a readable size. */
private fun smallestSp(baseSp: Float, minScale: Float): Float =
    maxOf(baseSp * minScale, minOf(baseSp, MIN_READABLE_SP))

/** The size a line is drawn at and whether it fits its rows at that size. */
private class Fit(val sizeSp: Float, val fits: Boolean)

/**
 * The biggest size at which [text] fits in [rows] rows: [baseSp] itself, then smaller, but never below
 * [smallestSp]. When it does not fit even then, the answer says so and carries the smallest size.
 */
private fun fitLine(
    measurer: TextMeasurer,
    text: String,
    family: FontFamily,
    weight: FontWeight,
    baseSp: Float,
    rows: Int,
    minScale: Float,
    availablePx: Int
): Fit {
    if (text.isBlank() || availablePx <= 0) return Fit(baseSp, true)
    val floorSp = smallestSp(baseSp, minScale)
    for (scale in FIT_STEPS) {
        if (scale < minScale) break
        val sizeSp = baseSp * scale
        if (sizeSp < floorSp) break
        if (lineCountOf(measurer, text, rowStyle(family, weight, sizeSp), availablePx) <= rows) {
            return Fit(sizeSp, true)
        }
    }
    return Fit(floorSp, false)
}

/**
 * How many rows the sung line gets in this song: 1, or 2 when some line is too long for one row even
 * when drawn as small as it may be. It looks at the whole song, so the answer — and with it the height
 * of the card — does not change while the song plays. It stops at the first long line, and lines too
 * short to fill a row are not even measured.
 */
private fun sungRowsOf(
    measurer: TextMeasurer,
    texts: List<String>,
    family: FontFamily,
    weight: FontWeight,
    baseSp: Float,
    availablePx: Int,
    density: Density
): Int {
    if (availablePx <= 0) return 1
    val probeSp = smallestSp(baseSp, ONE_ROW_MIN_SCALE)
    val probe = rowStyle(family, weight, probeSp)
    val widestGlyphPx = with(density) { probeSp.sp.toPx() } * WIDEST_GLYPH_EM
    val surelyFits = (availablePx / widestGlyphPx).toInt()
    for (text in texts) {
        if (text.length <= surelyFits) continue
        if (lineCountOf(measurer, text, probe, availablePx) > 1) return 2
    }
    return 1
}

/**
 * The floating lyrics window: a rounded glass card with the lines, an optional title and optional
 * playback buttons, and an animated picture behind the words that follows the music. The same composable
 * draws the real window (inside the music service) and the live preview in Settings, so the preview is
 * exactly what you get.
 *
 * [songLines] are all the lines of the song (not only the few in [window]): they decide how many rows the
 * sung line gets, so the card has the same size from the first line to the last (see above).
 *
 * [motion] says what the music is doing; without it the picture stands still.
 */
@Composable
fun FloatingLyricsCard(
    window: LyricWindow,
    settings: FloatingLyricsSettings,
    modifier: Modifier = Modifier,
    title: String? = null,
    isPlaying: Boolean = true,
    songLines: List<String> = window.lines,
    motion: MusicMotion? = null,
    onPrevious: () -> Unit = {},
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {}
) {
    val shape = RoundedCornerShape(settings.cornerRadiusDp.dp)
    val textColor = Color(settings.textColor)
    val duration = settings.animationMs
    val measurer = rememberTextMeasurer(cacheSize = 24)
    val still = remember { MusicMotion() }
    val live = motion ?: still

    // The background colour from Settings is the base; a little violet at the top and deep purple at the
    // bottom turn it into glass that belongs to the app instead of a flat grey box.
    val base = Color(settings.backgroundColor)
    val backgroundAlpha = settings.backgroundAlpha
    val fill = remember(base, backgroundAlpha) {
        Brush.verticalGradient(
            listOf(
                lerp(base, AccentViolet, 0.22f).copy(alpha = backgroundAlpha),
                lerp(base, DeepPurple, 0.30f).copy(alpha = backgroundAlpha)
            )
        )
    }
    val edge = remember {
        Brush.linearGradient(listOf(AccentViolet.copy(alpha = 0.55f), AccentPink.copy(alpha = 0.30f)))
    }

    Column(
        modifier = modifier
            .alpha(settings.windowAlpha)
            .clip(shape)
            .background(fill)
            .drawBehind { drawBackdrop(settings.backdrop, live, AccentViolet, AccentPink, settings.beatPulse) }
            .border(1.dp, edge, shape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = settings.alignment.toHorizontal()
    ) {
        if (title != null) {
            Text(
                text     = title,
                color    = textColor.copy(alpha = 0.6f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
        }

        // The width the words get is needed to know which lines are too long, so measure it here.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val availablePx = if (constraints.hasBoundedWidth) constraints.maxWidth else 0
            val density = LocalDensity.current
            val family = settings.font.toFontFamily()
            val weight = settings.weight.toFontWeight()
            val sungRows = remember(songLines, availablePx, settings.textSizeSp, family, weight, density) {
                sungRowsOf(measurer, songLines, family, weight, settings.textSizeSp, availablePx, density)
            }

            AnimatedContent(
                targetState = window,
                transitionSpec = {
                    val change = when (settings.animation) {
                        LineAnimation.NONE ->
                            EnterTransition.None togetherWith ExitTransition.None
                        // The old line is gone before the new one is fully there: no muddy overlap.
                        LineAnimation.FADE ->
                            fadeIn(tween(duration, delayMillis = duration / 3)) togetherWith
                                fadeOut(tween(duration * 2 / 3))
                        // The new line rises into place and settles softly; the old one lifts away.
                        LineAnimation.SLIDE ->
                            (slideInVertically(tween(duration, easing = EaseOutQuint)) { it / 3 } +
                                fadeIn(tween(duration, delayMillis = duration / 5))) togetherWith
                                (slideOutVertically(tween(duration, easing = EaseOutQuint)) { -it / 4 } +
                                    fadeOut(tween(duration * 3 / 5)))
                        // The new line pops in with a small overshoot.
                        LineAnimation.POP ->
                            (scaleIn(tween(duration, easing = EaseOutBack), initialScale = 0.82f) +
                                fadeIn(tween(duration * 2 / 3))) togetherWith
                                (scaleOut(tween(duration), targetScale = 1.12f) + fadeOut(tween(duration / 2)))
                    }
                    // Only the text moves. The size of the window is never animated: that would resize an
                    // Android window on every frame.
                    change using SizeTransform(clip = true) { _, _ -> snap() }
                },
                label = "floating_lyrics"
            ) { shown ->
                LyricLines(
                    window      = shown,
                    settings    = settings,
                    sungRows    = sungRows,
                    availablePx = availablePx,
                    measurer    = measurer,
                    motion      = live
                )
            }
        }

        if (settings.showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconActionButton(
                    icon = R.drawable.ic_skip_previous,
                    contentDescription = "Previous song",
                    onClick = onPrevious,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
                IconActionButton(
                    icon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    tint = textColor,
                    buttonSize = 44.dp,
                    iconSize = 26.dp
                )
                IconActionButton(
                    icon = R.drawable.ic_skip_next,
                    contentDescription = "Next song",
                    onClick = onNext,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
            }
        }
    }
}

@Composable
private fun LyricLines(
    window: LyricWindow,
    settings: FloatingLyricsSettings,
    sungRows: Int,
    availablePx: Int,
    measurer: TextMeasurer,
    motion: MusicMotion
) {
    Column(horizontalAlignment = settings.alignment.toHorizontal()) {
        window.lines.forEachIndexed { index, text ->
            val sung = index == window.active
            FloatingLyricRow(
                text        = text,
                sung        = sung,
                settings    = settings,
                rows        = if (sung) sungRows else 1,
                availablePx = availablePx,
                measurer    = measurer,
                durationMs  = window.durationMs,
                beat        = if (sung && settings.beatPulse) motion else null
            )
        }
    }
}

/**
 * One line in a row of its own: [rows] rows tall whatever the words are. The text is fitted into it;
 * a sung line that can not be fitted slides sideways instead (see [TickerText]). The row swells a little
 * on every beat when [beat] is given.
 */
@Composable
private fun FloatingLyricRow(
    text: String,
    sung: Boolean,
    settings: FloatingLyricsSettings,
    rows: Int,
    availablePx: Int,
    measurer: TextMeasurer,
    durationMs: Long,
    beat: MusicMotion?
) {
    val density = LocalDensity.current
    val family = settings.font.toFontFamily()
    val weight = if (sung) settings.weight.toFontWeight() else FontWeight.Normal
    val baseSp = if (sung) settings.textSizeSp else settings.textSizeSp * NEIGHBOUR_SCALE
    // A song with two rows may shrink a long line further; with one row every line fits at 80 % already.
    val minScale = if (rows > 1) FIT_STEPS.last() else ONE_ROW_MIN_SCALE
    val fit = remember(text, family, weight, baseSp, rows, minScale, availablePx, density) {
        fitLine(measurer, text, family, weight, baseSp, rows, minScale, availablePx)
    }
    val slides = sung && !fit.fits
    val sizeSp = if (slides) maxOf(baseSp * TICKER_SCALE, minOf(baseSp, MIN_READABLE_SP)) else fit.sizeSp

    val color  = Color(settings.textColor)
    val shadow = if (settings.textShadow) {
        Shadow(color = Color.Black.copy(alpha = 0.85f), offset = Offset(0f, 2f), blurRadius = 6f)
    } else {
        null
    }
    val style = rowStyle(family, weight, sizeSp).copy(
        color     = if (sung) color else color.copy(alpha = color.alpha * settings.inactiveAlpha),
        textAlign = settings.alignment.toTextAlign(),
        shadow    = shadow
    )
    // The row's height comes from the size set in Settings, not from the fitted one, so it never changes.
    val rowHeight = with(density) { (baseSp * ROW_HEIGHT_FACTOR * rows).sp.toDp() }

    // Read in the graphics layer only, so a beat redraws this row and does not recompose or measure it.
    val swell = if (beat != null) {
        Modifier.graphicsLayer {
            val scale = 1f + PULSE_SCALE * beat.pulse
            scaleX = scale
            scaleY = scale
        }
    } else {
        Modifier
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .height(rowHeight)
            .then(swell),
        contentAlignment = Alignment.Center
    ) {
        if (slides) {
            TickerText(
                text        = text,
                style       = style,
                availablePx = availablePx,
                durationMs  = durationMs,
                measurer    = measurer
            )
        } else {
            BasicText(
                text     = text,
                style    = style,
                overflow = TextOverflow.Ellipsis,
                maxLines = rows,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * A line that is too long for its row, kept on ONE line and slid sideways while it is sung so that all of
 * it can be read without the row (and the window) growing. It waits a moment at the start, then moves at a
 * steady pace and arrives at the end shortly before the next line. The two ends fade out softly.
 */
@Composable
private fun TickerText(
    text: String,
    style: TextStyle,
    availablePx: Int,
    durationMs: Long,
    measurer: TextMeasurer
) {
    val textWidthPx = remember(text, style) {
        measurer.measure(
            text     = AnnotatedString(text),
            style    = style,
            softWrap = false,
            maxLines = 1
        ).size.width
    }
    val overflowPx = (textWidthPx - availablePx).coerceAtLeast(0)
    val progress = remember(text) { Animatable(0f) }

    LaunchedEffect(text, overflowPx, durationMs) {
        progress.snapTo(0f)
        if (overflowPx > 0) {
            delay(TICKER_HOLD_MS)
            val travelMs = (durationMs * TICKER_SHARE - TICKER_HOLD_MS).toLong()
                .coerceIn(TICKER_MIN_MS, TICKER_MAX_MS)
            progress.animateTo(1f, tween(travelMs.toInt(), easing = LinearEasing))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clipToBounds()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                // The ends fade out, but not the end the line is still at: the first words stay sharp
                // while it waits, and the last ones once it has arrived.
                val edge = (TICKER_EDGE_DP.dp.toPx() / size.width.coerceAtLeast(1f)).coerceIn(0.001f, 0.25f)
                val p = progress.value
                val left = 1f - (p * 12f).coerceIn(0f, 1f)
                val right = 1f - ((1f - p) * 12f).coerceIn(0f, 1f)
                drawRect(
                    brush = Brush.horizontalGradient(
                        0f to Color.Black.copy(alpha = left),
                        edge to Color.Black,
                        1f - edge to Color.Black,
                        1f to Color.Black.copy(alpha = right)
                    ),
                    blendMode = BlendMode.DstIn
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        BasicText(
            text     = text,
            style    = style,
            softWrap = false,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .wrapContentWidth(align = Alignment.Start, unbounded = true)
                .graphicsLayer { translationX = -overflowPx * progress.value }
        )
    }
}
