package com.melodiq.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import com.melodiq.audio.AudioProfile
import com.melodiq.audio.Band
import com.melodiq.audio.NO_BEAT
import kotlin.math.exp
import kotlin.math.sin

/**
 * What the music is doing right now, for things that move with it (the floating lyrics' backdrop and the
 * swell on every beat).
 *
 * The values are Compose state, but they change 30 times a second, so they must only be read inside draw
 * or graphics-layer blocks (`drawBehind`, `graphicsLayer`): then only that block runs again, and nothing is
 * recomposed or measured. [rememberMusicMotion] keeps them up to date.
 */
@Stable
class MusicMotion {
    /** How strong the low (drums, bass), middle and high parts are, 0..1. */
    var low by mutableFloatStateOf(IDLE_LEVEL)
        private set
    var mid by mutableFloatStateOf(IDLE_LEVEL)
        private set
    var high by mutableFloatStateOf(IDLE_LEVEL)
        private set

    /** 1 right on a beat, fading to 0 before the next. */
    var pulse by mutableFloatStateOf(0f)
        private set

    /** Seconds since the motion started: slow drifts and the small differences between bars use it. */
    var clock by mutableFloatStateOf(0f)
        private set

    /** Everything calm: the music is not playing. */
    internal fun settle() {
        low = IDLE_LEVEL
        mid = IDLE_LEVEL
        high = IDLE_LEVEL
        pulse = 0f
    }

    /**
     * One step. With a [profile] that already describes the song at [positionMs] the values come from the
     * music itself, otherwise from a made-up groove (the same idea as the Now Playing animation) so there
     * is never a dead moment, for instance in the first second of a song or when it can not be analysed.
     */
    internal fun advance(dt: Float, time: Float, profile: AudioProfile?, positionMs: Long) {
        var targetLow: Float
        var targetMid: Float
        var targetHigh: Float
        var targetPulse: Float

        // Look a little ahead: the picture is on screen a frame or two after it is worked out.
        val at = positionMs + LEAD_MS
        if (profile != null && profile.covers(at)) {
            targetLow = profile.level(Band.LOW, at)
            targetMid = profile.level(Band.MID, at)
            targetHigh = profile.level(Band.HIGH, at)
            val since = profile.msSinceBeat(at)
            targetPulse = if (since == NO_BEAT) 0f else exp(-since / PULSE_FALL_MS)
        } else {
            targetLow = pretendLevel(0, time)
            targetMid = pretendLevel(1, time)
            targetHigh = pretendLevel(2, time)
            targetPulse = pretendKick(time)
        }

        low = follow(low, targetLow, dt)
        mid = follow(mid, targetMid, dt)
        high = follow(high, targetHigh, dt)
        pulse = targetPulse
        clock = time
    }

    private companion object {
        const val IDLE_LEVEL = 0.10f
        /** How far ahead of the player's position the music is read, in milliseconds. */
        const val LEAD_MS = 40L
        /** How quickly the swell on a beat dies away: it is at about a third after this long. */
        const val PULSE_FALL_MS = 120f
        /** How quickly a level falls back (it rises at once). */
        const val FALL_SECONDS = 0.16f

        /** Rises fast, falls slowly: it looks like a meter and not like noise. */
        fun follow(current: Float, target: Float, dt: Float): Float =
            if (target >= current) {
                current + (target - current) * 0.65f
            } else {
                current + (target - current) * (1f - exp(-dt / FALL_SECONDS))
            }

        /** A made-up level that wanders about: three slow waves per band. */
        fun pretendLevel(band: Int, t: Float): Float {
            val a = sin(t * (2.1f + 0.9f * band) + band * 1.7f)
            val b = sin(t * (3.3f + 0.6f * band) + band * 0.9f + 1.3f)
            val v = 0.5f + 0.5f * (0.6f * a + 0.4f * b)
            return 0.15f + 0.85f * v * v
        }

        /** A made-up steady kick, about 114 beats a minute. */
        fun pretendKick(t: Float): Float = exp(-((t * 1.9f) % 1f) * 6f)
    }
}

/** How often the motion is worked out and drawn: every other frame of a 60 Hz screen is plenty. */
private const val MOTION_STEP_SECONDS = 0.030f

/**
 * A [MusicMotion] that is kept up to date while [running] (the music is playing and something is drawn).
 *
 * With a [profile] and a [positionMs] it follows the real music. Without them it plays a made-up groove, which
 * is what the preview in Settings uses. [positionMs] is called every step on the main thread; keep it cheap.
 */
@Composable
fun rememberMusicMotion(
    running: Boolean,
    profile: AudioProfile? = null,
    positionMs: () -> Long = { 0L }
): MusicMotion {
    val motion = remember { MusicMotion() }
    val position by rememberUpdatedState(positionMs)
    LaunchedEffect(running, profile) {
        if (!running) {
            motion.settle()
            return@LaunchedEffect
        }
        var last = withFrameNanos { it }
        var clock = motion.clock
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            if (dt < MOTION_STEP_SECONDS) continue
            last = now
            clock += dt
            motion.advance(dt, clock, profile, position())
        }
    }
    return motion
}
