# How Lyrix works

## 1. Finding your songs
1. On first launch Lyrix asks for permission to read audio files
   (`READ_MEDIA_AUDIO` on Android 13+, `READ_EXTERNAL_STORAGE` on older versions).
   If you deny it, a screen with **Allow access** and **Open app settings** buttons is shown.
2. `MusicRepository.syncLibrary()` asks Android's MediaStore for every music file of 30 s or longer
   and saves them in a local Room database (`songs` table). Only rows that are new or different are written, so an
   unchanged library leaves the table alone. Songs that no longer exist are removed in chunks of 500 ids (SQLite takes
   at most 999 values in one `IN (…)` on Android 11 and older), and only when the scan found songs: a scan that
   returns nothing right after the permission was granted must not erase the library.
3. Screens never read MediaStore directly — they observe the database, so lists update by themselves. The table is
   watched once and sorted once per change (by title, following the phone's language, in `MusicRepository`); the
   song list, *Recently played* and *Favourites* are all built from that one flow. Search looks through the songs
   already in memory and ignores capitals and accents ("beyonce" finds "Beyoncé").
4. If a file has no artist/album tag, MediaStore returns the text `<unknown>` (not null).
   `util/MediaTags.kt` turns that into "Unknown artist" / "Unknown album" everywhere.

## 2. Playing music
```
UI buttons ─▶ PlayerViewModel ─▶ PlayerManager ─▶ MediaController ─▶ MusicService ─▶ ExoPlayer
 (one copy         (state for         (one connection        (background service,
  for the app)      the screens)        for the app)           notification, audio focus)
```
* **MusicService** owns ExoPlayer and keeps playing when the app is closed with the home button. Swiping the app away from the recent apps, or dismissing the
  playback notification, closes everything at once (`MusicService.closeEverything()`): the floating lyrics window, the
  music, the notification and the service. `PlayerManager.release()` is part of that: the app's own controller keeps the
  service bound, and a bound service cannot stop.
* **PlayerManager** is connected once and never released while the app process lives. A tap that
  arrives before the connection is ready is remembered and played as soon as it connects.
* **PlayerViewModel** is created once in `AppRoot` and passed to every screen, so the mini player,
  the song lists and Now Playing always agree.
* Song position changes 5×/second, so it lives in its own flow (`progress`). Only the seek bar and the
  mini-player bar read it; song lists don't recompose while music plays.
* **Shuffle** is handled by `ShuffleCoordinator` (inside the service, next to ExoPlayer). It replaces ExoPlayer's
  random order with a *deck* (`ShuffleDeck`): a permutation of every song in the queue, the playing song first.
  - Each song appears exactly once per pass, so none is skipped and none repeats before the pass is over.
  - Turning shuffle on mid-way: songs already played stay behind the current one (that is what *Previous*
    walks back through) and only the unplayed songs are shuffled. If everything was played, a new pass starts.
  - *Repeat off* stops after the last song. *Repeat all* builds a new random deck when the last song starts.
  - The *Shuffle* buttons start shuffle mode with a random first song (`PlayerManager.playSongs(..., shuffle = true)`).
* **Notification / lock screen / headset buttons.** The media session is given `SkippablePlayer` (a
  `ForwardingPlayer` around ExoPlayer) that keeps *previous* and *next* available at all times. ExoPlayer withdraws
  *next* on the last song, which made the notification lose a button exactly when a queue ended (play jumped across;
  Android 13+ left an empty slot). *Next* on the last song just does nothing. The status-bar icon is
  `ic_stat_lyrix` (set on `DefaultMediaNotificationProvider`); the title comes from the media item's metadata.
* **Notification buttons.** Previous / play / next are drawn by Android (on Android 13+ from the playback state,
  with its own icons), so an app cannot restyle them. `NotificationButtons` (the session callback) adds two buttons
  with Lyrix's own icons: *shuffle* and *repeat* (`ic_notif_*`; a notification icon is painted one colour, so
  *on* is full brightness with a dot and *off* is dimmed). They are session custom commands: `onConnect` lets a
  controller press them, `onCustomCommand` flips shuffle / cycles repeat on the player, and a player listener
  re-sends the custom layout whenever either changes, so the icons are right even when the Now Playing screen or
  a headset changed it. Android 13+ shows them on either side of previous / next in the expanded media card.
* **A file that cannot be played is skipped.** When the player reports an error (a deleted, unreadable or broken
  file) and there is a next song, `MusicService` goes on to it and shows *Skipped a file that can't be played*;
  `PlaybackLogger` still saves the error report. After 5 errors in a row without a song playing in between (every
  file broken, with repeat all) it stops instead of looping for ever; a song that plays resets the count.
* **Who may control playback.** Lyrix itself (its screens and its notification), the system interface, Bluetooth,
  Android Auto and the Google voice assistant can do everything. Any other app that connects to the media session
  can still play, pause, seek and skip, but cannot load its own songs into the queue or use the shuffle / repeat
  buttons (`NotificationButtons.onConnect` holds the list of allowed package names).
* **Sleep timer** lives in `SleepTimerManager` (a singleton), so it still pauses the music after you
  close the app. It calls `pause()` — it never restarts music you already paused.

## 3. Lyrics
Lyrics come from the free LRCLIB service. `LyricsRepository` tries, in order, and stops at the first hit:

| Step | Request | Used when |
|------|---------|-----------|
| 1 | exact lookup `/api/get` (title + artist + album + length) | song has an artist tag |
| 2 | field search `/api/search?track_name=…` | always — works with the title alone |
| 3 | free-text search `/api/search?q=…` | last resort |

* Every step is tried with a **cleaned title** (`(Official Video)`, `[Lyrics]`, `01 - ` removed) and, for
  file-name style titles like `Artist - Title`, with that split as well.
* Search results are accepted only with real evidence: same title **and** length within 5 s when there is
  no artist, or matching artist. A title that merely contains your words never counts, so "Love" will
  not pull the lyrics of "Love Story".
* **Saved on the phone for good.** Found lyrics are stored in Room and never expire, so once a song's lyrics have
  loaded that song never needs the internet again (only *Try again* asks the service anew). "Not found" is retried
  after 1 day. A network failure is **never** saved, and shows a *Try again* button instead of "No lyrics": that means no
  connection, a timeout (408), a rate limit (429) or a server error (5xx). Any other 4xx answer counts as "nothing
  found" for that one request, and the next lookup is tried. On top
  of that `LyricsManager` keeps the last 12 results in memory, so returning to a song shows its lyrics without the
  spinner. (There is no purge: nothing would ever delete found lyrics.)
* **Online lyrics lookup** (Settings → Lyrics, on by default). Looking up lyrics is what uses the internet: a song's
  title, artist, album and length go to lrclib.net. With the switch off `LyricsRepository` makes no request at all:
  lyrics already saved on the phone (cached, or your own) are shown, otherwise *No lyrics*, and *Choose another
  version* answers *offline*. The switch is read straight from DataStore, so even the first lookup after the app
  starts follows it, and *Reset lyrics style* leaves it alone. The request logger exists in debug builds only, and
  the User-Agent carries the real version number.
* **Fullest wins.** LRCLIB often has several uploads of one song and some stop halfway. Among the trusted
  matches the one with the most lines is chosen (`TrackMatcher.pickBest`); a hit that looks cut short
  (`LyricsQuality.assess`: synced lines < 80 % of the plain lines, or the timing ends long before the song)
  is only kept as a fallback while the other steps look for a fuller one.
* **Missing tail.** If the synced lines are a prefix of the plain text, the remaining plain lines are appended
  without timing (`LyricsQuality.withMissingTail`) and shown dimmed, so nothing is missing from the screen.
  Lyrics that still look incomplete get a notice with a button to the version list.
* **Your own lyrics** (lyrics options, ⋮ above the lyrics): *Choose another version* (list of everything found,
  `LyricsRepository.findVersions`), *Edit or paste lyrics*, *Import .lrc/.txt*, *Back to automatic*, and *Sync
  timing*. Your choice and offset are stored per song as small JSON files (`CustomLyricsStore`, in the app's private
  `files/lyrics` folder) — deliberately not in Room, so they never expire and the database schema is untouched. They are
  written through `AtomicFile` (the old file stays until the new one is complete, so a crash in the middle of a save
  loses nothing), and an imported file is read in pieces and refused beyond 1 MB without loading it.
  Text with `[mm:ss.xx]` lines becomes synced lyrics, anything else plain lyrics.
* **Sync timing** is a panel above the lyrics (`LyricsSyncPanel`, opened by the *Sync* chip or from the lyrics
  options), not a dialog, so the lines can be watched moving while you adjust. Slider ±10 s, ±1 s buttons, ±0.1 s
  buttons that repeat while held; every change is saved at once (`LyricsTiming.MAX_OFFSET_MS` = ±30 s).
* **Edit lyrics** is a full screen (`LyricsEditorScreen`) laid over Now Playing, with `systemBarsPadding().imePadding()`:
  the keyboard pushes it up so the text field shrinks instead of being covered. Back closes the editor only.
* **Choose lyrics** marks the version already in use (`LyricsFingerprint` compares the first letters of the text,
  ignoring timestamps) and keeps the last 8 searches in memory (the *Search* button always asks again).
* **Auto-scroll** (`SyncedLyricsContent` / `centerLine`): the current line is scrolled to the middle of the list.
  The list has half a screen of padding above and below, and a line's `offset` is measured from the start of the
  *content* (below the padding), so the middle is `(viewportStartOffset + viewportEndOffset) / 2` — **not**
  `viewportSize / 2`, which put the line at the bottom edge. While a finger is on the list nothing scrolls; 3.5 s
  after it lets go the list glides back to the current line. Before the first line it returns to the top.
* **Try again** re-asks the service ignoring the cache.
* `LyricsManager` (singleton) holds the lyrics of the current song and the current line. Lyrics are only looked up
  when the Now Playing screen or the floating window asks, and the 100 ms position polling runs only while
  something is observing `activeLine` — a closed app with no floating window does no lyrics work.
* Lyrics are optional, so they are fenced off from the player: if anything unexpected fails while loading
  them, the app saves an error log, shows *Couldn't load lyrics* with a *Try again* button, and the music
  keeps playing.
* **Regex rule for Android:** the phone's regex engine (ICU) is stricter than a desktop JVM. Always escape
  literal `{ } [ ] ( )` with a backslash (`\{[^\}]*\}`, not `\{[^}]*}`), or the app crashes the first time
  the pattern is built.

## 4. Look, settings and floating lyrics
* **Settings** (`ui/screen/SettingsScreen.kt`, reached from the gear on Home / Now Playing). It opens on a short
  list of three entries — Floating lyrics, Lyrics, Now Playing look — and each opens a page of its own (a plain
  `page` state plus a `BackHandler`, no extra navigation routes): so nothing is a long scroll. All options are
  data classes in `data/model/AppSettings.kt`, stored in DataStore by `SettingsRepository`. `settings` is a
  `StateFlow` rebuilt from the stored values, so Settings, Now Playing and the floating window (inside the
  service) always agree; `update { … }` changes the stored values atomically.
* **Now Playing look**: `AmbientBackground` (aurora / pulse / still / plain) and `NowPlayingCover` (rounded or
  circle, breathe / float / spin / none, halo). Both drive their animation from one float clock that only the
  draw / graphics-layer phase reads, capped at 30 fps for the background, and stopped while paused.
* **Now Playing picture** (Settings → *Picture*): `MusicVisualizer` (default; Ring / Bars / Waves), the album cover
  (`NowPlayingCover`), or *Auto* (cover only when the song has art; the screen learns that while it loads the art
  for the accent colour). The visualizer is a pretend spectrum — three sine waves per bar plus a steady beat — so it
  needs no audio permission; it settles when paused. One float clock, read only by the draw phase, 30 fps, stopped
  while paused (unless *Animate only while playing* is off).
* **Lyrics view** (`LyricsView.kt`): size, alignment, font, weight, current-line scale, dimming, distance fade,
  highlight colour (or album colour), glow, smooth scroll, tap to seek, keep screen on.
* **Floating lyrics** (`overlay/`): `FloatingLyricsOverlay` is created by `MusicService` (a foreground service
  while music plays, so Android keeps the window alive). It adds a `ComposeView` to `WindowManager`
  (`TYPE_APPLICATION_OVERLAY`) and draws `FloatingLyricsCard` — the same composable as the live preview in
  Settings. A window added from a service has no Activity, so `OverlayLifecycleOwner` supplies the lifecycle and
  saved-state owners the ComposeView needs. `OverlayDragLayout` moves the window using raw screen coordinates (the
  window moves under the finger, so view coordinates would jitter) and only after the touch slop, so the buttons
  inside still work. It shows only when: enabled + permission granted + a song is playing (pause, stop, a
  dismissed notification and a swiped-away app remove the window; a 0.4 s grace keeps it from blinking between songs) + the screen is on + Lyrix is not on screen (`AppForeground`, optional) + synced lyrics exist (optional).
  The window is taken away while the screen is off (`FloatingLyricsOverlay` listens for screen on / off while it
  runs), and with it the 100 ms line ticker, which only runs while something observes the current line.
  The permission is *Display over other apps* (`SYSTEM_ALERT_WINDOW`); `OverlayPermission` opens the system page.
* **A style for each app.** `AppLyricsProfile` = package + name + *visible* + a full `FloatingLyricsSettings`
  (its four "when to show" switches are ignored: those stay global, `withBehaviorOf`). `AppProfileRepository` keeps
  them as one JSON text in the same DataStore (`fl_app_profiles`, plus the master switch `fl_per_app`); every
  field has a default and a range, so an older or newer profile still reads. `ForegroundAppTracker` finds the app
  on screen by reading Android's log of app switches (`UsageStatsManager.queryEvents`, the permission is *Usage
  access*, `UsageAccessPermission`) about once a second, and **only while it can matter** (floating lyrics on, per-app
  on, at least one app has a style of its own, something playing, screen on); the app that last
  "came to the front" is the app on screen. The overlay turns
  *default style + profiles + app on screen* into one `ResolvedFloating` (pure function `resolveFloating`) and
  everything else reads that: layout, content, visibility. **An app that is not on the list is never added by
  itself:** `resolveFloating` gives every such app the same answer (the default style and default position,
  `packageName = null`), so `FloatingLyricsOverlay.followStyle` does not even place the window again when the app on
  screen changes from one of them to another. `saveDraggedPosition` writes the dropped position into the profile of
  the app on screen when that app is on the list (`AppProfileRepository.savePosition` ignores any other app), or
  into the default position otherwise. While nothing plays the last app on screen is kept (`Tracking.PAUSED`), so
  the window does not jump to the default style and back between two songs.
  **The home screen & menu are not a slot of their own any more.** A launcher (an app with a HOME activity of normal
  priority, `InstalledApps.homePackages`; Settings' fallback "home" is skipped) in front means no app is open, and
  `ForegroundAppTracker` still reports the reserved key `HOME_SCREEN_KEY` (`#home`) for it, but `resolveFloating`
  answers it with the default style like any app that is not on the list; an old `#home` profile is ignored and
  dropped when the profiles are read (`AppProfileRepository.decode`). So there is one style, *All apps*, that covers
  the home screen, the app menu and every app without a style of its own.
* **The Floating lyrics page** (`ui/screen/FloatingLyricsPage.kt`) is where all of it is set. Pinned at the top: the
  switch, chips for the style being edited (*All apps*, one chip per app with its own style, *+ Add app*), the live
  preview (`FloatingPreview`: the real card at its real width, scaled down to fit, with one long sample line) and
  `PositionPad`, a little phone on which a touch or a drag puts the window (the stored `posX` / `posY`, the same
  formulas as `FloatingLyricsOverlay.applyLayout`; the window is drawn as wide and about as tall as the real one).
  Under them four groups, one at a time (`StyleTab`: Text, Window, Motion, More — `FloatingStyleControls.kt`), the same
  for the default style and for an app's style; *More* also holds the global "when to show" switches and what
  belongs to apps (per-app switch, *Remove*, *Use the "All apps" style here*). On a screen shorter than 720 dp the
  whole page scrolls instead of pinning the top. `AppProfilesViewModel` does all the reading and writing.
* **The card never changes size** (`FloatingLyricsCard`). The window is WRAP_CONTENT, so a change of the content's
  height is a real resize of an Android window; before, wrapping lyrics made the background grow and shrink and the
  line animation resized the window on every frame. Now each line has a row of a fixed height (text size x 1.25): the
  lines around the sung one get one row, the sung line gets one or two for the WHOLE song (`sungRowsOf` measures every
  line of the song once, with `TextMeasurer`, and picks two rows when a line cannot fit one row even at its smallest
  allowed size). A line too long for its rows is drawn smaller until it fits (`fitLine`: 100, 90, 80, 70 %, never
  below 9 sp unless the size set is smaller). **A sung line that still does not fit is not cut off:** it stays on one
  line and `TickerText` slides it sideways while it is sung — it waits 0.6 s, then moves linearly so the end arrives
  at about 85 % of the line's time (`LyricWindow.durationMs`, the time until the next line), with soft fades at the
  ends — all inside its fixed row, so the card keeps its size. The other lines that do not fit end in "...".
  `AnimatedContent` uses a `snap()` size transform, so only the text animates. The same composable draws the real
  window and the preview in Settings.
* **Look and movement of the card.** The background colour / opacity / corner radius / width from Settings are the
  base; a little violet on top and deep purple below make glass, with a 1 dp gradient edge. Behind the words
  `drawBackdrop` (`BackdropDrawing.kt`) draws *Bars* (centred rounded bars like the Now Playing animation: the left
  ones follow the low part of the music, the right ones the high part, each wobbles on its own), *Glow* (two drifting
  colour clouds) or nothing, and the sung line swells 3.5 % on every beat (`graphicsLayer`). Both read `MusicMotion`
  — five float states (`low`, `mid`, `high`, `pulse`, `clock`) that are only ever read in draw / graphics-layer blocks
  and are kept up to date by `rememberMusicMotion`, one `withFrameNanos` loop at 30 fps that runs only while the music
  plays and a style uses it. Nothing is recomposed or measured by the motion.
* **Moving with the music** (`audio/`). `BeatAnalyzer` (a singleton, started by `FloatingLyricsOverlay.followCurrentSong`
  while the floating lyrics are on, some style uses the motion and the screen is on) opens the song file with
  `MediaExtractor`, decodes it with `MediaCodec` on a low-priority thread of its own and feeds the sound to
  `HopAnalyzer`: it averages every four samples into one and splits the rest into low (below 140 Hz), middle and high
  (above 2.2 kHz) with one-pole filters (no FFT), one value per band every 20 ms, scaled to the loudest recent value of
  that band. A beat is a short rise of the low band: a peak clearly above the last 0.8 s, not tiny next to the loudest
  recent low sound, and at least 290 ms after the previous beat (tested on generated music: about 97 % of the drum
  hits found, none invented, no timing bias). `AudioProfile` holds the result as one byte per band per step and the
  beat times, and can be read while it is still being built (volatile counters). Everything is looked up by the
  playing **position** (`PlayerManager.getCurrentPosition()` + 40 ms, the picture reaches the screen a frame later),
  never by the clock, so a seek, a pause or a slow phone can not put it out of step. Until the analysis has reached
  the position (the first moments of a song, a seek far ahead, a file that cannot be decoded) `MusicMotion` plays a
  made-up groove (the same idea as `MusicVisualizer`). The last six songs are kept in memory. No permission is needed
  because the file is read, not the speaker or the microphone. **The Now Playing visualizer is not touched.**

## 5. Buttons and icons
Every icon is a vector drawable in `app/src/main/res/drawable/ic_*.xml` (24×24, white fill, tinted in code).
No emoji and no text glyphs are used as icons.

The one exception is the **Lyrix logo** (the launcher icon), which is full-colour artwork. The picture is the bitmap
`res/drawable-*dpi/ic_launcher_logo.png`; the adaptive icon (`mipmap-anydpi-v26/ic_launcher*.xml`) is made of
`ic_launcher_background` (plain black, the colour around the artwork's glowing frame), `ic_launcher_foreground` (the
bitmap, inset 23 % so the whole logo stays inside the 66dp safe zone and no launcher shape cuts it) and
`ic_launcher_monochrome` (the Android 13 themed icon: just the note, one colour). Android 7 - 7.1 use the PNGs in
`mipmap-*dpi/ic_launcher*.png`, and the playback notification's `ic_stat_lyrix` is the same note. When the logo
changes, replace all of these together; the two note vectors are traced from the artwork.

| Component | File | Use |
|-----------|------|-----|
| `VectorIcon` | `ui/components/VectorIcon.kt` | draw any `ic_*` drawable with a tint |
| `IconActionButton` | `ui/components/Buttons.kt` | round icon-only button with ripple + accessibility label |
| `MelodiqButton` | `ui/components/Buttons.kt` | labelled button, optional icon, `Filled` / `Tonal` / `Outlined` |
| `EmptyState` | `ui/components/EmptyState.kt` | icon + title + hint + action buttons |
| `ArtworkImage` | `ui/components/ArtworkImage.kt` | album art with a built-in music-note fallback |
| `EqualizerBars` | `ui/components/EqualizerBars.kt` | animated "now playing" bars |

To add an icon: save a 24×24 vector as `res/drawable/ic_name.xml` (`android:fillColor="#FFFFFFFF"`), then
`VectorIcon(id = R.drawable.ic_name)` or `IconActionButton(icon = R.drawable.ic_name, …)`.

## 6. Playlists
* Stored in the `playlists` table that has always existed (`PlaylistEntity`: id, name, `songIdsJson`, createdAt), so
  no migration. A playlist is a name plus song ids in the order they were added; the songs stay in the library, and
  ids that no longer exist are skipped when a playlist is shown.
* `PlaylistRepository` serialises every change behind a mutex (two quick taps never overwrite each other).
  `PlaylistNames` trims / collapses spaces / caps at 40 characters and rejects blank or duplicate names.
* `PlaylistsViewModel` is created once in `AppRoot` (like the player and library view models). It combines the
  playlists with the library songs into `PlaylistItem`s; `uiState.loaded` stops the empty message flashing.
* Screens: `PlaylistsScreen` (the tab), `PlaylistDetailScreen` (route `playlist/{playlistId}`). Dialogs in
  `PlaylistDialogs.kt`: name (create / rename), confirm, add-to-playlist, multi-song picker.
* **⋮ on a song** = `SongMenuHost` (menu → pick a playlist → new playlist name). Put it *outside* a `LazyColumn`
  (a dialog inside a lazy item disappears when the item scrolls away). Extra rows can be added with `extraActions`.
* **Changing the database.** Raise `version` in `AppDatabase` **and** add a `Migration` to `data/db/Migrations.kt`
  (`ALL`, empty at version 1; the file shows how). A missing migration makes Room stop with an error instead of
  wiping playlists, favourites and saved lyrics. Only a *downgrade* (an older Lyrix installed over a newer database)
  starts from scratch (`fallbackToDestructiveMigrationOnDowngrade`). Every build writes the schema to
  `app/schemas/` (the CI run uploads it as `room-schemas`); keep those files in the repository.

## 7. Project map
```
data/        model, Room database (+ Migrations), LRCLIB service, repositories (music, lyrics, playlists, settings, per-app styles, custom lyrics)
player/      MusicService (ExoPlayer) + SkippablePlayer + NotificationButtons + PlayerManager (app-wide controller) + ShuffleCoordinator
lyrics/      LyricsManager — lyrics + current line of the playing song, shared by screen and floating window
audio/       BeatAnalyzer + AudioProfile — listens to the song file: loudness of the low / middle / high parts and the beats
overlay/     FloatingLyricsOverlay, OverlayLifecycleOwner, OverlayPermission, AppForeground,
             ForegroundAppTracker + UsageAccessPermission (which app is on screen), InstalledApps (app names / list)
ui/          AppNavigation (AppRoot), screens (incl. Settings), components, view models, theme
util/        MediaTags, TrackMatcher/TitleCleaner, LrcParser, LyricsQuality, LyricsCleanup, ShuffleDeck, helpers
```

## 8. Backup, privacy and tests
* **Backup** (`res/xml/data_extraction_rules.xml` for Android 12+, `res/xml/backup_rules.xml` for Android 11 and older,
  both referenced in the manifest). The settings (`files/datastore`) and the saved lyrics (`files/lyrics`) are backed
  up and restored. The database (`melodiq.db` with its `-wal`, `-shm` and `-journal` files) and `files/crash_reports`
  are left out: playlists, favourites and the song list key on MediaStore ids, which are different on every phone, so a
  restored copy would point at the wrong songs. A restored phone simply scans its own library again.
* **Privacy.** Music files stay on the phone. What is sent is a song's title, artist, album and length, to lrclib.net,
  to find its lyrics: the permission screen says so and Settings → Lyrics → *Online lyrics lookup* turns it off. Debug
  builds log every request address; release builds do not.
* **Tests.** `app/src/test` holds JUnit 4 tests for the pure helpers (`LrcParser`, `TrackMatcher`, `ShuffleDeck`,
  `LyricsQuality`, `PlaylistNames`, `MediaTags`). The CI workflow runs `./gradlew testDebugUnitTest` after the APK is
  built and uploaded; a failing test never fails the run (the report is uploaded as `build-reports`).
