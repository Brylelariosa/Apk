# MHTML extraction pipeline — perf benchmarks

Real, executable JVM microbenchmarks backing the v25 optimizations in
`MhtmlParser.kt`. Run any of them with `java <file>.java` (JDK 11+, no
build step needed).

**Why plain JVM, not the Android app:** `android.graphics.Bitmap` /
`BitmapFactory` and `android.util.Base64` aren't available outside an
Android runtime, so these isolate the parts of the pipeline that *are*
reproducible on a JVM — the redundant buffer copy and the redundant disk
reads — plus a real-threads simulation of the CPU/IO overlap structure.
None of these numbers are a substitute for on-device profiling
(Android Studio Profiler / Perfetto) on real target hardware; they're the
"prove the mechanism, not the exact device number" evidence referenced in
MhtmlParser.kt's v25 docstring.

| Benchmark | What it measures | Result on this run |
|---|---|---|
| `Bench1Base64Copy.java` | Cost of `bodyStream.toByteArray()` before `Base64.decode()` vs. decoding straight from the backing array | ~4–7% faster on this step |
| `Bench2DiskReread.java` | Cost of `BitmapFactory.decodeFile()`'s two reads of a file just written vs. decoding the bytes already in memory | ~70–75% faster on this step (disk-speed dependent — real device eMMC/UFS will likely show a *larger* relative win than this container's fast filesystem) |
| `Bench3Pipeline.java` | Real thread-scheduled simulation: serial (extract → block on thumbnail → repeat) vs. overlapped (extract continues immediately; thumbnail runs concurrently, `Semaphore(2)`-bounded) | ~1.75–2.3x speedup across a modeled 4–10ms thumbnail-cost range |

Bench3's per-image millisecond costs are modeled inputs (BitmapFactory
isn't available here to measure directly) — the concurrency/thread
scheduling itself is real, not simulated.
