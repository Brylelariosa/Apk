package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * SCREENSHOT TIMING
 * -----------------
 * Primary:  onWindowFocusChanged(hasFocus=true) — fires once the panel animation
 *           is fully complete; most accurate trigger.
 * Fallback: onResume + 400 ms — for home screen / launcher / menus where Android
 *           does not grant focus to a translucent window overlaid on the launcher,
 *           so onWindowFocusChanged(true) never arrives.
 * Both paths are guarded by screenshotTaken so only one fires.
 *
 * SAVE RELIABILITY
 * ----------------
 * performGlobalAction() returns a Boolean — true = dispatched, not saved.
 * If it returns false (system briefly busy), we retry once after 200 ms.
 * finish() is delayed 1500 ms so our foreground component keeps the process
 * at a higher priority while the system completes the async MediaStore write.
 *
 * CPU / GPU
 * ---------
 * • Handler(mainLooper) instead of view.postDelayed — avoids triggering the
 *   view traversal machinery (measure / layout / draw pass) for plain delays.
 * • window.setBackgroundDrawable(null) — prevents first-frame surface composite
 *   from producing a visible flash.
 * • hardwareAccelerated=false in the manifest — no GPU layer allocated at all.
 * • NOTE: do NOT shrink the window to 1×1 px. On the home screen / launcher the
 *   screenshot layer composition order differs from inside apps — a 1×1 foreground
 *   surface causes the system to show the preview but discard the file save.
 */
class TriggerActivity : Activity() {

    // Single handler; removeCallbacksAndMessages(null) in onDestroy clears everything.
    private val handler = Handler(Looper.getMainLooper())

    private var screenshotTaken = false
    private var retryCount = 0
    private var screenshotRunnable: Runnable? = null
    private var finishRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // No background → no first-frame flash.
        window.setBackgroundDrawable(null)

        if (ScreenshotAccessibilityService.instance == null) { finish(); return }
    }

    override fun onResume() {
        super.onResume()
        if (!screenshotTaken && screenshotRunnable == null) {
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            // 600 ms: gives the QS panel collapse animation time to fully complete
            // on slower devices before we fire. onWindowFocusChanged bypasses this
            // delay when focus arrives sooner (normal in-app case).
            handler.postDelayed(r, 600L)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
            takeScreenshot()
        }
    }

    private fun takeScreenshot() {
        if (screenshotTaken) return

        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finish(); return }

        val dispatched = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        if (!dispatched && retryCount < 1) {
            retryCount++
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 200L)
            return
        }

        screenshotTaken = true

        val r = Runnable { finish() }
        finishRunnable = r
        handler.postDelayed(r, 1500L)
    }

    override fun onPause() {
        super.onPause()
        // Paused before firing → something jumped in front; cancel so we don't
        // screenshot the wrong screen.
        if (!screenshotTaken) {
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cancel every pending message in one call — no reference juggling needed.
        handler.removeCallbacksAndMessages(null)
        screenshotRunnable = null
        finishRunnable = null
    }
}
