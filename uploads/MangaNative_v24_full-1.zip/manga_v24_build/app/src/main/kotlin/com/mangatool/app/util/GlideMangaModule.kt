package com.mangatool.app.util

import android.content.Context
import com.bumptech.glide.Glide
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.Registry
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
import com.bumptech.glide.load.engine.cache.LruResourceCache

/**
 * Custom Glide memory configuration tuned for MangaTool's usage pattern.
 *
 * Registered via AndroidManifest meta-data (no kapt / annotation processor needed):
 *   <meta-data android:name="com.mangatool.app.util.GlideMangaModule"
 *              android:value="GlideModule" />
 *
 * ── Why this module exists ────────────────────────────────────────────────────
 * Glide's default memory cache is 8% of maxMemory (e.g. 128MB heap → 10 MB).
 * MangaTool's thumbnail pattern is:
 *   • 140 px WebP thumbnails: ~10–20 KB decoded → ~80 KB Bitmap (RGB_565).
 *   • Up to 50 chapters × 3 visible covers = 150 simultaneous thumbnails at once.
 *   • 150 × 80 KB = 12 MB — already exceeds the default 10 MB cache on budget
 *     devices. Result: Glide evicts covers on every scroll, causing re-decode
 *     from disk (noticeable flicker on slow eMMC storage).
 *
 * ── Memory cache (LruResourceCache) ──────────────────────────────────────────
 * Set to 15% of maxMemory, clamped to [16 MB, 56 MB]:
 *   • 16 MB floor: holds ~200 RGB_565 cover thumbnails — enough for 50 chapters
 *     with generous room for preview-page Glide entries.
 *   • 56 MB ceiling: prevents excessive heap usage on high-RAM devices where
 *     15% would be 80–100 MB (wasteful for a gallery app).
 *   • Budget device example (512 MB RAM, 128 MB max heap):
 *     15% × 128 MB = 19 MB — comfortably above the 12 MB active-set estimate.
 *
 * ── Bitmap pool (LruBitmapPool) ───────────────────────────────────────────────
 * Set to 10% of maxMemory, clamped to [8 MB, 32 MB]:
 *   Glide reuses pooled Bitmaps via inBitmap to avoid GC-pressure allocations.
 *   The pool needs to be large enough to absorb thumbnail reuse cycles (140 px
 *   thumbnails are all the same dimensions — very high reuse rate).
 *   The 8 MB floor holds ~100 pooled RGB_565 thumbnail slots (enough for the
 *   typical 3-column grid at any scroll depth). The 32 MB ceiling prevents the
 *   pool from consuming RAM needed for active Bitmaps during fast scrolling.
 */
class GlideMangaModule : com.bumptech.glide.module.GlideModule {

    override fun applyOptions(context: Context, builder: GlideBuilder) {
        val maxMem = Runtime.getRuntime().maxMemory()

        // Memory cache: 15% of max heap, clamped [16 MB, 56 MB]
        val cacheSize = (maxMem * 0.15).toLong()
            .coerceIn(16L * 1024 * 1024, 56L * 1024 * 1024)
        builder.setMemoryCache(LruResourceCache(cacheSize))

        // Bitmap pool: 10% of max heap, clamped [8 MB, 32 MB]
        val poolSize = (maxMem * 0.10).toLong()
            .coerceIn(8L * 1024 * 1024, 32L * 1024 * 1024)
        builder.setBitmapPool(LruBitmapPool(poolSize))
    }

    override fun registerComponents(context: Context, glide: Glide, registry: Registry) {
        // No custom components needed — default Glide pipeline is sufficient.
    }
}
