package com.mangatool.app.util

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.getSharedPreferences("mie_prefs", Context.MODE_PRIVATE)
    }

    var minSizeKb: Int
        get() = sp.getInt("min_size_kb", 40)
        set(v) { sp.edit().putInt("min_size_kb", v).apply() }

    var excludeGifs: Boolean
        get() = sp.getBoolean("exclude_gifs", true)
        set(v) { sp.edit().putBoolean("exclude_gifs", v).apply() }

    var reverseOrder: Boolean
        get() = sp.getBoolean("reverse_order", false)
        set(v) { sp.edit().putBoolean("reverse_order", v).apply() }

    /** Last sort field used in the built-in file manager ("NAME", "DATE", "TYPE"). */
    var fileSortBy: String
        get() = sp.getString("file_sort_by", "NAME") ?: "NAME"
        set(v) { sp.edit().putString("file_sort_by", v).apply() }

    /** Last sort direction used in the built-in file manager. */
    var fileSortAscending: Boolean
        get() = sp.getBoolean("file_sort_ascending", true)
        set(v) { sp.edit().putBoolean("file_sort_ascending", v).apply() }

    /** Persisted tree URI for Extract save folder. Null = not set. */
    var extractFolderUri: String?
        get() = sp.getString("extract_folder_uri", null)
        set(v) { sp.edit().putString("extract_folder_uri", v).apply() }

    /** Persisted tree URI for Merge save folder. Null = not set. */
    var mergeFolderUri: String?
        get() = sp.getString("merge_folder_uri", null)
        set(v) { sp.edit().putString("merge_folder_uri", v).apply() }

    /** Display name of the extract folder (shown in settings). */
    var extractFolderName: String?
        get() = sp.getString("extract_folder_name", null)
        set(v) { sp.edit().putString("extract_folder_name", v).apply() }

    /** Display name of the merge folder (shown in settings). */
    var mergeFolderName: String?
        get() = sp.getString("merge_folder_name", null)
        set(v) { sp.edit().putString("merge_folder_name", v).apply() }
}
