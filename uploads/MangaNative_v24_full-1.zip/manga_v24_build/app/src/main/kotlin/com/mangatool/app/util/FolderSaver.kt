package com.mangatool.app.util

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.mangatool.app.model.ImageGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

// Extension: save into a user-chosen folder (ACTION_OPEN_DOCUMENT_TREE URI)
object FolderSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val count: Int, val folderName: String)

    /**
     * Save extract groups into a user-picked folder tree URI — **fast, lossless**.
     *
     * Speed strategy — two-phase approach:
     *
     *   Phase 1 (sequential):  Create all DocumentFiles via SAF.
     *                          SAF's createFile() is an IPC round-trip that MUST be
     *                          sequential — DocumentFile is not thread-safe.
     *
     *   Phase 2 (parallel):    Write the actual bytes to each already-created URI.
     *                          Each URI is independent, so IO threads can blast all
     *                          files to disk simultaneously — same as how ZArchiver
     *                          feels instant when extracting.
     *
     * Quality: raw byte-copy for every format (JPEG, PNG, WEBP, GIF).
     *          Zero decoding, zero re-encoding, zero quality loss.
     */
    suspend fun saveExtractToTree(
        context: Context,
        treeUri: Uri,
        groups: List<ImageGroup>,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")

        val totalImages = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        onProgress(Progress("Creating folders…", 0))

        // ── Phase 1: create all DocumentFiles sequentially ────────────────────
        data class WriteTask(val uri: Uri, val srcPath: String)
        val tasks = mutableListOf<WriteTask>()

        var createsDone = 0
        groups.forEach { group ->
            val subName = group.groupName.sanitize()
            // Re-use existing subfolder or create
            val dir = root.findFile(subName)?.takeIf { it.isDirectory }
                ?: root.createDirectory(subName)
                ?: throw IllegalStateException("Cannot create folder: $subName")

            group.displayImages.forEach { img ->
                createsDone++
                onProgress(Progress(
                    "Creating files… $createsDone/$totalImages",
                    (createsDone * 10) / totalImages   // first 10% for creation phase
                ))

                val mime     = mimeForExtSafe(img.ext)
                val baseName = img.name.substringBeforeLast('.')

                // Attempt direct create — no pre-scan, no extra IPC round-trips
                var file = dir.createFile(mime, baseName)

                // Only if SAF auto-renamed do we fix it
                if (file != null &&
                    file.name != img.name &&
                    file.name != "$baseName.${img.ext}") {
                    dir.findFile(img.name)?.delete()
                    dir.findFile(baseName)?.delete()
                    file.delete()
                    file = dir.createFile(mime, baseName)
                }

                file?.let { tasks.add(WriteTask(it.uri, img.filePath)) }
            }
        }

        // ── Phase 2: write all in parallel ────────────────────────────────────
        onProgress(Progress("Writing ${tasks.size} images (parallel)…", 10))
        val written = AtomicInteger(0)

        coroutineScope {
            tasks.map { task ->
                async(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(task.uri)
                            ?.buffered(65_536)
                            ?.use { out ->
                                File(task.srcPath).inputStream().buffered(65_536).use { it.copyTo(out) }
                                written.incrementAndGet()   // only on a real write
                            }
                    }
                    val done = written.get()
                    // Report every 5 images to avoid hammering Main
                    if (done % 5 == 0 || done == tasks.size) {
                        onProgress(Progress(
                            "Writing $done/${tasks.size}…",
                            10 + (done * 90) / tasks.size
                        ))
                    }
                }
            }.awaitAll()
        }

        val finalCount = written.get()
        onProgress(Progress("Done! $finalCount images saved", 100))
        return SaveResult(finalCount, root.name ?: "Selected folder")
    }

    /**
     * Save merged pairs — parallel encode then sequential write.
     *
     * Encoding (merge + PNG compress) is the slow step. We run all pairs
     * in parallel on the IO thread pool, then write the resulting byte arrays
     * one-by-one (SAF DocumentFile is not thread-safe for concurrent writes).
     *
     * Naming: single pair → "Name.png"  |  multiple → "Name_1.png", "Name_2.png"…
     * Zero quality loss — lossless PNG, full resolution.
     */
    suspend fun saveMergeToTree(
        context: Context,
        treeUri: Uri,
        groups: List<ImageGroup>,
        photoName: String = "Merged",
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root     = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")
        val safeName = photoName.sanitize().ifBlank { "Merged" }

        // Flatten all pairs into a single indexed list
        data class Work(val group: ImageGroup, val pairIdx: Int, val pair: List<com.mangatool.app.model.ImageItem>)
        val allWork = groups.flatMap { g ->
            ImageMerger.pairImages(g.displayImages).mapIndexed { i, p -> Work(g, i, p) }
        }
        val total = allWork.size.coerceAtLeast(1)
        onProgress(Progress("Encoding 0/$total…", 0))

        // ── Parallel encode: run merge+PNG on every CPU core at once ──────────
        val encodedBytes: List<ByteArray?> = coroutineScope {
            allWork.mapIndexed { idx, work ->
                async(Dispatchers.IO) {
                    val swapped = work.group.pairSwaps.contains(work.pairIdx)
                    val bm  = ImageMerger.merge(work.pair, swapped)
                    val out = bm?.toPngBytes().also { bm?.recycle() }
                    onProgress(Progress("Encoding ${idx + 1}/$total…", ((idx + 1) * 90) / total))
                    out
                }
            }.awaitAll()
        }

        // ── Sequential write: SAF is not thread-safe ──────────────────────────
        onProgress(Progress("Writing files…", 92))
        var written = 0
        encodedBytes.forEachIndexed { idx, bytes ->
            if (bytes == null) return@forEachIndexed
            val baseName = if (total == 1) safeName else "${safeName}_${idx + 1}"
            root.findFile("$baseName.png")?.delete()
            val file = root.createFile("image/png", baseName)
            file?.let {
                context.contentResolver.openOutputStream(it.uri)
                    ?.buffered(65_536)
                    ?.use { out -> out.write(bytes) }
            }
            written++
        }

        onProgress(Progress("Done! $written photos saved", 100))
        return SaveResult(written, root.name ?: "Selected folder")
    }

    private fun mimeForExtSafe(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/png"
    }

    private fun String.sanitize() = replace(Regex("""[\\/:\"*?<>|]"""), "_").trim().ifBlank { "MIE" }
}
