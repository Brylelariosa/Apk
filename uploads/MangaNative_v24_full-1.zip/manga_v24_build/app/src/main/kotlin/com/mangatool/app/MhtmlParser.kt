package com.mangatool.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MhtmlParser {

    /**
     * Stream-parse an MHTML file into an ImageGroup without loading the whole
     * file into RAM.
     *
     * ── Memory model ──────────────────────────────────────────────────────────
     * v16: used StringBuilder bodyBuf, accumulating every part body as text.
     *   For a 200 KB image base64-encoded to ~270 KB of ASCII, the old path
     *   allocated: StringBuilder (~270 KB) → toString() String (~270 KB) →
     *   toByteArray(ISO_8859_1) (~270 KB) → Base64.decode() result (~200 KB).
     *   Peak per image ≈ 810 KB. Non-image parts (HTML, CSS) were also fully
     *   accumulated even though they were always discarded.
     *
     * v19 improvements:
     *   1. Headers are parsed FIRST. Non-image parts skip body accumulation
     *      entirely — only the boundary-scan loop runs, zero allocation.
     *   2. Image bodies accumulate into a ByteArrayOutputStream pre-sized to
     *      128 KB. No intermediate String. Single toByteArray() call feeds
     *      Base64.decode() directly.
     *      Peak per image ≈ ~270 KB (stream buffer) + ~200 KB (decoded) = ~470 KB.
     *      Saves ~340 KB of intermediate allocation per image.
     *   3. onProgress is throttled to fire every 5 images — eliminates rapid
     *      main-thread post() spam on chapters with many pages.
     *
     * v21 thumbnail generation:
     *   Immediately after writing each extracted image file, a 140 px WebP
     *   thumbnail is generated in a sibling "thumbnails/" directory.
     *   - inSampleSize adaptive (bounds check first) instead of hardcoded 8.
     *   - RGB_565 (2 bytes/px) instead of ARGB_8888 (4 bytes/px) for the
     *     thumbnail bitmap — halves peak memory.
     *   - WEBP_LOSSY (API 30+) / WEBP fallback (API 24-29) quality 65
     *     produces files ≈ 3–6 KB. WebP decodes faster than JPEG at this size.
     *   - bitmap.recycle() immediately after compress — pixel buffer returned
     *     to native heap before the next image begins.
     *
     * v22 extraction performance:
     *   1. BufferedInputStream (64 KB) wraps the raw ContentResolver stream.
     *   2. onProgress throttled every 10 images.
     *
     * v24 generateThumbnail fix:
     *   - WEBP_LOSSY requires API 30. minSdk is 24, so API 24-29 devices
     *     crashed with NoSuchFieldError. Fixed with Build.VERSION check.
     *   - inSampleSize is now adaptive (bounds decode first) instead of
     *     hardcoded 8. A hardcoded 8 on a 100×120 source image produced a
     *     12×15 px thumbnail, which compressed to a nearly-useless 1 KB WebP.
     *     The new code targets 280 px coarse then scales to exactly 140 px.
     */
    suspend fun parse(
        stream: InputStream,
        filename: String,
        tempDir: File,
        onProgress: ((done: Int) -> Unit)? = null
    ): ImageGroup? = withContext(Dispatchers.IO) {
        try {
            val reader = java.io.BufferedInputStream(stream, 65_536)
                .bufferedReader(Charsets.ISO_8859_1)

            // ── 1. Detect MIME boundary ──────────────────────────────────────
            var boundary: String? = null
            var line: String? = reader.readLine()
            while (line != null && boundary == null) {
                boundary = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.get(1)
                if (boundary == null) line = reader.readLine()
            }
            if (boundary == null) return@withContext null

            val boundaryMarker = "--$boundary"
            val closingMarker  = "--$boundary--"

            // ── 2. Skip to the first boundary line ──────────────────────────
            while (line != null && !line.startsWith(boundaryMarker)) {
                line = reader.readLine()
            }

            // Thumbnail directory is INSIDE tempDir (not beside it).
            // Each extraction gets its own unique tempDir, so concurrent
            // extractions never clobber each other's thumbnail files.
            val thumbDir = File(tempDir, "thumbnails")
            thumbDir.mkdirs()

            data class Extracted(
                val sortKey: String,
                val filePath: String,
                val size: Int,
                val ext: String,
                val thumbPath: String?
            )
            val extracted = mutableListOf<Extracted>()
            var partIdx = 0

            tempDir.mkdirs()

            val bodyStream = ByteArrayOutputStream(128 * 1024)

            // ── 3. State machine: boundary → headers → body → boundary ──────
            while (line != null && !line.startsWith(closingMarker)) {

                val headers = StringBuilder()
                line = reader.readLine()
                while (line != null && line.isNotBlank()) {
                    headers.append(line).append('\n')
                    line = reader.readLine()
                }

                val headStr   = headers.toString()
                val typeMatch = CONTENT_TYPE_RE.find(headStr)
                val encoding  = ENCODING_RE.find(headStr)?.groupValues?.get(1)?.lowercase()

                if (typeMatch != null) {
                    bodyStream.reset()
                    line = reader.readLine()
                    while (line != null && !line.startsWith(boundaryMarker)) {
                        bodyStream.write(line.toByteArray(Charsets.ISO_8859_1))
                        line = reader.readLine()
                    }

                    val rawExt = typeMatch.groupValues[1].lowercase()
                    val ext    = if (rawExt == "jpeg") "jpg" else rawExt

                    val bytes: ByteArray? = when (encoding) {
                        "base64" -> try {
                            Base64.decode(bodyStream.toByteArray(), Base64.DEFAULT)
                        } catch (_: Exception) { null }

                        "quoted-printable" ->
                            decodeQP(bodyStream.toString("ISO-8859-1"))
                                .toByteArray(Charsets.ISO_8859_1)

                        else -> bodyStream.toByteArray()
                    }

                    if (bytes != null && bytes.size > 100) {
                        val sortKey = partIdx.toString().padStart(8, '0')
                        val file    = File(tempDir, "$sortKey.$ext")
                        BufferedOutputStream(FileOutputStream(file)).use { it.write(bytes) }

                        val thumbFile = File(thumbDir, "$sortKey.webp")
                        val thumbPath = generateThumbnail(file.absolutePath, thumbFile)

                        extracted += Extracted(sortKey, file.absolutePath, bytes.size, ext, thumbPath)

                        if (extracted.size % 10 == 0) {
                            onProgress?.invoke(extracted.size)
                        }
                    }

                } else {
                    line = reader.readLine()
                    while (line != null && !line.startsWith(boundaryMarker)) {
                        line = reader.readLine()
                    }
                }

                partIdx++
            }

            if (extracted.isNotEmpty()) onProgress?.invoke(extracted.size)

            if (extracted.isEmpty()) return@withContext null

            extracted.sortBy { it.sortKey }
            val images = extracted.mapIndexed { i, r ->
                ImageItem(
                    originalIdx   = i,
                    filePath      = r.filePath,
                    ext           = r.ext,
                    size          = r.size,
                    thumbnailPath = r.thumbPath
                )
            }
            ImageGroup(groupName = smartRename(filename)).also { g -> g.allImages.addAll(images) }

        } catch (_: Exception) { null }
    }

    // ── Thumbnail generation ──────────────────────────────────────────────────

    /**
     * Generate a 140 px WebP lossy thumbnail from [imagePath] and write it to [thumbFile].
     *
     * v24 changes vs v21:
     *
     * 1. API crash fix — WEBP_LOSSY (added in API 30):
     *    The previous code called `Bitmap.CompressFormat.WEBP_LOSSY` unconditionally.
     *    minSdk is 24, so devices running Android 7–10 (API 24–29) crashed with
     *    `NoSuchFieldError: WEBP_LOSSY` at extraction time.
     *    Fix: `if (Build.VERSION.SDK_INT >= 30)` selects WEBP_LOSSY; the pre-30
     *    path uses the deprecated `WEBP` constant (available since API 17) which is
     *    identical at quality < 100 (always lossy in that range).
     *
     * 2. Adaptive inSampleSize (was hardcoded to 8):
     *    A fixed inSampleSize=8 decodes at 1/8 resolution regardless of the source
     *    dimensions. For a small source image (e.g. 100×120 px header image) this
     *    produces a 12×15 px bitmap — far below the 140 px target. The resulting
     *    WebP is correct but nearly useless as a thumbnail (blurry, extremely small).
     *    For very large images (4000×6000 px retina scans), inSampleSize=8 gives
     *    500×750 px — 3.5× larger than needed, wasting ~500 KB of RAM per thumbnail.
     *
     *    New approach (mirrors BitmapUtils.decodeThumbnail):
     *    a) Decode bounds without loading pixels (inJustDecodeBounds).
     *    b) Validate that the source has nonzero dimensions (skips 0-byte parts).
     *    c) Double inSampleSize until the coarse decode is ≥ 280 px on the longest
     *       axis (2× the 140 px target), ensuring the post-scale is always a
     *       gentle downscale, never an upscale.
     *    d) createScaledBitmap to exactly 140 px. Bilinear filter (true) gives
     *       visually clean edges compared to nearest-neighbour.
     *    e) Immediately recycle the intermediate rough bitmap if a new one was made.
     *
     * Returns the absolute path of the written thumbnail, or null on any failure.
     * A null result is handled gracefully in the adapter (falls back to filePath).
     */
    internal fun generateThumbnail(imagePath: String, thumbFile: File): String? {
        return try {
            // ── Step 1: decode bounds without pixel data ──────────────────────
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(imagePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            // ── Step 2: compute adaptive inSampleSize ─────────────────────────
            // Target coarse size: 280 px on longest axis (2× thumbnail target).
            // This gives createScaledBitmap a ~2× downscale budget — enough to
            // apply bilinear filtering without upsampling artifacts.
            val targetCoarse = 280
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= targetCoarse) {
                sample *= 2
            }

            // ── Step 3: coarse decode with RGB_565 ────────────────────────────
            // RGB_565 = 2 bytes/pixel vs ARGB_8888 = 4 bytes/pixel.
            // Manga pages are JPEGs with no alpha — identical visual quality at
            // thumbnail sizes. Halves the peak Bitmap allocation.
            val rough = BitmapFactory.decodeFile(imagePath, BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
                inSampleSize      = sample
            }) ?: return null

            // ── Step 4: precise scale to 140 px on longest axis ──────────────
            val largest = maxOf(rough.width, rough.height)
            val bitmap = if (largest > 140) {
                val scale = 140f / largest
                val w = (rough.width  * scale).toInt().coerceAtLeast(1)
                val h = (rough.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(rough, w, h, /* filter= */ true)
                if (scaled !== rough) rough.recycle()  // free the oversized coarse bitmap
                scaled
            } else {
                rough  // source already ≤ 140 px; use directly
            }

            // ── Step 5: compress to WebP ──────────────────────────────────────
            // WEBP_LOSSY was added in API 30.  The deprecated WEBP constant is
            // available from API 17 and is always lossy when quality < 100.
            // Both produce byte-for-byte identical output for quality=65 JPEG source.
            FileOutputStream(thumbFile).use { out ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSY, 65, out)
                } else {
                    @Suppress("DEPRECATION")
                    bitmap.compress(Bitmap.CompressFormat.WEBP, 65, out)
                }
            }

            // ── Step 6: return pixel buffer to native heap immediately ────────
            // DO NOT wait for GC. On low-end devices the native heap is limited;
            // holding 30 un-recycled RGB_565 bitmaps (~100 KB each) during
            // batch extraction causes premature native OOM before Java GC fires.
            bitmap.recycle()

            thumbFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    // ── Pattern constants — compiled once at class load, not per call ─────────
    private val CONTENT_TYPE_RE = Regex(
        """Content-Type:\s*image/(jpeg|jpg|png|gif|webp)""", RegexOption.IGNORE_CASE)
    private val ENCODING_RE = Regex(
        """Content-Transfer-Encoding:\s*(base64|quoted-printable)""", RegexOption.IGNORE_CASE)

    private fun decodeQP(s: String): String =
        s.replace(Regex("=[\\r\\n]+"), "")
         .replace(Regex("=[0-9A-Fa-f]{2}")) { it.value.substring(1).toInt(16).toChar().toString() }

    // ── Filename prettifier ───────────────────────────────────────────────────
    private fun smartRename(filename: String): String {
        var n = filename.replace(Regex("\\.mhtml?$", RegexOption.IGNORE_CASE), "")
        n = n.replace(Regex("[_+]"), " ")
        n = n.replace(Regex("\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE), "")
        n = n.trim()

        val m = Regex("""^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
            RegexOption.IGNORE_CASE).find(n)

        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(Regex("(\\d+)")) { it.value.padStart(3, '0') }
            val cp = prefix.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        } else {
            n = n.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trim()
        }

        return n.replace(Regex("\\s+-\\s*$"), "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
