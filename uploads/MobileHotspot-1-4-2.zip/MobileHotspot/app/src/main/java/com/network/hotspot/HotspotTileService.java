package com.network.hotspot;

import android.content.SharedPreferences;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class HotspotTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        Tile tile = getQsTile();
        if (tile == null) return;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);

        if (tile.getState() == Tile.STATE_ACTIVE) {
            // ── Tapped while ON ──
            // Let tile show OFF visually — hotspot keeps running, nothing disabled
            tile.setState(Tile.STATE_INACTIVE);
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, false).apply();
            tile.updateTile();

        } else {
            // ── Tapped while OFF ── enable hotspot via Shizuku on background thread
            tile.setState(Tile.STATE_ACTIVE);
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, true).apply();
            tile.updateTile();

            new Thread(() -> {
                HotspotManager.enableHotspotViaShizuku();
                // Re-check real state and update tile after command runs
                boolean on = HotspotManager.isHotspotEnabled(this);
                Tile t = getQsTile();
                if (t != null) {
                    t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
                    t.updateTile();
                }
            }).start();
        }
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;

        boolean enabled = HotspotManager.isHotspotEnabled(this);
        if (!enabled) {
            SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
            enabled = prefs.getBoolean(MainActivity.KEY_ENABLED, false);
        }

        tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.updateTile();
    }
}
