package com.network.hotspot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    static final String PREFS_NAME = "hotspot_prefs";
    static final String KEY_ENABLED = "hotspot_enabled";

    private static final int SHIZUKU_REQ = 1001;

    private SwitchCompat mainSwitch;
    private TextView tvStatus;
    private SharedPreferences prefs;

    // Called when the user responds to the Shizuku permission dialog
    private final Shizuku.OnRequestPermissionResultListener shizukuListener =
        (code, result) -> {
            if (code == SHIZUKU_REQ) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    doEnableHotspot();
                } else {
                    showToast("Shizuku permission denied");
                }
            }
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs     = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mainSwitch = findViewById(R.id.switch_hotspot);
        tvStatus   = findViewById(R.id.tv_status);

        Shizuku.addRequestPermissionResultListener(shizukuListener);

        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mainSwitch.setChecked(hotspotOn);
        updateStatus(hotspotOn);

        mainSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                // ── ON ── actually enable the real hotspot via Shizuku
                prefs.edit().putBoolean(KEY_ENABLED, true).apply();
                updateStatus(true);
                requestEnableHotspot();
            } else {
                // ── OFF ── let UI go to OFF but hotspot keeps running
                prefs.edit().putBoolean(KEY_ENABLED, false).apply();
                updateStatus(false);
                // intentionally no disable call here
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(shizukuListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh real hotspot state (e.g. after returning from system settings)
        boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
        mainSwitch.setChecked(hotspotOn);
        updateStatus(hotspotOn);
    }

    // ── Hotspot enabling flow ─────────────────────────────────────────────────

    private void requestEnableHotspot() {
        if (!HotspotManager.isShizukuAvailable()) {
            showToast("Shizuku not running — opening settings");
            openTetheringSettings();
            return;
        }
        if (!HotspotManager.hasShizukuPermission()) {
            // Shows Shizuku permission dialog; result goes to shizukuListener
            Shizuku.requestPermission(SHIZUKU_REQ);
            return;
        }
        doEnableHotspot();
    }

    /** Runs on a background thread so the shell command doesn't block the UI. */
    private void doEnableHotspot() {
        new Thread(() -> {
            boolean ok = HotspotManager.enableHotspotViaShizuku();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (!ok) {
                    showToast("Shizuku command failed — opening settings");
                    openTetheringSettings();
                }
                // Refresh switch to reflect actual state after command ran
                boolean hotspotOn = HotspotManager.isHotspotEnabled(this);
                mainSwitch.setChecked(hotspotOn);
                updateStatus(hotspotOn);
            });
        }).start();
    }

    private void openTetheringSettings() {
        try {
            startActivity(new Intent("android.settings.TETHER_SETTINGS"));
            return;
        } catch (Exception ignored) {}
        try {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        } catch (Exception ignored) {}
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private void updateStatus(boolean enabled) {
        tvStatus.setText(enabled ? R.string.status_on : R.string.status_off);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
