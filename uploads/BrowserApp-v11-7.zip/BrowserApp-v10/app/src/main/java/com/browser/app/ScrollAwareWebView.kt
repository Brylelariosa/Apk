package com.browser.app

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null

    /** Called by MainActivity so it can set webInputFocused = true */
    var onWebInputFocused: (() -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    /**
     * Returning true tells the system this view always wants keyboard input.
     * Without this, some Android versions skip calling onCreateInputConnection
     * for WebView when in immersive/fullscreen mode.
     */
    override fun onCheckIsTextEditor(): Boolean = true

    /**
     * Called by the IME framework when a web text input gains focus.
     * We notify MainActivity (so it sets webInputFocused = true to block
     * onWindowFocusChanged from re-hiding bars), then explicitly request
     * the keyboard since immersive mode suppresses it by default.
     */
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        if (ic != null) {
            post {
                onWebInputFocused?.invoke()
                val activity = context as? Activity ?: return@post
                WindowInsetsControllerCompat(activity.window, this)
                    .show(WindowInsetsCompat.Type.ime())
            }
        }
        return ic
    }
}
