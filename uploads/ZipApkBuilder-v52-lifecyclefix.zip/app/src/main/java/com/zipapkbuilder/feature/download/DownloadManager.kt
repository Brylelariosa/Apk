package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.feature.build.BuildFlowController
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.model.DownloadRestoreInfo
import com.zipapkbuilder.model.DownloadTask
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Coordinator for every downloaded-artifact concern: the resumable, pausable,
 * multi-task download engine; the Download Manager dialog that watches it;
 * ZIP/APK integrity verification; saving into the public Downloads folder;
 * download history; and persistence of the active queue across process
 * death. The actual work is split across focused, single-responsibility
 * components — this class constructs them (wiring each one's dependencies)
 * and owns the real "features" ([downloadArtifact], [downloadLatestRunLogs],
 * [downloadRunLogs]) that tie GitHub-specific URLs and save/report logic to
 * that generic machinery:
 *
 * - [DownloadEngine] — the resumable HTTP transfer itself
 * - [DownloadQueue] — task list, worker pool, submit/retry/resume/shutdown
 * - [DownloadDialogController] — the Download Manager dialog UI
 * - [DownloadIntegrity] — ZIP/APK verification after a transfer completes
 * - [DownloadHistory] — saving to Downloads + persisted history
 * - [DownloadPersistence] — the active-queue snapshot that survives a
 *   process kill/app restart (see [restorePersistedDownloads])
 * - [ApkInstaller] — offers the extracted APK to the system installer once
 *   an artifact download finishes
 *
 * [downloadQueue] no longer opens [downloadDialogController] directly (the
 * floating bubble's tap target) — it can outlive this whole [DownloadManager]
 * across an Activity recreation, so it only ever reaches
 * [DownloadUiCallback.flashTransferStart]/[DownloadUiCallback.completeTransfer]
 * on whichever Activity is *currently* registered (see [DownloadQueue]'s own
 * kdoc), and that Activity's [showDownloadManagerDialog] is what actually
 * opens this (its own, current) [downloadDialogController]. [downloadEngine]'s
 * checkpoint callback still forward-references [downloadQueue] directly,
 * since both live inside the same [DownloadManager] instance and neither
 * outlives the other — that lambda is never actually invoked until well
 * after both are fully constructed.
 *
 * Both [downloadArtifact] and [downloadRunLogs]/[downloadLatestRunLogs] build
 * their [DownloadTask] through exactly one factory each ([buildArtifactTask],
 * [buildLogTask]) — the same factory [restorePersistedDownloads] calls to
 * rebuild an equivalent task after a restart — so there is one implementation
 * of "what an artifact/log download task looks like," not a "fresh" copy and
 * a "restored" copy that could quietly drift apart.
 */
class DownloadManager(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    companion object {
        // How long a resumable partial download (artifact_*/logs_tmp_*) is kept
        // in cache before the cold-start sweep treats it as abandoned. Deliberately
        // long — see cleanupStaleCacheFiles() — so closing the app and coming back
        // later never loses download progress.
        private const val STALE_PARTIAL_DOWNLOAD_MS = 7L * 24 * 60 * 60 * 1000
    }

    private val downloadPersistence = DownloadPersistence(activity)
    // downloadEngine, downloadQueue, and downloadDialogController are all `by lazy`
    // for the same reason: constructed this early (before the Activity is even
    // attached), activity.applicationContext isn't safe to call yet — see
    // DownloadEngine's own kdoc. Deferring all three to first real access (always
    // well after onCreate, since nothing reaches them except in response to an
    // actual download/dialog request) makes resolving it then safe, and
    // DownloadEngine's constructor now takes that already-resolved Context
    // directly rather than MainActivity — no Activity reference, live or
    // captured in a closure, passes into DownloadEngine at all. downloadQueue and
    // downloadDialogController must be lazy too purely because each references
    // the one before it — forcing early wouldn't defer anything.
    //
    // downloadIntegrity/downloadHistory/downloadPersistence keep taking `activity`
    // directly (unchanged) — none of them stores it either, each resolves only
    // the application Context / SharedPreferences it actually needs on first real
    // use and holds onto that instead, since downloadEngine and downloadQueue can
    // both outlive whichever Activity was on screen when a download started (see
    // DownloadQueue's generationCounter kdoc) — see DownloadUiCallback for how
    // they still report progress/log lines back to whichever Activity is
    // currently alive.
    private val downloadEngine: DownloadEngine by lazy {
        DownloadEngine(activity.applicationContext, networkReliability) { downloadQueue.persistNow() }
    }
    private val downloadIntegrity = DownloadIntegrity(activity)
    private val downloadHistory   = DownloadHistory(activity)
    // Only ever reached via MainActivity's own DownloadUiCallback.requestApkInstall
    // implementation now (see installApk below) — never captured by a
    // DownloadTask.onSuccess closure, so it's safe for this one field to keep
    // using the Activity directly: it's only ever invoked while this exact
    // DownloadManager's Activity is the one currently registered.
    private val apkInstaller      = ApkInstaller(activity)

    private val downloadQueue: DownloadQueue by lazy { DownloadQueue(downloadEngine, downloadPersistence) }
    private val downloadDialogController: DownloadDialogController by lazy {
        DownloadDialogController(activity, downloadQueue)
    }

    /** Stops accepting new downloads; call from `onDestroy`. Same reasoning as the
     *  Activity's own executor shutdown — this only stops accepting *new* downloads,
     *  it doesn't interrupt ones already running. */
    fun shutdown() = downloadQueue.shutdown()

    /**
     * Reads whatever [DownloadPersistence.loadSnapshot] finds — every
     * non-completed download from the previous process — and rebuilds a live
     * [DownloadTask] for each via the exact same factories [downloadArtifact]
     * and [downloadRunLogs] use, then hands them to
     * [DownloadQueue.restoreTasks]. Call once, from [MainActivity.onCreate]
     * after `etToken` has been populated (a restored artifact/log task's
     * `resolveUrl` needs a token to work with). Safe to call even with an
     * empty or missing persisted queue — a no-op in that case.
     */
    fun restorePersistedDownloads() {
        val saved = downloadPersistence.loadSnapshot()
        if (saved.isEmpty()) return
        val token = activity.etToken.text.toString().trim()
        val rebuilt = saved.mapNotNull { seed ->
            // A restored task that's missing its partial file entirely isn't lost —
            // it just resumes from 0% instead of wherever it left off; the transfer
            // itself is still perfectly restorable via the same resolveUrl. Only skip
            // it here if the destination directory itself is gone (shouldn't normally
            // happen — it's always the app's own cache dir).
            when (val info = seed.restoreInfo) {
                is DownloadRestoreInfo.Artifact -> buildArtifactTask(token, info.downloadUrl, info.zipFileName, seed)
                is DownloadRestoreInfo.Log -> buildLogTask(token, info.owner, info.repo, info.runId, runNum = info.runNum, status = "", seed = seed)
            }
        }
        if (rebuilt.isEmpty()) return
        downloadQueue.restoreTasks(rebuilt)
        val activeCount = rebuilt.count { !it.isTerminal }
        val terminalCount = rebuilt.size - activeCount
        activity.appendLog(
            "↻ Restored ${rebuilt.size} download(s) from before restart" +
                (if (activeCount > 0) " — $activeCount resuming" else "") +
                (if (terminalCount > 0) " ($terminalCount need Retry — see Download Manager)" else "") + "."
        )
    }

    // ── Build-log downloads ─────────────────────────────────────────────────

    /** Downloads the log ZIP for the most recent run on the current branch —
     *  the fast, no-picker path from the Build Log button's quick "Download"
     *  choice. To download a *specific* run's log instead, see [downloadRunLogs]. */
    fun downloadLatestRunLogs() {
        val token  = activity.etToken.text.toString().trim()
        val repo   = activity.etRepo.text.toString().trim()
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }

        activity.setBusy(true)
        activity.setStatus("Fetching latest run…")
        activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        activity.appendLog("📥 Looking up the latest run to download its log…")

        // Only the quick metadata lookup below runs under activity.setBusy — once the
        // DownloadTask is handed to downloadQueue.submit(), the actual transfer runs
        // independently on its own worker pool (see DownloadQueue's kdoc), tracked by
        // the Download Manager rather than the global busy flag, so it no longer
        // blocks starting a build or another download while it's in progress.
        activity.bgExecutor.execute {
            try {
                val owner = activity.lastOwner.ifEmpty {
                    (BuildFlowController.fetchOwner(token) ?: run {
                        activity.setStatus("Failed"); activity.setBusy(false); return@execute
                    }).also { activity.lastOwner = it }
                }

                val (code, body, rateLimit) = GitHubApi.httpGet(token, GitHubApi.apiRunsForBranch(owner, repo, branch, perPage = 1))
                if (code != 200) {
                    activity.appendLog("✗ Could not fetch runs — ${GitHubApi.describeHttpError(code, body, rateLimit)}")
                    activity.setStatus("Failed"); activity.setBusy(false); return@execute
                }
                val runs = JSONObject(body).getJSONArray("workflow_runs")
                if (runs.length() == 0) {
                    activity.appendLog("⚠ No runs found on branch '$branch'")
                    activity.setStatus("No runs"); activity.setBusy(false); return@execute
                }
                val run           = runs.getJSONObject(0)
                val runId         = run.getLong("id")
                val runNum        = run.getLong("run_number")
                val status        = run.optString("status", "")
                val conclusion    = run.optString("conclusion", "")
                val conclusionStr = conclusion.ifEmpty { "in_progress" }
                activity.appendLog("  Run #$runNum  status=$status  conclusion=$conclusionStr")

                enqueueRunLogDownload(token, owner, repo, runId, runNum, status, Formatters.extractZipNameFromRun(run))
                activity.setStatus("Ready ✓")

            } catch (e: Exception) {
                activity.appendLog("✗ Error: ${Formatters.friendlyError(e)}")
                activity.setStatus("Failed")
            } finally {
                activity.setBusy(false)
            }
        }
    }

    /**
     * Downloads the log ZIP for a *specific* run — the counterpart to
     * [downloadLatestRunLogs] that lets the user choose any run instead of
     * always the most recent one, e.g. from
     * [com.zipapkbuilder.feature.buildlog.BuildLogViewer]'s run-picker list
     * (the same list "View Log" already shows). [owner] is passed in rather
     * than re-resolved here since the caller already has it — the run
     * picker only exists after [activity.lastOwner] was populated to build
     * that list in the first place. [projectName], when the caller has it
     * (see [Formatters.extractZipNameFromRun]), names the saved file after
     * whatever ZIP *this specific run* actually used rather than whatever
     * happens to be selected in the main UI right now — important here
     * specifically because this is the path for downloading an *older*
     * run's log, where "currently selected" and "what this run used" have
     * likely diverged.
     */
    fun downloadRunLogs(token: String, owner: String, repo: String, runId: Long, runNum: Long, status: String, projectName: String? = null) {
        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        enqueueRunLogDownload(token, owner, repo, runId, runNum, status, projectName)
    }

    /** Shared submit step behind both [downloadLatestRunLogs] and [downloadRunLogs]. */
    private fun enqueueRunLogDownload(token: String, owner: String, repo: String, runId: Long, runNum: Long, status: String, projectName: String? = null) {
        val task = buildLogTask(token, owner, repo, runId, runNum, status, projectName = projectName)
        if (downloadQueue.hasActiveTask(task.id)) {
            activity.appendLog("ℹ Already downloading the log for run #$runNum — see the Download Manager.")
            showDownloadManagerDialog()
            return
        }
        downloadQueue.submit(task)
        activity.appendLog("↻ Downloading log for run #$runNum — watch the floating icon, or tap 📥 in the header for details.")
    }

    /**
     * Builds a build-log-ZIP [DownloadTask] — the one place that knows how to
     * construct one, used identically by a fresh download
     * ([enqueueRunLogDownload]) and by [restorePersistedDownloads] rebuilding
     * one after a restart (via [seed], which pre-fills progress/status/etag
     * instead of leaving them at fresh-task defaults, and which already has
     * the correct final filename baked in — so [projectName] only matters
     * for a fresh task, never a restored one).
     */
    private fun buildLogTask(
        token: String, owner: String, repo: String, runId: Long, runNum: Long, status: String,
        seed: DownloadPersistence.PersistedDownload? = null,
        projectName: String? = null
    ): DownloadTask {
        val baseName = (projectName ?: activity.selectedZipName.takeIf { it.isNotEmpty() } ?: "logs")
            .removeSuffix(".zip").removeSuffix(".ZIP")
        val fileName = seed?.displayName ?: "${baseName}_run${runNum}_build_log.zip"
        // Deterministic name (keyed by runId) so a retry — automatic,
        // manual, or after restarting the app — resumes the same partial
        // file instead of starting over from 0%.
        val tmpFile = File(activity.cacheDir, "logs_tmp_${runId}.zip")
        // The redirect to the real log ZIP URL is resolved fresh on every
        // attempt inside performResumableDownload rather than just once
        // here — see its doc comment for why a cached redirect isn't safe
        // to reuse across a real pause.
        val logsUrl = GitHubApi.apiRunLogs(owner, repo, runId)

        // Captured as local vals, not referenced as bare downloadIntegrity/downloadHistory
        // below: a bare property reference would desugar to capturing this@DownloadManager
        // (and hence its activity field) in onSuccess's closure — which is stored on the
        // DownloadTask itself and invoked by DownloadQueue's worker pool (see
        // runDownloadTask), possibly long after the Activity that built this task is gone.
        // downloadIntegrity/downloadHistory are themselves Activity-free (see their own
        // kdocs); capturing them directly, rather than through this instance, means the
        // closure never has a path back to `activity` at all.
        val integrity = downloadIntegrity
        val history = downloadHistory
        val task = DownloadTask(
            id = "log_$runId",
            displayName = fileName,
            destFile = tmpFile,
            resolveUrl = {
                val conn0 = (URL(logsUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github+json")
                    instanceFollowRedirects = false
                    connectTimeout = 20_000; readTimeout = 60_000
                }
                conn0.connect()
                val respCode = conn0.responseCode
                when {
                    respCode in 301..308 -> {
                        val loc = conn0.getHeaderField("Location"); conn0.disconnect(); loc ?: logsUrl
                    }
                    respCode == 200 -> { conn0.disconnect(); logsUrl }
                    else -> {
                        conn0.disconnect()
                        throw Exception(
                            when {
                                status == "completed" -> "Logs unavailable for run #$runNum (HTTP $respCode) — GitHub deletes logs after 90 days"
                                status.isNotEmpty()    -> "Logs not ready yet (HTTP $respCode) — run is still in progress, try again shortly"
                                else -> "Logs unavailable for run #$runNum (HTTP $respCode) — the run may still be in progress or its logs may have expired"
                            }
                        )
                    }
                }
            },
            // See buildArtifactTask's onSuccess kdoc comment — same reasoning applies here.
            onSuccess = { t ->
                integrity.requireZipIntegrity(t.destFile, "Build log ZIP")
                val savedPath = history.saveZipToDownloads(t.destFile, fileName)
                t.destFile.delete()
                t.savedPath = savedPath
                DownloadQueue.reportLog("✓ Build log saved to Downloads!")
                DownloadQueue.reportLog("  File : $fileName")
                DownloadQueue.reportLog("  Path : $savedPath")
            },
            restoreInfo = DownloadRestoreInfo.Log(runId = runId, runNum = runNum, owner = owner, repo = repo, zipFileName = fileName),
            createdAtMs = seed?.createdAtMs ?: System.currentTimeMillis()
        )
        seed?.let { applySeed(task, it) }
        return task
    }

    // ── Artifact downloads ──────────────────────────────────────────────────

    /**
     * Starts (or resumes) downloading the given artifact via the Download
     * Manager. Unlike the old single-download flow, this no longer blocks on
     * or sets the global busy flag — the transfer itself runs independently on
     * [DownloadQueue]'s worker pool, tracked as a [DownloadTask] the user can
     * watch, pause, or cancel from [showDownloadManagerDialog] at any time,
     * whether or not this specific call is what started it.
     */
    fun downloadArtifact(downloadUrl: String) {
        val token = activity.etToken.text.toString().trim()
        val rawName = activity.prefs.getString(PrefKeys.PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        val task = buildArtifactTask(token, downloadUrl, zipFileName)

        // Tapping the button twice (or once from here and once from a saved
        // build's restore path) shouldn't spawn a second copy of the same
        // download — just surface the one already running.
        if (downloadQueue.hasActiveTask(task.id)) {
            activity.appendLog("ℹ Already downloading '$zipFileName' — see the Download Manager.")
            showDownloadManagerDialog()
            return
        }

        downloadQueue.submit(task)
        activity.appendLog("📥 Downloading — watch the floating icon, or tap 📥 in the header for details.")
    }

    /**
     * Builds an artifact-ZIP [DownloadTask] — the one place that knows how to
     * construct one, used identically by a fresh download ([downloadArtifact])
     * and by [restorePersistedDownloads] rebuilding one after a restart (via
     * [seed]).
     */
    private fun buildArtifactTask(
        token: String, downloadUrl: String, zipFileName: String,
        seed: DownloadPersistence.PersistedDownload? = null
    ): DownloadTask {
        // Deterministic per-artifact id (not a timestamp) so both the file on disk
        // and the task's identity survive a retry — automatic, manual, or after
        // restarting the app — instead of orphaning progress and starting at 0%.
        val artifactId = downloadQueue.stableIdFor(downloadUrl)
        val taskId = "artifact_$artifactId"
        val artifactZip = File(activity.cacheDir, "artifact_$artifactId.zip")

        // See buildLogTask's matching comment — same reasoning. downloadEngine is also
        // captured locally here since resolveUrl (unlike buildLogTask's, which only
        // touches local values) references it, and resolveUrl is re-invoked on every
        // connection attempt for as long as this task exists.
        val engine = downloadEngine
        val integrity = downloadIntegrity
        val history = downloadHistory
        val task = DownloadTask(
            id = taskId,
            displayName = zipFileName,
            destFile = artifactZip,
            // GitHub's artifact redirect URL expires 1 minute after it's issued
            // (per GitHub's REST API docs), so it's re-resolved fresh on every
            // connection attempt inside performResumableDownload rather than
            // resolved once up front.
            resolveUrl = { engine.resolveGithubRedirect(downloadUrl, token) },
            // Runs on a DownloadQueue worker thread, possibly well after the Activity
            // that started this download is gone (see DownloadQueue's generationCounter
            // kdoc) — engine/integrity/history above are captured as local vals rather
            // than referenced as bare downloadEngine/downloadIntegrity/downloadHistory,
            // specifically so this closure never implicitly captures this@DownloadManager
            // (and hence its activity field). The log lines + install handoff route
            // through DownloadQueue's companion so they reach whichever Activity is
            // currently registered, or safely go nowhere if none is.
            onSuccess = { t ->
                integrity.requireZipIntegrity(t.destFile, "Artifact ZIP")
                val savedPath = history.saveZipToDownloads(t.destFile, zipFileName)
                t.savedPath = savedPath
                DownloadQueue.reportLog("✓ Artifact saved to Downloads!")
                DownloadQueue.reportLog("  File : $zipFileName")
                DownloadQueue.reportLog("  Path : $savedPath")
                DownloadQueue.reportLog("  Open your Downloads app to find it anytime.")
                // One extraction pass feeds both the info log and the install offer below
                // — see extractApkFromZip's kdoc for why this replaced two separate scans.
                val apkFile = integrity.extractApkFromZip(t.destFile)
                if (apkFile != null) {
                    integrity.logApkInfoFromZip(apkFile)
                    DownloadQueue.requestApkInstall(apkFile)
                    // apkFile is deliberately not deleted here — the install intent just
                    // fired above still needs to read it; cleanupStaleCacheFiles() sweeps
                    // its apkinfo_ prefix on its own short staleness threshold instead.
                }
                t.destFile.delete() // the cache copy is no longer needed — it's saved to Downloads now
            },
            restoreInfo = DownloadRestoreInfo.Artifact(downloadUrl = downloadUrl, zipFileName = zipFileName),
            createdAtMs = seed?.createdAtMs ?: System.currentTimeMillis()
        )
        seed?.let { applySeed(task, it) }
        return task
    }

    /** Pre-fills a freshly-built [DownloadTask] with a [DownloadPersistence.PersistedDownload]'s
     *  progress/status instead of leaving it at fresh-task defaults — used only by
     *  [restorePersistedDownloads] rebuilding a task from before a restart. */
    private fun applySeed(task: DownloadTask, seed: DownloadPersistence.PersistedDownload) {
        task.downloadedBytes = seed.downloadedBytes
        task.totalBytes = seed.totalBytes
        task.status = seed.status
        task.errorMessage = seed.errorMessage
        task.etag = seed.etag
        task.lastModified = seed.lastModified
        task.retryCount = seed.retryCount
        task.lastProgressAtMs = seed.lastProgressAtMs
        task.pauseRequested = seed.pauseRequested
        task.detailText = when (seed.status) {
            DownloadTask.Status.FAILED    -> "Failed"
            DownloadTask.Status.CANCELLED -> "Cancelled"
            else -> "Restored — queued…"
        }
    }

    fun showDownloadManagerDialog() = downloadDialogController.showDownloadManagerDialog()

    /** [com.zipapkbuilder.MainActivity]'s [DownloadUiCallback.requestApkInstall]
     *  implementation delegates here — always using *this* Activity's own,
     *  currently-live [apkInstaller], since this is only ever reached while
     *  this DownloadManager's Activity is the one currently registered (see
     *  [DownloadQueue.requestApkInstall]). */
    fun installApk(apkFile: File) = apkInstaller.requestInstall(apkFile)

    fun loadDownloadHistory(): List<JSONObject> = downloadHistory.loadDownloadHistory()

    /**
     * Sweeps abandoned temp files left behind by a previous session. Called
     * once at cold start, from a background thread, *after*
     * [restorePersistedDownloads] has already resubmitted whatever it found
     * — critical ordering, not incidental: every file backing a currently
     * tracked [DownloadTask] (active or terminal-but-retryable) is excluded
     * from this sweep via [downloadQueue]'s live snapshot regardless of its
     * age, specifically so a long-paused download that's older than
     * [STALE_PARTIAL_DOWNLOAD_MS] can never have its partial bytes deleted
     * out from under a restored task — that combination (a legitimately old
     * partial file *and* a live task pointing at it) could only arise once
     * downloads survived a restart at all, so it's not a pre-existing
     * concern this sweep had to handle before [DownloadPersistence] existed.
     */
    fun cleanupStaleCacheFiles() {
        // viewlog_ (BuildLogViewer's per-viewing raw-log cache) is deleted the moment
        // its dialog closes via any path (Copy All / Tail Console / Close / back button)
        // — this short-lived bucket only catches the rare leftover from a process kill
        // while that dialog happened to be open. build_log_ (MainActivity.saveLogToFile's
        // per-share text file) has no such explicit delete anywhere — the share target
        // has long since read it by the time this threshold passes, so it only ever
        // needs sweeping here.
        val shortLived  = setOf("apkinfo_", "viewlog_", "build_log_")
        val longLived   = setOf("artifact_", "logs_tmp_")
        val protectedPaths = downloadQueue.snapshot().map { it.destFile.absolutePath }.toSet()
        val now = System.currentTimeMillis()
        val staleShortBefore = now - 2 * 60_000L
        val stalePartialBefore = now - STALE_PARTIAL_DOWNLOAD_MS
        try {
            var freedBytes = 0L
            var deletedCount = 0
            activity.cacheDir.listFiles()?.forEach { f ->
                if (f.absolutePath in protectedPaths) return@forEach
                val threshold = when {
                    shortLived.any { f.name.startsWith(it) } -> staleShortBefore
                    longLived.any  { f.name.startsWith(it) } -> stalePartialBefore
                    else -> return@forEach
                }
                if (f.lastModified() < threshold) {
                    val len = f.length()
                    if (f.delete()) { deletedCount++; freedBytes += len }
                }
            }
            if (deletedCount > 0) {
                activity.appendLog("🧹 Cleaned up $deletedCount leftover temp file(s) (${Formatters.fmtBytes(freedBytes)}) from a previous session.")
            }
        } catch (_: Exception) {
            // Cache cleanup is a hygiene nice-to-have — never worth surfacing an error for.
        }
    }
}
