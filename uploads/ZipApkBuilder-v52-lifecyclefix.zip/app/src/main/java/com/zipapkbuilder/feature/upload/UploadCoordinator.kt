package com.zipapkbuilder.feature.upload

import android.content.Context
import android.net.Uri
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONArray
import org.json.JSONObject

/**
 * Independent cancellation flag for exactly one logical upload operation — a
 * single upload, or a whole multi-file batch that's meant to stop together
 * (see [com.zipapkbuilder.MainActivity.pickUploadFile]). Replaces the old
 * design where every upload anywhere in the app — a build-flow upload, a
 * File Manager upload, each file in a multi-select batch — polled one
 * `UploadCoordinator`-instance-wide `uploadCancelled` field, which meant
 * cancelling any one of them silently cancelled every other upload that
 * happened to be in flight at the same moment too. Each [UploadCoordinator.UploadProgressHandle]
 * owns one of these (see its kdoc for how a batch shares a single token
 * across several files on purpose, while staying isolated from every other
 * operation).
 */
class UploadCancellationToken {
    @Volatile var cancelled = false
}

/**
 * Lifecycle-safe UI-feedback surface for the floating upload bubble, its
 * cancel-confirmation dialog, and its status/log lines — implemented by
 * [com.zipapkbuilder.MainActivity] and registered/unregistered via
 * [UploadCoordinator.Companion.registerUiCallback]/[unregisterUiCallback],
 * the same pattern as [com.zipapkbuilder.feature.build.BuildUiCallback] and
 * [com.zipapkbuilder.feature.download.DownloadUiCallback]. An upload started
 * under a since-destroyed Activity reports through whichever Activity is
 * currently registered instead of touching torn-down views — this matters
 * here specifically because an upload can be large enough to still be
 * running if a config change recreates the Activity mid-transfer.
 *
 * [appendLog]/[setStatus] intentionally match [com.zipapkbuilder.feature.build.BuildUiCallback]'s
 * signatures exactly: [com.zipapkbuilder.MainActivity]'s existing
 * implementations of those two already satisfy this interface too, so no new
 * code is needed for them specifically.
 */
interface UploadUiCallback {
    fun appendLog(line: String)
    fun setStatus(text: String)
    /** Shows the floating upload bubble. [onCancelRequested] is invoked if the
     *  user taps the bubble and confirms the resulting "Cancel upload?"
     *  prompt — implementations own that confirmation dialog themselves
     *  (it needs a live Activity to show against), and only call back here
     *  once the user has actually confirmed. */
    fun showUploadProgress(fileName: String, totalBytes: Long, onCancelRequested: () -> Unit)
    fun updateUploadProgress(pct: Int)
    /** Call once the upload attempt is fully done (success, failure, or
     *  cancellation) so the bubble reflects the outcome and fades itself out. */
    fun finishUpload(success: Boolean)
}

/**
 * Drives a single reliable, progress-tracked upload to GitHub: the upload
 * progress dialog, retry-with-backoff policy, and the large-file Git Data API
 * path (blob → tree → commit → ref update) that [com.zipapkbuilder.feature.build.BuildFlowController]
 * uses for anything too big for a single Contents API PUT.
 *
 * Holds no [com.zipapkbuilder.MainActivity] reference of any kind: [context]
 * is resolved to [Context.getApplicationContext] immediately (only ever used
 * for [Context.getContentResolver] — a plain, Activity-free reference, safe
 * to hold for this class's entire lifetime), and every UI update reports
 * through [UploadUiCallback] instead. Used both by the build flow's own
 * upload (called from [com.zipapkbuilder.feature.build.BuildUploadCoordinator],
 * synchronously inside a build that can run long enough for an Activity
 * recreation to land mid-upload) and by
 * [com.zipapkbuilder.feature.filemanager.FileUploadController]'s File
 * Manager upload — either way, the same lifecycle safety applies.
 *
 * Constructed as one of [com.zipapkbuilder.MainActivity]'s own field
 * initializers, before the Activity is attached — same constraint as
 * [com.zipapkbuilder.feature.download.DownloadEngine], and the same fix:
 * [MainActivity] resolves this lazily (`by lazy { UploadCoordinator(applicationContext, ...) }`)
 * so `applicationContext` above is only ever evaluated on first real access,
 * well after `onCreate`.
 */
class UploadCoordinator(
    context: Context,
    private val networkReliability: NetworkReliability
) {
    private val appContext: Context = context.applicationContext

    companion object {
        @Volatile private var uiCallback: UploadUiCallback? = null

        /** Call once views are ready to receive updates (`onCreate`). */
        fun registerUiCallback(callback: UploadUiCallback) {
            uiCallback = callback
        }

        /** Call from `onDestroy`. A no-op unless [callback] is still the
         *  currently-registered one, so a new Activity's registration
         *  (already done by the time this fires, on a config-change
         *  recreation) is never clobbered. */
        fun unregisterUiCallback(callback: UploadUiCallback) {
            if (uiCallback === callback) uiCallback = null
        }

        /** Routes a log line to whichever Activity is currently registered,
         *  or does nothing if none is. */
        internal fun reportLog(line: String) {
            uiCallback?.appendLog(line)
        }

        /** Routes a status-line update the same way. */
        internal fun reportStatus(text: String) {
            uiCallback?.setStatus(text)
        }
    }

    /**
     * Tracks one upload's progress via the floating bubble instead of the
     * old screen-covering, non-cancelable "Uploading" AlertDialog — the
     * whole point of the floating bubble is that it never forces itself in
     * front of the app, so uploading no longer blocks the user from doing
     * anything else while it runs.
     *
     * Cancellation moves from an always-visible "✕ Cancel" button (which the
     * old modal needed since it blocked everything else) to a confirmation
     * prompt shown only when the user deliberately taps the bubble — the
     * upload keeps running silently in the background otherwise.
     */
    inner class UploadProgressHandle(
        fileName: String,
        totalBytes: Long,
        /** Defaults to a fresh, independent token when the caller doesn't need to
         *  share one across several calls — see [UploadCancellationToken]'s kdoc
         *  and [com.zipapkbuilder.MainActivity.pickUploadFile] for the one case
         *  (a multi-file batch) that deliberately passes an existing one in. */
        val token: UploadCancellationToken = UploadCancellationToken()
    ) {
        /** True once this specific upload's own token has been cancelled — see
         *  [UploadCancellationToken]. No longer shared with any other upload. */
        val cancelled: Boolean get() = token.cancelled

        private var lastSpeedTime  = System.currentTimeMillis()
        private var lastSpeedBytes = 0L

        init {
            // token is a plain, Activity-free object — this lambda captures only
            // it, never `activity`, so MainActivity holding onto it while the
            // bubble is showing creates no reference back to any Activity state.
            uiCallback?.showUploadProgress(fileName, totalBytes) {
                token.cancelled = true
                reportLog("⚠ Cancelling upload…")
            }
            uiCallback?.updateUploadProgress(if (totalBytes > 0) 0 else -1)
        }

        /** Reports transfer progress; safe to call from a background thread. */
        val onProgress: (written: Long, total: Long) -> Unit = { written, total ->
            val now     = System.currentTimeMillis()
            val elapsed = now - lastSpeedTime
            if (elapsed >= 200) {
                val speedBps = (written - lastSpeedBytes) * 1000L / elapsed.coerceAtLeast(1)
                lastSpeedTime  = now; lastSpeedBytes = written
                val pct    = if (total > 0) (written * 100L / total).toInt() else -1
                val pctStr = if (total > 0) "${"%.0f".format(written * 100.0 / total)}%" else "…"
                uiCallback?.updateUploadProgress(pct)
                reportStatus("Uploading… $pctStr (${Formatters.fmtBytes(speedBps)}/s)")
            }
        }

        /** Surfaces a status line (retry/backoff/offline messages) without a popup. */
        fun setStatus(text: String) {
            reportStatus(text)
        }

        fun finish(success: Boolean) {
            uiCallback?.finishUpload(success)
        }
    }

    /** Starts tracking one upload's progress via the floating bubble. Safe to
     *  call from a background thread. Pass [token] to share cancellation state
     *  across several calls that should stop together (a multi-file batch);
     *  omit it for a standalone upload, which gets its own independent token. */
    fun beginUpload(fileName: String, totalBytes: Long, token: UploadCancellationToken = UploadCancellationToken()): UploadProgressHandle =
        UploadProgressHandle(fileName, totalBytes, token)

    /**
     * Applies the same network-reliability policy downloads get from the
     * download engine to a single upload attempt — without byte-level
     * resume, since none of GitHub's upload endpoints (Contents API PUT, or
     * the blob/tree/commit sequence in [uploadViaGitDataApi]) support
     * resuming a partial request the way a download's Range header does.
     * Instead, a failed attempt is retried *from scratch*, which is safe here
     * because every step involved is naturally idempotent or cheap to redo:
     * Git blobs and trees are content-addressed (recreating one with the same
     * bytes just returns the same SHA, at negligible cost), and a retried
     * commit/ref-update simply produces one small additional commit rather
     * than corrupting anything.
     *
     * - A dropped connection while genuinely offline pauses (shown via
     *   [UploadProgressHandle.setStatus]) and resumes automatically the instant
     *   connectivity returns — this never counts against [maxRetries].
     * - A transient HTTP failure (429/500/502/503/504, recognized via
     *   [NetworkReliability.retryableHttpCodeIn] since these arrive as thrown
     *   messages, not return codes) or an I/O error while the network still
     *   tests as reachable retries with exponential backoff, up to
     *   [maxRetries] times.
     * - Anything else (auth failure, payload too large, cancellation) is
     *   fatal immediately.
     *
     * Must be called from a background thread.
     */
    fun <T> withUploadRetry(
        dlUi: UploadProgressHandle,
        maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES,
        attempt: () -> T
    ): T {
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        while (true) {
            if (dlUi.cancelled) throw Exception("Cancelled by user")
            try {
                return attempt()
            } catch (e: Exception) {
                if (e.message == "Cancelled by user" || dlUi.cancelled) throw e

                val retryableCode = networkReliability.retryableHttpCodeIn(e.message)
                val isIoIssue = e is java.io.IOException

                if (isIoIssue && !networkReliability.isNetworkAvailable()) {
                    dlUi.setStatus("⚠ Paused (No Internet) — will resume automatically")
                    val reconnected = networkReliability.waitForNetwork { dlUi.cancelled }
                    if (!reconnected) throw Exception("Cancelled by user")
                    reportLog("↻ Back online — retrying upload…")
                    continue
                }

                if (isIoIssue || retryableCode != null) {
                    retryAttempt++
                    if (retryAttempt > maxRetries) {
                        throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                    }
                    dlUi.setStatus("Retrying in ${backoffMs / 1000}s… (attempt $retryAttempt/$maxRetries)")
                    networkReliability.sleepCancellable(backoffMs) { dlUi.cancelled }
                    backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                    continue
                }

                throw e // not network/transient-server-related — fatal
            }
        }
    }

    /**
     * Uploads [sourceUri]'s content to [filePath] using the Git Data API.
     * This path bypasses the Contents API's 50 MB file limit and supports up
     * to ~99 MB raw.
     *
     * The file is streamed straight from [sourceUri] and base64-encoded on
     * the fly (see [GitHubApi.uploadStreamingBase64]) rather than being read
     * into a byte array and re-encoded into a full base64 string first — the
     * old approach held the raw bytes, the base64 string, and the JSON body
     * as separate full-size copies at once. A fresh stream is opened here on
     * every call, since a retried attempt (see [withUploadRetry], which redoes
     * a failed attempt from scratch) can't resume a partially-consumed one.
     *
     * Steps: create blob → get branch tip → get base tree →
     *        create tree → create commit → advance ref.
     *
     * Returns the blob SHA (stored as lastFileSha for later ops) and the new
     * commit's SHA — the latter lets a caller match the exact workflow run
     * this push triggers via GitHub's `head_sha` run filter instead of a
     * timestamp heuristic (see [com.zipapkbuilder.feature.build.BuildRunMonitor.waitForRun]).
     */
    data class GitDataUploadResult(val blobSha: String, val commitSha: String)

    fun uploadViaGitDataApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, sourceUri: Uri, rawLength: Long, displayName: String,
        /** Defaults to the build-flow's own message when null — callers outside the
         *  build flow (e.g. [com.zipapkbuilder.feature.filemanager.FileUploadController]
         *  for a large File Manager upload) pass their own so it reads correctly and,
         *  importantly, so they can include `[skip ci]` where the build flow's default
         *  deliberately does not — a build-flow upload is *meant* to trigger the
         *  workflow, so it must never accidentally carry `[skip ci]`. */
        commitMessage: String? = null,
        cancellationToken: UploadCancellationToken,
        onProgress: (Long, Long) -> Unit
    ): GitDataUploadResult {
        // 1. Create blob (largest network call — drives the progress bar)
        reportLog("  Uploading blob…")
        val (blobCode, blobResp) = GitHubApi.uploadStreamingBase64(
            token, GitHubApi.apiBlobs(owner, repo), "POST",
            jsonPrefix = "{\"content\":\"",
            source = UriUtils.openInputStreamOrThrow(appContext.contentResolver, sourceUri),
            rawLength = rawLength,
            jsonSuffix = "\",\"encoding\":\"base64\"}",
            isCancelled = { cancellationToken.cancelled }, onProgress = onProgress
        )
        if (blobCode !in 200..201)
            throw Exception("Blob upload failed ($blobCode): ${blobResp.take(300)}")
        val blobSha = JSONObject(blobResp).getString("sha")
        reportLog("  Blob created ✓ (${blobSha.take(12)}…)")

        // 2. Get the current branch tip commit SHA
        val (refCode, refBody) = GitHubApi.httpGet(token, GitHubApi.apiRefHeads(owner, repo, branch))
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        // 3. Get base tree SHA from tip commit
        val (commitCode, commitBody) = GitHubApi.httpGet(token, GitHubApi.apiCommit(owner, repo, tipSha))
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        val baseSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

        // 4. Create a new tree with the file
        reportLog("  Creating tree…")
        val treeBody = JSONObject().apply {
            put("base_tree", baseSha)
            put("tree", JSONArray().put(JSONObject().apply {
                put("path", filePath)
                put("mode", "100644")
                put("type", "blob")
                put("sha",  blobSha)
            }))
        }.toString()
        val (treeCode, treeResp) = GitHubApi.httpPost(token, GitHubApi.apiTrees(owner, repo), treeBody)
        if (treeCode !in 200..201)
            throw Exception("Tree creation failed ($treeCode): ${treeResp.take(300)}")
        val newTreeSha = JSONObject(treeResp).getString("sha")

        // 5. Create new commit
        reportLog("  Committing…")
        val newCommitBody = JSONObject().apply {
            put("message", commitMessage ?: "ci: upload $displayName [run ${System.currentTimeMillis()}]")
            put("tree",    newTreeSha)
            put("parents", JSONArray().put(tipSha))
        }.toString()
        val (newCommitCode, newCommitResp) = GitHubApi.httpPost(token, GitHubApi.apiCommits(owner, repo), newCommitBody)
        if (newCommitCode !in 200..201)
            throw Exception("Commit failed ($newCommitCode): ${newCommitResp.take(300)}")
        val newCommitSha = JSONObject(newCommitResp).getString("sha")

        // 6. Advance branch ref
        reportLog("  Advancing branch ref…")
        val refPatchBody = JSONObject().apply {
            put("sha",   newCommitSha)
            put("force", false)
        }.toString()
        val (patchCode, patchResp) = GitHubApi.httpPatch(token, GitHubApi.apiRefsHeads(owner, repo, branch), refPatchBody)
        if (patchCode !in 200..201)
            throw Exception("Ref update failed ($patchCode): ${patchResp.take(300)}")

        return GitDataUploadResult(blobSha, newCommitSha)
    }

    /**
     * PUTs [sourceUri]'s content to [filePath] via the Contents API — the
     * path [com.zipapkbuilder.feature.build.BuildFlowController] uses for
     * ZIPs small enough to skip the Git Data API — streaming the base64
     * encoding straight into the request body via
     * [GitHubApi.uploadStreamingBase64] instead of building the whole JSON
     * payload as one String first. [com.zipapkbuilder.feature.filemanager.FileManagerController]'s
     * own file-upload feature shares the same envelope via
     * [GitHubApi.contentsApiEnvelope] rather than duplicating this JSON
     * construction. A fresh stream is opened on every call so a retried
     * attempt always starts from the beginning of the file.
     */
    fun uploadFileViaContentsApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, message: String, sourceUri: Uri, rawLength: Long,
        existingSha: String?, cancellationToken: UploadCancellationToken, onProgress: (Long, Long) -> Unit
    ): Pair<Int, String> {
        val (prefix, suffix) = GitHubApi.contentsApiEnvelope(message, branch, existingSha)
        return GitHubApi.uploadStreamingBase64(
            token, GitHubApi.apiContents(owner, repo, filePath), "PUT",
            jsonPrefix = prefix,
            source = UriUtils.openInputStreamOrThrow(appContext.contentResolver, sourceUri),
            rawLength = rawLength,
            jsonSuffix = suffix,
            isCancelled = { cancellationToken.cancelled }, onProgress = onProgress
        )
    }
}
