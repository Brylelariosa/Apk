package com.zipapkbuilder.feature.download

import android.content.SharedPreferences
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.model.DownloadRestoreInfo
import com.zipapkbuilder.model.DownloadTask
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists every non-completed [DownloadTask] to SharedPreferences as a small
 * JSON array, and restores it back on the next app start. This is what makes
 * an active, paused, queued, retrying, or even failed/cancelled download
 * survive a process kill, an app restart, or a swipe from Recent Apps —
 * before this existed, only a fully COMPLETED download left any trace once
 * the in-memory [DownloadQueue] that tracked it was gone.
 *
 * Only the *data* half of a task is persisted here — [DownloadTask.resolveUrl]
 * and [DownloadTask.onSuccess] are behavior (closures) and can't be
 * serialized; [DownloadTask.restoreInfo] is the data "recipe"
 * ([DownloadRestoreInfo]) [DownloadManager] uses to rebuild an equivalent
 * task from a [PersistedDownload] via the exact same factory function a
 * brand-new download of that kind would use — see [DownloadRestoreInfo]'s
 * own kdoc for why that matters.
 *
 * Writes are cheap, small SharedPreferences commits (`apply()`, itself
 * async) — [DownloadQueue] calls [saveSnapshot] at every real status
 * transition plus a throttled cadence while actively transferring (see
 * [DownloadEngine]'s progress loop), not on every single byte, so this never
 * becomes a meaningful source of I/O pressure even with several concurrent
 * downloads.
 */
class DownloadPersistence(activity: MainActivity) {

    /**
     * Resolved lazily and captured *only* by this initializer, not stored
     * as a field. Deferring until first real use (this class's first real
     * [saveSnapshot]/[loadSnapshot]/[clear] call, well after `onCreate`)
     * rather than at construction matters here for a subtler reason than
     * usual: MainActivity's own field initializers run before the Activity
     * is attached, when even `getSharedPreferences` isn't safe to call yet,
     * so resolving this up front would crash. Once first accessed,
     * [activity] is released for garbage collection either way — this
     * class never durably retains an Activity reference, which matters
     * since [DownloadQueue] (which holds this) can outlive whichever
     * Activity was on screen when a download started.
     */
    private val prefs: SharedPreferences by lazy { activity.prefs }


    companion object {
        /** Defensive cap on how many tasks get persisted at once — normal usage
         *  is a small handful; this just bounds worst-case growth. */
        private const val MAX_PERSISTED = 20
    }

    /** One task's persisted snapshot — everything needed to show it in the
     *  manager immediately, and (via [restoreInfo]) to rebuild a fully
     *  working [DownloadTask] through [DownloadManager]'s factories. */
    data class PersistedDownload(
        val id: String,
        val displayName: String,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val status: DownloadTask.Status,
        val errorMessage: String?,
        val etag: String?,
        val lastModified: String?,
        val retryCount: Int,
        val createdAtMs: Long,
        val lastProgressAtMs: Long,
        val pauseRequested: Boolean,
        val restoreInfo: DownloadRestoreInfo
    )

    /**
     * Writes every non-COMPLETED, restorable (i.e. [DownloadTask.restoreInfo]
     * non-null) task in [tasks] to SharedPreferences as one JSON array,
     * replacing whatever was there before. COMPLETED tasks are intentionally
     * excluded — they're already durably recorded via [DownloadHistory] and
     * the saved file itself, so persisting them here too would only mean
     * restoring a "Remove"-only row nobody needs. A task with no
     * [DownloadTask.restoreInfo] (shouldn't normally happen — every task
     * [DownloadManager] creates sets one) is skipped rather than persisted
     * un-restorably, since a task this code can't rebuild on restart is
     * worse than not showing it at all.
     */
    fun saveSnapshot(tasks: List<DownloadTask>) {
        val arr = JSONArray()
        tasks.asSequence()
            .filter { it.status != DownloadTask.Status.COMPLETED && it.restoreInfo != null }
            .take(MAX_PERSISTED)
            .forEach { task -> arr.put(toJson(task)) }
        try {
            prefs.edit().putString(PrefKeys.PREF_DOWNLOAD_QUEUE, arr.toString()).apply()
        } catch (_: Exception) {
            // Persistence is a reliability nice-to-have layered on top of the download
            // itself, which must keep running with or without it — never worth crashing
            // or interrupting a transfer over a failed SharedPreferences write.
        }
    }

    /** Reads back whatever [saveSnapshot] last wrote. Never throws — a corrupt
     *  or unrecognized entry is simply skipped rather than failing the whole load. */
    fun loadSnapshot(): List<PersistedDownload> {
        val raw = prefs.getString(PrefKeys.PREF_DOWNLOAD_QUEUE, null) ?: return emptyList()
        val arr = try { JSONArray(raw) } catch (_: Exception) { return emptyList() }
        val result = mutableListOf<PersistedDownload>()
        for (i in 0 until arr.length()) {
            try {
                fromJson(arr.getJSONObject(i))?.let { result.add(it) }
            } catch (_: Exception) {
                // One corrupt entry shouldn't take the rest of the queue down with it.
            }
        }
        return result
    }

    /** Clears the persisted queue entirely — called once every restorable task
     *  from [loadSnapshot] has been either re-submitted or dropped, so a stale
     *  entry (e.g. one whose partial file is long gone) can't resurrect itself
     *  on a later restart. The live queue re-populates this on its own via
     *  [saveSnapshot] as soon as anything meaningful happens next. */
    fun clear() {
        prefs.edit().remove(PrefKeys.PREF_DOWNLOAD_QUEUE).apply()
    }

    // ── (de)serialization ────────────────────────────────────────────────────

    private fun toJson(task: DownloadTask): JSONObject = JSONObject().apply {
        put("id", task.id)
        put("displayName", task.displayName)
        put("downloadedBytes", task.downloadedBytes)
        put("totalBytes", task.totalBytes)
        put("status", task.status.name)
        putOrNull("errorMessage", task.errorMessage)
        putOrNull("etag", task.etag)
        putOrNull("lastModified", task.lastModified)
        put("retryCount", task.retryCount)
        put("createdAtMs", task.createdAtMs)
        put("lastProgressAtMs", task.lastProgressAtMs)
        put("pauseRequested", task.pauseRequested)
        task.restoreInfo?.let { put("restoreInfo", restoreInfoToJson(it)) }
    }

    private fun JSONObject.putOrNull(key: String, value: String?) {
        put(key, value ?: JSONObject.NULL)
    }

    private fun optNullableString(obj: JSONObject, key: String): String? =
        if (!obj.has(key) || obj.isNull(key)) null else obj.optString(key)

    private fun restoreInfoToJson(info: DownloadRestoreInfo): JSONObject = when (info) {
        is DownloadRestoreInfo.Artifact -> JSONObject().apply {
            put("kind", "artifact")
            put("downloadUrl", info.downloadUrl)
            put("zipFileName", info.zipFileName)
        }
        is DownloadRestoreInfo.Log -> JSONObject().apply {
            put("kind", "log")
            put("runId", info.runId)
            put("runNum", info.runNum)
            put("owner", info.owner)
            put("repo", info.repo)
            put("zipFileName", info.zipFileName)
        }
    }

    private fun fromJson(obj: JSONObject): PersistedDownload? {
        val restoreObj = obj.optJSONObject("restoreInfo") ?: return null
        val restoreInfo: DownloadRestoreInfo = when (restoreObj.optString("kind")) {
            "artifact" -> DownloadRestoreInfo.Artifact(
                downloadUrl = restoreObj.getString("downloadUrl"),
                zipFileName = restoreObj.getString("zipFileName")
            )
            "log" -> DownloadRestoreInfo.Log(
                runId = restoreObj.getLong("runId"),
                runNum = if (restoreObj.has("runNum")) restoreObj.getLong("runNum") else restoreObj.getLong("runId"),
                owner = restoreObj.getString("owner"),
                repo = restoreObj.getString("repo"),
                zipFileName = restoreObj.getString("zipFileName")
            )
            else -> return null
        }
        val status = try {
            DownloadTask.Status.valueOf(obj.getString("status"))
        } catch (_: Exception) {
            DownloadTask.Status.QUEUED
        }
        return PersistedDownload(
            id = obj.getString("id"),
            displayName = obj.getString("displayName"),
            downloadedBytes = obj.optLong("downloadedBytes", 0L),
            totalBytes = obj.optLong("totalBytes", -1L),
            status = status,
            errorMessage = optNullableString(obj, "errorMessage"),
            etag = optNullableString(obj, "etag"),
            lastModified = optNullableString(obj, "lastModified"),
            retryCount = obj.optInt("retryCount", 0),
            createdAtMs = obj.optLong("createdAtMs", System.currentTimeMillis()),
            lastProgressAtMs = obj.optLong("lastProgressAtMs", System.currentTimeMillis()),
            pauseRequested = obj.optBoolean("pauseRequested", false),
            restoreInfo = restoreInfo
        )
    }
}
