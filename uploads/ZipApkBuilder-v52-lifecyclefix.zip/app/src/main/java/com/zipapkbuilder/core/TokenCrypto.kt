package com.zipapkbuilder.core

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts the GitHub Personal Access Token before it's written to
 * SharedPreferences, instead of storing it as plain text on disk.
 *
 * Uses an AES-256/GCM key that lives only inside the Android Keystore
 * (hardware-backed where the device supports it) — the raw key material
 * never leaves the secure element, and never enters the app's process.
 */
internal object TokenCrypto {
    private const val KEYSTORE_ALIAS  = "zipapk_pat_key"
    private const val TRANSFORMATION  = "AES/GCM/NoPadding"
    private const val GCM_TAG_LEN_BITS = 128
    private const val GCM_IV_LEN_BYTES = 12
    private const val MAGIC = "ENC1:" // marks values written by this encryptor

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        keyGen.init(
            KeyGenParameterSpec.Builder(
                KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return keyGen.generateKey()
    }

    /** True if [value] is already in this class's own encrypted format — i.e.
     *  it's safe to hand straight to [decrypt] rather than needing [encrypt]
     *  first. Exists so a caller (the legacy-token migration in
     *  [com.zipapkbuilder.MainActivity.migrateLegacyTokenIfNeeded]) can tell an
     *  already-encrypted value apart from a plaintext one without duplicating
     *  the [MAGIC]-prefix check itself. */
    fun isEncrypted(value: String): Boolean = value.startsWith(MAGIC)

    /**
     * Encrypts [plain] into a value that's safe to persist in SharedPreferences.
     *
     * Returns `null` — never [plain] itself — if encryption fails for any
     * reason (e.g. the AndroidKeystore is unavailable). This fails *closed*:
     * every caller must treat `null` as "do not save anything" and must never
     * fall back to writing [plain] unencrypted. (An earlier version of this
     * method caught the exception and returned `plain` instead, which meant a
     * transient Keystore failure could silently write the raw token to disk.)
     */
    fun encrypt(plain: String): String? {
        if (plain.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            }
            val combined = cipher.iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            MAGIC + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            null // fail CLOSED — never return the plaintext token as a fallback
        }
    }

    /**
     * Decrypts a value previously produced by [encrypt].
     *
     * Returns:
     * - `""` if [stored] itself is empty — nothing is saved; not a failure.
     * - [stored] unchanged if it doesn't carry the [MAGIC] prefix — a legacy
     *   plaintext value saved before encryption was added, returned as-is so
     *   existing users aren't logged out; it gets re-saved in encrypted form
     *   the next time the token is written.
     * - the decrypted plaintext on success.
     * - `null` if [stored] is non-empty, [MAGIC]-prefixed ciphertext that could
     *   NOT be decrypted (the Keystore key is gone/invalidated, or the data is
     *   corrupted). This is the one case a caller must treat as "the saved
     *   token can't be read right now" — never silently as an absent token,
     *   and never by treating the raw [stored] value as if it were usable.
     */
    fun decrypt(stored: String): String? {
        if (stored.isEmpty()) return ""
        if (!isEncrypted(stored)) return stored // legacy plaintext value
        return try {
            val combined   = Base64.decode(stored.removePrefix(MAGIC), Base64.NO_WRAP)
            val iv         = combined.copyOfRange(0, GCM_IV_LEN_BYTES)
            val cipherText = combined.copyOfRange(GCM_IV_LEN_BYTES, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_LEN_BITS, iv))
            }
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (e: Exception) {
            null // key invalidated or data corrupted — caller must NOT treat this as "no token"
        }
    }
}
