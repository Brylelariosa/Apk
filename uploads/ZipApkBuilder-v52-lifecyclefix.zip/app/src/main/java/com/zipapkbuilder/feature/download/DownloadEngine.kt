package com.zipapkbuilder.feature.download

import android.content.Context
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.model.DownloadTask
import com.zipapkbuilder.net.NetworkReliability
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * The actual byte-transfer mechanics: resumable HTTP GET with Range support,
 * pause/cancel polling, exponential-backoff retry, and offline wait-and-resume.
 * Split out of [DownloadManager] as the one piece that's pure network I/O —
 * no dialog, no queueing. [DownloadQueue] calls [performResumableDownload]
 * once per task on one of its worker threads; progress/status/speed are
 * reported back through [DownloadTask]'s own fields rather than a callback,
 * so multiple downloads can run through this at once without fighting over
 * shared state — [onCheckpoint] is the one exception, a much coarser signal
 * ("something worth persisting just changed") than per-field reporting would
 * be, used only to trigger [DownloadPersistence] snapshots.
 */
class DownloadEngine(
    context: Context,
    private val networkReliability: NetworkReliability,
    /** Invoked whenever [DownloadTask] state changes meaningfully enough to be
     *  worth persisting (status transitions, a throttled progress tick while
     *  actively transferring) — wired by [DownloadManager] to
     *  [DownloadPersistence.saveSnapshot] via [DownloadQueue]. Defaults to a
     *  no-op so this class stays independently testable/usable without a
     *  persistence layer wired up. */
    private val onCheckpoint: (DownloadTask) -> Unit = {}
) {
    /**
     * Only ever used for [Context.getCacheDir]. This class never sees
     * `MainActivity` at all — [DownloadManager] resolves [context] to an
     * application Context ([android.content.Context.getApplicationContext])
     * before constructing this, at a point where doing so is safe (see
     * `DownloadManager.downloadEngine`'s own kdoc), and hands it in already
     * resolved. No Activity reference of any kind — live or captured in a
     * closure — passes through this constructor.
     */
    private val appContext: Context = context.applicationContext

    /**
     * Resolves a GitHub API URL that responds with a redirect (301-308) to its
     * real, time-limited download location, following exactly one hop. Called
     * fresh before every connection attempt by [performResumableDownload]
     * rather than cached, since GitHub's own artifact redirect URL expires
     * after 1 minute — reusing an old one after a long pause or a backoff
     * wait would fail with an auth error even though the artifact is fine.
     */
    fun resolveGithubRedirect(apiUrl: String, token: String): String {
        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            instanceFollowRedirects = false
            connectTimeout = 30_000; readTimeout = 30_000
        }
        conn.connect()
        return if (conn.responseCode in 301..308) {
            val loc = conn.getHeaderField("Location")
            conn.disconnect()
            loc ?: apiUrl
        } else {
            conn.disconnect()
            apiUrl
        }
    }

    /**
     * Downloads from whatever URL [task]'s `resolveUrl` returns into
     * [task].destFile, resuming from any bytes already on disk via an HTTP Range
     * request when the server honors it. Reports all progress and status purely
     * through [task]'s own fields — this function never touches a View or an
     * Activity at all — so it behaves identically whether or not the Download
     * Manager is currently on screen to show it, and so multiple instances of
     * this function (one per worker) can run at once without fighting over
     * shared state the way the single-download version did.
     *
     * `resolveUrl` is called again before every connection attempt — not just
     * once — because the GitHub endpoints this feeds from redirect to a
     * short-lived signed URL, so a stale cached URL would fail after any real
     * pause.
     *
     * - [task].pauseRequested / [task].cancelRequested are checked continuously
     *   and are driven by the manager UI's per-row buttons, which work whether
     *   or not that UI is currently open.
     * - A dropped connection while the device is genuinely offline pauses
     *   automatically (status `WAITING_FOR_NETWORK`) and resumes the instant
     *   connectivity returns (see [NetworkReliability.waitForNetwork]) — this
     *   never counts against [maxRetries]; it's a wait, not a failure.
     * - A transient server-side error (HTTP 429/500/502/503/504) or an I/O
     *   error that occurs while the network still tests as reachable retries
     *   with exponential backoff (2s, 4s, 8s… capped at 30s) up to [maxRetries]
     *   times.
     * - A resume the server rejects (HTTP 416 — the local partial no longer
     *   matches what the server has) is discarded and restarted from 0% once;
     *   a repeat 416 on that fresh attempt is fatal rather than looping forever.
     * - Anything else (storage full, HTTP 401/403/404, cancellation) is fatal
     *   immediately.
     *
     * Must be called from a background thread. [task].destFile's bytes on
     * disk are preserved across every failure path, so resubmitting the same
     * task later resumes instead of restarting.
     */
    fun performResumableDownload(task: DownloadTask, maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES) {
        val destFile = task.destFile
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        var rangeRestartUsed = false

        while (true) {
            if (task.cancelRequested) throw Exception("Cancelled by user")
            val existingBytes = if (destFile.exists()) destFile.length() else 0L
            var conn: HttpURLConnection? = null

            try {
                task.status = DownloadTask.Status.CONNECTING
                task.detailText = if (existingBytes > 0) "Resuming…" else "Connecting…"
                onCheckpoint(task)
                val c = (URL(task.resolveUrl()).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    if (existingBytes > 0) setRequestProperty("Range", "bytes=$existingBytes-")
                    connectTimeout = 60_000
                    readTimeout    = 300_000
                }
                conn = c
                c.connect()
                val code = c.responseCode

                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    c.disconnect()
                    if (code == 416) {
                        if (rangeRestartUsed) {
                            throw Exception("Server rejected the download range even after restarting from 0% (HTTP 416).")
                        }
                        rangeRestartUsed = true
                        task.detailText = "Server rejected resume — restarting from 0%…"
                        destFile.delete()
                        onCheckpoint(task)
                        continue
                    }
                    if (code in NetworkReliability.RETRYABLE_HTTP_CODES) {
                        retryAttempt++
                        if (retryAttempt > maxRetries) {
                            throw Exception("Server returned HTTP $code — gave up after $maxRetries retries.")
                        }
                        notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                        networkReliability.sleepCancellable(backoffMs) { task.cancelRequested || task.pauseRequested }
                        if (task.cancelRequested) throw Exception("Cancelled by user")
                        awaitUnpauseIfRequested(task)
                        backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                        continue
                    }
                    throw Exception("Download failed (HTTP $code).")
                }

                // If we're resuming a partial download and the server's ETag for this
                // URL has changed since our partial bytes were saved, the remote content
                // itself changed underneath us (e.g. a re-run overwrote the artifact) —
                // resuming against it would silently splice old and new content together
                // into one corrupt file. Discard the stale partial and restart once, the
                // same defensive one-shot-restart pattern already used for a
                // server-rejected Range request (416) above.
                val newEtag = c.getHeaderField("ETag")
                val newLastModified = c.getHeaderField("Last-Modified")
                val etagChanged = existingBytes > 0 && !task.etag.isNullOrEmpty() &&
                    !newEtag.isNullOrEmpty() && task.etag != newEtag
                if (etagChanged) {
                    c.disconnect()
                    task.detailText = "Remote file changed since last attempt — restarting from 0%…"
                    destFile.delete()
                    task.etag = newEtag
                    task.lastModified = newLastModified
                    onCheckpoint(task)
                    continue
                }
                task.etag = newEtag ?: task.etag
                task.lastModified = newLastModified ?: task.lastModified

                // A server that ignores our Range header sends the whole file
                // again from byte 0 — discard the stale partial bytes rather
                // than corrupt the file by appending fresh content onto it.
                val serverIgnoredRange = existingBytes > 0 && code == HttpURLConnection.HTTP_OK
                if (serverIgnoredRange) destFile.delete()
                val effectiveExisting = if (serverIgnoredRange) 0L else existingBytes

                val contentLen = c.contentLengthLong
                val total = when {
                    code == HttpURLConnection.HTTP_PARTIAL ->
                        c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                            ?: (if (contentLen >= 0) contentLen + effectiveExisting else -1L)
                    contentLen >= 0 -> contentLen + effectiveExisting
                    else -> -1L
                }

                val remainingNeeded = if (total > 0) (total - effectiveExisting).coerceAtLeast(0L) else 0L
                if (!hasEnoughStorage(destFile.parentFile ?: appContext.cacheDir, remainingNeeded)) {
                    c.disconnect()
                    throw Exception("Not enough free storage for this download (need ~${Formatters.fmtBytes(remainingNeeded)} more).")
                }

                var downloaded = effectiveExisting
                task.totalBytes      = total
                task.downloadedBytes = downloaded
                task.status          = DownloadTask.Status.DOWNLOADING
                task.detailText       = ""
                onCheckpoint(task)

                val buf = ByteArray(32 * 1024)
                var speedStartTime  = System.currentTimeMillis()
                var speedStartBytes = downloaded
                // Persistence checkpoints are throttled far coarser than the speed
                // sample above (every ~1s instead of every ~200ms) — frequent enough
                // that a killed process loses at most a second of recorded progress
                // (resume correctness never depends on this value anyway; it always
                // re-verifies against destFile's actual length — see the top of this
                // loop), infrequent enough that it's never a meaningful source of I/O
                // pressure even with several downloads active at once.
                var lastCheckpointTime = speedStartTime

                c.inputStream.use { inp ->
                    FileOutputStream(destFile, effectiveExisting > 0).use { out ->
                        while (true) {
                            if (task.cancelRequested) throw Exception("Cancelled by user")
                            awaitUnpauseIfRequested(task)

                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n
                            task.downloadedBytes = downloaded

                            val now     = System.currentTimeMillis()
                            val elapsed = now - speedStartTime
                            if (elapsed >= 200) {
                                val speedBps = (downloaded - speedStartBytes) * 1000L / elapsed.coerceAtLeast(1)
                                speedStartTime  = now; speedStartBytes = downloaded
                                task.speedBps = speedBps
                                val remaining = if (total > 0) (total - downloaded).coerceAtLeast(0) else -1L
                                task.etaSeconds = if (total > 0 && speedBps > 0) remaining / speedBps else -1L
                            }
                            if (now - lastCheckpointTime >= 1_000) {
                                lastCheckpointTime = now
                                task.lastProgressAtMs = now
                                onCheckpoint(task)
                            }
                        }
                    }
                }
                c.disconnect()
                if (task.cancelRequested) throw Exception("Cancelled by user")

                task.downloadedBytes = downloaded
                task.status = DownloadTask.Status.VERIFYING
                task.detailText = "Verifying…"
                onCheckpoint(task)
                return

            } catch (e: Exception) {
                conn?.disconnect()
                if (e.message == "Cancelled by user") throw e
                // Only an I/O-ish failure is eligible for the automatic paths
                // below — e.g. the storage-full Exception thrown above is
                // fatal regardless of connectivity.
                if (e !is java.io.IOException) throw e

                if (!networkReliability.isNetworkAvailable()) {
                    task.status = DownloadTask.Status.WAITING_FOR_NETWORK
                    task.detailText = "⚠ Paused (No Internet) — will resume automatically"
                    onCheckpoint(task)
                    val reconnected = networkReliability.waitForNetwork { task.cancelRequested || task.pauseRequested }
                    if (!reconnected) {
                        if (task.cancelRequested) throw Exception("Cancelled by user")
                        // Otherwise waitForNetwork stopped early because pauseRequested fired,
                        // not because it actually reconnected — handle the pause properly, then
                        // loop back around. If the device is still offline, the very next
                        // connection attempt fails immediately and lands right back in this same
                        // branch to keep waiting for real connectivity.
                        awaitUnpauseIfRequested(task)
                        continue
                    }
                    task.status = DownloadTask.Status.DOWNLOADING
                    task.detailText = ""
                    onCheckpoint(task)
                    continue
                }

                retryAttempt++
                if (retryAttempt > maxRetries) {
                    throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                }
                notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                networkReliability.sleepCancellable(backoffMs) { task.cancelRequested || task.pauseRequested }
                if (task.cancelRequested) throw Exception("Cancelled by user")
                awaitUnpauseIfRequested(task)
                backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
            }
        }
    }

    /**
     * Waits out a pause if one is currently requested, transitioning through
     * `DownloadTask.Status.PAUSED` and back. Shared by every wait point in
     * [performResumableDownload] — the copy loop, both retry backoffs, and
     * the offline wait — so tapping Pause takes effect promptly no matter
     * which phase a task happens to be in, not just while actively receiving
     * bytes. Before this existed, only the copy loop actually checked
     * `pauseRequested`; a task that happened to be mid-backoff or waiting for
     * connectivity when Pause was tapped would silently ignore it until that
     * phase ended on its own (up to 30s for a backoff, potentially much
     * longer offline) — a real, reproducible reason pausing could feel like
     * it "wasn't working" on a flaky connection.
     *
     * Restores whatever status [task] had *before* pausing once resumed,
     * since what's correct to show next differs by caller (`DOWNLOADING`
     * from the copy loop, `RETRYING`/`WAITING_FOR_NETWORK` from the other
     * two) — this function doesn't need to know which, only how to get back
     * to it. A no-op if no pause is currently requested.
     *
     * Throws `"Cancelled by user"` if `cancelRequested` fires while waiting,
     * same as every other pause/cancel check in this class.
     */
    private fun awaitUnpauseIfRequested(task: DownloadTask) {
        if (!task.pauseRequested) return
        val resumeStatus = task.status
        task.status = DownloadTask.Status.PAUSED
        onCheckpoint(task)
        // Cancellation-aware wait instead of a bare Thread.sleep loop — wakes
        // early the instant either pauseRequested clears (resumed) or
        // cancelRequested fires, in slices of up to 200ms either way.
        while (task.pauseRequested && !task.cancelRequested) {
            networkReliability.sleepCancellable(200) { task.cancelRequested || !task.pauseRequested }
        }
        if (task.cancelRequested) throw Exception("Cancelled by user")
        task.status = resumeStatus
        onCheckpoint(task)
    }

    /** Sets a "retrying in Ns… (attempt X/Y)" status on [task] and records the
     *  attempt count (informational — see [DownloadTask.retryCount]'s kdoc). */
    private fun notifyRetrying(task: DownloadTask, attempt: Int, max: Int, backoffMs: Long) {
        task.status = DownloadTask.Status.RETRYING
        task.detailText = "Retrying in ${backoffMs / 1000}s… (attempt $attempt/$max)"
        task.retryCount = attempt
        onCheckpoint(task)
    }

    /**
     * Checks the target directory's filesystem for enough free space before
     * starting a download, so a large artifact fails fast with a clear message
     * instead of partway through with a confusing IOException. Content-length
     * of 0 or less (GitHub didn't report a size) skips the check rather than
     * blocking a legitimate download over a number we don't actually have.
     *
     * Also checks the public Downloads folder specifically, not just [dir]
     * (the app's internal cache, where the transfer itself lands first) —
     * the finished file is copied there afterward (see
     * [DownloadHistory.saveZipToDownloads]), and on some devices that's a
     * genuinely different storage volume/partition than internal cache.
     * Without this, a device that's nearly full could pass this check, let
     * the entire transfer complete, and only then fail at the very last
     * step — copying into Downloads — which is a far more confusing place
     * for a low-storage failure to surface.
     */
    private fun hasEnoughStorage(dir: java.io.File, requiredBytes: Long): Boolean {
        if (requiredBytes <= 0) return true
        return try {
            val margin = 10 * 1024 * 1024L // +10 MB safety margin
            val cacheOk = dir.usableSpace > requiredBytes + margin
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val downloadsOk = downloadsDir?.usableSpace?.let { it > requiredBytes + margin } ?: true
            cacheOk && downloadsOk
        } catch (_: Exception) {
            true // if we can't tell, don't block the download over it
        }
    }
}
