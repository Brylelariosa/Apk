package com.zipapkbuilder.feature.filemanager

import android.net.Uri
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.feature.upload.UploadCancellationToken

/**
 * Coordinator for everything file-manager-related: browsing the target
 * GitHub repo, viewing/editing a file, creating/renaming/deleting/moving
 * files and folders, and uploading a local file into the repo. The actual
 * work is split across four focused, single-responsibility controllers —
 * this class just constructs them (wiring each one's dependencies) and
 * exposes the small public surface the rest of the app calls into:
 * [showManageFilesDialog], [fetchAndBrowse], and [uploadFileToRepo].
 *
 * - [FileBrowserController] — repo browsing/navigation UI and its action menus
 * - [FileEditorController] — view/edit/save a file's content, copy it to clipboard
 * - [FileOperationController] — create/rename/move/delete files and folders
 * - [FileUploadController] — upload a local file into the repo
 * - [ZipExtractController] — extract a repo ZIP into real files/folders in place
 *
 * [FileBrowserController] is the one every mutating action ultimately
 * refreshes back through (every edit/create/delete/move re-fetches the
 * containing directory afterward, so the view can never drift from what's
 * actually on GitHub) — but [FileEditorController] and
 * [FileOperationController] don't depend on its concrete class for that.
 * They take a `refreshBrowser` callback instead, which keeps the dependency
 * one-way (browser → editor/operation for actions, not the reverse) even
 * though the real call graph loops back. [fileBrowserController] itself has
 * to be `lateinit` for this to wire up: the callback captures it by
 * reference before it exists yet, which is safe here because the callback
 * is never actually invoked until well after every controller below is
 * constructed.
 */
class FileManagerController(private val activity: MainActivity) {

    private lateinit var fileBrowserController: FileBrowserController

    private val refreshBrowser: (String, String, String, String, String) -> Unit =
        { token, owner, repo, branch, path -> fileBrowserController.fetchAndBrowse(token, owner, repo, branch, path) }

    private val fileEditorController    = FileEditorController(activity, refreshBrowser)
    private val fileOperationController = FileOperationController(activity, refreshBrowser)
    private val fileUploadController    = FileUploadController(activity)
    private val zipExtractController    = ZipExtractController(activity, refreshBrowser)

    init {
        fileBrowserController = FileBrowserController(activity, fileEditorController, fileOperationController, zipExtractController)
    }

    fun showManageFilesDialog() = fileBrowserController.showManageFilesDialog()

    fun fetchAndBrowse(token: String, owner: String, repo: String, branch: String, path: String) =
        fileBrowserController.fetchAndBrowse(token, owner, repo, branch, path)

    /** True while the file browser dialog is currently on screen — see
     *  [FileBrowserController.isShowing]'s kdoc for why this exists. */
    fun isFileManagerShowing(): Boolean = fileBrowserController.isShowing()

    fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String,
        cancellationToken: UploadCancellationToken = UploadCancellationToken()
    ) = fileUploadController.uploadFileToRepo(token, owner, repo, branch, filePath, uri, refreshPath, cancellationToken)
}
