package com.claudemanager.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.claudemanager.app.data.SortConfig
import com.claudemanager.app.data.SortGroup
import com.claudemanager.app.util.TimeUtil

/**
 * Lets the user decide how the project list is ordered: which groups come first (arrows), which
 * groups are used at all (switch), and how close "almost reset" is. Every change is saved at once.
 */
@Composable
fun SortScreen(
    config: SortConfig,
    onBack: () -> Unit,
    onChange: (SortConfig) -> Unit
) {
    val cs = MaterialTheme.colorScheme

    Scaffold { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
        ) {
            ScreenHeader("Sort order", onBack)
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Each project goes in the first group it fits, and the groups are listed " +
                            "from top to bottom. Use the arrows to move a group, or switch it off to ignore it. " +
                            "Inside a group, starred projects come first, then the soonest reset.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        config.order.forEachIndexed { index, group ->
                            GroupRow(
                                group = group,
                                enabled = group !in config.disabled,
                                isFirst = index == 0,
                                isLast = index == config.order.lastIndex,
                                onToggle = { onChange(config.toggled(group)) },
                                onUp = { onChange(config.moved(group, -1)) },
                                onDown = { onChange(config.moved(group, 1)) }
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Almost reset means",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "A project is almost reset when its timer ends within:",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (minutes in SortConfig.ALMOST_RESET_CHOICES) {
                            FilterPill(
                                label = TimeUtil.formatDuration(minutes * 60_000L),
                                selected = config.almostResetMinutes == minutes,
                                color = cs.primary
                            ) { onChange(config.copy(almostResetMinutes = minutes)) }
                        }
                    }
                }

                TextButton(
                    onClick = { onChange(SortConfig()) },
                    enabled = config != SortConfig()
                ) {
                    Text("Reset to default order")
                }
            }
        }
    }
}

@Composable
private fun GroupRow(
    group: SortGroup,
    enabled: Boolean,
    isFirst: Boolean,
    isLast: Boolean,
    onToggle: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(cs.surfaceVariant)
            .padding(start = 14.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // A switched-off group stays in the list, just dimmed, so it can be switched back on.
        Row(
            modifier = Modifier.weight(1f).alpha(if (enabled) 1f else 0.45f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusDot(group.dotColor(), 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = group.label(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = group.hint(),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
        IconButton(onClick = onUp, enabled = !isFirst) {
            Text("\u2191", fontSize = 20.sp)
        }
        IconButton(onClick = onDown, enabled = !isLast) {
            Text("\u2193", fontSize = 20.sp)
        }
        Switch(checked = enabled, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun SortGroup.dotColor(): Color {
    val s = status
    return when {
        s != null -> statusColor(s)
        this == SortGroup.RESET_DONE -> ResetGreen
        else -> MaterialTheme.colorScheme.primary
    }
}

private fun SortGroup.label(): String = when (this) {
    SortGroup.RESET_DONE -> "Reset time reached"
    SortGroup.RESET_SOON -> "Almost reset"
    SortGroup.TESTING -> "Testing"
    SortGroup.BUILDING -> "Building"
    SortGroup.RUNNING -> "Running"
    SortGroup.CUSTOM -> "Custom status"
    SortGroup.ERROR -> "Error"
    SortGroup.WAITING -> "Waiting"
    SortGroup.READY -> "Ready"
    SortGroup.FINISHED -> "Finished"
}

private fun SortGroup.hint(): String = when (this) {
    SortGroup.RESET_DONE -> "Timer is done, the account can be used again"
    SortGroup.RESET_SOON -> "Timer is about to finish"
    SortGroup.TESTING -> "Status is TESTING"
    SortGroup.BUILDING -> "Status is BUILDING"
    SortGroup.RUNNING -> "Status is RUNNING"
    SortGroup.CUSTOM -> "Status you named yourself"
    SortGroup.ERROR -> "Status is ERROR"
    SortGroup.WAITING -> "Status is WAITING"
    SortGroup.READY -> "Status is READY"
    SortGroup.FINISHED -> "Status is FINISHED"
}
