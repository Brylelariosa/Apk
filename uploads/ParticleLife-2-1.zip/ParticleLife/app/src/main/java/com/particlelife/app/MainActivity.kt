package com.particlelife.app

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Without this, phones with a notch/punch-hole camera letterbox around
        // it by default - the window stops short instead of drawing behind it.
        // SHORT_EDGES forces true edge-to-edge, cutout included.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        setContentView(R.layout.activity_main)

        gameView = findViewById(R.id.gameView)

        val actionPanel = findViewById<View>(R.id.actionPanel)
        findViewById<View>(R.id.btnMenu).setOnClickListener {
            actionPanel.visibility = if (actionPanel.isVisible) View.GONE else View.VISIBLE
        }

        fun runAndCollapse(action: () -> Unit) {
            action()
            actionPanel.visibility = View.GONE
        }

        findViewById<View>(R.id.btnRandomize).setOnClickListener { runAndCollapse { gameView.randomizeRules() } }
        findViewById<View>(R.id.btnMutate).setOnClickListener { runAndCollapse { gameView.mutateRules() } }
        findViewById<View>(R.id.btnColors).setOnClickListener { runAndCollapse { gameView.cycleColors() } }
        findViewById<View>(R.id.btnRules).setOnClickListener { runAndCollapse { gameView.toggleRules() } }
        findViewById<View>(R.id.btnReset).setOnClickListener { runAndCollapse { gameView.resetParticles() } }

        hideSystemUi()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    override fun onPause() {
        super.onPause()
        gameView.pause()
    }

    override fun onResume() {
        super.onResume()
        gameView.resume()
    }
}
