package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Particle Life: N species of particles, each pair of species has a signed
 * attraction coefficient. Every frame, every particle sums up forces from
 * nearby particles (weighted by that coefficient), integrates velocity with
 * friction, and moves. Random coefficients reliably produce clusters,
 * orbits, and chase/flee behavior - "life-like" motion with no explicit
 * rule for any of it.
 *
 * Runs its own render thread (matches the engine style used elsewhere:
 * SurfaceView + Runnable game loop, not Compose).
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    companion object {
        private const val NUM_TYPES = 6
        private const val PARTICLES_PER_TYPE = 90
        private const val INTERACTION_RADIUS = 220f     // px; also the spatial grid cell size
        private const val CLOSE_RANGE_FRACTION = 0.28f  // fraction of radius that's always repulsive
        private const val FRICTION = 0.88f              // velocity damping per frame
        private const val FORCE_SCALE = 900f
        private const val MAX_SPEED = 900f              // px/sec clamp, avoids blow-ups
        private const val TARGET_FPS = 60

        private val TYPE_COLORS = intArrayOf(
            Color.rgb(255, 87, 87),   // red
            Color.rgb(255, 200, 61),  // amber
            Color.rgb(102, 255, 128), // green
            Color.rgb(84, 209, 255),  // cyan
            Color.rgb(140, 120, 255), // violet
            Color.rgb(255, 120, 220)  // pink
        )
    }

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var hasSurface = false
    @Volatile private var pendingReset = false
    @Volatile private var pendingRandomize = false

    private val particles = mutableListOf<Particle>()
    private lateinit var attraction: Array<FloatArray>
    @Volatile private lateinit var grid: SpatialGrid

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trailPaint = Paint().apply { color = Color.argb(40, 8, 8, 16) }
    private val fpsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 34f
        isAntiAlias = true
    }

    private var firstFrame = true
    private var lastFpsTime = 0L
    private var frameCount = 0
    private var fps = 0

    init {
        holder.addCallback(this)
        randomizeAttractionMatrix()
    }

    // ---------- SurfaceHolder.Callback ----------

    override fun surfaceCreated(holder: SurfaceHolder) {
        hasSurface = true
        if (particles.isEmpty()) resetParticles()
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        grid = SpatialGrid(w.toFloat(), h.toFloat(), INTERACTION_RADIUS)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        hasSurface = false
        pause()
    }

    // ---------- lifecycle (called from MainActivity onResume/onPause) ----------

    fun resume() {
        if (running || !hasSurface) return
        running = true
        thread = Thread(this, "ParticleLifeLoop").apply { start() }
    }

    fun pause() {
        running = false
        thread?.join(500)
        thread = null
    }

    // ---------- public controls (called from the UI thread via button taps) ----------

    /** Requests a new random rule matrix; applied on the sim thread at the top of the next frame. */
    fun randomizeRules() {
        pendingRandomize = true
    }

    /** Requests particles be reshuffled to random positions using the current rules. */
    fun resetParticles() {
        pendingReset = true
    }

    // All mutation of `particles` / `attraction` happens only on the sim
    // thread (inside update()), triggered by the two volatile flags above.
    // That keeps the button-driven UI thread from ever touching the lists
    // the render/physics loop is iterating, so no locking is needed.

    private fun doResetParticles() {
        val w = width.takeIf { it > 0 } ?: 1080
        val h = height.takeIf { it > 0 } ?: 1920
        particles.clear()
        repeat(NUM_TYPES) { type ->
            repeat(PARTICLES_PER_TYPE) {
                particles.add(Particle(x = Random.nextFloat() * w, y = Random.nextFloat() * h, type = type))
            }
        }
        firstFrame = true
    }

    private fun randomizeAttractionMatrix() {
        attraction = Array(NUM_TYPES) { FloatArray(NUM_TYPES) { Random.nextFloat() * 2f - 1f } }
    }

    // ---------- game loop ----------

    override fun run() {
        val frameTimeMs = 1000L / TARGET_FPS
        while (running) {
            val start = System.currentTimeMillis()
            val dt = 1f / TARGET_FPS

            update(dt)
            draw()
            trackFps(start)

            val sleep = frameTimeMs - (System.currentTimeMillis() - start)
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun trackFps(now: Long) {
        frameCount++
        if (now - lastFpsTime >= 1000) {
            fps = frameCount
            frameCount = 0
            lastFpsTime = now
        }
    }

    // ---------- simulation ----------

    private fun update(dt: Float) {
        if (pendingRandomize) {
            randomizeAttractionMatrix()
            pendingRandomize = false
        }
        if (pendingReset) {
            doResetParticles()
            pendingReset = false
        }

        if (!::grid.isInitialized || width == 0 || height == 0) return
        val g = grid
        g.rebuild(particles)

        val w = width.toFloat()
        val h = height.toFloat()
        val closeRange = INTERACTION_RADIUS * CLOSE_RANGE_FRACTION

        for (p in particles) {
            var fx = 0f
            var fy = 0f

            g.forEachNearby(p.x, p.y) { j ->
                val other = particles[j]
                if (other !== p) {
                    val dx = other.x - p.x
                    val dy = other.y - p.y
                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < INTERACTION_RADIUS * INTERACTION_RADIUS) {
                        val dist = sqrt(distSq)
                        val f = forceAt(dist, attraction[p.type][other.type], closeRange)
                        fx += f * dx / dist
                        fy += f * dy / dist
                    }
                }
            }

            p.vx = (p.vx + fx * FORCE_SCALE * dt) * FRICTION
            p.vy = (p.vy + fy * FORCE_SCALE * dt) * FRICTION

            val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
            if (speed > MAX_SPEED) {
                p.vx = p.vx / speed * MAX_SPEED
                p.vy = p.vy / speed * MAX_SPEED
            }

            p.x += p.vx * dt
            p.y += p.vy * dt

            if (p.x < 0f) {
                p.x = 0f; p.vx = -p.vx * 0.5f
            } else if (p.x > w) {
                p.x = w; p.vx = -p.vx * 0.5f
            }
            if (p.y < 0f) {
                p.y = 0f; p.vy = -p.vy * 0.5f
            } else if (p.y > h) {
                p.y = h; p.vy = -p.vy * 0.5f
            }
        }
    }

    /**
     * Signed force magnitude (roughly -1..1) at distance [r].
     * Always repulsive inside [closeRange] (stops particles collapsing onto
     * each other regardless of rule matrix); beyond that it ramps from 0 up
     * to the rule coefficient [a] at the midpoint of the remaining range,
     * then back to 0 at INTERACTION_RADIUS.
     */
    private fun forceAt(r: Float, a: Float, closeRange: Float): Float {
        return if (r < closeRange) {
            r / closeRange - 1f
        } else {
            val span = INTERACTION_RADIUS - closeRange
            val t = (r - closeRange) / span
            a * (1f - abs(2f * t - 1f))
        }
    }

    // ---------- rendering ----------

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            if (firstFrame) {
                canvas.drawColor(Color.rgb(8, 8, 16))
                firstFrame = false
            } else {
                // Translucent overlay instead of a hard clear -> motion trails.
                canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), trailPaint)
            }
            for (p in particles) {
                particlePaint.color = TYPE_COLORS[p.type % TYPE_COLORS.size]
                canvas.drawCircle(p.x, p.y, 7f, particlePaint)
            }
            canvas.drawText("FPS: $fps  |  particles: ${particles.size}", 24f, 60f, fpsPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }
}
