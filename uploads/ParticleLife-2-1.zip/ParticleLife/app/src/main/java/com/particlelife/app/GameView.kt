package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Particle Life: N species of particles, each pair of species has a signed
 * attraction coefficient. Every frame, every particle sums up forces from
 * nearby particles (weighted by that coefficient), integrates velocity with
 * friction, and moves. Random coefficients reliably produce clusters,
 * orbits, and chase/flee behavior - "life-like" motion with no explicit
 * rule for any of it.
 *
 * The simulated world is larger than the visible screen (WORLD_SCALE) and
 * rendered zoomed-out (RENDER_SCALE = 1/WORLD_SCALE) so particles get more
 * room to roam without shrinking on screen - PARTICLE_RADIUS is pre-scaled
 * to compensate, see draw().
 *
 * Runs its own render thread (matches the engine style used elsewhere:
 * SurfaceView + Runnable game loop, not Compose).
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    companion object {
        private const val NUM_TYPES = 8
        private const val PARTICLES_PER_TYPE = 68
        private const val INTERACTION_RADIUS = 220f     // world px; also the spatial grid cell size
        private const val CLOSE_RANGE_FRACTION = 0.28f  // fraction of radius that's always repulsive
        private const val FRICTION = 0.88f              // velocity damping per frame
        private const val FORCE_SCALE = 900f
        private const val MAX_SPEED = 900f              // world px/sec clamp, avoids blow-ups
        private const val TARGET_FPS = 60

        private const val WORLD_SCALE = 1.75f           // world is this many times bigger than the screen
        private const val RENDER_SCALE = 1f / WORLD_SCALE
        private const val PARTICLE_RADIUS = 7f * WORLD_SCALE // pre-scaled so on-screen size is unchanged

        private const val MUTATE_STRENGTH = 0.25f       // max +/- nudge per coefficient on Mutate

        // Each palette needs at least NUM_TYPES colors. Cycled with the Colors button.
        private val COLOR_PALETTES: Array<IntArray> = arrayOf(
            intArrayOf( // Neon (original)
                Color.rgb(255, 87, 87),
                Color.rgb(255, 200, 61),
                Color.rgb(102, 255, 128),
                Color.rgb(84, 209, 255),
                Color.rgb(140, 120, 255),
                Color.rgb(255, 120, 220),
                Color.rgb(200, 255, 90),
                Color.rgb(190, 90, 255)
            ),
            intArrayOf( // Pastel
                Color.rgb(255, 179, 186),
                Color.rgb(255, 223, 186),
                Color.rgb(255, 255, 186),
                Color.rgb(186, 255, 201),
                Color.rgb(186, 255, 255),
                Color.rgb(186, 201, 255),
                Color.rgb(223, 186, 255),
                Color.rgb(255, 186, 240)
            ),
            intArrayOf( // Fire
                Color.rgb(255, 244, 214),
                Color.rgb(255, 214, 120),
                Color.rgb(255, 170, 60),
                Color.rgb(255, 120, 40),
                Color.rgb(240, 70, 30),
                Color.rgb(200, 40, 30),
                Color.rgb(140, 20, 20),
                Color.rgb(255, 90, 0)
            )
        )
    }

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var hasSurface = false
    @Volatile private var pendingReset = false
    @Volatile private var pendingRandomize = false
    @Volatile private var pendingMutate = false
    @Volatile private var paletteIndex = 0
    @Volatile private var showRules = false

    private var worldWidth = 0f
    private var worldHeight = 0f

    private val particles = mutableListOf<Particle>()
    private lateinit var attraction: Array<FloatArray>
    @Volatile private lateinit var grid: SpatialGrid

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 34f
        isAntiAlias = true
    }
    private val rulesPanelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesSwatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesCellPaint = Paint()
    private val rulesLegendPaint = Paint().apply {
        color = Color.rgb(210, 210, 220)
        textSize = 22f
        isAntiAlias = true
    }

    private var lastFpsTime = 0L
    private var frameCount = 0
    private var fps = 0

    init {
        holder.addCallback(this)
        randomizeAttractionMatrix()
    }

    // ---------- SurfaceHolder.Callback ----------

    override fun surfaceCreated(holder: SurfaceHolder) {
        hasSurface = true
        if (particles.isEmpty()) resetParticles()
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        worldWidth = w * WORLD_SCALE
        worldHeight = h * WORLD_SCALE
        grid = SpatialGrid(worldWidth, worldHeight, INTERACTION_RADIUS)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        hasSurface = false
        pause()
    }

    // ---------- lifecycle (called from MainActivity onResume/onPause) ----------

    fun resume() {
        if (running || !hasSurface) return
        running = true
        thread = Thread(this, "ParticleLifeLoop").apply { start() }
    }

    fun pause() {
        running = false
        thread?.join(500)
        thread = null
    }

    // ---------- public controls (called from the UI thread via button taps) ----------

    /** Requests a brand new random rule matrix; applied on the sim thread at the top of the next frame. */
    fun randomizeRules() {
        pendingRandomize = true
    }

    /** Requests the CURRENT rule matrix be nudged a little rather than replaced; applied on the sim thread. */
    fun mutateRules() {
        pendingMutate = true
    }

    /** Requests particles be reshuffled to random positions using the current rules. */
    fun resetParticles() {
        pendingReset = true
    }

    /** Switches to the next color palette. Purely visual - safe to flip directly, no sim-thread handoff needed. */
    fun cycleColors() {
        paletteIndex = (paletteIndex + 1) % COLOR_PALETTES.size
    }

    /** Shows/hides the attraction-matrix legend overlay so you can see what color attracts/repels what. */
    fun toggleRules() {
        showRules = !showRules
    }

    // All mutation of `particles` / `attraction` happens only on the sim
    // thread (inside update()), triggered by the volatile flags above.
    // That keeps the button-driven UI thread from ever touching the lists
    // the render/physics loop is iterating, so no locking is needed.

    private fun doResetParticles() {
        val w = worldWidth.takeIf { it > 0f } ?: (1080f * WORLD_SCALE)
        val h = worldHeight.takeIf { it > 0f } ?: (1920f * WORLD_SCALE)
        particles.clear()
        repeat(NUM_TYPES) { type ->
            repeat(PARTICLES_PER_TYPE) {
                particles.add(Particle(x = Random.nextFloat() * w, y = Random.nextFloat() * h, type = type))
            }
        }
    }

    private fun randomizeAttractionMatrix() {
        attraction = Array(NUM_TYPES) { FloatArray(NUM_TYPES) { Random.nextFloat() * 2f - 1f } }
    }

    private fun mutateAttractionMatrix() {
        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val delta = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                attraction[i][j] = (attraction[i][j] + delta).coerceIn(-1f, 1f)
            }
        }
    }

    // ---------- game loop ----------

    override fun run() {
        val frameTimeMs = 1000L / TARGET_FPS
        while (running) {
            val start = System.currentTimeMillis()
            val dt = 1f / TARGET_FPS

            update(dt)
            draw()
            trackFps(start)

            val sleep = frameTimeMs - (System.currentTimeMillis() - start)
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun trackFps(now: Long) {
        frameCount++
        if (now - lastFpsTime >= 1000) {
            fps = frameCount
            frameCount = 0
            lastFpsTime = now
        }
    }

    // ---------- simulation ----------

    private fun update(dt: Float) {
        if (pendingRandomize) {
            randomizeAttractionMatrix()
            pendingRandomize = false
        }
        if (pendingMutate) {
            mutateAttractionMatrix()
            pendingMutate = false
        }
        if (pendingReset) {
            doResetParticles()
            pendingReset = false
        }

        if (!::grid.isInitialized || worldWidth == 0f || worldHeight == 0f) return
        val g = grid
        g.rebuild(particles)

        val w = worldWidth
        val h = worldHeight
        val closeRange = INTERACTION_RADIUS * CLOSE_RANGE_FRACTION

        for (p in particles) {
            var fx = 0f
            var fy = 0f

            g.forEachNearby(p.x, p.y) { j ->
                val other = particles[j]
                if (other !== p) {
                    val dx = other.x - p.x
                    val dy = other.y - p.y
                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < INTERACTION_RADIUS * INTERACTION_RADIUS) {
                        val dist = sqrt(distSq)
                        val f = forceAt(dist, attraction[p.type][other.type], closeRange)
                        fx += f * dx / dist
                        fy += f * dy / dist
                    }
                }
            }

            p.vx = (p.vx + fx * FORCE_SCALE * dt) * FRICTION
            p.vy = (p.vy + fy * FORCE_SCALE * dt) * FRICTION

            val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
            if (speed > MAX_SPEED) {
                p.vx = p.vx / speed * MAX_SPEED
                p.vy = p.vy / speed * MAX_SPEED
            }

            p.x += p.vx * dt
            p.y += p.vy * dt

            if (p.x < 0f) {
                p.x = 0f; p.vx = -p.vx * 0.5f
            } else if (p.x > w) {
                p.x = w; p.vx = -p.vx * 0.5f
            }
            if (p.y < 0f) {
                p.y = 0f; p.vy = -p.vy * 0.5f
            } else if (p.y > h) {
                p.y = h; p.vy = -p.vy * 0.5f
            }
        }
    }

    /**
     * Signed force magnitude (roughly -1..1) at distance [r].
     * Always repulsive inside [closeRange] (stops particles collapsing onto
     * each other regardless of rule matrix); beyond that it ramps from 0 up
     * to the rule coefficient [a] at the midpoint of the remaining range,
     * then back to 0 at INTERACTION_RADIUS.
     */
    private fun forceAt(r: Float, a: Float, closeRange: Float): Float {
        return if (r < closeRange) {
            r / closeRange - 1f
        } else {
            val span = INTERACTION_RADIUS - closeRange
            val t = (r - closeRange) / span
            a * (1f - abs(2f * t - 1f))
        }
    }

    // ---------- rendering ----------

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            // Hard clear every frame - no motion-trail overlay.
            canvas.drawColor(Color.rgb(8, 8, 16))

            if (worldWidth > 0f && worldHeight > 0f) {
                val colors = COLOR_PALETTES[paletteIndex]
                canvas.save()
                canvas.scale(RENDER_SCALE, RENDER_SCALE)
                for (p in particles) {
                    particlePaint.color = colors[p.type % colors.size]
                    canvas.drawCircle(p.x, p.y, PARTICLE_RADIUS, particlePaint)
                }
                canvas.restore()
            }

            // Everything below draws in raw screen pixels, outside the world
            // scale transform, so it stays crisp regardless of WORLD_SCALE.
            if (showRules) drawRulesOverlay(canvas)
            canvas.drawText("FPS: $fps  |  particles: ${particles.size}", 24f, 60f, fpsPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    /**
     * Small legend panel: an NxN grid where cell (row, col) shows how the
     * row's species reacts to the column's species - green means attract,
     * red means repel, brightness is the strength. Row/column headers are
     * color swatches so they map directly to what's on screen. `attraction`
     * is only ever touched from this same sim thread, so no locking needed
     * here either.
     */
    private fun drawRulesOverlay(canvas: Canvas) {
        val colors = COLOR_PALETTES[paletteIndex]
        val cell = 30f
        val headerSize = 26f
        val pad = 16f
        val left = 24f
        val top = 100f

        val gridLeft = left + pad + headerSize
        val gridTop = top + pad + headerSize
        val gridSize = cell * NUM_TYPES

        val legendLine1 = "rows react to columns"
        val legendLine2 = "green = attract, red = repel"
        val legendWidth = maxOf(
            rulesLegendPaint.measureText(legendLine1),
            rulesLegendPaint.measureText(legendLine2)
        )
        val contentWidth = maxOf(gridSize, legendWidth)

        val panelRight = left + pad + headerSize + contentWidth + pad
        val panelBottom = gridTop + gridSize + pad + 58f

        rulesPanelPaint.color = Color.argb(225, 14, 14, 22)
        canvas.drawRoundRect(left, top, panelRight, panelBottom, 20f, 20f, rulesPanelPaint)

        for (i in 0 until NUM_TYPES) {
            rulesSwatchPaint.color = colors[i % colors.size]
            canvas.drawCircle(gridLeft + i * cell + cell / 2f, top + pad + headerSize / 2f, 8f, rulesSwatchPaint)
            canvas.drawCircle(left + pad + headerSize / 2f, gridTop + i * cell + cell / 2f, 8f, rulesSwatchPaint)
        }

        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val v = attraction[i][j].coerceIn(-1f, 1f)
                val mag = abs(v)
                rulesCellPaint.color = if (v >= 0f) {
                    Color.rgb(lerp(40, 60, mag), lerp(40, 210, mag), lerp(50, 90, mag))
                } else {
                    Color.rgb(lerp(40, 220, mag), lerp(40, 55, mag), lerp(50, 60, mag))
                }
                val cx = gridLeft + j * cell
                val cy = gridTop + i * cell
                canvas.drawRect(cx + 1f, cy + 1f, cx + cell - 1f, cy + cell - 1f, rulesCellPaint)
            }
        }

        canvas.drawText(legendLine1, left + pad, gridTop + gridSize + pad + 24f, rulesLegendPaint)
        canvas.drawText(legendLine2, left + pad, gridTop + gridSize + pad + 50f, rulesLegendPaint)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = (a + (b - a) * t.coerceIn(0f, 1f)).toInt()
}
