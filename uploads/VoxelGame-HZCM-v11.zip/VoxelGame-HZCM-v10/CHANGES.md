# HZCM v4 — Engineering Change Log (v9 → v10)

## Bug Fixes

### `World.cpp` — Three targeted fixes

---

#### Fix 1: Wrong cluster upload order → floating terrain / treetops with no ground

**Root cause:** `updateGPU()` iterated the upload task batch *forward*.  Tasks were
pushed in reverse order (ci=3, ci=2, ci=1, ci=0) so that LIFO single-pop gives
ci=0 first — but the batch path assigned `end-n..end` into a vector and iterated it
in order, which processes ci=3 (treetops/sky) first.  When the thermal budget was
< 4 (WARM or HOT state), only the top clusters became READY in the first frame,
producing floating tree canopies and snow islands with no ground beneath them.

**Fix:** Changed the task-iteration loop from forward to reverse:
```cpp
// Before (wrong):
for (auto& task : tasks) { ... }

// After (correct — processes ci=0 ground first):
for (int ti = (int)tasks.size() - 1; ti >= 0; --ti) {
    auto& task = tasks[ti]; ...
}
```

---

#### Fix 2: Transparent block sides during neighbour-flush rebuild

**Root cause:** `gatherAndDraw()` only rendered `ClusterState::READY` clusters.
When a loaded chunk's neighbour loaded, `workerNeighbourFlush` enqueued a
`CLUSTER_REBUILD` for the border clusters.  `buildClusterMesh` set the state to
`MESHED` on completion.  Between that transition and the next `updateGPU` frame,
the cluster's existing GPU allocation was still valid but the cluster was invisible
because the render path skipped anything that wasn't `READY`.  At low upload
budgets (HOT/CRITICAL state) or many concurrent rebuilds, this invisible window
stretched to multiple frames, producing persistent holes in terrain sides.

**Fix:** `gatherAndDraw` now also draws `MESHED` clusters that have a valid GPU
allocation (`clusterGPUOffset != MEGA_INVALID`), continuing to show the previous
mesh while the new one awaits upload:
```cpp
ClusterState cst = ch->clusterState[ci].load(std::memory_order_acquire);
if (cst != ClusterState::READY && cst != ClusterState::MESHED) continue;
// (existing offset/count guard then handles the empty-slot case)
```

---

#### Fix 3: Persistent transparent borders from concurrent chunk-build race

**Root cause:** Two adjacent chunks A and B could build concurrently.  If A grabbed
its neighbour pointers before B finished `generate()`, A meshed with `nb.px = null`
(treating B's side as AIR) and generated incorrect border faces.  When B completed
and called `workerNeighbourFlush(B)`, it checked A's clusters — but if they were
still in `DIRTY` state (A was mid-mesh), the flush skipped them.  A then became
`READY` with permanently wrong border faces and no further rebuild was ever queued.

**Fix:** After `workerChunkBuild` completes all cluster meshes, it re-reads the
four horizontal neighbour pointers and compares them to what was used at mesh time.
If any previously-null neighbour has since become generated, all CLUSTER_STACK
clusters are enqueued for rebuild:
```cpp
bool stale =
    (nx2 && nx2->generated.load() && !nx) ||
    (px2 && px2->generated.load() && !px) ||
    (nz2 && nz2->generated.load() && !nz) ||
    (pz2 && pz2->generated.load() && !pz);
if (stale) {
    for (int ci2 = 0; ci2 < CLUSTER_STACK; ++ci2)
        enqueueClusterRebuild(chunk, ci2);
}
```

---

## No other files changed

All three fixes are confined to `World.cpp`.  No API surface, shader, or data
layout changes were made.
