# kotlinx-coroutines-android discovers Dispatchers.Main via ServiceLoader at
# runtime, not a direct code reference — R8 full mode (the only mode AGP 8+
# supports) can decide that class is unreachable and strip/rename it, which
# crashes on the first coroutine launch. See the sibling SystemMonitor project
# for the launch-crash this caused there.
-keep class kotlinx.coroutines.android.** { *; }
-keep class kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keep class kotlinx.coroutines.CoroutineExceptionHandler { *; }
-dontwarn kotlinx.coroutines.**

# Belt-and-suspenders on manifest-declared entry points (AGP's default rules
# already cover this, but it costs nothing to be explicit).
-keep class com.bru.gameboost.GameBoostApp { *; }
-keep class com.bru.gameboost.presentation.MainActivity { *; }
-keep class com.bru.gameboost.presentation.BoostSessionService { *; }
-keep class com.bru.gameboost.presentation.GameBoostViewModel { *; }
-keep class com.bru.gameboost.presentation.GameBoostViewModel$Factory { *; }
