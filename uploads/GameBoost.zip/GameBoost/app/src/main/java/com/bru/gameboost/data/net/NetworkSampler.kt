package com.bru.gameboost.data.net

import com.bru.gameboost.domain.model.NetworkStatus

/** One reading of how the phone is connected and how fast the internet answers. */
interface NetworkSampler {

    /**
     * Waits on the network for up to a few seconds, so call it from its own loop and never from a
     * timing-sensitive one. Null means the platform wouldn't say (a revoked permission, say) —
     * show that as "unknown", not as "offline".
     */
    suspend fun sample(): NetworkStatus?
}
