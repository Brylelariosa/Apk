package com.bru.gameboost.presentation

import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.ConnectionType
import com.bru.gameboost.domain.model.CpuLoad
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.Latency
import com.bru.gameboost.domain.model.NetworkStatus
import com.bru.gameboost.domain.model.PingQuality
import com.bru.gameboost.domain.model.ThermalStatus
import java.util.Locale
import kotlin.math.roundToInt

/** The one place snapshots become text, so the notification and the screens never disagree. */
object SnapshotFormatter {

    /** Notification body: stats on the first line, then what the RAM clean freed (if one ran). */
    fun notificationText(snapshot: DeviceSnapshot?, cleanResult: CleanResult?): String {
        val stats = if (snapshot == null) {
            "Starting up…"
        } else {
            listOfNotNull(
                "CPU ${cpu(snapshot)}",
                pingForNotification(snapshot),
                "RAM ${ram(snapshot)}",
                snapshot.batteryTempC?.let { temperature(it) },
                "Batt ${battery(snapshot)}",
                throttling(snapshot)
            ).joinToString(" · ")
        }
        return if (cleanResult == null) stats else "$stats\n${cleanSummary(cleanResult)}"
    }

    fun cleanSummary(result: CleanResult): String =
        if (result.freedMb > 0) {
            "Freed ≈ ${result.freedMb} MB · ${result.appsChecked} apps checked"
        } else {
            "Nothing left to free · ${result.appsChecked} apps checked"
        }

    /** Short form for the boost checklist, where the app count is noise. */
    fun freedShort(result: CleanResult): String =
        if (result.freedMb > 0) "Freed ≈ ${result.freedMb} MB" else "RAM already clean"

    fun temperature(tempC: Float): String = String.format(Locale.getDefault(), "%.1f°C", tempC)

    fun cpu(snapshot: DeviceSnapshot): String = when (val load = snapshot.cpuLoad) {
        is CpuLoad.Measured -> "${load.percent.roundToInt()}%"
        // Inferred from clock speeds, not true utilisation — the "~" keeps it honest.
        is CpuLoad.Estimated -> "~${load.percent.roundToInt()}%"
        else -> "—"
    }

    /** Why the CPU meter is empty, or null when it isn't (or the first reading is still on its way). */
    fun cpuUnavailableNote(snapshot: DeviceSnapshot): String? =
        (snapshot.cpuLoad as? CpuLoad.Unavailable)?.let { "CPU load isn't readable on this device (${it.reason})" }

    /** The ping meter's value: "38 ms", or why there is no figure. */
    fun ping(snapshot: DeviceSnapshot): String = when (val status = snapshot.network) {
        null -> "—"
        NetworkStatus.Offline -> "Offline"
        is NetworkStatus.Online -> when (val latency = status.latency) {
            is Latency.Measured -> "${latency.medianMs} ms"
            Latency.Unreachable -> "No answer"
        }
    }

    /** The notification's connection fragment; null while the first probe is still running. */
    fun pingForNotification(snapshot: DeviceSnapshot): String? = when (val status = snapshot.network) {
        null -> null
        NetworkStatus.Offline -> "Offline"
        is NetworkStatus.Online -> when (val latency = status.latency) {
            is Latency.Measured -> "Ping ${latency.medianMs} ms"
            Latency.Unreachable -> "Ping: no answer"
        }
    }

    /**
     * Under the ping meter: what the figure was measured against (so it never passes itself off
     * as the game server's own ping), plus advice when the connection is poor. Null while measuring.
     */
    fun pingCaption(snapshot: DeviceSnapshot): String? = when (val status = snapshot.network) {
        null -> null
        NetworkStatus.Offline -> "No internet connection"
        is NetworkStatus.Online -> when (val latency = status.latency) {
            is Latency.Measured -> measuredPingCaption(status.type, latency)
            Latency.Unreachable -> unansweredPingCaption(status.type)
        }
    }

    private fun measuredPingCaption(type: ConnectionType, latency: Latency.Measured): String {
        val facts = buildList<String> {
            add(connectionLabel(type))
            add("to ${latency.host}")
            add("jitter ${latency.jitterMs} ms")
            if (latency.lost > 0) {
                add(if (latency.lost == 1) "1 probe dropped" else "${latency.lost} probes dropped")
            }
        }.joinToString(" · ")

        val hint = when {
            PingQuality.of(latency.medianMs) == PingQuality.POOR -> highPingHint(type)
            latency.lost > 0 || latency.jitterMs >= HIGH_JITTER_MS -> "Unstable connection — expect lag spikes"
            else -> null
        }
        return if (hint == null) facts else "$facts\n$hint"
    }

    private fun unansweredPingCaption(type: ConnectionType): String = when (type) {
        ConnectionType.WIFI -> "Wi-Fi is connected, but the ping test got no answer — check the router"
        ConnectionType.MOBILE_DATA ->
            "Mobile data is connected, but the ping test got no answer — check your signal or data balance"
        else -> "${connectionLabel(type)} is connected, but the ping test got no answer"
    }

    private fun highPingHint(type: ConnectionType): String = when (type) {
        ConnectionType.WIFI -> "High ping — move closer to the router, or use its 5 GHz band"
        ConnectionType.MOBILE_DATA -> "High ping — weak or busy mobile signal here; try a better spot, or Wi-Fi"
        ConnectionType.VPN -> "High ping — a VPN adds a detour; try it off"
        ConnectionType.ETHERNET, ConnectionType.OTHER -> "High ping — the connection itself is slow"
    }

    private fun connectionLabel(type: ConnectionType): String = when (type) {
        ConnectionType.WIFI -> "Wi-Fi"
        ConnectionType.MOBILE_DATA -> "Mobile data"
        ConnectionType.ETHERNET -> "Ethernet"
        ConnectionType.VPN -> "VPN"
        ConnectionType.OTHER -> "Network"
    }

    fun ram(snapshot: DeviceSnapshot): String {
        val used = snapshot.ramUsedMb
        val total = snapshot.ramTotalMb
        return if (used != null && total != null) "${gigabytes(used)}/${gigabytes(total)} GB" else "—"
    }

    fun battery(snapshot: DeviceSnapshot): String {
        val percent = snapshot.batteryPercent?.let { "$it%" } ?: "—"
        return if (snapshot.isCharging == true) "$percent (charging)" else percent
    }

    /** Only worth a mention once the platform itself reports throttling; null otherwise. */
    fun throttling(snapshot: DeviceSnapshot): String? {
        val status = snapshot.thermalStatus ?: return null
        if (status == ThermalStatus.NONE || status == ThermalStatus.UNKNOWN) return null
        return "Thermal ${status.name.lowercase()}"
    }

    // Consecutive probes differing by this much on average mean the link is wobbling, whatever its median.
    private const val HIGH_JITTER_MS = 30

    private fun gigabytes(mb: Long): String = String.format(Locale.getDefault(), "%.1f", mb / 1024.0)
}
