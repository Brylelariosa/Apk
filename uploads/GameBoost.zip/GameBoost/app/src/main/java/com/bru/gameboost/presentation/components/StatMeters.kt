package com.bru.gameboost.presentation.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bru.gameboost.domain.model.CpuLoad
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.Latency
import com.bru.gameboost.domain.model.NetworkStatus
import com.bru.gameboost.domain.model.PingQuality
import com.bru.gameboost.domain.model.isDown
import com.bru.gameboost.domain.model.pingMs
import com.bru.gameboost.presentation.SnapshotFormatter
import kotlin.math.roundToInt

// The temperature meter spans a realistic phone range; amber starts a few degrees before the alert.
private const val TEMP_BAR_MIN_C = 25f
private const val TEMP_BAR_MAX_C = 50f
private const val WARM_MARGIN_C = 3f

// The ping meter is full at this round trip; anything slower just pins the bar.
private const val PING_BAR_MAX_MS = 200f
private val WarmColor = Color(0xFFFFB300)

/**
 * The four mini meters (CPU, RAM, Ping, Temp) side by side. It turns a [DeviceSnapshot] into
 * fractions, colours and short readouts, so the card around it only has to place it. While
 * [ramScanning] a highlight sweeps along the RAM bar: the "working on it" cue for a RAM clean.
 *
 * It draws edge to edge in its own bounds, so whatever hosts it must not clip it to a rounded
 * shape without padding it first: flush against a rounded corner the first label loses its edge.
 */
@Composable
fun StatMeters(
    snapshot: DeviceSnapshot?,
    alertAtC: Float,
    ramScanning: Boolean,
    modifier: Modifier = Modifier
) {
    val usedMb = snapshot?.ramUsedMb
    val totalMb = snapshot?.ramTotalMb
    val ramFraction = if (usedMb != null && totalMb != null && totalMb > 0) usedMb.toFloat() / totalMb else null
    val cpuFraction = (snapshot?.cpuLoad as? CpuLoad.Reading)?.let { it.percent / 100f }
    val cpuApprox = snapshot?.cpuLoad is CpuLoad.Estimated
    val tempC = snapshot?.batteryTempC
    val tempFraction = tempC?.let { (it - TEMP_BAR_MIN_C) / (TEMP_BAR_MAX_C - TEMP_BAR_MIN_C) }
    val tempColor = when {
        tempC != null && tempC >= alertAtC -> MaterialTheme.colorScheme.error
        tempC != null && tempC >= alertAtC - WARM_MARGIN_C -> WarmColor
        else -> MaterialTheme.colorScheme.primary
    }
    val network = snapshot?.network
    val pingMs = network.pingMs
    val pingColor = when {
        network.isDown -> MaterialTheme.colorScheme.error
        pingMs == null -> MaterialTheme.colorScheme.primary
        else -> when (PingQuality.of(pingMs)) {
            PingQuality.GOOD -> MaterialTheme.colorScheme.primary
            PingQuality.FAIR -> WarmColor
            PingQuality.POOR -> MaterialTheme.colorScheme.error
        }
    }
    // A dead connection fills the bar red: it is the worst reading, not a missing one.
    val pingFraction = if (network.isDown) 1f else pingMs?.let { it / PING_BAR_MAX_MS }

    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        MiniMeter(
            label = "CPU",
            fraction = cpuFraction,
            barColor = MaterialTheme.colorScheme.primary,
            valueText = { f -> (if (cpuApprox) "~" else "") + "${(f * 100f).roundToInt()}%" },
            modifier = Modifier.weight(1f)
        )
        MiniMeter(
            label = "RAM",
            fraction = ramFraction,
            barColor = MaterialTheme.colorScheme.primary,
            valueText = { f -> "${(f * 100f).roundToInt()}%" },
            modifier = Modifier.weight(1f),
            scanning = ramScanning
        )
        MiniMeter(
            label = "Ping",
            fraction = pingFraction,
            barColor = pingColor,
            valueText = { _ -> pingShort(network) },
            modifier = Modifier.weight(1f)
        )
        MiniMeter(
            label = "Temp",
            fraction = tempFraction,
            barColor = tempColor,
            valueText = { _ -> tempC?.let { SnapshotFormatter.temperature(it) } ?: "—" },
            modifier = Modifier.weight(1f)
        )
    }
}

/**
 * One label, one number, one thin bar. The number is derived from the animated bar fill, so the
 * digits count smoothly along with the bar instead of jumping ahead of it. While [scanning] a
 * highlight sweeps along the bar: the "working on it" cue for a RAM clean.
 */
@Composable
private fun MiniMeter(
    label: String,
    fraction: Float?,
    barColor: Color,
    valueText: (Float) -> String,
    modifier: Modifier = Modifier,
    scanning: Boolean = false
) {
    val fill by animateFloatAsState(
        targetValue = (fraction ?: 0f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 700),
        label = "meterFill"
    )
    val color by animateColorAsState(
        targetValue = barColor,
        animationSpec = tween(durationMillis = 400),
        label = "meterColor"
    )
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)

    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
        Text(
            text = if (fraction == null) "—" else valueText(fill),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Clip
        )
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(track)
                .drawBehind {
                    drawRoundRect(
                        color = color,
                        size = Size(size.width * fill, size.height),
                        cornerRadius = CornerRadius(size.height / 2f)
                    )
                }
        ) {
            if (scanning) {
                ScanSweep(color = MaterialTheme.colorScheme.primary, modifier = Modifier.matchParentSize())
            }
        }
    }
}

/** A bright segment that runs along the bar. Only composed while a clean runs, so it costs nothing otherwise. */
@Composable
private fun ScanSweep(color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "scan")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing)
        ),
        label = "scanPhase"
    )
    Canvas(modifier = modifier) {
        val segment = size.width * 0.4f
        val left = ((size.width + segment) * phase - segment).coerceAtLeast(0f)
        val right = ((size.width + segment) * phase).coerceAtMost(size.width)
        if (right > left) {
            drawRect(
                color = color,
                topLeft = Offset(left, 0f),
                size = Size(right - left, size.height)
            )
        }
    }
}

/** The ping meter's value, short enough for a quarter-width column ("38 ms", "Offline", "No reply"). */
private fun pingShort(status: NetworkStatus?): String = when (status) {
    null -> "—"
    NetworkStatus.Offline -> "Offline"
    is NetworkStatus.Online -> when (val latency = status.latency) {
        is Latency.Measured -> "${latency.medianMs} ms"
        Latency.Unreachable -> "No reply"
    }
}
