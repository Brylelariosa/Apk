package com.bru.gameboost.presentation.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.presentation.RamCleanState
import com.bru.gameboost.presentation.SnapshotFormatter

// The card's padding. The meters' tap area runs to the card's edges, so it carries this padding
// itself: the card's own rounded corners shape its ripple, and no label sits flush against a
// clipped corner (a small rounded clip right around the meters used to shave the "C" off "CPU").
private val CardPaddingH = 14.dp
private val CardPaddingV = 12.dp

// Vertical gap between the card's sections: meters, battery notice, clean row.
private val SectionGap = 10.dp

private enum class CleanPhase { IDLE, RUNNING, RESULT }

/**
 * The whole "this device right now" readout in one short card: four mini meters and the Free RAM
 * action. It replaces a tall stack of bars so the games below it stay on screen. Tapping the
 * meters asks the screen to show [StatDetails] (ping notes, battery, thermal) as its own item.
 */
@Composable
fun StatStrip(
    snapshot: DeviceSnapshot?,
    alertAtC: Float,
    ramClean: RamCleanState,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onFreeRam: () -> Unit,
    onOpenBatterySaver: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    onClickLabel = if (expanded) "Hide details" else "Show details",
                    onClick = onToggleExpanded
                )
                .padding(
                    start = CardPaddingH,
                    top = CardPaddingV,
                    end = CardPaddingH,
                    bottom = SectionGap
                )
        ) {
            StatMeters(
                snapshot = snapshot,
                alertAtC = alertAtC,
                ramScanning = ramClean.running
            )
            // Sits in the empty right end of the last label, so the meters keep their width.
            ExpandChevron(expanded = expanded, modifier = Modifier.align(Alignment.TopEnd))
        }

        Column(
            modifier = Modifier.padding(start = CardPaddingH, end = CardPaddingH, bottom = CardPaddingV),
            verticalArrangement = Arrangement.spacedBy(SectionGap)
        ) {
            if (snapshot?.powerSaveMode == true) {
                BatterySaverNotice(onOpenSettings = onOpenBatterySaver)
            }
            CleanActionRow(ramClean = ramClean, onFreeRam = onFreeRam)
        }
    }
}

/** The second line of detail under the strip: what the four meters can't say in one word. */
@Composable
fun StatDetails(snapshot: DeviceSnapshot, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(horizontal = CardPaddingH, vertical = CardPaddingV),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DetailLine("RAM", "${SnapshotFormatter.ram(snapshot)} in use")
            SnapshotFormatter.pingCaption(snapshot)?.let { DetailLine("Ping", it) }
            SnapshotFormatter.cpuUnavailableNote(snapshot)?.let { DetailLine("CPU", it) }
            DetailLine(
                "Battery",
                listOfNotNull(
                    SnapshotFormatter.battery(snapshot),
                    SnapshotFormatter.throttling(snapshot)
                ).joinToString(" · ")
            )
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(56.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
    }
}

/** The small arrow that flips when the details are open. Owns its animation, so only it recomposes while turning. */
@Composable
private fun ExpandChevron(expanded: Boolean, modifier: Modifier = Modifier) {
    val angle by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(durationMillis = 250),
        label = "statChevron"
    )
    Icon(
        imageVector = Icons.Default.KeyboardArrowDown,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
            .size(16.dp)
            .graphicsLayer { rotationZ = angle }
    )
}

@Composable
private fun BatterySaverNotice(onOpenSettings: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Battery Saver is on — it can limit performance while you play.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(
            onClick = onOpenSettings,
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) { Text("Settings") }
    }
}

/**
 * A status line (idle hint, progress, or the last result) beside the Free RAM button. The freed
 * figure counts up from zero each time a clean finishes. It starts "done" so that coming back to
 * the screen doesn't replay an old result.
 */
@Composable
private fun CleanActionRow(
    ramClean: RamCleanState,
    onFreeRam: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lastClean = ramClean.last
    val countUp = remember { Animatable(1f) }
    LaunchedEffect(ramClean.running) {
        if (ramClean.running) {
            countUp.snapTo(0f)
        } else {
            countUp.animateTo(1f, tween(durationMillis = 700, easing = FastOutSlowInEasing))
        }
    }
    val phase = when {
        ramClean.running -> CleanPhase.RUNNING
        lastClean != null -> CleanPhase.RESULT
        else -> CleanPhase.IDLE
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AnimatedContent(
            targetState = phase,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp),
            label = "cleanLine"
        ) { shown ->
            when (shown) {
                CleanPhase.RUNNING -> StatusText("Closing background apps…")
                CleanPhase.RESULT ->
                    if (lastClean != null) {
                        CleanResultLine(result = lastClean, progress = { countUp.value })
                    } else {
                        StatusText("")
                    }
                CleanPhase.IDLE -> StatusText("Close cached apps to free RAM")
            }
        }
        FreeRamButton(running = ramClean.running, onClick = onFreeRam)
    }
}

@Composable
private fun StatusText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
    )
}

/** "Freed ≈ N MB", with N counting up as [progress] runs from 0 to 1. Only this line recomposes while it counts. */
@Composable
private fun CleanResultLine(result: CleanResult, progress: () -> Float) {
    val text = if (result.freedMb > 0) {
        val shown = (result.freedMb * progress()).toLong()
        "Freed ≈ $shown MB · ${result.appsChecked} apps"
    } else {
        "Already clean · ${result.appsChecked} apps"
    }
    StatusText(text)
}

@Composable
private fun FreeRamButton(running: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 14.dp),
        modifier = Modifier.height(36.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(16.dp)) {
            Crossfade(targetState = running, label = "freeRamIcon") { busy ->
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    BoltMark(
                        modifier = Modifier.size(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        Text("Free RAM")
    }
}
