package com.bru.gameboost.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import com.bru.gameboost.domain.ForegroundAppMonitor

/**
 * Reads the most recent MOVE_TO_FOREGROUND event in a short trailing window
 * to answer "what's in front right now" — the same Usage Access capability
 * (and the same AppOpsManager grant check) SystemMonitor already uses.
 */
class ForegroundAppMonitorImpl(private val context: Context) : ForegroundAppMonitor {

    private val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    @Suppress("DEPRECATION")
    override fun isAccessGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    override fun currentForegroundPackage(): String? {
        if (!isAccessGranted()) return null
        return runCatching {
            val end = System.currentTimeMillis()
            val events = usageStatsManager.queryEvents(end - QUERY_WINDOW_MS, end)
            val event = UsageEvents.Event()
            var lastResumedPackage: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    lastResumedPackage = event.packageName
                }
            }
            lastResumedPackage
        }.getOrNull()
    }

    private companion object {
        const val QUERY_WINDOW_MS = 60_000L
    }
}
