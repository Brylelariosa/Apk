package com.bru.gameboost.data.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.bru.gameboost.domain.model.ConnectionType
import com.bru.gameboost.domain.model.NetworkStatus

/**
 * Reads which network is active from ConnectivityManager (normal permission, no location or phone
 * access) and times the internet over exactly that network — VPN included — so the ping is for the
 * route the game really uses.
 */
class ConnectivityNetworkSampler(
    context: Context,
    private val probe: LatencyProbe = LatencyProbe()
) : NetworkSampler {

    private val connectivity: ConnectivityManager? =
        context.applicationContext.getSystemService(ConnectivityManager::class.java)

    override suspend fun sample(): NetworkStatus? {
        val manager = connectivity ?: return null
        return try {
            val network = manager.activeNetwork ?: return NetworkStatus.Offline
            val caps = manager.getNetworkCapabilities(network) ?: return NetworkStatus.Offline
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return NetworkStatus.Offline
            NetworkStatus.Online(connectionType(caps), probe.measure(network.socketFactory))
        } catch (e: SecurityException) {
            null // ACCESS_NETWORK_STATE missing or revoked
        }
    }

    // Wi-Fi and mobile data are checked before VPN: a VPN that reports its underlying network
    // is more usefully labelled by that network.
    private fun connectionType(caps: NetworkCapabilities): ConnectionType = when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnectionType.WIFI
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> ConnectionType.MOBILE_DATA
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> ConnectionType.ETHERNET
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> ConnectionType.VPN
        else -> ConnectionType.OTHER
    }
}
