package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.BoostSettings
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.DeviceSnapshot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/** Polls system-wide, non-root device stats for the live boost notification. */
interface DeviceStatsRepository {
    fun observeSnapshot(intervalMs: Long): Flow<DeviceSnapshot>
}

/** The user's saved "games to boost" list, plus the full launchable-app catalog to pick from. */
interface GameRepository {
    fun observeAddedGames(): Flow<List<BoostableGame>>
    suspend fun queryLaunchableApps(): List<BoostableGame>
    suspend fun addGame(game: BoostableGame)
    suspend fun removeGame(packageName: String)
}

/** Persisted on/off switches for the individual steps of a boost. */
interface SettingsRepository {
    val settings: StateFlow<BoostSettings>
    fun setSilenceNotifications(enabled: Boolean)
    fun setFreeRamOnBoost(enabled: Boolean)
    fun setKeepWifiFast(enabled: Boolean)
    fun setOverheatAlertC(celsius: Float)
}

/**
 * Asks the system to drop cached background processes of other apps, via the
 * unprivileged KILL_BACKGROUND_PROCESSES route (not force-stop, no root or
 * Shizuku). Apps running a foreground service — music, calls, downloads —
 * aren't background processes, so the OS leaves them alone.
 */
interface MemoryCleaner {
    suspend fun cleanBackground(protectedPackages: Set<String>): CleanResult
}

/**
 * Applies and reverts the Do-Not-Disturb boost. Reading [isAccessGranted] before
 * [applyBoost] is the caller's job — this class doesn't request the permission itself.
 */
interface DndController {
    fun isAccessGranted(): Boolean
    fun applyBoost()
    fun revertBoost()
}

/**
 * Applies and reverts the Wi-Fi half of a boost by asking the platform to keep Wi-Fi out of its
 * power-saving mode, so packets aren't held back between bursts. Nothing an unprivileged app can
 * do speeds up a mobile-data link (that comes down to signal and carrier), so on mobile data
 * both calls are harmless no-ops. Both are idempotent and safe to call from any thread.
 */
interface NetworkBooster {
    fun applyBoost()
    fun revertBoost()
}

/**
 * Watches which app is in the foreground so a session can end itself once the
 * user has actually left the boosted game, without needing a persistent overlay.
 */
interface ForegroundAppMonitor {
    fun isAccessGranted(): Boolean

    /** A fresh tracker per session, so no state leaks from one session into the next. */
    fun newTracker(): ForegroundTracker
}

/** Incremental foreground tracking; [poll] belongs to exactly one polling loop. */
interface ForegroundTracker {
    /** The package in front as of now, or null when none is known (e.g. screen off). */
    fun poll(): String?
}
