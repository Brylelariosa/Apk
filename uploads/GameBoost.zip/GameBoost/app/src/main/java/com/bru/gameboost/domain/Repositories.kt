package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import kotlinx.coroutines.flow.Flow

/** Polls system-wide, non-root device stats for the live boost notification. */
interface DeviceStatsRepository {
    fun observeSnapshot(intervalMs: Long): Flow<DeviceSnapshot>
}

/** The user's saved "games to boost" list, plus the full launchable-app catalog to pick from. */
interface GameRepository {
    fun observeAddedGames(): Flow<List<BoostableGame>>
    suspend fun queryLaunchableApps(): List<BoostableGame>
    suspend fun addGame(game: BoostableGame)
    suspend fun removeGame(packageName: String)
}

/**
 * Applies and reverts the Do-Not-Disturb boost. Reading [isAccessGranted] before
 * [applyBoost] is the caller's job — this class doesn't request the permission itself.
 */
interface DndController {
    fun isAccessGranted(): Boolean
    fun applyBoost()
    fun revertBoost()
}

/**
 * Watches which app is in the foreground so a session can end itself once the
 * user has actually left the boosted game, without needing a persistent overlay.
 */
interface ForegroundAppMonitor {
    fun isAccessGranted(): Boolean
    fun currentForegroundPackage(): String?
}
