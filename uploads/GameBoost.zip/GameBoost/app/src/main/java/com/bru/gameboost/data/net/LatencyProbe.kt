package com.bru.gameboost.data.net

import com.bru.gameboost.domain.model.Latency
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import java.io.IOException
import java.net.InetSocketAddress
import javax.net.SocketFactory
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Times TCP handshakes to well-known, always-up public servers. Apps can't send ICMP pings
 * without root, but opening a connection costs exactly one round trip (SYN out, SYN-ACK back),
 * so the handshake time *is* the round-trip time. Nothing is sent over the connection: it is
 * closed the moment it opens.
 *
 * Servers are addressed by IP literal on purpose. A hostname would add a DNS lookup to every
 * measurement, and the probe would fail whenever only DNS is broken.
 *
 * Blocking, so call it from Dispatchers.IO. Every connect is bounded by [timeoutMs], and
 * cancellation is honoured between connects.
 */
class LatencyProbe(
    private val endpoints: List<Endpoint> = DEFAULT_ENDPOINTS,
    private val samplesPerRound: Int = SAMPLES_PER_ROUND,
    private val timeoutMs: Int = CONNECT_TIMEOUT_MS
) {
    data class Endpoint(val label: String, val ip: String, val port: Int)

    /**
     * Measures against the first endpoint that answers. [factory] decides which network the
     * packets leave on, so the figure describes the same path the game's traffic takes.
     */
    suspend fun measure(factory: SocketFactory): Latency {
        for (endpoint in endpoints) {
            currentCoroutineContext().ensureActive()
            val first = connectMillis(factory, endpoint) ?: continue

            val samples = ArrayList<Int>(samplesPerRound)
            samples.add(first)
            repeat(samplesPerRound - 1) {
                // A short gap so the burst samples the link over time instead of one instant.
                delay(SAMPLE_GAP_MS)
                connectMillis(factory, endpoint)?.let { samples.add(it) }
            }
            return Latency.Measured(
                medianMs = LatencyStats.median(samples),
                jitterMs = LatencyStats.jitter(samples),
                lost = samplesPerRound - samples.size,
                host = endpoint.label
            )
        }
        return Latency.Unreachable
    }

    /** One handshake in whole milliseconds, or null if it failed or timed out. */
    private fun connectMillis(factory: SocketFactory, endpoint: Endpoint): Int? {
        val socket = try {
            factory.createSocket()
        } catch (e: IOException) {
            return null
        }
        return try {
            val startNs = System.nanoTime()
            socket.connect(InetSocketAddress(endpoint.ip, endpoint.port), timeoutMs)
            val elapsedNs = System.nanoTime() - startNs
            ((elapsedNs + HALF_MS_IN_NS) / NS_PER_MS).toInt().coerceAtLeast(1)
        } catch (e: IOException) {
            null
        } catch (e: SecurityException) {
            null // INTERNET permission missing: no answer, not a crash in the stats loop
        } finally {
            runCatching { socket.close() }
        }
    }

    companion object {
        // Anycast public resolvers with a TCP 443 listener: close to almost every user, and
        // fine with a bare handshake. Tried in order until one answers.
        val DEFAULT_ENDPOINTS = listOf(
            Endpoint("Cloudflare", "1.1.1.1", 443),
            Endpoint("Google", "8.8.8.8", 443),
            Endpoint("Quad9", "9.9.9.9", 443)
        )
        const val SAMPLES_PER_ROUND = 3
        const val CONNECT_TIMEOUT_MS = 1_200
        private const val SAMPLE_GAP_MS = 150L
        private const val NS_PER_MS = 1_000_000L
        private const val HALF_MS_IN_NS = 500_000L
    }
}

/** The number-crunching behind [LatencyProbe], kept apart so it can be unit-tested without a socket. */
internal object LatencyStats {

    /** The middle sample; for an even count, the mean of the two middle ones. Needs a non-empty list. */
    fun median(samples: List<Int>): Int {
        val sorted = samples.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[mid] else (sorted[mid - 1] + sorted[mid]) / 2
    }

    /** Mean absolute difference between consecutive samples, in the order taken; 0 for a single sample. */
    fun jitter(samples: List<Int>): Int {
        if (samples.size < 2) return 0
        return samples.zipWithNext { a, b -> abs(b - a) }.average().roundToInt()
    }
}
