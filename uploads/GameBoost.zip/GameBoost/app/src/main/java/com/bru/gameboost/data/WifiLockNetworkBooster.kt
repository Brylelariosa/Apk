package com.bru.gameboost.data

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import com.bru.gameboost.domain.NetworkBooster

/**
 * Holds a Wi-Fi lock for the length of a boost so the Wi-Fi radio isn't dropped into power-save
 * between packets — power-save is what makes a Wi-Fi ping bounce. It acts only while the phone is
 * on Wi-Fi; on mobile data there is nothing for the lock to hold, so it is a harmless no-op.
 *
 * Before Android 14 the high-performance mode works from the background, which is where a booster
 * lives while the game is in front. From Android 14 the platform only offers its low-latency mode,
 * and reportedly honours it only while the holding app is visible, so there the lock may do
 * little. A held lock dies with the process, so nothing needs persisting.
 */
class WifiLockNetworkBooster(context: Context) : NetworkBooster {

    private val wifiManager = context.applicationContext
        .getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private var lock: WifiManager.WifiLock? = null

    @Synchronized
    override fun applyBoost() {
        val manager = wifiManager ?: return
        val wifiLock = lock ?: runCatching {
            manager.createWifiLock(lockMode(), LOCK_TAG).apply { setReferenceCounted(false) }
        }.getOrNull() ?: return
        lock = wifiLock
        // acquire() can throw (too many locks held, WAKE_LOCK revoked); a missing lock must
        // never stop the boost itself.
        if (!wifiLock.isHeld) runCatching { wifiLock.acquire() }
    }

    /** Idempotent: does nothing unless the lock is currently held. */
    @Synchronized
    override fun revertBoost() {
        val wifiLock = lock ?: return
        if (wifiLock.isHeld) runCatching { wifiLock.release() }
    }

    @Suppress("DEPRECATION") // HIGH_PERF is deprecated from API 34, but it is the mode that works before that
    private fun lockMode(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }

    private companion object {
        const val LOCK_TAG = "GameBoost:wifi-boost"
    }
}
