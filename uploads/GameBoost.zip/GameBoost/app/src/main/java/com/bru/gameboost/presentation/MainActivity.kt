package com.bru.gameboost.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.bru.gameboost.presentation.screens.AddGameScreen
import com.bru.gameboost.presentation.screens.GamePickerScreen
import com.bru.gameboost.presentation.theme.GameBoostTheme

private sealed interface Screen {
    data object GamePicker : Screen
    data object AddGame : Screen
}

class MainActivity : ComponentActivity() {

    private val viewModel: GameBoostViewModel by viewModels {
        GameBoostViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProvideLifecycleOwnerCompat {
                GameBoostTheme {
                    var screen by remember { mutableStateOf<Screen>(Screen.GamePicker) }
                    when (screen) {
                        Screen.GamePicker -> GamePickerScreen(
                            viewModel = viewModel,
                            onAddGameClick = { screen = Screen.AddGame }
                        )
                        Screen.AddGame -> AddGameScreen(
                            viewModel = viewModel,
                            onDone = { screen = Screen.GamePicker }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // The DND / usage-access grants happen in a separate Settings screen,
        // so this is the reliable point to notice the user came back from it.
        viewModel.refreshPermissionState()
    }
}
