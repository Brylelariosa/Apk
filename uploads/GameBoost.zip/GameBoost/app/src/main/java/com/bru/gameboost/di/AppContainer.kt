package com.bru.gameboost.di

import android.content.Context
import com.bru.gameboost.data.DeviceStatsRepositoryImpl
import com.bru.gameboost.data.DndControllerImpl
import com.bru.gameboost.data.ForegroundAppMonitorImpl
import com.bru.gameboost.data.GameRepositoryImpl
import com.bru.gameboost.domain.BoostSessionStateHolder
import com.bru.gameboost.domain.DeviceStatsRepository
import com.bru.gameboost.domain.DndController
import com.bru.gameboost.domain.ForegroundAppMonitor
import com.bru.gameboost.domain.GameRepository

/**
 * Minimal manual DI container. A small utility app doesn't warrant a DI
 * framework; this keeps object construction centralized and swappable for
 * tests without adding Hilt/Koin as a build dependency.
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val gameRepository: GameRepository by lazy { GameRepositoryImpl(appContext) }
    val deviceStatsRepository: DeviceStatsRepository by lazy { DeviceStatsRepositoryImpl(appContext) }
    val dndController: DndController by lazy { DndControllerImpl(appContext) }
    val foregroundAppMonitor: ForegroundAppMonitor by lazy { ForegroundAppMonitorImpl(appContext) }
    val sessionStateHolder: BoostSessionStateHolder by lazy { BoostSessionStateHolder() }
}
