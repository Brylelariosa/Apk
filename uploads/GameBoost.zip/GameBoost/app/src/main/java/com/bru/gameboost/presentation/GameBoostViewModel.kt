package com.bru.gameboost.presentation

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bru.gameboost.GameBoostApp
import com.bru.gameboost.domain.BoostSessionStateHolder
import com.bru.gameboost.domain.DeviceStatsRepository
import com.bru.gameboost.domain.DndController
import com.bru.gameboost.domain.ForegroundAppMonitor
import com.bru.gameboost.domain.GameRepository
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.PermissionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GameBoostViewModel(
    application: Application,
    private val gameRepository: GameRepository,
    deviceStatsRepository: DeviceStatsRepository,
    private val dndController: DndController,
    private val foregroundAppMonitor: ForegroundAppMonitor,
    sessionStateHolder: BoostSessionStateHolder
) : AndroidViewModel(application) {

    val addedGames: StateFlow<List<BoostableGame>> = gameRepository.observeAddedGames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val sessionState: StateFlow<BoostSessionState> = sessionStateHolder.state

    /** Light in-app preview so the picker screen isn't blank before boosting. */
    val deviceSnapshot: StateFlow<DeviceSnapshot?> = deviceStatsRepository
        .observeSnapshot(PREVIEW_INTERVAL_MS)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _permissionState = MutableStateFlow(readPermissionState())
    val permissionState: StateFlow<PermissionState> = _permissionState.asStateFlow()

    /** Call from Activity.onResume — permissions are granted in a separate Settings screen. */
    fun refreshPermissionState() {
        _permissionState.value = readPermissionState()
    }

    fun addGame(game: BoostableGame) = viewModelScope.launch { gameRepository.addGame(game) }

    fun removeGame(packageName: String) = viewModelScope.launch { gameRepository.removeGame(packageName) }

    suspend fun queryLaunchableApps(): List<BoostableGame> = gameRepository.queryLaunchableApps()

    fun boostAndLaunch(game: BoostableGame) {
        val context = getApplication<GameBoostApp>()
        val intent = Intent(context, BoostSessionService::class.java).apply {
            action = BoostSessionService.ACTION_START
            putExtra(BoostSessionService.EXTRA_PACKAGE_NAME, game.packageName)
            putExtra(BoostSessionService.EXTRA_LABEL, game.label)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun endBoost() {
        val context = getApplication<GameBoostApp>()
        context.startService(Intent(context, BoostSessionService::class.java).apply {
            action = BoostSessionService.ACTION_STOP
        })
    }

    private fun readPermissionState(): PermissionState {
        val context = getApplication<GameBoostApp>()
        val postNotificationsGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        return PermissionState(
            notificationPolicyAccessGranted = dndController.isAccessGranted(),
            usageAccessGranted = foregroundAppMonitor.isAccessGranted(),
            postNotificationsGranted = postNotificationsGranted
        )
    }

    private companion object {
        const val PREVIEW_INTERVAL_MS = 3_000L
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val container = (application as GameBoostApp).container
            return GameBoostViewModel(
                application = application,
                gameRepository = container.gameRepository,
                deviceStatsRepository = container.deviceStatsRepository,
                dndController = container.dndController,
                foregroundAppMonitor = container.foregroundAppMonitor,
                sessionStateHolder = container.sessionStateHolder
            ) as T
        }
    }
}
