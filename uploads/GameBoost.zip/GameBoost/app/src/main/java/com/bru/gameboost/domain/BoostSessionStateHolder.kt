package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostableGame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The single shared source of truth for "is a boost active, and for which
 * game". BoostSessionService writes to it; GameBoostViewModel only reads it —
 * neither class references the other directly, so the service can keep
 * running (and the notification stays authoritative) whether or not an
 * Activity is currently alive to observe it.
 */
class BoostSessionStateHolder {

    private val _state = MutableStateFlow<BoostSessionState>(BoostSessionState.Idle)
    val state: StateFlow<BoostSessionState> = _state.asStateFlow()

    fun setActive(game: BoostableGame) {
        _state.value = BoostSessionState.Active(game)
    }

    fun setIdle() {
        _state.value = BoostSessionState.Idle
    }
}
