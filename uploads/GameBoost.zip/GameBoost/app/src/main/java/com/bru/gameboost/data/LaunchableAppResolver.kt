package com.bru.gameboost.data

import android.content.Intent
import android.content.pm.PackageManager
import com.bru.gameboost.domain.model.BoostableGame

/**
 * Lists launchable apps via the CATEGORY_LAUNCHER query declared in the
 * manifest's <queries> block — deliberately not QUERY_ALL_PACKAGES, which
 * Play gates behind a declaration form this app has no need to file.
 */
class LaunchableAppResolver(private val packageManager: PackageManager) {

    @Suppress("DEPRECATION")
    fun queryLaunchableApps(): List<BoostableGame> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(launcherIntent, 0)
            .mapNotNull { resolveInfo ->
                val packageName = resolveInfo.activityInfo?.packageName ?: return@mapNotNull null
                val label = runCatching { resolveInfo.loadLabel(packageManager).toString() }
                    .getOrNull() ?: return@mapNotNull null
                BoostableGame(packageName, label)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
