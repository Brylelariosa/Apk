package com.bru.gameboost.presentation.screens

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.PermissionState
import com.bru.gameboost.domain.model.ThermalStatus
import com.bru.gameboost.presentation.GameBoostViewModel
import kotlin.math.roundToInt

@Composable
fun GamePickerScreen(
    viewModel: GameBoostViewModel,
    onAddGameClick: () -> Unit
) {
    val context = LocalContext.current
    val games by viewModel.addedGames.collectAsStateWithLifecycle()
    val permissionState by viewModel.permissionState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val snapshot by viewModel.deviceSnapshot.collectAsStateWithLifecycle()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshPermissionState() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("GameBoost") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddGameClick) {
                Icon(Icons.Default.Add, contentDescription = "Add game")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { DeviceStatsCard(snapshot) }

            if (!permissionState.allGranted) {
                item {
                    PermissionsCard(
                        state = permissionState,
                        onRequestNotifications = {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        },
                        onOpenDndSettings = {
                            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        },
                        onOpenUsageSettings = {
                            context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                        }
                    )
                }
            }

            val activeGamePackage = (sessionState as? BoostSessionState.Active)?.game?.packageName
            if (sessionState is BoostSessionState.Active) {
                item {
                    ActiveSessionCard(
                        game = (sessionState as BoostSessionState.Active).game,
                        onEndBoost = viewModel::endBoost
                    )
                }
            }

            if (games.isEmpty()) {
                item { EmptyGamesHint() }
            } else {
                items(games, key = { it.packageName }) { game ->
                    GameRow(
                        game = game,
                        isBoosting = game.packageName == activeGamePackage,
                        onBoostClick = { viewModel.boostAndLaunch(game) },
                        onRemoveClick = { viewModel.removeGame(game.packageName) }
                    )
                }
            }
        }
    }
}

private val PermissionState.allGranted: Boolean
    get() = notificationPolicyAccessGranted && usageAccessGranted && postNotificationsGranted

@Composable
private fun DeviceStatsCard(snapshot: DeviceSnapshot?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("This device right now", style = MaterialTheme.typography.titleMedium)
            Text(
                formatSnapshotLine(snapshot),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun PermissionsCard(
    state: PermissionState,
    onRequestNotifications: () -> Unit,
    onOpenDndSettings: () -> Unit,
    onOpenUsageSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("A few permissions unlock more of this", style = MaterialTheme.typography.titleMedium)
            Text(
                "Everything works without them too — boosting just does less.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            if (!state.postNotificationsGranted) {
                PermissionRow("Show the live boost notification", onRequestNotifications)
            }
            if (!state.notificationPolicyAccessGranted) {
                PermissionRow("Do Not Disturb access (silences alerts while boosting)", onOpenDndSettings)
            }
            if (!state.usageAccessGranted) {
                PermissionRow("Usage access (ends the boost automatically when you quit)", onOpenUsageSettings)
            }
        }
    }
}

@Composable
private fun PermissionRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(end = 8.dp))
        TextButton(onClick = onClick) { Text("Grant") }
    }
}

@Composable
private fun ActiveSessionCard(game: BoostableGame, onEndBoost: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Boosting ${game.label}", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onEndBoost) { Text("End") }
        }
    }
}

@Composable
private fun EmptyGamesHint() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No games added yet", style = MaterialTheme.typography.titleMedium)
        Text(
            "Tap + to pick one from your installed apps.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun GameRow(
    game: BoostableGame,
    isBoosting: Boolean,
    onBoostClick: () -> Unit,
    onRemoveClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                game.label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(end = 8.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onBoostClick, enabled = !isBoosting) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Text(if (isBoosting) " Boosting" else " Boost", modifier = Modifier.padding(start = 4.dp))
                }
                IconButton(onClick = onRemoveClick) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove ${game.label}")
                }
            }
        }
    }
}

private fun formatSnapshotLine(snapshot: DeviceSnapshot?): String {
    if (snapshot == null) return "Reading…"
    val cpu = snapshot.cpuLoadPercent?.let { "CPU ${it.roundToInt()}%" } ?: "CPU —"
    val ram = if (snapshot.ramUsedMb != null && snapshot.ramTotalMb != null) {
        "RAM ${snapshot.ramUsedMb}/${snapshot.ramTotalMb}MB"
    } else "RAM —"
    val battery = snapshot.batteryPercent?.let { "Battery $it%" } ?: "Battery —"
    val thermal = snapshot.thermalStatus
        ?.takeIf { it != ThermalStatus.UNKNOWN }
        ?.let { " · Thermal ${it.name.lowercase()}" }
        ?: ""
    return "$cpu · $ram · $battery$thermal"
}
