package com.bru.gameboost.presentation.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostSettings
import com.bru.gameboost.domain.model.BoostStage
import com.bru.gameboost.domain.model.PermissionState
import com.bru.gameboost.presentation.GameBoostViewModel
import com.bru.gameboost.presentation.SnapshotFormatter
import com.bru.gameboost.presentation.components.AddGameTile
import com.bru.gameboost.presentation.components.AppIcon
import com.bru.gameboost.presentation.components.BoltMark
import com.bru.gameboost.presentation.components.BoostPulse
import com.bru.gameboost.presentation.components.BoostingOverlay
import com.bru.gameboost.presentation.components.GameTile
import com.bru.gameboost.presentation.components.IconLoader
import com.bru.gameboost.presentation.components.PulsingDot
import com.bru.gameboost.presentation.components.StatDetails
import com.bru.gameboost.presentation.components.StatStrip
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

// A tile is at least this wide; the grid fits as many columns as the screen allows (three on most phones).
private val TileMinWidth = 96.dp

// Stats, banners and headings take the whole row; only the game tiles share one.
private val FullSpan: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }

// The tile entrance plays while the screen first appears. Tiles that scroll in after this skip it.
private const val ENTRANCE_WINDOW_MS = 900L

// One slider stop per whole degree between the alert bounds.
private val OverheatSliderSteps =
    (BoostSettings.MAX_OVERHEAT_ALERT_C - BoostSettings.MIN_OVERHEAT_ALERT_C).roundToInt() - 1

@Composable
fun GamePickerScreen(
    viewModel: GameBoostViewModel,
    onAddGameClick: () -> Unit
) {
    val context = LocalContext.current
    val games by viewModel.addedGames.collectAsStateWithLifecycle()
    val permissionState by viewModel.permissionState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val snapshot by viewModel.deviceSnapshot.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val ramClean by viewModel.ramClean.collectAsStateWithLifecycle()
    val loadIcon = viewModel.iconLoader

    var showSettings by rememberSaveable { mutableStateOf(false) }
    var statsExpanded by rememberSaveable { mutableStateOf(false) }

    var entranceDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(ENTRANCE_WINDOW_MS)
        entranceDone = true
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshPermissionState() }

    val requestNotifications: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // No runtime prompt exists before Android 13; the switch lives in Settings.
            context.openNotificationSettings()
        }
    }

    val activeState = sessionState as? BoostSessionState.Active
    // Only steps that will really happen: DND needs its access grant as well as the switch.
    val showSilenceStep = settings.silenceNotifications && permissionState.notificationPolicyAccessGranted
    val showCleanStep = settings.freeRamOnBoost
    // The sequence overlay covers only the start-up stages, and only when there is something to
    // show: with both optional steps off the launch is instant and a flash of dimming would just look glitchy.
    val overlayVisible = activeState != null &&
        activeState.stage != BoostStage.ACTIVE &&
        (showSilenceStep || showCleanStep)
    val currentSnapshot = snapshot

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                PickerTopBar(
                    showPermissionBadge = !permissionState.allGranted,
                    onSettingsClick = { showSettings = true }
                )
            }
        ) { padding ->
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = TileMinWidth),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(start = 16.dp, top = 4.dp, end = 16.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (activeState != null) {
                    item(key = "active", span = FullSpan) {
                        ActiveBanner(
                            state = activeState,
                            loadIcon = loadIcon,
                            onEndBoost = viewModel::endBoost,
                            modifier = Modifier.animateItem()
                        )
                    }
                }

                item(key = "stats", span = FullSpan) {
                    StatStrip(
                        snapshot = currentSnapshot,
                        alertAtC = settings.overheatAlertC,
                        ramClean = ramClean,
                        expanded = statsExpanded,
                        onToggleExpanded = { statsExpanded = !statsExpanded },
                        onFreeRam = viewModel::freeRamNow,
                        onOpenBatterySaver = {
                            context.openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                        },
                        modifier = Modifier.animateItem()
                    )
                }

                if (statsExpanded && currentSnapshot != null) {
                    item(key = "stats_details", span = FullSpan) {
                        StatDetails(snapshot = currentSnapshot, modifier = Modifier.animateItem())
                    }
                }

                if (games.isEmpty()) {
                    item(key = "empty", span = FullSpan) {
                        EmptyGamesHint(onAddGameClick = onAddGameClick, modifier = Modifier.animateItem())
                    }
                } else {
                    item(key = "games_header", span = FullSpan) {
                        GamesHeader(modifier = Modifier.animateItem())
                    }
                    itemsIndexed(games, key = { _, game -> game.packageName }) { index, game ->
                        GameTile(
                            game = game,
                            isBoosting = game.packageName == activeState?.game?.packageName,
                            loadIcon = loadIcon,
                            entranceIndex = index,
                            playEntrance = !entranceDone,
                            onBoost = { viewModel.boostAndLaunch(game) },
                            onRemove = { viewModel.removeGame(game.packageName) },
                            modifier = Modifier.animateItem()
                        )
                    }
                    item(key = "add_game") {
                        AddGameTile(onClick = onAddGameClick, modifier = Modifier.animateItem())
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = overlayVisible,
            enter = fadeIn(animationSpec = tween(160)),
            exit = fadeOut(animationSpec = tween(260))
        ) {
            if (activeState != null) {
                BoostingOverlay(
                    state = activeState,
                    showSilenceStep = showSilenceStep,
                    showCleanStep = showCleanStep,
                    loadIcon = loadIcon
                )
            }
        }
    }

    if (showSettings) {
        SettingsSheet(
            settings = settings,
            permissionState = permissionState,
            onDismiss = { showSettings = false },
            onRequestNotifications = requestNotifications,
            onOpenDndSettings = {
                context.openSettings(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            },
            onOpenUsageSettings = { context.openUsageAccessSettings() },
            onSilenceNotificationsChange = viewModel::setSilenceNotifications,
            onFreeRamChange = viewModel::setFreeRamOnBoost,
            onKeepWifiFastChange = viewModel::setKeepWifiFast,
            onOverheatAlertChange = viewModel::setOverheatAlertC
        )
    }
}

private val PermissionState.allGranted: Boolean
    get() = notificationPolicyAccessGranted && usageAccessGranted && notificationsEnabled

/** A slim title bar: 48 dp instead of the stock 64, because every dp up here is a dp less of games. */
@Composable
private fun PickerTopBar(showPermissionBadge: Boolean, onSettingsClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(48.dp)
            .padding(start = 20.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BoltMark(modifier = Modifier.size(20.dp))
        Text(
            text = "GameBoost",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )
        IconButton(onClick = onSettingsClick) {
            // The dot says "a permission is still missing" without spending a whole card on it.
            BadgedBox(badge = { if (showPermissionBadge) Badge() }) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }
    }
}

@Composable
private fun GamesHeader(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 4.dp, top = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Text("Your games", style = MaterialTheme.typography.titleMedium)
        Text(
            "Tap to boost · hold to remove",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** The running boost as one slim banner: who, which stage, how much was freed, and the way out. */
@Composable
private fun ActiveBanner(
    state: BoostSessionState.Active,
    loadIcon: IconLoader,
    onEndBoost: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cleanResult = state.cleanResult
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(52.dp)) {
                BoostPulse(modifier = Modifier.fillMaxSize())
                AppIcon(packageName = state.game.packageName, loadIcon = loadIcon, size = 34.dp)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PulsingDot()
                    AnimatedContent(
                        targetState = state.stage,
                        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                        label = "bannerStage"
                    ) { stage ->
                        Text(
                            text = stage.bannerLabel(),
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
                Text(
                    text = state.game.label,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (cleanResult != null) {
                    Text(
                        text = SnapshotFormatter.freedShort(cleanResult),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Button(
                onClick = onEndBoost,
                contentPadding = PaddingValues(horizontal = 16.dp),
                modifier = Modifier.height(36.dp)
            ) { Text("End") }
        }
    }
}

private fun BoostStage.bannerLabel(): String = when (this) {
    BoostStage.PREPARING -> "Preparing…"
    BoostStage.CLEANING -> "Freeing RAM…"
    BoostStage.LAUNCHING -> "Launching…"
    BoostStage.ACTIVE -> "Boost active"
}

/** Permissions and boost options, tucked behind the gear so they don't push the games off screen. */
@OptIn(ExperimentalMaterial3Api::class) // ModalBottomSheet
@Composable
private fun SettingsSheet(
    settings: BoostSettings,
    permissionState: PermissionState,
    onDismiss: () -> Unit,
    onRequestNotifications: () -> Unit,
    onOpenDndSettings: () -> Unit,
    onOpenUsageSettings: () -> Unit,
    onSilenceNotificationsChange: (Boolean) -> Unit,
    onFreeRamChange: (Boolean) -> Unit,
    onKeepWifiFastChange: (Boolean) -> Unit,
    onOverheatAlertChange: (Float) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 24.dp)
        ) {
            if (!permissionState.allGranted) {
                Text("A few permissions unlock more of this", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Everything works without them too — boosting just does less.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                )
                if (!permissionState.notificationsEnabled) {
                    PermissionRow("Show the live boost notification", onRequestNotifications)
                }
                if (!permissionState.notificationPolicyAccessGranted) {
                    PermissionRow("Do Not Disturb access (silences alerts while boosting)", onOpenDndSettings)
                }
                if (!permissionState.usageAccessGranted) {
                    PermissionRow("Usage access (ends the boost automatically when you quit)", onOpenUsageSettings)
                }
                Spacer(Modifier.height(16.dp))
            }

            Text("When boosting", style = MaterialTheme.typography.titleMedium)
            SwitchRow(
                label = "Silence notifications (Do Not Disturb)",
                checked = settings.silenceNotifications,
                onCheckedChange = onSilenceNotificationsChange
            )
            SwitchRow(
                label = "Free RAM first (closes cached background apps)",
                checked = settings.freeRamOnBoost,
                onCheckedChange = onFreeRamChange
            )
            SwitchRow(
                label = "Keep Wi-Fi at full speed (steadier ping on Wi-Fi)",
                checked = settings.keepWifiFast,
                onCheckedChange = onKeepWifiFastChange
            )
            Text(
                "Overheat alert at ${settings.overheatAlertC.roundToInt()}°C",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp)
            )
            Slider(
                value = settings.overheatAlertC,
                onValueChange = onOverheatAlertChange,
                valueRange = BoostSettings.MIN_OVERHEAT_ALERT_C..BoostSettings.MAX_OVERHEAT_ALERT_C,
                steps = OverheatSliderSteps
            )
            Text(
                "Battery temperature at which GameBoost warns you while boosting.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun PermissionRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(onClick = onClick) { Text("Grant") }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun EmptyGamesHint(onAddGameClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BoltMark(modifier = Modifier.size(56.dp))
        Text(
            "No games added yet",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 12.dp)
        )
        Text(
            "Pick one from your installed apps. GameBoost frees RAM, silences alerts and watches the heat while you play.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )
        Button(onClick = onAddGameClick, modifier = Modifier.padding(top = 16.dp)) {
            Text("Add a game")
        }
    }
}

/** Settings screens differ by OEM; a missing one should do nothing rather than crash the app. */
private fun Context.openSettings(intent: Intent) {
    runCatching { startActivity(intent) }
}

private fun Context.openUsageAccessSettings() {
    // Android 10+ can jump straight to this app's toggle; fall back to the full list where that isn't honored.
    val forThisApp = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.fromParts("package", packageName, null))
    if (runCatching { startActivity(forThisApp) }.isFailure) {
        openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}

private fun Context.openNotificationSettings() {
    openSettings(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    )
}
