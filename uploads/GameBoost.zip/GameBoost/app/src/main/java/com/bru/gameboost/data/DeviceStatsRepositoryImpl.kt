package com.bru.gameboost.data

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.bru.gameboost.domain.DeviceStatsRepository
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.ThermalStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class DeviceStatsRepositoryImpl(
    context: Context,
    private val cpuLoadReader: CpuLoadReader = CpuLoadReader()
) : DeviceStatsRepository {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    override fun observeSnapshot(intervalMs: Long): Flow<DeviceSnapshot> = flow {
        var previousCpuTimes = cpuLoadReader.readTimes()

        while (true) {
            delay(intervalMs)

            val currentCpuTimes = cpuLoadReader.readTimes()
            val cpuLoad = if (previousCpuTimes != null && currentCpuTimes != null) {
                cpuLoadReader.percentBetween(previousCpuTimes, currentCpuTimes)
            } else null
            previousCpuTimes = currentCpuTimes

            val ram = readRam()

            emit(
                DeviceSnapshot(
                    cpuLoadPercent = cpuLoad,
                    ramUsedMb = ram?.usedMb,
                    ramTotalMb = ram?.totalMb,
                    batteryPercent = readBatteryPercent(),
                    thermalStatus = readThermalStatus()
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    private data class RamReading(val usedMb: Long, val totalMb: Long)

    private fun readRam(): RamReading? = runCatching {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val usedMb = totalMb - (info.availMem / (1024 * 1024))
        RamReading(usedMb, totalMb)
    }.getOrNull()

    private fun readBatteryPercent(): Int? = runCatching {
        batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            .takeIf { it in 0..100 }
    }.getOrNull()

    // PowerManager.getCurrentThermalStatus is API 29+; older devices just
    // never show a thermal row rather than a fabricated reading.
    private fun readThermalStatus(): ThermalStatus? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val pm = powerManager ?: return null
        return runCatching {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
                PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
                else -> ThermalStatus.UNKNOWN
            }
        }.getOrElse { ThermalStatus.UNKNOWN }
    }
}
