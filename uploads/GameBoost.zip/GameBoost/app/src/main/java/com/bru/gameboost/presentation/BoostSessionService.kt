package com.bru.gameboost.presentation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.bru.gameboost.GameBoostApp
import com.bru.gameboost.R
import com.bru.gameboost.di.AppContainer
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.ThermalStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Owns one boost session end-to-end: apply DND, launch the game, keep a
 * live-updating notification (the "overlay" for this app — no
 * SYSTEM_ALERT_WINDOW needed), and end the session either manually (the
 * notification action) or automatically once the user has genuinely left
 * the game, detected via Usage Access rather than a persistent bubble.
 */
class BoostSessionService : Service() {

    private lateinit var container: AppContainer
    private var sessionScope: CoroutineScope? = null

    override fun onCreate() {
        super.onCreate()
        container = (application as GameBoostApp).container
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME)
                val label = intent.getStringExtra(EXTRA_LABEL)
                if (packageName != null && label != null) {
                    startSession(BoostableGame(packageName, label))
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> endSession()
            else -> if (sessionScope == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startSession(game: BoostableGame) {
        if (sessionScope != null) return // a session is already running; ignore re-entrant starts

        container.sessionStateHolder.setActive(game)
        startForeground(NOTIFICATION_ID, buildNotification(game, snapshot = null))
        container.dndController.applyBoost()
        launchGame(game)

        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        sessionScope = scope

        scope.launch {
            container.deviceStatsRepository.observeSnapshot(STATS_INTERVAL_MS).collect { snapshot ->
                notificationManager.notify(NOTIFICATION_ID, buildNotification(game, snapshot))
            }
        }

        scope.launch {
            var consecutiveTicksAway = 0
            while (isActive) {
                delay(WATCH_INTERVAL_MS)
                if (!container.foregroundAppMonitor.isAccessGranted()) continue // manual-end only
                val foregroundPackage = container.foregroundAppMonitor.currentForegroundPackage()
                consecutiveTicksAway = if (foregroundPackage == game.packageName) 0 else consecutiveTicksAway + 1
                if (consecutiveTicksAway >= AWAY_TICKS_BEFORE_AUTO_END) {
                    endSession()
                }
            }
        }
    }

    private fun launchGame(game: BoostableGame) {
        val launchIntent = packageManager.getLaunchIntentForPackage(game.packageName) ?: return
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(launchIntent) }
    }

    private fun endSession() {
        container.dndController.revertBoost()
        container.sessionStateHolder.setIdle()
        sessionScope?.cancel()
        sessionScope = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        // Safety net if the process is killed without going through endSession
        // (e.g. system memory pressure) — still revert DND rather than leave
        // notifications silenced with no way back short of the Settings app.
        if (sessionScope != null) {
            container.dndController.revertBoost()
            container.sessionStateHolder.setIdle()
            sessionScope?.cancel()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private val notificationManager: NotificationManager
        get() = getSystemService(NotificationManager::class.java)

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Boost session",
            NotificationManager.IMPORTANCE_LOW // no sound/heads-up for a stats readout
        )
        notificationManager.createNotificationChannel(channel)
    }

    private fun buildNotification(game: BoostableGame, snapshot: DeviceSnapshot?): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, BoostSessionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Boosting ${game.label}")
            .setContentText(formatSnapshot(snapshot))
            .setSmallIcon(R.drawable.ic_notification_boost)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "End boost", stopIntent)
            .build()
    }

    private fun formatSnapshot(snapshot: DeviceSnapshot?): String {
        if (snapshot == null) return "Starting up…"
        val cpu = snapshot.cpuLoadPercent?.let { "CPU ${it.roundToInt()}%" } ?: "CPU —"
        val ram = if (snapshot.ramUsedMb != null && snapshot.ramTotalMb != null) {
            "RAM ${snapshot.ramUsedMb}/${snapshot.ramTotalMb}MB"
        } else "RAM —"
        val battery = snapshot.batteryPercent?.let { "Batt $it%" } ?: "Batt —"
        val thermal = snapshot.thermalStatus
            ?.takeIf { it != ThermalStatus.UNKNOWN }
            ?.let { " · ${it.name.lowercase()}" }
            ?: ""
        return "$cpu · $ram · $battery$thermal"
    }

    companion object {
        const val ACTION_START = "com.bru.gameboost.action.START"
        const val ACTION_STOP = "com.bru.gameboost.action.STOP"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_LABEL = "extra_label"

        private const val CHANNEL_ID = "boost_session"
        private const val NOTIFICATION_ID = 1001
        private const val STATS_INTERVAL_MS = 3_000L
        private const val WATCH_INTERVAL_MS = 5_000L
        private const val AWAY_TICKS_BEFORE_AUTO_END = 3 // ~15s grace before auto-ending
    }
}
