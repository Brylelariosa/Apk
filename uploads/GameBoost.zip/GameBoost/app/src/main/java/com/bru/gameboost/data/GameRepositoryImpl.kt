package com.bru.gameboost.data

import android.content.Context
import androidx.core.content.edit
import com.bru.gameboost.domain.GameRepository
import com.bru.gameboost.domain.model.BoostableGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class GameRepositoryImpl(
    private val context: Context,
    private val resolver: LaunchableAppResolver = LaunchableAppResolver(context.packageManager)
) : GameRepository {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val addedGames = MutableStateFlow(loadAddedGames())

    override fun observeAddedGames(): Flow<List<BoostableGame>> = addedGames.asStateFlow()

    override suspend fun queryLaunchableApps(): List<BoostableGame> =
        withContext(Dispatchers.IO) { resolver.queryLaunchableApps() }

    override suspend fun addGame(game: BoostableGame) = withContext(Dispatchers.IO) {
        val current = addedGames.value
        if (current.none { it.packageName == game.packageName }) {
            val updated = current + game
            persist(updated)
            addedGames.value = updated
        }
    }

    override suspend fun removeGame(packageName: String) = withContext(Dispatchers.IO) {
        val updated = addedGames.value.filterNot { it.packageName == packageName }
        persist(updated)
        addedGames.value = updated
    }

    private fun loadAddedGames(): List<BoostableGame> {
        val raw = prefs.getString(KEY_GAMES, null) ?: return emptyList()
        if (raw.isEmpty()) return emptyList()
        return raw.split(GAME_DELIMITER).mapNotNull { entry ->
            val parts = entry.split(FIELD_DELIMITER, limit = 2)
            if (parts.size == 2) BoostableGame(packageName = parts[0], label = parts[1]) else null
        }
    }

    private fun persist(games: List<BoostableGame>) {
        val raw = games.joinToString(GAME_DELIMITER) { "${it.packageName}$FIELD_DELIMITER${it.label}" }
        prefs.edit { putString(KEY_GAMES, raw) }
    }

    private companion object {
        const val PREFS_NAME = "gameboost_prefs"
        const val KEY_GAMES = "added_games"
        // Control characters, not visible punctuation, so an app label
        // containing a comma or semicolon can never corrupt the encoding.
        const val GAME_DELIMITER = "\u0001"
        const val FIELD_DELIMITER = "\u0002"
    }
}
