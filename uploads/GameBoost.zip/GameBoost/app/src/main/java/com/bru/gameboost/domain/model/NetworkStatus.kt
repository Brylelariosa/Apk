package com.bru.gameboost.domain.model

/**
 * The kind of network the phone's traffic leaves on, as far as Android tells an ordinary app.
 * [VPN] has its own entry because game-booster VPNs are common and they change what a latency
 * figure means.
 */
enum class ConnectionType { WIFI, MOBILE_DATA, ETHERNET, VPN, OTHER }

/**
 * Round-trip time to the internet. Apps can't send ICMP pings, so it is measured by timing TCP
 * handshakes — a handshake takes exactly one round trip.
 */
sealed interface Latency {
    /**
     * [medianMs] is the typical round trip over a short burst; [jitterMs] is how much consecutive
     * samples differed (the number that predicts lag spikes); [lost] is how many probes in the
     * burst got no answer (a rough packet-loss signal). [host] names the server that answered, so
     * the readout never passes itself off as the game server's own ping.
     */
    data class Measured(
        val medianMs: Int,
        val jitterMs: Int,
        val lost: Int,
        val host: String
    ) : Latency

    /** A network is up but nothing answered in time: a dead or badly congested link. */
    data object Unreachable : Latency
}

/** One tick of connectivity: no network at all, or a network and how fast the internet answers on it. */
sealed interface NetworkStatus {
    data object Offline : NetworkStatus
    data class Online(val type: ConnectionType, val latency: Latency) : NetworkStatus
}

/**
 * How a round-trip time feels in a competitive game. The thresholds are for ping to the
 * *internet*; a game server is further away, so the in-game number always reads a little higher.
 */
enum class PingQuality {
    GOOD, FAIR, POOR;

    companion object {
        const val GOOD_MAX_MS = 60
        const val FAIR_MAX_MS = 120

        fun of(pingMs: Int): PingQuality = when {
            pingMs <= GOOD_MAX_MS -> GOOD
            pingMs <= FAIR_MAX_MS -> FAIR
            else -> POOR
        }
    }
}

/** The measured round trip in ms, or null when there is no figure (still measuring, offline, or no reply). */
val NetworkStatus?.pingMs: Int?
    get() = ((this as? NetworkStatus.Online)?.latency as? Latency.Measured)?.medianMs

/** True when the phone has no way out: no network at all, or one that isn't answering. */
val NetworkStatus?.isDown: Boolean
    get() = this == NetworkStatus.Offline ||
        (this as? NetworkStatus.Online)?.latency == Latency.Unreachable
