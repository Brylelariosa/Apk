package com.bru.gameboost.presentation.theme

import androidx.compose.ui.graphics.Color

val AccentOrange = Color(0xFFFF7A1A)
val SurfaceDark = Color(0xFF121212)
val SurfaceCardDark = Color(0xFF1E1E1E)
