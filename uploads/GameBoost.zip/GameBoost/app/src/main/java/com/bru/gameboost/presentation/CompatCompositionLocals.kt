package com.bru.gameboost.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLifecycleOwner as LocalViewTreeLifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner

/**
 * Bridges [LocalViewTreeLifecycleOwner] (androidx.compose.ui.platform) into
 * [LocalLifecycleOwner] (androidx.lifecycle.compose) at the composition root.
 *
 * On this project's compose-ui version (2026.08.00 BOM, well past 1.7) the two
 * are already unified upstream, so this is purely defensive — cheap insurance
 * against the "CompositionLocal LocalLifecycleOwner not present" crash that hit
 * SystemMonitor on its older, R8-full-mode-obfuscated BOM (AndroidX issue
 * 336842920; see SystemMonitor's copy of this file for the full writeup).
 * Providing the value explicitly here means this app can never regress into
 * that crash regardless of future BOM/R8 changes. Harmless to leave in place.
 */
@Composable
fun ProvideLifecycleOwnerCompat(content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalLifecycleOwner provides LocalViewTreeLifecycleOwner.current,
        content = content
    )
}
