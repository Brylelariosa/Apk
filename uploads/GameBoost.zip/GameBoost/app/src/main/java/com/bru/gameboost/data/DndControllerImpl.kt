package com.bru.gameboost.data

import android.app.NotificationManager
import android.content.Context
import com.bru.gameboost.domain.DndController

/**
 * Uses PRIORITY (not NONE/total-silence) as the boosted filter, so the
 * user's own priority-only exceptions — alarms, starred contacts — still
 * come through. Remembers whatever filter was active before boosting so
 * [revertBoost] restores it exactly, rather than assuming "off".
 */
class DndControllerImpl(context: Context) : DndController {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private var previousFilter: Int? = null

    override fun isAccessGranted(): Boolean = notificationManager.isNotificationPolicyAccessGranted

    override fun applyBoost() {
        if (!isAccessGranted()) return
        previousFilter = notificationManager.currentInterruptionFilter
        runCatching {
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
    }

    override fun revertBoost() {
        val toRestore = previousFilter ?: return
        if (isAccessGranted()) {
            runCatching { notificationManager.setInterruptionFilter(toRestore) }
        }
        previousFilter = null
    }
}
