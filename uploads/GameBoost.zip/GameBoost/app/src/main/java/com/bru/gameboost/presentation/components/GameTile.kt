package com.bru.gameboost.presentation.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bru.gameboost.domain.model.BoostableGame
import kotlinx.coroutines.delay

// Both tiles share one footprint so the "Add game" tile lines up with the games.
private val TileMinHeight = 92.dp

// Only the first screenful is staggered; later tiles would just be waiting for nothing.
private const val MAX_STAGGERED_TILES = 11
private const val STAGGER_STEP_MS = 40L

// How far the tile sinks while a finger is on it.
private const val PRESSED_SCALE = 0.93f

/**
 * One game as a compact tile: tap to boost, hold for the remove menu. Three small motions, each
 * answering something that happened — the tile springs in when the screen opens, squishes under
 * the finger, and wears a pulsing ring while its boost is live.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(
    game: BoostableGame,
    isBoosting: Boolean,
    loadIcon: IconLoader,
    entranceIndex: Int,
    playEntrance: Boolean,
    onBoost: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) PRESSED_SCALE else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "tilePress"
    )

    // Tiles that appear after the first screenful (scrolling, a game just added) start settled.
    var shown by remember { mutableStateOf(!playEntrance) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(entranceIndex.coerceAtMost(MAX_STAGGERED_TILES) * STAGGER_STEP_MS)
            shown = true
        }
    }
    val enter by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "tileEnter"
    )

    val primary = MaterialTheme.colorScheme.primary
    val ringColor by animateColorAsState(
        targetValue = primary.copy(alpha = if (isBoosting) 1f else 0f),
        animationSpec = tween(durationMillis = 300),
        label = "tileRing"
    )

    var menuOpen by remember { mutableStateOf(false) }
    val shape = MaterialTheme.shapes.medium

    Box(modifier = modifier) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = TileMinHeight)
                .graphicsLayer {
                    // Read here, in the layer block, so a frame of animation redraws instead of recomposing.
                    val scale = pressScale * (0.86f + 0.14f * enter)
                    scaleX = scale
                    scaleY = scale
                    alpha = enter.coerceIn(0f, 1f)
                }
                .clip(shape)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                .border(width = 1.5.dp, color = ringColor, shape = shape)
                .combinedClickable(
                    interactionSource = interaction,
                    indication = null,
                    onClickLabel = "Boost ${game.label}",
                    role = Role.Button,
                    onLongClickLabel = "Show options",
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuOpen = true
                    },
                    // The running game's tile stays quiet; ending it is the banner's job.
                    onClick = { if (!isBoosting) onBoost() }
                )
                .padding(horizontal = 6.dp, vertical = 8.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(56.dp)) {
                if (isBoosting) BoostPulse(modifier = Modifier.fillMaxSize())
                AppIcon(packageName = game.packageName, loadIcon = loadIcon, size = 44.dp)
            }
            Text(
                text = game.label,
                style = MaterialTheme.typography.labelMedium,
                color = if (isBoosting) primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
                text = { Text("Remove from list") },
                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                onClick = {
                    menuOpen = false
                    onRemove()
                }
            )
        }
    }
}

/** The last tile in the grid: a dashed outline that opens the add-game screen. */
@Composable
fun AddGameTile(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) PRESSED_SCALE else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "addTilePress"
    )
    val outline = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = TileMinHeight)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .clip(MaterialTheme.shapes.medium)
            .drawBehind {
                // Inset by half the stroke so the clip above doesn't shave the outer edge off the line.
                val stroke = 1.5.dp.toPx()
                drawRoundRect(
                    color = outline,
                    topLeft = Offset(stroke / 2f, stroke / 2f),
                    size = Size(size.width - stroke, size.height - stroke),
                    cornerRadius = CornerRadius(20.dp.toPx() - stroke / 2f),
                    style = Stroke(
                        width = stroke,
                        pathEffect = PathEffect.dashPathEffect(
                            floatArrayOf(7.dp.toPx(), 5.dp.toPx())
                        )
                    )
                )
            }
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClickLabel = "Add a game",
                role = Role.Button,
                onClick = onClick
            )
            .padding(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(56.dp)) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = muted,
                modifier = Modifier.size(26.dp)
            )
        }
        Text(
            text = "Add game",
            style = MaterialTheme.typography.labelMedium,
            color = muted,
            maxLines = 1,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
