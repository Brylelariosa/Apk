plugins {
    id("com.android.application")
    // No org.jetbrains.kotlin.android here — AGP 9's built-in Kotlin compiles
    // Kotlin sources on its own now; applying that plugin conflicts with it.
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.bru.gameboost"
    // Compose BOM 2026.08.00's artifacts (compose 1.12.0) require compiling
    // against API 37 — AAR metadata checks reject 36. targetSdk is left at
    // 36 deliberately: compileSdk and targetSdk are independent (compileSdk
    // is just the API surface available to compile against; targetSdk opts
    // into runtime behavior changes), and only compileSdk is what broke here.
    compileSdk = 37

    defaultConfig {
        applicationId = "com.bru.gameboost"
        // Target device (Infinix Hot 11 2022) runs API 30; 26 keeps a broad,
        // still-modern floor without adding version-branching for anything
        // except the API 29+ thermal-status read, which degrades gracefully.
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Built-in Kotlin reads its JVM target from targetCompatibility above —
        // no separate kotlinOptions{} block needed (that DSL is gone too).
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.08.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.10.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
