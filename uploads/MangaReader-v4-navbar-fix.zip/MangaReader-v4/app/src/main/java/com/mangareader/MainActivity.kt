package com.mangareader

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mangareader.data.Chapter
import com.mangareader.data.Series
import com.mangareader.ui.ChapterListScreen
import com.mangareader.ui.LibraryScreen
import com.mangareader.ui.ReaderScreen
import com.mangareader.ui.theme.MangaReaderTheme
import com.mangareader.viewmodel.LibraryViewModel
import com.mangareader.viewmodel.ReaderViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Tracks the pending re-hide so a fresh reveal always restarts the timer. */
    private var reHideJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        hideSystemBars()
        watchForUnwantedReveals()

        setContent {
            MangaReaderTheme {
                MangaReaderApp(
                    onKeepAwakeChanged = { keepAwake ->
                        if (keepAwake) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                    },
                    // Lets the reading surface re-hide the bars itself the instant
                    // a touch/scroll starts, instead of only reacting after the OS
                    // has already revealed them (see watchForUnwantedReveals below).
                    onRequestHideBars = ::hideSystemBars
                )
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    /**
     * `BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE` is supposed to auto-hide a
     * transiently-revealed bar on its own after a couple of seconds, but on
     * some OEM builds (this app targets an Infinix/XOS device) a normal
     * scroll flick that merely starts near the top/bottom edge gets read by
     * the system as an edge-swipe, and the bar it reveals doesn't reliably
     * disappear again by itself.
     *
     * Instead of trusting the OS timer, we watch for the system bars
     * becoming visible and re-hide them ourselves shortly after. This fires
     * on every reveal — deliberate or scroll-triggered — so it corrects the
     * case the OS isn't handling without needing to guess *why* a reveal
     * happened.
     *
     * This is now the FALLBACK layer only. The reading surface itself
     * (ReaderScreen / ReaderZoomSurface) calls [hideSystemBars] proactively
     * the moment a touch lands and repeatedly while a scroll is in progress,
     * which catches most false reveals before they're visible for even a
     * frame. This listener mainly exists for screens/gestures that don't go
     * through the reader (library, chapter list, dialogs), so it no longer
     * needs to double as the reader's main defense — that's why the grace
     * window dropped from 1200ms to [REVEAL_GRACE_MS].
     */
    private fun watchForUnwantedReveals() {
        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { _, insets ->
            if (insets.isVisible(WindowInsetsCompat.Type.systemBars())) {
                reHideJob?.cancel()
                reHideJob = lifecycleScope.launch {
                    delay(REVEAL_GRACE_MS)
                    hideSystemBars()
                }
            }
            insets
        }
    }

    private companion object {
        /** Grace window before a transiently-revealed system bar is hidden again. */
        const val REVEAL_GRACE_MS = 150L
    }
}

// ── Navigation ─────────────────────────────────────────────────────────────────

sealed class Screen {
    object Library : Screen()
    data class ChapterList(val series: Series) : Screen()
    data class Reader(
        val chapter: Chapter,
        val chapterIndex: Int,
        val series: Series
    ) : Screen()
}

@Composable
fun MangaReaderApp(
    onKeepAwakeChanged: (Boolean) -> Unit = {},
    onRequestHideBars: () -> Unit = {}
) {
    val libraryVM: LibraryViewModel = viewModel()
    val readerVM:  ReaderViewModel  = viewModel()

    var screen by remember { mutableStateOf<Screen>(Screen.Library) }

    // Keep screen awake while in the reader; release when leaving.
    val keepAwake by readerVM.keepScreenAwake.collectAsStateWithLifecycle()
    val inReader  = screen is Screen.Reader
    LaunchedEffect(inReader, keepAwake) {
        onKeepAwakeChanged(inReader && keepAwake)
    }

    when (val s = screen) {

        is Screen.Library -> {
            // Reload progress whenever we return to the library so that chapter
            // progress bars and "Continue Reading" reflect the latest read state.
            LaunchedEffect(Unit) { libraryVM.reload() }

            LibraryScreen(
                viewModel     = libraryVM,
                onSeriesClick = { series -> screen = Screen.ChapterList(series) }
            )
        }

        is Screen.ChapterList -> ChapterListScreen(
            series         = s.series,
            progress       = libraryVM.getProgress(s.series.id),
            readChapterIds = libraryVM.getReadChapterIds(s.series.id),
            onChapterClick = { chapter, idx ->
                screen = Screen.Reader(chapter, idx, s.series)
            },
            onBack = { screen = Screen.Library }
        )

        is Screen.Reader -> ReaderScreen(
            viewModel       = readerVM,
            chapter         = s.chapter,
            chapterIndex    = s.chapterIndex,
            allChapters     = s.series.chapters,
            initialProgress = libraryVM.getProgress(s.series.id),
            onBack          = {
                // Pull the just-saved progress into the library's cached
                // snapshot BEFORE navigating away, so ChapterListScreen (and
                // the Library's "Continue Reading") reflect the chapter the
                // user actually just finished — not whatever was cached when
                // this reading session started.
                libraryVM.refreshProgress(s.series.id)
                screen = Screen.ChapterList(s.series)
            },
            onChapterChange = { newChapter, newIdx ->
                libraryVM.refreshProgress(s.series.id)
                screen = Screen.Reader(newChapter, newIdx, s.series)
            },
            onRequestHideBars = onRequestHideBars
        )
    }
}
