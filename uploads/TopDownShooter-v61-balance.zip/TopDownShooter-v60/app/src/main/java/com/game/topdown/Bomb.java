package com.game.topdown;

public class Bomb {
    public float  x, y;
    public float  vx, vy;           // throw velocity (world px/sec)
    public float  rollVx, rollVy;   // ground-roll velocity after landing (world px/sec)
    public float  spawnX, spawnY;   // where it was thrown from
    public float  maxRange;          // landing distance cap (scales with throw power)
    public boolean hasLanded;
    public int    ownerId;
    public long   deployTime;
    public long   explodedAt = -1;

    public static final float RADIUS      = 130f;
    public static final int   DAMAGE      = 80;
    public static final long  FUSE_MS     = 2500;
    public static final long  FLASH_MS    = 400;
    public static final float THROW_SPEED = 560f;   // px/sec at full joystick push
    public static final float THROW_RANGE = 500f;   // max range at full power

    // ── Physics constants ────────────────────────────────────────────────────
    /** Fraction of flight speed converted to roll speed on landing. */
    public static final float LAND_ROLL_FACTOR  = 0.28f;
    /** Energy kept after each wall bounce (0 = dead stop, 1 = no energy loss). */
    public static final float BOUNCE_RESTITUTION = 0.52f;
    /** Ground-roll deceleration in px/sec² (applied over time). */
    public static final float ROLL_FRICTION      = 220f;
    /** Roll speed below which the bomb is treated as fully stopped. */
    public static final float MIN_ROLL_SPEED     = 8f;

    public Bomb(float x, float y, int ownerId) {
        this.x = x;  this.y = y;
        this.spawnX = x; this.spawnY = y;
        this.ownerId = ownerId;
        this.maxRange = THROW_RANGE;   // default; override with power scaling
        this.deployTime = System.currentTimeMillis();
    }

    public float traveledSq() {
        float dx = x - spawnX, dy = y - spawnY;
        return dx * dx + dy * dy;
    }

    public boolean shouldExplode() {
        return explodedAt < 0 && System.currentTimeMillis() - deployTime >= FUSE_MS;
    }
    public boolean isFlashing() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt < FLASH_MS;
    }
    public boolean isDone() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt >= FLASH_MS;
    }
}
