# FILE_CHANGES — Fifty-sixth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityMemoryViewer.kt`
**Why:** Full code audit (this pass's own opening message). Full
mechanics in CHANGELOG.md item 1.
**What changed:** Added a private `HEX_DIGITS` char table and two
`StringBuilder` extension helpers (`appendHex2()`/`appendHex8()`)
directly above `formatHexDump()`. Every `String.format("%02X ...")`/
`("%08X ...")` call inside that function's row-building loop replaced
with the new helpers; loop structure, spacing, and output format
unchanged.
**Verification:** Structural diff is a like-for-like swap (identical
append sequence and literal spacing). Numeric equivalence cross-checked
against Java Formatter's `%X` semantics with a 200,000-case Python
harness — see CHANGELOG.md item 1.

### `app/src/main/kotlin/com/mgba/android/GameScreenRecorder.kt`
**Why:** Full code audit (this pass's own opening message). Full
mechanics in CHANGELOG.md item 2.
**What changed:** Added `private var audioTruncationLogged = false`
next to `recordingStartNanos`, reset alongside the other per-recording
fields in `start()`. In `feedAudio()`, one new
`if (maxShorts < pairs * 2 && !audioTruncationLogged)` block logs a
`Log.w()` with the wanted/got short counts and sets the flag,
inserted right after `maxShorts` is computed and before the existing
buffer-fill logic (which is otherwise untouched).
**Verification:** Brace/paren counts balanced after the edit (script-
checked). Exactly one `feedAudio()` and one `audioTruncationLogged`
declaration in the file post-edit — no accidental duplication from
the edit.

### `app/src/main/kotlin/com/mgba/android/MainActivityControlEditorMode.kt`
**Why:** Full code audit, follow-up pass (this pass's own opening
message, then "did you see a way to improve this"). Full mechanics in
CHANGELOG.md item 3 / BUGS_FIXED.md.
**What changed:** New `internal fun MainActivity.flushPendingSliderEdits()`
added just above `syncEditButtonBarToSelection()`, calling
`commitInlineEdit()` on `editSizeSlider` and `editOpacitySlider`.
Called at three sites, each right before `editSelectedId` changes:
the top of `onEditTouch()`'s `MotionEvent.ACTION_DOWN` branch (before
hit-testing), the top of `exitEditMode()`, and the top of
`confirmResetAllLayout()`'s `"Reset"` button handler. No other logic
in any of the three functions changed.
**Verification:** Brace/paren counts balanced after the edit. Exactly
one `flushPendingSliderEdits()` definition and three call sites
confirmed by grep. Confirmed by grep that `editSizeSlider`/
`editOpacitySlider` are the only two `SliderRow` instances in the app
— no other call site needed the same fix.

---

# FILE_CHANGES — Fifty-fifth pass

## Modified

### `app/src/main/res/drawable/ic_dpad_arrow.xml`
**Why:** Direct report with an in-app screenshot — "dpad arrow is very
long." Full mechanics in CHANGELOG.md item 1.
**What changed:** Triangle `pathData` only — apex/base coordinates
changed from height 21 × width 18 to height 16 × width 22 (now wider
than tall). Fill color, viewport, and every other file unchanged; no
`.kt` call site touched.
**Verification:** Well-formed. Re-rendered standalone and in a full
4-arm rotated mockup via the offline renderer; compared directly
against the reported "too long."

### `app/src/main/res/drawable/ic_record.xml`
**Why:** Direct report with the same screenshot — "don't like the
recorder button look weird... don't think it will say I'm the recorder
button." Full mechanics in CHANGELOG.md item 1.
**What changed:** Entire file replaced — camcorder body + viewfinder
wedge + lens dot (2 `<path>` elements, one a compound outline) is gone;
replaced with a plain ring + filled dot (2 simple circular `<path>`
elements). Header doc comment rewritten to explain the concept change,
not just new coordinates. No `.kt` call site touched — `actionIconFor()`/
`drawActionButtonIcon()` already just load, tint, and size whatever
this file contains.
**Verification:** Well-formed. Re-rendered standalone, alongside the
other 3 action-button icons, and inside the actual button-box
treatment via the offline renderer — checked specifically for
on-sight "does this say record," not just visual-weight parity with
its siblings (which the previous design already had).

---

# FILE_CHANGES — Fifty-fourth pass

## Added

### `app/src/main/res/drawable/ic_record.xml`
**Why:** Direct report — Record was still a bare `canvas.drawCircle()`,
the one action-button icon never converted to a real vector resource.
No reference PNG this time. Full mechanics in CHANGELOG.md item 1.
**What it is:** Camcorder body + viewfinder wedge, single continuous
outline (same construction as `ic_screenshot.xml`'s body+bump), plus a
filled lens dot as this icon's own accent shape.
**Verification:** Well-formed (`xml.dom.minidom`). Rendered standalone
and inside the actual button-box treatment via this pass's own offline
SVG-arc renderer, alongside the existing 3 sibling icons, before and
after the lens dot was added.

### `app/src/main/res/drawable/ic_dpad_arrow.xml`
**Why:** Direct report — the 4 d-pad arms drew their direction as
Unicode text (▲▼◀▶) via labelPaint instead of real icon artwork.
**What it is:** One filled triangle, pointing up; `drawDpad()` rotates
the canvas 0°/90°/180°/270° per arm rather than this being 4 separate
files.
**Verification:** Well-formed. Rendered standalone, and as a full
4-arm rotated mockup (all 4 directions) via the offline renderer.

### `app/src/main/res/drawable/ic_fast_forward.xml`
**Why:** Direct report — fast-forward drew "»" as text via labelPaint.
**What it is:** Standard twin-triangle "»" media glyph, solid fill.
**Verification:** Well-formed. Rendered standalone and inside the
actual button-box treatment via the offline renderer.

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** See CHANGELOG.md item 1 for full mechanics on all three.
**What changed:** `actionIconFor()` gained a `"record"` case.
`drawActionButtonIcon()`: `"record"` folded into the shared
quicksave/quickload/screenshot vector-icon branch (own former
plain-circle case removed, along with the `s` local that was its only
reader); thin-border condition extended to include `"record"`.
`drawDpad()`: text-glyph `drawArm()` replaced with an icon-drawing
version (border → `utilityIconBorderStrokeW`, `canvas.rotate()`/
`restore()` around each arm's icon draw). `drawControls()`'s
fast-forward block: border → `utilityIconBorderStrokeW`, corner radius
8f → 12f, `canvas.drawText("»", ...)` replaced with an icon draw.
**Verification:** Brace/paren counts balanced after every edit in this
file this pass (checked repeatedly, not just once at the end). No
`canvas.drawText` call remains for any of these three controls (only
remaining call is `drawOutlineButton()`'s own A/B/L/R/Select/Start
label draw, out of scope). No stray `outlineStrokeW` reference remains
for any of the three either. No compiler available.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** New cache fields needed for the 3 new icons.
**What changed:** `iconRecord`, `iconDpadArrow`, `iconFastForward`
`Drawable?` fields added alongside the existing icon cache. That
field's doc comment, and `utilityIconBorderStrokeW`'s own, both updated
to describe the expanded set of controls now using them.
**Verification:** Brace/paren counts balanced after every edit. No
compiler available.

---

# FILE_CHANGES — Fifty-third pass

## Modified

### `app/src/main/res/drawable/ic_quick_load.xml`
**Why:** Direct report — Quick Load's arrow read as a blunt hook/comma,
not an arrow; reference PNG supplied (`emulator_icons.zip`). Full
mechanics in CHANGELOG.md item 1.
**What changed:** Arrow `<path>`'s `android:pathData` replaced. Old
value connected both shaft arcs straight to the tip point, with no
arrowhead flare. New value fits the shaft's outer/inner edges as two
independent (non-concentric) true arcs — matched to the reference's
tapered ribbon rather than assumed to be constant-width — and adds
explicit barb points so the head flares into a real arrowhead. Header
and arrow doc comments rewritten to match. Folder `<path>` (geometry,
stroke width, stroke color) is unchanged.
**Verification:** Diffed against the file as received — only the
arrow `<path>`'s `pathData` attribute and the doc comments differ; the
folder `<path>` element is identical. Re-parsed the edited file with
`xml.etree.ElementTree` (well-formed) and re-rendered its actual
on-disk `pathData` to confirm the saved file is what was checked
against the reference PNG.

---

# FILE_CHANGES — Fifty-second pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** The three utility icons were being tinted to the button
outline's own dim, ~63%-alpha color instead of solid white — full root
cause in CHANGELOG.md item 1.
**What changed:** In `drawActionButtonIcon()`'s `"quicksave",
"quickload", "screenshot"` branch: `icon.setTint(strokePaint.color)` →
`icon.setTint(Color.WHITE)`; `icon.alpha = strokePaint.alpha` →
`icon.alpha = 255`. Everything else in the function — the box drawn via
`strokePaint`/`fillPaint` right above, the `half`/`setBounds` sizing,
the `"record"` branch — is unchanged. A comment was added at the two
changed lines explaining the old vs. new tint and why; nothing else in
the file was touched.
**Verification:** Diffed the whole file against the project this pass
started from — this is the only change, and it's exactly these two
lines plus the comment. Brace/paren count confirmed equal before and
after.

### `app/src/main/res/drawable/ic_quick_load.xml`
**Why:** New reference screenshot + explicit spec: bigger, bolder,
2.5–3.0 stroke, and specifically an arrow that reads as an arrow rather
than a thin curved line.
**What changed:** Folder outline enlarged (bbox now
~(4,9.5)-(26.5,28.5), was ~(5,13.5)-(27,27)), stroke 2.0 → 2.75. Arrow
rebuilt from the previous curved-tail-into-filled-triangle into a
straight diagonal shaft plus a right-angle corner-bracket head (2
subpaths sharing only the tip point) — reads as an unmistakable
arrowhead at small size instead of relying on a filled triangle that
was reading as a hook/checkmark.
**Verification:** See CHANGELOG.md item 1's Verification note — render
script, not a device build.

### `app/src/main/res/drawable/ic_quick_save.xml`
**Why:** Same spec as above.
**What changed:** Body/notch/bars all scaled up (body bbox now
~(4,3.5)-(28,28.5), was ~(7,6)-(25,26)), stroke 2.0 → 2.75. Same
chamfered-corner/notch/2-bar structure as the previous pass — no shape
changes, just bigger and bolder.
**Verification:** Same as above.

### `app/src/main/res/drawable/ic_screenshot.xml`
**Why:** Same spec as above; this icon's bbox was also the shortest of
the three relative to the viewport (~16 of 32 units tall), reading as
visibly lighter-weight next to the other two even before the tint bug.
**What changed:** Body+bump height roughly 40% taller (bbox now
~(4,6.2)-(28,29), was ~(5,8)-(27,24)), lens ring/dot enlarged to match,
stroke 2.0 → 2.75. Same body/bump/lens structure as the previous pass.
**Verification:** Same as above.

---

# FILE_CHANGES — Fifty-first pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** Quickload arrow rendered as an overlapping/kinked mess on an
actual device — full root cause in CHANGELOG.md item 1.
**What changed:**
- `"quickload"` case: tail curve's control point and endpoint, and the
  arrowhead's 3 points, all replaced with values chosen so the curve's
  bend stays wide (no tight radius for the stroke to fold over) and its
  end tangent already runs close to the arrowhead's own 45° axis. The
  folder outline itself, and the `drawFloppyDiskIcon()` / `"screenshot"`
  code right around it, are unchanged.
- Doc comment above `"quickload"` updated with the new fix's reasoning;
  old comment's claim about the tail/head relationship (a single shared
  point) removed since it wasn't the actual defect this time.
**Verification:** Standalone script re-run at 3 icon sizes/stroke-width
ratios matching this button's real Control Size range, not the one
generous size the previous pass checked at. Brace/paren balance
re-confirmed after the edit.

---

# FILE_CHANGES — Fiftieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/SharedUi.kt`
**Why:** New reference photo shows a detailed floppy disk for quicksave
— full detail in CHANGELOG.md item 1.
**What changed:**
- `drawFloppyDiskIcon()` rewritten: body is now one continuous `Path`
  (3 rounded corners via `arcTo()` + a straight diagonal chamfer at the
  top-right, one `moveTo()`/closed loop) instead of `drawRoundRect()`
  plus a separately-stroked notch. Added a shutter notch with a filled
  write-protect tab and 3 filled label lines below it.
- Signature changed: now takes both a stroke `Paint` and a fill `Paint`
  (`drawFloppyDiskIcon(canvas, strokePaint, fillPaint, cx, cy, s)`),
  since the tab/lines need a fill. Both existing call sites updated.
- New imports: `android.graphics.Path`, `android.graphics.RectF`.
**Verification:** No compiler here. Whole-file brace/paren balance
checked before and after.

### `app/src/main/kotlin/com/mgba/android/SettingsIcons.kt`
**Why:** Follows `drawFloppyDiskIcon()`'s new signature above.
**What changed:**
- `SettingsGlyph.STORAGE` case: now passes this view's own `fillPaint`
  as the new second paint argument.
**Verification:** No compiler here. Whole-file brace/paren balance
checked before and after.

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** New reference photo for all three action-button icons — full
detail in CHANGELOG.md item 1.
**What changed:**
- `drawActionButtonIcon()`'s `"quicksave"` case: was an inline
  folded-corner-page `Path` plus two content lines, now a single call
  to the shared `drawFloppyDiskIcon()` (SharedUi.kt).
- `"quickload"` case: was a rounded box plus a straight arrow `Path`,
  now a folder silhouette (one continuous `Path` — tab, notch-
  transition, lid, all 3 rounded corners) plus a filled arrowhead
  `Path` and a separately-stroked quadratic-curve tail.
- `"screenshot"` case: bump's `bumpL`/`bumpR` moved off-center (was
  symmetric around `cx`); new filled indicator `Rect` inside the bump;
  lens gained an inner stroked ring and a filled center circle (was one
  stroked ring).
- New code right after the button-background draws, before the
  `when(id)`: `fillPaint.color`/`fillPaint.alpha` now set to match
  `strokePaint`'s before any of the above run, since this is the first
  time this function needs `fillPaint` for anything other than the
  existing press-tint background fill (which still runs first and is
  unaffected). See CHANGELOG.md item 1 for the full reasoning.
- Doc comments on `drawActionButtonIcon()` and its `when` cases updated
  to match; stale comments describing the removed page/box-arrow shapes
  removed rather than left to drift.
**Verification:** No compiler here. All three new icons reproduced in a
standalone script and checked against the reference photo before being
committed to source (see CHANGELOG.md item 1). Whole-file brace/paren
balance checked after every edit, not just once at the end.

---

# FILE_CHANGES — Forty-ninth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** Corrects the Forty-eighth pass's button work per two direct
follow-up reports — full detail in CHANGELOG.md item 1.
**What changed:**
- `drawActionButtonCaption()` removed entirely; `drawOutlineButton()`'s
  `when(id)` dispatch is back to a single `"quicksave", "quickload",
  "screenshot", "record" ->` branch calling only `drawActionButtonIcon()`,
  as it was before Forty-eighth.
- `drawActionButtonIcon()`'s `"quicksave"` case: was
  `drawFloppyDiskIcon(...)`, now a folded-corner page shape (a `Path`)
  plus two content lines, matching the reference image.
- `drawActionButtonIcon()`'s `"quickload"` case: was a downward arrow
  into a tray (4 separate `drawLine()` calls), now a rounded box plus a
  `Path` arrow breaking out toward the upper right, matching the
  reference image.
- `"screenshot"` and `"record"` unchanged.
**Verification:** No compiler here. Whole-file brace/paren balance
checked before and after.

### `app/src/main/kotlin/com/mgba/android/GameScreenRecorder.kt`
**Why:** Two audit-found bugs — full detail in CHANGELOG.md item 2 /
BUGS_FIXED.md.
**What changed:**
- New `recordingStartNanos: Long` field (`@Volatile`), set in `start()`
  before `startCaptureLoop()` spawns the capture thread.
  `startCaptureLoop()`'s local `startNanos` (captured after EGL setup)
  is removed; every frame's presentation timestamp now uses
  `recordingStartNanos` instead.
- New `PendingSample` (private nested class) and two queue fields,
  `pendingVideoSamples`/`pendingAudioSamples`.
- `drainVideoLocked(Boolean)`/`drainAudioLocked(Boolean)` are now thin
  wrappers around one new shared `drainLocked(codec, bufferInfo,
  pending, isVideo, endOfStream)` — the two functions were near-
  identical, differing only in which field to touch.
- `maybeStartMuxerLocked()`: after `muxer.start()` succeeds, now calls
  a new `flushPendingLocked(pending, trackIndex)` for both queues.
- `teardownLocked()`: now also clears both pending queues.
**Verification:** No compiler or device here. Traced every existing
call site of the two drain functions to confirm the new shared
signature covers both without a behavior change to any caller. Whole-
file brace/paren balance checked before and after — caught and fixed a
missing closing paren in this fix's own doc comment before finishing.

---

# FILE_CHANGES — Forty-eighth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** Direct report — quicksave/quickload/screenshot should show
their name like My Boy!'s own icon-plus-name action buttons, not just
an icon. Full description in FEATURES_ADDED.md.
**What changed:**
- New `drawActionButtonCaption(canvas: Canvas, id: String, rect: RectF)`
  — draws `labelFor(id)` centered under the button, sized by measuring
  the actual string at a candidate size and scaling to fit (a
  `rect.width() * 2.2f` budget) rather than a fixed constant, since
  `rect` can be anything from the per-button Control Size slider or a
  corner-drag resize in the layout editor.
- `drawOutlineButton()`'s `when(id)` dispatch: the previous
  `"quicksave", "quickload", "screenshot", "record" ->` branch is now
  two branches — `"quicksave", "quickload", "screenshot"` calls
  `drawActionButtonIcon()` then the new `drawActionButtonCaption()`;
  `"record"` alone keeps calling only `drawActionButtonIcon()`, exactly
  as before.
- No change to `drawActionButtonIcon()` itself, `addButton()`'s four
  call sites for this row, the `Button` model, or any hitbox/drag/
  resize/opacity/flash-feedback code — the caption reads straight from
  the same `rect` every other part of this system already resolves per
  frame, so it needed no new stored state anywhere.
**Why this fixes it:** See CHANGELOG.md item 1 / FEATURES_ADDED.md.
**Verification:** No compiler here. Confirmed by reading every existing
call site of `drawOutlineButton()`, `drawActionButtonIcon()`, and
`labelFor()` — none needed a signature change, so nothing outside this
one function's `when` block and the one new function had to move;
whole-file brace/paren balance checked before and after.

---

# FILE_CHANGES — Forty-seventh pass

## Added

### `app/src/main/kotlin/com/mgba/android/EglBitmapSurfaceRenderer.kt`
**Why:** the screen recorder's video fix — see BUGS_FIXED.md. A real
EGL/GLES2 pipeline for drawing Bitmaps onto a MediaCodec encoder's input
Surface, replacing the `lockCanvas()`/`lockHardwareCanvas()` attempts
that only got one frame (or a few) through.
**Contains:** `EglBitmapSurfaceRenderer` (`start`, `drawFrame`,
`release`, plus its own private shader-compile helpers).

## Modified

**`RomBrowserActivity.kt`** — `refreshList()` now calls
`scrollView.scrollTo(0, 0)` on every real navigation, before
`renderList()` rebuilds the row views. See BUGS_FIXED.md ("landing at
the bottom of a freshly-opened folder").

**`GameScreenRecorder.kt`** — `captureAndDrawFrame()`/`startCaptureLoop()`
rewritten around `EglBitmapSurfaceRenderer` instead of
`Surface.lockHardwareCanvas()`; the renderer is constructed, `start()`ed,
used for every frame, and `release()`d entirely within the capture
thread's own `Thread { ... }` body (never touched from any other thread).
Presentation timestamps changed from raw `System.nanoTime()` to
recording-start-relative. Top-of-file doc comment updated to describe
the new mechanism; unused `android.graphics.Canvas` import removed.

**`MainActivity.kt`** — three new fields: `actionButtonFlashId`/
`actionButtonFlashUntil` (quicksave/quickload/screenshot tap feedback)
and `loadedLayoutOrientationTag` (layout-orientation-reload fix). See
BUGS_FIXED.md for both.

**`MainActivityShared.kt`** — new constant `ACTION_BUTTON_FLASH_MS`
(150L).

**`MainActivityInput.kt`** — `triggerActionButton()` now sets
`actionButtonFlashId`/`actionButtonFlashUntil` for quicksave/quickload/
screenshot before dispatching the actual action.

**`MainActivityControlLayout.kt`** — `loadCustomLayout()` captures
`orientationTag()` once into a local and records it into
`loadedLayoutOrientationTag`, instead of calling `orientationTag()`
three separate times; `buildControlLayout()` reloads via
`loadCustomLayout()` the instant the current orientation tag disagrees
with `loadedLayoutOrientationTag` (skipped while `editModeActive`);
`drawControls()`'s `pressed` check gained a
`"quicksave", "quickload", "screenshot"` branch reading the new flash
fields; `importLayoutBackupIfNeeded()`'s restore write changed
`.apply()` → `.commit()`.

**`MainActivityLayoutPresets.kt`** — `applyLayoutPreset()`'s
cross-orientation branch (writing a preset for the orientation you're
*not* currently in) changed `.apply()` → `.commit()`; `layoutPresetRow()`'s
edit action now draws `SettingsIconView(ctx, SettingsGlyph.EDIT, ...)`
instead of a plain `"✎"` `TextView`, matching its neighboring trash
icon's exact size/background pattern; its own doc comment updated to
say "a pencil icon" instead of quoting the character directly.

**`MainActivityMenus.kt`** — `settingsRow()`'s icon `FrameLayout.LayoutParams`
enlarged from `dp(24)` to `dp(28)` (the outer `dp(44)` column is
unchanged).

**`MainActivitySettingsDialogs.kt`** — `musicControlRow()`: `chip()`
enlarged from `dp(22)` to `dp(24)` and now returns both the icon and its
container (`Pair<SettingsIconView, View>`) instead of just the icon;
`refresh()` sets the shuffle chip's container background via a new
`activeChipBackground()` when shuffle is on, in addition to the existing
icon tint swap. New private `activeChipBackground()` helper (a
`colorFfActive`-colored counterpart to `iconChipBackground()`, kept local
to this file rather than folded into that shared one — see its own doc
comment for why).

**`SettingsIcons.kt`** — new `SettingsGlyph.EDIT` enum entry and its
`onDraw()` branch (a simple diagonal-shaft-plus-tip-plus-cap pencil, all
strokes); `SettingsGlyph.GAMEPAD`'s `onDraw()` branch redrawn — larger
face-button circles (`0.10s` → `0.16s` radius), the d-pad changed from
two disconnected segments to one connected "+", and the body's lower
edge nudged to keep proportions balanced against the larger internal
detail.


# FILE_CHANGES — Forty-sixth pass

## Added

### `app/src/main/kotlin/com/mgba/android/MainActivityShared.kt`
**Why:** build fix — see BUGS_FIXED.md/CHANGELOG.md. Every companion-
object constant and small nested data/sealed class the Forty-fifth
pass's split left behind inside `MainActivity`, hoisted to top-level.
**Contains:** `TAG` and every `PREF_*`/`ORIENTATION_*`/`GAME_FRAC_NORM`/
`EDIT_TOOLBAR_*`/`GBA_*`/`FALLBACK_FRAME_NS`/`FF_MAX_BATCH_FRAMES`/
`SAVE_STATE_SLOTS`/`STATE_THUMB_WIDTH_PX`/`SLOT_INFO_CACHE_MAX` constant
(plus 2 new debug-toggle prefs and 4 new music prefs, this pass);
`LayoutEntry`, `Geometry`, `ButtonDef`, `MemRegion`, `SlotInfo`,
`SlotKind`.

### `app/src/main/kotlin/com/mgba/android/MusicPlaylistPlayer.kt`
**Why:** background music's actual playback engine — self-contained, no
`MainActivity`/emulator dependency. See CHANGELOG.md item 1.
**Contains:** `MusicPlaylistPlayer` (`setPlaylist`, `setShuffle`,
`setVolume`, `play`, `pause`, `next`, `previous`, `release`).

### `app/src/main/kotlin/com/mgba/android/MainActivityMusic.kt`
**Why:** background music's glue — folder enumeration, the SAF picker
callback, lifecycle hooks. UI lives in `MainActivitySettingsDialogs.kt`
with every other settings screen. See CHANGELOG.md item 1.
**Contains:** `listMusicFiles`, `onMusicFolderPicked`,
`startMusicIfEnabled`, `pauseMusicForLifecycle`, `resumeMusicForLifecycle`.

### `app/src/main/kotlin/com/mgba/android/GameScreenRecorder.kt`
**Why:** screen recorder's encoding engine — MediaCodec/MediaMuxer, no
UI/Settings knowledge. See CHANGELOG.md item 2.
**Contains:** `GameScreenRecorder` (`start`, `stop`, `feedAudio`, plus
the capture-loop/drain/teardown internals).

### `app/src/main/kotlin/com/mgba/android/MainActivityRecorder.kt`
**Why:** screen recorder's glue — the record-button toggle, saving the
finished file, lifecycle hooks. See CHANGELOG.md item 2.
**Contains:** `toggleScreenRecording`, `finishRecordingAndSave`,
`stopScreenRecordingForLifecycle`.

### `app/src/main/kotlin/com/mgba/android/MainActivityLayoutPresets.kt`
**Why:** named layout presets — data model, persistence, apply/capture/
delete, the two editor entry points. See CHANGELOG.md item 3.
**Contains:** `LayoutPreset`, `loadLayoutPresets`, `saveLayoutPresets`,
`captureCurrentAsPreset`, `applyLayoutPreset`, `deleteLayoutPreset`,
`startNewLayoutPreset`, `editExistingLayoutPreset`,
`promptNewLayoutPresetName`, `layoutPresetRow`.

## Modified

**`MainActivity.kt`** — build fix (FILE MAP comment corrected; see
BUGS_FIXED.md); new fields for background music (`musicPlayer`,
`musicFolderUri`, `musicEnabled`, `musicShuffle`, `musicVolume`,
`musicFolderPicker`) and the screen recorder (`screenRecorder`,
`recordingPaint`); `editingPresetName` field (layout presets); two debug-
toggle fields; prefs loading in `onCreate()` for all of the above;
`onPause()`/`onResume()`/`onDestroy()` wired to music and recorder
lifecycle; `"record"` added to `extraControlIds`/`actionButtonIds`.

**`MainActivityAudio.kt`** — one line in `writePcm()` feeding the
recorder's audio encoder (see CHANGELOG.md item 2); one `MODE_PRIVATE`
qualification (build fix).

**`MainActivityRender.kt`** — `drawRecordingIndicator()` added and
wired into `renderFrame()`.

**`MainActivityControlLayout.kt`** — `drawActionButtonIcon()` added
(quicksave/quickload/screenshot/record icon glyphs, see BUGS_FIXED.md);
`"record"` button added to `buildControlLayout()`'s row-2 cluster; empty
labels on all 4 action buttons now that they draw icons instead of text;
recording-state "pressed" case in `drawControls()`.

**`MainActivityControlEditorGeometry.kt`** — `"record"` added to
`labelFor()`; top-of-file scope comment corrected (landscape-lock claim
was stale — see CHANGELOG.md item 3).

**`MainActivityControlEditorMode.kt`** — `exitEditMode()` extended to
handle the layout-preset save flow on top of its existing behavior,
unchanged when no preset session is active.

**`MainActivityInput.kt`** — `"record"` dispatch added to the action-
button tap handler.

**`MainActivityMenus.kt`** — `showGameMenu()` rewritten (see
CHANGELOG.md item 4); Debug row added to `buildSettingsMenu()`; Layouts
row subtitle updated.

**`MainActivitySettingsDialogs.kt`** — Background music section added to
`showAudioSettings()`; `showMusicVolumeDialog()` added;
`showInputSettings()` gained Button size/opacity (moved from Layouts);
`showLayoutsSettings()` rewritten as the preset manager;
`showDebugSettings()` added; one `MODE_PRIVATE` qualification (build fix).

**`RomBrowserActivity.kt`** — see BUGS_FIXED.md: `row()` tags itself
with its `File`; `finishZipScan()` replaces the second `renderList()`
call with targeted row removal.



## Added

Each file below holds `internal fun MainActivity.<name>()` extension
functions moved verbatim out of `MainActivity.kt` — same mechanism/
reasoning as `SharedUi.kt` (Thirty-second pass); see CHANGELOG.md item 1
for the full explanation and verification. "Contains" lists the
functions each file holds, in their original relative order.

### `app/src/main/kotlin/com/mgba/android/MainActivityAudio.kt`
**Why:** AudioTrack setup/settings is a self-contained concern.
**Contains:** `initAudioTrack`, `applyGameVolume`,
`updateSoundFrequencyFactor`, `requestAudioFocus`, `abandonAudioFocus`,
`releaseAudio`, `writePcm`, `applySoundFrequencyFilter`,
`decimateForFastForward`.

### `app/src/main/kotlin/com/mgba/android/MainActivityRom.kt`
**Why:** ROM staging/loading is a self-contained concern.
**Contains:** `stageRomFile`, `loadRomFromUri`, `changeRom`,
`deriveRomBaseName`.

### `app/src/main/kotlin/com/mgba/android/MainActivitySaveStateCore.kt`
**Why:** Save/state file-path resolution, the Storage-folder feature,
and quick save/load are one cohesive data layer.
**Contains:** `savesDir`, `statesDir`, `batterySaveFile`,
`stateSlotFile`, `stateThumbFile`, `quickStateFile`, `quickThumbFile`,
`autoStateFile`, `autoThumbFile`, `dataFolderTree`, `dataSubfolder`,
`autoFolderMirrorActive`, `autoFolderRoot`, `autoMirrorSubdir`,
`batterySaveEntry`, `stateSlotEntry`, `stateThumbEntry`,
`quickStateEntry`, `quickThumbEntry`, `autoStateEntry`,
`autoThumbEntry`, `stateEntryFor`, `stateThumbEntryFor`,
`quickSaveState`, `quickLoadState`, `backupIfExists`.

### `app/src/main/kotlin/com/mgba/android/MainActivitySaveStateUi.kt`
**Why:** The save-state slot dialog and its thumbnails are the
UI-facing half of the save-state feature, separate from the file-path
data layer above.
**Contains:** `showSaveStateMenu`, `captureGameFrameBitmap`,
`captureStateThumbnail`, `stateSlotRow`, `cacheSlotInfo`,
`loadSlotInfo`, `showSaveStateSlotDialog`. (`stateSlotRow()`'s two
`this@MainActivity` → `this@stateSlotRow` fix — see CHANGELOG.md item 1
— lives here.)

### `app/src/main/kotlin/com/mgba/android/MainActivityControlLayout.kt`
**Why:** Building/persisting/drawing the on-screen control layout
(not the editor itself) is one concern.
**Contains:** `isButtonVisible`, `orientationTag`, `loadCustomLayout`,
`saveCustomLayout`, `exportLayoutBackup`, `importLayoutBackupIfNeeded`,
`resolvedRect`, `addButton`, `buildControlLayout`,
`updateLinearFilterPaint`, `drawControls`, `shoulderButtonPath`,
`drawOutlineButton`, `updateDpadArmRects`, `drawDpad`, `dpadKeysFor`.

### `app/src/main/kotlin/com/mgba/android/MainActivityRender.kt`
**Why:** The Choreographer render loop, the game loop, and the screen
matrix/clamping math that both depend on are one concern.
**Contains:** `startRenderLoop`, `stopRenderLoop`, `startGameLoop`,
`stopGameLoop`, `renderFrame`, `clearSurfaceToBlack`,
`updateGameMatrix`, `clampRectToScreen`, `clampToScreenAxis`,
`clampControlCenterToScreen`, `drawLinkStatus`, `drawFpsOverlay`,
`setImmersive`.

### `app/src/main/kotlin/com/mgba/android/MainActivityInput.kt`
**Why:** Gameplay (not editor) touch/key handling is one concern.
**Contains:** `formatSpeed`, `showFastForwardSpeedSlider`,
`clearPointerState`, `onGameTouch`, `armFfLongPress`, `completeFfTap`,
`updateGameKeys`, `effectiveKeysForCore`, `actionButtonAt`,
`triggerActionButton`.

### `app/src/main/kotlin/com/mgba/android/MainActivityControlEditorGeometry.kt`
**Why:** Hit-testing/grid-snap/percent-conversion math the editor
depends on, separated from the mode/touch-handling half below since
it's a distinct, smaller-surface concern (mostly small, near-pure
functions).
**Contains:** `labelFor`, `editRectFor`, `resizeHandleRadius`,
`resizeHandleTouchRadius`, `dist`, `entryFor`, `gridCellPx`,
`snapPositionToGrid`, `snapScaleToGrid`, `hitTestEditable`,
`alphaToPercent`, `percentToAlpha`, `currentScalePercent`,
`currentAlphaPercent`, `isSelectedLocked`.

### `app/src/main/kotlin/com/mgba/android/MainActivityControlEditorMode.kt`
**Why:** Edit-mode lifecycle, the editor's own touch handling, and its
toolbar UI/sync are one concern, the largest single piece of the old
file.
**Contains:** `enterEditMode`, `exitEditMode`, `confirmResetAllLayout`,
`resetSingleButton`, `setSelectedScalePercent`,
`setSelectedAlphaPercent`, `toggleSelectedLock`,
`syncEditButtonBarToSelection`, `setSliderRowWidth`,
`refreshEditToolbarPosition`, `onEditTouch`, `nudgeSelected`,
`cancelEditLongPress`, `showRemoveButtonMenu`, `removeButton`,
`allControlIds`, `showAddControlMenu`, `showGridSettingsDialog`,
`drawGrid`, `drawEditOverlay`.

### `app/src/main/kotlin/com/mgba/android/MainActivityMemoryViewer.kt`
**Why:** The live memory-viewer overlay is self-contained.
**Contains:** `showMemoryViewer`, `hideMemoryViewer`,
`scheduleMemoryRefresh`, `refreshMemoryDump`, `formatHexDump`,
`buildMemoryViewer`.

### `app/src/main/kotlin/com/mgba/android/MainActivityMenus.kt`
**Why:** The two top-level overlay menus (Settings category list, quick
game menu) and screen-orientation apply.
**Contains:** `buildSettingsMenu`, `settingsRow`, `showSettingsMenu`,
`applyScreenOrientationPref`, `showGameMenu`, `gameMenuRow`,
`showAboutDialog`, `applyLayoutSettings`.

### `app/src/main/kotlin/com/mgba/android/MainActivityVideoSettings.kt`
**Why:** The Video settings screen plus the small shared dialog-row
helpers it (and other settings screens) use.
**Contains:** `dlgRadioGroup`, `RadioGroup.dlgAddOpt` (this one drops
its unused `MainActivity` dispatch receiver entirely — its body only
ever used the `RadioGroup` extension receiver, see CHANGELOG.md item 1
— so it's a plain top-level `RadioGroup` extension function, not a
`MainActivity` one, same as before this pass for every call site),
`videoListRow`, `videoCheckRow`, `videoDivider`, `showVideoSettings`,
`showScreenOrientationDialog`, `showMaxFrameSkipsDialog`.

### `app/src/main/kotlin/com/mgba/android/MainActivitySettingsDialogs.kt`
**Why:** The remaining settings-category dialogs.
**Contains:** `showAudioSettings`, `showSoundVolumeDialog`,
`showSoundFrequencyDialog`, `showInputSettings`, `showLayoutsSettings`,
`showMiscSettings`, `showStorageSettings`, `showAdvancedSettings`.

### `app/src/main/kotlin/com/mgba/android/MainActivityDebugLog.kt`
**Why:** Crash/link debug logging, screenshots, and reset/close are
this app's diagnostic/lifecycle-adjacent actions.
**Contains:** `installCrashLogger`, `capLogText`, `copyLinkDebugLog`,
`showLinkDebugLogDialog`, `copyCrashLog`, `showCrashLogDialog`,
`takeScreenshot`, `saveScreenshotBitmap`, `resetGame`, `closeGame`.

### `app/src/main/kotlin/com/mgba/android/MainActivityLink.kt`
**Why:** Link-multiplayer dialogs and the Bluetooth permission gate
they share.
**Contains:** `ensureBluetoothPermission`, `showLinkRemoteDialog`,
`showLinkLocalDialog`, `showLinkDisconnectDialog`, `showIpDialog`,
`joinWifi`, `onLinkConnected`, `stopLink`.

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Everything above.
**What changed:** ~7,700 lines → ~2,150. Removed: all 168 functions
listed above (moved out, verbatim, as described in CHANGELOG.md item 1).
Kept: every field/property (visibility widened `private`→`internal`
throughout, including all ~40 companion-object constants); the
companion object itself; the small data classes/sealed class
(`ButtonDef`, `LayoutEntry`, `Geometry`, `MemRegion`, `SlotInfo`,
`SlotKind`) and `SaveEntry` (an `inner class` — kept for its implicit
outer-instance access, its own 3 genuinely-private members
(`doc`/`stagingFile`/`usesDataFolder`) untouched since nothing outside
it ever calls them); the 8 lifecycle/`SurfaceHolder.Callback` overrides
(`onCreate`, `onDestroy`, `onPause`, `onResume`,
`onWindowFocusChanged`, `surfaceCreated`, `surfaceDestroyed`,
`surfaceChanged`), all completely unchanged (every call inside them to
something that moved is a plain unqualified call, and resolves exactly
as before — nothing inside any of the 8 needed editing). New top-of-
file comment documenting the file map, for the same reason every new
file has one — see CHANGELOG.md item 1.

# FILE_CHANGES — Forty-fourth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** nine items, full descriptions in CHANGELOG.md — see BUGS_FIXED.md/
FEATURES_ADDED.md for the shorter user-facing versions.
**What changed:**
- `saveCustomLayout()`: SharedPreferences write switched from `.apply()`
  to `.commit()` (item 1).
- `refreshEditToolbarPosition()`: now shrinks `editSizeSlider`/
  `editOpacitySlider` to fit the actual screen width before measuring;
  new `setSliderRowWidth()` helper, new field `editRowLabelWidthPx`
  (promoted from a local val at its construction site), new constant
  `EDIT_TOOLBAR_SLIDER_MIN_WIDTH_DP` (item 2).
- New `clampControlCenterToScreen()`, reusing `clampToScreenAxis()` per
  axis; new constant `CONTROL_DRAG_EDGE_MARGIN_DP`. Applied in
  `onEditTouch()`'s drag branch (replacing the old fixed-percentage
  clamp) and, new this pass, its resize branch too (item 3).
- `buildControlLayout()`: `lrH`/`ssH` now derive from `minOf(sw, sh)`
  instead of `sh` alone (item 4).
- `buildControlLayout()`'s `addButton()` calls for `quicksave`/
  `quickload`/`screenshot`: labels "💾"/"📂"/"📷" → "QS"/"QL"/"SS"
  (item 5).
- New `cropToGameScreen()`. Used by `captureStateThumbnail()` (before
  scaling to the thumbnail size) and `takeScreenshot()`'s PixelCopy
  callback (before handing off to `saveScreenshotBitmap()`) (item 6).
- New `SlotKind` (sealed class: `QuickSave`/`Autosave`/`Numbered`).
  `SlotInfo.slot: Int` → `SlotInfo.kind: SlotKind`. New
  `quickThumbFile()`/`autoStateFile()`/`autoThumbFile()` and their
  `SaveEntry` wrappers, new dispatchers `stateEntryFor()`/
  `stateThumbEntryFor()`. `captureStateThumbnail(slot: Int)` →
  `captureStateThumbnail(kind: SlotKind)`. New `loadSlotInfo()`,
  extracted from what used to be `showSaveStateSlotDialog()`'s own
  inline per-slot logic, now shared across all three kinds.
  `showSaveStateSlotDialog()` rewritten around the `SlotKind` list.
  `quickSaveState()` now also calls `captureStateThumbnail()` on success
  (item 7).
- New field `autoSaveLoadEnabled`, new constant `PREF_AUTO_SAVE_LOAD`,
  loaded alongside the other Misc prefs. New `CheckBox` in
  `showMiscSettings()`, persisted the same way `showFpsOverlay` already
  is. `onPause()`: new synchronous Autosave write when enabled, with a
  best-effort background-`Thread` thumbnail capture. `loadRomFromUri()`'s
  success callback: new silent Autosave load, before `startGameLoop()`.
  Also added to the "Reset settings" flow's defaults (item 8).

# FILE_CHANGES — Forty-first pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Control Size/Control Opacity sliders and the Max frame skips
timing fix — see CHANGELOG.md items 3–4 for the full descriptions.
**What changed:**
- `roundedDialogBackground()` deleted (moved to `SharedUi.kt`) — every
  call site is unaffected, unqualified same-package extension-function
  call either way.
- New fields `editSizeSlider`/`editOpacitySlider: SliderRow`, alongside
  the existing `editSizeLabel`/`editOpacityRow`.
- `editRow2`/`editOpacityRow` construction: the two `editChip("-", ...)`/
  `editChip("+", ...)` pairs replaced with one `sliderRow(...)` call
  each, given an explicit `dp(240)` width (needed for the slider's own
  internal `weight=1f` to have room to expand into).
- `adjustSelectedScale(delta: Float)`/`adjustSelectedAlpha(delta: Int)`
  deleted; replaced by absolute `setSelectedScalePercent(percent: Int)`/
  `setSelectedAlphaPercent(percent: Int)`, plus new pure-read helpers
  `currentScalePercent()`/`currentAlphaPercent()`/`isSelectedLocked()`
  and unit-conversion helpers `alphaToPercent()`/`percentToAlpha()`.
- `updateEditButtonBarLockIcon()` deleted; folded into a new
  `syncEditButtonBarToSelection()`, which also absorbs the inline label/
  visibility lines that used to live directly in `onEditTouch()`'s
  `ACTION_DOWN`. Called from `ACTION_DOWN` (selection), `toggleSelectedLock()`,
  and `resetSingleButton()` (the latter two are new call sites — the old
  chips had no live value that could go stale, so neither needed a
  refresh call before).
- `onEditTouch()`'s `ACTION_MOVE` (`editResizing` branch): one line added
  right after `e.scale = newScale` to keep the Control Size slider's
  displayed value live during a corner-drag resize too, not just its own
  drag.
- Two doc comments updated to reference `setSelectedScalePercent()`
  instead of the deleted `adjustSelectedScale()`
  (`clampRectToScreen()`'s and the `ACTION_MOVE` resize comment).
- `lastFrameLoopStartNs: Long` (a timestamp) replaced with
  `lastComputeNs: Long` (a duration) — see the field's own extensive
  comment. `startGameLoop()`'s reset line updated to match.
- The game loop: `behindSchedule` now reads `lastComputeNs > frameBudgetNs`
  instead of comparing two timestamps. `lastComputeNs = System.nanoTime()
  - t0` added in all three branches (skip, normal single-frame, fast-
  forward batch), each right after that branch's own last
  `nativeReadAudioSamples()` call and before its own blocking
  `writePcm()`/decimate-and-write.
- New import `kotlin.math.roundToInt`.
**Why this fixes it:** See CHANGELOG.md items 3–4.
**Verification:** No compiler/device, as every pass. Balance-checked.
Caught and fixed a real Kotlin implicit-receiver-shadowing hazard in the
new `sliderRow()` during review — see CHANGELOG.md item 3's own
Verification note (the fix itself is in `SharedUi.kt`, not this file, but
the hazard was in code originally drafted for this file's call sites).
Traced every new function's call sites and every renamed/deleted
function for stale references.

### `app/src/main/kotlin/com/mgba/android/SharedUi.kt`
**Why:** The new Control Size/Opacity slider needed a real, reusable
widget — see CHANGELOG.md item 3.
**What changed:**
- New `SliderRow` class and `Activity.sliderRow()` builder — a `SeekBar`
  plus a tap-to-type value readout; `setValue()`/`setEnabled()` let a
  caller refresh an already-built row without re-invoking its own
  `onChange`.
- New `Activity.showTypeValueDialog()` — a small numeric-`EditText`-in-
  an-`AlertDialog` prompt, the shared "type an exact value" UI both the
  new slider and (potentially) future callers can use.
- `roundedDialogBackground()` moved here from `MainActivity.kt` (see that
  file's own entry above) — the new dialog needs it, and it fits this
  file's existing "small, stateless, purely-cosmetic" scope.
- New imports for the above: `android.text.InputType`, `android.view.
  Gravity`, `android.view.View`, `android.widget.{EditText,LinearLayout,
  SeekBar,TextView}`, `androidx.appcompat.app.AlertDialog`.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No compiler/device. Balance-checked. Confirmed every
existing `MainActivity.kt` call site of the relocated
`roundedDialogBackground()` (7 call sites) still resolves as an
unqualified same-package extension-function call, unchanged.

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** `.zip` files now render instantly instead of waiting on content
verification — see CHANGELOG.md item 1.
**What changed:**
- `refreshList()`: the `immediate`/`zipCandidates`/`verifiedZips`
  variables are now `entries`/`zipCandidates`/`invalidZips` — `entries`
  is the full, final, correctly-sorted listing shown on the very first
  render (folders, `.gba`, *and* `.zip`, by name/extension alone);
  `invalidZips` is now *subtracted* from it once the background scan
  finishes, rather than a separate set *added* to a smaller initial list.
- `renderList()`'s doc comment updated: `stillScanning` now documents
  gating a prune, not gating additions.
**Why this fixes it:** See CHANGELOG.md item 1.
**Verification:** No compiler/device. Balance-checked. Traced the
`generation` staleness guard (untouched) to confirm it still applies to
the pruned final render.

### `app/src/main/res/values/themes.xml`
**Why:** One more step on the Landscape→Portrait transition flash — see
CHANGELOG.md item 2.
**What changed:**
- `Theme.mGBA.RomBrowser`: added `<item name="android:windowDisablePreview">true</item>`.
**Why this fixes it:** See CHANGELOG.md item 2.
**Verification:** No compiler/device. Re-validated as well-formed XML.

# FILE_CHANGES — Fortieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Square alignment-grid cells (+ a 64 preset), real touch targets
on the Control Size/Opacity ± chips, and removal of the control-area
background band — see CHANGELOG.md items 1–3 for the full descriptions.
**What changed:**
- New function `gridCellPx(): Float` — `min(lastSw, lastSh) /
  gridDivisions`, the single source of the grid's square cell size.
- `snapPositionToGrid()`: signature changed from `(v, dimension)` to
  `(v)`; now calls `gridCellPx()` instead of deriving its own cell size
  from the passed-in dimension. Both call sites (in `onEditTouch()`'s
  `ACTION_MOVE`) updated to the new one-argument form.
- `snapScaleToGrid()`: now calls `gridCellPx()` instead of computing
  `lastSw / n` itself.
- `drawGrid()`: now draws lines a fixed `gridCellPx()` apart instead of
  exactly `gridDivisions` lines spanning the width and `gridDivisions`
  spanning the height.
- `showGridSettingsDialog()`: `gridOptions` extended from `listOf(4, 8,
  16, 32)` to `listOf(4, 8, 16, 32, 64)`; preset radio labels changed
  from `"$n×$n"` to `"$n"`; description text extended to explain the new
  square-cell meaning.
- `editChip()`: gained a `minTouchDp: Int = 0` parameter; `setPadding`
  now goes through `dp()` instead of passing raw pixel literals.
- The four Control Size/Control Opacity `"-"`/`"+"` call sites (in the
  per-item editor bar) now pass `minTouchDp = 48`.
- Removed field `colorControlsBg` and the two lines in `drawControls()`
  that filled a rect with it from `controlsTop` down.
- Two doc comments updated to stop referencing removed/changed things:
  the `gridDivisions` field comment and the grid snap/draw section
  comment (square cells now, not `w/N`-by-`h/N`); `updateGameMatrix()`'s
  comment no longer mentions the removed `colorControlsBg` fill.
- `changeRom()`: now calls `overridePendingTransition(0, 0)` right after
  launching `RomBrowserActivity`.
**Why this fixes it:** See CHANGELOG.md items 1, 2, 3, 4.
**Verification:** No compiler/device, as every pass. Balance-checked
(comment/string/template-aware brace-paren-bracket scanner — see
CHANGELOG.md item 1 for the scanner's own bug found and fixed this
pass). Grepped for every remaining reference to `colorControlsBg` and
the old two-argument `snapPositionToGrid` to confirm none remain outside
of explanatory comments.

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** No visible landscape flash on open, a real status bar instead
of dead black space at the top, and a faster/clearer archive-scanning
state — see CHANGELOG.md items 4–6.
**What changed:**
- New imports: `android.content.res.ColorStateList`,
  `android.widget.ProgressBar`, `java.util.concurrent.Callable`,
  `java.util.concurrent.Executors`, `java.util.concurrent.Future`.
- New constant `ZIP_SCAN_THREADS = 4` in the companion object.
- New `override fun finish()` — calls `super.finish()` then
  `overridePendingTransition(0, 0)`, placed just above `onCreate()`.
- `refreshList()`: the zip-scanning `Thread` body now submits every
  candidate to a bounded `Executors.newFixedThreadPool(ZIP_SCAN_THREADS)`
  up front, collects each `Future<Boolean>` (each wrapped in its own
  try/catch, matching the previous per-file error handling), then shuts
  the pool down, instead of a single sequential `.filter { ... }` over
  all candidates.
- `renderList()`: the `stillScanning` branch now calls a new
  `scanningRow()` instead of `messageRow("Checking archives…")`.
- New function `scanningRow(): View` — a horizontal `LinearLayout` with
  an indeterminate `ProgressBar` (tinted `colorAccentLight`, from
  `SharedUi.kt`) next to the "Checking archives…" text.
- `messageRow()`'s doc comment narrowed to describe its one remaining
  caller (the empty-folder state) now that scanning has its own row.
**Why this fixes it:** See CHANGELOG.md items 4, 6.
**Verification:** No compiler/device. Traced the `Future` submit/collect
order (all submitted before any `.get()` blocks) and confirmed
`pool.shutdown()` only runs after every result is in. Confirmed the
existing `generation` staleness guard is untouched. Balance-checked.

### `app/src/main/res/values/themes.xml`
**Why:** RomBrowserActivity needs the system status bar visible; the app
theme it was inheriting hides it. See CHANGELOG.md item 5.
**What changed:**
- New style `Theme.mGBA.RomBrowser` (parent `Theme.mGBA`), overriding
  only `android:windowFullscreen` to `false`.
**Why this fixes it:** See CHANGELOG.md item 5.
**Verification:** Parsed as well-formed XML.

### `app/src/main/AndroidManifest.xml`
**Why:** Apply the new theme to the one Activity that needs it. See
CHANGELOG.md item 5.
**What changed:**
- `RomBrowserActivity`'s `<activity>` tag: added
  `android:theme="@style/Theme.mGBA.RomBrowser"`. Its existing
  `android:screenOrientation="portrait"` is unchanged.
**Why this fixes it:** See CHANGELOG.md item 5.
**Verification:** Parsed as well-formed XML.

## Unchanged (confirmed byte-identical to the input zip)
`RomZipUtils.kt`, `SharedUi.kt`, `EmulatorEngine.kt`,
`LinkMultiplayer.kt`, `mgba_jni.c`, `strings.xml`, both `build.gradle.kts`
files, `gradle.properties` — none of this pass's six reports touched the
zip-scanning logic itself (only how many run at once, and only from
`RomBrowserActivity.kt`'s side), the link/multiplayer code, the native
JNI layer, or the build configuration.

---

# FILE_CHANGES — Thirty-ninth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Game Screen Size/black-area/Stretch-to-Fit root-cause fix, the
leftover top-left speed indicator, a new alignment-grid feature, and a
customization-UI relabeling pass — see CHANGELOG.md/BUGS_FIXED.md/
FEATURES_ADDED.md for the full descriptions.
**What changed:**
- `updateGameMatrix()`: rewritten. The non-stretch box is now built from
  the live framebuffer's own aspect ratio instead of full-width by a
  height fraction, then run through the new `clampRectToScreen()`.
  Stretch to Fit is now its own branch, pinned to `(0, 0, sw, availH)`
  independent of any `customLayout["gamescreen"]` entry, rather than a
  different fit computed over the same customizable box.
- New function `clampRectToScreen(rect, sw, sh): RectF` — shrinks/
  re-centers a rect to fit within the screen bounds.
- `hitTestEditable()`: the `"gamescreen"` case is now gated on
  `!stretchToFit`.
- `onEditTouch()`'s `ACTION_MOVE`: added a matching `stretchToFit` guard
  for `"gamescreen"` specifically; drag/resize now call the new
  `snapPositionToGrid()`/`snapScaleToGrid()` when `snapToGrid` is on.
- New fields: `gridDivisions: Int` (default 8), `showGrid: Boolean`,
  `snapToGrid: Boolean` (both `@Volatile`, default false); new fields
  `editSizeLabel: TextView`, `editOpacityRow: LinearLayout` for the
  restructured per-item editor bar.
- New constants `PREF_GRID_SIZE`/`PREF_SHOW_GRID`/`PREF_SNAP_GRID`,
  loaded in `onCreate()` and included in the Advanced settings
  "Reset settings to defaults" block.
- New functions `snapPositionToGrid()`, `snapScaleToGrid()`,
  `drawGrid()`, `showGridSettingsDialog()`; new paint `gridLinePaint`.
  `drawEditOverlay()` now calls `drawGrid()`.
- Removed function `drawFfOverlay()` and its `hudPaint`; removed the
  `if (fastForwardActive) drawFfOverlay(canvas)` call in `renderFrame()`.
  `formatSpeed()` (which it used) is unchanged and still used elsewhere.
- Editor top bar (`editTopBar`) and per-item bar (`editButtonBar`, now
  `LinearLayout.VERTICAL` with three stacked rows instead of one
  horizontal strip) relabeled — emoji/dingbat glyphs removed throughout;
  "Reset All" renamed "Reset Controls"; new "Grid" entry added. See
  CHANGELOG.md item 5 for the full before/after label list.
- `onEditTouch()`'s `ACTION_DOWN`: now also sets `editSizeLabel.text`
  (contextual "Game Screen Size"/"Control Size") and
  `editOpacityRow.visibility` (hidden for `"gamescreen"`).
- `updateEditButtonBarLockIcon()`, `adjustSelectedScale()`/
  `adjustSelectedAlpha()`'s lock toasts, `confirmResetAllLayout()`'s
  toast, `showRemoveButtonMenu()`/`removeButton()`'s menu/toast text,
  and the Input-settings "Edit Button Layout…" button: emoji removed,
  wording updated to match the renamed top-bar buttons.

## Unchanged (confirmed byte-identical to the input zip)

`LinkMultiplayer.kt`, `RomBrowserActivity.kt`, `EmulatorEngine.kt`,
`RomZipUtils.kt`, `SharedUi.kt`, `mgba_jni.c`, `AndroidManifest.xml` —
multiplayer/emulator-core functionality untouched, as required.

---



## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Real compile error, caught by an attached CI build log — see
BUGS_FIXED.md/CHANGELOG.md.
**What changed:**
- Removed one duplicate `/**` immediately above `applyLayoutSettings()`'s
  doc comment (introduced last pass; the comment's actual content and the
  function itself are unchanged).

---

# FILE_CHANGES — Thirty-seventh pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Six related requests around fast-forward, the game screen, and
Fullscreen — see CHANGELOG.md/BUGS_FIXED.md for the full descriptions.
**What changed:**
- Game loop (`startGameLoop()`): the buffer-publish step
  (`synchronized(bufferLock) { readyIdx = ...; writeIdx = ... }`) moved
  from unconditional to only running on the branch where `backBmp` was
  actually rendered into — fixes the white-flash bug.
- New field `gameScreenRect`; removed fields `fullscreenMode`; removed
  constants `CTRL_FRAC_FULL`, `PREF_FULLSCREEN`.
- `updateGameMatrix()`: now resolves `"gamescreen"`'s rect via
  `resolvedRect()` (the same function every button's own position
  resolves through) instead of a fixed top-left region sized by
  `gameScreenFraction`/`fullscreenMode` directly.
- `buildControlLayout()`: calls `updateGameMatrix(sw, sh)` internally at
  its own end now; three external call sites that used to pair the two
  calls manually (`startGameLoop()`, `surfaceChanged()`,
  `applyLayoutSettings()`) simplified to just the one call.
- `labelFor()`, `editRectFor()`, `hitTestEditable()`: each gained a
  `"gamescreen"` case (label "Game Screen"; rect from `gameScreenRect`;
  hit-tested last, after every real button).
- `showRemoveButtonMenu()`: guarded against `id == "gamescreen"`.
- `resetSingleButton()` needed no changes — already called
  `buildControlLayout()`, which now updates the screen too, for free.
- FF button (`onGameTouch()`'s `ACTION_DOWN`/`ACTION_UP`): tap-vs-hold
  disambiguation added (new field `ffLongPressPending`) — a tap still
  toggles fast-forward instantly-feeling (resolved on `ACTION_UP` now
  rather than `ACTION_DOWN`), a hold opens the new
  `showFastForwardSpeedSlider()` instead. FF button's drawn label:
  dropped the "» 4×" active-speed text, kept the existing color/fill
  on/off indicator.
- New `showFastForwardSpeedSlider()`.
- `showVideoSettings()`: removed the Fullscreen checkbox entirely; fixed
  "Screen size" to also hide `settingsMenuOverlay` (not just dismiss its
  own popup) before entering the editor.
- Controls background draw and idle-alpha calc: `fullscreenMode`
  conditionals removed (background always draws now; idle alpha is
  always `buttonBaseAlpha`, no fullscreen-specific dim).
- "Reset settings" handler (Misc): `fullscreenMode`/`PREF_FULLSCREEN`
  removed; `stretchToFit`/`maxFrameSkips`/`linearFilterEnabled` (and
  their prefs) added — these three had been missing from this handler
  since they were introduced two passes ago, noticed while removing
  `fullscreenMode` from the same list.
- Settings sidebar's Video row subtitle: "...& fullscreen" →
  "...& effects".

---

# FILE_CHANGES — Thirty-sixth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Real compile error, caught by an attached CI build log — see
BUGS_FIXED.md/CHANGELOG.md.
**What changed:**
- Added `@Volatile private var linearFilterEnabled = false`, declared
  next to `stretchToFit`/`maxFrameSkips`. Corrected a comment nearby
  (`updateLinearFilterPaint()`'s doc comment) that had incorrectly
  described this field as already existing before this pass.

---

# FILE_CHANGES — Thirty-fifth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Video settings rebuild, Max frame skips implementation, Turbo A/B
sizing — all requested directly. Full description in CHANGELOG.md.
**What changed:**
- New `gamePaint` (shared, mutable `Paint`) and `updateLinearFilterPaint()`;
  the game bitmap's `canvas.drawBitmap(bmp, gameMatrix, null)` now passes
  `gamePaint` instead of `null`. Called once after prefs load and again
  from the new Linear filtering checkbox's toggle handler.
- New fields: `consecutiveFrameSkips`, `lastFrameLoopStartNs`,
  `frameBudgetNs`. Reset alongside `ffFrameAccumulator` wherever the game
  loop (re)starts.
- `startGameLoop()`: computes `behindSchedule` from the gap since the
  previous iteration's own `t0`; the `framesToRun == 1` branch now chooses
  `nativeRunFrame(null)` vs `nativeRunFrame(backBmp)` based on
  `maxFrameSkips`/`behindSchedule`/`consecutiveFrameSkips` instead of
  always blitting.
- `buildControlLayout()`: Turbo A/B's `tSz` raised `abSz * 0.55f` →
  `abSz * 0.75f`.
- Both button-resize `coerceIn` call sites (toolbar +/- and pinch gesture):
  `4.0f` → `8.0f` max.
- `showVideoSettings()` rewritten entirely (list layout, see CHANGELOG.md).
  New helpers `videoListRow()`, `videoCheckRow()`, `videoDivider()`,
  `roundedDialogBackground()` (the last one also a straight extraction of
  a `GradientDrawable` pattern that was previously copy-pasted at several
  other dialog call sites — same styling, one place now instead of many).
- New `showScreenOrientationDialog()`, `showMaxFrameSkipsDialog()`.

---

# FILE_CHANGES — Thirty-fourth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Turbo A/B rework and fast-forward audio quality — both requested
directly. Full description of both in CHANGELOG.md. (The other two things
reported this pass — cutout black area, fast-forward lag — were
investigated but not code-changed; see CHANGELOG.md items 3–4 and
KNOWN_LIMITATIONS.md.)
**What changed:**
- `extraControlIds`: added `"ta"`, `"tb"` at the front of the list.
- `allControlIds()`: removed the `if (turboButtonsEnabled) { ids += "ta"; ids += "tb" }`
  special case — now fully covered by `ids += extraControlIds`.
- `buildControlLayout()`: the Turbo A/B block's `if (turboButtonsEnabled)`
  wrapper removed — `addButton("ta", ...)`/`addButton("tb", ...)` now
  called unconditionally, same pattern every other extra control already
  used (visibility is `addButton()`'s own internal `isButtonVisible()`
  check). Button face text changed `"T"`/`"T"` → `"A"`/`"B"`.
- Removed: `turboButtonsEnabled` field, `PREF_TURBO` constant, its
  SharedPreferences load line, and the whole "⚡ Turbo A / Turbo B
  buttons" checkbox block in `showInputSettings()` (including the now-
  unused local `prefs` variable that block was the only user of).
- `turboHalfPeriodMs`: `66L` → `30L`.
- `decimateForFastForward()`: rewritten from box-filter averaging to a
  one-pole low-pass (continuous IIR state across the whole accumulated
  block) followed by direct every-`factor`th-sample downsampling. Return
  value / output-count math (`accumPairs / factor`) unchanged — only how
  each output sample's value is computed changed, not how many get
  produced or how long `writePcm()` ends up blocking for.

---

# FILE_CHANGES — Thirty-third pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** Live memory viewer feature — see FEATURES_ADDED.md.
**What changed:**
- New `nativeReadMemory()`, placed directly after `nativeReadAudioSamples()`
  (same "caller allocates a Java array, native fills it" shape). Loops
  `core->busRead8(core, address + i)` for `length` bytes into the caller's
  `jbyteArray` via `GetByteArrayElements`/`ReleaseByteArrayElements`,
  entirely inside `g_core_mutex`. Returns 0 (buffer untouched) if the core
  isn't initialised or `length` isn't positive; otherwise always returns
  `length`.

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Same feature — the Kotlin-side declaration for the function above.
**What changed:**
- New `external fun nativeReadMemory(address: Int, buf: ByteArray, length: Int): Int`,
  added after `nativeReadAudioSamples`.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Both requests this pass. Full description of the memory viewer in
FEATURES_ADDED.md; the cutout change in CHANGELOG.md.
**What changed:**
- Cutout handling in `onCreate()` upgraded: `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS`
  on API 30+, falling back to the previous `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES`
  on API 28–29 (unchanged below that).
- New fields: `memoryViewerOverlay`, `memoryDumpText`, `memoryAddressText`,
  `memoryRegionIndex`, `memoryPageOffset`.
- New `MemRegion` data class and `memRegions` list (EWRAM/IWRAM/Palette/
  VRAM/OAM, standard GBA memory map addresses).
- New functions: `showMemoryViewer()`, `hideMemoryViewer()`,
  `scheduleMemoryRefresh()` (self-rescheduling `Handler.postDelayed()`
  loop, guarded by `isFinishing || isDestroyed` and the overlay's own
  visibility, same shape as this file's other posted-completion guards),
  `refreshMemoryDump()`, `formatHexDump()`, `buildMemoryViewer()`.
- `onCreate()`: `memoryViewerOverlay` built and attached to `root`, same
  pattern as `settingsMenuOverlay` right above it.
- `showGameMenu()`: new "Memory" item appended right before "Close" (so
  every other item's index is unchanged), added to `needsRom`, dispatches
  to `showMemoryViewer()`.

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** Cutout fix — this Activity is new this overall changeset and
never had any cutout handling at all.
**What changed:**
- Added import `android.view.WindowManager`.
- `onCreate()`: same `ALWAYS`/`SHORT_EDGES` pair MainActivity now has,
  added before `setContentView()`.

---

# FILE_CHANGES — Thirty-second pass

## Added

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** ROM selection needed to be a real, statically Portrait-locked
Activity instead of an overlay inside MainActivity's window — see
FEATURES_ADDED.md for the full reasoning.
**What it contains:** Everything that used to be
`buildRomBrowser()`/`openRomBrowserAtRoot()`/`romBrowserUp()`/
`refreshRomBrowserList()`/`renderRomBrowserList()`/`romBrowserMessageRow()`/
`romBrowserRow()`/`buildBrowserStack()` inside `MainActivity.kt` (Thirty-
first pass), adapted to standalone-Activity shape: `setResult()`+`finish()`
instead of toggling overlay visibility; its own `onCreate()` (builds the
UI, wires an `OnBackPressedCallback` for folder-aware Back, then calls
`ensureBroadFileAccess { openAtRoot() }`); its own copies of
`pendingFileAccessAction`/`legacyStoragePermissionLauncher`/
`allFilesAccessLauncher`/`hasBroadFileAccess()`/`ensureBroadFileAccess()`/
`romPicker`/`pickerLive` (moved from `MainActivity.kt`, not duplicated —
`MainActivity.kt` no longer has its own copies); its own
`PREF_ROMS_LAST_FOLDER` constant (private to this Activity now — nothing
else needs it). UI is full-screen edge-to-edge again, not the
centered/width-capped "panel over a dimmed backdrop" Thirty-first pass
built — that trick existed specifically to fake a Portrait look inside an
actually-Landscape window, which is no longer the situation now that this
Activity's whole window really is Portrait.

### `app/src/main/kotlin/com/mgba/android/RomZipUtils.kt`
**Why:** `isZipSignature()`/`zipContainsGba()` needed to be callable from
two different classes now (`MainActivity.stageRomFile()` and
`RomBrowserActivity`'s listing) instead of one.
**What it contains:** `object RomZipUtils` with both functions, moved
out of `MainActivity.kt` verbatim except `zipContainsGba()` now takes a
`ContentResolver` parameter explicitly instead of implicitly using an
Activity's own `contentResolver` property.

### `app/src/main/kotlin/com/mgba/android/SharedUi.kt`
**Why:** `dp()`, `uiToast()`, `colorAccentLight`, `iconChipBackground()`
needed to be usable from `RomBrowserActivity` too.
**What it contains:** The same four, moved out of `MainActivity.kt` as
top-level `Context`/`Activity` extension functions/properties (package-
level, not a shared base class — every existing unqualified call site in
`MainActivity.kt`, e.g. `dp(20)`, keeps compiling unchanged since these
now live in the same package instead of being that class's own private
members).

## Modified

### `app/src/main/AndroidManifest.xml`
**Why:** `RomBrowserActivity` needs its own manifest entry to declare a
static Portrait lock.
**What changed:** New `<activity android:name=".RomBrowserActivity"
android:exported="false" android:screenOrientation="portrait"/>` entry,
with a comment explaining why (see FEATURES_ADDED.md).

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Same feature — see FEATURES_ADDED.md.
**What changed:**
- Removed: `isZipSignature()`, `zipContainsGba()` (→ `RomZipUtils.kt`);
  `dp()`, `iconChipBackground()`, `colorAccentLight`, `uiToast()`
  (→ `SharedUi.kt`); `romTreePicker`'s already-removed successor —
  `pendingFileAccessAction`/`legacyStoragePermissionLauncher`/
  `allFilesAccessLauncher`/`hasBroadFileAccess()`/`ensureBroadFileAccess()`/
  `romPicker`/`pickerLive` (→ `RomBrowserActivity.kt`); every ROM-browser
  UI field and function (`romBrowserOverlay`, `romBrowserListLayout`,
  `romBrowserPathText`, `romBrowserBackBtn`, `romBrowserDeviceRoot`,
  `romBrowserStack`, `romBrowserGeneration`, `buildBrowserStack()`,
  `openRomBrowserAtRoot()`, `romBrowserUp()`, `refreshRomBrowserList()`,
  `renderRomBrowserList()`, `romBrowserMessageRow()`, `romBrowserRow()`,
  `buildRomBrowser()` — all → `RomBrowserActivity.kt`); `PREFS` constant
  (→ top-level in `SharedUi.kt`); `PREF_ROMS_LAST_FOLDER` constant
  (→ private in `RomBrowserActivity.kt`, nothing else needs it); imports
  `android.os.Environment`, `android.provider.Settings`,
  `java.io.BufferedInputStream` (all now unused here — their only call
  sites moved out).
- `stageRomFile()` now calls `RomZipUtils.isZipSignature(input)` instead
  of a local function; otherwise unchanged.
- `changeRom()` reduced to one line:
  `romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))`.
- New `romBrowserLauncher` (`ActivityResultContracts.StartActivityForResult()`)
  — on `RESULT_OK`, hands `result.data?.data` to the existing, unchanged
  `loadRomFromUri()`; does nothing on `RESULT_CANCELED`, same
  surface-sits-idle behavior as before.
- `onCreate()`: no longer builds/attaches a ROM browser overlay to `root`
  (nothing to build here now).
- Six stale comments fixed, all left over from earlier passes and made
  more obviously wrong by this one: the floating-Load-ROM-button removal
  note in `onCreate()` (referenced `romBrowserOverlay`); the "land
  straight in" comment right before `changeRom()`'s call site in
  `onCreate()` (described a flow this file no longer has any part of);
  `surfaceChanged()`'s resize comment (claimed ROM selection forces a
  Portrait switch — hasn't been true since Thirty-first pass); the
  Storage-folder feature's "deliberately SAF" comment (justified itself
  by comparison to the ROM browser's *old* reasoning, which the ROM
  browser no longer uses); `onGameTouch()`'s comment (referenced
  `romBrowserOverlay`'s `isClickable` guard, which doesn't exist to
  reference anymore); `applyScreenOrientationPref()`'s try/catch history
  comment (referenced `openRomBrowserAtRoot()`/`buildRomBrowser()` call
  sites that no longer exist in this file).

---

# FILE_CHANGES — Thirty-first pass

## Modified

### `app/src/main/AndroidManifest.xml`
**Why:** Requested feature — free-roam file manager needs broad local
storage access; see FEATURES_ADDED.md.
**What changed:**
- Replaced the old "READ_EXTERNAL_STORAGE removed, unused" comment block
  with one explaining the new permissions and why the old reasoning no
  longer applies.
- Added `<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>`
  and `<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>`.
- Added `android:requestLegacyExternalStorage="true"` to `<application>`
  — only takes effect on exactly API 29, harmless/ignored elsewhere.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Same feature, plus the portrait-panel styling — both requested
directly. Full description in FEATURES_ADDED.md.
**What changed:**
- Added imports: `android.os.Environment`, `android.provider.Settings`.
- Removed `romTreeUri` field, `romTreePicker` (the `OpenDocumentTree`
  launcher), and the `PREF_ROMS_TREE_URI` constant.
- Added `PREF_ROMS_LAST_FOLDER` constant (plain path string, replaces the
  removed tree-Uri pref).
- Added `pendingFileAccessAction`, `legacyStoragePermissionLauncher`,
  `allFilesAccessLauncher`, `hasBroadFileAccess()`, `ensureBroadFileAccess()`
  — mirrors the existing `ensureBluetoothPermission()` pattern. The All
  Files Access launch is wrapped in try/catch: the per-app Settings
  intent (`ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION`) isn't shipped
  by every OEM skin, falls back to the general
  `ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION` screen.
- `changeRom()` simplified to `ensureBroadFileAccess { openRomBrowserAtRoot() }`.
- `romBrowserStack` is now `MutableList<File>` (was `MutableList<DocumentFile>`).
- Added `romBrowserDeviceRoot` (`Environment.getExternalStorageDirectory()`,
  lazily cached) and `buildBrowserStack(target)`, which walks `File.parentFile`
  from a target back up to the device root to reconstruct the navigation
  stack — used to restore the last-browsed folder on reopen.
- `openRomBrowserAtRoot()` rewritten: reads `PREF_ROMS_LAST_FOLDER`,
  validates it's still a real directory, falls back to the device root
  if not, builds the stack via `buildBrowserStack()`.
- `refreshRomBrowserList()`: `current.listFiles()` (nullable for
  `java.io.File`, unlike `DocumentFile`) now falls back to `emptyArray()`;
  persists the current folder to `PREF_ROMS_LAST_FOLDER` on every
  navigation; breadcrumb text shows "Internal storage" for the root
  entry instead of its raw folder name. Zip-candidate scanning
  (Thirtieth pass) unchanged in structure, just calls
  `zipContainsGba(Uri.fromFile(f))` instead of `zipContainsGba(doc.uri)`.
- `renderRomBrowserList()`'s parameter type updated to `List<File>`.
- `romBrowserRow()` rewritten for `File` instead of `DocumentFile` —
  functionally identical (directory → drill in, file → `loadRomFromUri(Uri.fromFile(file))`),
  simpler in one respect: `File.name` isn't nullable, so the old
  `doc.name ?: "?"` fallback is gone.
- `buildRomBrowser()` return type changed from `LinearLayout` to
  `FrameLayout`; `romBrowserOverlay`'s declared type updated to match.
  The existing header/pathRow/list/fallback content is now built into a
  `panel` (rounded corners via `GradientDrawable`, `#FF17171B` background,
  same as before) with a computed max width
  (`dp(420).coerceAtMost(94% of screen width)`), centered inside a new
  outer `FrameLayout` with a `#CC000000` dimmed backdrop.
- Header's "📂 Change folder" button replaced with "🏠 Root" (clears
  `romBrowserStack` back to just `romBrowserDeviceRoot`).
- Updated three stale comments left pointing at the removed
  `romTreePicker`/`PREF_ROMS_TREE_URI`: the block comment above
  `openRomBrowserAtRoot()` (kept the original reasoning for the record,
  marked superseded, explained why); the Storage-folder feature's own
  explanatory comment a few hundred lines earlier, which referenced
  `romTreePicker` only as a same-mechanism comparison; and the
  `onCreate()` comment describing the "land straight in" startup flow.

---

# FILE_CHANGES — Thirtieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Requested feature — the ROM browser's `.zip` filtering should be
based on what's actually inside the archive, not its extension. Full
description in FEATURES_ADDED.md.
**What changed:**
- New `isZipSignature(input: BufferedInputStream): Boolean` — the exact
  magic-bytes check `stageRomFile()` used to do inline, now shared.
  `stageRomFile()` calls it instead of repeating the byte comparison; no
  behavior change there.
- New `zipContainsGba(uri: Uri): Boolean` — same check, but only peeks
  for a `.gba` entry name and returns the instant it finds one; never
  writes anything to disk.
- `refreshRomBrowserList()` rewritten: `current.listFiles()` is now split
  into `immediate` (directories + bare `.gba` files, rendered right away,
  same sort as before) and `zipCandidates` (`.zip` files, not yet shown).
  If there are no zip candidates, the visible result is unchanged
  end-to-end. If there are, a background `Thread` named
  `"mGBA-rom-zip-scan"` calls `zipContainsGba()` on each — each check
  wrapped in its own try/catch so one unreadable/corrupt zip can't abort
  the rest of the scan — then posts back to the main thread and merges
  whichever passed into the visible list.
- New `romBrowserGeneration` field (`@Volatile Int`, declared with this
  browser's other fields near the top of the class), bumped at the start
  of every `refreshRomBrowserList()` call. The posted completion checks
  it against the value captured when its own scan started, and bails out
  if the user has since navigated elsewhere (or the Activity is
  finishing/destroyed) — same shape as `loadRomFromUri()`'s own
  posted-completion guard, including the explicit `post label@ { }` style
  rather than the implicit `@post` label.
- New `renderRomBrowserList(entries, stillScanning)` — the actual list
  rendering, extracted out of `refreshRomBrowserList()` so both the
  immediate render and the post-scan re-render share one code path. When
  `stillScanning` is true, an empty `entries` does *not* trigger the "No
  ROMs or folders here" empty state (a folder holding only zip candidates
  would otherwise flash that message right before the scan fills it in)
  — the list shows a trailing "Checking archives…" row instead.
- New `romBrowserMessageRow(message)` — small shared helper for that row
  and the pre-existing empty-state message, which used to have its
  `TextView` styling written out inline once.
- Removed `romRelevantExtensions` (the `.zip`/`.gba` list). Its two
  extensions now need different treatment — one renders immediately, one
  needs verification first — so a single list checked identically for
  both no longer fit. Both extensions are still checked, just inline at
  their own now-separate call sites, matching how `stageRomFile()` already
  checks `.gba` as a string literal rather than a named constant.

---

# FILE_CHANGES — Twenty-ninth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** Code audit found `g_link_obj`/`g_link_xchg_mid`/`g_link_is_host`
written outside `g_core_mutex` despite being read under it everywhere
else. See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- `nativeLinkStart()`: `GetObjectClass()`/`GetMethodID()` still run before
  the lock (pure JNIEnv calls, no shared state touched); `NewGlobalRef()`
  now happens before the lock too but is only *assigned* to `g_link_obj`
  after `pthread_mutex_lock(&g_core_mutex)`, alongside `g_link_xchg_mid`
  and `g_link_is_host`. The old unconditional `DeleteGlobalRef` of any
  previous `g_link_obj` at the top of the function moved to right after
  the lock, immediately before the new one is assigned.
- `nativeLinkStop()`: the `if (g_link_obj) { DeleteGlobalRef; ... }` and
  `g_link_xchg_mid = NULL;` lines moved from after
  `pthread_mutex_unlock(&g_core_mutex)` to before it.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Code audit found `showSaveStateSlotDialog()`'s save/load action
had the same unsynchronized-Thread race an earlier pass already fixed for
Quick Save/Quick Load, just never extended here. See CHANGELOG.md/
BUGS_FIXED.md.
**What changed:**
- Renamed `quickStateBusy` → `saveStateBusy` (`AtomicBoolean`); updated
  its doc comment to describe the broader scope. `quickSaveState()`/
  `quickLoadState()`'s existing `compareAndSet`/`.set(false)` calls
  updated to the new name, no other change to either function.
- `showSaveStateSlotDialog()`'s `setAdapter` callback: added the same
  `if (!saveStateBusy.compareAndSet(false, true)) { uiToast(...); return@setAdapter }`
  guard, right after the existing empty-slot check and before the
  save/load `Thread` is spawned. Wrapped that `Thread`'s body in
  `try { ... } finally { saveStateBusy.set(false) }` so the guard always
  clears, success or failure — mirrors `quickSaveState()`'s own
  `try/finally` shape exactly.

---

# FILE_CHANGES — Twenty-seventh pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested against Dragon Ball Z: Supersonic Warriors with a
fresh matched capture and confirmed the communication error appears during
the post-handshake quiet stretch, before this file's own retry gives up.
See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `g_link_last_sio_rcnt`, `g_link_last_sio_siocnt`,
  `g_link_sio_mode_logged` next to the other pre-declared link globals
  (FIX 8's block, for the same "used before declared" reason as that one).
- `nativeRunFrame()`: right after the existing `g_core->runFrame(g_core);`
  / `g_link_driver.env = NULL;` pair, added a guarded block that reads
  `g_link_gba->sio.rcnt` and `g_link_gba->sio.siocnt` directly and logs
  them (tagged `SIO mode`, distinct from the existing `SIO write` tag)
  only when either value has changed since the last check.
- `nativeLinkStart()`: added `g_link_sio_mode_logged = false;` next to the
  existing FIX 20/21 reset lines, so every session logs a fresh baseline.
- Added a FIX 22 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-21.



## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested FIX 20 on a real device (fresh matched capture
attached) and separately reported Dragon Ball Z: Supersonic Warriors
failing instantly with "communication error" plus lag. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `LINK_PACE_WINDOW_NS` (3s), `g_link_pace_window_start`,
  `g_link_pace_window_active`, and `link_pace_arm_window()`.
- `link_pace_exchange()`: now returns immediately (no clock read) when no
  window is armed; when one is armed, checks whether it's expired first
  (clearing `g_link_pace_window_active` and returning if so) before
  falling through to FIX 20's original interval-pacing logic unchanged.
- `nativeLinkStart()`: now calls `link_pace_arm_window()` right after the
  existing `g_link_last_exchange_set = false;` line.
- `link_sio_write_register()`: added a new `address == 0x134u` branch
  (RCNT was previously unhandled — the function only special-cased 0x12A
  and 0x128) that calls `link_pace_arm_window()`, placed before the
  existing `if (address != 0x128u) return value;` line so it applies on
  every RCNT write regardless of value or role.
- Added a FIX 21 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-20.

---

# FILE_CHANGES — Twenty-sixth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested FIX 20 on a real device (fresh matched capture
attached) and separately reported Dragon Ball Z: Supersonic Warriors
failing instantly with "communication error" plus lag. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `LINK_PACE_WINDOW_NS` (3s), `g_link_pace_window_start`,
  `g_link_pace_window_active`, and `link_pace_arm_window()`.
- `link_pace_exchange()`: now returns immediately (no clock read) when no
  window is armed; when one is armed, checks whether it's expired first
  (clearing `g_link_pace_window_active` and returning if so) before
  falling through to FIX 20's original interval-pacing logic unchanged.
- `nativeLinkStart()`: now calls `link_pace_arm_window()` right after the
  existing `g_link_last_exchange_set = false;` line.
- `link_sio_write_register()`: added a new `address == 0x134u` branch
  (RCNT was previously unhandled — the function only special-cased 0x12A
  and 0x128) that calls `link_pace_arm_window()`, placed before the
  existing `if (address != 0x128u) return value;` line so it applies on
  every RCNT write regardless of value or role.
- Added a FIX 21 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-20.

---

# FILE_CHANGES — Twenty-fifth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User-reported, with a fresh matched host+child capture attached:
multiplayer still doesn't connect, now confirmed (by the user, not a log)
to be an app-side issue rather than a ROM-side one. See CHANGELOG.md/
BUGS_FIXED.md/KNOWN_LIMITATIONS.md for the full reasoning.
**What changed:**
- Added `LINK_PACE_EXCHANGES` (default on), `LINK_GBA_CYCLES_PER_FRAME`,
  `LINK_MIN_EXCHANGE_INTERVAL_NS`, `g_link_last_exchange_ts`,
  `g_link_last_exchange_set`, and `link_pace_exchange()` — a small,
  self-contained, OFF-able block placed immediately before `link_exchange()`.
- `link_pace_exchange()` is called at the top of `link_sio_write_register()`'s
  existing host Start-bit branch, immediately before the existing call to
  `link_exchange()` — no other line in that branch changed.
- `nativeLinkStart()`: added one line, `g_link_last_exchange_set = false;`,
  next to the existing `g_link_driver.localSend = 0xFFFFu;` reset, so a new
  connection attempt never paces its first exchange against a stale
  timestamp from a previous session.
- Added a new FIX 20 entry to the file's own top-of-file history comment,
  in the same style/detail as FIX 1-19.



## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: menu Save State/Load State feels slow, both
opening the slot picker and confirming after picking a slot. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Hoisted the `SlotInfo` data class out of `showSaveStateSlotDialog()` to
  a private class-level declaration (now carries `modified: Long` too),
  and added `slotInfoCache: ConcurrentHashMap<String, SlotInfo>` keyed by
  `"$currentRomBaseName:$slot"`.
- `showSaveStateSlotDialog()`: each slot now checks `slotInfoCache` before
  reading/decoding its thumbnail; only re-decodes when `exists`/`modified`
  no longer match the cached entry.
- Added `SaveEntry.moveInto(dest)`: renames `legacy` into `dest.legacy`
  when neither entry uses a Storage folder (deleting any existing `dest`
  first), falling back to the old copy-based behavior otherwise.
- `backupIfExists()` now calls `entry.moveInto(entry.backupEntry())`
  instead of doing its own read/write copy.

---

# FILE_CHANGES — Twenty-fourth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: menu Save State/Load State feels slow, both
opening the slot picker and confirming after picking a slot. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Hoisted the `SlotInfo` data class out of `showSaveStateSlotDialog()` to
  a private class-level declaration (now carries `modified: Long` too),
  and added `slotInfoCache: ConcurrentHashMap<String, SlotInfo>` keyed by
  `"$currentRomBaseName:$slot"`.
- `showSaveStateSlotDialog()`: each slot now checks `slotInfoCache` before
  reading/decoding its thumbnail; only re-decodes when `exists`/`modified`
  no longer match the cached entry.
- Added `SaveEntry.moveInto(dest)`: renames `legacy` into `dest.legacy`
  when neither entry uses a Storage folder (deleting any existing `dest`
  first), falling back to the old copy-based behavior otherwise.
- `backupIfExists()` now calls `entry.moveInto(entry.backupEntry())`
  instead of doing its own read/write copy.

---

# FILE_CHANGES — Twenty-third pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: Quick Save/Quick Load racing each other during
fast save/load testing. See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `quickStateBusy: AtomicBoolean`, shared by `quickSaveState()` and
  `quickLoadState()`.
- Both functions now `compareAndSet(false, true)` at the top and bail out
  with a "Still saving/loading" toast if another call is already in
  flight, instead of unconditionally spawning a new `Thread`.
- Both `Thread { ... }` bodies wrapped in `try/finally` so
  `quickStateBusy` is always cleared, including the existing early
  `return@Thread` in `quickLoadState()` for "No quick save yet".

---

# FILE_CHANGES — Twenty-second pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: a stray "Load ROM" button rendering on top of the
ROM browser (screenshot provided), and Save State feeling slow. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Removed the `loadRomBtn` field, its `Button` construction, and its
  `root.addView(...)` call in `onCreate()` entirely.
- Removed the two `loadRomBtn.visibility = ...` calls left over from the
  ROM-load success/failure paths, and the one in `closeGame()`.
- `onGameTouch()`: now returns early on `ACTION_UP` with `changeRom()`
  whenever `!romLoaded`, replacing the button as the way back into ROM
  selection when nothing else is on screen.
- `showSaveStateSlotDialog()`: moved the "Saved to Slot N"/"Loaded Slot
  N"/failure `uiToast(...)` call to fire immediately after
  `nativeSaveState()`/`nativeLoadState()` returns, ahead of
  `captureStateThumbnail(slot)` rather than after it.
- Updated the doc comments on `changeRom()`, `onCreate()`'s closing block,
  and `closeGame()` that referenced `loadRomBtn` by name.

---

# FILE_CHANGES — Twenty-first pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** real-device bug report — Storage folder feature broke save/load.
See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Removed `NativeHandle` and `SaveEntry.nativePath()` — the `/proc/self/fd/<N>`
  bridge in its entirety.
- `SaveEntry.outputStream()`: now opens with explicit `"wt"` mode (was the
  2-arg `openOutputStream(uri)` default), so a write shorter than the
  previous save can't leave stale trailing bytes on providers that don't
  truncate on plain `"w"`.
- New `SaveEntry` methods: `stageForRead()`, `stageForWrite()`,
  `commitWrite()` (one-shot save-state/quicksave/thumbnail read/write —
  stage a SAF document's bytes to/from a local cache file, native only
  ever touches the local file) and `batteryMirrorPath()`,
  `syncBatteryMirror()` (session-long battery save — local mirror file the
  core mmaps for the whole session, synced out to the real document at a
  handful of call sites, not continuously).
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`: rewired
  from `entry.nativePath(...).use { }` to the new stage/commit methods.
- `loadRomFromUri()`/`resetGame()`: rewired from `saveEntry.nativePath(...)`
  to `saveEntry.batteryMirrorPath()`; `loadRomFromUri()` also now syncs the
  *outgoing* ROM's mirror before swapping in a new one.
- `onPause()`/`onDestroy()`/`closeGame()`: each now calls
  `syncBatteryMirror()` for the currently-loaded ROM, so the chosen
  folder's copy doesn't just sit stale until the app happens to reload a
  ROM again.

---

# FILE_CHANGES — Twentieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** new Storage-folder feature — see CHANGELOG.md/FEATURES_ADDED.md.
**What changed:**
- New `PREF_DATA_FOLDER_URI`, `dataFolderPicker` (SAF tree picker, mirrors
  the existing `romTreePicker`), `dataFolderTree()`, `dataSubfolder()`.
- New `SaveEntry` (inner class) + `NativeHandle`: the abstraction that
  lets every save-adjacent file live in either internal storage or the
  chosen folder transparently, including the `/proc/self/fd/<N>` bridge
  for native calls — see that class's own comment for the full mechanism.
- `batterySaveEntry()`/`stateSlotEntry()`/`stateThumbEntry()`/
  `quickStateEntry()`: thin wrappers over the existing (now "legacy",
  still the fallback) `batterySaveFile()`/`stateSlotFile()`/
  `stateThumbFile()`/`quickStateFile()`.
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`/
  `captureStateThumbnail()`/`backupIfExists()`/both `nativeLoadROM()` call
  sites (initial load + `resetGame()`): rewired from raw `File` to
  `SaveEntry`.
- `saveScreenshotBitmap()`: writes into the `screenshot` subfolder when a
  folder's chosen; unchanged `getExternalFilesDir()` fallback otherwise.
- New `showStorageSettings()` + a "Storage" row in the Settings menu.

---

# FILE_CHANGES — Nineteenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** This pass's two log captures covered different real-world spans
with no quick way to tell how different, or why.
**What changed:** `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line (same layout as the log's own timestamps) to
the text before it's shown/copied.

### `app/src/main/cpp/mgba_jni.c`
**Why:** record-keeping only.
**What changed:** New FIX 19 entry in the top-of-file history noting
Eighteenth pass's fix showed no observed change in this capture, and
pointing at the MainActivity.kt change above. No logic changed in this
file this pass.

---

# FILE_CHANGES — Eighteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** First real matched two-phone capture (see CHANGELOG.md/
KNOWN_LIMITATIONS.md) confirmed the network exchange is correct in both
directions, narrowing the still-open bug to the child ROM's own code.
Re-reading `nativeLinkChildExchange()` against that finding turned up a
gap the function's own comment already admitted: it never touched the
child device's own SIOCNT.
**What changed:**
- `nativeLinkChildExchange()`: after writing SIOMULTI0-3 and before
  raising the IRQ, now reads the child's current SIOCNT and refreshes
  bits 2 (child), 3 (ready), 4-5 (player ID), and clears bit 7 (busy) —
  preserving every other bit (mode, baud rate, IRQ-enable) exactly as the
  ROM last set it.
- Updated that function's own top comment (previously said it
  "deliberately does NOT touch SIOCNT"; no longer true).
- New FIX 18 entry in the file's top-of-file history comment.

---

# FILE_CHANGES — Seventeenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** `copyLinkDebugLog()`'s `logcat` dependency doesn't work on every
device (W's own two-phone split this pass — real output on one, nothing on
the other) and was blocking the one thing every pass since the Twelfth has
asked for: a synchronized two-phone capture. Separately, W's new
`wifi_host__1_.text`/`wifi_join__1_.text` captures (taken with Sixteenth
pass's exchange-result/child-exchange logging already in place) needed a
close read.
**What changed:**
- New includes: `<stdarg.h>`, `<stdio.h>`, `<time.h>`.
- `LOGI`/`LOGW`/`LOGE` macros now expand to a new `jni_log_line()` instead
  of calling `__android_log_print()` directly. Every existing call site in
  the file is unchanged — these are still plain macros.
- New: `g_link_log_mutex` (dedicated lock, never `g_core_mutex` — see its
  own comment for why reusing `g_core_mutex` would self-deadlock),
  `g_link_log_file`, `g_link_log_path`, `link_log_write_locked()`,
  `link_log_write()`, `jni_log_line()`. Together: every `LOGI`/`LOGW`/
  `LOGE` call now also appends a logcat-`threadtime`-formatted line to a
  private file, in addition to the normal `__android_log_print()` call
  (unchanged — Android Studio / a real debugger sees no difference).
- New: `Java_com_mgba_android_EmulatorEngine_nativeSetLinkLogPath()` —
  receives the file path from Kotlin once at startup, opens it in append
  mode.
- `nativeLinkStart()`: now re-opens the log file in truncate mode
  (`fopen(path, "w")`) at the start of every session, so a capture
  reflects one connection attempt.
- Top-of-file fix-history comment: added a FIX 17 entry covering both the
  logging infrastructure and this pass's reading of the new evidence
  (host/child value distributions, the re-check of FIX 9's bit2/bit3
  reflection, and an updated theory citing mGBA's own real lockstep
  implementation).
**Why this fixes it:** The logging change directly addresses "can't get
log on this device" — see FIX 17's own comment. It doesn't fix the
reported multiplayer bug itself; see KNOWN_LIMITATIONS.md for what this
pass's evidence actually shows and BUGS_FIXED.md for why this isn't
labeled a bug fix.
**Verification:** No NDK/Android SDK in this sandbox, as every pass — but
unlike every prior pass, this sandbox does have a plain `gcc`. The new
logging functions (`link_log_write_locked`, `link_log_write`,
`jni_log_line`, the macros, `nativeSetLinkLogPath`, and
`nativeLinkStart()`'s new truncate block) were extracted verbatim from the
edited file — not retyped — and compiled standalone against minimal
stand-ins for the Android/JNI-only pieces (`__android_log_print`, `JNIEnv`'s
`GetStringUTFChars`/`ReleaseStringUTFChars`), since the real NDK/mgba
headers aren't available here either. Compiled clean under
`gcc -Wall -Wextra -std=gnu11` (no explicit `C_STANDARD` is pinned in this
project's `CMakeLists.txt`, so this matches the NDK/Clang default
GNU-extended dialect rather than glibc's stricter plain `-std=c11`, which
does not expose `clock_gettime`/`CLOCK_REALTIME` without extra feature-test
macros — confirmed by hitting exactly that failure first and fixing the
*test's* dialect flag, not the real code, which needs no such fix under
the NDK). At runtime: opens the file, writes/reads back formatted lines
correctly, confirms a second `nativeSetLinkLogPath()` call appends rather
than truncates (per its own doc comment), and confirms `nativeLinkStart()`'s
new block does truncate. This is real verification of the new code's
syntax and logic that no prior pass in this project's history could do
("no compiler here" appears in nearly every previous pass's own
Verification section) — it is not a substitute for a real
`./gradlew assembleDebug` against the actual mgba/NDK headers, which
remains untested as always. Brace/paren counts on the full file checked
balanced before and after (68/68 braces, 363/363 parens).

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Kotlin-side declaration for the new native entry point.
**What changed:** Added `external fun nativeSetLinkLogPath(path: String):
Boolean` with a doc comment explaining when to call it and its
relationship to `nativeLinkStart()`'s truncation.
**Verification:** No Kotlin compiler in this sandbox. Signature matches
the JNI export name (`Java_com_mgba_android_EmulatorEngine_
nativeSetLinkLogPath`) exactly, following the same `Java_<package>_<class>_
<method>` pattern already proven by every other `external fun` in this
file (spot-checked against `nativeLinkStart`'s own export name). File-wide
brace/paren balance checked programmatically (comment- and string-aware,
not just a raw character count) — clean.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** See `mgba_jni.c` above — this is the Kotlin half of the same
change.
**What changed:**
- `onCreate()`: added one `EmulatorEngine.nativeSetLinkLogPath(...)` call
  right after `link = LinkMultiplayer(this)`, passing
  `File(filesDir, "link_debug.log").absolutePath`.
- `copyLinkDebugLog()`: no longer builds a `logcat` `Process` at all — now
  just reads `File(filesDir, "link_debug.log")` directly. Simpler than
  what it replaced (no `ProcessBuilder`/stream-draining/`waitFor()`), and
  removes the only place in this project that shelled out to a system
  binary for this feature.
- `showLinkDebugLogDialog()`: empty-state message updated to describe the
  new mechanism instead of the old tag-filtered-window one, including a
  pointer to check Logcat for the file-open confirmation line if the file
  is unexpectedly still empty after a real attempt.
- Doc comments above both functions rewritten to describe the new
  mechanism and reference this pass.
**Verification:** No Kotlin compiler here. Single call site of
`copyLinkDebugLog()`/`showLinkDebugLogDialog()` each, both unchanged
(quick-menu item 9 still calls `copyLinkDebugLog()` the same way). File-wide
brace/paren balance checked programmatically — clean.

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** See `mgba_jni.c` above — Fifteenth pass's 7 connection-lifecycle
log lines were logcat-only; without also mirroring them into the new file,
the file-based tool would be strictly less capable than the old
logcat-based one for anyone whose logcat access does work.
**What changed:**
- New imports: `java.io.File`, `java.text.SimpleDateFormat`,
  `java.util.Locale`.
- New `linkLog(level, msg, throwable?)` private helper: calls the normal
  `Log.i`/`Log.w`/`Log.e` (unchanged behavior for anyone watching Logcat
  directly) and additionally appends a matching line to
  `File(context.filesDir, "link_debug.log")`.
- All 7 existing `Log.i`/`Log.w` call sites (the BYE-send logging in
  `disconnect()`, the "Disconnected" line, and `handlePeerLost()`'s
  "Peer connection lost" line) now call `linkLog(...)` instead. No call
  site's actual logged content changed — only the function they go
  through.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No Kotlin compiler here. All 7 original call sites
confirmed replaced (`grep` for `Log\.` now only matches inside `linkLog()`
itself). File-wide brace/paren balance checked programmatically — clean.

---

# FILE_CHANGES — Sixteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** W's three real logcat captures (first genuine evidence in sixteen
passes) showed real exchange activity but left two specific things
unanswerable: whether the host's rapid exchange attempts were getting real
replies or timing out, and whether the child's own receive path
(`nativeLinkChildExchange()`) was ever running at all.
**What changed:**
- `link_sio_write_register()`'s host-only exchange branch: added
  `LOGI("SIO exchange result: sent=... recv=... timedOut=...")` right after
  `link_exchange()` returns.
- `nativeLinkChildExchange()`: added `LOGW` on its early-exit branch
  (previously silent) and `LOGI` on every successful call, logging both
  `hostData` and `childData`. Previously had no logging at all.
- Top-of-file fix-history comment: added a FIX 16 entry summarizing what
  the three logs actually showed and the theory (unconfirmed) that fits.
**Why this fixes it:** It doesn't fix the reported bug — it closes the two
remaining diagnostic blind spots standing between "we have activity" and
"we know what the activity means." See FIX 16's own comment and
CHANGELOG.md items 1-2.
**Verification:** No compiler/device here, as every pass. Brace/paren
counts checked balanced before and after. Both additions are pure logging
— no control flow, register values, or return values changed.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** `copyLinkDebugLog()`'s window (8000 lines, sized last pass against
boot noise) is short relative to real exchange activity's actual measured
rate this pass — `wifi_host.text` alone was 2243 lines in 1.67 seconds,
before this pass's two new trace points add more on top.
**What changed:** `logcat -t 8000` → `-t 20000`. Comment above the function
updated with the real measured numbers behind the bump.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No compiler here. Single call site of the modified
function unchanged.

---

# FILE_CHANGES — Earlier passes (summary)

Full diffs trimmed for length. File(s) touched per pass, condensed:

- **Fifteenth** — `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`:
  Sixteenth/Seventeenth pass's exchange-result/child-exchange trace
  logging groundwork, plus connection-lifecycle logging.
- **Fourteenth** — `MainActivity.kt`: compile-error fix only
  (`showLinkDebugLogDialog` parameter rename).
- **Thirteenth** — `MainActivity.kt`: save-state thumbnails.
- **Twelfth** — `MainActivity.kt`: original logcat-based "Copy link log"
  (superseded by Seventeenth pass's file-based version).
- **Eleventh** — `MainActivity.kt`: quick-menu tap regression fix.
- **Tenth** — `MainActivity.kt`: quick game menu restyle, Settings
  cleanup, immersive mode, display-cutout fix, Screenshot/Reset/Close.
- **Ninth** — `LinkMultiplayer.kt`: Wi-Fi host keepalive/liveness fix.
- **Eighth** — `mgba_jni.c`: trace logging only, no logic change.
- **Seventh** — `mgba_jni.c`: SIO IRQ raise (host + child).
- **Sixth** — `mgba_jni.c`, `EmulatorEngine.kt`, `LinkMultiplayer.kt`,
  `MainActivity.kt`: the original `nativeLinkChildExchange()` passive-
  responder fix, SIOCNT status bits, peer-disconnect detection,
  Bluetooth keepalive.
- **Fifth** — `LinkMultiplayer.kt`, `MainActivity.kt`,
  `AndroidManifest.xml`, `gradle.properties`, `README_SETUP.md`: first
  multiplayer-focused pass — thread-safety, socket cleanup, permissions.
