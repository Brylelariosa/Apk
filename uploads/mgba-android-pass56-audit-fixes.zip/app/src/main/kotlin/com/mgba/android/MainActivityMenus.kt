package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


internal fun MainActivity.buildSettingsMenu(): LinearLayout {
    val ctx = this

    val header = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(16), dp(16), dp(14))
        addView(TextView(ctx).apply {
            text = "Settings"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(TextView(ctx).apply {
            text = "✕ Close"; textSize = 13f
            setTextColor(colorAccentLight)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            isClickable = true; isFocusable = true
            background = iconChipBackground()
            setOnClickListener { settingsMenuOverlay.visibility = View.GONE }
        })
    }

    val rows = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        addView(settingsRow(SettingsGlyph.VIDEO, "Video",    "Screen size, orientation & effects") { showVideoSettings() })
        addView(settingsRow(SettingsGlyph.AUDIO, "Audio",    "Enable sound, volume & frequency")            { showAudioSettings() })
        addView(settingsRow(SettingsGlyph.GAMEPAD, "Input",    "Edit on-screen button layout")  { showInputSettings() })
        addView(settingsRow(SettingsGlyph.LAYOUTS, "Layouts",  "Save & switch named button layouts") { showLayoutsSettings() })
        addView(settingsRow(SettingsGlyph.MISC, "Misc",     "Fast-forward speed")            { showMiscSettings() })
        addView(settingsRow(SettingsGlyph.STORAGE, "Storage",  "Where saves/states/screenshots live") { showStorageSettings() })
        addView(settingsRow(SettingsGlyph.WIFI, "Link remote", "Multiplayer over Wi-Fi")     { showLinkRemoteDialog() })
        addView(settingsRow(SettingsGlyph.BLUETOOTH, "Link local",  "Multiplayer over Bluetooth") { showLinkLocalDialog() })
        addView(settingsRow(SettingsGlyph.ADVANCED, "Advanced", "Reset settings to defaults")    { showAdvancedSettings() })
        // FEATURE — direct report: "setting add debug on it you can
        // toggle rom memory viewer or link debug". See
        // showDebugSettings() for the two toggles themselves.
        addView(settingsRow(SettingsGlyph.DEBUG, "Debug",    "Memory viewer & link log toggles") { showDebugSettings() })
        addView(settingsRow(SettingsGlyph.INFO, "About",    "Version & info")                { showAboutDialog() })
    }

    return LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor("#FF17171B"))
        isClickable = true; isFocusable = true   // swallow touches — nothing behind this should be reachable
        addView(header)
        addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
        // Scrollable: this app is locked to landscape (see onCreate), so
        // available height can be quite short on a lot of phones — eleven
        // rows plus a header can easily exceed that, which would make
        // "About" unreachable without this. (Was seven rows before Change
        // ROM / Link remote / Link local moved in from floating buttons —
        // already scrollable, so they just slot in.)
        addView(ScrollView(ctx).apply { addView(rows) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
    }
}


internal fun MainActivity.settingsRow(icon: SettingsGlyph, title: String, subtitle: String, onClick: () -> Unit): View {
    val ctx = this
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        isClickable = true; isFocusable = true
        setBackgroundResource(rippleBackgroundResId())
        setPadding(dp(20), dp(14), dp(20), dp(14))
        addView(FrameLayout(ctx).apply {
            // FIX (direct report: "improve all setting icon still bit
            // bad... because there small") — 24dp matched Material's own
            // minimum icon size, but combined with this file's ~30%
            // internal padding (see SettingsIconView.onDraw's own `s`
            // calculation) that read as noticeably small/thin for a
            // full-width settings row. 28dp keeps the dp(44) column
            // comfortably centered (8dp clearance each side) while
            // giving every glyph real presence.
            addView(SettingsIconView(ctx, icon), FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT))
        addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(ctx).apply {
                text = title; textSize = 17f
                setTextColor(Color.WHITE)
            })
            addView(TextView(ctx).apply {
                text = subtitle; textSize = 12f
                setTextColor(Color.parseColor("#888892"))
                setPadding(0, dp(2), 0, 0)
            })
        })
        setOnClickListener { onClick() }
    }
}


internal fun MainActivity.showSettingsMenu() {
    settingsMenuOverlay.visibility = View.VISIBLE
}


/** Applies the *right* orientation for whatever this activity is doing
 *  right now — not just [screenOrientationChoice] in isolation. Safe to
 *  call any time, not just from onCreate — e.g. showVideoSettings()'s
 *  Save button calls this too, right after persisting a new choice.
 *  android:configChanges in the manifest already keeps this activity
 *  (and the running core) alive across whatever orientation change this
 *  triggers, rather than recreating it.
 *
 *  FIX (this pass — direct report: file browser "still landscape at
 *  first then open and then instantly go portrait"): this used to
 *  apply [screenOrientationChoice] unconditionally, every single time,
 *  including while idle with no ROM loaded — which is also the exact
 *  moment changeRom() launches RomBrowserActivity (onCreate's own first
 *  call below, and again from closeGame() right after backing out of a
 *  game). RomBrowserActivity is Portrait, hard-locked in the manifest
 *  (see its own file-header comment for why that has to stay a
 *  manifest default rather than a runtime call) — so every time this
 *  activity requested Landscape while idle, opening the browser meant
 *  an immediate landscape→portrait rotation of the physical display
 *  *during* that activity transition, which is the flash that was
 *  reported: a real frame or two of RomBrowserActivity's own window
 *  still catching up to its new orientation before it settles.
 *  overridePendingTransition(0,0) (both directions — see changeRom()
 *  below and RomBrowserActivity's finish() override) was already added
 *  last pass and helps with the *transition animation* itself, but
 *  can't fix a rotation that still has to happen at all.
 *
 *  The actual fix: stop treating the file browser and gameplay as
 *  though they share one orientation. [romLoaded] is already the
 *  single source of truth for "is a game actually running" everywhere
 *  else in this class, so it's used the same way here — Portrait while
 *  idle (which now means: cold start in onCreate, and again the moment
 *  closeGame() clears romLoaded, both called *before* changeRom()
 *  runs), and [screenOrientationChoice] only once a ROM is actually
 *  loaded (this is called again right after romLoaded flips true in
 *  the load-success path below). With both this activity and
 *  RomBrowserActivity already agreeing on Portrait by the time the
 *  browser actually launches, there's nothing left for the system to
 *  rotate mid-transition — any landscape↔portrait rotation now happens
 *  once, cleanly, on this activity's own idle screen (always after
 *  stopGameLoop() has already halted rendering — see closeGame() — so
 *  there's never a live SurfaceView draw in flight when it happens),
 *  the same as a user manually turning their phone, not smeared across
 *  an activity launch.
 *
 *  BUG FIX: wrapped in try/catch. setRequestedOrientation() has a known
 *  Android crash — IllegalStateException("Only fullscreen opaque
 *  activities can request orientation") — thrown on API 26+ whenever
 *  the system doesn't currently consider this activity fullscreen (e.g.
 *  split-screen/multi-window/freeform, or some OEM launcher/window
 *  quirks entirely outside this app's control). This call already
 *  existed before the fix (app start, Video settings' Save button),
 *  just rarely enough that this was a latent, never-hit risk; a later
 *  pass temporarily added far more call sites — every ROM browser
 *  open/close/load, back when it forced Portrait for that screen from
 *  right here in this class — which is exactly where a crash "opening
 *  a ROM" started actually showing up. Those extra call sites are gone
 *  now (the ROM browser is RomBrowserActivity, its own Activity,
 *  locked to Portrait statically via the manifest instead of any
 *  requestedOrientation call — see its top-of-file comment). This
 *  pass adds two more call sites of its own (closeGame(), the ROM-load
 *  success path) but they're both still just this same function,
 *  still just this one place that ever touches requestedOrientation —
 *  the try/catch stays regardless: cheap insurance, and the underlying
 *  platform quirk it guards against has nothing to do with how many
 *  call sites there are. Worst case with the catch: that one
 *  orientation change silently doesn't happen; without it, the whole
 *  app crashes. */
internal fun MainActivity.applyScreenOrientationPref() {
    try {
        requestedOrientation = if (!romLoaded) {
            // Idle — no game running. Always Portrait, matching
            // RomBrowserActivity exactly; see the function doc above.
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else when (screenOrientationChoice) {
            ORIENTATION_AUTO             -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            ORIENTATION_REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
            ORIENTATION_PORTRAIT         -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            ORIENTATION_SYSTEM           -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else                         -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE  // ORIENTATION_LANDSCAPE + any bad stored value
        }
    } catch (e: Exception) {
        Log.e(TAG, "setRequestedOrientation failed, ignoring", e)
    }
}


// ── ROM file browser — now RomBrowserActivity.kt, a separate Activity ──
//
// buildBrowserStack(), openRomBrowserAtRoot(), romBrowserUp(),
// refreshRomBrowserList(), renderRomBrowserList(), romBrowserMessageRow(),
// romBrowserRow(), and buildRomBrowser() all moved to RomBrowserActivity.kt
// this pass (Thirty-second) — see that file for the current versions and
// its own top-of-file comment for why this is a separate Activity now
// instead of an overlay here (a real, twice-reproduced native crash from
// forcing orientation on this screen while it lived in this Activity's
// own window, alongside the game surface).

// FIX: ⚙ used to call showSettingsMenu() directly, jumping straight into
// the full Video/Audio/Input/Layouts/... category list with no menu in
// between. This is the quick game menu that now opens first — Load,
// Save and Fast forward act immediately; Settings hands off to the
// screen below.
//
// MENU REDESIGN: restyled from a bare .setItems() list (default system
// row styling) to plain rows via a custom ArrayAdapter, to match the
// reference screenshot — and folded Link remote/local back in here
// alongside three new actions (Screenshot, Reset, Close), matching that
// reference's full ten-item list. It's one continuous list; AlertDialog's
// own internal ListView scrolls it automatically once it overflows the
// dialog's height, exactly like it already did for the old 5-item
// version — nothing extra needed for that part. Settings, Link remote
// and Link local are still also reachable from the Settings screen,
// unchanged (see buildSettingsMenu()) — this just adds a faster path to
// the same actions, matching how My Boy's own menu is laid out.
/** One row of the quick game menu below — label, whether it needs a ROM
 *  loaded first, and what it does. FIX (this pass, alongside adding
 *  Settings → Debug's two toggles): showGameMenu() used to be a fixed
 *  `items` list, a *separate* `needsRom` set of hardcoded positions
 *  into that list, and a `when(which)` dispatch with its OWN hardcoded
 *  positions — three parallel structures kept in sync purely by
 *  everyone remembering to renumber all three together. That was
 *  already fragile (see the old code's own comment about why "Memory"
 *  went right before "Close" specifically to dodge renumbering
 *  everything after it) even with a fixed item count; conditionally
 *  hiding "Copy link log"/"Memory" per the new Debug toggles would have
 *  meant the positions after whichever one got hidden shifting too,
 *  for every OTHER entry in both `needsRom` and `when`. Binding each
 *  row's label/needsRom/action together instead — this class — removes
 *  the parallel-structure/position bug class entirely: entries can be
 *  added, removed, or hidden in any combination with nothing else to
 *  keep in sync. */
private class GameMenuAction(val label: String, val needsRom: Boolean, val action: () -> Unit)

internal fun MainActivity.showGameMenu() {
    val entries = mutableListOf(
        GameMenuAction("Load", true) { showSaveStateSlotDialog(forSave = false) },
        GameMenuAction("Save", true) { showSaveStateSlotDialog(forSave = true) },
        GameMenuAction("Fast forward", true) {
            fastForwardActive = !fastForwardActive
            uiToast(if (fastForwardActive) "Fast forward ON" else "Fast forward OFF")
        },
        GameMenuAction("Cheats", false) { uiToast("Cheats — not implemented yet") },
        GameMenuAction("Settings", false) { showSettingsMenu() },
        GameMenuAction("Link remote", false) { showLinkRemoteDialog() },
        GameMenuAction("Link local", false) { showLinkLocalDialog() },
        GameMenuAction("Screenshot", true) { takeScreenshot() },
        GameMenuAction("Reset", true) { resetGame() },
    )
    // FEATURE (Settings → Debug — direct report: "setting add debug on
    // it you can toggle rom memory viewer or link debug each one has
    // toggle and if you off all of it on menu all of those is gone but
    // you can toggle it back"): these two are debug/troubleshooting
    // tools, not everyday menu items. Hidden here — never deleted, just
    // left out of `entries` for this one dialog build — while their own
    // Debug toggle is off; see showDebugSettings()/debugLinkLogEnabled/
    // debugMemoryViewerEnabled's own field comments for where the
    // toggle itself lives. "Copy crash log" stays unconditional: unlike
    // the other two, it isn't a *specialized* debug tool for one
    // feature (Link, Memory Viewer) — it's the general "something broke,
    // here's why" log, useful regardless of which other debug tools are
    // showing.
    if (debugLinkLogEnabled) entries += GameMenuAction("Copy link log", false) { copyLinkDebugLog() }
    entries += GameMenuAction("Copy crash log", false) { copyCrashLog() }
    if (debugMemoryViewerEnabled) entries += GameMenuAction("Memory", true) { showMemoryViewer() }
    entries += GameMenuAction("Close", false) { closeGame() }

    val labels = entries.map { it.label }
    val adapter = object : ArrayAdapter<String>(this, 0, labels) {
        override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
            val row = recycled as? TextView ?: gameMenuRow()
            row.text = getItem(position)
            return row
        }
    }
    val dialog = AlertDialog.Builder(this)
        .setAdapter(adapter) { _, which ->
            val entry = entries[which]
            if (entry.needsRom && !romLoaded) { uiToast("Load a ROM first"); return@setAdapter }
            entry.action()
        }
        .create()
    // Dark rounded panel to match the reference screenshot explicitly —
    // the system default AlertDialog background varies more by device/
    // OEM skin (Infinix's XOS included) than the plain row styling
    // above does, so this is pinned rather than left to the theme.
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Plain-text row for the quick game menu above — larger and simpler
 *  than settingsRow() (no icon/subtitle) to match the reference
 *  screenshot: a scrollable list of plain rows, nothing else.
 *
 *  FIX (Eleventh pass): this row must NOT be isClickable/isFocusable,
 *  and previously was — copied from settingsRow() below without
 *  noticing the two are backed by completely different click paths.
 *  settingsRow() is a plain LinearLayout child added via addView(),
 *  which has no click handling of its own, so it needs to be
 *  clickable/focusable AND carry its own setOnClickListener. This row
 *  is the convertView inside showGameMenu()'s ListView (AlertDialog's
 *  setAdapter), where the *only* click handling is that ListView's own
 *  OnItemClickListener — the `{ _, which -> ... }` lambda passed to
 *  setAdapter() above. A clickable/focusable child steals the touch
 *  before the ListView ever gets to fire that listener, so every row
 *  quietly ate its own tap: the ripple still played (the background
 *  is a pressed-state drawable, and ListView forwards pressed state to
 *  whichever child is under the touch regardless of its own clickable
 *  flag) but `which` was never delivered — which is why Load, Save,
 *  Settings, Link remote, Link local, etc. all silently did nothing
 *  after this menu was restyled. Removing the two flags here restores
 *  the same plain-list-item behavior the old .setItems() version had,
 *  while keeping the ripple background exactly as it was. */
internal fun MainActivity.gameMenuRow(): TextView {
    return TextView(this).apply {
        textSize = 17f
        setTextColor(Color.WHITE)
        setPadding(dp(28), dp(20), dp(28), dp(20))
        setBackgroundResource(rippleBackgroundResId())
    }
}


// ── About ────────────────────────────────────────────────────────────

internal fun MainActivity.showAboutDialog() {
    val ctx = this
    val versionName = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "—"
    } catch (e: PackageManager.NameNotFoundException) { "—" }

    val layout = ctx.dialogContentLayout().apply {
        addView(TextView(ctx).apply {
            text = getString(R.string.app_name); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        addView(TextView(ctx).apply {
            text = "Version $versionName"
            textSize = 12f; setTextColor(Color.parseColor("#AAAAAA"))
            setPadding(0, dp(6), 0, dp(16))
        })
        addView(TextView(ctx).apply {
            text = "A custom Android build wrapping the mGBA core via JNI."
            textSize = 12f; setTextColor(Color.WHITE)
        })
    }

    AlertDialog.Builder(ctx)
        .setTitle("ℹ️  About")
        .setView(layout)
        .setPositiveButton("OK", null)
        .show()
}


/**
 * Rebuild control layout and game matrix after settings change.
 * Called on main thread; game thread picks up changes on next frame.
 * FIX: the explicit updateGameMatrix() call this used to make right
 * after buildControlLayout() is gone — buildControlLayout() calls it
 * internally now (see the note at its own end), so this was calling
 * it twice for no benefit.
 */
internal fun MainActivity.applyLayoutSettings() {
    val holder = surfaceHolder ?: return
    val sw = holder.surfaceFrame.width().toFloat()
    val sh = holder.surfaceFrame.height().toFloat()
    if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)
}

