package com.mgba.android

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt

// ─────────────────────────────────────────────────────────────────────────
// FILE MAP (pass 46 — "refactor main activity into separate class so
// organized"): MainActivity.kt used to hold every function in this app's
// main screen (~7,700 lines). Everything that COULD move out safely now
// lives in its own file as internal extension functions on MainActivity —
// same pattern SharedUi.kt already used for its own split (see that file's
// top comment). What's left here is only what Kotlin/Android actually
// requires to stay a physical member of this class:
//   - every field/property (now `internal` instead of `private` so the
//     split-out files can read/write them — see each new file's own doc
//     comment for why that's safe)
//   - the Activity/SurfaceHolder.Callback lifecycle overrides (onCreate,
//     onDestroy, onPause, onResume, onWindowFocusChanged, surfaceCreated,
//     surfaceDestroyed, surfaceChanged) — Kotlin requires an override to be
//     a literal member of the overriding class, not an extension function
//   - SaveEntry — an `inner class`, which (unlike a plain nested class)
//     needs to stay a physical member of MainActivity for its implicit
//     outer-instance access to work
//
// BUILD FIX (this pass): the small data classes/sealed class (ButtonDef,
// LayoutEntry, Geometry, MemRegion, SlotInfo, SlotKind) and the companion
// object's constants were originally left nested right here on the
// assumption that it made no difference — they're each only a few lines,
// and moving type declarations (as opposed to the functions that use
// them) looked like it would buy no real readability win for real
// relocation risk. That assumption broke the build: an extension function
// in one of the split-out files below only gets MainActivity's real
// *instance* members through its implicit receiver, not its companion
// object's constants or its nested types — those only resolve unqualified
// when the referencing code is textually inside the class body itself, so
// every split-out file below failed with "Unresolved reference" on TAG,
// every PREF_*/ORIENTATION_* constant, LayoutEntry, Geometry, ButtonDef,
// SlotInfo, and SlotKind, plus everything that cascaded from those. Fixed
// by hoisting all of it to MainActivityShared.kt as plain top-level
// (package-scope) declarations — see that file's own top-of-file comment
// for the full explanation, and SharedUi.kt's PREFS/dp() for the
// already-established precedent this follows.
//
// Business logic lives in, by responsibility:
//   MainActivityShared.kt              — shared constants + data/sealed classes (see above)
//   MainActivityAudio.kt               — AudioTrack init/write/settings
//   MainActivityRom.kt                 — ROM staging/loading
//   MainActivitySaveStateCore.kt       — save/state file paths, quick save/load, backups
//   MainActivitySaveStateUi.kt         — save-state slot dialog, thumbnails
//   MainActivityControlLayout.kt       — building/persisting/drawing on-screen controls
//   MainActivityRender.kt              — render loop, game loop, screen matrix
//   MainActivityInput.kt               — gameplay touch/key handling
//   MainActivityControlEditorGeometry.kt — layout-editor hit-testing/grid/percent math
//   MainActivityControlEditorMode.kt   — layout-editor mode/touch/toolbar sync
//   MainActivityMemoryViewer.kt        — live memory-viewer overlay
//   MainActivityMenus.kt               — Settings/game-menu overlay building
//   MainActivityVideoSettings.kt       — Video settings screen + its dialogs
//   MainActivitySettingsDialogs.kt     — Audio/Input/Layouts/Misc/Storage/Advanced/About dialogs
//   MainActivityDebugLog.kt            — crash/link debug log, screenshot, reset/close
//   MainActivityLink.kt                — link-multiplayer dialogs, Bluetooth permission
// ─────────────────────────────────────────────────────────────────────────
class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    internal lateinit var surfaceView: SurfaceView
    internal lateinit var settingsBtn: TextView
    internal lateinit var settingsMenuOverlay: LinearLayout
    // ── Memory viewer (see showMemoryViewer()/buildMemoryViewer()) ──────────
    // FEATURE: live GBA memory inspector, requested for watching game state
    // (Pokémon battle values — HP, party data, etc. — were the specific
    // example) change in real time. Deliberately built as an overlay, same
    // built-once/shown-hidden pattern as Settings just below, rather than
    // its own Activity the way the ROM browser is — the whole point is to
    // watch memory *while the game keeps running underneath*, which an
    // Activity switch (pausing MainActivity, per the Android lifecycle)
    // would work against; showSettingsMenu() already establishes that
    // showing an overlay here does NOT stop the game loop, exactly what
    // this needs too. Read-only for now: inspects live RAM, as asked for,
    // not a cheat/poke tool — see showMemoryViewer()'s own doc comment.
    internal lateinit var memoryViewerOverlay: LinearLayout
    internal lateinit var memoryDumpText: TextView
    internal lateinit var memoryAddressText: TextView
    internal var memoryRegionIndex = 0
    internal var memoryPageOffset = 0
    // ROM browser fields (romBrowserOverlay, romBrowserListLayout,
    // romBrowserPathText, romBrowserBackBtn, romBrowserDeviceRoot,
    // romBrowserStack, romBrowserGeneration) all moved out this pass
    // (Thirty-second) into RomBrowserActivity.kt, a separate Activity now —
    // see changeRom()/romBrowserLauncher below and RomBrowserActivity.kt's
    // own top-of-file comment for why (a real, twice-reproduced native
    // crash from forcing orientation on this screen while it lived here as
    // an overlay in the same window as the game surface).
    // ── Screen orientation (see applyScreenOrientationPref()/showVideoSettings()) ──
    internal var screenOrientationChoice: Int = ORIENTATION_LANDSCAPE
    internal var surfaceHolder: SurfaceHolder? = null
    internal var gameThread:    Thread? = null
    @Volatile internal var running   = false
    @Volatile internal var romLoaded = false
    // ── Save states / battery save ────────────────────────────────────────
    // Identifies the loaded ROM for save-file naming (both the battery .sav
    // and save-state slots below) — see deriveRomBaseName(). Kept separate
    // from the fixed "rom_loaded.gba" cache path every ROM is copied to
    // (see romPicker) so switching ROMs (via Settings → Change ROM) never
    // mixes one game's save data into another's.
    @Volatile internal var currentRomBaseName = "rom"
    // ── Triple-buffered framebuffers ────────────────────────────────────────
    // AUDIO FIX (this pass — root cause of crackle/stutter/perceived pitch
    // drift): renderFrame() (lockCanvas/drawBitmap/unlockCanvasAndPost) used
    // to run on the SAME thread as writePcm(), right after it, every frame.
    // Since writePcm() blocking IS the frame pacer now (see startGameLoop()),
    // any slow render — a GC pause, a busy compositor, a software-canvas
    // SurfaceView on a budget device — delayed the *next* audio write too.
    // That starves AudioTrack while the render is stuck, which is heard as a
    // click/pop when playback resumes (buffer underrun), and the resulting
    // irregular frame delivery reads as choppiness or "speed" wobble even
    // though no single sample is mispitched. This was flagged in an earlier
    // pass as a known, deferred risk ("the real fix is decoupling rendering
    // onto its own thread") rather than fixed outright.
    //
    // Fix: three Bitmap buffers, ping-ponged so the game thread never writes
    // into a buffer the renderer might currently be reading:
    //   writeIdx   — owned by the game thread; where nativeRunFrame() writes.
    //   readyIdx   — the most recently completed frame, swapped in under
    //                bufferLock once a frame finishes; -1 = none yet.
    //   displayIdx — owned by the Choreographer render callback; the buffer
    //                it last drew (and may still be drawing via the Surface).
    // The game thread always picks its next writeIdx as whichever of the 3
    // indices is neither readyIdx nor displayIdx — with 3 buffers and only
    // 2 "spoken for" at once, a free one always exists, so the writer never
    // blocks on the renderer and the renderer never tears mid-draw.
    // The renderer runs off Choreographer.postFrameCallback — i.e. paced by
    // the display's own vsync — completely independent of how fast the
    // audio-locked game thread is producing frames.
    internal var frameBuffers: Array<Bitmap>? = null
    internal var writeIdx = 0
    internal val bufferLock = Object()
    internal var readyIdx = -1
    internal var displayIdx = -1
    @Volatile internal var renderLoopActive = false
    internal val renderCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!renderLoopActive) return
            val bufs = frameBuffers
            if (bufs != null) {
                var toDraw = -1
                synchronized(bufferLock) {
                    if (readyIdx != -1 && readyIdx != displayIdx) {
                        displayIdx = readyIdx
                    }
                    toDraw = displayIdx
                }
                if (toDraw != -1) renderFrame(bufs[toDraw])
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    internal val gameMatrix  = Matrix()
    internal val currentKeys = AtomicInteger(0)
    // BUG FIX ("buttons disappear while dragging"): this used to be a
    // `mutableListOf<ButtonDef>()` that buildControlLayout() mutated in
    // place — buttons.clear() followed by ~11 buttons += calls. That's
    // called on every ACTION_MOVE while dragging a button in the editor
    // (see onEditTouch), i.e. dozens of times a second, ON THE UI THREAD —
    // while the game thread's render loop reads this same list ~60x/sec to
    // draw it (drawControls()). There was no synchronization between the
    // two, so the render thread could paint a frame at the exact moment the
    // list was between clear() and being refilled: every button vanishes
    // for that one frame. Worse under load (exactly when you're actively
    // dragging), which matches "it freezes/disappears when you move it".
    // Fix: build a brand-new list off to the side and swap the *reference*
    // in one atomic write. The render thread then only ever sees a fully
    // "old" or fully "new" list, never a half-built one.
    @Volatile internal var buttons: List<ButtonDef> = emptyList()
    internal var controlsTop = 0f
    // pickerLive moved to RomBrowserActivity this pass — its only two uses
    // (romPicker, the classic single-file fallback) moved there with it.
    internal lateinit var link: LinkMultiplayer
    // FEATURE (screen recorder) — see GameScreenRecorder.kt's own doc
    // comment; assigned in onCreate() alongside `link` above.
    internal lateinit var screenRecorder: GameScreenRecorder
    internal val mainHandler = Handler(Looper.getMainLooper())

    // ── Control layout editor ────────────────────────────────────────────
    // LayoutEntry/Geometry moved to MainActivityShared.kt (pass 46 build fix —
    // see that file's own top-of-file comment); see it for the full
    // storage-format rationale (fractions not pixels, per-orientation keys).
    // customLayout/defaultGeometry below are unaffected: real instance
    // fields, not the nested-type declarations that broke the build.

    internal val customLayout = mutableMapOf<String, LayoutEntry>()
    internal val defaultGeometry = mutableMapOf<String, Geometry>()
    internal var lastSw = 0f
    internal var lastSh = 0f

    // FIX (direct report: "if you back the emulator without using the
    // closed on menu the layout reset you have to go to setting layout
    // to select the layout again") — loadCustomLayout() used to run
    // exactly once, from onCreate(), at a point applyScreenOrientationPref()
    // *always* forces Portrait (its own "Idle — no game running" branch —
    // true of every onCreate(), since no ROM has loaded yet at that
    // point), regardless of the player's actual chosen game orientation.
    // android:configChanges keeps this Activity alive straight through
    // the later Portrait->Landscape flip once a ROM actually loads
    // (surfaceChanged() reacts to that, not a new onCreate()), so nothing
    // else was ever going to call loadCustomLayout() again on its own —
    // a landscape player's saved layout was never read at all for that
    // whole process's life. Tracks which orientation's data is currently
    // loaded into customLayout/removedButtons/addedExtraButtons, so
    // buildControlLayout() can reload the instant the real orientation
    // tag disagrees with it — see that function and loadCustomLayout()
    // itself, which is what actually keeps this field up to date.
    internal var loadedLayoutOrientationTag: String? = null

    // ── ADD/REMOVE CONTROL ──────────────────────────────────────────────
    // Button ids currently hidden from the on-screen layout (and therefore
    // excluded from buildControlLayout()'s `buttons`/ffBtnRect output, so
    // they're neither drawn nor hit-tested during normal gameplay). Entered
    // via hold-to-remove in the editor (see onEditTouch/showRemoveButtonMenu)
    // and reversed via "+ Add control" (see showAddControlMenu). Persisted
    // the same way/at the same points as customLayout — see
    // loadCustomLayout()/saveCustomLayout() — so Cancel discards a removal
    // exactly like it discards a drag, and Done makes it stick.
    internal val removedButtons = mutableSetOf<String>()

    // "Extra" controls — the shoulder+face combos, the A/B combos, and the
    // three one-tap actions (quick save/load, screenshot). Opposite default
    // from removedButtons above: these start OFF and only ever appear once
    // explicitly added, rather than starting on and being explicitly
    // removed — shipping this feature should never dump 9 new buttons onto
    // a layout someone already has set up exactly how they want it. See
    // isButtonVisible()/allControlIds() for how the two sets combine, and
    // buildControlLayout() for where each of these is actually built.
    // "ta"/"tb" (Turbo A / Turbo B) joined this list this pass — previously
    // a single all-or-nothing Settings checkbox added both together (see
    // showInputSettings()'s old turboCheck, removed this pass); moved here
    // on request, so each can be added/positioned/removed independently,
    // same as every other opt-in extra.
    // "record" (FEATURE — screen recorder toggle button) joined this
    // list the same pass "record" itself was added — see
    // GameScreenRecorder.kt/MainActivityRecorder.kt.
    internal val extraControlIds = listOf(
        "ta", "tb", "la", "lb", "ra", "rb", "ab", "abturbo", "quicksave", "quickload", "screenshot", "record"
    )
    internal val addedExtraButtons = mutableSetOf<String>()

    @Volatile internal var editModeActive = false
    // FEATURE (Layouts preset manager — see MainActivityLayoutPresets.kt's
    // top-of-file comment) — set by startNewLayoutPreset()/
    // editExistingLayoutPreset() right before enterEditMode(), read and
    // reset by exitEditMode() on Done: null = ordinary "Edit Button
    // Layout…" session (today's existing behavior, untouched); "" = a
    // brand-new preset pending a name; any other string = updating that
    // existing preset under its same name.
    internal var editingPresetName: String? = null
    internal var editSelectedId: String? = null
    internal var editDragPointerId = -1
    internal var editDragOffX = 0f   // touch point minus button center, at drag start
    internal var editDragOffY = 0f
    internal var editResizing = false
    internal var editResizeStartDist = 0f
    internal var editResizeStartScale = 1f
    internal var editDirty = false   // true once the working copy diverges from what's saved
    internal lateinit var editTopBar: LinearLayout
    // FIX: promoted from a local val in the UI-building method to a field
    // — refreshEditToolbarPosition() needs this wrapper's own laid-out
    // height (not editTopBar's, the child it wraps) to compute topBound
    // accurately. See that fix, and editTopBarScroll's own construction
    // site, for the full reasoning.
    internal lateinit var editTopBarScroll: HorizontalScrollView
    internal lateinit var editButtonBar: LinearLayout
    internal lateinit var editButtonLabel: TextView
    internal lateinit var editLockBtn: Button
    // CUSTOMIZATION UI: editSizeLabel's text switches between "Game Screen
    // Size" and "Control Size" depending on what's selected — the clear,
    // non-abbreviated labels requested, rather than a single generic
    // "Size" for both. editOpacityRow is hidden entirely when the game
    // screen is selected: opacity has no effect on the live game image
    // (there's no such thing as "Game Screen Opacity" in this app), so
    // showing it there would be a control that visibly does nothing.
    // FIX (this pass): editSizeSlider/editOpacitySlider replace what used
    // to be a "-"/"+" editChip() pair in each row — see sliderRow() in
    // SharedUi.kt for the widget itself, and syncEditButtonBarToSelection()
    // below for what keeps them (and the two fields above) showing the
    // right thing as the selection/lock state changes.
    internal lateinit var editSizeLabel: TextView
    internal lateinit var editOpacityRow: LinearLayout
    internal lateinit var editSizeSlider: SliderRow
    internal lateinit var editOpacitySlider: SliderRow
    // FIX (direct report, still reproducible after every earlier
    // refreshEditToolbarPosition() fix: "the button customization pop up
    // still get cut off if you move around the button"): promoted from a
    // local val at editRowLabelWidth's own construction site so
    // refreshEditToolbarPosition() can read it too — see that function's
    // own use of it, and its doc comment, for why every earlier fix here
    // (all of them position-clamping fixes) could never actually close
    // this: editRow2/editOpacityRow's combined width (this label +
    // EDIT_TOOLBAR_SLIDER_WIDTH_DP's fixed 190dp slider) was never
    // adapted to the screen at all, landscape or portrait — clamping the
    // popup's *position* can't help when the popup itself is simply
    // wider than the screen has room for.
    internal var editRowLabelWidthPx = 0
    // FIX (direct report, still reproducible after the width-shrink fix
    // right above and every position-clamping fix before it: "still the
    // pop up on control customization still get cut off"): that fix
    // shrinks editRow2/editOpacityRow's *sliders* to fit the screen, but
    // editRow1 — editButtonLabel (the selected control's name, e.g.
    // "Fast-Forward") plus editLockBtn ("Unlocked"/"Locked") plus the
    // Reset chip — was never touched at all, and has no slider of its own
    // to shrink. LinearLayout doesn't shrink non-weighted children to fit
    // their parent: each measures at its own full natural width regardless
    // of its siblings, so on a screen too narrow for all three combined,
    // editRow1's own measured width gets clamped by the AT_MOST bound in
    // refreshEditToolbarPosition()'s editButtonBar.measure() call below,
    // but its *children* don't — layoutHorizontal() still places each one
    // at its full width, one after another, so the trailing child (Reset,
    // or the tail of a long label) lands partly or fully past that clamped
    // bound. That's a second, independent way to get "cut off", never
    // fixed by anything above since every fix above assumed row 2/3's
    // slider was the only fixed-width element in the bar. editResetBtn
    // (below) is editRow1's Reset chip promoted from the local/anonymous
    // val it used to be, so refreshEditToolbarPosition() can measure it
    // too; editRow1ChipsWidthPx is that measurement plus editLockBtn's,
    // taken once against each chip's own longest possible text — the same
    // approach editRowLabelWidthPx above already uses, not a guessed
    // constant — so refreshEditToolbarPosition() can reserve the right
    // amount of room for both chips and give whatever's left to
    // editButtonLabel's own maxWidth, the same "shrink the one row that
    // can afford to, leave the interactive controls at a fully readable/
    // tappable size" split the slider fix already uses.
    internal lateinit var editResetBtn: Button
    internal var editRow1ChipsWidthPx = 0
    // FEATURE (direct report: "add a way to move button without swipe
    // like arrow up down left right"): four small chips, one per
    // direction, each wired to nudgeSelected() in onCreate below. Plain
    // ASCII ("^"/"v"/"<"/">"), not a Unicode arrow or dingbat glyph — see
    // editTopBar's own construction comment for why this editor's UI
    // stays plain-text throughout.
    internal lateinit var editNudgeUpBtn: Button
    internal lateinit var editNudgeDownBtn: Button
    internal lateinit var editNudgeLeftBtn: Button
    internal lateinit var editNudgeRightBtn: Button
    // HOLD-TO-REMOVE: armed on ACTION_DOWN over a button (plain grab, not a
    // corner resize-grab — see onEditTouch), cancelled by real movement or
    // by lifting the finger before it fires. See cancelEditLongPress().
    internal var editLongPressPending: Runnable? = null
    internal var editDownX = 0f
    internal var editDownY = 0f
    internal val editTouchSlop: Float by lazy { ViewConfiguration.get(this).scaledTouchSlop.toFloat() }
    // FEATURE: hold-for-speed-slider on the on-screen »/fast-forward
    // button, gameplay (not edit-mode) touch handling — see onGameTouch()
    // and showFastForwardSpeedSlider(). Same "armed on DOWN, cancelled if
    // it resolves as a tap before the timeout fires" shape as
    // editLongPressPending just above, for the same reason (Runnable
    // stays cancellable via mainHandler.removeCallbacks right up until it
    // actually runs).
    internal var ffLongPressPending: Runnable? = null
    // FIX (this pass — audit's own design-tradeoff note): which pointer
    // currently owns the pending/armed FF gesture above, -1 for none. Was
    // implicit before (ffLongPressPending being non-null only ever meant
    // "the first/primary finger", since only ACTION_DOWN — by definition
    // the very first pointer — ever armed it). Now that a second/third
    // finger landing on ff (ACTION_POINTER_DOWN, see onGameTouch below)
    // can arm it too, the specific pointer id has to be tracked explicitly
    // so the matching lift — ACTION_UP for the primary finger, or
    // ACTION_POINTER_UP for a secondary one — can tell whether *this*
    // lifting finger is the one that armed it, rather than always assuming
    // pointer 0.
    internal var ffDownPointerId: Int = -1

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile internal var fastForwardSpeed  = 2.0f
    @Volatile internal var fastForwardActive = false
    internal var ffBtnRect  = RectF()
    internal var ffFrameAccumulator = 0.0

    // FIX (direct report: "quick load and save button is bad there
    // highlights same for screenshot button") — quicksave/quickload/
    // screenshot fire their whole action synchronously on ACTION_DOWN
    // (see triggerActionButton()) with no separate "release" phase the
    // way a held emulator key has, so drawControls() previously had no
    // path that ever showed them as pressed at all: their keyMask is
    // always 0 (they're app-level actions, not GBA buttons), and none
    // of them matched drawControls()'s other explicit `pressed` cases
    // either. actionButtonFlashId/actionButtonFlashUntil record a
    // short-lived window drawControls() checks instead — see
    // triggerActionButton() (MainActivityInput.kt) for where these get
    // set and ACTION_BUTTON_FLASH_MS (MainActivityShared.kt) for the
    // window length. Self-expiring by construction: once
    // System.currentTimeMillis() passes actionButtonFlashUntil, the
    // very next rendered frame just reads back as not-pressed again, no
    // separate timer/Handler needed.
    internal var actionButtonFlashId: String? = null
    internal var actionButtonFlashUntil: Long = 0L

    // FEATURE (this pass): the game screen is now a resizable/draggable
    // participant in the same edit-mode/customLayout system every button
    // already used — see resolvedRect("gamescreen", ...) in
    // updateGameMatrix(), and editRectFor()/hitTestEditable()/labelFor()
    // below. gameScreenRect is its resolved on-screen rect, kept as its
    // own field (not a ButtonDef in the buttons list) since it isn't a
    // real input control — no keyMask, never drawn as a button glyph
    // during normal gameplay, excluded from the long-press-to-remove menu
    // (see onEditTouch) since there's nothing sensible "removing" it
    // would mean.
    //
    // Replaces the previous Fullscreen checkbox (fullscreenMode) entirely
    // on request — a separate on/off toggle for "game covers the control
    // area" doesn't add anything once the screen itself can just be
    // dragged and resized to be exactly as big as wanted, controls
    // included or not.
    internal var gameScreenRect = RectF()
    // FEATURE: distorts the image to fill the game area exactly instead of
    // preserving the GBA's native 3:2 aspect ratio — see updateGameMatrix().
    @Volatile internal var stretchToFit = false
    // FEATURE: bilinear-smooths the upscaled image instead of showing
    // crisp/blocky pixels — see gamePaint/updateLinearFilterPaint() below.
    // FIX: this field itself was missing entirely through pass 35 — every
    // read of it (the pref-load line, updateLinearFilterPaint(), the
    // Video settings checkbox) compiled as an unresolved reference,
    // caught by the real CI build (this project has no compiler in the
    // sandbox that writes it — see every pass's own verification notes).
    // Wrongly assumed to already exist alongside stretchToFit/maxFrameSkips
    // above without actually checking for a declaration, not just a use —
    // the two lines it happened to share a grep result with were a load
    // line and a doc comment, neither of which is one.
    @Volatile internal var linearFilterEnabled = false
    // FEATURE: MyBoy-style frame skipping for normal (non-fast-forward)
    // play — see maybeSkipRenderThisFrame() in the game loop. 0 = never
    // skip (always render every frame, the previous and still-default
    // behavior); up to maxFrameSkips consecutive frames may be emulated
    // without blitting if the loop is genuinely running behind.
    @Volatile internal var maxFrameSkips = 0
    // FEATURE: state for maybeSkipRenderThisFrame's "are we behind" check
    // and its consecutive-skip budget — see startGameLoop().
    @Volatile internal var consecutiveFrameSkips = 0
    // FIX (this pass — reported directly: "max frame skip at 10 it very
    // bad its laggy... the max frame skip it becomes slower", unlike a
    // reference emulator's own frame skip, which the report says makes
    // things faster): "are we behind" used to compare the *previous*
    // iteration's full wall-clock duration (old lastFrameLoopStartNs, a
    // timestamp) against frameBudgetNs. That total always includes the
    // blocking writePcm() call — the frame pacer by design, see the AUDIO
    // ARCHITECTURE comment above initAudioTrack() — which alone consumes
    // ~1 frame period of real time on *every* normal iteration, skip or
    // not. So total iteration time sits right on top of frameBudgetNs
    // essentially always, and which side of that exact threshold it lands
    // on is mostly scheduling/audio-buffer noise, not a signal the device
    // is actually struggling — "behind schedule" could fire close to half
    // the time on a perfectly healthy device. With no cooldown beyond a
    // single non-skip iteration, one false trip could then chain up to
    // maxFrameSkips visibly-stuck-on-one-frame iterations in a row before
    // the counter reset — worse the higher maxFrameSkips was set, exactly
    // backwards from the feature's own goal ("10 is laggier than a low
    // setting" instead of "closer to keeping pace than off").
    //
    // lastComputeNs replaces that timestamp with a duration: only the
    // CPU-bound portion of the *previous* iteration (nativeSetKeys through
    // nativeReadAudioSamples — see the loop below for exactly where this
    // is measured, and where it deliberately stops, before the blocking
    // write). Comparing *that* to frameBudgetNs actually answers "is the
    // device's own compute too slow for one frame's budget" — the
    // question this check was always meant to ask — instead of "did the
    // pacer's own intentional wait happen to land a hair over an exact
    // integer-nanosecond line," which it couldn't help but answer instead.
    internal var lastComputeNs = 0L
    internal val frameBudgetNs = 1_000_000_000L / 60  // one GBA frame at 60fps

    // ── Button / screen customization ─────────────────────────────────────
    internal var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    internal var buttonBaseAlpha       = 160    // idle opacity 0-255
    internal var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65
    // OUTLINE SKIN: stroke width for the line-art button style, recomputed
    // as a screen-size fraction in buildControlLayout() (same convention as
    // every other button dimension in that function) rather than a fixed
    // pixel constant, so it scales sensibly across phone sizes.
    internal var outlineStrokeW        = 5f
    // Thinner border, originally used only for the Quick Load / Quick
    // Save / Screenshot utility-button boxes (per explicit user request to
    // thin just those three, leaving D-pad/A/B/L/R/Select/Start/
    // fast-forward's outlineStrokeW alone). Record, the d-pad arms, and
    // fast-forward each joined in later passes, once they got the same
    // real-vector-icon treatment those three already had — see
    // drawActionButtonIcon()/drawDpad()/drawControls()'s own FIX comments
    // (MainActivityControlLayout.kt). A/B/L/R/Select/Start are still the
    // only controls left on outlineStrokeW, now for the opposite reason:
    // nobody's asked to touch those, not any remaining "in scope" line.
    // Computed from real display density in buildControlLayout() so it
    // lands at a true ~1.5-2dp regardless of screen size, rather than the
    // screen-size-fraction formula outlineStrokeW uses.
    internal var utilityIconBorderStrokeW = 2f

    // ── Editor alignment grid (FEATURE — Thirty-ninth pass; square cells —
    //    Fortieth pass) ────────────────────────────────────────────────────
    // Purely an editing-time aid: a grid of square cells drawn over the
    // screen while the layout editor is open, with position/size optionally
    // snapping to it — see gridCellPx()/drawGrid()/snapPositionToGrid()/
    // snapScaleToGrid(), all only ever called from drawEditOverlay()/
    // onEditTouch(). None of the three fields below are read anywhere
    // outside edit mode, so they can never affect the actual gameplay
    // display, the default geometry any control falls back to, or anything
    // already saved in customLayout — showGrid in particular is pure
    // rendering state; toggling it never touches customLayout/
    // removedButtons/addedExtraButtons, so turning the visual grid off
    // can't ever surprise-reset a saved layout.
    // FIX (Fortieth pass): gridDivisions no longer means "N columns × N
    // rows". Reported directly as "not really box[es]", and true even
    // though every preset was labelled N×N — dividing width and height by
    // the same N produces a w/N-by-h/N rectangle on any non-square screen,
    // never an actual square. It now means "how many square cells fit
    // across the SHORTER of width/height" — see gridCellPx(), the one
    // place that size is computed; drawGrid() and both snap functions all
    // read it from there so what's drawn and what dragging/resizing snaps
    // to can never drift apart from each other. Also extended with a 64
    // preset this pass (was capped at 32) — see showGridSettingsDialog().
    internal var gridDivisions = 8            // N — square cells, N of them across the shorter screen dimension
    @Volatile internal var showGrid   = false
    @Volatile internal var snapToGrid = false

    // ── Turbo (rapid-fire) A / B ────────────────────────────────────────────
    // Adds two extra red on-screen buttons — "A"/"B" in red — that
    // auto-repeat the A/B press while held instead of holding it
    // continuously. Individually opt-in via "+ Add control" (see
    // extraControlIds above) as of this pass — previously a single
    // Settings checkbox added both together with no way to get just one;
    // removed on request in favor of the same per-button system every
    // other extra control already used.
    @Volatile internal var turboAHeld = false
    @Volatile internal var turboBHeld = false
    // Half-period of the on/off square wave, in ms.
    // FIX (this pass): was 66ms (≈7-8 presses/sec), reported as feeling
    // slow — not really "rapid" fire. Halved to 30ms (≈16-17 presses/sec),
    // comfortably inside the range real turbo controllers typically run
    // at (roughly 10-30/sec), and still safely above the ~16.7ms a single
    // GBA frame takes at 60fps — each on/off phase still spans close to
    // two full frames, so the core should still reliably register every
    // edge as a distinct press rather than the two phases blurring
    // together into what would just look like a continuous hold again.
    internal val turboHalfPeriodMs = 30L

    // ── Performance overlay (FEATURE — off by default) ─────────────────────
    // Small corner readout of emulated core FPS and the AudioTrack underrun
    // counter — the same underrun figure already logged periodically (see
    // writePcm()), just also surfaced on-screen for at-a-glance diagnosis
    // without needing logcat. Purely additive and opt-in: when disabled
    // (the default) the game thread does none of the counting work below,
    // so there's zero overhead on the thread that also paces audio.
    // Toggled in ⚙ Settings → Misc, next to the other gameplay tweaks.
    @Volatile internal var showFpsOverlay = false
    // FEATURE (Settings → Debug) — see PREF_DEBUG_MEMORY_VIEWER/
    // PREF_DEBUG_LINK_LOG's own comment (MainActivityShared.kt) for the
    // default-true reasoning; loaded in onCreate() below.
    @Volatile internal var debugMemoryViewerEnabled = true
    @Volatile internal var debugLinkLogEnabled = true
    @Volatile internal var fpsOverlayText = ""
    internal var fpsFrameCount    = 0
    internal var fpsWindowStartNs = 0L

    // FEATURE (direct report — Misc setting, "like myboy": "auto save
    // game on exit, load it back on start"): when on, onPause() writes a
    // dedicated Autosave state (see autoStateFile()/SlotKind.Autosave)
    // every time the app backgrounds, and loadRomFromUri()'s own success
    // callback silently loads it back the next time that same ROM starts
    // up. Off by default — matches every other opt-in gameplay tweak in
    // this section (showFpsOverlay just above, stretchToFit, etc.), and
    // an automatic state load on every single ROM start is exactly the
    // kind of surprising-by-default behavior this file otherwise avoids.
    @Volatile internal var autoSaveLoadEnabled = false

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile internal var audioTrack: AudioTrack? = null
    internal val audioBuffer = ShortArray(2048)
    // FAST-FORWARD AUDIO: accumulates every sub-frame's PCM across one
    // fast-forward batch (see startGameLoop) before decimateForFastForward()
    // compresses it back down to about one frame's worth. Sized for
    // FF_MAX_BATCH_FRAMES sub-frames at audioBuffer's own per-read capacity.
    internal val ffAccumBuffer = ShortArray(FF_MAX_BATCH_FRAMES * audioBuffer.size)
    internal var audioDiagCounter = 0
    internal var audioManager: AudioManager? = null
    // AUDIO FIX (this pass): audio focus was never requested. AudioTrack will
    // still *build* and accept writes without it, but several OEM audio HALs
    // (MIUI/ColorOS/FuntouchOS in particular) silently keep a stream's output
    // gain at zero — not muted, not erroring, just inaudible — until the app
    // holding the Surface/foreground also holds AUDIOFOCUS_GAIN. Requesting
    // it costs nothing on stock AOSP devices where sound already worked.
    internal var audioFocusRequest: AudioFocusRequest? = null
    internal val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* no-op: USAGE_GAME doesn't duck */ }

    // ── Audio settings — Enable sound / Sound volume / Sound frequency ─────
    // FEATURE (this pass): replaces the old standalone "Button click sound"
    // toggle (direct report asked for it removed — see updateGameKeys(),
    // which no longer has any click-sound logic at all) with a real Audio
    // settings screen matching a reference screenshot's own list: Enable
    // sound (game audio on/off), Sound volume (an in-app volume slider,
    // independent of the device media volume), and Sound frequency (output
    // sample rate, traded against CPU/battery use — the same lower-
    // fidelity-for-performance option other GBA emulators on Android,
    // MyBoy among them, expose). See showAudioSettings()/
    // showSoundVolumeDialog()/showSoundFrequencyDialog() and
    // applyGameVolume()/applySoundFrequencyFilter() below for where each
    // one actually takes effect.
    @Volatile internal var soundEnabled = true
    @Volatile internal var soundVolumePercent = 100
    // One of 44100/22050/11025 — see showSoundFrequencyDialog(). Stored as
    // the literal Hz value rather than an index: it's already exactly the
    // number initAudioTrack() needs, self-documenting in SharedPreferences,
    // and there's no ordering/migration to keep in sync with the dialog's
    // own option list this way.
    @Volatile internal var soundFrequencyHz = 44100
    // soundFreqFactor/soundFreqAlpha are derived from soundFrequencyHz —
    // see updateSoundFrequencyFactor() — and cached rather than recomputed
    // inside applySoundFrequencyFilter()'s per-sample loop, which runs on
    // the game thread on every single writePcm() call. soundFreqLpL/R are
    // that filter's own continuous state, deliberately *not* reset every
    // call — see applySoundFrequencyFilter()'s own comment for why, in
    // contrast to decimateForFastForward()'s similar but call-scoped
    // filter above.
    @Volatile internal var soundFreqFactor = 1
    @Volatile internal var soundFreqAlpha = 0f
    internal var soundFreqLpL = 0f
    internal var soundFreqLpR = 0f
    // Set from the settings UI (main thread) when Sound frequency changes,
    // consumed and cleared from the game loop itself (see startGameLoop())
    // — changing an AudioTrack's sample rate means rebuilding it entirely
    // (initAudioTrack()), and that rebuild has to happen on the same
    // thread that owns the track's normal write/lifecycle, the same
    // reasoning writePcm()'s own ERROR_DEAD_OBJECT-triggered rebuild
    // already follows, rather than racing a UI-thread rebuild against a
    // concurrent game-thread write.
    @Volatile internal var audioTrackRebuildPending = false


    // ── ROM picker ─────────────────────────────────────────────────────────

    // FIX: BLUETOOTH_CONNECT / BLUETOOTH_SCAN are runtime-dangerous permissions
    // on API 31+ (Android 12+). They were declared in the manifest but never
    // actually requested anywhere, so every Bluetooth link-cable action
    // (Host, Join, listing bonded devices) threw an uncaught SecurityException
    // and crashed the app on any Android 12+ device. This launcher requests
    // the permission on demand; [pendingBtAction] resumes whatever the user
    // was trying to do as soon as it's granted.
    internal var pendingBtAction: (() -> Unit)? = null
    internal val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingBtAction; pendingBtAction = null
        if (granted) action?.invoke()
        else uiToast("Bluetooth permission is required for BT link cable")
    }

    // FEATURE (Thirty-second pass): romPicker (the classic single-file SAF
    // picker) and the whole broad-file-access permission flow
    // (ensureBroadFileAccess() etc.) moved to RomBrowserActivity.kt along
    // with the rest of ROM browsing — see the field-block comment above and
    // RomBrowserActivity.kt's own top-of-file comment for why. What's left
    // here is just the launcher that starts that Activity and receives
    // whichever ROM it picked, mirroring how romPicker/dataFolderPicker
    // above already used registerForActivityResult() for a similar
    // "launch something, get a Uri back" shape.
    internal val romBrowserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { loadRomFromUri(it) }
        }
        // RESULT_CANCELED (backed out / denied permission / nothing
        // picked): do nothing, same as before — the surface just sits
        // idle and tapping it calls changeRom() again (see onGameTouch()).
    }

    // FEATURE: user-chosen Storage folder (see PREF_DATA_FOLDER_URI/
    // showStorageSettings()/SaveEntry). Unlike the ROM browser (its own
    // Activity now, see above), this still goes through a SAF tree picker
    // rather than the broad MANAGE_EXTERNAL_STORAGE permission — it needs
    // *write* access, and there's no reason to widen what this feature
    // touches just because the ROM browser needs the broader permission
    // for its own, separate reasons.
    internal val dataFolderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            Log.e(TAG, "takePersistableUriPermission failed for data folder", e)
            uiToast("Couldn't get permission for that folder"); return@registerForActivityResult
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(PREF_DATA_FOLDER_URI, uri.toString())
            .apply()
        // Create the three subfolders right away so they're visible in a
        // file manager immediately, not only after the first save/
        // screenshot/(future) cheat file actually gets written.
        dataSubfolder("save"); dataSubfolder("cheat"); dataSubfolder("screenshot")
        uiToast("Folder set — new saves/states/screenshots go here from now on")
        refreshStorageSettingsUi?.invoke()
    }

    // FEATURE — direct report: "in sound settings add a way to add
    // background music like you select a folder with song inside and
    // play it 1by1 or shuffle it like playlist." See
    // MainActivityMusic.kt's top-of-file comment for the full design.
    // Field here (not in that extension-function file) for the same
    // reason dataFolderPicker above is: registerForActivityResult() has
    // to run at Activity construction time, which only a real field
    // initializer gives you.
    // lateinit + assigned in onCreate() (not a field initializer) — see
    // FIX (pass 46 hotfix): a field initializer runs during Activity
    // construction, before attachBaseContext(), so `applicationContext`
    // is not yet safe to call here — it crashed on every launch before
    // onCreate() (and installCrashLogger() inside it) ever ran. Same
    // reasoning as `screenRecorder`/`link` below.
    internal lateinit var musicPlayer: MusicPlaylistPlayer
    internal var musicFolderUri: Uri? = null
    @Volatile internal var musicEnabled = false
    @Volatile internal var musicShuffle = false
    internal var musicVolume = 0.7f
    internal val musicFolderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> onMusicFolderPicked(uri) }

    /**
     * One save-adjacent file — a battery save, a numbered state slot, a
     * state thumbnail, or the quicksave slot — that transparently lives in
     * either this app's internal storage ([legacy], unchanged default) or
     * the [subfolder] ("save") of the user's chosen Storage folder, once
     * one is set. See the block comment above dataFolderTree() for the
     * full reasoning; this class is just the per-file interface onto it,
     * used from quickSaveState()/quickLoadState()/showSaveStateSlotDialog()/
     * captureStateThumbnail()/the two nativeLoadROM() call sites.
     */
    internal inner class SaveEntry(private val legacy: File, private val subfolder: String = "save") {
        private fun doc(create: Boolean): DocumentFile? {
            val dir = dataSubfolder(subfolder) ?: return null
            return try {
                dir.findFile(legacy.name)
                    ?: if (create) dir.createFile("application/octet-stream", legacy.name) else null
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.doc(${legacy.name}) failed", e); null
            }
        }

        // FIX: was `get() = dataFolderTree() != null` — re-resolved on
        // every single read (a SharedPreferences lookup +
        // persistedUriPermissions scan + DocumentFile.exists()/canWrite(),
        // the latter two real ContentProvider round-trips) instead of
        // once. SaveEntry instances are always freshly constructed per
        // logical operation — see batterySaveEntry()/stateSlotEntry()/
        // stateThumbEntry()/quickStateEntry()/backupEntry() below, none of
        // which hold or reuse an instance across separate operations — and
        // nearly every method on this class reads usesDataFolder at least
        // once, some (exists(), moveInto(), mirrorToAutoFolder()) more
        // than once within a single call chain: a single quickSaveState()
        // chain (backupIfExists -> stageForWrite -> commitWrite ->
        // mirrorToAutoFolder) triggered roughly 8-12 separate resolutions
        // of what's really one answer for this instance's entire short
        // lifetime. Computed once at construction instead — every read
        // below is unchanged (a plain val reads with the exact same
        // `usesDataFolder` syntax a get() property did), so this only
        // costs one resolution now instead of one per read. Only matters
        // in practice once the opt-in Storage folder feature is actually
        // configured — see dataFolderTree()'s own cheap short-circuit for
        // the (default) unconfigured case, which this doesn't change.
        private val usesDataFolder: Boolean = dataFolderTree() != null

        fun exists(): Boolean = if (usesDataFolder) doc(create = false) != null else legacy.exists()

        fun lastModified(): Long =
            if (usesDataFolder) (doc(create = false)?.lastModified() ?: 0L) else legacy.lastModified()

        /** Best-effort delete; used by backupIfExists' callers indirectly
         *  through overwrite semantics only — nothing currently calls this
         *  directly, kept for symmetry with the rest of this class. */
        fun delete(): Boolean = if (usesDataFolder) (doc(create = false)?.delete() ?: false) else legacy.delete()

        /** The sibling "<name>.bak" entry backupIfExists() copies this one
         *  into — same folder this entry itself resolves to, legacy or
         *  Storage folder alike. */
        fun backupEntry(): SaveEntry = SaveEntry(File(legacy.parentFile, "${legacy.name}.bak"), subfolder)

        /** For plain Kotlin-side writes (state thumbnails, and
         *  backupIfExists' own copy, and commitWrite()/syncBatteryMirror()
         *  below) — NOT for native fopen()-based calls, which always get a
         *  local path instead; see stageForRead()/stageForWrite() below.
         *  "wt" explicitly, not the 2-arg openOutputStream(uri)'s default
         *  "w": some providers only guarantee truncation with "wt" — a
         *  plain "w" that happens to write fewer bytes than the previous
         *  save could otherwise leave stale trailing bytes behind. */
        fun outputStream(): OutputStream {
            if (!usesDataFolder) return legacy.outputStream()
            val d = doc(create = true) ?: throw IOException("Couldn't create ${legacy.name} in the chosen folder")
            return contentResolver.openOutputStream(d.uri, "wt") ?: throw IOException("openOutputStream failed for ${legacy.name}")
        }

        /** Null if the entry doesn't exist yet — mirrors the legacy
         *  `if (!f.exists()) return` checks this replaces. */
        fun inputStream(): InputStream? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.inputStream() else null
            val d = doc(create = false) ?: return null
            return contentResolver.openInputStream(d.uri)
        }

        /** Where stageForRead()/stageForWrite() below put their scratch
         *  copy — this app's own cache dir, one fixed name per (subfolder,
         *  legacy name) pair, so a repeated save/load against the same slot
         *  reuses the same scratch file instead of littering the cache. */
        private fun stagingFile(): File = File(cacheDir, "saf_stage_${subfolder}_${legacy.name}")

        /**
         * A LOCAL, REAL file path — never a content:// URI — that already
         * holds this entry's current bytes, ready for
         * nativeLoadState()/nativeLoadROM() to fopen() and read. Returns
         * null if the entry doesn't exist yet, same as the exists() checks
         * every caller already does first.
         *
         * When no Storage folder is configured this is just [legacy]'s own
         * path — already a real local file, nothing to stage. When one IS
         * configured, this copies the SAF document's bytes into a scratch
         * file under this app's cache dir first (via inputStream() above,
         * which every DocumentsProvider supports), then hands back THAT
         * path. See the block comment above dataFolderTree() for why this
         * replaced a direct SAF-fd bridge this pass.
         */
        fun stageForRead(): String? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.absolutePath else null
            val input = inputStream() ?: return null
            val tmp = stagingFile()
            return try {
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.absolutePath
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.stageForRead(${legacy.name}) failed", e)
                null
            }
        }

        /**
         * A LOCAL, REAL file path for nativeSaveState() to fopen() and
         * write into. When no Storage folder is configured this is just
         * [legacy]'s own path — the write lands directly where it always
         * has, nothing further needed. When one IS configured, this is a
         * scratch file under this app's cache dir; the caller MUST call
         * commitWrite() with this same path immediately after a
         * *successful* native write, or the bytes never reach the chosen
         * folder — see commitWrite() below.
         */
        fun stageForWrite(): String {
            if (!usesDataFolder) return legacy.absolutePath
            return stagingFile().absolutePath
        }

        /** Copies whatever native just wrote at [localPath] (from a prior
         *  stageForWrite() call) into the real SAF document. No-op when no
         *  Storage folder is configured — native already wrote straight to
         *  [legacy] in that case, there's nothing left to copy. Callers
         *  must only invoke this after confirming the native write actually
         *  succeeded: calling it unconditionally would happily overwrite a
         *  perfectly good existing save with a partial/empty file on a
         *  failed write. */
        fun commitWrite(localPath: String) {
            if (!usesDataFolder) return
            try {
                File(localPath).inputStream().use { input ->
                    outputStream().use { out -> input.copyTo(out) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.commitWrite(${legacy.name}) failed — folder copy not updated, local save is still intact", e)
            }
        }

        /** FIX (menu-slot speed pass): moves this entry's current bytes into
         *  [dest] (its ".bak" sibling), replacing whatever was there —
         *  called right before this slot is about to be overwritten by a
         *  fresh save. When no Storage folder is configured this is a
         *  single File.renameTo(): an instant, metadata-only move on the
         *  same volume, NOT a byte-for-byte copy. backupIfExists() used to
         *  read this entry's full bytes and write them out again just to
         *  have nativeSaveState() immediately overwrite this same file
         *  anyway right after — up to 2x a save-state's worth of disk I/O
         *  on every single save, which was most of "pick a slot -> Saved"
         *  feeling slow. Deletes any existing [dest] first, since
         *  File.renameTo()'s platform behavior when the destination already
         *  exists isn't guaranteed. Falls back to copy (old behavior) if
         *  the rename fails for any reason, or whenever a Storage folder
         *  IS configured — DocumentFile has no equivalent plain rename
         *  here, so that path is unchanged from before this fix. */
        fun moveInto(dest: SaveEntry) {
            if (!usesDataFolder && !dest.usesDataFolder) {
                dest.legacy.delete()
                if (legacy.renameTo(dest.legacy)) return
            }
            inputStream()?.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        }

        /**
         * The real, local, persistent path nativeLoadROM() mmaps this
         * entry's battery save through for the *entire* ROM session — the
         * one save-adjacent file that can't just be staged-and-discarded
         * per call, since the core keeps writing to it live for as long as
         * the ROM is running (see mgba_jni.c's core->loadSave() comment).
         *
         * When no Storage folder is configured this is just [legacy]
         * itself, exactly as before this feature existed. When one IS
         * configured, [legacy] is used as a local *mirror*: whatever bytes
         * already exist in the chosen folder are copied in here first (so
         * a save carries over from wherever it was last written), the core
         * then mmaps this same local file for the whole session same as
         * always, and syncBatteryMirror() below copies its current bytes
         * back out to the real document at the points in this file that
         * call it (onPause, before swapping ROMs, onDestroy). A failed
         * copy-in here just means starting from whatever's already local
         * (same as a fresh save) rather than losing the load entirely.
         */
        fun batteryMirrorPath(): String {
            if (usesDataFolder) {
                try {
                    inputStream()?.use { input -> legacy.outputStream().use { out -> input.copyTo(out) } }
                } catch (e: Exception) {
                    Log.w(TAG, "SaveEntry.batteryMirrorPath(${legacy.name}): couldn't stage existing save from the chosen folder, continuing from whatever's already local", e)
                }
            }
            return legacy.absolutePath
        }

        /** Copies [legacy]'s current bytes — the mirror nativeLoadROM has
         *  been mmap-writing to all session — out to the real SAF
         *  document. No-op when no Storage folder is configured, or if
         *  [legacy] doesn't exist yet (nothing played, nothing to sync). */
        fun syncBatteryMirror() {
            if (!usesDataFolder || !legacy.exists()) return
            try {
                legacy.inputStream().use { input -> outputStream().use { out -> input.copyTo(out) } }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.syncBatteryMirror(${legacy.name}) failed — folder copy may be stale, local mirror still has the latest", e)
            }
        }

        /** Best-effort copy of [legacy]'s current bytes into the automatic
         *  own-folder mirror's "Saves" subfolder — see
         *  autoFolderMirrorActive()/autoFolderRoot() above. Skipped
         *  entirely once a Storage folder is configured (usesDataFolder) —
         *  that's this app's "own folder" now, see autoFolderMirrorActive()
         *  — and whenever [legacy] doesn't exist yet, same as every other
         *  method here. Deliberately reads from [legacy] specifically
         *  rather than going through outputStream()/doc(): [legacy] is only
         *  guaranteed to hold this entry's current bytes when
         *  !usesDataFolder (see stageForWrite()'s own doc comment — a
         *  configured Storage folder stages state-slot writes through a
         *  scratch cache file instead), which is exactly the one condition
         *  this method already requires before doing anything. Never
         *  throws: same "must never block or fail the real save" discipline
         *  as syncBatteryMirror()/commitWrite() above — this is purely a
         *  convenience copy on top of a write that has already succeeded. */
        fun mirrorToAutoFolder() {
            if (usesDataFolder || !legacy.exists()) return
            val dest = autoMirrorSubdir("Saves") ?: return
            try {
                legacy.copyTo(File(dest, legacy.name), overwrite = true)
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.mirrorToAutoFolder(${legacy.name}) failed", e)
            }
        }
    }

    /** Set only while showStorageSettings()'s dialog is on screen, so
     *  dataFolderPicker's callback above can refresh its status text in
     *  place instead of needing the user to close and reopen it. */
    internal var refreshStorageSettingsUi: (() -> Unit)? = null

    /** FIX (quicksave race pass): guards quickSaveState()/quickLoadState()
     *  against overlapping calls. Both used to spawn a brand-new, totally
     *  unsynchronized Thread on every tap — a fast double-tap of Quick Save,
     *  or Quick Save immediately followed by Quick Load (exactly the "test
     *  saving/loading fast" case), fired two Threads with no ordering
     *  between them. g_core_mutex on the native side only serializes the
     *  moment of the actual file write/read against the running game
     *  thread — it does NOT decide which Kotlin thread reaches that point
     *  first. So a fast second tap could win that race and load the file
     *  from BEFORE the first tap's save had written it (looks like it
     *  "loaded the old/first save"), or two saves could land in either
     *  order (looks like it "saved a different frame" than expected). This
     *  flag makes a tap that arrives while one is still in flight a no-op
     *  (with its own toast) instead of racing — same one-thing-at-a-time
     *  guarantee MyBoy's pause-then-menu flow gets for free by construction.
     *
     *  FIX (audit pass): renamed from quickStateBusy and now also guards
     *  showSaveStateSlotDialog()'s save/load Thread, which had the exact
     *  same unguarded pattern — every reason above applies identically
     *  there (it calls the same nativeSaveState()/nativeLoadState(), off
     *  the same kind of bare background Thread, with no ordering between
     *  overlapping calls either). Narrower to actually hit in practice —
     *  the slot dialog dismisses itself after one tap, so it takes two
     *  separate menu visits in quick succession rather than one fast
     *  double-tap on an always-visible button — but it's the identical
     *  underlying race, and one flag correctly covering *every* save-state
     *  operation (quick or slot) is simpler and safer than two flags that
     *  would each need to know about the other to close the gap between
     *  them (a quick-save racing a slot-load, etc.). */
    internal val saveStateBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FEATURE: new — self-service crash log, no logcat/adb needed. See
        // installCrashLogger()'s own doc comment. Installed as the literal
        // first thing after super.onCreate() so it's active before
        // anything else in this method — or any background thread this
        // method goes on to spawn, e.g. loadRomFromUri()'s — gets a chance
        // to throw.
        installCrashLogger()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // FIX: let the window draw into the camera-cutout area instead of
        // leaving the default black bar there. LAYOUT_IN_DISPLAY_CUTOUT_MODE_
        // DEFAULT letterboxes around the cutout on whichever edge it sits
        // on — most visible in landscape (still the default orientation
        // below), where the cutout (normally the phone's physical top edge,
        // a "short" edge) ends up intruding into the middle of the
        // horizontal game view instead of just sitting inside a status bar
        // that's already hidden.
        //
        // FIX (this pass): reported as still a lot of black area around the
        // cutout even with SHORT_EDGES. Upgraded to ALWAYS on API 30+,
        // which is a strict superset of SHORT_EDGES — "content is always
        // allowed to extend into the cutout areas" outright, with none of
        // SHORT_EDGES's own conditions about which edge or bar state — so
        // this can only extend the drawable area further, never shrink it.
        // ALWAYS needs API 30 specifically (SHORT_EDGES, the previous only
        // option here, needs API 28); below 30 this still falls back to
        // SHORT_EDGES exactly as before. Genuinely uncertain this fully
        // explains what was reported rather than just being a real,
        // separate improvement alongside it — no device in this sandbox to
        // confirm either way, and "a lot of black screen" without a
        // screenshot leaves real room for this being partly/wholly a
        // different area entirely (see RomBrowserActivity.kt, which had no
        // cutout handling at all before this pass — a confirmed gap, not a
        // guess, since that Activity is new this same overall changeset).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            stretchToFit          = p.getBoolean(PREF_STRETCH,    false)
            maxFrameSkips         = p.getInt(PREF_MAX_SKIPS,      0)
            linearFilterEnabled   = p.getBoolean(PREF_LINEAR_FILTER, false)
            soundEnabled          = p.getBoolean(PREF_SOUND_ENABLED, true)
            soundVolumePercent    = p.getInt(PREF_SOUND_VOLUME,   100)
            soundFrequencyHz      = p.getInt(PREF_SOUND_FREQ,     44100)
            showFpsOverlay        = p.getBoolean(PREF_SHOW_FPS,   false)
            debugMemoryViewerEnabled = p.getBoolean(PREF_DEBUG_MEMORY_VIEWER, true)
            debugLinkLogEnabled      = p.getBoolean(PREF_DEBUG_LINK_LOG, true)
            autoSaveLoadEnabled   = p.getBoolean(PREF_AUTO_SAVE_LOAD, false)
            gridDivisions         = p.getInt(PREF_GRID_SIZE,      8)
            showGrid              = p.getBoolean(PREF_SHOW_GRID,  false)
            snapToGrid            = p.getBoolean(PREF_SNAP_GRID,  false)
            screenOrientationChoice = p.getInt(PREF_ORIENTATION, ORIENTATION_LANDSCAPE)
            musicEnabled          = p.getBoolean(PREF_MUSIC_ENABLED, false)
            musicShuffle           = p.getBoolean(PREF_MUSIC_SHUFFLE, false)
            musicVolume            = p.getFloat(PREF_MUSIC_VOLUME, 0.7f)
            p.getString(PREF_MUSIC_FOLDER_URI, null)?.let { musicFolderUri = Uri.parse(it) }
        }
        updateLinearFilterPaint()
        updateSoundFrequencyFactor()
        // FEATURE: screen orientation setting (Video settings, see
        // applyScreenOrientationPref()/showVideoSettings()). This used to be
        // a fixed requestedOrientation = SCREEN_ORIENTATION_LANDSCAPE right
        // here, with android:screenOrientation="landscape" in the manifest
        // on top of it — see AndroidManifest.xml for why that attribute is
        // now "unspecified" instead. android:configChanges there already
        // keeps this activity (and the running core) alive across whatever
        // orientation change this causes, exactly as it did for the old
        // hardcoded assignment, so nothing about restart/config-change
        // handling needed to change for this.
        applyScreenOrientationPref()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // FIX (pass 43 — direct report: "if i clear cache my button reset"):
        // pre-fills SharedPreferences from the automatic own-folder backup
        // when — and only when — it has nothing of its own to offer
        // loadCustomLayout() right below. See importLayoutBackupIfNeeded()'s
        // own doc comment; loadCustomLayout() itself is unchanged.
        importLayoutBackupIfNeeded()
        loadCustomLayout()
        // FEATURE — background music: applies the persisted volume to
        // the (not-yet-created) player up front, then starts playback
        // if a folder was already chosen in a previous session and the
        // toggle was left on.
        musicPlayer = MusicPlaylistPlayer(applicationContext)
        musicPlayer.setVolume(musicVolume)
        startMusicIfEnabled()

        link = LinkMultiplayer(this)
        // FEATURE (screen recorder) — see GameScreenRecorder.kt's own
        // doc comment. lateinit + assigned here (not a field initializer
        // like musicPlayer above) for the same reason `link` itself is:
        // it needs the fully-constructed Activity instance, not just a
        // bare Context, and onCreate() is where that's safe to hand out.
        screenRecorder = GameScreenRecorder(this)

        // FIX 17: durable link-debug logging that doesn't depend on OS
        // logcat access — see KNOWN_LIMITATIONS.md's "The debug-log tool
        // doesn't work on every phone" and copyLinkDebugLog() below, which
        // now reads this file instead of shelling out to `logcat`. filesDir
        // is always writable by this app, on every device, with no
        // permission needed — unlike reading back the system's own logcat
        // buffer, which some OEM builds restrict even for an app reading
        // its own output.
        EmulatorEngine.nativeSetLinkLogPath(File(filesDir, "link_debug.log").absolutePath)
        // FIX 9: previously nothing ever told this side when the *other*
        // phone disconnected — isConnected only ever went back to false via
        // our own local "Disconnect" tap. link.onPeerLost fires from
        // LinkMultiplayer's liveness watchdog / BYE handling, already on the
        // main thread, so this can update UI directly.
        link.onPeerLost = { EmulatorEngine.nativeLinkStop(); uiToast("Peer disconnected") }
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // FIX (this pass): the floating "▶ Load ROM" button that used to sit
        // here is gone. It was a Button, and a stock Material Button carries
        // a small default elevation even when nothing sets one explicitly —
        // enough that Android's Z-order draws it ABOVE the opaque
        // settingsMenuOverlay added later in this method (and, before it
        // became a separate Activity, the ROM browser overlay too),
        // regardless of add order. Since changeRom() (below, and on Close —
        // see closeGame()) already opens the ROM browser automatically any
        // time there's no ROM loaded, that button was floating uselessly on
        // top of the browser it was supposed to sit *behind* — visible as a
        // stray purple pill hovering over the file list. Removed outright
        // rather than patched (e.g. elevation = 0f), since changeRom()
        // already covers every case it existed for. The one thing it also
        // did — give the user a way back in in the two edge cases where
        // nothing else is on screen (the folder picker gets cancelled
        // before any folder's ever been chosen, or a ROM load fails) — is
        // now handled by onGameTouch() below: tapping the idle surface while
        // no ROM is loaded calls changeRom() directly.

        // UI: the 🔗 Link and 📂 change-ROM buttons that used to float here
        // (top-right, always on top of the game view) are gone — both now
        // live as rows inside the Settings list instead ("Link remote",
        // "Link local", "Change ROM" — see buildSettingsMenu()), reached via
        // the ⚙ button below. One less pair of icons sitting over gameplay,
        // and Settings was already scrollable so the extra rows just fit.
        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            // FIX: setPadding below was raw pixels, not dp — the same
            // "forgot this one spot" gap this file's own comments already
            // trace for several other paddings/margins (e.g. the per-item
            // editor bar's own EDIT_TOOLBAR_GAP_DP fix, and this same
            // button's own topMargin/leftMargin just below).
            setTextColor(Color.WHITE); setPadding(dp(20), dp(6), dp(20), dp(6))
            background = iconChipBackground()
            setOnClickListener { showGameMenu() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            // FIX: was raw topMargin = 8; leftMargin = 8 — 8 *pixels*, not
            // 8dp, same bug class as setPadding just above. On a
            // high-density phone this button sat only a couple of dp from
            // the true screen corner instead of the intended 8dp.
            it.topMargin = dp(8); it.leftMargin = dp(8)
        })

        // ── Control-layout editor UI ────────────────────────────────────────
        // Two small real-View toolbars layered above the SurfaceView. Editing
        // itself (drag/resize hit-testing) happens on the SurfaceView's touch
        // events (see onEditTouch) exactly like normal gameplay input — these
        // bars are just chrome: mode controls + per-button fine adjustment.
        // FIX (Fortieth pass — reported directly: "control size... plus
        // and minus... really hard to click its very small"): setPadding
        // below took raw pixels, not dp, unlike every other size in this
        // file (which all go through dp()) — on a real, higher-density
        // phone that's a handful of actual pixels, not the "18/4" it reads
        // as in the source. Barely visible on the worded top-bar chips
        // ("Add Control" etc.), where the text itself provides most of the
        // width either way, but it's nearly a single-glyph "-"/"+" chip's
        // *entire* size — exactly the ones called out. minTouchDp lets a
        // specific chip additionally guarantee a real minimum touch target
        // (Android's own 48dp guideline) no matter how little content/
        // padding would otherwise produce; only the four "-"/"+" call
        // sites below pass it — every other chip keeps its old
        // hug-content sizing, just with the dp() padding fix applied.
        fun editChip(label: String, minTouchDp: Int = 0, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setPadding(dp(18), dp(4), dp(18), dp(4))
            val minPx = if (minTouchDp > 0) dp(minTouchDp) else 0
            minWidth = minPx; minimumWidth = minPx; minHeight = minPx; minimumHeight = minPx
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#552A2A3A"))
            setOnClickListener { onClick() }
        }

        // CUSTOMIZATION UI (this pass): every label below is plain text —
        // no emoji/dingbat glyphs anywhere in this editor UI, per the
        // request. "Reset All" is now "Reset Controls" (matches the wording
        // asked for); a "Grid" entry point was added alongside it — see
        // showGridSettingsDialog().
        editTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            // FIX: both setPadding calls in this block were raw pixels,
            // not dp — same bug class as editTopBarScroll's own topMargin
            // fix just below this bar's construction, and directly part of
            // the same "control customization popup" reported as cut
            // off/cramped.
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.parseColor("#DD1A1A22"))
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "Edit Layout"
                setTextColor(Color.parseColor("#FFEE58")); textSize = 12f
                setPadding(dp(8), dp(8), dp(24), dp(8))
            })
            // ADD/REMOVE CONTROL — opens the picker of currently-hidden
            // controls (see showAddControlMenu). Removing one is done by
            // holding it instead (see onEditTouch/showRemoveButtonMenu) —
            // full instructions are in the toast shown on entering edit
            // mode (enterEditMode()), kept off this bar so it stays short
            // enough to fit alongside these buttons in landscape.
            addView(editChip("Add Control")    { showAddControlMenu() })
            addView(editChip("Reset Controls") { confirmResetAllLayout() })
            addView(editChip("Grid")           { showGridSettingsDialog() })
            addView(editChip("Cancel")         { exitEditMode(save = false) })
            addView(editChip("Done")           { exitEditMode(save = true) })
        }
        // Wrapped in a HorizontalScrollView so this row degrades to
        // scrollable (instead of clipping off-screen) on narrower landscape
        // widths now that it holds five buttons instead of three — see the
        // BUG FIX comments around the button-editor's hitbox/precision
        // issues above for the broader "landscape + this editor" theme.
        // Visibility is still toggled on editTopBar itself (enterEditMode/
        // exitEditMode) — a GONE child collapses this wrapper to nothing,
        // so no extra plumbing needed here for that.
        editTopBarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(editTopBar)
        }
        // FIX (this pass — same direct report as four previous passes'
        // refreshEditToolbarPosition() fix attempts: "if you move it
        // sometimes it disappears or get cutoff"): topMargin below was raw
        // pixels, not dp — the same bug class this file's own comments
        // already trace for several other paddings/margins, this time on
        // the one input every one of those previous fix attempts assumed
        // was already correct. refreshEditToolbarPosition() computes the
        // per-item bar's minimum allowed top (topBound, right below) from
        // this bar's own laid-out height/position, so every previous pass
        // was re-deriving the clamp math against a *slightly wrong* input
        // — on a high-density phone this sat only a couple of dp from the
        // top instead of the intended 8dp, and topBound was reading
        // editTopBar's own height directly rather than this wrapper's
        // (see that fix for the rest of it). Neither gap alone was large,
        // but both fed the exact same downstream clamp, and no previous
        // pass's fix touched either one — each just re-tuned the clamp
        // formula itself against inputs that were quietly off to begin
        // with, which is consistent with the bug surviving that many
        // separate attempts at the formula alone.
        root.addView(editTopBarScroll, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; it.topMargin = dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP) })

        // Per-item bar, restructured (this pass) into three stacked rows
        // instead of one long horizontal strip of chips — the requested
        // labels ("Game Screen Size", "Control Size", "Control Opacity")
        // are full words, not something that fits cleanly as bare "Size±"/
        // "Op±" chip text the way the old single-row version had them.
        // Row 1: which control is selected, its lock state, and its own
        //         reset — unchanged in spirit, plain text instead of
        //         lock emoji/↺ glyph.
        // Row 2: size, label switches between "Game Screen Size" and
        //         "Control Size" — see onEditTouch's ACTION_DOWN.
        // Row 3: opacity — hidden outright when the game screen is
        //         selected (see editOpacityRow's own field comment).
        // FIX (this pass — direct report: "make the pop up smaller"): was
        // setPadding(14, 4, 14, 4) — raw pixels, not dp, the exact same
        // mistake EDIT_TOOLBAR_GAP_DP's own comment already traces for the
        // bar's margin/gap (≈4-5dp on a typical ~3x-density phone, not the
        // 14dp it reads as in code). Fixed to real dp here too, and sized
        // down at the same time — textSize 13→12 and a smaller dp() padding
        // that's still consistent across every density, instead of an
        // accidentally-tiny raw-px value that only *looked* small on this
        // pass's own test device.
        editButtonLabel = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(8), dp(3), dp(8), dp(3))
            // FIX (see editRow1ChipsWidthPx's own field comment above):
            // maxWidth alone is a no-op without ellipsize, and
            // TruncateAt.END without maxLines=1 wraps to a second line
            // instead of truncating the first — need all three together
            // for "…" on one line. maxWidth itself is set by
            // refreshEditToolbarPosition() on every call, not here, since
            // it depends on the current screen width.
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        editLockBtn = editChip("Unlocked") { toggleSelectedLock() }
        editResetBtn = editChip("Reset") { editSelectedId?.let { resetSingleButton(it) } }
        // See editRow1ChipsWidthPx's own field comment above for why this
        // is measured here, once, off each chip's own real paint/padding
        // rather than guessed — computed at construction, not inside
        // refreshEditToolbarPosition() itself, since unlike
        // editRowLabelWidthPx's label, neither chip's text or style ever
        // changes afterward, so there's nothing to re-measure per call.
        editRow1ChipsWidthPx =
            (editLockBtn.paint.measureText("Unlocked").toInt() + editLockBtn.paddingLeft + editLockBtn.paddingRight) +
            (editResetBtn.paint.measureText("Reset").toInt() + editResetBtn.paddingLeft + editResetBtn.paddingRight)
        val editRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editButtonLabel)
            addView(editLockBtn)
            addView(editResetBtn)
        }
        // FEATURE (direct report: "add a way to move button without
        // swipe like arrow up down left right"): an alternative to
        // dragging for fine, precise repositioning, ordered to match the
        // request's own wording. Each tap moves the selected control by
        // EDIT_NUDGE_STEP_DP in one direction through
        // clampControlCenterToScreen()/snapPositionToGrid() — the exact
        // same path a drag already goes through (see nudgeSelected() and
        // onEditTouch's own ACTION_MOVE above it) — so nudging can never
        // put a control anywhere a drag couldn't also have put it.
        // minTouchDp = 40 on all four: these are the same kind of small,
        // single-character, tap-repeatedly button the old "-"/"+" size
        // chips were before a direct report called them "really hard to
        // click, very small" — this pass doesn't repeat that, rather
        // than trusting editChip()'s own padding alone the way editRow1's
        // Lock/Reset chips do (those hold full words, wide enough on
        // their own). A small rightMargin between each (not on the last)
        // keeps adjacent directions from being mis-tapped for each other.
        editNudgeUpBtn = editChip("^", minTouchDp = 40) { nudgeSelected(0f, -dp(EDIT_NUDGE_STEP_DP).toFloat()) }
        editNudgeDownBtn = editChip("v", minTouchDp = 40) { nudgeSelected(0f, dp(EDIT_NUDGE_STEP_DP).toFloat()) }
        editNudgeLeftBtn = editChip("<", minTouchDp = 40) { nudgeSelected(-dp(EDIT_NUDGE_STEP_DP).toFloat(), 0f) }
        editNudgeRightBtn = editChip(">", minTouchDp = 40) { nudgeSelected(dp(EDIT_NUDGE_STEP_DP).toFloat(), 0f) }
        val editNudgeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val btnGap = dp(EDIT_TOOLBAR_ROW_GAP_DP)
            addView(editNudgeUpBtn, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = btnGap })
            addView(editNudgeDownBtn, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = btnGap })
            addView(editNudgeLeftBtn, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = btnGap })
            addView(editNudgeRightBtn)
        }
        // FIX (this pass): "-"/"+" chips replaced with a real slider (drag
        // anywhere along it) plus a tap-to-type-exact-number readout — see
        // sliderRow()/SliderRow in SharedUi.kt. Direct report: "in control
        // size there's plus and minus but it really hard to click its very
        // small... maybe a slider with number or percent and you can type
        // the number". editSizeLabel stays a separate field (rather than a
        // label baked into sliderRow itself) because its text keeps
        // swapping between "Control Size"/"Game Screen Size" after
        // construction — see syncEditButtonBarToSelection(). Both rows are
        // given an explicit width (dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP) below)
        // rather than left at WRAP_CONTENT: the SeekBar's own weight=1 (see sliderRow()) only
        // has room to expand into an *exact*-width parent, not a
        // WRAP_CONTENT one, since there's no "extra space" for weight to
        // distribute otherwise.
        //
        // FIX (this pass — direct report: "the slider and number input box
        // aligned horizontally and vertically"): editSizeLabel and the
        // opacity row's label used to each be their own bare TextView,
        // sized to hug whichever text they held — "Control Size"/"Game
        // Screen Size" for one, the always-fixed "Control Opacity" for the
        // other. Since those strings are different lengths, the sliders
        // sitting right after them landed at two different x positions,
        // one row not lined up under the other. editRowLabel() below gives
        // every label in this bar the exact same look in one place, and
        // both rows now pin that label to editRowLabelWidth — measured
        // from the *longest* string either one can ever show ("Game Screen
        // Size") rather than guessed as a constant, so it's exactly wide
        // enough on any device/font and never clips. With both labels the
        // same width, both sliders start at the same x — one steady
        // two-column grid instead of two rows that happen to independently
        // wrap their own content.
        // labelText, not text: TextView has its own "text" property, and
        // an unqualified "text" on the right of an assignment *inside*
        // this apply{} block would resolve to that (silently reading back
        // whatever the TextView's own text already was, i.e. always
        // ""/empty here) rather than this function's parameter — the same
        // implicit-receiver-shadows-outer-name trap sliderRow()'s own
        // comment already calls out for SeekBar.max, just one property
        // name over. Distinct names sidesteps it the same way.
        // FIX (this pass — direct report: "make the pop up smaller"): text
        // 12→11sp and tighter start/end padding. editRowLabelWidth right
        // below is *measured* from this exact paint/padding, so shrinking
        // either one here automatically narrows both row2 and the opacity
        // row — nothing to keep in sync by hand.
        fun editRowLabel(labelText: String = "") = TextView(this).apply {
            text = labelText
            textSize = 11f; setTextColor(Color.parseColor("#CCCCCC")); setPadding(dp(8), dp(3), dp(6), dp(3))
        }
        editSizeLabel = editRowLabel()
        editRowLabelWidthPx = editSizeLabel.paint.measureText("Game Screen Size").toInt() +
            editSizeLabel.paddingLeft + editSizeLabel.paddingRight + dp(4)
        editSizeSlider = sliderRow(
            min = 50, max = 800, initial = 100,
            label = { editSizeLabel.text.toString() }
        ) { setSelectedScalePercent(it) }
        val editRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editSizeLabel, LinearLayout.LayoutParams(editRowLabelWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(editSizeSlider.root, LinearLayout.LayoutParams(dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        // Opacity's own floor: alphaToPercent(60), not 0 — see that
        // function's own comment for why a control can be dimmed a lot but
        // never made fully invisible/undiscoverable this way.
        editOpacitySlider = sliderRow(
            min = alphaToPercent(60), max = 100, initial = 100,
            label = { "Control Opacity" }
        ) { setSelectedAlphaPercent(it) }
        editOpacityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(editRowLabel("Control Opacity"), LinearLayout.LayoutParams(editRowLabelWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(editOpacitySlider.root, LinearLayout.LayoutParams(dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        editButtonBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // FIX (this pass — direct report: "make the pop up smaller"):
            // was dp(10)/dp(6) — trimmed alongside every other size in this
            // block; see EDIT_TOOLBAR_ROW_GAP_DP/_SLIDER_WIDTH_DP's own
            // comment in the companion object for the rest of this pass.
            setPadding(dp(8), dp(5), dp(8), dp(5))
            // FIX (this pass — direct report: "make pop up circle edge"):
            // was a flat setBackgroundColor() — square corners — see
            // editToolbarBackground() in SharedUi.kt for the same fill
            // rounded to match every other popup in the app.
            background = editToolbarBackground()
            visibility = View.GONE
            // FIX (this pass — direct reports: the popup "get cut off" and
            // "the slider and box is not aligned"): editSizeSlider's/
            // editOpacitySlider's own value boxes (36dp tall at the time —
            // see EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP in SharedUi.kt for the
            // current number) are taller than editRow1's plain
            // chips/text, so with all three rows stacked directly against
            // each other there was no room for that extra height without
            // visually spilling into the row above/below — that's what
            // actually read as "cut off"/"not aligned" here, on top of
            // refreshEditToolbarPosition()'s own separate off-screen-
            // clamping fix below. A small explicit gap between rows fixes
            // it without shrinking the touch target any further.
            //
            // FIX (this pass — direct report: "make the pop up smaller"):
            // 6dp → EDIT_TOOLBAR_ROW_GAP_DP (4dp) — still a clearly visible
            // gap between rows, just tighter, now that the value boxes
            // themselves are also shorter (see EDIT_TOOLBAR_VALUE_BOX_
            // HEIGHT_DP in SharedUi.kt) so there's less height to separate.
            val rowGap = dp(EDIT_TOOLBAR_ROW_GAP_DP)
            addView(editRow1, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = rowGap })
            addView(editNudgeRow, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = rowGap })
            addView(editRow2, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = rowGap })
            addView(editOpacityRow)
        }
        // Positioned dynamically (see refreshEditToolbarPosition) — x/y set
        // directly rather than via gravity, since it needs to track whichever
        // button is currently selected.
        root.addView(editButtonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        // ── Settings screen ──────────────────────────────────────────────
        // Built once and just shown/hidden (same pattern as editTopBar
        // above) — it has no dynamic state of its own, unlike the category
        // dialogs it opens, which rebuild their fields fresh every time.
        settingsMenuOverlay = buildSettingsMenu().apply { visibility = View.GONE }
        root.addView(settingsMenuOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ── Memory viewer ────────────────────────────────────────────────
        // Same built-once/shown-hidden pattern as Settings just above — see
        // showMemoryViewer()'s doc comment for why this is an overlay
        // rather than its own Activity (needs the game loop to keep
        // running underneath it, unlike the ROM browser).
        memoryViewerOverlay = buildMemoryViewer().apply { visibility = View.GONE }
        root.addView(memoryViewerOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ROM file browser: was built and attached here as an overlay,
        // same built-once/shown-hidden pattern as the Settings screen just
        // above — now RomBrowserActivity.kt, its own Activity, launched via
        // changeRom()/romBrowserLauncher instead. Nothing to build here.

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()

        // FIX (direct report: pressing the phone's back button while
        // playing instantly exits the app — and separately, "the button
        // customization reset", specifically when that happened while the
        // layout editor was open, since nothing had a chance to run
        // before the process/Activity was torn down). MainActivity had no
        // back handling at all before this — the system default just
        // finishes the Activity outright, skipping every custom overlay
        // below entirely, including one that might have unsaved edits
        // sitting in memory. OnBackPressedCallback (the base
        // androidx.activity API, not activity-ktx's addCallback{} lambda —
        // see RomBrowserActivity.onCreate()'s own comment for why: this
        // project doesn't have that artifact declared) intercepts it
        // instead. Checked topmost-open-thing-first: editModeActive means
        // exitEditMode(false) — discard, the same outcome as tapping
        // Cancel (see that button's own binding below), so an abrupt back
        // press can no longer lose anything a real Save wouldn't already
        // have kept. memoryViewerOverlay/settingsMenuOverlay are plain
        // custom overlays, not real Dialogs, so unlike every AlertDialog
        // elsewhere in this file — including showGameMenu() itself —
        // back doesn't already dismiss them on its own the way it does a
        // real Dialog's own window; both need the same explicit
        // visibility flip their own on-screen Back/✕ buttons already use.
        // With none of those open, back now opens the game menu instead
        // of exiting — the actual request here — so leaving the app for
        // good is only ever that menu's own explicit Close item from here
        // on, never an accidental side effect of the system button/gesture.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    editModeActive -> exitEditMode(save = false)
                    memoryViewerOverlay.visibility == View.VISIBLE -> hideMemoryViewer()
                    settingsMenuOverlay.visibility == View.VISIBLE -> settingsMenuOverlay.visibility = View.GONE
                    else -> showGameMenu()
                }
            }
        })

        // FEATURE: land straight in ROM selection instead of requiring an
        // explicit tap first — changeRom() launches RomBrowserActivity
        // unconditionally; whether that lands the user straight in the
        // folder they last browsed, prompts for permission first, or
        // whatever else, is entirely that Activity's own concern now (see
        // RomBrowserActivity.kt), not something this onCreate() needs to
        // know about. If the user backs out of it with nothing picked
        // (permission denied, cancelled, whatever), romBrowserLauncher's
        // callback above does nothing and the surface just sits idle —
        // tapping it calls changeRom() again (see onGameTouch()), so
        // there's still a way back in without any button needed underneath.
        changeRom()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        // FIX (Twenty-first pass): last-resort flush of the battery-save
        // mirror to the chosen Storage folder, if one is configured — see
        // SaveEntry.syncBatteryMirror(). onPause() below is the main place
        // this happens; this is just a backstop for whatever's played
        // between onPause and the process actually going away, e.g. a
        // resumed session that's then killed outright rather than just
        // backgrounded. mirrorToAutoFolder() alongside it — see the FEATURE
        // block above dataFolderTree() — for the same backstop, but for the
        // automatic own-folder mirror instead of a chosen SAF folder.
        if (romLoaded) {
            batterySaveEntry(currentRomBaseName).syncBatteryMirror()
            batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
        }
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
        musicPlayer.release()
        // FEATURE (screen recorder) — see stopScreenRecordingForLifecycle()'s
        // own comment (MainActivityRecorder.kt): a backstop matching
        // onPause()'s own call just below, for whatever's played between
        // onPause and the process actually going away.
        stopScreenRecordingForLifecycle()
    }

    // FIX: no onPause/onResume existed at all. The emulation thread and the
    // AudioTrack were only ever stopped from surfaceDestroyed()/onDestroy(),
    // but backgrounding an app (Home button, recents, notification shade)
    // does not reliably or promptly destroy a SurfaceView's Surface — so the
    // game kept running full-speed and audio kept playing while the app was
    // not visible, burning battery/CPU and producing audio "leaking" behind
    // whatever the user switched to. This is exactly the kind of background
    // battery-drain behavior Play Console's background-usage checks flag.
    override fun onPause() {
        super.onPause()
        stopGameLoop()
        // FEATURE (background music) — no business playing while the app
        // itself isn't in front, same reasoning as stopGameLoop() just
        // above (see this override's own FIX comment).
        pauseMusicForLifecycle()
        // FEATURE (screen recorder) — can't keep capturing game frames
        // once stopGameLoop() above has stopped producing them, and
        // leaving a recording open across a backgrounding is exactly the
        // kind of unbounded-file/leaked-resource risk that reasoning
        // applies to as well. See its own comment.
        stopScreenRecordingForLifecycle()
        // FIX (Twenty-first pass): flush the battery-save mirror out to the
        // chosen Storage folder (no-op if none is configured, or if nothing
        // has been played yet — see SaveEntry.syncBatteryMirror()). Backgrounding
        // is the single most common way a session actually ends on Android —
        // Home button, notification shade, a phone call — far more often
        // than onDestroy() ever runs, so this is the flush that actually
        // matters in practice; onDestroy()'s own call is just a backstop.
        // mirrorToAutoFolder() alongside it — see the FEATURE block above
        // dataFolderTree() — same flush, automatic own-folder mirror
        // instead of a chosen SAF folder.
        if (romLoaded) {
            batterySaveEntry(currentRomBaseName).syncBatteryMirror()
            batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
            // FEATURE (direct report — Misc setting "Auto Save & Load",
            // "like myboy... auto save game on exit points load it back
            // on start"): deliberately synchronous, unlike every other
            // save-state write in this file (quickSaveState()/
            // showSaveStateSlotDialog() both spawn a background Thread —
            // see saveStateBusy's own doc comment for why). Those are
            // optimized to keep gameplay responsive while the game loop
            // is still running; this one specifically needs to be *done*
            // before onPause() returns, since Android may kill the
            // process shortly after onPause()/onStop() complete —
            // especially under memory pressure — with no guarantee a
            // fire-and-forget background Thread ever gets to finish.
            // stopGameLoop() just above already means there's no running
            // game thread left to contend with the native core mutex
            // either way, so a direct call here is safe as well as
            // necessary. No equivalent call in onDestroy() as a backstop,
            // unlike the battery-save mirror just above: onDestroy() is
            // only ever reached by way of this same onPause() first (a
            // killed process doesn't run onDestroy() either), and the
            // game loop is already stopped by the time this runs, so
            // nothing could change the emulator's state between here and
            // onDestroy() that a second save would ever need to catch.
            if (autoSaveLoadEnabled) {
                try {
                    val entry = autoStateEntry()
                    backupIfExists(entry)
                    val localPath = entry.stageForWrite()
                    if (EmulatorEngine.nativeSaveState(localPath)) {
                        entry.commitWrite(localPath)
                        entry.mirrorToAutoFolder()
                        // Thumbnail capture still runs on its own
                        // background Thread here, not inline, even though
                        // captureStateThumbnail() no longer blocking-waits
                        // on a PixelCopy/main-thread round trip the way it
                        // used to (see its own doc comment: it now copies
                        // frameBuffers[displayIdx] directly under
                        // bufferLock instead) — the deadlock risk that
                        // originally forced this onto a background Thread
                        // is gone, but it's kept async anyway, deliberately:
                        // the thumbnail is cosmetic, not data, so if the
                        // process dies before this Thread finishes, the
                        // Autosave row simply keeps showing its previous
                        // thumbnail until the next chance to update it —
                        // the state save above it, the part that actually
                        // matters, is already safely done, and there's no
                        // reason to let a purely cosmetic capture delay
                        // onPause() returning right after it.
                        Thread { captureStateThumbnail(SlotKind.Autosave) }
                            .apply { name = "mGBA-autosave-thumb" }.start()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Autosave-on-pause failed", e)
                }
            }
        }
        try {
            audioTrack?.pause()
            // AUDIO FIX: pause() alone leaves whatever was already queued in
            // the AudioTrack's internal buffer intact. If the app is
            // backgrounded for a while and then resumed, that stale audio
            // would play first, ahead of anything the resumed game loop
            // writes — an audible "blip" of old sound. flush() (only valid
            // once paused/stopped) discards it so resume always starts clean.
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (romLoaded && surfaceHolder != null && !running) {
            startGameLoop()
        }
        resumeMusicForLifecycle()
    }

    // FIX: setImmersive() was only ever called once, at the very end of
    // onCreate. Every AlertDialog this app opens — the game menu, each
    // Settings category, save-state prompts, all of them — takes window
    // focus away and back, and that resets the old systemUiVisibility
    // flags, so the status/nav bars crept back in the moment any dialog was
    // shown and dismissed. Re-applying on every focus regain (not just
    // launch) is the standard fix for immersive mode "not sticking".
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setImmersive()
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())   // also calls updateGameMatrix() internally now
        if (romLoaded && !running) startGameLoop()
        // BUG FIX: this fires on every resize — a user-triggered orientation
        // change (see applyScreenOrientationPref()), entering/exiting
        // split-screen, etc. A SurfaceView's buffer doesn't repaint itself
        // just because it changed size — whatever pixels were already in it
        // stay there, stretched/cropped to the new dimensions, until
        // something actually draws again. Without this, that could briefly
        // be a stretched copy of the last black-cleared frame (harmless) or,
        // in some resize orderings, genuinely undefined content — either
        // way, repainting black immediately at the new size is cheap and
        // removes any doubt.
        else clearSurfaceToBlack()
    }

    // Scratch list buildControlLayout() appends into via addButton(); only
    // ever touched from the UI thread, then published atomically to
    // `buttons` in one assignment at the end of buildControlLayout().
    internal var buildingButtons = mutableListOf<ButtonDef>()

    // ── Draw controls ──────────────────────────────────────────────────────

    internal val fillPaint   = Paint(Paint.ANTI_ALIAS_FLAG)
    internal val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    // FEATURE: linearFilterEnabled (declared above with stretchToFit/
    // maxFrameSkips — see the FIX note there for why its declaration is
    // worth a second look) wired up here. Bilinear (isFilterBitmap = true)
    // softens the GBA's blocky upscaled pixels; nearest-neighbor (false,
    // the default, matching every previous pass's actual on-screen
    // behavior since this used to always be a plain `null` Paint, which
    // the Canvas API treats as filtering off) keeps them crisp. One
    // shared, mutable Paint instead of a fresh one per frame —
    // updateLinearFilterPaint() below flips isFilterBitmap on the same
    // instance whenever the setting changes, rather than needing a new
    // object either way.
    internal val gamePaint = Paint().apply { isFilterBitmap = false }
    // Reused by captureGameFrameBitmapInto() (MainActivitySaveStateUi.kt)
    // on every recorded video frame — a Canvas re-pointed at a
    // different destination Bitmap via setBitmap() each call instead of
    // `Canvas(bitmap)`-constructing a new one, and a RectF whose bounds
    // just get overwritten each call instead of a new RectF — same
    // "shared, mutable instance beats a fresh allocation on a hot path"
    // reasoning as gamePaint itself just above and shoulderPathL/R
    // further down. See that function's own doc comment for the full
    // story (a direct report this was a contributing cause of).
    internal val gameFrameScratchCanvas = Canvas()
    internal val gameFrameScratchDstRect = RectF()
    internal val labelPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    // Cached VectorDrawables for this app's real-icon buttons/controls —
    // real vector resources (res/drawable/ic_quick_load.xml etc.) instead
    // of the Canvas Path/Arc or Unicode-text-glyph drawing these all used
    // to do inline, at various points (iconRecord/iconDpadArrow/
    // iconFastForward are the newer three — "record" drew a plain
    // canvas.drawCircle(), the d-pad arms drew "▲▼◀▶" as text, and
    // fast-forward drew "»" as text, up through the passes that gave each
    // a real vector resource and folded it into this same cache; see
    // actionIconFor() and drawActionButtonIcon()/drawDpad()/
    // drawControls()'s own FIX comments, MainActivityControlLayout.kt).
    // The first four go through actionIconFor()'s [id]-keyed lookup since
    // they're entries in the generic `buttons` list; iconDpadArrow and
    // iconFastForward don't — the d-pad is one `buttons` entry drawn as 4
    // hardcoded arms, and fast-forward isn't a `buttons` entry at all
    // (its own ffBtnRect, drawn separately in drawControls()) — so those
    // two use this exact same cache-fill-on-first-use pattern inline at
    // their own call sites instead, rather than a lookup keyed by an [id]
    // that doesn't exist for either of them.
    // Loaded once on first draw and reused every frame after, same
    // reuse-not-reallocate discipline as strokePaint/fillPaint above:
    // ContextCompat.getDrawable() + mutate() is a resource-table lookup and
    // a fresh Path parse, cheap once but not something to repeat ~60×/sec
    // while these buttons are on screen. mutate() up front means the
    // setTint() this function does per frame (to follow the button's own
    // idle/pressed accent color, exactly like strokePaint) only ever
    // affects this cached instance, never any other place the same
    // drawable resource might someday be drawn. Nullable because loading
    // needs a Context, and there's no useful "preload" moment before this
    // Activity exists to draw a button in the first place; each is
    // populated on its own first use.
    internal var iconQuickLoad: Drawable? = null
    internal var iconQuickSave: Drawable? = null
    internal var iconScreenshot: Drawable? = null
    internal var iconRecord: Drawable? = null
    internal var iconDpadArrow: Drawable? = null
    internal var iconFastForward: Drawable? = null

    // PERF FIX: these were previously Color.parseColor("#...") calls made
    // INSIDE drawControls()/drawDpad() — i.e. re-parsed from a hex string on
    // every single rendered frame (the d-pad alone re-parsed the same string
    // 4×/frame). That's pure wasted CPU sitting on the exact thread that
    // also paces audio playback (see startGameLoop()) — any extra time spent
    // here delays the next AudioTrack.write(), which is what an underrun
    // "click" actually is. Precomputing these once is a zero-risk, visually
    // identical change (same values, same Color.parseColor, just evaluated
    // once instead of ~6-7×/frame).
    // colorControlsBg (was Color.parseColor("#CC111122"), a semi-opaque
    // dark-navy fill drawn from controlsTop down every frame — see the old
    // drawControls()) is gone as of the Fortieth pass: reported directly
    // as an unwanted "black transparent" band behind the on-screen
    // controls. No replacement fill — canvas.drawColor(Color.BLACK) in
    // renderFrame() already clears the whole canvas before drawControls()
    // runs, so removing the rect just leaves that area plain black instead
    // of tinted; nothing left to redraw, no stale-frame/unfilled-gap risk.
    internal val colorFfActive   = Color.parseColor("#CC7700")
    // OUTLINE SKIN: every control is now a stroked (line-art) shape instead
    // of a filled one, matching the requested reference skin — one shared
    // light/neutral accent for every button (D-pad / A / B / L / R /
    // Select / Start / FF-idle). The old solid colorFfIdle / colorDpadBase /
    // colorDpadArm fills are gone: there's no shared d-pad base plate any
    // more either — see drawDpad(), each arm is its own outlined button.
    // (colorAccentLight itself moved to SharedUi.kt this pass — RomBrowserActivity needs it too.)
    // Used only by the optional Turbo A/B satellites — red reads as
    // "rapid-fire" (the usual emulator-skin convention), which is exactly
    // right here since that's what they are, unlike the normal A/B.
    internal val colorAccentRed   = Color.parseColor("#E5484D")

    /** Builds the L/R shoulder-trigger glyph: a flat hinge edge (left edge
     *  for L, right edge for R) with small rounded corners, a flat top edge,
     *  a short flat bottom segment on the hinge side, and one big smooth
     *  sweep on the outer side connecting the top corner down to where that
     *  bottom segment starts — the classic controller-bumper silhouette from
     *  the reference skin, instead of a plain pill. `mirrored = true` flips
     *  it for R.
     *
     *  PERF FIX (pass 43 — direct report: shoulderButtonPath() allocated a
     *  brand-new Path — a moveTo, 2 quadTo, a cubicTo, a lineTo and a
     *  close, not a cheap object — on every single call): this is invoked
     *  twice per rendered frame (L and R, from drawOutlineButton() below)
     *  for as long as a game is running, so 120 Path allocations/sec at
     *  60fps — the same permanent GC churn as drawDpad()'s old RectF
     *  allocations above, and for the same reason it matters (see that
     *  PERF FIX comment). The glyph's shape only actually changes when
     *  [rect] itself does (editor drag/resize, orientation change, scale
     *  change) — not every frame during normal play — so it's now built
     *  into one of two reusable Path instances (L and R need independent,
     *  simultaneously-live geometry, hence two, not one), rewound and
     *  rebuilt only when [rect] differs from the last frame's for that
     *  side, and simply returned as-is otherwise. `Path.rewind()`
     *  (clears the drawn geometry but keeps the Path's own internal
     *  arrays for reuse) rather than `.reset()` (also releases them) on
     *  purpose — same "don't let a hot path release and immediately
     *  reallocate its own storage" reasoning as reusing the RectF fields
     *  above instead of `new`-ing them. */
    internal val shoulderPathL = Path()
    internal val shoulderPathR = Path()
    internal val shoulderRectL = RectF()
    internal val shoulderRectR = RectF()

    /** Renders four independently-outlined direction buttons — no shared
     *  base plate — arranged in a loose cross, matching the reference skin
     *  where the D-pad reads as four separate line-art buttons rather than
     *  one filled plate. Hit-testing is UNCHANGED: dpadKeysFor() still
     *  resolves the whole unified [rect] by angle (see its own doc comment),
     *  so diagonals still work exactly as before even though visually
     *  you're now tapping between two shapes rather than on a solid arm.
     *
     *  PERF FIX (pass 43 — direct report: drawDpad() allocated a fresh
     *  RectF for each of the 4 arms on every single call): this runs once
     *  per rendered frame for as long as a game is running, so 4
     *  allocations/frame is 240 allocations/sec at 60fps — permanent GC
     *  churn on the exact thread that also paces audio playback (see the
     *  colorFfActive PERF FIX comment elsewhere in this file for why that
     *  specifically matters: any extra time spent allocating/collecting
     *  here delays the next AudioTrack.write(), which is what an underrun
     *  "click" actually is). The 4 arms only actually change shape when
     *  the d-pad's own bounding [rect] does (editor drag/resize,
     *  orientation change, scale change) — not every frame during normal
     *  play — so they're now precomputed once into 4 reusable RectF
     *  fields, refreshed only when [rect] differs from the last frame's
     *  (updateDpadArmRects() below, a plain RectF.equals() check — no
     *  allocation either way), and just redrawn (current pressed/alpha
     *  state, genuinely per-frame data) the rest of the time. */
    internal val dpadArmRectUp = RectF()
    internal val dpadArmRectDown = RectF()
    internal val dpadArmRectLeft = RectF()
    internal val dpadArmRectRight = RectF()
    // Deliberately inverted (right < left) so it can never equal a real
    // d-pad rect — guarantees the very first call always computes rather
    // than reading 4 empty RectFs, without needing a separate boolean flag.
    internal val dpadLastRect = RectF(0f, 0f, -1f, -1f)
    internal var dpadArmCorner = 0f

    // ── Touch handling ─────────────────────────────────────────────────────
    //
    // STICKY DRAG-OFF: once a finger is down on a control, it keeps
    // contributing that control's key(s) even after the finger drags
    // outside that control's own hit-box — right up until that specific
    // finger actually lifts (ACTION_UP / ACTION_POINTER_UP) or the gesture
    // is cancelled. Previously updateGameKeys() re-hit-tested every
    // pointer's CURRENT position on every single call with nothing carried
    // over, so straying off a button's rect by even a pixel — while still
    // pressing down — read as an immediate release. That doesn't match how
    // a physical button (or basically any touch gamepad) behaves.
    //
    // Tracked per pointer ID (not per button) so multiple fingers can each
    // independently hold their own button, and so a finger sliding from one
    // button straight onto a different one correctly switches instead of
    // both buttons lighting up.
    internal val pointerKeys   = mutableMapOf<Int, Int>()  // pointerId -> GBA key bits that finger last hit
    internal val pointerTurboA = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-A satellite
    internal val pointerTurboB = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-B satellite

    // ── One-tap extra controls (quick save/load, screenshot) ────────────────
    // FEATURE: new. Unlike every other button, these don't feed
    // currentKeys/nativeSetKeys at all (keyMask 0 — see buildControlLayout)
    // — a tap fires the action once, immediately, the same way the ⏩
    // button toggles fastForwardActive in onGameTouch's ACTION_DOWN rather
    // than going through updateGameKeys.
    internal val actionButtonIds = setOf("quicksave", "quickload", "screenshot", "record")

    internal val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFEE58")
    }
    internal val editHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FFEE58")
    }
    internal val editDimPaint = Paint().apply { color = Color.parseColor("#22000000") }
    internal val gridLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.parseColor("#33FFFFFF")
    }

    // ── Settings screen ────────────────────────────────────────────────────
    //
    // RESKIN: the old single scrolling dialog is now a full-screen category
    // list — Video / Audio / Input / Layouts / Misc / Advanced / About —
    // matching the requested reference layout. Every setting that existed
    // before still exists, just regrouped:
    //   Video    — game screen size, fullscreen              (was GAME SCREEN)
    //   Audio    — button click sound
    //   Input    — the drag/resize button-layout editor
    //   Layouts  — button size, button opacity                (was CONTROLS)
    //   Misc     — fast-forward speed                         (was EMULATION)
    //   Advanced — reset all settings to defaults (new — nothing else in
    //              this app currently qualifies as "advanced")
    //   About    — app name / version (new)
    //
    // Link remote / Link local were added later, moved here from floating
    // buttons that used to sit on top of the game view (📂 top-right, 🔗
    // top-right) — see the comment in onCreate where settingsBtn is built.
    // Link remote is the Wi-Fi flow, Link local is Bluetooth; both used to
    // live behind one combined dialog, now split into their own rows to
    // match. Nothing about the underlying connect logic changed (see
    // showLinkRemoteDialog()/showLinkLocalDialog()). Both rows are also on
    // the quick game menu now for a faster path to the same actions (see
    // showGameMenu()) — harmless to leave duplicated here too.
    //
    // REMOVED: the Change ROM and Save States rows. changeRom() now lives
    // only on the initial "▶ Load ROM" button, and on Close, which now goes
    // straight to ROM selection itself rather than just that button (see
    // the BUG FIX comment on closeGame()). Save/Load moved to the quick
    // game menu's own rows, which already called showSaveStateSlotDialog()
    // directly rather than through this screen's old showSaveStateMenu()
    // — that function is now unused; left in place rather than deleted in
    // case it's wanted back.
    //
    // settingsMenuOverlay itself is built once in onCreate and just shown/
    // hidden (see buildSettingsMenu()) — it has no dynamic state of its own.
    // Each category still opens as an AlertDialog exactly like the old
    // settings screen did, rebuilding its fields fresh every time it's
    // opened, so Save/Cancel behaves exactly as before; dismissing that
    // dialog reveals the category list again underneath.

    // dp() and iconChipBackground() moved to SharedUi.kt this pass (Thirty-
    // second) as Context extension functions — RomBrowserActivity needs
    // them too, and every call site here (dp(20), iconChipBackground(), ...)
    // keeps working unchanged since both are in the same package.

    // ── Memory viewer ─────────────────────────────────────────────────────

    // Standard GBA memory map — fixed by the hardware, not this app; the
    // same addresses any GBA devkit/emulator/disassembler uses. EWRAM
    // listed first/default since that's where most games, Pokémon
    // included, keep the bulk of their live state (party data, battle
    // structs, etc.) — IWRAM is smaller and mostly used for hot/
    // performance-critical data, less likely to be what's actually being
    // looked for here.
    internal val memRegions = listOf(
        MemRegion("EWRAM",   0x02000000, 0x40000),
        MemRegion("IWRAM",   0x03000000, 0x8000),
        MemRegion("Palette", 0x05000000, 0x400),
        MemRegion("VRAM",    0x06000000, 0x18000),
        MemRegion("OAM",     0x07000000, 0x400)
    )
    // 32 rows of 16 bytes — fits one screen without scrolling on most
    // phones at the dump's text size, without paging through hundreds of
    // screens to cross a 256KB region like EWRAM one page at a time.
    internal val memoryPageBytes = 512
    internal val memoryRefreshMs = 500L

    // SlotInfo/SlotKind moved to MainActivityShared.kt (pass 46 build fix —
    // see that file's own top-of-file comment); see it for the full
    // row-data / slot-kind rationale. slotInfoCache below is unaffected:
    // a real instance field, not one of the nested-type declarations that
    // broke the build.

    /** FIX (menu-slot speed pass): cache of each slot's already-decoded
     *  SlotInfo, keyed by "$currentRomBaseName:${kind.cacheKeySuffix()}"
     *  (the ROM name is part of the key since numbered slots repeat
     *  across ROMs but refer to different underlying files).
     *  showSaveStateSlotDialog() below re-decodes a slot's thumbnail from
     *  disk only when that slot's exists/modified no longer match what's
     *  cached — i.e. only when the data's actually stale, typically right
     *  after a save to that same slot. Before this, opening the dialog
     *  re-read and re-decoded every slot's PNG from disk on *every single
     *  open*, even when nothing had changed since the last time you
     *  looked — most of what made "menu tap -> slot list appearing" feel
     *  slow on repeat opens. ConcurrentHashMap since a fast reopen could
     *  plausibly start a second listing thread before the first one's
     *  finished.
     *
     *  FIX: was genuinely unbounded — grows by one entry per (ROM name,
     *  slot) combination ever viewed, for the life of the process. In
     *  practice this stays tiny (thumbnails are only STATE_THUMB_WIDTH_PX
     *  wide and there are only SAVE_STATE_SLOTS slots plus the two special
     *  ones, so even a long session across many ROMs stays in the low
     *  single-digit MB) — this cap is a cheap backstop on principle rather
     *  than a fix for any actually-observed growth. Simplest possible
     *  bound rather than real LRU eviction: once the cache would exceed
     *  SLOT_INFO_CACHE_MAX entries, it's cleared outright (a plain
     *  ConcurrentHashMap has no built-in ordering to evict-oldest-first
     *  with, and reaching this cap at all would already mean hundreds of
     *  distinct ROMs played in one process lifetime) — the next dialog
     *  open just repopulates whatever it needs, same cost as any other
     *  cache miss. */
    internal val slotInfoCache = java.util.concurrent.ConcurrentHashMap<String, SlotInfo>()

    // ── Link status overlay ────────────────────────────────────────────────

    internal val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }

    // ── Performance overlay (FEATURE — see the field comments above) ───────

    internal val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCFFFFFF"); textSize = 24f; textAlign = Paint.Align.RIGHT
    }

    // ── Screen recorder overlay (FEATURE — see GameScreenRecorder.kt) ──────

    internal val recordingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCFF4444"); textSize = 26f
    }
}
