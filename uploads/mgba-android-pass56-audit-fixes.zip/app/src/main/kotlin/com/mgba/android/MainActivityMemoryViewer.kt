package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


/** Shows the live memory viewer overlay — read-only inspection of the
 *  running core's RAM, requested for watching game state (a Pokémon
 *  battle's HP/party data was the specific example) change turn by
 *  turn. Values are read through mCore's own busRead8() (see
 *  nativeReadMemory() in mgba_jni.c) — the same bus mGBA's own cheat
 *  system reads through — rather than a raw pointer into EWRAM/IWRAM
 *  specifically, so every region (I/O registers, palette, VRAM, OAM,
 *  even ROM) works through one path instead of needing one per region.
 *
 *  Read-only for now, deliberately: "inspect live RAM" is what was
 *  asked for. Writing to memory (poking values — an actual cheat/edit
 *  tool) is a natural next step from here — a busWrite8() counterpart
 *  to nativeReadMemory() would be a small, symmetric addition — but is
 *  a materially different feature (anything that changes game state
 *  deserves its own explicit ask rather than riding along with
 *  "inspect"), so it's not included here.
 *
 *  Does not stop the game loop (see the field-block comment above
 *  where memoryViewerOverlay is declared) — gameplay keeps running
 *  underneath while this is open, and a self-rescheduling
 *  Handler.postDelayed() loop (see scheduleMemoryRefresh()) keeps the
 *  dump current every memoryRefreshMs while the overlay stays visible. */
internal fun MainActivity.showMemoryViewer() {
    memoryRegionIndex = 0
    memoryPageOffset = 0
    memoryViewerOverlay.visibility = View.VISIBLE
    refreshMemoryDump()
    scheduleMemoryRefresh()
}


internal fun MainActivity.hideMemoryViewer() {
    memoryViewerOverlay.visibility = View.GONE
}


internal fun MainActivity.scheduleMemoryRefresh() {
    mainHandler.postDelayed({
        if (isFinishing || isDestroyed) return@postDelayed
        if (memoryViewerOverlay.visibility != View.VISIBLE) return@postDelayed
        refreshMemoryDump()
        scheduleMemoryRefresh()
    }, memoryRefreshMs)
}


internal fun MainActivity.refreshMemoryDump() {
    val region = memRegions[memoryRegionIndex]
    memoryAddressText.text = "%s   0x%08X".format(region.label, region.base + memoryPageOffset)
    if (!romLoaded) { memoryDumpText.text = "Load a ROM first"; return }
    val length = memoryPageBytes.coerceAtMost(region.size - memoryPageOffset)
    if (length <= 0) { memoryDumpText.text = "End of region"; return }
    val address = region.base + memoryPageOffset
    val buf = ByteArray(length)
    val n = EmulatorEngine.nativeReadMemory(address, buf, length)
    memoryDumpText.text = if (n <= 0) "Not available right now" else formatHexDump(address, buf, n)
}


// PERF (audit finding): formatHexDump() below is the entire body of
// scheduleMemoryRefresh()'s self-rescheduling loop (memoryRefreshMs =
// 500ms, memoryPageBytes = 512 — MainActivity.kt), which runs on the
// MAIN thread — the same thread Choreographer's doFrame() needs for
// every vsync tick while this overlay is open over a running game (see
// showMemoryViewer()'s own doc comment: gameplay keeps running
// underneath). At 512 bytes/page that's 32 rows x (1 address + 16 byte)
// = 544 String.format() calls every 500ms — each one allocates and
// drives a Locale-aware java.util.Formatter plus its own format-string
// parse, real overhead for a call repeated this densely on a thread
// that also owns rendering. A manual hex-digit lookup produces
// byte-for-byte the same output (uppercase, zero-padded — verified by
// hand against String.format's own %02X/%08X contract for byte/int
// arguments; no compiler in this sandbox, same as every pass before
// this one) with no Formatter overhead and no allocation beyond the
// StringBuilder this already builds into.
private val HEX_DIGITS = "0123456789ABCDEF".toCharArray()

private fun StringBuilder.appendHex2(byte: Byte) {
    val v = byte.toInt() and 0xFF
    append(HEX_DIGITS[v ushr 4])
    append(HEX_DIGITS[v and 0xF])
}

private fun StringBuilder.appendHex8(value: Int) {
    for (shift in 28 downTo 0 step 4) append(HEX_DIGITS[(value ushr shift) and 0xF])
}


/** Classic hex-dump layout: 8-digit address, 16 hex bytes (a mid-row gap
 *  after the 8th, same convention as `hexdump -C`/most hex editors),
 *  then the same 16 bytes as ASCII (printable range 0x20–0x7E, '.' for
 *  everything else). */
internal fun MainActivity.formatHexDump(baseAddress: Int, bytes: ByteArray, length: Int): String {
    val sb = StringBuilder()
    var i = 0
    while (i < length) {
        val rowLen = minOf(16, length - i)
        sb.appendHex8(baseAddress + i); sb.append("  ")
        for (j in 0 until 16) {
            if (j < rowLen) { sb.appendHex2(bytes[i + j]); sb.append(' ') } else sb.append("   ")
            if (j == 7) sb.append(' ')
        }
        sb.append(' ')
        for (j in 0 until rowLen) {
            val b = bytes[i + j].toInt() and 0xFF
            sb.append(if (b in 0x20..0x7E) b.toChar() else '.')
        }
        sb.append('\n')
        i += 16
    }
    return sb.toString()
}


internal fun MainActivity.buildMemoryViewer(): LinearLayout {
    val ctx = this

    val header = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(16), dp(16), dp(14))
        addView(TextView(ctx).apply {
            text = "Memory"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(TextView(ctx).apply {
            text = "✕ Close"; textSize = 13f
            setTextColor(colorAccentLight)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            isClickable = true; isFocusable = true
            background = iconChipBackground()
            setOnClickListener { hideMemoryViewer() }
        })
    }

    // Chip TextViews kept in a list (indexed the same as memRegions) so
    // tapping one can restyle every chip's highlight directly, rather
    // than rebuilding this row (or the whole overlay) from scratch on
    // every tap.
    val regionChips = mutableListOf<TextView>()
    val regionRow = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(dp(16), dp(0), dp(16), dp(10))
        memRegions.forEachIndexed { index, region ->
            val chip = TextView(ctx).apply {
                text = region.label; textSize = 12f
                setTextColor(if (index == memoryRegionIndex) Color.WHITE else colorAccentLight)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
            }
            regionChips.add(chip)
            chip.setOnClickListener {
                memoryRegionIndex = index
                memoryPageOffset = 0
                regionChips.forEachIndexed { i, c -> c.setTextColor(if (i == index) Color.WHITE else colorAccentLight) }
                refreshMemoryDump()
            }
            addView(chip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.rightMargin = dp(8) })
        }
    }

    val pageRow = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(0), dp(20), dp(10))
        addView(TextView(ctx).apply {
            text = "◀"; textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(20), dp(4))
            isClickable = true; isFocusable = true
            background = iconChipBackground()
            setOnClickListener {
                memoryPageOffset = (memoryPageOffset - memoryPageBytes).coerceAtLeast(0)
                refreshMemoryDump()
            }
        })
        memoryAddressText = TextView(ctx).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(colorAccentLight)
        }
        addView(memoryAddressText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(TextView(ctx).apply {
            text = "▶"; textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(4), dp(10), dp(4))
            isClickable = true; isFocusable = true
            background = iconChipBackground()
            setOnClickListener {
                val region = memRegions[memoryRegionIndex]
                // FIX: was (region.size - 1).coerceAtLeast(0) — the cap
                // needs to be the start offset of the *last full page*,
                // not the last valid *byte*. Every region here
                // (EWRAM/IWRAM/Palette/VRAM/OAM) is an exact multiple of
                // memoryPageBytes, so the old cap let one extra tap of ▶
                // past the last full page land on a degenerate 1-byte
                // "page" — just the final byte already visible on the
                // previous page — instead of ▶ simply having nothing
                // left to do once the last full page is showing.
                memoryPageOffset = (memoryPageOffset + memoryPageBytes).coerceAtMost(
                    (region.size - memoryPageBytes).coerceAtLeast(0))
                refreshMemoryDump()
            }
        })
    }

    memoryDumpText = TextView(ctx).apply {
        typeface = Typeface.MONOSPACE
        textSize = 11f
        setTextColor(Color.parseColor("#D8D8DE"))
        setPadding(dp(16), dp(0), dp(16), dp(16))
    }

    val footer = TextView(ctx).apply {
        text = "Read-only — refreshes automatically every ${memoryRefreshMs / 1000.0}s while open"
        textSize = 11f
        setTextColor(Color.parseColor("#888892"))
        setPadding(dp(20), dp(4), dp(20), dp(16))
    }

    return LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor("#FF17171B"))
        isClickable = true; isFocusable = true
        addView(header)
        addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
        addView(regionRow)
        addView(pageRow)
        addView(ScrollView(ctx).apply { addView(memoryDumpText) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(footer)
    }
}

