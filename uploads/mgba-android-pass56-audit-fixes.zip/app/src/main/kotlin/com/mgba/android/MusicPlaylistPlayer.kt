package com.mgba.android

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log

/** Plays a folder of audio files one at a time, in order or shuffled,
 *  auto-advancing on completion — a small, self-contained playlist engine
 *  with no dependency on MainActivity/emulator specifics beyond a
 *  [Context] and a list of `content://` [Uri]s (from SAF), so it's
 *  reusable and easy to reason about on its own. See MainActivityMusic.kt
 *  for how MainActivity wires this to Settings UI, the folder picker, and
 *  the activity lifecycle.
 *
 *  FEATURE — direct report: "in sound settings add a way to add
 *  background music like you select a folder with song inside and play
 *  it 1by1 or shuffle it like playlist."
 *
 *  Every actual MediaPlayer.prepare() call happens on a background
 *  thread — it's a blocking call, and this can run from inside another
 *  track's own completion callback (auto-advance), which fires on the
 *  main thread; blocking that to decode the next track's header would
 *  be a stutter at best. `setupGeneration` guards against a background
 *  prepare() that's been superseded (rapid next-taps, a fresh
 *  setPlaylist() mid-prepare) from starting audio nobody asked for
 *  anymore. All actual `player` field reads/writes still happen on the
 *  main thread (posted back via `mainHandler`), so there's no cross-
 *  thread race on the field itself. */
internal class MusicPlaylistPlayer(private val appContext: Context) {

    /** (index within the current playlist, total tracks) — for a
     *  "Track 3 of 12"-style now-playing readout, if wired up. */
    var onTrackChanged: ((index: Int, total: Int) -> Unit)? = null
    var onError: ((message: String) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var tracks: List<Uri> = emptyList()
    private var order: MutableList<Int> = mutableListOf()   // playback order, indices into `tracks`
    private var orderPos = -1                                 // position within `order`
    private var shuffleEnabled = false
    private var volume = 1.0f
    @Volatile private var setupGeneration = 0

    val currentIndex: Int get() = order.getOrNull(orderPos) ?: -1
    val trackCount: Int get() = tracks.size
    val isPlaying: Boolean get() = player?.isPlaying == true

    /** Replaces the whole playlist (e.g. a newly-chosen folder). Keeps
     *  playing through the change if something was already playing and
     *  the same track is still present in the new list; otherwise just
     *  rebuilds the order without starting anything. */
    fun setPlaylist(newTracks: List<Uri>, shuffle: Boolean) {
        val wasPlaying = isPlaying
        val prevUri = currentIndex.takeIf { it in tracks.indices }?.let { tracks[it] }
        release()
        tracks = newTracks
        shuffleEnabled = shuffle
        rebuildOrder(startFrom = prevUri)
        if (wasPlaying && tracks.isNotEmpty()) playCurrent()
    }

    fun setShuffle(shuffle: Boolean) {
        if (shuffle == shuffleEnabled) return
        val prevUri = currentIndex.takeIf { it in tracks.indices }?.let { tracks[it] }
        shuffleEnabled = shuffle
        rebuildOrder(startFrom = prevUri)
    }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        player?.setVolume(volume, volume)
    }

    fun play() {
        if (tracks.isEmpty()) return
        if (player == null) {
            if (orderPos !in order.indices) orderPos = 0
            playCurrent()
        } else {
            try { player?.start() } catch (e: Exception) { Log.w(TAG, "MusicPlaylistPlayer.play()", e) }
        }
    }

    fun pause() {
        try { if (player?.isPlaying == true) player?.pause() } catch (e: Exception) { Log.w(TAG, "MusicPlaylistPlayer.pause()", e) }
    }

    fun next() = advance(+1)
    fun previous() = advance(-1)

    /** Fully tears down playback — app backgrounding/shutdown, or a
     *  fresh playlist about to replace this one. Also invalidates any
     *  background prepare() still in flight (see the class doc above). */
    fun release() {
        setupGeneration++
        try { player?.release() } catch (e: Exception) { Log.w(TAG, "MusicPlaylistPlayer.release()", e) }
        player = null
    }

    private fun rebuildOrder(startFrom: Uri?) {
        order = tracks.indices.toMutableList()
        if (shuffleEnabled) order.shuffle()
        orderPos = if (startFrom != null) {
            val idx = tracks.indexOf(startFrom)
            order.indexOf(idx).takeIf { it >= 0 } ?: 0
        } else 0
    }

    private fun advance(direction: Int) {
        if (order.isEmpty()) return
        val wasPlaying = isPlaying
        orderPos = ((orderPos + direction) % order.size + order.size) % order.size
        if (wasPlaying) playCurrent() else release()
    }

    /** [attemptsRemaining] bounds how many tracks in a row this will
     *  skip past on error before giving up — without a bound, a folder
     *  where every file happened to be unplayable would recurse once per
     *  track (playCurrent -> error -> advance -> playCurrent -> ...)
     *  instead of just reporting "nothing here plays" and stopping. Capped
     *  well below anything that could meaningfully deepen the call stack. */
    private fun playCurrent(attemptsRemaining: Int = tracks.size.coerceIn(1, 10)) {
        val idx = currentIndex
        if (idx !in tracks.indices) return
        if (attemptsRemaining <= 0) {
            onError?.invoke("No playable tracks found in this folder")
            return
        }
        release()
        val myGeneration = setupGeneration
        val uri = tracks[idx]
        Thread {
            var prepared: MediaPlayer? = null
            try {
                prepared = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(appContext, uri)
                    prepare() // blocking — deliberately off the main thread, see class doc
                }
            } catch (e: Exception) {
                Log.w(TAG, "MusicPlaylistPlayer: failed to prepare $uri", e)
                prepared?.release()
                prepared = null
            }
            mainHandler.post {
                if (myGeneration != setupGeneration) {
                    // Superseded while this was preparing in the background
                    // (release()/a new setPlaylist()/another playCurrent()
                    // already happened) — discard rather than starting
                    // audio nobody asked for anymore.
                    prepared?.release()
                    return@post
                }
                if (prepared == null) {
                    orderPos = ((orderPos + 1) % order.size + order.size) % order.size
                    playCurrent(attemptsRemaining - 1)
                    return@post
                }
                player = prepared.apply {
                    setVolume(volume, volume)
                    setOnCompletionListener { advance(+1) }
                    setOnErrorListener { _, what, extra ->
                        Log.w(TAG, "MusicPlaylistPlayer: MediaPlayer error what=$what extra=$extra on $uri")
                        orderPos = ((orderPos + 1) % order.size + order.size) % order.size
                        playCurrent(attemptsRemaining - 1)
                        true
                    }
                    start()
                }
                onTrackChanged?.invoke(idx, tracks.size)
            }
        }.start()
    }
}
