package com.mgba.android

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Encodes the emulator's own framebuffer + game audio into an MP4,
 *  entirely independent of the phone's actual on-screen display. FEATURE
 *  — direct report: "add features screen recorder on it but only the
 *  game screen will record and sound no button."
 *
 *  Drawing from the SAME raw framebuffer captureGameFrameBitmap() reads
 *  for screenshots/save-state thumbnails (MainActivitySaveStateUi.kt) —
 *  which is already the pre-controls game frame, not a screen grab of
 *  the whole display — is what guarantees the on-screen buttons can
 *  never appear in the recording: they're simply never drawn to this
 *  class's own encoder input Surface in the first place, not filtered
 *  out after the fact. No MediaProjection/screen-capture permission
 *  needed at all, for the same reason — this never touches the device's
 *  actual display output. Captured via that function's own
 *  captureGameFrameBitmapInto() sibling rather than
 *  captureGameFrameBitmap() itself — see captureBitmap's field comment
 *  below for why this class specifically needs the reused-destination
 *  version instead of the fresh-Bitmap-per-call one screenshots/
 *  thumbnails still use.
 *
 *  Video: MediaCodec H.264 in Surface-input mode — the encoder handles
 *  the RGB->YUV conversion internally via its own EGL pipeline, which
 *  sidesteps the real device-to-device fragmentation a hand-rolled
 *  ByteBuffer approach would run into (which raw YUV byte layout — planar
 *  vs semi-planar, and which one a given encoder actually wants — varies
 *  per device/vendor). Fed by EglBitmapSurfaceRenderer — a real EGL/GLES2
 *  context bound directly to the input Surface, texture-uploading each
 *  captured frame and drawing it with a full-viewport quad — from a
 *  dedicated capture thread this class owns; see startCaptureLoop() and
 *  that class's own doc comment for why a real EGL context replaced an
 *  earlier lockCanvas()/lockHardwareCanvas() attempt. 30fps/720x480
 *  rather than something even higher: still a 2D handheld-console
 *  capture, not fast-paced 3D/FPS footage, so there's a ceiling on how
 *  much a higher rate actually buys visually. FIX (direct report:
 *  recorded video "is lag" despite smooth live gameplay — the 20fps
 *  this used to be, while real and steady rather than stuttering
 *  internally, plainly reads as choppy next to the full-rate gameplay
 *  it's sitting next to): raised from 20. Not raised further than 30,
 *  and VIDEO_BITRATE left as-is, without a real device to actually
 *  verify encoder load/quality at a higher rate against (see
 *  KNOWN_LIMITATIONS.md) — 30 is a well-worn, conservative "smooth"
 *  target that's very unlikely to strain any device that already
 *  handled 20 fine. What made even 20 a deliberate ceiling rather than
 *  just "the number that felt right" was captureGameFrameBitmap()'s two
 *  fresh allocations per call — a ~1.4MB ARGB_8888 Bitmap among them —
 *  on every single recorded frame; captureBitmap below is what removes
 *  that constraint, which is what made raising this affordable in the
 *  first place. 720x480 specifically because it's exactly 3x the GBA's
 *  native 240x160, so it's undistorted at the source aspect ratio with
 *  no letterboxing math needed, and divisible by 16 (encoder-friendly).
 *
 *  Audio: MediaCodec AAC in the standard ByteBuffer-input mode, fed PCM
 *  directly from MainActivityAudio.kt's writePcm() (see feedAudio()) —
 *  the exact same samples a listener actually hears, not a separate or
 *  duplicated read of anything.
 *
 *  Both encoders' output gets muxed into one MP4 via MediaMuxer, written
 *  to a temp file under cacheDir rather than directly into the chosen
 *  Storage folder — MediaMuxer's own String-path constructor (guaranteed
 *  available at any API level this app supports, unlike its
 *  FileDescriptor overload) needs a plain java.io.File path, not a SAF
 *  DocumentFile/content:// Uri directly. See
 *  MainActivityRecorder.kt's finishRecordingAndSave() for the copy-out
 *  step afterward — same "stage locally, then copy to the real
 *  destination" shape SaveEntry.stageForWrite()/commitWrite() already
 *  established for save-states.
 *
 *  Everything encoder/muxer-related is behind [lock]: video frames arrive
 *  from this class's own capture thread, audio arrives from the
 *  emulator's own game thread (MainActivityRender.kt's gameThread), and
 *  start()/stop() get called from the main thread by a button tap —
 *  three different threads that all need to agree on encoder/muxer state
 *  without corrupting it. */
internal class GameScreenRecorder(private val activity: MainActivity) {

    companion object {
        private const val VIDEO_WIDTH = 720
        private const val VIDEO_HEIGHT = 480
        private const val VIDEO_BITRATE = 4_000_000
        private const val VIDEO_FPS = 30
        private const val AUDIO_SAMPLE_RATE = 44100
        private const val AUDIO_CHANNELS = 2
        private const val AUDIO_BITRATE = 128_000
    }

    @Volatile var isRecording = false
        private set

    private val lock = Object()
    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    private var muxerStarted = false
    private val videoBufferInfo = MediaCodec.BufferInfo()
    private val audioBufferInfo = MediaCodec.BufferInfo()
    private var audioPresentationTimeUs = 0L
    // FIX (audit finding): set once, synchronously, at the very top of
    // start() — before startCaptureLoop() even spawns the capture
    // thread — and used as the *only* origin for video's per-frame
    // presentation timestamps (see startCaptureLoop()'s own comment).
    // Previously the capture thread set its own local `startNanos`
    // *after* EGL setup (EglBitmapSurfaceRenderer.start() — real GL
    // context/shader work, not instant) finished, so video's "time 0"
    // landed however long EGL setup took *after* audio's "time 0"
    // (audioPresentationTimeUs above, effectively zeroed the instant
    // feedAudio() is first called post-start() — near-immediate, since
    // the game thread calls it continuously). Sharing one origin closes
    // that gap instead of just shrinking it. @Volatile for the same
    // cross-thread reason as captureBitmap just below: written here on
    // whichever thread calls start(), read on the capture thread.
    @Volatile private var recordingStartNanos = 0L

    // FIX (audit finding): feedAudio() below silently truncates a batch
    // when the audio encoder's own input buffer has less room than
    // [pairs] needs — a different, previously undiagnosed case from the
    // already-documented "no input buffer at all this call" drop right
    // next to it. Logged once per recording rather than every
    // occurrence: a given encoder's input buffer size doesn't change
    // mid-session, so once this starts happening it would otherwise
    // recur on every single feedAudio() call for the rest of the
    // recording — per-frame log spam with no new information each
    // time, the exact class of problem jni_log()'s own noise-reduction
    // fix (mgba_jni.c) already had to remove elsewhere. One line is
    // enough to leave a real diagnostic trail instead of this only ever
    // surfacing as an unexplained "audio sounds off" report with
    // nothing in the log pointing at why.
    private var audioTruncationLogged = false

    // FIX (audit finding): both drainLocked() (shared by
    // drainVideoLocked()/drainAudioLocked()) and maybeStartMuxerLocked()
    // together fix a real-data-loss bug — see drainLocked()'s own doc
    // comment for the mechanism. These two queues hold whichever
    // track's encoder produces real output before *both* tracks are
    // registered and the muxer can legally start; maybeStartMuxerLocked()
    // flushes and clears both the instant it actually starts. Always
    // empty in the common case where both encoders' format-changed
    // events land before either produces real data — which is most of
    // the time, so this is a zero-cost path outside the startup race it
    // exists for. Also cleared in teardownLocked(): this class is one
    // long-lived instance reused across many start()/stop() cycles, so
    // a sample stranded by an aborted recording (muxer never started)
    // must not bleed into the next one.
    private class PendingSample(val bytes: ByteArray, val presentationTimeUs: Long, val flags: Int)
    private val pendingVideoSamples = mutableListOf<PendingSample>()
    private val pendingAudioSamples = mutableListOf<PendingSample>()
    // Reused across every feedAudio() call rather than allocated fresh
    // each time — this runs on the game thread at up to ~60Hz while
    // recording, so a per-call allocation here would be real GC
    // pressure on exactly the thread that can least afford a pause.
    // 4096 shorts is comfortably above audioBuffer's own fixed 2048-short
    // size (MainActivityAudio.kt) — writePcm() always hands this at most
    // that many, whatever accumulated it upstream during fast-forward.
    private val audioScratch = ByteBuffer.allocate(4096 * 2).order(ByteOrder.LITTLE_ENDIAN)

    // Allocated once in start(), drawn into on every captured frame via
    // captureGameFrameBitmapInto() (MainActivitySaveStateUi.kt — see
    // that function's own doc comment for the full "direct report:
    // recorded audio disappears sometimes" story this is part of the
    // fix for), released in teardownLocked() — one ~1.4MB allocation
    // for a whole recording instead of two fresh ones on every single
    // frame the old captureGameFrameBitmap() call here used to make.
    // @Volatile: written on the main thread in start()/teardownLocked()
    // (the latter while [lock] is held, from whichever thread called
    // stop()), read on the capture thread in captureAndDrawFrame() —
    // same cross-thread-visibility reasoning as captureRunning/
    // isRecording just below/above. teardownLocked() can race a capture
    // still mid-flight (stopCaptureLoopLocked()'s own doc comment
    // explains why that's accepted rather than joined out); resulting
    // failures (a recycled Bitmap, or this field going null) surface as
    // an ordinary exception from captureGameFrameBitmapInto() or
    // renderer.drawFrame(), caught by captureAndDrawFrame()'s own
    // try/catch exactly like an inputSurface teardown race already was.
    @Volatile private var captureBitmap: Bitmap? = null

    private var captureThread: Thread? = null
    @Volatile private var captureRunning = false
    private var tempFile: File? = null

    /** Starts a new recording into a temp file under cacheDir. Returns
     *  the temp file on success, null on any setup failure (codec
     *  unavailable, etc.) — the caller (MainActivityRecorder.kt) toasts
     *  accordingly; this class doesn't know about UI. */
    fun start(): File? = synchronized(lock) {
        if (isRecording) return@synchronized null
        try {
            val file = File(activity.cacheDir, "recording_${System.currentTimeMillis()}.mp4")

            val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_WIDTH, VIDEO_HEIGHT).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            }
            val vCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            vCodec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = vCodec.createInputSurface()
            vCodec.start()

            val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
            }
            val aCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aCodec.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aCodec.start()

            val mux = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // See captureBitmap's own field comment above for why this
            // is allocated once per recording rather than left to
            // captureAndDrawFrame()/captureGameFrameBitmapInto() to
            // allocate (or not) on their own.
            captureBitmap = Bitmap.createBitmap(VIDEO_WIDTH, VIDEO_HEIGHT, Bitmap.Config.ARGB_8888)

            videoCodec = vCodec; audioCodec = aCodec; inputSurface = surface; muxer = mux
            videoTrackIndex = -1; audioTrackIndex = -1; muxerStarted = false
            tempFile = file
            recordingStartNanos = System.nanoTime()
            audioPresentationTimeUs = 0L
            audioTruncationLogged = false
            isRecording = true
            startCaptureLoop()
            file
        } catch (e: Exception) {
            Log.e(TAG, "GameScreenRecorder.start() failed", e)
            teardownLocked()
            null
        }
    }

    /** Stops capture, signals end-of-stream to the video encoder, drains
     *  whatever's left from both, finalizes the muxer, and releases
     *  everything. Deliberately synchronous — MainActivityRecorder.kt's
     *  caller already runs this off the main thread. Returns the temp
     *  file (now a finished, valid MP4) for the caller to copy out to
     *  its real destination, or null if nothing was recording. */
    fun stop(): File? = synchronized(lock) {
        if (!isRecording) return@synchronized null
        isRecording = false
        stopCaptureLoopLocked()
        try {
            videoCodec?.signalEndOfInputStream()
            drainVideoLocked(endOfStream = true)
            drainAudioLocked(endOfStream = true)
        } catch (e: Exception) {
            Log.e(TAG, "GameScreenRecorder.stop() drain failed", e)
        }
        val result = tempFile
        teardownLocked()
        result
    }

    /** Called from the emulator's own game thread (see writePcm()'s own
     *  hook, MainActivityAudio.kt) — deliberately non-blocking: this
     *  runs on the same thread that drives actual emulation timing, so
     *  stalling here to wait for an encoder input buffer would mean
     *  stalling gameplay for an optional recording feature. Drops
     *  (doesn't retry/queue) a chunk if the encoder has no input buffer
     *  ready right this instant — audio encoders are fast enough in
     *  practice that a single dropped ~20ms chunk here and there is
     *  inaudible next to actually-stalled gameplay.
     *
     *  FIX (direct report: recorded audio "disappear[s] sometimes" —
     *  cuts out partway through and stays gone for the rest of the
     *  clip, while video keeps recording the whole time): the
     *  encoder's OUTPUT buffer pool is small and finite, and this used
     *  to drain it only from this function's own success path (what's
     *  now the second drainAudioLocked() call below, after
     *  queueInputBuffer()). If dequeueInputBuffer() ever failed for
     *  several calls in a row — genuinely possible, since this runs
     *  right alongside the capture thread's own per-frame work, and any
     *  GC pause here competed with that (captureBitmap's field comment
     *  above covers the biggest source of that pressure, now removed)
     *  — output would never get drained either, because draining only
     *  ever followed a successful queue. Once the pool fills from lack
     *  of draining, the encoder stops accepting new input too, and
     *  since nothing outside that now-unreachable success path ever
     *  called drainAudioLocked(), it stayed that way permanently: every
     *  later call here failed the same way for the rest of the
     *  recording, silently, while video — a separate thread and codec —
     *  just kept going without it. Now drained both before AND after
     *  feeding, so a backed-up encoder gets a chance to clear before
     *  this even asks for an input buffer, not only after successfully
     *  giving it one. More importantly, also drained independently on
     *  every captured video frame regardless of what happens here (see
     *  captureAndDrawFrame() below) — that runs on its own steady
     *  timer, so audio output can never go undrained for longer than
     *  one frame interval even if this function stops being called, or
     *  keeps failing, for an extended stretch. [pcm]/[pairs] are
     *  exactly writePcm()'s own already-processed buffer/count — same
     *  audio a listener actually hears. */
    fun feedAudio(pcm: ShortArray, pairs: Int) {
        if (pairs <= 0) return
        synchronized(lock) {
            if (!isRecording) return
            val codec = audioCodec ?: return
            try {
                // Opportunistic drain before feeding — see the FIX note
                // above for why this matters beyond just the drain
                // already at the end of this block.
                drainAudioLocked(endOfStream = false)
                val inIndex = codec.dequeueInputBuffer(0)
                if (inIndex < 0) return // no buffer ready right now — drop this chunk, see doc above
                val buf = codec.getInputBuffer(inIndex) ?: return
                buf.clear()
                val maxShorts = minOf(pairs * 2, buf.remaining() / 2, audioScratch.capacity() / 2)
                if (maxShorts <= 0) return
                if (maxShorts < pairs * 2 && !audioTruncationLogged) {
                    audioTruncationLogged = true
                    Log.w(TAG, "GameScreenRecorder.feedAudio(): encoder input buffer smaller " +
                        "than batch (wanted ${pairs * 2} shorts, got $maxShorts) — truncating " +
                        "this and likely later calls; won't log again this recording")
                }
                audioScratch.clear()
                for (i in 0 until maxShorts) audioScratch.putShort(pcm[i])
                audioScratch.flip()
                buf.put(audioScratch)
                val byteCount = maxShorts * 2
                codec.queueInputBuffer(inIndex, 0, byteCount, audioPresentationTimeUs, 0)
                // maxShorts/2 == stereo sample pairs actually queued.
                audioPresentationTimeUs += (maxShorts / 2).toLong() * 1_000_000L / AUDIO_SAMPLE_RATE
                drainAudioLocked(endOfStream = false)
            } catch (e: Exception) {
                Log.w(TAG, "GameScreenRecorder.feedAudio()", e)
            }
        }
    }

    /** Called from this class's own capture thread only (startCaptureLoop) —
     *  draws one frame via [renderer] and, on success, drains whatever the
     *  video encoder now has ready. See EglBitmapSurfaceRenderer's own doc
     *  comment for why this replaced a Canvas-based capture (direct
     *  report: "screen record is bad it record sound but not frame it
     *  show only 1 frame"). [renderer] is thread-confined to the capture
     *  thread — see startCaptureLoop() — so unlike the old
     *  lockHardwareCanvas() version, there's no `inputSurface` snapshot
     *  to take under `lock` here at all; renderer.drawFrame() throwing
     *  (e.g. stop() racing in and tearing the underlying Surface down
     *  concurrently) is caught the same way that snapshot-going-stale
     *  case always was — logged, this one frame skipped, exactly the
     *  right outcome for a recording that's already ending. That same
     *  catch now also covers captureGameFrameBitmapInto() below racing a
     *  concurrent teardownLocked() recycling captureBitmap out from
     *  under it — a race that couldn't happen with the old
     *  captureGameFrameBitmap() call here, since that handed back a
     *  brand new Bitmap nothing else could ever touch. */
    private fun captureAndDrawFrame(renderer: EglBitmapSurfaceRenderer, presentationTimeNs: Long) {
        try {
            val bmp = captureBitmap ?: return
            if (!activity.captureGameFrameBitmapInto(bmp)) return
            renderer.drawFrame(bmp, presentationTimeNs)
        } catch (e: Exception) {
            Log.w(TAG, "GameScreenRecorder: capture/drawFrame failed", e)
            return
        }
        synchronized(lock) {
            if (isRecording) {
                drainVideoLocked(endOfStream = false)
                // FIX: see feedAudio()'s own doc comment above — this is
                // the independent heartbeat that keeps the audio
                // encoder's output pool from ever backing up long enough
                // to wedge dequeueInputBuffer() there, running on this
                // thread's own steady per-frame cadence regardless of
                // whatever is or isn't happening with audio on the game
                // thread.
                drainAudioLocked(endOfStream = false)
            }
        }
    }

    private fun startCaptureLoop() {
        captureRunning = true
        captureThread = Thread {
            // EGL setup, every drawFrame() call, and teardown all happen
            // on this one thread for this renderer's entire lifetime —
            // an EGL context is bound to whichever thread last made it
            // current, and nothing else in this class ever touches it.
            val surface = synchronized(lock) { inputSurface } ?: return@Thread
            // Constructed and start()ed as two separate steps (rather
            // than e.g. `EglBitmapSurfaceRenderer(surface).apply { start() }`)
            // specifically so `renderer` is still a valid, held reference
            // if start() throws partway through — release() is safe to
            // call on a partially-initialized instance (see its own doc
            // comment) and is what actually frees whatever EGL display/
            // context/surface DID get allocated before the failure;
            // losing that reference to a chained expression's exception
            // would leak it instead.
            val renderer = EglBitmapSurfaceRenderer(surface)
            try {
                renderer.start()
            } catch (e: Exception) {
                Log.e(TAG, "GameScreenRecorder: EGL renderer setup failed", e)
                renderer.release()
                return@Thread
            }
            try {
                val frameIntervalMs = 1000L / VIDEO_FPS
                // FIX (audit finding): used to be `System.nanoTime()`
                // captured right here — i.e. *after* the EGL setup
                // above already finished — making every frame's
                // timestamp relative to "whenever this thread got
                // through EGL setup" instead of "whenever recording
                // actually started". recordingStartNanos (set
                // synchronously in start(), before this thread even
                // spawns) is the same origin audio's clock effectively
                // starts from, so this loop no longer needs — or
                // wants — its own local start reference.
                while (captureRunning) {
                    val frameStart = System.currentTimeMillis()
                    try {
                        captureAndDrawFrame(renderer, System.nanoTime() - recordingStartNanos)
                    } catch (e: Exception) {
                        Log.w(TAG, "GameScreenRecorder capture loop", e)
                    }
                    val sleepMs = frameIntervalMs - (System.currentTimeMillis() - frameStart)
                    if (sleepMs > 0) {
                        try { Thread.sleep(sleepMs) } catch (e: InterruptedException) { return@Thread }
                    }
                }
            } finally {
                // Runs even on the return@Thread above (Kotlin/JVM always
                // runs an enclosing finally on the way out of its try,
                // labeled non-local return included) — so the renderer's
                // EGL resources are never leaked regardless of how this
                // thread's loop actually exits.
                renderer.release()
            }
        }.apply { name = "mGBA-screen-recorder"; start() }
    }

    /** Must be called with [lock] held (called only from stop() above). */
    private fun stopCaptureLoopLocked() {
        captureRunning = false
        // Deliberately NOT captureThread?.join() here: this runs inside
        // the very `lock` captureAndDrawFrame()'s own drain call
        // (synchronized(lock) { ... }, above) needs to finish its
        // current iteration — joining would wait for that thread while
        // holding the lock it needs to exit, an easy self-deadlock.
        // captureRunning = false is enough on its own: the loop checks
        // it every iteration and exits within one frame interval
        // regardless, and whatever's already mid-flight when
        // isRecording flips false just no-ops via captureAndDrawFrame()'s
        // own `if (isRecording)` guard around its drain call.
        captureThread = null
    }

    /** Must be called with [lock] held. Releases every resource
     *  regardless of how far start() got before failing, so a partial
     *  setup failure never leaks a codec/muxer. */
    private fun teardownLocked() {
        try { videoCodec?.stop() } catch (e: Exception) {}
        try { videoCodec?.release() } catch (e: Exception) {}
        try { audioCodec?.stop() } catch (e: Exception) {}
        try { audioCodec?.release() } catch (e: Exception) {}
        try { inputSurface?.release() } catch (e: Exception) {}
        try { if (muxerStarted) muxer?.stop() } catch (e: Exception) { Log.w(TAG, "MediaMuxer.stop()", e) }
        try { muxer?.release() } catch (e: Exception) {}
        try { captureBitmap?.recycle() } catch (e: Exception) {}
        videoCodec = null; audioCodec = null; inputSurface = null; muxer = null
        videoTrackIndex = -1; audioTrackIndex = -1; muxerStarted = false
        // FIX (audit finding): see PendingSample's own field comment
        // above — a sample stranded here by an aborted recording (muxer
        // never started) must not survive into the next start().
        pendingVideoSamples.clear(); pendingAudioSamples.clear()
        captureBitmap = null
        tempFile = null
    }

    /** Must be called with [lock] held (called only from drainVideoLocked()/
     *  drainAudioLocked() just below, one real function instead of two —
     *  they differed only in which codec/BufferInfo/pending-queue/
     *  track-index field to use, so keeping both meant every future fix
     *  here had to be made twice, correctly, in two places).
     *
     *  FIX (audit finding, not a direct report): both used to call
     *  codec.releaseOutputBuffer() unconditionally once real output was
     *  ready, but only actually wrote it to the muxer if muxerStarted
     *  was already true — MediaMuxer requires BOTH tracks registered
     *  before start() is legal (see maybeStartMuxerLocked() below), so
     *  whichever encoder produced real output first, before the OTHER
     *  encoder's own format-changed event landed, had that output
     *  silently thrown away instead of held for later. Audio was the
     *  likely victim in practice: feedAudio() goes live the instant
     *  isRecording flips true in start(), while video can't produce
     *  anything until the capture thread's EGL setup — real GL context/
     *  shader work, not instant — finishes. Now: real output produced
     *  before muxerStarted is copied into [pending] instead of
     *  discarded (the codec's own output buffer is only valid until
     *  releaseOutputBuffer(), called right after either way, so the
     *  bytes have to be copied out, not just referenced, to survive
     *  until maybeStartMuxerLocked() can flush them); once the muxer
     *  actually starts, that queue is written out in the same order it
     *  was captured in before any further live sample is. Empty in the
     *  common case where both encoders' format-changed events land
     *  before either produces real data — most of the time — so this
     *  adds no cost outside the startup race it exists for. */
    private fun drainLocked(
        codec: MediaCodec, bufferInfo: MediaCodec.BufferInfo,
        pending: MutableList<PendingSample>, isVideo: Boolean, endOfStream: Boolean
    ) {
        val timeoutUs = if (endOfStream) 10_000L else 0L
        while (true) {
            val outIndex = try {
                codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            } catch (e: Exception) { Log.w(TAG, "drainLocked", e); return }
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (isVideo) {
                        if (videoTrackIndex >= 0) continue
                        videoTrackIndex = muxer?.addTrack(codec.outputFormat) ?: return
                    } else {
                        if (audioTrackIndex >= 0) continue
                        audioTrackIndex = muxer?.addTrack(codec.outputFormat) ?: return
                    }
                    maybeStartMuxerLocked()
                }
                outIndex >= 0 -> {
                    val buf = codec.getOutputBuffer(outIndex)
                    if (buf != null && bufferInfo.size > 0) {
                        if (muxerStarted) {
                            val trackIndex = if (isVideo) videoTrackIndex else audioTrackIndex
                            muxer?.writeSampleData(trackIndex, buf, bufferInfo)
                        } else {
                            val bytes = ByteArray(bufferInfo.size)
                            buf.position(bufferInfo.offset)
                            buf.limit(bufferInfo.offset + bufferInfo.size)
                            buf.get(bytes)
                            pending += PendingSample(bytes, bufferInfo.presentationTimeUs, bufferInfo.flags)
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    /** Must be called with [lock] held. */
    private fun drainVideoLocked(endOfStream: Boolean) {
        val codec = videoCodec ?: return
        drainLocked(codec, videoBufferInfo, pendingVideoSamples, isVideo = true, endOfStream)
    }

    /** Must be called with [lock] held. */
    private fun drainAudioLocked(endOfStream: Boolean) {
        val codec = audioCodec ?: return
        drainLocked(codec, audioBufferInfo, pendingAudioSamples, isVideo = false, endOfStream)
    }

    /** Must be called with [lock] held. MediaMuxer requires BOTH tracks
     *  added before start() — whichever encoder reports its output
     *  format second (video and audio each do, exactly once, before
     *  producing any actual encoded data) is what actually triggers
     *  this to fire.
     *
     *  FIX: flushes pendingVideoSamples/pendingAudioSamples — see
     *  drainLocked()'s own doc comment — the instant the muxer actually
     *  starts, so real output produced during the startup race reaches
     *  the file instead of staying queued forever. */
    private fun maybeStartMuxerLocked() {
        if (muxerStarted) return
        if (videoTrackIndex >= 0 && audioTrackIndex >= 0) {
            try {
                muxer?.start()
                muxerStarted = true
                flushPendingLocked(pendingVideoSamples, videoTrackIndex)
                flushPendingLocked(pendingAudioSamples, audioTrackIndex)
            } catch (e: Exception) {
                Log.e(TAG, "MediaMuxer.start() failed", e)
            }
        }
    }

    /** Writes every sample queued by drainLocked() to [trackIndex], in
     *  the order they were captured, then clears the queue. Called only
     *  from maybeStartMuxerLocked() right after the muxer actually
     *  starts — must be called with [lock] held, same as that. */
    private fun flushPendingLocked(pending: MutableList<PendingSample>, trackIndex: Int) {
        if (pending.isEmpty()) return
        val info = MediaCodec.BufferInfo()
        for (sample in pending) {
            info.set(0, sample.bytes.size, sample.presentationTimeUs, sample.flags)
            try {
                muxer?.writeSampleData(trackIndex, ByteBuffer.wrap(sample.bytes), info)
            } catch (e: Exception) {
                Log.w(TAG, "flushPendingLocked", e)
            }
        }
        pending.clear()
    }
}
