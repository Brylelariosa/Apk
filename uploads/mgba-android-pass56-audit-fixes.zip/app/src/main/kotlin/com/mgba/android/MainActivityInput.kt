package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


/** REMOVED (this pass): used to draw "⏩ Nx" in the top-left corner
 *  whenever fast-forward was active — reported as an unwanted
 *  always-on-top speed indicator (see CHANGELOG.md). The button's own
 *  color/fill change (see drawControls()'s ffPressed branch) already
 *  shows on/off state, so nothing replaces this — it's just gone.
 *  formatSpeed() below is still used by the Misc settings text field
 *  and the hold-for-speed-slider popup, so it stays. */
internal fun MainActivity.formatSpeed(s: Float): String =
    if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)


/** Hold-the-»-button speed picker — a slider (0.5–16×, half-speed
 *  steps, matching the existing text-field validation's own range —
 *  see the Fast-forward speed setting in Misc) plus a Done button,
 *  requested as a faster way to change speed than opening Settings
 *  every time. Setting the value here writes the exact same
 *  fastForwardSpeed field/PREF_FF_SPEED pref that setting's own text
 *  field does — either one changes what the other shows next time. */
internal fun MainActivity.showFastForwardSpeedSlider() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(4), dp(24), dp(0))
    }
    val valueText = TextView(ctx).apply {
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }
    layout.addView(valueText)
    // SeekBar only deals in whole-number steps — 0..31 here maps to
    // 0.5..16.0 in steps of 0.5, matching the Misc speed field's own
    // 0.5–16 range exactly (see its "Speed must be 0.5 – 16" check).
    fun speedFor(progress: Int) = 0.5f + progress * 0.5f
    val seek = SeekBar(ctx).apply {
        max = 31
        progress = ((fastForwardSpeed - 0.5f) / 0.5f).toInt().coerceIn(0, 31)
    }
    valueText.text = "${formatSpeed(speedFor(seek.progress))}×"
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
            valueText.text = "${formatSpeed(speedFor(value))}×"
        }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    layout.addView(seek)

    val dialog = AlertDialog.Builder(ctx)
        .setTitle("Fast-forward speed")
        .setView(layout)
        .setPositiveButton("Done") { _, _ ->
            val speed = speedFor(seek.progress)
            fastForwardSpeed = speed
            prefs.edit().putFloat(PREF_FF_SPEED, speed).apply()
        }
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


internal fun MainActivity.clearPointerState() {
    pointerKeys.clear(); pointerTurboA.clear(); pointerTurboB.clear()
}


// FIX (this pass): replaces the removed floating "Load ROM" button (see
// the FIX comment in onCreate where it used to be built) as the way
// back into ROM selection whenever nothing else is on screen — the
// folder picker gets cancelled before any folder's ever been chosen, or
// a ROM load fails (see loadRomFromUri's catch block). Gated on
// !romLoaded specifically so this never fires mid-game: settingsMenuOverlay
// sits on top of the surface while Settings are open and marks itself
// isClickable = true precisely to swallow touches before they'd ever
// reach here (the ROM browser doesn't need the same guard any more —
// it's RomBrowserActivity, a separate Activity now, so MainActivity's
// own surface simply isn't the foreground window, let alone touchable,
// whenever it's showing). ACTION_UP (not ACTION_DOWN) so a
// drag that started on the idle screen doesn't fire this.
internal fun MainActivity.onGameTouch(event: MotionEvent) {
    if (!romLoaded) {
        if (event.actionMasked == MotionEvent.ACTION_UP) changeRom()
        return
    }
    if (editModeActive) { onEditTouch(event); return }
    when (event.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
            val x = event.x; val y = event.y
            // FEATURE (this pass): »/fast-forward no longer toggles the
            // instant it's touched — a hold now shows a speed slider
            // instead (see showFastForwardSpeedSlider()), so this has
            // to wait and see which one it turns out to be. Arms a
            // delayed Runnable exactly like the editor's own
            // hold-to-remove gesture (editLongPressPending above);
            // ACTION_UP/ACTION_POINTER_UP below cancel it and toggle
            // normally if they get there first (a real tap), otherwise
            // the Runnable itself fires, opens the slider, and there's
            // nothing left for either of those to do. See
            // armFfLongPress()'s own doc comment for why this is now
            // shared with ACTION_POINTER_DOWN below.
            if (ffBtnRect.contains(x, y)) {
                armFfLongPress(event.getPointerId(0))
                return
            }
            // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
            // One-tap extra controls (quick save/load, screenshot) — see
            // actionButtonAt(). Deliberately still first-finger-only,
            // unlike ff just above — these are meant as one-off
            // deliberate taps, not something you'd chord mid-gesture
            // with a direction already held, so there's no equivalent
            // case for reaching them from a second finger the way
            // there is for fast-forward (see ACTION_POINTER_DOWN below).
            actionButtonAt(x, y)?.let { id -> triggerActionButton(id); return }
            updateGameKeys(event)
        }
        MotionEvent.ACTION_POINTER_DOWN -> {
            // FIX (this pass — audit's own design-tradeoff note): a
            // second/third finger landing on ff now gets the exact same
            // long-press-for-slider / tap-to-toggle treatment
            // ACTION_DOWN already gives the very first finger — "hold a
            // direction, tap FF to speed through a corridor" is an
            // ordinary GBA-play gesture this made impossible before,
            // since only ACTION_DOWN (by definition the first pointer)
            // ever checked ffBtnRect. quicksave/quickload/screenshot
            // above stay first-finger-only on purpose — see
            // actionButtonAt()'s call site comment in ACTION_DOWN.
            val idx = event.actionIndex
            if (ffLongPressPending == null && ffBtnRect.contains(event.getX(idx), event.getY(idx))) {
                armFfLongPress(event.getPointerId(idx))
                return
            }
            updateGameKeys(event)
        }
        MotionEvent.ACTION_MOVE -> updateGameKeys(event)
        MotionEvent.ACTION_UP -> {
            // FIX (this pass): was `if (ffBtnRect.contains(event.x,
            // event.y))` — required the lifting finger to still be
            // exactly over the button, so pressing ff then drifting
            // off it slightly before releasing (ordinary finger
            // wobble, well within normal tap tolerance) fell through
            // to here *without* cancelling ffLongPressPending, which
            // could then still fire and pop the slider open later,
            // seemingly out of nowhere, after the finger was long
            // gone. Tracking *which pointer* armed the gesture
            // (ffDownPointerId, needed anyway for the new
            // ACTION_POINTER_DOWN case above) fixes both at once: any
            // lift of that specific finger — wherever it currently is
            // — resolves the gesture one way or the other, so there's
            // no path left where it's forgotten about mid-air.
            if (ffDownPointerId != -1 && ffDownPointerId == event.getPointerId(0)) {
                completeFfTap()
                return
            }
            clearPointerState()
            currentKeys.set(0)
            turboAHeld = false; turboBHeld = false
        }
        MotionEvent.ACTION_POINTER_UP -> {
            val liftedId = event.getPointerId(event.actionIndex)
            // Matching half of ACTION_UP's own fix just above — the
            // ff-arming finger isn't necessarily the *last* one down
            // now that a second/third finger can arm it too, so this
            // needs the exact same check, not just ACTION_UP.
            if (ffDownPointerId != -1 && ffDownPointerId == liftedId) {
                completeFfTap()
                return
            }
            // Evict just the lifting finger's sticky state — it's the
            // only one actually going away. The explicit remove() here
            // AND excludePointerIndex below are both needed: this same
            // MotionEvent still reports the lifting pointer at its last
            // coordinates (it's only dropped from the *next* event), so
            // without excluding its index in updateGameKeys(), the
            // hit-test would immediately re-add it to pointerKeys and
            // undo the remove().
            pointerKeys.remove(liftedId)
            pointerTurboA.remove(liftedId)
            pointerTurboB.remove(liftedId)
            updateGameKeys(event, excludePointerIndex = event.actionIndex)
        }
        else                          -> {
            ffLongPressPending?.let { mainHandler.removeCallbacks(it) }
            ffLongPressPending = null
            ffDownPointerId = -1
            clearPointerState()
            currentKeys.set(0)
            turboAHeld = false; turboBHeld = false
        }
    }
}


/** Arms the ff long-press-for-slider Runnable for [pointerId] — shared
 *  by ACTION_DOWN (the first finger touching down fresh) and
 *  ACTION_POINTER_DOWN (a second or third finger landing on ff while
 *  another is already held for a direction) so both go through the
 *  exact same tap-vs-hold logic rather than two independently
 *  maintained copies of it. Only ff gets this multi-finger treatment —
 *  see actionButtonAt()'s call site comment in onGameTouch's
 *  ACTION_DOWN for why quicksave/quickload/screenshot deliberately
 *  don't. */
internal fun MainActivity.armFfLongPress(pointerId: Int) {
    ffDownPointerId = pointerId
    val lp = Runnable {
        ffLongPressPending = null
        ffDownPointerId = -1
        showFastForwardSpeedSlider()
    }
    ffLongPressPending = lp
    mainHandler.postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong())
}


/** The matching "this finger lifted before the long-press fired" half
 *  of [armFfLongPress] — a genuine tap, so toggle fastForwardActive
 *  normally. Called once onGameTouch has already confirmed the
 *  *specific* finger that armed the gesture is the one lifting (either
 *  ACTION_UP, if it was the last finger down, or ACTION_POINTER_UP if
 *  another is still held) — safe to call unconditionally at that
 *  point: a no-op `?.let` if the long press already fired
 *  (ffLongPressPending is already null and the slider is open by
 *  then — toggling fast-forward out from under it here would be
 *  wrong), otherwise cancels the pending Runnable and toggles. Either
 *  way, ffDownPointerId always clears — this finger's gesture is
 *  resolved now, one way or the other. */
internal fun MainActivity.completeFfTap() {
    ffLongPressPending?.let { pending ->
        mainHandler.removeCallbacks(pending)
        ffLongPressPending = null
        fastForwardActive = !fastForwardActive
    }
    ffDownPointerId = -1
}


internal fun MainActivity.updateGameKeys(event: MotionEvent, excludePointerIndex: Int = -1) {
    for (i in 0 until event.pointerCount) {
        if (i == excludePointerIndex) continue
        val pid = event.getPointerId(i)
        val x = event.getX(i); val y = event.getY(i)
        var hitAny = false
        var hitKeys = 0
        var hitTa = false
        var hitTb = false
        for (btn in buttons) {
            if (!btn.rect.contains(x, y)) continue
            hitAny = true
            when (btn.id) {
                // Turbo satellites don't feed currentKeys directly (that
                // would just be a continuous hold) — see the on/off
                // square-wave applied in startGameLoop() before
                // nativeSetKeys().
                "ta" -> hitTa = true
                "tb" -> hitTb = true
                // "A/B turbo" combo — both satellites at once, reusing
                // the exact same pointerTurboA/pointerTurboB machinery
                // as ta/tb individually. Both share one phaseOn value
                // in effectiveKeysForCore(), so driving both from a
                // single touch square-waves A and B together in sync,
                // rather than needing a third independent turbo channel.
                "abturbo" -> { hitTa = true; hitTb = true }
                else -> hitKeys = hitKeys or (if (btn.isDpad) dpadKeysFor(btn.rect, x, y) else btn.keyMask)
            }
        }
        if (hitAny) {
            // Overwrite (don't merge with) this pointer's previous
            // sticky state — a finger that's moved onto a different
            // button, or off Turbo onto a normal button, should read
            // as ONLY what it's on now, not accumulate stale bits from
            // wherever it used to be.
            pointerKeys[pid] = hitKeys
            if (hitTa) pointerTurboA.add(pid) else pointerTurboA.remove(pid)
            if (hitTb) pointerTurboB.add(pid) else pointerTurboB.remove(pid)
        }
        // else: this pointer is over empty space right now. Leave
        // pointerKeys[pid] / pointerTurboA / pointerTurboB exactly as
        // they were — that's the fix itself: a control that was
        // pressed keeps reading as pressed while dragged off it, until
        // this specific pointer lifts (handled in onGameTouch above).
    }

    var keys = 0
    for (k in pointerKeys.values) keys = keys or k
    currentKeys.set(keys)
    turboAHeld = pointerTurboA.isNotEmpty()
    turboBHeld = pointerTurboB.isNotEmpty()
}


/** currentKeys as touched, plus the Turbo A/B on/off square wave mixed
 *  in if either is currently held. Kept separate from currentKeys
 *  itself so the on-screen "pressed" glow stays a simple, steady held
 *  state (see drawControls()) — only what actually reaches the core
 *  flickers. Called once per emulated frame from startGameLoop(), which
 *  at turboHalfPeriodMs=66 is plenty of resolution for the wave to read
 *  cleanly even under fast-forward. */
internal fun MainActivity.effectiveKeysForCore(): Int {
    var keys = currentKeys.get()
    if (turboAHeld || turboBHeld) {
        val phaseOn = (System.currentTimeMillis() / turboHalfPeriodMs) % 2L == 0L
        if (turboAHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_A else keys and EmulatorEngine.KEY_A.inv()
        if (turboBHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_B else keys and EmulatorEngine.KEY_B.inv()
    }
    return keys
}


internal fun MainActivity.actionButtonAt(x: Float, y: Float): String? =
    buttons.firstOrNull { it.id in actionButtonIds && it.rect.contains(x, y) }?.id


internal fun MainActivity.triggerActionButton(id: String) {
    // FIX (direct report: "quick load and save button is bad there
    // highlights same for screenshot button") — see
    // actionButtonFlashId/actionButtonFlashUntil's own doc comment
    // (MainActivity.kt) for the full diagnosis. "record" doesn't need
    // this: it already gets a real, meaningful pressed indicator from
    // drawControls()'s own `screenRecorder?.isRecording == true` check
    // (hollow outline while idle, filled while actually recording), so
    // it's deliberately left out here rather than having this
    // momentary flash fight with that steadier state right after tap.
    if (id == "quicksave" || id == "quickload" || id == "screenshot") {
        actionButtonFlashId = id
        actionButtonFlashUntil = System.currentTimeMillis() + ACTION_BUTTON_FLASH_MS
    }
    when (id) {
        "quicksave"  -> quickSaveState()
        "quickload"  -> quickLoadState()
        "screenshot" -> takeScreenshot()
        "record"     -> toggleScreenRecording()
    }
}

