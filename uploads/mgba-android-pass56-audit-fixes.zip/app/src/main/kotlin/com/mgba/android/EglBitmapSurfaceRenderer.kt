package com.mgba.android

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Draws Bitmaps onto a MediaCodec encoder's input Surface via a real EGL/
 *  GLES2 pipeline — the video half of GameScreenRecorder.
 *
 *  FIX (direct report: "screen record is bad it record sound but not
 *  frame it show only 1 frame"). GameScreenRecorder used to draw each
 *  frame with Surface.lockCanvas() — a plain *software* canvas —
 *  straight onto MediaCodec.createInputSurface()'s own Surface. That
 *  Surface's own docs are explicit it "must be rendered with a
 *  hardware-accelerated API, such as OpenGL ES," and lockCanvas()
 *  specifically "may fail or produce unexpected results" on one. In
 *  practice: the very first lockCanvas()/unlockCanvasAndPost() got a
 *  real frame into the encoder (why one frame showed up at all), but
 *  that software-canvas path was never meant to drive this kind of
 *  Surface, so the encoder's input queue couldn't make forward progress
 *  after it — every later capture never advanced the video past that
 *  first frame, while audio (its own, completely separate ByteBuffer-
 *  input codec, never touching this Surface at all) kept encoding fine
 *  the whole time.
 *
 *  Switching the same call site to Surface.lockHardwareCanvas() — same
 *  drawBitmap(), hardware-backed — let more than one frame through, but
 *  is a RenderThread/HWUI path meant for ordinary display-bound Surfaces
 *  (a SurfaceView's own, a TextureView's own), not the mechanism Android's
 *  own sample code or CTS media tests use to feed an *encoder's* input
 *  Surface, and it could still eventually starve there (a later frame
 *  throwing on lockHardwareCanvas() itself, caught, silently skipped —
 *  the encoder side, not the drawing side, is what actually froze).
 *
 *  This class replaces both with the standard, documented mechanism for
 *  exactly this "feed a Surface-input encoder from programmatically-drawn
 *  content" case: a real EGL context created directly against the
 *  encoder's own Surface, a Bitmap uploaded as a plain GLES2 2D texture
 *  and drawn onto a full-viewport quad, and eglSwapBuffers()+
 *  eglPresentationTimeANDROID() to submit each frame with an explicit
 *  timestamp — the same approach Grafika's "record OpenGL ES" sample and
 *  the platform's own EncodeDecodeTest use.
 *
 *  NOT thread-safe by design, and deliberately has no locking of its
 *  own: an EGL context is bound to whichever thread last called
 *  eglMakeCurrent() with it, so every method here — [start], every
 *  [drawFrame], and [release] — must be called from the same single
 *  thread for the lifetime of one instance. GameScreenRecorder's own
 *  capture thread is that thread; nothing else ever touches this class. */
internal class EglBitmapSurfaceRenderer(private val outputSurface: Surface) {

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aTexCoord;
            }
        """
        private const val FRAGMENT_SHADER = """
            precision mediump float;
            varying vec2 vTexCoord;
            uniform sampler2D uTexture;
            void main() {
                gl_FragColor = texture2D(uTexture, vTexCoord);
            }
        """
        // Full-viewport quad as a triangle strip: top-left, bottom-left,
        // top-right, bottom-right. Texcoord v=0 is the SOURCE BITMAP'S
        // TOP row — GLUtils.texImage2D/texSubImage2D upload a Bitmap's
        // rows as-is, no implicit flip — and NDC y=+1 is the top of
        // this Surface's own eventual output (the same convention every
        // ordinary GLSurfaceView-rendered Android screen already relies
        // on without anyone needing to think about it), so this mapping
        // needs no extra vertical flip on top of that.
        private val QUAD_POSITIONS = floatArrayOf(
            -1f, 1f,
            -1f, -1f,
            1f, 1f,
            1f, -1f
        )
        private val QUAD_TEXCOORDS = floatArrayOf(
            0f, 0f,
            0f, 1f,
            1f, 0f,
            1f, 1f
        )
    }

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var textureId = 0
    private var positionHandle = 0
    private var texCoordHandle = 0
    private var textureUniformHandle = 0
    // Set once the texture's storage has been allocated (first frame) —
    // see drawFrame()'s own comment for why every frame after that reuses
    // it via texSubImage2D instead of reallocating.
    private var textureAllocated = false

    private val positionBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(QUAD_POSITIONS.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(QUAD_POSITIONS); position(0) }
    private val texCoordBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(QUAD_TEXCOORDS.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(QUAD_TEXCOORDS); position(0) }

    /** Sets up EGL against [outputSurface] and compiles the shader
     *  program. Must be called once, before the first [drawFrame], from
     *  the thread that will own this renderer for its whole lifetime.
     *  Throws (does not return a status) on any setup failure — the
     *  caller treats that the same as any other capture-thread startup
     *  failure. */
    fun start() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) error("eglGetDisplay failed")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) error("eglInitialize failed")

        // EGL_RECORDABLE_ANDROID: hints the driver this config's surfaces
        // feed a video encoder/recorder, not just the display — the same
        // attribute Grafika's own recording sample sets for exactly this
        // "draw into a MediaCodec input Surface" case.
        val configAttribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0) ||
            numConfigs[0] <= 0
        ) {
            error("eglChooseConfig found no matching config")
        }
        val config = configs[0] ?: error("eglChooseConfig returned a null config")

        val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) error("eglCreateContext failed")

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, outputSurface, surfaceAttribs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) error("eglCreateWindowSurface failed")

        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            error("eglMakeCurrent failed")
        }

        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        textureUniformHandle = GLES20.glGetUniformLocation(program, "uTexture")

        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    /** Draws [bitmap] as the encoder's next frame, presented at
     *  [presentationTimeNs] — the video encoder uses the delta between
     *  consecutive calls' timestamps for its own internal pacing, not
     *  wall-clock arrival time, so the caller just needs these
     *  monotonically increasing (GameScreenRecorder uses a
     *  recording-start-relative nanoTime()). */
    fun drawFrame(bitmap: Bitmap, presentationTimeNs: Long) {
        GLES20.glViewport(0, 0, bitmap.width, bitmap.height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        // FIX (perf): every bitmap captureGameFrameBitmap() hands this
        // class is already scaled to the exact same fixed VIDEO_WIDTH x
        // VIDEO_HEIGHT (Bitmap.createScaledBitmap's own contract), so
        // the texture's storage only needs allocating once — texSubImage2D
        // re-fills the same storage every later frame instead of having
        // GL reallocate it, on a thread that already has a full bitmap
        // capture to do every frame regardless.
        if (!textureAllocated) {
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
            textureAllocated = true
        } else {
            GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bitmap)
        }
        GLES20.glUniform1i(textureUniformHandle, 0)

        positionBuffer.position(0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, positionBuffer)

        texCoordBuffer.position(0)
        GLES20.glEnableVertexAttribArray(texCoordHandle)
        GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(texCoordHandle)

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, presentationTimeNs)
        if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
            // Mirrors GameScreenRecorder's own long-standing tolerance
            // for this class of failure (see its captureAndDrawFrame()
            // caller): stop()/teardownLocked() can race in on another
            // thread and tear the underlying Surface down mid-frame —
            // logged and skipped, not a crash, since a recording that's
            // already ending has nothing meaningful left to submit to.
            Log.w(TAG, "EglBitmapSurfaceRenderer: eglSwapBuffers failed")
        }
    }

    /** Releases every EGL/GL resource. Safe to call even if [start]
     *  threw partway through, or more than once — every step is
     *  individually guarded, matching GameScreenRecorder's own
     *  teardownLocked() style right next to this class's caller. */
    fun release() {
        if (textureId != 0) {
            try { GLES20.glDeleteTextures(1, intArrayOf(textureId), 0) } catch (e: Exception) {}
            textureId = 0
        }
        if (program != 0) {
            try { GLES20.glDeleteProgram(program) } catch (e: Exception) {}
            program = 0
        }
        try {
            if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            }
        } catch (e: Exception) {}
        try {
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
        } catch (e: Exception) {}
        eglSurface = EGL14.EGL_NO_SURFACE
        try {
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
        } catch (e: Exception) {}
        eglContext = EGL14.EGL_NO_CONTEXT
        try {
            if (eglDisplay != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(eglDisplay)
        } catch (e: Exception) {}
        eglDisplay = EGL14.EGL_NO_DISPLAY
    }

    private fun buildProgram(vertexSrc: String, fragmentSrc: String): Int {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
        val prog = GLES20.glCreateProgram()
        if (prog == 0) error("glCreateProgram failed")
        GLES20.glAttachShader(prog, vertexShader)
        GLES20.glAttachShader(prog, fragmentShader)
        GLES20.glLinkProgram(prog)
        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, linkStatus, 0)
        GLES20.glDeleteShader(vertexShader)
        GLES20.glDeleteShader(fragmentShader)
        if (linkStatus[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(prog)
            GLES20.glDeleteProgram(prog)
            error("Program link failed: $log")
        }
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        if (shader == 0) error("glCreateShader failed for type $type")
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            error("Shader compile failed: $log")
        }
        return shader
    }
}
