package com.mgba.android

import android.text.format.DateFormat
import android.util.Log
import java.io.File
import java.io.IOException

// ─────────────────────────────────────────────────────────────────────────
// FEATURE — direct report: "add features screen recorder on it but only
// the game screen will record and sound no button." GameScreenRecorder.kt
// is the actual encoding engine (self-contained, no UI/Settings
// knowledge) — this file is the glue: the record-button toggle, saving
// the finished file to wherever Screenshots already save to (mirrors
// takeScreenshot()/saveScreenshotBitmap(), MainActivityDebugLog.kt,
// exactly — same dataSubfolder()/autoMirrorSubdir() fallback, just a
// "video" subfolder and a file copy instead of a bitmap compress), and
// hooking start/stop to the activity lifecycle.
// ─────────────────────────────────────────────────────────────────────────

/** The record button's tap handler — see actionButtonIds/labelFor()
 *  (MainActivity.kt/MainActivityControlEditorGeometry.kt) and
 *  MainActivityInput.kt's triggerActionButton() for where this is wired
 *  in alongside quicksave/quickload/screenshot. Both start and stop run
 *  off the main thread — MediaCodec/MediaMuxer setup and teardown aren't
 *  guaranteed instant, and a button tap is exactly the kind of thing
 *  that should never risk a visible stutter. */
internal fun MainActivity.toggleScreenRecording() {
    if (!romLoaded) { uiToast("Load a ROM first"); return }
    if (screenRecorder.isRecording) {
        uiToast("Recording stopped — saving…")
        Thread {
            val finished = screenRecorder.stop()
            if (finished != null) finishRecordingAndSave(finished)
            else uiToast("Recording failed")
        }.apply { name = "mGBA-recorder-stop" }.start()
    } else {
        Thread {
            val started = screenRecorder.start()
            uiToast(if (started != null) "Recording started" else "Couldn't start recording")
        }.apply { name = "mGBA-recorder-start" }.start()
    }
}

/** Copies the finished temp recording (see GameScreenRecorder's own doc
 *  comment for why it's a temp file in the first place) into the chosen
 *  Storage folder's "video" subfolder, or the same automatic-mirror
 *  fallback Screenshots/saves already use. Deletes the temp file either
 *  way — this is the terminal step, nothing downstream still needs it. */
internal fun MainActivity.finishRecordingAndSave(tempFile: File) {
    val stamp = DateFormat.format("yyyyMMdd_HHmmss", System.currentTimeMillis())
    val name = "${currentRomBaseName}_$stamp.mp4"
    try {
        val subDir = dataSubfolder("video")
        if (subDir != null) {
            val doc = subDir.createFile("video/mp4", name)
                ?: throw IOException("Couldn't create $name in the chosen folder")
            contentResolver.openOutputStream(doc.uri)?.use { out ->
                tempFile.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IOException("openOutputStream failed for $name")
        } else {
            val dir = autoMirrorSubdir("Recordings")
                ?: File(getExternalFilesDir(null), "Recordings").apply { mkdirs() }
            tempFile.copyTo(File(dir, name), overwrite = true)
        }
        uiToast("Saved $name")
    } catch (e: Exception) {
        Log.e(TAG, "Recording save failed", e)
        uiToast("Recording save failed")
    } finally {
        tempFile.delete()
    }
}

/** onPause()'s/onDestroy()'s own call into this (see both) — recording
 *  can't meaningfully continue once stopGameLoop() has stopped producing
 *  new frames, and leaving one open across a backgrounding is exactly
 *  the kind of unbounded-file/leaked-resource risk that reasoning
 *  applies to as well. Stops AND saves whatever was captured so far
 *  rather than silently discarding it — a recording cut short by
 *  switching apps should still leave a (shorter) clip, not nothing.
 *
 *  Deliberately NOT backgrounded onto a new Thread the way
 *  toggleScreenRecording()'s own stop path is: onPause()/onDestroy()
 *  give the process very little guaranteed time to keep running once
 *  they return, so a copy still in flight on some other thread when the
 *  process actually dies would lose the recording anyway. Blocking
 *  briefly for a same-device file copy right here is the safer trade. */
internal fun MainActivity.stopScreenRecordingForLifecycle() {
    if (!screenRecorder.isRecording) return
    val finished = screenRecorder.stop()
    if (finished != null) finishRecordingAndSave(finished)
}
