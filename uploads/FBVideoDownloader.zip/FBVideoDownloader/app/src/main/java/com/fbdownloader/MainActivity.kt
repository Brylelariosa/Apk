package com.fbdownloader

import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var urlInput: EditText
    private lateinit var pasteBtn: ImageButton
    private lateinit var extractBtn: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var downloadSdBtn: Button
    private lateinit var downloadHdBtn: Button

    private var sdUrl: String? = null
    private var hdUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        pasteBtn = findViewById(R.id.pasteBtn)
        extractBtn = findViewById(R.id.extractBtn)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        downloadSdBtn = findViewById(R.id.downloadSdBtn)
        downloadHdBtn = findViewById(R.id.downloadHdBtn)

        pasteBtn.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.primaryClip?.getItemAt(0)?.text?.toString()?.let {
                urlInput.setText(it)
            }
        }

        extractBtn.setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (url.isEmpty()) {
                statusText.text = "Paste a Facebook video URL first"
                return@setOnClickListener
            }
            if (!url.contains("facebook.com") && !url.contains("fb.watch")) {
                statusText.text = "That doesn't look like a Facebook URL"
                return@setOnClickListener
            }
            extractVideo(url)
        }

        downloadSdBtn.setOnClickListener { sdUrl?.let { startDownload(it, "SD") } }
        downloadHdBtn.setOnClickListener { hdUrl?.let { startDownload(it, "HD") } }

        // Handle share intent from other apps
        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleShareIntent(it) }
    }

    private fun handleShareIntent(intent: Intent) {
        if (intent.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val urlMatch = Regex("""https?://\S*(facebook\.com|fb\.watch)\S*""").find(sharedText)
            urlMatch?.value?.let { urlInput.setText(it) }
        }
    }

    private fun extractVideo(url: String) {
        scope.launch {
            setLoading(true)
            statusText.text = "Looking for video..."
            downloadSdBtn.visibility = View.GONE
            downloadHdBtn.visibility = View.GONE
            sdUrl = null
            hdUrl = null

            try {
                val (sd, hd) = withContext(Dispatchers.IO) { fetchVideoUrls(url) }
                sdUrl = sd
                hdUrl = hd

                when {
                    sd == null && hd == null ->
                        statusText.text = "❌ No video found. The video may be private or the URL is unsupported."
                    else -> {
                        statusText.text = "✅ Video found! Choose quality to download:"
                        if (sd != null) downloadSdBtn.visibility = View.VISIBLE
                        if (hd != null) downloadHdBtn.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                statusText.text = "❌ Error: ${e.message ?: "Unknown error"}"
            } finally {
                setLoading(false)
            }
        }
    }

    private fun fetchVideoUrls(originalUrl: String): Pair<String?, String?> {
        // Try mobile URL first — simpler HTML, more reliable parsing
        val mobileUrl = originalUrl
            .replace("www.facebook.com", "m.facebook.com")
            .replace("web.facebook.com", "m.facebook.com")

        val html = fetchHtml(mobileUrl)
            ?: fetchHtml(originalUrl)
            ?: throw Exception("Could not load page. Check your internet connection.")

        val sd = findUrl(html, listOf(
            Regex(""""sd_src":"([^"]+)""""),
            Regex(""""playable_url":"([^"]+)""""),
            Regex(""""browser_native_sd_url":"([^"]+)""""),
            Regex(""""sd_src_no_ratelimit":"([^"]+)""""),
            Regex(""""url":"(https:[^"]+\.mp4[^"]*)"(?:[^}]*"width":\d+)?""")
        ))

        val hd = findUrl(html, listOf(
            Regex(""""hd_src":"([^"]+)""""),
            Regex(""""browser_native_hd_url":"([^"]+)""""),
            Regex(""""hd_src_no_ratelimit":"([^"]+)"""")
        ))

        // Avoid returning identical URLs for both qualities
        return Pair(sd, if (hd != sd) hd else null)
    }

    private fun fetchHtml(url: String): String? = try {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .build()
        val response = client.newCall(request).execute()
        if (response.isSuccessful) response.body?.string() else null
    } catch (e: Exception) {
        null
    }

    private fun findUrl(html: String, patterns: List<Regex>): String? {
        for (pattern in patterns) {
            val match = pattern.find(html) ?: continue
            val raw = match.groupValues[1]
            val decoded = raw
                .replace("\\u002F", "/")
                .replace("\\u0025", "%")
                .replace("\\/", "/")
            if (decoded.startsWith("http") && (decoded.contains(".mp4") || decoded.contains("video"))) {
                return decoded
            }
        }
        return null
    }

    private fun startDownload(url: String, quality: String) {
        try {
            val filename = "fb_video_${System.currentTimeMillis()}_$quality.mp4"
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle("FB Video ($quality)")
                setDescription(filename)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
            }
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(this, "⬇ Downloading $quality to Downloads folder", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        extractBtn.isEnabled = !loading
        urlInput.isEnabled = !loading
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
