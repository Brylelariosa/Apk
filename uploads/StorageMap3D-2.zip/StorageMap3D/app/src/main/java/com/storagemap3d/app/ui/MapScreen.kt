package com.storagemap3d.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.MapSel
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.gl.MapView
import com.storagemap3d.app.gl.PickKind

private val PANEL_GLASS = Color(0xF0111F2D)

@Composable
fun MapScreen(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    if (vm.access == AccessMode.None) {
        NeedAccess("The map needs storage access", onGrantAll, onPickFolder)
    } else if (!vm.indexUsable) {
        NeedScan(vm, "Scan to draw your map")
    } else {
        MapContent(vm)
    }
}

@Composable
private fun MapContent(vm: MainViewModel) {
    val owner = LocalLifecycleOwner.current
    var view by remember { mutableStateOf<MapView?>(null) }
    var glError by remember { mutableStateOf<String?>(null) }
    val scene = vm.scene

    LaunchedEffect(scene == null, vm.indexUsable) {
        vm.ensureMap()
    }

    // Pause and resume the GL thread with the screen so it never renders while the app is hidden.
    DisposableEffect(owner, view) {
        val target = view
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) target?.resumeGl()
            if (event == Lifecycle.Event.ON_PAUSE) target?.pauseGl()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    Box(Modifier.fillMaxSize().background(Pal.Ink)) {
        AndroidView(
            factory = { ctx ->
                val v = MapView(ctx, vm.camera)
                v.onPick = { index -> vm.onMapPick(index) }
                v.onError = { message -> glError = message }
                view = v
                v
            },
            modifier = Modifier.fillMaxSize(),
            update = { v ->
                v.animate = !vm.reduceMotion
                val s = vm.scene
                if (s != null && v.scene !== s) {
                    v.showScene(s, vm.takeCameraReset())
                }
                v.setSelected(vm.selectedNodeId)
            },
        )

        CrumbBar(vm, Modifier.align(Alignment.TopStart).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp))

        if (scene != null && scene.totalItems > 0) {
            Text(
                "Showing the " + scene.shownItems + " largest of " + scene.totalItems + " items",
                style = Type.Small,
                color = Pal.Dim,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 20.dp, top = 68.dp),
            )
        }

        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            MapButton(Ico.Plus, "Zoom in") { view?.zoomBy(0.78f) }
            MapButton(Ico.Minus, "Zoom out") { view?.zoomBy(1.28f) }
            MapButton(Ico.Target, "Reset view") { view?.resetView() }
        }

        val sel = vm.mapSel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (sel != null) {
                SelectionCard(vm, sel)
            } else {
                Text(
                    "Drag to rotate  \u00b7  pinch to zoom  \u00b7  two fingers to pan  \u00b7  tap a block",
                    style = Type.Small,
                    color = Pal.Faint,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                LegendStrip()
            }
        }

        if (vm.mapBusy) {
            CenterNote("Building the map\u2026")
        } else if (glError != null) {
            Box(Modifier.align(Alignment.Center).padding(24.dp)) {
                Notice(
                    "3D drawing is not available on this device: " + glError,
                    tone = Tone.Bad,
                    ico = Ico.Warning,
                )
            }
        } else if (vm.mapMessage != null) {
            CenterNote(vm.mapMessage ?: "")
        }
    }
}

@Composable
private fun BoxScope.CenterNote(text: String) {
    val shape = RoundedCornerShape(14.dp)
    Text(
        text,
        style = Type.Body,
        color = Pal.Text,
        modifier = Modifier
            .align(Alignment.Center)
            .clip(shape)
            .background(PANEL_GLASS)
            .border(1.dp, Pal.Line, shape)
            .padding(horizontal = 18.dp, vertical = 12.dp),
    )
}

@Composable
private fun MapButton(ico: Ico, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(PANEL_GLASS)
            .border(1.dp, Pal.Line, CircleShape)
            .semantics { contentDescription = desc }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        IconMark(ico, tint = Pal.Text)
    }
}

@Composable
private fun CrumbBar(vm: MainViewModel, modifier: Modifier) {
    val crumbs = vm.mapCrumbs
    val scroll = rememberScrollState()
    LaunchedEffect(crumbs) { scroll.scrollTo(scroll.maxValue) }
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .clip(shape)
            .background(PANEL_GLASS)
            .border(1.dp, Pal.Line, shape),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (crumbs.size > 1) {
            IconBtn(Ico.Up, "Up one level", { vm.mapUp() }, tint = Pal.Text)
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            crumbs.forEachIndexed { i, c ->
                if (i > 0) {
                    IconMark(Ico.Chevron, tint = Pal.Faint, boxSize = 14.dp, modifier = Modifier.padding(horizontal = 2.dp))
                }
                val last = i == crumbs.size - 1
                Text(
                    c.name,
                    style = if (last) Type.BodyStrong else Type.Body,
                    color = if (last) Pal.Text else Pal.Dim,
                    maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = !last) { vm.openMapFocus(c.id) }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
    }
}

@Composable
private fun LegendStrip() {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(PANEL_GLASS)
            .border(1.dp, Pal.Line, shape)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LegendDot(Color(0xFF86A5C6), "Folder")
        for (c in Cat.order) LegendDot(Color(Cat.color(c)), Cat.label(c))
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(7.dp))
        Text(label, style = Type.Small, color = Pal.Dim, maxLines = 1)
    }
}

@Composable
private fun SelectionCard(vm: MainViewModel, sel: MapSel) {
    val node = sel.node
    val ref = sel.ref
    val isDir = sel.kind == PickKind.CONTAINER || sel.kind == PickKind.FOLDER
    Panel(Modifier.fillMaxWidth(), padding = 14.dp, container = Pal.Panel) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FileTile(isDir, node?.cat ?: 0)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(sel.title, style = Type.Heading, color = Pal.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val subtitle: String = if (node == null) {
                    "Items too small to draw one by one"
                } else if (node.isDir) {
                    Fmt.count(node.files) + " files  \u00b7  " + Fmt.count(node.dirs) + " folders"
                } else {
                    Cat.label(node.cat) + "  \u00b7  " + Fmt.ago(node.mtime)
                }
                Text(subtitle, style = Type.Small, color = Pal.Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconBtn(Ico.Close, "Clear selection", { vm.clearMapSelection() })
        }
        if (node != null && ref != null) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(Fmt.bytes(node.size), style = Type.NumLarge, color = Pal.Text)
                    Text("Size", style = Type.Small, color = Pal.Dim)
                }
                Column(Modifier.weight(1f)) {
                    Text(vm.shareOfFocus(node.size), style = Type.NumLarge, color = Pal.Text)
                    Text("of this folder", style = Type.Small, color = Pal.Dim)
                }
            }
            Spacer(Modifier.height(12.dp))
            if (node.isDir) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppButton("Open folder", { vm.openMapFocus(node.id) }, Modifier.weight(1f))
                    AppButton("In Explorer", { vm.showInExplorer(ref) }, Modifier.weight(1f), kind = BtnKind.Secondary)
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppButton("Open", { vm.openFile(ref) }, Modifier.weight(1f))
                    AppButton("Share", { vm.shareFile(ref) }, Modifier.weight(1f), kind = BtnKind.Secondary)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppButton("Explorer", { vm.showInExplorer(ref) }, Modifier.weight(1f), kind = BtnKind.Ghost)
                    AppButton("Details", { vm.showProperties(ref) }, Modifier.weight(1f), kind = BtnKind.Ghost)
                    AppButton("Delete", { vm.requestDelete(listOf(ref)) }, Modifier.weight(1f), kind = BtnKind.Danger)
                }
            }
        }
    }
}
