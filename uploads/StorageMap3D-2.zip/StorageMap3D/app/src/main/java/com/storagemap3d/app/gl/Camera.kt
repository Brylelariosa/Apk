package com.storagemap3d.app.gl

import android.opengl.Matrix
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.tan

/**
 * Orbit camera around a point on the ground plane. The UI thread changes it from touch gestures and
 * the GL thread reads it every frame, so the fields are volatile.
 */
class OrbitCamera {
    @Volatile var yaw = 0.62f
    @Volatile var pitch = 0.92f
    @Volatile var dist = 160f
    @Volatile var tx = 50f
    @Volatile var tz = 50f
    @Volatile var extent = 100f

    private val fovY = 45f

    /** Frame a square scene of the given size. */
    fun reset(sceneExtent: Float) {
        extent = sceneExtent
        yaw = 0.62f
        pitch = 0.92f
        dist = sceneExtent * 1.6f
        tx = sceneExtent / 2f
        tz = sceneExtent / 2f
    }

    fun eye(out: FloatArray) {
        val cp = cos(pitch)
        out[0] = tx + dist * cp * sin(yaw)
        out[1] = dist * sin(pitch)
        out[2] = tz + dist * cp * cos(yaw)
    }

    fun viewProj(width: Int, height: Int, out: FloatArray) {
        val view = FloatArray(16)
        val proj = FloatArray(16)
        val e = FloatArray(3)
        eye(e)
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], tx, 0f, tz, 0f, 1f, 0f)
        val aspect = if (height <= 0) 1f else width.toFloat() / height.toFloat()
        Matrix.perspectiveM(proj, 0, fovY, aspect, 4f, 1400f)
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }

    /** Drag with one finger: orbit. */
    fun rotate(dxPx: Float, dyPx: Float) {
        yaw -= dxPx * 0.0055f
        pitch = (pitch + dyPx * 0.0045f).coerceIn(0.22f, 1.5f)
    }

    /** Pinch: positive factor below 1 zooms in. */
    fun zoom(factor: Float) {
        dist = (dist * factor).coerceIn(extent * 0.22f, extent * 3.6f)
    }

    /** Drag with two fingers: slide the scene under the camera. */
    fun pan(dxPx: Float, dyPx: Float, viewHeightPx: Int) {
        val h = max(viewHeightPx, 1).toFloat()
        val perPixel = 2f * dist * tan(Math.toRadians((fovY / 2f).toDouble())).toFloat() / h
        val s = max(sin(pitch), 0.35f)
        val sy = sin(yaw)
        val cy = cos(yaw)
        tx += (-cy * dxPx - sy * dyPx / s) * perPixel
        tz += (sy * dxPx - cy * dyPx / s) * perPixel
        tx = tx.coerceIn(-extent * 0.3f, extent * 1.3f)
        tz = tz.coerceIn(-extent * 0.3f, extent * 1.3f)
    }
}
