package com.storagemap3d.app.core

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class DupPhase { Idle, Running, Done, Cancelled, Failed }

data class DupUi(
    val phase: DupPhase = DupPhase.Idle,
    val candidates: Long = 0L,
    val checked: Long = 0L,
    val groups: Int = 0,
    val wasted: Long = 0L,
    val hashedBytes: Long = 0L,
    val message: String = "",
)

/**
 * Finds identical files without reading more than necessary:
 *  1. files are grouped by exact size (from the index, no disk access),
 *  2. each file in a group gets a cheap sampled SHA-256 (head, middle and tail),
 *  3. only files that still match get a full SHA-256.
 * Only files whose full digests match are reported. Nothing is ever deleted here.
 */
class DupEngine(
    private val db: Db,
    private val backend: Backend,
    private val scope: CoroutineScope,
    private val onResults: () -> Unit,
) {
    var ui by mutableStateOf(DupUi())
        private set

    @Volatile
    private var cancelled = false
    private var job: Job? = null
    private var candidates = 0L
    private val checked = AtomicLong(0L)
    private val hashedBytes = AtomicLong(0L)
    private val groups = AtomicInteger(0)
    private val wasted = AtomicLong(0L)
    private val lastPublish = AtomicLong(0L)

    val running: Boolean
        get() = ui.phase == DupPhase.Running

    fun cancel() {
        if (!running) return
        cancelled = true
        if (Native.loaded) Native.hashCancel(true)
    }

    fun start(minSize: Long) {
        if (running) return
        if (!Native.loaded) {
            ui = DupUi(phase = DupPhase.Failed, message = "The native hashing library could not be loaded.")
            return
        }
        cancelled = false
        candidates = 0L
        checked.set(0L)
        hashedBytes.set(0L)
        groups.set(0)
        wasted.set(0L)
        lastPublish.set(0L)
        ui = DupUi(phase = DupPhase.Running)

        job = scope.launch(Dispatchers.IO) {
            try {
                if (db.lastScan() == null) {
                    ui = DupUi(phase = DupPhase.Failed, message = "Scan your storage first.")
                } else {
                    Native.hashCancel(false)
                    db.clearDups()
                    val sizeGroups = db.dupSizeGroups(minSize)
                    var total = 0L
                    for (g in sizeGroups) total += g.count.toLong()
                    candidates = total
                    ui = DupUi(phase = DupPhase.Running, candidates = total)

                    val gate = Semaphore(2)
                    coroutineScope {
                        for (g in sizeGroups) {
                            if (cancelled) break
                            gate.acquire()
                            launch {
                                try {
                                    if (!cancelled) processGroup(g)
                                } finally {
                                    gate.release()
                                }
                            }
                        }
                    }
                    ui = DupUi(
                        phase = if (cancelled) DupPhase.Cancelled else DupPhase.Done,
                        candidates = candidates,
                        checked = checked.get(),
                        groups = groups.get(),
                        wasted = wasted.get(),
                        hashedBytes = hashedBytes.get(),
                    )
                }
            } catch (t: Throwable) {
                ui = DupUi(phase = DupPhase.Failed, message = t.message ?: "The duplicate search stopped unexpectedly.")
            }
            withContext(Dispatchers.Main) { onResults() }
        }
    }

    private fun processGroup(g: SizeGroup) {
        val ids = db.nodeIdsOfSize(g.size)
        val refs = ArrayList<FileRef>(ids.size)
        for (id in ids) {
            val n = db.node(id)
            if (n != null) refs.add(backend.refOf(n))
        }
        // Files up to the sampling threshold are read completely either way, so hash them fully at once.
        val small = g.size <= SMALL_FILE

        val byPartial = HashMap<String, ArrayList<FileRef>>()
        for (r in refs) {
            if (cancelled) return
            val digest = backend.hash(r, if (small) 1 else 0)
            checked.incrementAndGet()
            if (small) hashedBytes.addAndGet(g.size)
            publish(false)
            if (digest == null) continue
            byPartial.getOrPut(Native.hex(digest)) { ArrayList() }.add(r)
        }

        for ((partialDigest, members) in byPartial) {
            if (cancelled) return
            if (members.size < 2) continue
            if (small) {
                save(g.size, partialDigest, members)
                continue
            }
            val byFull = HashMap<String, ArrayList<FileRef>>()
            for (r in members) {
                if (cancelled) return
                val digest = backend.hash(r, 1)
                hashedBytes.addAndGet(g.size)
                publish(false)
                if (digest == null) continue
                byFull.getOrPut(Native.hex(digest)) { ArrayList() }.add(r)
            }
            for ((fullDigest, same) in byFull) {
                if (same.size >= 2) save(g.size, fullDigest, same)
            }
        }
    }

    private fun save(size: Long, digest: String, members: List<FileRef>) {
        val ids = ArrayList<Long>()
        for (m in members) {
            if (m.nodeId >= 0L) ids.add(m.nodeId)
        }
        if (ids.size < 2) return
        db.addDupGroup(size, digest, ids)
        groups.incrementAndGet()
        wasted.addAndGet(size * (ids.size - 1).toLong())
        publish(true)
    }

    private fun publish(force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPublish.get() < 200L) return
        lastPublish.set(now)
        ui = DupUi(
            phase = DupPhase.Running,
            candidates = candidates,
            checked = checked.get(),
            groups = groups.get(),
            wasted = wasted.get(),
            hashedBytes = hashedBytes.get(),
        )
    }

    private companion object {
        /** Must match SAMPLE_THRESHOLD in rust/src/hash.rs (3 x 32 KiB). */
        const val SMALL_FILE = 3L * 32L * 1024L
    }
}
