package com.storagemap3d.app.core

import android.os.Environment
import android.os.StatFs

/** File categories. The numeric ids match category.rs in the Rust crate. */
object Cat {
    const val OTHER = 0
    const val IMAGE = 1
    const val VIDEO = 2
    const val AUDIO = 3
    const val DOC = 4
    const val ARCHIVE = 5
    const val APP = 6
    const val COUNT = 7

    /** Display order, largest-interest first. */
    val order: IntArray = intArrayOf(IMAGE, VIDEO, AUDIO, DOC, ARCHIVE, APP, OTHER)

    fun label(c: Int): String = when (c) {
        IMAGE -> "Images"
        VIDEO -> "Video"
        AUDIO -> "Audio"
        DOC -> "Documents"
        ARCHIVE -> "Archives"
        APP -> "Apps"
        else -> "Other"
    }

    /** ARGB colour used by both the Compose UI and the OpenGL scene. */
    fun color(c: Int): Int = when (c) {
        IMAGE -> 0xFF4DA3FF.toInt()
        VIDEO -> 0xFF9B7BFF.toInt()
        AUDIO -> 0xFFFF6FA3.toInt()
        DOC -> 0xFF5BD6A6.toInt()
        ARCHIVE -> 0xFFFF7A59.toInt()
        APP -> 0xFF36D1DC.toInt()
        else -> 0xFF7C8DA3.toInt()
    }
}

object NodeFlags {
    /** The folder could not be read, so its contents (and emptiness) are unknown. */
    const val UNREADABLE = 1

    /** Android/data or Android/obb: protected by Android, deliberately not entered. */
    const val PROTECTED = 2

    /** Some folder below this one could not be read, so totals and emptiness are not guaranteed. */
    const val PARTIAL = 4
}

/** One row of the scan index. Folder sizes are recursive totals. */
data class NodeRow(
    val id: Long,
    val parent: Long,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val mtime: Long,
    val cat: Int,
    val files: Long,
    val dirs: Long,
    val flags: Int,
    val doc: String?,
)

/**
 * Something the user can act on. [key] is an absolute path in full-access mode and a Storage Access
 * Framework document id in limited mode. [size] is -1 when unknown (for example an unscanned folder).
 */
data class FileRef(
    val key: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val mtime: Long,
    val cat: Int,
    val nodeId: Long = -1L,
    val place: String = "",
)

data class VolumeStats(val total: Long, val free: Long) {
    val used: Long get() = (total - free).coerceAtLeast(0L)
    val usedFraction: Float
        get() = if (total <= 0L) 0f else (used.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
}

object Volume {
    /** Capacity and free space of the shared storage volume the app scans. */
    fun read(): VolumeStats {
        return try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            VolumeStats(total = st.totalBytes, free = st.availableBytes)
        } catch (e: Exception) {
            VolumeStats(0L, 0L)
        }
    }
}

data class ScanInfo(
    val id: Long,
    val root: String,
    val mode: String,
    val started: Long,
    val finished: Long,
    val files: Long,
    val dirs: Long,
    val bytes: Long,
    val restricted: Long,
    val errors: Long,
)

data class CatStat(val cat: Int, val files: Long, val bytes: Long)

data class FolderStat(val row: NodeRow, val own: Long)

data class HistoryPoint(val ts: Long, val total: Long, val used: Long, val free: Long, val scanned: Long)

data class DupGroup(val gid: Long, val size: Long, val count: Int)

data class SizeGroup(val size: Long, val count: Int)

enum class Phase { Idle, Scanning, Saving, Done, Cancelled, Failed }

data class ScanUi(
    val phase: Phase = Phase.Idle,
    val files: Long = 0L,
    val dirs: Long = 0L,
    val bytes: Long = 0L,
    val restricted: Long = 0L,
    val path: String = "",
    val message: String = "",
    val startedAt: Long = 0L,
)

enum class AccessMode { None, Full, Saf }
