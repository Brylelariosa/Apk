package com.storagemap3d.app.core

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Records free and used space once a day so the history chart has data even between scans. */
class SnapshotWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val db = Db.get(applicationContext)
            val v = Volume.read()
            if (v.total > 0L) {
                val scanned = db.rootNode()?.size ?: 0L
                db.addHistory(HistoryPoint(System.currentTimeMillis(), v.total, v.used, v.free, scanned))
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "storage-snapshot"

        fun apply(context: Context, enabled: Boolean) {
            val wm = WorkManager.getInstance(context.applicationContext)
            if (enabled) {
                val request = PeriodicWorkRequestBuilder<SnapshotWorker>(1, TimeUnit.DAYS).build()
                wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
            } else {
                wm.cancelUniqueWork(WORK_NAME)
            }
        }
    }
}
