package com.storagemap3d.app.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** One entry of a live directory listing returned by the Rust library. */
data class RawEntry(val kind: Int, val cat: Int, val size: Long, val mtime: Long, val name: String)

data class ScanStats(
    val state: Int,
    val files: Long,
    val dirs: Long,
    val bytes: Long,
    val restricted: Long,
    val errors: Long,
)

/**
 * JNI bridge to the Rust library (libvoxelsandbox.so, see rust/Cargo.toml for why it has that name).
 * The `external` functions must match the names in rust/src/jni_api.rs exactly.
 */
object Native {
    const val S_IDLE = 0
    const val S_RUNNING = 1
    const val S_DONE = 2
    const val S_CANCELLED = 3
    const val S_FAILED = 4

    const val KIND_FILE = 0
    const val KIND_DIR = 1
    const val KIND_TRUNCATED = 255

    @Volatile
    var loaded: Boolean = false
        private set

    init {
        loaded = try {
            System.loadLibrary("voxelsandbox")
            true
        } catch (t: Throwable) {
            false
        }
    }

    external fun version(): String
    external fun scanStart(root: String): Boolean
    external fun scanPoll(): ByteArray?
    external fun scanStats(): ByteArray?
    external fun scanCurrent(): String
    external fun scanCancel()
    external fun hashFile(path: String, mode: Int): ByteArray?
    external fun hashFd(fd: Int, mode: Int): ByteArray?
    external fun hashCancel(flag: Boolean)
    external fun listDir(path: String): ByteArray?
    external fun squarify(sizes: String, w: Float, h: Float): ByteArray?
    external fun classify(name: String): Int

    fun stats(): ScanStats? {
        val raw = scanStats() ?: return null
        if (raw.size < 48) return null
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        return ScanStats(
            state = bb.getLong().toInt(),
            files = bb.getLong(),
            dirs = bb.getLong(),
            bytes = bb.getLong(),
            restricted = bb.getLong(),
            errors = bb.getLong(),
        )
    }

    /** Treemap layout: returns x, y, w, h for each size, tiling a w by h rectangle. */
    fun layout(sizes: LongArray, w: Float, h: Float): FloatArray {
        if (sizes.isEmpty()) return FloatArray(0)
        val text = StringBuilder(sizes.size * 8)
        for (i in sizes.indices) {
            if (i > 0) text.append(',')
            text.append(sizes[i])
        }
        val raw = squarify(text.toString(), w, h) ?: return FloatArray(sizes.size * 4)
        val out = FloatArray(raw.size / 4)
        ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out)
        return out
    }

    /** Decode the packed entries of [listDir]. */
    fun decodeEntries(raw: ByteArray): List<RawEntry> {
        val out = ArrayList<RawEntry>()
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        while (bb.remaining() >= 20) {
            val kind = bb.get().toInt() and 0xFF
            val cat = bb.get().toInt() and 0xFF
            val size = bb.getLong()
            val mtime = bb.getLong()
            val n = bb.getShort().toInt() and 0xFFFF
            if (bb.remaining() < n) break
            val name = String(raw, bb.position(), n, Charsets.UTF_8)
            bb.position(bb.position() + n)
            out.add(RawEntry(kind, cat, size, mtime, name))
        }
        return out
    }

    fun hex(bytes: ByteArray): String {
        val digits = "0123456789abcdef"
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(digits[v shr 4])
            sb.append(digits[v and 15])
        }
        return sb.toString()
    }
}
