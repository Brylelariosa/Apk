package com.storagemap3d.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.FileRef

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    padding: Dp = 16.dp,
    container: Color = Pal.Panel,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    var m = modifier.clip(shape).background(container).border(1.dp, Pal.Line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(padding), content = content)
}

@Composable
fun ScreenHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    startPadding: Dp = 20.dp,
    trailing: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = startPadding, end = 8.dp, top = 14.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.Title, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Text(subtitle, style = Type.Small, color = Pal.Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, style = Type.Heading, color = Pal.Text)
}

enum class BtnKind { Primary, Secondary, Danger, Ghost }

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.Primary,
    enabled: Boolean = true,
    ico: Ico? = null,
) {
    val bg = when (kind) {
        BtnKind.Primary -> Pal.Amber
        BtnKind.Secondary -> Pal.Raised
        BtnKind.Danger -> Pal.DangerSoft
        BtnKind.Ghost -> Color.Transparent
    }
    val fg = when (kind) {
        BtnKind.Primary -> Pal.Ink
        BtnKind.Secondary -> Pal.Text
        BtnKind.Danger -> Pal.Danger
        BtnKind.Ghost -> Pal.Amber
    }
    val shape = RoundedCornerShape(12.dp)
    var m = modifier.heightIn(min = 46.dp).clip(shape)
    m = if (enabled) m.background(bg) else m.background(Pal.Raised)
    if (kind == BtnKind.Ghost) m = m.border(1.dp, Pal.Line, shape)
    m = m.clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(horizontal = 18.dp)
    val content = if (enabled) fg else Pal.Faint
    Row(m, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        if (ico != null) {
            IconMark(ico, tint = content, boxSize = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = Type.BodyStrong, color = content, maxLines = 1)
    }
}

@Composable
fun IconBtn(
    ico: Ico,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Pal.Dim,
    background: Color = Color.Transparent,
) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(background)
            .semantics { contentDescription = desc }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        IconMark(ico, tint = tint)
    }
}

@Composable
fun Chip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    dot: Color? = null,
) {
    val shape = RoundedCornerShape(50)
    val bg = if (selected) Pal.AmberSoft else Pal.Raised
    val fg = if (selected) Pal.Amber else Pal.Dim
    val outline = if (selected) Pal.Amber else Pal.Line
    Row(
        modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, outline, shape)
            .clickable(role = Role.Tab, onClick = onClick)
            .heightIn(min = 40.dp)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (dot != null) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
        }
        Text(label, style = Type.Label, color = fg, maxLines = 1)
    }
}

@Composable
fun Segmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier
            .clip(shape)
            .background(Pal.Raised)
            .border(1.dp, Pal.Line, shape)
            .padding(3.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 40.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (on) Pal.Panel else Color.Transparent)
                    .clickable(role = Role.Tab, onClick = { onSelect(i) }),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = Type.BodyStrong, color = if (on) Pal.Amber else Pal.Dim, maxLines = 1)
            }
        }
    }
}

/** Thin horizontal progress track. */
@Composable
fun Meter(fraction: Float, color: Color, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Canvas(modifier.fillMaxWidth().height(height)) {
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(Pal.Raised, cornerRadius = r)
        val w = size.width * fraction.coerceIn(0f, 1f)
        if (w > 0f) {
            val bar = if (w < size.height) size.height else w
            drawRoundRect(color, size = Size(bar, size.height), cornerRadius = r)
        }
    }
}

/** Horizontal bar split into coloured parts proportional to their first value. */
@Composable
fun StackBar(parts: List<Pair<Float, Color>>, modifier: Modifier = Modifier, height: Dp = 14.dp) {
    Canvas(modifier.fillMaxWidth().height(height)) {
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(Pal.Raised, cornerRadius = r)
        var total = 0f
        for (p in parts) total += p.first
        if (total <= 0f) return@Canvas
        val clip = Path()
        clip.addRoundRect(RoundRect(0f, 0f, size.width, size.height, r))
        val gap = 2.dp.toPx()
        clipPath(clip) {
            var x = 0f
            for (p in parts) {
                val w = size.width * p.first / total
                if (w > 0.5f) {
                    drawRect(p.second, topLeft = androidx.compose.ui.geometry.Offset(x, 0f), size = Size(if (w > gap) w - gap else w, size.height))
                }
                x += w
            }
        }
    }
}

enum class Tone { Info, Warn, Bad, Good }

@Composable
fun Notice(text: String, modifier: Modifier = Modifier, tone: Tone = Tone.Info, ico: Ico? = null) {
    val bg = when (tone) {
        Tone.Info -> Pal.Raised
        Tone.Warn -> Pal.AmberSoft
        Tone.Bad -> Pal.DangerSoft
        Tone.Good -> Pal.Raised
    }
    val fg = when (tone) {
        Tone.Info -> Pal.Dim
        Tone.Warn -> Pal.Amber
        Tone.Bad -> Pal.Danger
        Tone.Good -> Pal.Ok
    }
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (ico != null) {
            IconMark(ico, tint = fg, boxSize = 18.dp, modifier = Modifier.padding(top = 1.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, style = Type.Body, color = if (tone == Tone.Info) Pal.Dim else fg)
    }
}

@Composable
fun EmptyState(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = Type.Heading, color = Pal.Text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, style = Type.Body, color = Pal.Dim, textAlign = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(18.dp))
            action()
        }
    }
}

@Composable
fun FileTile(isDir: Boolean, cat: Int, modifier: Modifier = Modifier) {
    val base = if (isDir) Pal.Amber else Color(Cat.color(cat))
    Box(
        modifier
            .size(40.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(base.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        IconMark(if (isDir) Ico.Folder else Ico.File, tint = base, boxSize = 20.dp)
    }
}

@Composable
fun FileRow(
    ref: FileRef,
    subtitle: String,
    trailing: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onMore: (() -> Unit)? = null,
    highlighted: Boolean = false,
    leading: (@Composable () -> Unit)? = null,
) {
    val shape = RoundedCornerShape(14.dp)
    var m = modifier.fillMaxWidth().clip(shape)
    if (highlighted) m = m.background(Pal.AmberSoft)
    m = m.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp)
    Row(m, verticalAlignment = Alignment.CenterVertically) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(6.dp))
        }
        FileTile(ref.isDir, ref.cat)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ref.name, style = Type.BodyStrong, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = Type.Small, color = Pal.Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing.isNotEmpty()) {
            Spacer(Modifier.width(8.dp))
            Text(trailing, style = Type.Num, color = Pal.Text, maxLines = 1)
        }
        if (onMore != null) {
            IconBtn(Ico.More, "More actions", onMore)
        }
    }
}

@Composable
fun CheckMark(checked: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier
            .size(24.dp)
            .clip(shape)
            .background(if (checked) Pal.Amber else Color.Transparent)
            .border(1.5.dp, if (checked) Pal.Amber else Pal.Faint, shape),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) IconMark(Ico.Check, tint = Pal.Ink, boxSize = 16.dp)
    }
}

@Composable
fun SwitchRow(title: String, body: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Switch, onClick = { onChange(!checked) })
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.BodyStrong, color = Pal.Text)
            if (body != null) Text(body, style = Type.Small, color = Pal.Dim)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Pal.Ink,
                checkedTrackColor = Pal.Amber,
                checkedBorderColor = Pal.Amber,
                uncheckedThumbColor = Pal.Dim,
                uncheckedTrackColor = Pal.Raised,
                uncheckedBorderColor = Pal.Line,
            ),
        )
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    danger: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.Panel,
        titleContentColor = Pal.Text,
        textContentColor = Pal.Dim,
        shape = RoundedCornerShape(20.dp),
        title = { Text(title, style = Type.Heading) },
        text = { Text(message, style = Type.Body) },
        confirmButton = {
            AppButton(confirmText, onConfirm, kind = if (danger) BtnKind.Danger else BtnKind.Primary)
        },
        dismissButton = {
            AppButton("Cancel", onDismiss, kind = BtnKind.Ghost)
        },
    )
}
