package com.storagemap3d.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.storagemap3d.app.ui.AppRoot
import com.storagemap3d.app.ui.StorageMapTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        vm.onFolderPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StorageMapTheme {
                AppRoot(
                    vm = vm,
                    onGrantAll = { openAllFilesAccessSettings() },
                    onPickFolder = { pickFolder.launch(null) },
                )
            }
        }
    }

    /** Opens the "All files access" page for this app (Android 11+). */
    private fun openAllFilesAccessSettings() {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                vm.say("Open Android Settings, then Apps, Special app access, All files access.")
            }
        }
    }
}
