package com.storagemap3d.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.core.NodeRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun ActionRow(ico: Ico, label: String, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconMark(ico, tint = if (danger) Pal.Danger else Pal.Dim)
        Spacer(Modifier.width(14.dp))
        Text(label, style = Type.BodyStrong, color = if (danger) Pal.Danger else Pal.Text)
    }
}

/** What can be done with a file or folder that was picked from a list. */
@Composable
fun FileActionsDialog(vm: MainViewModel) {
    val ref = vm.actionTarget ?: return
    Dialog(
        onDismissRequest = { vm.actionTarget = null },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Panel(Modifier.fillMaxWidth(0.92f), padding = 8.dp) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                FileTile(ref.isDir, ref.cat)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(ref.name, style = Type.Heading, color = Pal.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val detail = buildString {
                        if (ref.size >= 0L) append(Fmt.bytes(ref.size))
                        if (ref.mtime > 0L) {
                            if (isNotEmpty()) append("  ·  ")
                            append(Fmt.ago(ref.mtime))
                        }
                    }
                    if (detail.isNotEmpty()) Text(detail, style = Type.Small, color = Pal.Dim)
                }
            }
            if (!ref.isDir) {
                ActionRow(Ico.Open, "Open") {
                    vm.openFile(ref)
                    vm.actionTarget = null
                }
                ActionRow(Ico.Share, "Share") {
                    vm.shareFile(ref)
                    vm.actionTarget = null
                }
            }
            ActionRow(Ico.Folder, "Show in Explorer") { vm.showInExplorer(ref) }
            ActionRow(Ico.Info, "Properties") { vm.showProperties(ref) }
            ActionRow(Ico.Trash, "Delete\u2026", danger = true) { vm.requestDelete(listOf(ref)) }
        }
    }
}

@Composable
private fun PropRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, Modifier.weight(0.34f), style = Type.Small, color = Pal.Dim)
        Text(value, Modifier.weight(0.66f), style = Type.Body, color = Pal.Text)
    }
}

@Composable
fun PropertiesDialog(vm: MainViewModel) {
    val ref = vm.propRef ?: return
    var node by remember(ref.key) { mutableStateOf<NodeRow?>(null) }
    LaunchedEffect(ref.key) {
        node = withContext(Dispatchers.IO) {
            val id = vm.backend.nodeIdFor(ref)
            if (id >= 0L) vm.db.node(id) else null
        }
    }
    val clipboard = LocalClipboardManager.current
    val hash = vm.propHash

    Dialog(
        onDismissRequest = { vm.closeProperties() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Panel(Modifier.fillMaxWidth(0.92f).heightIn(max = 560.dp), padding = 18.dp) {
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                Text("Properties", style = Type.Title, color = Pal.Text)
                Spacer(Modifier.height(10.dp))
                PropRow("Name", ref.name)
                val location = if (vm.access == AccessMode.Full) ref.key.substringBeforeLast('/', "") else ref.place
                if (location.isNotEmpty()) PropRow("Location", location)
                val type = if (ref.isDir) "Folder" else Cat.label(ref.cat) + "  ·  " + vm.backend.mimeFor(ref.name)
                PropRow("Type", type)
                if (ref.size >= 0L) {
                    val exact = String.format("%,d", ref.size)
                    PropRow("Size", Fmt.bytes(ref.size) + "  (" + exact + " bytes)")
                } else {
                    PropRow("Size", "Not measured yet. Scan storage to size folders.")
                }
                if (ref.mtime > 0L) PropRow("Modified", Fmt.date(ref.mtime) + "  ·  " + Fmt.ago(ref.mtime))
                val n = node
                if (ref.isDir && n != null) {
                    PropRow("Contents", Fmt.count(n.files) + " files, " + Fmt.count(n.dirs) + " folders (as of the last scan)")
                }
                if (!ref.isDir) {
                    Spacer(Modifier.height(12.dp))
                    if (hash == null) {
                        AppButton(
                            text = if (vm.propHashBusy) "Calculating\u2026" else "Calculate SHA-256",
                            onClick = { vm.computeHash() },
                            enabled = !vm.propHashBusy,
                            kind = BtnKind.Secondary,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        Text("SHA-256", style = Type.Small, color = Pal.Dim)
                        Text(hash, style = Type.Small, color = Pal.Text, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(8.dp))
                        AppButton(
                            text = "Copy checksum",
                            onClick = { clipboard.setText(AnnotatedString(hash)) },
                            kind = BtnKind.Secondary,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            AppButton("Close", { vm.closeProperties() }, kind = BtnKind.Ghost, modifier = Modifier.fillMaxWidth())
        }
    }
}

/** Shows the confirmation for a pending delete. Nothing is ever deleted without this step. */
@Composable
fun DeleteHost(vm: MainViewModel) {
    val req = vm.deleteRequest ?: return
    ConfirmDialog(
        title = req.title,
        message = req.message,
        confirmText = "Delete",
        danger = true,
        onConfirm = { vm.confirmDelete() },
        onDismiss = { vm.cancelDelete() },
    )
}
