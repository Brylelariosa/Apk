package com.storagemap3d.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.core.AccessMode

/** Shown instead of a screen that cannot work without storage access. */
@Composable
fun NeedAccess(title: String, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        EmptyState(
            title = title,
            body = "Allow \u201cAll files access\u201d so Storage Map 3D can measure your folders, or pick a single folder to work in limited mode. Everything stays on this device.",
            action = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AppButton("Allow all files access", onGrantAll, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    AppButton("Choose one folder instead", onPickFolder, Modifier.fillMaxWidth(), kind = BtnKind.Secondary)
                }
            },
        )
    }
}

/** Shown instead of a screen that needs scan results; also shows scan progress while one runs. */
@Composable
fun NeedScan(vm: MainViewModel, title: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (vm.scanner.busy) {
            Panel(Modifier.padding(16.dp)) {
                ScanProgress(vm.scanner.ui, onCancel = { vm.cancelScan() }, animate = !vm.reduceMotion)
            }
        } else {
            val stale = vm.summary.info != null && !vm.indexUsable
            EmptyState(
                title = title,
                body = if (stale) {
                    "The saved scan was made with different storage access. Scan again to refresh it."
                } else {
                    "Scan your storage once. The results stay on this device, so this screen opens instantly afterwards."
                },
                action = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (vm.access == AccessMode.None) {
                            Text0("Allow storage access on the Overview screen first.")
                        } else {
                            AppButton(
                                if (stale) "Scan again" else "Scan storage",
                                { vm.startScan() },
                                Modifier.fillMaxWidth(),
                                ico = Ico.Play,
                            )
                        }
                    }
                },
            )
        }
    }
}

@Composable
private fun Text0(text: String) {
    androidx.compose.material3.Text(text, style = Type.Small, color = Pal.Faint)
}
