package com.storagemap3d.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Line icons drawn with the canvas, so the app needs no icon libraries or emoji. */
enum class Ico {
    Overview, Map, Folder, Chart, Settings, File, Search, Sort, Filter, Share, Trash, Info, Open,
    Back, Up, Close, Check, Warning, Copy, Clock, Pie, Play, Stop, Plus, Minus, Target, Lock,
    Chevron, More,
}

@Composable
fun IconMark(ico: Ico, modifier: Modifier = Modifier, tint: Color = Pal.Dim, boxSize: Dp = 22.dp) {
    Canvas(modifier.size(boxSize)) {
        val u = this.size.minDimension / 24f
        drawIco(ico, tint, u)
    }
}

private fun DrawScope.line(c: Color, u: Float, w: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
    drawLine(c, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w * u, cap = StrokeCap.Round)
}

private fun DrawScope.poly(c: Color, u: Float, w: Float, closed: Boolean, vararg p: Float) {
    val path = Path()
    path.moveTo(p[0] * u, p[1] * u)
    var i = 2
    while (i + 1 < p.size) {
        path.lineTo(p[i] * u, p[i + 1] * u)
        i += 2
    }
    if (closed) path.close()
    drawPath(path, c, style = Stroke(width = w * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.ring(c: Color, u: Float, w: Float, cx: Float, cy: Float, r: Float) {
    drawCircle(c, radius = r * u, center = Offset(cx * u, cy * u), style = Stroke(width = w * u))
}

private fun DrawScope.dot(c: Color, u: Float, cx: Float, cy: Float, r: Float) {
    drawCircle(c, radius = r * u, center = Offset(cx * u, cy * u))
}

private fun DrawScope.box(c: Color, u: Float, w: Float, x: Float, y: Float, bw: Float, bh: Float, round: Float) {
    drawRoundRect(
        c,
        topLeft = Offset(x * u, y * u),
        size = Size(bw * u, bh * u),
        cornerRadius = CornerRadius(round * u),
        style = Stroke(width = w * u),
    )
}

private fun DrawScope.drawIco(ico: Ico, c: Color, u: Float) {
    val w = 1.8f
    when (ico) {
        Ico.Overview -> {
            box(c, u, w, 3.5f, 3.5f, 7f, 7f, 1.8f)
            box(c, u, w, 13.5f, 3.5f, 7f, 7f, 1.8f)
            box(c, u, w, 3.5f, 13.5f, 7f, 7f, 1.8f)
            box(c, u, w, 13.5f, 13.5f, 7f, 7f, 1.8f)
        }
        Ico.Map -> {
            poly(c, u, w, true, 12f, 2.8f, 20f, 7.4f, 20f, 16.6f, 12f, 21.2f, 4f, 16.6f, 4f, 7.4f)
            poly(c, u, w, false, 4f, 7.4f, 12f, 12f, 20f, 7.4f)
            line(c, u, w, 12f, 12f, 12f, 21.2f)
        }
        Ico.Folder -> poly(c, u, w, true, 3f, 6.5f, 9f, 6.5f, 11.5f, 9f, 21f, 9f, 21f, 19f, 3f, 19f)
        Ico.Chart -> {
            line(c, u, 2.6f, 6f, 20f, 6f, 12f)
            line(c, u, 2.6f, 12f, 20f, 12f, 5f)
            line(c, u, 2.6f, 18f, 20f, 18f, 9.5f)
        }
        Ico.Settings -> {
            line(c, u, w, 4f, 6f, 20f, 6f)
            line(c, u, w, 4f, 12f, 20f, 12f)
            line(c, u, w, 4f, 18f, 20f, 18f)
            dot(c, u, 9f, 6f, 2.5f)
            dot(c, u, 15f, 12f, 2.5f)
            dot(c, u, 8f, 18f, 2.5f)
        }
        Ico.File -> {
            poly(c, u, w, true, 6f, 3f, 14f, 3f, 19f, 8f, 19f, 21f, 6f, 21f)
            poly(c, u, w, false, 14f, 3f, 14f, 8f, 19f, 8f)
        }
        Ico.Search -> {
            ring(c, u, w, 10.5f, 10.5f, 6.5f)
            line(c, u, w, 15.4f, 15.4f, 21f, 21f)
        }
        Ico.Sort -> {
            line(c, u, w, 4f, 7f, 20f, 7f)
            line(c, u, w, 4f, 12f, 15f, 12f)
            line(c, u, w, 4f, 17f, 10f, 17f)
        }
        Ico.Filter -> poly(c, u, w, true, 3f, 5f, 21f, 5f, 14f, 12.5f, 14f, 19.5f, 10f, 17.5f, 10f, 12.5f)
        Ico.Share -> {
            ring(c, u, w, 18f, 5.5f, 2.6f)
            ring(c, u, w, 6f, 12f, 2.6f)
            ring(c, u, w, 18f, 18.5f, 2.6f)
            line(c, u, w, 8.3f, 10.8f, 15.7f, 6.7f)
            line(c, u, w, 8.3f, 13.2f, 15.7f, 17.3f)
        }
        Ico.Trash -> {
            line(c, u, w, 4f, 7f, 20f, 7f)
            poly(c, u, w, false, 9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f)
            poly(c, u, w, false, 6f, 7f, 7f, 20.5f, 17f, 20.5f, 18f, 7f)
            line(c, u, w, 10f, 11f, 10f, 17f)
            line(c, u, w, 14f, 11f, 14f, 17f)
        }
        Ico.Info -> {
            ring(c, u, w, 12f, 12f, 9f)
            line(c, u, w, 12f, 11f, 12f, 17f)
            dot(c, u, 12f, 7.6f, 1.2f)
        }
        Ico.Open -> {
            poly(c, u, w, false, 10f, 5f, 5f, 5f, 5f, 19f, 19f, 19f, 19f, 14f)
            line(c, u, w, 12f, 12f, 21f, 3f)
            poly(c, u, w, false, 15f, 3f, 21f, 3f, 21f, 9f)
        }
        Ico.Back -> {
            line(c, u, w, 20f, 12f, 5f, 12f)
            poly(c, u, w, false, 11f, 6f, 5f, 12f, 11f, 18f)
        }
        Ico.Up -> poly(c, u, w, false, 6f, 15f, 12f, 9f, 18f, 15f)
        Ico.Close -> {
            line(c, u, w, 6f, 6f, 18f, 18f)
            line(c, u, w, 18f, 6f, 6f, 18f)
        }
        Ico.Check -> poly(c, u, w, false, 5f, 12.5f, 10f, 17.5f, 19f, 7f)
        Ico.Warning -> {
            poly(c, u, w, true, 12f, 3.5f, 21.5f, 20f, 2.5f, 20f)
            line(c, u, w, 12f, 9.5f, 12f, 14.5f)
            dot(c, u, 12f, 17.2f, 1.2f)
        }
        Ico.Copy -> {
            box(c, u, w, 8.5f, 8.5f, 11f, 11f, 2f)
            poly(c, u, w, false, 15.5f, 8.5f, 15.5f, 5.5f, 5.5f, 5.5f, 5.5f, 15.5f, 8.5f, 15.5f)
        }
        Ico.Clock -> {
            ring(c, u, w, 12f, 12f, 9f)
            poly(c, u, w, false, 12f, 7f, 12f, 12f, 15.5f, 14f)
        }
        Ico.Pie -> {
            ring(c, u, w, 12f, 12f, 9f)
            line(c, u, w, 12f, 12f, 12f, 3f)
            line(c, u, w, 12f, 12f, 19.8f, 16.5f)
        }
        Ico.Play -> poly(c, u, w, true, 7f, 4.5f, 19.5f, 12f, 7f, 19.5f)
        Ico.Stop -> box(c, u, w, 6.5f, 6.5f, 11f, 11f, 1.5f)
        Ico.Plus -> {
            line(c, u, w, 12f, 5f, 12f, 19f)
            line(c, u, w, 5f, 12f, 19f, 12f)
        }
        Ico.Minus -> line(c, u, w, 5f, 12f, 19f, 12f)
        Ico.Target -> {
            ring(c, u, w, 12f, 12f, 5.5f)
            line(c, u, w, 12f, 2.5f, 12f, 6f)
            line(c, u, w, 12f, 18f, 12f, 21.5f)
            line(c, u, w, 2.5f, 12f, 6f, 12f)
            line(c, u, w, 18f, 12f, 21.5f, 12f)
        }
        Ico.Lock -> {
            box(c, u, w, 5f, 11f, 14f, 9.5f, 2f)
            drawArc(
                c,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(8f * u, 4.5f * u),
                size = Size(8f * u, 8f * u),
                style = Stroke(width = w * u, cap = StrokeCap.Round),
            )
            line(c, u, w, 8f, 8.5f, 8f, 11f)
            line(c, u, w, 16f, 8.5f, 16f, 11f)
        }
        Ico.Chevron -> poly(c, u, w, false, 9f, 6f, 15f, 12f, 9f, 18f)
        Ico.More -> {
            dot(c, u, 5f, 12f, 1.7f)
            dot(c, u, 12f, 12f, 1.7f)
            dot(c, u, 19f, 12f, 1.7f)
        }
        else -> {}
    }
}
