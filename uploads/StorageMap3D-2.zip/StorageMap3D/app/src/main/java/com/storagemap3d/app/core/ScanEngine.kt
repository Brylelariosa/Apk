package com.storagemap3d.app.core

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Walks a Storage Access Framework tree (limited mode) and writes the same node rows the Rust scanner
 * produces. Much slower than the native scanner because every folder is a content-provider query,
 * but it works without "All files access".
 */
class SafScanner(
    private val resolver: ContentResolver,
    private val tree: Uri,
    private val db: Db,
    private val isCancelled: () -> Boolean,
    private val progress: (Long, Long, Long, Long, String) -> Unit,
) {
    enum class Result { Done, Cancelled, Failed }

    private class Frame(
        val id: Long,
        val parent: Long,
        val doc: String,
        val name: String,
        val mtime: Long,
        val kids: List<SafEntry>,
    ) {
        var next = 0
        var size = 0L
        var files = 0L
        var dirs = 0L
        var flags = 0
    }

    var files = 0L
        private set
    var dirs = 0L
        private set
    var bytes = 0L
        private set
    var restricted = 0L
        private set

    fun run(rootName: String): Result {
        val rootDoc = DocumentsContract.getTreeDocumentId(tree)
        val rootKids = SafTree.children(resolver, tree, rootDoc) ?: return Result.Failed
        val pending = ArrayList<NodeRow>(BATCH)
        val stack = ArrayList<Frame>()
        var nextId = 1L
        var lastReport = 0L
        stack.add(Frame(0L, -1L, rootDoc, rootName, 0L, rootKids))

        while (stack.isNotEmpty()) {
            if (isCancelled()) return Result.Cancelled
            val top = stack[stack.size - 1]
            if (top.next < top.kids.size) {
                val k = top.kids[top.next]
                top.next++
                val id = nextId
                nextId++
                if (k.isDir) {
                    val kids = SafTree.children(resolver, tree, k.docId)
                    if (kids == null) {
                        restricted++
                        dirs++
                        pending.add(
                            NodeRow(id, top.id, k.name, true, 0L, k.mtime, 0, 0L, 0L, NodeFlags.UNREADABLE, k.docId)
                        )
                        top.dirs++
                        top.flags = top.flags or NodeFlags.PARTIAL
                    } else {
                        stack.add(Frame(id, top.id, k.docId, k.name, k.mtime, kids))
                    }
                } else {
                    val cat = if (Native.loaded) Native.classify(k.name) else 0
                    pending.add(NodeRow(id, top.id, k.name, false, k.size, k.mtime, cat, 0L, 0L, 0, k.docId))
                    top.size += k.size
                    top.files++
                    files++
                    bytes += k.size
                }
            } else {
                stack.removeAt(stack.size - 1)
                pending.add(
                    NodeRow(top.id, top.parent, top.name, true, top.size, top.mtime, 0, top.files, top.dirs, top.flags, top.doc)
                )
                dirs++
                if (stack.isNotEmpty()) {
                    val p = stack[stack.size - 1]
                    p.size += top.size
                    p.files += top.files
                    p.dirs += top.dirs + 1L
                    if ((top.flags and (NodeFlags.UNREADABLE or NodeFlags.PARTIAL)) != 0) {
                        p.flags = p.flags or NodeFlags.PARTIAL
                    }
                }
            }
            if (pending.size >= BATCH) {
                db.stageMany(pending)
                pending.clear()
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastReport > 200L) {
                lastReport = now
                progress(files, dirs, bytes, restricted, top.name)
            }
        }
        if (pending.isNotEmpty()) db.stageMany(pending)
        return Result.Done
    }

    private companion object {
        const val BATCH = 1000
    }
}

/**
 * Runs scans on a background coroutine and exposes their progress as Compose state. The Rust scanner
 * streams records that are written straight into a staging table; the finished scan replaces the
 * live index in one transaction, so cancelling never loses earlier results.
 */
class ScanEngine(
    private val app: Application,
    private val db: Db,
    private val backend: Backend,
    private val scope: CoroutineScope,
    private val onFinished: () -> Unit,
) {
    var ui by mutableStateOf(ScanUi())
        private set

    @Volatile
    private var cancelRequested = false
    private var job: Job? = null

    val busy: Boolean
        get() = ui.phase == Phase.Scanning || ui.phase == Phase.Saving

    fun start() {
        if (busy) return
        when (backend.refresh()) {
            AccessMode.Full -> startFull()
            AccessMode.Saf -> startSaf()
            AccessMode.None -> ui = ScanUi(phase = Phase.Failed, message = "Allow storage access first.")
        }
    }

    fun cancel() {
        if (!busy) return
        cancelRequested = true
        if (Native.loaded) Native.scanCancel()
    }

    fun dismissMessage() {
        if (!busy) ui = ScanUi()
    }

    private fun failed(message: String, startedAt: Long): ScanUi =
        ScanUi(phase = Phase.Failed, message = message, startedAt = startedAt)

    private fun recordSnapshot(scannedBytes: Long) {
        val v = Volume.read()
        db.addHistory(HistoryPoint(System.currentTimeMillis(), v.total, v.used, v.free, scannedBytes))
    }

    // ------------------------------------------------------------------------------------------
    // Full access: Rust scanner
    // ------------------------------------------------------------------------------------------

    private fun startFull() {
        if (!Native.loaded) {
            ui = failed("The native scanner library could not be loaded on this device.", 0L)
            return
        }
        cancelRequested = false
        val root = backend.rootPath()
        val startedAt = System.currentTimeMillis()
        ui = ScanUi(phase = Phase.Scanning, path = root, startedAt = startedAt)

        job = scope.launch(Dispatchers.IO) {
            var finished = false
            try {
                db.beginStage()
                if (!Native.scanStart(root)) {
                    throw IllegalStateException("A scan is already running.")
                }
                var lastPublish = 0L
                while (true) {
                    val batch = Native.scanPoll()
                    if (batch != null) {
                        if (batch.isEmpty()) break
                        if (!cancelRequested) db.ingestNative(batch)
                    }
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastPublish >= 150L) {
                        lastPublish = now
                        publishNative()
                    }
                }

                val st = Native.stats()
                if (cancelRequested || st == null || st.state == Native.S_CANCELLED) {
                    db.dropStage()
                    ui = ScanUi(
                        phase = Phase.Cancelled,
                        files = ui.files,
                        dirs = ui.dirs,
                        bytes = ui.bytes,
                        startedAt = startedAt,
                        message = "Scan cancelled. Your previous results were kept.",
                    )
                } else if (st.state != Native.S_DONE) {
                    db.dropStage()
                    ui = failed("The storage folder could not be scanned.", startedAt)
                } else {
                    ui = ui.copy(
                        phase = Phase.Saving,
                        files = st.files,
                        dirs = st.dirs,
                        bytes = st.bytes,
                        restricted = st.restricted,
                    )
                    val finishedAt = System.currentTimeMillis()
                    db.commitStage(
                        ScanInfo(0L, root, "full", startedAt, finishedAt, st.files, st.dirs, st.bytes, st.restricted, st.errors)
                    )
                    recordSnapshot(st.bytes)
                    ui = ui.copy(phase = Phase.Done, message = "")
                    finished = true
                }
            } catch (t: Throwable) {
                drainNative()
                db.dropStage()
                ui = failed(t.message ?: "The scan stopped unexpectedly.", startedAt)
            }
            if (finished) {
                withContext(Dispatchers.Main) { onFinished() }
            }
        }
    }

    private fun publishNative() {
        if (ui.phase != Phase.Scanning) return
        val st = Native.stats() ?: return
        ui = ui.copy(
            files = st.files,
            dirs = st.dirs,
            bytes = st.bytes,
            restricted = st.restricted,
            path = Native.scanCurrent(),
        )
    }

    /** After an error: stop the native thread and empty its queue so it can finish. */
    private fun drainNative() {
        try {
            Native.scanCancel()
            var guard = 0
            while (guard < 400) {
                val b = Native.scanPoll()
                if (b != null && b.isEmpty()) break
                guard++
            }
        } catch (t: Throwable) {
            // Nothing else to do.
        }
    }

    // ------------------------------------------------------------------------------------------
    // Limited mode: Storage Access Framework
    // ------------------------------------------------------------------------------------------

    private fun startSaf() {
        val tree = backend.treeUri()
        if (tree == null) {
            ui = failed("No folder selected.", 0L)
            return
        }
        cancelRequested = false
        val startedAt = System.currentTimeMillis()
        val rootName = backend.rootLabel()
        ui = ScanUi(phase = Phase.Scanning, path = rootName, startedAt = startedAt)

        job = scope.launch(Dispatchers.IO) {
            var finished = false
            try {
                db.beginStage()
                val scanner = SafScanner(
                    resolver = app.contentResolver,
                    tree = tree,
                    db = db,
                    isCancelled = { cancelRequested },
                    progress = { f, d, b, r, p ->
                        ui = ui.copy(files = f, dirs = d, bytes = b, restricted = r, path = p)
                    },
                )
                val result = scanner.run(rootName)
                if (result == SafScanner.Result.Cancelled) {
                    db.dropStage()
                    ui = ScanUi(
                        phase = Phase.Cancelled,
                        files = scanner.files,
                        dirs = scanner.dirs,
                        bytes = scanner.bytes,
                        startedAt = startedAt,
                        message = "Scan cancelled. Your previous results were kept.",
                    )
                } else if (result == SafScanner.Result.Failed) {
                    db.dropStage()
                    ui = failed("That folder can't be read. Pick it again from the system folder picker.", startedAt)
                } else {
                    ui = ui.copy(
                        phase = Phase.Saving,
                        files = scanner.files,
                        dirs = scanner.dirs,
                        bytes = scanner.bytes,
                        restricted = scanner.restricted,
                    )
                    // For limited-mode scans `root` holds the tree URI, so a different picked folder is detected.
                    db.commitStage(
                        ScanInfo(
                            0L, tree.toString(), "saf", startedAt, System.currentTimeMillis(),
                            scanner.files, scanner.dirs, scanner.bytes, scanner.restricted, 0L,
                        )
                    )
                    recordSnapshot(scanner.bytes)
                    ui = ui.copy(phase = Phase.Done, message = "")
                    finished = true
                }
            } catch (t: Throwable) {
                db.dropStage()
                ui = failed(t.message ?: "The scan stopped unexpectedly.", startedAt)
            }
            if (finished) {
                withContext(Dispatchers.Main) { onFinished() }
            }
        }
    }
}
