package com.storagemap3d.app.gl

import android.opengl.Matrix
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.Db
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.core.Native
import com.storagemap3d.app.core.NodeRow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Floats per drawn box: x, z, w, d | y0, h, highlight, animate | r, g, b, a. */
const val FLOATS_PER_INSTANCE = 12

object PickKind {
    const val GROUND = 0
    const val CONTAINER = 1
    const val FILE = 2
    const val FOLDER = 3
    const val OTHER = 4
}

/** What a drawn box stands for. [nodeId] is -1 for the ground and for grouped "smaller items". */
class PickInfo(val nodeId: Long, val kind: Int, val label: String)

/** A text label anchored to a point above a box. Higher [priority] wins when labels overlap. */
class LabelInfo(
    val nodeId: Long,
    val x: Float,
    val y: Float,
    val z: Float,
    val halfW: Float,
    val halfD: Float,
    val name: String,
    val sizeText: String,
    val priority: Float,
    val minPx: Float,
)

class SceneData(
    val focusId: Long,
    val focusSize: Long,
    val extent: Float,
    val data: FloatArray,
    val count: Int,
    val picks: Array<PickInfo>,
    val labels: List<LabelInfo>,
    val shownItems: Int,
    val totalItems: Int,
) {
    /** Highlight every box that belongs to [nodeId] (pass -1 to clear). */
    fun setSelected(nodeId: Long) {
        for (i in 0 until count) {
            val p = picks[i]
            val on = nodeId >= 0L && p.nodeId == nodeId && p.kind != PickKind.GROUND
            data[i * FLOATS_PER_INSTANCE + 6] = if (on) 1f else 0f
        }
    }
}

/**
 * Builds the 3D scene for one folder: its children are laid out as a squarified treemap on the
 * ground, every sub-folder becomes a container (floor plus four walls) and the largest items inside
 * it are placed in a second treemap. Deeper levels are reached by opening a folder, which keeps the
 * number of drawn boxes small (level of detail).
 */
object SceneBuilder {
    const val WORLD = 100f
    private const val FLOOR_H = 0.6f
    private const val WALL_H = 3.4f
    private const val GAP_TOP = 0.35f
    private const val GAP_IN = 0.18f

    private val GROUND = 0xFF0F1D2C.toInt()
    private val FLOOR = 0xFF17293B.toInt()
    private val WALL = 0xFF35536F.toInt()
    private val TILE = 0xFF4F6B89.toInt()
    private val CAP = 0xFF86A5C6.toInt()
    private val OTHER_BLOCK = 0xFF2A3B4F.toInt()

    private class Builder {
        var data = FloatArray(1024 * FLOATS_PER_INSTANCE)
        var n = 0
        val picks = ArrayList<PickInfo>()

        fun add(x: Float, z: Float, w: Float, d: Float, y0: Float, h: Float, color: Int, animate: Boolean, pick: PickInfo) {
            if ((n + 1) * FLOATS_PER_INSTANCE > data.size) data = data.copyOf(data.size * 2)
            val o = n * FLOATS_PER_INSTANCE
            data[o] = x
            data[o + 1] = z
            data[o + 2] = w
            data[o + 3] = d
            data[o + 4] = y0
            data[o + 5] = h
            data[o + 6] = 0f
            data[o + 7] = if (animate) 1f else 0f
            data[o + 8] = ((color shr 16) and 255) / 255f
            data[o + 9] = ((color shr 8) and 255) / 255f
            data[o + 10] = (color and 255) / 255f
            data[o + 11] = 1f
            picks.add(pick)
            n++
        }
    }

    private class Plan(
        val node: NodeRow,
        val x: Float,
        val z: Float,
        val w: Float,
        val d: Float,
        val container: Boolean,
        val kids: List<NodeRow>,
        val restBytes: Long,
    )

    fun build(db: Db, focusId: Long, quality: Int): SceneData? {
        val focus = db.node(focusId) ?: return null
        val maxTop = when (quality) {
            0 -> 22
            2 -> 48
            else -> 34
        }
        val maxInner = when (quality) {
            0 -> 8
            2 -> 22
            else -> 14
        }

        val top = db.children(focusId, maxTop)
        val totalItems = db.childCount(focusId).toInt()
        val b = Builder()
        val labels = ArrayList<LabelInfo>()
        b.add(-6f, -6f, WORLD + 12f, WORLD + 12f, -0.6f, 0.6f, GROUND, false, PickInfo(-1L, PickKind.GROUND, ""))
        if (top.isEmpty()) {
            return SceneData(focusId, focus.size, WORLD, b.data, b.n, b.picks.toTypedArray(), labels, 0, 0)
        }

        var shownBytes = 0L
        for (n in top) shownBytes += n.size
        val rest = max(focus.size - shownBytes, 0L)
        val hasOther = rest > 0L && rest.toDouble() / max(focus.size, 1L).toDouble() >= 0.01
        val count = top.size + (if (hasOther) 1 else 0)
        val sizes = LongArray(count)
        for (i in 0 until count) sizes[i] = if (i < top.size) top[i].size else rest
        val rects = Native.layout(sizes, WORLD, WORLD)

        // Phase 1: decide what each top-level rectangle becomes and load the contents of containers.
        val plans = ArrayList<Plan>()
        var maxFile = 1L
        var maxTile = 1L
        for (i in top.indices) {
            val node = top[i]
            val gx = rects[i * 4] + GAP_TOP
            val gz = rects[i * 4 + 1] + GAP_TOP
            val gw = rects[i * 4 + 2] - 2f * GAP_TOP
            val gd = rects[i * 4 + 3] - 2f * GAP_TOP
            if (gw < 0.9f || gd < 0.9f) continue
            val container = node.isDir && gw >= 5f && gd >= 5f
            var kids: List<NodeRow> = emptyList()
            var restBytes = 0L
            if (container) {
                val share = (gw * gd) / (WORLD * WORLD)
                val limit = (sqrt(share) * 60f).toInt().coerceIn(4, maxInner)
                kids = db.children(node.id, limit)
                var s = 0L
                for (k in kids) {
                    s += k.size
                    if (k.isDir) maxTile = max(maxTile, k.size) else maxFile = max(maxFile, k.size)
                }
                restBytes = max(node.size - s, 0L)
            } else if (!node.isDir) {
                maxFile = max(maxFile, node.size)
            } else {
                maxTile = max(maxTile, node.size)
            }
            plans.add(Plan(node, gx, gz, gw, gd, container, kids, restBytes))
        }

        fun fileHeight(size: Long): Float = 0.9f + 8.5f * sqrt(size.toFloat() / maxFile.toFloat())
        fun tileHeight(size: Long): Float = 1.2f + 4.2f * sqrt(size.toFloat() / maxTile.toFloat())

        // Phase 2: emit boxes and labels.
        for (p in plans) {
            val node = p.node
            val area = p.w * p.d
            if (!node.isDir) {
                val h = 1.2f + 10f * sqrt(node.size.toFloat() / maxFile.toFloat())
                b.add(p.x, p.z, p.w, p.d, 0f, h, Cat.color(node.cat), true, PickInfo(node.id, PickKind.FILE, node.name))
                labels.add(LabelInfo(node.id, p.x + p.w / 2f, h + 0.1f, p.z + p.d / 2f, p.w / 2f, p.d / 2f, node.name, Fmt.bytes(node.size), area, 64f))
                continue
            }
            if (!p.container) {
                val h = tileHeight(node.size)
                b.add(p.x, p.z, p.w, p.d, 0f, h, TILE, true, PickInfo(node.id, PickKind.FOLDER, node.name))
                labels.add(LabelInfo(node.id, p.x + p.w / 2f, h + 0.1f, p.z + p.d / 2f, p.w / 2f, p.d / 2f, node.name, Fmt.bytes(node.size), area, 64f))
                continue
            }

            // Container: floor and four walls, all selecting the folder.
            val pick = PickInfo(node.id, PickKind.CONTAINER, node.name)
            val t = (min(p.w, p.d) * 0.07f).coerceIn(0.35f, 1.1f)
            b.add(p.x, p.z, p.w, p.d, 0f, FLOOR_H, FLOOR, false, pick)
            b.add(p.x, p.z, p.w, t, 0f, WALL_H, WALL, true, pick)
            b.add(p.x, p.z + p.d - t, p.w, t, 0f, WALL_H, WALL, true, pick)
            b.add(p.x, p.z + t, t, p.d - 2f * t, 0f, WALL_H, WALL, true, pick)
            b.add(p.x + p.w - t, p.z + t, t, p.d - 2f * t, 0f, WALL_H, WALL, true, pick)
            labels.add(
                LabelInfo(node.id, p.x + p.w / 2f, WALL_H + 0.1f, p.z + p.d / 2f, p.w / 2f, p.d / 2f, node.name, Fmt.bytes(node.size), 10000f + area, 70f)
            )

            val inX = p.x + t
            val inZ = p.z + t
            val inW = p.w - 2f * t
            val inD = p.d - 2f * t
            val showRest = p.restBytes > 0L && p.restBytes.toDouble() / max(node.size, 1L).toDouble() >= 0.02
            val n = p.kids.size + (if (showRest) 1 else 0)
            if (n == 0 || inW <= 0.5f || inD <= 0.5f) continue
            val ks = LongArray(n)
            for (j in 0 until n) ks[j] = if (j < p.kids.size) p.kids[j].size else p.restBytes
            val r = Native.layout(ks, inW, inD)
            for (j in 0 until n) {
                val px = inX + r[j * 4] + GAP_IN
                val pz = inZ + r[j * 4 + 1] + GAP_IN
                val pw = r[j * 4 + 2] - 2f * GAP_IN
                val pd = r[j * 4 + 3] - 2f * GAP_IN
                if (pw < 0.45f || pd < 0.45f) continue
                if (j >= p.kids.size) {
                    b.add(px, pz, pw, pd, FLOOR_H, 0.8f, OTHER_BLOCK, true, PickInfo(-1L, PickKind.OTHER, "Smaller items"))
                    continue
                }
                val k = p.kids[j]
                val kArea = pw * pd
                if (k.isDir) {
                    val h = tileHeight(k.size)
                    val kp = PickInfo(k.id, PickKind.FOLDER, k.name)
                    b.add(px, pz, pw, pd, FLOOR_H, h, TILE, true, kp)
                    var topY = FLOOR_H + h
                    if (pw > 1.6f && pd > 1.6f) {
                        b.add(px + pw * 0.18f, pz + pd * 0.18f, pw * 0.64f, pd * 0.64f, topY, 0.35f, CAP, true, kp)
                        topY += 0.35f
                    }
                    if (kArea >= 6f) {
                        labels.add(LabelInfo(k.id, px + pw / 2f, topY + 0.1f, pz + pd / 2f, pw / 2f, pd / 2f, k.name, Fmt.bytes(k.size), kArea, 60f))
                    }
                } else {
                    val h = fileHeight(k.size)
                    b.add(px, pz, pw, pd, FLOOR_H, h, Cat.color(k.cat), true, PickInfo(k.id, PickKind.FILE, k.name))
                    if (kArea >= 6f) {
                        labels.add(LabelInfo(k.id, px + pw / 2f, FLOOR_H + h + 0.1f, pz + pd / 2f, pw / 2f, pd / 2f, k.name, Fmt.bytes(k.size), kArea, 60f))
                    }
                }
            }
        }

        if (hasOther) {
            val i = top.size
            val gx = rects[i * 4] + GAP_TOP
            val gz = rects[i * 4 + 1] + GAP_TOP
            val gw = rects[i * 4 + 2] - 2f * GAP_TOP
            val gd = rects[i * 4 + 3] - 2f * GAP_TOP
            if (gw > 0.9f && gd > 0.9f) {
                b.add(gx, gz, gw, gd, 0f, 0.9f, OTHER_BLOCK, true, PickInfo(-1L, PickKind.OTHER, "Smaller items"))
            }
        }

        labels.sortByDescending { it.priority }
        val capped: List<LabelInfo> = if (labels.size > 90) labels.subList(0, 90) else labels
        return SceneData(focusId, focus.size, WORLD, b.data, b.n, b.picks.toTypedArray(), capped, top.size, totalItems)
    }
}

/** Ray casting against the boxes of a scene (tapping an object). */
object Picker {
    /** Index of the nearest pickable box under the screen point, or -1. */
    fun pick(scene: SceneData, vp: FloatArray, sx: Float, sy: Float, w: Int, h: Int): Int {
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, vp, 0)) return -1
        val nx = 2f * sx / w - 1f
        val ny = 1f - 2f * sy / h
        val a = FloatArray(4)
        val c = FloatArray(4)
        Matrix.multiplyMV(a, 0, inv, 0, floatArrayOf(nx, ny, -1f, 1f), 0)
        Matrix.multiplyMV(c, 0, inv, 0, floatArrayOf(nx, ny, 1f, 1f), 0)
        if (a[3] == 0f || c[3] == 0f) return -1
        val ox = a[0] / a[3]
        val oy = a[1] / a[3]
        val oz = a[2] / a[3]
        var dx = c[0] / c[3] - ox
        var dy = c[1] / c[3] - oy
        var dz = c[2] / c[3] - oz
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len < 1e-6f) return -1
        dx /= len
        dy /= len
        dz /= len

        var best = -1
        var bestT = Float.MAX_VALUE
        for (i in 0 until scene.count) {
            if (scene.picks[i].kind == PickKind.GROUND) continue
            val o = i * FLOATS_PER_INSTANCE
            val x = scene.data[o]
            val z = scene.data[o + 1]
            val y0 = scene.data[o + 4]
            val t = intersect(
                ox, oy, oz, dx, dy, dz,
                x, y0, z, x + scene.data[o + 2], y0 + scene.data[o + 5], z + scene.data[o + 3],
            )
            if (t >= 0f && t < bestT) {
                bestT = t
                best = i
            }
        }
        return best
    }

    /** Slab test: distance along the ray to the box, or -1 when missed. */
    private fun intersect(
        ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float,
        minX: Float, minY: Float, minZ: Float, maxX: Float, maxY: Float, maxZ: Float,
    ): Float {
        var tMin = 0f
        var tMax = Float.MAX_VALUE
        val origin = floatArrayOf(ox, oy, oz)
        val dir = floatArrayOf(dx, dy, dz)
        val lo = floatArrayOf(minX, minY, minZ)
        val hi = floatArrayOf(maxX, maxY, maxZ)
        for (axis in 0 until 3) {
            if (abs(dir[axis]) < 1e-8f) {
                if (origin[axis] < lo[axis] || origin[axis] > hi[axis]) return -1f
            } else {
                val inv = 1f / dir[axis]
                var t1 = (lo[axis] - origin[axis]) * inv
                var t2 = (hi[axis] - origin[axis]) * inv
                if (t1 > t2) {
                    val tmp = t1
                    t1 = t2
                    t2 = tmp
                }
                if (t1 > tMin) tMin = t1
                if (t2 < tMax) tMax = t2
                if (tMin > tMax) return -1f
            }
        }
        return tMin
    }
}
