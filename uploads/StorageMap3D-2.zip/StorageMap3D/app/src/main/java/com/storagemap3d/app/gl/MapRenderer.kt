package com.storagemap3d.app.gl

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * OpenGL ES 3.0 renderer. The whole scene is one instanced draw call: a unit box (5 faces) is drawn
 * once per scene object, positioned and coloured from a per-instance attribute buffer.
 */
class MapRenderer(private val camera: OrbitCamera) : GLSurfaceView.Renderer {

    private val lock = Any()
    private var pending: FloatArray? = null
    private var pendingCount = 0
    private var current: FloatArray? = null
    private var currentCount = 0
    private var needUpload = false

    private var program = 0
    private var vao = 0
    private val buffers = IntArray(3)
    private var uVP = 0
    private var uCam = 0
    private var uGrow = 0
    private var instanceCount = 0
    private var viewW = 1
    private var viewH = 1
    private val vp = FloatArray(16)
    private val eye = FloatArray(3)

    /** 0..1: how far the boxes have grown from the ground (entrance animation). */
    @Volatile
    var grow = 1f

    @Volatile
    var error: String? = null

    /** Queue a scene for upload. Safe to call from any thread; the data array is copied on the GL thread. */
    fun setScene(data: FloatArray, count: Int) {
        synchronized(lock) {
            pending = data
            pendingCount = count
        }
    }

    override fun onSurfaceCreated(unused: GL10, config: EGLConfig) {
        GLES30.glClearColor(0.043f, 0.082f, 0.125f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_CULL_FACE)

        val vs = compile(GLES30.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        if (vs == 0 || fs == 0) {
            program = 0
            return
        }
        program = link(vs, fs)
        if (program == 0) return
        uVP = GLES30.glGetUniformLocation(program, "uVP")
        uCam = GLES30.glGetUniformLocation(program, "uCam")
        uGrow = GLES30.glGetUniformLocation(program, "uGrow")

        val vaoIds = IntArray(1)
        GLES30.glGenVertexArrays(1, vaoIds, 0)
        vao = vaoIds[0]
        GLES30.glGenBuffers(3, buffers, 0)
        GLES30.glBindVertexArray(vao)

        val vb = ByteBuffer.allocateDirect(CUBE_VERTICES.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(CUBE_VERTICES)
        vb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buffers[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, CUBE_VERTICES.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)

        val ib = ByteBuffer.allocateDirect(CUBE_INDICES.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(CUBE_INDICES)
        ib.position(0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, buffers[1])
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, CUBE_INDICES.size * 2, ib, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buffers[2])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, BYTES_PER_INSTANCE, null, GLES30.GL_DYNAMIC_DRAW)
        for (i in 0 until 3) {
            GLES30.glEnableVertexAttribArray(2 + i)
            GLES30.glVertexAttribPointer(2 + i, 4, GLES30.GL_FLOAT, false, BYTES_PER_INSTANCE, i * 16)
            GLES30.glVertexAttribDivisor(2 + i, 1)
        }
        GLES30.glBindVertexArray(0)

        // The GL context was (re)created, so whatever scene we had must be uploaded again.
        instanceCount = 0
        synchronized(lock) {
            if (current != null) needUpload = true
        }
    }

    override fun onSurfaceChanged(unused: GL10, width: Int, height: Int) {
        viewW = width
        viewH = height
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(unused: GL10) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (program == 0) return

        var upload: FloatArray? = null
        var uploadCount = 0
        synchronized(lock) {
            val p = pending
            if (p != null) {
                current = p
                currentCount = pendingCount
                pending = null
                needUpload = true
            }
            if (needUpload) {
                upload = current
                uploadCount = currentCount
                needUpload = false
            }
        }
        val data = upload
        if (data != null) {
            val fb = ByteBuffer.allocateDirect(uploadCount * BYTES_PER_INSTANCE)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
            fb.put(data, 0, uploadCount * FLOATS_PER_INSTANCE)
            fb.position(0)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buffers[2])
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, uploadCount * BYTES_PER_INSTANCE, fb, GLES30.GL_DYNAMIC_DRAW)
            instanceCount = uploadCount
        }
        if (instanceCount == 0) return

        camera.viewProj(viewW, viewH, vp)
        camera.eye(eye)
        GLES30.glUseProgram(program)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniform3f(uCam, eye[0], eye[1], eye[2])
        GLES30.glUniform1f(uGrow, grow)
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, CUBE_INDICES.size, GLES30.GL_UNSIGNED_SHORT, 0, instanceCount)
        GLES30.glBindVertexArray(0)
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        if (shader == 0) {
            error = "Could not create a shader."
            return 0
        }
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            error = "Shader compile failed: " + GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private fun link(vs: Int, fs: Int): Int {
        val p = GLES30.glCreateProgram()
        if (p == 0) {
            error = "Could not create a GL program."
            return 0
        }
        GLES30.glAttachShader(p, vs)
        GLES30.glAttachShader(p, fs)
        GLES30.glLinkProgram(p)
        val status = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            error = "Program link failed: " + GLES30.glGetProgramInfoLog(p)
            GLES30.glDeleteProgram(p)
            return 0
        }
        return p
    }

    private companion object {
        const val BYTES_PER_INSTANCE = FLOATS_PER_INSTANCE * 4

        // Unit box from (0,0,0) to (1,1,1): position then normal, five faces (the bottom is never seen).
        val CUBE_VERTICES = floatArrayOf(
            // top (+Y)
            0f, 1f, 0f, 0f, 1f, 0f,
            0f, 1f, 1f, 0f, 1f, 0f,
            1f, 1f, 1f, 0f, 1f, 0f,
            1f, 1f, 0f, 0f, 1f, 0f,
            // +X
            1f, 0f, 0f, 1f, 0f, 0f,
            1f, 1f, 0f, 1f, 0f, 0f,
            1f, 1f, 1f, 1f, 0f, 0f,
            1f, 0f, 1f, 1f, 0f, 0f,
            // -X
            0f, 0f, 0f, -1f, 0f, 0f,
            0f, 0f, 1f, -1f, 0f, 0f,
            0f, 1f, 1f, -1f, 0f, 0f,
            0f, 1f, 0f, -1f, 0f, 0f,
            // +Z
            0f, 0f, 1f, 0f, 0f, 1f,
            1f, 0f, 1f, 0f, 0f, 1f,
            1f, 1f, 1f, 0f, 0f, 1f,
            0f, 1f, 1f, 0f, 0f, 1f,
            // -Z
            0f, 0f, 0f, 0f, 0f, -1f,
            0f, 1f, 0f, 0f, 0f, -1f,
            1f, 1f, 0f, 0f, 0f, -1f,
            1f, 0f, 0f, 0f, 0f, -1f,
        )

        val CUBE_INDICES = shortArrayOf(
            0, 1, 2, 0, 2, 3,
            4, 5, 6, 4, 6, 7,
            8, 9, 10, 8, 10, 11,
            12, 13, 14, 12, 14, 15,
            16, 17, 18, 16, 18, 19,
        )

        const val VERTEX_SHADER = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec4 aBox;
layout(location = 3) in vec4 aVert;
layout(location = 4) in vec4 aColor;
uniform mat4 uVP;
uniform float uGrow;
out vec3 vNormal;
out vec3 vWorld;
out vec3 vColor;
flat out vec4 vBox;
flat out float vSel;
void main() {
    float h = aVert.y * mix(1.0, uGrow, aVert.w);
    vec3 world = vec3(aBox.x + aPos.x * aBox.z, aVert.x + aPos.y * h, aBox.y + aPos.z * aBox.w);
    vNormal = aNormal;
    vWorld = world;
    vColor = aColor.rgb;
    vBox = aBox;
    vSel = aVert.z;
    gl_Position = uVP * vec4(world, 1.0);
}
"""

        const val FRAGMENT_SHADER = """#version 300 es
precision highp float;
in vec3 vNormal;
in vec3 vWorld;
in vec3 vColor;
flat in vec4 vBox;
flat in float vSel;
uniform vec3 uCam;
out vec4 fragColor;
void main() {
    vec3 n = normalize(vNormal);
    float diffuse = max(dot(n, normalize(vec3(-0.35, 0.82, 0.45))), 0.0);
    float sky = 0.5 + 0.5 * n.y;
    vec3 col = vColor * (0.34 + 0.52 * diffuse + 0.20 * sky);
    if (n.y > 0.5) {
        float dx = min(vWorld.x - vBox.x, vBox.x + vBox.z - vWorld.x);
        float dz = min(vWorld.z - vBox.y, vBox.y + vBox.w - vWorld.z);
        float edge = 1.0 - smoothstep(0.0, 0.28, min(dx, dz));
        col = mix(col, col * 0.55, edge);
    }
    col = mix(col, vec3(1.0, 0.86, 0.55), 0.42 * vSel);
    float dist = length(vWorld - uCam);
    col = mix(col, vec3(0.043, 0.082, 0.125), clamp((dist - 180.0) / 300.0, 0.0, 0.55));
    fragColor = vec4(col, 1.0);
}
"""
    }
}
