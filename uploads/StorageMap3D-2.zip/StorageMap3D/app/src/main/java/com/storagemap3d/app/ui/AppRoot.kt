package com.storagemap3d.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.storagemap3d.app.MainViewModel

private class NavItem(val ico: Ico, val label: String)

private val NAV_ITEMS = listOf(
    NavItem(Ico.Overview, "Overview"),
    NavItem(Ico.Map, "3D Map"),
    NavItem(Ico.Folder, "Explorer"),
    NavItem(Ico.Chart, "Analysis"),
    NavItem(Ico.Settings, "Settings"),
)

@Composable
fun AppRoot(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) vm.onResume()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    // Keep the screen awake only while a scan or a duplicate search is running.
    val view = LocalView.current
    val working = vm.scanner.busy || vm.dups.running
    DisposableEffect(working) {
        view.keepScreenOn = working
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(vm.tab, vm.access) {
        if (vm.tab == 2) vm.explorerInit()
    }

    BackHandler(enabled = vm.tab != 0) {
        if (vm.tab == 1 && vm.mapSel != null) {
            vm.clearMapSelection()
        } else if (vm.tab == 1 && vm.mapCrumbs.size > 1) {
            vm.mapUp()
        } else if (vm.tab == 2 && vm.exUp()) {
            // handled: left a search or went up one folder
        } else if (vm.tab == 3 && vm.analysisPage != null) {
            vm.openAnalysis(null)
        } else {
            vm.tab = 0
        }
    }

    Scaffold(
        containerColor = Pal.Ink,
        contentColor = Pal.Text,
        bottomBar = { NavBar(vm.tab) { vm.tab = it } },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            val spec: FiniteAnimationSpec<Float> = if (vm.reduceMotion) snap() else tween(160)
            Crossfade(targetState = vm.tab, animationSpec = spec, label = "tab") { tab ->
                when (tab) {
                    0 -> OverviewScreen(vm, onGrantAll, onPickFolder)
                    1 -> MapScreen(vm, onGrantAll, onPickFolder)
                    2 -> ExplorerScreen(vm, onGrantAll, onPickFolder)
                    3 -> AnalysisScreen(vm, onGrantAll, onPickFolder)
                    else -> SettingsScreen(vm, onGrantAll, onPickFolder)
                }
            }
        }
    }

    FileActionsDialog(vm)
    PropertiesDialog(vm)
    DeleteHost(vm)
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Pal.Panel)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.Line))
        Row(Modifier.fillMaxWidth()) {
            NAV_ITEMS.forEachIndexed { i, item ->
                val on = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .selectable(selected = on, role = Role.Tab, onClick = { onSelect(i) })
                        .padding(top = 8.dp, bottom = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(width = 56.dp, height = 30.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(if (on) Pal.AmberSoft else Pal.Panel),
                        contentAlignment = Alignment.Center,
                    ) {
                        IconMark(item.ico, tint = if (on) Pal.Amber else Pal.Dim)
                    }
                    Text(
                        item.label,
                        style = Type.Label,
                        color = if (on) Pal.Amber else Pal.Dim,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 3.dp),
                    )
                }
            }
        }
    }
}
