package com.storagemap3d.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.storagemap3d.app.AnalysisPage
import com.storagemap3d.app.MainViewModel
import com.storagemap3d.app.core.AccessMode
import com.storagemap3d.app.core.Cat
import com.storagemap3d.app.core.CatStat
import com.storagemap3d.app.core.Fmt
import com.storagemap3d.app.core.Phase
import com.storagemap3d.app.core.ScanUi
import com.storagemap3d.app.core.VolumeStats
import kotlinx.coroutines.delay

private class LegendEntry(val label: String, val bytes: Long, val color: Color)

@Composable
fun OverviewScreen(vm: MainViewModel, onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    val summary = vm.summary
    val volume = vm.volume
    val usable = vm.indexUsable

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Storage Map 3D", style = Type.Title, color = Pal.Text)
                    Text(vm.backend.rootLabel(), style = Type.Small, color = Pal.Dim)
                }
                IconMark(Ico.Map, tint = Pal.Amber, boxSize = 26.dp)
            }
        }

        item { HeroPanel(vm, volume, summary.cats, if (usable) summary.scannedBytes else 0L) }

        if (!vm.nativeOk) {
            item {
                Notice(
                    "The native scanning library could not be loaded on this device, so scanning, hashing and the 3D map are unavailable.",
                    tone = Tone.Bad,
                    ico = Ico.Warning,
                )
            }
        }

        if (vm.access == AccessMode.None) {
            item { AccessCard(onGrantAll, onPickFolder) }
        } else if (vm.access == AccessMode.Saf) {
            item {
                Panel {
                    Notice(
                        "Limited mode: only \u201c" + vm.backend.rootLabel() + "\u201d is measured. Allow all files access to scan the whole phone.",
                        tone = Tone.Warn,
                        ico = Ico.Lock,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppButton("Allow all files", onGrantAll, Modifier.weight(1f), kind = BtnKind.Secondary)
                        AppButton("Change folder", onPickFolder, Modifier.weight(1f), kind = BtnKind.Ghost)
                    }
                }
            }
        }

        if (vm.access != AccessMode.None) {
            item { ScanCard(vm) }
        }

        if (usable) {
            item {
                Panel(onClick = { vm.tab = 1 }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconMark(Ico.Map, tint = Pal.Amber, boxSize = 26.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Open the 3D map", style = Type.Heading, color = Pal.Text)
                            Text("Folders become blocks sized by what they hold.", style = Type.Small, color = Pal.Dim)
                        }
                        IconMark(Ico.Chevron, tint = Pal.Faint)
                    }
                }
            }

            if (summary.topFiles.isNotEmpty()) {
                item {
                    Panel(padding = 8.dp) {
                        Row(Modifier.fillMaxWidth().padding(start = 10.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Largest files", style = Type.Heading, color = Pal.Text, modifier = Modifier.weight(1f))
                            AppButton(
                                "See all",
                                {
                                    vm.tab = 3
                                    vm.openAnalysis(AnalysisPage.Largest)
                                },
                                kind = BtnKind.Ghost,
                                modifier = Modifier.padding(end = 4.dp),
                            )
                        }
                        for (f in summary.topFiles) {
                            FileRow(f, f.place, Fmt.bytes(f.size), onClick = { vm.actionTarget = f })
                        }
                    }
                }
            }

            if (summary.topFolders.isNotEmpty()) {
                item {
                    Panel(padding = 8.dp) {
                        Text("Heaviest folders", style = Type.Heading, color = Pal.Text, modifier = Modifier.padding(start = 10.dp, top = 6.dp, bottom = 4.dp))
                        Text(
                            "Ranked by the files directly inside each folder.",
                            style = Type.Small,
                            color = Pal.Dim,
                            modifier = Modifier.padding(start = 10.dp, bottom = 6.dp),
                        )
                        for (row in summary.topFolders) {
                            FileRow(row.ref, row.ref.place, Fmt.bytes(row.own), onClick = { vm.actionTarget = row.ref })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroPanel(vm: MainViewModel, volume: VolumeStats, cats: List<CatStat>, scanned: Long) {
    Panel(padding = 20.dp) {
        Text("Available", style = Type.Label, color = Pal.Dim)
        Spacer(Modifier.height(2.dp))
        if (volume.total <= 0L) {
            Text("Unknown", style = Type.Display, color = Pal.Text)
        } else {
            val parts = Fmt.bytes(volume.free).split(" ")
            Row(verticalAlignment = Alignment.Bottom) {
                Text(parts[0], style = Type.Display, color = Pal.Text)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (parts.size > 1) parts[1] else "",
                    style = Type.NumLarge,
                    color = Pal.Dim,
                    modifier = Modifier.padding(bottom = 7.dp),
                )
                Spacer(Modifier.weight(1f))
                Text(
                    String.format("%.0f%% used", volume.usedFraction * 100f),
                    style = Type.Label,
                    color = Pal.Amber,
                    modifier = Modifier.padding(bottom = 10.dp),
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        StrataBar(volume, cats, scanned, animate = !vm.reduceMotion)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("Used  ", style = Type.Small, color = Pal.Dim)
            Text(Fmt.bytes(volume.used), style = Type.Num, color = Pal.Text)
            Spacer(Modifier.weight(1f))
            Text("of  ", style = Type.Small, color = Pal.Dim)
            Text(Fmt.bytes(volume.total), style = Type.Num, color = Pal.Text)
        }

        val entries = ArrayList<LegendEntry>()
        val sorted = cats.filter { it.bytes > 0L }.sortedByDescending { it.bytes }
        for (c in sorted) entries.add(LegendEntry(Cat.label(c.cat), c.bytes, Color(Cat.color(c.cat))))
        val unmeasured = if (scanned > 0L) (volume.used - scanned) else 0L
        if (unmeasured > 0L) entries.add(LegendEntry("Not measurable", unmeasured, Pal.Faint))
        if (entries.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            for (pair in entries.chunked(2)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    for (e in pair) LegendItem(e, Modifier.weight(1f).padding(end = 10.dp))
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (unmeasured > 1_000_000_000L) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Android keeps about " + Fmt.bytes(unmeasured) +
                        " out of reach of apps: system files and other apps' private data, including Android/data and Android/obb.",
                    style = Type.Small,
                    color = Pal.Dim,
                )
            }
        } else if (scanned == 0L && volume.total > 0L) {
            Spacer(Modifier.height(12.dp))
            Text("Scan your storage to see what fills it.", style = Type.Small, color = Pal.Dim)
        }
    }
}

@Composable
private fun LegendItem(e: LegendEntry, modifier: Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(e.color))
        Spacer(Modifier.width(8.dp))
        Text(e.label, style = Type.Small, color = Pal.Dim, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(6.dp))
        Text(Fmt.bytes(e.bytes), style = Type.Small, color = Pal.Text, maxLines = 1)
    }
}

/**
 * The storage volume as a core sample: every scanned category is a band of its own colour, used
 * space that apps cannot measure is hatched, and free space stays empty.
 */
@Composable
private fun StrataBar(volume: VolumeStats, cats: List<CatStat>, scanned: Long, animate: Boolean) {
    val reveal = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (animate) reveal.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    val order = Cat.order
    Canvas(Modifier.fillMaxWidth().height(54.dp)) {
        val w = size.width
        val h = size.height
        val corner = CornerRadius(12.dp.toPx())
        drawRoundRect(Pal.Raised, cornerRadius = corner)
        val total = if (volume.total > 0L) volume.total.toFloat() else 1f
        val track = Path()
        track.addRoundRect(RoundRect(0f, 0f, w, h, corner))
        val grow = reveal.value
        clipPath(track) {
            var x = 0f
            // Measured categories.
            for (cat in order) {
                var bytes = 0L
                for (c in cats) if (c.cat == cat) bytes = c.bytes
                if (bytes <= 0L || scanned <= 0L) continue
                val seg = w * (bytes.toFloat() / total) * grow
                if (seg < 0.5f) continue
                drawRect(Color(Cat.color(cat)), topLeft = Offset(x, 0f), size = Size(seg, h))
                drawLine(Pal.Ink, Offset(x + seg, 0f), Offset(x + seg, h), strokeWidth = 1.5.dp.toPx())
                x += seg
            }
            // Used space apps cannot measure: hatched.
            val unmeasured = if (scanned > 0L) (volume.used - scanned) else volume.used
            if (unmeasured > 0L) {
                val seg = w * (unmeasured.toFloat() / total) * grow
                if (seg > 0.5f) {
                    drawRect(Pal.Faint.copy(alpha = 0.22f), topLeft = Offset(x, 0f), size = Size(seg, h))
                    clipRect(left = x, top = 0f, right = x + seg, bottom = h) {
                        var hx = x - h
                        while (hx < x + seg) {
                            drawLine(Pal.Faint.copy(alpha = 0.55f), Offset(hx, h), Offset(hx + h, 0f), strokeWidth = 1.5.dp.toPx())
                            hx += 9.dp.toPx()
                        }
                    }
                    x += seg
                }
            }
            // Faint contour lines across the used region, like layers in a core sample.
            val usedEnd = x
            if (usedEnd > 0f) {
                drawLine(Color(0x22FFFFFF), Offset(0f, h / 3f), Offset(usedEnd, h / 3f), strokeWidth = 1.dp.toPx())
                drawLine(Color(0x22FFFFFF), Offset(0f, h * 2f / 3f), Offset(usedEnd, h * 2f / 3f), strokeWidth = 1.dp.toPx())
            }
        }
        drawRoundRect(Pal.Line, cornerRadius = corner, style = Stroke(width = 1.dp.toPx()))
    }
}

@Composable
private fun AccessCard(onGrantAll: () -> Unit, onPickFolder: () -> Unit) {
    Panel(padding = 20.dp) {
        Text("Allow storage access", style = Type.Title, color = Pal.Text)
        Spacer(Modifier.height(8.dp))
        Text(
            "To measure folders across your phone, Android asks you to grant \u201cAll files access\u201d. " +
                "Everything stays on this device; nothing is uploaded. Even with this permission Android never lets an app " +
                "read other apps' private data (Android/data, Android/obb).",
            style = Type.Body,
            color = Pal.Dim,
        )
        Spacer(Modifier.height(16.dp))
        AppButton("Allow all files access", onGrantAll, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        AppButton("Choose one folder instead", onPickFolder, Modifier.fillMaxWidth(), kind = BtnKind.Secondary)
        Spacer(Modifier.height(10.dp))
        Text(
            "Limited mode uses Android's folder picker and only measures the folder you choose. It is slower.",
            style = Type.Small,
            color = Pal.Faint,
        )
    }
}

@Composable
private fun ScanCard(vm: MainViewModel) {
    val ui = vm.scanner.ui
    val info = vm.summary.info
    Panel {
        if (vm.scanner.busy) {
            ScanProgress(ui, onCancel = { vm.cancelScan() }, animate = !vm.reduceMotion)
        } else {
            Text(if (info == null) "No scan yet" else "Last scan", style = Type.Heading, color = Pal.Text)
            Spacer(Modifier.height(4.dp))
            if (info == null) {
                Text(
                    "A scan reads file names, sizes and dates, then keeps the results on this device so every screen opens instantly.",
                    style = Type.Body,
                    color = Pal.Dim,
                )
            } else {
                Text(
                    Fmt.dateTime(info.finished) + "  \u00b7  " + Fmt.bytes(info.bytes) + " in " + Fmt.count(info.files) + " files",
                    style = Type.Body,
                    color = Pal.Dim,
                )
                if (info.restricted > 0L) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        Fmt.count(info.restricted) + " folders were off limits and are not counted.",
                        style = Type.Small,
                        color = Pal.Faint,
                    )
                }
                if (!vm.indexUsable) {
                    Spacer(Modifier.height(10.dp))
                    Notice("This scan was made with different access. Scan again to refresh it.", tone = Tone.Warn, ico = Ico.Warning)
                }
            }
            if ((ui.phase == Phase.Failed || ui.phase == Phase.Cancelled) && ui.message.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Notice(ui.message, tone = if (ui.phase == Phase.Failed) Tone.Bad else Tone.Info)
            }
            Spacer(Modifier.height(14.dp))
            AppButton(
                if (info == null) "Scan storage" else "Scan again",
                { vm.startScan() },
                Modifier.fillMaxWidth(),
                ico = Ico.Play,
            )
        }
    }
}

@Composable
fun ScanProgress(ui: ScanUi, onCancel: () -> Unit, animate: Boolean) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            now = System.currentTimeMillis()
        }
    }
    val saving = ui.phase == Phase.Saving
    Text(if (saving) "Saving results" else "Scanning", style = Type.Heading, color = Pal.Text)
    Spacer(Modifier.height(2.dp))
    val elapsed = if (ui.startedAt > 0L) Fmt.duration(now - ui.startedAt) else ""
    Text(
        if (saving) "Building the index" else "Running in the background  \u00b7  $elapsed",
        style = Type.Small,
        color = Pal.Dim,
    )
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth()) {
        Counter("Files", Fmt.count(ui.files), Modifier.weight(1f))
        Counter("Folders", Fmt.count(ui.dirs), Modifier.weight(1f))
        Counter("Data", Fmt.bytes(ui.bytes), Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    IndeterminateBar(animate)
    if (ui.path.isNotEmpty() && !saving) {
        Spacer(Modifier.height(10.dp))
        val shown = if (ui.path.length > 56) "\u2026" + ui.path.takeLast(55) else ui.path
        Text(shown, style = Type.Small, color = Pal.Faint, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Spacer(Modifier.height(14.dp))
    AppButton("Cancel scan", onCancel, Modifier.fillMaxWidth(), kind = BtnKind.Secondary, enabled = !saving)
}

@Composable
private fun Counter(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, style = Type.NumLarge, color = Pal.Text, maxLines = 1)
        Text(label, style = Type.Small, color = Pal.Dim)
    }
}

@Composable
private fun IndeterminateBar(animate: Boolean) {
    val transition = rememberInfiniteTransition(label = "scan")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "scanPhase",
    )
    Canvas(Modifier.fillMaxWidth().height(6.dp)) {
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(Pal.Raised, cornerRadius = r)
        val seg = size.width * 0.28f
        val start = if (animate) (size.width + seg) * phase - seg else size.width * 0.36f
        val left = if (start < 0f) 0f else start
        val right = if (start + seg > size.width) size.width else start + seg
        if (right > left) {
            drawRoundRect(Pal.Amber, topLeft = Offset(left, 0f), size = Size(right - left, size.height), cornerRadius = r)
        }
    }
}
