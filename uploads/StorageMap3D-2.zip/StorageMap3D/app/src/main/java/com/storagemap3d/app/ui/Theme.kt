package com.storagemap3d.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Palette. A deep blue-green ink, one warm amber for everything interactive, and a separate set of
 * category hues (see core/Models.kt) that is reserved for data so it never competes with controls.
 */
object Pal {
    val Ink = Color(0xFF0B1520)
    val Panel = Color(0xFF111F2D)
    val Raised = Color(0xFF182B3E)
    val Line = Color(0xFF243A50)
    val Text = Color(0xFFE7EEF5)
    val Dim = Color(0xFF8FA3B8)
    val Faint = Color(0xFF5B7288)
    val Amber = Color(0xFFF4B860)
    val AmberSoft = Color(0xFF2B2619)
    val Danger = Color(0xFFFF7A6B)
    val DangerSoft = Color(0xFF3A1F24)
    val Ok = Color(0xFF5BD6A6)
}

object Type {
    val Display = TextStyle(
        fontSize = 46.sp, lineHeight = 50.sp, fontWeight = FontWeight.Light,
        letterSpacing = (-1.4).sp, fontFeatureSettings = "tnum",
    )
    val Title = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp)
    val Heading = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold)
    val Body = TextStyle(fontSize = 14.sp, lineHeight = 20.sp)
    val BodyStrong = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
    val Small = TextStyle(fontSize = 12.sp, lineHeight = 16.sp)
    val Label = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.2.sp)
    val Num = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium, fontFeatureSettings = "tnum")
    val NumLarge = TextStyle(
        fontSize = 26.sp, lineHeight = 30.sp, fontWeight = FontWeight.Light,
        letterSpacing = (-0.6).sp, fontFeatureSettings = "tnum",
    )
}

@Composable
fun StorageMapTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Pal.Amber,
        onPrimary = Pal.Ink,
        secondary = Pal.Amber,
        onSecondary = Pal.Ink,
        background = Pal.Ink,
        onBackground = Pal.Text,
        surface = Pal.Panel,
        onSurface = Pal.Text,
        surfaceVariant = Pal.Raised,
        onSurfaceVariant = Pal.Dim,
        outline = Pal.Line,
        error = Pal.Danger,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
