# JNI: the Rust library looks these methods up by name.
-keep class com.storagemap3d.app.core.Native { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Created by name at runtime (WorkManager / ViewModelProvider).
-keep class com.storagemap3d.app.core.SnapshotWorker { *; }
-keep class com.storagemap3d.app.MainViewModel { <init>(android.app.Application); }
