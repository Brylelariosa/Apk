plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Same list the CI workflow reads from gradle.properties (rustAbis=arm64-v8a,armeabi-v7a).
val rustAbis: List<String> = ((findProperty("rustAbis") as String?) ?: "arm64-v8a")
    .split(",")
    .map { it.trim() }
    .filter { it.isNotEmpty() }

android {
    namespace = "com.storagemap3d.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.storagemap3d.app"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            abiFilters.addAll(rustAbis)
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.10"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}

// Local builds (Android Studio / command line without CI): compile the Rust library with cargo-ndk first.
// The CI workflow builds it in its own step and passes -PrustPrebuilt=true, so nothing happens there.
if ((findProperty("rustPrebuilt") as String?) != "true") {
    val buildRustLibrary = tasks.register<Exec>("buildRustLibrary") {
        workingDir = rootProject.file("rust")
        val command = mutableListOf("cargo", "ndk")
        for (abi in rustAbis) {
            command.add("-t")
            command.add(abi)
        }
        command.addAll(listOf("-o", file("src/main/jniLibs").absolutePath, "build", "--release"))
        commandLine(command)
    }
    tasks.matching { it.name == "preBuild" }.configureEach {
        dependsOn(buildRustLibrary)
    }
}
