//! File type classification by extension. One table, used by the scanner, the explorer listing and
//! (through JNI) by the Storage Access Framework scanner, so every screen agrees on categories.

pub const OTHER: u8 = 0;
pub const IMAGE: u8 = 1;
pub const VIDEO: u8 = 2;
pub const AUDIO: u8 = 3;
pub const DOCUMENT: u8 = 4;
pub const ARCHIVE: u8 = 5;
pub const APP: u8 = 6;

/// Classify a file name by its extension (case-insensitive). Names without an extension, and
/// dot-files such as ".nomedia", are `OTHER`.
pub fn classify(name: &str) -> u8 {
    let dot = match name.rfind('.') {
        Some(i) => i,
        None => return OTHER,
    };
    if dot == 0 || dot + 1 >= name.len() {
        return OTHER;
    }
    let ext = &name[dot + 1..];
    if ext.len() > 8 {
        return OTHER;
    }
    let bytes = ext.as_bytes();
    let mut buf = [0u8; 8];
    for i in 0..bytes.len() {
        buf[i] = bytes[i].to_ascii_lowercase();
    }
    let lower = match std::str::from_utf8(&buf[..bytes.len()]) {
        Ok(s) => s,
        Err(_) => return OTHER,
    };
    match lower {
        "jpg" | "jpeg" | "png" | "gif" | "webp" | "bmp" | "heic" | "heif" | "avif" | "tif" | "tiff"
        | "svg" | "dng" | "cr2" | "nef" | "arw" | "raw" | "ico" | "jfif" => IMAGE,
        "mp4" | "mkv" | "avi" | "mov" | "wmv" | "flv" | "webm" | "m4v" | "3gp" | "3g2" | "mpg"
        | "mpeg" | "ts" | "m2ts" | "ogv" | "vob" => VIDEO,
        "mp3" | "aac" | "wav" | "flac" | "ogg" | "oga" | "m4a" | "wma" | "opus" | "amr" | "mid"
        | "midi" | "aiff" | "ape" | "mka" => AUDIO,
        "pdf" | "doc" | "docx" | "xls" | "xlsx" | "ppt" | "pptx" | "txt" | "rtf" | "odt" | "ods"
        | "odp" | "csv" | "md" | "epub" | "mobi" | "azw3" | "json" | "xml" | "html" | "htm" | "log"
        | "tex" => DOCUMENT,
        "zip" | "rar" | "7z" | "tar" | "gz" | "tgz" | "bz2" | "xz" | "zst" | "lz4" | "iso" | "cab"
        | "jar" => ARCHIVE,
        "apk" | "xapk" | "apks" | "apkm" | "aab" | "obb" => APP,
        _ => OTHER,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classifies_common_extensions() {
        assert_eq!(classify("photo.JPG"), IMAGE);
        assert_eq!(classify("clip.Mp4"), VIDEO);
        assert_eq!(classify("song.flac"), AUDIO);
        assert_eq!(classify("report.pdf"), DOCUMENT);
        assert_eq!(classify("backup.tar"), ARCHIVE);
        assert_eq!(classify("game.apk"), APP);
    }

    #[test]
    fn handles_odd_names() {
        assert_eq!(classify("noext"), OTHER);
        assert_eq!(classify(".nomedia"), OTHER);
        assert_eq!(classify("trailing."), OTHER);
        assert_eq!(classify("a.verylongextension"), OTHER);
        assert_eq!(classify("archive.tar.gz"), ARCHIVE);
        assert_eq!(classify("dir.with.dots/readme.md"), DOCUMENT);
        assert_eq!(classify("unicode\u{00e9}.png"), IMAGE);
    }
}
