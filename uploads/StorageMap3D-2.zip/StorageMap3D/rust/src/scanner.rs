//! Iterative, streaming directory scanner.
//!
//! The walk uses an explicit stack (no recursion) and never keeps a list of files in memory: every
//! file is encoded into a compact binary record and handed to the caller in batches, while only one
//! small accumulator per directory on the current path is kept alive. Directory records are emitted
//! when the directory is finished, so they carry exact recursive totals.
//!
//! Record layouts (all little endian):
//!   file: kind=1 u8, id u32, parent u32, size u64, mtime i64, category u8, name length u16, name
//!   dir : kind=2 u8, id u32, parent u32, size u64, mtime i64, files u32, dirs u32, flags u8,
//!         name length u16, name
//! The root has id 0, parent `NO_PARENT` and its name is the full path that was scanned.
//!
//! Symbolic links are never followed. Android/data and Android/obb directly below the scan root are
//! reported as protected and are not entered, because Android does not let apps read them.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;

use crate::category::classify;
use crate::listing::mtime_secs;

pub const REC_FILE: u8 = 1;
pub const REC_DIR: u8 = 2;
pub const NO_PARENT: u32 = u32::MAX;
/// The folder could not be read (permission denied or vanished), so its contents are unknown.
pub const FLAG_UNREADABLE: u8 = 1;
/// The folder is protected by Android (Android/data, Android/obb) and was deliberately not entered.
pub const FLAG_PROTECTED: u8 = 2;
/// Some folder below this one could not be read, so its totals (and emptiness) are not guaranteed.
pub const FLAG_PARTIAL: u8 = 4;

const BATCH_BYTES: usize = 256 * 1024;
const BATCH_RECORDS: usize = 8192;

/// Live counters shared between the scanner thread and the UI poller.
pub struct Progress {
    pub files: AtomicU64,
    pub dirs: AtomicU64,
    pub bytes: AtomicU64,
    pub restricted: AtomicU64,
    pub errors: AtomicU64,
    pub cancel: AtomicBool,
    pub current: Mutex<String>,
}

impl Progress {
    pub fn new() -> Progress {
        Progress {
            files: AtomicU64::new(0),
            dirs: AtomicU64::new(0),
            bytes: AtomicU64::new(0),
            restricted: AtomicU64::new(0),
            errors: AtomicU64::new(0),
            cancel: AtomicBool::new(false),
            current: Mutex::new(String::new()),
        }
    }

    fn set_current(&self, path: &Path) {
        if let Ok(mut guard) = self.current.lock() {
            guard.clear();
            guard.push_str(&path.to_string_lossy());
        }
    }
}

impl Default for Progress {
    fn default() -> Self {
        Progress::new()
    }
}

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum ScanEnd {
    Completed,
    Cancelled,
    Failed,
}

struct Frame {
    id: u32,
    parent: u32,
    name: String,
    mtime: i64,
    path: PathBuf,
    iter: Option<fs::ReadDir>,
    size: u64,
    files: u32,
    dirs: u32,
    flags: u8,
}

fn put_name(buf: &mut Vec<u8>, name: &str) {
    let bytes = name.as_bytes();
    let n = if bytes.len() > u16::MAX as usize { u16::MAX as usize } else { bytes.len() };
    buf.extend_from_slice(&(n as u16).to_le_bytes());
    buf.extend_from_slice(&bytes[..n]);
}

pub fn encode_file(buf: &mut Vec<u8>, id: u32, parent: u32, size: u64, mtime: i64, cat: u8, name: &str) {
    buf.push(REC_FILE);
    buf.extend_from_slice(&id.to_le_bytes());
    buf.extend_from_slice(&parent.to_le_bytes());
    buf.extend_from_slice(&size.to_le_bytes());
    buf.extend_from_slice(&mtime.to_le_bytes());
    buf.push(cat);
    put_name(buf, name);
}

fn encode_dir(buf: &mut Vec<u8>, f: &Frame) {
    buf.push(REC_DIR);
    buf.extend_from_slice(&f.id.to_le_bytes());
    buf.extend_from_slice(&f.parent.to_le_bytes());
    buf.extend_from_slice(&f.size.to_le_bytes());
    buf.extend_from_slice(&f.mtime.to_le_bytes());
    buf.extend_from_slice(&f.files.to_le_bytes());
    buf.extend_from_slice(&f.dirs.to_le_bytes());
    buf.push(f.flags);
    put_name(buf, &f.name);
}

/// Walk `root`, calling `sink` with each full batch of records. `sink` returns `false` to stop early.
pub fn scan_tree<F>(root: &Path, prog: &Progress, mut sink: F) -> ScanEnd
where
    F: FnMut(Vec<u8>) -> bool,
{
    let root_meta = match fs::metadata(root) {
        Ok(m) => m,
        Err(_) => return ScanEnd::Failed,
    };
    if !root_meta.is_dir() {
        return ScanEnd::Failed;
    }
    let root_iter = match fs::read_dir(root) {
        Ok(i) => i,
        Err(_) => return ScanEnd::Failed,
    };

    let mut batch: Vec<u8> = Vec::with_capacity(BATCH_BYTES + 4096);
    let mut in_batch: usize = 0;
    let mut next_id: u32 = 1;
    let mut stack: Vec<Frame> = Vec::with_capacity(64);

    prog.set_current(root);
    stack.push(Frame {
        id: 0,
        parent: NO_PARENT,
        name: root.to_string_lossy().into_owned(),
        mtime: mtime_secs(&root_meta),
        path: root.to_path_buf(),
        iter: Some(root_iter),
        size: 0,
        files: 0,
        dirs: 0,
        flags: 0,
    });

    while !stack.is_empty() {
        if prog.cancel.load(Ordering::Relaxed) {
            return ScanEnd::Cancelled;
        }

        let next = {
            let top = stack.last_mut().unwrap();
            match top.iter.as_mut() {
                Some(it) => it.next(),
                None => None,
            }
        };

        match next {
            Some(Err(_)) => {
                prog.errors.fetch_add(1, Ordering::Relaxed);
            }
            Some(Ok(entry)) => {
                let file_type = match entry.file_type() {
                    Ok(t) => t,
                    Err(_) => {
                        prog.errors.fetch_add(1, Ordering::Relaxed);
                        continue;
                    }
                };
                if file_type.is_symlink() {
                    continue;
                }
                let name = entry.file_name().to_string_lossy().into_owned();
                let depth = stack.len();
                let parent_id = stack[depth - 1].id;

                if file_type.is_dir() {
                    let id = next_id;
                    next_id = next_id.wrapping_add(1);
                    let mtime = match entry.metadata() {
                        Ok(m) => mtime_secs(&m),
                        Err(_) => 0,
                    };
                    let child_path = stack[depth - 1].path.join(&name);
                    let protected = depth == 2 && stack[1].name == "Android" && (name == "data" || name == "obb");
                    let mut frame = Frame {
                        id,
                        parent: parent_id,
                        name,
                        mtime,
                        path: child_path,
                        iter: None,
                        size: 0,
                        files: 0,
                        dirs: 0,
                        flags: 0,
                    };
                    if protected {
                        frame.flags = FLAG_PROTECTED | FLAG_UNREADABLE;
                    } else {
                        match fs::read_dir(&frame.path) {
                            Ok(it) => frame.iter = Some(it),
                            Err(_) => frame.flags = FLAG_UNREADABLE,
                        }
                    }
                    if frame.iter.is_some() {
                        prog.set_current(&frame.path);
                        stack.push(frame);
                    } else {
                        // Nothing to descend into: record it right away as an unreadable leaf.
                        prog.restricted.fetch_add(1, Ordering::Relaxed);
                        prog.dirs.fetch_add(1, Ordering::Relaxed);
                        encode_dir(&mut batch, &frame);
                        in_batch += 1;
                        let parent = &mut stack[depth - 1];
                        parent.dirs = parent.dirs.saturating_add(1);
                        parent.flags |= FLAG_PARTIAL;
                    }
                } else if file_type.is_file() {
                    let md = match entry.metadata() {
                        Ok(m) => m,
                        Err(_) => {
                            prog.errors.fetch_add(1, Ordering::Relaxed);
                            continue;
                        }
                    };
                    let size = md.len();
                    let id = next_id;
                    next_id = next_id.wrapping_add(1);
                    encode_file(&mut batch, id, parent_id, size, mtime_secs(&md), classify(&name), &name);
                    in_batch += 1;
                    let parent = &mut stack[depth - 1];
                    parent.size = parent.size.saturating_add(size);
                    parent.files = parent.files.saturating_add(1);
                    prog.files.fetch_add(1, Ordering::Relaxed);
                    prog.bytes.fetch_add(size, Ordering::Relaxed);
                }
                // Sockets, pipes and device nodes are ignored.
            }
            None => {
                let done = stack.pop().unwrap();
                encode_dir(&mut batch, &done);
                in_batch += 1;
                prog.dirs.fetch_add(1, Ordering::Relaxed);
                if let Some(parent) = stack.last_mut() {
                    parent.size = parent.size.saturating_add(done.size);
                    parent.files = parent.files.saturating_add(done.files);
                    parent.dirs = parent.dirs.saturating_add(done.dirs).saturating_add(1);
                    if done.flags & (FLAG_UNREADABLE | FLAG_PARTIAL) != 0 {
                        parent.flags |= FLAG_PARTIAL;
                    }
                }
            }
        }

        if in_batch >= BATCH_RECORDS || batch.len() >= BATCH_BYTES {
            let full = std::mem::replace(&mut batch, Vec::with_capacity(BATCH_BYTES + 4096));
            in_batch = 0;
            if !sink(full) {
                return ScanEnd::Cancelled;
            }
        }
    }

    if !batch.is_empty() && !sink(batch) {
        return ScanEnd::Cancelled;
    }
    ScanEnd::Completed
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    #[derive(Debug, Clone)]
    struct Rec {
        kind: u8,
        id: u32,
        parent: u32,
        size: u64,
        files: u32,
        dirs: u32,
        flags: u8,
        cat: u8,
        name: String,
    }

    fn rd_u32(b: &[u8], p: usize) -> u32 {
        u32::from_le_bytes([b[p], b[p + 1], b[p + 2], b[p + 3]])
    }

    fn rd_u64(b: &[u8], p: usize) -> u64 {
        let mut a = [0u8; 8];
        a.copy_from_slice(&b[p..p + 8]);
        u64::from_le_bytes(a)
    }

    fn decode(buf: &[u8]) -> Vec<Rec> {
        let mut out = Vec::new();
        let mut p = 0usize;
        while p < buf.len() {
            let kind = buf[p];
            p += 1;
            let id = rd_u32(buf, p);
            p += 4;
            let parent = rd_u32(buf, p);
            p += 4;
            let size = rd_u64(buf, p);
            p += 8;
            p += 8; // mtime
            let (mut files, mut dirs, mut flags, mut cat) = (0u32, 0u32, 0u8, 0u8);
            if kind == REC_FILE {
                cat = buf[p];
                p += 1;
            } else {
                files = rd_u32(buf, p);
                p += 4;
                dirs = rd_u32(buf, p);
                p += 4;
                flags = buf[p];
                p += 1;
            }
            let n = u16::from_le_bytes([buf[p], buf[p + 1]]) as usize;
            p += 2;
            let name = String::from_utf8_lossy(&buf[p..p + n]).into_owned();
            p += n;
            out.push(Rec { kind, id, parent, size, files, dirs, flags, cat, name });
        }
        out
    }

    fn temp_dir(tag: &str) -> PathBuf {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        let p = std::env::temp_dir().join(format!("smap_{}_{}_{}", tag, std::process::id(), nanos));
        fs::create_dir_all(&p).unwrap();
        p
    }

    fn scan_all(root: &Path) -> (ScanEnd, Vec<Rec>, Progress) {
        let prog = Progress::new();
        let mut recs: Vec<Rec> = Vec::new();
        let end = scan_tree(root, &prog, |data| {
            recs.extend(decode(&data));
            true
        });
        (end, recs, prog)
    }

    #[test]
    fn totals_flags_and_protected_folders() {
        let root = temp_dir("scan");
        fs::write(root.join("a.txt"), vec![0u8; 10]).unwrap();
        fs::write(root.join("img.jpg"), vec![0u8; 100]).unwrap();
        fs::create_dir_all(root.join("sub").join("deep")).unwrap();
        fs::write(root.join("sub").join("b.mp4"), vec![0u8; 1000]).unwrap();
        fs::write(root.join("sub").join("deep").join("c.zip"), vec![0u8; 5]).unwrap();
        fs::create_dir(root.join("empty")).unwrap();
        fs::create_dir_all(root.join("Android").join("data")).unwrap();
        fs::write(root.join("Android").join("data").join("secret.bin"), vec![0u8; 777]).unwrap();

        let (end, recs, prog) = scan_all(&root);
        assert_eq!(end, ScanEnd::Completed);

        let by_name: HashMap<String, Rec> = recs.iter().map(|r| (r.name.clone(), r.clone())).collect();
        let root_rec = recs.iter().find(|r| r.parent == NO_PARENT).unwrap();
        assert_eq!(root_rec.id, 0);
        assert_eq!(root_rec.size, 10 + 100 + 1000 + 5);
        assert_eq!(root_rec.files, 4);
        assert_eq!(root_rec.dirs, 5); // sub, deep, empty, Android, data

        assert_eq!(by_name["sub"].size, 1005);
        assert_eq!(by_name["sub"].files, 2);
        assert_eq!(by_name["deep"].size, 5);
        assert_eq!(by_name["empty"].files, 0);
        assert_eq!(by_name["empty"].flags, 0);
        assert_ne!(by_name["data"].flags & FLAG_PROTECTED, 0);
        // A folder that contains an unreadable one is marked partial, all the way up to the root.
        assert_ne!(by_name["Android"].flags & FLAG_PARTIAL, 0);
        assert_ne!(root_rec.flags & FLAG_PARTIAL, 0);
        assert_eq!(by_name["sub"].flags, 0);
        assert_eq!(by_name["data"].size, 0);
        assert!(!by_name.contains_key("secret.bin"));
        assert_eq!(by_name["img.jpg"].cat, crate::category::IMAGE);
        assert_eq!(by_name["b.mp4"].cat, crate::category::VIDEO);

        // The directory records always come after every record of their children.
        let pos: HashMap<u32, usize> = recs.iter().enumerate().map(|(i, r)| (r.id, i)).collect();
        for r in recs.iter() {
            if r.parent != NO_PARENT {
                assert!(pos[&r.parent] > pos[&r.id], "{} must be emitted before its parent", r.name);
            }
        }

        assert_eq!(prog.files.load(Ordering::Relaxed), 4);
        assert_eq!(prog.bytes.load(Ordering::Relaxed), 1115);
        assert_eq!(prog.dirs.load(Ordering::Relaxed), 6); // root + 5
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn sizes_add_up_for_a_wide_tree() {
        let root = temp_dir("wide");
        let mut expected = 0u64;
        for d in 0..20 {
            let dir = root.join(format!("d{}", d));
            fs::create_dir(&dir).unwrap();
            for f in 0..50 {
                let len = (d * 50 + f) as u64 % 97 + 1;
                fs::write(dir.join(format!("f{}.bin", f)), vec![1u8; len as usize]).unwrap();
                expected += len;
            }
        }
        let (end, recs, _) = scan_all(&root);
        assert_eq!(end, ScanEnd::Completed);
        let root_rec = recs.iter().find(|r| r.parent == NO_PARENT).unwrap();
        assert_eq!(root_rec.size, expected);
        assert_eq!(root_rec.files, 1000);
        let file_sum: u64 = recs.iter().filter(|r| r.kind == REC_FILE).map(|r| r.size).sum();
        assert_eq!(file_sum, expected);
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn cancel_stops_the_walk() {
        let root = temp_dir("cancel");
        for d in 0..5 {
            fs::create_dir(root.join(format!("d{}", d))).unwrap();
        }
        let prog = Progress::new();
        prog.cancel.store(true, Ordering::Relaxed);
        let end = scan_tree(&root, &prog, |_| true);
        assert_eq!(end, ScanEnd::Cancelled);
        let _ = fs::remove_dir_all(&root);
    }

    #[test]
    fn missing_root_fails() {
        let prog = Progress::new();
        assert_eq!(scan_tree(Path::new("/definitely/not/here"), &prog, |_| true), ScanEnd::Failed);
    }
}
