//! Storage Map 3D native core.
//!
//! * `scanner`  - iterative directory walk that streams compact binary records (never keeps a file list in RAM)
//! * `hash`     - dependency-free SHA-256 plus sampled/full file hashing for duplicate detection
//! * `treemap`  - squarified treemap layout used by the 3D scene
//! * `listing`  - single-directory listing for the file explorer
//! * `category` - file type classification shared by every code path
//! * `jni_api`  - the only place that talks to the JVM

pub mod category;
pub mod hash;
pub mod jni_api;
pub mod listing;
pub mod scanner;
pub mod treemap;

pub const VERSION: &str = "1.0.0";
