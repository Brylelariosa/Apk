//! Single-directory listing for the file explorer.
//!
//! Entry layout (little endian): kind u8, category u8, size u64, mtime i64, name length u16, name bytes.
//! Directories report size 0; the app fills in cached folder sizes from its index.

use std::fs;
use std::io;
use std::path::Path;
use std::time::UNIX_EPOCH;

use crate::category::classify;

pub const KIND_FILE: u8 = 0;
pub const KIND_DIR: u8 = 1;
/// Marker entry appended when a folder holds more than `MAX_ENTRIES` items.
pub const KIND_TRUNCATED: u8 = 255;
pub const MAX_ENTRIES: usize = 100_000;

/// Modification time in whole seconds since the Unix epoch (0 when unknown).
pub fn mtime_secs(md: &fs::Metadata) -> i64 {
    match md.modified() {
        Ok(t) => match t.duration_since(UNIX_EPOCH) {
            Ok(d) => d.as_secs() as i64,
            Err(e) => -(e.duration().as_secs() as i64),
        },
        Err(_) => 0,
    }
}

fn push_entry(out: &mut Vec<u8>, kind: u8, cat: u8, size: u64, mtime: i64, name: &str) {
    let bytes = name.as_bytes();
    let n = if bytes.len() > u16::MAX as usize { u16::MAX as usize } else { bytes.len() };
    out.push(kind);
    out.push(cat);
    out.extend_from_slice(&size.to_le_bytes());
    out.extend_from_slice(&mtime.to_le_bytes());
    out.extend_from_slice(&(n as u16).to_le_bytes());
    out.extend_from_slice(&bytes[..n]);
}

/// List one directory. Symbolic links are resolved so the explorer shows what they point to;
/// broken links and special files (sockets, pipes) are skipped.
pub fn list_dir(path: &Path) -> io::Result<Vec<u8>> {
    let read = fs::read_dir(path)?;
    let mut out: Vec<u8> = Vec::with_capacity(8192);
    let mut count = 0usize;
    for entry in read {
        let entry = match entry {
            Ok(e) => e,
            Err(_) => continue,
        };
        if count >= MAX_ENTRIES {
            push_entry(&mut out, KIND_TRUNCATED, 0, 0, 0, "");
            break;
        }
        let file_type = match entry.file_type() {
            Ok(t) => t,
            Err(_) => continue,
        };
        let md = if file_type.is_symlink() {
            match fs::metadata(entry.path()) {
                Ok(m) => m,
                Err(_) => continue,
            }
        } else {
            match entry.metadata() {
                Ok(m) => m,
                Err(_) => continue,
            }
        };
        let name = entry.file_name().to_string_lossy().into_owned();
        if md.is_dir() {
            push_entry(&mut out, KIND_DIR, 0, 0, mtime_secs(&md), &name);
        } else if md.is_file() {
            push_entry(&mut out, KIND_FILE, classify(&name), md.len(), mtime_secs(&md), &name);
        } else {
            continue;
        }
        count += 1;
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir(tag: &str) -> std::path::PathBuf {
        let nanos = std::time::SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        let p = std::env::temp_dir().join(format!("smap_{}_{}_{}", tag, std::process::id(), nanos));
        fs::create_dir_all(&p).unwrap();
        p
    }

    #[test]
    fn lists_files_and_folders() {
        let dir = temp_dir("list");
        fs::write(dir.join("photo.jpg"), vec![1u8; 123]).unwrap();
        fs::create_dir(dir.join("sub")).unwrap();
        let data = list_dir(&dir).unwrap();

        let mut p = 0usize;
        let mut seen: Vec<(u8, u8, u64, String)> = Vec::new();
        while p < data.len() {
            let kind = data[p];
            let cat = data[p + 1];
            let mut b = [0u8; 8];
            b.copy_from_slice(&data[p + 2..p + 10]);
            let size = u64::from_le_bytes(b);
            let n = u16::from_le_bytes([data[p + 18], data[p + 19]]) as usize;
            let name = String::from_utf8_lossy(&data[p + 20..p + 20 + n]).into_owned();
            p += 20 + n;
            seen.push((kind, cat, size, name));
        }
        seen.sort_by(|a, b| a.3.cmp(&b.3));
        assert_eq!(seen.len(), 2);
        assert_eq!(seen[0], (KIND_FILE, crate::category::IMAGE, 123, "photo.jpg".to_string()));
        assert_eq!(seen[1], (KIND_DIR, 0, 0, "sub".to_string()));
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn missing_folder_is_an_error() {
        assert!(list_dir(Path::new("/definitely/not/here")).is_err());
    }
}
