//! Squarified treemap layout (Bruls, Huizing, van Wijk).
//!
//! Every item gets a rectangle whose area is proportional to its size, and the rectangles tile the
//! container exactly. Items of size zero get an empty rectangle at the container origin.

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Rect {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

/// Worst aspect ratio of a row laid along a side of length `side`.
/// `sum` is the total area of the row, `max_area`/`min_area` its largest and smallest item.
fn worst(sum: f64, max_area: f64, min_area: f64, side: f64) -> f64 {
    let s2 = sum * sum;
    let l2 = side * side;
    let a = l2 * max_area / s2;
    let b = s2 / (l2 * min_area);
    if a > b {
        a
    } else {
        b
    }
}

/// Lay out `sizes` inside the rectangle (x, y, w, h). The result has one rectangle per input item,
/// in input order.
pub fn squarify(sizes: &[u64], x: f64, y: f64, w: f64, h: f64) -> Vec<Rect> {
    let n = sizes.len();
    let mut out = vec![Rect { x, y, w: 0.0, h: 0.0 }; n];
    if n == 0 || !(w > 0.0) || !(h > 0.0) {
        return out;
    }

    // Positive items, largest first (ties keep input order so the layout is deterministic).
    let mut idx: Vec<usize> = (0..n).filter(|&i| sizes[i] > 0).collect();
    if idx.is_empty() {
        return out;
    }
    idx.sort_by(|&a, &b| sizes[b].cmp(&sizes[a]).then(a.cmp(&b)));

    let total: f64 = idx.iter().map(|&i| sizes[i] as f64).sum();
    let scale = (w * h) / total;
    let areas: Vec<f64> = idx.iter().map(|&i| sizes[i] as f64 * scale).collect();

    let m = areas.len();
    let (mut rx, mut ry, mut rw, mut rh) = (x, y, w, h);
    let mut i = 0usize;
    while i < m {
        let short = if rw < rh { rw } else { rh };
        let mut sum = areas[i];
        let mut best = worst(sum, areas[i], areas[i], short);
        let mut j = i + 1;
        while j < m {
            let new_sum = sum + areas[j];
            let candidate = worst(new_sum, areas[i], areas[j], short);
            if candidate <= best {
                sum = new_sum;
                best = candidate;
                j += 1;
            } else {
                break;
            }
        }

        if rw >= rh {
            // The row becomes a column on the left edge.
            let col_w = if rh > 0.0 { sum / rh } else { 0.0 };
            let mut cy = ry;
            for k in i..j {
                let item_h = if col_w > 0.0 { areas[k] / col_w } else { 0.0 };
                out[idx[k]] = Rect { x: rx, y: cy, w: col_w, h: item_h };
                cy += item_h;
            }
            rx += col_w;
            rw = (rw - col_w).max(0.0);
        } else {
            // The row becomes a strip along the top edge.
            let row_h = if rw > 0.0 { sum / rw } else { 0.0 };
            let mut cx = rx;
            for k in i..j {
                let item_w = if row_h > 0.0 { areas[k] / row_h } else { 0.0 };
                out[idx[k]] = Rect { x: cx, y: ry, w: item_w, h: row_h };
                cx += item_w;
            }
            ry += row_h;
            rh = (rh - row_h).max(0.0);
        }
        i = j;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn area(r: &Rect) -> f64 {
        r.w * r.h
    }

    fn overlap(a: &Rect, b: &Rect) -> f64 {
        let ox = (a.x + a.w).min(b.x + b.w) - a.x.max(b.x);
        let oy = (a.y + a.h).min(b.y + b.h) - a.y.max(b.y);
        if ox > 0.0 && oy > 0.0 {
            ox * oy
        } else {
            0.0
        }
    }

    fn pseudo_sizes(n: usize, seed: u64) -> Vec<u64> {
        let mut s = seed;
        let mut v = Vec::new();
        for _ in 0..n {
            s = s.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            v.push(((s >> 33) % 100_000) + 1);
        }
        v
    }

    #[test]
    fn areas_are_proportional_and_tile_the_container() {
        for &(n, seed, w, h) in [(1usize, 1u64, 100.0, 100.0), (7, 2, 100.0, 60.0), (40, 3, 30.0, 90.0), (200, 4, 100.0, 100.0)].iter() {
            let sizes = pseudo_sizes(n, seed);
            let rects = squarify(&sizes, 5.0, 7.0, w, h);
            assert_eq!(rects.len(), n);
            let total: u64 = sizes.iter().sum();
            let mut sum_area = 0.0;
            for (i, r) in rects.iter().enumerate() {
                let expected = w * h * sizes[i] as f64 / total as f64;
                assert!((area(r) - expected).abs() < 1e-6 * (w * h), "item {} area {} expected {}", i, area(r), expected);
                assert!(r.x >= 5.0 - 1e-9 && r.y >= 7.0 - 1e-9);
                assert!(r.x + r.w <= 5.0 + w + 1e-6 && r.y + r.h <= 7.0 + h + 1e-6);
                sum_area += area(r);
            }
            assert!((sum_area - w * h).abs() < 1e-6 * (w * h));
        }
    }

    #[test]
    fn rectangles_do_not_overlap() {
        let sizes = pseudo_sizes(60, 9);
        let rects = squarify(&sizes, 0.0, 0.0, 100.0, 100.0);
        for i in 0..rects.len() {
            for j in (i + 1)..rects.len() {
                assert!(overlap(&rects[i], &rects[j]) < 1e-6, "items {} and {} overlap", i, j);
            }
        }
    }

    #[test]
    fn zero_sized_items_get_empty_rectangles() {
        let rects = squarify(&[0, 50, 0, 50], 0.0, 0.0, 10.0, 10.0);
        assert_eq!(area(&rects[0]), 0.0);
        assert_eq!(area(&rects[2]), 0.0);
        assert!((area(&rects[1]) - 50.0).abs() < 1e-9);
        assert!((area(&rects[3]) - 50.0).abs() < 1e-9);
    }

    #[test]
    fn degenerate_input_is_safe() {
        assert!(squarify(&[], 0.0, 0.0, 10.0, 10.0).is_empty());
        let r = squarify(&[5, 5], 0.0, 0.0, 0.0, 10.0);
        assert_eq!(r.len(), 2);
        assert_eq!(area(&r[0]), 0.0);
        let r = squarify(&[0, 0], 0.0, 0.0, 10.0, 10.0);
        assert_eq!(area(&r[1]), 0.0);
    }
}
