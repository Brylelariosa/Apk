//! Dependency-free SHA-256 and the file hashing used by the duplicate finder.
//!
//! Duplicate detection works in two stages: a cheap "sampled" digest (head, middle and tail of a file)
//! rules out most same-size files, then a full digest is computed for the survivors. Only files whose
//! full digests match are reported as duplicates.

use std::fs::File;
use std::io::{self, Read, Seek, SeekFrom};
use std::sync::atomic::{AtomicBool, Ordering};

// Round constants: first 32 bits of the fractional parts of the cube roots of the first 64 primes.
const K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

// Initial state: first 32 bits of the fractional parts of the square roots of the first 8 primes.
const H0: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

pub struct Sha256 {
    state: [u32; 8],
    buf: [u8; 64],
    buf_len: usize,
    total: u64,
}

impl Default for Sha256 {
    fn default() -> Self {
        Sha256::new()
    }
}

impl Sha256 {
    pub fn new() -> Sha256 {
        Sha256 { state: H0, buf: [0u8; 64], buf_len: 0, total: 0 }
    }

    pub fn update(&mut self, input: &[u8]) {
        let mut data = input;
        self.total = self.total.wrapping_add(data.len() as u64);
        if self.buf_len > 0 {
            let need = 64 - self.buf_len;
            let take = if data.len() < need { data.len() } else { need };
            self.buf[self.buf_len..self.buf_len + take].copy_from_slice(&data[..take]);
            self.buf_len += take;
            data = &data[take..];
            if self.buf_len == 64 {
                let block = self.buf;
                compress(&mut self.state, &block);
                self.buf_len = 0;
            }
        }
        while data.len() >= 64 {
            compress(&mut self.state, &data[..64]);
            data = &data[64..];
        }
        if !data.is_empty() {
            self.buf[..data.len()].copy_from_slice(data);
            self.buf_len = data.len();
        }
    }

    pub fn finalize(mut self) -> [u8; 32] {
        let bit_len = self.total.wrapping_mul(8);
        let mut pad = [0u8; 72];
        pad[0] = 0x80;
        let pad_len = if self.buf_len < 56 { 56 - self.buf_len } else { 120 - self.buf_len };
        self.update(&pad[..pad_len]);
        self.update(&bit_len.to_be_bytes());
        let mut out = [0u8; 32];
        for i in 0..8 {
            out[i * 4..i * 4 + 4].copy_from_slice(&self.state[i].to_be_bytes());
        }
        out
    }
}

fn compress(state: &mut [u32; 8], block: &[u8]) {
    let mut w = [0u32; 64];
    for i in 0..16 {
        w[i] = u32::from_be_bytes([block[4 * i], block[4 * i + 1], block[4 * i + 2], block[4 * i + 3]]);
    }
    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16].wrapping_add(s0).wrapping_add(w[i - 7]).wrapping_add(s1);
    }
    let mut a = state[0];
    let mut b = state[1];
    let mut c = state[2];
    let mut d = state[3];
    let mut e = state[4];
    let mut f = state[5];
    let mut g = state[6];
    let mut h = state[7];
    for i in 0..64 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ ((!e) & g);
        let t1 = h.wrapping_add(s1).wrapping_add(ch).wrapping_add(K[i]).wrapping_add(w[i]);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let t2 = s0.wrapping_add(maj);
        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(t1);
        d = c;
        c = b;
        b = a;
        a = t1.wrapping_add(t2);
    }
    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

/// Bytes read from each of the head, middle and tail of a file for the sampled digest.
pub const SAMPLE_CHUNK: u64 = 32 * 1024;
/// Files up to this size are always read completely, so for them the sampled digest IS the full digest.
pub const SAMPLE_THRESHOLD: u64 = SAMPLE_CHUNK * 3;

static CANCEL: AtomicBool = AtomicBool::new(false);

/// Ask running (and future) hash calls to stop early; they return an error until reset with `false`.
pub fn set_cancel(value: bool) {
    CANCEL.store(value, Ordering::Relaxed);
}

pub fn is_cancelled() -> bool {
    CANCEL.load(Ordering::Relaxed)
}

fn cancelled_error() -> io::Error {
    io::Error::new(io::ErrorKind::Other, "cancelled")
}

fn hash_stream<R: Read>(reader: &mut R, hasher: &mut Sha256, size_hint: u64) -> io::Result<()> {
    let cap: usize = if size_hint == 0 {
        4096
    } else if size_hint < 262_144 {
        size_hint as usize
    } else {
        262_144
    };
    let mut buf = vec![0u8; cap];
    loop {
        if is_cancelled() {
            return Err(cancelled_error());
        }
        let n = match reader.read(&mut buf) {
            Ok(0) => return Ok(()),
            Ok(n) => n,
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        };
        hasher.update(&buf[..n]);
    }
}

/// Hash an open file. `full == true` reads everything; otherwise large files are sampled.
pub fn hash_file(file: &mut File, full: bool) -> io::Result<[u8; 32]> {
    let size = file.metadata()?.len();
    let mut hasher = Sha256::new();
    if full || size <= SAMPLE_THRESHOLD {
        hash_stream(file, &mut hasher, size)?;
    } else {
        let mut buf = vec![0u8; SAMPLE_CHUNK as usize];
        hasher.update(&size.to_le_bytes());
        let offsets = [0u64, size / 2 - SAMPLE_CHUNK / 2, size - SAMPLE_CHUNK];
        for off in offsets.iter() {
            if is_cancelled() {
                return Err(cancelled_error());
            }
            file.seek(SeekFrom::Start(*off))?;
            file.read_exact(&mut buf)?;
            hasher.update(&buf);
        }
    }
    Ok(hasher.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn hex(d: [u8; 32]) -> String {
        let mut s = String::new();
        for b in d.iter() {
            s.push_str(&format!("{:02x}", b));
        }
        s
    }

    fn sha(data: &[u8]) -> String {
        let mut h = Sha256::new();
        h.update(data);
        hex(h.finalize())
    }

    fn temp_path(tag: &str) -> std::path::PathBuf {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        std::env::temp_dir().join(format!("smap_{}_{}_{}", tag, std::process::id(), nanos))
    }

    #[test]
    fn known_vectors() {
        assert_eq!(sha(b""), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
        assert_eq!(sha(b"abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
        assert_eq!(sha(b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"), "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
        assert_eq!(sha(&vec![b'a'; 55]), "9f4390f8d30c2dd92ec9f095b65e2b9ae9b0a925a5258e241c9f1e910f734318");
        assert_eq!(sha(&vec![b'a'; 56]), "b35439a4ac6f0948b6d6f9e3c6af0f5f590ce20f1bde7090ef7970686ec6738a");
        assert_eq!(sha(&vec![b'a'; 63]), "7d3e74a05d7db15bce4ad9ec0658ea98e3f06eeecf16b4c6fff2da457ddc2f34");
        assert_eq!(sha(&vec![b'a'; 64]), "ffe054fe7ae0cb6dc65c3af9b61d5209f439851db43d0ba5997337df154668eb");
        assert_eq!(sha(&vec![b'a'; 65]), "635361c48bb9eab14198e76ea8ab7f1a41685d6ad62aa9146d301d4f17eb0ae0");
        assert_eq!(sha(&vec![b'a'; 119]), "31eba51c313a5c08226adf18d4a359cfdfd8d2e816b13f4af952f7ea6584dcfb");
        assert_eq!(sha(&vec![b'a'; 120]), "2f3d335432c70b580af0e8e1b3674a7c020d683aa5f73aaaedfdc55af904c21c");
        assert_eq!(sha(&vec![b'a'; 128]), "6836cf13bac400e9105071cd6af47084dfacad4e5e302c94bfed24e013afb73e");
        assert_eq!(sha(&vec![b'a'; 1_000_000]), "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
    }

    #[test]
    fn chunked_updates_match_one_shot() {
        let data: Vec<u8> = (0..5000usize).map(|i| (i.wrapping_mul(31).wrapping_add(7) % 251) as u8).collect();
        let expected = sha(&data);
        for chunk in [1usize, 7, 63, 64, 65, 1000].iter() {
            let mut h = Sha256::new();
            for piece in data.chunks(*chunk) {
                h.update(piece);
            }
            assert_eq!(hex(h.finalize()), expected, "chunk size {}", chunk);
        }
    }

    #[test]
    fn file_hashes() {
        let n = 300_000usize;
        let data: Vec<u8> = (0..n).map(|i| (i.wrapping_mul(31).wrapping_add(7) % 251) as u8).collect();
        let path = temp_path("hash");
        std::fs::write(&path, &data).unwrap();
        let expected = {
            let mut h = Sha256::new();
            h.update(&data);
            h.finalize()
        };
        let mut f = File::open(&path).unwrap();
        assert_eq!(hash_file(&mut f, true).unwrap(), expected);

        let mut f = File::open(&path).unwrap();
        let sampled = hash_file(&mut f, false).unwrap();
        assert_ne!(sampled, expected);

        let mut changed = data.clone();
        changed[n / 2] ^= 0xff;
        std::fs::write(&path, &changed).unwrap();
        let mut f = File::open(&path).unwrap();
        assert_ne!(hash_file(&mut f, false).unwrap(), sampled);

        let small = vec![9u8; 1000];
        std::fs::write(&path, &small).unwrap();
        let mut f = File::open(&path).unwrap();
        let a = hash_file(&mut f, false).unwrap();
        let mut f = File::open(&path).unwrap();
        let b = hash_file(&mut f, true).unwrap();
        assert_eq!(a, b);
        let _ = std::fs::remove_file(&path);
    }
}
