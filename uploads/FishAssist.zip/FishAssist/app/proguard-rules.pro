-keep class com.fishassist.app.** { *; }
-keepattributes *Annotation*
-keepclassmembers class * {
    @dagger.hilt.* *;
}
