package com.fishassist.app.vision

import android.graphics.Rect

/**
 * Calibration data learned by the user tapping screen elements.
 * All colours stored as ARGB ints from [android.graphics.Color].
 */
data class CalibrationData(
    /** Bounding rect of the fishing minigame on screen. */
    val minigameBounds: Rect = Rect(),
    /** Representative colour of the green catcher bar. */
    val barColor: Int = 0xFF4CAF50.toInt(),
    /** Representative colour of the fish icon. */
    val fishColor: Int = 0xFF2196F3.toInt(),
    /** Representative colour of the bite exclamation mark. */
    val biteColor: Int = 0xFFFFEB3B.toInt(),
    /** Radius (px) around a sample pixel to still call it a match. */
    val colorTolerance: Int = 35,
    val isComplete: Boolean = false
)
