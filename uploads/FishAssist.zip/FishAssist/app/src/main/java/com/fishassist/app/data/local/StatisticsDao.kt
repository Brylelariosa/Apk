package com.fishassist.app.data.local

import androidx.room.*
import com.fishassist.app.data.model.Statistics
import kotlinx.coroutines.flow.Flow

@Dao
interface StatisticsDao {
    @Query("SELECT * FROM statistics WHERE id = 1")
    fun observe(): Flow<Statistics?>

    @Query("SELECT * FROM statistics WHERE id = 1")
    suspend fun get(): Statistics?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: Statistics)

    @Query("DELETE FROM statistics")
    suspend fun reset()
}
