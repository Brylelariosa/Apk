package com.fishassist.app.data.model

/**
 * All user-configurable settings for the fishing bot.
 * Stored via DataStore; updated live without restarting services.
 */
data class Settings(
    /** How long (ms) to hold the cast button — controls cast distance. */
    val castPowerMs: Long = 800L,
    /** Min reaction delay (ms) after bite before the hook tap fires. */
    val reactionDelayMinMs: Long = 80L,
    /** Max reaction delay (ms) — actual delay is random in [min, max]. */
    val reactionDelayMaxMs: Long = 200L,
    /** Whether to use human-like randomised reaction timing. */
    val humanLikeDelay: Boolean = true,
    /** PID aggressiveness for the minigame bar tracker (0.1 – 2.0). */
    val trackingAggressiveness: Float = 1.0f,
    /** Bite-detection colour-match threshold fraction (0.01 – 1.0). */
    val detectionSensitivity: Float = 0.5f,
    /** Target FPS for frame analysis. */
    val targetFps: Int = 30,
    /** Reduce FPS to ~15 to save battery. */
    val batterySaverMode: Boolean = false,
    /** Run at full device capacity. */
    val performanceMode: Boolean = false,
    /** Auto-start automation when the overlay opens. */
    val autoStart: Boolean = false,
    /** Resume after game interruption (calls, notifications). */
    val autoResume: Boolean = true,
    /** PID difficulty profile. */
    val difficultyProfile: DifficultyProfile = DifficultyProfile.BALANCED,
    /** Cast distance profile. */
    val castProfile: CastProfile = CastProfile.MEDIUM
)

enum class DifficultyProfile(val kp: Float, val ki: Float, val kd: Float) {
    HUMAN(0.6f, 0.02f, 0.15f),
    BALANCED(1.0f, 0.05f, 0.25f),
    COMPETITIVE(1.5f, 0.08f, 0.35f),
    PERFECT(2.0f, 0.10f, 0.50f)
}

enum class CastProfile(val holdMs: Long) {
    SHORT(300L),
    MEDIUM(800L),
    LONG(1400L),
    MAX(2000L)
}
