package com.fishassist.app.ui.calibration

import android.graphics.Bitmap
import android.graphics.Rect
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fishassist.app.data.local.AppDataStore
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAL_BAR_CLR
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAL_BITE_CLR
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAL_BOUNDS
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAL_DONE
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAL_FISH_CLR
import com.fishassist.app.service.ScreenCaptureService
import com.fishassist.app.vision.CalibrationData
import com.fishassist.app.vision.FrameAnalyzer
import com.fishassist.app.vision.MinigameDetector
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class CalibrationStep { INTRO, TAP_BAR, TAP_FISH, TAP_BITE, SET_BOUNDS, DONE }

@HiltViewModel
class CalibrationViewModel @Inject constructor(
    private val store:          AppDataStore,
    private val frameAnalyzer:  FrameAnalyzer,
    private val minigameDetect: MinigameDetector
) : ViewModel() {

    private val _step    = MutableStateFlow(CalibrationStep.INTRO)
    val step: StateFlow<CalibrationStep> = _step.asStateFlow()

    private val _message = MutableStateFlow("Tap 'Next' to begin calibration.")
    val message: StateFlow<String> = _message.asStateFlow()

    private val _previewFrame = MutableStateFlow<Bitmap?>(null)
    val previewFrame: StateFlow<Bitmap?> = _previewFrame.asStateFlow()

    // Calibration values being built
    private var barColor  = 0xFF4CAF50.toInt()
    private var fishColor = 0xFF2196F3.toInt()
    private var biteColor = 0xFFFFEB3B.toInt()
    private var boundsTopLeft     = Pair(-1, -1)
    private var boundsBottomRight = Pair(-1, -1)

    init {
        viewModelScope.launch {
            ScreenCaptureService.frameFlow.collect { _previewFrame.value = it }
        }
    }

    fun advance() {
        _step.value = when (_step.value) {
            CalibrationStep.INTRO -> {
                _message.value = "Open Stardew Valley, start fishing, then TAP the green catcher bar on screen."
                CalibrationStep.TAP_BAR
            }
            CalibrationStep.TAP_BAR -> {
                _message.value = "Good. Now TAP the moving fish icon."
                CalibrationStep.TAP_FISH
            }
            CalibrationStep.TAP_FISH -> {
                _message.value = "Now wait for a bite and TAP the yellow '!' mark when it appears."
                CalibrationStep.TAP_BITE
            }
            CalibrationStep.TAP_BITE -> {
                boundsTopLeft = -1 to -1
                _message.value = "Tap the TOP-LEFT corner of the minigame box."
                CalibrationStep.SET_BOUNDS
            }
            CalibrationStep.SET_BOUNDS -> {
                saveCalibration()
                CalibrationStep.DONE
            }
            CalibrationStep.DONE -> CalibrationStep.DONE
        }
    }

    /** Called when the user taps on the preview image. x/y are in bitmap coordinates. */
    fun onTap(x: Int, y: Int) {
        val frame = _previewFrame.value ?: return
        val sampled = frameAnalyzer.sampleAverageColor(frame, x, y)
        when (_step.value) {
            CalibrationStep.TAP_BAR -> {
                barColor = sampled
                _message.value = "Bar colour captured (#%06X). Tap 'Next'.".format(sampled and 0xFFFFFF)
            }
            CalibrationStep.TAP_FISH -> {
                fishColor = sampled
                _message.value = "Fish colour captured (#%06X). Tap 'Next'.".format(sampled and 0xFFFFFF)
            }
            CalibrationStep.TAP_BITE -> {
                biteColor = sampled
                _message.value = "Bite colour captured (#%06X). Tap 'Next'.".format(sampled and 0xFFFFFF)
            }
            CalibrationStep.SET_BOUNDS -> {
                if (boundsTopLeft.first == -1) {
                    boundsTopLeft = x to y
                    _message.value = "Top-left set ($x, $y). Now tap the BOTTOM-RIGHT corner."
                } else {
                    boundsBottomRight = x to y
                    _message.value = "Bounds set (${boundsTopLeft} → ${boundsBottomRight}). Tap 'Finish'."
                }
            }
            else -> Unit
        }
    }

    private fun saveCalibration() {
        val bounds = if (boundsTopLeft.first >= 0 && boundsBottomRight.first >= 0)
            Rect(boundsTopLeft.first, boundsTopLeft.second,
                 boundsBottomRight.first, boundsBottomRight.second)
        else Rect()

        viewModelScope.launch {
            store.updateSettings { prefs ->
                prefs[KEY_CAL_BAR_CLR]  = barColor
                prefs[KEY_CAL_FISH_CLR] = fishColor
                prefs[KEY_CAL_BITE_CLR] = biteColor
                prefs[KEY_CAL_BOUNDS]   = "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"
                prefs[KEY_CAL_DONE]     = true
            }
            minigameDetect.calibration = CalibrationData(
                minigameBounds = bounds,
                barColor  = barColor,
                fishColor = fishColor,
                biteColor = biteColor,
                isComplete = true
            )
            _message.value = "Calibration complete! The bot will now use your colours."
        }
    }

    fun reset() {
        viewModelScope.launch { store.updateSettings { it[KEY_CAL_DONE] = false } }
        barColor  = 0xFF4CAF50.toInt()
        fishColor = 0xFF2196F3.toInt()
        biteColor = 0xFFFFEB3B.toInt()
        boundsTopLeft     = -1 to -1
        boundsBottomRight = -1 to -1
        _step.value    = CalibrationStep.INTRO
        _message.value = "Calibration reset. Tap 'Next' to recalibrate."
    }
}
