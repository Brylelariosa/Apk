package com.fishassist.app.data.repository

import androidx.datastore.preferences.core.*
import com.fishassist.app.data.local.AppDataStore
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_BATTERY
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAST_POWER
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_CAST_PROFILE
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_DELAY_MAX
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_DELAY_MIN
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_DETECT_SENS
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_DIFFICULTY
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_HUMAN_DELAY
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_PERFORMANCE
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_AUTO_START
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_AUTO_RESUME
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_TARGET_FPS
import com.fishassist.app.data.local.AppDataStore.Companion.KEY_TRACK_AGG
import com.fishassist.app.data.model.CastProfile
import com.fishassist.app.data.model.DifficultyProfile
import com.fishassist.app.data.model.Settings
import kotlinx.coroutines.flow.Flow

@Singleton
class SettingsRepository constructor(private val store: AppDataStore) {

    val settings: Flow<Settings> = store.settingsFlow

    suspend fun setCastPower(ms: Long)                = store.updateSettings { it[KEY_CAST_POWER] = ms }
    suspend fun setReactionMin(ms: Long)              = store.updateSettings { it[KEY_DELAY_MIN] = ms }
    suspend fun setReactionMax(ms: Long)              = store.updateSettings { it[KEY_DELAY_MAX] = ms }
    suspend fun setHumanDelay(enabled: Boolean)       = store.updateSettings { it[KEY_HUMAN_DELAY] = enabled }
    suspend fun setTrackingAgg(value: Float)          = store.updateSettings { it[KEY_TRACK_AGG] = value }
    suspend fun setDetectionSens(value: Float)        = store.updateSettings { it[KEY_DETECT_SENS] = value }
    suspend fun setTargetFps(fps: Int)                = store.updateSettings { it[KEY_TARGET_FPS] = fps }
    suspend fun setBatterySaver(enabled: Boolean)     = store.updateSettings { it[KEY_BATTERY] = enabled }
    suspend fun setPerformanceMode(enabled: Boolean)  = store.updateSettings { it[KEY_PERFORMANCE] = enabled }
    suspend fun setAutoStart(enabled: Boolean)        = store.updateSettings { it[KEY_AUTO_START] = enabled }
    suspend fun setAutoResume(enabled: Boolean)       = store.updateSettings { it[KEY_AUTO_RESUME] = enabled }
    suspend fun setDifficulty(p: DifficultyProfile)   = store.updateSettings { it[KEY_DIFFICULTY] = p.name }
    suspend fun setCastProfile(p: CastProfile)        = store.updateSettings { it[KEY_CAST_PROFILE] = p.name }
}
