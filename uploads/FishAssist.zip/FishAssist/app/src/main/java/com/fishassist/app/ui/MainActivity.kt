package com.fishassist.app.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.fishassist.app.R
import com.fishassist.app.databinding.ActivityMainBinding
import com.fishassist.app.service.OverlayService
import com.fishassist.app.service.ScreenCaptureService
import com.fishassist.app.util.PermissionHelper
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingCapture = false

    // MediaProjection permission launcher
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenCaptureService.start(this, result.resultCode, result.data!!)
            if (!OverlayService::class.java.name.isEmpty()) OverlayService.start(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHost = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        binding.bottomNav.setupWithNavController(navHost.navController)
    }

    /** Called by DashboardFragment when user taps "Start Capture". */
    fun requestScreenCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    /** Stop both services cleanly. */
    fun stopServices() {
        ScreenCaptureService.stop(this)
        OverlayService.stop(this)
    }

    /** Check all required permissions and return a list of what's missing. */
    fun missingPermissions(): List<String> = buildList {
        if (!PermissionHelper.hasOverlayPermission(this@MainActivity))     add("Draw over apps")
        if (!PermissionHelper.isAccessibilityEnabled(this@MainActivity))   add("Accessibility Service")
        if (!PermissionHelper.hasNotificationPermission(this@MainActivity)) add("Notifications")
    }
}
