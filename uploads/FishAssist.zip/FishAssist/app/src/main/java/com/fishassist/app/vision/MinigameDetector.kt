package com.fishassist.app.vision

import android.graphics.Bitmap
import android.graphics.Rect
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detects the state of the Stardew Valley fishing minigame.
 *
 * ## Coordinate convention
 * All Y positions are normalised to [0.0, 1.0] within [calibration.minigameBounds]:
 *   0.0 = top, 1.0 = bottom.
 *
 * ## How it works
 * The minigame is a vertical slot (dark-blue background) that appears
 * right-of-centre. Inside it:
 *  - Green bar  — player-controlled catcher
 *  - Fish icon  — target the PID must keep the bar aligned with
 *  - Progress meter — rightmost column, fills as bar overlaps fish
 *
 * Colours are learned during calibration; defaults are reasonable first
 * guesses for Pixel-class devices at default brightness.
 */
@Singleton
class MinigameDetector @Inject constructor(private val analyzer: FrameAnalyzer) {

    var calibration: CalibrationData = CalibrationData()

    // ── Minigame presence ──────────────────────────────────────────

    fun isMinigameVisible(frame: Bitmap): Boolean {
        val bounds = calibration.minigameBounds.takeIf { !it.isEmpty }
            ?: defaultBounds(frame)
        val darkBlue = 0xFF1A2A4A.toInt()
        val matches  = analyzer.countMatchingPixels(frame, bounds, darkBlue, 50,
            FrameAnalyzer.STRIDE_COARSE)
        val s = FrameAnalyzer.STRIDE_COARSE
        val totalSampled = (bounds.width() / s) * (bounds.height() / s)
        return totalSampled > 0 && matches.toFloat() / totalSampled > 0.15f
    }

    // ── Bar position ───────────────────────────────────────────────

    /** Normalised centre-Y of the green catcher bar, or null if not found. */
    fun findBarPosition(frame: Bitmap): Float? {
        val bounds = calibration.minigameBounds.takeIf { !it.isEmpty } ?: return null
        return analyzer.findCentroidY(
            frame, bounds, calibration.barColor, calibration.colorTolerance,
            minFraction = 0.005f, stride = FrameAnalyzer.STRIDE_FINE
        )?.let { analyzer.normaliseY(it, bounds) }
    }

    /** Normalised height fraction of the green bar. */
    fun findBarSize(frame: Bitmap): Float {
        val bounds = calibration.minigameBounds.takeIf { !it.isEmpty } ?: return 0.2f
        val ext = analyzer.findVerticalExtent(
            frame, bounds, bounds.centerX(), calibration.barColor, calibration.colorTolerance
        ) ?: return 0.2f
        return (ext.second - ext.first).toFloat() / bounds.height()
    }

    // ── Fish position ──────────────────────────────────────────────

    /** Normalised Y of the fish icon, or null if not found. */
    fun findFishPosition(frame: Bitmap): Float? {
        val bounds = calibration.minigameBounds.takeIf { !it.isEmpty } ?: return null
        val fishRegion = Rect(bounds.left, bounds.top,
            bounds.left + (bounds.width() * 0.6f).toInt(), bounds.bottom)
        return analyzer.findCentroidY(
            frame, fishRegion, calibration.fishColor, calibration.colorTolerance,
            minFraction = 0.003f, stride = FrameAnalyzer.STRIDE_FINE
        )?.let { analyzer.normaliseY(it, bounds) }
    }

    // ── Catch progress ─────────────────────────────────────────────

    /** Catch progress fraction [0.0, 1.0]. */
    fun estimateCatchProgress(frame: Bitmap): Float {
        val bounds = calibration.minigameBounds.takeIf { !it.isEmpty } ?: return 0f
        val meterRegion = Rect(
            bounds.right - (bounds.width() * 0.15f).toInt(), bounds.top,
            bounds.right, bounds.bottom
        )
        val matches = analyzer.countMatchingPixels(
            frame, meterRegion, 0xFF76C442.toInt(), 60, FrameAnalyzer.STRIDE_FINE
        )
        val total = meterRegion.width() * meterRegion.height()
        return if (total > 0) (matches.toFloat() / total).coerceIn(0f, 1f) else 0f
    }

    // ── Full snapshot ──────────────────────────────────────────────

    fun analyze(frame: Bitmap): MinigameState {
        if (!isMinigameVisible(frame)) return MinigameState.NOT_VISIBLE
        return MinigameState(
            visible  = true,
            barPos   = findBarPosition(frame),
            barSize  = findBarSize(frame),
            fishPos  = findFishPosition(frame),
            progress = estimateCatchProgress(frame)
        )
    }

    private fun defaultBounds(frame: Bitmap) = Rect(
        frame.width / 2, frame.height / 8,
        (frame.width * 0.85f).toInt(), (frame.height * 0.85f).toInt()
    )
}

data class MinigameState(
    val visible:  Boolean = false,
    val barPos:   Float?  = null,
    val barSize:  Float   = 0.2f,
    val fishPos:  Float?  = null,
    val progress: Float   = 0f
) {
    val isCaught get() = progress >= 0.95f
    companion object { val NOT_VISIBLE = MinigameState() }
}
