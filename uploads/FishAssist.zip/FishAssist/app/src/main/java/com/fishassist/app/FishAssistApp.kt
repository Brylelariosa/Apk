package com.fishassist.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

@HiltAndroidApp
class FishAssistApp : Application() {
    val appScope = CoroutineScope(SupervisorJob())
}
