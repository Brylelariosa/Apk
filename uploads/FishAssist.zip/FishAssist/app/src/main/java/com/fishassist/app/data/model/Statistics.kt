package com.fishassist.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "statistics")
data class Statistics(
    @PrimaryKey val id: Int = 1,
    val totalFishCaught: Long = 0L,
    val totalMissed: Long = 0L,
    val totalSessionMs: Long = 0L,
    val totalReactionTimeMs: Long = 0L,
    val reactionSamples: Long = 0L,
    val detectionFpsSum: Float = 0f,
    val fpsSamples: Long = 0L
) {
    val catchRate: Float
        get() = if (totalFishCaught + totalMissed > 0)
            totalFishCaught.toFloat() / (totalFishCaught + totalMissed) * 100f
        else 0f

    val avgReactionMs: Float
        get() = if (reactionSamples > 0) totalReactionTimeMs.toFloat() / reactionSamples else 0f

    val avgDetectionFps: Float
        get() = if (fpsSamples > 0) detectionFpsSum / fpsSamples else 0f

    val sessionFormatted: String
        get() {
            val s = totalSessionMs / 1000
            return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
        }
}
