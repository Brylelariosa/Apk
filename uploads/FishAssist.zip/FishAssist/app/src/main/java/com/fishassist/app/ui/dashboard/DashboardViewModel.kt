package com.fishassist.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fishassist.app.automation.FishingStateMachine
import com.fishassist.app.automation.OverlayUiState
import com.fishassist.app.data.model.LogEntry
import com.fishassist.app.data.repository.StatisticsRepository
import com.fishassist.app.service.FishingAccessibilityService
import com.fishassist.app.service.ScreenCaptureService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val stateMachine: FishingStateMachine,
    private val statsRepo:    StatisticsRepository
) : ViewModel() {

    val uiState: StateFlow<OverlayUiState> = stateMachine.uiState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), OverlayUiState())

    val logs: StateFlow<List<LogEntry>> = stateMachine.logs
        .runningFold(emptyList<LogEntry>()) { acc, entry -> (listOf(entry) + acc).take(200) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val isCaptureRunning: StateFlow<Boolean> = ScreenCaptureService.frameFlow
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val isAccessibilityReady: StateFlow<Boolean> = flow {
        // Poll every 2 seconds — accessibility doesn't have a broadcast
        while (true) {
            emit(FishingAccessibilityService.isConnected)
            kotlinx.coroutines.delay(2_000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun start() { stateMachine.start() }
    fun pause() { stateMachine.pause() }
    fun stop()  { stateMachine.stop()  }
}
