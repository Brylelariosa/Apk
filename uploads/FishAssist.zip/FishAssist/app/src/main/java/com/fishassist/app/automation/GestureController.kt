package com.fishassist.app.automation

import android.util.Log
import com.fishassist.app.service.FishingAccessibilityService
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Thin suspending wrapper around [FishingAccessibilityService] gesture primitives.
 * Injected as a singleton so the state machine always uses the same instance.
 */
@Singleton
class GestureController @Inject constructor() {

    companion object { private const val TAG = "GestureCtrl" }

    val isReady get() = FishingAccessibilityService.isConnected

    /** Single tap at absolute screen coordinates [x],[y]. */
    suspend fun tap(x: Float, y: Float): Boolean {
        val svc = FishingAccessibilityService.instance
            ?: run { Log.w(TAG, "tap(): no service"); return false }
        return suspendCancellableCoroutine { cont ->
            svc.tap(x, y) { ok -> if (cont.isActive) cont.resume(ok) }
        }
    }

    /**
     * Press-and-hold at [x],[y] for [durationMs] ms.
     * Used for cast power and PID pressing.
     */
    suspend fun hold(x: Float, y: Float, durationMs: Long): Boolean {
        val svc = FishingAccessibilityService.instance
            ?: run { Log.w(TAG, "hold(): no service"); return false }
        return suspendCancellableCoroutine { cont ->
            svc.hold(x, y, durationMs) { ok -> if (cont.isActive) cont.resume(ok) }
        }
    }

    /** Swipe between two points. */
    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300L): Boolean {
        val svc = FishingAccessibilityService.instance
            ?: run { Log.w(TAG, "swipe(): no service"); return false }
        return suspendCancellableCoroutine { cont ->
            svc.swipe(x1, y1, x2, y2, durationMs) { ok -> if (cont.isActive) cont.resume(ok) }
        }
    }
}
