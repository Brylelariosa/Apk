package com.fishassist.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility Service that provides gesture injection for automation.
 *
 * Exposes a singleton [instance] so [GestureController] can call
 * [dispatchGesture] without a service binding round-trip.
 */
class FishingAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "FishA11y"

        /** Singleton reference set when the service connects. */
        @Volatile
        var instance: FishingAccessibilityService? = null
            private set

        val isConnected: Boolean get() = instance != null
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We don't consume any events — pure gesture injection only.
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        instance = null
        Log.i(TAG, "Accessibility service destroyed")
        super.onDestroy()
    }

    // ──────────────────────────────────────────────────────────────
    // Gesture helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Simulate a tap at [x],[y].
     * [onComplete] called on main thread with success flag.
     */
    fun tap(x: Float, y: Float, onComplete: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                onComplete?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription) {
                onComplete?.invoke(false)
            }
        }, mainHandler)
    }

    /**
     * Simulate a press-and-hold at [x],[y] for [durationMs] ms.
     * Used to control cast power.
     */
    fun hold(x: Float, y: Float, durationMs: Long, onComplete: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(50L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                onComplete?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription) {
                onComplete?.invoke(false)
            }
        }, mainHandler)
    }

    /**
     * Swipe from [x1],[y1] to [x2],[y2] over [durationMs] ms.
     */
    fun swipe(
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        durationMs: Long = 300L,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                onComplete?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription) {
                onComplete?.invoke(false)
            }
        }, mainHandler)
    }
}
