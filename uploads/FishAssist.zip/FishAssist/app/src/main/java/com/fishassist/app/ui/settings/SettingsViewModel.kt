package com.fishassist.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fishassist.app.data.model.CastProfile
import com.fishassist.app.data.model.DifficultyProfile
import com.fishassist.app.data.model.Settings
import com.fishassist.app.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repo: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<Settings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Settings())

    fun setCastProfile(p: CastProfile)        = viewModelScope.launch { repo.setCastProfile(p) }
    fun setDifficulty(p: DifficultyProfile)   = viewModelScope.launch { repo.setDifficulty(p) }
    fun setReactionMin(ms: Long)              = viewModelScope.launch { repo.setReactionMin(ms) }
    fun setReactionMax(ms: Long)              = viewModelScope.launch { repo.setReactionMax(ms) }
    fun setHumanDelay(v: Boolean)             = viewModelScope.launch { repo.setHumanDelay(v) }
    fun setTrackingAgg(v: Float)              = viewModelScope.launch { repo.setTrackingAgg(v) }
    fun setDetectionSens(v: Float)            = viewModelScope.launch { repo.setDetectionSens(v) }
    fun setTargetFps(fps: Int)                = viewModelScope.launch { repo.setTargetFps(fps) }
    fun setBatterySaver(v: Boolean)           = viewModelScope.launch { repo.setBatterySaver(v) }
    fun setAutoStart(v: Boolean)              = viewModelScope.launch { repo.setAutoStart(v) }
    fun setAutoResume(v: Boolean)             = viewModelScope.launch { repo.setAutoResume(v) }
}
