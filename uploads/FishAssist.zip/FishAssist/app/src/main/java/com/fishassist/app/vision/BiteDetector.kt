package com.fishassist.app.vision

import android.graphics.Bitmap
import android.graphics.Rect
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detects fish bite events by scanning for the bright yellow "!" indicator
 * that appears above the bobber in Stardew Valley Mobile.
 *
 * Two-pass strategy:
 *  1. Coarse pass — fast pixel count over the full bite region.
 *  2. Confirmation — requires [BITE_CONFIRM_MIN] consecutive detections
 *     (enforced by [FishingStateMachine]) to avoid false positives.
 */
@Singleton
class BiteDetector @Inject constructor(private val analyzer: FrameAnalyzer) {

    companion object {
        // Stardew Valley "!" colour: high R, high G, low B
        private const val BITE_R_MIN  = 200
        private const val BITE_G_MIN  = 180
        private const val BITE_B_MAX  = 80
        private const val SCAN_TOP    = 0.10f
        private const val SCAN_BOTTOM = 0.55f
    }

    /** Minimum fraction of sampled pixels that must match to fire a detection. */
    var sensitivityFraction: Float = 0.012f

    /**
     * Scan [frame] for a bite indicator.
     *
     * @param frame      Current screen bitmap.
     * @param biteRegion Override scan region; defaults to top 55% of screen.
     */
    fun detect(frame: Bitmap, biteRegion: Rect? = null): BiteResult {
        val region = biteRegion ?: Rect(
            0, (frame.height * SCAN_TOP).toInt(),
            frame.width, (frame.height * SCAN_BOTTOM).toInt()
        )
        var matches = 0; var sampled = 0
        val stride  = FrameAnalyzer.STRIDE_COARSE
        val xEnd    = region.right.coerceAtMost(frame.width)
        val yEnd    = region.bottom.coerceAtMost(frame.height)
        var y = region.top.coerceAtLeast(0)
        while (y < yEnd) {
            var x = region.left.coerceAtLeast(0)
            while (x < xEnd) {
                val px = frame.getPixel(x, y)
                if (isBiteColour(px)) matches++
                sampled++
                x += stride
            }
            y += stride
        }
        val confidence = if (sampled > 0) matches.toFloat() / sampled else 0f
        return BiteResult(confidence >= sensitivityFraction, confidence, region)
    }

    private fun isBiteColour(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8)  and 0xFF
        val b =  c         and 0xFF
        return r >= BITE_R_MIN && g >= BITE_G_MIN && b <= BITE_B_MAX
    }
}

data class BiteResult(
    val detected:   Boolean,
    val confidence: Float,
    val scanRegion: Rect
)
