package com.fishassist.app.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fishassist.app.databinding.FragmentDashboardBinding
import com.fishassist.app.ui.MainActivity
import com.fishassist.app.ui.logs.LogAdapter
import com.fishassist.app.util.collectFlow
import com.fishassist.app.util.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private val vm: DashboardViewModel by viewModels()
    private var _b: FragmentDashboardBinding? = null
    private val b get() = _b!!
    private val logAdapter = LogAdapter()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentDashboardBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.rvLogs.adapter = logAdapter
        b.rvLogs.itemAnimator = null  // prevent flicker on rapid log updates

        // Permission status badges
        collectFlow(vm.isAccessibilityReady) { ready ->
            b.badgeAccessibility.text = if (ready) "✓ Accessibility" else "✗ Accessibility"
            b.badgeAccessibility.setBackgroundColor(
                if (ready) 0xFF4CAF50.toInt() else 0xFFF44336.toInt()
            )
        }
        collectFlow(vm.isCaptureRunning) { running ->
            b.badgeCapture.text = if (running) "✓ Screen Capture" else "✗ Screen Capture"
            b.badgeCapture.setBackgroundColor(
                if (running) 0xFF4CAF50.toInt() else 0xFFF44336.toInt()
            )
        }

        // Main state
        collectFlow(vm.uiState) { ui ->
            b.tvStateLabel.text  = ui.stateLabel
            b.tvFps.text         = "%.1f fps".format(ui.detectionFps)
            b.tvConfidence.text  = "Confidence: %.0f%%".format(ui.confidence * 100)
            b.btnStart.isEnabled = !ui.isRunning
            b.btnPause.isEnabled = ui.isRunning
            b.btnStop.isEnabled  = ui.isRunning || ui.isPaused
        }

        // Logs
        collectFlow(vm.logs) { entries ->
            logAdapter.submitList(entries)
            if (entries.isNotEmpty()) b.rvLogs.scrollToPosition(0)
        }

        // Control buttons
        b.btnStart.setOnClickListener {
            val missing = (requireActivity() as MainActivity).missingPermissions()
            if (missing.isNotEmpty()) {
                toast("Missing permissions: ${missing.joinToString()}", long = true)
                return@setOnClickListener
            }
            (requireActivity() as MainActivity).requestScreenCapture()
            vm.start()
        }
        b.btnPause.setOnClickListener { vm.pause() }
        b.btnStop.setOnClickListener  {
            vm.stop()
            (requireActivity() as MainActivity).stopServices()
        }
    }

    private fun toast(msg: String, long: Boolean = false) =
        requireContext().let {
            android.widget.Toast.makeText(it, msg,
                if (long) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT
            ).show()
        }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
