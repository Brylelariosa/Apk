package com.fishassist.app.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fishassist.app.data.model.CastProfile
import com.fishassist.app.data.model.DifficultyProfile
import com.fishassist.app.databinding.FragmentSettingsBinding
import com.fishassist.app.util.collectFlow
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private val vm: SettingsViewModel by viewModels()
    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!
    private var ignoreCallbacks = false

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSettingsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Spinners
        b.spinnerCast.adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_item,
            CastProfile.values().map { it.name }).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        b.spinnerDifficulty.adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_item,
            DifficultyProfile.values().map { it.name }).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // Load current settings → populate UI
        collectFlow(vm.settings) { s ->
            ignoreCallbacks = true
            b.spinnerCast.setSelection(CastProfile.values().indexOf(s.castProfile))
            b.spinnerDifficulty.setSelection(DifficultyProfile.values().indexOf(s.difficultyProfile))
            b.seekTrackingAgg.progress = (s.trackingAggressiveness * 50).toInt()
            b.seekDetectSens.progress  = (s.detectionSensitivity   * 100).toInt()
            b.seekFps.progress         = s.targetFps
            b.switchHumanDelay.isChecked  = s.humanLikeDelay
            b.switchBatterySaver.isChecked = s.batterySaverMode
            b.switchAutoStart.isChecked   = s.autoStart
            b.switchAutoResume.isChecked  = s.autoResume
            b.tvReactionRange.text =
                "Reaction: ${s.reactionDelayMinMs}–${s.reactionDelayMaxMs} ms"
            ignoreCallbacks = false
        }

        // Spinner listeners
        b.spinnerCast.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (!ignoreCallbacks) vm.setCastProfile(CastProfile.values()[pos])
            }
        }
        b.spinnerDifficulty.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (!ignoreCallbacks) vm.setDifficulty(DifficultyProfile.values()[pos])
            }
        }

        // SeekBar + switch listeners
        b.seekTrackingAgg.setOnSeekBarChangeListener(seekListener { vm.setTrackingAgg(it / 50f) })
        b.seekDetectSens.setOnSeekBarChangeListener(seekListener  { vm.setDetectionSens(it / 100f) })
        b.seekFps.setOnSeekBarChangeListener(seekListener         { vm.setTargetFps(it.coerceAtLeast(5)) })
        b.switchHumanDelay.setOnCheckedChangeListener   { _, v -> if (!ignoreCallbacks) vm.setHumanDelay(v) }
        b.switchBatterySaver.setOnCheckedChangeListener { _, v -> if (!ignoreCallbacks) vm.setBatterySaver(v) }
        b.switchAutoStart.setOnCheckedChangeListener    { _, v -> if (!ignoreCallbacks) vm.setAutoStart(v) }
        b.switchAutoResume.setOnCheckedChangeListener   { _, v -> if (!ignoreCallbacks) vm.setAutoResume(v) }
    }

    private fun seekListener(action: (Int) -> Unit) = object : android.widget.SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser && !ignoreCallbacks) action(progress)
        }
        override fun onStartTrackingTouch(p0: android.widget.SeekBar?) {}
        override fun onStopTrackingTouch(p0: android.widget.SeekBar?)  {}
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
