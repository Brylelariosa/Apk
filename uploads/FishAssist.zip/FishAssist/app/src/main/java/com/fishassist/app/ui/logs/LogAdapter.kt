package com.fishassist.app.ui.logs

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fishassist.app.data.model.LogEntry
import com.fishassist.app.databinding.ItemLogBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogAdapter : ListAdapter<LogEntry, LogAdapter.VH>(DIFF) {

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    inner class VH(val b: ItemLogBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemLogBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = getItem(position)
        holder.b.tvTime.text    = timeFmt.format(Date(entry.timestamp))
        holder.b.tvMessage.text = entry.message
        val color = when (entry.level) {
            LogEntry.Level.DEBUG -> 0xFF9E9E9E.toInt()
            LogEntry.Level.INFO  -> 0xFFE0E0E0.toInt()
            LogEntry.Level.WARN  -> 0xFFFF9800.toInt()
            LogEntry.Level.ERROR -> 0xFFF44336.toInt()
        }
        holder.b.tvMessage.setTextColor(color)
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<LogEntry>() {
            override fun areItemsTheSame(a: LogEntry, b: LogEntry) = a.timestamp == b.timestamp
            override fun areContentsTheSame(a: LogEntry, b: LogEntry) = a == b
        }
    }
}
