package com.fishassist.app.di

import android.content.Context
import com.fishassist.app.data.local.AppDataStore
import com.fishassist.app.data.local.AppDatabase
import com.fishassist.app.data.local.StatisticsDao
import com.fishassist.app.data.repository.SettingsRepository
import com.fishassist.app.data.repository.StatisticsRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module for bindings that require manual construction.
 *
 * Classes annotated with @Inject constructor are auto-provided by Hilt
 * and must NOT have a matching @Provides here — so FrameAnalyzer,
 * GestureController, MinigameDetector, BiteDetector, and
 * FishingStateMachine are all wired via their constructors.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideAppDataStore(@ApplicationContext ctx: Context): AppDataStore =
        AppDataStore(ctx)

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        AppDatabase.create(ctx)

    @Provides @Singleton
    fun provideStatisticsDao(db: AppDatabase): StatisticsDao =
        db.statisticsDao()

    @Provides @Singleton
    fun provideSettingsRepository(store: AppDataStore): SettingsRepository =
        SettingsRepository(store)

    @Provides @Singleton
    fun provideStatisticsRepository(dao: StatisticsDao): StatisticsRepository =
        StatisticsRepository(dao)
}
