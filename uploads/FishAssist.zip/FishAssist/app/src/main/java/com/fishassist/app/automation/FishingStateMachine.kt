package com.fishassist.app.automation

import android.graphics.Bitmap
import android.util.Log
import com.fishassist.app.data.model.DifficultyProfile
import com.fishassist.app.data.model.LogEntry
import com.fishassist.app.data.model.Settings
import com.fishassist.app.data.repository.SettingsRepository
import com.fishassist.app.data.repository.StatisticsRepository
import com.fishassist.app.service.ScreenCaptureService
import com.fishassist.app.vision.BiteDetector
import com.fishassist.app.vision.MinigameDetector
import com.fishassist.app.vision.PIDController
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Central automation engine.
 *
 * Drives the [FishingState] state machine by consuming screen frames from
 * [ScreenCaptureService.frameFlow], running CV detectors, and dispatching
 * gestures via [GestureController].
 *
 * ## Thread safety
 * The main coroutine runs on [Dispatchers.Default]. All public functions
 * are thread-safe; state is exposed only through [StateFlow].
 */
@Singleton
class FishingStateMachine @Inject constructor(
    private val settingsRepo:    SettingsRepository,
    private val statsRepo:       StatisticsRepository,
    private val biteDetector:    BiteDetector,
    private val minigameDetect:  MinigameDetector,
    private val gestureCtrl:     GestureController
) {
    companion object {
        private const val TAG               = "FishSM"
        private const val PID_INTERVAL_MS   = 80L
        private const val BITE_CONFIRM_N    = 2
        private const val BOBBER_TIMEOUT_MS = 6_000L
        private const val BITE_TIMEOUT_MS   = 45_000L
        private const val CAST_X_FRAC       = 0.5f
        private const val CAST_Y_FRAC       = 0.5f
    }

    // ── Public state ───────────────────────────────────────────────
    private val _state   = MutableStateFlow<FishingState>(FishingState.Idle)
    val state: StateFlow<FishingState> = _state.asStateFlow()

    private val _logs    = MutableSharedFlow<LogEntry>(replay = 100, extraBufferCapacity = 50)
    val logs: SharedFlow<LogEntry> = _logs.asSharedFlow()

    private val _uiState = MutableStateFlow(OverlayUiState())
    val uiState: StateFlow<OverlayUiState> = _uiState.asStateFlow()

    // ── Internal fields ────────────────────────────────────────────
    private val scope          = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob:      Job? = null
    private var settings       = Settings()
    private var screenW        = 1080
    private var screenH        = 1920
    private val pid            = PIDController()

    // FPS tracking
    private var lastFrameMs    = 0L
    private var fpsCurrent     = 0f

    // Bite confirmation counter
    private var biteFrames     = 0
    private var biteStartMs    = 0L

    // PID state
    private var lastPidMs      = 0L
    private var isPressingScreen = false
    private var stateEntryMs   = 0L
    private var sessionStartMs = 0L

    // ── Lifecycle ──────────────────────────────────────────────────

    fun start() {
        if (_state.value.isActive) return
        sessionStartMs = System.currentTimeMillis()
        loopJob?.cancel()
        scope.launch { settingsRepo.settings.take(1).collect { settings = it } }
        transition(FishingState.DetectingGame)
        loopJob = scope.launch { runLoop() }
        log("Automation started")
    }

    fun pause() {
        if (_state.value !is FishingState.MinigameActive &&
            _state.value !is FishingState.WaitingBite    &&
            _state.value !is FishingState.WaitingBobber) return
        loopJob?.cancel()
        transition(FishingState.Paused)
        log("Paused")
    }

    fun resume() {
        if (_state.value !is FishingState.Paused) return
        transition(FishingState.Casting)
        loopJob = scope.launch { runLoop() }
        log("Resumed")
    }

    fun stop() {
        loopJob?.cancel()
        scope.launch {
            val elapsed = System.currentTimeMillis() - sessionStartMs
            if (elapsed > 0) statsRepo.addSessionTime(elapsed)
        }
        isPressingScreen = false
        pid.reset(); biteFrames = 0
        transition(FishingState.Idle)
        log("Stopped")
    }

    // ── Main loop ──────────────────────────────────────────────────

    private suspend fun runLoop() {
        // Keep settings fresh in background
        scope.launch {
            settingsRepo.settings.collect { s ->
                settings = s
                biteDetector.sensitivityFraction = s.detectionSensitivity * 0.02f
                applyDifficulty(s.difficultyProfile)
            }
        }
        ScreenCaptureService.frameFlow
            .filterNotNull()
            .collect { frame ->
                screenW = frame.width
                screenH = frame.height
                trackFps()
                processFrame(frame)
            }
    }

    // ── Frame dispatcher ───────────────────────────────────────────

    private suspend fun processFrame(frame: Bitmap) {
        when (val st = _state.value) {
            is FishingState.DetectingGame  -> onDetectingGame()
            is FishingState.Casting        -> onCasting()
            is FishingState.WaitingBobber  -> onWaitingBobber()
            is FishingState.WaitingBite    -> onWaitingBite(frame)
            is FishingState.Hooking        -> { /* gesture in flight */ }
            is FishingState.MinigameActive -> onMinigame(frame, st)
            is FishingState.Collecting     -> onCollecting()
            else -> Unit
        }
    }

    // ── State handlers ─────────────────────────────────────────────

    private suspend fun onDetectingGame() {
        // Simple presence heuristic: if frames are flowing, game is visible.
        delay(500)
        log("Game detected — casting")
        transition(FishingState.Casting)
    }

    private suspend fun onCasting() {
        val holdMs = settings.castProfile.holdMs
        log("Casting (${holdMs}ms hold)")
        transition(FishingState.WaitingBobber)
        val cx = screenW * CAST_X_FRAC
        val cy = screenH * CAST_Y_FRAC
        gestureCtrl.hold(cx, cy, holdMs)
    }

    private suspend fun onWaitingBobber() {
        val elapsed = System.currentTimeMillis() - stateEntryMs
        when {
            elapsed > BOBBER_TIMEOUT_MS -> {
                log("Bobber timeout — recasting", LogEntry.Level.WARN)
                transition(FishingState.Casting)
            }
            elapsed > 1_500 -> {
                log("Bobber landed — watching for bite")
                biteFrames = 0
                transition(FishingState.WaitingBite)
            }
        }
    }

    private suspend fun onWaitingBite(frame: Bitmap) {
        val elapsed = System.currentTimeMillis() - stateEntryMs
        if (elapsed > BITE_TIMEOUT_MS) {
            log("Bite timeout — recasting", LogEntry.Level.WARN)
            scope.launch { statsRepo.recordMiss() }
            transition(FishingState.Casting)
            return
        }
        val result = biteDetector.detect(frame)
        updateConfidence(result.confidence)
        if (result.detected) {
            biteFrames++
            if (biteFrames >= BITE_CONFIRM_N) {
                biteFrames   = 0
                biteStartMs  = System.currentTimeMillis()
                log("Bite confirmed! Hooking…")
                transition(FishingState.Hooking)
                hookFish()
            }
        } else {
            biteFrames = 0
        }
    }

    private suspend fun hookFish() {
        val delay = if (settings.humanLikeDelay)
            Random.nextLong(settings.reactionDelayMinMs, settings.reactionDelayMaxMs + 1)
        else
            settings.reactionDelayMinMs
        delay(delay)
        gestureCtrl.tap(screenW * CAST_X_FRAC, screenH * CAST_Y_FRAC)
        delay(600)   // wait for minigame to open
        pid.reset(); isPressingScreen = false; lastPidMs = 0L
        transition(FishingState.MinigameActive())
        log("Minigame started")
    }

    private suspend fun onMinigame(frame: Bitmap, state: FishingState.MinigameActive) {
        val mg = minigameDetect.analyze(frame)
        if (!mg.visible) {
            if (System.currentTimeMillis() - state.startMs > 1_500) {
                log("Minigame ended")
                transition(FishingState.Collecting)
            }
            return
        }
        if (mg.isCaught) {
            val reactionMs = System.currentTimeMillis() - biteStartMs
            scope.launch { statsRepo.recordCatch(reactionMs, fpsCurrent) }
            updateFishCount()
            log("Fish caught! 🎣")
            transition(FishingState.Collecting)
            return
        }

        // Rate-limit PID decisions
        val now = System.currentTimeMillis()
        if (now - lastPidMs < PID_INTERVAL_MS) return
        val dt = ((now - lastPidMs) / 1000f).coerceIn(0.001f, 0.5f)
        lastPidMs = now

        val fishPos = mg.fishPos ?: return
        val barPos  = mg.barPos  ?: 0.5f
        val output  = pid.compute(fishPos, barPos, dt)
        updateConfidence(1f - kotlin.math.abs(fishPos - barPos))

        val cx = screenW * CAST_X_FRAC
        val cy = screenH * CAST_Y_FRAC
        if (output > pid.deadband && !isPressingScreen) {
            isPressingScreen = true
            gestureCtrl.hold(cx, cy, PID_INTERVAL_MS * 3)
        } else if (output < -pid.deadband && isPressingScreen) {
            isPressingScreen = false
            // Release = just stop holding; no explicit action needed
        }
    }

    private suspend fun onCollecting() {
        delay(1_200)   // collection animation
        log("Recasting…")
        transition(FishingState.Casting)
    }

    // ── Helpers ────────────────────────────────────────────────────

    private fun transition(next: FishingState) {
        stateEntryMs = System.currentTimeMillis()
        _state.value = next
        _uiState.value = _uiState.value.copy(
            stateLabel = next.label,
            isRunning  = next.isActive && next !is FishingState.Paused,
            isPaused   = next is FishingState.Paused
        )
        Log.d(TAG, "→ ${next.label}")
    }

    private fun log(msg: String, level: LogEntry.Level = LogEntry.Level.INFO) {
        _logs.tryEmit(LogEntry(message = msg, level = level))
        Log.i(TAG, msg)
    }

    private fun trackFps() {
        val now = System.currentTimeMillis()
        if (lastFrameMs > 0) {
            fpsCurrent = (1000f / (now - lastFrameMs).coerceAtLeast(1))
            _uiState.value = _uiState.value.copy(detectionFps = fpsCurrent)
        }
        lastFrameMs = now
    }

    private fun updateConfidence(c: Float) {
        _uiState.value = _uiState.value.copy(confidence = c.coerceIn(0f, 1f))
    }

    private fun updateFishCount() {
        _uiState.value = _uiState.value.copy(fishCaught = _uiState.value.fishCaught + 1)
    }

    private fun applyDifficulty(p: DifficultyProfile) {
        pid.kp = p.kp * settings.trackingAggressiveness
        pid.ki = p.ki
        pid.kd = p.kd
    }
}

/** State consumed by [OverlayService] and the dashboard. */
data class OverlayUiState(
    val stateLabel:   String  = "Idle",
    val isRunning:    Boolean = false,
    val isPaused:     Boolean = false,
    val detectionFps: Float   = 0f,
    val fishCaught:   Long    = 0L,
    val confidence:   Float   = 0f
)
