package com.fishassist.app.vision

/**
 * Generic discrete PID controller used to keep the fishing bar
 * centred on the fish position.
 *
 * Output interpretation:
 *   > +[deadband]  → press screen (bar moves up)
 *   < -[deadband]  → release (bar falls with gravity)
 *   within band    → maintain current press state
 */
class PIDController(
    var kp: Float = 1.0f,
    var ki: Float = 0.05f,
    var kd: Float = 0.25f,
    val deadband: Float = 0.05f,
    val integralClamp: Float = 0.5f
) {
    private var integral   = 0f
    private var lastError  = 0f
    private var lastOutput = 0f

    /**
     * @param setpoint  Desired position (0.0 = top, 1.0 = bottom)
     * @param measured  Current bar-centre position
     * @param dt        Time delta in seconds since last call
     * @return output in [-1, +1] range
     */
    fun compute(setpoint: Float, measured: Float, dt: Float): Float {
        val error = setpoint - measured
        integral = (integral + error * dt).coerceIn(-integralClamp, integralClamp)
        val derivative = if (dt > 0f) (error - lastError) / dt else 0f
        lastError  = error
        lastOutput = (kp * error + ki * integral + kd * derivative).coerceIn(-1f, 1f)
        return lastOutput
    }

    /** Reset integrator and history (call on state transitions). */
    fun reset() {
        integral   = 0f
        lastError  = 0f
        lastOutput = 0f
    }

    val lastOutputValue get() = lastOutput
}
