package com.fishassist.app.util

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.fishassist.app.service.FishingAccessibilityService

object PermissionHelper {

    /** True when SYSTEM_ALERT_WINDOW ("draw over other apps") is granted. */
    fun hasOverlayPermission(ctx: Context): Boolean =
        Settings.canDrawOverlays(ctx)

    /** Intent to open the "draw over other apps" settings screen. */
    fun overlayPermissionIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${ctx.packageName}"))

    /** True when our Accessibility Service is enabled AND connected. */
    fun isAccessibilityEnabled(ctx: Context): Boolean {
        if (FishingAccessibilityService.isConnected) return true
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return list.any { it.resolveInfo.serviceInfo.packageName == ctx.packageName }
    }

    /** Intent to open Accessibility Settings. */
    fun accessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    /** True when POST_NOTIFICATIONS is granted (Android 13+). */
    fun hasNotificationPermission(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
        } else true
}
