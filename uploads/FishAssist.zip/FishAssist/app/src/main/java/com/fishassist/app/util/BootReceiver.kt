package com.fishassist.app.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receives BOOT_COMPLETED. Auto-start is intentionally NOT implemented here
 * to avoid nuisance behaviour — the manifest declaration exists to allow
 * future opt-in via a user setting.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.i("BootReceiver", "Boot completed — auto-start disabled by default")
        }
    }
}
