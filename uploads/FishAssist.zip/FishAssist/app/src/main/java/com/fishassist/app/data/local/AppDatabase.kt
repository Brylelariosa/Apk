package com.fishassist.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.fishassist.app.data.model.Statistics

@Database(entities = [Statistics::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun statisticsDao(): StatisticsDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "fishassist_db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
