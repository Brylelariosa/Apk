package com.fishassist.app.ui.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fishassist.app.data.model.Statistics
import com.fishassist.app.data.repository.StatisticsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StatisticsViewModel @Inject constructor(
    private val repo: StatisticsRepository
) : ViewModel() {

    val stats: StateFlow<Statistics> = repo.statistics
        .map { it ?: Statistics() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Statistics())

    fun reset() = viewModelScope.launch { repo.reset() }
}
