package com.fishassist.app.data.model

data class LogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val level: Level = Level.INFO,
    val message: String
) {
    enum class Level { DEBUG, INFO, WARN, ERROR }
}
