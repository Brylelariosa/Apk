package com.fishassist.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.fishassist.app.data.model.CastProfile
import com.fishassist.app.data.model.DifficultyProfile
import com.fishassist.app.data.model.Settings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("fishassist_prefs")

class AppDataStore(private val context: Context) {

    companion object {
        val KEY_CAST_POWER   = longPreferencesKey("cast_power_ms")
        val KEY_DELAY_MIN    = longPreferencesKey("reaction_min_ms")
        val KEY_DELAY_MAX    = longPreferencesKey("reaction_max_ms")
        val KEY_HUMAN_DELAY  = booleanPreferencesKey("human_like_delay")
        val KEY_TRACK_AGG    = floatPreferencesKey("tracking_aggressiveness")
        val KEY_DETECT_SENS  = floatPreferencesKey("detection_sensitivity")
        val KEY_TARGET_FPS   = intPreferencesKey("target_fps")
        val KEY_BATTERY      = booleanPreferencesKey("battery_saver")
        val KEY_PERFORMANCE  = booleanPreferencesKey("performance_mode")
        val KEY_AUTO_START   = booleanPreferencesKey("auto_start")
        val KEY_AUTO_RESUME  = booleanPreferencesKey("auto_resume")
        val KEY_DIFFICULTY   = stringPreferencesKey("difficulty_profile")
        val KEY_CAST_PROFILE = stringPreferencesKey("cast_profile")

        // Calibration keys
        val KEY_CAL_BOUNDS   = stringPreferencesKey("cal_bounds")      // "x,y,w,h"
        val KEY_CAL_BAR_CLR  = intPreferencesKey("cal_bar_color")      // ARGB int
        val KEY_CAL_FISH_CLR = intPreferencesKey("cal_fish_color")     // ARGB int
        val KEY_CAL_BITE_CLR = intPreferencesKey("cal_bite_color")     // ARGB int
        val KEY_CAL_DONE     = booleanPreferencesKey("calibration_done")
    }

    val settingsFlow: Flow<Settings> = context.dataStore.data.map { prefs ->
        Settings(
            castPowerMs            = prefs[KEY_CAST_POWER] ?: 800L,
            reactionDelayMinMs     = prefs[KEY_DELAY_MIN]  ?: 80L,
            reactionDelayMaxMs     = prefs[KEY_DELAY_MAX]  ?: 200L,
            humanLikeDelay         = prefs[KEY_HUMAN_DELAY] ?: true,
            trackingAggressiveness = prefs[KEY_TRACK_AGG]  ?: 1.0f,
            detectionSensitivity   = prefs[KEY_DETECT_SENS] ?: 0.5f,
            targetFps              = prefs[KEY_TARGET_FPS]  ?: 30,
            batterySaverMode       = prefs[KEY_BATTERY]    ?: false,
            performanceMode        = prefs[KEY_PERFORMANCE] ?: false,
            autoStart              = prefs[KEY_AUTO_START] ?: false,
            autoResume             = prefs[KEY_AUTO_RESUME] ?: true,
            difficultyProfile      = prefs[KEY_DIFFICULTY]?.let {
                DifficultyProfile.valueOf(it)
            } ?: DifficultyProfile.BALANCED,
            castProfile            = prefs[KEY_CAST_PROFILE]?.let {
                CastProfile.valueOf(it)
            } ?: CastProfile.MEDIUM
        )
    }

    suspend fun updateSettings(block: suspend (MutablePreferences) -> Unit) {
        context.dataStore.edit { block(it) }
    }
}
