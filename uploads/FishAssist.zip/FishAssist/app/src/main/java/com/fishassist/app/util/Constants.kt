package com.fishassist.app.util

object Constants {
    const val MEDIA_PROJECTION_REQUEST_CODE = 101
    const val OVERLAY_PERMISSION_REQUEST    = 102
    const val NOTIF_CHANNEL_GENERAL         = "fishassist_general"
    const val EXTRA_FROM_NOTIFICATION       = "from_notification"
}
