package com.fishassist.app.vision

import android.graphics.Color
import android.graphics.Rect
import android.graphics.Bitmap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Low-level bitmap analysis utilities shared by [BiteDetector] and [MinigameDetector].
 *
 * All methods operate on [Bitmap] objects captured by [ScreenCaptureService].
 * Pixel iteration uses configurable stride to trade accuracy for speed.
 */
@Singleton
class FrameAnalyzer @Inject constructor() {

    companion object {
        const val STRIDE_COARSE = 4
        const val STRIDE_FINE   = 1
    }

    /** Returns true if [pixel] is within [tolerance] of [target] in each RGB channel. */
    fun colorMatches(pixel: Int, target: Int, tolerance: Int): Boolean =
        abs(Color.red(pixel)   - Color.red(target))   <= tolerance &&
        abs(Color.green(pixel) - Color.green(target)) <= tolerance &&
        abs(Color.blue(pixel)  - Color.blue(target))  <= tolerance

    private fun abs(v: Int) = if (v < 0) -v else v

    /**
     * Count pixels in [region] matching [targetColor] within [tolerance].
     * Samples every [stride] pixels for speed.
     */
    fun countMatchingPixels(
        bitmap: Bitmap, region: Rect,
        targetColor: Int, tolerance: Int,
        stride: Int = STRIDE_COARSE
    ): Int {
        var count = 0
        val xEnd = region.right.coerceAtMost(bitmap.width)
        val yEnd = region.bottom.coerceAtMost(bitmap.height)
        var y = region.top.coerceAtLeast(0)
        while (y < yEnd) {
            var x = region.left.coerceAtLeast(0)
            while (x < xEnd) {
                if (colorMatches(bitmap.getPixel(x, y), targetColor, tolerance)) count++
                x += stride
            }
            y += stride
        }
        return count
    }

    /**
     * Find the top and bottom Y of pixels matching [targetColor] in a vertical
     * scan at x=[centerX] inside [region]. Returns null if nothing found.
     */
    fun findVerticalExtent(
        bitmap: Bitmap, region: Rect, centerX: Int,
        targetColor: Int, tolerance: Int
    ): Pair<Int, Int>? {
        var topY = -1; var bottomY = -1
        val xSafe = centerX.coerceIn(0, bitmap.width - 1)
        for (y in region.top.coerceAtLeast(0) until region.bottom.coerceAtMost(bitmap.height)) {
            if (colorMatches(bitmap.getPixel(xSafe, y), targetColor, tolerance)) {
                if (topY == -1) topY = y
                bottomY = y
            }
        }
        return if (topY != -1) topY to bottomY else null
    }

    /**
     * Find centroid Y of matching pixels in [region].
     * Returns null if match density is below [minFraction].
     */
    fun findCentroidY(
        bitmap: Bitmap, region: Rect,
        targetColor: Int, tolerance: Int,
        minFraction: Float = 0.02f,
        stride: Int = STRIDE_FINE
    ): Float? {
        var sumY = 0L; var count = 0
        val xEnd = region.right.coerceAtMost(bitmap.width)
        val yEnd = region.bottom.coerceAtMost(bitmap.height)
        var y = region.top.coerceAtLeast(0)
        while (y < yEnd) {
            var x = region.left.coerceAtLeast(0)
            while (x < xEnd) {
                if (colorMatches(bitmap.getPixel(x, y), targetColor, tolerance)) { sumY += y; count++ }
                x += stride
            }
            y += stride
        }
        val s = stride.coerceAtLeast(1)
        val totalSampled = ((xEnd - region.left) / s) * ((yEnd - region.top) / s)
        return if (count > 0 && totalSampled > 0 && count.toFloat() / totalSampled >= minFraction)
            sumY.toFloat() / count
        else null
    }

    /** Normalise an absolute Y coordinate to [0.0, 1.0] within [region]. */
    fun normaliseY(absoluteY: Float, region: Rect): Float =
        ((absoluteY - region.top) / region.height().toFloat()).coerceIn(0f, 1f)

    /**
     * Sample the average colour of a [radius]-pixel box around [x],[y].
     * Used for calibration tap colour sampling.
     */
    fun sampleAverageColor(bitmap: Bitmap, x: Int, y: Int, radius: Int = 2): Int {
        var r = 0; var g = 0; var b = 0; var n = 0
        for (dy in -radius..radius) for (dx in -radius..radius) {
            val c = bitmap.getPixel(
                (x + dx).coerceIn(0, bitmap.width - 1),
                (y + dy).coerceIn(0, bitmap.height - 1)
            )
            r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++
        }
        return Color.rgb(r / n, g / n, b / n)
    }
}
