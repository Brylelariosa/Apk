package com.fishassist.app.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.WindowManager
import com.fishassist.app.automation.FishingStateMachine
import com.fishassist.app.databinding.OverlayControlBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import javax.inject.Inject
import kotlin.math.abs

/**
 * Floating overlay service that renders the control panel and status HUD
 * on top of all other apps (including Stardew Valley).
 *
 * The overlay is draggable and collapses to a compact dot when idle.
 */
@AndroidEntryPoint
class OverlayService : Service() {

    @Inject lateinit var stateMachine: FishingStateMachine

    private lateinit var wm: WindowManager
    private lateinit var binding: OverlayControlBinding
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Drag tracking
    private var initialX = 0; private var initialY = 0
    private var touchX = 0f; private var touchY = 0f
    private var isDragging = false

    private val layoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 20; y = 200
    }

    companion object {
        fun start(context: android.content.Context) =
            context.startService(Intent(context, OverlayService::class.java))

        fun stop(context: android.content.Context) =
            context.stopService(Intent(context, OverlayService::class.java))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        binding = OverlayControlBinding.inflate(LayoutInflater.from(this))
        setupDrag()
        setupButtons()
        wm.addView(binding.root, layoutParams)
        observeState()
    }

    private fun setupDrag() {
        binding.dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x; initialY = layoutParams.y
                    touchX = event.rawX; touchY = event.rawY
                    isDragging = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 5 || abs(dy) > 5) isDragging = true
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        wm.updateViewLayout(binding.root, layoutParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> isDragging
                else -> false
            }
        }
    }

    private fun setupButtons() {
        binding.btnStart.setOnClickListener  { stateMachine.start() }
        binding.btnPause.setOnClickListener  { stateMachine.pause() }
        binding.btnStop.setOnClickListener   { stateMachine.stop() }
        binding.btnEmergency.setOnClickListener {
            stateMachine.stop()
            stopSelf()
        }
        binding.btnCollapse.setOnClickListener { toggleCompact() }
    }

    private var isCompact = false
    private fun toggleCompact() {
        isCompact = !isCompact
        val vis = if (isCompact) android.view.View.GONE else android.view.View.VISIBLE
        binding.controlPanel.visibility = vis
        binding.btnCollapse.text = if (isCompact) "▶" else "◀"
    }

    private fun observeState() {
        scope.launch {
            stateMachine.uiState.collectLatest { ui ->
                binding.tvStatus.text     = ui.stateLabel
                binding.tvFps.text        = "%.1f fps".format(ui.detectionFps)
                binding.tvFishCount.text  = "${ui.fishCaught} fish"
                binding.tvConfidence.text = "%.0f%%".format(ui.confidence * 100)

                val color = when {
                    ui.isRunning -> 0xFF4CAF50.toInt()
                    ui.isPaused  -> 0xFFFF9800.toInt()
                    else         -> 0xFF9E9E9E.toInt()
                }
                binding.statusDot.setBackgroundColor(color)

                binding.btnStart.isEnabled = !ui.isRunning
                binding.btnPause.isEnabled = ui.isRunning
                binding.btnStop.isEnabled  = ui.isRunning || ui.isPaused
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { wm.removeView(binding.root) }
        super.onDestroy()
    }
}
