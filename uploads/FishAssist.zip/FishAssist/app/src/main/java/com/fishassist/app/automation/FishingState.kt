package com.fishassist.app.automation

/**
 * All states in the fishing automation state machine.
 * Transitions are managed exclusively by [FishingStateMachine].
 */
sealed class FishingState {
    object Idle            : FishingState()
    object DetectingGame   : FishingState()
    object EquippingRod    : FishingState()
    object Casting         : FishingState()
    /** Cast fired; waiting for the bobber to land in the water. */
    object WaitingBobber   : FishingState()
    /** Bobber landed; watching for the bite indicator. */
    object WaitingBite     : FishingState()
    /** Bite detected; executing the hook tap. */
    object Hooking         : FishingState()
    /** Minigame active; PID control loop running. */
    data class MinigameActive(val startMs: Long = System.currentTimeMillis()) : FishingState()
    object Collecting      : FishingState()
    object Paused          : FishingState()
    data class Error(val msg: String) : FishingState()

    val label: String get() = when (this) {
        is Idle            -> "Idle"
        is DetectingGame   -> "Detecting game..."
        is EquippingRod    -> "Equipping rod..."
        is Casting         -> "Casting..."
        is WaitingBobber   -> "Waiting for bobber..."
        is WaitingBite     -> "Waiting for bite..."
        is Hooking         -> "Hooking!"
        is MinigameActive  -> "Fishing minigame!"
        is Collecting      -> "Collecting..."
        is Paused          -> "Paused"
        is Error           -> "Error: $msg"
    }

    val isActive: Boolean get() = this !is Idle && this !is Paused && this !is Error
}
