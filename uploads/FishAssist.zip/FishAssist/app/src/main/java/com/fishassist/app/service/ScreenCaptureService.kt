package com.fishassist.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.fishassist.app.R
import com.fishassist.app.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground service that captures screen frames via MediaProjection.
 *
 * Frames are emitted as [Bitmap] objects on [frameFlow].
 * Consumers must NOT recycle the bitmap; the service manages recycling.
 */
@AndroidEntryPoint
class ScreenCaptureService : LifecycleService() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler

    private var screenWidth  = 0
    private var screenHeight = 0
    private var screenDpi    = 0

    companion object {
        private const val TAG        = "ScreenCapture"
        private const val CHANNEL_ID = "fishassist_capture"
        private const val NOTIF_ID   = 1001
        const val EXTRA_CODE = "extra_result_code"
        const val EXTRA_DATA = "extra_result_data"

        /** Latest captured frame; null when service is stopped. */
        private val _frameFlow = MutableStateFlow<Bitmap?>(null)
        val frameFlow: StateFlow<Bitmap?> = _frameFlow.asStateFlow()

        fun start(context: Context, resultCode: Int, data: Intent) {
            Intent(context, ScreenCaptureService::class.java).also { i ->
                i.putExtra(EXTRA_CODE, resultCode)
                i.putExtra(EXTRA_DATA, data)
                context.startForegroundService(i)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Measure screen once
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        DisplayMetrics().also { m ->
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getMetrics(m)
            screenWidth  = m.widthPixels
            screenHeight = m.heightPixels
            screenDpi    = m.densityDpi
        }
        captureThread = HandlerThread("CaptureThread").apply { start() }
        captureHandler = Handler(captureThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForeground(NOTIF_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_CODE, -1) ?: -1
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }

        if (resultData != null && resultCode != -1) {
            startCapture(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
        ).apply {
            setOnImageAvailableListener(::onImageAvailable, captureHandler)
        }

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "FishAssistCapture",
            screenWidth, screenHeight, screenDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, captureHandler
        )
        Log.i(TAG, "Capture started at ${screenWidth}x${screenHeight}")
    }

    private fun onImageAvailable(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        try {
            val plane    = image.planes[0]
            val rowPad   = plane.rowStride - plane.pixelStride * screenWidth
            val bmpWidth = screenWidth + rowPad / plane.pixelStride

            val raw = Bitmap.createBitmap(bmpWidth, screenHeight, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(plane.buffer)

            val cropped = if (bmpWidth == screenWidth) raw else {
                Bitmap.createBitmap(raw, 0, 0, screenWidth, screenHeight).also { raw.recycle() }
            }
            // Recycle previous frame
            _frameFlow.value?.recycle()
            _frameFlow.value = cropped
        } catch (e: Exception) {
            Log.e(TAG, "Frame capture error", e)
        } finally {
            image.close()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "FishAssist Capture", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FishAssist")
            .setContentText("Screen capture active")
            .setSmallIcon(R.drawable.ic_fish)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        virtualDisplay?.release()
        mediaProjection?.stop()
        imageReader?.close()
        captureThread.quitSafely()
        _frameFlow.value = null
        Log.i(TAG, "Capture stopped")
        super.onDestroy()
    }
}
