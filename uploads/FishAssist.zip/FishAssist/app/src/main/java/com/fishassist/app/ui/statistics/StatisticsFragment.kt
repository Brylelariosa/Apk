package com.fishassist.app.ui.statistics

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fishassist.app.databinding.FragmentStatisticsBinding
import com.fishassist.app.util.collectFlow
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class StatisticsFragment : Fragment() {

    private val vm: StatisticsViewModel by viewModels()
    private var _b: FragmentStatisticsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentStatisticsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        collectFlow(vm.stats) { s ->
            b.tvFishCaught.text    = s.totalFishCaught.toString()
            b.tvMissed.text        = s.totalMissed.toString()
            b.tvCatchRate.text     = "%.1f%%".format(s.catchRate)
            b.tvSessionTime.text   = s.sessionFormatted
            b.tvAvgReaction.text   = "%.0f ms".format(s.avgReactionMs)
            b.tvAvgFps.text        = "%.1f fps".format(s.avgDetectionFps)
        }

        b.btnReset.setOnClickListener {
            android.app.AlertDialog.Builder(requireContext())
                .setTitle("Reset Statistics")
                .setMessage("Clear all fishing statistics?")
                .setPositiveButton("Reset") { _, _ -> vm.reset() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
