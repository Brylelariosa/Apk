/* AI Empire Tycoon - hardware art.
   1) Seven server tiers that each have their own silhouette, colour and lights, used in the data halls and on the upgrade cards.
   2) Thumbnails for every upgrade (office, lab, data center, cooling, power, network, servers), built from the same drawings
      the campus uses, so what you see on a card is what you get on the island.
   Everything draws into the isometric space of art.js. */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D, A = G.art;
  const P = A.P, box = A.box, poly = A.poly, ell = A.ell, tri = A.tri, hash = A.hash, quad = A.quad;
  const HW = (A.hw = {});

  HW.RW = 0.56; HW.RD = 0.9;                       // footprint of one rack in a data hall
  HW.H = [15, 20, 25, 33, 36, 40, 46];             // rack height per tier, in pixels
  const ACC = D.hw.map((h) => h.color);
  HW.accent = (t) => ACC[Math.max(0, Math.min(ACC.length - 1, t))];

  /* ---------- small drawing helpers ---------- */
  const geo = (x, y, w, d, h, z0, big) => ({ x, y, w, d, h, z0: z0 || 0, big: !!big, L: A.fL(x, y, w, d, h, z0 || 0), R: A.fR(x, y, w, d, h, z0 || 0), cx: x + w / 2, cy: y + d / 2 });
  // an ellipse that lies on a face, so round things look round on a slanted wall
  function faceEll(c, f, u, v, r, fill, stroke, lw) {
    const o = f(0, 0), a = f(1, 0), b = f(0, 1);
    const lu = Math.hypot(a[0] - o[0], a[1] - o[1]) || 1, lv = Math.hypot(b[0] - o[0], b[1] - o[1]) || 1;
    c.beginPath();
    for (let i = 0; i <= 14; i++) { const t = (i / 14) * 6.2832, p = f(u + (Math.cos(t) * r) / lu, v + (Math.sin(t) * r) / lv); if (i) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }
    c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw || 1; c.stroke(); }
  }
  function faceLine(c, f, u0, v0, u1, v1, stroke, lw) {
    const a = f(u0, v0), b = f(u1, v1);
    c.strokeStyle = stroke; c.lineWidth = lw || 1; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
  }
  // a small fan on a face: dark opening, coloured rim, three blades
  function fanOn(c, f, u, v, r, hex) {
    faceEll(c, f, u, v, r, '#060a16', hex, Math.max(0.6, r * 0.2));
    const o = f(0, 0), a = f(1, 0), b = f(0, 1), lu = Math.hypot(a[0] - o[0], a[1] - o[1]) || 1, lv = Math.hypot(b[0] - o[0], b[1] - o[1]) || 1;
    c.strokeStyle = hex; c.lineWidth = Math.max(0.5, r * 0.16); c.beginPath();
    for (let i = 0; i < 3; i++) { const t = i * 2.094 + 0.5, p = f(u, v), q = f(u + (Math.cos(t) * r * 0.78) / lu, v + (Math.sin(t) * r * 0.78) / lv); c.moveTo(p[0], p[1]); c.lineTo(q[0], q[1]); }
    c.stroke();
  }
  const sparkle = (c, x, y, s, col) => { c.fillStyle = col; c.beginPath(); c.moveTo(x, y - s); c.lineTo(x + s * 0.28, y - s * 0.28); c.lineTo(x + s, y); c.lineTo(x + s * 0.28, y + s * 0.28); c.lineTo(x, y + s); c.lineTo(x - s * 0.28, y + s * 0.28); c.lineTo(x - s, y); c.lineTo(x - s * 0.28, y - s * 0.28); c.closePath(); c.fill(); };
  const blink = (c, p, col, w) => { c.fillStyle = col; c.fillRect(p[0] - (w || 2.4) / 2, p[1] - 0.9, w || 2.4, 1.8); };
  // a rectangle on a face with a top-to-bottom gradient (colour `top` at v1, `bot` at v0)
  function gq(c, f, u0, u1, v0, v1, top, bot) {
    const a = f(u0, v1), b = f(u0, v0), gr = c.createLinearGradient(a[0], a[1], b[0], b[1]);
    gr.addColorStop(0, top); gr.addColorStop(1, bot);
    quad(c, f, u0, u1, v0, v1, gr);
  }
  // the same with a left-to-right gradient (colour `l` at u0, `r` at u1), kept horizontal on the screen
  function gh(c, f, u0, u1, v0, v1, l, r) {
    const a = f(u0, v0), b = f(u1, v0), gr = c.createLinearGradient(a[0], 0, b[0], 0);
    gr.addColorStop(0, l); gr.addColorStop(1, r);
    quad(c, f, u0, u1, v0, v1, gr);
  }
  // additive light: lamps, cores, beams
  const bloom = (c, x, y, r, hex, a) => { c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = a; c.drawImage(A.glow(hex), x - r, y - r, r * 2, r * 2); c.restore(); };
  const lineP = (c, a, b, col, lw) => { c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); };
  const RAINBOW = ['#ff6b6b', '#ffa94d', '#ffe066', '#69db7c', '#4dabf7', '#b197fc'];

  // Geometry shared by the pod's drawing and its blinking lights: node positions inside the dome, in screen space.
  const POD_N = [[0, 0, 0.92], [-0.5, 0.05, 0.64], [0.5, 0.05, 0.64], [0, -0.5, 0.62], [0, 0.52, 0.6], [-0.82, 0.05, 0.3], [0.82, 0.05, 0.3], [-0.42, -0.72, 0.28], [0.42, -0.72, 0.28], [-0.4, 0.74, 0.26], [0.4, 0.74, 0.26], [0, 0, 0.34]];
  const POD_E = [];
  POD_N.forEach((a, i) => POD_N.forEach((b, j) => { if (j > i && Math.hypot(a[0] - b[0], a[1] - b[1], (a[2] - b[2]) * 1.15) < 0.78) POD_E.push([i, j]); }));
  function podGeom(g) {
    const dh = 19, bh = g.h - dh - 3, rb = g.big ? 0.34 : 0.27, p0 = P(g.cx, g.cy, g.z0 + 3 + bh), rx = rb * 45.25, ry = rb * 22.63;
    const nodes = POD_N.map((n) => ({ x: p0[0] + n[0] * rx * 0.84, y: p0[1] + n[1] * ry * 0.84 - n[2] * dh * 0.9, d: n[1], z: n[2] }));
    return { dh, bh, rb, p0, rx, ry, nodes };
  }

  /* ================= the seven tiers =================
     Each tier has draw(c, g) for the body and leds(c, g, k, ri) for the blinking lights (k = animation frame).
     g is a footprint helper: g.L is the face that looks left-down (the front), g.R the face that looks right-down.
     g.big is true for the large pictures on upgrade cards, which get a little more detail than the small ones in the halls. */
  const TIERS = [
    // 0. Entry GPU server: a brushed-steel rack server with three trays, mesh vents, pull handles and green lights.
    {
      name: 'steel rack',
      draw(c, g) {
        box(c, g.x, g.y, g.w, g.d, g.h, g.z0, tri('#6d7d9f'));
        const L = g.L, R = g.R, n = g.big ? 7 : 3;
        quad(c, L, 0.05, 0.95, 0.04, 0.96, '#0b1322');
        for (let i = 0; i < 3; i++) {
          const v0 = 0.07 + i * 0.3, v1 = v0 + 0.25;
          gq(c, L, 0.08, 0.92, v0, v1, '#dde6f5', '#8697bb');
          quad(c, L, 0.08, 0.92, v1 - 0.04, v1, 'rgba(255,255,255,.6)');
          for (let k = 0; k < n; k++) { const a = 0.13 + k * (0.5 / n); quad(c, L, a, a + 0.23 / n, v0 + 0.06, v1 - 0.08, 'rgba(18,30,58,.62)'); }
          quad(c, L, 0.72, 0.89, v0 + 0.07, v0 + 0.11, '#2c3957');
        }
        for (let i = 0; i < 5; i++) quad(c, R, 0.12, 0.88, 0.1 + i * 0.17, 0.135 + i * 0.17, 'rgba(10,16,30,.5)');
        quad(c, R, 0.12, 0.88, 0.94, 0.97, 'rgba(255,255,255,.12)');
        quad(c, L, 0.05, 0.95, 0.96, 1, '#2be3b8');                     // thin teal brand strip along the top
      },
      leds(c, g, k, ri) {
        for (let i = 0; i < 3; i++) {
          if (hash(ri * 3 + i, k, 11) < 0.3) continue;
          const p = g.L(0.79, 0.07 + i * 0.3 + 0.185), col = i === 1 && k === 1 ? '#ffb347' : '#2be3b8';
          blink(c, p, col); if (g.big) bloom(c, p[0], p[1], 5, col, 0.55);
        }
      }
    },
    // 1. High-performance GPU server: black cabinet, a wall of small fans on the front, a glass side showing GPU cards.
    {
      name: 'gpu cabinet',
      draw(c, g) {
        box(c, g.x, g.y, g.w, g.d, g.h, g.z0, tri('#1b2550'));
        const L = g.L, R = g.R;
        quad(c, L, 0.05, 0.95, 0.04, 0.96, '#050813');
        for (let i = 0; i < 4; i++) {
          const v = 0.14 + i * 0.225;
          quad(c, L, 0.08, 0.92, v - 0.1, v + 0.1, '#10183a');
          fanOn(c, L, 0.29, v, g.big ? 1.9 : 1.7, '#4da3ff');
          fanOn(c, L, 0.71, v, g.big ? 1.9 : 1.7, '#4da3ff');
        }
        quad(c, R, 0.07, 0.95, 0.09, 0.91, '#070c26');                      // glass window
        for (let i = 0; i < 6; i++) {
          const u = 0.13 + i * 0.135;
          gq(c, R, u, u + 0.09, 0.15, 0.85, '#3d50b0', '#141d4c');
          quad(c, R, u, u + 0.09, 0.8, 0.85, '#85c4ff');
          if (g.big) quad(c, R, u + 0.02, u + 0.04, 0.2, 0.74, 'rgba(255,255,255,.18)');
        }
        gq(c, R, 0.07, 0.95, 0.09, 0.4, 'rgba(255,255,255,0)', 'rgba(77,163,255,.22)');  // reflection of the floor light
        quad(c, R, 0, 0.04, 0.04, 0.96, '#7cc0ff');                         // light strip on the front corner
        quad(c, L, 0.05, 0.95, 0.96, 1, '#7cc0ff');
        quad(c, R, 0.04, 0.96, 0.96, 1, 'rgba(124,192,255,.7)');
      },
      leds(c, g, k, ri) {
        for (let i = 0; i < 6; i++) {
          if (hash(ri * 6 + i, k, 12) < 0.45) continue;
          const u = 0.13 + i * 0.135, p = g.R(u + 0.045, 0.83);
          c.fillStyle = '#e4f2ff'; c.fillRect(p[0] - 1.1, p[1] - 0.7, 2.2, 1.4);
          if (g.big) bloom(c, p[0], p[1], 5, '#7cc0ff', 0.6);
        }
      }
    },
    // 2. Advanced AI accelerator: violet cabinet with a big chip package (die + memory stacks), coolant pipes and heat-sink fins.
    {
      name: 'accelerator',
      draw(c, g) {
        box(c, g.x, g.y, g.w, g.d, g.h, g.z0, tri('#3b2a7c'));
        const L = g.L, R = g.R;
        quad(c, L, 0.06, 0.94, 0.04, 0.96, '#0b0720');
        gq(c, L, 0.1, 0.9, 0.4, 0.92, '#e2d4ff', '#a38af0');                // chip package
        quad(c, L, 0.1, 0.9, 0.9, 0.92, 'rgba(255,255,255,.7)');
        quad(c, L, 0.13, 0.25, 0.47, 0.85, '#4a3597'); quad(c, L, 0.75, 0.87, 0.47, 0.85, '#4a3597');   // memory stacks
        quad(c, L, 0.29, 0.71, 0.46, 0.86, '#150b34');                      // the die
        for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) quad(c, L, 0.32 + i * 0.13, 0.32 + i * 0.13 + 0.09, 0.49 + j * 0.115, 0.49 + j * 0.115 + 0.08, 'rgba(214,186,255,.9)');
        for (let i = 0; i < 3; i++) quad(c, L, 0.12, 0.88, 0.09 + i * 0.1, 0.12 + i * 0.1, 'rgba(181,140,255,.38)');
        // side: glowing coolant pipes with joints
        quad(c, R, 0.08, 0.94, 0.08, 0.92, 'rgba(7,3,22,.6)');
        for (let i = 0; i < 3; i++) {
          const u = 0.2 + i * 0.27;
          gh(c, R, u, u + 0.1, 0.1, 0.9, '#ffa3dc', '#b4519f');
          for (const v of [0.28, 0.55, 0.8]) quad(c, R, u - 0.02, u + 0.12, v, v + 0.05, '#ffd6ef');
        }
        quad(c, R, 0, 0.04, 0.04, 0.96, 'rgba(206,170,255,.95)');
        const nf = g.big ? 7 : 5, fw = (g.w - 0.1) / nf;
        for (let i = 0; i < nf; i++) box(c, g.x + 0.05 + i * fw, g.y + 0.08, fw * 0.62, g.d - 0.16, g.big ? 6 : 4.5, g.z0 + g.h, tri(i % 2 ? '#b08cff' : '#8f69ec'), true);
      },
      leds(c, g, k, ri) {
        const a = hash(ri, k, 13), p = g.L(0.5, 0.67);
        c.fillStyle = 'rgba(255,255,255,' + (0.35 + a * 0.5) + ')'; c.fillRect(p[0] - 2.4, p[1] - 1.6, 4.8, 3.2);
        if (g.big) bloom(c, p[0], p[1], 9, '#c9a8ff', 0.5 * a + 0.2);
        if (hash(ri, k, 14) > 0.5) blink(c, g.L(0.18, 0.1), '#ff8fd6');
      }
    },
    // 3. Neuromorphic pod: a sealed plum capsule with a glowing activity display, under a glass dome that holds a living
    //    neuron network (nodes spread through the dome, joined by synapses).
    {
      name: 'neuro pod',
      draw(c, g) {
        const q = podGeom(g), cx = g.cx, cy = g.cy, z0 = g.z0, big = g.big;
        // base plate with a pink light ring
        const b0 = A.cyl(c, cx, cy, q.rb + 0.07, 3, z0, tri('#2f1834'));
        c.strokeStyle = 'rgba(255,143,177,.9)'; c.lineWidth = 1; c.beginPath(); c.ellipse(b0[0], b0[1] + 3, b0[2] * 0.97, b0[3] * 0.97, 0, 0.1, Math.PI - 0.1); c.stroke();
        const t = A.cyl(c, cx, cy, q.rb, q.bh, z0 + 3, tri('#8c4a86'));            // capsule body (t = top ellipse)
        // the floor inside the dome, dark with a pink glow
        c.fillStyle = '#2a1030'; A.ell(c, t[0], t[1], t[2] * 0.93, t[3] * 0.93); c.fill();
        bloom(c, t[0], t[1], t[2] * 1.2, '#ff8fb1', 0.55);
        // glossy stripe and glowing bands on the body
        c.fillStyle = 'rgba(255,255,255,.2)'; c.beginPath(); c.ellipse(t[0] - t[2] * 0.5, t[1] + q.bh * 0.55 + t[3] * 0.5, t[2] * 0.07, q.bh * 0.38, 0, 0, 6.283); c.fill();
        c.strokeStyle = '#ff8fb1'; c.lineWidth = big ? 1.6 : 1.2;
        for (const k of [0.06, 0.94]) { c.beginPath(); c.ellipse(t[0], t[1] + q.bh * k, t[2], t[3], 0, 0.04, Math.PI - 0.04); c.stroke(); }
        // activity display (the bars move in the light frames)
        c.fillStyle = '#220d27'; c.beginPath();
        for (let i = 0; i <= 10; i++) { const fx = -0.66 + i * 0.132, y = t[1] + q.bh * 0.26 + t[3] * Math.sqrt(1 - fx * fx); if (i) c.lineTo(t[0] + fx * t[2], y); else c.moveTo(t[0] + fx * t[2], y); }
        for (let i = 10; i >= 0; i--) { const fx = -0.66 + i * 0.132, y = t[1] + q.bh * 0.8 + t[3] * Math.sqrt(1 - fx * fx); c.lineTo(t[0] + fx * t[2], y); }
        c.closePath(); c.fill();
        // neuron network: synapses first, then the nodes from back to front
        const nodes = q.nodes;
        for (const e of POD_E) {
          const a = nodes[e[0]], b = nodes[e[1]], dp = (a.d + b.d) / 2;
          c.strokeStyle = 'rgba(255,175,205,' + (0.55 + 0.3 * dp) + ')'; c.lineWidth = big ? 0.9 : 0.7;
          c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
        }
        nodes.slice().sort((a, b) => a.d - b.d).forEach((n) => {
          const r = (0.9 + n.z * 0.9 + (n.d + 1) * 0.25) * (big ? 1.25 : 1);
          bloom(c, n.x, n.y, r * 3, '#ff8fb1', 0.3);
          c.fillStyle = '#ffe9f0'; c.beginPath(); c.arc(n.x, n.y, r, 0, 6.283); c.fill();
        });
        // glass dome over everything
        A.dome(c, cx, cy, q.rb, q.dh, z0 + 3 + q.bh, '#ffc4d8', 0.3);
        c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 1; c.beginPath(); c.ellipse(t[0], t[1], t[2] * 0.72, q.dh * 0.74, 0, Math.PI * 1.08, Math.PI * 1.46); c.stroke();
        c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.ellipse(t[0] - t[2] * 0.42, t[1] - q.dh * 0.62, 1.4, 2.6, -0.5, 0, 6.283); c.fill();
      },
      leds(c, g, k, ri) {
        const q = podGeom(g), t = q.p0;
        q.nodes.forEach((n, i) => {
          if (hash(ri * 12 + i, k, 15) < 0.6) return;
          bloom(c, n.x, n.y, 5, '#ffffff', 0.4); c.fillStyle = '#fff'; c.beginPath(); c.arc(n.x, n.y, 1.3, 0, 6.283); c.fill();
        });
        // the activity bars
        for (let i = 0; i < 5; i++) {
          const fx = -0.5 + i * 0.25, y = t[1] + q.bh * 0.76 + q.ry * Math.sqrt(1 - fx * fx), hgt = 2 + hash(ri * 5 + i, k, 16) * q.bh * 0.42;
          c.fillStyle = i % 2 ? '#ff8fb1' : '#ffd0e0'; c.fillRect(t[0] + fx * q.rx - 1.1, y - hgt, 2.2, hgt);
        }
      }
    },
    // 4. Photonic compute core: a brass cabinet of glass and light. A white beam runs up the middle, a spectrum shows on
    //    the side and a crystal prism splits the light on the roof.
    {
      name: 'photonic core',
      draw(c, g) {
        const bh = g.h - 8;
        box(c, g.x, g.y, g.w, g.d, bh, g.z0, tri('#6a5526'));
        const L = A.fL(g.x, g.y, g.w, g.d, bh, g.z0), R = A.fR(g.x, g.y, g.w, g.d, bh, g.z0);
        quad(c, L, 0.07, 0.93, 0.05, 0.95, '#150f04');
        gq(c, L, 0.11, 0.89, 0.08, 0.92, 'rgba(255,236,170,.5)', 'rgba(255,196,80,.22)');
        gh(c, L, 0.4, 0.6, 0.05, 0.95, 'rgba(255,248,215,1)', 'rgba(255,232,170,1)');            // the light core
        for (let i = 0; i < 3; i++) faceEll(c, L, 0.5, 0.2 + i * 0.3, 2.1, 'rgba(255,255,255,.95)');
        for (const u of [0.2, 0.78]) quad(c, L, u, u + 0.05, 0.12, 0.88, 'rgba(255,209,102,.85)');
        // a spectrum behind glass on the side
        quad(c, R, 0.07, 0.95, 0.07, 0.93, '#120c03');
        RAINBOW.forEach((col, i) => quad(c, R, 0.1, 0.92, 0.12 + i * 0.125, 0.12 + i * 0.125 + 0.085, col));
        quad(c, R, 0.07, 0.95, 0.07, 0.4, 'rgba(0,0,0,.18)');
        quad(c, R, 0, 0.04, 0.04, 0.96, 'rgba(255,226,140,.95)');
        // the prism on the roof, with rays leaving it
        const px = P(g.cx, g.cy, g.z0 + bh + 3), s = g.big ? 1.25 : 1;
        bloom(c, px[0], px[1] - 4 * s, 15 * s, '#ffe9a8', 0.55);
        RAINBOW.forEach((col, i) => { c.strokeStyle = col; c.lineWidth = g.big ? 1.2 : 0.9; c.globalAlpha = 0.9; c.beginPath(); c.moveTo(px[0] + 3 * s, px[1] - 4 * s); c.lineTo(px[0] + (15 + i * 1.6) * s, px[1] - (7 - i * 2.2) * s); c.stroke(); });
        c.globalAlpha = 1;
        c.fillStyle = '#fff6cf'; c.beginPath(); c.moveTo(px[0], px[1] - 12 * s); c.lineTo(px[0] + 7 * s, px[1] - 4 * s); c.lineTo(px[0], px[1] + 1 * s); c.lineTo(px[0] - 7 * s, px[1] - 4 * s); c.closePath(); c.fill();
        c.fillStyle = 'rgba(255,205,90,.95)'; c.beginPath(); c.moveTo(px[0], px[1] - 12 * s); c.lineTo(px[0] + 7 * s, px[1] - 4 * s); c.lineTo(px[0], px[1] - 4 * s); c.closePath(); c.fill();
        c.fillStyle = 'rgba(255,255,255,.85)'; c.beginPath(); c.moveTo(px[0], px[1] - 12 * s); c.lineTo(px[0] - 2.4 * s, px[1] - 4 * s); c.lineTo(px[0], px[1] + 1 * s); c.lineTo(px[0] + 1.6 * s, px[1] - 4 * s); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,240,180,.9)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(px[0], px[1] + 1 * s); c.lineTo(px[0], px[1] + 3.4); c.stroke();
      },
      leds(c, g, k, ri) {
        const bh = g.h - 8, L = A.fL(g.x, g.y, g.w, g.d, bh, g.z0), a = hash(ri, k, 16), p = L(0.5, 0.5);
        c.fillStyle = 'rgba(255,255,255,' + (0.45 + a * 0.5) + ')'; c.fillRect(p[0] - 1.8, p[1] - bh * 0.4, 3.6, bh * 0.8);
        const q = P(g.cx, g.cy, g.z0 + bh + 11);
        sparkle(c, q[0] + (k - 1) * 4, q[1] - 5, 3 + a * 2, '#fff8d8');
        if (g.big) bloom(c, p[0], p[1], 14, '#fff1b8', 0.35 + a * 0.3);
      }
    },
    // 5. Quantum tensor array: a gold "chandelier" cryostat (stacked plates, rods and cables) under a frosted glass can,
    //    standing on a pump housing, with a glowing qubit chip at the bottom.
    {
      name: 'cryostat',
      draw(c, g) {
        const cx = g.cx, cy = g.cy, z0 = g.z0, H = g.h, big = g.big;
        const rc = big ? 0.3 : 0.27, kx = rc * 32 * 1.414, ky = rc * 16 * 1.414;
        A.cyl(c, cx, cy, rc + 0.05, 2.5, z0, tri('#27447a'));
        const ped = A.cyl(c, cx, cy, rc, 3.5, z0 + 2.5, tri('#cfe3fa'));
        c.strokeStyle = 'rgba(125,249,255,.9)'; c.lineWidth = 1; c.beginPath(); c.ellipse(ped[0], ped[1] + 3.5, ped[2], ped[3], 0, 0.1, Math.PI - 0.1); c.stroke();
        const zTop = z0 + H - 7, zBot = z0 + 14, n = 4, RR = [0.2, 0.165, 0.13, 0.095];
        const zs = RR.map((_, i) => zTop - (i * (zTop - zBot)) / (n - 1));
        const chip = P(cx, cy, zBot - 5);
        bloom(c, chip[0], chip[1], 14, '#7df9ff', 0.6);
        // the dark inside of the can
        const canTop = P(cx, cy, z0 + H - 2), canBot = P(cx, cy, z0 + 6);
        c.fillStyle = 'rgba(5,12,32,.55)'; c.beginPath(); c.moveTo(canTop[0] - kx, canTop[1]); c.lineTo(canBot[0] - kx, canBot[1]); c.ellipse(canBot[0], canBot[1], kx, ky, 0, Math.PI, 0, true); c.lineTo(canTop[0] + kx, canTop[1]); c.ellipse(canTop[0], canTop[1], kx, ky, 0, 0, Math.PI, true); c.closePath(); c.fill();
        // plates from the bottom up; the rods between two plates are drawn after the lower one so the upper one covers their tops
        for (let i = n - 1; i >= 0; i--) {
          const pl = A.cyl(c, cx, cy, RR[i], 1.8, zs[i] - 1.8, tri('#ecc85f'));
          if (i > 0) {
            const lo = P(cx, cy, zs[i] - 1.8)[1], hi = P(cx, cy, zs[i - 1] - 1.8)[1];
            c.strokeStyle = '#f7e08f'; c.lineWidth = big ? 1.5 : 1.2;
            for (const a of [2.6, 0.54, 1.57]) { const rx = RR[i - 1] * 32 * 1.414 * 0.72, ry = RR[i - 1] * 16 * 1.414 * 0.72, x = pl[0] + Math.cos(a) * rx, yy = Math.sin(a) * ry; c.beginPath(); c.moveTo(x, lo + yy * 0.6); c.lineTo(x, hi + yy * 0.6 + 1.8); c.stroke(); }
          }
          c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.7; c.beginPath(); c.ellipse(pl[0], pl[1], pl[2] * 0.9, pl[3] * 0.9, 0, Math.PI * 1.05, Math.PI * 1.7); c.stroke();
        }
        // copper cable bundle looping down the front
        c.strokeStyle = 'rgba(224,128,70,.95)'; c.lineWidth = big ? 1.2 : 0.9;
        for (const o of [-0.6, 0.6]) { const a = P(cx, cy, zTop - 1), b = P(cx, cy, zBot - 1); c.beginPath(); c.moveTo(a[0] + o * 7, a[1] + 3); c.bezierCurveTo(a[0] + o * 15, a[1] + (b[1] - a[1]) * 0.35, b[0] + o * 11, a[1] + (b[1] - a[1]) * 0.75, b[0] + o * 2, b[1]); c.stroke(); }
        // the qubit chip
        c.fillStyle = '#a8faff'; c.beginPath(); c.moveTo(chip[0], chip[1] - 2.2); c.lineTo(chip[0] + 4.5, chip[1]); c.lineTo(chip[0], chip[1] + 2.2); c.lineTo(chip[0] - 4.5, chip[1]); c.closePath(); c.fill();
        // the glass can in front: a faint tint, two bright edges and a lid
        const gl = c.createLinearGradient(canTop[0] - kx, 0, canTop[0] + kx, 0);
        gl.addColorStop(0, 'rgba(215,238,255,.34)'); gl.addColorStop(0.3, 'rgba(215,238,255,.06)'); gl.addColorStop(0.8, 'rgba(215,238,255,.05)'); gl.addColorStop(1, 'rgba(215,238,255,.24)');
        c.fillStyle = gl; c.beginPath(); c.moveTo(canTop[0] - kx, canTop[1]); c.lineTo(canBot[0] - kx, canBot[1]); c.ellipse(canBot[0], canBot[1], kx, ky, 0, Math.PI, 0, true); c.lineTo(canTop[0] + kx, canTop[1]); c.ellipse(canTop[0], canTop[1], kx, ky, 0, 0, Math.PI, true); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(235,248,255,.7)'; c.lineWidth = 1; c.beginPath(); c.moveTo(canTop[0] - kx, canTop[1]); c.lineTo(canBot[0] - kx, canBot[1]); c.moveTo(canTop[0] + kx, canTop[1]); c.lineTo(canBot[0] + kx, canBot[1]); c.stroke();
        c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(canTop[0] - kx * 0.62, canTop[1] + 4); c.lineTo(canBot[0] - kx * 0.62, canBot[1] - 3); c.stroke();
        // lid with the three gold conduits
        A.cyl(c, cx, cy, rc, 2.5, z0 + H - 2, tri('#b9c9de'));
        for (const [dx, dy] of [[-0.08, -0.06], [0.08, -0.03], [0, 0.07]]) A.cyl(c, cx + dx, cy + dy, 0.045, 4, z0 + H + 0.5, tri('#e9c45c'));
      },
      leds(c, g, k, ri) {
        const zBot = g.z0 + 14, q = P(g.cx, g.cy, zBot - 5), a = hash(ri, k, 17);
        bloom(c, q[0], q[1], 8, '#baffff', 0.5 + a * 0.5);
        c.fillStyle = 'rgba(255,255,255,' + (0.5 + a * 0.5) + ')'; c.beginPath(); c.arc(q[0], q[1], 1.5, 0, 6.283); c.fill();
        if (hash(ri, k, 18) > 0.35) sparkle(c, q[0] + (k - 1) * 8, q[1] - 12 - k * 4, 2.4, '#bff7ff');
      }
    },
    // 6. Stellar compute shard: a crystal that glows like a young star, held over a pedestal of light rings, with an orbit of shards.
    {
      name: 'stellar shard',
      draw(c, g) {
        const cx = g.cx, cy = g.cy, z0 = g.z0, H = g.h, big = g.big, s = big ? 1.3 : 1;
        const x = P(cx, cy)[0], base = P(cx, cy, z0)[1];
        // pedestal: two plates and glowing rings
        A.cyl(c, cx, cy, big ? 0.34 : 0.3, 3, z0, tri('#2c3358'));
        const p2 = A.cyl(c, cx, cy, big ? 0.24 : 0.21, 3, z0 + 3, tri('#3d4678'));
        c.strokeStyle = 'rgba(255,240,168,.95)'; c.lineWidth = 1.1; c.beginPath(); c.ellipse(p2[0], p2[1], p2[2] * 0.82, p2[3] * 0.82, 0, 0, 6.283); c.stroke();
        // beam
        const yb = base - 8, yt = base - H, ym = base - H * 0.52, w = 9 * s;
        const bg = c.createLinearGradient(0, yb, 0, yt - 8); bg.addColorStop(0, 'rgba(255,240,170,.38)'); bg.addColorStop(1, 'rgba(255,240,170,0)');
        c.fillStyle = bg; c.beginPath(); c.moveTo(x - 6 * s, yb); c.lineTo(x + 6 * s, yb); c.lineTo(x + 2 * s, yt - 8); c.lineTo(x - 2 * s, yt - 8); c.closePath(); c.fill();
        // back half of the orbit
        c.strokeStyle = 'rgba(255,240,168,.55)'; c.lineWidth = 1; c.beginPath(); c.ellipse(x, ym, 17 * s, 5.5 * s, 0, Math.PI, 6.283); c.stroke();
        bloom(c, x, ym, 22 * s, '#ffe9a0', 0.6);
        // crystal: four facets with gradients
        const fl = c.createLinearGradient(x - w, ym, x, ym); fl.addColorStop(0, '#fff3b8'); fl.addColorStop(1, '#ffffff');
        const fr = c.createLinearGradient(x, ym, x + w, ym); fr.addColorStop(0, '#ffe58a'); fr.addColorStop(1, '#d9a93c');
        c.fillStyle = fl; c.beginPath(); c.moveTo(x, yt); c.lineTo(x - w, ym); c.lineTo(x, yb); c.closePath(); c.fill();
        c.fillStyle = fr; c.beginPath(); c.moveTo(x, yt); c.lineTo(x + w, ym); c.lineTo(x, yb); c.closePath(); c.fill();
        c.fillStyle = 'rgba(255,255,255,.92)'; c.beginPath(); c.moveTo(x, yt); c.lineTo(x - w * 0.2, ym); c.lineTo(x, yb); c.lineTo(x + w * 0.2, ym); c.closePath(); c.fill();
        c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.moveTo(x, yt); c.lineTo(x - w * 0.55, ym - (ym - yt) * 0.2); c.lineTo(x - w * 0.2, ym); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,255,255,.9)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(x, yt); c.lineTo(x - w, ym); c.lineTo(x, yb); c.lineTo(x + w, ym); c.closePath(); c.stroke();
        // front half of the orbit
        c.strokeStyle = 'rgba(255,244,190,.95)'; c.lineWidth = 1.3; c.beginPath(); c.ellipse(x, ym, 17 * s, 5.5 * s, 0, 0, Math.PI); c.stroke();
        bloom(c, x, ym, 8 * s, '#ffffff', 0.9);
      },
      leds(c, g, k, ri) {
        const s = g.big ? 1.3 : 1, x = P(g.cx, g.cy)[0], base = P(g.cx, g.cy, g.z0)[1], H = g.h, ym = base - H * 0.52, a = hash(ri, k, 19);
        const ang = [0.4, 1.57, 2.7][k % 3];
        const ox = x + Math.cos(ang) * 17 * s, oy = ym + Math.sin(ang) * 5.5 * s;
        bloom(c, ox, oy, 7, '#fff3b0', 0.8); sparkle(c, ox, oy, 2.4 + a, '#ffffff');
        sparkle(c, x + (k - 1) * 9, ym - H * 0.34 + k * 3, 2.4 + a * 2, '#fffbe0');
        sparkle(c, x - (k - 1) * 7, ym + H * 0.12 - k * 2, 1.8 + a * 1.4, '#fff0a8');
      }
    }
  ];
  HW.TIERS = TIERS;

  // One rack of tier t standing at (x, y) in a hall whose floor is at z0.
  HW.rack = function (c, t, x, y, z0, pal) {
    const T = TIERS[t] || TIERS[0], g = geo(x, y, HW.RW, HW.RD, HW.H[t], z0);
    const p = P(g.cx, g.cy, z0);
    const gl = c.createRadialGradient(p[0], p[1], 1, p[0], p[1], 20);
    gl.addColorStop(0, U.rgba(ACC[t], 0.3)); gl.addColorStop(1, U.rgba(ACC[t], 0));
    c.fillStyle = gl; ell(c, p[0], p[1], 22, 11); c.fill();
    T.draw(c, g);
  };
  HW.leds = function (c, t, x, y, z0, k, ri) { const T = TIERS[t] || TIERS[0]; T.leds(c, geo(x, y, HW.RW, HW.RD, HW.H[t], z0), k, ri || 0); };
  // positions (in screen space) where a tier lets off mist, for the scene to animate
  HW.mistAt = (x, y, z0, t) => P(x + HW.RW / 2, y + HW.RD / 2, z0 + HW.H[t]);

  // A tiny version of a tier on a flat face (used inside the server closet).
  HW.mini = function (c, f, u0, u1, v0, v1, t) {
    const body = ['#8394b4', '#243055', '#3d2b78', '#552c52', '#7a6636', '#cfe3fb', '#e9d27a'][t] || '#8394b4';
    A.quad(c, f, u0, u1, v0, v1, body);
    const n = 5;
    for (let i = 0; i < n; i++) {
      const a = v0 + ((v1 - v0) * (i + 0.15)) / n, b = v0 + ((v1 - v0) * (i + 0.8)) / n;
      A.quad(c, f, u0 + 0.015, u1 - 0.015, a, b, 'rgba(6,10,24,.55)');
    }
    A.quad(c, f, u0, u0 + (u1 - u0) * 0.14, v0, v1, U.rgba(ACC[t], 0.9));
  };
  HW.miniLeds = function (c, f, u0, u1, v0, v1, t, k, seed) {
    for (let i = 0; i < 5; i++) {
      if (hash(i + seed * 7, k, 23) < 0.35) continue;
      const p = f(u1 - (u1 - u0) * 0.2, v0 + ((v1 - v0) * (i + 0.5)) / 5);
      c.fillStyle = (i + k) % 4 === 0 ? '#ffb347' : ACC[t]; c.fillRect(p[0] - 1.2, p[1] - 0.8, 2.4, 1.6);
    }
  };

  /* ================= showcase drawings for the upgrade cards ================= */
  // A single unit of tier t on a round platform, drawn exactly like it appears in a hall, only bigger.
  HW.showcase = function (t, pal) {
    const s = 3.1, g = geo(0.2, 0.05, HW.RW, HW.RD, HW.H[t], 4, true);
    const o = { id: 'show' + t, fp: [0, 0, 1, 1, HW.H[t]] };
    const cx = g.cx, cy = g.cy, top = P(cx, cy, 4 + HW.H[t] + 16)[1], bot = P(cx, cy, 0)[1] + 20, mx = P(cx, cy)[0];
    o.b = [mx - 50 * s, top * s - 4, mx + 50 * s, bot * s].map((v, i) => (i % 2 ? v : v));
    o.draw = (c) => {
      c.save(); c.scale(s, s);
      const p = P(cx, cy, 0);
      const pg = c.createRadialGradient(p[0], p[1], 2, p[0], p[1], 46);
      pg.addColorStop(0, U.rgba(ACC[t], 0.5)); pg.addColorStop(1, U.rgba(ACC[t], 0));
      c.fillStyle = pg; ell(c, p[0], p[1] + 2, 48, 24); c.fill();
      c.fillStyle = '#1b2646'; ell(c, p[0], p[1] + 3, 33, 16.5); c.fill();
      c.fillStyle = '#2a3764'; ell(c, p[0], p[1], 33, 16.5); c.fill();
      c.strokeStyle = U.rgba(ACC[t], 0.9); c.lineWidth = 1; ell(c, p[0], p[1], 29, 14.5); c.stroke();
      TIERS[t].draw(c, g);
      TIERS[t].leds(c, g, 1, 2);
      c.restore();
    };
    return o;
  };
  // An empty four-slot rack: used for the "Server Rack" card.
  HW.rackShowcase = function (pal) {
    const s = 3.0, g = geo(0.2, 0.05, 0.66, 0.9, 42, 4, true);
    const o = { id: 'showrack', fp: [0, 0, 1, 1, 42] };
    const cx = g.cx, cy = g.cy, mx = P(cx, cy)[0];
    o.b = [mx - 50 * s, P(cx, cy, 4 + 42 + 16)[1] * s - 4, mx + 50 * s, (P(cx, cy, 0)[1] + 20) * s];
    o.draw = (c) => {
      c.save(); c.scale(s, s);
      const p = P(cx, cy, 0);
      c.fillStyle = '#1b2646'; ell(c, p[0], p[1] + 3, 33, 16.5); c.fill();
      c.fillStyle = '#2a3764'; ell(c, p[0], p[1], 33, 16.5); c.fill();
      box(c, g.x, g.y, g.w, g.d, g.h, 4, tri('#4c5a7e'));
      const L = g.L, R = g.R;
      A.quad(c, L, 0.06, 0.94, 0.04, 0.96, '#0c1426');
      for (let i = 0; i < 4; i++) {
        const v0 = 0.07 + i * 0.225;
        if (i < 2) { A.quad(c, L, 0.1, 0.9, v0, v0 + 0.2, '#96a7c9'); A.quad(c, L, 0.14, 0.62, v0 + 0.08, v0 + 0.12, 'rgba(20,32,60,.6)'); blink(c, L(0.8, v0 + 0.1), '#2be3b8', 3.4); }
        else faceLine(c, L, 0.1, v0 + 0.1, 0.9, v0 + 0.1, 'rgba(150,175,230,.35)', 1);
      }
      for (let i = 0; i < 5; i++) A.quad(c, R, 0.1, 0.9, 0.1 + i * 0.18, 0.13 + i * 0.18, 'rgba(10,16,30,.4)');
      c.restore();
    };
    return o;
  };
  // Two small pieces of art for levels the campus never draws (a desk instead of a lab, a pole instead of a power plant).
  function deskObj(pal) {
    const o = { id: 'desk', fp: [0, 0, 2, 1.6, 40] };
    o.b = A.bbox(0, 0, 2, 1.6, 54, 14).map((v) => v * 1.7);
    o.draw = (c) => {
      c.save(); c.scale(1.7, 1.7);
      box(c, 0, 0, 2, 1.6, 2, 0, pal.concrete);
      box(c, 0.2, 0.3, 1.5, 0.8, 14, 2, pal.wood);
      box(c, 0.5, 0.45, 0.8, 0.08, 10, 16, pal.dark);
      A.quad(c, A.fL(0.5, 0.45, 0.8, 0.08, 10, 16), 0.08, 0.92, 0.12, 0.88, '#69d4ee');
      HW.rack(c, 0, 1.25, 1.0, 2, pal);
      c.restore();
    };
    return o;
  }
  function poleObj(pal) {
    const o = { id: 'pole', fp: [0, 0, 1.4, 1.4, 70] };
    o.b = A.bbox(0, 0, 1.4, 1.4, 86, 16).map((v) => v * 1.5);
    o.draw = (c) => {
      c.save(); c.scale(1.5, 1.5);
      box(c, 0, 0, 1.4, 1.4, 2, 0, pal.concrete);
      const a = P(0.5, 0.5, 2), t = P(0.5, 0.5, 66);
      c.strokeStyle = '#8a6a48'; c.lineWidth = 3; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(t[0], t[1]); c.stroke();
      c.strokeStyle = '#a58660'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(t[0] - 12, t[1] + 6); c.lineTo(t[0] + 12, t[1] - 6); c.moveTo(t[0] - 10, t[1] + 16); c.lineTo(t[0] + 10, t[1] + 6); c.stroke();
      c.strokeStyle = 'rgba(210,225,255,.6)'; c.lineWidth = 1; c.beginPath(); c.moveTo(t[0] - 12, t[1] + 6); c.quadraticCurveTo(t[0] - 30, t[1] + 26, t[0] - 46, t[1] + 12); c.moveTo(t[0] + 12, t[1] - 6); c.quadraticCurveTo(t[0] + 30, t[1] + 16, t[0] + 46, t[1] + 2); c.stroke();
      box(c, 0.9, 0.7, 0.4, 0.5, 12, 2, pal.metal);
      c.restore();
    };
    return o;
  }

  /* ================= thumbnails ================= */
  // Representative contents for a data hall card: what the hall tends to hold at that size.
  const HALL_MIX = [null, [1, 0, 0, 0, 0, 0, 0], [1, 1, 0, 0, 0, 0, 0], [0, 1, 1, 0, 0, 0, 0], [0, 1, 1, 1, 0, 0, 0], [0, 0, 1, 1, 1, 1, 0]];
  function makeObj(kind, lv, pal) {
    switch (kind) {
      case 'hw': return HW.showcase(lv, pal);
      case 'rack': return HW.rackShowcase(pal);
      case 'hq': return A.hq(lv, pal);
      case 'lab': return lv === 0 ? deskObj(pal) : A.lab(lv, pal);
      case 'dc': { if (lv === 0) return A.shed(pal, [2, 0, 0, 0, 0, 0, 0], 2); const cap = D.ladders.dc[lv].racks - D.ladders.dc[lv - 1].racks; return A.hall(lv, cap, cap, HALL_MIX[lv] || HALL_MIX[1], Math.min(5, lv), pal); }
      case 'cool': return A.cooling(lv, pal);
      case 'pwr': return lv === 0 ? poleObj(pal) : A.power(lv, pal);
      case 'net': return A.tower(lv, pal);
    }
    return null;
  }
  const cache = {};   // key -> { cv, w, h }  (the drawing at a moderate resolution)
  function build(kind, lv, skin) {
    const pal = A.palette(skin), obj = makeObj(kind, lv, pal);
    if (!obj) return null;
    const b = obj.tb || obj.b, w = b[2] - b[0], h = b[3] - b[1];
    const res = Math.min(1.6, 340 / Math.max(w, h));
    const spr = A.sprite(b, (c) => {
      obj.draw(c);
      if (obj.leds) obj.leds(c, 1);
      if (obj.screens) { c.fillStyle = 'rgba(150,240,255,.35)'; for (const q of obj.screens) { c.beginPath(); c.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) c.lineTo(q[i][0], q[i][1]); c.closePath(); c.fill(); } }
      if (obj.orb) { c.strokeStyle = 'rgba(155,231,255,.6)'; c.lineWidth = 1; c.beginPath(); c.arc(obj.orb.p[0], obj.orb.p[1], obj.orb.r * 0.6, 0, 6.283); c.stroke(); }
    }, res);
    return (cache[kind + lv + skin] = { cv: spr.cv, w, h, glow: obj.glow && obj.glow[0] ? obj.glow[0].c : null });
  }
  const queue = [];
  let queued = false;
  function pump() {
    queued = false;
    const job = queue.shift();
    if (job) { try { job(); } catch (e) { if (G.err) G.err(e); } }
    if (queue.length) { queued = true; setTimeout(pump, 12); }
  }
  function paintNow(cv, ent, o) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2), W = o.w, H = o.h;
    if (cv.width !== Math.round(W * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const c = cv.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, W, H);
    // soft light behind the picture
    const gr = c.createRadialGradient(W / 2, H * 0.62, 2, W / 2, H * 0.62, Math.max(W, H) * 0.62);
    gr.addColorStop(0, U.rgba(o.tint || ent.glow || '#3dd6c6', o.dim ? 0.1 : 0.26)); gr.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = gr; c.fillRect(0, 0, W, H);
    const pad = o.pad === undefined ? 6 : o.pad, k = Math.min((W - pad * 2) / ent.w, (H - pad * 2) / ent.h, o.maxScale || 1.6);
    const dw = ent.w * k, dh = ent.h * k, dx = (W - dw) / 2, dy = H - pad - dh - (o.lift || 0);
    c.imageSmoothingQuality = 'high';
    c.drawImage(ent.cv, dx, dy, dw, dh);
    if (o.dim) { c.globalCompositeOperation = 'source-atop'; c.fillStyle = 'rgba(7,11,26,.62)'; c.fillRect(0, 0, W, H); c.globalCompositeOperation = 'source-over'; }
  }
  // Draw the picture for (kind, lv) into a <canvas>. The first time is deferred a little so a screen with many pictures opens fast.
  // opts: w, h (CSS pixels), dim (locked), tint, pad, maxScale
  HW.paint = function (cv, kind, lv, opts) {
    const o = Object.assign({ w: 96, h: 72 }, opts || {});
    const skin = (G.state && G.state.pres.skin) || 'midnight', key = kind + lv + skin;
    cv.style.width = o.w + 'px'; cv.style.height = o.h + 'px';
    const hit = cache[key];
    if (hit) { paintNow(cv, hit, o); return; }
    queue.push(() => { const e = cache[key] || build(kind, lv, skin); if (e && cv.isConnected !== false) paintNow(cv, e, o); });
    if (!queued) { queued = true; setTimeout(pump, 0); }
  };
  HW.thumb = function (kind, lv, opts) {
    const cv = document.createElement('canvas');
    cv.className = 'thumb';
    HW.paint(cv, kind, lv, opts);
    return cv;
  };
  HW.clear = () => { for (const k in cache) delete cache[k]; };
  HW.cacheInfo = () => { let px = 0, n = 0; for (const k in cache) { px += cache[k].cv.width * cache[k].cv.height; n++; } return { n, mb: +((px * 4) / 1048576).toFixed(1) }; };
})();
