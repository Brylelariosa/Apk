/* AI Empire Tycoon - isometric art. Everything is drawn procedurally (no image files). */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D;
  const A = (G.art = {});
  const HW = 32, HH = 16;
  const P = (x, y, z) => [(x - y) * HW, (x + y) * HH - (z || 0)];
  A.P = P; A.HW = HW; A.HH = HH;
  A.res = 1.5;

  /* ---------- colours ---------- */
  const triCache = {};
  function tri(hex, k) {
    k = k || 1;
    const key = hex + k;
    if (triCache[key]) return triCache[key];
    return (triCache[key] = { t: U.shade(hex, 1.22 * k), l: U.shade(hex, 0.96 * k), r: U.shade(hex, 0.7 * k), e: 'rgba(255,255,255,.18)', hex });
  }
  A.tri = tri;
  A.palette = function (skin) {
    const k = D.skins[skin] || D.skins.midnight;
    return {
      acc: k.accent, lamp: k.lamp, glassHex: k.glass,
      wall: tri(k.wall), roof: tri(k.roof), glass: tri(k.glass),
      concrete: tri('#51608a'), dark: tri('#1a2238'), metal: tri('#5f6f92'), rack: tri('#2a3350'),
      floor: tri('#33436a'), hall: tri('#182240'), white: tri('#cfd9ee'), cyan: tri('#2d9fc2'), wood: tri('#8b6a4a')
    };
  };

  /* ---------- primitives ---------- */
  function poly(c, pts, fill, stroke) {
    c.beginPath();
    c.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1; c.stroke(); }
  }
  A.poly = poly;
  function box(c, x, y, w, d, h, z0, col, noEdge) {
    z0 = z0 || 0;
    const nT = P(x, y, z0 + h), eT = P(x + w, y, z0 + h), sT = P(x + w, y + d, z0 + h), wT = P(x, y + d, z0 + h);
    const sB = P(x + w, y + d, z0), wB = P(x, y + d, z0), eB = P(x + w, y, z0);
    poly(c, [wT, sT, sB, wB], col.l);
    poly(c, [sT, eT, eB, sB], col.r);
    poly(c, [nT, eT, sT, wT], col.t);
    if (!noEdge) {
      c.strokeStyle = col.e; c.lineWidth = 1; c.beginPath();
      c.moveTo(wT[0], wT[1]); c.lineTo(sT[0], sT[1]); c.lineTo(eT[0], eT[1]); c.stroke();
    }
  }
  A.box = box;
  const fL = (x, y, w, d, h, z0) => (u, v) => P(x + u * w, y + d, (z0 || 0) + v * h);
  const fR = (x, y, w, d, h, z0) => (u, v) => P(x + w, y + d - u * d, (z0 || 0) + v * h);
  function quad(c, f, u0, u1, v0, v1, fill) { poly(c, [f(u0, v0), f(u1, v0), f(u1, v1), f(u0, v1)], fill); }
  function wins(c, f, cols, rows, mx, my, fillFn) {
    for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
      const fl = fillFn(i, j);
      if (fl) quad(c, f, (i + mx) / cols, (i + 1 - mx) / cols, (j + my) / rows, (j + 1 - my) / rows, fl);
    }
  }
  A.fL = fL; A.fR = fR; A.quad = quad; A.wins = wins;
  const hash = (a, b, s) => {
    let h = (Math.imul(a + 7, 374761393) + Math.imul(b + 13, 668265263) + Math.imul((s || 0) + 3, 1274126177)) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  A.hash = hash;
  function ell(c, cx, cy, rx, ry) { c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); }
  A.ell = ell;
  function cyl(c, x, y, r, h, z0, col) {
    const p = P(x, y, z0 || 0), cx = p[0], cy = p[1], rx = r * HW * 1.414, ry = r * HH * 1.414;
    const g = c.createLinearGradient(cx - rx, 0, cx + rx, 0);
    g.addColorStop(0, col.l); g.addColorStop(0.45, col.t); g.addColorStop(1, col.r);
    c.fillStyle = g; c.beginPath();
    c.moveTo(cx - rx, cy - h); c.lineTo(cx - rx, cy); c.ellipse(cx, cy, rx, ry, 0, Math.PI, 0, true);
    c.lineTo(cx + rx, cy - h); c.ellipse(cx, cy - h, rx, ry, 0, 0, Math.PI, true); c.closePath(); c.fill();
    ell(c, cx, cy - h, rx, ry); c.fillStyle = col.t; c.fill();
    c.strokeStyle = col.e; c.lineWidth = 1; c.stroke();
    return [cx, cy - h, rx, ry];
  }
  A.cyl = cyl;
  function dome(c, x, y, r, h, z0, hex, a) {
    const p = P(x, y, z0 || 0), cx = p[0], cy = p[1], rx = r * HW * 1.414, ry = r * HH * 1.414;
    const g = c.createRadialGradient(cx - rx * 0.35, cy - h * 0.7, 2, cx, cy - h * 0.3, Math.max(rx, h) * 1.05);
    g.addColorStop(0, U.rgba(hex, 0.95 * a)); g.addColorStop(0.55, U.rgba(hex, 0.5 * a)); g.addColorStop(1, U.rgba(hex, 0.2 * a));
    c.fillStyle = g; c.beginPath();
    c.moveTo(cx - rx, cy); c.ellipse(cx, cy, rx, h, 0, Math.PI, Math.PI * 2, false);
    c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI, false); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 1; c.stroke();
    return [cx, cy - h * 0.55];
  }
  A.dome = dome;
  const glowC = {};
  A.glow = function (hex) {
    if (glowC[hex]) return glowC[hex];
    const s = document.createElement('canvas'); s.width = s.height = 64;
    const g = s.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, U.rgba(hex, 1)); gr.addColorStop(0.28, U.rgba(hex, 0.42)); gr.addColorStop(1, U.rgba(hex, 0));
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return (glowC[hex] = s);
  };
  A.sprite = function (b, fn, res) {
    const sc = res || A.res, w = Math.ceil((b[2] - b[0]) * sc), h = Math.ceil((b[3] - b[1]) * sc);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, w); cv.height = Math.max(1, h);
    const c = cv.getContext('2d');
    c.scale(sc, sc); c.translate(-b[0], -b[1]); c.lineJoin = 'round'; c.lineCap = 'round';
    fn(c);
    return { cv, x: b[0], y: b[1], w: b[2] - b[0], h: b[3] - b[1] };
  };
  A.bbox = (x, y, w, d, h, pad) => {
    pad = pad === undefined ? 8 : pad;
    return [P(x, y + d)[0] - pad, P(x, y, h)[1] - pad - 6, P(x + w, y)[0] + pad, P(x + w, y + d)[1] + pad];
  };

  /* ---------- plan of the campus ---------- */
  // The north row, left to right: the office (plots 1..6), a gap that holds the closet (A.HALLS[0]) and the network tower, and the lab.
  // The gap must fit a building with open ground on both sides, so the lab sits `lab.dx` further east than its drawing says.
  // Everything else keeps the coordinates written in its own drawing code.
  A.PLAN = { lab: { dx: 0.5 }, net: { x: 6.85, y: 5.2, s: 0.8 } };
  // Slide a finished building along the ground: its picture, hit area, lights and glow all move with it, so a plot can change
  // without editing the drawing code. Only for buildings that set their lights and glow up front (the lab does), not ones that
  // fill them in while they are drawn.
  A.slide = function (o, dx, dy) {
    if (!dx && !dy) return o;
    const s = P(dx, dy), mv = (p) => [p[0] + s[0], p[1] + s[1]], draw = o.draw;
    o.draw = (c) => { c.save(); c.translate(s[0], s[1]); draw(c); c.restore(); };
    o.fp = [o.fp[0] + dx, o.fp[1] + dy, o.fp[2], o.fp[3], o.fp[4]];
    o.b = [o.b[0] + s[0], o.b[1] + s[1], o.b[2] + s[0], o.b[3] + s[1]];
    for (const k of ['glow', 'fans', 'smoke', 'bubbles']) if (o[k]) o[k].forEach((q) => { q.p = mv(q.p); });
    if (o.orb) o.orb.p = mv(o.orb.p);
    if (o.ring) o.ring.c = mv(o.ring.c);
    return o;
  };
  A.person = function (c, px, py, ph, col, seated, skin) {
    c.fillStyle = 'rgba(0,0,0,.28)'; ell(c, px, py, 4.5, 2.2); c.fill();
    const y0 = py - (seated ? 0 : Math.abs(Math.sin(ph)) * 1.2);
    if (!seated) {
      const sw = Math.sin(ph) * 2.2;
      c.strokeStyle = '#1b2236'; c.lineWidth = 1.7; c.beginPath();
      c.moveTo(px - 1.3, y0 - 5); c.lineTo(px - 1.3 + sw, y0); c.moveTo(px + 1.3, y0 - 5); c.lineTo(px + 1.3 - sw, y0); c.stroke();
    } else { c.fillStyle = '#1b2236'; c.fillRect(px - 2.8, y0 - 5.5, 5.6, 2.8); }
    c.fillStyle = col; c.fillRect(px - 2.7, y0 - 12.5, 5.4, 7.6);
    c.fillStyle = skin || '#e8c39e'; ell(c, px, y0 - 15, 2.5, 2.7); c.fill();
    c.fillStyle = '#2a2233'; c.beginPath(); c.ellipse(px, y0 - 15.6, 2.6, 1.9, 0, Math.PI, Math.PI * 2); c.fill();
  };
  A.tree = function (c, px, py, s, hexA) {
    s = s || 1;
    c.fillStyle = 'rgba(0,0,0,.25)'; ell(c, px, py, 9 * s, 4 * s); c.fill();
    c.fillStyle = '#4a3a2c'; c.fillRect(px - 1.4 * s, py - 9 * s, 2.8 * s, 9 * s);
    const g = c.createRadialGradient(px - 3 * s, py - 20 * s, 1, px, py - 17 * s, 13 * s);
    g.addColorStop(0, U.shade(hexA || '#3fa37a', 1.25)); g.addColorStop(1, U.shade(hexA || '#3fa37a', 0.62));
    c.fillStyle = g; ell(c, px, py - 17 * s, 9 * s, 10.5 * s); c.fill();
  };

  /* ---------- land and roads ---------- */
  // The campus is a floating island: a lawn slab on top of a tapering rock with glowing crystal veins underneath.
  A.landDepth = (Lx, Ly) => Math.round(34 + (Lx + Ly) * 5);
  A.land = function (Lx, Ly, pal, roads) {
    const T = 16, DEPTH = A.landDepth(Lx, Ly);
    const b = [P(0, Ly)[0] - 10, P(0, 0)[1] - 10, P(Lx, 0)[0] + 10, P(Lx, Ly)[1] + T + DEPTH + 14];
    const spr = A.sprite(b, (c) => {
      const n = P(0, 0), e = P(Lx, 0), s = P(Lx, Ly), w = P(0, Ly);
      // ---- rock underside: two faces that meet at a point below the middle of the island ----
      const wl = [w[0], w[1] + T], sl = [s[0], s[1] + T], el = [e[0], e[1] + T];
      const apex = [(w[0] + e[0]) / 2 + 4, s[1] + T + DEPTH];
      const face = (p0, p1, light, dark) => {
        const g = c.createLinearGradient(0, p0[1], 0, apex[1]);
        g.addColorStop(0, light); g.addColorStop(1, dark);
        c.fillStyle = g; c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.lineTo(apex[0], apex[1]); c.closePath(); c.fill();
      };
      face(wl, sl, '#22345a', '#0c1630');
      face(sl, el, '#142140', '#070d1f');
      // facets: shards running from the rim down to the point
      const rnd = U.rng(Math.round(Lx * 31 + Ly * 17));
      for (let side = 0; side < 2; side++) {
        const p0 = side ? sl : wl, p1 = side ? el : sl;
        for (let i = 1; i < 7; i++) {
          const t = i / 7 + (rnd() - 0.5) * 0.06, px = U.lerp(p0[0], p1[0], t), py = U.lerp(p0[1], p1[1], t);
          const k = 0.45 + rnd() * 0.4, mx = U.lerp(px, apex[0], k), my = U.lerp(py, apex[1], k) + (rnd() - 0.5) * 6;
          c.fillStyle = side ? 'rgba(2,6,16,' + (0.16 + rnd() * 0.2) + ')' : 'rgba(150,185,255,' + (0.05 + rnd() * 0.07) + ')';
          c.beginPath(); c.moveTo(px - 5, py); c.lineTo(px + 5, py); c.lineTo(mx, my); c.closePath(); c.fill();
        }
      }
      // glowing veins
      c.lineWidth = 1.1; c.lineCap = 'round';
      for (let i = 0; i < 6; i++) {
        const t = 0.12 + rnd() * 0.76, side = i % 2, p0 = side ? sl : wl, p1 = side ? el : sl;
        const px = U.lerp(p0[0], p1[0], t), py = U.lerp(p0[1], p1[1], t) + 2, k = 0.3 + rnd() * 0.4;
        const g = c.createLinearGradient(px, py, U.lerp(px, apex[0], k), U.lerp(py, apex[1], k));
        g.addColorStop(0, U.rgba(pal.acc, 0.5)); g.addColorStop(1, U.rgba(pal.acc, 0));
        c.strokeStyle = g; c.beginPath(); c.moveTo(px, py); c.lineTo(U.lerp(px, apex[0], k), U.lerp(py, apex[1], k) + (rnd() - 0.5) * 8); c.stroke();
      }
      // crystal cluster at the tip
      const crystal = (x, y, h, wd, a) => { c.fillStyle = U.rgba(pal.acc, a); c.beginPath(); c.moveTo(x - wd, y); c.lineTo(x, y - h); c.lineTo(x + wd, y); c.lineTo(x + wd * 0.4, y + h * 0.28); c.lineTo(x - wd * 0.4, y + h * 0.28); c.closePath(); c.fill(); c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.8; c.stroke(); };
      crystal(apex[0] - 8, apex[1] - 4, 18, 4.5, 0.55); crystal(apex[0] + 6, apex[1] - 2, 24, 5.5, 0.75); crystal(apex[0] - 1, apex[1] + 2, 15, 4, 0.9);
      // ---- lawn slab ----
      poly(c, [w, s, [s[0], s[1] + T], [w[0], w[1] + T]], '#0e1a33');
      poly(c, [s, e, [e[0], e[1] + T], [s[0], s[1] + T]], '#080f21');
      c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 1; c.beginPath(); c.moveTo(w[0], w[1] + T); c.lineTo(s[0], s[1] + T); c.lineTo(e[0], e[1] + T); c.stroke();
      const g = c.createLinearGradient(0, n[1], 0, s[1]);
      g.addColorStop(0, '#16494a'); g.addColorStop(0.55, '#10393c'); g.addColorStop(1, '#0d2e35');
      poly(c, [n, e, s, w], g);
      // paver grid
      c.strokeStyle = 'rgba(160,230,220,.06)'; c.lineWidth = 1; c.beginPath();
      for (let i = 1; i < Lx; i++) { const a = P(i, 0), z = P(i, Ly); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      for (let j = 1; j < Ly; j++) { const a = P(0, j), z = P(Lx, j); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      c.stroke();
      // lighter lawn patches
      for (let i = 0; i < Lx; i++) for (let j = 0; j < Ly; j++) {
        if (hash(i, j, 5) > 0.8) poly(c, [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)], 'rgba(80,190,150,.08)');
        else if (hash(i, j, 9) > 0.9) poly(c, [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)], 'rgba(0,0,0,.1)');
      }
      // roads
      for (const r of roads || []) {
        const x0 = r[0], y0 = r[1], x1 = r[2], y1 = r[3], hw = 0.42;
        const horiz = Math.abs(x1 - x0) >= Math.abs(y1 - y0);
        const pts = horiz ? [P(x0, y0 - hw), P(x1, y0 - hw), P(x1, y0 + hw), P(x0, y0 + hw)] : [P(x0 - hw, y0), P(x0 + hw, y0), P(x0 + hw, y1), P(x0 - hw, y1)];
        poly(c, pts, '#1d2845');
        c.strokeStyle = U.rgba(pal.acc, 0.35); c.lineWidth = 1; c.setLineDash([5, 6]); c.beginPath();
        const a = P(x0, y0), z = P(x1, y1); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke(); c.setLineDash([]);
      }
      // glowing rim
      c.strokeStyle = U.rgba(pal.acc, 0.5); c.lineWidth = 1.8; c.beginPath();
      c.moveTo(w[0], w[1]); c.lineTo(s[0], s[1]); c.lineTo(e[0], e[1]); c.stroke();
      c.strokeStyle = U.rgba(pal.acc, 0.16); c.lineWidth = 1; c.beginPath();
      c.moveTo(w[0], w[1]); c.lineTo(n[0], n[1]); c.lineTo(e[0], e[1]); c.stroke();
    });
    spr.depth = DEPTH; spr.tip = P(Lx, Ly)[1] + T;
    return spr;
  };

  /* ================= HEADQUARTERS ================= */
  A.hq = function (tier, pal) {
    const o = { id: 'hq', kind: 'hq', tier, name: D.ladders.hq[tier].name, seats: [], windows: null };
    if (tier <= 1) {
      const x0 = tier === 0 ? 1.7 : 1.3, sz = tier === 0 ? 4 : 4.7, H = tier === 0 ? 44 : 50;
      o.fp = [x0, x0, sz, sz, H];
      o.b = A.bbox(x0, x0, sz, sz, H + 8, 10);
      const desks = tier === 0 ? [[2.5, 2.0], [3.9, 2.0], [2.05, 3.5]] : [[1.9, 1.75], [3.15, 1.75], [4.4, 1.75], [1.7, 3.0], [1.7, 4.25], [3.4, 3.6]];
      desks.forEach((d) => {
        const alongA = d[0] < 2.3 && d[1] > 2.6;
        o.seats.push(alongA ? [d[0] + 0.95, d[1] + 0.55] : [d[0] + 0.55, d[1] + 0.85]);
      });
      o.screens = [];
      o.draw = (c) => {
        box(c, x0, x0, sz, sz, 4, 0, pal.floor);
        poly(c, [P(x0 + 0.8, x0 + 0.8, 4), P(x0 + sz - 0.8, x0 + 0.8, 4), P(x0 + sz - 0.8, x0 + sz - 0.8, 4), P(x0 + 0.8, x0 + sz - 0.8, 4)], U.rgba(pal.acc, 0.1));
        box(c, x0, x0, 0.2, sz, H, 4, pal.wall);
        box(c, x0, x0, sz, 0.2, H, 4, pal.wall);
        const fa = fR(x0, x0, 0.2, sz, H, 4), fb = fL(x0, x0, sz, 0.2, H, 4);
        wins(c, fa, 3, 1, 0.12, 0.3, () => 'rgba(255,205,140,.9)');
        // garage door and window on the right wall
        quad(c, fb, 0.06, 0.46, 0.08, 0.74, '#2e3955');
        for (let i = 1; i < 6; i++) quad(c, fb, 0.06, 0.46, 0.08 + i * 0.11, 0.085 + i * 0.11, 'rgba(255,255,255,.1)');
        quad(c, fb, 0.56, 0.94, 0.3, 0.78, 'rgba(120,200,255,.55)');
        // whiteboard on the left wall
        quad(c, fR(x0, x0, 0.2, sz, H, 4), 0.1, 0.5, 0.34, 0.82, '#e9eef8');
        c.strokeStyle = 'rgba(61,120,190,.7)'; c.lineWidth = 1; c.beginPath();
        let a = fR(x0, x0, 0.2, sz, H, 4)(0.16, 0.7); let z = fR(x0, x0, 0.2, sz, H, 4)(0.42, 0.62); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]);
        a = fR(x0, x0, 0.2, sz, H, 4)(0.16, 0.56); z = fR(x0, x0, 0.2, sz, H, 4)(0.36, 0.5); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke();
        // furniture, back to front
        const items = [];
        desks.forEach((d, i) => items.push([d[0] + d[1], () => {
          const along = d[0] < 2.3 && d[1] > 2.6;
          const dw = along ? 0.62 : 1.15, dd = along ? 1.15 : 0.62;
          box(c, d[0], d[1], dw, dd, 12, 4, pal.wood);
          const mx = along ? d[0] + 0.1 : d[0] + 0.3, my = along ? d[1] + 0.3 : d[1] + 0.08;
          const mw = along ? 0.08 : 0.5, md = along ? 0.5 : 0.08;
          box(c, mx, my, mw, md, 9, 16, pal.dark);
          const f = along ? fR(mx, my, mw, md, 9, 16) : fL(mx, my, mw, md, 9, 16);
          quad(c, f, 0.1, 0.9, 0.12, 0.88, '#69d4ee');
          o.screens.push([f(0.1, 0.12), f(0.9, 0.12), f(0.9, 0.88), f(0.1, 0.88)]);
          const s = o.seats[i]; box(c, s[0] - 0.2, s[1] - 0.2, 0.4, 0.4, 7, 4, pal.dark);
        }]));
        items.push([x0 + sz + x0 - 1.1, () => { box(c, x0 + sz - 0.95, x0 + 0.3, 0.6, 0.6, 26, 4, pal.dark); o.ledPts = [P(x0 + sz - 0.5, x0 + 0.9, 24), P(x0 + sz - 0.5, x0 + 0.9, 18), P(x0 + sz - 0.5, x0 + 0.9, 12)]; }]);
        if (tier === 1) {
          items.push([x0 + sz + 1.5, () => { box(c, x0 + sz - 1.6, x0 + sz - 1.6, 1.4, 1.4, 14, 4, tri('#3a2f55')); quad(c, fL(x0 + sz - 1.6, x0 + sz - 1.6, 1.4, 1.4, 14, 4), 0.1, 0.9, 0.35, 0.95, 'rgba(160,190,255,.35)'); }]);
        }
        items.push([x0 + sz + sz - 2.6, () => { box(c, x0 + sz - 0.7, x0 + sz - 0.7, 0.34, 0.34, 6, 4, tri('#5a3d2c')); A.tree(c, P(x0 + sz - 0.53, x0 + sz - 0.53, 10)[0], P(x0 + sz - 0.53, x0 + sz - 0.53, 10)[1], 0.55, '#43b283'); }]);
        items.sort((p, q) => p[0] - q[0]).forEach((it) => it[1]());
        // string lights
        const l0 = P(x0, x0 + sz * 0.5, H + 3), l1 = P(x0 + sz * 0.5, x0, H + 3), l2 = P(x0 + sz, x0, H + 3), l3 = P(x0, x0 + sz, H + 3);
        c.strokeStyle = 'rgba(255,255,255,.3)'; c.lineWidth = 1; c.beginPath(); c.moveTo(l3[0], l3[1]); c.quadraticCurveTo(l0[0] - 4, l0[1] + 12, l1[0], l1[1]); c.quadraticCurveTo(l1[0] + 8, l1[1] + 12, l2[0], l2[1]); c.stroke();
        o.lights = [];
        for (let i = 1; i < 8; i++) { const t = i / 8, px = U.lerp(l3[0], l1[0], t), py = U.lerp(l3[1], l1[1], t) + Math.sin(t * Math.PI) * 9; o.lights.push([px, py]); }
        for (let i = 1; i < 6; i++) { const t = i / 6, px = U.lerp(l1[0], l2[0], t), py = U.lerp(l1[1], l2[1], t) + Math.sin(t * Math.PI) * 9; o.lights.push([px, py]); }
      };
      o.entry = P(x0 + sz * 0.5, x0 + sz + 0.3);
      o.glow = [{ p: P(x0 + 1.5, x0 + 1.5, 28), r: 55, c: '#ffc98a', a: 0.12 }];
    } else if (tier === 2) {
      o.fp = [1.4, 1.4, 4.4, 4.4, 84]; o.b = A.bbox(1.4, 1.4, 4.4, 4.4, 92, 12);
      o.draw = (c) => {
        box(c, 1.1, 1.1, 5, 5, 3, 0, pal.concrete);
        box(c, 1.4, 1.4, 4.4, 4.4, 78, 3, pal.wall);
        const fl = fL(1.4, 1.4, 4.4, 4.4, 78, 3), fr = fR(1.4, 1.4, 4.4, 4.4, 78, 3);
        const lit = (s) => (i, j) => (hash(i, j, s) > 0.4 ? 'rgba(255,214,150,.88)' : 'rgba(96,140,190,.5)');
        wins(c, fl, 5, 3, 0.18, 0.22, lit(1)); wins(c, fr, 5, 3, 0.18, 0.22, lit(2));
        quad(c, fl, 0.42, 0.58, 0, 0.26, U.rgba(pal.acc, 0.85));
        box(c, 2.0, 2.0, 1.1, 1.1, 8, 81, pal.metal); box(c, 3.6, 3.4, 1.3, 1.0, 6, 81, pal.metal);
        o.roofGlow = P(3.6, 3.6, 92);
        c.strokeStyle = U.rgba(pal.acc, 0.8); c.lineWidth = 2; c.beginPath(); const a = P(1.4, 5.8, 80), z = P(5.8, 5.8, 80), e = P(5.8, 1.4, 80); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.lineTo(e[0], e[1]); c.stroke();
        o.winFaces = [fl, fr];
      };
      o.glow = [{ p: P(3.6, 3.6, 92), r: 36, c: pal.acc, a: 0.22 }];
    } else if (tier === 3) {
      o.fp = [1, 1, 5, 5, 132]; o.b = A.bbox(1, 1, 5, 5, 140, 12);
      o.draw = (c) => {
        box(c, 1, 1, 5, 5, 20, 0, pal.concrete);
        const fp = fL(1, 1, 5, 5, 20, 0);
        wins(c, fp, 8, 1, 0.14, 0.3, (i) => (hash(i, 1, 4) > 0.3 ? 'rgba(255,214,150,.85)' : 'rgba(96,140,190,.5)'));
        box(c, 1.7, 1.7, 3.6, 3.6, 112, 20, pal.glass);
        const fl = fL(1.7, 1.7, 3.6, 3.6, 112, 20), fr = fR(1.7, 1.7, 3.6, 3.6, 112, 20);
        const lit = (s) => (i, j) => (hash(i, j, s) > 0.45 ? 'rgba(255,230,180,.8)' : 'rgba(150,200,255,.3)');
        wins(c, fl, 7, 9, 0.12, 0.2, lit(3)); wins(c, fr, 7, 9, 0.12, 0.2, lit(4));
        c.strokeStyle = U.rgba(pal.acc, 0.7); c.lineWidth = 1.5; c.beginPath();
        for (const u of [0, 0.5, 1]) { const a = fl(u, 0), z = fl(u, 1); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
        c.stroke();
        box(c, 2.0, 2.0, 1.2, 1.2, 5, 132, tri('#2f6a55')); box(c, 3.6, 3.5, 1.2, 1.1, 5, 132, tri('#2f6a55'));
        const t1 = P(2.6, 2.6, 140), t2 = P(4.2, 4.0, 140); A.tree(c, t1[0], t1[1] + 5, 0.55, '#43b283'); A.tree(c, t2[0], t2[1] + 5, 0.5, '#43b283');
        const m = P(3.5, 3.5, 132); c.strokeStyle = '#9fb3d6'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(m[0], m[1]); c.lineTo(m[0], m[1] - 34); c.stroke();
        o.beacon = [m[0], m[1] - 35];
      };
      o.glow = [{ p: P(3.5, 3.5, 138), r: 44, c: pal.acc, a: 0.2 }];
    } else {
      o.fp = [1, 1, 5, 5, 205]; o.b = A.bbox(1, 1, 5, 5, 214, 12);
      o.draw = (c) => {
        box(c, 1, 1, 5, 5, 16, 0, pal.concrete);
        const edge = (x, y, w, d, h, z0) => {
          c.strokeStyle = U.rgba(pal.acc, 0.85); c.lineWidth = 1.6; c.beginPath();
          const a = P(x, y + d, z0 + h), z = P(x + w, y + d, z0 + h), e = P(x + w, y, z0 + h); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.lineTo(e[0], e[1]); c.stroke();
        };
        const lit = (s) => (i, j) => (hash(i, j, s) > 0.4 ? 'rgba(255,236,200,.82)' : 'rgba(150,200,255,.3)');
        [[1.4, 4.2, 64, 16, 7, 6, 5], [2.0, 3.0, 56, 80, 5, 7, 6], [2.5, 2.0, 40, 136, 4, 5, 7]].forEach((s) => {
          box(c, s[0], s[0], s[1], s[1], s[2], s[3], pal.glass);
          wins(c, fL(s[0], s[0], s[1], s[1], s[2], s[3]), s[4], s[5], 0.14, 0.18, lit(s[6]));
          wins(c, fR(s[0], s[0], s[1], s[1], s[2], s[3]), s[4], s[5], 0.14, 0.18, lit(s[6] + 9));
          edge(s[0], s[0], s[1], s[1], s[2], s[3]);
        });
        const m = P(3.5, 3.5, 176);
        c.strokeStyle = U.rgba(pal.acc, 0.9); c.lineWidth = 1.5; c.beginPath(); c.moveTo(m[0], m[1]); c.lineTo(m[0], m[1] - 36); c.stroke();
        o.beacon = [m[0], m[1] - 37];
        o.ringC = P(3.5, 3.5, 150);
      };
      o.glow = [{ p: P(3.5, 3.5, 160), r: 70, c: pal.acc, a: 0.22 }];
    }
    return o;
  };

  /* ================= RESEARCH LAB ================= */
  A.lab = function (tier, pal) {
    const o = { id: 'lab', kind: 'lab', tier, name: D.ladders.lab[tier].name };
    if (tier === 1) {
      o.fp = [8.4, 1.5, 4.2, 3.7, 52]; o.b = A.bbox(8.4, 1.5, 4.2, 3.7, 70, 12);
      o.draw = (c) => {
        box(c, 8.1, 1.2, 4.8, 4.3, 3, 0, pal.concrete);
        box(c, 8.4, 1.5, 4.2, 3.7, 32, 3, pal.wall);
        wins(c, fL(8.4, 1.5, 4.2, 3.7, 32, 3), 4, 1, 0.1, 0.2, () => 'rgba(130,215,255,.7)');
        wins(c, fR(8.4, 1.5, 4.2, 3.7, 32, 3), 3, 1, 0.12, 0.2, () => 'rgba(130,215,255,.6)');
        quad(c, fL(8.4, 1.5, 4.2, 3.7, 32, 3), 0.44, 0.56, 0, 0.5, U.rgba(pal.acc, 0.8));
        dome(c, 10.4, 3.2, 1.05, 22, 35, '#9be7ff', 1);
        cyl(c, 12.0, 2.1, 0.22, 12, 35, pal.metal);
      };
      o.glow = [{ p: P(10.4, 3.2, 50), r: 38, c: pal.acc, a: 0.25 }];
      o.orb = { p: P(10.4, 3.2, 70), r: 11 };
    } else if (tier === 2) {
      o.fp = [8.1, 1.3, 5.0, 4.3, 70]; o.b = A.bbox(8.1, 1.3, 5.0, 4.3, 90, 12);
      o.draw = (c) => {
        box(c, 7.9, 1.1, 5.4, 4.7, 3, 0, pal.concrete);
        box(c, 8.1, 1.3, 2.3, 4.2, 40, 3, pal.wall);
        box(c, 11.0, 1.3, 2.1, 4.2, 32, 3, pal.wall);
        box(c, 10.4, 2.5, 0.6, 1.5, 12, 14, pal.glass);
        for (const [x, w, h] of [[8.1, 2.3, 40], [11.0, 2.1, 32]]) {
          wins(c, fL(x, 1.3, w, 4.2, h, 3), 3, 2, 0.14, 0.2, (i, j) => (hash(i, j, x) > 0.25 ? 'rgba(130,215,255,.7)' : 'rgba(255,214,150,.8)'));
          wins(c, fR(x, 1.3, w, 4.2, h, 3), 4, 2, 0.14, 0.2, (i, j) => (hash(i, j, x + 3) > 0.25 ? 'rgba(130,215,255,.6)' : 'rgba(255,214,150,.7)'));
        }
        dome(c, 10.7, 3.35, 1.1, 26, 24, '#9be7ff', 1);
        c.strokeStyle = U.rgba(pal.acc, 0.8); c.lineWidth = 1.4; c.beginPath(); const a = P(8.1, 5.5, 43), z = P(10.4, 5.5, 43); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke();
        cyl(c, 12.3, 2.0, 0.25, 14, 35, pal.metal);
      };
      o.glow = [{ p: P(10.7, 3.35, 52), r: 52, c: pal.acc, a: 0.28 }];
      o.orb = { p: P(10.7, 3.35, 82), r: 14 };
    } else if (tier === 3) {
      o.fp = [8.0, 1.2, 5.2, 4.6, 100]; o.b = A.bbox(8.0, 1.2, 5.2, 4.6, 118, 14);
      o.draw = (c) => {
        const p0 = P(10.6, 3.5, 0), rx = 2.55 * HW * 1.414, ry = 2.55 * HH * 1.414;
        ell(c, p0[0], p0[1] + 6, rx, ry); c.fillStyle = '#0e1630'; c.fill();
        ell(c, p0[0], p0[1], rx, ry); c.fillStyle = '#25345a'; c.fill();
        ell(c, p0[0], p0[1], rx * 0.78, ry * 0.78); c.fillStyle = '#1a2646'; c.fill();
        c.strokeStyle = U.rgba(pal.acc, 0.8); c.lineWidth = 2; ell(c, p0[0], p0[1], rx * 0.78, ry * 0.78); c.stroke();
        cyl(c, 8.9, 2.2, 0.55, 34, 0, pal.wall); cyl(c, 12.4, 4.9, 0.55, 30, 0, pal.wall);
        box(c, 10.05, 2.95, 1.1, 1.1, 78, 0, pal.glass);
        wins(c, fL(10.05, 2.95, 1.1, 1.1, 78, 0), 2, 6, 0.15, 0.2, (i, j) => (hash(i, j, 9) > 0.35 ? 'rgba(160,240,255,.85)' : 'rgba(80,140,200,.4)'));
        wins(c, fR(10.05, 2.95, 1.1, 1.1, 78, 0), 2, 6, 0.15, 0.2, (i, j) => (hash(i, j, 11) > 0.35 ? 'rgba(160,240,255,.7)' : 'rgba(80,140,200,.4)'));
        const t = P(10.6, 3.5, 78); ell(c, t[0], t[1], 9, 4.5); c.fillStyle = U.rgba(pal.acc, 0.9); c.fill();
      };
      o.ring = { c: P(10.6, 3.5, 56), rx: 62, ry: 24 };
      o.glow = [{ p: P(10.6, 3.5, 70), r: 70, c: pal.acc, a: 0.3 }];
      o.orb = { p: P(10.6, 3.5, 112), r: 16 };
    }
    return o.fp ? A.slide(o, A.PLAN.lab.dx, 0) : o;
  };

  /* ================= SERVER HALLS ================= */
  A.HALLS = [
    { x: 6.6, y: 1.4, w: 1.3, d: 1.5, h: 24 },
    { x: 1, y: 7.5, w: 5, d: 4.5, h: 34 },
    { x: 8.5, y: 7.5, w: 6, d: 5, h: 38 },
    { x: 1, y: 13.5, w: 7, d: 5.2, h: 44 },
    { x: 9, y: 15, w: 8, d: 6, h: 50 },
    { x: 15.2, y: 8.2, w: 6, d: 6, h: 56 }
  ];
  A.hallGrid = (lv) => { const H = A.HALLS[lv]; return { cols: Math.max(2, Math.floor((H.w - 1) / 0.72)), rows: Math.max(1, Math.floor((H.d - 0.9) / 1.55)) }; };
  // The closet: a small cooled room behind the office. Its door stands open so you can see the servers inside.
  // mix = servers owned per tier, racks = racks owned (at most three fit in here)
  A.shed = function (pal, mix, racks) {
    const H = A.HALLS[0], o = { id: 'dc0', kind: 'dc', lv: 0, name: D.ladders.dc[0].name, fp: [H.x, H.y, H.w, H.d, H.h] };
    mix = mix || [2, 0, 0, 0, 0, 0, 0];
    let top = 0; mix.forEach((m, i) => { if (m > 0) top = i; });
    const n = Math.max(1, Math.min(3, racks || 1)), u0 = 0.2, gap = 0.04, wd = (0.6 - gap * (n - 1)) / n;
    const slot = (i) => [u0 + i * (wd + gap), u0 + i * (wd + gap) + wd];
    o.b = A.bbox(H.x, H.y, H.w, H.d, H.h + 6, 8);
    o.draw = (c) => {
      box(c, H.x - 0.1, H.y - 0.1, H.w + 0.2, H.d + 0.2, 2, 0, pal.concrete);
      box(c, H.x, H.y, H.w, H.d, H.h, 2, pal.metal);
      const fl = fL(H.x, H.y, H.w, H.d, H.h, 2), fr = fR(H.x, H.y, H.w, H.d, H.h, 2);
      // doorway with the racks inside, and the open door leaf folded back to the left
      quad(c, fl, 0.14, 0.86, 0, 0.74, '#080d1c');
      quad(c, fl, 0.14, 0.86, 0, 0.1, 'rgba(61,214,198,.12)');
      for (let i = 0; i < n; i++) { const [a0, a1] = slot(i); A.hw.mini(c, fl, a0, a1, 0.02, 0.7, top); }
      quad(c, fl, 0.05, 0.14, 0, 0.74, '#3b4868');
      quad(c, fl, 0.05, 0.075, 0, 0.74, 'rgba(255,255,255,.14)');
      quad(c, fl, 0.14, 0.86, 0.74, 0.8, '#3b4868');
      quad(c, fl, 0.2, 0.8, 0.82, 0.92, U.rgba(pal.acc, 0.7));
      for (let i = 0; i < 4; i++) quad(c, fr, 0.2, 0.8, 0.2 + i * 0.15, 0.28 + i * 0.15, 'rgba(10,15,30,.55)');
    };
    o.leds = (c, k) => { const fl = fL(H.x, H.y, H.w, H.d, H.h, 2); for (let i = 0; i < n; i++) { const [a0, a1] = slot(i); A.hw.miniLeds(c, fl, a0, a1, 0.02, 0.7, top, k, i); } };
    o.ledB = A.bbox(H.x, H.y, H.w, H.d, H.h, 6);
    o.fans = [{ p: P(H.x + H.w * 0.5, H.y + H.d * 0.5, 2 + H.h), r: 7 }];
    return o;
  };

  /* racks live in a hall; `n` racks are drawn for `cap` racks of capacity. mix = servers per tier */
  A.hall = function (lv, n, cap, mix, coolLv, pal) {
    const H = A.HALLS[lv], g = A.hallGrid(lv), pos = g.cols * g.rows, HWa = A.hw;
    const draw = n <= 0 ? 0 : Math.max(1, Math.min(pos, Math.round(pos * Math.min(1, n / cap))));
    const o = { id: 'dc' + lv, kind: 'dc', lv, name: D.ladders.dc[lv].name, fp: [H.x, H.y, H.w, H.d, H.h], nDraw: draw, nRacks: n, cap, pos };
    const tot = mix.reduce((a, b) => a + b, 0);
    const tierOf = (k) => { if (tot <= 0) return 0; const q = (k + 0.5) / Math.max(1, draw); let acc = 0; for (let i = 0; i < mix.length; i++) { acc += mix[i] / tot; if (q <= acc + 1e-9) return i; } return mix.length - 1; };
    const rp = [];
    for (let k = 0; k < draw; k++) { const col = k % g.cols, row = Math.floor(k / g.cols); rp.push({ x: H.x + 0.95 + col * 0.72, y: H.y + 0.75 + row * 1.55, t: tierOf(k) }); }
    o.racks = rp;
    const maxH = rp.reduce((m, r) => Math.max(m, HWa.H[r.t]), 17);
    o.b = A.bbox(H.x, H.y, H.w, H.d, Math.max(H.h, maxH + 14) + 10, 12);
    // tall cryostats let off a little mist
    o.bubbles = rp.filter((r) => r.t === 5).slice(0, 4).map((r) => ({ p: HWa.mistAt(r.x, r.y, 3, 5), mist: 1 }));
    o.draw = (c) => {
      box(c, H.x - 0.2, H.y - 0.2, H.w + 0.4, H.d + 0.4, 3, 0, pal.concrete);
      box(c, H.x, H.y, H.w, H.d, 3, 3, pal.hall);
      // glowing floor grid
      c.strokeStyle = U.rgba(pal.acc, 0.16); c.lineWidth = 1; c.beginPath();
      for (let i = 1; i < H.w; i++) { const a = P(H.x + i, H.y, 6), z = P(H.x + i, H.y + H.d, 6); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      for (let j = 1; j < H.d; j++) { const a = P(H.x, H.y + j, 6), z = P(H.x + H.w, H.y + j, 6); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      c.stroke();
      // bigger halls keep cold air in front of the racks and hot air behind them
      if (lv >= 2) for (let r = 0; r < g.rows; r++) {
        const yy = H.y + 0.75 + r * 1.55;
        poly(c, [P(H.x + 0.8, yy + 0.95, 3.4), P(H.x + H.w - 0.3, yy + 0.95, 3.4), P(H.x + H.w - 0.3, yy + 1.45, 3.4), P(H.x + 0.8, yy + 1.45, 3.4)], 'rgba(77,200,255,.1)');
        poly(c, [P(H.x + 0.8, yy - 0.35, 3.4), P(H.x + H.w - 0.3, yy - 0.35, 3.4), P(H.x + H.w - 0.3, yy - 0.05, 3.4), P(H.x + 0.8, yy - 0.05, 3.4)], 'rgba(255,130,70,.09)');
      }
      // back walls
      box(c, H.x, H.y, 0.22, H.d, H.h, 3, pal.wall); box(c, H.x, H.y, H.w, 0.22, H.h, 3, pal.wall);
      const fa = fR(H.x, H.y, 0.22, H.d, H.h, 3), fb = fL(H.x, H.y, H.w, 0.22, H.h, 3);
      for (const f of [fa, fb]) {
        quad(c, f, 0.04, 0.96, 0.55, 0.92, 'rgba(10,16,34,.5)');
        for (let i = 0; i < 6; i++) quad(c, f, 0.04, 0.96, 0.58 + i * 0.055, 0.6 + i * 0.055, 'rgba(255,255,255,.07)');
        quad(c, f, 0.04, 0.96, 0.2, 0.26, U.rgba(pal.acc, 0.55));
      }
      // cooling units along the back wall
      const nCool = Math.min(Math.floor(H.d / 1.4), 1 + coolLv);
      for (let i = 0; i < nCool; i++) { const cy = H.y + 0.5 + i * 1.35; box(c, H.x + 0.28, cy, 0.5, 0.9, 13, 3, pal.white); const f = fR(H.x + 0.28, cy, 0.5, 0.9, 13, 3); for (let s = 0; s < 4; s++) quad(c, f, 0.1, 0.9, 0.15 + s * 0.2, 0.2 + s * 0.2, 'rgba(40,60,100,.55)'); }
      // racks, back to front. Every tier has its own look (see art-hw.js)
      rp.slice().sort((a, b) => (a.x + a.y) - (b.x + b.y)).forEach((r) => HWa.rack(c, r.t, r.x, r.y, 3, pal));
      // overhead tray and frame
      const tz = H.h + 3;
      c.strokeStyle = 'rgba(255,170,90,.55)'; c.lineWidth = 2; c.beginPath();
      for (let r = 0; r < g.rows; r++) { const a = P(H.x + 0.8, H.y + 1.05 + r * 1.55, tz - 5), z = P(H.x + H.w - 0.4, H.y + 1.05 + r * 1.55, tz - 5); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      c.stroke();
      const colH = (x, y) => { const a = P(x, y, 3), z = P(x, y, tz); c.strokeStyle = 'rgba(210,225,255,.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke(); };
      colH(H.x + 0.1, H.y + H.d - 0.1); colH(H.x + H.w - 0.1, H.y + 0.1); colH(H.x + H.w - 0.1, H.y + H.d - 0.1);
      c.strokeStyle = U.rgba(pal.acc, 0.8); c.lineWidth = 2; c.beginPath();
      const w1 = P(H.x, H.y + H.d, tz), s1 = P(H.x + H.w, H.y + H.d, tz), e1 = P(H.x + H.w, H.y, tz); c.moveTo(w1[0], w1[1]); c.lineTo(s1[0], s1[1]); c.lineTo(e1[0], e1[1]); c.stroke();
      if (lv >= 5) { dome(c, H.x + H.w / 2, H.y + H.d / 2, H.w * 0.52, 60, H.h + 3, '#8fd6ff', 0.55); }
    };
    // blinking LED layers (drawn into small sprites by the scene)
    o.ledB = A.bbox(H.x, H.y, H.w, H.d, maxH + 12, 6);
    o.leds = (c, k) => rp.forEach((r, ri) => HWa.leds(c, r.t, r.x, r.y, 3, k, ri));
    o.glow = draw ? [{ p: P(H.x + H.w / 2, H.y + H.d / 2, 14), r: Math.min(95, 28 + H.w * 9), c: cols0(mix), a: 0.14 }] : [];
    return o;
  };
  function cols0(mix) { let b = 0; mix.forEach((m, i) => { if (m > 0) b = i; }); return A.hw.accent(b); }

  /* ================= COOLING YARD ================= */
  A.COOLX = 6.2;
  A.cooling = function (lv, pal) {
    const X = A.COOLX;
    const o = { id: 'cool', kind: 'cool', lv, name: D.ladders.cool[lv].name, fp: [X, 7.6, 1.2, 4.8, 40], fans: [], bubbles: [] };
    o.b = A.bbox(X, 7.6, 1.2, 4.8, 54, 12);
    const n = 3 + lv;
    o.draw = (c) => {
      box(c, X - 0.05, 7.55, 1.3, 4.9, 2, 0, pal.concrete);
      for (let i = 0; i < n; i++) {
        const y = 7.75 + i * (4.3 / n), z = 2, cx = X + 0.6;
        if (lv <= 1) {
          const hh = lv === 0 ? 9 : 15;
          box(c, X + 0.2, y, 0.8, 0.8, hh, z, pal.white);
          const f = fL(X + 0.2, y, 0.8, 0.8, hh, z); for (let s = 0; s < 3; s++) quad(c, f, 0.12, 0.88, 0.15 + s * 0.28, 0.25 + s * 0.28, 'rgba(40,60,100,.5)');
          o.fans.push({ p: P(cx, y + 0.4, z + hh), r: 8 });
        } else if (lv === 2) {
          box(c, X + 0.2, y, 0.8, 0.8, 14, z, pal.white); cyl(c, cx, y + 0.4, 0.24, 24, z + 14, tri('#6fd5e8'));
          o.fans.push({ p: P(cx, y + 0.4, z + 38), r: 8 });
        } else if (lv === 3) {
          box(c, X + 0.18, y, 0.85, 0.8, 18, z, tri('#3aa6cc'));
          const f = fL(X + 0.18, y, 0.85, 0.8, 18, z); quad(c, f, 0.1, 0.9, 0.12, 0.8, 'rgba(120,230,255,.35)');
          o.bubbles.push({ p: P(cx, y + 0.4, z + 18), w: 18 });
        } else if (lv === 4) {
          cyl(c, cx, y + 0.4, 0.38, 26, z, tri('#dbeaff')); o.bubbles.push({ p: P(cx, y + 0.4, z + 28), w: 14, mist: 1 });
        } else {
          box(c, X + 0.3, y + 0.1, 0.6, 0.6, 34, z, tri('#6a4fd0'));
          o.bubbles.push({ p: P(cx, y + 0.4, z + 36), w: 10, mist: 1 });
        }
      }
    };
    return o;
  };

  /* ================= POWER ================= */
  A.power = function (lv, pal) {
    const o = { id: 'pwr' + lv, kind: 'pwr', lv, name: D.ladders.pwr[lv].name, fans: [], smoke: [], glow: [] };
    if (lv === 1) {
      o.fp = [14.3, 1.1, 2, 2, 50]; o.b = A.bbox(14.3, 1.1, 2, 2, 62, 12);
      o.draw = (c) => {
        box(c, 14.2, 1.0, 2.2, 2.2, 2, 0, pal.concrete);
        box(c, 14.5, 1.4, 0.7, 0.9, 14, 2, pal.metal); box(c, 15.4, 1.8, 0.7, 0.9, 14, 2, pal.metal);
        for (const [x, y] of [[14.5, 2.4], [15.5, 1.3]]) { const a = P(x, y, 2), t = P(x, y, 56); c.strokeStyle = '#9fb3d6'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(a[0] - 4, a[1]); c.lineTo(t[0], t[1]); c.lineTo(a[0] + 4, a[1]); c.stroke(); c.beginPath(); c.moveTo(t[0] - 10, t[1] + 6); c.lineTo(t[0] + 10, t[1] + 6); c.stroke(); }
      };
      o.glow = [{ p: P(15, 2, 20), r: 26, c: '#ffd28a', a: 0.12 }];
    } else if (lv === 2) {
      o.fp = [16.9, 1.0, 4, 3.2, 20]; o.b = A.bbox(16.9, 1.0, 4, 3.2, 26, 10);
      o.draw = (c) => {
        box(c, 16.9, 1.0, 4, 3.2, 2, 0, pal.concrete);
        for (let i = 0; i < 4; i++) for (let j = 0; j < 2; j++) {
          const x = 17.1 + i * 0.85, y = 1.2 + j * 1.0;
          poly(c, [P(x, y, 14), P(x + 0.72, y, 14), P(x + 0.72, y + 0.8, 7), P(x, y + 0.8, 7)], '#2b5f9e', 'rgba(180,220,255,.45)');
          const a = P(x + 0.3, y + 0.8, 7), z = P(x + 0.3, y + 0.8, 2); c.strokeStyle = '#7a8aa8'; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke();
        }
        box(c, 17.2, 3.3, 1.0, 0.7, 9, 2, pal.white); box(c, 18.6, 3.3, 1.0, 0.7, 9, 2, pal.white);
        for (const x of [17.2, 18.6]) quad(c, fL(x, 3.3, 1.0, 0.7, 9, 2), 0.15, 0.85, 0.3, 0.45, '#46e39a');
      };
      o.glow = [{ p: P(18.5, 2.5, 10), r: 40, c: '#5aa8ff', a: 0.12 }];
    } else if (lv === 3) {
      o.fp = [14.3, 3.7, 2.6, 2.6, 66]; o.b = A.bbox(14.3, 3.7, 2.6, 2.6, 82, 12);
      o.draw = (c) => {
        box(c, 14.2, 3.6, 2.8, 2.8, 2, 0, pal.concrete);
        box(c, 14.4, 4.7, 2.3, 1.5, 22, 2, pal.metal);
        quad(c, fL(14.4, 4.7, 2.3, 1.5, 22, 2), 0.1, 0.9, 0.4, 0.6, 'rgba(255,200,120,.7)');
        cyl(c, 14.9, 4.2, 0.28, 46, 2, pal.white); cyl(c, 15.8, 4.2, 0.28, 38, 2, pal.white);
        o.smoke.push({ p: P(14.9, 4.2, 50), s: 1 }, { p: P(15.8, 4.2, 42), s: 0.9 });
      };
      o.glow = [{ p: P(15.5, 5.4, 14), r: 36, c: '#ffb066', a: 0.16 }];
    } else if (lv === 4) {
      o.fp = [17.4, 4.4, 3, 3, 46]; o.b = A.bbox(17.4, 4.4, 3, 3, 60, 12);
      o.draw = (c) => {
        box(c, 17.3, 4.3, 3.2, 3.2, 2, 0, pal.concrete);
        cyl(c, 18.9, 5.9, 1.15, 14, 2, pal.white);
        dome(c, 18.9, 5.9, 0.95, 30, 16, '#7fe9ff', 0.9);
        const p = P(18.9, 5.9, 20); c.strokeStyle = U.rgba(pal.acc, 0.9); c.lineWidth = 2; ell(c, p[0], p[1], 22, 11); c.stroke();
      };
      o.ring = { c: P(18.9, 5.9, 20), rx: 22, ry: 11, small: 1 };
      o.glow = [{ p: P(18.9, 5.9, 30), r: 60, c: '#7fe9ff', a: 0.3 }];
    } else if (lv === 5) {
      // Orbital solar array: a ground rectenna catching a beam of power from orbit
      o.fp = [17.8, 15.4, 3.2, 3.2, 90]; o.b = A.bbox(17.8, 15.4, 3.2, 3.2, 130, 14);
      o.draw = (c) => {
        box(c, 17.7, 15.3, 3.4, 3.4, 2, 0, pal.concrete);
        for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
          const x = 17.95 + i * 1.0, y = 15.55 + j * 1.0;
          poly(c, [P(x, y, 12), P(x + 0.85, y, 12), P(x + 0.85, y + 0.85, 6), P(x, y + 0.85, 6)], '#2f6fc0', 'rgba(255,224,150,.55)');
          const a = P(x + 0.42, y + 0.85, 6), z = P(x + 0.42, y + 0.85, 2); c.strokeStyle = '#7a8aa8'; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke();
        }
        const m0 = P(19.4, 17.0, 2), m1 = P(19.4, 17.0, 86);
        c.strokeStyle = '#dbe6ff'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(m0[0], m0[1]); c.lineTo(m1[0], m1[1]); c.stroke();
        const bg = c.createLinearGradient(m1[0], m1[1] - 40, m1[0], m1[1]); bg.addColorStop(0, 'rgba(255,224,138,0)'); bg.addColorStop(1, 'rgba(255,224,138,.8)');
        c.fillStyle = bg; c.fillRect(m1[0] - 3.5, m1[1] - 40, 7, 40);
        ell(c, m1[0], m1[1], 12, 6); c.fillStyle = '#ffe08a'; c.fill();
      };
      o.ring = { c: P(19.4, 17.0, 50), rx: 26, ry: 12, small: 1 };
      o.glow = [{ p: P(19.4, 17.0, 90), r: 70, c: '#ffe08a', a: 0.3 }];
    }
    return o;
  };

  /* ================= NETWORK TOWER ================= */
  A.tower = function (lv, pal) {
    const N = A.PLAN.net, nx = N.x + N.s / 2, ny = N.y + N.s / 2;
    const o = { id: 'net', kind: 'net', lv, name: D.ladders.net[lv].name, fp: [N.x, N.y, N.s, N.s, 70] };
    o.b = A.bbox(N.x, N.y, N.s, N.s, 86, 24);
    const h = 40 + lv * 7;
    { const bp = P(nx, ny); o.tb = [bp[0] - 20, bp[1] - h - 12, bp[0] + 20, bp[1] + 10]; }
    o.draw = (c) => {
      const b = P(nx, ny, 0);
      ell(c, b[0], b[1], 11, 5.5); c.fillStyle = '#27355a'; c.fill();
      c.strokeStyle = '#a8b9da'; c.lineWidth = 1.6; c.beginPath();
      c.moveTo(b[0] - 7, b[1]); c.lineTo(b[0], b[1] - h); c.lineTo(b[0] + 7, b[1]); c.moveTo(b[0] - 5, b[1] - 9); c.lineTo(b[0] + 5, b[1] - 9); c.moveTo(b[0] - 3.5, b[1] - 19); c.lineTo(b[0] + 3.5, b[1] - 19); c.stroke();
      for (let i = 0; i < Math.min(5, lv + 1); i++) {
        const y = b[1] - 14 - i * 6.5, side = i % 2 ? 1 : -1;
        c.fillStyle = '#dbe6ff'; ell(c, b[0] + side * 7, y, 5, 3); c.fill();
        c.strokeStyle = '#8a9cc4'; c.lineWidth = 1; c.beginPath(); c.moveTo(b[0], y); c.lineTo(b[0] + side * 5, y); c.stroke();
      }
      o.top = [b[0], b[1] - h];
      // the better the network, the more it glows: lenses on the dishes, then a halo, then a beam of light
      if (lv >= 3) { const g2 = c.createRadialGradient(b[0], b[1] - h, 1, b[0], b[1] - h, 9); g2.addColorStop(0, U.rgba(pal.acc, 0.95)); g2.addColorStop(1, U.rgba(pal.acc, 0)); c.fillStyle = g2; c.fillRect(b[0] - 9, b[1] - h - 9, 18, 18); }
      if (lv >= 4) { c.strokeStyle = U.rgba(pal.acc, 0.8); c.lineWidth = 1.3; c.beginPath(); c.ellipse(b[0], b[1] - h + 6, 11, 4.5, 0, 0, 6.283); c.stroke(); }
      if (lv >= 5) { const g3 = c.createLinearGradient(0, b[1] - h - 36, 0, b[1] - h); g3.addColorStop(0, 'rgba(255,255,255,0)'); g3.addColorStop(1, U.rgba(pal.acc, 0.8)); c.fillStyle = g3; c.fillRect(b[0] - 1.6, b[1] - h - 36, 3.2, 36); }
    };
    if (lv >= 3) o.glow = [{ p: P(nx, ny, h), r: 22 + lv * 4, c: pal.acc, a: 0.22 }];
    return o;
  };

  /* ================= CONSTRUCTION SITE ================= */
  A.site = function (fp, name) {
    const x = fp[0], y = fp[1], w = fp[2], d = fp[3];
    const o = { id: 'site', kind: 'site', name: 'Under construction', fp: [x, y, w, d, 40] };
    o.b = A.bbox(x, y, w, d, 96, 14);
    o.draw = (c) => {
      box(c, x, y, w, d, 2, 0, tri('#3a3f52'));
      c.strokeStyle = 'rgba(255,190,70,.8)'; c.lineWidth = 2; c.setLineDash([6, 5]);
      const a = P(x, y + d, 3), z = P(x + w, y + d, 3), e = P(x + w, y, 3); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.lineTo(e[0], e[1]); c.stroke(); c.setLineDash([]);
      const cx = x + w - 0.5, cy = y + d - 0.5, base = P(cx, cy, 2), top = P(cx, cy, 90);
      c.strokeStyle = '#e8b030'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(base[0], base[1]); c.lineTo(top[0], top[1]); c.stroke();
      c.lineWidth = 1; for (let i = 1; i < 9; i++) { const p = P(cx, cy, 2 + i * 10); c.beginPath(); c.moveTo(p[0] - 3, p[1]); c.lineTo(p[0] + 3, p[1] - 5); c.stroke(); }
      o.crane = top;
      box(c, x + 0.3, y + 0.3, 0.8, 0.8, 8, 2, tri('#e8b030')); box(c, x + 1.3, y + 0.4, 0.6, 0.6, 5, 2, tri('#4b5ca0'));
    };
    return o;
  };
})();
