#include <jni.h>
#include "core/game.h"

static Game g_game;

extern "C" JNIEXPORT void JNICALL
Java_com_example_gtaclone_MainActivity_nativeInit(JNIEnv* env, jobject obj) {
    g_game.Initialize();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_gtaclone_MainActivity_nativeSurfaceChanged(JNIEnv* env, jobject obj, jint width, jint height) {
    g_game.Resize(width, height);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_gtaclone_MainActivity_nativeUpdate(JNIEnv* env, jobject obj) {
    g_game.UpdateAndRender();
}
