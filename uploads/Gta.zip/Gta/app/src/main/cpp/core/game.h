#ifndef GAME_H
#define GAME_H

class Game {
public:
    void Initialize();
    void Resize(int width, int height);
    void UpdateAndRender();

private:
    float vehiclePositionX = 0.0f;
    float vehicleVelocityX = 0.005f;
};

#endif
