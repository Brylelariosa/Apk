package com.example.gtaclone;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private GLSurfaceView glView;

    static {
        System.loadLibrary("gtagame");
    }

    private native void nativeInit();
    private native void nativeSurfaceChanged(int width, int height);
    private native void nativeUpdate();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setRenderer(new GLSurfaceView.Renderer() {
            @Override
            public void onSurfaceCreated(GL10 gl, EGLConfig config) { nativeInit(); }
            @Override
            public void onSurfaceChanged(GL10 gl, int width, int height) { nativeSurfaceChanged(width, height); }
            @Override
            public void onDrawFrame(GL10 gl) { nativeUpdate(); }
        });
        setContentView(glView);
    }
}
