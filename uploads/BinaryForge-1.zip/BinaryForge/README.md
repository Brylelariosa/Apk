# BinaryForge

Offline Android tool that inspects binaries (ELF, PE, raw BIN/DAT/IMG), disassembles code, finds functions
and cross-references, extracts strings, and shows everything in a hex viewer and code explorer.
The core is Rust, the UI is Kotlin/Compose, and they talk over JNI. No network permission, no root, no AI model.

This is **milestone 1 (priorities 1 and 2 of the spec)**. See "What is and is not done" below.

## Layout

```
Cargo.toml          Rust workspace (found by the CI workflow; builds core + jni)
core/               analysis engine (library crate, depends only on std + capstone)
  src/parser        bounded reads over untrusted input (positioned file reads, no whole-file loads)
  src/formats       format detection, ELF and PE parsers, raw fallback
  src/architecture  architecture from headers, or estimated from code patterns for raw files
  src/memory        virtual address <-> file offset mapping
  src/disassembler  backend trait, Capstone backend, text-based flow/target classification
  src/functions     function discovery (symbols, exception tables, entry points, relocations, call targets)
  src/references    cross-reference table
  src/dependencies  libraries and imports
  src/extraction    string extraction (ASCII + UTF-16LE), byte search
  src/project       analysis session: lifecycle, progress, cancellation, JSON views for the app
jni/                libbinaryforge.so: thin JNI layer (every call is panic-guarded, errors are JSON)
app/                Android app (Kotlin, Jetpack Compose, minSdk 26)
```

## How analysis works

1. **Import** copies the picked file into app-private storage (hashing it with SHA-256 on the way). The original is
   only read. Analysis runs on the private copy, which is opened read-only and never executed.
2. **Structure pass** (fast): format detection, headers, sections/segments, symbols, imports, entry points.
   Anything the file does not state is left out or tagged `assumed`/`estimated`.
3. **Deep pass** (background, cancellable, progress reported): linear sweep of code regions, cross-references,
   function discovery, strings. The hex view and structure tabs are usable while it runs.

Confidence tags used everywhere: `verified` (read from a structure the file defines), `likely` (reliable rule, not
stated by the file, e.g. a direct call target), `estimated` (heuristic), `assumed` (typed in by the user).

## Building

CI: push the ZIP to `uploads/` as before. The workflow finds `Cargo.toml` at the project root, builds
`libbinaryforge.so` with cargo-ndk into `app/src/main/jniLibs`, then Gradle packages it. ABIs come from
`rustAbis=` in `gradle.properties` (default `arm64-v8a`).

The workflow currently insists on a library named `libvoxelsandbox.so`. Change that check to accept any library:

```
if ! find "$JNI_DIR" -name '*.so' | grep -q .; then
```

Local: `cargo ndk -t arm64-v8a -o app/src/main/jniLibs build --release`, then `./gradlew assembleDebug`.
Engine tests (desktop): `cargo test --lib`.

## What is and is not done

Done (milestone 1):
- File import with SHA-256, project list, storage view, delete, integrity re-check, analysis limits (threads, memory).
- ELF 32/64 (either endianness) with or without section headers, PE32/PE32+ (imports, delay imports, exports,
  x64 exception-table function ranges), raw files with manual or estimated architecture.
- Disassembly: x86, x86-64, AArch64 (Capstone). Branch targets, call/jump/return flow, RIP-relative and
  `adrp`+`add`/`ldr` address resolution (heuristic), function and string annotations.
- Function discovery with per-function source and an explicit `estimated end` marker; cross-references;
  per-function statistics (flow counts, calls, registers referenced, data refs, callers).
- Hex viewer (go to, find hex/text), strings, symbols, imports, sections, segments, code regions.

Not done yet (later priorities, nothing is faked in the UI):
- Graphics/texture/model/animation/shader/audio detection and extraction (priority 3).
- Metadata normalization, AI_GUIDE.md and the structured export ZIP (priority 4).
- Analysis checkpoints/resume, crash recovery, fuzz-style tests, advanced formats (priority 5).
- Disassembly for 32-bit ARM/Thumb, MIPS, PowerPC, RISC-V; Mach-O and ISO parsers (detected, shown as raw).
- ELF packed relocations (Android APS2/RELR) are detected and reported but not decoded; PLT stubs are not
  mapped to import names on AArch64.
- Function ends are exact only when a symbol size or exception table says so; otherwise they are marked estimated.
