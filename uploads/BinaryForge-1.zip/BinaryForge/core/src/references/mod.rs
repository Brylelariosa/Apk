//! Cross-references between addresses.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum XrefKind {
    Call,
    Jump,
    CondJump,
    /// A memory operand or address materialization that points at `to`.
    Data,
}

impl XrefKind {
    pub fn name(self) -> &'static str {
        match self {
            XrefKind::Call => "call",
            XrefKind::Jump => "jump",
            XrefKind::CondJump => "cond_jump",
            XrefKind::Data => "data",
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Xref {
    pub from: u64,
    pub to: u64,
    pub kind: XrefKind,
}

/// All references, sorted by destination so "who points here?" is a binary search.
pub struct XrefTable {
    by_to: Vec<Xref>,
}

impl XrefTable {
    pub fn new(mut list: Vec<Xref>) -> XrefTable {
        list.sort_by(|a, b| (a.to, a.from).cmp(&(b.to, b.from)));
        XrefTable { by_to: list }
    }

    pub fn len(&self) -> usize {
        self.by_to.len()
    }

    pub fn is_empty(&self) -> bool {
        self.by_to.is_empty()
    }

    /// Every reference whose destination is exactly `target`.
    pub fn to(&self, target: u64) -> &[Xref] {
        let start = self.by_to.partition_point(|x| x.to < target);
        let end = self.by_to.partition_point(|x| x.to <= target);
        &self.by_to[start..end]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lookup_by_destination() {
        let table = XrefTable::new(vec![
            Xref { from: 5, to: 100, kind: XrefKind::Call },
            Xref { from: 1, to: 100, kind: XrefKind::Jump },
            Xref { from: 9, to: 200, kind: XrefKind::Data },
        ]);
        assert_eq!(table.len(), 3);
        let hits = table.to(100);
        assert_eq!(hits.len(), 2);
        assert_eq!(hits[0].from, 1);
        assert_eq!(hits[1].from, 5);
        assert!(table.to(150).is_empty());
        assert_eq!(table.to(200)[0].kind, XrefKind::Data);
    }
}
