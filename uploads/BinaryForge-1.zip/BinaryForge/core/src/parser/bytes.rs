//! Bounds-checked reads of integers from an in-memory structure.

use crate::error::{Error, Result};
use crate::types::Endian;

#[derive(Clone, Copy)]
pub struct Bytes<'a> {
    data: &'a [u8],
    endian: Endian,
}

impl<'a> Bytes<'a> {
    pub fn new(data: &'a [u8], endian: Endian) -> Bytes<'a> {
        Bytes { data, endian }
    }

    pub fn len(&self) -> usize {
        self.data.len()
    }

    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }

    fn slice(&self, at: usize, n: usize) -> Result<&'a [u8]> {
        let d: &'a [u8] = self.data;
        match at.checked_add(n) {
            Some(end) if end <= d.len() => Ok(&d[at..end]),
            _ => Err(Error::Malformed(format!(
                "field at +0x{:x} (size {}) lies outside a {}-byte structure",
                at,
                n,
                d.len()
            ))),
        }
    }

    pub fn u8(&self, at: usize) -> Result<u8> {
        let b = self.slice(at, 1)?;
        Ok(b[0])
    }

    pub fn u16(&self, at: usize) -> Result<u16> {
        let b = self.slice(at, 2)?;
        let a = [b[0], b[1]];
        Ok(match self.endian {
            Endian::Little => u16::from_le_bytes(a),
            Endian::Big => u16::from_be_bytes(a),
        })
    }

    pub fn u32(&self, at: usize) -> Result<u32> {
        let b = self.slice(at, 4)?;
        let a = [b[0], b[1], b[2], b[3]];
        Ok(match self.endian {
            Endian::Little => u32::from_le_bytes(a),
            Endian::Big => u32::from_be_bytes(a),
        })
    }

    pub fn u64(&self, at: usize) -> Result<u64> {
        let b = self.slice(at, 8)?;
        let a = [b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]];
        Ok(match self.endian {
            Endian::Little => u64::from_le_bytes(a),
            Endian::Big => u64::from_be_bytes(a),
        })
    }

    /// Pointer-sized value (4 or 8 bytes) widened to u64.
    pub fn word(&self, at: usize, is64: bool) -> Result<u64> {
        if is64 {
            self.u64(at)
        } else {
            Ok(self.u32(at)? as u64)
        }
    }

    /// NUL-terminated string at `at` (lossy). Empty when `at` is out of range.
    pub fn cstr(&self, at: usize) -> String {
        if at >= self.data.len() {
            return String::new();
        }
        let rest = &self.data[at..];
        let end = rest.iter().position(|&b| b == 0).unwrap_or(rest.len());
        String::from_utf8_lossy(&rest[..end]).into_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_both_endians_and_rejects_overruns() {
        let data = [1u8, 2, 3, 4, 5, 6, 7, 8];
        let le = Bytes::new(&data, Endian::Little);
        let be = Bytes::new(&data, Endian::Big);
        assert_eq!(le.u16(0).unwrap(), 0x0201);
        assert_eq!(be.u16(0).unwrap(), 0x0102);
        assert_eq!(le.u32(4).unwrap(), 0x08070605);
        assert_eq!(be.u64(0).unwrap(), 0x0102030405060708);
        assert!(le.u32(6).is_err());
        assert!(le.u8(8).is_err());
        assert!(le.u64(usize::MAX).is_err());
    }

    #[test]
    fn reads_c_strings() {
        let data = b"abc\0def";
        let b = Bytes::new(data, Endian::Little);
        assert_eq!(b.cstr(0), "abc");
        assert_eq!(b.cstr(4), "def");
        assert_eq!(b.cstr(99), "");
    }
}
