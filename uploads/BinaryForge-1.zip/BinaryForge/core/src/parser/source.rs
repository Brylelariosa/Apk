//! Random-access byte sources. The original file is only ever opened read-only.

use crate::error::{Error, Result};
use std::fs::File;
use std::path::Path;

pub trait ByteSource: Send + Sync {
    fn len(&self) -> u64;
    /// Reads up to `buf.len()` bytes at `offset`. Returns 0 at end of file.
    fn read_at(&self, offset: u64, buf: &mut [u8]) -> Result<usize>;
}

/// A file read with positioned reads (no memory mapping, no whole-file loads).
pub struct FileSource {
    file: File,
    len: u64,
}

impl FileSource {
    pub fn open(path: &Path) -> Result<FileSource> {
        let file = File::open(path)?;
        let len = file.metadata()?.len();
        Ok(FileSource { file, len })
    }
}

#[cfg(unix)]
impl ByteSource for FileSource {
    fn len(&self) -> u64 {
        self.len
    }

    fn read_at(&self, offset: u64, buf: &mut [u8]) -> Result<usize> {
        use std::os::unix::fs::FileExt;
        if offset >= self.len || buf.is_empty() {
            return Ok(0);
        }
        loop {
            match self.file.read_at(buf, offset) {
                Ok(n) => return Ok(n),
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(e) => return Err(Error::from(e)),
            }
        }
    }
}

/// In-memory source, used by tests and for small synthetic images.
pub struct MemSource {
    data: Vec<u8>,
}

impl MemSource {
    pub fn new(data: Vec<u8>) -> MemSource {
        MemSource { data }
    }
}

impl ByteSource for MemSource {
    fn len(&self) -> u64 {
        self.data.len() as u64
    }

    fn read_at(&self, offset: u64, buf: &mut [u8]) -> Result<usize> {
        if offset >= self.data.len() as u64 {
            return Ok(0);
        }
        let start = offset as usize;
        let n = buf.len().min(self.data.len() - start);
        buf[..n].copy_from_slice(&self.data[start..start + n]);
        Ok(n)
    }
}
