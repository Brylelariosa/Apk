//! Safe access to untrusted input: bounded reads and byte-order aware decoding.

mod bytes;
mod source;

pub use bytes::Bytes;
pub use source::{ByteSource, FileSource, MemSource};

use crate::error::{Error, Result};

/// Largest single allocation the parsers will make for a table read.
pub const MAX_READ_BYTES: u64 = 256 * 1024 * 1024;

pub fn check_range(src: &dyn ByteSource, offset: u64, len: u64) -> Result<()> {
    let size = src.len();
    match offset.checked_add(len) {
        Some(end) if end <= size => Ok(()),
        _ => Err(Error::OutOfBounds { offset, len, size }),
    }
}

pub fn read_exact_at(src: &dyn ByteSource, offset: u64, buf: &mut [u8]) -> Result<()> {
    check_range(src, offset, buf.len() as u64)?;
    let mut done: usize = 0;
    while done < buf.len() {
        let n = src.read_at(offset + done as u64, &mut buf[done..])?;
        if n == 0 {
            return Err(Error::Io("unexpected end of file".to_string()));
        }
        done += n;
    }
    Ok(())
}

/// Reads exactly `len` bytes; fails if the range is outside the file.
pub fn read_vec(src: &dyn ByteSource, offset: u64, len: u64) -> Result<Vec<u8>> {
    if len > MAX_READ_BYTES {
        return Err(Error::Limit(format!(
            "a single read of {} bytes exceeds the {} byte limit",
            len, MAX_READ_BYTES
        )));
    }
    check_range(src, offset, len)?;
    let mut v = vec![0u8; len as usize];
    read_exact_at(src, offset, &mut v)?;
    Ok(v)
}

/// Reads up to `len` bytes, clamped to the end of the file. Never fails on range.
pub fn read_clamped(src: &dyn ByteSource, offset: u64, len: u64) -> Result<Vec<u8>> {
    let size = src.len();
    if offset >= size {
        return Ok(Vec::new());
    }
    let avail = (size - offset).min(len);
    read_vec(src, offset, avail)
}

/// Reads a NUL-terminated string of at most `max` bytes.
pub fn read_cstr(src: &dyn ByteSource, offset: u64, max: usize) -> Result<String> {
    let mut out: Vec<u8> = Vec::new();
    let mut pos = offset;
    let mut block = [0u8; 64];
    while out.len() < max {
        let n = src.read_at(pos, &mut block)?;
        if n == 0 {
            break;
        }
        for i in 0..n {
            if block[i] == 0 {
                return Ok(String::from_utf8_lossy(&out).into_owned());
            }
            out.push(block[i]);
            if out.len() >= max {
                return Ok(String::from_utf8_lossy(&out).into_owned());
            }
        }
        pos += n as u64;
    }
    Ok(String::from_utf8_lossy(&out).into_owned())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bounded_reads() {
        let src = MemSource::new(vec![1, 2, 3, 4]);
        assert_eq!(read_vec(&src, 1, 2).unwrap(), vec![2, 3]);
        assert!(read_vec(&src, 3, 2).is_err());
        assert!(read_vec(&src, u64::MAX, 2).is_err());
        assert_eq!(read_clamped(&src, 2, 100).unwrap(), vec![3, 4]);
        assert_eq!(read_clamped(&src, 10, 4).unwrap(), Vec::<u8>::new());
    }

    #[test]
    fn cstr_reads() {
        let src = MemSource::new(b"hello\0world".to_vec());
        assert_eq!(read_cstr(&src, 0, 100).unwrap(), "hello");
        assert_eq!(read_cstr(&src, 6, 100).unwrap(), "world");
        assert_eq!(read_cstr(&src, 0, 3).unwrap(), "hel");
    }
}
