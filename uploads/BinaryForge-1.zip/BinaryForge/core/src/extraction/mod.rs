//! Extraction of data that lives inside a binary: strings and byte-pattern search.
//! Resource extraction (textures, models, audio ...) is planned for a later milestone.

pub mod strings;

use crate::error::Result;
use crate::parser::{read_exact_at, ByteSource};

/// Finds the first occurrence of `pattern` at or after `from`.
pub fn find_bytes(src: &dyn ByteSource, from: u64, pattern: &[u8]) -> Result<Option<u64>> {
    if pattern.is_empty() {
        return Ok(None);
    }
    let size = src.len();
    let plen = pattern.len();
    let chunk: usize = 1 << 20;
    let mut buf: Vec<u8> = vec![0u8; chunk + plen];
    let mut pos = from;
    while pos < size {
        let window = (chunk + plen) as u64;
        let want = window.min(size - pos) as usize;
        read_exact_at(src, pos, &mut buf[..want])?;
        let data = &buf[..want];
        if data.len() >= plen {
            let last_start = data.len() - plen;
            let mut i = 0usize;
            while i <= last_start {
                match data[i..=last_start].iter().position(|&b| b == pattern[0]) {
                    Some(p) => {
                        i += p;
                        if &data[i..i + plen] == pattern {
                            return Ok(Some(pos + i as u64));
                        }
                        i += 1;
                    }
                    None => break,
                }
            }
        }
        if (want as u64) < window {
            break;
        }
        pos += chunk as u64;
    }
    Ok(None)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::MemSource;

    #[test]
    fn finds_patterns_across_chunk_boundaries() {
        let mut data = vec![0u8; (1 << 20) + 100];
        let at = (1 << 20) - 2;
        data[at..at + 4].copy_from_slice(&[1, 2, 3, 4]);
        let src = MemSource::new(data);
        assert_eq!(find_bytes(&src, 0, &[1, 2, 3, 4]).unwrap(), Some(at as u64));
        assert_eq!(find_bytes(&src, at as u64 + 1, &[1, 2, 3, 4]).unwrap(), None);
        assert_eq!(find_bytes(&src, 0, &[9, 9]).unwrap(), None);
        assert_eq!(find_bytes(&src, 0, &[]).unwrap(), None);
    }
}
