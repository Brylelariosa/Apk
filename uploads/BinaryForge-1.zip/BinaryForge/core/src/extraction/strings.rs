//! String extraction: printable ASCII and UTF-16LE runs.
//!
//! The file is scanned in chunks with a small overlap so a string that crosses a chunk
//! boundary is reported exactly once.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use crate::error::{Error, Result};
use crate::parser::{read_exact_at, ByteSource};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StrEnc {
    Ascii,
    Utf16Le,
}

impl StrEnc {
    pub fn name(self) -> &'static str {
        match self {
            StrEnc::Ascii => "ascii",
            StrEnc::Utf16Le => "utf16le",
        }
    }
}

#[derive(Clone, Debug)]
pub struct StringEntry {
    pub offset: u64,
    pub enc: StrEnc,
    pub text: String,
}

impl StringEntry {
    /// Size of the string in the file.
    pub fn byte_len(&self) -> u64 {
        match self.enc {
            StrEnc::Ascii => self.text.len() as u64,
            StrEnc::Utf16Le => self.text.len() as u64 * 2,
        }
    }
}

pub struct StringScan {
    /// Sorted by file offset.
    pub entries: Vec<StringEntry>,
    pub total_found: u64,
    pub truncated: bool,
}

impl StringScan {
    pub fn empty() -> StringScan {
        StringScan {
            entries: Vec::new(),
            total_found: 0,
            truncated: false,
        }
    }

    /// The string that covers file offset `offset`, if any.
    pub fn containing(&self, offset: u64) -> Option<&StringEntry> {
        let idx = self.entries.partition_point(|e| e.offset <= offset);
        if idx == 0 {
            return None;
        }
        let e = &self.entries[idx - 1];
        if offset < e.offset + e.byte_len() {
            Some(e)
        } else {
            None
        }
    }
}

const CHUNK: usize = 1 << 20;
const OVERLAP: usize = 8192;
const MAX_ASCII: usize = 4096;
const MAX_UTF16: usize = 2048;

fn is_print(b: u8) -> bool {
    (0x20..=0x7e).contains(&b) || b == 0x09
}

struct Sink<'a> {
    entries: &'a mut Vec<StringEntry>,
    total: &'a mut u64,
    max_entries: usize,
}

impl<'a> Sink<'a> {
    fn push(&mut self, offset: u64, enc: StrEnc, text: String) {
        *self.total += 1;
        if self.entries.len() < self.max_entries {
            self.entries.push(StringEntry { offset, enc, text });
        }
    }
}

fn scan_chunk(data: &[u8], base: u64, first: usize, own_end: usize, min_len: usize, sink: &mut Sink) {
    // ASCII runs
    let mut i = first;
    while i < own_end {
        if is_print(data[i]) && (i == 0 || !is_print(data[i - 1])) {
            let mut j = i;
            while j < data.len() && is_print(data[j]) && (j - i) < MAX_ASCII {
                j += 1;
            }
            if j - i >= min_len {
                let text = String::from_utf8_lossy(&data[i..j]).into_owned();
                sink.push(base + i as u64, StrEnc::Ascii, text);
            }
            i = j;
        } else {
            i += 1;
        }
    }

    // UTF-16LE runs (printable ASCII code units)
    let mut i = first;
    while i + 1 < data.len() && i < own_end {
        if is_print(data[i]) && data[i + 1] == 0 {
            let continues = i >= 2 && is_print(data[i - 2]) && data[i - 1] == 0;
            if !continues {
                let mut j = i;
                let mut chars = 0usize;
                while j + 1 < data.len() && is_print(data[j]) && data[j + 1] == 0 && chars < MAX_UTF16 {
                    j += 2;
                    chars += 1;
                }
                if chars >= min_len {
                    let text: String = data[i..j].iter().step_by(2).map(|&b| b as char).collect();
                    sink.push(base + i as u64, StrEnc::Utf16Le, text);
                }
                i = j;
                continue;
            }
        }
        i += 1;
    }
}

/// Scans the whole file. `progress` is advanced by the number of bytes scanned.
pub fn scan(
    src: &dyn ByteSource,
    min_len: usize,
    max_entries: usize,
    cancel: &AtomicBool,
    progress: &AtomicU64,
) -> Result<StringScan> {
    let size = src.len();
    let min_len = min_len.max(2);
    let mut entries: Vec<StringEntry> = Vec::new();
    let mut total: u64 = 0;
    let mut buf: Vec<u8> = vec![0u8; CHUNK + OVERLAP + 2];
    let mut pos: u64 = 0;
    while pos < size {
        if cancel.load(Ordering::Relaxed) {
            return Err(Error::Cancelled);
        }
        let ctx: u64 = pos.min(2);
        let begin = pos - ctx;
        let want = ((CHUNK + OVERLAP) as u64 + ctx).min(size - begin) as usize;
        read_exact_at(src, begin, &mut buf[..want])?;
        let data = &buf[..want];
        let first = ctx as usize;
        let own_end = (first + CHUNK).min(data.len());
        {
            let mut sink = Sink {
                entries: &mut entries,
                total: &mut total,
                max_entries,
            };
            scan_chunk(data, begin, first, own_end, min_len, &mut sink);
        }
        progress.fetch_add((own_end - first) as u64, Ordering::Relaxed);
        pos += CHUNK as u64;
    }
    entries.sort_by_key(|e| e.offset);
    let truncated = total > entries.len() as u64;
    Ok(StringScan {
        entries,
        total_found: total,
        truncated,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::MemSource;

    #[test]
    fn finds_ascii_and_utf16_strings() {
        let mut data: Vec<u8> = vec![0; 4];
        data.extend_from_slice(b"hello");
        data.extend_from_slice(&[0, 0, 0]);
        for c in "wide".bytes() {
            data.push(c);
            data.push(0);
        }
        data.extend_from_slice(&[0, 0, 0, 0]);
        let src = MemSource::new(data);
        let cancel = AtomicBool::new(false);
        let progress = AtomicU64::new(0);
        let scan = scan(&src, 4, 100, &cancel, &progress).unwrap();
        assert_eq!(scan.entries.len(), 2);
        assert_eq!(scan.entries[0].text, "hello");
        assert_eq!(scan.entries[0].offset, 4);
        assert_eq!(scan.entries[0].enc, StrEnc::Ascii);
        assert_eq!(scan.entries[1].text, "wide");
        assert_eq!(scan.entries[1].offset, 12);
        assert_eq!(scan.entries[1].enc, StrEnc::Utf16Le);
        assert!(!scan.truncated);
        assert_eq!(scan.containing(6).map(|e| e.offset), Some(4));
        assert!(scan.containing(10).is_none());
    }

    #[test]
    fn reports_a_string_crossing_a_chunk_boundary_once() {
        let mut data = vec![0u8; CHUNK + 64];
        let at = CHUNK - 3;
        data[at..at + 8].copy_from_slice(b"boundary");
        let src = MemSource::new(data);
        let cancel = AtomicBool::new(false);
        let progress = AtomicU64::new(0);
        let scan = scan(&src, 4, 100, &cancel, &progress).unwrap();
        assert_eq!(scan.entries.len(), 1);
        assert_eq!(scan.entries[0].text, "boundary");
        assert_eq!(scan.entries[0].offset, at as u64);
    }

    #[test]
    fn honours_the_entry_limit() {
        let mut data: Vec<u8> = Vec::new();
        for _ in 0..10 {
            data.extend_from_slice(b"abcdef\0");
        }
        let src = MemSource::new(data);
        let cancel = AtomicBool::new(false);
        let progress = AtomicU64::new(0);
        let scan = scan(&src, 4, 3, &cancel, &progress).unwrap();
        assert_eq!(scan.entries.len(), 3);
        assert_eq!(scan.total_found, 10);
        assert!(scan.truncated);
    }
}
