use crate::architecture::Arch;
use crate::formats::{FormatKind, ImageOptions};
use crate::types::Endian;
use crate::util::hex::parse_addr;

/// Everything the user can configure for one analysis.
#[derive(Clone, Debug)]
pub struct AnalysisOptions {
    pub image: ImageOptions,
    pub min_string_len: usize,
    /// Worker threads the deep analysis may use.
    pub threads: usize,
    /// Soft memory budget for analysis tables.
    pub max_memory_mb: u64,
}

impl Default for AnalysisOptions {
    fn default() -> AnalysisOptions {
        AnalysisOptions {
            image: ImageOptions::default(),
            min_string_len: 4,
            threads: 2,
            max_memory_mb: 256,
        }
    }
}

impl AnalysisOptions {
    /// Parses `key=value` lines. Unknown keys are ignored.
    ///
    /// Keys: format, arch, endian, base, entry, min_string_len, threads, max_memory_mb.
    pub fn parse(text: &str) -> AnalysisOptions {
        let mut o = AnalysisOptions::default();
        for line in text.lines() {
            let mut parts = line.splitn(2, '=');
            let key = parts.next().unwrap_or("").trim();
            let value = parts.next().unwrap_or("").trim();
            match key {
                "format" => {
                    o.image.force_format = FormatKind::from_key(value);
                }
                "arch" => {
                    o.image.arch = Arch::from_name(value);
                }
                "endian" => {
                    o.image.endian = match value {
                        "big" => Some(Endian::Big),
                        "little" => Some(Endian::Little),
                        _ => None,
                    };
                }
                "base" => {
                    if let Some(v) = parse_addr(value) {
                        o.image.base_address = v;
                    }
                }
                "entry" => {
                    o.image.entry_offset = parse_addr(value);
                }
                "min_string_len" => {
                    if let Ok(v) = value.parse::<usize>() {
                        o.min_string_len = v.clamp(2, 64);
                    }
                }
                "threads" => {
                    if let Ok(v) = value.parse::<usize>() {
                        o.threads = v.clamp(1, 8);
                    }
                }
                "max_memory_mb" => {
                    if let Ok(v) = value.parse::<u64>() {
                        o.max_memory_mb = v.clamp(64, 4096);
                    }
                }
                _ => {}
            }
        }
        o
    }

    /// Maximum number of cross-references kept in memory.
    pub fn max_xrefs(&self) -> usize {
        ((self.max_memory_mb * 1024 * 1024) / 8 / 24) as usize
    }

    /// Maximum number of strings kept in memory.
    pub fn max_strings(&self) -> usize {
        ((self.max_memory_mb * 1024 * 1024) / 8 / 64) as usize
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_known_keys_and_clamps() {
        let o = AnalysisOptions::parse(
            "format=raw\narch=arm64\nendian=little\nbase=0x1000\nentry=0x20\nmin_string_len=1\nthreads=99\nmax_memory_mb=1\nunknown=1",
        );
        assert_eq!(o.image.force_format, Some(FormatKind::Raw));
        assert_eq!(o.image.arch, Some(Arch::Aarch64));
        assert_eq!(o.image.base_address, 0x1000);
        assert_eq!(o.image.entry_offset, Some(0x20));
        assert_eq!(o.min_string_len, 2);
        assert_eq!(o.threads, 8);
        assert_eq!(o.max_memory_mb, 64);
    }

    #[test]
    fn auto_format_means_detect() {
        let o = AnalysisOptions::parse("format=auto");
        assert_eq!(o.image.force_format, None);
    }
}
