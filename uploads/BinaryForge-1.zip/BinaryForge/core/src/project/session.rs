//! A thread-safe analysis session.
//!
//! Lifecycle: `open` (cheap) -> `analyze` (headers, sections, symbols; fast) ->
//! `deep_analyze` (linear sweep, functions, cross-references, strings; cancellable, reports
//! progress). All query methods take `&self`, so the UI can read the hex view while the deep
//! analysis is still running.

use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicU8, Ordering};
use std::sync::{Arc, Mutex, RwLock};
use std::time::Instant;

use super::names::NameTable;
use super::options::AnalysisOptions;
use super::report;
use crate::disassembler::{self, Decoded, Disassembler, Flow};
use crate::error::{Error, Result};
use crate::extraction::find_bytes;
use crate::extraction::strings::{self, StringScan};
use crate::formats::{load_image, BinaryImage, Import, SymKind, Symbol};
use crate::functions::{self, function_at, Function};
use crate::memory::AddressMap;
use crate::parser::{read_clamped, read_exact_at, read_vec, ByteSource, FileSource};
use crate::references::{Xref, XrefKind, XrefTable};
use crate::util::hex::{hex_bytes, parse_addr, parse_hex_bytes};
use crate::util::json::{error_json, JsonWriter};

const STATE_IDLE: u8 = 0;
const STATE_RUNNING: u8 = 1;
const STATE_DONE: u8 = 2;
const STATE_CANCELLED: u8 = 3;
const STATE_FAILED: u8 = 4;

fn state_name(state: u8) -> &'static str {
    match state {
        STATE_RUNNING => "running",
        STATE_DONE => "done",
        STATE_CANCELLED => "cancelled",
        STATE_FAILED => "error",
        _ => "idle",
    }
}

/// Shared progress and cancellation state.
struct Control {
    cancel: AtomicBool,
    state: AtomicU8,
    done: AtomicU64,
    total: AtomicU64,
    phase: Mutex<String>,
    message: Mutex<String>,
}

impl Control {
    fn new() -> Control {
        Control {
            cancel: AtomicBool::new(false),
            state: AtomicU8::new(STATE_IDLE),
            done: AtomicU64::new(0),
            total: AtomicU64::new(0),
            phase: Mutex::new(String::new()),
            message: Mutex::new(String::new()),
        }
    }

    fn begin(&self, total: u64, phase: &str) {
        self.cancel.store(false, Ordering::Relaxed);
        self.done.store(0, Ordering::Relaxed);
        self.total.store(total.max(1), Ordering::Relaxed);
        self.state.store(STATE_RUNNING, Ordering::Relaxed);
        self.set_phase(phase);
        self.set_message("");
    }

    fn finish(&self, state: u8, message: &str) {
        self.state.store(state, Ordering::Relaxed);
        self.set_message(message);
        if state == STATE_DONE {
            self.set_phase("Finished");
            let total = self.total.load(Ordering::Relaxed);
            self.done.store(total, Ordering::Relaxed);
        }
    }

    fn cancelled(&self) -> bool {
        self.cancel.load(Ordering::Relaxed)
    }

    fn set_phase(&self, text: &str) {
        if let Ok(mut p) = self.phase.lock() {
            *p = text.to_string();
        }
    }

    fn phase(&self) -> String {
        self.phase.lock().map(|p| p.clone()).unwrap_or_default()
    }

    fn set_message(&self, text: &str) {
        if let Ok(mut m) = self.message.lock() {
            *m = text.to_string();
        }
    }

    fn message(&self) -> String {
        self.message.lock().map(|m| m.clone()).unwrap_or_default()
    }
}

struct Loaded {
    image: BinaryImage,
    map: AddressMap,
    dis: Option<Box<dyn Disassembler>>,
    names: NameTable,
}

struct DeepStats {
    instructions: u64,
    code_bytes: u64,
    elapsed_ms: u64,
    notes: Vec<String>,
}

struct DeepAnalysis {
    functions: Vec<Function>,
    xrefs: XrefTable,
    strings: StringScan,
    names: NameTable,
    stats: DeepStats,
}

struct SweepOutput {
    xrefs: Vec<Xref>,
    call_targets: Vec<u64>,
    instructions: u64,
    dropped: u64,
}

fn push_xref(list: &mut Vec<Xref>, dropped: &mut u64, cap: usize, from: u64, to: u64, kind: XrefKind) {
    if list.len() < cap {
        list.push(Xref { from, to, kind });
    } else {
        *dropped += 1;
    }
}

fn run_sweep(
    src: &dyn ByteSource,
    loaded: &Loaded,
    dis: Option<&dyn Disassembler>,
    ctl: &Control,
    max_xrefs: usize,
) -> Result<SweepOutput> {
    const CHUNK: usize = 64 * 1024;
    let dis = match dis {
        Some(d) => d,
        None => {
            let code_bytes: u64 = loaded.image.code_regions.iter().map(|r| r.size).sum();
            ctl.done.fetch_add(code_bytes, Ordering::Relaxed);
            return Ok(SweepOutput {
                xrefs: Vec::new(),
                call_targets: Vec::new(),
                instructions: 0,
                dropped: 0,
            });
        }
    };
    let map = &loaded.map;
    let mut xrefs: Vec<Xref> = Vec::new();
    let mut targets: HashSet<u64> = HashSet::new();
    let mut instructions: u64 = 0;
    let mut dropped: u64 = 0;
    let mut buf: Vec<u8> = vec![0u8; CHUNK];

    for region in &loaded.image.code_regions {
        let mut pos: u64 = 0;
        while pos < region.size {
            if ctl.cancelled() {
                return Err(Error::Cancelled);
            }
            let remaining = region.size - pos;
            let want = remaining.min(CHUNK as u64) as usize;
            let last = want as u64 == remaining;
            read_exact_at(src, region.file_offset + pos, &mut buf[..want])?;
            let consumed = dis.sweep(
                &buf[..want],
                region.va.wrapping_add(pos),
                last,
                &mut |d: &Decoded| {
                    instructions += 1;
                    if let Some(t) = d.target {
                        if map.contains(t) {
                            let kind = match d.flow {
                                Flow::Call => Some(XrefKind::Call),
                                Flow::Jump => Some(XrefKind::Jump),
                                Flow::CondJump => Some(XrefKind::CondJump),
                                _ => None,
                            };
                            if let Some(k) = kind {
                                if k == XrefKind::Call {
                                    targets.insert(t);
                                }
                                push_xref(&mut xrefs, &mut dropped, max_xrefs, d.addr, t, k);
                            }
                        }
                    }
                    if let Some(m) = d.mem {
                        if map.contains(m) {
                            push_xref(&mut xrefs, &mut dropped, max_xrefs, d.addr, m, XrefKind::Data);
                        }
                    }
                },
            );
            let step = if consumed == 0 { want } else { consumed };
            pos += step as u64;
            ctl.done.fetch_add(step as u64, Ordering::Relaxed);
        }
    }

    Ok(SweepOutput {
        xrefs,
        call_targets: targets.into_iter().collect(),
        instructions,
        dropped,
    })
}

fn symbol_matches(s: &Symbol, kind: &str, needle: &str) -> bool {
    let kind_ok = match kind {
        "func" => s.kind == SymKind::Func && !s.is_import,
        "object" => s.kind == SymKind::Object && !s.is_import,
        "import" => s.is_import,
        "export" => s.is_export,
        _ => true,
    };
    if !kind_ok {
        return false;
    }
    if needle.is_empty() {
        return true;
    }
    s.name.to_ascii_lowercase().contains(needle)
        || format!("{:x}", s.va).contains(needle.trim_start_matches("0x"))
}

fn not_ready_json() -> String {
    let mut j = JsonWriter::new();
    j.begin_object();
    j.kv_bool("ready", false);
    j.kv_u64("total", 0);
    j.key("items");
    j.begin_array();
    j.end_array();
    j.end_object();
    j.finish()
}

fn mem_comment(loaded: &Loaded, names: &NameTable, strings: Option<&StringScan>, m: u64) -> Option<String> {
    if let Some(l) = names.label(m) {
        return Some(l);
    }
    if let (Some(s), Some(off)) = (strings, loaded.map.va_to_offset(m)) {
        if let Some(e) = s.containing(off) {
            let t: String = e.text.chars().take(60).collect();
            return Some(format!("\"{}\"", t));
        }
    }
    None
}

pub struct Session {
    path: PathBuf,
    source: FileSource,
    options: AnalysisOptions,
    ctl: Control,
    loaded: RwLock<Option<Arc<Loaded>>>,
    deep: RwLock<Option<Arc<DeepAnalysis>>>,
}

impl Session {
    /// Opens the file read-only. `options_text` holds `key=value` lines.
    pub fn open(path: &str, options_text: &str) -> Result<Session> {
        let p = PathBuf::from(path);
        let source = FileSource::open(&p)?;
        Ok(Session {
            path: p,
            source,
            options: AnalysisOptions::parse(options_text),
            ctl: Control::new(),
            loaded: RwLock::new(None),
            deep: RwLock::new(None),
        })
    }

    fn loaded(&self) -> Option<Arc<Loaded>> {
        self.loaded.read().ok().and_then(|g| g.clone())
    }

    fn deep(&self) -> Option<Arc<DeepAnalysis>> {
        self.deep.read().ok().and_then(|g| g.clone())
    }

    fn load(&self) -> Result<Arc<Loaded>> {
        if let Some(l) = self.loaded() {
            return Ok(l);
        }
        let mut image = load_image(&self.source, &self.options.image)?;
        image.symbols.sort_by_key(|s| s.va);
        let dis = disassembler::create(image.arch.arch, image.arch.endian);
        let map = image.address_map();
        let names = NameTable::build(&image, &[]);
        let loaded = Arc::new(Loaded {
            image,
            map,
            dis,
            names,
        });
        let mut guard = self.loaded.write().unwrap_or_else(|e| e.into_inner());
        *guard = Some(loaded.clone());
        Ok(loaded)
    }

    // ---- lifecycle ---------------------------------------------------------------------

    /// Parses the file structure and returns the summary document.
    pub fn analyze_json(&self) -> String {
        match self.load() {
            Ok(l) => report::summary_json(
                &self.path,
                self.source.len(),
                &l.image,
                l.dis.as_ref().map(|d| d.backend()),
            ),
            Err(e) => error_json(&e.to_string()),
        }
    }

    pub fn cancel(&self) {
        self.ctl.cancel.store(true, Ordering::Relaxed);
    }

    /// Runs the deep analysis to completion (or cancellation) and returns the status document.
    pub fn deep_analyze_json(&self) -> String {
        match self.deep_analyze() {
            Ok(()) => self.ctl.finish(STATE_DONE, ""),
            Err(Error::Cancelled) => self.ctl.finish(STATE_CANCELLED, "cancelled"),
            Err(e) => self.ctl.finish(STATE_FAILED, &e.to_string()),
        }
        self.status_json()
    }

    fn deep_analyze(&self) -> Result<()> {
        if self.deep().is_some() {
            return Ok(());
        }
        let loaded = self.load()?;
        let image = &loaded.image;
        let started = Instant::now();
        let code_bytes: u64 = image.code_regions.iter().map(|r| r.size).sum();
        self.ctl
            .begin(code_bytes + self.source.len(), "Scanning code and strings");
        let src: &dyn ByteSource = &self.source;
        let ctl = &self.ctl;
        let opts = &self.options;
        let dis: Option<&dyn Disassembler> = loaded.dis.as_deref();

        let (sweep_res, strings_res) = if opts.threads >= 2 {
            std::thread::scope(|s| {
                let handle = s.spawn(|| {
                    strings::scan(src, opts.min_string_len, opts.max_strings(), &ctl.cancel, &ctl.done)
                });
                let sweep_res = run_sweep(src, &loaded, dis, ctl, opts.max_xrefs());
                let strings_res = match handle.join() {
                    Ok(r) => r,
                    Err(_) => Err(Error::Other("the string scanner thread panicked".to_string())),
                };
                (sweep_res, strings_res)
            })
        } else {
            let sweep_res = run_sweep(src, &loaded, dis, ctl, opts.max_xrefs());
            let strings_res =
                strings::scan(src, opts.min_string_len, opts.max_strings(), &ctl.cancel, &ctl.done);
            (sweep_res, strings_res)
        };

        let sweep = sweep_res?;
        let strings = strings_res?;
        if ctl.cancelled() {
            return Err(Error::Cancelled);
        }

        ctl.set_phase("Building functions");
        let functions = functions::discover(image, &sweep.call_targets);

        let mut kept: Vec<Xref> = Vec::with_capacity(sweep.xrefs.len());
        for x in sweep.xrefs {
            if x.kind == XrefKind::Jump || x.kind == XrefKind::CondJump {
                let from = function_at(&functions, x.from).map(|f| f.start);
                let to = function_at(&functions, x.to).map(|f| f.start);
                if from.is_some() && from == to {
                    continue;
                }
            }
            kept.push(x);
        }
        let xrefs = XrefTable::new(kept);
        let names = NameTable::build(image, &functions);

        let mut notes: Vec<String> = Vec::new();
        if dis.is_none() {
            notes.push(format!(
                "No disassembler backend is available for {}; functions come from symbols and file metadata only.",
                image.arch.arch.name()
            ));
        }
        if sweep.dropped > 0 {
            notes.push(format!(
                "{} cross-references were not stored because the memory limit was reached.",
                sweep.dropped
            ));
        }
        if strings.truncated {
            notes.push(format!(
                "Only {} of {} strings were kept because of the memory limit.",
                strings.entries.len(),
                strings.total_found
            ));
        }
        if image.code_regions.iter().any(|r| r.confidence != crate::types::Confidence::Verified) {
            notes.push(
                "Some code regions are assumed or estimated, so the sweep may have decoded data as code."
                    .to_string(),
            );
        }

        let deep = Arc::new(DeepAnalysis {
            functions,
            xrefs,
            strings,
            names,
            stats: DeepStats {
                instructions: sweep.instructions,
                code_bytes,
                elapsed_ms: started.elapsed().as_millis() as u64,
                notes,
            },
        });
        let mut guard = self.deep.write().unwrap_or_else(|e| e.into_inner());
        *guard = Some(deep);
        Ok(())
    }

    pub fn status_json(&self) -> String {
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_str("state", state_name(self.ctl.state.load(Ordering::Relaxed)));
        j.kv_str("phase", &self.ctl.phase());
        let total = self.ctl.total.load(Ordering::Relaxed);
        let done = self.ctl.done.load(Ordering::Relaxed);
        let fraction = if total == 0 {
            0.0
        } else {
            (done as f64 / total as f64).min(1.0)
        };
        j.kv_f64("fraction", fraction);
        j.kv_str("message", &self.ctl.message());
        j.kv_bool("analyzed", self.loaded().is_some());
        match self.deep() {
            Some(d) => {
                j.kv_bool("deep_ready", true);
                j.kv_u64("functions", d.functions.len() as u64);
                j.kv_u64("xrefs", d.xrefs.len() as u64);
                j.kv_u64("strings", d.strings.entries.len() as u64);
                j.kv_u64("strings_total", d.strings.total_found);
                j.kv_u64("instructions", d.stats.instructions);
                j.kv_u64("code_bytes", d.stats.code_bytes);
                j.kv_u64("elapsed_ms", d.stats.elapsed_ms);
                j.key("notes");
                j.begin_array();
                for n in &d.stats.notes {
                    j.string(n);
                }
                j.end_array();
            }
            None => {
                j.kv_bool("deep_ready", false);
            }
        }
        j.end_object();
        j.finish()
    }

    // ---- raw access --------------------------------------------------------------------

    /// Reads up to `len` bytes (at most 1 MiB) at `offset`; shorter at end of file.
    pub fn read(&self, offset: u64, len: usize) -> Vec<u8> {
        let len = len.min(1 << 20) as u64;
        read_clamped(&self.source, offset, len).unwrap_or_default()
    }

    /// First offset >= `from` where the hex-encoded pattern occurs: >= 0 found,
    /// -1 not found, -2 invalid pattern or read error.
    pub fn find(&self, from: u64, pattern_hex: &str) -> i64 {
        let pattern = match parse_hex_bytes(pattern_hex) {
            Some(p) => p,
            None => return -2,
        };
        match find_bytes(&self.source, from, &pattern) {
            Ok(Some(o)) => o as i64,
            Ok(None) => -1,
            Err(_) => -2,
        }
    }

    // ---- paged lists -------------------------------------------------------------------

    /// `what`: symbols (arg = all|func|object|import|export), imports, functions, strings,
    /// xrefs (arg = destination address).
    pub fn query_json(&self, what: &str, arg: &str, offset: usize, limit: usize, filter: &str) -> String {
        let limit = limit.clamp(1, 1000);
        let needle = filter.trim().to_ascii_lowercase();
        match what {
            "symbols" => self.query_symbols(arg, offset, limit, &needle),
            "imports" => self.query_imports(offset, limit, &needle),
            "functions" => self.query_functions(offset, limit, &needle),
            "strings" => self.query_strings(offset, limit, &needle),
            "xrefs" => self.query_xrefs(arg, offset, limit),
            _ => error_json("unknown query"),
        }
    }

    fn query_symbols(&self, kind: &str, offset: usize, limit: usize, needle: &str) -> String {
        let loaded = match self.loaded() {
            Some(l) => l,
            None => return error_json("The analysis has not run yet."),
        };
        let matches: Vec<&Symbol> = loaded
            .image
            .symbols
            .iter()
            .filter(|s| symbol_matches(s, kind, needle))
            .collect();
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_bool("ready", true);
        j.kv_u64("total", matches.len() as u64);
        j.key("items");
        j.begin_array();
        for s in matches.iter().skip(offset).take(limit) {
            j.begin_object();
            j.kv_str("name", &s.name);
            j.kv_hex("va", s.va);
            j.kv_u64("size", s.size);
            j.kv_str("kind", s.kind.name());
            j.kv_bool("global", s.global);
            j.kv_bool("import", s.is_import);
            j.kv_bool("export", s.is_export);
            j.kv_str("source", s.source);
            j.end_object();
        }
        j.end_array();
        j.end_object();
        j.finish()
    }

    fn query_imports(&self, offset: usize, limit: usize, needle: &str) -> String {
        let loaded = match self.loaded() {
            Some(l) => l,
            None => return error_json("The analysis has not run yet."),
        };
        let matches: Vec<&Import> = loaded
            .image
            .imports
            .iter()
            .filter(|i| {
                needle.is_empty()
                    || i.name.to_ascii_lowercase().contains(needle)
                    || i.library.to_ascii_lowercase().contains(needle)
            })
            .collect();
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_bool("ready", true);
        j.kv_u64("total", matches.len() as u64);
        j.key("items");
        j.begin_array();
        for i in matches.iter().skip(offset).take(limit) {
            j.begin_object();
            j.kv_str("library", &i.library);
            j.kv_str("name", &i.name);
            if i.slot_va != 0 {
                j.kv_hex("slot", i.slot_va);
            } else {
                j.kv_str("slot", "");
            }
            match i.ordinal {
                Some(o) => {
                    j.kv_u64("ordinal", o as u64);
                }
                None => {
                    j.key("ordinal");
                    j.null();
                }
            }
            j.end_object();
        }
        j.end_array();
        j.end_object();
        j.finish()
    }

    fn query_functions(&self, offset: usize, limit: usize, needle: &str) -> String {
        let deep = match self.deep() {
            Some(d) => d,
            None => return not_ready_json(),
        };
        let addr_needle = needle.trim_start_matches("0x");
        let matches: Vec<&Function> = deep
            .functions
            .iter()
            .filter(|f| {
                needle.is_empty()
                    || f.name.to_ascii_lowercase().contains(needle)
                    || format!("{:x}", f.start).contains(addr_needle)
            })
            .collect();
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_bool("ready", true);
        j.kv_u64("total", matches.len() as u64);
        j.key("items");
        j.begin_array();
        for f in matches.iter().skip(offset).take(limit) {
            j.begin_object();
            j.kv_u64("id", f.id as u64);
            j.kv_str("name", &f.name);
            j.kv_hex("start", f.start);
            j.kv_hex("end", f.end);
            j.kv_u64("size", f.size());
            j.kv_str("confidence", f.confidence.name());
            j.kv_str("bounds", f.bounds);
            j.kv_str("bounds_confidence", f.bounds_confidence().name());
            j.kv_str("source", f.source);
            j.kv_u64("refs_in", deep.xrefs.to(f.start).len() as u64);
            if let Some(p) = f.parent {
                j.kv_hex("parent", p);
            }
            j.end_object();
        }
        j.end_array();
        j.end_object();
        j.finish()
    }

    fn query_strings(&self, offset: usize, limit: usize, needle: &str) -> String {
        let loaded = match self.loaded() {
            Some(l) => l,
            None => return error_json("The analysis has not run yet."),
        };
        let deep = match self.deep() {
            Some(d) => d,
            None => return not_ready_json(),
        };
        let matches: Vec<&crate::extraction::strings::StringEntry> = deep
            .strings
            .entries
            .iter()
            .filter(|e| needle.is_empty() || e.text.to_ascii_lowercase().contains(needle))
            .collect();
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_bool("ready", true);
        j.kv_u64("total", matches.len() as u64);
        j.key("items");
        j.begin_array();
        for e in matches.iter().skip(offset).take(limit) {
            j.begin_object();
            j.kv_hex("offset", e.offset);
            match loaded.map.offset_to_va(e.offset) {
                Some(va) => {
                    j.kv_hex("va", va);
                }
                None => {
                    j.kv_str("va", "");
                }
            }
            j.kv_str("enc", e.enc.name());
            let text: String = e.text.chars().take(400).collect();
            j.kv_str("text", &text);
            j.end_object();
        }
        j.end_array();
        j.end_object();
        j.finish()
    }

    fn query_xrefs(&self, arg: &str, offset: usize, limit: usize) -> String {
        let addr = match parse_addr(arg) {
            Some(a) => a,
            None => return error_json("Invalid address."),
        };
        let deep = match self.deep() {
            Some(d) => d,
            None => return not_ready_json(),
        };
        let hits = deep.xrefs.to(addr);
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_bool("ready", true);
        j.kv_u64("total", hits.len() as u64);
        j.key("items");
        j.begin_array();
        for x in hits.iter().skip(offset).take(limit) {
            j.begin_object();
            j.kv_hex("from", x.from);
            j.kv_str("kind", x.kind.name());
            match function_at(&deep.functions, x.from) {
                Some(f) => {
                    j.kv_str("func", &f.name);
                }
                None => {
                    j.kv_str("func", "");
                }
            }
            j.end_object();
        }
        j.end_array();
        j.end_object();
        j.finish()
    }

    // ---- code views --------------------------------------------------------------------

    /// Disassembles `count` instructions starting at `addr`.
    pub fn disassemble_json(&self, addr: u64, count: usize) -> String {
        let loaded = match self.loaded() {
            Some(l) => l,
            None => return error_json("The analysis has not run yet."),
        };
        let dis = match &loaded.dis {
            Some(d) => d,
            None => {
                return error_json(&format!(
                    "No disassembler is available for {}.",
                    loaded.image.arch.arch.name()
                ))
            }
        };
        let off = match loaded.map.va_to_offset(addr) {
            Some(o) => o,
            None => return error_json("That address is not backed by file data."),
        };
        let count = count.clamp(1, 2000);
        let avail = loaded.map.file_bytes_from(addr);
        let want = ((count * dis.arch().max_insn_len()) as u64).min(avail).min(64 * 1024);
        let code = match read_vec(&self.source, off, want) {
            Ok(c) => c,
            Err(e) => return error_json(&e.to_string()),
        };
        let insns = dis.disassemble(&code, addr, count);

        let deep = self.deep();
        let names: &NameTable = match &deep {
            Some(d) => &d.names,
            None => &loaded.names,
        };
        let functions: &[Function] = match &deep {
            Some(d) => &d.functions,
            None => &[],
        };
        let strings: Option<&StringScan> = match &deep {
            Some(d) => Some(&d.strings),
            None => None,
        };

        let mut j = JsonWriter::new();
        j.begin_object();
        j.key("insns");
        j.begin_array();
        for i in &insns {
            j.begin_object();
            j.kv_hex("addr", i.addr);
            if let Some(o) = loaded.map.va_to_offset(i.addr) {
                j.kv_hex("off", o);
            }
            j.kv_str("bytes", &hex_bytes(&i.bytes));
            j.kv_str("mnem", &i.mnemonic);
            j.kv_str("ops", &i.operands);
            j.kv_str("flow", i.flow.name());
            j.kv_bool("valid", i.valid);
            if let Some(t) = i.target {
                j.kv_hex("target", t);
                if let Some(l) = names.label(t) {
                    j.kv_str("target_label", &l);
                }
            }
            if let Some(m) = i.mem {
                j.kv_hex("mem", m);
                if let Some(c) = mem_comment(&loaded, names, strings, m) {
                    j.kv_str("comment", &c);
                }
            }
            if let Some(f) = function_at(functions, i.addr) {
                if f.start == i.addr {
                    j.kv_str("func", &f.name);
                }
            }
            j.end_object();
        }
        j.end_array();
        match insns.last() {
            Some(last) => {
                j.kv_hex("next", last.addr.wrapping_add(last.bytes.len() as u64));
            }
            None => {
                j.kv_hex("next", addr);
            }
        }
        j.kv_bool("end", insns.len() < count);
        j.end_object();
        j.finish()
    }

    /// Statistics and references for the function that contains `addr`.
    pub fn function_detail_json(&self, addr: u64) -> String {
        let loaded = match self.loaded() {
            Some(l) => l,
            None => return error_json("The analysis has not run yet."),
        };
        let deep = match self.deep() {
            Some(d) => d,
            None => return error_json("The deep analysis has not finished yet."),
        };
        let dis = match &loaded.dis {
            Some(d) => d,
            None => return error_json("No disassembler is available for this architecture."),
        };
        let f = match function_at(&deep.functions, addr) {
            Some(f) => f,
            None => return error_json("No function contains that address."),
        };
        let off = match loaded.map.va_to_offset(f.start) {
            Some(o) => o,
            None => return error_json("The function is not backed by file data."),
        };
        let size = f.size().min(loaded.map.file_bytes_from(f.start));
        let capped = size.min(1 << 20);
        let code = match read_vec(&self.source, off, capped) {
            Ok(c) => c,
            Err(e) => return error_json(&e.to_string()),
        };
        let insns = dis.disassemble(&code, f.start, code.len().min(200_000));

        let mut flows: BTreeMap<&'static str, u64> = BTreeMap::new();
        let mut calls: BTreeMap<u64, u64> = BTreeMap::new();
        let mut regs: BTreeSet<String> = BTreeSet::new();
        let mut data_refs: BTreeSet<u64> = BTreeSet::new();
        let mut invalid: u64 = 0;
        for i in &insns {
            *flows.entry(i.flow.name()).or_insert(0) += 1;
            if !i.valid {
                invalid += 1;
            }
            for r in &i.regs {
                regs.insert(r.clone());
            }
            if i.flow == Flow::Call {
                if let Some(t) = i.target {
                    *calls.entry(t).or_insert(0) += 1;
                }
            }
            if let Some(m) = i.mem {
                data_refs.insert(m);
            }
        }

        let names = &deep.names;
        let strings = Some(&deep.strings);
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_u64("id", f.id as u64);
        j.kv_str("name", &f.name);
        j.kv_hex("start", f.start);
        j.kv_hex("end", f.end);
        j.kv_u64("size", f.size());
        j.kv_str("source", f.source);
        j.kv_str("confidence", f.confidence.name());
        j.kv_str("bounds", f.bounds);
        j.kv_str("bounds_confidence", f.bounds_confidence().name());
        if let Some(p) = f.parent {
            j.kv_hex("parent", p);
        }
        j.kv_u64("instructions", insns.len() as u64);
        j.kv_u64("undecoded_units", invalid);
        j.kv_bool("truncated", size > capped);

        j.key("flow_counts");
        j.begin_object();
        for (name, n) in &flows {
            j.kv_u64(name, *n);
        }
        j.end_object();

        j.key("calls");
        j.begin_array();
        for (target, n) in calls.iter().take(200) {
            j.begin_object();
            j.kv_hex("target", *target);
            j.kv_u64("count", *n);
            if let Some(l) = names.label(*target) {
                j.kv_str("name", &l);
            }
            j.end_object();
        }
        j.end_array();

        j.key("registers");
        j.begin_array();
        for r in &regs {
            j.string(r);
        }
        j.end_array();

        j.key("data_refs");
        j.begin_array();
        for m in data_refs.iter().take(100) {
            j.begin_object();
            j.kv_hex("addr", *m);
            if let Some(c) = mem_comment(&loaded, names, strings, *m) {
                j.kv_str("label", &c);
            }
            j.end_object();
        }
        j.end_array();

        let callers = deep.xrefs.to(f.start);
        j.kv_u64("callers_total", callers.len() as u64);
        j.key("callers");
        j.begin_array();
        for x in callers.iter().take(100) {
            j.begin_object();
            j.kv_hex("from", x.from);
            j.kv_str("kind", x.kind.name());
            if let Some(cf) = function_at(&deep.functions, x.from) {
                j.kv_str("func", &cf.name);
            }
            j.end_object();
        }
        j.end_array();

        j.end_object();
        j.finish()
    }
}
