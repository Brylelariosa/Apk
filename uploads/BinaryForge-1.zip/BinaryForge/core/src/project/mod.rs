//! Analysis sessions: ties parsing, disassembly, function discovery and extraction together
//! behind one thread-safe object that the JNI layer drives.

mod names;
mod options;
mod report;
mod session;

pub use options::AnalysisOptions;
pub use session::Session;
