//! Address -> name lookup used to annotate disassembly.

use crate::formats::{BinaryImage, SymKind};
use crate::functions::Function;

pub struct NameEntry {
    pub addr: u64,
    pub size: u64,
    pub name: String,
    pub is_import: bool,
}

pub struct NameTable {
    entries: Vec<NameEntry>,
}

impl NameTable {
    pub fn build(image: &BinaryImage, functions: &[Function]) -> NameTable {
        let ptr = ((image.arch.bits as u64) / 8).max(4);
        let mut entries: Vec<NameEntry> = Vec::new();
        for s in &image.symbols {
            if s.is_import || s.va == 0 || s.kind == SymKind::Tls {
                continue;
            }
            entries.push(NameEntry {
                addr: s.va,
                size: s.size,
                name: s.name.clone(),
                is_import: false,
            });
        }
        for i in &image.imports {
            if i.slot_va == 0 {
                continue;
            }
            let name = if i.library.is_empty() {
                i.name.clone()
            } else {
                format!("{}!{}", i.library, i.name)
            };
            entries.push(NameEntry {
                addr: i.slot_va,
                size: ptr,
                name,
                is_import: true,
            });
        }
        for f in functions {
            if !f.named {
                entries.push(NameEntry {
                    addr: f.start,
                    size: f.size(),
                    name: f.name.clone(),
                    is_import: false,
                });
            }
        }
        entries.sort_by(|a, b| a.addr.cmp(&b.addr));
        NameTable { entries }
    }

    /// The entry that covers `addr` and the offset of `addr` inside it.
    pub fn lookup(&self, addr: u64) -> Option<(&NameEntry, u64)> {
        let idx = self.entries.partition_point(|e| e.addr <= addr);
        if idx == 0 {
            return None;
        }
        let e = &self.entries[idx - 1];
        let delta = addr - e.addr;
        if delta == 0 || (e.size > 0 && delta < e.size) {
            Some((e, delta))
        } else {
            None
        }
    }

    /// "name" or "name+0x10".
    pub fn label(&self, addr: u64) -> Option<String> {
        let (e, delta) = self.lookup(addr)?;
        if delta == 0 {
            Some(e.name.clone())
        } else {
            Some(format!("{}+0x{:x}", e.name, delta))
        }
    }
}
