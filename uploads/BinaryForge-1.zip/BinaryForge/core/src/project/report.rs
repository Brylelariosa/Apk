//! JSON documents describing an analyzed image.

use std::path::Path;

use crate::dependencies;
use crate::formats::BinaryImage;
use crate::util::json::JsonWriter;

pub fn summary_json(path: &Path, size: u64, image: &BinaryImage, backend: Option<&str>) -> String {
    let map = image.address_map();
    let mut j = JsonWriter::new();
    j.begin_object();

    j.key("file");
    j.begin_object();
    j.kv_str("path", &path.to_string_lossy());
    j.kv_u64("size", size);
    j.end_object();

    j.key("format");
    j.begin_object();
    j.kv_str("kind", image.format.key());
    j.kv_str("name", &image.format_name);
    j.kv_str("confidence", image.format_confidence.name());
    j.end_object();

    j.key("arch");
    j.begin_object();
    j.kv_str("name", image.arch.arch.name());
    j.kv_u64("bits", image.arch.bits as u64);
    j.kv_str("endian", image.arch.endian.name());
    j.kv_str("confidence", image.arch.confidence.name());
    j.kv_str("evidence", &image.arch.evidence);
    j.end_object();

    j.kv_hex("image_base", image.image_base);

    j.key("entry_points");
    j.begin_array();
    for e in &image.entry_points {
        j.begin_object();
        j.kv_hex("va", e.va);
        match map.va_to_offset(e.va) {
            Some(o) => {
                j.kv_hex("offset", o);
            }
            None => {
                j.kv_str("offset", "");
            }
        }
        j.kv_str("name", &e.name);
        j.kv_str("kind", &e.kind);
        j.kv_str("confidence", e.confidence.name());
        j.end_object();
    }
    j.end_array();

    j.key("sections");
    j.begin_array();
    for s in &image.sections {
        j.begin_object();
        j.kv_u64("index", s.index as u64);
        j.kv_str("name", &s.name);
        j.kv_str("kind", s.kind.name());
        j.kv_hex("va", s.va);
        j.kv_hex("offset", s.file_offset);
        j.kv_u64("size", s.file_size);
        j.kv_u64("mem_size", s.mem_size);
        j.kv_str("perms", &s.perms.text());
        j.kv_str("type", &s.type_name);
        j.kv_str("confidence", s.confidence.name());
        j.end_object();
    }
    j.end_array();

    j.key("segments");
    j.begin_array();
    for s in &image.segments {
        j.begin_object();
        j.kv_str("kind", &s.kind);
        j.kv_hex("va", s.va);
        j.kv_hex("offset", s.file_offset);
        j.kv_u64("size", s.file_size);
        j.kv_u64("mem_size", s.mem_size);
        j.kv_str("perms", &s.perms.text());
        j.kv_u64("align", s.align);
        j.end_object();
    }
    j.end_array();

    j.key("code_regions");
    j.begin_array();
    for r in &image.code_regions {
        j.begin_object();
        j.kv_str("name", &r.name);
        j.kv_hex("va", r.va);
        j.kv_hex("offset", r.file_offset);
        j.kv_u64("size", r.size);
        j.kv_str("confidence", r.confidence.name());
        j.end_object();
    }
    j.end_array();

    j.key("libraries");
    j.begin_array();
    for d in dependencies::summarize(image) {
        j.begin_object();
        j.kv_str("name", &d.name);
        match d.imported_symbols {
            Some(n) => {
                j.kv_u64("imports", n as u64);
            }
            None => {
                j.key("imports");
                j.null();
            }
        }
        j.end_object();
    }
    j.end_array();

    j.key("info");
    j.begin_array();
    for (k, v) in &image.info {
        j.begin_array();
        j.string(k);
        j.string(v);
        j.end_array();
    }
    j.end_array();

    let exports = image.symbols.iter().filter(|s| s.is_export).count();
    j.key("counts");
    j.begin_object();
    j.kv_u64("symbols", image.symbols.len() as u64);
    j.kv_u64("imports", image.imports.len() as u64);
    j.kv_u64("exports", exports as u64);
    j.kv_u64("sections", image.sections.len() as u64);
    j.kv_u64("segments", image.segments.len() as u64);
    j.kv_u64("unresolved_imports", dependencies::unresolved_import_count(image) as u64);
    j.end_object();

    j.key("warnings");
    j.begin_array();
    for w in &image.warnings {
        j.string(w);
    }
    if backend.is_none() && image.arch.arch != crate::architecture::Arch::Unknown && !image.code_regions.is_empty() {
        j.string(&format!(
            "No disassembler backend is available for {} in this build. Functions come from symbols and file metadata only.",
            image.arch.arch.name()
        ));
    }
    j.end_array();

    j.key("disassembler");
    j.begin_object();
    j.kv_bool("available", backend.is_some());
    j.kv_str("backend", backend.unwrap_or(""));
    j.end_object();

    j.end_object();
    j.finish()
}
