//! CPU architecture identification: exact (from headers) or estimated (from raw code patterns).

use crate::error::Result;
use crate::parser::{read_clamped, ByteSource};
use crate::types::{Confidence, Endian};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Arch {
    X86,
    X86_64,
    Arm,
    Aarch64,
    Mips,
    Mips64,
    PowerPc,
    PowerPc64,
    RiscV32,
    RiscV64,
    Unknown,
}

impl Arch {
    pub fn name(self) -> &'static str {
        match self {
            Arch::X86 => "x86",
            Arch::X86_64 => "x86_64",
            Arch::Arm => "arm",
            Arch::Aarch64 => "aarch64",
            Arch::Mips => "mips",
            Arch::Mips64 => "mips64",
            Arch::PowerPc => "ppc",
            Arch::PowerPc64 => "ppc64",
            Arch::RiscV32 => "riscv32",
            Arch::RiscV64 => "riscv64",
            Arch::Unknown => "unknown",
        }
    }

    pub fn from_name(text: &str) -> Option<Arch> {
        match text.trim().to_ascii_lowercase().as_str() {
            "x86" | "i386" | "i686" => Some(Arch::X86),
            "x86_64" | "x64" | "amd64" => Some(Arch::X86_64),
            "arm" | "arm32" | "armv7" => Some(Arch::Arm),
            "aarch64" | "arm64" => Some(Arch::Aarch64),
            "mips" => Some(Arch::Mips),
            "mips64" => Some(Arch::Mips64),
            "ppc" | "powerpc" => Some(Arch::PowerPc),
            "ppc64" | "powerpc64" => Some(Arch::PowerPc64),
            "riscv32" => Some(Arch::RiscV32),
            "riscv64" => Some(Arch::RiscV64),
            _ => None,
        }
    }

    pub fn pointer_bits(self) -> u8 {
        match self {
            Arch::X86 | Arch::Arm | Arch::Mips | Arch::PowerPc | Arch::RiscV32 => 32,
            Arch::X86_64 | Arch::Aarch64 | Arch::Mips64 | Arch::PowerPc64 | Arch::RiscV64 => 64,
            Arch::Unknown => 0,
        }
    }

    /// Smallest step the linear sweep takes over bytes that do not decode.
    pub fn insn_unit(self) -> usize {
        match self {
            Arch::X86 | Arch::X86_64 | Arch::Unknown => 1,
            Arch::RiscV32 | Arch::RiscV64 => 2,
            _ => 4,
        }
    }

    pub fn max_insn_len(self) -> usize {
        match self {
            Arch::X86 | Arch::X86_64 => 15,
            _ => 4,
        }
    }
}

#[derive(Clone, Debug)]
pub struct ArchInfo {
    pub arch: Arch,
    pub endian: Endian,
    pub bits: u8,
    pub confidence: Confidence,
    pub evidence: String,
}

impl ArchInfo {
    pub fn unknown(evidence: &str) -> ArchInfo {
        ArchInfo {
            arch: Arch::Unknown,
            endian: Endian::Little,
            bits: 0,
            confidence: Confidence::Unknown,
            evidence: evidence.to_string(),
        }
    }
}

/// Architecture from an ELF header. `machine` is e_machine.
pub fn from_elf_machine(machine: u16, is64: bool, endian: Endian) -> ArchInfo {
    let class_text = if is64 { "64-bit" } else { "32-bit" };
    let (arch, label) = match machine {
        3 => (Arch::X86, "EM_386"),
        62 => (Arch::X86_64, "EM_X86_64"),
        40 => (Arch::Arm, "EM_ARM"),
        183 => (Arch::Aarch64, "EM_AARCH64"),
        8 => (if is64 { Arch::Mips64 } else { Arch::Mips }, "EM_MIPS"),
        20 => (Arch::PowerPc, "EM_PPC"),
        21 => (Arch::PowerPc64, "EM_PPC64"),
        243 => (if is64 { Arch::RiscV64 } else { Arch::RiscV32 }, "EM_RISCV"),
        _ => (Arch::Unknown, "unrecognized machine"),
    };
    let bits = if arch == Arch::Unknown {
        if is64 {
            64
        } else {
            32
        }
    } else {
        arch.pointer_bits()
    };
    ArchInfo {
        arch,
        endian,
        bits,
        confidence: if arch == Arch::Unknown {
            Confidence::Unknown
        } else {
            Confidence::Verified
        },
        evidence: format!(
            "e_machine={} ({}), {}, {}-endian",
            machine,
            label,
            class_text,
            endian.name()
        ),
    }
}

/// Architecture from a PE/COFF `Machine` field.
pub fn from_pe_machine(machine: u16) -> ArchInfo {
    let (arch, label) = match machine {
        0x014c => (Arch::X86, "IMAGE_FILE_MACHINE_I386"),
        0x8664 => (Arch::X86_64, "IMAGE_FILE_MACHINE_AMD64"),
        0x01c0 => (Arch::Arm, "IMAGE_FILE_MACHINE_ARM"),
        0x01c4 => (Arch::Arm, "IMAGE_FILE_MACHINE_ARMNT (Thumb-2)"),
        0xaa64 => (Arch::Aarch64, "IMAGE_FILE_MACHINE_ARM64"),
        0x5032 => (Arch::RiscV32, "IMAGE_FILE_MACHINE_RISCV32"),
        0x5064 => (Arch::RiscV64, "IMAGE_FILE_MACHINE_RISCV64"),
        _ => (Arch::Unknown, "unrecognized machine"),
    };
    ArchInfo {
        arch,
        endian: Endian::Little,
        bits: arch.pointer_bits(),
        confidence: if arch == Arch::Unknown {
            Confidence::Unknown
        } else {
            Confidence::Verified
        },
        evidence: format!("COFF Machine=0x{:04x} ({})", machine, label),
    }
}

/// Heuristic architecture guess for files without a header (BIN, RAW, DAT ...).
/// Counts distinctive function prologue/epilogue patterns in the first 4 MiB.
/// The result is always `Estimated` at best.
pub fn guess_raw(src: &dyn ByteSource) -> Result<ArchInfo> {
    let data = read_clamped(src, 0, 4 * 1024 * 1024)?;
    let mut a64: u64 = 0;
    let mut arm: u64 = 0;
    let mut x64: u64 = 0;
    let mut x32: u64 = 0;

    let mut i = 0usize;
    while i + 4 <= data.len() {
        let w = u32::from_le_bytes([data[i], data[i + 1], data[i + 2], data[i + 3]]);
        // AArch64
        if w == 0xd65f03c0 {
            a64 += 4; // ret
        } else if (w & 0xffc07fff) == 0xa9807bfd {
            a64 += 4; // stp x29, x30, [sp, #imm]!
        } else if (w & 0xffc07fff) == 0xa8c07bfd {
            a64 += 3; // ldp x29, x30, [sp], #imm
        } else if w == 0x910003fd {
            a64 += 3; // mov x29, sp
        } else if w == 0xd503233f || w == 0xd50323bf || w == 0xd503245f {
            a64 += 3; // paciasp / autiasp / bti c
        }
        // 32-bit ARM
        if (w & 0xffff4000) == 0xe92d4000 {
            arm += 3; // push {..., lr}
        } else if (w & 0xffff8000) == 0xe8bd8000 {
            arm += 3; // pop {..., pc}
        } else if w == 0xe12fff1e {
            arm += 4; // bx lr
        }
        i += 4;
    }

    let mut j = 0usize;
    while j + 4 <= data.len() {
        let b0 = data[j];
        let b1 = data[j + 1];
        let b2 = data[j + 2];
        let b3 = data[j + 3];
        if b0 == 0x55 && b1 == 0x48 && b2 == 0x89 && b3 == 0xe5 {
            x64 += 4; // push rbp; mov rbp, rsp
        } else if b0 == 0xf3 && b1 == 0x0f && b2 == 0x1e && b3 == 0xfa {
            x64 += 4; // endbr64
        } else if b0 == 0xf3 && b1 == 0x0f && b2 == 0x1e && b3 == 0xfb {
            x32 += 4; // endbr32
        } else if b0 == 0x55 && b1 == 0x89 && b2 == 0xe5 {
            x32 += 3; // push ebp; mov ebp, esp
        } else if b0 == 0x5d && b1 == 0xc3 {
            x64 += 1; // pop rbp; ret (shared by both)
            x32 += 1;
        }
        j += 1;
    }

    let scores = [
        (Arch::Aarch64, a64),
        (Arch::Arm, arm),
        (Arch::X86_64, x64),
        (Arch::X86, x32),
    ];
    let mut best = (Arch::Unknown, 0u64);
    let mut second = 0u64;
    for &(a, s) in scores.iter() {
        if s > best.1 {
            second = best.1;
            best = (a, s);
        } else if s > second {
            second = s;
        }
    }
    let evidence = format!(
        "pattern scores: aarch64={}, arm={}, x86_64={}, x86={}",
        a64, arm, x64, x32
    );
    if best.1 >= 12 && best.1 >= second * 2 {
        Ok(ArchInfo {
            arch: best.0,
            endian: Endian::Little,
            bits: best.0.pointer_bits(),
            confidence: Confidence::Estimated,
            evidence,
        })
    } else {
        Ok(ArchInfo::unknown(&format!(
            "no reliable code pattern found ({})",
            evidence
        )))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::MemSource;

    #[test]
    fn elf_machine_mapping() {
        let a = from_elf_machine(183, true, Endian::Little);
        assert_eq!(a.arch, Arch::Aarch64);
        assert_eq!(a.bits, 64);
        assert_eq!(a.confidence, Confidence::Verified);
        let b = from_elf_machine(62, true, Endian::Little);
        assert_eq!(b.arch, Arch::X86_64);
        let c = from_elf_machine(9999, false, Endian::Big);
        assert_eq!(c.arch, Arch::Unknown);
        assert_eq!(c.bits, 32);
    }

    #[test]
    fn pe_machine_mapping() {
        assert_eq!(from_pe_machine(0x8664).arch, Arch::X86_64);
        assert_eq!(from_pe_machine(0x14c).arch, Arch::X86);
        assert_eq!(from_pe_machine(0xaa64).arch, Arch::Aarch64);
        assert_eq!(from_pe_machine(0x1234).arch, Arch::Unknown);
    }

    #[test]
    fn guesses_aarch64_from_prologues() {
        let mut data: Vec<u8> = Vec::new();
        for _ in 0..20 {
            data.extend_from_slice(&0xa9bf7bfdu32.to_le_bytes());
            data.extend_from_slice(&0x910003fdu32.to_le_bytes());
            data.extend_from_slice(&0xd65f03c0u32.to_le_bytes());
        }
        let src = MemSource::new(data);
        let info = guess_raw(&src).unwrap();
        assert_eq!(info.arch, Arch::Aarch64);
        assert_eq!(info.confidence, Confidence::Estimated);
    }

    #[test]
    fn random_looking_data_stays_unknown() {
        let src = MemSource::new(vec![0x41; 4096]);
        let info = guess_raw(&src).unwrap();
        assert_eq!(info.arch, Arch::Unknown);
    }
}
