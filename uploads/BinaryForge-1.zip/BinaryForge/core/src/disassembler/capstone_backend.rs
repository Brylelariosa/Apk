//! Capstone-backed disassembler for x86, x86-64 and AArch64.
//!
//! A fresh `Capstone` handle is created per call. That is cheap and keeps this type
//! trivially `Send + Sync`. Only mnemonic and operand text are used, so the result does
//! not depend on Capstone's optional "detail" mode.

use capstone::prelude::*;

use crate::architecture::Arch;
use crate::disassembler::classify::{classify, registers_in, AdrpTracker};
use crate::disassembler::{Decoded, Disassembler, Flow, Insn};
use crate::util::hex::hex_bytes;

pub struct CapstoneBackend {
    arch: Arch,
}

impl CapstoneBackend {
    pub fn new(arch: Arch) -> CapstoneBackend {
        CapstoneBackend { arch }
    }
}

fn build(which: Arch) -> Option<Capstone> {
    let built = match which {
        Arch::X86_64 => Capstone::new()
            .x86()
            .mode(arch::x86::ArchMode::Mode64)
            .syntax(arch::x86::ArchSyntax::Intel)
            .build(),
        Arch::X86 => Capstone::new()
            .x86()
            .mode(arch::x86::ArchMode::Mode32)
            .syntax(arch::x86::ArchSyntax::Intel)
            .build(),
        Arch::Aarch64 => Capstone::new()
            .arm64()
            .mode(arch::arm64::ArchMode::Arm)
            .build(),
        _ => return None,
    };
    built.ok()
}

impl Disassembler for CapstoneBackend {
    fn arch(&self) -> Arch {
        self.arch
    }

    fn backend(&self) -> &'static str {
        "capstone"
    }

    fn sweep(&self, code: &[u8], addr: u64, last: bool, f: &mut dyn FnMut(&Decoded)) -> usize {
        let cs = match build(self.arch) {
            Some(c) => c,
            None => return code.len(),
        };
        let unit = self.arch.insn_unit();
        let guard = if last { 0 } else { self.arch.max_insn_len() };
        let mut tracker = AdrpTracker::new();
        let mut pos: usize = 0;
        while pos < code.len() {
            if !last && code.len() - pos < guard.max(1) {
                break;
            }
            let slice = &code[pos..];
            let mut advanced: usize = 0;
            let mut stop = false;
            if let Ok(insns) = cs.disasm_all(slice, addr.wrapping_add(pos as u64)) {
                for insn in insns.as_ref() {
                    let start = insn.address().wrapping_sub(addr) as usize;
                    if !last && code.len().saturating_sub(start) < guard {
                        stop = true;
                        break;
                    }
                    let len = insn.bytes().len();
                    let mnemonic = insn.mnemonic().unwrap_or("");
                    let ops = insn.op_str().unwrap_or("");
                    let mut c = classify(self.arch, mnemonic, ops, insn.address(), len);
                    if self.arch == Arch::Aarch64 {
                        tracker.observe(mnemonic, ops, c.flow, &mut c.mem);
                    }
                    f(&Decoded {
                        addr: insn.address(),
                        len,
                        flow: c.flow,
                        target: c.target,
                        mem: c.mem,
                    });
                    advanced = start + len - pos;
                }
            }
            pos += advanced;
            if stop {
                break;
            }
            if advanced == 0 {
                let n = unit.min(code.len() - pos);
                f(&Decoded {
                    addr: addr.wrapping_add(pos as u64),
                    len: n,
                    flow: Flow::Invalid,
                    target: None,
                    mem: None,
                });
                tracker.clear();
                pos += n;
            }
        }
        pos
    }

    fn disassemble(&self, code: &[u8], addr: u64, max_insns: usize) -> Vec<Insn> {
        let mut out: Vec<Insn> = Vec::new();
        let cs = match build(self.arch) {
            Some(c) => c,
            None => return out,
        };
        let unit = self.arch.insn_unit();
        let mut tracker = AdrpTracker::new();
        let mut pos: usize = 0;
        while pos < code.len() && out.len() < max_insns {
            let remaining = max_insns - out.len();
            let mut advanced: usize = 0;
            if let Ok(insns) = cs.disasm_count(&code[pos..], addr.wrapping_add(pos as u64), remaining) {
                for insn in insns.as_ref() {
                    let bytes = insn.bytes().to_vec();
                    let len = bytes.len();
                    let mnemonic = insn.mnemonic().unwrap_or("").to_string();
                    let ops = insn.op_str().unwrap_or("").to_string();
                    let mut c = classify(self.arch, &mnemonic, &ops, insn.address(), len);
                    if self.arch == Arch::Aarch64 {
                        tracker.observe(&mnemonic, &ops, c.flow, &mut c.mem);
                    }
                    out.push(Insn {
                        addr: insn.address(),
                        bytes,
                        regs: registers_in(self.arch, &ops),
                        mnemonic,
                        operands: ops,
                        flow: c.flow,
                        target: c.target,
                        mem: c.mem,
                        valid: true,
                    });
                    advanced += len;
                }
            }
            pos += advanced;
            if advanced == 0 {
                let n = unit.min(code.len() - pos);
                let raw = code[pos..pos + n].to_vec();
                let (mnemonic, operands) = if self.arch == Arch::Aarch64 && n == 4 {
                    let w = u32::from_le_bytes([raw[0], raw[1], raw[2], raw[3]]);
                    (".inst".to_string(), format!("0x{:08x}", w))
                } else {
                    (".byte".to_string(), format!("0x{}", hex_bytes(&raw)))
                };
                out.push(Insn {
                    addr: addr.wrapping_add(pos as u64),
                    bytes: raw,
                    mnemonic,
                    operands,
                    flow: Flow::Invalid,
                    target: None,
                    mem: None,
                    regs: Vec::new(),
                    valid: false,
                });
                tracker.clear();
                pos += n;
            }
        }
        out
    }
}
