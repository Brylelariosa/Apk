//! Text-based classification of disassembled instructions.
//!
//! The backend produces mnemonic and operand text. From that text this module derives
//! control flow, direct branch targets and statically known memory addresses. Keeping it
//! text-based means it works the same for any backend and can be unit-tested without one.

use crate::architecture::Arch;
use crate::disassembler::Flow;

#[derive(Clone, Copy, Debug)]
pub struct Classified {
    pub flow: Flow,
    pub target: Option<u64>,
    pub mem: Option<u64>,
}

pub fn classify(arch: Arch, mnemonic: &str, ops: &str, addr: u64, len: usize) -> Classified {
    match arch {
        Arch::Aarch64 => classify_a64(mnemonic, ops),
        Arch::X86 | Arch::X86_64 => classify_x86(mnemonic, ops, addr, len),
        _ => Classified {
            flow: Flow::Normal,
            target: None,
            mem: None,
        },
    }
}

fn parse_number(token: &str) -> Option<u64> {
    let t = token.trim();
    let (neg, t) = match t.strip_prefix('-') {
        Some(rest) => (true, rest),
        None => (false, t),
    };
    let v = if let Some(h) = t.strip_prefix("0x") {
        u64::from_str_radix(h, 16).ok()?
    } else {
        t.parse::<u64>().ok()?
    };
    Some(if neg { v.wrapping_neg() } else { v })
}

/// Number in the last operand ("x0, #0x1234" -> 0x1234, "0x401000" -> 0x401000).
fn last_number(ops: &str) -> Option<u64> {
    let tok = ops.rsplit(|c: char| c == ',' || c == ' ').next()?;
    let tok = tok.trim().trim_start_matches('#');
    if tok.is_empty() {
        return None;
    }
    parse_number(tok)
}

fn imm_of(token: &str) -> Option<u64> {
    parse_number(token.trim().trim_start_matches('#'))
}

fn classify_a64(m: &str, ops: &str) -> Classified {
    let flow = match m {
        "bl" => Flow::Call,
        "blr" | "blraa" | "blraaz" | "blrab" | "blrabz" => Flow::IndirectCall,
        "b" => Flow::Jump,
        "br" | "braa" | "braaz" | "brab" | "brabz" => Flow::IndirectJump,
        "ret" | "retaa" | "retab" | "eret" | "eretaa" | "eretab" => Flow::Return,
        "cbz" | "cbnz" | "tbz" | "tbnz" => Flow::CondJump,
        "svc" | "hvc" | "smc" | "brk" | "hlt" | "udf" => Flow::Trap,
        _ => {
            if m.starts_with("b.") || m.starts_with("bc.") {
                Flow::CondJump
            } else {
                Flow::Normal
            }
        }
    };
    let target = match flow {
        Flow::Call | Flow::Jump | Flow::CondJump => last_number(ops),
        _ => None,
    };
    let mem = match m {
        "adr" => last_number(ops),
        "ldr" | "ldrsw" | "prfm" => {
            if ops.contains('[') {
                None
            } else {
                last_number(ops)
            }
        }
        _ => None,
    };
    Classified { flow, target, mem }
}

/// "0x401000" (a bare hexadecimal literal) -> value.
fn direct_target(ops: &str) -> Option<u64> {
    let t = ops.trim();
    let digits = t.strip_prefix("0x")?;
    if digits.is_empty() || !digits.chars().all(|c| c.is_ascii_hexdigit()) {
        return None;
    }
    u64::from_str_radix(digits, 16).ok()
}

/// Effective address of a `[rip +/- disp]` operand.
fn rip_relative(ops: &str, addr: u64, len: usize) -> Option<u64> {
    let p = ops.find("rip")?;
    let after = ops[p + 3..].trim_start();
    let next = addr.wrapping_add(len as u64);
    let (neg, rest) = if let Some(r) = after.strip_prefix('+') {
        (false, r)
    } else if let Some(r) = after.strip_prefix('-') {
        (true, r)
    } else {
        return Some(next);
    };
    let rest = rest.trim_start();
    let end = rest
        .find(|c: char| !(c.is_ascii_hexdigit() || c == 'x' || c == 'X'))
        .unwrap_or(rest.len());
    let disp = parse_number(&rest[..end])?;
    Some(if neg {
        next.wrapping_sub(disp)
    } else {
        next.wrapping_add(disp)
    })
}

/// Address of an absolute `[0x...]` operand (not segment-relative).
fn absolute_mem(ops: &str) -> Option<u64> {
    let open = ops.find('[')?;
    let close = ops[open..].find(']')? + open;
    if open > 0 && ops.as_bytes()[open - 1] == b':' {
        return None;
    }
    direct_target(ops[open + 1..close].trim())
}

fn classify_x86(mnemonic: &str, ops: &str, addr: u64, len: usize) -> Classified {
    let base = mnemonic.split_whitespace().last().unwrap_or(mnemonic);
    let direct = direct_target(ops);
    let flow = match base {
        "call" => {
            if direct.is_some() {
                Flow::Call
            } else {
                Flow::IndirectCall
            }
        }
        "jmp" => {
            if direct.is_some() {
                Flow::Jump
            } else {
                Flow::IndirectJump
            }
        }
        "ret" | "retf" | "retn" | "iret" | "iretd" | "iretq" | "sysret" | "sysexit" => Flow::Return,
        "int3" | "int" | "ud2" | "hlt" | "syscall" | "sysenter" | "into" | "int1" | "ud0" | "ud1" => {
            Flow::Trap
        }
        b if b.starts_with("loop") => Flow::CondJump,
        b if b.starts_with('j') => Flow::CondJump,
        _ => Flow::Normal,
    };
    let target = match flow {
        Flow::Call | Flow::Jump | Flow::CondJump => direct,
        _ => None,
    };
    let mem = rip_relative(ops, addr, len).or_else(|| absolute_mem(ops));
    Classified { flow, target, mem }
}

pub fn registers_in(arch: Arch, ops: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for tok in ops.split(|c: char| !c.is_ascii_alphanumeric()) {
        if tok.is_empty() {
            continue;
        }
        let t = tok.to_ascii_lowercase();
        let is_reg = match arch {
            Arch::Aarch64 => is_a64_reg(&t),
            Arch::X86 | Arch::X86_64 => is_x86_reg(&t),
            _ => false,
        };
        if is_reg && !out.contains(&t) {
            out.push(t);
        }
    }
    out
}

fn is_a64_reg(t: &str) -> bool {
    if matches!(t, "sp" | "xzr" | "wzr" | "wsp" | "lr" | "fp") {
        return true;
    }
    let first = match t.chars().next() {
        Some(c) => c,
        None => return false,
    };
    if !matches!(first, 'x' | 'w' | 'v' | 'd' | 's' | 'q' | 'b' | 'h') {
        return false;
    }
    let digits = &t[1..];
    if digits.is_empty() || digits.len() > 2 || !digits.chars().all(|c| c.is_ascii_digit()) {
        return false;
    }
    let n: u32 = match digits.parse() {
        Ok(v) => v,
        Err(_) => return false,
    };
    match first {
        'x' | 'w' => n <= 30,
        _ => n <= 31,
    }
}

fn is_x86_reg(t: &str) -> bool {
    const NAMES: &[&str] = &[
        "rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rbp", "rsp", "rip", "eax", "ebx", "ecx", "edx",
        "esi", "edi", "ebp", "esp", "eip", "ax", "bx", "cx", "dx", "si", "di", "bp", "sp", "al",
        "bl", "cl", "dl", "ah", "bh", "ch", "dh", "sil", "dil", "bpl", "spl", "cs", "ds", "es",
        "fs", "gs", "ss", "eflags", "rflags",
    ];
    if NAMES.contains(&t) {
        return true;
    }
    if let Some(rest) = t.strip_prefix('r') {
        let digits: String = rest.chars().take_while(|c| c.is_ascii_digit()).collect();
        let suffix = &rest[digits.len()..];
        if let Ok(n) = digits.parse::<u32>() {
            if (8..=15).contains(&n) && (suffix.is_empty() || suffix == "d" || suffix == "w" || suffix == "b") {
                return true;
            }
        }
    }
    for prefix in ["xmm", "ymm", "zmm"] {
        if let Some(rest) = t.strip_prefix(prefix) {
            if let Ok(n) = rest.parse::<u32>() {
                if n <= 31 {
                    return true;
                }
            }
        }
    }
    if let Some(rest) = t.strip_prefix("st") {
        if let Ok(n) = rest.parse::<u32>() {
            if n <= 7 {
                return true;
            }
        }
    }
    false
}

fn a64_reg_index(token: &str) -> Option<usize> {
    let t = token.trim();
    let rest = t.strip_prefix('x').or_else(|| t.strip_prefix('w'))?;
    let n: usize = rest.parse().ok()?;
    if n <= 30 {
        Some(n)
    } else {
        None
    }
}

/// Base register and constant offset of a `[xN, #imm]` operand.
fn a64_mem_operand(ops: &str) -> Option<(usize, u64)> {
    let open = ops.find('[')?;
    let close = ops[open..].find(']')? + open;
    let inner = &ops[open + 1..close];
    let mut it = inner.split(',');
    let base = a64_reg_index(it.next()?)?;
    match it.next() {
        None => Some((base, 0)),
        Some(second) => {
            let s = second.trim();
            if !s.starts_with('#') {
                return None;
            }
            if it.next().is_some() {
                return None;
            }
            Some((base, imm_of(s)?))
        }
    }
}

/// Resolves `adrp` + `add`/`ldr`/`str` address pairs on AArch64.
///
/// The result is a heuristic: it is reset at every control transfer and whenever a tracked
/// register is overwritten, but it cannot see through arbitrary register moves.
pub struct AdrpTracker {
    pages: [Option<u64>; 32],
}

impl Default for AdrpTracker {
    fn default() -> AdrpTracker {
        AdrpTracker::new()
    }
}

impl AdrpTracker {
    pub fn new() -> AdrpTracker {
        AdrpTracker { pages: [None; 32] }
    }

    pub fn clear(&mut self) {
        self.pages = [None; 32];
    }

    /// Feeds one instruction. May set `mem` to the address that a pair resolved to.
    pub fn observe(&mut self, mnemonic: &str, ops: &str, flow: Flow, mem: &mut Option<u64>) {
        if flow != Flow::Normal {
            self.clear();
            return;
        }
        let parts: Vec<&str> = ops.split(',').map(|p| p.trim()).collect();
        match mnemonic {
            "adrp" => {
                if parts.len() == 2 {
                    if let (Some(r), Some(v)) = (a64_reg_index(parts[0]), last_number(parts[1])) {
                        self.pages[r] = Some(v);
                    }
                }
            }
            "add" => {
                if parts.len() >= 3 {
                    let rd = a64_reg_index(parts[0]);
                    let rn = a64_reg_index(parts[1]);
                    if let (Some(rd), Some(rn)) = (rd, rn) {
                        if let Some(page) = self.pages[rn] {
                            if let Some(mut imm) = imm_of(parts[2]) {
                                if parts.len() == 4 && parts[3].replace(' ', "") == "lsl#12" {
                                    imm <<= 12;
                                }
                                *mem = Some(page.wrapping_add(imm));
                            }
                        }
                        self.pages[rd] = None;
                    } else if let Some(rd) = rd {
                        self.pages[rd] = None;
                    }
                }
            }
            "cmp" | "cmn" | "tst" | "ccmp" | "ccmn" | "nop" | "prfm" | "dmb" | "dsb" | "isb" => {}
            m if m.starts_with("ld") || m.starts_with("st") => {
                if let Some((rn, off)) = a64_mem_operand(ops) {
                    if let Some(page) = self.pages[rn] {
                        *mem = Some(page.wrapping_add(off));
                    }
                }
                if m.starts_with("ld") {
                    if let Some(r) = parts.get(0).and_then(|p| a64_reg_index(p)) {
                        self.pages[r] = None;
                    }
                    if m.starts_with("ldp") {
                        if let Some(r) = parts.get(1).and_then(|p| a64_reg_index(p)) {
                            self.pages[r] = None;
                        }
                    }
                }
            }
            _ => {
                if let Some(first) = parts.get(0) {
                    if let Some(r) = a64_reg_index(first) {
                        self.pages[r] = None;
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn aarch64_flow_and_targets() {
        let c = classify(Arch::Aarch64, "bl", "#0x1234", 0x1000, 4);
        assert_eq!(c.flow, Flow::Call);
        assert_eq!(c.target, Some(0x1234));

        let c = classify(Arch::Aarch64, "b.eq", "#0x20", 0x1000, 4);
        assert_eq!(c.flow, Flow::CondJump);
        assert_eq!(c.target, Some(0x20));

        let c = classify(Arch::Aarch64, "tbz", "w0, #3, #0x40", 0x1000, 4);
        assert_eq!(c.flow, Flow::CondJump);
        assert_eq!(c.target, Some(0x40));

        let c = classify(Arch::Aarch64, "ret", "", 0x1000, 4);
        assert_eq!(c.flow, Flow::Return);
        assert_eq!(c.target, None);

        let c = classify(Arch::Aarch64, "br", "x16", 0x1000, 4);
        assert_eq!(c.flow, Flow::IndirectJump);
    }

    #[test]
    fn aarch64_memory_references() {
        assert_eq!(classify(Arch::Aarch64, "adr", "x0, #0x1008", 0x1000, 4).mem, Some(0x1008));
        assert_eq!(classify(Arch::Aarch64, "ldr", "x0, #0x2000", 0x1000, 4).mem, Some(0x2000));
        assert_eq!(classify(Arch::Aarch64, "ldr", "x0, [x1, #8]", 0x1000, 4).mem, None);
    }

    #[test]
    fn x86_flow_and_memory() {
        let c = classify(Arch::X86_64, "call", "0x401000", 0x400000, 5);
        assert_eq!(c.flow, Flow::Call);
        assert_eq!(c.target, Some(0x401000));

        let c = classify(Arch::X86_64, "call", "rax", 0x400000, 2);
        assert_eq!(c.flow, Flow::IndirectCall);

        let c = classify(Arch::X86_64, "jmp", "qword ptr [rip + 0x2fe2]", 0x1000, 6);
        assert_eq!(c.flow, Flow::IndirectJump);
        assert_eq!(c.mem, Some(0x1000 + 6 + 0x2fe2));

        let c = classify(Arch::X86_64, "je", "0x1010", 0x1000, 2);
        assert_eq!(c.flow, Flow::CondJump);
        assert_eq!(c.target, Some(0x1010));

        assert_eq!(classify(Arch::X86_64, "mov", "eax, dword ptr fs:[0x28]", 0, 6).mem, None);
        assert_eq!(classify(Arch::X86, "mov", "eax, dword ptr [0x4a1234]", 0, 5).mem, Some(0x4a1234));
        assert_eq!(classify(Arch::X86_64, "bnd jmp", "0x2000", 0, 5).flow, Flow::Jump);
        assert_eq!(classify(Arch::X86_64, "ret", "", 0, 1).flow, Flow::Return);
    }

    #[test]
    fn adrp_pairs_are_resolved() {
        let mut t = AdrpTracker::new();
        let mut mem = None;
        t.observe("adrp", "x8, #0x5000", Flow::Normal, &mut mem);
        assert_eq!(mem, None);
        t.observe("add", "x8, x8, #0x10", Flow::Normal, &mut mem);
        assert_eq!(mem, Some(0x5010));

        let mut after = None;
        t.observe("ldr", "x0, [x8, #8]", Flow::Normal, &mut after);
        assert_eq!(after, None);

        t.observe("adrp", "x9, #0x6000", Flow::Normal, &mut after);
        t.observe("ldr", "x1, [x9, #0x18]", Flow::Normal, &mut after);
        assert_eq!(after, Some(0x6018));

        let mut cleared = None;
        t.observe("adrp", "x10, #0x7000", Flow::Normal, &mut cleared);
        t.observe("bl", "#0x1", Flow::Call, &mut cleared);
        t.observe("add", "x10, x10, #4", Flow::Normal, &mut cleared);
        assert_eq!(cleared, None);
    }

    #[test]
    fn register_extraction() {
        assert_eq!(
            registers_in(Arch::Aarch64, "x29, x30, [sp, #-0x10]!"),
            vec!["x29".to_string(), "x30".to_string(), "sp".to_string()]
        );
        assert_eq!(
            registers_in(Arch::X86_64, "rax, qword ptr [rbp - 8]"),
            vec!["rax".to_string(), "rbp".to_string()]
        );
    }
}
