//! Machine-code disassembly.
//!
//! The `Disassembler` trait hides the backend. The engine only needs two operations:
//! a fast linear sweep (flow, branch target, memory reference per instruction) and a
//! detailed listing (text, bytes, registers) for display and export.

mod capstone_backend;
pub mod classify;

use crate::architecture::Arch;
use crate::types::Endian;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Flow {
    Normal,
    Jump,
    CondJump,
    Call,
    IndirectJump,
    IndirectCall,
    Return,
    Trap,
    Invalid,
}

impl Flow {
    pub fn name(self) -> &'static str {
        match self {
            Flow::Normal => "normal",
            Flow::Jump => "jump",
            Flow::CondJump => "cond_jump",
            Flow::Call => "call",
            Flow::IndirectJump => "indirect_jump",
            Flow::IndirectCall => "indirect_call",
            Flow::Return => "return",
            Flow::Trap => "trap",
            Flow::Invalid => "invalid",
        }
    }
}

/// Light-weight result handed to the sweep callback (no text).
#[derive(Clone, Copy, Debug)]
pub struct Decoded {
    pub addr: u64,
    pub len: usize,
    pub flow: Flow,
    /// Destination of a direct branch or call.
    pub target: Option<u64>,
    /// Address of a statically known memory operand.
    pub mem: Option<u64>,
}

/// A fully described instruction.
#[derive(Clone, Debug)]
pub struct Insn {
    pub addr: u64,
    pub bytes: Vec<u8>,
    pub mnemonic: String,
    pub operands: String,
    pub flow: Flow,
    pub target: Option<u64>,
    pub mem: Option<u64>,
    /// Registers named by the operands (references, not read/write roles).
    pub regs: Vec<String>,
    pub valid: bool,
}

pub trait Disassembler: Send + Sync {
    fn arch(&self) -> Arch;
    fn backend(&self) -> &'static str;

    /// Linear sweep over `code`, mapped at `addr`. `f` is called for every decoded unit
    /// (undecodable bytes are reported as `Flow::Invalid`). When `last` is false the
    /// final few bytes are left unprocessed so an instruction is never cut at a chunk
    /// boundary. Returns the number of bytes consumed.
    fn sweep(&self, code: &[u8], addr: u64, last: bool, f: &mut dyn FnMut(&Decoded)) -> usize;

    /// Decodes up to `max_insns` instructions from the start of `code`.
    fn disassemble(&self, code: &[u8], addr: u64, max_insns: usize) -> Vec<Insn>;
}

/// Creates a backend for `arch`, or `None` when this build cannot disassemble it.
pub fn create(arch: Arch, endian: Endian) -> Option<Box<dyn Disassembler>> {
    if endian != Endian::Little {
        return None;
    }
    match arch {
        Arch::X86 | Arch::X86_64 | Arch::Aarch64 => {
            Some(Box::new(capstone_backend::CapstoneBackend::new(arch)))
        }
        _ => None,
    }
}
