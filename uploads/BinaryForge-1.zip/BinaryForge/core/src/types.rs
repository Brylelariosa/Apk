//! Small value types shared by every module.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Endian {
    Little,
    Big,
}

impl Endian {
    pub fn name(self) -> &'static str {
        match self {
            Endian::Little => "little",
            Endian::Big => "big",
        }
    }
}

/// How sure the engine is about a piece of information.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Confidence {
    /// Read directly from a structure that the file itself defines.
    Verified,
    /// Derived by a reliable rule (for example a call target) but not stated by the file.
    Likely,
    /// Heuristic result. A hint, not a fact.
    Estimated,
    /// Supplied by the user (manual format selection).
    Assumed,
    Unknown,
}

impl Confidence {
    pub fn name(self) -> &'static str {
        match self {
            Confidence::Verified => "verified",
            Confidence::Likely => "likely",
            Confidence::Estimated => "estimated",
            Confidence::Assumed => "assumed",
            Confidence::Unknown => "unknown",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct Perms {
    pub read: bool,
    pub write: bool,
    pub exec: bool,
}

impl Perms {
    pub fn new(read: bool, write: bool, exec: bool) -> Perms {
        Perms { read, write, exec }
    }

    pub fn text(self) -> String {
        let mut s = String::with_capacity(3);
        s.push(if self.read { 'r' } else { '-' });
        s.push(if self.write { 'w' } else { '-' });
        s.push(if self.exec { 'x' } else { '-' });
        s
    }
}
