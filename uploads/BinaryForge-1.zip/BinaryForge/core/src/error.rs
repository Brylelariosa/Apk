use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    Io(String),
    OutOfBounds { offset: u64, len: u64, size: u64 },
    Malformed(String),
    Unsupported(String),
    Limit(String),
    Cancelled,
    Other(String),
}

pub type Result<T> = std::result::Result<T, Error>;

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Io(m) => write!(f, "I/O error: {}", m),
            Error::OutOfBounds { offset, len, size } => write!(
                f,
                "read of {} bytes at offset 0x{:x} is outside the file (size {})",
                len, offset, size
            ),
            Error::Malformed(m) => write!(f, "malformed data: {}", m),
            Error::Unsupported(m) => write!(f, "unsupported: {}", m),
            Error::Limit(m) => write!(f, "limit exceeded: {}", m),
            Error::Cancelled => write!(f, "cancelled"),
            Error::Other(m) => write!(f, "{}", m),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Error {
        Error::Io(e.to_string())
    }
}
