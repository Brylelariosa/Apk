//! BinaryForge analysis engine.
//!
//! Everything here treats input files as untrusted: all reads are bounds-checked,
//! nothing is executed, and the original file is only ever opened read-only.

pub mod architecture;
pub mod dependencies;
pub mod disassembler;
pub mod error;
pub mod extraction;
pub mod formats;
pub mod functions;
pub mod memory;
pub mod parser;
pub mod project;
pub mod references;
pub mod types;
pub mod util;

pub use error::{Error, Result};

/// Engine version reported to the app.
pub const ENGINE_VERSION: &str = env!("CARGO_PKG_VERSION");
