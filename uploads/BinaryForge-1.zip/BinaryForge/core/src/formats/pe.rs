//! PE/COFF parser (PE32 and PE32+).

use crate::architecture::from_pe_machine;
use crate::error::{Error, Result};
use crate::formats::{
    BinaryImage, CodeRegion, EntryPoint, FormatKind, Import, KnownFunction, Section, SectionKind,
    SymKind, Symbol,
};
use crate::memory::Region;
use crate::parser::{read_cstr, read_vec, ByteSource, Bytes};
use crate::types::{Confidence, Endian, Perms};

const SCN_CNT_CODE: u32 = 0x0000_0020;
const SCN_CNT_INIT: u32 = 0x0000_0040;
const SCN_CNT_UNINIT: u32 = 0x0000_0080;
const SCN_MEM_EXECUTE: u32 = 0x2000_0000;
const SCN_MEM_READ: u32 = 0x4000_0000;
const SCN_MEM_WRITE: u32 = 0x8000_0000;

const DIR_EXPORT: usize = 0;
const DIR_IMPORT: usize = 1;
const DIR_EXCEPTION: usize = 3;
const DIR_DELAY_IMPORT: usize = 13;
const DIR_CLR: usize = 14;

struct PeSection {
    name: String,
    vsize: u32,
    rva: u32,
    raw_size: u32,
    raw_ptr: u32,
    flags: u32,
}

struct Layout {
    image_base: u64,
    size_of_headers: u32,
    file_size: u64,
    sections: Vec<PeSection>,
}

impl Layout {
    /// Bytes of a section that the loader copies from the file.
    fn backed_len(s: &PeSection) -> u32 {
        if s.vsize != 0 {
            s.vsize.min(s.raw_size)
        } else {
            s.raw_size
        }
    }

    fn rva_to_offset(&self, rva: u32) -> Option<u64> {
        if rva < self.size_of_headers {
            let off = rva as u64;
            return if off < self.file_size { Some(off) } else { None };
        }
        for s in &self.sections {
            if rva >= s.rva {
                let d = rva - s.rva;
                if d < Layout::backed_len(s) {
                    let off = s.raw_ptr as u64 + d as u64;
                    return if off < self.file_size { Some(off) } else { None };
                }
            }
        }
        None
    }
}

fn subsystem_name(v: u16) -> String {
    let s = match v {
        1 => "native",
        2 => "Windows GUI",
        3 => "Windows console",
        5 => "OS/2 console",
        7 => "POSIX console",
        9 => "Windows CE GUI",
        10 => "EFI application",
        11 => "EFI boot service driver",
        12 => "EFI runtime driver",
        14 => "Xbox",
        _ => return format!("{}", v),
    };
    s.to_string()
}

fn read_thunks(
    src: &dyn ByteSource,
    layout: &Layout,
    is64: bool,
    library: &str,
    int_rva: u32,
    iat_rva: u32,
    out: &mut Vec<Import>,
) {
    let ptr: u64 = if is64 { 8 } else { 4 };
    let table_rva = if int_rva != 0 { int_rva } else { iat_rva };
    let table_off = match layout.rva_to_offset(table_rva) {
        Some(o) => o,
        None => return,
    };
    let mut idx: u64 = 0;
    while idx < 65536 {
        let raw = match read_vec(src, table_off + idx * ptr, ptr) {
            Ok(r) => r,
            Err(_) => break,
        };
        let v = Bytes::new(&raw, Endian::Little).word(0, is64).unwrap_or(0);
        if v == 0 {
            break;
        }
        let slot_va = layout
            .image_base
            .wrapping_add(iat_rva as u64)
            .wrapping_add(idx * ptr);
        let by_ordinal = if is64 { (v >> 63) == 1 } else { (v >> 31) == 1 };
        if by_ordinal {
            let ord = (v & 0xffff) as u32;
            out.push(Import {
                library: library.to_string(),
                name: format!("#{}", ord),
                ordinal: Some(ord),
                slot_va,
            });
        } else {
            let name_rva = (v & 0x7fff_ffff) as u32;
            let name = match layout.rva_to_offset(name_rva) {
                Some(o) => read_cstr(src, o + 2, 512).unwrap_or_default(),
                None => String::new(),
            };
            out.push(Import {
                library: library.to_string(),
                name,
                ordinal: None,
                slot_va,
            });
        }
        idx += 1;
    }
}

pub fn parse(src: &dyn ByteSource) -> Result<BinaryImage> {
    let file_size = src.len();
    let dos = read_vec(src, 0, 64)?;
    if dos[0] != b'M' || dos[1] != b'Z' {
        return Err(Error::Malformed("missing MZ signature".to_string()));
    }
    let e_lfanew = Bytes::new(&dos, Endian::Little).u32(0x3c)? as u64;
    let sig = read_vec(src, e_lfanew, 4)?;
    if sig.as_slice() != b"PE\0\0" {
        return Err(Error::Malformed("missing PE signature".to_string()));
    }
    let coff = read_vec(src, e_lfanew + 4, 20)?;
    let c = Bytes::new(&coff, Endian::Little);
    let machine = c.u16(0)?;
    let nsections = c.u16(2)? as usize;
    let timestamp = c.u32(4)?;
    let size_opt = c.u16(16)? as u64;
    let characteristics = c.u16(18)?;
    if size_opt < 96 {
        return Err(Error::Malformed("the optional header is too small".to_string()));
    }
    if nsections > 1000 {
        return Err(Error::Malformed(format!("implausible section count {}", nsections)));
    }
    let opt_off = e_lfanew + 24;
    let opt = read_vec(src, opt_off, size_opt)?;
    let o = Bytes::new(&opt, Endian::Little);
    let magic = o.u16(0)?;
    let is64 = match magic {
        0x10b => false,
        0x20b => true,
        other => {
            return Err(Error::Unsupported(format!(
                "optional header magic 0x{:x}",
                other
            )))
        }
    };
    let entry_rva = o.u32(16)?;
    let image_base: u64 = if is64 { o.u64(24)? } else { o.u32(28)? as u64 };
    let size_of_image = o.u32(56)?;
    let size_of_headers = o.u32(60)?;
    let checksum = o.u32(64)?;
    let subsystem = o.u16(68)?;
    let dll_chars = o.u16(70)?;
    let (nrva_off, dd_off): (usize, usize) = if is64 { (108, 112) } else { (92, 96) };
    let nrva = o.u32(nrva_off).unwrap_or(0) as usize;
    let mut dirs: Vec<(u32, u32)> = Vec::new();
    for i in 0..nrva.min(16) {
        let at = dd_off + i * 8;
        match (o.u32(at), o.u32(at + 4)) {
            (Ok(rva), Ok(sz)) => dirs.push((rva, sz)),
            _ => break,
        }
    }

    let sec_off = opt_off + size_opt;
    let sec_raw = read_vec(src, sec_off, nsections as u64 * 40)?;
    let mut psections: Vec<PeSection> = Vec::new();
    for i in 0..nsections {
        let at = i * 40;
        let sb = Bytes::new(&sec_raw[at..at + 40], Endian::Little);
        let name_bytes = &sec_raw[at..at + 8];
        let end = name_bytes.iter().position(|&b| b == 0).unwrap_or(8);
        psections.push(PeSection {
            name: String::from_utf8_lossy(&name_bytes[..end]).into_owned(),
            vsize: sb.u32(8)?,
            rva: sb.u32(12)?,
            raw_size: sb.u32(16)?,
            raw_ptr: sb.u32(20)?,
            flags: sb.u32(36)?,
        });
    }

    let layout = Layout {
        image_base,
        size_of_headers,
        file_size,
        sections: psections,
    };

    let mut warnings: Vec<String> = Vec::new();
    let mut sections: Vec<Section> = Vec::new();
    let mut regions: Vec<Region> = Vec::new();
    let mut code_regions: Vec<CodeRegion> = Vec::new();

    let hdr_file = (size_of_headers as u64).min(file_size);
    regions.push(Region {
        name: "headers".to_string(),
        va: image_base,
        mem_size: if size_of_headers != 0 { size_of_headers as u64 } else { hdr_file },
        file_offset: 0,
        file_size: hdr_file,
        perms: Perms::new(true, false, false),
    });

    let mut clamped = 0u32;
    for (i, s) in layout.sections.iter().enumerate() {
        let mem_size: u64 = if s.vsize != 0 { s.vsize as u64 } else { s.raw_size as u64 };
        let mut file_bytes = Layout::backed_len(s) as u64;
        let raw_ptr = s.raw_ptr as u64;
        let mut confidence = Confidence::Verified;
        if file_bytes > 0 && raw_ptr + file_bytes > file_size {
            confidence = Confidence::Estimated;
            file_bytes = file_size.saturating_sub(raw_ptr).min(file_bytes);
            clamped += 1;
        }
        let kind = if s.flags & (SCN_CNT_CODE | SCN_MEM_EXECUTE) != 0 {
            SectionKind::Code
        } else if s.name.starts_with(".debug") {
            SectionKind::Debug
        } else if s.flags & SCN_CNT_UNINIT != 0 && s.raw_size == 0 {
            SectionKind::Bss
        } else if s.flags & SCN_CNT_INIT != 0 {
            SectionKind::Data
        } else {
            SectionKind::Unknown
        };
        let perms = Perms::new(
            s.flags & SCN_MEM_READ != 0,
            s.flags & SCN_MEM_WRITE != 0,
            s.flags & SCN_MEM_EXECUTE != 0,
        );
        let va = image_base.wrapping_add(s.rva as u64);
        sections.push(Section {
            index: (i as u32) + 1,
            name: s.name.clone(),
            kind,
            va,
            file_offset: raw_ptr,
            file_size: file_bytes,
            mem_size,
            perms,
            type_name: format!("flags 0x{:08x}", s.flags),
            confidence,
        });
        regions.push(Region {
            name: s.name.clone(),
            va,
            mem_size,
            file_offset: raw_ptr,
            file_size: file_bytes.min(mem_size),
            perms,
        });
        if kind == SectionKind::Code && file_bytes > 0 {
            code_regions.push(CodeRegion {
                name: s.name.clone(),
                va,
                file_offset: raw_ptr,
                size: file_bytes.min(mem_size),
                confidence,
            });
        }
    }
    if clamped > 0 {
        warnings.push(format!(
            "{} section(s) extend past the end of the file; their sizes were clamped.",
            clamped
        ));
    }

    // ---- imports ---------------------------------------------------------------------
    let mut imports: Vec<Import> = Vec::new();
    let mut libraries: Vec<String> = Vec::new();
    if let Some(&(rva, _size)) = dirs.get(DIR_IMPORT) {
        if rva != 0 {
            if let Some(off) = layout.rva_to_offset(rva) {
                let mut i: u64 = 0;
                while i < 4096 {
                    let raw = match read_vec(src, off + i * 20, 20) {
                        Ok(r) => r,
                        Err(_) => break,
                    };
                    let d = Bytes::new(&raw, Endian::Little);
                    let orig = d.u32(0).unwrap_or(0);
                    let name_rva = d.u32(12).unwrap_or(0);
                    let first = d.u32(16).unwrap_or(0);
                    if orig == 0 && name_rva == 0 && first == 0 {
                        break;
                    }
                    let lib = layout
                        .rva_to_offset(name_rva)
                        .and_then(|o| read_cstr(src, o, 256).ok())
                        .unwrap_or_default();
                    if !libraries.contains(&lib) {
                        libraries.push(lib.clone());
                    }
                    read_thunks(src, &layout, is64, &lib, orig, first, &mut imports);
                    i += 1;
                }
            }
        }
    }
    let mut delay_count = 0u32;
    if let Some(&(rva, _size)) = dirs.get(DIR_DELAY_IMPORT) {
        if rva != 0 {
            if let Some(off) = layout.rva_to_offset(rva) {
                let mut i: u64 = 0;
                while i < 1024 {
                    let raw = match read_vec(src, off + i * 32, 32) {
                        Ok(r) => r,
                        Err(_) => break,
                    };
                    let d = Bytes::new(&raw, Endian::Little);
                    let attrs = d.u32(0).unwrap_or(0);
                    let name_rva = d.u32(4).unwrap_or(0);
                    let iat = d.u32(12).unwrap_or(0);
                    let int = d.u32(16).unwrap_or(0);
                    if name_rva == 0 {
                        break;
                    }
                    if attrs & 1 == 1 {
                        let lib = layout
                            .rva_to_offset(name_rva)
                            .and_then(|o| read_cstr(src, o, 256).ok())
                            .unwrap_or_default();
                        if !libraries.contains(&lib) {
                            libraries.push(lib.clone());
                        }
                        read_thunks(src, &layout, is64, &lib, int, iat, &mut imports);
                        delay_count += 1;
                    }
                    i += 1;
                }
            }
        }
    }

    // ---- exports ---------------------------------------------------------------------
    let mut symbols: Vec<Symbol> = Vec::new();
    if let Some(&(rva, size)) = dirs.get(DIR_EXPORT) {
        if rva != 0 && size >= 40 {
            if let Some(off) = layout.rva_to_offset(rva) {
                if let Ok(raw) = read_vec(src, off, 40) {
                    let e = Bytes::new(&raw, Endian::Little);
                    let base = e.u32(16).unwrap_or(0);
                    let nfuncs = (e.u32(20).unwrap_or(0) as u64).min(200_000);
                    let nnames = (e.u32(24).unwrap_or(0) as u64).min(200_000);
                    let aof = e.u32(28).unwrap_or(0);
                    let aon = e.u32(32).unwrap_or(0);
                    let aoo = e.u32(36).unwrap_or(0);
                    let funcs = layout
                        .rva_to_offset(aof)
                        .and_then(|o| read_vec(src, o, nfuncs * 4).ok())
                        .unwrap_or_default();
                    let names = layout
                        .rva_to_offset(aon)
                        .and_then(|o| read_vec(src, o, nnames * 4).ok())
                        .unwrap_or_default();
                    let ords = layout
                        .rva_to_offset(aoo)
                        .and_then(|o| read_vec(src, o, nnames * 2).ok())
                        .unwrap_or_default();
                    let fb = Bytes::new(&funcs, Endian::Little);
                    let nb = Bytes::new(&names, Endian::Little);
                    let ob = Bytes::new(&ords, Endian::Little);
                    let mut named = vec![false; nfuncs as usize];
                    let in_export_dir = |r: u32| r >= rva && r - rva < size;
                    let code_kind = |r: u32| -> SymKind {
                        let va = image_base.wrapping_add(r as u64);
                        for cr in &code_regions {
                            if va >= cr.va && va - cr.va < cr.size {
                                return SymKind::Func;
                            }
                        }
                        SymKind::Object
                    };
                    for i in 0..(nnames as usize) {
                        let ord = match ob.u16(i * 2) {
                            Ok(v) => v as usize,
                            Err(_) => break,
                        };
                        let func_rva = match fb.u32(ord * 4) {
                            Ok(v) => v,
                            Err(_) => continue,
                        };
                        let name_rva = nb.u32(i * 4).unwrap_or(0);
                        if ord < named.len() {
                            named[ord] = true;
                        }
                        if func_rva == 0 || in_export_dir(func_rva) {
                            continue;
                        }
                        let name = layout
                            .rva_to_offset(name_rva)
                            .and_then(|o| read_cstr(src, o, 512).ok())
                            .unwrap_or_default();
                        if name.is_empty() {
                            continue;
                        }
                        symbols.push(Symbol {
                            name,
                            va: image_base.wrapping_add(func_rva as u64),
                            size: 0,
                            kind: code_kind(func_rva),
                            global: true,
                            is_import: false,
                            is_export: true,
                            source: "export",
                        });
                    }
                    for idx in 0..(nfuncs as usize) {
                        if named[idx] {
                            continue;
                        }
                        let func_rva = fb.u32(idx * 4).unwrap_or(0);
                        if func_rva == 0 || in_export_dir(func_rva) {
                            continue;
                        }
                        symbols.push(Symbol {
                            name: format!("ordinal_{}", base as u64 + idx as u64),
                            va: image_base.wrapping_add(func_rva as u64),
                            size: 0,
                            kind: code_kind(func_rva),
                            global: true,
                            is_import: false,
                            is_export: true,
                            source: "export",
                        });
                    }
                }
            }
        }
    }

    // ---- exception table: exact function ranges (x64 only) ------------------------------
    let mut known: Vec<KnownFunction> = Vec::new();
    if machine == 0x8664 {
        if let Some(&(rva, size)) = dirs.get(DIR_EXCEPTION) {
            if rva != 0 && size >= 12 {
                if let Some(off) = layout.rva_to_offset(rva) {
                    let n = (size as u64 / 12).min(2_000_000);
                    let mut done: u64 = 0;
                    while done < n {
                        let m = (n - done).min(4096);
                        let raw = match read_vec(src, off + done * 12, m * 12) {
                            Ok(r) => r,
                            Err(_) => break,
                        };
                        let b = Bytes::new(&raw, Endian::Little);
                        for i in 0..(m as usize) {
                            let begin = b.u32(i * 12).unwrap_or(0);
                            let end = b.u32(i * 12 + 4).unwrap_or(0);
                            let unwind = b.u32(i * 12 + 8).unwrap_or(0);
                            if begin == 0 || end <= begin {
                                continue;
                            }
                            let mut parent: Option<u64> = None;
                            if unwind != 0 && (unwind & 1) == 0 {
                                if let Some(uo) = layout.rva_to_offset(unwind) {
                                    if let Ok(u) = read_vec(src, uo, 4) {
                                        let flags = u[0] >> 3;
                                        if flags & 4 != 0 {
                                            let count = u[2] as u64;
                                            let codes = ((count + 1) & !1) * 2;
                                            if let Ok(ch) = read_vec(src, uo + 4 + codes, 12) {
                                                let pb = Bytes::new(&ch, Endian::Little).u32(0).unwrap_or(0);
                                                if pb != 0 {
                                                    parent = Some(image_base.wrapping_add(pb as u64));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            known.push(KnownFunction {
                                start: image_base.wrapping_add(begin as u64),
                                end: image_base.wrapping_add(end as u64),
                                parent,
                            });
                        }
                        done += m;
                    }
                }
            }
        }
    }

    // ---- entry point, warnings, metadata ----------------------------------------------
    let mut entry_points: Vec<EntryPoint> = Vec::new();
    if entry_rva != 0 {
        entry_points.push(EntryPoint {
            va: image_base.wrapping_add(entry_rva as u64),
            name: "AddressOfEntryPoint".to_string(),
            kind: "entry".to_string(),
            confidence: Confidence::Verified,
        });
    }
    if let Some(&(rva, _)) = dirs.get(DIR_CLR) {
        if rva != 0 {
            warnings.push(
                "A CLR header is present: this is a managed (.NET) assembly. Its code is IL, so native disassembly is not meaningful."
                    .to_string(),
            );
        }
    }
    if machine == 0xaa64 {
        warnings.push(
            "ARM64 PE exception tables use a different layout and are not read in this version."
                .to_string(),
        );
    }

    let is_dll = characteristics & 0x2000 != 0;
    let mut info: Vec<(String, String)> = Vec::new();
    info.push((
        "pe_kind".to_string(),
        if is64 { "PE32+".to_string() } else { "PE32".to_string() },
    ));
    info.push(("subsystem".to_string(), subsystem_name(subsystem)));
    info.push(("timestamp_raw".to_string(), format!("0x{:08x}", timestamp)));
    info.push(("characteristics".to_string(), format!("0x{:04x}", characteristics)));
    info.push(("dll_characteristics".to_string(), format!("0x{:04x}", dll_chars)));
    info.push(("size_of_image".to_string(), format!("0x{:x}", size_of_image)));
    info.push(("checksum".to_string(), format!("0x{:08x}", checksum)));
    if delay_count > 0 {
        info.push(("delay_imports".to_string(), format!("{} libraries", delay_count)));
    }
    if !known.is_empty() {
        info.push(("exception_table".to_string(), format!("{} function ranges", known.len())));
    }

    let arch_info = from_pe_machine(machine);
    let mut img = BinaryImage::new(
        FormatKind::Pe,
        format!(
            "{} {}",
            if is64 { "PE32+" } else { "PE32" },
            if is_dll { "DLL" } else { "executable" }
        ),
        arch_info,
    );
    img.image_base = image_base;
    img.entry_points = entry_points;
    img.sections = sections;
    img.regions = regions;
    img.code_regions = code_regions;
    img.symbols = symbols;
    img.imports = imports;
    img.libraries = libraries;
    img.known_functions = known;
    img.info = info;
    img.warnings = warnings;
    Ok(img)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::architecture::Arch;
    use crate::parser::MemSource;

    fn put16(v: &mut Vec<u8>, at: usize, x: u16) {
        v[at..at + 2].copy_from_slice(&x.to_le_bytes());
    }
    fn put32(v: &mut Vec<u8>, at: usize, x: u32) {
        v[at..at + 4].copy_from_slice(&x.to_le_bytes());
    }
    fn put64(v: &mut Vec<u8>, at: usize, x: u64) {
        v[at..at + 8].copy_from_slice(&x.to_le_bytes());
    }

    pub fn minimal_pe64() -> Vec<u8> {
        let mut v = vec![0u8; 0x400];
        v[0] = b'M';
        v[1] = b'Z';
        put32(&mut v, 0x3c, 0x40);
        v[0x40..0x44].copy_from_slice(b"PE\0\0");
        put16(&mut v, 0x44, 0x8664);
        put16(&mut v, 0x46, 1);
        put16(&mut v, 0x54, 0xf0);
        put16(&mut v, 0x56, 0x22);
        let opt = 0x58;
        put16(&mut v, opt, 0x20b);
        put32(&mut v, opt + 16, 0x1000);
        put64(&mut v, opt + 24, 0x1_4000_0000);
        put32(&mut v, opt + 32, 0x1000);
        put32(&mut v, opt + 36, 0x200);
        put32(&mut v, opt + 56, 0x2000);
        put32(&mut v, opt + 60, 0x200);
        put32(&mut v, opt + 108, 16);
        let sec = opt + 0xf0;
        v[sec..sec + 5].copy_from_slice(b".text");
        put32(&mut v, sec + 8, 0x100);
        put32(&mut v, sec + 12, 0x1000);
        put32(&mut v, sec + 16, 0x200);
        put32(&mut v, sec + 20, 0x200);
        put32(&mut v, sec + 36, 0x6000_0020);
        v
    }

    #[test]
    fn parses_minimal_pe64() {
        let src = MemSource::new(minimal_pe64());
        let img = parse(&src).unwrap();
        assert_eq!(img.arch.arch, Arch::X86_64);
        assert_eq!(img.image_base, 0x1_4000_0000);
        assert_eq!(img.sections.len(), 1);
        assert_eq!(img.sections[0].name, ".text");
        assert_eq!(img.sections[0].kind, SectionKind::Code);
        assert_eq!(img.code_regions.len(), 1);
        assert_eq!(img.code_regions[0].va, 0x1_4000_1000);
        assert_eq!(img.entry_points[0].va, 0x1_4000_1000);
        let map = img.address_map();
        assert_eq!(map.va_to_offset(0x1_4000_1010), Some(0x210));
    }

    #[test]
    fn truncated_pe_is_an_error_not_a_panic() {
        let mut data = minimal_pe64();
        data.truncate(0x100);
        let src = MemSource::new(data);
        assert!(parse(&src).is_err());
    }
}
