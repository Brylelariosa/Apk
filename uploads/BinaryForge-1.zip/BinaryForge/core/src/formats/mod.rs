//! Executable and container formats.
//!
//! `load_image` turns a file into a `BinaryImage`: a format-independent description of
//! sections, memory layout, symbols and entry points. Anything the file does not state
//! is left out or marked with a lower `Confidence`; nothing is invented.

pub mod elf;
pub mod pe;
mod raw;

use crate::architecture::{Arch, ArchInfo};
use crate::error::Result;
use crate::memory::{AddressMap, Region};
use crate::parser::{read_clamped, ByteSource};
use crate::types::{Confidence, Endian, Perms};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FormatKind {
    Elf,
    Pe,
    MachO,
    Iso9660,
    Zip,
    Gzip,
    Raw,
    Unknown,
}

impl FormatKind {
    pub fn key(self) -> &'static str {
        match self {
            FormatKind::Elf => "elf",
            FormatKind::Pe => "pe",
            FormatKind::MachO => "macho",
            FormatKind::Iso9660 => "iso9660",
            FormatKind::Zip => "zip",
            FormatKind::Gzip => "gzip",
            FormatKind::Raw => "raw",
            FormatKind::Unknown => "unknown",
        }
    }

    pub fn from_key(text: &str) -> Option<FormatKind> {
        match text.trim().to_ascii_lowercase().as_str() {
            "elf" => Some(FormatKind::Elf),
            "pe" => Some(FormatKind::Pe),
            "macho" => Some(FormatKind::MachO),
            "iso9660" | "iso" => Some(FormatKind::Iso9660),
            "zip" => Some(FormatKind::Zip),
            "gzip" => Some(FormatKind::Gzip),
            "raw" => Some(FormatKind::Raw),
            _ => None,
        }
    }

    pub fn title(self) -> &'static str {
        match self {
            FormatKind::Elf => "ELF",
            FormatKind::Pe => "PE/COFF",
            FormatKind::MachO => "Mach-O",
            FormatKind::Iso9660 => "ISO 9660 image",
            FormatKind::Zip => "ZIP archive",
            FormatKind::Gzip => "gzip stream",
            FormatKind::Raw => "raw binary",
            FormatKind::Unknown => "unrecognized binary",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SectionKind {
    Code,
    Data,
    Bss,
    Metadata,
    Debug,
    Unknown,
}

impl SectionKind {
    pub fn name(self) -> &'static str {
        match self {
            SectionKind::Code => "code",
            SectionKind::Data => "data",
            SectionKind::Bss => "bss",
            SectionKind::Metadata => "metadata",
            SectionKind::Debug => "debug",
            SectionKind::Unknown => "unknown",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SymKind {
    Func,
    Object,
    Notype,
    Tls,
    Other,
}

impl SymKind {
    pub fn name(self) -> &'static str {
        match self {
            SymKind::Func => "func",
            SymKind::Object => "object",
            SymKind::Notype => "notype",
            SymKind::Tls => "tls",
            SymKind::Other => "other",
        }
    }
}

#[derive(Clone, Debug)]
pub struct Section {
    pub index: u32,
    pub name: String,
    pub kind: SectionKind,
    pub va: u64,
    pub file_offset: u64,
    pub file_size: u64,
    pub mem_size: u64,
    pub perms: Perms,
    pub type_name: String,
    pub confidence: Confidence,
}

#[derive(Clone, Debug)]
pub struct Segment {
    pub kind: String,
    pub va: u64,
    pub file_offset: u64,
    pub file_size: u64,
    pub mem_size: u64,
    pub perms: Perms,
    pub align: u64,
}

#[derive(Clone, Debug)]
pub struct Symbol {
    pub name: String,
    pub va: u64,
    pub size: u64,
    pub kind: SymKind,
    pub global: bool,
    pub is_import: bool,
    pub is_export: bool,
    pub source: &'static str,
}

#[derive(Clone, Debug)]
pub struct Import {
    pub library: String,
    pub name: String,
    pub ordinal: Option<u32>,
    /// Address of the pointer slot the loader fills in (0 when the file does not say).
    pub slot_va: u64,
}

#[derive(Clone, Debug)]
pub struct EntryPoint {
    pub va: u64,
    pub name: String,
    pub kind: String,
    pub confidence: Confidence,
}

/// A range of file bytes that hold machine code.
#[derive(Clone, Debug)]
pub struct CodeRegion {
    pub name: String,
    pub va: u64,
    pub file_offset: u64,
    pub size: u64,
    pub confidence: Confidence,
}

/// A function range stated by the file itself (for example the PE exception table).
#[derive(Clone, Debug)]
pub struct KnownFunction {
    pub start: u64,
    pub end: u64,
    pub parent: Option<u64>,
}

#[derive(Clone, Debug)]
pub struct BinaryImage {
    pub format: FormatKind,
    pub format_name: String,
    pub format_confidence: Confidence,
    pub arch: ArchInfo,
    pub image_base: u64,
    pub entry_points: Vec<EntryPoint>,
    pub sections: Vec<Section>,
    pub segments: Vec<Segment>,
    pub regions: Vec<Region>,
    pub code_regions: Vec<CodeRegion>,
    pub symbols: Vec<Symbol>,
    pub imports: Vec<Import>,
    pub libraries: Vec<String>,
    /// Addresses inside code that the file stores as pointers (relocation targets).
    pub code_pointers: Vec<u64>,
    pub known_functions: Vec<KnownFunction>,
    pub info: Vec<(String, String)>,
    pub warnings: Vec<String>,
}

impl BinaryImage {
    pub fn new(format: FormatKind, format_name: String, arch: ArchInfo) -> BinaryImage {
        BinaryImage {
            format,
            format_name,
            format_confidence: Confidence::Verified,
            arch,
            image_base: 0,
            entry_points: Vec::new(),
            sections: Vec::new(),
            segments: Vec::new(),
            regions: Vec::new(),
            code_regions: Vec::new(),
            symbols: Vec::new(),
            imports: Vec::new(),
            libraries: Vec::new(),
            code_pointers: Vec::new(),
            known_functions: Vec::new(),
            info: Vec::new(),
            warnings: Vec::new(),
        }
    }

    pub fn address_map(&self) -> AddressMap {
        AddressMap::new(self.regions.clone())
    }

    pub fn in_code(&self, va: u64) -> bool {
        in_code_regions(&self.code_regions, va)
    }
}

pub fn in_code_regions(regions: &[CodeRegion], va: u64) -> bool {
    for r in regions {
        if va >= r.va && va - r.va < r.size {
            return true;
        }
    }
    false
}

/// User overrides for detection (manual format selection).
#[derive(Clone, Debug)]
pub struct ImageOptions {
    pub force_format: Option<FormatKind>,
    pub arch: Option<Arch>,
    pub endian: Option<Endian>,
    pub base_address: u64,
    pub entry_offset: Option<u64>,
}

impl Default for ImageOptions {
    fn default() -> ImageOptions {
        ImageOptions {
            force_format: None,
            arch: None,
            endian: None,
            base_address: 0,
            entry_offset: None,
        }
    }
}

/// Signature-based format detection. Never executes or modifies the file.
pub fn detect(src: &dyn ByteSource) -> Result<FormatKind> {
    let head = read_clamped(src, 0, 64)?;
    if head.len() >= 4 && head[0] == 0x7f && head[1] == b'E' && head[2] == b'L' && head[3] == b'F' {
        return Ok(FormatKind::Elf);
    }
    if head.len() >= 0x40 && head[0] == b'M' && head[1] == b'Z' {
        let e_lfanew = u32::from_le_bytes([head[0x3c], head[0x3d], head[0x3e], head[0x3f]]) as u64;
        let sig = read_clamped(src, e_lfanew, 4)?;
        if sig.len() == 4 && sig[0] == b'P' && sig[1] == b'E' && sig[2] == 0 && sig[3] == 0 {
            return Ok(FormatKind::Pe);
        }
        return Ok(FormatKind::Unknown);
    }
    if head.len() >= 4 {
        let m = [head[0], head[1], head[2], head[3]];
        if m == [0xfe, 0xed, 0xfa, 0xce]
            || m == [0xce, 0xfa, 0xed, 0xfe]
            || m == [0xfe, 0xed, 0xfa, 0xcf]
            || m == [0xcf, 0xfa, 0xed, 0xfe]
        {
            return Ok(FormatKind::MachO);
        }
        if m == [b'P', b'K', 3, 4] {
            return Ok(FormatKind::Zip);
        }
    }
    if head.len() >= 2 && head[0] == 0x1f && head[1] == 0x8b {
        return Ok(FormatKind::Gzip);
    }
    let iso = read_clamped(src, 0x8001, 5)?;
    if iso.as_slice() == b"CD001" {
        return Ok(FormatKind::Iso9660);
    }
    Ok(FormatKind::Unknown)
}

/// Detects the format (unless forced) and parses it. A failed ELF/PE parse of an
/// auto-detected file falls back to raw mode with a warning instead of failing.
pub fn load_image(src: &dyn ByteSource, opts: &ImageOptions) -> Result<BinaryImage> {
    let (kind, forced) = match opts.force_format {
        Some(k) => (k, true),
        None => (detect(src)?, false),
    };
    match kind {
        FormatKind::Elf => match elf::parse(src) {
            Ok(img) => Ok(img),
            Err(e) => {
                if forced {
                    Err(e)
                } else {
                    let mut img = raw::build(src, FormatKind::Elf, opts)?;
                    img.warnings
                        .insert(0, format!("The ELF parser failed ({}). The file is shown as raw data.", e));
                    Ok(img)
                }
            }
        },
        FormatKind::Pe => match pe::parse(src) {
            Ok(img) => Ok(img),
            Err(e) => {
                if forced {
                    Err(e)
                } else {
                    let mut img = raw::build(src, FormatKind::Pe, opts)?;
                    img.warnings
                        .insert(0, format!("The PE parser failed ({}). The file is shown as raw data.", e));
                    Ok(img)
                }
            }
        },
        other => raw::build(src, other, opts),
    }
}
