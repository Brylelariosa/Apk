//! ELF parser (32/64-bit, little/big endian).
//!
//! Works with or without section headers: stripped Android libraries often have none, in
//! which case the program headers and the dynamic segment are used instead and the result
//! is marked accordingly.

use std::collections::HashSet;

use crate::architecture::{from_elf_machine, Arch};
use crate::error::{Error, Result};
use crate::formats::{
    in_code_regions, BinaryImage, CodeRegion, EntryPoint, FormatKind, Import, Section,
    SectionKind, Segment, SymKind, Symbol,
};
use crate::memory::{AddressMap, Region};
use crate::parser::{read_clamped, read_cstr, read_vec, ByteSource, Bytes};
use crate::types::{Confidence, Endian, Perms};

const PT_LOAD: u32 = 1;
const PT_DYNAMIC: u32 = 2;
const PT_INTERP: u32 = 3;
const PT_NOTE: u32 = 4;

const SHT_SYMTAB: u32 = 2;
const SHT_STRTAB: u32 = 3;
const SHT_DYNAMIC: u32 = 6;
const SHT_NOBITS: u32 = 8;
const SHT_DYNSYM: u32 = 11;

const SHF_WRITE: u64 = 1;
const SHF_ALLOC: u64 = 2;
const SHF_EXECINSTR: u64 = 4;

const DT_NEEDED: u64 = 1;
const DT_PLTRELSZ: u64 = 2;
const DT_HASH: u64 = 4;
const DT_STRTAB: u64 = 5;
const DT_SYMTAB: u64 = 6;
const DT_RELA: u64 = 7;
const DT_RELASZ: u64 = 8;
const DT_STRSZ: u64 = 10;
const DT_SYMENT: u64 = 11;
const DT_INIT: u64 = 12;
const DT_FINI: u64 = 13;
const DT_SONAME: u64 = 14;
const DT_RPATH: u64 = 15;
const DT_REL: u64 = 17;
const DT_RELSZ: u64 = 18;
const DT_PLTREL: u64 = 20;
const DT_JMPREL: u64 = 23;
const DT_INIT_ARRAY: u64 = 25;
const DT_FINI_ARRAY: u64 = 26;
const DT_INIT_ARRAYSZ: u64 = 27;
const DT_FINI_ARRAYSZ: u64 = 28;
const DT_RUNPATH: u64 = 29;
const DT_RELR: u64 = 36;
const DT_ANDROID_REL: u64 = 0x6000_000f;
const DT_ANDROID_RELA: u64 = 0x6000_0011;
const DT_ANDROID_RELR: u64 = 0x6fff_e000;
const DT_GNU_HASH: u64 = 0x6fff_fef5;

const MAX_STRTAB: u64 = 128 * 1024 * 1024;
const MAX_SYMBOLS: u64 = 5_000_000;
const MAX_RELOCS: u64 = 8_000_000;

struct Phdr {
    kind: u32,
    flags: u32,
    offset: u64,
    vaddr: u64,
    filesz: u64,
    memsz: u64,
    align: u64,
}

struct Shdr {
    name_off: u32,
    kind: u32,
    flags: u64,
    addr: u64,
    offset: u64,
    size: u64,
    link: u32,
}

struct RawSym {
    name: String,
    value: u64,
    size: u64,
    info: u8,
    shndx: u16,
}

struct RawReloc {
    offset: u64,
    sym: u32,
    kind: u32,
    addend: Option<i64>,
}

struct RelocTypes {
    relative: u32,
    glob_dat: u32,
    jump_slot: u32,
    abs: u32,
}

fn reloc_types(arch: Arch) -> Option<RelocTypes> {
    match arch {
        Arch::X86_64 | Arch::X86 => Some(RelocTypes {
            relative: 8,
            glob_dat: 6,
            jump_slot: 7,
            abs: 1,
        }),
        Arch::Aarch64 => Some(RelocTypes {
            relative: 1027,
            glob_dat: 1025,
            jump_slot: 1026,
            abs: 257,
        }),
        Arch::Arm => Some(RelocTypes {
            relative: 23,
            glob_dat: 21,
            jump_slot: 22,
            abs: 2,
        }),
        _ => None,
    }
}

fn cstr_at(data: &[u8], at: usize) -> String {
    if at >= data.len() {
        return String::new();
    }
    let rest = &data[at..];
    let end = rest.iter().position(|&b| b == 0).unwrap_or(rest.len());
    String::from_utf8_lossy(&rest[..end]).into_owned()
}

fn parse_shdr(b: &Bytes, is64: bool) -> Result<Shdr> {
    if is64 {
        Ok(Shdr {
            name_off: b.u32(0)?,
            kind: b.u32(4)?,
            flags: b.u64(8)?,
            addr: b.u64(16)?,
            offset: b.u64(24)?,
            size: b.u64(32)?,
            link: b.u32(40)?,
        })
    } else {
        Ok(Shdr {
            name_off: b.u32(0)?,
            kind: b.u32(4)?,
            flags: b.u32(8)? as u64,
            addr: b.u32(12)? as u64,
            offset: b.u32(16)? as u64,
            size: b.u32(20)? as u64,
            link: b.u32(24)?,
        })
    }
}

fn parse_phdr(b: &Bytes, is64: bool) -> Result<Phdr> {
    if is64 {
        Ok(Phdr {
            kind: b.u32(0)?,
            flags: b.u32(4)?,
            offset: b.u64(8)?,
            vaddr: b.u64(16)?,
            filesz: b.u64(32)?,
            memsz: b.u64(40)?,
            align: b.u64(48)?,
        })
    } else {
        Ok(Phdr {
            kind: b.u32(0)?,
            offset: b.u32(4)? as u64,
            vaddr: b.u32(8)? as u64,
            filesz: b.u32(16)? as u64,
            memsz: b.u32(20)? as u64,
            flags: b.u32(24)?,
            align: b.u32(28)? as u64,
        })
    }
}

fn parse_sym(b: &Bytes, at: usize, is64: bool, strtab: &[u8]) -> Result<RawSym> {
    if is64 {
        let name_off = b.u32(at)? as usize;
        Ok(RawSym {
            name: cstr_at(strtab, name_off),
            info: b.u8(at + 4)?,
            shndx: b.u16(at + 6)?,
            value: b.u64(at + 8)?,
            size: b.u64(at + 16)?,
        })
    } else {
        let name_off = b.u32(at)? as usize;
        Ok(RawSym {
            name: cstr_at(strtab, name_off),
            value: b.u32(at + 4)? as u64,
            size: b.u32(at + 8)? as u64,
            info: b.u8(at + 12)?,
            shndx: b.u16(at + 14)?,
        })
    }
}

fn read_symbols(
    src: &dyn ByteSource,
    offset: u64,
    count: u64,
    strtab: &[u8],
    is64: bool,
    endian: Endian,
) -> Vec<RawSym> {
    let ent: u64 = if is64 { 24 } else { 16 };
    let avail = src.len().saturating_sub(offset) / ent;
    let total = count.min(avail).min(MAX_SYMBOLS);
    let mut out: Vec<RawSym> = Vec::new();
    let mut done: u64 = 0;
    while done < total {
        let n = (total - done).min(8192);
        let raw = match read_vec(src, offset + done * ent, n * ent) {
            Ok(r) => r,
            Err(_) => break,
        };
        let b = Bytes::new(&raw, endian);
        for i in 0..(n as usize) {
            if let Ok(s) = parse_sym(&b, i * (ent as usize), is64, strtab) {
                out.push(s);
            }
        }
        done += n;
    }
    out
}

fn parse_reloc(b: &Bytes, at: usize, is64: bool, is_rela: bool) -> Result<RawReloc> {
    if is64 {
        let r_offset = b.u64(at)?;
        let info = b.u64(at + 8)?;
        let addend = if is_rela { Some(b.u64(at + 16)? as i64) } else { None };
        Ok(RawReloc {
            offset: r_offset,
            sym: (info >> 32) as u32,
            kind: (info & 0xffff_ffff) as u32,
            addend,
        })
    } else {
        let r_offset = b.u32(at)? as u64;
        let info = b.u32(at + 4)?;
        let addend = if is_rela { Some(b.u32(at + 8)? as i32 as i64) } else { None };
        Ok(RawReloc {
            offset: r_offset,
            sym: info >> 8,
            kind: info & 0xff,
            addend,
        })
    }
}

fn read_relocs(
    src: &dyn ByteSource,
    offset: u64,
    size: u64,
    is_rela: bool,
    is64: bool,
    endian: Endian,
) -> Vec<RawReloc> {
    let ent: u64 = match (is64, is_rela) {
        (true, true) => 24,
        (true, false) => 16,
        (false, true) => 12,
        (false, false) => 8,
    };
    let avail = src.len().saturating_sub(offset);
    let total = (size.min(avail) / ent).min(MAX_RELOCS);
    let mut out: Vec<RawReloc> = Vec::new();
    let mut done: u64 = 0;
    while done < total {
        let n = (total - done).min(4096);
        let raw = match read_vec(src, offset + done * ent, n * ent) {
            Ok(r) => r,
            Err(_) => break,
        };
        let b = Bytes::new(&raw, endian);
        for i in 0..(n as usize) {
            let at = i * (ent as usize);
            let parsed = parse_reloc(&b, at, is64, is_rela);
            if let Ok(r) = parsed {
                out.push(r);
            }
        }
        done += n;
    }
    out
}

fn segment_name(kind: u32) -> String {
    let s = match kind {
        0 => "NULL",
        1 => "LOAD",
        2 => "DYNAMIC",
        3 => "INTERP",
        4 => "NOTE",
        5 => "SHLIB",
        6 => "PHDR",
        7 => "TLS",
        0x6474_e550 => "GNU_EH_FRAME",
        0x6474_e551 => "GNU_STACK",
        0x6474_e552 => "GNU_RELRO",
        0x6474_e553 => "GNU_PROPERTY",
        _ => return format!("0x{:x}", kind),
    };
    s.to_string()
}

fn section_type_name(kind: u32) -> String {
    let s = match kind {
        0 => "NULL",
        1 => "PROGBITS",
        2 => "SYMTAB",
        3 => "STRTAB",
        4 => "RELA",
        5 => "HASH",
        6 => "DYNAMIC",
        7 => "NOTE",
        8 => "NOBITS",
        9 => "REL",
        10 => "SHLIB",
        11 => "DYNSYM",
        14 => "INIT_ARRAY",
        15 => "FINI_ARRAY",
        16 => "PREINIT_ARRAY",
        17 => "GROUP",
        18 => "SYMTAB_SHNDX",
        0x6fff_fff6 => "GNU_HASH",
        0x6fff_fffd => "GNU_VERDEF",
        0x6fff_fffe => "GNU_VERNEED",
        0x6fff_ffff => "GNU_VERSYM",
        _ => return format!("0x{:x}", kind),
    };
    s.to_string()
}

fn classify_section(name: &str, sh: &Shdr) -> SectionKind {
    if name.starts_with(".debug") || name.starts_with(".zdebug") {
        return SectionKind::Debug;
    }
    if sh.flags & SHF_ALLOC != 0 {
        if sh.flags & SHF_EXECINSTR != 0 {
            SectionKind::Code
        } else if sh.kind == SHT_NOBITS {
            SectionKind::Bss
        } else {
            SectionKind::Data
        }
    } else {
        match sh.kind {
            2 | 3 | 4 | 5 | 7 | 9 | 11 | 0x6fff_fff6 | 0x6fff_fffd | 0x6fff_fffe | 0x6fff_ffff => {
                SectionKind::Metadata
            }
            _ => SectionKind::Unknown,
        }
    }
}

fn dyn_get(entries: &[(u64, u64)], tag: u64) -> Option<u64> {
    entries.iter().find(|e| e.0 == tag).map(|e| e.1)
}

/// Number of dynamic symbols according to DT_HASH (nchain).
fn hash_symbol_count(src: &dyn ByteSource, off: u64, endian: Endian) -> Option<u64> {
    let head = read_vec(src, off, 8).ok()?;
    let b = Bytes::new(&head, endian);
    b.u32(4).ok().map(|n| n as u64)
}

/// Number of dynamic symbols according to DT_GNU_HASH (walks the last bucket's chain).
fn gnu_hash_symbol_count(src: &dyn ByteSource, off: u64, is64: bool, endian: Endian) -> Option<u64> {
    let head = read_vec(src, off, 16).ok()?;
    let b = Bytes::new(&head, endian);
    let nbuckets = b.u32(0).ok()? as u64;
    let symoffset = b.u32(4).ok()? as u64;
    let bloom_size = b.u32(8).ok()? as u64;
    if nbuckets == 0 || nbuckets > 4_000_000 {
        return None;
    }
    let word: u64 = if is64 { 8 } else { 4 };
    let buckets_off = off.checked_add(16)?.checked_add(bloom_size.checked_mul(word)?)?;
    let buckets = read_vec(src, buckets_off, nbuckets * 4).ok()?;
    let bb = Bytes::new(&buckets, endian);
    let mut max: u64 = 0;
    for i in 0..(nbuckets as usize) {
        let v = bb.u32(i * 4).ok()? as u64;
        if v > max {
            max = v;
        }
    }
    if max < symoffset {
        return Some(symoffset);
    }
    let chain_off = buckets_off + nbuckets * 4;
    let mut idx = max - symoffset;
    let mut steps: u32 = 0;
    loop {
        let raw = read_vec(src, chain_off + idx * 4, 4).ok()?;
        let h = Bytes::new(&raw, endian).u32(0).ok()?;
        if h & 1 == 1 {
            return Some(symoffset + idx + 1);
        }
        idx += 1;
        steps += 1;
        if steps > 1_000_000 {
            return None;
        }
    }
}

fn find_build_id(data: &[u8], endian: Endian) -> Option<String> {
    let b = Bytes::new(data, endian);
    let mut at: usize = 0;
    while at + 12 <= data.len() {
        let namesz = b.u32(at).ok()? as usize;
        let descsz = b.u32(at + 4).ok()? as usize;
        let ntype = b.u32(at + 8).ok()?;
        let name_at = at + 12;
        let desc_at = name_at.checked_add((namesz + 3) & !3)?;
        let end = desc_at.checked_add((descsz + 3) & !3)?;
        if end > data.len() + 3 {
            return None;
        }
        if ntype == 3 && namesz >= 3 && descsz > 0 && descsz <= 64 && desc_at + descsz <= data.len() {
            if &data[name_at..name_at + 3] == b"GNU" {
                return Some(crate::util::hex::hex_bytes(&data[desc_at..desc_at + descsz]));
            }
        }
        at = end;
    }
    None
}

pub fn parse(src: &dyn ByteSource) -> Result<BinaryImage> {
    let total_size = src.len();
    let ident = read_vec(src, 0, 16)?;
    if ident[0] != 0x7f || ident[1] != b'E' || ident[2] != b'L' || ident[3] != b'F' {
        return Err(Error::Malformed("missing ELF magic".to_string()));
    }
    let is64 = match ident[4] {
        1 => false,
        2 => true,
        other => return Err(Error::Malformed(format!("invalid ELF class {}", other))),
    };
    let endian = match ident[5] {
        1 => Endian::Little,
        2 => Endian::Big,
        other => {
            return Err(Error::Malformed(format!(
                "invalid ELF data encoding {}",
                other
            )))
        }
    };
    let os_abi = ident[7];
    let hdr_len: u64 = if is64 { 64 } else { 52 };
    let hdr = read_vec(src, 0, hdr_len)?;
    let h = Bytes::new(&hdr, endian);
    let e_type = h.u16(16)?;
    let e_machine = h.u16(18)?;
    let (e_entry, e_phoff, e_shoff, e_flags, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) =
        if is64 {
            (
                h.u64(24)?,
                h.u64(32)?,
                h.u64(40)?,
                h.u32(48)?,
                h.u16(54)?,
                h.u16(56)?,
                h.u16(58)?,
                h.u16(60)?,
                h.u16(62)?,
            )
        } else {
            (
                h.u32(24)? as u64,
                h.u32(28)? as u64,
                h.u32(32)? as u64,
                h.u32(36)?,
                h.u16(42)?,
                h.u16(44)?,
                h.u16(46)?,
                h.u16(48)?,
                h.u16(50)?,
            )
        };

    let arch_info = from_elf_machine(e_machine, is64, endian);
    let arch = arch_info.arch;
    let mut warnings: Vec<String> = Vec::new();

    // ---- program headers -------------------------------------------------------------
    let mut phdrs: Vec<Phdr> = Vec::new();
    let min_ph: u64 = if is64 { 56 } else { 32 };
    if e_phoff != 0 && e_phnum > 0 {
        if (e_phentsize as u64) < min_ph {
            warnings.push(format!(
                "Program header entry size {} is smaller than the ELF minimum {}.",
                e_phentsize, min_ph
            ));
        } else {
            let ent = e_phentsize as usize;
            let total = e_phentsize as u64 * e_phnum as u64;
            match read_vec(src, e_phoff, total) {
                Ok(raw) => {
                    for i in 0..(e_phnum as usize) {
                        let start = i * ent;
                        let b = Bytes::new(&raw[start..start + ent], endian);
                        match parse_phdr(&b, is64) {
                            Ok(p) => phdrs.push(p),
                            Err(e) => warnings.push(format!("Program header {} is unreadable: {}.", i, e)),
                        }
                    }
                }
                Err(e) => warnings.push(format!("The program header table is unreadable: {}.", e)),
            }
        }
    }

    // ---- section headers -------------------------------------------------------------
    let mut shdrs: Vec<Shdr> = Vec::new();
    let min_sh: u64 = if is64 { 64 } else { 40 };
    let mut shnum = e_shnum as u64;
    let mut shstrndx = e_shstrndx as u32;
    if e_shoff != 0 && (e_shentsize as u64) >= min_sh {
        if shnum == 0 || shstrndx == 0xffff {
            if let Ok(first_raw) = read_vec(src, e_shoff, min_sh) {
                if let Ok(first) = parse_shdr(&Bytes::new(&first_raw, endian), is64) {
                    if shnum == 0 {
                        shnum = first.size;
                    }
                    if shstrndx == 0xffff {
                        shstrndx = first.link;
                    }
                }
            }
        }
        if shnum > 0 {
            let table_len = shnum.checked_mul(e_shentsize as u64);
            match table_len {
                Some(len) if e_shoff.checked_add(len).map_or(false, |end| end <= total_size) => {
                    match read_vec(src, e_shoff, len) {
                        Ok(raw) => {
                            let ent = e_shentsize as usize;
                            for i in 0..(shnum as usize) {
                                let start = i * ent;
                                let b = Bytes::new(&raw[start..start + ent], endian);
                                match parse_shdr(&b, is64) {
                                    Ok(s) => shdrs.push(s),
                                    Err(e) => {
                                        warnings.push(format!("Section header {} is unreadable: {}.", i, e));
                                        break;
                                    }
                                }
                            }
                        }
                        Err(e) => warnings.push(format!("The section header table is unreadable: {}.", e)),
                    }
                }
                _ => warnings.push(
                    "The section header table lies outside the file (stripped or truncated file)."
                        .to_string(),
                ),
            }
        }
    }
    let has_sections = !shdrs.is_empty();
    if !has_sections && e_type != 1 {
        warnings.push(
            "No section headers: sections are unavailable and the analysis uses the program headers only."
                .to_string(),
        );
    }

    let shstr: Vec<u8> = match shdrs.get(shstrndx as usize) {
        Some(s) if s.kind != SHT_NOBITS => read_clamped(src, s.offset, s.size.min(16 * 1024 * 1024))?,
        _ => Vec::new(),
    };

    // ---- segments and memory layout ---------------------------------------------------
    let mut regions: Vec<Region> = Vec::new();
    let mut segments: Vec<Segment> = Vec::new();
    let mut load_index = 0u32;
    for ph in &phdrs {
        let perms = Perms::new(ph.flags & 4 != 0, ph.flags & 2 != 0, ph.flags & 1 != 0);
        segments.push(Segment {
            kind: segment_name(ph.kind),
            va: ph.vaddr,
            file_offset: ph.offset,
            file_size: ph.filesz,
            mem_size: ph.memsz,
            perms,
            align: ph.align,
        });
        if ph.kind == PT_LOAD && ph.memsz > 0 {
            let mut file_size = ph.filesz.min(ph.memsz);
            let avail = total_size.saturating_sub(ph.offset);
            if file_size > avail {
                warnings.push(format!(
                    "LOAD segment {} extends past the end of the file (truncated file?).",
                    load_index
                ));
                file_size = avail;
            }
            regions.push(Region {
                name: format!("LOAD#{}", load_index),
                va: ph.vaddr,
                mem_size: ph.memsz,
                file_offset: ph.offset,
                file_size,
                perms,
            });
            load_index += 1;
        }
    }

    // ---- sections ---------------------------------------------------------------------
    let mut sections: Vec<Section> = Vec::new();
    let mut section_problems = 0u32;
    for (i, sh) in shdrs.iter().enumerate() {
        if i == 0 && sh.kind == 0 {
            continue;
        }
        if sh.kind == 0 {
            continue;
        }
        let name = cstr_at(&shstr, sh.name_off as usize);
        let kind = classify_section(&name, sh);
        let alloc = sh.flags & SHF_ALLOC != 0;
        let mut file_size = if sh.kind == SHT_NOBITS { 0 } else { sh.size };
        let mut confidence = Confidence::Verified;
        if file_size > 0 && sh.offset.checked_add(file_size).map_or(true, |end| end > total_size) {
            section_problems += 1;
            confidence = Confidence::Estimated;
            file_size = total_size.saturating_sub(sh.offset).min(file_size);
        }
        sections.push(Section {
            index: i as u32,
            name,
            kind,
            va: if alloc { sh.addr } else { 0 },
            file_offset: sh.offset,
            file_size,
            mem_size: sh.size,
            perms: Perms::new(alloc, sh.flags & SHF_WRITE != 0, sh.flags & SHF_EXECINSTR != 0),
            type_name: section_type_name(sh.kind),
            confidence,
        });
    }
    if section_problems > 0 {
        warnings.push(format!(
            "{} section(s) extend past the end of the file; their sizes were clamped.",
            section_problems
        ));
    }

    if regions.is_empty() {
        if e_type == 1 {
            warnings.push(
                "Relocatable object (ET_REL): it has no load addresses, so disassembly and function analysis are disabled. The sections and the hex view remain available."
                    .to_string(),
            );
        } else {
            for s in &sections {
                if s.perms.read && s.va != 0 && s.mem_size > 0 {
                    regions.push(Region {
                        name: s.name.clone(),
                        va: s.va,
                        mem_size: s.mem_size,
                        file_offset: s.file_offset,
                        file_size: s.file_size.min(s.mem_size),
                        perms: s.perms,
                    });
                }
            }
            if !regions.is_empty() {
                warnings.push(
                    "No LOAD segments: the memory layout was rebuilt from the sections.".to_string(),
                );
            }
        }
    }

    // ---- code regions -----------------------------------------------------------------
    let mut code_regions: Vec<CodeRegion> = Vec::new();
    if e_type != 1 {
        for s in &sections {
            if s.kind == SectionKind::Code && s.file_size > 0 && s.va != 0 {
                code_regions.push(CodeRegion {
                    name: s.name.clone(),
                    va: s.va,
                    file_offset: s.file_offset,
                    size: s.file_size,
                    confidence: Confidence::Verified,
                });
            }
        }
        if code_regions.is_empty() {
            for r in &regions {
                if r.perms.exec && r.file_size > 0 {
                    code_regions.push(CodeRegion {
                        name: format!("{} (executable segment)", r.name),
                        va: r.va,
                        file_offset: r.file_offset,
                        size: r.file_size,
                        confidence: Confidence::Estimated,
                    });
                }
            }
            if !code_regions.is_empty() {
                warnings.push(
                    "Code regions were taken from executable segments, so they may include non-code bytes."
                        .to_string(),
                );
            }
        }
    }

    let map = AddressMap::new(regions.clone());

    // ---- dynamic segment --------------------------------------------------------------
    let mut dyn_entries: Vec<(u64, u64)> = Vec::new();
    let mut dyn_loc: Option<(u64, u64)> = None;
    for p in &phdrs {
        if p.kind == PT_DYNAMIC {
            dyn_loc = Some((p.offset, p.filesz));
            break;
        }
    }
    if dyn_loc.is_none() {
        for s in &shdrs {
            if s.kind == SHT_DYNAMIC {
                dyn_loc = Some((s.offset, s.size));
                break;
            }
        }
    }
    if let Some((off, size)) = dyn_loc {
        let raw = read_clamped(src, off, size.min(4 * 1024 * 1024))?;
        let ent: usize = if is64 { 16 } else { 8 };
        let b = Bytes::new(&raw, endian);
        let mut at = 0usize;
        while at + ent <= raw.len() {
            let tag = b.word(at, is64)?;
            let val = b.word(at + ent / 2, is64)?;
            if tag == 0 {
                break;
            }
            dyn_entries.push((tag, val));
            at += ent;
        }
    }

    let mut dynstr: Vec<u8> = Vec::new();
    if let (Some(strtab_va), Some(strsz)) = (dyn_get(&dyn_entries, DT_STRTAB), dyn_get(&dyn_entries, DT_STRSZ)) {
        if let Some(off) = map.va_to_offset(strtab_va) {
            dynstr = read_clamped(src, off, strsz.min(MAX_STRTAB))?;
        }
    }

    let mut libraries: Vec<String> = Vec::new();
    let mut info: Vec<(String, String)> = Vec::new();
    for e in &dyn_entries {
        match e.0 {
            DT_NEEDED => libraries.push(cstr_at(&dynstr, e.1 as usize)),
            DT_SONAME => info.push(("soname".to_string(), cstr_at(&dynstr, e.1 as usize))),
            DT_RPATH => info.push(("rpath".to_string(), cstr_at(&dynstr, e.1 as usize))),
            DT_RUNPATH => info.push(("runpath".to_string(), cstr_at(&dynstr, e.1 as usize))),
            _ => {}
        }
    }
    let packed_relocs = dyn_get(&dyn_entries, DT_ANDROID_REL).is_some()
        || dyn_get(&dyn_entries, DT_ANDROID_RELA).is_some()
        || dyn_get(&dyn_entries, DT_RELR).is_some()
        || dyn_get(&dyn_entries, DT_ANDROID_RELR).is_some();
    if packed_relocs {
        warnings.push(
            "This file uses packed relocations (Android APS2/RELR). They are not decoded in this version, so function-pointer discovery from relocations is incomplete."
                .to_string(),
        );
    }

    // ---- symbols ----------------------------------------------------------------------
    let mut symtab_raw: Vec<RawSym> = Vec::new();
    let mut dynsym_raw: Vec<RawSym> = Vec::new();
    let ent_sym: u64 = if is64 { 24 } else { 16 };
    let mut has_symtab = false;
    for sh in &shdrs {
        if sh.kind != SHT_SYMTAB && sh.kind != SHT_DYNSYM {
            continue;
        }
        let strtab: Vec<u8> = match shdrs.get(sh.link as usize) {
            Some(st) if st.kind == SHT_STRTAB => read_clamped(src, st.offset, st.size.min(MAX_STRTAB))?,
            _ => Vec::new(),
        };
        let list = read_symbols(src, sh.offset, sh.size / ent_sym, &strtab, is64, endian);
        if sh.kind == SHT_SYMTAB {
            has_symtab = true;
            symtab_raw = list;
        } else {
            dynsym_raw = list;
        }
    }
    if dynsym_raw.is_empty() {
        if let Some(symtab_va) = dyn_get(&dyn_entries, DT_SYMTAB) {
            let syment = dyn_get(&dyn_entries, DT_SYMENT).unwrap_or(ent_sym);
            if syment == ent_sym {
                let mut count: Option<u64> = None;
                if let Some(hv) = dyn_get(&dyn_entries, DT_HASH) {
                    if let Some(off) = map.va_to_offset(hv) {
                        count = hash_symbol_count(src, off, endian);
                    }
                }
                if count.is_none() {
                    if let Some(gv) = dyn_get(&dyn_entries, DT_GNU_HASH) {
                        if let Some(off) = map.va_to_offset(gv) {
                            count = gnu_hash_symbol_count(src, off, is64, endian);
                        }
                    }
                }
                match (count, map.va_to_offset(symtab_va)) {
                    (Some(n), Some(off)) => {
                        dynsym_raw = read_symbols(src, off, n, &dynstr, is64, endian);
                    }
                    _ => warnings.push(
                        "The dynamic symbol table could not be located (no usable hash table)."
                            .to_string(),
                    ),
                }
            }
        }
    }

    let mut symbols: Vec<Symbol> = Vec::new();
    let mut seen: HashSet<(String, u64)> = HashSet::new();
    for (list, is_dyn) in [(&symtab_raw, false), (&dynsym_raw, true)] {
        for r in list.iter() {
            let typ = r.info & 0x0f;
            let bind = r.info >> 4;
            if r.name.is_empty() || typ == 3 || typ == 4 {
                continue;
            }
            let defined = r.shndx != 0;
            let key = (r.name.clone(), r.value);
            if !seen.insert(key) {
                continue;
            }
            let kind = match typ {
                0 => SymKind::Notype,
                1 => SymKind::Object,
                2 | 10 => SymKind::Func,
                6 => SymKind::Tls,
                _ => SymKind::Other,
            };
            symbols.push(Symbol {
                name: r.name.clone(),
                va: r.value,
                size: r.size,
                kind,
                global: bind == 1 || bind == 2,
                is_import: !defined,
                is_export: is_dyn && defined && (bind == 1 || bind == 2),
                source: if is_dyn { "dynsym" } else { "symtab" },
            });
        }
    }

    // ---- relocations: import slots and function pointers ------------------------------
    let mut imports: Vec<Import> = Vec::new();
    let mut code_pointers: Vec<u64> = Vec::new();
    let mut entry_points: Vec<EntryPoint> = Vec::new();
    let init_array = dyn_get(&dyn_entries, DT_INIT_ARRAY).zip(dyn_get(&dyn_entries, DT_INIT_ARRAYSZ));
    let fini_array = dyn_get(&dyn_entries, DT_FINI_ARRAY).zip(dyn_get(&dyn_entries, DT_FINI_ARRAYSZ));
    let ptr_size: u64 = if is64 { 8 } else { 4 };

    if let Some(types) = reloc_types(arch) {
        let mut tables: Vec<(u64, u64, bool)> = Vec::new();
        if let (Some(va), Some(sz)) = (dyn_get(&dyn_entries, DT_RELA), dyn_get(&dyn_entries, DT_RELASZ)) {
            tables.push((va, sz, true));
        }
        if let (Some(va), Some(sz)) = (dyn_get(&dyn_entries, DT_REL), dyn_get(&dyn_entries, DT_RELSZ)) {
            tables.push((va, sz, false));
        }
        if let (Some(va), Some(sz)) = (dyn_get(&dyn_entries, DT_JMPREL), dyn_get(&dyn_entries, DT_PLTRELSZ)) {
            let rela = match dyn_get(&dyn_entries, DT_PLTREL) {
                Some(7) => true,
                Some(_) => false,
                None => is64,
            };
            tables.push((va, sz, rela));
        }
        let mut imported_with_slot: HashSet<String> = HashSet::new();
        for (va, sz, rela) in tables {
            let off = match map.va_to_offset(va) {
                Some(o) => o,
                None => continue,
            };
            let relocs = read_relocs(src, off, sz, rela, is64, endian);
            for r in relocs.iter() {
                if r.kind == types.relative {
                    let target: Option<u64> = match r.addend {
                        Some(a) => Some(a as u64),
                        None => match map.va_to_offset(r.offset) {
                            Some(o) => read_vec(src, o, ptr_size)
                                .ok()
                                .and_then(|raw| Bytes::new(&raw, endian).word(0, is64).ok()),
                            None => None,
                        },
                    };
                    if let Some(t) = target {
                        if in_code_regions(&code_regions, t) {
                            code_pointers.push(t);
                            let in_init = match init_array {
                                Some((ia, isz)) => r.offset >= ia && r.offset - ia < isz,
                                None => false,
                            };
                            if in_init {
                                let idx = (r.offset - init_array.map_or(0, |x| x.0)) / ptr_size;
                                entry_points.push(EntryPoint {
                                    va: t,
                                    name: format!("init_array[{}]", idx),
                                    kind: "init_array".to_string(),
                                    confidence: Confidence::Verified,
                                });
                            }
                            let in_fini = match fini_array {
                                Some((fa, fsz)) => r.offset >= fa && r.offset - fa < fsz,
                                None => false,
                            };
                            if in_fini {
                                let idx = (r.offset - fini_array.map_or(0, |x| x.0)) / ptr_size;
                                entry_points.push(EntryPoint {
                                    va: t,
                                    name: format!("fini_array[{}]", idx),
                                    kind: "fini_array".to_string(),
                                    confidence: Confidence::Verified,
                                });
                            }
                        }
                    }
                } else if r.kind == types.glob_dat || r.kind == types.jump_slot || r.kind == types.abs {
                    if r.sym != 0 {
                        if let Some(s) = dynsym_raw.get(r.sym as usize) {
                            if s.shndx == 0 && !s.name.is_empty() {
                                imports.push(Import {
                                    library: String::new(),
                                    name: s.name.clone(),
                                    ordinal: None,
                                    slot_va: r.offset,
                                });
                                imported_with_slot.insert(s.name.clone());
                            }
                        }
                    }
                }
            }
        }
        for s in &symbols {
            if s.is_import && !imported_with_slot.contains(&s.name) {
                imports.push(Import {
                    library: String::new(),
                    name: s.name.clone(),
                    ordinal: None,
                    slot_va: 0,
                });
            }
        }
    } else {
        for s in &symbols {
            if s.is_import {
                imports.push(Import {
                    library: String::new(),
                    name: s.name.clone(),
                    ordinal: None,
                    slot_va: 0,
                });
            }
        }
    }

    // ---- entry points -----------------------------------------------------------------
    if e_entry != 0 {
        entry_points.insert(
            0,
            EntryPoint {
                va: e_entry,
                name: "e_entry".to_string(),
                kind: "entry".to_string(),
                confidence: Confidence::Verified,
            },
        );
    }
    if let Some(va) = dyn_get(&dyn_entries, DT_INIT) {
        entry_points.push(EntryPoint {
            va,
            name: "DT_INIT".to_string(),
            kind: "init".to_string(),
            confidence: Confidence::Verified,
        });
    }
    if let Some(va) = dyn_get(&dyn_entries, DT_FINI) {
        entry_points.push(EntryPoint {
            va,
            name: "DT_FINI".to_string(),
            kind: "fini".to_string(),
            confidence: Confidence::Verified,
        });
    }
    // Array entries stored in place (not relocated), e.g. statically linked executables.
    for (label, arr) in [("init_array", init_array), ("fini_array", fini_array)] {
        if let Some((va, size)) = arr {
            if let Some(off) = map.va_to_offset(va) {
                let n = (size / ptr_size).min(4096);
                if let Ok(raw) = read_vec(src, off, n * ptr_size) {
                    let b = Bytes::new(&raw, endian);
                    for i in 0..(n as usize) {
                        if let Ok(v) = b.word(i * (ptr_size as usize), is64) {
                            if v != 0 && in_code_regions(&code_regions, v) {
                                let dup = entry_points.iter().any(|e| e.va == v && e.kind == label);
                                if !dup {
                                    entry_points.push(EntryPoint {
                                        va: v,
                                        name: format!("{}[{}]", label, i),
                                        kind: label.to_string(),
                                        confidence: Confidence::Verified,
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- descriptive metadata ---------------------------------------------------------
    let (type_short, type_long) = match e_type {
        1 => ("relocatable object", "ET_REL (relocatable)"),
        2 => ("executable", "ET_EXEC (executable)"),
        3 => ("shared object", "ET_DYN (shared object or PIE)"),
        4 => ("core dump", "ET_CORE (core dump)"),
        _ => ("file", "unknown type"),
    };
    let mut meta: Vec<(String, String)> = Vec::new();
    meta.push(("elf_type".to_string(), type_long.to_string()));
    meta.push(("os_abi".to_string(), format!("{}", os_abi)));
    meta.push(("flags".to_string(), format!("0x{:x}", e_flags)));
    for p in &phdrs {
        if p.kind == PT_INTERP {
            if let Ok(s) = read_cstr(src, p.offset, 256) {
                meta.push(("interpreter".to_string(), s));
            }
        }
    }
    let mut build_id: Option<String> = None;
    for p in &phdrs {
        if p.kind == PT_NOTE && build_id.is_none() {
            if let Ok(raw) = read_clamped(src, p.offset, p.filesz.min(4096)) {
                build_id = find_build_id(&raw, endian);
            }
        }
    }
    if let Some(id) = build_id {
        meta.push(("build_id".to_string(), id));
    }
    if has_sections {
        meta.push((
            "symbols".to_string(),
            if has_symtab {
                ".symtab present".to_string()
            } else {
                "stripped (no .symtab)".to_string()
            },
        ));
        let dwarf = sections.iter().any(|s| s.name == ".debug_info");
        meta.push((
            "debug_info".to_string(),
            if dwarf { "DWARF present".to_string() } else { "none".to_string() },
        ));
    }
    meta.extend(info);

    let mut image_base = u64::MAX;
    for r in &regions {
        if r.va < image_base {
            image_base = r.va;
        }
    }
    if image_base == u64::MAX {
        image_base = 0;
    }

    let mut img = BinaryImage::new(
        FormatKind::Elf,
        format!("ELF{} {}", if is64 { 64 } else { 32 }, type_short),
        arch_info,
    );
    img.image_base = image_base;
    img.entry_points = entry_points;
    img.sections = sections;
    img.segments = segments;
    img.regions = regions;
    img.code_regions = code_regions;
    img.symbols = symbols;
    img.imports = imports;
    img.libraries = libraries;
    img.code_pointers = code_pointers;
    img.info = meta;
    img.warnings = warnings;
    Ok(img)
}
