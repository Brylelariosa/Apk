//! Fallback for files without a parsed executable header (BIN, RAW, DAT, images, ...).
//!
//! The whole file is presented as one region. The architecture comes from the user, or from
//! a pattern heuristic that is reported as `Estimated`.

use crate::architecture::{guess_raw, Arch, ArchInfo};
use crate::error::Result;
use crate::formats::{
    BinaryImage, CodeRegion, EntryPoint, FormatKind, ImageOptions, Section, SectionKind,
};
use crate::memory::Region;
use crate::parser::ByteSource;
use crate::types::{Confidence, Endian, Perms};

pub fn build(src: &dyn ByteSource, kind: FormatKind, opts: &ImageOptions) -> Result<BinaryImage> {
    let size = src.len();
    let mut warnings: Vec<String> = Vec::new();

    let arch: ArchInfo = match opts.arch {
        Some(a) => ArchInfo {
            arch: a,
            endian: opts.endian.unwrap_or(Endian::Little),
            bits: a.pointer_bits(),
            confidence: Confidence::Assumed,
            evidence: "selected manually".to_string(),
        },
        None => guess_raw(src)?,
    };

    match kind {
        FormatKind::Raw | FormatKind::Unknown => {
            warnings.push(
                "No known executable header was found. The whole file is treated as raw data."
                    .to_string(),
            );
        }
        other => {
            warnings.push(format!(
                "{} was recognized, but this version has no parser for it. The file is shown as raw data.",
                other.title()
            ));
        }
    }
    if arch.arch == Arch::Unknown {
        warnings.push(
            "The CPU architecture could not be determined. Choose one manually to enable disassembly."
                .to_string(),
        );
    } else if arch.confidence == Confidence::Estimated {
        warnings.push(
            "The architecture is estimated from code patterns. Verify it before relying on the disassembly."
                .to_string(),
        );
    }

    let name = match kind {
        FormatKind::Raw | FormatKind::Unknown => "Raw binary".to_string(),
        other => format!("{} (raw view)", other.title()),
    };
    let mut img = BinaryImage::new(kind, name, arch);
    img.format_confidence = if kind == FormatKind::Raw || kind == FormatKind::Unknown {
        Confidence::Unknown
    } else {
        Confidence::Verified
    };
    img.image_base = opts.base_address;
    img.warnings = warnings;

    img.regions.push(Region {
        name: "raw".to_string(),
        va: opts.base_address,
        mem_size: size,
        file_offset: 0,
        file_size: size,
        perms: Perms::new(true, false, true),
    });
    img.sections.push(Section {
        index: 0,
        name: "raw".to_string(),
        kind: SectionKind::Unknown,
        va: opts.base_address,
        file_offset: 0,
        file_size: size,
        mem_size: size,
        perms: Perms::new(true, false, false),
        type_name: "RAW".to_string(),
        confidence: Confidence::Unknown,
    });

    if img.arch.arch != Arch::Unknown && size > 0 {
        img.code_regions.push(CodeRegion {
            name: "raw (assumed code)".to_string(),
            va: opts.base_address,
            file_offset: 0,
            size,
            confidence: Confidence::Assumed,
        });
    }
    if let Some(off) = opts.entry_offset {
        img.entry_points.push(EntryPoint {
            va: opts.base_address.wrapping_add(off),
            name: "entry (user supplied)".to_string(),
            kind: "entry".to_string(),
            confidence: Confidence::Assumed,
        });
    }
    Ok(img)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::MemSource;

    #[test]
    fn raw_image_uses_manual_architecture() {
        let src = MemSource::new(vec![0u8; 64]);
        let opts = ImageOptions {
            arch: Some(Arch::Aarch64),
            base_address: 0x1000,
            entry_offset: Some(8),
            ..ImageOptions::default()
        };
        let img = build(&src, FormatKind::Raw, &opts).unwrap();
        assert_eq!(img.arch.arch, Arch::Aarch64);
        assert_eq!(img.arch.confidence, Confidence::Assumed);
        assert_eq!(img.entry_points[0].va, 0x1008);
        assert_eq!(img.code_regions.len(), 1);
        assert!(img.address_map().contains(0x1020));
    }
}
