//! Function discovery.
//!
//! Function starts come from, in order of strength: exact ranges in the file (PE exception
//! table), symbols with a size, entry points, other symbols, pointers stored by relocations,
//! and direct call targets seen during the sweep. Every function records where it came from
//! and whether its end is exact or estimated.

use std::collections::BTreeMap;

use crate::formats::{BinaryImage, SymKind};
use crate::types::Confidence;

#[derive(Clone, Debug)]
pub struct Function {
    pub id: u32,
    pub start: u64,
    pub end: u64,
    pub name: String,
    /// True when the name comes from the file (symbol or export).
    pub named: bool,
    pub source: &'static str,
    /// Confidence that a function starts here.
    pub confidence: Confidence,
    /// "symbol-size", "exception-table" (exact) or "estimated".
    pub bounds: &'static str,
    /// For exception-table fragments: the function this chunk belongs to.
    pub parent: Option<u64>,
}

impl Function {
    pub fn size(&self) -> u64 {
        self.end.saturating_sub(self.start)
    }

    pub fn bounds_confidence(&self) -> Confidence {
        if self.bounds == "estimated" {
            Confidence::Estimated
        } else {
            Confidence::Verified
        }
    }
}

struct Seed {
    source: &'static str,
    confidence: Confidence,
    /// Lower is stronger.
    rank: u8,
    size: Option<u64>,
    end: Option<u64>,
    name: Option<String>,
    parent: Option<u64>,
}

fn add_seed(seeds: &mut BTreeMap<u64, Seed>, addr: u64, seed: Seed) {
    match seeds.remove(&addr) {
        Some(old) => {
            let (mut strong, weak) = if seed.rank < old.rank { (seed, old) } else { (old, seed) };
            if strong.name.is_none() {
                strong.name = weak.name;
            }
            if strong.end.is_none() && strong.size.is_none() {
                strong.end = weak.end;
                strong.size = weak.size;
            }
            if strong.parent.is_none() {
                strong.parent = weak.parent;
            }
            seeds.insert(addr, strong);
        }
        None => {
            seeds.insert(addr, seed);
        }
    }
}

fn region_end(image: &BinaryImage, va: u64) -> u64 {
    for r in &image.code_regions {
        if va >= r.va && va - r.va < r.size {
            return r.va + r.size;
        }
    }
    va
}

/// Builds the function list (sorted by start address).
pub fn discover(image: &BinaryImage, call_targets: &[u64]) -> Vec<Function> {
    let mut seeds: BTreeMap<u64, Seed> = BTreeMap::new();

    for k in &image.known_functions {
        if !image.in_code(k.start) {
            continue;
        }
        add_seed(
            &mut seeds,
            k.start,
            Seed {
                source: if k.parent.is_some() { "exception-table fragment" } else { "exception-table" },
                confidence: Confidence::Verified,
                rank: 0,
                size: None,
                end: Some(k.end),
                name: None,
                parent: k.parent,
            },
        );
    }

    for s in &image.symbols {
        if s.is_import || s.kind != SymKind::Func || s.va == 0 || !image.in_code(s.va) {
            continue;
        }
        let size = if s.size > 0 { Some(s.size) } else { None };
        add_seed(
            &mut seeds,
            s.va,
            Seed {
                source: if s.is_export { "export" } else { "symbol" },
                confidence: Confidence::Verified,
                rank: if size.is_some() { 1 } else { 3 },
                size,
                end: None,
                name: Some(s.name.clone()),
                parent: None,
            },
        );
    }

    for e in &image.entry_points {
        if !image.in_code(e.va) {
            continue;
        }
        add_seed(
            &mut seeds,
            e.va,
            Seed {
                source: "entry point",
                confidence: e.confidence,
                rank: 2,
                size: None,
                end: None,
                name: Some(e.name.clone()),
                parent: None,
            },
        );
    }

    for &p in &image.code_pointers {
        add_seed(
            &mut seeds,
            p,
            Seed {
                source: "relocation pointer",
                confidence: Confidence::Likely,
                rank: 5,
                size: None,
                end: None,
                name: None,
                parent: None,
            },
        );
    }

    let mut targets: Vec<u64> = call_targets.to_vec();
    targets.sort_unstable();
    targets.dedup();
    for t in targets {
        if !image.in_code(t) {
            continue;
        }
        add_seed(
            &mut seeds,
            t,
            Seed {
                source: "call target",
                confidence: Confidence::Likely,
                rank: 6,
                size: None,
                end: None,
                name: None,
                parent: None,
            },
        );
    }

    let starts: Vec<u64> = seeds.keys().copied().collect();
    let mut functions: Vec<Function> = Vec::with_capacity(starts.len());
    for (i, &start) in starts.iter().enumerate() {
        let seed = match seeds.get(&start) {
            Some(s) => s,
            None => continue,
        };
        let limit = region_end(image, start);
        let (mut end, bounds): (u64, &'static str) = if let Some(e) = seed.end {
            (e, "exception-table")
        } else if let Some(sz) = seed.size {
            (start.saturating_add(sz), "symbol-size")
        } else {
            let next = starts.get(i + 1).copied().unwrap_or(limit);
            (next.min(limit), "estimated")
        };
        if end > limit {
            end = limit;
        }
        if end <= start {
            end = start.saturating_add(1).min(limit.max(start + 1));
        }
        let named = seed.name.is_some() && (seed.source == "symbol" || seed.source == "export");
        let name = match &seed.name {
            Some(n) => n.clone(),
            None => format!("sub_{:x}", start),
        };
        functions.push(Function {
            id: i as u32,
            start,
            end,
            name,
            named,
            source: seed.source,
            confidence: seed.confidence,
            bounds,
            parent: seed.parent,
        });
    }
    functions
}

/// The function that contains `addr` (functions must be sorted by start).
pub fn function_at(functions: &[Function], addr: u64) -> Option<&Function> {
    let idx = functions.partition_point(|f| f.start <= addr);
    if idx == 0 {
        return None;
    }
    let f = &functions[idx - 1];
    if addr < f.end {
        Some(f)
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::architecture::{Arch, ArchInfo};
    use crate::formats::{CodeRegion, EntryPoint, FormatKind, Symbol};
    use crate::types::Endian;

    fn image() -> BinaryImage {
        let arch = ArchInfo {
            arch: Arch::Aarch64,
            endian: Endian::Little,
            bits: 64,
            confidence: Confidence::Verified,
            evidence: String::new(),
        };
        let mut img = BinaryImage::new(FormatKind::Elf, "test".to_string(), arch);
        img.code_regions.push(CodeRegion {
            name: ".text".to_string(),
            va: 0x1000,
            file_offset: 0x1000,
            size: 0x100,
            confidence: Confidence::Verified,
        });
        img.symbols.push(Symbol {
            name: "alpha".to_string(),
            va: 0x1000,
            size: 0x20,
            kind: SymKind::Func,
            global: true,
            is_import: false,
            is_export: true,
            source: "dynsym",
        });
        img.entry_points.push(EntryPoint {
            va: 0x1040,
            name: "e_entry".to_string(),
            kind: "entry".to_string(),
            confidence: Confidence::Verified,
        });
        img
    }

    #[test]
    fn merges_seeds_and_estimates_bounds() {
        let img = image();
        let funcs = discover(&img, &[0x1020, 0x1020, 0x1060, 0x9000]);
        assert_eq!(funcs.len(), 4);
        assert_eq!(funcs[0].name, "alpha");
        assert_eq!(funcs[0].end, 0x1020);
        assert_eq!(funcs[0].bounds, "symbol-size");
        assert_eq!(funcs[1].start, 0x1020);
        assert_eq!(funcs[1].name, "sub_1020");
        assert_eq!(funcs[1].bounds, "estimated");
        assert_eq!(funcs[1].end, 0x1040);
        assert_eq!(funcs[2].name, "e_entry");
        assert_eq!(funcs[3].end, 0x1100);
    }

    #[test]
    fn finds_containing_function() {
        let img = image();
        let funcs = discover(&img, &[]);
        assert_eq!(function_at(&funcs, 0x1010).map(|f| f.start), Some(0x1000));
        assert!(function_at(&funcs, 0x0fff).is_none());
        assert!(function_at(&funcs, 0x2000).is_none());
    }
}
