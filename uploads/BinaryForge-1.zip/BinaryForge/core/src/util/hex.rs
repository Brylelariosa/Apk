//! Hex helpers.

const DIGITS: &[u8; 16] = b"0123456789abcdef";

pub fn hex_bytes(data: &[u8]) -> String {
    let mut s = String::with_capacity(data.len() * 2);
    for &b in data {
        s.push(DIGITS[(b >> 4) as usize] as char);
        s.push(DIGITS[(b & 0x0f) as usize] as char);
    }
    s
}

/// Parses an address. Accepts "0x1a2b" or bare hex digits.
pub fn parse_addr(text: &str) -> Option<u64> {
    let t = text.trim();
    let digits = match t.strip_prefix("0x") {
        Some(rest) => rest,
        None => match t.strip_prefix("0X") {
            Some(rest) => rest,
            None => t,
        },
    };
    if digits.is_empty() {
        return None;
    }
    u64::from_str_radix(digits, 16).ok()
}

/// Parses "7f 45 4c 46" or "7f454c46" into bytes.
pub fn parse_hex_bytes(text: &str) -> Option<Vec<u8>> {
    let mut digits: Vec<u8> = Vec::new();
    for c in text.chars() {
        if c.is_whitespace() {
            continue;
        }
        let v = c.to_digit(16)?;
        digits.push(v as u8);
    }
    if digits.is_empty() || digits.len() % 2 != 0 {
        return None;
    }
    let mut out: Vec<u8> = Vec::with_capacity(digits.len() / 2);
    let mut i = 0;
    while i < digits.len() {
        out.push((digits[i] << 4) | digits[i + 1]);
        i += 2;
    }
    Some(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hex_roundtrip() {
        assert_eq!(hex_bytes(&[0x7f, 0x45, 0x00, 0xff]), "7f4500ff");
        assert_eq!(parse_hex_bytes("7f 45 00 ff"), Some(vec![0x7f, 0x45, 0x00, 0xff]));
        assert_eq!(parse_hex_bytes("7f4"), None);
        assert_eq!(parse_hex_bytes(""), None);
    }

    #[test]
    fn addresses() {
        assert_eq!(parse_addr("0x10"), Some(16));
        assert_eq!(parse_addr("ff"), Some(255));
        assert_eq!(parse_addr("zz"), None);
        assert_eq!(parse_addr(""), None);
    }
}
