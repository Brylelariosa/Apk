//! Minimal JSON writer. The engine only produces JSON, it never parses it.

pub struct JsonWriter {
    out: String,
    first: Vec<bool>,
    after_key: bool,
}

impl Default for JsonWriter {
    fn default() -> JsonWriter {
        JsonWriter::new()
    }
}

fn escape_into(out: &mut String, s: &str) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", c as u32));
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

impl JsonWriter {
    pub fn new() -> JsonWriter {
        JsonWriter {
            out: String::new(),
            first: Vec::new(),
            after_key: false,
        }
    }

    fn before_value(&mut self) {
        if self.after_key {
            self.after_key = false;
            return;
        }
        if let Some(first) = self.first.last_mut() {
            if *first {
                *first = false;
            } else {
                self.out.push(',');
            }
        }
    }

    pub fn begin_object(&mut self) -> &mut JsonWriter {
        self.before_value();
        self.out.push('{');
        self.first.push(true);
        self
    }

    pub fn end_object(&mut self) -> &mut JsonWriter {
        self.first.pop();
        self.out.push('}');
        self
    }

    pub fn begin_array(&mut self) -> &mut JsonWriter {
        self.before_value();
        self.out.push('[');
        self.first.push(true);
        self
    }

    pub fn end_array(&mut self) -> &mut JsonWriter {
        self.first.pop();
        self.out.push(']');
        self
    }

    pub fn key(&mut self, name: &str) -> &mut JsonWriter {
        self.before_value();
        escape_into(&mut self.out, name);
        self.out.push(':');
        self.after_key = true;
        self
    }

    pub fn string(&mut self, value: &str) -> &mut JsonWriter {
        self.before_value();
        escape_into(&mut self.out, value);
        self
    }

    pub fn u64(&mut self, value: u64) -> &mut JsonWriter {
        self.before_value();
        self.out.push_str(&value.to_string());
        self
    }

    pub fn i64(&mut self, value: i64) -> &mut JsonWriter {
        self.before_value();
        self.out.push_str(&value.to_string());
        self
    }

    pub fn f64(&mut self, value: f64) -> &mut JsonWriter {
        self.before_value();
        if value.is_finite() {
            self.out.push_str(&format!("{}", value));
        } else {
            self.out.push_str("null");
        }
        self
    }

    pub fn bool(&mut self, value: bool) -> &mut JsonWriter {
        self.before_value();
        self.out.push_str(if value { "true" } else { "false" });
        self
    }

    pub fn null(&mut self) -> &mut JsonWriter {
        self.before_value();
        self.out.push_str("null");
        self
    }

    /// Addresses are written as "0x..." strings so 64-bit values survive JSON consumers.
    pub fn hex(&mut self, value: u64) -> &mut JsonWriter {
        self.before_value();
        self.out.push('"');
        self.out.push_str(&format!("0x{:x}", value));
        self.out.push('"');
        self
    }

    pub fn kv_str(&mut self, name: &str, value: &str) -> &mut JsonWriter {
        self.key(name);
        self.string(value)
    }

    pub fn kv_u64(&mut self, name: &str, value: u64) -> &mut JsonWriter {
        self.key(name);
        self.u64(value)
    }

    pub fn kv_bool(&mut self, name: &str, value: bool) -> &mut JsonWriter {
        self.key(name);
        self.bool(value)
    }

    pub fn kv_hex(&mut self, name: &str, value: u64) -> &mut JsonWriter {
        self.key(name);
        self.hex(value)
    }

    pub fn kv_f64(&mut self, name: &str, value: f64) -> &mut JsonWriter {
        self.key(name);
        self.f64(value)
    }

    pub fn finish(self) -> String {
        self.out
    }
}

pub fn error_json(message: &str) -> String {
    let mut j = JsonWriter::new();
    j.begin_object();
    j.kv_str("error", message);
    j.end_object();
    j.finish()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn writes_nested_structures() {
        let mut j = JsonWriter::new();
        j.begin_object();
        j.kv_str("a", "x\"y");
        j.key("list");
        j.begin_array();
        j.u64(1);
        j.hex(255);
        j.begin_object();
        j.kv_bool("ok", true);
        j.end_object();
        j.end_array();
        j.kv_u64("n", 7);
        j.end_object();
        assert_eq!(
            j.finish(),
            "{\"a\":\"x\\\"y\",\"list\":[1,\"0xff\",{\"ok\":true}],\"n\":7}"
        );
    }

    #[test]
    fn error_envelope() {
        assert_eq!(error_json("bad"), "{\"error\":\"bad\"}");
    }
}
