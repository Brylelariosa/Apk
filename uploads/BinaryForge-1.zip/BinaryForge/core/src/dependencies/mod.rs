//! External dependencies of an image: libraries and the symbols imported from them.

use crate::formats::BinaryImage;

#[derive(Clone, Debug)]
pub struct LibraryDependency {
    pub name: String,
    /// Number of imported symbols attributed to this library. `None` when the file
    /// format does not record which library provides which symbol (ELF).
    pub imported_symbols: Option<usize>,
}

pub fn summarize(image: &BinaryImage) -> Vec<LibraryDependency> {
    let mut out: Vec<LibraryDependency> = Vec::new();
    for lib in &image.libraries {
        let attributed = image.imports.iter().any(|i| !i.library.is_empty());
        let count = if attributed {
            Some(image.imports.iter().filter(|i| &i.library == lib).count())
        } else {
            None
        };
        out.push(LibraryDependency {
            name: lib.clone(),
            imported_symbols: count,
        });
    }
    out
}

/// Imports whose providing library is not recorded in the file.
pub fn unresolved_import_count(image: &BinaryImage) -> usize {
    image.imports.iter().filter(|i| i.library.is_empty()).count()
}
