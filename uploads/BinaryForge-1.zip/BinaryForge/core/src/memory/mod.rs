//! Virtual-address <-> file-offset mapping.

use crate::types::Perms;

/// One contiguous piece of the loaded image.
#[derive(Clone, Debug)]
pub struct Region {
    pub name: String,
    pub va: u64,
    /// Size in memory.
    pub mem_size: u64,
    pub file_offset: u64,
    /// Bytes backed by the file (never larger than `mem_size`).
    pub file_size: u64,
    pub perms: Perms,
}

#[derive(Clone, Debug, Default)]
pub struct AddressMap {
    regions: Vec<Region>,
}

impl AddressMap {
    pub fn new(mut regions: Vec<Region>) -> AddressMap {
        regions.sort_by_key(|r| r.va);
        AddressMap { regions }
    }

    pub fn regions(&self) -> &[Region] {
        &self.regions
    }

    /// Region whose memory range contains `va`.
    pub fn find(&self, va: u64) -> Option<&Region> {
        for r in &self.regions {
            if va >= r.va && va - r.va < r.mem_size {
                return Some(r);
            }
        }
        None
    }

    pub fn contains(&self, va: u64) -> bool {
        self.find(va).is_some()
    }

    /// File offset for `va`, only when the byte is backed by the file.
    pub fn va_to_offset(&self, va: u64) -> Option<u64> {
        for r in &self.regions {
            if va >= r.va {
                let d = va - r.va;
                if d < r.file_size {
                    return r.file_offset.checked_add(d);
                }
            }
        }
        None
    }

    /// Virtual address of a file offset (first region that backs it).
    pub fn offset_to_va(&self, offset: u64) -> Option<u64> {
        for r in &self.regions {
            if offset >= r.file_offset {
                let d = offset - r.file_offset;
                if d < r.file_size {
                    return r.va.checked_add(d);
                }
            }
        }
        None
    }

    /// Number of file-backed bytes from `va` to the end of its region.
    pub fn file_bytes_from(&self, va: u64) -> u64 {
        for r in &self.regions {
            if va >= r.va {
                let d = va - r.va;
                if d < r.file_size {
                    return r.file_size - d;
                }
            }
        }
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn map() -> AddressMap {
        AddressMap::new(vec![
            Region {
                name: "text".to_string(),
                va: 0x1000,
                mem_size: 0x200,
                file_offset: 0x400,
                file_size: 0x200,
                perms: Perms::new(true, false, true),
            },
            Region {
                name: "bss".to_string(),
                va: 0x3000,
                mem_size: 0x100,
                file_offset: 0x600,
                file_size: 0,
                perms: Perms::new(true, true, false),
            },
        ])
    }

    #[test]
    fn maps_both_ways() {
        let m = map();
        assert_eq!(m.va_to_offset(0x1010), Some(0x410));
        assert_eq!(m.offset_to_va(0x410), Some(0x1010));
        assert_eq!(m.va_to_offset(0x11ff), Some(0x5ff));
        assert_eq!(m.va_to_offset(0x1200), None);
        assert_eq!(m.file_bytes_from(0x1100), 0x100);
    }

    #[test]
    fn bss_is_mapped_but_not_file_backed() {
        let m = map();
        assert!(m.contains(0x3050));
        assert_eq!(m.va_to_offset(0x3050), None);
        assert!(!m.contains(0x9000));
    }
}
