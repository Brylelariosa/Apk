package com.binaryforge.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.AppViewModel
import com.binaryforge.app.data.ManualOptions
import com.binaryforge.app.engine.EntryPointInfo
import com.binaryforge.app.engine.hex
import com.binaryforge.app.ui.components.BfButton
import com.binaryforge.app.ui.components.BfChoice
import com.binaryforge.app.ui.components.BfConfidenceTag
import com.binaryforge.app.ui.components.BfDialog
import com.binaryforge.app.ui.components.BfField
import com.binaryforge.app.ui.components.BfHint
import com.binaryforge.app.ui.components.BfKeyValue
import com.binaryforge.app.ui.components.BfPanel
import com.binaryforge.app.ui.components.BfProgressBar
import com.binaryforge.app.ui.components.BfTag
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.components.formatDuration
import com.binaryforge.app.ui.components.formatTime
import com.binaryforge.app.ui.theme.Bf

@Composable
fun OverviewTab(ctx: ProjectContext, vm: AppViewModel) {
    val s = ctx.summary
    var showManual by remember { mutableStateOf(false) }
    var verifyText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            BfPanel(title = "File") {
                BfKeyValue("Name", ctx.meta.name)
                BfKeyValue("Size", "${formatBytes(s.size)} (${s.size} bytes)")
                BfKeyValue("SHA-256", ctx.meta.sha256, mono = true)
                BfKeyValue("Imported", formatTime(ctx.meta.importedAt))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BfTextButton("Verify integrity", {
                        vm.verifyIntegrity(ctx.meta) { verifyText = it }
                    })
                }
                val result = verifyText
                if (result != null) {
                    Text(
                        result,
                        color = if (result.startsWith("Verified")) Bf.Green else Bf.Red,
                        fontSize = 12.sp,
                    )
                }
            }
        }
        item {
            BfPanel(title = "Format") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        s.formatName,
                        color = Bf.Text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    BfConfidenceTag(s.formatConfidence)
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${s.archName}   ${s.archBits}-bit   ${s.endian}-endian",
                        color = Bf.Cyan,
                        fontFamily = Mono,
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f),
                    )
                    BfConfidenceTag(s.archConfidence)
                }
                Text(s.archEvidence, color = Bf.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                BfKeyValue("Image base", hex(s.imageBase), mono = true)
                BfKeyValue(
                    "Disassembler",
                    if (s.disassemblerAvailable) s.disassemblerBackend else "not available for this architecture",
                    valueColor = if (s.disassemblerAvailable) Bf.Text else Bf.Yellow,
                )
                BfKeyValue("Symbols", "${s.symbolCount} (${s.exportCount} exported)")
                BfKeyValue("Imports", "${s.importCount}")
            }
        }
        if (s.warnings.isNotEmpty()) {
            item {
                BfPanel(title = "Notes", outline = Bf.Yellow) {
                    s.warnings.forEach { w ->
                        Text("- $w", color = Bf.Yellow, fontSize = 13.sp, lineHeight = 18.sp)
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
        item {
            BfPanel(title = "Entry points") {
                if (s.entryPoints.isEmpty()) {
                    BfHint("The file does not state an entry point.")
                }
                s.entryPoints.forEach { e -> EntryPointRow(e, ctx) }
            }
        }
        if (s.libraries.isNotEmpty() || s.unresolvedImports > 0) {
            item {
                BfPanel(title = "Dependencies") {
                    s.libraries.forEach { lib ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Text(lib.name, color = Bf.Text, fontFamily = Mono, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (lib.imports != null) {
                                Text("${lib.imports} imports", color = Bf.Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    if (s.unresolvedImports > 0) {
                        Spacer(Modifier.height(6.dp))
                        BfHint(
                            "${s.unresolvedImports} imported symbols have no recorded provider library. The file format does not say which library supplies them, so they stay unresolved."
                        )
                    }
                }
            }
        }
        if (s.info.isNotEmpty()) {
            item {
                BfPanel(title = "Details") {
                    s.info.forEach { (k, v) -> BfKeyValue(k, v, mono = true) }
                }
            }
        }
        item { AnalysisPanel(ctx) }
        item {
            BfPanel(title = "Manual configuration") {
                BfHint("If detection is wrong, or the file has no header, choose the format, architecture and base address yourself and analyze again.")
                Spacer(Modifier.height(8.dp))
                BfButton("Configure and re-analyze", { showManual = true }, primary = false)
            }
        }
    }

    if (showManual) {
        ManualDialog(
            initial = ctx.meta.manual,
            onDismiss = { showManual = false },
            onApply = {
                showManual = false
                vm.reanalyze(it)
            },
        )
    }
}

@Composable
private fun EntryPointRow(e: EntryPointInfo, ctx: ProjectContext) {
    val canDisassemble = ctx.summary.disassemblerAvailable
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                if (canDisassemble) ctx.openCode(e.va) else ctx.openHex(e.offset ?: 0L)
            }
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(hex(e.va), color = Bf.Cyan, fontFamily = Mono, fontSize = 13.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, color = Bf.Text, fontSize = 13.sp)
            Text(e.kind, color = Bf.Muted, fontSize = 11.sp)
        }
        BfConfidenceTag(e.confidence)
    }
}

@Composable
private fun AnalysisPanel(ctx: ProjectContext) {
    val d = ctx.deep
    BfPanel(title = "Deep analysis") {
        if (d == null || d.state == "idle") {
            BfHint("Starting...")
        } else if (d.running) {
            Text(
                "${d.phase}  ${(d.fraction * 100).toInt()}%",
                color = Bf.Accent,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(6.dp))
            BfProgressBar(d.fraction)
        } else if (d.state == "error") {
            Text(d.message, color = Bf.Red, fontSize = 13.sp)
        } else {
            BfKeyValue("State", if (d.state == "done") "complete" else d.state)
            if (d.deepReady) {
                BfKeyValue("Functions", "${d.functions}")
                BfKeyValue("References", "${d.xrefs}")
                BfKeyValue("Strings", if (d.stringsTotal > d.strings) "${d.strings} of ${d.stringsTotal}" else "${d.strings}")
                BfKeyValue("Instructions", "${d.instructions} scanned (${formatBytes(d.codeBytes)} of code)")
                BfKeyValue("Time", formatDuration(d.elapsedMs))
            }
            d.notes.forEach { n ->
                Spacer(Modifier.height(4.dp))
                Row {
                    BfTag("NOTE", Bf.Yellow)
                    Spacer(Modifier.width(8.dp))
                    Text(n, color = Bf.Yellow, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ManualDialog(
    initial: ManualOptions,
    onDismiss: () -> Unit,
    onApply: (ManualOptions) -> Unit,
) {
    var format by remember { mutableStateOf(initial.format) }
    var arch by remember { mutableStateOf(initial.arch) }
    var base by remember { mutableStateOf(initial.base) }
    var entry by remember { mutableStateOf(initial.entry) }
    val formats = listOf("auto" to "Auto", "raw" to "Raw", "elf" to "ELF", "pe" to "PE")
    val archs = listOf(
        "" to "Auto",
        "aarch64" to "AArch64",
        "x86_64" to "x86-64",
        "x86" to "x86",
        "arm" to "ARM",
    )
    BfDialog(
        title = "Manual configuration",
        onDismiss = onDismiss,
        confirmText = "Analyze",
        onConfirm = { onApply(ManualOptions(format, arch, base.trim(), entry.trim())) },
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("Format", color = Bf.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                formats.forEach { (key, label) -> BfChoice(label, format == key) { format = key } }
            }
            Spacer(Modifier.height(10.dp))
            Text("Architecture", color = Bf.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                archs.forEach { (key, label) -> BfChoice(label, arch == key) { arch = key } }
            }
            Spacer(Modifier.height(10.dp))
            Text("Base address (hex)", color = Bf.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            BfField(base, { base = it }, "0x0", Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Text("Entry offset in file (hex, optional)", color = Bf.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            BfField(entry, { entry = it }, "0x0", Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            BfHint("Raw mode treats the whole file as machine code mapped at the base address. 32-bit ARM has no disassembler in this version.")
        }
    }
}
