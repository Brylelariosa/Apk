package com.binaryforge.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.screens.DashboardScreen
import com.binaryforge.app.ui.screens.ProjectScreen
import com.binaryforge.app.ui.theme.BinaryForgeTheme
import com.binaryforge.app.ui.theme.Bf

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BinaryForgeTheme {
                AppRoot(vm)
            }
        }
    }
}

@Composable
private fun AppRoot(vm: AppViewModel) {
    val session by vm.session.collectAsState()
    val message by vm.message.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.importFile(uri)
    }
    val current = session

    BackHandler(enabled = current != null) { vm.closeProject() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bf.Bg)
    ) {
        val note = message
        if (note != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Bf.PanelHigh)
                    .padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(note, color = Bf.Red, fontSize = 13.sp, modifier = Modifier.weight(1f))
                BfTextButton("Dismiss", { vm.dismissMessage() }, Bf.Muted)
            }
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (current == null) {
                DashboardScreen(vm) { picker.launch(arrayOf("*/*")) }
            } else {
                key(current) {
                    ProjectScreen(vm, current) { vm.closeProject() }
                }
            }
        }
    }
}
