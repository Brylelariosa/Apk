package com.binaryforge.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.binaryforge.app.data.AnalysisSettings
import com.binaryforge.app.data.Importer
import com.binaryforge.app.data.ManualOptions
import com.binaryforge.app.data.ProjectMeta
import com.binaryforge.app.data.ProjectStore
import com.binaryforge.app.data.SettingsStore
import com.binaryforge.app.data.StorageInfo
import com.binaryforge.app.data.buildOptions
import com.binaryforge.app.engine.DeepStatus
import com.binaryforge.app.engine.Engine
import com.binaryforge.app.engine.Summary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

sealed interface BusyState {
    object Idle : BusyState
    data class Importing(val name: String, val done: Long, val total: Long) : BusyState
}

sealed interface ProjectState {
    object Loading : ProjectState
    data class Failed(val message: String) : ProjectState
    data class Ready(val engine: Engine, val summary: Summary) : ProjectState
}

/** One opened project: its structure summary plus the background deep analysis. */
class ProjectSession(val meta: ProjectMeta) {
    val state = MutableStateFlow<ProjectState>(ProjectState.Loading)
    val deep = MutableStateFlow<DeepStatus?>(null)

    @Volatile
    var engine: Engine? = null

    @Volatile
    var job: Job? = null
}

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val store = ProjectStore(application)
    private val importer = Importer(application, store)
    private val settingsStore = SettingsStore(application)

    val projects = MutableStateFlow<List<ProjectMeta>>(emptyList())
    val storage = MutableStateFlow(StorageInfo(0L, 0L, 0L))
    val history = MutableStateFlow<List<String>>(emptyList())
    val busy = MutableStateFlow<BusyState>(BusyState.Idle)
    val message = MutableStateFlow<String?>(null)
    val settings = MutableStateFlow(settingsStore.load())
    val session = MutableStateFlow<ProjectSession?>(null)

    private var importJob: Job? = null

    init {
        refresh()
    }

    private fun reloadBlocking() {
        val list = store.list()
        val info = store.storageInfo()
        val hist = store.readHistory(12)
        projects.value = list
        storage.value = info
        history.value = hist
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) { reloadBlocking() }
    }

    fun dismissMessage() {
        message.value = null
    }

    fun saveSettings(value: AnalysisSettings) {
        settings.value = value
        settingsStore.save(value)
    }

    // ---- import ------------------------------------------------------------------------------

    fun importFile(uri: Uri) {
        if (busy.value !is BusyState.Idle) return
        busy.value = BusyState.Importing("", 0L, -1L)
        importJob = viewModelScope.launch {
            try {
                val meta = importer.import(uri) { name, done, total ->
                    busy.value = BusyState.Importing(name, done, total)
                }
                withContext(Dispatchers.IO) { store.appendHistory("Imported ${meta.name}") }
                busy.value = BusyState.Idle
                refresh()
                openProject(meta)
            } catch (e: CancellationException) {
                busy.value = BusyState.Idle
                throw e
            } catch (e: Exception) {
                busy.value = BusyState.Idle
                message.value = "Import failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun cancelImport() {
        importJob?.cancel()
    }

    // ---- projects ----------------------------------------------------------------------------

    fun openProject(meta: ProjectMeta, manual: ManualOptions = meta.manual) {
        closeProject()
        val opened = meta.copy(manual = manual)
        val ps = ProjectSession(opened)
        session.value = ps
        ps.job = viewModelScope.launch(Dispatchers.Default) {
            try {
                val file = store.sourceFile(opened.id)
                val engine = Engine.open(file.absolutePath, buildOptions(settings.value, manual))
                ps.engine = engine
                val summary = engine.analyze()
                ps.state.value = ProjectState.Ready(engine, summary)
                store.save(
                    opened.copy(
                        lastOpenedAt = System.currentTimeMillis(),
                        format = summary.formatName,
                        arch = summary.archName,
                    )
                )
                reloadBlocking()
                runDeepAnalysis(ps, engine, opened.name)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ps.state.value = ProjectState.Failed(e.message ?: "The analysis failed.")
            }
        }
    }

    private suspend fun runDeepAnalysis(ps: ProjectSession, engine: Engine, name: String) {
        coroutineScope<Unit> {
            val poller = launch(Dispatchers.IO) {
                while (isActive) {
                    try {
                        val status = engine.status()
                        ps.deep.value = status
                        if (status.state == "done" || status.state == "cancelled" || status.state == "error") {
                            break
                        }
                    } catch (e: Exception) {
                        break
                    }
                    delay(250)
                }
            }
            try {
                val finalStatus = engine.deepAnalyze()
                ps.deep.value = finalStatus
                if (finalStatus.state == "done") {
                    store.appendHistory(
                        "Analyzed $name: ${finalStatus.functions} functions, ${finalStatus.strings} strings, ${finalStatus.elapsedMs} ms"
                    )
                    reloadBlocking()
                }
            } catch (e: Exception) {
                ps.deep.value = DeepStatus(state = "error", message = e.message ?: "The deep analysis failed.")
            } finally {
                poller.cancel()
            }
        }
    }

    fun cancelAnalysis() {
        session.value?.engine?.cancel()
    }

    fun closeProject() {
        val ps = session.value ?: return
        session.value = null
        ps.engine?.cancel()
        viewModelScope.launch(Dispatchers.IO) {
            val job = ps.job
            job?.cancel()
            job?.join()
            ps.engine?.close()
            reloadBlocking()
        }
    }

    /** Re-runs the analysis with manual format overrides (kept in the project record). */
    fun reanalyze(manual: ManualOptions) {
        val ps = session.value ?: return
        val updated = ps.meta.copy(manual = manual)
        viewModelScope.launch(Dispatchers.IO) { store.save(updated) }
        openProject(updated, manual)
    }

    fun deleteProject(meta: ProjectMeta) {
        if (session.value?.meta?.id == meta.id) closeProject()
        viewModelScope.launch(Dispatchers.IO) {
            store.delete(meta.id)
            store.appendHistory("Deleted ${meta.name}")
            reloadBlocking()
        }
    }

    /** Re-hashes the private copy and compares it with the hash taken at import time. */
    fun verifyIntegrity(meta: ProjectMeta, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    val digest = MessageDigest.getInstance("SHA-256")
                    val buffer = ByteArray(1 shl 20)
                    store.sourceFile(meta.id).inputStream().use { stream ->
                        while (true) {
                            val n = stream.read(buffer)
                            if (n < 0) break
                            digest.update(buffer, 0, n)
                        }
                    }
                    val now = digest.digest().joinToString("") { b -> "%02x".format(b) }
                    if (now == meta.sha256) {
                        "Verified: the SHA-256 matches the value recorded at import."
                    } else {
                        "MISMATCH: the file differs from the import-time hash ($now)."
                    }
                } catch (e: Exception) {
                    "Verification failed: ${e.message ?: "unknown error"}"
                }
            }
            onResult(text)
        }
    }

    override fun onCleared() {
        super.onCleared()
        session.value?.let { ps ->
            ps.engine?.cancel()
            ps.job?.cancel()
        }
    }
}
