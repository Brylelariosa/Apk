package com.binaryforge.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.engine.Page
import com.binaryforge.app.ui.theme.Bf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val PAGE_SIZE = 200

/**
 * Loads a long list from the engine one page at a time. A generation counter makes sure a
 * slow response for an old filter can never overwrite the list for the current one.
 */
class PagedState<T>(private val loader: (offset: Int, limit: Int, filter: String) -> Page<T>) {
    val items = mutableStateListOf<T>()

    var total by mutableStateOf(0)
        private set
    var ready by mutableStateOf(false)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private var filter = ""
    private var generation = 0

    suspend fun reset(newFilter: String) {
        generation++
        filter = newFilter
        items.clear()
        total = 0
        ready = false
        loading = false
        error = null
        loadMore()
    }

    suspend fun loadMore() {
        if (loading) return
        if (ready && items.size >= total) return
        loading = true
        val gen = generation
        val offset = items.size
        val currentFilter = filter
        try {
            val page = withContext(Dispatchers.IO) { loader(offset, PAGE_SIZE, currentFilter) }
            if (gen == generation) {
                ready = page.ready
                total = page.total
                items.addAll(page.items)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (gen == generation) {
                error = e.message ?: "The query failed."
                ready = true
            }
        } finally {
            if (gen == generation) loading = false
        }
    }
}

/** Search field, result count and a lazily loaded list. */
@Composable
fun <T> BfPagedList(
    state: PagedState<T>,
    query: String,
    onQueryChange: (String) -> Unit,
    hint: String,
    unitLabel: String,
    notReadyText: String,
    emptyText: String,
    modifier: Modifier = Modifier,
    header: @Composable () -> Unit = {},
    itemContent: @Composable (T) -> Unit,
) {
    val listState = rememberLazyListState()

    LaunchedEffect(state, query) {
        if (query.isNotEmpty()) delay(300)
        state.reset(query)
    }
    LaunchedEffect(state, listState) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last ->
                if (last >= state.items.size - 8) state.loadMore()
            }
    }

    Column(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 6.dp)
        ) {
            header()
            BfField(query, onQueryChange, hint, Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            val err = state.error
            when {
                err != null -> Text(err, color = Bf.Red, fontSize = 12.sp)
                !state.ready -> Text(
                    if (state.loading) "Loading..." else notReadyText,
                    color = Bf.Muted,
                    fontSize = 12.sp,
                )
                state.total == 0 -> Text(emptyText, color = Bf.Muted, fontSize = 12.sp)
                else -> Text("${state.total} $unitLabel", color = Bf.Muted, fontSize = 12.sp)
            }
        }
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            items(state.items) { item -> itemContent(item) }
        }
    }
}
