package com.binaryforge.app.engine

/**
 * Raw JNI declarations. The matching Rust functions live in `jni/src/lib.rs`
 * (`Java_com_binaryforge_app_engine_NativeBridge_*`). Everything returns JSON text except
 * the hex-viewer read, which returns bytes. Use [Engine] instead of calling this directly.
 */
object NativeBridge {
    /** Non-null when `libbinaryforge.so` could not be loaded. */
    var loadError: String? = null
        private set

    init {
        try {
            System.loadLibrary("binaryforge")
        } catch (t: Throwable) {
            loadError = t.message ?: t.javaClass.simpleName
        }
    }

    val isAvailable: Boolean
        get() = loadError == null

    fun version(): String {
        if (!isAvailable) return "unavailable"
        return try {
            nativeVersion() ?: "unknown"
        } catch (t: Throwable) {
            "unavailable"
        }
    }

    @JvmStatic external fun nativeVersion(): String?
    @JvmStatic external fun nativeOpen(path: String, options: String): String?
    @JvmStatic external fun nativeClose(handle: Long)
    @JvmStatic external fun nativeAnalyze(handle: Long): String?
    @JvmStatic external fun nativeDeepAnalyze(handle: Long): String?
    @JvmStatic external fun nativeStatus(handle: Long): String?
    @JvmStatic external fun nativeCancel(handle: Long)
    @JvmStatic external fun nativeRead(handle: Long, offset: Long, length: Int): ByteArray?
    @JvmStatic external fun nativeFind(handle: Long, from: Long, patternHex: String): Long
    @JvmStatic external fun nativeQuery(
        handle: Long,
        what: String,
        arg: String,
        offset: Int,
        limit: Int,
        filter: String,
    ): String?
    @JvmStatic external fun nativeDisassemble(handle: Long, address: Long, count: Int): String?
    @JvmStatic external fun nativeFunctionDetail(handle: Long, address: Long): String?
}
