package com.binaryforge.app.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("binaryforge", Context.MODE_PRIVATE)

    fun load(): AnalysisSettings {
        val cores = Runtime.getRuntime().availableProcessors()
        val defaultThreads = (cores - 1).coerceIn(1, 4)
        return AnalysisSettings(
            threads = prefs.getInt("threads", defaultThreads).coerceIn(1, 8),
            memoryMb = prefs.getInt("memory_mb", 256).coerceIn(64, 4096),
            minStringLen = prefs.getInt("min_string", 4).coerceIn(2, 64),
        )
    }

    fun save(settings: AnalysisSettings) {
        prefs.edit()
            .putInt("threads", settings.threads)
            .putInt("memory_mb", settings.memoryMb)
            .putInt("min_string", settings.minStringLen)
            .apply()
    }
}
