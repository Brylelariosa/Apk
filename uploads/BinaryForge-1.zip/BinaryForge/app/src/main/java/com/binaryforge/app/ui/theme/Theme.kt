package com.binaryforge.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** BinaryForge palette: charcoal surfaces, an ember accent, cyan for addresses. */
object Bf {
    val Bg = Color(0xFF0B0E13)
    val Panel = Color(0xFF131820)
    val PanelHigh = Color(0xFF1A212B)
    val Border = Color(0xFF263040)
    val Text = Color(0xFFE6EAF0)
    val Muted = Color(0xFF8A94A3)
    val Dim = Color(0xFF5B6574)
    val Accent = Color(0xFFFFAB40)
    val OnAccent = Color(0xFF1A1000)
    val Cyan = Color(0xFF5CC8D7)
    val Green = Color(0xFF4CC38A)
    val Yellow = Color(0xFFE3B341)
    val Red = Color(0xFFF26D6D)
    val Violet = Color(0xFFB39DDB)
    val Blue = Color(0xFF79B8FF)
}

@Composable
fun BinaryForgeTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Bf.Accent,
        onPrimary = Bf.OnAccent,
        secondary = Bf.Cyan,
        onSecondary = Bf.Bg,
        background = Bf.Bg,
        onBackground = Bf.Text,
        surface = Bf.Panel,
        onSurface = Bf.Text,
        surfaceVariant = Bf.PanelHigh,
        onSurfaceVariant = Bf.Muted,
        outline = Bf.Border,
        error = Bf.Red,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
