package com.binaryforge.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest

/**
 * Copies a file chosen in the system picker into app-private storage, hashing it on the way.
 * The original is only ever read. Analysis then runs on the private copy, which makes
 * projects resumable and independent of the source location.
 */
class Importer(private val context: Context, private val store: ProjectStore) {

    suspend fun import(
        uri: Uri,
        onProgress: (name: String, done: Long, total: Long) -> Unit,
    ): ProjectMeta = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var name = "file"
        var total = -1L
        resolver.query(uri, null, null, null, null)?.use { c ->
            val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = c.getColumnIndex(OpenableColumns.SIZE)
            if (c.moveToFirst()) {
                if (nameIndex >= 0 && !c.isNull(nameIndex)) name = c.getString(nameIndex)
                if (sizeIndex >= 0 && !c.isNull(sizeIndex)) total = c.getLong(sizeIndex)
            }
        }
        val free = context.filesDir.usableSpace
        if (total > 0 && total + 64L * 1024 * 1024 > free) {
            throw IOException("Not enough free storage to import this file.")
        }

        val id = store.newId()
        val dir = store.projectDir(id)
        dir.mkdirs()
        val target: File = store.sourceFile(id)
        val digest = MessageDigest.getInstance("SHA-256")
        var copied = 0L
        onProgress(name, 0L, total)
        try {
            val input = resolver.openInputStream(uri)
                ?: throw IOException("The selected file could not be opened.")
            input.use { stream ->
                FileOutputStream(target).use { out ->
                    val buffer = ByteArray(1 shl 20)
                    while (true) {
                        ensureActive()
                        val n = stream.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        digest.update(buffer, 0, n)
                        copied += n
                        onProgress(name, copied, total)
                    }
                }
            }
        } catch (e: Throwable) {
            dir.deleteRecursively()
            throw e
        }

        val now = System.currentTimeMillis()
        val meta = ProjectMeta(
            id = id,
            name = name,
            size = copied,
            sha256 = digest.digest().joinToString("") { b -> "%02x".format(b) },
            importedAt = now,
            lastOpenedAt = now,
            format = "",
            arch = "",
            manual = ManualOptions(),
        )
        store.save(meta)
        meta
    }
}
