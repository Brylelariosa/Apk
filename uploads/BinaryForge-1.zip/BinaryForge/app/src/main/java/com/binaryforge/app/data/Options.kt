package com.binaryforge.app.data

/** Manual overrides for files whose format or architecture could not be detected. */
data class ManualOptions(
    val format: String = "auto",
    val arch: String = "",
    val base: String = "",
    val entry: String = "",
) {
    val isDefault: Boolean
        get() = format == "auto" && arch.isEmpty() && base.isEmpty() && entry.isEmpty()
}

/** Resource limits for the engine. */
data class AnalysisSettings(
    val threads: Int = 2,
    val memoryMb: Int = 256,
    val minStringLen: Int = 4,
)

/** Serializes settings into the `key=value` text the engine parses. */
fun buildOptions(settings: AnalysisSettings, manual: ManualOptions): String {
    val sb = StringBuilder()
    sb.append("threads=").append(settings.threads).append('\n')
    sb.append("max_memory_mb=").append(settings.memoryMb).append('\n')
    sb.append("min_string_len=").append(settings.minStringLen).append('\n')
    sb.append("format=").append(manual.format).append('\n')
    if (manual.arch.isNotEmpty()) sb.append("arch=").append(manual.arch).append('\n')
    if (manual.base.isNotEmpty()) sb.append("base=").append(manual.base).append('\n')
    if (manual.entry.isNotEmpty()) sb.append("entry=").append(manual.entry).append('\n')
    return sb.toString()
}
