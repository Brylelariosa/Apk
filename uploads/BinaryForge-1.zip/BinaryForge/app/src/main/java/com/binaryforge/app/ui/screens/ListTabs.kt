package com.binaryforge.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.engine.ImportRow
import com.binaryforge.app.engine.StringRow
import com.binaryforge.app.engine.SymbolRow
import com.binaryforge.app.engine.hex
import com.binaryforge.app.ui.components.BfChoice
import com.binaryforge.app.ui.components.BfPagedList
import com.binaryforge.app.ui.components.BfTag
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.PagedState
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.components.hexPad
import com.binaryforge.app.ui.theme.Bf

@Composable
fun SymbolsTab(ctx: ProjectContext) {
    val engine = ctx.engine
    var kind by remember { mutableStateOf("all") }
    var query by remember(kind) { mutableStateOf("") }

    val chips: @Composable () -> Unit = {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 8.dp)
        ) {
            listOf(
                "all" to "All",
                "func" to "Functions",
                "object" to "Objects",
                "export" to "Exports",
                "imports" to "Imports",
            ).forEach { (key, label) -> BfChoice(label, kind == key) { kind = key } }
        }
    }

    if (kind == "imports") {
        val state = remember(engine) {
            PagedState<ImportRow> { offset, limit, filter -> engine.imports(offset, limit, filter) }
        }
        BfPagedList(
            state = state,
            query = query,
            onQueryChange = { query = it },
            hint = "Search imports",
            unitLabel = "imports",
            notReadyText = "Imports are not available.",
            emptyText = "No imports.",
            header = chips,
        ) { row -> ImportItem(row) }
    } else {
        val currentKind = kind
        val state = remember(engine, currentKind) {
            PagedState<SymbolRow> { offset, limit, filter ->
                engine.symbols(currentKind, offset, limit, filter)
            }
        }
        BfPagedList(
            state = state,
            query = query,
            onQueryChange = { query = it },
            hint = "Search symbols by name or address",
            unitLabel = "symbols",
            notReadyText = "Symbols are not available.",
            emptyText = "No symbols match. Stripped files often have none.",
            header = chips,
        ) { row -> SymbolItem(row, ctx) }
    }
}

@Composable
private fun SymbolItem(row: SymbolRow, ctx: ProjectContext) {
    val canOpen = row.kind == "func" && !row.isImport && row.va != 0L && ctx.summary.disassemblerAvailable
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = canOpen) { ctx.openCode(row.va) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = if (row.isImport) "        " else hexPad(row.va, 8),
            color = Bf.Cyan,
            fontFamily = Mono,
            fontSize = 12.sp,
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = row.name,
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val sizeText = if (row.size > 0L) "  size ${formatBytes(row.size)}" else ""
            Text("${row.kind}$sizeText   ${row.source}", color = Bf.Muted, fontSize = 11.sp)
        }
        if (row.isImport) BfTag("IMPORT", Bf.Violet)
        if (row.isExport) BfTag("EXPORT", Bf.Green)
    }
}

@Composable
private fun ImportItem(row: ImportRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = row.name,
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val where = if (row.library.isEmpty()) "provider not recorded" else row.library
            val slot = if (row.slot != null) "   slot ${hex(row.slot)}" else ""
            Text("$where$slot", color = Bf.Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun StringsTab(ctx: ProjectContext) {
    val engine = ctx.engine
    val ready = ctx.deep?.deepReady == true
    val running = ctx.deep?.running == true
    val state = remember(engine, ready) {
        PagedState<StringRow> { offset, limit, filter -> engine.strings(offset, limit, filter) }
    }
    var query by remember { mutableStateOf("") }
    BfPagedList(
        state = state,
        query = query,
        onQueryChange = { query = it },
        hint = "Search strings",
        unitLabel = "strings",
        notReadyText = if (running) "Strings appear when the analysis has finished." else "Strings are not available.",
        emptyText = "No strings found.",
    ) { row -> StringItem(row, ctx) }
}

@Composable
private fun StringItem(row: StringRow, ctx: ProjectContext) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable { ctx.openHex(row.offset) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = row.text,
            color = Bf.Text,
            fontFamily = Mono,
            fontSize = 12.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("off ${hex(row.offset)}", color = Bf.Cyan, fontFamily = Mono, fontSize = 11.sp)
            val va = row.va
            if (va != null) {
                Text("   va ${hex(va)}", color = Bf.Muted, fontFamily = Mono, fontSize = 11.sp)
            }
            Spacer(Modifier.width(8.dp))
            BfTag(row.enc.uppercase(), Bf.Muted)
        }
    }
}
