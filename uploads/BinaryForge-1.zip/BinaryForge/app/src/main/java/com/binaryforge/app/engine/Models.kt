package com.binaryforge.app.engine

import org.json.JSONArray
import org.json.JSONObject

class EngineException(message: String) : Exception(message)

/** Parses "0x1a2b" (or bare hex) into a 64-bit value. Returns null for empty or invalid text. */
fun parseAddr(text: String?): Long? {
    if (text == null || text.isEmpty()) return null
    val t = text.removePrefix("0x").removePrefix("0X")
    if (t.isEmpty()) return null
    return try {
        java.lang.Long.parseUnsignedLong(t, 16)
    } catch (e: NumberFormatException) {
        null
    }
}

fun hex(value: Long): String = "0x" + java.lang.Long.toHexString(value)

// ---- JSON helpers --------------------------------------------------------------------------

private fun JSONObject.addr(name: String): Long = parseAddr(optString(name, "")) ?: 0L

private fun JSONObject.addrOrNull(name: String): Long? =
    if (isNull(name)) null else parseAddr(optString(name, ""))

private fun JSONObject.textOrNull(name: String): String? =
    if (isNull(name)) null else optString(name, "").ifEmpty { null }

private fun <T> JSONArray.objects(map: (JSONObject) -> T): List<T> {
    val out = ArrayList<T>(length())
    for (i in 0 until length()) out.add(map(getJSONObject(i)))
    return out
}

private fun JSONArray.strings(): List<String> {
    val out = ArrayList<String>(length())
    for (i in 0 until length()) out.add(getString(i))
    return out
}

// ---- structure summary ---------------------------------------------------------------------

data class SectionInfo(
    val index: Int,
    val name: String,
    val kind: String,
    val va: Long,
    val offset: Long,
    val size: Long,
    val memSize: Long,
    val perms: String,
    val type: String,
    val confidence: String,
)

data class SegmentInfo(
    val kind: String,
    val va: Long,
    val offset: Long,
    val size: Long,
    val memSize: Long,
    val perms: String,
    val align: Long,
)

data class EntryPointInfo(
    val va: Long,
    val offset: Long?,
    val name: String,
    val kind: String,
    val confidence: String,
)

data class CodeRegionInfo(
    val name: String,
    val va: Long,
    val offset: Long,
    val size: Long,
    val confidence: String,
)

data class LibraryInfo(val name: String, val imports: Int?)

data class Summary(
    val size: Long,
    val formatKind: String,
    val formatName: String,
    val formatConfidence: String,
    val archName: String,
    val archBits: Int,
    val endian: String,
    val archConfidence: String,
    val archEvidence: String,
    val imageBase: Long,
    val entryPoints: List<EntryPointInfo>,
    val sections: List<SectionInfo>,
    val segments: List<SegmentInfo>,
    val codeRegions: List<CodeRegionInfo>,
    val libraries: List<LibraryInfo>,
    val info: List<Pair<String, String>>,
    val symbolCount: Int,
    val importCount: Int,
    val exportCount: Int,
    val unresolvedImports: Int,
    val warnings: List<String>,
    val disassemblerAvailable: Boolean,
    val disassemblerBackend: String,
) {
    /** True when the architecture came from a header (not guessed or typed in). */
    val archVerified: Boolean get() = archConfidence == "verified"

    /** Address a code listing should start from by default. */
    val defaultCodeStart: Long?
        get() = entryPoints.firstOrNull()?.va ?: codeRegions.firstOrNull()?.va
}

fun parseSummary(o: JSONObject): Summary {
    val file = o.getJSONObject("file")
    val format = o.getJSONObject("format")
    val arch = o.getJSONObject("arch")
    val counts = o.getJSONObject("counts")
    val disasm = o.getJSONObject("disassembler")
    val info = ArrayList<Pair<String, String>>()
    val infoArray = o.getJSONArray("info")
    for (i in 0 until infoArray.length()) {
        val pair = infoArray.getJSONArray(i)
        info.add(Pair(pair.getString(0), pair.getString(1)))
    }
    return Summary(
        size = file.optLong("size", 0L),
        formatKind = format.optString("kind", "unknown"),
        formatName = format.optString("name", "unknown"),
        formatConfidence = format.optString("confidence", "unknown"),
        archName = arch.optString("name", "unknown"),
        archBits = arch.optInt("bits", 0),
        endian = arch.optString("endian", "little"),
        archConfidence = arch.optString("confidence", "unknown"),
        archEvidence = arch.optString("evidence", ""),
        imageBase = o.addr("image_base"),
        entryPoints = o.getJSONArray("entry_points").objects { e ->
            EntryPointInfo(
                va = e.addr("va"),
                offset = e.addrOrNull("offset"),
                name = e.optString("name", ""),
                kind = e.optString("kind", ""),
                confidence = e.optString("confidence", "unknown"),
            )
        },
        sections = o.getJSONArray("sections").objects { s ->
            SectionInfo(
                index = s.optInt("index", 0),
                name = s.optString("name", ""),
                kind = s.optString("kind", "unknown"),
                va = s.addr("va"),
                offset = s.addr("offset"),
                size = s.optLong("size", 0L),
                memSize = s.optLong("mem_size", 0L),
                perms = s.optString("perms", "---"),
                type = s.optString("type", ""),
                confidence = s.optString("confidence", "unknown"),
            )
        },
        segments = o.getJSONArray("segments").objects { s ->
            SegmentInfo(
                kind = s.optString("kind", ""),
                va = s.addr("va"),
                offset = s.addr("offset"),
                size = s.optLong("size", 0L),
                memSize = s.optLong("mem_size", 0L),
                perms = s.optString("perms", "---"),
                align = s.optLong("align", 0L),
            )
        },
        codeRegions = o.getJSONArray("code_regions").objects { r ->
            CodeRegionInfo(
                name = r.optString("name", ""),
                va = r.addr("va"),
                offset = r.addr("offset"),
                size = r.optLong("size", 0L),
                confidence = r.optString("confidence", "unknown"),
            )
        },
        libraries = o.getJSONArray("libraries").objects { l ->
            LibraryInfo(
                name = l.optString("name", ""),
                imports = if (l.isNull("imports")) null else l.optInt("imports", 0),
            )
        },
        info = info,
        symbolCount = counts.optInt("symbols", 0),
        importCount = counts.optInt("imports", 0),
        exportCount = counts.optInt("exports", 0),
        unresolvedImports = counts.optInt("unresolved_imports", 0),
        warnings = o.getJSONArray("warnings").strings(),
        disassemblerAvailable = disasm.optBoolean("available", false),
        disassemblerBackend = disasm.optString("backend", ""),
    )
}

// ---- deep analysis status ------------------------------------------------------------------

data class DeepStatus(
    val state: String = "idle",
    val phase: String = "",
    val fraction: Float = 0f,
    val message: String = "",
    val deepReady: Boolean = false,
    val functions: Int = 0,
    val xrefs: Int = 0,
    val strings: Int = 0,
    val stringsTotal: Long = 0L,
    val instructions: Long = 0L,
    val codeBytes: Long = 0L,
    val elapsedMs: Long = 0L,
    val notes: List<String> = emptyList(),
) {
    val running: Boolean get() = state == "running"
}

fun parseStatus(o: JSONObject): DeepStatus = DeepStatus(
    state = o.optString("state", "idle"),
    phase = o.optString("phase", ""),
    fraction = o.optDouble("fraction", 0.0).toFloat(),
    message = o.optString("message", ""),
    deepReady = o.optBoolean("deep_ready", false),
    functions = o.optInt("functions", 0),
    xrefs = o.optInt("xrefs", 0),
    strings = o.optInt("strings", 0),
    stringsTotal = o.optLong("strings_total", 0L),
    instructions = o.optLong("instructions", 0L),
    codeBytes = o.optLong("code_bytes", 0L),
    elapsedMs = o.optLong("elapsed_ms", 0L),
    notes = o.optJSONArray("notes")?.strings() ?: emptyList(),
)

// ---- paged rows ----------------------------------------------------------------------------

data class Page<T>(val ready: Boolean, val total: Int, val items: List<T>)

fun <T> parsePage(o: JSONObject, map: (JSONObject) -> T): Page<T> {
    val items = o.optJSONArray("items")?.objects(map) ?: emptyList()
    return Page(o.optBoolean("ready", true), o.optInt("total", 0), items)
}

data class FunctionRow(
    val id: Int,
    val name: String,
    val start: Long,
    val end: Long,
    val size: Long,
    val confidence: String,
    val bounds: String,
    val boundsConfidence: String,
    val source: String,
    val refsIn: Int,
    val parent: Long?,
)

fun parseFunctionRow(o: JSONObject) = FunctionRow(
    id = o.optInt("id", 0),
    name = o.optString("name", ""),
    start = o.addr("start"),
    end = o.addr("end"),
    size = o.optLong("size", 0L),
    confidence = o.optString("confidence", "unknown"),
    bounds = o.optString("bounds", ""),
    boundsConfidence = o.optString("bounds_confidence", "unknown"),
    source = o.optString("source", ""),
    refsIn = o.optInt("refs_in", 0),
    parent = o.addrOrNull("parent"),
)

data class SymbolRow(
    val name: String,
    val va: Long,
    val size: Long,
    val kind: String,
    val global: Boolean,
    val isImport: Boolean,
    val isExport: Boolean,
    val source: String,
)

fun parseSymbolRow(o: JSONObject) = SymbolRow(
    name = o.optString("name", ""),
    va = o.addr("va"),
    size = o.optLong("size", 0L),
    kind = o.optString("kind", ""),
    global = o.optBoolean("global", false),
    isImport = o.optBoolean("import", false),
    isExport = o.optBoolean("export", false),
    source = o.optString("source", ""),
)

data class ImportRow(val library: String, val name: String, val slot: Long?, val ordinal: Int?)

fun parseImportRow(o: JSONObject) = ImportRow(
    library = o.optString("library", ""),
    name = o.optString("name", ""),
    slot = o.addrOrNull("slot"),
    ordinal = if (o.isNull("ordinal")) null else o.optInt("ordinal", 0),
)

data class StringRow(val offset: Long, val va: Long?, val enc: String, val text: String)

fun parseStringRow(o: JSONObject) = StringRow(
    offset = o.addr("offset"),
    va = o.addrOrNull("va"),
    enc = o.optString("enc", "ascii"),
    text = o.optString("text", ""),
)

data class XrefRow(val from: Long, val kind: String, val func: String)

fun parseXrefRow(o: JSONObject) = XrefRow(
    from = o.addr("from"),
    kind = o.optString("kind", ""),
    func = o.optString("func", ""),
)

// ---- code listing --------------------------------------------------------------------------

data class InsnRow(
    val addr: Long,
    val off: Long?,
    val bytes: String,
    val mnem: String,
    val ops: String,
    val flow: String,
    val valid: Boolean,
    val target: Long?,
    val targetLabel: String?,
    val mem: Long?,
    val comment: String?,
    val func: String?,
)

data class Listing(val insns: List<InsnRow>, val next: Long, val end: Boolean)

fun parseListing(o: JSONObject): Listing {
    val rows = o.getJSONArray("insns").objects { i ->
        InsnRow(
            addr = i.addr("addr"),
            off = i.addrOrNull("off"),
            bytes = i.optString("bytes", ""),
            mnem = i.optString("mnem", ""),
            ops = i.optString("ops", ""),
            flow = i.optString("flow", "normal"),
            valid = i.optBoolean("valid", true),
            target = i.addrOrNull("target"),
            targetLabel = i.textOrNull("target_label"),
            mem = i.addrOrNull("mem"),
            comment = i.textOrNull("comment"),
            func = i.textOrNull("func"),
        )
    }
    return Listing(rows, o.addr("next"), o.optBoolean("end", false))
}

// ---- function detail -----------------------------------------------------------------------

data class CallRow(val target: Long, val count: Int, val name: String?)
data class DataRefRow(val addr: Long, val label: String?)

data class FunctionDetail(
    val name: String,
    val start: Long,
    val end: Long,
    val size: Long,
    val source: String,
    val confidence: String,
    val bounds: String,
    val boundsConfidence: String,
    val parent: Long?,
    val instructions: Int,
    val undecoded: Int,
    val truncated: Boolean,
    val flowCounts: List<Pair<String, Int>>,
    val calls: List<CallRow>,
    val registers: List<String>,
    val dataRefs: List<DataRefRow>,
    val callersTotal: Int,
    val callers: List<XrefRow>,
)

fun parseFunctionDetail(o: JSONObject): FunctionDetail {
    val flows = ArrayList<Pair<String, Int>>()
    val flowObj = o.optJSONObject("flow_counts")
    if (flowObj != null) {
        val keys = flowObj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            flows.add(Pair(k, flowObj.optInt(k, 0)))
        }
    }
    return FunctionDetail(
        name = o.optString("name", ""),
        start = o.addr("start"),
        end = o.addr("end"),
        size = o.optLong("size", 0L),
        source = o.optString("source", ""),
        confidence = o.optString("confidence", "unknown"),
        bounds = o.optString("bounds", ""),
        boundsConfidence = o.optString("bounds_confidence", "unknown"),
        parent = o.addrOrNull("parent"),
        instructions = o.optInt("instructions", 0),
        undecoded = o.optInt("undecoded_units", 0),
        truncated = o.optBoolean("truncated", false),
        flowCounts = flows,
        calls = o.optJSONArray("calls")?.objects { c ->
            CallRow(c.addr("target"), c.optInt("count", 0), c.textOrNull("name"))
        } ?: emptyList(),
        registers = o.optJSONArray("registers")?.strings() ?: emptyList(),
        dataRefs = o.optJSONArray("data_refs")?.objects { d ->
            DataRefRow(d.addr("addr"), d.textOrNull("label"))
        } ?: emptyList(),
        callersTotal = o.optInt("callers_total", 0),
        callers = o.optJSONArray("callers")?.objects { x -> parseXrefRow(x) } ?: emptyList(),
    )
}
