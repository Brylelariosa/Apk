package com.binaryforge.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.AppViewModel
import com.binaryforge.app.ProjectSession
import com.binaryforge.app.ProjectState
import com.binaryforge.app.data.ManualOptions
import com.binaryforge.app.data.ProjectMeta
import com.binaryforge.app.engine.DeepStatus
import com.binaryforge.app.engine.Engine
import com.binaryforge.app.engine.Summary
import com.binaryforge.app.ui.components.BfButton
import com.binaryforge.app.ui.components.BfHint
import com.binaryforge.app.ui.components.BfPanel
import com.binaryforge.app.ui.components.BfProgressBar
import com.binaryforge.app.ui.components.BfTabBar
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.components.formatDuration
import com.binaryforge.app.ui.theme.Bf

/** Everything a tab needs, plus the callbacks for jumping to another tab. */
class ProjectContext(
    val meta: ProjectMeta,
    val engine: Engine,
    val summary: Summary,
    val deep: DeepStatus?,
    val openHex: (Long) -> Unit,
    val openCode: (Long) -> Unit,
)

private val TAB_TITLES = listOf("Overview", "Sections", "Symbols", "Strings", "Hex", "Code")
private const val TAB_HEX = 4
private const val TAB_CODE = 5

@Composable
fun ProjectScreen(vm: AppViewModel, ps: ProjectSession, onBack: () -> Unit) {
    val state by ps.state.collectAsState()
    val deep by ps.deep.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var hexTarget by remember { mutableStateOf<Long?>(null) }
    var codeTarget by remember { mutableStateOf<Long?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bf.Bg)
    ) {
        TopBar(ps.meta.name, formatBytes(ps.meta.size), onBack)
        when (val s = state) {
            is ProjectState.Loading -> {
                Box(Modifier.fillMaxSize().padding(24.dp)) {
                    BfHint("Reading the file structure...")
                }
            }
            is ProjectState.Failed -> {
                Column(Modifier.padding(16.dp)) {
                    BfPanel(title = "Analysis failed", outline = Bf.Red) {
                        Text(s.message, color = Bf.Text, fontSize = 14.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(10.dp))
                        BfHint("You can still inspect the bytes by opening the file as raw data and choosing the architecture yourself.")
                        Spacer(Modifier.height(10.dp))
                        BfButton("Open as raw data", { vm.reanalyze(ManualOptions(format = "raw")) })
                        Spacer(Modifier.height(8.dp))
                        BfButton("Back", onBack, primary = false)
                    }
                }
            }
            is ProjectState.Ready -> {
                val ctx = ProjectContext(
                    meta = ps.meta,
                    engine = s.engine,
                    summary = s.summary,
                    deep = deep,
                    openHex = { offset ->
                        hexTarget = offset
                        tab = TAB_HEX
                    },
                    openCode = { address ->
                        codeTarget = address
                        tab = TAB_CODE
                    },
                )
                DeepStrip(deep, onCancel = { vm.cancelAnalysis() }, onRestart = { vm.reanalyze(ps.meta.manual) })
                BfTabBar(TAB_TITLES, tab) { tab = it }
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (tab) {
                        0 -> OverviewTab(ctx, vm)
                        1 -> SectionsTab(ctx)
                        2 -> SymbolsTab(ctx)
                        3 -> StringsTab(ctx)
                        TAB_HEX -> HexTab(ctx, hexTarget) { hexTarget = null }
                        else -> CodeTab(ctx, codeTarget) { codeTarget = null }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(name: String, size: String, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Bf.Panel)
            .padding(start = 4.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BfTextButton("Back", onBack, Bf.Muted)
        Column(Modifier.weight(1f)) {
            Text(
                text = name,
                color = Bf.Text,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(size, color = Bf.Muted, fontSize = 11.sp)
        }
    }
}

/** One-line status of the background analysis. */
@Composable
private fun DeepStrip(deep: DeepStatus?, onCancel: () -> Unit, onRestart: () -> Unit) {
    val status = deep ?: DeepStatus(state = "idle")
    Column(
        Modifier
            .fillMaxWidth()
            .background(Bf.PanelHigh)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        when (status.state) {
            "done" -> Text(
                "Analysis complete: ${status.functions} functions, ${status.xrefs} references, ${status.strings} strings in ${formatDuration(status.elapsedMs)}",
                color = Bf.Green,
                fontSize = 12.sp,
            )
            "cancelled" -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Analysis cancelled. Code and string views are incomplete.",
                    color = Bf.Yellow,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                BfTextButton("Restart", onRestart)
            }
            "error" -> Text(
                "Analysis failed: ${status.message}",
                color = Bf.Red,
                fontSize = 12.sp,
            )
            else -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val label = if (status.phase.isEmpty()) "Starting analysis" else status.phase
                    Text(
                        "$label  ${(status.fraction * 100).toInt()}%",
                        color = Bf.Accent,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f),
                    )
                    BfTextButton("Cancel", onCancel, Bf.Muted)
                }
                BfProgressBar(status.fraction)
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}
