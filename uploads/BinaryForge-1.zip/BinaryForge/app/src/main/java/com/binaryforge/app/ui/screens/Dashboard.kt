package com.binaryforge.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.AppViewModel
import com.binaryforge.app.BusyState
import com.binaryforge.app.data.AnalysisSettings
import com.binaryforge.app.data.ProjectMeta
import com.binaryforge.app.data.StorageInfo
import com.binaryforge.app.engine.NativeBridge
import com.binaryforge.app.ui.components.BfButton
import com.binaryforge.app.ui.components.BfDialog
import com.binaryforge.app.ui.components.BfHint
import com.binaryforge.app.ui.components.BfKeyValue
import com.binaryforge.app.ui.components.BfPanel
import com.binaryforge.app.ui.components.BfProgressBar
import com.binaryforge.app.ui.components.BfSectionLabel
import com.binaryforge.app.ui.components.BfStepper
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.components.formatTime
import com.binaryforge.app.ui.theme.Bf

@Composable
private fun HexMark(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val outer = Path().apply {
            moveTo(w * 0.5f, 0f)
            lineTo(w, h * 0.25f)
            lineTo(w, h * 0.75f)
            lineTo(w * 0.5f, h)
            lineTo(0f, h * 0.75f)
            lineTo(0f, h * 0.25f)
            close()
        }
        drawPath(outer, color = Bf.Accent)
        val inner = Path().apply {
            moveTo(w * 0.5f, h * 0.14f)
            lineTo(w * 0.86f, h * 0.35f)
            lineTo(w * 0.86f, h * 0.65f)
            lineTo(w * 0.5f, h * 0.86f)
            lineTo(w * 0.14f, h * 0.65f)
            lineTo(w * 0.14f, h * 0.35f)
            close()
        }
        drawPath(inner, color = Bf.Bg)
        drawRect(color = Bf.Accent, topLeft = Offset(w * 0.3f, h * 0.36f), size = Size(w * 0.4f, h * 0.07f))
        drawRect(color = Bf.Accent, topLeft = Offset(w * 0.3f, h * 0.52f), size = Size(w * 0.28f, h * 0.07f))
    }
}

@Composable
fun DashboardScreen(vm: AppViewModel, onPickFile: () -> Unit) {
    val projects by vm.projects.collectAsState()
    val storage by vm.storage.collectAsState()
    val history by vm.history.collectAsState()
    val busy by vm.busy.collectAsState()
    val settings by vm.settings.collectAsState()
    var showSettings by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ProjectMeta?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Bf.Bg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HexMark(Modifier.size(34.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("BinaryForge", color = Bf.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Offline binary analysis", color = Bf.Muted, fontSize = 13.sp)
                }
                BfTextButton("Limits", { showSettings = true })
            }
        }
        item { ImportPanel(busy, onPickFile, onCancel = { vm.cancelImport() }) }
        item { StatusPanel(busy) }
        item { StoragePanel(storage) }
        item { BfSectionLabel("Recent projects") }
        if (projects.isEmpty()) {
            item { BfHint("No projects yet. Import a file to start an analysis.") }
        }
        items(projects, key = { it.id }) { project ->
            ProjectCard(
                project = project,
                onOpen = { vm.openProject(project) },
                onDelete = { deleteTarget = project },
            )
        }
        item { BfSectionLabel("Analysis history") }
        if (history.isEmpty()) {
            item { BfHint("Nothing recorded yet.") }
        } else {
            item {
                BfPanel {
                    history.forEach { line ->
                        Text(
                            text = line,
                            color = Bf.Muted,
                            fontFamily = Mono,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                        )
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            current = settings,
            onDismiss = { showSettings = false },
            onSave = {
                vm.saveSettings(it)
                showSettings = false
            },
        )
    }
    val target = deleteTarget
    if (target != null) {
        BfDialog(
            title = "Delete project?",
            onDismiss = { deleteTarget = null },
            confirmText = "Delete",
            onConfirm = {
                vm.deleteProject(target)
                deleteTarget = null
            },
        ) {
            Text(
                "${target.name} and its private copy will be removed from this device. The original file you imported is not touched.",
                color = Bf.Muted,
                fontSize = 14.sp,
            )
        }
    }
}

@Composable
private fun ImportPanel(busy: BusyState, onPick: () -> Unit, onCancel: () -> Unit) {
    BfPanel(title = "Import") {
        when (busy) {
            is BusyState.Importing -> {
                val label = if (busy.name.isEmpty()) "file" else busy.name
                Text("Copying $label", color = Bf.Text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                val fraction = if (busy.total > 0) busy.done.toFloat() / busy.total.toFloat() else 0f
                BfProgressBar(fraction)
                Spacer(Modifier.height(6.dp))
                val amount = if (busy.total > 0) {
                    "${formatBytes(busy.done)} of ${formatBytes(busy.total)}"
                } else {
                    formatBytes(busy.done)
                }
                Text(amount, color = Bf.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                BfButton("Cancel import", onCancel, primary = false)
            }
            BusyState.Idle -> {
                BfHint(
                    "Pick any binary: ELF, PE, SO, DLL, BIN, ISO, IMG, DAT or RAW. The file is copied into private storage; the original is never modified or executed."
                )
                Spacer(Modifier.height(10.dp))
                BfButton("Import file", onPick, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun StatusPanel(busy: BusyState) {
    BfPanel(title = "Processing") {
        val state = when (busy) {
            is BusyState.Importing -> "Importing"
            BusyState.Idle -> "Idle"
        }
        BfKeyValue("Status", state, valueColor = if (busy is BusyState.Importing) Bf.Accent else Bf.Green)
        val error = NativeBridge.loadError
        if (error == null) {
            BfKeyValue("Engine", "Rust core ${NativeBridge.version()}", mono = true)
        } else {
            BfKeyValue("Engine", "not loaded: $error", valueColor = Bf.Red)
        }
        BfKeyValue("Network", "none (offline by design)")
    }
}

@Composable
private fun StoragePanel(storage: StorageInfo) {
    BfPanel(title = "Storage") {
        BfKeyValue("Projects", formatBytes(storage.projectBytes))
        BfKeyValue("Free", "${formatBytes(storage.freeBytes)} of ${formatBytes(storage.totalBytes)}")
        val used = if (storage.totalBytes > 0) 1f - storage.freeBytes.toFloat() / storage.totalBytes.toFloat() else 0f
        Spacer(Modifier.height(6.dp))
        BfProgressBar(used)
        Spacer(Modifier.height(4.dp))
        Text("Device storage in use", color = Bf.Dim, fontSize = 11.sp)
    }
}

@Composable
private fun ProjectCard(project: ProjectMeta, onOpen: () -> Unit, onDelete: () -> Unit) {
    BfPanel {
        Text(
            text = project.name,
            color = Bf.Text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        val details = buildString {
            append(formatBytes(project.size))
            if (project.format.isNotEmpty()) append("   ").append(project.format)
            if (project.arch.isNotEmpty()) append("   ").append(project.arch)
        }
        Text(details, color = Bf.Muted, fontSize = 12.sp)
        Text("Opened ${formatTime(project.lastOpenedAt)}", color = Bf.Dim, fontSize = 11.sp)
        Row {
            BfTextButton("Open", onOpen)
            BfTextButton("Delete", onDelete, Bf.Red)
        }
    }
}

@Composable
private fun SettingsDialog(
    current: AnalysisSettings,
    onDismiss: () -> Unit,
    onSave: (AnalysisSettings) -> Unit,
) {
    var threads by remember { mutableStateOf(current.threads) }
    var memory by remember { mutableStateOf(current.memoryMb) }
    var minString by remember { mutableStateOf(current.minStringLen) }
    BfDialog(
        title = "Analysis limits",
        onDismiss = onDismiss,
        confirmText = "Save",
        onConfirm = { onSave(AnalysisSettings(threads, memory, minString)) },
    ) {
        Column {
            BfHint("Lower these on devices that get hot or run low on memory. They apply to the next analysis.")
            Spacer(Modifier.height(8.dp))
            BfStepper("Worker threads", threads, { threads = it }, min = 1, max = 8)
            BfStepper("Memory budget", memory, { memory = it }, min = 64, max = 2048, step = 64, suffix = " MB")
            BfStepper("Minimum string length", minString, { minString = it }, min = 2, max = 16)
        }
    }
}
