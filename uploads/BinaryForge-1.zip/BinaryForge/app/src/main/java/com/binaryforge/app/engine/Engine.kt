package com.binaryforge.app.engine

import org.json.JSONObject

/**
 * Kotlin face of one native analysis session. All methods block, so call them from a
 * background dispatcher. Failures from the engine surface as [EngineException].
 */
class Engine private constructor(private val handle: Long) {
    @Volatile
    private var closed = false

    companion object {
        fun open(path: String, options: String): Engine {
            if (!NativeBridge.isAvailable) {
                throw EngineException("The native engine could not be loaded: ${NativeBridge.loadError}")
            }
            val text = NativeBridge.nativeOpen(path, options)
                ?: throw EngineException("The native engine returned no data.")
            val json = JSONObject(text)
            if (json.has("error")) throw EngineException(json.getString("error"))
            return Engine(json.getLong("handle"))
        }
    }

    private fun call(block: () -> String?): JSONObject {
        if (closed) throw EngineException("The project is closed.")
        val text = block() ?: throw EngineException("The native engine returned no data.")
        val json = JSONObject(text)
        if (json.has("error")) throw EngineException(json.getString("error"))
        return json
    }

    fun analyze(): Summary = parseSummary(call { NativeBridge.nativeAnalyze(handle) })

    /** Blocks until the deep analysis has finished or been cancelled. */
    fun deepAnalyze(): DeepStatus = parseStatus(call { NativeBridge.nativeDeepAnalyze(handle) })

    fun status(): DeepStatus = parseStatus(call { NativeBridge.nativeStatus(handle) })

    fun cancel() {
        if (!closed) NativeBridge.nativeCancel(handle)
    }

    fun read(offset: Long, length: Int): ByteArray {
        if (closed) return ByteArray(0)
        return NativeBridge.nativeRead(handle, offset, length) ?: ByteArray(0)
    }

    /** First offset at or after [from] where [patternHex] occurs: >= 0 found, -1 none, -2 invalid. */
    fun find(from: Long, patternHex: String): Long {
        if (closed) return -2L
        return NativeBridge.nativeFind(handle, from, patternHex)
    }

    private fun query(what: String, arg: String, offset: Int, limit: Int, filter: String): JSONObject =
        call { NativeBridge.nativeQuery(handle, what, arg, offset, limit, filter) }

    fun functions(offset: Int, limit: Int, filter: String): Page<FunctionRow> =
        parsePage(query("functions", "", offset, limit, filter), ::parseFunctionRow)

    /** [kind]: all, func, object, import or export. */
    fun symbols(kind: String, offset: Int, limit: Int, filter: String): Page<SymbolRow> =
        parsePage(query("symbols", kind, offset, limit, filter), ::parseSymbolRow)

    fun imports(offset: Int, limit: Int, filter: String): Page<ImportRow> =
        parsePage(query("imports", "", offset, limit, filter), ::parseImportRow)

    fun strings(offset: Int, limit: Int, filter: String): Page<StringRow> =
        parsePage(query("strings", "", offset, limit, filter), ::parseStringRow)

    fun xrefsTo(address: Long, offset: Int, limit: Int): Page<XrefRow> =
        parsePage(query("xrefs", hex(address), offset, limit, ""), ::parseXrefRow)

    fun disassemble(address: Long, count: Int): Listing =
        parseListing(call { NativeBridge.nativeDisassemble(handle, address, count) })

    fun functionDetail(address: Long): FunctionDetail =
        parseFunctionDetail(call { NativeBridge.nativeFunctionDetail(handle, address) })

    fun close() {
        if (!closed) {
            closed = true
            NativeBridge.nativeClose(handle)
        }
    }
}
