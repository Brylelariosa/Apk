package com.binaryforge.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.ui.theme.Bf
import java.util.Locale

val Mono: FontFamily = FontFamily.Monospace

// ---- formatting ----------------------------------------------------------------------------

fun formatBytes(n: Long): String {
    if (n < 1024) return "$n B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = n.toDouble()
    var i = -1
    while (v >= 1024.0 && i < units.size - 1) {
        v /= 1024.0
        i++
    }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun hexPad(value: Long, width: Int = 8): String =
    java.lang.Long.toHexString(value).padStart(width, '0')

fun formatTime(ms: Long): String {
    if (ms <= 0L) return "-"
    return java.text.SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(java.util.Date(ms))
}

fun formatDuration(ms: Long): String {
    if (ms < 1000) return "$ms ms"
    return String.format(Locale.US, "%.1f s", ms / 1000.0)
}

fun confidenceColor(confidence: String): Color = when (confidence) {
    "verified" -> Bf.Green
    "likely" -> Bf.Cyan
    "estimated" -> Bf.Yellow
    "assumed" -> Bf.Violet
    else -> Bf.Dim
}

// ---- building blocks -----------------------------------------------------------------------

@Composable
fun BfPanel(
    modifier: Modifier = Modifier,
    title: String? = null,
    outline: Color = Bf.Border,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(8.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Bf.Panel)
            .border(1.dp, outline, shape)
            .padding(12.dp)
    ) {
        if (title != null) {
            Text(
                text = title.uppercase(),
                color = Bf.Muted,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp,
            )
            Spacer(Modifier.height(8.dp))
        }
        content()
    }
}

@Composable
fun BfKeyValue(key: String, value: String, mono: Boolean = false, valueColor: Color = Bf.Text) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = key,
            color = Bf.Muted,
            fontSize = 13.sp,
            modifier = Modifier.width(112.dp),
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = 13.sp,
            fontFamily = if (mono) Mono else FontFamily.Default,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
fun BfTag(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp,
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp),
    )
}

@Composable
fun BfConfidenceTag(confidence: String, modifier: Modifier = Modifier) {
    BfTag(confidence.uppercase(), confidenceColor(confidence), modifier)
}

@Composable
fun BfSectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        color = Bf.Muted,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.4.sp,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
    )
}

@Composable
fun BfHint(text: String, color: Color = Bf.Muted) {
    Text(text = text, color = color, fontSize = 13.sp, lineHeight = 18.sp)
}

@Composable
fun BfTabBar(titles: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Bf.Panel)
            .horizontalScroll(rememberScrollState())
    ) {
        titles.forEachIndexed { index, title ->
            val active = index == selected
            Column(
                modifier = Modifier
                    .clickable { onSelect(index) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = title.uppercase(),
                    color = if (active) Bf.Accent else Bf.Muted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp,
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .height(2.dp)
                        .width(24.dp)
                        .background(if (active) Bf.Accent else Color.Transparent)
                )
            }
        }
    }
}

@Composable
fun BfProgressBar(fraction: Float, modifier: Modifier = Modifier) {
    val f = if (fraction.isNaN()) 0f else fraction.coerceIn(0f, 1f)
    Box(
        modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Bf.PanelHigh)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(f)
                .background(Bf.Accent)
        )
    }
}

@Composable
fun BfButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(6.dp)
    if (primary) {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Bf.Accent,
                contentColor = Bf.OnAccent,
                disabledContainerColor = Bf.PanelHigh,
                disabledContentColor = Bf.Dim,
            ),
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            shape = shape,
            border = BorderStroke(1.dp, Bf.Border),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Bf.Text,
                disabledContentColor = Bf.Dim,
            ),
        ) {
            Text(text)
        }
    }
}

@Composable
fun BfTextButton(text: String, onClick: () -> Unit, color: Color = Bf.Accent) {
    TextButton(onClick = onClick) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun BfField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    onSubmit: (() -> Unit)? = null,
) {
    val shape = RoundedCornerShape(6.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(color = Bf.Text, fontSize = 14.sp, fontFamily = Mono),
        cursorBrush = SolidColor(Bf.Accent),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onSubmit?.invoke() }),
        modifier = modifier,
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Bf.PanelHigh)
                    .border(1.dp, Bf.Border, shape)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                if (value.isEmpty()) {
                    Text(hint, color = Bf.Dim, fontSize = 14.sp)
                }
                inner()
            }
        },
    )
}

/** A dialog in the BinaryForge style with an optional confirm action. */
@Composable
fun BfDialog(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String? = null,
    onConfirm: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Bf.Panel,
        titleContentColor = Bf.Text,
        textContentColor = Bf.Text,
        title = { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp) },
        text = { content() },
        confirmButton = {
            if (confirmText != null && onConfirm != null) {
                BfTextButton(confirmText, onConfirm)
            }
        },
        dismissButton = {
            BfTextButton(if (confirmText != null) "Cancel" else "Close", onDismiss, Bf.Muted)
        },
    )
}

@Composable
fun BfStepper(
    label: String,
    value: Int,
    onChange: (Int) -> Unit,
    min: Int,
    max: Int,
    step: Int = 1,
    suffix: String = "",
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Bf.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        BfTextButton("-", { onChange((value - step).coerceAtLeast(min)) }, Bf.Text)
        Text(
            text = "$value$suffix",
            color = Bf.Accent,
            fontFamily = Mono,
            fontSize = 14.sp,
            modifier = Modifier.width(72.dp),
        )
        BfTextButton("+", { onChange((value + step).coerceAtMost(max)) }, Bf.Text)
    }
}

/** A selectable pill, used for filters and mode switches. */
@Composable
fun BfChoice(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Text(
        text = text,
        color = if (selected) Bf.OnAccent else Bf.Text,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .padding(end = 6.dp)
            .clip(shape)
            .background(if (selected) Bf.Accent else Bf.PanelHigh)
            .border(1.dp, if (selected) Bf.Accent else Bf.Border, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}
