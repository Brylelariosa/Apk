package com.binaryforge.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.engine.Engine
import com.binaryforge.app.engine.FunctionDetail
import com.binaryforge.app.engine.FunctionRow
import com.binaryforge.app.engine.InsnRow
import com.binaryforge.app.engine.Page
import com.binaryforge.app.engine.XrefRow
import com.binaryforge.app.engine.hex
import com.binaryforge.app.engine.parseAddr
import com.binaryforge.app.ui.components.BfButton
import com.binaryforge.app.ui.components.BfChoice
import com.binaryforge.app.ui.components.BfConfidenceTag
import com.binaryforge.app.ui.components.BfDialog
import com.binaryforge.app.ui.components.BfField
import com.binaryforge.app.ui.components.BfHint
import com.binaryforge.app.ui.components.BfKeyValue
import com.binaryforge.app.ui.components.BfPagedList
import com.binaryforge.app.ui.components.BfPanel
import com.binaryforge.app.ui.components.BfSectionLabel
import com.binaryforge.app.ui.components.BfTabBar
import com.binaryforge.app.ui.components.BfTag
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.PagedState
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.components.hexPad
import com.binaryforge.app.ui.theme.Bf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val LISTING_PAGE = 200

/** Instructions shown in the listing, loaded in pages as the user scrolls. */
class ListingState(private val engine: Engine) {
    val rows = mutableStateListOf<InsnRow>()

    var error by mutableStateOf<String?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var endReached by mutableStateOf(false)
        private set
    var start by mutableStateOf<Long?>(null)
        private set
    var historySize by mutableStateOf(0)
        private set

    private var next = 0L
    private var generation = 0
    private val history = ArrayList<Long>()

    suspend fun goTo(address: Long, push: Boolean = true) {
        val current = start
        if (push && current != null && current != address) {
            history.add(current)
            historySize = history.size
        }
        generation++
        start = address
        next = address
        rows.clear()
        endReached = false
        error = null
        loading = false
        loadMore()
    }

    suspend fun goBack() {
        if (history.isEmpty()) return
        val previous = history.removeAt(history.size - 1)
        historySize = history.size
        goTo(previous, push = false)
    }

    suspend fun loadMore() {
        if (loading || endReached || start == null) return
        loading = true
        val gen = generation
        val from = next
        try {
            val listing = withContext(Dispatchers.IO) { engine.disassemble(from, LISTING_PAGE) }
            if (gen == generation) {
                rows.addAll(listing.insns)
                next = listing.next
                endReached = listing.end || listing.insns.isEmpty()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (gen == generation) {
                error = e.message ?: "The disassembly failed."
                endReached = true
            }
        } finally {
            if (gen == generation) loading = false
        }
    }
}

@Composable
fun CodeTab(ctx: ProjectContext, jumpTo: Long?, onJumpConsumed: () -> Unit) {
    val engine = ctx.engine
    val scope = rememberCoroutineScope()
    val listing = remember(engine) { ListingState(engine) }
    var mode by remember { mutableStateOf(0) }
    var xrefTarget by remember { mutableStateOf<Long?>(null) }
    var detailTarget by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(jumpTo) {
        if (jumpTo != null) {
            mode = 1
            listing.goTo(jumpTo)
            onJumpConsumed()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (!ctx.summary.disassemblerAvailable) {
            Column(Modifier.padding(12.dp)) {
                BfPanel(outline = Bf.Yellow) {
                    Text(
                        "No disassembler is available for ${ctx.summary.archName} in this build. The function list comes from symbols and file metadata. Use the hex view to inspect the bytes.",
                        color = Bf.Yellow,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                    )
                }
            }
        }
        BfTabBar(listOf("Functions", "Listing"), mode) { mode = it }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (mode == 0) {
                FunctionsView(
                    ctx = ctx,
                    onOpen = { address ->
                        scope.launch {
                            mode = 1
                            listing.goTo(address)
                        }
                    },
                    onInfo = { detailTarget = it },
                )
            } else {
                ListingView(
                    ctx = ctx,
                    listing = listing,
                    onXref = { xrefTarget = it },
                    onInfo = { detailTarget = it },
                )
            }
        }
    }

    val xref = xrefTarget
    if (xref != null) {
        XrefDialog(
            engine = engine,
            address = xref,
            onGoto = { address ->
                xrefTarget = null
                scope.launch {
                    mode = 1
                    listing.goTo(address)
                }
            },
            onDismiss = { xrefTarget = null },
        )
    }
    val detail = detailTarget
    if (detail != null) {
        FunctionDetailDialog(
            engine = engine,
            address = detail,
            onGoto = { address ->
                detailTarget = null
                scope.launch {
                    mode = 1
                    listing.goTo(address)
                }
            },
            onDismiss = { detailTarget = null },
        )
    }
}

@Composable
private fun FunctionsView(ctx: ProjectContext, onOpen: (Long) -> Unit, onInfo: (Long) -> Unit) {
    val engine = ctx.engine
    val ready = ctx.deep?.deepReady == true
    val running = ctx.deep?.running == true
    val canOpen = ctx.summary.disassemblerAvailable
    val state = remember(engine, ready) {
        PagedState<FunctionRow> { offset, limit, filter -> engine.functions(offset, limit, filter) }
    }
    var query by remember { mutableStateOf("") }
    BfPagedList(
        state = state,
        query = query,
        onQueryChange = { query = it },
        hint = "Search functions by name or address",
        unitLabel = "functions",
        notReadyText = if (running) "Functions appear when the analysis has finished." else "Functions are not available.",
        emptyText = "No functions were found.",
    ) { fn -> FunctionItem(fn, canOpen, onOpen, onInfo) }
}

@Composable
private fun FunctionItem(fn: FunctionRow, canOpen: Boolean, onOpen: (Long) -> Unit, onInfo: (Long) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = canOpen) { onOpen(fn.start) }
            .padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = fn.name,
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hexPad(fn.start, 8), color = Bf.Cyan, fontFamily = Mono, fontSize = 11.sp)
                Text(
                    "   ${formatBytes(fn.size)}   ${fn.refsIn} refs",
                    color = Bf.Muted,
                    fontSize = 11.sp,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                BfConfidenceTag(fn.confidence)
                Spacer(Modifier.width(6.dp))
                if (fn.boundsConfidence != "verified") {
                    BfTag("END ESTIMATED", Bf.Yellow)
                    Spacer(Modifier.width(6.dp))
                }
                Text(fn.source, color = Bf.Dim, fontSize = 11.sp)
            }
        }
        BfTextButton("Info", { onInfo(fn.start) }, Bf.Muted)
    }
}

private fun flowColor(flow: String, valid: Boolean): Color = when {
    !valid -> Bf.Dim
    flow == "call" || flow == "indirect_call" -> Bf.Accent
    flow == "jump" || flow == "cond_jump" || flow == "indirect_jump" -> Bf.Blue
    flow == "return" -> Bf.Red
    flow == "trap" -> Bf.Yellow
    else -> Bf.Text
}

private fun shortBytes(hexText: String): String =
    if (hexText.length > 12) hexText.substring(0, 12) + "+" else hexText

@Composable
private fun ListingView(
    ctx: ProjectContext,
    listing: ListingState,
    onXref: (Long) -> Unit,
    onInfo: (Long) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var addrText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val hScroll = rememberScrollState()
    val digits = remember(ctx.summary) {
        if (ctx.summary.codeRegions.any { it.va + it.size > 0xffffffffL }) 12 else 8
    }
    val canList = ctx.summary.disassemblerAvailable

    LaunchedEffect(listing, listState) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last ->
                if (last >= listing.rows.size - 20) listing.loadMore()
            }
    }
    BackHandler(enabled = listing.historySize > 0) {
        scope.launch { listing.goBack() }
    }

    fun go() {
        val address = parseAddr(addrText)
        if (address != null && canList) {
            scope.launch { listing.goTo(address) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BfTextButton(
                "Back",
                { scope.launch { listing.goBack() } },
                if (listing.historySize > 0) Bf.Accent else Bf.Dim,
            )
            BfField(
                value = addrText,
                onValueChange = { addrText = it },
                hint = "Address (hex)",
                modifier = Modifier.weight(1f),
                onSubmit = { go() },
            )
            Spacer(Modifier.width(8.dp))
            BfButton("Go", { go() }, primary = false, enabled = canList)
        }
        if (canList) {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp)
            ) {
                val entry = ctx.summary.entryPoints.firstOrNull()
                if (entry != null) {
                    BfChoice("Entry", false) { scope.launch { listing.goTo(entry.va) } }
                }
                ctx.summary.codeRegions.take(4).forEach { region ->
                    BfChoice(region.name, false) { scope.launch { listing.goTo(region.va) } }
                }
            }
        }
        val err = listing.error
        if (err != null) {
            Text(err, color = Bf.Red, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
        }
        if (listing.start == null) {
            Box(Modifier.padding(16.dp)) {
                BfHint(
                    if (canList) {
                        "Pick a function, an entry point or a code region, or type an address. Tap an address to see what references it, tap a branch target to follow it, tap a function name for its statistics."
                    } else {
                        "Disassembly is not available for this architecture in this build."
                    }
                )
            }
        } else {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .horizontalScroll(hScroll)
            ) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxHeight()) {
                    items(listing.rows) { row ->
                        InsnLine(row, digits, onXref, onInfo) { target ->
                            scope.launch { listing.goTo(target) }
                        }
                    }
                    if (listing.loading) {
                        item {
                            Text("Loading...", color = Bf.Muted, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsnLine(
    row: InsnRow,
    digits: Int,
    onXref: (Long) -> Unit,
    onInfo: (Long) -> Unit,
    onGoto: (Long) -> Unit,
) {
    Column(Modifier.padding(horizontal = 8.dp)) {
        val func = row.func
        if (func != null) {
            Text(
                text = "$func:",
                color = Bf.Accent,
                fontFamily = Mono,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                softWrap = false,
                modifier = Modifier
                    .padding(top = 10.dp, bottom = 2.dp)
                    .clickable { onInfo(row.addr) },
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = hexPad(row.addr, digits),
                color = if (row.valid) Bf.Cyan else Bf.Dim,
                fontFamily = Mono,
                fontSize = 12.sp,
                softWrap = false,
                modifier = Modifier
                    .clickable { onXref(row.addr) }
                    .padding(end = 10.dp),
            )
            Text(
                text = shortBytes(row.bytes),
                color = Bf.Dim,
                fontFamily = Mono,
                fontSize = 12.sp,
                softWrap = false,
                modifier = Modifier.width(96.dp),
            )
            val target = row.target
            val body = remember(row) {
                buildAnnotatedString {
                    withStyle(SpanStyle(color = flowColor(row.flow, row.valid))) {
                        append(row.mnem.padEnd(8))
                    }
                    append(" ")
                    withStyle(
                        SpanStyle(
                            color = if (row.target != null) Bf.Blue else Bf.Text,
                            textDecoration = if (row.target != null) TextDecoration.Underline else null,
                        )
                    ) {
                        append(row.ops)
                    }
                }
            }
            Text(
                text = body,
                fontFamily = Mono,
                fontSize = 12.sp,
                softWrap = false,
                modifier = if (target != null) Modifier.clickable { onGoto(target) } else Modifier,
            )
            val note = remember(row) { listOfNotNull(row.targetLabel, row.comment).joinToString("  ") }
            if (note.isNotEmpty()) {
                Text(
                    text = "   ; $note",
                    color = Bf.Green,
                    fontFamily = Mono,
                    fontSize = 12.sp,
                    softWrap = false,
                )
            }
        }
    }
}

@Composable
private fun XrefDialog(engine: Engine, address: Long, onGoto: (Long) -> Unit, onDismiss: () -> Unit) {
    var page by remember(address) { mutableStateOf<Page<XrefRow>?>(null) }
    var error by remember(address) { mutableStateOf<String?>(null) }
    LaunchedEffect(address) {
        try {
            page = withContext(Dispatchers.IO) { engine.xrefsTo(address, 0, 200) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "The query failed."
        }
    }
    BfDialog("References to ${hex(address)}", onDismiss) {
        val p = page
        val err = error
        when {
            err != null -> Text(err, color = Bf.Red, fontSize = 13.sp)
            p == null -> Text("Loading...", color = Bf.Muted, fontSize = 13.sp)
            !p.ready -> Text("References are available after the analysis finishes.", color = Bf.Muted, fontSize = 13.sp)
            p.items.isEmpty() -> Text("Nothing references this address.", color = Bf.Muted, fontSize = 13.sp)
            else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(p.items) { x ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onGoto(x.from) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(hex(x.from), color = Bf.Cyan, fontFamily = Mono, fontSize = 12.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                if (x.func.isEmpty()) "(outside any known function)" else x.func,
                                color = Bf.Text,
                                fontSize = 13.sp,
                            )
                            Text(x.kind, color = Bf.Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FunctionDetailDialog(engine: Engine, address: Long, onGoto: (Long) -> Unit, onDismiss: () -> Unit) {
    var detail by remember(address) { mutableStateOf<FunctionDetail?>(null) }
    var error by remember(address) { mutableStateOf<String?>(null) }
    LaunchedEffect(address) {
        try {
            detail = withContext(Dispatchers.IO) { engine.functionDetail(address) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "The query failed."
        }
    }
    BfDialog("Function", onDismiss) {
        val d = detail
        val err = error
        Column(
            Modifier
                .heightIn(max = 460.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when {
                err != null -> Text(err, color = Bf.Red, fontSize = 13.sp)
                d == null -> Text("Analyzing...", color = Bf.Muted, fontSize = 13.sp)
                else -> DetailBody(d, onGoto)
            }
        }
    }
}

@Composable
private fun DetailBody(d: FunctionDetail, onGoto: (Long) -> Unit) {
    Text(d.name, color = Bf.Accent, fontFamily = Mono, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    Text(
        "${hex(d.start)} - ${hex(d.end)}   ${formatBytes(d.size)}",
        color = Bf.Cyan,
        fontFamily = Mono,
        fontSize = 12.sp,
    )
    Spacer(Modifier.padding(top = 6.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        BfConfidenceTag(d.confidence)
        Spacer(Modifier.width(6.dp))
        if (d.boundsConfidence == "verified") {
            BfTag("END ${d.bounds.uppercase()}", Bf.Green)
        } else {
            BfTag("END ESTIMATED", Bf.Yellow)
        }
    }
    Spacer(Modifier.padding(top = 6.dp))
    BfKeyValue("Source", d.source)
    val parent = d.parent
    if (parent != null) BfKeyValue("Fragment of", hex(parent), mono = true)
    val undecoded = if (d.undecoded > 0) " (${d.undecoded} undecoded units)" else ""
    BfKeyValue("Instructions", "${d.instructions}$undecoded")
    if (d.truncated) BfHint("Only the first 1 MiB of this function was analyzed.")

    if (d.flowCounts.isNotEmpty()) {
        BfSectionLabel("Control flow")
        Text(
            d.flowCounts.joinToString("   ") { "${it.first} ${it.second}" },
            color = Bf.Text,
            fontFamily = Mono,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
    }
    if (d.registers.isNotEmpty()) {
        BfSectionLabel("Registers referenced")
        Text(d.registers.joinToString(" "), color = Bf.Text, fontFamily = Mono, fontSize = 12.sp, lineHeight = 17.sp)
    }
    if (d.calls.isNotEmpty()) {
        BfSectionLabel("Direct calls (${d.calls.size})")
        d.calls.forEach { c ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onGoto(c.target) }
                    .padding(vertical = 4.dp)
            ) {
                Text(hex(c.target), color = Bf.Cyan, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "${c.name ?: ""}   x${c.count}",
                    color = Bf.Text,
                    fontFamily = Mono,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
    if (d.dataRefs.isNotEmpty()) {
        BfSectionLabel("Data references (${d.dataRefs.size})")
        d.dataRefs.forEach { r ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text(hex(r.addr), color = Bf.Cyan, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Text(r.label ?: "", color = Bf.Green, fontFamily = Mono, fontSize = 12.sp, modifier = Modifier.weight(1f))
            }
        }
    }
    BfSectionLabel("Callers (${d.callersTotal})")
    if (d.callers.isEmpty()) {
        BfHint("No direct references were found. Indirect calls and data tables cannot be resolved statically.")
    }
    d.callers.forEach { x ->
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onGoto(x.from) }
                .padding(vertical = 4.dp)
        ) {
            Text(hex(x.from), color = Bf.Cyan, fontFamily = Mono, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                "${x.func}   ${x.kind}",
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f),
            )
        }
    }
}
