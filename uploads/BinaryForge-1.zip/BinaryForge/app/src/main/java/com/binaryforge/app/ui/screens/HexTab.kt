package com.binaryforge.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.engine.Engine
import com.binaryforge.app.engine.hex
import com.binaryforge.app.engine.parseAddr
import com.binaryforge.app.ui.components.BfButton
import com.binaryforge.app.ui.components.BfChoice
import com.binaryforge.app.ui.components.BfField
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.hexPad
import com.binaryforge.app.ui.theme.Bf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val HEX_PAGE = 4096
private const val HEX_DIGITS = "0123456789abcdef"

/** A small cache of 4 KiB pages so scrolling never waits on the engine for visible rows. */
private class HexPages(private val engine: Engine) {
    val pages = mutableStateMapOf<Long, ByteArray>()
    private val order = ArrayDeque<Long>()
    private val inFlight = HashSet<Long>()

    suspend fun ensure(page: Long) {
        if (page < 0L || pages.containsKey(page) || !inFlight.add(page)) return
        try {
            val data = withContext(Dispatchers.IO) { engine.read(page * HEX_PAGE, HEX_PAGE) }
            pages[page] = data
            order.addLast(page)
            while (order.size > 160) {
                pages.remove(order.removeFirst())
            }
        } finally {
            inFlight.remove(page)
        }
    }
}

@Composable
fun HexTab(ctx: ProjectContext, jumpTo: Long?, onJumpConsumed: () -> Unit) {
    val engine = ctx.engine
    val size = ctx.summary.size
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val pages = remember(engine) { HexPages(engine) }
    var gotoText by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var textMode by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var lastFound by remember { mutableStateOf(-1L) }
    var highlight by remember { mutableStateOf(-1L) }
    // Bytes per row follows the available width; kept out of Compose state because it is only
    // read from event handlers.
    val rowSize = remember { IntArray(1) { 8 } }

    fun scrollToOffset(offset: Long) {
        val row = offset / rowSize[0]
        scope.launch { listState.scrollToItem(row.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()) }
    }

    fun goTo() {
        val offset = parseAddr(gotoText)
        if (offset == null || offset < 0L || offset >= size) {
            status = "Enter an offset between 0x0 and ${hex(size - 1)}"
            return
        }
        status = ""
        highlight = offset
        scrollToOffset(offset)
    }

    fun find() {
        val pattern = if (textMode) {
            findText.toByteArray(Charsets.UTF_8).joinToString("") { b -> "%02x".format(b) }
        } else {
            findText.filter { !it.isWhitespace() }
        }
        if (pattern.isEmpty()) return
        val start = if (lastFound >= 0L) lastFound + 1 else listState.firstVisibleItemIndex.toLong() * rowSize[0]
        scope.launch {
            val result = withContext(Dispatchers.IO) { engine.find(start, pattern) }
            when {
                result >= 0L -> {
                    lastFound = result
                    highlight = result
                    status = "Found at ${hex(result)}"
                    scrollToOffset(result)
                }
                result == -1L -> {
                    lastFound = -1L
                    status = "No further match."
                }
                else -> status = "Invalid pattern. Use hex bytes such as 7f 45 4c 46."
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 4.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                BfField(
                    value = gotoText,
                    onValueChange = { gotoText = it },
                    hint = "Go to offset (hex)",
                    modifier = Modifier.weight(1f),
                    onSubmit = { goTo() },
                )
                Spacer(Modifier.width(8.dp))
                BfButton("Go", { goTo() }, primary = false)
            }
            Spacer(Modifier.padding(top = 6.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                BfChoice("HEX", !textMode) {
                    textMode = false
                    lastFound = -1L
                }
                BfChoice("TEXT", textMode) {
                    textMode = true
                    lastFound = -1L
                }
                BfField(
                    value = findText,
                    onValueChange = {
                        findText = it
                        lastFound = -1L
                    },
                    hint = if (textMode) "Find text" else "Find hex bytes",
                    modifier = Modifier.weight(1f),
                    onSubmit = { find() },
                )
                Spacer(Modifier.width(8.dp))
                BfButton("Find", { find() }, primary = false)
            }
            if (status.isNotEmpty()) {
                Text(status, color = Bf.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val perRow = if (maxWidth >= 520.dp) 16 else 8
            rowSize[0] = perRow
            val rowCount = ((size + perRow - 1) / perRow).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            val digits = maxOf(6, java.lang.Long.toHexString(size).length)
            val fontSize = if (perRow == 16) 11.sp else 12.sp

            LaunchedEffect(listState, pages, perRow) {
                snapshotFlow { listState.firstVisibleItemIndex }.collect { first ->
                    val page = (first.toLong() * perRow) / HEX_PAGE
                    var p = page - 1
                    while (p <= page + 3) {
                        pages.ensure(p)
                        p++
                    }
                }
            }
            LaunchedEffect(jumpTo, perRow) {
                if (jumpTo != null) {
                    highlight = jumpTo
                    scrollToOffset(jumpTo)
                    onJumpConsumed()
                }
            }

            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                items(rowCount) { row ->
                    val rowStart = row.toLong() * perRow
                    val page = rowStart / HEX_PAGE
                    val inPage = (rowStart % HEX_PAGE).toInt()
                    val bytes = pages.pages[page]
                    val selected = highlight >= rowStart && highlight < rowStart + perRow
                    HexRow(rowStart, perRow, bytes, inPage, digits, selected, fontSize)
                }
            }
        }
    }
}

@Composable
private fun HexRow(
    rowStart: Long,
    perRow: Int,
    bytes: ByteArray?,
    inPage: Int,
    digits: Int,
    selected: Boolean,
    fontSize: androidx.compose.ui.unit.TextUnit,
) {
    val text = remember(rowStart, bytes, perRow, digits) {
        buildAnnotatedString {
            withStyle(SpanStyle(color = Bf.Cyan)) { append(hexPad(rowStart, digits)) }
            append("  ")
            val hexPart = StringBuilder()
            val ascii = StringBuilder()
            for (i in 0 until perRow) {
                val index = inPage + i
                if (bytes != null && index < bytes.size) {
                    val v = bytes[index].toInt() and 0xff
                    hexPart.append(HEX_DIGITS[v shr 4]).append(HEX_DIGITS[v and 15]).append(' ')
                    ascii.append(if (v in 32..126) v.toChar() else '.')
                } else if (bytes == null) {
                    hexPart.append(".. ")
                    ascii.append(' ')
                } else {
                    hexPart.append("   ")
                    ascii.append(' ')
                }
                if (i == perRow / 2 - 1) hexPart.append(' ')
            }
            withStyle(SpanStyle(color = Bf.Text)) { append(hexPart.toString()) }
            append(" ")
            withStyle(SpanStyle(color = Bf.Muted)) { append(ascii.toString()) }
        }
    }
    Text(
        text = text,
        fontFamily = Mono,
        fontSize = fontSize,
        softWrap = false,
        maxLines = 1,
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) Bf.PanelHigh else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 1.dp),
    )
}
