package com.binaryforge.app.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** A project is a private copy of an imported file plus a small metadata record. */
data class ProjectMeta(
    val id: String,
    val name: String,
    val size: Long,
    val sha256: String,
    val importedAt: Long,
    val lastOpenedAt: Long,
    val format: String,
    val arch: String,
    val manual: ManualOptions,
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("size", size)
        o.put("sha256", sha256)
        o.put("importedAt", importedAt)
        o.put("lastOpenedAt", lastOpenedAt)
        o.put("format", format)
        o.put("arch", arch)
        val m = JSONObject()
        m.put("format", manual.format)
        m.put("arch", manual.arch)
        m.put("base", manual.base)
        m.put("entry", manual.entry)
        o.put("manual", m)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): ProjectMeta {
            val m = o.optJSONObject("manual")
            return ProjectMeta(
                id = o.getString("id"),
                name = o.optString("name", "unnamed"),
                size = o.optLong("size", 0L),
                sha256 = o.optString("sha256", ""),
                importedAt = o.optLong("importedAt", 0L),
                lastOpenedAt = o.optLong("lastOpenedAt", 0L),
                format = o.optString("format", ""),
                arch = o.optString("arch", ""),
                manual = ManualOptions(
                    format = m?.optString("format", "auto") ?: "auto",
                    arch = m?.optString("arch", "") ?: "",
                    base = m?.optString("base", "") ?: "",
                    entry = m?.optString("entry", "") ?: "",
                ),
            )
        }
    }
}

data class StorageInfo(val projectBytes: Long, val freeBytes: Long, val totalBytes: Long)

class ProjectStore(context: Context) {
    private val filesDir: File = context.filesDir
    private val root = File(filesDir, "projects")
    private val historyFile = File(filesDir, "history.log")

    init {
        root.mkdirs()
    }

    fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    fun projectDir(id: String): File = File(root, id)

    /** The private, read-only-by-convention copy of the imported file. */
    fun sourceFile(id: String): File = File(projectDir(id), "source.bin")

    private fun metaFile(id: String): File = File(projectDir(id), "meta.json")

    fun list(): List<ProjectMeta> {
        val dirs = root.listFiles() ?: return emptyList()
        val out = ArrayList<ProjectMeta>()
        for (dir in dirs) {
            val meta = File(dir, "meta.json")
            if (!dir.isDirectory || !meta.isFile) continue
            try {
                out.add(ProjectMeta.fromJson(JSONObject(meta.readText())))
            } catch (e: Exception) {
                // A damaged record is skipped; the project files stay untouched.
            }
        }
        return out.sortedByDescending { it.lastOpenedAt }
    }

    fun save(meta: ProjectMeta) {
        projectDir(meta.id).mkdirs()
        val tmp = File(projectDir(meta.id), "meta.json.tmp")
        tmp.writeText(meta.toJson().toString())
        val target = metaFile(meta.id)
        if (!tmp.renameTo(target)) {
            target.writeText(meta.toJson().toString())
            tmp.delete()
        }
    }

    fun delete(id: String) {
        projectDir(id).deleteRecursively()
    }

    fun storageInfo(): StorageInfo {
        var used = 0L
        root.walkTopDown().forEach { f -> if (f.isFile) used += f.length() }
        return StorageInfo(used, filesDir.usableSpace, filesDir.totalSpace)
    }

    fun appendHistory(line: String) {
        try {
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
                .format(java.util.Date())
            historyFile.appendText("$stamp  $line\n")
            val lines = historyFile.readLines()
            if (lines.size > 200) {
                historyFile.writeText(lines.takeLast(100).joinToString("\n", postfix = "\n"))
            }
        } catch (e: Exception) {
            // History is a convenience; never fail an operation because of it.
        }
    }

    fun readHistory(limit: Int): List<String> {
        return try {
            if (!historyFile.isFile) emptyList() else historyFile.readLines().takeLast(limit).reversed()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
