package com.binaryforge.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binaryforge.app.engine.CodeRegionInfo
import com.binaryforge.app.engine.SectionInfo
import com.binaryforge.app.engine.SegmentInfo
import com.binaryforge.app.engine.hex
import com.binaryforge.app.ui.components.BfConfidenceTag
import com.binaryforge.app.ui.components.BfHint
import com.binaryforge.app.ui.components.BfPanel
import com.binaryforge.app.ui.components.BfSectionLabel
import com.binaryforge.app.ui.components.BfTag
import com.binaryforge.app.ui.components.BfTextButton
import com.binaryforge.app.ui.components.Mono
import com.binaryforge.app.ui.components.formatBytes
import com.binaryforge.app.ui.theme.Bf

private fun kindColor(kind: String): Color = when (kind) {
    "code" -> Bf.Accent
    "data" -> Bf.Cyan
    "bss" -> Bf.Violet
    "debug" -> Bf.Dim
    "metadata" -> Bf.Muted
    else -> Bf.Dim
}

@Composable
fun SectionsTab(ctx: ProjectContext) {
    val s = ctx.summary
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { BfSectionLabel("Sections (${s.sections.size})") }
        if (s.sections.isEmpty()) {
            item { BfHint("This file has no section table. Segments and code regions below come from the program headers.") }
        }
        items(s.sections) { section -> SectionRow(section, ctx) }
        item { BfSectionLabel("Segments (${s.segments.size})") }
        if (s.segments.isEmpty()) {
            item { BfHint("This format has no segment table.") }
        }
        items(s.segments) { segment -> SegmentRow(segment) }
        item { BfSectionLabel("Code regions (${s.codeRegions.size})") }
        if (s.codeRegions.isEmpty()) {
            item { BfHint("No executable code was identified, so the code views are empty. Use manual configuration to treat the file as raw machine code.") }
        }
        items(s.codeRegions) { region -> CodeRegionRow(region, ctx) }
    }
}

@Composable
private fun SectionRow(sec: SectionInfo, ctx: ProjectContext) {
    BfPanel(
        Modifier.clickable(enabled = sec.size > 0L) { ctx.openHex(sec.offset) }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = sec.name.ifEmpty { "(unnamed)" },
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            BfTag(sec.kind.uppercase(), kindColor(sec.kind))
            Spacer(Modifier.width(8.dp))
            Text(sec.perms, color = Bf.Muted, fontFamily = Mono, fontSize = 12.sp)
        }
        Text(
            "va ${hex(sec.va)}   off ${hex(sec.offset)}   ${formatBytes(sec.size)}",
            color = Bf.Muted,
            fontFamily = Mono,
            fontSize = 11.sp,
        )
        if (sec.confidence != "verified") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BfConfidenceTag(sec.confidence)
                Spacer(Modifier.width(8.dp))
                Text("range clamped to the file", color = Bf.Muted, fontSize = 11.sp)
            }
        }
        if (sec.kind == "code" && ctx.summary.disassemblerAvailable && sec.va != 0L) {
            Row {
                BfTextButton("Disassemble", { ctx.openCode(sec.va) })
                if (sec.size > 0L) BfTextButton("Hex", { ctx.openHex(sec.offset) }, Bf.Muted)
            }
        }
    }
}

@Composable
private fun SegmentRow(seg: SegmentInfo) {
    BfPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = seg.kind,
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Text(seg.perms, color = Bf.Muted, fontFamily = Mono, fontSize = 12.sp)
        }
        Text(
            "va ${hex(seg.va)}   off ${hex(seg.offset)}",
            color = Bf.Muted,
            fontFamily = Mono,
            fontSize = 11.sp,
        )
        Text(
            "file ${formatBytes(seg.size)}   memory ${formatBytes(seg.memSize)}   align ${hex(seg.align)}",
            color = Bf.Muted,
            fontFamily = Mono,
            fontSize = 11.sp,
        )
    }
}

@Composable
private fun CodeRegionRow(region: CodeRegionInfo, ctx: ProjectContext) {
    BfPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = region.name,
                color = Bf.Text,
                fontFamily = Mono,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f),
            )
            BfConfidenceTag(region.confidence)
        }
        Text(
            "va ${hex(region.va)}   off ${hex(region.offset)}   ${formatBytes(region.size)}",
            color = Bf.Muted,
            fontFamily = Mono,
            fontSize = 11.sp,
        )
        if (ctx.summary.disassemblerAvailable) {
            BfTextButton("Disassemble", { ctx.openCode(region.va) })
        }
    }
}
