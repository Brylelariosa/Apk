# No code shrinking is configured; JNI-bound names must stay intact.
-keep class com.binaryforge.app.engine.NativeBridge { *; }
