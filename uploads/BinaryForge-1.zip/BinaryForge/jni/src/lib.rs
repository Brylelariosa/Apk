//! JNI bridge between the Kotlin app and the BinaryForge engine.
//!
//! Every function returns JSON text (or raw bytes for hex reads). Failures are reported as
//! `{"error": "..."}`, so no Java exception has to cross the boundary, and every call is
//! wrapped in `catch_unwind` so a bug in the engine cannot take the app down.
//!
//! The Kotlin side is `com.binaryforge.app.engine.NativeBridge`.

use std::collections::HashMap;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

use binaryforge_core::project::Session;
use binaryforge_core::util::json::{error_json, JsonWriter};
use jni::objects::{JClass, JString};
use jni::sys::{jbyteArray, jint, jlong, jstring};
use jni::JNIEnv;

static NEXT_ID: AtomicI64 = AtomicI64::new(1);
static SESSIONS: OnceLock<Mutex<HashMap<i64, Arc<Session>>>> = OnceLock::new();

fn registry() -> &'static Mutex<HashMap<i64, Arc<Session>>> {
    SESSIONS.get_or_init(|| Mutex::new(HashMap::new()))
}

/// Looks a session up by handle. The returned `Arc` keeps the session alive for the whole
/// call even if the app closes it concurrently.
fn session(handle: jlong) -> Option<Arc<Session>> {
    let map = registry().lock().ok()?;
    map.get(&handle).cloned()
}

fn json_guard<F: FnOnce() -> String>(f: F) -> String {
    match catch_unwind(AssertUnwindSafe(f)) {
        Ok(text) => text,
        Err(payload) => {
            let msg = if let Some(s) = payload.downcast_ref::<&str>() {
                s.to_string()
            } else if let Some(s) = payload.downcast_ref::<String>() {
                s.clone()
            } else {
                "unknown panic".to_string()
            };
            error_json(&format!("Internal engine error: {}", msg))
        }
    }
}

fn with_session<F: FnOnce(&Session) -> String>(handle: jlong, f: F) -> String {
    json_guard(|| match session(handle) {
        Some(s) => f(&*s),
        None => error_json("Invalid session handle."),
    })
}

fn get_string(env: &mut JNIEnv, value: &JString) -> String {
    match env.get_string(value) {
        Ok(s) => s.into(),
        Err(_) => String::new(),
    }
}

fn make_string(env: &mut JNIEnv, text: &str) -> jstring {
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeVersion<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    make_string(&mut env, binaryforge_core::ENGINE_VERSION)
}

/// Opens a file read-only. Returns `{"handle": n}` or `{"error": "..."}`.
#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeOpen<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    path: JString<'local>,
    options: JString<'local>,
) -> jstring {
    let path_text = get_string(&mut env, &path);
    let options_text = get_string(&mut env, &options);
    let out = json_guard(|| match Session::open(&path_text, &options_text) {
        Ok(opened) => {
            let id = NEXT_ID.fetch_add(1, Ordering::Relaxed);
            if let Ok(mut map) = registry().lock() {
                map.insert(id, Arc::new(opened));
            }
            let mut j = JsonWriter::new();
            j.begin_object();
            j.kv_u64("handle", id as u64);
            j.end_object();
            j.finish()
        }
        Err(e) => error_json(&e.to_string()),
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeClose<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Ok(mut map) = registry().lock() {
            map.remove(&handle);
        }
    }));
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeAnalyze<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) -> jstring {
    let out = with_session(handle, |s| s.analyze_json());
    make_string(&mut env, &out)
}

/// Runs the deep analysis (blocking; call from a background thread).
#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeDeepAnalyze<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) -> jstring {
    let out = with_session(handle, |s| s.deep_analyze_json());
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeStatus<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) -> jstring {
    let out = with_session(handle, |s| s.status_json());
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeCancel<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) {
    let _ = catch_unwind(AssertUnwindSafe(|| {
        if let Some(s) = session(handle) {
            s.cancel();
        }
    }));
}

/// Reads raw bytes for the hex viewer. Returns an empty array on any failure.
#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeRead<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    offset: jlong,
    length: jint,
) -> jbyteArray {
    let data: Vec<u8> = match catch_unwind(AssertUnwindSafe(|| match session(handle) {
        Some(s) => s.read(offset as u64, length.max(0) as usize),
        None => Vec::new(),
    })) {
        Ok(v) => v,
        Err(_) => Vec::new(),
    };
    match env.byte_array_from_slice(&data) {
        Ok(arr) => arr.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// Byte-pattern search. Returns the offset, -1 when not found, -2 on an invalid pattern.
#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeFind<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    from: jlong,
    pattern_hex: JString<'local>,
) -> jlong {
    let pattern = get_string(&mut env, &pattern_hex);
    match catch_unwind(AssertUnwindSafe(|| match session(handle) {
        Some(s) => s.find(from.max(0) as u64, &pattern),
        None => -2,
    })) {
        Ok(v) => v,
        Err(_) => -2,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeQuery<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    what: JString<'local>,
    arg: JString<'local>,
    offset: jint,
    limit: jint,
    filter: JString<'local>,
) -> jstring {
    let what_text = get_string(&mut env, &what);
    let arg_text = get_string(&mut env, &arg);
    let filter_text = get_string(&mut env, &filter);
    let out = with_session(handle, |s| {
        s.query_json(
            &what_text,
            &arg_text,
            offset.max(0) as usize,
            limit.max(1) as usize,
            &filter_text,
        )
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeDisassemble<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    address: jlong,
    count: jint,
) -> jstring {
    let out = with_session(handle, |s| {
        s.disassemble_json(address as u64, count.max(1) as usize)
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_binaryforge_app_engine_NativeBridge_nativeFunctionDetail<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    address: jlong,
) -> jstring {
    let out = with_session(handle, |s| s.function_detail_json(address as u64));
    make_string(&mut env, &out)
}
