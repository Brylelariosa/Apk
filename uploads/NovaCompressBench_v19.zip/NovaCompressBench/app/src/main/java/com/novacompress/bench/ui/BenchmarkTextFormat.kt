package com.novacompress.bench.ui

import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.VerificationResult
import com.novacompress.bench.ui.screens.home.formatBytes

/**
 * Formats one source's results into the same plain-text block this app's
 * Results screen has always produced. Factored out of that screen (see
 * BENCHMARKS.md Entry 19) so [com.novacompress.bench.ui.screens.history.HistoryScreen]
 * can copy a *saved* run in byte-identical format to a *live* one, rather
 * than inventing a second, differently-shaped summary for the same data.
 */
fun formatSourceResultsAsText(sourceName: String, results: List<BenchmarkMetrics>): String {
    val originalSize = results.firstOrNull()?.originalSizeBytes
    val header = if (originalSize != null) {
        "NovaCompress Bench \u2014 $sourceName (${formatBytes(originalSize)})"
    } else {
        "NovaCompress Bench \u2014 $sourceName"
    }
    val rows = results.joinToString("\n\n") { m ->
        when (m.verified) {
            VerificationResult.PASS, VerificationResult.FAIL -> {
                val reasonLine = m.failureReason?.let { "\n  $it" } ?: ""
                "${m.algorithmName}: ${m.verified}" +
                    "\n  ratio %.2fx, saved %.1f%%".format(m.compressionRatio, m.spaceSavingPercent) +
                    "\n  compress ${m.compressionTimeMs} ms (%.1f MB/s), decompress ${m.decompressionTimeMs} ms (%.1f MB/s)"
                        .format(m.compressionThroughputMBps, m.decompressionThroughputMBps) +
                    reasonLine
            }
            VerificationResult.UNAVAILABLE, VerificationResult.SKIPPED -> {
                "${m.algorithmName}: ${m.verified}" + (m.failureReason?.let { "\n  $it" } ?: "")
            }
        }
    }
    return "$header\n\n$rows"
}

/** Formats several sources' results together, in run order - the same
 *  shape [com.novacompress.bench.ui.screens.results.ResultsScreen]'s own
 *  "copy all" button has always produced for a multi-source run. */
fun formatMultiSourceResultsAsText(bySource: Map<String, List<BenchmarkMetrics>>): String {
    if (bySource.isEmpty()) return "NovaCompress Bench"
    return bySource.entries.joinToString("\n\n${"=".repeat(32)}\n\n") { (sourceName, results) ->
        formatSourceResultsAsText(sourceName, results)
    }
}
