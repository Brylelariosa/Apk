package com.romexplorer.gba.ui.pokemontables

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.common.IndexedCache
import com.romexplorer.gba.core.common.RomKeyedCache
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.pokemon.BattleAnimationReader
import com.romexplorer.gba.core.pokemon.BattleAnimScriptDisassembler
import com.romexplorer.gba.core.pokemon.BattleAnimationScript
import com.romexplorer.gba.core.pokemon.DisassembledAnimScript
import com.romexplorer.gba.core.pokemon.DisplayRow
import com.romexplorer.gba.core.pokemon.FieldWriteResult
import com.romexplorer.gba.core.pokemon.FireRedTables
import com.romexplorer.gba.core.pokemon.ItemIconReader
import com.romexplorer.gba.core.pokemon.ItemNameLookup
import com.romexplorer.gba.core.pokemon.NameTableLookup
import com.romexplorer.gba.core.pokemon.NameTableWriter
import com.romexplorer.gba.core.pokemon.PokemonTableReader
import com.romexplorer.gba.core.pokemon.PokemonTableWriter
import com.romexplorer.gba.core.pokemon.SpeciesIconReader
import com.romexplorer.gba.core.pokemon.TableRowFormatter
import com.romexplorer.gba.core.pokemon.TrainerPartyFormatter
import com.romexplorer.gba.core.pokemon.TrainerPartyMember
import com.romexplorer.gba.core.pokemon.TrainerPartyReader
import com.romexplorer.gba.core.pokemon.TrainerPartyWriter
import com.romexplorer.gba.core.pokemon.TrainerSpriteReader
import com.romexplorer.gba.core.pokemon.UnusedSlotDetector
import com.romexplorer.gba.core.pokemon.model.DisplayHint
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.pokemon.model.TableRow
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.data.repository.CustomTypeNamesRepository
import com.romexplorer.gba.data.repository.RomSession
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed class PokemonTablesState {
    data object NotFireRed : PokemonTablesState()
    data object NoRomOpen : PokemonTablesState()
    data class Ready(val availableTables: List<KnownTableSchema>) : PokemonTablesState()
}

/** A selected table, already formatted for display — see [TableRowFormatter]. */
data class PokemonTableSelection(
    val schema: KnownTableSchema,
    val rows: List<DisplayRow>,
)

class PokemonTableViewModel(
    private val sessionManager: RomSessionManager,
    private val customTypeNamesRepository: CustomTypeNamesRepository,
) : ViewModel() {

    val uiState: StateFlow<PokemonTablesState> = sessionManager.session
        .map { toState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), toState(sessionManager.session.value))

    /** For the save-as suggested filename. */
    val romDisplayName: StateFlow<String?> = sessionManager.session
        .map { it?.displayName }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), sessionManager.session.value?.displayName)

    private val _selectedTable = MutableStateFlow<PokemonTableSelection?>(null)
    val selectedTable: StateFlow<PokemonTableSelection?> = _selectedTable.asStateFlow()

    private val _isLoadingTable = MutableStateFlow(false)
    val isLoadingTable: StateFlow<Boolean> = _isLoadingTable.asStateFlow()

    /** Set after a failed edit (out-of-range value, etc.); null when there's nothing to show. */
    private val _editStatus = MutableStateFlow<String?>(null)
    val editStatus: StateFlow<String?> = _editStatus.asStateFlow()

    private val itemNameCache = RomKeyedCache<Map<Int, String>>()
    private val speciesNameCache = RomKeyedCache<Map<Int, String>>()
    private val moveNameCache = RomKeyedCache<Map<Int, String>>()
    private val typeNameCache = RomKeyedCache<Map<Int, String>>()

    private val speciesIconCache = IndexedCache<DecodedImage?>()
    private val itemIconCache = IndexedCache<DecodedImage?>()

    // Guards editTrainerPartyMember/resizeTrainerParty's write-then-refresh
    // sequence. Both re-derive partyPointer/partyFlags/partySize fresh from
    // session.editOverlay right before writing, which is correct for any
    // one call in isolation — but two calls for the same trainer racing
    // (a resize's write finishing between when a second call reads its
    // own fresh copy and when it writes) could still write against a
    // partySize/pointer that a concurrent resize is simultaneously
    // replacing. A double-tap on Save or tapping "+ Add Pokémon" right
    // after editing a slot are the realistic ways to trigger that from the
    // UI. Serializing here removes the interleaving entirely rather than
    // trying to reason about which order is safe.
    private val trainerEditMutex = Mutex()
    private val trainerSpriteCache = IndexedCache<DecodedImage?>()
    private val battleAnimationCache = IndexedCache<BattleAnimationScript?>()
    private val battleAnimationDisassemblyCache = IndexedCache<DisassembledAnimScript?>()

    private fun toState(session: RomSession?): PokemonTablesState = when {
        session == null -> PokemonTablesState.NoRomOpen
        session.header.gameCode != FireRedTables.EXPECTED_GAME_CODE -> PokemonTablesState.NotFireRed
        else -> PokemonTablesState.Ready(FireRedTables.all)
    }

    fun selectTable(schema: KnownTableSchema) {
        val session = sessionManager.session.value ?: return
        val accessor = session.accessor
        viewModelScope.launch {
            _isLoadingTable.value = true
            // The overlay is the same one the hex editor writes to, so an edit
            // made on either screen shows up here too — see PokemonTableWriter.
            val table = PokemonTableReader.read(accessor, schema, session.editOverlay)

            val itemNames = if (schema.fields.any { it.displayHint == DisplayHint.ITEM_ID }) itemNamesFor(accessor) else emptyMap()
            val typeNames = if (schema.fields.any { it.displayHint == DisplayHint.TYPE_ID }) typeNamesFor(session) else emptyMap()

            val rows = when (schema) {
                FireRedTables.speciesBaseStats -> {
                    val speciesNames = speciesNamesFor(accessor)
                    table.rows.map { row ->
                        TableRowFormatter.format(schema, row, itemNames, typeNames, externalTitle = speciesNames[row.index])
                    }
                }
                FireRedTables.moves -> {
                    val moveNames = moveNamesFor(accessor)
                    table.rows.map { row ->
                        TableRowFormatter.format(schema, row, itemNames, typeNames, externalTitle = moveNames[row.index])
                    }
                }
                FireRedTables.trainers -> withTrainerParties(accessor, schema, table.rows, itemNames, session.editOverlay)
                else -> table.rows.map { row -> TableRowFormatter.format(schema, row, itemNames) }
            }

            _selectedTable.value = PokemonTableSelection(schema, rows)
            _isLoadingTable.value = false
        }
    }

    fun clearSelection() {
        _selectedTable.value = null
    }

    /**
     * Re-reads and re-formats exactly one row of the currently-selected
     * table and splices it back into [_selectedTable] in place — the
     * single-row counterpart to [selectTable]'s full reload, used after any
     * edit that only changes one row's own bytes (a field edit, a trainer's
     * party edit or resize).
     *
     * Two things a full [selectTable] reload after every edit got wrong,
     * both worse the bigger the table — most visibly on
     * [FireRedTables.trainers] (~750 rows, each needing its own party
     * decode, see [withTrainerParties]):
     *  - It set [_isLoadingTable], which swaps [EntryList]'s `when` branch
     *    to a spinner and back. Composing a *different* branch tears down
     *    [EntryList] and rebuilds it fresh, discarding its own `remember`
     *    state — the search query and scroll position — so every edit
     *    silently reset whatever the user had searched for.
     *  - It redecoded every other row's data to reflect a change in one
     *    row, which for trainers meant re-running ~750 concurrent party
     *    reads for a single party edit.
     *
     * This never touches [_isLoadingTable] — there's no meaningful loading
     * moment for one already-known row index — so [EntryList] stays
     * composed throughout and neither problem applies.
     */
    private suspend fun refreshRow(schema: KnownTableSchema, rowIndex: Int) {
        val session = sessionManager.session.value ?: return
        val current = _selectedTable.value ?: return
        if (current.schema != schema) return
        val accessor = session.accessor

        val table = PokemonTableReader.read(accessor, schema, session.editOverlay)
        val freshRow = table.rows.getOrNull(rowIndex) ?: return

        val itemNames = if (schema.fields.any { it.displayHint == DisplayHint.ITEM_ID }) itemNamesFor(accessor) else emptyMap()
        val typeNames = if (schema.fields.any { it.displayHint == DisplayHint.TYPE_ID }) typeNamesFor(session) else emptyMap()

        val updated = when (schema) {
            FireRedTables.speciesBaseStats ->
                TableRowFormatter.format(schema, freshRow, itemNames, typeNames, externalTitle = speciesNamesFor(accessor)[freshRow.index])
            FireRedTables.moves ->
                TableRowFormatter.format(schema, freshRow, itemNames, typeNames, externalTitle = moveNamesFor(accessor)[freshRow.index])
            FireRedTables.trainers ->
                formatTrainerRow(accessor, schema, freshRow, itemNames, speciesNamesFor(accessor), moveNamesFor(accessor), session.editOverlay)
            else -> TableRowFormatter.format(schema, freshRow, itemNames)
        }

        _selectedTable.value = current.copy(rows = current.rows.map { if (it.index == rowIndex) updated else it })
    }

    /**
     * Writes [newValue] into [field] of row [rowIndex], via the shared
     * [com.romexplorer.gba.core.hex.EditOverlay] — see [PokemonTableWriter].
     * On success, re-reads and reformats that one row (see [refreshRow]) so
     * every derived bit of its own display (a resolved name, a trainer's
     * party line) stays consistent rather than patching just the one cell
     * and risking it drifting out of sync — without re-reading every other
     * row in the table to do it.
     */
    fun editField(schema: KnownTableSchema, rowIndex: Int, field: TableField, newValue: Long) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            when (val result = PokemonTableWriter.write(session.accessor, session.editOverlay, schema, rowIndex, field, newValue)) {
                FieldWriteResult.Success -> {
                    sessionManager.persistDraft()
                    refreshRow(schema, rowIndex)
                }
                FieldWriteResult.OutOfRange -> {
                    val range = PokemonTableWriter.validRange(field.kind)
                    _editStatus.value = "${field.name} must be between ${range.first} and ${range.last}"
                }
                FieldWriteResult.NotEditable -> _editStatus.value = "${field.name} can't be edited here"
                FieldWriteResult.OutOfBounds -> _editStatus.value = "Couldn't write ${field.name} — out of ROM bounds"
            }
        }
    }

    fun clearEditStatus() {
        _editStatus.value = null
    }

    fun canUndoEdit(): Boolean = sessionManager.session.value?.editOverlay?.canUndo() ?: false

    /** Undoes the most recent edit — from this screen or the hex editor, since they share one overlay — and reloads. */
    fun undoEdit() {
        val session = sessionManager.session.value ?: return
        val schema = _selectedTable.value?.schema ?: return
        session.editOverlay.undo()
        viewModelScope.launch { sessionManager.persistDraft() }
        selectTable(schema)
    }

    /** True if there are edits not yet exported to a saved ROM file (see [exportRom]). */
    fun hasUnsavedEdits(): Boolean = sessionManager.hasUnsavedEdits()

    /** Writes the currently-open ROM, with every edit applied, to [destination] — shared with the Hex Editor, see RomSessionManager.exportEditedRom. */
    fun exportRom(destination: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = sessionManager.exportEditedRom(destination)
            _editStatus.value = if (result.isSuccess) "Saved successfully" else "Save failed: ${result.exceptionOrNull()?.message}"
            onDone(result.isSuccess)
        }
    }

    /** Discards every unsaved edit for the current ROM, reverting every table back to its original bytes. */
    fun discardAllEdits() {
        viewModelScope.launch {
            sessionManager.discardDraft()
            _selectedTable.value?.schema?.let { selectTable(it) }
        }
    }

    /**
     * Registers a custom label for a type ID beyond FireRed's built-in 18
     * (e.g. "FAIRY") — a display name only, not a real new type with its own
     * battle type-effectiveness; see [CustomTypeNamesRepository]. The next
     * free ID above every type currently known (built-in or already-custom)
     * is assigned automatically, so the person naming it is never asked to
     * pick a raw number themselves — the exact problem this whole feature
     * exists to get away from.
     */
    fun addCustomType(name: String, onAdded: (Int) -> Unit) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            val existing = typeNamesFor(session)
            val nextId = (existing.keys.maxOrNull() ?: (FireRedTables.TYPE_COUNT - 1)) + 1
            customTypeNamesRepository.setCustomType(session.cacheKey, nextId, name)
            typeNameCache.invalidate()
            _selectedTable.value?.schema?.let { selectTable(it) }
            onAdded(nextId)
        }
    }

    /**
     * Row indices in [schema] that are genuinely unused and therefore safe
     * to claim as a new entry (see [UnusedSlotDetector]) — empty means every
     * slot in this ROM's copy of the table is already taken, not that
     * something went wrong. Only [FireRedTables.items], [FireRedTables.speciesBaseStats]
     * and [FireRedTables.moves] support this; other schemas return an empty list.
     */
    suspend fun unusedSlotIndices(schema: KnownTableSchema): List<Int> {
        val session = sessionManager.session.value ?: return emptyList()
        val table = PokemonTableReader.read(session.accessor, schema, session.editOverlay)
        return when (schema) {
            FireRedTables.items -> table.rows.filter { UnusedSlotDetector.isUnusedItemSlot(it) }.map { it.index }
            FireRedTables.speciesBaseStats -> {
                val names = speciesNamesFor(session.accessor)
                table.rows.filter { UnusedSlotDetector.isUnusedSpeciesSlot(it, names[it.index]) }.map { it.index }
            }
            FireRedTables.moves -> {
                val names = moveNamesFor(session.accessor)
                table.rows.filter { UnusedSlotDetector.isUnusedMoveSlot(it, names[it.index]) }.map { it.index }
            }
            else -> emptyList()
        }
    }

    /**
     * Names a previously-unused slot (see [unusedSlotIndices]), turning it
     * into a real, functional new entry. This — reusing a reserved-but-blank
     * slot the table already ships with — is what "add a new item/Pokémon/
     * move" means in this app: the table itself is never expanded or
     * relocated (see [UnusedSlotDetector]'s doc for why that's out of
     * scope), so this can never corrupt anything outside the slot claimed.
     */
    fun claimSlot(schema: KnownTableSchema, index: Int, name: String) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            val result = when (schema) {
                FireRedTables.items -> {
                    val nameField = schema.fields.first { it.kind == FieldKind.POKEMON_STRING }
                    PokemonTableWriter.writeName(session.accessor, session.editOverlay, schema, index, nameField, name)
                }
                FireRedTables.speciesBaseStats -> NameTableWriter.write(
                    session.accessor,
                    session.editOverlay,
                    FireRedTables.SPECIES_NAMES_OFFSET,
                    FireRedTables.SPECIES_NAME_LENGTH,
                    index,
                    name,
                )
                FireRedTables.moves -> NameTableWriter.write(
                    session.accessor,
                    session.editOverlay,
                    FireRedTables.MOVE_NAMES_OFFSET,
                    FireRedTables.MOVE_NAME_LENGTH,
                    index,
                    name,
                )
                else -> FieldWriteResult.NotEditable
            }
            when (result) {
                FieldWriteResult.Success -> {
                    itemNameCache.invalidate()
                    speciesNameCache.invalidate()
                    moveNameCache.invalidate()
                    sessionManager.persistDraft()
                    selectTable(schema)
                    _editStatus.value = "\"$name\" added at slot #$index — scroll down to fill in its other fields"
                }
                else -> _editStatus.value = "Couldn't name this entry"
            }
        }
    }

    /**
     * Called from the UI per visible row (e.g. from `produceState`, not
     * `viewModelScope.launch`) so decoding — real work, LZ77 + tile decode
     * — only happens for rows actually on screen, and stops automatically
     * once a row scrolls away and its composable leaves composition.
     */
    suspend fun loadSpeciesIcon(speciesIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return speciesIconCache.getOrPut(accessor, speciesIndex) { SpeciesIconReader.read(accessor, speciesIndex) }
    }

    suspend fun loadItemIcon(itemIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return itemIconCache.getOrPut(accessor, itemIndex) { ItemIconReader.read(accessor, itemIndex) }
    }

    suspend fun loadTrainerSprite(trainerPicIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return trainerSpriteCache.getOrPut(accessor, trainerPicIndex) { TrainerSpriteReader.read(accessor, trainerPicIndex) }
    }

    /** A move's real animation script, for [MoveAnimationDialog] — see [BattleAnimationReader]. */
    suspend fun loadBattleAnimation(moveIndex: Int): BattleAnimationScript? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return battleAnimationCache.getOrPut(accessor, moveIndex) { BattleAnimationReader.read(accessor, moveIndex) }
    }

    /** That same script, actually decoded into real commands — see [BattleAnimScriptDisassembler]. */
    suspend fun loadBattleAnimationDisassembly(moveIndex: Int): DisassembledAnimScript? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        val script = loadBattleAnimation(moveIndex) ?: return null
        return battleAnimationDisassemblyCache.getOrPut(accessor, moveIndex) {
            BattleAnimScriptDisassembler.disassemble(accessor, script.romOffset)
        }
    }

    /**
     * Edits one existing party slot for the trainer at [trainerRowIndex] —
     * species/level/item/moves — without changing how many Pokémon the
     * trainer has. See [TrainerPartyWriter.writeMember].
     */
    fun editTrainerPartyMember(trainerRowIndex: Int, memberIndex: Int, newMember: TrainerPartyMember) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            trainerEditMutex.withLock {
                val table = PokemonTableReader.read(session.accessor, FireRedTables.trainers, session.editOverlay)
                val row = table.rows.getOrNull(trainerRowIndex)
                val partyFlags = (row?.values?.get("Party Flags") as? Long)?.toInt() ?: 0
                val partyPointer = row?.values?.get("Party Pointer") as? Long ?: 0L
                val partySize = (row?.values?.get("Party Size") as? Long)?.toInt() ?: 0
                val success = row != null &&
                    TrainerPartyWriter.writeMember(session.accessor, session.editOverlay, partyPointer, partyFlags, partySize, memberIndex, newMember)
                if (success) {
                    sessionManager.persistDraft()
                    refreshRow(FireRedTables.trainers, trainerRowIndex)
                } else {
                    _editStatus.value = "Couldn't write that party slot"
                }
            }
        }
    }

    /**
     * Changes how many Pokémon the trainer at [trainerRowIndex] has — see
     * [TrainerPartyWriter.resize] for why this always relocates the whole
     * party to free space rather than editing in place.
     */
    fun resizeTrainerParty(trainerRowIndex: Int, newMembers: List<TrainerPartyMember>) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            trainerEditMutex.withLock {
                val table = PokemonTableReader.read(session.accessor, FireRedTables.trainers, session.editOverlay)
                val row = table.rows.getOrNull(trainerRowIndex)
                val partyFlags = (row?.values?.get("Party Flags") as? Long)?.toInt() ?: 0
                val otherPartyRanges = table.rows.mapNotNull { r ->
                    if (r.index == trainerRowIndex) return@mapNotNull null
                    val pointer = r.values["Party Pointer"] as? Long ?: return@mapNotNull null
                    val size = (r.values["Party Size"] as? Long)?.toInt() ?: return@mapNotNull null
                    val flags = (r.values["Party Flags"] as? Long)?.toInt() ?: return@mapNotNull null
                    if (pointer <= 0 || size <= 0) return@mapNotNull null
                    val length = TrainerPartyWriter.entrySize(flags).toLong() * size
                    pointer until (pointer + length)
                }
                val success = row != null && TrainerPartyWriter.resize(
                    session.accessor,
                    session.editOverlay,
                    trainerRowIndex,
                    FireRedTables.trainers.romOffset,
                    partyFlags,
                    newMembers,
                    reservedRanges = otherPartyRanges,
                )
                if (success) {
                    sessionManager.persistDraft()
                    refreshRow(FireRedTables.trainers, trainerRowIndex)
                } else {
                    _editStatus.value = "Couldn't resize this trainer's party — no free space found for ${newMembers.size} Pokémon"
                }
            }
        }
    }

    /**
     * Trainer rows get the same header-field formatting as any other table,
     * plus each trainer's actual party — decoded separately per row since
     * it lives behind its own pointer with a shape that varies by trainer
     * (see [TrainerPartyReader]). Reads run concurrently since there can be
     * ~750 trainers and [RomAccessor] is safe for concurrent access.
     */
    private suspend fun withTrainerParties(
        accessor: RomAccessor,
        schema: KnownTableSchema,
        rows: List<TableRow>,
        itemNames: Map<Int, String>,
        overlay: EditOverlay,
    ): List<DisplayRow> {
        val speciesNames = speciesNamesFor(accessor)
        val moveNames = moveNamesFor(accessor)
        return coroutineScope {
            rows.map { row -> async { formatTrainerRow(accessor, schema, row, itemNames, speciesNames, moveNames, overlay) } }.awaitAll()
        }
    }

    /** One trainer row's header fields plus its decoded party — the per-row unit [withTrainerParties] runs for every trainer and [refreshRow] runs for just the one that changed. */
    private suspend fun formatTrainerRow(
        accessor: RomAccessor,
        schema: KnownTableSchema,
        row: TableRow,
        itemNames: Map<Int, String>,
        speciesNames: Map<Int, String>,
        moveNames: Map<Int, String>,
        overlay: EditOverlay,
    ): DisplayRow {
        val display = TableRowFormatter.format(schema, row, itemNames)
        val partyFlags = (row.values["Party Flags"] as? Long)?.toInt() ?: 0
        val partyPointer = row.values["Party Pointer"] as? Long ?: 0L
        val partySize = (row.values["Party Size"] as? Long)?.toInt() ?: 0
        // overlay matters here just as much as it does for the row's own
        // fields above (TableRowFormatter.format already sees it, via
        // PokemonTableReader) — a party lives behind its own pointer, off
        // in its own separately-read block of ROM, so it needs its own
        // explicit pass; see EditOverlay.applyToRange's doc for why this
        // isn't automatic.
        val members = TrainerPartyReader.read(accessor, partyFlags, partyPointer, partySize, overlay)
        val partyLines = TrainerPartyFormatter.format(members, speciesNames, itemNames, moveNames)
        val trainerPicIndex = (row.values["Trainer Pic"] as? Long)?.toInt()
        return display.copy(partyLines = partyLines, partyMembers = members, trainerPicIndex = trainerPicIndex)
    }

    private suspend fun itemNamesFor(accessor: RomAccessor): Map<Int, String> =
        itemNameCache.getOrPut(accessor) { ItemNameLookup.build(accessor) }

    private suspend fun speciesNamesFor(accessor: RomAccessor): Map<Int, String> =
        speciesNameCache.getOrPut(accessor) {
            NameTableLookup.build(
                accessor,
                FireRedTables.SPECIES_NAMES_OFFSET,
                FireRedTables.SPECIES_NAME_LENGTH,
                FireRedTables.speciesBaseStats.entryCount,
            )
        }

    private suspend fun moveNamesFor(accessor: RomAccessor): Map<Int, String> =
        moveNameCache.getOrPut(accessor) {
            NameTableLookup.build(accessor, FireRedTables.MOVE_NAMES_OFFSET, FireRedTables.MOVE_NAME_LENGTH, FireRedTables.moves.entryCount)
        }

    /** FireRed's own 18 types plus any custom labels registered for this ROM — see [CustomTypeNamesRepository]. */
    private suspend fun typeNamesFor(session: RomSession): Map<Int, String> =
        typeNameCache.getOrPut(session.accessor) {
            val romTypes = NameTableLookup.build(session.accessor, FireRedTables.TYPE_NAMES_OFFSET, FireRedTables.TYPE_NAME_LENGTH, FireRedTables.TYPE_COUNT)
            val customTypes = customTypeNamesRepository.customTypesFor(session.cacheKey).first()
            romTypes + customTypes
        }

    /** Item ID -> name, for a searchable picker (see [FieldEditDialogs]). */
    suspend fun itemNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return itemNamesFor(session.accessor)
    }

    /** Type ID -> name (built-in + custom), for a searchable picker. */
    suspend fun typeNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return typeNamesFor(session)
    }

    /** Species index -> name, for a searchable picker. */
    suspend fun speciesNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return speciesNamesFor(session.accessor)
    }

    /** Move index -> name, for a searchable picker. */
    suspend fun moveNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return moveNamesFor(session.accessor)
    }
}
