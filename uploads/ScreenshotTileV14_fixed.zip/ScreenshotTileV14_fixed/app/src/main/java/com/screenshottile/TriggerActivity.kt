package com.screenshottile

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * UNIFIED SCREENSHOT PATH
 * -----------------------
 * Previous versions split into "in-app path" (fire immediately on focus) and
 * "home screen path" (finish first, then fire). This caused two race conditions:
 *
 *   1. In-app path: onWindowFocusChanged(true) can fire while the QS panel
 *      animation is still in progress. Calling performGlobalAction immediately
 *      means Android captures the panel mid-animation → suppressed or partial save.
 *
 *   2. Home screen split: hadWindowFocus is device-dependent. Some OEMs never
 *      grant focus to translucent activities even inside apps, so the wrong path
 *      ran. 350 ms for surface teardown was not enough on slower devices.
 *
 * New approach — always the same sequence:
 *
 *   1. moveTaskToBack(true) — immediately removes our surface from the
 *      composition stack. Android 12+ won't suppress the write. The process
 *      stays alive (unlike finish()), so the service's Handler fires reliably.
 *
 *   2. service.scheduleScreenshot(500 ms) — 500 ms is safe headroom for:
 *      • QS panel collapse animation (~300 ms on most devices)
 *      • Surface teardown propagating through the compositor
 *      Consistent across all devices and scenarios.
 *
 *   3. finishAndRemoveTask() after 1800 ms — well after the screenshot capture
 *      and MediaStore write complete. The anonymous task (taskAffinity="") is
 *      fully destroyed — never re-surfaces.
 *
 * TASK ISOLATION
 * --------------
 * android:taskAffinity="" in the manifest + finishAndRemoveTask() ensures this
 * activity's anonymous task is completely destroyed and never interferes with
 * other apps' back stacks or the hardware screenshot button.
 */
class TriggerActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var screenshotScheduled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(null)
        if (ScreenshotAccessibilityService.instance == null) {
            finishAndRemoveTask()
            return
        }
    }

    override fun onResume() {
        super.onResume()
        if (screenshotScheduled) return
        screenshotScheduled = true

        val service = ScreenshotAccessibilityService.instance
        if (service == null) {
            finishAndRemoveTask()
            return
        }

        // Step 1: move our surface behind everything.
        moveTaskToBack(true)

        // Step 2: fire screenshot once the surface is fully gone.
        service.scheduleScreenshot(500L)

        // Step 3: clean up well after the write completes.
        handler.postDelayed({ finishAndRemoveTask() }, 1800L)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
