package com.zipapkbuilder.core

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.zipapkbuilder.R

/**
 * A small rounded tile with a tinted glyph — the "what kind of popup is this"
 * marker at the start of a dialog's title bar (see [dialogTitleBar]). The tile
 * is a quiet tonal wash of the [tone]'s accent color with a matching hairline
 * edge, so a delete confirmation reads red, a keystore prompt orange, an
 * upload popup violet, without any of them shouting.
 *
 * Its layout params are a [LinearLayout.LayoutParams] of exactly [sizeDp], ready
 * to be added to a horizontal row; callers that need a margin adjust that
 * object (as [dialogTitleBar] does for its end margin).
 */
fun Context.iconTile(
    @DrawableRes iconRes: Int,
    tone: ButtonTone = ButtonTone.PRIMARY,
    sizeDp: Int = 36,
    iconSizeDp: Int = 18,
    cornerDp: Int = 11
): FrameLayout {
    val dp = resources.displayMetrics.density
    val accent = ContextCompat.getColor(this, tone.accent)
    return FrameLayout(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = cornerDp * dp
            setColor(ColorUtils.setAlphaComponent(accent, 0x2A))
            setStroke(maxOf(1, (1 * dp).toInt()), ColorUtils.setAlphaComponent(accent, 0x47))
        }
        layoutParams = LinearLayout.LayoutParams((sizeDp * dp).toInt(), (sizeDp * dp).toInt())
        addView(
            ImageView(context).apply {
                setImageResource(iconRes)
                imageTintList = ColorStateList.valueOf(accent)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            },
            FrameLayout.LayoutParams((iconSizeDp * dp).toInt(), (iconSizeDp * dp).toInt(), Gravity.CENTER)
        )
    }
}
