package com.zipapkbuilder.feature.artifacts

import android.app.AlertDialog
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.feature.build.BuildFlowController
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import com.zipapkbuilder.core.dialogBullets
import com.zipapkbuilder.core.dialogChip
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogStack
import com.zipapkbuilder.core.iconTile

/**
 * Browses every artifact GitHub currently has for a repo — exactly what the
 * GitHub website shows on Actions → Artifacts — and lets the user pick one to
 * download via [com.zipapkbuilder.feature.download.DownloadManager], switch
 * repos, or re-trigger a build, all from the same dialog. Works even after
 * the app is uninstalled and reinstalled, since this data lives on GitHub, not
 * in SharedPreferences.
 */
class ArtifactBrowser(private val activity: MainActivity) {

    /**
     * Fetches every artifact for the repo from GitHub API — exactly what the
     * GitHub website shows on the Actions → Artifacts page.  Works even after
     * the app is uninstalled and reinstalled because the data lives on GitHub,
     * not in SharedPreferences.
     */
    fun browseAllArtifacts() {
        val token = activity.etToken.text.toString().trim()
        val repo  = activity.etRepo.text.toString().trim()
        if (token.isEmpty()) { activity.appendLog("[warn] Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("[warn] Enter a repository name first."); return }

        activity.setBusy(true)
        activity.appendLog("Fetching all artifacts from GitHub…")

        activity.bgExecutor.execute {
            try {
                val owner = activity.lastOwner.ifEmpty {
                    (BuildFlowController.fetchOwner(token) ?: throw Exception("Could not verify token.")).also { activity.lastOwner = it }
                }

                // Collect up to 5 pages × 30 = 150 artifacts (same as GitHub website)
                val allArtifacts = mutableListOf<JSONObject>()
                var page = 1
                while (page <= 5) {
                    val url = "${GitHubApi.apiArtifacts(owner, repo)}?per_page=30&page=$page"
                    val (code, body) = GitHubApi.httpGet(token, url)
                    if (code != 200) break
                    val obj  = JSONObject(body)
                    val arr  = obj.getJSONArray("artifacts")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allArtifacts.add(arr.getJSONObject(i))
                    val totalCount = obj.optInt("total_count", 0)
                    if (allArtifacts.size >= totalCount) break
                    page++
                }

                // Newest build first, regardless of what order the API paginated them
                // in — `created_at` is a fixed-width ISO-8601 UTC ("…T…Z") timestamp,
                // so a plain descending string sort is already a correct descending
                // chronological sort (no date parsing needed); an artifact missing
                // the field entirely (shouldn't happen, but optString defaults to "")
                // sorts last rather than crashing or landing at the top.
                val sortedArtifacts = allArtifacts.sortedByDescending { it.optString("created_at", "") }

                activity.mainHandler.post {
                    activity.setBusy(false)
                    // Background fetch above can take a few seconds; if the user backed
                    // out of the app in the meantime, don't try to pop a new AlertDialog
                    // on a dead Activity (WindowManager.BadTokenException) — same fix as
                    // the workflow-trigger picker in BuildFlowController.
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    if (sortedArtifacts.isEmpty()) {
                        activity.appendLog("No artifacts found in github.com/$owner/$repo")
                        activity.appendLog("  Artifacts are kept for 30 days after each build.")
                        lateinit var noArtDlg: AlertDialog
                        val noArtBody = activity.dialogStack(
                            activity.dialogMessage("No artifacts were found in:"),
                            activity.dialogChip("github.com/$owner/$repo", R.drawable.ic_github, ButtonTone.PRIMARY),
                            activity.dialogMessage("Possible reasons:"),
                            activity.dialogBullets(listOf(
                                "All artifacts have expired (30-day limit)",
                                "The repo name is wrong",
                                "No builds have been run yet"
                            )),
                            activity.dialogMessage("Start a new build with Upload & build.")
                        )
                        val noArtContent = activity.dialogWithActions(
                            noArtBody,
                            DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { noArtDlg.dismiss() }
                        )
                        noArtDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                            .setCustomTitle(activity.dialogTitleBar("No artifacts found", R.drawable.ic_download, ButtonTone.TEAL) { noArtDlg.dismiss() })
                            .setView(noArtContent)
                            .show()
                    } else {
                        activity.appendLog("[ok] Found ${sortedArtifacts.size} artifact(s)")
                        showArtifactBrowserDialog(token, owner, repo, sortedArtifacts)
                    }
                }
            } catch (e: Exception) {
                activity.appendLog("[error] ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /**
     * Displays all artifacts — fixed text visibility, trigger workflow, switch repo.
     */
    private fun showArtifactBrowserDialog(
        token: String, owner: String, repo: String,
        artifacts: List<JSONObject>
    ) {
        val dp   = activity.resources.displayMetrics.density
        val fmt  = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val fmtIn= SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

        // Declared up front (assigned once the dialog is actually built, below) so the
        // close button in the custom title bar and the "Close" pill in the button row
        // can both dismiss the same dialog instance.
        lateinit var dlg: AlertDialog

        // ── Custom title bar ──────────────────────────────────────────────
        val titleRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_header_top_rounded)
        }
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (8*dp).toInt())
        }
        val titleTv = TextView(activity).apply {
            text = "$owner / $repo"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val artifactCountTv = TextView(activity).apply {
            text = "${artifacts.size}"
            textSize = 10f
            setTextColor(0xFF9AA0B8.toInt())
        }
        topBar.addView(activity.iconTile(R.drawable.ic_download, ButtonTone.TEAL, sizeDp = 32, iconSizeDp = 17).also {
            (it.layoutParams as LinearLayout.LayoutParams).marginEnd = (10*dp).toInt()
        })
        topBar.addView(titleTv); topBar.addView(artifactCountTv)
        topBar.addView(activity.iconButton(R.drawable.ic_close, 0xFF9AA0B8.toInt()) { dlg.dismiss() }.apply {
            contentDescription = "Close"
        })
        titleRoot.addView(topBar)

        // Action chips row: Switch Repo + Trigger Build
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }
        val chipRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), (4*dp).toInt(), (14*dp).toInt(), (10*dp).toInt())
        }
        var pendingArtDialog: AlertDialog? = null
        val switchChip = activity.pillButton("Switch repo", ButtonTone.SURFACE, R.drawable.ic_switch) {
            pendingArtDialog?.dismiss()
            activity.repoSwitcher.showSavedReposDialog()
        }
        switchChip.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.marginEnd = (8*dp).toInt() }
        val triggerChip = activity.pillButton("Run build", ButtonTone.ORANGE, R.drawable.ic_flash) {
            pendingArtDialog?.dismiss()
            activity.buildFlowController.triggerWorkflowDispatch(activity, token, owner, repo, branch)
        }
        chipRow.addView(switchChip); chipRow.addView(triggerChip)
        titleRoot.addView(chipRow)

        // Divider
        titleRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Custom adapter — explicit colors ──────────────────────────────
        var selectedIndex = -1

        val listView = android.widget.ListView(activity).apply {
            setBackgroundColor(0xFF13162A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt())
            dividerHeight = 1
        }

        data class ArtInfo(val name: String, val sizeStr: String, val builtStr: String, val expiresStr: String, val expired: Boolean)
        val artInfos = artifacts.map { art ->
            val name      = art.getString("name")
            val sizeBytes = art.optLong("size_in_bytes", 0L)
            val sizeStr   = when {
                sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
                sizeBytes >= 1_024     -> "${sizeBytes / 1024} KB"
                else                   -> "$sizeBytes B"
            }
            val expired     = art.optBoolean("expired", false)
            val expiresRaw  = art.optString("expires_at", "")
            val expiresStr  = if (expiresRaw.isNotEmpty()) {
                try { "expires " + fmt.format(fmtIn.parse(expiresRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val createdRaw = art.optString("created_at", "")
            val builtStr   = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            ArtInfo(name, sizeStr, builtStr, expiresStr, expired)
        }

        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = artInfos.size
            override fun getItem(pos: Int) = artInfos[pos]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val info = artInfos[pos]
                val isSelected = (pos == selectedIndex)
                val row = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setBackgroundColor(if (isSelected) 0xFF221F4A.toInt() else 0xFF13162A.toInt())
                    setPadding((16*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                }
                // Status dot
                val dot = android.view.View(parent.context).apply {
                    setBackgroundColor(if (info.expired) 0xFFFF6B6B.toInt() else 0xFF2ECC71.toInt())
                    layoutParams = LinearLayout.LayoutParams((8*dp).toInt(), (8*dp).toInt()).also {
                        it.marginEnd = (12*dp).toInt()
                    }
                }
                val col = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val nameTv = TextView(parent.context).apply {
                    text = info.name
                    textSize = 13f
                    setTextColor(if (info.expired) 0xFF9AA0B8.toInt() else 0xFFE8EAED.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val metaTv = TextView(parent.context).apply {
                    text = buildString {
                        append(info.sizeStr)
                        if (info.builtStr.isNotEmpty()) append("  ·  built ${info.builtStr}")
                        if (info.expiresStr.isNotEmpty()) append("  ·  ${info.expiresStr}")
                        if (info.expired) append("  EXPIRED")
                    }
                    textSize = 10.5f
                    setTextColor(if (info.expired) 0xFFFF6B6B.toInt() else 0xFF50587A.toInt())
                }
                col.addView(nameTv); col.addView(metaTv)
                row.addView(dot); row.addView(col)
                return row
            }
        }

        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            selectedIndex = pos
            adapter.notifyDataSetChanged()
        }

        // ── Full custom view ──────────────────────────────────────────────
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
        }

        val listContainer = android.widget.FrameLayout(activity).apply {
            val maxH = (activity.resources.displayMetrics.heightPixels * 0.55f).toInt()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            addView(listView)
        }
        root.addView(listContainer)

        val content = activity.dialogWithActions(
            root,
            DialogAction("Download", ButtonTone.GREEN, R.drawable.ic_download) {
                if (selectedIndex < 0) {
                    activity.appendLog("[warn] Tap an artifact to select it first.")
                } else {
                    val art = artifacts[selectedIndex]
                    if (art.optBoolean("expired", false)) {
                        activity.appendLog("[error] That artifact has expired — it can no longer be downloaded.")
                        lateinit var expiredDlg: AlertDialog
                        val expiredName = art.optString("name", "")
                        val expiredParts = mutableListOf<android.view.View>()
                        if (expiredName.isNotEmpty()) {
                            expiredParts += activity.dialogChip(expiredName, R.drawable.ic_package, ButtonTone.ORANGE)
                        }
                        expiredParts += activity.dialogMessage("This artifact has expired and can no longer be downloaded.\n\nRun a new build to generate a fresh one.")
                        val expiredBody = activity.dialogStack(*expiredParts.toTypedArray())
                        val expiredContent = activity.dialogWithActions(
                            expiredBody,
                            DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { expiredDlg.dismiss() }
                        )
                        expiredDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                            .setCustomTitle(activity.dialogTitleBar("Artifact expired", R.drawable.ic_warning, ButtonTone.ORANGE) { expiredDlg.dismiss() })
                            .setView(expiredContent)
                            .show()
                    } else {
                        dlg.dismiss()
                        val artId  = art.getLong("id")
                        val artName = art.getString("name")
                        val dlUrl   = GitHubApi.apiArtifactZip(owner, repo, artId)
                        activity.prefs.edit().putString(PrefKeys.PREF_ARTIFACT_NAME, artName).apply()
                        activity.artifactDownloadUrl = dlUrl
                        activity.appendLog("Downloading: $artName")
                        activity.withStoragePermission { activity.downloadManager.downloadArtifact(dlUrl) }
                    }
                }
            },
            DialogAction("Run", ButtonTone.ORANGE, R.drawable.ic_flash) {
                dlg.dismiss()
                activity.buildFlowController.triggerWorkflowDispatch(activity, token, owner, repo, branch)
            },
            DialogAction("Close", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(content)
            .show()

        pendingArtDialog = dlg
    }
}
