package com.zipapkbuilder.core

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/*
 * Building blocks for a popup's body, next to [dialogMessage]. They all share the
 * popup's 20dp side inset so message text, chips and bullet lists line up under
 * the title. Stack several with [dialogStack] and hand the result to
 * [dialogWithActions] as its body.
 */

/** Vertical container for several body parts (message, chip, bullets…). */
fun Context.dialogStack(vararg parts: View): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        parts.forEach { addView(it) }
    }

/**
 * A rounded, monospaced chip that names the thing a popup is about — a file name,
 * a repo path, a key alias. [iconRes] (tinted with [tone]'s accent) leads it and
 * [meta] (a size, a label) sits on the end in a quieter color.
 */
fun Context.dialogChip(
    text: String,
    @DrawableRes iconRes: Int? = null,
    tone: ButtonTone = ButtonTone.PRIMARY,
    meta: String? = null
): LinearLayout {
    val dp = resources.displayMetrics.density
    val accent = ContextCompat.getColor(this, tone.accent)
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 12 * dp
            setColor(ContextCompat.getColor(context, R.color.bg_surface_2))
            setStroke(maxOf(1, (1 * dp).toInt()), ContextCompat.getColor(context, R.color.border_default))
        }
        setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.setMargins((20 * dp).toInt(), (4 * dp).toInt(), (20 * dp).toInt(), (10 * dp).toInt()) }

        if (iconRes != null) {
            addView(ImageView(context).apply {
                setImageResource(iconRes)
                imageTintList = ColorStateList.valueOf(accent)
                layoutParams = LinearLayout.LayoutParams((20 * dp).toInt(), (20 * dp).toInt()).also {
                    it.marginEnd = (10 * dp).toInt()
                }
            })
        }
        addView(TextView(context).apply {
            this.text = text
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.MIDDLE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (!meta.isNullOrEmpty()) {
            addView(TextView(context).apply {
                this.text = meta
                textSize = 11f
                setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.marginStart = (10 * dp).toInt() }
            })
        }
    }
}

/** A short bulleted list — real bullets and a hanging indent, instead of "• " typed into a string. */
fun Context.dialogBullets(items: List<String>): LinearLayout {
    val dp = resources.displayMetrics.density
    return LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding((20 * dp).toInt(), (2 * dp).toInt(), (20 * dp).toInt(), (10 * dp).toInt())
        items.forEach { item ->
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, (3 * dp).toInt(), 0, (3 * dp).toInt())
                addView(View(context).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(ContextCompat.getColor(context, R.color.text_tertiary))
                    }
                    layoutParams = LinearLayout.LayoutParams((5 * dp).toInt(), (5 * dp).toInt()).also {
                        it.topMargin = (8 * dp).toInt()
                        it.marginStart = (2 * dp).toInt()
                        it.marginEnd = (10 * dp).toInt()
                    }
                })
                addView(TextView(context).apply {
                    text = item
                    textSize = 13.5f
                    setTextColor(0xFFC7CBDD.toInt())
                    setLineSpacing(0f, 1.2f)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
            })
        }
    }
}

/** A "working…" body: a small spinner beside one line of text, for popups that wait on the network. */
fun Context.dialogLoading(text: String): LinearLayout {
    val dp = resources.displayMetrics.density
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), (22 * dp).toInt())
        addView(ProgressBar(context).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.primary))
            layoutParams = LinearLayout.LayoutParams((22 * dp).toInt(), (22 * dp).toInt()).also {
                it.marginEnd = (14 * dp).toInt()
            }
        })
        addView(TextView(context).apply {
            this.text = text
            textSize = 14f
            setTextColor(0xFFC7CBDD.toInt())
        })
    }
}
