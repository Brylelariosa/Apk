package com.zipapkbuilder.core

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/** One action in a [dialogWithActions] button row. */
data class DialogAction(
    val label: String,
    val tone: ButtonTone,
    @DrawableRes val iconRes: Int,
    val onClick: () -> Unit
)

/**
 * Wraps [body] (a message TextView, an EditText, a custom form — whatever the dialog
 * needs, or `null` for none) together with a bottom row of [actions] rendered as
 * [pillButton]s, and returns the whole thing as one view to hand to
 * `AlertDialog.Builder.setView(...)`. A hairline sits between the body and the
 * actions so the two read as separate zones.
 *
 * Use this instead of `.setPositiveButton()`/`.setNegativeButton()`/`.setNeutralButton()`
 * for every dialog with real actions. The platform's built-in button bar
 * (`ButtonBarLayout`) has an OEM-dependent stacking threshold and its own baked-in
 * minWidth/minHeight/padding from the Material text-button style — fighting it via
 * `getButton(...)` post-styling (see [styleButton]) proved unreliable across devices:
 * first no styling at all, then full-width stacked bars once padding was added, then
 * still oversized/chunky pills even after trimming that padding down. A plain
 * `LinearLayout` we build and measure ourselves sidesteps all of that and matches the
 * sizing already proven to look right elsewhere in the app — the Switch/Trigger chips
 * and the download row's Pause/Resume/Cancel buttons use this exact same [pillButton],
 * just not inside a dialog's button bar, and nobody's flagged those as too big.
 *
 * Sizing: one or two actions with short labels have room to breathe, so they get slightly
 * larger pills; three or more (or long labels) keep the compact size, which is what fits
 * three short labels on one row of a narrow phone. When the labels are too long for that (a three-way choice with
 * "Generate new"-length names), pass `stacked = true` for one full-width button per line.
 *
 * Caller is responsible for dismissing the dialog inside each [DialogAction.onClick] —
 * see the usual pattern:
 * ```
 * lateinit var dlg: AlertDialog
 * val content = activity.dialogWithActions(
 *     messageBody,
 *     DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) { ...; dlg.dismiss() },
 *     DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
 * )
 * dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
 *     .setCustomTitle(activity.dialogTitleBar("…", R.drawable.ic_add, ButtonTone.GREEN) { dlg.dismiss() })
 *     .setView(content).show()
 * ```
 * (see [dialogTitleBar] — every dialog's title goes through it, in place of the
 * plain-text `.setTitle(String)`)
 */
fun Context.dialogWithActions(
    body: View?,
    vararg actions: DialogAction,
    stacked: Boolean = false
): LinearLayout {
    val dp = resources.displayMetrics.density
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (body != null) {
        root.addView(body)
        root.addView(View(this).apply {
            setBackgroundColor(ContextCompat.getColor(context, R.color.divider))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, maxOf(1, (1 * dp).toInt())
            )
        })
    }

    if (stacked) {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
        }
        actions.forEachIndexed { i, action ->
            val btn = stackedActionButton(action)
            btn.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { if (i > 0) it.topMargin = (8 * dp).toInt() }
            column.addView(btn)
        }
        root.addView(column)
        return root
    }

    // Larger pills only when there is clearly room: at most two actions with short labels.
    // "Stop upload" + "Keep uploading" would just fit on a 360dp phone and overflow on a
    // narrower one, so longer label pairs keep the compact size.
    val roomy = actions.size <= 2 && actions.sumOf { it.label.length } <= 18
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.END
        setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
    }
    actions.forEachIndexed { i, action ->
        val btn = if (roomy) {
            pillButton(
                action.label, action.tone, action.iconRes,
                textSizeSp = 12.5f, iconSizeDp = 16, horizontalPaddingDp = 16, verticalPaddingDp = 10
            ) { action.onClick() }
        } else {
            pillButton(action.label, action.tone, action.iconRes) { action.onClick() }
        }
        btn.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { if (i > 0) it.marginStart = (8 * dp).toInt() }
        row.addView(btn)
    }
    root.addView(row)
    return root
}

/**
 * One full-width action for [dialogWithActions]'s `stacked` layout. Built as a small
 * row (icon + label, centered together) rather than a [pillButton], because a TextView's
 * compound icon stays pinned to the view's edge when the view is stretched wide.
 */
private fun Context.stackedActionButton(action: DialogAction): LinearLayout {
    val dp = resources.displayMetrics.density
    val textColor = ContextCompat.getColor(this, action.tone.textColor)
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = ContextCompat.getDrawable(context, action.tone.background)
        setPadding((16 * dp).toInt(), (11 * dp).toInt(), (16 * dp).toInt(), (11 * dp).toInt())
        isClickable = true
        isFocusable = true
        setOnClickListener { action.onClick() }
        addView(ImageView(context).apply {
            setImageResource(action.iconRes)
            imageTintList = ColorStateList.valueOf(textColor)
            layoutParams = LinearLayout.LayoutParams((16 * dp).toInt(), (16 * dp).toInt()).also {
                it.marginEnd = (8 * dp).toInt()
            }
        })
        addView(TextView(context).apply {
            text = action.label
            textSize = 13f
            setTextColor(textColor)
            setTypeface(null, Typeface.BOLD)
        })
    }
}

/** A message TextView styled to match the app's dialog theme, for use as [dialogWithActions]'s body. */
fun Context.dialogMessage(text: String): android.widget.TextView {
    val dp = resources.displayMetrics.density
    return android.widget.TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFFC7CBDD.toInt())
        setLineSpacing(0f, 1.22f)
        setPadding((20 * dp).toInt(), (6 * dp).toInt(), (20 * dp).toInt(), (14 * dp).toInt())
    }
}
