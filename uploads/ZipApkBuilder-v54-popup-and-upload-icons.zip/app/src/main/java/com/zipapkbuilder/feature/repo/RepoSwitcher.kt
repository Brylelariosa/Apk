package com.zipapkbuilder.feature.repo

import android.app.AlertDialog
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.dialogLoading
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions

/**
 * Lets the user switch which repo/branch the rest of the app targets, without
 * retyping it: [showSavedReposDialog] lists every repo the token can see (not
 * just ones used before — fetched live from GitHub, so it's never stale), and
 * [applySwitchRepo] resets every piece of per-repo session state (owner cache,
 * last build) so nothing from the previous repo leaks into the new one.
 */
class RepoSwitcher(private val activity: MainActivity) {

    /** Switches the active repo/branch and clears all stale per-repo state. */
    fun applySwitchRepo(repo: String, branch: String) {
        activity.etRepo.setText(repo)
        activity.etBranch.setText(branch)
        activity.prefs.edit().putString(PrefKeys.PREF_REPO, repo).putString(PrefKeys.PREF_BRANCH, branch).apply()
        activity.lastOwner           = ""
        activity.lastRemotePath      = ""
        activity.lastFileSha         = null
        activity.lastRunId           = -1L
        activity.artifactDownloadUrl = null
        // selectedZipName is scoped to whatever repo/build session picked it — carrying it
        // over into a different repo was a real bug: it's used as the fallback name for a
        // downloaded build log whenever that specific run's own commit message doesn't carry
        // one (e.g. a workflow_dispatch-triggered run has no upload commit to read a name
        // from at all — see Formatters.extractZipNameFromRun), so a stale value here meant a
        // log downloaded from the *new* repo could still end up named after the *previous*
        // repo's last-picked ZIP.
        activity.selectedZipName = ""
        activity.prefs.edit().remove(PrefKeys.PREF_ZIP_NAME).apply()
        activity.buildFlowController.clearBuildState(activity.prefs)
        activity.mainHandler.post {
            activity.tvOwnerInfo.text = ""; activity.tvOwnerInfo.visibility = android.view.View.GONE
            activity.showSelectedZip(null)
            activity.setStatus("Idle")
        }
        activity.appendLog("[ok] Switched to $repo @ $branch")
    }

    /**
     * Fetches all repos for the authenticated user from GitHub and shows a
     * picker. Tapping a repo immediately switches to it.
     */
    fun showSavedReposDialog() {
        val token = activity.etToken.text.toString().trim()
        if (token.isEmpty()) {
            lateinit var okDlg: AlertDialog
            val content = activity.dialogWithActions(
                activity.dialogMessage("Enter your GitHub token first so your repositories can be fetched."),
                DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { okDlg.dismiss() }
            )
            okDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setCustomTitle(activity.dialogTitleBar("GitHub token needed", R.drawable.ic_key, ButtonTone.ORANGE) { okDlg.dismiss() })
                .setView(content)
                .show()
            return
        }

        // Show a loading dialog while we fetch
        lateinit var loadingDlg: AlertDialog
        loadingDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Switch repository", R.drawable.ic_switch, ButtonTone.PRIMARY) { loadingDlg.dismiss() })
            .setView(activity.dialogLoading("Fetching your repositories…"))
            .setCancelable(true)
            .show()

        activity.bgExecutor.execute {
            try {
                // Fetch up to 100 repos sorted by most recently updated
                val url = "${GitHubApi.apiUserRepos()}?per_page=100&sort=updated&affiliation=owner,collaborator"
                val (code, body) = GitHubApi.httpGet(token, url)
                if (code != 200) throw Exception("GitHub returned HTTP $code")

                val arr = JSONArray(body)
                if (arr.length() == 0) throw Exception("No repositories found for this token.")

                // Build display list
                data class RepoEntry(val fullName: String, val name: String, val defaultBranch: String, val private: Boolean)
                val repos = (0 until arr.length()).map { i ->
                    val obj = arr.getJSONObject(i)
                    RepoEntry(
                        fullName      = obj.getString("full_name"),
                        name          = obj.getString("name"),
                        defaultBranch = obj.optString("default_branch", "main"),
                        private       = obj.optBoolean("private", false)
                    )
                }
                val lockTint = 0xFFF5A623.toInt()
                val folderTint = 0xFF7C6BFF.toInt()
                val rows = repos.map { r ->
                    IconMenuRow(
                        label = r.name,
                        iconRes = if (r.private) R.drawable.ic_lock else R.drawable.ic_folder,
                        iconTint = if (r.private) lockTint else folderTint,
                        subtitle = r.defaultBranch
                    )
                }

                activity.mainHandler.post {
                    // The fetch above can take a few seconds; if the user backed out of
                    // the app (or the Activity was otherwise torn down) in the meantime,
                    // don't touch loadingDlg or pop a new AlertDialog on a dead Activity.
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    loadingDlg.dismiss()
                    lateinit var dlgRepo: AlertDialog
                    dlgRepo = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setCustomTitle(activity.dialogTitleBar("Switch repository", R.drawable.ic_switch, ButtonTone.PRIMARY, subtitle = if (repos.size == 1) "1 repository" else "${repos.size} repositories") { dlgRepo.dismiss() })
                        .setAdapter(IconMenuAdapter(activity, rows)) { _, which ->
                            val picked = repos[which]
                            applySwitchRepo(picked.name, picked.defaultBranch)
                        }
                        .show()
                    dlgRepo.listView?.setBackgroundColor(0xFF13162A.toInt())
                }
            } catch (e: Exception) {
                activity.mainHandler.post {
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    loadingDlg.dismiss()
                    lateinit var errDlg: AlertDialog
                    val content = activity.dialogWithActions(
                        activity.dialogMessage(e.message ?: "Unknown error"),
                        DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { errDlg.dismiss() }
                    )
                    errDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setCustomTitle(activity.dialogTitleBar("Could not fetch repositories", R.drawable.ic_warning, ButtonTone.RED) { errDlg.dismiss() })
                        .setView(content)
                        .show()
                }
            }
        }
    }
}
