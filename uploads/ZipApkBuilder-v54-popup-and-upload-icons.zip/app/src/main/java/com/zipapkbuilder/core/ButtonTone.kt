package com.zipapkbuilder.core

import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import com.zipapkbuilder.R

/**
 * One design token per semantic action color, each pairing a filled/rippled
 * pill background with the text/icon color that reads correctly on it, plus an
 * [accent] used where the same meaning shows up as a tinted glyph rather than a
 * filled button (the icon tiles in dialog title bars — see [iconTile]).
 * [PillButton] and [DialogButtonStyler] both build on this — it's what lets
 * every button in the app (dialog button-bar buttons, chips, small action
 * buttons) share one consistent, rounded, rippled look instead of each call
 * site picking its own flat color and corner radius.
 *
 * Semantic convention used app-wide (documented here since it's easy for the
 * mapping to drift otherwise):
 *  - [GREEN]   creation / success / positive  — New, Create, Resume, Download
 *  - [TEAL]    primary confirm                — Save, Move, Go
 *  - [ORANGE]  trigger / build / caution      — Trigger workflow, keystore, stop upload
 *  - [RED]     destructive                    — Delete, Cancel (download), Remove
 *  - [BLUE]    informational / view            — View/Edit, Copy, Pause, View Log
 *  - [PURPLE]  secondary accent                — reserved for special emphasis
 *  - [SURFACE] neutral / dismiss               — Cancel, Close, Up, Switch, Refresh
 *  - [PRIMARY] app-brand default               — a dialog's main CTA (OK, Continue)
 */
enum class ButtonTone(
    @DrawableRes val background: Int,
    @ColorRes val textColor: Int,
    @ColorRes val accent: Int
) {
    PRIMARY(R.drawable.bg_btn_primary_ripple, R.color.text_on_color, R.color.primary_light),
    TEAL(R.drawable.bg_btn_teal_ripple, R.color.text_on_color, R.color.accent_teal),
    PURPLE(R.drawable.bg_btn_purple_ripple, R.color.text_on_color, R.color.accent_purple),
    GREEN(R.drawable.bg_btn_green_ripple, R.color.text_on_color, R.color.accent_green),
    ORANGE(R.drawable.bg_btn_orange_ripple, R.color.text_on_color, R.color.accent_orange),
    RED(R.drawable.bg_btn_red_ripple, R.color.text_on_color, R.color.accent_red),
    BLUE(R.drawable.bg_btn_blue_ripple, R.color.text_on_color, R.color.accent_blue),
    SURFACE(R.drawable.bg_btn_surface_ripple, R.color.text_primary, R.color.text_secondary),
}
