package com.zipapkbuilder.core

import android.content.Context
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/**
 * Builds a dialog's title row: an optional [iconTile] that says what kind of
 * popup this is, the title text (with an optional one-line [subtitle] under it),
 * and a real, tappable close button on the end — the same circular,
 * ripple-backed [iconButton] used everywhere else in the app for an icon-only
 * action, not a bare "✕"/"X" glyph on a plain TextView.
 * `AlertDialog.Builder.setTitle(String)` has no way to add anything alongside
 * the text at all, which is why every dialog in the app previously had no way
 * to close except tapping outside, the back button, or (where one happened to
 * exist) a "Cancel"/"Close" pill down in the button row.
 *
 * [iconRes] and [tone] are optional and default to no tile, so every existing
 * `dialogTitleBar("Title") { … }` call keeps working unchanged; pass them to
 * give a popup its marker (`R.drawable.ic_delete` + [ButtonTone.RED] for a
 * delete confirmation, and so on — see [ButtonTone] for what each tone means).
 *
 * Hand the result to `AlertDialog.Builder.setCustomTitle(...)` in place of
 * `.setTitle(...)`. [onClose] almost always just calls the dialog's own
 * `.dismiss()` — since that reference doesn't exist until `.show()` returns,
 * the usual pattern (matching [dialogWithActions]'s own kdoc) is:
 * ```
 * lateinit var dlg: AlertDialog
 * dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
 *     .setCustomTitle(activity.dialogTitleBar("Title", R.drawable.ic_folder, ButtonTone.ORANGE) { dlg.dismiss() })
 *     .setView(content)
 *     .show()
 * ```
 *
 * The rounded corners, border, dim and open/close motion every dialog has come
 * from [R.style.Theme_App_Dialog] — this function only owns the title row.
 */
fun Context.dialogTitleBar(
    title: String,
    @DrawableRes iconRes: Int? = null,
    tone: ButtonTone = ButtonTone.PRIMARY,
    subtitle: String? = null,
    onClose: () -> Unit
): LinearLayout {
    val dp = resources.displayMetrics.density
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(
            ((if (iconRes != null) 18 else 20) * dp).toInt(), (16 * dp).toInt(),
            (10 * dp).toInt(), (8 * dp).toInt()
        )

        if (iconRes != null) {
            addView(iconTile(iconRes, tone).also {
                (it.layoutParams as LinearLayout.LayoutParams).marginEnd = (12 * dp).toInt()
            })
        }

        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(TextView(context).apply {
                text = title
                textSize = 17f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
            })
            if (!subtitle.isNullOrEmpty()) {
                addView(TextView(context).apply {
                    text = subtitle
                    textSize = 12f
                    setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.MIDDLE
                    setPadding(0, (2 * dp).toInt(), 0, 0)
                })
            }
        })

        addView(
            iconButton(
                iconRes = R.drawable.ic_close,
                tint = ContextCompat.getColor(context, R.color.text_secondary)
            ) { onClose() }.apply { contentDescription = "Close" }
        )
    }
}
