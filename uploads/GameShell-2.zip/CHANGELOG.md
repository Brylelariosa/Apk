# Changelog

## 1.0
- Initial version: fullscreen immersive kiosk wrapper for a single website game
- Disk-backed asset store (`GameAssetStore`) — resources download once, then load from local storage on every later launch; non-GET requests always bypass the cache
- Version-bumped cache invalidation via `CACHE_VERSION` in `GameConfig.kt`
- Immersive mode re-asserted on focus regain so bars can't creep back after a dialog/notification pull-down
- Optional on-screen JS console overlay for debugging without ADB
- Hardware-accelerated WebView tuned for canvas/animation-heavy games; long-press text-selection popup disabled
