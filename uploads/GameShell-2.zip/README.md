# GameShell

A minimal Android wrapper that runs a website game fullscreen — no
status bar, no navigation bar — and never re-downloads the game's
assets after the first play.

## Setup

1. Open `app/src/main/java/com/gameshell/GameConfig.kt`.
2. Set `GAME_URL` to your game's URL.
3. Push. The next build points the app at your game.

No workflow file is bundled here — it builds through the existing
pipeline in the Apk repo. That pipeline expects a standard Gradle
wrapper, so this project includes `gradlew` and
`gradle/wrapper/gradle-wrapper.properties` (both plain text, pinned
to Gradle 8.6). It's still missing `gradle/wrapper/gradle-wrapper.jar`
— that one's a binary, and there's no way to fetch or generate it
without network access. It's the same file across every Gradle
project regardless of version, so grab a copy of it from any repo
that's built successfully before (MenuShell, ZipApkBuilder, whichever)
and drop it in at that exact path before this one builds.

## How the caching works

The first time the app loads your game, every GET resource it
requests — HTML, JS, CSS, images, audio — is downloaded once and
saved to the app's private storage. Every later launch loads
entirely from that local copy: zero network requests for anything
the game already fetched, even offline. Non-GET requests (API calls,
leaderboards, anything dynamic) always go straight to the network
and are never cached.

If you update the hosted game and need fresh copies fetched, bump
`CACHE_VERSION` in `GameConfig.kt` by 1 and push. The old cached
files are deleted automatically the next time the app runs.

## Debugging without ADB

Set `DEBUG_CONSOLE_ENABLED = true` in `GameConfig.kt` to show the
game's JS console output (errors, warnings, logs) as an overlay
along the bottom of the screen. Leave it `false` for normal play.

## Known caveat

XOS's WebView had IME/keyboard quirks in earlier testing (see
BrowserApp). If your game has a text input field — a name-entry box,
a chat — and the keyboard misbehaves on the HOT 11, that's the same
class of issue; the fix from BrowserApp can be ported over.

## Project structure

- `MainActivity.kt` — wires everything together
- `ImmersiveModeController.kt` — fullscreen/immersive mode, reusable
- `GameAssetStore.kt` — disk-backed resource store, keyed by URL hash
- `CachingWebViewClient.kt` — intercepts requests, serves from the store
- `GameConfig.kt` — the three things you're likely to change
