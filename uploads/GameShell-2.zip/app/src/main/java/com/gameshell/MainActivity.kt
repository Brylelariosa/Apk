package com.gameshell

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import com.gameshell.databinding.ActivityMainBinding

class MainActivity : Activity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var immersiveMode: ImmersiveModeController

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        immersiveMode = ImmersiveModeController(this).also { it.apply() }
        configureWebView()

        val assetStore = GameAssetStore(applicationContext, GameConfig.CACHE_VERSION)
        binding.gameWebView.webViewClient = CachingWebViewClient(assetStore)
        binding.gameWebView.webChromeClient = buildChromeClient()

        if (savedInstanceState == null) {
            binding.gameWebView.loadUrl(GameConfig.GAME_URL)
        }
    }

    private fun configureWebView() {
        binding.gameWebView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        binding.gameWebView.apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            isHorizontalScrollBarEnabled = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isLongClickable = false
            setOnLongClickListener { true } // swallow long-press so no text-selection/share popup interrupts play
        }
    }

    private fun buildChromeClient() = object : WebChromeClient() {
        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
            if (GameConfig.DEBUG_CONSOLE_ENABLED) {
                binding.debugConsole.visibility = View.VISIBLE
                binding.debugConsole.append(
                    "${message.messageLevel()}: ${message.message()} (${message.lineNumber()})\n"
                )
            }
            return true
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        immersiveMode.onWindowFocusChanged(hasFocus)
    }

    override fun onBackPressed() {
        // Swallow back when there's no in-page history so a stray
        // edge-swipe can't exit a fullscreen game mid-play.
        if (binding.gameWebView.canGoBack()) {
            binding.gameWebView.goBack()
        }
    }

    override fun onDestroy() {
        binding.gameWebView.destroy()
        super.onDestroy()
    }
}
