package com.gameshell

import android.util.Log
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Serves a GET resource from [assetStore] once it has been confirmed to be a
 * static asset and fetched once, so a game's static files are downloaded
 * exactly one time and every later play loads them entirely from local
 * storage. Non-GET requests, and any GET request that isn't confidently a
 * static asset - dynamic/API calls, login, session, account, or anything
 * unclassified - always pass straight through to WebView's own network
 * stack untouched, so cookies, redirects, and auth state stay correct.
 */
class CachingWebViewClient(private val assetStore: GameAssetStore) : WebViewClient() {

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        if (request.method != "GET") return null

        val url = request.url.toString()

        if (!isStaticAssetRequest(request)) {
            logCacheDecision("BYPASS DYNAMIC", url)
            return null
        }

        assetStore.get(url)?.let { cached ->
            logCacheDecision("CACHE HIT", url)
            return WebResourceResponse(cached.mimeType, null, FileInputStream(cached.bodyFile))
        }

        return fetchAndCacheStaticAsset(url, request.requestHeaders)
    }

    /** True only for GET requests confidently classified as static assets - see [isStaticAssetUrl]. */
    private fun isStaticAssetRequest(request: WebResourceRequest): Boolean =
        isStaticAssetUrl(request.url.toString())

    /**
     * A URL is a cacheable static asset only if it doesn't look dynamic/authenticated
     * ([isDynamicRequest] - checked first, taking priority over the extension check)
     * AND its path ends in a known static-resource extension. Anything else, including
     * anything that can't be confidently classified, is treated as dynamic by default.
     */
    private fun isStaticAssetUrl(url: String): Boolean {
        if (isDynamicRequest(url)) return false
        val path = runCatching { URL(url).path }.getOrDefault(url).lowercase()
        return STATIC_ASSET_EXTENSIONS.any { path.endsWith(it) }
    }

    /**
     * Keyword-based check for login/session/account/API-style hosts or paths. This
     * takes priority over the extension check: a URL matching any of these is never
     * treated as a cacheable static asset, however static-looking its extension is.
     */
    private fun isDynamicRequest(url: String): Boolean {
        val lower = url.lowercase()
        return DYNAMIC_URL_KEYWORDS.any { lower.contains(it) }
    }

    /** Dynamic or unrecognized response content types must never enter the persistent cache. */
    private fun isDynamicMimeType(mimeType: String?): Boolean {
        val normalized = mimeType?.substringBefore(";")?.trim()?.lowercase()
        return normalized == null || normalized !in STATIC_MIME_TYPES
    }

    private fun fetchAndCacheStaticAsset(url: String, headers: Map<String, String>): WebResourceResponse? {
        val connection = try {
            (URL(url).openConnection() as HttpURLConnection).apply {
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
                CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
                instanceFollowRedirects = true
                connectTimeout = 15_000
                readTimeout = 15_000
                connect()
            }
        } catch (e: Exception) {
            return null // fall back to WebView's own network handling
        }

        return try {
            if (connection.responseCode !in 200..299) return null

            // A redirect may have landed somewhere no longer static/safe. getURL()
            // reflects the final, post-redirect location once the response has been
            // read, so re-confirm classification before trusting this for the cache.
            val finalUrl = connection.url.toString()
            if (!isStaticAssetUrl(finalUrl)) {
                logCacheDecision("BYPASS DYNAMIC", finalUrl)
                return null
            }

            val mimeType = connection.contentType?.substringBefore(";")?.trim()
                ?: guessMimeType(finalUrl)

            if (isDynamicMimeType(mimeType)) {
                logCacheDecision("BYPASS DYNAMIC", finalUrl)
                return null
            }

            val bytes = connection.inputStream.use { it.readBytes() }
            assetStore.put(url, mimeType, bytes)
            logCacheDecision("CACHE STATIC", url)
            WebResourceResponse(mimeType, null, ByteArrayInputStream(bytes))
        } catch (e: Exception) {
            null // fall back to WebView's own network handling
        } finally {
            connection.disconnect()
        }
    }

    private fun guessMimeType(url: String): String =
        MimeTypeMap.getFileExtensionFromUrl(url)
            ?.let { MimeTypeMap.getSingleton().getMimeTypeFromExtension(it) }
            ?: "application/octet-stream"

    /**
     * Debug-only cache-decision logging, gated behind the project's existing debug
     * flag. Logs scheme/host/path only - never the query string, headers, or cookies,
     * since a query string can carry a token or similar credential.
     */
    private fun logCacheDecision(decision: String, url: String) {
        if (!GameConfig.DEBUG_CONSOLE_ENABLED) return
        val safeUrl = runCatching {
            URL(url).let { "${it.protocol}://${it.host}${it.path}" }
        }.getOrDefault("<unparsable url>")
        Log.d(TAG, "$decision: $safeUrl")
    }

    companion object {
        private const val TAG = "CachingWebViewClient"

        private val STATIC_ASSET_EXTENSIONS = listOf(
            ".js", ".mjs", ".css",
            ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".ico",
            ".woff", ".woff2", ".ttf", ".otf",
            ".mp3", ".ogg", ".wav", ".m4a", ".webm", ".mp4"
        )

        private val STATIC_MIME_TYPES = setOf(
            "text/css",
            "text/javascript", "application/javascript", "application/x-javascript",
            "image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml",
            "image/x-icon", "image/vnd.microsoft.icon",
            "font/woff", "font/woff2", "font/ttf", "font/otf", "font/sfnt",
            "application/font-woff", "application/font-woff2",
            "application/x-font-ttf", "application/x-font-otf",
            "audio/mpeg", "audio/ogg", "audio/wav", "audio/x-wav", "audio/mp4", "audio/x-m4a",
            "video/webm", "video/mp4"
        )

        // Keyword match takes priority over extension checks: any of these appearing
        // anywhere in the URL marks it dynamic/authenticated, regardless of how static
        // the path or extension looks.
        private val DYNAMIC_URL_KEYWORDS = listOf(
            "login", "logout", "signin", "sign-in", "signout", "sign-out",
            "auth", "session", "account", "credential", "token",
            "user", "save", "sync", "api"
        )
    }
}
