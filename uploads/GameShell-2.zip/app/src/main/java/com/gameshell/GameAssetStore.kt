package com.gameshell

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * Persists downloaded game resources to disk so they never need to be
 * fetched twice. Stored under the app's private files directory
 * (not the OS-clearable cache dir), so it survives storage pressure
 * and only clears when [GameConfig.CACHE_VERSION] changes or the user
 * clears app storage by hand.
 */
class GameAssetStore(context: Context, cacheVersion: Int) {

    private val currentDir =
        File(context.filesDir, "game_assets/v$cacheVersion").apply { mkdirs() }

    init {
        pruneOtherVersions(context, cacheVersion)
    }

    fun get(url: String): CachedResource? {
        val key = keyFor(url)
        val body = File(currentDir, "$key.body")
        val mime = File(currentDir, "$key.mime")
        if (!body.exists() || !mime.exists()) return null
        return CachedResource(mime.readText().trim(), body)
    }

    fun put(url: String, mimeType: String, bytes: ByteArray) {
        val key = keyFor(url)
        val bodyTmp = File(currentDir, "$key.body.tmp")
        val mimeTmp = File(currentDir, "$key.mime.tmp")
        bodyTmp.writeBytes(bytes)
        mimeTmp.writeText(mimeType)
        // Write-then-rename is atomic on the same filesystem, so a
        // concurrent reader (WebView loads many resources in parallel)
        // never sees a half-written file.
        bodyTmp.renameTo(File(currentDir, "$key.body"))
        mimeTmp.renameTo(File(currentDir, "$key.mime"))
    }

    private fun keyFor(url: String): String =
        MessageDigest.getInstance("SHA-256").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun pruneOtherVersions(context: Context, keep: Int) {
        File(context.filesDir, "game_assets")
            .listFiles { f -> f.isDirectory && f.name != "v$keep" }
            ?.forEach { it.deleteRecursively() }
    }

    data class CachedResource(val mimeType: String, val bodyFile: File)
}
