package com.mgba.android

import android.Manifest
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn:  Button
    private lateinit var changeRomBtn: TextView
    private lateinit var linkBtn:     TextView
    private lateinit var settingsBtn: TextView
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    // BUG FIX ("buttons disappear while dragging"): this used to be a
    // `mutableListOf<ButtonDef>()` that buildControlLayout() mutated in
    // place — buttons.clear() followed by ~11 buttons += calls. That's
    // called on every ACTION_MOVE while dragging a button in the editor
    // (see onEditTouch), i.e. dozens of times a second, ON THE UI THREAD —
    // while the game thread's render loop reads this same list ~60x/sec to
    // draw it (drawControls()). There was no synchronization between the
    // two, so the render thread could paint a frame at the exact moment the
    // list was between clear() and being refilled: every button vanishes
    // for that one frame. Worse under load (exactly when you're actively
    // dragging), which matches "it freezes/disappears when you move it".
    // Fix: build a brand-new list off to the side and swap the *reference*
    // in one atomic write. The render thread then only ever sees a fully
    // "old" or fully "new" list, never a half-built one.
    @Volatile private var buttons: List<ButtonDef> = emptyList()
    private var controlsTop = 0f
    @Volatile private var pickerLive = false
    private lateinit var link: LinkMultiplayer

    // ── Control layout editor ────────────────────────────────────────────────
    // Per-button position/size/opacity overrides, keyed by stable button id
    // ("dpad","a","b","start","select","l","r","ff", …). Absent from the
    // map == "use the default geometric layout computed in buildControlLayout()".
    // Positions are stored as FRACTIONS of screen width/height (not raw
    // pixels) so a saved layout still makes sense if the app is later run on
    // a different screen size. Persisted as JSON in SharedPreferences,
    // keyed per orientation (see orientationTag()) so a future portrait mode
    // doesn't inherit an unsuitable landscape layout — today the activity is
    // locked to landscape (android:screenOrientation="landscape"), so only
    // the "land" profile is ever active, but the storage format doesn't need
    // to change when portrait support is eventually added.
    private data class LayoutEntry(
        var xFrac: Float,
        var yFrac: Float,
        var scale: Float = 1f,
        var alphaOverride: Int = -1,   // -1 == inherit the global idle-alpha setting
        var locked: Boolean = false
    )
    private data class Geometry(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val customLayout = mutableMapOf<String, LayoutEntry>()
    private val defaultGeometry = mutableMapOf<String, Geometry>()
    private var lastSw = 0f
    private var lastSh = 0f

    @Volatile private var editModeActive = false
    private var editSelectedId: String? = null
    private var editDragPointerId = -1
    private var editDragOffX = 0f   // touch point minus button center, at drag start
    private var editDragOffY = 0f
    private var editResizing = false
    private var editResizeStartDist = 0f
    private var editResizeStartScale = 1f
    private var editDirty = false   // true once the working copy diverges from what's saved
    private lateinit var editTopBar: LinearLayout
    private lateinit var editButtonBar: LinearLayout
    private lateinit var editButtonLabel: TextView
    private lateinit var editLockBtn: Button

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f
    @Volatile private var fastForwardActive = false
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0

    // ── Fullscreen mode (toggled ONLY from Settings) ───────────────────────
    @Volatile private var fullscreenMode = false

    // ── Button / screen customization ─────────────────────────────────────
    private var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    private var buttonBaseAlpha       = 160    // idle opacity 0-255
    private var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65

    // ── Button click sound ───────────────────────────────────────────────
    // Uses the system's built-in FX_KEYPRESS_STANDARD effect via AudioManager
    // rather than SoundPool/MediaPlayer. That matters for two reasons:
    //  1. No asset file needed — the sound ships with the OS.
    //  2. playSoundEffect() is fire-and-forget and non-blocking; it's cached
    //     by the system after the first call. A prior approach that created
    //     a MediaPlayer (or cold-loaded a SoundPool sample) on every touch
    //     event would synchronously decode/prepare audio on the UI thread —
    //     and since updateGameKeys() runs on EVERY ACTION_MOVE while
    //     dragging (not just on initial press), that's dozens of blocking
    //     calls per second, which is exactly what freezes the UI.
    // We avoid both problems by only firing on the RISING EDGE of a button
    // press (see updateGameKeys) and by using the pre-cached system effect.
    private var buttonSoundEnabled = false
    private var lastSoundKeys      = 0
    private var audioManager: AudioManager? = null

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)
    private var audioDiagCounter = 0
    // AUDIO FIX (this pass): audio focus was never requested. AudioTrack will
    // still *build* and accept writes without it, but several OEM audio HALs
    // (MIUI/ColorOS/FuntouchOS in particular) silently keep a stream's output
    // gain at zero — not muted, not erroring, just inaudible — until the app
    // holding the Surface/foreground also holds AUDIOFOCUS_GAIN. Requesting
    // it costs nothing on stock AOSP devices where sound already worked.
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* no-op: USAGE_GAME doesn't duck */ }

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f
        private const val CTRL_FRAC_FULL  = 0.60f

        // ── GBA hardware timing ─────────────────────────────────────────────
        // AUDIO FIX (root cause #1): the old loop paced itself with
        // Thread.sleep(1_000_000_000.0 / 60.0) — i.e. it assumed an exact
        // 60.000 Hz refresh. Real GBA hardware runs at CPU_CLOCK / CYCLES_PER_FRAME
        // = 16777216 / 280896 ≈ 59.7275 Hz. Pacing 0.46% too fast meant the game
        // thread fed the blip_buf resampler audio slightly faster than a
        // 44.1 kHz AudioTrack could drain it. Since the old code wrote with
        // WRITE_NON_BLOCKING and never checked the return value, that constant
        // small surplus was silently dropped by AudioTrack roughly every 3–4
        // real seconds — an audible periodic "stutter" that would read as
        // "audio is a little broken" on a real device even though nothing was
        // ever fully silent. Below are the exact constants (matching
        // GBA_AUDIO_CLOCK in mgba_jni.c) used for the corrected pacing.
        private const val GBA_CPU_CLOCK_HZ    = 16_777_216L   // 2^24, ARM7TDMI clock
        private const val GBA_CYCLES_PER_FRAME = 280_896L     // 228 lines * 1232 cycles
        // Only used as a *fallback* pacer for frames that produce no audio
        // (e.g. the first frame or two right after a ROM loads, before the
        // blip_buf resamplers have accumulated a full sample). Normal frames
        // are paced by the AudioTrack itself — see startGameLoop().
        private val FALLBACK_FRAME_NS =
            GBA_CYCLES_PER_FRAME * 1_000_000_000L / GBA_CPU_CLOCK_HZ

        // SharedPreferences
        private const val PREFS            = "mgba_prefs"
        private const val PREF_FF_SPEED    = "ff_speed"
        private const val PREF_BTN_SCALE   = "btn_scale"
        private const val PREF_BTN_ALPHA   = "btn_alpha"
        private const val PREF_SCREEN_FRAC = "screen_frac"
        private const val PREF_FULLSCREEN  = "fullscreen"
        private const val PREF_BTN_SOUND   = "btn_sound"
        private const val PREF_LAYOUT_PREFIX = "layout_"
    }

    private data class ButtonDef(
        val id: String, val rect: RectF, val keyMask: Int, val label: String, val color: Int,
        val isDpad: Boolean = false
    )

    // ── ROM picker ─────────────────────────────────────────────────────────

    // FIX: BLUETOOTH_CONNECT / BLUETOOTH_SCAN are runtime-dangerous permissions
    // on API 31+ (Android 12+). They were declared in the manifest but never
    // actually requested anywhere, so every Bluetooth link-cable action
    // (Host, Join, listing bonded devices) threw an uncaught SecurityException
    // and crashed the app on any Android 12+ device. This launcher requests
    // the permission on demand; [pendingBtAction] resumes whatever the user
    // was trying to do as soon as it's granted.
    private var pendingBtAction: (() -> Unit)? = null
    private val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingBtAction; pendingBtAction = null
        if (granted) action?.invoke()
        else uiToast("Bluetooth permission is required for BT link cable")
    }

    /** Runs [action] immediately if Bluetooth permission is already granted
     *  (or not needed on this API level), otherwise requests it first. */
    private fun ensureBluetoothPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) { action() }
        else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        Thread {
            try {
                // FIX: stop any in-progress game loop *before* touching the
                // native core, and reset transient input/FF state. Previously
                // there was no way to load a second ROM at all (loadRomBtn was
                // permanently hidden after the first successful load), so this
                // path was never exercised. Note: nativeLoadROM() destroys the
                // old native core unconditionally before loading the new file —
                // if the new file fails to load, the previous game session is
                // gone rather than restored. Fixing that fully needs a native-
                // side change (keep old core until the new one loads OK); flagged
                // here as a known residual risk rather than silently hidden.
                stopGameLoop()
                val tmp = cacheDir.resolve("rom_loaded.gba")
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                } ?: run { uiToast("Cannot read selected file"); return@Thread }
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)
                Handler(Looper.getMainLooper()).post {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth()
                        val h = EmulatorEngine.nativeGetHeight()
                        frameBitmap = Bitmap.createBitmap(
                            w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        romLoaded = true
                        currentKeys.set(0)
                        fastForwardActive = false
                        loadRomBtn.visibility   = View.GONE
                        linkBtn.visibility      = View.VISIBLE
                        changeRomBtn.visibility = View.VISIBLE
                        initAudioTrack()
                        startGameLoop()
                    } else {
                        romLoaded = false
                        uiToast("Unsupported ROM format")
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            fullscreenMode        = p.getBoolean(PREF_FULLSCREEN, false)
            buttonSoundEnabled    = p.getBoolean(PREF_BTN_SOUND,  false)
        }
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        loadCustomLayout()

        link = LinkMultiplayer(this)
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK); textSize = 16f
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })

        linkBtn = TextView(this).apply {
            text = "🔗 Link"; textSize = 13f
            setTextColor(Color.WHITE); setPadding(20, 10, 20, 10)
            setBackgroundColor(Color.parseColor("#44000000"))
            visibility = View.GONE
            setOnClickListener { showLinkDialog() }
        }
        root.addView(linkBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 8 })

        // FIX: previously there was NO way to load a different ROM once one
        // was loaded — loadRomBtn was hidden forever and nothing replaced it.
        // Switching games required force-killing and restarting the app.
        changeRomBtn = TextView(this).apply {
            text = "📂"; textSize = 16f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            setBackgroundColor(Color.parseColor("#44000000"))
            visibility = View.GONE
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(changeRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 96 })

        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            setBackgroundColor(Color.parseColor("#44000000"))
            setOnClickListener { showSettingsDialog() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.START; it.topMargin = 8; it.leftMargin = 8 })

        // ── Control-layout editor UI ────────────────────────────────────────
        // Two small real-View toolbars layered above the SurfaceView. Editing
        // itself (drag/resize hit-testing) happens on the SurfaceView's touch
        // events (see onEditTouch) exactly like normal gameplay input — these
        // bars are just chrome: mode controls + per-button fine adjustment.
        fun editChip(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setPadding(18, 4, 18, 4)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#552A2A3A"))
            setOnClickListener { onClick() }
        }

        editTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.parseColor("#DD1A1A22"))
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "🖊 EDIT LAYOUT — drag to move, corner handle to resize"
                setTextColor(Color.parseColor("#FFEE58")); textSize = 12f
                setPadding(8, 8, 24, 8)
            })
            addView(editChip("↺ Reset All") { confirmResetAllLayout() })
            addView(editChip("✕ Cancel")    { exitEditMode(save = false) })
            addView(editChip("✓ Done")      { exitEditMode(save = true) })
        }
        root.addView(editTopBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; it.topMargin = 8 })

        editButtonLabel = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(14, 4, 14, 4)
        }
        editLockBtn = editChip("🔓") { toggleSelectedLock() }
        editButtonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 6, 10, 6)
            setBackgroundColor(Color.parseColor("#EE22222E"))
            visibility = View.GONE
            addView(editButtonLabel)
            addView(editChip("Size－") { adjustSelectedScale(-0.1f) })
            addView(editChip("Size＋") { adjustSelectedScale(+0.1f) })
            addView(editChip("Op－")   { adjustSelectedAlpha(-20) })
            addView(editChip("Op＋")   { adjustSelectedAlpha(+20) })
            addView(editLockBtn)
            addView(editChip("↺") { editSelectedId?.let { resetSingleButton(it) } })
        }
        // Positioned dynamically (see refreshEditToolbarPosition) — x/y set
        // directly rather than via gravity, since it needs to track whichever
        // button is currently selected.
        root.addView(editButtonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // FIX: no onPause/onResume existed at all. The emulation thread and the
    // AudioTrack were only ever stopped from surfaceDestroyed()/onDestroy(),
    // but backgrounding an app (Home button, recents, notification shade)
    // does not reliably or promptly destroy a SurfaceView's Surface — so the
    // game kept running full-speed and audio kept playing while the app was
    // not visible, burning battery/CPU and producing audio "leaking" behind
    // whatever the user switched to. This is exactly the kind of background
    // battery-drain behavior Play Console's background-usage checks flag.
    override fun onPause() {
        super.onPause()
        stopGameLoop()
        try {
            audioTrack?.pause()
            // AUDIO FIX: pause() alone leaves whatever was already queued in
            // the AudioTrack's internal buffer intact. If the app is
            // backgrounded for a while and then resumed, that stale audio
            // would play first, ahead of anything the resumed game loop
            // writes — an audible "blip" of old sound. flush() (only valid
            // once paused/stopped) discards it so resume always starts clean.
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (romLoaded && surfaceHolder != null && !running) {
            startGameLoop()
        }
    }

    // ── Audio ──────────────────────────────────────────────────────────────
    //
    // AUDIO ARCHITECTURE (rewritten)
    // ───────────────────────────────
    // Old design: game thread ran nativeRunFrame() once, wrote PCM to
    // AudioTrack with WRITE_NON_BLOCKING (return value discarded), then slept
    // for a *fixed* 1/60 s to pace itself. Two compounding problems:
    //   1. 1/60 s is not the GBA's real frame period (see GBA_CYCLES_PER_FRAME
    //      above), so the loop fed audio ~0.46% faster than it could play.
    //   2. WRITE_NON_BLOCKING silently drops whatever doesn't fit — so that
    //      surplus was thrown away in little bursts instead of building
    //      genuine latency, producing a small periodic glitch.
    //
    // New design: the game thread writes PCM with a genuine *blocking* write
    // and does NOT sleep on its own for the normal-speed case — the blocking
    // write against a real audio clock (the DAC/HAL drain rate) becomes the
    // frame pacer. This is the same "audio-locked" sync strategy used by most
    // well-engineered software emulators: the audio hardware clock is far more
    // stable than Thread.sleep(), which is at the mercy of OS scheduling
    // jitter, so tying video pacing to it removes drift entirely instead of
    // approximating a fixed wall-clock rate. A short fallback sleep
    // (FALLBACK_FRAME_NS) only kicks in for frames that produce zero audio
    // samples (e.g. immediately after a ROM loads), so the loop never spins
    // unpaced if audio is temporarily unavailable.
    //
    // Fast-forward keeps dropping audio outright (see the game loop) rather
    // than writing pitch-shifted audio — resampling audio to match an
    // arbitrary FF multiplier without introducing artifacts is a substantial
    // DSP problem on its own (a proper implementation needs a good
    // interpolating resampler, not a naive one, to avoid aliasing); silence
    // during FF is standard behavior across essentially every GBA/SNES/NES
    // emulator and is a deliberate scope decision, not an oversight.
    // (audioTrack / audioBuffer / audioDiagCounter fields are declared above,
    // grouped with the rest of the class's mutable state.)

    /**
     * (Re)creates the AudioTrack.
     *
     * Buffer size: minBuf * 2 rather than the old minBuf * 4. With blocking
     * writes now providing the pacing, a smaller buffer means lower
     * end-to-end audio latency (less "delay" between an in-game sound effect
     * and hearing it) while still giving enough cushion to absorb a slow
     * render frame without an audible underrun. minBuf*2 vs *4 is exactly the
     * kind of tradeoff a future "audio latency" setting (mentioned in the
     * features roadmap) would expose to the user instead of hardcoding.
     *
     * PERFORMANCE_MODE_LOW_LATENCY (API 26+) opts into the platform's fast
     * mixer path when the device supports it. It's a request, not a
     * guarantee — unsupported devices silently fall back to the normal path
     * with no functional risk, so it's safe to always ask for it.
     */
    private fun initAudioTrack() {
        releaseAudio()
        val minBuf = AudioTrack.getMinBufferSize(
            44100,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        val bufferBytes = (minBuf * 2).coerceAtLeast(4096)

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }

        audioTrack = try { builder.build() } catch (e: Exception) {
            Log.e(TAG, "AudioTrack.Builder failed, retrying without low-latency mode", e)
            // Some OEM audio HALs reject PERFORMANCE_MODE_LOW_LATENCY outright
            // instead of gracefully degrading. Retry once without it so a
            // quirky device still gets sound, even if not the fast path.
            try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(44100)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e2: Exception) {
                Log.e(TAG, "AudioTrack unavailable on this device", e2)
                null
            }
        }
        // Explicit full volume — build() already defaults to 1.0f, but this
        // removes any doubt on OEM tracks that have shipped odd defaults.
        try { audioTrack?.setVolume(1.0f) } catch (_: Exception) {}
        requestAudioFocus()
        audioTrack?.play()
        audioDiagCounter = 0
        Log.d(TAG, "AudioTrack started (bufferBytes=$bufferBytes, minBuf=$minBuf, " +
                "lowLatency=${Build.VERSION.SDK_INT >= Build.VERSION_CODES.O})")
    }

    /** See the comment on [audioFocusRequest] for why this exists. */
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        Log.d(TAG, "Audio focus granted=$granted")
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusListener)
        }
    }

    private fun releaseAudio() {
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        abandonAudioFocus()
    }

    /**
     * Blocking write of [count] interleaved stereo PCM pairs from
     * [audioBuffer] to the AudioTrack. Called from the game thread only.
     *
     * Unlike the old WRITE_NON_BLOCKING call (whose return value was
     * discarded), this checks the result:
     *   - a short write (0 < written < requested) retries the remainder —
     *     legitimate under blocking mode only if playback state changed
     *     mid-write (e.g. onPause() firing concurrently), in which case
     *     finishing the write is harmless and cheap.
     *   - ERROR_DEAD_OBJECT means the audio server died/restarted under us
     *     (e.g. mediaserver crash, or another app seized exclusive audio) —
     *     recreate the AudioTrack once and retry, rather than staying silent
     *     for the rest of the session.
     *   - any other negative error code is logged and the frame's audio is
     *     dropped; retrying indefinitely inside the game loop would risk
     *     hanging it.
     */
    private fun writePcm(count: Int) {
        if (count <= 0) return
        val totalShorts = count * 2
        var track = audioTrack ?: return
        var offset = 0
        var attempts = 0
        while (offset < totalShorts && attempts < 2) {
            val n = try {
                track.write(audioBuffer, offset, totalShorts - offset, AudioTrack.WRITE_BLOCKING)
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack.write threw", e); return
            }
            when {
                n > 0 -> offset += n
                n == AudioTrack.ERROR_DEAD_OBJECT -> {
                    Log.w(TAG, "AudioTrack died — reinitializing")
                    initAudioTrack()
                    track = audioTrack ?: return
                    attempts++
                }
                n < 0 -> { Log.e(TAG, "AudioTrack.write error=$n"); return }
                else  -> return // n == 0: track not started / no progress possible right now
            }
        }
        // Lightweight real-device diagnostics: log the underrun counter every
        // ~5s (300 frames @ ~60Hz) rather than every frame, so it's cheap
        // enough to leave in a release build's logcat for field debugging.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioDiagCounter++
            if (audioDiagCounter >= 300) {
                audioDiagCounter = 0
                Log.d(TAG, "AudioTrack underrunCount=${audioTrack?.underrunCount}")
            }
        }
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) { updateGameMatrix(w.toFloat(), h.toFloat()); if (!running) startGameLoop() }
    }

    // ── Game loop ──────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bmp = frameBitmap ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) { buildControlLayout(sw, sh); updateGameMatrix(sw, sh) }
        try { audioTrack?.play() } catch (_: Exception) {}
        running = true
        ffFrameAccumulator = 0.0
        gameThread = Thread {
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(currentKeys.get())
                    var wroteAudio = false
                    for (i in 0 until framesToRun) {
                        EmulatorEngine.nativeRunFrame(bmp)
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        if (n > 0 && !fastForwardActive) {
                            writePcm(n)   // blocking — this *is* the frame pacer now
                            wroteAudio = true
                        }
                    }

                    renderFrame(bmp)

                    if (fastForwardActive) {
                        // Intentionally unpaced — see the audio-architecture note
                        // above for why FF drops audio instead of pitch-shifting it.
                    } else if (!wroteAudio) {
                        // Fallback pacer for the rare frame that produced no audio
                        // (e.g. immediately after a ROM loads, before blip_buf has
                        // accumulated a full sample, or if this device has no usable
                        // AudioTrack at all). Uses the real GBA frame period so even
                        // this fallback doesn't reintroduce the old 60.000 Hz drift.
                        val elapsed = System.nanoTime() - t0
                        val sleepMs = (FALLBACK_FRAME_NS - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                    // Normal case: writePcm() above already blocked until the
                    // audio HAL had room for this frame's samples, which paces
                    // the loop against the real device audio clock — no
                    // Thread.sleep() needed and no drift accumulates.
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        // 750ms rather than 500ms: the game thread may be inside a blocking
        // AudioTrack.write() call (see writePcm()). Android unblocks a
        // pending write when the track's play state changes from another
        // thread, so this should return almost immediately in practice —
        // the extra margin only matters on a slow/unusual audio HAL.
        gameThread?.join(750)
        gameThread = null
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
            if (editModeActive) drawEditOverlay(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (fastForwardActive) drawFfOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ────────────────────────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp   = frameBitmap ?: return
        val gameH = if (fullscreenMode) sh else sh * gameScreenFraction
        val scale = minOf(sw / bmp.width, gameH / bmp.height)
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(
            (sw - bmp.width  * scale) / 2f,
            (gameH - bmp.height * scale) / 2f
        )
    }

    // ── Controls layout ────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
     * gameScreenFraction controls where the controls strip begins.
     *
     * Fullscreen mode: game fills screen, controls overlay from CTRL_FRAC_FULL.
     * Normal mode    : game in top [gameScreenFraction] fraction.
     *
     * NOTE: the fullscreen ⛶ button was REMOVED from the game screen.
     * Toggle fullscreen from ⚙ Settings instead.
     */
    // ── Layout persistence ───────────────────────────────────────────────────

    private fun orientationTag(): String =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "land" else "port"

    private fun loadCustomLayout() {
        customLayout.clear()
        val raw = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_LAYOUT_PREFIX + orientationTag(), null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                customLayout[o.getString("id")] = LayoutEntry(
                    xFrac = o.getDouble("x").toFloat(),
                    yFrac = o.getDouble("y").toFloat(),
                    scale = o.optDouble("scale", 1.0).toFloat(),
                    alphaOverride = o.optInt("alpha", -1),
                    locked = o.optBoolean("locked", false)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt saved layout, ignoring", e)
        }
    }

    private fun saveCustomLayout() {
        try {
            val arr = JSONArray()
            for ((id, e) in customLayout) {
                arr.put(JSONObject().apply {
                    put("id", id); put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
                    put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
                })
            }
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PREF_LAYOUT_PREFIX + orientationTag(), arr.toString())
                .apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save layout", e)
            uiToast("Couldn't save layout")
        }
        editDirty = false
    }

    /** Computes the on-screen rect for [id] given its DEFAULT center/size,
     *  applying any saved/in-progress override. Always records the default
     *  geometry so "reset this button" and a brand-new drag both have a
     *  known baseline to work from, even if a saved override already exists. */
    private fun resolvedRect(id: String, cx: Float, cy: Float, w: Float, h: Float): RectF {
        defaultGeometry[id] = Geometry(cx, cy, w, h)
        val ov = customLayout[id]
        val fcx = if (ov != null) ov.xFrac * lastSw else cx
        val fcy = if (ov != null) ov.yFrac * lastSh else cy
        val scale = ov?.scale ?: 1f
        val fw = (w * scale).coerceAtLeast(1f)
        val fh = (h * scale).coerceAtLeast(1f)
        return RectF(fcx - fw / 2f, fcy - fh / 2f, fcx + fw / 2f, fcy + fh / 2f)
    }

    // Scratch list buildControlLayout() appends into via addButton(); only
    // ever touched from the UI thread, then published atomically to
    // `buttons` in one assignment at the end of buildControlLayout().
    private var buildingButtons = mutableListOf<ButtonDef>()

    private fun addButton(id: String, cx: Float, cy: Float, w: Float, h: Float, mask: Int, label: String, color: Int, isDpad: Boolean = false) {
        buildingButtons += ButtonDef(id, resolvedRect(id, cx, cy, w, h), mask, label, color, isDpad)
    }

    // ── Control layout (positions/sizes) ────────────────────────────────────
    //
    // CONTROL EDITOR (feature #2): every button below is now addressable by a
    // stable id and routed through resolvedRect()/addButton(), which checks
    // customLayout for a saved override before falling back to the default
    // formula. The formulas themselves are UNCHANGED from the original
    // design — they're still exactly what you get on a fresh install or
    // after "Reset all" — only the indirection through an override is new.
    private fun buildControlLayout(sw: Float, sh: Float) {
        buildingButtons = mutableListOf()
        lastSw = sw; lastSh = sh
        controlsTop = sh * (if (fullscreenMode) CTRL_FRAC_FULL else gameScreenFraction)
        val padH = sh - controlsTop

        // Apply scale multiplier to all button sizes
        val s      = buttonScaleMultiplier
        val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
        val abSz   = btnSz * 0.94f

        // ── D-pad (left side) ────────────────────────────────────────────
        // FEATURE: unified into ONE control (id "dpad") instead of four
        // separate up/down/left/right hitboxes. Two problems that fixes:
        //  1. Editor UX — previously you had to drag/resize 4 buttons
        //     individually to reshape the d-pad, easy to knock out of
        //     alignment. Now it's one object, exactly like My Boy!'s pad.
        //  2. Diagonals — the old 4 separate rects had gaps between them
        //     (arranged in a cross with `step` spacing), so touching between
        //     e.g. up and right hit NEITHER hitbox — diagonal input was
        //     physically impossible. The unified pad hit-tests by angle
        //     (see dpadKeysFor()) so diagonals work like a real d-pad.
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        val dpadSize = btnSz * 3.0f
        addButton("dpad", dpCx, dpCy, dpadSize, dpadSize, 0, "", Color.parseColor("#555566"), isDpad = true)

        // ── A / B (right side) ────────────────────────────────────────────
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        addButton("a", abCx+abGap, abCy, abSz, abSz, EmulatorEngine.KEY_A, "A", Color.parseColor("#CF6679"))
        addButton("b", abCx-abGap, abCy, abSz, abSz, EmulatorEngine.KEY_B, "B", Color.parseColor("#4FC3F7"))

        // ── Select / Start (centre) ───────────────────────────────────────
        val ssW  = sw * 0.11f * s;  val ssH  = sh * 0.038f * s
        val ssCy = controlsTop + padH * 0.82f + ssH / 2f
        val ssGap = sw * 0.07f
        addButton("select", sw/2f-ssGap-ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_SELECT, "SEL", Color.parseColor("#444455"))
        addButton("start",  sw/2f+ssGap+ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_START,  "STA", Color.parseColor("#444455"))

        // ── L / R shoulder buttons ─────────────────────────────────────────
        val lrW = sw * 0.13f * s;  val lrH = sh * 0.042f * s
        val lrY = controlsTop + padH * 0.06f + lrH / 2f
        addButton("l", sw*0.03f+lrW/2f,      lrY, lrW, lrH, EmulatorEngine.KEY_L, "L", Color.parseColor("#444455"))
        addButton("r", sw-sw*0.03f-lrW/2f,   lrY, lrW, lrH, EmulatorEngine.KEY_R, "R", Color.parseColor("#444455"))

        // ── ⏩ Fast-forward (utility strip above SEL/STA) ──────────────────
        // Not pushed into `buttons` (it isn't a GBA key — see onGameTouch),
        // but still routed through resolvedRect() so it's just as draggable
        // and resizable in the editor as every other button.
        val utilH = (ssH * 0.85f).coerceAtLeast(18f)
        val utilW = sw * 0.10f
        val utilY = ssCy - ssH/2f - utilH - sh * 0.012f + utilH / 2f
        val utilGap = sw * 0.055f
        ffBtnRect = resolvedRect("ff", sw/2f - utilGap - utilW/2f, utilY, utilW, utilH)
        // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only

        // Publish the whole list in one atomic reference write — see the
        // `buttons` field comment for why this matters.
        buttons = buildingButtons

        if (editModeActive) refreshEditToolbarPosition()
    }

    // ── Draw controls ──────────────────────────────────────────────────────

    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return

        if (!fullscreenMode) {
            fillPaint.color = Color.parseColor("#CC111122")
            canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)
        }

        val keys       = currentKeys.get()
        // Idle alpha scales with user preference; press brightens by +80.
        // Per-button opacity overrides from the editor take priority — see
        // the loop below.
        val idleAlpha  = if (fullscreenMode) (buttonBaseAlpha * 0.70f).toInt() else buttonBaseAlpha

        for (btn in buttons) {
            val ov = customLayout[btn.id]?.alphaOverride ?: -1
            val btnIdle = if (ov >= 0) ov else idleAlpha
            if (btn.isDpad) {
                drawDpad(canvas, btn.rect, keys, btnIdle)
                continue
            }
            fillPaint.color = btn.color
            fillPaint.alpha = if (keys and btn.keyMask != 0) (btnIdle + 80).coerceAtMost(255) else btnIdle
            canvas.drawRoundRect(btn.rect, 12f, 12f, fillPaint)
            labelPaint.textSize = (btn.rect.height() * 0.46f).coerceAtLeast(14f)
            canvas.drawText(
                btn.label,
                btn.rect.centerX(),
                btn.rect.centerY() + labelPaint.textSize * 0.36f,
                labelPaint
            )
        }

        // ── ⏩ Fast-forward button ────────────────────────────────────────
        fillPaint.color = if (fastForwardActive) Color.parseColor("#CC7700")
                          else Color.parseColor("#333344")
        fillPaint.alpha = idleAlpha + 20
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        val ffLabel = if (fastForwardActive) "⏩${formatSpeed(fastForwardSpeed)}×" else "⏩"
        canvas.drawText(ffLabel,
            ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
    }

    /** Renders the unified d-pad: a rounded base plate plus four directional
     *  "arms" that individually brighten when their key bit is held —
     *  including two bits at once for a diagonal, which now actually
     *  happens (see dpadKeysFor). */
    private fun drawDpad(canvas: Canvas, rect: RectF, keys: Int, idleAlpha: Int) {
        val cx = rect.centerX(); val cy = rect.centerY()
        val r  = minOf(rect.width(), rect.height()) / 2f

        fillPaint.color = Color.parseColor("#33222233")
        fillPaint.alpha = (idleAlpha * 0.6f).toInt().coerceIn(0, 255)
        canvas.drawRoundRect(rect, r * 0.3f, r * 0.3f, fillPaint)

        val armLen = r * 0.62f
        val armW   = r * 0.56f
        fun arm(dx: Float, dy: Float, pressed: Boolean, label: String) {
            val ax = cx + dx * armLen; val ay = cy + dy * armLen
            val armRect = RectF(ax - armW / 2f, ay - armW / 2f, ax + armW / 2f, ay + armW / 2f)
            fillPaint.color = Color.parseColor("#555566")
            fillPaint.alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
            canvas.drawRoundRect(armRect, 10f, 10f, fillPaint)
            labelPaint.textSize = (armW * 0.5f).coerceAtLeast(12f)
            canvas.drawText(label, ax, ay + labelPaint.textSize * 0.36f, labelPaint)
        }
        arm(0f, -1f, keys and EmulatorEngine.KEY_UP    != 0, "▲")
        arm(0f,  1f, keys and EmulatorEngine.KEY_DOWN  != 0, "▼")
        arm(-1f, 0f, keys and EmulatorEngine.KEY_LEFT  != 0, "◀")
        arm(1f,  0f, keys and EmulatorEngine.KEY_RIGHT != 0, "▶")
    }

    /** Maps a touch point inside the unified d-pad rect to a GBA key-bit
     *  combination by angle from center, split into 8 x 45° sectors — the
     *  4 cardinal sectors give a single direction, the 4 sectors between
     *  them give the two adjacent bits (a genuine diagonal). A small
     *  circular dead-zone at the very center avoids accidental input from
     *  a light tap that lands near the middle. */
    private fun dpadKeysFor(rect: RectF, x: Float, y: Float): Int {
        val cx = rect.centerX(); val cy = rect.centerY()
        val halfW = (rect.width() / 2f).coerceAtLeast(1f)
        val halfH = (rect.height() / 2f).coerceAtLeast(1f)
        val dx = x - cx; val dy = y - cy
        val distNorm = maxOf(abs(dx) / halfW, abs(dy) / halfH)
        if (distNorm < 0.16f) return 0   // dead zone — no accidental direction from a center tap

        var deg = Math.toDegrees(kotlin.math.atan2(-dy.toDouble(), dx.toDouble()))
        if (deg < 0) deg += 360.0
        val U = EmulatorEngine.KEY_UP; val D = EmulatorEngine.KEY_DOWN
        val L = EmulatorEngine.KEY_LEFT; val R = EmulatorEngine.KEY_RIGHT
        return when {
            deg >= 337.5 || deg < 22.5  -> R
            deg < 67.5                  -> U or R
            deg < 112.5                 -> U
            deg < 157.5                 -> U or L
            deg < 202.5                 -> L
            deg < 247.5                 -> D or L
            deg < 292.5                 -> D
            else                         -> D or R
        }
    }

    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00"); textSize = 28f; isFakeBoldText = true
    }
    private fun drawFfOverlay(canvas: Canvas) =
        canvas.drawText("⏩ ${formatSpeed(fastForwardSpeed)}×", 14f, 36f, hudPaint)

    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    // ── Touch handling ─────────────────────────────────────────────────────

    private fun onGameTouch(event: MotionEvent) {
        if (editModeActive) { onEditTouch(event); return }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                // ⏩ — tap toggles fast-forward
                if (ffBtnRect.contains(x, y)) { fastForwardActive = !fastForwardActive; return }
                // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
                updateGameKeys(event)
            }
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)
            MotionEvent.ACTION_UP -> {
                if (ffBtnRect.contains(event.x, event.y)) return
                currentKeys.set(0)
                lastSoundKeys = 0
            }
            MotionEvent.ACTION_POINTER_UP -> updateGameKeys(event)
            else                          -> { currentKeys.set(0); lastSoundKeys = 0 }
        }
    }

    private fun updateGameKeys(event: MotionEvent) {
        var keys = 0
        for (i in 0 until event.pointerCount) {
            val x = event.getX(i); val y = event.getY(i)
            for (btn in buttons) {
                if (!btn.rect.contains(x, y)) continue
                keys = keys or (if (btn.isDpad) dpadKeysFor(btn.rect, x, y) else btn.keyMask)
            }
        }
        currentKeys.set(keys)

        // Click sound: only on the RISING EDGE (bits newly set that weren't
        // set last call). This function runs on every ACTION_MOVE while a
        // finger drags across the d-pad, not just on initial touch-down —
        // gating on the edge instead of "any key held" keeps this to one
        // fire-and-forget system call per actual button press, so it can
        // never flood the audio pipeline or block the UI thread.
        if (buttonSoundEnabled) {
            val newlyPressed = keys and lastSoundKeys.inv()
            if (newlyPressed != 0) audioManager?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
        lastSoundKeys = keys
    }

    // ── Control layout editor ────────────────────────────────────────────────
    //
    // FEATURE #2 — a My Boy!-style layout editor. Scope for this pass: every
    // button (D-pad × 4, A, B, Start, Select, L, R, Fast-Forward) can be
    // freely dragged anywhere on screen and resized via a corner handle, with
    // a per-button opacity override and a per-button lock, all live-previewed
    // over the actual running game and persisted across sessions. Deliberately
    // NOT built in this pass (flagged rather than silently skipped):
    // per-button rotation/mirroring (unusual for a D-pad/AB layout — mostly
    // relevant for decorative custom skins, low value here), snap-to-guides /
    // alignment grid, and named/duplicatable layout profiles beyond the
    // automatic portrait/landscape split already wired into the storage
    // format. Per-game layouts are a storage-key change away (see
    // orientationTag()/PREF_LAYOUT_PREFIX) but need a ROM-identity concept
    // (hash or path) this codebase doesn't have yet, so it's out of scope
    // until that exists rather than faked with a no-op toggle.

    private fun labelFor(id: String): String = when (id) {
        "dpad" -> "D-Pad"
        "a" -> "A Button"; "b" -> "B Button"; "start" -> "Start"; "select" -> "Select"
        "l" -> "L Shoulder"; "r" -> "R Shoulder"; "ff" -> "Fast-Forward"
        else -> id
    }

    private fun editRectFor(id: String): RectF? =
        if (id == "ff") ffBtnRect else buttons.find { it.id == id }?.rect

    private fun resizeHandleRadius(rect: RectF): Float =
        (minOf(rect.width(), rect.height()) * 0.22f).coerceIn(22f, 36f)

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    /** Gets-or-creates the override entry for [id], seeded from its current
     *  default geometry so a freshly-touched button starts exactly where it
     *  visually already is, not at some arbitrary origin. */
    private fun entryFor(id: String): LayoutEntry = customLayout.getOrPut(id) {
        val g = defaultGeometry[id]
        LayoutEntry(
            xFrac = (g?.cx ?: lastSw / 2f) / lastSw.coerceAtLeast(1f),
            yFrac = (g?.cy ?: lastSh / 2f) / lastSh.coerceAtLeast(1f)
        )
    }

    private fun hitTestEditable(x: Float, y: Float): String? {
        if (ffBtnRect.contains(x, y)) return "ff"
        for (b in buttons) if (b.rect.contains(x, y)) return b.id
        return null
    }

    private fun enterEditMode() {
        if (!romLoaded) {
            uiToast("Load a ROM first — the editor previews live over the running game")
            return
        }
        editModeActive = true
        editSelectedId = null
        currentKeys.set(0)   // don't leave a key "stuck" held from the touch that opened the editor
        editTopBar.visibility = View.VISIBLE
        editButtonBar.visibility = View.GONE
        uiToast("Drag a button to move it • drag its corner dot to resize")
    }

    private fun exitEditMode(save: Boolean) {
        editModeActive = false
        editSelectedId = null
        editDragPointerId = -1
        editResizing = false
        editTopBar.visibility = View.GONE
        editButtonBar.visibility = View.GONE
        if (save) { saveCustomLayout(); uiToast("Layout saved") }
        else { loadCustomLayout(); uiToast("Changes discarded") }
        buildControlLayout(lastSw, lastSh)
    }

    private fun confirmResetAllLayout() {
        AlertDialog.Builder(this)
            .setTitle("Reset layout?")
            .setMessage("This clears every custom position/size for this orientation. You can still Cancel afterward to undo.")
            .setPositiveButton("Reset") { _, _ ->
                customLayout.clear()
                editDirty = true
                editSelectedId = null
                editButtonBar.visibility = View.GONE
                buildControlLayout(lastSw, lastSh)
                uiToast("Reset — tap ✓ Done to save, or ✕ Cancel to undo")
            }
            .setNegativeButton("Keep", null)
            .show()
    }

    private fun resetSingleButton(id: String) {
        customLayout.remove(id)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedScale(delta: Float) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        e.scale = (e.scale + delta).coerceIn(0.5f, 2.5f)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedAlpha(delta: Int) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        val base = if (e.alphaOverride < 0) buttonBaseAlpha else e.alphaOverride
        e.alphaOverride = (base + delta).coerceIn(60, 255)
        editDirty = true
    }

    private fun toggleSelectedLock() {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        e.locked = !e.locked
        editDirty = true
        updateEditButtonBarLockIcon()
    }

    private fun updateEditButtonBarLockIcon() {
        val id = editSelectedId ?: return
        editLockBtn.text = if (customLayout[id]?.locked == true) "🔒" else "🔓"
    }

    /** Repositions the per-button toolbar just above (or below, if that
     *  would collide with the top bar) the currently selected control. */
    private fun refreshEditToolbarPosition() {
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        editButtonBar.post {
            val w = editButtonBar.width.takeIf { it > 0 } ?: 480
            val h = editButtonBar.height.takeIf { it > 0 } ?: 110
            var ty = rect.top - h - 12f
            if (ty < editTopBar.height + 12f) ty = rect.bottom + 12f
            val tx = (rect.centerX() - w / 2f).coerceIn(4f, (lastSw - w - 4f).coerceAtLeast(4f))
            ty = ty.coerceIn(4f, (lastSh - h - 4f).coerceAtLeast(4f))
            editButtonBar.x = tx
            editButtonBar.y = ty
        }
    }

    private fun onEditTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                val hitId = hitTestEditable(x, y)
                if (hitId == null) {
                    editSelectedId = null
                    editButtonBar.visibility = View.GONE
                    return
                }
                editSelectedId = hitId
                editDragPointerId = event.getPointerId(0)
                val rect = editRectFor(hitId) ?: return
                val handleR = resizeHandleRadius(rect)
                editResizing = dist(x, y, rect.right, rect.bottom) <= handleR * 1.6f
                if (editResizing) {
                    editResizeStartDist = dist(x, y, rect.centerX(), rect.centerY()).coerceAtLeast(1f)
                    editResizeStartScale = customLayout[hitId]?.scale ?: 1f
                } else {
                    editDragOffX = x - rect.centerX()
                    editDragOffY = y - rect.centerY()
                }
                editButtonLabel.text = labelFor(hitId)
                updateEditButtonBarLockIcon()
                editButtonBar.visibility = View.VISIBLE
                refreshEditToolbarPosition()
            }
            MotionEvent.ACTION_MOVE -> {
                val id = editSelectedId ?: return
                val ptr = event.findPointerIndex(editDragPointerId)
                if (ptr < 0) return
                val e = entryFor(id)
                if (e.locked) return
                val x = event.getX(ptr); val y = event.getY(ptr)
                if (editResizing) {
                    val c = editRectFor(id)
                    val d = dist(x, y, c?.centerX() ?: x, c?.centerY() ?: y)
                    e.scale = (editResizeStartScale * (d / editResizeStartDist)).coerceIn(0.5f, 2.5f)
                } else {
                    val cx = (x - editDragOffX).coerceIn(lastSw * 0.03f, lastSw * 0.97f)
                    val cy = (y - editDragOffY).coerceIn(lastSh * 0.03f, lastSh * 0.97f)
                    e.xFrac = cx / lastSw.coerceAtLeast(1f)
                    e.yFrac = cy / lastSh.coerceAtLeast(1f)
                }
                editDirty = true
                buildControlLayout(lastSw, lastSh)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == editDragPointerId) {
                    editDragPointerId = -1
                    editResizing = false
                }
            }
        }
    }

    private val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFEE58")
    }
    private val editHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FFEE58")
    }
    private val editDimPaint = Paint().apply { color = Color.parseColor("#22000000") }

    private fun drawEditOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), editDimPaint)
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        canvas.drawRoundRect(rect, 12f, 12f, editHighlightPaint)
        canvas.drawCircle(rect.right, rect.bottom, resizeHandleRadius(rect), editHandlePaint)
    }

    // ── Settings dialog ────────────────────────────────────────────────────

    /**
     * ⚙ Settings — comprehensive options panel.
     *
     * Sections:
     *   GAME SCREEN — fraction of screen height the game occupies + fullscreen toggle
     *   CONTROLS    — button size multiplier and opacity
     *   EMULATION   — fast-forward speed
     *
     * Fullscreen mode is intentionally ONLY accessible here (no on-screen button)
     * to keep the game screen clean.
     */
    private fun showSettingsDialog() {
        val ctx  = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        // ── Root layout (ScrollView → LinearLayout) ──────────────────────
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        fun sectionLabel(text: String) = TextView(ctx).apply {
            this.text = text; textSize = 10f
            setTextColor(Color.parseColor("#AAAAAA"))
            setPadding(0, 24, 0, 6)
        }
        fun makeRadioGroup(horizontal: Boolean = true) = RadioGroup(ctx).apply {
            if (horizontal) orientation = LinearLayout.HORIZONTAL
        }
        fun RadioGroup.addOpt(label: String): RadioButton = RadioButton(ctx).apply {
            text = label
            id   = View.generateViewId()
            setTextColor(Color.WHITE)
            textSize = 13f
        }.also { addView(it) }

        // ── GAME SCREEN ──────────────────────────────────────────────────
        layout.addView(sectionLabel("── GAME SCREEN ──"))

        val screenOptions = listOf(
            "35%"        to 0.35f,
            "44%"        to 0.44f,
            "52% (def)"  to 0.52f,
            "65%"        to 0.65f
        )
        val screenRadio = makeRadioGroup()
        screenOptions.forEach { (label, _) -> screenRadio.addOpt(label) }
        val curScreenIdx = screenOptions.indexOfFirst { abs(it.second - gameScreenFraction) < 0.02f }
            .takeIf { it >= 0 } ?: 2
        (screenRadio.getChildAt(curScreenIdx) as RadioButton).isChecked = true
        layout.addView(screenRadio)

        // Fullscreen toggle — now ONLY here, not on the game screen
        val fsCheck = CheckBox(ctx).apply {
            text    = "Fullscreen — game covers control area"
            isChecked = fullscreenMode
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, 8, 0, 0)
        }
        layout.addView(fsCheck)
        layout.addView(TextView(ctx).apply {
            text = "  (controls become a transparent overlay)"
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
        })

        // ── CONTROLS ─────────────────────────────────────────────────────
        layout.addView(sectionLabel("── CONTROLS ──"))

        layout.addView(TextView(ctx).apply {
            text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
        val sizeRadio   = makeRadioGroup()
        sizeOptions.forEach { (label, _) -> sizeRadio.addOpt(label) }
        val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
            .takeIf { it >= 0 } ?: 1
        (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
        layout.addView(sizeRadio)

        layout.addView(TextView(ctx).apply {
            text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 0)
        })
        val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
        val alphaRadio   = makeRadioGroup()
        alphaOptions.forEach { (label, _) -> alphaRadio.addOpt(label) }
        val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
            .takeIf { it >= 0 } ?: 1
        (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
        layout.addView(alphaRadio)

        // Button click sound — system FX_KEYPRESS_STANDARD effect, fired
        // only on the rising edge of a press (see updateGameKeys()).
        val soundCheck = CheckBox(ctx).apply {
            text      = "🔊 Button click sound"
            isChecked = buttonSoundEnabled
            setTextColor(Color.WHITE)
            textSize  = 13f
            setPadding(0, 10, 0, 0)
        }
        layout.addView(soundCheck)

        // FEATURE #2: My Boy!-style per-button layout editor entry point.
        // Dismisses this dialog and opens the live drag/resize editor over
        // the running game (see enterEditMode()).
        val editLayoutBtn = Button(ctx).apply {
            text = "🖊  Edit Button Layout…"
            setPadding(0, 12, 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(editLayoutBtn)

        // ── EMULATION ────────────────────────────────────────────────────
        layout.addView(sectionLabel("── EMULATION ──"))
        layout.addView(TextView(ctx).apply {
            text = "Fast-forward speed (0.5 – 16×)\nTap ⏩ on screen to activate"
            textSize = 12f; setTextColor(Color.WHITE)
        })
        val ffEdit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 2, 4, 4.5"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(8, 8, 8, 8)
        }
        layout.addView(ffEdit)

        // ── Hint about fullscreen ─────────────────────────────────────────
        layout.addView(TextView(ctx).apply {
            text = "\nTip: tap ⚙ during gameplay to toggle fullscreen or adjust size."
            textSize = 10f; setTextColor(Color.parseColor("#666688"))
        })

        // ── Dialog ───────────────────────────────────────────────────────
        AlertDialog.Builder(ctx)
            .setTitle("⚙ Settings")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->

                // Read screen fraction
                val selScreenIdx = (0 until screenRadio.childCount)
                    .firstOrNull { (screenRadio.getChildAt(it) as RadioButton).isChecked } ?: curScreenIdx
                val newFrac = screenOptions[selScreenIdx].second

                // Read button size
                val selSizeIdx = (0 until sizeRadio.childCount)
                    .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
                val newScale = sizeOptions[selSizeIdx].second

                // Read button alpha
                val selAlphaIdx = (0 until alphaRadio.childCount)
                    .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
                val newAlpha = alphaOptions[selAlphaIdx].second

                // Read FF speed
                val ffVal = ffEdit.text.toString().toFloatOrNull()
                if (ffVal != null) {
                    when {
                        ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                        else -> fastForwardSpeed = ffVal
                    }
                }

                // Apply and persist
                val needsRelayout = abs(newFrac - gameScreenFraction) > 0.01f
                    || newScale != buttonScaleMultiplier
                    || fsCheck.isChecked != fullscreenMode

                buttonScaleMultiplier = newScale
                buttonBaseAlpha       = newAlpha
                gameScreenFraction    = newFrac
                fullscreenMode        = fsCheck.isChecked
                buttonSoundEnabled    = soundCheck.isChecked

                prefs.edit()
                    .putFloat(PREF_FF_SPEED,    fastForwardSpeed)
                    .putFloat(PREF_BTN_SCALE,   newScale)
                    .putInt(PREF_BTN_ALPHA,      newAlpha)
                    .putFloat(PREF_SCREEN_FRAC,  newFrac)
                    .putBoolean(PREF_FULLSCREEN,  fullscreenMode)
                    .putBoolean(PREF_BTN_SOUND,   buttonSoundEnabled)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
            .also { dlg -> editLayoutBtn.setOnClickListener { dlg.dismiss(); enterEditMode() } }
    }

    /**
     * Rebuild control layout and game matrix after settings change.
     * Called on main thread; game thread picks up changes on next frame.
     */
    private fun applyLayoutSettings() {
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) {
            buildControlLayout(sw, sh)
            if (romLoaded) updateGameMatrix(sw, sh)
        }
    }

    // ── Link cable UI ──────────────────────────────────────────────────────

    private fun showLinkDialog() {
        if (link.isConnected) {
            AlertDialog.Builder(this).setTitle("Link Connected ✓")
                .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("GBA Link Cable")
            .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi",
                               "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady     = { ip -> uiToast("Waiting…\nIP: $ip"); updateLinkBtn("⏳ Hosting…") },
                        onConnected = { onLinkConnected(true,  "Wi-Fi") },
                        onError     = { uiToast("Host error: $it"); updateLinkBtn("🔗 Link") })
                    1 -> { updateLinkBtn("🔗 Scanning…")
                           link.discoverWifiHosts(
                               onFound = { hosts ->
                                   if (hosts.isEmpty()) showIpDialog()
                                   else AlertDialog.Builder(this)
                                       .setTitle("Select host")
                                       .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                       .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show() },
                               onError = { showIpDialog() }) }
                    // FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+.
                    // It was declared in the manifest but never requested, so tapping either
                    // of these two options crashed the app on Android 12+ with an uncaught
                    // SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
                    // createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
                    2 -> ensureBluetoothPermission {
                           updateLinkBtn("⏳ BT Host…")
                           link.startBluetoothHost(
                               onConnected = { onLinkConnected(true,  "Bluetooth") },
                               onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") }) }
                    3 -> ensureBluetoothPermission {
                           val devs = link.getBondedDevices()
                           if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
                           AlertDialog.Builder(this).setTitle("Choose device")
                               .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                   updateLinkBtn("⏳ BT…")
                                   link.connectBluetooth(devs[j],
                                       onConnected = { onLinkConnected(false, "Bluetooth") },
                                       onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") })
                               }.show() }
                }
            }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        updateLinkBtn("⏳ Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it"); updateLinkBtn("🔗 Link") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        updateLinkBtn("🔗 $via ✓")
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        updateLinkBtn("🔗 Link"); uiToast("Disconnected")
    }

    private fun updateLinkBtn(t: String) =
        Handler(Looper.getMainLooper()).post { linkBtn.text = t }

    // ── Link status overlay ────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Helpers ────────────────────────────────────────────────────────────

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
