package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.util.Noise;
import com.kartracer.world.Props;

/**
 * Scenery meshes. Vertex alpha: 0..127 = wind sway weight, 128..255 = emissive (+ sway weight - 128).
 * LOD 0 is the detailed mesh, LOD 1 the cheap far version.
 */
public final class PropModels {
    private PropModels() {}

    private static int c(int hex, int a) { return Col.withAlpha(Col.hex(hex), a); }

    public static MeshData build(int type, int lod) { return build(type, lod, 0); }

    /** theme tints the rocks: 0 beach, 1 jungle, 2 volcano, 3 desert. */
    public static MeshData build(int type, int lod, int theme) {
        MeshBuilder b = new MeshBuilder();
        switch (type) {
            case Props.PALM: palm(b, lod); break;
            case Props.BUSH: bush(b, lod); break;
            case Props.ROCK: {
                int[][] cols = {{0x8C877F, 0x5E5A55}, {0x7C8574, 0x4A5342}, {0x4C4852, 0x26232B}, {0xB88458, 0x7A4E34}};
                int[] c = cols[Math.max(0, Math.min(3, theme))];
                rock(b, lod, 11 + theme, 1.0f, c[0], c[1]);
                break;
            }
            case Props.JTREE: jungleTree(b, lod); break;
            case Props.FERN: fern(b, lod); break;
            case Props.MUSHROOM: mushroom(b, lod); break;
            case Props.CACTUS: cactus(b, lod); break;
            case Props.DEADTREE: deadTree(b, lod); break;
            case Props.SPIRE: spire(b, lod); break;
            case Props.MESA: mesa(b, lod); break;
            case Props.UMBRELLA: umbrella(b, lod); break;
            case Props.TORCH: torch(b, lod); break;
            case Props.LIGHTHOUSE: lighthouse(b); break;
            case Props.SIGN_L: sign(b, false); break;
            case Props.SIGN_R: sign(b, true); break;
            case Props.TUFT: tuft(b, lod); break;
            default: totem(b, lod); break;
        }
        return b.build();
    }

    // ---------------------------------------------------------------- vegetation

    private static void palm(MeshBuilder b, int lod) {
        int segs = lod == 0 ? 7 : 3;
        float h = 6.6f;
        float[] tx = new float[segs + 1], ty = new float[segs + 1];
        for (int i = 0; i <= segs; i++) { float t = i / (float) segs; ty[i] = t * h; tx[i] = 0.9f * t * t; }
        for (int i = 0; i < segs; i++) {
            float t0 = i / (float) segs, t1 = (i + 1) / (float) segs;
            int shade = (i & 1) == 0 ? 0x8A6A44 : 0x76593A;
            b.tube(tx[i], ty[i], 0, tx[i + 1], ty[i + 1], 0, 0.30f - 0.13f * t0, 0.30f - 0.13f * t1, lod == 0 ? 7 : 5,
                    c(shade, (int) (t0 * 90)), c(shade, (int) (t1 * 90)), false);
        }
        float cx = tx[segs];
        int fronds = lod == 0 ? 9 : 6, pts = lod == 0 ? 6 : 4;
        for (int k = 0; k < fronds; k++) {
            float a = k * MathX.TAU / fronds + 0.3f;
            float[] px = new float[pts], py = new float[pts], pz = new float[pts], hw = new float[pts];
            for (int j = 0; j < pts; j++) {
                float s = j / (float) (pts - 1);
                float d = s * 3.3f;
                px[j] = cx + (float) Math.cos(a) * d;
                pz[j] = (float) Math.sin(a) * d;
                py[j] = h + 0.25f + 0.9f * s - 2.0f * s * s;
                hw[j] = 0.42f * (float) Math.sin(MathX.PI * (0.12f + 0.88f * s)) + 0.03f;
            }
            b.ribbon(px, py, pz, hw, -(float) Math.sin(a), 0f, (float) Math.cos(a), c(0x2E7A32, 150), c(0x7DC24B, 200));
        }
        if (lod == 0) for (int k = 0; k < 3; k++) {
            float a = k * 2.1f;
            b.sphere(cx + (float) Math.cos(a) * 0.28f, h - 0.15f, (float) Math.sin(a) * 0.28f, 0.17f, 6, 4, c(0x5B3A1E, 120));
        }
    }

    private static void bush(MeshBuilder b, int lod) {
        int dark = c(0x2F6E32, 0), light = c(0x6FB04A, 110);
        if (lod == 1) { b.sphere(0, 0.55f, 0, 0.95f, 0.65f, 0.95f, 6, 4, dark, light); return; }
        b.sphere(0, 0.55f, 0, 0.95f, 0.65f, 0.95f, 9, 6, dark, light);
        b.sphere(0.65f, 0.40f, 0.30f, 0.62f, 0.45f, 0.62f, 8, 5, dark, light);
        b.sphere(-0.55f, 0.38f, -0.35f, 0.58f, 0.42f, 0.58f, 8, 5, c(0x346F36, 0), c(0x78B84F, 110));
    }

    /** Low poly jagged rock, flat shaded. */
    public static void rock(MeshBuilder b, int lod, int seed, float r, int hiHex, int loHex) {
        int segs = lod == 0 ? 8 : 5, rings = lod == 0 ? 5 : 3;
        float[][][] p = new float[rings + 1][segs + 1][3];
        for (int k = 0; k <= rings; k++) {
            float ph = -MathX.PI / 2f + MathX.PI * k / rings;
            for (int i = 0; i <= segs; i++) {
                int ii = i % segs;
                float th = MathX.TAU * ii / segs;
                float jit = (k == 0 || k == rings) ? 1f : 0.72f + 0.55f * Noise.hash(ii, k, seed);
                float x = (float) (Math.cos(ph) * Math.cos(th)) * 1.1f * jit * r;
                float y = (float) Math.sin(ph) * 0.78f * jit * r + 0.42f * r;
                float z = (float) (Math.cos(ph) * Math.sin(th)) * 1.0f * jit * r;
                p[k][i][0] = x; p[k][i][1] = Math.max(y, -0.08f); p[k][i][2] = z;
            }
        }
        int hi = Col.hex(hiHex), lo = Col.hex(loHex);
        for (int k = 0; k < rings; k++) for (int i = 0; i < segs; i++) {
            float[] a = p[k][i], bb = p[k][i + 1], cc = p[k + 1][i], d = p[k + 1][i + 1];
            tri(b, a, cc, bb, hi, lo);
            tri(b, bb, cc, d, hi, lo);
        }
    }

    private static void tri(MeshBuilder b, float[] a, float[] bb, float[] c, int hi, int lo) {
        float ux = bb[0] - a[0], uy = bb[1] - a[1], uz = bb[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        float ny = uz * vx - ux * vz;
        float l = (float) Math.sqrt((uy * vz - uz * vy) * (uy * vz - uz * vy) + ny * ny + (ux * vy - uy * vx) * (ux * vy - uy * vx));
        float t = l < 1e-9f ? 0.5f : MathX.sat(ny / l * 0.5f + 0.5f);
        b.flatTri(a[0], a[1], a[2], bb[0], bb[1], bb[2], c[0], c[1], c[2], Col.mix(lo, hi, t));
    }

    private static void jungleTree(MeshBuilder b, int lod) {
        float h = 9.5f;
        int bark = 0x6B4A2E;
        if (lod == 0) {
            b.tube(0, 0, 0, 0.15f, h * 0.5f, 0.1f, 0.80f, 0.55f, 8, c(bark, 0), c(bark, 20), false);
            b.tube(0.15f, h * 0.5f, 0.1f, 0f, h, 0f, 0.55f, 0.40f, 8, c(bark, 20), c(bark, 50), false);
            for (int k = 0; k < 4; k++) {
                float a = k * MathX.TAU / 4f + 0.5f;
                b.tube((float) Math.cos(a) * 1.7f, 0f, (float) Math.sin(a) * 1.7f, (float) Math.cos(a) * 0.4f, 2.4f, (float) Math.sin(a) * 0.4f, 0.14f, 0.32f, 5, c(bark, 0), c(bark, 0), false);
            }
        } else b.tube(0, 0, 0, 0, h, 0, 0.78f, 0.42f, 5, c(bark, 0), c(bark, 50), false);
        int dark = c(0x1F5E34, 40), mid = c(0x2F8040, 110), light = c(0x6CB84A, 160);
        float[][] blobs = {{0, h + 1.2f, 0, 3.4f, 2.4f}, {2.4f, h - 0.3f, 1.2f, 2.5f, 1.9f}, {-2.3f, h - 0.1f, -1.0f, 2.6f, 2.0f},
                {0.6f, h + 2.8f, -0.8f, 2.4f, 1.8f}, {-0.8f, h - 0.8f, 2.4f, 2.2f, 1.7f}};
        int nb = lod == 0 ? blobs.length : 2;
        for (int i = 0; i < nb; i++) {
            float[] o = blobs[i];
            b.sphere(o[0], o[1], o[2], o[3], o[4], o[3], lod == 0 ? 9 : 6, lod == 0 ? 6 : 4, i % 2 == 0 ? dark : mid, light);
        }
        if (lod == 0) for (int k = 0; k < 5; k++) {
            float a = k * 1.3f;
            float x = (float) Math.cos(a) * 2.6f, z = (float) Math.sin(a) * 2.2f;
            b.tube(x, h - 0.6f, z, x + 0.1f, h - 4.5f, z, 0.05f, 0.03f, 4, c(0x3F7A3A, 100), c(0x4F8A3A, 127), false);
        }
    }

    private static void fern(MeshBuilder b, int lod) {
        int leaves = lod == 0 ? 7 : 4, pts = lod == 0 ? 5 : 3;
        for (int k = 0; k < leaves; k++) {
            float a = k * MathX.TAU / leaves + 0.4f;
            float[] px = new float[pts], py = new float[pts], pz = new float[pts], hw = new float[pts];
            for (int j = 0; j < pts; j++) {
                float s = j / (float) (pts - 1);
                px[j] = (float) Math.cos(a) * 1.8f * s; pz[j] = (float) Math.sin(a) * 1.8f * s;
                py[j] = 0.1f + 0.9f * s - 0.9f * s * s;
                hw[j] = 0.2f * (float) Math.sin(MathX.PI * (0.1f + 0.9f * s)) + 0.02f;
            }
            b.ribbon(px, py, pz, hw, -(float) Math.sin(a), 0f, (float) Math.cos(a), c(0x2F8A3A, 40), c(0x7CCB52, 127));
        }
    }

    private static void mushroom(MeshBuilder b, int lod) {
        b.cyl(0, 0, 0, 0.20f, 0.14f, 0.85f, 7, c(0xD9CDB0, 0), c(0xF2E9D0, 0), false, false);
        b.sphere(0, 0.88f, 0, 0.80f, 0.42f, 0.80f, lod == 0 ? 10 : 6, lod == 0 ? 6 : 4, c(0x9E2020, 0), c(0xE53A30, 0));
        if (lod == 0) for (int k = 0; k < 6; k++) {
            float a = k * 1.05f, rr = 0.42f + (k % 2) * 0.2f;
            b.sphere((float) Math.cos(a) * rr, 1.12f - rr * 0.35f, (float) Math.sin(a) * rr, 0.13f, 0.06f, 0.13f, 6, 3, c(0xFFFFFF, 0), c(0xFFFFFF, 0));
        }
    }

    private static void cactus(MeshBuilder b, int lod) {
        int g0 = c(0x3F8A4A, 0), g1 = c(0x5FB063, 30);
        b.cyl(0, 0, 0, 0.42f, 0.36f, 3.5f, 8, g0, g1, false, false);
        b.sphere(0, 3.5f, 0, 0.36f, 0.4f, 0.36f, 8, 4, g1, g1);
        b.tube(-0.3f, 1.5f, 0, -1.0f, 1.65f, 0, 0.22f, 0.22f, 7, g0, g0, false);
        b.tube(-1.0f, 1.65f, 0, -1.05f, 2.9f, 0, 0.22f, 0.2f, 7, g0, g1, false);
        b.sphere(-1.05f, 2.9f, 0, 0.2f, 0.22f, 0.2f, 6, 4, g1, g1);
        if (lod == 0) {
            b.tube(0.3f, 2.1f, 0, 0.85f, 2.2f, 0.1f, 0.2f, 0.2f, 7, g0, g0, false);
            b.tube(0.85f, 2.2f, 0.1f, 0.9f, 3.1f, 0.1f, 0.2f, 0.18f, 7, g0, g1, false);
            b.sphere(0.9f, 3.1f, 0.1f, 0.18f, 0.2f, 0.18f, 6, 4, g1, g1);
            b.sphere(0.1f, 3.9f, 0, 0.12f, 6, 4, c(0xF06292, 40));
        }
    }

    private static void deadTree(MeshBuilder b, int lod) {
        int bark = 0x7A6A5A;
        b.tube(0, 0, 0, 0.3f, 4.2f, 0, 0.35f, 0.12f, 6, c(bark, 0), c(bark, 40), false);
        b.tube(0.1f, 2.5f, 0, 1.5f, 4.0f, 0.5f, 0.12f, 0.04f, 5, c(bark, 10), c(bark, 60), false);
        b.tube(-0.1f, 3.0f, 0, -1.3f, 4.3f, -0.4f, 0.11f, 0.04f, 5, c(bark, 10), c(bark, 60), false);
        if (lod == 0) {
            b.tube(0.2f, 3.6f, 0, 0.9f, 5.2f, 0.8f, 0.09f, 0.03f, 5, c(bark, 10), c(bark, 60), false);
            b.tube(0.1f, 1.8f, 0, -0.9f, 2.9f, 0.9f, 0.1f, 0.03f, 5, c(bark, 10), c(bark, 60), false);
        }
    }

    // ---------------------------------------------------------------- rock formations

    private static void spire(MeshBuilder b, int lod) {
        int lo = c(0x2A2830, 0), mid = c(0x4A4652, 0), hi = c(0x6A6474, 0);
        if (lod == 1) { b.cyl(0, 0, 0, 2.0f, 0f, 7.5f, 6, lo, hi, false, false); return; }
        b.cyl(0, -0.3f, 0, 2.1f, 1.5f, 3.3f, 6, lo, mid, false, false);
        b.push().translate(0.25f, 2.9f, 0.1f).rotZ(0.06f).cyl(0, 0, 0, 1.5f, 0.95f, 3.0f, 6, mid, mid, false, false).pop();
        b.push().translate(0.5f, 5.7f, 0.2f).rotZ(0.1f).cyl(0, 0, 0, 0.95f, 0f, 3.6f, 6, mid, hi, false, false).pop();
        b.push().translate(-1.3f, 0f, 0.9f).cyl(0, 0, 0, 0.8f, 0f, 3.2f, 5, lo, mid, false, false).pop();
    }

    private static void mesa(MeshBuilder b, int lod) {
        int[] cols = {0xB8643C, 0xD2825A, 0xAA5232, 0xC87846, 0xE1AA6E};
        float[][] layers = {{0, 3.0f, 10f, 9f}, {3.0f, 2.5f, 9f, 9.5f}, {5.5f, 2.5f, 9.5f, 8.2f}, {8.0f, 3.0f, 8.2f, 8.0f}, {11.0f, 0.6f, 8.0f, 7.2f}};
        int n = lod == 0 ? layers.length : 2;
        for (int i = 0; i < n; i++) {
            float[] l = layers[i];
            int col = c(cols[i], 0);
            b.push().rotY(i * 0.35f).cyl(0, l[0], 0, l[2], l[3], l[1], 10, Col.scale(col, 0.85f), col, false, i == layers.length - 1).pop();
        }
        if (lod == 1) b.cyl(0, 5.5f, 0, 9.5f, 8f, 6f, 10, c(0xC87846, 0), c(0xE1AA6E, 0), false, true);
    }

    // ---------------------------------------------------------------- man made

    private static void umbrella(MeshBuilder b, int lod) {
        b.tube(0, 0, 0, 0, 2.5f, 0, 0.045f, 0.04f, 5, c(0xF0F0F0, 0), c(0xF0F0F0, 0), false);
        int n = 8;
        float r = 1.7f;
        for (int i = 0; i < n; i++) {
            float a0 = MathX.TAU * i / n, a1 = MathX.TAU * (i + 1) / n;
            int col = (i & 1) == 0 ? c(0xE53935, 0) : c(0xFFFFFF, 0);
            b.flatTri(0, 3.0f, 0, (float) Math.cos(a1) * r, 2.35f, (float) Math.sin(a1) * r, (float) Math.cos(a0) * r, 2.35f, (float) Math.sin(a0) * r, col);
        }
        b.cyl(0, 2.35f, 0, r, r * 0.97f, 0.0f, n, c(0xFFFFFF, 0), c(0xFFFFFF, 0), false, false);
    }

    private static void torch(MeshBuilder b, int lod) {
        b.tube(0, 0, 0, 0, 1.9f, 0, 0.07f, 0.06f, 5, c(0x7A5230, 0), c(0x7A5230, 0), false);
        b.cyl(0, 1.85f, 0, 0.14f, 0.22f, 0.22f, 7, c(0x3A2A20, 0), c(0x5A4030, 0), false, false);
        b.cyl(0, 2.05f, 0, 0.16f, 0.0f, 0.55f, 6, c(0xFF7A10, 128), c(0xFFE060, 128), false, false);
    }

    private static void lighthouse(MeshBuilder b) {
        float y = 0f;
        for (int i = 0; i < 6; i++) {
            float r0 = 2.7f - i * 0.18f, r1 = 2.7f - (i + 1) * 0.18f;
            int col = (i & 1) == 0 ? c(0xF5F5F5, 0) : c(0xD32F2F, 0);
            b.cyl(0, y, 0, r0, r1, 3.0f, 12, Col.scale(col, 0.88f), col, false, false);
            y += 3.0f;
        }
        b.cyl(0, y, 0, 2.2f, 2.2f, 0.35f, 12, c(0x37474F, 0), c(0x546E7A, 0), false, true);
        b.cyl(0, y + 0.35f, 0, 1.1f, 1.0f, 1.7f, 10, c(0xFFD54F, 128), c(0xFFF59D, 128), false, false);
        b.cyl(0, y + 2.05f, 0, 1.6f, 0f, 1.6f, 10, c(0xB71C1C, 0), c(0xE53935, 0), false, false);
        b.box(0, 0.9f, -2.65f, 0.5f, 0.9f, 0.1f, c(0x5D4037, 0));
    }

    private static void sign(MeshBuilder b, boolean right) {
        b.tube(0, 0, 0, 0, 2.2f, 0, 0.06f, 0.06f, 5, c(0x6D4C41, 0), c(0x6D4C41, 0), false);
        b.box(0, 2.55f, -0.015f, 1.0f, 0.55f, 0.03f, c(0x263238, 0));
        b.box(0, 2.55f, 0.02f, 0.93f, 0.48f, 0.02f, c(0xFFC400, 0));
        float s = right ? 1f : -1f;
        int dk = c(0x263238, 0);
        b.box(-0.12f * s, 2.55f, 0.045f, 0.4f, 0.1f, 0.01f, dk);
        if (right) b.flatTri(0.28f, 2.92f, 0.052f, 0.28f, 2.18f, 0.052f, 0.80f, 2.55f, 0.052f, dk);
        else b.flatTri(-0.28f, 2.18f, 0.052f, -0.28f, 2.92f, 0.052f, -0.80f, 2.55f, 0.052f, dk);
    }

    private static void tuft(MeshBuilder b, int lod) {
        int blades = lod == 0 ? 3 : 2;
        for (int k = 0; k < blades; k++) {
            b.push().rotY(k * MathX.PI / blades);
            b.ribbon(new float[]{0, 0.05f, 0.12f}, new float[]{0, 0.5f, 0.9f}, new float[]{0, 0, 0}, new float[]{0.24f, 0.18f, 0.02f},
                    1f, 0f, 0f, c(0x4A9A3A, 0), c(0xA6D36A, 127));
            b.pop();
        }
    }

    private static void totem(MeshBuilder b, int lod) {
        int w0 = c(0x825532, 0), w1 = c(0x966440, 0), w2 = c(0x784B2D, 0);
        b.box(0, 0.6f, 0, 0.45f, 0.6f, 0.45f, w0);
        b.box(0, 1.8f, 0, 0.40f, 0.6f, 0.40f, w1);
        b.box(0, 2.9f, 0, 0.45f, 0.5f, 0.45f, w2);
        b.cyl(0, 3.4f, 0, 0.52f, 0f, 0.7f, 6, c(0x1E9E8A, 0), c(0xFFB300, 0), false, false);
        for (int lvl = 0; lvl < 3; lvl++) {
            float y = lvl == 0 ? 0.75f : (lvl == 1 ? 1.95f : 3.0f);
            float hw = lvl == 1 ? 0.40f : 0.45f;
            b.box(-0.18f, y + 0.12f, hw + 0.01f, 0.1f, 0.08f, 0.01f, c(0xFFFFFF, 0));
            b.box(0.18f, y + 0.12f, hw + 0.01f, 0.1f, 0.08f, 0.01f, c(0xFFFFFF, 0));
            b.box(-0.18f, y + 0.12f, hw + 0.02f, 0.04f, 0.04f, 0.01f, c(0x101010, 0));
            b.box(0.18f, y + 0.12f, hw + 0.02f, 0.04f, 0.04f, 0.01f, c(0x101010, 0));
            b.box(0, y - 0.15f, hw + 0.01f, 0.2f, 0.07f, 0.01f, c(0x3A1A10, 0));
        }
        b.box(0, 1.2f, 0.0f, 0.5f, 0.05f, 0.5f, c(0xD84315, 0));
        b.box(0, 2.4f, 0.0f, 0.45f, 0.05f, 0.45f, c(0x1E9E8A, 0));
    }

}
