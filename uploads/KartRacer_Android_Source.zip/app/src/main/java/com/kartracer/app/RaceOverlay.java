package com.kartracer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;

import com.kartracer.gfx.HudData;
import com.kartracer.sim.PlayerInput;
import com.kartracer.world.TrackData;

/** In-race HUD, touch controls (buttons / tilt / slide), minimap and the control layout editor. */
public final class RaceOverlay extends View implements SensorEventListener {
    public interface Callbacks {
        void onPausePressed();
        void onEditDone();
    }

    private static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, DRIFT = 4, ITEM = 5, BOOST = 6;
    private static final float[] BASE_R = {40, 40, 54, 42, 44, 38, 36};
    private static final int[] CTL_COL = {0xFF2A4A6B, 0xFF2A4A6B, 0xFF2E9E4F, 0xFFC62828, 0xFF00838F, 0xFF6A1B9A, 0xFFEF6C00};
    private static final int[] CTL_ICON = {Icons.ARROW_L, Icons.ARROW_R, Icons.PEDAL, Icons.BRAKE, Icons.DRIFT, Icons.BOX, Icons.BOLT};
    private static final int[] LEVEL_COL = {0xFFFFFFFF, 0xFF4FC3F7, 0xFFFFA726, 0xFFE040FB};

    private final Settings settings;
    private final HudData hud;
    private final PlayerInput input;
    private final Callbacks cb;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path mapPath = new Path();
    private final float[] fit = new float[3];
    private MapPaths.Data mapData;
    private float mapBoxX, mapBoxY, mapBoxS;
    private final float[] cx = new float[7], cy = new float[7], cr = new float[7];
    private final boolean[] down = new boolean[7];
    private final int[] ptrCtl = new int[24];
    private final boolean[] ptrActive = new boolean[24];
    private int slidePtr = -1;
    private float slideStartX, slideSteer, tiltSteer, tiltFiltered;
    private boolean tiltOn;
    private boolean editMode;
    private int editCtl = -1;
    private float pauseX, pauseY, pauseR;
    private int lastSpeed = -1;
    private String speedStr = "0";
    private boolean looping;

    public RaceOverlay(Context c, Settings s, HudData hud, PlayerInput input, Callbacks cb) {
        super(c);
        settings = s; this.hud = hud; this.input = input; this.cb = cb;
        text.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        for (int i = 0; i < ptrCtl.length; i++) ptrCtl[i] = -1;
        setClickable(true);
    }

    // ------------------------------------------------------------------ public API

    public void setTrack(TrackData td) {
        mapData = MapPaths.forTrack(td);
        mapBoxS = 0f;
    }

    public void startLoop() {
        if (!looping) { looping = true; invalidate(); }
        refreshSensors();
    }

    public void stopLoop() {
        looping = false;
        unregisterSensors();
        input.clear();
        for (int i = 0; i < down.length; i++) down[i] = false;
        for (int i = 0; i < ptrActive.length; i++) { ptrActive[i] = false; ptrCtl[i] = -1; }
        slidePtr = -1;
    }

    public void startEditing() {
        editMode = true;
        editCtl = -1;
        looping = true;
        invalidate();
    }

    public boolean isEditing() { return editMode; }

    public void refreshSensors() {
        unregisterSensors();
        if (settings.steerMode == 1 && looping) {
            SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            Sensor a = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a != null) { sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME); tiltOn = true; }
        }
    }

    private void unregisterSensors() {
        if (tiltOn) {
            SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            if (sm != null) sm.unregisterListener(this);
            tiltOn = false;
        }
        tiltSteer = tiltFiltered = 0f;
    }

    @Override protected void onDetachedFromWindow() { unregisterSensors(); super.onDetachedFromWindow(); }

    @Override
    public void onSensorChanged(SensorEvent ev) {
        float ax = ev.values[0], ay = ev.values[1];
        Display d = getDisplay();
        int rot = d != null ? d.getRotation() : Surface.ROTATION_90;
        float sx;
        if (rot == Surface.ROTATION_90) sx = ay;
        else if (rot == Surface.ROTATION_270) sx = -ay;
        else if (rot == Surface.ROTATION_180) sx = -ax;
        else sx = ax;
        float raw = -sx / (9.81f * 0.5f) * (settings.tiltSens / 100f);
        if (Math.abs(raw) < 0.06f) raw = 0f;
        raw = Math.max(-1f, Math.min(1f, raw));
        tiltFiltered += (raw - tiltFiltered) * 0.35f;
        tiltSteer = tiltFiltered;
        if (settings.steerMode == 1 && !editMode) input.steer = tiltSteer;
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    // ------------------------------------------------------------------ layout

    private boolean visible(int i) {
        if (editMode) return true;
        if (i == LEFT || i == RIGHT) return settings.steerMode == 0;
        if (i == ITEM) return hud.itemsOn;
        return true;
    }

    private void layoutControls(int W, int H) {
        float sc = settings.buttonScale / 100f;
        for (int i = 0; i < 7; i++) {
            cx[i] = settings.layout[i * 2] * W;
            cy[i] = settings.layout[i * 2 + 1] * H;
            cr[i] = Ui.dp(BASE_R[i]) * sc;
        }
        pauseR = Ui.dp(22);
        pauseX = W - Ui.dp(16) - pauseR;
        pauseY = Ui.dp(14) + pauseR;
    }

    // ------------------------------------------------------------------ touch

    private int hit(float x, float y) {
        int best = -1;
        float bestD = 1e9f;
        for (int i = 0; i < 7; i++) {
            if (!visible(i)) continue;
            float dx = x - cx[i], dy = y - cy[i];
            float d = (float) Math.sqrt(dx * dx + dy * dy) / cr[i];
            if (d < 1.25f && d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    private void haptic() {
        if (settings.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int W = getWidth(), H = getHeight();
        layoutControls(W, H);
        if (editMode) return editTouch(e, W, H);
        if (!hud.active) return false;
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int idx = e.getActionIndex(), id = e.getPointerId(idx);
            if (id >= ptrCtl.length) return true;
            float x = e.getX(idx), y = e.getY(idx);
            ptrActive[id] = true;
            int c = hit(x, y);
            if (c >= 0) {
                ptrCtl[id] = c;
                if (c == ITEM) { input.pressItem(); haptic(); }
                else if (c == DRIFT || c == BOOST) haptic();
            } else if ((x - pauseX) * (x - pauseX) + (y - pauseY) * (y - pauseY) < pauseR * pauseR * 2.2f) {
                ptrCtl[id] = -1;
                cb.onPausePressed();
            } else if (settings.steerMode == 2 && x < W * 0.55f && slidePtr < 0) {
                slidePtr = id; slideStartX = x; slideSteer = 0f; ptrCtl[id] = -2;
            } else ptrCtl[id] = -1;
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id == slidePtr) slideSteer = Math.max(-1f, Math.min(1f, (e.getX(i) - slideStartX) / Ui.dp(60)));
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            if (action == MotionEvent.ACTION_CANCEL) {
                for (int i = 0; i < ptrActive.length; i++) { ptrActive[i] = false; ptrCtl[i] = -1; }
                slidePtr = -1; slideSteer = 0f;
            } else {
                int idx = e.getActionIndex(), id = e.getPointerId(idx);
                if (id < ptrCtl.length) { ptrActive[id] = false; ptrCtl[id] = -1; }
                if (id == slidePtr) { slidePtr = -1; slideSteer = 0f; }
            }
        }
        publish();
        return true;
    }

    private void publish() {
        for (int i = 0; i < 7; i++) down[i] = false;
        for (int i = 0; i < ptrCtl.length; i++) if (ptrActive[i] && ptrCtl[i] >= 0) down[ptrCtl[i]] = true;
        float steer;
        if (settings.steerMode == 1) steer = tiltSteer;
        else if (settings.steerMode == 2) steer = slideSteer;
        else steer = (down[RIGHT] ? 1f : 0f) - (down[LEFT] ? 1f : 0f);
        input.steer = steer;
        input.throttle = (settings.autoGas || down[GAS]) ? 1f : 0f;
        input.brake = down[BRAKE] ? 1f : 0f;
        input.drift = down[DRIFT];
        input.boost = down[BOOST];
    }

    private boolean editTouch(MotionEvent e, int W, int H) {
        float x = e.getX(), y = e.getY();
        int a = e.getActionMasked();
        float bw = Ui.dp(110), bh = Ui.dp(40), by = Ui.dp(14);
        float resetX = W / 2f - bw - Ui.dp(8), doneX = W / 2f + Ui.dp(8);
        if (a == MotionEvent.ACTION_DOWN) {
            if (y > by && y < by + bh && x > doneX && x < doneX + bw) { editMode = false; settings.customLayout = true; cb.onEditDone(); return true; }
            if (y > by && y < by + bh && x > resetX && x < resetX + bw) { settings.resetLayout(); invalidate(); return true; }
            editCtl = hit(x, y);
        } else if (a == MotionEvent.ACTION_MOVE && editCtl >= 0) {
            settings.layout[editCtl * 2] = Math.max(0.05f, Math.min(0.95f, x / W));
            settings.layout[editCtl * 2 + 1] = Math.max(0.08f, Math.min(0.94f, y / H));
            settings.customLayout = true;
            invalidate();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) editCtl = -1;
        return true;
    }

    // ------------------------------------------------------------------ drawing

    private void label(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean shadow) {
        text.setTextSize(size);
        text.setTextAlign(align);
        if (shadow) { text.setColor(0xAA000000); c.drawText(s, x + Ui.dp(1.5f), y + Ui.dp(1.5f), text); }
        text.setColor(color);
        c.drawText(s, x, y, text);
    }

    private static String ordinal(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) return "th";
        switch (n % 10) { case 1: return "st"; case 2: return "nd"; case 3: return "rd"; default: return "th"; }
    }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        layoutControls(W, H);
        if (editMode) { drawEdit(c, W, H); return; }
        if (!hud.active || !looping) return;
        publish();
        float d = Ui.density();
        drawPlace(c, d);
        drawMinimap(c, W, d);
        drawPause(c);
        drawCenter(c, W, H, d);
        drawSpeed(c, W, H, d);
        drawControls(c, false);
        if (settings.showFps) label(c, hud.fps + " fps", W * 0.5f, Ui.dp(22), 13 * d, 0xCCFFFFFF, Paint.Align.CENTER, true);
        postInvalidateDelayed(30);
    }

    private void drawPlace(Canvas c, float d) {
        float x = Ui.dp(18), y = Ui.dp(14);
        String num = String.valueOf(hud.place);
        label(c, num, x, y + Ui.dp(46), 52 * d / 2.2f * 2.2f, 0xFFFFFFFF, Paint.Align.LEFT, true);
        text.setTextSize(52 * d);
        float nw = text.measureText(num);
        label(c, ordinal(hud.place), x + nw + Ui.dp(2), y + Ui.dp(20), 18 * d, 0xFFFFD54F, Paint.Align.LEFT, true);
        label(c, "/ " + hud.nKarts, x + nw + Ui.dp(2), y + Ui.dp(44), 14 * d, 0xCCFFFFFF, Paint.Align.LEFT, true);
        String lap = "LAP " + hud.lap + "/" + hud.laps;
        text.setTextSize(13 * d);
        float lw = text.measureText(lap) + Ui.dp(20);
        paint.setColor(0x99000000);
        rect.set(x, y + Ui.dp(56), x + lw, y + Ui.dp(82));
        c.drawRoundRect(rect, Ui.dp(13), Ui.dp(13), paint);
        label(c, lap, x + lw / 2f, y + Ui.dp(74), 13 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
    }

    private void drawPause(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x99000000);
        c.drawCircle(pauseX, pauseY, pauseR, paint);
        paint.setColor(0xFFFFFFFF);
        Icons.draw(c, Icons.PAUSE, pauseX, pauseY, pauseR * 0.5f, paint);
    }

    private void drawMinimap(Canvas c, int W, float d) {
        if (mapData == null) return;
        float S = Ui.dp(116);
        float x = W - Ui.dp(16) - S, y = Ui.dp(14) + Ui.dp(44) + Ui.dp(10);
        if (mapBoxS != S || mapBoxX != x) {
            mapBoxS = S; mapBoxX = x; mapBoxY = y;
            MapPaths.fit(mapData, x, y, S, S, Ui.dp(10), fit);
            MapPaths.buildPath(mapData, fit, mapPath);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x88000000);
        rect.set(x, y, x + S, y + S);
        c.drawRoundRect(rect, Ui.dp(12), Ui.dp(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(Ui.dp(5));
        paint.setColor(0xFF1A1A1A);
        c.drawPath(mapPath, paint);
        paint.setStrokeWidth(Ui.dp(2.6f));
        paint.setColor(0xEEFFFFFF);
        c.drawPath(mapPath, paint);
        paint.setStyle(Paint.Style.FILL);
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < hud.mapN; i++) {
                boolean me = i == hud.localSlot;
                if ((pass == 1) != me) continue;
                float u = hud.mapX[i] * fit[0] + fit[1], v = hud.mapZ[i] * fit[0] + fit[2];
                paint.setColor(0xFFFFFFFF);
                c.drawCircle(u, v, Ui.dp(me ? 6.5f : 4.6f), paint);
                paint.setColor(0xFF000000 | hud.mapColor[i]);
                c.drawCircle(u, v, Ui.dp(me ? 4.8f : 3.2f), paint);
                if (me) {
                    float fx = (float) Math.sin(hud.mapYaw[i]), fz = -(float) Math.cos(hud.mapYaw[i]);
                    paint.setStrokeWidth(Ui.dp(2));
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(0xFFFFFFFF);
                    c.drawLine(u, v, u + fx * Ui.dp(11), v + fz * Ui.dp(11), paint);
                    paint.setStyle(Paint.Style.FILL);
                }
            }
        }
    }

    private void drawCenter(Canvas c, int W, int H, float d) {
        float x = W / 2f, y = H * 0.36f;
        long now = System.currentTimeMillis();
        if (hud.phase == 0) {
            float rt = hud.raceTime;
            if (rt < -3.2f) {
                label(c, hud.netMode ? "WAITING FOR PLAYERS" : "GET READY", x, y, 26 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
            } else {
                int n = (int) Math.ceil(-rt);
                float frac = n - (-rt);
                int col = n >= 3 ? 0xFFEF5350 : (n == 2 ? 0xFFFFA726 : 0xFFFFEE58);
                float size = 110 * d * (1f + 0.35f * (1f - frac));
                label(c, String.valueOf(Math.max(1, n)), x, y + Ui.dp(40), size, col, Paint.Align.CENTER, true);
            }
        } else if (hud.phase == 1 && hud.raceTime < 1.0f && hud.raceTime >= 0f) {
            int a = (int) (255 * (1f - hud.raceTime));
            label(c, "GO!", x, y + Ui.dp(30), 96 * d, (a << 24) | 0x66FF66, Paint.Align.CENTER, true);
        }
        if (now < hud.toastUntilMs && hud.toast != null && hud.toast.length() > 0 && !hud.finished) {
            label(c, hud.toast, x, H * 0.22f, 26 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        }
        if (hud.wrongWay && !hud.finished) {
            paint.setColor(0xCCB71C1C);
            rect.set(x - Ui.dp(120), H * 0.46f - Ui.dp(22), x + Ui.dp(120), H * 0.46f + Ui.dp(22));
            c.drawRoundRect(rect, Ui.dp(10), Ui.dp(10), paint);
            label(c, "WRONG WAY", x, H * 0.46f + Ui.dp(9), 22 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
        }
        if (hud.finished) {
            label(c, "FINISHED  " + hud.place + ordinal(hud.place), x, H * 0.30f, 40 * d, 0xFFFFD54F, Paint.Align.CENTER, true);
            if (hud.phase != 2) label(c, "Waiting for the other racers...", x, H * 0.30f + Ui.dp(34), 16 * d, 0xDDFFFFFF, Paint.Align.CENTER, true);
        }
        if (hud.paused) label(c, "PAUSED", x, y, 40 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
    }

    private void drawSpeed(Canvas c, int W, int H, float d) {
        int sp = (int) hud.speedKmh;
        if (sp != lastSpeed) { lastSpeed = sp; speedStr = String.valueOf(sp); }
        float x = W / 2f;
        label(c, speedStr, x, H - Ui.dp(62), 40 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        label(c, "KM/H", x, H - Ui.dp(46), 11 * d, 0xCCB0C4DE, Paint.Align.CENTER, true);
        float bw = Ui.dp(150), bh = Ui.dp(8), by = H - Ui.dp(30);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        rect.set(x - bw / 2f, by, x + bw / 2f, by + bh);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
        paint.setColor(hud.boosting ? 0xFFFF9800 : 0xFF26C6DA);
        rect.set(x - bw / 2f, by, x - bw / 2f + bw * Math.max(0.03f, Math.min(1f, hud.nitro)), by + bh);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
        label(c, "NITRO", x, by + Ui.dp(22), 10 * d, 0xAAB0C4DE, Paint.Align.CENTER, false);
    }

    private int itemIcon(int item) {
        switch (item) {
            case 1: return Icons.BOLT;
            case 2: return Icons.ROCKET;
            case 3: return Icons.COCONUT;
            case 4: return Icons.DROP;
            case 5: return Icons.SHIELD;
            default: return Icons.BOX;
        }
    }

    private int itemColor(int item) {
        switch (item) {
            case 1: return 0xFFFFEE58;
            case 2: return 0xFFFF7043;
            case 3: return 0xFFA1887F;
            case 4: return 0xFFB388FF;
            case 5: return 0xFF4FC3F7;
            default: return 0xFFFFFFFF;
        }
    }

    private void drawControls(Canvas c, boolean edit) {
        float op = settings.controlOpacity / 100f;
        for (int i = 0; i < 7; i++) {
            if (!visible(i)) continue;
            boolean pressed = down[i] || (i == GAS && settings.autoGas && !edit);
            float x = cx[i], y = cy[i], r = cr[i];
            int a = (int) (255 * op * (pressed ? 1f : 0.72f));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((a << 24) | (CTL_COL[i] & 0xFFFFFF));
            c.drawCircle(x, y, r * (pressed ? 0.94f : 1f), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(2));
            paint.setColor(((int) (255 * op * 0.8f) << 24) | 0xFFFFFF);
            c.drawCircle(x, y, r, paint);
            int icon = CTL_ICON[i];
            int ic = 0xFFFFFFFF;
            float iconScale = 0.52f;
            if (i == ITEM) {
                icon = itemIcon(hud.item);
                ic = hud.item == 0 ? 0x77FFFFFF : itemColor(hud.item);
                iconScale = 0.58f;
                if (hud.item != 0) {
                    float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 160.0);
                    paint.setColor(((int) (120 * pulse) << 24) | 0xFFFFFF);
                    paint.setStrokeWidth(Ui.dp(4));
                    c.drawCircle(x, y, r + Ui.dp(3), paint);
                }
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ic);
            Icons.draw(c, icon, x, y, r * iconScale, paint);
            if (!edit && i == DRIFT && hud.drifting) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(5));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setColor(LEVEL_COL[Math.max(0, Math.min(3, hud.driftLevel))]);
                rect.set(x - r - Ui.dp(6), y - r - Ui.dp(6), x + r + Ui.dp(6), y + r + Ui.dp(6));
                c.drawArc(rect, -90, Math.min(360f, hud.driftTime / 2.8f * 360f), false, paint);
            }
            if (!edit && i == BOOST && hud.nitro > 0.01f) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(4));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setColor(0xFFFFEE58);
                rect.set(x - r - Ui.dp(5), y - r - Ui.dp(5), x + r + Ui.dp(5), y + r + Ui.dp(5));
                c.drawArc(rect, -90, 360f * hud.nitro, false, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeCap(Paint.Cap.BUTT);
        }
    }

    private void drawEdit(Canvas c, int W, int H) {
        float d = Ui.density();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x88000000);
        c.drawRect(0, 0, W, H, paint);
        drawControls(c, true);
        for (int i = 0; i < 7; i++) {
            label(c, Settings.CONTROL_NAMES[i], cx[i], cy[i] + cr[i] + Ui.dp(16), 11 * d, i == editCtl ? 0xFFFFA726 : 0xFFFFFFFF, Paint.Align.CENTER, true);
            if (i == editCtl) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(3));
                paint.setColor(0xFFFFA726);
                c.drawCircle(cx[i], cy[i], cr[i] + Ui.dp(4), paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
        label(c, "Drag the buttons where you want them", W / 2f, Ui.dp(76), 15 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        float bw = Ui.dp(110), bh = Ui.dp(40), by = Ui.dp(14);
        float resetX = W / 2f - bw - Ui.dp(8), doneX = W / 2f + Ui.dp(8);
        paint.setColor(0xFF244566);
        rect.set(resetX, by, resetX + bw, by + bh);
        c.drawRoundRect(rect, Ui.dp(10), Ui.dp(10), paint);
        label(c, "RESET", resetX + bw / 2f, by + bh / 2f + Ui.dp(5), 14 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
        paint.setColor(0xFFFFA726);
        rect.set(doneX, by, doneX + bw, by + bh);
        c.drawRoundRect(rect, Ui.dp(10), Ui.dp(10), paint);
        label(c, "DONE", doneX + bw / 2f, by + bh / 2f + Ui.dp(5), 14 * d, 0xFF1A1000, Paint.Align.CENTER, false);
    }
}
