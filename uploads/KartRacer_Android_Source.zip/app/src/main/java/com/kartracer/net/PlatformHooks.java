package com.kartracer.net;

/** Things the networking code needs from the platform (implemented on Android by the app). */
public interface PlatformHooks {
    /** Keep the Wi-Fi radio receptive to broadcast packets while discovery runs. */
    void acquireMulticastLock();
    void releaseMulticastLock();
    /** Extra broadcast addresses the platform knows about (may be empty). */
    String[] extraBroadcastAddresses();

    PlatformHooks NONE = new PlatformHooks() {
        public void acquireMulticastLock() {}
        public void releaseMulticastLock() {}
        public String[] extraBroadcastAddresses() { return new String[0]; }
    };
}
