package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;

/** Procedural kart, wheel and driver meshes. Body space: forward = -Z, right = +X, ground at y = 0. */
public final class KartModels {
    private KartModels() {}

    public static final int TYPES = 6, DRIVERS = 6;
    public static final String[] DRIVER_NAMES = {"Rex", "Coco", "Bolt", "Mango", "Zippy", "Tiki"};
    /** Paint colors (0xRRGGBB) offered in the garage. */
    public static final int[] PAINTS = {0xE53935, 0xFF9800, 0xFDD835, 0x43A047, 0x00ACC1, 0x1E88E5, 0x8E24AA, 0xEC407A};
    public static final String[] PAINT_NAMES = {"Red", "Orange", "Yellow", "Green", "Teal", "Blue", "Purple", "Pink"};

    // wheel layout per kart type
    public static final float[] FRONT_R = {0.40f, 0.34f, 0.62f, 0.38f, 0.34f, 0.50f};
    public static final float[] REAR_R = {0.44f, 0.38f, 0.62f, 0.38f, 0.46f, 0.50f};
    public static final float[] WHEEL_W = {0.32f, 0.26f, 0.44f, 0.30f, 0.30f, 0.36f};
    public static final float[] TRACK_HALF = {0.82f, 0.78f, 1.00f, 0.80f, 0.82f, 0.90f};
    public static final float[] BASE_HALF = {0.95f, 1.05f, 1.00f, 0.90f, 1.00f, 1.00f};
    public static final float[] SEAT_Y = {0.80f, 0.60f, 1.45f, 0.82f, 0.85f, 0.98f};
    public static final float[] SEAT_Z = {0.15f, 0.20f, 0.35f, 0.30f, 0.45f, 0.30f};

    private static int paint(int shade) { return Col.rgba(shade, shade, shade, 255); }
    private static int fixed(int r, int g, int b) { return Col.rgba(r, g, b, 0); }

    private static final int STEEL = fixed(176, 182, 190), DARK = fixed(46, 50, 58), BLACK = fixed(24, 26, 30), LIGHT = fixed(255, 248, 200);

    public static MeshData body(int type) {
        MeshBuilder b = new MeshBuilder();
        switch (Math.floorMod(type, TYPES)) {
            case 0: duneHopper(b); break;
            case 1: sandViper(b); break;
            case 2: rockCrusher(b); break;
            case 3: waveRunner(b); break;
            case 4: lavaRod(b); break;
            default: jungleRover(b); break;
        }
        return b.build();
    }

    private static void duneHopper(MeshBuilder b) {
        int p = paint(238), pd = paint(205);
        b.box(0, 0.36f, 0, 0.55f, 0.05f, 1.25f, DARK);
        b.box(0, 0.58f, 0.15f, 0.62f, 0.20f, 0.95f, p);
        b.box(0, 0.50f, -1.10f, 0.42f, 0.14f, 0.40f, p);
        b.sphere(0, 0.50f, -1.42f, 0.38f, 0.16f, 0.30f, 10, 6, pd, p);
        b.box(0, 0.73f, -0.90f, 0.18f, 0.02f, 0.22f, DARK);
        b.box(0, 0.74f, 0.20f, 0.34f, 0.07f, 0.30f, fixed(40, 44, 52));
        b.box(0, 0.95f, 0.58f, 0.36f, 0.30f, 0.09f, fixed(40, 44, 52));
        for (int s = -1; s <= 1; s += 2) {
            b.tube(s * 0.52f, 0.70f, 0.40f, s * 0.52f, 1.60f, 0.40f, 0.05f, 0.05f, 6, STEEL, STEEL, true);
            b.tube(s * 0.52f, 1.60f, 0.40f, s * 0.42f, 0.85f, 1.05f, 0.04f, 0.04f, 6, STEEL, STEEL, true);
            b.tube(s * 0.22f, 0.80f, 1.20f, s * 0.22f, 0.95f, 1.78f, 0.07f, 0.06f, 8, STEEL, DARK, true);
            b.box(s * 0.88f, 0.80f, -0.95f, 0.20f, 0.04f, 0.42f, p);
            b.box(s * 0.88f, 0.80f, 0.95f, 0.20f, 0.04f, 0.42f, p);
            b.sphere(s * 0.30f, 0.58f, -1.62f, 0.10f, 8, 5, LIGHT);
        }
        b.tube(0, 1.60f, 0.40f, 0, 1.60f, 0.40f, 0.05f, 0.05f, 6, STEEL, STEEL, false);
        b.tube(-0.52f, 1.60f, 0.40f, 0.52f, 1.60f, 0.40f, 0.05f, 0.05f, 6, STEEL, STEEL, true);
        b.box(0, 0.80f, 1.05f, 0.40f, 0.22f, 0.22f, fixed(70, 74, 82));
        b.tube(-0.6f, 0.45f, -1.6f, 0.6f, 0.45f, -1.6f, 0.05f, 0.05f, 6, STEEL, STEEL, true);
        b.push().translate(0, 1.02f, -0.18f).rotX(-1.0f).cyl(0, -0.02f, 0, 0.19f, 0.19f, 0.04f, 10, BLACK, BLACK, true, true).pop();
        b.tube(0, 0.85f, 0.0f, 0, 1.0f, -0.16f, 0.03f, 0.03f, 6, STEEL, STEEL, false);
    }

    private static void sandViper(MeshBuilder b) {
        int p = paint(240), pd = paint(200);
        b.box(0, 0.42f, 0.10f, 0.50f, 0.13f, 1.20f, p);
        b.tube(0, 0.42f, -1.0f, 0, 0.40f, -2.05f, 0.42f, 0.06f, 10, p, pd, true);
        b.box(0, 0.62f, 0.25f, 0.42f, 0.08f, 0.50f, fixed(30, 32, 38));
        b.box(0, 0.30f, -1.95f, 0.80f, 0.025f, 0.22f, pd);
        for (int s = -1; s <= 1; s += 2) {
            b.box(s * 0.72f, 0.48f, 0.20f, 0.14f, 0.13f, 0.70f, fixed(50, 54, 62));
            b.box(s * 0.72f, 0.50f, -0.52f, 0.10f, 0.07f, 0.05f, BLACK);
            b.tube(s * 0.50f, 0.50f, 1.20f, s * 0.50f, 1.15f, 1.35f, 0.04f, 0.04f, 6, STEEL, STEEL, true);
            b.box(s * 0.95f, 1.15f, 1.40f, 0.03f, 0.18f, 0.30f, p);
            b.tube(s * 0.20f, 0.50f, 1.25f, s * 0.20f, 0.62f, 1.75f, 0.08f, 0.07f, 8, STEEL, DARK, true);
            b.box(s * 0.30f, 0.50f, -1.40f, 0.12f, 0.02f, 0.04f, LIGHT);
        }
        b.box(0, 1.18f, 1.40f, 0.95f, 0.04f, 0.28f, p);
        b.box(0, 0.58f, 1.2f, 0.4f, 0.12f, 0.2f, fixed(70, 74, 82));
    }

    private static void rockCrusher(MeshBuilder b) {
        int p = paint(238), pd = paint(210);
        b.box(0, 0.95f, 0.05f, 0.62f, 0.12f, 1.35f, fixed(50, 52, 58));
        b.box(0, 1.25f, 0.25f, 0.72f, 0.25f, 1.00f, p);
        b.box(0, 1.20f, -0.95f, 0.60f, 0.20f, 0.50f, pd);
        b.box(0, 1.68f, 0.45f, 0.58f, 0.28f, 0.55f, fixed(30, 40, 55));
        b.box(0, 1.98f, 0.45f, 0.64f, 0.04f, 0.62f, p);
        b.box(0, 0.80f, -0.2f, 0.5f, 0.04f, 0.9f, STEEL);
        b.tube(-0.6f, 0.95f, -1.58f, 0.6f, 0.95f, -1.58f, 0.07f, 0.07f, 8, STEEL, STEEL, true);
        b.tube(-0.6f, 1.35f, -1.58f, 0.6f, 1.35f, -1.58f, 0.06f, 0.06f, 8, STEEL, STEEL, true);
        for (int s = -1; s <= 1; s += 2) {
            b.tube(s * 0.5f, 0.70f, -1.58f, s * 0.5f, 1.35f, -1.58f, 0.06f, 0.06f, 6, STEEL, STEEL, true);
            b.tube(s * 0.55f, 1.40f, 1.10f, s * 0.55f, 2.50f, 1.10f, 0.09f, 0.08f, 8, STEEL, DARK, true);
            b.box(s * 0.40f, 2.08f, 0.15f, 0.08f, 0.06f, 0.06f, LIGHT);
            b.box(s * 0.62f, 1.30f, -1.3f, 0.10f, 0.08f, 0.06f, LIGHT);
        }
        b.box(0, 2.08f, 0.15f, 0.08f, 0.06f, 0.06f, LIGHT);
    }

    private static void waveRunner(MeshBuilder b) {
        int p = paint(235), pd = paint(190);
        b.sphere(0, 0.62f, 0.05f, 0.62f, 0.30f, 1.30f, 12, 8, pd, p);
        b.sphere(0, 0.58f, -1.15f, 0.40f, 0.22f, 0.55f, 10, 6, pd, p);
        b.push().translate(0, 0.98f, -0.35f).rotX(0.5f).box(0, 0, 0, 0.40f, 0.20f, 0.02f, fixed(150, 210, 240)).pop();
        b.box(0, 0.86f, 0.40f, 0.30f, 0.12f, 0.30f, fixed(40, 44, 52));
        b.push().translate(0, 0.95f, 1.15f).rotX(-0.25f).box(0, 0, 0, 0.28f, 0.04f, 0.95f, fixed(255, 230, 80)).box(0, 0.045f, 0, 0.08f, 0.01f, 0.9f, fixed(230, 60, 60)).pop();
        b.push().translate(0, 1.15f, 1.25f).rotX(0.35f).box(0, 0, 0, 0.03f, 0.30f, 0.40f, p).pop();
        for (int s = -1; s <= 1; s += 2) b.box(s * 0.70f, 0.55f, -0.20f, 0.06f, 0.08f, 0.50f, STEEL);
    }

    private static void lavaRod(MeshBuilder b) {
        int p = paint(238), pd = paint(200);
        b.box(0, 0.45f, 0, 0.50f, 0.07f, 1.40f, fixed(40, 42, 48));
        b.box(0, 0.72f, -0.85f, 0.42f, 0.20f, 0.75f, p);
        b.sphere(0, 0.70f, -1.55f, 0.40f, 0.20f, 0.30f, 10, 6, pd, p);
        b.box(0, 1.00f, -0.85f, 0.30f, 0.15f, 0.40f, fixed(150, 155, 165));
        b.box(0, 0.85f, 0.55f, 0.55f, 0.30f, 0.50f, p);
        b.push().translate(0, 1.2f, 0.12f).rotX(0.6f).box(0, 0, 0, 0.45f, 0.18f, 0.02f, fixed(150, 210, 240)).pop();
        b.box(0, 0.80f, 1.25f, 0.45f, 0.10f, 0.15f, pd);
        b.box(0, 0.95f, 0.15f, 0.30f, 0.30f, 0.07f, fixed(40, 44, 52));
        for (int s = -1; s <= 1; s += 2) {
            for (int k = 0; k < 2; k++) {
                float z = -0.85f + (k == 0 ? -0.2f : 0.2f);
                b.tube(s * 0.12f, 1.08f, z, s * 0.12f, 1.50f, z, 0.05f, 0.04f, 6, STEEL, fixed(255, 150, 30), true);
            }
            b.tube(s * 0.62f, 0.45f, -0.40f, s * 0.62f, 0.45f, 0.75f, 0.06f, 0.06f, 8, STEEL, STEEL, true);
            b.box(s * 0.435f, 0.75f, -0.90f, 0.01f, 0.10f, 0.50f, fixed(255, 140, 20));
            b.sphere(s * 0.30f, 0.62f, -1.75f, 0.09f, 8, 5, LIGHT);
        }
    }

    private static void jungleRover(MeshBuilder b) {
        int p = paint(236), pd = paint(205);
        b.box(0, 0.78f, 0.15f, 0.70f, 0.28f, 1.05f, p);
        b.box(0, 0.85f, -0.95f, 0.55f, 0.20f, 0.50f, pd);
        b.box(0, 0.58f, -0.2f, 0.5f, 0.05f, 1.2f, STEEL);
        b.box(0, 1.05f, 0.25f, 0.62f, 0.04f, 0.04f, DARK);
        for (int s = -1; s <= 1; s += 2) {
            b.tube(s * 0.65f, 1.0f, -0.20f, s * 0.65f, 1.90f, -0.20f, 0.05f, 0.05f, 6, DARK, DARK, true);
            b.tube(s * 0.65f, 1.0f, 0.95f, s * 0.65f, 1.90f, 0.95f, 0.05f, 0.05f, 6, DARK, DARK, true);
            b.tube(s * 0.65f, 1.90f, -0.20f, s * 0.65f, 1.90f, 0.95f, 0.05f, 0.05f, 6, DARK, DARK, true);
            b.sphere(s * 0.50f, 0.92f, -1.45f, 0.13f, 8, 5, LIGHT);
        }
        b.tube(-0.65f, 1.90f, -0.20f, 0.65f, 1.90f, -0.20f, 0.05f, 0.05f, 6, DARK, DARK, true);
        b.tube(-0.65f, 1.90f, 0.95f, 0.65f, 1.90f, 0.95f, 0.05f, 0.05f, 6, DARK, DARK, true);
        b.tube(0.72f, 0.95f, -0.30f, 0.72f, 1.85f, -0.30f, 0.06f, 0.06f, 8, STEEL, STEEL, true);
        b.push().translate(0, 1.0f, 1.30f).rotX(MathX.PI / 2f).cyl(0, -0.10f, 0, 0.42f, 0.42f, 0.2f, 14, BLACK, BLACK, true, true).pop();
        b.push().translate(0, 1.0f, 1.42f).rotX(MathX.PI / 2f).cyl(0, 0, 0, 0.2f, 0.2f, 0.03f, 10, fixed(190, 195, 200), fixed(190, 195, 200), true, true).pop();
        b.box(0, 0.62f, -1.52f, 0.62f, 0.07f, 0.06f, STEEL);
    }

    // ---------------------------------------------------------------- wheels

    public static MeshData wheel(int type, boolean rear) {
        int t = Math.floorMod(type, TYPES);
        float r = rear ? REAR_R[t] : FRONT_R[t], w = WHEEL_W[t];
        MeshBuilder b = new MeshBuilder();
        int tire = fixed(34, 34, 38), tread = fixed(52, 52, 56);
        b.push().rotZ(MathX.PI / 2f).cyl(0, -w / 2f, 0, r, r, w, 18, tire, tire, true, true).pop();
        int blocks = t == 2 || t == 5 ? 14 : 12;
        for (int i = 0; i < blocks; i++) {
            float a = MathX.TAU * i / blocks;
            b.push().rotX(a).translate(0, r, 0).box(0, 0.015f, 0, w * 0.5f * 0.96f, 0.035f, r * 0.17f, tread).pop();
        }
        int hub = fixed(205, 210, 218);
        b.push().rotZ(MathX.PI / 2f).cyl(0, -w * 0.52f, 0, r * 0.58f, r * 0.58f, w * 1.04f, 14, hub, hub, true, true).pop();
        int bolt = fixed(90, 94, 102);
        for (int i = 0; i < 5; i++) {
            float a = MathX.TAU * i / 5f;
            b.push().rotX(a).translate(w * 0.54f, r * 0.30f, 0).box(0, 0, 0, 0.02f, r * 0.09f, r * 0.09f, bolt).pop();
            b.push().rotX(a).translate(-w * 0.54f, r * 0.30f, 0).box(0, 0, 0, 0.02f, r * 0.09f, r * 0.09f, bolt).pop();
        }
        return b.build();
    }

    // ---------------------------------------------------------------- drivers

    private static final int[] SKIN = {0xFFD6AA, 0x8D5C3C, 0xFFC8A0, 0xDCAA78, 0x5A3C28, 0xFADCBE};
    private static final int[] SHIRT = {0xE63C32, 0xFABE28, 0x3278E6, 0x3CBE6E, 0xB450DC, 0xF07828};

    /** Driver in seat space: origin at the seat, forward -Z. */
    public static MeshData driver(int id) {
        int d = Math.floorMod(id, DRIVERS);
        MeshBuilder b = new MeshBuilder();
        int skin = Col.hex(SKIN[d]), shirt = Col.hex(SHIRT[d]);
        int shirtD = Col.scale(shirt, 0.7f);
        b.cyl(0, 0.0f, 0, 0.27f, 0.22f, 0.62f, 10, shirtD, shirt, true, true);
        b.sphere(0, 0.90f, -0.02f, 0.27f, 0.30f, 0.27f, 12, 8, Col.scale(skin, 0.9f), skin);
        for (int s = -1; s <= 1; s += 2) {
            b.sphere(s * 0.10f, 0.94f, -0.23f, 0.075f, 0.085f, 0.04f, 8, 5, Col.hex(0xFFFFFF), Col.hex(0xFFFFFF));
            b.sphere(s * 0.10f, 0.94f, -0.265f, 0.035f, 6, 4, Col.hex(0x20242C));
            b.tube(s * 0.30f, 0.50f, -0.02f, s * 0.20f, 0.22f, -0.48f, 0.075f, 0.065f, 7, shirt, shirt, false);
            b.sphere(s * 0.20f, 0.20f, -0.50f, 0.075f, 7, 5, skin);
        }
        b.box(0, 0.80f, -0.255f, d == 5 ? 0.13f : 0.08f, 0.015f, 0.02f, Col.hex(0x3A2020));
        b.sphere(0, 0.88f, -0.27f, 0.04f, 6, 4, Col.scale(skin, 0.85f));
        switch (d) {
            case 0: { // red cap
                int c = Col.hex(0xD32F2F);
                b.sphere(0, 1.04f, -0.02f, 0.29f, 0.20f, 0.29f, 12, 6, Col.scale(c, 0.8f), c);
                b.box(0, 1.00f, -0.30f, 0.20f, 0.015f, 0.16f, Col.scale(c, 0.7f));
                break;
            }
            case 1: { // pigtails + headband
                int h = Col.hex(0x6D3A1E);
                b.sphere(0, 1.04f, 0.04f, 0.30f, 0.26f, 0.30f, 12, 6, Col.scale(h, 0.8f), h);
                for (int s = -1; s <= 1; s += 2) {
                    b.sphere(s * 0.40f, 0.88f, 0.08f, 0.11f, 8, 5, h);
                    b.tube(s * 0.30f, 1.0f, 0.06f, s * 0.40f, 0.82f, 0.08f, 0.06f, 0.08f, 6, h, h, false);
                }
                b.cyl(0, 1.0f, -0.02f, 0.285f, 0.285f, 0.05f, 12, Col.hex(0xFF4081), Col.hex(0xFF4081), false, false);
                break;
            }
            case 2: { // helmet
                int c = Col.hex(0xECEFF1);
                b.sphere(0, 0.96f, -0.01f, 0.35f, 0.34f, 0.35f, 12, 8, Col.scale(c, 0.85f), c);
                b.box(0, 0.93f, -0.33f, 0.22f, 0.08f, 0.03f, Col.hex(0x1A237E));
                b.box(0, 1.28f, -0.02f, 0.03f, 0.04f, 0.28f, Col.hex(0x1E88E5));
                break;
            }
            case 3: { // mohawk
                int c = Col.hex(0xFF6F00);
                for (int k = 0; k < 6; k++) b.box(0, 1.18f + (k == 2 || k == 3 ? 0.08f : 0f), -0.20f + k * 0.08f, 0.03f, 0.10f + (k == 2 || k == 3 ? 0.06f : 0f), 0.05f, c);
                b.sphere(0, 1.06f, -0.02f, 0.285f, 0.14f, 0.285f, 10, 5, Col.hex(0x3E2723), Col.hex(0x3E2723));
                break;
            }
            case 4: { // goggles + spiky hair
                int hair = Col.hex(0x1B5E20);
                for (int k = 0; k < 5; k++) {
                    float a = -0.6f + k * 0.3f;
                    b.cyl(MathX.clamp(a * 0.4f, -0.3f, 0.3f), 1.10f, -0.02f + a * 0.2f, 0.07f, 0f, 0.2f, 5, hair, hair, false, false);
                }
                b.cyl(0, 0.99f, -0.02f, 0.305f, 0.305f, 0.05f, 12, Col.hex(0x37474F), Col.hex(0x37474F), false, false);
                for (int s = -1; s <= 1; s += 2) b.sphere(s * 0.11f, 1.0f, -0.29f, 0.10f, 0.10f, 0.045f, 8, 5, Col.hex(0x26C6DA), Col.hex(0x80DEEA));
                break;
            }
            default: { // bandana
                int c = Col.hex(0xC62828);
                b.cyl(0, 0.99f, -0.02f, 0.295f, 0.295f, 0.09f, 12, c, c, false, false);
                b.sphere(0, 1.0f, 0.31f, 0.09f, 7, 5, c);
                b.sphere(0, 1.04f, -0.02f, 0.28f, 0.12f, 0.28f, 10, 5, Col.hex(0x212121), Col.hex(0x212121));
                break;
            }
        }
        return b.build();
    }
}
