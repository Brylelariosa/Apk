package com.kartracer.net;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** A framed TCP connection with its own reader and writer threads. Frame = [int len][byte type][payload]. */
public final class Conn {
    public interface Listener {
        void onMessage(Conn c, Msg m);
        void onClosed(Conn c);
    }

    private static final byte[] POISON = new byte[0];
    private final Socket socket;
    private final DataInputStream in;
    private final java.io.OutputStream out;
    private final LinkedBlockingQueue<byte[]> queue = new LinkedBlockingQueue<byte[]>();
    private final Listener listener;
    private volatile boolean open = true;
    public volatile long lastRecvMs = System.currentTimeMillis();
    /** Free slot for the owner (player slot on the host). */
    public int tag = -1;

    public Conn(Socket s, Listener l) throws IOException {
        socket = s;
        listener = l;
        s.setTcpNoDelay(true);
        s.setKeepAlive(true);
        in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
        out = s.getOutputStream();
    }

    public void start(String name) {
        Thread r = new Thread(new Runnable() { public void run() { readLoop(); } }, name + "-read");
        r.setDaemon(true);
        r.start();
        Thread w = new Thread(new Runnable() { public void run() { writeLoop(); } }, name + "-write");
        w.setDaemon(true);
        w.start();
    }

    public boolean isOpen() { return open; }

    public String remoteAddress() {
        try { return socket.getInetAddress().getHostAddress(); } catch (Exception e) { return "?"; }
    }

    public void send(Msg m) {
        if (!open) return;
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64);
            DataOutputStream d = new DataOutputStream(bo);
            d.writeInt(0);
            d.writeByte(m.type());
            m.write(d);
            d.flush();
            byte[] b = bo.toByteArray();
            int len = b.length - 4;
            b[0] = (byte) (len >>> 24); b[1] = (byte) (len >>> 16); b[2] = (byte) (len >>> 8); b[3] = (byte) len;
            queue.offer(b);
        } catch (IOException e) {
            close();
        }
    }

    private void writeLoop() {
        try {
            while (open) {
                byte[] b = queue.poll(500, TimeUnit.MILLISECONDS);
                if (b == null) continue;
                if (b == POISON) break;
                out.write(b);
                // drain what is waiting, then flush once
                byte[] n;
                while ((n = queue.poll()) != null && n != POISON) out.write(n);
                out.flush();
            }
        } catch (Exception ignored) {
        }
        close();
    }

    private void readLoop() {
        try {
            while (open) {
                int len = in.readInt();
                if (len < 1 || len > 1 << 20) throw new IOException("bad frame length " + len);
                byte[] b = new byte[len];
                in.readFully(b);
                lastRecvMs = System.currentTimeMillis();
                DataInputStream d = new DataInputStream(new ByteArrayInputStream(b));
                int type = d.readByte() & 255;
                Msg m = Msg.read(type, d);
                listener.onMessage(this, m);
            }
        } catch (Exception ignored) {
        }
        close();
    }

    public void close() {
        if (!open) return;
        open = false;
        queue.offer(POISON);
        try { socket.close(); } catch (Exception ignored) { }
        listener.onClosed(this);
    }

    /** Flushes queued messages (best effort) then closes. */
    public void closeAfterFlush() {
        if (!open) return;
        new Thread(new Runnable() {
            public void run() {
                try { Thread.sleep(150); } catch (InterruptedException ignored) { }
                close();
            }
        }).start();
    }
}
