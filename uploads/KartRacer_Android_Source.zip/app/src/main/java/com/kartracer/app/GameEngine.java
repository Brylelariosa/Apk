package com.kartracer.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.kartracer.gfx.SceneData;
import com.kartracer.gfx.StaticAssets;
import com.kartracer.gl.GameRenderer;
import com.kartracer.net.ClientLink;
import com.kartracer.net.Discovery;
import com.kartracer.net.HostServer;
import com.kartracer.net.Msg;
import com.kartracer.net.PlatformHooks;
import com.kartracer.sim.Participant;
import com.kartracer.sim.Race;
import com.kartracer.sim.RaceSettings;
import com.kartracer.sim.ResultRow;
import com.kartracer.util.Diag;
import com.kartracer.world.TrackData;
import com.kartracer.world.Tracks;

import java.io.IOException;
import java.util.List;

/** Glue between UI, renderer, race simulation and the LAN sessions. All public methods are called on the UI thread. */
public final class GameEngine implements GameRenderer.Host {
    public interface Listener {
        void onMenuSceneReady();
        void onLoading(boolean show, String msg);
        void onRaceReady(TrackData td, boolean multiplayer);
        void onRaceEnded(List<ResultRow> rows, boolean multiplayer, boolean isHost, int localSlot);
        void onLobby(Msg.Lobby lobby, int mySlot, boolean amHost);
        void onHosts(List<Discovery.HostInfo> hosts);
        void onNetEnded(String message);
        void onNotice(String text);
        void onStats(int fps, float ms);
        void onRenderScale(float scale);
        void onFatal(String message);
    }

    public static final int MODE_MENU = 0, MODE_OFFLINE = 1, MODE_HOST = 2, MODE_CLIENT = 3;
    private static final String[] AI_NAMES = {"Bolt", "Mango", "Zippy", "Coral", "Rusty", "Pixel", "Tiki"};

    private final Context app;
    private final Settings settings;
    private final Listener ui;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final PlatformHooks hooks;
    public GameRenderer renderer;

    private SceneData sceneData;
    private int sceneTrack = -1;
    private boolean sceneBusy;
    private Runnable afterScene;
    private int wantedTrack = -1;

    private HostServer host;
    private ClientLink client;
    private Discovery.Browser browser;
    private Race race;
    private boolean raceReported;
    private int mode = MODE_MENU;
    private int mySlot;
    private Msg.Lobby lastLobby;
    private final Runnable poller = new Runnable() {
        @Override public void run() {
            Race r = race;
            if (r != null && !raceReported && r.phase == Race.PH_ENDED && r.results != null) {
                raceReported = true;
                ui.onRaceEnded(r.results, mode >= MODE_HOST, mode == MODE_HOST, r.localSlot);
            }
            main.postDelayed(this, 250);
        }
    };

    public GameEngine(Context c, Settings s, Listener ui) {
        app = c.getApplicationContext();
        settings = s;
        this.ui = ui;
        hooks = new AndroidHooks(app);
        main.postDelayed(poller, 500);
    }

    public int mode() { return mode; }
    public Race race() { return race; }
    public TrackData trackData() { return sceneData == null ? null : sceneData.td; }

    // ------------------------------------------------------------------ scene loading

    /** Makes sure the scene for `track` is on the GPU, then runs `done` on the UI thread. */
    private void ensureScene(final int track, Runnable done) {
        if (sceneTrack == track && sceneData != null && renderer.hasScene()) {
            if (done != null) done.run();
            return;
        }
        afterScene = done;
        wantedTrack = track;
        if (sceneBusy) return;
        sceneBusy = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    long t0 = System.currentTimeMillis();
                    StaticAssets.get();
                    final SceneData sd = SceneData.build(Tracks.get(track));
                    Diag.log("Engine", "scene data built for track " + track + " in " + (System.currentTimeMillis() - t0) + " ms");
                    main.post(new Runnable() {
                        @Override public void run() {
                            sceneBusy = false;
                            if (wantedTrack != track) { // a different track was requested meanwhile
                                ensureScene(wantedTrack, afterScene);
                                return;
                            }
                            sceneData = sd;
                            sceneTrack = track;
                            renderer.post(new Runnable() { @Override public void run() { renderer.setScene(sd); } });
                        }
                    });
                } catch (final Throwable e) {
                    Diag.err("Engine", "scene build failed", e);
                    main.post(new Runnable() {
                        @Override public void run() { sceneBusy = false; ui.onLoading(false, ""); ui.onNetEnded("Could not load the track: " + e); }
                    });
                }
            }
        }, "scene-loader");
        t.start();
    }

    @Override
    public void onSceneReady() {
        main.post(new Runnable() {
            @Override public void run() {
                Runnable r = afterScene;
                afterScene = null;
                if (r != null) r.run(); else ui.onMenuSceneReady();
            }
        });
    }

    @Override
    public void onStats(final int fps, final float frameMs) {
        main.post(new Runnable() { @Override public void run() { ui.onStats(fps, frameMs); } });
    }

    @Override
    public void onError(final String message) {
        main.post(new Runnable() { @Override public void run() { ui.onFatal(message); } });
    }

    @Override
    public void suggestRenderScale(final float scale) {
        main.post(new Runnable() { @Override public void run() { ui.onRenderScale(scale); } });
    }

    public void bootstrap() { ensureScene(0, null); }

    // ------------------------------------------------------------------ offline race

    private RaceSettings quickSettings() {
        RaceSettings c = new RaceSettings();
        c.track = settings.track; c.laps = settings.laps; c.aiCount = settings.aiCount; c.difficulty = settings.difficulty; c.items = settings.items;
        return c;
    }

    public void startOffline() {
        final RaceSettings cfg = quickSettings();
        mode = MODE_OFFLINE;
        ui.onLoading(true, "Loading " + Tracks.get(cfg.track).name + "...");
        ensureScene(cfg.track, new Runnable() {
            @Override public void run() {
                Participant[] parts = new Participant[1 + cfg.aiCount];
                parts[0] = new Participant(0, false, settings.playerName, settings.kart, settings.paint, settings.driver, 0);
                for (int a = 0; a < cfg.aiCount; a++) {
                    parts[a + 1] = new Participant(a + 1, true, AI_NAMES[a % AI_NAMES.length], (settings.kart + 1 + a * 2) % 6,
                            (settings.paint + 1 + a) % 8, (a * 5 + 1) % 6, a % 3);
                }
                Race r = new Race(sceneData.td, cfg, parts, 0, Race.ROLE_OFFLINE, null, System.nanoTime());
                attachRace(r, false);
            }
        });
    }

    private void attachRace(final Race r, boolean multiplayer) {
        race = r;
        raceReported = false;
        renderer.post(new Runnable() { @Override public void run() { renderer.setRace(r); } });
        ui.onLoading(false, "");
        ui.onRaceReady(sceneData.td, multiplayer);
    }

    public void setPaused(final boolean p) {
        final Race r = race;
        if (r == null) return;
        renderer.post(new Runnable() { @Override public void run() { r.setPaused(p); } });
    }

    public void restartOffline() {
        if (mode == MODE_OFFLINE) startOffline();
    }

    /** Leaves the race / lobby and returns to the menu scene. */
    public void quitToMenu() {
        renderer.post(new Runnable() { @Override public void run() { renderer.clearRace(); } });
        race = null;
        teardownNet();
        mode = MODE_MENU;
        ui.onLoading(false, "");
    }

    // ------------------------------------------------------------------ hosting

    public String startHosting() {
        teardownNet();
        mode = MODE_HOST;
        mySlot = 0;
        host = new HostServer(hooks, new HostServer.Events() {
            @Override public void onLobby(final Msg.Lobby l) {
                main.post(new Runnable() { @Override public void run() { lastLobby = l; if (mode == MODE_HOST) ui.onLobby(l, 0, true); } });
            }
            @Override public void onGo(final int goMs) {
                renderer.post(new Runnable() { @Override public void run() { Race r = race; if (r != null) r.startAt(goMs); } });
            }
            @Override public void onNotice(final String t) {
                main.post(new Runnable() { @Override public void run() { ui.onNotice(t); } });
            }
        });
        try {
            host.start(settings.playerName, settings.kart, settings.paint, settings.driver);
            RaceSettings cfg = quickSettings();
            host.setSettings(cfg);
            Diag.log("Net", "hosting on tcp " + host.tcpPort + " udp " + host.udpPort);
            return null;
        } catch (IOException e) {
            Diag.err("Net", "host start failed", e);
            teardownNet();
            mode = MODE_MENU;
            return "Could not start the host: " + e.getMessage();
        }
    }

    public int hostPort() { return host == null ? 0 : host.tcpPort; }

    public void hostSetSettings(RaceSettings s) { if (host != null) host.setSettings(s); }
    public void hostProfileChanged() { if (host != null) host.updateHostProfile(settings.playerName, settings.kart, settings.paint, settings.driver); }
    public void hostKick(int id) { if (host != null) host.kick(id); }

    public void hostStartRace() {
        if (host == null) return;
        final Msg.Start s = host.startRace();
        if (s == null) return;
        ui.onLoading(true, "Loading " + Tracks.get(s.settings.track).name + "...");
        ensureScene(s.settings.track, new Runnable() {
            @Override public void run() {
                Race r = new Race(sceneData.td, s.settings, s.parts, 0, Race.ROLE_HOST, host, s.seed);
                attachRace(r, true);
                host.hostLoaded();
            }
        });
    }

    public void hostBackToLobby() {
        renderer.post(new Runnable() { @Override public void run() { renderer.clearRace(); } });
        race = null;
        if (host != null) host.backToLobby();
    }

    // ------------------------------------------------------------------ joining

    public void startBrowsing() {
        stopBrowsing();
        browser = new Discovery.Browser(hooks, new Discovery.Listener() {
            @Override public void onHosts(final List<Discovery.HostInfo> hosts) {
                main.post(new Runnable() { @Override public void run() { ui.onHosts(hosts); } });
            }
        });
        browser.start();
    }

    public void stopBrowsing() {
        if (browser != null) { browser.stop(); browser = null; }
    }

    public void join(String ip, int port) {
        teardownNet();
        stopBrowsing();
        mode = MODE_CLIENT;
        settings.lastIp = ip;
        client = new ClientLink(ip, port, settings.playerName, settings.kart, settings.paint, settings.driver, new ClientLink.Events() {
            @Override public void onConnected(final Msg.Welcome w) {
                main.post(new Runnable() {
                    @Override public void run() {
                        mySlot = w.slot;
                        Msg.Lobby l = new Msg.Lobby();
                        l.settings = w.settings; l.players = w.players;
                        lastLobby = l;
                        if (!w.rejoin && mode == MODE_CLIENT) ui.onLobby(l, w.slot, false);
                    }
                });
            }
            @Override public void onLobby(final Msg.Lobby l) {
                main.post(new Runnable() { @Override public void run() { lastLobby = l; if (race == null && mode == MODE_CLIENT) ui.onLobby(l, mySlot, false); } });
            }
            @Override public void onRejected(final String reason) {
                main.post(new Runnable() { @Override public void run() { endNet(reason); } });
            }
            @Override public void onStart(final Msg.Start s) {
                main.post(new Runnable() { @Override public void run() { clientStart(s); } });
            }
            @Override public void onGo(final int goMs) {
                renderer.post(new Runnable() { @Override public void run() { Race r = race; if (r != null) r.startAt(goMs); } });
            }
            @Override public void onKicked(final String reason) {
                main.post(new Runnable() { @Override public void run() { endNet(reason); } });
            }
            @Override public void onConnectionLost(final boolean retrying) {
                main.post(new Runnable() {
                    @Override public void run() {
                        if (retrying) ui.onNotice("Connection lost - trying to reconnect...");
                        else endNet("Connection to the host was lost");
                    }
                });
            }
            @Override public void onBack() {
                main.post(new Runnable() {
                    @Override public void run() {
                        renderer.post(new Runnable() { @Override public void run() { renderer.clearRace(); } });
                        race = null;
                        if (lastLobby != null) ui.onLobby(lastLobby, mySlot, false);
                    }
                });
            }
        });
        client.connect();
    }

    private void clientStart(final Msg.Start s) {
        if (client == null) return;
        int slot = -1;
        for (Participant p : s.parts) if (p.playerId == client.mySlot) slot = p.slot;
        if (slot < 0) { endNet("You are not part of this race"); return; }
        final int localSlot = slot;
        final boolean rejoin = race != null;
        ui.onLoading(true, "Loading " + Tracks.get(s.settings.track).name + "...");
        ensureScene(s.settings.track, new Runnable() {
            @Override public void run() {
                Race r = new Race(sceneData.td, s.settings, s.parts, localSlot, Race.ROLE_CLIENT, client, s.seed);
                if (rejoin) r.resyncNeeded = true;
                attachRace(r, true);
                client.sendLoaded();
            }
        });
    }

    public void clientUpdate(boolean ready) {
        if (client != null) client.sendUpdate(settings.kart, settings.paint, settings.driver, ready);
    }

    private void endNet(String message) {
        renderer.post(new Runnable() { @Override public void run() { renderer.clearRace(); } });
        race = null;
        teardownNet();
        mode = MODE_MENU;
        ui.onLoading(false, "");
        ui.onNetEnded(message);
    }

    private void teardownNet() {
        if (host != null) { host.stop(); host = null; }
        if (client != null) { client.leave(); client = null; }
        stopBrowsing();
    }

    public void onPause() { stopBrowsing(); }

    public void shutdown() {
        main.removeCallbacksAndMessages(null);
        teardownNet();
    }
}
