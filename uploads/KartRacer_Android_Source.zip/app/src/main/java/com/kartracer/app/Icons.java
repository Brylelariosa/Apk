package com.kartracer.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Clean vector icons drawn with Canvas paths (24 unit design grid). No emoji, no bitmaps. */
public final class Icons {
    private Icons() {}

    public static final int PLAY = 0, PEOPLE = 1, WIFI = 2, WRENCH = 3, GEAR = 4, BACK = 5, FLAG = 6, TROPHY = 7, CHECK = 8, CLOSE = 9,
            PLUS = 10, MINUS = 11, ARROW_L = 12, ARROW_R = 13, PAUSE = 14, REFRESH = 15, COPY = 16, SHARE = 17, BOLT = 18, ROCKET = 19,
            SHIELD = 20, DROP = 21, COCONUT = 22, STEERING = 23, PEDAL = 24, BRAKE = 25, DRIFT = 26, BOX = 27, CROWN = 28, SPEED = 29,
            INFO = 30, BUG = 31, SAVE = 32, HOME = 33, CAMERA = 34, SLIDERS = 35, USER = 36, EDIT = 37;

    private static final Path P = new Path(), Q = new Path();
    private static final RectF R = new RectF();
    private static float cx, cy, s;

    private static float X(float u) { return cx + (u - 12f) * s; }
    private static float Y(float v) { return cy + (v - 12f) * s; }
    private static void m(Path p, float u, float v) { p.moveTo(X(u), Y(v)); }
    private static void l(Path p, float u, float v) { p.lineTo(X(u), Y(v)); }
    private static void rect(float a, float b, float c, float d) { R.set(X(a), Y(b), X(c), Y(d)); }

    private static void stroke(Paint p, float w) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * s); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); }
    private static void fill(Paint p) { p.setStyle(Paint.Style.FILL); }

    /** Draws icon centered at (centerX, centerY) with half size r using the paint's color. Paint style is restored to FILL. */
    public static void draw(Canvas c, int icon, float centerX, float centerY, float r, Paint p) {
        cx = centerX; cy = centerY; s = r / 12f;
        float oldW = p.getStrokeWidth();
        Paint.Style oldStyle = p.getStyle();
        P.reset(); Q.reset();
        switch (icon) {
            case PLAY: fill(p); m(P, 7, 4); l(P, 20, 12); l(P, 7, 20); P.close(); c.drawPath(P, p); break;
            case PEOPLE:
                fill(p);
                c.drawCircle(X(9), Y(8.5f), 3.3f * s, p); c.drawCircle(X(17), Y(9.5f), 2.7f * s, p);
                rect(2.5f, 13, 15.5f, 27); c.drawArc(R, 180, 180, true, p);
                rect(13, 14, 21.5f, 25); c.drawArc(R, 180, 180, true, p);
                break;
            case WIFI:
                stroke(p, 2.2f);
                for (int i = 0; i < 3; i++) { float rr = 5f + i * 4.6f; rect(12 - rr, 19 - rr, 12 + rr, 19 + rr); c.drawArc(R, 225, 90, false, p); }
                fill(p); c.drawCircle(X(12), Y(19), 1.9f * s, p);
                break;
            case WRENCH:
                c.save(); c.rotate(-45f, cx, cy);
                fill(p);
                R.set(X(10.4f), Y(9), X(13.6f), Y(22)); c.drawRoundRect(R, 1.5f * s, 1.5f * s, p);
                P.addCircle(X(12), Y(6.5f), 5.2f * s, Path.Direction.CW);
                R.set(X(10.2f), Y(0), X(13.8f), Y(5.5f)); Q.addRect(R, Path.Direction.CW);
                P.op(Q, Path.Op.DIFFERENCE);
                c.drawPath(P, p);
                c.restore();
                break;
            case GEAR:
                fill(p);
                P.addCircle(cx, cy, 6.6f * s, Path.Direction.CW);
                for (int i = 0; i < 8; i++) {
                    c.save(); c.rotate(i * 45f, cx, cy);
                    R.set(X(10), Y(2), X(14), Y(6)); c.drawRoundRect(R, 0.8f * s, 0.8f * s, p);
                    c.restore();
                }
                Q.addCircle(cx, cy, 3.2f * s, Path.Direction.CW);
                P.op(Q, Path.Op.DIFFERENCE);
                c.drawPath(P, p);
                break;
            case BACK: stroke(p, 2.6f); m(P, 15, 5); l(P, 8, 12); l(P, 15, 19); c.drawPath(P, p); break;
            case FLAG:
                fill(p); R.set(X(5), Y(3), X(7.2f), Y(21)); c.drawRect(R, p);
                m(P, 7.2f, 4); l(P, 19.5f, 4); l(P, 15.5f, 8.5f); l(P, 19.5f, 13); l(P, 7.2f, 13); P.close(); c.drawPath(P, p);
                break;
            case TROPHY:
                fill(p);
                m(P, 7, 3.5f); l(P, 17, 3.5f); l(P, 15.5f, 12); l(P, 8.5f, 12); P.close(); c.drawPath(P, p);
                R.set(X(10.8f), Y(12), X(13.2f), Y(17)); c.drawRect(R, p);
                R.set(X(7.5f), Y(17), X(16.5f), Y(20.5f)); c.drawRoundRect(R, s, s, p);
                stroke(p, 1.8f);
                rect(2.5f, 4.5f, 9, 11); c.drawArc(R, 90, 180, false, p);
                rect(15, 4.5f, 21.5f, 11); c.drawArc(R, 270, 180, false, p);
                break;
            case CHECK: stroke(p, 3f); m(P, 5, 12.5f); l(P, 10, 17.5f); l(P, 19, 7); c.drawPath(P, p); break;
            case CLOSE: stroke(p, 2.8f); m(P, 6, 6); l(P, 18, 18); m(P, 18, 6); l(P, 6, 18); c.drawPath(P, p); break;
            case PLUS: stroke(p, 3f); m(P, 12, 5); l(P, 12, 19); m(P, 5, 12); l(P, 19, 12); c.drawPath(P, p); break;
            case MINUS: stroke(p, 3f); m(P, 5, 12); l(P, 19, 12); c.drawPath(P, p); break;
            case ARROW_L: fill(p); m(P, 17, 4); l(P, 6, 12); l(P, 17, 20); l(P, 13.5f, 12); P.close(); c.drawPath(P, p); break;
            case ARROW_R: fill(p); m(P, 7, 4); l(P, 18, 12); l(P, 7, 20); l(P, 10.5f, 12); P.close(); c.drawPath(P, p); break;
            case PAUSE:
                fill(p); R.set(X(6), Y(4.5f), X(10), Y(19.5f)); c.drawRoundRect(R, s, s, p);
                R.set(X(14), Y(4.5f), X(18), Y(19.5f)); c.drawRoundRect(R, s, s, p);
                break;
            case REFRESH:
                stroke(p, 2.4f); rect(4.5f, 4.5f, 19.5f, 19.5f); c.drawArc(R, -50, 290, false, p);
                fill(p); m(P, 14, 2.5f); l(P, 21, 6); l(P, 15, 10); P.close(); c.drawPath(P, p);
                break;
            case COPY:
                stroke(p, 2f);
                R.set(X(8), Y(8), X(19), Y(20)); c.drawRoundRect(R, 2 * s, 2 * s, p);
                m(P, 15.5f, 5.5f); l(P, 15.5f, 4.5f); l(P, 5.5f, 4.5f); l(P, 5.5f, 15.5f); l(P, 6.5f, 15.5f); c.drawPath(P, p);
                break;
            case SHARE:
                fill(p); c.drawCircle(X(6), Y(12), 2.8f * s, p); c.drawCircle(X(17.5f), Y(5.5f), 2.8f * s, p); c.drawCircle(X(17.5f), Y(18.5f), 2.8f * s, p);
                stroke(p, 1.8f); m(P, 6, 12); l(P, 17.5f, 5.5f); m(P, 6, 12); l(P, 17.5f, 18.5f); c.drawPath(P, p);
                break;
            case BOLT:
                fill(p); m(P, 13.5f, 1.5f); l(P, 5, 13.5f); l(P, 11, 13.5f); l(P, 9.5f, 22.5f); l(P, 19, 9.5f); l(P, 13, 9.5f); P.close(); c.drawPath(P, p);
                break;
            case ROCKET:
                fill(p);
                m(P, 12, 1.5f); P.quadTo(17.5f, 6, 15.5f, 16.5f); l(P, 8.5f, 16.5f); P.quadTo(6.5f, 6, 12, 1.5f); P.close(); c.drawPath(P, p);
                Q.reset(); m(Q, 8.8f, 12); l(Q, 4.5f, 18.5f); l(Q, 8.5f, 16.5f); Q.close(); c.drawPath(Q, p);
                Q.reset(); m(Q, 15.2f, 12); l(Q, 19.5f, 18.5f); l(Q, 15.5f, 16.5f); Q.close(); c.drawPath(Q, p);
                Q.reset(); m(Q, 10, 17.5f); l(Q, 12, 23); l(Q, 14, 17.5f); Q.close(); c.drawPath(Q, p);
                break;
            case SHIELD:
                fill(p);
                m(P, 12, 1.8f); l(P, 20, 5); l(P, 20, 11.5f); P.quadTo(20, 18.5f, 12, 22.5f); P.quadTo(4, 18.5f, 4, 11.5f); l(P, 4, 5); P.close();
                c.drawPath(P, p);
                break;
            case DROP:
                fill(p);
                m(P, 12, 2.5f); P.cubicTo(17.5f, 9, 19.5f, 12, 19.5f, 15.5f); rect(4.5f, 8.5f, 19.5f, 22.5f); P.arcTo(R, 0, 180); P.cubicTo(4.5f, 12, 6.5f, 9, 12, 2.5f); P.close();
                c.drawPath(P, p);
                break;
            case COCONUT:
                fill(p); c.drawCircle(cx, Y(12.5f), 8.5f * s, p);
                break;
            case STEERING:
                stroke(p, 2.6f); c.drawCircle(cx, cy, 8.5f * s, p);
                fill(p); c.drawCircle(cx, cy, 2.4f * s, p);
                stroke(p, 2.4f); m(P, 3.5f, 12); l(P, 9.6f, 12); m(P, 14.4f, 12); l(P, 20.5f, 12); m(P, 12, 14.4f); l(P, 12, 20.5f); c.drawPath(P, p);
                break;
            case PEDAL:
                fill(p); R.set(X(7), Y(3), X(17), Y(21)); c.drawRoundRect(R, 2.5f * s, 2.5f * s, p);
                break;
            case BRAKE:
                fill(p); R.set(X(4), Y(7), X(20), Y(17)); c.drawRoundRect(R, 2.5f * s, 2.5f * s, p);
                break;
            case DRIFT:
                stroke(p, 2.8f);
                m(P, 5, 20); P.cubicTo(5, 10, 9, 8, 17, 8); c.drawPath(P, p);
                fill(p); P.reset(); m(P, 15, 3); l(P, 21.5f, 8); l(P, 15, 13); P.close(); c.drawPath(P, p);
                break;
            case BOX:
                stroke(p, 2.2f);
                m(P, 12, 2.5f); l(P, 20, 7); l(P, 20, 17); l(P, 12, 21.5f); l(P, 4, 17); l(P, 4, 7); P.close();
                m(P, 4, 7); l(P, 12, 11.5f); l(P, 20, 7); m(P, 12, 11.5f); l(P, 12, 21.5f);
                c.drawPath(P, p);
                break;
            case CROWN:
                fill(p); m(P, 3, 19); l(P, 3, 7.5f); l(P, 8, 12.5f); l(P, 12, 4.5f); l(P, 16, 12.5f); l(P, 21, 7.5f); l(P, 21, 19); P.close(); c.drawPath(P, p);
                break;
            case SPEED:
                stroke(p, 2.4f); rect(3, 5, 21, 23); c.drawArc(R, 180, 180, false, p);
                m(P, 12, 14); l(P, 17, 8.5f); c.drawPath(P, p);
                fill(p); c.drawCircle(X(12), Y(14), 1.9f * s, p);
                break;
            case INFO:
                stroke(p, 2.2f); c.drawCircle(cx, cy, 9f * s, p);
                fill(p); c.drawCircle(X(12), Y(7.6f), 1.4f * s, p); R.set(X(10.9f), Y(10.5f), X(13.1f), Y(17.5f)); c.drawRoundRect(R, s, s, p);
                break;
            case BUG:
                fill(p); R.set(X(7), Y(7.5f), X(17), Y(20)); c.drawRoundRect(R, 5 * s, 5 * s, p);
                c.drawCircle(X(12), Y(6), 2.8f * s, p);
                stroke(p, 1.8f); m(P, 7, 11); l(P, 3, 9); m(P, 17, 11); l(P, 21, 9); m(P, 7, 15); l(P, 3, 15); m(P, 17, 15); l(P, 21, 15); m(P, 8, 19); l(P, 4.5f, 21.5f); m(P, 16, 19); l(P, 19.5f, 21.5f); c.drawPath(P, p);
                break;
            case SAVE:
                fill(p); m(P, 4, 4); l(P, 17, 4); l(P, 20, 7); l(P, 20, 20); l(P, 4, 20); P.close();
                R.set(X(7), Y(4), X(15), Y(9)); Q.addRect(R, Path.Direction.CW);
                R.set(X(7), Y(13), X(17), Y(20)); Q.addRect(R, Path.Direction.CW);
                P.op(Q, Path.Op.DIFFERENCE); c.drawPath(P, p);
                break;
            case HOME:
                fill(p); m(P, 12, 3); l(P, 22, 12); l(P, 19, 12); l(P, 19, 21); l(P, 14, 21); l(P, 14, 15); l(P, 10, 15); l(P, 10, 21); l(P, 5, 21); l(P, 5, 12); l(P, 2, 12); P.close(); c.drawPath(P, p);
                break;
            case CAMERA:
                fill(p);
                R.set(X(2.5f), Y(7), X(21.5f), Y(20)); P.addRoundRect(R, 3 * s, 3 * s, Path.Direction.CW);
                R.set(X(8), Y(4), X(16), Y(8.5f)); P.addRoundRect(R, s, s, Path.Direction.CW);
                Q.addCircle(X(12), Y(13.5f), 3.6f * s, Path.Direction.CW);
                P.op(Q, Path.Op.DIFFERENCE);
                c.drawPath(P, p);
                break;
            case SLIDERS:
                stroke(p, 2f); m(P, 4, 6); l(P, 20, 6); m(P, 4, 12); l(P, 20, 12); m(P, 4, 18); l(P, 20, 18); c.drawPath(P, p);
                fill(p); c.drawCircle(X(9), Y(6), 2.6f * s, p); c.drawCircle(X(16), Y(12), 2.6f * s, p); c.drawCircle(X(8), Y(18), 2.6f * s, p);
                break;
            case USER:
                fill(p); c.drawCircle(X(12), Y(8), 4.2f * s, p); rect(4, 14, 20, 30); c.drawArc(R, 180, 180, true, p);
                break;
            case EDIT:
                fill(p); m(P, 4, 20); l(P, 4, 15.5f); l(P, 15.5f, 4); l(P, 20, 8.5f); l(P, 8.5f, 20); P.close(); c.drawPath(P, p);
                break;
            default: break;
        }
        p.setStyle(oldStyle);
        p.setStrokeWidth(oldW);
    }
}
