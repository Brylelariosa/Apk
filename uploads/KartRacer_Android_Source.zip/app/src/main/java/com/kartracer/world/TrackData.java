package com.kartracer.world;

import com.kartracer.util.MathX;
import com.kartracer.util.Rng;

/** Fully generated track: roads, terrain grid, objects, scenery and queries. Pure Java, deterministic. */
public final class TrackData {
    public static final int CHUNK = 16;

    public static final class Ramp { public float x, z, yaw, len, wid, h; }
    public static final class Pad { public float x, y, z, yaw, len, wid; }
    public static final class Crate { public float x, y, z; }
    public static final class Haz { public int type; public float x0, z0, x1, z1, y, period, phase, radius; }

    public final TrackDef def;
    public Road main;
    public Road[] roads;
    public float length;

    // terrain grid
    public float gx0, gz0, cell;
    public int gnx, gnz;
    public float[] base, sdf, roadY;
    public byte[] surf, rsurf;
    public float waterLevel;
    public float minX, maxX, minZ, maxZ;
    private byte[] occ;

    // objects
    public Ramp[] ramps = new Ramp[0];
    public Pad[] pads = new Pad[0];
    public Crate[] crates = new Crate[0];
    public Haz[] hazards = new Haz[0];
    public int nBoxes;
    public float[] boxX, boxY, boxZ;

    // scenery
    public int scN;
    public byte[] scType = new byte[1024];
    public float[] scX = new float[1024], scY = new float[1024], scZ = new float[1024], scYaw = new float[1024], scScale = new float[1024];

    // colliders
    public int colN;
    public float[] colX = new float[512], colZ = new float[512], colR = new float[512];
    private float maxColR;
    private int hcx, hcz;
    private int[] hStart, hItems;
    private static final float HCELL = 10f;

    // start grid (8 slots)
    public final float[] gridX = new float[8], gridY = new float[8], gridZ = new float[8], gridYaw = new float[8];

    private float[] straight;
    private float px, pz;

    private TrackData(TrackDef def) { this.def = def; }

    public static TrackData build(TrackDef def) {
        TrackData t = new TrackData(def);
        t.generate();
        return t;
    }

    private void generate() {
        buildRoads();
        buildGrid();
        rasterRoads();
        buildHeights();
        buildSurfaces();
        placeObjects();
        placeScenery();
        buildColliders();
        buildStartGrid();
    }

    // ------------------------------------------------------------------ roads

    private void buildRoads() {
        main = Road.fromControl(def.controlPoints(), true, 2.5f, def.roadSurface);
        int n = main.n;
        float best = 1e9f;
        int bi = 0;
        for (int i = 0; i < n; i += 2) {
            float sum = 0f;
            for (int k = -24; k <= 24; k++) sum += Math.abs(main.curv[main.wrap(i + k)]);
            if (sum < best) { best = sum; bi = i; }
        }
        main.rotate(bi);
        length = main.length;
        straight = new float[n];
        for (int i = 0; i < n; i++) {
            float sum = 0f;
            for (int k = -8; k <= 8; k++) sum += Math.abs(main.curv[main.wrap(i + k)]);
            straight[i] = sum;
        }
        int ns = def.shortcuts.length;
        roads = new Road[1 + ns];
        roads[0] = main;
        for (int k = 0; k < ns; k++) {
            float[] sc = def.shortcuts[k];
            int i0 = main.wrap(Math.round(sc[0] * n)), i1 = main.wrap(Math.round(sc[1] * n));
            if (sc[0] < 0f) { // auto: best corner cut for the requested span
                int win = Math.round(sc[1] * n);
                i0 = autoShortcut(win);
                i1 = i0 + win;
            }
            float cx = main.x[i1] - main.x[i0], cz = main.z[i1] - main.z[i0];
            float cl = MathX.len2(cx, cz);
            cx /= cl; cz /= cl;
            float[] p0 = edgePoint(i0, cx, cz), p1 = edgePoint(i1, -cx, -cz);
            float mx = (p0[0] + p1[0]) * 0.5f - cz * sc[3], mz = (p0[1] + p1[1]) * 0.5f + cx * sc[3];
            float[] q0 = {main.x[main.wrap(i0 - 8)], main.z[main.wrap(i0 - 8)], main.y[i0], sc[2]};
            float[] q1 = {main.x[main.wrap(i1 + 8)], main.z[main.wrap(i1 + 8)], main.y[i1], sc[2]};
            float[] m = {mx, mz, (main.y[i0] + main.y[i1]) * 0.5f, sc[2]};
            p0[3] = sc[2]; p1[3] = sc[2];
            roads[1 + k] = Road.fromControl(new float[][]{q0, p0, m, p1, q1}, false, 2.5f, Surf.DIRT, true);
        }
    }

    /** Finds the start sample where a chord of `win` samples saves the most distance and stays clear of the road. */
    private int autoShortcut(int win) {
        int n = main.n;
        int best = (int) (0.2f * n);
        float bestSave = -1f;
        int lo = (int) (0.10f * n), hi = n - win - (int) (0.07f * n);
        for (int i = lo; i < hi; i += 3) {
            int j = i + win;
            float cx = main.x[j] - main.x[i], cz = main.z[j] - main.z[i];
            float save = (main.s[j] - main.s[i]) - MathX.len2(cx, cz);
            if (save <= bestSave) continue;
            boolean ok = true;
            for (int q = 1; q < 8 && ok; q++) {
                float qx = main.x[i] + cx * q / 8f, qz = main.z[i] + cz * q / 8f;
                for (int m = 0; m < n; m += 2) {
                    if (m >= i - 14 && m <= j + 14) continue;
                    if (MathX.len2(qx - main.x[m], qz - main.z[m]) < 26f) { ok = false; break; }
                }
            }
            if (ok) { bestSave = save; best = i; }
        }
        return best;
    }

    /** Point on the road edge at sample i, on the side the given direction points to. */
    private float[] edgePoint(int i, float dx, float dz) {
        float rx = -main.tz[i], rz = main.tx[i];
        float side = (dx * rx + dz * rz) >= 0f ? 1f : -1f;
        float off = main.w[i] * 0.5f * 0.55f * side;
        return new float[]{main.x[i] + rx * off, main.z[i] + rz * off, main.y[i], 0f};
    }

    // ------------------------------------------------------------------ grid

    private void buildGrid() {
        float x0 = 1e9f, x1 = -1e9f, z0 = 1e9f, z1 = -1e9f;
        for (Road r : roads) {
            for (int i = 0; i < r.n; i++) {
                x0 = Math.min(x0, r.x[i]); x1 = Math.max(x1, r.x[i]);
                z0 = Math.min(z0, r.z[i]); z1 = Math.max(z1, r.z[i]);
            }
        }
        cell = def.cell;
        float m = def.margin;
        int cxn = (int) Math.ceil((x1 - x0 + 2 * m) / (cell * CHUNK));
        int czn = (int) Math.ceil((z1 - z0 + 2 * m) / (cell * CHUNK));
        gnx = cxn * CHUNK + 1;
        gnz = czn * CHUNK + 1;
        gx0 = (x0 + x1) * 0.5f - (gnx - 1) * cell * 0.5f;
        gz0 = (z0 + z1) * 0.5f - (gnz - 1) * cell * 0.5f;
        minX = gx0 + 8f; maxX = gx0 + (gnx - 1) * cell - 8f;
        minZ = gz0 + 8f; maxZ = gz0 + (gnz - 1) * cell - 8f;
        waterLevel = def.waterLevel;
    }

    private void rasterRoads() {
        int n = gnx * gnz;
        sdf = new float[n];
        roadY = new float[n];
        rsurf = new byte[n];
        java.util.Arrays.fill(sdf, 1e9f);
        float infl = def.shoulder + def.blend + 2f;
        for (Road r : roads) {
            int segs = r.closed ? r.n : r.n - 1;
            for (int i = 0; i < segs; i++) {
                int a = i, b = (i + 1) % r.n;
                float ax = r.x[a], az = r.z[a], bx = r.x[b], bz = r.z[b];
                float dx = bx - ax, dz = bz - az;
                float l2 = dx * dx + dz * dz;
                float rad = Math.max(r.w[a], r.w[b]) * 0.5f + infl;
                int ix0 = Math.max(0, (int) Math.floor((Math.min(ax, bx) - rad - gx0) / cell));
                int ix1 = Math.min(gnx - 1, (int) Math.ceil((Math.max(ax, bx) + rad - gx0) / cell));
                int iz0 = Math.max(0, (int) Math.floor((Math.min(az, bz) - rad - gz0) / cell));
                int iz1 = Math.min(gnz - 1, (int) Math.ceil((Math.max(az, bz) + rad - gz0) / cell));
                for (int gz = iz0; gz <= iz1; gz++) {
                    float pz = gz0 + gz * cell;
                    for (int gx = ix0; gx <= ix1; gx++) {
                        float px = gx0 + gx * cell;
                        float t = l2 > 1e-6f ? MathX.clamp(((px - ax) * dx + (pz - az) * dz) / l2, 0f, 1f) : 0f;
                        float qx = ax + dx * t - px, qz = az + dz * t - pz;
                        float d = (float) Math.sqrt(qx * qx + qz * qz);
                        float hw = MathX.lerp(r.w[a], r.w[b], t) * 0.5f;
                        float sd = d - hw;
                        int idx = gz * gnx + gx;
                        if (sd < sdf[idx]) {
                            sdf[idx] = sd;
                            roadY[idx] = MathX.lerp(r.y[a], r.y[b], t) + (r != main ? 0.02f : 0f);
                            rsurf[idx] = (byte) r.surface;
                        }
                    }
                }
            }
        }
    }

    private void buildHeights() {
        int n = gnx * gnz;
        base = new float[n];
        for (int gz = 0; gz < gnz; gz++) {
            float z = gz0 + gz * cell;
            for (int gx = 0; gx < gnx; gx++) {
                float x = gx0 + gx * cell;
                int idx = gz * gnx + gx;
                float rho = Terrain.rho(def, x, z);
                float nh = Terrain.height(def, x, z, rho);
                float d = sdf[idx];
                float wgt = 1f - MathX.smooth(def.shoulder, def.shoulder + def.blend, d);
                float h = d < 1e8f ? MathX.lerp(nh, roadY[idx], wgt) : nh;
                base[idx] = Terrain.carve(def, x, z, rho, d, h);
            }
        }
    }

    private void buildSurfaces() {
        surf = new byte[gnx * gnz];
        for (int gz = 0; gz < gnz; gz++) {
            for (int gx = 0; gx < gnx; gx++) {
                int idx = gz * gnx + gx;
                float x = gx0 + gx * cell, z = gz0 + gz * cell;
                float ny = normalYAtVertex(gx, gz);
                surf[idx] = (byte) Terrain.surface(def, x, z, base[idx], ny, sdf[idx]);
            }
        }
        occ = new byte[gnx * gnz];
    }

    public float normalYAtVertex(int gx, int gz) {
        int x0 = Math.max(0, gx - 1), x1 = Math.min(gnx - 1, gx + 1);
        int z0 = Math.max(0, gz - 1), z1 = Math.min(gnz - 1, gz + 1);
        float dhdx = (base[gz * gnx + x1] - base[gz * gnx + x0]) / ((x1 - x0) * cell);
        float dhdz = (base[z1 * gnx + gx] - base[z0 * gnx + gx]) / ((z1 - z0) * cell);
        return 1f / (float) Math.sqrt(1f + dhdx * dhdx + dhdz * dhdz);
    }

    // ------------------------------------------------------------------ queries

    public float terrainHeight(float x, float z) {
        float fx = (x - gx0) / cell, fz = (z - gz0) / cell;
        fx = MathX.clamp(fx, 0f, gnx - 1.001f);
        fz = MathX.clamp(fz, 0f, gnz - 1.001f);
        int ix = (int) fx, iz = (int) fz;
        float u = fx - ix, v = fz - iz;
        int i = iz * gnx + ix;
        float ha = base[i], hc = base[i + 1], hb = base[i + gnx], hd = base[i + gnx + 1];
        if (u + v <= 1f) return ha + u * (hc - ha) + v * (hb - ha);
        return hd + (1f - u) * (hb - hd) + (1f - v) * (hc - hd);
    }

    /** Ground height including ramps (what karts drive on). */
    public float groundHeight(float x, float z) {
        float h = terrainHeight(x, z);
        for (int k = 0; k < ramps.length; k++) {
            Ramp r = ramps[k];
            float dx = x - r.x, dz = z - r.z;
            if (dx * dx + dz * dz > (r.len + r.wid) * (r.len + r.wid)) continue;
            float s = (float) Math.sin(r.yaw), c = (float) Math.cos(r.yaw);
            float u = dx * s - dz * c, v = dx * c + dz * s;
            if (u >= 0f && u <= r.len && Math.abs(v) <= r.wid * 0.5f) h += r.h * (u / r.len);
        }
        return h;
    }

    public void normalAt(float x, float z, float[] out) {
        float e = 1.2f;
        float hx = groundHeight(x + e, z) - groundHeight(x - e, z);
        float hz = groundHeight(x, z + e) - groundHeight(x, z - e);
        float nx = -hx / (2f * e), nz = -hz / (2f * e);
        float l = (float) Math.sqrt(nx * nx + 1f + nz * nz);
        out[0] = nx / l; out[1] = 1f / l; out[2] = nz / l;
    }

    public float sdfAt(float x, float z) {
        float fx = (x - gx0) / cell, fz = (z - gz0) / cell;
        fx = MathX.clamp(fx, 0f, gnx - 1.001f);
        fz = MathX.clamp(fz, 0f, gnz - 1.001f);
        int ix = (int) fx, iz = (int) fz;
        float u = fx - ix, v = fz - iz;
        int i = iz * gnx + ix;
        float a = sdf[i], b = sdf[i + 1], c = sdf[i + gnx], d = sdf[i + gnx + 1];
        return MathX.lerp(MathX.lerp(a, b, u), MathX.lerp(c, d, u), v);
    }

    public int surfaceAt(float x, float z, float groundH) {
        if (groundH < waterLevel - 0.04f) return def.lava ? Surf.LAVA : Surf.WATER;
        int ix = MathX.clamp(Math.round((x - gx0) / cell), 0, gnx - 1);
        int iz = MathX.clamp(Math.round((z - gz0) / cell), 0, gnz - 1);
        int idx = iz * gnx + ix;
        if (sdfAt(x, z) < 0f) return rsurf[idx];
        return surf[idx];
    }

    public boolean inBounds(float x, float z) { return x > minX && x < maxX && z > minZ && z < maxZ; }

    /** Interpolated main-road point at arc length s: out = {x, z, y, tx, tz, w}. */
    public void mainPointAt(float s, float[] out) {
        int n = main.n;
        s = s - length * (float) Math.floor(s / length);
        int i = Math.min(n - 1, (int) (s / length * n));
        while (i < n - 1 && main.s[i + 1] <= s) i++;
        while (i > 0 && main.s[i] > s) i--;
        int j = (i + 1) % n;
        float s1 = j == 0 ? length : main.s[j];
        float t = MathX.clamp((s - main.s[i]) / Math.max(1e-4f, s1 - main.s[i]), 0f, 1f);
        out[0] = MathX.lerp(main.x[i], main.x[j], t);
        out[1] = MathX.lerp(main.z[i], main.z[j], t);
        out[2] = MathX.lerp(main.y[i], main.y[j], t);
        float tx = MathX.lerp(main.tx[i], main.tx[j], t), tz = MathX.lerp(main.tz[i], main.tz[j], t);
        float l = MathX.len2(tx, tz);
        out[3] = tx / l; out[4] = tz / l;
        out[5] = MathX.lerp(main.w[i], main.w[j], t);
    }

    /** Colliders within r of (x,z); returns indices count written to out. */
    public int queryColliders(float x, float z, float r, int[] out) {
        if (colN == 0) return 0;
        float rr = r + maxColR;
        int x0 = MathX.clamp((int) ((x - rr - gx0) / HCELL), 0, hcx - 1), x1 = MathX.clamp((int) ((x + rr - gx0) / HCELL), 0, hcx - 1);
        int z0 = MathX.clamp((int) ((z - rr - gz0) / HCELL), 0, hcz - 1), z1 = MathX.clamp((int) ((z + rr - gz0) / HCELL), 0, hcz - 1);
        int c = 0;
        for (int cz = z0; cz <= z1; cz++) {
            for (int cx = x0; cx <= x1; cx++) {
                int cell = cz * hcx + cx;
                for (int k = hStart[cell]; k < hStart[cell + 1]; k++) {
                    int id = hItems[k];
                    float dx = colX[id] - x, dz = colZ[id] - z, s = colR[id] + r;
                    if (dx * dx + dz * dz < s * s && c < out.length) out[c++] = id;
                }
            }
        }
        return c;
    }

    // ------------------------------------------------------------------ objects

    private int snap(float frac, float range) {
        int n = main.n;
        int c = main.wrap(Math.round(frac * n));
        int win = (int) (range * n);
        int best = c;
        float bv = 1e9f;
        for (int k = -win; k <= win; k++) {
            int i = main.wrap(c + k);
            if (straight[i] < bv) { bv = straight[i]; best = i; }
        }
        return best;
    }

    private void placeObjects() {
        int n = main.n;
        // ramps
        ramps = new Ramp[def.ramps.length];
        for (int k = 0; k < ramps.length; k++) {
            int i = snap(def.ramps[k], 0.03f);
            Ramp r = new Ramp();
            r.x = main.x[i]; r.z = main.z[i];
            r.yaw = (float) Math.atan2(main.tx[i], -main.tz[i]);
            r.len = 8f; r.wid = main.w[i] * 0.62f; r.h = 2.5f;
            ramps[k] = r;
        }
        // boost pads
        pads = new Pad[def.pads.length];
        for (int k = 0; k < pads.length; k++) {
            int i = snap(def.pads[k], 0.03f);
            Pad p = new Pad();
            float side = (k % 2 == 0) ? 1f : -1f;
            float off = main.w[i] * 0.2f * side;
            p.x = main.x[i] + (-main.tz[i]) * off; p.z = main.z[i] + main.tx[i] * off;
            p.y = groundHeight(p.x, p.z);
            p.yaw = (float) Math.atan2(main.tx[i], -main.tz[i]);
            p.len = 9f; p.wid = main.w[i] * 0.34f;
            pads[k] = p;
        }
        // crates: clusters of three at the road edge
        crates = new Crate[def.crates.length * 3];
        for (int k = 0; k < def.crates.length; k++) {
            int i0 = main.wrap(Math.round(def.crates[k] * n));
            float side = (k % 2 == 0) ? 1f : -1f;
            for (int j = 0; j < 3; j++) {
                int i = main.wrap(i0 + j * 2);
                float off = (main.w[i] * 0.5f - 1.6f - (j == 1 ? 1.4f : 0f)) * side;
                Crate c = new Crate();
                c.x = main.x[i] + (-main.tz[i]) * off; c.z = main.z[i] + main.tx[i] * off;
                c.y = groundHeight(c.x, c.z);
                crates[k * 3 + j] = c;
            }
        }
        // hazards
        hazards = new Haz[def.hazards.length];
        for (int k = 0; k < hazards.length; k++) {
            float[] h = def.hazards[k];
            int i = snap(h[1], 0.02f);
            float rx = -main.tz[i], rz = main.tx[i];
            Haz z = new Haz();
            z.type = (int) h[0];
            z.x0 = main.x[i] + rx * h[2]; z.z0 = main.z[i] + rz * h[2];
            z.x1 = main.x[i] + rx * h[3]; z.z1 = main.z[i] + rz * h[3];
            z.y = main.y[i]; z.period = h[4]; z.phase = h[5];
            z.radius = z.type == 0 ? 1.7f : 2.6f;
            hazards[k] = z;
        }
        // item boxes: rows of three
        nBoxes = def.boxRows.length * 3;
        boxX = new float[nBoxes]; boxY = new float[nBoxes]; boxZ = new float[nBoxes];
        for (int k = 0; k < def.boxRows.length; k++) {
            int i = snap(def.boxRows[k], 0.02f);
            for (int j = 0; j < 3; j++) {
                float off = (j - 1) * main.w[i] * 0.28f;
                int id = k * 3 + j;
                boxX[id] = main.x[i] + (-main.tz[i]) * off;
                boxZ[id] = main.z[i] + main.tx[i] * off;
                boxY[id] = groundHeight(boxX[id], boxZ[id]) + 1.1f;
            }
        }
    }

    // ------------------------------------------------------------------ scenery

    private void addScenery(int type, float x, float z, float yaw, float scale) {
        if (scN == scType.length) {
            int c = scN * 2;
            scType = java.util.Arrays.copyOf(scType, c);
            scX = java.util.Arrays.copyOf(scX, c); scY = java.util.Arrays.copyOf(scY, c); scZ = java.util.Arrays.copyOf(scZ, c);
            scYaw = java.util.Arrays.copyOf(scYaw, c); scScale = java.util.Arrays.copyOf(scScale, c);
        }
        scType[scN] = (byte) type;
        scX[scN] = x; scY[scN] = terrainHeight(x, z) - 0.05f; scZ[scN] = z;
        scYaw[scN] = yaw; scScale[scN] = scale;
        scN++;
        float cr = Props.COLL[type] * scale;
        if (cr > 0.15f && !(type == Props.ROCK && scale < 0.8f)) addCollider(x, z, cr);
    }

    private void addCollider(float x, float z, float r) {
        if (colN == colX.length) {
            int c = colN * 2;
            colX = java.util.Arrays.copyOf(colX, c); colZ = java.util.Arrays.copyOf(colZ, c); colR = java.util.Arrays.copyOf(colR, c);
        }
        colX[colN] = x; colZ[colN] = z; colR[colN] = r;
        colN++;
        maxColR = Math.max(maxColR, r);
    }

    private boolean near(Rng r, float lo, float hi) {
        int i = r.nextInt(main.n);
        float side = r.chance(0.5f) ? 1f : -1f;
        float off = main.w[i] * 0.5f + r.range(lo, hi);
        px = main.x[i] + (-main.tz[i]) * side * off;
        pz = main.z[i] + main.tx[i] * side * off;
        return inBounds(px, pz);
    }

    private boolean far(Rng r) {
        px = r.range(minX, maxX); pz = r.range(minZ, maxZ);
        return true;
    }

    private boolean occupied(float x, float z) {
        int ix = MathX.clamp(Math.round((x - gx0) / cell), 0, gnx - 1), iz = MathX.clamp(Math.round((z - gz0) / cell), 0, gnz - 1);
        return occ[iz * gnx + ix] != 0;
    }

    private void mark(float x, float z, int rad) {
        int ix = MathX.clamp(Math.round((x - gx0) / cell), 0, gnx - 1), iz = MathX.clamp(Math.round((z - gz0) / cell), 0, gnz - 1);
        for (int dz = -rad; dz <= rad; dz++) for (int dx = -rad; dx <= rad; dx++) {
            int a = ix + dx, b = iz + dz;
            if (a >= 0 && b >= 0 && a < gnx && b < gnz) occ[b * gnx + a] = 1;
        }
    }

    private float slopeAt(float x, float z) {
        float e = 1.5f;
        float a = (terrainHeight(x + e, z) - terrainHeight(x - e, z)) / (2 * e);
        float b = (terrainHeight(x, z + e) - terrainHeight(x, z - e)) / (2 * e);
        return Math.max(Math.abs(a), Math.abs(b));
    }

    /** Scatter helper: places up to `target` props of `type`. */
    private void scatter(Rng r, int type, int target, boolean nearRoad, float lo, float hi, float minH, float maxH,
                         float minSdf, float maxSlope, float s0, float s1, int markRad, float cluster) {
        int placed = 0;
        for (int k = 0; k < target * 25 && placed < target; k++) {
            if (nearRoad) { if (!near(r, lo, hi)) continue; } else far(r);
            float h = terrainHeight(px, pz);
            if (h < minH || h > maxH) continue;
            if (sdfAt(px, pz) < minSdf) continue;
            if (slopeAt(px, pz) > maxSlope) continue;
            if (cluster > 0f && com.kartracer.util.Noise.fbm(px / 40f, pz / 40f, 2, def.seed + type) < cluster) continue;
            if (markRad >= 0 && occupied(px, pz)) continue;
            addScenery(type, px, pz, r.range(0f, MathX.TAU), r.range(s0, s1));
            if (markRad >= 0) mark(px, pz, markRad);
            placed++;
        }
    }

    private void placeScenery() {
        Rng r = new Rng(def.seed * 7919L + 13);
        float wl = def.waterLevel;
        switch (def.theme) {
            case 0:
                scatter(r, Props.PALM, 230, true, 3.5f, 60f, 0.9f, 7f, 3.2f, 0.5f, 0.85f, 1.4f, 1, 0.38f);
                scatter(r, Props.PALM, 90, false, 0, 0, 1.0f, 8f, 14f, 0.5f, 0.9f, 1.5f, 1, 0f);
                scatter(r, Props.BUSH, 130, true, 3f, 40f, 0.9f, 7f, 3f, 0.6f, 0.8f, 1.4f, 0, 0f);
                scatter(r, Props.ROCK, 70, true, 5f, 70f, -1.2f, 8f, 3f, 0.9f, 0.6f, 2.2f, 1, 0f);
                scatter(r, Props.UMBRELLA, 14, true, 4f, 16f, 0.9f, 4f, 3.5f, 0.3f, 0.9f, 1.1f, 1, 0f);
                break;
            case 1:
                scatter(r, Props.JTREE, 330, true, 3f, 55f, wl + 1.2f, 40f, 3.2f, 0.55f, 0.9f, 1.6f, 1, 0f);
                scatter(r, Props.JTREE, 120, false, 0, 0, wl + 1f, 40f, 15f, 0.7f, 1.0f, 1.8f, 1, 0f);
                scatter(r, Props.FERN, 260, true, 2.2f, 22f, wl + 0.8f, 40f, 2.5f, 0.8f, 0.8f, 1.5f, -1, 0f);
                scatter(r, Props.MUSHROOM, 60, true, 3.5f, 28f, wl + 0.8f, 40f, 3.2f, 0.6f, 0.8f, 1.8f, 0, 0f);
                scatter(r, Props.ROCK, 70, true, 4f, 50f, wl + 0.5f, 40f, 3f, 0.9f, 0.7f, 2.0f, 1, 0f);
                scatter(r, Props.TOTEM, 8, true, 2.8f, 8f, wl + 1f, 40f, 2.6f, 0.5f, 1.0f, 1.3f, 1, 0f);
                scatter(r, Props.BUSH, 100, true, 2.5f, 30f, wl + 0.8f, 40f, 2.5f, 0.7f, 0.9f, 1.6f, -1, 0f);
                scatter(r, Props.TUFT, 300, true, 1.5f, 14f, wl + 0.6f, 40f, 1.8f, 0.8f, 0.8f, 1.4f, -1, 0f);
                break;
            case 2:
                scatter(r, Props.SPIRE, 110, true, 6f, 70f, wl + 0.5f, 60f, 5f, 1.4f, 0.8f, 2.2f, 1, 0f);
                scatter(r, Props.SPIRE, 60, false, 0, 0, wl + 0.5f, 60f, 20f, 2.0f, 1.2f, 2.8f, 1, 0f);
                scatter(r, Props.ROCK, 160, true, 3f, 60f, wl + 0.4f, 60f, 2.8f, 1.4f, 0.6f, 2.4f, 0, 0f);
                scatter(r, Props.DEADTREE, 40, true, 5f, 55f, wl + 0.6f, 60f, 4f, 0.8f, 0.9f, 1.4f, 1, 0f);
                scatter(r, Props.TOTEM, 6, true, 2.8f, 9f, wl + 0.6f, 60f, 2.6f, 0.5f, 1.0f, 1.3f, 1, 0f);
                break;
            default:
                scatter(r, Props.CACTUS, 230, true, 3f, 60f, 0f, 30f, 3f, 0.6f, 0.8f, 1.5f, 1, 0f);
                scatter(r, Props.ROCK, 120, true, 4f, 60f, 0f, 30f, 3f, 1.2f, 0.6f, 2.2f, 1, 0f);
                scatter(r, Props.DEADTREE, 40, true, 5f, 60f, 0f, 30f, 4f, 0.7f, 0.9f, 1.4f, 1, 0f);
                scatter(r, Props.TOTEM, 6, true, 2.8f, 9f, 0f, 30f, 2.6f, 0.5f, 1.0f, 1.3f, 1, 0f);
                scatter(r, Props.TUFT, 200, true, 1.5f, 20f, 0f, 30f, 1.8f, 0.7f, 0.8f, 1.4f, -1, 0f);
                // mesas far from the road
                int placed = 0;
                for (int k = 0; k < 4000 && placed < 36; k++) {
                    far(r);
                    float s = r.range(4f, 9f);
                    if (sdfAt(px, pz) < 14f + s * 9f) continue;
                    if (occupied(px, pz)) continue;
                    addScenery(Props.MESA, px, pz, r.range(0f, MathX.TAU), s);
                    mark(px, pz, (int) (s * 3));
                    placed++;
                }
                break;
        }
        placeLineProps(r);
        placeSigns();
    }

    /** Torches / braziers lining the road, special landmarks. */
    private void placeLineProps(Rng r) {
        int n = main.n;
        if (def.theme == 0 || def.theme == 2) {
            float every = def.theme == 0 ? 38f : 36f;
            float acc = 0f;
            for (int i = 0; i < n; i += 2) {
                acc += length / n * 2f;
                if (acc < every) continue;
                acc = 0f;
                for (int sd = -1; sd <= 1; sd += 2) {
                    if (def.theme == 0 && sd < 0) continue;
                    float off = main.w[i] * 0.5f + 1.8f;
                    float x = main.x[i] + (-main.tz[i]) * off * sd, z = main.z[i] + main.tx[i] * off * sd;
                    if (sdfAt(x, z) < 0.8f) continue;
                    addScenery(Props.TORCH, x, z, 0f, def.theme == 0 ? 1f : 1.2f);
                }
            }
        }
        if (def.theme == 0) {
            for (int k = 0; k < 600; k++) {
                int i = r.nextInt(n);
                int sd = rho(i) > 1f ? 1 : -1;
                float off = main.w[i] * 0.5f + r.range(28f, 50f);
                float x = main.x[i] + (-main.tz[i]) * off * sd, z = main.z[i] + main.tx[i] * off * sd;
                if (!inBounds(x, z) || terrainHeight(x, z) < 1.0f || sdfAt(x, z) < 20f || occupied(x, z)) continue;
                if (Math.abs(main.s[i] - 0f) < length * 0.1f) continue;
                addScenery(Props.LIGHTHOUSE, x, z, 0f, 1f);
                mark(x, z, 3);
                break;
            }
        }
    }

    private float rho(int i) { return Terrain.rho(def, main.x[i] + (-main.tz[i]) * 6f, main.z[i] + main.tx[i] * 6f) - Terrain.rho(def, main.x[i], main.z[i]); }

    private void placeSigns() {
        int n = main.n;
        float last = -1000f;
        for (int i = 0; i < n; i++) {
            float k = main.curv[i];
            if (Math.abs(k) < 0.014f) continue;
            // local maximum of |curv| in a 12-sample window
            boolean peak = true;
            for (int d = -12; d <= 12; d++) if (Math.abs(main.curv[main.wrap(i + d)]) > Math.abs(k) + 1e-6f) { peak = false; break; }
            if (!peak || main.s[i] - last < 60f) continue;
            int a = main.wrap(i - 22);
            float outer = k > 0 ? -1f : 1f; // right turn -> outside is left
            float off = main.w[a] * 0.5f + 2.6f;
            float x = main.x[a] + (-main.tz[a]) * off * outer, z = main.z[a] + main.tx[a] * off * outer;
            if (sdfAt(x, z) < 1.2f) continue;
            float yaw = (float) Math.atan2(main.tx[a], -main.tz[a]);
            addScenery(k > 0 ? Props.SIGN_R : Props.SIGN_L, x, z, yaw, 1.2f);
            last = main.s[i];
        }
    }

    // ------------------------------------------------------------------ colliders / grid

    private void buildColliders() {
        hcx = (int) Math.ceil(gnx * cell / HCELL);
        hcz = (int) Math.ceil(gnz * cell / HCELL);
        int cells = hcx * hcz;
        hStart = new int[cells + 1];
        int[] cellOf = new int[colN];
        for (int i = 0; i < colN; i++) {
            int cx = MathX.clamp((int) ((colX[i] - gx0) / HCELL), 0, hcx - 1);
            int cz = MathX.clamp((int) ((colZ[i] - gz0) / HCELL), 0, hcz - 1);
            cellOf[i] = cz * hcx + cx;
            hStart[cellOf[i] + 1]++;
        }
        for (int i = 0; i < cells; i++) hStart[i + 1] += hStart[i];
        hItems = new int[colN];
        int[] fill = new int[cells];
        for (int i = 0; i < colN; i++) hItems[hStart[cellOf[i]] + fill[cellOf[i]]++] = i;
    }

    private void buildStartGrid() {
        float[] p = new float[6];
        for (int k = 0; k < 8; k++) {
            int row = k / 2, col = k % 2;
            float back = 7f + row * 7.5f + (col == 1 ? 3.6f : 0f);
            mainPointAt(length - back, p);
            float lat = (col == 0 ? -1f : 1f) * Math.min(3.0f, p[5] * 0.22f);
            gridX[k] = p[0] + (-p[4]) * lat;
            gridZ[k] = p[1] + p[3] * lat;
            gridY[k] = groundHeight(gridX[k], gridZ[k]);
            gridYaw[k] = (float) Math.atan2(p[3], -p[4]);
        }
    }
}
