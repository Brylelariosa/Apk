package com.kartracer.sim;

/** Ring of one-shot effect events produced by the simulation and consumed by the renderer. */
public final class FxEvents {
    public static final int BOOST = 1, HIT = 2, SMASH = 3, LAND = 4, SPLASH = 5, BUMP = 6, ITEM_PICK = 7, PAD = 8, EXPLODE = 9,
            LAUNCH = 10, RESPAWN = 11, SHIELD_POP = 12, CHECKPOINT = 13, DRIFT_SPARK = 14, TOAST = 15, FINISH = 16;
    public static final int CAP = 192;

    public final int[] type = new int[CAP];
    public final float[] x = new float[CAP], y = new float[CAP], z = new float[CAP], a = new float[CAP];
    public int count;

    public void add(int t, float px, float py, float pz, float pa) {
        if (count >= CAP) return;
        type[count] = t; x[count] = px; y[count] = py; z[count] = pz; a[count] = pa;
        count++;
    }

    public void clear() { count = 0; }
}
