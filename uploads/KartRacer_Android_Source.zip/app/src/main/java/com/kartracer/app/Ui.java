package com.kartracer.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Small programmatic UI toolkit: consistent colors, buttons, chips, toggles, sliders. */
public final class Ui {
    private Ui() {}

    public static final int PANEL = 0xE60B1A2E, CARD = 0xCC12263D, CARD2 = 0xFF1A3350, ACCENT = 0xFFFFA726, ACCENT_DARK = 0xFFE65100,
            TEAL = 0xFF26C6DA, TEXT = 0xFFFFFFFF, DIM = 0xFFA9BCD0, OK = 0xFF4CAF50, BAD = 0xFFEF5350, STROKE = 0x33FFFFFF;

    private static float density = 2.5f;

    public static void init(Context c) { density = c.getResources().getDisplayMetrics().density; }
    public static int dp(float v) { return Math.round(v * density); }
    public static float density() { return density; }

    public interface IntCb { void run(int v); }
    public interface BoolCb { void run(boolean v); }

    // ------------------------------------------------------------------ drawables

    public static GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public static GradientDrawable roundedStroke(int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable g = rounded(color, radiusDp);
        g.setStroke(Math.max(1, dp(strokeDp)), strokeColor);
        return g;
    }

    public static GradientDrawable gradient(int top, int bottom, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private static StateListDrawable pressable(Drawable normal, Drawable pressed) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    /** Icon drawn with the vector icon set. */
    public static final class IconDrawable extends Drawable {
        private final int icon;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        public IconDrawable(int icon, int color) { this.icon = icon; p.setColor(color); }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            Icons.draw(c, icon, b.exactCenterX(), b.exactCenterY(), Math.min(b.width(), b.height()) / 2f, p);
        }
        @Override public void setAlpha(int a) { p.setAlpha(a); }
        @Override public void setColorFilter(ColorFilter f) { p.setColorFilter(f); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    // ------------------------------------------------------------------ text / layout

    public static TextView text(Context c, CharSequence t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(bold ? Typeface.create("sans-serif-medium", Typeface.BOLD) : Typeface.create("sans-serif", Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    public static LinearLayout hbox(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    public static LinearLayout vbox(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }

    public static LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    public static LinearLayout.LayoutParams lpw(int w, int h, float weight) { return new LinearLayout.LayoutParams(w, h, weight); }

    public static LinearLayout.LayoutParams lpm(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    public static FrameLayout.LayoutParams flp(int w, int h, int gravity) { return new FrameLayout.LayoutParams(w, h, gravity); }

    public static FrameLayout.LayoutParams flpm(int w, int h, int gravity, int l, int t, int r, int b) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, gravity);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    public static View space(Context c, int wDp, int hDp) { View v = new View(c); v.setLayoutParams(lp(dp(wDp), dp(hDp))); return v; }

    public static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(roundedStroke(CARD, 14, STROKE, 1));
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        return l;
    }

    // ------------------------------------------------------------------ controls

    public static ImageView iconView(Context c, int icon, float sizeDp, int color) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(new IconDrawable(icon, color));
        v.setLayoutParams(lp(dp(sizeDp), dp(sizeDp)));
        return v;
    }

    /** kind: 0 primary (amber), 1 secondary (dark), 2 danger. */
    public static View button(Context c, String label, int icon, int kind, View.OnClickListener click) {
        LinearLayout b = hbox(c);
        b.setGravity(Gravity.CENTER);
        int top = kind == 0 ? 0xFFFFB74D : (kind == 2 ? 0xFFEF5350 : 0xFF244566);
        int bot = kind == 0 ? ACCENT_DARK : (kind == 2 ? 0xFFB71C1C : 0xFF16304B);
        GradientDrawable n = gradient(top, bot, 12);
        n.setStroke(dp(1), kind == 1 ? 0x44FFFFFF : 0x00000000);
        GradientDrawable pr = gradient(Math.max(0xFF000000, top) & 0xFFE0E0E0, bot, 12);
        b.setBackground(pressable(n, pr));
        b.setPadding(dp(16), dp(10), dp(18), dp(10));
        if (icon >= 0) {
            ImageView iv = iconView(c, icon, 22, kind == 1 ? TEXT : 0xFF1A1000);
            if (kind != 0) iv.setImageDrawable(new IconDrawable(icon, TEXT));
            b.addView(iv);
            b.addView(space(c, 8, 1));
        }
        TextView t = text(c, label, 15, kind == 0 ? 0xFF1A1000 : TEXT, true);
        t.setLetterSpacing(0.04f);
        b.addView(t);
        b.setOnClickListener(click);
        b.setClickable(true);
        return b;
    }

    public static View iconButton(Context c, int icon, int sizeDp, View.OnClickListener click) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(pressable(roundedStroke(0xCC16304B, sizeDp / 2f, 0x44FFFFFF, 1), roundedStroke(0xFF2A5078, sizeDp / 2f, 0x66FFFFFF, 1)));
        ImageView iv = iconView(c, icon, sizeDp * 0.5f, TEXT);
        f.addView(iv, flp(dp(sizeDp * 0.5f), dp(sizeDp * 0.5f), Gravity.CENTER));
        f.setLayoutParams(lp(dp(sizeDp), dp(sizeDp)));
        f.setOnClickListener(click);
        return f;
    }

    /** Segmented control. */
    public static View chips(Context c, String[] labels, int selected, IntCb cb) {
        final LinearLayout row = hbox(c);
        row.setBackground(rounded(0x55000000, 10));
        row.setPadding(dp(3), dp(3), dp(3), dp(3));
        final TextView[] tv = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = text(c, labels[i], 13, i == selected ? 0xFF1A1000 : TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(10), dp(8), dp(10), dp(8));
            t.setBackground(i == selected ? rounded(ACCENT, 8) : null);
            tv[i] = t;
            row.addView(t, lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            tv[i].setOnClickListener(v -> {
                for (int k = 0; k < tv.length; k++) {
                    tv[k].setBackground(k == idx ? rounded(ACCENT, 8) : null);
                    tv[k].setTextColor(k == idx ? 0xFF1A1000 : TEXT);
                }
                cb.run(idx);
            });
        }
        return row;
    }

    /** Pill style on/off switch. */
    public static final class ToggleView extends View {
        private boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF r = new android.graphics.RectF();

        public ToggleView(Context c, boolean on) { super(c); this.on = on; setClickable(true); }
        public boolean isOn() { return on; }
        public void setOn(boolean v) { on = v; invalidate(); }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(dp(46), dp(26)); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setColor(on ? ACCENT : 0x66FFFFFF);
            r.set(0, 0, w, h);
            c.drawRoundRect(r, h / 2f, h / 2f, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(on ? w - h / 2f : h / 2f, h / 2f, h / 2f - dp(3), p);
        }
    }

    public static View toggle(Context c, String label, boolean on, BoolCb cb) {
        LinearLayout row = hbox(c);
        row.setPadding(0, dp(6), 0, dp(6));
        row.addView(text(c, label, 14, TEXT, false), lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ToggleView tg = new ToggleView(c, on);
        tg.setOnClickListener(v -> { tg.setOn(!tg.isOn()); cb.run(tg.isOn()); });
        row.addView(tg);
        row.setOnClickListener(v -> tg.performClick());
        return row;
    }

    public static View slider(Context c, String label, int min, int max, int value, String suffix, IntCb cb) {
        LinearLayout box = vbox(c);
        box.setPadding(0, dp(6), 0, dp(4));
        LinearLayout top = hbox(c);
        top.addView(text(c, label, 14, TEXT, false), lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text(c, value + suffix, 14, ACCENT, true);
        top.addView(val);
        box.addView(top);
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(ACCENT));
        sb.setPadding(dp(10), dp(6), dp(10), dp(2));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { val.setText((p + min) + suffix); if (fromUser) cb.run(p + min); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    /** "- value +" stepper. */
    public static View stepper(Context c, String label, int min, int max, int value, IntCb cb) {
        LinearLayout row = hbox(c);
        row.setPadding(0, dp(5), 0, dp(5));
        row.addView(text(c, label, 14, TEXT, false), lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final int[] v = {value};
        final TextView val = text(c, String.valueOf(value), 17, ACCENT, true);
        val.setGravity(Gravity.CENTER);
        View minus = iconButton(c, Icons.MINUS, 34, null);
        View plus = iconButton(c, Icons.PLUS, 34, null);
        minus.setOnClickListener(x -> { if (v[0] > min) { v[0]--; val.setText(String.valueOf(v[0])); cb.run(v[0]); } });
        plus.setOnClickListener(x -> { if (v[0] < max) { v[0]++; val.setText(String.valueOf(v[0])); cb.run(v[0]); } });
        row.addView(minus);
        row.addView(val, lp(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(plus);
        return row;
    }

    public static View statBar(Context c, String label, float v, int color) {
        LinearLayout row = hbox(c);
        row.setPadding(0, dp(4), 0, dp(4));
        TextView t = text(c, label, 13, DIM, false);
        row.addView(t, lp(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT));
        final float vv = Math.max(0.05f, Math.min(1f, v));
        FrameLayout bar = new FrameLayout(c);
        bar.setBackground(rounded(0x44FFFFFF, 4));
        View fill = new View(c);
        fill.setBackground(rounded(color, 4));
        bar.addView(fill, new FrameLayout.LayoutParams(0, dp(8)));
        bar.post(() -> { FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) fill.getLayoutParams(); l.width = (int) (bar.getWidth() * vv); fill.setLayoutParams(l); });
        row.addView(bar, lpw(0, dp(8), 1f));
        return row;
    }

    public static TextView sectionTitle(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 12, TEAL, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(0, dp(2), 0, dp(6));
        return t;
    }

    public static void fadeIn(View v) {
        v.setAlpha(0f);
        v.animate().alpha(1f).setDuration(180).start();
    }
}
