package com.kartracer.sim;

import com.kartracer.net.Msg;
import com.kartracer.util.MathX;
import com.kartracer.util.Rng;
import com.kartracer.world.Road;
import com.kartracer.world.TrackData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Race simulation: fixed-step physics for all locally simulated karts, AI, items, hazards, ranking and network sync.
 * Roles: OFFLINE (everything local), HOST (authoritative world + AI, relays), CLIENT (own kart only, mirrors the rest).
 */
public final class Race {
    public static final int ROLE_OFFLINE = 0, ROLE_HOST = 1, ROLE_CLIENT = 2;
    public static final int PH_COUNTDOWN = 0, PH_RACING = 1, PH_ENDED = 2;
    public static final int I_NONE = 0, I_NITRO = 1, I_ROCKET = 2, I_COCONUT = 3, I_SLICK = 4, I_SHIELD = 5, I_COUNT = 6;
    public static final int E_ROCKET = 1, E_COCONUT = 2, E_SLICK = 3;
    public static final float STEP = 1f / 60f;
    public static final int MAXE = 40;
    public static final int INTERP_MS = 110;

    public final TrackData track;
    public final RaceSettings cfg;
    public final int role, nKarts, localSlot;
    public final Kart[] karts;
    public final FxEvents fx = new FxEvents();
    public final RaceNet net;
    private final AiDriver[] ai;
    private final Participant[] parts;
    private final boolean[] tookOver;
    private final Rng rng;
    private final int[] order;

    public int phase = PH_COUNTDOWN;
    public float raceTime = -3.5f;
    private int goMs;
    private float acc, netAcc;
    private boolean paused, fastForward;
    private int pausedAtMs;
    private int snapSeq;
    private float startHold;
    private float firstFinishTime = -1f, lastHumanFinish = -1f;
    public boolean localFinished;
    public float leaderTotal;
    private int finishCount;

    public final boolean[] boxActive, crateAlive;
    private final float[] boxRespawn;
    private final int[] boxPending;
    public final boolean itemsOn;

    // entities (authoritative on host/offline, mirrored on clients)
    public final int[] eType = new int[MAXE], eOwner = new int[MAXE], eTarget = new int[MAXE], eId = new int[MAXE];
    public final float[] ex = new float[MAXE], ey = new float[MAXE], ez = new float[MAXE], evx = new float[MAXE], evy = new float[MAXE],
            evz = new float[MAXE], eYaw = new float[MAXE], eLife = new float[MAXE], eAge = new float[MAXE];
    public final boolean[] eAlive = new boolean[MAXE];
    private int nextEntId = 1;

    private final Msg.KartNet[] lastNet;
    public List<ResultRow> results;
    public boolean resyncNeeded;
    private final int[] tmpIds = new int[16];

    public Race(TrackData track, RaceSettings cfg, Participant[] parts, int localSlot, int role, RaceNet net, long seed) {
        this.track = track; this.cfg = cfg; this.role = role; this.net = net; this.localSlot = localSlot; this.parts = parts;
        nKarts = parts.length;
        karts = new Kart[nKarts]; ai = new AiDriver[nKarts]; order = new int[nKarts]; tookOver = new boolean[nKarts];
        lastNet = new Msg.KartNet[nKarts];
        rng = new Rng(seed);
        itemsOn = cfg.items;
        for (Participant p : parts) {
            int ctrl = p.slot == localSlot ? Kart.CTRL_LOCAL : ((role == ROLE_CLIENT || !p.ai) ? Kart.CTRL_REMOTE : Kart.CTRL_AI);
            Kart k = new Kart(p.slot, ctrl);
            k.name = p.name; k.kartType = p.kart; k.color = p.color; k.driver = p.driver; k.aiSkill = p.skill;
            k.st = KartStats.get(p.kart);
            int g = Math.min(7, p.slot);
            k.place(track.gridX[g], track.gridY[g], track.gridZ[g], track.gridYaw[g]);
            locate(k, true);
            k.furthest = k.s;
            karts[p.slot] = k;
            if (ctrl == Kart.CTRL_AI) ai[p.slot] = new AiDriver(seed + p.slot * 977L, cfg.difficulty, p.skill);
        }
        boxActive = new boolean[track.nBoxes];
        Arrays.fill(boxActive, itemsOn);
        boxRespawn = new float[track.nBoxes];
        boxPending = new int[track.nBoxes];
        crateAlive = new boolean[track.crates.length];
        Arrays.fill(crateAlive, true);
        updateRanks();
    }

    // ------------------------------------------------------------------ control

    public Kart localKart() { return karts[localSlot]; }

    /** Multiplayer: absolute host-clock time (ms) of the GO moment. */
    public void startAt(int goMs) { this.goMs = goMs; started = true; }
    private boolean started;

    public void setPaused(boolean p) {
        if (role != ROLE_OFFLINE || p == paused) return;
        paused = p;
    }

    public boolean isPaused() { return paused; }
    public float alpha() { return MathX.clamp(acc / STEP, 0f, 1f); }

    private int nowMs() { return net != null ? net.clockMs() : (int) (System.nanoTime() / 1000000L); }

    /** Item button pressed (called on the game thread). */
    private boolean pendingItem;
    public void pressItem() { pendingItem = true; }
    public final KartInput localInput = new KartInput();

    public void forceRespawnLocal() { Kart k = localKart(); if (!k.finished && phase == PH_RACING) respawn(k); }

    // ------------------------------------------------------------------ main update

    public void update(float frameDt) {
        if (paused) return;
        if (role != ROLE_OFFLINE) raceTime = started ? (nowMs() - goMs) / 1000f : -3.5f;
        pollNet();
        fastForward = role == ROLE_OFFLINE && localFinished && phase == PH_RACING;
        acc += Math.min(frameDt, 0.1f) * (fastForward ? 3f : 1f);
        int steps = 0;
        while (acc >= STEP && steps < 10) { simStep(STEP); acc -= STEP; steps++; }
        if (steps == 10) acc = 0f;
        float vdt = Math.min(frameDt, 0.1f);
        int renderMs = nowMs() - INTERP_MS;
        for (int i = 0; i < nKarts; i++) {
            Kart k = karts[i];
            if (k.ctrl == Kart.CTRL_REMOTE) {
                if (!k.hasRemote()) continue;
                k.sampleRemote(renderMs);
                k.finished = (k.remoteFlags & Kart.F_FINISHED) != 0;
                progress(k);
            }
            k.updateVisuals(track, vdt);
        }
        netTick(vdt);
    }

    private void simStep(float dt) {
        if (role == ROLE_OFFLINE) raceTime += dt;
        if (phase == PH_COUNTDOWN && raceTime >= 0f) goRace();
        boolean racing = phase != PH_COUNTDOWN;
        for (int i = 0; i < nKarts; i++) {
            Kart k = karts[i];
            if (k.ctrl == Kart.CTRL_REMOTE) continue;
            if (k.needRespawn) respawn(k);
            if (k.ctrl == Kart.CTRL_LOCAL && !k.finished) {
                k.in.set(localInput);
                k.in.item = pendingItem;
                pendingItem = false;
            } else {
                AiDriver d = ai[i];
                if (d == null) { d = ai[i] = new AiDriver(i * 131L + 5, cfg.difficulty, 1); }
                d.cruise = k.ctrl == Kart.CTRL_LOCAL;
                d.drive(this, k, dt);
            }
            if (!racing) {
                if (k.ctrl == Kart.CTRL_LOCAL) startHold = localInput.throttle > 0.5f ? startHold + dt : 0f;
                k.in.clear();
            }
            k.step(track, fx, dt);
            postStep(k, dt, racing);
        }
        collideKarts();
        if (role != ROLE_CLIENT) updateEntities(dt);
        for (int b = 0; b < boxActive.length; b++) {
            if (itemsOn && !boxActive[b] && raceTime >= boxRespawn[b]) boxActive[b] = true;
        }
        updateRanks();
        if (phase == PH_RACING && role != ROLE_CLIENT) checkRaceEnd();
    }

    private void goRace() {
        phase = PH_RACING;
        for (int i = 0; i < nKarts; i++) {
            Kart k = karts[i];
            if (k.ctrl == Kart.CTRL_REMOTE) continue;
            boolean boost;
            if (k.ctrl == Kart.CTRL_LOCAL) {
                boost = startHold > 0.05f && startHold < 0.75f;
                if (startHold > 1.8f) k.slowTime = 0.5f;
            } else boost = rng.chance(0.35f + 0.2f * cfg.difficulty);
            if (boost) { k.addBoost(0.35f, 1.1f); fx.add(FxEvents.BOOST, k.x, k.y, k.z, k.slot); }
        }
    }

    // ------------------------------------------------------------------ per kart events

    private void postStep(Kart k, float dt, boolean racing) {
        if (k.bumpPending > 0f) { fx.add(FxEvents.BUMP, k.x, k.y, k.z, k.bumpPending); k.bumpPending = 0f; }
        progress(k);
        if (!racing) return;
        if (k.in.item) { k.in.item = false; useItem(k); }
        pads(k);
        crates(k);
        boxes(k);
        hazards(k);
        float spd = k.speed();
        if (!k.finished && spd < 1.3f && k.in.throttle > 0.4f && k.respawnTimer <= 0f) k.stuckTime += dt; else k.stuckTime = 0f;
        if (k.stuckTime > (k.ctrl == Kart.CTRL_AI ? 3.5f : 5f) || track.sdfAt(k.x, k.z) > 90f) respawn(k);
        float along = k.vx * track.main.tx[k.idx] + k.vz * track.main.tz[k.idx];
        if (along < -3f && !k.finished) k.wrongWayTime += dt; else k.wrongWayTime = 0f;
        k.wrongWay = k.wrongWayTime > 1.2f;
        if (!k.finished && k.crossings >= cfg.laps + 1) finish(k, raceTime);
    }

    private void finish(Kart k, float time) {
        if (k.finished) return;
        k.finished = true;
        k.finishTime = time;
        finishCount++;
        if (firstFinishTime < 0f) firstFinishTime = time;
        fx.add(FxEvents.FINISH, k.x, k.y, k.z, k.slot);
        if (k.ctrl == Kart.CTRL_LOCAL) {
            localFinished = true;
            lastHumanFinish = raceTime;
            if (role == ROLE_CLIENT && net != null) net.sendReliable(new Msg.Finished((int) (time * 1000f)));
        }
        if (isHuman(k)) lastHumanFinish = Math.max(lastHumanFinish, time);
    }

    private boolean isHuman(Kart k) { return k.ctrl == Kart.CTRL_LOCAL || (k.ctrl == Kart.CTRL_REMOTE && !parts[k.slot].ai && !tookOver[k.slot]); }

    private void pads(Kart k) {
        if (!k.grounded) return;
        for (int i = 0; i < track.pads.length; i++) {
            com.kartracer.world.TrackData.Pad p = track.pads[i];
            float dx = k.x - p.x, dz = k.z - p.z;
            float s = (float) Math.sin(p.yaw), c = (float) Math.cos(p.yaw);
            float u = dx * s - dz * c, v = dx * c + dz * s;
            if (u >= 0f && u <= p.len && Math.abs(v) <= p.wid * 0.5f) {
                if (k.boostTime < 0.3f) fx.add(FxEvents.PAD, k.x, k.y, k.z, k.slot);
                k.addBoost(0.40f, 1.3f);
            }
        }
    }

    private void crates(Kart k) {
        for (int i = 0; i < crateAlive.length; i++) {
            if (!crateAlive[i]) continue;
            com.kartracer.world.TrackData.Crate c = track.crates[i];
            float dx = k.x - c.x, dz = k.z - c.z;
            if (dx * dx + dz * dz < 2.0f * 2.0f && Math.abs(k.y - c.y) < 2.5f) {
                crateAlive[i] = false;
                k.vx *= 0.95f; k.vz *= 0.95f;
                fx.add(FxEvents.SMASH, c.x, c.y + 0.5f, c.z, k.speed());
                if (net != null) net.sendReliable(new Msg.Destroy(i));
            }
        }
    }

    private void boxes(Kart k) {
        if (!itemsOn || k.finished) return;
        for (int b = 0; b < boxActive.length; b++) {
            if (!boxActive[b]) continue;
            float dx = k.x - track.boxX[b], dz = k.z - track.boxZ[b];
            if (dx * dx + dz * dz > 2.4f * 2.4f || Math.abs(k.y + 1f - track.boxY[b]) > 3f) continue;
            if (k.item != 0) continue;
            if (role == ROLE_CLIENT) {
                int now = nowMs();
                if (now - boxPending[b] > 600 && net != null) { boxPending[b] = now; net.sendReliable(new Msg.Pickup(b)); }
            } else grantBox(k.slot, b);
        }
    }

    private void grantBox(int slot, int box) {
        if (!boxActive[box] || slot < 0 || slot >= nKarts) return;
        Kart k = karts[slot];
        if (k.item != 0 || k.finished) return;
        boxActive[box] = false;
        boxRespawn[box] = raceTime + 4f;
        int item = rollItem(k.place);
        if (k.ctrl != Kart.CTRL_REMOTE) { k.item = item; fx.add(FxEvents.ITEM_PICK, track.boxX[box], track.boxY[box], track.boxZ[box], slot); }
        if (net != null) net.sendReliable(new Msg.BoxTaken(box, slot, item));
        else if (false) { }
    }

    private int rollItem(int place) {
        float p = nKarts <= 1 ? 0f : (place - 1) / (float) (nKarts - 1);
        float[] w = {0f, 1f + 3f * p, 0.5f + 3.5f * p, 3f - 1.5f * p, 2.5f - 1.5f * p, 2f - 0.5f * p};
        float sum = 0f;
        for (int i = 1; i < I_COUNT; i++) sum += w[i];
        float r = rng.next() * sum;
        for (int i = 1; i < I_COUNT; i++) { r -= w[i]; if (r <= 0f) return i; }
        return I_NITRO;
    }

    private void useItem(Kart k) {
        int it = k.item;
        if (it == 0 || k.finished) return;
        k.item = 0;
        switch (it) {
            case I_NITRO: k.addBoost(0.5f, 2.2f); fx.add(FxEvents.BOOST, k.x, k.y, k.z, k.slot); break;
            case I_SHIELD: k.shield = 8f; break;
            default:
                if (role == ROLE_CLIENT && k.ctrl == Kart.CTRL_LOCAL) {
                    if (net != null) {
                        Msg.UseItem u = new Msg.UseItem();
                        u.item = it; u.x = k.x; u.y = k.y; u.z = k.z; u.yaw = k.yaw; u.speed = k.forwardSpeed();
                        net.sendReliable(u);
                    }
                } else spawnEntity(it, k.slot, k.x, k.y, k.z, k.yaw, k.forwardSpeed());
        }
    }

    private void hazards(Kart k) {
        if (k.invuln > 0f || k.respawnTimer > 0f) return;
        for (int i = 0; i < track.hazards.length; i++) {
            com.kartracer.world.TrackData.Haz h = track.hazards[i];
            float[] p = hz;
            if (h.type == 0) {
                boulderPos(h, raceTime, p);
                float dx = k.x - p[0], dz = k.z - p[1];
                if (dx * dx + dz * dz < (h.radius + 1f) * (h.radius + 1f) && k.y < h.y + 4f) k.applyHit(Kart.HIT_SPIN, fx);
            } else if (geyserActive(h, raceTime)) {
                float dx = k.x - h.x0, dz = k.z - h.z0;
                if (dx * dx + dz * dz < (h.radius + 0.6f) * (h.radius + 0.6f)) k.applyHit(Kart.HIT_FLIP, fx);
            }
        }
    }

    private final float[] hz = new float[2];

    /** Boulder swings between its two end points. out = {x, z}. */
    public static void boulderPos(com.kartracer.world.TrackData.Haz h, float t, float[] out) {
        float f = 0.5f - 0.5f * (float) Math.cos(MathX.TAU * (t + h.phase) / h.period);
        out[0] = MathX.lerp(h.x0, h.x1, f);
        out[1] = MathX.lerp(h.z0, h.z1, f);
    }

    private static float cyc(com.kartracer.world.TrackData.Haz h, float t) {
        float u = (t + h.phase) / h.period;
        return u - (float) Math.floor(u);
    }

    public static boolean geyserActive(com.kartracer.world.TrackData.Haz h, float t) { float u = cyc(h, t); return u > 0.72f && u < 0.9f; }
    public static boolean geyserWarning(com.kartracer.world.TrackData.Haz h, float t) { float u = cyc(h, t); return u > 0.55f && u <= 0.72f; }

    // ------------------------------------------------------------------ progress / ranks

    private float tmpT;

    private float segDist2(Kart k, int i0, int i1) {
        Road m = track.main;
        float ax = m.x[i0], az = m.z[i0], dx = m.x[i1] - ax, dz = m.z[i1] - az;
        float l2 = dx * dx + dz * dz;
        float t = l2 > 1e-6f ? MathX.clamp(((k.x - ax) * dx + (k.z - az) * dz) / l2, 0f, 1f) : 0f;
        tmpT = t;
        float qx = ax + dx * t - k.x, qz = az + dz * t - k.z;
        return qx * qx + qz * qz;
    }

    private void locate(Kart k, boolean global) {
        Road m = track.main;
        int n = m.n;
        int best = k.idx;
        float bd = Float.MAX_VALUE;
        if (!global) {
            for (int d = -6; d <= 22; d++) {
                int i = m.wrap(k.idx + d);
                float dx = k.x - m.x[i], dz = k.z - m.z[i];
                float d2 = dx * dx + dz * dz;
                if (d2 < bd) { bd = d2; best = i; }
            }
        }
        if (global || bd > 35f * 35f) {
            bd = Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                float dx = k.x - m.x[i], dz = k.z - m.z[i];
                float d2 = dx * dx + dz * dz;
                if (d2 < bd) { bd = d2; best = i; }
            }
        }
        int nxt = m.wrap(best + 1), prv = m.wrap(best - 1);
        float d1 = segDist2(k, best, nxt), t1 = tmpT;
        float d0 = segDist2(k, prv, best), t0 = tmpT;
        float sNew;
        if (d1 <= d0) sNew = m.s[best] + t1 * segLen(best);
        else sNew = m.s[prv] + t0 * segLen(prv);
        sNew = sNew - track.length * (float) Math.floor(sNew / track.length);
        float ds = sNew - k.s;
        if (!global) {
            if (ds < -track.length * 0.5f) {
                if (k.furthest >= track.length * 0.8f) { k.crossings++; if (k.crossings > 1 && k.ctrl == Kart.CTRL_LOCAL) fx.add(FxEvents.CHECKPOINT, k.x, k.y, k.z, k.crossings); }
                k.furthest = 0f;
            } else if (ds > track.length * 0.5f) {
                if (k.crossings > 0) k.crossings--;
                k.furthest = track.length;
            }
        }
        k.idx = best;
        k.s = sNew;
        k.furthest = Math.max(k.furthest, sNew);
        k.lap = MathX.clamp(k.crossings, 1, cfg.laps);
        k.total = k.crossings * track.length + k.s;
    }

    private float segLen(int i) {
        Road m = track.main;
        float next = i + 1 < m.n ? m.s[i + 1] : track.length;
        return next - m.s[i];
    }

    private void progress(Kart k) { locate(k, false); }

    private final Comparator<Integer> cmp = new Comparator<Integer>() {
        public int compare(Integer a, Integer b) {
            Kart ka = karts[a], kb = karts[b];
            if (ka.finished != kb.finished) return ka.finished ? -1 : 1;
            if (ka.finished) return Float.compare(ka.finishTime, kb.finishTime);
            return Float.compare(kb.total, ka.total);
        }
    };

    private void updateRanks() {
        // insertion sort on a tiny array, no allocation
        for (int i = 0; i < nKarts; i++) order[i] = i;
        for (int i = 1; i < nKarts; i++) {
            int v = order[i], j = i - 1;
            while (j >= 0 && before(v, order[j])) { order[j + 1] = order[j]; j--; }
            order[j + 1] = v;
        }
        for (int i = 0; i < nKarts; i++) karts[order[i]].place = i + 1;
        leaderTotal = karts[order[0]].total;
    }

    private boolean before(int a, int b) {
        Kart ka = karts[a], kb = karts[b];
        if (ka.finished != kb.finished) return ka.finished;
        if (ka.finished) return ka.finishTime < kb.finishTime;
        return ka.total > kb.total;
    }

    public int slotAtPlace(int place) { return order[MathX.clamp(place - 1, 0, nKarts - 1)]; }

    // ------------------------------------------------------------------ respawn

    private void respawn(Kart k) {
        Road m = track.main;
        int j = m.wrap(k.idx - 5);
        float yaw = (float) Math.atan2(m.tx[j], -m.tz[j]);
        float gy = track.groundHeight(m.x[j], m.z[j]);
        float keepNitro = k.nitro;
        int keepItem = k.item;
        k.place(m.x[j], gy + 0.1f, m.z[j], yaw);
        k.resetState();
        k.nitro = keepNitro; k.item = keepItem;
        k.invuln = 2.2f;
        k.idx = j;
        k.s = m.s[j];
        k.furthest = Math.max(k.furthest, k.s);
        fx.add(FxEvents.RESPAWN, k.x, k.y, k.z, k.slot);
    }

    // ------------------------------------------------------------------ kart vs kart

    private void collideKarts() {
        float rr = Kart.RADIUS * 2f;
        for (int i = 0; i < nKarts; i++) {
            Kart a = karts[i];
            for (int j = i + 1; j < nKarts; j++) {
                Kart b = karts[j];
                if (a.ctrl == Kart.CTRL_REMOTE && b.ctrl == Kart.CTRL_REMOTE) continue;
                float dx = b.x - a.x, dz = b.z - a.z;
                if (dx * dx + dz * dz >= rr * rr || Math.abs(a.y - b.y) > 1.6f) continue;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d < 1e-4f) { dx = 1f; dz = 0f; d = 1f; }
                float nx = dx / d, nz = dz / d, pen = rr - d;
                boolean am = a.ctrl != Kart.CTRL_REMOTE, bm = b.ctrl != Kart.CTRL_REMOTE;
                float ma = a.st.mass, mb = b.st.mass;
                if (am && bm) {
                    a.x -= nx * pen * mb / (ma + mb); a.z -= nz * pen * mb / (ma + mb);
                    b.x += nx * pen * ma / (ma + mb); b.z += nz * pen * ma / (ma + mb);
                } else if (am) { a.x -= nx * pen; a.z -= nz * pen; }
                else { b.x += nx * pen; b.z += nz * pen; }
                float rvn = (b.vx - a.vx) * nx + (b.vz - a.vz) * nz;
                if (rvn < 0f) {
                    float j2 = -(1f + 0.5f) * rvn / (1f / ma + 1f / mb);
                    if (am) { a.vx -= j2 / ma * nx; a.vz -= j2 / ma * nz; }
                    if (bm) { b.vx += j2 / mb * nx; b.vz += j2 / mb * nz; }
                    float impact = -rvn;
                    if (impact > 4f) fx.add(FxEvents.BUMP, (a.x + b.x) * 0.5f, a.y + 0.4f, (a.z + b.z) * 0.5f, impact);
                    if (impact > 13f) {
                        Kart weaker = ma <= mb ? a : b;
                        if (weaker.ctrl != Kart.CTRL_REMOTE) weaker.applyHit(Kart.HIT_BUMP, fx);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ entities

    private void spawnEntity(int item, int owner, float x, float y, float z, float yaw, float ownerSpeed) {
        int e = -1;
        for (int i = 0; i < MAXE; i++) if (!eAlive[i]) { e = i; break; }
        if (e < 0) return;
        float fx0 = (float) Math.sin(yaw), fz0 = -(float) Math.cos(yaw);
        eAlive[e] = true; eId[e] = nextEntId++; eOwner[e] = owner; eTarget[e] = -1; eAge[e] = 0f;
        eYaw[e] = yaw;
        switch (item) {
            case I_ROCKET: {
                eType[e] = E_ROCKET;
                ex[e] = x + fx0 * 2.4f; ez[e] = z + fz0 * 2.4f; ey[e] = y + 0.8f;
                float sp = 62f;
                evx[e] = fx0 * sp; evz[e] = fz0 * sp; evy[e] = 0f;
                eLife[e] = 7f;
                Kart me = karts[owner];
                int tgt = -1;
                float bestGap = 1e9f;
                for (int i = 0; i < nKarts; i++) {
                    if (i == owner) continue;
                    float gap = karts[i].total - me.total;
                    if (gap > 0f && gap < bestGap && gap < 500f) { bestGap = gap; tgt = i; }
                }
                eTarget[e] = tgt;
                break;
            }
            case I_COCONUT: {
                eType[e] = E_COCONUT;
                ex[e] = x + fx0 * 2.2f; ez[e] = z + fz0 * 2.2f; ey[e] = y + 0.7f;
                float sp = 52f + Math.max(0f, ownerSpeed) * 0.3f;
                evx[e] = fx0 * sp; evz[e] = fz0 * sp; evy[e] = 0f;
                eLife[e] = 4f;
                break;
            }
            default: {
                eType[e] = E_SLICK;
                ex[e] = x - fx0 * 2.6f; ez[e] = z - fz0 * 2.6f; ey[e] = track.groundHeight(ex[e], ez[e]) + 0.1f;
                evx[e] = evy[e] = evz[e] = 0f;
                eLife[e] = 25f;
            }
        }
        fx.add(FxEvents.LAUNCH, ex[e], ey[e], ez[e], item);
    }

    private void killEntity(int e, boolean explode) {
        if (explode) fx.add(FxEvents.EXPLODE, ex[e], ey[e], ez[e], eType[e]);
        eAlive[e] = false;
    }

    private void updateEntities(float dt) {
        for (int e = 0; e < MAXE; e++) {
            if (!eAlive[e]) continue;
            eAge[e] += dt;
            eLife[e] -= dt;
            if (eLife[e] <= 0f) { killEntity(e, eType[e] != E_SLICK); continue; }
            int type = eType[e];
            if (type == E_ROCKET && eTarget[e] >= 0) {
                Kart t = karts[eTarget[e]];
                float dx = t.x - ex[e], dz = t.z - ez[e];
                float want = (float) Math.atan2(dx, -dz);
                float cur = (float) Math.atan2(evx[e], -evz[e]);
                float turn = MathX.clamp(MathX.angleDiff(want, cur), -3.4f * dt, 3.4f * dt);
                float na = cur + turn, sp = 62f;
                evx[e] = (float) Math.sin(na) * sp; evz[e] = -(float) Math.cos(na) * sp;
                eYaw[e] = na;
            }
            if (type != E_SLICK) {
                ex[e] += evx[e] * dt; ez[e] += evz[e] * dt;
                ey[e] = track.groundHeight(ex[e], ez[e]) + (type == E_ROCKET ? 0.9f : 0.6f);
                if (type == E_COCONUT && track.queryColliders(ex[e], ez[e], 0.5f, tmpIds) > 0) { killEntity(e, true); continue; }
            }
            float rad = type == E_SLICK ? 2.0f : 1.6f;
            for (int i = 0; i < nKarts; i++) {
                Kart k = karts[i];
                float armed = type == E_SLICK ? 0.9f : 0.45f;
                if (i == eOwner[e] && eAge[e] < armed) continue;
                if (k.invuln > 0f && type != E_SLICK) continue;
                float dx = k.x - ex[e], dz = k.z - ez[e];
                if (dx * dx + dz * dz < rad * rad && Math.abs(k.y - ey[e]) < 3f) {
                    hitKart(i, type == E_SLICK ? Kart.HIT_OIL : Kart.HIT_SPIN, eOwner[e], ex[e], ey[e], ez[e]);
                    killEntity(e, type != E_SLICK);
                    break;
                }
            }
        }
    }

    private void hitKart(int slot, int kind, int src, float x, float y, float z) {
        Kart k = karts[slot];
        if (net != null) {
            Msg.Hit h = new Msg.Hit();
            h.slot = slot; h.kind = kind; h.src = src; h.x = x; h.y = y; h.z = z;
            net.sendReliable(h);
        }
        if (k.ctrl != Kart.CTRL_REMOTE) k.applyHit(kind, fx);
        else fx.add(FxEvents.EXPLODE, x, y, z, 0f);
    }

    // ------------------------------------------------------------------ race end

    private void checkRaceEnd() {
        boolean humansDone = true, allDone = true;
        for (int i = 0; i < nKarts; i++) {
            Kart k = karts[i];
            if (!k.finished) { allDone = false; if (isHuman(k)) humansDone = false; }
        }
        if (!humansDone) {
            if (firstFinishTime >= 0f && raceTime - firstFinishTime > 60f) endRace();
            return;
        }
        float grace = role == ROLE_OFFLINE ? 25f : 8f;
        if (allDone || raceTime - lastHumanFinish > grace) endRace();
    }

    public void endRace() {
        if (phase == PH_ENDED) return;
        updateRanks();
        List<ResultRow> rows = new ArrayList<ResultRow>();
        for (int i = 0; i < nKarts; i++) {
            Kart k = karts[order[i]];
            ResultRow r = new ResultRow();
            r.slot = k.slot; r.place = i + 1; r.name = k.name; r.ai = parts[k.slot].ai || tookOver[k.slot];
            r.timeMs = k.finished ? (int) (k.finishTime * 1000f) : -1;
            rows.add(r);
        }
        results = rows;
        phase = PH_ENDED;
        if (role == ROLE_HOST && net != null) {
            Msg.Results m = new Msg.Results();
            m.rows = rows.toArray(new ResultRow[0]);
            net.sendReliable(m);
        }
    }

    // ------------------------------------------------------------------ networking

    private Msg.KartNet kartNet(Kart k, int stamp) {
        Msg.KartNet n = new Msg.KartNet();
        n.slot = k.slot; n.stamp = stamp; n.flags = k.flags(); n.crossings = k.crossings;
        n.x = k.x; n.y = k.y; n.z = k.z; n.yaw = k.yaw; n.vx = k.vx; n.vy = k.vy; n.vz = k.vz;
        return n;
    }

    private void netTick(float dt) {
        if (net == null || phase == PH_ENDED && role == ROLE_CLIENT) return;
        netAcc += dt;
        if (netAcc < 1f / 30f) return;
        netAcc = 0f;
        int now = nowMs();
        if (role == ROLE_CLIENT) {
            net.sendFast(new Msg.State(kartNet(karts[localSlot], now)));
        } else if (role == ROLE_HOST) {
            Msg.Snapshot s = new Msg.Snapshot();
            s.seq = snapSeq++; s.stamp = now;
            s.karts = new Msg.KartNet[nKarts];
            for (int i = 0; i < nKarts; i++) {
                Kart k = karts[i];
                s.karts[i] = (k.ctrl == Kart.CTRL_REMOTE && lastNet[i] != null) ? lastNet[i] : kartNet(k, now);
            }
            int c = 0;
            for (int e = 0; e < MAXE; e++) if (eAlive[e]) c++;
            s.ents = new Msg.EntNet[c];
            c = 0;
            for (int e = 0; e < MAXE; e++) {
                if (!eAlive[e]) continue;
                Msg.EntNet n = new Msg.EntNet();
                n.id = eId[e]; n.type = eType[e]; n.owner = eOwner[e]; n.x = ex[e]; n.y = ey[e]; n.z = ez[e];
                n.vx = evx[e]; n.vy = evy[e]; n.vz = evz[e]; n.yaw = eYaw[e];
                s.ents[c++] = n;
            }
            net.sendFast(s);
        }
    }

    private void pollNet() {
        if (net == null) return;
        Msg m;
        int guard = 0;
        while ((m = net.poll()) != null && guard++ < 500) handle(m);
    }

    private void handle(Msg m) {
        switch (m.type()) {
            case Msg.STATE: {
                if (role != ROLE_HOST) return;
                Msg.KartNet s = ((Msg.State) m).k;
                if (s.slot < 0 || s.slot >= nKarts) return;
                Kart k = karts[s.slot];
                if (k.ctrl != Kart.CTRL_REMOTE) return;
                lastNet[s.slot] = s;
                k.pushRemote(s.stamp, s.x, s.y, s.z, s.yaw, s.vx, s.vy, s.vz, s.flags);
                break;
            }
            case Msg.SNAPSHOT: {
                if (role != ROLE_CLIENT) return;
                Msg.Snapshot s = (Msg.Snapshot) m;
                for (Msg.KartNet n : s.karts) {
                    if (n.slot < 0 || n.slot >= nKarts) continue;
                    Kart k = karts[n.slot];
                    if (n.slot == localSlot) {
                        if (resyncNeeded) {
                            resyncNeeded = false;
                            k.place(n.x, n.y, n.z, n.yaw);
                            k.vx = n.vx; k.vz = n.vz; k.crossings = n.crossings;
                            locate(k, true);
                            k.furthest = k.s;
                            k.invuln = 2f;
                        }
                        continue;
                    }
                    k.pushRemote(n.stamp, n.x, n.y, n.z, n.yaw, n.vx, n.vy, n.vz, n.flags);
                    k.crossings = n.crossings;
                }
                Arrays.fill(eAlive, false);
                int c = 0;
                for (Msg.EntNet n : s.ents) {
                    if (c >= MAXE) break;
                    eAlive[c] = true; eId[c] = n.id; eType[c] = n.type; eOwner[c] = n.owner;
                    ex[c] = n.x; ey[c] = n.y; ez[c] = n.z; evx[c] = n.vx; evy[c] = n.vy; evz[c] = n.vz; eYaw[c] = n.yaw;
                    c++;
                }
                break;
            }
            case Msg.PICKUP: {
                if (role != ROLE_HOST) return;
                Msg.Pickup p = (Msg.Pickup) m;
                if (p.box >= 0 && p.box < boxActive.length) grantBox(p.from, p.box);
                break;
            }
            case Msg.BOX_TAKEN: {
                Msg.BoxTaken b = (Msg.BoxTaken) m;
                if (role != ROLE_CLIENT || b.box < 0 || b.box >= boxActive.length) return;
                boxActive[b.box] = false;
                boxRespawn[b.box] = raceTime + 4f;
                fx.add(FxEvents.ITEM_PICK, track.boxX[b.box], track.boxY[b.box], track.boxZ[b.box], b.slot);
                if (b.slot == localSlot) karts[localSlot].item = b.item;
                break;
            }
            case Msg.USE_ITEM: {
                if (role != ROLE_HOST) return;
                Msg.UseItem u = (Msg.UseItem) m;
                if (u.from >= 0 && u.from < nKarts) spawnEntity(u.item, u.from, u.x, u.y, u.z, u.yaw, u.speed);
                break;
            }
            case Msg.HIT: {
                if (role != ROLE_CLIENT) return;
                Msg.Hit h = (Msg.Hit) m;
                fx.add(FxEvents.EXPLODE, h.x, h.y, h.z, 0f);
                if (h.slot == localSlot) karts[localSlot].applyHit(h.kind, fx);
                break;
            }
            case Msg.DESTROY: {
                int id = ((Msg.Destroy) m).id;
                if (id >= 0 && id < crateAlive.length && crateAlive[id]) {
                    crateAlive[id] = false;
                    com.kartracer.world.TrackData.Crate c = track.crates[id];
                    fx.add(FxEvents.SMASH, c.x, c.y + 0.5f, c.z, 12f);
                }
                break;
            }
            case Msg.FINISHED: {
                if (role != ROLE_HOST) return;
                Msg.Finished f = (Msg.Finished) m;
                if (f.from >= 0 && f.from < nKarts && karts[f.from].ctrl == Kart.CTRL_REMOTE) finish(karts[f.from], f.timeMs / 1000f);
                break;
            }
            case Msg.RESULTS: {
                if (role != ROLE_CLIENT) return;
                Msg.Results r = (Msg.Results) m;
                results = new ArrayList<ResultRow>(Arrays.asList(r.rows));
                phase = PH_ENDED;
                break;
            }
            case Msg.STATUS: {
                if (role != ROLE_HOST) return;
                Msg.Status s = (Msg.Status) m;
                if (s.slot < 0 || s.slot >= nKarts || s.slot == localSlot) return;
                Kart k = karts[s.slot];
                if (s.status == 2) { k.ctrl = Kart.CTRL_REMOTE; tookOver[s.slot] = false; k.clearRemote(); lastNet[s.slot] = null; }
                else if (k.ctrl == Kart.CTRL_REMOTE) {
                    k.ctrl = Kart.CTRL_AI; tookOver[s.slot] = true;
                    ai[s.slot] = new AiDriver(s.slot * 71L + 3, cfg.difficulty, 1);
                    k.in.clear();
                }
                break;
            }
            default: break;
        }
    }

    /** Client: current extrapolated entity position for rendering. */
    public void entityPos(int e, float[] out) {
        out[0] = ex[e]; out[1] = ey[e]; out[2] = ez[e];
    }

    /** Called per frame on clients so entities keep moving between snapshots. */
    public void advanceEntitiesClient(float dt) {
        if (role != ROLE_CLIENT) return;
        for (int e = 0; e < MAXE; e++) if (eAlive[e] && eType[e] != E_SLICK) { ex[e] += evx[e] * dt; ez[e] += evz[e] * dt; }
    }

    public int humanCount() {
        int c = 0;
        for (int i = 0; i < nKarts; i++) if (isHuman(karts[i])) c++;
        return c;
    }
}
