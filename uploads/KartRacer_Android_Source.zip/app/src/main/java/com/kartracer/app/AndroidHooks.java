package com.kartracer.app;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;

import com.kartracer.net.PlatformHooks;
import com.kartracer.util.Diag;

/** Android specifics for the LAN code: multicast lock and DHCP broadcast address. */
public final class AndroidHooks implements PlatformHooks {
    private final Context ctx;
    private WifiManager.MulticastLock lock;

    public AndroidHooks(Context c) { ctx = c.getApplicationContext(); }

    private WifiManager wifi() { return (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE); }

    @Override
    public synchronized void acquireMulticastLock() {
        try {
            WifiManager wm = wifi();
            if (wm == null) return;
            if (lock == null) { lock = wm.createMulticastLock("kartracer-lan"); lock.setReferenceCounted(false); }
            if (!lock.isHeld()) lock.acquire();
        } catch (Exception e) {
            Diag.err("Net", "multicast lock", e);
        }
    }

    @Override
    public synchronized void releaseMulticastLock() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
    }

    @Override
    @SuppressWarnings("deprecation")
    public String[] extraBroadcastAddresses() {
        try {
            WifiManager wm = wifi();
            DhcpInfo d = wm == null ? null : wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                int bc = (d.ipAddress & d.netmask) | ~d.netmask;
                return new String[]{(bc & 255) + "." + ((bc >> 8) & 255) + "." + ((bc >> 16) & 255) + "." + ((bc >> 24) & 255)};
            }
        } catch (Exception ignored) { }
        return new String[0];
    }
}
