package com.gameshell

import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Serves every GET resource from [assetStore] once it has been
 * fetched once, so a game's assets are downloaded exactly one time
 * and every later play loads entirely from local storage. Non-GET
 * requests (leaderboards, save APIs, anything dynamic) always pass
 * straight through to the network untouched.
 */
class CachingWebViewClient(private val assetStore: GameAssetStore) : WebViewClient() {

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        if (request.method != "GET") return null

        val url = request.url.toString()

        assetStore.get(url)?.let { cached ->
            return WebResourceResponse(cached.mimeType, null, FileInputStream(cached.bodyFile))
        }

        return fetchAndCache(url, request.requestHeaders)
    }

    private fun fetchAndCache(url: String, headers: Map<String, String>): WebResourceResponse? {
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
                CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
                connectTimeout = 15_000
                readTimeout = 15_000
                connect()
            }

            if (connection.responseCode !in 200..299) return null

            val mimeType = connection.contentType?.substringBefore(";")?.trim()
                ?: guessMimeType(url)
            val bytes = connection.inputStream.use { it.readBytes() }

            assetStore.put(url, mimeType, bytes)
            WebResourceResponse(mimeType, null, ByteArrayInputStream(bytes))
        } catch (e: Exception) {
            null // fall back to WebView's own network handling
        }
    }

    private fun guessMimeType(url: String): String =
        MimeTypeMap.getFileExtensionFromUrl(url)
            ?.let { MimeTypeMap.getSingleton().getMimeTypeFromExtension(it) }
            ?: "application/octet-stream"
}
