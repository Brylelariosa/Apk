package com.gameshell

object GameConfig {

    /**
     * URL of the web game to load. Change this and push to point the
     * app at a different game.
     */
    const val GAME_URL = "https://example.com/your-game/index.html"

    /**
     * Bump this by 1 whenever the hosted game updates and the app
     * needs to fetch fresh copies of every asset instead of serving
     * the ones already saved on-device. Old cached versions are
     * deleted automatically the next time the app runs.
     */
    const val CACHE_VERSION = 1

    /**
     * Shows the game's JS console output (log/warn/error) as an
     * on-screen overlay. There's no ADB in this workflow, so this is
     * the way to see script errors on-device. Leave false for normal
     * play.
     */
    const val DEBUG_CONSOLE_ENABLED = false
}
