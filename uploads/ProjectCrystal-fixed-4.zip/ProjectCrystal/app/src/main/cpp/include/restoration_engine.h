#pragma once

#include "image_buffer.h"
#include "restoration_params.h"

namespace crystal {

// Per-stage wall-clock timings (milliseconds), summed across every tile.
// Surfaced in Debug Mode so the user can see where processing time goes.
struct ProcessingStats {
    double analysisMs = 0.0;       // Stage 1/2: blur/noise/frequency estimation
    double candidateGenMs = 0.0;   // Stage 3: Wiener / Richardson-Lucy / edge-aware / texture candidates
    double consensusMs = 0.0;      // Stage 4
    double artifactMs = 0.0;       // Stage 6
    double frequencyGateMs = 0.0;  // Stage 7
    double realityLockMs = 0.0;    // Stage 8
    double blendMs = 0.0;          // tile reassembly
    double totalMs = 0.0;
    int tileCount = 0;

    // Mean absolute per-pixel change vs. the original Y channel, in [0,1],
    // area-weighted across tiles, measured *after* each named stage. Every
    // stage only ever pulls the signal further from raw candidateGen output
    // back toward the original (conservative-by-construction), so these are
    // expected to be non-increasing left to right; whichever one drops the
    // most is the stage actually suppressing visible restoration. Exists
    // because a "the result barely changed" report is otherwise
    // undiagnosable without a stack-trace-grade look inside the pipeline,
    // and this device has no adb access to get one any other way (see
    // DiagnosticLog's doc comment) — this is the same idea applied to
    // "why didn't it change" instead of "why did it crash".
    double consensusDelta = 0.0;
    double artifactDelta = 0.0;
    double freqGateDelta = 0.0;
    double realityLockDelta = 0.0;
};

// Stage 9: everything the pipeline produces for a single run — the restored
// image plus the diagnostic maps Debug Mode visualizes.
struct PipelineOutput {
    FloatImage restored;      // 3-channel RGB, [0,1]
    FloatImage blurMap;       // 1-channel, full resolution, blocky-per-tile
    FloatImage noiseMap;      // 1-channel
    FloatImage edgeMap;       // 1-channel
    FloatImage confidenceMap; // 1-channel
    FloatImage artifactMap;   // 1-channel
    float realityScore = 0.0f; // 0..1, whole-image summary
    ProcessingStats stats;
};

// Top-level orchestrator: implements Stages 1-9 of the pipeline described in
// the project spec. Each stage is a separate, independently testable class
// (BlurEstimator, NoiseEstimator, Deconvolution, ConsensusEngine,
// ArtifactDetector, FrequencyAnalyzer, RealityLock, TileProcessor); this
// class's only job is to run them in order, per tile, and reassemble the
// result. Everything happens behind a single JNI call (see jni_bridge.cpp)
// so the Kotlin/JNI boundary is crossed once per image, not once per stage.
class RestorationEngine {
public:
    static PipelineOutput run(const FloatImage& inputRgb, const RestorationParams& params);
};

} // namespace crystal
