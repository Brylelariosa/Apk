package com.projectcrystal.app.ui.editor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.navArgs
import com.projectcrystal.app.R
import com.projectcrystal.app.core.model.ProcessingState
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.FragmentEditorBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import com.projectcrystal.app.util.showOnce
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * The main editing surface: image preview (zoomable, or before/after
 * compare), the progress overlay while a restoration is running, and the
 * entry points into [ToolBottomSheetFragment] (sliders) and
 * [ExportDialogFragment] (save). All state lives in the shared
 * [EditorViewModel] — this Fragment is a thin renderer of that state plus
 * user-input plumbing, which is what keeps rotation/process-death
 * (ViewModel survives both) from losing the user's in-progress edit.
 *
 * The original and restored bitmaps are decoded once and cached here at the
 * View's lifecycle (not the ViewModel's): both the initial preview and the
 * before/after compare view need the same two bitmaps, and re-decoding a
 * full-resolution image from disk on every compare toggle is wasted work
 * and a redundant allocation. They're released in [onDestroyView].
 */
class EditorFragment : Fragment(), MenuProvider {

    private var _binding: FragmentEditorBinding? = null
    private val binding get() = _binding!!

    private val args: EditorFragmentArgs by navArgs()

    private val editorViewModel: EditorViewModel by activityViewModels {
        ViewModelFactory {
            val appContext = requireContext().applicationContext
            EditorViewModel(appContext, ImageRepository(appContext))
        }
    }

    private var originalBitmap: Bitmap? = null
    private var restoredBitmap: Bitmap? = null
    private var restoredBitmapPath: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEditorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        val sourceUri = Uri.parse(args.sourceUri)
        editorViewModel.setSourceImage(sourceUri)
        loadPreview()

        if (args.historyEntryId >= 0) loadHistoryParams(args.historyEntryId)

        binding.openToolsButton.setOnClickListener {
            childFragmentManager.showOnce(ToolBottomSheetFragment(), ToolBottomSheetFragment.TAG)
        }
        binding.restoreButton.setOnClickListener { editorViewModel.startRestoration() }
        binding.cancelButton.setOnClickListener { editorViewModel.cancelRestoration() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                editorViewModel.processingState.collect(::renderState)
            }
        }
    }

    private fun loadPreview() {
        lifecycleScope.launch {
            runCatching { editorViewModel.decodeOriginal() }
                .onSuccess { bitmap ->
                    setOriginalBitmap(bitmap)
                    binding.previewImage.setImageBitmap(bitmap)
                    binding.previewImage.resetToFit()
                }
                .onFailure { showEditorMessage(getString(R.string.editor_load_failed)) }
        }
    }

    private fun loadHistoryParams(historyEntryId: Long) {
        lifecycleScope.launch { editorViewModel.loadHistoryParams(historyEntryId) }
    }

    private suspend fun renderState(state: ProcessingState) {
        val isBusy = state is ProcessingState.Analyzing || state is ProcessingState.Processing
        binding.progressIndicator.setVisibleOrGone(isBusy)
        binding.progressLabel.setVisibleOrGone(isBusy)
        binding.cancelButton.setVisibleOrGone(isBusy)
        binding.restoreButton.isEnabled = !isBusy

        when (state) {
            is ProcessingState.Analyzing -> {
                binding.progressIndicator.isIndeterminate = false
                binding.progressIndicator.setProgressCompat((state.progress * 100).roundToInt(), true)
                binding.progressLabel.text = getString(R.string.processing_analyzing)
            }
            is ProcessingState.Processing -> {
                binding.progressIndicator.isIndeterminate = false
                binding.progressIndicator.setProgressCompat((state.progress * 100).roundToInt(), true)
                binding.progressLabel.text = state.stageLabel
            }
            is ProcessingState.Done -> showRestoredResult(state)
            is ProcessingState.Failed -> showEditorMessage(getString(R.string.processing_failed, state.message))
            ProcessingState.Cancelled, ProcessingState.Idle -> Unit
        }
    }

    /** Decodes the restored image at most once per result (a StateFlow re-delivers its current value to every new collector, e.g. after the app is backgrounded and foregrounded again). */
    private suspend fun showRestoredResult(state: ProcessingState.Done) {
        if (restoredBitmapPath != state.result.restoredImagePath) {
            val restored = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(state.result.restoredImagePath) }
            if (restored == null) {
                showEditorMessage(getString(R.string.editor_load_failed))
                return
            }
            setRestoredBitmap(restored)
            restoredBitmapPath = state.result.restoredImagePath
            // CompareSliderView keeps its own reference to whatever bitmap
            // was last handed to it; if the user re-runs restoration while
            // the compare view happens to be the visible one, the bitmap it
            // was drawing just got recycled by setRestoredBitmap() above.
            // Keep it in sync unconditionally (harmless no-op if the view
            // isn't currently visible) rather than only on the next
            // explicit toggle.
            binding.compareView.afterBitmap = restored
        }
        restoredBitmap?.let { bitmap ->
            binding.previewImage.setImageBitmap(bitmap)
            binding.previewImage.resetToFit()
        }
    }

    private fun setOriginalBitmap(bitmap: Bitmap) {
        if (originalBitmap !== bitmap) originalBitmap?.recycle()
        originalBitmap = bitmap
    }

    private fun setRestoredBitmap(bitmap: Bitmap) {
        if (restoredBitmap !== bitmap) restoredBitmap?.recycle()
        restoredBitmap = bitmap
    }

    private fun showEditorMessage(message: String) {
        (activity as? com.projectcrystal.app.ui.main.MainActivity)?.showMessage(message)
    }

    // ---- MenuProvider: Compare / Export -----------------------------------

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.editor_toolbar_menu, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean = when (menuItem.itemId) {
        R.id.action_compare -> {
            toggleCompareView()
            true
        }
        R.id.action_export -> {
            childFragmentManager.showOnce(ExportDialogFragment(), ExportDialogFragment.TAG)
            true
        }
        else -> false
    }

    private fun toggleCompareView() {
        val showingCompare = binding.compareView.visibility == View.VISIBLE
        if (showingCompare) {
            binding.compareView.setVisibleOrGone(false)
            binding.previewImage.setVisibleOrGone(true)
            return
        }
        val before = originalBitmap
        val after = restoredBitmap
        if (before == null || after == null) return // nothing to compare yet; both are already loading via loadPreview()/renderState()
        binding.compareView.beforeBitmap = before
        binding.compareView.afterBitmap = after
        binding.previewImage.setVisibleOrGone(false)
        binding.compareView.setVisibleOrGone(true)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        originalBitmap?.recycle()
        if (restoredBitmap !== originalBitmap) restoredBitmap?.recycle()
        originalBitmap = null
        restoredBitmap = null
        restoredBitmapPath = null
        _binding = null
    }
}
