package com.game.topdown;

public class Gun {
    public String name;
    public int    maxAmmo, ammo;
    public float  fireRate, damage, bulletSpeed, spread;
    public int    pellets, color;
    public long   reloadMs;

    // runtime state
    public boolean reloading;
    public long    reloadStart, lastFireTime;

    public boolean canFireNow() {
        if (ammo <= 0 || reloading) return false;
        return System.currentTimeMillis() - lastFireTime >= (long)(1000f / fireRate);
    }
    public void markFired() { lastFireTime = System.currentTimeMillis(); }

    public void startReload() {
        if (!reloading && ammo < maxAmmo) { reloading = true; reloadStart = System.currentTimeMillis(); }
    }
    public void tick() {
        if (reloading && System.currentTimeMillis() - reloadStart >= reloadMs) {
            ammo = maxAmmo; reloading = false;
        }
    }

    public static Gun[] createAll() {
        return new Gun[]{pistol(), smg(), shotgun(), assault(), sniper(), burst(), minigun()};
    }

    // 1. Pistol
    public static Gun pistol() {
        Gun g=new Gun(); g.name="Pistol"; g.maxAmmo=12; g.ammo=12;
        g.fireRate=3f; g.damage=34f; g.bulletSpeed=640f;
        g.pellets=1; g.spread=0.04f; g.reloadMs=1200; g.color=0xFF4FC3F7; return g;
    }
    // 2. SMG
    public static Gun smg() {
        Gun g=new Gun(); g.name="SMG"; g.maxAmmo=30; g.ammo=30;
        g.fireRate=10f; g.damage=14f; g.bulletSpeed=520f;
        g.pellets=1; g.spread=0.12f; g.reloadMs=2000; g.color=0xFF81C784; return g;
    }
    // 3. Shotgun
    public static Gun shotgun() {
        Gun g=new Gun(); g.name="Shotgun"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.1f; g.damage=18f; g.bulletSpeed=480f;
        g.pellets=6; g.spread=0.32f; g.reloadMs=2400; g.color=0xFFFF8A65; return g;
    }
    // 4. Assault Rifle
    public static Gun assault() {
        Gun g=new Gun(); g.name="Assault"; g.maxAmmo=25; g.ammo=25;
        g.fireRate=7.5f; g.damage=19f; g.bulletSpeed=590f;
        g.pellets=1; g.spread=0.07f; g.reloadMs=1800; g.color=0xFFFFB347; return g;
    }
    // 5. Sniper
    public static Gun sniper() {
        Gun g=new Gun(); g.name="Sniper"; g.maxAmmo=5; g.ammo=5;
        g.fireRate=0.8f; g.damage=95f; g.bulletSpeed=980f;
        g.pellets=1; g.spread=0.005f; g.reloadMs=2800; g.color=0xFFCE93D8; return g;
    }
    // 6. Burst Rifle (3 tight pellets per shot)
    public static Gun burst() {
        Gun g=new Gun(); g.name="Burst"; g.maxAmmo=24; g.ammo=24;
        g.fireRate=3f; g.damage=22f; g.bulletSpeed=610f;
        g.pellets=3; g.spread=0.035f; g.reloadMs=2000; g.color=0xFF4DD0E1; return g;
    }
    // 7. Minigun
    public static Gun minigun() {
        Gun g=new Gun(); g.name="Minigun"; g.maxAmmo=120; g.ammo=120;
        g.fireRate=18f; g.damage=9f; g.bulletSpeed=540f;
        g.pellets=1; g.spread=0.22f; g.reloadMs=4500; g.color=0xFFFF5252; return g;
    }
}
