# Rubik AI Lab - PROJECT STATE

Version 2.1 - 2026-10-21

## Owner constraints
- DO NOT use GitHub. Owner uploads the final ZIP himself. His GitHub Actions workflow ("Build APK") unzips the newest ZIP under uploads/, finds settings.gradle, and runs ./gradlew assembleDebug (JDK 17, Gradle 8.6, NDK 25.2.9519653, CMake 3.22.1).
- No fake learning: no prerecorded solutions, no fabricated stats. Conventional-solver benchmarks are reported separately from the learned model.
- CI-compatible layout: app/src/main/cpp/{CMakeLists.txt, jni_bridge.cpp, core/*.cpp|*.h} (core/ is flat because the CI cache key hashes core/*.cpp).
- Stack: Kotlin UI (framework views only, no AndroidX) + OpenGL ES 2.0 renderer + native C++17 core via JNI.

## Done in v2 (see CHANGELOG.md, AI_DESIGN.md)
- [x] Generic puzzle core (2x2, 3x3, 4x4, 5x5, Pyraminx, Skewb), host-tested against known group facts
- [x] Piece encoder, network, pool-based value-iteration trainer, weighted A*, per-puzzle engines and checkpoints
- [x] Canonical-frame solving for puzzles that can be turned as a whole (verified with all-move scrambles)
- [x] JNI bridge, Kotlin app: Play (swipe, timer), Train (live AI practice, thermal governor), Test (held-out / fresh)
- [x] Docs, host tests (tests/), sanitizer runs
- Android build verified: NO. CI run 1868 (release build): native C++ built for all four ABIs, then Kotlin failed on one error
  (PlayPage.kt: `timerView` used by the timer Runnable before init assigned it). Fixed in v2.1; the rebuild is the next check.
  The authoring sandbox has no Android SDK or Kotlin compiler, so nothing Kotlin is compiled here; CI is the owner's.

## Known limits
- 4x4 and 5x5 are play-only. The learned AI handles scrambles up to roughly depth 14 to 16 on the 3x3; fully random cubes need much more training than a phone session.
- Checkpoints from v1 (checkpoint.bin) are not loaded.
