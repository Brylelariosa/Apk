# Changelog

## v2.1 (2026-10-21)
- Build fix: CI run 1868 (release build) stopped in compileReleaseKotlin with
  `PlayPage.kt:66:17 Variable 'timerView' must be initialized`. The timer Runnable (`ticker`) was declared
  above the `init` block that assigns `timerView`; it now sits below that block. No behaviour change.
- That run had already built the native library for all four ABIs (x86, x86_64, arm64-v8a, armeabi-v7a)
  without errors, so only the Kotlin step was left to fix. The rebuild has not been run yet.

## v2
- Six puzzles: 2x2, 3x3, 4x4, 5x5, Pyraminx, Skewb, all built from one generic geometry-driven model.
  The 3x3 now also has middle-layer turns.
- AI for 2x2, 3x3, Pyraminx and Skewb with one network and checkpoint per puzzle.
- Training: pool-based value iteration (each expensive target is reused for several gradient steps),
  newest-depth sampling, deeper default curriculum for the 3x3 (16), progress reporting per round.
- Heat: Cool / Balanced / Fast presets, thermal governor with duty cycling, background priority, thread caps.
- Train tab: live view of the AI practising on fresh scrambles, round progress, chart, temperature and effort.
- Play tab: swipe to turn layers, drag to look around, timer with personal bests, turn pad, AI solve.
- Test tab: held-out or fresh scrambles, learned AI or conventional baseline, saved results.
- Layout: every main control fits on one screen without scrolling; vector icons; bottom navigation.
- Checkpoints are now per puzzle (checkpoint_<id>.bin, format version 3). The v1 checkpoint is not read.
