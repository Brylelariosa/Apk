# Build and test

## Android (the owner's CI)
`./gradlew assembleDebug` (JDK 17, Gradle 8.6, NDK 25.2.9519653, CMake 3.22.1). minSdk 24, framework views only
(no AndroidX). The native library is built from `app/src/main/cpp/CMakeLists.txt`.

## Host tests of the native core (g++, no Android needed)
```
sh tests/run_host_tests.sh          # puzzle tests + engine end-to-end test
sh tests/run_host_tests.sh full     # also the full state-count checks (2x2, Skewb, Pyraminx)
```
`tests/bench.cpp` trains a puzzle for N seconds and prints solve rates:
`g++ -std=c++17 -O3 -fno-math-errno -Iapp/src/main/cpp tests/bench.cpp app/src/main/cpp/core/*.cpp -o bench -pthread`
then `./bench <puzzleId 0..5> <seconds> <threads> [maxDepth] [pool] [maxEpochs] [frontierMix]`.

## What was and was not verified (v2)
- Verified on the host: puzzle geometry and move tables, group facts and state counts, piece structure,
  canonical-frame solving, solver end-to-end on physical scrambles, checkpoint round trip, AddressSanitizer
  and UBSan runs of the tests.
- Verified by script: swipe-to-move maths (Python mirror of gl/Picker.kt) is consistent with the real rotation
  for five puzzles; vector icons render as intended.
- CI run 1868 (release): all four native ABI builds succeeded (one harmless `-Wunused-private-field` warning for
  `Encoder::puzzle_`); Kotlin failed on PlayPage.kt `timerView` init order, fixed in v2.1. No other compiler error was reported.
- NOT verified: the Android build itself. The authoring sandbox had no Android SDK and no Kotlin compiler, so the
  Kotlin code was only linted (imports, brackets) and reviewed by hand. Expect to fix a typo if CI complains.
