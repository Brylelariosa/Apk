// JNI surface of the native core. Package/class: com.rubikailab.app.core.NativeBridge (a Kotlin object,
// so every function receives the singleton as its second argument).
//
// Result layouts (see NativeBridge.kt / Models.kt for the matching decoders):
//   nativeTrain / nativeStats -> double[17]: steps, samples, iterations, depth, loss, mae, accuracy,
//                                samplesPerSec, learningRate, phase, progress, epoch, threads, batch, pool,
//                                maxDepth, chunkSteps
//   nativeSolve    -> int[5 + n]: status, expanded, generated, elapsedMs, n, move_0 .. move_n-1
//   nativeEvaluate -> double[6]: solved, total, avgLength, avgExpanded, avgMs, cancelled(0/1)
//   nativePuzzleInfo -> int[13]: valid, stickers, colors, faces, moves, aiSupported, aiMoveCount, needsCanon,
//                                defaultMaxDepth, bodyPieces, coreTriangles, hidden1, hidden2
//   nativePuzzleStickers -> float[stickers * 20]: cornerCount, 12 corner coordinates, normal(3), centroid(3), colour
//   nativePuzzleMoves    -> float[moves * 8]: axis(3), angleDeg, lo, hi, inverse, isSolverMove
//   nativePuzzleBodies   -> float[]: pieceCount, then per piece: classX, classY, classZ, triangleCount, 12 floats
//                           (3 corners + outward normal) per triangle

#include <jni.h>

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "core/engine.h"
#include "core/puzzle.h"

namespace {

using rubik::Engine;
using rubik::Puzzle;

inline Engine* engineOf(jlong handle) { return reinterpret_cast<Engine*>(handle); }

jdoubleArray packStats(JNIEnv* env, const rubik::TrainStats& s) {
  const jdouble v[17] = {static_cast<jdouble>(s.steps),
                         static_cast<jdouble>(s.samples),
                         static_cast<jdouble>(s.iterations),
                         static_cast<jdouble>(s.depth),
                         static_cast<jdouble>(s.loss),
                         static_cast<jdouble>(s.mae),
                         static_cast<jdouble>(s.accuracy),
                         static_cast<jdouble>(s.samplesPerSec),
                         static_cast<jdouble>(s.lr),
                         static_cast<jdouble>(s.phase),
                         static_cast<jdouble>(s.progress),
                         static_cast<jdouble>(s.epoch),
                         static_cast<jdouble>(s.threads),
                         static_cast<jdouble>(s.batch),
                         static_cast<jdouble>(s.pool),
                         static_cast<jdouble>(s.maxDepth),
                         static_cast<jdouble>(s.chunkSteps)};
  jdoubleArray arr = env->NewDoubleArray(17);
  if (arr != nullptr) env->SetDoubleArrayRegion(arr, 0, 17, v);
  return arr;
}

jintArray packInts(JNIEnv* env, const std::vector<jint>& values) {
  jintArray arr = env->NewIntArray(static_cast<jsize>(values.size()));
  if (arr != nullptr && !values.empty()) {
    env->SetIntArrayRegion(arr, 0, static_cast<jsize>(values.size()), values.data());
  }
  return arr;
}

jfloatArray packFloats(JNIEnv* env, const std::vector<jfloat>& values) {
  jfloatArray arr = env->NewFloatArray(static_cast<jsize>(values.size()));
  if (arr != nullptr && !values.empty()) {
    env->SetFloatArrayRegion(arr, 0, static_cast<jsize>(values.size()), values.data());
  }
  return arr;
}

// Copies a Java byte[] holding exactly `expected` stickers into `out`; false if the size is wrong.
bool readState(JNIEnv* env, jbyteArray state, int expected, uint8_t* out) {
  if (state == nullptr || env->GetArrayLength(state) != expected || expected > rubik::kMaxStickers) return false;
  jbyte raw[rubik::kMaxStickers];
  env->GetByteArrayRegion(state, 0, expected, raw);
  for (int i = 0; i < expected; ++i) out[i] = static_cast<uint8_t>(raw[i]);
  return true;
}

}  // namespace

extern "C" {

// ------------------------------------------------------------------------------------------ puzzles

JNIEXPORT jint JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleCount(JNIEnv*, jobject) {
  return static_cast<jint>(rubik::kPuzzleCount);
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleInfo(JNIEnv* env, jobject, jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jint> out(13, 0);
  if (p != nullptr) {
    out[0] = p->valid ? 1 : 0;
    out[1] = p->stickers;
    out[2] = p->colors;
    out[3] = p->faces;
    out[4] = p->moves;
    out[5] = p->aiSupported ? 1 : 0;
    out[6] = static_cast<jint>(p->aiMoves.size());
    out[7] = p->needsCanon ? 1 : 0;
    out[8] = p->defaultMaxDepth;
    out[9] = static_cast<jint>(p->bodies.size());
    out[10] = static_cast<jint>(p->core.size() / 12);
    out[11] = p->hidden1;
    out[12] = p->hidden2;
  }
  return packInts(env, out);
}

JNIEXPORT jobjectArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStrings(JNIEnv* env, jobject,
                                                                                            jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  jclass stringClass = env->FindClass("java/lang/String");
  if (stringClass == nullptr) return nullptr;
  jobjectArray arr = env->NewObjectArray(3, stringClass, nullptr);
  if (arr == nullptr) return nullptr;
  std::string names;
  std::string full = "?";
  std::string shortName = "?";
  if (p != nullptr) {
    full = p->name;
    shortName = p->shortName;
    for (size_t i = 0; i < p->move.size(); ++i) {
      if (i > 0) names += ' ';
      names += p->move[i].name;
    }
  }
  env->SetObjectArrayElement(arr, 0, env->NewStringUTF(full.c_str()));
  env->SetObjectArrayElement(arr, 1, env->NewStringUTF(shortName.c_str()));
  env->SetObjectArrayElement(arr, 2, env->NewStringUTF(names.c_str()));
  return arr;
}

JNIEXPORT jfloatArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStyle(JNIEnv* env, jobject,
                                                                                         jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jfloat> out = {3.0f, 0.86f, 0.0f};
  if (p != nullptr) out = {p->radius, p->stickerScale, p->stickerLift};
  return packFloats(env, out);
}

JNIEXPORT jfloatArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleStickers(JNIEnv* env, jobject,
                                                                                            jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jfloat> out;
  if (p != nullptr) {
    out.reserve(static_cast<size_t>(p->stickers) * 20);
    for (int i = 0; i < p->stickers; ++i) {
      out.push_back(static_cast<jfloat>(p->vcount[static_cast<size_t>(i)]));
      for (int k = 0; k < 12; ++k) out.push_back(p->verts[static_cast<size_t>(i * 12 + k)]);
      for (int k = 0; k < 3; ++k) out.push_back(p->normal[static_cast<size_t>(i * 3 + k)]);
      for (int k = 0; k < 3; ++k) out.push_back(p->centroid[static_cast<size_t>(i * 3 + k)]);
      out.push_back(static_cast<jfloat>(p->solved[static_cast<size_t>(i)]));
    }
  }
  return packFloats(env, out);
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleFaces(JNIEnv* env, jobject,
                                                                                       jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jint> out;
  if (p != nullptr) {
    for (int i = 0; i < p->stickers; ++i) out.push_back(p->faceOf[static_cast<size_t>(i)]);
  }
  return packInts(env, out);
}

JNIEXPORT jfloatArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleMoves(JNIEnv* env, jobject,
                                                                                         jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jfloat> out;
  if (p != nullptr) {
    for (int m = 0; m < p->moves; ++m) {
      const rubik::MoveInfo& mv = p->move[static_cast<size_t>(m)];
      out.push_back(mv.axis[0]);
      out.push_back(mv.axis[1]);
      out.push_back(mv.axis[2]);
      out.push_back(mv.angleDeg);
      out.push_back(mv.lo);
      out.push_back(mv.hi);
      out.push_back(static_cast<jfloat>(mv.inverse));
      out.push_back(p->aiMove(m) ? 1.0f : 0.0f);
    }
  }
  return packFloats(env, out);
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleMoveTable(JNIEnv* env, jobject,
                                                                                           jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jint> out;
  if (p != nullptr) {
    out.reserve(static_cast<size_t>(p->moves) * static_cast<size_t>(p->stickers));
    for (int m = 0; m < p->moves; ++m) {
      for (int i = 0; i < p->stickers; ++i) out.push_back(p->perm[static_cast<size_t>(m)][static_cast<size_t>(i)]);
    }
  }
  return packInts(env, out);
}

JNIEXPORT jfloatArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleBodies(JNIEnv* env, jobject,
                                                                                          jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jfloat> out;
  if (p != nullptr) {
    out.push_back(static_cast<jfloat>(p->bodies.size()));
    for (const rubik::BodyPiece& b : p->bodies) {
      out.push_back(b.cls[0]);
      out.push_back(b.cls[1]);
      out.push_back(b.cls[2]);
      out.push_back(static_cast<jfloat>(b.tris.size() / 12));
      out.insert(out.end(), b.tris.begin(), b.tris.end());
    }
  }
  return packFloats(env, out);
}

JNIEXPORT jfloatArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativePuzzleCore(JNIEnv* env, jobject,
                                                                                        jint id) {
  const Puzzle* p = rubik::puzzleById(id);
  std::vector<jfloat> out;
  if (p != nullptr) out.assign(p->core.begin(), p->core.end());
  return packFloats(env, out);
}

// ------------------------------------------------------------------------------------------ engines

JNIEXPORT jlong JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeCreate(JNIEnv*, jobject, jint puzzleId,
                                                                               jlong seed) {
  std::unique_ptr<Engine> e = Engine::create(puzzleId, static_cast<uint64_t>(seed));
  return reinterpret_cast<jlong>(e.release());
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeDestroy(JNIEnv*, jobject, jlong handle) {
  delete engineOf(handle);
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeReset(JNIEnv*, jobject, jlong handle,
                                                                             jlong seed) {
  engineOf(handle)->reset(static_cast<uint64_t>(seed));
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeConfigure(JNIEnv*, jobject, jlong handle,
                                                                                 jint batch, jfloat learningRate,
                                                                                 jint maxDepth, jint threads,
                                                                                 jint pool, jfloat frontierMix) {
  Engine* e = engineOf(handle);
  rubik::TrainConfig cfg = e->config();
  cfg.batch = batch;
  cfg.lr = learningRate;
  cfg.maxDepth = maxDepth;
  cfg.threads = threads;
  cfg.pool = pool;
  cfg.frontierMix = frontierMix;
  e->configure(cfg);
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeTrain(JNIEnv* env, jobject,
                                                                                     jlong handle, jint budgetMs) {
  return packStats(env, engineOf(handle)->train(budgetMs));
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeStats(JNIEnv* env, jobject,
                                                                                     jlong handle) {
  return packStats(env, engineOf(handle)->stats());
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSolve(
    JNIEnv* env, jobject, jlong handle, jint mode, jbyteArray state, jint maxExpansions, jfloat lambda,
    jint timeoutMs) {
  Engine* e = engineOf(handle);
  std::vector<jint> out;
  uint8_t puzzle[rubik::kMaxStickers];
  if (!readState(env, state, e->puzzle().stickers, puzzle)) {
    out = {rubik::kInvalid, 0, 0, 0, 0};
    return packInts(env, out);
  }

  rubik::SearchConfig cfg;
  cfg.maxExpansions = maxExpansions;
  cfg.lambda = lambda;
  cfg.timeoutMs = timeoutMs;
  const rubik::SearchResult r = e->solve(mode, puzzle, cfg);

  out.reserve(5 + r.moves.size());
  out.push_back(r.status);
  out.push_back(r.expanded);
  out.push_back(r.generated);
  out.push_back(r.elapsedMs);
  out.push_back(static_cast<jint>(r.moves.size()));
  for (uint8_t m : r.moves) out.push_back(static_cast<jint>(m));
  return packInts(env, out);
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeEvaluate(
    JNIEnv* env, jobject, jlong handle, jint mode, jint depth, jint cases, jint maxExpansions, jfloat lambda,
    jint timeoutMs, jlong freshSeed) {
  rubik::SearchConfig cfg;
  cfg.maxExpansions = maxExpansions;
  cfg.lambda = lambda;
  cfg.timeoutMs = timeoutMs;
  const rubik::EvalResult r =
      engineOf(handle)->evaluate(mode, depth, cases, cfg, static_cast<uint64_t>(freshSeed));
  const jdouble v[6] = {static_cast<jdouble>(r.solved), static_cast<jdouble>(r.total), r.avgLength,
                        r.avgExpanded,                  r.avgMs,                       r.cancelled ? 1.0 : 0.0};
  jdoubleArray arr = env->NewDoubleArray(6);
  if (arr != nullptr) env->SetDoubleArrayRegion(arr, 0, 6, v);
  return arr;
}

JNIEXPORT jfloat JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeEstimate(JNIEnv* env, jobject,
                                                                                  jlong handle, jbyteArray state) {
  Engine* e = engineOf(handle);
  uint8_t puzzle[rubik::kMaxStickers];
  if (!readState(env, state, e->puzzle().stickers, puzzle)) return -1.0f;
  return e->estimate(puzzle);
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSetCancel(JNIEnv*, jobject, jlong handle,
                                                                                 jboolean cancel) {
  engineOf(handle)->setCancel(cancel == JNI_TRUE);
}

JNIEXPORT jboolean JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSave(JNIEnv* env, jobject, jlong handle,
                                                                                jstring path) {
  if (path == nullptr) return JNI_FALSE;
  const char* chars = env->GetStringUTFChars(path, nullptr);
  if (chars == nullptr) return JNI_FALSE;
  const bool ok = engineOf(handle)->save(chars);
  env->ReleaseStringUTFChars(path, chars);
  return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeLoad(JNIEnv* env, jobject, jlong handle,
                                                                                jstring path) {
  if (path == nullptr) return JNI_FALSE;
  const char* chars = env->GetStringUTFChars(path, nullptr);
  if (chars == nullptr) return JNI_FALSE;
  const bool ok = engineOf(handle)->load(chars);
  env->ReleaseStringUTFChars(path, chars);
  return ok ? JNI_TRUE : JNI_FALSE;
}

}  // extern "C"
