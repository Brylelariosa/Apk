#include "puzzle.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <memory>
#include <mutex>
#include <numeric>

namespace rubik {
namespace {

struct V3 {
  float x, y, z;
};

inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline float length(V3 a) { return std::sqrt(dot(a, a)); }

inline V3 unit(V3 a) {
  const float l = length(a);
  return l > 0.f ? a * (1.f / l) : a;
}

const float kMatchTol = 2.0e-3f;   // centre / normal matching
const float kLayerTol = 1.0e-3f;   // layer membership

// v rotated by angleDeg about the unit axis a (right-hand rule).
V3 rotateAbout(V3 a, float angleDeg, V3 v) {
  const double th = static_cast<double>(angleDeg) * 3.14159265358979323846 / 180.0;
  const float c = static_cast<float>(std::cos(th));
  const float s = static_cast<float>(std::sin(th));
  return v * c + cross(a, v) * s + a * (dot(a, v) * (1.f - c));
}

V3 centroidOf(const Puzzle& p, int i) {
  return {p.centroid[static_cast<size_t>(i * 3)], p.centroid[static_cast<size_t>(i * 3 + 1)],
          p.centroid[static_cast<size_t>(i * 3 + 2)]};
}

V3 normalOf(const Puzzle& p, int i) {
  return {p.normal[static_cast<size_t>(i * 3)], p.normal[static_cast<size_t>(i * 3 + 1)],
          p.normal[static_cast<size_t>(i * 3 + 2)]};
}

V3 vertexOf(const Puzzle& p, int i, int k) {
  const size_t o = static_cast<size_t>(i * 12 + k * 3);
  return {p.verts[o], p.verts[o + 1], p.verts[o + 2]};
}

V3 axisOf(const MoveInfo& m) { return {m.axis[0], m.axis[1], m.axis[2]}; }

bool inLayer(const MoveInfo& m, V3 point) {
  const float pr = dot(point, axisOf(m));
  return pr >= m.lo - kLayerTol && pr <= m.hi + kLayerTol;
}

// ------------------------------------------------------------------------------------------ building blocks

// Corners are counter-clockwise as seen from outside, so the first three give the outward normal.
void addSticker(Puzzle& p, int color, int face, const V3* v, int n) {
  V3 c = {0.f, 0.f, 0.f};
  for (int k = 0; k < 4; ++k) {
    const V3 q = v[k < n ? k : n - 1];
    p.verts.push_back(q.x);
    p.verts.push_back(q.y);
    p.verts.push_back(q.z);
  }
  for (int k = 0; k < n; ++k) c = c + v[k];
  c = c * (1.f / static_cast<float>(n));
  const V3 nrm = unit(cross(v[1] - v[0], v[2] - v[0]));
  p.vcount.push_back(static_cast<uint8_t>(n));
  p.normal.push_back(nrm.x);
  p.normal.push_back(nrm.y);
  p.normal.push_back(nrm.z);
  p.centroid.push_back(c.x);
  p.centroid.push_back(c.y);
  p.centroid.push_back(c.z);
  p.solved.push_back(static_cast<uint8_t>(color));
  p.faceOf.push_back(static_cast<uint8_t>(face));
  p.stickers += 1;
}

// Adds a clockwise / counter-clockwise pair of turns of one layer.
void addMovePair(Puzzle& p, const std::string& name, V3 axis, float stepDeg, float lo, float hi) {
  const int base = static_cast<int>(p.move.size());
  const V3 a = unit(axis);
  for (int dir = 0; dir < 2; ++dir) {
    MoveInfo m;
    m.axis[0] = a.x;
    m.axis[1] = a.y;
    m.axis[2] = a.z;
    m.angleDeg = dir == 0 ? -stepDeg : stepDeg;
    m.lo = lo;
    m.hi = hi;
    m.inverse = base + (1 - dir);
    m.name = dir == 0 ? name : name + "'";
    p.move.push_back(m);
  }
  p.moves = static_cast<int>(p.move.size());
}

void addOrientedTri(BodyPiece& bp, V3 a, V3 b, V3 c, V3 interior) {
  V3 n = unit(cross(b - a, c - a));
  const V3 mid = (a + b + c) * (1.f / 3.f);
  if (dot(n, mid - interior) < 0.f) n = n * -1.f;
  const V3 pts[3] = {a, b, c};
  for (const V3& q : pts) {
    bp.tris.push_back(q.x);
    bp.tris.push_back(q.y);
    bp.tris.push_back(q.z);
  }
  bp.tris.push_back(n.x);
  bp.tris.push_back(n.y);
  bp.tris.push_back(n.z);
}

// Dark solid under one sticker: the sticker polygon pushed slightly below its plane, tapering towards the
// puzzle centre. Pieces made of these look solid and need no knowledge of the real piece shapes.
void addFrustumBody(Puzzle& p, int sticker, float inward) {
  const int n = p.vcount[static_cast<size_t>(sticker)];
  const V3 nrm = normalOf(p, sticker);
  V3 top[4];
  V3 bot[4];
  V3 tc = {0.f, 0.f, 0.f};
  V3 bc = {0.f, 0.f, 0.f};
  for (int k = 0; k < n; ++k) {
    const V3 v = vertexOf(p, sticker, k);
    top[k] = v - nrm * 0.006f;
    bot[k] = v * (1.f - inward);
    tc = tc + top[k];
    bc = bc + bot[k];
  }
  tc = tc * (1.f / static_cast<float>(n));
  bc = bc * (1.f / static_cast<float>(n));
  const V3 interior = (tc + bc) * 0.5f;
  BodyPiece bp;
  const V3 c = centroidOf(p, sticker);
  bp.cls[0] = c.x;
  bp.cls[1] = c.y;
  bp.cls[2] = c.z;
  for (int k = 1; k + 1 < n; ++k) {
    addOrientedTri(bp, top[0], top[k], top[k + 1], interior);
    addOrientedTri(bp, bot[0], bot[k], bot[k + 1], interior);
  }
  for (int k = 0; k < n; ++k) {
    const int k2 = (k + 1) % n;
    addOrientedTri(bp, top[k], top[k2], bot[k2], interior);
    addOrientedTri(bp, top[k], bot[k2], bot[k], interior);
  }
  p.bodies.push_back(bp);
}

// Static dark solid in the middle of a puzzle whose pieces are frustums (keeps cuts from looking hollow).
void addCoreTri(Puzzle& p, V3 a, V3 b, V3 c) {
  BodyPiece tmp;
  addOrientedTri(tmp, a, b, c, {0.f, 0.f, 0.f});
  p.core.insert(p.core.end(), tmp.tris.begin(), tmp.tris.end());
}

int findSticker(const Puzzle& p, V3 c, V3 n) {
  for (int j = 0; j < p.stickers; ++j) {
    if (length(centroidOf(p, j) - c) < kMatchTol && length(normalOf(p, j) - n) < kMatchTol) return j;
  }
  return -1;
}

// perm[m][j] = i means: after the move, position j shows what position i showed before.
bool buildPerms(Puzzle& p) {
  p.perm.assign(static_cast<size_t>(p.moves), std::vector<uint8_t>(static_cast<size_t>(p.stickers), 0));
  for (int m = 0; m < p.moves; ++m) {
    const MoveInfo& mv = p.move[static_cast<size_t>(m)];
    std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    const V3 axis = axisOf(mv);
    std::vector<bool> inSet(static_cast<size_t>(p.stickers), false);
    std::vector<bool> hit(static_cast<size_t>(p.stickers), false);
    for (int i = 0; i < p.stickers; ++i) {
      pm[static_cast<size_t>(i)] = static_cast<uint8_t>(i);
      inSet[static_cast<size_t>(i)] = inLayer(mv, centroidOf(p, i));
    }
    for (int i = 0; i < p.stickers; ++i) {
      if (!inSet[static_cast<size_t>(i)]) continue;
      const V3 c2 = rotateAbout(axis, mv.angleDeg, centroidOf(p, i));
      const V3 n2 = rotateAbout(axis, mv.angleDeg, normalOf(p, i));
      const int j = findSticker(p, c2, n2);
      // The turning layer must be carried onto itself, one sticker per position.
      if (j < 0 || !inSet[static_cast<size_t>(j)] || hit[static_cast<size_t>(j)]) return false;
      hit[static_cast<size_t>(j)] = true;
      pm[static_cast<size_t>(j)] = static_cast<uint8_t>(i);
    }
  }
  return true;
}

void buildFaces(Puzzle& p) {
  p.faceBegin.assign(static_cast<size_t>(p.faces) + 1, 0);
  p.faceList.clear();
  for (int f = 0; f < p.faces; ++f) {
    p.faceBegin[static_cast<size_t>(f)] = static_cast<int>(p.faceList.size());
    for (int i = 0; i < p.stickers; ++i) {
      if (p.faceOf[static_cast<size_t>(i)] == f) p.faceList.push_back(i);
    }
  }
  p.faceBegin[static_cast<size_t>(p.faces)] = static_cast<int>(p.faceList.size());
}

// ------------------------------------------------------------------------------------------ cubes

const float kFaceNormal[6][3] = {{0, 1, 0}, {1, 0, 0}, {0, 0, 1}, {0, -1, 0}, {-1, 0, 0}, {0, 0, -1}};
const float kFaceUp[6][3] = {{0, 0, -1}, {0, 1, 0}, {0, 1, 0}, {0, 0, 1}, {0, 1, 0}, {0, 1, 0}};
const float kFaceRight[6][3] = {{1, 0, 0}, {0, 0, -1}, {1, 0, 0}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}};
const char kFaceName[7] = "URFDLB";

V3 faceVec(const float (*table)[3], int f) { return {table[f][0], table[f][1], table[f][2]}; }

void buildCube(Puzzle& p, int n) {
  p.id = n - 2;
  p.name = std::to_string(n) + "x" + std::to_string(n) + " Cube";
  p.shortName = std::to_string(n) + "x" + std::to_string(n);
  p.colors = 6;
  p.faces = 6;
  const float half = static_cast<float>(n) * 0.5f;
  const float mid = static_cast<float>(n - 1) * 0.5f;

  for (int f = 0; f < 6; ++f) {
    const V3 nrm = faceVec(kFaceNormal, f);
    const V3 up = faceVec(kFaceUp, f);
    const V3 right = faceVec(kFaceRight, f);
    for (int r = 0; r < n; ++r) {
      for (int c = 0; c < n; ++c) {
        const V3 ctr = nrm * half + right * (static_cast<float>(c) - mid) + up * (mid - static_cast<float>(r));
        const V3 corners[4] = {ctr - right * 0.5f - up * 0.5f, ctr + right * 0.5f - up * 0.5f,
                               ctr + right * 0.5f + up * 0.5f, ctr - right * 0.5f + up * 0.5f};
        addSticker(p, f, f, corners, 4);
      }
    }
  }

  // Face turns (the outer layer), then the inner slices counted from U, R and F.
  for (int f = 0; f < 6; ++f) {
    addMovePair(p, std::string(1, kFaceName[f]), faceVec(kFaceNormal, f), 90.f, half - 1.f, half + 0.01f);
  }
  for (int f = 0; f < 3; ++f) {
    for (int k = 1; k <= n - 2; ++k) {
      const float cc = half - static_cast<float>(k) - 0.5f;
      addMovePair(p, std::to_string(k + 1) + std::string(1, kFaceName[f]), faceVec(kFaceNormal, f), 90.f,
                  cc - 0.5f, cc + 0.5f);
    }
  }

  // Bodies: one dark block per cubie.
  const float hb = 0.485f;
  const V3 axes[3] = {{1.f, 0.f, 0.f}, {0.f, 1.f, 0.f}, {0.f, 0.f, 1.f}};
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      for (int k = 0; k < n; ++k) {
        const V3 cc = {static_cast<float>(i) - mid, static_cast<float>(j) - mid, static_cast<float>(k) - mid};
        BodyPiece bp;
        bp.cls[0] = cc.x;
        bp.cls[1] = cc.y;
        bp.cls[2] = cc.z;
        for (int a = 0; a < 3; ++a) {
          for (int sgn = -1; sgn <= 1; sgn += 2) {
            const V3 nrm = axes[a] * static_cast<float>(sgn);
            const V3 u = axes[(a + 1) % 3];
            const V3 v = axes[(a + 2) % 3];
            const V3 ctr = cc + nrm * hb;
            const V3 p00 = ctr - u * hb - v * hb;
            const V3 p10 = ctr + u * hb - v * hb;
            const V3 p11 = ctr + u * hb + v * hb;
            const V3 p01 = ctr - u * hb + v * hb;
            addOrientedTri(bp, p00, p10, p11, cc);
            addOrientedTri(bp, p00, p11, p01, cc);
          }
        }
        p.bodies.push_back(bp);
      }
    }
  }

  p.radius = half * 1.7320508f + 0.05f;
  p.stickerScale = 0.86f;
  p.stickerLift = hb + 0.006f - 0.5f;

  p.aiSupported = n <= 3;
  if (n == 2) {
    for (int m = 0; m < 6; ++m) p.aiMoves.push_back(m);  // U, R, F: the corner D-L-B never moves
    p.defaultMaxDepth = 12;
    p.hidden1 = 128;
    p.hidden2 = 64;
  } else if (n == 3) {
    for (int m = 0; m < 12; ++m) p.aiMoves.push_back(m);
    p.defaultMaxDepth = 16;
    p.hidden1 = 192;
    p.hidden2 = 96;
  }
}

// ------------------------------------------------------------------------------------------ Pyraminx

void buildPyraminx(Puzzle& p) {
  p.id = kPyraminx;
  p.name = "Pyraminx";
  p.shortName = "Pyraminx";
  p.colors = 4;
  p.faces = 4;
  const float R = 2.3f;
  const float rho = R * 0.94280904f;  // sqrt(8) / 3
  // 0 = U (top), 1 = L, 2 = R, 3 = B
  const V3 vert[4] = {{0.f, R, 0.f},
                      {-rho * 0.8660254f, -R / 3.f, rho * 0.5f},
                      {rho * 0.8660254f, -R / 3.f, rho * 0.5f},
                      {0.f, -R / 3.f, -rho}};
  // Face f lies opposite vertex f' where f' = {0, 1, 2, 3}[f]; face 3 is the front face (U, L, R).
  const int faceVerts[4][3] = {{1, 2, 3}, {0, 2, 3}, {0, 1, 3}, {0, 1, 2}};

  for (int f = 0; f < 4; ++f) {
    V3 p0 = vert[faceVerts[f][0]];
    V3 p1 = vert[faceVerts[f][1]];
    V3 p2 = vert[faceVerts[f][2]];
    if (dot(cross(p1 - p0, p2 - p0), p0 + p1 + p2) < 0.f) std::swap(p1, p2);  // counter-clockwise from outside
    auto Q = [&](int i, int j) { return p0 + (p1 - p0) * (static_cast<float>(i) / 3.f) + (p2 - p0) * (static_cast<float>(j) / 3.f); };
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; i + j <= 2; ++j) {
        const V3 up[3] = {Q(i, j), Q(i + 1, j), Q(i, j + 1)};
        addSticker(p, f, f, up, 3);
        if (i + j <= 1) {
          const V3 down[3] = {Q(i + 1, j), Q(i + 1, j + 1), Q(i, j + 1)};
          addSticker(p, f, f, down, 3);
        }
      }
    }
  }

  const char* layerNames[4] = {"U", "L", "R", "B"};
  const char* tipNames[4] = {"u", "l", "r", "b"};
  for (int v = 0; v < 4; ++v) {
    addMovePair(p, layerNames[v], vert[v], 120.f, R / 9.f, R + 1.f);
    addMovePair(p, tipNames[v], vert[v], 120.f, 5.f * R / 9.f, R + 1.f);
  }

  const float inward = 0.14f;
  for (int i = 0; i < p.stickers; ++i) addFrustumBody(p, i, inward);
  const float cs = (1.f - inward) * 0.97f;
  for (int f = 0; f < 4; ++f) {
    addCoreTri(p, vert[faceVerts[f][0]] * cs, vert[faceVerts[f][1]] * cs, vert[faceVerts[f][2]] * cs);
  }

  p.radius = R + 0.05f;
  p.stickerScale = 0.84f;
  p.stickerLift = 0.f;
  p.aiSupported = true;
  for (int m = 0; m < p.moves; ++m) p.aiMoves.push_back(m);
  p.defaultMaxDepth = 11;
  p.hidden1 = 128;
  p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ Skewb

void buildSkewb(Puzzle& p) {
  p.id = kSkewb;
  p.name = "Skewb";
  p.shortName = "Skewb";
  p.colors = 6;
  p.faces = 6;
  const float S = 1.5f;

  for (int f = 0; f < 6; ++f) {
    const V3 nrm = faceVec(kFaceNormal, f);
    const V3 up = faceVec(kFaceUp, f);
    const V3 right = faceVec(kFaceRight, f);
    auto P = [&](float a, float b) { return (nrm + right * a + up * b) * S; };
    const V3 diamond[4] = {P(1, 0), P(0, 1), P(-1, 0), P(0, -1)};
    addSticker(p, f, f, diamond, 4);
    const V3 t0[3] = {P(1, 1), P(0, 1), P(1, 0)};
    const V3 t1[3] = {P(-1, 1), P(-1, 0), P(0, 1)};
    const V3 t2[3] = {P(-1, -1), P(0, -1), P(-1, 0)};
    const V3 t3[3] = {P(1, -1), P(1, 0), P(0, -1)};
    addSticker(p, f, f, t0, 3);
    addSticker(p, f, f, t1, 3);
    addSticker(p, f, f, t2, 3);
    addSticker(p, f, f, t3, 3);
  }

  // The four corners the solver turns come first; the other four are their opposites.
  const int corners[8][3] = {{1, 1, 1},   {1, 1, -1},  {1, -1, 1},  {-1, 1, 1},
                             {-1, -1, -1}, {-1, -1, 1}, {-1, 1, -1}, {1, -1, -1}};
  for (int k = 0; k < 8; ++k) {
    std::string name;
    name += corners[k][1] > 0 ? 'U' : 'D';
    name += corners[k][0] > 0 ? 'R' : 'L';
    name += corners[k][2] > 0 ? 'F' : 'B';
    const V3 axis = {static_cast<float>(corners[k][0]), static_cast<float>(corners[k][1]),
                     static_cast<float>(corners[k][2])};
    addMovePair(p, name, axis, 120.f, 0.f, 100.f);
  }

  const float inward = 0.2f;
  for (int i = 0; i < p.stickers; ++i) addFrustumBody(p, i, inward);
  const float h = S * (1.f - inward) * 0.97f;
  for (int f = 0; f < 6; ++f) {
    const V3 nrm = faceVec(kFaceNormal, f) * h;
    const V3 up = faceVec(kFaceUp, f) * h;
    const V3 right = faceVec(kFaceRight, f) * h;
    const V3 a = nrm - right - up;
    const V3 b = nrm + right - up;
    const V3 c = nrm + right + up;
    const V3 d = nrm - right + up;
    addCoreTri(p, a, b, c);
    addCoreTri(p, a, c, d);
  }

  p.radius = S * 1.7320508f + 0.05f;
  p.stickerScale = 0.88f;
  p.stickerLift = 0.f;
  p.aiSupported = true;
  for (int m = 0; m < 8; ++m) p.aiMoves.push_back(m);  // corners U-R-F, U-R-B, D-R-F, U-L-F; corner D-L-B never moves
  p.defaultMaxDepth = 12;
  p.hidden1 = 128;
  p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ structure

struct UnionFind {
  std::vector<int> parent;
  explicit UnionFind(int n) : parent(static_cast<size_t>(n)) { std::iota(parent.begin(), parent.end(), 0); }
  int find(int a) {
    while (parent[static_cast<size_t>(a)] != a) {
      parent[static_cast<size_t>(a)] = parent[static_cast<size_t>(parent[static_cast<size_t>(a)])];
      a = parent[static_cast<size_t>(a)];
    }
    return a;
  }
  void unite(int a, int b) {
    a = find(a);
    b = find(b);
    if (a != b) parent[static_cast<size_t>(std::max(a, b))] = std::min(a, b);
  }
};

bool shareCorner(const Puzzle& p, int a, int b) {
  for (int i = 0; i < p.vcount[static_cast<size_t>(a)]; ++i) {
    for (int j = 0; j < p.vcount[static_cast<size_t>(b)]; ++j) {
      if (length(vertexOf(p, a, i) - vertexOf(p, b, j)) < 1.0e-3f) return true;
    }
  }
  return false;
}

// Pieces = groups of touching stickers that lie in exactly the same turning layers. Classes = pieces that
// can change places under the solver's moves. Fixed pieces never move under the solver's moves.
bool buildStructure(Puzzle& p) {
  const int S = p.stickers;
  std::vector<uint64_t> sig(static_cast<size_t>(S), 0);
  for (int i = 0; i < S; ++i) {
    for (int m = 0; m < p.moves; ++m) {
      if (inLayer(p.move[static_cast<size_t>(m)], centroidOf(p, i))) sig[static_cast<size_t>(i)] |= 1ULL << m;
    }
  }
  UnionFind uf(S);
  for (int i = 0; i < S; ++i) {
    for (int j = i + 1; j < S; ++j) {
      if (sig[static_cast<size_t>(i)] == sig[static_cast<size_t>(j)] && shareCorner(p, i, j)) uf.unite(i, j);
    }
  }
  p.slots.clear();
  p.slotOf.assign(static_cast<size_t>(S), -1);
  std::vector<int> compSlot(static_cast<size_t>(S), -1);
  for (int i = 0; i < S; ++i) {
    const int root = uf.find(i);
    if (compSlot[static_cast<size_t>(root)] < 0) {
      compSlot[static_cast<size_t>(root)] = static_cast<int>(p.slots.size());
      p.slots.push_back(Slot());
    }
    Slot& s = p.slots[static_cast<size_t>(compSlot[static_cast<size_t>(root)])];
    if (s.n >= 3) return false;
    s.stickers[s.n++] = i;
    p.slotOf[static_cast<size_t>(i)] = compSlot[static_cast<size_t>(root)];
  }

  const int nSlots = static_cast<int>(p.slots.size());
  UnionFind orbit(nSlots);
  for (int m : p.aiMoves) {
    const std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    for (int i = 0; i < S; ++i) {
      if (pm[static_cast<size_t>(i)] != i) {
        orbit.unite(p.slotOf[static_cast<size_t>(i)], p.slotOf[pm[static_cast<size_t>(i)]]);
      }
    }
  }
  std::vector<int> classOfRoot(static_cast<size_t>(nSlots), -1);
  p.classCount = 0;
  for (int s = 0; s < nSlots; ++s) {
    const int root = orbit.find(s);
    if (classOfRoot[static_cast<size_t>(root)] < 0) classOfRoot[static_cast<size_t>(root)] = p.classCount++;
    p.slots[static_cast<size_t>(s)].cls = classOfRoot[static_cast<size_t>(root)];
  }
  // Pieces in one class must all have the same number of stickers.
  std::vector<int> classSize(static_cast<size_t>(p.classCount), -1);
  for (const Slot& s : p.slots) {
    int& sz = classSize[static_cast<size_t>(s.cls)];
    if (sz < 0) sz = s.n;
    if (sz != s.n) return false;
  }

  p.slotFixed.assign(static_cast<size_t>(nSlots), true);
  for (int m : p.aiMoves) {
    const std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    for (int i = 0; i < S; ++i) {
      if (pm[static_cast<size_t>(i)] != i) p.slotFixed[static_cast<size_t>(p.slotOf[static_cast<size_t>(i)])] = false;
    }
  }
  return true;
}

// ------------------------------------------------------------------------------------------ symmetry

bool buildRotations(Puzzle& p) {
  using Mat = std::array<int, 9>;
  const Mat identity = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  const Mat rx = {1, 0, 0, 0, 0, -1, 0, 1, 0};   // (x, y, z) -> (x, -z, y)
  const Mat ry = {0, 0, 1, 0, 1, 0, -1, 0, 0};   // (x, y, z) -> (z, y, -x)
  auto mul = [](const Mat& a, const Mat& b) {
    Mat r{};
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; j < 3; ++j) {
        int s = 0;
        for (int k = 0; k < 3; ++k) s += a[static_cast<size_t>(i * 3 + k)] * b[static_cast<size_t>(k * 3 + j)];
        r[static_cast<size_t>(i * 3 + j)] = s;
      }
    }
    return r;
  };
  std::vector<Mat> group;
  group.push_back(identity);
  for (size_t at = 0; at < group.size(); ++at) {
    for (const Mat& g : {rx, ry}) {
      const Mat next = mul(g, group[at]);
      if (std::find(group.begin(), group.end(), next) == group.end()) group.push_back(next);
    }
  }
  if (group.size() != 24) return false;

  p.rotations.clear();
  for (const Mat& m : group) {
    std::vector<uint8_t> rot(static_cast<size_t>(p.stickers), 0);
    auto apply = [&m](V3 v) {
      return V3{static_cast<float>(m[0]) * v.x + static_cast<float>(m[1]) * v.y + static_cast<float>(m[2]) * v.z,
                static_cast<float>(m[3]) * v.x + static_cast<float>(m[4]) * v.y + static_cast<float>(m[5]) * v.z,
                static_cast<float>(m[6]) * v.x + static_cast<float>(m[7]) * v.y + static_cast<float>(m[8]) * v.z};
    };
    for (int j = 0; j < p.stickers; ++j) {
      const int i = findSticker(p, apply(centroidOf(p, j)), apply(normalOf(p, j)));
      if (i < 0) return false;
      rot[static_cast<size_t>(i)] = static_cast<uint8_t>(j);  // the sticker at j travels to i
    }
    p.rotations.push_back(rot);
  }

  // conj[r][m]: the physical move that, applied to the unrotated puzzle, matches solver move m applied to
  // the puzzle rotated by r. perm' = R o perm_m o R^-1 as index maps.
  p.conj.assign(p.rotations.size(), std::vector<int>(static_cast<size_t>(p.moves), -1));
  for (size_t r = 0; r < p.rotations.size(); ++r) {
    const std::vector<uint8_t>& rot = p.rotations[r];
    std::vector<int> inv(static_cast<size_t>(p.stickers), 0);
    for (int i = 0; i < p.stickers; ++i) inv[rot[static_cast<size_t>(i)]] = i;
    for (int m : p.aiMoves) {
      std::vector<uint8_t> target(static_cast<size_t>(p.stickers), 0);
      for (int j = 0; j < p.stickers; ++j) {
        target[static_cast<size_t>(j)] = rot[p.perm[static_cast<size_t>(m)][static_cast<size_t>(inv[static_cast<size_t>(j)])]];
      }
      int found = -1;
      for (int q = 0; q < p.moves; ++q) {
        if (p.perm[static_cast<size_t>(q)] == target) {
          found = q;
          break;
        }
      }
      if (found < 0) return false;
      p.conj[r][static_cast<size_t>(m)] = found;
    }
  }

  p.refStickers.clear();
  for (size_t s = 0; s < p.slots.size(); ++s) {
    if (!p.slotFixed[s]) continue;
    for (int k = 0; k < p.slots[s].n; ++k) p.refStickers.push_back(p.slots[s].stickers[k]);
  }
  return !p.refStickers.empty();
}

std::unique_ptr<Puzzle> build(int id) {
  std::unique_ptr<Puzzle> p(new Puzzle());
  switch (id) {
    case kCube2: buildCube(*p, 2); break;
    case kCube3: buildCube(*p, 3); break;
    case kCube4: buildCube(*p, 4); break;
    case kCube5: buildCube(*p, 5); break;
    case kPyraminx: buildPyraminx(*p); break;
    case kSkewb: buildSkewb(*p); break;
    default: return nullptr;
  }
  buildFaces(*p);
  bool ok = p->stickers <= kMaxStickers && p->moves <= kMaxMoves && buildPerms(*p);
  if (ok && p->aiSupported) {
    ok = p->stickers <= kMaxAiStickers && buildStructure(*p);
    p->needsCanon = static_cast<int>(p->aiMoves.size()) < p->moves;
    if (ok && p->needsCanon) ok = buildRotations(*p);
  }
  p->valid = ok;
  return p;
}

}  // namespace

// ------------------------------------------------------------------------------------------ Puzzle

bool Puzzle::aiMove(int m) const { return std::find(aiMoves.begin(), aiMoves.end(), m) != aiMoves.end(); }

void Puzzle::setSolved(uint8_t* s) const {
  for (int i = 0; i < stickers; ++i) s[i] = solved[static_cast<size_t>(i)];
}

bool Puzzle::isSolved(const uint8_t* s) const {
  for (int f = 0; f < faces; ++f) {
    const int b = faceBegin[static_cast<size_t>(f)];
    const int e = faceBegin[static_cast<size_t>(f) + 1];
    const uint8_t c = s[faceList[static_cast<size_t>(b)]];
    for (int k = b + 1; k < e; ++k) {
      if (s[faceList[static_cast<size_t>(k)]] != c) return false;
    }
  }
  return true;
}

void Puzzle::apply(const uint8_t* src, uint8_t* dst, int move) const {
  const uint8_t* pm = perm[static_cast<size_t>(move)].data();
  for (int i = 0; i < stickers; ++i) dst[i] = src[pm[i]];
}

uint64_t Puzzle::hash(const uint8_t* s) const {
  uint64_t h = 1469598103934665603ULL;
  for (int i = 0; i < stickers; ++i) {
    h ^= s[i];
    h *= 1099511628211ULL;
  }
  h ^= h >> 29;
  return h;
}

void Puzzle::rotate(const uint8_t* s, int r, uint8_t* out) const {
  if (rotations.empty()) {
    std::memcpy(out, s, static_cast<size_t>(stickers));
    return;
  }
  const uint8_t* rp = rotations[static_cast<size_t>(r)].data();
  for (int i = 0; i < stickers; ++i) out[i] = s[rp[i]];
}

int Puzzle::canonRotation(const uint8_t* s) const {
  if (!needsCanon) return 0;
  for (size_t r = 0; r < rotations.size(); ++r) {
    bool match = true;
    for (int i : refStickers) {
      if (s[rotations[r][static_cast<size_t>(i)]] != solved[static_cast<size_t>(i)]) {
        match = false;
        break;
      }
    }
    if (match) return static_cast<int>(r);
  }
  return -1;
}

const Puzzle* puzzleById(int id) {
  static std::mutex lock;
  static std::unique_ptr<Puzzle> cache[kPuzzleCount];
  if (id < 0 || id >= kPuzzleCount) return nullptr;
  std::lock_guard<std::mutex> guard(lock);
  if (!cache[id]) cache[id] = build(id);
  return cache[id].get();
}

}  // namespace rubik
