package com.rubikailab.app.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ViewConfiguration
import com.rubikailab.app.core.PuzzleModel

/**
 * GLSurfaceView hosting [PuzzleRenderer].
 *
 * Gestures (when [turnable] is on): a drag that starts on a sticker and is long enough turns the layer
 * that carries that sticker the way the finger moved; a drag that starts anywhere else, or that does not
 * match any layer, orbits the camera. With [orbitMode] on, every drag orbits. When [turnable] is off the
 * view only orbits (used by the watch-the-AI view).
 *
 * [onUserMove] is called on the UI thread with the move the player asked for; the owner applies it to
 * its own state and enqueues it on [renderer]. [onMoveDone] is delivered on the UI thread each time an
 * animated turn has finished.
 */
class PuzzleView(
    context: Context,
    private val onUserMove: (Int) -> Unit,
    onMoveDone: (Int) -> Unit
) : GLSurfaceView(context) {

    val renderer: PuzzleRenderer

    /** Whether swipes on the puzzle may turn layers. */
    var turnable = true

    /** When true every drag orbits the camera, even one that starts on the puzzle. */
    var orbitMode = false

    private var picker: Picker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var picked = -1
    private var mode = IDLE
    private val slop: Float

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        renderer = PuzzleRenderer({ requestRender() }, { move -> post { onMoveDone(move) } })
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        slop = maxOf(context.resources.displayMetrics.density * 14f, ViewConfiguration.get(context).scaledTouchSlop * 1.5f)
    }

    /** Shows [puzzle] in the given [state]. */
    fun setPuzzle(puzzle: PuzzleModel, state: ByteArray) {
        picker = Picker(puzzle)
        renderer.setPuzzle(puzzle, state)
    }

    override fun onResume() {
        super.onResume()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                mode = UNDECIDED
                picked = -1
                val p = picker
                if (turnable && !orbitMode && p != null) {
                    p.setCamera(width, height, renderer.yaw, renderer.pitch)
                    picked = p.pick(event.x, event.y)
                }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == UNDECIDED) {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (dx * dx + dy * dy >= slop * slop) {
                        var move = -1
                        val p = picker
                        if (picked >= 0 && p != null) move = p.swipeMove(picked, dx, dy)
                        if (move >= 0) {
                            mode = TURNED
                            onUserMove(move)
                        } else {
                            mode = ORBIT
                            renderer.rotate(dx, dy)
                            lastX = event.x
                            lastY = event.y
                        }
                    }
                } else if (mode == ORBIT) {
                    renderer.rotate(event.x - lastX, event.y - lastY)
                    lastX = event.x
                    lastY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = IDLE
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private companion object {
        const val IDLE = 0
        const val UNDECIDED = 1
        const val TURNED = 2
        const val ORBIT = 3
    }
}
