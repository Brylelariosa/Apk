// Host tests for the puzzle model and the encoder. Build: see tests/README.md
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>

#include "core/encoder.h"
#include "core/puzzle.h"
#include "core/rng.h"

using namespace rubik;

static int g_fail = 0;
#define CHECK(cond, ...)                                      \
  do {                                                        \
    if (!(cond)) {                                            \
      ++g_fail;                                               \
      printf("FAIL %s:%d: ", __FILE__, __LINE__);             \
      printf(__VA_ARGS__);                                    \
      printf("\n");                                           \
    }                                                         \
  } while (0)

// Open-addressing set of 64-bit keys (0 is mapped to 1).
class HashSet {
 public:
  explicit HashSet(size_t capacityPow2) : mask_(capacityPow2 - 1), t_(capacityPow2, 0) {}
  bool insert(uint64_t k) {
    if (k == 0) k = 1;
    size_t i = (k * 0x9E3779B97F4A7C15ULL >> 20) & mask_;
    while (t_[i] != 0) {
      if (t_[i] == k) return false;
      i = (i + 1) & mask_;
    }
    t_[i] = k;
    ++n_;
    return true;
  }
  size_t size() const { return n_; }
 private:
  size_t mask_;
  std::vector<uint64_t> t_;
  size_t n_ = 0;
};

static std::vector<long> bfs(const Puzzle& p, const std::vector<int>& moves, int maxDepth, size_t cap) {
  HashSet seen(cap);
  std::vector<std::vector<uint8_t>> frontier, next;
  std::vector<uint8_t> s(p.stickers);
  p.setSolved(s.data());
  seen.insert(p.hash(s.data()));
  frontier.push_back(s);
  std::vector<long> counts;
  counts.push_back(1);
  for (int d = 1; d <= maxDepth && !frontier.empty(); ++d) {
    next.clear();
    std::vector<uint8_t> c(p.stickers);
    for (const auto& st : frontier) {
      for (int m : moves) {
        p.apply(st.data(), c.data(), m);
        if (seen.insert(p.hash(c.data()))) next.push_back(c);
      }
    }
    counts.push_back((long)next.size());
    frontier.swap(next);
  }
  return counts;
}

static void applySeq(const Puzzle& p, std::vector<uint8_t>& s, const std::vector<int>& seq) {
  std::vector<uint8_t> t(p.stickers);
  for (int m : seq) {
    p.apply(s.data(), t.data(), m);
    s = t;
  }
}

static int moveNamed(const Puzzle& p, const char* name) {
  for (int m = 0; m < p.moves; ++m) if (p.move[m].name == name) return m;
  return -1;
}

int main(int argc, char** argv) {
  bool full = argc > 1 && std::strcmp(argv[1], "full") == 0;
  for (int id = 0; id < kPuzzleCount; ++id) {
    const Puzzle* p = puzzleById(id);
    CHECK(p != nullptr, "puzzle %d missing", id);
    if (!p) continue;
    printf("== %s: stickers=%d colors=%d faces=%d moves=%d ai=%d valid=%d canon=%d\n", p->name.c_str(), p->stickers,
           p->colors, p->faces, p->moves, (int)p->aiMoves.size(), (int)p->valid, (int)p->needsCanon);
    CHECK(p->valid, "%s not valid", p->name.c_str());
    if (!p->valid) continue;

    // inverse pairs, orders, face uniformity
    std::vector<uint8_t> solved(p->stickers);
    p->setSolved(solved.data());
    CHECK(p->isSolved(solved.data()), "solved state not solved");
    for (int m = 0; m < p->moves; ++m) {
      const MoveInfo& mv = p->move[m];
      CHECK(mv.inverse == (m ^ 1), "inverse index of move %d", m);
      // perm[m^1] must be the inverse permutation of perm[m]
      for (int i = 0; i < p->stickers; ++i) {
        int j = p->perm[m][i];
        CHECK(p->perm[m ^ 1][j] == i, "move %s: inverse table mismatch at %d", mv.name.c_str(), i);
      }
      // order
      std::vector<uint8_t> s = solved;
      int order = 0;
      std::vector<uint8_t> t(p->stickers);
      int moved = 0;
      for (int i = 0; i < p->stickers; ++i) if (p->perm[m][i] != i) ++moved;
      for (int k = 1; k <= 6; ++k) {
        p->apply(s.data(), t.data(), m);
        s = t;
        if (s == solved) { order = k; break; }
        if (k == 1) CHECK(!p->isSolved(s.data()), "move %s leaves the puzzle solved", mv.name.c_str());
      }
      int expect = std::abs(mv.angleDeg) > 100 ? 3 : 4;
      CHECK(order == expect, "move %s order %d expected %d", mv.name.c_str(), order, expect);
      if (m % 2 == 0 && m < 14) printf("   move %-4s moved stickers %d\n", mv.name.c_str(), moved);
    }
    // sticker geometry sanity: polygons are planar, normals outward
    for (int i = 0; i < p->stickers; ++i) {
      float dotn = 0;
      for (int k = 0; k < 3; ++k) dotn += p->centroid[i * 3 + k] * p->normal[i * 3 + k];
      CHECK(dotn > 0, "sticker %d normal not outward", i);
    }

    if (!p->aiSupported) continue;
    printf("   slots=%zu classes=%d fixed=", p->slots.size(), p->classCount);
    int nfixed = 0;
    for (size_t s = 0; s < p->slots.size(); ++s) if (p->slotFixed[s]) ++nfixed;
    printf("%d\n", nfixed);
    for (int c = 0; c < p->classCount; ++c) {
      int n = 0, k = 0; bool fx = false;
      for (size_t s = 0; s < p->slots.size(); ++s) if (p->slots[s].cls == c) { ++n; k = p->slots[s].n; fx = p->slotFixed[s]; }
      printf("     class %d: %d slots x %d stickers%s\n", c, n, k, fx ? " (fixed)" : "");
    }
    Encoder enc(*p);
    CHECK(enc.ok(), "encoder not ok for %s", p->name.c_str());
    printf("   encoder: features=%d active=%d\n", enc.features(), enc.active());
    int feats[64];
    CHECK(enc.encode(solved.data(), feats) == enc.active(), "encode solved");
    std::vector<int> wrong(enc.classes());
    CHECK(enc.misplaced(solved.data(), wrong.data()) == 0, "solved has misplaced pieces");
    // random AI walks: encoding valid, features in range, distinct
    Rng rng(123 + id);
    std::vector<uint8_t> s = solved, t(p->stickers);
    for (int step = 0; step < 4000; ++step) {
      int m = p->aiMoves[rng.below((uint32_t)p->aiMoves.size())];
      p->apply(s.data(), t.data(), m);
      s = t;
      int n = enc.encode(s.data(), feats);
      CHECK(n == enc.active(), "encode failed in walk");
      for (int i = 0; i < n; ++i) CHECK(feats[i] >= 0 && feats[i] < enc.features(), "feature out of range");
      if (g_fail > 20) return 1;
    }
    for (int c = 0; c < enc.classes(); ++c) printf("   class %d maxMoved=%d\n", c, enc.maxMoved(c));
  }

  // 3x3 specifics
  {
    const Puzzle* p = puzzleById(kCube3);
    std::vector<uint8_t> s(p->stickers), solved(p->stickers);
    p->setSolved(solved.data());
    int R = moveNamed(*p, "R"), Rp = moveNamed(*p, "R'"), U = moveNamed(*p, "U"), Up = moveNamed(*p, "U'");
    s = solved;
    for (int k = 0; k < 6; ++k) applySeq(*p, s, {R, U, Rp, Up});
    CHECK(s == solved, "(R U R' U')^6 must be the identity");
    s = solved;
    for (int k = 0; k < 5; ++k) applySeq(*p, s, {R, U, Rp, Up});
    CHECK(s != solved, "(R U R' U')^5 must not be the identity");
    s = solved;
    for (int k = 0; k < 105; ++k) applySeq(*p, s, {R, U});
    CHECK(s == solved, "(R U)^105 must be the identity");
    s = solved;
    for (int k = 0; k < 104; ++k) applySeq(*p, s, {R, U});
    CHECK(s != solved, "(R U)^104 must not be the identity");
    std::vector<int> all;
    for (int m = 0; m < 12; ++m) all.push_back(m);
    std::vector<long> c = bfs(*p, all, 6, 1 << 22);
    long expect[7] = {1, 12, 114, 1068, 10011, 93840, 878880};
    for (int d = 0; d < 7; ++d) {
      printf("   3x3 depth %d: %ld\n", d, c[d]);
      CHECK(c[d] == expect[d], "3x3 qtm count depth %d: %ld vs %ld", d, c[d], expect[d]);
    }
  }
  // 2x2 full BFS with U R F
  if (full) {
    const Puzzle* p = puzzleById(kCube2);
    std::vector<long> c = bfs(*p, p->aiMoves, 20, 1 << 23);
    long expect[15] = {1, 6, 27, 120, 534, 2256, 8969, 33058, 114149, 360508, 930588, 1350852, 782536, 90280, 276};
    long total = 0;
    for (size_t d = 0; d < c.size(); ++d) total += c[d];
    printf("   2x2 total %ld, depths %zu\n", total, c.size());
    CHECK(total == 3674160, "2x2 state count %ld", total);
    for (size_t d = 0; d < c.size() && d < 15; ++d) CHECK(c[d] == expect[d], "2x2 depth %zu: %ld vs %ld", d, c[d], expect[d]);
    // Skewb full BFS
    const Puzzle* sk = puzzleById(kSkewb);
    std::vector<long> c2 = bfs(*sk, sk->aiMoves, 20, 1 << 23);
    long t2 = 0;
    for (long v : c2) t2 += v;
    printf("   skewb total %ld, depths %zu\n", t2, c2.size());
    CHECK(t2 == 3149280, "skewb state count %ld", t2);
    // Pyraminx layer moves only
    const Puzzle* py = puzzleById(kPyraminx);
    std::vector<int> layer;
    for (int m = 0; m < py->moves; ++m) if (((m / 2) & 1) == 0) layer.push_back(m);
    std::vector<long> c3 = bfs(*py, layer, 20, 1 << 22);
    long t3 = 0;
    for (long v : c3) t3 += v;
    printf("   pyraminx (no tips) total %ld, depths %zu\n", t3, c3.size());
    CHECK(t3 == 933120, "pyraminx state count %ld", t3);
  }

  // canonicalisation (2x2, skewb): walks over ALL physical moves, conjugation property
  for (int id : {(int)kCube2, (int)kSkewb}) {
    const Puzzle* p = puzzleById(id);
    Rng rng(777 + id);
    std::vector<uint8_t> s(p->stickers), t(p->stickers), canon(p->stickers), a(p->stickers), b(p->stickers);
    p->setSolved(s.data());
    int bad = 0, shifted = 0;
    for (int step = 0; step < 3000; ++step) {
      int m = (int)rng.below((uint32_t)p->moves);
      p->apply(s.data(), t.data(), m);
      s = t;
      int r = p->canonRotation(s.data());
      if (r < 0) { ++bad; continue; }
      if (r != 0) ++shifted;
      p->rotate(s.data(), r, canon.data());
      for (int i : p->refStickers) if (canon[i] != p->solved[i]) ++bad;
      // conjugation: AI move on canon == rotate(physical move on s)
      for (int mc : p->aiMoves) {
        p->apply(canon.data(), a.data(), mc);
        int mp = p->conj[r][mc];
        CHECK(mp >= 0, "conj missing");
        p->apply(s.data(), b.data(), mp);
        std::vector<uint8_t> br(p->stickers);
        p->rotate(b.data(), r, br.data());
        if (std::memcmp(br.data(), a.data(), p->stickers) != 0) ++bad;
      }
    }
    printf("   canon %s: bad=%d (states with non-identity frame: %d)\n", p->name.c_str(), bad, shifted);
    CHECK(bad == 0, "canonicalisation broken for %s", p->name.c_str());
  }

  printf(g_fail ? "FAILED (%d)\n" : "ALL OK\n", g_fail);
  return g_fail ? 1 : 0;
}
