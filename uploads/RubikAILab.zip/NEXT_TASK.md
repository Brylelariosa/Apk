# Rubik AI Lab - NEXT TASK

Version 2.1 - 2026-10-21

## Do this next
1. Build v2.1 with CI. Run 1868 failed only at PlayPage.kt (init order, fixed). If the Kotlin compile or R8 reports
   anything else, fix exactly the reported lines (nothing is compiled in the authoring sandbox). The CI builds
   assembleRelease when the keystore secrets exist, so R8 (minify + shrinkResources) runs too.
2. On the phone: Train tab -> pick a puzzle -> Start training; check the temperature chip and the live AI view; try Cool / Balanced / Fast.
3. Play tab: check that swipes turn the layer you expect on every puzzle (3x3 first), and the "Rotate view" toggle.
4. Test tab: run a sweep on the held-out scrambles and on fresh ones; compare Learned AI with Baseline.

## Ideas, not started
- Continuous finger-following turns (current swipes trigger an animated turn).
- Megaminx / other shapes; a "train only while charging" option; per-puzzle hidden sizes in the settings.

## Rules
- Never touch GitHub. Never claim a test or build happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
