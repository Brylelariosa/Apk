# Rubik AI Lab

Android app (Kotlin views + OpenGL ES 2.0 + native C++17) with six twisty puzzles, a hand-play mode with
swipe controls, and an on-device AI that learns to solve them from nothing but sticker colours.

## Puzzles
| Puzzle | Play | AI |
|---|---|---|
| 2x2 Cube | yes | yes |
| 3x3 Cube (face and middle-layer turns) | yes | yes |
| 4x4 Cube, 5x5 Cube | yes | no (state space far too large for a phone) |
| Pyraminx (triangle, tips included) | yes | yes |
| Skewb (corner-turning cube) | yes | yes |

## Tabs
- **Play** - the puzzle fills the screen and nothing needs scrolling. Swipe a sticker to turn the layer it
  sits in (the layer moves the way your finger moves; on the Skewb a swipe, a tap or a press-and-hold on a
  corner twists that corner); turning makes a soft cube sound (Settings > Sound switches it off); drag the background, or switch on "Rotate view", to look around. Everything you tap is in one
  panel at the bottom: puzzle picker, timer and moves, turn pad / rotate view / settings buttons, then
  Scramble, Reset and "AI solve". Timer with personal bests.
- **Train** - watch the AI practise on fresh scrambles at the depth it is currently training on (it sees only
  colours, searches with its learned estimate, then the puzzle plays its solution), round progress, loss /
  accuracy / depth / speed chart, and the effort preset: Cool, Balanced or Fast. A thermal governor keeps the
  phone under the preset's temperature ceiling.
- **Test** - benchmark the AI or the conventional baseline on held-out scrambles (never used for training) or
  on brand-new random ones. Results are saved.

## Source layout
```
app/src/main/cpp/            native core (flat core/ directory, the CI cache key hashes core/*.cpp)
  jni_bridge.cpp             JNI surface
  core/puzzle.*              generic puzzle model: geometry -> move tables, pieces, symmetries
  core/encoder.*             state -> sparse "piece P in slot S with orientation O" features
  core/net.*                 value network (sparse input -> h1 -> h2 -> 1)
  core/trainer.*             approximate value iteration over pools of random states
  core/search.*              weighted A* with learned or conventional heuristic
  core/engine.*              one engine per puzzle: trainer + held-out tests + search + checkpoints
app/src/main/java/com/rubikailab/app/
  core/                      Kotlin side of the puzzle model and JNI
  gl/                        renderer, camera, picking and swipe-to-move, cube turn sounds (TurnSound.kt)
  ui/                        Play, Train and Test pages, dialogs, small widgets
  Lab.kt, ThermalGovernor.kt, TrainingService.kt
tests/                       host tests for the native core, tests/preview/ (host renderer, see BUILD.md), tests/sound/ (turn sound synthesis)
```

See AI_DESIGN.md for how the AI learns and BUILD.md for building and testing.
