package com.rubikailab.app.gl

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import com.rubikailab.app.R
import java.util.Random

/**
 * The sound of a cube being turned: a soft plastic slide while the layer moves and a dry click when it seats.
 * It plays through a [SoundPool], so many turns can overlap (a scramble is a quick rattle of clicks). The six
 * short samples in res/raw are synthesised by tests/sound/make_sounds.py; every play varies the pitch a little,
 * so no two turns sound the same. The sounds follow the media volume. Safe to call from any thread.
 */
class TurnSound(context: Context) {

    private val pool: SoundPool
    private val slides = IntArray(SLIDE_RES.size)
    private val clicks = IntArray(CLICK_RES.size)
    private val rng = Random()
    private var lastClickAt = 0L

    @Volatile
    private var live = true

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        val app = context.applicationContext
        for (i in SLIDE_RES.indices) slides[i] = pool.load(app, SLIDE_RES[i], 1)
        for (i in CLICK_RES.indices) clicks[i] = pool.load(app, CLICK_RES[i], 1)
    }

    /** A layer starts turning and will take [ms] milliseconds. Very fast turns (a scramble) only click. */
    fun turnStarted(ms: Long) {
        if (!live || ms < MIN_SLIDE_MS) return
        val id = slides[rng.nextInt(slides.size)]
        val fit = (SLIDE_MS / ms.toFloat()).coerceIn(0.8f, 1.5f)
        val rate = fit * (0.96f + rng.nextFloat() * 0.08f)
        pool.play(id, SLIDE_VOLUME, SLIDE_VOLUME, 1, 0, rate)
    }

    /** The layer has seated; [ms] is how long that turn took. */
    fun turnEnded(ms: Long) {
        if (!live) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClickAt < MIN_GAP_MS) return
        lastClickAt = now
        val id = clicks[rng.nextInt(clicks.size)]
        val rate = 0.92f + rng.nextFloat() * 0.16f
        val volume = if (ms < MIN_SLIDE_MS) QUICK_VOLUME else CLICK_VOLUME
        pool.play(id, volume, volume, 2, 0, rate)
    }

    /** Frees the sound pool. The object must not be used afterwards. */
    fun release() {
        live = false
        pool.release()
    }

    private companion object {
        val SLIDE_RES = intArrayOf(R.raw.turn_slide_1, R.raw.turn_slide_2, R.raw.turn_slide_3)
        val CLICK_RES = intArrayOf(R.raw.turn_click_1, R.raw.turn_click_2, R.raw.turn_click_3)
        const val SLIDE_MS = 220f
        const val MIN_SLIDE_MS = 90L
        const val MIN_GAP_MS = 18L
        const val SLIDE_VOLUME = 0.7f
        const val CLICK_VOLUME = 0.95f
        const val QUICK_VOLUME = 0.6f
    }
}
