#!/usr/bin/env python3
"""Synthesises the cube turn sounds (res/raw/turn_slide_*.wav and turn_click_*.wav). No recordings are used: every
sample is built here from damped resonances (the plastic shell), a short noise burst (the impact) and shaped noise
(the layer sliding), so the sounds are reproducible and carry no licence.

  python3 tests/sound/make_sounds.py app/src/main/res/raw          # writes the six WAV files
  python3 tests/sound/make_sounds.py /tmp/sounds --report          # also prints level / spectrum figures

Needs only numpy. 44.1 kHz, 16 bit, mono.
"""
import sys, os, wave
import numpy as np

SR = 44100


def band(x, lo, hi, soft=0.25):
    """Smooth band-pass by FFT masking: pass [lo, hi] Hz, edges eased over `soft` of their frequency."""
    n = len(x)
    f = np.fft.rfftfreq(n, 1.0 / SR)
    m = np.ones_like(f)
    if lo > 0:
        m *= np.clip((f - lo * (1 - soft)) / (lo * 2 * soft), 0, 1)
    if hi < SR / 2:
        m *= np.clip((hi * (1 + soft) - f) / (hi * 2 * soft), 0, 1)
    return np.fft.irfft(np.fft.rfft(x) * m, n)


def smooth(t, a, b):
    u = np.clip((t - a) / (b - a), 0, 1)
    return u * u * (3 - 2 * u)


def click(seed, bright=1.0, body=1.0, bounce=0.35, length=0.10):
    """The sound of a layer snapping into place: impact tick, plastic shell resonances, a low thump, a small rebound."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR

    def strike(delay, gain):
        s = np.zeros(n)
        d = int(delay * SR)
        tt = t[: n - d]
        # impact: a very short noise burst, high-passed so it reads as a tick, not a thud
        burst = band(rng.standard_normal(len(tt)), 1800 * bright, 9500)
        burst *= np.exp(-tt / 0.0011) * (1 - np.exp(-tt / 0.00015))
        # the plastic shell: damped, slightly inharmonic resonances
        modes = [(420, 0.014, 0.50), (910, 0.012, 0.55), (1480, 0.009, 0.55), (2250, 0.007, 0.42),
                 (3150, 0.005, 0.32), (4300, 0.0035, 0.20), (5900, 0.0025, 0.11)]
        res = np.zeros(len(tt))
        for f, tau, a in modes:
            f2 = f * bright * (1 + rng.uniform(-0.04, 0.04))
            res += a * body * np.exp(-tt / tau) * np.sin(2 * np.pi * f2 * tt + rng.uniform(0, 0.6))
        # the hand and the cube's mass: a short low thump
        thump = 0.42 * body * np.exp(-tt / 0.011) * np.sin(2 * np.pi * rng.uniform(150, 190) * tt)
        s[d:] = gain * (0.95 * burst + res + thump)
        return s

    x = strike(0.0, 1.0) + strike(rng.uniform(0.0065, 0.011), bounce)
    x = band(x, 60, 10500, 0.2)
    x *= 1 - smooth(t, length - 0.02, length)
    return x / np.max(np.abs(x)) * 0.85


def slide(seed, length=0.22, speed=1.0):
    """The layer sliding round: shaped noise with a ratchet texture (the pieces passing the core), quiet and soft."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    hiss = band(rng.standard_normal(n), 1300, 6200)
    rumble = band(rng.standard_normal(n), 90, 520)
    # grit: random tiny contacts, each a few ms of high-passed noise
    grit = np.zeros(n)
    count = int(950 * length * speed)
    for p in rng.integers(0, n - 160, count):
        k = np.arange(160)
        grit[p:p + 160] += rng.uniform(0.2, 1.0) * rng.standard_normal(160) * np.exp(-k / 38.0)
    grit = band(grit, 1800, 8000)
    ratchet = 0.62 + 0.38 * np.sin(2 * np.pi * 93 * speed * t + rng.uniform(0, 6.28)) * np.sin(2 * np.pi * 57 * speed * t + rng.uniform(0, 6.28))
    env = smooth(t, 0.0, 0.03) * (1 - smooth(t, length - 0.06, length)) * (0.62 + 0.38 * np.sin(np.pi * t / length))
    x = (0.5 * hiss / np.std(hiss) + 0.7 * grit / np.std(grit) + 0.28 * rumble / np.std(rumble)) * ratchet * env
    # the faint tick as the layer lets go of its seat
    tick = click(seed + 100, bright=1.25, body=0.5, bounce=0.0, length=0.03)
    x[: len(tick)] += 0.55 * tick * np.max(np.abs(x)) / 0.85
    return x / np.max(np.abs(x)) * 0.42


def write(path, x):
    pcm = np.clip(x, -1, 1)
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((pcm * 32767).astype('<i2').tobytes())


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    os.makedirs(out, exist_ok=True)
    clicks = [click(11, bright=1.00, body=1.00, bounce=0.35),
              click(23, bright=0.86, body=1.15, bounce=0.28),
              click(37, bright=1.14, body=0.85, bounce=0.42)]
    slides = [slide(5, speed=1.0), slide(9, speed=0.9), slide(14, speed=1.1)]
    for i, x in enumerate(clicks, 1):
        write(os.path.join(out, f'turn_click_{i}.wav'), x)
    for i, x in enumerate(slides, 1):
        write(os.path.join(out, f'turn_slide_{i}.wav'), x)
    if '--report' in sys.argv:
        for name, x in [(f'click_{i}', c) for i, c in enumerate(clicks, 1)] + [(f'slide_{i}', s) for i, s in enumerate(slides, 1)]:
            f = np.fft.rfftfreq(len(x), 1 / SR)
            mag = np.abs(np.fft.rfft(x))
            cen = float((f * mag).sum() / mag.sum())
            rms = float(np.sqrt(np.mean(x ** 2)))
            print(f'{name}: {len(x) / SR * 1000:.0f} ms, peak {np.max(np.abs(x)):.2f}, rms {rms:.3f}, spectral centroid {cen:.0f} Hz')


if __name__ == '__main__':
    main()
