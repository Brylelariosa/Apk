# Rubik AI Lab - NEXT TASK

Version 2.6 - 2026-10-24

## Do this next
1. Build v2.6 with CI. Nothing from v2.3 to v2.6 has been compiled yet (the authoring sandbox has no Kotlin compiler or Android SDK):
   if the Kotlin compile or R8 reports anything, fix exactly the reported lines. The CI builds assembleRelease when the keystore secrets
   exist, so R8 (minify + shrinkResources) runs too.
2. Play tab on the phone (v2.5 layout): the puzzle picker, timer / moves, turn pad, rotate view and settings are in one panel at the
   bottom above Scramble / Reset / AI solve; the top only has the face strip and short messages. Check that the puzzle stays centred between
   the face strip and the panel, that the panel's icon switches (pad, rotate view) light up, and that a drag on the panel does not spin the view.
3. Skewb on the phone, looking straight at the white face (tap it in the face strip): swipe each of the four corner pieces, tap each, hold each
   (tap = clockwise, hold 0.45 s = counter-clockwise), and touch just outside a corner tip: every one must twist that corner. The turn pad (grid
   icon) now has all sixteen corner twists. If a corner STILL does not turn, add a log line in PuzzleView.onTouchEvent (what pick() returns on
   ACTION_DOWN, whether onUserMove is reached) and one in PlayPage.onUserMove (busy / solving): the swipe maths passes on the host in every view.
3b. Sounds on the phone (media volume up): a user turn gives a soft slide then a click; a scramble is a quick rattle of clicks; the AI solution clicks too;
   Play settings > Sound > Turn sounds switches it off at once; the Train tab stays silent. Nobody has listened to the samples yet: retune
   tests/sound/make_sounds.py (decays, levels, brightness) if they sound too hissy or too clicky, then rerun it into app/src/main/res/raw.
4. Earlier checks still open: the 3x3 thin lines and pieces turning with their layer, the Pyraminx tip swipes, a drag on the puzzle never
   spinning the view, Train tab live view and thermal presets, Test tab sweeps (Learned AI vs Baseline).

## Ideas, not started
- Continuous finger-following turns (current swipes trigger an animated turn).
- Megaminx / other shapes; a "train only while charging" option; per-puzzle hidden sizes in the settings.

## Rules
- Never touch GitHub. Never claim a test or build happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
