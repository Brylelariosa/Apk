package com.network.hotspot;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import rikka.shizuku.Shizuku;

public class HotspotManager {

    private static final int WIFI_AP_STATE_ENABLING = 12;
    private static final int WIFI_AP_STATE_ENABLED  = 13;

    // ── State ────────────────────────────────────────────────────────────────

    /** True if the real system hotspot is currently on or starting. */
    public static boolean isHotspotEnabled(Context context) {
        WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return false;
        try {
            Method m = wm.getClass().getDeclaredMethod("getWifiApState");
            m.setAccessible(true);
            int state = (Integer) m.invoke(wm);
            return state == WIFI_AP_STATE_ENABLED || state == WIFI_AP_STATE_ENABLING;
        } catch (Exception e) {
            return false;
        }
    }

    // ── Shizuku helpers ──────────────────────────────────────────────────────

    public static boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasShizukuPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    // ── Enable hotspot via Shizuku shell ─────────────────────────────────────

    /**
     * Runs shell commands via Shizuku to enable the real hotspot.
     * Tries multiple commands so it works across Android 10–13.
     * Must be called on a background thread.
     */
    public static boolean enableHotspotViaShizuku() {
        if (!isShizukuAvailable() || !hasShizukuPermission()) return false;

        // Try "cmd wifi start-softap" — works on Android 12+ (shell is explicitly allowed)
        if (runCmd("cmd", "wifi", "start-softap")) return true;

        // Try connectivity tethering command — some Android 11 ROMs
        if (runCmd("cmd", "connectivity", "tethering", "start", "wifi")) return true;

        // Try svc wifi hotspot — some OEM ROMs (Infinix/MediaTek)
        if (runCmd("svc", "wifi", "hotspot", "enable")) return true;

        return false;
    }

    private static boolean runCmd(String... args) {
        try {
            // Shizuku 13.1.x made newProcess private in favor of UserService,
            // but it's still present at runtime — invoke it via reflection.
            Method newProcess = Shizuku.class.getDeclaredMethod(
                    "newProcess", String[].class, String[].class, String.class);
            newProcess.setAccessible(true);
            Process p = (Process) newProcess.invoke(null, args, null, null);

            // Drain stderr so the process doesn't block
            new Thread(() -> {
                try {
                    InputStream err = p.getErrorStream();
                    BufferedReader r = new BufferedReader(new InputStreamReader(err));
                    while (r.readLine() != null) { /* discard */ }
                } catch (Exception ignored) {}
            }).start();

            int exit = p.waitFor();
            return exit == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
