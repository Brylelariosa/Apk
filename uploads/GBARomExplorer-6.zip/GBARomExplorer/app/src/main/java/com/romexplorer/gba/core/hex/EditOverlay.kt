package com.romexplorer.gba.core.hex

/** A single undoable byte edit. */
private data class ByteEdit(val offset: Long, val previousValue: Int?, val newValue: Int)

/**
 * Tracks in-progress hex edits as a sparse offset -> byte overlay on top of
 * the original ROM bytes, without ever mutating the source file (SAF
 * documents may not even be writable in place). Supports full undo/redo.
 * "Save as new file" (in the repository layer) applies this overlay onto a
 * copy of the original bytes.
 */
class EditOverlay {
    private val overlay = LinkedHashMap<Long, Int>() // offset -> new byte value (0..255)
    private val undoStack = ArrayDeque<ByteEdit>()
    private val redoStack = ArrayDeque<ByteEdit>()

    val isDirty: Boolean get() = overlay.isNotEmpty()
    val editedOffsets: Set<Long> get() = overlay.keys

    /** Returns the overlaid value for [offset] if edited, else null (caller falls back to original byte). */
    fun get(offset: Long): Int? = overlay[offset]

    fun setByte(offset: Long, newValue: Int, originalValue: Int) {
        val previous = overlay[offset]
        val effectivePrevious = previous ?: originalValue
        if (effectivePrevious == newValue) return
        overlay[offset] = newValue
        undoStack.addLast(ByteEdit(offset, previous, newValue))
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(): Long? {
        val edit = undoStack.removeLastOrNull() ?: return null
        if (edit.previousValue == null) overlay.remove(edit.offset) else overlay[edit.offset] = edit.previousValue
        redoStack.addLast(edit)
        return edit.offset
    }

    fun redo(): Long? {
        val edit = redoStack.removeLastOrNull() ?: return null
        overlay[edit.offset] = edit.newValue
        undoStack.addLast(edit)
        return edit.offset
    }

    fun clear() {
        overlay.clear()
        undoStack.clear()
        redoStack.clear()
    }

    /** Materializes the overlay onto a copy of [original], for export/save. */
    fun applyTo(original: ByteArray): ByteArray {
        val result = original.copyOf()
        for ((offset, value) in overlay) {
            if (offset >= 0 && offset < result.size) {
                result[offset.toInt()] = value.toByte()
            }
        }
        return result
    }

    /** A plain, serializable copy of the current overlay contents, safe to persist
     * (e.g. as a draft — see [com.romexplorer.gba.data.repository.RomSessionManager]). */
    fun snapshot(): Map<Long, Int> = overlay.toMap()

    /**
     * Patches [bytes] — a snapshot already read from the ROM starting at
     * [baseOffset], which need not be 0 (unlike [applyTo]) — with whatever
     * edits fall within that range. This is what makes a reader's own
     * output reflect a pending edit instead of stale on-disk bytes: every
     * reader that wants that has to call this itself on whatever range it
     * reads, the same way the hex editor's own view does, because an
     * [EditOverlay] is inert on its own — a [com.romexplorer.gba.core.rom.RomAccessor]
     * has no knowledge of it (see that interface's doc) and never applies
     * it automatically. [com.romexplorer.gba.core.pokemon.PokemonTableReader]
     * and [com.romexplorer.gba.core.pokemon.TrainerPartyReader] both call
     * this — the latter didn't used to, which is exactly why a trainer
     * party edit used to write correctly but never appear to save: every
     * re-read after it showed this same stale, un-patched data right back.
     */
    fun applyToRange(bytes: ByteArray, baseOffset: Long) {
        if (!isDirty) return
        val rangeEnd = baseOffset + bytes.size
        for (offset in overlay.keys) {
            if (offset < baseOffset || offset >= rangeEnd) continue
            bytes[(offset - baseOffset).toInt()] = overlay.getValue(offset).toByte()
        }
    }

    /**
     * Replaces this overlay's contents with a previously-[snapshot]ed one — used to
     * restore a persisted draft when a ROM is (re)opened. This is a restore, not a new
     * user edit: it clears undo/redo rather than pushing onto them, so "undo" right
     * after opening a ROM doesn't unexpectedly wipe out a restored draft.
     */
    fun loadSnapshot(values: Map<Long, Int>) {
        overlay.clear()
        overlay.putAll(values)
        undoStack.clear()
        redoStack.clear()
    }
}
