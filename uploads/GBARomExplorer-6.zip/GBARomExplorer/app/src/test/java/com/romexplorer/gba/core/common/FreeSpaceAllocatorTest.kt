package com.romexplorer.gba.core.common

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeSpaceAllocatorTest {

    private fun romOf(vararg bytes: Int): ByteArrayRomAccessor =
        ByteArrayRomAccessor(ByteArray(bytes.size) { bytes[it].toByte() })

    @Test
    fun `finds a run of 0xFF bytes long enough for the request`() = runTest {
        val rom = romOf(0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00)
        val offset = FreeSpaceAllocator.findFreeRun(rom, EditOverlay(), length = 4)
        assertEquals(2L, offset)
    }

    @Test
    fun `returns null when no run is long enough`() = runTest {
        val rom = romOf(0xFF, 0xFF, 0x00, 0xFF, 0xFF)
        val offset = FreeSpaceAllocator.findFreeRun(rom, EditOverlay(), length = 3)
        assertNull(offset)
    }

    @Test
    fun `honors reserved ranges so two allocations in one operation don't collide`() = runTest {
        val rom = romOf(0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF)
        val first = FreeSpaceAllocator.findFreeRun(rom, EditOverlay(), length = 3)
        assertEquals(0L, first)

        val second = FreeSpaceAllocator.findFreeRun(
            rom,
            EditOverlay(),
            length = 3,
            reservedRanges = listOf(0L until 3L),
        )
        assertEquals(3L, second)
    }

    @Test
    fun `a pending overlay edit is not treated as free even if it writes another 0xFF`() = runTest {
        val rom = romOf(0x00, 0xFF, 0xFF)
        val overlay = EditOverlay()
        overlay.setByte(1L, newValue = 0xFF, originalValue = 0xFF)
        val offset = FreeSpaceAllocator.findFreeRun(rom, overlay, length = 2, reservedRanges = listOf(1L until 2L))
        assertNull(offset) // only byte 2 is left, not enough for length 2
    }

    @Test
    fun `write stages bytes into the overlay without touching the underlying ROM`() = runTest {
        val rom = romOf(0xFF, 0xFF, 0xFF, 0xFF)
        val overlay = EditOverlay()
        val ok = FreeSpaceAllocator.write(rom, overlay, destination = 1L, bytes = byteArrayOf(0x01, 0x02))
        assertTrue(ok)

        val patched = overlay.applyTo(rom.read(0, 4))
        assertArrayEquals(byteArrayOf(0xFF.toByte(), 0x01, 0x02, 0xFF.toByte()), patched)
    }

    @Test
    fun `a write that fails leaves the overlay completely untouched, not partially applied`() = runTest {
        val rom = romOf(0x00, 0x00, 0x00, 0x00)
        val overlay = EditOverlay()
        // 6 bytes requested starting at offset 2, but the ROM is only 4
        // bytes long — this must fail as a whole rather than staging
        // offsets 2-3 (which are in range) before discovering offset 4 isn't.
        val ok = FreeSpaceAllocator.write(rom, overlay, destination = 2L, bytes = ByteArray(6) { 0xAB.toByte() })

        assertEquals(false, ok)
        assertEquals(false, overlay.isDirty)
    }

    @Test
    fun `leBytes encodes little endian`() {
        assertArrayEquals(byteArrayOf(0x56, 0x34, 0x12, 0x08), FreeSpaceAllocator.leBytes(0x08123456L, 4))
    }

    @Test
    fun `toRomPointer sets the GBA ROM address bit`() {
        assertEquals(0x08123456L, FreeSpaceAllocator.toRomPointer(0x00123456L))
    }
}
