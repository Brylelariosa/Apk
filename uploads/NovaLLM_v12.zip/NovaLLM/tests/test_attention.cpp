// Standalone gradient-check tests for MultiHeadAttention::backward - the
// hardest piece in core/training, since it needs backprop through
// softmax, causal masking, and the multi-head split/merge. No Android/
// JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_attention.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/transformer/Linear.cpp \
//     ../app/src/main/cpp/core/transformer/Attention.cpp \
//     ../app/src/main/cpp/core/transformer/KVCache.cpp \
//     ../app/src/main/cpp/core/training/GradientCheck.cpp \
//     -o test_attention && ./test_attention
#include <cstdio>
#include <cmath>
#include <random>
#include "core/transformer/Attention.h"
#include "core/training/GradientCheck.h"

using namespace novallm;

static int g_failures = 0;
void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

Tensor randomTensor(std::mt19937& rng, std::vector<int> shape, float scale) {
    Tensor t(shape);
    for (size_t i = 0; i < t.size(); ++i) {
        uint32_t bits = rng();
        float unit = static_cast<float>(bits) / 4294967295.0f;
        t.data()[i] = (unit * 2.0f - 1.0f) * scale;
    }
    return t;
}

float dotLoss(const Tensor& output, const Tensor& direction) {
    float s = 0.0f;
    for (size_t i = 0; i < output.size(); ++i) s += output.data()[i] * direction.data()[i];
    return s;
}

void testAttentionGradient() {
    std::mt19937 rng(555);
    MultiHeadAttention attn(8, 2, 17);
    Tensor x = randomTensor(rng, {4, 8}, 0.3f);
    Tensor direction = randomTensor(rng, attn.forward(x).shape(), 1.0f);

    MultiHeadAttention::Grads g = attn.backward(x, direction);
    auto lossFn = [&]() { return dotLoss(attn.forward(x), direction); };

    float errX = gradcheck::maxRelativeError(x, g.gradInput, lossFn);
    expectTrue(errX < 2e-2f, "Attention backward: gradInput matches numerical gradient");

    float errWq = gradcheck::maxRelativeError(attn.wq().weight(), g.gradWq, lossFn);
    float errBq = gradcheck::maxRelativeError(attn.wq().bias(), g.gradBq, lossFn);
    expectTrue(errWq < 2e-2f, "Attention backward: gradWq matches numerical gradient");
    expectTrue(errBq < 2e-2f, "Attention backward: gradBq matches numerical gradient");

    float errWk = gradcheck::maxRelativeError(attn.wk().weight(), g.gradWk, lossFn);
    float errBk = gradcheck::maxRelativeError(attn.wk().bias(), g.gradBk, lossFn);
    expectTrue(errWk < 2e-2f, "Attention backward: gradWk matches numerical gradient");
    expectTrue(errBk < 2e-2f, "Attention backward: gradBk matches numerical gradient");

    float errWv = gradcheck::maxRelativeError(attn.wv().weight(), g.gradWv, lossFn);
    float errBv = gradcheck::maxRelativeError(attn.wv().bias(), g.gradBv, lossFn);
    expectTrue(errWv < 2e-2f, "Attention backward: gradWv matches numerical gradient");
    expectTrue(errBv < 2e-2f, "Attention backward: gradBv matches numerical gradient");

    float errWo = gradcheck::maxRelativeError(attn.wo().weight(), g.gradWo, lossFn);
    float errBo = gradcheck::maxRelativeError(attn.wo().bias(), g.gradBo, lossFn);
    expectTrue(errWo < 2e-2f, "Attention backward: gradWo matches numerical gradient");
    expectTrue(errBo < 2e-2f, "Attention backward: gradBo matches numerical gradient");

    std::printf("  (errX=%e errWq=%e errBq=%e errWk=%e errBk=%e errWv=%e errBv=%e errWo=%e errBo=%e)\n",
                errX, errWq, errBq, errWk, errBk, errWv, errBv, errWo, errBo);
}

// Precision-independent structural check, the backward-pass analog of the
// forward causal-masking test: if gradOutput is nonzero ONLY at position
// j, then dL/dx at any position k>j must be EXACTLY zero, because
// position k's output could only have influenced positions >= k, none of
// which received a nonzero gradOutput when k>j.
void testCausalStructuralInvariant() {
    std::mt19937 rng(777);
    MultiHeadAttention attn(8, 2, 29);
    Tensor x = randomTensor(rng, {5, 8}, 0.3f);

    Tensor gradOutput({5, 8}, 0.0f);
    int j = 2; // only position 2 receives a gradient
    for (int col = 0; col < 8; ++col) {
        uint32_t bits = rng();
        gradOutput.at({j, col}) = (static_cast<float>(bits) / 4294967295.0f * 2.0f - 1.0f);
    }

    MultiHeadAttention::Grads g = attn.backward(x, gradOutput);

    bool ok = true;
    for (int k = j + 1; k < 5; ++k) {
        for (int col = 0; col < 8; ++col) {
            if (std::fabs(g.gradInput.at({k, col})) > 1e-5f) ok = false;
        }
    }
    expectTrue(ok, "Attention backward CAUSAL STRUCTURAL CHECK: gradient from position j "
                   "does not reach dL/dx at any position > j (precision-independent)");
}

int main() {
    testAttentionGradient();
    testCausalStructuralInvariant();
    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
