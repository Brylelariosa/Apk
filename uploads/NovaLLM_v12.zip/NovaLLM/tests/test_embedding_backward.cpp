// Standalone gradient-check tests for TokenEmbedding::backward - the
// scatter-ADD into the weight table. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_embedding_backward.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/embedding/TokenEmbedding.cpp \
//     ../app/src/main/cpp/core/training/GradientCheck.cpp \
//     -o test_embedding_backward && ./test_embedding_backward
#include <cstdio>
#include <cmath>
#include <random>
#include "core/embedding/TokenEmbedding.h"
#include "core/training/GradientCheck.h"
using namespace novallm;

static int g_failures = 0;
void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}
Tensor randomTensor(std::mt19937& rng, std::vector<int> shape, float scale) {
    Tensor t(shape);
    for (size_t i = 0; i < t.size(); ++i) {
        uint32_t bits = rng();
        float unit = static_cast<float>(bits) / 4294967295.0f;
        t.data()[i] = (unit * 2.0f - 1.0f) * scale;
    }
    return t;
}
float dotLoss(const Tensor& output, const Tensor& direction) {
    float s = 0.0f;
    for (size_t i = 0; i < output.size(); ++i) s += output.data()[i] * direction.data()[i];
    return s;
}

void testGradientMatches() {
    std::mt19937 rng(321);
    TokenEmbedding emb(10, 4, 3);
    std::vector<int> ids = {2, 5, 2, 7}; // id 2 repeats - tests accumulation
    Tensor direction = randomTensor(rng, {4, 4}, 1.0f);

    Tensor gradWeights = emb.backward(ids, direction);
    auto lossFn = [&]() { return dotLoss(emb.lookupSequence(ids), direction); };
    float err = gradcheck::maxRelativeError(emb.weights(), gradWeights, lossFn, 1e-3f, 40);
    expectTrue(err < 2e-2f, "TokenEmbedding backward: matches numerical gradient");
    std::printf("  (err=%e)\n", err);
}

// Precision-independent: rows for token ids that never appeared in the
// sequence must have EXACTLY zero gradient - the loss never depended on
// them at all.
void testUnusedRowsAreExactlyZero() {
    std::mt19937 rng(654);
    TokenEmbedding emb(10, 4, 9);
    std::vector<int> ids = {2, 5, 2, 7};
    Tensor direction = randomTensor(rng, {4, 4}, 1.0f);
    Tensor gradWeights = emb.backward(ids, direction);

    bool ok = true;
    for (int id = 0; id < 10; ++id) {
        bool used = (id == 2 || id == 5 || id == 7);
        if (!used) {
            for (int j = 0; j < 4; ++j) {
                if (gradWeights.at({id, j}) != 0.0f) ok = false;
            }
        }
    }
    expectTrue(ok, "TokenEmbedding structural check: unused token rows are EXACTLY zero (precision-independent)");
}

// Precision-independent: verify the scatter-ADD accumulated correctly for
// the repeated id (2) by direct construction, not finite differences.
void testAccumulationIsExact() {
    TokenEmbedding emb(10, 4, 1);
    std::vector<int> ids = {2, 5, 2, 7};
    Tensor direction({4, 4});
    for (size_t i = 0; i < direction.size(); ++i) direction.data()[i] = static_cast<float>(i) + 1.0f;

    Tensor gradWeights = emb.backward(ids, direction);
    bool ok = true;
    for (int j = 0; j < 4; ++j) {
        float expected = direction.at({0, j}) + direction.at({2, j}); // positions 0 and 2 both used id 2
        if (std::fabs(gradWeights.at({2, j}) - expected) > 1e-6f) ok = false;
    }
    expectTrue(ok, "TokenEmbedding structural check: repeated token id accumulates (scatter-ADD, not scatter-set)");
}

int main() {
    testGradientMatches();
    testUnusedRowsAreExactlyZero();
    testAccumulationIsExact();
    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
