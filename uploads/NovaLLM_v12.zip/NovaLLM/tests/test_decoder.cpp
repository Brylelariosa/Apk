// Standalone correctness tests for core/decoder. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_decoder.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/embedding/*.cpp \
//     ../app/src/main/cpp/core/transformer/*.cpp \
//     ../app/src/main/cpp/core/decoder/*.cpp \
//     -o test_decoder && ./test_decoder
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include "core/decoder/Model.h"
#include "core/decoder/Sampling.h"
#include "core/decoder/Generator.h"
#include "core/tokenizer/Tokenizer.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

Model::Config smallConfig(int vocabSize) {
    Model::Config cfg;
    cfg.vocabSize = vocabSize;
    cfg.embedDim = 16;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 64;
    cfg.maxSeqLen = 64;
    return cfg;
}

void testModelOutputShape() {
    Model model(smallConfig(300), /*seed=*/1);
    std::vector<int> ids = {5, 10, 15, 20};
    Tensor logits = model.forward(ids);
    expectTrue(logits.dim(0) == 4 && logits.dim(1) == 300, "Model: logits shape {seqLen, vocabSize}");
}

// Re-verify causality at the FULL multi-layer model level (stacked blocks
// + final norm + LM head) - stacking could in principle introduce a leak
// even though each individual block is causal, so this is worth re-proving
// here rather than assuming composition is automatically safe.
void testModelCausality() {
    Model model(smallConfig(300), /*seed=*/1);
    std::vector<int> idsA = {5, 10, 15, 20, 25};
    std::vector<int> idsB = {5, 10, 15, 20, 99};

    Tensor logitsA = model.forward(idsA);
    Tensor logitsB = model.forward(idsB);

    bool identical = true;
    for (int i = 0; i < 4 && identical; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(logitsA.at({i, v}) - logitsB.at({i, v})) > 1e-4f) { identical = false; break; }
        }
    }
    expectTrue(identical, "Model: causal mask holds through the full multi-layer stack");
}

void testGreedyIsDeterministic() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params greedy;
    greedy.temperature = 0.0f;

    Sampler s1(1);
    Sampler s2(999); // different seed must not matter for greedy
    int a = s1.sample(logits, greedy);
    int b = s2.sample(logits, greedy);
    expectTrue(a == 1 && b == 1, "Sampler: greedy always picks the argmax regardless of seed");
}

void testTopKOneMatchesGreedy() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params params;
    params.temperature = 1.0f;
    params.topK = 1;
    Sampler s(42);
    for (int i = 0; i < 10; ++i) {
        int picked = s.sample(logits, params);
        if (picked != 1) { expectTrue(false, "Sampler: topK=1 always returns the single highest-logit token"); return; }
    }
    expectTrue(true, "Sampler: topK=1 always returns the single highest-logit token");
}

void testTopPNearZeroMatchesArgmax() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params params;
    params.temperature = 1.0f;
    params.topP = 0.0001f; // nucleus should collapse to just the top token
    Sampler s(7);
    for (int i = 0; i < 10; ++i) {
        int picked = s.sample(logits, params);
        if (picked != 1) { expectTrue(false, "Sampler: topP near 0 collapses to the argmax token"); return; }
    }
    expectTrue(true, "Sampler: topP near 0 collapses to the argmax token");
}

void testSamplingDistributionRoughlyMatchesSoftmax() {
    // logits = [0, ln3] -> softmax = [0.25, 0.75]. Sample many times and
    // check the empirical split is in the right neighborhood (std dev of
    // Binomial(4000, 0.75) ~= 27, so +-150 is a very safe, non-flaky margin).
    std::vector<float> logits = {0.0f, std::log(3.0f)};
    Sampler::Params params; // temperature=1, no top-k/top-p
    Sampler s(123);
    int count1 = 0;
    const int trials = 4000;
    for (int i = 0; i < trials; ++i) {
        if (s.sample(logits, params) == 1) count1++;
    }
    bool inRange = (count1 > 2850 && count1 < 3150); // expected ~3000
    expectTrue(inRange, "Sampler: empirical distribution roughly matches softmax probabilities");
}

void testGeneratorRunsAndIsDeterministicWhenGreedy() {
    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox runs past the lazy dog"
    };
    tok.train(corpus, 30);
    tok.addSpecialToken("eos", "<eos>");

    Model model(smallConfig(static_cast<int>(tok.vocabSize())), /*seed=*/55);

    Generator::GenerationParams params;
    params.maxNewTokens = 8;
    params.sampling.temperature = 0.0f; // greedy - must be fully reproducible

    Generator gen1(model, tok, /*samplerSeed=*/1);
    Generator gen2(model, tok, /*samplerSeed=*/2); // seed shouldn't matter under greedy
    std::string out1 = gen1.generate("the quick", params);
    std::string out2 = gen2.generate("the quick", params);

    expectTrue(out1 == out2, "Generator: greedy generation is fully deterministic regardless of sampler seed");
    expectTrue(!out1.empty(), "Generator: produces non-empty output for maxNewTokens > 0");
}

// THE critical test for this subsystem: incremental (KV-cached) forward
// must produce numerically identical results to the already-trusted
// non-cached forward(), token by token. Position-offset bugs in cached
// generation are a well-known, easy-to-get-wrong class of bug that
// wouldn't crash anything - they'd just silently produce a broken model.
void testKVCacheMatchesNonCachedExactly() {
    Model model(smallConfig(300), /*seed=*/1);
    std::vector<int> ids = {5, 10, 15, 20, 25, 30};

    Tensor refLogits = model.forward(ids); // {6, vocabSize}, trusted path

    model.resetCache();
    std::vector<std::vector<float>> incrementalRows;
    for (int id : ids) {
        std::vector<int> step = {id}; // one token at a time, like real generation
        Tensor stepLogits = model.forwardIncremental(step); // {1, vocabSize}
        incrementalRows.emplace_back(stepLogits.data(), stepLogits.data() + stepLogits.dim(1));
    }

    bool allMatch = true;
    for (size_t i = 0; i < ids.size() && allMatch; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(refLogits.at({static_cast<int>(i), v}) - incrementalRows[i][static_cast<size_t>(v)]) > 1e-3f) {
                allMatch = false;
                break;
            }
        }
    }
    expectTrue(allMatch, "KV-CACHE: token-by-token incremental forward exactly matches non-cached forward");
}

void testKVCachePrimingWholePromptAlsoMatches() {
    Model model(smallConfig(300), /*seed=*/2);
    std::vector<int> ids = {7, 14, 21, 28};

    Tensor refLogits = model.forward(ids);

    model.resetCache();
    Tensor primedLogits = model.forwardIncremental(ids); // whole prompt in ONE incremental call

    bool allMatch = true;
    for (int i = 0; i < 4 && allMatch; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(refLogits.at({i, v}) - primedLogits.at({i, v})) > 1e-3f) { allMatch = false; break; }
        }
    }
    expectTrue(allMatch, "KV-CACHE: priming with the whole prompt in one call also matches non-cached forward");
}

void testResetCacheActuallyResets() {
    Model model(smallConfig(300), /*seed=*/3);
    std::vector<int> ids = {1, 2, 3};

    model.resetCache();
    Tensor first = model.forwardIncremental(ids);

    model.resetCache();
    Tensor second = model.forwardIncremental(ids); // same ids, fresh cache - must match `first` exactly

    bool identical = true;
    for (int i = 0; i < 3 && identical; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(first.at({i, v}) - second.at({i, v})) > 1e-6f) { identical = false; break; }
        }
    }
    expectTrue(identical, "resetCache(): fresh cache reproduces identical results, not contaminated by prior sequence");
}

void testModelSaveLoadRoundTrip() {
    Model model(smallConfig(300), /*seed=*/42);
    std::vector<int> ids = {3, 6, 9, 12};
    Tensor before = model.forward(ids);

    std::string path = "/tmp/novallm_test_model.bin";
    model.save(path);

    Model loaded = Model::load(path);
    Tensor after = loaded.forward(ids);

    bool identical = true;
    for (int i = 0; i < 4 && identical; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(before.at({i, v}) - after.at({i, v})) > 1e-6f) { identical = false; break; }
        }
    }
    expectTrue(identical, "Model save/load: loaded model produces bit-for-bit identical forward() output");

    // The loaded model's cache must also start fresh and still match the
    // non-cached reference - save/load must not leak or corrupt cache state.
    loaded.resetCache();
    std::vector<float> lastRow;
    for (int step = 0; step < 4; ++step) {
        std::vector<int> single = {ids[static_cast<size_t>(step)]};
        Tensor stepLogits = loaded.forwardIncremental(single);
        if (step == 3) lastRow.assign(stepLogits.data(), stepLogits.data() + stepLogits.dim(1));
    }
    bool lastMatches = true;
    for (int v = 0; v < 300; ++v) {
        if (std::fabs(before.at({3, v}) - lastRow[static_cast<size_t>(v)]) > 1e-3f) { lastMatches = false; break; }
    }
    expectTrue(lastMatches, "Model save/load: loaded model's KV-cached generation also matches the reference");

    std::remove(path.c_str());
}

int main() {
    testModelOutputShape();
    testModelCausality();
    testGreedyIsDeterministic();
    testTopKOneMatchesGreedy();
    testTopPNearZeroMatchesArgmax();
    testSamplingDistributionRoughlyMatchesSoftmax();
    testGeneratorRunsAndIsDeterministicWhenGreedy();
    testKVCacheMatchesNonCachedExactly();
    testKVCachePrimingWholePromptAlsoMatches();
    testResetCacheActuallyResets();
    testModelSaveLoadRoundTrip();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
