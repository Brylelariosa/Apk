// Standalone gradient-check tests for TransformerBlock::backward -
// composing LayerNorm/Attention/FeedForward through the residual
// connections. No Android/JNI needed.
//
// Note: this deeper computation chain needs a LARGER finite-difference
// epsilon (1e-2) than the individual sublayers (1e-3) - confirmed by
// sweeping epsilon during development. Using the smaller epsilon here
// makes float32 rounding noise from the longer LN->Attn->LN->FFN chain
// dominate the signal, which looks exactly like a real bug (10%+
// "error") until you sweep epsilon and see it improve monotonically as
// epsilon grows, the opposite of what curvature bias would do.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_block.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/transformer/Linear.cpp \
//     ../app/src/main/cpp/core/transformer/LayerNorm.cpp \
//     ../app/src/main/cpp/core/transformer/FeedForward.cpp \
//     ../app/src/main/cpp/core/transformer/Attention.cpp \
//     ../app/src/main/cpp/core/transformer/KVCache.cpp \
//     ../app/src/main/cpp/core/transformer/Block.cpp \
//     ../app/src/main/cpp/core/training/GradientCheck.cpp \
//     -o test_block && ./test_block
#include <cstdio>
#include <cmath>
#include <random>
#include "core/transformer/Block.h"
#include "core/training/GradientCheck.h"

using namespace novallm;

static int g_failures = 0;
void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

Tensor randomTensor(std::mt19937& rng, std::vector<int> shape, float scale) {
    Tensor t(shape);
    for (size_t i = 0; i < t.size(); ++i) {
        uint32_t bits = rng();
        float unit = static_cast<float>(bits) / 4294967295.0f;
        t.data()[i] = (unit * 2.0f - 1.0f) * scale;
    }
    return t;
}

float dotLoss(const Tensor& output, const Tensor& direction) {
    float s = 0.0f;
    for (size_t i = 0; i < output.size(); ++i) s += output.data()[i] * direction.data()[i];
    return s;
}

void testBlockGradient() {
    std::mt19937 rng(999);
    TransformerBlock block(8, 2, 32, 41);
    Tensor x = randomTensor(rng, {4, 8}, 0.3f);
    Tensor direction = randomTensor(rng, block.forward(x).shape(), 1.0f);

    TransformerBlock::Grads g = block.backward(x, direction);
    auto lossFn = [&]() { return dotLoss(block.forward(x), direction); };

    float errX = gradcheck::maxRelativeError(x, g.gradInput, lossFn);
    expectTrue(errX < 2e-2f, "Block backward: gradInput matches numerical gradient");

    // Spot-check one parameter from each of the four sublayers, reaching
    // through the new accessors - if the composition/residual-splitting
    // logic were wrong, these would be wrong even though each sublayer's
    // own backward() is already independently verified.
    float errGamma1 = gradcheck::maxRelativeError(block.ln1().gamma(), g.ln1.gradGamma, lossFn, 1e-2f, 20);
    expectTrue(errGamma1 < 2e-2f, "Block backward: ln1 gradGamma matches (reached through composition)");

    float errWq = gradcheck::maxRelativeError(block.attn().wq().weight(), g.attn.gradWq, lossFn, 1e-2f, 20);
    expectTrue(errWq < 2e-2f, "Block backward: attn gradWq matches (reached through composition)");

    float errGamma2 = gradcheck::maxRelativeError(block.ln2().gamma(), g.ln2.gradGamma, lossFn, 1e-2f, 20);
    expectTrue(errGamma2 < 2e-2f, "Block backward: ln2 gradGamma matches (reached through composition)");

    float errW1 = gradcheck::maxRelativeError(block.ffn().fc1().weight(), g.ffn.gradW1, lossFn, 1e-2f, 20);
    expectTrue(errW1 < 2e-2f, "Block backward: ffn fc1 gradW1 matches (reached through composition)");

    std::printf("  (errX=%e errGamma1=%e errWq=%e errGamma2=%e errW1=%e)\n",
                errX, errGamma1, errWq, errGamma2, errW1);
}

void testBlockCausalStructuralInvariant() {
    std::mt19937 rng(888);
    TransformerBlock block(8, 2, 32, 63);
    Tensor x = randomTensor(rng, {5, 8}, 0.3f);

    Tensor gradOutput({5, 8}, 0.0f);
    int j = 1;
    for (int col = 0; col < 8; ++col) {
        uint32_t bits = rng();
        gradOutput.at({j, col}) = (static_cast<float>(bits) / 4294967295.0f * 2.0f - 1.0f);
    }

    TransformerBlock::Grads g = block.backward(x, gradOutput);

    bool ok = true;
    for (int k = j + 1; k < 5; ++k) {
        for (int col = 0; col < 8; ++col) {
            if (std::fabs(g.gradInput.at({k, col})) > 1e-5f) ok = false;
        }
    }
    expectTrue(ok, "Block backward CAUSAL STRUCTURAL CHECK holds end-to-end through the full "
                   "block (LN -> Attn -> +res -> LN -> FFN -> +res), precision-independent");
}

int main() {
    testBlockGradient();
    testBlockCausalStructuralInvariant();
    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
