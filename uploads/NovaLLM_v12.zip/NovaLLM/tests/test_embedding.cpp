// Standalone correctness tests for core/embedding. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_embedding.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/embedding/TokenEmbedding.cpp \
//     ../app/src/main/cpp/core/embedding/PositionalEncoding.cpp \
//     -o test_embedding && ./test_embedding
#include <cstdio>
#include <cmath>
#include <vector>
#include "core/embedding/TokenEmbedding.h"
#include "core/embedding/PositionalEncoding.h"

using namespace novallm;

static int g_failures = 0;

void expectNear(float actual, float expected, const char* what, float eps = 1e-5f) {
    if (std::fabs(actual - expected) > eps) {
        std::printf("FAIL  %s: expected %f, got %f\n", what, expected, actual);
        g_failures++;
    } else {
        std::printf("pass  %s\n", what);
    }
}

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

void testTokenEmbeddingShape() {
    TokenEmbedding emb(10, 4);
    expectTrue(emb.weights().shape() == std::vector<int>({10, 4}), "embedding weight matrix shape");
}

void testTokenEmbeddingLookupMatchesWeights() {
    TokenEmbedding emb(10, 4, /*seed=*/7);
    Tensor row = emb.lookup(3);
    expectTrue(row.shape() == std::vector<int>({4}), "lookup() returns {embedDim} shaped row");
    for (int j = 0; j < 4; ++j) {
        expectNear(row.data()[j], emb.weights().at({3, j}), "lookup() row matches weight table");
    }
}

void testTokenEmbeddingSequence() {
    TokenEmbedding emb(10, 4, /*seed=*/7);
    std::vector<int> ids = {1, 5, 2};
    Tensor seq = emb.lookupSequence(ids);
    expectTrue(seq.shape() == std::vector<int>({3, 4}), "lookupSequence() shape is {seqLen, embedDim}");
    for (size_t i = 0; i < ids.size(); ++i) {
        for (int j = 0; j < 4; ++j) {
            expectNear(seq.at({static_cast<int>(i), j}), emb.weights().at({ids[i], j}),
                       "lookupSequence() row matches individual lookup");
        }
    }
}

void testTokenEmbeddingOutOfRangeThrows() {
    TokenEmbedding emb(10, 4);
    bool threw = false;
    try { emb.lookup(999); } catch (const std::out_of_range&) { threw = true; }
    expectTrue(threw, "lookup() throws on out-of-range token id");
}

void testPositionalEncodingShapeAndZeroPosition() {
    PositionalEncoding pe(16, 6);
    Tensor table = pe.encode(16);
    expectTrue(table.shape() == std::vector<int>({16, 6}), "positional table shape");

    // At position 0, angle = 0 for every dimension pair, so every even
    // index is sin(0)=0 and every odd index is cos(0)=1, regardless of i.
    for (int i = 0; i < 6; ++i) {
        float expected = (i % 2 == 0) ? 0.0f : 1.0f;
        expectNear(table.at({0, i}), expected, "position 0 encoding is deterministic sin/cos(0)");
    }
}

void testPositionalEncodingApplyTo() {
    TokenEmbedding emb(10, 4, /*seed=*/3);
    PositionalEncoding pe(16, 4);
    std::vector<int> ids = {2, 4};
    Tensor tokenEmb = emb.lookupSequence(ids);
    Tensor combined = pe.applyTo(tokenEmb);

    Tensor posTable = pe.encode(2);
    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 4; ++j) {
            float expected = tokenEmb.at({i, j}) + posTable.at({i, j});
            expectNear(combined.at({i, j}), expected, "applyTo() == embedding + positional table");
        }
    }
}

void testPositionalEncodingExceedsMaxThrows() {
    PositionalEncoding pe(4, 4);
    bool threw = false;
    try { pe.encode(5); } catch (const std::out_of_range&) { threw = true; }
    expectTrue(threw, "encode() throws when seqLen exceeds maxSeqLen");
}

int main() {
    testTokenEmbeddingShape();
    testTokenEmbeddingLookupMatchesWeights();
    testTokenEmbeddingSequence();
    testTokenEmbeddingOutOfRangeThrows();
    testPositionalEncodingShapeAndZeroPosition();
    testPositionalEncodingApplyTo();
    testPositionalEncodingExceedsMaxThrows();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
