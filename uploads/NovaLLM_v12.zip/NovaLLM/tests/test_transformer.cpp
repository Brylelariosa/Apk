// Standalone correctness tests for core/transformer. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_transformer.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/transformer/Linear.cpp \
//     ../app/src/main/cpp/core/transformer/LayerNorm.cpp \
//     ../app/src/main/cpp/core/transformer/FeedForward.cpp \
//     ../app/src/main/cpp/core/transformer/Attention.cpp \
//     ../app/src/main/cpp/core/transformer/Block.cpp \
//     -o test_transformer && ./test_transformer
#include <cstdio>
#include <cmath>
#include <vector>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/transformer/Linear.h"
#include "core/transformer/LayerNorm.h"
#include "core/transformer/FeedForward.h"
#include "core/transformer/Attention.h"
#include "core/transformer/Block.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

void expectNear(float actual, float expected, const char* what, float eps = 1e-3f) {
    if (std::fabs(actual - expected) > eps) {
        std::printf("FAIL  %s: expected %f, got %f\n", what, expected, actual);
        g_failures++;
    } else {
        std::printf("pass  %s\n", what);
    }
}

void testLinearShape() {
    Linear lin(8, 16);
    Tensor x({3, 8}, 1.0f);
    Tensor y = lin.forward(x);
    expectTrue(y.shape() == std::vector<int>({3, 16}), "Linear: output shape {seqLen, outDim}");
}

void testLayerNormStats() {
    LayerNorm ln(8);
    Tensor x({2, 8});
    for (size_t i = 0; i < x.size(); ++i) x.data()[i] = static_cast<float>(i) * 3.1f - 4.0f;
    Tensor y = ln.forward(x);

    // Default gamma=1, beta=0, so each output row should have ~zero mean
    // and ~unit variance.
    for (int i = 0; i < 2; ++i) {
        float mean = 0.0f;
        for (int j = 0; j < 8; ++j) mean += y.at({i, j});
        mean /= 8.0f;
        float var = 0.0f;
        for (int j = 0; j < 8; ++j) { float d = y.at({i, j}) - mean; var += d * d; }
        var /= 8.0f;
        expectNear(mean, 0.0f, "LayerNorm: row mean ~0");
        expectNear(var, 1.0f, "LayerNorm: row variance ~1");
    }
}

void testGelu() {
    expectNear(gelu(0.0f), 0.0f, "gelu(0) == 0");
    expectTrue(gelu(5.0f) > 4.9f, "gelu(large positive) ~= x");
    expectTrue(std::fabs(gelu(-5.0f)) < 0.01f, "gelu(large negative) ~= 0");
}

void testFeedForwardShape() {
    FeedForward ffn(8, 32);
    Tensor x({3, 8}, 0.5f);
    Tensor y = ffn.forward(x);
    expectTrue(y.shape() == std::vector<int>({3, 8}), "FeedForward: output shape matches input (embedDim preserved)");
}

void testSoftmaxRows() {
    Tensor x({2, 3});
    float vals[] = {1, 2, 3, 0, 0, 0};
    for (int i = 0; i < 6; ++i) x.data()[i] = vals[i];
    matrix::softmaxRows(x);
    for (int i = 0; i < 2; ++i) {
        float sum = x.at({i, 0}) + x.at({i, 1}) + x.at({i, 2});
        expectNear(sum, 1.0f, "softmaxRows: row sums to 1");
    }
    // Uniform row [0,0,0] -> each entry should be exactly 1/3.
    expectNear(x.at({1, 0}), 1.0f / 3.0f, "softmaxRows: uniform row gives uniform distribution");
}

void testSliceSetColumnsRoundTrip() {
    Tensor a({3, 6});
    for (size_t i = 0; i < a.size(); ++i) a.data()[i] = static_cast<float>(i);

    Tensor slice = matrix::sliceColumns(a, 2, 3);
    expectTrue(slice.shape() == std::vector<int>({3, 3}), "sliceColumns: shape");

    Tensor rebuilt(a.shape(), 0.0f);
    matrix::setColumns(rebuilt, 0, matrix::sliceColumns(a, 0, 2));
    matrix::setColumns(rebuilt, 2, matrix::sliceColumns(a, 2, 3));
    matrix::setColumns(rebuilt, 5, matrix::sliceColumns(a, 5, 1));

    bool identical = true;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::fabs(a.data()[i] - rebuilt.data()[i]) > 1e-6f) identical = false;
    }
    expectTrue(identical, "sliceColumns + setColumns: full round trip reconstructs original");
}

void testAttentionShape() {
    MultiHeadAttention attn(8, 2, /*seed=*/1);
    Tensor x({4, 8}, 0.1f);
    Tensor y = attn.forward(x);
    expectTrue(y.shape() == std::vector<int>({4, 8}), "MultiHeadAttention: output shape preserved");
}

void testAttentionRejectsBadHeadCount() {
    bool threw = false;
    try { MultiHeadAttention attn(8, 3); (void)attn; } // 8 not divisible by 3
    catch (const std::invalid_argument&) { threw = true; }
    expectTrue(threw, "MultiHeadAttention: throws when embedDim not divisible by numHeads");
}

// The single most important correctness property of a decoder-only
// transformer: position i's output must be completely unaffected by
// anything at position > i. If this fails, the model would be "cheating"
// by reading future tokens - useless (or actively broken) for generation.
void testCausalMaskingNoFutureLeakage() {
    const int embedDim = 8;
    const int numHeads = 2;

    MultiHeadAttention attn(embedDim, numHeads, /*seed=*/99);

    Tensor xA({5, embedDim});
    Tensor xB({5, embedDim});
    for (size_t i = 0; i < xA.size(); ++i) {
        xA.data()[i] = static_cast<float>(i) * 0.05f;
        xB.data()[i] = xA.data()[i];
    }
    // Only the LAST position (index 4) differs between the two inputs.
    for (int j = 0; j < embedDim; ++j) {
        xB.at({4, j}) = xA.at({4, j}) + 10.0f;
    }

    Tensor outA = attn.forward(xA);
    Tensor outB = attn.forward(xB);

    bool earlierPositionsIdentical = true;
    for (int i = 0; i < 4 && earlierPositionsIdentical; ++i) {
        for (int j = 0; j < embedDim; ++j) {
            if (std::fabs(outA.at({i, j}) - outB.at({i, j})) > 1e-5f) {
                earlierPositionsIdentical = false;
                break;
            }
        }
    }
    expectTrue(earlierPositionsIdentical,
               "CAUSAL MASK: positions before the changed token are byte-for-byte unaffected");

    bool lastPositionDiffers = false;
    for (int j = 0; j < embedDim; ++j) {
        if (std::fabs(outA.at({4, j}) - outB.at({4, j})) > 1e-5f) { lastPositionDiffers = true; break; }
    }
    expectTrue(lastPositionDiffers,
               "sanity check: the changed position's own output DOES change (attention isn't a no-op)");
}

void testTransformerBlockShapeAndCausality() {
    TransformerBlock block(8, 2, 32, /*seed=*/5);
    Tensor xA({4, 8});
    Tensor xB({4, 8});
    for (size_t i = 0; i < xA.size(); ++i) {
        xA.data()[i] = static_cast<float>(i) * 0.02f;
        xB.data()[i] = xA.data()[i];
    }
    for (int j = 0; j < 8; ++j) xB.at({3, j}) = xA.at({3, j}) + 5.0f;

    Tensor outA = block.forward(xA);
    Tensor outB = block.forward(xB);
    expectTrue(outA.shape() == std::vector<int>({4, 8}), "TransformerBlock: output shape preserved");

    bool identical = true;
    for (int i = 0; i < 3 && identical; ++i) {
        for (int j = 0; j < 8; ++j) {
            if (std::fabs(outA.at({i, j}) - outB.at({i, j})) > 1e-5f) { identical = false; break; }
        }
    }
    expectTrue(identical, "TransformerBlock: causal masking holds end-to-end through the full block");
}

int main() {
    testLinearShape();
    testLayerNormStats();
    testGelu();
    testFeedForwardShape();
    testSoftmaxRows();
    testSliceSetColumnsRoundTrip();
    testAttentionShape();
    testAttentionRejectsBadHeadCount();
    testCausalMaskingNoFutureLeakage();
    testTransformerBlockShapeAndCausality();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
