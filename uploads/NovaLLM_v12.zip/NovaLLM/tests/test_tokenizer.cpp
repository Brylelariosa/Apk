// Standalone correctness tests for core/tokenizer. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_tokenizer.cpp \
//     ../app/src/main/cpp/core/tokenizer/UTF8.cpp \
//     ../app/src/main/cpp/core/tokenizer/Vocabulary.cpp \
//     ../app/src/main/cpp/core/tokenizer/BPE.cpp \
//     ../app/src/main/cpp/core/tokenizer/Tokenizer.cpp \
//     -o test_tokenizer && ./test_tokenizer
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include "core/tokenizer/UTF8.h"
#include "core/tokenizer/Vocabulary.h"
#include "core/tokenizer/BPE.h"
#include "core/tokenizer/Tokenizer.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

void expectEq(size_t actual, size_t expected, const char* what) {
    if (actual != expected) {
        std::printf("FAIL  %s: expected %zu, got %zu\n", what, expected, actual);
        g_failures++;
    } else {
        std::printf("pass  %s\n", what);
    }
}

void testUtf8() {
    expectEq(utf8::codepointCount("hello"), 5, "utf8 ASCII codepoint count");
    // "caf\xC3\xA9" = "café" - 4 codepoints, 5 bytes (e-acute is 2 bytes)
    std::string cafe = "caf\xC3\xA9";
    expectEq(cafe.size(), 5, "utf8 cafe byte length");
    expectEq(utf8::codepointCount(cafe), 4, "utf8 cafe codepoint count");
    expectTrue(utf8::isValid(cafe), "utf8 cafe is valid");
    expectTrue(!utf8::isValid(std::string("\xC3")), "utf8 truncated sequence is invalid");
}

void testVocabulary() {
    Vocabulary v;
    expectEq(v.size(), 256, "vocab starts with 256 byte tokens");
    expectEq(static_cast<size_t>(v.idFor(std::string(1, 'a'))), 97, "vocab byte 'a' has id 97");

    int id = v.addToken("hello");
    expectEq(static_cast<size_t>(id), 256, "vocab first custom token gets id 256");
    expectEq(static_cast<size_t>(v.addToken("hello")), 256, "vocab re-adding same token returns same id");
    expectTrue(v.tokenFor(256) == "hello", "vocab tokenFor roundtrip");

    int bosId = v.addSpecialToken("bos", "<bos>");
    expectEq(static_cast<size_t>(v.specialTokenId("bos")), static_cast<size_t>(bosId), "vocab special token lookup");
    expectTrue(v.specialTokenId("nonexistent") == -1, "vocab missing special token returns -1");
}

void testBpeTraining() {
    Vocabulary v;
    BPE bpe;
    // "abab" x3: pair (a,b) is the most frequent -> merges to AB first,
    // leaving [AB,AB] x3 -> that merges again to ABAB. Then nothing left.
    std::vector<std::string> corpus = {"abab", "abab", "abab"};
    bpe.train(corpus, v, 10);

    expectEq(bpe.mergeCount(), 2, "bpe learns exactly 2 merges from 'abab'x3 (stops early)");

    std::vector<int> encoded = bpe.encode("abab");
    expectEq(encoded.size(), 1, "bpe encodes 'abab' down to a single token");

    // Unseen pair - should fall back to raw bytes, no information loss.
    std::vector<int> unseenEncoded = bpe.encode("ba");
    expectEq(unseenEncoded.size(), 2, "bpe leaves never-merged pair 'ba' as raw bytes");
}

void testTokenizerRoundTrip() {
    Tokenizer tok;
    std::vector<std::string> corpus = {"abab", "abab", "abab", "the quick brown fox"};
    tok.train(corpus, 20);

    for (const std::string& sample : {std::string("abab"), std::string("ba"),
                                        std::string("the quick brown fox"),
                                        std::string("caf\xC3\xA9"),
                                        std::string("never seen before! 123")}) {
        std::vector<int> ids = tok.encode(sample);
        std::string back = tok.decode(ids);
        expectTrue(back == sample, ("tokenizer roundtrip: \"" + sample + "\"").c_str());
    }

    expectTrue(tok.vocabSize() > 256, "tokenizer vocab grew past the base 256 bytes");
}

void testSaveLoad() {
    Tokenizer tok;
    std::vector<std::string> corpus = {"abab", "abab", "abab", "the quick brown fox"};
    tok.train(corpus, 20);
    tok.addSpecialToken("eos", "<eos>");

    std::string path = "/tmp/novallm_test_tokenizer";
    tok.save(path);

    Tokenizer reloaded;
    reloaded.load(path);

    expectEq(reloaded.vocabSize(), tok.vocabSize(), "save/load preserves vocab size");
    expectEq(reloaded.mergeCount(), tok.mergeCount(), "save/load preserves merge count");

    std::vector<int> before = tok.encode("the quick brown fox");
    std::vector<int> after = reloaded.encode("the quick brown fox");
    expectTrue(before == after, "save/load produces identical encoding");
    expectEq(static_cast<size_t>(reloaded.specialTokenId("eos")),
              static_cast<size_t>(tok.specialTokenId("eos")), "save/load preserves special tokens");

    std::remove((path + ".vocab").c_str());
    std::remove((path + ".merges").c_str());
}

int main() {
    testUtf8();
    testVocabulary();
    testBpeTraining();
    testTokenizerRoundTrip();
    testSaveLoad();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
