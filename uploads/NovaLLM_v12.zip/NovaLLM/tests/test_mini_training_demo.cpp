// A real, working, multi-step training run - not a gradient check. Trains
// a tiny model to overfit one short repeated phrase via actual
// forward -> CrossEntropyLoss -> Model::backward -> Adam, watching loss
// drop over 300 steps, then samples before/after to show what changed.
//
// This is the classic "can the pipeline even memorize a handful of
// examples" sanity check - the first thing you'd want to see work before
// trusting a training loop on anything larger. No Android/JNI needed.
//
// Termux: link against every .cpp under core/math, core/tokenizer,
// core/embedding, core/transformer, core/decoder, and core/training.
#include <cstdio>
#include <cmath>
#include <string>
#include "core/tokenizer/Tokenizer.h"
#include "core/decoder/Model.h"
#include "core/decoder/Generator.h"
#include "core/training/Loss.h"
#include "core/training/ModelOptimizer.h"
using namespace novallm;

// Same hazard as jni_bridge.cpp: generated text from an undertrained
// model can contain arbitrary bytes, including invalid UTF-8. Escape
// before printing to a terminal (or, on-device, before NewStringUTF).
std::string escapeForDisplay(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (c >= 0x20 && c < 0x7F) {
            out += static_cast<char>(c);
        } else {
            char buf[8];
            std::snprintf(buf, sizeof(buf), "\\x%02X", c);
            out += buf;
        }
    }
    return out;
}

int main() {
    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox jumps over the lazy dog"
    };
    tok.train(corpus, 40);

    Model::Config cfg;
    cfg.vocabSize = static_cast<int>(tok.vocabSize());
    cfg.embedDim = 16;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 64;
    cfg.maxSeqLen = 32;
    Model model(cfg, 42);
    ModelOptimizer optimizer(cfg.numLayers);

    std::string text = "the quick brown fox jumps over the lazy dog";
    std::vector<int> ids = tok.encode(text);
    // Next-token prediction: targets[i] = ids[i+1], last position predicts
    // the first token again (wraps), fine for this overfitting demo.
    std::vector<int> targets(ids.begin() + 1, ids.end());
    targets.push_back(ids[0]);

    Generator genBefore(model, tok, 1);
    Generator::GenerationParams genParams;
    genParams.maxNewTokens = 15;
    genParams.sampling.temperature = 0.0f; // greedy, deterministic
    std::string before = genBefore.generate("the quick", genParams);

    printf("=== Before training ===\n");
    printf("generated: \"%s\"\n\n", escapeForDisplay(before).c_str());

    printf("=== Training (300 steps, watch the loss) ===\n");
    const int numSteps = 300;
    for (int step = 0; step < numSteps; ++step) {
        Tensor logits = model.forward(ids);
        Tensor gradLogits;
        float loss = CrossEntropyLoss::forwardBackward(logits, targets, gradLogits);
        Model::Grads grads = model.backward(ids, gradLogits);
        optimizer.step(model, grads, 0.01f);

        if (step == 0 || (step + 1) % 50 == 0) {
            printf("step %3d: loss=%.5f\n", step + 1, loss);
        }
    }

    Generator genAfter(model, tok, 1);
    std::string after = genAfter.generate("the quick", genParams);
    printf("\n=== After training ===\n");
    printf("generated: \"%s\"\n", escapeForDisplay(after).c_str());

    return 0;
}
