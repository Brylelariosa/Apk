// Standalone correctness tests for core/math. No Android/JNI/Gradle needed -
// build and run this directly in Termux for a fast local check before you
// ever touch the CI pipeline.
//
// Termux:
//   pkg install clang
//   cd tests
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_math.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/math/MemoryPool.cpp \
//     -o test_math && ./test_math
#include <cstdio>
#include <cmath>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/MemoryPool.h"

using namespace novallm;

static int g_failures = 0;

void expectNear(float actual, float expected, const char* what, float eps = 1e-5f) {
    if (std::fabs(actual - expected) > eps) {
        std::printf("FAIL  %s: expected %f, got %f\n", what, expected, actual);
        g_failures++;
    } else {
        std::printf("pass  %s\n", what);
    }
}

void testTensorBasics() {
    Tensor t({2, 3});
    t.fill(1.5f);
    expectNear(t.at({0, 0}), 1.5f, "Tensor::fill / at()");
    expectNear(static_cast<float>(t.size()), 6.0f, "Tensor::size()");

    t.at({1, 2}) = 9.0f;
    expectNear(t.at({1, 2}), 9.0f, "Tensor::at() write");
}

void testMatmulIdentity() {
    // A (2x2) * I (2x2) == A
    Tensor a({2, 2});
    a.data()[0] = 1; a.data()[1] = 2;
    a.data()[2] = 3; a.data()[3] = 4;

    Tensor identity({2, 2});
    identity.data()[0] = 1; identity.data()[1] = 0;
    identity.data()[2] = 0; identity.data()[3] = 1;

    Tensor c = matrix::matmul(a, identity);
    expectNear(c.at({0, 0}), 1, "matmul identity [0][0]");
    expectNear(c.at({0, 1}), 2, "matmul identity [0][1]");
    expectNear(c.at({1, 0}), 3, "matmul identity [1][0]");
    expectNear(c.at({1, 1}), 4, "matmul identity [1][1]");
}

void testMatmulKnownValues() {
    // [1 2 3]   [ 7  8]     [ 58  64]
    // [4 5 6] x [ 9 10]  =  [139 154]
    //           [11 12]
    Tensor a({2, 3});
    float av[] = {1, 2, 3, 4, 5, 6};
    for (int i = 0; i < 6; i++) a.data()[i] = av[i];

    Tensor b({3, 2});
    float bv[] = {7, 8, 9, 10, 11, 12};
    for (int i = 0; i < 6; i++) b.data()[i] = bv[i];

    Tensor c = matrix::matmul(a, b);
    expectNear(c.at({0, 0}), 58, "matmul known [0][0]");
    expectNear(c.at({0, 1}), 64, "matmul known [0][1]");
    expectNear(c.at({1, 0}), 139, "matmul known [1][0]");
    expectNear(c.at({1, 1}), 154, "matmul known [1][1]");
}

void testTranspose() {
    Tensor a({2, 3});
    float av[] = {1, 2, 3, 4, 5, 6};
    for (int i = 0; i < 6; i++) a.data()[i] = av[i];
    Tensor t = matrix::transpose(a);
    expectNear(static_cast<float>(t.dim(0)), 3, "transpose rows");
    expectNear(static_cast<float>(t.dim(1)), 2, "transpose cols");
    expectNear(t.at({0, 0}), 1, "transpose [0][0]");
    expectNear(t.at({2, 1}), 6, "transpose [2][1]");
}

void testAddBias() {
    Tensor a({2, 3}, 1.0f);
    Tensor bias({3});
    bias.data()[0] = 10; bias.data()[1] = 20; bias.data()[2] = 30;
    Tensor c = matrix::addBias(a, bias);
    expectNear(c.at({0, 0}), 11, "addBias row0 col0");
    expectNear(c.at({1, 2}), 31, "addBias row1 col2");
}

void testMemoryPool() {
    MemoryPool pool(1024);
    float* a = pool.allocFloats(10);
    float* b = pool.allocFloats(10);
    for (int i = 0; i < 10; i++) a[i] = 1.0f;
    for (int i = 0; i < 10; i++) b[i] = 2.0f;
    bool overlap = false;
    for (int i = 0; i < 10; i++) if (a[i] != 1.0f) overlap = true;
    if (overlap) { std::printf("FAIL  MemoryPool: alloc overlap\n"); g_failures++; }
    else { std::printf("pass  MemoryPool: non-overlapping allocs\n"); }

    pool.reset();
    if (pool.used() != 0) { std::printf("FAIL  MemoryPool: reset\n"); g_failures++; }
    else { std::printf("pass  MemoryPool: reset\n"); }
}

int main() {
    testTensorBasics();
    testMatmulIdentity();
    testMatmulKnownValues();
    testTranspose();
    testAddBias();
    testMemoryPool();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
