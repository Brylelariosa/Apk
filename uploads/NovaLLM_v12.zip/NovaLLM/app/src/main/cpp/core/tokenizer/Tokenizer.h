#pragma once
#include <string>
#include <vector>
#include "Vocabulary.h"
#include "BPE.h"

namespace novallm {

// Public facade. Vocabulary (id<->bytes) + BPE (merge rules) together make
// a complete, trainable, saveable/loadable tokenizer.
class Tokenizer {
public:
    Tokenizer() = default; // starts with the 256-byte base vocabulary, no merges

    void train(const std::vector<std::string>& corpus, int numMerges);

    std::vector<int> encode(const std::string& text) const;
    std::string decode(const std::vector<int>& ids) const;

    void addSpecialToken(const std::string& name, const std::string& tokenBytes);
    int specialTokenId(const std::string& name) const;

    size_t vocabSize() const { return vocab_.size(); }
    size_t mergeCount() const { return bpe_.mergeCount(); }

    // Saves/loads both the vocabulary and merge rules. `pathPrefix` gets
    // ".vocab" / ".merges" appended, e.g. passing ".../tokenizer" writes
    // ".../tokenizer.vocab" and ".../tokenizer.merges".
    void save(const std::string& pathPrefix) const;
    void load(const std::string& pathPrefix);

private:
    Vocabulary vocab_;
    BPE bpe_;
};

} // namespace novallm
