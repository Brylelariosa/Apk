#pragma once
#include "../math/Tensor.h"

namespace novallm {

// Adam optimizer (Kingma & Ba 2014) for a single tensor. Not plain SGD -
// transformers are notoriously hard to train with vanilla SGD, so this
// was the right first optimizer to build rather than a throwaway one.
//
// One Adam instance per learnable tensor, each with its own persistent
// per-element momentum (m) and variance (v) state and its own step
// counter t - equivalent to a single shared global step counter as long
// as every parameter's step() is called once per training iteration,
// which is the normal usage pattern (see ModelOptimizer).
class Adam {
public:
    explicit Adam(float beta1 = 0.9f, float beta2 = 0.999f, float eps = 1e-8f);

    // Updates `param` in place using `grad`. m/v state is lazily sized to
    // match `param` on first call. `lr` is passed per-call rather than
    // fixed at construction, so a learning-rate schedule can vary it over
    // time without touching any optimizer state.
    void step(Tensor& param, const Tensor& grad, float lr);

private:
    float beta1_;
    float beta2_;
    float eps_;
    int t_ = 0;
    Tensor m_;
    Tensor v_;
    bool initialized_ = false;
};

} // namespace novallm
