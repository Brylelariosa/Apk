#include "UTF8.h"
#include <stdexcept>

namespace novallm {
namespace utf8 {

namespace {
// Returns the number of continuation bytes expected after this lead byte,
// or -1 if the lead byte itself is invalid.
int expectedContinuationBytes(unsigned char lead) {
    if ((lead & 0x80) == 0x00) return 0; // 0xxxxxxx - ASCII
    if ((lead & 0xE0) == 0xC0) return 1; // 110xxxxx
    if ((lead & 0xF0) == 0xE0) return 2; // 1110xxxx
    if ((lead & 0xF8) == 0xF0) return 3; // 11110xxx
    return -1;
}
}

std::vector<uint32_t> decode(const std::string& bytes) {
    std::vector<uint32_t> out;
    out.reserve(bytes.size());

    size_t i = 0;
    while (i < bytes.size()) {
        unsigned char lead = static_cast<unsigned char>(bytes[i]);
        int cont = expectedContinuationBytes(lead);
        if (cont < 0 || i + static_cast<size_t>(cont) >= bytes.size()) {
            throw std::invalid_argument("utf8::decode - malformed UTF-8 sequence");
        }

        uint32_t cp;
        if (cont == 0) {
            cp = lead;
        } else {
            cp = lead & static_cast<unsigned char>(0x3F >> cont);
            for (int k = 1; k <= cont; ++k) {
                unsigned char cb = static_cast<unsigned char>(bytes[i + static_cast<size_t>(k)]);
                if ((cb & 0xC0) != 0x80) {
                    throw std::invalid_argument("utf8::decode - bad continuation byte");
                }
                cp = (cp << 6) | (cb & 0x3F);
            }
        }
        out.push_back(cp);
        i += static_cast<size_t>(cont) + 1;
    }
    return out;
}

size_t codepointCount(const std::string& bytes) {
    return decode(bytes).size();
}

bool isValid(const std::string& bytes) {
    try {
        decode(bytes);
        return true;
    } catch (const std::invalid_argument&) {
        return false;
    }
}

} // namespace utf8
} // namespace novallm
