#include "Block.h"
#include "../math/Matrix.h"
#include <ostream>
#include <istream>

namespace novallm {

TransformerBlock::TransformerBlock(int embedDim, int numHeads, int ffnHiddenDim, unsigned int seed)
    : ln1_(embedDim),
      attn_(embedDim, numHeads, seed),
      ln2_(embedDim),
      ffn_(embedDim, ffnHiddenDim, seed + 10) {}

Tensor TransformerBlock::forward(const Tensor& x) const {
    Tensor normed1 = ln1_.forward(x);
    Tensor attnOut = attn_.forward(normed1);
    Tensor residual1 = matrix::add(x, attnOut);

    Tensor normed2 = ln2_.forward(residual1);
    Tensor ffnOut = ffn_.forward(normed2);
    Tensor residual2 = matrix::add(residual1, ffnOut);

    return residual2;
}

Tensor TransformerBlock::forwardIncremental(const Tensor& x, KVCache& cache) const {
    Tensor normed1 = ln1_.forward(x);
    Tensor attnOut = attn_.forwardIncremental(normed1, cache);
    Tensor residual1 = matrix::add(x, attnOut);

    Tensor normed2 = ln2_.forward(residual1);
    Tensor ffnOut = ffn_.forward(normed2);
    Tensor residual2 = matrix::add(residual1, ffnOut);

    return residual2;
}

TransformerBlock::Grads TransformerBlock::backward(const Tensor& x, const Tensor& gradOutput) const {
    // Recompute the intermediates backward() needs (same recompute-not-
    // cache trade-off as every other backward() in this project).
    Tensor normed1 = ln1_.forward(x);
    Tensor attnOut = attn_.forward(normed1);
    Tensor residual1 = matrix::add(x, attnOut);
    Tensor normed2 = ln2_.forward(residual1);

    Grads g;

    // residual2 = residual1 + ffnOut - gradient splits identically to both.
    g.ffn = ffn_.backward(normed2, gradOutput);
    g.ln2 = ln2_.backward(residual1, g.ffn.gradInput);
    Tensor gradResidual1 = matrix::add(gradOutput, g.ln2.gradInput);

    // residual1 = x + attnOut - gradient splits identically to both.
    g.attn = attn_.backward(normed1, gradResidual1);
    g.ln1 = ln1_.backward(x, g.attn.gradInput);
    g.gradInput = matrix::add(gradResidual1, g.ln1.gradInput);

    return g;
}

void TransformerBlock::save(std::ostream& out) const {
    ln1_.save(out);
    attn_.save(out);
    ln2_.save(out);
    ffn_.save(out);
}

void TransformerBlock::load(std::istream& in) {
    ln1_.load(in);
    attn_.load(in);
    ln2_.load(in);
    ffn_.load(in);
}

} // namespace novallm
