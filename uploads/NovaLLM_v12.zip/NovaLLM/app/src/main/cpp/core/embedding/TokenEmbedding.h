#pragma once
#include <vector>
#include <iosfwd>
#include "../math/Tensor.h"

namespace novallm {

// Learned lookup table: token id -> embedding vector. Weight matrix is
// {vocabSize, embedDim}; row `id` is that token's embedding. Randomly
// initialized here (small Gaussian, GPT-2-style) - training (subsystem 7)
// is what actually shapes these into something meaningful.
class TokenEmbedding {
public:
    TokenEmbedding(int vocabSize, int embedDim, unsigned int seed = 42);

    // Single-token lookup: returns a copy of that row, shape {embedDim}.
    Tensor lookup(int tokenId) const;

    // Whole-sequence lookup: returns {seqLen, embedDim}.
    Tensor lookupSequence(const std::vector<int>& tokenIds) const;

    int vocabSize() const { return vocabSize_; }
    int embedDim() const { return embedDim_; }

    Tensor& weights() { return weights_; }
    const Tensor& weights() const { return weights_; }

    // Scatter-ADDs gradOutput into a fresh {vocabSize, embedDim} gradient
    // tensor: gradWeights[tokenIds[i]] += gradOutput[i] for each position
    // i. Must accumulate, not overwrite - if a token id repeats in the
    // sequence, every occurrence's gradient contributes. No gradient
    // w.r.t. tokenIds themselves; they're discrete indices, not a
    // differentiable input.
    Tensor backward(const std::vector<int>& tokenIds, const Tensor& gradOutput) const;

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    int vocabSize_;
    int embedDim_;
    Tensor weights_; // {vocabSize, embedDim}
};

} // namespace novallm
