#include "FeedForward.h"
#include <cmath>
#include <ostream>
#include <istream>

namespace novallm {

float gelu(float x) {
    // 0.5x(1 + tanh(sqrt(2/pi) * (x + 0.044715x^3)))
    constexpr float kSqrt2OverPi = 0.7978845608028654f;
    float inner = kSqrt2OverPi * (x + 0.044715f * x * x * x);
    return 0.5f * x * (1.0f + std::tanh(inner));
}

float geluGrad(float x) {
    constexpr float kSqrt2OverPi = 0.7978845608028654f;
    constexpr float kCoeff = 0.044715f;
    float x2 = x * x;
    float inner = kSqrt2OverPi * (x + kCoeff * x2 * x);
    float t = std::tanh(inner);
    float dInnerDx = kSqrt2OverPi * (1.0f + 3.0f * kCoeff * x2);
    // d/dx [0.5x(1+tanh(inner))] = 0.5(1+tanh(inner)) + 0.5x(1-tanh(inner)^2)*dInner/dx
    return 0.5f * (1.0f + t) + 0.5f * x * (1.0f - t * t) * dInnerDx;
}

FeedForward::FeedForward(int embedDim, int hiddenDim, unsigned int seed)
    : fc1_(embedDim, hiddenDim, seed, /*useBias=*/true),
      fc2_(hiddenDim, embedDim, seed + 1, /*useBias=*/true) {}

Tensor FeedForward::forward(const Tensor& x) const {
    Tensor hidden = fc1_.forward(x);
    for (size_t i = 0; i < hidden.size(); ++i) {
        hidden.data()[i] = gelu(hidden.data()[i]);
    }
    return fc2_.forward(hidden);
}

FeedForward::Grads FeedForward::backward(const Tensor& x, const Tensor& gradOutput) const {
    Tensor hiddenPreGelu = fc1_.forward(x); // recomputed - see header note
    Tensor hiddenPostGelu = hiddenPreGelu;
    for (size_t i = 0; i < hiddenPostGelu.size(); ++i) {
        hiddenPostGelu.data()[i] = gelu(hiddenPreGelu.data()[i]);
    }

    Linear::Grads fc2Grads = fc2_.backward(hiddenPostGelu, gradOutput);

    Tensor gradHidden = fc2Grads.gradInput; // dL/d(hiddenPostGelu)
    for (size_t i = 0; i < gradHidden.size(); ++i) {
        gradHidden.data()[i] *= geluGrad(hiddenPreGelu.data()[i]); // chain through gelu
    }

    Linear::Grads fc1Grads = fc1_.backward(x, gradHidden);

    Grads g;
    g.gradInput = fc1Grads.gradInput;
    g.gradW1 = fc1Grads.gradWeight;
    g.gradB1 = fc1Grads.gradBias;
    g.gradW2 = fc2Grads.gradWeight;
    g.gradB2 = fc2Grads.gradBias;
    return g;
}

void FeedForward::save(std::ostream& out) const {
    fc1_.save(out);
    fc2_.save(out);
}

void FeedForward::load(std::istream& in) {
    fc1_.load(in);
    fc2_.load(in);
}

} // namespace novallm
