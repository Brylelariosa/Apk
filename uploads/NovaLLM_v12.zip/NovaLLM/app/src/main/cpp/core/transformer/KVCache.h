#pragma once
#include "../math/Tensor.h"

namespace novallm {

// Stores accumulated Key/Value tensors for ONE attention layer across a
// generation sequence, so each new token only needs attention computed
// against a growing cache instead of the whole sequence being reprocessed
// from scratch every step. One KVCache per transformer layer, owned by
// Model - not per attention head (heads are split out of the cached
// {seqLen, embedDim} K/V after retrieval, same as the non-cached path).
class KVCache {
public:
    KVCache(int maxSeqLen, int embedDim);

    // Appends newK/newV (each {newLen, embedDim}, newLen==1 during normal
    // generation, >1 when priming with a whole prompt) to the cache.
    // Returns the position index of the first newly-appended row.
    int append(const Tensor& newK, const Tensor& newV);

    // {currentLen, embedDim} slice of everything cached so far.
    Tensor keys() const;
    Tensor values() const;

    int currentLen() const { return currentLen_; }
    int maxSeqLen() const { return maxSeqLen_; }
    void reset();

private:
    int maxSeqLen_;
    int embedDim_;
    int currentLen_ = 0;
    Tensor kBuffer_; // {maxSeqLen, embedDim}, only [0, currentLen_) valid
    Tensor vBuffer_;
};

} // namespace novallm
