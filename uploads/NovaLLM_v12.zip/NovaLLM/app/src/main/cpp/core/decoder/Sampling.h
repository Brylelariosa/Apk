#pragma once
#include <vector>
#include <random>

namespace novallm {

// Turns a single position's logits (a {vocabSize}-length row - NOT the
// full {seqLen, vocabSize} tensor, just the last position) into one
// sampled next-token id.
//
// Pipeline: temperature scale -> softmax -> top-k filter -> top-p
// (nucleus) filter -> renormalize -> sample. temperature == 0 short-
// circuits to greedy argmax (deterministic, ignores top-k/top-p entirely).
class Sampler {
public:
    struct Params {
        float temperature = 1.0f; // 0 = greedy argmax
        int topK = 0;             // 0 = disabled
        float topP = 1.0f;        // 1.0 = disabled (no nucleus filtering)
    };

    explicit Sampler(unsigned int seed = 42);

    int sample(const std::vector<float>& logitsRow, const Params& params);

private:
    std::mt19937 rng_;
};

} // namespace novallm
