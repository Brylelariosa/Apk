#include "Vocabulary.h"
#include <cstdint>
#include <fstream>
#include <stdexcept>

namespace novallm {

Vocabulary::Vocabulary() {
    idToToken_.reserve(256);
    for (int b = 0; b < 256; ++b) {
        std::string tok(1, static_cast<char>(static_cast<unsigned char>(b)));
        tokenToId_[tok] = b;
        idToToken_.push_back(std::move(tok));
    }
}

int Vocabulary::addToken(const std::string& tokenBytes) {
    auto it = tokenToId_.find(tokenBytes);
    if (it != tokenToId_.end()) return it->second;
    int id = static_cast<int>(idToToken_.size());
    idToToken_.push_back(tokenBytes);
    tokenToId_[tokenBytes] = id;
    return id;
}

int Vocabulary::idFor(const std::string& tokenBytes) const {
    auto it = tokenToId_.find(tokenBytes);
    return it == tokenToId_.end() ? -1 : it->second;
}

const std::string& Vocabulary::tokenFor(int id) const {
    return idToToken_.at(static_cast<size_t>(id));
}

int Vocabulary::addSpecialToken(const std::string& name, const std::string& tokenBytes) {
    int id = addToken(tokenBytes);
    specialTokens_[name] = id;
    return id;
}

int Vocabulary::specialTokenId(const std::string& name) const {
    auto it = specialTokens_.find(name);
    return it == specialTokens_.end() ? -1 : it->second;
}

void Vocabulary::save(const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Vocabulary::save - cannot open " + path);
    const char magic[4] = {'N', 'V', 'C', 'B'};
    out.write(magic, 4);

    uint32_t count = static_cast<uint32_t>(idToToken_.size());
    out.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto& tok : idToToken_) {
        uint32_t len = static_cast<uint32_t>(tok.size());
        out.write(reinterpret_cast<const char*>(&len), sizeof(len));
        out.write(tok.data(), static_cast<std::streamsize>(len));
    }

    uint32_t specialCount = static_cast<uint32_t>(specialTokens_.size());
    out.write(reinterpret_cast<const char*>(&specialCount), sizeof(specialCount));
    for (const auto& kv : specialTokens_) {
        const std::string& name = kv.first;
        uint32_t nameLen = static_cast<uint32_t>(name.size());
        out.write(reinterpret_cast<const char*>(&nameLen), sizeof(nameLen));
        out.write(name.data(), static_cast<std::streamsize>(nameLen));
        int32_t idVal = kv.second;
        out.write(reinterpret_cast<const char*>(&idVal), sizeof(idVal));
    }
}

void Vocabulary::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Vocabulary::load - cannot open " + path);
    char magic[4];
    in.read(magic, 4);
    if (magic[0] != 'N' || magic[1] != 'V' || magic[2] != 'C' || magic[3] != 'B') {
        throw std::runtime_error("Vocabulary::load - bad magic in " + path);
    }

    uint32_t count = 0;
    in.read(reinterpret_cast<char*>(&count), sizeof(count));
    idToToken_.clear();
    tokenToId_.clear();
    idToToken_.reserve(count);
    for (uint32_t i = 0; i < count; ++i) {
        uint32_t len = 0;
        in.read(reinterpret_cast<char*>(&len), sizeof(len));
        std::string tok(len, '\0');
        if (len > 0) in.read(&tok[0], static_cast<std::streamsize>(len));
        tokenToId_[tok] = static_cast<int>(i);
        idToToken_.push_back(std::move(tok));
    }

    uint32_t specialCount = 0;
    in.read(reinterpret_cast<char*>(&specialCount), sizeof(specialCount));
    specialTokens_.clear();
    for (uint32_t i = 0; i < specialCount; ++i) {
        uint32_t nameLen = 0;
        in.read(reinterpret_cast<char*>(&nameLen), sizeof(nameLen));
        std::string name(nameLen, '\0');
        if (nameLen > 0) in.read(&name[0], static_cast<std::streamsize>(nameLen));
        int32_t idVal = 0;
        in.read(reinterpret_cast<char*>(&idVal), sizeof(idVal));
        specialTokens_[name] = idVal;
    }
}

} // namespace novallm
