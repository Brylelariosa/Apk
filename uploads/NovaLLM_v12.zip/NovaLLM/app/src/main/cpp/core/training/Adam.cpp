#include "Adam.h"
#include <cmath>

namespace novallm {

Adam::Adam(float beta1, float beta2, float eps) : beta1_(beta1), beta2_(beta2), eps_(eps) {}

void Adam::step(Tensor& param, const Tensor& grad, float lr) {
    if (!initialized_) {
        m_ = Tensor(param.shape(), 0.0f);
        v_ = Tensor(param.shape(), 0.0f);
        initialized_ = true;
    }
    t_ += 1;
    float biasCorrection1 = 1.0f - std::pow(beta1_, static_cast<float>(t_));
    float biasCorrection2 = 1.0f - std::pow(beta2_, static_cast<float>(t_));

    for (size_t i = 0; i < param.size(); ++i) {
        float g = grad.data()[i];
        m_.data()[i] = beta1_ * m_.data()[i] + (1.0f - beta1_) * g;
        v_.data()[i] = beta2_ * v_.data()[i] + (1.0f - beta2_) * g * g;

        float mHat = m_.data()[i] / biasCorrection1;
        float vHat = v_.data()[i] / biasCorrection2;

        param.data()[i] -= lr * mHat / (std::sqrt(vHat) + eps_);
    }
}

} // namespace novallm
