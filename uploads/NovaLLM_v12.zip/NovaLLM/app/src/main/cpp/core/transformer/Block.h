#pragma once
#include "../math/Tensor.h"
#include "LayerNorm.h"
#include "Attention.h"
#include "FeedForward.h"
#include "KVCache.h"
#include <iosfwd>

namespace novallm {

// Pre-norm transformer block (GPT-2 style, more stable to train than
// post-norm): x -> LN -> Attention -> +x -> LN -> FFN -> +.
//
// Residual connections aren't a separate class - they're just
// matrix::add(x, sublayer(ln(x))), so there's no Residual.cpp; the
// operation lives inline here where it's used.
class TransformerBlock {
public:
    struct Grads {
        Tensor gradInput; // {seqLen, embedDim} - flows to whatever fed this block
        LayerNorm::Grads ln1;
        MultiHeadAttention::Grads attn;
        LayerNorm::Grads ln2;
        FeedForward::Grads ffn;
    };

    TransformerBlock(int embedDim, int numHeads, int ffnHiddenDim, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}. Full recompute.
    Tensor forward(const Tensor& x) const;

    // x: {newLen, embedDim}, just the new token(s). LayerNorm and
    // FeedForward are already position-wise so they need no special
    // handling here - only the attention sublayer touches the cache.
    Tensor forwardIncremental(const Tensor& x, KVCache& cache) const;

    // At each residual junction the gradient simply splits/sums to both
    // branches (d(a+b)/da = d(a+b)/db = 1) - everything else is composing
    // the four sublayers' already-verified backward() methods in reverse.
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    LayerNorm& ln1() { return ln1_; }
    MultiHeadAttention& attn() { return attn_; }
    LayerNorm& ln2() { return ln2_; }
    FeedForward& ffn() { return ffn_; }

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    LayerNorm ln1_;
    MultiHeadAttention attn_;
    LayerNorm ln2_;
    FeedForward ffn_;
};

} // namespace novallm
