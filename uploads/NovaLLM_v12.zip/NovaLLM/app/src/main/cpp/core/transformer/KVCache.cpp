#include "KVCache.h"
#include <algorithm>
#include <stdexcept>

namespace novallm {

KVCache::KVCache(int maxSeqLen, int embedDim)
    : maxSeqLen_(maxSeqLen), embedDim_(embedDim),
      kBuffer_({maxSeqLen, embedDim}), vBuffer_({maxSeqLen, embedDim}) {}

int KVCache::append(const Tensor& newK, const Tensor& newV) {
    int newLen = newK.dim(0);
    if (newK.dim(1) != embedDim_ || newV.dim(0) != newLen || newV.dim(1) != embedDim_) {
        throw std::invalid_argument("KVCache::append - shape mismatch");
    }
    if (currentLen_ + newLen > maxSeqLen_) {
        throw std::out_of_range("KVCache::append - exceeds maxSeqLen");
    }

    int startPos = currentLen_;
    size_t rowFloats = static_cast<size_t>(embedDim_);
    for (int i = 0; i < newLen; ++i) {
        const float* kSrc = newK.data() + static_cast<size_t>(i) * rowFloats;
        const float* vSrc = newV.data() + static_cast<size_t>(i) * rowFloats;
        float* kDst = kBuffer_.data() + static_cast<size_t>(startPos + i) * rowFloats;
        float* vDst = vBuffer_.data() + static_cast<size_t>(startPos + i) * rowFloats;
        std::copy(kSrc, kSrc + rowFloats, kDst);
        std::copy(vSrc, vSrc + rowFloats, vDst);
    }
    currentLen_ += newLen;
    return startPos;
}

Tensor KVCache::keys() const {
    Tensor out({currentLen_, embedDim_});
    size_t n = static_cast<size_t>(currentLen_) * static_cast<size_t>(embedDim_);
    std::copy(kBuffer_.data(), kBuffer_.data() + n, out.data());
    return out;
}

Tensor KVCache::values() const {
    Tensor out({currentLen_, embedDim_});
    size_t n = static_cast<size_t>(currentLen_) * static_cast<size_t>(embedDim_);
    std::copy(vBuffer_.data(), vBuffer_.data() + n, out.data());
    return out;
}

void KVCache::reset() {
    currentLen_ = 0;
}

} // namespace novallm
