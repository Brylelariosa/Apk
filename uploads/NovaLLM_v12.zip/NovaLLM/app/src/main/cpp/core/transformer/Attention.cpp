#include "Attention.h"
#include "../math/Matrix.h"
#include <cmath>
#include <stdexcept>
#include <vector>
#include <ostream>
#include <istream>

namespace novallm {

MultiHeadAttention::MultiHeadAttention(int embedDim, int numHeads, unsigned int seed)
    : embedDim_(embedDim), numHeads_(numHeads), headDim_(embedDim / numHeads),
      wq_(embedDim, embedDim, seed, true),
      wk_(embedDim, embedDim, seed + 1, true),
      wv_(embedDim, embedDim, seed + 2, true),
      wo_(embedDim, embedDim, seed + 3, true) {
    if (embedDim % numHeads != 0) {
        throw std::invalid_argument("MultiHeadAttention: embedDim must be divisible by numHeads");
    }
}

Tensor MultiHeadAttention::forward(const Tensor& x) const {
    int seqLen = x.dim(0);

    Tensor q = wq_.forward(x); // {seqLen, embedDim}
    Tensor k = wk_.forward(x);
    Tensor v = wv_.forward(x);

    Tensor concatOut({seqLen, embedDim_});
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(q, h * headDim_, headDim_); // {seqLen, headDim}
        Tensor kh = matrix::sliceColumns(k, h * headDim_, headDim_);
        Tensor vh = matrix::sliceColumns(v, h * headDim_, headDim_);

        Tensor khT = matrix::transpose(kh);                 // {headDim, seqLen}
        Tensor scores = matrix::matmul(qh, khT);             // {seqLen, seqLen}
        scores = matrix::scale(scores, scaleFactor);

        // Causal mask: query position i must not see key position j > i.
        for (int i = 0; i < seqLen; ++i) {
            for (int j = i + 1; j < seqLen; ++j) {
                scores.at({i, j}) = -1e9f;
            }
        }

        matrix::softmaxRows(scores); // row-wise, in place

        Tensor headOut = matrix::matmul(scores, vh); // {seqLen, headDim}
        matrix::setColumns(concatOut, h * headDim_, headOut);
    }

    return wo_.forward(concatOut);
}

Tensor MultiHeadAttention::forwardIncremental(const Tensor& x, KVCache& cache) const {
    int newLen = x.dim(0);

    Tensor qNew = wq_.forward(x); // {newLen, embedDim} - only new positions need new Q
    Tensor kNew = wk_.forward(x); // {newLen, embedDim}
    Tensor vNew = wv_.forward(x);

    int startPos = cache.append(kNew, vNew); // record this step's K/V, get its global offset
    Tensor kAll = cache.keys();               // {totalLen, embedDim} - everything so far
    Tensor vAll = cache.values();
    int totalLen = kAll.dim(0);

    Tensor concatOut({newLen, embedDim_});
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(qNew, h * headDim_, headDim_); // {newLen, headDim}
        Tensor kh = matrix::sliceColumns(kAll, h * headDim_, headDim_); // {totalLen, headDim}
        Tensor vh = matrix::sliceColumns(vAll, h * headDim_, headDim_); // {totalLen, headDim}

        Tensor khT = matrix::transpose(kh);      // {headDim, totalLen}
        Tensor scores = matrix::matmul(qh, khT); // {newLen, totalLen}
        scores = matrix::scale(scores, scaleFactor);

        // Causal mask against GLOBAL position, not local row index: new
        // row i actually sits at position startPos+i in the full sequence
        // and may only attend to cached positions up to and including it.
        for (int i = 0; i < newLen; ++i) {
            int globalPos = startPos + i;
            for (int j = globalPos + 1; j < totalLen; ++j) {
                scores.at({i, j}) = -1e9f;
            }
        }

        matrix::softmaxRows(scores);

        Tensor headOut = matrix::matmul(scores, vh); // {newLen, headDim}
        matrix::setColumns(concatOut, h * headDim_, headOut);
    }

    return wo_.forward(concatOut);
}

MultiHeadAttention::Grads MultiHeadAttention::backward(const Tensor& x, const Tensor& gradOutput) const {
    int seqLen = x.dim(0);

    // Recompute forward intermediates (same trade-off as
    // FeedForward::backward: simpler interface than caching from
    // forward(), at the cost of redoing this work once per backward call).
    Tensor q = wq_.forward(x);
    Tensor k = wk_.forward(x);
    Tensor v = wv_.forward(x);
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    Tensor concatOut({seqLen, embedDim_});
    std::vector<Tensor> weightsPerHead(static_cast<size_t>(numHeads_));
    std::vector<Tensor> qhPerHead(static_cast<size_t>(numHeads_));
    std::vector<Tensor> khPerHead(static_cast<size_t>(numHeads_));
    std::vector<Tensor> vhPerHead(static_cast<size_t>(numHeads_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(q, h * headDim_, headDim_);
        Tensor kh = matrix::sliceColumns(k, h * headDim_, headDim_);
        Tensor vh = matrix::sliceColumns(v, h * headDim_, headDim_);

        Tensor khT = matrix::transpose(kh);
        Tensor scores = matrix::matmul(qh, khT);
        scores = matrix::scale(scores, scaleFactor);
        for (int i = 0; i < seqLen; ++i) {
            for (int j = i + 1; j < seqLen; ++j) scores.at({i, j}) = -1e9f;
        }
        matrix::softmaxRows(scores); // `scores` now holds the attention weights

        Tensor headOut = matrix::matmul(scores, vh);
        matrix::setColumns(concatOut, h * headDim_, headOut);

        weightsPerHead[static_cast<size_t>(h)] = scores;
        qhPerHead[static_cast<size_t>(h)] = qh;
        khPerHead[static_cast<size_t>(h)] = kh;
        vhPerHead[static_cast<size_t>(h)] = vh;
    }

    Linear::Grads woGrads = wo_.backward(concatOut, gradOutput);
    Tensor gradConcatOut = woGrads.gradInput; // {seqLen, embedDim}

    Tensor gradQ({seqLen, embedDim_}, 0.0f);
    Tensor gradK({seqLen, embedDim_}, 0.0f);
    Tensor gradV({seqLen, embedDim_}, 0.0f);

    for (int h = 0; h < numHeads_; ++h) {
        Tensor gradHeadOut = matrix::sliceColumns(gradConcatOut, h * headDim_, headDim_);

        const Tensor& weights = weightsPerHead[static_cast<size_t>(h)];
        const Tensor& qh = qhPerHead[static_cast<size_t>(h)];
        const Tensor& kh = khPerHead[static_cast<size_t>(h)];
        const Tensor& vh = vhPerHead[static_cast<size_t>(h)];

        // headOut = weights @ vh
        Tensor gradWeights = matrix::matmul(gradHeadOut, matrix::transpose(vh)); // {seqLen,seqLen}
        Tensor gradVh = matrix::matmul(matrix::transpose(weights), gradHeadOut); // {seqLen,headDim}

        // Standard softmax backward, row-wise:
        //   gradScores[i] = weights[i] * (gradWeights[i] - dot(gradWeights[i], weights[i]))
        // For causally-masked positions weights[i][j]~=0, so gradScores
        // there is automatically ~0 too - the mask needs no separate
        // handling in the backward direction.
        Tensor gradScores({seqLen, seqLen});
        for (int i = 0; i < seqLen; ++i) {
            float dot = 0.0f;
            for (int j = 0; j < seqLen; ++j) dot += gradWeights.at({i, j}) * weights.at({i, j});
            for (int j = 0; j < seqLen; ++j) {
                gradScores.at({i, j}) = weights.at({i, j}) * (gradWeights.at({i, j}) - dot);
            }
        }

        // scores = (qh @ kh^T) * scaleFactor
        Tensor gradM = matrix::scale(gradScores, scaleFactor);
        Tensor gradQh = matrix::matmul(gradM, kh);                       // {seqLen,headDim}
        Tensor gradKh = matrix::matmul(matrix::transpose(gradM), qh);    // {seqLen,headDim}

        // Each head owns a disjoint column range, so a plain set (not an
        // accumulate) is correct here.
        matrix::setColumns(gradQ, h * headDim_, gradQh);
        matrix::setColumns(gradK, h * headDim_, gradKh);
        matrix::setColumns(gradV, h * headDim_, gradVh);
    }

    Linear::Grads wqGrads = wq_.backward(x, gradQ);
    Linear::Grads wkGrads = wk_.backward(x, gradK);
    Linear::Grads wvGrads = wv_.backward(x, gradV);

    Grads g;
    // x feeds all three projections independently, so its gradients sum.
    g.gradInput = matrix::add(matrix::add(wqGrads.gradInput, wkGrads.gradInput), wvGrads.gradInput);
    g.gradWq = wqGrads.gradWeight; g.gradBq = wqGrads.gradBias;
    g.gradWk = wkGrads.gradWeight; g.gradBk = wkGrads.gradBias;
    g.gradWv = wvGrads.gradWeight; g.gradBv = wvGrads.gradBias;
    g.gradWo = woGrads.gradWeight; g.gradBo = woGrads.gradBias;
    return g;
}

void MultiHeadAttention::save(std::ostream& out) const {
    wq_.save(out);
    wk_.save(out);
    wv_.save(out);
    wo_.save(out);
}

void MultiHeadAttention::load(std::istream& in) {
    wq_.load(in);
    wk_.load(in);
    wv_.load(in);
    wo_.load(in);
    embedDim_ = wq_.outDim();
}

} // namespace novallm
