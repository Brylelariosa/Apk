#include "Tokenizer.h"

namespace novallm {

void Tokenizer::train(const std::vector<std::string>& corpus, int numMerges) {
    bpe_.train(corpus, vocab_, numMerges);
}

std::vector<int> Tokenizer::encode(const std::string& text) const {
    return bpe_.encode(text);
}

std::string Tokenizer::decode(const std::vector<int>& ids) const {
    std::string out;
    for (int id : ids) out += vocab_.tokenFor(id);
    return out;
}

void Tokenizer::addSpecialToken(const std::string& name, const std::string& tokenBytes) {
    vocab_.addSpecialToken(name, tokenBytes);
}

int Tokenizer::specialTokenId(const std::string& name) const {
    return vocab_.specialTokenId(name);
}

void Tokenizer::save(const std::string& pathPrefix) const {
    vocab_.save(pathPrefix + ".vocab");
    bpe_.save(pathPrefix + ".merges");
}

void Tokenizer::load(const std::string& pathPrefix) {
    vocab_.load(pathPrefix + ".vocab");
    bpe_.load(pathPrefix + ".merges");
}

} // namespace novallm
