#pragma once
#include "../math/Tensor.h"

namespace novallm {

// Fixed (non-learned) sinusoidal positional encoding, as in "Attention Is
// All You Need". Precomputes a {maxSeqLen, embedDim} table once; add a
// slice of it to token embeddings to inject position information.
//
// RoPE is the planned upgrade from this - it rotates query/key vectors
// inside attention rather than adding a fixed vector at the embedding
// stage, so it belongs in core/transformer once attention exists, not
// here. Deferred on purpose, not forgotten.
class PositionalEncoding {
public:
    PositionalEncoding(int maxSeqLen, int embedDim);

    // Returns the {seqLen, embedDim} slice of the precomputed table for
    // positions [0, seqLen).
    Tensor encode(int seqLen) const;

    // Returns the {len, embedDim} slice for positions [startPos, startPos+len).
    // Needed for incremental (KV-cached) generation: new tokens sit at
    // their TRUE position in the sequence, not position 0 - using encode()
    // there would silently re-anchor every generated token back to the
    // start, which is exactly the kind of bug that wouldn't crash, just
    // quietly produce a broken model.
    Tensor encodeRange(int startPos, int len) const;

    // Convenience: embeddings + positional encoding, both {seqLen, embedDim}.
    Tensor applyTo(const Tensor& embeddings) const;

    int maxSeqLen() const { return maxSeqLen_; }
    int embedDim() const { return embedDim_; }

private:
    int maxSeqLen_;
    int embedDim_;
    Tensor table_; // {maxSeqLen, embedDim}, precomputed at construction
};

} // namespace novallm
