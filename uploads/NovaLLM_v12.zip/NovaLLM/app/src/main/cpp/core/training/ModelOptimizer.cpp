#include "ModelOptimizer.h"

namespace novallm {

ModelOptimizer::ModelOptimizer(int numLayers) : blockOpts_(static_cast<size_t>(numLayers)) {}

void ModelOptimizer::step(Model& model, const Model::Grads& grads, float lr) {
    embeddingOpt_.step(model.tokenEmbedding().weights(), grads.gradTokenEmbedding, lr);

    for (int i = 0; i < model.numBlocks(); ++i) {
        auto& block = model.block(i);
        const auto& bg = grads.blockGrads[static_cast<size_t>(i)];
        auto& opt = blockOpts_[static_cast<size_t>(i)];

        opt.ln1.gamma.step(block.ln1().gamma(), bg.ln1.gradGamma, lr);
        opt.ln1.beta.step(block.ln1().beta(), bg.ln1.gradBeta, lr);

        opt.attn.wq.weight.step(block.attn().wq().weight(), bg.attn.gradWq, lr);
        opt.attn.wq.bias.step(block.attn().wq().bias(), bg.attn.gradBq, lr);
        opt.attn.wk.weight.step(block.attn().wk().weight(), bg.attn.gradWk, lr);
        opt.attn.wk.bias.step(block.attn().wk().bias(), bg.attn.gradBk, lr);
        opt.attn.wv.weight.step(block.attn().wv().weight(), bg.attn.gradWv, lr);
        opt.attn.wv.bias.step(block.attn().wv().bias(), bg.attn.gradBv, lr);
        opt.attn.wo.weight.step(block.attn().wo().weight(), bg.attn.gradWo, lr);
        opt.attn.wo.bias.step(block.attn().wo().bias(), bg.attn.gradBo, lr);

        opt.ln2.gamma.step(block.ln2().gamma(), bg.ln2.gradGamma, lr);
        opt.ln2.beta.step(block.ln2().beta(), bg.ln2.gradBeta, lr);

        opt.ffn.fc1.weight.step(block.ffn().fc1().weight(), bg.ffn.gradW1, lr);
        opt.ffn.fc1.bias.step(block.ffn().fc1().bias(), bg.ffn.gradB1, lr);
        opt.ffn.fc2.weight.step(block.ffn().fc2().weight(), bg.ffn.gradW2, lr);
        opt.ffn.fc2.bias.step(block.ffn().fc2().bias(), bg.ffn.gradB2, lr);
    }

    finalNormOpt_.gamma.step(model.finalNorm().gamma(), grads.finalNormGrads.gradGamma, lr);
    finalNormOpt_.beta.step(model.finalNorm().beta(), grads.finalNormGrads.gradBeta, lr);

    lmHeadOpt_.weight.step(model.lmHead().weight(), grads.lmHeadGrads.gradWeight, lr);
    lmHeadOpt_.bias.step(model.lmHead().bias(), grads.lmHeadGrads.gradBias, lr);
}

} // namespace novallm
