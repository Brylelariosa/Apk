#include "Sampling.h"
#include "../math/Tensor.h"
#include "../math/Matrix.h"
#include <algorithm>
#include <numeric>

namespace novallm {

Sampler::Sampler(unsigned int seed) : rng_(seed) {}

int Sampler::sample(const std::vector<float>& logitsRow, const Params& params) {
    int n = static_cast<int>(logitsRow.size());

    if (params.temperature <= 0.0f) {
        // Greedy argmax - deterministic, ignores top-k/top-p entirely.
        int best = 0;
        for (int i = 1; i < n; ++i) {
            if (logitsRow[i] > logitsRow[best]) best = i;
        }
        return best;
    }

    // Temperature scale, then softmax - reuse the same tested primitive
    // attention uses, by wrapping this one row as a {1,n} tensor.
    Tensor probsTensor({1, n});
    for (int i = 0; i < n; ++i) {
        probsTensor.data()[i] = logitsRow[i] / params.temperature;
    }
    matrix::softmaxRows(probsTensor);
    std::vector<float> p(probsTensor.data(), probsTensor.data() + n);

    // Top-k: keep only the k highest-probability tokens.
    if (params.topK > 0 && params.topK < n) {
        std::vector<int> idx(static_cast<size_t>(n));
        std::iota(idx.begin(), idx.end(), 0);
        std::partial_sort(idx.begin(), idx.begin() + params.topK, idx.end(),
                           [&](int a, int b) { return p[static_cast<size_t>(a)] > p[static_cast<size_t>(b)]; });
        float threshold = p[static_cast<size_t>(idx[static_cast<size_t>(params.topK) - 1])];
        for (int i = 0; i < n; ++i) {
            if (p[static_cast<size_t>(i)] < threshold) p[static_cast<size_t>(i)] = 0.0f;
        }
    }

    // Top-p / nucleus: keep the smallest prefix (by descending probability)
    // whose cumulative mass exceeds topP. The single most likely token
    // always survives regardless of topP, so this never zeroes everything.
    if (params.topP < 1.0f && n > 0) {
        std::vector<int> idx(static_cast<size_t>(n));
        std::iota(idx.begin(), idx.end(), 0);
        std::sort(idx.begin(), idx.end(),
                  [&](int a, int b) { return p[static_cast<size_t>(a)] > p[static_cast<size_t>(b)]; });
        float cumulative = p[static_cast<size_t>(idx[0])];
        for (int rank = 1; rank < n; ++rank) {
            size_t id = static_cast<size_t>(idx[static_cast<size_t>(rank)]);
            if (cumulative >= params.topP) {
                p[id] = 0.0f;
            } else {
                cumulative += p[id];
            }
        }
    }

    float sum = std::accumulate(p.begin(), p.end(), 0.0f);
    if (sum <= 0.0f) {
        // Defensive fallback - shouldn't be reachable given the top-p
        // guarantee above and top-k always keeping >=1 entry.
        int best = 0;
        for (int i = 1; i < n; ++i) if (logitsRow[i] > logitsRow[best]) best = i;
        return best;
    }
    for (float& v : p) v /= sum;

    std::discrete_distribution<int> dist(p.begin(), p.end());
    return dist(rng_);
}

} // namespace novallm
