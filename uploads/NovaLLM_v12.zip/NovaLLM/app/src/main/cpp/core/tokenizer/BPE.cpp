#include "BPE.h"
#include <fstream>
#include <stdexcept>

namespace novallm {

namespace {
std::vector<int> textToByteIds(const std::string& text) {
    std::vector<int> ids;
    ids.reserve(text.size());
    for (unsigned char c : text) ids.push_back(static_cast<int>(c));
    return ids;
}
}

void BPE::train(const std::vector<std::string>& corpus, Vocabulary& vocab, int numMerges) {
    std::vector<std::vector<int>> sequences;
    sequences.reserve(corpus.size());
    for (const auto& doc : corpus) {
        sequences.push_back(textToByteIds(doc));
    }

    merges_.clear();
    mergeLookup_.clear();

    for (int m = 0; m < numMerges; ++m) {
        // Count every adjacent pair's frequency across the whole corpus.
        std::unordered_map<int64_t, long long> pairCounts;
        for (const auto& seq : sequences) {
            for (size_t i = 0; i + 1 < seq.size(); ++i) {
                pairCounts[packPair(seq[i], seq[i + 1])]++;
            }
        }
        if (pairCounts.empty()) break; // corpus is fully merged, nothing left to do

        int64_t bestPair = 0;
        long long bestCount = 0;
        for (const auto& kv : pairCounts) {
            if (kv.second > bestCount) {
                bestCount = kv.second;
                bestPair = kv.first;
            }
        }
        if (bestCount < 2) break; // no pair repeats - a merge here wouldn't generalize

        int leftId = static_cast<int>(static_cast<uint32_t>(bestPair >> 32));
        int rightId = static_cast<int>(static_cast<uint32_t>(bestPair & 0xFFFFFFFFLL));

        std::string mergedBytes = vocab.tokenFor(leftId) + vocab.tokenFor(rightId);
        int newId = vocab.addToken(mergedBytes);

        merges_.push_back({leftId, rightId, newId});
        mergeLookup_[bestPair] = static_cast<int>(merges_.size()) - 1;

        // Apply this merge everywhere it occurs, left to right, in every sequence.
        for (auto& seq : sequences) {
            std::vector<int> next;
            next.reserve(seq.size());
            for (size_t i = 0; i < seq.size(); ++i) {
                if (i + 1 < seq.size() && seq[i] == leftId && seq[i + 1] == rightId) {
                    next.push_back(newId);
                    ++i; // consume both tokens of the pair
                } else {
                    next.push_back(seq[i]);
                }
            }
            seq.swap(next);
        }
    }
}

std::vector<int> BPE::encode(const std::string& text) const {
    std::vector<int> ids = textToByteIds(text);
    if (merges_.empty()) return ids;

    // Repeatedly find the lowest-rank (highest-priority) applicable pair
    // and merge it - same strategy as GPT-2's byte-level BPE encoder.
    while (ids.size() > 1) {
        int bestRank = -1;
        size_t bestPos = 0;
        for (size_t i = 0; i + 1 < ids.size(); ++i) {
            auto it = mergeLookup_.find(packPair(ids[i], ids[i + 1]));
            if (it != mergeLookup_.end() && (bestRank == -1 || it->second < bestRank)) {
                bestRank = it->second;
                bestPos = i;
            }
        }
        if (bestRank == -1) break; // no more applicable merges

        int newId = merges_[static_cast<size_t>(bestRank)].resultId;
        std::vector<int> next;
        next.reserve(ids.size() - 1);
        for (size_t i = 0; i < ids.size(); ++i) {
            if (i == bestPos) {
                next.push_back(newId);
                ++i; // skip the consumed right-hand token
            } else {
                next.push_back(ids[i]);
            }
        }
        ids.swap(next);
    }
    return ids;
}

void BPE::save(const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("BPE::save - cannot open " + path);
    const char magic[4] = {'N', 'B', 'P', 'E'};
    out.write(magic, 4);
    uint32_t count = static_cast<uint32_t>(merges_.size());
    out.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto& rule : merges_) {
        int32_t l = rule.leftId, r = rule.rightId, res = rule.resultId;
        out.write(reinterpret_cast<const char*>(&l), sizeof(l));
        out.write(reinterpret_cast<const char*>(&r), sizeof(r));
        out.write(reinterpret_cast<const char*>(&res), sizeof(res));
    }
}

void BPE::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("BPE::load - cannot open " + path);
    char magic[4];
    in.read(magic, 4);
    if (magic[0] != 'N' || magic[1] != 'B' || magic[2] != 'P' || magic[3] != 'E') {
        throw std::runtime_error("BPE::load - bad magic in " + path);
    }
    uint32_t count = 0;
    in.read(reinterpret_cast<char*>(&count), sizeof(count));
    merges_.clear();
    merges_.reserve(count);
    mergeLookup_.clear();
    for (uint32_t i = 0; i < count; ++i) {
        int32_t l = 0, r = 0, res = 0;
        in.read(reinterpret_cast<char*>(&l), sizeof(l));
        in.read(reinterpret_cast<char*>(&r), sizeof(r));
        in.read(reinterpret_cast<char*>(&res), sizeof(res));
        merges_.push_back({l, r, res});
        mergeLookup_[packPair(l, r)] = static_cast<int>(i);
    }
}

} // namespace novallm
