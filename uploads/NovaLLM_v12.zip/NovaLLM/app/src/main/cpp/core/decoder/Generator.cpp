#include "Generator.h"

namespace novallm {

Generator::Generator(Model& model, Tokenizer& tokenizer, unsigned int samplerSeed)
    : model_(model), tokenizer_(tokenizer), sampler_(samplerSeed) {}

std::string Generator::generate(const std::string& prompt, const GenerationParams& params) {
    std::vector<int> promptIds = tokenizer_.encode(prompt);
    int eosId = tokenizer_.specialTokenId("eos");
    int totalLen = static_cast<int>(promptIds.size());

    model_.resetCache();
    Tensor logits = model_.forwardIncremental(promptIds); // prime the cache with the whole prompt

    std::vector<int> generatedIds;

    for (int step = 0; step < params.maxNewTokens; ++step) {
        if (totalLen >= model_.config().maxSeqLen) break;

        int lastPos = logits.dim(0) - 1;
        int vocabSize = logits.dim(1);
        std::vector<float> lastLogits(static_cast<size_t>(vocabSize));
        for (int v = 0; v < vocabSize; ++v) {
            lastLogits[static_cast<size_t>(v)] = logits.at({lastPos, v});
        }

        int nextId = sampler_.sample(lastLogits, params.sampling);
        generatedIds.push_back(nextId);
        totalLen++;

        if (eosId != -1 && nextId == eosId) break;
        if (step + 1 >= params.maxNewTokens || totalLen >= model_.config().maxSeqLen) break;

        std::vector<int> singleStep = {nextId};
        logits = model_.forwardIncremental(singleStep); // {1, vocabSize} - cache does the rest
    }

    return tokenizer_.decode(generatedIds);
}

} // namespace novallm
