#include "GradientCheck.h"
#include <cmath>
#include <algorithm>

namespace novallm {
namespace gradcheck {

float maxRelativeError(Tensor& param, const Tensor& analyticalGrad,
                        const std::function<float()>& computeLoss,
                        float epsilon, int maxElementsToCheck) {
    float maxError = 0.0f;
    int total = static_cast<int>(param.size());
    int n = std::min(total, maxElementsToCheck);
    // Sample evenly across the tensor rather than just the first N
    // elements, so a bug isolated to one region can't hide from a check
    // that only ever samples the start.
    int stride = std::max(1, total / std::max(n, 1));

    for (int idx = 0; idx < n; ++idx) {
        int i = idx * stride;
        if (i >= total) break;

        float original = param.data()[i];

        param.data()[i] = original + epsilon;
        float lossPlus = computeLoss();

        param.data()[i] = original - epsilon;
        float lossMinus = computeLoss();

        param.data()[i] = original; // restore before the caller sees it again

        float numericalGrad = (lossPlus - lossMinus) / (2.0f * epsilon);
        float analytical = analyticalGrad.data()[i];

        // Floor the denominator rather than branching on "near zero": when
        // the true gradient is exactly 0, the numerical estimate still
        // lands on tiny floating-point noise (not exact 0), and a too-tight
        // floor turns that noise into a misleading ~1.0 relative error.
        // 1e-3 comfortably exceeds the observed float32 finite-difference
        // noise floor (~1e-6 for epsilon=1e-3) while staying far below the
        // O(1) magnitude a genuinely wrong gradient would differ by.
        float denom = std::max(std::max(std::fabs(numericalGrad), std::fabs(analytical)), 1e-3f);
        float relError = std::fabs(numericalGrad - analytical) / denom;
        maxError = std::max(maxError, relError);
    }
    return maxError;
}

} // namespace gradcheck
} // namespace novallm
