#include "Loss.h"
#include "../math/Matrix.h"
#include <cmath>
#include <algorithm>

namespace novallm {

float CrossEntropyLoss::forwardBackward(const Tensor& logits, const std::vector<int>& targets,
                                          Tensor& gradLogits) {
    int seqLen = logits.dim(0);
    int vocabSize = logits.dim(1);
    gradLogits = Tensor({seqLen, vocabSize});

    float totalLoss = 0.0f;
    for (int i = 0; i < seqLen; ++i) {
        Tensor row({1, vocabSize});
        for (int v = 0; v < vocabSize; ++v) row.data()[v] = logits.at({i, v});
        matrix::softmaxRows(row); // row now holds probabilities

        int target = targets[static_cast<size_t>(i)];
        float p = row.data()[target];
        totalLoss += -std::log(std::max(p, 1e-9f)); // avoid log(0) on a saturated softmax

        for (int v = 0; v < vocabSize; ++v) {
            float grad = row.data()[v] - (v == target ? 1.0f : 0.0f);
            gradLogits.at({i, v}) = grad / static_cast<float>(seqLen); // average over the sequence
        }
    }
    return totalLoss / static_cast<float>(seqLen);
}

} // namespace novallm
