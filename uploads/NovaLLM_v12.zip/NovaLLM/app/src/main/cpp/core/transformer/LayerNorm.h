#pragma once
#include "../math/Tensor.h"
#include <iosfwd>

namespace novallm {

// Normalizes each row (each token position) to zero mean / unit variance
// across the embedding dimension, then applies a learned per-dimension
// scale (gamma, init 1) and shift (beta, init 0).
class LayerNorm {
public:
    struct Grads {
        Tensor gradInput; // {seqLen, dim}
        Tensor gradGamma; // {dim}
        Tensor gradBeta;  // {dim}
    };

    explicit LayerNorm(int dim, float eps = 1e-5f);

    // x: {seqLen, dim} -> {seqLen, dim}
    Tensor forward(const Tensor& x) const;

    // x is the SAME input passed to forward(). Standard LayerNorm backward:
    // with xhat = (x-mean)/sigma and dxhat = gradOutput * gamma,
    //   gradInput = (dxhat - mean(dxhat) - xhat * mean(dxhat*xhat)) / sigma
    // (means taken across the feature dimension, per row).
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    int dim() const { return dim_; }
    Tensor& gamma() { return gamma_; }
    Tensor& beta() { return beta_; }

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    int dim_;
    float eps_;
    Tensor gamma_; // {dim}, initialized to 1
    Tensor beta_;  // {dim}, initialized to 0
};

} // namespace novallm
