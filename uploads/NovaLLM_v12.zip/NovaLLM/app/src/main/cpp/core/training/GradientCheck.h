#pragma once
#include <functional>
#include "../math/Tensor.h"

namespace novallm {
namespace gradcheck {

// Numerically estimates d(loss)/d(param) via central differences and
// compares it against an analytically-computed gradient, returning the
// max relative error found. This is THE standard way to verify a
// hand-written backward pass is correct: every backward() in this
// project gets checked against this before being trusted, the same way
// every earlier subsystem got checked against known values or an
// independent reference path.
//
// `computeLoss` must run the full forward computation using whatever is
// CURRENTLY in `param` and return a single scalar loss - this function
// perturbs individual elements of `param` in place and calls it
// repeatedly, restoring the original value before returning.
float maxRelativeError(Tensor& param, const Tensor& analyticalGrad,
                        const std::function<float()>& computeLoss,
                        float epsilon = 1e-3f, int maxElementsToCheck = 20);

} // namespace gradcheck
} // namespace novallm
