#pragma once
#include <vector>
#include "Adam.h"
#include "../decoder/Model.h"

namespace novallm {

// One Adam instance per learnable tensor in a Model, mirroring
// Model::Grads's exact nesting (LinearOptState/LayerNormOptState/
// AttentionOptState/FeedForwardOptState/BlockOptState) so the traversal
// in step() can be audited side-by-side against Model::backward()'s
// construction of Grads - if either one is missing a parameter, the
// mismatch is easy to spot by comparison, not just by a symptom later.
struct LinearOptState {
    Adam weight, bias;
};
struct LayerNormOptState {
    Adam gamma, beta;
};
struct AttentionOptState {
    LinearOptState wq, wk, wv, wo;
};
struct FeedForwardOptState {
    LinearOptState fc1, fc2;
};
struct BlockOptState {
    LayerNormOptState ln1;
    AttentionOptState attn;
    LayerNormOptState ln2;
    FeedForwardOptState ffn;
};

class ModelOptimizer {
public:
    explicit ModelOptimizer(int numLayers);

    // Applies one Adam update to every parameter in `model` using the
    // gradients in `grads` (from a matching Model::backward() call) and
    // the given learning rate.
    void step(Model& model, const Model::Grads& grads, float lr);

private:
    Adam embeddingOpt_;
    std::vector<BlockOptState> blockOpts_;
    LayerNormOptState finalNormOpt_;
    LinearOptState lmHeadOpt_;
};

} // namespace novallm
