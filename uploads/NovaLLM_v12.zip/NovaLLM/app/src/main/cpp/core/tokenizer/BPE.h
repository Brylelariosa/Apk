#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include "Vocabulary.h"

namespace novallm {

// Byte-level BPE: learns merge rules from a corpus, then applies them
// (greedily, lowest-rank pair first - same strategy GPT-2's encoder uses)
// to turn new text into a sequence of token ids.
//
// Deliberately no pretokenization step (no regex word-splitting before
// BPE): the whole byte stream is one sequence. Simpler and still fully
// correct/reversible, at the cost of some compression quality vs a
// word-boundary-aware version. That's a reasonable place to revisit later,
// not a correctness gap now.
class BPE {
public:
    // Learns up to `numMerges` merge rules from the corpus and registers
    // each resulting merged token in `vocab` (which must already contain
    // the 256 base byte tokens - see Vocabulary's default constructor).
    // May stop earlier than `numMerges` if the corpus runs out of
    // repeating pairs to merge.
    void train(const std::vector<std::string>& corpus, Vocabulary& vocab, int numMerges);

    // Applies learned merges to raw text, returns token ids. Byte
    // sequences with no matching merge just stay as their raw byte ids -
    // there is no "unknown token" case.
    std::vector<int> encode(const std::string& text) const;

    void save(const std::string& path) const;
    void load(const std::string& path);

    size_t mergeCount() const { return merges_.size(); }

private:
    struct MergeRule {
        int leftId;
        int rightId;
        int resultId;
    };
    std::vector<MergeRule> merges_;                  // in learned order = priority order
    std::unordered_map<int64_t, int> mergeLookup_;    // packed(leftId,rightId) -> rank

    static int64_t packPair(int a, int b) {
        return (static_cast<int64_t>(static_cast<uint32_t>(a)) << 32) |
               static_cast<uint32_t>(b);
    }
};

} // namespace novallm
