#pragma once
#include <vector>
#include "../math/Tensor.h"

namespace novallm {

// Cross-entropy loss combined with softmax, for next-token prediction.
// logits: {seqLen, vocabSize}. targets[i] is the correct next-token id for
// position i. Combining softmax+CE analytically gives the famously simple
// gradient dLoss/dLogits = softmax(logits) - one_hot(target), which is
// what backward() computes directly rather than differentiating through
// a separate softmax step.
class CrossEntropyLoss {
public:
    // Computes the average loss over all positions AND fills gradLogits
    // ({seqLen, vocabSize}) with dLoss/dLogits, ready to backprop into
    // whatever produced the logits (the LM head, eventually).
    static float forwardBackward(const Tensor& logits, const std::vector<int>& targets,
                                   Tensor& gradLogits);
};

} // namespace novallm
