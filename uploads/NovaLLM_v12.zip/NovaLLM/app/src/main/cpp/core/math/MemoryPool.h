#pragma once
#include <cstddef>
#include <cstdint>

namespace novallm {

// Simple bump ("arena") allocator. Once we're generating tokens, the
// transformer forward pass allocates the same-shaped temporary buffers
// (attention scores, FFN activations, etc.) over and over - one pool that
// gets reset() every forward pass avoids malloc/free churn for all of that.
//
// Not thread-safe by design - each inference thread should own its own pool.
class MemoryPool {
public:
    explicit MemoryPool(size_t capacityBytes);
    ~MemoryPool();

    MemoryPool(const MemoryPool&) = delete;
    MemoryPool& operator=(const MemoryPool&) = delete;

    // Returns `bytes` of 16-byte aligned memory (safe for future NEON
    // float32x4_t use). Throws std::bad_alloc if the pool is exhausted.
    void* alloc(size_t bytes);

    float* allocFloats(size_t count) {
        return reinterpret_cast<float*>(alloc(count * sizeof(float)));
    }

    // Rewinds the pool so all previous allocations are invalidated and the
    // space is reused. Call once per forward pass / generated token.
    void reset();

    size_t capacity() const { return capacity_; }
    size_t used() const { return offset_; }

private:
    size_t capacity_;
    size_t offset_ = 0;
    unsigned char* rawBuffer_ = nullptr; // what malloc actually gave us
    unsigned char* buffer_ = nullptr;    // 16-byte aligned start; alloc() hands out from here
};

} // namespace novallm
