#pragma once
#include "../math/Tensor.h"
#include <iosfwd>

namespace novallm {

// Standard learned linear layer: y = x @ W + b.
// x is {seqLen, inDim}, W is {inDim, outDim}, b is {outDim}, y is {seqLen, outDim}.
// Shared building block for attention's Q/K/V/output projections and for
// the feed-forward network's two layers.
class Linear {
public:
    struct Grads {
        Tensor gradInput;  // {seqLen, inDim}  - flows back to whatever fed this layer
        Tensor gradWeight; // {inDim, outDim}  - accumulated into by the optimizer
        Tensor gradBias;   // {outDim}
    };

    Linear(int inDim, int outDim, unsigned int seed = 42, bool useBias = true);

    Tensor forward(const Tensor& x) const;

    // x is the SAME input that was passed to forward() (needed for the
    // weight/bias gradients). gradOutput is dLoss/dOutput, same shape as
    // forward()'s return value.
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    int inDim() const { return inDim_; }
    int outDim() const { return outDim_; }
    Tensor& weight() { return weight_; }
    const Tensor& weight() const { return weight_; }
    Tensor& bias() { return bias_; }
    const Tensor& bias() const { return bias_; }

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    int inDim_;
    int outDim_;
    bool useBias_;
    Tensor weight_; // {inDim, outDim}
    Tensor bias_;   // {outDim}
};

} // namespace novallm
