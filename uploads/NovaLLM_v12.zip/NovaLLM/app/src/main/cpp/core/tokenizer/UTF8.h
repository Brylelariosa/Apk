#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace novallm {
namespace utf8 {

// Decodes a UTF-8 byte string into Unicode codepoints. Throws
// std::invalid_argument on malformed input rather than silently producing
// garbage - a tokenizer should fail loudly on bad input, not quietly
// corrupt its vocabulary.
//
// Note: the BPE tokenizer itself operates on raw bytes and does NOT depend
// on this - byte-level BPE never needs to know where codepoint boundaries
// are to stay correct. This exists for validation and for codepoint-vs-byte
// stats (useful later for corpus inspection, and if word-boundary-aware
// pretokenization gets added on top of the current whole-stream BPE).
std::vector<uint32_t> decode(const std::string& bytes);

size_t codepointCount(const std::string& bytes);

bool isValid(const std::string& bytes);

} // namespace utf8
} // namespace novallm
