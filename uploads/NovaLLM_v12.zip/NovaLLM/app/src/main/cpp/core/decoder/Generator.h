#pragma once
#include <string>
#include <vector>
#include "Model.h"
#include "Sampling.h"
#include "../tokenizer/Tokenizer.h"

namespace novallm {

// Ties everything built so far into one pipeline: text -> tokenizer ->
// model -> sampler -> append -> repeat -> decode back to text.
//
// Uses Model's KV-cached incremental forward: the prompt primes the cache
// in one call, then each new token only costs one incremental step
// instead of reprocessing the whole sequence - see core/transformer/
// KVCache.h for what that actually saves.
class Generator {
public:
    struct GenerationParams {
        int maxNewTokens = 20;
        Sampler::Params sampling;
    };

    Generator(Model& model, Tokenizer& tokenizer, unsigned int samplerSeed = 42);

    // Returns only the newly generated text (prompt not included). Stops
    // early if an "eos" special token gets sampled (if the tokenizer has
    // one registered) or if maxSeqLen would be exceeded.
    std::string generate(const std::string& prompt, const GenerationParams& params);

private:
    Model& model_;
    Tokenizer& tokenizer_;
    Sampler sampler_;
};

} // namespace novallm
