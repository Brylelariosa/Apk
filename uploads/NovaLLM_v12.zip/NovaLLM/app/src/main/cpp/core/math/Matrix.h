#pragma once
#include "Tensor.h"

namespace novallm {

// 2D matrix helpers built on top of Tensor.
// Convention: Tensor with shape {rows, cols}, row-major.
// These are naive O(n^3) / O(n^2) reference implementations.
// Correctness first - blocking/SIMD/NEON come later as their own pass.
namespace matrix {

// C = A * B, A is {m,k}, B is {k,n}, C is {m,n}
Tensor matmul(const Tensor& a, const Tensor& b);

// C = A + B (elementwise, same shape)
Tensor add(const Tensor& a, const Tensor& b);

// Add a bias vector (size == cols) to every row of A ({rows, cols})
Tensor addBias(const Tensor& a, const Tensor& bias);

// B = A^T
Tensor transpose(const Tensor& a);

// C = A * scalar
Tensor scale(const Tensor& a, float scalar);

// Numerically-stable row-wise softmax, in place: each row of x ({rows,
// cols}) becomes its own softmax distribution. Shared by attention
// (attention-weight rows) and, later, the decoder's output logits.
void softmaxRows(Tensor& x);

// Extracts columns [startCol, startCol+numCols) from a ({rows, colsA}).
Tensor sliceColumns(const Tensor& a, int startCol, int numCols);

// Writes src ({rows, numCols}) into dst's columns [startCol, ...), in place.
void setColumns(Tensor& dst, int startCol, const Tensor& src);

} // namespace matrix
} // namespace novallm
