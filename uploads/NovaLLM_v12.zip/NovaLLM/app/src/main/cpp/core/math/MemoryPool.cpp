#include "MemoryPool.h"
#include <new>
#include <cstdlib>

namespace novallm {
namespace {
constexpr size_t kAlignment = 16;
}

MemoryPool::MemoryPool(size_t capacityBytes) : capacity_(capacityBytes) {
    // Over-allocate and hand-align manually rather than using aligned_alloc(),
    // which isn't available on Android below API 28 (bionic libc). minSdk
    // for this project is 24, so we can't rely on it.
    rawBuffer_ = static_cast<unsigned char*>(std::malloc(capacityBytes + kAlignment));
    if (!rawBuffer_) {
        throw std::bad_alloc();
    }
    uintptr_t addr = reinterpret_cast<uintptr_t>(rawBuffer_);
    uintptr_t alignedAddr = (addr + kAlignment - 1) & ~(kAlignment - 1);
    buffer_ = reinterpret_cast<unsigned char*>(alignedAddr);
}

MemoryPool::~MemoryPool() {
    std::free(rawBuffer_);
}

void* MemoryPool::alloc(size_t bytes) {
    size_t alignedBytes = (bytes + kAlignment - 1) & ~(kAlignment - 1);
    if (offset_ + alignedBytes > capacity_) {
        throw std::bad_alloc();
    }
    void* ptr = buffer_ + offset_;
    offset_ += alignedBytes;
    return ptr;
}

void MemoryPool::reset() {
    offset_ = 0;
}

} // namespace novallm
