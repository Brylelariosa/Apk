#pragma once
#include "../math/Tensor.h"
#include "Linear.h"
#include "KVCache.h"
#include <iosfwd>

namespace novallm {

// Causal (decoder-only) multi-head self-attention. Position i can only
// attend to positions <= i - this is what makes autoregressive generation
// valid at all. There is no non-causal mode: this is a text-generation
// engine, not a bidirectional encoder.
class MultiHeadAttention {
public:
    struct Grads {
        Tensor gradInput; // {seqLen, embedDim} - dL/dx, summed across the
                           // Q/K/V paths since x feeds all three
        Tensor gradWq, gradBq;
        Tensor gradWk, gradBk;
        Tensor gradWv, gradBv;
        Tensor gradWo, gradBo;
    };

    MultiHeadAttention(int embedDim, int numHeads, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}. Full recompute every
    // call - used for training / whole-sequence scoring, not generation.
    Tensor forward(const Tensor& x) const;

    // x: {newLen, embedDim} - JUST the new token(s) since the last call
    // (the whole prompt on the first call, then newLen==1 per step after).
    // Appends this step's K/V to `cache` and attends the new position(s)
    // against the FULL cached history. Returns {newLen, embedDim} - only
    // the new positions' outputs, mathematically identical to what
    // forward() would produce for those same positions given the whole
    // sequence, just without redoing the earlier positions' work.
    Tensor forwardIncremental(const Tensor& x, KVCache& cache) const;

    // x is the SAME input passed to forward(). Recomputes per-head Q/K/V
    // and post-softmax weights internally (same trade-off as
    // FeedForward::backward - simpler interface, some redundant compute).
    // Softmax's own backward naturally zeroes the gradient at causally-
    // masked positions (their weight is ~0 after softmax, which multiplies
    // through the whole term), so no separate re-masking step is needed.
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    int embedDim() const { return embedDim_; }
    int numHeads() const { return numHeads_; }
    int headDim() const { return headDim_; }

    // Direct access to the four projections' learnable parameters -
    // needed for gradient-checking the weight gradients (not just
    // gradInput), and later for the optimizer to reach every parameter
    // in the model.
    Linear& wq() { return wq_; }
    Linear& wk() { return wk_; }
    Linear& wv() { return wv_; }
    Linear& wo() { return wo_; }

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    int embedDim_;
    int numHeads_;
    int headDim_;
    Linear wq_, wk_, wv_, wo_;
};

} // namespace novallm
