#pragma once
#include <string>
#include <vector>
#include <unordered_map>

namespace novallm {

// Bidirectional token <-> id table. Ids 0-255 are always the 256 raw byte
// tokens (byte-level BPE base vocabulary) - this is what guarantees any
// input can be tokenized with zero "unknown token" cases: worst case, a
// byte just stays its own token. Everything above 255 is either a learned
// BPE merge or a special token.
class Vocabulary {
public:
    Vocabulary(); // seeds ids 0-255 with the 256 raw byte tokens

    // Adds a new token if not already present, returns its id either way.
    int addToken(const std::string& tokenBytes);

    int idFor(const std::string& tokenBytes) const; // -1 if absent
    const std::string& tokenFor(int id) const;
    size_t size() const { return idToToken_.size(); }

    int addSpecialToken(const std::string& name, const std::string& tokenBytes);
    int specialTokenId(const std::string& name) const; // -1 if absent

    void save(const std::string& path) const;
    void load(const std::string& path);

private:
    std::vector<std::string> idToToken_;
    std::unordered_map<std::string, int> tokenToId_;
    std::unordered_map<std::string, int> specialTokens_; // name -> id
};

} // namespace novallm
