# JNI binds by exact fully-qualified class/method name (Java_com_jarry_novallm_MainActivity_nativeXxx).
# If R8 renames MainActivity or any `external fun`, System.loadLibrary still
# succeeds but every native call fails at runtime with UnsatisfiedLinkError -
# this would NOT show up as a build error, only as a crash on device the
# first time a button is tapped. Keep this class and its native methods
# exactly as-is; let R8 shrink/obfuscate everything else freely.
-keep class com.jarry.novallm.MainActivity {
    native <methods>;
}
-keepclasseswithmembernames class * {
    native <methods>;
}
