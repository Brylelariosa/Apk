#!/usr/bin/env python3
"""Applies the 1.2.0 changes to the existing Android sources (extracted from the original ZIP into the work tree).
Every replacement must match exactly once, so everything else in the project stays byte-identical."""
import pathlib, sys

ROOT = pathlib.Path(sys.argv[1])  # work tree containing only the files being changed
KT = ROOT / "app/src/main/java/app/claudefilebridge"

def patch(path, edits):
    p = pathlib.Path(path)
    s = p.read_text()
    for label, old, new in edits:
        n = s.count(old)
        if n != 1:
            raise SystemExit(f"{p.name} '{label}': expected exactly 1 match, found {n}")
        s = s.replace(old, new)
    p.write_text(s)
    print("patched", p.name, len(edits), "edit(s)")

# ------------------------------------------------------------------ Model.kt
patch(KT / "Model.kt", [
    ("OpCtx", '''class OpCtx(
    val confirm: suspend (String, String) -> Boolean,
    val progress: (Float?, String) -> Unit
)''', '''class OpCtx(
    val confirm: suspend (String, String) -> Boolean,
    val progress: (Float?, String) -> Unit,
    /** Overwrite question that offers "Always allow"; the third argument is the workspace folder it would apply to. Null = use [confirm]. */
    val confirmOverwrite: (suspend (String, String, String) -> Boolean)? = null
)'''),
    ("Pending", 'class Pending(val id: String, val title: String, val detail: String, val deferred: CompletableDeferred<Boolean>)',
     'class Pending(val id: String, val title: String, val detail: String, val deferred: CompletableDeferred<Boolean>, val alwaysScope: String? = null)'),
])

# ------------------------------------------------------------------ Store.kt
patch(KT / "Store.kt", [
    ("overwrite grants", '''    var confirmOverwrite: Boolean
        get() = b("cf_over", true)
        set(v) { putB("cf_over", v) }
''', '''    var confirmOverwrite: Boolean
        get() = b("cf_over", true)
        set(v) { putB("cf_over", v) }

    /**
     * Folders (tree URIs) for which the user chose "Always allow" on the overwrite question. Stored in SharedPreferences, so
     * it survives repeated overwrites and app restarts; a different folder always asks again.
     */
    var overwriteGrants: Set<String>
        get() {
            val raw = s("ow_grants")
            if (raw.isEmpty()) return emptySet()
            return try {
                val a = JSONArray(raw)
                val out = HashSet<String>()
                for (i in 0 until a.length()) {
                    val u = a.optString(i)
                    if (u.isNotEmpty()) out.add(u)
                }
                out
            } catch (e: Exception) {
                emptySet()
            }
        }
        set(v) { put("ow_grants", if (v.isEmpty()) null else JSONArray(v.toList()).toString()) }

    fun grantOverwrite(treeUri: String) {
        overwriteGrants = overwriteGrants + treeUri
    }
'''),
])

# ------------------------------------------------------------------ Files.kt
p = KT / "Files.kt"
s = p.read_text()
start = s.index("    suspend fun write(path: String, content: String, overwrite: Boolean, createParents: Boolean, ctx: OpCtx): JSONObject {")
end = s.index("\n    private suspend fun copyFileTo(")
s = s[:start] + '''    /** Complete-content write or replacement; see [SafeWrite] (verified by read-back, revision checked, no prompt when the user chose Always allow). */
    suspend fun write(path: String, content: String, overwrite: Boolean, createParents: Boolean, ctx: OpCtx, expectedRevision: String = ""): JSONObject =
        SafeWrite.write(path, content, overwrite, createParents, expectedRevision, ctx)
''' + s[end:]
p.write_text(s)
print("patched Files.kt write()")
patch(p, [
    ("copy gate", '''            if (Prefs.confirmOverwrite && !ctx.confirm("Overwrite file?", "Claude wants to replace ${b.display} with a copy of ${a.display}.")) {
                throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
            }''', '''            OverwriteGate.ensure(ctx, b.tree, "Overwrite file?", "Claude wants to replace ${b.display} with a copy of ${a.display}.")'''),
    ("move gate", '''            if (Prefs.confirmOverwrite && !ctx.confirm("Overwrite file?", "Claude wants to replace ${b.display} with ${a.display}.")) {
                throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
            }''', '''            OverwriteGate.ensure(ctx, b.tree, "Overwrite file?", "Claude wants to replace ${b.display} with ${a.display}.")'''),
    ("read revision", '''                "long_lines_truncated" to truncated,
                "size" to total
            )''', '''                "long_lines_truncated" to truncated,
                "size" to total,
                "revision" to Revisions.of(l.tree, n)
            )'''),
    ("info revision", '''            "children" to (if (n.isDir) l.tree.children(n).size else null)
        )''', '''            "children" to (if (n.isDir) l.tree.children(n).size else null),
            "revision" to (if (n.isDir) null else Revisions.of(l.tree, n))
        )'''),
])

# ------------------------------------------------------------------ Zip.kt (ZIP replacement uses the same policy)
patch(KT / "Zip.kt", [
    ("zip gate", '''                if (Prefs.confirmOverwrite && !ctx.confirm("Replace existing ZIP?", "Claude wants to replace ${o.display}.")) {
                    throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
                }''', '''                OverwriteGate.ensure(ctx, o.tree, "Replace existing ZIP?", "Claude wants to replace ${o.display}.")'''),
])

# ------------------------------------------------------------------ Net.kt
patch(KT / "Net.kt", [
    ("journal sync", '''    suspend fun selftest(): ApiResult = post("/device/selftest", JSONObject())''',
     '''    suspend fun selftest(): ApiResult = post("/device/selftest", JSONObject())
    suspend fun journalSync(entries: JSONArray): ApiResult = post("/device/journal/sync", jsonOf("entries" to entries))'''),
])

# ------------------------------------------------------------------ Service.kt
patch(KT / "Service.kt", [
    ("ACT_ALWAYS const", '''    const val ACT_DENY = "app.claudefilebridge.DENY"''', '''    const val ACT_DENY = "app.claudefilebridge.DENY"
    const val ACT_ALWAYS = "app.claudefilebridge.ALWAYS"'''),
    ("always action", '''            .addAction(0, "Allow", pi(10, ACT_ALLOW))
            .addAction(0, "Deny", pi(11, ACT_DENY))
            .build()''', '''            .addAction(0, "Allow", pi(10, ACT_ALLOW))
            .apply { if (p.alwaysScope != null) addAction(0, "Always allow", pi(12, ACT_ALWAYS)) }
            .addAction(0, "Deny", pi(11, ACT_DENY))
            .build()'''),
    ("receiver", '''            Notifier.ACT_DENY -> Confirm.resolve(id, false)''', '''            Notifier.ACT_DENY -> Confirm.resolve(id, false)
            Notifier.ACT_ALWAYS -> Confirm.resolve(id, true, true)'''),
])

# ------------------------------------------------------------------ Ui.kt
patch(KT / "Ui.kt", [
    ("dialog", '''        text = { Text(cur.detail) },
        confirmButton = { AppButton("Allow", { Confirm.resolve(cur.id, true) }) },''', '''        text = { Text(if (cur.alwaysScope != null) cur.detail + "\\n\\nAlways allow stops this question for replacing existing files in this folder. You can turn it off again in Settings." else cur.detail) },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (cur.alwaysScope != null) AppButton("Always allow", { Confirm.resolve(cur.id, true, true) }, style = BtnStyle.Outline)
                AppButton("Allow", { Confirm.resolve(cur.id, true) })
            }
        },'''),
    ("settings state", '''    var cfOver by remember { mutableStateOf(Prefs.confirmOverwrite) }
''', '''    var cfOver by remember { mutableStateOf(Prefs.confirmOverwrite) }
    var owGrants by remember { mutableIntStateOf(Prefs.overwriteGrants.size) }
'''),
    ("settings row", '''                ToggleRow("Confirm overwrites", cfOver, { cfOver = it; Prefs.confirmOverwrite = it })
''', '''                ToggleRow("Confirm overwrites", cfOver, { cfOver = it; Prefs.confirmOverwrite = it })
                if (owGrants > 0) {
                    Hint("Always allow is on for $owGrants folder(s): replacing existing files there no longer asks.")
                    AppButton("Ask again before overwriting", { Prefs.overwriteGrants = emptySet(); owGrants = 0 }, Modifier.fillMaxWidth(), style = BtnStyle.Outline)
                }
'''),
])

# ------------------------------------------------------------------ Bridge.kt
patch(KT / "Bridge.kt", [
    ("import", "import org.json.JSONObject\n", "import org.json.JSONArray\nimport org.json.JSONObject\n"),
    ("remoteCtx", '''                val ok = Confirm.ask(title, detail)
                scope.launch { Backend.progressQuiet(cmd.id, "running", null) }
                ok
            },''', '''                val ok = Confirm.ask(title, detail)
                scope.launch { Backend.progressQuiet(cmd.id, "running", null) }
                ok
            },
            confirmOverwrite = { title, detail, workspaceKey ->
                scope.launch { Backend.progressQuiet(cmd.id, "awaiting_confirmation", jsonOf("waiting_for" to title)) }
                OpTracker.put(cmd.id, OpInfo(cmd.tool, "Waiting for your approval", null, cmd.id, cmd.client))
                val ok = Confirm.ask(title, detail, alwaysScope = workspaceKey)
                scope.launch { Backend.progressQuiet(cmd.id, "running", null) }
                ok
            },'''),
    ("Confirm", '''    suspend fun ask(title: String, detail: String, timeoutMs: Long = 120_000L): Boolean {
        val d = CompletableDeferred<Boolean>()
        val p = Pending(UUID.randomUUID().toString(), title, detail, d)''', '''    suspend fun ask(title: String, detail: String, timeoutMs: Long = 120_000L, alwaysScope: String? = null): Boolean {
        val d = CompletableDeferred<Boolean>()
        val p = Pending(UUID.randomUUID().toString(), title, detail, d, alwaysScope)'''),
    ("Confirm.resolve", '''    fun resolve(id: String, allow: Boolean) {
        val p = BridgeState.pending.value
        if (p != null && p.id == id) p.deferred.complete(allow)
    }''', '''    fun resolve(id: String, allow: Boolean, always: Boolean = false) {
        val p = BridgeState.pending.value
        if (p != null && p.id == id) {
            // "Always allow" is stored before the answer is delivered, so it holds even if the waiting operation was cancelled meanwhile.
            val scope = p.alwaysScope
            if (allow && always && scope != null) Prefs.grantOverwrite(scope)
            p.deferred.complete(allow)
        }
    }'''),
    ("write_file expected_revision", '''FileOps.write(a.optString("path"), a.optString("content"), ow, a.optBoolean("create_parents", true), ctx)''',
     '''FileOps.write(a.optString("path"), a.optString("content"), ow, a.optBoolean("create_parents", true), ctx, a.optString("expected_revision"))'''),
    ("new tools", '''            "create_folder" -> {
                need(Perm.CREATE_FOLDERS)''', '''            "edit_file" -> {
                need(Perm.MODIFY)
                SafeWrite.edit(a.optString("path"), a.optJSONArray("edits") ?: JSONArray(), a.optString("expected_revision"), ctx)
            }
            "verify_files" -> {
                need(Perm.READ)
                Verify.files(a.optJSONArray("paths") ?: JSONArray(), a.optBoolean("hash", true))
            }
            "verify_zip" -> {
                need(Perm.READ)
                Verify.zip(a.optString("path"), a.optJSONArray("expect_files") ?: JSONArray(), a.optBoolean("deep", false))
            }
            "create_folder" -> {
                need(Perm.CREATE_FOLDERS)'''),
    ("READ_ONLY", 'private val READ_ONLY = setOf("list_files", "read_file", "get_file_info", "get_build_status", "get_build_logs")',
     'private val READ_ONLY = setOf("list_files", "read_file", "get_file_info", "verify_files", "verify_zip", "get_build_status", "get_build_logs")'),
    ("stateJson", '''        "workspace" to treeLabel(Prefs.treeUri("workspace")),
        "app" to BuildConfig.VERSION_NAME
    )''', '''        "workspace" to treeLabel(Prefs.treeUri("workspace")),
        "app" to BuildConfig.VERSION_NAME,
        "confirmations" to jsonOf("overwrite" to OverwriteGate.policyFor(Prefs.treeUri("workspace"))),
        "features" to Features.list
    )'''),
    ("start recover", '''        BridgeState.claudeEnabled.value = Prefs.claudeEnabled
        registerNet(ctx)''', '''        BridgeState.claudeEnabled.value = Prefs.claudeEnabled
        Journal.recoverInterrupted()
        registerNet(ctx)'''),
    ("hello sync", '''            if (st > 0L) Prefs.skewMs = st - System.currentTimeMillis()
''', '''            if (st > 0L) Prefs.skewMs = st - System.currentTimeMillis()
            Journal.syncPending()
'''),
    ("journal begin", '''    private suspend fun runCommand(cmd: Command) {
        val t0 = System.currentTimeMillis()''', '''    private suspend fun runCommand(cmd: Command) {
        val t0 = System.currentTimeMillis()
        Journal.begin(cmd)'''),
    ("journal finish", '''        val bytes = result?.optLong("size", 0L) ?: 0L
''', '''        Journal.finish(cmd, ok, code, result, ms)
        val bytes = result?.optLong("size", 0L) ?: 0L
'''),
    ("reportResult", '''                if (r.code in 200..299 || r.code == 400 || r.code == 401) return
''', '''                if (r.code in 200..299 || r.code == 400 || r.code == 401) {
                    // accepted=false: the backend had already given up on this command, so keep it for the journal sync
                    if (r.code in 200..299 && r.body?.optBoolean("accepted", true) != false) Journal.reported(id)
                    return
                }
'''),
])

# ------------------------------------------------------------------ build + docs
patch(ROOT / "app/build.gradle.kts", [
    ("version", '''        versionCode = 3
        versionName = "1.1.0"''', '''        versionCode = 4
        versionName = "1.2.0"'''),
])
print("done")
