# Claude FileBridge

Android app + Supabase backend that lets Claude work with files on your phone through a custom MCP connector.
Files stay on the phone. Supabase only relays small commands and small results.

```
Claude -> MCP (Edge Function filebridge-mcp) -> command queue -> signed Realtime wake
       -> phone (FileBridge app) -> local file operations (Storage Access Framework) -> small result -> Claude
```

## Build the app
- Project root = ZIP root. JDK 17, Android SDK 35: `./gradlew assembleDebug` (or `assembleRelease`, debug-signed and minified).
  `gradlew` is included; it uses `gradle/wrapper/gradle-wrapper.jar` and downloads that jar itself if it is missing. The wrapper downloads Gradle 8.9 (required by AGP 8.7).
- One universal APK. No ABI splits, no abiFilters. minSdk 26, targetSdk 34.
- This project was written without a Kotlin toolchain available, so it has not been compiled yet. If CI reports a compile error, send the log and it gets fixed.

## Backend (Supabase project uvxrpymncajhqtqpwdsb)
- Schema, RLS and helper functions: `supabase/migrations/20261005_filebridge_schema_v1.sql` (already applied).
- Edge Function: `supabase/functions/filebridge-mcp/index.ts`.
  Deploy with JWT verification OFF (the function authenticates every call itself).
  Dashboard route: Edge Functions > Deploy a new function > Via Editor > name `filebridge-mcp` > paste the file > Deploy,
  then Function details > turn off "Enforce JWT verification".
- Health check: `GET https://uvxrpymncajhqtqpwdsb.supabase.co/functions/v1/filebridge-mcp/health`

## First run on the phone
1. Setup: backend URL is pre-filled. Enter the one-time pairing code and tap Pair.
2. Select Folder for Claude Workspace (for example Download/Claude). ZIP / APK / Build folders are optional;
   without them `ZIP/`, `APK/` and `BuildWorkspace/` are sub-folders of the workspace.
3. Start FileBridge. It runs as a foreground service so you can keep using the phone. Stop it from the notification or the home screen.
4. In Claude: Settings > Connectors > Add custom connector > paste the connector URL (it contains a private key, treat it like a password).
5. Battery: set FileBridge to Unrestricted (button in Settings). On Infinix XOS also allow Auto-start.
6. For builds: Settings > Build provider (GitHub): owner, repo, branch, workflow file, ZIP path in the repo, token.

## Safety model
- AIs only get narrow tools: 19 for files and builds, 7 for shared memory. There is no shell / exec / terminal tool.
- The phone enforces everything: workspace-only paths (`..` rejected), permission toggles, confirmations, no silent overwrite.
  Move / Delete / Upload are OFF by default. Deleting always asks on the phone.
- Commands are signed (HMAC) per device, carry an ID, timestamp, expiry and nonce, and are accepted once.
  Destructive commands expire in 45 s and are discarded if the phone was away. Replays are rejected.
- Per-device bearer token (hash stored server-side), secrets encrypted with the Android Keystore. RLS denies all direct table access.
- Realtime only carries tiny signed wake pings; commands and results travel over authenticated HTTPS and results are purged once delivered.
- Emergency Stop cancels ZIPs, uploads and pending operations and pauses Claude. It never deletes files.
- ZIPs are streamed to `NAME.zip.tmp` and renamed on success; failures remove the temp file. Extraction blocks path traversal and rolls back on error.
- Low resource use: no background scanning, indexing, polling or screenshots; one heartbeat about every 25 s while idle; one heavy operation at a time.

## Troubleshooting: "device_unreachable" / commands never arrive
1. Home > Diagnostics (same lines in `adb logcat -s FileBridge`). Healthy sequence:
   `realtime: joined channel` > `wake self-test OK` > on every command `ping received: a command is waiting` > `poll: 1 command(s) received` > `<tool> -> ok in N ms`.
2. `wake self-test FAILED` means Realtime pings are not arriving. The app then switches to polling by itself.
   Settings > Connection > "Reliable mode (polling)" forces polling (a little more data and battery, works when pings are blocked).
3. Backend log (Supabase > Edge Functions > filebridge-mcp > Logs): each command logs `"evt":"queued",...,"wake":202`.
   Anything else is a backend problem. v1.0.0 sent a secret key as a Bearer header to Realtime and got 401; fixed in function 1.0.1.
4. Battery (Infinix / XOS): App info > Battery > No restrictions, allow Auto-start / Background activity, lock FileBridge in Recents,
   switch off power-saving modes and "Power Marathon". Doze can pause the connection with the screen off even for foreground services.
5. Stale pairing: Home > Disconnect Device, then pair again with a new one-time code (the old code is single-use).

## Shared memory and several AIs at the same time (v1.1.0)
- Every AI gets its own connector key (Settings > Connected AIs) with scopes: `memory`, `files`, `builds`. A new AI defaults to memory only.
  Each key can be revoked at any moment. Tools outside an AI's scopes are hidden and refused.
- Memory tools: `memory_resume` (start here), `memory_search`, `memory_read`, `memory_write`, `memory_append`, `memory_handoff`, `memory_archive`.
  Author is recorded from the key, so one AI cannot pose as another. Entries carry a version (edits are refused if another AI changed them first),
  to-dos can be claimed with `status=in_progress` so two AIs do not take the same task, and `memory_append` is safe for simultaneous writers.
- Secrets (tokens, keys, private keys, connector URLs) are rejected on write. Memory is notes, never instructions. Only you can delete entries (Memory tab).
- Running together: reads from several AIs run in parallel on the phone, changes run one at a time, each AI may have 5 operations waiting (10 per phone).
- Continue the work anywhere: Memory tab > copy icon exports everything as Markdown.
- Backend source: `supabase/functions/filebridge-mcp/index.ts` (1.2.0) and `supabase/migrations/*` (the 1.2.0 upgrade is described below).

## UI
Real Material buttons and vector icons everywhere, no emoji. Bottom navigation: Home, Files, Memory, Activity, Settings.

## 1.2.0: reliability upgrade (overwrite prompts, automatic recovery, coordination)

### Why overwrites asked for permission (root cause, from the real command history)
Every overwrite (`write_file` with `overwrite=true`) waited for FileBridge's **own on-device "Overwrite file?" confirmation**:
the 4 overwrites on record took 96 s on average (one timed out at 120 s and was recorded as `declined`), while ordinary writes took 2 s.
`Confirm overwrites` was ON by default and had no "always" choice, and Claude's per-tool "Always allow" cannot reach into the phone.
Three different things can ask, and they are now distinguishable:
- **FileBridge app** (dialog + notification on the phone). Results now say `confirmation_source: "filebridge_app"` while waiting, and `list_devices` shows `confirmations.overwrite` (`ask`, `always_allow` or `never_ask`).
- **Android Storage Access Framework** never asks per file: the folder grant is persisted (`takePersistableUriPermission`, read+write) and survives restarts. It only asks again if the grant is lost (folder moved/deleted, app data cleared).
- **Claude's MCP client** shows its own approval card before a tool call even reaches FileBridge; the server cannot see or change it. Set the connector's tools to "Always allow" in Claude. After upgrading, use "refresh tools" once: new tools start as "needs approval".

### What changed
- **Always allow, persistent and scoped.** The overwrite dialog and notification have an **Always allow** button. It is stored per workspace folder in SharedPreferences (survives restarts), applies to `write_file`, `edit_file`, copy/move onto an existing file and replacing an existing ZIP in that folder, and never to another folder. Delete still always asks. Settings shows it and can switch it off again.
- **`write_file` replaces the complete content correctly.** The new content is first written to `NAME.fbtmp`, then written into the original file in place (mode `wt`, so nothing is appended or duplicated and the file keeps its identity), read back and compared by SHA-256. If that does not verify, the complete temporary copy is swapped in. Identical content is a no-op (no prompt). Results carry `revision`, `verified` and `confirmation`.
- **`edit_file`** (new): exact-match replacements in an existing text file, all or nothing, verified the same way.
- **Revisions and conflicts.** `read_file`, `get_file_info`, `write_file`, `edit_file` return a `revision` (SHA-256). A replace is refused with `revision_conflict` if the file changed since the AI last read it (the phone re-checks atomically; the server fills in the revision the session last read). A file another AI changed and this AI never read is refused with `revision_unseen`.
- **Leases** (`file_lease`): reserve files/folders for a few minutes; other AIs' writes there are refused with `locked_by_other`; leases expire by themselves, so a session that hits its usage limit never blocks others.
- **Automatic journal and shared memory.** Every file operation is journalled by the server itself (tool, paths, owner, project, state, revision), `file_state` tracks each file's revision, the project revision moves on every change, and a pinned **Auto progress: <project>** entry in shared memory is rebuilt after every change. Nothing depends on an AI remembering `PROJECT_STATE.md` or a handoff. If shared memory is full or unavailable the journal still holds everything.
- **Phone-side journal.** Results the backend never received and operations that were running when the app died are kept in `fb_journal.jsonl` and synchronised after the next connection (`/device/journal/sync`).
- **`resume_project`** (new): returns unfinished/interrupted/not-executed operations, test states, leases, checkpoint, modified files, and **checks the recently changed files on the real phone** (`verify_files`): missing files, files changed outside the journal, leftover `*.fbtmp`.
- **`project_checkpoint`** (new): what only the AI knows (done / pending / next steps); mirrored into the Auto progress entry.
- **`test_run`** (new): `plan` -> `start` -> `finish(passed|failed)` or `interrupt`, with command, environment (`original` / `temp_copy` / `other`), affected files, exit code and errors. A planned test can never become passed, passed needs exit code 0, a test whose session vanished becomes `interrupted` automatically, and a result goes stale when a covered file changes afterwards. FileBridge has no shell/exec by design, so tests run where they can run and are recorded honestly.
- **ZIPs:** `verify_zip` (new) checks that a ZIP exists, lists its entries, checks expected files (and CRCs with `deep`). `create_zip` / `prepare_project_zip` accept `expect_files` and fail with `zip_verification_failed` instead of reporting success when something is missing.
- **Direct workspace work.** The server instructions tell Claude to read/edit/write the original files through FileBridge instead of copying projects into its own sandbox, and to copy only the smallest set of files when something must be compiled elsewhere (recorded as `temp_copy`).

### Deploy / upgrade steps
1. Database: apply `supabase/migrations/20261017_filebridge_v1_2a_state_leases_tests.sql`, then `..._v1_2b_queue_integration.sql` (additive and backward compatible; both are already applied to project `uvxrpymncajhqtqpwdsb`).
2. Edge Function: deploy `supabase/functions/filebridge-mcp/index.ts` (verify_jwt stays OFF). `GET /health` should report `1.2.0`.
3. App: build 1.2.0 (versionCode 4), install it, open Settings once. In Claude, refresh the connector's tools.
`patch/` contains the scripts that derived these files from 1.1.0 (every replacement must match exactly once).

### Tests
- `supabase/tests/filebridge_v1_2_tests.sql` (SQL, each block runs inside a transaction that is rolled back; see its header for what was run) and `tests/edge_function.test.mjs` (`node --test`, Node 22+, runs the real `index.ts` against `tests/mock_supabase.mjs` and a simulated phone).
- `tests/kotlin_lint.py` is only a structural check (brackets/strings). **The Android code was not compiled in the environment that produced 1.2.0** (no Kotlin/Android toolchain); build it with your usual flow and send the log if anything fails.

### Known limitations
- Two chats that share one connector key are only told apart if they pass the `session` value `resume_project` returns; the phone-side revision check protects overwrites either way.
- While an on-device confirmation is open, other changes queue behind it (up to 120 s).
- Revisions are SHA-256 of files up to 32 MB; larger files report no revision, and `edit_file` works on text files up to 3 MB. `read_file` still truncates lines over 4000 characters, so never rebuild a file from a read: use `edit_file`.
- `resume_project` can only verify files on the phone when the 1.2.0 app is installed.

