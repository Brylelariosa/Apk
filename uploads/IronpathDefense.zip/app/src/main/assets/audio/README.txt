Optional audio overrides
------------------------
The game synthesizes every sound effect in code (see audio/SoundSynth.kt), so this
folder can stay empty. To replace a sound, drop an .ogg/.wav here using the name from
audio/SoundEffect.kt (button_tap.ogg, shoot.ogg, hit.ogg, explosion.ogg, tower_place.ogg,
tower_upgrade.ogg, tower_sell.ogg, wave_start.ogg, life_lost.ogg, victory.ogg, game_over.ogg).

Background music: add music_loop.ogg here. The Music volume slider only appears in
Settings when that file exists; the game never fakes music.
