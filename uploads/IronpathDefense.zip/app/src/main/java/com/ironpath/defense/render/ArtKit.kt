package com.ironpath.defense.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.SparseArray

/**
 * Shared vector-drawing primitives for all procedural art (towers, enemies,
 * effects). One set of preallocated paints means drawing a tower with fifty
 * parts allocates nothing. Glows use one cached unit-size radial gradient per
 * color, scaled by the canvas, so a glow is a single draw call.
 */
object ArtKit {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val s = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val glows = SparseArray<RadialGradient>()
    val path = Path()

    /** Low graphics quality swaps gradient glows for a flat translucent disc. */
    var glowEnabled = true

    val STONE = 0xFF676C74.toInt()
    val STONE_LIGHT = 0xFF8A9099.toInt()
    val WOOD = 0xFF8B5E34.toInt()
    val WOOD_LIGHT = 0xFFB07B44.toInt()
    val WOOD_DARK = 0xFF5E3D20.toInt()
    val STEEL = 0xFFB8C2CE.toInt()
    val STEEL_DARK = 0xFF6A7480.toInt()
    val IRON = 0xFF3E434B.toInt()
    val GOLD = 0xFFFFD35A.toInt()
    val FIRE = 0xFFFF9A3C.toInt()
    val ICE = 0xFFBFF3FF.toInt()

    fun circ(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        c.drawCircle(x, y, r, p)
    }

    fun ring(c: Canvas, x: Float, y: Float, r: Float, w: Float, col: Int) {
        s.strokeWidth = w
        s.color = col
        c.drawCircle(x, y, r, s)
    }

    fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        rf.set(l, t, r, b)
        c.drawRoundRect(rf, rad, rad, p)
    }

    fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        rf.set(l, t, r, b)
        c.drawOval(rf, p)
    }

    fun ovalStroke(c: Canvas, l: Float, t: Float, r: Float, b: Float, w: Float, col: Int) {
        s.strokeWidth = w
        s.color = col
        rf.set(l, t, r, b)
        c.drawOval(rf, s)
    }

    fun ln(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, col: Int) {
        s.strokeWidth = w
        s.color = col
        c.drawLine(x1, y1, x2, y2, s)
    }

    fun arc(c: Canvas, cx: Float, cy: Float, r: Float, start: Float, sweep: Float, w: Float, col: Int) {
        s.strokeWidth = w
        s.color = col
        rf.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rf, start, sweep, false, s)
    }

    fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, col: Int) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.close()
        p.style = Paint.Style.FILL
        p.color = col
        c.drawPath(path, p)
    }

    fun quad(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, x4: Float, y4: Float, col: Int) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.lineTo(x4, y4)
        path.close()
        p.style = Paint.Style.FILL
        p.color = col
        c.drawPath(path, p)
    }

    /** Draws the path built in [path] filled. */
    fun fillPath(c: Canvas, col: Int) {
        p.style = Paint.Style.FILL
        p.color = col
        c.drawPath(path, p)
    }

    fun strokePath(c: Canvas, w: Float, col: Int) {
        s.strokeWidth = w
        s.color = col
        c.drawPath(path, s)
    }

    fun polygon(c: Canvas, cx: Float, cy: Float, r: Float, sides: Int, rotDeg: Float, col: Int) {
        path.reset()
        for (i in 0 until sides) {
            val a = (rotDeg + i * 360f / sides) * 0.0174533f
            val px = cx + kotlin.math.cos(a) * r
            val py = cy + kotlin.math.sin(a) * r
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        p.style = Paint.Style.FILL
        p.color = col
        c.drawPath(path, p)
    }

    fun glow(c: Canvas, x: Float, y: Float, r: Float, col: Int, a: Float) {
        if (a <= 0.01f || r <= 0.5f) return
        val rgb = col and 0x00FFFFFF
        if (!glowEnabled) {
            circ(c, x, y, r * 0.55f, rgb or ((a * 80f).toInt().coerceIn(0, 255) shl 24))
            return
        }
        var sh = glows.get(rgb)
        if (sh == null) {
            sh = RadialGradient(
                0f, 0f, 1f,
                intArrayOf(rgb or (0xFF shl 24), rgb or (0x66 shl 24), rgb),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            glows.put(rgb, sh)
        }
        gp.shader = sh
        gp.alpha = (a * 255f).toInt().coerceIn(0, 255)
        c.save()
        c.translate(x, y)
        c.scale(r, r)
        c.drawCircle(0f, 0f, 1f, gp)
        c.restore()
    }

    fun shade(col: Int, f: Float): Int {
        val a = (col ushr 24) and 0xFF
        val r = (((col shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((col shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((col and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun withAlpha(col: Int, a: Float): Int =
        (col and 0x00FFFFFF) or (((((col ushr 24) and 0xFF) * a).toInt().coerceIn(0, 255)) shl 24)

    fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        return (0xFF shl 24) or (((ar + (br - ar) * k).toInt()) shl 16) or (((ag + (bg - ag) * k).toInt()) shl 8) or ((ab + (bb - ab) * k).toInt())
    }

    /** Cheap deterministic hash noise in [0,1) for jitter without allocating a Random. */
    fun hash(n: Int): Float {
        var x = n * 374761393 + 668265263
        x = (x xor (x ushr 13)) * 1274126177
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65536f
    }
}
