package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.Vector2

/** A short-lived visual spark (tower impact, enemy death, upgrade burst). Pooled by ParticleSystem. */
class Particle {
    val position = Vector2()
    val velocity = Vector2()
    /** Added to vertical velocity each second (negative = rises, like embers). */
    var accelY = 0f
    var lifeRemaining = 0f
    var lifeTotal = 1f
    var colorArgb = 0xFFFFFFFF.toInt()
    var startRadius = 4f
    var style = 0 // 0 spark, 1 smoke (grows, fades), 2 ember (rises, glows)
    var growth = 0f
    var alive = false

    /** 1 at birth, fading to 0 at death — the renderer uses this for both size and alpha falloff. */
    fun lifeFraction(): Float = if (lifeTotal <= 0f) 0f else (lifeRemaining / lifeTotal).coerceIn(0f, 1f)
}
