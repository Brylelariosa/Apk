package com.ironpath.defense.ui

import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.core.GraphicsQuality
import com.ironpath.defense.engine.GameRun
import com.ironpath.defense.engine.Juice
import com.ironpath.defense.engine.RunSummary
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.map.MapRegistry
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.save.SaveData
import com.ironpath.defense.settings.SettingsSystem

/**
 * Everything the renderer and screens need to draw one frame, gathered in one
 * place. Systems are exposed read-only by convention: the UI never mutates
 * game state directly — it only calls [GameActions].
 */
class HudState(
    val data: SaveData,
    val settings: SettingsSystem,
    val ui: UiState,
    val banners: BannerSystem,
    val particles: ParticleSystem,
    val juice: Juice
) {
    var screen = GameScreenState.MAIN_MENU
    var run: GameRun? = null
    var backdrop: MapSystem? = null
    var speedIndex = 0
    var fade = 0f
    var time = 0f
    var summary: RunSummary? = null
    var quality = GraphicsQuality.MEDIUM

    /** Seconds since the end screen appeared (drives its animations). */
    var endAge = 0f

    /** A map is playable once the previous map has reached [MapRegistry.UNLOCK_WAVE]. */
    fun isMapUnlocked(index: Int): Boolean =
        index <= 0 || data.mapBestWave[(index - 1).coerceIn(0, SaveData.SLOTS - 1)] >= MapRegistry.UNLOCK_WAVE
}
