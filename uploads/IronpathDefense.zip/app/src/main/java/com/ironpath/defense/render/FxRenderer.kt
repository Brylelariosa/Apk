package com.ironpath.defense.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.entity.projectile.Projectile
import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.zone.Zone
import com.ironpath.defense.entity.zone.ZoneKind
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.glow
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.polygon
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.tri
import com.ironpath.defense.render.ArtKit.withAlpha
import kotlin.math.cos
import kotlin.math.sin

/**
 * Draws everything transient in the battlefield (world units): lingering
 * zones, projectiles (each weapon looks different, and upgrades visibly change
 * them: fire arrows, ballista bolts, cluster/doomsday shells, fuel globs, rail
 * slugs...), particles, shock rings, lightning arcs and floating numbers.
 */
class FxRenderer {
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    // --- zones (under enemies) -----------------------------------------------
    fun drawZones(c: Canvas, zones: List<Zone>, time: Float) {
        for (i in 0 until zones.size) {
            val z = zones[i]
            val col = z.kind.colorArgb
            if (z.telegraph > 0f) {
                val pulse = 0.5f + 0.5f * sin(time * 9f)
                ring(c, z.x, z.y, z.radius, 3f, withAlpha(col, 0.45f + 0.4f * pulse))
                glow(c, z.x, z.y, z.radius, col, 0.12f + 0.1f * pulse)
                ArtKit.arc(c, z.x, z.y, z.radius - 6f, -90f, 360f * (1f - z.telegraph / z.telegraphTotal), 4f, withAlpha(col, 0.9f))
                continue
            }
            val fade = (z.life / 0.6f).coerceIn(0f, 1f)
            when (z.kind) {
                ZoneKind.FIRE -> {
                    glow(c, z.x, z.y, z.radius * 1.15f, col, 0.35f * fade)
                    for (k in 0 until 4) {
                        val ph = time * 5f + k * 1.9f + z.x
                        val fx = z.x + cos(ph * 0.7f + k) * z.radius * 0.55f
                        val fy = z.y + sin(ph * 0.9f + k) * z.radius * 0.35f
                        glow(c, fx, fy - 4f, 8f, 0xFFFFC46B.toInt(), 0.7f * fade)
                        tri(c, fx - 3f, fy + 3f, fx + 3f, fy + 3f, fx + sin(ph) * 1.5f, fy - 9f - sin(ph * 2f) * 2f, withAlpha(col, 0.9f * fade))
                    }
                }
                ZoneKind.TOXIC -> {
                    circ(c, z.x, z.y, z.radius, withAlpha(col, 0.16f * fade))
                    ring(c, z.x, z.y, z.radius, 1.6f, withAlpha(col, 0.4f * fade))
                    for (k in 0 until 5) {
                        val ph = (time * 0.7f + k * 0.37f) % 1f
                        circ(c, z.x + cos(k * 2.4f) * z.radius * 0.6f, z.y + z.radius * 0.4f - ph * z.radius * 0.9f, 2f + ph * 3f, withAlpha(col, 0.5f * (1f - ph) * fade))
                    }
                }
                ZoneKind.FROST -> {
                    circ(c, z.x, z.y, z.radius, withAlpha(col, 0.2f * fade))
                    ring(c, z.x, z.y, z.radius, 1.6f, withAlpha(0xFFFFFFFF.toInt(), 0.5f * fade))
                    for (k in 0 until 3) { val a = k * 2.1f + z.x; ln(c, z.x, z.y, z.x + cos(a) * z.radius * 0.8f, z.y + sin(a) * z.radius * 0.8f, 1.2f, withAlpha(0xFFFFFFFF.toInt(), 0.5f * fade)) }
                }
                ZoneKind.LAVA -> {
                    glow(c, z.x, z.y, z.radius * 1.5f, col, 0.5f * fade)
                    circ(c, z.x, z.y, z.radius, withAlpha(0xFFFF4A10.toInt(), 0.7f * fade))
                    circ(c, z.x, z.y, z.radius * 0.72f, withAlpha(0xFFFFB04A.toInt(), 0.7f * fade))
                    for (k in 0 until 6) {
                        val a = k * 1.05f + time * 0.4f
                        ln(c, z.x + cos(a) * z.radius * 0.2f, z.y + sin(a) * z.radius * 0.2f, z.x + cos(a + 0.4f) * z.radius * 0.85f, z.y + sin(a + 0.4f) * z.radius * 0.85f, 2.4f, withAlpha(0xFF3A1208.toInt(), 0.8f * fade))
                    }
                    ring(c, z.x, z.y, z.radius, 3f, withAlpha(0xFFFFE066.toInt(), 0.8f * fade))
                }
                ZoneKind.SPORE -> {
                    for (k in 0 until 5) {
                        val a = time * 0.5f + k * 1.26f
                        circ(c, z.x + cos(a) * z.radius * 0.4f, z.y + sin(a * 1.3f) * z.radius * 0.35f, z.radius * 0.62f, withAlpha(col, 0.14f * fade))
                    }
                    for (k in 0 until 7) { val ph = (time * 0.5f + k * 0.29f) % 1f; circ(c, z.x + cos(k * 2.1f) * z.radius * 0.8f * ph, z.y - ph * z.radius * 0.7f + sin(k * 1.3f) * 10f, 2.2f, withAlpha(0xFFE9C7FF.toInt(), 0.7f * (1f - ph) * fade)) }
                    ring(c, z.x, z.y, z.radius, 1.6f, withAlpha(col, 0.5f * fade))
                }
                ZoneKind.SURGE -> {
                    glow(c, z.x, z.y, z.radius, col, 0.16f * fade)
                    ring(c, z.x, z.y, z.radius, 2.4f, withAlpha(col, 0.7f * fade))
                    val tick = (time * 14f).toInt()
                    for (k in 0 until 3) {
                        val a = ArtKit.hash(tick + k * 17) * 6.283f
                        ln(c, z.x, z.y, z.x + cos(a) * z.radius, z.y + sin(a) * z.radius, 1.6f, withAlpha(0xFFE9FBFF.toInt(), 0.7f * fade))
                    }
                }
                ZoneKind.BOUNTY -> {
                    val spin = time * 25f
                    for (k in 0 until 12) ArtKit.arc(c, z.x, z.y, z.radius, spin + k * 30f, 16f, 3.2f, withAlpha(col, 0.8f))
                    circ(c, z.x, z.y, z.radius, withAlpha(col, 0.07f))
                    text.textSize = 26f
                    text.color = withAlpha(col, 0.85f)
                    c.drawText("$", z.x, z.y + 9f, text)
                }
                else -> {
                    circ(c, z.x, z.y, z.radius, withAlpha(col, 0.12f * fade))
                    ring(c, z.x, z.y, z.radius, 2f, withAlpha(col, 0.5f * fade))
                }
            }
        }
    }

    // --- projectiles ---------------------------------------------------------
    fun drawProjectiles(c: Canvas, list: List<Projectile>, time: Float) {
        for (i in 0 until list.size) projectile(c, list[i], time)
    }

    private fun projectile(c: Canvas, p: Projectile, time: Float) {
        val x = p.position.x
        val y = p.position.y
        val dx = p.dirX
        val dy = p.dirY
        val shot = p.shot
        when (p.type) {
            ProjectileType.ARROW -> {
                val len = if (shot.pierce > 0) 18f else 13f
                val fire = shot.burnDps > 0f
                if (fire) glow(c, x, y, 11f, shot.burnColorArgb, 0.7f)
                ln(c, x - dx * len, y - dy * len, x, y, 2.2f, 0xFFE8E4D8.toInt())
                tri(c, x + dx * 6f, y + dy * 6f, x - dy * 2.6f, y + dx * 2.6f, x + dy * 2.6f, y - dx * 2.6f, if (shot.splashRadius > 0f) 0xFFE0482E.toInt() else 0xFFCFD6DE.toInt())
                ln(c, x - dx * len, y - dy * len, x - dx * (len - 4f) - dy * 2.5f, y - dy * (len - 4f) + dx * 2.5f, 1.4f, 0xFFC9C3B0.toInt())
                ln(c, x - dx * len, y - dy * len, x - dx * (len - 4f) + dy * 2.5f, y - dy * (len - 4f) - dx * 2.5f, 1.4f, 0xFFC9C3B0.toInt())
            }
            ProjectileType.BALLISTA_BOLT -> {
                glow(c, x, y, 13f, 0xFFFFE08A.toInt(), if (shot.isCrit) 0.8f else 0.4f)
                ln(c, x - dx * 26f, y - dy * 26f, x, y, 3.6f, 0xFFB07B44.toInt())
                tri(c, x + dx * 9f, y + dy * 9f, x - dy * 4.2f, y + dx * 4.2f, x + dy * 4.2f, y - dx * 4.2f, 0xFFF2E3B0.toInt())
                if (shot.burnDps > 0f) glow(c, x, y, 14f, shot.burnColorArgb, 0.6f)
            }
            ProjectileType.CANNONBALL -> {
                val big = if (shot.isSpecial) 11f else 7f + shot.splashRadius * 0.02f
                for (k in 1..3) circ(c, x - dx * k * 7f, y - dy * k * 7f, big * (1f - k * 0.18f), withAlpha(0xFF8A8480.toInt(), 0.28f - k * 0.06f))
                if (shot.isSpecial) glow(c, x, y, big * 3f, 0xFFFF6A2E.toInt(), 0.8f)
                circ(c, x, y, big, 0xFF2A2B2F.toInt())
                circ(c, x - big * 0.3f, y - big * 0.3f, big * 0.38f, 0xFF6A6D74.toInt())
                if (shot.isSpecial) ring(c, x, y, big + 2f, 1.6f, 0xFFFFC46B.toInt())
            }
            ProjectileType.FROST_SHARD -> {
                glow(c, x, y, 11f, 0xFF9FE8FF.toInt(), 0.6f)
                ln(c, x - dx * 14f, y - dy * 14f, x, y, 1.6f, withAlpha(0xFFBFF3FF.toInt(), 0.5f))
                polygon(c, x, y, 6.5f, 4, p.age * 400f, shot.colorArgb or 0xFF000000.toInt())
                polygon(c, x, y, 3.4f, 4, p.age * 400f, 0xFFFFFFFF.toInt())
            }
            ProjectileType.RANGER_DART -> {
                glow(c, x, y, 10f, 0xFFFFF2B0.toInt(), 0.55f)
                ln(c, x - dx * 34f, y - dy * 34f, x, y, 2f, withAlpha(0xFFFFF2B0.toInt(), 0.55f))
                ln(c, x - dx * 16f, y - dy * 16f, x, y, 2.6f, 0xFFFFFFFF.toInt())
                if (shot.isCrit) glow(c, x, y, 16f, 0xFFFFD35A.toInt(), 0.7f)
            }
            ProjectileType.RAIL_SLUG -> {
                glow(c, x, y, 14f, 0xFF7DF9FF.toInt(), 0.7f)
                ln(c, x - dx * 56f, y - dy * 56f, x, y, 3.4f, withAlpha(0xFF7DF9FF.toInt(), 0.4f))
                ln(c, x - dx * 30f, y - dy * 30f, x, y, 2f, 0xFFFFFFFF.toInt())
                ring(c, x - dx * 10f, y - dy * 10f, 5f, 1.2f, withAlpha(0xFF7DF9FF.toInt(), 0.8f))
            }
            ProjectileType.LIGHTNING_BOLT -> {
                val tick = (time * 30f).toInt()
                glow(c, x, y, 14f, shot.colorArgb or 0xFF000000.toInt(), 0.8f)
                circ(c, x, y, 3.4f, 0xFFFFFFFF.toInt())
                for (k in 0 until 2) {
                    val a = ArtKit.hash(tick * 3 + k) * 6.283f
                    ln(c, x, y, x + cos(a) * 11f, y + sin(a) * 11f, 1.4f, 0xFFE9D9FF.toInt())
                }
                ln(c, x - dx * 16f, y - dy * 16f, x, y, 1.6f, withAlpha(0xFFB388FF.toInt(), 0.6f))
            }
            ProjectileType.FLAME -> {
                val col = shot.burnColorArgb
                val r = 5f + p.age * 36f
                val a = (1f - p.age * 2.2f).coerceIn(0.15f, 1f)
                glow(c, x, y, r * 2.3f, col, 0.5f * a)
                circ(c, x, y, r, withAlpha(col, 0.75f * a))
                circ(c, x, y, r * 0.55f, withAlpha(0xFFFFE08A.toInt(), 0.9f * a))
            }
            ProjectileType.FUEL_GLOB -> {
                val col = shot.burnColorArgb
                val wob = 1f + 0.12f * sin(p.age * 30f)
                glow(c, x, y, 18f, col, 0.55f)
                circ(c, x, y, 8f * wob, col)
                circ(c, x - 2f, y - 2f, 3.4f, 0xFFE9FFC8.toInt())
                for (k in 1..3) circ(c, x - dx * k * 6f, y - dy * k * 6f + k * 1.5f, 3.4f - k * 0.7f, withAlpha(col, 0.5f - k * 0.1f))
                if (shot.isSpecial) ring(c, x, y, 12f, 1.6f, 0xFFFFE066.toInt())
            }
        }
    }

    // --- particles & effects (above everything) -----------------------------
    fun drawParticles(c: Canvas, ps: ParticleSystem, time: Float, glowOn: Boolean) {
        val particles = ps.particles
        for (i in 0 until particles.size) {
            val p = particles[i]
            val lf = p.lifeFraction()
            when (p.style) {
                1 -> circ(c, p.position.x, p.position.y, p.startRadius, withAlpha(p.colorArgb, 0.42f * lf))
                2 -> {
                    if (glowOn) glow(c, p.position.x, p.position.y, p.startRadius * 3f, p.colorArgb, 0.55f * lf)
                    circ(c, p.position.x, p.position.y, p.startRadius * (0.4f + 0.6f * lf), withAlpha(p.colorArgb, lf))
                }
                else -> circ(c, p.position.x, p.position.y, (p.startRadius * lf).coerceAtLeast(0.6f), withAlpha(p.colorArgb, lf.coerceAtLeast(0.2f)))
            }
        }
        val rings = ps.rings
        for (i in 0 until rings.size) {
            val r = rings[i]
            val lf = r.lifeFraction()
            ring(c, r.position.x, r.position.y, r.currentRadius(), r.strokeWidth * (0.3f + lf), withAlpha(r.colorArgb, lf))
        }
        val bolts = ps.bolts
        for (i in 0 until bolts.size) bolt(c, bolts[i].from.x, bolts[i].from.y, bolts[i].to.x, bolts[i].to.y, bolts[i].colorArgb, bolts[i].lifeFraction(), i, time)
    }

    private fun bolt(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, lf: Float, seed: Int, time: Float) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(1f)
        val nx = -dy / len
        val ny = dx / len
        val tick = (time * 40f).toInt()
        var px = x1
        var py = y1
        val segs = 5
        for (s in 1..segs) {
            val t = s.toFloat() / segs
            val j = if (s == segs) 0f else (ArtKit.hash(seed * 31 + s * 7 + tick) - 0.5f) * 20f
            val qx = x1 + dx * t + nx * j
            val qy = y1 + dy * t + ny * j
            ln(c, px, py, qx, qy, 5f * lf + 1f, withAlpha(col, 0.35f * lf))
            ln(c, px, py, qx, qy, 1.8f, withAlpha(0xFFFFFFFF.toInt(), lf))
            px = qx
            py = qy
        }
        glow(c, x2, y2, 12f, col, 0.5f * lf)
    }

    fun drawTexts(c: Canvas, ps: ParticleSystem) {
        val numbers = ps.damageNumbers
        for (i in 0 until numbers.size) {
            val d = numbers[i]
            val lf = d.lifeFraction()
            text.textSize = if (d.isCrit) 25f else 16f
            val a = (lf * 1.6f).coerceIn(0f, 1f)
            text.color = withAlpha(0xFF101010.toInt(), a * 0.8f)
            c.drawText(d.value.toString(), d.position.x + 1f, d.position.y + 1.5f, text)
            text.color = withAlpha(if (d.isCrit) 0xFFFFD35A.toInt() else 0xFFFFFFFF.toInt(), a)
            c.drawText(d.value.toString(), d.position.x, d.position.y, text)
        }
        val texts = ps.floatingTexts
        for (i in 0 until texts.size) {
            val t = texts[i]
            val lf = t.lifeFraction()
            text.textSize = 21f
            val a = (lf * 1.8f).coerceIn(0f, 1f)
            text.color = withAlpha(0xFF101010.toInt(), a * 0.85f)
            c.drawText(t.text, t.position.x + 1.2f, t.position.y + 1.6f, text)
            text.color = withAlpha(t.colorArgb, a)
            c.drawText(t.text, t.position.x, t.position.y - (1f - lf) * 22f, text)
        }
    }
}
