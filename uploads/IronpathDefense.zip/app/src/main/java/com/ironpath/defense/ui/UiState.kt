package com.ironpath.defense.ui

import com.ironpath.defense.core.GameScreenState

/** Purely visual/navigation state that is not part of the game rules (which tab is open, which codex entry...). */
class UiState {
    var settingsReturn = GameScreenState.MAIN_MENU
    var codexTab = 0
    var codexTower = 0
    var codexBuild = 0

    companion object {
        /** Showcase builds in the Towers screen, to demonstrate visual crosspathing. */
        val PREVIEW_BUILDS = arrayOf(
            intArrayOf(0, 0, 0), intArrayOf(5, 2, 0), intArrayOf(2, 5, 0), intArrayOf(5, 0, 2),
            intArrayOf(0, 5, 2), intArrayOf(2, 0, 5), intArrayOf(0, 2, 5)
        )
    }
}
