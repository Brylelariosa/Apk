package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemySystem

/**
 * Spawns the groups of the active [WaveDefinition] on schedule and detects
 * when the wave is finished (all spawned and none of its enemies alive —
 * including anything summoned by bosses or splitters).
 *
 * The *plan* for a wave (including the Director's adaptation) is decided
 * outside, and handed in through [start], so the preview the player saw is
 * exactly what spawns.
 */
class WaveSystem(
    private val enemySystem: EnemySystem,
    val totalWaveCount: Int
) {
    var currentWaveIndex = 0 // number of waves cleared so far; 0 before the run starts
        private set
    var waveInProgress = false
        private set
    var enemiesRemaining = 0
        private set

    private var activeWave: WaveDefinition? = null
    private val groupStates = ArrayList<GroupSpawnState>()
    private var totalToSpawn = 0

    val activeWaveDefinition: WaveDefinition? get() = activeWave
    val hasWonGame: Boolean get() = currentWaveIndex >= totalWaveCount && !waveInProgress

    private class GroupSpawnState(val group: SpawnGroup) {
        var timeUntilNextSpawn = group.startDelaySeconds
        var spawnedCount = 0
        val isDone: Boolean get() = spawnedCount >= group.count
    }

    fun canStartNextWave(): Boolean = !waveInProgress && currentWaveIndex < totalWaveCount

    /** Index (1-based) of the wave that [start] will launch next. */
    val nextWaveNumber: Int get() = currentWaveIndex + 1

    fun start(definition: WaveDefinition) {
        if (!canStartNextWave()) return
        activeWave = definition
        groupStates.clear()
        totalToSpawn = 0
        for (g in definition.groups) {
            groupStates.add(GroupSpawnState(g))
            totalToSpawn += g.count
        }
        enemiesRemaining = totalToSpawn
        waveInProgress = true
    }

    /** Advances spawning. Returns the wave's base completion reward on the step it ends, else null. */
    fun update(dt: Float, healthMult: Float): Int? {
        val wave = activeWave ?: return null
        var spawned = 0
        var allDone = true
        for (state in groupStates) {
            if (!state.isDone) {
                state.timeUntilNextSpawn -= dt
                while (!state.isDone && state.timeUntilNextSpawn <= 0f) {
                    enemySystem.spawn(state.group.kind, wave.index, healthMult)
                    state.spawnedCount++
                    state.timeUntilNextSpawn += state.group.intervalSeconds
                }
            }
            spawned += state.spawnedCount
            if (!state.isDone) allDone = false
        }
        var alive = 0
        val list = enemySystem.active
        for (i in 0 until list.size) if (list[i].spawnedByWaveIndex == wave.index) alive++
        enemiesRemaining = (totalToSpawn - spawned) + alive
        if (allDone && alive == 0) {
            currentWaveIndex = wave.index
            waveInProgress = false
            activeWave = null
            groupStates.clear()
            enemiesRemaining = 0
            return wave.completionReward
        }
        return null
    }

    fun reset() {
        currentWaveIndex = 0
        waveInProgress = false
        activeWave = null
        groupStates.clear()
        enemiesRemaining = 0
    }
}
