package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.entity.enemy.EnemyKind.ARMORED
import com.ironpath.defense.entity.enemy.EnemyKind.BASIC
import com.ironpath.defense.entity.enemy.EnemyKind.BOSS
import com.ironpath.defense.entity.enemy.EnemyKind.BOSS_QUEEN
import com.ironpath.defense.entity.enemy.EnemyKind.FAST
import com.ironpath.defense.entity.enemy.EnemyKind.HEALER
import com.ironpath.defense.entity.enemy.EnemyKind.MINI_BRUISER
import com.ironpath.defense.entity.enemy.EnemyKind.MINI_COMMANDER
import com.ironpath.defense.entity.enemy.EnemyKind.PHANTOM
import com.ironpath.defense.entity.enemy.EnemyKind.REGENERATOR
import com.ironpath.defense.entity.enemy.EnemyKind.SHIELDED
import com.ironpath.defense.entity.enemy.EnemyKind.SPLITTER
import com.ironpath.defense.entity.enemy.EnemyKind.SWARM
import com.ironpath.defense.entity.enemy.EnemyKind.TANK

/**
 * The hand-authored 20-wave campaign of Ironpath Valley (the original map).
 * The first eight waves are the original release's, unchanged in spirit;
 * from wave 7 on the new enemy types are introduced one at a time, and the
 * old "boss every 5 waves" has become mini-bosses on 5/15 and bosses on 10/20.
 * Other maps use [WavePlanner]'s generator.
 */
object WaveLibrary {
    val ALL: List<WaveDefinition> = listOf(
        wave(1, WaveType.NORMAL,
            group(BASIC, 8, 0.80f),
            reward = 60),
        wave(2, WaveType.FAST,
            group(BASIC, 10, 0.70f),
            group(FAST, 4, 0.60f, 4f),
            reward = 70),
        wave(3, WaveType.ARMORED,
            group(BASIC, 8, 0.60f),
            group(ARMORED, 3, 1.20f, 3f),
            reward = 90),
        wave(4, WaveType.FAST,
            group(FAST, 10, 0.35f),
            group(BASIC, 6, 0.60f, 2f),
            reward = 100),
        wave(5, WaveType.MINIBOSS,
            group(BASIC, 6, 0.60f),
            group(MINI_BRUISER, 1, 1f, 6f),
            reward = 250),
        wave(6, WaveType.SWARM,
            group(ARMORED, 6, 1.00f),
            group(SWARM, 12, 0.25f, 3f),
            reward = 130),
        wave(7, WaveType.TANK,
            group(TANK, 2, 2.50f),
            group(BASIC, 8, 0.60f, 2f),
            group(FAST, 8, 0.30f, 5f),
            reward = 150),
        wave(8, WaveType.SWARM,
            group(SWARM, 16, 0.20f),
            group(REGENERATOR, 3, 1.50f, 4f),
            reward = 170),
        wave(9, WaveType.SPECIAL,
            group(SHIELDED, 6, 0.90f),
            group(FAST, 8, 0.30f, 4f),
            reward = 200),
        wave(10, WaveType.BOSS,
            group(REGENERATOR, 4, 1.20f),
            group(ARMORED, 6, 0.90f, 2f),
            group(BOSS, 1, 1f, 8f),
            reward = 320, isBoss = true),
        wave(11, WaveType.SPECIAL,
            group(SPLITTER, 5, 1.00f),
            group(FAST, 12, 0.25f, 3f),
            reward = 220),
        wave(12, WaveType.ARMORED,
            group(ARMORED, 10, 0.70f),
            group(TANK, 2, 2.50f, 4f),
            group(HEALER, 2, 1.60f, 5f),
            reward = 240),
        wave(13, WaveType.SPECIAL,
            group(PHANTOM, 8, 0.60f),
            group(REGENERATOR, 5, 1.00f, 3f),
            group(FAST, 10, 0.25f, 6f),
            reward = 260),
        wave(14, WaveType.SWARM,
            group(SWARM, 20, 0.15f),
            group(SPLITTER, 4, 1.00f, 3f),
            group(ARMORED, 6, 0.70f, 5f),
            reward = 280),
        wave(15, WaveType.MINIBOSS,
            group(SHIELDED, 8, 0.80f),
            group(MINI_COMMANDER, 1, 1f, 4f),
            group(HEALER, 2, 1.50f, 6f),
            reward = 450),
        wave(16, WaveType.MIXED,
            group(TANK, 3, 2.20f),
            group(HEALER, 3, 1.40f, 2f),
            group(SWARM, 18, 0.15f, 5f),
            reward = 300),
        wave(17, WaveType.ARMORED,
            group(ARMORED, 14, 0.60f),
            group(SHIELDED, 6, 0.80f, 4f),
            group(FAST, 16, 0.20f, 6f),
            reward = 330),
        wave(18, WaveType.SPECIAL,
            group(PHANTOM, 10, 0.55f),
            group(SPLITTER, 6, 0.90f, 3f),
            group(HEALER, 3, 1.40f, 5f),
            reward = 360),
        wave(19, WaveType.TANK,
            group(TANK, 5, 1.80f),
            group(ARMORED, 10, 0.55f, 3f),
            group(REGENERATOR, 6, 0.70f, 6f),
            reward = 400),
        wave(20, WaveType.BOSS,
            group(BOSS_QUEEN, 1, 1f),
            group(ARMORED, 12, 0.50f, 10f),
            group(SWARM, 16, 0.12f, 14f),
            group(BOSS, 1, 1f, 18f),
            reward = 600, isBoss = true)
    )

    private fun group(kind: EnemyKind, count: Int, interval: Float, delay: Float = 0f) =
        SpawnGroup(kind, count, interval, delay)

    private fun wave(index: Int, type: WaveType, vararg groups: SpawnGroup, reward: Int, isBoss: Boolean = false) =
        WaveDefinition(index, groups.toList(), reward, isBoss, type)
}
