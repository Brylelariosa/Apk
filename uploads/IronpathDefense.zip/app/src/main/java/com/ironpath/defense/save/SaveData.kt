package com.ironpath.defense.save

/**
 * Everything persisted between launches: settings and progression. A plain
 * mutable holder owned by GameWorld; [SaveSystem] copies it to and from
 * SharedPreferences. Per-map arrays are indexed by map id.
 */
class SaveData {
    // --- progression ------------------------------------------------------
    /** Best wave ever *completed* on any map; unlocks towers (unchanged from v1). */
    var highestWaveCompleted = 0
    var selectedMap = 0
    var selectedDifficulty = 1
    val mapBestWave = IntArray(SLOTS)
    val mapWins = IntArray(SLOTS)        // bitmask of Difficulty ordinals won
    val mapBestScore = IntArray(SLOTS)
    var achievements = 0L
    var totalKills = 0
    var bossKills = 0
    var wavesCleared = 0
    var towersBuilt = 0
    var fusionsBuilt = 0
    var steamBursts = 0
    var gamesPlayed = 0
    var flawlessWins = 0

    // --- settings ---------------------------------------------------------
    var showDamageNumbers = true
    var masterVolume = 8
    var sfxVolume = 8
    var musicVolume = 6
    var qualityOrdinal = -1 // -1 = pick a default for this device
    var screenShake = true
    var autoStart = false

    companion object {
        const val SLOTS = 16
    }
}
