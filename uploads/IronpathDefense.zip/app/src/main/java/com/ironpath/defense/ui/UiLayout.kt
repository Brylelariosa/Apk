package com.ironpath.defense.ui

import com.ironpath.defense.core.GameConfig

/**
 * Screen geometry only: size, display cutout insets, density and the
 * world<->screen transform. All buttons and panels are laid out immediate-mode
 * by the screens themselves (see [UiKit]) — which means a button's drawn
 * rectangle and its tap rectangle can never disagree.
 *
 * The world is scaled to fit entirely on screen and centered; on wide phones
 * the leftover margins are filled with scenery and used by HUD controls.
 */
class UiLayout {
    var screenWidth = 0f
        private set
    var screenHeight = 0f
        private set
    /** Pixels per "reference dp": the UI is designed for a 360-dp-tall screen and scales with screen height. */
    var density = 2.75f
        private set
    var insets = SafeInsets.NONE
        private set
    var worldScale = 1f
        private set
    var worldOffsetX = 0f
        private set
    var worldOffsetY = 0f
        private set

    val safeLeft: Float get() = insets.left
    val safeTop: Float get() = insets.top
    val safeRight: Float get() = screenWidth - insets.right
    val safeBottom: Float get() = screenHeight - insets.bottom

    fun dp(v: Float): Float = v * density

    fun worldToScreenX(worldX: Float) = worldOffsetX + worldX * worldScale
    fun worldToScreenY(worldY: Float) = worldOffsetY + worldY * worldScale
    fun worldToScreenLength(worldLength: Float) = worldLength * worldScale
    fun screenToWorldX(screenX: Float) = (screenX - worldOffsetX) / worldScale
    fun screenToWorldY(screenY: Float) = (screenY - worldOffsetY) / worldScale

    @Synchronized
    fun recompute(width: Float, height: Float, safeInsets: SafeInsets) {
        screenWidth = width
        screenHeight = height
        density = height / 360f
        insets = safeInsets
        val safeWidth = width - safeInsets.left - safeInsets.right
        val scaleX = safeWidth / GameConfig.WORLD_WIDTH
        val scaleY = height / GameConfig.WORLD_HEIGHT
        worldScale = minOf(scaleX, scaleY)
        val scaledWidth = GameConfig.WORLD_WIDTH * worldScale
        val scaledHeight = GameConfig.WORLD_HEIGHT * worldScale
        worldOffsetX = safeInsets.left + (safeWidth - scaledWidth) / 2f
        worldOffsetY = (height - scaledHeight) / 2f
    }
}
