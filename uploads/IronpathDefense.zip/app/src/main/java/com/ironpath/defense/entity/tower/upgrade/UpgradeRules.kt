package com.ironpath.defense.entity.tower.upgrade

enum class UpgradeAvailability { AVAILABLE, LOCKED, MAXED }

/** How a path is currently being used by a tower; drives the upgrade UI labels. */
enum class PathRole { OPEN, ACTIVE, MAIN, CROSS, LOCKED }

/**
 * The crosspath rules, as pure functions over the three tier numbers.
 *
 *  - One path may climb to tier 5 (the *main* path).
 *  - A second path may climb to tier 2 (the *crosspath*).
 *  - The third path is then locked at tier 0.
 *
 * Legal end states are therefore 5-2-0, 5-0-2, 2-5-0, 0-5-2, 2-0-5, 0-2-5 (and
 * anything below them). Everything the UI shows comes from these functions, so
 * the rule lives in exactly one place.
 */
object UpgradeRules {
    const val PATH_COUNT = 3
    const val MAX_TIER = 5
    const val SECONDARY_PATH_CAP = 2

    fun isLockedByCrosspath(tiers: IntArray, path: Int): Boolean {
        val nextTier = tiers[path] + 1
        var otherPathsInUse = 0
        var otherPathPastCap = false
        for (i in tiers.indices) {
            if (i == path) continue
            if (tiers[i] > 0) otherPathsInUse++
            if (tiers[i] > SECONDARY_PATH_CAP) otherPathPastCap = true
        }
        if (tiers[path] == 0 && otherPathsInUse >= 2) return true
        if (nextTier > SECONDARY_PATH_CAP && otherPathPastCap) return true
        return false
    }

    /** Highest tier this path can still reach given the other two. */
    fun capFor(tiers: IntArray, path: Int): Int {
        var otherUsed = 0
        var otherPastCap = false
        for (i in tiers.indices) {
            if (i == path) continue
            if (tiers[i] > 0) otherUsed++
            if (tiers[i] > SECONDARY_PATH_CAP) otherPastCap = true
        }
        if (tiers[path] == 0 && otherUsed >= 2) return 0
        return if (otherPastCap) SECONDARY_PATH_CAP else MAX_TIER
    }

    fun mainPath(tiers: IntArray): Int {
        for (i in tiers.indices) if (tiers[i] > SECONDARY_PATH_CAP) return i
        return -1
    }

    fun roleOf(tiers: IntArray, path: Int): PathRole {
        val t = tiers[path]
        var used = 0
        for (i in tiers.indices) if (tiers[i] > 0) used++
        return when {
            t > SECONDARY_PATH_CAP -> PathRole.MAIN
            t > 0 -> if (mainPath(tiers) >= 0) PathRole.CROSS else PathRole.ACTIVE
            used >= 2 -> PathRole.LOCKED
            else -> PathRole.OPEN
        }
    }

    /** Compact build code like "5-2-0". */
    fun buildCode(tiers: IntArray): String = "${tiers[0]}-${tiers[1]}-${tiers[2]}"
}
