package com.ironpath.defense.economy

import com.ironpath.defense.core.GameConfig

/**
 * Owns the player's money. Every spend/earn path in the game (tower
 * purchase, upgrade, sell, kill rewards, wave-clear bonus) routes through
 * here, so this is the one place that can ever answer "can the player
 * afford X" or change how much money they have.
 */
class EconomySystem(startingMoney: Int = GameConfig.STARTING_MONEY) {

    var money = startingMoney
        private set

    /** Lifetime income this run (kills, wave rewards, refunds). Shown on the end screen. */
    var totalEarned = 0
        private set

    fun canAfford(cost: Int): Boolean = money >= cost

    /** Deducts [amount] only if affordable. Returns whether the spend happened. */
    fun spend(amount: Int): Boolean {
        if (!canAfford(amount)) return false
        money -= amount
        return true
    }

    fun earn(amount: Int) {
        money += amount
        totalEarned += amount
    }

    fun reset(startingMoney: Int = GameConfig.STARTING_MONEY) {
        money = startingMoney
        totalEarned = 0
    }
}
