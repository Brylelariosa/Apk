package com.ironpath.defense.entity.projectile

/**
 * Everything a projectile (or tower pulse) needs to resolve a hit, copied from
 * the firing tower's stats at fire time so later upgrades never retroactively
 * change shots already in flight. Mutable and pooled with its projectile.
 */
class ShotProfile {
    var damage = 0f
    var isCrit = false
    var colorArgb = 0xFFFFFFFF.toInt()
    var armorPenetration = 0f
    var splashRadius = 0f
    var slowMultiplier = 1f
    var slowDurationSeconds = 0f
    var chainCount = 0
    var chainRadius = 0f
    var chainDamageFalloff = 1f
    var burnDps = 0f
    var burnSeconds = 0f
    var burnColorArgb = 0xFFFF8A2B.toInt()
    var freezeChance = 0f
    var freezeSeconds = 0f
    var vulnerabilityBonus = 0f
    var vulnerabilitySeconds = 0f
    var bossDamageMultiplier = 1f
    var executeThreshold = 0f

    var pierce = 0
    var armorShred = 0f
    var armoredBonus = 1f
    var shieldBreak = 1f
    var burnSpreadRadius = 0f
    var deathBlastDamage = 0f
    var deathBlastRadius = 0f
    var zoneKind = 0
    var zoneDps = 0f
    var zoneRadius = 0f
    var zoneSeconds = 0f
    var zoneSlow = 1f
    var silenceSeconds = 0f
    var bounty = 0
    var clusterCount = 0
    var clusterDamageFraction = 0f
    var steamBurst = 0f
    var superconduct = 0
    var specialStun = 0f
    var isSpecial = false
    var sourceType = -1

    fun reset() {
        damage = 0f
        isCrit = false
        colorArgb = 0xFFFFFFFF.toInt()
        armorPenetration = 0f
        splashRadius = 0f
        slowMultiplier = 1f
        slowDurationSeconds = 0f
        chainCount = 0
        chainRadius = 0f
        chainDamageFalloff = 1f
        burnDps = 0f
        burnSeconds = 0f
        burnColorArgb = 0xFFFF8A2B.toInt()
        freezeChance = 0f
        freezeSeconds = 0f
        vulnerabilityBonus = 0f
        vulnerabilitySeconds = 0f
        bossDamageMultiplier = 1f
        executeThreshold = 0f
        pierce = 0
        armorShred = 0f
        armoredBonus = 1f
        shieldBreak = 1f
        burnSpreadRadius = 0f
        deathBlastDamage = 0f
        deathBlastRadius = 0f
        zoneKind = 0
        zoneDps = 0f
        zoneRadius = 0f
        zoneSeconds = 0f
        zoneSlow = 1f
        silenceSeconds = 0f
        bounty = 0
        clusterCount = 0
        clusterDamageFraction = 0f
        steamBurst = 0f
        superconduct = 0
        specialStun = 0f
        isSpecial = false
        sourceType = -1
    }
}
