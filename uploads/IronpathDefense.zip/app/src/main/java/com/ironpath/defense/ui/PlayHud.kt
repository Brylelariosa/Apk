package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.ironpath.defense.ability.AbilityType
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.engine.BannerKind
import com.ironpath.defense.engine.GameRun
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.render.ArtKit
import com.ironpath.defense.render.EnemyArt
import com.ironpath.defense.render.TowerArt
import kotlin.math.ceil
import kotlin.math.sin

/**
 * The in-game HUD, laid out for one-handed landscape play: status chips top
 * left, pause + speed top right, abilities bottom left, the build dock bottom
 * center and the start-wave button bottom right. Banners, the boss bar, the
 * next-wave preview and the tower panel appear only when relevant so the
 * battlefield stays as clear as possible.
 */
class PlayHud(private val kit: UiKit, private val layout: UiLayout) {
    private val panel = TowerPanel(kit, layout)
    private val a = RectF()
    private val b = RectF()
    private val hintCache = WrapCache()

    fun draw(c: Canvas, state: HudState, run: GameRun) {
        val m = kit.dp(8f)
        val left = layout.safeLeft + m
        val right = layout.safeRight - m
        val top = layout.safeTop + m
        val bottom = layout.safeBottom - m
        val tower = run.selectedTower
        var freeLeft = left
        var freeRight = right
        if (tower != null) {
            panel.layoutFor(tower)
            if (panel.onRight) freeRight = panel.rect.left - m else freeLeft = panel.rect.right + m
        }
        topBar(c, state, run, left, right, top)
        centerTop(c, state, run, left, right, top)
        abilities(c, run, freeLeft, bottom)
        if (run.phase == GameRun.Phase.BUILD) startButton(c, state, run, freeRight, bottom)
        if (tower == null) dock(c, run, left, right, bottom)
        if (tower != null) panel.draw(c, run, tower, state.time)
        pendingHint(c, run, left, right, top)
        banners(c, state, run)
    }

    // --- top bar ------------------------------------------------------------------
    private fun chip(c: Canvas, x: Float, y: Float, h: Float, icon: Int, text: String, color: Int): Float {
        val textW = kit.measure(text, 15f)
        val w = h * 0.95f + textW + kit.dp(10f)
        a.set(x, y, x + w, y + h)
        kit.panel(c, a, 12f, Palette.PANEL, Palette.EDGE, 1.2f)
        kit.icon(c, icon, x + h * 0.5f, y + h / 2f, h * 0.27f, color)
        kit.textMid(c, text, x + h * 0.92f, y + h / 2f, 15f, Palette.TEXT, Paint.Align.LEFT, true, true)
        return w
    }

    private fun topBar(c: Canvas, state: HudState, run: GameRun, left: Float, right: Float, top: Float) {
        val h = kit.dp(40f)
        var x = left
        val lowLives = run.lives <= run.maxLives * 0.3f
        val pulse = if (lowLives) 0.5f + 0.5f * sin(state.time * 7f) else 0f
        x += chip(c, x, top, h, UiKit.ICON_HEART, "${run.lives.coerceAtLeast(0)}/${run.maxLives}",
            if (lowLives) ArtKit.lerp(Palette.RED, 0xFFFFFFFF.toInt(), pulse) else Palette.RED) + kit.dp(6f)
        x += chip(c, x, top, h, UiKit.ICON_COIN, run.economy.money.toString(), Palette.GOLD) + kit.dp(6f)
        val waveNo = run.currentWaveNumber.coerceAtMost(run.waves.totalWaveCount)
        chip(c, x, top, h, UiKit.ICON_FLAG, "WAVE $waveNo/${run.waves.totalWaveCount}", run.nextWave.type.colorArgb)
        // pause + speed on the right
        val big = kit.dp(44f)
        a.set(right - big, top, right, top + big)
        kit.iconButton(c, a, UiId.PAUSE, UiKit.ICON_PAUSE, UiKit.SECONDARY)
        val mult = GameConfig.SPEED_MULTIPLIERS[state.speedIndex].toInt()
        a.set(right - big - kit.dp(6f) - kit.dp(62f), top, right - big - kit.dp(6f), top + big)
        kit.button(c, a, UiId.SPEED, "$mult\u00D7", if (mult > 1) UiKit.PRIMARY else UiKit.SECONDARY, true, 17f)
        if (mult > 1) {
            kit.icon(c, UiKit.ICON_CHEVRON, (a.left + a.right) / 2f, a.bottom - kit.dp(7f), kit.dp(3.5f), 0x99FFFFFF.toInt())
        }
    }

    // --- center: next-wave preview, enemy count, boss bar ---------------------------
    private fun centerTop(c: Canvas, state: HudState, run: GameRun, left: Float, right: Float, top: Float) {
        val cx = layout.screenWidth / 2f
        val boss = run.activeBoss
        if (boss != null && run.phase == GameRun.Phase.ACTIVE) {
            bossBar(c, boss, cx, top)
            return
        }
        if (run.phase == GameRun.Phase.ACTIVE) {
            val txt = "${run.waves.enemiesRemaining} enemies left"
            val w = kit.measure(txt, 13f) + kit.dp(24f)
            a.set(cx - w / 2f, top, cx + w / 2f, top + kit.dp(30f))
            kit.panel(c, a, 12f, Palette.PANEL, Palette.EDGE, 1.2f)
            kit.textMid(c, txt, cx, top + kit.dp(15f), 13f, Palette.TEXT, Paint.Align.CENTER)
            val mood = run.director.mood.label
            kit.textMid(c, "Director: $mood", cx, top + kit.dp(40f), 10f, Palette.TEXT_FAINT, Paint.Align.CENTER, false)
            return
        }
        if (run.phase != GameRun.Phase.BUILD) return
        val wave = run.nextWave
        val summary = wave.summary
        val icons = minOf(summary.size, 6)
        val iconW = kit.dp(44f)
        val title = "NEXT: ${wave.type.label}"
        val titleW = kit.measure(title, 12.5f)
        val w = maxOf(titleW + kit.dp(26f), icons * iconW + kit.dp(20f))
        val h = kit.dp(66f)
        val x0 = cx - w / 2f
        // keep clear of the status chips / buttons when the screen is narrow
        a.set(x0, top, x0 + w, top + h)
        kit.panel(c, a, 12f, Palette.PANEL, wave.type.colorArgb, 1.8f)
        kit.textMid(c, title, cx, top + kit.dp(12f), 12.5f, wave.type.colorArgb, Paint.Align.CENTER)
        val startX = cx - icons * iconW / 2f + iconW / 2f
        for (i in 0 until icons) {
            val (kind, count) = summary[i]
            val ix = startX + i * iconW
            EnemyArt.drawIcon(c, kind, ix, top + kit.dp(36f), kit.dp(24f), state.time)
            kit.textMid(c, "x$count", ix, top + kit.dp(57f), 10.5f, Palette.TEXT, Paint.Align.CENTER)
        }
        if (wave.note.isNotEmpty()) {
            val noteW = minOf(layout.safeRight - layout.safeLeft - kit.dp(40f), kit.dp(420f))
            val lines = kit.wrap(hintCache, wave.note, noteW, 10f)
            kit.textMid(c, lines[0] + if (lines.size > 1) "…" else "", cx, top + h + kit.dp(10f), 10f, Palette.CYAN, Paint.Align.CENTER, false, true)
        }
        // tapping the card could explain enemies in future; for now it is informational only
    }

    private fun bossBar(c: Canvas, boss: Enemy, cx: Float, top: Float) {
        val w = kit.dp(280f)
        val h = kit.dp(16f)
        kit.textMid(c, boss.kind.displayName.uppercase(), cx, top + kit.dp(8f), 13f, 0xFFFF7A6A.toInt(), Paint.Align.CENTER, true, true)
        a.set(cx - w / 2f, top + kit.dp(18f), cx + w / 2f, top + kit.dp(18f) + h)
        kit.bar(c, a, boss.currentHealth / boss.maxHealth, Palette.RED, Palette.HEALTH_BACK)
        if (boss.maxShield > 0f && boss.shield > 0f) {
            b.set(a.left, a.top - kit.dp(5f), a.right, a.top - kit.dp(1f))
            kit.bar(c, b, boss.shield / boss.maxShield, Palette.SHIELD, 0x66101820)
        }
        kit.panel(c, a, 8f, 0x00000000, Palette.EDGE_BRIGHT, 1.4f)
        for (i in 1..2) {
            val x = a.left + a.width() * i / 3f
            kit.stroke(c, x, a.top, x, a.bottom, 0x66FFFFFF, 1f)
        }
        if (boss.silenceTime > 0f) kit.textMid(c, "SILENCED", cx, a.bottom + kit.dp(9f), 10f, Palette.PURPLE, Paint.Align.CENTER)
        else if (boss.shield > 0f) kit.textMid(c, "SHIELDED", cx, a.bottom + kit.dp(9f), 10f, Palette.SHIELD, Paint.Align.CENTER)
    }

    // --- abilities ------------------------------------------------------------------
    private fun abilities(c: Canvas, run: GameRun, left: Float, bottom: Float) {
        val size = kit.dp(46f)
        val gap = kit.dp(6f)
        val types = AbilityType.entries
        for (i in types.indices) {
            val t = types[i]
            val y = bottom - (i + 1) * size - i * gap
            a.set(left, y, left + size, y + size)
            val ready = run.player.isReady(t)
            val armed = run.player.armed == t
            kit.hitArea(UiId.ABILITY_BASE + i, a)
            kit.panel(c, a, 12f, if (armed) 0xFF3A2A1E.toInt() else Palette.PANEL, if (armed) t.colorArgb else if (ready) Palette.EDGE_BRIGHT else Palette.EDGE, if (armed) 2.6f else 1.4f)
            if (ready) kit.glow(c, a.centerX(), a.centerY(), size * 0.62f, t.colorArgb, 0.35f)
            val icon = when (t) {
                AbilityType.STRIKE -> UiKit.ICON_BLAST
                AbilityType.FREEZE -> UiKit.ICON_SNOW
                AbilityType.OVERDRIVE -> UiKit.ICON_BOLT
            }
            kit.icon(c, icon, a.centerX(), a.centerY() - kit.dp(2f), size * 0.27f, if (ready) t.colorArgb else Palette.TEXT_FAINT)
            if (!ready) {
                val f = run.player.cooldownFraction(t)
                b.set(a.left + 1f, a.top + 1f + (a.height() - 2f) * (1f - f), a.right - 1f, a.bottom - 1f)
                kit.panel(c, b, 11f, 0x99000000.toInt(), 0, 0f)
                kit.textMid(c, run.player.secondsLeft(t).toString(), a.centerX(), a.centerY(), 14f, Palette.TEXT, Paint.Align.CENTER, true, true)
            } else {
                kit.textMid(c, t.label, a.centerX(), a.bottom - kit.dp(7f), 9f, Palette.TEXT, Paint.Align.CENTER)
            }
        }
    }

    // --- start wave ------------------------------------------------------------------
    private fun startButton(c: Canvas, state: HudState, run: GameRun, freeRight: Float, bottom: Float) {
        if (!run.waves.canStartNextWave()) return
        val w = kit.dp(128f)
        val h = kit.dp(50f)
        a.set(freeRight - w, bottom - h, freeRight, bottom)
        val pulse = 0.5f + 0.5f * sin(state.time * 4f)
        kit.glow(c, a.centerX(), a.centerY(), w * 0.62f, Palette.GREEN, 0.18f + 0.14f * pulse)
        val sub = if (run.autoStartEnabled) "auto in ${ceil(run.autoStartTimer.coerceAtLeast(0f)).toInt()}s" else null
        kit.button(c, a, UiId.START_WAVE, if (run.waves.currentWaveIndex == 0) "START" else "NEXT WAVE", UiKit.PRIMARY, true, 14.5f, sub)
        kit.icon(c, UiKit.ICON_PLAY, a.left + kit.dp(14f), a.centerY() - (if (sub != null) kit.dp(3f) else 0f), kit.dp(5f), Palette.TEXT)
    }

    // --- build dock -------------------------------------------------------------------
    private fun dock(c: Canvas, run: GameRun, left: Float, right: Float, bottom: Float) {
        val types = TowerType.entries
        val avail = layout.safeRight - layout.safeLeft - kit.dp(72f) * 2f - kit.dp(150f)
        val slotW = minOf(kit.dp(68f), (avail - kit.dp(4f) * (types.size - 1)) / types.size)
        val slotH = kit.dp(74f)
        val gap = kit.dp(4f)
        val total = types.size * slotW + (types.size - 1) * gap
        var x = layout.screenWidth / 2f - total / 2f
        val y = bottom - slotH
        a.set(x - kit.dp(6f), y - kit.dp(5f), x + total + kit.dp(6f), bottom + kit.dp(3f))
        kit.panel(c, a, 14f, 0x99090D12.toInt(), Palette.EDGE, 1f)
        for (i in types.indices) {
            val t = types[i]
            a.set(x, y, x + slotW, y + slotH)
            val unlocked = run.canBuild(t)
            val armed = run.pendingType == t
            val afford = run.economy.money >= t.baseCost
            kit.hitArea(UiId.SHOP_BASE + i, a)
            kit.panel(c, a, 10f, if (armed) 0xFF27402C.toInt() else Palette.PANEL_SOLID, if (armed) Palette.GREEN else if (unlocked) Palette.EDGE_BRIGHT else Palette.EDGE, if (armed) 2.6f else 1.3f)
            if (armed) kit.glow(c, a.centerX(), a.centerY(), slotW * 0.8f, Palette.GREEN, 0.25f)
            val iconY = a.top + slotH * 0.38f
            if (unlocked) {
                TowerArt.drawIcon(c, t, a.centerX(), iconY, slotW / 100f, 0f, -40f)
            } else {
                kit.icon(c, UiKit.ICON_LOCK, a.centerX(), iconY, slotW * 0.17f, Palette.TEXT_FAINT)
            }
            kit.textFit(c, t.shortName, a.centerX(), a.top + slotH * 0.7f, slotW - kit.dp(4f), 10.5f, if (unlocked) Palette.TEXT else Palette.TEXT_FAINT, Paint.Align.CENTER)
            if (unlocked) kit.textMid(c, "$${t.baseCost}", a.centerX(), a.top + slotH * 0.88f, 11f, if (afford) Palette.GOLD else Palette.RED, Paint.Align.CENTER)
            else kit.textMid(c, "Wave ${t.unlockWave}", a.centerX(), a.top + slotH * 0.88f, 9.5f, Palette.TEXT_FAINT, Paint.Align.CENTER, false)
            x += slotW + gap
        }
    }

    private fun pendingHint(c: Canvas, run: GameRun, left: Float, right: Float, top: Float) {
        val armedAbility = run.player.armed
        val text = when {
            armedAbility != null -> "Tap the battlefield to call the ${armedAbility.label}"
            run.pendingType != null -> "Tap a green tile to build the ${run.pendingType!!.displayName}"
            else -> return
        }
        val w = kit.measure(text, 13f) + kit.dp(28f)
        val cx = layout.screenWidth / 2f
        val y = layout.safeBottom - kit.dp(104f) - kit.dp(8f)
        a.set(cx - w / 2f, y, cx + w / 2f, y + kit.dp(30f))
        kit.panel(c, a, 14f, 0xDD0D1A12.toInt(), Palette.GREEN, 1.6f)
        kit.textMid(c, text, cx, y + kit.dp(15f), 13f, Palette.TEXT, Paint.Align.CENTER)
    }

    // --- banners & countdown -------------------------------------------------------------
    private fun banners(c: Canvas, state: HudState, run: GameRun) {
        val cx = layout.screenWidth / 2f
        var slotY = layout.screenHeight * 0.30f
        for (bn in state.banners.slots) {
            if (!bn.alive) continue
            val age = bn.age
            val inT = (age / 0.28f).coerceIn(0f, 1f)
            val outT = (bn.life / 0.45f).coerceIn(0f, 1f)
            val pop = 1f + (1f - inT) * 0.6f + (if (inT < 1f) 0f else 0.03f * sin(age * 9f))
            val alpha = inT * outT
            if (alpha <= 0.01f) continue
            val bigSz = if (bn.kind == BannerKind.WAVE || bn.kind == BannerKind.CLEAR) 34f else if (bn.kind == BannerKind.BOSS) 30f else 17f
            val subSz = if (bn.kind == BannerKind.EVENT || bn.kind == BannerKind.TOAST) 12f else 15f
            val wTitle = kit.measure(bn.title, bigSz) * pop
            val wSub = kit.measure(bn.subtitle, subSz)
            val maxW = layout.screenWidth * 0.9f
            val w = minOf(maxOf(wTitle, wSub) + kit.dp(60f), maxW)
            val h = if (bn.kind == BannerKind.EVENT || bn.kind == BannerKind.TOAST) kit.dp(54f) else kit.dp(78f)
            val col = a2(bn.colorArgb, alpha)
            c.save()
            c.translate(cx, slotY + h / 2f)
            c.scale(pop, pop)
            a.set(-w / 2f, -h / 2f, w / 2f, h / 2f)
            val boss = bn.kind == BannerKind.BOSS
            val flash = if (boss) 0.5f + 0.5f * sin(age * 12f) else 0f
            kit.panel(c, a, 14f, a2(if (boss) 0xFF3A0D10.toInt() else 0xFF0B1118.toInt(), 0.85f * alpha), a2(if (boss) ArtKit.lerp(bn.colorArgb, 0xFFFFFFFF.toInt(), flash) else bn.colorArgb, alpha), 2.2f)
            kit.textMid(c, bn.title, 0f, -h * 0.12f, bigSz, col, Paint.Align.CENTER, true, true)
            kit.textFit(c, bn.subtitle, 0f, h * 0.30f, w - kit.dp(28f), subSz, a2(Palette.TEXT, alpha), Paint.Align.CENTER, false)
            c.restore()
            slotY += h + kit.dp(8f)
        }
        if (run.phase == GameRun.Phase.COUNTDOWN) {
            val n = ceil(run.countdown.coerceAtLeast(0f)).toInt()
            if (n in 1..9) {
                val frac = run.countdown - (n - 1)
                val s = 1f + (frac.coerceIn(0f, 1f)) * 0.5f
                c.save()
                c.translate(cx, layout.screenHeight * 0.62f)
                c.scale(s, s)
                kit.textMid(c, n.toString(), 0f, 0f, 64f, a2(0xFFFFFFFF.toInt(), 0.4f + 0.6f * (1f - frac.coerceIn(0f, 1f))), Paint.Align.CENTER, true, true)
                c.restore()
            }
        }
    }

    private fun a2(color: Int, alpha: Float): Int = ArtKit.withAlpha(color, alpha.coerceIn(0f, 1f))
}
