package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.map.GameMap
import com.ironpath.defense.map.MapTheme
import kotlin.random.Random

/**
 * Produces the *base* plan for any wave on any map (before the Adaptive
 * Director tweaks it). Ironpath Valley uses its authored campaign; every
 * other map is generated deterministically from the map and wave number so a
 * replay is predictable, with a theme-flavored cast of specialists and bosses.
 * Waves differ by composition and mechanics — never just by bigger HP.
 */
object WavePlanner {
    fun base(map: GameMap, index: Int): WaveDefinition =
        if (map.id == 0 && index in 1..WaveLibrary.ALL.size) WaveLibrary.ALL[index - 1] else generate(map, index)

    private val cycle = listOf(
        WaveType.NORMAL, WaveType.FAST, WaveType.ARMORED, WaveType.SWARM,
        WaveType.MIXED, WaveType.TANK, WaveType.SPECIAL, WaveType.MIXED
    )

    private fun signature(theme: MapTheme): List<EnemyKind> = when (theme) {
        MapTheme.FOREST -> listOf(EnemyKind.SHIELDED, EnemyKind.SPLITTER)
        MapTheme.DESERT -> listOf(EnemyKind.PHANTOM, EnemyKind.FAST)
        MapTheme.SNOW -> listOf(EnemyKind.TANK, EnemyKind.SPLITTER)
        MapTheme.VOLCANO -> listOf(EnemyKind.ARMORED, EnemyKind.REGENERATOR, EnemyKind.SHIELDED)
        MapTheme.RUINS -> listOf(EnemyKind.PHANTOM, EnemyKind.HEALER)
        MapTheme.CITY -> listOf(EnemyKind.SWARM, EnemyKind.FAST, EnemyKind.SHIELDED)
        MapTheme.FACTORY -> listOf(EnemyKind.ARMORED, EnemyKind.SHIELDED, EnemyKind.HEALER)
        MapTheme.ALIEN -> listOf(EnemyKind.SPLITTER, EnemyKind.HEALER, EnemyKind.PHANTOM)
    }

    private fun bosses(theme: MapTheme): List<EnemyKind> = when (theme) {
        MapTheme.FOREST -> listOf(EnemyKind.BOSS, EnemyKind.BOSS_QUEEN)
        MapTheme.DESERT -> listOf(EnemyKind.BOSS_WRAITH, EnemyKind.BOSS)
        MapTheme.SNOW -> listOf(EnemyKind.BOSS_COLOSSUS, EnemyKind.BOSS_QUEEN)
        MapTheme.VOLCANO -> listOf(EnemyKind.BOSS_COLOSSUS, EnemyKind.BOSS)
        MapTheme.RUINS -> listOf(EnemyKind.BOSS_WRAITH, EnemyKind.BOSS_COLOSSUS)
        MapTheme.CITY -> listOf(EnemyKind.BOSS, EnemyKind.BOSS_COLOSSUS, EnemyKind.BOSS_WRAITH)
        MapTheme.FACTORY -> listOf(EnemyKind.BOSS_COLOSSUS, EnemyKind.BOSS)
        MapTheme.ALIEN -> listOf(EnemyKind.BOSS_QUEEN, EnemyKind.BOSS_WRAITH, EnemyKind.BOSS_COLOSSUS)
    }

    private val minis = listOf(EnemyKind.MINI_BRUISER, EnemyKind.MINI_COMMANDER, EnemyKind.MINI_STALKER)

    /** Earliest wave on which each special enemy may appear, so the learning curve stays gentle. */
    fun firstWave(kind: EnemyKind): Int = when (kind) {
        EnemyKind.ARMORED -> 3
        EnemyKind.REGENERATOR -> 5
        EnemyKind.TANK -> 6
        EnemyKind.SHIELDED -> 6
        EnemyKind.SPLITTER -> 8
        EnemyKind.PHANTOM -> 8
        EnemyKind.HEALER -> 9
        else -> 1
    }

    fun interval(kind: EnemyKind): Float = when (kind) {
        EnemyKind.FAST -> 0.30f
        EnemyKind.SWARM -> 0.16f
        EnemyKind.ARMORED -> 0.90f
        EnemyKind.REGENERATOR -> 1.00f
        EnemyKind.TANK -> 2.20f
        EnemyKind.SHIELDED -> 0.80f
        EnemyKind.SPLITTER -> 1.10f
        EnemyKind.HEALER -> 1.60f
        EnemyKind.PHANTOM -> 0.70f
        else -> 0.70f
    }

    private fun generate(map: GameMap, w: Int): WaveDefinition {
        val rnd = Random(map.id * 7919 + w * 104729)
        val total = map.waveCount
        val isBoss = w % 10 == 0 || w == total
        val isMini = !isBoss && w % 5 == 0
        val growth = 1f + 0.05f * w
        fun n(base: Int): Int = (base * growth).toInt().coerceAtLeast(2)
        fun ok(kind: EnemyKind, fallback: EnemyKind): EnemyKind = if (w >= firstWave(kind)) kind else fallback
        fun g(kind: EnemyKind, count: Int, delay: Float = 0f) = SpawnGroup(kind, count.coerceAtLeast(1), interval(kind), delay)

        val sig = signature(map.theme).filter { w >= firstWave(it) }
        val reward = 50 + w * 13

        if (isBoss) {
            val roster = bosses(map.theme)
            val boss = roster[((w / 10) - 1).coerceAtLeast(0) % roster.size]
            val groups = ArrayList<SpawnGroup>()
            groups.add(SpawnGroup(boss, 1, 1f, 4f))
            groups.add(g(ok(EnemyKind.ARMORED, EnemyKind.BASIC), n(8), 8f))
            groups.add(g(EnemyKind.SWARM, n(12), 12f))
            if (w == total && roster.size > 1) {
                groups.add(SpawnGroup(roster[(roster.indexOf(boss) + 1) % roster.size], 1, 1f, 20f))
            }
            return WaveDefinition(w, groups, reward * 2, true, WaveType.BOSS)
        }
        if (isMini) {
            val mini = minis[((w / 5) + map.id) % minis.size]
            val groups = listOf(
                g(EnemyKind.BASIC, n(8)),
                SpawnGroup(mini, 1, 1f, 5f),
                g(sig.firstOrNull() ?: EnemyKind.FAST, n(6), 8f)
            )
            return WaveDefinition(w, groups, (reward * 1.5f).toInt(), false, WaveType.MINIBOSS)
        }

        val type = when {
            w == 1 -> WaveType.NORMAL
            w == 2 -> WaveType.FAST
            else -> cycle[(w - 1 + map.id) % cycle.size]
        }
        val groups = ArrayList<SpawnGroup>()
        when (type) {
            WaveType.NORMAL -> {
                groups.add(g(EnemyKind.BASIC, n(9)))
                groups.add(g(ok(EnemyKind.ARMORED, EnemyKind.BASIC), n(4), 4f))
            }
            WaveType.FAST -> {
                groups.add(g(EnemyKind.FAST, n(12)))
                groups.add(g(EnemyKind.BASIC, n(6), 3f))
            }
            WaveType.SWARM -> {
                groups.add(g(EnemyKind.SWARM, n(16)))
                groups.add(g(EnemyKind.FAST, n(6), 5f))
            }
            WaveType.ARMORED -> {
                groups.add(g(ok(EnemyKind.ARMORED, EnemyKind.BASIC), n(7)))
                groups.add(g(EnemyKind.BASIC, n(6), 3f))
            }
            WaveType.TANK -> {
                groups.add(g(ok(EnemyKind.TANK, EnemyKind.ARMORED), (w / 4 + 1).coerceAtMost(7)))
                groups.add(g(ok(EnemyKind.ARMORED, EnemyKind.BASIC), n(5), 3f))
                groups.add(g(EnemyKind.BASIC, n(6), 6f))
            }
            WaveType.SPECIAL -> {
                val picks = if (sig.isEmpty()) listOf(EnemyKind.FAST) else sig
                groups.add(g(picks[rnd.nextInt(picks.size)], n(6)))
                groups.add(g(picks[rnd.nextInt(picks.size)], n(4), 4f))
                groups.add(g(EnemyKind.BASIC, n(5), 7f))
            }
            else -> {
                val pool = ArrayList<EnemyKind>()
                pool.add(EnemyKind.BASIC)
                pool.add(EnemyKind.FAST)
                pool.add(EnemyKind.SWARM)
                for (k in listOf(EnemyKind.ARMORED, EnemyKind.REGENERATOR, EnemyKind.TANK)) if (w >= firstWave(k)) pool.add(k)
                pool.addAll(sig)
                var delay = 0f
                repeat(3) {
                    val kind = pool[rnd.nextInt(pool.size)]
                    val count = if (kind == EnemyKind.TANK) (w / 5 + 1) else n(6)
                    groups.add(g(kind, count, delay))
                    delay += 3f + rnd.nextInt(3)
                }
            }
        }
        return WaveDefinition(w, groups, reward, false, type)
    }
}
