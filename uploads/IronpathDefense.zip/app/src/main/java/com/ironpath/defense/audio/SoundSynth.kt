package com.ironpath.defense.audio

import kotlin.math.exp
import kotlin.math.sin

/**
 * Tiny offline synthesizer that renders every [SoundEffect] to 16-bit mono PCM.
 * Sounds are built from a handful of primitives (pitch-swept oscillators and
 * filtered noise bursts) so there are no audio assets to ship and the whole
 * set renders in a few milliseconds.
 */
object SoundSynth {
    const val RATE = 22050
    private const val TWO_PI = 6.2831855f

    private class Rng(var s: Int) {
        fun next(): Float {
            s = s xor (s shl 13)
            s = s xor (s ushr 17)
            s = s xor (s shl 5)
            return ((s and 0xFFFF) - 32768) / 32768f
        }
    }

    /** wave: 0 sine, 1 square, 2 saw, 3 triangle. */
    private fun tone(seconds: Float, f0: Float, f1: Float, wave: Int = 0, decay: Float = 3f, vol: Float = 1f): FloatArray {
        val n = (seconds * RATE).toInt()
        val out = FloatArray(n)
        var phase = 0f
        for (i in 0 until n) {
            val k = i.toFloat() / n
            phase += TWO_PI * (f0 + (f1 - f0) * k) / RATE
            val w = when (wave) {
                1 -> if (sin(phase) >= 0f) 1f else -1f
                2 -> ((phase / TWO_PI) % 1f) * 2f - 1f
                3 -> {
                    val q = (phase / TWO_PI) % 1f
                    if (q < 0.5f) q * 4f - 1f else 3f - q * 4f
                }
                else -> sin(phase)
            }
            val attack = minOf(1f, i / 90f)
            out[i] = w * attack * exp(-decay * k * 3f) * vol
        }
        return out
    }

    /** Low-passed white noise; smaller [smooth] = darker/rumblier. */
    private fun noise(seconds: Float, decay: Float, vol: Float, smooth: Float, seed: Int = 7919): FloatArray {
        val n = (seconds * RATE).toInt()
        val out = FloatArray(n)
        val rng = Rng(seed)
        var y = 0f
        for (i in 0 until n) {
            val k = i.toFloat() / n
            y += (rng.next() - y) * smooth
            out[i] = y * exp(-decay * k * 3f) * vol
        }
        return out
    }

    private fun mix(vararg parts: FloatArray): FloatArray {
        var len = 0
        for (p in parts) if (p.size > len) len = p.size
        val out = FloatArray(len)
        for (p in parts) for (i in p.indices) out[i] += p[i]
        return out
    }

    private fun after(src: FloatArray, seconds: Float): FloatArray {
        val off = (seconds * RATE).toInt()
        val out = FloatArray(off + src.size)
        System.arraycopy(src, 0, out, off, src.size)
        return out
    }

    private fun arp(freqs: FloatArray, step: Float, len: Float, wave: Int, vol: Float): FloatArray {
        val parts = Array(freqs.size) { after(tone(len, freqs[it], freqs[it], wave, 3.2f, vol), it * step) }
        return mix(*parts)
    }

    private fun toPcm(a: FloatArray, gain: Float = 0.85f): ShortArray {
        val out = ShortArray(a.size)
        val fade = minOf(a.size, 120)
        for (i in a.indices) {
            var v = a[i] * gain
            if (i >= a.size - fade) v *= (a.size - i).toFloat() / fade
            out[i] = (v.coerceIn(-1f, 1f) * 30000f).toInt().toShort()
        }
        return out
    }

    fun render(effect: SoundEffect): ShortArray {
        val data: FloatArray = when (effect) {
            SoundEffect.SHOOT -> tone(0.08f, 700f, 300f, 1, 5f, 0.5f)
            SoundEffect.HIT -> noise(0.05f, 4f, 0.7f, 0.5f)
            SoundEffect.EXPLOSION -> mix(noise(0.5f, 2.2f, 0.9f, 0.25f), tone(0.4f, 90f, 40f, 0, 3f, 0.9f))
            SoundEffect.TOWER_PLACE -> mix(tone(0.16f, 150f, 70f, 0, 4f, 0.9f), noise(0.06f, 6f, 0.5f, 0.6f))
            SoundEffect.TOWER_UPGRADE -> arp(floatArrayOf(523f, 659f, 784f, 1047f), 0.075f, 0.16f, 3, 0.55f)
            SoundEffect.TOWER_SELL -> mix(tone(0.12f, 1300f, 1300f, 1, 5f, 0.3f), after(tone(0.22f, 1750f, 1750f, 1, 3f, 0.3f), 0.08f))
            SoundEffect.WAVE_START -> mix(tone(0.65f, 196f, 262f, 2, 1.4f, 0.4f), tone(0.65f, 294f, 392f, 0, 1.4f, 0.3f))
            SoundEffect.LIFE_LOST -> mix(tone(0.4f, 130f, 50f, 0, 3f, 0.9f), noise(0.28f, 3f, 0.6f, 0.2f))
            SoundEffect.BUTTON_TAP -> tone(0.05f, 900f, 700f, 0, 5f, 0.6f)
            SoundEffect.VICTORY -> arp(floatArrayOf(523f, 659f, 784f, 1047f, 1319f), 0.13f, 0.5f, 3, 0.5f)
            SoundEffect.GAME_OVER -> arp(floatArrayOf(392f, 349f, 311f, 247f), 0.26f, 0.55f, 3, 0.55f)
            SoundEffect.SHOOT_ARROW -> mix(tone(0.09f, 1100f, 600f, 3, 6f, 0.45f), noise(0.05f, 8f, 0.25f, 0.8f))
            SoundEffect.SHOOT_CANNON -> mix(tone(0.3f, 110f, 35f, 0, 3.5f, 0.9f), noise(0.25f, 4f, 0.7f, 0.3f))
            SoundEffect.SHOOT_FROST -> mix(tone(0.22f, 1800f, 2400f, 0, 3f, 0.3f), tone(0.22f, 2700f, 3200f, 0, 3f, 0.2f))
            SoundEffect.SHOOT_SNIPER -> mix(noise(0.1f, 7f, 0.7f, 0.9f), tone(0.28f, 800f, 120f, 1, 4f, 0.3f))
            SoundEffect.SHOOT_LIGHTNING -> mix(tone(0.16f, 300f, 1700f, 1, 3f, 0.28f), noise(0.14f, 4f, 0.5f, 0.95f))
            SoundEffect.SHOOT_FLAME -> noise(0.12f, 3f, 0.4f, 0.12f)
            SoundEffect.ENEMY_DIE -> mix(noise(0.14f, 4f, 0.5f, 0.35f), tone(0.14f, 400f, 120f, 0, 4f, 0.5f))
            SoundEffect.WAVE_CLEAR -> arp(floatArrayOf(392f, 523f, 659f, 784f), 0.09f, 0.3f, 3, 0.5f)
            SoundEffect.BOSS_WARN -> mix(
                tone(0.36f, 300f, 520f, 2, 0.8f, 0.4f),
                after(tone(0.36f, 520f, 300f, 2, 0.8f, 0.4f), 0.36f),
                after(tone(0.36f, 300f, 520f, 2, 0.8f, 0.4f), 0.72f),
                after(tone(0.36f, 520f, 300f, 2, 0.8f, 0.4f), 1.08f),
                tone(1.4f, 60f, 45f, 0, 1.2f, 0.7f)
            )
            SoundEffect.ABILITY -> mix(noise(0.5f, 2f, 0.5f, 0.3f), tone(0.5f, 200f, 1200f, 0, 2f, 0.4f))
            SoundEffect.FREEZE -> mix(tone(0.3f, 2000f, 2000f, 0, 3f, 0.3f), tone(0.3f, 2600f, 2600f, 0, 3f, 0.25f))
            SoundEffect.STEAM -> noise(0.4f, 2.5f, 0.5f, 0.5f)
            SoundEffect.FUSION -> arp(floatArrayOf(659f, 784f, 988f, 1319f, 1568f), 0.06f, 0.3f, 0, 0.5f)
            SoundEffect.ERROR -> tone(0.16f, 150f, 120f, 1, 3f, 0.5f)
            SoundEffect.COUNTDOWN -> tone(0.1f, 660f, 660f, 0, 4f, 0.6f)
            SoundEffect.SHIELD_BREAK -> mix(noise(0.2f, 5f, 0.6f, 0.8f), tone(0.25f, 1400f, 400f, 1, 4f, 0.3f))
            SoundEffect.EMP -> mix(tone(0.5f, 200f, 60f, 1, 2f, 0.5f), noise(0.4f, 2.5f, 0.5f, 0.5f))
            SoundEffect.SUMMON -> mix(tone(0.45f, 120f, 240f, 2, 2f, 0.4f), tone(0.45f, 180f, 360f, 0, 2f, 0.3f))
        }
        return toPcm(data)
    }
}
