package com.ironpath.defense.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.SystemClock
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

/**
 * Plays sound effects through a [SoundPool]. Effects come from
 * `assets/audio/<file>` when present, otherwise they are synthesized by
 * [SoundSynth] on a background thread, written once to the cache directory as
 * small WAV files and loaded like any other sample.
 *
 * Background music is optional and only plays if `assets/audio/music_loop.ogg`
 * exists ([hasMusic]); the game never fakes music.
 */
class AudioSystem(context: Context) {
    private val appContext = context.applicationContext
    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(MAX_CONCURRENT_STREAMS)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundIds = ConcurrentHashMap<SoundEffect, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet<Int>()
    private val lastPlay = LongArray(SoundEffect.entries.size)
    private var musicPlayer: MediaPlayer? = null

    @Volatile var masterVolume = 0.8f
    @Volatile var sfxVolume = 0.8f
    var musicVolume = 0.6f
        set(value) {
            field = value
            musicPlayer?.setVolume(value * masterVolume, value * masterVolume)
        }

    val hasMusic: Boolean

    init {
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) ready.add(sampleId)
        }
        hasMusic = probeMusic()
        val loader = Thread({ loadAll() }, "ironpath-sfx")
        loader.isDaemon = true
        loader.start()
    }

    private fun probeMusic(): Boolean = try {
        appContext.assets.list("audio")?.contains("music_loop.ogg") == true
    } catch (_: IOException) {
        false
    }

    private fun loadAll() {
        for (effect in SoundEffect.entries) {
            try {
                if (!loadFromAsset(effect)) loadSynth(effect)
            } catch (_: Exception) {
                // A single failed sample must never take the game down; it just stays silent.
            }
        }
    }

    private fun loadFromAsset(effect: SoundEffect): Boolean {
        val name = effect.assetFileName ?: return false
        return try {
            appContext.assets.openFd("audio/$name").use { descriptor ->
                soundIds[effect] = soundPool.load(descriptor, LOAD_PRIORITY)
            }
            true
        } catch (_: IOException) {
            false
        }
    }

    private fun loadSynth(effect: SoundEffect) {
        val file = File(appContext.cacheDir, "sfx_v${SYNTH_VERSION}_${effect.name}.wav")
        if (!file.exists() || file.length() < 64L) {
            file.writeBytes(wavBytes(SoundSynth.render(effect), SoundSynth.RATE))
        }
        soundIds[effect] = soundPool.load(file.absolutePath, LOAD_PRIORITY)
    }

    private fun wavBytes(pcm: ShortArray, sampleRate: Int): ByteArray {
        val dataLen = pcm.size * 2
        val buf = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray())
        buf.putInt(36 + dataLen)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16)
        buf.putShort(1)
        buf.putShort(1)
        buf.putInt(sampleRate)
        buf.putInt(sampleRate * 2)
        buf.putShort(2)
        buf.putShort(16)
        buf.put("data".toByteArray())
        buf.putInt(dataLen)
        for (s in pcm) buf.putShort(s)
        return buf.array()
    }

    /** Plays [effect]; [pitch] lets callers vary a sound (a little random jitter is always added). */
    fun play(effect: SoundEffect, volume: Float = 1f, pitch: Float = 1f) {
        val id = soundIds[effect] ?: return
        if (!ready.contains(id)) return
        val now = SystemClock.uptimeMillis()
        val slot = effect.ordinal
        if (now - lastPlay[slot] < effect.minGapMs) return
        val v = (volume * effect.gain * masterVolume * sfxVolume).coerceIn(0f, 1f)
        if (v <= 0.005f) return
        lastPlay[slot] = now
        val rate = (pitch * (0.94f + Random.nextFloat() * 0.12f)).coerceIn(0.5f, 2f)
        soundPool.play(id, v, v, LOAD_PRIORITY, 0, rate)
    }

    fun playMusicLoop(assetPath: String = "audio/music_loop.ogg") {
        if (!hasMusic || musicPlayer != null || musicVolume * masterVolume <= 0.005f) return
        try {
            appContext.assets.openFd(assetPath).use { descriptor ->
                musicPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
                    isLooping = true
                    setVolume(musicVolume * masterVolume, musicVolume * masterVolume)
                    prepare()
                    start()
                }
            }
        } catch (_: IOException) {
        }
    }

    fun stopMusic() {
        musicPlayer?.apply {
            stop()
            release()
        }
        musicPlayer = null
    }

    fun onPause() {
        soundPool.autoPause()
        musicPlayer?.pause()
    }

    fun onResume() {
        soundPool.autoResume()
        musicPlayer?.start()
    }

    fun release() {
        stopMusic()
        soundPool.release()
    }

    companion object {
        private const val MAX_CONCURRENT_STREAMS = 14
        private const val LOAD_PRIORITY = 1
        private const val SYNTH_VERSION = 1
    }
}
