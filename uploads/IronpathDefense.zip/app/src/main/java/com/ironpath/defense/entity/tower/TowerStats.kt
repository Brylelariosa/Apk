package com.ironpath.defense.entity.tower

import com.ironpath.defense.entity.projectile.ShotProfile

/**
 * Immutable snapshot of a tower's current numbers and behaviors, built from
 * its type's base stats plus every purchased upgrade (and cross-path perk).
 * Upgrades are pure `TowerStats -> TowerStats` functions (see `Mods`).
 *
 * Beyond raw numbers this carries *behaviors* — piercing, armor shredding,
 * burn spreading, death blasts, lingering zones, special volleys, heat ramp,
 * support auras, silence, bounty, cluster blasts — so upgrades can change how
 * a tower fights, not just how hard it hits. A default value means "off".
 */
data class TowerStats(
    val damage: Float,
    val range: Float,
    val fireRateSeconds: Float,
    val splashRadius: Float = 0f,
    val armorPenetration: Float = 0f,
    val slowMultiplier: Float = 1f,
    val slowDurationSeconds: Float = 0f,
    val chainCount: Int = 0,
    val chainRadius: Float = 0f,
    val chainDamageFalloff: Float = 1f,
    val projectilesPerShot: Int = 1,
    val critChance: Float = 0f,
    val critMultiplier: Float = 1f,
    val burnDps: Float = 0f,
    val burnSeconds: Float = 0f,
    val dotColorArgb: Int = DEFAULT_DOT_COLOR,
    val freezeChance: Float = 0f,
    val freezeSeconds: Float = 0f,
    val vulnerabilityBonus: Float = 0f,
    val vulnerabilitySeconds: Float = 0f,
    val bossDamageMultiplier: Float = 1f,
    val executeThreshold: Float = 0f,
    val pulseDamage: Float = 0f,
    val pulseIntervalSeconds: Float = 0f,
    val pulseRadius: Float = 0f,
    // --- behaviors ----------------------------------------------------------
    val pierce: Int = 0,
    val armorShred: Float = 0f,
    val armoredBonus: Float = 1f,
    val shieldBreak: Float = 1f,
    val burnSpreadRadius: Float = 0f,
    val deathBlastDamage: Float = 0f,
    val deathBlastRadius: Float = 0f,
    val zoneKind: Int = 0,
    val zoneDps: Float = 0f,
    val zoneRadius: Float = 0f,
    val zoneSeconds: Float = 0f,
    val zoneSlow: Float = 1f,
    val specialEvery: Int = 0,
    val specialExtraShots: Int = 0,
    val specialDamageMult: Float = 1f,
    val specialSplashBonus: Float = 0f,
    val specialChainBonus: Int = 0,
    val specialStunSeconds: Float = 0f,
    val rampMax: Float = 0f,
    val auraRadius: Float = 0f,
    val auraDamage: Float = 0f,
    val auraRate: Float = 0f,
    val auraRange: Float = 0f,
    val silenceSeconds: Float = 0f,
    val bounty: Int = 0,
    val clusterCount: Int = 0,
    val clusterDamageFraction: Float = 0f,
    val projectileOverride: Int = -1,
    // --- set by synergy links, never by upgrades ---------------------------
    val steamBurst: Float = 0f,
    val superconduct: Int = 0
) {
    val shotsPerSecond: Float
        get() = if (fireRateSeconds > 0f) projectilesPerShot / fireRateSeconds else 0f

    companion object {
        val DEFAULT_DOT_COLOR: Int = 0xFFFF8A2B.toInt()
    }
}

/** Copies a firing snapshot into a pooled [ShotProfile]. */
fun TowerStats.writeShot(shot: ShotProfile, damage: Float, isCrit: Boolean, colorArgb: Int) {
    shot.damage = damage
    shot.isCrit = isCrit
    shot.colorArgb = colorArgb
    shot.armorPenetration = armorPenetration
    shot.splashRadius = splashRadius
    shot.slowMultiplier = slowMultiplier
    shot.slowDurationSeconds = slowDurationSeconds
    shot.chainCount = chainCount
    shot.chainRadius = chainRadius
    shot.chainDamageFalloff = chainDamageFalloff
    shot.burnDps = burnDps
    shot.burnSeconds = burnSeconds
    shot.burnColorArgb = dotColorArgb
    shot.freezeChance = freezeChance
    shot.freezeSeconds = freezeSeconds
    shot.vulnerabilityBonus = vulnerabilityBonus
    shot.vulnerabilitySeconds = vulnerabilitySeconds
    shot.bossDamageMultiplier = bossDamageMultiplier
    shot.executeThreshold = executeThreshold
    shot.pierce = pierce
    shot.armorShred = armorShred
    shot.armoredBonus = armoredBonus
    shot.shieldBreak = shieldBreak
    shot.burnSpreadRadius = burnSpreadRadius
    shot.deathBlastDamage = deathBlastDamage
    shot.deathBlastRadius = deathBlastRadius
    shot.zoneKind = zoneKind
    shot.zoneDps = zoneDps
    shot.zoneRadius = zoneRadius
    shot.zoneSeconds = zoneSeconds
    shot.zoneSlow = zoneSlow
    shot.silenceSeconds = silenceSeconds
    shot.bounty = bounty
    shot.clusterCount = clusterCount
    shot.clusterDamageFraction = clusterDamageFraction
    shot.steamBurst = steamBurst
    shot.superconduct = superconduct
}
