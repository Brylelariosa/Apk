package com.ironpath.defense.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.GraphicsQuality
import com.ironpath.defense.engine.GameRun
import com.ironpath.defense.entity.tower.SynergyRules
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.rr
import com.ironpath.defense.render.ArtKit.withAlpha
import com.ironpath.defense.ui.HudState
import com.ironpath.defense.ui.UiLayout
import kotlin.math.sin

/**
 * Draws the battlefield. Static terrain is one cached bitmap (rebuilt only when
 * the map, screen size or graphics quality changes); everything else is drawn
 * in world units through a single transform, back to front:
 * ambient props -> gates -> placement hints -> zones -> synergy links -> towers
 * -> enemies -> projectiles -> weather -> particles -> floating numbers.
 */
class WorldRenderer(private val layout: UiLayout) {
    private val terrain = TerrainPainter()
    private val ambient = AmbientRenderer()
    private val fx = FxRenderer()
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val screenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bitmap: Bitmap? = null
    private var bitmapKey = 0L

    val previewPainter: TerrainPainter get() = terrain

    private fun terrainFor(map: MapSystem, quality: GraphicsQuality): Bitmap {
        val key = map.map.id * 1_000_003L + layout.screenWidth.toInt() * 7919L + layout.screenHeight.toInt() * 31L + quality.ordinal
        var bmp = bitmap
        if (bmp == null || key != bitmapKey) {
            bmp?.recycle()
            bmp = terrain.build(map.map, map.tileGrid, layout, quality)
            bitmap = bmp
            bitmapKey = key
        }
        return bmp!!
    }

    /** Menu background: the selected map with weather, no units. */
    fun drawBackdrop(c: Canvas, state: HudState) {
        val map = state.backdrop ?: return
        ArtKit.glowEnabled = state.quality.glow
        c.drawBitmap(terrainFor(map, state.quality), 0f, 0f, bitmapPaint)
        c.save()
        c.translate(layout.worldOffsetX, layout.worldOffsetY)
        c.scale(layout.worldScale, layout.worldScale)
        ambient.drawGround(c, map.map, null, state.time)
        ambient.drawWeather(c, map.map.theme, state.time, state.quality.ambientDensity, visX0(), visY0(), visX1(), visY1())
        c.restore()
    }

    private fun visX0() = -layout.worldOffsetX / layout.worldScale
    private fun visY0() = -layout.worldOffsetY / layout.worldScale
    private fun visX1() = (layout.screenWidth - layout.worldOffsetX) / layout.worldScale
    private fun visY1() = (layout.screenHeight - layout.worldOffsetY) / layout.worldScale

    fun drawWorld(c: Canvas, state: HudState, run: GameRun) {
        val time = state.time
        val quality = state.quality
        ArtKit.glowEnabled = quality.glow
        c.drawBitmap(terrainFor(run.mapSystem, quality), 0f, 0f, bitmapPaint)
        c.save()
        val shake = state.juice.shake
        val shx = if (shake > 0.01f) (ArtKit.hash((time * 60f).toInt() * 2) - 0.5f) * 2f * shake else 0f
        val shy = if (shake > 0.01f) (ArtKit.hash((time * 60f).toInt() * 2 + 1) - 0.5f) * 2f * shake else 0f
        c.translate(layout.worldOffsetX + shx, layout.worldOffsetY + shy)
        c.scale(layout.worldScale, layout.worldScale)

        ambient.drawGround(c, run.map, run.mechanics, time)
        ambient.drawGates(c, run.spawnPosition, run.basePosition, time, state.juice.baseFlash,
            run.lives.toFloat() / run.maxLives, quality.glow)
        if (run.pendingType != null) placementHints(c, run, time)
        fx.drawZones(c, run.zones.active, time)
        synergyLinks(c, run, time)

        val towers = run.towers.all
        for (i in 0 until towers.size) {
            val t = towers[i]
            if (t === run.selectedTower) selectionUnder(c, t, run, time)
            TowerArt.draw(c, t, t.position.x, t.position.y, 1f, time)
        }
        run.selectedTower?.let { selectionOver(c, it, time) }

        val enemies = run.enemies.active
        for (pass in 0 until 2) {
            for (i in 0 until enemies.size) {
                val e = enemies[i]
                if ((pass == 0) == e.kind.isElite) continue
                EnemyArt.draw(c, e, e.position.x, e.position.y, 1f, time)
            }
        }
        for (i in 0 until enemies.size) {
            val e = enemies[i]
            if (e.isRevealed) EnemyArt.drawHealthBar(c, e, e.position.x, e.position.y, 1f)
        }
        fx.drawProjectiles(c, run.projectiles.active, time)
        ambient.drawWeather(c, run.map.theme, time, quality.ambientDensity, visX0(), visY0(), visX1(), visY1())
        fx.drawParticles(c, state.particles, time, quality.glow)
        fx.drawTexts(c, state.particles)
        c.restore()

        ambient.drawScreenOverlay(c, layout.screenWidth, layout.screenHeight, run.mechanics, time)
        val flash = state.juice.baseFlash
        if (flash > 0.01f || run.lives <= run.maxLives * 0.25f) {
            val low = if (run.lives <= run.maxLives * 0.25f) 0.10f + 0.07f * sin(time * 5f) else 0f
            vignette(c, (flash * 0.5f + low).coerceIn(0f, 0.6f))
        }
    }

    private fun vignette(c: Canvas, alpha: Float) {
        val w = layout.screenWidth
        val h = layout.screenHeight
        val depth = minOf(w, h) * 0.18f
        screenPaint.style = Paint.Style.FILL
        for (i in 0 until 4) {
            val a = alpha * (1f - i / 4f)
            screenPaint.color = withAlpha(0xFFFF2A1A.toInt(), a)
            val o = i * depth / 4f
            c.drawRect(0f, o, w, o + depth / 4f, screenPaint)
            c.drawRect(0f, h - o - depth / 4f, w, h - o, screenPaint)
            c.drawRect(o, 0f, o + depth / 4f, h, screenPaint)
            c.drawRect(w - o - depth / 4f, 0f, w - o, h, screenPaint)
        }
    }

    private fun placementHints(c: Canvas, run: GameRun, time: Float) {
        val t = GameConfig.TILE_SIZE
        val grid = run.mapSystem.tileGrid
        val pulse = 0.5f + 0.5f * sin(time * 5f)
        for (r in 0 until GameConfig.GRID_ROWS) for (col in 0 until GameConfig.GRID_COLS) {
            if (!grid.canPlaceTower(col, r)) continue
            val high = grid.bonusAt(col, r) > 0f
            rr(c, col * t + 5f, r * t + 5f, (col + 1) * t - 5f, (r + 1) * t - 5f, 8f,
                withAlpha(if (high) 0xFFFFE066.toInt() else 0xFF58D67A.toInt(), 0.16f + 0.14f * pulse))
        }
    }

    private fun synergyLinks(c: Canvas, run: GameRun, time: Float) {
        val towers = run.towers.all
        val max2 = GameConfig.SYNERGY_LINK_DISTANCE * GameConfig.SYNERGY_LINK_DISTANCE
        for (i in 0 until towers.size) {
            val a = towers[i]
            for (j in i + 1 until towers.size) {
                val b = towers[j]
                if (a.position.distanceSquaredTo(b.position) > max2) continue
                val id = SynergyRules.between(a.type, b.type)
                if (id == SynergyRules.NONE) continue
                val col = SynergyRules.color(id)
                ln(c, a.position.x, a.position.y, b.position.x, b.position.y, 2.2f, withAlpha(col, 0.35f))
                val k = (time * 0.8f + i * 0.3f) % 1f
                circ(c, a.position.x + (b.position.x - a.position.x) * k, a.position.y + (b.position.y - a.position.y) * k, 3.2f, withAlpha(col, 0.95f))
                val k2 = 1f - k
                circ(c, a.position.x + (b.position.x - a.position.x) * k2, a.position.y + (b.position.y - a.position.y) * k2, 2.2f, withAlpha(col, 0.7f))
            }
        }
    }

    private fun selectionUnder(c: Canvas, t: Tower, run: GameRun, time: Float) {
        val range = t.effective.range * run.modifiers.towerRangeMult
        val col = t.accentColorArgb
        circ(c, t.position.x, t.position.y, range, withAlpha(col, 0.09f))
        ring(c, t.position.x, t.position.y, range, 2.6f, withAlpha(col, 0.8f))
        val aura = t.stats.auraRadius
        if (aura > 0f) for (k in 0 until 28) ArtKit.arc(c, t.position.x, t.position.y, aura, k * 12.857f + time * 14f, 6f, 2.2f, withAlpha(0xFF5DD6FF.toInt(), 0.75f))
    }

    private fun selectionOver(c: Canvas, t: Tower, time: Float) {
        val pulse = 3f + 2f * sin(time * 6f)
        val s = 31f + pulse
        val x = t.position.x
        val y = t.position.y
        val col = 0xFFFFFFFF.toInt()
        val l = 11f
        ln(c, x - s, y - s, x - s + l, y - s, 3f, col); ln(c, x - s, y - s, x - s, y - s + l, 3f, col)
        ln(c, x + s, y - s, x + s - l, y - s, 3f, col); ln(c, x + s, y - s, x + s, y - s + l, 3f, col)
        ln(c, x - s, y + s, x - s + l, y + s, 3f, col); ln(c, x - s, y + s, x - s, y + s - l, 3f, col)
        ln(c, x + s, y + s, x + s - l, y + s, 3f, col); ln(c, x + s, y + s, x + s, y + s - l, 3f, col)
    }
}
