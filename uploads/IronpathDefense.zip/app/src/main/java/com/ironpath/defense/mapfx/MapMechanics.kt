package com.ironpath.defense.mapfx

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.Fx
import com.ironpath.defense.core.RunModifiers
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemySystem
import com.ironpath.defense.entity.zone.ZoneKind
import com.ironpath.defense.entity.zone.ZoneSystem
import com.ironpath.defense.map.GameMap
import com.ironpath.defense.map.MapMechanic
import com.ironpath.defense.map.MapSystem
import kotlin.random.Random

/**
 * Runs the rule that gives each map its own gameplay identity:
 *
 *  - Sandstorm (Dunes): telegraphed storms shrink every tower's range.
 *  - Black Ice (Frozen Pass): enemies slide faster over icy stretches.
 *  - Lava Surge (Caldera): lava floods part of the road — burns enemies, jams nearby towers.
 *  - Rune Pedestals (Ruins): player-triggered stun/damage bursts with their own recharge.
 *  - Grid Surge (City): a pylon at a time overclocks every tower in its field.
 *  - Active Machinery (Gearworks): hydraulic presses slam the line; conveyors surge.
 *  - Spore Blooms (Alien): drifting clouds that heal enemies standing in them.
 *
 * Scripted events only start while a wave is running and are always
 * telegraphed (warning text, ring, and a delay) so nothing is unfair.
 */
class MapMechanics(
    private val map: GameMap,
    private val mapSystem: MapSystem,
    private val zones: ZoneSystem,
    private val enemies: EnemySystem,
    private val collision: CollisionSystem,
    private val modifiers: RunModifiers,
    private val feedback: CombatFeedback
) {
    /** Short banner text for the HUD ("" when nothing is happening). */
    var statusText = ""
        private set
    var statusColor = 0xFFFFFFFF.toInt()
        private set

    /** 0..1 intensity of the map-wide weather overlay (sandstorm). */
    var weather = 0f
        private set

    /** Which pylon is charging/active (-1 none) and how charged it is (0..1). */
    var activePylon = -1
        private set
    var pylonCharge = 0f
        private set

    var waveNumber = 1
    val runeCooldown = FloatArray(map.specialTiles.size)
    val pressPhase = FloatArray(map.specialTiles.size)

    private val pressTimer = FloatArray(map.specialTiles.size) { 3f + it * 2.4f }
    private val scratch = ArrayList<Enemy>(32)
    private val tmp = Vector2()
    private var nextEvent = 16f
    private var phase = 0
    private var phaseTimer = 0f
    private var statusTimer = 0f
    private var pylonCursor = 0

    val runeCount: Int get() = if (map.mechanic == MapMechanic.RUNES) map.specialTiles.size else 0

    /** Path segments that [EnemySystem.slickMultiplier] applies to. */
    fun buildSlickArray(segmentCount: Int): BooleanArray {
        val arr = BooleanArray(segmentCount)
        for (s in map.slickSegments) if (s in 0 until segmentCount) arr[s] = true
        return arr
    }

    fun reset() {
        phase = 0
        phaseTimer = 0f
        nextEvent = 16f
        weather = 0f
        activePylon = -1
        pylonCharge = 0f
        statusText = ""
        statusTimer = 0f
        modifiers.towerRangeMult = 1f
        enemies.slickMultiplier = if (map.mechanic == MapMechanic.ICE) ICE_SPEEDUP else 1f
        runeCooldown.fill(0f)
    }

    fun update(dt: Float, waveActive: Boolean) {
        if (statusTimer > 0f) {
            statusTimer -= dt
            if (statusTimer <= 0f) statusText = ""
        }
        when (map.mechanic) {
            MapMechanic.SANDSTORM -> updateSandstorm(dt, waveActive)
            MapMechanic.ICE -> enemies.slickMultiplier = ICE_SPEEDUP
            MapMechanic.LAVA -> updateHazardSpawner(dt, waveActive, ZoneKind.LAVA)
            MapMechanic.RUNES -> {
                for (i in runeCooldown.indices) if (runeCooldown[i] > 0f) runeCooldown[i] -= dt
            }
            MapMechanic.GRID_SURGE -> updateSurge(dt, waveActive)
            MapMechanic.FACTORY -> updateFactory(dt, waveActive)
            MapMechanic.SPORES -> updateHazardSpawner(dt, waveActive, ZoneKind.SPORE)
            MapMechanic.NONE -> {}
        }
    }

    private fun setStatus(text: String, color: Int, seconds: Float) {
        statusText = text
        statusColor = color
        statusTimer = seconds
    }

    private fun approach(value: Float, target: Float, step: Float): Float =
        if (value < target) minOf(target, value + step) else maxOf(target, value - step)

    // --- Dunes ----------------------------------------------------------------
    private fun updateSandstorm(dt: Float, waveActive: Boolean) {
        when (phase) {
            0 -> {
                weather = approach(weather, 0f, dt * 0.8f)
                modifiers.towerRangeMult = 1f
                if (waveActive) {
                    nextEvent -= dt
                    if (nextEvent <= 0f) {
                        phase = 1
                        phaseTimer = 3f
                        setStatus("SANDSTORM INCOMING", STORM_COLOR, 3f)
                        feedback.onFx(Fx.STORM_WARN, 640f, 352f, 260f, STORM_COLOR)
                    }
                }
            }
            1 -> {
                phaseTimer -= dt
                weather = approach(weather, 0.4f, dt * 0.5f)
                if (phaseTimer <= 0f) {
                    phase = 2
                    phaseTimer = 9f
                    setStatus("SANDSTORM: TOWER RANGE -28%", STORM_COLOR, 9f)
                }
            }
            else -> {
                phaseTimer -= dt
                weather = approach(weather, 1f, dt * 1.2f)
                modifiers.towerRangeMult = 0.72f
                if (phaseTimer <= 0f) {
                    phase = 0
                    nextEvent = 22f + Random.nextFloat() * 12f
                    modifiers.towerRangeMult = 1f
                }
            }
        }
    }

    // --- Caldera (lava) and Xenon Reach (spores): same pattern, different zone ---
    private fun updateHazardSpawner(dt: Float, waveActive: Boolean, kind: ZoneKind) {
        if (!waveActive) return
        nextEvent -= dt
        if (nextEvent > 0f) return
        nextEvent = 15f + Random.nextFloat() * 8f
        val path = mapSystem.pathSystem
        path.positionAt(path.totalLength * (0.12f + Random.nextFloat() * 0.72f), 0, tmp)
        if (kind == ZoneKind.LAVA) {
            val z = zones.spawn(ZoneKind.LAVA, tmp.x, tmp.y, 74f, 6f, 2.8f)
            z.enemyPctDps = 0.085f
            z.jamTowers = true
            setStatus("LAVA SURGE! Towers near the flow will be scorched.", kind.colorArgb, 5f)
            feedback.onFx(Fx.LAVA_WARN, tmp.x, tmp.y, 74f, kind.colorArgb)
        } else {
            val z = zones.spawn(ZoneKind.SPORE, tmp.x, tmp.y, 88f, 6.5f, 2.2f)
            z.enemyHealPct = 0.05f
            setStatus("SPORE BLOOM: enemies heal inside the cloud.", kind.colorArgb, 5f)
            feedback.onFx(Fx.LAVA_WARN, tmp.x, tmp.y, 88f, kind.colorArgb)
        }
    }

    // --- Neon Quarter ---------------------------------------------------------
    private fun updateSurge(dt: Float, waveActive: Boolean) {
        val n = map.specialTiles.size
        if (n == 0) return
        when (phase) {
            0 -> {
                activePylon = -1
                pylonCharge = 0f
                if (waveActive) {
                    nextEvent -= dt
                    if (nextEvent <= 0f) {
                        activePylon = pylonCursor % n
                        phase = 1
                        phaseTimer = 2f
                        setStatus("GRID SURGE CHARGING", SURGE_COLOR, 2f)
                    }
                }
            }
            1 -> {
                phaseTimer -= dt
                pylonCharge = (1f - phaseTimer / 2f).coerceIn(0f, 1f)
                if (phaseTimer <= 0f) {
                    phase = 2
                    phaseTimer = 10f
                    val (c, r) = map.specialTiles[activePylon]
                    val center = map.tileCenter(c, r)
                    val z = zones.spawn(ZoneKind.SURGE, center.x, center.y, 140f, 10f)
                    z.towerRate = 0.35f
                    setStatus("GRID SURGE: +35% fire rate near the pylon", SURGE_COLOR, 10f)
                    feedback.onFx(Fx.SURGE, center.x, center.y, 140f, SURGE_COLOR)
                }
            }
            else -> {
                phaseTimer -= dt
                pylonCharge = 1f
                if (phaseTimer <= 0f) {
                    phase = 0
                    pylonCursor++
                    nextEvent = 5f + Random.nextFloat() * 4f
                }
            }
        }
    }

    // --- Gearworks ------------------------------------------------------------
    private fun updateFactory(dt: Float, waveActive: Boolean) {
        for (i in pressTimer.indices) {
            pressTimer[i] -= dt
            val t = pressTimer[i]
            val since = PRESS_PERIOD - t
            pressPhase[i] = if (t > 1.2f) {
                if (since < 0.5f) 1f - since / 0.5f else 0f
            } else {
                1f - t.coerceAtLeast(0f) / 1.2f
            }
            if (t <= 0f) {
                slam(i, waveActive)
                pressTimer[i] = PRESS_PERIOD
            }
        }
        when (phase) {
            0 -> {
                enemies.slickMultiplier = 1f
                if (waveActive) {
                    nextEvent -= dt
                    if (nextEvent <= 0f) {
                        phase = 1
                        phaseTimer = 2f
                        setStatus("CONVEYOR SURGE INCOMING", FACTORY_COLOR, 2f)
                    }
                }
            }
            1 -> {
                phaseTimer -= dt
                if (phaseTimer <= 0f) {
                    phase = 2
                    phaseTimer = 6f
                    setStatus("CONVEYORS SURGING: enemies move 35% faster on belts", FACTORY_COLOR, 6f)
                }
            }
            else -> {
                phaseTimer -= dt
                enemies.slickMultiplier = ICE_SPEEDUP
                if (phaseTimer <= 0f) {
                    phase = 0
                    nextEvent = 14f + Random.nextFloat() * 6f
                    enemies.slickMultiplier = 1f
                }
            }
        }
    }

    private fun slam(index: Int, waveActive: Boolean) {
        val (c, r) = map.specialTiles[index]
        val center = map.tileCenter(c, r)
        collision.queryRadiusInto(center, PRESS_RADIUS, scratch)
        if (scratch.isEmpty() && !waveActive) return
        for (i in 0 until scratch.size) {
            val e = scratch[i]
            e.takeTrueDamage(35f + 5f * waveNumber)
            e.timeSinceLastHit = 0f
            e.applyStun(0.7f)
        }
        feedback.onFx(Fx.PRESS, center.x, center.y, PRESS_RADIUS, FACTORY_COLOR)
    }

    // --- Sunken Ruins ---------------------------------------------------------
    /** Returns true if the tap landed on a rune pedestal (whether or not it was ready). */
    fun tryActivateRune(worldX: Float, worldY: Float): Boolean {
        if (map.mechanic != MapMechanic.RUNES) return false
        for (i in map.specialTiles.indices) {
            val (c, r) = map.specialTiles[i]
            val center = map.tileCenter(c, r)
            val dx = center.x - worldX
            val dy = center.y - worldY
            if (dx * dx + dy * dy > RUNE_TAP_RADIUS * RUNE_TAP_RADIUS) continue
            if (runeCooldown[i] > 0f) return true
            runeCooldown[i] = RUNE_COOLDOWN
            collision.queryRadiusInto(center, RUNE_RADIUS, scratch)
            val damage = 150f + 9f * waveNumber
            for (k in 0 until scratch.size) {
                val e = scratch[k]
                e.takeTrueDamage(damage)
                e.timeSinceLastHit = 0f
                e.applyStun(1.4f)
                e.hitFlash = 0.15f
            }
            feedback.onFx(Fx.RUNE, center.x, center.y, RUNE_RADIUS, RUNE_COLOR)
            return true
        }
        return false
    }

    companion object {
        const val ICE_SPEEDUP = 1.35f
        const val PRESS_PERIOD = 7.5f
        const val PRESS_RADIUS = 52f
        const val RUNE_RADIUS = 135f
        const val RUNE_COOLDOWN = 26f
        private const val RUNE_TAP_RADIUS = 46f
        private val STORM_COLOR: Int = 0xFFFFC46B.toInt()
        private val SURGE_COLOR: Int = 0xFF58D6FF.toInt()
        private val FACTORY_COLOR: Int = 0xFFFFB02E.toInt()
        private val RUNE_COLOR: Int = 0xFF7CF2D0.toInt()
    }
}
