package com.ironpath.defense.ui

/** A few fixed slots for the big animated banners ("WAVE 12", "BOSS INCOMING", ...). No allocation after startup. */
class BannerSystem {
    class Banner {
        var kind = 0
        var title = ""
        var subtitle = ""
        var colorArgb = 0
        var life = 0f
        var total = 1f
        var alive = false
        val age: Float get() = total - life
    }

    val slots = Array(SLOT_COUNT) { Banner() }

    fun push(kind: Int, title: String, subtitle: String, colorArgb: Int, seconds: Float) {
        var target: Banner? = null
        for (b in slots) if (!b.alive) {
            target = b
            break
        }
        if (target == null) {
            target = slots[0]
            for (b in slots) if (b.life < target!!.life) target = b
        }
        val t = target!!
        t.kind = kind
        t.title = title
        t.subtitle = subtitle
        t.colorArgb = colorArgb
        t.life = seconds
        t.total = seconds
        t.alive = true
    }

    fun update(dt: Float) {
        for (b in slots) {
            if (!b.alive) continue
            b.life -= dt
            if (b.life <= 0f) b.alive = false
        }
    }

    fun clear() {
        for (b in slots) b.alive = false
    }

    private companion object {
        const val SLOT_COUNT = 4
    }
}
