package com.ironpath.defense.engine

/**
 * "Game feel" values the renderer reads every frame: camera shake, the red
 * base-damage flash and a general screen pulse. Systems add to them; they
 * decay on their own. Screen shake can be turned off in Settings.
 */
class Juice {
    var shake = 0f
        private set
    var baseFlash = 0f
    var pulse = 0f
    var shakeEnabled = true

    fun addShake(amount: Float) {
        if (!shakeEnabled) return
        shake = (shake + amount).coerceAtMost(MAX_SHAKE)
    }

    fun update(dt: Float) {
        shake = (shake - dt * 28f).coerceAtLeast(0f)
        baseFlash = (baseFlash - dt * 1.6f).coerceAtLeast(0f)
        pulse = (pulse - dt * 2.5f).coerceAtLeast(0f)
    }

    fun reset() {
        shake = 0f
        baseFlash = 0f
        pulse = 0f
    }

    private companion object {
        const val MAX_SHAKE = 14f
    }
}
