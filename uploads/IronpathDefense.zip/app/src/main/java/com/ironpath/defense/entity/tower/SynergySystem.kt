package com.ironpath.defense.entity.tower

import com.ironpath.defense.core.GameConfig

/**
 * The game's signature mechanic: **tower synergy**. Towers built close
 * together (within [GameConfig.SYNERGY_LINK_DISTANCE]) link according to
 * their elements, and linked towers fight differently — placement matters.
 *
 *  - Fire + Ice      -> Steam Burst: burning *and* chilled enemies flash into scalding steam.
 *  - Ice + Electric  -> Superconduct: lightning gains chain links on chilled targets; frost lasts longer.
 *  - Fire + Kinetic  -> Incendiary Rounds: arrows/shells/rounds ignite their targets.
 *  - Ice + Kinetic   -> Frostbite Rounds: physical shots chill their targets.
 *
 * Separately, towers with a support aura (the Ranger's Tactical path) buff
 * every tower in its radius: Support + Damage -> Enhanced Attack.
 */
object SynergyRules {
    const val NONE = 0
    const val STEAM = 1
    const val SUPERCONDUCT = 2
    const val INCENDIARY = 3
    const val FROSTBITE = 4

    fun between(a: TowerType, b: TowerType): Int {
        val ea = a.element
        val eb = b.element
        return when {
            isPair(ea, eb, TowerElement.FIRE, TowerElement.ICE) -> STEAM
            isPair(ea, eb, TowerElement.ICE, TowerElement.ELECTRIC) -> SUPERCONDUCT
            isPair(ea, eb, TowerElement.FIRE, TowerElement.KINETIC) -> INCENDIARY
            isPair(ea, eb, TowerElement.ICE, TowerElement.KINETIC) -> FROSTBITE
            else -> NONE
        }
    }

    private fun isPair(a: TowerElement, b: TowerElement, x: TowerElement, y: TowerElement): Boolean =
        (a == x && b == y) || (a == y && b == x)

    fun name(id: Int): String = when (id) {
        STEAM -> "Steam Burst"
        SUPERCONDUCT -> "Superconduct"
        INCENDIARY -> "Incendiary Rounds"
        FROSTBITE -> "Frostbite Rounds"
        else -> ""
    }

    fun description(id: Int): String = when (id) {
        STEAM -> "Burning + chilled enemies erupt in steam."
        SUPERCONDUCT -> "Lightning chains further through chilled foes."
        INCENDIARY -> "Shots set enemies on fire."
        FROSTBITE -> "Shots chill enemies."
        else -> ""
    }

    fun color(id: Int): Int = when (id) {
        STEAM -> 0xFFE8F4FF.toInt()
        SUPERCONDUCT -> 0xFF8FD8FF.toInt()
        INCENDIARY -> 0xFFFF9A3C.toInt()
        FROSTBITE -> 0xFFA6EDFF.toInt()
        else -> 0
    }
}

class SynergySystem {
    /** Recomputes every tower's links and buffs. Call whenever towers are placed, sold or upgraded. */
    fun refresh(towers: List<Tower>) {
        for (i in 0 until towers.size) towers[i].clearSynergy()
        val link2 = GameConfig.SYNERGY_LINK_DISTANCE * GameConfig.SYNERGY_LINK_DISTANCE
        for (i in 0 until towers.size) {
            val a = towers[i]
            for (j in i + 1 until towers.size) {
                val b = towers[j]
                if (a.position.distanceSquaredTo(b.position) <= link2) link(a, b)
            }
        }
        for (i in 0 until towers.size) {
            val src = towers[i]
            val s = src.stats
            if (s.auraRadius <= 0f) continue
            val r2 = s.auraRadius * s.auraRadius
            for (j in 0 until towers.size) {
                if (j == i) continue
                val t = towers[j]
                if (src.position.distanceSquaredTo(t.position) > r2) continue
                if (s.auraDamage > t.buffDamage) t.buffDamage = s.auraDamage
                if (s.auraRate > t.buffRate) t.buffRate = s.auraRate
                if (s.auraRange > t.buffRange) t.buffRange = s.auraRange
                if (s.auraDamage + s.auraRate + s.auraRange > 0f) t.addSynergy("Command Aura")
            }
        }
        for (i in 0 until towers.size) towers[i].refreshEffective()
    }

    private fun link(a: Tower, b: Tower) {
        val id = SynergyRules.between(a.type, b.type)
        if (id == SynergyRules.NONE) return
        when (id) {
            SynergyRules.STEAM -> {
                a.steamLinked = true
                b.steamLinked = true
            }
            SynergyRules.SUPERCONDUCT -> {
                a.conductive = true
                b.conductive = true
            }
            SynergyRules.INCENDIARY -> {
                if (a.type.element == TowerElement.KINETIC) a.incendiary = true else b.incendiary = true
            }
            SynergyRules.FROSTBITE -> {
                if (a.type.element == TowerElement.KINETIC) a.frostbite = true else b.frostbite = true
            }
        }
        val name = SynergyRules.name(id)
        a.addSynergy(name)
        b.addSynergy(name)
    }
}
