package com.ironpath.defense.entity.tower.upgrade

import com.ironpath.defense.entity.projectile.ProjectileType

/**
 * Small, composable stat modifiers: the vocabulary upgrades are written in.
 * Multipliers multiply, "add" values add, and behavior flags take the stronger
 * of the old and new value so stacking tiers never weakens a tower.
 */
object Mods {
    fun damage(mult: Float): StatModifier = { it.copy(damage = it.damage * mult, pulseDamage = it.pulseDamage) }
    fun range(mult: Float): StatModifier = { it.copy(range = it.range * mult) }
    fun cooldown(mult: Float): StatModifier = { it.copy(fireRateSeconds = it.fireRateSeconds * mult) }
    fun splash(add: Float): StatModifier = { it.copy(splashRadius = it.splashRadius + add) }
    fun armorPen(add: Float): StatModifier = { it.copy(armorPenetration = it.armorPenetration + add) }

    fun slow(multiplier: Float, seconds: Float): StatModifier = {
        it.copy(
            slowMultiplier = minOf(it.slowMultiplier, multiplier),
            slowDurationSeconds = maxOf(it.slowDurationSeconds, seconds)
        )
    }

    fun chain(addLinks: Int, addReach: Float, minFalloff: Float): StatModifier = {
        it.copy(
            chainCount = it.chainCount + addLinks,
            chainRadius = it.chainRadius + addReach,
            chainDamageFalloff = maxOf(it.chainDamageFalloff, minFalloff)
        )
    }

    fun multishot(add: Int): StatModifier = { it.copy(projectilesPerShot = it.projectilesPerShot + add) }

    fun crit(chance: Float, multiplier: Float): StatModifier = {
        it.copy(critChance = maxOf(it.critChance, chance), critMultiplier = maxOf(it.critMultiplier, multiplier))
    }

    fun burn(dps: Float, seconds: Float): StatModifier = {
        it.copy(burnDps = maxOf(it.burnDps, dps), burnSeconds = maxOf(it.burnSeconds, seconds))
    }

    fun dotColor(colorArgb: Int): StatModifier = { it.copy(dotColorArgb = colorArgb) }

    fun freeze(chance: Float, seconds: Float): StatModifier = {
        it.copy(freezeChance = maxOf(it.freezeChance, chance), freezeSeconds = maxOf(it.freezeSeconds, seconds))
    }

    fun mark(bonus: Float, seconds: Float): StatModifier = {
        it.copy(
            vulnerabilityBonus = maxOf(it.vulnerabilityBonus, bonus),
            vulnerabilitySeconds = maxOf(it.vulnerabilitySeconds, seconds)
        )
    }

    fun bossDamage(mult: Float): StatModifier = { it.copy(bossDamageMultiplier = it.bossDamageMultiplier * mult) }
    fun execute(threshold: Float): StatModifier = { it.copy(executeThreshold = maxOf(it.executeThreshold, threshold)) }

    fun pulse(damage: Float, intervalSeconds: Float, radius: Float): StatModifier = {
        val interval = if (it.pulseIntervalSeconds > 0f) minOf(it.pulseIntervalSeconds, intervalSeconds) else intervalSeconds
        it.copy(
            pulseDamage = maxOf(it.pulseDamage, damage),
            pulseIntervalSeconds = interval,
            pulseRadius = maxOf(it.pulseRadius, radius)
        )
    }

    // --- behaviors --------------------------------------------------------
    fun pierce(add: Int): StatModifier = { it.copy(pierce = (it.pierce + add).coerceAtMost(15)) }
    fun shred(fractionPerHit: Float): StatModifier = { it.copy(armorShred = maxOf(it.armorShred, fractionPerHit)) }
    fun armoredBonus(mult: Float): StatModifier = { it.copy(armoredBonus = it.armoredBonus * mult) }
    fun shieldBreak(mult: Float): StatModifier = { it.copy(shieldBreak = it.shieldBreak * mult) }
    fun burnSpread(radius: Float): StatModifier = { it.copy(burnSpreadRadius = maxOf(it.burnSpreadRadius, radius)) }

    fun deathBlast(damage: Float, radius: Float): StatModifier = {
        it.copy(deathBlastDamage = maxOf(it.deathBlastDamage, damage), deathBlastRadius = maxOf(it.deathBlastRadius, radius))
    }

    fun zone(kindId: Int, dps: Float, radius: Float, seconds: Float, slow: Float = 1f): StatModifier = {
        it.copy(zoneKind = kindId, zoneDps = maxOf(it.zoneDps, dps), zoneRadius = maxOf(it.zoneRadius, radius),
            zoneSeconds = maxOf(it.zoneSeconds, seconds), zoneSlow = minOf(it.zoneSlow, slow))
    }

    /** Every [every]-th volley is "special": extra shots, a damage multiplier, bigger blast, extra chain links, a stun. */
    fun special(every: Int, extraShots: Int, damageMult: Float, splashBonus: Float, chainBonus: Int = 0, stun: Float = 0f): StatModifier = {
        val newEvery = if (it.specialEvery > 0) minOf(it.specialEvery, every) else every
        it.copy(
            specialEvery = newEvery,
            specialExtraShots = maxOf(it.specialExtraShots, extraShots),
            specialDamageMult = maxOf(it.specialDamageMult, damageMult),
            specialSplashBonus = maxOf(it.specialSplashBonus, splashBonus),
            specialChainBonus = maxOf(it.specialChainBonus, chainBonus),
            specialStunSeconds = maxOf(it.specialStunSeconds, stun)
        )
    }

    fun ramp(maxBonus: Float): StatModifier = { it.copy(rampMax = maxOf(it.rampMax, maxBonus)) }

    fun aura(radius: Float, damage: Float, rate: Float, rangeBonus: Float): StatModifier = {
        it.copy(
            auraRadius = maxOf(it.auraRadius, radius),
            auraDamage = maxOf(it.auraDamage, damage),
            auraRate = maxOf(it.auraRate, rate),
            auraRange = maxOf(it.auraRange, rangeBonus)
        )
    }

    fun silence(seconds: Float): StatModifier = { it.copy(silenceSeconds = maxOf(it.silenceSeconds, seconds)) }
    fun bounty(add: Int): StatModifier = { it.copy(bounty = it.bounty + add) }

    fun cluster(count: Int, fraction: Float): StatModifier = {
        it.copy(clusterCount = maxOf(it.clusterCount, count), clusterDamageFraction = maxOf(it.clusterDamageFraction, fraction))
    }

    fun projectile(type: ProjectileType): StatModifier = { it.copy(projectileOverride = type.ordinal) }
}
