package com.ironpath.defense.combat

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.projectile.ShotProfile
import kotlin.random.Random

/**
 * The single place where "a shot connected with an enemy" turns into damage
 * and status effects. Projectiles, chains, pulses and splash all funnel
 * through [apply], so adding a new effect means touching exactly one function.
 */
class HitResolver(
    private val collision: CollisionSystem,
    private val feedback: CombatFeedback
) {
    private val steamScratch = ArrayList<Enemy>(32)

    fun apply(enemy: Enemy, shot: ShotProfile, damage: Float): Float {
        var raw = damage
        val elite = enemy.kind.isElite
        if (elite) raw *= shot.bossDamageMultiplier
        if (enemy.armor > 0f) raw *= shot.armoredBonus
        if (enemy.shield > 0f) raw *= shot.shieldBreak
        var dealt = enemy.applyDamage(raw, shot.armorPenetration)
        enemy.lastHitSourceType = shot.sourceType

        if (shot.armorShred > 0f) enemy.shredArmor(shot.armorShred)
        if (shot.executeThreshold > 0f && !elite && enemy.currentHealth > 0f &&
            enemy.currentHealth <= enemy.maxHealth * shot.executeThreshold
        ) {
            dealt += enemy.currentHealth
            enemy.currentHealth = 0f
        }
        if (shot.slowDurationSeconds > 0f) enemy.applySlow(shot.slowMultiplier, shot.slowDurationSeconds)
        if (shot.burnDps > 0f && shot.burnSeconds > 0f) enemy.applyBurn(shot.burnDps, shot.burnSeconds, shot.burnColorArgb)
        if (shot.vulnerabilityBonus > 0f && shot.vulnerabilitySeconds > 0f) {
            enemy.applyVulnerability(shot.vulnerabilityBonus, shot.vulnerabilitySeconds)
        }
        if (shot.freezeChance > 0f && shot.freezeSeconds > 0f && Random.nextFloat() < shot.freezeChance) {
            enemy.applyStun(shot.freezeSeconds)
        }
        if (shot.specialStun > 0f) enemy.applyStun(shot.specialStun)
        if (shot.silenceSeconds > enemy.silenceTime) {
            enemy.silenceTime = shot.silenceSeconds
        }
        if (shot.burnSpreadRadius > enemy.burnSpreadRadius && enemy.isBurning) enemy.burnSpreadRadius = shot.burnSpreadRadius
        if (shot.deathBlastDamage > enemy.deathBlastDamage) {
            enemy.deathBlastDamage = shot.deathBlastDamage
            enemy.deathBlastRadius = shot.deathBlastRadius
        }
        if (shot.bounty > enemy.bountyBonus) enemy.bountyBonus = shot.bounty
        if (shot.steamBurst > 0f && enemy.isBurning && enemy.isSlowed && enemy.steamCooldown <= 0f) {
            steamBurst(enemy, shot)
        }
        return dealt
    }

    /** Fire + Frost synergy: an enemy that is both burning and chilled flashes into scalding steam. */
    private fun steamBurst(center: Enemy, shot: ShotProfile) {
        center.steamCooldown = 1.4f
        feedback.onFx(Fx.STEAM, center.position.x, center.position.y, GameConfig.STEAM_RADIUS, 0xFFE8F4FF.toInt())
        collision.queryRadiusInto(center.position, GameConfig.STEAM_RADIUS, steamScratch)
        for (i in 0 until steamScratch.size) {
            val o = steamScratch[i]
            o.takeTrueDamage(shot.steamBurst)
            o.timeSinceLastHit = 0f
            o.hitFlash = 0.1f
            feedback.onEnemyHit(o, shot.steamBurst, false, shot.sourceType)
        }
    }
}
