package com.ironpath.defense.entity.tower.upgrade

import com.ironpath.defense.entity.tower.TowerStats

/** A pure transformation of a tower's stats. Upgrades are lists of these. */
typealias StatModifier = (TowerStats) -> TowerStats

/** One purchasable tier within an [UpgradePath]. */
class TowerUpgrade(
    val name: String,
    val description: String,
    val cost: Int,
    private val modifiers: List<StatModifier>
) {
    fun applyTo(stats: TowerStats): TowerStats =
        modifiers.fold(stats) { current, modifier -> modifier(current) }
}

/** One of a tower's three evolution lines: a name, an accent color and five ordered tiers. */
class UpgradePath(
    val name: String,
    val colorArgb: Int,
    val tagline: String,
    val upgrades: List<TowerUpgrade>
)

/**
 * A tower-specific *fusion* that only exists for one ordered pairing of paths:
 * [main] at tier 3+ combined with [cross] at tier 2. 5-2-0 and 2-5-0 therefore
 * activate different perks (and three-path towers have six in total).
 */
class CrossPerk(
    val main: Int,
    val cross: Int,
    val name: String,
    val description: String,
    private val modifiers: List<StatModifier>
) {
    fun applyTo(stats: TowerStats): TowerStats =
        modifiers.fold(stats) { current, modifier -> modifier(current) }
}
