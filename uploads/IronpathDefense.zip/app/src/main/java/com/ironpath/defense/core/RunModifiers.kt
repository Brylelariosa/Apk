package com.ironpath.defense.core

/** Global, temporary modifiers that map mechanics apply to a run (e.g. sandstorm range loss). */
class RunModifiers {
    var towerRangeMult = 1f
    fun reset() {
        towerRangeMult = 1f
    }
}
