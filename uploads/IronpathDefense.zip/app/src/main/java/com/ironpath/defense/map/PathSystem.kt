package com.ironpath.defense.map

import com.ironpath.defense.core.Vector2
import kotlin.math.atan2

/**
 * Turns a map's waypoint polyline into "where is the enemy that has walked
 * exactly D units along the path" queries.
 *
 * Each enemy caches the segment index it was last resolved into
 * (`Enemy.pathSegmentHint`) and passes it back in on the next call, so a
 * normal frame resolves in O(1) rather than rescanning every segment.
 */
class PathSystem(private val waypoints: List<Vector2>) {
    private val cumulativeDistances: FloatArray
    private val headings: FloatArray
    val totalLength: Float
    val segmentCount: Int get() = waypoints.size - 1

    init {
        require(waypoints.size >= 2) { "A path needs at least two waypoints" }
        cumulativeDistances = FloatArray(waypoints.size)
        headings = FloatArray(waypoints.size - 1)
        var acc = 0f
        for (i in 1 until waypoints.size) {
            acc += waypoints[i - 1].distanceTo(waypoints[i])
            cumulativeDistances[i] = acc
            headings[i - 1] = atan2(waypoints[i].y - waypoints[i - 1].y, waypoints[i].x - waypoints[i - 1].x)
        }
        totalLength = acc
    }

    /**
     * Writes the world position at [distance] along the path into [out], and
     * returns the segment index that position falls in (pass this back in as
     * [hintSegment] next time for the same enemy).
     */
    fun positionAt(distance: Float, hintSegment: Int, out: Vector2): Int {
        val clamped = distance.coerceIn(0f, totalLength)
        var segment = hintSegment.coerceIn(0, waypoints.size - 2)
        while (segment < waypoints.size - 2 && clamped > cumulativeDistances[segment + 1]) segment++
        while (segment > 0 && clamped < cumulativeDistances[segment]) segment--
        val segmentStart = cumulativeDistances[segment]
        val segmentLength = cumulativeDistances[segment + 1] - segmentStart
        val t = if (segmentLength > 0f) (clamped - segmentStart) / segmentLength else 0f
        val from = waypoints[segment]
        val to = waypoints[segment + 1]
        out.set(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t)
        return segment
    }

    /** Travel direction (radians) of a segment; enemies rotate their art to match. */
    fun headingOf(segment: Int): Float = headings[segment.coerceIn(0, headings.size - 1)]

    fun waypoint(index: Int): Vector2 = waypoints[index.coerceIn(0, waypoints.size - 1)]

    fun hasReachedEnd(distance: Float): Boolean = distance >= totalLength
}
