package com.ironpath.defense.settings

import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.core.GraphicsQuality
import com.ironpath.defense.save.SaveData

/**
 * Player-facing settings. Values live in [SaveData] (so they persist) and are
 * pushed to the audio system as they change; [onChanged] asks GameWorld to
 * write the save. Volumes are integer steps 0..10 for easy tap-to-adjust UI.
 */
class SettingsSystem(
    private val audio: AudioSystem,
    private val data: SaveData,
    private val defaultQuality: GraphicsQuality,
    private val onChanged: () -> Unit
) {
    val masterVolume: Int get() = data.masterVolume
    val sfxVolume: Int get() = data.sfxVolume
    val musicVolume: Int get() = data.musicVolume
    val showDamageNumbers: Boolean get() = data.showDamageNumbers
    val screenShake: Boolean get() = data.screenShake
    val autoStart: Boolean get() = data.autoStart
    val hasMusic: Boolean get() = audio.hasMusic

    val quality: GraphicsQuality
        get() = GraphicsQuality.entries.getOrNull(data.qualityOrdinal) ?: defaultQuality

    fun applyToAudio() {
        audio.masterVolume = data.masterVolume / 10f
        audio.sfxVolume = data.sfxVolume / 10f
        audio.musicVolume = data.musicVolume / 10f
        if (data.musicVolume == 0 || data.masterVolume == 0) audio.stopMusic() else audio.playMusicLoop()
    }

    fun changeMaster(delta: Int) {
        data.masterVolume = (data.masterVolume + delta).coerceIn(0, 10)
        commit()
    }

    fun changeSfx(delta: Int) {
        data.sfxVolume = (data.sfxVolume + delta).coerceIn(0, 10)
        commit()
    }

    fun changeMusic(delta: Int) {
        data.musicVolume = (data.musicVolume + delta).coerceIn(0, 10)
        commit()
    }

    fun cycleQuality() {
        val next = (quality.ordinal + 1) % GraphicsQuality.entries.size
        data.qualityOrdinal = next
        commit()
    }

    fun toggleDamageNumbers() {
        data.showDamageNumbers = !data.showDamageNumbers
        commit()
    }

    fun toggleScreenShake() {
        data.screenShake = !data.screenShake
        commit()
    }

    fun toggleAutoStart() {
        data.autoStart = !data.autoStart
        commit()
    }

    private fun commit() {
        applyToAudio()
        onChanged()
    }
}
