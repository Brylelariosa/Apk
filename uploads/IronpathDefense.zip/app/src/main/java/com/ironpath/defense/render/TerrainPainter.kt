package com.ironpath.defense.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.GraphicsQuality
import com.ironpath.defense.map.GameMap
import com.ironpath.defense.map.MapMechanic
import com.ironpath.defense.map.MapTheme
import com.ironpath.defense.map.TileGrid
import com.ironpath.defense.map.TileKind
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.glow
import com.ironpath.defense.render.ArtKit.hash
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.oval
import com.ironpath.defense.render.ArtKit.polygon
import com.ironpath.defense.render.ArtKit.quad
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.rr
import com.ironpath.defense.render.ArtKit.shade
import com.ironpath.defense.render.ArtKit.tri
import com.ironpath.defense.render.ArtKit.withAlpha
import com.ironpath.defense.ui.UiLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Paints the *static* look of a map once into a screen-sized bitmap: themed
 * ground, the road, buildable-tile hints, high ground, scenery obstacles and
 * scenery filling the screen margins. Everything that moves (weather, props,
 * machinery) is drawn by [AmbientRenderer] on top, so the per-frame cost of
 * the terrain is one bitmap blit. Also draws map previews for the menus.
 */
class TerrainPainter {
    private val tile = GameConfig.TILE_SIZE
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pts = FloatArray(64)

    fun build(map: GameMap, grid: TileGrid, layout: UiLayout, quality: GraphicsQuality): Bitmap {
        val w = layout.screenWidth.toInt().coerceAtLeast(2)
        val h = layout.screenHeight.toInt().coerceAtLeast(2)
        val config = if (quality == GraphicsQuality.LOW) Bitmap.Config.RGB_565 else Bitmap.Config.ARGB_8888
        val bmp = Bitmap.createBitmap(w, h, config)
        val c = Canvas(bmp)
        val th = map.theme
        c.drawColor(th.ground1)
        c.save()
        c.translate(layout.worldOffsetX, layout.worldOffsetY)
        c.scale(layout.worldScale, layout.worldScale)
        val minC = floor(-layout.worldOffsetX / layout.worldScale / tile).toInt() - 1
        val maxC = ceil((w - layout.worldOffsetX) / layout.worldScale / tile).toInt() + 1
        val minR = floor(-layout.worldOffsetY / layout.worldScale / tile).toInt() - 1
        val maxR = ceil((h - layout.worldOffsetY) / layout.worldScale / tile).toInt() + 1
        val seed = map.id * 977
        for (r in minR..maxR) for (col in minC..maxC) {
            val x = col * tile
            val y = r * tile
            val shadeK = 0.97f + hash(seed + col * 31 + r * 57) * 0.06f
            rr(c, x, y, x + tile + 0.5f, y + tile + 0.5f, 0f, shade(if ((col + r) and 1 == 0) th.ground1 else th.ground2, shadeK))
        }
        for (r in minR..maxR) for (col in minC..maxC) groundDetail(c, th, col * tile, r * tile, seed + col * 131 + r * 17)
        buildHints(c, grid, th)
        roadLayer(c, map)
        // scenery: margins first (behind), then blockers
        for (r in minR..maxR) for (col in minC..maxC) {
            val inside = col in 0 until GameConfig.GRID_COLS && r in 0 until GameConfig.GRID_ROWS
            val s = seed + col * 53 + r * 97
            if (!inside && hash(s) < 0.34f && !nearRoadExtension(map, col, r)) scenery(c, th, col * tile + tile / 2f, r * tile + tile / 2f, s)
        }
        for ((col, r) in map.blockers) scenery(c, th, col * tile + tile / 2f, r * tile + tile / 2f, seed + col * 53 + r * 97)
        for ((col, r) in map.highGround) plateau(c, th, col * tile, r * tile)
        specials(c, map)
        c.restore()
        vignette(c, w, h)
        return bmp
    }

    private fun nearRoadExtension(map: GameMap, col: Int, r: Int): Boolean {
        val first = map.tileWaypoints.first()
        val last = map.tileWaypoints.last()
        if (abs(r - first.second) <= 1 && col < 1) return true
        if (abs(col - first.first) <= 1 && r < 1) return true
        if (abs(r - last.second) <= 1 && col >= GameConfig.GRID_COLS - 1) return true
        return false
    }

    private fun vignette(c: Canvas, w: Int, h: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rad = sqrt((w * w + h * h).toFloat()) * 0.62f
        p.shader = RadialGradient(w / 2f, h / 2f, rad, intArrayOf(0x00000000, 0x00000000, 0x55000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    // --- ground ------------------------------------------------------------------
    private fun groundDetail(c: Canvas, th: MapTheme, x: Float, y: Float, s: Int) {
        val r1 = hash(s)
        val r2 = hash(s + 7)
        val r3 = hash(s + 13)
        val px = x + r2 * tile
        val py = y + r3 * tile
        when (th) {
            MapTheme.FOREST -> {
                if (r1 < 0.5f) { val g = shade(th.ground2, 1.25f); tri(c, px - 2f, py + 3f, px, py - 4f, px + 1f, py + 3f, g); tri(c, px + 1f, py + 3f, px + 4f, py - 3f, px + 4f, py + 3f, g) }
                if (r1 > 0.93f) { circ(c, px, py, 1.6f, 0xFFFFF2B0.toInt()); circ(c, px + 5f, py + 2f, 1.4f, 0xFFFFFFFF.toInt()) }
            }
            MapTheme.DESERT -> {
                if (r1 < 0.45f) ln(c, px - 8f, py, px + 8f, py - 2f, 1.4f, shade(th.ground2, 0.9f))
                if (r1 > 0.9f) circ(c, px, py, 2.2f, shade(th.ground2, 0.8f))
            }
            MapTheme.SNOW -> {
                if (r1 < 0.4f) oval(c, px - 10f, py - 3f, px + 10f, py + 3f, 0x66FFFFFF)
                if (r1 > 0.92f) { circ(c, px, py, 1.4f, 0xFFFFFFFF.toInt()); circ(c, px + 4f, py - 3f, 1.1f, 0xFFBEE8FF.toInt()) }
            }
            MapTheme.VOLCANO -> {
                if (r1 < 0.35f) { ln(c, px, py, px + 9f, py + 5f, 1.4f, 0xFF150C0A.toInt()); ln(c, px + 9f, py + 5f, px + 12f, py + 13f, 1.2f, 0xFF150C0A.toInt()) }
                if (r1 > 0.94f) { glow(c, px, py, 7f, 0xFFFF5A1E.toInt(), 0.5f); circ(c, px, py, 1.5f, 0xFFFFB04A.toInt()) }
            }
            MapTheme.RUINS -> {
                if (r1 < 0.3f) { circ(c, px, py, 4f, 0xFF6E7468.toInt()); circ(c, px - 1f, py - 1f, 2.4f, 0xFF858C7C.toInt()) }
                if (r1 > 0.85f) ln(c, px - 6f, py, px + 6f, py, 1.4f, 0xFF3E5E44.toInt())
            }
            MapTheme.CITY -> {
                if (r1 < 0.12f) { circ(c, px, py, 9f, 0xFF20242C.toInt()); circ(c, px, py, 6.5f, 0xFF2A2F38.toInt()) }
                if (r1 > 0.9f) oval(c, px - 9f, py - 4f, px + 9f, py + 4f, withAlpha(th.accent, 0.12f))
            }
            MapTheme.FACTORY -> {
                if (r1 < 0.3f) { ln(c, x, py, x + tile, py, 1f, shade(th.ground2, 0.8f)) }
                if (r1 > 0.85f) { circ(c, px, py, 1.6f, shade(th.ground1, 1.3f)); circ(c, px + 8f, py, 1.6f, shade(th.ground1, 1.3f)) }
            }
            MapTheme.ALIEN -> {
                if (r1 < 0.2f) { glow(c, px, py, 8f, th.accent, 0.35f); circ(c, px, py, 1.8f, withAlpha(th.accent, 0.9f)) }
                if (r1 > 0.85f) oval(c, px - 8f, py - 4f, px + 8f, py + 4f, 0x33000000)
            }
        }
    }

    private fun buildHints(c: Canvas, grid: TileGrid, th: MapTheme) {
        val hint = if (th == MapTheme.SNOW || th == MapTheme.DESERT) 0x16000000 else 0x14FFFFFF
        for (r in 0 until GameConfig.GRID_ROWS) for (col in 0 until GameConfig.GRID_COLS) {
            if (grid.kindAt(col, r) != TileKind.BUILDABLE) continue
            val x = col * tile
            val y = r * tile
            rr(c, x + 4f, y + 4f, x + tile - 4f, y + tile - 4f, 7f, hint)
            val k = 0x30000000
            ln(c, x + 5f, y + 11f, x + 5f, y + 5f, 1.2f, k); ln(c, x + 5f, y + 5f, x + 11f, y + 5f, 1.2f, k)
            ln(c, x + tile - 5f, y + tile - 11f, x + tile - 5f, y + tile - 5f, 1.2f, k); ln(c, x + tile - 5f, y + tile - 5f, x + tile - 11f, y + tile - 5f, 1.2f, k)
        }
    }

    private fun plateau(c: Canvas, th: MapTheme, x: Float, y: Float) {
        rr(c, x + 3f, y + 3f, x + tile - 3f, y + tile - 3f, 9f, withAlpha(th.accent, 0.20f))
        rr(c, x + 3f, y + 3f, x + tile - 3f, y + tile - 3f, 9f, 0x22000000)
        rr(c, x + 6f, y + 5f, x + tile - 6f, y + tile - 7f, 8f, withAlpha(shade(th.ground1, 1.18f), 0.9f))
        val cx = x + tile / 2f
        val cy = y + tile / 2f
        tri(c, cx - 7f, cy + 4f, cx + 7f, cy + 4f, cx, cy - 7f, withAlpha(th.accent, 0.85f))
        ln(c, x + 6f, y + tile - 6f, x + tile - 6f, y + tile - 6f, 2f, 0x44000000)
    }

    // --- road ---------------------------------------------------------------------
    private fun roadPoints(map: GameMap): Int {
        val wp = map.worldWaypoints()
        var n = 0
        val ext = tile * 14f
        val d0x = wp[1].x - wp[0].x
        val d0y = wp[1].y - wp[0].y
        val l0 = sqrt(d0x * d0x + d0y * d0y).coerceAtLeast(1f)
        pts[n++] = wp[0].x - d0x / l0 * ext
        pts[n++] = wp[0].y - d0y / l0 * ext
        for (p in wp) { pts[n++] = p.x; pts[n++] = p.y }
        val last = wp[wp.size - 1]
        val prev = wp[wp.size - 2]
        val outside = last.x < 0f || last.x > GameConfig.WORLD_WIDTH || last.y < 0f || last.y > GameConfig.WORLD_HEIGHT
        if (outside) {
            val dx = last.x - prev.x
            val dy = last.y - prev.y
            val l = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            pts[n++] = last.x + dx / l * ext
            pts[n++] = last.y + dy / l * ext
        }
        return n
    }

    private fun strokeRoad(c: Canvas, n: Int, width: Float, color: Int) {
        ArtKit.path.reset()
        ArtKit.path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < n) { ArtKit.path.lineTo(pts[i], pts[i + 1]); i += 2 }
        ArtKit.strokePath(c, width, color)
    }

    private fun roadLayer(c: Canvas, map: GameMap) {
        val th = map.theme
        val n = roadPoints(map)
        strokeRoad(c, n, tile * 1.02f, 0x33000000)
        strokeRoad(c, n, tile * 0.98f, th.pathEdge)
        strokeRoad(c, n, tile * 0.84f, th.pathCore)
        strokeRoad(c, n, tile * 0.5f, withAlpha(shade(th.pathCore, 1.08f), 0.55f))
        // walk the polyline for decoration
        var s = map.id * 313
        var i = 2
        while (i + 1 < n) {
            val x1 = pts[i - 2]; val y1 = pts[i - 1]; val x2 = pts[i]; val y2 = pts[i + 1]
            val dx = x2 - x1; val dy = y2 - y1
            val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val ux = dx / len; val uy = dy / len
            var d = 12f
            while (d < len) {
                s++
                val off = (hash(s) - 0.5f) * tile * 0.6f
                val px = x1 + ux * d - uy * off
                val py = y1 + uy * d + ux * off
                roadDecor(c, th, px, py, ux, uy, s, d)
                d += 22f + hash(s + 5) * 16f
            }
            i += 2
        }
        // slick (ice / conveyor) stretches get their own surface
        if (map.slickSegments.isNotEmpty()) {
            val wp = map.worldWaypoints()
            for (seg in map.slickSegments) {
                if (seg + 1 >= wp.size) continue
                val a = wp[seg]; val b = wp[seg + 1]
                val ice = map.mechanic == MapMechanic.ICE
                ln(c, a.x, a.y, b.x, b.y, tile * 0.84f, if (ice) 0xFFCFEFFF.toInt() else 0xFF1F2328.toInt())
                ln(c, a.x, a.y, b.x, b.y, tile * 0.5f, if (ice) 0x88FFFFFF.toInt() else 0xFF2B3036.toInt())
                val dx = b.x - a.x; val dy = b.y - a.y
                val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                val ux = dx / len; val uy = dy / len
                var d = 18f
                while (d < len - 10f) {
                    val x = a.x + ux * d; val y = a.y + uy * d
                    if (ice) { ln(c, x - uy * 14f, y + ux * 14f, x + ux * 8f - uy * 4f, y + uy * 8f + ux * 4f, 1.2f, 0x99FFFFFF.toInt()) }
                    else { ln(c, x - ux * 5f - uy * 7f, y - uy * 5f + ux * 7f, x - uy * 0f, y + 0f, 2.2f, 0xFFFFB02E.toInt()); ln(c, x - ux * 5f + uy * 7f, y - uy * 5f - ux * 7f, x, y, 2.2f, 0xFFFFB02E.toInt()) }
                    d += if (ice) 30f else 24f
                }
                ln(c, a.x - uy * tile * 0.42f, a.y + ux * tile * 0.42f, b.x - uy * tile * 0.42f, b.y + ux * tile * 0.42f, 2f, if (ice) 0xFF7FB6D8.toInt() else 0xFFFFB02E.toInt())
                ln(c, a.x + uy * tile * 0.42f, a.y - ux * tile * 0.42f, b.x + uy * tile * 0.42f, b.y - ux * tile * 0.42f, 2f, if (ice) 0xFF7FB6D8.toInt() else 0xFFFFB02E.toInt())
            }
        }
    }

    private fun roadDecor(c: Canvas, th: MapTheme, x: Float, y: Float, ux: Float, uy: Float, s: Int, d: Float) {
        val r = hash(s + 3)
        when (th) {
            MapTheme.CITY -> {}
            MapTheme.VOLCANO -> {
                if (r < 0.4f) { ln(c, x, y, x + ux * 10f + uy * 5f, y + uy * 10f - ux * 5f, 1.8f, 0xFFFF5A1E.toInt()); glow(c, x, y, 6f, 0xFFFF5A1E.toInt(), 0.3f) }
                else circ(c, x, y, 2f, shade(th.pathCore, 0.7f))
            }
            MapTheme.FACTORY -> if (r < 0.3f) circ(c, x, y, 1.6f, 0xFF4A5058.toInt())
            else -> if (r < 0.55f) circ(c, x, y, 1.4f + r * 2.2f, shade(th.pathCore, if (r < 0.3f) 0.8f else 1.12f))
        }
        if (th == MapTheme.CITY && r < 0.5f) {
            ln(c, x - ux * 7f, y - uy * 7f, x + ux * 7f, y + uy * 7f, 2f, 0xCCE8D9A0.toInt())
        }
    }

    // --- special tiles (static bases of animated props) ---------------------
    private fun specials(c: Canvas, map: GameMap) {
        val th = map.theme
        for ((col, r) in map.specialTiles) {
            val cx = col * tile + tile / 2f
            val cy = r * tile + tile / 2f
            when (map.mechanic) {
                MapMechanic.RUNES -> {
                    oval(c, cx - 24f, cy + 10f, cx + 24f, cy + 26f, 0x44000000)
                    circ(c, cx, cy, 25f, 0xFF4E5448.toInt()); circ(c, cx, cy, 21f, 0xFF868C7A.toInt()); circ(c, cx, cy, 15f, 0xFF6C7262.toInt())
                    ring(c, cx, cy, 18f, 1.6f, withAlpha(th.accent, 0.8f))
                }
                MapMechanic.GRID_SURGE -> {
                    oval(c, cx - 22f, cy + 10f, cx + 22f, cy + 26f, 0x44000000)
                    polygon(c, cx, cy, 25f, 8, 22.5f, 0xFF20242C.toInt()); polygon(c, cx, cy, 20f, 8, 22.5f, 0xFF3A4150.toInt())
                    circ(c, cx, cy, 11f, 0xFF14181F.toInt()); ring(c, cx, cy, 14f, 2f, withAlpha(th.accent, 0.8f))
                }
                MapMechanic.FACTORY -> {
                    // hydraulic press housings on both sides of the road
                    rr(c, cx - 22f, cy - 36f, cx + 22f, cy - 24f, 3f, 0xFF4A5058.toInt()); rr(c, cx - 22f, cy + 24f, cx + 22f, cy + 36f, 3f, 0xFF4A5058.toInt())
                    rr(c, cx - 22f, cy - 36f, cx + 22f, cy - 33f, 1f, 0xFFFFB02E.toInt()); rr(c, cx - 22f, cy + 33f, cx + 22f, cy + 36f, 1f, 0xFFFFB02E.toInt())
                }
                else -> {}
            }
        }
    }

    // --- scenery --------------------------------------------------------------
    private fun scenery(c: Canvas, th: MapTheme, cx: Float, cy: Float, s: Int) {
        val v = hash(s)
        val j = (hash(s + 3) - 0.5f) * 10f
        val x = cx + j
        val y = cy + (hash(s + 9) - 0.5f) * 8f
        oval(c, x - 21f, y + 8f, x + 21f, y + 26f, 0x33000000)
        when (th) {
            MapTheme.FOREST -> {
                val big = 20f + v * 8f
                rr(c, x - 3.4f, y + 2f, x + 3.4f, y + 18f, 2f, 0xFF5A3A22.toInt())
                circ(c, x - 9f, y + 2f, big * 0.6f, shade(th.deco1, 0.9f)); circ(c, x + 9f, y + 2f, big * 0.6f, shade(th.deco1, 0.9f))
                circ(c, x, y - 4f, big * 0.82f, th.deco1)
                circ(c, x - 4f, y - 9f, big * 0.55f, th.deco2); circ(c, x + 5f, y - 6f, big * 0.3f, shade(th.deco2, 1.2f))
            }
            MapTheme.DESERT -> if (v < 0.55f) {
                rr(c, x - 4f, y - 18f, x + 4f, y + 16f, 4f, th.deco1); rr(c, x - 15f, y - 7f, x - 9f, y + 2f, 3f, th.deco1); rr(c, x - 15f, y - 2f, x - 4f, y + 4f, 3f, th.deco1)
                rr(c, x + 9f, y - 12f, x + 15f, y - 2f, 3f, th.deco1); rr(c, x + 4f, y - 4f, x + 15f, y + 2f, 3f, th.deco1)
                ln(c, x, y - 16f, x, y + 12f, 1.2f, shade(th.deco1, 1.3f))
            } else {
                circ(c, x - 6f, y + 4f, 10f, th.deco2); circ(c, x + 8f, y + 6f, 8f, shade(th.deco2, 0.85f)); circ(c, x - 8f, y + 1f, 5f, shade(th.deco2, 1.25f))
            }
            MapTheme.SNOW -> if (v < 0.5f) {
                for (k in 0 until 3) { val ox = (k - 1) * 11f; tri(c, x + ox - 8f, y + 14f, x + ox + 8f, y + 14f, x + ox + (hash(s + k) - 0.5f) * 4f, y - 18f + abs(k - 1) * 8f, withAlpha(th.deco1, 0.9f)); tri(c, x + ox - 3f, y + 14f, x + ox + 8f, y + 14f, x + ox + 1f, y - 18f + abs(k - 1) * 8f, 0x66FFFFFF) }
            } else {
                tri(c, x - 14f, y + 14f, x + 14f, y + 14f, x, y - 14f, shade(th.deco2, 1.1f)); tri(c, x - 6f, y + 14f, x + 14f, y + 14f, x + 2f, y - 14f, 0x55FFFFFF); oval(c, x - 16f, y + 10f, x + 16f, y + 18f, 0xCCFFFFFF.toInt())
            }
            MapTheme.VOLCANO -> {
                polygon(c, x, y + 2f, 20f + v * 4f, 7, v * 90f, th.deco1); polygon(c, x - 2f, y, 14f, 7, v * 90f + 20f, shade(th.deco1, 1.35f))
                ln(c, x - 8f, y - 2f, x + 4f, y + 6f, 2f, th.deco2); ln(c, x + 4f, y + 6f, x + 10f, y + 14f, 1.6f, th.deco2); glow(c, x, y + 2f, 18f, th.deco2, 0.28f)
            }
            MapTheme.RUINS -> if (v < 0.55f) {
                rr(c, x - 10f, y - 8f, x + 10f, y + 16f, 3f, shade(th.deco1, 0.8f)); rr(c, x - 12f, y - 14f, x + 12f, y - 6f, 3f, th.deco1)
                for (k in 0 until 3) ln(c, x - 6f + k * 6f, y - 4f, x - 6f + k * 6f, y + 14f, 1.2f, shade(th.deco1, 0.65f))
                circ(c, x + 14f, y + 12f, 5f, th.deco1); ln(c, x - 12f, y + 4f, x - 4f, y + 12f, 1.6f, th.deco2)
            } else {
                circ(c, x - 6f, y + 4f, 9f, th.deco1); circ(c, x + 7f, y + 7f, 7f, shade(th.deco1, 0.85f)); circ(c, x - 3f, y - 2f, 5f, th.deco2)
            }
            MapTheme.CITY -> {
                val bw = 24f + v * 6f
                rr(c, x - bw, y - 24f, x + bw, y + 22f, 4f, 0xFF2B3140.toInt()); rr(c, x - bw + 3f, y - 21f, x + bw - 3f, y + 19f, 3f, th.deco1)
                rr(c, x - 10f, y - 14f, x + 2f, y - 6f, 2f, 0xFF3A4252.toInt()); circ(c, x + 12f, y + 6f, 5f, 0xFF2B3140.toInt()); circ(c, x + 12f, y + 6f, 3f, 0xFF59647A.toInt())
                ln(c, x - bw + 2f, y - 22f, x + bw - 2f, y - 22f, 2f, if (v < 0.5f) th.accent else th.deco2)
                for (k in 0 until 3) rr(c, x - bw + 6f + k * 8f, y + 8f, x - bw + 11f + k * 8f, y + 14f, 1f, withAlpha(th.deco2, 0.8f))
            }
            MapTheme.FACTORY -> {
                rr(c, x - 22f, y - 20f, x + 22f, y + 18f, 5f, 0xFF4A5058.toInt()); rr(c, x - 19f, y - 17f, x + 19f, y + 15f, 4f, th.deco1)
                circ(c, x - 6f, y - 2f, 11f, 0xFF30353C.toInt()); polygon(c, x - 6f, y - 2f, 9f, 8, v * 45f, 0xFF59616C.toInt()); circ(c, x - 6f, y - 2f, 3f, 0xFF30353C.toInt())
                for (k in 0 until 4) rr(c, x + 6f + k * 4f, y - 18f, x + 8f + k * 4f, y + 14f, 0f, if (k % 2 == 0) th.deco2 else 0xFF1E2227.toInt())
                ln(c, x - 22f, y + 18f, x + 22f, y + 18f, 2f, 0xFFFFB02E.toInt())
            }
            MapTheme.ALIEN -> {
                glow(c, x, y - 4f, 26f, th.deco2, 0.22f)
                for (k in 0 until 5) { val a = -1.57f + (k - 2) * 0.55f; tri(c, x - 3.5f, y + 10f, x + 3.5f, y + 10f, x + cos(a) * 24f, y + 10f + sin(a) * 28f, shade(th.deco1, 0.8f + k * 0.1f)) }
                circ(c, x, y + 4f, 9f, th.deco1); circ(c, x - 2f, y + 2f, 4.5f, shade(th.deco1, 1.4f))
                for (k in 0 until 3) { val ox = (k - 1) * 12f; circ(c, x + ox, y - 14f - abs(k - 1) * 3f, 3.2f, th.deco2); glow(c, x + ox, y - 14f - abs(k - 1) * 3f, 8f, th.deco2, 0.7f) }
            }
        }
    }

    // --- previews for menus --------------------------------------------------
    /** Draws a stylized miniature of [map] inside the given screen rectangle. */
    fun drawPreview(c: Canvas, map: GameMap, left: Float, top: Float, width: Float, height: Float, detailed: Boolean) {
        val th = map.theme
        c.save()
        c.clipRect(left, top, left + width, top + height)
        c.translate(left, top)
        c.drawColor(th.ground1)
        c.scale(width / GameConfig.WORLD_WIDTH, height / GameConfig.WORLD_HEIGHT)
        if (detailed) {
            for (r in 0 until GameConfig.GRID_ROWS) for (col in 0 until GameConfig.GRID_COLS) {
                if ((col + r) and 1 == 1) rr(c, col * tile, r * tile, (col + 1) * tile, (r + 1) * tile, 0f, th.ground2)
            }
        } else {
            rr(c, 0f, GameConfig.WORLD_HEIGHT * 0.5f, GameConfig.WORLD_WIDTH, GameConfig.WORLD_HEIGHT, 0f, withAlpha(th.ground2, 0.7f))
        }
        val n = roadPoints(map)
        strokeRoad(c, n, tile * 0.98f, th.pathEdge)
        strokeRoad(c, n, tile * 0.78f, th.pathCore)
        for ((col, r) in map.blockers) {
            val x = col * tile + tile / 2f
            val y = r * tile + tile / 2f
            circ(c, x, y, tile * 0.36f, th.deco1)
            if (detailed) circ(c, x - 5f, y - 5f, tile * 0.18f, th.deco2)
        }
        for ((col, r) in map.highGround) tri(c, col * tile + 14f, r * tile + 48f, col * tile + 50f, r * tile + 48f, col * tile + 32f, r * tile + 14f, withAlpha(th.accent, 0.85f))
        for ((col, r) in map.specialTiles) circ(c, col * tile + tile / 2f, r * tile + tile / 2f, tile * 0.3f, th.accent)
        c.restore()
    }
}
