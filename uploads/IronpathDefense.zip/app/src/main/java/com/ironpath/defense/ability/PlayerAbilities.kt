package com.ironpath.defense.ability

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.Fx
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemySystem
import com.ironpath.defense.entity.tower.Tower

/**
 * Cooldown-based abilities the player can fire during a wave. Cooldowns run on
 * simulation time (so they speed up with game speed) and every ability starts
 * partly charged so it is not available in the very first seconds of a run.
 */
class PlayerAbilities(
    private val collision: CollisionSystem,
    private val enemies: EnemySystem,
    private val towers: () -> List<Tower>,
    private val feedback: CombatFeedback
) {
    private val cooldown = FloatArray(AbilityType.entries.size)
    private val scratch = ArrayList<Enemy>(48)
    private val tmp = Vector2()

    /** Set while a targeted ability is waiting for the player to tap the battlefield. */
    var armed: AbilityType? = null
        private set

    init {
        reset()
    }

    fun reset() {
        for (a in AbilityType.entries) cooldown[a.ordinal] = a.cooldownSeconds * 0.35f
        armed = null
    }

    fun update(dt: Float) {
        for (i in cooldown.indices) if (cooldown[i] > 0f) cooldown[i] -= dt
    }

    fun isReady(type: AbilityType): Boolean = cooldown[type.ordinal] <= 0f

    /** 0 = ready, 1 = just used. */
    fun cooldownFraction(type: AbilityType): Float =
        (cooldown[type.ordinal] / type.cooldownSeconds).coerceIn(0f, 1f)

    fun secondsLeft(type: AbilityType): Int = Math.ceil(cooldown[type.ordinal].coerceAtLeast(0f).toDouble()).toInt()

    /** Tap on an ability button. Returns false if it is still recharging. */
    fun activate(type: AbilityType, waveNumber: Int): Boolean {
        if (!isReady(type)) return false
        if (type.needsTarget) {
            armed = if (armed == type) null else type
            return true
        }
        armed = null
        when (type) {
            AbilityType.FREEZE -> {
                val list = enemies.active
                for (i in 0 until list.size) {
                    list[i].applySlow(0.35f, 4f)
                    list[i].applyStun(0.8f)
                }
                feedback.onFx(Fx.FREEZE_ALL, GameConfig.WORLD_WIDTH / 2f, GameConfig.WORLD_HEIGHT / 2f, 520f, type.colorArgb)
            }
            AbilityType.OVERDRIVE -> {
                val all = towers()
                for (i in 0 until all.size) {
                    all[i].overdriveTime = 6f
                    if (all[i].overdriveBonus < 0.5f) all[i].overdriveBonus = 0.5f
                }
                feedback.onFx(Fx.OVERDRIVE, GameConfig.WORLD_WIDTH / 2f, GameConfig.WORLD_HEIGHT / 2f, 520f, type.colorArgb)
            }
            AbilityType.STRIKE -> {}
        }
        cooldown[type.ordinal] = type.cooldownSeconds
        return true
    }

    /** Resolves an armed targeted ability at a world position. Returns true if it fired. */
    fun fireArmedAt(x: Float, y: Float, waveNumber: Int): Boolean {
        val type = armed ?: return false
        armed = null
        if (type != AbilityType.STRIKE || !isReady(type)) return false
        tmp.set(x, y)
        collision.queryRadiusInto(tmp, STRIKE_RADIUS, scratch)
        val damage = 140f + 9f * waveNumber
        for (i in 0 until scratch.size) {
            val e = scratch[i]
            val dealt = e.applyDamage(damage, 100f)
            feedback.onEnemyHit(e, dealt, false, -1)
        }
        feedback.onFx(Fx.STRIKE, x, y, STRIKE_RADIUS, type.colorArgb)
        cooldown[type.ordinal] = type.cooldownSeconds
        return true
    }

    fun disarm() {
        armed = null
    }

    companion object {
        const val STRIKE_RADIUS = 115f
    }
}
