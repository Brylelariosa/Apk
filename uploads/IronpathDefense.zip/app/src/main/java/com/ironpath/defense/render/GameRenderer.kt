package com.ironpath.defense.render

import android.graphics.Canvas
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.ui.HudState
import com.ironpath.defense.ui.MenuScreens
import com.ironpath.defense.ui.Palette
import com.ironpath.defense.ui.PlayHud
import com.ironpath.defense.ui.UiKit
import com.ironpath.defense.ui.UiLayout

/**
 * Orchestrates one frame: world or menu backdrop first, then the HUD or menu
 * for the current screen, then the screen-transition fade. Buttons are
 * registered into [kit] while drawing and used by input on the next tap.
 */
class GameRenderer(private val layout: UiLayout) {
    val kit = UiKit(layout)
    private val world = WorldRenderer(layout)
    private val playHud = PlayHud(kit, layout)
    private val menus = MenuScreens(kit, layout, world.previewPainter)

    fun render(c: Canvas, state: HudState) {
        if (layout.screenWidth < 2f || layout.screenHeight < 2f) return
        kit.time = state.time
        kit.beginFrame(true)
        c.drawColor(Palette.VOID)
        val run = state.run
        when (state.screen) {
            GameScreenState.MAIN_MENU -> {
                world.drawBackdrop(c, state)
                menus.mainMenu(c, state)
            }
            GameScreenState.MAP_SELECT -> {
                world.drawBackdrop(c, state)
                menus.mapSelect(c, state)
            }
            GameScreenState.CODEX -> {
                world.drawBackdrop(c, state)
                menus.codex(c, state)
            }
            GameScreenState.SETTINGS -> {
                if (state.ui.settingsReturn == GameScreenState.PAUSED && run != null) {
                    world.drawWorld(c, state, run)
                    kit.interactive = false
                    playHud.draw(c, state, run)
                    kit.interactive = true
                } else {
                    world.drawBackdrop(c, state)
                }
                menus.settings(c, state)
            }
            GameScreenState.PLAYING -> if (run != null) {
                world.drawWorld(c, state, run)
                playHud.draw(c, state, run)
            }
            GameScreenState.PAUSED -> if (run != null) {
                world.drawWorld(c, state, run)
                kit.interactive = false
                playHud.draw(c, state, run)
                kit.interactive = true
                menus.pause(c, state)
            }
            GameScreenState.VICTORY, GameScreenState.GAME_OVER -> if (run != null) {
                world.drawWorld(c, state, run)
                kit.interactive = false
                playHud.draw(c, state, run)
                kit.interactive = true
                menus.end(c, state)
            }
        }
        if (state.fade > 0.003f) {
            kit.rect(c, 0f, 0f, layout.screenWidth, layout.screenHeight, (state.fade.coerceIn(0f, 1f) * 255f).toInt() shl 24)
        }
    }
}
