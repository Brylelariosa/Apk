package com.ironpath.defense.entity.tower

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.HitResolver
import com.ironpath.defense.core.RunModifiers
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.projectile.ProjectileSystem
import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.projectile.ShotProfile
import kotlin.random.Random

/**
 * Owns the placed towers and runs their combat each fixed step: cooldowns,
 * targeting, multishot, special volleys (every Nth shot), heat ramp, pulses
 * (novas / EMP) and timed disables (jams) and buffs (overdrive).
 */
class TowerSystem(
    private val collisionSystem: CollisionSystem,
    private val projectileSystem: ProjectileSystem,
    private val hitResolver: HitResolver,
    private val feedback: CombatFeedback,
    private val modifiers: RunModifiers
) {
    private val towers = ArrayList<Tower>()
    val all: List<Tower> get() = towers

    private val targetBuffer = ArrayList<Enemy>(20)
    private val pulseTargets = ArrayList<Enemy>(48)
    private val pulseShot = ShotProfile()

    fun place(tower: Tower) {
        towers.add(tower)
    }

    fun remove(tower: Tower) {
        towers.remove(tower)
    }

    fun clear() {
        towers.clear()
    }

    fun update(dt: Float) {
        for (i in 0 until towers.size) {
            val tower = towers[i]
            if (tower.flashRemaining > 0f) tower.flashRemaining -= dt
            if (tower.specialFlash > 0f) tower.specialFlash -= dt
            if (tower.recoil > 0f) tower.recoil = (tower.recoil - dt * RECOIL_DECAY).coerceAtLeast(0f)
            if (tower.evolveTimer > 0f) tower.evolveTimer -= dt
            if (tower.buildTimer > 0f) tower.buildTimer -= dt
            if (tower.overdriveTime > 0f) {
                tower.overdriveTime -= dt
                if (tower.overdriveTime <= 0f) tower.overdriveBonus = 0f
            }
            if (tower.jamTime > 0f) {
                tower.jamTime -= dt
                continue // jammed: no firing, no pulses, no cooldown progress
            }
            if (tower.firingTimer > 0f) {
                tower.firingTimer -= dt
                tower.heat = (tower.heat + dt * HEAT_GAIN).coerceAtMost(1f)
            } else if (tower.heat > 0f) {
                tower.heat = (tower.heat - dt * HEAT_LOSS).coerceAtLeast(0f)
            }
            val stats = tower.effective
            if (stats.pulseDamage > 0f && stats.pulseIntervalSeconds > 0f) updatePulse(tower, stats, dt)
            val boost = 1f + (if (tower.overdriveTime > 0f) tower.overdriveBonus else 0f) + stats.rampMax * tower.heat
            tower.cooldownRemaining -= dt * boost
            if (tower.cooldownRemaining > 0f) continue
            fireVolley(tower, stats)
        }
    }

    private fun fireVolley(tower: Tower, stats: TowerStats) {
        val range = stats.range * modifiers.towerRangeMult
        val special = stats.specialEvery > 0 && (tower.shotCounter + 1) % stats.specialEvery == 0
        val shots = stats.projectilesPerShot + (if (special) stats.specialExtraShots else 0)
        targetBuffer.clear()
        if (shots <= 1) {
            val single = collisionSystem.findTarget(tower.position, range, tower.targetingMode) ?: return
            targetBuffer.add(single)
        } else {
            collisionSystem.findTargets(tower.position, range, tower.targetingMode, shots, targetBuffer)
            if (targetBuffer.isEmpty()) return
        }
        tower.shotCounter++
        tower.aimAt(targetBuffer[0].position)
        val type = if (stats.projectileOverride >= 0) ProjectileType.entries[stats.projectileOverride] else tower.type.projectileType
        for (shotIndex in 0 until shots) {
            val target = targetBuffer[shotIndex % targetBuffer.size]
            val isCrit = stats.critChance > 0f && Random.nextFloat() < stats.critChance
            var damage = if (isCrit) stats.damage * stats.critMultiplier else stats.damage
            if (special) damage *= stats.specialDamageMult
            val projectile = projectileSystem.spawn(type, tower.position, target, stats.pierce)
            val shot = projectile.shot
            stats.writeShot(shot, damage, isCrit, tower.accentColorArgb)
            shot.sourceType = tower.type.ordinal
            if (special) {
                shot.isSpecial = true
                shot.splashRadius += stats.specialSplashBonus
                shot.chainCount += stats.specialChainBonus
                if (stats.specialStunSeconds > 0f) shot.specialStun = stats.specialStunSeconds
            }
        }
        tower.cooldownRemaining = stats.fireRateSeconds
        tower.flashRemaining = MUZZLE_FLASH_SECONDS
        tower.recoil = 1f
        tower.firingTimer = FIRING_WINDOW
        if (special) tower.specialFlash = 0.3f
        feedback.onTowerFire(tower, special)
    }

    private fun updatePulse(tower: Tower, stats: TowerStats, dt: Float) {
        tower.pulseCooldownRemaining -= dt
        if (tower.pulseCooldownRemaining > 0f) return
        collisionSystem.queryRadiusInto(tower.position, stats.pulseRadius, pulseTargets)
        if (pulseTargets.isEmpty()) return // hold the charge until something is actually in reach
        stats.writeShot(pulseShot, stats.pulseDamage, false, tower.accentColorArgb)
        pulseShot.sourceType = tower.type.ordinal
        feedback.onPulse(tower.position, stats.pulseRadius, tower.accentColorArgb)
        for (k in 0 until pulseTargets.size) {
            val enemy = pulseTargets[k]
            val dealt = hitResolver.apply(enemy, pulseShot, stats.pulseDamage)
            feedback.onEnemyHit(enemy, dealt, false, tower.type.ordinal)
        }
        tower.pulseCooldownRemaining = stats.pulseIntervalSeconds
    }

    private companion object {
        const val MUZZLE_FLASH_SECONDS = 0.09f
        const val RECOIL_DECAY = 7f
        const val HEAT_GAIN = 0.33f
        const val HEAT_LOSS = 0.6f
        const val FIRING_WINDOW = 0.7f
    }
}
