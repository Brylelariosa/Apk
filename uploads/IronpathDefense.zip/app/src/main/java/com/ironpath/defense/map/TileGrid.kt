package com.ironpath.defense.map

/** Static classification of a single grid cell. */
enum class TileKind { BUILDABLE, PATH, BLOCKED }

/**
 * Per-tile classification (path / buildable / blocked), a per-tile range bonus
 * for high ground, and dynamic tower occupancy, addressed by (col, row).
 *
 * Kept separate from [GameMap] so the *shape* of a map and the *bookkeeping*
 * of what is currently built on it are independent: a fresh TileGrid is
 * derived from a GameMap at the start of a run and only occupancy mutates.
 */
class TileGrid(private val cols: Int, private val rows: Int) {
    private val kinds = Array(rows) { Array(cols) { TileKind.BUILDABLE } }
    private val occupied = Array(rows) { Array(cols) { false } }
    private val bonus = Array(rows) { FloatArray(cols) }

    fun inBounds(col: Int, row: Int) = col in 0 until cols && row in 0 until rows

    fun setKind(col: Int, row: Int, kind: TileKind) {
        if (inBounds(col, row)) kinds[row][col] = kind
    }

    fun kindAt(col: Int, row: Int): TileKind =
        if (inBounds(col, row)) kinds[row][col] else TileKind.BLOCKED

    fun setBonus(col: Int, row: Int, value: Float) {
        if (inBounds(col, row)) bonus[row][col] = value
    }

    /** Fractional range bonus granted to a tower built here (high ground). */
    fun bonusAt(col: Int, row: Int): Float = if (inBounds(col, row)) bonus[row][col] else 0f

    fun isOccupied(col: Int, row: Int): Boolean =
        if (inBounds(col, row)) occupied[row][col] else true

    fun setOccupied(col: Int, row: Int, value: Boolean) {
        if (inBounds(col, row)) occupied[row][col] = value
    }

    /** A tower can only go on a buildable, currently-empty tile — never on the path. */
    fun canPlaceTower(col: Int, row: Int): Boolean =
        inBounds(col, row) && kindAt(col, row) == TileKind.BUILDABLE && !isOccupied(col, row)

    /** Clears every occupancy flag (tile kinds are untouched). Used when starting a new session. */
    fun resetOccupancy() {
        for (row in occupied.indices) occupied[row].fill(false)
    }
}
