package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.sin

/** Cached word-wrap result for one piece of text; reused until text/width/size change. */
class WrapCache {
    var source: String? = null
    var width = 0f
    var size = 0f
    val lines = ArrayList<String>(4)
}

/**
 * Immediate-mode drawing toolkit shared by every screen: panels, glossy
 * buttons, chips, bars, text and a set of vector icons. Buttons register their
 * own hit region as they are drawn ([registry]), which is how drawn and
 * tappable areas stay identical. All paints are preallocated; nothing here
 * allocates per frame except the occasional re-wrapped string.
 */
class UiKit(val layout: UiLayout) {
    val registry = ButtonRegistry()
    var interactive = true
    var time = 0f

    val r = RectF()
    private val r2 = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val fm = Paint.FontMetrics()
    private var pressedId = UiId.NONE
    private var pressedAt = -10f

    fun dp(v: Float): Float = layout.dp(v)
    fun notifyPressed(id: Int) {
        pressedId = id
        pressedAt = time
    }

    fun beginFrame(clearButtons: Boolean) {
        if (clearButtons) registry.clear()
        interactive = true
    }

    // --- basic shapes -----------------------------------------------------
    fun panel(c: Canvas, rect: RectF, radiusDp: Float, fillColor: Int = Palette.PANEL, edgeColor: Int = Palette.EDGE, edgeDp: Float = 1.5f) {
        val rad = dp(radiusDp)
        fill.style = Paint.Style.FILL
        fill.color = fillColor
        c.drawRoundRect(rect, rad, rad, fill)
        if (edgeDp > 0f) {
            line.strokeWidth = dp(edgeDp)
            line.color = edgeColor
            c.drawRoundRect(rect, rad, rad, line)
        }
    }

    fun rect(c: Canvas, l: Float, t: Float, rr: Float, b: Float, color: Int) {
        fill.style = Paint.Style.FILL
        fill.color = color
        c.drawRect(l, t, rr, b, fill)
    }

    fun circle(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int) {
        fill.style = Paint.Style.FILL
        fill.color = color
        c.drawCircle(cx, cy, radius, fill)
    }

    fun ring(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, widthDp: Float) {
        line.strokeWidth = dp(widthDp)
        line.color = color
        c.drawCircle(cx, cy, radius, line)
    }

    fun stroke(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, widthDp: Float) {
        line.strokeWidth = dp(widthDp)
        line.color = color
        c.drawLine(x1, y1, x2, y2, line)
    }

    fun bar(c: Canvas, rect: RectF, frac: Float, fillColor: Int, backColor: Int) {
        val rad = rect.height() / 2f
        fill.style = Paint.Style.FILL
        fill.color = backColor
        c.drawRoundRect(rect, rad, rad, fill)
        val f = frac.coerceIn(0f, 1f)
        if (f > 0.001f) {
            r2.set(rect.left, rect.top, rect.left + maxOf(rect.height(), rect.width() * f), rect.bottom)
            fill.color = fillColor
            c.drawRoundRect(r2, rad, rad, fill)
        }
    }

    /** Soft glow made of three stacked translucent discs (cheap on any GPU). */
    fun glow(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, alpha: Float) {
        val base = (color ushr 24) and 0xFF
        val a = (base * alpha).toInt().coerceIn(0, 255)
        fill.style = Paint.Style.FILL
        for (i in 0 until 3) {
            val k = 1f - i * 0.28f
            val ai = (a * (0.18f + i * 0.2f)).toInt().coerceIn(0, 255)
            fill.color = (color and 0x00FFFFFF) or (ai shl 24)
            c.drawCircle(cx, cy, radius * k, fill)
        }
    }

    // --- text -----------------------------------------------------------------
    fun text(c: Canvas, s: String, x: Float, y: Float, sizeDp: Float, color: Int,
             align: Paint.Align = Paint.Align.LEFT, bold: Boolean = true, shadow: Boolean = false) {
        textPaint.textSize = dp(sizeDp)
        textPaint.textAlign = align
        textPaint.typeface = if (bold) BOLD else REGULAR
        if (shadow) {
            textPaint.color = 0xB0000000.toInt()
            c.drawText(s, x + dp(1f), y + dp(1.4f), textPaint)
        }
        textPaint.color = color
        c.drawText(s, x, y, textPaint)
    }

    /** Draws [s] vertically centered on [cy]. */
    fun textMid(c: Canvas, s: String, x: Float, cy: Float, sizeDp: Float, color: Int,
                align: Paint.Align = Paint.Align.LEFT, bold: Boolean = true, shadow: Boolean = false) {
        textPaint.textSize = dp(sizeDp)
        textPaint.typeface = if (bold) BOLD else REGULAR
        textPaint.getFontMetrics(fm)
        text(c, s, x, cy - (fm.ascent + fm.descent) / 2f, sizeDp, color, align, bold, shadow)
    }

    /** Like [textMid] but shrinks the text (down to 60%) so it fits within [maxW] pixels. */
    fun textFit(c: Canvas, s: String, x: Float, cy: Float, maxW: Float, sizeDp: Float, color: Int,
                align: Paint.Align = Paint.Align.LEFT, bold: Boolean = true) {
        var size = sizeDp
        val w = measure(s, size, bold)
        if (w > maxW && w > 0f) size = (sizeDp * maxW / w).coerceAtLeast(sizeDp * 0.6f)
        textMid(c, s, x, cy, size, color, align, bold)
    }

    fun measure(s: String, sizeDp: Float, bold: Boolean = true): Float {
        textPaint.textSize = dp(sizeDp)
        textPaint.typeface = if (bold) BOLD else REGULAR
        return textPaint.measureText(s)
    }

    /** Word-wraps [s] into [cache] for the given width; returns the cached lines. */
    fun wrap(cache: WrapCache, s: String, widthPx: Float, sizeDp: Float, bold: Boolean = false): List<String> {
        if (cache.source === s && cache.width == widthPx && cache.size == sizeDp) return cache.lines
        cache.source = s
        cache.width = widthPx
        cache.size = sizeDp
        cache.lines.clear()
        textPaint.textSize = dp(sizeDp)
        textPaint.typeface = if (bold) BOLD else REGULAR
        var current = ""
        for (word in s.split(' ')) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (textPaint.measureText(candidate) <= widthPx || current.isEmpty()) {
                current = candidate
            } else {
                cache.lines.add(current)
                current = word
            }
        }
        if (current.isNotEmpty()) cache.lines.add(current)
        return cache.lines
    }

    /** Draws wrapped text starting at ([x], [top]); returns the y just below the last line. */
    fun wrapped(c: Canvas, cache: WrapCache, s: String, x: Float, top: Float, widthPx: Float, sizeDp: Float,
                color: Int, maxLines: Int, bold: Boolean = false): Float {
        val lines = wrap(cache, s, widthPx, sizeDp, bold)
        val lh = dp(sizeDp * 1.22f)
        var y = top
        val n = minOf(lines.size, maxLines)
        for (i in 0 until n) {
            text(c, lines[i], x, y + dp(sizeDp), sizeDp, color, Paint.Align.LEFT, bold)
            y += lh
        }
        return y
    }

    // --- buttons --------------------------------------------------------------
    /** A glossy two-tone button. Registers its tap region when the screen is interactive. */
    fun button(c: Canvas, rect: RectF, id: Int, label: String, style: Int = SECONDARY, enabled: Boolean = true,
               sizeDp: Float = 15f, sub: String? = null) {
        if (interactive && enabled) registry.add(id, rect)
        val pressed = id == pressedId && time - pressedAt < 0.14f
        val inset = if (pressed) dp(2f) else 0f
        r2.set(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
        drawGloss(c, r2, if (enabled) style else DISABLED, 9f)
        val cy = (r2.top + r2.bottom) / 2f
        val cx = (r2.left + r2.right) / 2f
        val color = if (enabled) Palette.TEXT else Palette.TEXT_FAINT
        if (sub == null) {
            textMid(c, label, cx, cy, sizeDp, color, Paint.Align.CENTER, true, true)
        } else {
            textMid(c, label, cx, cy - dp(sizeDp * 0.35f), sizeDp, color, Paint.Align.CENTER, true, true)
            textMid(c, sub, cx, cy + dp(sizeDp * 0.78f), sizeDp * 0.68f, if (enabled) Palette.GOLD else Palette.TEXT_FAINT, Paint.Align.CENTER, true)
        }
    }

    fun iconButton(c: Canvas, rect: RectF, id: Int, iconCode: Int, style: Int = SECONDARY, enabled: Boolean = true) {
        if (interactive && enabled) registry.add(id, rect)
        val pressed = id == pressedId && time - pressedAt < 0.14f
        val inset = if (pressed) dp(2f) else 0f
        r2.set(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
        drawGloss(c, r2, if (enabled) style else DISABLED, 9f)
        icon(c, iconCode, (r2.left + r2.right) / 2f, (r2.top + r2.bottom) / 2f, minOf(r2.width(), r2.height()) * 0.32f,
            if (enabled) Palette.TEXT else Palette.TEXT_FAINT)
    }

    /** Registers a tap region with no drawing (for custom-drawn buttons). */
    fun hitArea(id: Int, rect: RectF) {
        if (interactive) registry.add(id, rect)
    }

    fun isPressed(id: Int): Boolean = id == pressedId && time - pressedAt < 0.14f

    private fun drawGloss(c: Canvas, rect: RectF, style: Int, radiusDp: Float) {
        val rad = dp(radiusDp)
        val base = STYLE_COLORS[style]
        fill.style = Paint.Style.FILL
        fill.color = base[0]
        c.drawRoundRect(rect, rad, rad, fill)
        c.save()
        c.clipRect(rect.left, (rect.top + rect.bottom) / 2f, rect.right, rect.bottom)
        fill.color = base[1]
        c.drawRoundRect(rect, rad, rad, fill)
        c.restore()
        line.strokeWidth = dp(1.4f)
        line.color = base[2]
        c.drawRoundRect(rect, rad, rad, line)
        line.strokeWidth = dp(1f)
        line.color = 0x44FFFFFF
        c.drawLine(rect.left + rad, rect.top + dp(2f), rect.right - rad, rect.top + dp(2f), line)
    }

    // --- icons ------------------------------------------------------------------
    fun icon(c: Canvas, code: Int, cx: Float, cy: Float, s: Float, color: Int) {
        fill.style = Paint.Style.FILL
        fill.color = color
        line.color = color
        line.strokeWidth = maxOf(dp(1.6f), s * 0.28f)
        when (code) {
            ICON_PAUSE -> {
                r2.set(cx - s * 0.75f, cy - s, cx - s * 0.2f, cy + s)
                c.drawRoundRect(r2, s * 0.15f, s * 0.15f, fill)
                r2.set(cx + s * 0.2f, cy - s, cx + s * 0.75f, cy + s)
                c.drawRoundRect(r2, s * 0.15f, s * 0.15f, fill)
            }
            ICON_PLAY -> {
                path.reset()
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx + s * 0.95f, cy)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.close()
                c.drawPath(path, fill)
            }
            ICON_BACK -> {
                line.strokeWidth = maxOf(dp(2f), s * 0.34f)
                c.drawLine(cx + s * 0.8f, cy, cx - s * 0.8f, cy, line)
                c.drawLine(cx - s * 0.8f, cy, cx - s * 0.05f, cy - s * 0.75f, line)
                c.drawLine(cx - s * 0.8f, cy, cx - s * 0.05f, cy + s * 0.75f, line)
            }
            ICON_CLOSE -> {
                c.drawLine(cx - s * 0.8f, cy - s * 0.8f, cx + s * 0.8f, cy + s * 0.8f, line)
                c.drawLine(cx - s * 0.8f, cy + s * 0.8f, cx + s * 0.8f, cy - s * 0.8f, line)
            }
            ICON_PLUS -> {
                c.drawLine(cx - s * 0.8f, cy, cx + s * 0.8f, cy, line)
                c.drawLine(cx, cy - s * 0.8f, cx, cy + s * 0.8f, line)
            }
            ICON_MINUS -> c.drawLine(cx - s * 0.8f, cy, cx + s * 0.8f, cy, line)
            ICON_CHECK -> {
                c.drawLine(cx - s * 0.8f, cy, cx - s * 0.2f, cy + s * 0.6f, line)
                c.drawLine(cx - s * 0.2f, cy + s * 0.6f, cx + s * 0.9f, cy - s * 0.7f, line)
            }
            ICON_HEART -> {
                path.reset()
                path.moveTo(cx, cy + s * 0.95f)
                path.cubicTo(cx - s * 1.6f, cy - s * 0.1f, cx - s * 0.8f, cy - s * 1.25f, cx, cy - s * 0.4f)
                path.cubicTo(cx + s * 0.8f, cy - s * 1.25f, cx + s * 1.6f, cy - s * 0.1f, cx, cy + s * 0.95f)
                path.close()
                c.drawPath(path, fill)
            }
            ICON_COIN -> {
                fill.color = Palette.GOLD
                c.drawCircle(cx, cy, s, fill)
                line.color = Palette.GOLD_DARK
                line.strokeWidth = maxOf(dp(1.2f), s * 0.2f)
                c.drawCircle(cx, cy, s * 0.62f, line)
            }
            ICON_FLAG -> {
                c.drawLine(cx - s * 0.6f, cy + s, cx - s * 0.6f, cy - s, line)
                path.reset()
                path.moveTo(cx - s * 0.6f, cy - s)
                path.lineTo(cx + s * 0.9f, cy - s * 0.4f)
                path.lineTo(cx - s * 0.6f, cy + s * 0.2f)
                path.close()
                c.drawPath(path, fill)
            }
            ICON_LOCK -> {
                r2.set(cx - s * 0.8f, cy - s * 0.1f, cx + s * 0.8f, cy + s * 0.95f)
                c.drawRoundRect(r2, s * 0.2f, s * 0.2f, fill)
                line.strokeWidth = maxOf(dp(1.4f), s * 0.24f)
                r2.set(cx - s * 0.5f, cy - s * 0.95f, cx + s * 0.5f, cy + s * 0.35f)
                c.drawArc(r2, 180f, 180f, false, line)
                c.drawLine(cx - s * 0.5f, cy - s * 0.3f, cx - s * 0.5f, cy - s * 0.05f, line)
                c.drawLine(cx + s * 0.5f, cy - s * 0.3f, cx + s * 0.5f, cy - s * 0.05f, line)
            }
            ICON_STAR -> {
                path.reset()
                for (i in 0 until 10) {
                    val a = -1.5708f + i * 0.6283f
                    val rad = if (i % 2 == 0) s else s * 0.42f
                    val px = cx + cos(a) * rad
                    val py = cy + sin(a) * rad
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, fill)
            }
            ICON_CHEVRON -> {
                line.strokeWidth = maxOf(dp(1.8f), s * 0.3f)
                for (i in 0 until 3) {
                    val ox = cx + (i - 1) * s * 0.75f
                    c.drawLine(ox - s * 0.3f, cy - s * 0.7f, ox + s * 0.3f, cy, line)
                    c.drawLine(ox + s * 0.3f, cy, ox - s * 0.3f, cy + s * 0.7f, line)
                }
            }
            ICON_GEAR -> {
                for (i in 0 until 8) {
                    c.save()
                    c.rotate(i * 45f, cx, cy)
                    r2.set(cx - s * 0.2f, cy - s * 1.05f, cx + s * 0.2f, cy - s * 0.6f)
                    c.drawRect(r2, fill)
                    c.restore()
                }
                c.drawCircle(cx, cy, s * 0.72f, fill)
                fill.color = 0xFF1B222C.toInt()
                c.drawCircle(cx, cy, s * 0.3f, fill)
            }
            ICON_BOLT -> {
                path.reset()
                path.moveTo(cx + s * 0.2f, cy - s)
                path.lineTo(cx - s * 0.65f, cy + s * 0.15f)
                path.lineTo(cx - s * 0.05f, cy + s * 0.15f)
                path.lineTo(cx - s * 0.2f, cy + s)
                path.lineTo(cx + s * 0.65f, cy - s * 0.2f)
                path.lineTo(cx + s * 0.05f, cy - s * 0.2f)
                path.close()
                c.drawPath(path, fill)
            }
            ICON_SNOW -> {
                line.strokeWidth = maxOf(dp(1.4f), s * 0.2f)
                for (i in 0 until 3) {
                    c.save()
                    c.rotate(i * 60f, cx, cy)
                    c.drawLine(cx, cy - s, cx, cy + s, line)
                    c.drawLine(cx - s * 0.3f, cy - s * 0.65f, cx, cy - s * 0.35f, line)
                    c.drawLine(cx + s * 0.3f, cy - s * 0.65f, cx, cy - s * 0.35f, line)
                    c.restore()
                }
            }
            ICON_BLAST -> {
                path.reset()
                for (i in 0 until 16) {
                    val a = i * 0.3927f
                    val rad = if (i % 2 == 0) s else s * 0.55f
                    val px = cx + cos(a) * rad
                    val py = cy + sin(a) * rad
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, fill)
            }
            ICON_TARGET -> {
                line.strokeWidth = maxOf(dp(1.4f), s * 0.2f)
                c.drawCircle(cx, cy, s * 0.7f, line)
                c.drawLine(cx - s, cy, cx - s * 0.35f, cy, line)
                c.drawLine(cx + s * 0.35f, cy, cx + s, cy, line)
                c.drawLine(cx, cy - s, cx, cy - s * 0.35f, line)
                c.drawLine(cx, cy + s * 0.35f, cx, cy + s, line)
            }
        }
    }

    companion object {
        const val PRIMARY = 0
        const val SECONDARY = 1
        const val DANGER = 2
        const val GOLD = 3
        const val GHOST = 4
        const val DISABLED = 5
        const val SELECTED = 6

        const val ICON_PAUSE = 1
        const val ICON_PLAY = 2
        const val ICON_BACK = 3
        const val ICON_CLOSE = 4
        const val ICON_PLUS = 5
        const val ICON_MINUS = 6
        const val ICON_CHECK = 7
        const val ICON_HEART = 8
        const val ICON_COIN = 9
        const val ICON_FLAG = 10
        const val ICON_LOCK = 11
        const val ICON_STAR = 12
        const val ICON_CHEVRON = 13
        const val ICON_GEAR = 14
        const val ICON_BOLT = 15
        const val ICON_SNOW = 16
        const val ICON_BLAST = 17
        const val ICON_TARGET = 18

        private val BOLD: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        private val REGULAR: Typeface = Typeface.DEFAULT

        // top, bottom, outline
        private val STYLE_COLORS = arrayOf(
            intArrayOf(0xFF4CC46A.toInt(), 0xFF2E9A4D.toInt(), 0xFF1B5E30.toInt()),
            intArrayOf(0xFF50617A.toInt(), 0xFF38465C.toInt(), 0xFF1D2636.toInt()),
            intArrayOf(0xFFE0594F.toInt(), 0xFFB93A33.toInt(), 0xFF6B1E1A.toInt()),
            intArrayOf(0xFFFFC94A.toInt(), 0xFFE09A22.toInt(), 0xFF8A5A10.toInt()),
            intArrayOf(0x66202A38, 0x66202A38, 0x88506078.toInt()),
            intArrayOf(0xFF3A404A.toInt(), 0xFF2D323A.toInt(), 0xFF22262D.toInt()),
            intArrayOf(0xFF4E90E8.toInt(), 0xFF3669B8.toInt(), 0xFF1D3D70.toInt())
        )
    }
}
