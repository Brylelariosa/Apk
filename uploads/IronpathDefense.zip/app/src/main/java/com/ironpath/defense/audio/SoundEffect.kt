package com.ironpath.defense.audio

/**
 * Every sound the game can make. If `assets/audio/<assetFileName>` exists it
 * is used; otherwise the sound is synthesized in code by [SoundSynth], so the
 * game is never silent just because no audio files were shipped. [minGapMs]
 * rate-limits spammy effects and [gain] balances loudness between effects.
 */
enum class SoundEffect(val assetFileName: String?, val minGapMs: Int = 0, val gain: Float = 1f) {
    SHOOT("shoot.ogg", 60, 0.5f),
    HIT("hit.ogg", 45, 0.45f),
    EXPLOSION("explosion.ogg", 70, 0.8f),
    TOWER_PLACE("tower_place.ogg"),
    TOWER_UPGRADE("tower_upgrade.ogg"),
    TOWER_SELL("tower_sell.ogg"),
    WAVE_START("wave_start.ogg"),
    LIFE_LOST("life_lost.ogg"),
    BUTTON_TAP("button_tap.ogg", 30, 0.7f),
    VICTORY("victory.ogg"),
    GAME_OVER("game_over.ogg"),
    SHOOT_ARROW(null, 55, 0.5f),
    SHOOT_CANNON(null, 90, 0.75f),
    SHOOT_FROST(null, 80, 0.45f),
    SHOOT_SNIPER(null, 90, 0.7f),
    SHOOT_LIGHTNING(null, 70, 0.55f),
    SHOOT_FLAME(null, 120, 0.3f),
    ENEMY_DIE(null, 40, 0.5f),
    WAVE_CLEAR(null),
    BOSS_WARN(null),
    ABILITY(null),
    FREEZE(null, 120, 0.5f),
    STEAM(null, 150, 0.5f),
    FUSION(null),
    ERROR(null, 100, 0.7f),
    COUNTDOWN(null),
    SHIELD_BREAK(null, 120, 0.6f),
    EMP(null),
    SUMMON(null, 150, 0.6f)
}
