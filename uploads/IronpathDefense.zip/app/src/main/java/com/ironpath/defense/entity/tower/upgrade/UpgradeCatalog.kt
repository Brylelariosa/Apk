package com.ironpath.defense.entity.tower.upgrade

import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.zone.ZoneKind

/**
 * The full upgrade tree for every tower: three bespoke paths of five tiers
 * each, plus six cross-path fusions per tower (one per ordered path pair).
 *
 * Paths are NOT shared categories. Each one is a different way to evolve the
 * *same* weapon around that weapon's own mechanics — piercing ballistae vs
 * archer volleys vs fire arrows; siege mortars vs gatling cannons vs
 * demolition shells; and so on. Most tiers add a behavior (piercing, shred,
 * spreading fire, death blasts, lingering zones, special volleys, ramping fire
 * rate, support auras, EMP silence) rather than just a number.
 *
 * Path colors double as the visual accent for evolved towers.
 */
object UpgradeCatalog {
    private fun up(name: String, description: String, cost: Int, vararg mods: StatModifier) =
        TowerUpgrade(name, description, cost, mods.toList())

    private fun path(name: String, colorArgb: Int, tagline: String, vararg upgrades: TowerUpgrade) =
        UpgradePath(name, colorArgb, tagline, upgrades.toList())

    private fun perk(main: Int, cross: Int, name: String, description: String, vararg mods: StatModifier) =
        CrossPerk(main, cross, name, description, mods.toList())

    private val FIRE = ZoneKind.FIRE.id
    private val TOXIC = ZoneKind.TOXIC.id
    private val FROSTZ = ZoneKind.FROST.id

    // ======================================================================
    // ARCHER — a wooden watchtower. Ballista / Volley Corps / Pyre Fletcher.
    // ======================================================================
    val ARCHER: List<UpgradePath> = listOf(
        path("Bowmaster", 0xFFE8C06A.toInt(), "Piercing bolts that evolve into a siege ballista.",
            up("Longbow", "Tall yew bow: +20% range and arrows pierce one enemy.", 60, Mods.range(1.2f), Mods.pierce(1)),
            up("Bodkin Points", "Steel heads: +6 armor pen, +20% damage, pierce +1.", 120, Mods.armorPen(6f), Mods.damage(1.2f), Mods.pierce(1)),
            up("Eagle Eye", "22% crit chance for triple damage and +10% range.", 280, Mods.crit(0.22f, 3f), Mods.range(1.1f)),
            up("Ballista Frame", "Heavy bolts skewer a whole line: x2.6 damage, pierce +3, slower.", 640,
                Mods.damage(2.6f), Mods.cooldown(1.35f), Mods.pierce(3), Mods.range(1.2f), Mods.projectile(ProjectileType.BALLISTA_BOLT)),
            up("Skewer Battery", "Bolts pierce the whole line, 40% crits, execute weak foes, +40% vs bosses.", 1700,
                Mods.pierce(6), Mods.crit(0.4f, 3.5f), Mods.execute(0.12f), Mods.bossDamage(1.4f), Mods.damage(1.3f))
        ),
        path("Volley Corps", 0xFF6FB6FF.toInt(), "More bows, more arrows, rain from above.",
            up("Quick Draw", "Drilled archers reload 22% faster.", 60, Mods.cooldown(0.78f)),
            up("Twin Nock", "Fires two arrows per volley at different targets.", 130, Mods.multishot(1)),
            up("Fan Volley", "Three-arrow fan and a faster reload.", 290, Mods.multishot(1), Mods.cooldown(0.9f)),
            up("Rain of Arrows", "Every 4th volley rains 6 extra exploding arrows on the pack.", 660,
                Mods.special(4, 6, 0.9f, 28f), Mods.damage(1.15f)),
            up("Arrow Storm", "+3 arrows per volley; every 3rd volley rains 10 more arrows.", 1650,
                Mods.multishot(3), Mods.special(3, 10, 1f, 34f), Mods.cooldown(0.85f))
        ),
        path("Pyre Fletcher", 0xFFFF7A3C.toInt(), "Tar, oil and wildfire.",
            up("Pitch Tips", "Tar-soaked heads ignite targets: 6 burn damage/s for 3s.", 55, Mods.burn(6f, 3f)),
            up("Oil Flasks", "Arrows shatter oil flasks that leave burning ground (10/s, 3s).", 125, Mods.zone(FIRE, 10f, 38f, 3f)),
            up("Explosive Tips", "Powder-packed heads detonate: 42 splash, +25% damage.", 275, Mods.splash(42f), Mods.damage(1.25f)),
            up("Wildfire", "Burning enemies ignite neighbors within 70 and burn at 30/s.", 620, Mods.burn(30f, 3.5f), Mods.burnSpread(70f)),
            up("Dragon's Breath", "Burn 70/s, burning kills blast for 70, and a fire nova every 2.6s.", 1600,
                Mods.burn(70f, 4f), Mods.deathBlast(70f, 60f), Mods.pulse(55f, 2.6f, 120f), Mods.splash(14f))
        )
    )

    val ARCHER_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Ballista Battery", "A second ballista fires with the first: +1 bolt per volley.", Mods.multishot(1), Mods.pierce(1)),
        perk(0, 2, "Burning Bolts", "Skewering bolts ignite everything they pass and leave fire behind.", Mods.burn(24f, 3.5f), Mods.zone(FIRE, 12f, 34f, 2.5f)),
        perk(1, 0, "Marksman Volley", "Every arrow in the volley pierces and can crit (15%).", Mods.pierce(1), Mods.crit(0.15f, 2.5f)),
        perk(1, 2, "Fire Rain", "Every volley arrow bursts into flame: 30 splash and 14 burn/s.", Mods.splash(30f), Mods.burn(14f, 3f)),
        perk(2, 0, "Sniper's Flame", "Fire arrows punch armor (+8 pen) and hit 25% harder at +10% range.", Mods.armorPen(8f), Mods.damage(1.25f), Mods.range(1.1f)),
        perk(2, 1, "Cinder Volley", "Extra arrow per volley and fire spreads 25 further.", Mods.multishot(1), Mods.burnSpread(95f))
    )

    // ======================================================================
    // CANNON — a stone fort. Siege Engine / Gatling Works / Demolition.
    // ======================================================================
    val CANNON: List<UpgradePath> = listOf(
        path("Siege Engine", 0xFFE08A4A.toInt(), "Mortars, cluster shells and the doomsday round.",
            up("Heavy Shot", "Denser iron: +35% damage and +10 blast radius.", 90, Mods.damage(1.35f), Mods.splash(10f)),
            up("Mortar Conversion", "Long-barrel mortar: +30% range, +15% damage.", 180, Mods.range(1.3f), Mods.damage(1.15f), Mods.cooldown(1.1f)),
            up("Cluster Shells", "Each shell bursts into 3 secondary blasts around impact.", 430, Mods.cluster(3, 0.4f)),
            up("Siege Mortar", "Siege-grade mortar: x2 damage, +26 blast, +15% range.", 980, Mods.damage(2f), Mods.splash(26f), Mods.range(1.15f)),
            up("Doomsday Shell", "Every 4th shell is a doomsday round: x3 damage, huge blast, stuns.", 2400,
                Mods.special(4, 0, 3f, 70f, 0, 1.2f), Mods.cluster(4, 0.45f))
        ),
        path("Gatling Works", 0xFF9AA7B8.toInt(), "Rotary barrels and a hail of shells.",
            up("Oiled Gears", "Reloads 20% faster.", 90, Mods.cooldown(0.8f)),
            up("Rapid Loader", "Reloads another 25% faster.", 170, Mods.cooldown(0.75f)),
            up("Twin Barrels", "Fires two shells per volley at different targets.", 410, Mods.multishot(1), Mods.damage(0.9f)),
            up("Gatling Cannon", "Rotary barrels: fire rate climbs up to +60% while it keeps firing.", 920, Mods.ramp(0.6f), Mods.cooldown(0.85f)),
            up("Hellstorm", "Ramp to +100%; every 6th volley launches 6 extra rockets.", 2200,
                Mods.ramp(1f), Mods.multishot(1), Mods.special(6, 6, 0.8f, 20f))
        ),
        path("Demolition", 0xFFD9534F.toInt(), "Armor shredding and shield breaking.",
            up("Armor-Piercing Rounds", "+10 armor penetration.", 100, Mods.armorPen(10f)),
            up("Sunder Shells", "Each hit strips 12% of the target's armor (stacks).", 190, Mods.shred(0.12f)),
            up("Fracture Charges", "+40% damage to armored targets and +40% to shields.", 440, Mods.armoredBonus(1.4f), Mods.shieldBreak(1.4f)),
            up("Wrecking Crew", "Bosses/elites take +45%, shields +35%, stronger shred.", 1000, Mods.shred(0.2f), Mods.bossDamage(1.45f), Mods.shieldBreak(1.35f)),
            up("Titan Breaker", "x2 damage, executes weakened non-elites, armor melts away.", 2300,
                Mods.damage(2f), Mods.execute(0.15f), Mods.shred(0.3f), Mods.armorPen(10f))
        )
    )

    val CANNON_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Barrage Mortar", "Mortar volleys: +1 shell and a faster reload.", Mods.multishot(1), Mods.cooldown(0.85f)),
        perk(0, 2, "Bunker Buster", "Siege shells shred armor and crack shields.", Mods.shred(0.2f), Mods.shieldBreak(1.4f), Mods.armoredBonus(1.3f)),
        perk(1, 0, "Cluster Gatling", "Rapid shells scatter two mini-blasts.", Mods.cluster(2, 0.3f), Mods.splash(8f)),
        perk(1, 2, "AP Gatling", "Rapid shells strip armor and ignore 8 more.", Mods.shred(0.1f), Mods.armorPen(8f)),
        perk(2, 0, "Mortar Sunder", "Armor-breaking shells reach 20% further with a wider blast.", Mods.range(1.2f), Mods.splash(16f)),
        perk(2, 1, "Rapid Breaker", "Faster reload and one extra shell.", Mods.cooldown(0.8f), Mods.multishot(1))
    )

    // ======================================================================
    // FROST — a crystal spire. Permafrost / Blizzard / Shatter.
    // ======================================================================
    val FROST: List<UpgradePath> = listOf(
        path("Permafrost", 0xFF6FB8FF.toInt(), "Lock the lane: deep chills and flash freezes.",
            up("Deep Chill", "Slows to 50% for 2s.", 70, Mods.slow(0.5f, 2f)),
            up("Icy Grip", "Slows to 42% for 2.6s and +30% damage.", 140, Mods.slow(0.42f, 2.6f), Mods.damage(1.3f)),
            up("Flash Freeze", "20% chance to freeze enemies solid for 1.2s.", 330, Mods.freeze(0.2f, 1.2f)),
            up("Glacial Lock", "35% freeze for 1.6s; chilled foes take +15% damage.", 720, Mods.freeze(0.35f, 1.6f), Mods.mark(0.15f, 2.5f)),
            up("Absolute Zero", "60% freeze for 2.2s, near-total slow, +25% damage taken.", 1900,
                Mods.freeze(0.6f, 2.2f), Mods.slow(0.3f, 3f), Mods.mark(0.25f, 3f))
        ),
        path("Blizzard", 0xFFBFEFFF.toInt(), "Waves of frost across the whole battlefield.",
            up("Frost Burst", "Shards burst on impact: +34 splash.", 80, Mods.splash(34f)),
            up("Snow Flurry", "Faster, wider bursts.", 150, Mods.cooldown(0.8f), Mods.splash(12f)),
            up("Winter Nova", "Releases a frost nova every 2.2s (30 dmg, 115 radius).", 340, Mods.pulse(30f, 2.2f, 115f)),
            up("Frozen Ground", "Impacts leave frost patches that slow to 65% for 3s.", 780, Mods.zone(FROSTZ, 0f, 48f, 3f, 0.65f)),
            up("Ice Age", "Huge nova every 1.3s; a permanent blizzard slows everything in range.", 1900,
                Mods.pulse(150f, 1.3f, 170f), Mods.range(1.15f), Mods.zone(FROSTZ, 4f, 60f, 3.5f, 0.55f))
        ),
        path("Shatter", 0xFFB08CFF.toInt(), "Chill, then break them.",
            up("Razor Shards", "Sharper ice: +50% damage and +3 armor pen.", 70, Mods.damage(1.5f), Mods.armorPen(3f)),
            up("Brittle Cold", "Chilled enemies take +18% damage; +4 armor pen.", 150, Mods.mark(0.18f, 2.5f), Mods.armorPen(4f)),
            up("Prism Lens", "Shards split: +1 shard at another target, +20% damage.", 350, Mods.multishot(1), Mods.damage(1.2f)),
            up("Shatterpoint", "20% crits (x2.5); kills shatter into ice shards (45 dmg).", 800, Mods.crit(0.2f, 2.5f), Mods.deathBlast(45f, 58f)),
            up("Cryo Cannon", "x2.2 damage, executes 18% weakened foes, bigger shatter blasts.", 1950,
                Mods.damage(2.2f), Mods.execute(0.18f), Mods.deathBlast(90f, 75f), Mods.cooldown(1.1f))
        )
    )

    val FROST_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Whiteout", "Frozen ground and a chill nova blanket the lane.", Mods.zone(FROSTZ, 0f, 55f, 2.5f, 0.6f), Mods.pulse(18f, 2.8f, 105f)),
        perk(0, 2, "Brittle Lock", "Chilled foes take +30% damage and shatter on death.", Mods.mark(0.3f, 3f), Mods.deathBlast(50f, 55f)),
        perk(1, 0, "Glacier Field", "Bursts freeze (25% for 0.9s) and chill harder.", Mods.freeze(0.25f, 0.9f), Mods.slow(0.5f, 2f)),
        perk(1, 2, "Icicle Storm", "Bursts pierce armor (+6) and hit 20% harder.", Mods.armorPen(6f), Mods.damage(1.2f)),
        perk(2, 0, "Cold Snap Rounds", "Shatter shards chill hard (45% for 2s) and hit 25% harder.", Mods.slow(0.45f, 2f), Mods.damage(1.25f)),
        perk(2, 1, "Snowburst Shards", "Shards burst on impact: +40 splash.", Mods.splash(40f))
    )

    // ======================================================================
    // RANGER — a long-rifle watchpost. Precision / Tactical / Advanced Rifle.
    // ======================================================================
    val RANGER: List<UpgradePath> = listOf(
        path("Precision", 0xFFFFD166.toInt(), "Weak points, crits and the perfect shot.",
            up("Scope", "Long-range optics: +20% range, +15% damage.", 110, Mods.range(1.2f), Mods.damage(1.15f)),
            up("Weak-Point Targeting", "+12 armor pen and +40% damage to armored targets.", 230, Mods.armorPen(12f), Mods.armoredBonus(1.4f)),
            up("Elite Marksman", "25% crits for x2.5 and a faster bolt action.", 520, Mods.crit(0.25f, 2.5f), Mods.cooldown(0.85f)),
            up("Anti-Materiel Rifle", "x2.2 damage, +16 armor pen, +40% vs bosses; slower.", 1150,
                Mods.damage(2.2f), Mods.armorPen(16f), Mods.bossDamage(1.4f), Mods.cooldown(1.15f)),
            up("Deadshot", "40% crits for x4, executes foes below 25%, +20% range.", 2600,
                Mods.crit(0.4f, 4f), Mods.execute(0.25f), Mods.range(1.2f), Mods.damage(1.2f))
        ),
        path("Tactical", 0xFF5DD6FF.toInt(), "Mark targets and command the defense.",
            up("Spotter Scope", "Marks targets: all towers deal +12% damage to them for 3s.", 110, Mods.mark(0.12f, 3f)),
            up("Field Intel", "Longer marks (+18%, 4s); nearby towers gain +10% range.", 230, Mods.mark(0.18f, 4f), Mods.aura(150f, 0f, 0f, 0.1f)),
            up("Fire Control", "Command aura (r170): nearby towers deal +15% damage.", 540, Mods.aura(170f, 0.15f, 0f, 0.1f)),
            up("Coordinated Fire", "Aura +25% damage, +10% rate; marked kills pay +4 gold.", 1200,
                Mods.aura(190f, 0.25f, 0.1f, 0.1f), Mods.bounty(4), Mods.mark(0.22f, 4f)),
            up("Battlefield Command", "Aura r230: +35% damage, +15% rate, +12% range; every 5th shot is a strike.", 2700,
                Mods.aura(230f, 0.35f, 0.15f, 0.12f), Mods.special(5, 0, 2.5f, 60f), Mods.mark(0.3f, 5f), Mods.bounty(8))
        ),
        path("Advanced Rifle", 0xFFFF7BAC.toInt(), "Faster actions, piercing rounds, railguns.",
            up("Speed Loader", "Reloads 20% faster.", 110, Mods.cooldown(0.8f)),
            up("Piercing Rounds", "Rounds punch through 2 enemies in a line.", 230, Mods.pierce(2)),
            up("Burst Rifle", "Every 3rd shot fires a 3-round burst.", 520, Mods.special(3, 2, 0.8f, 0f)),
            up("Railgun Conversion", "Rail slugs: x1.8 damage and +4 pierce.", 1150, Mods.damage(1.8f), Mods.pierce(4), Mods.projectile(ProjectileType.RAIL_SLUG)),
            up("Gauss Cannon", "Slugs pierce everything; every 4th shot is a x3 charged shot.", 2600,
                Mods.pierce(11), Mods.damage(1.5f), Mods.special(4, 0, 3f, 0f))
        )
    )

    val RANGER_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Spotter's Mark", "Precision hits mark for allies (+20%, 4s) and aid nearby range.", Mods.mark(0.2f, 4f), Mods.aura(150f, 0.1f, 0f, 0.1f)),
        perk(0, 2, "Penetrator", "Rounds pierce two enemies and ignore 8 more armor.", Mods.pierce(2), Mods.armorPen(8f)),
        perk(1, 0, "Designated Target", "Command post rounds crit 15% for x2 and ignore 6 armor.", Mods.crit(0.15f, 2f), Mods.armorPen(6f)),
        perk(1, 2, "Fire Support", "Command post fires 15% faster and pierces one target.", Mods.cooldown(0.85f), Mods.pierce(1)),
        perk(2, 0, "Rail Sniper", "Rail slugs crit 20% for x3 and reach 10% further.", Mods.crit(0.2f, 3f), Mods.range(1.1f)),
        perk(2, 1, "Targeting Rails", "Rail slugs mark everything they pierce (+20%).", Mods.mark(0.2f, 3.5f))
    )

    // ======================================================================
    // LIGHTNING — a tesla coil. Voltage / Chain Reaction / Electromagnetic.
    // ======================================================================
    val LIGHTNING: List<UpgradePath> = listOf(
        path("Voltage", 0xFFFFE066.toInt(), "Raw power: overcharged bolts and thunder strikes.",
            up("High Voltage", "+40% damage.", 130, Mods.damage(1.4f)),
            up("Capacitor Bank", "Faster recharge and +15% damage.", 260, Mods.cooldown(0.8f), Mods.damage(1.15f)),
            up("Overcharge", "Every 4th bolt: x2.5 damage, +2 chain links, brief stun.", 580, Mods.special(4, 0, 2.5f, 0f, 2, 0.5f)),
            up("Lightning Rod", "x2 damage, +15% range, 20% crits.", 1300, Mods.damage(2f), Mods.range(1.15f), Mods.crit(0.2f, 2.5f)),
            up("Zeus' Wrath", "Every 3rd bolt is a thunder strike: x5 damage, 90 blast, +40% vs bosses.", 2900,
                Mods.special(3, 0, 5f, 90f, 0, 0.8f), Mods.bossDamage(1.4f), Mods.damage(1.3f))
        ),
        path("Chain Reaction", 0xFF7DF9FF.toInt(), "Arcs that leap farther and detonate.",
            up("Conductive Coil", "+1 chain link and +20 reach.", 130, Mods.chain(1, 20f, 0.7f)),
            up("Superconductor", "Chains keep 80% damage; +1 link.", 260, Mods.chain(1, 15f, 0.8f)),
            up("Arc Storm", "+2 links, +25 reach, +30% damage.", 590, Mods.chain(2, 25f, 0.8f), Mods.damage(1.3f)),
            up("Chain Detonation", "Every link detonates in a 36 radius blast; +1 link.", 1350, Mods.splash(36f), Mods.chain(1, 10f, 0.85f)),
            up("Tesla Web", "+4 links with no loss, plus a crackling web pulse every 2s.", 3000,
                Mods.chain(4, 30f, 1f), Mods.pulse(55f, 2f, 160f))
        ),
        path("Electromagnetic", 0xFFB388FF.toInt(), "EMP: slow, stun and silence.",
            up("Ionized Air", "Bolts slow by 15% and mark targets (+12%).", 140, Mods.slow(0.85f, 1.5f), Mods.mark(0.12f, 2f)),
            up("EMP Pulse", "EMP every 3s: 30 damage and silences abilities for 2.5s.", 270, Mods.pulse(30f, 3f, 115f), Mods.silence(2.5f)),
            up("Magnetic Field", "Bigger, faster EMP, +15% range, shields take double.", 620, Mods.pulse(55f, 2.2f, 135f), Mods.range(1.15f), Mods.shieldBreak(2f)),
            up("Stun Coil", "25% stun chance (0.9s) and EMP strips 15% armor.", 1400, Mods.freeze(0.25f, 0.9f), Mods.shred(0.15f)),
            up("Electromagnetic Storm", "EMP storm every 1.2s: 220 damage, 30% stun, 3.5s silence.", 3100,
                Mods.pulse(220f, 1.2f, 170f), Mods.freeze(0.3f, 1.1f), Mods.silence(3.5f))
        )
    )

    val LIGHTNING_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Forked Lightning", "Overcharged bolts chain three more times.", Mods.chain(3, 20f, 0.9f)),
        perk(0, 2, "Static Discharge", "Strong bolts also slow (70%) and silence for 2s.", Mods.slow(0.7f, 2f), Mods.silence(2f)),
        perk(1, 0, "Chain Lightning Prime", "Chain links hit 35% harder with no loss.", Mods.damage(1.35f), Mods.chain(0, 0f, 1f)),
        perk(1, 2, "Magnetized Chains", "Every chain link slows (75%) and marks (+15%).", Mods.slow(0.75f, 1.5f), Mods.mark(0.15f, 2.5f)),
        perk(2, 0, "Shockfield", "EMP pulses hit for 70 and briefly stun.", Mods.pulse(70f, 2.2f, 140f), Mods.freeze(0.2f, 0.7f)),
        perk(2, 1, "Conductive Field", "EMP arcs: +2 chain links, 10% faster.", Mods.chain(2, 20f, 0.8f), Mods.cooldown(0.9f))
    )

    // ======================================================================
    // FLAMETHROWER — an industrial burner. Inferno / Combustion / Experimental Fuel.
    // ======================================================================
    val FLAME: List<UpgradePath> = listOf(
        path("Inferno", 0xFFFF5A1F.toInt(), "A flamethrower that becomes a furnace.",
            up("Wide Nozzle", "Flared nozzle: wider flames (+12) and +10% range.", 90, Mods.splash(12f), Mods.range(1.1f)),
            up("Hot Fuel", "+40% damage; burn 12/s for 2.5s.", 170, Mods.damage(1.4f), Mods.burn(12f, 2.5f)),
            up("Melting Point", "Flames melt armor: each hit strips 8% (stacks).", 400, Mods.shred(0.08f), Mods.armorPen(4f)),
            up("Firestorm", "+60% damage; every 6th burst is a fireball (x3, +44 blast).", 900,
                Mods.damage(1.6f), Mods.splash(14f), Mods.special(6, 0, 3f, 44f)),
            up("Massive Inferno", "Stream pierces the crowd; +80% damage, ramp +50%, burn 60/s.", 2100,
                Mods.damage(1.8f), Mods.pierce(4), Mods.ramp(0.5f), Mods.burn(60f, 3f), Mods.range(1.15f))
        ),
        path("Combustion", 0xFFFFC233.toInt(), "Fire that spreads, explodes and chains.",
            up("Kindling", "Burning enemies ignite neighbors within 55.", 90, Mods.burnSpread(55f)),
            up("Flashpoint", "Burning enemies explode on death (60 damage, r50).", 170, Mods.deathBlast(60f, 50f)),
            up("Scorched Earth", "Flames leave burning ground (18/s for 3s).", 390, Mods.zone(FIRE, 18f, 42f, 3f)),
            up("Chain Reaction", "Explosions are larger (120, r68) and fire spreads to 85.", 880, Mods.deathBlast(120f, 68f), Mods.burnSpread(85f)),
            up("Conflagration", "Firestorm pulse every 1.6s, spread 100, blasts of 200.", 2050,
                Mods.pulse(140f, 1.6f, 150f), Mods.burnSpread(100f), Mods.deathBlast(200f, 80f))
        ),
        path("Experimental Fuel", 0xFF8CFF4A.toInt(), "Chemical flames, napalm and super-fuel.",
            up("Chemical Additive", "Green chemical fire: +8 armor pen, burn 10/s.", 100, Mods.armorPen(8f), Mods.burn(10f, 2.2f), Mods.dotColor(0xFF8CFF4A.toInt())),
            up("Toxic Smoke", "Leaves poison clouds (14/s, r55); poisoned foes take +12%.", 180, Mods.zone(TOXIC, 14f, 55f, 3f), Mods.mark(0.12f, 3f)),
            up("Napalm Lobber", "Lobs fuel globs: +60% range, bigger blasts, leaves fire pools.", 420,
                Mods.projectile(ProjectileType.FUEL_GLOB), Mods.range(1.6f), Mods.cooldown(5.5f), Mods.damage(5.5f), Mods.splash(20f), Mods.zone(FIRE, 16f, 46f, 3.5f)),
            up("Volatile Mix", "Every 4th glob detonates (x3, +50 blast); burn 40/s; kills blast.", 900,
                Mods.special(4, 0, 3f, 50f), Mods.burn(40f, 3f), Mods.deathBlast(80f, 60f)),
            up("Super-Fuel", "x2 damage, burn 120/s, executes 15% weakened foes, +20% range.", 2150,
                Mods.damage(2f), Mods.burn(120f, 3.5f), Mods.execute(0.15f), Mods.range(1.2f), Mods.cooldown(0.85f))
        )
    )

    val FLAME_PERKS: List<CrossPerk> = listOf(
        perk(0, 1, "Blazing Spread", "Inferno flames spread fire (r70) and burning kills blast for 80.", Mods.burnSpread(70f), Mods.deathBlast(80f, 55f)),
        perk(0, 2, "Acid Fire", "Melting flames burn through shields and armor; poisoned foes take +12%.", Mods.shieldBreak(1.5f), Mods.armoredBonus(1.25f), Mods.mark(0.12f, 3f)),
        perk(1, 0, "Searing Blasts", "Explosions strip 15% armor and ignite for 25/s.", Mods.shred(0.15f), Mods.burn(25f, 3f)),
        perk(1, 2, "Toxic Blasts", "Burning ground turns toxic (16/s, r55) and marks foes.", Mods.zone(TOXIC, 16f, 55f, 3.5f), Mods.mark(0.1f, 2.5f)),
        perk(2, 0, "Chemical Inferno", "Fuel burns hotter: +30% damage and 30 burn/s.", Mods.damage(1.3f), Mods.burn(30f, 3f)),
        perk(2, 1, "Explosive Fuel", "Globs ignite neighbors (r60) and burning kills blast for 70.", Mods.burnSpread(60f), Mods.deathBlast(70f, 52f))
    )
}
