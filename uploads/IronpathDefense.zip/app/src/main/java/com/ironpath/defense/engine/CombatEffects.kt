package com.ironpath.defense.engine

import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.audio.SoundEffect
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.Fx
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.projectile.ShotProfile
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.settings.SettingsSystem
import kotlin.random.Random

/**
 * The one place combat events become *spectacle*: particles, rings, damage
 * numbers, screen shake and sound. Combat code only reports what happened
 * (see [CombatFeedback]); everything about how it looks and sounds lives here.
 * Optional sinks forward a couple of events to the run (Director telemetry).
 */
class CombatEffects(
    private val particles: ParticleSystem,
    private val audio: AudioSystem,
    private val settings: SettingsSystem,
    private val juice: Juice
) : CombatFeedback {
    var damageSink: ((sourceType: Int, amount: Float) -> Unit)? = null
    var steamSink: (() -> Unit)? = null
    private val tmp = Vector2()
    private var lastHitSoundNanos = 0L

    override fun onEnemyHit(enemy: Enemy, damageDealt: Float, isCrit: Boolean, sourceType: Int) {
        damageSink?.invoke(sourceType, damageDealt)
        val color = TowerType.entries.getOrNull(sourceType)?.colorArgb ?: HIT_SPARK_COLOR
        if (isCrit) {
            particles.spawnHitBurst(enemy.position, CRIT_COLOR, 9)
            particles.spawnRing(enemy.position, 4f, 34f, 0.3f, CRIT_COLOR, 3f)
        } else if (Random.nextFloat() < 0.6f) {
            particles.spawnHitBurst(enemy.position, if (Random.nextBoolean()) HIT_SPARK_COLOR else color, 3)
        }
        if (settings.showDamageNumbers && damageDealt >= 3f && (isCrit || Random.nextFloat() < 0.6f)) {
            particles.spawnDamageNumber(enemy.position, damageDealt.toInt(), isCrit)
        }
        playHitSound()
    }

    override fun onSplash(center: Vector2, radius: Float, colorArgb: Int) {
        particles.spawnRing(center, radius * 0.25f, radius, 0.28f, colorArgb, 4f)
    }

    override fun onChainLink(from: Vector2, to: Vector2, colorArgb: Int) {
        particles.spawnBolt(from, to, colorArgb)
        audio.play(SoundEffect.SHOOT_LIGHTNING, 0.35f, 1.3f)
    }

    override fun onPulse(center: Vector2, radius: Float, colorArgb: Int) {
        particles.spawnRing(center, 12f, radius, 0.5f, colorArgb, 6f)
        particles.spawnRing(center, 6f, radius * 0.7f, 0.35f, 0xFFFFFFFF.toInt(), 2.5f)
        audio.play(SoundEffect.EMP, 0.35f, 1.4f)
    }

    override fun onTowerFire(tower: Tower, special: Boolean) {
        val mx = tower.position.x + tower.aimX * 18f
        val my = tower.position.y + tower.aimY * 18f
        val color = tower.accentColorArgb
        val sound = when (tower.type) {
            TowerType.ARCHER -> SoundEffect.SHOOT_ARROW
            TowerType.CANNON -> SoundEffect.SHOOT_CANNON
            TowerType.FROST -> SoundEffect.SHOOT_FROST
            TowerType.FLAME -> SoundEffect.SHOOT_FLAME
            TowerType.RANGER -> SoundEffect.SHOOT_SNIPER
            TowerType.LIGHTNING -> SoundEffect.SHOOT_LIGHTNING
        }
        audio.play(sound, if (special) 1f else 0.8f, if (special) 0.8f else 1f)
        when (tower.type) {
            TowerType.CANNON -> {
                particles.spawnSmoke(mx, my, 0xFF8A8480.toInt(), 2, 26f, 7f, 0.6f)
                tmp.set(mx, my)
                particles.spawnHitBurst(tmp, 0xFFFFC46B.toInt(), 4)
            }
            TowerType.RANGER -> {
                tmp.set(mx, my)
                particles.spawnHitBurst(tmp, 0xFFFFF2B0.toInt(), 3)
            }
            TowerType.FLAME -> if (Random.nextFloat() < 0.3f) particles.spawnEmbers(mx, my, 0xFFFFB04A.toInt(), 1, 6f)
            else -> if (Random.nextFloat() < 0.35f) {
                tmp.set(mx, my)
                particles.spawnHitBurst(tmp, color, 2)
            }
        }
        if (special) {
            tmp.set(tower.position)
            particles.spawnRing(tmp, 10f, 54f, 0.35f, color, 4f)
        }
    }

    override fun onImpact(type: ProjectileType, x: Float, y: Float, shot: ShotProfile) {
        when (type) {
            ProjectileType.CANNONBALL -> {
                particles.spawnExplosion(x, y, shot.splashRadius.coerceAtLeast(30f), 0xFFFFA24A.toInt())
                audio.play(SoundEffect.EXPLOSION, if (shot.isSpecial) 1f else 0.7f, if (shot.isSpecial) 0.7f else 1f)
                juice.addShake(if (shot.isSpecial) 7f else 1.6f)
            }
            ProjectileType.FUEL_GLOB -> {
                particles.spawnExplosion(x, y, shot.splashRadius.coerceAtLeast(34f), 0xFF9BE04A.toInt())
                audio.play(SoundEffect.EXPLOSION, 0.55f, 1.2f)
            }
            ProjectileType.FROST_SHARD -> {
                tmp.set(x, y)
                particles.spawnHitBurst(tmp, 0xFFBFF3EF.toInt(), 4)
            }
            ProjectileType.LIGHTNING_BOLT -> {
                tmp.set(x, y)
                particles.spawnHitBurst(tmp, 0xFFE9D9FF.toInt(), 5)
                if (shot.isSpecial) juice.addShake(3f)
            }
            ProjectileType.FLAME -> {
                particles.spawnSmoke(x, y, 0xFF4A3A30.toInt(), 1, 14f, 6f, 0.5f)
                if (Random.nextFloat() < 0.5f) particles.spawnEmbers(x, y, 0xFFFFB04A.toInt(), 1, 8f)
            }
            ProjectileType.ARROW, ProjectileType.BALLISTA_BOLT, ProjectileType.RAIL_SLUG, ProjectileType.RANGER_DART -> {
                if (shot.isSpecial || type == ProjectileType.RAIL_SLUG) {
                    tmp.set(x, y)
                    particles.spawnHitBurst(tmp, type.colorArgb, 4)
                }
            }
        }
        if (shot.isSpecial && shot.splashRadius > 0f && type != ProjectileType.CANNONBALL) {
            particles.spawnExplosion(x, y, shot.splashRadius, shot.colorArgb)
        }
    }

    override fun onFx(kind: Int, x: Float, y: Float, radius: Float, colorArgb: Int) {
        tmp.set(x, y)
        when (kind) {
            Fx.STEAM -> {
                particles.spawnSmoke(x, y, 0xFFE8F4FF.toInt(), 5, 36f, radius * 0.3f, 0.8f)
                particles.spawnRing(tmp, radius * 0.3f, radius, 0.35f, colorArgb, 3f)
                audio.play(SoundEffect.STEAM, 0.6f)
                steamSink?.invoke()
            }
            Fx.EXPLOSION, Fx.STRIKE -> {
                particles.spawnExplosion(x, y, radius, colorArgb)
                audio.play(SoundEffect.EXPLOSION, 0.9f)
                juice.addShake(if (kind == Fx.STRIKE) 9f else 3f)
            }
            Fx.SHIELD_UP -> {
                particles.spawnRing(tmp, radius * 0.4f, radius, 0.5f, colorArgb, 4f)
                audio.play(SoundEffect.ABILITY, 0.4f, 1.4f)
            }
            Fx.SHIELD_BREAK -> {
                particles.spawnHitBurst(tmp, colorArgb, 10)
                particles.spawnRing(tmp, radius * 0.5f, radius * 1.3f, 0.3f, 0xFFFFFFFF.toInt(), 3f)
                audio.play(SoundEffect.SHIELD_BREAK, 0.7f)
            }
            Fx.SUMMON -> {
                particles.spawnRing(tmp, radius * 0.3f, radius, 0.5f, colorArgb, 5f)
                particles.spawnSmoke(x, y, 0xFF2A2230.toInt(), 5, 30f, 10f, 0.9f)
                audio.play(SoundEffect.SUMMON, 0.8f)
                juice.addShake(2f)
            }
            Fx.EMP -> {
                particles.spawnRing(tmp, 20f, radius, 0.7f, colorArgb, 8f)
                particles.spawnRing(tmp, 10f, radius * 0.6f, 0.5f, 0xFFFFFFFF.toInt(), 3f)
                audio.play(SoundEffect.EMP, 1f)
                juice.addShake(6f)
            }
            Fx.BLINK -> {
                particles.spawnRing(tmp, radius * 0.3f, radius, 0.3f, colorArgb, 3f)
                particles.spawnHitBurst(tmp, colorArgb, 6)
            }
            Fx.ENRAGE -> {
                particles.spawnRing(tmp, radius * 0.4f, radius, 0.55f, colorArgb, 6f)
                particles.spawnEmbers(x, y, colorArgb, 6, radius * 0.6f)
                audio.play(SoundEffect.EXPLOSION, 0.5f, 0.6f)
                juice.addShake(4f)
            }
            Fx.BOSS_ENTER -> {
                particles.spawnRing(tmp, 20f, 160f, 0.9f, colorArgb, 8f)
                particles.spawnSmoke(x, y, 0xFF2A2230.toInt(), 8, 50f, 14f, 1.1f)
                juice.addShake(8f)
            }
            Fx.SPLIT -> {
                particles.spawnHitBurst(tmp, colorArgb, 8)
                particles.spawnRing(tmp, radius * 0.4f, radius, 0.3f, colorArgb, 3f)
            }
            Fx.HEAL -> particles.spawnEmbers(x, y, colorArgb, 3, radius * 0.5f)
            Fx.PRESS -> {
                particles.spawnRing(tmp, 8f, radius, 0.3f, colorArgb, 5f)
                particles.spawnSmoke(x, y, 0xFF9AA0A8.toInt(), 3, 30f, 8f, 0.6f)
                audio.play(SoundEffect.EXPLOSION, 0.5f, 0.7f)
                juice.addShake(3f)
            }
            Fx.RUNE -> {
                particles.spawnRing(tmp, 10f, radius, 0.6f, colorArgb, 7f)
                particles.spawnRing(tmp, 6f, radius * 0.6f, 0.4f, 0xFFFFFFFF.toInt(), 3f)
                particles.spawnEmbers(x, y, colorArgb, 10, radius * 0.8f)
                audio.play(SoundEffect.ABILITY, 0.9f, 1.2f)
                juice.addShake(4f)
            }
            Fx.FREEZE_ALL -> {
                particles.spawnRing(tmp, 20f, radius, 0.8f, colorArgb, 9f)
                audio.play(SoundEffect.FREEZE, 1f, 0.8f)
            }
            Fx.OVERDRIVE -> {
                particles.spawnRing(tmp, 20f, radius, 0.7f, colorArgb, 8f)
                audio.play(SoundEffect.FUSION, 0.8f, 0.9f)
            }
            Fx.CLUSTER, Fx.SHATTER -> {
                particles.spawnHitBurst(tmp, colorArgb, 8)
                particles.spawnRing(tmp, radius * 0.3f, radius, 0.3f, colorArgb, 3f)
            }
            Fx.CLOAK -> particles.spawnHitBurst(tmp, colorArgb, 3)
            Fx.LAVA_WARN, Fx.STORM_WARN, Fx.BOUNTY -> {
                particles.spawnRing(tmp, radius * 0.4f, radius, 0.7f, colorArgb, 5f)
                audio.play(SoundEffect.COUNTDOWN, 0.5f, 0.7f)
            }
            Fx.SURGE -> {
                particles.spawnRing(tmp, 12f, radius, 0.6f, colorArgb, 6f)
                audio.play(SoundEffect.FUSION, 0.6f, 0.8f)
            }
        }
    }

    // --- non-combat events raised by the run ------------------------------
    fun onTowerPlaced(position: Vector2, colorArgb: Int) {
        particles.spawnRing(position, 8f, 46f, 0.35f, colorArgb, 4f)
        particles.spawnSmoke(position.x, position.y + 18f, 0xFFB8AD9A.toInt(), 4, 30f, 8f, 0.6f)
        particles.spawnHitBurst(position, colorArgb, 8)
        audio.play(SoundEffect.TOWER_PLACE)
    }

    fun onTowerUpgraded(position: Vector2, pathColorArgb: Int, upgradeName: String, isCapstone: Boolean) {
        particles.spawnUpgradeBurst(position, pathColorArgb)
        tmp.set(position.x, position.y - FLOATING_TEXT_LIFT)
        particles.spawnFloatingText(tmp, upgradeName, pathColorArgb)
        if (isCapstone) {
            particles.spawnRing(position, 14f, 150f, 0.8f, pathColorArgb, 7f)
            particles.spawnUpgradeBurst(position, 0xFFFFFFFF.toInt())
            juice.addShake(4f)
        }
        audio.play(SoundEffect.TOWER_UPGRADE, 1f, if (isCapstone) 0.85f else 1f)
    }

    fun onFusion(position: Vector2, name: String, colorArgb: Int) {
        particles.spawnUpgradeBurst(position, colorArgb)
        particles.spawnRing(position, 12f, 120f, 0.7f, 0xFFFFFFFF.toInt(), 5f)
        tmp.set(position.x, position.y - 58f)
        particles.spawnFloatingText(tmp, "FUSION: $name", 0xFFFFE066.toInt(), 1.9f)
        audio.play(SoundEffect.FUSION)
    }

    fun onTowerSold(position: Vector2, colorArgb: Int) {
        particles.spawnHitBurst(position, colorArgb, 12)
        particles.spawnSmoke(position.x, position.y, 0xFF8A8076.toInt(), 6, 40f, 10f, 0.8f)
        particles.spawnRing(position, 10f, 40f, 0.3f, 0xFFFFD35A.toInt(), 3f)
        audio.play(SoundEffect.TOWER_SELL)
    }

    fun onEnemyDied(enemy: Enemy, gold: Int) {
        val color = enemy.kind.colorArgb
        if (enemy.kind.isBoss) {
            particles.spawnExplosion(enemy.position.x, enemy.position.y, 120f, color)
            particles.spawnRing(enemy.position, 20f, 200f, 0.9f, 0xFFFFFFFF.toInt(), 6f)
            audio.play(SoundEffect.EXPLOSION, 1f, 0.6f)
            juice.addShake(10f)
        } else if (enemy.kind.isMini) {
            particles.spawnExplosion(enemy.position.x, enemy.position.y, 70f, color)
            audio.play(SoundEffect.EXPLOSION, 0.8f, 0.8f)
            juice.addShake(4f)
        } else {
            particles.spawnHitBurst(enemy.position, color, 5)
            if (Random.nextFloat() < 0.5f) particles.spawnSmoke(enemy.position.x, enemy.position.y, 0xFF6A625A.toInt(), 1, 16f, 6f, 0.5f)
            audio.play(SoundEffect.ENEMY_DIE, 0.8f)
        }
        if (gold >= 20 && settings.showDamageNumbers) {
            tmp.set(enemy.position.x, enemy.position.y - 12f)
            particles.spawnFloatingText(tmp, "+$$gold", 0xFFFFD35A.toInt(), 1.0f)
        }
    }

    fun onBaseHit(position: Vector2) {
        particles.spawnRing(position, 16f, 120f, 0.5f, 0xFFFF4A3A.toInt(), 8f)
        particles.spawnHitBurst(position, 0xFFFF6A4A.toInt(), 12)
        juice.addShake(9f)
        juice.baseFlash = 1f
        audio.play(SoundEffect.LIFE_LOST)
    }

    private fun playHitSound() {
        val now = System.nanoTime()
        if (now - lastHitSoundNanos < HIT_SOUND_MIN_GAP_NANOS) return
        lastHitSoundNanos = now
        audio.play(SoundEffect.HIT, 0.6f)
    }

    private companion object {
        val HIT_SPARK_COLOR: Int = 0xFFF2E9D8.toInt()
        val CRIT_COLOR: Int = 0xFFFFD35A.toInt()
        const val FLOATING_TEXT_LIFT = 38f
        const val HIT_SOUND_MIN_GAP_NANOS = 45_000_000L
    }
}
