package com.ironpath.defense.entity.enemy

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * One enemy instance. Pooled and reused (see [EnemySystem]); [generation]
 * lets cached references (e.g. a homing projectile's target) detect that the
 * slot was recycled for a different enemy.
 */
class Enemy {
    lateinit var kind: EnemyKind
    val position = Vector2()
    var uid = 0
    var distanceTraveled = 0f
    var pathSegmentHint = 0
    var heading = 0f
    var walkPhase = 0f
    var maxHealth = 0f
    var currentHealth = 0f
    var baseArmor = 0f
    var armor = 0f
    var speed = 0f
    var reward = 0
    var rewardMult = 1f
    var radius = 0f
    var spawnedByWaveIndex = 0
    var alive = false
    var generation = 0
    var summoned = false

    // --- Statuses ---------------------------------------------------------
    var slowMultiplier = 1f
    var slowTimeRemaining = 0f
    var timeSinceLastHit = Float.MAX_VALUE
    var burnDps = 0f
    var burnTimeRemaining = 0f
    var burnColorArgb = 0xFFFF8A2B.toInt()
    var vulnerabilityBonus = 0f
    var vulnerabilityTimeRemaining = 0f
    var stunTimeRemaining = 0f
    var silenceTime = 0f
    var hasteTime = 0f
    var hasteMult = 1f

    // --- Shield / stealth / abilities ------------------------------------
    var shield = 0f
    var maxShield = 0f
    var shieldRegenTimer = 0f
    var shieldWasUp = false
    var cloaked = false
    var cloakTimer = 0f
    var revealTime = 0f
    var abilityTimer = 0f
    var abilityTimer2 = 0f
    var phase = 0

    // --- Tower-applied riders ---------------------------------------------
    var burnSpreadRadius = 0f
    var spreadTimer = 0f
    var deathBlastDamage = 0f
    var deathBlastRadius = 0f
    var blastGen = 0
    var bountyBonus = 0
    var steamCooldown = 0f

    // --- Presentation -----------------------------------------------------
    var hitFlash = 0f
    var entranceTimer = 0f
    var lastHitSourceType = -1

    val isBurning: Boolean get() = burnTimeRemaining > 0f
    val isMarked: Boolean get() = vulnerabilityTimeRemaining > 0f
    val isStunned: Boolean get() = stunTimeRemaining > 0f
    val isSlowed: Boolean get() = slowTimeRemaining > 0f
    val isSilenced: Boolean get() = silenceTime > 0f

    /** A cloaked enemy is untargetable unless something is revealing it. */
    val isRevealed: Boolean
        get() = !cloaked || revealTime > 0f || burnTimeRemaining > 0f ||
            vulnerabilityTimeRemaining > 0f || slowTimeRemaining > 0f || stunTimeRemaining > 0f
    val isTargetable: Boolean get() = isRevealed

    fun effectiveSpeed(): Float {
        if (stunTimeRemaining > 0f) return 0f
        val haste = if (hasteTime > 0f) hasteMult else 1f
        return speed * slowMultiplier * haste
    }

    fun applyBurn(dps: Float, seconds: Float, colorArgb: Int) {
        if (dps >= burnDps || burnTimeRemaining <= 0f) {
            burnDps = dps
            burnColorArgb = colorArgb
        }
        burnTimeRemaining = maxOf(burnTimeRemaining, seconds)
    }

    fun applyVulnerability(bonus: Float, seconds: Float) {
        if (bonus >= vulnerabilityBonus || vulnerabilityTimeRemaining <= 0f) vulnerabilityBonus = bonus
        vulnerabilityTimeRemaining = maxOf(vulnerabilityTimeRemaining, seconds)
    }

    /** Bosses and mini-bosses only suffer a fraction of any stun. */
    fun applyStun(seconds: Float) {
        val effective = when {
            kind.isBoss -> seconds * BOSS_STUN_FRACTION
            kind.isMini -> seconds * MINI_STUN_FRACTION
            else -> seconds
        }
        stunTimeRemaining = maxOf(stunTimeRemaining, effective)
    }

    fun applySlow(multiplier: Float, durationSeconds: Float) {
        val resisted = 1f - (1f - multiplier) * (1f - kind.slowResistance)
        if (resisted < slowMultiplier || slowTimeRemaining <= 0f) slowMultiplier = resisted
        slowTimeRemaining = maxOf(slowTimeRemaining, durationSeconds)
    }

    /** Strips a fraction of the *base* armor per call, never below [SHRED_FLOOR] of it. */
    fun shredArmor(fraction: Float) {
        if (baseArmor <= 0f || fraction <= 0f) return
        armor = (armor - baseArmor * fraction).coerceAtLeast(baseArmor * SHRED_FLOOR)
    }

    fun heal(amount: Float) {
        currentHealth = (currentHealth + amount).coerceAtMost(maxHealth)
    }

    /** Damage that ignores armor but is still absorbed by the shield first. */
    fun takeTrueDamage(amount: Float) {
        if (amount <= 0f) return
        var remaining = amount
        if (maxShield > 0f) shieldRegenTimer = 0f
        if (shield > 0f) {
            val absorbed = if (shield < remaining) shield else remaining
            shield -= absorbed
            remaining -= absorbed
        }
        currentHealth -= remaining
    }

    /** Armor- and vulnerability-aware hit. Returns the amount actually dealt (shield + health). */
    fun applyDamage(rawDamage: Float, armorPenetration: Float = 0f): Float {
        val effectiveArmor = (armor - armorPenetration).coerceAtLeast(0f)
        val boosted = if (vulnerabilityTimeRemaining > 0f) rawDamage * (1f + vulnerabilityBonus) else rawDamage
        val dealt = (boosted - effectiveArmor).coerceAtLeast(boosted * GameConfig.MIN_DAMAGE_FRACTION)
        takeTrueDamage(dealt)
        timeSinceLastHit = 0f
        hitFlash = 0.1f
        return dealt
    }

    fun clearStatuses() {
        slowMultiplier = 1f
        slowTimeRemaining = 0f
        burnDps = 0f
        burnTimeRemaining = 0f
        vulnerabilityBonus = 0f
        vulnerabilityTimeRemaining = 0f
        stunTimeRemaining = 0f
        silenceTime = 0f
        hasteTime = 0f
        hasteMult = 1f
        cloaked = false
        cloakTimer = 0f
        revealTime = 0f
        burnSpreadRadius = 0f
        spreadTimer = 0f
        deathBlastDamage = 0f
        deathBlastRadius = 0f
        blastGen = 0
        bountyBonus = 0
        steamCooldown = 0f
        hitFlash = 0f
        abilityTimer = 0f
        abilityTimer2 = 0f
        phase = 0
        shieldRegenTimer = 0f
        shieldWasUp = false
        timeSinceLastHit = Float.MAX_VALUE
        lastHitSourceType = -1
    }

    private companion object {
        const val BOSS_STUN_FRACTION = 0.4f
        const val MINI_STUN_FRACTION = 0.6f
        const val SHRED_FLOOR = 0.25f
    }
}
