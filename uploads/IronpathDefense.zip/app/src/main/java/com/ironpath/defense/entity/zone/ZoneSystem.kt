package com.ironpath.defense.entity.zone

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.projectile.ShotProfile
import com.ironpath.defense.entity.tower.Tower

/**
 * Pooled lingering area effects. Overlapping zones of the same kind created by
 * the same weapon are merged (their lifetime is refreshed) so a fast-firing
 * tower can never flood the battlefield with hundreds of zones.
 */
class ZoneSystem(private val collision: CollisionSystem) {
    private val pool = ObjectPool(MAX_ZONES, { Zone() }, { it.alive = false })
    private val activeList = ArrayList<Zone>(MAX_ZONES)
    private val scratch = ArrayList<Enemy>(48)
    private val tmp = Vector2()

    /** Set by the run once the tower system exists (zones can jam or buff towers). */
    var towers: List<Tower> = emptyList()
    val active: List<Zone> get() = activeList

    fun spawn(kind: ZoneKind, x: Float, y: Float, radius: Float, seconds: Float, telegraph: Float = 0f): Zone {
        if (activeList.size >= MAX_ZONES) releaseAt(0)
        val z = pool.obtain()
        z.configure(kind, x, y, radius, seconds, telegraph)
        activeList.add(z)
        return z
    }

    /** Zone left behind by an impact (burning ground, toxic cloud, frost patch). */
    fun spawnFromShot(x: Float, y: Float, shot: ShotProfile) {
        val kind = ZoneKind.fromId(shot.zoneKind) ?: return
        val merge = shot.zoneRadius * 0.7f
        for (i in 0 until activeList.size) {
            val z = activeList[i]
            if (z.kind != kind || z.telegraph > 0f) continue
            val dx = z.x - x
            val dy = z.y - y
            if (dx * dx + dy * dy < merge * merge) {
                if (z.life < shot.zoneSeconds) z.life = shot.zoneSeconds
                return
            }
        }
        val z = spawn(kind, x, y, shot.zoneRadius, shot.zoneSeconds)
        z.enemyDps = shot.zoneDps
        z.enemySlow = shot.zoneSlow
        z.sourceType = shot.sourceType
    }

    /** True if a point lies inside an active bounty zone (kills there pay extra). */
    fun inBountyZone(x: Float, y: Float): Boolean {
        for (i in 0 until activeList.size) {
            val z = activeList[i]
            if (z.kind != ZoneKind.BOUNTY || !z.isActive) continue
            val dx = z.x - x
            val dy = z.y - y
            if (dx * dx + dy * dy <= z.radius * z.radius) return true
        }
        return false
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeList.size) {
            val z = activeList[i]
            if (z.telegraph > 0f) {
                z.telegraph -= dt
                i++
                continue
            }
            z.life -= dt
            if (z.life <= 0f) {
                releaseAt(i)
                continue
            }
            z.tick -= dt
            if (z.tick <= 0f) {
                z.tick = TICK
                applyEffects(z)
            }
            i++
        }
    }

    private fun applyEffects(z: Zone) {
        val hitsEnemies = z.enemyDps > 0f || z.enemyPctDps > 0f || z.enemySlow < 1f ||
            z.enemyHealPct > 0f || z.enemyStun > 0f || z.silence > 0f
        if (hitsEnemies) {
            tmp.set(z.x, z.y)
            collision.queryRadiusInto(tmp, z.radius, scratch)
            for (i in 0 until scratch.size) {
                val e = scratch[i]
                if (z.enemyDps > 0f) {
                    if (z.kind == ZoneKind.FIRE || z.kind == ZoneKind.TOXIC || z.kind == ZoneKind.LAVA) {
                        e.applyBurn(z.enemyDps, TICK * 2.4f, z.kind.colorArgb)
                    } else {
                        e.takeTrueDamage(z.enemyDps * TICK)
                        e.timeSinceLastHit = 0f
                    }
                }
                if (z.enemyPctDps > 0f) {
                    val scale = if (e.kind.isBoss) 0.3f else 1f
                    e.takeTrueDamage(e.maxHealth * z.enemyPctDps * TICK * scale)
                    e.timeSinceLastHit = 0f
                }
                if (z.enemySlow < 1f) e.applySlow(z.enemySlow, TICK * 2.4f)
                if (z.enemyHealPct > 0f) e.heal(e.maxHealth * z.enemyHealPct * TICK)
                if (z.enemyStun > 0f) e.applyStun(z.enemyStun)
                if (z.silence > 0f && z.silence > e.silenceTime) e.silenceTime = z.silence
            }
        }
        if (z.jamTowers || z.towerRate > 0f) {
            val r2 = z.radius * z.radius
            for (k in 0 until towers.size) {
                val t = towers[k]
                val dx = t.position.x - z.x
                val dy = t.position.y - z.y
                if (dx * dx + dy * dy > r2) continue
                if (z.jamTowers && t.jamTime < TICK * 2.4f) t.jamTime = TICK * 2.4f
                if (z.towerRate > 0f) {
                    if (t.overdriveTime < TICK * 2.4f) t.overdriveTime = TICK * 2.4f
                    if (t.overdriveBonus < z.towerRate) t.overdriveBonus = z.towerRate
                }
            }
        }
    }

    fun clear() {
        for (z in activeList) {
            z.alive = false
            pool.free(z)
        }
        activeList.clear()
    }

    private fun releaseAt(index: Int) {
        val z = activeList[index]
        val last = activeList.size - 1
        activeList[index] = activeList[last]
        activeList.removeAt(last)
        z.alive = false
        pool.free(z)
    }

    companion object {
        const val MAX_ZONES = 40
        const val TICK = 0.25f
    }
}
