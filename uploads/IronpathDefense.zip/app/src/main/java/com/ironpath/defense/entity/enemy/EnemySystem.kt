package com.ironpath.defense.entity.enemy

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.map.PathSystem

/**
 * Owns the pooled [Enemy] objects and moves them along the path.
 *
 * Statuses tick here; kind-specific behavior (healing auras, cloaking, boss
 * phases, splitting) lives in [EnemyAbilities] so this class stays a plain
 * movement/status integrator. [slickSegments]/[slickMultiplier] let a map
 * mechanic (ice, conveyors) speed enemies up on chosen path segments.
 */
class EnemySystem(private var pathSystem: PathSystem) {
    private val pool = ObjectPool(initialCapacity = 64, factory = { Enemy() }, reset = { it.alive = false })
    private val activeList = ArrayList<Enemy>(160)
    private var nextUid = 1

    val active: List<Enemy> get() = activeList
    var slickSegments: BooleanArray = BooleanArray(0)
    var slickMultiplier = 1f
    val path: PathSystem get() = pathSystem

    /** Called after every spawn so abilities can initialise per-kind state (shields, timers). */
    var spawnHook: ((Enemy) -> Unit)? = null

    fun setPath(path: PathSystem, slick: BooleanArray) {
        clear()
        pathSystem = path
        slickSegments = slick
    }

    /** Wave-scaled health multiplier (before difficulty). */
    fun waveHealthMultiplier(waveIndex: Int): Float =
        1f + GameConfig.WAVE_HEALTH_SCALING_PER_WAVE * (waveIndex - 1).coerceAtLeast(0)

    fun spawn(
        kind: EnemyKind,
        waveIndex: Int,
        healthMult: Float = 1f,
        rewardMult: Float = 1f,
        atDistance: Float = 0f,
        summoned: Boolean = false
    ): Enemy {
        val waveHealth = waveHealthMultiplier(waveIndex) * healthMult
        val rewardMultiplier = 1f + GameConfig.WAVE_REWARD_SCALING_PER_WAVE * (waveIndex - 1).coerceAtLeast(0)
        val e = pool.obtain()
        e.kind = kind
        e.uid = nextUid++
        e.maxHealth = kind.baseHealth * waveHealth
        e.currentHealth = e.maxHealth
        e.baseArmor = kind.armor
        e.armor = kind.armor
        e.speed = kind.baseSpeed
        e.radius = kind.radius
        e.reward = (kind.baseReward * rewardMultiplier).toInt()
        e.rewardMult = rewardMult
        e.summoned = summoned
        e.maxShield = kind.baseShield * waveHealth
        e.shield = e.maxShield
        e.distanceTraveled = atDistance.coerceIn(0f, pathSystem.totalLength - 1f)
        e.pathSegmentHint = 0
        e.walkPhase = (e.uid % 17) * 0.37f
        e.clearStatuses()
        e.spawnedByWaveIndex = waveIndex
        e.entranceTimer = if (kind.isBoss) 1.8f else 0f
        e.alive = true
        e.generation++
        e.pathSegmentHint = pathSystem.positionAt(e.distanceTraveled, 0, e.position)
        e.heading = pathSystem.headingOf(e.pathSegmentHint)
        e.cloakTimer = 1.4f + (e.uid % 5) * 0.2f
        e.abilityTimer = when (kind) {
            EnemyKind.BOSS -> 7f
            EnemyKind.BOSS_QUEEN -> 5f
            EnemyKind.BOSS_COLOSSUS -> 7f
            EnemyKind.BOSS_WRAITH -> 5f
            EnemyKind.MINI_BRUISER -> 5f
            EnemyKind.MINI_STALKER -> 4f
            else -> 0.3f
        }
        spawnHook?.invoke(e)
        activeList.add(e)
        return e
    }

    fun update(dt: Float, onLeaked: (Enemy) -> Unit, onKilled: (Enemy) -> Unit) {
        var i = 0
        while (i < activeList.size) {
            val e = activeList[i]
            tickStatuses(e, dt)
            if (e.currentHealth <= 0f) {
                removeActiveAt(i)
                onKilled(e)
                e.alive = false
                pool.free(e)
                continue // index i now holds the swapped-in element — recheck it
            }
            val seg = e.pathSegmentHint
            val slick = if (seg >= 0 && seg < slickSegments.size && slickSegments[seg]) slickMultiplier else 1f
            val step = e.effectiveSpeed() * slick * dt
            e.distanceTraveled += step
            e.walkPhase += step * 0.09f
            e.pathSegmentHint = pathSystem.positionAt(e.distanceTraveled, e.pathSegmentHint, e.position)
            e.heading = pathSystem.headingOf(e.pathSegmentHint)
            if (pathSystem.hasReachedEnd(e.distanceTraveled)) {
                removeActiveAt(i)
                onLeaked(e)
                e.alive = false
                pool.free(e)
                continue
            }
            i++
        }
    }

    private fun tickStatuses(e: Enemy, dt: Float) {
        if (e.slowTimeRemaining > 0f) {
            e.slowTimeRemaining -= dt
            if (e.slowTimeRemaining <= 0f) e.slowMultiplier = 1f
        }
        if (e.stunTimeRemaining > 0f) e.stunTimeRemaining -= dt
        if (e.silenceTime > 0f) e.silenceTime -= dt
        if (e.revealTime > 0f) e.revealTime -= dt
        if (e.steamCooldown > 0f) e.steamCooldown -= dt
        if (e.hitFlash > 0f) e.hitFlash -= dt
        if (e.entranceTimer > 0f) e.entranceTimer -= dt
        if (e.hasteTime > 0f) {
            e.hasteTime -= dt
            if (e.hasteTime <= 0f) e.hasteMult = 1f
        }
        if (e.vulnerabilityTimeRemaining > 0f) {
            e.vulnerabilityTimeRemaining -= dt
            if (e.vulnerabilityTimeRemaining <= 0f) e.vulnerabilityBonus = 0f
        }
        if (e.burnTimeRemaining > 0f) {
            e.burnTimeRemaining -= dt
            e.takeTrueDamage(e.burnDps * dt) // damage over time ignores armor (but shields absorb it)
            e.timeSinceLastHit = 0f          // and keeps a Regenerator from healing it off
            if (e.burnSpreadRadius > 0f) {
                e.spreadTimer -= dt
                if (e.spreadTimer <= 0f) {
                    e.spreadTimer = 0.45f
                    spreadFire(e)
                }
            }
            if (e.burnTimeRemaining <= 0f) {
                e.burnDps = 0f
                e.burnSpreadRadius = 0f
            }
        }
        if (e.kind.regenPerSecond > 0f) {
            e.timeSinceLastHit += dt
            if (e.timeSinceLastHit >= GameConfig.REGEN_GRACE_PERIOD_SECONDS) {
                e.heal(e.maxHealth * e.kind.regenPerSecond * dt)
            }
        }
    }

    /** Wildfire: a burning enemy ignites its neighbors, who can then keep spreading it. */
    private fun spreadFire(src: Enemy) {
        val r2 = src.burnSpreadRadius * src.burnSpreadRadius
        for (j in 0 until activeList.size) {
            val o = activeList[j]
            if (o === src || o.burnTimeRemaining > 1f) continue
            if (src.position.distanceSquaredTo(o.position) <= r2) {
                o.applyBurn(src.burnDps * 0.85f, 2.2f, src.burnColorArgb)
                o.burnSpreadRadius = src.burnSpreadRadius
                if (src.deathBlastDamage > 0f && o.deathBlastDamage < src.deathBlastDamage) {
                    o.deathBlastDamage = src.deathBlastDamage
                    o.deathBlastRadius = src.deathBlastRadius
                }
            }
        }
    }

    fun clear() {
        for (e in activeList) {
            e.alive = false
            pool.free(e)
        }
        activeList.clear()
    }

    private fun removeActiveAt(index: Int) {
        val lastIndex = activeList.size - 1
        activeList[index] = activeList[lastIndex]
        activeList.removeAt(lastIndex)
    }
}
