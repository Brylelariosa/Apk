package com.ironpath.defense.entity.enemy

import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.Fx
import com.ironpath.defense.entity.tower.Tower

/**
 * Kind-specific enemy mechanics, kept apart from the movement/status
 * integrator in [EnemySystem]:
 *
 *  - Medic / War Medic: heal nearby enemies.     - Aegis: recharging shield.
 *  - Phantom / Shade Captain / Void Wraith: cloak cycle (+ blinks).
 *  - Siege Brute: periodic speed charge.         - Splitter: bursts into Spawnlings.
 *  - Ironclad Warden: shield + guard phases.     - Brood Queen: swarm spawning + enrage.
 *  - Static Colossus: EMP that jams towers.      - Void Wraith: blink + phantom summons.
 *
 * A *silenced* enemy (EMP upgrades) loses its abilities: it stops healing,
 * uncloaks, stops summoning — and its timers freeze until the silence ends.
 */
class EnemyAbilities(
    private val enemies: EnemySystem,
    private val feedback: CombatFeedback,
    private val towers: () -> List<Tower>
) {
    /** Difficulty health multiplier applied to everything summoned. */
    var difficultyHealth = 1f

    init {
        enemies.spawnHook = { e -> initSpawned(e) }
    }

    private fun initSpawned(e: Enemy) {
        if (e.kind.isBoss && !e.summoned) {
            feedback.onFx(Fx.BOSS_ENTER, e.position.x.coerceAtLeast(40f), e.position.y, 120f, e.kind.colorArgb)
        }
        if (e.kind == EnemyKind.BOSS_COLOSSUS) {
            e.maxShield = e.maxHealth * 0.12f
            e.shield = e.maxShield
            e.shieldWasUp = true
        }
    }

    fun update(dt: Float) {
        val list = enemies.active
        var i = 0
        while (i < list.size) {
            val e = list[i]
            i++
            if (e.maxShield > 0f) trackShield(e)
            if (e.silenceTime > 0f) {
                e.cloaked = false
                continue
            }
            when (e.kind) {
                EnemyKind.HEALER -> healAura(e, dt, 110f, 0.10f)
                EnemyKind.MINI_COMMANDER -> {
                    healAura(e, dt, 125f, 0.12f)
                    commanderShield(e, dt)
                }
                EnemyKind.SHIELDED -> shieldRegen(e, dt, 3.5f, 0.35f)
                EnemyKind.PHANTOM -> cloakCycle(e, dt, 2.0f, 2.4f)
                EnemyKind.MINI_STALKER -> {
                    cloakCycle(e, dt, 1.8f, 2.6f)
                    blink(e, dt, 6f, 95f)
                }
                EnemyKind.MINI_BRUISER -> charge(e, dt)
                EnemyKind.BOSS -> warden(e, dt)
                EnemyKind.BOSS_QUEEN -> queen(e, dt)
                EnemyKind.BOSS_COLOSSUS -> colossus(e, dt)
                EnemyKind.BOSS_WRAITH -> wraith(e, dt)
                else -> {}
            }
        }
    }

    /** Called by the run when an enemy dies (before its slot is recycled). */
    fun onKilled(e: Enemy) {
        if (e.kind == EnemyKind.SPLITTER) {
            for (n in 0 until 3) {
                enemies.spawn(EnemyKind.SPAWNLING, e.spawnedByWaveIndex, difficultyHealth, 0.6f,
                    (e.distanceTraveled + (n - 1) * 14f).coerceAtLeast(0f), true)
            }
            feedback.onFx(Fx.SPLIT, e.position.x, e.position.y, e.radius * 2f, e.kind.colorArgb)
        }
    }

    // --- shared helpers ---------------------------------------------------
    private fun trackShield(e: Enemy) {
        if (e.shield > 0f) {
            e.shieldWasUp = true
        } else if (e.shieldWasUp) {
            e.shieldWasUp = false
            feedback.onFx(Fx.SHIELD_BREAK, e.position.x, e.position.y, e.radius * 1.6f, 0xFF8FD8FF.toInt())
        }
    }

    private fun shieldRegen(e: Enemy, dt: Float, delay: Float, fractionPerSecond: Float) {
        if (e.maxShield <= 0f) return
        e.shieldRegenTimer += dt
        if (e.shieldRegenTimer >= delay && e.shield < e.maxShield) {
            e.shield = (e.shield + e.maxShield * fractionPerSecond * dt).coerceAtMost(e.maxShield)
        }
    }

    private fun healAura(e: Enemy, dt: Float, radius: Float, pctPerSecond: Float) {
        e.abilityTimer -= dt
        if (e.abilityTimer > 0f) return
        e.abilityTimer = 0.5f
        val r2 = radius * radius
        val list = enemies.active
        var healed = false
        for (k in 0 until list.size) {
            val o = list[k]
            if (o === e || o.currentHealth >= o.maxHealth) continue
            if (e.position.distanceSquaredTo(o.position) <= r2) {
                o.heal(o.maxHealth * pctPerSecond * 0.5f)
                healed = true
            }
        }
        if (healed) feedback.onFx(Fx.HEAL, e.position.x, e.position.y, radius, 0xFF7AE0A0.toInt())
    }

    private fun commanderShield(e: Enemy, dt: Float) {
        e.abilityTimer2 -= dt
        if (e.abilityTimer2 > 0f) return
        e.abilityTimer2 = 6f
        val r2 = 130f * 130f
        val list = enemies.active
        for (k in 0 until list.size) {
            val o = list[k]
            if (o === e || o.kind.isBoss) continue
            if (e.position.distanceSquaredTo(o.position) <= r2) {
                o.maxShield = maxOf(o.maxShield, o.maxHealth * 0.35f)
                o.shield = maxOf(o.shield, o.maxHealth * 0.35f)
                o.shieldWasUp = true
            }
        }
        feedback.onFx(Fx.SHIELD_UP, e.position.x, e.position.y, 130f, 0xFF3FB9A5.toInt())
    }

    private fun cloakCycle(e: Enemy, dt: Float, visible: Float, hidden: Float) {
        e.cloakTimer -= dt
        if (e.cloakTimer > 0f) return
        e.cloaked = !e.cloaked
        e.cloakTimer = if (e.cloaked) hidden else visible
        feedback.onFx(Fx.CLOAK, e.position.x, e.position.y, e.radius * 1.8f, e.kind.colorArgb)
    }

    private fun blink(e: Enemy, dt: Float, interval: Float, distance: Float) {
        e.abilityTimer -= dt
        if (e.abilityTimer > 0f) return
        e.abilityTimer = interval
        blinkForward(e, distance)
    }

    private fun blinkForward(e: Enemy, distance: Float) {
        feedback.onFx(Fx.BLINK, e.position.x, e.position.y, e.radius * 2f, e.kind.colorArgb)
        val limit = enemies.path.totalLength - 90f
        if (e.distanceTraveled + distance < limit) {
            e.distanceTraveled += distance
            e.pathSegmentHint = enemies.path.positionAt(e.distanceTraveled, e.pathSegmentHint, e.position)
            feedback.onFx(Fx.BLINK, e.position.x, e.position.y, e.radius * 2f, e.kind.colorArgb)
        }
    }

    private fun charge(e: Enemy, dt: Float) {
        e.abilityTimer -= dt
        if (e.abilityTimer > 0f) return
        e.abilityTimer = 7f
        e.hasteTime = 2.2f
        e.hasteMult = 2.0f
        feedback.onFx(Fx.ENRAGE, e.position.x, e.position.y, e.radius * 2.4f, 0xFFFF7A3C.toInt())
    }

    private fun summon(src: Enemy, kind: EnemyKind, count: Int, spacing: Float) {
        for (n in 0 until count) {
            enemies.spawn(kind, src.spawnedByWaveIndex, difficultyHealth, 0f,
                (src.distanceTraveled - n * spacing).coerceAtLeast(0f), true)
        }
        feedback.onFx(Fx.SUMMON, src.position.x, src.position.y, src.radius * 2.4f, src.kind.colorArgb)
    }

    // --- bosses -------------------------------------------------------------
    private fun warden(e: Enemy, dt: Float) {
        val frac = e.currentHealth / e.maxHealth
        if ((e.phase == 0 && frac <= 0.66f) || (e.phase == 1 && frac <= 0.33f)) {
            e.phase++
            e.maxShield = e.maxHealth * 0.14f
            e.shield = e.maxShield
            e.shieldWasUp = true
            feedback.onFx(Fx.SHIELD_UP, e.position.x, e.position.y, e.radius * 2.2f, 0xFF8FD8FF.toInt())
            summon(e, EnemyKind.ARMORED, 2 + e.phase, 30f)
        }
        e.abilityTimer -= dt
        if (e.abilityTimer <= 0f) {
            e.abilityTimer = 12f - e.phase * 2.5f
            summon(e, EnemyKind.BASIC, 3, 26f)
        }
    }

    private fun queen(e: Enemy, dt: Float) {
        val frac = e.currentHealth / e.maxHealth
        if (e.phase == 0 && frac <= 0.5f) {
            e.phase = 1
            e.hasteTime = 9999f
            e.hasteMult = 1.45f
            feedback.onFx(Fx.ENRAGE, e.position.x, e.position.y, e.radius * 3f, 0xFFFF5A3C.toInt())
        }
        if (e.timeSinceLastHit > 3f) e.heal(e.maxHealth * 0.01f * dt)
        e.abilityTimer -= dt
        if (e.abilityTimer <= 0f) {
            e.abilityTimer = if (e.phase == 1) 4f else 7f
            summon(e, EnemyKind.SWARM, if (e.phase == 1) 7 else 5, 18f)
        }
    }

    private fun colossus(e: Enemy, dt: Float) {
        shieldRegen(e, dt, 4f, 0.2f)
        if (e.phase == 0 && e.currentHealth / e.maxHealth <= 0.5f) {
            e.phase = 1
            e.maxShield = e.maxHealth * 0.15f
            e.shield = e.maxShield
            e.shieldWasUp = true
            feedback.onFx(Fx.ENRAGE, e.position.x, e.position.y, e.radius * 3f, 0xFFFFD84A.toInt())
        }
        e.abilityTimer -= dt
        if (e.abilityTimer > 0f) return
        e.abilityTimer = if (e.phase == 1) 6.5f else 9f
        val r2 = EMP_RADIUS * EMP_RADIUS
        val all = towers()
        for (k in 0 until all.size) {
            val t = all[k]
            val dx = t.position.x - e.position.x
            val dy = t.position.y - e.position.y
            if (dx * dx + dy * dy <= r2 && t.jamTime < EMP_SECONDS) t.jamTime = EMP_SECONDS
        }
        feedback.onFx(Fx.EMP, e.position.x, e.position.y, EMP_RADIUS, 0xFFFFD84A.toInt())
    }

    private fun wraith(e: Enemy, dt: Float) {
        cloakCycle(e, dt, 2.4f, 2.0f)
        if (e.phase == 0 && e.currentHealth / e.maxHealth <= 0.5f) {
            e.phase = 1
            summon(e, EnemyKind.PHANTOM, 3, 30f)
        }
        e.abilityTimer -= dt
        if (e.abilityTimer <= 0f) {
            e.abilityTimer = 8f
            blinkForward(e, 130f)
        }
    }

    private companion object {
        const val EMP_RADIUS = 200f
        const val EMP_SECONDS = 3.5f
    }
}
