package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind

/** The flavor of a wave; drives the banner, the preview chip and the player-facing tip. */
enum class WaveType(val label: String, val colorArgb: Int, val tip: String) {
    NORMAL("Standard Assault", 0xFF9FB4C8.toInt(), "A balanced push. Build a solid core defense."),
    FAST("Rush", 0xFFFFD84A.toInt(), "Fast movers. Slow them down and cover the whole lane."),
    SWARM("Swarm", 0xFFE070C0.toInt(), "Huge numbers. Splash damage and chain lightning shine."),
    TANK("Siege Column", 0xFFC9754A.toInt(), "Heavy hitters. Stack damage and armor-piercing."),
    ARMORED("Armored Assault", 0xFF9AA7B8.toInt(), "Thick armor. Weak shots barely scratch it."),
    SPECIAL("Specialist Squad", 0xFF8FE8D0.toInt(), "Special enemies with unusual abilities."),
    MIXED("Combined Arms", 0xFFB9A6FF.toInt(), "A bit of everything. Stay flexible."),
    MINIBOSS("Mini-Boss", 0xFFFF9A4A.toInt(), "An elite leads the wave. Focus it down."),
    BOSS("BOSS WAVE", 0xFFFF4A4A.toInt(), "A boss with unique abilities approaches!")
}

data class SpawnGroup(
    val kind: EnemyKind,
    val count: Int,
    val intervalSeconds: Float,
    val startDelaySeconds: Float = 0f
)

/**
 * One wave. [note] is the Adaptive Director's transparent explanation of any
 * adjustment it made (shown in the wave preview), and [adapted] flags that
 * the composition differs from the map's base plan.
 */
data class WaveDefinition(
    val index: Int,
    val groups: List<SpawnGroup>,
    val completionReward: Int,
    val isBossWave: Boolean = false,
    val type: WaveType = WaveType.NORMAL,
    val note: String = "",
    val adapted: Boolean = false
) {
    val totalEnemies: Int get() = groups.sumOf { it.count }

    /** Distinct enemy kinds with their total counts, most numerous first (for the preview strip). */
    val summary: List<Pair<EnemyKind, Int>> by lazy {
        val counts = LinkedHashMap<EnemyKind, Int>()
        for (g in groups) counts[g.kind] = (counts[g.kind] ?: 0) + g.count
        val pairs = ArrayList<Pair<EnemyKind, Int>>()
        for ((kind, count) in counts) pairs.add(kind to count)
        pairs.sortWith(compareByDescending<Pair<EnemyKind, Int>> { it.first.tier }.thenByDescending { it.second })
        pairs
    }

    /** The most dangerous enemy in the wave (boss/mini first). */
    val headliner: EnemyKind? get() = summary.firstOrNull()?.first
}
