package com.ironpath.defense.render

import android.graphics.Canvas
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.render.ArtKit.GOLD
import com.ironpath.defense.render.ArtKit.ICE
import com.ironpath.defense.render.ArtKit.IRON
import com.ironpath.defense.render.ArtKit.STEEL
import com.ironpath.defense.render.ArtKit.STEEL_DARK
import com.ironpath.defense.render.ArtKit.STONE
import com.ironpath.defense.render.ArtKit.STONE_LIGHT
import com.ironpath.defense.render.ArtKit.WOOD
import com.ironpath.defense.render.ArtKit.WOOD_DARK
import com.ironpath.defense.render.ArtKit.WOOD_LIGHT
import com.ironpath.defense.render.ArtKit.arc
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.glow
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.oval
import com.ironpath.defense.render.ArtKit.ovalStroke
import com.ironpath.defense.render.ArtKit.polygon
import com.ironpath.defense.render.ArtKit.quad
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.rr
import com.ironpath.defense.render.ArtKit.tri
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Procedural, layered art for every tower. Each tower is a fixed *base* plus
 * three independent component *slots*, one per upgrade path:
 *
 *   Path A -> the weapon itself (front, rotates with aim),
 *   Path B -> flanks / satellites / support equipment,
 *   Path C -> top & power sources (energy, fuel, fire).
 *
 * Components appear by tier, newer tiers replace obsolete parts (a bow becomes
 * a ballista), and because the slots never overlap, a 5-2-0 tower looks truly
 * different from 2-5-0 or 5-0-2 — the picture is built from the real tiers.
 * The most recently bought component animates in (scale overshoot) and the
 * whole tower pops with an evolve flash.
 */
object TowerArt {
    private val SKIN = 0xFFE8C9A0.toInt()

    fun draw(c: Canvas, t: Tower, cx: Float, cy: Float, scale: Float, time: Float) {
        val build = (t.buildTimer / Tower.BUILD_SECONDS).coerceIn(0f, 1f)
        val evo = (t.evolveTimer / Tower.EVOLVE_SECONDS).coerceIn(0f, 1f)
        val pop = 1f + 0.10f * sin(evo * 3.1416f) + 0.45f * build * build
        c.save()
        c.translate(cx, cy - build * 14f * scale)
        c.scale(scale * pop, scale * pop)
        oval(c, -27f, 9f, 27f, 29f, 0x44000000)
        val aim = atan2(t.aimY, t.aimX) * 57.29578f
        val a = t.pathTiers[0]
        val b = t.pathTiers[1]
        val k = t.pathTiers[2]
        when (t.type) {
            TowerType.ARCHER -> archer(c, t, time, aim, a, b, k)
            TowerType.CANNON -> cannon(c, t, time, aim, a, b, k)
            TowerType.FROST -> frost(c, t, time, aim, a, b, k)
            TowerType.RANGER -> ranger(c, t, time, aim, a, b, k)
            TowerType.LIGHTNING -> lightning(c, t, time, aim, a, b, k)
            TowerType.FLAME -> flameTower(c, t, time, aim, a, b, k)
        }
        if (t.fusion != null) {
            val ph = time * 2f + t.idlePhase
            ring(c, 0f, 0f, 29f + sin(ph) * 1.2f, 1.6f, ArtKit.withAlpha(GOLD, 0.55f + 0.25f * sin(ph * 1.7f)))
        }
        if (evo > 0f) {
            glow(c, 0f, 0f, 48f * (1.15f - evo * 0.35f), t.accentColorArgb, evo * 0.85f)
            ring(c, 0f, 0f, 20f + (1f - evo) * 34f, 3f * evo, ArtKit.withAlpha(0xFFFFFFFF.toInt(), evo))
        }
        if (t.jamTime > 0f) {
            val j = if (((time * 14f).toInt() and 1) == 0) 1f else 0.4f
            ln(c, -18f, -18f, 18f, 18f, 3f, ArtKit.withAlpha(0xFFFFD84A.toInt(), j))
            ln(c, -18f, 18f, 18f, -18f, 3f, ArtKit.withAlpha(0xFFFFD84A.toInt(), j))
            glow(c, 0f, 0f, 30f, 0xFFFFD84A.toInt(), 0.35f * j)
        }
        c.restore()
    }

    /** Un-upgraded, un-animated tower for shop buttons and menus. */
    fun drawIcon(c: Canvas, type: TowerType, cx: Float, cy: Float, scale: Float, time: Float, aimDeg: Float = -35f) {
        c.save()
        c.translate(cx, cy)
        c.scale(scale, scale)
        val dummyAim = aimDeg
        when (type) {
            TowerType.ARCHER -> archerBody(c, 0f, 0f, time, dummyAim, 0f, 0, 0, 0, null)
            TowerType.CANNON -> cannonBody(c, 0f, time, dummyAim, 0, 0, 0, null)
            TowerType.FROST -> frostBody(c, time, dummyAim, 0, 0, 0, null)
            TowerType.RANGER -> rangerBody(c, 0f, 0f, time, dummyAim, 0, 0, 0, null)
            TowerType.LIGHTNING -> lightningBody(c, time, 0, 0, 0, null)
            TowerType.FLAME -> flameBody(c, 0f, time, dummyAim, 0, 0, 0, null, 0f)
        }
        c.restore()
    }

    private fun appear(t: Tower?, path: Int, tier: Int): Float {
        if (t == null || t.evolvedPath != path || t.pathTiers[path] != tier || t.evolveTimer <= 0f) return 1f
        val x = 1f - t.evolveTimer / Tower.EVOLVE_SECONDS
        val s = 1.70158f
        val y = x - 1f
        return (y * y * ((s + 1f) * y + s) + 1f).coerceIn(0f, 1.4f)
    }

    private inline fun part(c: Canvas, k: Float, ax: Float, ay: Float, block: () -> Unit) {
        if (k >= 0.995f) {
            block()
        } else {
            c.save()
            c.scale(k, k, ax, ay)
            block()
            c.restore()
        }
    }

    private fun flameUp(c: Canvas, x: Float, y: Float, s: Float, ph: Float, cool: Int = ArtKit.FIRE) {
        val fl = 1f + 0.18f * sin(ph * 2.3f)
        glow(c, x, y - s * 0.4f, s * 2.4f * fl, cool, 0.5f)
        tri(c, x - s * 0.6f, y, x + s * 0.6f, y, x + 0.15f * sin(ph * 3f) * s, y - s * 1.9f * fl, cool)
        tri(c, x - s * 0.35f, y, x + s * 0.35f, y, x, y - s * 1.1f * fl, 0xFFFFE08A.toInt())
    }

    private fun flameFwd(c: Canvas, x: Float, y: Float, s: Float, ph: Float, cool: Int) {
        val fl = 1f + 0.2f * sin(ph * 2.7f)
        glow(c, x + s * 0.8f, y, s * 2.2f * fl, cool, 0.55f)
        tri(c, x, y - s * 0.6f, x, y + s * 0.6f, x + s * 1.9f * fl, y + 0.12f * s * sin(ph * 3f), cool)
        tri(c, x, y - s * 0.32f, x, y + s * 0.32f, x + s * 1.1f * fl, y, 0xFFFFE08A.toInt())
    }

    // =====================================================================
    // ARCHER
    // =====================================================================
    private fun archer(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        archerBody(c, 0f, t.recoil * 4f, time + t.idlePhase, aim, if (t.flashRemaining > 0f) 1f else 0f, a, b, k, t)
    }

    private fun archerBody(c: Canvas, ox: Float, rec: Float, time: Float, aim: Float, fired: Float, a: Int, b: Int, k: Int, t: Tower?) {
        val ph = time * 3f
        rr(c, -24f, -24f, 24f, 24f, 6f, WOOD_DARK)
        rr(c, -21f, -21f, 21f, 21f, 5f, WOOD)
        for (i in -1..1) ln(c, -20f, i * 12f, 20f, i * 12f, 1.2f, WOOD_DARK)
        circ(c, -21f, -21f, 3.4f, WOOD_LIGHT); circ(c, 21f, -21f, 3.4f, WOOD_LIGHT)
        circ(c, -21f, 21f, 3.4f, WOOD_LIGHT); circ(c, 21f, 21f, 3.4f, WOOD_LIGHT)
        // Path C - Pyre Fletcher: torches, oil, wreath, dragon
        if (k >= 1) part(c, appear(t, 2, 1), 21f, 0f) {
            flameUp(c, 21f, -21f, 4f, ph, ArtKit.FIRE); flameUp(c, 21f, 21f, 4f, ph + 1.3f, ArtKit.FIRE)
        }
        if (k >= 2) part(c, appear(t, 2, 2), -17f, -16f) {
            circ(c, -17f, -16f, 7f, IRON); circ(c, -17f, -16f, 4.6f, 0xFF2A2E34.toInt())
            oval(c, -19f, -14f, -14f, -9f, 0xCC1A1410.toInt()); ln(c, -17f, -9f, -17f, -5f, 1.6f, 0xFF1A1410.toInt())
        }
        if (k >= 4) part(c, appear(t, 2, 4), 0f, 0f) {
            for (i in 0 until 8) {
                val ang = i * 0.7854f + time * 0.7f
                flameUp(c, cos(ang) * 27f, sin(ang) * 27f + 5f, 3.3f, ph + i, ArtKit.FIRE)
            }
        }
        // Path B - Volley Corps: quiver, banner
        if (b >= 1) part(c, appear(t, 1, 1), -16f, 12f) {
            rr(c, -20f, 6f, -13f, 19f, 2f, WOOD_DARK)
            for (i in 0 until 3) ln(c, -18.5f + i * 2.4f, 6f, -18.5f + i * 2.4f, 2f, 1.3f, 0xFFE8E4D8.toInt())
        }
        if (b >= 5) part(c, appear(t, 1, 5), 21f, -34f) {
            ln(c, 20f, -20f, 20f, -38f, 1.6f, WOOD_DARK)
            val sw = sin(ph) * 2f
            tri(c, 20f, -38f, 20f, -29f, 34f + sw, -33f + sw * 0.4f, 0xFF4F9BFF.toInt())
            ring(c, 0f, 0f, 26f, 1.4f, 0x884F9BFF.toInt())
        }
        // Rotating turret group: archer, bows / ballista, dragon
        c.save()
        c.rotate(aim)
        c.translate(-rec, 0f)
        circ(c, 0f, 0f, 9f, 0xFF4F7F45.toInt()); circ(c, -1f, 0f, 6.4f, 0xFF3B6636.toInt())
        circ(c, 1.5f, 0f, 5.2f, SKIN)
        arc(c, 0.5f, 0f, 5.8f, 100f, 160f, 2.4f, 0xFF3B6636.toInt())
        if (a >= 3) { ring(c, 3.8f, -0.6f, 3f, 0.9f, GOLD); glow(c, 3.8f, -0.6f, 5f, GOLD, 0.4f + 0.3f * sin(ph * 2f)) }
        if (b >= 4) for (i in -2..2) ln(c, -13f, i * 4.4f, -23f, i * 4.4f, 1.7f, WOOD_LIGHT)
        val doubled = b >= 2
        val nBows = if (a >= 4) (if (doubled) 2 else 1) else 1 + (if (doubled) 1 else 0) + (if (b >= 3) 1 else 0)
        for (i in 0 until nBows) {
            val ang = if (nBows == 1) 0f else (i - (nBows - 1) / 2f) * (if (a >= 4) 22f else 17f)
            c.save()
            c.rotate(ang)
            if (a >= 4) ballista(c, fired, a >= 5, ph) else bow(c, fired, a, k, ph)
            c.restore()
        }
        if (k >= 5) part(c, appear(t, 2, 5), 24f, 0f) {
            tri(c, 17f, -6f, 17f, 6f, 31f, 0f, 0xFFB03A2E.toInt())
            tri(c, 18f, -5f, 14f, -11f, 24f, -3f, 0xFF7A241C.toInt()); tri(c, 18f, 5f, 14f, 11f, 24f, 3f, 0xFF7A241C.toInt())
            circ(c, 22f, -2.4f, 1.3f, 0xFFFFE066.toInt())
            glow(c, 32f, 0f, 11f + fired * 5f, ArtKit.FIRE, 0.7f)
        }
        c.restore()
    }

    private fun bow(c: Canvas, fired: Float, a: Int, k: Int, ph: Float) {
        val len = 11f + 2f * minOf(a, 3)
        val pull = if (fired > 0f) 1f else 6f + sin(ph) * 0.6f
        ArtKit.path.reset()
        ArtKit.path.moveTo(13f, -len)
        ArtKit.path.quadTo(23f, 0f, 13f, len)
        ArtKit.strokePath(c, 3f, WOOD_LIGHT)
        ln(c, 13f, -len, 13f - pull, 0f, 1f, 0xFFEFE6C8.toInt())
        ln(c, 13f - pull, 0f, 13f, len, 1f, 0xFFEFE6C8.toInt())
        if (fired <= 0f) {
            ln(c, 13f - pull, 0f, 28f, 0f, 1.7f, WOOD_LIGHT)
            val head = if (k >= 3) 0xFFE0482E.toInt() else if (a >= 2) STEEL else 0xFFC9C3B0.toInt()
            tri(c, 28f, -2.6f, 28f, 2.6f, 34f, 0f, head)
            if (k >= 1) glow(c, 31f, 0f, 7f, ArtKit.FIRE, 0.7f)
        }
    }

    private fun ballista(c: Canvas, fired: Float, golden: Boolean, ph: Float) {
        val trim = if (golden) GOLD else STEEL_DARK
        rr(c, -4f, -3f, 24f, 3f, 1.5f, WOOD_DARK)
        ArtKit.path.reset()
        ArtKit.path.moveTo(15f, -18f)
        ArtKit.path.quadTo(27f, 0f, 15f, 18f)
        ArtKit.strokePath(c, 4.2f, trim)
        val pull = if (fired > 0f) 12f else 4f
        ln(c, 15f, -18f, pull, 0f, 1.1f, 0xFFEFE6C8.toInt()); ln(c, pull, 0f, 15f, 18f, 1.1f, 0xFFEFE6C8.toInt())
        circ(c, 2f, -6.5f, 3.2f, IRON); circ(c, 2f, 6.5f, 3.2f, IRON)
        ln(c, 2f, -6.5f, 2f + cos(ph * 4f) * 2f, -6.5f + sin(ph * 4f) * 2f, 1f, STEEL)
        if (fired <= 0f) {
            ln(c, pull, 0f, 34f, 0f, 2.6f, WOOD_LIGHT)
            tri(c, 34f, -3.6f, 34f, 3.6f, 43f, 0f, if (golden) GOLD else STEEL)
            if (golden) glow(c, 40f, 0f, 11f, GOLD, 0.7f)
        }
    }

    // =====================================================================
    // CANNON
    // =====================================================================
    private fun cannon(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        cannonBody(c, t.recoil * 5f, time + t.idlePhase, aim, a, b, k, t)
    }

    private fun cannonBody(c: Canvas, rec: Float, time: Float, aim: Float, a: Int, b: Int, k: Int, t: Tower?) {
        polygon(c, 0f, 0f, 27f, 8, 22.5f, 0xFF50555D.toInt())
        polygon(c, 0f, -1f, 23.5f, 8, 22.5f, STONE)
        polygon(c, 0f, -2f, 17f, 8, 22.5f, STONE_LIGHT)
        for (i in 0 until 8) {
            val ang = (i * 45f + 22.5f) * 0.0174533f
            circ(c, cos(ang) * 25f, sin(ang) * 25f, 3.6f, STONE_LIGHT)
        }
        if (a >= 4) part(c, appear(t, 0, 4), 0f, 0f) {
            for (i in 0 until 4) {
                val ang = (i * 90f + 45f) * 0.0174533f
                val x = cos(ang) * 21f; val y = sin(ang) * 21f
                circ(c, x, y, 5f, IRON); circ(c, x, y, 2.4f, STEEL_DARK)
            }
        }
        if (k >= 4) part(c, appear(t, 2, 4), 0f, 0f) {
            for (i in 0 until 4) {
                c.save(); c.rotate(i * 90f + 45f)
                quad(c, 16f, -7f, 27f, -5f, 27f, 5f, 16f, 7f, IRON)
                ln(c, 18f, -6f, 26f, -4f, 1.4f, 0xFFFF8A2B.toInt()); ln(c, 18f, 6f, 26f, 4f, 1.4f, 0xFFFF8A2B.toInt())
                c.restore()
            }
        }
        if (a >= 5) { ring(c, 0f, 0f, 27f, 2f, ArtKit.withAlpha(0xFFFF5A3C.toInt(), 0.6f + 0.3f * sin(time * 4f))) }
        // Path B - gatling machinery on the carriage
        if (b >= 1) part(c, appear(t, 1, 1), -4f, -14f) {
            polygon(c, -5f, -14f, 5.5f, 8, time * 90f, STEEL_DARK); circ(c, -5f, -14f, 2f, IRON)
        }
        if (b >= 2) part(c, appear(t, 1, 2), -16f, 8f) {
            rr(c, -22f, 3f, -11f, 15f, 2f, IRON); rr(c, -21f, 4f, -12f, 8f, 1f, 0xFF50555D.toInt())
            for (i in 0 until 4) circ(c, -9f + i * 3.5f, 4f - i * 0.5f, 1.4f, GOLD)
        }
        c.save()
        c.rotate(aim)
        c.translate(-rec, 0f)
        rr(c, -13f, -10f, 9f, 10f, 3f, IRON)
        circ(c, -4f, -12f, 5f, 0xFF5E3D20.toInt()); circ(c, -4f, 12f, 5f, 0xFF5E3D20.toInt())
        circ(c, -4f, -12f, 2f, ArtKit.WOOD_LIGHT); circ(c, -4f, 12f, 2f, ArtKit.WOOD_LIGHT)
        var len = 27f
        var half = 5f
        if (a >= 1) half = 6.4f
        if (a >= 2) len = 32f
        if (a >= 4) { len = 37f; half = 8.2f }
        if (b >= 4) {
            val rot = time * (if (t != null && t.heat > 0.05f) 5f + t.heat * 18f else 1.2f)
            for (i in 0 until 4) {
                val yy = sin(rot + i * 1.5708f) * 6.5f
                rr(c, 2f, yy - 1.8f, 28f, yy + 1.8f, 1.5f, if (cos(rot + i * 1.5708f) > 0f) STEEL else STEEL_DARK)
            }
            rr(c, 26f, -8f, 30f, 8f, 1.5f, IRON)
            if (b >= 5) glow(c, 29f, 0f, 14f + (t?.heat ?: 0f) * 8f, 0xFFFF5A3C.toInt(), 0.5f + (t?.heat ?: 0f) * 0.4f)
        } else if (b >= 3) {
            rr(c, 0f, -9.4f, len, -2.2f, 2f, STEEL_DARK); rr(c, 0f, 2.2f, len, 9.4f, 2f, STEEL_DARK)
            rr(c, len - 4f, -10f, len, -1.6f, 1f, IRON); rr(c, len - 4f, 1.6f, len, 10f, 1f, IRON)
        } else {
            rr(c, 0f, -half, len, half, 2f, STEEL_DARK)
            ln(c, 2f, -half * 0.55f, len - 2f, -half * 0.55f, 1.2f, STEEL)
            rr(c, len - 4f, -half - 1.4f, len, half + 1.4f, 1.2f, IRON)
            if (a >= 2) rr(c, len - 2f, -half - 3f, len + 3f, half + 3f, 1.5f, IRON)
        }
        if (b >= 5) for (s in 0 until 2) {
            val y = if (s == 0) -17f else 17f
            rr(c, -8f, y - 4f, 10f, y + 4f, 2f, IRON)
            circ(c, 11f, y - 1.6f, 1.6f, 0xFFE0482E.toInt()); circ(c, 11f, y + 1.6f, 1.6f, 0xFFE0482E.toInt())
        }
        if (a >= 3) for (i in -1..1) { circ(c, -15f, i * 5.5f, 3.2f, IRON); circ(c, -17f, i * 5.5f, 1.6f, 0xFFE0482E.toInt()) }
        if (a >= 5) {
            for (i in 0 until 5) rr(c, 4f + i * 5.2f, -half, 6.6f + i * 5.2f, half, 0f, if (i % 2 == 0) 0xFFFFC21A.toInt() else 0xFF1A1A1A.toInt())
            glow(c, len + 2f, 0f, 14f, 0xFFFF7A2E.toInt(), 0.65f)
        }
        if (k >= 1) rr(c, 6f, -half - 0.8f, 15f, half + 0.8f, 1.2f, STEEL)
        if (k >= 2) { tri(c, len + 1f, -half - 1f, len + 1f, -half + 2.5f, len + 7f, -half - 4f, STEEL); tri(c, len + 1f, half + 1f, len + 1f, half - 2.5f, len + 7f, half + 4f, STEEL) }
        if (k >= 3) part(c, appear(t, 2, 3), len, 0f) {
            tri(c, len + 1f, -5.6f, len + 1f, 5.6f, len + 14f, 0f, STEEL)
            for (i in 0 until 3) ln(c, len + 3f + i * 3.4f, -4f + i * 1.2f, len + 4f + i * 3.4f, 4f - i * 1.2f, 1.1f, IRON)
        }
        if (k >= 5) glow(c, len + 13f, 0f, 12f + 2f * sin(time * 9f), 0xFFFF7A2E.toInt(), 0.8f)
        c.restore()
    }

    // =====================================================================
    // FROST
    // =====================================================================
    private fun frost(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        frostBody(c, time + t.idlePhase, aim, a, b, k, t)
    }

    private fun frostBody(c: Canvas, time: Float, aim: Float, a: Int, b: Int, k: Int, t: Tower?) {
        val bob = sin(time * 2.2f) * 1.6f
        val flash = if (t != null && t.flashRemaining > 0f) 1f else 0f
        circ(c, 0f, 0f, 25f, 0xFF2C5775.toInt()); circ(c, 0f, -1f, 22f, 0xFF3E7A9C.toInt())
        ring(c, 0f, -1f, 21f, 2f, 0xFF9FE8FF.toInt())
        oval(c, -16f, 6f, -4f, 12f, 0x66FFFFFF); oval(c, 6f, -15f, 17f, -9f, 0x55FFFFFF)
        if (a >= 1) for (i in 0 until 6) {
            val ang = i * 1.0472f + 0.3f
            val x = cos(ang) * 22f; val y = sin(ang) * 22f
            tri(c, x - sin(ang) * 3.4f, y + cos(ang) * 3.4f, x + sin(ang) * 3.4f, y - cos(ang) * 3.4f, cos(ang) * (if (a >= 2) 31f else 27f), sin(ang) * (if (a >= 2) 31f else 27f), 0xFFBFF3FF.toInt())
        }
        if (a >= 4) part(c, appear(t, 0, 4), 0f, 0f) {
            for (i in 0 until 4) {
                val ang = (i * 90f + 45f) * 0.0174533f
                val x = cos(ang) * 18f; val y = sin(ang) * 18f
                polygon(c, x, y, 8.5f, 6, i * 20f, 0xAA8FD6F0.toInt()); polygon(c, x - 1.5f, y - 1.5f, 4.5f, 6, i * 20f, 0xCCE6FBFF.toInt())
            }
        }
        if (b >= 1) {
            val spin = time * (if (b >= 2) 220f else 140f)
            for (s in 0 until 2) {
                val vx = if (s == 0) -17f else 17f
                val vy = if (s == 0) 15f else -15f
                c.save(); c.rotate(spin + s * 45f, vx, vy)
                val blades = if (b >= 2) 4 else 2
                for (i in 0 until blades) { c.save(); c.rotate(i * 360f / blades, vx, vy); ln(c, vx, vy, vx + 6.5f, vy, 2.2f, 0xFFE6FBFF.toInt()); c.restore() }
                c.restore()
                circ(c, vx, vy, 1.8f, STEEL_DARK)
            }
        }
        if (b >= 3) for (i in 0 until 8) arc(c, 0f, -1f, 25.5f, i * 45f + time * 30f, 26f, 3f, 0xCCFFFFFF.toInt())
        if (b >= 4) for (i in 0 until 4) {
            val ang = i * 1.5708f + 0.8f
            oval(c, cos(ang) * 29f - 7f, sin(ang) * 22f - 3f, cos(ang) * 29f + 7f, sin(ang) * 22f + 3f, 0x66BFF3FF)
        }
        // central crystal
        c.save()
        c.translate(0f, bob)
        glow(c, 0f, 0f, 18f + flash * 8f, if (a >= 5) 0xFF3A6BFF.toInt() else 0xFF9FE8FF.toInt(), 0.45f + flash * 0.4f)
        val spin = time * 22f
        if (k >= 1) for (i in 0 until 4) {
            val ang = (spin + i * 90f) * 0.0174533f
            tri(c, cos(ang) * 8f - sin(ang) * 3f, sin(ang) * 8f + cos(ang) * 3f, cos(ang) * 8f + sin(ang) * 3f, sin(ang) * 8f - cos(ang) * 3f, cos(ang) * 17f, sin(ang) * 17f, 0xFFB8F0FF.toInt())
        }
        polygon(c, 0f, 0f, 13f, 6, spin, if (a >= 5) 0xFF2F5FD8.toInt() else 0xFF8FDFF5.toInt())
        polygon(c, -1f, -1f, 8.5f, 6, spin, if (a >= 5) 0xFF6A8CFF.toInt() else 0xFFE6FBFF.toInt())
        if (k >= 3) { ln(c, -6f, -2f, 3f, 4f, 0.9f, 0xFFFFFFFF.toInt()); ln(c, 2f, -7f, 5f, 0f, 0.9f, 0xFFFFFFFF.toInt()) }
        c.restore()
        if (a >= 3) { ring(c, 0f, bob, 17f, 1.8f, 0xCCE6FBFF.toInt()); for (i in 0 until 4) { val ang = i * 1.5708f + time; polygon(c, cos(ang) * 17f, bob + sin(ang) * 17f, 2.2f, 4, 0f, 0xFFFFFFFF.toInt()) } }
        if (k >= 4) for (i in 0 until 3) {
            val ang = time * 1.4f + i * 2.0944f
            polygon(c, cos(ang) * 25f, sin(ang) * 25f, 4.5f, 4, time * 80f, 0xFFB08CFF.toInt())
        }
        // aim pointer / cryo cannon
        c.save()
        c.rotate(aim)
        if (k >= 5) {
            quad(c, 8f, 0f, 18f, -5f, 36f, 0f, 18f, 5f, 0xFFB08CFF.toInt())
            quad(c, 12f, 0f, 19f, -2.6f, 30f, 0f, 19f, 2.6f, 0xFFEBDDFF.toInt())
            glow(c, 36f, 0f, 10f + flash * 6f, 0xFFB08CFF.toInt(), 0.7f)
        } else if (k >= 2) {
            tri(c, 10f, -3.4f, 10f, 3.4f, 32f, 0f, 0xFFD3C0FF.toInt())
        } else {
            tri(c, 11f, -3f, 11f, 3f, 21f, 0f, ICE)
        }
        c.restore()
        if (b >= 5) {
            circ(c, -6f, -26f, 9f, 0xDDB7C4D2.toInt()); circ(c, 4f, -28f, 11f, 0xDDC8D3DF.toInt()); circ(c, 13f, -25f, 8f, 0xDDB7C4D2.toInt())
            for (i in 0 until 6) { val ph = time * 2f + i * 1.1f; circ(c, -10f + i * 4.4f + sin(ph) * 2f, -20f + ((ph * 5f) % 14f), 1.3f, 0xFFFFFFFF.toInt()) }
        }
        if (a >= 5) for (i in 0 until 7) { val ph = time * 0.9f + i * 0.37f; circ(c, -22f + i * 7.4f, -22f + (ph % 1f) * 46f, 1.2f, 0xCCFFFFFF.toInt()) }
    }

    // =====================================================================
    // RANGER
    // =====================================================================
    private fun ranger(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        rangerBody(c, t.recoil * 4f, if (t.flashRemaining > 0f) 1f else 0f, time + t.idlePhase, aim, a, b, k, t)
    }

    private fun rangerBody(c: Canvas, rec: Float, fired: Float, time: Float, aim: Float, a: Int, b: Int, k: Int, t: Tower?) {
        circ(c, 0f, 0f, 25f, 0xFF3E4A2E.toInt()); circ(c, 0f, -1f, 22.5f, 0xFF55633C.toInt())
        circ(c, -10f, 9f, 7f, 0xFF45532F.toInt()); circ(c, 10f, -8f, 6f, 0xFF68784A.toInt()); circ(c, 11f, 11f, 4.5f, 0xFF3E4A2E.toInt())
        ring(c, 0f, -1f, 22.5f, 1.6f, 0xFF2E3820.toInt())
        // Path B - tactical gear
        if (b >= 1) part(c, appear(t, 1, 1), 0f, -19f) {
            circ(c, -3f, -19f, 3.2f, 0xFF22262C.toInt()); circ(c, 3f, -19f, 3.2f, 0xFF22262C.toInt()); rr(c, -3f, -20f, 3f, -18f, 0f, IRON)
        }
        if (b >= 2) part(c, appear(t, 1, 2), 15f, 15f) {
            c.save(); c.rotate(time * 100f, 15f, 15f); ln(c, 15f, 15f, 15f, 6f, 2f, STEEL); arc(c, 15f, 10f, 6f, 180f, 180f, 2.2f, STEEL); c.restore()
            circ(c, 15f, 15f, 2.6f, IRON)
        }
        if (b >= 3) part(c, appear(t, 1, 3), -17f, -12f) {
            for (i in 0 until 3) {
                val x = -22f + i * 5f
                ln(c, x, -6f, x, -26f + i * 3f, 1.2f, STEEL)
                circ(c, x, -26f + i * 3f, 1.6f, if (((time * 3f + i).toInt() and 1) == 0) 0xFFFF4A4A.toInt() else 0xFF661A1A.toInt())
            }
        }
        if (b >= 4) {
            val pr = 27f + sin(time * 3f) * 2f
            ring(c, 0f, -1f, pr, 1.8f, ArtKit.withAlpha(0xFF5DD6FF.toInt(), 0.55f))
            part(c, appear(t, 1, 4), 22f, -22f) { ln(c, 22f, -10f, 22f, -34f, 1.6f, IRON); tri(c, 22f, -34f, 22f, -26f, 33f, -30f + sin(time * 4f), 0xFF5DD6FF.toInt()) }
        }
        if (b >= 5) {
            for (i in 0 until 12) arc(c, 0f, -1f, 31f, i * 30f + time * 22f, 14f, 2f, 0xAA5DD6FF.toInt())
            glow(c, 0f, -1f, 34f, 0xFF5DD6FF.toInt(), 0.22f)
        }
        c.save()
        c.rotate(aim)
        c.translate(-rec, 0f)
        circ(c, -1f, 0f, 8.6f, 0xFF5C6B38.toInt()); circ(c, 1.2f, 0f, 5.2f, 0xFF7C8A4A.toInt()); circ(c, 2.2f, 0f, 3.6f, SKIN)
        // rifle
        val thick = if (a >= 4) 3.3f else 2.2f
        val gold = a >= 5
        rr(c, -15f, -3.2f, 2f, 3.2f, 1.5f, WOOD_DARK)
        if (k >= 4) {
            rr(c, 2f, -4.2f, 38f, -1.6f, 1f, 0xFF2B3138.toInt()); rr(c, 2f, 1.6f, 38f, 4.2f, 1f, 0xFF2B3138.toInt())
            val zz = time * 40f
            ln(c, 6f, -2f, 14f, 2f * sin(zz), 1.4f, 0xFF7DF9FF.toInt()); ln(c, 14f, 2f * sin(zz), 22f, -2f * sin(zz + 1f), 1.4f, 0xFF7DF9FF.toInt()); ln(c, 22f, -2f * sin(zz + 1f), 36f, 0f, 1.4f, 0xFF7DF9FF.toInt())
        } else if (k >= 3) {
            for (i in -1..1) rr(c, 2f, i * 3.4f - 1.2f, 36f, i * 3.4f + 1.2f, 1f, IRON)
        } else {
            rr(c, 2f, -thick, 36f, thick, 1f, if (gold) GOLD else IRON)
            if (gold) rr(c, 10f, -thick - 0.6f, 12f, thick + 0.6f, 0f, 0xFFFFF0B0.toInt())
        }
        if (k >= 5) for (i in 0 until 4) { rr(c, 6f + i * 7f, -6.5f, 8.4f + i * 7f, 6.5f, 1f, 0xFF2B3138.toInt()); glow(c, 7.2f + i * 7f, 0f, 7f, 0xFF7DF9FF.toInt(), 0.5f) }
        val scopeLen = if (a >= 1) 14f else 10f
        rr(c, 6f, -6f, 6f + scopeLen, -2.8f, 1.4f, 0xFF2B2F36.toInt())
        circ(c, 6f + scopeLen, -4.4f, 1.9f, if (((time * 1.6f).toInt() and 3) == 0) 0xFFFFFFFF.toInt() else 0xFF7DB8FF.toInt())
        if (k >= 1) rr(c, -9f, 3f, -1f, 10f, 3f, 0xFF3A2E36.toInt())
        if (a >= 3) { rr(c, 36f, -2.8f, 44f, 2.8f, 1f, 0xFF22262C.toInt()); ln(c, 28f, 0f, 33f, -9f, 1.2f, STEEL_DARK); ln(c, 28f, 0f, 33f, 9f, 1.2f, STEEL_DARK) }
        if (a >= 4) { rr(c, 36f, -4.2f, 42f, 4.2f, 1f, STEEL_DARK); for (i in 0 until 3) ln(c, 37f + i * 2f, -4f, 37f + i * 2f, 4f, 0.8f, IRON) }
        if (a >= 2 && fired <= 0f) ln(c, 40f, 0f, 118f, 0f, 0.9f, 0x66FF3A3A)
        if (k >= 2) glow(c, 38f, 0f, 6f, 0xFFFF7BAC.toInt(), 0.5f)
        if (fired > 0f) glow(c, 40f, 0f, 14f, 0xFFFFF2B0.toInt(), 0.85f)
        if (a >= 5) { ring(c, 56f, 0f, 7.5f, 1.1f, 0xFF7DF9FF.toInt()); ln(c, 47f, 0f, 52f, 0f, 1f, 0xFF7DF9FF.toInt()); ln(c, 60f, 0f, 65f, 0f, 1f, 0xFF7DF9FF.toInt()); ln(c, 56f, -11f, 56f, -6f, 1f, 0xFF7DF9FF.toInt()); ln(c, 56f, 6f, 56f, 11f, 1f, 0xFF7DF9FF.toInt()) }
        c.restore()
    }

    // =====================================================================
    // LIGHTNING
    // =====================================================================
    private fun lightning(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        lightningBody(c, time + t.idlePhase, a, b, k, t)
    }

    private fun arcs(c: Canvas, x: Float, y: Float, len: Float, count: Int, seed: Int, col: Int, w: Float) {
        for (i in 0 until count) {
            val ang = ArtKit.hash(seed * 31 + i * 7) * 6.2832f
            var px = x; var py = y
            for (s in 1..3) {
                val a2 = ang + (ArtKit.hash(seed * 13 + i * 5 + s) - 0.5f) * 1.4f
                val nx = x + cos(a2) * len * s / 3f
                val ny = y + sin(a2) * len * s / 3f
                ln(c, px, py, nx, ny, w, col)
                px = nx; py = ny
            }
        }
    }

    private fun lightningBody(c: Canvas, time: Float, a: Int, b: Int, k: Int, t: Tower?) {
        val tick = (time * 12f).toInt()
        val flash = if (t != null && t.flashRemaining > 0f) 1f else 0f
        val violet = if (k >= 1) 0xFFB388FF.toInt() else 0xFFC9A6FF.toInt()
        polygon(c, 0f, 0f, 27f, 8, 22.5f, 0xFF30343C.toInt()); polygon(c, 0f, 0f, 23f, 8, 22.5f, IRON)
        ring(c, 0f, 0f, 21f, 1.6f, 0xFF7A808A.toInt())
        // Path B - chain nodes
        if (b >= 1) part(c, appear(t, 1, 1), 0f, 0f) {
            val hot = b >= 4
            val col = if (hot) 0xFFFF7A4A.toInt() else 0xFF7DF9FF.toInt()
            for (s in 0 until 2) {
                val x = if (s == 0) -22f else 22f
                ln(c, x, 0f, x, 6f, 3f, STEEL_DARK); circ(c, x, -2f, 4.4f, 0xFFD0D6DE.toInt())
                glow(c, x, -2f, 8f, col, if (hot) 0.5f + 0.3f * sin(time * 7f + s) else 0.4f)
                if (b >= 2) { val aa = (ArtKit.hash(tick + s) - 0.5f) * 5f; ln(c, x, -2f, x * 0.5f, aa, 1f, ArtKit.withAlpha(col, 0.8f)); ln(c, x * 0.5f, aa, 0f, 0f, 1f, ArtKit.withAlpha(col, 0.8f)) }
            }
        }
        if (b >= 3) for (i in 0 until 3) {
            val ang = time * 0.9f + i * 2.0944f
            val x = cos(ang) * 19f; val y = sin(ang) * 19f
            circ(c, x, y, 3.4f, 0xFFD0D6DE.toInt()); glow(c, x, y, 7f, if (b >= 4) 0xFFFF7A4A.toInt() else 0xFF7DF9FF.toInt(), 0.5f)
        }
        if (b >= 5) for (i in 0 until 4) {
            val ang = (i * 90f + 45f) * 0.0174533f
            val x = cos(ang) * 23f; val y = sin(ang) * 23f
            circ(c, x, y, 3.8f, 0xFFD0D6DE.toInt())
            val ang2 = ((i + 1) * 90f + 45f) * 0.0174533f
            val x2 = cos(ang2) * 23f; val y2 = sin(ang2) * 23f
            val mx = (x + x2) / 2f + (ArtKit.hash(tick + i) - 0.5f) * 8f
            val my = (y + y2) / 2f + (ArtKit.hash(tick * 3 + i) - 0.5f) * 8f
            ln(c, x, y, mx, my, 1.2f, 0xFF7DF9FF.toInt()); ln(c, mx, my, x2, y2, 1.2f, 0xFF7DF9FF.toInt())
        }
        // Path A - capacitors
        if (a >= 2) part(c, appear(t, 0, 2), 0f, 0f) {
            for (s in 0 until 2) {
                val y = if (s == 0) -20f else 20f
                rr(c, -10f, y - 4f, 10f, y + 4f, 3f, 0xFF3A5AA8.toInt()); rr(c, -6f, y - 4f, -3f, y + 4f, 0f, 0xFFFFE066.toInt()); rr(c, 3f, y - 4f, 6f, y + 4f, 0f, 0xFFFFE066.toInt())
            }
        }
        // Path C - electromagnetics
        if (k >= 1) { ovalStroke(c, -17f, -7f, 17f, 7f, 2.4f, 0xFFB388FF.toInt()); if (k >= 4) { c.save(); c.rotate(time * 40f); ovalStroke(c, -19f, -6f, 19f, 6f, 2.2f, 0xFFD3BBFF.toInt()); c.restore() } }
        if (k >= 2) part(c, appear(t, 2, 2), 16f, 16f) {
            arc(c, 18f, 18f, 8f, 180f, 90f, 2.6f, STEEL); circ(c, 14f, 14f, 1.8f, 0xFFB388FF.toInt()); glow(c, 14f, 14f, 6f, 0xFFB388FF.toInt(), 0.5f)
        }
        if (k >= 3) { val pr = 27f + sin(time * 3f) * 2.5f; ring(c, 0f, 0f, pr, 2f, ArtKit.withAlpha(0xFFB388FF.toInt(), 0.6f)); glow(c, 0f, 0f, pr, 0xFFB388FF.toInt(), 0.16f) }
        if (k >= 4) for (i in 0 until 4) { c.save(); c.rotate(i * 90f + time * 25f); ln(c, 10f, 0f, 24f, 0f, 3f, IRON); circ(c, 25f, 0f, 3f, 0xFFB388FF.toInt()); glow(c, 25f, 0f, 7f, 0xFFB388FF.toInt(), 0.6f); c.restore() }
        if (k >= 5) { circ(c, -8f, -26f, 9f, 0xCC3A3550.toInt()); circ(c, 4f, -28f, 11f, 0xCC4A4468.toInt()); circ(c, 14f, -25f, 8f, 0xCC3A3550.toInt()); glow(c, 4f, -27f, 22f, 0xFFB388FF.toInt(), 0.3f + 0.2f * sin(time * 9f)) }
        // coil
        circ(c, 0f, 0f, 16f, 0xFFB5733A.toInt()); circ(c, 0f, 0f, 14f, 0xFF8E5628.toInt())
        for (i in 0 until 3) ring(c, 0f, 0f, 6f + i * 3.4f, 1.2f, 0xFFD79A5A.toInt())
        circ(c, 0f, 0f, 11f, IRON); circ(c, 0f, 0f, 9f, 0xFF50555D.toInt())
        val sr = (if (a >= 1) 9.2f else 7.6f) + flash * 1.4f
        glow(c, 0f, 0f, sr * 2.8f, violet, 0.5f + flash * 0.4f)
        circ(c, 0f, 0f, sr, 0xFFE4E7EE.toInt()); circ(c, -1.6f, -1.6f, sr * 0.5f, 0xFFFFFFFF.toInt())
        if (a >= 3) { c.save(); c.rotate(time * 70f); ovalStroke(c, -15f, -4f, 15f, 4f, 2f, 0xFFFFE066.toInt()); c.restore() }
        if (a >= 4) { ln(c, 0f, 0f, 0f, -32f, 1.6f, STEEL); tri(c, -2.4f, -30f, 2.4f, -30f, 0f, -40f, 0xFFFFFFFF.toInt()); glow(c, 0f, -38f, 8f, 0xFFFFE066.toInt(), 0.7f) }
        if (a >= 5) {
            ring(c, 0f, 0f, 13f, 2.2f, GOLD)
            for (i in 0 until 8) { val ang = i * 0.7854f; tri(c, cos(ang) * 12f - sin(ang) * 2f, sin(ang) * 12f + cos(ang) * 2f, cos(ang) * 12f + sin(ang) * 2f, sin(ang) * 12f - cos(ang) * 2f, cos(ang) * 18f, sin(ang) * 18f, GOLD) }
            ln(c, -6f, -2f, -6f, -30f, 1.4f, STEEL); circ(c, -6f, -31f, 2.4f, 0xFFFFFFFF.toInt()); ln(c, 6f, -2f, 6f, -30f, 1.4f, STEEL); circ(c, 6f, -31f, 2.4f, 0xFFFFFFFF.toInt())
            glow(c, 0f, 0f, 26f, GOLD, 0.35f)
        }
        val arcCount = 2 + (if (a >= 5 || k >= 5) 3 else 0) + (if (flash > 0f) 2 else 0)
        arcs(c, 0f, 0f, if (a >= 5) 30f else 22f, arcCount, tick, 0xFFFFFFFF.toInt(), 1.4f)
        arcs(c, 0f, 0f, if (a >= 5) 30f else 22f, arcCount, tick + 91, violet, 2.4f)
    }

    // =====================================================================
    // FLAME
    // =====================================================================
    private fun flameTower(c: Canvas, t: Tower, time: Float, aim: Float, a: Int, b: Int, k: Int) {
        flameBody(c, t.recoil * 2f, time + t.idlePhase, aim, a, b, k, t, if (t.firingTimer > 0.05f || t.flashRemaining > 0f) 1f else 0f)
    }

    private fun flameBody(c: Canvas, rec: Float, time: Float, aim: Float, a: Int, b: Int, k: Int, t: Tower?, firing: Float) {
        val ph = time * 3f
        val green = k >= 1
        val stream = if (green) 0xFF8CFF4A.toInt() else ArtKit.FIRE
        polygon(c, 0f, 0f, 27f, 8, 22.5f, 0xFF23262B.toInt()); polygon(c, 0f, 0f, 24f, 8, 22.5f, IRON)
        for (i in 0 until 8) arc(c, 0f, 0f, 23.5f, i * 45f + 2f, 38f, 3.2f, if (i % 2 == 0) 0xFFFFB02E.toInt() else 0xFF22252A.toInt())
        if (b >= 3) { glow(c, 0f, 4f, 34f, ArtKit.FIRE, 0.22f + 0.08f * sin(ph)); for (i in 0 until 6) circ(c, cos(i * 1.047f) * 20f, sin(i * 1.047f) * 20f, 1.6f, ArtKit.withAlpha(0xFFFF8A2B.toInt(), 0.5f + 0.4f * sin(ph + i))) }
        // fuel tank(s)
        val tank = if (green) 0xFF3E9A48.toInt() else 0xFFB3392E.toInt()
        rr(c, -23f, -10f, -4f, 10f, 5f, tank); rr(c, -21f, -8f, -6f, -3f, 3f, ArtKit.shade(tank, 1.35f))
        ln(c, -15f, -10f, -15f, 10f, 1.4f, ArtKit.shade(tank, 0.7f)); circ(c, -13f, 0f, 2.2f, STEEL)
        if (a >= 2 || k >= 4) part(c, appear(t, if (a >= 2) 0 else 2, if (a >= 2) 2 else 4), -14f, -16f) {
            val tank2 = if (k >= 4) 0xFF8F4BD9.toInt() else tank
            rr(c, -21f, -22f, -6f, -14f, 4f, tank2); circ(c, -10f, -18f, 2.4f, 0xFFE8E8E8.toInt()); ln(c, -10f, -18f, -10f + cos(time * 2f) * 1.8f, -18f + sin(time * 2f) * 1.8f, 1f, IRON)
        }
        if (k >= 4) for (i in 0 until 4) circ(c, -18f + i * 4f, -8f + sin(ph + i * 1.4f) * 3f, 1.4f, 0x99C8FF9A.toInt())
        if (k >= 2) part(c, appear(t, 2, 2), -14f, 15f) {
            rr(c, -19f, 11f, -9f, 17f, 2f, IRON)
            for (i in 0 until 3) { val pp = (time * 0.9f + i * 0.33f) % 1f; circ(c, -14f + i * 2f + pp * 3f, 11f - pp * 14f, 2.2f + pp * 3f, ArtKit.withAlpha(0xFF8CFF4A.toInt(), 0.5f * (1f - pp))) }
        }
        if (b >= 2) part(c, appear(t, 1, 2), 0f, 0f) {
            for (s in 0 until 2) {
                val x = if (s == 0) -6f else 22f; val y = -21f
                rr(c, x - 4.5f, y - 5f, x + 4.5f, y + 5f, 2.4f, 0xFFD9A021.toInt()); rr(c, x - 4.5f, y - 1f, x + 4.5f, y + 1.6f, 0f, 0xFF22252A.toInt()); circ(c, x, y - 5f, 1.4f, 0xFFE0482E.toInt())
                if (b >= 4) ln(c, x, y - 5f, if (s == 0) 8f else 8f, -9f, 1.2f, if (((time * 6f).toInt() and 1) == 0) 0xFFFFE066.toInt() else 0xFFE0482E.toInt())
            }
        }
        if (k >= 1 && k < 2) part(c, appear(t, 2, 1), 8f, 20f) { rr(c, 3f, 15f, 13f, 24f, 3f, 0xFF3E9A48.toInt()); glow(c, 8f, 19f, 9f, 0xFF8CFF4A.toInt(), 0.5f) }
        if (b >= 5) for (i in 0 until 6) { val ang = i * 1.0472f + time * 0.6f; flameUp(c, cos(ang) * 21f, sin(ang) * 21f + 6f, 3.4f, ph + i, ArtKit.FIRE) }
        if (a >= 5) { val pulse = 0.5f + 0.5f * sin(time * 5f); ring(c, 0f, 0f, 12f + pulse * 2f, 2.4f, 0xFFFF7A2E.toInt()); glow(c, 0f, 0f, 24f, 0xFFFF5A1F.toInt(), 0.45f + pulse * 0.3f); if (k >= 5) glow(c, 0f, 0f, 16f, 0xFF9BFFD0.toInt(), 0.6f) }
        else if (k >= 5) { glow(c, 0f, 0f, 20f, 0xFF9BFFD0.toInt(), 0.65f); ring(c, 0f, 0f, 9f, 2f, 0xFFE6FFF0.toInt()) }
        // turret
        c.save()
        c.rotate(aim)
        c.translate(-rec, 0f)
        if (a >= 3) { for (i in 0 until 3) { val x = 3f + i * 6f; rr(c, x, -7.5f, x + 4.4f, 7.5f, 1.5f, 0xFF7A2E1C.toInt()); glow(c, x + 2.2f, 0f, 7f, 0xFFFF6A2E.toInt(), 0.4f + 0.2f * sin(ph + i)) } }
        val twin = a >= 4
        if (k >= 3) {
            rr(c, 0f, -6.2f, 25f, 6.2f, 3.2f, 0xFF30343B.toInt()); rr(c, 22f, -7.6f, 28f, 7.6f, 2f, STEEL_DARK); circ(c, 28f, 0f, 3.2f, 0xFF16191D.toInt())
            glow(c, 30f, 0f, 9f, stream, 0.4f + firing * 0.4f)
        } else if (twin) {
            for (s in 0 until 2) { val y = if (s == 0) -5.4f else 5.4f; rr(c, 0f, y - 2.6f, 22f, y + 2.6f, 1.6f, STEEL_DARK); quad(c, 22f, y - 2.2f, 28f, y - 4.6f, 28f, y + 4.6f, 22f, y + 2.2f, IRON) }
        } else {
            rr(c, 0f, -3.6f, 20f, 3.6f, 2f, STEEL_DARK)
            val w = if (a >= 1) 7f else 5.2f
            quad(c, 20f, -3f, 27f, -w, 27f, w, 20f, 3f, IRON)
            ln(c, 2f, -2f, 18f, -2f, 1.2f, STEEL)
        }
        if (b >= 1) { val sp = ((time * 14f).toInt() and 1) == 0; if (sp) { ln(c, 26f, -6f, 29f, -8f, 1.2f, 0xFFFFFFFF.toInt()); circ(c, 29f, -8f, 1.4f, 0xFFB8F0FF.toInt()) } }
        if (firing > 0f) {
            val x0 = if (k >= 3) 31f else 28f
            flameFwd(c, x0, 0f, 6.5f + (if (a >= 4) 2.5f else 0f) + (if (a >= 5) 3f else 0f), ph * 2f, stream)
            if (twin) { flameFwd(c, x0, -5f, 4.5f, ph * 2f + 1f, stream); flameFwd(c, x0, 5f, 4.5f, ph * 2f + 2f, stream) }
        } else {
            flameFwd(c, if (k >= 3) 31f else 28f, 0f, 2.2f, ph, stream)
        }
        c.restore()
    }
}
