package com.ironpath.defense.ability

/** The player's three active abilities (HUD buttons on the left edge). */
enum class AbilityType(
    val label: String,
    val hint: String,
    val cooldownSeconds: Float,
    val colorArgb: Int,
    val needsTarget: Boolean
) {
    STRIKE("Strike", "Tap, then tap the battlefield: heavy blast.", 45f, 0xFFFF6A3C.toInt(), true),
    FREEZE("Cryo", "Slows and briefly stuns every enemy.", 60f, 0xFF7FD8FF.toInt(), false),
    OVERDRIVE("Boost", "All towers fire 50% faster for 6s.", 75f, 0xFFFFD84A.toInt(), false)
}
