package com.ironpath.defense.engine

import com.ironpath.defense.core.Difficulty

/** Immutable snapshot of a finished run for the victory/defeat screens. */
class RunSummary(
    val victory: Boolean,
    val mapName: String,
    val difficulty: Difficulty,
    val wave: Int,
    val totalWaves: Int,
    val kills: Int,
    val moneyEarned: Int,
    val towersBuilt: IntArray,
    val livesLeft: Int,
    val maxLives: Int,
    val score: Int,
    val stars: Int,
    val reason: String,
    val newBest: Boolean,
    val unlockedMap: String?,
    val trophies: List<String>
)
