package com.ironpath.defense.entity.projectile

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.HitResolver
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.zone.ZoneSystem
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Owns pooled projectiles: flight (homing, lead-predicted ballistic, piercing)
 * and impact resolution (single target, splash with cluster blasts, chain
 * lightning with superconduct links, lingering zones).
 */
class ProjectileSystem(
    private val collision: CollisionSystem,
    private val hitResolver: HitResolver,
    private val zones: ZoneSystem,
    private val feedback: CombatFeedback
) {
    private val pool = ObjectPool(
        initialCapacity = 64,
        factory = { Projectile() },
        reset = {
            it.alive = false
            it.homingTarget = null
            it.shot.reset()
            it.age = 0f
            it.hitCount = 0
            it.pierceLeft = 0
            it.piercing = false
            it.travelled = 0f
        }
    )
    private val activeList = ArrayList<Projectile>(160)
    private val hitScratch = ArrayList<Enemy>(48)
    private val chainScratch = ArrayList<Enemy>(32)
    private val pierceScratch = ArrayList<Enemy>(24)
    private val alreadyHit = ArrayList<Enemy>(16)
    private val tmp = Vector2()

    val active: List<Projectile> get() = activeList

    /** Spawns a projectile at the tower's muzzle. Fill `shot` on the returned projectile. */
    fun spawn(type: ProjectileType, origin: Vector2, target: Enemy, pierce: Int = 0): Projectile {
        val p = pool.obtain()
        p.type = type
        var aimX = target.position.x
        var aimY = target.position.y
        if (!type.isHoming) {
            // Lead the target: aim where it will be when the projectile arrives.
            val speed = target.effectiveSpeed()
            if (speed > 0f) {
                val vx = cos(target.heading) * speed
                val vy = sin(target.heading) * speed
                var t = hypot(aimX - origin.x, aimY - origin.y) / type.speed
                repeat(2) {
                    val tt = t.coerceAtMost(MAX_LEAD_SECONDS)
                    aimX = target.position.x + vx * tt
                    aimY = target.position.y + vy * tt
                    t = hypot(aimX - origin.x, aimY - origin.y) / type.speed
                }
            }
        }
        val dx = aimX - origin.x
        val dy = aimY - origin.y
        val length = hypot(dx, dy)
        if (length > 0.001f) {
            p.dirX = dx / length
            p.dirY = dy / length
        } else {
            p.dirX = 1f
            p.dirY = 0f
        }
        p.position.set(origin.x + p.dirX * MUZZLE_OFFSET, origin.y + p.dirY * MUZZLE_OFFSET)
        p.alive = true
        if (type.isHoming) {
            p.homingTarget = target
            p.homingTargetGeneration = target.generation
            p.targetPoint.set(aimX, aimY)
        } else {
            p.homingTarget = null
            if (pierce > 0) {
                p.piercing = true
                p.pierceLeft = pierce
                p.maxTravel = length + PIERCE_OVERSHOOT
                p.targetPoint.set(origin.x + p.dirX * p.maxTravel, origin.y + p.dirY * p.maxTravel)
            } else {
                p.targetPoint.set(aimX, aimY)
            }
        }
        activeList.add(p)
        return p
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeList.size) {
            val p = activeList[i]
            p.age += dt
            if (p.piercing) {
                if (updatePiercing(p, dt)) {
                    if (p.shot.zoneKind > 0 && p.shot.zoneSeconds > 0f) zones.spawnFromShot(p.position.x, p.position.y, p.shot)
                    releaseAt(i)
                } else {
                    i++
                }
                continue
            }
            val destination: Vector2? = if (p.type.isHoming) {
                if (p.isHomingTargetValid()) p.homingTarget!!.position else null
            } else {
                p.targetPoint
            }
            if (destination == null) {
                releaseAt(i)
                continue
            }
            val stepDistance = p.type.speed * dt
            val distance = p.position.distanceTo(destination)
            if (distance > 0.001f) {
                p.dirX = (destination.x - p.position.x) / distance
                p.dirY = (destination.y - p.position.y) / distance
            }
            if (distance <= stepDistance) {
                p.position.set(destination)
                resolveImpact(p)
                releaseAt(i)
                continue
            }
            p.position.moveToward(destination, stepDistance)
            i++
        }
    }

    /** Returns true when the piercing shot has finished (out of pierce or out of range). */
    private fun updatePiercing(p: Projectile, dt: Float): Boolean {
        val step = p.type.speed * dt
        p.position.x += p.dirX * step
        p.position.y += p.dirY * step
        p.travelled += step
        collision.queryRadiusInto(p.position, PIERCE_QUERY_RADIUS, pierceScratch)
        for (k in 0 until pierceScratch.size) {
            val e = pierceScratch[k]
            if (p.hasHit(e.uid)) continue
            val dx = e.position.x - p.position.x
            val dy = e.position.y - p.position.y
            val r = e.radius + PIERCE_HIT_PAD
            if (dx * dx + dy * dy > r * r) continue
            if (p.hitCount < Projectile.MAX_PIERCE_HITS) {
                p.hitUids[p.hitCount] = e.uid
                p.hitCount++
            }
            feedback.onImpact(p.type, p.position.x, p.position.y, p.shot)
            hit(e, p.shot, p.shot.damage)
            if (p.shot.splashRadius > 0f) {
                applySplash(e.position.x, e.position.y, p.shot.splashRadius, p.shot.damage * 0.5f, p.shot, e)
            }
            p.pierceLeft--
            if (p.pierceLeft < 0 || p.hitCount >= Projectile.MAX_PIERCE_HITS) return true
        }
        return p.travelled >= p.maxTravel
    }

    private fun resolveImpact(p: Projectile) {
        feedback.onImpact(p.type, p.position.x, p.position.y, p.shot)
        when {
            p.shot.chainCount > 0 -> resolveChain(p)
            p.shot.splashRadius > 0f -> resolveSplash(p)
            else -> resolveSingleTarget(p)
        }
        if (p.shot.zoneKind > 0 && p.shot.zoneSeconds > 0f) zones.spawnFromShot(p.position.x, p.position.y, p.shot)
    }

    private fun resolveSingleTarget(p: Projectile) {
        val target = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: nearestTo(p.position.x, p.position.y, IMPACT_SNAP_RADIUS)
            ?: return // ballistic shot arrived and nothing is there anymore: a clean miss
        hit(target, p.shot, p.shot.damage)
    }

    private fun resolveSplash(p: Projectile) {
        val s = p.shot
        feedback.onSplash(p.position, s.splashRadius, s.colorArgb)
        applySplash(p.position.x, p.position.y, s.splashRadius, s.damage, s, null)
        if (s.clusterCount > 0) {
            val base = p.age * 7.3f
            val r = s.splashRadius * 0.6f
            for (k in 0 until s.clusterCount) {
                val a = base + k * (6.2832f / s.clusterCount)
                val cx = p.position.x + cos(a) * s.splashRadius * 0.9f
                val cy = p.position.y + sin(a) * s.splashRadius * 0.9f
                tmp.set(cx, cy)
                feedback.onSplash(tmp, r, s.colorArgb)
                applySplash(cx, cy, r, s.damage * s.clusterDamageFraction, s, null)
            }
        }
    }

    private fun applySplash(x: Float, y: Float, radius: Float, damage: Float, shot: ShotProfile, exclude: Enemy?) {
        tmp.set(x, y)
        collision.queryRadiusInto(tmp, radius, hitScratch)
        for (k in 0 until hitScratch.size) {
            val e = hitScratch[k]
            if (e !== exclude) hit(e, shot, damage)
        }
    }

    private fun resolveChain(p: Projectile) {
        val s = p.shot
        alreadyHit.clear()
        var currentDamage = s.damage
        var current: Enemy? = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: nearestTo(p.position.x, p.position.y, IMPACT_SNAP_RADIUS)
        var hitsRemaining = s.chainCount + 1 // the primary hit counts as one
        if (current != null && s.superconduct > 0 && current.isSlowed) hitsRemaining += s.superconduct
        while (current != null && hitsRemaining > 0) {
            val enemy: Enemy = current
            alreadyHit.add(enemy)
            hit(enemy, s, currentDamage)
            if (s.splashRadius > 0f) {
                feedback.onSplash(enemy.position, s.splashRadius, s.colorArgb)
                applySplash(enemy.position.x, enemy.position.y, s.splashRadius, currentDamage * 0.5f, s, enemy)
            }
            hitsRemaining--
            if (hitsRemaining == 0) break
            val next = nextChainTarget(enemy, s.chainRadius)
            if (next != null) feedback.onChainLink(enemy.position, next.position, s.colorArgb)
            current = next
            currentDamage *= s.chainDamageFalloff
        }
    }

    private fun nextChainTarget(from: Enemy, radius: Float): Enemy? {
        collision.queryRadiusInto(from.position, radius, chainScratch)
        var best: Enemy? = null
        var bestD = Float.MAX_VALUE
        for (k in 0 until chainScratch.size) {
            val e = chainScratch[k]
            if (alreadyHit.contains(e)) continue
            val d = from.position.distanceSquaredTo(e.position)
            if (d < bestD) {
                bestD = d
                best = e
            }
        }
        return best
    }

    private fun nearestTo(x: Float, y: Float, radius: Float): Enemy? {
        tmp.set(x, y)
        collision.queryRadiusInto(tmp, radius, hitScratch)
        var best: Enemy? = null
        var bestD = Float.MAX_VALUE
        for (k in 0 until hitScratch.size) {
            val e = hitScratch[k]
            val d = tmp.distanceSquaredTo(e.position)
            if (d < bestD) {
                bestD = d
                best = e
            }
        }
        return best
    }

    private fun hit(enemy: Enemy, shot: ShotProfile, damage: Float) {
        val dealt = hitResolver.apply(enemy, shot, damage)
        feedback.onEnemyHit(enemy, dealt, shot.isCrit, shot.sourceType)
    }

    fun clear() {
        for (p in activeList) {
            p.alive = false
            p.homingTarget = null
            pool.free(p)
        }
        activeList.clear()
    }

    private fun releaseAt(index: Int) {
        val p = activeList[index]
        val lastIndex = activeList.size - 1
        activeList[index] = activeList[lastIndex]
        activeList.removeAt(lastIndex)
        p.alive = false
        p.homingTarget = null
        pool.free(p)
    }

    companion object {
        private const val IMPACT_SNAP_RADIUS = 22f
        private const val MUZZLE_OFFSET = 12f
        private const val MAX_LEAD_SECONDS = 0.9f
        private const val PIERCE_OVERSHOOT = 150f
        private const val PIERCE_QUERY_RADIUS = 52f
        private const val PIERCE_HIT_PAD = 7f
    }
}
