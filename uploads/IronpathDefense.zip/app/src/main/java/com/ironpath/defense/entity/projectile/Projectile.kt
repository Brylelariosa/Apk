package com.ironpath.defense.entity.projectile

import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy

/**
 * One in-flight projectile. Pooled; never allocate these directly.
 * Homing types chase [homingTarget]; ballistic ones fly to [targetPoint]
 * (already lead-predicted). Piercing ballistic shots keep flying through
 * [maxTravel] and remember which enemies they already hit.
 */
class Projectile {
    lateinit var type: ProjectileType
    val position = Vector2()
    val targetPoint = Vector2()
    val shot = ShotProfile()
    var homingTarget: Enemy? = null
    var homingTargetGeneration = -1
    var dirX = 1f
    var dirY = 0f
    var alive = false
    var age = 0f
    var piercing = false
    var pierceLeft = 0
    var travelled = 0f
    var maxTravel = 0f
    val hitUids = IntArray(MAX_PIERCE_HITS)
    var hitCount = 0

    fun isHomingTargetValid(): Boolean {
        val target = homingTarget ?: return false
        return target.alive && target.generation == homingTargetGeneration
    }

    fun hasHit(uid: Int): Boolean {
        for (i in 0 until hitCount) if (hitUids[i] == uid) return true
        return false
    }

    companion object {
        const val MAX_PIERCE_HITS = 16
    }
}
