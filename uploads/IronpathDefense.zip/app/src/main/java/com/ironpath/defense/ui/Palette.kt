package com.ironpath.defense.ui

/** Shared UI colors. Menus and HUD draw only from here so the look stays consistent. */
object Palette {
    val VOID = 0xFF0C1016.toInt()
    val PANEL = 0xE60F151D.toInt()
    val PANEL_SOLID = 0xFF141B25.toInt()
    val PANEL_LIGHT = 0xFF1E2835.toInt()
    val EDGE = 0xFF3A4A5E.toInt()
    val EDGE_BRIGHT = 0xFF6F86A3.toInt()
    val TEXT = 0xFFF1EEE4.toInt()
    val TEXT_DIM = 0xFFA8B3C2.toInt()
    val TEXT_FAINT = 0xFF6C7787.toInt()
    val GOLD = 0xFFFFD35A.toInt()
    val GOLD_DARK = 0xFFC9962A.toInt()
    val GREEN = 0xFF58D67A.toInt()
    val RED = 0xFFFF5A5A.toInt()
    val ORANGE = 0xFFFF9A3C.toInt()
    val BLUE = 0xFF58B8FF.toInt()
    val CYAN = 0xFF7DF9FF.toInt()
    val PURPLE = 0xFFB388FF.toInt()
    val HEALTH_BACK = 0xFF2A1A1C.toInt()
    val HEALTH_OK = 0xFF58D67A.toInt()
    val HEALTH_LOW = 0xFFFF5A5A.toInt()
    val SHIELD = 0xFF8FD8FF.toInt()
    val SCRIM = 0xAA05080C.toInt()
    val GATE_SPAWN = 0xFFD4505C.toInt()
    val GATE_BASE = 0xFF4DA3F0.toInt()
}
