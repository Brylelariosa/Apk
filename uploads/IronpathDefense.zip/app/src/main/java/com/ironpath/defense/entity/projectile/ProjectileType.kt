package com.ironpath.defense.entity.projectile

/**
 * Projectile archetypes. Speed/homing decide flight; the renderer draws each
 * one differently and upgrades change which type a tower fires (ballista
 * bolts, fuel globs, rail slugs).
 */
enum class ProjectileType(
    val displayName: String,
    val speed: Float,
    val isHoming: Boolean,
    val colorArgb: Int,
    val radius: Float
) {
    ARROW("Arrow", 520f, false, 0xFFE8E4D8.toInt(), 4f),
    CANNONBALL("Cannonball", 260f, false, 0xFF3B3B3E.toInt(), 7f),
    FROST_SHARD("Frost Shard", 380f, true, 0xFFBFF3EF.toInt(), 5f),
    RANGER_DART("Sniper Round", 620f, false, 0xFFD8E8B0.toInt(), 4f),
    LIGHTNING_BOLT("Lightning Bolt", 900f, true, 0xFFE9D9FF.toInt(), 3f),
    FLAME("Flame", 430f, false, 0xFFFF9A3C.toInt(), 6f),
    FUEL_GLOB("Fuel Glob", 300f, false, 0xFF9BE04A.toInt(), 7f),
    BALLISTA_BOLT("Ballista Bolt", 700f, false, 0xFFF2E3B0.toInt(), 5f),
    RAIL_SLUG("Rail Slug", 1100f, false, 0xFF8EF3FF.toInt(), 3f)
}
