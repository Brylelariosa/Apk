package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.ironpath.defense.engine.GameRun
import com.ironpath.defense.entity.tower.TargetingMode
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerStats
import com.ironpath.defense.entity.tower.upgrade.PathRole
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import com.ironpath.defense.render.TowerArt
import java.util.Locale

/**
 * The tower inspector: header, live stats, all THREE upgrade paths at once
 * (tier pips, MAIN / CROSS / LOCKED labels, next upgrade and cost) and a detail
 * card for the selected path with the exact stat changes the next tier makes,
 * the fusion it would unlock, and the buy button. Docked to the side opposite
 * the tower so the tower stays visible.
 */
class TowerPanel(private val kit: UiKit, private val layout: UiLayout) {
    val rect = RectF()
    var onRight = true
        private set

    private val a = RectF()
    private val b = RectF()
    private val descCache = WrapCache()
    private val diffLabels = Array(DIFF_MAX) { "" }
    private val diffValues = Array(DIFF_MAX) { "" }
    private var diffCount = 0
    private var diffKey = Long.MIN_VALUE

    /** Computes where the panel sits for [tower]; call before drawing other HUD parts. */
    fun layoutFor(tower: Tower) {
        val m = kit.dp(8f)
        val width = minOf(kit.dp(430f), layout.screenWidth * 0.56f)
        val towerX = layout.worldToScreenX(tower.position.x)
        onRight = towerX < layout.screenWidth * 0.5f
        val top = layout.safeTop + m + kit.dp(48f) + m * 0.5f
        val bottom = layout.safeBottom - m * 0.5f
        if (onRight) rect.set(layout.safeRight - m - width, top, layout.safeRight - m, bottom)
        else rect.set(layout.safeLeft + m, top, layout.safeLeft + m + width, bottom)
    }

    fun draw(c: Canvas, run: GameRun, tower: Tower, time: Float) {
        val fit = (rect.height() / kit.dp(296f)).coerceIn(0.78f, 1.2f)
        fun u(v: Float): Float = kit.dp(v) * fit
        fun sz(v: Float): Float = v * fit
        kit.panel(c, rect, 12f, Palette.PANEL, Palette.EDGE_BRIGHT, 1.6f)
        kit.hitArea(UiId.BLOCK, rect) // swallow taps on the panel body so they never fall through to the battlefield
        val left = rect.left + u(8f)
        val right = rect.right - u(8f)
        var y = rect.top + u(6f)
        val accent = tower.accentColorArgb

        // --- header ---------------------------------------------------------
        TowerArt.draw(c, tower, left + u(22f), y + u(22f), u(0.58f), time)
        kit.textMid(c, tower.classTitle, left + u(50f), y + u(13f), sz(15f), accent)
        kit.textMid(c, "${tower.type.displayName}  ${UpgradeRules.buildCode(tower.pathTiers)}", left + u(50f), y + u(31f), sz(10.5f), Palette.TEXT_DIM, Paint.Align.LEFT, false)
        a.set(right - u(34f), y + u(2f), right, y + u(36f))
        kit.iconButton(c, a, UiId.CLOSE_PANEL, UiKit.ICON_CLOSE, UiKit.SECONDARY)
        y += u(42f)

        // --- stats ---------------------------------------------------------------
        val s = tower.effective
        val cellW = (right - left - u(6f) * 3f) / 4f
        val rangeMult = run.modifiers.towerRangeMult
        statCell(c, left, y, cellW, u(28f), "DAMAGE", damageText(s), sz(9f), sz(12.5f))
        statCell(c, left + (cellW + u(6f)), y, cellW, u(28f), "RATE", rateText(s), sz(9f), sz(12.5f))
        statCell(c, left + (cellW + u(6f)) * 2f, y, cellW, u(28f), "RANGE", (s.range * rangeMult).toInt().toString(), sz(9f), sz(12.5f))
        a.set(left + (cellW + u(6f)) * 3f, y, right, y + u(28f))
        kit.button(c, a, UiId.TARGET, targetName(tower.targetingMode), UiKit.SECONDARY, true, sz(11.5f))
        y += u(32f)

        // --- path cards (left) + detail (right) ------------------------------
        val colW = u(176f)
        val cardH = u(52f)
        val gap = u(4f)
        for (p in 0 until 3) pathCard(c, run, tower, p, left, y + p * (cardH + gap), colW, cardH, fit)
        val dx = left + colW + u(6f)
        b.set(dx, y, right, y + cardH * 3f + gap * 2f)
        detail(c, run, tower, b, fit)
        y += cardH * 3f + gap * 2f + u(6f)

        // --- bottom row: sell + synergy info --------------------------------------
        a.set(left, y, left + u(110f), rect.bottom - u(6f))
        kit.button(c, a, UiId.SELL, "SELL $${tower.sellValue}", UiKit.DANGER, true, sz(12f))
        val info = infoLine(tower)
        if (info != null) {
            kit.textFit(c, info, left + u(118f), (a.top + a.bottom) / 2f, right - left - u(118f), sz(11f),
                if (tower.fusion != null) Palette.GOLD else Palette.CYAN)
        }
    }

    private fun statCell(c: Canvas, x: Float, y: Float, w: Float, h: Float, label: String, value: String, labelSz: Float, valueSz: Float) {
        a.set(x, y, x + w, y + h)
        kit.panel(c, a, 7f, Palette.PANEL_LIGHT, Palette.EDGE, 1f)
        kit.textMid(c, label, x + w / 2f, y + h * 0.28f, labelSz, Palette.TEXT_FAINT, Paint.Align.CENTER)
        kit.textFit(c, value, x + w / 2f, y + h * 0.7f, w - kit.dp(4f), valueSz, Palette.TEXT, Paint.Align.CENTER)
    }

    private fun pathCard(c: Canvas, run: GameRun, tower: Tower, p: Int, x: Float, y: Float, w: Float, h: Float, fit: Float) {
        fun u(v: Float): Float = kit.dp(v) * fit
        fun sz(v: Float): Float = v * fit
        val path = tower.type.paths[p]
        val role = tower.roleOf(p)
        val tier = tower.pathTiers[p]
        val cap = UpgradeRules.capFor(tower.pathTiers, p)
        val selected = run.selectedPath == p
        val locked = role == PathRole.LOCKED
        a.set(x, y, x + w, y + h)
        kit.hitArea(UiId.PATH_BASE + p, a)
        kit.panel(c, a, 8f, if (selected) 0xFF263447.toInt() else Palette.PANEL_SOLID,
            if (selected) path.colorArgb else Palette.EDGE, if (selected) 2.2f else 1.2f)
        kit.rect(c, x + u(1.5f), y + u(8f), x + u(5.5f), y + h - u(8f), if (locked) Palette.TEXT_FAINT else path.colorArgb)
        val nameColor = if (locked) Palette.TEXT_FAINT else path.colorArgb
        kit.textFit(c, path.name, x + u(11f), y + u(12f), w - u(70f), sz(12f), nameColor)
        val (label, labelColor) = when (role) {
            PathRole.MAIN -> "MAIN" to Palette.GOLD
            PathRole.CROSS -> "CROSS" to Palette.CYAN
            PathRole.LOCKED -> "LOCKED" to Palette.RED
            PathRole.ACTIVE -> "ACTIVE" to Palette.TEXT
            PathRole.OPEN -> "OPEN" to Palette.TEXT_DIM
        }
        kit.textMid(c, label, x + w - u(7f), y + u(12f), sz(9.5f), labelColor, Paint.Align.RIGHT)
        // tier pips: filled = owned, outlined = still reachable, dark = beyond the cap
        val pip = u(13f)
        for (i in 0 until 5) {
            val px = x + u(11f) + i * (pip + u(3f))
            a.set(px, y + u(21f), px + pip, y + u(21f) + u(8f))
            val owned = i < tier
            val reachable = i < cap
            val col = if (owned) path.colorArgb else if (reachable && !locked) Palette.EDGE_BRIGHT else 0xFF1B222C.toInt()
            kit.panel(c, a, 2f, if (owned) col else 0xFF111820.toInt(), col, 1.2f)
        }
        a.set(x, y, x + w, y + h)
        val next = tower.nextUpgrade(p)
        val availability = tower.upgradeAvailability(p)
        val textY = y + u(41f)
        when {
            next == null -> kit.textMid(c, "MAXED  ${tier}/5", x + u(11f), textY, sz(10.5f), path.colorArgb, Paint.Align.LEFT)
            availability == UpgradeAvailability.LOCKED -> {
                kit.icon(c, UiKit.ICON_LOCK, x + u(17f), textY, u(5.5f), Palette.TEXT_FAINT)
                kit.textMid(c, if (tier == 0) "Third path locked" else "Cross-path cap ($cap)", x + u(27f), textY, sz(10f), Palette.TEXT_FAINT, Paint.Align.LEFT, false)
            }
            else -> {
                val afford = run.economy.money >= next.cost
                kit.textFit(c, next.name, x + u(11f), textY, w - u(50f), sz(10.5f), Palette.TEXT)
                kit.textMid(c, "$${next.cost}", x + w - u(6f), textY, sz(11f), if (afford) Palette.GOLD else Palette.RED, Paint.Align.RIGHT)
            }
        }
    }

    private fun detail(c: Canvas, run: GameRun, tower: Tower, box: RectF, fit: Float) {
        fun u(v: Float): Float = kit.dp(v) * fit
        fun sz(v: Float): Float = v * fit
        kit.panel(c, box, 8f, Palette.PANEL_SOLID, Palette.EDGE, 1.2f)
        val p = run.selectedPath.coerceIn(0, 2)
        val path = tower.type.paths[p]
        val next = tower.nextUpgrade(p)
        val x = box.left + u(8f)
        val w = box.width() - u(16f)
        var y = box.top + u(6f)
        if (next == null) {
            kit.textMid(c, "${path.name}: MAXED", x, y + u(8f), sz(13f), path.colorArgb)
            val top = path.upgrades[4]
            y = kit.wrapped(c, descCache, top.description, x, y + u(20f), w, sz(10.5f), Palette.TEXT_DIM, 5)
            return
        }
        kit.textFit(c, next.name, x, y + u(8f), w, sz(13f), path.colorArgb)
        kit.textMid(c, "Tier ${tower.pathTiers[p] + 1} of 5", x, y + u(22f), sz(9f), Palette.TEXT_FAINT, Paint.Align.LEFT, false)
        y = kit.wrapped(c, descCache, next.description, x, y + u(29f), w, sz(10f), Palette.TEXT_DIM, 3)
        refreshDiffs(tower, p)
        val lh = u(13.5f)
        var dyy = y + u(2f)
        for (i in 0 until diffCount) {
            kit.textMid(c, diffLabels[i], x, dyy + lh * 0.5f, sz(8.5f), Palette.TEXT_FAINT, Paint.Align.LEFT)
            kit.textMid(c, diffValues[i], box.right - u(8f), dyy + lh * 0.5f, sz(10.5f), Palette.GREEN, Paint.Align.RIGHT)
            dyy += lh
        }
        val fusion = tower.fusionAfterUpgrade(p)
        if (fusion != null) kit.textFit(c, "FUSION: ${fusion.name}", x, dyy + lh * 0.5f, w, sz(10f), Palette.GOLD)
        val availability = tower.upgradeAvailability(p)
        a.set(x, box.bottom - u(38f), box.right - u(8f), box.bottom - u(6f))
        when (availability) {
            UpgradeAvailability.LOCKED -> kit.button(c, a, UiId.BUY, "LOCKED", UiKit.DISABLED, false, sz(12f))
            else -> {
                val afford = run.economy.money >= next.cost
                if (afford) kit.button(c, a, UiId.BUY, "UPGRADE  $${next.cost}", UiKit.GOLD, true, sz(12.5f))
                else kit.button(c, a, UiId.BUY, "NEED $${next.cost - run.economy.money} MORE", UiKit.DISABLED, true, sz(11.5f))
            }
        }
    }

    private fun refreshDiffs(tower: Tower, path: Int) {
        val key = System.identityHashCode(tower).toLong() * 131L + tower.effectiveVersion * 7L + path
        if (key == diffKey) return
        diffKey = key
        diffCount = 0
        val old = tower.effective
        val new = tower.previewAfterUpgrade(path) ?: return
        fun add(label: String, o: Float, n: Float, suffix: String = "", scale: Float = 1f) {
            if (diffCount >= DIFF_MAX || Math.abs(o - n) < 0.0005f) return
            diffLabels[diffCount] = label
            diffValues[diffCount] = "${fmt(o * scale)}$suffix → ${fmt(n * scale)}$suffix"
            diffCount++
        }
        add("DAMAGE", old.damage, new.damage)
        add("ATTACK SPEED", old.fireRateSeconds, new.fireRateSeconds, "s")
        add("RANGE", old.range, new.range)
        add("SHOTS", old.projectilesPerShot.toFloat(), new.projectilesPerShot.toFloat())
        add("PIERCE", old.pierce.toFloat(), new.pierce.toFloat())
        add("BLAST RADIUS", old.splashRadius, new.splashRadius)
        add("CHAIN LINKS", old.chainCount.toFloat(), new.chainCount.toFloat())
        add("BURN / SEC", old.burnDps, new.burnDps)
        add("FIRE SPREAD", old.burnSpreadRadius, new.burnSpreadRadius)
        add("DEATH BLAST", old.deathBlastDamage, new.deathBlastDamage)
        add("CRIT CHANCE", old.critChance, new.critChance, "%", 100f)
        add("ARMOR PEN", old.armorPenetration, new.armorPenetration)
        add("ARMOR SHRED", old.armorShred, new.armorShred, "%", 100f)
        add("FREEZE", old.freezeChance, new.freezeChance, "%", 100f)
        add("SLOW", 1f - old.slowMultiplier, 1f - new.slowMultiplier, "%", 100f)
        add("EXECUTE", old.executeThreshold, new.executeThreshold, "%", 100f)
        add("PULSE DMG", old.pulseDamage, new.pulseDamage)
        add("AURA RADIUS", old.auraRadius, new.auraRadius)
        add("AURA DAMAGE", old.auraDamage, new.auraDamage, "%", 100f)
        add("SPECIAL EVERY", old.specialEvery.toFloat(), new.specialEvery.toFloat(), " shots")
        add("HEAT RAMP", old.rampMax, new.rampMax, "%", 100f)
        add("GROUND ZONE", old.zoneDps, new.zoneDps)
        add("MARK DAMAGE", old.vulnerabilityBonus, new.vulnerabilityBonus, "%", 100f)
        add("SILENCE", old.silenceSeconds, new.silenceSeconds, "s")
    }

    private fun fmt(v: Float): String =
        if (Math.abs(v - Math.round(v)) < 0.01f) Math.round(v).toString() else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    private fun damageText(s: TowerStats): String {
        val base = fmt(s.damage)
        return if (s.projectilesPerShot > 1) "$base x${s.projectilesPerShot}" else base
    }

    private fun rateText(s: TowerStats): String = String.format(Locale.US, "%.1f/s", s.shotsPerSecond)

    private fun targetName(mode: TargetingMode): String = when (mode) {
        TargetingMode.FIRST -> "First"
        TargetingMode.STRONGEST -> "Strong"
        TargetingMode.CLOSEST -> "Close"
    }

    private fun infoLine(tower: Tower): String? {
        val fusion = tower.fusion
        if (fusion != null) return "FUSION: ${fusion.name}"
        if (tower.synergies.isNotEmpty()) return "Linked: ${tower.synergies.joinToString(", ")}"
        if (tower.heightBonus > 0f) return "High ground: +${(tower.heightBonus * 100f).toInt()}% range"
        return null
    }

    private companion object {
        const val DIFF_MAX = 4
    }
}
