package com.ironpath.defense.entity.zone

/**
 * A circular area that applies effects to enemies and/or towers for a while.
 * Used by tower upgrades (burning ground, toxic clouds, frost patches), map
 * hazards (lava, spores, surges) and boss abilities (EMP). While [telegraph] > 0
 * the zone is only a warning ring and has no effect.
 */
class Zone {
    lateinit var kind: ZoneKind
    var x = 0f
    var y = 0f
    var radius = 0f
    var life = 0f
    var lifeTotal = 0f
    var telegraph = 0f
    var telegraphTotal = 0f
    var tick = 0f
    var alive = false
    var sourceType = -1

    var enemyDps = 0f
    var enemyPctDps = 0f
    var enemySlow = 1f
    var enemyHealPct = 0f
    var enemyStun = 0f
    var silence = 0f
    var jamTowers = false
    var towerRate = 0f

    fun configure(kind: ZoneKind, x: Float, y: Float, radius: Float, seconds: Float, telegraph: Float) {
        this.kind = kind
        this.x = x
        this.y = y
        this.radius = radius
        this.life = seconds
        this.lifeTotal = seconds
        this.telegraph = telegraph
        this.telegraphTotal = telegraph
        this.tick = 0f
        this.alive = true
        this.sourceType = -1
        enemyDps = 0f
        enemyPctDps = 0f
        enemySlow = 1f
        enemyHealPct = 0f
        enemyStun = 0f
        silence = 0f
        jamTowers = false
        towerRate = 0f
    }

    val isActive: Boolean get() = alive && telegraph <= 0f
}
