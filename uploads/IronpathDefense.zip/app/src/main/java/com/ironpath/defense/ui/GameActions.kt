package com.ironpath.defense.ui

import com.ironpath.defense.entity.tower.TowerType

/**
 * Everything the player can ask the game to do. Input handling maps taps to
 * these calls; GameWorld implements them. Keeping this as an interface means
 * the UI layer never needs to know how the game reacts.
 */
interface GameActions {
    // --- navigation -----------------------------------------------------
    fun playSelected()
    fun openMaps()
    fun openCodex()
    fun openSettings()
    fun closeSettings()
    fun goBack()
    fun selectMap(index: Int)
    fun selectDifficulty(index: Int)
    fun startSelectedMap()
    fun restartRun()
    fun exitToMaps()
    fun exitToMenu()
    fun togglePause()
    // --- gameplay ---------------------------------------------------------
    fun startWave()
    fun cycleSpeed()
    fun armTower(type: TowerType)
    fun worldTap(worldX: Float, worldY: Float)
    fun selectPath(path: Int)
    fun buySelected()
    fun sellSelected()
    fun cycleTargeting()
    fun deselect()
    fun useAbility(index: Int)
    // --- settings ---------------------------------------------------------
    fun changeVolume(which: Int, delta: Int)
    fun cycleQuality()
    fun toggleSetting(which: Int)
    // --- codex ------------------------------------------------------------
    fun codexTab(tab: Int)
    fun codexTower(index: Int)
    fun codexBuild(index: Int)
}
