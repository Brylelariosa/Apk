package com.ironpath.defense.ui

import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.core.InputEvent
import com.ironpath.defense.entity.tower.TowerType

/**
 * Turns a tap into an action. UI buttons win (resolved from the regions the
 * screens registered while drawing); anything else during play is a tap on
 * the battlefield, converted to world coordinates.
 */
class InputController(private val kit: UiKit, private val onButtonPressed: () -> Unit) {
    fun handleTap(event: InputEvent, layout: UiLayout, state: HudState, actions: GameActions) {
        val id = kit.registry.hit(event.screenX, event.screenY)
        if (id == UiId.BLOCK) return
        if (id != UiId.NONE) {
            kit.notifyPressed(id)
            onButtonPressed()
            dispatch(id, actions)
            return
        }
        if (state.screen == GameScreenState.PLAYING) {
            actions.worldTap(layout.screenToWorldX(event.screenX), layout.screenToWorldY(event.screenY))
        }
    }

    private fun dispatch(id: Int, a: GameActions) {
        when {
            id == UiId.MENU_PLAY -> a.playSelected()
            id == UiId.MENU_MAPS -> a.openMaps()
            id == UiId.MENU_TOWERS -> a.openCodex()
            id == UiId.MENU_SETTINGS -> a.openSettings()
            id == UiId.BACK -> a.goBack()
            id == UiId.PAUSE -> a.togglePause()
            id == UiId.PAUSE_RESUME -> a.togglePause()
            id == UiId.PAUSE_SETTINGS -> a.openSettings()
            id == UiId.PAUSE_RESTART -> a.restartRun()
            id == UiId.PAUSE_EXIT -> a.exitToMaps()
            id == UiId.SPEED -> a.cycleSpeed()
            id == UiId.START_WAVE -> a.startWave()
            id in UiId.ABILITY_BASE until UiId.ABILITY_BASE + 3 -> a.useAbility(id - UiId.ABILITY_BASE)
            id in UiId.SHOP_BASE until UiId.SHOP_BASE + 12 -> {
                val type = TowerType.entries.getOrNull(id - UiId.SHOP_BASE)
                if (type != null) a.armTower(type)
            }
            id in UiId.PATH_BASE until UiId.PATH_BASE + 3 -> a.selectPath(id - UiId.PATH_BASE)
            id == UiId.BUY -> a.buySelected()
            id == UiId.SELL -> a.sellSelected()
            id == UiId.TARGET -> a.cycleTargeting()
            id == UiId.CLOSE_PANEL -> a.deselect()
            id in UiId.SET_VOL_BASE until UiId.SET_VOL_BASE + 6 -> {
                val n = id - UiId.SET_VOL_BASE
                a.changeVolume(n % 3, if (n < 3) -1 else 1)
            }
            id == UiId.SET_QUALITY -> a.cycleQuality()
            id in UiId.SET_TOGGLE_BASE until UiId.SET_TOGGLE_BASE + 3 -> a.toggleSetting(id - UiId.SET_TOGGLE_BASE)
            id in UiId.MAP_BASE until UiId.MAP_BASE + 16 -> a.selectMap(id - UiId.MAP_BASE)
            id in UiId.DIFF_BASE until UiId.DIFF_BASE + 3 -> a.selectDifficulty(id - UiId.DIFF_BASE)
            id == UiId.MAP_PLAY -> a.startSelectedMap()
            id in UiId.CODEX_TOWER_BASE until UiId.CODEX_TOWER_BASE + 12 -> a.codexTower(id - UiId.CODEX_TOWER_BASE)
            id in UiId.CODEX_BUILD_BASE until UiId.CODEX_BUILD_BASE + 8 -> a.codexBuild(id - UiId.CODEX_BUILD_BASE)
            id in UiId.CODEX_TAB_BASE until UiId.CODEX_TAB_BASE + 2 -> a.codexTab(id - UiId.CODEX_TAB_BASE)
            id == UiId.END_PRIMARY -> a.exitToMaps()
            id == UiId.END_SECONDARY -> a.restartRun()
        }
    }
}
