package com.ironpath.defense.map

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * The static shape and identity of one map.
 *
 * Waypoints are authored in tile coordinates and may start/end *outside* the
 * grid (col -1 or col 20) so enemies visibly walk in from, and out of, the
 * screen edge. [blockers] are scenery obstacles that cannot be built on,
 * [highGround] tiles grant a range bonus, [slickSegments] are path segments
 * (indexed by their starting waypoint) that the map mechanic can speed up, and
 * [specialTiles] hold mechanic props (rune pedestals, grid pylons, presses).
 */
class GameMap(
    val id: Int,
    val displayName: String,
    val theme: MapTheme,
    val mechanic: MapMechanic,
    val stars: Int,
    val waveCount: Int,
    val blurb: String,
    val mechanicName: String,
    val mechanicText: String,
    val tileWaypoints: List<Pair<Int, Int>>,
    val blockers: List<Pair<Int, Int>> = emptyList(),
    val highGround: List<Pair<Int, Int>> = emptyList(),
    val slickSegments: Set<Int> = emptySet(),
    val specialTiles: List<Pair<Int, Int>> = emptyList()
) {
    fun worldWaypoints(): List<Vector2> = tileWaypoints.map { (col, row) ->
        Vector2(
            col * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f,
            row * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f
        )
    }

    /** Builds a fresh TileGrid: path tiles PATH, obstacles BLOCKED, high ground bonus, rest BUILDABLE. */
    fun buildTileGrid(): TileGrid {
        val grid = TileGrid(GameConfig.GRID_COLS, GameConfig.GRID_ROWS)
        for (i in 0 until tileWaypoints.size - 1) {
            markSegment(grid, tileWaypoints[i], tileWaypoints[i + 1])
        }
        val last = tileWaypoints.last()
        grid.setKind(last.first, last.second, TileKind.PATH)
        for ((c, r) in blockers) if (grid.kindAt(c, r) == TileKind.BUILDABLE) grid.setKind(c, r, TileKind.BLOCKED)
        if (mechanic == MapMechanic.RUNES || mechanic == MapMechanic.GRID_SURGE) {
            for ((c, r) in specialTiles) grid.setKind(c, r, TileKind.BLOCKED)
        }
        for ((c, r) in highGround) if (grid.kindAt(c, r) == TileKind.BUILDABLE) grid.setBonus(c, r, HIGH_GROUND_BONUS)
        return grid
    }

    private fun markSegment(grid: TileGrid, from: Pair<Int, Int>, to: Pair<Int, Int>) {
        var col = from.first
        var row = from.second
        grid.setKind(col, row, TileKind.PATH)
        val stepCol = (to.first - from.first).coerceIn(-1, 1)
        val stepRow = (to.second - from.second).coerceIn(-1, 1)
        while (col != to.first || row != to.second) {
            if (col != to.first) col += stepCol
            if (row != to.second) row += stepRow
            grid.setKind(col, row, TileKind.PATH)
        }
    }

    /** World-space center of a tile. */
    fun tileCenter(col: Int, row: Int): Vector2 = Vector2(
        col * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f,
        row * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f
    )

    companion object {
        const val HIGH_GROUND_BONUS = 0.18f
    }
}
