package com.ironpath.defense.entity.zone

private fun argb(v: Long): Int = v.toInt()

/** Kinds of lingering area effects. The first three can be created by tower upgrades (by [id]). */
enum class ZoneKind(val id: Int, val colorArgb: Int) {
    FIRE(1, argb(0xFFFF8A2B)),
    TOXIC(2, argb(0xFF8CFF4A)),
    FROST(3, argb(0xFF9FE8FF)),
    STEAM(4, argb(0xFFE8F4FF)),
    LAVA(5, argb(0xFFFF5A1E)),
    SPORE(6, argb(0xFFC77DFF)),
    SURGE(7, argb(0xFF58D6FF)),
    JAM(8, argb(0xFFFFD84A)),
    RUNE(9, argb(0xFF7CF2D0)),
    BOUNTY(10, argb(0xFFFFD34D));

    companion object {
        fun fromId(id: Int): ZoneKind? = entries.firstOrNull { it.id == id }
    }
}
