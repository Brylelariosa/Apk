package com.ironpath.defense.map

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * Facade the rest of the game talks to for "what does the map look like /
 * can I build here" questions. Owns the map's derived [TileGrid] and the
 * world<->tile coordinate conversions, so no other system needs tile math.
 */
class MapSystem(val map: GameMap) {
    val tileGrid: TileGrid = map.buildTileGrid()
    val pathSystem = PathSystem(map.worldWaypoints())

    fun worldToTile(world: Vector2): Pair<Int, Int> =
        Math.floor((world.x / GameConfig.TILE_SIZE).toDouble()).toInt() to
            Math.floor((world.y / GameConfig.TILE_SIZE).toDouble()).toInt()

    fun tileToWorldCenter(col: Int, row: Int): Vector2 = map.tileCenter(col, row)

    fun canPlaceTowerAt(world: Vector2): Boolean {
        val (col, row) = worldToTile(world)
        return tileGrid.canPlaceTower(col, row)
    }

    fun markBuilt(world: Vector2, built: Boolean) {
        val (col, row) = worldToTile(world)
        tileGrid.setOccupied(col, row, built)
    }

    /** High-ground range bonus (fraction) at a world position. */
    fun rangeBonusAt(world: Vector2): Float {
        val (col, row) = worldToTile(world)
        return tileGrid.bonusAt(col, row)
    }

    /** Clears all tower occupancy for a fresh session (the layout itself never changes). */
    fun resetOccupancy() = tileGrid.resetOccupancy()
}
