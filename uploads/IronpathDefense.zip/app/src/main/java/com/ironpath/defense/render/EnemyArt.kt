package com.ironpath.defense.render

import android.graphics.Canvas
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.glow
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.oval
import com.ironpath.defense.render.ArtKit.polygon
import com.ironpath.defense.render.ArtKit.quad
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.rr
import com.ironpath.defense.render.ArtKit.shade
import com.ironpath.defense.render.ArtKit.tri
import com.ironpath.defense.render.ArtKit.withAlpha
import kotlin.math.cos
import kotlin.math.sin

/**
 * Every enemy kind has its own silhouette and animation (walk cycles, wings,
 * shields, cloaks) rather than being a recolored circle. Bodies are drawn
 * facing +x and rotated to the path heading; status overlays (burning, frozen,
 * marked, shielded...) are drawn upright on top.
 */
object EnemyArt {
    private val WHITE = 0xFFFFFFFF.toInt()

    fun draw(c: Canvas, e: Enemy, sx: Float, sy: Float, scale: Float, time: Float) {
        val r = e.radius
        val kind = e.kind
        val cloakAlpha = if (!e.cloaked) 255 else if (e.isRevealed) 140 else 46
        c.save()
        c.translate(sx, sy)
        c.scale(scale, scale)
        oval(c, -r, r * 0.45f, r, r * 1.25f, 0x33000000)
        var ent = 1f
        if (e.entranceTimer > 0f) ent = (1f - e.entranceTimer / 1.8f).coerceIn(0f, 1f)
        if (ent < 1f) {
            c.scale(0.4f + 0.6f * ent, 0.4f + 0.6f * ent)
            glow(c, 0f, 0f, r * 3.2f * (1f - ent * 0.5f), kind.colorArgb, 0.6f * (1f - ent))
        }
        if (cloakAlpha < 255) c.saveLayerAlpha(-r * 3f, -r * 3f, r * 3f, r * 3f, cloakAlpha)
        c.save()
        c.rotate(e.heading * 57.29578f)
        body(c, kind, r, sin(e.walkPhase), time + e.uid * 0.37f, e)
        if (e.hitFlash > 0f) circ(c, 0f, 0f, r * 0.95f, withAlpha(WHITE, (e.hitFlash / 0.1f).coerceIn(0f, 1f) * 0.55f))
        c.restore()
        if (cloakAlpha < 255) c.restore()
        overlays(c, e, r, time)
        c.restore()
    }

    /** Static portrait for UI (wave preview, codex). [r] is in pixels. */
    fun drawIcon(c: Canvas, kind: EnemyKind, cx: Float, cy: Float, size: Float, time: Float) {
        val r = kind.radius
        c.save()
        c.translate(cx, cy)
        val s = size / (r * 2.3f)
        c.scale(s, s)
        c.rotate(-20f)
        body(c, kind, r, sin(time * 3f), time, null)
        c.restore()
    }

    fun drawHealthBar(c: Canvas, e: Enemy, sx: Float, sy: Float, scale: Float) {
        val damaged = e.currentHealth < e.maxHealth - 0.5f
        if (!damaged && e.shield <= 0f && !e.kind.isElite) return
        val bw = (e.radius * 1.8f).coerceAtLeast(24f) * scale
        val bh = (if (e.kind.isElite) 5.5f else 3.6f) * scale.coerceAtLeast(0.7f)
        val top = sy - (e.radius * 1.15f) * scale - bh * 2.4f
        val frac = (e.currentHealth / e.maxHealth).coerceIn(0f, 1f)
        rr(c, sx - bw / 2f - 1f, top - 1f, sx + bw / 2f + 1f, top + bh + 1f, bh * 0.5f, 0xCC10141A.toInt())
        val col = if (frac > 0.5f) 0xFF58D67A.toInt() else if (frac > 0.25f) 0xFFFFC94A.toInt() else 0xFFFF5A5A.toInt()
        rr(c, sx - bw / 2f, top, sx - bw / 2f + bw * frac, top + bh, bh * 0.5f, col)
        if (e.maxShield > 0f && e.shield > 0f) {
            val sf = (e.shield / e.maxShield).coerceIn(0f, 1f)
            rr(c, sx - bw / 2f, top - bh - 1.5f, sx - bw / 2f + bw * sf, top - 1.5f, bh * 0.5f, 0xFF8FD8FF.toInt())
        }
    }

    private fun overlays(c: Canvas, e: Enemy, r: Float, time: Float) {
        if (e.shield > 0f && e.maxShield > 0f) {
            val f = (e.shield / e.maxShield).coerceIn(0.2f, 1f)
            val flick = 0.7f + 0.3f * sin(time * 9f + e.uid)
            ring(c, 0f, 0f, r * 1.35f, 2.2f, withAlpha(0xFF8FD8FF.toInt(), 0.75f * f * flick))
            glow(c, 0f, 0f, r * 1.8f, 0xFF8FD8FF.toInt(), 0.16f * f)
        }
        if (e.isBurning) {
            val col = e.burnColorArgb
            for (i in 0 until 3) {
                val ph = time * 7f + i * 2.1f + e.uid
                val fx = cos(ph * 0.8f) * r * 0.45f
                val fy = -r * 0.2f - ((ph * 3f) % 1f) * r * 0.5f
                glow(c, fx, fy, r * 0.55f, col, 0.55f)
                tri(c, fx - r * 0.16f, fy + r * 0.2f, fx + r * 0.16f, fy + r * 0.2f, fx, fy - r * 0.32f, col)
            }
        }
        if (e.isStunned) {
            ring(c, 0f, 0f, r * 1.1f, 2f, 0xCCBFF3FF.toInt())
            for (i in 0 until 3) {
                val a = time * 3f + i * 2.094f
                polygon(c, cos(a) * r * 0.9f, sin(a) * r * 0.5f - r * 0.5f, r * 0.16f, 4, 0f, 0xFFE6FBFF.toInt())
            }
        } else if (e.isSlowed) {
            oval(c, -r, r * 0.35f, r, r * 1.2f, 0x558FD6FF)
            ring(c, 0f, r * 0.8f, r * 0.75f, 1.6f, 0x888FD6FF.toInt())
        }
        if (e.isMarked) {
            val pr = r * 1.15f + sin(time * 6f) * r * 0.06f
            ring(c, 0f, 0f, pr, 1.8f, 0xCCFF5A5A.toInt())
            ln(c, -pr * 1.2f, 0f, -pr * 0.7f, 0f, 1.8f, 0xCCFF5A5A.toInt()); ln(c, pr * 0.7f, 0f, pr * 1.2f, 0f, 1.8f, 0xCCFF5A5A.toInt())
            ln(c, 0f, -pr * 1.2f, 0f, -pr * 0.7f, 1.8f, 0xCCFF5A5A.toInt()); ln(c, 0f, pr * 0.7f, 0f, pr * 1.2f, 1.8f, 0xCCFF5A5A.toInt())
        }
        if (e.isSilenced) {
            val y = -r * 1.5f
            circ(c, 0f, y, r * 0.3f, 0xCC6B3FD0.toInt())
            ln(c, -r * 0.14f, y - r * 0.14f, r * 0.14f, y + r * 0.14f, 1.6f, WHITE); ln(c, -r * 0.14f, y + r * 0.14f, r * 0.14f, y - r * 0.14f, 1.6f, WHITE)
        }
        if (e.hasteTime > 0f) for (i in 0 until 3) ln(c, -r * (1.3f + i * 0.35f), (i - 1) * r * 0.5f, -r * (2f + i * 0.35f), (i - 1) * r * 0.5f, 1.8f, 0x99FFFFFF.toInt())
        if (e.kind == EnemyKind.BOSS_COLOSSUS && e.abilityTimer in 0f..1.3f) {
            val f = 1f - e.abilityTimer / 1.3f
            ring(c, 0f, 0f, r * (1.2f + f * 1.6f), 2.6f, withAlpha(0xFFFFD84A.toInt(), f))
        }
    }

    private fun legs(c: Canvas, r: Float, w: Float, col: Int, pairs: Int, spread: Float) {
        for (i in 0 until pairs) {
            val x = r * (0.5f - i * (1f / pairs) * 1.1f)
            val sw = w * r * 0.25f * (if (i % 2 == 0) 1f else -1f)
            ln(c, x, -r * 0.7f, x + sw, -r * (0.7f + spread), 2.2f, col)
            ln(c, x, r * 0.7f, x - sw, r * (0.7f + spread), 2.2f, col)
        }
    }

    private fun eyes(c: Canvas, x: Float, r: Float, col: Int) {
        circ(c, x, -r * 0.22f, r * 0.14f, WHITE); circ(c, x, r * 0.22f, r * 0.14f, WHITE)
        circ(c, x + r * 0.04f, -r * 0.22f, r * 0.07f, col); circ(c, x + r * 0.04f, r * 0.22f, r * 0.07f, col)
    }

    private fun body(c: Canvas, kind: EnemyKind, r: Float, w: Float, time: Float, e: Enemy?) {
        val base = kind.colorArgb
        val dark = shade(base, 0.62f)
        val light = shade(base, 1.3f)
        when (kind) {
            EnemyKind.BASIC -> {
                legs(c, r, w, dark, 2, 0.45f)
                oval(c, -r, -r * 0.85f, r * 0.8f, r * 0.85f, base)
                oval(c, -r * 0.7f, -r * 0.6f, r * 0.4f, r * 0.1f, light)
                circ(c, r * 0.62f, 0f, r * 0.5f, light)
                eyes(c, r * 0.8f, r, 0xFF2A1A12.toInt())
            }
            EnemyKind.FAST -> {
                for (i in 1..3) ln(c, -r * (1.1f + i * 0.5f), (i - 2) * r * 0.35f, -r * (1.7f + i * 0.5f), (i - 2) * r * 0.35f, 1.4f, withAlpha(base, 0.5f))
                tri(c, -r * 1.1f, -r * 0.7f, -r * 1.1f, r * 0.7f, r * 1.25f, 0f, base)
                tri(c, -r * 0.7f, -r * 0.35f, -r * 0.7f, r * 0.35f, r * 0.75f, 0f, light)
                circ(c, r * 0.35f, 0f, r * 0.3f, dark)
                circ(c, r * 0.45f, -r * 0.1f, r * 0.1f, WHITE)
            }
            EnemyKind.ARMORED -> {
                legs(c, r, w, dark, 2, 0.4f)
                polygon(c, 0f, 0f, r * 1.05f, 6, 0f, 0xFF4A515B.toInt())
                polygon(c, 0f, 0f, r * 0.88f, 6, 0f, base)
                polygon(c, -r * 0.1f, -r * 0.08f, r * 0.55f, 6, 0f, light)
                for (i in 0 until 6) { val a = i * 1.0472f; circ(c, cos(a) * r * 0.78f, sin(a) * r * 0.78f, r * 0.08f, 0xFF3A4048.toInt()) }
                rr(c, r * 0.65f, -r * 0.3f, r * 1.15f, r * 0.3f, r * 0.12f, dark)
                circ(c, r * 0.95f, 0f, r * 0.1f, 0xFFFFC94A.toInt())
            }
            EnemyKind.SWARM, EnemyKind.SPAWNLING -> {
                legs(c, r, w * 1.6f, dark, 3, 0.55f)
                oval(c, -r * 0.9f, -r * 0.6f, r * 0.7f, r * 0.6f, base)
                circ(c, r * 0.6f, 0f, r * 0.42f, light)
                ln(c, r * 0.8f, -r * 0.2f, r * 1.3f, -r * 0.55f + w * r * 0.1f, 1.2f, dark); ln(c, r * 0.8f, r * 0.2f, r * 1.3f, r * 0.55f - w * r * 0.1f, 1.2f, dark)
                circ(c, r * 0.7f, 0f, r * 0.12f, 0xFFFFE066.toInt())
            }
            EnemyKind.REGENERATOR -> {
                val pulse = 1f + 0.06f * sin(time * 4f)
                glow(c, 0f, 0f, r * 1.6f, 0xFF7BFFB0.toInt(), 0.18f)
                legs(c, r, w, dark, 2, 0.4f)
                circ(c, 0f, 0f, r * 0.95f * pulse, base)
                circ(c, -r * 0.2f, -r * 0.2f, r * 0.55f, light)
                tri(c, -r * 0.1f, -r * 0.55f, r * 0.55f, 0f, -r * 0.1f, r * 0.55f, 0x88FFFFFF.toInt())
                circ(c, r * 0.55f, 0f, r * 0.34f, dark); circ(c, r * 0.65f, 0f, r * 0.1f, 0xFFB8FFD0.toInt())
            }
            EnemyKind.TANK -> {
                val off = w * r * 0.12f
                rr(c, -r * 1.05f, -r * 1.0f, r * 1.05f, -r * 0.55f, r * 0.15f, 0xFF3A3028.toInt())
                rr(c, -r * 1.05f, r * 0.55f, r * 1.05f, r * 1.0f, r * 0.15f, 0xFF3A3028.toInt())
                for (i in -3..3) { val x = i * r * 0.32f + off; ln(c, x, -r * 0.95f, x, -r * 0.6f, 1.6f, 0xFF6A5A48.toInt()); ln(c, x, r * 0.6f, x, r * 0.95f, 1.6f, 0xFF6A5A48.toInt()) }
                rr(c, -r * 0.9f, -r * 0.65f, r * 0.9f, r * 0.65f, r * 0.2f, base)
                rr(c, -r * 0.7f, -r * 0.45f, r * 0.4f, r * 0.2f, r * 0.12f, light)
                circ(c, r * 0.1f, 0f, r * 0.42f, dark); circ(c, r * 0.1f, 0f, r * 0.26f, base)
                rr(c, r * 0.1f, -r * 0.1f, r * 1.2f, r * 0.1f, r * 0.05f, 0xFF2A2420.toInt())
            }
            EnemyKind.SHIELDED -> {
                legs(c, r, w, dark, 2, 0.4f)
                oval(c, -r * 0.9f, -r * 0.8f, r * 0.8f, r * 0.8f, base)
                circ(c, r * 0.55f, 0f, r * 0.46f, light)
                rr(c, r * 0.35f, -r * 0.9f, r * 0.55f, r * 0.9f, r * 0.1f, 0xFF8FD8FF.toInt())
                circ(c, r * 0.72f, 0f, r * 0.14f, WHITE)
            }
            EnemyKind.SPLITTER -> {
                val wob = 1f + 0.08f * sin(time * 5f)
                legs(c, r, w, dark, 2, 0.3f)
                circ(c, -r * 0.4f, 0f, r * 0.72f * wob, base)
                circ(c, r * 0.42f, 0f, r * 0.62f / wob, light)
                ln(c, r * 0.05f, -r * 0.55f, r * 0.05f, r * 0.55f, 1.6f, dark)
                eyes(c, r * 0.65f, r * 0.9f, 0xFF5A1A30.toInt())
            }
            EnemyKind.HEALER -> {
                glow(c, 0f, 0f, r * 2.2f + sin(time * 3f) * r * 0.15f, 0xFF7AE0A0.toInt(), 0.14f)
                legs(c, r, w, dark, 2, 0.4f)
                oval(c, -r * 0.95f, -r * 0.8f, r * 0.8f, r * 0.8f, base)
                circ(c, r * 0.55f, 0f, r * 0.42f, light)
                rr(c, -r * 0.55f, -r * 0.14f, r * 0.15f, r * 0.14f, 0f, WHITE); rr(c, -r * 0.2f, -r * 0.5f, -r * 0.2f + r * 0.28f, r * 0.5f, 0f, WHITE)
            }
            EnemyKind.PHANTOM -> {
                ArtKit.path.reset()
                ArtKit.path.moveTo(r * 0.9f, 0f)
                ArtKit.path.quadTo(r * 0.2f, -r * 1.05f, -r * 0.7f, -r * 0.8f)
                for (i in 0 until 4) ArtKit.path.lineTo(-r * 1.15f, -r * 0.6f + i * r * 0.4f + sin(time * 6f + i) * r * 0.12f)
                ArtKit.path.quadTo(r * 0.2f, r * 1.05f, r * 0.9f, 0f)
                ArtKit.fillPath(c, base)
                circ(c, r * 0.35f, -r * 0.22f, r * 0.17f, 0xFFFFFFFF.toInt()); circ(c, r * 0.35f, r * 0.22f, r * 0.17f, 0xFFFFFFFF.toInt())
                circ(c, r * 0.4f, -r * 0.22f, r * 0.08f, 0xFF2A1A5A.toInt()); circ(c, r * 0.4f, r * 0.22f, r * 0.08f, 0xFF2A1A5A.toInt())
            }
            EnemyKind.MINI_BRUISER -> {
                legs(c, r, w, dark, 2, 0.35f)
                oval(c, -r * 1.0f, -r * 0.95f, r * 0.7f, r * 0.95f, base)
                circ(c, r * 0.1f, -r * 0.82f, r * 0.42f, light); circ(c, r * 0.1f, r * 0.82f, r * 0.42f, light)
                circ(c, r * 0.72f, 0f, r * 0.46f, dark)
                tri(c, r * 0.7f, -r * 0.4f, r * 0.9f, -r * 0.4f, r * 1.1f, -r * 0.95f, 0xFFE8E0D0.toInt()); tri(c, r * 0.7f, r * 0.4f, r * 0.9f, r * 0.4f, r * 1.1f, r * 0.95f, 0xFFE8E0D0.toInt())
                eyes(c, r * 0.85f, r * 0.8f, 0xFFFF3A2A.toInt())
                if (e != null && e.hasteTime > 0f) glow(c, 0f, 0f, r * 1.8f, 0xFFFF7A3C.toInt(), 0.35f)
            }
            EnemyKind.MINI_COMMANDER -> {
                for (i in 0 until 3) { val a = time * 1.6f + i * 2.094f; circ(c, cos(a) * r * 1.3f, sin(a) * r * 1.3f, r * 0.17f, 0xFF8FD8FF.toInt()) }
                ring(c, 0f, 0f, r * 1.3f, 1.2f, 0x558FD8FF.toInt())
                tri(c, -r * 0.2f, -r * 0.9f, -r * 1.4f, 0f, -r * 0.2f, r * 0.9f, dark)
                oval(c, -r * 0.8f, -r * 0.75f, r * 0.7f, r * 0.75f, base)
                circ(c, r * 0.55f, 0f, r * 0.44f, light)
                rr(c, -r * 0.45f, -r * 0.12f, r * 0.2f, r * 0.12f, 0f, WHITE); rr(c, -r * 0.2f, -r * 0.4f, r * 0.04f, r * 0.4f, 0f, WHITE)
                eyes(c, r * 0.72f, r * 0.9f, 0xFF0F4A44.toInt())
            }
            EnemyKind.MINI_STALKER -> {
                for (i in 1..3) quad(c, -r * (0.8f + i * 0.45f), 0f, -r * (0.2f + i * 0.45f), -r * 0.5f, r * 0.1f - r * i * 0.45f, 0f, -r * (0.2f + i * 0.45f), r * 0.5f, withAlpha(base, 0.22f))
                quad(c, -r * 0.9f, 0f, -r * 0.1f, -r * 0.85f, r * 1.2f, 0f, -r * 0.1f, r * 0.85f, base)
                quad(c, -r * 0.5f, 0f, 0f, -r * 0.4f, r * 0.8f, 0f, 0f, r * 0.4f, light)
                circ(c, r * 0.35f, 0f, r * 0.2f, 0xFFFF4AB8.toInt()); glow(c, r * 0.35f, 0f, r * 0.6f, 0xFFFF4AB8.toInt(), 0.6f)
            }
            EnemyKind.BOSS -> {
                legs(c, r, w * 0.6f, dark, 2, 0.3f)
                polygon(c, 0f, 0f, r * 1.05f, 8, 22.5f, dark)
                polygon(c, 0f, 0f, r * 0.9f, 8, 22.5f, base)
                polygon(c, -r * 0.1f, -r * 0.1f, r * 0.58f, 8, 22.5f, light)
                circ(c, r * 0.1f, -r * 0.92f, r * 0.42f, 0xFF8A8F98.toInt()); circ(c, r * 0.1f, r * 0.92f, r * 0.42f, 0xFF8A8F98.toInt())
                circ(c, r * 0.1f, -r * 0.92f, r * 0.2f, 0xFFB8C2CE.toInt()); circ(c, r * 0.1f, r * 0.92f, r * 0.2f, 0xFFB8C2CE.toInt())
                circ(c, r * 0.7f, 0f, r * 0.42f, 0xFF4A4F58.toInt())
                tri(c, r * 0.6f, -r * 0.3f, r * 0.7f, -r * 0.3f, r * 0.9f, -r * 0.95f, 0xFFE8E0D0.toInt()); tri(c, r * 0.6f, r * 0.3f, r * 0.7f, r * 0.3f, r * 0.9f, r * 0.95f, 0xFFE8E0D0.toInt())
                rr(c, r * 0.72f, -r * 0.1f, r * 1.0f, r * 0.1f, 0f, 0xFFFF5A3A.toInt()); glow(c, r * 0.9f, 0f, r * 0.5f, 0xFFFF5A3A.toInt(), 0.6f)
            }
            EnemyKind.BOSS_QUEEN -> {
                val flap = sin(time * 14f) * 0.35f
                for (s in 0 until 2) {
                    val sg = if (s == 0) -1f else 1f
                    c.save(); c.rotate(sg * (28f + flap * 30f), 0f, 0f)
                    oval(c, -r * 0.2f, sg * r * 0.2f - (if (sg < 0f) r * 1.5f else 0f), r * 0.9f, sg * r * 0.2f + (if (sg > 0f) r * 1.5f else 0f), 0x66E6FF9A)
                    c.restore()
                }
                val pul = 1f + 0.05f * sin(time * 3f)
                oval(c, -r * 1.35f, -r * 0.8f * pul, -r * 0.1f, r * 0.8f * pul, dark)
                oval(c, -r * 1.2f, -r * 0.6f, -r * 0.3f, r * 0.2f, light)
                circ(c, r * 0.1f, 0f, r * 0.6f, base)
                circ(c, r * 0.78f, 0f, r * 0.42f, light)
                for (i in 0 until 3) { val x = -r * 0.1f + i * r * 0.28f; ln(c, x, -r * 0.55f, x + sin(w + i) * r * 0.18f, -r * 1.1f, 2.4f, dark); ln(c, x, r * 0.55f, x - sin(w + i) * r * 0.18f, r * 1.1f, 2.4f, dark) }
                tri(c, r * 0.7f, -r * 0.3f, r * 0.82f, -r * 0.3f, r * 0.76f, -r * 0.62f, 0xFFFFD34D.toInt()); tri(c, r * 0.7f, r * 0.3f, r * 0.82f, r * 0.3f, r * 0.76f, r * 0.62f, 0xFFFFD34D.toInt()); tri(c, r * 0.74f, -r * 0.1f, r * 0.84f, -r * 0.1f, r * 0.79f, -r * 0.42f, 0xFFFFD34D.toInt())
                eyes(c, r * 0.95f, r * 0.8f, 0xFFB01A1A.toInt())
                if (e != null && e.phase == 1) glow(c, 0f, 0f, r * 2.2f, 0xFFFF3A2A.toInt(), 0.35f + 0.15f * sin(time * 8f))
            }
            EnemyKind.BOSS_COLOSSUS -> {
                val core = 0.6f + 0.4f * sin(time * 4f)
                rr(c, -r * 1.0f, -r * 1.05f, r * 0.9f, -r * 0.6f, r * 0.12f, 0xFF30363F.toInt()); rr(c, -r * 1.0f, r * 0.6f, r * 0.9f, r * 1.05f, r * 0.12f, 0xFF30363F.toInt())
                for (i in -3..3) { val x = i * r * 0.3f + w * r * 0.1f; ln(c, x, -r * 1.0f, x, -r * 0.65f, 1.8f, 0xFF59616C.toInt()); ln(c, x, r * 0.65f, x, r * 1.0f, 1.8f, 0xFF59616C.toInt()) }
                rr(c, -r * 0.9f, -r * 0.7f, r * 0.8f, r * 0.7f, r * 0.14f, base)
                rr(c, -r * 0.7f, -r * 0.5f, r * 0.3f, r * 0.2f, r * 0.1f, light)
                circ(c, -r * 0.1f, 0f, r * 0.38f, 0xFF1A222C.toInt()); glow(c, -r * 0.1f, 0f, r * 0.9f, 0xFFFFD84A.toInt(), 0.5f * core); circ(c, -r * 0.1f, 0f, r * 0.2f * (0.8f + 0.4f * core), 0xFFFFE066.toInt())
                rr(c, r * 0.2f, -r * 0.85f, r * 1.25f, -r * 0.55f, r * 0.08f, 0xFF59616C.toInt()); rr(c, r * 0.2f, r * 0.55f, r * 1.25f, r * 0.85f, r * 0.08f, 0xFF59616C.toInt())
                circ(c, r * 1.2f, -r * 0.7f, r * 0.12f, 0xFFFFD84A.toInt()); circ(c, r * 1.2f, r * 0.7f, r * 0.12f, 0xFFFFD84A.toInt())
                circ(c, r * 0.65f, 0f, r * 0.28f, 0xFF3F4752.toInt()); circ(c, r * 0.72f, 0f, r * 0.1f, 0xFFFF5A3A.toInt())
            }
            EnemyKind.BOSS_WRAITH -> {
                for (i in 0 until 3) { val a = time * 2f + i * 2.094f; circ(c, -r * 0.2f + cos(a) * r * 1.35f, sin(a) * r * 1.35f, r * 0.16f, 0xFFD3BBFF.toInt()); glow(c, -r * 0.2f + cos(a) * r * 1.35f, sin(a) * r * 1.35f, r * 0.5f, 0xFFB388FF.toInt(), 0.4f) }
                ArtKit.path.reset()
                ArtKit.path.moveTo(r * 1.0f, 0f)
                ArtKit.path.quadTo(r * 0.3f, -r * 1.1f, -r * 0.6f, -r * 0.9f)
                for (i in 0 until 5) ArtKit.path.lineTo(-r * (1.3f + (i % 2) * 0.35f), -r * 0.8f + i * r * 0.4f + sin(time * 5f + i) * r * 0.14f)
                ArtKit.path.quadTo(r * 0.3f, r * 1.1f, r * 1.0f, 0f)
                ArtKit.fillPath(c, base)
                ArtKit.path.reset()
                ArtKit.path.moveTo(r * 0.7f, 0f); ArtKit.path.quadTo(r * 0.15f, -r * 0.55f, -r * 0.4f, -r * 0.4f); ArtKit.path.quadTo(-r * 0.2f, 0f, -r * 0.4f, r * 0.4f); ArtKit.path.quadTo(r * 0.15f, r * 0.55f, r * 0.7f, 0f)
                ArtKit.fillPath(c, 0xFF1A1030.toInt())
                circ(c, r * 0.3f, -r * 0.2f, r * 0.13f, 0xFFFF6AD8.toInt()); circ(c, r * 0.3f, r * 0.2f, r * 0.13f, 0xFFFF6AD8.toInt())
                glow(c, r * 0.3f, 0f, r * 0.7f, 0xFFFF6AD8.toInt(), 0.35f)
            }
        }
    }
}
