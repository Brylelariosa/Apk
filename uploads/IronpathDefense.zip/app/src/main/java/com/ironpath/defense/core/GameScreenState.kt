package com.ironpath.defense.core

/** Top-level screen/flow state. GameView and the input/HUD layers branch on this. */
enum class GameScreenState {
    MAIN_MENU,
    MAP_SELECT,
    CODEX,
    PLAYING,
    PAUSED,
    SETTINGS,
    GAME_OVER,
    VICTORY
}
