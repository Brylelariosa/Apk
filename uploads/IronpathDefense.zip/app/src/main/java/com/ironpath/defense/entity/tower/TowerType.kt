package com.ironpath.defense.entity.tower

import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.tower.upgrade.CrossPerk
import com.ironpath.defense.entity.tower.upgrade.UpgradeCatalog
import com.ironpath.defense.entity.tower.upgrade.UpgradePath

/** Damage "element": decides which synergy links a tower can form with its neighbors. */
enum class TowerElement(val displayName: String) {
    KINETIC("Kinetic"), FIRE("Fire"), ICE("Ice"), ELECTRIC("Electric")
}

/**
 * Static definition of each tower archetype: cost, unlock wave, base stats,
 * projectile, element, and its three bespoke upgrade paths plus fusions.
 * Enum order is the order towers appear in the shop (roughly by unlock wave).
 */
enum class TowerType(
    val displayName: String,
    val shortName: String,
    val baseCost: Int,
    val unlockWave: Int,
    val colorArgb: Int,
    val projectileType: ProjectileType,
    val element: TowerElement,
    val baseStats: TowerStats,
    val blurb: String,
    val paths: List<UpgradePath>,
    val perks: List<CrossPerk>
) {
    ARCHER(
        displayName = "Archer Tower", shortName = "Archer", baseCost = 100, unlockWave = 1,
        colorArgb = 0xFF6FA85C.toInt(), projectileType = ProjectileType.ARROW, element = TowerElement.KINETIC,
        baseStats = TowerStats(damage = 12f, range = 170f, fireRateSeconds = 0.45f),
        blurb = "Cheap and fast. Becomes a piercing ballista, a volley corps or a fire-arrow pyre.",
        paths = UpgradeCatalog.ARCHER, perks = UpgradeCatalog.ARCHER_PERKS
    ),
    CANNON(
        displayName = "Cannon Tower", shortName = "Cannon", baseCost = 180, unlockWave = 1,
        colorArgb = 0xFF8A8F98.toInt(), projectileType = ProjectileType.CANNONBALL, element = TowerElement.KINETIC,
        baseStats = TowerStats(damage = 34f, range = 150f, fireRateSeconds = 1.30f, splashRadius = 55f),
        blurb = "Heavy splash shells. Grows into a siege mortar, a gatling fortress or an armor breaker.",
        paths = UpgradeCatalog.CANNON, perks = UpgradeCatalog.CANNON_PERKS
    ),
    FROST(
        displayName = "Frost Tower", shortName = "Frost", baseCost = 130, unlockWave = 3,
        colorArgb = 0xFF6FD6D0.toInt(), projectileType = ProjectileType.FROST_SHARD, element = TowerElement.ICE,
        baseStats = TowerStats(damage = 6f, range = 140f, fireRateSeconds = 0.90f, slowMultiplier = 0.60f, slowDurationSeconds = 1.5f),
        blurb = "Slows everything it touches. Locks lanes, whips up blizzards or shatters chilled foes.",
        paths = UpgradeCatalog.FROST, perks = UpgradeCatalog.FROST_PERKS
    ),
    FLAME(
        displayName = "Flame Tower", shortName = "Flame", baseCost = 230, unlockWave = 8,
        colorArgb = 0xFFFF7A2E.toInt(), projectileType = ProjectileType.FLAME, element = TowerElement.FIRE,
        baseStats = TowerStats(damage = 5f, range = 105f, fireRateSeconds = 0.11f, splashRadius = 24f, burnDps = 7f, burnSeconds = 1.6f),
        blurb = "Short-range fire that burns. Evolves into an inferno, a chain of explosions or napalm.",
        paths = UpgradeCatalog.FLAME, perks = UpgradeCatalog.FLAME_PERKS
    ),
    RANGER(
        displayName = "Ranger Tower", shortName = "Ranger", baseCost = 220, unlockWave = 6,
        colorArgb = 0xFFA3B565.toInt(), projectileType = ProjectileType.RANGER_DART, element = TowerElement.KINETIC,
        baseStats = TowerStats(damage = 48f, range = 260f, fireRateSeconds = 1.10f, armorPenetration = 6f),
        blurb = "Long-range sniper. Precision crits, a tactical command post or advanced railgun tech.",
        paths = UpgradeCatalog.RANGER, perks = UpgradeCatalog.RANGER_PERKS
    ),
    LIGHTNING(
        displayName = "Lightning Tower", shortName = "Tesla", baseCost = 260, unlockWave = 10,
        colorArgb = 0xFFC9A6FF.toInt(), projectileType = ProjectileType.LIGHTNING_BOLT, element = TowerElement.ELECTRIC,
        baseStats = TowerStats(damage = 18f, range = 150f, fireRateSeconds = 0.85f, chainCount = 2, chainRadius = 90f, chainDamageFalloff = 0.65f),
        blurb = "Chain lightning. Overcharge it, spread the arcs or turn it into an EMP.",
        paths = UpgradeCatalog.LIGHTNING, perks = UpgradeCatalog.LIGHTNING_PERKS
    );

    /** A tower unlocks once the player has reached wave [unlockWave] (reaching it means having completed the one before). */
    fun isUnlockedAt(highestWaveCompleted: Int): Boolean = highestWaveCompleted + 1 >= unlockWave
}
