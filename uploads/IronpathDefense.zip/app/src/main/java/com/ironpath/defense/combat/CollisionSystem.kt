package com.ironpath.defense.combat

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.tower.TargetingMode

/**
 * Uniform-grid spatial hash over enemy positions, rebuilt once per fixed step.
 * Range queries only touch the few cells overlapping the query circle.
 *
 * [queryRadius] returns a shared scratch list: consume it before querying
 * again. Code that needs to query while iterating uses [queryRadiusInto] with
 * its own list. Cloaked enemies are excluded from *targeting* ([findTarget],
 * [findTargets]) but not from area queries, so splash still catches them.
 */
class CollisionSystem(worldWidth: Float, worldHeight: Float) {
    private val cellSize = GameConfig.SPATIAL_CELL_SIZE
    private val cols = (worldWidth / cellSize).toInt() + 1
    private val rows = (worldHeight / cellSize).toInt() + 1
    private val buckets = Array(cols * rows) { ArrayList<Enemy>(8) }
    private val scratch = ArrayList<Enemy>(48)
    private val candidatePool = ArrayList<Enemy>(48)

    fun rebuild(enemies: List<Enemy>) {
        for (b in buckets.indices) buckets[b].clear()
        for (i in 0 until enemies.size) {
            val enemy = enemies[i]
            val col = (enemy.position.x / cellSize).toInt().coerceIn(0, cols - 1)
            val row = (enemy.position.y / cellSize).toInt().coerceIn(0, rows - 1)
            buckets[row * cols + col].add(enemy)
        }
    }

    fun queryRadius(center: Vector2, radius: Float): List<Enemy> {
        queryRadiusInto(center, radius, scratch)
        return scratch
    }

    fun queryRadiusInto(center: Vector2, radius: Float, out: ArrayList<Enemy>) {
        out.clear()
        val radiusSquared = radius * radius
        val minCol = ((center.x - radius) / cellSize).toInt()
        val maxCol = ((center.x + radius) / cellSize).toInt()
        val minRow = ((center.y - radius) / cellSize).toInt()
        val maxRow = ((center.y + radius) / cellSize).toInt()
        for (row in minRow..maxRow) {
            if (row < 0 || row >= rows) continue
            for (col in minCol..maxCol) {
                if (col < 0 || col >= cols) continue
                val bucket = buckets[row * cols + col]
                for (k in 0 until bucket.size) {
                    val enemy = bucket[k]
                    if (center.distanceSquaredTo(enemy.position) <= radiusSquared) out.add(enemy)
                }
            }
        }
    }

    fun findTarget(position: Vector2, range: Float, mode: TargetingMode): Enemy? {
        val candidates = queryRadius(position, range)
        var best: Enemy? = null
        var bestScore = -Float.MAX_VALUE
        for (i in 0 until candidates.size) {
            val e = candidates[i]
            if (!e.isTargetable) continue
            val score = targetScore(e, position, mode)
            if (score > bestScore) {
                bestScore = score
                best = e
            }
        }
        return best
    }

    /** Fills [out] with up to [count] distinct targets, best-first for the given [mode]. */
    fun findTargets(position: Vector2, range: Float, mode: TargetingMode, count: Int, out: MutableList<Enemy>) {
        out.clear()
        val inRange = queryRadius(position, range)
        candidatePool.clear()
        for (i in 0 until inRange.size) if (inRange[i].isTargetable) candidatePool.add(inRange[i])
        if (candidatePool.isEmpty()) return
        val picks = minOf(count, candidatePool.size)
        repeat(picks) {
            var bestIndex = 0
            var bestScore = targetScore(candidatePool[0], position, mode)
            for (i in 1 until candidatePool.size) {
                val score = targetScore(candidatePool[i], position, mode)
                if (score > bestScore) {
                    bestScore = score
                    bestIndex = i
                }
            }
            out.add(candidatePool.removeAt(bestIndex))
        }
    }

    private fun targetScore(enemy: Enemy, from: Vector2, mode: TargetingMode): Float = when (mode) {
        TargetingMode.FIRST -> enemy.distanceTraveled
        TargetingMode.STRONGEST -> enemy.currentHealth + enemy.shield
        TargetingMode.CLOSEST -> -from.distanceSquaredTo(enemy.position)
    }
}
