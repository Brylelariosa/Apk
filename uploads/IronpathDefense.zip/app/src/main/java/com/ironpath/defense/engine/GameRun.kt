package com.ironpath.defense.engine

import com.ironpath.defense.ability.AbilityType
import com.ironpath.defense.ability.PlayerAbilities
import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.audio.SoundEffect
import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.Fx
import com.ironpath.defense.combat.HitResolver
import com.ironpath.defense.core.Difficulty
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.RunModifiers
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.director.DirectorEvent
import com.ironpath.defense.director.DirectorEventType
import com.ironpath.defense.director.DirectorSystem
import com.ironpath.defense.economy.EconomySystem
import com.ironpath.defense.economy.UpgradeSystem
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemyAbilities
import com.ironpath.defense.entity.enemy.EnemySystem
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.entity.projectile.ProjectileSystem
import com.ironpath.defense.entity.tower.SynergySystem
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerSystem
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability
import com.ironpath.defense.entity.zone.ZoneKind
import com.ironpath.defense.entity.zone.ZoneSystem
import com.ironpath.defense.map.GameMap
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.mapfx.MapMechanics
import com.ironpath.defense.save.SaveData
import com.ironpath.defense.wave.WaveDefinition
import com.ironpath.defense.wave.WavePlanner
import com.ironpath.defense.wave.WaveSystem
import com.ironpath.defense.wave.WaveType
import kotlin.math.ceil

/**
 * One playthrough of one map at one difficulty: every gameplay system, the
 * wave flow (build -> countdown -> active -> cleared), tower actions and the
 * win/lose rules. GameWorld owns *which screen is showing*; a GameRun owns
 * *the game itself*, so restarting is just creating a new run.
 */
class GameRun(
    val map: GameMap,
    val difficulty: Difficulty,
    private val effects: CombatEffects,
    private val audio: AudioSystem,
    private val particles: ParticleSystem,
    private val data: SaveData,
    private val listener: RunListener
) {
    enum class Phase { BUILD, COUNTDOWN, ACTIVE, ENDED }

    // --- systems ----------------------------------------------------------------
    val mapSystem = MapSystem(map)
    val modifiers = RunModifiers()
    private val collision = CollisionSystem(GameConfig.WORLD_WIDTH, GameConfig.WORLD_HEIGHT)
    val enemies = EnemySystem(mapSystem.pathSystem)
    val zones = ZoneSystem(collision)
    private val hitResolver = HitResolver(collision, effects)
    val projectiles = ProjectileSystem(collision, hitResolver, zones, effects)
    val towers = TowerSystem(collision, projectiles, hitResolver, effects, modifiers)
    private val synergy = SynergySystem()
    private val enemyAbilities = EnemyAbilities(enemies, effects) { towers.all }
    val waves = WaveSystem(enemies, map.waveCount)
    val economy = EconomySystem(difficulty.startMoney)
    private val upgrades = UpgradeSystem(economy)
    val director = DirectorSystem()
    val mechanics = MapMechanics(map, mapSystem, zones, enemies, collision, modifiers, effects)
    val player = PlayerAbilities(collision, enemies, { towers.all }, effects)

    // --- run state ----------------------------------------------------------
    val maxLives = difficulty.lives
    var lives = maxLives
        private set
    var phase = Phase.BUILD
        private set
    var countdown = 0f
        private set
    var autoStartTimer = GameConfig.AUTO_START_SECONDS
        private set
    var autoStartEnabled = false
    var nextWave: WaveDefinition = WavePlanner.base(map, 1)
        private set
    var nextEvent: DirectorEvent? = null
        private set
    var victory = false
        private set
    val stats = RunStats()

    var selectedTower: Tower? = null
        private set
    var pendingType: TowerType? = null
        private set
    var selectedPath = 0

    /** The boss currently on the field (for the HUD health bar), or null. */
    var activeBoss: Enemy? = null
        private set
    var activeBossGeneration = -1
        private set

    val basePosition: Vector2
    val spawnPosition: Vector2

    private var livesAtWaveStart = maxLives
    private var lastCountdownTick = 0
    private val blastX = FloatArray(MAX_BLASTS)
    private val blastY = FloatArray(MAX_BLASTS)
    private val blastR = FloatArray(MAX_BLASTS)
    private val blastD = FloatArray(MAX_BLASTS)
    private val blastGen = IntArray(MAX_BLASTS)
    private val blastColor = IntArray(MAX_BLASTS)
    private val blastSource = IntArray(MAX_BLASTS)
    private var blastCount = 0
    private val blastScratch = ArrayList<Enemy>(32)
    private val tmp = Vector2()

    init {
        val path = mapSystem.pathSystem
        val last = path.waypoint(path.segmentCount)
        basePosition = Vector2(
            last.x.coerceIn(30f, GameConfig.WORLD_WIDTH - 30f),
            last.y.coerceIn(30f, GameConfig.WORLD_HEIGHT - 30f)
        )
        spawnPosition = path.waypoint(0).copy()
        zones.towers = towers.all
        enemyAbilities.difficultyHealth = difficulty.healthMult
        enemies.slickSegments = mechanics.buildSlickArray(path.segmentCount)
        mechanics.reset()
        director.reset()
        effects.damageSink = { sourceType, amount -> director.recordDamage(sourceType, amount) }
        effects.steamSink = { stats.steamBursts++ }
        planNext()
    }

    val currentWaveNumber: Int
        get() = if (waves.waveInProgress) (waves.activeWaveDefinition?.index ?: waves.currentWaveIndex) else waves.currentWaveIndex + 1

    // --- per-step update ---------------------------------------------------------
    fun update(dt: Float) {
        if (phase == Phase.ENDED) return
        when (phase) {
            Phase.BUILD -> if (autoStartEnabled && waves.canStartNextWave()) {
                autoStartTimer -= dt
                if (autoStartTimer <= 0f) requestStartWave()
            }
            Phase.COUNTDOWN -> {
                countdown -= dt
                val whole = ceil(countdown.coerceAtLeast(0f)).toInt()
                if (whole != lastCountdownTick) {
                    lastCountdownTick = whole
                    if (whole in 1..3) audio.play(SoundEffect.COUNTDOWN, 0.8f, 1f + (3 - whole) * 0.12f)
                }
                if (countdown <= 0f) beginWave()
            }
            else -> {}
        }
        val waveActive = phase == Phase.ACTIVE
        mechanics.waveNumber = currentWaveNumber
        mechanics.update(dt, waveActive)
        val reward = if (waveActive) waves.update(dt, difficulty.healthMult) else null
        enemies.update(dt, ::onLeaked, ::onKilled)
        enemyAbilities.update(dt)
        collision.rebuild(enemies.active)
        processBlasts()
        towers.update(dt)
        projectiles.update(dt)
        zones.update(dt)
        player.update(dt)
        trackBoss()
        if (lives <= 0) {
            end(false)
            return
        }
        if (reward != null) onWaveFinished(reward)
    }

    private fun trackBoss() {
        var found: Enemy? = null
        val list = enemies.active
        for (i in 0 until list.size) {
            val e = list[i]
            if (e.kind.isBoss) {
                if (found == null || e.maxHealth > found.maxHealth) found = e
            }
        }
        activeBoss = found
        activeBossGeneration = found?.generation ?: -1
    }

    // --- wave flow ---------------------------------------------------------------
    private fun planNext() {
        val base = WavePlanner.base(map, waves.nextWaveNumber)
        val plan = director.plan(base, towers.all, mapSystem)
        nextWave = plan.wave
        nextEvent = plan.event
    }

    fun requestStartWave() {
        if (phase != Phase.BUILD || !waves.canStartNextWave()) return
        val wave = nextWave
        phase = Phase.COUNTDOWN
        val elite = wave.type == WaveType.BOSS || wave.type == WaveType.MINIBOSS
        countdown = if (elite) 4.5f else GameConfig.WAVE_COUNTDOWN_SECONDS
        lastCountdownTick = ceil(countdown).toInt() + 1
        selectedTower = null
        pendingType = null
        player.disarm()
        val final = wave.index == map.waveCount
        listener.onBanner(BannerKind.WAVE, "WAVE ${wave.index}", if (final) "FINAL WAVE" else wave.type.label, wave.type.colorArgb)
        if (elite) {
            val head = wave.headliner?.displayName ?: ""
            listener.onBanner(BannerKind.BOSS, if (wave.type == WaveType.BOSS) "BOSS INCOMING" else "MINI-BOSS", head, 0xFFFF4A4A.toInt())
            audio.play(SoundEffect.BOSS_WARN, 1f)
        }
    }

    private fun beginWave() {
        val wave = nextWave
        phase = Phase.ACTIVE
        livesAtWaveStart = lives
        waves.start(wave)
        audio.play(SoundEffect.WAVE_START)
        val event = nextEvent
        nextEvent = null
        if (event != null) applyEvent(event)
        if (wave.note.isNotEmpty()) listener.onBanner(BannerKind.EVENT, "DIRECTOR", wave.note, 0xFF8FE8D0.toInt())
    }

    private fun applyEvent(event: DirectorEvent) {
        when (event.type) {
            DirectorEventType.SUPPLY_DROP -> {
                economy.earn(event.amount)
                tmp.set(GameConfig.WORLD_WIDTH / 2f, GameConfig.WORLD_HEIGHT / 2f)
                particles.spawnFloatingText(tmp, "SUPPLY DROP +$${event.amount}", 0xFFFFD35A.toInt(), 2.2f)
                audio.play(SoundEffect.TOWER_SELL, 1f, 0.9f)
            }
            DirectorEventType.BOUNTY_ZONE -> {
                zones.spawn(ZoneKind.BOUNTY, event.x, event.y, 110f, 90f)
                effects.onFx(Fx.BOUNTY, event.x, event.y, 110f, ZoneKind.BOUNTY.colorArgb)
            }
        }
    }

    private fun onWaveFinished(baseReward: Int) {
        val perfect = lives >= livesAtWaveStart
        val reward = (baseReward * difficulty.rewardMult).toInt()
        val bonus = if (perfect) (reward * 0.1f).toInt() else 0
        economy.earn(reward + bonus)
        val cleared = waves.currentWaveIndex
        data.wavesCleared++
        if (cleared > data.highestWaveCompleted) data.highestWaveCompleted = cleared
        if (cleared > data.mapBestWave[map.id]) data.mapBestWave[map.id] = cleared
        director.onWaveFinished(lives, maxLives, economy.money, baseReward)
        listener.onProgress()
        audio.play(SoundEffect.WAVE_CLEAR)
        listener.onBanner(
            BannerKind.CLEAR, "WAVE $cleared CLEARED",
            if (bonus > 0) "+$$reward  +$$bonus perfect bonus" else "+$$reward", 0xFF8FE88F.toInt()
        )
        if (waves.hasWonGame) {
            end(true)
            return
        }
        planNext()
        phase = Phase.BUILD
        autoStartTimer = GameConfig.AUTO_START_SECONDS
    }

    private fun end(won: Boolean) {
        if (phase == Phase.ENDED) return
        phase = Phase.ENDED
        victory = won
        selectedTower = null
        pendingType = null
        player.disarm()
        listener.onRunEnded(won)
    }

    // --- combat callbacks -----------------------------------------------------
    private fun onKilled(e: Enemy) {
        val inBounty = zones.inBountyZone(e.position.x, e.position.y)
        val gold = (e.reward * e.rewardMult * difficulty.rewardMult * (if (inBounty) 1.5f else 1f)).toInt() + e.bountyBonus
        economy.earn(gold)
        stats.kills++
        if (e.kind.isBoss) {
            stats.bossKills++
            listener.onBanner(BannerKind.BOSS, "${e.kind.displayName.uppercase()} DEFEATED", "+$$gold", 0xFFFFD35A.toInt())
        }
        director.recordKill(e, mapSystem.pathSystem.totalLength)
        effects.onEnemyDied(e, gold)
        enemyAbilities.onKilled(e)
        if (e.deathBlastDamage > 0f) queueBlast(e)
    }

    private fun onLeaked(e: Enemy) {
        val cost = e.kind.leakDamage
        lives -= cost
        stats.livesLost += cost
        stats.leaks++
        director.recordLeak(e.kind)
        effects.onBaseHit(basePosition)
    }

    private fun queueBlast(e: Enemy) {
        if (blastCount >= MAX_BLASTS) return
        val i = blastCount++
        blastX[i] = e.position.x
        blastY[i] = e.position.y
        blastR[i] = e.deathBlastRadius
        blastD[i] = e.deathBlastDamage
        blastGen[i] = e.blastGen
        blastColor[i] = if (e.isBurning) e.burnColorArgb else 0xFF9FE8FF.toInt()
        blastSource[i] = e.lastHitSourceType
    }

    /** Death blasts (burning kills, shattering ice): damage nearby enemies, and burning ones become volatile too. */
    private fun processBlasts() {
        val n = blastCount
        blastCount = 0
        for (i in 0 until n) {
            tmp.set(blastX[i], blastY[i])
            collision.queryRadiusInto(tmp, blastR[i], blastScratch)
            val damage = blastD[i]
            for (k in 0 until blastScratch.size) {
                val e = blastScratch[k]
                e.takeTrueDamage(damage)
                e.timeSinceLastHit = 0f
                e.hitFlash = 0.1f
                if (e.isBurning && blastGen[i] < 3 && e.deathBlastDamage < damage * 0.8f) {
                    e.deathBlastDamage = damage * 0.8f
                    e.deathBlastRadius = blastR[i] * 0.95f
                    e.blastGen = blastGen[i] + 1
                }
                effects.onEnemyHit(e, damage, false, blastSource[i])
            }
            effects.onFx(Fx.EXPLOSION, blastX[i], blastY[i], blastR[i], blastColor[i])
        }
    }

    // --- player actions ----------------------------------------------------------
    fun canBuild(type: TowerType): Boolean = type.isUnlockedAt(data.highestWaveCompleted)

    fun armTower(type: TowerType) {
        if (!canBuild(type)) {
            audio.play(SoundEffect.ERROR)
            return
        }
        pendingType = if (pendingType == type) null else type
        selectedTower = null
        player.disarm()
    }

    fun deselect() {
        selectedTower = null
        pendingType = null
        player.disarm()
    }

    /** Routes a tap on the battlefield: armed ability, rune pedestal, tower placement or selection. */
    fun onWorldTap(x: Float, y: Float) {
        if (phase == Phase.ENDED) return
        if (player.armed != null) {
            player.fireArmedAt(x, y, currentWaveNumber)
            audio.play(SoundEffect.ABILITY)
            return
        }
        if (mechanics.tryActivateRune(x, y)) return
        val tapped = towerAtWorld(x, y)
        val type = pendingType
        if (type != null) {
            if (tapped != null) {
                select(tapped)
                pendingType = null
            } else if (tryPlace(type, x, y)) {
                pendingType = null
            }
            return
        }
        if (tapped != null) select(tapped) else deselect()
    }

    private fun select(tower: Tower) {
        selectedTower = tower
        selectedPath = if (tower.dominantPath >= 0) tower.dominantPath else 0
        audio.play(SoundEffect.BUTTON_TAP, 0.6f, 1.3f)
    }

    private fun towerAtWorld(x: Float, y: Float): Tower? {
        tmp.set(x, y)
        val tile = mapSystem.worldToTile(tmp)
        val all = towers.all
        for (i in 0 until all.size) {
            val t = all[i]
            val tt = mapSystem.worldToTile(t.position)
            if (tt.first == tile.first && tt.second == tile.second) return t
        }
        return null
    }

    private fun tryPlace(type: TowerType, x: Float, y: Float): Boolean {
        tmp.set(x, y)
        if (!mapSystem.canPlaceTowerAt(tmp)) {
            audio.play(SoundEffect.ERROR)
            tmp.set(x, y - 20f)
            particles.spawnFloatingText(tmp, "Can't build here", 0xFFFF8A7A.toInt(), 0.9f)
            return false
        }
        if (!canBuild(type) || !economy.spend(type.baseCost)) {
            audio.play(SoundEffect.ERROR)
            tmp.set(x, y - 20f)
            particles.spawnFloatingText(tmp, "Need $${type.baseCost}", 0xFFFF8A7A.toInt(), 0.9f)
            return false
        }
        val tile = mapSystem.worldToTile(tmp)
        val center = mapSystem.tileToWorldCenter(tile.first, tile.second)
        val tower = Tower(type, center)
        tower.heightBonus = mapSystem.rangeBonusAt(center)
        tower.refreshEffective()
        towers.place(tower)
        mapSystem.markBuilt(center, true)
        synergy.refresh(towers.all)
        effects.onTowerPlaced(center, type.colorArgb)
        stats.towersBuilt[type.ordinal]++
        data.towersBuilt++
        selectedTower = tower
        selectedPath = 0
        return true
    }

    fun upgradeSelected(path: Int): Boolean {
        val tower = selectedTower ?: return false
        if (path !in tower.pathTiers.indices) return false
        val hadFusion = tower.fusion
        if (!upgrades.tryUpgrade(tower, path)) {
            audio.play(SoundEffect.ERROR)
            return false
        }
        synergy.refresh(towers.all)
        val tier = tower.pathTiers[path]
        val upgrade = tower.type.paths[path].upgrades[tier - 1]
        val color = tower.type.paths[path].colorArgb
        effects.onTowerUpgraded(tower.position, color, upgrade.name, tier == 5)
        val fusion = tower.fusion
        if (fusion != null && fusion !== hadFusion) {
            effects.onFusion(tower.position, fusion.name, color)
            stats.fusions++
            data.fusionsBuilt++
        }
        selectedPath = path
        listener.onProgress()
        return true
    }

    fun sellSelected() {
        val tower = selectedTower ?: return
        upgrades.sell(tower)
        towers.remove(tower)
        mapSystem.markBuilt(tower.position, false)
        synergy.refresh(towers.all)
        effects.onTowerSold(tower.position, tower.accentColorArgb)
        selectedTower = null
    }

    fun cycleTargeting() {
        selectedTower?.cycleTargetingMode()
        audio.play(SoundEffect.BUTTON_TAP, 0.6f)
    }

    fun canAffordUpgrade(tower: Tower, path: Int): Boolean = upgrades.canUpgrade(tower, path)

    fun useAbility(index: Int) {
        val type = AbilityType.entries.getOrNull(index) ?: return
        if (phase == Phase.ENDED) return
        if (!player.isReady(type)) {
            audio.play(SoundEffect.ERROR, 0.6f)
            return
        }
        selectedTower = null
        pendingType = null
        player.activate(type, currentWaveNumber)
        audio.play(if (type.needsTarget) SoundEffect.BUTTON_TAP else SoundEffect.ABILITY)
    }

    /** Rough score used on the end screens and the per-map best score. */
    fun score(): Int {
        val raw = stats.kills * 10 + waves.currentWaveIndex * 100 + lives.coerceAtLeast(0) * 50 + (if (victory) 1000 else 0)
        return (raw * difficulty.scoreMult).toInt()
    }

    fun stars(): Int = when {
        !victory -> 0
        lives >= maxLives * 0.9f -> 3
        lives >= maxLives * 0.5f -> 2
        else -> 1
    }

    fun upgradeAvailability(tower: Tower, path: Int): UpgradeAvailability = tower.upgradeAvailability(path)

    private companion object {
        const val MAX_BLASTS = 24
    }
}
