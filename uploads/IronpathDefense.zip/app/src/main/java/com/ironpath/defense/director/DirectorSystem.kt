package com.ironpath.defense.director

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.map.TileKind
import com.ironpath.defense.wave.SpawnGroup
import com.ironpath.defense.wave.WavePlanner
import com.ironpath.defense.wave.WaveType
import com.ironpath.defense.wave.WaveDefinition
import kotlin.math.abs
import kotlin.math.roundToInt

enum class DirectorMood(val label: String) {
    STRUGGLING("Struggling"), STEADY("Steady"), DOMINATING("Dominating")
}

enum class DirectorEventType { SUPPLY_DROP, BOUNTY_ZONE }

/** A one-off, clearly announced help (or hint) the Director attaches to the *next* wave. */
class DirectorEvent(val type: DirectorEventType, val amount: Int, val x: Float, val y: Float, val text: String)

class DirectorPlan(val wave: WaveDefinition, val event: DirectorEvent?)

/**
 * The Adaptive Game Director: a lightweight, rule-based "dungeon master".
 *
 * It *observes* the run — which towers deal the damage, how deep into the path
 * enemies die, how many leak and which kinds, remaining lives, banked money and
 * where towers stand — and then shapes the *next* wave within hard limits:
 *
 *  - never touches towers, tower stats, enemy stats or the economy rules;
 *  - enemy counts move at most -15% / +20% for regular groups; bosses are never rescaled;
 *  - at most one counter group, one elite squad and one event per wave;
 *  - the plan is produced once, *before* the wave, and shown to the player in the
 *    next-wave preview with an explanation, so there is nothing hidden.
 *
 * Struggling players get a lighter wave and a supply drop; dominating players
 * get a more *interesting* wave (elite squads), not just more HP; reliance on a
 * single tower type draws counter-enemies; and a lopsided layout earns a bounty
 * zone that makes an unused area worth building in.
 */
class DirectorSystem {
    var mood = DirectorMood.STEADY
        private set
    var pressure = 0f
        private set

    private val damageByType = FloatArray(TowerType.entries.size)
    private val leakByKind = IntArray(EnemyKind.entries.size)
    private var progressSum = 0f
    private var killCount = 0
    private var leaksThisWave = 0
    private var lastSupplyWave = -10
    private var lastZoneWave = -10
    private var lastEliteWave = -10
    private var lastCounterWave = -10

    fun reset() {
        mood = DirectorMood.STEADY
        pressure = 0f
        damageByType.fill(0f)
        leakByKind.fill(0)
        progressSum = 0f
        killCount = 0
        leaksThisWave = 0
        lastSupplyWave = -10
        lastZoneWave = -10
        lastEliteWave = -10
        lastCounterWave = -10
    }

    // --- telemetry ----------------------------------------------------------
    fun recordDamage(sourceType: Int, amount: Float) {
        if (sourceType in damageByType.indices) damageByType[sourceType] += amount
    }

    fun recordKill(enemy: Enemy, pathLength: Float) {
        if (enemy.summoned) return
        progressSum += (enemy.distanceTraveled / pathLength).coerceIn(0f, 1f)
        killCount++
    }

    fun recordLeak(kind: EnemyKind) {
        leaksThisWave++
        leakByKind[kind.ordinal]++
    }

    /** Called when a wave ends: updates the pressure estimate and the mood. */
    fun onWaveFinished(lives: Int, maxLives: Int, money: Int, waveReward: Int) {
        val lifeFrac = lives.toFloat() / maxLives.toFloat()
        val avgProgress = if (killCount > 0) progressSum / killCount else 0.5f
        var p = (0.5f - avgProgress) * 1.4f - leaksThisWave * 0.22f - (1f - lifeFrac) * 0.9f
        if (money > 2.2f * waveReward + 250f) p += 0.1f // sitting on lots of unspent cash: comfortable
        pressure = pressure * 0.55f + p.coerceIn(-1f, 1f) * 0.45f
        mood = when {
            pressure > 0.33f -> DirectorMood.DOMINATING
            pressure < -0.22f -> DirectorMood.STRUGGLING
            else -> DirectorMood.STEADY
        }
        for (i in damageByType.indices) damageByType[i] *= 0.5f
        progressSum = 0f
        killCount = 0
        leaksThisWave = 0
    }

    /** Short human-readable cause of defeat (for the defeat screen). */
    fun defeatReason(): String {
        var best = -1
        var bestCount = 0
        for (i in leakByKind.indices) {
            if (leakByKind[i] > bestCount) {
                bestCount = leakByKind[i]
                best = i
            }
        }
        if (best < 0) return "The base was overrun."
        val kind = EnemyKind.entries[best]
        return if (kind.isElite) "Breached by the ${kind.displayName}." else "Overrun by ${kind.displayName}s."
    }

    // --- planning -----------------------------------------------------------
    fun plan(base: WaveDefinition, towers: List<Tower>, map: MapSystem): DirectorPlan {
        val w = base.index
        if (base.type == WaveType.BOSS) {
            return DirectorPlan(base, supportEvent(base, w))
        }
        var groups: MutableList<SpawnGroup> = base.groups.toMutableList()
        val notes = ArrayList<String>(3)
        var adapted = false

        val mult = (1f + 0.2f * pressure).coerceIn(0.85f, 1.2f)
        if (w >= 3 && abs(mult - 1f) >= 0.04f) {
            groups = groups.map { g ->
                if (g.kind.isElite) g else g.copy(count = (g.count * mult).roundToInt().coerceAtLeast(1))
            }.toMutableList()
            adapted = true
            notes.add(if (mult < 1f) "A lighter wave while you recover." else "A larger wave: your defense is strong.")
        }

        val dominant = dominantType(towers)
        if (dominant != null && w >= 4 && w - lastCounterWave >= 2 && base.type != WaveType.MINIBOSS && mood != DirectorMood.STRUGGLING) {
            val counter = counterFor(dominant, w)
            if (counter != null) {
                val count = (3 + w / 4 + (if (counter == EnemyKind.SWARM) 6 else 0)).coerceAtMost(14)
                groups.add(SpawnGroup(counter, count, WavePlanner.interval(counter), 4f))
                lastCounterWave = w
                adapted = true
                notes.add("Counter-intel: ${dominant.shortName}-heavy defense; expect ${counter.displayName}s.")
            }
        }

        if (mood == DirectorMood.DOMINATING && w >= 5 && w - lastEliteWave >= 3 && base.type != WaveType.MINIBOSS) {
            val elite = pickElite(w, groups)
            if (elite != null) {
                groups.add(SpawnGroup(elite, (3 + w / 5).coerceAtMost(8), WavePlanner.interval(elite), 6f))
                lastEliteWave = w
                adapted = true
                notes.add("Elite squad dispatched: ${elite.displayName}s.")
            }
        }

        var event: DirectorEvent? = null
        if (mood == DirectorMood.STRUGGLING && w - lastSupplyWave >= 4) {
            event = supportEvent(base, w)
        } else if (w >= 3 && w - lastZoneWave >= 3 && concentrated(towers)) {
            val spot = findBountySpot(towers, map)
            if (spot != null) {
                event = DirectorEvent(DirectorEventType.BOUNTY_ZONE, 0, spot.x, spot.y,
                    "Bounty zone: kills in the marked area pay +50%.")
                lastZoneWave = w
            }
        }
        if (event != null) notes.add(event.text)

        // Hard cap: the Director can never make a wave dramatically bigger than planned.
        val cap = (base.totalEnemies * 1.4f).toInt() + 4
        var total = groups.sumOf { it.count }
        if (total > cap && groups.size > 1) {
            val last = groups.last()
            val trimmed = (last.count - (total - cap)).coerceAtLeast(1)
            groups[groups.size - 1] = last.copy(count = trimmed)
            total = groups.sumOf { it.count }
        }
        val wave = if (adapted) base.copy(groups = groups, adapted = true, note = notes.joinToString(" "))
        else base.copy(note = notes.joinToString(" "))
        return DirectorPlan(wave, event)
    }

    private fun supportEvent(base: WaveDefinition, w: Int): DirectorEvent? {
        if (mood != DirectorMood.STRUGGLING || w - lastSupplyWave < 4) return null
        val amount = (base.completionReward * 0.6f).toInt().coerceAtLeast(40)
        lastSupplyWave = w
        return DirectorEvent(DirectorEventType.SUPPLY_DROP, amount, 0f, 0f, "Supply drop: +$$amount when the wave starts.")
    }

    private fun dominantType(towers: List<Tower>): TowerType? {
        var total = 0f
        for (d in damageByType) total += d
        if (total < 200f) return null
        var best = -1
        var bestValue = 0f
        for (i in damageByType.indices) {
            if (damageByType[i] > bestValue) {
                bestValue = damageByType[i]
                best = i
            }
        }
        if (best < 0 || bestValue / total < 0.55f) return null
        val type = TowerType.entries[best]
        var count = 0
        for (t in towers) if (t.type == type) count++
        return if (count >= 2) type else null
    }

    private fun counterFor(type: TowerType, w: Int): EnemyKind? {
        val options = when (type) {
            TowerType.ARCHER -> listOf(EnemyKind.ARMORED, EnemyKind.TANK)
            TowerType.CANNON -> listOf(EnemyKind.FAST, EnemyKind.PHANTOM)
            TowerType.FROST -> listOf(EnemyKind.HEALER, EnemyKind.SHIELDED)
            TowerType.FLAME -> listOf(EnemyKind.FAST, EnemyKind.HEALER)
            TowerType.RANGER -> listOf(EnemyKind.SWARM, EnemyKind.SPLITTER)
            TowerType.LIGHTNING -> listOf(EnemyKind.SHIELDED, EnemyKind.PHANTOM)
        }
        val usable = options.filter { w >= WavePlanner.firstWave(it) }
        if (usable.isEmpty()) return null
        return usable[(w / 2) % usable.size]
    }

    private fun pickElite(w: Int, groups: List<SpawnGroup>): EnemyKind? {
        val pool = listOf(EnemyKind.SHIELDED, EnemyKind.PHANTOM, EnemyKind.HEALER, EnemyKind.TANK, EnemyKind.SPLITTER)
            .filter { w >= WavePlanner.firstWave(it) && groups.none { g -> g.kind == it } }
        if (pool.isEmpty()) return null
        return pool[w % pool.size]
    }

    private fun concentrated(towers: List<Tower>): Boolean {
        if (towers.size < 5) return false
        val third = GameConfig.WORLD_WIDTH / 3f
        val bands = IntArray(3)
        for (t in towers) bands[(t.position.x / third).toInt().coerceIn(0, 2)]++
        var most = 0
        for (b in bands) if (b > most) most = b
        return most >= towers.size * 0.7f
    }

    private fun findBountySpot(towers: List<Tower>, map: MapSystem): Vector2? {
        val grid = map.tileGrid
        var best: Vector2? = null
        var bestScore = 0f
        for (r in 0 until GameConfig.GRID_ROWS) {
            for (c in 0 until GameConfig.GRID_COLS) {
                if (!grid.canPlaceTower(c, r) || !nearPath(map, c, r)) continue
                val center = map.tileToWorldCenter(c, r)
                var minD = Float.MAX_VALUE
                for (t in towers) {
                    val d = t.position.distanceTo(center)
                    if (d < minD) minD = d
                }
                if (minD < 170f) continue
                if (minD > bestScore) {
                    bestScore = minD
                    best = center
                }
            }
        }
        return best
    }

    private fun nearPath(map: MapSystem, c: Int, r: Int): Boolean {
        for (dr in -2..2) for (dc in -2..2) if (map.tileGrid.kindAt(c + dc, r + dr) == TileKind.PATH) return true
        return false
    }
}
