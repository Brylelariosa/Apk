package com.ironpath.defense.combat

import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.projectile.ShotProfile
import com.ironpath.defense.entity.tower.Tower

/** Identifiers for generic one-shot effects raised through [CombatFeedback.onFx]. */
object Fx {
    const val STEAM = 1
    const val EXPLOSION = 2
    const val SHIELD_UP = 3
    const val SHIELD_BREAK = 4
    const val SUMMON = 5
    const val EMP = 6
    const val BLINK = 7
    const val ENRAGE = 8
    const val BOSS_ENTER = 9
    const val SPLIT = 10
    const val HEAL = 11
    const val PRESS = 12
    const val RUNE = 13
    const val STRIKE = 14
    const val FREEZE_ALL = 15
    const val OVERDRIVE = 16
    const val CLUSTER = 17
    const val SHATTER = 18
    const val CLOAK = 19
    const val LAVA_WARN = 20
    const val STORM_WARN = 21
    const val SURGE = 22
    const val BOUNTY = 23
}

/**
 * The combat systems report what happened through this interface and never
 * touch particles, audio or UI directly. The engine supplies the single
 * implementation that turns events into visuals, sound and run statistics.
 */
interface CombatFeedback {
    fun onEnemyHit(enemy: Enemy, damageDealt: Float, isCrit: Boolean, sourceType: Int)
    fun onSplash(center: Vector2, radius: Float, colorArgb: Int)
    fun onChainLink(from: Vector2, to: Vector2, colorArgb: Int)
    fun onPulse(center: Vector2, radius: Float, colorArgb: Int)
    fun onTowerFire(tower: Tower, special: Boolean)
    fun onImpact(type: ProjectileType, x: Float, y: Float, shot: ShotProfile)
    fun onFx(kind: Int, x: Float, y: Float, radius: Float, colorArgb: Int)
}
