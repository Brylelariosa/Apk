package com.ironpath.defense.map

private fun argb(v: Long): Int = v.toInt()

/**
 * Visual identity of a map. Pure data: the terrain painter, ambient/weather
 * renderer and map-preview all derive their look from these colors, so adding
 * a theme never touches gameplay code.
 */
enum class MapTheme(
    val displayName: String,
    val ground1: Int,
    val ground2: Int,
    val pathCore: Int,
    val pathEdge: Int,
    val accent: Int,
    val deco1: Int,
    val deco2: Int,
    val sky: Int
) {
    FOREST("Forest", argb(0xFF3F7D3A), argb(0xFF397235), argb(0xFFB89868), argb(0xFF7B6240), argb(0xFFFFE9A6), argb(0xFF2E5E2B), argb(0xFF4F9A45), argb(0xFF12301A)),
    DESERT("Desert", argb(0xFFD9B26F), argb(0xFFCFA766), argb(0xFFEAD6A6), argb(0xFFA98A52), argb(0xFFFFD27A), argb(0xFF5D8A3A), argb(0xFFB07D4A), argb(0xFF3A2A14)),
    SNOW("Frozen Pass", argb(0xFFE4EEF7), argb(0xFFD7E4F0), argb(0xFF9DB9D3), argb(0xFF5F7F9E), argb(0xFFBEE8FF), argb(0xFF8AC4E8), argb(0xFF4A6B88), argb(0xFF10202E)),
    VOLCANO("Volcano", argb(0xFF3A2A28), argb(0xFF332422), argb(0xFF5A4A44), argb(0xFF1E1412), argb(0xFFFF7A2E), argb(0xFF8C2A12), argb(0xFFFF5A1E), argb(0xFF200A06)),
    RUINS("Ancient Ruins", argb(0xFF5E7C62), argb(0xFF567459), argb(0xFFA39C86), argb(0xFF5E5A4A), argb(0xFF7CF2D0), argb(0xFF8E8A78), argb(0xFF3F6B4C), argb(0xFF0E1E1A)),
    CITY("City", argb(0xFF353B4A), argb(0xFF2F3543), argb(0xFF22252E), argb(0xFF14161C), argb(0xFFFF3FA4), argb(0xFF59647A), argb(0xFF00E5FF), argb(0xFF0A0C14)),
    FACTORY("Factory", argb(0xFF5A5F66), argb(0xFF51565D), argb(0xFF2E3238), argb(0xFF1C1F24), argb(0xFFFFB02E), argb(0xFF7D858F), argb(0xFFE05A2B), argb(0xFF121418)),
    ALIEN("Alien World", argb(0xFF3A2B5C), argb(0xFF342752), argb(0xFF5C4B7A), argb(0xFF281C3F), argb(0xFF5CFFC8), argb(0xFF8F4BD9), argb(0xFF30E3B5), argb(0xFF0C0818))
}

/** The map-specific gameplay rule. Implemented by [com.ironpath.defense.mapfx.MapMechanics]. */
enum class MapMechanic { NONE, SANDSTORM, ICE, LAVA, RUNES, GRID_SURGE, FACTORY, SPORES }
