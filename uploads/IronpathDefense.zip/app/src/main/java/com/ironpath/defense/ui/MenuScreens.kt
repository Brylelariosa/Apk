package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.ironpath.defense.core.Difficulty
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import com.ironpath.defense.map.MapRegistry
import com.ironpath.defense.render.ArtKit
import com.ironpath.defense.render.TerrainPainter
import com.ironpath.defense.render.TowerArt
import com.ironpath.defense.save.Achievements
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Every full-screen menu: main menu, map select, towers/trophies codex, settings, pause and the end screens. */
class MenuScreens(private val kit: UiKit, private val layout: UiLayout, private val previews: TerrainPainter) {
    private val a = RectF()
    private val b = RectF()
    private val wrapA = WrapCache()
    private val wrapB = WrapCache()
    private val wrapC = WrapCache()
    private val aimTarget = Vector2()
    private val codexTowers = HashMap<Int, Tower>()

    private fun header(c: Canvas, title: String, top: Float, left: Float) {
        a.set(left, top, left + kit.dp(44f), top + kit.dp(40f))
        kit.iconButton(c, a, UiId.BACK, UiKit.ICON_BACK, UiKit.SECONDARY)
        kit.textMid(c, title, left + kit.dp(56f), top + kit.dp(20f), 20f, Palette.TEXT, Paint.Align.LEFT, true, true)
    }

    private fun scrim(c: Canvas, alpha: Int) {
        kit.rect(c, 0f, 0f, layout.screenWidth, layout.screenHeight, (alpha shl 24))
    }

    // =====================================================================
    // MAIN MENU
    // =====================================================================
    fun mainMenu(c: Canvas, state: HudState) {
        val w = layout.screenWidth
        val h = layout.screenHeight
        val m = kit.dp(14f)
        scrim(c, 0x88)
        val cx = w / 2f
        val leftX = layout.safeLeft + kit.dp(26f)
        val leftW = cx - leftX - kit.dp(8f)
        val t = state.time
        // title block
        val pulse = 0.5f + 0.5f * sin(t * 1.6f)
        kit.glow(c, leftX + leftW * 0.4f, h * 0.2f, kit.dp(110f), Palette.ORANGE, 0.10f + 0.06f * pulse)
        kit.text(c, "IRONPATH", leftX, h * 0.175f, 46f, 0xFFF4E9D2.toInt(), Paint.Align.LEFT, true, true)
        kit.text(c, "DEFENSE", leftX + kit.dp(3f), h * 0.175f + kit.dp(36f), 30f, Palette.ORANGE, Paint.Align.LEFT, true, true)
        for (i in 0 until 3) {
            val x = leftX + kit.dp(4f) + i * kit.dp(22f)
            kit.stroke(c, x, h * 0.175f + kit.dp(46f), x + kit.dp(14f), h * 0.175f + kit.dp(46f), Palette.ORANGE, 3f)
        }
        // selected map card
        val map = MapRegistry.get(state.data.selectedMap)
        val pw = leftW.coerceAtMost(kit.dp(330f))
        val ph = pw * 11f / 20f
        val py = h - kit.dp(18f) - layout.insets.bottom - ph - kit.dp(26f)
        a.set(leftX, py, leftX + pw, py + ph)
        previews.drawPreview(c, map, a.left, a.top, pw, ph, true)
        kit.panel(c, a, 10f, 0, Palette.EDGE_BRIGHT, 2f)
        kit.textMid(c, map.displayName, leftX + kit.dp(4f), py + ph + kit.dp(13f), 14f, Palette.TEXT, Paint.Align.LEFT, true, true)
        val best = state.data.mapBestWave[map.id]
        kit.textMid(c, "Best wave $best/${map.waveCount}", leftX + pw - kit.dp(4f), py + ph + kit.dp(13f), 11.5f, Palette.TEXT_DIM, Paint.Align.RIGHT, false)
        // buttons
        val bw = kit.dp(230f).coerceAtMost((layout.safeRight - cx) - m * 2f)
        val bx = cx + ((layout.safeRight - cx) - bw) / 2f
        val total = kit.dp(62f) + 3f * kit.dp(50f) + 3f * kit.dp(10f)
        var y = (h - total) / 2f
        a.set(bx, y, bx + bw, y + kit.dp(62f))
        kit.glow(c, a.centerX(), a.centerY(), bw * 0.7f, Palette.GREEN, 0.14f + 0.1f * pulse)
        kit.button(c, a, UiId.MENU_PLAY, "PLAY", UiKit.PRIMARY, true, 24f)
        y += kit.dp(72f)
        a.set(bx, y, bx + bw, y + kit.dp(50f)); kit.button(c, a, UiId.MENU_MAPS, "MAPS", UiKit.SECONDARY, true, 18f)
        y += kit.dp(60f)
        a.set(bx, y, bx + bw, y + kit.dp(50f)); kit.button(c, a, UiId.MENU_TOWERS, "TOWERS", UiKit.SECONDARY, true, 18f)
        y += kit.dp(60f)
        a.set(bx, y, bx + bw, y + kit.dp(50f)); kit.button(c, a, UiId.MENU_SETTINGS, "SETTINGS", UiKit.SECONDARY, true, 18f)
    }

    // =====================================================================
    // MAP SELECT
    // =====================================================================
    fun mapSelect(c: Canvas, state: HudState) {
        scrim(c, 0xAA)
        val m = kit.dp(10f)
        val left = layout.safeLeft + m
        val right = layout.safeRight - m
        val top = layout.safeTop + m
        header(c, "SELECT MAP", top, left)
        val maps = MapRegistry.all
        val sel = state.data.selectedMap.coerceIn(0, maps.size - 1)
        val map = maps[sel]
        val unlocked = state.isMapUnlocked(sel)
        // thumbnails along the bottom
        val thumbGap = kit.dp(6f)
        val thumbW = minOf(kit.dp(96f), (right - left - thumbGap * (maps.size - 1)) / maps.size)
        val thumbH = thumbW * 0.62f
        val thumbsTop = layout.safeBottom - m - thumbH - kit.dp(14f)
        var x = (layout.screenWidth - (thumbW * maps.size + thumbGap * (maps.size - 1))) / 2f
        for (i in maps.indices) {
            val mp = maps[i]
            a.set(x, thumbsTop, x + thumbW, thumbsTop + thumbH)
            previews.drawPreview(c, mp, a.left, a.top, thumbW, thumbH, false)
            val isSel = i == sel
            val ok = state.isMapUnlocked(i)
            if (!ok) {
                kit.panel(c, a, 8f, 0xAA05080C.toInt(), 0, 0f)
                kit.icon(c, UiKit.ICON_LOCK, a.centerX(), a.centerY(), kit.dp(8f), Palette.TEXT_DIM)
            }
            kit.hitArea(UiId.MAP_BASE + i, a)
            kit.panel(c, a, 8f, 0, if (isSel) Palette.GOLD else Palette.EDGE, if (isSel) 3f else 1.2f)
            kit.textFit(c, mp.displayName, a.centerX(), a.bottom + kit.dp(8f), thumbW, 9.5f, if (isSel) Palette.GOLD else Palette.TEXT_DIM, Paint.Align.CENTER)
            x += thumbW + thumbGap
        }
        // big preview
        val y0 = top + kit.dp(48f)
        val y1 = thumbsTop - kit.dp(12f)
        val contentH = y1 - y0
        val previewH = (contentH - kit.dp(6f)).coerceAtLeast(kit.dp(100f))
        val previewW = (previewH * 20f / 11f).coerceAtMost((right - left) * 0.52f)
        val previewH2 = previewW * 11f / 20f
        a.set(left, y0, left + previewW, y0 + previewH2)
        previews.drawPreview(c, map, a.left, a.top, previewW, previewH2, true)
        kit.panel(c, a, 12f, 0, Palette.EDGE_BRIGHT, 2f)
        if (!unlocked) {
            kit.panel(c, a, 12f, 0x99060A10.toInt(), 0, 0f)
            kit.icon(c, UiKit.ICON_LOCK, a.centerX(), a.centerY() - kit.dp(10f), kit.dp(16f), Palette.TEXT)
            val prev = MapRegistry.get(sel - 1)
            kit.textMid(c, "Reach wave ${MapRegistry.UNLOCK_WAVE} on ${prev.displayName}", a.centerX(), a.centerY() + kit.dp(22f), 12f, Palette.TEXT, Paint.Align.CENTER)
        }
        // info column
        val ix = left + previewW + kit.dp(16f)
        val iw = right - ix
        val fit = (contentH / kit.dp(232f)).coerceIn(0.75f, 1.15f)
        fun sz(v: Float) = v * fit
        var y = y0 + kit.dp(2f) * fit
        kit.textMid(c, map.displayName, ix, y + kit.dp(11f) * fit, sz(20f), map.theme.accent, Paint.Align.LEFT, true, true)
        for (s in 0 until 5) kit.icon(c, UiKit.ICON_STAR, right - kit.dp(10f) - (4 - s) * kit.dp(17f) * fit, y + kit.dp(11f) * fit, kit.dp(6.5f) * fit, if (s < map.stars) Palette.GOLD else 0xFF3A4350.toInt())
        y += kit.dp(26f) * fit
        y = kit.wrapped(c, wrapA, map.blurb, ix, y, iw, sz(11f), Palette.TEXT_DIM, 2) + kit.dp(4f) * fit
        kit.textMid(c, map.mechanicName.uppercase(), ix, y + kit.dp(7f) * fit, sz(11.5f), Palette.GOLD)
        y = kit.wrapped(c, wrapB, map.mechanicText, ix, y + kit.dp(15f) * fit, iw, sz(10.5f), Palette.TEXT, 3) + kit.dp(4f) * fit
        val best = state.data.mapBestWave[map.id]
        val score = state.data.mapBestScore[map.id]
        kit.textMid(c, "Best: wave $best/${map.waveCount}   Score: ${String.format(Locale.US, "%,d", score)}   ${map.waveCount} waves", ix, y + kit.dp(7f) * fit, sz(10.5f), Palette.TEXT_DIM, Paint.Align.LEFT, false)
        y += kit.dp(18f) * fit
        // difficulty chips
        val diffs = Difficulty.entries
        val cw = (iw - kit.dp(8f) * fit * (diffs.size - 1)) / diffs.size
        for (i in diffs.indices) {
            val d = diffs[i]
            val won = state.data.mapWins[map.id] and (1 shl i) != 0
            val hardLocked = d == Difficulty.HARD && state.data.mapWins[map.id] == 0
            a.set(ix + i * (cw + kit.dp(8f) * fit), y, ix + i * (cw + kit.dp(8f) * fit) + cw, y + kit.dp(34f) * fit)
            val selected = state.data.selectedDifficulty == i
            val label = if (hardLocked) "${d.label}" else d.label + (if (won) " \u2713" else "")
            kit.button(c, a, UiId.DIFF_BASE + i, label, if (selected) UiKit.SELECTED else UiKit.SECONDARY, !hardLocked, sz(12f))
            if (hardLocked) kit.icon(c, UiKit.ICON_LOCK, a.right - kit.dp(11f) * fit, a.centerY(), kit.dp(5f) * fit, Palette.TEXT_FAINT)
        }
        y += kit.dp(42f) * fit
        a.set(ix, y, right, minOf(y + kit.dp(46f) * fit, y1 + kit.dp(4f)))
        kit.button(c, a, UiId.MAP_PLAY, if (unlocked) "PLAY" else "LOCKED", if (unlocked) UiKit.PRIMARY else UiKit.DISABLED, unlocked, sz(20f))
    }

    // =====================================================================
    // CODEX: TOWERS + TROPHIES
    // =====================================================================
    fun codex(c: Canvas, state: HudState) {
        scrim(c, 0xB0)
        val m = kit.dp(10f)
        val left = layout.safeLeft + m
        val right = layout.safeRight - m
        val top = layout.safeTop + m
        header(c, if (state.ui.codexTab == 0) "TOWERS" else "TROPHIES", top, left)
        val tabW = kit.dp(96f)
        for (i in 0 until 2) {
            a.set(right - (2 - i) * (tabW + kit.dp(6f)) + kit.dp(6f), top, right - (1 - i) * (tabW + kit.dp(6f)), top + kit.dp(38f))
            kit.button(c, a, UiId.CODEX_TAB_BASE + i, if (i == 0) "Towers" else "Trophies", if (state.ui.codexTab == i) UiKit.SELECTED else UiKit.SECONDARY, true, 13f)
        }
        val y0 = top + kit.dp(48f)
        val y1 = layout.safeBottom - m
        if (state.ui.codexTab == 1) trophies(c, state, left, right, y0, y1) else towers(c, state, left, right, y0, y1)
    }

    private fun trophies(c: Canvas, state: HudState, left: Float, right: Float, y0: Float, y1: Float) {
        val defs = Achievements.all
        var unlocked = 0
        for (d in defs) if (Achievements.isUnlocked(state.data, d)) unlocked++
        kit.textMid(c, "$unlocked / ${defs.size} unlocked", left, y0 + kit.dp(8f), 13f, Palette.TEXT_DIM, Paint.Align.LEFT, false)
        val cols = 2
        val gap = kit.dp(8f)
        val cw = (right - left - gap) / cols
        val rows = (defs.size + cols - 1) / cols
        val ch = minOf(kit.dp(44f), (y1 - y0 - kit.dp(22f) - gap * (rows - 1)) / rows)
        for (i in defs.indices) {
            val d = defs[i]
            val x = left + (i % cols) * (cw + gap)
            val y = y0 + kit.dp(22f) + (i / cols) * (ch + gap)
            val got = Achievements.isUnlocked(state.data, d)
            a.set(x, y, x + cw, y + ch)
            kit.panel(c, a, 9f, if (got) 0xFF2A2A1A.toInt() else Palette.PANEL_SOLID, if (got) Palette.GOLD_DARK else Palette.EDGE, 1.4f)
            kit.icon(c, if (got) UiKit.ICON_STAR else UiKit.ICON_LOCK, x + ch * 0.55f, y + ch / 2f, ch * 0.25f, if (got) Palette.GOLD else Palette.TEXT_FAINT)
            kit.textFit(c, d.title, x + ch * 1.05f, y + ch * 0.32f, cw - ch * 1.2f, 12.5f, if (got) Palette.GOLD else Palette.TEXT_DIM)
            kit.textFit(c, d.description, x + ch * 1.05f, y + ch * 0.72f, cw - ch * 1.2f, 9.5f, Palette.TEXT_FAINT, Paint.Align.LEFT, false)
        }
    }

    private fun previewTower(type: TowerType, build: Int): Tower {
        val key = type.ordinal * 16 + build
        var t = codexTowers[key]
        if (t == null) {
            t = Tower(type, Vector2(0f, 0f))
            val tiers = UiState.PREVIEW_BUILDS[build]
            t.setPreviewTiers(tiers[0], tiers[1], tiers[2])
            t.buildTimer = 0f
            codexTowers[key] = t
        }
        return t
    }

    private fun towers(c: Canvas, state: HudState, left: Float, right: Float, y0: Float, y1: Float) {
        val types = TowerType.entries
        val ui = state.ui
        val sel = ui.codexTower.coerceIn(0, types.size - 1)
        val type = types[sel]
        // left list
        val listW = kit.dp(118f)
        val rowH = minOf(kit.dp(44f), (y1 - y0) / types.size - kit.dp(4f))
        for (i in types.indices) {
            val t = types[i]
            a.set(left, y0 + i * (rowH + kit.dp(4f)), left + listW, y0 + i * (rowH + kit.dp(4f)) + rowH)
            val ok = t.isUnlockedAt(state.data.highestWaveCompleted)
            kit.hitArea(UiId.CODEX_TOWER_BASE + i, a)
            kit.panel(c, a, 9f, if (i == sel) 0xFF263447.toInt() else Palette.PANEL_SOLID, if (i == sel) t.colorArgb else Palette.EDGE, if (i == sel) 2.4f else 1.2f)
            TowerArt.drawIcon(c, t, a.left + rowH * 0.55f, a.centerY(), rowH / 100f, state.time, -40f)
            kit.textFit(c, t.shortName, a.left + rowH * 1.1f, a.centerY() - kit.dp(6f), listW - rowH * 1.2f, 12f, if (ok) Palette.TEXT else Palette.TEXT_FAINT)
            kit.textMid(c, if (ok) "$${t.baseCost}" else "Wave ${t.unlockWave}", a.left + rowH * 1.1f, a.centerY() + kit.dp(8f), 10f, if (ok) Palette.GOLD else Palette.TEXT_FAINT, Paint.Align.LEFT, false)
        }
        // centre stage
        val stageX = left + listW + kit.dp(10f)
        val stageW = kit.dp(250f).coerceAtMost((right - left) * 0.34f)
        val chipsH = kit.dp(60f)
        a.set(stageX, y0, stageX + stageW, y1 - chipsH - kit.dp(6f))
        kit.panel(c, a, 12f, 0xAA0A1017.toInt(), type.colorArgb, 1.6f)
        val tower = previewTower(type, ui.codexBuild.coerceIn(0, UiState.PREVIEW_BUILDS.size - 1))
        val t = state.time
        tower.aimAt(aimTarget.also { it.set(cos(t * 0.7f) * 100f, sin(t * 0.7f) * 100f) })
        val cyc = (t * 1.1f) % 1f
        tower.flashRemaining = if (cyc < 0.12f) 0.09f else 0f
        tower.recoil = if (cyc < 0.25f) 1f - cyc * 4f else 0f
        tower.firingTimer = if (cyc < 0.6f) 0.5f else 0f
        tower.heat = if (cyc < 0.6f) 0.8f else 0f
        c.save()
        c.clipRect(a)
        kit.glow(c, a.centerX(), a.centerY() + kit.dp(6f), minOf(a.width(), a.height()) * 0.5f, tower.accentColorArgb, 0.22f)
        TowerArt.draw(c, tower, a.centerX(), a.centerY() + kit.dp(4f), minOf(a.width(), a.height()) / 62f, t)
        c.restore()
        kit.textMid(c, UpgradeRules.buildCode(tower.pathTiers), a.centerX(), a.top + kit.dp(14f), 14f, Palette.GOLD, Paint.Align.CENTER, true, true)
        if (ui.codexBuild != 0) kit.textMid(c, tower.classTitle, a.centerX(), a.bottom - kit.dp(12f), 11f, tower.accentColorArgb, Paint.Align.CENTER)
        // build chips
        val builds = UiState.PREVIEW_BUILDS
        val chipW = (stageW - kit.dp(4f) * 3f) / 4f
        for (i in builds.indices) {
            val row = i / 4
            val col = i % 4
            a.set(stageX + col * (chipW + kit.dp(4f)), y1 - chipsH + row * (kit.dp(28f) + kit.dp(4f)), stageX + col * (chipW + kit.dp(4f)) + chipW, y1 - chipsH + row * (kit.dp(28f) + kit.dp(4f)) + kit.dp(28f))
            kit.button(c, a, UiId.CODEX_BUILD_BASE + i, if (i == 0) "BASE" else UpgradeRules.buildCode(builds[i]), if (ui.codexBuild == i) UiKit.SELECTED else UiKit.SECONDARY, true, 10.5f)
        }
        // info column
        val ix = stageX + stageW + kit.dp(12f)
        val iw = right - ix
        var y = y0 + kit.dp(2f)
        kit.textMid(c, type.displayName, ix, y + kit.dp(10f), 18f, type.colorArgb, Paint.Align.LEFT, true, true)
        y = kit.wrapped(c, wrapA, type.blurb, ix, y + kit.dp(24f), iw, 11f, Palette.TEXT_DIM, 3) + kit.dp(3f)
        val s = type.baseStats
        kit.textMid(c, "Cost $${type.baseCost}   Damage ${s.damage.toInt()}   Range ${s.range.toInt()}   Rate ${String.format(Locale.US, "%.1f", s.shotsPerSecond)}/s   ${type.element.displayName}", ix, y + kit.dp(7f), 10.5f, Palette.TEXT, Paint.Align.LEFT, false)
        y += kit.dp(18f)
        val tiers = tower.pathTiers
        for (p in 0 until 3) {
            val path = type.paths[p]
            val tier = tiers[p]
            a.set(ix, y, right, y + kit.dp(40f))
            kit.panel(c, a, 8f, Palette.PANEL_SOLID, if (tier > 0) path.colorArgb else Palette.EDGE, 1.2f)
            kit.rect(c, a.left + 2f, a.top + kit.dp(6f), a.left + kit.dp(5f), a.bottom - kit.dp(6f), path.colorArgb)
            kit.textFit(c, path.name, a.left + kit.dp(12f), a.top + kit.dp(11f), iw * 0.42f, 12f, path.colorArgb)
            kit.textFit(c, if (tier > 0) "T$tier  ${path.upgrades[tier - 1].name}" else path.tagline, a.left + kit.dp(12f), a.top + kit.dp(28f), iw - kit.dp(20f), 10f, if (tier > 0) Palette.TEXT else Palette.TEXT_DIM, Paint.Align.LEFT, tier > 0)
            val role = if (tiers[p] > 2) "MAIN" else if (tiers[p] > 0 && UpgradeRules.mainPath(tiers) >= 0) "CROSS" else ""
            if (role.isNotEmpty()) kit.textMid(c, role, a.right - kit.dp(8f), a.top + kit.dp(11f), 9.5f, if (role == "MAIN") Palette.GOLD else Palette.CYAN, Paint.Align.RIGHT)
            y += kit.dp(44f)
        }
        val fusion = tower.fusion
        if (fusion != null) {
            kit.textMid(c, "FUSION: ${fusion.name}", ix, y + kit.dp(6f), 11.5f, Palette.GOLD)
            kit.wrapped(c, wrapC, fusion.description, ix, y + kit.dp(14f), iw, 10f, Palette.TEXT_DIM, 2)
        } else if (ui.codexBuild == 0) {
            kit.wrapped(c, wrapC, "Pick a build below to see how the tower's appearance and abilities change with its upgrades.", ix, y + kit.dp(2f), iw, 10f, Palette.TEXT_FAINT, 3)
        }
    }

    // =====================================================================
    // SETTINGS
    // =====================================================================
    fun settings(c: Canvas, state: HudState) {
        scrim(c, 0xCC)
        val s = state.settings
        val pw = minOf(kit.dp(620f), layout.safeRight - layout.safeLeft - kit.dp(24f))
        val ph = kit.dp(266f)
        val x0 = layout.screenWidth / 2f - pw / 2f
        val y0 = layout.screenHeight / 2f - ph / 2f
        a.set(x0, y0, x0 + pw, y0 + ph)
        kit.panel(c, a, 16f, Palette.PANEL_SOLID, Palette.EDGE_BRIGHT, 2f)
        kit.textMid(c, "SETTINGS", x0 + pw / 2f, y0 + kit.dp(22f), 20f, Palette.TEXT, Paint.Align.CENTER, true, true)
        val colW = (pw - kit.dp(48f)) / 2f
        val lx = x0 + kit.dp(16f)
        val rx = lx + colW + kit.dp(16f)
        var y = y0 + kit.dp(46f)
        kit.textMid(c, "AUDIO", lx, y + kit.dp(6f), 11f, Palette.GOLD)
        kit.textMid(c, "GAME", rx, y + kit.dp(6f), 11f, Palette.GOLD)
        y += kit.dp(18f)
        stepper(c, lx, y, colW, "Master volume", s.masterVolume, 0)
        stepper(c, lx, y + kit.dp(46f), colW, "Sound effects", s.sfxVolume, 1)
        if (s.hasMusic) stepper(c, lx, y + kit.dp(92f), colW, "Music", s.musicVolume, 2)
        else kit.textMid(c, "Music: no track installed", lx, y + kit.dp(112f), 11f, Palette.TEXT_FAINT, Paint.Align.LEFT, false)
        a.set(rx, y, rx + colW, y + kit.dp(38f))
        kit.button(c, a, UiId.SET_QUALITY, "Graphics: ${s.quality.label}", UiKit.SECONDARY, true, 13f)
        toggle(c, rx, y + kit.dp(46f), colW, "Damage numbers", s.showDamageNumbers, 0)
        toggle(c, rx, y + kit.dp(92f), colW, "Screen shake", s.screenShake, 1)
        toggle(c, rx, y + kit.dp(138f), colW, "Auto-start waves", s.autoStart, 2)
        a.set(x0 + pw / 2f - kit.dp(80f), y0 + ph - kit.dp(50f), x0 + pw / 2f + kit.dp(80f), y0 + ph - kit.dp(10f))
        kit.button(c, a, UiId.BACK, "DONE", UiKit.PRIMARY, true, 15f)
    }

    private fun stepper(c: Canvas, x: Float, y: Float, w: Float, label: String, value: Int, which: Int) {
        kit.textMid(c, label, x, y + kit.dp(5f), 11.5f, Palette.TEXT_DIM, Paint.Align.LEFT, false)
        val bs = kit.dp(32f)
        a.set(x, y + kit.dp(9f), x + bs, y + kit.dp(9f) + bs)
        kit.iconButton(c, a, UiId.SET_VOL_BASE + which, UiKit.ICON_MINUS, UiKit.SECONDARY)
        a.set(x + w - bs, y + kit.dp(9f), x + w, y + kit.dp(9f) + bs)
        kit.iconButton(c, a, UiId.SET_VOL_BASE + 3 + which, UiKit.ICON_PLUS, UiKit.SECONDARY)
        val bx0 = x + bs + kit.dp(8f)
        val bx1 = x + w - bs - kit.dp(8f)
        val seg = (bx1 - bx0) / 10f
        for (i in 0 until 10) {
            b.set(bx0 + i * seg + 1.5f, y + kit.dp(14f), bx0 + (i + 1) * seg - 1.5f, y + kit.dp(36f))
            kit.panel(c, b, 3f, if (i < value) Palette.GREEN else 0xFF1B222C.toInt(), if (i < value) 0xFF2E9A4D.toInt() else Palette.EDGE, 1f)
        }
    }

    private fun toggle(c: Canvas, x: Float, y: Float, w: Float, label: String, on: Boolean, which: Int) {
        a.set(x, y, x + w, y + kit.dp(38f))
        kit.panel(c, a, 9f, Palette.PANEL_LIGHT, Palette.EDGE, 1.2f)
        kit.textMid(c, label, x + kit.dp(10f), y + kit.dp(19f), 12.5f, Palette.TEXT, Paint.Align.LEFT)
        b.set(x + w - kit.dp(70f), y + kit.dp(5f), x + w - kit.dp(5f), y + kit.dp(33f))
        kit.button(c, b, UiId.SET_TOGGLE_BASE + which, if (on) "ON" else "OFF", if (on) UiKit.PRIMARY else UiKit.DISABLED, true, 12f)
        a.set(x, y, x + w, y + kit.dp(38f))
        kit.hitArea(UiId.SET_TOGGLE_BASE + which, a)
    }

    // =====================================================================
    // PAUSE
    // =====================================================================
    fun pause(c: Canvas, state: HudState) {
        val run = state.run ?: return
        scrim(c, 0xAA)
        val pw = kit.dp(320f)
        val ph = kit.dp(290f)
        val x0 = layout.screenWidth / 2f - pw / 2f
        val y0 = layout.screenHeight / 2f - ph / 2f
        a.set(x0, y0, x0 + pw, y0 + ph)
        kit.panel(c, a, 16f, Palette.PANEL_SOLID, Palette.EDGE_BRIGHT, 2f)
        kit.textMid(c, "PAUSED", x0 + pw / 2f, y0 + kit.dp(24f), 24f, Palette.TEXT, Paint.Align.CENTER, true, true)
        kit.textMid(c, "${run.map.displayName}  \u2022  ${run.difficulty.label}", x0 + pw / 2f, y0 + kit.dp(46f), 11.5f, Palette.TEXT_DIM, Paint.Align.CENTER, false)
        kit.textMid(c, "Wave ${run.currentWaveNumber}/${run.waves.totalWaveCount}   Director: ${run.director.mood.label}", x0 + pw / 2f, y0 + kit.dp(62f), 11f, Palette.TEXT_FAINT, Paint.Align.CENTER, false)
        val bw = pw - kit.dp(48f)
        var y = y0 + kit.dp(76f)
        a.set(x0 + kit.dp(24f), y, x0 + kit.dp(24f) + bw, y + kit.dp(48f)); kit.button(c, a, UiId.PAUSE_RESUME, "RESUME", UiKit.PRIMARY, true, 17f)
        y += kit.dp(56f)
        a.set(x0 + kit.dp(24f), y, x0 + kit.dp(24f) + bw, y + kit.dp(42f)); kit.button(c, a, UiId.PAUSE_SETTINGS, "Settings", UiKit.SECONDARY, true, 14f)
        y += kit.dp(50f)
        a.set(x0 + kit.dp(24f), y, x0 + kit.dp(24f) + bw, y + kit.dp(42f)); kit.button(c, a, UiId.PAUSE_RESTART, "Restart", UiKit.SECONDARY, true, 14f)
        y += kit.dp(50f)
        a.set(x0 + kit.dp(24f), y, x0 + kit.dp(24f) + bw, y + kit.dp(42f)); kit.button(c, a, UiId.PAUSE_EXIT, "Exit to Map", UiKit.DANGER, true, 14f)
    }

    // =====================================================================
    // VICTORY / DEFEAT
    // =====================================================================
    fun end(c: Canvas, state: HudState) {
        val sum = state.summary ?: return
        scrim(c, 0xB8)
        val t = state.time
        val pw = minOf(kit.dp(600f), layout.safeRight - layout.safeLeft - kit.dp(20f))
        val ph = kit.dp(300f)
        val x0 = layout.screenWidth / 2f - pw / 2f
        val y0 = layout.screenHeight / 2f - ph / 2f
        val accent = if (sum.victory) Palette.GOLD else Palette.RED
        if (sum.victory) confetti(c, t)
        a.set(x0, y0, x0 + pw, y0 + ph)
        kit.glow(c, a.centerX(), a.centerY(), pw * 0.5f, accent, 0.10f)
        kit.panel(c, a, 18f, Palette.PANEL_SOLID, accent, 2.6f)
        val pop = (state.endAge / 0.35f).coerceIn(0f, 1f)
        kit.text(c, if (sum.victory) "VICTORY!" else "DEFEAT", x0 + kit.dp(22f), y0 + kit.dp(46f) , 36f * (0.7f + 0.3f * pop), accent, Paint.Align.LEFT, true, true)
        if (sum.victory) {
            for (s in 0 until 3) {
                val earned = s < sum.stars
                val delay = 0.4f + s * 0.25f
                val k = ((state.endAge - delay) / 0.3f).coerceIn(0f, 1f)
                kit.icon(c, UiKit.ICON_STAR, x0 + kit.dp(30f) + s * kit.dp(34f), y0 + kit.dp(72f), kit.dp(13f) * (0.4f + 0.6f * k), if (earned) Palette.GOLD else 0xFF3A4350.toInt())
            }
        } else {
            kit.textFit(c, sum.reason, x0 + kit.dp(22f), y0 + kit.dp(70f), pw * 0.5f, 12.5f, Palette.TEXT_DIM, Paint.Align.LEFT, false)
        }
        val labelX = x0 + kit.dp(22f)
        val valueX = x0 + pw * 0.52f
        var y = y0 + kit.dp(98f)
        fun row(label: String, value: String, color: Int = Palette.TEXT) {
            kit.textMid(c, label, labelX, y, 12.5f, Palette.TEXT_DIM, Paint.Align.LEFT, false)
            kit.textMid(c, value, valueX, y, 13f, color, Paint.Align.RIGHT)
            y += kit.dp(21f)
        }
        row("Map", "${sum.mapName} (${sum.difficulty.label})")
        row("Wave reached", "${sum.wave} / ${sum.totalWaves}")
        row("Enemies defeated", sum.kills.toString())
        row("Money earned", "$${sum.moneyEarned}", Palette.GOLD)
        row("Base health", "${sum.livesLeft.coerceAtLeast(0)} / ${sum.maxLives}")
        row("Score", String.format(Locale.US, "%,d", sum.score) + if (sum.newBest) "  NEW BEST!" else "", if (sum.newBest) Palette.GOLD else Palette.TEXT)
        // towers used
        var tx = labelX
        val ty = y + kit.dp(14f)
        val types = TowerType.entries
        for (i in types.indices) {
            val n = sum.towersBuilt[i]
            if (n <= 0) continue
            TowerArt.drawIcon(c, types[i], tx + kit.dp(12f), ty, kit.dp(0.25f), t, -40f)
            kit.textMid(c, "x$n", tx + kit.dp(26f), ty, 11f, Palette.TEXT, Paint.Align.LEFT)
            tx += kit.dp(54f)
        }
        // rewards column
        val rx = x0 + pw * 0.58f
        val rw = x0 + pw - kit.dp(20f) - rx
        var ry = y0 + kit.dp(26f)
        if (sum.unlockedMap != null || sum.trophies.isNotEmpty()) {
            kit.textMid(c, "REWARDS", rx, ry, 11.5f, Palette.GOLD)
            ry += kit.dp(16f)
            if (sum.unlockedMap != null) {
                kit.icon(c, UiKit.ICON_LOCK, rx + kit.dp(6f), ry + kit.dp(2f), kit.dp(4.5f), Palette.GREEN)
                kit.textFit(c, "Map unlocked: ${sum.unlockedMap}", rx + kit.dp(16f), ry + kit.dp(2f), rw - kit.dp(16f), 11f, Palette.GREEN)
                ry += kit.dp(16f)
            }
            for (name in sum.trophies) {
                kit.icon(c, UiKit.ICON_STAR, rx + kit.dp(6f), ry + kit.dp(2f), kit.dp(5f), Palette.GOLD)
                kit.textFit(c, "Trophy: $name", rx + kit.dp(16f), ry + kit.dp(2f), rw - kit.dp(16f), 11f, Palette.GOLD)
                ry += kit.dp(16f)
            }
        }
        val bw = x0 + pw - kit.dp(20f) - rx
        a.set(rx, y0 + ph - kit.dp(108f), rx + bw, y0 + ph - kit.dp(60f))
        kit.button(c, a, UiId.END_SECONDARY, if (sum.victory) "Replay" else "Retry", if (sum.victory) UiKit.SECONDARY else UiKit.PRIMARY, true, 16f)
        a.set(rx, y0 + ph - kit.dp(52f), rx + bw, y0 + ph - kit.dp(12f))
        kit.button(c, a, UiId.END_PRIMARY, if (sum.victory) "Continue" else "Return to Map", if (sum.victory) UiKit.PRIMARY else UiKit.SECONDARY, true, 15f)
    }

    private fun confetti(c: Canvas, t: Float) {
        val w = layout.screenWidth
        val h = layout.screenHeight
        val colors = intArrayOf(0xFFFFD35A.toInt(), 0xFFFF6A6A.toInt(), 0xFF6AD8FF.toInt(), 0xFF7CF29A.toInt(), 0xFFD38CFF.toInt())
        for (i in 0 until 60) {
            val x = ((ArtKit.hash(i * 3) * w) + sin(t * 1.5f + i) * 24f)
            val y = ((ArtKit.hash(i * 3 + 1) * h * 1.2f + t * (60f + ArtKit.hash(i) * 90f)) % (h + 40f)) - 20f
            c.save()
            c.rotate(t * 160f * (ArtKit.hash(i + 9) - 0.5f) + i * 30f, x, y)
            kit.rect(c, x - kit.dp(3f), y - kit.dp(1.6f), x + kit.dp(3f), y + kit.dp(1.6f), colors[i % colors.size])
            c.restore()
        }
    }
}
