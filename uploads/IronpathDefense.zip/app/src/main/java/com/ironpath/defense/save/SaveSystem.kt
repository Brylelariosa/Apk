package com.ironpath.defense.save

import android.content.Context
import android.content.SharedPreferences

/**
 * Thin wrapper over SharedPreferences. Keys from the first release
 * (`highest_wave_completed`, `show_damage_numbers`, `sfx_on`, `music_on`) keep
 * their meaning so existing players do not lose progress.
 */
class SaveSystem(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): SaveData {
        val d = SaveData()
        d.highestWaveCompleted = prefs.getInt(KEY_HIGHEST_WAVE, 0)
        d.showDamageNumbers = prefs.getBoolean(KEY_DAMAGE_NUMBERS, true)
        d.selectedMap = prefs.getInt("selected_map", 0)
        d.selectedDifficulty = prefs.getInt("selected_diff", 1)
        d.achievements = prefs.getLong("ach_bits", 0L)
        d.totalKills = prefs.getInt("stat_kills", 0)
        d.bossKills = prefs.getInt("stat_bosses", 0)
        d.wavesCleared = prefs.getInt("stat_waves", 0)
        d.towersBuilt = prefs.getInt("stat_towers", 0)
        d.fusionsBuilt = prefs.getInt("stat_fusions", 0)
        d.steamBursts = prefs.getInt("stat_steam", 0)
        d.gamesPlayed = prefs.getInt("stat_games", 0)
        d.flawlessWins = prefs.getInt("stat_flawless", 0)
        for (i in 0 until SaveData.SLOTS) {
            d.mapBestWave[i] = prefs.getInt("map_best_$i", 0)
            d.mapWins[i] = prefs.getInt("map_wins_$i", 0)
            d.mapBestScore[i] = prefs.getInt("map_score_$i", 0)
        }
        // The first release only had on/off switches; migrate them to volume levels once.
        val legacySfxOn = prefs.getBoolean(KEY_SFX_ON, true)
        val legacyMusicOn = prefs.getBoolean(KEY_MUSIC_ON, true)
        d.masterVolume = prefs.getInt("vol_master", 8)
        d.sfxVolume = prefs.getInt("vol_sfx", if (legacySfxOn) 8 else 0)
        d.musicVolume = prefs.getInt("vol_music", if (legacyMusicOn) 6 else 0)
        d.qualityOrdinal = prefs.getInt("quality", -1)
        d.screenShake = prefs.getBoolean("screen_shake", true)
        d.autoStart = prefs.getBoolean("auto_start", false)
        return d
    }

    fun save(data: SaveData) = write(data, sync = false)
    fun saveNow(data: SaveData) = write(data, sync = true)

    private fun write(d: SaveData, sync: Boolean) {
        val e = prefs.edit()
            .putInt(KEY_HIGHEST_WAVE, d.highestWaveCompleted)
            .putBoolean(KEY_DAMAGE_NUMBERS, d.showDamageNumbers)
            .putBoolean(KEY_SFX_ON, d.sfxVolume > 0)
            .putBoolean(KEY_MUSIC_ON, d.musicVolume > 0)
            .putInt("selected_map", d.selectedMap)
            .putInt("selected_diff", d.selectedDifficulty)
            .putLong("ach_bits", d.achievements)
            .putInt("stat_kills", d.totalKills)
            .putInt("stat_bosses", d.bossKills)
            .putInt("stat_waves", d.wavesCleared)
            .putInt("stat_towers", d.towersBuilt)
            .putInt("stat_fusions", d.fusionsBuilt)
            .putInt("stat_steam", d.steamBursts)
            .putInt("stat_games", d.gamesPlayed)
            .putInt("stat_flawless", d.flawlessWins)
            .putInt("vol_master", d.masterVolume)
            .putInt("vol_sfx", d.sfxVolume)
            .putInt("vol_music", d.musicVolume)
            .putInt("quality", d.qualityOrdinal)
            .putBoolean("screen_shake", d.screenShake)
            .putBoolean("auto_start", d.autoStart)
        for (i in 0 until SaveData.SLOTS) {
            e.putInt("map_best_$i", d.mapBestWave[i])
            e.putInt("map_wins_$i", d.mapWins[i])
            e.putInt("map_score_$i", d.mapBestScore[i])
        }
        if (sync) e.commit() else e.apply()
    }

    companion object {
        private const val PREFS_NAME = "ironpath_save"
        private const val KEY_HIGHEST_WAVE = "highest_wave_completed"
        private const val KEY_MUSIC_ON = "music_on"
        private const val KEY_SFX_ON = "sfx_on"
        private const val KEY_DAMAGE_NUMBERS = "show_damage_numbers"
    }
}
