package com.ironpath.defense.ui

import android.graphics.RectF

/** Button identifiers. Ranges (BASE + n) are used for lists of similar buttons. */
object UiId {
    const val NONE = -1
    const val MENU_PLAY = 1
    const val MENU_MAPS = 2
    const val MENU_TOWERS = 3
    const val MENU_SETTINGS = 4
    const val BACK = 5
    const val BLOCK = 7
    const val PAUSE = 10
    const val PAUSE_RESUME = 11
    const val PAUSE_SETTINGS = 12
    const val PAUSE_RESTART = 13
    const val PAUSE_EXIT = 14
    const val SPEED = 20
    const val START_WAVE = 21
    const val ABILITY_BASE = 30
    const val SHOP_BASE = 40
    const val PATH_BASE = 60
    const val BUY = 63
    const val SELL = 64
    const val TARGET = 65
    const val CLOSE_PANEL = 66
    const val SET_VOL_BASE = 80      // +0..2 minus, +3..5 plus (master, sfx, music)
    const val SET_QUALITY = 90
    const val SET_TOGGLE_BASE = 91   // +0 numbers, +1 shake, +2 auto-start
    const val MAP_BASE = 100
    const val DIFF_BASE = 120
    const val MAP_PLAY = 125
    const val CODEX_TOWER_BASE = 140
    const val CODEX_BUILD_BASE = 160
    const val CODEX_TAB_BASE = 170
    const val END_PRIMARY = 180
    const val END_SECONDARY = 181
}

/**
 * Hit regions registered by the screens as they draw each frame. Input is
 * resolved against the regions from the most recently drawn frame, topmost
 * (last registered) first.
 */
class ButtonRegistry {
    private val left = FloatArray(MAX)
    private val top = FloatArray(MAX)
    private val right = FloatArray(MAX)
    private val bottom = FloatArray(MAX)
    private val ids = IntArray(MAX)
    private var count = 0

    fun clear() {
        count = 0
    }

    fun add(id: Int, r: RectF) {
        if (count >= MAX) return
        left[count] = r.left
        top[count] = r.top
        right[count] = r.right
        bottom[count] = r.bottom
        ids[count] = id
        count++
    }

    fun hit(x: Float, y: Float): Int {
        var i = count - 1
        while (i >= 0) {
            if (x >= left[i] && x <= right[i] && y >= top[i] && y <= bottom[i]) return ids[i]
            i--
        }
        return UiId.NONE
    }

    private companion object {
        const val MAX = 160
    }
}
