package com.ironpath.defense.map

/**
 * Every playable map. Each has its own path layout, obstacles, high ground,
 * theme and rule — they are strategically different, not recolors.
 * A map unlocks when the previous one has reached [UNLOCK_WAVE].
 */
object MapRegistry {
    const val UNLOCK_WAVE = 10

    val all: List<GameMap> = listOf(
        GameMap(
            id = 0, displayName = "Ironpath Valley", theme = MapTheme.FOREST, mechanic = MapMechanic.NONE,
            stars = 1, waveCount = 20,
            blurb = "A winding forest road with long sightlines and tight elbows.",
            mechanicName = "Highland Clearings",
            mechanicText = "Ancient trees block building, but hilltops grant +18% tower range.",
            tileWaypoints = listOf(-1 to 8, 4 to 8, 4 to 3, 9 to 3, 9 to 8, 14 to 8, 14 to 2, 20 to 2),
            blockers = listOf(
                1 to 4, 2 to 4, 6 to 6, 7 to 6, 7 to 5, 11 to 5, 12 to 5, 12 to 6, 16 to 5, 17 to 5, 17 to 6,
                2 to 0, 3 to 0, 3 to 1, 11 to 0, 12 to 0, 18 to 9, 17 to 9, 18 to 10, 1 to 10, 2 to 10
            ),
            highGround = listOf(6 to 4, 7 to 7, 11 to 4, 12 to 7, 16 to 4, 2 to 7)
        ),
        GameMap(
            id = 1, displayName = "Scorched Dunes", theme = MapTheme.DESERT, mechanic = MapMechanic.SANDSTORM,
            stars = 2, waveCount = 20,
            blurb = "Long straight lanes turn the kill-corridors into a gauntlet.",
            mechanicName = "Sandstorms",
            mechanicText = "Telegraphed sandstorms cut every tower's range by 28% for several seconds.",
            tileWaypoints = listOf(-1 to 2, 16 to 2, 16 to 5, 3 to 5, 3 to 8, 20 to 8),
            blockers = listOf(
                6 to 3, 13 to 4, 9 to 4, 8 to 0, 9 to 0, 1 to 0, 18 to 1, 18 to 3,
                14 to 6, 15 to 7, 6 to 7, 11 to 9, 12 to 10, 17 to 10, 0 to 6, 1 to 7
            ),
            highGround = listOf(8 to 3, 4 to 7, 12 to 6, 15 to 4)
        ),
        GameMap(
            id = 2, displayName = "Frostfall Pass", theme = MapTheme.SNOW, mechanic = MapMechanic.ICE,
            stars = 3, waveCount = 25,
            blurb = "Hairpin switchbacks carved through a glacier.",
            mechanicName = "Black Ice",
            mechanicText = "Enemies slide 35% faster across icy stretches. Slow them before the ice.",
            tileWaypoints = listOf(-1 to 1, 5 to 1, 5 to 4, 1 to 4, 1 to 7, 8 to 7, 8 to 2, 13 to 2, 13 to 9, 17 to 9, 17 to 5, 20 to 5),
            blockers = listOf(
                2 to 2, 3 to 2, 7 to 0, 8 to 0, 10 to 4, 11 to 5, 15 to 2, 16 to 2, 15 to 6,
                19 to 8, 18 to 8, 4 to 9, 5 to 9, 10 to 8, 19 to 0, 0 to 9
            ),
            highGround = listOf(3 to 5, 10 to 3, 6 to 5, 15 to 8),
            slickSegments = setOf(0, 4, 7)
        ),
        GameMap(
            id = 3, displayName = "Cinder Caldera", theme = MapTheme.VOLCANO, mechanic = MapMechanic.LAVA,
            stars = 3, waveCount = 25,
            blurb = "The road spirals inward toward your base at the heart of the crater.",
            mechanicName = "Lava Surges",
            mechanicText = "Lava floods the road for a few seconds: it burns enemies but scorches nearby towers.",
            tileWaypoints = listOf(-1 to 9, 17 to 9, 17 to 1, 3 to 1, 3 to 7, 13 to 7, 13 to 4, 8 to 4),
            blockers = listOf(
                1 to 3, 1 to 4, 0 to 4, 5 to 2, 6 to 2, 5 to 3, 6 to 3, 10 to 2, 15 to 3, 15 to 4,
                19 to 5, 19 to 6, 18 to 7, 6 to 8, 11 to 8, 1 to 8
            ),
            highGround = listOf(9 to 5, 11 to 5, 7 to 3, 15 to 6)
        ),
        GameMap(
            id = 4, displayName = "Sunken Ruins", theme = MapTheme.RUINS, mechanic = MapMechanic.RUNES,
            stars = 3, waveCount = 25,
            blurb = "Crumbling temple grounds guarded by ancient rune pedestals.",
            mechanicName = "Rune Pedestals",
            mechanicText = "Tap a glowing pedestal to unleash a stunning rune burst. Each recharges on its own.",
            tileWaypoints = listOf(-1 to 5, 6 to 5, 6 to 1, 11 to 1, 11 to 9, 16 to 9, 16 to 4, 20 to 4),
            blockers = listOf(
                1 to 7, 2 to 7, 8 to 7, 9 to 7, 8 to 8, 13 to 2, 14 to 2, 14 to 3, 18 to 7, 18 to 8,
                3 to 8, 4 to 8, 1 to 1, 2 to 1, 1 to 2, 8 to 5, 9 to 5, 14 to 7
            ),
            highGround = listOf(4 to 6, 9 to 3, 13 to 5, 14 to 8),
            specialTiles = listOf(8 to 3, 13 to 6, 3 to 3)
        ),
        GameMap(
            id = 5, displayName = "Neon Quarter", theme = MapTheme.CITY, mechanic = MapMechanic.GRID_SURGE,
            stars = 4, waveCount = 30,
            blurb = "Right-angle city blocks with rooftop firing positions.",
            mechanicName = "Grid Surge",
            mechanicText = "Power pylons surge in turn, overclocking every tower in their field by 35%.",
            tileWaypoints = listOf(-1 to 2, 3 to 2, 3 to 6, 7 to 6, 7 to 2, 11 to 2, 11 to 8, 15 to 8, 15 to 3, 18 to 3, 18 to 9, 20 to 9),
            blockers = listOf(
                1 to 4, 1 to 5, 5 to 0, 6 to 0, 13 to 0, 14 to 0, 9 to 8, 9 to 9, 8 to 9, 5 to 8, 5 to 9, 6 to 9,
                1 to 8, 2 to 8, 13 to 10, 14 to 10, 17 to 6, 17 to 7, 19 to 5, 19 to 6, 9 to 0, 10 to 0, 0 to 0
            ),
            highGround = listOf(2 to 4, 8 to 4, 12 to 6, 16 to 5),
            specialTiles = listOf(5 to 4, 9 to 5, 13 to 5)
        ),
        GameMap(
            id = 6, displayName = "Gearworks", theme = MapTheme.FACTORY, mechanic = MapMechanic.FACTORY,
            stars = 4, waveCount = 30,
            blurb = "A serpentine assembly line with two-row killing lanes.",
            mechanicName = "Active Machinery",
            mechanicText = "Hydraulic presses slam the line, stunning enemies. Conveyors periodically surge forward.",
            tileWaypoints = listOf(-1 to 1, 17 to 1, 17 to 4, 2 to 4, 2 to 7, 17 to 7, 17 to 9, 20 to 9),
            blockers = listOf(
                5 to 2, 12 to 2, 9 to 3, 15 to 3, 7 to 5, 14 to 6, 10 to 6, 4 to 5, 4 to 9, 5 to 9, 9 to 9, 10 to 9,
                13 to 9, 14 to 9, 1 to 9, 0 to 3, 1 to 3, 19 to 3, 19 to 4, 0 to 5, 0 to 6, 19 to 6
            ),
            highGround = listOf(3 to 2, 8 to 2, 13 to 5, 8 to 8, 16 to 6),
            slickSegments = setOf(0, 2, 4),
            specialTiles = listOf(7 to 1, 10 to 4, 7 to 7)
        ),
        GameMap(
            id = 7, displayName = "Xenon Reach", theme = MapTheme.ALIEN, mechanic = MapMechanic.SPORES,
            stars = 5, waveCount = 30,
            blurb = "An organic maze that doubles back on itself again and again.",
            mechanicName = "Spore Blooms",
            mechanicText = "Drifting spore clouds heal any enemy inside them. Burst them down or avoid the cloud.",
            tileWaypoints = listOf(-1 to 9, 3 to 9, 3 to 6, 1 to 6, 1 to 3, 6 to 3, 6 to 8, 10 to 8, 10 to 1, 14 to 1, 14 to 6, 17 to 6, 17 to 3, 20 to 3),
            blockers = listOf(
                8 to 5, 8 to 6, 9 to 5, 12 to 3, 12 to 4, 12 to 5, 16 to 1, 17 to 1, 18 to 1, 16 to 8, 17 to 8, 18 to 8,
                3 to 1, 4 to 1, 4 to 5, 4 to 6, 8 to 2, 19 to 9, 18 to 10, 13 to 9, 14 to 9, 1 to 8, 0 to 8
            ),
            highGround = listOf(2 to 4, 8 to 3, 12 to 7, 15 to 3)
        )
    )

    fun default(): GameMap = all.first()
    fun get(index: Int): GameMap = all[index.coerceIn(0, all.size - 1)]
}
