package com.ironpath.defense.entity.tower

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.tower.upgrade.CrossPerk
import com.ironpath.defense.entity.tower.upgrade.PathRole
import com.ironpath.defense.entity.tower.upgrade.TowerUpgrade
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * One placed tower. Holds three layers of numbers:
 *  - [stats]: base + upgrades + fusion (what the player bought),
 *  - [effective]: [stats] + live buffs (support aura, synergy links, high ground),
 *  - presentation timers the renderer uses for animation (recoil, evolve, build).
 *
 * Combat always reads [effective]; the upgrade UI previews against it too.
 */
class Tower(val type: TowerType, val position: Vector2) {
    val pathTiers = IntArray(UpgradeRules.PATH_COUNT)

    var stats: TowerStats = type.baseStats
        private set
    var effective: TowerStats = type.baseStats
        private set
    var effectiveVersion = 0
        private set
    var fusion: CrossPerk? = null
        private set
    var totalInvested = type.baseCost
        private set

    // --- combat runtime ---------------------------------------------------
    var cooldownRemaining = 0f
    var pulseCooldownRemaining = 0f
    var targetingMode = TargetingMode.FIRST
    var heat = 0f
    var firingTimer = 0f
    var shotCounter = 0
    var jamTime = 0f
    var overdriveTime = 0f
    var overdriveBonus = 0f

    // --- buffs written by SynergySystem ---------------------------------
    var buffDamage = 0f
    var buffRate = 0f
    var buffRange = 0f
    var heightBonus = 0f
    var steamLinked = false
    var conductive = false
    var incendiary = false
    var frostbite = false
    val synergies = ArrayList<String>(3)

    // --- presentation -------------------------------------------------------
    var flashRemaining = 0f
    var specialFlash = 0f
    var recoil = 0f
    var evolveTimer = 0f
    var evolvedPath = -1
    var buildTimer = BUILD_SECONDS
    val idlePhase: Float = Random.nextFloat() * 6.2831f
    var aimX = 1f
        private set
    var aimY = 0f
        private set

    val sellValue: Int get() = (totalInvested * GameConfig.SELL_REFUND_FRACTION).toInt()
    val totalUpgrades: Int get() = pathTiers.sum()

    /** Index of the path with the highest tier (-1 for an un-upgraded tower). Ties go to the lower index. */
    val dominantPath: Int
        get() {
            var best = -1
            var bestTier = 0
            for (i in pathTiers.indices) {
                if (pathTiers[i] > bestTier) {
                    bestTier = pathTiers[i]
                    best = i
                }
            }
            return best
        }

    /** The path currently acting as the crosspath (used, not the main one), or -1. */
    val crossPath: Int
        get() {
            val main = UpgradeRules.mainPath(pathTiers)
            if (main < 0) return -1
            for (i in pathTiers.indices) if (i != main && pathTiers[i] > 0) return i
            return -1
        }

    val accentColorArgb: Int
        get() {
            val p = dominantPath
            return if (p < 0) type.colorArgb else type.paths[p].colorArgb
        }

    /** Evolved name: the dominant path's current tier name, or the base name. */
    val classTitle: String
        get() {
            val p = dominantPath
            return if (p < 0) type.displayName else type.paths[p].upgrades[pathTiers[p] - 1].name
        }

    fun roleOf(path: Int): PathRole = UpgradeRules.roleOf(pathTiers, path)

    fun nextUpgrade(path: Int): TowerUpgrade? = type.paths[path].upgrades.getOrNull(pathTiers[path])

    fun upgradeAvailability(path: Int): UpgradeAvailability = when {
        nextUpgrade(path) == null -> UpgradeAvailability.MAXED
        UpgradeRules.isLockedByCrosspath(pathTiers, path) -> UpgradeAvailability.LOCKED
        else -> UpgradeAvailability.AVAILABLE
    }

    /** Applies the next tier of [path]. Caller has already validated legality and paid. */
    fun applyUpgrade(path: Int) {
        val upgrade = checkNotNull(nextUpgrade(path)) { "${type.displayName} path $path is already maxed" }
        pathTiers[path]++
        totalInvested += upgrade.cost
        stats = statsFor(pathTiers)
        fusion = perkFor(pathTiers)
        refreshEffective()
        evolveTimer = EVOLVE_SECONDS
        evolvedPath = path
    }

    /** Codex/preview only: jump straight to a build without paying. */
    fun setPreviewTiers(a: Int, b: Int, c: Int) {
        pathTiers[0] = a
        pathTiers[1] = b
        pathTiers[2] = c
        stats = statsFor(pathTiers)
        fusion = perkFor(pathTiers)
        refreshEffective()
    }

    /** The fusion that would be active if [path]'s next tier were bought (null if none or already active). */
    fun fusionAfterUpgrade(path: Int): CrossPerk? {
        if (nextUpgrade(path) == null) return null
        val t = pathTiers.copyOf()
        t[path]++
        val perk = perkFor(t)
        return if (perk != null && perk !== fusion) perk else null
    }

    /** Effective stats as they would be after buying [path]'s next tier (null if maxed). For the diff UI. */
    fun previewAfterUpgrade(path: Int): TowerStats? {
        if (nextUpgrade(path) == null) return null
        val t = pathTiers.copyOf()
        t[path]++
        return buildEffective(statsFor(t))
    }

    fun cycleTargetingMode() {
        val modes = TargetingMode.entries
        targetingMode = modes[(targetingMode.ordinal + 1) % modes.size]
    }

    fun aimAt(target: Vector2) {
        val dx = target.x - position.x
        val dy = target.y - position.y
        val length = sqrt(dx * dx + dy * dy)
        if (length > 0.001f) {
            aimX = dx / length
            aimY = dy / length
        }
    }

    // --- synergy plumbing (called by SynergySystem) ---------------------
    fun clearSynergy() {
        buffDamage = 0f
        buffRate = 0f
        buffRange = 0f
        steamLinked = false
        conductive = false
        incendiary = false
        frostbite = false
        synergies.clear()
    }

    fun addSynergy(name: String) {
        if (!synergies.contains(name)) synergies.add(name)
    }

    fun refreshEffective() {
        effective = buildEffective(stats)
        effectiveVersion++
    }

    private fun buildEffective(base: TowerStats): TowerStats {
        var s = base
        if (buffDamage > 0f) {
            s = s.copy(damage = s.damage * (1f + buffDamage), pulseDamage = s.pulseDamage * (1f + buffDamage))
        }
        if (buffRate > 0f) {
            s = s.copy(
                fireRateSeconds = s.fireRateSeconds / (1f + buffRate),
                pulseIntervalSeconds = if (s.pulseIntervalSeconds > 0f) s.pulseIntervalSeconds / (1f + buffRate) else 0f
            )
        }
        val rangeBonus = buffRange + heightBonus
        if (rangeBonus > 0f) s = s.copy(range = s.range * (1f + rangeBonus))
        if (steamLinked) s = s.copy(steamBurst = STEAM_BASE + STEAM_PER_UPGRADE * totalUpgrades)
        if (conductive) {
            s = when (type) {
                TowerType.LIGHTNING -> s.copy(superconduct = 2, chainRadius = s.chainRadius * 1.2f)
                TowerType.FROST -> s.copy(slowDurationSeconds = s.slowDurationSeconds * 1.25f)
                else -> s
            }
        }
        if (incendiary && s.burnDps < INCENDIARY_BURN) {
            s = s.copy(burnDps = INCENDIARY_BURN, burnSeconds = maxOf(s.burnSeconds, 2.5f))
        }
        if (frostbite && s.slowDurationSeconds <= 0f) {
            s = s.copy(slowMultiplier = 0.8f, slowDurationSeconds = 1.2f)
        }
        return s
    }

    private fun statsFor(tiers: IntArray): TowerStats {
        var result = type.baseStats
        for (path in tiers.indices) {
            for (tier in 0 until tiers[path]) {
                result = type.paths[path].upgrades[tier].applyTo(result)
            }
        }
        val perk = perkFor(tiers)
        if (perk != null) result = perk.applyTo(result)
        return result
    }

    private fun perkFor(tiers: IntArray): CrossPerk? {
        for (p in type.perks) if (tiers[p.main] >= 3 && tiers[p.cross] >= 2) return p
        return null
    }

    companion object {
        const val BUILD_SECONDS = 0.55f
        const val EVOLVE_SECONDS = 0.9f
        private const val STEAM_BASE = 26f
        private const val STEAM_PER_UPGRADE = 9f
        private const val INCENDIARY_BURN = 8f
    }
}
