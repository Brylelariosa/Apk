package com.ironpath.defense.core

/** Run difficulty: changes the starting position and enemy toughness, never the rules. */
enum class Difficulty(
    val label: String,
    val startMoney: Int,
    val lives: Int,
    val healthMult: Float,
    val rewardMult: Float,
    val scoreMult: Float
) {
    EASY("Easy", 500, 25, 0.80f, 1.10f, 0.7f),
    NORMAL("Normal", 400, 20, 1.00f, 1.00f, 1.0f),
    HARD("Hard", 350, 15, 1.30f, 0.92f, 1.6f)
}

/** Graphics quality presets. Everything that can get expensive scales off one of these. */
enum class GraphicsQuality(
    val label: String,
    val particleScale: Float,
    val maxParticles: Int,
    val ambientDensity: Float,
    val glow: Boolean
) {
    LOW("Low", 0.40f, 110, 0.35f, false),
    MEDIUM("Medium", 1.00f, 240, 0.70f, true),
    HIGH("High", 1.50f, 400, 1.00f, true)
}
