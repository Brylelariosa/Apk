package com.ironpath.defense.engine

import android.app.ActivityManager
import android.content.Context
import android.graphics.Canvas
import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.audio.SoundEffect
import com.ironpath.defense.core.Difficulty
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.core.GraphicsQuality
import com.ironpath.defense.core.InputQueue
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.map.MapRegistry
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.render.GameRenderer
import com.ironpath.defense.save.Achievements
import com.ironpath.defense.save.SaveSystem
import com.ironpath.defense.settings.SettingsSystem
import com.ironpath.defense.ui.BannerSystem
import com.ironpath.defense.ui.GameActions
import com.ironpath.defense.ui.HudState
import com.ironpath.defense.ui.InputController
import com.ironpath.defense.ui.UiLayout
import com.ironpath.defense.ui.UiState
import com.ironpath.defense.ui.SafeInsets

/**
 * Composition root and screen state machine. It owns what outlives a single
 * game (save data, audio, settings, particles, UI state) and creates a fresh
 * [GameRun] for every playthrough. All player intent arrives through
 * [GameActions]; the renderer only ever sees [HudState].
 *
 * Simulation (update) and drawing (render) run on the same game thread, so UI
 * animation (banners, fades) is driven by real frame time in [render] and
 * stays smooth at any game speed.
 */
class GameWorld(private val context: Context) : GameActions, RunListener {
    private val saveSystem = SaveSystem(context)
    private val data = saveSystem.load()
    private val audio = AudioSystem(context)
    private val settings = SettingsSystem(audio, data, detectQuality()) { saveSystem.save(data) }
    private val particles = ParticleSystem()
    private val juice = Juice()
    private val effects = CombatEffects(particles, audio, settings, juice)
    private val banners = BannerSystem()
    private val uiState = UiState()
    private val layout = UiLayout()
    private val renderer = GameRenderer(layout)
    private val input = InputController(renderer.kit) { audio.play(SoundEffect.BUTTON_TAP) }
    private val hud = HudState(data, settings, uiState, banners, particles, juice)

    val inputQueue = InputQueue()

    private var screen = GameScreenState.MAIN_MENU
    private var run: GameRun? = null
    private var backdrop = MapSystem(MapRegistry.get(data.selectedMap))
    private var speedIndex = 0
    private var insets = SafeInsets.NONE
    private var animTime = 0f
    private var lastRenderNanos = 0L

    // screen transition (fade out -> switch -> fade in), driven by real time
    private var fadeAlpha = 0f
    private var fadeDir = 0
    private var pendingScreen = GameScreenState.MAIN_MENU
    private var pendingAction: (() -> Unit)? = null

    // per-run bookkeeping for lifetime stats
    private var flushedKills = 0
    private var flushedBosses = 0
    private var flushedFusions = 0
    private var flushedSteam = 0
    private var bestWaveAtStart = 0

    init {
        data.selectedMap = data.selectedMap.coerceIn(0, MapRegistry.all.size - 1)
        if (!isMapUnlocked(data.selectedMap)) data.selectedMap = 0
        data.selectedDifficulty = data.selectedDifficulty.coerceIn(0, Difficulty.entries.size - 1)
        settings.applyToAudio()
        refreshHud()
    }

    val isPlaying: Boolean get() = screen == GameScreenState.PLAYING

    val currentSpeedMultiplier: Float
        get() = if (screen == GameScreenState.PLAYING) GameConfig.SPEED_MULTIPLIERS[speedIndex] else 1f

    private fun detectQuality(): GraphicsQuality {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = am.memoryClass
        return when {
            am.isLowRamDevice || mem <= 128 -> GraphicsQuality.LOW
            mem >= 384 && Runtime.getRuntime().availableProcessors() >= 8 -> GraphicsQuality.HIGH
            else -> GraphicsQuality.MEDIUM
        }
    }

    private fun isMapUnlocked(index: Int): Boolean =
        index <= 0 || data.mapBestWave[(index - 1).coerceIn(0, data.mapBestWave.size - 1)] >= MapRegistry.UNLOCK_WAVE

    // --- surface / lifecycle -------------------------------------------------------
    fun onSurfaceResized(width: Float, height: Float) {
        layout.recompute(width, height, insets)
    }

    fun onSafeInsetsChanged(newInsets: SafeInsets) {
        insets = newInsets
        if (layout.screenWidth > 0f) layout.recompute(layout.screenWidth, layout.screenHeight, newInsets)
    }

    fun pauseForBackground() {
        if (screen == GameScreenState.PLAYING) screen = GameScreenState.PAUSED
        audio.onPause()
    }

    fun onHostResume() {
        audio.onResume()
    }

    fun persistNow() {
        flushStats()
        saveSystem.saveNow(data)
    }

    /** Returns true if the back press was consumed (so the Activity should not close). */
    fun handleBack(): Boolean {
        when (screen) {
            GameScreenState.PLAYING, GameScreenState.PAUSED -> togglePause()
            GameScreenState.SETTINGS -> closeSettings()
            GameScreenState.MAP_SELECT, GameScreenState.CODEX -> goBack()
            GameScreenState.VICTORY, GameScreenState.GAME_OVER -> exitToMaps()
            GameScreenState.MAIN_MENU -> return false
        }
        return true
    }

    // --- frame loop --------------------------------------------------------------
    fun update(dt: Float) {
        for (event in inputQueue.drain()) {
            if (fadeDir != 1) input.handleTap(event, layout, hud, this)
        }
        refreshHud()
        particles.update(dt)
        juice.update(dt)
        val r = run
        if (screen == GameScreenState.PLAYING && r != null) {
            r.autoStartEnabled = settings.autoStart
            r.update(dt)
        }
    }

    fun render(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastRenderNanos == 0L) 0f else ((now - lastRenderNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastRenderNanos = now
        animTime += dt
        banners.update(dt)
        if (screen == GameScreenState.VICTORY || screen == GameScreenState.GAME_OVER) hud.endAge += dt
        advanceFade(dt)
        hud.time = animTime
        hud.fade = fadeAlpha
        renderer.render(canvas, hud)
    }

    private fun advanceFade(dt: Float) {
        when (fadeDir) {
            1 -> {
                fadeAlpha += dt * 6f
                if (fadeAlpha >= 1f) {
                    fadeAlpha = 1f
                    screen = pendingScreen
                    pendingAction?.invoke()
                    pendingAction = null
                    fadeDir = -1
                }
            }
            -1 -> {
                fadeAlpha -= dt * 5f
                if (fadeAlpha <= 0f) {
                    fadeAlpha = 0f
                    fadeDir = 0
                }
            }
        }
    }

    private fun goTo(next: GameScreenState, action: (() -> Unit)? = null) {
        if (fadeDir == 1) return
        pendingScreen = next
        pendingAction = action
        fadeDir = 1
    }

    private fun refreshHud() {
        hud.screen = screen
        hud.run = run
        hud.backdrop = backdrop
        hud.speedIndex = speedIndex
        val q = settings.quality
        hud.quality = q
        particles.maxParticles = q.maxParticles
        particles.scale = q.particleScale
        juice.shakeEnabled = settings.screenShake
    }

    // --- run lifecycle -----------------------------------------------------------
    private fun startRun(mapIndex: Int, difficultyIndex: Int) {
        val map = MapRegistry.get(mapIndex)
        val difficulty = Difficulty.entries[difficultyIndex.coerceIn(0, Difficulty.entries.size - 1)]
        particles.clear()
        banners.clear()
        juice.reset()
        flushedKills = 0
        flushedBosses = 0
        flushedFusions = 0
        flushedSteam = 0
        bestWaveAtStart = data.mapBestWave[map.id]
        val newRun = GameRun(map, difficulty, effects, audio, particles, data, this)
        newRun.autoStartEnabled = settings.autoStart
        run = newRun
        backdrop = newRun.mapSystem
        hud.summary = null
        hud.endAge = 0f
        speedIndex = 0
        data.gamesPlayed++
        screen = GameScreenState.PLAYING
        banners.push(BannerKind.EVENT, map.displayName.uppercase(), "Map rule: ${map.mechanicName}", 0xFFFFD35A.toInt(), 4.5f)
    }

    private fun flushStats() {
        val r = run ?: return
        data.totalKills += r.stats.kills - flushedKills
        data.bossKills += r.stats.bossKills - flushedBosses
        data.steamBursts += r.stats.steamBursts - flushedSteam
        flushedKills = r.stats.kills
        flushedBosses = r.stats.bossKills
        flushedSteam = r.stats.steamBursts
    }

    private fun showTrophies() {
        for (t in Achievements.evaluate(data)) {
            banners.push(BannerKind.TOAST, "TROPHY UNLOCKED", t.title, 0xFFFFD35A.toInt(), 3.2f)
            audio.play(SoundEffect.FUSION, 0.8f)
        }
    }

    // --- RunListener ------------------------------------------------------------
    override fun onBanner(kind: Int, title: String, subtitle: String, colorArgb: Int) {
        val seconds = when (kind) {
            BannerKind.WAVE -> 2.4f
            BannerKind.CLEAR -> 2.6f
            BannerKind.BOSS -> 3.0f
            else -> 3.4f
        }
        banners.push(kind, title, subtitle, colorArgb, seconds)
    }

    override fun onProgress() {
        flushStats()
        showTrophies()
        saveSystem.save(data)
    }

    override fun onRunEnded(victory: Boolean) {
        val r = run ?: return
        flushStats()
        val score = r.score()
        val idx = r.map.id
        val newBest = score > data.mapBestScore[idx]
        if (newBest) data.mapBestScore[idx] = score
        if (victory) {
            data.mapWins[idx] = data.mapWins[idx] or (1 shl r.difficulty.ordinal)
            if (r.stats.livesLost == 0) data.flawlessWins++
        }
        val next = idx + 1
        val unlocked = if (next < MapRegistry.all.size && bestWaveAtStart < MapRegistry.UNLOCK_WAVE &&
            data.mapBestWave[idx] >= MapRegistry.UNLOCK_WAVE) MapRegistry.get(next).displayName else null
        val trophies = ArrayList<String>()
        for (t in Achievements.evaluate(data)) trophies.add(t.title)
        saveSystem.saveNow(data)
        hud.summary = RunSummary(
            victory = victory, mapName = r.map.displayName, difficulty = r.difficulty, wave = r.waves.currentWaveIndex,
            totalWaves = r.waves.totalWaveCount, kills = r.stats.kills, moneyEarned = r.economy.totalEarned,
            towersBuilt = r.stats.towersBuilt.copyOf(), livesLeft = r.lives, maxLives = r.maxLives, score = score,
            stars = r.stars(), reason = if (victory) "" else r.director.defeatReason(), newBest = newBest,
            unlockedMap = unlocked, trophies = trophies
        )
        hud.endAge = 0f
        audio.play(if (victory) SoundEffect.VICTORY else SoundEffect.GAME_OVER)
        screen = if (victory) GameScreenState.VICTORY else GameScreenState.GAME_OVER
    }

    // --- GameActions: navigation -----------------------------------------------------
    override fun playSelected() {
        val idx = data.selectedMap
        if (!isMapUnlocked(idx)) {
            openMaps()
            return
        }
        goTo(GameScreenState.PLAYING) { startRun(data.selectedMap, data.selectedDifficulty) }
    }

    override fun openMaps() = goTo(GameScreenState.MAP_SELECT)

    override fun openCodex() = goTo(GameScreenState.CODEX)

    override fun openSettings() {
        uiState.settingsReturn = if (screen == GameScreenState.PAUSED) GameScreenState.PAUSED else GameScreenState.MAIN_MENU
        screen = GameScreenState.SETTINGS
    }

    override fun closeSettings() {
        screen = uiState.settingsReturn
    }

    override fun goBack() {
        when (screen) {
            GameScreenState.SETTINGS -> closeSettings()
            GameScreenState.MAP_SELECT, GameScreenState.CODEX -> goTo(GameScreenState.MAIN_MENU)
            else -> {}
        }
    }

    override fun selectMap(index: Int) {
        data.selectedMap = index.coerceIn(0, MapRegistry.all.size - 1)
        backdrop = MapSystem(MapRegistry.get(data.selectedMap))
        if (data.selectedDifficulty == Difficulty.HARD.ordinal && data.mapWins[data.selectedMap] == 0) {
            data.selectedDifficulty = Difficulty.NORMAL.ordinal
        }
        saveSystem.save(data)
    }

    override fun selectDifficulty(index: Int) {
        if (index == Difficulty.HARD.ordinal && data.mapWins[data.selectedMap] == 0) return
        data.selectedDifficulty = index.coerceIn(0, Difficulty.entries.size - 1)
        saveSystem.save(data)
    }

    override fun startSelectedMap() {
        if (!isMapUnlocked(data.selectedMap)) return
        goTo(GameScreenState.PLAYING) { startRun(data.selectedMap, data.selectedDifficulty) }
    }

    override fun restartRun() {
        val r = run ?: return
        val map = r.map.id
        val diff = r.difficulty.ordinal
        flushStats()
        goTo(GameScreenState.PLAYING) { startRun(map, diff) }
    }

    override fun exitToMaps() {
        flushStats()
        saveSystem.save(data)
        goTo(GameScreenState.MAP_SELECT) {
            run = null
            particles.clear()
            banners.clear()
        }
    }

    override fun exitToMenu() {
        flushStats()
        saveSystem.save(data)
        goTo(GameScreenState.MAIN_MENU) {
            run = null
            particles.clear()
            banners.clear()
        }
    }

    override fun togglePause() {
        when (screen) {
            GameScreenState.PLAYING -> screen = GameScreenState.PAUSED
            GameScreenState.PAUSED -> screen = GameScreenState.PLAYING
            else -> {}
        }
    }

    // --- GameActions: gameplay ------------------------------------------------------
    override fun startWave() {
        run?.requestStartWave()
    }

    override fun cycleSpeed() {
        if (screen != GameScreenState.PLAYING) return
        speedIndex = (speedIndex + 1) % GameConfig.SPEED_MULTIPLIERS.size
    }

    override fun armTower(type: TowerType) {
        run?.armTower(type)
    }

    override fun worldTap(worldX: Float, worldY: Float) {
        run?.onWorldTap(worldX, worldY)
    }

    override fun selectPath(path: Int) {
        val r = run ?: return
        r.selectedPath = path.coerceIn(0, 2)
        audio.play(SoundEffect.BUTTON_TAP, 0.5f, 1.2f)
    }

    override fun buySelected() {
        val r = run ?: return
        r.upgradeSelected(r.selectedPath)
    }

    override fun sellSelected() {
        run?.sellSelected()
    }

    override fun cycleTargeting() {
        run?.cycleTargeting()
    }

    override fun deselect() {
        run?.deselect()
    }

    override fun useAbility(index: Int) {
        run?.useAbility(index)
    }

    // --- GameActions: settings & codex --------------------------------------------------
    override fun changeVolume(which: Int, delta: Int) {
        when (which) {
            0 -> settings.changeMaster(delta)
            1 -> settings.changeSfx(delta)
            else -> settings.changeMusic(delta)
        }
        audio.play(SoundEffect.BUTTON_TAP)
    }

    override fun cycleQuality() {
        settings.cycleQuality()
    }

    override fun toggleSetting(which: Int) {
        when (which) {
            0 -> settings.toggleDamageNumbers()
            1 -> settings.toggleScreenShake()
            else -> settings.toggleAutoStart()
        }
    }

    override fun codexTab(tab: Int) {
        uiState.codexTab = tab.coerceIn(0, 1)
    }

    override fun codexTower(index: Int) {
        uiState.codexTower = index.coerceIn(0, TowerType.entries.size - 1)
    }

    override fun codexBuild(index: Int) {
        uiState.codexBuild = index.coerceIn(0, UiState.PREVIEW_BUILDS.size - 1)
    }
}
