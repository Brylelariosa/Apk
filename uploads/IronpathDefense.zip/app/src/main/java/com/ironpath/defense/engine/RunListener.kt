package com.ironpath.defense.engine

/** Banner categories understood by the UI's banner system. */
object BannerKind {
    const val WAVE = 0
    const val CLEAR = 1
    const val BOSS = 2
    const val EVENT = 3
    const val TOAST = 4
}

/** What a [GameRun] tells the rest of the game (UI banners, persistence, end-of-run flow). */
interface RunListener {
    fun onBanner(kind: Int, title: String, subtitle: String, colorArgb: Int)
    fun onRunEnded(victory: Boolean)
    fun onProgress()
}
