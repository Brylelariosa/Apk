package com.ironpath.defense.save

/** The trophy list. Each trophy is a pure predicate over the persisted [SaveData] counters. */
object Achievements {
    class Def(val id: Int, val title: String, val description: String, val check: (SaveData) -> Boolean)

    private fun anyWin(d: SaveData): Boolean {
        for (w in d.mapWins) if (w != 0) return true
        return false
    }

    private fun winCount(d: SaveData): Int {
        var n = 0
        for (w in d.mapWins) if (w != 0) n++
        return n
    }

    val all: List<Def> = listOf(
        Def(0, "First Blood", "Defeat your first enemy.") { it.totalKills >= 1 },
        Def(1, "Centurion", "Defeat 100 enemies.") { it.totalKills >= 100 },
        Def(2, "Exterminator", "Defeat 2,000 enemies.") { it.totalKills >= 2000 },
        Def(3, "Defender", "Win your first map.") { anyWin(it) },
        Def(4, "Cartographer", "Win on three different maps.") { winCount(it) >= 3 },
        Def(5, "Hard Earned", "Win a map on Hard difficulty.") { d -> d.mapWins.any { (it and 4) != 0 } },
        Def(6, "Boss Breaker", "Defeat 5 bosses.") { it.bossKills >= 5 },
        Def(7, "Specialist", "Complete a fusion build (main tier 3+ with a tier 2 cross-path).") { it.fusionsBuilt >= 1 },
        Def(8, "Master Builder", "Activate 10 fusion builds.") { it.fusionsBuilt >= 10 },
        Def(9, "Steam Team", "Trigger Steam Burst 25 times (Flame + Frost).") { it.steamBursts >= 25 },
        Def(10, "Untouchable", "Win a map without losing a single life.") { it.flawlessWins >= 1 },
        Def(11, "Wave Rider", "Clear 100 waves in total.") { it.wavesCleared >= 100 }
    )

    /** Unlocks any newly satisfied trophies, sets their bits, and returns them for the toast. */
    fun evaluate(data: SaveData): List<Def> {
        var fresh: ArrayList<Def>? = null
        for (def in all) {
            val bit = 1L shl def.id
            if ((data.achievements and bit) == 0L && def.check(data)) {
                data.achievements = data.achievements or bit
                if (fresh == null) fresh = ArrayList()
                fresh.add(def)
            }
        }
        return fresh ?: emptyList()
    }

    fun isUnlocked(data: SaveData, def: Def): Boolean = (data.achievements and (1L shl def.id)) != 0L
}
