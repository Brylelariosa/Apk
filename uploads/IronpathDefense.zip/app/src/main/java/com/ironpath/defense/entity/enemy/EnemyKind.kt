package com.ironpath.defense.entity.enemy

private fun argb(v: Long): Int = v.toInt()

/**
 * Static archetype data for every enemy type. Each kind has its own silhouette
 * and animation in EnemyArt and, where it has one, its own mechanic in
 * [EnemyAbilities]. [tier] 0 = regular, 1 = mini-boss, 2 = boss.
 */
enum class EnemyKind(
    val displayName: String,
    val baseHealth: Float,
    val baseSpeed: Float,
    val baseReward: Int,
    val armor: Float,
    val radius: Float,
    val colorArgb: Int,
    val tip: String,
    val regenPerSecond: Float = 0f,
    val slowResistance: Float = 0f,
    val baseShield: Float = 0f,
    val leakDamage: Int = 1,
    val tier: Int = 0
) {
    BASIC("Grunt", 40f, 90f, 8, 0f, 18f, argb(0xFFC97B4A), "Average in every way."),
    FAST("Scout", 24f, 170f, 6, 0f, 14f, argb(0xFFE3C23C), "Sprints past short-range towers."),
    ARMORED("Bulwark", 90f, 55f, 14, 8f, 20f, argb(0xFF7C8591), "Armor shrugs off weak hits."),
    SWARM("Skitter", 14f, 100f, 3, 0f, 11f, argb(0xFFB25FA0), "Arrives in huge numbers."),
    REGENERATOR("Mender", 70f, 70f, 16, 2f, 19f, argb(0xFF4CAF7D), "Heals unless kept under fire.", regenPerSecond = 0.04f),
    TANK("Juggernaut", 360f, 38f, 30, 4f, 26f, argb(0xFF9A4B3A), "Huge health, resists slows.", slowResistance = 0.35f),
    SHIELDED("Aegis", 55f, 80f, 18, 0f, 19f, argb(0xFF4AA3E8), "Energy shield recharges when left alone.", baseShield = 70f),
    SPLITTER("Splitter", 80f, 65f, 16, 0f, 22f, argb(0xFFE07A9B), "Bursts into fast Spawnlings on death."),
    SPAWNLING("Spawnling", 18f, 110f, 2, 0f, 10f, argb(0xFFEBA3BC), "A fragment of something larger."),
    HEALER("Medic", 60f, 70f, 20, 0f, 18f, argb(0xFF7AE0A0), "Heals nearby enemies. Kill it first."),
    PHANTOM("Phantom", 50f, 100f, 18, 0f, 17f, argb(0xFF9C8CFF), "Cloaks until burned, chilled or marked."),
    MINI_BRUISER("Siege Brute", 900f, 40f, 120, 10f, 32f, argb(0xFFB8452E), "Mini-boss. Periodically charges ahead.", slowResistance = 0.4f, leakDamage = 3, tier = 1),
    MINI_COMMANDER("War Medic", 700f, 55f, 120, 4f, 28f, argb(0xFF3FB9A5), "Mini-boss. Heals and shields its escort.", leakDamage = 3, tier = 1),
    MINI_STALKER("Shade Captain", 600f, 85f, 120, 0f, 24f, argb(0xFF6F5BD6), "Mini-boss. Cloaks and blinks forward.", leakDamage = 3, tier = 1),
    BOSS("Ironclad Warden", 1400f, 45f, 150, 12f, 34f, argb(0xFF7A2E3B), "Boss. Raises shields and calls guards in phases.", slowResistance = 0.5f, leakDamage = 5, tier = 2),
    BOSS_QUEEN("Brood Queen", 1800f, 40f, 180, 6f, 36f, argb(0xFFB4D43A), "Boss. Spawns swarms and enrages when hurt.", slowResistance = 0.5f, leakDamage = 5, tier = 2),
    BOSS_COLOSSUS("Static Colossus", 2600f, 32f, 220, 16f, 40f, argb(0xFF5E7FA8), "Boss. Emits EMP pulses that jam towers.", slowResistance = 0.6f, leakDamage = 6, tier = 2),
    BOSS_WRAITH("Void Wraith", 1500f, 62f, 200, 4f, 30f, argb(0xFF7B3FD0), "Boss. Cloaks, blinks and summons phantoms.", slowResistance = 0.5f, leakDamage = 5, tier = 2);

    val isBoss: Boolean get() = tier == 2
    val isMini: Boolean get() = tier == 1
    val isElite: Boolean get() = tier >= 1
}
