package com.ironpath.defense.render

import android.graphics.Canvas
import android.graphics.Paint
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.map.GameMap
import com.ironpath.defense.map.MapMechanic
import com.ironpath.defense.map.MapTheme
import com.ironpath.defense.mapfx.MapMechanics
import com.ironpath.defense.render.ArtKit.circ
import com.ironpath.defense.render.ArtKit.glow
import com.ironpath.defense.render.ArtKit.hash
import com.ironpath.defense.render.ArtKit.ln
import com.ironpath.defense.render.ArtKit.oval
import com.ironpath.defense.render.ArtKit.polygon
import com.ironpath.defense.render.ArtKit.ring
import com.ironpath.defense.render.ArtKit.rr
import com.ironpath.defense.render.ArtKit.withAlpha
import kotlin.math.cos
import kotlin.math.sin

/**
 * The "living map": everything that moves in the environment. Drifting cloud
 * shadows, theme weather (leaves + fireflies, blowing sand, snow, embers, dust,
 * rain, steam, spores), animated props (rune pedestals, grid pylons, hydraulic
 * presses) and the glowing spawn portal / base fortress. All motion is a pure
 * function of time with hashed per-mote seeds, so it allocates nothing and its
 * density scales with the graphics quality.
 */
class AmbientRenderer {
    private val screenPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun wrap(v: Float, size: Float): Float = ((v % size) + size) % size

    // --- ground-level props ----------------------------------------------------
    fun drawGround(c: Canvas, map: GameMap, mech: MapMechanics?, time: Float) {
        val th = map.theme
        val t = GameConfig.TILE_SIZE
        for (i in map.specialTiles.indices) {
            val (col, row) = map.specialTiles[i]
            val cx = col * t + t / 2f
            val cy = row * t + t / 2f
            when (map.mechanic) {
                MapMechanic.RUNES -> {
                    val cd = mech?.runeCooldown?.getOrNull(i) ?: 0f
                    val ready = cd <= 0f
                    val pulse = 0.5f + 0.5f * sin(time * 3f + i)
                    glow(c, cx, cy, 34f, th.accent, if (ready) 0.35f + 0.25f * pulse else 0.08f)
                    for (k in 0 until 6) {
                        val a = time * (if (ready) 0.8f else 0.2f) + k * 1.0472f
                        val gx = cx + cos(a) * 19f
                        val gy = cy + sin(a) * 19f
                        ln(c, gx - 2.4f, gy - 2.4f, gx + 2.4f, gy + 2.4f, 1.8f, withAlpha(th.accent, if (ready) 0.95f else 0.35f))
                    }
                    if (!ready) ArtKit.arc(c, cx, cy, 24f, -90f, 360f * (1f - cd / MapMechanics.RUNE_COOLDOWN), 3f, withAlpha(th.accent, 0.9f))
                    else { circ(c, cx, cy, 6f + pulse * 2f, withAlpha(0xFFFFFFFF.toInt(), 0.9f)); ring(c, cx, cy, 24f + pulse * 3f, 1.4f, withAlpha(th.accent, 0.6f)) }
                }
                MapMechanic.GRID_SURGE -> {
                    val active = mech != null && mech.activePylon == i
                    val charge = if (active) mech!!.pylonCharge else 0f
                    val col2 = th.deco2
                    glow(c, cx, cy, 30f + charge * 16f, col2, 0.25f + charge * 0.5f)
                    circ(c, cx, cy, 6f + charge * 3f, if (active) 0xFFFFFFFF.toInt() else withAlpha(col2, 0.8f))
                    if (active) {
                        val tick = (time * 16f).toInt()
                        for (k in 0 until 3) {
                            val a = hash(tick + k * 9 + i) * 6.283f
                            ln(c, cx, cy, cx + cos(a) * 26f, cy + sin(a) * 26f, 1.6f, withAlpha(0xFFE9FBFF.toInt(), 0.9f))
                        }
                        ring(c, cx, cy, 28f + charge * 6f, 2f, withAlpha(col2, 0.8f))
                    }
                }
                MapMechanic.FACTORY -> {
                    val ph = mech?.pressPhase?.getOrNull(i) ?: 0f
                    val reach = 6f + ph * 22f
                    rr(c, cx - 16f, cy - 34f + reach - 14f, cx + 16f, cy - 34f + reach + 10f, 3f, 0xFF7D858F.toInt())
                    rr(c, cx - 16f, cy + 34f - reach - 10f, cx + 16f, cy + 34f - reach + 14f, 3f, 0xFF7D858F.toInt())
                    rr(c, cx - 12f, cy - 34f + reach + 4f, cx + 12f, cy - 34f + reach + 10f, 2f, if (ph > 0.6f) 0xFFFF5A3A.toInt() else 0xFFFFB02E.toInt())
                    rr(c, cx - 12f, cy + 34f - reach - 10f, cx + 12f, cy + 34f - reach - 4f, 2f, if (ph > 0.6f) 0xFFFF5A3A.toInt() else 0xFFFFB02E.toInt())
                    if (ph > 0.6f) glow(c, cx, cy, 28f, 0xFFFFB02E.toInt(), (ph - 0.6f) * 1.2f)
                }
                else -> {}
            }
        }
        if (th == MapTheme.VOLCANO) {
            for (k in 0 until 6) {
                val bx = 60f + hash(k * 7) * (GameConfig.WORLD_WIDTH - 120f)
                val by = 40f + hash(k * 11 + 1) * (GameConfig.WORLD_HEIGHT - 80f)
                val p = (time * 0.6f + hash(k)) % 1f
                if (p < 0.5f) glow(c, bx, by, 6f + p * 14f, 0xFFFF5A1E.toInt(), 0.3f * (1f - p * 2f))
            }
        }
    }

    // --- spawn portal & base ------------------------------------------------
    fun drawGates(c: Canvas, spawn: Vector2, base: Vector2, time: Float, baseFlash: Float, hpFrac: Float, glowOn: Boolean) {
        val sx = spawn.x.coerceIn(10f, GameConfig.WORLD_WIDTH - 10f)
        val sy = spawn.y.coerceIn(10f, GameConfig.WORLD_HEIGHT - 10f)
        if (glowOn) glow(c, sx, sy, 44f, 0xFFD4505C.toInt(), 0.35f)
        circ(c, sx, sy, 24f, 0xCC1A0E14.toInt())
        for (k in 0 until 8) ArtKit.arc(c, sx, sy, 22f, time * 90f + k * 45f, 24f, 3f, 0xFFD4505C.toInt())
        for (k in 0 until 6) ArtKit.arc(c, sx, sy, 14f, -time * 130f + k * 60f, 30f, 2.4f, 0xFFFF8A8A.toInt())
        circ(c, sx, sy, 6f + sin(time * 4f) * 1.5f, 0xFFFFFFFF.toInt())
        // base fortress
        val bx = base.x
        val by = base.y
        oval(c, bx - 34f, by + 14f, bx + 34f, by + 34f, 0x44000000)
        polygon(c, bx, by, 31f, 8, 22.5f, 0xFF3A404A.toInt()); polygon(c, bx, by, 27f, 8, 22.5f, 0xFF6C7480.toInt()); polygon(c, bx, by, 21f, 8, 22.5f, 0xFF4B525C.toInt())
        for (k in 0 until 4) { val a = k * 1.5708f + 0.785f; circ(c, bx + cos(a) * 28f, by + sin(a) * 28f, 5.5f, 0xFF8A929E.toInt()); circ(c, bx + cos(a) * 28f, by + sin(a) * 28f, 2.4f, 0xFF4B525C.toInt()) }
        val pulse = 0.6f + 0.4f * sin(time * 2.5f)
        if (glowOn) glow(c, bx, by, 34f, 0xFF4DA3F0.toInt(), 0.35f * pulse)
        polygon(c, bx, by - 1f, 11f, 6, time * 20f, 0xFF4DA3F0.toInt()); polygon(c, bx - 1f, by - 2f, 6f, 6, time * 20f, 0xFFD8F0FF.toInt())
        ln(c, bx, by - 8f, bx, by - 34f, 1.8f, 0xFF3A404A.toInt())
        val sw = sin(time * 4f) * 2f
        ArtKit.tri(c, bx, by - 34f, bx, by - 24f, bx + 16f + sw, by - 29f + sw * 0.3f, if (hpFrac > 0.35f) 0xFF4DA3F0.toInt() else 0xFFFF5A5A.toInt())
        if (baseFlash > 0f) {
            glow(c, bx, by, 60f, 0xFFFF3A2A.toInt(), baseFlash * 0.9f)
            ring(c, bx, by, 32f + (1f - baseFlash) * 20f, 4f * baseFlash, withAlpha(0xFFFF6A4A.toInt(), baseFlash))
        }
    }

    // --- weather ----------------------------------------------------------------
    fun drawWeather(c: Canvas, theme: MapTheme, time: Float, density: Float, x0: Float, y0: Float, x1: Float, y1: Float) {
        val w = x1 - x0
        val h = y1 - y0
        if (density <= 0.05f) return
        // slow drifting cloud shadows
        if (theme != MapTheme.CITY && theme != MapTheme.FACTORY) {
            for (k in 0 until 3) {
                val px = x0 + wrap(hash(k * 5) * w + time * (8f + k * 3f), w + 400f) - 200f
                val py = y0 + hash(k * 5 + 2) * h
                oval(c, px - 170f, py - 60f, px + 170f, py + 60f, 0x0C000000)
            }
        }
        val count = (when (theme) {
            MapTheme.FOREST -> 26
            MapTheme.DESERT -> 34
            MapTheme.SNOW -> 70
            MapTheme.VOLCANO -> 36
            MapTheme.RUINS -> 28
            MapTheme.CITY -> 60
            MapTheme.FACTORY -> 22
            MapTheme.ALIEN -> 40
        } * density).toInt()
        for (i in 0 until count) {
            val a = hash(i * 3 + 1)
            val b = hash(i * 3 + 2)
            val s = hash(i * 3 + 3)
            when (theme) {
                MapTheme.FOREST -> if (i % 3 != 0) {
                    val px = x0 + wrap(a * w + time * (14f + s * 12f) + sin(time + i) * 16f, w)
                    val py = y0 + wrap(b * h + time * (22f + s * 18f), h)
                    c.save(); c.rotate(time * 90f * (s - 0.5f) + i * 40f, px, py)
                    oval(c, px - 4f, py - 2f, px + 4f, py + 2f, if (i % 2 == 0) 0xCCE0A040.toInt() else 0xCC7ABF52.toInt())
                    c.restore()
                } else {
                    val px = x0 + wrap(a * w + sin(time * 0.5f + i) * 24f, w)
                    val py = y0 + wrap(b * h + cos(time * 0.4f + i) * 20f, h)
                    glow(c, px, py, 9f, 0xFFFFF2A0.toInt(), 0.35f + 0.35f * sin(time * 2f + i * 1.7f))
                }
                MapTheme.DESERT -> {
                    val px = x0 + wrap(a * w + time * (160f + s * 120f), w)
                    val py = y0 + b * h
                    ln(c, px, py, px - 24f - s * 18f, py + 1f, 1.4f, 0x33FFF0C0)
                }
                MapTheme.SNOW -> {
                    val px = x0 + wrap(a * w + sin(time * 0.8f + i) * 18f + time * 22f, w)
                    val py = y0 + wrap(b * h + time * (28f + s * 34f), h)
                    circ(c, px, py, 1.2f + s * 2f, 0xDDFFFFFF.toInt())
                }
                MapTheme.VOLCANO -> if (i % 2 == 0) {
                    val px = x0 + wrap(a * w + sin(time + i) * 14f, w)
                    val py = y0 + h - wrap(time * (30f + s * 40f) + b * h, h)
                    glow(c, px, py, 5f + s * 3f, 0xFFFF7A2E.toInt(), 0.7f)
                } else {
                    val px = x0 + wrap(a * w + time * 12f, w)
                    val py = y0 + wrap(b * h + time * (12f + s * 10f), h)
                    circ(c, px, py, 1.4f, 0x88888078.toInt())
                }
                MapTheme.RUINS -> {
                    val px = x0 + wrap(a * w + sin(time * 0.3f + i) * 30f, w)
                    val py = y0 + wrap(b * h - time * (6f + s * 6f), h)
                    glow(c, px, py, 7f + s * 4f, 0xFF7CF2D0.toInt(), 0.22f + 0.15f * sin(time + i))
                }
                MapTheme.CITY -> {
                    val px = x0 + wrap(a * w - time * 70f, w)
                    val py = y0 + wrap(b * h + time * (300f + s * 140f), h)
                    ln(c, px, py, px - 4f, py - 16f, 1.1f, 0x55BFD8FF)
                }
                MapTheme.FACTORY -> {
                    val px = x0 + a * w
                    val ph = (time * 0.35f + s) % 1f
                    circ(c, px, y0 + b * h - ph * 40f, 4f + ph * 16f, withAlpha(0xFFE6EAF0.toInt(), 0.22f * (1f - ph)))
                    if (i % 4 == 0 && ph > 0.9f) glow(c, px, y0 + b * h, 6f, 0xFFFFB02E.toInt(), 0.8f)
                }
                MapTheme.ALIEN -> {
                    val px = x0 + wrap(a * w + sin(time * 0.6f + i) * 28f, w)
                    val py = y0 + h - wrap(time * (8f + s * 12f) + b * h, h)
                    glow(c, px, py, 5f + s * 5f, if (i % 2 == 0) 0xFF5CFFC8.toInt() else 0xFFC77DFF.toInt(), 0.4f + 0.3f * sin(time * 2f + i))
                }
            }
        }
    }

    /** Screen-space overlay for map-wide weather events (sandstorm). */
    fun drawScreenOverlay(c: Canvas, w: Float, h: Float, mech: MapMechanics?, time: Float) {
        val weather = mech?.weather ?: 0f
        if (weather <= 0.02f) return
        screenPaint.color = withAlpha(0xFFD9A860.toInt(), 0.32f * weather)
        c.drawRect(0f, 0f, w, h, screenPaint)
        screenPaint.strokeWidth = 2.5f
        for (i in 0 until (40 * weather).toInt()) {
            val y = hash(i * 7) * h
            val x = wrap(hash(i * 3) * w + time * (900f + hash(i) * 500f), w + 200f) - 100f
            screenPaint.color = withAlpha(0xFFFFE9B0.toInt(), 0.35f * weather)
            c.drawLine(x, y, x - 90f - hash(i + 5) * 60f, y + 3f, screenPaint)
        }
    }
}
