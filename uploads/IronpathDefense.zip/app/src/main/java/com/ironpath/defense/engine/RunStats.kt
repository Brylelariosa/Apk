package com.ironpath.defense.engine

import com.ironpath.defense.entity.tower.TowerType

/** Counters for one run, shown on the victory/defeat screens and folded into lifetime stats. */
class RunStats {
    var kills = 0
    var bossKills = 0
    var livesLost = 0
    var leaks = 0
    var fusions = 0
    var steamBursts = 0
    val towersBuilt = IntArray(TowerType.entries.size)

    val totalTowersBuilt: Int
        get() {
            var n = 0
            for (c in towersBuilt) n += c
            return n
        }
}
