# Ironpath Defense — R8 / ProGuard rules
#
# Deliberately minimal. The default rules AGP applies automatically
# (getDefaultProguardFile("proguard-android-optimize.txt")) already cover
# standard Android component keep-rules (Activity, etc. declared in the
# manifest are kept automatically).
#
# This project adds NO extra -keep rules because:
#   - There is no reflection anywhere in the codebase (no Class.forName,
#     no reflective field/method access).
#   - There is no JSON/serialization library (save data is written as plain
#     SharedPreferences key/value pairs — see save/SaveSystem.kt), so there
#     are no data classes that need their shape preserved for a (de)serializer.
#   - GameView is constructed entirely in code (see GameActivity.kt), never
#     inflated from an XML layout, so its single-argument constructor needs
#     no special keep rule.
#   - There are zero third-party/AndroidX dependencies to reconcile consumer
#     ProGuard rules with.
#
# If you add a dependency or a serialization layer later, add the *specific*
# keep rule that dependency's own documentation recommends — never a blanket
# "-keep class ** { *; }", which defeats shrinking almost entirely.
