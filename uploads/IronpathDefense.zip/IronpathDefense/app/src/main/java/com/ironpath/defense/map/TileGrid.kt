package com.ironpath.defense.map

/** Static classification of a single grid cell. */
enum class TileKind { BUILDABLE, PATH, BLOCKED }

/**
 * Per-tile classification (path / buildable / blocked) plus dynamic tower
 * occupancy, addressed by integer (col, row) grid coordinates.
 *
 * Kept separate from [GameMap] so the *shape* of a map (its waypoints) and
 * the *bookkeeping* of what's currently built on it are independent — a
 * fresh TileGrid is derived from a GameMap at the start of a run, and only
 * the grid's occupancy mutates during play.
 */
class TileGrid(private val cols: Int, private val rows: Int) {

    private val kinds = Array(rows) { Array(cols) { TileKind.BUILDABLE } }
    private val occupied = Array(rows) { Array(cols) { false } }

    fun inBounds(col: Int, row: Int) = col in 0 until cols && row in 0 until rows

    fun setKind(col: Int, row: Int, kind: TileKind) {
        if (inBounds(col, row)) kinds[row][col] = kind
    }

    fun kindAt(col: Int, row: Int): TileKind =
        if (inBounds(col, row)) kinds[row][col] else TileKind.BLOCKED

    fun isOccupied(col: Int, row: Int): Boolean =
        if (inBounds(col, row)) occupied[row][col] else true

    fun setOccupied(col: Int, row: Int, value: Boolean) {
        if (inBounds(col, row)) occupied[row][col] = value
    }

    /** A tower can only go on a buildable, currently-empty tile — never on the path. */
    fun canPlaceTower(col: Int, row: Int): Boolean =
        inBounds(col, row) && kindAt(col, row) == TileKind.BUILDABLE && !isOccupied(col, row)

    /** Clears every occupancy flag (tile *kinds* — path/buildable/blocked — are untouched). Used when starting a new session. */
    fun resetOccupancy() {
        for (row in occupied.indices) occupied[row].fill(false)
    }
}
