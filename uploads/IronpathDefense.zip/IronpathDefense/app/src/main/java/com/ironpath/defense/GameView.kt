package com.ironpath.defense

import android.content.Context
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.ironpath.defense.core.GameLoop
import com.ironpath.defense.core.InputEvent
import com.ironpath.defense.engine.GameWorld

/**
 * The only Android-specific glue in the project: hosts a SurfaceView + a
 * dedicated [GameLoop] thread, and forwards Surface lifecycle and touch
 * events into [GameWorld], which owns every actual game system. GameView
 * itself contains no gameplay logic — it doesn't know what a Tower or a
 * Wave is.
 *
 * Constructed entirely in code (see GameActivity) rather than inflated from
 * an XML layout, so there's no `activity_game.xml` at all and no
 * View(Context, AttributeSet) constructor to keep for R8.
 */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    val gameWorld = GameWorld(context)
    private var gameLoop: GameLoop? = null

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val loop = GameLoop(
            holder = holder,
            speedMultiplierProvider = { gameWorld.currentSpeedMultiplier },
            onUpdate = { dt -> gameWorld.update(dt) },
            onRender = { canvas -> gameWorld.render(canvas) }
        )
        loop.running = true
        loop.start()
        gameLoop = loop
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        gameWorld.onSurfaceResized(width.toFloat(), height.toFloat())
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        val loop = gameLoop ?: return
        loop.running = false
        try {
            loop.join(THREAD_JOIN_TIMEOUT_MS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        gameLoop = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            gameWorld.inputQueue.offer(InputEvent(event.x, event.y))
        }
        return true
    }

    /** Called from GameActivity.onPause — drops any in-progress run into the pause screen and force-flushes a save. */
    fun onHostPause() {
        gameWorld.pauseForBackground()
        gameWorld.persistNow()
    }

    companion object {
        private const val THREAD_JOIN_TIMEOUT_MS = 500L
    }
}
