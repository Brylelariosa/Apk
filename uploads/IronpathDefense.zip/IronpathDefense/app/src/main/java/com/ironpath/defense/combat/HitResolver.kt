package com.ironpath.defense.combat

import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.entity.projectile.ShotProfile
import kotlin.random.Random

/**
 * The one place that turns "this shot hit that enemy" into damage and status
 * effects. Projectile impacts and tower pulses both go through here, so an
 * upgrade like "marks foes" or "executes weak enemies" behaves identically
 * whichever way the damage was delivered.
 */
object HitResolver {

    /**
     * Applies [damage] from [shot] to [enemy], then the shot's status effects.
     * [damage] is passed separately from `shot.damage` because chain shots
     * lose damage per link. Returns the damage actually dealt (after armor,
     * boss bonus, marks, and any execute).
     */
    fun apply(enemy: Enemy, shot: ShotProfile, damage: Float): Float {
        var raw = damage
        val isBoss = enemy.kind == EnemyKind.BOSS
        if (isBoss) raw *= shot.bossDamageMultiplier

        var dealt = enemy.applyDamage(raw, shot.armorPenetration)

        if (shot.executeThreshold > 0f && !isBoss && enemy.currentHealth > 0f &&
            enemy.currentHealth <= enemy.maxHealth * shot.executeThreshold
        ) {
            dealt += enemy.currentHealth
            enemy.currentHealth = 0f
        }

        if (shot.slowDurationSeconds > 0f) enemy.applySlow(shot.slowMultiplier, shot.slowDurationSeconds)
        if (shot.burnDps > 0f && shot.burnSeconds > 0f) enemy.applyBurn(shot.burnDps, shot.burnSeconds, shot.burnColorArgb)
        if (shot.vulnerabilityBonus > 0f && shot.vulnerabilitySeconds > 0f) {
            enemy.applyVulnerability(shot.vulnerabilityBonus, shot.vulnerabilitySeconds)
        }
        if (shot.freezeChance > 0f && shot.freezeSeconds > 0f && Random.nextFloat() < shot.freezeChance) {
            enemy.applyStun(shot.freezeSeconds)
        }
        return dealt
    }
}
