package com.ironpath.defense.ui

/**
 * Screen edges (in pixels) that hardware may cover — camera cutouts and
 * rounded corners. The world and terrain are drawn edge to edge *under*
 * these, but anything the player has to read or tap (HUD, buttons, the
 * playable map itself) is kept inside them.
 */
data class SafeInsets(
    val left: Float = 0f,
    val top: Float = 0f,
    val right: Float = 0f,
    val bottom: Float = 0f
) {
    companion object {
        val NONE = SafeInsets()
    }
}
