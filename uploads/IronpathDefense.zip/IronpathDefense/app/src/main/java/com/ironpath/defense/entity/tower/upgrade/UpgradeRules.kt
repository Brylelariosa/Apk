package com.ironpath.defense.entity.tower.upgrade

/** Whether a tower's next step on a given path can be bought, ignoring money. */
enum class UpgradeAvailability { AVAILABLE, LOCKED, MAXED }

/**
 * The crosspathing rules, kept as pure functions so the UI, the purchase
 * check, and any future AI/tests all agree on them.
 *
 * Same shape as Bloons TD 6: every tower has three paths of [MAX_TIER]
 * tiers, but a build may use at most two of them, and only one may go past
 * tier [SECONDARY_PATH_CAP]. So 5/2/0 and 3/2/0 are legal; 3/3/0, 2/2/2 and
 * 5/2/1 are not.
 */
object UpgradeRules {
    const val PATH_COUNT = 3
    const val MAX_TIER = 5
    const val SECONDARY_PATH_CAP = 2

    /** True if buying [path]'s next tier would break the crosspath rules for a tower at [tiers]. */
    fun isLockedByCrosspath(tiers: IntArray, path: Int): Boolean {
        val nextTier = tiers[path] + 1
        var otherPathsInUse = 0
        var otherPathPastCap = false
        for (i in tiers.indices) {
            if (i == path) continue
            if (tiers[i] > 0) otherPathsInUse++
            if (tiers[i] > SECONDARY_PATH_CAP) otherPathPastCap = true
        }
        // A third path can never be started once two are in use.
        if (tiers[path] == 0 && otherPathsInUse >= 2) return true
        // Only one path may climb past the cap.
        if (nextTier > SECONDARY_PATH_CAP && otherPathPastCap) return true
        return false
    }
}
