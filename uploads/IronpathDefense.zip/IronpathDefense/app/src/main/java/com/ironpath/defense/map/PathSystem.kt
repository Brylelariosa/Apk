package com.ironpath.defense.map

import com.ironpath.defense.core.Vector2

/**
 * Turns a map's waypoint polyline into "where is the enemy that has walked
 * exactly D units along the path" queries.
 *
 * Each enemy caches the segment index it was last resolved into (see
 * `Enemy.pathSegmentHint`) and passes it back in on the next call, so a
 * normal frame (where the enemy only moved slightly forward) resolves in
 * O(1) rather than rescanning every segment from the start — this matters
 * once dozens of enemies are walking the path every one of the 60
 * fixed-timestep updates per second.
 */
class PathSystem(private val waypoints: List<Vector2>) {

    private val cumulativeDistances: FloatArray
    val totalLength: Float

    init {
        require(waypoints.size >= 2) { "A path needs at least two waypoints" }
        cumulativeDistances = FloatArray(waypoints.size)
        var acc = 0f
        cumulativeDistances[0] = 0f
        for (i in 1 until waypoints.size) {
            acc += waypoints[i - 1].distanceTo(waypoints[i])
            cumulativeDistances[i] = acc
        }
        totalLength = acc
    }

    /**
     * Writes the world position at [distance] along the path into [out], and
     * returns the segment index that position falls in (pass this back in as
     * [hintSegment] next time for the same enemy).
     */
    fun positionAt(distance: Float, hintSegment: Int, out: Vector2): Int {
        val clamped = distance.coerceIn(0f, totalLength)

        var segment = hintSegment.coerceIn(0, waypoints.size - 2)
        // Advance forward if the hint is behind where we now are.
        while (segment < waypoints.size - 2 && clamped > cumulativeDistances[segment + 1]) {
            segment++
        }
        // Rare (e.g. hint from a different, longer path): fall back to searching backward.
        while (segment > 0 && clamped < cumulativeDistances[segment]) {
            segment--
        }

        val segmentStart = cumulativeDistances[segment]
        val segmentLength = cumulativeDistances[segment + 1] - segmentStart
        val t = if (segmentLength > 0f) (clamped - segmentStart) / segmentLength else 0f

        val from = waypoints[segment]
        val to = waypoints[segment + 1]
        out.set(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t)
        return segment
    }

    fun hasReachedEnd(distance: Float): Boolean = distance >= totalLength
}
