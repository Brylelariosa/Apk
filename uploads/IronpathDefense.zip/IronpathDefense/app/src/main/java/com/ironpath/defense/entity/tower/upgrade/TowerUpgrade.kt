package com.ironpath.defense.entity.tower.upgrade

import com.ironpath.defense.entity.tower.TowerStats

/** A pure transformation of a tower's stats — what one upgrade (or one part of it) changes. */
typealias StatModifier = (TowerStats) -> TowerStats

/**
 * One purchasable step on an [UpgradePath]: a name and one-line description
 * for the UI, a [cost], and the stat changes it makes. An upgrade is just
 * data plus a list of [StatModifier]s, so adding or retuning one never
 * touches combat code.
 */
class TowerUpgrade(
    val name: String,
    val description: String,
    val cost: Int,
    private val modifiers: List<StatModifier>
) {
    fun applyTo(stats: TowerStats): TowerStats =
        modifiers.fold(stats) { current, modifier -> modifier(current) }
}

/**
 * One of a tower's three specialization branches (think "class"): an ordered
 * list of upgrades bought strictly in sequence. [colorArgb] tints this
 * path's card, pips, and upgrade effects.
 */
class UpgradePath(
    val name: String,
    val colorArgb: Int,
    val upgrades: List<TowerUpgrade>
)
