package com.ironpath.defense.audio

/**
 * Every short sound effect the game can play, and the asset file it expects
 * under `assets/audio/`. See AudioSystem's class doc for why a missing file
 * is safe (no crash, that effect just stays silent).
 */
enum class SoundEffect(val assetFileName: String) {
    SHOOT("shoot.ogg"),
    HIT("hit.ogg"),
    EXPLOSION("explosion.ogg"),
    TOWER_PLACE("tower_place.ogg"),
    TOWER_UPGRADE("tower_upgrade.ogg"),
    TOWER_SELL("tower_sell.ogg"),
    WAVE_START("wave_start.ogg"),
    LIFE_LOST("life_lost.ogg"),
    BUTTON_TAP("button_tap.ogg"),
    VICTORY("victory.ogg"),
    GAME_OVER("game_over.ogg")
}
