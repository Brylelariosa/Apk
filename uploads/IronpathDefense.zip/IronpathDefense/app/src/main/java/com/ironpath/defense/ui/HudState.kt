package com.ironpath.defense.ui

import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType

/**
 * Immutable per-frame snapshot of everything the HUD needs to draw and
 * hit-test, assembled once by GameWorld. Neither [HudRenderer] nor
 * GameView's input handling need a direct reference to EconomySystem,
 * WaveSystem, SettingsSystem, etc. — they only ever see this.
 *
 * Affordability/unlock status for shop buttons isn't precomputed into this
 * snapshot: [money] and [highestWaveCompleted] are enough for HudRenderer to
 * call the already-existing [TowerType.isUnlockedAt] and compare against
 * [TowerType.baseCost] itself, which avoids allocating a five-entry
 * map/array here every single frame for no real benefit.
 */
data class HudState(
    val screenState: GameScreenState,
    val money: Int,
    val lives: Int,
    val maxLives: Int,
    val waveNumber: Int,
    val totalWaves: Int,
    val waveInProgress: Boolean,
    val canStartWave: Boolean,
    val isBossWave: Boolean,
    val speedMultiplier: Float,
    val highestWaveCompleted: Int,
    val selectedTower: Tower?,
    val pendingTowerType: TowerType?,
    val musicOn: Boolean,
    val sfxOn: Boolean,
    val showDamageNumbers: Boolean
)
