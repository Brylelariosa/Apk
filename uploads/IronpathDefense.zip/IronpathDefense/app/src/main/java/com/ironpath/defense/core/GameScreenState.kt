package com.ironpath.defense.core

/** Top-level screen/flow state. GameView and the input/HUD layers branch on this. */
enum class GameScreenState {
    MAIN_MENU,
    PLAYING,
    PAUSED,
    SETTINGS,
    GAME_OVER,
    VICTORY
}
