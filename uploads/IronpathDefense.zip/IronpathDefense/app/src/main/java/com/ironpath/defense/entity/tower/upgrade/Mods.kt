package com.ironpath.defense.entity.tower.upgrade

/**
 * The vocabulary of stat changes an upgrade can be built from. Each function
 * returns a [StatModifier]; an upgrade lists as many as it needs.
 *
 * Semantics are chosen so the catalog can state *absolute* numbers where it
 * reads best: multipliers (`damage`, `range`, `cooldown`, `bossDamage`)
 * compound, counts and radii (`splash`, `armorPen`, `multishot`, `chain`)
 * add, and status effects (`burn`, `freeze`, `mark`, `crit`, `execute`,
 * `pulse`, `slow`) only ever move toward the stronger value — buying a weaker
 * effect after a stronger one can never make a tower worse.
 */
object Mods {

    /** Multiplies damage. */
    fun damage(mult: Float): StatModifier = { it.copy(damage = it.damage * mult) }

    /** Multiplies range. */
    fun range(mult: Float): StatModifier = { it.copy(range = it.range * mult) }

    /** Multiplies the time between volleys — below 1 is faster. */
    fun cooldown(mult: Float): StatModifier = { it.copy(fireRateSeconds = it.fireRateSeconds * mult) }

    /** Adds blast radius (turns single-target shots into splash shots). */
    fun splash(add: Float): StatModifier = { it.copy(splashRadius = it.splashRadius + add) }

    /** Adds flat armor penetration. */
    fun armorPen(add: Float): StatModifier = { it.copy(armorPenetration = it.armorPenetration + add) }

    /** Slows to [multiplier] of normal speed (lower = stronger) for at least [seconds]. */
    fun slow(multiplier: Float, seconds: Float): StatModifier = {
        it.copy(
            slowMultiplier = minOf(it.slowMultiplier, multiplier),
            slowDurationSeconds = maxOf(it.slowDurationSeconds, seconds)
        )
    }

    /** Adds chain links and reach; raises the damage kept per link to at least [minFalloff]. */
    fun chain(addLinks: Int, addReach: Float, minFalloff: Float): StatModifier = {
        it.copy(
            chainCount = it.chainCount + addLinks,
            chainRadius = it.chainRadius + addReach,
            chainDamageFalloff = maxOf(it.chainDamageFalloff, minFalloff)
        )
    }

    /** Adds extra projectiles per volley. */
    fun multishot(add: Int): StatModifier = { it.copy(projectilesPerShot = it.projectilesPerShot + add) }

    /** Crit chance (0..1) and damage multiplier. */
    fun crit(chance: Float, multiplier: Float): StatModifier = {
        it.copy(
            critChance = maxOf(it.critChance, chance),
            critMultiplier = maxOf(it.critMultiplier, multiplier)
        )
    }

    /** Damage over time (ignores armor). */
    fun burn(dps: Float, seconds: Float): StatModifier = {
        it.copy(burnDps = maxOf(it.burnDps, dps), burnSeconds = maxOf(it.burnSeconds, seconds))
    }

    /** Recolors the damage-over-time effect (fire vs. poison, say). */
    fun dotColor(colorArgb: Int): StatModifier = { it.copy(dotColorArgb = colorArgb) }

    /** Chance (0..1) per hit to stun for [seconds]. */
    fun freeze(chance: Float, seconds: Float): StatModifier = {
        it.copy(
            freezeChance = maxOf(it.freezeChance, chance),
            freezeSeconds = maxOf(it.freezeSeconds, seconds)
        )
    }

    /** Marks enemies so they take [bonus] (0.2 = +20%) more damage for [seconds]. */
    fun mark(bonus: Float, seconds: Float): StatModifier = {
        it.copy(
            vulnerabilityBonus = maxOf(it.vulnerabilityBonus, bonus),
            vulnerabilitySeconds = maxOf(it.vulnerabilitySeconds, seconds)
        )
    }

    /** Multiplies damage dealt to bosses. */
    fun bossDamage(mult: Float): StatModifier = { it.copy(bossDamageMultiplier = it.bossDamageMultiplier * mult) }

    /** Hits kill non-boss enemies outright at or below this health fraction. */
    fun execute(threshold: Float): StatModifier = { it.copy(executeThreshold = maxOf(it.executeThreshold, threshold)) }

    /** A periodic nova around the tower: [damage] to everything within [radius] every [intervalSeconds]. */
    fun pulse(damage: Float, intervalSeconds: Float, radius: Float): StatModifier = {
        val interval = if (it.pulseIntervalSeconds > 0f) minOf(it.pulseIntervalSeconds, intervalSeconds) else intervalSeconds
        it.copy(
            pulseDamage = maxOf(it.pulseDamage, damage),
            pulseIntervalSeconds = interval,
            pulseRadius = maxOf(it.pulseRadius, radius)
        )
    }
}
