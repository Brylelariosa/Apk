package com.ironpath.defense.entity.tower

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * A placed tower instance.
 *
 * Not pooled: towers are placed/sold far less often than enemies spawn or
 * projectiles fire, so allocation pressure here is negligible — but it's
 * still a plain mutable class (not a data class) for consistency with the
 * rest of the entity layer and because identity, not structural equality,
 * is what matters for a placed tower.
 */
class Tower(val type: TowerType, val position: Vector2) {

    var tier = 1
        private set

    var totalInvested = type.baseCost
        private set

    var cooldownRemaining = 0f
    var targetingMode = TargetingMode.FIRST

    val stats: TowerTierStats get() = type.statsFor(tier)
    val canUpgrade: Boolean get() = tier < type.maxTier
    val sellValue: Int get() = (totalInvested * GameConfig.SELL_REFUND_FRACTION).toInt()

    /** Only called by UpgradeSystem, which has already validated the player can afford it. */
    fun applyUpgrade() {
        check(canUpgrade) { "${type.displayName} is already at max tier" }
        tier++
        totalInvested += stats.upgradeCost // stats now reflects the new tier
    }

    fun cycleTargetingMode() {
        val modes = TargetingMode.entries
        targetingMode = modes[(targetingMode.ordinal + 1) % modes.size]
    }
}
