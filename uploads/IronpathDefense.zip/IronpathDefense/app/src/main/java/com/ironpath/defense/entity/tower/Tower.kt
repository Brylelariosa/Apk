package com.ironpath.defense.entity.tower

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.tower.upgrade.TowerUpgrade
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import kotlin.math.sqrt

/**
 * A placed tower instance.
 *
 * Its build is [pathTiers]: how many upgrades it has bought on each of the
 * type's three paths. [stats] is the type's base stats with those upgrades
 * folded in, recomputed only when an upgrade is bought — never per tick.
 *
 * Not pooled: towers are placed/sold far less often than enemies spawn or
 * projectiles fire, so allocation pressure here is negligible — but it's
 * still a plain mutable class (not a data class) for consistency with the
 * rest of the entity layer and because identity, not structural equality,
 * is what matters for a placed tower.
 */
class Tower(val type: TowerType, val position: Vector2) {

    /** Upgrades bought per path, indexed like [TowerType.paths]. Mutated only by [applyUpgrade]. */
    val pathTiers = IntArray(UpgradeRules.PATH_COUNT)

    var stats: TowerStats = type.baseStats
        private set

    var totalInvested = type.baseCost
        private set

    // --- Runtime state driven by TowerSystem ------------------------------------
    var cooldownRemaining = 0f
    var pulseCooldownRemaining = 0f
    var targetingMode = TargetingMode.FIRST

    // --- Presentation-only state (read by the renderer, never by gameplay) --------
    /** Counts down after each volley; the renderer draws a muzzle flash while it's positive. */
    var flashRemaining = 0f
    /** Unit vector toward the last target, so the barrel can point at what it's shooting. */
    var aimX = 1f
        private set
    var aimY = 0f
        private set

    val sellValue: Int get() = (totalInvested * GameConfig.SELL_REFUND_FRACTION).toInt()

    /** Total upgrades bought across all paths. */
    val totalUpgrades: Int get() = pathTiers.sum()

    /** Index of the path with the most upgrades (the lowest index wins ties), or -1 for an un-upgraded tower. */
    val dominantPath: Int
        get() {
            var best = -1
            var bestTier = 0
            for (i in pathTiers.indices) {
                if (pathTiers[i] > bestTier) {
                    bestTier = pathTiers[i]
                    best = i
                }
            }
            return best
        }

    /** Tint used for this tower's effects: its dominant path's color, or the type color if un-upgraded. */
    val accentColorArgb: Int
        get() {
            val p = dominantPath
            return if (p < 0) type.colorArgb else type.paths[p].colorArgb
        }

    /** The name of the most advanced upgrade on the dominant path, or the base tower name — the tower's "class". */
    val classTitle: String
        get() {
            val p = dominantPath
            return if (p < 0) type.displayName else type.paths[p].upgrades[pathTiers[p] - 1].name
        }

    /** The next upgrade on [path], or null if that path is finished. */
    fun nextUpgrade(path: Int): TowerUpgrade? = type.paths[path].upgrades.getOrNull(pathTiers[path])

    fun upgradeAvailability(path: Int): UpgradeAvailability = when {
        nextUpgrade(path) == null -> UpgradeAvailability.MAXED
        UpgradeRules.isLockedByCrosspath(pathTiers, path) -> UpgradeAvailability.LOCKED
        else -> UpgradeAvailability.AVAILABLE
    }

    /** Only called by UpgradeSystem, which has already validated availability and charged the player. */
    fun applyUpgrade(path: Int) {
        val upgrade = checkNotNull(nextUpgrade(path)) { "${type.displayName} path $path is already maxed" }
        pathTiers[path]++
        totalInvested += upgrade.cost
        stats = recomputeStats()
    }

    fun cycleTargetingMode() {
        val modes = TargetingMode.entries
        targetingMode = modes[(targetingMode.ordinal + 1) % modes.size]
    }

    /** Points the barrel at [target] (a world position). */
    fun aimAt(target: Vector2) {
        val dx = target.x - position.x
        val dy = target.y - position.y
        val length = sqrt(dx * dx + dy * dy)
        if (length > 0.001f) {
            aimX = dx / length
            aimY = dy / length
        }
    }

    private fun recomputeStats(): TowerStats {
        var result = type.baseStats
        for (path in pathTiers.indices) {
            for (tier in 0 until pathTiers[path]) {
                result = type.paths[path].upgrades[tier].applyTo(result)
            }
        }
        return result
    }
}
