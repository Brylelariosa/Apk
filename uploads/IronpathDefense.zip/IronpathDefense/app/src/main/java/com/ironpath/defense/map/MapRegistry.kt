package com.ironpath.defense.map

/**
 * Registry of available maps. Ships with exactly one polished map today;
 * a second map is added here without touching MapSystem, PathSystem,
 * GameWorld, or the UI — they all already work in terms of "the current
 * GameMap", not "Ironpath Valley" specifically.
 */
object MapRegistry {
    val all: List<GameMap> = listOf(GameMap.ironpathValley())

    fun default(): GameMap = all.first()
}
