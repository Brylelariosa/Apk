package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind

/** One spawn batch within a wave: [count] enemies of [kind], [intervalSeconds] apart, starting [startDelaySeconds] into the wave. */
data class SpawnGroup(
    val kind: EnemyKind,
    val count: Int,
    val intervalSeconds: Float,
    val startDelaySeconds: Float = 0f
)

/** A full wave: however many [SpawnGroup]s run concurrently (their delays can overlap), plus the reward for clearing it. */
data class WaveDefinition(
    val index: Int,
    val groups: List<SpawnGroup>,
    val completionReward: Int,
    val isBossWave: Boolean = false
)
