package com.ironpath.defense.core

import android.graphics.Canvas
import android.view.SurfaceHolder

/**
 * Drives the simulation on a dedicated background thread using a fixed
 * timestep accumulator, and renders once per real frame on the same thread.
 *
 * Why fixed-timestep rather than "just multiply the delta passed to update":
 * a variable-length dt fed straight into physics/movement code makes
 * behavior depend on exactly when frames landed, which is both
 * non-deterministic and dangerous on low-end devices where dt can spike
 * after a hitch (an enemy could "teleport" past a tower's range in one
 * frame). Instead, real elapsed time is accumulated and drained in fixed
 * [GameConfig.FIXED_TIMESTEP] chunks, so every simulation step is always the
 * same size. Game speed (1x/2x/3x) scales how fast the accumulator fills,
 * which means "2x speed" runs the simulation in twice as many equally-sized
 * steps per second — not a doubled render rate and not larger, coarser
 * steps.
 *
 * There is deliberately no "paused" flag here: GameWorld.update() itself is
 * a no-op whenever its screen state isn't PLAYING (menu/paused/settings/end
 * screens), which is the single authority on whether the simulation should
 * advance. Rendering keeps running at full rate regardless, so a paused
 * overlay still draws smoothly and responds to input instantly. Mirroring
 * that same on/off state into a second flag here would just be two places
 * that have to agree instead of one.
 *
 * [speedMultiplierProvider] is a supplier, not a stored field, for the same
 * reason: GameWorld's speed index is the one source of truth, so this loop
 * just reads it fresh every iteration instead of needing GameView to copy a
 * changed value over from GameWorld into a second field here on every speed
 * change.
 */
class GameLoop(
    private val holder: SurfaceHolder,
    private val speedMultiplierProvider: () -> Float,
    private val onUpdate: (deltaSeconds: Float) -> Unit,
    private val onRender: (Canvas) -> Unit
) : Thread("GameLoop") {

    @Volatile var running = false

    private var accumulator = 0f

    override fun run() {
        var lastTimeNanos = System.nanoTime()

        while (running) {
            val now = System.nanoTime()
            var frameDelta = (now - lastTimeNanos) / 1_000_000_000f
            lastTimeNanos = now
            if (frameDelta > MAX_FRAME_DELTA_SECONDS) frameDelta = MAX_FRAME_DELTA_SECONDS

            accumulator += frameDelta * speedMultiplierProvider()
            var stepsThisFrame = 0
            while (accumulator >= GameConfig.FIXED_TIMESTEP && stepsThisFrame < GameConfig.MAX_STEPS_PER_FRAME) {
                onUpdate(GameConfig.FIXED_TIMESTEP)
                accumulator -= GameConfig.FIXED_TIMESTEP
                stepsThisFrame++
            }
            // If we hit the step cap (a severe hitch), drop the remainder rather
            // than let it balloon into a huge catch-up burst on the next frame.
            if (stepsThisFrame >= GameConfig.MAX_STEPS_PER_FRAME) accumulator = 0f

            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    synchronized(holder) { onRender(canvas) }
                }
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: IllegalStateException) {
                        // Surface was destroyed between lock and unlock (e.g. activity
                        // finishing mid-frame) — nothing to recover, just skip this frame.
                    }
                }
            }

            val frameTimeNanos = System.nanoTime() - now
            val sleepNanos = TARGET_FRAME_NANOS - frameTimeNanos
            if (sleepNanos > 0) {
                try {
                    sleep(sleepNanos / 1_000_000, (sleepNanos % 1_000_000).toInt())
                } catch (_: InterruptedException) {
                    currentThread().interrupt()
                }
            }
        }
    }

    companion object {
        private const val TARGET_FPS = 60
        private const val TARGET_FRAME_NANOS = 1_000_000_000L / TARGET_FPS
        private const val MAX_FRAME_DELTA_SECONDS = 0.25f
    }
}
