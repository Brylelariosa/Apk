package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.Vector2

/** An expanding, fading ring (upgrade flash, splash blast, pulse nova). Pooled by ParticleSystem. */
class ShockRing {
    val position = Vector2()
    var startRadius = 0f
    var endRadius = 0f
    var strokeWidth = 4f
    var colorArgb = 0xFFFFFFFF.toInt()
    var lifeRemaining = 0f
    var lifeTotal = 0.4f
    var alive = false

    fun lifeFraction(): Float = if (lifeTotal <= 0f) 0f else (lifeRemaining / lifeTotal).coerceIn(0f, 1f)

    /** Current radius, easing out so the ring bursts fast then slows. */
    fun currentRadius(): Float {
        val t = 1f - lifeFraction()
        val eased = 1f - (1f - t) * (1f - t)
        return startRadius + (endRadius - startRadius) * eased
    }
}
