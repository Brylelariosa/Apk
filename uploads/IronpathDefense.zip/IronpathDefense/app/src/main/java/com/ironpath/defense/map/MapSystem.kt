package com.ironpath.defense.map

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * Facade the rest of the game talks to for "what does the map look like /
 * can I build here" questions. Owns the current [GameMap]'s derived
 * [TileGrid] and the world<->tile coordinate conversions, so no other system
 * needs to know tile math.
 */
class MapSystem(val map: GameMap) {

    val tileGrid: TileGrid = map.buildTileGrid()
    val pathSystem = PathSystem(map.worldWaypoints())

    fun worldToTile(world: Vector2): Pair<Int, Int> =
        (world.x / GameConfig.TILE_SIZE).toInt() to (world.y / GameConfig.TILE_SIZE).toInt()

    fun tileToWorldCenter(col: Int, row: Int): Vector2 = Vector2(
        col * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f,
        row * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f
    )

    fun canPlaceTowerAt(world: Vector2): Boolean {
        val (col, row) = worldToTile(world)
        return tileGrid.canPlaceTower(col, row)
    }

    fun markBuilt(world: Vector2, built: Boolean) {
        val (col, row) = worldToTile(world)
        tileGrid.setOccupied(col, row, built)
    }

    /** Clears all tower occupancy for a fresh session (the map's path/buildable layout itself never changes). */
    fun resetOccupancy() = tileGrid.resetOccupancy()
}
