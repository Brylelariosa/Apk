package com.ironpath.defense.engine

import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.audio.SoundEffect
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.settings.SettingsSystem

/**
 * Turns combat events into sparks, rings, arcs, floating numbers and sound.
 * Combat code reports *what happened* through [CombatFeedback]; this is the
 * only place that decides what that looks and sounds like, so retuning the
 * effects never touches simulation code.
 *
 * Also owns the non-combat flourishes for the tower lifecycle (placing and
 * upgrading), which are the same kind of "make it feel good" work.
 */
class CombatEffects(
    private val particleSystem: ParticleSystem,
    private val audioSystem: AudioSystem,
    private val settingsSystem: SettingsSystem
) : CombatFeedback {

    private var lastHitSoundNanos = 0L

    override fun onEnemyHit(enemy: Enemy, damageDealt: Float, isCrit: Boolean) {
        if (isCrit) {
            particleSystem.spawnHitBurst(enemy.position, CRIT_COLOR, sparkCount = 9)
            particleSystem.spawnRing(enemy.position, startRadius = 4f, endRadius = 34f, seconds = 0.3f, colorArgb = CRIT_COLOR, strokeWidth = 3f)
        } else {
            particleSystem.spawnHitBurst(enemy.position, HIT_SPARK_COLOR, sparkCount = 4)
        }
        if (settingsSystem.showDamageNumbers) {
            particleSystem.spawnDamageNumber(enemy.position, damageDealt.toInt(), isCrit)
        }
        playHitSound()
    }

    override fun onSplash(center: Vector2, radius: Float, colorArgb: Int) {
        particleSystem.spawnRing(center, startRadius = radius * 0.25f, endRadius = radius, seconds = 0.28f, colorArgb = colorArgb, strokeWidth = 4f)
        particleSystem.spawnHitBurst(center, colorArgb, sparkCount = 8)
    }

    override fun onChainLink(from: Vector2, to: Vector2, colorArgb: Int) {
        particleSystem.spawnBolt(from, to, colorArgb)
    }

    override fun onPulse(center: Vector2, radius: Float, colorArgb: Int) {
        particleSystem.spawnRing(center, startRadius = 12f, endRadius = radius, seconds = 0.5f, colorArgb = colorArgb, strokeWidth = 6f)
        particleSystem.spawnRing(center, startRadius = 6f, endRadius = radius * 0.7f, seconds = 0.35f, colorArgb = 0xFFFFFFFF.toInt(), strokeWidth = 2.5f)
    }

    /** A tower was just built. */
    fun onTowerPlaced(position: Vector2, colorArgb: Int) {
        particleSystem.spawnRing(position, startRadius = 8f, endRadius = 46f, seconds = 0.35f, colorArgb = colorArgb, strokeWidth = 4f)
        particleSystem.spawnHitBurst(position, colorArgb, sparkCount = 8)
    }

    /**
     * An upgrade was just bought: a flash and fountain of sparks in the
     * path's color, plus the upgrade's name rising off the tower. The
     * capstone (final tier) gets a second, wider wave so it feels earned.
     */
    fun onTowerUpgraded(position: Vector2, pathColorArgb: Int, upgradeName: String, isCapstone: Boolean) {
        particleSystem.spawnUpgradeBurst(position, pathColorArgb)
        particleSystem.spawnFloatingText(Vector2(position.x, position.y - FLOATING_TEXT_LIFT), upgradeName, pathColorArgb)
        if (isCapstone) {
            particleSystem.spawnRing(position, startRadius = 14f, endRadius = 150f, seconds = 0.8f, colorArgb = pathColorArgb, strokeWidth = 7f)
            particleSystem.spawnUpgradeBurst(position, 0xFFFFFFFF.toInt())
        }
    }

    /** Hit sounds are rate-limited: a pulse or splash can hit a dozen enemies in one tick and would otherwise stack into noise. */
    private fun playHitSound() {
        val now = System.nanoTime()
        if (now - lastHitSoundNanos < HIT_SOUND_MIN_GAP_NANOS) return
        lastHitSoundNanos = now
        audioSystem.play(SoundEffect.HIT, volume = 0.6f)
    }

    private companion object {
        val HIT_SPARK_COLOR: Int = 0xFFF2E9D8.toInt()
        val CRIT_COLOR: Int = 0xFFFFD35A.toInt()
        const val FLOATING_TEXT_LIFT = 38f
        const val HIT_SOUND_MIN_GAP_NANOS = 45_000_000L
    }
}
