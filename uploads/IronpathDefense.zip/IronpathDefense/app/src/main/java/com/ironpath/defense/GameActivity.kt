package com.ironpath.defense

import android.app.Activity
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager

/**
 * The app's single screen. Plain `Activity`, not `AppCompatActivity` — the
 * whole UI is drawn by [GameView] on a Canvas, so there's no toolbar, no
 * Material widgets, and no XML layout to inflate, which means no reason to
 * pull in the AppCompat/Material dependency at all (see app/build.gradle.kts).
 *
 * minSdk is 30 (Android 11), which is also exactly when [WindowInsetsController]
 * was introduced — so immersive mode below is the plain platform API with no
 * version-check branching or AndroidX compat shim needed.
 */
class GameActivity : Activity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Fullscreen means fullscreen: draw under the camera cutout / notch instead of
        // leaving a black bar beside it, and lay out edge to edge from the first frame.
        // (The HUD stays clear of the cutout itself — see GameView's insets listener.)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        window.setDecorFitsSystemWindows(false)

        gameView = GameView(this)
        setContentView(gameView)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Re-asserted on every focus gain (not just onCreate/onResume): pulling
        // down the notification shade and dismissing it, for example, otherwise
        // leaves the system bars visible for the rest of the session.
        if (hasFocus) enterImmersiveMode()
    }

    private fun enterImmersiveMode() {
        window.setDecorFitsSystemWindows(false)
        window.insetsController?.apply {
            hide(WindowInsets.Type.systemBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onPause() {
        gameView.onHostPause()
        super.onPause()
    }

    @Suppress("DEPRECATION") // Intentional: see class doc — no AndroidX ComponentActivity/OnBackPressedDispatcher here.
    override fun onBackPressed() {
        if (gameView.gameWorld.isPlaying) {
            gameView.gameWorld.togglePause()
        } else {
            super.onBackPressed()
        }
    }
}
