package com.ironpath.defense.ui

import com.ironpath.defense.entity.tower.TowerType

/**
 * Every gameplay action a tap can trigger, as an interface GameWorld
 * implements. [InputController] only ever talks to this — never to
 * EconomySystem, TowerSystem, WaveSystem, etc. directly — which keeps input
 * handling a pure "geometry in, intent out" translation layer.
 */
interface GameActions {
    fun startWave()
    fun cycleSpeed()
    fun togglePause()
    fun openSettings()
    fun closeSettings()
    fun toggleMusic()
    fun toggleSfx()
    fun toggleDamageNumbers()
    fun goToMainMenu()
    fun startNewGame()

    /** Arms [type] for placement, or disarms it if it was already armed (tapping the same shop slot twice). */
    fun armTowerTypeForPlacement(type: TowerType)

    /** Attempts to place the currently-armed tower type at this world position. No-ops if nothing is armed or the tile is invalid. */
    fun attemptPlaceTowerAt(worldX: Float, worldY: Float)

    /** @return true if a placed tower was found at this world position and is now selected. */
    fun selectPlacedTowerAt(worldX: Float, worldY: Float): Boolean

    fun deselectTower()
    fun upgradeSelectedTower()
    fun sellSelectedTower()
    fun cycleSelectedTowerTargeting()
}
