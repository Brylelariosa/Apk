package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.Vector2

/** A brief jagged line between two points (a chain-lightning link). Pooled by ParticleSystem. */
class ArcBolt {
    val from = Vector2()
    val to = Vector2()
    var colorArgb = 0xFFFFFFFF.toInt()
    var lifeRemaining = 0f
    var lifeTotal = 0.16f
    var alive = false

    fun lifeFraction(): Float = if (lifeTotal <= 0f) 0f else (lifeRemaining / lifeTotal).coerceIn(0f, 1f)
}
