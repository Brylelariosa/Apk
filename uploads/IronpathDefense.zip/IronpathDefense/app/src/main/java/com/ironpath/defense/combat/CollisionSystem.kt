package com.ironpath.defense.combat

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.tower.TargetingMode

/**
 * Uniform spatial grid over the current enemy set.
 *
 * This is what keeps targeting cheap as enemy/tower counts grow: instead of
 * every tower checking every enemy every tick (O(towers × enemies), the
 * thing the spec explicitly calls out to avoid), each tower's range query
 * only visits the handful of grid cells its range circle overlaps. All range
 * comparisons use squared distance ([Vector2.distanceSquaredTo]) so no
 * square root runs per candidate.
 *
 * [rebuild] is called once per fixed-timestep tick from GameWorld — cheap,
 * since it's just re-bucketing the (already-iterated) active enemy list —
 * and every tower's targeting query that tick reads from the same buckets.
 */
class CollisionSystem(worldWidth: Float, worldHeight: Float) {

    private val cellSize = GameConfig.SPATIAL_CELL_SIZE
    private val cols = (worldWidth / cellSize).toInt() + 1
    private val rows = (worldHeight / cellSize).toInt() + 1
    private val buckets = Array(cols * rows) { ArrayList<Enemy>(8) }

    // Reused across queries so a targeting/splash/chain lookup never allocates a list.
    private val scratch = ArrayList<Enemy>(32)

    fun rebuild(enemies: List<Enemy>) {
        for (bucket in buckets) bucket.clear()
        for (enemy in enemies) {
            val col = (enemy.position.x / cellSize).toInt().coerceIn(0, cols - 1)
            val row = (enemy.position.y / cellSize).toInt().coerceIn(0, rows - 1)
            buckets[row * cols + col].add(enemy)
        }
    }

    /** Fills (and returns) a reused scratch list with every enemy within [radius] of [center]. */
    fun queryRadius(center: Vector2, radius: Float): List<Enemy> {
        scratch.clear()
        val radiusSquared = radius * radius
        val minCol = ((center.x - radius) / cellSize).toInt()
        val maxCol = ((center.x + radius) / cellSize).toInt()
        val minRow = ((center.y - radius) / cellSize).toInt()
        val maxRow = ((center.y + radius) / cellSize).toInt()

        for (row in minRow..maxRow) {
            if (row < 0 || row >= rows) continue
            for (col in minCol..maxCol) {
                if (col < 0 || col >= cols) continue
                val bucket = buckets[row * cols + col]
                for (enemy in bucket) {
                    if (center.distanceSquaredTo(enemy.position) <= radiusSquared) scratch.add(enemy)
                }
            }
        }
        return scratch
    }

    /** Picks the best target within [range] of [position] per [mode]. Null if nothing is in range. */
    fun findTarget(position: Vector2, range: Float, mode: TargetingMode): Enemy? {
        val candidates = queryRadius(position, range)
        if (candidates.isEmpty()) return null
        return when (mode) {
            TargetingMode.FIRST -> candidates.maxByOrNull { it.distanceTraveled }
            TargetingMode.STRONGEST -> candidates.maxByOrNull { it.currentHealth }
            TargetingMode.CLOSEST -> candidates.minByOrNull { position.distanceSquaredTo(it.position) }
        }
    }
}
