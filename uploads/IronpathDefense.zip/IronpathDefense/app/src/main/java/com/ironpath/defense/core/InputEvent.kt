package com.ironpath.defense.core

/** A raw touch tap, in screen (view) pixel coordinates, timestamped by the UI thread. */
data class InputEvent(val screenX: Float, val screenY: Float)

/**
 * Thread-safe hand-off point between the Android UI thread (where touch
 * events arrive via View.onTouchEvent) and the game thread (where the world
 * actually mutates state).
 *
 * Touch input on a SurfaceView-backed game is a classic cross-thread hazard:
 * the UI thread receives MotionEvents while the game loop thread is
 * concurrently reading/writing GameState. Rather than synchronizing every
 * touch against every tick, taps are queued here and drained once per
 * simulation step, so all gameplay mutation still happens on a single
 * thread (the game thread) and the queue itself is the only shared data.
 */
class InputQueue {
    private val pending = ArrayDeque<InputEvent>()
    private val lock = Any()

    fun offer(event: InputEvent) {
        synchronized(lock) { pending.addLast(event) }
    }

    /** Drains and returns all taps queued since the last call. Never allocates when empty. */
    fun drain(): List<InputEvent> {
        synchronized(lock) {
            if (pending.isEmpty()) return emptyList()
            val drained = ArrayList<InputEvent>(pending.size)
            drained.addAll(pending)
            pending.clear()
            return drained
        }
    }
}
