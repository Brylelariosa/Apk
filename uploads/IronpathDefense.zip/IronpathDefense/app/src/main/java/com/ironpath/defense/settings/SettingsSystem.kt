package com.ironpath.defense.settings

import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.save.SaveData

/**
 * In-memory player settings (music / SFX / damage numbers), kept in sync
 * with [AudioSystem] so a toggle takes effect immediately.
 *
 * Deliberately does not talk to SaveSystem itself — GameWorld, which already
 * coordinates every other cross-system side effect, decides *when* a changed
 * setting gets written to disk (alongside wave progress, in one SaveData).
 * This class only owns "what the current values are" and "make AudioSystem
 * match them."
 */
class SettingsSystem(private val audioSystem: AudioSystem) {

    var musicOn = true
        private set
    var sfxOn = true
        private set
    var showDamageNumbers = true
        private set

    fun loadFrom(data: SaveData) {
        musicOn = data.musicOn
        sfxOn = data.sfxOn
        showDamageNumbers = data.showDamageNumbers
        audioSystem.setMusicEnabled(musicOn)
        audioSystem.setSfxEnabled(sfxOn)
    }

    fun toggleMusic(): Boolean {
        musicOn = !musicOn
        audioSystem.setMusicEnabled(musicOn)
        return musicOn
    }

    fun toggleSfx(): Boolean {
        sfxOn = !sfxOn
        audioSystem.setSfxEnabled(sfxOn)
        return sfxOn
    }

    fun toggleDamageNumbers(): Boolean {
        showDamageNumbers = !showDamageNumbers
        return showDamageNumbers
    }
}
