package com.ironpath.defense.combat

import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy

/**
 * How combat systems report what just happened, so something else can turn
 * it into particles, numbers and sound. ProjectileSystem and TowerSystem
 * apply damage and statuses; they never spawn a spark or play a sound
 * themselves — they call this, and GameWorld wires in the implementation
 * (see engine/CombatEffects). Keeps simulation and presentation separate.
 */
interface CombatFeedback {
    /** An enemy just took a hit of [damageDealt] (after armor/marks). */
    fun onEnemyHit(enemy: Enemy, damageDealt: Float, isCrit: Boolean)

    /** A splash shot detonated at [center]. */
    fun onSplash(center: Vector2, radius: Float, colorArgb: Int)

    /** A chain shot jumped from [from] to [to]. */
    fun onChainLink(from: Vector2, to: Vector2, colorArgb: Int)

    /** A tower released a pulse nova. */
    fun onPulse(center: Vector2, radius: Float, colorArgb: Int)
}
