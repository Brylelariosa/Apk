package com.ironpath.defense.entity.tower

/**
 * Stats for one upgrade tier of one tower type. A tower's full progression
 * is just a `List<TowerTierStats>` on [TowerType] — adding a fourth tier to
 * any tower later is appending one entry, nothing else changes.
 *
 * Not every field applies to every tower; irrelevant ones sit at their
 * neutral default (0f, or 1f for [slowMultiplier] which multiplies speed).
 */
data class TowerTierStats(
    val damage: Float,
    val range: Float,
    val fireRateSeconds: Float,
    /** Cost to reach this tier from the previous one. 0 for tier 1 (that's [TowerType.baseCost] instead). */
    val upgradeCost: Int,
    val splashRadius: Float = 0f,
    val slowMultiplier: Float = 1f,
    val slowDurationSeconds: Float = 0f,
    val armorPenetration: Float = 0f,
    val chainCount: Int = 0,
    val chainRadius: Float = 0f,
    val chainDamageFalloff: Float = 1f
)
