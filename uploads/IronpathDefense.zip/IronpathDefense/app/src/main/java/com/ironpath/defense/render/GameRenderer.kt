package com.ironpath.defense.render

import android.graphics.Canvas
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.particle.ArcBolt
import com.ironpath.defense.entity.particle.DamageNumber
import com.ironpath.defense.entity.particle.FloatingText
import com.ironpath.defense.entity.particle.Particle
import com.ironpath.defense.entity.particle.ShockRing
import com.ironpath.defense.entity.projectile.Projectile
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.ui.HudRenderer
import com.ironpath.defense.ui.HudState
import com.ironpath.defense.ui.Palette
import com.ironpath.defense.ui.UiLayout

/**
 * Top-level render entry point, called once per real frame from GameView's
 * GameLoop. Clears the canvas, draws the battlefield (skipped on the main
 * menu screen, before anything is placed), then draws the HUD/overlay for
 * whatever [GameScreenState] the game is currently in.
 */
class GameRenderer(mapSystem: MapSystem) {

    private val worldRenderer = WorldRenderer(mapSystem)
    private val hudRenderer = HudRenderer()

    fun render(
        canvas: Canvas,
        layout: UiLayout,
        hudState: HudState,
        towers: List<Tower>,
        enemies: List<Enemy>,
        projectiles: List<Projectile>,
        particles: List<Particle>,
        damageNumbers: List<DamageNumber>,
        rings: List<ShockRing>,
        bolts: List<ArcBolt>,
        floatingTexts: List<FloatingText>
    ) {
        canvas.drawColor(Palette.VOID_BACKGROUND)

        if (hudState.screenState != GameScreenState.MAIN_MENU) {
            worldRenderer.drawWorld(
                canvas, layout, towers, enemies, projectiles, particles, damageNumbers,
                rings, bolts, floatingTexts,
                selectedTower = hudState.selectedTower,
                showDamageNumbers = hudState.showDamageNumbers,
                highlightBuildable = hudState.pendingTowerType != null
            )
        }

        hudRenderer.draw(canvas, layout, hudState)
    }
}
