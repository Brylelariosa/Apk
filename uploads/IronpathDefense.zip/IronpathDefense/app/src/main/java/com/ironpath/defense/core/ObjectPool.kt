package com.ironpath.defense.core

/**
 * A generic free-list object pool.
 *
 * Every churn-heavy entity in the game (enemies, projectiles, particles,
 * damage numbers) is obtained from a pool and freed back into it instead of
 * being allocated/garbage-collected every time it spawns or dies. This is
 * the single biggest allocation-avoidance lever available on low-end
 * hardware, where GC pauses are the most common cause of visible frame
 * hitches during a busy wave.
 *
 * @param initialCapacity how many instances to pre-allocate up front, so the
 *   very first wave doesn't pay an allocation burst mid-gameplay.
 * @param factory creates a brand-new instance (only called when the pool is
 *   empty and growing).
 * @param reset restores a reused instance to a clean default state before
 *   handing it back out via [obtain].
 */
class ObjectPool<T>(
    initialCapacity: Int,
    private val factory: () -> T,
    private val reset: (T) -> Unit
) {
    private val free = ArrayDeque<T>(initialCapacity)

    init {
        repeat(initialCapacity) { free.addLast(factory()) }
    }

    /** Number of instances sitting idle in the pool right now. */
    val freeCount: Int get() = free.size

    fun obtain(): T {
        val item = if (free.isEmpty()) factory() else free.removeLast()
        reset(item)
        return item
    }

    fun free(item: T) {
        free.addLast(item)
    }
}
