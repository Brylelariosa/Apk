package com.ironpath.defense.save

/** Everything persisted across app launches: progression + settings. */
data class SaveData(
    val highestWaveCompleted: Int = 0,
    val musicOn: Boolean = true,
    val sfxOn: Boolean = true,
    val showDamageNumbers: Boolean = true
)
