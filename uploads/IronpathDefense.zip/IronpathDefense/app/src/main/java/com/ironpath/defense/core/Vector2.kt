package com.ironpath.defense.core

import kotlin.math.sqrt

/**
 * A plain mutable 2D float vector used throughout the simulation.
 *
 * Deliberately a normal (non-data) mutable class: hot paths (enemy movement,
 * targeting, projectile flight) mutate positions in place every tick rather
 * than allocating a new Vector2 per frame per entity. `set(...)` is the
 * allocation-free way to update an existing instance.
 */
class Vector2(var x: Float = 0f, var y: Float = 0f) {

    fun set(newX: Float, newY: Float): Vector2 {
        x = newX
        y = newY
        return this
    }

    fun set(other: Vector2): Vector2 {
        x = other.x
        y = other.y
        return this
    }

    fun distanceSquaredTo(other: Vector2): Float {
        val dx = x - other.x
        val dy = y - other.y
        return dx * dx + dy * dy
    }

    fun distanceTo(other: Vector2): Float = sqrt(distanceSquaredTo(other))

    /** Moves this point toward [target] by at most [maxStep], returning the leftover distance if it overshot. */
    fun moveToward(target: Vector2, maxStep: Float) {
        val dx = target.x - x
        val dy = target.y - y
        val dist = sqrt(dx * dx + dy * dy)
        if (dist <= maxStep || dist == 0f) {
            x = target.x
            y = target.y
        } else {
            val inv = maxStep / dist
            x += dx * inv
            y += dy * inv
        }
    }

    fun copy(): Vector2 = Vector2(x, y)
}
