package com.ironpath.defense.entity.projectile

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.HitResolver
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy

/**
 * Owns every in-flight projectile: pooled spawning, per-tick movement, and
 * impact resolution (single-target / splash / chain).
 *
 * [spawn] hands back the pooled [Projectile] with a freshly-reset
 * [Projectile.shot] for the caller (TowerSystem) to fill in. That keeps this
 * package free of any dependency on tower stats — TowerType already depends
 * on ProjectileType, so the reverse dependency would be a cycle.
 *
 * Damage and status effects are applied through [HitResolver]; anything
 * visual or audible is reported through [CombatFeedback] and handled
 * elsewhere, so this class never knows particles or sound exist.
 */
class ProjectileSystem(
    private val collisionSystem: CollisionSystem,
    private val feedback: CombatFeedback
) {

    private val pool = ObjectPool(
        initialCapacity = 64,
        factory = { Projectile() },
        reset = { it.alive = false; it.homingTarget = null; it.shot.reset() }
    )
    private val activeList = ArrayList<Projectile>(128)
    val active: List<Projectile> get() = activeList

    /**
     * Launches a [type] projectile from [origin] toward [target]. The caller
     * must fill in the returned projectile's [Projectile.shot] before the
     * next update.
     */
    fun spawn(type: ProjectileType, origin: Vector2, target: Enemy): Projectile {
        val p = pool.obtain()
        p.type = type
        p.position.set(origin)
        p.targetPoint.set(target.position)
        p.alive = true

        if (type.isHoming) {
            p.homingTarget = target
            p.homingTargetGeneration = target.generation
        } else {
            p.homingTarget = null
        }

        val dx = target.position.x - origin.x
        val dy = target.position.y - origin.y
        val length = kotlin.math.sqrt(dx * dx + dy * dy)
        if (length > 0.001f) {
            p.dirX = dx / length
            p.dirY = dy / length
        }
        activeList.add(p)
        return p
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeList.size) {
            val p = activeList[i]

            val destination: Vector2? = if (p.type.isHoming) {
                if (p.isHomingTargetValid()) p.homingTarget!!.position else null
            } else {
                p.targetPoint
            }

            if (destination == null) {
                // Homing target died/was recycled mid-flight — this shot dissipates harmlessly.
                releaseAt(i)
                continue
            }

            val stepDistance = p.type.speed * dt
            val distance = p.position.distanceTo(destination)
            if (distance > 0.001f) {
                p.dirX = (destination.x - p.position.x) / distance
                p.dirY = (destination.y - p.position.y) / distance
            }

            if (distance <= stepDistance) {
                p.position.set(destination)
                resolveImpact(p)
                releaseAt(i)
                continue
            }
            p.position.moveToward(destination, stepDistance)
            i++
        }
    }

    private fun resolveImpact(p: Projectile) {
        when {
            p.shot.chainCount > 0 -> resolveChain(p)
            p.shot.splashRadius > 0f -> resolveSplash(p)
            else -> resolveSingleTarget(p)
        }
    }

    private fun resolveSingleTarget(p: Projectile) {
        val target = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: collisionSystem.queryRadius(p.position, IMPACT_SNAP_RADIUS).firstOrNull()
            ?: return // ballistic shot arrived and nothing is there anymore: a clean miss
        hit(target, p.shot, p.shot.damage)
    }

    private fun resolveSplash(p: Projectile) {
        feedback.onSplash(p.position, p.shot.splashRadius, p.shot.colorArgb)
        // Copy out of the shared query buffer before applying hits, since a hit
        // callback could (indirectly, via game logic elsewhere) trigger another query.
        val hits = ArrayList(collisionSystem.queryRadius(p.position, p.shot.splashRadius))
        for (enemy in hits) hit(enemy, p.shot, p.shot.damage)
    }

    private fun resolveChain(p: Projectile) {
        val alreadyHit = HashSet<Enemy>()
        var currentDamage = p.shot.damage
        var current: Enemy? = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: collisionSystem.queryRadius(p.position, IMPACT_SNAP_RADIUS).firstOrNull()

        var hitsRemaining = p.shot.chainCount + 1 // the primary hit counts as one
        while (current != null && hitsRemaining > 0) {
            val enemy = current
            alreadyHit += enemy
            hit(enemy, p.shot, currentDamage)
            hitsRemaining--
            if (hitsRemaining == 0) break

            val next = collisionSystem.queryRadius(enemy.position, p.shot.chainRadius)
                .firstOrNull { it !in alreadyHit }
            if (next != null) feedback.onChainLink(enemy.position, next.position, p.shot.colorArgb)
            current = next
            currentDamage *= p.shot.chainDamageFalloff
        }
    }

    private fun hit(enemy: Enemy, shot: ShotProfile, damage: Float) {
        val dealt = HitResolver.apply(enemy, shot, damage)
        feedback.onEnemyHit(enemy, dealt, shot.isCrit)
    }

    fun clear() {
        for (p in activeList) {
            p.alive = false
            p.homingTarget = null
            pool.free(p)
        }
        activeList.clear()
    }

    private fun releaseAt(index: Int) {
        val p = activeList[index]
        val lastIndex = activeList.size - 1
        activeList[index] = activeList[lastIndex]
        activeList.removeAt(lastIndex)
        p.alive = false
        p.homingTarget = null
        pool.free(p)
    }

    companion object {
        private const val IMPACT_SNAP_RADIUS = 20f
    }
}
