package com.ironpath.defense.entity.projectile

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy

/**
 * Owns every in-flight projectile: pooled spawning, per-tick movement, and
 * impact resolution (single-target / splash / chain).
 *
 * Deliberately takes plain values (type, origin, damage, ...) rather than a
 * `Tower` reference in [spawn] — TowerType already depends on ProjectileType
 * (a tower's definition names its projectile), so if ProjectileSystem also
 * depended on the tower package, the two entity packages would depend on
 * each other. TowerSystem (which already lives in the tower package) reads
 * `tower.stats` and passes the individual numbers across instead.
 */
class ProjectileSystem(private val collisionSystem: CollisionSystem) {

    private val pool = ObjectPool(
        initialCapacity = 64,
        factory = { Projectile() },
        reset = { it.alive = false; it.homingTarget = null }
    )
    private val activeList = ArrayList<Projectile>(128)
    val active: List<Projectile> get() = activeList

    fun spawn(
        type: ProjectileType,
        origin: Vector2,
        target: Enemy,
        damage: Float,
        armorPenetration: Float = 0f,
        splashRadius: Float = 0f,
        slowMultiplier: Float = 1f,
        slowDurationSeconds: Float = 0f,
        chainCount: Int = 0,
        chainRadius: Float = 0f,
        chainDamageFalloff: Float = 1f
    ) {
        val p = pool.obtain()
        p.type = type
        p.position.set(origin)
        p.damage = damage
        p.armorPenetration = armorPenetration
        p.splashRadius = splashRadius
        p.slowMultiplier = slowMultiplier
        p.slowDurationSeconds = slowDurationSeconds
        p.chainCount = chainCount
        p.chainRadius = chainRadius
        p.chainDamageFalloff = chainDamageFalloff
        p.alive = true

        if (type.isHoming) {
            p.homingTarget = target
            p.homingTargetGeneration = target.generation
            p.targetPoint.set(target.position)
        } else {
            p.homingTarget = null
            p.targetPoint.set(target.position)
        }
        activeList.add(p)
    }

    /**
     * Advances every projectile. [onHit] fires once per enemy actually
     * damaged (primary/splash/chain) so the caller can spawn damage numbers
     * and particles — ProjectileSystem only applies damage, it doesn't know
     * about rewards, particles, or rendering.
     */
    fun update(dt: Float, onHit: (Enemy, damageDealt: Float) -> Unit) {
        var i = 0
        while (i < activeList.size) {
            val p = activeList[i]

            val destination: Vector2? = if (p.type.isHoming) {
                if (p.isHomingTargetValid()) p.homingTarget!!.position else null
            } else {
                p.targetPoint
            }

            if (destination == null) {
                // Homing target died/was recycled mid-flight — this shot dissipates harmlessly.
                releaseAt(i)
                continue
            }

            val stepDistance = p.type.speed * dt
            if (p.position.distanceTo(destination) <= stepDistance) {
                p.position.set(destination)
                resolveImpact(p, onHit)
                releaseAt(i)
                continue
            }
            p.position.moveToward(destination, stepDistance)
            i++
        }
    }

    private fun resolveImpact(p: Projectile, onHit: (Enemy, Float) -> Unit) {
        when {
            p.chainCount > 0 -> resolveChain(p, onHit)
            p.splashRadius > 0f -> resolveSplash(p, onHit)
            else -> resolveSingleTarget(p, onHit)
        }
    }

    private fun resolveSingleTarget(p: Projectile, onHit: (Enemy, Float) -> Unit) {
        val target = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: collisionSystem.queryRadius(p.position, IMPACT_SNAP_RADIUS).firstOrNull()
            ?: return // ballistic shot arrived and nothing is there anymore: a clean miss
        applyHit(target, p.damage, p.armorPenetration, p.slowMultiplier, p.slowDurationSeconds, onHit)
    }

    private fun resolveSplash(p: Projectile, onHit: (Enemy, Float) -> Unit) {
        // Copy out of the shared query buffer before applying hits, since applyHit's
        // callback could (indirectly, via game logic elsewhere) trigger another query.
        val hits = ArrayList(collisionSystem.queryRadius(p.position, p.splashRadius))
        for (enemy in hits) {
            applyHit(enemy, p.damage, p.armorPenetration, p.slowMultiplier, p.slowDurationSeconds, onHit)
        }
    }

    private fun resolveChain(p: Projectile, onHit: (Enemy, Float) -> Unit) {
        val alreadyHit = HashSet<Enemy>()
        var currentDamage = p.damage
        var current: Enemy? = p.homingTarget?.takeIf { p.isHomingTargetValid() }
            ?: collisionSystem.queryRadius(p.position, IMPACT_SNAP_RADIUS).firstOrNull()

        var hitsRemaining = p.chainCount + 1 // the primary hit counts as one
        while (current != null && hitsRemaining > 0) {
            val enemy = current
            alreadyHit += enemy
            applyHit(enemy, currentDamage, p.armorPenetration, p.slowMultiplier, p.slowDurationSeconds, onHit)
            hitsRemaining--
            if (hitsRemaining == 0) break

            val nearby = collisionSystem.queryRadius(enemy.position, p.chainRadius)
            current = nearby.firstOrNull { it !in alreadyHit }
            currentDamage *= p.chainDamageFalloff
        }
    }

    private fun applyHit(
        enemy: Enemy,
        damage: Float,
        armorPenetration: Float,
        slowMultiplier: Float,
        slowDurationSeconds: Float,
        onHit: (Enemy, Float) -> Unit
    ) {
        val dealt = enemy.applyDamage(damage, armorPenetration)
        if (slowDurationSeconds > 0f) enemy.applySlow(slowMultiplier, slowDurationSeconds)
        onHit(enemy, dealt)
    }

    fun clear() {
        for (p in activeList) {
            p.alive = false
            p.homingTarget = null
            pool.free(p)
        }
        activeList.clear()
    }

    private fun releaseAt(index: Int) {
        val p = activeList[index]
        val lastIndex = activeList.size - 1
        activeList[index] = activeList[lastIndex]
        activeList.removeAt(lastIndex)
        p.alive = false
        p.homingTarget = null
        pool.free(p)
    }

    companion object {
        private const val IMPACT_SNAP_RADIUS = 20f
    }
}
