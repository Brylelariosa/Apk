package com.ironpath.defense.entity.enemy

/**
 * Data-driven definition of one enemy archetype. Adding a new enemy type is
 * adding one enum constant here — no other file needs to change (EnemySystem,
 * the renderer, and wave definitions all work purely in terms of EnemyKind).
 *
 * @param baseHealth / baseSpeed / baseReward stats at wave 1, before
 *   EnemySystem applies per-wave scaling.
 * @param armor flat damage reduction per hit (see [Enemy.applyDamage]).
 * @param radius collision/visual radius in world units.
 * @param colorArgb this type's distinguishing render color.
 * @param regenPerSecond fraction of max health regenerated per second once
 *   [com.ironpath.defense.core.GameConfig.REGEN_GRACE_PERIOD_SECONDS] has
 *   passed since the last hit taken. Zero for every type except Regenerator.
 * @param slowResistance 0 = affected normally by Frost-style slows, 1 =
 *   fully immune. Only the Boss has partial resistance.
 */
enum class EnemyKind(
    val displayName: String,
    val baseHealth: Float,
    val baseSpeed: Float,
    val baseReward: Int,
    val armor: Float,
    val radius: Float,
    val colorArgb: Int,
    val regenPerSecond: Float = 0f,
    val slowResistance: Float = 0f
) {
    BASIC(displayName = "Basic", baseHealth = 40f, baseSpeed = 90f, baseReward = 8, armor = 0f, radius = 18f, colorArgb = 0xFFC97B4A.toInt()),
    FAST(displayName = "Fast", baseHealth = 24f, baseSpeed = 170f, baseReward = 6, armor = 0f, radius = 14f, colorArgb = 0xFFE3C23C.toInt()),
    ARMORED(displayName = "Armored", baseHealth = 90f, baseSpeed = 55f, baseReward = 14, armor = 8f, radius = 20f, colorArgb = 0xFF7C8591.toInt()),
    SWARM(displayName = "Swarm", baseHealth = 14f, baseSpeed = 100f, baseReward = 3, armor = 0f, radius = 11f, colorArgb = 0xFFB25FA0.toInt()),
    REGENERATOR(displayName = "Regenerator", baseHealth = 70f, baseSpeed = 70f, baseReward = 16, armor = 2f, radius = 19f, colorArgb = 0xFF4CAF7D.toInt(), regenPerSecond = 0.04f),
    BOSS(displayName = "Boss", baseHealth = 1400f, baseSpeed = 45f, baseReward = 150, armor = 12f, radius = 34f, colorArgb = 0xFF7A2E3B.toInt(), slowResistance = 0.5f)
}
