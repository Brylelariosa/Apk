package com.ironpath.defense.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.particle.ArcBolt
import com.ironpath.defense.entity.particle.DamageNumber
import com.ironpath.defense.entity.particle.FloatingText
import com.ironpath.defense.entity.particle.Particle
import com.ironpath.defense.entity.particle.ShockRing
import com.ironpath.defense.entity.projectile.Projectile
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.map.TileKind
import com.ironpath.defense.ui.Palette
import com.ironpath.defense.ui.UiLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Draws the battlefield edge to edge: terrain (with scenery filling whatever
 * the map's aspect ratio leaves over), towers that visibly evolve with their
 * upgrades, enemies with their status effects, projectiles with trails, and
 * every cosmetic effect — all in world space, mapped to screen space via
 * [UiLayout]'s viewport transform.
 *
 * Every Paint used here is a field allocated once, never per-draw-call. The
 * static terrain layer is rendered to a full-screen offscreen bitmap once —
 * on first use and again only if the viewport changes — rather than redrawn
 * as hundreds of individual tile rects every frame.
 */
class WorldRenderer(private val mapSystem: MapSystem) {

    private val bitmapPaint = Paint()
    private val towerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val platePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF20262D.toInt() }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barrelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val barBackgroundPaint = Paint().apply { color = 0xFF14181D.toInt() }
    private val barFillPaint = Paint()
    private val selectionRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = 0xFFFFFFFF.toInt()
    }
    private val rangeFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rangeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val highlightPaint = Paint().apply { color = Palette.PLACEMENT_HIGHLIGHT }

    private val enemyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slowRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = 0xFFBFF3EF.toInt()
    }
    private val icePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88BFF3EF.toInt() }
    private val flamePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.DANGER }
    private val markPath = Path()
    private val healthBarBackgroundPaint = Paint().apply { color = Palette.HEALTH_BAR_BACKGROUND }
    private val healthBarFillPaint = Paint()

    private val projectilePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val critRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = 0xFFFFFFFF.toInt()
    }

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val boltGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
    }
    private val boltCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
    }
    private val damageNumberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val floatingTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val floatingShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var terrainBitmap: Bitmap? = null
    private var terrainWidth = -1
    private var terrainHeight = -1
    private var terrainScale = -1f
    private var terrainOffsetX = Float.NaN
    private var terrainOffsetY = Float.NaN

    fun drawWorld(
        canvas: Canvas,
        layout: UiLayout,
        towers: List<Tower>,
        enemies: List<Enemy>,
        projectiles: List<Projectile>,
        particles: List<Particle>,
        damageNumbers: List<DamageNumber>,
        rings: List<ShockRing>,
        bolts: List<ArcBolt>,
        floatingTexts: List<FloatingText>,
        selectedTower: Tower?,
        showDamageNumbers: Boolean,
        highlightBuildable: Boolean
    ) {
        // Before the first layout pass the surface size is still zero — nothing sensible to draw yet.
        if (layout.screenWidth < 1f || layout.screenHeight < 1f) return

        val time = animationSeconds()

        canvas.save()
        canvas.clipRect(layout.battlefield)

        drawTerrain(canvas, layout)
        if (highlightBuildable) drawBuildableHighlight(canvas, layout)
        if (selectedTower != null) drawRange(canvas, layout, selectedTower)

        for (tower in towers) drawTower(canvas, layout, tower, isSelected = tower === selectedTower, time = time)
        for (enemy in enemies) drawEnemy(canvas, layout, enemy, time)
        for (ring in rings) drawRing(canvas, layout, ring)
        for (projectile in projectiles) drawProjectile(canvas, layout, projectile)
        for (bolt in bolts) drawBolt(canvas, layout, bolt)
        for (particle in particles) drawParticle(canvas, layout, particle)
        if (showDamageNumbers) for (number in damageNumbers) drawDamageNumber(canvas, layout, number)
        for (text in floatingTexts) drawFloatingText(canvas, layout, text)

        canvas.restore()
    }

    // --- Terrain ---------------------------------------------------------------

    private fun drawTerrain(canvas: Canvas, layout: UiLayout) {
        val bitmap = getOrBuildTerrainBitmap(layout)
        canvas.drawBitmap(bitmap, 0f, 0f, bitmapPaint)
    }

    private fun getOrBuildTerrainBitmap(layout: UiLayout): Bitmap {
        val width = layout.screenWidth.toInt().coerceAtLeast(1)
        val height = layout.screenHeight.toInt().coerceAtLeast(1)

        terrainBitmap?.let {
            if (terrainWidth == width && terrainHeight == height &&
                terrainScale == layout.worldScale &&
                terrainOffsetX == layout.worldOffsetX && terrainOffsetY == layout.worldOffsetY
            ) return it
        }
        terrainBitmap?.recycle()

        // Opaque terrain never needs an alpha channel — RGB_565 halves the memory of ARGB_8888.
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        paintTerrain(Canvas(bitmap), layout, width, height)

        terrainBitmap = bitmap
        terrainWidth = width
        terrainHeight = height
        terrainScale = layout.worldScale
        terrainOffsetX = layout.worldOffsetX
        terrainOffsetY = layout.worldOffsetY
        return bitmap
    }

    /**
     * Paints the playable grid plus scenery out to every screen edge. Tiles
     * outside the grid are forest, except that the road keeps running off
     * screen where the path enters and leaves, so the map looks like a
     * slice of a bigger world rather than a box with padding.
     */
    private fun paintTerrain(offscreen: Canvas, layout: UiLayout, width: Int, height: Int) {
        val tile = layout.worldToScreenLength(GameConfig.TILE_SIZE).coerceAtLeast(1f)
        val originX = layout.worldToScreenX(0f)
        val originY = layout.worldToScreenY(0f)

        val firstCol = floor(-originX / tile).toInt()
        val lastCol = ceil((width - originX) / tile).toInt()
        val firstRow = floor(-originY / tile).toInt()
        val lastRow = ceil((height - originY) / tile).toInt()

        val tilePaint = Paint()
        val treePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.FOREST_TREE }

        for (row in firstRow..lastRow) {
            for (col in firstCol..lastCol) {
                tilePaint.color = tileColor(col, row)
                val left = originX + col * tile
                val top = originY + row * tile
                // +1px avoids hairline gaps between adjacent tiles from float rounding.
                offscreen.drawRect(left, top, left + tile + 1f, top + tile + 1f, tilePaint)

                if (isScenery(col, row) && ((col * 7 + row * 13) and 3) != 0) {
                    offscreen.drawCircle(left + tile / 2f, top + tile / 2f, tile * 0.30f, treePaint)
                }
            }
        }

        // Spawn gate where enemies come in, base gate where they leave.
        val waypoints = mapSystem.map.tileWaypoints
        val gateWidth = tile * 0.16f
        val gridRight = originX + GameConfig.GRID_COLS * tile
        tilePaint.color = Palette.GATE_SPAWN
        val entryRow = waypoints.first().second
        offscreen.drawRect(
            originX - gateWidth / 2f, originY + entryRow * tile,
            originX + gateWidth / 2f, originY + (entryRow + 1) * tile, tilePaint
        )
        tilePaint.color = Palette.GATE_BASE
        val exitRow = waypoints.last().second
        offscreen.drawRect(
            gridRight - gateWidth / 2f, originY + exitRow * tile,
            gridRight + gateWidth / 2f, originY + (exitRow + 1) * tile, tilePaint
        )

        // A faint edge so the playable area reads clearly against the scenery.
        val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = 0x33FFFFFF
        }
        offscreen.drawRect(originX, originY, gridRight, originY + GameConfig.GRID_ROWS * tile, edgePaint)
    }

    private fun isInsideGrid(col: Int, row: Int) =
        col in 0 until GameConfig.GRID_COLS && row in 0 until GameConfig.GRID_ROWS

    /** Outside the grid and not part of the road running off screen. */
    private fun isScenery(col: Int, row: Int): Boolean = !isInsideGrid(col, row) && !isRoadExtension(col, row)

    private fun isRoadExtension(col: Int, row: Int): Boolean {
        val waypoints = mapSystem.map.tileWaypoints
        return (col < 0 && row == waypoints.first().second) ||
            (col >= GameConfig.GRID_COLS && row == waypoints.last().second)
    }

    private fun tileColor(col: Int, row: Int): Int {
        val alt = ((col + row) and 1) == 0
        if (isInsideGrid(col, row)) {
            return when (mapSystem.tileGrid.kindAt(col, row)) {
                TileKind.PATH -> if (alt) Palette.PATH_STONE else Palette.PATH_STONE_ALT
                TileKind.BUILDABLE -> if (alt) Palette.BUILDABLE_GROUND else Palette.BUILDABLE_GROUND_ALT
                TileKind.BLOCKED -> Palette.BLOCKED_GROUND
            }
        }
        if (isRoadExtension(col, row)) return if (alt) Palette.PATH_STONE else Palette.PATH_STONE_ALT
        return if (alt) Palette.FOREST else Palette.FOREST_ALT
    }

    /** While a tower type is armed, lights every tile it could be built on. */
    private fun drawBuildableHighlight(canvas: Canvas, layout: UiLayout) {
        val grid = mapSystem.tileGrid
        val tile = layout.worldToScreenLength(GameConfig.TILE_SIZE)
        for (row in 0 until GameConfig.GRID_ROWS) {
            for (col in 0 until GameConfig.GRID_COLS) {
                if (!grid.canPlaceTower(col, row)) continue
                val left = layout.worldToScreenX(col * GameConfig.TILE_SIZE)
                val top = layout.worldToScreenY(row * GameConfig.TILE_SIZE)
                canvas.drawRect(left + 2f, top + 2f, left + tile - 2f, top + tile - 2f, highlightPaint)
            }
        }
    }

    // --- Towers ------------------------------------------------------------------

    private fun drawRange(canvas: Canvas, layout: UiLayout, tower: Tower) {
        val cx = layout.worldToScreenX(tower.position.x)
        val cy = layout.worldToScreenY(tower.position.y)
        val radius = layout.worldToScreenLength(tower.stats.range)
        val accent = tower.accentColorArgb
        rangeFillPaint.color = withAlpha(accent, 34)
        canvas.drawCircle(cx, cy, radius, rangeFillPaint)
        rangeStrokePaint.color = withAlpha(accent, 150)
        canvas.drawCircle(cx, cy, radius, rangeStrokePaint)
    }

    /**
     * A tower's look tracks its build: the body grows a little per upgrade,
     * an accent core appears in its dominant path's color, the barrel turns
     * to face what it's shooting, a glowing aura fades in from tier 3, and a
     * fully-upgraded path adds orbiting sparks.
     */
    private fun drawTower(canvas: Canvas, layout: UiLayout, tower: Tower, isSelected: Boolean, time: Float) {
        val cx = layout.worldToScreenX(tower.position.x)
        val cy = layout.worldToScreenY(tower.position.y)
        val tile = layout.worldToScreenLength(GameConfig.TILE_SIZE)
        val upgrades = tower.totalUpgrades
        val radius = tile * 0.30f * (1f + 0.018f * upgrades)
        val accent = tower.accentColorArgb
        val dominant = tower.dominantPath
        val dominantTier = if (dominant < 0) 0 else tower.pathTiers[dominant]

        if (dominantTier >= 3) {
            val pulse = 0.5f + 0.5f * sin(time * 3f)
            auraPaint.color = withAlpha(accent, 38 + (32f * pulse).toInt() + (dominantTier - 3) * 14)
            canvas.drawCircle(cx, cy, radius * (1.55f + 0.10f * pulse), auraPaint)
        }

        val plate = radius * 1.15f
        canvas.drawRoundRect(cx - plate, cy - plate, cx + plate, cy + plate, radius * 0.3f, radius * 0.3f, platePaint)

        towerPaint.color = tower.type.colorArgb
        canvas.drawRoundRect(cx - radius, cy - radius, cx + radius, cy + radius, radius * 0.25f, radius * 0.25f, towerPaint)

        if (upgrades > 0) {
            accentPaint.color = accent
            val core = radius * 0.58f
            canvas.drawRoundRect(cx - core, cy - core, cx + core, cy + core, core * 0.3f, core * 0.3f, accentPaint)
        }

        val barrelLength = radius * 1.25f
        barrelPaint.strokeWidth = radius * 0.42f
        barrelPaint.color = if (upgrades > 0) accent else 0xFFE8E4D8.toInt()
        val tipX = cx + tower.aimX * barrelLength
        val tipY = cy + tower.aimY * barrelLength
        canvas.drawLine(cx, cy, tipX, tipY, barrelPaint)

        canvas.drawCircle(cx, cy, radius * 0.38f, platePaint)

        if (tower.flashRemaining > 0f) {
            flashPaint.color = withAlpha(accent, 120)
            canvas.drawCircle(tipX, tipY, radius * 0.75f, flashPaint)
            flashPaint.color = 0xFFFFFFFF.toInt()
            canvas.drawCircle(tipX, tipY, radius * 0.36f, flashPaint)
        }

        if (dominantTier >= UpgradeRules.MAX_TIER) {
            for (k in 0 until 3) {
                val angle = time * 2.2f + k * 2.0944f
                canvas.drawCircle(
                    cx + cos(angle) * radius * 1.65f, cy + sin(angle) * radius * 1.65f,
                    radius * 0.14f, orbitPaint
                )
            }
        }

        if (upgrades > 0) drawPathBars(canvas, tower, cx, cy, radius)

        if (isSelected) canvas.drawCircle(cx, cy, radius * 1.5f, selectionRingPaint)
    }

    /** Three tiny meters under the tower, one per path, filled by how far up that path it is. */
    private fun drawPathBars(canvas: Canvas, tower: Tower, cx: Float, cy: Float, radius: Float) {
        val barWidth = radius * 0.66f
        val gap = radius * 0.12f
        val barHeight = radius * 0.17f
        val totalWidth = barWidth * 3f + gap * 2f
        val top = cy + radius * 1.32f
        var left = cx - totalWidth / 2f
        for (path in 0 until UpgradeRules.PATH_COUNT) {
            canvas.drawRect(left, top, left + barWidth, top + barHeight, barBackgroundPaint)
            val tier = tower.pathTiers[path]
            if (tier > 0) {
                barFillPaint.color = tower.type.paths[path].colorArgb
                canvas.drawRect(left, top, left + barWidth * tier / UpgradeRules.MAX_TIER, top + barHeight, barFillPaint)
            }
            left += barWidth + gap
        }
    }

    // --- Enemies -----------------------------------------------------------------

    private fun drawEnemy(canvas: Canvas, layout: UiLayout, enemy: Enemy, time: Float) {
        val screenX = layout.worldToScreenX(enemy.position.x)
        val screenY = layout.worldToScreenY(enemy.position.y)
        val radius = layout.worldToScreenLength(enemy.radius)

        enemyPaint.color = enemy.kind.colorArgb
        canvas.drawCircle(screenX, screenY, radius, enemyPaint)

        if (enemy.isStunned) {
            canvas.drawCircle(screenX, screenY, radius + 2f, icePaint)
            canvas.drawCircle(screenX, screenY, radius + 3f, slowRingPaint)
        } else if (enemy.slowTimeRemaining > 0f) {
            canvas.drawCircle(screenX, screenY, radius + 3f, slowRingPaint)
        }

        if (enemy.isBurning) {
            flamePaint.color = withAlpha(enemy.burnColorArgb, 205)
            for (i in 0 until 3) {
                val phase = time * 11f + i * 2.1f
                val flameX = screenX + sin(phase) * radius * 0.55f
                val flameY = screenY - radius * 0.35f - abs(sin(phase * 0.7f)) * radius * 0.6f
                canvas.drawCircle(flameX, flameY, radius * 0.26f * (0.75f + 0.25f * cos(phase)), flamePaint)
            }
        }

        val barWidth = radius * 2.2f
        val barHeight = layout.worldToScreenLength(5f)
        val barLeft = screenX - barWidth / 2f
        val barTop = screenY - radius - barHeight - 4f
        canvas.drawRect(barLeft, barTop, barLeft + barWidth, barTop + barHeight, healthBarBackgroundPaint)

        val healthFraction = (enemy.currentHealth / enemy.maxHealth).coerceIn(0f, 1f)
        healthBarFillPaint.color = if (healthFraction > 0.35f) Palette.HEALTH_BAR_FILL else Palette.HEALTH_BAR_FILL_LOW
        canvas.drawRect(barLeft, barTop, barLeft + barWidth * healthFraction, barTop + barHeight, healthBarFillPaint)

        if (enemy.isMarked) {
            // A small downward triangle over the health bar: "this one takes extra damage".
            val size = barHeight * 1.6f
            val tipY = barTop - 2f
            markPath.reset()
            markPath.moveTo(screenX - size, tipY - size * 1.4f)
            markPath.lineTo(screenX + size, tipY - size * 1.4f)
            markPath.lineTo(screenX, tipY)
            markPath.close()
            canvas.drawPath(markPath, markPaint)
        }
    }

    // --- Projectiles and effects -----------------------------------------------------

    private fun drawProjectile(canvas: Canvas, layout: UiLayout, projectile: Projectile) {
        val screenX = layout.worldToScreenX(projectile.position.x)
        val screenY = layout.worldToScreenY(projectile.position.y)
        val type = projectile.type
        val shot = projectile.shot
        val radius = layout.worldToScreenLength(type.radius) * (if (shot.isCrit) 1.6f else 1f)
        val trailLength = layout.worldToScreenLength(if (type.isHoming) 20f else 28f)

        trailPaint.color = withAlpha(shot.colorArgb, 150)
        trailPaint.strokeWidth = radius * 1.5f
        canvas.drawLine(
            screenX, screenY,
            screenX - projectile.dirX * trailLength, screenY - projectile.dirY * trailLength,
            trailPaint
        )

        if (shot.burnDps > 0f) {
            haloPaint.color = withAlpha(shot.burnColorArgb, 130)
            canvas.drawCircle(screenX, screenY, radius * 2.1f, haloPaint)
        }

        projectilePaint.color = type.colorArgb
        canvas.drawCircle(screenX, screenY, radius, projectilePaint)

        if (shot.isCrit) canvas.drawCircle(screenX, screenY, radius * 1.5f, critRingPaint)
    }

    private fun drawRing(canvas: Canvas, layout: UiLayout, ring: ShockRing) {
        ringPaint.color = withAlpha(ring.colorArgb, (ring.lifeFraction() * 230f).toInt())
        ringPaint.strokeWidth = layout.worldToScreenLength(ring.strokeWidth).coerceAtLeast(1.5f)
        canvas.drawCircle(
            layout.worldToScreenX(ring.position.x), layout.worldToScreenY(ring.position.y),
            layout.worldToScreenLength(ring.currentRadius()), ringPaint
        )
    }

    /** A jagged bolt: a few segments with random sideways jitter, redrawn each frame so it crackles. */
    private fun drawBolt(canvas: Canvas, layout: UiLayout, bolt: ArcBolt) {
        val x1 = layout.worldToScreenX(bolt.from.x)
        val y1 = layout.worldToScreenY(bolt.from.y)
        val x2 = layout.worldToScreenX(bolt.to.x)
        val y2 = layout.worldToScreenY(bolt.to.y)
        val dx = x2 - x1
        val dy = y2 - y1
        val length = sqrt(dx * dx + dy * dy)
        if (length < 1f) return

        val normalX = -dy / length
        val normalY = dx / length
        val jitter = length * 0.08f
        val fade = bolt.lifeFraction()

        boltGlowPaint.color = withAlpha(bolt.colorArgb, (fade * 130f).toInt())
        boltGlowPaint.strokeWidth = layout.worldToScreenLength(7f)
        boltCorePaint.color = withAlpha(0xFFFFFFFF.toInt(), (fade * 255f).toInt())
        boltCorePaint.strokeWidth = layout.worldToScreenLength(2.4f).coerceAtLeast(1.5f)

        var previousX = x1
        var previousY = y1
        for (i in 1..BOLT_SEGMENTS) {
            val t = i.toFloat() / BOLT_SEGMENTS
            var pointX = x1 + dx * t
            var pointY = y1 + dy * t
            if (i < BOLT_SEGMENTS) {
                val offset = (Random.nextFloat() - 0.5f) * 2f * jitter
                pointX += normalX * offset
                pointY += normalY * offset
            }
            canvas.drawLine(previousX, previousY, pointX, pointY, boltGlowPaint)
            canvas.drawLine(previousX, previousY, pointX, pointY, boltCorePaint)
            previousX = pointX
            previousY = pointY
        }
    }

    private fun drawParticle(canvas: Canvas, layout: UiLayout, particle: Particle) {
        val screenX = layout.worldToScreenX(particle.position.x)
        val screenY = layout.worldToScreenY(particle.position.y)
        val fraction = particle.lifeFraction()
        particlePaint.color = particle.colorArgb
        particlePaint.alpha = (fraction * 255).toInt().coerceIn(0, 255)
        canvas.drawCircle(screenX, screenY, layout.worldToScreenLength(particle.startRadius) * fraction, particlePaint)
    }

    private fun drawDamageNumber(canvas: Canvas, layout: UiLayout, number: DamageNumber) {
        val screenX = layout.worldToScreenX(number.position.x)
        val screenY = layout.worldToScreenY(number.position.y)
        damageNumberPaint.color = if (number.isCrit) CRIT_NUMBER_COLOR else Palette.TEXT_PRIMARY
        damageNumberPaint.alpha = (number.lifeFraction() * 255).toInt().coerceIn(0, 255)
        damageNumberPaint.textSize = layout.worldToScreenLength(if (number.isCrit) 30f else 20f)
        val label = if (number.isCrit) "-${number.value}!" else "-${number.value}"
        canvas.drawText(label, screenX, screenY, damageNumberPaint)
    }

    private fun drawFloatingText(canvas: Canvas, layout: UiLayout, text: FloatingText) {
        val screenX = layout.worldToScreenX(text.position.x)
        val screenY = layout.worldToScreenY(text.position.y)
        val alpha = (text.lifeFraction() * 2f).coerceAtMost(1f)
        val size = layout.worldToScreenLength(17f)

        floatingShadowPaint.textSize = size
        floatingShadowPaint.color = withAlpha(0xFF000000.toInt(), (alpha * 200f).toInt())
        canvas.drawText(text.text, screenX + 2f, screenY + 2f, floatingShadowPaint)

        floatingTextPaint.textSize = size
        floatingTextPaint.color = withAlpha(text.colorArgb, (alpha * 255f).toInt())
        canvas.drawText(text.text, screenX, screenY, floatingTextPaint)
    }

    // --- Helpers -------------------------------------------------------------------------

    /** Seconds on a clock that wraps every ten minutes — small enough to keep float precision for animation phases. */
    private fun animationSeconds(): Float = ((System.nanoTime() / 1_000_000L) % 600_000L) / 1000f

    private fun withAlpha(colorArgb: Int, alpha: Int): Int =
        (colorArgb and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private companion object {
        const val BOLT_SEGMENTS = 5
        val CRIT_NUMBER_COLOR: Int = 0xFFFFD35A.toInt()
    }
}
