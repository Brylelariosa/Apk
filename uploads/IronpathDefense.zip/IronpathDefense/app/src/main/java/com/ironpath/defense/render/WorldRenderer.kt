package com.ironpath.defense.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.particle.DamageNumber
import com.ironpath.defense.entity.particle.Particle
import com.ironpath.defense.entity.projectile.Projectile
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.map.TileKind
import com.ironpath.defense.ui.Palette
import com.ironpath.defense.ui.UiLayout

/**
 * Draws the battlefield: terrain, towers, enemies (with health bars),
 * projectiles, and particles/damage numbers — everything in world space,
 * mapped to screen space via [UiLayout]'s viewport transform.
 *
 * Every Paint used here is a field allocated once, never per-draw-call. The
 * static terrain layer (tile colors never change; only occupancy does, and
 * occupancy isn't drawn) is rendered to an offscreen bitmap once — on first
 * use and again only if the viewport is resized — rather than redrawn as
 * ~220 individual tile rects every frame. This is the same "cache
 * frequently used textures, don't repeatedly redo static work" principle
 * the spec asks for, applied to procedurally-drawn content instead of a
 * decoded image asset.
 */
class WorldRenderer(private val mapSystem: MapSystem) {

    private val bitmapPaint = Paint()
    private val towerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rangeCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Palette.RANGE_CIRCLE_STROKE
    }
    private val enemyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slowRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = 0xFFBFF3EF.toInt()
    }
    private val healthBarBackgroundPaint = Paint().apply { color = Palette.HEALTH_BAR_BACKGROUND }
    private val healthBarFillPaint = Paint()
    private val projectilePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val damageNumberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var terrainBitmap: Bitmap? = null
    private var terrainBitmapWidth = -1
    private var terrainBitmapHeight = -1

    fun drawWorld(
        canvas: Canvas,
        layout: UiLayout,
        towers: List<Tower>,
        enemies: List<Enemy>,
        projectiles: List<Projectile>,
        particles: List<Particle>,
        damageNumbers: List<DamageNumber>,
        selectedTower: Tower?,
        showDamageNumbers: Boolean
    ) {
        canvas.save()
        canvas.clipRect(layout.battlefield)

        drawTerrain(canvas, layout)
        for (tower in towers) drawTower(canvas, layout, tower, isSelected = tower === selectedTower)
        for (enemy in enemies) drawEnemy(canvas, layout, enemy)
        for (projectile in projectiles) drawProjectile(canvas, layout, projectile)
        for (particle in particles) drawParticle(canvas, layout, particle)
        if (showDamageNumbers) for (number in damageNumbers) drawDamageNumber(canvas, layout, number)

        canvas.restore()
    }

    private fun drawTerrain(canvas: Canvas, layout: UiLayout) {
        val bitmap = getOrBuildTerrainBitmap(layout)
        canvas.drawBitmap(bitmap, layout.battlefield.left, layout.battlefield.top, bitmapPaint)
    }

    private fun getOrBuildTerrainBitmap(layout: UiLayout): Bitmap {
        val width = layout.battlefield.width().toInt().coerceAtLeast(1)
        val height = layout.battlefield.height().toInt().coerceAtLeast(1)

        terrainBitmap?.let { if (terrainBitmapWidth == width && terrainBitmapHeight == height) return it }

        // Opaque terrain never needs an alpha channel — RGB_565 halves the memory of ARGB_8888.
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        val offscreen = Canvas(bitmap)
        val grid = mapSystem.tileGrid
        val tilePaint = Paint()
        val tileScreenSize = layout.worldToScreenLength(GameConfig.TILE_SIZE)

        for (row in 0 until GameConfig.GRID_ROWS) {
            for (col in 0 until GameConfig.GRID_COLS) {
                tilePaint.color = when (grid.kindAt(col, row)) {
                    TileKind.PATH -> Palette.PATH_STONE
                    TileKind.BUILDABLE -> Palette.BUILDABLE_GROUND
                    TileKind.BLOCKED -> Palette.BLOCKED_GROUND
                }
                val left = layout.worldToScreenX(col * GameConfig.TILE_SIZE) - layout.battlefield.left
                val top = layout.worldToScreenY(row * GameConfig.TILE_SIZE) - layout.battlefield.top
                // +1px avoids hairline gaps between adjacent tiles from float rounding.
                offscreen.drawRect(left, top, left + tileScreenSize + 1f, top + tileScreenSize + 1f, tilePaint)
            }
        }

        terrainBitmap = bitmap
        terrainBitmapWidth = width
        terrainBitmapHeight = height
        return bitmap
    }

    private fun drawTower(canvas: Canvas, layout: UiLayout, tower: Tower, isSelected: Boolean) {
        val screenX = layout.worldToScreenX(tower.position.x)
        val screenY = layout.worldToScreenY(tower.position.y)
        val baseRadius = layout.worldToScreenLength(GameConfig.TILE_SIZE * 0.32f)
        val radius = baseRadius * (1f + 0.12f * (tower.tier - 1))

        if (isSelected) {
            canvas.drawCircle(screenX, screenY, layout.worldToScreenLength(tower.stats.range), rangeCirclePaint)
        }

        towerPaint.color = tower.type.colorArgb
        canvas.drawRect(screenX - radius, screenY - radius, screenX + radius, screenY + radius, towerPaint)

        // Tier pips above the tower — one dot per tier already purchased.
        val pipRadius = radius * 0.18f
        for (t in 1..tower.tier) {
            val pipX = screenX - radius + pipRadius * (4 * (t - 1) + 1)
            canvas.drawCircle(pipX, screenY - radius - pipRadius * 2.5f, pipRadius, towerPaint)
        }
    }

    private fun drawEnemy(canvas: Canvas, layout: UiLayout, enemy: Enemy) {
        val screenX = layout.worldToScreenX(enemy.position.x)
        val screenY = layout.worldToScreenY(enemy.position.y)
        val radius = layout.worldToScreenLength(enemy.radius)

        enemyPaint.color = enemy.kind.colorArgb
        canvas.drawCircle(screenX, screenY, radius, enemyPaint)

        if (enemy.slowTimeRemaining > 0f) {
            canvas.drawCircle(screenX, screenY, radius + 3f, slowRingPaint)
        }

        val barWidth = radius * 2.2f
        val barHeight = layout.worldToScreenLength(5f)
        val barLeft = screenX - barWidth / 2f
        val barTop = screenY - radius - barHeight - 4f
        canvas.drawRect(barLeft, barTop, barLeft + barWidth, barTop + barHeight, healthBarBackgroundPaint)

        val healthFraction = (enemy.currentHealth / enemy.maxHealth).coerceIn(0f, 1f)
        healthBarFillPaint.color = if (healthFraction > 0.35f) Palette.HEALTH_BAR_FILL else Palette.HEALTH_BAR_FILL_LOW
        canvas.drawRect(barLeft, barTop, barLeft + barWidth * healthFraction, barTop + barHeight, healthBarFillPaint)
    }

    private fun drawProjectile(canvas: Canvas, layout: UiLayout, projectile: Projectile) {
        val screenX = layout.worldToScreenX(projectile.position.x)
        val screenY = layout.worldToScreenY(projectile.position.y)
        projectilePaint.color = projectile.type.colorArgb
        canvas.drawCircle(screenX, screenY, layout.worldToScreenLength(projectile.type.radius), projectilePaint)
    }

    private fun drawParticle(canvas: Canvas, layout: UiLayout, particle: Particle) {
        val screenX = layout.worldToScreenX(particle.position.x)
        val screenY = layout.worldToScreenY(particle.position.y)
        val fraction = particle.lifeFraction()
        particlePaint.color = particle.colorArgb
        particlePaint.alpha = (fraction * 255).toInt().coerceIn(0, 255)
        canvas.drawCircle(screenX, screenY, layout.worldToScreenLength(particle.startRadius) * fraction, particlePaint)
    }

    private fun drawDamageNumber(canvas: Canvas, layout: UiLayout, number: DamageNumber) {
        val screenX = layout.worldToScreenX(number.position.x)
        val screenY = layout.worldToScreenY(number.position.y)
        damageNumberPaint.alpha = (number.lifeFraction() * 255).toInt().coerceIn(0, 255)
        damageNumberPaint.textSize = layout.worldToScreenLength(20f)
        canvas.drawText("-${number.value}", screenX, screenY, damageNumberPaint)
    }
}
