package com.ironpath.defense.map

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * The static shape of one map: an ordered list of path waypoints (enemies
 * walk this polyline start-to-end) plus a human-readable name. Waypoints are
 * given in tile coordinates for readability when authoring a map, and
 * converted to world-space pixel centers via [worldWaypoints].
 */
class GameMap(val displayName: String, tileWaypoints: List<Pair<Int, Int>>) {

    val tileWaypoints: List<Pair<Int, Int>> = tileWaypoints

    fun worldWaypoints(): List<Vector2> = tileWaypoints.map { (col, row) ->
        Vector2(
            col * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f,
            row * GameConfig.TILE_SIZE + GameConfig.TILE_SIZE / 2f
        )
    }

    /** Builds a fresh TileGrid for this map: path tiles marked PATH, everything else BUILDABLE. */
    fun buildTileGrid(): TileGrid {
        val grid = TileGrid(GameConfig.GRID_COLS, GameConfig.GRID_ROWS)
        for (i in 0 until tileWaypoints.size - 1) {
            markSegment(grid, tileWaypoints[i], tileWaypoints[i + 1])
        }
        // The waypoint list only records corners; mark the final point too.
        val last = tileWaypoints.last()
        grid.setKind(last.first, last.second, TileKind.PATH)
        return grid
    }

    private fun markSegment(grid: TileGrid, from: Pair<Int, Int>, to: Pair<Int, Int>) {
        var col = from.first
        var row = from.second
        grid.setKind(col, row, TileKind.PATH)
        val stepCol = (to.first - from.first).coerceIn(-1, 1)
        val stepRow = (to.second - from.second).coerceIn(-1, 1)
        while (col != to.first || row != to.second) {
            if (col != to.first) col += stepCol
            if (row != to.second) row += stepRow
            grid.setKind(col, row, TileKind.PATH)
        }
    }

    companion object {
        /**
         * The single polished launch map: an S-curve that crosses the whole
         * 20x11 grid so every tower type has both open, long-sightline spots
         * (good for Archer/Ranger) and tight elbows where splash/chain towers
         * (Cannon/Lightning) shine.
         *
         * [MapRegistry] is the extension point for the "support multiple maps
         * eventually" requirement: adding a second map is just adding another
         * GameMap entry there — no other system needs to change.
         */
        fun ironpathValley(): GameMap = GameMap(
            displayName = "Ironpath Valley",
            tileWaypoints = listOf(
                0 to 8,
                4 to 8,
                4 to 3,
                9 to 3,
                9 to 8,
                14 to 8,
                14 to 2,
                19 to 2
            )
        )
    }
}
