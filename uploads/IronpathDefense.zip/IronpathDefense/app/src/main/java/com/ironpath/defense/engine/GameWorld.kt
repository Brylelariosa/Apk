package com.ironpath.defense.engine

import android.content.Context
import android.graphics.Canvas
import com.ironpath.defense.audio.AudioSystem
import com.ironpath.defense.audio.SoundEffect
import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.core.InputQueue
import com.ironpath.defense.core.Vector2
import com.ironpath.defense.economy.EconomySystem
import com.ironpath.defense.economy.UpgradeSystem
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.enemy.EnemySystem
import com.ironpath.defense.entity.particle.ParticleSystem
import com.ironpath.defense.entity.projectile.ProjectileSystem
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerSystem
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules
import com.ironpath.defense.map.MapRegistry
import com.ironpath.defense.map.MapSystem
import com.ironpath.defense.render.GameRenderer
import com.ironpath.defense.save.SaveData
import com.ironpath.defense.save.SaveSystem
import com.ironpath.defense.settings.SettingsSystem
import com.ironpath.defense.ui.GameActions
import com.ironpath.defense.ui.HudState
import com.ironpath.defense.ui.InputController
import com.ironpath.defense.ui.SafeInsets
import com.ironpath.defense.ui.UiLayout
import com.ironpath.defense.wave.WaveLibrary
import com.ironpath.defense.wave.WaveSystem

/**
 * The composition root: owns every system, wires their callbacks together,
 * and is the single place that knows the whole game exists. GameView (pure
 * Android/thread/Surface plumbing) only ever touches [onSurfaceResized],
 * [update], [render], the public [inputQueue], [pauseForBackground], and
 * [persistNow] — it has no idea EconomySystem or WaveSystem exist.
 *
 * Also implements [GameActions] directly: it already has direct references
 * to every system a UI action could possibly need, so a separate
 * "controller" class delegating to GameWorld would just be a pass-through
 * layer with no independent behavior of its own.
 */
class GameWorld(context: Context) : GameActions {

    // --- Systems -------------------------------------------------------------
    private val mapSystem = MapSystem(MapRegistry.default())
    private val collisionSystem = CollisionSystem(GameConfig.WORLD_WIDTH, GameConfig.WORLD_HEIGHT)
    private val enemySystem = EnemySystem(mapSystem.pathSystem)
    private val waveSystem = WaveSystem(enemySystem)
    private val economySystem = EconomySystem()
    private val upgradeSystem = UpgradeSystem(economySystem)
    private val particleSystem = ParticleSystem()
    private val saveSystem = SaveSystem(context)
    private val audioSystem = AudioSystem(context)
    private val settingsSystem = SettingsSystem(audioSystem)

    // Combat systems report hits/splashes/pulses to CombatEffects, which turns
    // them into particles and sound — so it has to exist before they do.
    private val combatEffects = CombatEffects(particleSystem, audioSystem, settingsSystem)
    private val projectileSystem = ProjectileSystem(collisionSystem, combatEffects)
    private val towerSystem = TowerSystem(collisionSystem, projectileSystem, combatEffects)

    // --- Presentation / input --------------------------------------------
    val uiLayout = UiLayout()
    val inputQueue = InputQueue()
    private val inputController = InputController()
    private val gameRenderer = GameRenderer(mapSystem)

    // --- Session state -------------------------------------------------------
    private var screenState = GameScreenState.MAIN_MENU
    private var lives = GameConfig.STARTING_LIVES
    private var highestWaveCompleted = 0
    private var selectedTower: Tower? = null
    private var pendingTowerType: TowerType? = null
    private var speedIndex = 0
    val currentSpeedMultiplier: Float get() = GameConfig.SPEED_MULTIPLIERS[speedIndex]

    /** Used by GameActivity to decide what the system back button should do (pause vs. exit). */
    val isPlaying: Boolean get() = screenState == GameScreenState.PLAYING

    init {
        val saved = saveSystem.load()
        highestWaveCompleted = saved.highestWaveCompleted
        settingsSystem.loadFrom(saved)
    }

    private var surfaceWidth = 0f
    private var surfaceHeight = 0f
    private var safeInsets = SafeInsets.NONE

    fun onSurfaceResized(width: Float, height: Float) {
        surfaceWidth = width
        surfaceHeight = height
        relayout()
    }

    /** Camera cutouts / rounded corners changed: keep the HUD and playable map clear of them. */
    fun onSafeInsetsChanged(insets: SafeInsets) {
        safeInsets = insets
        relayout()
    }

    private fun relayout() {
        if (surfaceWidth > 0f && surfaceHeight > 0f) uiLayout.recompute(surfaceWidth, surfaceHeight, safeInsets)
    }

    /** Called by GameActivity.onPause: if a run is in progress, drop into the pause screen rather than resuming mid-chaos later. */
    fun pauseForBackground() {
        if (screenState == GameScreenState.PLAYING) screenState = GameScreenState.PAUSED
    }

    fun persistNow() = saveSystem.saveNow(currentSaveSnapshot())

    // --- Per-tick update -------------------------------------------------------

    fun update(dt: Float) {
        // Input is drained unconditionally: Resume/Settings/Retry/Main-Menu
        // buttons must work even while the simulation itself is halted below.
        drainInput()

        if (screenState != GameScreenState.PLAYING) return

        val waveReward = waveSystem.update(dt)
        if (waveReward != null) {
            economySystem.earn(waveReward)
            persist()
        }

        // Ordering note: enemies move (and process this tick's kills/leaks)
        // BEFORE the collision grid is rebuilt and towers fire, so targeting
        // always aims at this-tick-fresh positions. The trade-off is that an
        // enemy killed by a projectile landing later in this same tick isn't
        // removed until the top of the *next* tick — an imperceptible ~16ms
        // at 60 fixed steps/second, and simpler than keeping two separate
        // "kill sweep" passes in sync.
        enemySystem.update(dt, onLeaked = ::handleEnemyLeaked, onKilled = ::handleEnemyKilled)
        collisionSystem.rebuild(enemySystem.active)
        towerSystem.update(dt)
        projectileSystem.update(dt)
        particleSystem.update(dt)

        when {
            lives <= 0 -> transitionToGameOver()
            waveSystem.hasWonGame -> transitionToVictory()
        }
    }

    private fun handleEnemyKilled(enemy: Enemy) {
        economySystem.earn(enemy.reward)
        particleSystem.spawnHitBurst(enemy.position, enemy.kind.colorArgb, sparkCount = 10)
        audioSystem.play(SoundEffect.EXPLOSION)
    }

    private fun handleEnemyLeaked(enemy: Enemy) {
        lives--
        audioSystem.play(SoundEffect.LIFE_LOST)
    }

    private fun transitionToGameOver() {
        screenState = GameScreenState.GAME_OVER
        persist()
        audioSystem.play(SoundEffect.GAME_OVER)
    }

    private fun transitionToVictory() {
        screenState = GameScreenState.VICTORY
        persist()
        audioSystem.play(SoundEffect.VICTORY)
    }

    private fun persist() {
        if (waveSystem.currentWaveIndex > highestWaveCompleted) highestWaveCompleted = waveSystem.currentWaveIndex
        saveSystem.save(currentSaveSnapshot())
    }

    private fun currentSaveSnapshot() = SaveData(
        highestWaveCompleted = highestWaveCompleted,
        musicOn = settingsSystem.musicOn,
        sfxOn = settingsSystem.sfxOn,
        showDamageNumbers = settingsSystem.showDamageNumbers
    )

    // --- Input ---------------------------------------------------------------

    private fun drainInput() {
        for (event in inputQueue.drain()) {
            // Rebuilt per-event (not once per batch) so a second queued tap in
            // the rare case of two taps landing in one frame sees the effect
            // of the first (e.g. a sell immediately clearing the selection).
            inputController.handleTap(event, uiLayout, buildHudState(), this)
        }
    }

    private fun buildHudState(): HudState {
        val upcomingOrActiveWave = waveSystem.activeWaveDefinition
            ?: WaveLibrary.ALL.getOrNull(waveSystem.currentWaveIndex)
        val waveNumber = (waveSystem.currentWaveIndex + 1).coerceAtMost(waveSystem.totalWaveCount)

        return HudState(
            screenState = screenState,
            money = economySystem.money,
            lives = lives.coerceAtLeast(0),
            maxLives = GameConfig.STARTING_LIVES,
            waveNumber = waveNumber,
            totalWaves = waveSystem.totalWaveCount,
            waveInProgress = waveSystem.waveInProgress,
            canStartWave = waveSystem.canStartNextWave(),
            isBossWave = upcomingOrActiveWave?.isBossWave ?: false,
            speedMultiplier = currentSpeedMultiplier,
            highestWaveCompleted = highestWaveCompleted,
            selectedTower = selectedTower,
            pendingTowerType = pendingTowerType,
            musicOn = settingsSystem.musicOn,
            sfxOn = settingsSystem.sfxOn,
            showDamageNumbers = settingsSystem.showDamageNumbers
        )
    }

    // --- Rendering -------------------------------------------------------------

    fun render(canvas: Canvas) {
        gameRenderer.render(
            canvas, uiLayout, buildHudState(),
            towerSystem.all, enemySystem.active, projectileSystem.active,
            particleSystem.particles, particleSystem.damageNumbers,
            particleSystem.rings, particleSystem.bolts, particleSystem.floatingTexts
        )
    }

    // --- GameActions -----------------------------------------------------------

    override fun startWave() {
        if (waveSystem.canStartNextWave()) {
            waveSystem.startNextWave()
            audioSystem.play(SoundEffect.WAVE_START)
        }
    }

    override fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % GameConfig.SPEED_MULTIPLIERS.size
    }

    override fun togglePause() {
        screenState = if (screenState == GameScreenState.PLAYING) GameScreenState.PAUSED else GameScreenState.PLAYING
    }

    override fun openSettings() {
        screenState = GameScreenState.SETTINGS
    }

    override fun closeSettings() {
        screenState = GameScreenState.PAUSED
    }

    override fun toggleMusic() {
        settingsSystem.toggleMusic()
        persist()
    }

    override fun toggleSfx() {
        settingsSystem.toggleSfx()
        persist()
    }

    override fun toggleDamageNumbers() {
        settingsSystem.toggleDamageNumbers()
        persist()
    }

    override fun goToMainMenu() {
        screenState = GameScreenState.MAIN_MENU
        audioSystem.stopMusic()
    }

    override fun startNewGame() {
        resetSession()
        screenState = GameScreenState.PLAYING
        audioSystem.playMusicLoop() // no-ops harmlessly today — see AudioSystem's class doc on shipped assets
    }

    override fun armTowerTypeForPlacement(type: TowerType) {
        pendingTowerType = if (pendingTowerType == type) null else type
        selectedTower = null
    }

    override fun attemptPlaceTowerAt(worldX: Float, worldY: Float) {
        val type = pendingTowerType ?: return
        val world = Vector2(worldX, worldY)
        if (!mapSystem.canPlaceTowerAt(world)) return
        if (!upgradeSystem.tryPurchase(type, highestWaveCompleted)) return

        val (col, row) = mapSystem.worldToTile(world)
        val towerPosition = mapSystem.tileToWorldCenter(col, row)
        towerSystem.place(Tower(type, towerPosition))
        mapSystem.markBuilt(towerPosition, true)
        audioSystem.play(SoundEffect.TOWER_PLACE)
        combatEffects.onTowerPlaced(towerPosition, type.colorArgb)
        pendingTowerType = null
    }

    override fun selectPlacedTowerAt(worldX: Float, worldY: Float): Boolean {
        val world = Vector2(worldX, worldY)
        val tapRadiusSquared = TAP_SELECT_RADIUS * TAP_SELECT_RADIUS
        val nearest = towerSystem.all.minByOrNull { it.position.distanceSquaredTo(world) }
        val found = nearest?.takeIf { it.position.distanceSquaredTo(world) <= tapRadiusSquared }
        selectedTower = found
        if (found != null) uiLayout.dockTowerPanelAwayFrom(uiLayout.worldToScreenX(found.position.x))
        return found != null
    }

    override fun deselectTower() {
        selectedTower = null
    }

    override fun upgradeSelectedTower(path: Int) {
        val tower = selectedTower ?: return
        if (path !in tower.pathTiers.indices) return

        // Read what's being bought before buying it: afterwards "next" is the following upgrade.
        val upgrade = tower.nextUpgrade(path) ?: return
        val pathColor = tower.type.paths[path].colorArgb
        if (!upgradeSystem.tryUpgrade(tower, path)) return

        audioSystem.play(SoundEffect.TOWER_UPGRADE)
        combatEffects.onTowerUpgraded(
            tower.position, pathColor, upgrade.name,
            isCapstone = tower.pathTiers[path] >= UpgradeRules.MAX_TIER
        )
    }

    override fun sellSelectedTower() {
        val tower = selectedTower ?: return
        upgradeSystem.sell(tower)
        towerSystem.remove(tower)
        mapSystem.markBuilt(tower.position, false)
        audioSystem.play(SoundEffect.TOWER_SELL)
        selectedTower = null
    }

    override fun cycleSelectedTowerTargeting() {
        selectedTower?.cycleTargetingMode()
    }

    private fun resetSession() {
        enemySystem.clear()
        projectileSystem.clear()
        particleSystem.clear()
        towerSystem.clear()
        mapSystem.resetOccupancy()
        waveSystem.reset()
        economySystem.reset()
        lives = GameConfig.STARTING_LIVES
        selectedTower = null
        pendingTowerType = null
        speedIndex = 0
    }

    companion object {
        private const val TAP_SELECT_RADIUS = GameConfig.TILE_SIZE * 0.6f
    }
}
