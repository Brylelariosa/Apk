package com.ironpath.defense.entity.tower

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.entity.projectile.ProjectileSystem

/**
 * Advances every placed tower's cooldown and fires when a target is
 * available. Target selection is delegated to [CollisionSystem] (spatial
 * grid — never an O(towers × enemies) scan); the actual shot is delegated to
 * [ProjectileSystem].
 */
class TowerSystem(
    private val collisionSystem: CollisionSystem,
    private val projectileSystem: ProjectileSystem
) {
    private val towers = ArrayList<Tower>()
    val all: List<Tower> get() = towers

    fun place(tower: Tower) {
        towers.add(tower)
    }

    fun remove(tower: Tower) {
        towers.remove(tower)
    }

    /** Removes every placed tower (used when starting a new session). */
    fun clear() {
        towers.clear()
    }

    fun update(dt: Float) {
        for (i in towers.indices) {
            val tower = towers[i]
            tower.cooldownRemaining -= dt
            if (tower.cooldownRemaining > 0f) continue

            val stats = tower.stats
            val target = collisionSystem.findTarget(tower.position, stats.range, tower.targetingMode) ?: continue

            projectileSystem.spawn(
                type = tower.type.projectileType,
                origin = tower.position,
                target = target,
                damage = stats.damage,
                armorPenetration = stats.armorPenetration,
                splashRadius = stats.splashRadius,
                slowMultiplier = stats.slowMultiplier,
                slowDurationSeconds = stats.slowDurationSeconds,
                chainCount = stats.chainCount,
                chainRadius = stats.chainRadius,
                chainDamageFalloff = stats.chainDamageFalloff
            )
            tower.cooldownRemaining = stats.fireRateSeconds
        }
    }
}
