package com.ironpath.defense.entity.tower

import com.ironpath.defense.combat.CollisionSystem
import com.ironpath.defense.combat.CombatFeedback
import com.ironpath.defense.combat.HitResolver
import com.ironpath.defense.entity.enemy.Enemy
import com.ironpath.defense.entity.projectile.ProjectileSystem
import com.ironpath.defense.entity.projectile.ShotProfile
import kotlin.random.Random

/**
 * Advances every placed tower and makes it act: fire a volley (one or more
 * projectiles, with crits) when a target is in range, and release its pulse
 * nova if an upgrade gave it one. Target selection is delegated to
 * [CollisionSystem] (spatial grid — never an O(towers x enemies) scan); the
 * shots themselves to [ProjectileSystem].
 */
class TowerSystem(
    private val collisionSystem: CollisionSystem,
    private val projectileSystem: ProjectileSystem,
    private val feedback: CombatFeedback
) {
    private val towers = ArrayList<Tower>()
    val all: List<Tower> get() = towers

    // Reused every tick so firing never allocates.
    private val targetBuffer = ArrayList<Enemy>(8)
    private val pulseTargets = ArrayList<Enemy>(32)
    private val pulseShot = ShotProfile()

    fun place(tower: Tower) {
        towers.add(tower)
    }

    fun remove(tower: Tower) {
        towers.remove(tower)
    }

    /** Removes every placed tower (used when starting a new session). */
    fun clear() {
        towers.clear()
    }

    fun update(dt: Float) {
        for (i in towers.indices) {
            val tower = towers[i]
            val stats = tower.stats

            if (tower.flashRemaining > 0f) tower.flashRemaining -= dt

            if (stats.pulseDamage > 0f && stats.pulseIntervalSeconds > 0f) updatePulse(tower, stats, dt)

            tower.cooldownRemaining -= dt
            if (tower.cooldownRemaining > 0f) continue
            fireVolley(tower, stats)
        }
    }

    private fun fireVolley(tower: Tower, stats: TowerStats) {
        targetBuffer.clear()
        if (stats.projectilesPerShot <= 1) {
            val single = collisionSystem.findTarget(tower.position, stats.range, tower.targetingMode) ?: return
            targetBuffer.add(single)
        } else {
            collisionSystem.findTargets(
                tower.position, stats.range, tower.targetingMode, stats.projectilesPerShot, targetBuffer
            )
            if (targetBuffer.isEmpty()) return
        }

        tower.aimAt(targetBuffer[0].position)

        for (shotIndex in 0 until stats.projectilesPerShot) {
            // With fewer enemies than projectiles, the extras double up on targets in order.
            val target = targetBuffer[shotIndex % targetBuffer.size]
            val isCrit = stats.critChance > 0f && Random.nextFloat() < stats.critChance
            val damage = if (isCrit) stats.damage * stats.critMultiplier else stats.damage

            val projectile = projectileSystem.spawn(tower.type.projectileType, tower.position, target)
            stats.writeShot(projectile.shot, damage, isCrit, tower.accentColorArgb)
        }

        tower.cooldownRemaining = stats.fireRateSeconds
        tower.flashRemaining = MUZZLE_FLASH_SECONDS
    }

    private fun updatePulse(tower: Tower, stats: TowerStats, dt: Float) {
        tower.pulseCooldownRemaining -= dt
        if (tower.pulseCooldownRemaining > 0f) return

        val inReach = collisionSystem.queryRadius(tower.position, stats.pulseRadius)
        if (inReach.isEmpty()) return // hold the charge until something is actually in reach

        pulseTargets.clear()
        pulseTargets.addAll(inReach)
        stats.writeShot(pulseShot, stats.pulseDamage, false, tower.accentColorArgb)

        feedback.onPulse(tower.position, stats.pulseRadius, tower.accentColorArgb)
        for (enemy in pulseTargets) {
            val dealt = HitResolver.apply(enemy, pulseShot, stats.pulseDamage)
            feedback.onEnemyHit(enemy, dealt, false)
        }
        tower.pulseCooldownRemaining = stats.pulseIntervalSeconds
    }

    private companion object {
        const val MUZZLE_FLASH_SECONDS = 0.09f
    }
}
