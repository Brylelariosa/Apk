package com.ironpath.defense.entity.tower.upgrade

import com.ironpath.defense.entity.tower.upgrade.Mods.armorPen
import com.ironpath.defense.entity.tower.upgrade.Mods.bossDamage
import com.ironpath.defense.entity.tower.upgrade.Mods.burn
import com.ironpath.defense.entity.tower.upgrade.Mods.chain
import com.ironpath.defense.entity.tower.upgrade.Mods.cooldown
import com.ironpath.defense.entity.tower.upgrade.Mods.crit
import com.ironpath.defense.entity.tower.upgrade.Mods.damage
import com.ironpath.defense.entity.tower.upgrade.Mods.dotColor
import com.ironpath.defense.entity.tower.upgrade.Mods.execute
import com.ironpath.defense.entity.tower.upgrade.Mods.freeze
import com.ironpath.defense.entity.tower.upgrade.Mods.mark
import com.ironpath.defense.entity.tower.upgrade.Mods.multishot
import com.ironpath.defense.entity.tower.upgrade.Mods.pulse
import com.ironpath.defense.entity.tower.upgrade.Mods.range
import com.ironpath.defense.entity.tower.upgrade.Mods.slow
import com.ironpath.defense.entity.tower.upgrade.Mods.splash

/**
 * Every tower's three upgrade paths, five tiers each. This file is pure
 * data: retuning a cost or number, renaming an upgrade, or adding a whole new
 * path touches nothing outside it.
 *
 * Each path is a "class" the player commits to (Archer: Marksman / Volley /
 * Pyre, and so on). See [UpgradeRules] for the 5/2/0 crosspath limits.
 *
 * Write a new upgrade as `up(name, cost, description, <one or more Mods>)`.
 * Descriptions should stay short — the tower panel shows two lines of them.
 */
object UpgradeCatalog {

    // Path accent colors, in a separate object so their initialization can
    // never be ordered after the lists below that read them.
    private object Tint {
        val GOLD = 0xFFF2C14E.toInt()
        val SKY = 0xFF6EC6F5.toInt()
        val EMBER = 0xFFEF7B3A.toInt()
        val BRICK = 0xFFE8743B.toInt()
        val STEEL = 0xFF7FB2E5.toInt()
        val AMETHYST = 0xFFB37AE0.toInt()
        val ICE = 0xFF9BE7FF.toInt()
        val TEAL = 0xFF4FD1C5.toInt()
        val VIOLET = 0xFFA78BFA.toInt()
        val LIME = 0xFFB4E05A.toInt()
        val VENOM = 0xFF58D68D.toInt()
        val STORM = 0xFFC9A6FF.toInt()
        val VOLT = 0xFFFFE066.toInt()
        val CYAN = 0xFF67E8F9.toInt()
    }

    private fun up(name: String, cost: Int, description: String, vararg mods: StatModifier) =
        TowerUpgrade(name, description, cost, mods.toList())

    private fun path(name: String, colorArgb: Int, vararg upgrades: TowerUpgrade) =
        UpgradePath(name, colorArgb, upgrades.toList())

    // --- Archer ---------------------------------------------------------------
    val ARCHER: List<UpgradePath> = listOf(
        path("Marksman", Tint.GOLD,
            up("Keen Eyes", 50, "+20% damage, +15% range", damage(1.2f), range(1.15f)),
            up("Bodkin Points", 100, "Pierces 6 armor, +20% damage", armorPen(6f), damage(1.2f)),
            up("Deadeye", 240, "25% chance to crit for 3x damage", crit(0.25f, 3f), range(1.1f)),
            up("Sniper's Nest", 560, "2.2x damage, +30% range, slower shots", damage(2.2f), range(1.3f), cooldown(1.25f)),
            up("Executioner", 1500, "50% crits, executes weak foes, +50% vs bosses",
                damage(1.8f), crit(0.5f, 3f), execute(0.15f), bossDamage(1.5f), armorPen(6f))
        ),
        path("Volley", Tint.SKY,
            up("Quick Draw", 60, "+30% fire rate", cooldown(0.77f)),
            up("Twin Shot", 120, "Fires 2 arrows at once", multishot(1)),
            up("Triple Volley", 280, "Fires 3 arrows, +10% fire rate", multishot(1), cooldown(0.9f)),
            up("Rain of Arrows", 650, "Fires 4 arrows, +25% damage", multishot(1), damage(1.25f)),
            up("Storm of Steel", 1600, "Fires 6 arrows at blazing speed",
                multishot(2), cooldown(0.75f), damage(1.3f), range(1.1f))
        ),
        path("Pyre", Tint.EMBER,
            up("Pitch Tips", 55, "Burns foes for 5 dmg/s", burn(5f, 3f)),
            up("Flaming Arrows", 110, "Burn 12 dmg/s for 4s", burn(12f, 4f)),
            up("Explosive Tips", 260, "Arrows explode, +30% damage", splash(45f), damage(1.3f)),
            up("Inferno Arrows", 620, "Burn 35 dmg/s, bigger blasts", burn(35f, 5f), splash(30f), damage(1.2f)),
            up("Dragon's Breath", 1600, "Burn 80 dmg/s, fire pulses scorch nearby foes",
                burn(80f, 6f), splash(35f), damage(1.5f), pulse(45f, 2.2f, 120f))
        )
    )

    // --- Cannon ---------------------------------------------------------------
    val CANNON: List<UpgradePath> = listOf(
        path("Bombardier", Tint.BRICK,
            up("Heavy Shot", 90, "+35% damage, +10 blast radius", damage(1.35f), splash(10f)),
            up("Reinforced Barrel", 170, "+15% range, +10% fire rate", range(1.15f), cooldown(0.9f)),
            up("Shrapnel Rounds", 420, "+40% damage, +25 blast radius", damage(1.4f), splash(25f)),
            up("Siege Mortar", 950, "2x damage, +20% range, bigger blasts",
                damage(2f), range(1.2f), splash(30f), cooldown(1.15f)),
            up("Doomsday Shell", 2400, "2.5x damage, huge blast, +60% vs bosses",
                damage(2.5f), splash(50f), bossDamage(1.6f))
        ),
        path("Gunner", Tint.STEEL,
            up("Oiled Gears", 90, "+20% fire rate", cooldown(0.83f)),
            up("Rapid Loader", 170, "+25% fire rate", cooldown(0.8f)),
            up("Twin Barrels", 400, "Fires 2 cannonballs", multishot(1)),
            up("Gatling Cannon", 900, "Blistering fire rate, +20% damage", cooldown(0.6f), damage(1.2f)),
            up("Hellstorm", 2200, "Fires 3 cannonballs, +30% damage",
                multishot(1), damage(1.3f), cooldown(0.8f))
        ),
        path("Demolition", Tint.AMETHYST,
            up("Armor-Piercing", 100, "Pierces 8 armor", armorPen(8f)),
            up("Sunder", 190, "Marked foes take +15% damage", mark(0.15f, 3f)),
            up("Fracture", 450, "Pierces 10 more armor, marks +25%",
                armorPen(10f), mark(0.25f, 3.5f), damage(1.2f)),
            up("Wrecking Crew", 1000, "+50% vs bosses, marks +35%, +40% damage",
                bossDamage(1.5f), mark(0.35f, 4f), damage(1.4f)),
            up("Titan Breaker", 2300, "2x damage, executes weak foes, marks +40%",
                damage(2f), execute(0.2f), mark(0.4f, 5f), splash(25f))
        )
    )

    // --- Frost ----------------------------------------------------------------
    val FROST: List<UpgradePath> = listOf(
        path("Permafrost", Tint.ICE,
            up("Deep Chill", 70, "Slows to 50% for 2s", slow(0.5f, 2f)),
            up("Icy Touch", 130, "Slows to 40% for 2.5s, +30% damage", slow(0.4f, 2.5f), damage(1.3f)),
            up("Flash Freeze", 300, "18% chance to freeze foes solid", freeze(0.18f, 1f)),
            up("Glacial Lock", 700, "35% freeze chance, slows to 30%", freeze(0.35f, 1.6f), slow(0.3f, 3f)),
            up("Absolute Zero", 1700, "60% freeze chance, foes take +20% damage",
                freeze(0.6f, 2.2f), mark(0.2f, 3f), damage(1.5f))
        ),
        path("Blizzard", Tint.TEAL,
            up("Wider Chill", 70, "+15% range, shards burst on impact", range(1.15f), splash(40f)),
            up("Snow Flurry", 130, "Bigger bursts, +15% fire rate", splash(30f), cooldown(0.87f)),
            up("Winter Nova", 320, "Icy pulse every 2.2s hits all nearby", pulse(25f, 2.2f, 130f)),
            up("Blizzard", 720, "Stronger, faster pulses", pulse(60f, 1.6f, 170f), splash(30f)),
            up("Ice Age", 1800, "Massive pulse: 140 damage every 1.2s", pulse(140f, 1.2f, 230f), range(1.2f))
        ),
        path("Shatter", Tint.VIOLET,
            up("Sharp Shards", 80, "+60% damage", damage(1.6f)),
            up("Piercing Cold", 150, "Pierces 6 armor, +30% damage", armorPen(6f), damage(1.3f)),
            up("Brittle", 350, "Chilled foes take +20% damage", mark(0.2f, 3f)),
            up("Shatterpoint", 800, "+50% damage, 15% crits, marks +30%",
                damage(1.5f), crit(0.15f, 2.5f), mark(0.3f, 3.5f)),
            up("Cryo Cannon", 1900, "2.5x damage, +50% vs bosses, executes weak foes",
                damage(2.5f), bossDamage(1.5f), execute(0.15f))
        )
    )

    // --- Ranger ---------------------------------------------------------------
    val RANGER: List<UpgradePath> = listOf(
        path("Sniper", Tint.GOLD,
            up("Scope", 110, "+20% range, +15% damage", range(1.2f), damage(1.15f)),
            up("Long Barrel", 210, "+30% damage, pierces 6 more armor", damage(1.3f), armorPen(6f)),
            up("Elite Sniper", 480, "+33% fire rate, 20% crits", cooldown(0.75f), crit(0.2f, 2.5f)),
            up("Anti-Armor Rifle", 1100, "2.2x damage, pierces 14 armor, +40% vs bosses",
                damage(2.2f), armorPen(14f), bossDamage(1.4f)),
            up("Deadshot", 2600, "2x damage, 40% crits for 4x, executes weak foes",
                damage(2f), crit(0.4f, 4f), execute(0.25f), range(1.2f))
        ),
        path("Skirmisher", Tint.LIME,
            up("Quick Reload", 110, "+18% fire rate", cooldown(0.85f)),
            up("Split Dart", 220, "Fires 2 darts", multishot(1)),
            up("Volley Darts", 500, "Fires 3 darts, +10% fire rate", multishot(1), cooldown(0.9f)),
            up("Dart Barrage", 1100, "Fires 4 darts, +20% damage", multishot(1), damage(1.2f)),
            up("Thousand Darts", 2500, "Fires 6 darts, +30% damage, faster",
                multishot(2), damage(1.3f), cooldown(0.75f))
        ),
        path("Toxin", Tint.VENOM,
            up("Poison Tips", 100, "Poison 8 dmg/s for 4s", burn(8f, 4f), dotColor(0xFF58D68D.toInt())),
            up("Venom", 200, "Poison 18 dmg/s, pierces 4 armor", burn(18f, 5f), armorPen(4f)),
            up("Corrosive Coat", 460, "Poison 28 dmg/s, foes take +20% damage", burn(28f, 5f), mark(0.2f, 4f)),
            up("Plague Darts", 1050, "Poison 50 dmg/s, darts burst on impact",
                burn(50f, 6f), splash(45f), damage(1.2f)),
            up("Death Bloom", 2400, "Poison 100 dmg/s, +30% vs bosses, marks +30%",
                burn(100f, 7f), splash(30f), mark(0.3f, 5f), bossDamage(1.3f))
        )
    )

    // --- Lightning ------------------------------------------------------------
    val LIGHTNING: List<UpgradePath> = listOf(
        path("Arc Master", Tint.STORM,
            up("Conductive Coil", 130, "+1 chain link, longer reach", chain(1, 15f, 0f)),
            up("Superconductor", 250, "Chains keep 80% damage, +1 link", chain(1, 0f, 0.8f)),
            up("Chain Storm", 580, "+2 links, longer reach, +30% damage", chain(2, 25f, 0f), damage(1.3f)),
            up("Tesla Web", 1300, "+3 links, keeps 90% damage, +50% damage, faster",
                chain(3, 30f, 0.9f), damage(1.5f), cooldown(0.85f)),
            up("Thunder God", 3000, "+4 links, no falloff, thunder pulses",
                chain(4, 40f, 1f), damage(1.8f), pulse(60f, 2f, 160f))
        ),
        path("Overcharge", Tint.VOLT,
            up("High Voltage", 130, "+40% damage", damage(1.4f)),
            up("Capacitors", 250, "+25% fire rate", cooldown(0.8f)),
            up("Static Shock", 560, "20% chance to stun, +30% damage", freeze(0.2f, 0.8f), damage(1.3f)),
            up("Lightning Rod", 1250, "2x damage, +20% range, 20% crits",
                damage(2f), range(1.2f), crit(0.2f, 2.5f)),
            up("Zeus' Wrath", 2900, "2.5x damage, 35% crits, pierces 12 armor, +50% vs bosses",
                damage(2.5f), cooldown(0.75f), crit(0.35f, 3f), bossDamage(1.5f), armorPen(12f))
        ),
        path("Storm Caller", Tint.CYAN,
            up("Ionized Air", 140, "Zapped foes take +12% damage", mark(0.12f, 3f)),
            up("Thunderclap", 270, "Thunder pulse every 3s", pulse(30f, 3f, 110f)),
            up("Storm Cloud", 620, "Stronger pulse every 2.4s, +15% range", pulse(55f, 2.4f, 140f), range(1.15f)),
            up("Tempest", 1400, "Heavy pulse every 1.8s, foes take +25%", pulse(110f, 1.8f, 180f), mark(0.25f, 4f)),
            up("Eye of the Storm", 3100, "Pulse 220 damage every 1.2s, pulses stun",
                pulse(220f, 1.2f, 240f), freeze(0.3f, 1f))
        )
    )
}
