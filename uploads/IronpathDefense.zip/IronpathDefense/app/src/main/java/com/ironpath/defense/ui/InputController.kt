package com.ironpath.defense.ui

import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.core.InputEvent
import com.ironpath.defense.entity.tower.TowerType

/**
 * Pure "geometry in, intent out" translation: given a tap (in screen pixels)
 * and the current [HudState]/[UiLayout], decides which [GameActions] method
 * that tap means and calls it. Holds no game state of its own and never
 * mutates anything except through [GameActions] — every rect it tests
 * against is the exact same [UiLayout] instance [HudRenderer] just drew, so
 * a tap always means what it visually looks like it should mean.
 */
class InputController {

    fun handleTap(event: InputEvent, layout: UiLayout, state: HudState, actions: GameActions) {
        val x = event.screenX
        val y = event.screenY

        when (state.screenState) {
            GameScreenState.MAIN_MENU -> {
                if (layout.mainMenuPlayButton.contains(x, y)) actions.startNewGame()
            }
            GameScreenState.PLAYING -> handlePlayingTap(x, y, layout, state, actions)
            GameScreenState.PAUSED -> {
                when {
                    layout.pauseResumeButton.contains(x, y) -> actions.togglePause()
                    layout.pauseSettingsButton.contains(x, y) -> actions.openSettings()
                    layout.pauseMainMenuButton.contains(x, y) -> actions.goToMainMenu()
                }
            }
            GameScreenState.SETTINGS -> {
                when {
                    layout.settingsMusicRow.contains(x, y) -> actions.toggleMusic()
                    layout.settingsSfxRow.contains(x, y) -> actions.toggleSfx()
                    layout.settingsDamageNumbersRow.contains(x, y) -> actions.toggleDamageNumbers()
                    layout.settingsCloseButton.contains(x, y) -> actions.closeSettings()
                }
            }
            GameScreenState.GAME_OVER, GameScreenState.VICTORY -> {
                if (layout.endScreenRetryButton.contains(x, y)) actions.startNewGame()
            }
        }
    }

    private fun handlePlayingTap(x: Float, y: Float, layout: UiLayout, state: HudState, actions: GameActions) {
        when {
            layout.pauseButton.contains(x, y) -> actions.togglePause()
            layout.speedButton.contains(x, y) -> actions.cycleSpeed()
            layout.startWaveButton.contains(x, y) -> actions.startWave()

            layout.bottomBar.contains(x, y) && state.selectedTower != null ->
                handleTowerInfoTap(x, y, layout, actions)

            layout.bottomBar.contains(x, y) && state.selectedTower == null ->
                handleShopTap(x, y, layout, actions)

            layout.battlefield.contains(x, y) -> handleBattlefieldTap(x, y, layout, state, actions)
        }
    }

    private fun handleTowerInfoTap(x: Float, y: Float, layout: UiLayout, actions: GameActions) {
        when {
            layout.upgradeButton.contains(x, y) -> actions.upgradeSelectedTower()
            layout.sellButton.contains(x, y) -> actions.sellSelectedTower()
            layout.targetingButton.contains(x, y) -> actions.cycleSelectedTowerTargeting()
            layout.closeButton.contains(x, y) -> actions.deselectTower()
        }
    }

    private fun handleShopTap(x: Float, y: Float, layout: UiLayout, actions: GameActions) {
        for (type in TowerType.entries) {
            if (layout.towerShopSlots[type.ordinal].contains(x, y)) {
                actions.armTowerTypeForPlacement(type)
                return
            }
        }
    }

    private fun handleBattlefieldTap(x: Float, y: Float, layout: UiLayout, state: HudState, actions: GameActions) {
        val worldX = layout.screenToWorldX(x)
        val worldY = layout.screenToWorldY(y)

        if (state.pendingTowerType != null) {
            actions.attemptPlaceTowerAt(worldX, worldY)
        } else {
            val foundTower = actions.selectPlacedTowerAt(worldX, worldY)
            if (!foundTower) actions.deselectTower()
        }
    }
}
