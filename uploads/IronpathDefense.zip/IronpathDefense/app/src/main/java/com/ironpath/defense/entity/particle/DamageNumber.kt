package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.Vector2

/** A floating "-N" damage indicator. Pooled by ParticleSystem. Crits draw larger and gold. */
class DamageNumber {
    val position = Vector2()
    var value = 0
    var isCrit = false
    var lifeRemaining = 0f
    var lifeTotal = 0.7f
    var alive = false

    fun lifeFraction(): Float = if (lifeTotal <= 0f) 0f else (lifeRemaining / lifeTotal).coerceIn(0f, 1f)
}
