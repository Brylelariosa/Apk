package com.ironpath.defense.entity.projectile

import com.ironpath.defense.core.Vector2
import com.ironpath.defense.entity.enemy.Enemy

/**
 * A single active projectile. Pooled by [ProjectileSystem].
 *
 * Two flight modes, chosen per [ProjectileType.isHoming]:
 *  - Ballistic (Archer/Cannon/Ranger): launched at the target's position at
 *    fire time and flies straight there — a fast enemy that moves out of the
 *    way after the shot leaves the tower can genuinely dodge it.
 *  - Homing (Frost/Lightning): re-aims at [homingTarget]'s live position
 *    every tick, using [homingTargetGeneration] to detect "the enemy I was
 *    chasing died and this pooled slot became a different enemy" (see
 *    [Enemy.generation]) rather than silently retargeting an unrelated spawn.
 *
 * What the shot *does* on impact lives in [shot]; [dirX]/[dirY] are the unit
 * direction of the last movement step, kept only so the renderer can draw a
 * motion trail without recomputing it.
 */
class Projectile {
    lateinit var type: ProjectileType
    val position = Vector2()
    val targetPoint = Vector2() // fixed destination for ballistic projectiles

    val shot = ShotProfile()

    var homingTarget: Enemy? = null
    var homingTargetGeneration = -1

    var dirX = 1f
    var dirY = 0f

    var alive = false

    fun isHomingTargetValid(): Boolean {
        val target = homingTarget ?: return false
        return target.alive && target.generation == homingTargetGeneration
    }
}
