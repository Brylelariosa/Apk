package com.ironpath.defense.ui

/**
 * Chrome colors only — backgrounds, panels, text, button states. Entity
 * tints (enemy/tower/projectile colors) live directly on their own enums
 * instead, since color there is an identifying property of the archetype,
 * not a UI theming concern. This split means retheming the HUD never
 * involves hunting through render code, and vice versa.
 *
 * Plain `val`, not `const val`: several entries need `.toInt()` to fold a
 * 0xFFRRGGBB literal into a signed Int, which Kotlin's `const val` (a true
 * compile-time constant) does not permit as an initializer. A regular `val`
 * on a singleton `object` already compiles to a single static field, so
 * there's no runtime cost to this choice.
 */
object Palette {
    val VOID_BACKGROUND = 0xFF12161C.toInt()
    val PANEL = 0xFF1E252E.toInt()
    val PANEL_LIGHT = 0xFF2A323D.toInt()

    val PATH_STONE = 0xFF4A4740.toInt()
    val BUILDABLE_GROUND = 0xFF24361F.toInt()
    val BLOCKED_GROUND = 0xFF1A2018.toInt()

    val TEXT_PRIMARY = 0xFFEDEAE0.toInt()
    val TEXT_SECONDARY = 0xFFAAA79C.toInt()
    val TEXT_DISABLED = 0xFF6B6862.toInt()

    val ACCENT_EMBER = 0xFFE8A33D.toInt()
    val DANGER = 0xFFD1495B.toInt()
    val SUCCESS = 0xFF6FA85C.toInt()

    val BUTTON_ENABLED = 0xFF2E3A2C.toInt()
    val BUTTON_DISABLED = 0xFF23262B.toInt()
    val BUTTON_BORDER = 0xFF454B44.toInt()

    val HEALTH_BAR_BACKGROUND = 0xFF241B1B.toInt()
    val HEALTH_BAR_FILL = 0xFF6FA85C.toInt()
    val HEALTH_BAR_FILL_LOW = 0xFFD1495B.toInt()

    val RANGE_CIRCLE_STROKE = 0x55E8A33D.toInt()
}
