package com.ironpath.defense.entity.tower

import com.ironpath.defense.entity.projectile.ProjectileType

/**
 * Data-driven definition of one tower archetype: cost, unlock condition,
 * render color, projectile, and its full 3-tier upgrade progression.
 *
 * Five original archetypes, each covering a distinct tactical role so
 * placement/upgrade choices actually matter:
 *  - Archer: cheap, fast-firing single-target generalist.
 *  - Cannon: splash damage — the answer to Swarm groups.
 *  - Frost: low damage but slows enemies, making every other tower's shots count for more.
 *  - Ranger: long range, high single-target damage, armor-penetration — the answer to Armored/Boss.
 *  - Lightning: chains to nearby enemies — a second, higher-tier answer to clustered Swarms.
 */
enum class TowerType(
    val displayName: String,
    val baseCost: Int,
    val unlockWave: Int,
    val colorArgb: Int,
    val projectileType: ProjectileType,
    val tiers: List<TowerTierStats>
) {
    ARCHER(
        displayName = "Archer Tower",
        baseCost = 100,
        unlockWave = 1,
        colorArgb = 0xFF6FA85C.toInt(),
        projectileType = ProjectileType.ARROW,
        tiers = listOf(
            TowerTierStats(damage = 12f, range = 170f, fireRateSeconds = 0.45f, upgradeCost = 0),
            TowerTierStats(damage = 20f, range = 185f, fireRateSeconds = 0.38f, upgradeCost = 90),
            TowerTierStats(damage = 32f, range = 200f, fireRateSeconds = 0.30f, upgradeCost = 160)
        )
    ),
    CANNON(
        displayName = "Cannon Tower",
        baseCost = 180,
        unlockWave = 1,
        colorArgb = 0xFF8A8F98.toInt(),
        projectileType = ProjectileType.CANNONBALL,
        tiers = listOf(
            TowerTierStats(damage = 34f, range = 150f, fireRateSeconds = 1.30f, upgradeCost = 0, splashRadius = 55f),
            TowerTierStats(damage = 55f, range = 160f, fireRateSeconds = 1.15f, upgradeCost = 150, splashRadius = 65f),
            TowerTierStats(damage = 85f, range = 175f, fireRateSeconds = 1.00f, upgradeCost = 260, splashRadius = 78f)
        )
    ),
    FROST(
        displayName = "Frost Tower",
        baseCost = 130,
        unlockWave = 3,
        colorArgb = 0xFF6FD6D0.toInt(),
        projectileType = ProjectileType.FROST_SHARD,
        tiers = listOf(
            TowerTierStats(damage = 6f, range = 140f, fireRateSeconds = 0.90f, upgradeCost = 0, slowMultiplier = 0.60f, slowDurationSeconds = 1.5f),
            TowerTierStats(damage = 9f, range = 150f, fireRateSeconds = 0.80f, upgradeCost = 110, slowMultiplier = 0.50f, slowDurationSeconds = 1.8f),
            TowerTierStats(damage = 13f, range = 160f, fireRateSeconds = 0.70f, upgradeCost = 190, slowMultiplier = 0.40f, slowDurationSeconds = 2.2f)
        )
    ),
    RANGER(
        displayName = "Ranger Tower",
        baseCost = 220,
        unlockWave = 6,
        colorArgb = 0xFFA3B565.toInt(),
        projectileType = ProjectileType.RANGER_DART,
        tiers = listOf(
            TowerTierStats(damage = 48f, range = 260f, fireRateSeconds = 1.10f, upgradeCost = 0, armorPenetration = 6f),
            TowerTierStats(damage = 72f, range = 280f, fireRateSeconds = 0.95f, upgradeCost = 190, armorPenetration = 10f),
            TowerTierStats(damage = 110f, range = 300f, fireRateSeconds = 0.80f, upgradeCost = 320, armorPenetration = 16f)
        )
    ),
    LIGHTNING(
        displayName = "Lightning Tower",
        baseCost = 260,
        unlockWave = 10,
        colorArgb = 0xFFC9A6FF.toInt(),
        projectileType = ProjectileType.LIGHTNING_BOLT,
        tiers = listOf(
            TowerTierStats(damage = 18f, range = 150f, fireRateSeconds = 0.85f, upgradeCost = 0, chainCount = 2, chainRadius = 90f, chainDamageFalloff = 0.65f),
            TowerTierStats(damage = 27f, range = 160f, fireRateSeconds = 0.75f, upgradeCost = 220, chainCount = 3, chainRadius = 100f, chainDamageFalloff = 0.70f),
            TowerTierStats(damage = 40f, range = 175f, fireRateSeconds = 0.65f, upgradeCost = 360, chainCount = 4, chainRadius = 115f, chainDamageFalloff = 0.75f)
        )
    );

    val maxTier: Int get() = tiers.size

    fun statsFor(tier: Int): TowerTierStats = tiers[(tier - 1).coerceIn(0, tiers.size - 1)]

    fun isUnlockedAt(highestWaveCompleted: Int): Boolean = highestWaveCompleted + 1 >= unlockWave
}
