package com.ironpath.defense.entity.tower

import com.ironpath.defense.entity.projectile.ProjectileType
import com.ironpath.defense.entity.tower.upgrade.UpgradeCatalog
import com.ironpath.defense.entity.tower.upgrade.UpgradePath

/**
 * Data-driven definition of one tower archetype: cost, unlock condition,
 * render color, projectile, its starting [baseStats], and its three upgrade
 * [paths] (see [UpgradeCatalog]).
 *
 * Five original archetypes, each covering a distinct tactical role so
 * placement/upgrade choices actually matter:
 *  - Archer: cheap, fast-firing single-target generalist.
 *  - Cannon: splash damage — the answer to Swarm groups.
 *  - Frost: low damage but slows enemies, making every other tower's shots count for more.
 *  - Ranger: long range, high single-target damage, armor-penetration — the answer to Armored/Boss.
 *  - Lightning: chains to nearby enemies — a second, higher-tier answer to clustered Swarms.
 */
enum class TowerType(
    val displayName: String,
    val baseCost: Int,
    val unlockWave: Int,
    val colorArgb: Int,
    val projectileType: ProjectileType,
    val baseStats: TowerStats,
    val paths: List<UpgradePath>
) {
    ARCHER(
        displayName = "Archer Tower",
        baseCost = 100,
        unlockWave = 1,
        colorArgb = 0xFF6FA85C.toInt(),
        projectileType = ProjectileType.ARROW,
        baseStats = TowerStats(damage = 12f, range = 170f, fireRateSeconds = 0.45f),
        paths = UpgradeCatalog.ARCHER
    ),
    CANNON(
        displayName = "Cannon Tower",
        baseCost = 180,
        unlockWave = 1,
        colorArgb = 0xFF8A8F98.toInt(),
        projectileType = ProjectileType.CANNONBALL,
        baseStats = TowerStats(damage = 34f, range = 150f, fireRateSeconds = 1.30f, splashRadius = 55f),
        paths = UpgradeCatalog.CANNON
    ),
    FROST(
        displayName = "Frost Tower",
        baseCost = 130,
        unlockWave = 3,
        colorArgb = 0xFF6FD6D0.toInt(),
        projectileType = ProjectileType.FROST_SHARD,
        baseStats = TowerStats(
            damage = 6f, range = 140f, fireRateSeconds = 0.90f,
            slowMultiplier = 0.60f, slowDurationSeconds = 1.5f
        ),
        paths = UpgradeCatalog.FROST
    ),
    RANGER(
        displayName = "Ranger Tower",
        baseCost = 220,
        unlockWave = 6,
        colorArgb = 0xFFA3B565.toInt(),
        projectileType = ProjectileType.RANGER_DART,
        baseStats = TowerStats(damage = 48f, range = 260f, fireRateSeconds = 1.10f, armorPenetration = 6f),
        paths = UpgradeCatalog.RANGER
    ),
    LIGHTNING(
        displayName = "Lightning Tower",
        baseCost = 260,
        unlockWave = 10,
        colorArgb = 0xFFC9A6FF.toInt(),
        projectileType = ProjectileType.LIGHTNING_BOLT,
        baseStats = TowerStats(
            damage = 18f, range = 150f, fireRateSeconds = 0.85f,
            chainCount = 2, chainRadius = 90f, chainDamageFalloff = 0.65f
        ),
        paths = UpgradeCatalog.LIGHTNING
    );

    fun isUnlockedAt(highestWaveCompleted: Int): Boolean = highestWaveCompleted + 1 >= unlockWave
}
