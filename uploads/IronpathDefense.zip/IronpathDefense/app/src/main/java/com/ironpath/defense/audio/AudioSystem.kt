package com.ironpath.defense.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import java.io.IOException

/**
 * Thin SoundPool wrapper for short SFX plus an optional looping music track.
 *
 * Every sound is loaded once (here, at construction) and replayed by ID from
 * then on via [play] — gameplay code never constructs a new player object
 * per shot/hit/explosion, which matters since a busy wave can trigger dozens
 * of these a second (see spec: "Avoid creating a new audio player object for
 * every projectile or enemy").
 *
 * No .ogg files ship in this project (see README's Assets section) — every
 * load is wrapped in try/catch so a missing asset degrades to a harmless
 * no-op rather than a crash. The game is fully playable silent today and
 * picks up real audio the moment files matching [SoundEffect]'s asset names
 * (and `audio/music_loop.ogg` for music) are dropped into `assets/audio/`.
 */
class AudioSystem(context: Context) {

    // Only ever needed for asset access, so hold the application context —
    // never the Activity — for the lifetime of this object.
    private val appContext = context.applicationContext

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(MAX_CONCURRENT_STREAMS)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundIds = HashMap<SoundEffect, Int>()
    private var musicPlayer: MediaPlayer? = null

    var sfxEnabled = true

    // Custom setter (rather than a separate setMusicEnabled() fun, which would clash
    // with the JVM setter Kotlin generates for this property) so that turning music
    // off always stops the player — there's no way to flip the flag and skip that.
    var musicEnabled = true
        set(value) {
            field = value
            if (!value) stopMusic()
        }

    init {
        for (effect in SoundEffect.entries) loadSafely(effect)
    }

    private fun loadSafely(effect: SoundEffect) {
        try {
            appContext.assets.openFd("audio/${effect.assetFileName}").use { descriptor ->
                soundIds[effect] = soundPool.load(descriptor, LOAD_PRIORITY)
            }
        } catch (_: IOException) {
            // Asset not present yet — play() will silently no-op for this effect.
        }
    }

    fun play(effect: SoundEffect, volume: Float = 1f) {
        if (!sfxEnabled) return
        val id = soundIds[effect] ?: return
        soundPool.play(id, volume, volume, LOAD_PRIORITY, 0, 1f)
    }

    fun playMusicLoop(assetPath: String = "audio/music_loop.ogg") {
        if (!musicEnabled || musicPlayer != null) return
        try {
            appContext.assets.openFd(assetPath).use { descriptor ->
                musicPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
                    isLooping = true
                    prepare()
                    start()
                }
            }
        } catch (_: IOException) {
            // No music asset shipped yet — stay silent rather than crash.
        }
    }

    fun stopMusic() {
        musicPlayer?.apply {
            stop()
            release()
        }
        musicPlayer = null
    }

    fun release() {
        stopMusic()
        soundPool.release()
    }

    companion object {
        private const val MAX_CONCURRENT_STREAMS = 12
        private const val LOAD_PRIORITY = 1
    }
}
