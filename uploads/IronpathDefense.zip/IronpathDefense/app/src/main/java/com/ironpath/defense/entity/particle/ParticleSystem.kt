package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import kotlin.random.Random

/**
 * Pooled hit-spark particles and floating damage numbers. Purely cosmetic —
 * GameWorld decides *whether* to spawn a damage number (respecting the
 * player's "Damage Numbers" setting); this system just manages whatever it's
 * told to spawn.
 */
class ParticleSystem {

    private val particlePool = ObjectPool(64, { Particle() }, { it.alive = false })
    private val activeParticles = ArrayList<Particle>(96)
    val particles: List<Particle> get() = activeParticles

    private val damageNumberPool = ObjectPool(32, { DamageNumber() }, { it.alive = false })
    private val activeDamageNumbers = ArrayList<DamageNumber>(48)
    val damageNumbers: List<DamageNumber> get() = activeDamageNumbers

    fun spawnHitBurst(position: Vector2, colorArgb: Int, sparkCount: Int = 6) {
        repeat(sparkCount) {
            val p = particlePool.obtain()
            val angle = Random.nextFloat() * (2f * Math.PI.toFloat())
            val speed = 60f + Random.nextFloat() * 90f
            p.position.set(position)
            p.velocity.set(kotlin.math.cos(angle) * speed, kotlin.math.sin(angle) * speed)
            p.lifeTotal = 0.35f + Random.nextFloat() * 0.15f
            p.lifeRemaining = p.lifeTotal
            p.colorArgb = colorArgb
            p.startRadius = 3f + Random.nextFloat() * 2.5f
            p.alive = true
            activeParticles.add(p)
        }
    }

    fun spawnDamageNumber(position: Vector2, value: Int) {
        val d = damageNumberPool.obtain()
        d.position.set(position.x + Random.nextFloat() * 10f - 5f, position.y)
        d.value = value
        d.lifeTotal = 0.7f
        d.lifeRemaining = d.lifeTotal
        d.alive = true
        activeDamageNumbers.add(d)
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeParticles.size) {
            val p = activeParticles[i]
            p.lifeRemaining -= dt
            if (p.lifeRemaining <= 0f) {
                removeParticleAt(i)
                continue
            }
            p.position.x += p.velocity.x * dt
            p.position.y += p.velocity.y * dt
            // Gentle drag so sparks settle rather than flying forever in a straight line.
            val drag = dragFactorFor(dt)
            p.velocity.x *= drag
            p.velocity.y *= drag
            i++
        }

        i = 0
        while (i < activeDamageNumbers.size) {
            val d = activeDamageNumbers[i]
            d.lifeRemaining -= dt
            if (d.lifeRemaining <= 0f) {
                removeDamageNumberAt(i)
                continue
            }
            d.position.y -= DAMAGE_NUMBER_RISE_SPEED * dt
            i++
        }
    }

    fun clear() {
        for (p in activeParticles) { p.alive = false; particlePool.free(p) }
        activeParticles.clear()
        for (d in activeDamageNumbers) { d.alive = false; damageNumberPool.free(d) }
        activeDamageNumbers.clear()
    }

    private fun removeParticleAt(index: Int) {
        val p = activeParticles[index]
        val last = activeParticles.size - 1
        activeParticles[index] = activeParticles[last]
        activeParticles.removeAt(last)
        p.alive = false
        particlePool.free(p)
    }

    private fun removeDamageNumberAt(index: Int) {
        val d = activeDamageNumbers[index]
        val last = activeDamageNumbers.size - 1
        activeDamageNumbers[index] = activeDamageNumbers[last]
        activeDamageNumbers.removeAt(last)
        d.alive = false
        damageNumberPool.free(d)
    }

    companion object {
        private const val DAMAGE_NUMBER_RISE_SPEED = 40f

        /** ~6%/sec velocity drag, expressed as a per-tick factor so it scales correctly regardless of dt. */
        private fun dragFactorFor(dt: Float): Float = Math.pow(0.94, dt.toDouble()).toFloat()
    }
}
