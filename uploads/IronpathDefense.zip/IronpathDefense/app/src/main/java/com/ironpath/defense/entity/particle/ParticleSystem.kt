package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.core.Vector2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Pooled cosmetic effects: hit sparks, floating damage numbers, expanding
 * rings, chain-lightning arcs and rising labels. Purely visual — GameWorld
 * decides *whether* to spawn a damage number (respecting the player's
 * "Damage Numbers" setting); this system just manages whatever it's told to
 * spawn and caps how many sparks can exist so a huge wave on a low-end
 * device can't drown the frame in particles.
 */
class ParticleSystem {

    private val particlePool = ObjectPool(64, { Particle() }, { it.alive = false; it.accelY = 0f })
    private val activeParticles = ArrayList<Particle>(96)
    val particles: List<Particle> get() = activeParticles

    private val damageNumberPool = ObjectPool(32, { DamageNumber() }, { it.alive = false; it.isCrit = false })
    private val activeDamageNumbers = ArrayList<DamageNumber>(48)
    val damageNumbers: List<DamageNumber> get() = activeDamageNumbers

    private val ringPool = ObjectPool(16, { ShockRing() }, { it.alive = false })
    private val activeRings = ArrayList<ShockRing>(24)
    val rings: List<ShockRing> get() = activeRings

    private val boltPool = ObjectPool(16, { ArcBolt() }, { it.alive = false })
    private val activeBolts = ArrayList<ArcBolt>(24)
    val bolts: List<ArcBolt> get() = activeBolts

    private val textPool = ObjectPool(8, { FloatingText() }, { it.alive = false })
    private val activeTexts = ArrayList<FloatingText>(12)
    val floatingTexts: List<FloatingText> get() = activeTexts

    fun spawnHitBurst(position: Vector2, colorArgb: Int, sparkCount: Int = 6) {
        repeat(sparkCount) {
            val p = obtainParticle() ?: return
            val angle = Random.nextFloat() * (2f * Math.PI.toFloat())
            val speed = 60f + Random.nextFloat() * 90f
            p.position.set(position)
            p.velocity.set(cos(angle) * speed, sin(angle) * speed)
            p.lifeTotal = 0.35f + Random.nextFloat() * 0.15f
            p.lifeRemaining = p.lifeTotal
            p.colorArgb = colorArgb
            p.startRadius = 3f + Random.nextFloat() * 2.5f
            p.alive = true
            activeParticles.add(p)
        }
    }

    /** The upgrade-purchase flourish: two ripples and a fountain of sparks that drift upward. */
    fun spawnUpgradeBurst(position: Vector2, colorArgb: Int) {
        spawnRing(position, startRadius = 10f, endRadius = 62f, seconds = 0.45f, colorArgb = colorArgb, strokeWidth = 5f)
        spawnRing(position, startRadius = 6f, endRadius = 92f, seconds = 0.65f, colorArgb = 0xFFFFFFFF.toInt(), strokeWidth = 2.5f)

        repeat(UPGRADE_SPARK_COUNT) {
            val p = obtainParticle() ?: return
            val angle = Random.nextFloat() * (2f * Math.PI.toFloat())
            val speed = 40f + Random.nextFloat() * 95f
            p.position.set(position)
            p.velocity.set(cos(angle) * speed, sin(angle) * speed - 40f)
            p.accelY = -70f
            p.lifeTotal = 0.6f + Random.nextFloat() * 0.35f
            p.lifeRemaining = p.lifeTotal
            p.colorArgb = colorArgb
            p.startRadius = 3.5f + Random.nextFloat() * 3f
            p.alive = true
            activeParticles.add(p)
        }
    }

    fun spawnRing(
        position: Vector2,
        startRadius: Float,
        endRadius: Float,
        seconds: Float,
        colorArgb: Int,
        strokeWidth: Float = 4f
    ) {
        if (activeRings.size >= MAX_RINGS) return
        val r = ringPool.obtain()
        r.position.set(position)
        r.startRadius = startRadius
        r.endRadius = endRadius
        r.strokeWidth = strokeWidth
        r.colorArgb = colorArgb
        r.lifeTotal = seconds
        r.lifeRemaining = seconds
        r.alive = true
        activeRings.add(r)
    }

    fun spawnBolt(from: Vector2, to: Vector2, colorArgb: Int) {
        if (activeBolts.size >= MAX_BOLTS) return
        val b = boltPool.obtain()
        b.from.set(from)
        b.to.set(to)
        b.colorArgb = colorArgb
        b.lifeTotal = BOLT_SECONDS
        b.lifeRemaining = BOLT_SECONDS
        b.alive = true
        activeBolts.add(b)
    }

    fun spawnFloatingText(position: Vector2, text: String, colorArgb: Int, seconds: Float = 1.3f) {
        if (activeTexts.size >= MAX_TEXTS) return
        val t = textPool.obtain()
        t.position.set(position)
        t.text = text
        t.colorArgb = colorArgb
        t.lifeTotal = seconds
        t.lifeRemaining = seconds
        t.alive = true
        activeTexts.add(t)
    }

    fun spawnDamageNumber(position: Vector2, value: Int, isCrit: Boolean = false) {
        val d = damageNumberPool.obtain()
        d.position.set(position.x + Random.nextFloat() * 10f - 5f, position.y)
        d.value = value
        d.isCrit = isCrit
        d.lifeTotal = if (isCrit) 0.95f else 0.7f
        d.lifeRemaining = d.lifeTotal
        d.alive = true
        activeDamageNumbers.add(d)
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeParticles.size) {
            val p = activeParticles[i]
            p.lifeRemaining -= dt
            if (p.lifeRemaining <= 0f) {
                removeParticleAt(i)
                continue
            }
            p.velocity.y += p.accelY * dt
            p.position.x += p.velocity.x * dt
            p.position.y += p.velocity.y * dt
            // Gentle drag so sparks settle rather than flying forever in a straight line.
            val drag = dragFactorFor(dt)
            p.velocity.x *= drag
            p.velocity.y *= drag
            i++
        }

        i = 0
        while (i < activeDamageNumbers.size) {
            val d = activeDamageNumbers[i]
            d.lifeRemaining -= dt
            if (d.lifeRemaining <= 0f) {
                removeDamageNumberAt(i)
                continue
            }
            d.position.y -= DAMAGE_NUMBER_RISE_SPEED * dt
            i++
        }

        i = 0
        while (i < activeRings.size) {
            val r = activeRings[i]
            r.lifeRemaining -= dt
            if (r.lifeRemaining <= 0f) {
                swapRemove(activeRings, i)
                r.alive = false
                ringPool.free(r)
                continue
            }
            i++
        }

        i = 0
        while (i < activeBolts.size) {
            val b = activeBolts[i]
            b.lifeRemaining -= dt
            if (b.lifeRemaining <= 0f) {
                swapRemove(activeBolts, i)
                b.alive = false
                boltPool.free(b)
                continue
            }
            i++
        }

        i = 0
        while (i < activeTexts.size) {
            val t = activeTexts[i]
            t.lifeRemaining -= dt
            if (t.lifeRemaining <= 0f) {
                swapRemove(activeTexts, i)
                t.alive = false
                textPool.free(t)
                continue
            }
            t.position.y -= FLOATING_TEXT_RISE_SPEED * dt
            i++
        }
    }

    fun clear() {
        for (p in activeParticles) { p.alive = false; particlePool.free(p) }
        activeParticles.clear()
        for (d in activeDamageNumbers) { d.alive = false; damageNumberPool.free(d) }
        activeDamageNumbers.clear()
        for (r in activeRings) { r.alive = false; ringPool.free(r) }
        activeRings.clear()
        for (b in activeBolts) { b.alive = false; boltPool.free(b) }
        activeBolts.clear()
        for (t in activeTexts) { t.alive = false; textPool.free(t) }
        activeTexts.clear()
    }

    /** A pooled spark, or null when the on-screen spark cap is reached. */
    private fun obtainParticle(): Particle? =
        if (activeParticles.size >= MAX_PARTICLES) null else particlePool.obtain()

    private fun removeParticleAt(index: Int) {
        val p = activeParticles[index]
        swapRemove(activeParticles, index)
        p.alive = false
        particlePool.free(p)
    }

    private fun removeDamageNumberAt(index: Int) {
        val d = activeDamageNumbers[index]
        swapRemove(activeDamageNumbers, index)
        d.alive = false
        damageNumberPool.free(d)
    }

    /** O(1) removal: order of these lists has no meaning, so swap the last element into the gap. */
    private fun <T> swapRemove(list: ArrayList<T>, index: Int) {
        val last = list.size - 1
        list[index] = list[last]
        list.removeAt(last)
    }

    companion object {
        private const val DAMAGE_NUMBER_RISE_SPEED = 40f
        private const val FLOATING_TEXT_RISE_SPEED = 26f
        private const val UPGRADE_SPARK_COUNT = 22
        private const val BOLT_SECONDS = 0.16f
        private const val MAX_PARTICLES = 320
        private const val MAX_RINGS = 40
        private const val MAX_BOLTS = 40
        private const val MAX_TEXTS = 10

        /** ~6%/sec velocity drag, expressed as a per-tick factor so it scales correctly regardless of dt. */
        private fun dragFactorFor(dt: Float): Float = Math.pow(0.94, dt.toDouble()).toFloat()
    }
}
