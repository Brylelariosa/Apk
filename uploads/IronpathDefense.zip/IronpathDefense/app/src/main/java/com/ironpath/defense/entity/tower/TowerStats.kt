package com.ironpath.defense.entity.tower

import com.ironpath.defense.entity.projectile.ShotProfile

/**
 * A tower's fully-resolved combat numbers at this moment: the type's
 * [TowerType.baseStats] with every purchased upgrade folded in (see
 * `Tower.applyUpgrade`). Immutable — an upgrade produces a new copy — so the
 * per-tick systems can read it without worrying about it changing mid-read.
 *
 * Not every field applies to every tower; irrelevant ones sit at a neutral
 * default (0 for "off", 1 for multipliers), which is what lets one class
 * describe all five archetypes and every upgrade combination.
 */
data class TowerStats(
    val damage: Float,
    val range: Float,
    /** Seconds between volleys. Lower is faster. */
    val fireRateSeconds: Float,

    val splashRadius: Float = 0f,
    val armorPenetration: Float = 0f,

    val slowMultiplier: Float = 1f,
    val slowDurationSeconds: Float = 0f,

    val chainCount: Int = 0,
    val chainRadius: Float = 0f,
    val chainDamageFalloff: Float = 1f,

    /** Projectiles per volley; each one is aimed at a distinct target when enough are in range. */
    val projectilesPerShot: Int = 1,

    val critChance: Float = 0f,
    val critMultiplier: Float = 1f,

    /** Damage-over-time applied on hit; ignores armor. [dotColorArgb] tints the flames/poison. */
    val burnDps: Float = 0f,
    val burnSeconds: Float = 0f,
    val dotColorArgb: Int = DEFAULT_DOT_COLOR,

    /** Chance per hit to stun for [freezeSeconds] (bosses only lose part of it — see Enemy.applyStun). */
    val freezeChance: Float = 0f,
    val freezeSeconds: Float = 0f,

    /** Marked enemies take this much extra damage (0.2 = +20%) from every source for the duration. */
    val vulnerabilityBonus: Float = 0f,
    val vulnerabilitySeconds: Float = 0f,

    val bossDamageMultiplier: Float = 1f,
    /** Non-boss enemies at or below this health fraction are killed outright by a hit. */
    val executeThreshold: Float = 0f,

    /** Periodic nova around the tower, independent of its normal shots. 0 damage = none. */
    val pulseDamage: Float = 0f,
    val pulseIntervalSeconds: Float = 0f,
    val pulseRadius: Float = 0f
) {
    val shotsPerSecond: Float
        get() = if (fireRateSeconds > 0f) projectilesPerShot / fireRateSeconds else 0f

    companion object {
        val DEFAULT_DOT_COLOR: Int = 0xFFFF8A2B.toInt()
    }
}

/**
 * Copies this tower's on-hit behavior into [shot] (a pooled projectile's
 * profile, or the tower's pulse profile). Lives here rather than on
 * ShotProfile so the projectile package never has to know TowerStats exists.
 */
fun TowerStats.writeShot(shot: ShotProfile, damage: Float, isCrit: Boolean, colorArgb: Int) {
    shot.damage = damage
    shot.isCrit = isCrit
    shot.colorArgb = colorArgb
    shot.armorPenetration = armorPenetration
    shot.splashRadius = splashRadius
    shot.slowMultiplier = slowMultiplier
    shot.slowDurationSeconds = slowDurationSeconds
    shot.chainCount = chainCount
    shot.chainRadius = chainRadius
    shot.chainDamageFalloff = chainDamageFalloff
    shot.burnDps = burnDps
    shot.burnSeconds = burnSeconds
    shot.burnColorArgb = dotColorArgb
    shot.freezeChance = freezeChance
    shot.freezeSeconds = freezeSeconds
    shot.vulnerabilityBonus = vulnerabilityBonus
    shot.vulnerabilitySeconds = vulnerabilitySeconds
    shot.bossDamageMultiplier = bossDamageMultiplier
    shot.executeThreshold = executeThreshold
}
