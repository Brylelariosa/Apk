package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.entity.tower.TargetingMode
import com.ironpath.defense.entity.tower.TowerType

/**
 * Draws every non-world pixel: the always-visible top/bottom bars during
 * play, and whichever full-screen overlay [HudState.screenState] calls for.
 *
 * All Paint objects are fields, reused and mutated (color/textSize/alpha)
 * per draw call rather than constructed fresh — the same allocation-avoidance
 * discipline as [com.ironpath.defense.render.WorldRenderer].
 */
class HudRenderer {

    private val panelPaint = Paint().apply { color = Palette.PANEL }
    private val scrimPaint = Paint().apply { color = 0xAA000000.toInt() }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Palette.BUTTON_BORDER
    }
    private val buttonFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.CENTER
    }
    private val leftTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.LEFT
    }
    private val swatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(canvas: Canvas, layout: UiLayout, state: HudState) {
        when (state.screenState) {
            GameScreenState.MAIN_MENU -> drawMainMenu(canvas, layout, state)
            GameScreenState.PLAYING -> {
                drawTopBar(canvas, layout, state)
                drawBottomBar(canvas, layout, state)
            }
            GameScreenState.PAUSED -> {
                drawTopBar(canvas, layout, state)
                drawBottomBar(canvas, layout, state)
                drawScrim(canvas, layout)
                drawPauseOverlay(canvas, layout)
            }
            GameScreenState.SETTINGS -> {
                drawTopBar(canvas, layout, state)
                drawBottomBar(canvas, layout, state)
                drawScrim(canvas, layout)
                drawSettingsOverlay(canvas, layout, state)
            }
            GameScreenState.GAME_OVER -> {
                drawTopBar(canvas, layout, state)
                drawScrim(canvas, layout)
                drawEndScreen(canvas, layout, state, won = false)
            }
            GameScreenState.VICTORY -> {
                drawTopBar(canvas, layout, state)
                drawScrim(canvas, layout)
                drawEndScreen(canvas, layout, state, won = true)
            }
        }
    }

    // --- Top / bottom bars --------------------------------------------------

    private fun drawTopBar(canvas: Canvas, layout: UiLayout, state: HudState) {
        canvas.drawRect(layout.topBar, panelPaint)

        leftTextPaint.textSize = layout.topBar.height() * 0.42f
        leftTextPaint.color = Palette.ACCENT_EMBER
        canvas.drawText("$${state.money}", layout.topBar.height() * 0.3f, layout.topBar.centerY() + leftTextPaint.textSize * 0.35f, leftTextPaint)

        leftTextPaint.color = if (state.lives <= state.maxLives / 4) Palette.DANGER else Palette.TEXT_PRIMARY
        val livesX = layout.topBar.width() * 0.16f
        canvas.drawText("Lives ${state.lives}/${state.maxLives}", livesX, layout.topBar.centerY() + leftTextPaint.textSize * 0.35f, leftTextPaint)

        leftTextPaint.color = Palette.TEXT_SECONDARY
        val waveX = layout.topBar.width() * 0.34f
        val waveLabel = buildString {
            append("Wave ${state.waveNumber}/${state.totalWaves}")
            if (state.isBossWave) append("  \u2620") // skull glyph flags a boss wave
        }
        canvas.drawText(waveLabel, waveX, layout.topBar.centerY() + leftTextPaint.textSize * 0.35f, leftTextPaint)

        drawButton(canvas, layout.startWaveButton, if (state.waveInProgress) "In Progress" else "Start Wave", enabled = state.canStartWave)
        drawButton(canvas, layout.speedButton, "${state.speedMultiplier.toInt()}x", enabled = true)
        drawButton(canvas, layout.pauseButton, "II", enabled = true)
    }

    private fun drawBottomBar(canvas: Canvas, layout: UiLayout, state: HudState) {
        canvas.drawRect(layout.bottomBar, panelPaint)
        val selected = state.selectedTower
        if (selected != null) {
            drawTowerInfoPanel(canvas, layout, state)
        } else {
            drawShopRow(canvas, layout, state)
        }
    }

    private fun drawShopRow(canvas: Canvas, layout: UiLayout, state: HudState) {
        for (type in TowerType.entries) {
            val rect = layout.towerShopSlots[type.ordinal]
            val unlocked = type.isUnlockedAt(state.highestWaveCompleted)
            val affordable = state.money >= type.baseCost
            val armed = state.pendingTowerType == type

            buttonFillPaint.color = when {
                !unlocked -> Palette.BUTTON_DISABLED
                armed -> Palette.ACCENT_EMBER
                else -> Palette.BUTTON_ENABLED
            }
            val inset = 6f
            val slotRect = RectF(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
            canvas.drawRoundRect(slotRect, 12f, 12f, buttonFillPaint)
            canvas.drawRoundRect(slotRect, 12f, 12f, borderPaint)

            val swatchRadius = slotRect.height() * 0.16f
            swatchPaint.color = type.colorArgb
            canvas.drawCircle(slotRect.centerX(), slotRect.top + slotRect.height() * 0.28f, swatchRadius, swatchPaint)

            textPaint.textSize = slotRect.height() * 0.15f
            textPaint.color = if (unlocked) Palette.TEXT_PRIMARY else Palette.TEXT_DISABLED
            canvas.drawText(type.displayName.removeSuffix(" Tower"), slotRect.centerX(), slotRect.top + slotRect.height() * 0.58f, textPaint)

            textPaint.textSize = slotRect.height() * 0.14f
            textPaint.color = when {
                !unlocked -> Palette.TEXT_DISABLED
                !affordable -> Palette.TEXT_SECONDARY
                else -> Palette.ACCENT_EMBER
            }
            val subLabel = if (unlocked) "$${type.baseCost}" else "Wave ${type.unlockWave}"
            canvas.drawText(subLabel, slotRect.centerX(), slotRect.top + slotRect.height() * 0.80f, textPaint)
        }
    }

    private fun drawTowerInfoPanel(canvas: Canvas, layout: UiLayout, state: HudState) {
        val tower = state.selectedTower ?: return

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Palette.TEXT_PRIMARY
        textPaint.textSize = layout.infoTextArea.height() * 0.42f
        val margin = layout.infoTextArea.height() * 0.2f
        canvas.drawText(
            "${tower.type.displayName}  \u2022  Tier ${tower.tier}/${tower.type.maxTier}",
            margin, layout.infoTextArea.centerY() + textPaint.textSize * 0.35f, textPaint
        )
        textPaint.textAlign = Paint.Align.CENTER

        val upgradeLabel = if (tower.canUpgrade) "Upgrade $${tower.type.statsFor(tower.tier + 1).upgradeCost}" else "Max Tier"
        drawButton(canvas, layout.upgradeButton, upgradeLabel, enabled = tower.canUpgrade && state.money >= (tower.type.statsFor(tower.tier + 1).upgradeCost))
        drawButton(canvas, layout.sellButton, "Sell $${tower.sellValue}", enabled = true)
        drawButton(canvas, layout.targetingButton, targetingLabel(tower.targetingMode), enabled = true)
        drawButton(canvas, layout.closeButton, "Close", enabled = true)
    }

    private fun targetingLabel(mode: TargetingMode) = "Target:\n${mode.displayName}"

    // --- Overlays ------------------------------------------------------------

    private fun drawScrim(canvas: Canvas, layout: UiLayout) {
        canvas.drawRect(0f, 0f, layout.screenWidth, layout.screenHeight, scrimPaint)
    }

    private fun drawMainMenu(canvas: Canvas, layout: UiLayout, state: HudState) {
        canvas.drawColor(Palette.VOID_BACKGROUND)

        textPaint.color = Palette.ACCENT_EMBER
        textPaint.textSize = layout.screenHeight * 0.11f
        canvas.drawText("IRONPATH DEFENSE", layout.screenWidth / 2f, layout.screenHeight * 0.28f, textPaint)

        textPaint.color = Palette.TEXT_SECONDARY
        textPaint.textSize = layout.screenHeight * 0.05f
        canvas.drawText("Best wave: ${state.highestWaveCompleted}", layout.screenWidth / 2f, layout.screenHeight * 0.38f, textPaint)

        drawButton(canvas, layout.mainMenuPlayButton, "Play", enabled = true)
    }

    private fun drawPauseOverlay(canvas: Canvas, layout: UiLayout) {
        textPaint.color = Palette.TEXT_PRIMARY
        textPaint.textSize = layout.screenHeight * 0.08f
        canvas.drawText("Paused", layout.screenWidth / 2f, layout.pauseResumeButton.top - layout.screenHeight * 0.05f, textPaint)

        drawButton(canvas, layout.pauseResumeButton, "Resume", enabled = true)
        drawButton(canvas, layout.pauseSettingsButton, "Settings", enabled = true)
        drawButton(canvas, layout.pauseMainMenuButton, "Main Menu", enabled = true)
    }

    private fun drawSettingsOverlay(canvas: Canvas, layout: UiLayout, state: HudState) {
        textPaint.color = Palette.TEXT_PRIMARY
        textPaint.textSize = layout.screenHeight * 0.07f
        canvas.drawText("Settings", layout.screenWidth / 2f, layout.settingsMusicRow.top - layout.screenHeight * 0.05f, textPaint)

        drawButton(canvas, layout.settingsMusicRow, "Music: ${if (state.musicOn) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsSfxRow, "Sound Effects: ${if (state.sfxOn) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsDamageNumbersRow, "Damage Numbers: ${if (state.showDamageNumbers) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsCloseButton, "Close", enabled = true)
    }

    private fun drawEndScreen(canvas: Canvas, layout: UiLayout, state: HudState, won: Boolean) {
        textPaint.color = if (won) Palette.ACCENT_EMBER else Palette.DANGER
        textPaint.textSize = layout.screenHeight * 0.08f
        canvas.drawText(
            if (won) "Ironpath Secured" else "The Path Has Fallen",
            layout.screenWidth / 2f, layout.endScreenRetryButton.top - layout.screenHeight * 0.12f, textPaint
        )

        textPaint.color = Palette.TEXT_SECONDARY
        textPaint.textSize = layout.screenHeight * 0.045f
        canvas.drawText(
            "Best wave: ${state.highestWaveCompleted}",
            layout.screenWidth / 2f, layout.endScreenRetryButton.top - layout.screenHeight * 0.04f, textPaint
        )

        drawButton(canvas, layout.endScreenRetryButton, if (won) "Play Again" else "Try Again", enabled = true)
    }

    // --- Shared button primitive ---------------------------------------------

    private fun drawButton(canvas: Canvas, rect: RectF, label: String, enabled: Boolean) {
        buttonFillPaint.color = if (enabled) Palette.BUTTON_ENABLED else Palette.BUTTON_DISABLED
        val cornerRadius = rect.height() * 0.18f
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, buttonFillPaint)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, borderPaint)

        textPaint.color = if (enabled) Palette.TEXT_PRIMARY else Palette.TEXT_DISABLED

        if (label.contains('\n')) {
            val lines = label.split('\n')
            textPaint.textSize = rect.height() * 0.26f
            val lineHeight = textPaint.textSize * 1.05f
            val startY = rect.centerY() - lineHeight * (lines.size - 1) / 2f + textPaint.textSize * 0.35f
            for ((i, line) in lines.withIndex()) {
                canvas.drawText(line, rect.centerX(), startY + i * lineHeight, textPaint)
            }
        } else {
            textPaint.textSize = rect.height() * 0.32f
            canvas.drawText(label, rect.centerX(), rect.centerY() + textPaint.textSize * 0.35f, textPaint)
        }
    }
}
