package com.ironpath.defense.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.ironpath.defense.core.GameScreenState
import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules

/**
 * Draws every non-world pixel: the floating status chips and buttons, the
 * tower shop dock, the tower upgrade panel, and whichever full-screen
 * overlay [HudState.screenState] calls for. Nothing here carves space out of
 * the battlefield — it all floats over it.
 *
 * All Paint objects are fields, reused and mutated (color/textSize/alpha)
 * per draw call rather than constructed fresh — the same allocation-avoidance
 * discipline as [com.ironpath.defense.render.WorldRenderer]. Each text
 * alignment has its own Paint so drawing one never leaks alignment into the next.
 */
class HudRenderer {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scrimPaint = Paint().apply { color = 0xAA000000.toInt() }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = Palette.BUTTON_BORDER
    }
    private val accentBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val buttonFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.CENTER
    }
    private val leftTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.LEFT
    }
    private val boldLeftTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.LEFT
        isFakeBoldText = true
    }
    private val rightTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.TEXT_PRIMARY
        textAlign = Paint.Align.RIGHT
        isFakeBoldText = true
    }
    private val swatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pipOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val slotRect = RectF()

    /** Wrapped description lines, cached so the panel never re-measures text every frame. */
    private class WrapEntry(var widthPx: Int, var sizePx: Int, var lines: List<String>)
    private val wrapCache = HashMap<String, WrapEntry>()

    fun draw(canvas: Canvas, layout: UiLayout, state: HudState) {
        when (state.screenState) {
            GameScreenState.MAIN_MENU -> drawMainMenu(canvas, layout, state)
            GameScreenState.PLAYING -> drawPlayingHud(canvas, layout, state)
            GameScreenState.PAUSED -> {
                drawPlayingHud(canvas, layout, state)
                drawScrim(canvas, layout)
                drawPauseOverlay(canvas, layout)
            }
            GameScreenState.SETTINGS -> {
                drawPlayingHud(canvas, layout, state)
                drawScrim(canvas, layout)
                drawSettingsOverlay(canvas, layout, state)
            }
            GameScreenState.GAME_OVER -> {
                drawTopHud(canvas, layout, state)
                drawScrim(canvas, layout)
                drawEndScreen(canvas, layout, state, won = false)
            }
            GameScreenState.VICTORY -> {
                drawTopHud(canvas, layout, state)
                drawScrim(canvas, layout)
                drawEndScreen(canvas, layout, state, won = true)
            }
        }
    }

    // --- In-game HUD ----------------------------------------------------------

    private fun drawPlayingHud(canvas: Canvas, layout: UiLayout, state: HudState) {
        drawTopHud(canvas, layout, state)
        if (state.selectedTower != null) {
            drawTowerPanel(canvas, layout, state)
        } else {
            drawShopDock(canvas, layout, state)
        }
    }

    private fun drawTopHud(canvas: Canvas, layout: UiLayout, state: HudState) {
        drawChip(canvas, layout.moneyChip, "$${state.money}", Palette.ACCENT_EMBER)

        val livesColor = if (state.lives <= state.maxLives / 4) Palette.DANGER else Palette.TEXT_PRIMARY
        drawChip(canvas, layout.livesChip, "Lives ${state.lives}/${state.maxLives}", livesColor)

        val waveLabel = buildString {
            append("Wave ${state.waveNumber}/${state.totalWaves}")
            if (state.isBossWave) append("  BOSS")
        }
        drawChip(canvas, layout.waveChip, waveLabel, if (state.isBossWave) Palette.DANGER else Palette.TEXT_SECONDARY)

        drawButton(canvas, layout.startWaveButton, if (state.waveInProgress) "In Progress" else "Start Wave", enabled = state.canStartWave)
        drawButton(canvas, layout.speedButton, "${state.speedMultiplier.toInt()}x", enabled = true)
        drawButton(canvas, layout.pauseButton, "II", enabled = true)
    }

    /** A translucent rounded pill holding one line of status text, shrunk to fit if needed. */
    private fun drawChip(canvas: Canvas, rect: RectF, label: String, color: Int) {
        val radius = rect.height() * 0.3f
        fillPaint.color = Palette.PANEL_OVERLAY
        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        canvas.drawRoundRect(rect, radius, radius, borderPaint)

        val padding = rect.height() * 0.35f
        boldLeftTextPaint.color = color
        boldLeftTextPaint.textSize = rect.height() * 0.46f
        val measured = boldLeftTextPaint.measureText(label)
        val available = rect.width() - padding * 2f
        if (measured > available && measured > 0f) boldLeftTextPaint.textSize *= available / measured
        canvas.drawText(label, rect.left + padding, rect.centerY() + boldLeftTextPaint.textSize * 0.35f, boldLeftTextPaint)
    }

    // --- Shop dock ------------------------------------------------------------

    private fun drawShopDock(canvas: Canvas, layout: UiLayout, state: HudState) {
        val dock = layout.shopDock
        val dockRadius = dock.height() * 0.14f
        fillPaint.color = Palette.PANEL_OVERLAY
        canvas.drawRoundRect(dock, dockRadius, dockRadius, fillPaint)
        canvas.drawRoundRect(dock, dockRadius, dockRadius, borderPaint)

        state.pendingTowerType?.let { armed ->
            textPaint.color = Palette.ACCENT_EMBER
            textPaint.textSize = layout.screenHeight * 0.035f
            canvas.drawText(
                "Tap a lit tile to build the ${armed.displayName}",
                layout.screenWidth / 2f, dock.top - layout.screenHeight * 0.02f, textPaint
            )
        }

        for (type in TowerType.entries) {
            val rect = layout.towerShopSlots[type.ordinal]
            val unlocked = type.isUnlockedAt(state.highestWaveCompleted)
            val affordable = state.money >= type.baseCost
            val armed = state.pendingTowerType == type

            buttonFillPaint.color = when {
                !unlocked -> Palette.BUTTON_DISABLED
                armed -> Palette.ACCENT_EMBER
                else -> Palette.BUTTON_ENABLED
            }
            val inset = 3f
            slotRect.set(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
            val corner = slotRect.height() * 0.14f
            canvas.drawRoundRect(slotRect, corner, corner, buttonFillPaint)
            canvas.drawRoundRect(slotRect, corner, corner, borderPaint)

            val swatchRadius = slotRect.height() * 0.16f
            swatchPaint.color = type.colorArgb
            canvas.drawCircle(slotRect.centerX(), slotRect.top + slotRect.height() * 0.28f, swatchRadius, swatchPaint)

            textPaint.textSize = slotRect.height() * 0.15f
            textPaint.color = if (unlocked) Palette.TEXT_PRIMARY else Palette.TEXT_DISABLED
            canvas.drawText(type.displayName.removeSuffix(" Tower"), slotRect.centerX(), slotRect.top + slotRect.height() * 0.58f, textPaint)

            textPaint.textSize = slotRect.height() * 0.14f
            textPaint.color = when {
                !unlocked -> Palette.TEXT_DISABLED
                !affordable -> Palette.TEXT_SECONDARY
                else -> Palette.ACCENT_EMBER
            }
            val subLabel = if (unlocked) "$${type.baseCost}" else "Wave ${type.unlockWave}"
            canvas.drawText(subLabel, slotRect.centerX(), slotRect.top + slotRect.height() * 0.80f, textPaint)
        }
    }

    // --- Tower panel: class title, stats, three upgrade paths, actions -----------

    private fun drawTowerPanel(canvas: Canvas, layout: UiLayout, state: HudState) {
        val tower = state.selectedTower ?: return
        val accent = tower.accentColorArgb
        val panel = layout.towerPanel
        val corner = panel.width() * 0.035f

        fillPaint.color = Palette.PANEL_OVERLAY
        canvas.drawRoundRect(panel, corner, corner, fillPaint)
        accentBorderPaint.color = accent
        canvas.drawRoundRect(panel, corner, corner, accentBorderPaint)

        drawPanelHeader(canvas, layout, tower, accent)
        drawPanelStats(canvas, layout, tower)
        for (path in layout.pathCards.indices) drawPathCard(canvas, layout, state, tower, path)

        drawButton(canvas, layout.targetingButton, "Target:\n${tower.targetingMode.displayName}", enabled = true)
        drawButton(canvas, layout.sellButton, "Sell $${tower.sellValue}", enabled = true)
        drawButton(canvas, layout.closeButton, "Close", enabled = true)
    }

    private fun drawPanelHeader(canvas: Canvas, layout: UiLayout, tower: Tower, accent: Int) {
        val header = layout.panelHeader

        leftTextPaint.color = Palette.TEXT_SECONDARY
        leftTextPaint.textSize = header.height() * 0.30f
        canvas.drawText(tower.type.displayName, header.left, header.top + header.height() * 0.32f, leftTextPaint)

        val hasClass = tower.dominantPath >= 0
        boldLeftTextPaint.color = if (hasClass) accent else Palette.TEXT_PRIMARY
        boldLeftTextPaint.textSize = header.height() * 0.48f
        val title = if (hasClass) tower.classTitle else "No upgrades yet"
        val maxTitleWidth = header.width() * 0.72f
        val measured = boldLeftTextPaint.measureText(title)
        if (measured > maxTitleWidth && measured > 0f) boldLeftTextPaint.textSize *= maxTitleWidth / measured
        canvas.drawText(title, header.left, header.top + header.height() * 0.86f, boldLeftTextPaint)

        // The build code, e.g. "5-2-0": how far up each path this tower is.
        rightTextPaint.color = if (hasClass) accent else Palette.TEXT_SECONDARY
        rightTextPaint.textSize = header.height() * 0.40f
        val tiers = tower.pathTiers
        canvas.drawText("${tiers[0]}-${tiers[1]}-${tiers[2]}", header.right, header.top + header.height() * 0.40f, rightTextPaint)
    }

    private fun drawPanelStats(canvas: Canvas, layout: UiLayout, tower: Tower) {
        val stats = tower.stats
        val row = layout.panelStats
        val shotsPerSecond = (stats.shotsPerSecond * 10f).toInt() / 10f

        leftTextPaint.color = Palette.TEXT_SECONDARY
        leftTextPaint.textSize = row.height() * 0.50f
        canvas.drawText(
            "DMG ${stats.damage.toInt()}    RNG ${stats.range.toInt()}    ${shotsPerSecond}/s",
            row.left, row.centerY() + leftTextPaint.textSize * 0.35f, leftTextPaint
        )
    }

    private fun drawPathCard(canvas: Canvas, layout: UiLayout, state: HudState, tower: Tower, path: Int) {
        val rect = layout.pathCards[path]
        val definition = tower.type.paths[path]
        val tier = tower.pathTiers[path]
        val availability = tower.upgradeAvailability(path)
        val next = tower.nextUpgrade(path)
        val affordable = next != null && state.money >= next.cost
        val canBuy = availability == UpgradeAvailability.AVAILABLE && affordable
        val h = rect.height()
        val corner = h * 0.12f
        val inactive = availability != UpgradeAvailability.AVAILABLE

        fillPaint.color = if (inactive) Palette.BUTTON_DISABLED else Palette.PANEL_OVERLAY_LIGHT
        canvas.drawRoundRect(rect, corner, corner, fillPaint)

        // Colored stripe down the left edge: this path's identity.
        fillPaint.color = definition.colorArgb
        fillPaint.alpha = if (inactive) 90 else 255
        slotRect.set(rect.left, rect.top, rect.left + h * 0.09f, rect.bottom)
        canvas.drawRoundRect(slotRect, corner, corner, fillPaint)
        fillPaint.alpha = 255

        if (canBuy) {
            accentBorderPaint.color = definition.colorArgb
            canvas.drawRoundRect(rect, corner, corner, accentBorderPaint)
        } else {
            canvas.drawRoundRect(rect, corner, corner, borderPaint)
        }

        val textLeft = rect.left + h * 0.20f
        val textRight = rect.right - h * 0.10f
        val textWidth = textRight - textLeft

        // Row 1: path name on the left, tier pips on the right.
        boldLeftTextPaint.color = if (inactive && availability == UpgradeAvailability.LOCKED) Palette.TEXT_DISABLED else definition.colorArgb
        boldLeftTextPaint.textSize = h * 0.19f
        canvas.drawText(definition.name, textLeft, rect.top + h * 0.26f, boldLeftTextPaint)
        drawTierPips(canvas, textRight, rect.top + h * 0.19f, h * 0.045f, tier, definition.colorArgb)

        // Row 2: the next upgrade and its price, or why there isn't one.
        val row2 = rect.top + h * 0.51f
        when (availability) {
            UpgradeAvailability.AVAILABLE -> {
                val upgrade = next ?: return
                boldLeftTextPaint.color = if (affordable) Palette.TEXT_PRIMARY else Palette.TEXT_SECONDARY
                boldLeftTextPaint.textSize = h * 0.19f
                canvas.drawText(upgrade.name, textLeft, row2, boldLeftTextPaint)

                rightTextPaint.color = if (affordable) Palette.SUCCESS else Palette.DANGER
                rightTextPaint.textSize = h * 0.19f
                canvas.drawText("$${upgrade.cost}", textRight, row2, rightTextPaint)
                drawDescription(canvas, upgrade.description, textLeft, rect.top + h * 0.70f, textWidth, h, Palette.TEXT_SECONDARY)
            }
            UpgradeAvailability.LOCKED -> {
                boldLeftTextPaint.color = Palette.TEXT_DISABLED
                boldLeftTextPaint.textSize = h * 0.19f
                canvas.drawText("Locked", textLeft, row2, boldLeftTextPaint)
                drawDescription(canvas, LOCKED_HINT, textLeft, rect.top + h * 0.70f, textWidth, h, Palette.TEXT_DISABLED)
            }
            UpgradeAvailability.MAXED -> {
                boldLeftTextPaint.color = Palette.ACCENT_EMBER
                boldLeftTextPaint.textSize = h * 0.19f
                canvas.drawText("Maxed out", textLeft, row2, boldLeftTextPaint)
                val finalUpgrade = definition.upgrades.last()
                drawDescription(canvas, finalUpgrade.description, textLeft, rect.top + h * 0.70f, textWidth, h, Palette.TEXT_SECONDARY)
            }
        }
    }

    private fun drawTierPips(canvas: Canvas, rightEdge: Float, centerY: Float, radius: Float, tier: Int, color: Int) {
        val spacing = radius * 2.9f
        pipPaint.color = color
        pipOutlinePaint.color = color
        for (i in 0 until UpgradeRules.MAX_TIER) {
            val cx = rightEdge - radius - (UpgradeRules.MAX_TIER - 1 - i) * spacing
            if (i < tier) canvas.drawCircle(cx, centerY, radius, pipPaint)
            else canvas.drawCircle(cx, centerY, radius, pipOutlinePaint)
        }
    }

    /** Up to two wrapped lines of small description text under a path card's headline. */
    private fun drawDescription(
        canvas: Canvas, text: String, left: Float, firstBaseline: Float,
        maxWidth: Float, cardHeight: Float, color: Int
    ) {
        leftTextPaint.color = color
        leftTextPaint.textSize = cardHeight * 0.14f
        val lines = wrap(text, maxWidth, leftTextPaint)
        val lineCount = minOf(lines.size, MAX_DESCRIPTION_LINES)
        for (i in 0 until lineCount) {
            canvas.drawText(lines[i], left, firstBaseline + i * cardHeight * 0.17f, leftTextPaint)
        }
    }

    private fun wrap(text: String, maxWidth: Float, paint: Paint): List<String> {
        val widthPx = maxWidth.toInt()
        val sizePx = paint.textSize.toInt()
        val cached = wrapCache[text]
        if (cached != null && cached.widthPx == widthPx && cached.sizePx == sizePx) return cached.lines

        val lines = computeWrap(text, maxWidth, paint)
        if (cached != null) {
            cached.widthPx = widthPx
            cached.sizePx = sizePx
            cached.lines = lines
        } else {
            wrapCache[text] = WrapEntry(widthPx, sizePx, lines)
        }
        return lines
    }

    private fun computeWrap(text: String, maxWidth: Float, paint: Paint): List<String> {
        val result = ArrayList<String>(3)
        var line = ""
        for (word in text.split(' ')) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (line.isEmpty() || paint.measureText(candidate) <= maxWidth) {
                line = candidate
            } else {
                result.add(line)
                line = word
            }
        }
        if (line.isNotEmpty()) result.add(line)
        return result
    }

    // --- Overlays ------------------------------------------------------------

    private fun drawScrim(canvas: Canvas, layout: UiLayout) {
        canvas.drawRect(0f, 0f, layout.screenWidth, layout.screenHeight, scrimPaint)
    }

    private fun drawMainMenu(canvas: Canvas, layout: UiLayout, state: HudState) {
        canvas.drawColor(Palette.VOID_BACKGROUND)

        textPaint.color = Palette.ACCENT_EMBER
        textPaint.textSize = layout.screenHeight * 0.11f
        canvas.drawText("IRONPATH DEFENSE", layout.screenWidth / 2f, layout.screenHeight * 0.28f, textPaint)

        textPaint.color = Palette.TEXT_SECONDARY
        textPaint.textSize = layout.screenHeight * 0.05f
        canvas.drawText("Best wave: ${state.highestWaveCompleted}", layout.screenWidth / 2f, layout.screenHeight * 0.38f, textPaint)

        drawButton(canvas, layout.mainMenuPlayButton, "Play", enabled = true)
    }

    private fun drawPauseOverlay(canvas: Canvas, layout: UiLayout) {
        textPaint.color = Palette.TEXT_PRIMARY
        textPaint.textSize = layout.screenHeight * 0.08f
        canvas.drawText("Paused", layout.screenWidth / 2f, layout.pauseResumeButton.top - layout.screenHeight * 0.05f, textPaint)

        drawButton(canvas, layout.pauseResumeButton, "Resume", enabled = true)
        drawButton(canvas, layout.pauseSettingsButton, "Settings", enabled = true)
        drawButton(canvas, layout.pauseMainMenuButton, "Main Menu", enabled = true)
    }

    private fun drawSettingsOverlay(canvas: Canvas, layout: UiLayout, state: HudState) {
        textPaint.color = Palette.TEXT_PRIMARY
        textPaint.textSize = layout.screenHeight * 0.07f
        canvas.drawText("Settings", layout.screenWidth / 2f, layout.settingsMusicRow.top - layout.screenHeight * 0.05f, textPaint)

        drawButton(canvas, layout.settingsMusicRow, "Music: ${if (state.musicOn) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsSfxRow, "Sound Effects: ${if (state.sfxOn) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsDamageNumbersRow, "Damage Numbers: ${if (state.showDamageNumbers) "On" else "Off"}", enabled = true)
        drawButton(canvas, layout.settingsCloseButton, "Close", enabled = true)
    }

    private fun drawEndScreen(canvas: Canvas, layout: UiLayout, state: HudState, won: Boolean) {
        textPaint.color = if (won) Palette.ACCENT_EMBER else Palette.DANGER
        textPaint.textSize = layout.screenHeight * 0.08f
        canvas.drawText(
            if (won) "Ironpath Secured" else "The Path Has Fallen",
            layout.screenWidth / 2f, layout.endScreenRetryButton.top - layout.screenHeight * 0.12f, textPaint
        )

        textPaint.color = Palette.TEXT_SECONDARY
        textPaint.textSize = layout.screenHeight * 0.045f
        canvas.drawText(
            "Best wave: ${state.highestWaveCompleted}",
            layout.screenWidth / 2f, layout.endScreenRetryButton.top - layout.screenHeight * 0.04f, textPaint
        )

        drawButton(canvas, layout.endScreenRetryButton, if (won) "Play Again" else "Try Again", enabled = true)
    }

    // --- Shared button primitive ---------------------------------------------

    private fun drawButton(canvas: Canvas, rect: RectF, label: String, enabled: Boolean) {
        buttonFillPaint.color = if (enabled) Palette.BUTTON_ENABLED else Palette.BUTTON_DISABLED
        val cornerRadius = rect.height() * 0.18f
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, buttonFillPaint)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, borderPaint)

        textPaint.color = if (enabled) Palette.TEXT_PRIMARY else Palette.TEXT_DISABLED

        if (label.contains('\n')) {
            val lines = label.split('\n')
            textPaint.textSize = rect.height() * 0.26f
            val lineHeight = textPaint.textSize * 1.05f
            val startY = rect.centerY() - lineHeight * (lines.size - 1) / 2f + textPaint.textSize * 0.35f
            for ((i, line) in lines.withIndex()) {
                canvas.drawText(line, rect.centerX(), startY + i * lineHeight, textPaint)
            }
        } else {
            textPaint.textSize = rect.height() * 0.32f
            canvas.drawText(label, rect.centerX(), rect.centerY() + textPaint.textSize * 0.35f, textPaint)
        }
    }

    private companion object {
        const val MAX_DESCRIPTION_LINES = 2
        const val LOCKED_HINT = "A tower can only use two paths, and only one past tier 2."
    }
}
