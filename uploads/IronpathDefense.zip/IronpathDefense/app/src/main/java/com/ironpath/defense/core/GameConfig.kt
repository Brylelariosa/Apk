package com.ironpath.defense.core

/**
 * Central tuning constants. Kept in one file so balance/perf knobs never
 * hide as magic numbers deep inside a system.
 */
object GameConfig {
    // --- World / grid ---------------------------------------------------
    const val TILE_SIZE = 64f
    const val GRID_COLS = 20
    const val GRID_ROWS = 11
    const val WORLD_WIDTH = GRID_COLS * TILE_SIZE
    const val WORLD_HEIGHT = GRID_ROWS * TILE_SIZE

    // --- Simulation -------------------------------------------------------
    const val FIXED_TIMESTEP = 1f / 60f
    const val MAX_STEPS_PER_FRAME = 8 // clamps the "spiral of death" after a big hitch
    val SPEED_MULTIPLIERS = floatArrayOf(1f, 2f, 3f)

    // --- Economy ------------------------------------------------------------
    const val STARTING_MONEY = 400
    const val STARTING_LIVES = 20
    const val SELL_REFUND_FRACTION = 0.7f

    // --- Spatial partitioning ----------------------------------------------
    // Cell size close to the largest tower range keeps a range query to a
    // small, constant number of neighboring cells regardless of how many
    // enemies/towers exist overall.
    const val SPATIAL_CELL_SIZE = 96f

    // --- Enemy behavior -----------------------------------------------------
    const val REGEN_GRACE_PERIOD_SECONDS = 3f
    const val MIN_DAMAGE_FRACTION = 0.1f // armor can never block more than 90% of a hit

    // --- Wave scaling ---------------------------------------------------
    const val WAVE_HEALTH_SCALING_PER_WAVE = 0.15f
    const val WAVE_REWARD_SCALING_PER_WAVE = 0.05f
}
