package com.ironpath.defense.entity.enemy

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * A single active enemy instance. Pooled by [EnemySystem]: fields are
 * overwritten on [EnemySystem.spawn] rather than a new Enemy being
 * constructed per spawn (see [com.ironpath.defense.core.ObjectPool]).
 */
class Enemy {
    lateinit var kind: EnemyKind

    val position = Vector2()
    var distanceTraveled = 0f
    var pathSegmentHint = 0

    var maxHealth = 0f
    var currentHealth = 0f
    var armor = 0f
    var speed = 0f
    var reward = 0
    var radius = 0f
    var spawnedByWaveIndex = 0
    var alive = false

    /**
     * Bumped by [EnemySystem] every time this pooled instance is handed out.
     * A homing [com.ironpath.defense.entity.projectile.Projectile] snapshots
     * this alongside its target reference so it can tell "my target died and
     * this object was recycled into an unrelated new enemy" apart from "my
     * target is still alive" — `alive == true` alone can't distinguish those
     * two cases once pooling is in play.
     */
    var generation = 0

    // --- Status effects ----------------------------------------------------
    var slowMultiplier = 1f // 1 = full speed, e.g. 0.6 = 40% slow
    var slowTimeRemaining = 0f
    var timeSinceLastHit = Float.MAX_VALUE

    // Damage over time (fire/poison). Ignores armor. The color is presentation only.
    var burnDps = 0f
    var burnTimeRemaining = 0f
    var burnColorArgb = 0xFFFF8A2B.toInt()

    // "Marked": takes extra damage from every source while the timer runs.
    var vulnerabilityBonus = 0f
    var vulnerabilityTimeRemaining = 0f

    // Frozen/stunned solid: cannot move while the timer runs.
    var stunTimeRemaining = 0f

    val isBurning: Boolean get() = burnTimeRemaining > 0f
    val isMarked: Boolean get() = vulnerabilityTimeRemaining > 0f
    val isStunned: Boolean get() = stunTimeRemaining > 0f

    fun effectiveSpeed(): Float = if (stunTimeRemaining > 0f) 0f else speed * slowMultiplier

    /** Starts or refreshes damage-over-time; a stronger burn replaces a weaker one, the timer never shortens. */
    fun applyBurn(dps: Float, seconds: Float, colorArgb: Int) {
        if (dps >= burnDps || burnTimeRemaining <= 0f) {
            burnDps = dps
            burnColorArgb = colorArgb
        }
        burnTimeRemaining = maxOf(burnTimeRemaining, seconds)
    }

    /** Starts or refreshes a damage-taken bonus (0.2 = +20%). */
    fun applyVulnerability(bonus: Float, seconds: Float) {
        if (bonus >= vulnerabilityBonus || vulnerabilityTimeRemaining <= 0f) vulnerabilityBonus = bonus
        vulnerabilityTimeRemaining = maxOf(vulnerabilityTimeRemaining, seconds)
    }

    /** Stuns for [seconds]. Bosses shrug most of it off so a freeze can't lock down a boss. */
    fun applyStun(seconds: Float) {
        val effective = if (kind == EnemyKind.BOSS) seconds * BOSS_STUN_FRACTION else seconds
        stunTimeRemaining = maxOf(stunTimeRemaining, effective)
    }

    /** Clears every status effect (used when a pooled instance is reused). */
    fun clearStatuses() {
        slowMultiplier = 1f
        slowTimeRemaining = 0f
        burnDps = 0f
        burnTimeRemaining = 0f
        vulnerabilityBonus = 0f
        vulnerabilityTimeRemaining = 0f
        stunTimeRemaining = 0f
        timeSinceLastHit = Float.MAX_VALUE
    }

    /** Applies a Frost-style slow, respecting the kind's [EnemyKind.slowResistance]. */
    fun applySlow(multiplier: Float, durationSeconds: Float) {
        val resisted = 1f - (1f - multiplier) * (1f - kind.slowResistance)
        if (resisted < slowMultiplier || slowTimeRemaining <= 0f) {
            slowMultiplier = resisted
        }
        slowTimeRemaining = maxOf(slowTimeRemaining, durationSeconds)
    }

    /**
     * Applies damage after armor mitigation and returns the actual amount
     * dealt (for damage-number display). Armor can never block more than
     * [GameConfig.MIN_DAMAGE_FRACTION] of the raw hit, so a heavily-armored
     * enemy is merely tanky, never truly un-damageable by weak towers.
     */
    fun applyDamage(rawDamage: Float, armorPenetration: Float = 0f): Float {
        val effectiveArmor = (armor - armorPenetration).coerceAtLeast(0f)
        val boosted = if (vulnerabilityTimeRemaining > 0f) rawDamage * (1f + vulnerabilityBonus) else rawDamage
        val dealt = (boosted - effectiveArmor).coerceAtLeast(boosted * GameConfig.MIN_DAMAGE_FRACTION)
        currentHealth -= dealt
        timeSinceLastHit = 0f
        return dealt
    }

    private companion object {
        /** Share of a stun's duration a boss actually suffers. */
        const val BOSS_STUN_FRACTION = 0.4f
    }
}
