package com.ironpath.defense.entity.enemy

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.Vector2

/**
 * A single active enemy instance. Pooled by [EnemySystem]: fields are
 * overwritten on [EnemySystem.spawn] rather than a new Enemy being
 * constructed per spawn (see [com.ironpath.defense.core.ObjectPool]).
 */
class Enemy {
    lateinit var kind: EnemyKind

    val position = Vector2()
    var distanceTraveled = 0f
    var pathSegmentHint = 0

    var maxHealth = 0f
    var currentHealth = 0f
    var armor = 0f
    var speed = 0f
    var reward = 0
    var radius = 0f
    var spawnedByWaveIndex = 0
    var alive = false

    /**
     * Bumped by [EnemySystem] every time this pooled instance is handed out.
     * A homing [com.ironpath.defense.entity.projectile.Projectile] snapshots
     * this alongside its target reference so it can tell "my target died and
     * this object was recycled into an unrelated new enemy" apart from "my
     * target is still alive" — `alive == true` alone can't distinguish those
     * two cases once pooling is in play.
     */
    var generation = 0

    // --- Status effects ----------------------------------------------------
    var slowMultiplier = 1f // 1 = full speed, e.g. 0.6 = 40% slow
    var slowTimeRemaining = 0f
    var timeSinceLastHit = Float.MAX_VALUE

    fun effectiveSpeed(): Float = speed * slowMultiplier

    /** Applies a Frost-style slow, respecting the kind's [EnemyKind.slowResistance]. */
    fun applySlow(multiplier: Float, durationSeconds: Float) {
        val resisted = 1f - (1f - multiplier) * (1f - kind.slowResistance)
        if (resisted < slowMultiplier || slowTimeRemaining <= 0f) {
            slowMultiplier = resisted
        }
        slowTimeRemaining = maxOf(slowTimeRemaining, durationSeconds)
    }

    /**
     * Applies damage after armor mitigation and returns the actual amount
     * dealt (for damage-number display). Armor can never block more than
     * [GameConfig.MIN_DAMAGE_FRACTION] of the raw hit, so a heavily-armored
     * enemy is merely tanky, never truly un-damageable by weak towers.
     */
    fun applyDamage(rawDamage: Float, armorPenetration: Float = 0f): Float {
        val effectiveArmor = (armor - armorPenetration).coerceAtLeast(0f)
        val dealt = (rawDamage - effectiveArmor).coerceAtLeast(rawDamage * GameConfig.MIN_DAMAGE_FRACTION)
        currentHealth -= dealt
        timeSinceLastHit = 0f
        return dealt
    }
}
