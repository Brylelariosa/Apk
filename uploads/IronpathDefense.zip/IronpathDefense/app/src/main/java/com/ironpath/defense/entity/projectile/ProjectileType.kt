package com.ironpath.defense.entity.projectile

/**
 * Visual + flight-behavior constants for a projectile. Gameplay numbers
 * (damage, splash radius, etc.) live on the *firing tower's*
 * [com.ironpath.defense.entity.tower.TowerTierStats] — a projectile just
 * carries a copy of whatever the tower computed at fire time plus how it
 * should move and render, so ProjectileType only needs to describe motion
 * and appearance, not combat math.
 *
 * @param speed world units per second (0 = homing projectile arrives
 *   instantly-relative-to-travel-time is not used here; every projectile
 *   type currently travels at a finite speed and is removed on arrival/miss).
 * @param isHoming true = steers toward the target enemy's current position
 *   every tick (Lightning, Frost); false = launched at the target's position
 *   at fire time and flies straight/arced from there (Archer, Cannon,
 *   Ranger), which lets a fast enemy actually dodge a slow Cannon shot.
 */
enum class ProjectileType(
    val displayName: String,
    val speed: Float,
    val isHoming: Boolean,
    val colorArgb: Int,
    val radius: Float
) {
    ARROW(displayName = "Arrow", speed = 520f, isHoming = false, colorArgb = 0xFFE8E4D8.toInt(), radius = 4f),
    CANNONBALL(displayName = "Cannonball", speed = 260f, isHoming = false, colorArgb = 0xFF3B3B3E.toInt(), radius = 7f),
    FROST_SHARD(displayName = "Frost Shard", speed = 380f, isHoming = true, colorArgb = 0xFFBFF3EF.toInt(), radius = 5f),
    RANGER_DART(displayName = "Ranger Dart", speed = 620f, isHoming = false, colorArgb = 0xFFD8E8B0.toInt(), radius = 4f),
    LIGHTNING_BOLT(displayName = "Lightning Bolt", speed = 900f, isHoming = true, colorArgb = 0xFFE9D9FF.toInt(), radius = 3f)
}
