package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.entity.enemy.EnemyKind.ARMORED
import com.ironpath.defense.entity.enemy.EnemyKind.BASIC
import com.ironpath.defense.entity.enemy.EnemyKind.BOSS
import com.ironpath.defense.entity.enemy.EnemyKind.FAST
import com.ironpath.defense.entity.enemy.EnemyKind.REGENERATOR
import com.ironpath.defense.entity.enemy.EnemyKind.SWARM

/**
 * The 20-wave launch campaign, expressed as data rather than branching
 * spawn logic — each entry below is a self-contained, independently
 * tunable [WaveDefinition]. A designer extending this later adds another
 * `wave(...)` call; nothing else in the wave/economy/UI systems needs to
 * change, since they only ever ask "what does wave N look like."
 *
 * Boss waves land on 5, 10, 15 and 20; [WaveSystem] treats clearing the
 * final entry in this list as the win condition.
 */
object WaveLibrary {

    val ALL: List<WaveDefinition> = listOf(
        wave(1, reward = 60,
            group(BASIC, count = 8, interval = 0.80f)
        ),
        wave(2, reward = 70,
            group(BASIC, count = 10, interval = 0.70f),
            group(FAST, count = 4, interval = 0.60f, delay = 4f)
        ),
        wave(3, reward = 90,
            group(BASIC, count = 8, interval = 0.60f),
            group(ARMORED, count = 3, interval = 1.20f, delay = 3f)
        ),
        wave(4, reward = 100,
            group(FAST, count = 10, interval = 0.35f),
            group(BASIC, count = 6, interval = 0.60f, delay = 2f)
        ),
        wave(5, reward = 250, isBoss = true,
            group(BASIC, count = 6, interval = 0.60f),
            group(BOSS, count = 1, interval = 1f, delay = 6f)
        ),
        wave(6, reward = 130,
            group(ARMORED, count = 6, interval = 1.00f),
            group(SWARM, count = 12, interval = 0.25f, delay = 3f)
        ),
        wave(7, reward = 150,
            group(FAST, count = 14, interval = 0.30f),
            group(ARMORED, count = 4, interval = 1.00f, delay = 3f)
        ),
        wave(8, reward = 170,
            group(SWARM, count = 16, interval = 0.20f),
            group(REGENERATOR, count = 3, interval = 1.50f, delay = 4f)
        ),
        wave(9, reward = 200,
            group(ARMORED, count = 8, interval = 0.80f),
            group(FAST, count = 10, interval = 0.30f, delay = 3f),
            group(SWARM, count = 10, interval = 0.20f, delay = 6f)
        ),
        wave(10, reward = 320, isBoss = true,
            group(REGENERATOR, count = 4, interval = 1.20f),
            group(ARMORED, count = 6, interval = 0.90f, delay = 2f),
            group(BOSS, count = 1, interval = 1f, delay = 8f)
        ),
        wave(11, reward = 220,
            group(FAST, count = 18, interval = 0.25f),
            group(REGENERATOR, count = 5, interval = 1.00f, delay = 4f)
        ),
        wave(12, reward = 240,
            group(ARMORED, count = 10, interval = 0.70f),
            group(SWARM, count = 14, interval = 0.20f, delay = 3f)
        ),
        wave(13, reward = 260,
            group(REGENERATOR, count = 6, interval = 0.90f),
            group(FAST, count = 16, interval = 0.25f, delay = 3f),
            group(ARMORED, count = 6, interval = 0.80f, delay = 6f)
        ),
        wave(14, reward = 280,
            group(SWARM, count = 20, interval = 0.15f),
            group(ARMORED, count = 8, interval = 0.70f, delay = 5f)
        ),
        wave(15, reward = 450, isBoss = true,
            group(FAST, count = 16, interval = 0.20f, delay = 8f),
            group(BOSS, count = 2, interval = 3.00f)
        ),
        wave(16, reward = 300,
            group(REGENERATOR, count = 8, interval = 0.80f),
            group(SWARM, count = 18, interval = 0.15f, delay = 4f)
        ),
        wave(17, reward = 330,
            group(ARMORED, count = 14, interval = 0.60f),
            group(FAST, count = 20, interval = 0.20f, delay = 4f)
        ),
        wave(18, reward = 360,
            group(SWARM, count = 24, interval = 0.12f),
            group(REGENERATOR, count = 8, interval = 0.70f, delay = 5f)
        ),
        wave(19, reward = 400,
            group(ARMORED, count = 16, interval = 0.55f),
            group(REGENERATOR, count = 8, interval = 0.70f, delay = 5f),
            group(FAST, count = 20, interval = 0.18f, delay = 10f)
        ),
        wave(20, reward = 600, isBoss = true,
            group(ARMORED, count = 14, interval = 0.50f, delay = 10f),
            group(SWARM, count = 20, interval = 0.12f, delay = 14f),
            group(BOSS, count = 3, interval = 2.50f)
        )
    )

    private fun group(kind: EnemyKind, count: Int, interval: Float, delay: Float = 0f) =
        SpawnGroup(kind, count, interval, delay)

    // `groups` comes before `isBoss` on purpose: with `isBoss` in between `reward` and
    // the vararg, calling wave(n, reward = r, group(...), group(...)) makes Kotlin bind
    // that first group(...) to the skipped `isBoss` slot instead of the vararg (a type
    // mismatch, since it resolves trailing positional args to the next unfilled
    // parameter in declaration order — not the vararg specifically). With the vararg
    // immediately after `reward`, every call below still works unchanged; a boss wave
    // just names isBoss explicitly, e.g. wave(5, reward = 250, isBoss = true, group(...)).
    private fun wave(index: Int, reward: Int, vararg groups: SpawnGroup, isBoss: Boolean = false) =
        WaveDefinition(index, groups.toList(), reward, isBoss)
}
