package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemyKind
import com.ironpath.defense.entity.enemy.EnemyKind.ARMORED
import com.ironpath.defense.entity.enemy.EnemyKind.BASIC
import com.ironpath.defense.entity.enemy.EnemyKind.BOSS
import com.ironpath.defense.entity.enemy.EnemyKind.FAST
import com.ironpath.defense.entity.enemy.EnemyKind.REGENERATOR
import com.ironpath.defense.entity.enemy.EnemyKind.SWARM

/**
 * The 20-wave launch campaign, expressed as data rather than branching
 * spawn logic — each entry below is a self-contained, independently
 * tunable [WaveDefinition]. A designer extending this later adds another
 * `wave(...)` call; nothing else in the wave/economy/UI systems needs to
 * change, since they only ever ask "what does wave N look like."
 *
 * Boss waves land on 5, 10, 15 and 20; [WaveSystem] treats clearing the
 * final entry in this list as the win condition.
 */
object WaveLibrary {

    val ALL: List<WaveDefinition> = listOf(
        wave(1,
            group(BASIC, count = 8, interval = 0.80f),
            reward = 60
        ),
        wave(2,
            group(BASIC, count = 10, interval = 0.70f),
            group(FAST, count = 4, interval = 0.60f, delay = 4f),
            reward = 70
        ),
        wave(3,
            group(BASIC, count = 8, interval = 0.60f),
            group(ARMORED, count = 3, interval = 1.20f, delay = 3f),
            reward = 90
        ),
        wave(4,
            group(FAST, count = 10, interval = 0.35f),
            group(BASIC, count = 6, interval = 0.60f, delay = 2f),
            reward = 100
        ),
        wave(5,
            group(BASIC, count = 6, interval = 0.60f),
            group(BOSS, count = 1, interval = 1f, delay = 6f),
            reward = 250, isBoss = true
        ),
        wave(6,
            group(ARMORED, count = 6, interval = 1.00f),
            group(SWARM, count = 12, interval = 0.25f, delay = 3f),
            reward = 130
        ),
        wave(7,
            group(FAST, count = 14, interval = 0.30f),
            group(ARMORED, count = 4, interval = 1.00f, delay = 3f),
            reward = 150
        ),
        wave(8,
            group(SWARM, count = 16, interval = 0.20f),
            group(REGENERATOR, count = 3, interval = 1.50f, delay = 4f),
            reward = 170
        ),
        wave(9,
            group(ARMORED, count = 8, interval = 0.80f),
            group(FAST, count = 10, interval = 0.30f, delay = 3f),
            group(SWARM, count = 10, interval = 0.20f, delay = 6f),
            reward = 200
        ),
        wave(10,
            group(REGENERATOR, count = 4, interval = 1.20f),
            group(ARMORED, count = 6, interval = 0.90f, delay = 2f),
            group(BOSS, count = 1, interval = 1f, delay = 8f),
            reward = 320, isBoss = true
        ),
        wave(11,
            group(FAST, count = 18, interval = 0.25f),
            group(REGENERATOR, count = 5, interval = 1.00f, delay = 4f),
            reward = 220
        ),
        wave(12,
            group(ARMORED, count = 10, interval = 0.70f),
            group(SWARM, count = 14, interval = 0.20f, delay = 3f),
            reward = 240
        ),
        wave(13,
            group(REGENERATOR, count = 6, interval = 0.90f),
            group(FAST, count = 16, interval = 0.25f, delay = 3f),
            group(ARMORED, count = 6, interval = 0.80f, delay = 6f),
            reward = 260
        ),
        wave(14,
            group(SWARM, count = 20, interval = 0.15f),
            group(ARMORED, count = 8, interval = 0.70f, delay = 5f),
            reward = 280
        ),
        wave(15,
            group(FAST, count = 16, interval = 0.20f, delay = 8f),
            group(BOSS, count = 2, interval = 3.00f),
            reward = 450, isBoss = true
        ),
        wave(16,
            group(REGENERATOR, count = 8, interval = 0.80f),
            group(SWARM, count = 18, interval = 0.15f, delay = 4f),
            reward = 300
        ),
        wave(17,
            group(ARMORED, count = 14, interval = 0.60f),
            group(FAST, count = 20, interval = 0.20f, delay = 4f),
            reward = 330
        ),
        wave(18,
            group(SWARM, count = 24, interval = 0.12f),
            group(REGENERATOR, count = 8, interval = 0.70f, delay = 5f),
            reward = 360
        ),
        wave(19,
            group(ARMORED, count = 16, interval = 0.55f),
            group(REGENERATOR, count = 8, interval = 0.70f, delay = 5f),
            group(FAST, count = 20, interval = 0.18f, delay = 10f),
            reward = 400
        ),
        wave(20,
            group(ARMORED, count = 14, interval = 0.50f, delay = 10f),
            group(SWARM, count = 20, interval = 0.12f, delay = 14f),
            group(BOSS, count = 3, interval = 2.50f),
            reward = 600, isBoss = true
        )
    )

    private fun group(kind: EnemyKind, count: Int, interval: Float, delay: Float = 0f) =
        SpawnGroup(kind, count, interval, delay)

    // reward/isBoss are declared *after* the vararg on purpose, which forces every
    // call to pass them by name — and forces every group(...) above to be plain
    // positional with no named argument before it. That's required, not stylistic:
    // Kotlin resolves a trailing positional argument after a named one by its raw
    // position in the full parameter list, not by "the next open vararg slot". With
    // reward/isBoss sitting before the vararg (as in two earlier versions of this
    // file), that intermittently bound a group(...) into reward/isBoss's slot
    // instead: a type mismatch when the slot was empty, a hard "mixing named and
    // positioned arguments" error when a boss wave had already filled it by name.
    // Named strictly after positional, with nothing in between, removes the
    // ambiguity outright — there's no ordering left here to get wrong.
    private fun wave(index: Int, vararg groups: SpawnGroup, reward: Int, isBoss: Boolean = false) =
        WaveDefinition(index, groups.toList(), reward, isBoss)
}
