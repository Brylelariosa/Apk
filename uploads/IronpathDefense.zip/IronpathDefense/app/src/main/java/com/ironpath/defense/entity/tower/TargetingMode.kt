package com.ironpath.defense.entity.tower

/** Per-tower player-selectable targeting priority, cycled via the tower info panel. */
enum class TargetingMode(val displayName: String) {
    FIRST("First"),       // enemy furthest along the path (closest to the exit)
    STRONGEST("Strongest"), // enemy with the highest current health
    CLOSEST("Closest")     // enemy with the smallest straight-line distance to this tower
}
