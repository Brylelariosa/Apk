package com.ironpath.defense.wave

import com.ironpath.defense.entity.enemy.EnemySystem

/**
 * Runtime spawn scheduler for the wave currently in progress. [WaveLibrary]
 * supplies *what* a wave contains; this class only handles *when* — ticking
 * each active [SpawnGroup]'s delay/interval timers and calling
 * [EnemySystem.spawn] as they come due — and detects when a wave is
 * finished (every group exhausted and every enemy it spawned is gone).
 *
 * A new wave can't start until the current one is fully cleared, so at most
 * one wave's enemies are ever alive at once — this keeps "did wave N finish"
 * a simple, unambiguous question.
 */
class WaveSystem(private val enemySystem: EnemySystem) {

    var currentWaveIndex = 0 // number of waves cleared so far; 0 before the game starts
        private set
    var waveInProgress = false
        private set

    private var activeWave: WaveDefinition? = null
    private val groupStates = ArrayList<GroupSpawnState>()

    val totalWaveCount: Int get() = WaveLibrary.ALL.size
    val activeWaveDefinition: WaveDefinition? get() = activeWave
    val hasWonGame: Boolean get() = currentWaveIndex >= totalWaveCount && !waveInProgress

    private class GroupSpawnState(val group: SpawnGroup) {
        var timeUntilNextSpawn = group.startDelaySeconds
        var spawnedCount = 0
        val isDone: Boolean get() = spawnedCount >= group.count
    }

    fun canStartNextWave(): Boolean = !waveInProgress && currentWaveIndex < totalWaveCount

    fun startNextWave() {
        if (!canStartNextWave()) return
        val definition = WaveLibrary.ALL[currentWaveIndex] // currentWaveIndex is 0-based-next here
        activeWave = definition
        groupStates.clear()
        for (g in definition.groups) groupStates.add(GroupSpawnState(g))
        waveInProgress = true
    }

    /** Advances spawn timers for the in-progress wave. Returns the completion reward the instant it finishes, else null. */
    fun update(dt: Float): Int? {
        val wave = activeWave ?: return null

        for (state in groupStates) {
            if (state.isDone) continue
            state.timeUntilNextSpawn -= dt
            while (!state.isDone && state.timeUntilNextSpawn <= 0f) {
                enemySystem.spawn(state.group.kind, wave.index)
                state.spawnedCount++
                state.timeUntilNextSpawn += state.group.intervalSeconds
            }
        }

        val allGroupsDone = groupStates.all { it.isDone }
        val noEnemiesLeftFromThisWave = enemySystem.active.none { it.spawnedByWaveIndex == wave.index }
        if (allGroupsDone && noEnemiesLeftFromThisWave) {
            currentWaveIndex = wave.index
            waveInProgress = false
            activeWave = null
            groupStates.clear()
            return wave.completionReward
        }
        return null
    }

    fun reset() {
        currentWaveIndex = 0
        waveInProgress = false
        activeWave = null
        groupStates.clear()
    }
}
