package com.ironpath.defense.entity.enemy

import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.core.ObjectPool
import com.ironpath.defense.map.PathSystem

/**
 * Owns every active enemy: spawning (with per-wave stat scaling), per-tick
 * movement along the path, regen/slow status ticking, and pooled recycling.
 *
 * Uses swap-remove instead of `MutableList.removeAt(i)` when an enemy dies or
 * leaks: order of the active list has no gameplay meaning, so an O(1)
 * swap-with-last is strictly better than an O(n) shift, and this list is
 * walked every one of the 60 fixed-timestep updates per second.
 */
class EnemySystem(private val pathSystem: PathSystem) {

    private val pool = ObjectPool(initialCapacity = 64, factory = { Enemy() }, reset = { it.alive = false })
    private val activeList = ArrayList<Enemy>(128)
    val active: List<Enemy> get() = activeList

    fun spawn(kind: EnemyKind, waveIndex: Int): Enemy {
        val healthMultiplier = 1f + GameConfig.WAVE_HEALTH_SCALING_PER_WAVE * (waveIndex - 1)
        val rewardMultiplier = 1f + GameConfig.WAVE_REWARD_SCALING_PER_WAVE * (waveIndex - 1)

        val e = pool.obtain()
        e.kind = kind
        e.maxHealth = kind.baseHealth * healthMultiplier
        e.currentHealth = e.maxHealth
        e.armor = kind.armor
        e.speed = kind.baseSpeed
        e.radius = kind.radius
        e.reward = (kind.baseReward * rewardMultiplier).toInt()
        e.distanceTraveled = 0f
        e.pathSegmentHint = 0
        e.slowMultiplier = 1f
        e.slowTimeRemaining = 0f
        e.timeSinceLastHit = Float.MAX_VALUE
        e.spawnedByWaveIndex = waveIndex
        e.alive = true
        e.generation++
        pathSystem.positionAt(0f, 0, e.position)

        activeList.add(e)
        return e
    }

    /**
     * Advances every active enemy by [dt]. [onKilled] fires for enemies whose
     * health reached zero (reward money); [onLeaked] fires for enemies that
     * reached the end of the path (cost a life). Each enemy triggers at most
     * one of the two, never both.
     */
    fun update(dt: Float, onLeaked: (Enemy) -> Unit, onKilled: (Enemy) -> Unit) {
        var i = 0
        while (i < activeList.size) {
            val e = activeList[i]

            if (e.slowTimeRemaining > 0f) {
                e.slowTimeRemaining -= dt
                if (e.slowTimeRemaining <= 0f) e.slowMultiplier = 1f
            }

            if (e.kind.regenPerSecond > 0f) {
                e.timeSinceLastHit += dt
                if (e.timeSinceLastHit >= GameConfig.REGEN_GRACE_PERIOD_SECONDS) {
                    e.currentHealth = (e.currentHealth + e.maxHealth * e.kind.regenPerSecond * dt)
                        .coerceAtMost(e.maxHealth)
                }
            }

            if (e.currentHealth <= 0f) {
                removeActiveAt(i)
                onKilled(e)
                e.alive = false
                pool.free(e)
                continue // index i now holds the swapped-in element — recheck it
            }

            e.distanceTraveled += e.effectiveSpeed() * dt
            e.pathSegmentHint = pathSystem.positionAt(e.distanceTraveled, e.pathSegmentHint, e.position)

            if (pathSystem.hasReachedEnd(e.distanceTraveled)) {
                removeActiveAt(i)
                onLeaked(e)
                e.alive = false
                pool.free(e)
                continue
            }

            i++
        }
    }

    /** Returns every active enemy to the pool without triggering kill/leak callbacks (used on full reset). */
    fun clear() {
        for (e in activeList) {
            e.alive = false
            pool.free(e)
        }
        activeList.clear()
    }

    private fun removeActiveAt(index: Int) {
        val lastIndex = activeList.size - 1
        activeList[index] = activeList[lastIndex]
        activeList.removeAt(lastIndex)
    }
}
