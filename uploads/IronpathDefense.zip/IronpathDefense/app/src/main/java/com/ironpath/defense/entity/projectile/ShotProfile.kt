package com.ironpath.defense.entity.projectile

/**
 * Everything a shot does when it lands, as one mutable bundle owned by a
 * pooled [Projectile] (or by TowerSystem for a tower's pulse attack).
 *
 * Deliberately a plain value holder with no reference to the tower package:
 * TowerType already depends on ProjectileType, so if the projectile package
 * also depended on tower stats the two would depend on each other. The tower
 * side copies its stats *into* one of these at fire time instead (see
 * `TowerStats.writeShot`), and combat code only ever reads it.
 *
 * Mutable and reused (never re-allocated per shot) for the same reason the
 * projectiles themselves are pooled.
 */
class ShotProfile {
    var damage = 0f
    var isCrit = false
    var colorArgb = 0xFFFFFFFF.toInt()

    var armorPenetration = 0f
    var splashRadius = 0f

    var slowMultiplier = 1f
    var slowDurationSeconds = 0f

    var chainCount = 0
    var chainRadius = 0f
    var chainDamageFalloff = 1f

    var burnDps = 0f
    var burnSeconds = 0f
    var burnColorArgb = 0xFFFF8A2B.toInt()

    var freezeChance = 0f
    var freezeSeconds = 0f

    var vulnerabilityBonus = 0f
    var vulnerabilitySeconds = 0f

    var bossDamageMultiplier = 1f
    var executeThreshold = 0f

    /** Restores every field to its neutral default (no special effects). */
    fun reset() {
        damage = 0f
        isCrit = false
        colorArgb = 0xFFFFFFFF.toInt()
        armorPenetration = 0f
        splashRadius = 0f
        slowMultiplier = 1f
        slowDurationSeconds = 0f
        chainCount = 0
        chainRadius = 0f
        chainDamageFalloff = 1f
        burnDps = 0f
        burnSeconds = 0f
        burnColorArgb = 0xFFFF8A2B.toInt()
        freezeChance = 0f
        freezeSeconds = 0f
        vulnerabilityBonus = 0f
        vulnerabilitySeconds = 0f
        bossDamageMultiplier = 1f
        executeThreshold = 0f
    }
}
