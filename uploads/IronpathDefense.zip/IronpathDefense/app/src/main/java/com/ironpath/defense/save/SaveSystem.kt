package com.ironpath.defense.save

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists progression + settings as plain SharedPreferences key/value pairs
 * — no JSON/serialization layer, so there's no schema to keep in sync and no
 * reflection for R8 to worry about (see app/proguard-rules.pro).
 *
 * [save] uses `apply()` (non-blocking — never stalls the game thread) for
 * routine saves like a wave clearing; Android's own QueuedWork mechanism
 * already flushes any pending `apply()` write before a normal process death.
 * [saveNow] uses `commit()` (synchronous) and is called only from
 * GameActivity.onPause — the one moment blocking briefly to *guarantee* the
 * write actually lands before the process might be killed is worth it.
 */
class SaveSystem(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): SaveData = SaveData(
        highestWaveCompleted = prefs.getInt(KEY_HIGHEST_WAVE, 0),
        musicOn = prefs.getBoolean(KEY_MUSIC_ON, true),
        sfxOn = prefs.getBoolean(KEY_SFX_ON, true),
        showDamageNumbers = prefs.getBoolean(KEY_DAMAGE_NUMBERS, true)
    )

    fun save(data: SaveData) = write(data, sync = false)

    fun saveNow(data: SaveData) = write(data, sync = true)

    private fun write(data: SaveData, sync: Boolean) {
        val editor = prefs.edit()
            .putInt(KEY_HIGHEST_WAVE, data.highestWaveCompleted)
            .putBoolean(KEY_MUSIC_ON, data.musicOn)
            .putBoolean(KEY_SFX_ON, data.sfxOn)
            .putBoolean(KEY_DAMAGE_NUMBERS, data.showDamageNumbers)
        if (sync) editor.commit() else editor.apply()
    }

    companion object {
        private const val PREFS_NAME = "ironpath_save"
        private const val KEY_HIGHEST_WAVE = "highest_wave_completed"
        private const val KEY_MUSIC_ON = "music_on"
        private const val KEY_SFX_ON = "sfx_on"
        private const val KEY_DAMAGE_NUMBERS = "show_damage_numbers"
    }
}
