package com.ironpath.defense.economy

import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType

/**
 * Validates and charges for every tower money-action (purchase / upgrade /
 * sell). Deliberately does NOT construct or place Tower instances — that
 * requires MapSystem (is this tile buildable?) and TowerSystem (register the
 * new tower), which only GameWorld has both of. Keeping this system to pure
 * economic validation+transaction means it doesn't need to know the map or
 * placement rules exist at all.
 */
class UpgradeSystem(private val economySystem: EconomySystem) {

    fun canPurchase(type: TowerType, highestWaveCompleted: Int): Boolean =
        type.isUnlockedAt(highestWaveCompleted) && economySystem.canAfford(type.baseCost)

    /** Charges [type]'s base cost if unlocked and affordable. The caller is responsible for actually placing the tower. */
    fun tryPurchase(type: TowerType, highestWaveCompleted: Int): Boolean {
        if (!type.isUnlockedAt(highestWaveCompleted)) return false
        return economySystem.spend(type.baseCost)
    }

    fun canUpgrade(tower: Tower): Boolean =
        tower.canUpgrade && economySystem.canAfford(tower.type.statsFor(tower.tier + 1).upgradeCost)

    fun tryUpgrade(tower: Tower): Boolean {
        if (!tower.canUpgrade) return false
        val cost = tower.type.statsFor(tower.tier + 1).upgradeCost
        if (!economySystem.spend(cost)) return false
        tower.applyUpgrade()
        return true
    }

    /** Refunds the tower's sell value. The caller removes it from TowerSystem/MapSystem. */
    fun sell(tower: Tower) {
        economySystem.earn(tower.sellValue)
    }
}
