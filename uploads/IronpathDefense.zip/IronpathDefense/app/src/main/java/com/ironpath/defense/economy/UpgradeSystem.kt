package com.ironpath.defense.economy

import com.ironpath.defense.entity.tower.Tower
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeAvailability

/**
 * Validates and charges for every tower money-action (purchase / upgrade /
 * sell). Deliberately does NOT construct or place Tower instances — that
 * requires MapSystem (is this tile buildable?) and TowerSystem (register the
 * new tower), which only GameWorld has both of. Keeping this system to pure
 * economic validation+transaction means it doesn't need to know the map or
 * placement rules exist at all.
 *
 * Which upgrades are *allowed* (the crosspath rules) is decided by the tower
 * itself via [Tower.upgradeAvailability]; this class only adds "and can the
 * player afford it".
 */
class UpgradeSystem(private val economySystem: EconomySystem) {

    fun canPurchase(type: TowerType, highestWaveCompleted: Int): Boolean =
        type.isUnlockedAt(highestWaveCompleted) && economySystem.canAfford(type.baseCost)

    /** Charges [type]'s base cost if unlocked and affordable. The caller is responsible for actually placing the tower. */
    fun tryPurchase(type: TowerType, highestWaveCompleted: Int): Boolean {
        if (!type.isUnlockedAt(highestWaveCompleted)) return false
        return economySystem.spend(type.baseCost)
    }

    fun canUpgrade(tower: Tower, path: Int): Boolean {
        val next = tower.nextUpgrade(path) ?: return false
        return tower.upgradeAvailability(path) == UpgradeAvailability.AVAILABLE && economySystem.canAfford(next.cost)
    }

    /** Buys the next upgrade on [path] if the build rules allow it and the player can pay. */
    fun tryUpgrade(tower: Tower, path: Int): Boolean {
        if (path !in tower.pathTiers.indices) return false
        if (tower.upgradeAvailability(path) != UpgradeAvailability.AVAILABLE) return false
        val cost = tower.nextUpgrade(path)?.cost ?: return false
        if (!economySystem.spend(cost)) return false
        tower.applyUpgrade(path)
        return true
    }

    /** Refunds the tower's sell value. The caller removes it from TowerSystem/MapSystem. */
    fun sell(tower: Tower) {
        economySystem.earn(tower.sellValue)
    }
}
