package com.ironpath.defense.ui

import android.graphics.RectF
import com.ironpath.defense.core.GameConfig

/**
 * Single source of truth for HUD screen-space geometry and the world<->screen
 * viewport transform. Both [com.ironpath.defense.render.GameRenderer] (draws
 * these rects/uses this transform) and the input handling in GameView (hit-tests
 * taps against the same rects/transform) read from one instance, so layout
 * math is never duplicated — a common source of "the button looks like it's
 * at X but taps register at Y" bugs in Canvas-based UIs.
 *
 * [recompute] is called whenever the surface size changes, including once on
 * first layout.
 */
class UiLayout {
    var screenWidth = 0f
        private set
    var screenHeight = 0f
        private set

    val topBar = RectF()
    val battlefield = RectF()
    val bottomBar = RectF()

    val pauseButton = RectF()
    val speedButton = RectF()
    val startWaveButton = RectF()

    /** Shop-mode buttons, one per tower slot; index into this with `TowerType.ordinal`. */
    val towerShopSlots = Array(5) { RectF() }

    /** Tower-info-mode geometry, shown instead of the shop row while a placed tower is selected. */
    val infoTextArea = RectF()
    val targetingButton = RectF()
    val upgradeButton = RectF()
    val sellButton = RectF()
    val closeButton = RectF()

    // --- Full-screen overlay buttons ---------------------------------------
    // These screens (main menu / pause / settings / game-over / victory) are
    // mutually exclusive, so each gets its own clearly-named rects even
    // though they're all just vertically-stacked centered buttons under the
    // hood — see centeredButtonRect().
    val mainMenuPlayButton = RectF()
    val pauseResumeButton = RectF()
    val pauseSettingsButton = RectF()
    val pauseMainMenuButton = RectF()
    val settingsMusicRow = RectF()
    val settingsSfxRow = RectF()
    val settingsDamageNumbersRow = RectF()
    val settingsCloseButton = RectF()
    val endScreenRetryButton = RectF()

    // --- World <-> screen viewport (letterboxed "contain" scaling) --------
    var worldScale = 1f
        private set
    private var worldOffsetX = 0f
    private var worldOffsetY = 0f

    fun worldToScreenX(worldX: Float) = battlefield.left + worldOffsetX + worldX * worldScale
    fun worldToScreenY(worldY: Float) = battlefield.top + worldOffsetY + worldY * worldScale
    fun worldToScreenLength(worldLength: Float) = worldLength * worldScale

    fun screenToWorldX(screenX: Float) = (screenX - battlefield.left - worldOffsetX) / worldScale
    fun screenToWorldY(screenY: Float) = (screenY - battlefield.top - worldOffsetY) / worldScale

    fun recompute(width: Float, height: Float) {
        screenWidth = width
        screenHeight = height

        val topBarHeight = height * 0.10f
        val bottomBarHeight = height * 0.22f

        topBar.set(0f, 0f, width, topBarHeight)
        battlefield.set(0f, topBarHeight, width, height - bottomBarHeight)
        bottomBar.set(0f, height - bottomBarHeight, width, height)

        layoutTopBarButtons(topBarHeight)
        layoutShopSlots()
        layoutTowerInfoPanel(bottomBarHeight)
        layoutOverlayButtons()
        layoutViewportTransform()
    }

    private fun layoutTopBarButtons(topBarHeight: Float) {
        val buttonSize = topBarHeight * 0.8f
        val margin = (topBarHeight - buttonSize) / 2f

        pauseButton.set(
            screenWidth - margin - buttonSize, margin,
            screenWidth - margin, margin + buttonSize
        )
        speedButton.set(
            pauseButton.left - margin - buttonSize, margin,
            pauseButton.left - margin, margin + buttonSize
        )
        val startWaveWidth = buttonSize * 2.4f
        startWaveButton.set(
            speedButton.left - margin - startWaveWidth, margin,
            speedButton.left - margin, margin + buttonSize
        )
    }

    private fun layoutShopSlots() {
        val slotWidth = screenWidth / towerShopSlots.size
        for (i in towerShopSlots.indices) {
            towerShopSlots[i].set(i * slotWidth, bottomBar.top, (i + 1) * slotWidth, bottomBar.bottom)
        }
    }

    private fun layoutTowerInfoPanel(bottomBarHeight: Float) {
        val textHeight = bottomBarHeight * 0.34f
        infoTextArea.set(0f, bottomBar.top, screenWidth, bottomBar.top + textHeight)

        val buttonTop = infoTextArea.bottom
        val buttonWidth = screenWidth / 4f
        targetingButton.set(0f, buttonTop, buttonWidth, bottomBar.bottom)
        upgradeButton.set(buttonWidth, buttonTop, buttonWidth * 2f, bottomBar.bottom)
        sellButton.set(buttonWidth * 2f, buttonTop, buttonWidth * 3f, bottomBar.bottom)
        closeButton.set(buttonWidth * 3f, buttonTop, buttonWidth * 4f, bottomBar.bottom)
    }

    private fun layoutOverlayButtons() {
        mainMenuPlayButton.set(centeredButtonRect(slot = 0, totalSlots = 1))

        pauseResumeButton.set(centeredButtonRect(slot = 0, totalSlots = 3))
        pauseSettingsButton.set(centeredButtonRect(slot = 1, totalSlots = 3))
        pauseMainMenuButton.set(centeredButtonRect(slot = 2, totalSlots = 3))

        settingsMusicRow.set(centeredButtonRect(slot = 0, totalSlots = 4))
        settingsSfxRow.set(centeredButtonRect(slot = 1, totalSlots = 4))
        settingsDamageNumbersRow.set(centeredButtonRect(slot = 2, totalSlots = 4))
        settingsCloseButton.set(centeredButtonRect(slot = 3, totalSlots = 4))

        endScreenRetryButton.set(centeredButtonRect(slot = 0, totalSlots = 1))
    }

    private fun centeredButtonRect(slot: Int, totalSlots: Int): RectF {
        val buttonWidth = screenWidth * 0.4f
        val buttonHeight = screenHeight * 0.12f
        val gap = screenHeight * 0.03f
        val totalHeight = totalSlots * buttonHeight + (totalSlots - 1) * gap
        val startTop = (screenHeight - totalHeight) / 2f
        val top = startTop + slot * (buttonHeight + gap)
        val left = (screenWidth - buttonWidth) / 2f
        return RectF(left, top, left + buttonWidth, top + buttonHeight)
    }

    private fun layoutViewportTransform() {
        val scaleX = battlefield.width() / GameConfig.WORLD_WIDTH
        val scaleY = battlefield.height() / GameConfig.WORLD_HEIGHT
        worldScale = minOf(scaleX, scaleY)
        val scaledWidth = GameConfig.WORLD_WIDTH * worldScale
        val scaledHeight = GameConfig.WORLD_HEIGHT * worldScale
        worldOffsetX = (battlefield.width() - scaledWidth) / 2f
        worldOffsetY = (battlefield.height() - scaledHeight) / 2f
    }
}
