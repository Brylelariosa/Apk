package com.ironpath.defense.ui

import android.graphics.RectF
import com.ironpath.defense.core.GameConfig
import com.ironpath.defense.entity.tower.TowerType
import com.ironpath.defense.entity.tower.upgrade.UpgradeRules

/**
 * Single source of truth for HUD screen-space geometry and the world<->screen
 * viewport transform. Both [com.ironpath.defense.render.GameRenderer] (draws
 * these rects/uses this transform) and [InputController] (hit-tests taps
 * against the same rects/transform) read from one instance, so layout math
 * is never duplicated — a common source of "the button looks like it's at X
 * but taps register at Y" bugs in Canvas-based UIs.
 *
 * The screen is fullscreen: the battlefield is the whole display, the map is
 * scaled to fill as much of it as its aspect ratio allows, scenery covers the
 * rest, and the HUD floats on top in translucent chips and panels instead of
 * carving bars out of the play area. Everything interactive respects the
 * [SafeInsets] so a camera cutout never hides a button.
 *
 * [recompute] is called whenever the surface size or the safe insets change,
 * including once on first layout.
 */
class UiLayout {
    var screenWidth = 0f
        private set
    var screenHeight = 0f
        private set

    private var insets = SafeInsets.NONE

    /** The whole screen. The world is drawn edge to edge; HUD elements float above it. */
    val battlefield = RectF()

    // --- Top HUD: status chips on the left, buttons on the right -------------
    val moneyChip = RectF()
    val livesChip = RectF()
    val waveChip = RectF()
    val pauseButton = RectF()
    val speedButton = RectF()
    val startWaveButton = RectF()

    // --- Shop dock (shown while no tower is selected) -----------------------
    val shopDock = RectF()
    /** One per tower type; index into this with `TowerType.ordinal`. */
    val towerShopSlots = Array(TowerType.entries.size) { RectF() }

    // --- Tower panel (shown while a placed tower is selected) ---------------
    val towerPanel = RectF()
    val panelHeader = RectF()
    val panelStats = RectF()
    /** One card per upgrade path, top to bottom. */
    val pathCards = Array(UpgradeRules.PATH_COUNT) { RectF() }
    val targetingButton = RectF()
    val sellButton = RectF()
    val closeButton = RectF()

    /** The panel sits on whichever side of the screen the selected tower is *not*, so it never covers it. */
    private var towerPanelOnRight = true

    // --- Full-screen overlay buttons ---------------------------------------
    // These screens (main menu / pause / settings / game-over / victory) are
    // mutually exclusive, so each gets its own clearly-named rects even
    // though they're all just vertically-stacked centered buttons under the
    // hood — see centeredButtonRect().
    val mainMenuPlayButton = RectF()
    val pauseResumeButton = RectF()
    val pauseSettingsButton = RectF()
    val pauseMainMenuButton = RectF()
    val settingsMusicRow = RectF()
    val settingsSfxRow = RectF()
    val settingsDamageNumbersRow = RectF()
    val settingsCloseButton = RectF()
    val endScreenRetryButton = RectF()

    // --- World <-> screen viewport ------------------------------------------
    var worldScale = 1f
        private set
    var worldOffsetX = 0f
        private set
    var worldOffsetY = 0f
        private set

    fun worldToScreenX(worldX: Float) = battlefield.left + worldOffsetX + worldX * worldScale
    fun worldToScreenY(worldY: Float) = battlefield.top + worldOffsetY + worldY * worldScale
    fun worldToScreenLength(worldLength: Float) = worldLength * worldScale

    fun screenToWorldX(screenX: Float) = (screenX - battlefield.left - worldOffsetX) / worldScale
    fun screenToWorldY(screenY: Float) = (screenY - battlefield.top - worldOffsetY) / worldScale

    @Synchronized
    fun recompute(width: Float, height: Float, safeInsets: SafeInsets) {
        screenWidth = width
        screenHeight = height
        insets = safeInsets

        battlefield.set(0f, 0f, width, height)

        layoutTopHud()
        layoutShopDock()
        layoutTowerPanel()
        layoutOverlayButtons()
        layoutViewportTransform()
    }

    /** Moves the tower panel to the screen side opposite [towerScreenX]. */
    @Synchronized
    fun dockTowerPanelAwayFrom(towerScreenX: Float) {
        towerPanelOnRight = towerScreenX < screenWidth / 2f
        if (screenWidth > 0f) layoutTowerPanel()
    }

    private val margin: Float get() = screenHeight * 0.022f
    private val chipHeight: Float get() = screenHeight * 0.078f

    private fun layoutTopHud() {
        val m = margin
        val gap = m * 0.6f
        val h = chipHeight
        val top = insets.top + m
        val left = insets.left + m
        val right = screenWidth - insets.right - m

        pauseButton.set(right - h, top, right, top + h)
        speedButton.set(pauseButton.left - gap - h, top, pauseButton.left - gap, top + h)
        val startWaveWidth = h * 2.9f
        startWaveButton.set(speedButton.left - gap - startWaveWidth, top, speedButton.left - gap, top + h)

        val chipsAvailable = startWaveButton.left - gap - left
        val moneyWidth = minOf(screenHeight * 0.30f, chipsAvailable * 0.30f)
        val livesWidth = minOf(screenHeight * 0.36f, chipsAvailable * 0.34f)
        val waveWidth = minOf(screenHeight * 0.44f, chipsAvailable * 0.36f)
        moneyChip.set(left, top, left + moneyWidth, top + h)
        livesChip.set(moneyChip.right + gap, top, moneyChip.right + gap + livesWidth, top + h)
        waveChip.set(livesChip.right + gap, top, livesChip.right + gap + waveWidth, top + h)
    }

    private fun layoutShopDock() {
        val m = margin
        val gap = m * 0.5f
        val slotCount = towerShopSlots.size
        val safeWidth = screenWidth - insets.left - insets.right
        val slotWidth = minOf(screenHeight * 0.21f, (safeWidth - 2f * m - gap * (slotCount + 1)) / slotCount)
        val slotHeight = screenHeight * 0.15f
        val dockWidth = slotCount * slotWidth + gap * (slotCount + 1)
        val dockHeight = slotHeight + gap * 2f

        val dockLeft = insets.left + (safeWidth - dockWidth) / 2f
        val dockBottom = screenHeight - insets.bottom - m * 0.6f
        shopDock.set(dockLeft, dockBottom - dockHeight, dockLeft + dockWidth, dockBottom)

        for (i in towerShopSlots.indices) {
            val slotLeft = shopDock.left + gap + i * (slotWidth + gap)
            towerShopSlots[i].set(slotLeft, shopDock.top + gap, slotLeft + slotWidth, shopDock.top + gap + slotHeight)
        }
    }

    private fun layoutTowerPanel() {
        val m = margin
        val safeWidth = screenWidth - insets.left - insets.right
        val panelWidth = minOf(screenHeight * 0.66f, safeWidth * 0.42f)
        val panelTop = insets.top + m + chipHeight + m * 0.8f
        val panelBottom = screenHeight - insets.bottom - m
        val panelLeft = if (towerPanelOnRight) screenWidth - insets.right - m - panelWidth else insets.left + m
        towerPanel.set(panelLeft, panelTop, panelLeft + panelWidth, panelBottom)

        val pad = panelWidth * 0.035f
        val innerLeft = towerPanel.left + pad
        val innerRight = towerPanel.right - pad
        val innerWidth = innerRight - innerLeft
        val panelHeight = towerPanel.height()
        val gapY = panelHeight * 0.012f

        var y = towerPanel.top + pad
        val headerHeight = panelHeight * 0.115f
        panelHeader.set(innerLeft, y, innerRight, y + headerHeight)
        y += headerHeight

        val statsHeight = panelHeight * 0.075f
        panelStats.set(innerLeft, y, innerRight, y + statsHeight)
        y += statsHeight + gapY

        val actionsHeight = panelHeight * 0.095f
        val actionsTop = towerPanel.bottom - pad - actionsHeight
        val cardsBottom = actionsTop - gapY
        val cardCount = pathCards.size
        val cardHeight = (cardsBottom - y - gapY * (cardCount - 1)) / cardCount
        for (i in pathCards.indices) {
            pathCards[i].set(innerLeft, y, innerRight, y + cardHeight)
            y += cardHeight + gapY
        }

        val buttonGap = pad * 0.6f
        val buttonWidth = (innerWidth - buttonGap * 2f) / 3f
        targetingButton.set(innerLeft, actionsTop, innerLeft + buttonWidth, actionsTop + actionsHeight)
        sellButton.set(
            targetingButton.right + buttonGap, actionsTop,
            targetingButton.right + buttonGap + buttonWidth, actionsTop + actionsHeight
        )
        closeButton.set(
            sellButton.right + buttonGap, actionsTop,
            sellButton.right + buttonGap + buttonWidth, actionsTop + actionsHeight
        )
    }

    private fun layoutOverlayButtons() {
        mainMenuPlayButton.set(centeredButtonRect(slot = 0, totalSlots = 1))

        pauseResumeButton.set(centeredButtonRect(slot = 0, totalSlots = 3))
        pauseSettingsButton.set(centeredButtonRect(slot = 1, totalSlots = 3))
        pauseMainMenuButton.set(centeredButtonRect(slot = 2, totalSlots = 3))

        settingsMusicRow.set(centeredButtonRect(slot = 0, totalSlots = 4))
        settingsSfxRow.set(centeredButtonRect(slot = 1, totalSlots = 4))
        settingsDamageNumbersRow.set(centeredButtonRect(slot = 2, totalSlots = 4))
        settingsCloseButton.set(centeredButtonRect(slot = 3, totalSlots = 4))

        endScreenRetryButton.set(centeredButtonRect(slot = 0, totalSlots = 1))
    }

    private fun centeredButtonRect(slot: Int, totalSlots: Int): RectF {
        val buttonWidth = minOf(screenWidth * 0.4f, screenHeight * 0.95f)
        val buttonHeight = screenHeight * 0.12f
        val gap = screenHeight * 0.03f
        val totalHeight = totalSlots * buttonHeight + (totalSlots - 1) * gap
        val startTop = (screenHeight - totalHeight) / 2f
        val top = startTop + slot * (buttonHeight + gap)
        val left = (screenWidth - buttonWidth) / 2f
        return RectF(left, top, left + buttonWidth, top + buttonHeight)
    }

    /**
     * Scales the map to fill the screen as far as its aspect ratio allows,
     * keeping it inside the safe insets so no part of the playable grid
     * sits under a camera cutout. Scenery fills whatever is left over.
     */
    private fun layoutViewportTransform() {
        val safeWidth = screenWidth - insets.left - insets.right
        val scaleX = safeWidth / GameConfig.WORLD_WIDTH
        val scaleY = screenHeight / GameConfig.WORLD_HEIGHT
        worldScale = minOf(scaleX, scaleY)
        val scaledWidth = GameConfig.WORLD_WIDTH * worldScale
        val scaledHeight = GameConfig.WORLD_HEIGHT * worldScale
        worldOffsetX = insets.left + (safeWidth - scaledWidth) / 2f
        worldOffsetY = (screenHeight - scaledHeight) / 2f
    }
}
