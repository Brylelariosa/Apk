package com.ironpath.defense.entity.particle

import com.ironpath.defense.core.Vector2

/** A short rising label in world space (an upgrade's name popping off a tower). Pooled by ParticleSystem. */
class FloatingText {
    val position = Vector2()
    var text = ""
    var colorArgb = 0xFFFFFFFF.toInt()
    var lifeRemaining = 0f
    var lifeTotal = 1f
    var alive = false

    fun lifeFraction(): Float = if (lifeTotal <= 0f) 0f else (lifeRemaining / lifeTotal).coerceIn(0f, 1f)
}
