No audio files ship in this project (see the main README's "What's not
included" section for why). AudioSystem.kt loads every sound through a
try/catch, so their absence is silent and harmless, not a crash.

Drop compressed OGG/Opus files with these exact names in this folder and
they'll be picked up automatically — nothing else needs to change:

  shoot.ogg           tower_upgrade.ogg
  hit.ogg             tower_sell.ogg
  explosion.ogg       wave_start.ogg
  tower_place.ogg     life_lost.ogg
  button_tap.ogg      victory.ogg
  game_over.ogg

  music_loop.ogg      (looping background track; optional, separate from
                        the SFX list above — see AudioSystem.playMusicLoop)

Keep each SFX short and compressed (the spec's own guidance: avoid large
uncompressed WAV files) — SoundPool is meant for short one-shot sounds, not
long tracks.
