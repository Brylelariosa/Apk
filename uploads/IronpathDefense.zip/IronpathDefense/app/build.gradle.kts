plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ironpath.defense"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ironpath.defense"
        // Android 11 (API 30) matches the "low/mid-range, 4GB RAM" target hardware.
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    // --- APK size / single-universal-APK policy -----------------------------
    // Deliberately absent from this file:
    //   - splits { abi { ... } }
    //   - ndk { abiFilters ... } / any per-ABI packaging
    // The game has no native (C++/NDK) code at all (see README), so there are
    // no .so libraries to split by ABI in the first place — the single output
    // APK is universal by construction, not by an ABI-splits workaround.
    // -------------------------------------------------------------------------

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // No signingConfig block is declared here on purpose: the CI workflow
            // signs release builds by passing -Pandroid.injected.signing.store.file
            // (and .store.password / .key.alias / .key.password) on the Gradle
            // command line. AGP recognizes those injected properties natively and
            // applies them to whichever variant is being assembled, so no keystore
            // material ever needs to live in this build script. When those
            // properties are absent, `assembleRelease` still succeeds but produces
            // an unsigned APK — which is why the workflow falls back to
            // `assembleDebug` (auto-signed with the debug key) when no keystore
            // secret is configured.
        }
        debug {
            // Defaults (debuggable = true, minify = false) are fine as-is.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // Defensive default: harmless today (zero third-party deps), but prevents
    // "duplicate file" build failures the moment a library dependency is ever
    // added later.
    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module"
            )
        }
    }

    lint {
        // Static analysis only; never fail the CI build over lint warnings.
        abortOnError = false
    }
}

dependencies {
    // Intentionally empty. Every system in this game (rendering, audio, save
    // data, input) is built on the plain Android SDK + Kotlin stdlib, which is
    // sufficient once minSdk = 30 (WindowInsetsController, SoundPool, Canvas,
    // SharedPreferences are all native platform APIs at that level). No
    // AndroidX, no AppCompat/Material, no JSON/serialization library. This is
    // itself the single biggest APK-size decision in the project — see the
    // audit in README.md.
}
