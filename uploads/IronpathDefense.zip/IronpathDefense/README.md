# Ironpath Defense

An original Android tower-defense game (Kotlin, no third-party dependencies):
build one polished map, place five original tower types beside an enemy
path, and hold for 20 escalating waves against six enemy archetypes and four
bosses. No assets, names, code, or UI are copied from any existing game.

## Building it

This project is built by the provided GitHub Actions workflow, not locally:
unzip → find `settings.gradle.kts` → Gradle 8.6 / JDK 17 → `assembleRelease`
(if a keystore secret is configured) or `assembleDebug` otherwise → APK
uploaded as a build artifact. Nothing in this project needs Android Studio;
a standard `./gradlew` invocation is all the workflow ever runs.

Two things worth knowing if you ever build it another way:

- **`gradle-wrapper.jar` isn't included.** The workflow's own "Fetch
  gradle-wrapper.jar" step downloads it fresh for Gradle 8.6 before running
  `gradlew`, so committing a binary jar here would just be redundant. To run
  it locally instead, generate one once with `gradle wrapper --gradle-version 8.6`
  from any local Gradle install.
- **No SDK platform/build-tools are pre-installed by the workflow** beyond
  `platform-tools` — AGP downloads compileSdk 34 + matching build-tools
  itself on first use, which is default, standard AGP behavior and needs no
  workflow changes.

## Architecture

```
GameActivity  → the only Android-specific glue: immersive fullscreen +
GameView        SurfaceView/GameLoop lifecycle + forwarding touch events.
                Neither class knows what a "Tower" is.

GameWorld     → composition root. Owns every system below, implements
(engine/)       GameActions (the interface the UI calls into), and runs the
                per-tick update/render sequence.

core/         → Vector2, GameConfig (every tuning constant in one file),
                GameLoop (fixed-timestep thread), ObjectPool<T>,
                GameScreenState, InputEvent/InputQueue.
map/          → GameMap + MapRegistry (waypoints/map data), TileGrid
                (buildable/path/occupied), PathSystem (distance-along-path
                queries), MapSystem (world<->tile facade).
entity/enemy  → EnemyKind (data-driven stats), Enemy (pooled instance),
                EnemySystem (spawn/move/regen/slow/leak/kill).
entity/tower  → TowerType + TowerTierStats (data-driven, 3 tiers each),
                Tower (placed instance), TowerSystem (cooldown/targeting/fire),
                TargetingMode.
entity/       → ProjectileType, Projectile (pooled; ballistic or homing),
 projectile     ProjectileSystem (flight + single/splash/chain impact).
entity/       → Particle, DamageNumber, ParticleSystem (both pooled).
 particle
combat/       → CollisionSystem: a uniform spatial grid so tower targeting
                and splash/chain queries are never an O(towers×enemies) scan.
wave/         → SpawnGroup/WaveDefinition (data), WaveLibrary (the 20
                authored waves), WaveSystem (runtime spawn timers).
economy/      → EconomySystem (money), UpgradeSystem (buy/upgrade/sell
                validation+transactions — never constructs/places a Tower).
save/         → SaveData, SaveSystem (plain SharedPreferences, no
                serialization library).
audio/        → SoundEffect, AudioSystem (SoundPool SFX + optional music
                loop, both tolerant of missing asset files).
settings/     → SettingsSystem (music/SFX/damage-number toggles).
ui/           → UiLayout (single source of truth for HUD rects *and* the
                world<->screen viewport transform), HudState (per-frame
                snapshot), HudRenderer, GameActions (interface), 
                InputController (tap → action), Palette (chrome colors).
render/       → WorldRenderer (map/towers/enemies/projectiles/particles),
                GameRenderer (top-level per-frame entry point).
```

**Why Canvas + SurfaceView, not OpenGL ES:** this is a 2D game with, at
worst, a few hundred simultaneous entities — well within what a
hardware-accelerated Canvas handles at 60fps — and a hand-rolled OpenGL
pipeline would add real implementation risk (shaders, buffer management,
context loss handling) for no performance the target hardware actually
needs. `GameLoop` runs a fixed-timestep accumulator on its own thread
(see its class doc for why not "just multiply the delta"), decoupling
simulation speed (1x/2x/3x) from render rate entirely.

**Why zero third-party/AndroidX dependencies:** minSdk 30 already provides
`WindowInsetsController`, modern `SharedPreferences`, `SoundPool`, and
everything else this project touches as plain platform APIs. `GameActivity`
extends `Activity` (not `AppCompatActivity`) and there is no XML layout
anywhere — `GameView` is constructed entirely in code — so there was never a
reason to pull in AppCompat/Material. Save data is hand-written
SharedPreferences key/value pairs rather than JSON, so there's no
serialization library either. This is the single biggest APK-size lever in
the project (see the audit below).

**Why no native (C++/NDK) code**, despite the build environment providing
NDK/CMake: it wouldn't provide a real performance benefit here. The
performance-critical work (object pooling, spatial-grid targeting, squared-
distance checks) is about *algorithmic* complexity, not something a JNI
boundary would speed up — and per the spec's own instruction, NDK should
only be used when it provides genuine benefit. The workflow's NDK/CMake
install and `.cxx` cache steps are harmless no-ops here.

## Gameplay reference

**Towers** (unlock wave in parens): Archer (1) cheap fast single-target,
Cannon (1) splash vs. groups, Frost (3) slows enemies, Ranger (6) long
range + armor penetration, Lightning (10) chains to nearby enemies. Each has
3 tiers with meaningfully different damage/range/fire-rate/special-effect
numbers — all in `TowerType.kt`, nowhere else.

**Enemies:** Basic, Fast, Armored (flat damage reduction, never below 10%
of a hit), Swarm (spawned in large cheap groups), Regenerator (heals when
not hit for 3s), Boss (huge health pool, half-effective slows). Stats scale
per wave in `EnemySystem.spawn()`.

**Waves:** 20 hand-authored waves in `WaveLibrary.kt`, boss waves on 5/10/15/20.
Adding a 21st wave is adding one `wave(...)` entry there.

**Save data:** highest wave completed (also gates tower unlocks) + the three
settings toggles, written via `apply()` on wave-clear and `commit()` in
`GameActivity.onPause`.

## What's *not* included (by design, not oversight)

- **No audio files.** `AudioSystem` is fully wired (SFX by ID via SoundPool,
  an optional looping `MediaPlayer` track) and expects `.ogg` files under
  `app/src/main/assets/audio/` — see `assets/audio/README.txt` for the exact
  filenames it looks for. Every load is try/catch-guarded, so the game runs
  completely normally, just silently, until those files are added.
- **No bitmap art.** Every tower, enemy, and projectile is drawn
  procedurally with Canvas primitives (see `WorldRenderer.kt`), and the
  launcher icon is a vector drawable. Zero image assets to optimize because
  there are zero image assets.
- **One map.** `MapRegistry` is the extension point for more — add a
  `GameMap` there; `MapSystem`/`PathSystem`/rendering/input already work in
  terms of "the current map," not "Ironpath Valley" specifically.

## Extending it

- **New tower:** add a `TowerType` enum constant with its `TowerTierStats`
  list. `TowerSystem`/`ProjectileSystem`/the shop UI all iterate
  `TowerType.entries` already.
- **New enemy:** add an `EnemyKind` enum constant.
- **New wave:** add a `wave(...)` entry to `WaveLibrary.ALL`.
- **New map:** add a `GameMap` (a name + a list of tile waypoints) to
  `MapRegistry.all`.

---

## APK size & performance audit

**1. Expected major size contributors.** In descending order: (a) the
Kotlin stdlib portion R8 can't strip (every Kotlin app pays this baseline —
typically the largest single piece of a small app's DEX once minified), (b)
the app's own ~50 small Kotlin files compiled to DEX, (c) `resources.arsc` +
the manifest/XML (strings, one theme, one vector icon) — all measured in KB,
not MB. There is no fourth tier: no bitmap assets, no audio assets, no
native libraries, no AndroidX/Material resources.

**2. Unnecessarily large assets.** None found — there are no bitmap or audio
assets in the project at all (see "What's not included" above). The one
launcher icon is a vector drawable (a few hundred bytes of XML).

**3. Duplicate native libraries.** None possible — the project contains no
native (C++/NDK) code and links no `.so` libraries, so there is nothing to
deduplicate. `packaging.resources.excludes` in `app/build.gradle.kts` also
pre-empts the classic `META-INF/LICENSE` duplicate-file failure mode for
whenever a dependency is eventually added.

**4. Unnecessary dependencies.** The `dependencies {}` block in
`app/build.gradle.kts` is empty. No AndroidX, no AppCompat/Material, no
JSON/serialization library, no test framework — each was evaluated and
deliberately left out (see "Why zero third-party dependencies" above).

**5. ABI splits avoided?** Yes — and more specifically, there was never
anything to split: no native code means no per-ABI `.so` variants exist in
the first place, so the single output APK is universal by construction, not
via an ABI-splits workaround that then has to be disabled.

**6. R8 / resource shrinking enabled?** Yes, both, for the `release` build
type only (`isMinifyEnabled = true`, `isShrinkResources = true` in
`app/build.gradle.kts`), with `proguard-rules.pro` deliberately carrying no
extra `-keep` rules beyond AGP's own defaults — there's no reflection,
serialization, or XML-inflated custom View in the codebase that would need
one (see that file's own comments for specifics).

**7. Remaining safe size opportunities.** Genuinely marginal at this point:
(a) `resConfigs("en")` in `defaultConfig` would guard against a future
dependency pulling in other-locale string resources — not added now since,
with zero dependencies, there are currently no other-locale resources to
strip; (b) if bitmap art is added later, prefer WebP and the smallest
texture that reads clearly at gameplay zoom, per the spec's own asset
guidance.

**8. Low-end-device performance bottlenecks.** None identified in the
design; the specific mitigations already in place: object pooling for
enemies/projectiles/particles/damage numbers (`ObjectPool<T>`, zero
per-spawn allocation once warmed up); a uniform spatial grid
(`CollisionSystem`) so targeting/splash/chain queries touch a handful of
nearby entities, never the full enemy list; squared-distance comparisons
everywhere a range check happens (no per-candidate `sqrt`); swap-remove
(O(1)) instead of shift-remove (O(n)) when an enemy/projectile/particle is
freed from its active list; the static terrain layer rendered once to a
cached `RGB_565` bitmap instead of ~220 rects redrawn every frame; and a
fixed-timestep loop with a step cap so a hitch can't cascade into a larger
one. The one theoretical soft spot is very large simultaneous splash/chain
resolution (dozens of Cannon/Lightning shots landing the same tick) — the
spatial grid keeps each individual query cheap, but this is the one place
worth profiling first if a future content addition (e.g. a sixth tower)
ever pushes hit-resolution volume much higher than the current 20-wave
campaign does.
