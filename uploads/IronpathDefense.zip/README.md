# Ironpath Defense

A native Android (Kotlin, Canvas/SurfaceView) tower-defense game. Everything is drawn
procedurally and every sound is synthesized in code: no art or audio assets required.
Landscape, fullscreen/immersive, GPU canvas with software fallback. minSdk 30.

## What's in 2.0

* **8 maps** with different layouts and rules: Ironpath Valley (forest, high ground),
  Scorched Dunes (sandstorms cut range), Frostfall Pass (black ice speeds enemies),
  Cinder Caldera (lava surges), Sunken Ruins (tap rune pedestals), Neon Quarter (grid surges
  overclock towers), Gearworks (presses + conveyor surges), Xenon Reach (healing spore clouds).
  Each unlocks by reaching wave 10 on the previous one. Easy / Normal / Hard (Hard needs a win).
* **6 towers** (Archer, Cannon, Frost, Flame, Ranger, Lightning), each with **three bespoke
  upgrade paths x 5 tiers**. Crosspath rules are unchanged: one path to tier 5, a second to
  tier 2, the third locked (5-2-0, 5-0-2, 2-5-0, 0-5-2, 2-0-5, 0-2-5). Tiers add *behaviors*
  (piercing, armor shred, spreading fire, death blasts, ground zones, special volleys, heat
  ramp, support auras, EMP silence...) - see `entity/tower/upgrade/UpgradeCatalog.kt`.
* **Fusions**: each ordered path pair (main tier 3+ with a tier-2 crosspath) unlocks a
  tower-specific perk, so 5-2-0 and 2-5-0 are different builds (36 fusions in total).
* **Visual crosspathing**: `render/TowerArt.kt` builds each tower from its real tiers. Path A
  is the weapon slot, B the flanks/support gear, C the top/power slot; new parts animate in.
* **Tower synergy**: towers within ~2.3 tiles link: Fire+Ice = Steam Burst, Ice+Electric =
  Superconduct, Fire/Ice + physical towers = Incendiary / Frostbite rounds. The Ranger's
  Tactical path adds a Command Aura (Support + Damage). See `entity/tower/SynergySystem.kt`.
* **Adaptive Director** (`director/DirectorSystem.kt`): watches damage by tower type, how deep
  enemies die, leaks, lives, banked money and tower layout, then shapes the *next* wave within
  hard limits (-15%/+20% counts, one counter group / elite squad / event per wave, bosses never
  rescaled). It can add counter-enemies, elite squads, a supply drop when you struggle, or a
  bounty zone when you stack one area. It never touches towers or stats, and the plan is shown
  in the next-wave preview.
* **Waves**: Standard, Rush, Swarm, Siege, Armored, Specialist, Combined Arms, Mini-boss, Boss;
  18 enemy kinds (shielded, splitting, healing, cloaking...) and 4 bosses with phases, summons,
  EMP jamming and blinks. Countdown, banners, boss bar, next-wave preview.
* **UI**: full menu flow (Play / Maps / Towers codex with visual build previews / Trophies /
  Settings), pause, victory/defeat summaries, 3 player abilities, 1x/2x/3x speed, tower panel
  that shows all three paths with MAIN / CROSS / LOCKED and exact stat changes.
* **Settings** (saved): master/effects/music volume, graphics quality (auto-detected default),
  damage numbers, screen shake, auto-start waves. Progress, best waves/scores, trophies saved.

## Code map

    core/      config, loop (GPU canvas), difficulty/quality, pools, input queue
    map/       GameMap, MapRegistry (8 maps), TileGrid (+high ground), PathSystem, MapSystem
    mapfx/     MapMechanics (one rule per map)
    entity/    enemy (kinds, abilities, bosses), tower (stats, synergy, upgrade/*), projectile,
               zone (lingering fire/frost/lava/spore areas), particle
    combat/    CollisionSystem (spatial hash), HitResolver, CombatFeedback
    wave/      WaveLibrary (authored 20 waves), WavePlanner (generator), WaveSystem
    director/  DirectorSystem
    ability/   player abilities
    engine/    GameRun (one playthrough), GameWorld (screens + persistence), CombatEffects, Juice
    render/    WorldRenderer, TerrainPainter (cached terrain), AmbientRenderer (weather/props),
               TowerArt, EnemyArt, FxRenderer, ArtKit
    ui/        UiKit (immediate-mode widgets; buttons register their own hit regions),
               PlayHud, TowerPanel, MenuScreens, GameActions/InputController
    audio/     SoundSynth (procedural), AudioSystem (SoundPool; optional asset overrides)
    save/      SaveData/SaveSystem (v1 keys preserved), Achievements
    settings/  SettingsSystem

## Adding content

* New tower: add a `TowerType`, three `UpgradePath`s + six `CrossPerk`s in `UpgradeCatalog`,
  a draw function in `TowerArt`, a sound in `CombatEffects.onTowerFire`.
* New map: add a `GameMap` to `MapRegistry` (waypoints may start/end off-grid), a theme in
  `MapTheme` if needed, and a `MapMechanic` branch in `MapMechanics`.
* New enemy: `EnemyKind` entry, a branch in `EnemyArt.body`, optional logic in `EnemyAbilities`.

## Build

Standard Gradle project (AGP 8.4, Kotlin 1.9, JDK 17): `./gradlew assembleDebug`.
