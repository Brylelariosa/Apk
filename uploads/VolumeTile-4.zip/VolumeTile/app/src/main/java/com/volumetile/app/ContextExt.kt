package com.volumetile.app

import android.content.Context
import android.media.AudioManager
import android.widget.Toast

/** Short toast from any Context - services included. */
fun Context.toast(resId: Int) {
    Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}

/**
 * Pops up the system volume panel - the one the hardware buttons bring up - by nudging
 * the media stream with ADJUST_SAME, which changes nothing. No activity is launched, so
 * whatever is in the foreground (a game, say) keeps running.
 */
fun Context.showSystemVolumePanel() {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audioManager.adjustStreamVolume(
        AudioManager.STREAM_MUSIC,
        AudioManager.ADJUST_SAME,
        AudioManager.FLAG_SHOW_UI
    )
}

/**
 * Moves the media volume one step up or down, the way the hardware keys do, and lets the
 * system volume panel show the new level. No activity is launched.
 */
fun Context.stepMediaVolume(up: Boolean) {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audioManager.adjustStreamVolume(
        AudioManager.STREAM_MUSIC,
        if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
        AudioManager.FLAG_SHOW_UI
    )
}

/** Mutes the media volume, or restores it when it is already muted; the volume panel shows the result. */
fun Context.toggleMediaMute() {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audioManager.adjustStreamVolume(
        AudioManager.STREAM_MUSIC,
        AudioManager.ADJUST_TOGGLE_MUTE,
        AudioManager.FLAG_SHOW_UI
    )
}

/** Density-independent pixels to whole screen pixels. */
fun Context.dpToPx(dp: Float): Int = (dp * resources.displayMetrics.density + 0.5f).toInt()
