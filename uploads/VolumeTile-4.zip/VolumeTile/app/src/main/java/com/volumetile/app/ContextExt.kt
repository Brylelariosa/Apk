package com.volumetile.app

import android.content.Context
import android.media.AudioManager
import android.widget.Toast

/** Short toast from any Context - services included. */
fun Context.toast(resId: Int) {
    Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}

/**
 * Pops up the system volume panel - the one the hardware buttons bring up - by nudging
 * the media stream with ADJUST_SAME, which changes nothing. No activity is launched, so
 * whatever is in the foreground (a game, say) keeps running.
 */
fun Context.showSystemVolumePanel() {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audioManager.adjustStreamVolume(
        AudioManager.STREAM_MUSIC,
        AudioManager.ADJUST_SAME,
        AudioManager.FLAG_SHOW_UI
    )
}
