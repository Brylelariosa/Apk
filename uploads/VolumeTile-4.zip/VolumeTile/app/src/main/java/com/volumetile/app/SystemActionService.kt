package com.volumetile.app

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Presses system buttons on behalf of the Quick Settings tiles and of the accessibility
 * button in the navigation bar.
 *
 * Apps can't take screenshots or open the power menu directly; without root the
 * only route is an AccessibilityService, whose performGlobalAction() hands the
 * request to the system. This one subscribes to no events and can't read window
 * content (see res/xml/system_action_service.xml) - it only runs what it is asked.
 *
 * Requests reach it two ways:
 *  - A tile calls [dispatch]. Tiles live in the same process, so they reach the
 *    running instance through the companion instead of binding to it.
 *  - The person taps the accessibility button. That opens an [ActionChooserOverlay]
 *    and whatever they pick is run with [ActionOrigin.CHOOSER].
 */
class SystemActionService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    // Created on first use, dropped again in release().
    private var chooser: ActionChooserOverlay? = null
    private var buttonController: AccessibilityButtonController? = null

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            toggleChooser()
        }
    }

    private val screenshotTask = Runnable {
        if (!performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)) {
            toast(R.string.toast_action_failed)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // The system only shows the button for this service, and only delivers its taps,
        // because res/xml/system_action_service.xml sets flagRequestAccessibilityButton.
        buttonController = accessibilityButtonController.also {
            it.registerAccessibilityButtonCallback(buttonCallback)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        release()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }

    private fun release() {
        handler.removeCallbacksAndMessages(null)
        buttonController?.unregisterAccessibilityButtonCallback(buttonCallback)
        buttonController = null
        chooser?.dismiss()
        chooser = null
        if (instance === this) instance = null
    }

    private fun toggleChooser() {
        val overlay = chooser ?: ActionChooserOverlay(this) { action ->
            perform(action, ActionOrigin.CHOOSER)
        }.also { chooser = it }
        overlay.toggle(SystemAction.supported())
    }

    private fun perform(action: SystemAction, origin: ActionOrigin) {
        when (action) {
            SystemAction.VOLUME_PANEL -> showSystemVolumePanel()
            SystemAction.SCREENSHOT -> takeScreenshot(origin)
            SystemAction.SHADE_SCREENSHOT -> takeShadeScreenshot(origin)
            SystemAction.POWER_MENU -> {
                if (!performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)) {
                    toast(R.string.toast_action_failed)
                }
            }
        }
    }

    private fun takeScreenshot(origin: ActionOrigin) {
        when (origin) {
            // The shade is open (the tile lives in it): close it and let it finish animating.
            ActionOrigin.QUICK_SETTINGS_TILE -> {
                collapseShade()
                scheduleScreenshot(SHADE_COLLAPSE_SETTLE_MS)
            }
            // Nothing to close; just let the chooser panel disappear.
            ActionOrigin.CHOOSER -> scheduleScreenshot(TAP_SETTLE_MS)
        }
    }

    private fun takeShadeScreenshot(origin: ActionOrigin) {
        when (origin) {
            // Shade stays open on purpose, so it is part of the capture.
            ActionOrigin.QUICK_SETTINGS_TILE -> scheduleScreenshot(TAP_SETTLE_MS)
            // The shade is closed here, so pull it down first and give it time to open.
            ActionOrigin.CHOOSER -> {
                if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) {
                    scheduleScreenshot(SHADE_EXPAND_SETTLE_MS)
                } else {
                    toast(R.string.toast_action_failed)
                }
            }
        }
    }

    private fun scheduleScreenshot(delayMs: Long) {
        // Cancel any pending capture first so a double tap still yields one screenshot.
        handler.removeCallbacks(screenshotTask)
        handler.postDelayed(screenshotTask, delayMs)
    }

    /**
     * Closes the notification shade without launching an activity, so a game in
     * the foreground isn't paused. API 31 added a proper global action for this;
     * before that, the close-system-dialogs broadcast does the same job.
     */
    @Suppress("DEPRECATION")
    private fun collapseShade() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
        }
    }

    companion object {
        /** Time for the shade's collapse animation to finish before we capture. */
        private const val SHADE_COLLAPSE_SETTLE_MS = 500L

        /** Time for the shade's open animation to finish before we capture. */
        private const val SHADE_EXPAND_SETTLE_MS = 800L

        /**
         * Lets whatever was just tapped - a tile's press feedback, or the chooser panel -
         * disappear so it isn't in the capture.
         */
        private const val TAP_SETTLE_MS = 250L

        // Cleared in release(), so it never outlives the service.
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: SystemActionService? = null

        /** True when the user has switched the service on in Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            val resolver = context.contentResolver
            if (Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) {
                return false
            }
            val enabled = Settings.Secure.getString(
                resolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val self = ComponentName(context, SystemActionService::class.java)
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == self }
        }

        /**
         * Runs [action] if the service is connected. Returns false when it isn't -
         * e.g. just after a process restart, before the system has rebound it.
         * Tiles use the default [origin]; the chooser passes its own.
         */
        fun dispatch(
            action: SystemAction,
            origin: ActionOrigin = ActionOrigin.QUICK_SETTINGS_TILE
        ): Boolean {
            val service = instance ?: return false
            service.perform(action, origin)
            return true
        }
    }
}
