package com.network.hotspot;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    static final String PREFS_NAME = "hotspot_prefs";
    static final String KEY_ENABLED = "hotspot_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SwitchCompat mainSwitch = findViewById(R.id.switch_hotspot);
        TextView tvStatus = findViewById(R.id.tv_status);

        boolean enabled = prefs.getBoolean(KEY_ENABLED, false);
        mainSwitch.setChecked(enabled);
        updateStatus(tvStatus, enabled);

        mainSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.edit().putBoolean(KEY_ENABLED, isChecked).apply();
            updateStatus(tvStatus, isChecked);
        });
    }

    private void updateStatus(TextView tv, boolean enabled) {
        tv.setText(enabled ? R.string.status_on : R.string.status_off);
    }
}
