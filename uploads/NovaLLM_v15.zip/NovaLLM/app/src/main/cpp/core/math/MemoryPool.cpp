#include "MemoryPool.h"
#include <new>
#include <cstdlib>

namespace novallm {
namespace {
constexpr size_t kAlignment = 16;
}

MemoryPool::MemoryPool(size_t capacityBytes) : capacity_(capacityBytes) {
    // Over-allocate and hand-align manually rather than using aligned_alloc(),
    // which isn't available on Android below API 28 (bionic libc). minSdk
    // for this project is 24, so we can't rely on it.
    rawBuffer_ = static_cast<unsigned char*>(std::malloc(capacityBytes + kAlignment));
    if (!rawBuffer_) {
        throw std::bad_alloc();
    }
    uintptr_t addr = reinterpret_cast<uintptr_t>(rawBuffer_);
    uintptr_t alignedAddr = (addr + kAlignment - 1) & ~(kAlignment - 1);
    buffer_ = reinterpret_cast<unsigned char*>(alignedAddr);
}

MemoryPool::~MemoryPool() {
    std::free(rawBuffer_);
}

MemoryPool::MemoryPool(MemoryPool&& other) noexcept
    : capacity_(other.capacity_), offset_(other.offset_),
      rawBuffer_(other.rawBuffer_), buffer_(other.buffer_) {
    other.rawBuffer_ = nullptr;
    other.buffer_ = nullptr;
    other.capacity_ = 0;
    other.offset_ = 0;
}

MemoryPool& MemoryPool::operator=(MemoryPool&& other) noexcept {
    if (this != &other) {
        std::free(rawBuffer_); // free(nullptr) is a defined no-op if we have none yet
        capacity_ = other.capacity_;
        offset_ = other.offset_;
        rawBuffer_ = other.rawBuffer_;
        buffer_ = other.buffer_;
        other.rawBuffer_ = nullptr;
        other.buffer_ = nullptr;
        other.capacity_ = 0;
        other.offset_ = 0;
    }
    return *this;
}

void* MemoryPool::alloc(size_t bytes) {
    size_t alignedBytes = (bytes + kAlignment - 1) & ~(kAlignment - 1);
    if (offset_ + alignedBytes > capacity_) {
        throw std::bad_alloc();
    }
    void* ptr = buffer_ + offset_;
    offset_ += alignedBytes;
    return ptr;
}

void MemoryPool::reset() {
    offset_ = 0;
}

namespace {
// One active-pool slot per thread, matching MemoryPool's own "each
// inference thread should own its own pool" contract - a thread pool
// added in a later subsystem-8 pass can give each worker its own
// MemoryPool + PooledScope without them stepping on each other.
thread_local MemoryPool* g_activePool = nullptr;
} // namespace

MemoryPool* currentPool() { return g_activePool; }

PooledScope::PooledScope(MemoryPool& pool) noexcept : previous_(g_activePool) {
    g_activePool = &pool;
}

PooledScope::~PooledScope() {
    g_activePool = previous_;
}

} // namespace novallm
