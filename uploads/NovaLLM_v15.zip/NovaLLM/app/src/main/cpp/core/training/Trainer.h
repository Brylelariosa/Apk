#pragma once
#include <functional>
#include <string>
#include "Dataset.h"
#include "ModelOptimizer.h"
#include "../decoder/Model.h"

namespace novallm {

struct TrainingConfig {
    int numEpochs = 1;
    float learningRate = 1e-3f;
    int checkpointEverySteps = 0; // 0 = never checkpoint mid-training
    std::string checkpointPath;   // used only if checkpointEverySteps > 0
};

// The standard loop: for each epoch, for each example in `dataset`,
// forward -> CrossEntropyLoss -> Model::backward -> optimizer step.
// Calls `onStep(stepIndex, loss)` after every example if provided - this
// is how progress reporting or a UI hooks in, without this function
// needing to know anything about where that reporting goes.
void train(Model& model, ModelOptimizer& optimizer, const Dataset& dataset,
           const TrainingConfig& config,
           const std::function<void(int step, float loss)>& onStep = nullptr);

} // namespace novallm
