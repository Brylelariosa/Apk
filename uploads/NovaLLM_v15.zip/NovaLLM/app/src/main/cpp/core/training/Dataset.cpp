#include "Dataset.h"
#include <algorithm>

namespace novallm {

Dataset::Dataset(const std::string& text, const Tokenizer& tokenizer, int maxSeqLen) {
    std::vector<int> allIds = tokenizer.encode(text);
    totalTokens_ = allIds.size();

    size_t step = static_cast<size_t>(maxSeqLen);
    for (size_t start = 0; start < allIds.size(); start += step) {
        size_t end = std::min(start + step, allIds.size());
        size_t chunkLen = end - start;
        if (chunkLen < 2) continue; // need at least one input + one target token

        Example ex;
        ex.ids.assign(allIds.begin() + static_cast<long>(start),
                       allIds.begin() + static_cast<long>(end) - 1);
        ex.targets.assign(allIds.begin() + static_cast<long>(start) + 1,
                           allIds.begin() + static_cast<long>(end));
        examples_.push_back(std::move(ex));
    }
}

} // namespace novallm
