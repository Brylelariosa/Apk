#include "Trainer.h"
#include "Loss.h"

namespace novallm {

void train(Model& model, ModelOptimizer& optimizer, const Dataset& dataset,
           const TrainingConfig& config,
           const std::function<void(int, float)>& onStep) {
    int step = 0;
    for (int epoch = 0; epoch < config.numEpochs; ++epoch) {
        for (size_t i = 0; i < dataset.size(); ++i) {
            const Dataset::Example& ex = dataset.example(i);

            Tensor logits = model.forward(ex.ids);
            Tensor gradLogits;
            float loss = CrossEntropyLoss::forwardBackward(logits, ex.targets, gradLogits);
            Model::Grads grads = model.backward(ex.ids, gradLogits);
            optimizer.step(model, grads, config.learningRate);

            if (onStep) onStep(step, loss);

            if (config.checkpointEverySteps > 0 &&
                (step + 1) % config.checkpointEverySteps == 0) {
                model.save(config.checkpointPath);
            }
            ++step;
        }
    }
}

} // namespace novallm
