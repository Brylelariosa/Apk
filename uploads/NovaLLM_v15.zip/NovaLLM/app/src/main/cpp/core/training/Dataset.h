#pragma once
#include <string>
#include <vector>
#include "../tokenizer/Tokenizer.h"

namespace novallm {

// Tokenizes `text` with `tokenizer` and splits the resulting token stream
// into non-overlapping chunks of at most `maxSeqLen` tokens, each becoming
// one next-token-prediction training example: input = chunk[0..n-2],
// target = chunk[1..n-1] (target[i] is always the token right after
// input[i]). The last chunk may be shorter than maxSeqLen - the Model and
// CrossEntropyLoss both already work with variable sequence lengths, so
// there's no padding to worry about. Chunks too short to form a valid
// (input, target) pair (<2 tokens) are dropped.
//
// Takes raw text, not a file path: reading is left to the caller
// deliberately. On Android, training text bundled as an app asset isn't
// reachable through plain std::ifstream (assets live inside the APK's own
// container, not the regular filesystem) - Kotlin reads it and passes the
// string down through JNI, the same pattern already used for Model
// save/load's cacheDir. Keeping that Android-specific concern out of
// core/ keeps this testable from plain Termux/g++ too.
class Dataset {
public:
    struct Example {
        std::vector<int> ids;
        std::vector<int> targets;
    };

    Dataset(const std::string& text, const Tokenizer& tokenizer, int maxSeqLen);

    size_t size() const { return examples_.size(); }
    const Example& example(size_t i) const { return examples_.at(i); }

    // Total raw tokens the text produced before chunking - useful for
    // reporting corpus size / compression stats.
    size_t totalTokens() const { return totalTokens_; }

private:
    std::vector<Example> examples_;
    size_t totalTokens_ = 0;
};

} // namespace novallm
