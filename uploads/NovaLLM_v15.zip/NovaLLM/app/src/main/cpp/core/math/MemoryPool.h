#pragma once
#include <cstddef>
#include <cstdint>

namespace novallm {

// Simple bump ("arena") allocator. Once we're generating tokens, the
// transformer forward pass allocates the same-shaped temporary buffers
// (attention scores, FFN activations, etc.) over and over - one pool that
// gets reset() every forward pass avoids malloc/free churn for all of that.
//
// Not thread-safe by design - each inference thread should own its own pool.
class MemoryPool {
public:
    explicit MemoryPool(size_t capacityBytes);
    ~MemoryPool();

    MemoryPool(const MemoryPool&) = delete;
    MemoryPool& operator=(const MemoryPool&) = delete;

    // Move-only: lets a MemoryPool live as a member of another movable
    // class (e.g. Model's generation-time scratch pool below) without
    // needing to be copyable. Whoever moves one is responsible for not
    // doing so while a PooledScope backed by it is active.
    MemoryPool(MemoryPool&& other) noexcept;
    MemoryPool& operator=(MemoryPool&& other) noexcept;

    // Returns `bytes` of 16-byte aligned memory (safe for future NEON
    // float32x4_t use). Throws std::bad_alloc if the pool is exhausted.
    void* alloc(size_t bytes);

    float* allocFloats(size_t count) {
        return reinterpret_cast<float*>(alloc(count * sizeof(float)));
    }

    // Rewinds the pool so all previous allocations are invalidated and the
    // space is reused. Call once per forward pass / generated token.
    void reset();

    size_t capacity() const { return capacity_; }
    size_t used() const { return offset_; }

private:
    size_t capacity_;
    size_t offset_ = 0;
    unsigned char* rawBuffer_ = nullptr; // what malloc actually gave us
    unsigned char* buffer_ = nullptr;    // 16-byte aligned start; alloc() hands out from here
};

// RAII helper: while a PooledScope is alive, the ordinary Tensor(shape) /
// Tensor(shape, fillValue) constructors - on this thread - draw their
// storage from `pool` instead of the heap, with no change to any call
// site. Nests safely: destroying an inner scope restores whichever pool
// (if any) was active before it.
//
// Only ephemeral, single-call activations should ever be built inside a
// scope. Anything that must outlive the call (learned weights, KVCache's
// accumulated K/V) is constructed before any scope exists, so it stays
// heap-owned automatically - see Model::forwardIncremental for the
// intended usage. This is the same "temporaries during a forward pass,
// reset every call" pattern MemoryPool's class comment described back in
// subsystem 1 - now actually wired in.
class PooledScope {
public:
    explicit PooledScope(MemoryPool& pool) noexcept;
    ~PooledScope();

    PooledScope(const PooledScope&) = delete;
    PooledScope& operator=(const PooledScope&) = delete;

private:
    MemoryPool* previous_;
};

// The pool (if any) a PooledScope on THIS thread currently has active.
// Consulted by Tensor's constructors - every other MemoryPool user should
// keep passing pools around explicitly; this is purely how Tensor finds
// out which one, if any, is active right now.
MemoryPool* currentPool();

} // namespace novallm
