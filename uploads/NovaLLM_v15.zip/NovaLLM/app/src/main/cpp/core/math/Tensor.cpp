#include "Tensor.h"
#include "MemoryPool.h"
#include <algorithm>
#include <ostream>
#include <istream>
#include <cstdint>
#include <utility>

namespace novallm {

Tensor::Tensor(const std::vector<int>& shape) : shape_(shape) {
    computeStrides();
    size_t n = product(shape_);
    if (MemoryPool* pool = currentPool()) {
        poolData_ = pool->allocFloats(n);
        poolCount_ = n;
        std::fill(poolData_, poolData_ + n, 0.0f);
    } else {
        ownedData_.assign(n, 0.0f);
    }
}

Tensor::Tensor(const std::vector<int>& shape, float fillValue) : shape_(shape) {
    computeStrides();
    size_t n = product(shape_);
    if (MemoryPool* pool = currentPool()) {
        poolData_ = pool->allocFloats(n);
        poolCount_ = n;
        std::fill(poolData_, poolData_ + n, fillValue);
    } else {
        ownedData_.assign(n, fillValue);
    }
}

// Copies always land in heap-owned storage, regardless of whether the
// source was pool-backed - a copy must remain valid even after the pool
// it was copied from gets reset() (or moves, or is destroyed).
Tensor::Tensor(const Tensor& other)
    : shape_(other.shape_), strides_(other.strides_),
      ownedData_(other.data(), other.data() + other.size()) {}

Tensor& Tensor::operator=(const Tensor& other) {
    if (this != &other) {
        shape_ = other.shape_;
        strides_ = other.strides_;
        ownedData_.assign(other.data(), other.data() + other.size());
        poolData_ = nullptr;
        poolCount_ = 0;
    }
    return *this;
}

// Moving is cheap and preserves whichever storage `other` had (heap or
// pool-borrowed); `other` is left as a valid, empty, heap-backed Tensor.
Tensor::Tensor(Tensor&& other) noexcept
    : shape_(std::move(other.shape_)), strides_(std::move(other.strides_)),
      ownedData_(std::move(other.ownedData_)),
      poolData_(other.poolData_), poolCount_(other.poolCount_) {
    other.poolData_ = nullptr;
    other.poolCount_ = 0;
}

Tensor& Tensor::operator=(Tensor&& other) noexcept {
    if (this != &other) {
        shape_ = std::move(other.shape_);
        strides_ = std::move(other.strides_);
        ownedData_ = std::move(other.ownedData_);
        poolData_ = other.poolData_;
        poolCount_ = other.poolCount_;
        other.poolData_ = nullptr;
        other.poolCount_ = 0;
    }
    return *this;
}

void Tensor::computeStrides() {
    strides_.assign(shape_.size(), 1);
    for (int i = static_cast<int>(shape_.size()) - 2; i >= 0; --i) {
        strides_[i] = strides_[i + 1] * shape_[i + 1];
    }
}

size_t Tensor::product(const std::vector<int>& v) {
    size_t p = 1;
    for (int x : v) p *= static_cast<size_t>(x);
    return p;
}

size_t Tensor::flattenIndex(const std::vector<int>& indices) const {
    if (indices.size() != shape_.size()) {
        throw std::out_of_range("Tensor::flattenIndex - rank mismatch");
    }
    size_t idx = 0;
    for (size_t i = 0; i < indices.size(); ++i) {
        if (indices[i] < 0 || indices[i] >= shape_[i]) {
            throw std::out_of_range("Tensor::flattenIndex - index out of bounds");
        }
        idx += static_cast<size_t>(indices[i]) * static_cast<size_t>(strides_[i]);
    }
    return idx;
}

float& Tensor::at(const std::vector<int>& indices) {
    return data()[flattenIndex(indices)];
}

float Tensor::at(const std::vector<int>& indices) const {
    return data()[flattenIndex(indices)];
}

void Tensor::fill(float value) {
    float* d = data();
    size_t n = size();
    for (size_t i = 0; i < n; ++i) d[i] = value;
}

void Tensor::reshape(const std::vector<int>& newShape) {
    if (product(newShape) != size()) {
        throw std::invalid_argument("Tensor::reshape - element count mismatch");
    }
    shape_ = newShape;
    computeStrides();
}

std::string Tensor::debugString(int maxElements) const {
    std::string s = "Tensor(shape=[";
    for (size_t i = 0; i < shape_.size(); ++i) {
        s += std::to_string(shape_[i]);
        if (i + 1 < shape_.size()) s += ",";
    }
    s += "], data=[";
    const float* d = data();
    int n = static_cast<int>(std::min<size_t>(static_cast<size_t>(maxElements), size()));
    for (int i = 0; i < n; ++i) {
        s += std::to_string(d[i]);
        if (i + 1 < n) s += ",";
    }
    if (static_cast<size_t>(n) < size()) s += ",...";
    s += "])";
    return s;
}

void Tensor::save(std::ostream& out) const {
    uint32_t rank = static_cast<uint32_t>(shape_.size());
    out.write(reinterpret_cast<const char*>(&rank), sizeof(rank));
    for (int d : shape_) {
        int32_t dim32 = d;
        out.write(reinterpret_cast<const char*>(&dim32), sizeof(dim32));
    }
    size_t n = size();
    if (n > 0) {
        out.write(reinterpret_cast<const char*>(data()),
                   static_cast<std::streamsize>(n * sizeof(float)));
    }
}

void Tensor::load(std::istream& in) {
    uint32_t rank = 0;
    in.read(reinterpret_cast<char*>(&rank), sizeof(rank));
    std::vector<int> newShape(rank);
    for (uint32_t i = 0; i < rank; ++i) {
        int32_t d = 0;
        in.read(reinterpret_cast<char*>(&d), sizeof(d));
        newShape[i] = d;
    }
    shape_ = newShape;
    computeStrides();
    // load() always (re)populates heap-owned storage, regardless of
    // whatever this Tensor held before - loaded tensors are learned
    // parameters, which must persist, never ephemeral pool-backed scratch.
    poolData_ = nullptr;
    poolCount_ = 0;
    ownedData_.assign(product(shape_), 0.0f);
    if (!ownedData_.empty()) {
        in.read(reinterpret_cast<char*>(ownedData_.data()),
                 static_cast<std::streamsize>(ownedData_.size() * sizeof(float)));
    }
}

} // namespace novallm
