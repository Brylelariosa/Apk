#pragma once
#include <vector>
#include <cstddef>
#include <string>
#include <stdexcept>
#include <iosfwd>

namespace novallm {

// A flat, row-major, N-dimensional float tensor.
// No autograd, no broadcasting magic - just a data buffer + shape.
// Kept intentionally simple: correctness first, SIMD/quantization come
// later as their own subsystem pass on top of this.
//
// Storage is normally an owned, heap-allocated buffer - but if a
// PooledScope (MemoryPool.h) is active on this thread when a Tensor is
// constructed via Tensor(shape) or Tensor(shape, fillValue), it borrows
// its buffer from that pool instead, with everything else about the
// class behaving identically either way. Copying a Tensor always
// produces an independent, heap-owned result, so a copy stays valid
// even after the pool it was borrowed from gets reset(); moving
// transfers whichever storage the source had.
class Tensor {
public:
    Tensor() = default;
    explicit Tensor(const std::vector<int>& shape);
    Tensor(const std::vector<int>& shape, float fillValue);

    Tensor(const Tensor& other);
    Tensor& operator=(const Tensor& other);
    Tensor(Tensor&& other) noexcept;
    Tensor& operator=(Tensor&& other) noexcept;

    // Element access via multi-dimensional index, e.g. t.at({row, col})
    float& at(const std::vector<int>& indices);
    float at(const std::vector<int>& indices) const;

    float* data() { return poolData_ ? poolData_ : ownedData_.data(); }
    const float* data() const { return poolData_ ? poolData_ : ownedData_.data(); }

    size_t size() const { return poolData_ ? poolCount_ : ownedData_.size(); }
    const std::vector<int>& shape() const { return shape_; }
    int dim(int axis) const { return shape_.at(axis); }
    int rank() const { return static_cast<int>(shape_.size()); }

    void fill(float value);
    void reshape(const std::vector<int>& newShape);

    std::string debugString(int maxElements = 16) const;

    // Self-describing binary format: rank, then each dimension, then raw
    // float data. Every learned-parameter class (Linear, LayerNorm, ...)
    // composes its own save/load out of these rather than reimplementing
    // tensor I/O each time.
    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    std::vector<int> shape_;
    std::vector<int> strides_;
    std::vector<float> ownedData_; // storage when NOT pool-backed (the default, unchanged path)
    float* poolData_ = nullptr;    // non-null => storage borrowed from a MemoryPool
    size_t poolCount_ = 0;         // element count when pool-backed; never freed here -
                                    // the pool frees it in bulk via reset()

    void computeStrides();
    size_t flattenIndex(const std::vector<int>& indices) const;
    static size_t product(const std::vector<int>& v);
};

} // namespace novallm

