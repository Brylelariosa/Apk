// A real, working, multi-example training run using the actual Dataset +
// train() infrastructure (not the ad-hoc single-phrase loop from the
// mini-demo test). Trains on ten short, thematically-related sentences,
// watches loss drop, and samples before/after. No Android/JNI needed.
//
// Termux: link against every .cpp under core/math, core/tokenizer,
// core/embedding, core/transformer, core/decoder, and core/training.
#include <cstdio>
#include <string>
#include "core/tokenizer/Tokenizer.h"
#include "core/decoder/Model.h"
#include "core/decoder/Generator.h"
#include "core/training/Dataset.h"
#include "core/training/Trainer.h"
using namespace novallm;

std::string escapeForDisplay(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (c >= 0x20 && c < 0x7F) out += static_cast<char>(c);
        else { char buf[8]; std::snprintf(buf, sizeof(buf), "\\x%02X", c); out += buf; }
    }
    return out;
}

int main() {
    std::string text =
        "the sun rises in the east and sets in the west. "
        "the moon rises at night and gives a soft light. "
        "stars fill the sky when the sun goes down. "
        "rain falls from clouds high above the ground. "
        "wind moves through trees and shakes the leaves. "
        "rivers flow from mountains down to the sea. "
        "fire burns wood and turns it into ash. "
        "ice forms when water grows very cold. "
        "snow covers the ground in winter months. "
        "flowers bloom in spring when the air grows warm.";

    Tokenizer tok;
    std::vector<std::string> corpus = {text};
    tok.train(corpus, 80);

    Model::Config cfg;
    cfg.vocabSize = static_cast<int>(tok.vocabSize());
    cfg.embedDim = 32;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 128;
    cfg.maxSeqLen = 32;
    Model model(cfg, 17);
    ModelOptimizer optimizer(cfg.numLayers);

    Dataset ds(text, tok, cfg.maxSeqLen);
    printf("dataset: %zu examples from %zu tokens, vocab=%zu\n\n", ds.size(), ds.totalTokens(), tok.vocabSize());

    Generator::GenerationParams genParams;
    genParams.maxNewTokens = 20;
    genParams.sampling.temperature = 0.0f;
    Generator genBefore(model, tok, 1);
    std::string before = genBefore.generate("the sun", genParams);
    printf("BEFORE: \"%s\"\n\n", escapeForDisplay(before).c_str());

    TrainingConfig tcfg;
    tcfg.numEpochs = 22;
    tcfg.learningRate = 0.01f;

    float firstLoss = -1.0f, lastLoss = -1.0f;
    int totalSteps = 0;
    train(model, optimizer, ds, tcfg, [&](int step, float loss) {
        if (firstLoss < 0.0f) firstLoss = loss;
        lastLoss = loss;
        totalSteps = step + 1;
        if (step % 50 == 0) printf("step %4d: loss=%.5f\n", step, loss);
    });
    printf("step %4d: loss=%.5f (final)\n", totalSteps - 1, lastLoss);

    Generator genAfter(model, tok, 1);
    std::string after = genAfter.generate("the sun", genParams);
    printf("\nAFTER: \"%s\"\n", escapeForDisplay(after).c_str());

    printf("\nloss %.5f -> %.5f over %d steps (%d epochs x %zu examples)\n",
           firstLoss, lastLoss, totalSteps, tcfg.numEpochs, ds.size());
    return 0;
}
