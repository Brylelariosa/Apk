// Standalone correctness tests for core/math's MemoryPool, Tensor's
// pool-backed storage mode, and the PooledScope wiring now used by
// core/decoder/Model::forwardIncremental(). No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_memory_pool.cpp \
//     ../app/src/main/cpp/core/math/*.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/embedding/*.cpp \
//     ../app/src/main/cpp/core/transformer/*.cpp \
//     ../app/src/main/cpp/core/decoder/*.cpp \
//     -o test_memory_pool && ./test_memory_pool
#include <cstdio>
#include <cmath>
#include <chrono>
#include <utility>
#include <vector>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/MemoryPool.h"
#include "core/decoder/Model.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

// ---------------------------------------------------------------------
// MemoryPool itself: alloc/reset/exhaustion, plus the new move support
// (needed so Model can hold one as a plain member - see Model.h).
// ---------------------------------------------------------------------

void testAllocReturnsWritableMemory() {
    MemoryPool pool(4096);
    float* buf = pool.allocFloats(10);
    for (int i = 0; i < 10; ++i) buf[i] = static_cast<float>(i);
    bool ok = true;
    for (int i = 0; i < 10; ++i) {
        if (buf[i] != static_cast<float>(i)) ok = false;
    }
    expectTrue(ok, "MemoryPool: allocFloats returns writable memory for the requested count");
}

void testResetRewindsToTheSameAddress() {
    MemoryPool pool(4096);
    float* first = pool.allocFloats(8);
    pool.reset();
    float* second = pool.allocFloats(8);
    expectTrue(first == second, "MemoryPool: reset() rewinds the offset, so the next alloc reuses the same address");
}

void testExhaustionThrowsBadAllocInsteadOfCorrupting() {
    MemoryPool pool(64); // tiny on purpose
    bool threw = false;
    try {
        pool.allocFloats(1000); // 4000 bytes, far more than 64 can hold
    } catch (const std::bad_alloc&) {
        threw = true;
    }
    expectTrue(threw, "MemoryPool: allocating past capacity throws std::bad_alloc rather than corrupting silently");
}

void testMoveConstructorTransfersOwnershipAndData() {
    MemoryPool poolA(4096);
    float* p = poolA.allocFloats(16);
    for (int i = 0; i < 16; ++i) p[i] = 3.5f;
    size_t usedBefore = poolA.used();
    size_t capBefore = poolA.capacity();

    MemoryPool poolB(std::move(poolA));
    expectTrue(poolB.used() == usedBefore, "MemoryPool move ctor: used() carries over to the destination");
    expectTrue(poolB.capacity() == capBefore, "MemoryPool move ctor: capacity() carries over to the destination");
    bool valuesIntact = true;
    for (int i = 0; i < 16; ++i) {
        if (p[i] != 3.5f) valuesIntact = false;
    }
    expectTrue(valuesIntact, "MemoryPool move ctor: previously-written data survives the move");
    // poolA is left safely destructible (moved-from) - just letting it go
    // out of scope here doubles as a check that ~MemoryPool() doesn't
    // double-free.
}

void testMoveAssignmentReplacesDestinationCorrectly() {
    MemoryPool poolA(4096);
    poolA.allocFloats(8); // 32 bytes, already 16-byte aligned
    MemoryPool poolB(128);

    poolB = std::move(poolA);
    expectTrue(poolB.capacity() == 4096, "MemoryPool move assignment: capacity replaced with the source's");
    expectTrue(poolB.used() == 32, "MemoryPool move assignment: used() replaced with the source's");
}

// ---------------------------------------------------------------------
// Tensor's pool-backed storage mode.
//
// IMPORTANT pattern used throughout below: the MemoryPool variable is
// always declared in an OUTER scope than the PooledScope that activates
// it, and outlives every Tensor that borrows from it. PooledScope only
// controls which pool new Tensors draw from - it does not extend the
// pool's own lifetime. This mirrors how Model uses scratchPool_ (a
// member that outlives any single forwardIncremental() call).
// ---------------------------------------------------------------------

void testTensorWithNoScopeIsUnaffected() {
    expectTrue(currentPool() == nullptr, "sanity: no PooledScope active at the start of this test");
    Tensor t({3, 3}, 5.0f);
    bool ok = true;
    for (size_t i = 0; i < t.size(); ++i) {
        if (t.data()[i] != 5.0f) ok = false;
    }
    expectTrue(ok, "Tensor: with no PooledScope active, construction is exactly today's heap-backed behavior");
}

void testTensorInsideScopeDrawsFromThePool() {
    MemoryPool pool(4096);
    size_t usedBefore;
    bool grew, valuesOk = true;
    {
        PooledScope scope(pool);
        usedBefore = pool.used();
        Tensor t({4, 4}, 2.0f); // 16 floats
        grew = pool.used() > usedBefore;
        for (size_t i = 0; i < t.size(); ++i) {
            if (t.data()[i] != 2.0f) valuesOk = false;
        }
    }
    expectTrue(grew, "Tensor: constructing inside a PooledScope draws storage from that pool");
    expectTrue(valuesOk, "Tensor: pool-backed construction still fills values correctly");
}

void testMatmulInsideScopeProducesCorrectValues() {
    MemoryPool pool(4096);
    Tensor a({2, 3}), b({3, 2});
    float av[] = {1, 2, 3, 4, 5, 6};
    float bv[] = {7, 8, 9, 10, 11, 12};
    for (int i = 0; i < 6; ++i) { a.data()[i] = av[i]; b.data()[i] = bv[i]; }

    Tensor result;
    {
        PooledScope scope(pool);
        result = matrix::matmul(a, b); // computed pool-backed; pool (above) outlives this block
    }
    float expected[] = {58, 64, 139, 154};
    bool ok = true;
    for (int i = 0; i < 4; ++i) {
        if (std::fabs(result.data()[i] - expected[i]) > 1e-4f) ok = false;
    }
    expectTrue(ok, "matmul: produces correct values when its output is pool-backed");
}

// THE critical safety property: a Tensor's COPY must remain valid even
// after the pool it was copied FROM gets reset() for a later, unrelated
// call - exactly what happens between successive
// Model::forwardIncremental() calls sharing one scratchPool_.
void testCopySurvivesALaterResetOfItsSourcePool() {
    MemoryPool pool(4096);
    Tensor copyOut;
    {
        PooledScope scope(pool);
        Tensor a({4}, 0.0f);
        for (int i = 0; i < 4; ++i) a.data()[i] = 7.0f + static_cast<float>(i);
        copyOut = a; // COPY (a is an lvalue) - must deep-copy to heap right here
    }
    {
        // Simulates the NEXT forwardIncremental() call: same pool,
        // reset(), new allocations landing at the same offsets `a` used.
        PooledScope scope(pool);
        pool.reset();
        Tensor b({4}, -99.0f); // would alias copyOut's old bytes if the copy had shared a pointer
        (void)b;
    }
    bool intact = true;
    for (int i = 0; i < 4; ++i) {
        if (std::fabs(copyOut.data()[i] - (7.0f + static_cast<float>(i))) > 1e-6f) intact = false;
    }
    expectTrue(intact, "Tensor copy: survives a later reset() of the pool it was copied from");
}

void testExplicitMovePreservesPoolBackedValues() {
    MemoryPool pool(4096);
    Tensor result;
    {
        PooledScope scope(pool);
        Tensor temp({4}, 9.5f);
        result = std::move(temp); // explicit move of an lvalue - transfers storage, doesn't deep-copy
    }
    bool ok = true;
    for (size_t i = 0; i < result.size(); ++i) {
        if (result.data()[i] != 9.5f) ok = false;
    }
    expectTrue(ok, "Tensor: explicit move out of a scope preserves pool-backed values (pool still alive)");
}

void testNestedScopesRestorePreviousPoolOnExit() {
    MemoryPool outer(4096);
    MemoryPool inner(4096);
    expectTrue(currentPool() == nullptr, "PooledScope: no pool active before any scope opens");
    {
        PooledScope scopeOuter(outer);
        expectTrue(currentPool() == &outer, "PooledScope: outer scope is active once opened");
        {
            PooledScope scopeInner(inner);
            expectTrue(currentPool() == &inner, "PooledScope: nested inner scope takes over while active");
        }
        expectTrue(currentPool() == &outer, "PooledScope: exiting the inner scope restores the outer one");
    }
    expectTrue(currentPool() == nullptr, "PooledScope: exiting the outer scope restores the no-pool state");
}

// ---------------------------------------------------------------------
// End-to-end through Model - the actual consumer of all of the above.
// ---------------------------------------------------------------------

Model::Config smallConfig(int vocabSize) {
    Model::Config cfg;
    cfg.vocabSize = vocabSize;
    cfg.embedDim = 16;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 64;
    cfg.maxSeqLen = 64;
    return cfg;
}

void testForwardIncrementalMatchesForwardWithPoolingActive() {
    Model model(smallConfig(300), /*seed=*/9);
    std::vector<int> ids = {2, 4, 6, 8, 10};
    Tensor ref = model.forward(ids); // trusted, non-incremental, never pool-backed

    model.resetCache();
    bool allMatch = true;
    for (size_t i = 0; i < ids.size() && allMatch; ++i) {
        std::vector<int> step = {ids[i]};
        Tensor stepLogits = model.forwardIncremental(step); // now pool-backed internally
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(ref.at({static_cast<int>(i), v}) - stepLogits.at({0, v})) > 1e-3f) {
                allMatch = false;
                break;
            }
        }
    }
    expectTrue(allMatch, "Model: pooled forwardIncremental still matches non-pooled forward() exactly");
}

void testScratchPoolIsActuallyUsedAndWithinBudget() {
    Model model(smallConfig(300), /*seed=*/10);
    model.resetCache();
    model.forwardIncremental(std::vector<int>{1, 2, 3, 4});

    bool used = model.scratchPoolUsed() > 0;
    bool withinBudget = model.scratchPoolUsed() <= model.scratchPoolCapacity();
    expectTrue(used, "Model: forwardIncremental actually exercises the scratch pool (used() > 0)");
    expectTrue(withinBudget, "Model: scratch pool usage stays within its estimated capacity");
}

// A much larger, hypothetical future config must not try to grab
// gigabytes upfront - estimateScratchPoolBytes() caps at 32MB (see
// Model.cpp) and lets an actual over-budget call fail loud instead.
void testHugeConfigCapacityStaysCapped() {
    Model::Config cfg = smallConfig(50);
    cfg.embedDim = 512;
    cfg.numLayers = 12;
    cfg.numHeads = 8;
    cfg.ffnHiddenDim = 2048;
    cfg.maxSeqLen = 512;
    Model model(cfg, /*seed=*/13); // must construct promptly, no multi-GB allocation attempt
    expectTrue(model.scratchPoolCapacity() <= 32u * 1024 * 1024,
               "Model: scratch pool capacity stays capped even for a much larger hypothetical config");
}

void testManyGenerationStepsNeverExceedBudget() {    // Longer than any other test exercises - guards against
    // estimateScratchPoolBytes() being too tight for a real session.
    Model model(smallConfig(300), /*seed=*/11);
    model.resetCache();
    bool ok = true;
    try {
        std::vector<int> id = {1};
        model.forwardIncremental(id);
        for (int step = 0; step < 40; ++step) {
            std::vector<int> single = {(step % 250) + 1};
            model.forwardIncremental(single);
        }
    } catch (const std::bad_alloc&) {
        ok = false;
    }
    expectTrue(ok, "Model: 40+ consecutive forwardIncremental calls never exhaust the scratch pool");
}

// Illustrative, not a rigorous benchmark (same caveat as core/runtime's
// own timing test) - this sandbox's allocator may not behave like a
// phone's, and the trend matters more than the exact numbers.
void demoAllocationOverheadComparison() {
    const int iterations = 20000;
    Tensor a({16, 16}, 1.0f), b({16, 16}, 2.0f);

    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < iterations; ++i) {
        Tensor c = matrix::matmul(a, b);
        Tensor d = matrix::add(c, a);
        Tensor e = matrix::transpose(d);
        (void)e;
    }
    auto t1 = std::chrono::steady_clock::now();

    MemoryPool pool(1 << 16);
    for (int i = 0; i < iterations; ++i) {
        pool.reset();
        PooledScope scope(pool);
        Tensor c = matrix::matmul(a, b);
        Tensor d = matrix::add(c, a);
        Tensor e = matrix::transpose(d);
        (void)e;
    }
    auto t2 = std::chrono::steady_clock::now();

    double heapMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
    double pooledMs = std::chrono::duration<double, std::milli>(t2 - t1).count();
    std::printf("\n%d matmul+add+transpose chains (16x16) \u2014 heap: %ldms, pooled: %ldms\n",
                iterations, static_cast<long>(heapMs), static_cast<long>(pooledMs));
}

int main() {
    testAllocReturnsWritableMemory();
    testResetRewindsToTheSameAddress();
    testExhaustionThrowsBadAllocInsteadOfCorrupting();
    testMoveConstructorTransfersOwnershipAndData();
    testMoveAssignmentReplacesDestinationCorrectly();

    testTensorWithNoScopeIsUnaffected();
    testTensorInsideScopeDrawsFromThePool();
    testMatmulInsideScopeProducesCorrectValues();
    testCopySurvivesALaterResetOfItsSourcePool();
    testExplicitMovePreservesPoolBackedValues();
    testNestedScopesRestorePreviousPoolOnExit();

    testForwardIncrementalMatchesForwardWithPoolingActive();
    testScratchPoolIsActuallyUsedAndWithinBudget();
    testHugeConfigCapacityStaysCapped();
    testManyGenerationStepsNeverExceedBudget();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);

    demoAllocationOverheadComparison();

    return g_failures == 0 ? 0 : 1;
}
