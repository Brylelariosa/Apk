// Standalone tests for Dataset - chunking raw text into next-token-
// prediction training examples. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_dataset.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/training/Dataset.cpp \
//     -o test_dataset && ./test_dataset
#include <cstdio>
#include <cmath>
#include "core/tokenizer/Tokenizer.h"
#include "core/training/Dataset.h"
using namespace novallm;

static int g_failures = 0;
void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

void testChunkingCorrectness() {
    Tokenizer tok;
    std::vector<std::string> corpus = {"the sun rises in the east and sets in the west"};
    tok.train(corpus, 20);

    std::string text = "the sun rises in the east and sets in the west";
    std::vector<int> allIds = tok.encode(text);
    printf("  (raw token count: %zu)\n", allIds.size());

    Dataset ds(text, tok, 5); // small maxSeqLen to force multiple chunks
    expectTrue(ds.totalTokens() == allIds.size(), "Dataset: totalTokens matches raw encode() length");

    // Reconstruct the full id stream from all chunks and verify it
    // matches consecutive slices of allIds exactly - this checks both the
    // chunk boundaries AND the input/target shift-by-one relationship.
    size_t pos = 0;
    bool chunksOk = true;
    for (size_t c = 0; c < ds.size(); ++c) {
        const auto& ex = ds.example(c);
        // ex.ids should be allIds[pos .. pos+len), ex.targets shifted by 1
        for (size_t i = 0; i < ex.ids.size(); ++i) {
            if (ex.ids[i] != allIds[pos + i]) chunksOk = false;
            if (ex.targets[i] != allIds[pos + i + 1]) chunksOk = false;
        }
        pos += ex.ids.size() + 1; // +1 because each chunk's target reaches one further than its ids
    }
    expectTrue(chunksOk, "Dataset: chunk ids/targets exactly match consecutive slices of the raw token stream");
}

void testTinyTextEdgeCase() {
    Tokenizer tok;
    std::vector<std::string> corpus = {"hi"};
    tok.train(corpus, 5);
    Dataset ds("h", tok, 10); // single byte - can't form even one (input,target) pair
    expectTrue(ds.size() == 0, "Dataset: text too short to form any example yields zero examples, no crash");
}

void testMultiExampleTrainingReducesLoss() {
    Tokenizer tok;
    std::string text = "the sun rises in the east. the moon rises at night. "
                        "stars fill the sky. rain falls from clouds. wind moves the trees.";
    std::vector<std::string> corpus = {text};
    tok.train(corpus, 60);

    Dataset ds(text, tok, 16);
    printf("  (dataset: %zu examples from %zu tokens)\n", ds.size(), ds.totalTokens());
    expectTrue(ds.size() >= 2, "Dataset: realistic multi-sentence text yields multiple examples");
}

int main() {
    testChunkingCorrectness();
    testTinyTextEdgeCase();
    testMultiExampleTrainingReducesLoss();
    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
