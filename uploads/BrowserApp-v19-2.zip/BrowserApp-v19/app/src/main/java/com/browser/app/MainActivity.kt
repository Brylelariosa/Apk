package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.app.DownloadManager
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.util.TypedValue
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.webkit.JavascriptInterface
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class BrowserTab(
    val id: Int,
    val webView: ScrollAwareWebView,
    var url: String   = "",
    var title: String = "New Tab"
)

class MainActivity : AppCompatActivity() {

    // ── Static views ───────────────────────────────────────────────────
    private lateinit var webViewContainer: FrameLayout
    private lateinit var urlBar:           LinearLayout
    private lateinit var urlInput:         EditText
    private lateinit var btnBack:          ImageButton
    private lateinit var btnForward:       ImageButton
    private lateinit var btnRefresh:       ImageButton
    private lateinit var btnSettings:      ImageButton
    private lateinit var btnAddSpeedDial:  ImageButton
    private lateinit var btnTabCount:      TextView
    private lateinit var btnToggle:        ImageButton
    private lateinit var pageProgress:     ProgressBar
    private lateinit var tapZoneIndicator: View
    private lateinit var debugOverlayView: TextView

    // ── Tabs ───────────────────────────────────────────────────────────
    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabIndex = 0
    private var tabIdCounter   = 0
    private var tabDialog: AlertDialog? = null
    private val webView get() = tabs[activeTabIndex].webView

    // ── File upload ────────────────────────────────────────────────────
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        fileUploadCallback?.onReceiveValue(uris.toTypedArray())
        fileUploadCallback = null
    }

    // ── Gesture / state ────────────────────────────────────────────────
    private var gestureDetector: GestureDetector? = null
    private val prefs by lazy { getSharedPreferences("browser", MODE_PRIVATE) }

    private var urlBarVisible    = false
    private var toggleVisible    = true
    private var isOnHomePage     = false
    private var isImeVisible     = false
    private var webInputFocused  = false
    private var debugOverlayVisible = false
    private var lastScrollMs     = 0L

    @Volatile private var currentHost:     String? = null
    @Volatile private var adBlockEnabled   = true
    @Volatile private var dataSaverLevel   = 0
    @Volatile private var fabBehavior      = 0
    @Volatile private var tapZone          = 2
    @Volatile private var swipeNavEnabled  = false

    private val resetWebInputFocused = Runnable { if (!isImeVisible) webInputFocused = false }

    companion object {
        private const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"
        private val DATA_SAVER_LABELS = arrayOf(
            "Off", "High Quality (~20%)", "Medium Quality (~40%)",
            "Low Quality (~65%)", "No Images (~80%)")
        private val FAB_BEHAVIOR_LABELS = arrayOf(
            "Auto-hide on scroll", "Tap page to hide", "Always visible", "Hidden – tap zone")
        private val TAP_ZONE_LABELS = arrayOf(
            "Top of screen", "Bottom-left", "Bottom-center", "Bottom-right")
        private val TAP_ZONE_SHORT = arrayOf("Top", "Btm-L", "Btm-C", "Btm-R")
        private val DEFAULT_SPEED_DIAL = """[
{"url":"https://www.google.com","name":"Google"},
{"url":"https://www.youtube.com","name":"YouTube"},
{"url":"https://www.facebook.com","name":"Facebook"},
{"url":"https://www.reddit.com","name":"Reddit"},
{"url":"https://x.com","name":"X"},
{"url":"https://www.wikipedia.org","name":"Wikipedia"},
{"url":"https://github.com","name":"GitHub"},
{"url":"https://gmail.com","name":"Gmail"}]"""
    }

    // ══════════════════════════════════════════════════════════════════
    // HOME HTML — add sheet calls native dialog (fixes keyboard issue)
    // ══════════════════════════════════════════════════════════════════

    private fun buildHomeHtml() = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{background:#0a0a0a;color:#fff;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:52px 18px 30px}
.clock{font-size:68px;font-weight:200;letter-spacing:-3px;line-height:1;
  background:linear-gradient(135deg,#fff 40%,#4FC3F7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.date{font-size:13px;color:#666;margin-top:6px;margin-bottom:36px;letter-spacing:.5px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;width:100%;max-width:400px}
a{text-decoration:none;color:inherit}
.card{display:flex;flex-direction:column;align-items:center;gap:7px;
  padding:14px 6px 11px;border-radius:16px;background:#161616;
  border:1px solid #1e1e1e;position:relative;user-select:none;-webkit-user-select:none}
.card:active{background:#222;transform:scale(.95)}
/* editing: no wobble - kills perf */
.card.editing{border-color:#333;outline:1px solid #2a2a2a}
.icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;
  justify-content:center;overflow:hidden;background:#1e1e1e;flex-shrink:0}
.icon img{width:32px;height:32px;object-fit:contain;display:block}
.fallback{width:46px;height:46px;border-radius:12px;display:none;
  align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff;background:#2a2a2a}
.label{font-size:10px;color:#777;text-align:center;letter-spacing:.3px;
  width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.del-btn{position:absolute;top:-7px;right:-7px;width:22px;height:22px;border-radius:50%;
  background:#FF4444;display:none;align-items:center;justify-content:center;
  font-size:14px;color:#fff;z-index:20;font-weight:700}
.card.editing .del-btn{display:flex}
.add-card{cursor:pointer;border-style:dashed;border-color:#252525;background:#0e0e0e}
.done-bar{grid-column:1/-1;display:flex;align-items:center;justify-content:center;
  padding:11px;border-radius:12px;background:#0d1a22;border:1px solid #4FC3F7;
  color:#4FC3F7;font-size:13px;font-weight:600;cursor:pointer;margin-top:2px}
</style>
</head>
<body>
<div class="clock" id="clk"></div>
<div class="date" id="dt"></div>
<div class="grid" id="grid"></div>
<script>
var DEFAULTS=${DEFAULT_SPEED_DIAL.trimIndent()};
var editing=false;
function sdLoad(){
  try{
    if(typeof SpeedDial!=='undefined'){var d=SpeedDial.get();if(d&&d.length>2)return JSON.parse(d);}
    var s=localStorage.getItem('sd');return s?JSON.parse(s):DEFAULTS.slice();
  }catch(e){return DEFAULTS.slice();}
}
function sdSave(a){
  try{var j=JSON.stringify(a);
    if(typeof SpeedDial!=='undefined')SpeedDial.save(j);else localStorage.setItem('sd',j);
  }catch(e){}
}
function fav(url){
  try{var h=new URL(url).hostname;return'https://www.google.com/s2/favicons?domain='+h+'&sz=64';}
  catch(e){return'';}
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function render(){
  var items=sdLoad(),g=document.getElementById('grid');
  g.innerHTML='';
  items.forEach(function(it,i){
    var w=document.createElement('div');w.style.position='relative';
    var fi=fav(it.url),ini=it.name.charAt(0).toUpperCase();
    w.innerHTML='<a href="'+(editing?'javascript:void(0)':it.url)+'" class="sl">'
      +'<div class="card'+(editing?' editing':'')+'"><div class="del-btn" data-del="'+i+'">&#10005;</div>'
      +'<div class="icon"><img src="'+fi+'" width="32" height="32"'
        +' onerror="this.style.display=\'none\';this.nextSibling.style.display=\'flex\'">'
      +'<div class="fallback">'+ini+'</div></div>'
      +'<span class="label">'+esc(it.name)+'</span></div></a>';
    var pt,pl=w.querySelector('.sl');
    pl.addEventListener('touchstart',function(){pt=setTimeout(function(){editing=true;render();},600);},{passive:true});
    pl.addEventListener('touchend',function(){clearTimeout(pt);});
    pl.addEventListener('touchmove',function(){clearTimeout(pt);});
    w.querySelector('.del-btn').addEventListener('click',function(e){
      e.preventDefault();e.stopPropagation();
      var a=sdLoad();a.splice(parseInt(this.dataset.del),1);sdSave(a);render();
    });
    g.appendChild(w);
  });
  var aw=document.createElement('div');aw.style.position='relative';
  aw.innerHTML='<div class="card add-card"><div class="icon" style="background:transparent;font-size:26px;color:#444">+</div><span class="label">Add</span></div>';
  aw.addEventListener('click',function(){
    editing=false;render();
    /* Call native dialog — no keyboard-in-webview issue */
    if(typeof SpeedDial!=='undefined')SpeedDial.openAddDialog();
  });
  g.appendChild(aw);
  if(editing){
    var db=document.createElement('div');db.className='done-bar';db.textContent='Done';
    db.addEventListener('click',function(){editing=false;render();});
    g.appendChild(db);
  }
}
window.addToSpeedDial=function(url,name){
  var a=sdLoad();
  for(var i=0;i<a.length;i++){if(a[i].url===url)return;}
  a.push({url:url,name:name});sdSave(a);render();
};
window.refreshSpeedDial=function(){render();};
function tick(){
  var n=new Date(),h=n.getHours().toString().padStart(2,'0'),m=n.getMinutes().toString().padStart(2,'0'),
      days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
      months=['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('clk').textContent=h+':'+m;
  document.getElementById('dt').textContent=days[n.getDay()]+', '+months[n.getMonth()]+' '+n.getDate();
}
tick();setInterval(tick,5000);render();
</script>
</body>
</html>"""

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        CookieManager.getInstance().setAcceptCookie(true)

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { v, insets ->
            val wasVis = isImeVisible
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            when {
                !wasVis && isImeVisible  -> { webView.removeCallbacks(resetWebInputFocused); webInputFocused = true }
                wasVis  && !isImeVisible -> { webInputFocused = false; applyImmersiveMode() }
            }
            ViewCompat.onApplyWindowInsets(v, insets)
        }

        bindStaticViews()
        loadSettings()          // restore persisted settings before anything renders
        applyImmersiveMode()
        val first = createTab()
        switchToTab(0, false)
        loadHomePage(first.webView)
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    // ── Settings persistence ───────────────────────────────────────────

    private fun loadSettings() {
        adBlockEnabled  = prefs.getBoolean("ad_block",      true)
        dataSaverLevel  = prefs.getInt    ("data_saver",    0)
        fabBehavior     = prefs.getInt    ("fab_behavior",  0)
        tapZone         = prefs.getInt    ("tap_zone",      2)
        swipeNavEnabled = prefs.getBoolean("swipe_nav",     false)
        // Apply FAB state that depends on fabBehavior
        if (fabBehavior == 3) {
            btnToggle.alpha = 0f; btnToggle.translationY = 0f; toggleVisible = false
        }
    }

    private fun saveSettings() {
        prefs.edit()
            .putBoolean("ad_block",     adBlockEnabled)
            .putInt    ("data_saver",   dataSaverLevel)
            .putInt    ("fab_behavior", fabBehavior)
            .putInt    ("tap_zone",     tapZone)
            .putBoolean("swipe_nav",    swipeNavEnabled)
            .apply()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isImeVisible && !webInputFocused)
            window.decorView.postDelayed({ if (!isImeVisible && !webInputFocused) applyImmersiveMode() }, 350)
    }

    private fun applyImmersiveMode() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // Tabs
    // ══════════════════════════════════════════════════════════════════

    private fun createTab(): BrowserTab {
        val wv = ScrollAwareWebView(this)
        configureWebView(wv)
        val tab = BrowserTab(tabIdCounter++, wv)
        tabs.add(tab)
        return tab
    }

    private fun switchToTab(index: Int, animate: Boolean = true) {
        if (tabs.isEmpty()) return
        val ni = index.coerceIn(0, tabs.lastIndex)
        if (activeTabIndex < tabs.size) {
            val old = tabs[activeTabIndex].webView
            if (old.parent != null) {
                if (animate) old.animate().alpha(0f).translationX(-50f * resources.displayMetrics.density)
                    .setDuration(140).setInterpolator(AccelerateInterpolator())
                    .withEndAction { webViewContainer.removeView(old) }.start()
                else webViewContainer.removeView(old)
            }
        }
        activeTabIndex = ni
        val nw = tabs[ni].webView
        if (nw.parent == null) webViewContainer.addView(nw, 0,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (animate) { nw.alpha = 0f; nw.translationX = 50f * resources.displayMetrics.density
            nw.animate().alpha(1f).translationX(0f).setDuration(160).setInterpolator(DecelerateInterpolator()).start()
        } else { nw.alpha = 1f; nw.translationX = 0f }
        ViewCompat.setOnApplyWindowInsetsListener(nw) { v, ins ->
            v.setPadding(0, 0, 0, ins.getInsets(WindowInsetsCompat.Type.ime()).bottom); ins }
        updateTabCount(); buildGestureDetector(); syncNavButtons()
    }

    private fun closeTab(i: Int) {
        if (tabs.size == 1) {
            webViewContainer.removeView(tabs[0].webView); tabs[0].webView.destroy()
            tabs.clear(); activeTabIndex = 0
            val t = createTab(); switchToTab(0, false); loadHomePage(t.webView); return
        }
        val tab = tabs.removeAt(i)
        webViewContainer.removeView(tab.webView); tab.webView.destroy()
        switchToTab(if (activeTabIndex >= tabs.size) tabs.lastIndex else activeTabIndex, false)
    }

    private fun openNewTab(url: String? = null) {
        val t = createTab(); switchToTab(tabs.lastIndex)
        if (url != null) t.webView.loadUrl(url) else loadHomePage(t.webView)
    }

    private fun updateTabCount() { btnTabCount.text = tabs.size.toString() }

    private fun showTabSwitcher() {
        val dp = resources.displayMetrics.density
        val sv = ScrollView(this)
        val ct = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4*dp).toInt(), 0, (8*dp).toInt())
        }
        val newTabTv = TextView(this).apply {
            text = "+ New Tab"; setTextColor(Color.parseColor("#4FC3F7")); textSize = 15f
            setPadding((20*dp).toInt(),(14*dp).toInt(),(20*dp).toInt(),(14*dp).toInt())
        }
        newTabTv.setOnClickListener { openNewTab(); tabDialog?.dismiss() }
        ct.addView(newTabTv)

        tabs.forEachIndexed { i, tab ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((20*dp).toInt(),(10*dp).toInt(),(8*dp).toInt(),(10*dp).toInt())
                if (i == activeTabIndex) setBackgroundColor(Color.parseColor("#1A4FC3F7"))
                isClickable = true; isFocusable = true
            }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            box.addView(TextView(this).apply { text = tab.title.ifBlank{"New Tab"}
                setTextColor(if(i==activeTabIndex) Color.parseColor("#4FC3F7") else Color.WHITE)
                textSize=13f; maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
            box.addView(TextView(this).apply { text=tab.url.ifBlank{"Home"}
                setTextColor(Color.parseColor("#55FFFFFF")); textSize=10f; maxLines=1
                ellipsize=android.text.TextUtils.TruncateAt.END
                setPadding(0,(2*dp).toInt(),0,0) })
            val cx = TextView(this).apply { text="✕"; textSize=15f
                setTextColor(Color.parseColor("#55FFFFFF"))
                setPadding((16*dp).toInt(),(8*dp).toInt(),(8*dp).toInt(),(8*dp).toInt()) }
            row.addView(box); row.addView(cx)
            val ci = i
            row.setOnClickListener { switchToTab(ci); tabDialog?.dismiss() }
            cx.setOnClickListener  { closeTab(ci);  tabDialog?.dismiss() }
            ct.addView(row)
            ct.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#22FFFFFF"))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })
        }
        sv.addView(ct)
        tabDialog = AlertDialog.Builder(this).setTitle("Tabs (${tabs.size})").setView(sv)
            .setNegativeButton("Close", null).show().also { it.styleDialog() }
    }

    // ══════════════════════════════════════════════════════════════════
    // Static views
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun bindStaticViews() {
        webViewContainer = findViewById(R.id.webViewContainer)
        urlBar           = findViewById(R.id.urlBar)
        urlInput         = findViewById(R.id.urlInput)
        btnBack          = findViewById(R.id.btnBack)
        btnForward       = findViewById(R.id.btnForward)
        btnRefresh       = findViewById(R.id.btnRefresh)
        btnSettings      = findViewById(R.id.btnSettings)
        btnAddSpeedDial  = findViewById(R.id.btnAddSpeedDial)
        btnTabCount      = findViewById(R.id.btnTabCount)
        btnToggle        = findViewById(R.id.btnToggleUrlBar)
        pageProgress     = findViewById(R.id.pageProgress)
        tapZoneIndicator = findViewById(R.id.tapZoneIndicator)
        tapZoneIndicator.visibility = View.GONE

        debugOverlayView = TextView(this).apply {
            textSize = 9f; setTextColor(0xFFFFFF00.toInt()); setBackgroundColor(0xCC000000.toInt())
            setPadding(8,8,8,8); elevation = 50f; visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.BOTTOM)
        }
        (findViewById<FrameLayout>(android.R.id.content)).addView(debugOverlayView)

        urlBar.post { urlBar.translationY = -urlBar.height.toFloat() }

        btnToggle.setOnClickListener       { toggleUrlBar() }
        btnBack.setOnClickListener         { if (webView.canGoBack())    webView.goBack() }
        btnForward.setOnClickListener      { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener      { if (isOnHomePage) loadHomePage(webView) else webView.reload() }
        btnSettings.setOnClickListener     { showSettingsDialog() }
        btnTabCount.setOnClickListener     { showTabSwitcher() }
        btnAddSpeedDial.setOnClickListener {
            if (isOnHomePage) { Toast.makeText(this,"Already on home",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val url  = webView.url ?: return@setOnClickListener
            val name = webView.title?.trim()?.take(28)?.ifBlank{null}
                ?: try { java.net.URI(url).host?.removePrefix("www.") } catch(_:Exception){null}
                ?: url
            showNativeAddSpeedDialDialog(url, name)
        }

        urlInput.setOnEditorActionListener { _, id, ev ->
            val ok = id in listOf(EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_SEARCH,
                EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_UNSPECIFIED)
                || (ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
            if (ok) { navigateTo(urlInput.text.toString()); true } else false
        }
        urlInput.setOnKeyListener { _, k, ev ->
            if (k == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN) { navigateTo(urlInput.text.toString()); true } else false
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Gesture detector — rebuilt on each tab switch
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun buildGestureDetector() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (urlBarVisible) { hideUrlBar(); return true }; return false
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (fabBehavior == 1 && toggleVisible && !urlBarVisible) { hideToggleFab(); return true }
                if (fabBehavior == 3 && !urlBarVisible && isTapInZone(e.x, e.y)) { showUrlBar(); return true }
                return false
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vX: Float, vY: Float): Boolean {
                if (!swipeNavEnabled || urlBarVisible) return false
                val sx  = e1?.x ?: return false
                val aX  = if (vX > 0) vX else -vX
                val aY  = if (vY > 0) vY else -vY
                if (aX < 500f || aX < aY * 1.2f) return false
                val edgePx = 64 * resources.displayMetrics.density
                val goBack = vX > 0
                if  (goBack && sx > edgePx) return false                    // left-edge only
                if (!goBack && sx < webView.width - edgePx) return false    // right-edge only
                if  (goBack && !webView.canGoBack())    return false
                if (!goBack && !webView.canGoForward()) return false
                animateNavigation(goBack)
                return true
            }
        })
        gestureDetector = gd
        webView.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                webInputFocused = true
                webView.removeCallbacks(resetWebInputFocused)
                webView.postDelayed(resetWebInputFocused, 600)
            }
            gd.onTouchEvent(ev); false
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Swipe navigation — screenshot-overlay slide
    // ══════════════════════════════════════════════════════════════════

    private fun animateNavigation(goBack: Boolean) {
        val wv   = webView
        val cont = webViewContainer
        try {
            // Capture current frame into a bitmap
            val bmp = Bitmap.createBitmap(wv.width.coerceAtLeast(1), wv.height.coerceAtLeast(1), Bitmap.Config.RGB_565)
            wv.draw(Canvas(bmp))

            // Place snapshot on top — user sees this while new page loads beneath
            val snap = ImageView(this).apply {
                setImageBitmap(bmp)
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT)
                elevation = 5f
            }
            cont.addView(snap)

            // Navigate immediately (loads behind snapshot)
            if (goBack) wv.goBack() else wv.goForward()

            // Slide snapshot away to reveal new page (like a card being pulled off)
            val toX = wv.width.toFloat() * (if (goBack) 1f else -1f)
            snap.animate()
                .translationX(toX)
                .setDuration(300)
                .setInterpolator(DecelerateInterpolator(1.8f))
                .withEndAction { cont.removeView(snap); bmp.recycle() }
                .start()
        } catch (_: Exception) {
            // Fallback: just navigate
            if (goBack) wv.goBack() else wv.goForward()
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration (per tab)
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: ScrollAwareWebView) {
        wv.isFocusable = true; wv.isFocusableInTouchMode = true

        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            userAgentString = MOBILE_UA; loadWithOverviewMode = true; useWideViewPort = true
            allowFileAccess = true       // needed for file:// offline pages
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.addJavascriptInterface(WebKeyboardBridge(wv), "Android")
        wv.addJavascriptInterface(SpeedDialBridge(), "SpeedDial")
        wv.onWebInputFocused = { showKeyboardFor(wv) }
        wv.onDebugEvent = { msg -> dbg(msg) }

        // Throttled scroll → FAB behaviour
        wv.onScrollCallback = { dy ->
            val now = System.currentTimeMillis()
            if (now - lastScrollMs > 40) {
                lastScrollMs = now
                if (!urlBarVisible && fabBehavior == 0)
                    if (dy > 8) hideToggleFab() else if (dy < -8) showToggleFab(true)
            }
        }

        // ── Download listener ────────────────────────────────────────
        wv.setDownloadListener { url, ua, contentDisposition, mimeType, _ ->
            try {
                val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", ua)
                    addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    setTitle(filename)
                    setDescription("Downloading via Browser")
                }
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading $filename…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String?, fav: Bitmap?) {
                pageProgress.visibility = View.VISIBLE; pageProgress.progress = 0
                val tab = tabs.find { it.webView === v }
                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true; urlInput.setText("Home")
                    tab?.url = ""; tab?.title = "Home"
                } else {
                    isOnHomePage = false
                    currentHost = try { java.net.URI(url).host?.removePrefix("www.") } catch(_:Exception){null}
                    urlInput.setText(url); tab?.url = url
                }
                syncNavButtons()
            }
            override fun onPageFinished(v: WebView, url: String?) {
                pageProgress.visibility = View.GONE
                val tab = tabs.find { it.webView === v }
                tab?.title = v.title ?: ""; tab?.url = url ?: ""
                v.evaluateJavascript("""(function(){if(window.__kbl)return;window.__kbl=true;
                  function isEd(el){if(!el||!el.tagName)return false;var t=el.tagName.toUpperCase();
                    if(t==='INPUT'){var ty=(el.getAttribute('type')||'text').toLowerCase();
                      return['checkbox','radio','submit','button','file','image','reset','hidden','range','color'].indexOf(ty)<0;}
                    if(t==='TEXTAREA')return true;
                    var r=(el.getAttribute('role')||'').toLowerCase();
                    if(r==='textbox'||r==='searchbox'||r==='combobox')return true;
                    var c=el.getAttribute('contenteditable');return c!==null&&c!=='false'||el.isContentEditable;}
                  function chk(e){var el=e.target;for(var i=0;i<5&&el;i++,el=el.parentElement){
                    if(isEd(el)){if(typeof Android!=='undefined')Android.onInputFocused();return;}}}
                  document.addEventListener('focusin',chk,true);})();""", null)
                if (url == null || url.startsWith("data:")) { isOnHomePage = true; urlInput.setText("Home") }
                else { isOnHomePage = false; urlInput.setText(url) }
                syncNavButtons()
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(r, currentHost)) return AdBlocker.emptyResponse()
                if (dataSaverLevel > 0 && AdBlocker.shouldBlockForDataSaver(r, currentHost, dataSaverLevel)) return AdBlocker.emptyResponse()
                return null
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (p < 100) { pageProgress.visibility = View.VISIBLE; pageProgress.progress = p }
                else pageProgress.postDelayed({ pageProgress.visibility = View.GONE }, 200)
            }
            override fun onReceivedTitle(v: WebView, t: String?) { tabs.find { it.webView === v }?.title = t ?: "" }

            // ── File upload chooser ──────────────────────────────────
            override fun onShowFileChooser(
                v: WebView, callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)   // cancel any pending
                fileUploadCallback = callback
                val types = params.acceptTypes
                    ?.filter { it.isNotBlank() }
                    ?.toTypedArray()
                    ?.takeIf { it.isNotEmpty() }
                    ?: arrayOf("*/*")
                try { filePickerLauncher.launch(types) }
                catch (_: Exception) { fileUploadCallback = null; return false }
                return true
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // JS Bridges
    // ══════════════════════════════════════════════════════════════════

    inner class WebKeyboardBridge(private val wv: ScrollAwareWebView) {
        @JavascriptInterface
        fun onInputFocused() = runOnUiThread {
            webInputFocused = true
            wv.removeCallbacks(resetWebInputFocused)
            wv.postDelayed({ showKeyboardFor(wv) }, 200)
        }
    }

    inner class SpeedDialBridge {
        @JavascriptInterface fun get()  = prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL
        @JavascriptInterface fun save(json: String) = prefs.edit().putString("speed_dial", json).apply()
        @JavascriptInterface fun openAddDialog() = runOnUiThread { showNativeAddSpeedDialDialog() }
    }

    // ══════════════════════════════════════════════════════════════════
    // Native "Add to Speed Dial" dialog (no keyboard-in-webview issue)
    // ══════════════════════════════════════════════════════════════════

    private fun showNativeAddSpeedDialDialog(prefillUrl: String = "", prefillName: String = "") {
        val dp = resources.displayMetrics.density
        val cont = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(),(12*dp).toInt(),(20*dp).toInt(),(4*dp).toInt())
        }
        fun label(t: String) = TextView(this).apply { text=t; textSize=11f; setTextColor(Color.parseColor("#99FFFFFF"))
            setPadding(0,(4*dp).toInt(),0,(2*dp).toInt()) }
        val urlEt = EditText(this).apply {
            hint="https://example.com"; setText(prefillUrl); setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val nameEt = EditText(this).apply {
            hint="Name"; setText(prefillName); setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        // Auto-fill name from URL
        urlEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (nameEt.text.isBlank()) try {
                    var u = s.toString(); if (!u.startsWith("http")) u = "https://$u"
                    val h = java.net.URI(u).host?.removePrefix("www.")?.split(".")?.first() ?: return
                    nameEt.setText(h.replaceFirstChar { it.uppercase() })
                } catch (_: Exception) {}
            }
        })
        cont.addView(label("URL")); cont.addView(urlEt)
        cont.addView(label("Name")); cont.addView(nameEt)
        AlertDialog.Builder(this).setTitle("Add to Speed Dial").setView(cont)
            .setPositiveButton("Add") { _, _ ->
                var url = urlEt.text.toString().trim()
                val name = nameEt.text.toString().trim().ifBlank { "Site" }
                if (url.isNotEmpty()) {
                    if (!url.startsWith("http")) url = "https://$url"
                    addToSpeedDial(url, name)
                }
            }
            .setNegativeButton("Cancel", null).show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Speed dial helpers
    // ══════════════════════════════════════════════════════════════════

    private fun addToSpeedDial(url: String, name: String) {
        val arr = try { JSONArray(prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL) }
                  catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length())
            if (arr.getJSONObject(i).optString("url") == url) {
                Toast.makeText(this,"Already in Speed Dial",Toast.LENGTH_SHORT).show(); return }
        arr.put(JSONObject().put("url", url).put("name", name))
        prefs.edit().putString("speed_dial", arr.toString()).apply()
        Toast.makeText(this,"Added: $name",Toast.LENGTH_SHORT).show()
        tabs.forEach { t ->
            val u = t.webView.url ?: ""
            if (u.startsWith("data:") || u.startsWith("https://home.local"))
                t.webView.evaluateJavascript("if(typeof refreshSpeedDial==='function')refreshSpeedDial()", null)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Offline save
    // ══════════════════════════════════════════════════════════════════

    private fun savePageOffline() {
        val dir = File(filesDir, "offline").also { it.mkdirs() }
        val safe = (webView.title ?: "page").replace(Regex("[^a-zA-Z0-9 _-]"),"").trim().take(30).ifBlank{"page"}
        val file = File(dir, "${System.currentTimeMillis()}_$safe.mht")
        @Suppress("DEPRECATION")
        webView.saveWebArchive(file.absolutePath, false) { path ->
            runOnUiThread {
                if (path != null) Toast.makeText(this,"Saved: $safe",Toast.LENGTH_SHORT).show()
                else Toast.makeText(this,"Save failed",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSavedPages() {
        val files = File(filesDir,"offline").listFiles()?.sortedByDescending{it.lastModified()} ?: emptyList()
        if (files.isEmpty()) { Toast.makeText(this,"No saved pages",Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("Saved Pages")
            .setItems(files.map { it.name.substringAfter("_").removeSuffix(".mht") }.toTypedArray()) { _, i ->
                webView.loadUrl("file://${files[i].absolutePath}"); hideUrlBar()
            }
            .setNegativeButton("Close", null).show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Home / nav
    // ══════════════════════════════════════════════════════════════════

    private fun loadHomePage(wv: ScrollAwareWebView = webView) {
        isOnHomePage = true; urlInput.setText("Home")
        wv.loadDataWithBaseURL("https://home.local/", buildHomeHtml(), "text/html", "UTF-8", null)
    }

    private fun applyDataSaverSettings() {
        webView.settings.cacheMode = if (dataSaverLevel >= 3) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
        webView.settings.loadsImagesAutomatically = dataSaverLevel < 4
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    private fun navigateTo(raw: String) {
        val s = raw.trim(); if (s.isEmpty() || s == "Home") return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ") -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url); hideUrlBar()
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() { if (urlBarVisible) hideUrlBar() else showUrlBar() }

    private fun showUrlBar() {
        if (urlBarVisible) return; urlBarVisible = true
        if (fabBehavior != 3) showToggleFab(false)
        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(230).setInterpolator(DecelerateInterpolator())
            .withEndAction { urlBar.setLayerType(View.LAYER_TYPE_NONE, null) }.start()
        if (isOnHomePage) urlInput.setText("")
        urlInput.post { urlInput.isFocusable=true; urlInput.isFocusableInTouchMode=true
            urlInput.requestFocus(); urlInput.selectAll() }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return; urlBarVisible = false
        dismissKeyboard(); urlInput.clearFocus()
        urlInput.isFocusable=false; urlInput.isFocusableInTouchMode=false
        webView.requestFocus()
        if (isOnHomePage) urlInput.setText("Home")
        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.animate().translationY(-urlBar.height.toFloat()).setDuration(190)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { urlBar.visibility=View.INVISIBLE; urlBar.setLayerType(View.LAYER_TYPE_NONE,null) }.start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Globe FAB
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible || fabBehavior == 3) return; toggleVisible = true
        if (animate) btnToggle.animate().alpha(1f).translationY(0f).setDuration(190).start()
        else { btnToggle.alpha=1f; btnToggle.translationY=0f }
    }
    private fun hideToggleFab() {
        if (!toggleVisible || fabBehavior == 2) return; toggleVisible = false
        btnToggle.animate().alpha(0f).translationY(22f * resources.displayMetrics.density).setDuration(170).start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Tap zone
    // ══════════════════════════════════════════════════════════════════

    private fun isTapInZone(x: Float, y: Float): Boolean {
        val w=webView.width.toFloat(); val h=webView.height.toFloat()
        return when(tapZone){
            0->y<h*0.13f; 1->y>h*0.78f&&x<w*0.40f; 2->y>h*0.78f&&x>w*0.28f&&x<w*0.72f; 3->y>h*0.78f&&x>w*0.60f; else->false }
    }

    // ══════════════════════════════════════════════════════════════════
    // Keyboard
    // ══════════════════════════════════════════════════════════════════

    private fun showKeyboardFor(wv: ScrollAwareWebView) {
        webInputFocused = true; wv.removeCallbacks(resetWebInputFocused)
        if (!wv.hasFocus()) wv.requestFocusFromTouch()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val ok = imm.showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT)
        if (!ok) wv.postDelayed({
            val ok2 = imm.showSoftInput(wv, InputMethodManager.SHOW_FORCED)
            if (!ok2) WindowInsetsControllerCompat(window,wv).show(WindowInsetsCompat.Type.ime())
        }, 150)
    }
    private fun dismissKeyboard() {
        WindowInsetsControllerCompat(window,window.decorView).hide(WindowInsetsCompat.Type.ime())
    }

    // ══════════════════════════════════════════════════════════════════
    // Back button
    // ══════════════════════════════════════════════════════════════════

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            !isOnHomePage       -> loadHomePage()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding((20*dp).toInt(),(12*dp).toInt(),(20*dp).toInt(),(8*dp).toInt()) }
        fun div() = View(this).apply { setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1) }
        fun toggle(label:String,desc:String,checked:Boolean,fn:(Boolean)->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL
                gravity=android.view.Gravity.CENTER_VERTICAL;setPadding(0,(10*dp).toInt(),0,(10*dp).toInt())}
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL
                layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)}
            box.addView(TextView(this).apply{text=label;textSize=15f;setTextColor(Color.WHITE)})
            box.addView(TextView(this).apply{text=desc;textSize=12f;setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0,(2*dp).toInt(),0,0)})
            val sw=Switch(this).apply{isChecked=checked;setOnCheckedChangeListener{_,on->fn(on)}}
            row.addView(box);row.addView(sw);root.addView(row);root.addView(div())}
        fun chevron(label:String,value:()->String,fn:(TextView)->Unit){
            val rv=TypedValue();theme.resolveAttribute(android.R.attr.selectableItemBackground,rv,true)
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL
                gravity=android.view.Gravity.CENTER_VERTICAL;setPadding(0,(10*dp).toInt(),0,(10*dp).toInt())
                isClickable=true;isFocusable=true;if(rv.resourceId!=0)setBackgroundResource(rv.resourceId)}
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL
                layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f);isClickable=false}
            box.addView(TextView(this).apply{text=label;textSize=15f;setTextColor(Color.WHITE)})
            val vl=TextView(this).apply{text=value();textSize=12f;setTextColor(Color.parseColor("#4FC3F7"))
                setPadding(0,(2*dp).toInt(),0,0)}
            box.addView(vl);row.addView(box)
            row.addView(TextView(this).apply{text="›";textSize=22f;setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding((8*dp).toInt(),0,0,0)})
            row.setOnClickListener{fn(vl)};root.addView(row);root.addView(div())}
        fun action(label:String,desc:String,fn:()->Unit){
            val rv=TypedValue();theme.resolveAttribute(android.R.attr.selectableItemBackground,rv,true)
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL
                setPadding(0,(10*dp).toInt(),0,(10*dp).toInt())
                isClickable=true;isFocusable=true;if(rv.resourceId!=0)setBackgroundResource(rv.resourceId)}
            row.addView(TextView(this).apply{text=label;textSize=15f;setTextColor(Color.parseColor("#4FC3F7"))})
            row.addView(TextView(this).apply{text=desc;textSize=12f;setTextColor(Color.parseColor("#66FFFFFF"))
                setPadding(0,(2*dp).toInt(),0,0)})
            row.setOnClickListener{fn()};root.addView(row);root.addView(div())}

        toggle("Ad Blocker","Block ads and trackers",adBlockEnabled){on->adBlockEnabled=on;saveSettings();if(!isOnHomePage)webView.reload()}
        val dsS=arrayOf("Off","High","Medium","Low","No Images")
        chevron("Data Saver",{dsS[dataSaverLevel]}){vl->
            val ci=intArrayOf(dataSaverLevel)
            AlertDialog.Builder(this).setTitle("Data Saver")
                .setSingleChoiceItems(DATA_SAVER_LABELS,dataSaverLevel){_,w->ci[0]=w}
                .setPositiveButton("Apply"){_,_->dataSaverLevel=ci[0];vl.text=dsS[dataSaverLevel]
                    applyDataSaverSettings();saveSettings();if(!isOnHomePage)webView.reload()}
                .setNegativeButton("Cancel",null).show().styleDialog()}
        chevron("URL Bar Access",{FAB_BEHAVIOR_LABELS[fabBehavior]}){vl->
            val ci=intArrayOf(fabBehavior)
            AlertDialog.Builder(this).setTitle("URL Bar Access")
                .setSingleChoiceItems(FAB_BEHAVIOR_LABELS,fabBehavior){_,w->ci[0]=w}
                .setPositiveButton("Apply"){_,_->fabBehavior=ci[0];vl.text=FAB_BEHAVIOR_LABELS[fabBehavior]
                    saveSettings();when(fabBehavior){2->showToggleFab(true);3->hideToggleFab()}}
                .setNegativeButton("Cancel",null).show().styleDialog()}
        if(fabBehavior==3) chevron("  Tap Zone",{TAP_ZONE_SHORT[tapZone]}){vl->
            val ci=intArrayOf(tapZone)
            AlertDialog.Builder(this).setTitle("Tap Zone")
                .setSingleChoiceItems(TAP_ZONE_LABELS,tapZone){_,w->ci[0]=w}
                .setPositiveButton("Apply"){_,_->tapZone=ci[0];vl.text=TAP_ZONE_SHORT[tapZone];saveSettings()}
                .setNegativeButton("Cancel",null).show().styleDialog()}
        toggle("Swipe to Navigate","Left edge→forward  •  right edge→back",swipeNavEnabled){on->swipeNavEnabled=on;saveSettings()}
        if(!isOnHomePage) action("Save Page Offline","Save as MHTML for offline viewing"){savePageOffline()}
        action("Saved Pages","Open previously saved pages"){showSavedPages()}
        toggle("Debug Overlay","Live event log",debugOverlayVisible){on->debugOverlayVisible=on
            debugOverlayView.visibility=if(on)View.VISIBLE else View.GONE}

        val sv=ScrollView(this).also{it.addView(root)}
        AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done",null).show().styleDialog()
    }

    // ── Debug ──────────────────────────────────────────────────────────
    private val debugLog = ArrayDeque<String>()
    private fun dbg(msg: String) {
        android.util.Log.d("BrowserApp", msg)
        if (!debugOverlayVisible) return
        val ts = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date())
        runOnUiThread {
            debugLog.addFirst("$ts  $msg"); if (debugLog.size > 8) debugLog.removeLast()
            debugOverlayView.text = debugLog.joinToString("\n")
        }
    }
    private fun AlertDialog.styleDialog(): AlertDialog {
        window?.setBackgroundDrawableResource(android.R.color.background_dark)
        getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#4FC3F7"))
        getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#99FFFFFF"))
        return this
    }
}
