# Tetris AI

A from-scratch Android Tetris built in Kotlin + Jetpack Compose, with three modes:

- **Play** — normal Tetris with on-screen controls (move, rotate, soft/hard drop),
  gravity that speeds up with level.
- **Watch AI Play** — an AI plays live using a heuristic board evaluator
  (aggregate height, holes, bumpiness, complete lines). It searches every
  rotation × column for the current piece, simulates the drop, and picks the
  best-scoring placement.
- **Train AI** — a genetic algorithm evolves the AI's own evaluation weights.
  Each generation, a population of 12 candidate strategies plays a couple of
  headless games; the fittest breed the next generation via crossover +
  mutation. Progress (best/average fitness per generation) shows live, and the
  winning weights are saved automatically — "Watch AI Play" always uses the
  most recently trained weights.

## Project layout

```
app/src/main/java/com/steve/tetris/
  game/     TetrisGame.kt, Tetromino.kt      — engine, framework-free
  ai/       TetrisAI.kt, GeneticTrainer.kt,
            HeuristicWeights.kt              — move search + evolution
  storage/  WeightsStorage.kt                — persists trained weights
  ui/       AppRoot.kt, HomeScreen.kt,
            PlayScreen.kt, AIScreen.kt,
            TrainScreen.kt, BoardView.kt     — Compose UI
```

## Building

Push this zip to the `uploads/` folder of your Build-APK-workflow repo — the
existing CI pipeline unzips it, finds `settings.gradle`, and builds a debug
APK (no signing secrets required).

## Notes / possible follow-ups

- No custom app icon or edge-to-edge/cutout handling yet — kept out of scope
  for this first version. Easy to add later the same way it was done for the
  emulator app.
- Training defaults (12 individuals, 2 games each, up to 250 pieces/game) are
  tuned for a reasonably quick generation on mid-range hardware. If it feels
  slow on your device, lower "Generations" in the Train AI screen, or edit
  `GeneticTrainer`'s constructor defaults.
- Rotation uses simple left/right wall-kicks, not full SRS — good enough for
  solid play, not tournament-accurate.
