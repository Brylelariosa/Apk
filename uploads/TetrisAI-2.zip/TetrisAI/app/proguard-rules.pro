# Shrink (remove unused code) but do NOT obfuscate. Steve builds entirely
# through CI with no local Android Studio / retrace tooling, so keeping real
# class and method names means logcat output stays directly readable without
# needing to match it against a mapping.txt that never leaves the runner.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
