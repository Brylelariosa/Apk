package com.steve.tetris.ai

import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.TetrisGame
import kotlin.random.Random

private data class Individual(val weights: HeuristicWeights, var fitness: Double = 0.0)

data class GenerationResult(
    val generation: Int,
    val bestFitness: Double,
    val averageFitness: Double,
    val bestWeights: HeuristicWeights
)

/**
 * Evolves a population of heuristic weight vectors. Each individual plays a
 * few headless (unrendered) games; the fittest survive and breed the next
 * generation via crossover + mutation. Call runGeneration() repeatedly from
 * a background dispatcher — each call advances the population by one
 * generation and returns its stats, so the UI can show live progress.
 */
class GeneticTrainer(
    private val populationSize: Int = 12,
    private val gamesPerIndividual: Int = 2,
    private val maxPiecesPerGame: Int = 250,
    private val mutationRate: Double = 0.15,
    private val random: Random = Random.Default
) {
    private var population: MutableList<Individual> = MutableList(populationSize) {
        Individual(randomWeights())
    }

    private fun randomWeights(): HeuristicWeights = HeuristicWeights(
        aggregateHeight = random.nextDouble(-1.0, 0.0),
        completeLines = random.nextDouble(0.0, 1.0),
        holes = random.nextDouble(-1.0, 0.0),
        bumpiness = random.nextDouble(-1.0, 0.0)
    )

    fun runGeneration(genNumber: Int): GenerationResult {
        for (ind in population) {
            var total = 0.0
            repeat(gamesPerIndividual) { total += simulateGame(ind.weights) }
            ind.fitness = total / gamesPerIndividual
        }
        population.sortByDescending { it.fitness }

        val best = population.first()
        val avg = population.map { it.fitness }.average()

        population = evolve(population)

        return GenerationResult(genNumber, best.fitness, avg, best.weights)
    }

    private fun simulateGame(weights: HeuristicWeights): Double {
        val game = TetrisGame(random)
        var pieces = 0
        while (!game.isGameOver && pieces < maxPiecesPerGame) {
            val move = TetrisAI.bestMove(game.copyBoard(), game.current.type, weights)
            if (move != null) {
                var rotAttempts = 0
                while (game.current.rotation != move.rotation && rotAttempts < 4) {
                    game.rotate()
                    rotAttempts++
                }
                var guard = 0
                while (game.current.col < move.col && guard < BOARD_COLS) {
                    game.moveRight(); guard++
                }
                guard = 0
                while (game.current.col > move.col && guard < BOARD_COLS) {
                    game.moveLeft(); guard++
                }
            }
            game.hardDrop()
            pieces++
        }
        return game.score.toDouble() + game.linesCleared * 10.0
    }

    private fun evolve(sorted: List<Individual>): MutableList<Individual> {
        val eliteCount = maxOf(1, populationSize / 6)
        val children = mutableListOf<Individual>()
        children.addAll(sorted.take(eliteCount).map { Individual(it.weights) })
        while (children.size < populationSize) {
            val parentA = tournamentPick(sorted)
            val parentB = tournamentPick(sorted)
            val childWeights = crossover(parentA.weights, parentB.weights)
            children.add(Individual(mutate(childWeights)))
        }
        return children
    }

    private fun tournamentPick(sorted: List<Individual>): Individual {
        val a = sorted[random.nextInt(sorted.size)]
        val b = sorted[random.nextInt(sorted.size)]
        return if (a.fitness >= b.fitness) a else b
    }

    private fun crossover(a: HeuristicWeights, b: HeuristicWeights): HeuristicWeights {
        val aArr = a.asArray()
        val bArr = b.asArray()
        val childArr = DoubleArray(aArr.size) { i -> if (random.nextBoolean()) aArr[i] else bArr[i] }
        return HeuristicWeights.fromArray(childArr)
    }

    private fun mutate(w: HeuristicWeights): HeuristicWeights {
        val arr = w.asArray()
        for (i in arr.indices) {
            if (random.nextDouble() < mutationRate) {
                arr[i] += random.nextDouble(-0.2, 0.2)
            }
        }
        return HeuristicWeights.fromArray(arr)
    }
}
