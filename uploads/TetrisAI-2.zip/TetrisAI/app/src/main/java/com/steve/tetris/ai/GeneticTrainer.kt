package com.steve.tetris.ai

import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.TetrisGame
import kotlin.random.Random

private data class Individual(val weights: HeuristicWeights, var fitness: Double = 0.0)

data class GenerationResult(
    val generation: Int,
    val bestFitness: Double,
    val averageFitness: Double,
    val bestWeights: HeuristicWeights,
    // Best individual seen across ALL generations so far, not just this one -
    // fitness is noisy (random piece sequences), so a single bad generation
    // shouldn't be able to overwrite a genuinely better strategy found earlier.
    val bestEverFitness: Double,
    val bestEverWeights: HeuristicWeights,
    // Top individuals of this generation, for showing several distinct
    // strategies from the population playing at once.
    val topWeights: List<HeuristicWeights>
)

/**
 * Evolves a population of heuristic weight vectors. Each individual plays a
 * few headless (unrendered) games; the fittest survive and breed the next
 * generation via crossover + mutation. Call runGeneration() repeatedly from
 * a background dispatcher — each call advances the population by one
 * generation and returns its stats, so the UI can show live progress.
 */
class GeneticTrainer(
    private val populationSize: Int = 16,
    private val gamesPerIndividual: Int = 2,
    private val maxPiecesPerGame: Int = 300,
    private val mutationRate: Double = 0.15,
    private val showcaseCount: Int = 4,
    private val random: Random = Random.Default
) {
    // Each feature has a fixed, meaningful sign (e.g. height must always
    // count AGAINST a placement, never for it). Unbounded mutation is a
    // random walk - left unchecked, over many generations a weight can drift
    // across zero and flip sign, e.g. "tall is bad" quietly becoming
    // "tall is good". That produces exactly the "builds a tower and tops
    // out" failure this was showing. Every weight gets clamped back into its
    // valid range after every mutation.
    private val bounds = arrayOf(
        -2.0..-0.02,  // aggregateHeight: must stay negative
        0.02..2.0,    // completeLines: must stay positive
        -2.0..-0.02,  // holes: must stay negative
        -2.0..-0.02,  // bumpiness: must stay negative
        -2.0..-0.02,  // rowTransitions: must stay negative
        -2.0..-0.02   // colTransitions: must stay negative
    )
    private var population: MutableList<Individual> = MutableList(populationSize) {
        Individual(randomWeights())
    }

    private var bestEverWeights = HeuristicWeights()
    private var bestEverFitness = Double.NEGATIVE_INFINITY

    private fun randomWeights(): HeuristicWeights = HeuristicWeights(
        aggregateHeight = random.nextDouble(bounds[0].start, bounds[0].endInclusive),
        completeLines = random.nextDouble(bounds[1].start, bounds[1].endInclusive),
        holes = random.nextDouble(bounds[2].start, bounds[2].endInclusive),
        bumpiness = random.nextDouble(bounds[3].start, bounds[3].endInclusive),
        rowTransitions = random.nextDouble(bounds[4].start, bounds[4].endInclusive),
        colTransitions = random.nextDouble(bounds[5].start, bounds[5].endInclusive)
    )

    fun runGeneration(genNumber: Int): GenerationResult {
        for (ind in population) {
            var total = 0.0
            repeat(gamesPerIndividual) { total += simulateGame(ind.weights) }
            ind.fitness = total / gamesPerIndividual
        }
        population.sortByDescending { it.fitness }

        val best = population.first()
        val avg = population.map { it.fitness }.average()
        val top = population.take(showcaseCount).map { it.weights }

        if (best.fitness > bestEverFitness) {
            bestEverFitness = best.fitness
            bestEverWeights = best.weights
        }

        population = evolve(population)

        return GenerationResult(genNumber, best.fitness, avg, best.weights, bestEverFitness, bestEverWeights, top)
    }

    private fun simulateGame(weights: HeuristicWeights): Double {
        val game = TetrisGame(random)
        var pieces = 0
        while (!game.isGameOver && pieces < maxPiecesPerGame) {
            val move = TetrisAI.bestMove(game.copyBoard(), game.current.type, weights)
            if (move != null) {
                var rotAttempts = 0
                while (game.current.rotation != move.rotation && rotAttempts < 4) {
                    game.rotate()
                    rotAttempts++
                }
                var guard = 0
                while (game.current.col < move.col && guard < BOARD_COLS) {
                    game.moveRight(); guard++
                }
                guard = 0
                while (game.current.col > move.col && guard < BOARD_COLS) {
                    game.moveLeft(); guard++
                }
            }
            game.hardDrop()
            pieces++
        }
        // Score + a per-line bonus (score alone under-rewards early clears at
        // level 1) + a small per-piece survival bonus, since a population of
        // random weights often just tops out almost immediately and score/
        // lines alone don't distinguish "died in 5 pieces" from "died in 80".
        return game.score.toDouble() + game.linesCleared * 10.0 + pieces * 0.5
    }

    private fun evolve(sorted: List<Individual>): MutableList<Individual> {
        val champion = sorted.first()
        val children = mutableListOf<Individual>()

        // Keep the champion exactly as-is - guarantees this generation's best
        // strategy is never lost, only refined.
        children.add(Individual(champion.weights))

        // "Get the highest score, multiply them, train again": most of the
        // next generation is mutated clones of the CURRENT BEST, not just
        // broad crossover across the whole population. Most clones get a
        // small refining mutation; a minority get a much bigger jump so the
        // population doesn't just converge and stall around one local optimum.
        val championCloneCount = (populationSize * 0.5).toInt()
        repeat(championCloneCount) { i ->
            val strength = if (i % 4 == 0) 0.5 else 0.15
            children.add(Individual(mutate(champion.weights, strength)))
        }

        // A couple more unmutated elites, for stability.
        val eliteCount = maxOf(1, populationSize / 8)
        children.addAll(sorted.drop(1).take(eliteCount).map { Individual(it.weights) })

        // The rest: crossover across the wider population, for exploration
        // (escapes local optima the champion-cloning alone can't reach).
        while (children.size < populationSize) {
            val parentA = tournamentPick(sorted)
            val parentB = tournamentPick(sorted)
            children.add(Individual(mutate(crossover(parentA.weights, parentB.weights))))
        }
        return children
    }

    private fun tournamentPick(sorted: List<Individual>): Individual {
        val a = sorted[random.nextInt(sorted.size)]
        val b = sorted[random.nextInt(sorted.size)]
        return if (a.fitness >= b.fitness) a else b
    }

    private fun crossover(a: HeuristicWeights, b: HeuristicWeights): HeuristicWeights {
        val aArr = a.asArray()
        val bArr = b.asArray()
        val childArr = DoubleArray(aArr.size) { i -> if (random.nextBoolean()) aArr[i] else bArr[i] }
        return HeuristicWeights.fromArray(childArr)
    }

    private fun mutate(w: HeuristicWeights, strength: Double = 0.2): HeuristicWeights {
        val arr = w.asArray()
        for (i in arr.indices) {
            if (random.nextDouble() < mutationRate) {
                arr[i] = (arr[i] + random.nextDouble(-strength, strength)).coerceIn(bounds[i])
            }
        }
        return HeuristicWeights.fromArray(arr)
    }
}
