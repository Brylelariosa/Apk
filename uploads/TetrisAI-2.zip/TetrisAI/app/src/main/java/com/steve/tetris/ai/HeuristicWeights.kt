package com.steve.tetris.ai

/**
 * Weights for the board-evaluation function the AI uses to score a potential
 * placement. Defaults are the well-known "starter" values popularized by
 * public Tetris-bot writeups (aggregate height / complete lines / holes /
 * bumpiness) — a reasonable seed before the genetic trainer improves on them.
 */
data class HeuristicWeights(
    val aggregateHeight: Double = -0.510066,
    val completeLines: Double = 0.760666,
    val holes: Double = -0.35663,
    val bumpiness: Double = -0.184483
) {
    fun asArray(): DoubleArray = doubleArrayOf(aggregateHeight, completeLines, holes, bumpiness)

    companion object {
        fun fromArray(values: DoubleArray) = HeuristicWeights(values[0], values[1], values[2], values[3])
    }
}
