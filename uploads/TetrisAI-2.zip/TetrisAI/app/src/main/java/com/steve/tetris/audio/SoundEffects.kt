package com.steve.tetris.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * All sound effects are synthesized sine-wave tones - no bundled audio files.
 *
 * Two problems in earlier versions: (1) low frequencies (~140Hz) distort or
 * disappear on small phone speakers, which reproduce ~300Hz-2kHz far more
 * cleanly - shifted everything up into that range. (2) During fast AI
 * playback, every lock/rotate spawned its own independent AudioTrack with no
 * coordination, so dozens of overlapping tones piled up into noise. Blips
 * are now debounced (skip if one just played), and melodic sequences
 * (line clear / game over) cancel any previous one instead of layering.
 */
class SoundEffects {
    private val sampleRate = 44100
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var lastRotateAt = 0L
    private var lastLockAt = 0L
    private var melodicJob: Job? = null

    fun rotate() {
        val now = System.currentTimeMillis()
        if (now - lastRotateAt < 45L) return
        lastRotateAt = now
        playTone(880.0, 18, volume = 0.15f)
    }

    fun lock() {
        val now = System.currentTimeMillis()
        if (now - lastLockAt < 60L) return
        lastLockAt = now
        playTone(320.0, 35, volume = 0.18f)
    }

    fun gameOver() {
        melodicJob?.cancel()
        melodicJob = playSequence(listOf(440.0, 392.0, 330.0, 262.0), 150, volume = 0.2f)
    }

    /** [combo] is the resulting combo count (1 = first clear, 2 = second in a row, ...). */
    fun lineClear(combo: Int) {
        // C5 E5 G5 C6 E6 - a clean ascending major arpeggio; longer combos add notes.
        val notes = listOf(523.25, 659.25, 783.99, 1046.50, 1318.51)
        val noteCount = (1 + combo).coerceIn(2, notes.size)
        melodicJob?.cancel()
        melodicJob = playSequence(notes.take(noteCount), 80, volume = 0.2f)
    }

    private fun playTone(freqHz: Double, durationMs: Int, volume: Float) {
        scope.launch { playOne(freqHz, durationMs, volume) }
    }

    private fun playSequence(freqsHz: List<Double>, noteDurationMs: Int, volume: Float): Job =
        scope.launch {
            for (f in freqsHz) {
                playOne(f, noteDurationMs, volume)
                delay((noteDurationMs * 0.7).toLong())
            }
        }

    private suspend fun playOne(freqHz: Double, durationMs: Int, volume: Float) {
        var track: AudioTrack? = null
        try {
            track = buildTone(freqHz, durationMs, volume)
            track.play()
            delay(durationMs.toLong() + 20L)
        } catch (e: Exception) {
            // Some devices/emulators have no usable audio output - fail silently.
        } finally {
            // Runs even on cancellation (e.g. a new line-clear cutting this
            // one off), so a superseded note stops immediately instead of
            // trailing into the next sound.
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
        }
    }

    private fun buildTone(freqHz: Double, durationMs: Int, volume: Float): AudioTrack {
        val sampleCount = (sampleRate * durationMs / 1000.0).toInt().coerceAtLeast(1)
        val samples = ShortArray(sampleCount)
        val fadeCount = (sampleCount * 0.12).toInt().coerceAtLeast(1)
        for (i in 0 until sampleCount) {
            val angle = 2.0 * PI * i * freqHz / sampleRate
            val fadeIn = (i.toDouble() / fadeCount).coerceIn(0.0, 1.0)
            val fadeOut = ((sampleCount - i).toDouble() / fadeCount).coerceIn(0.0, 1.0)
            val envelope = minOf(fadeIn, fadeOut, 1.0)
            samples[i] = (sin(angle) * envelope * volume * Short.MAX_VALUE).toInt().toShort()
        }
        val bytesNeeded = sampleCount * 2
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = maxOf(bytesNeeded, minBuffer)

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }

    fun release() {
        scope.cancel()
    }
}
