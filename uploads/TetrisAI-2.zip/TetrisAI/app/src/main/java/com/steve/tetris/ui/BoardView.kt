package com.steve.tetris.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.steve.tetris.game.ActivePiece
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.Tetromino

private val pieceColors = listOf(
    Color(0xFF1E1E1E), // 0 - unused (empty cells aren't drawn)
    Color(0xFF00BCD4), // I - cyan
    Color(0xFFFFC107), // O - yellow
    Color(0xFF9C27B0), // T - purple
    Color(0xFF4CAF50), // S - green
    Color(0xFFF44336), // Z - red
    Color(0xFF3F51B5), // J - blue
    Color(0xFFFF9800)  // L - orange
)

@Composable
fun BoardView(board: Array<IntArray>, current: ActivePiece?, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(BOARD_COLS / BOARD_ROWS.toFloat())
    ) {
        val cellW = size.width / BOARD_COLS
        val cellH = size.height / BOARD_ROWS

        drawRect(color = Color(0xFF121212), size = size)

        for (r in 0 until BOARD_ROWS) {
            for (c in 0 until BOARD_COLS) {
                val value = board[r][c]
                if (value != 0) drawCell(r, c, cellW, cellH, pieceColors[value])
            }
        }

        current?.let { piece ->
            val color = pieceColors[Tetromino.colorIndex.getValue(piece.type)]
            piece.cells().forEach { (r, c) ->
                if (r in 0 until BOARD_ROWS && c in 0 until BOARD_COLS) {
                    drawCell(r, c, cellW, cellH, color)
                }
            }
        }

        for (c in 0..BOARD_COLS) {
            drawLine(
                color = Color(0x22FFFFFF),
                start = Offset(c * cellW, 0f),
                end = Offset(c * cellW, size.height)
            )
        }
        for (r in 0..BOARD_ROWS) {
            drawLine(
                color = Color(0x22FFFFFF),
                start = Offset(0f, r * cellH),
                end = Offset(size.width, r * cellH)
            )
        }
    }
}

private fun DrawScope.drawCell(r: Int, c: Int, cellW: Float, cellH: Float, color: Color) {
    drawRect(
        color = color,
        topLeft = Offset(c * cellW, r * cellH),
        size = Size(cellW - 1f, cellH - 1f)
    )
}
