package com.steve.tetris.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.steve.tetris.game.ActivePiece
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.Tetromino
import kotlin.random.Random

private const val BREAK_DURATION_MS = 220

private data class Fragment(
    val row: Int,
    val col: Int,
    val startXFrac: Float,   // starting position within the cell, 0..1
    val startYFrac: Float,
    val vx: Float,           // velocity in cell-widths per second
    val vy: Float,           // velocity in cell-heights per second (negative = up)
    val sizeFrac: Float,     // fragment size as a fraction of a cell
    val color: Color
)

@Composable
fun BoardView(
    board: Array<IntArray>,
    current: ActivePiece?,
    modifier: Modifier = Modifier,
    flashingRows: List<Int> = emptyList()
) {
    // When a line completes, its cells shatter into small fragments that pop
    // outward and fall, instead of the row just flashing flat - synced with
    // the freeze GameController holds before actually removing the row.
    var fragments by remember { mutableStateOf(emptyList<Fragment>()) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(flashingRows) {
        if (flashingRows.isNotEmpty()) {
            val spawned = mutableListOf<Fragment>()
            for (r in flashingRows) {
                for (c in 0 until BOARD_COLS) {
                    val color = pieceColors.getOrElse(board[r][c]) { Color.White }
                    repeat(3) {
                        spawned += Fragment(
                            row = r,
                            col = c,
                            startXFrac = 0.2f + Random.nextFloat() * 0.6f,
                            startYFrac = 0.2f + Random.nextFloat() * 0.6f,
                            vx = (Random.nextFloat() - 0.5f) * 5f,
                            vy = -(1.5f + Random.nextFloat() * 3.5f),
                            sizeFrac = 0.22f + Random.nextFloat() * 0.18f,
                            color = color
                        )
                    }
                }
            }
            fragments = spawned
            progress.snapTo(0f)
            progress.animateTo(1f, animationSpec = tween(BREAK_DURATION_MS, easing = LinearEasing))
            fragments = emptyList()
        }
    }

    Canvas(
        // matchHeightConstraintsFirst: size from the AVAILABLE HEIGHT, not full
        // width - keeps the board (and controls below it) on screen on any phone.
        modifier = modifier.aspectRatio(BOARD_COLS / BOARD_ROWS.toFloat(), matchHeightConstraintsFirst = true)
    ) {
        val cellW = size.width / BOARD_COLS
        val cellH = size.height / BOARD_ROWS

        drawRect(color = boardBackground, size = size)

        // Grid lines are drawn UNDER the pieces so solid pieces read as one
        // clean shape instead of being sliced into a checkerboard.
        for (c in 0..BOARD_COLS) {
            drawLine(
                color = Color(0x1FFFFFFF),
                start = Offset(c * cellW, 0f),
                end = Offset(c * cellW, size.height)
            )
        }
        for (r in 0..BOARD_ROWS) {
            drawLine(
                color = Color(0x1FFFFFFF),
                start = Offset(0f, r * cellH),
                end = Offset(size.width, r * cellH)
            )
        }

        val breaking = fragments.isNotEmpty()
        for (r in 0 until BOARD_ROWS) {
            if (breaking && r in flashingRows) continue // this row is shattering into fragments instead
            for (c in 0 until BOARD_COLS) {
                val value = board[r][c]
                if (value != 0) drawCell(r, c, cellW, cellH, pieceColors[value])
            }
        }

        current?.let { piece ->
            val color = pieceColors[Tetromino.colorIndex.getValue(piece.type)]
            piece.cells().forEach { (r, c) ->
                if (r in 0 until BOARD_ROWS && c in 0 until BOARD_COLS) {
                    drawCell(r, c, cellW, cellH, color)
                }
            }
        }

        if (breaking) {
            val t = progress.value * (BREAK_DURATION_MS / 1000f)
            val gravity = 9f // cell-heights per second^2 - tuned for a snappy little pop, not realistic physics
            val alpha = (1f - progress.value).coerceIn(0f, 1f)
            fragments.forEach { f ->
                val x = (f.col + f.startXFrac + f.vx * t) * cellW
                val y = (f.row + f.startYFrac + f.vy * t + 0.5f * gravity * t * t) * cellH
                val s = f.sizeFrac * cellW
                drawRect(
                    color = f.color.copy(alpha = alpha),
                    topLeft = Offset(x - s / 2f, y - s / 2f),
                    size = Size(s, s)
                )
            }
        }
    }
}

// Cells are drawn edge-to-edge (no shrink gap) so adjacent same-piece cells
// tile into one seamless shape rather than a checkerboard of tiny squares.
private fun DrawScope.drawCell(r: Int, c: Int, cellW: Float, cellH: Float, color: Color) {
    drawRect(
        color = color,
        topLeft = Offset(c * cellW, r * cellH),
        size = Size(cellW, cellH)
    )
}
