package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.steve.tetris.ai.GenerationResult
import com.steve.tetris.ai.GeneticTrainer
import com.steve.tetris.ai.HeuristicWeights
import com.steve.tetris.ai.TetrisAI
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.storage.WeightsStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TrainScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<GenerationResult>() }
    var isTraining by remember { mutableStateOf(false) }
    var totalGenerations by remember { mutableStateOf(20) }
    var showcase by remember { mutableStateOf(GameController()) }
    var showcaseLabel by remember { mutableStateOf("Untrained AI - watch it struggle") }
    val showcaseState = showcase.snapshot

    // Idle demo loop: before training starts (or once it finishes), keep
    // replaying the CURRENT weights on a loop so the board is never just
    // sitting empty - this is what "not trained yet" actually looks like.
    LaunchedEffect(isTraining) {
        if (!isTraining) {
            val weights = if (results.isEmpty()) HeuristicWeights() else results.last().bestWeights
            showcaseLabel = if (results.isEmpty()) "Untrained AI - watch it struggle" else "Trained AI (gen ${results.last().generation})"
            while (true) {
                showcase = GameController()
                playShowcase(showcase, weights)
                delay(500L)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back", color = accentColor) }
            Text("Train AI", style = MaterialTheme.typography.titleMedium, color = Color(0xFFE6E9EF))
        }

        Spacer(Modifier.height(8.dp))
        Text(showcaseLabel, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A93A3))
        Spacer(Modifier.height(6.dp))

        Box(
            modifier = Modifier.weight(2f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val boardModifier = Modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(14.dp))
            BoardView(board = showcaseState.board, current = showcaseState.current, modifier = boardModifier)
            LineClearFlash(eventId = showcaseState.clearEventId, modifier = boardModifier)
        }

        Spacer(Modifier.height(10.dp))
        Text("Generations: $totalGenerations", color = Color(0xFF8A93A3), style = MaterialTheme.typography.bodySmall)
        Slider(
            value = totalGenerations.toFloat(),
            onValueChange = { totalGenerations = it.toInt().coerceIn(5, 60) },
            valueRange = 5f..60f,
            enabled = !isTraining
        )
        Button(
            enabled = !isTraining,
            onClick = {
                results.clear()
                isTraining = true
                scope.launch {
                    val trainer = GeneticTrainer()
                    var lastBestWeights = HeuristicWeights()
                    for (gen in 1..totalGenerations) {
                        val result = withContext(Dispatchers.Default) { trainer.runGeneration(gen) }
                        results.add(result)
                        lastBestWeights = result.bestWeights
                        // Show this generation's best strategy actually playing.
                        showcaseLabel = "Gen $gen best (fitness ${"%.0f".format(result.bestFitness)})"
                        showcase = GameController()
                        playShowcase(showcase, lastBestWeights)
                    }
                    withContext(Dispatchers.Default) {
                        WeightsStorage.save(context, lastBestWeights)
                    }
                    isTraining = false
                }
            },
            modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
            Text(if (isTraining) "Training… (${results.size}/$totalGenerations)" else "Start Training")
        }

        Spacer(Modifier.height(10.dp))
        Text("Generation log", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(results.reversed()) { r ->
                GenerationRow(result = r, maxFitness = results.maxOfOrNull { it.bestFitness } ?: 0.0)
            }
        }
    }
}

/** Plays one game with [weights], visually, one placement at a time, until game over or [maxPieces]. */
private suspend fun playShowcase(controller: GameController, weights: HeuristicWeights, maxPieces: Int = 60) {
    var pieces = 0
    while (!controller.snapshot.isGameOver && pieces < maxPieces) {
        val snap = controller.snapshot
        val piece = snap.current ?: break
        val move = TetrisAI.bestMove(controller.currentBoard(), piece.type, weights, snap.next)
        if (move != null) {
            var rotAttempts = 0
            while (controller.snapshot.current?.rotation != move.rotation && rotAttempts < 4) {
                controller.rotate(); rotAttempts++
            }
            var guard = 0
            while ((controller.snapshot.current?.col ?: move.col) < move.col && guard < BOARD_COLS) {
                controller.moveRight(); guard++
            }
            guard = 0
            while ((controller.snapshot.current?.col ?: move.col) > move.col && guard < BOARD_COLS) {
                controller.moveLeft(); guard++
            }
        }
        controller.hardDrop()
        pieces++
        delay(45L)
    }
}

@Composable
private fun GenerationRow(result: GenerationResult, maxFitness: Double) {
    val fraction = if (maxFitness > 0) (result.bestFitness / maxFitness).toFloat().coerceIn(0f, 1f) else 0f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "#${result.generation}",
            modifier = Modifier.width(34.dp),
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF8A93A3)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF262C38))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .clip(RoundedCornerShape(4.dp))
                    .background(accentColor)
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "%.0f".format(result.bestFitness),
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFFE6E9EF),
            modifier = Modifier.width(46.dp)
        )
    }
}
