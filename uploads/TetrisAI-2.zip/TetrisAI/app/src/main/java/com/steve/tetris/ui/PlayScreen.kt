package com.steve.tetris.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.steve.tetris.game.TetrisGame
import kotlinx.coroutines.delay

@Composable
fun PlayScreen(onBack: () -> Unit) {
    var game by remember { mutableStateOf(TetrisGame()) }
    var tick by remember { mutableStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }

    LaunchedEffect(game, isPaused) {
        while (!game.isGameOver && !isPaused) {
            val delayMs = maxOf(100L, 800L - (game.level - 1) * 60L)
            delay(delayMs)
            game.softDrop()
            tick++
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Score: ${game.score}   Lvl ${game.level}   Next: ${game.next}", style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(8.dp))

        key(tick) {
            BoardView(board = game.board, current = if (game.isGameOver) null else game.current)
        }

        if (game.isGameOver) {
            Spacer(Modifier.height(12.dp))
            Text("Game Over — ${game.linesCleared} lines", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { game = TetrisGame(); isPaused = false; tick++ }) { Text("Restart") }
        } else {
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { game.moveLeft(); tick++ }) { Text("←") }
                Button(onClick = { game.rotate(); tick++ }) { Text("⟳") }
                Button(onClick = { game.moveRight(); tick++ }) { Text("→") }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { game.softDrop(); tick++ }) { Text("Soft Drop") }
                Button(onClick = { game.hardDrop(); tick++ }) { Text("Hard Drop") }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { isPaused = !isPaused }) { Text(if (isPaused) "Resume" else "Pause") }
        }
    }
}
