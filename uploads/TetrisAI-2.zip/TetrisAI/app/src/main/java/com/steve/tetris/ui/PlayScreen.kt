package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun PlayScreen(onBack: () -> Unit) {
    var controller by remember { mutableStateOf(GameController()) }
    var isPaused by remember { mutableStateOf(false) }
    val state = controller.snapshot

    LaunchedEffect(controller, isPaused) {
        while (!controller.snapshot.isGameOver && !isPaused) {
            val delayMs = maxOf(100L, 800L - (controller.snapshot.level - 1) * 60L)
            delay(delayMs)
            if (!isPaused) controller.softDrop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back", color = accentColor) }
            NextPiecePanel(type = state.next)
        }

        Spacer(Modifier.height(8.dp))

        StatRow(score = state.score, level = state.level, lines = state.linesCleared)

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val boardModifier = Modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(14.dp))
            BoardView(board = state.board, current = state.current, modifier = boardModifier)
            LineClearFlash(eventId = state.clearEventId, modifier = boardModifier)
        }

        if (state.isGameOver) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Game Over — ${state.linesCleared} lines",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFFE6E9EF)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { controller = GameController(); isPaused = false }) { Text("Restart") }
        } else {
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                ControlButton("←") { controller.moveLeft() }
                ControlButton("⟳") { controller.rotate() }
                ControlButton("→") { controller.moveRight() }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                ControlButton("▾ Soft Drop", wide = true) { controller.softDrop() }
                ControlButton("⤓ Hard Drop", wide = true) { controller.hardDrop() }
            }
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = { isPaused = !isPaused }) {
                Text(if (isPaused) "Resume" else "Pause", color = accentColor)
            }
        }
    }
}

@Composable
private fun StatRow(score: Int, level: Int, lines: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(panelBackground)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        StatItem("SCORE", score.toString())
        StatItem("LEVEL", level.toString())
        StatItem("LINES", lines.toString())
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        Text(value, style = MaterialTheme.typography.titleMedium, color = Color(0xFFE6E9EF))
    }
}

@Composable
private fun ControlButton(label: String, wide: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = if (wide) Modifier.size(width = 150.dp, height = 52.dp) else Modifier.size(64.dp)
    ) {
        Text(label)
    }
}
