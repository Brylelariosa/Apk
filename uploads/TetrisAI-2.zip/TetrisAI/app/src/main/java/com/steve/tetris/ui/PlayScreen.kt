package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.steve.tetris.audio.SoundEffects
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PlayScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var controller by remember { mutableStateOf(GameController(SoundEffects())) }
    var isPaused by remember { mutableStateOf(false) }
    val state = controller.snapshot

    DisposableEffect(controller) {
        onDispose { controller.dispose() }
    }

    LaunchedEffect(controller, isPaused) {
        while (!controller.snapshot.isGameOver && !isPaused) {
            val delayMs = maxOf(100L, 800L - (controller.snapshot.level - 1) * 60L)
            delay(delayMs)
            if (!isPaused) controller.softDrop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back", color = accentColor) }
            NextPiecePanel(type = state.next)
        }

        Spacer(Modifier.height(8.dp))

        StatRow(score = state.score, level = state.level, lines = state.linesCleared, combo = state.combo)

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            BoardView(
                board = state.board,
                current = state.current,
                flashingRows = state.flashingRows,
                modifier = Modifier.fillMaxHeight().clip(RoundedCornerShape(14.dp))
            )
        }

        if (state.isGameOver) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Game Over — ${state.linesCleared} lines",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFFE6E9EF)
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                controller.dispose()
                controller = GameController(SoundEffects())
                isPaused = false
            }) { Text("Restart") }
        } else {
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                DirButton("←") { scope.launch { controller.moveLeft() } }
                DirButton("⟳") { scope.launch { controller.rotate() } }
                DirButton("→") { scope.launch { controller.moveRight() } }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                DropButton("▾  Soft Drop") { scope.launch { controller.softDrop() } }
                DropButton("⤓  Hard Drop") { scope.launch { controller.hardDrop() } }
            }
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = { isPaused = !isPaused }) {
                Text(if (isPaused) "Resume" else "Pause", color = accentColor)
            }
        }
    }
}

@Composable
private fun StatRow(score: Int, level: Int, lines: Int, combo: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(panelBackground)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        StatItem("SCORE", score.toString())
        StatItem("LEVEL", level.toString())
        StatItem("LINES", lines.toString())
        StatItem("COMBO", if (combo > 1) "x$combo" else "-", highlight = combo > 1)
    }
}

@Composable
private fun StatItem(label: String, value: String, highlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        Text(
            value,
            style = MaterialTheme.typography.titleMedium,
            color = if (highlight) Color(0xFFFFD600) else Color(0xFFE6E9EF)
        )
    }
}

/** Circular secondary-style button for movement/rotation. */
@Composable
private fun DirButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(68.dp),
        shape = CircleShape,
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = panelBackground, contentColor = accentColor)
    ) {
        Text(label, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

/** Filled primary-style pill button for the two drop actions. */
@Composable
private fun DropButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.width(150.dp).height(52.dp),
        shape = RoundedCornerShape(26.dp)
    ) {
        Text(label, fontWeight = FontWeight.SemiBold)
    }
}
