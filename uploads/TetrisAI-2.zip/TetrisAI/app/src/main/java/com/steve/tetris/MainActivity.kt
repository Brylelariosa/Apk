package com.steve.tetris

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.steve.tetris.ui.AppRoot
import com.steve.tetris.ui.screenBackground
import com.steve.tetris.ui.accentColor

private val TetrisColorScheme = darkColorScheme(
    primary = accentColor,
    secondary = Color(0xFFFFD600),
    background = screenBackground,
    surface = screenBackground,
    onPrimary = Color.Black,
    onBackground = Color(0xFFE6E9EF),
    onSurface = Color(0xFFE6E9EF)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = TetrisColorScheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                }
            }
        }
    }
}
