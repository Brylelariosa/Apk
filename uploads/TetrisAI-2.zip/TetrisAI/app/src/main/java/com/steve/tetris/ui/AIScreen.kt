package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.steve.tetris.ai.TetrisAI
import com.steve.tetris.audio.SoundEffects
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.storage.WeightsStorage
import kotlinx.coroutines.delay

@Composable
fun AIScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf(GameController(SoundEffects())) }
    var speedMs by remember { mutableStateOf(120L) }
    val weights = remember { WeightsStorage.load(context) }
    val state = controller.snapshot

    DisposableEffect(controller) {
        onDispose { controller.dispose() }
    }

    LaunchedEffect(controller) {
        while (!controller.snapshot.isGameOver) {
            val snap = controller.snapshot
            val piece = snap.current
            if (piece != null) {
                // 2-piece lookahead: score this placement together with the
                // best spot for the piece after it, so play looks deliberate.
                val move = TetrisAI.bestMove(controller.currentBoard(), piece.type, weights, snap.next)
                if (move != null) {
                    var rotAttempts = 0
                    while (controller.snapshot.current?.rotation != move.rotation && rotAttempts < 4) {
                        controller.rotate(); rotAttempts++
                        delay(speedMs / 3)
                    }
                    var guard = 0
                    while ((controller.snapshot.current?.col ?: move.col) < move.col && guard < BOARD_COLS) {
                        controller.moveRight(); guard++
                        delay(speedMs / 3)
                    }
                    guard = 0
                    while ((controller.snapshot.current?.col ?: move.col) > move.col && guard < BOARD_COLS) {
                        controller.moveLeft(); guard++
                        delay(speedMs / 3)
                    }
                }
            }
            controller.hardDrop()
            delay(speedMs)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back", color = accentColor) }
            NextPiecePanel(type = state.next)
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(panelBackground)
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("AI SCORE", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
                Text(state.score.toString(), style = MaterialTheme.typography.titleMedium, color = Color(0xFFE6E9EF))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("LINES", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
                Text(state.linesCleared.toString(), style = MaterialTheme.typography.titleMedium, color = Color(0xFFE6E9EF))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("COMBO", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
                Text(
                    if (state.combo > 1) "x${state.combo}" else "-",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (state.combo > 1) Color(0xFFFFD600) else Color(0xFFE6E9EF)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            BoardView(
                board = state.board,
                current = state.current,
                flashingRows = state.flashingRows,
                modifier = Modifier.fillMaxHeight().clip(RoundedCornerShape(14.dp))
            )
        }

        Spacer(Modifier.height(12.dp))
        if (state.isGameOver) {
            Text("AI Game Over — ${state.linesCleared} lines cleared", color = Color(0xFFE6E9EF))
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                controller.dispose()
                controller = GameController(SoundEffects())
            }) { Text("Watch Again") }
        } else {
            Text("Speed", style = MaterialTheme.typography.labelMedium, color = Color(0xFF8A93A3))
            Slider(
                value = (300L - speedMs).toFloat(),
                onValueChange = { speedMs = (300L - it.toLong()).coerceIn(20L, 280L) },
                valueRange = 0f..280f
            )
        }
    }
}
