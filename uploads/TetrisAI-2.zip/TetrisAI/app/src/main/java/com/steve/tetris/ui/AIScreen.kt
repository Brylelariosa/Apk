package com.steve.tetris.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.steve.tetris.ai.TetrisAI
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.TetrisGame
import com.steve.tetris.storage.WeightsStorage
import kotlinx.coroutines.delay

@Composable
fun AIScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var game by remember { mutableStateOf(TetrisGame()) }
    var tick by remember { mutableStateOf(0) }
    var speedMs by remember { mutableStateOf(120L) }
    val weights = remember { WeightsStorage.load(context) }

    LaunchedEffect(game) {
        while (!game.isGameOver) {
            val move = TetrisAI.bestMove(game.copyBoard(), game.current.type, weights)
            if (move != null) {
                var rotAttempts = 0
                while (game.current.rotation != move.rotation && rotAttempts < 4) {
                    game.rotate(); rotAttempts++; tick++
                    delay(speedMs / 3)
                }
                var guard = 0
                while (game.current.col < move.col && guard < BOARD_COLS) {
                    game.moveRight(); guard++; tick++
                    delay(speedMs / 3)
                }
                guard = 0
                while (game.current.col > move.col && guard < BOARD_COLS) {
                    game.moveLeft(); guard++; tick++
                    delay(speedMs / 3)
                }
            }
            game.hardDrop()
            tick++
            delay(speedMs)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("AI Score: ${game.score}", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        key(tick) {
            BoardView(board = game.board, current = if (game.isGameOver) null else game.current)
        }
        Spacer(Modifier.height(12.dp))
        if (game.isGameOver) {
            Text("AI Game Over — ${game.linesCleared} lines cleared")
            Spacer(Modifier.height(8.dp))
            Button(onClick = { game = TetrisGame(); tick++ }) { Text("Watch Again") }
        } else {
            Text("Speed", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = (300L - speedMs).toFloat(),
                onValueChange = { speedMs = (300L - it.toLong()).coerceIn(20L, 280L) },
                valueRange = 0f..280f
            )
        }
    }
}
