package com.steve.tetris.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

/**
 * A brief white flash over the board whenever a line clear happens.
 * `eventId` should be a value that changes on every clear (a counter),
 * not the line count itself - two consecutive single-line clears both
 * report "1" and wouldn't otherwise be treated as distinct events.
 */
@Composable
fun LineClearFlash(eventId: Int, modifier: Modifier = Modifier) {
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(eventId) {
        if (eventId > 0) {
            alpha.snapTo(0.5f)
            alpha.animateTo(0f, animationSpec = tween(durationMillis = 350))
        }
    }
    if (alpha.value > 0f) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.White.copy(alpha = alpha.value))
        )
    }
}
