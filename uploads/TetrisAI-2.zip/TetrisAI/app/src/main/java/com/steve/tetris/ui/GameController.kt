package com.steve.tetris.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.steve.tetris.game.ActivePiece
import com.steve.tetris.game.PieceType
import com.steve.tetris.game.TetrisGame

data class GameSnapshot(
    val board: Array<IntArray>,
    val current: ActivePiece?,
    val next: PieceType,
    val score: Int,
    val linesCleared: Int,
    val level: Int,
    val isGameOver: Boolean,
    val clearEventId: Int
)

/**
 * TetrisGame is a plain, framework-free class - mutating it doesn't tell
 * Compose anything changed. This wraps it and republishes a fresh
 * GameSnapshot into a Compose State after every move, so the UI reliably
 * recomposes on every input instead of relying on a manually bumped counter.
 */
class GameController {
    private var engine = TetrisGame()
    private var clearEventId = 0

    var snapshot by mutableStateOf(makeSnapshot())
        private set

    private fun makeSnapshot(clearedNow: Int = 0) = GameSnapshot(
        board = engine.copyBoard(),
        current = if (engine.isGameOver) null else engine.current,
        next = engine.next,
        score = engine.score,
        linesCleared = engine.linesCleared,
        level = engine.level,
        isGameOver = engine.isGameOver,
        clearEventId = clearEventId
    )

    fun restart() {
        engine = TetrisGame()
        clearEventId = 0
        snapshot = makeSnapshot()
    }

    fun moveLeft() = mutate { it.moveLeft() }
    fun moveRight() = mutate { it.moveRight() }
    fun rotate() = mutate { it.rotate() }
    fun softDrop() = mutate { it.softDrop() }
    fun hardDrop() = mutate { it.hardDrop() }

    /** For AI playback: reads the current board without mutating anything. */
    fun currentBoard(): Array<IntArray> = engine.copyBoard()

    private fun mutate(action: (TetrisGame) -> Unit) {
        val before = engine.linesCleared
        action(engine)
        val clearedNow = engine.linesCleared - before
        if (clearedNow > 0) clearEventId++
        snapshot = makeSnapshot(clearedNow)
    }
}
