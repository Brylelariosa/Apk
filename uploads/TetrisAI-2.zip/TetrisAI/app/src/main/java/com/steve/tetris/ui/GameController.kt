package com.steve.tetris.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.steve.tetris.audio.SoundEffects
import com.steve.tetris.game.ActivePiece
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.PieceType
import com.steve.tetris.game.TetrisGame
import com.steve.tetris.game.Tetromino
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class GameSnapshot(
    val board: Array<IntArray>,
    val current: ActivePiece?,
    val next: PieceType,
    val score: Int,
    val linesCleared: Int,
    val level: Int,
    val isGameOver: Boolean,
    val clearEventId: Int,
    val combo: Int = 0,
    val flashingRows: List<Int> = emptyList()
)

/**
 * Reactive wrapper around TetrisGame. Three things beyond plain state syncing:
 *
 * 1. Every mutation republishes a fresh GameSnapshot so Compose reliably
 *    recomposes (TetrisGame itself has no idea Compose exists).
 * 2. Locking a piece that completes a line is a two-phase reveal: first we
 *    publish the board WITH the completed row still sitting there (so it can
 *    flash), THEN - after a short pause - the real engine clear/shift runs
 *    and we publish the final state.
 * 3. That pause is a suspension point. Without a lock, a manual move/rotate
 *    (or gravity firing again) could mutate the SAME engine while a drop is
 *    frozen mid-reveal, so the drop that resumes afterward no longer matches
 *    what was actually shown - pieces landing somewhere unpredicted, or in
 *    rare cases a bogus game-over. Every mutation goes through one mutex so
 *    only one is ever in flight at a time.
 */
class GameController(private val sound: SoundEffects? = null) {
    private var engine = TetrisGame()
    private var clearEventId = 0
    private val mutex = Mutex()

    var snapshot by mutableStateOf(makeSnapshot())
        private set

    private fun makeSnapshot(
        clearedNow: Int = 0,
        flashRows: List<Int> = emptyList(),
        overrideBoard: Array<IntArray>? = null,
        hidePiece: Boolean = false
    ) = GameSnapshot(
        board = overrideBoard ?: engine.copyBoard(),
        current = if (hidePiece || engine.isGameOver) null else engine.current,
        next = engine.next,
        score = engine.score,
        linesCleared = engine.linesCleared,
        level = engine.level,
        isGameOver = engine.isGameOver,
        clearEventId = clearEventId,
        combo = engine.combo,
        flashingRows = flashRows
    )

    suspend fun restart() = mutex.withLock {
        engine = TetrisGame()
        clearEventId = 0
        snapshot = makeSnapshot()
    }

    suspend fun moveLeft() = mutex.withLock {
        engine.moveLeft()
        snapshot = makeSnapshot()
    }

    suspend fun moveRight() = mutex.withLock {
        engine.moveRight()
        snapshot = makeSnapshot()
    }

    suspend fun rotate() = mutex.withLock {
        val before = engine.current
        engine.rotate()
        if (engine.current != before) sound?.rotate()
        snapshot = makeSnapshot()
    }

    /** For AI move search: the locked board, not including the falling piece. */
    fun currentBoard(): Array<IntArray> = engine.copyBoard()

    suspend fun softDrop() = mutex.withLock { drop(hard = false) }
    suspend fun hardDrop() = mutex.withLock { drop(hard = true) }

    // Only called from within mutex.withLock above - never call directly.
    private suspend fun drop(hard: Boolean) {
        if (engine.isGameOver) return
        val willLock = if (hard) true else !engine.canMoveDown()

        if (willLock) {
            val restingPiece = if (hard) engine.hardDropTarget() else engine.current
            val boardWithPiece = mergedBoard(engine.copyBoard(), restingPiece)
            val predictedRows = completedRows(boardWithPiece)

            sound?.lock()
            if (predictedRows.isNotEmpty()) {
                // Freeze-frame: show the completed row(s) before they vanish.
                // Safe to hold the lock through this delay - that's the point.
                snapshot = makeSnapshot(flashRows = predictedRows, overrideBoard = boardWithPiece, hidePiece = true)
                sound?.lineClear(engine.combo + 1)
                delay(220L)
            }
        }

        val before = engine.linesCleared
        val wasGameOver = engine.isGameOver
        if (hard) engine.hardDrop() else engine.softDrop()
        val clearedNow = engine.linesCleared - before
        if (clearedNow > 0) clearEventId++
        if (!wasGameOver && engine.isGameOver) sound?.gameOver()
        snapshot = makeSnapshot(clearedNow)
    }

    fun dispose() {
        sound?.release()
    }

    private fun mergedBoard(board: Array<IntArray>, piece: ActivePiece): Array<IntArray> {
        val copy = Array(BOARD_ROWS) { r -> board[r].copyOf() }
        val color = Tetromino.colorIndex.getValue(piece.type)
        for ((r, c) in piece.cells()) {
            if (r in 0 until BOARD_ROWS && c in 0 until BOARD_COLS) copy[r][c] = color
        }
        return copy
    }

    private fun completedRows(board: Array<IntArray>): List<Int> =
        (0 until BOARD_ROWS).filter { r -> board[r].all { it != 0 } }
}
