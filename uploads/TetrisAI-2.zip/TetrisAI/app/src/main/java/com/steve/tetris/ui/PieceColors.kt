package com.steve.tetris.ui

import androidx.compose.ui.graphics.Color

// Index 0 is unused (empty cells aren't drawn); indices 1-7 match PieceType/colorIndex.
val pieceColors = listOf(
    Color(0xFF1A1A1A),
    Color(0xFF00E5FF), // I - cyan
    Color(0xFFFFD600), // O - yellow
    Color(0xFFD500F9), // T - purple
    Color(0xFF00E676), // S - green
    Color(0xFFFF5252), // Z - red
    Color(0xFF448AFF), // J - blue
    Color(0xFFFF9100)  // L - orange
)

val boardBackground = Color(0xFF0B0E14)
val screenBackground = Color(0xFF11151C)
val panelBackground = Color(0xFF1A1F29)
val accentColor = Color(0xFF00E5FF)
