package com.steve.tetris.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.steve.tetris.game.PieceType
import com.steve.tetris.game.Tetromino

@Composable
fun NextPiecePanel(type: PieceType, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(panelBackground)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("NEXT", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        Canvas(modifier = Modifier.size(56.dp).padding(top = 4.dp)) {
            val cellSize = size.minDimension / 4f
            val cells = Tetromino.cellsFor(type, 0)
            val color = pieceColors[Tetromino.colorIndex.getValue(type)]
            // Center the piece's bounding box within the 4x4 preview grid.
            val minCol = cells.minOf { it.second }
            val maxCol = cells.maxOf { it.second }
            val minRow = cells.minOf { it.first }
            val maxRow = cells.maxOf { it.first }
            val offsetCol = (3 - (maxCol - minCol)) / 2f - minCol
            val offsetRow = (3 - (maxRow - minRow)) / 2f - minRow
            cells.forEach { (r, c) ->
                drawRect(
                    color = color,
                    topLeft = Offset((c + offsetCol) * cellSize, (r + offsetRow) * cellSize),
                    size = Size(cellSize - 2f, cellSize - 2f)
                )
            }
        }
    }
}
