package com.steve.tetris.ai

import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.PieceType
import com.steve.tetris.game.Tetromino
import kotlin.math.abs

data class Move(val rotation: Int, val col: Int)

private data class SimResult(val board: Array<IntArray>, val linesCleared: Int)

/**
 * Brute-force placement search: for every legal (rotation, column) pair,
 * simulate dropping the piece there, evaluate the resulting board with the
 * given weights, and keep the best-scoring placement. This is the standard
 * approach used by classic Tetris-playing bots.
 */
object TetrisAI {

    /**
     * Finds the best (rotation, column) for [type]. When [nextType] is
     * supplied, each candidate placement is also scored by how well the
     * *following* piece would fit on the resulting board (2-piece
     * lookahead) - this is what makes even an untrained/default-weight AI
     * look like it's planning ahead rather than greedily reacting.
     */
    fun bestMove(
        board: Array<IntArray>,
        type: PieceType,
        weights: HeuristicWeights,
        nextType: PieceType? = null
    ): Move? {
        var bestScore = Double.NEGATIVE_INFINITY
        var bestMove: Move? = null

        for (rotation in rotationsFor(type)) {
            val shape = Tetromino.cellsFor(type, rotation)
            val minCol = -shape.minOf { it.second }
            val maxCol = BOARD_COLS - 1 - shape.maxOf { it.second }
            if (minCol > maxCol) continue
            for (col in minCol..maxCol) {
                val dropRow = findDropRow(board, shape, col) ?: continue
                val sim = simulateDrop(board, shape, col, dropRow, type)
                var score = evaluate(sim.board, sim.linesCleared, weights)
                if (nextType != null) {
                    bestScoreFor(sim.board, nextType, weights)?.let { score += it }
                }
                if (score > bestScore) {
                    bestScore = score
                    bestMove = Move(rotation, col)
                }
            }
        }
        return bestMove
    }

    /** Best achievable single-placement score for [type] on [board] - used for lookahead. */
    private fun bestScoreFor(board: Array<IntArray>, type: PieceType, weights: HeuristicWeights): Double? {
        var best: Double? = null
        for (rotation in rotationsFor(type)) {
            val shape = Tetromino.cellsFor(type, rotation)
            val minCol = -shape.minOf { it.second }
            val maxCol = BOARD_COLS - 1 - shape.maxOf { it.second }
            if (minCol > maxCol) continue
            for (col in minCol..maxCol) {
                val dropRow = findDropRow(board, shape, col) ?: continue
                val sim = simulateDrop(board, shape, col, dropRow, type)
                val score = evaluate(sim.board, sim.linesCleared, weights)
                if (best == null || score > best) best = score
            }
        }
        return best
    }

    private fun rotationsFor(type: PieceType): IntRange =
        if (type == PieceType.O) 0..0 else 0..3

    private fun findDropRow(board: Array<IntArray>, shape: List<Pair<Int, Int>>, col: Int): Int? {
        var row = -2
        while (fits(board, shape, row + 1, col)) row += 1
        return if (fits(board, shape, row, col)) row else null
    }

    private fun fits(board: Array<IntArray>, shape: List<Pair<Int, Int>>, row: Int, col: Int): Boolean {
        for ((r, c) in shape) {
            val br = r + row
            val bc = c + col
            if (bc !in 0 until BOARD_COLS) return false
            if (br >= BOARD_ROWS) return false
            if (br >= 0 && board[br][bc] != 0) return false
        }
        return true
    }

    private fun simulateDrop(
        board: Array<IntArray>,
        shape: List<Pair<Int, Int>>,
        col: Int,
        row: Int,
        type: PieceType
    ): SimResult {
        val copy = Array(BOARD_ROWS) { r -> board[r].copyOf() }
        val color = Tetromino.colorIndex.getValue(type)
        for ((r, c) in shape) {
            val br = r + row
            val bc = c + col
            if (br in 0 until BOARD_ROWS) copy[br][bc] = color
        }
        val remaining = copy.filter { r -> r.any { it == 0 } }
        val cleared = BOARD_ROWS - remaining.size
        val newRows = List(cleared) { IntArray(BOARD_COLS) }
        return SimResult((newRows + remaining).toTypedArray(), cleared)
    }

    fun evaluate(board: Array<IntArray>, linesCleared: Int, w: HeuristicWeights): Double {
        val heights = IntArray(BOARD_COLS)
        for (c in 0 until BOARD_COLS) {
            var h = 0
            for (r in 0 until BOARD_ROWS) {
                if (board[r][c] != 0) {
                    h = BOARD_ROWS - r
                    break
                }
            }
            heights[c] = h
        }
        val aggregateHeight = heights.sum()

        var holes = 0
        for (c in 0 until BOARD_COLS) {
            var blockFound = false
            for (r in 0 until BOARD_ROWS) {
                if (board[r][c] != 0) blockFound = true
                else if (blockFound) holes++
            }
        }

        var bumpiness = 0
        for (c in 0 until BOARD_COLS - 1) {
            bumpiness += abs(heights[c] - heights[c + 1])
        }

        var rowTransitions = 0
        for (r in 0 until BOARD_ROWS) {
            var prevFilled = true // left wall counts as filled
            for (c in 0 until BOARD_COLS) {
                val filled = board[r][c] != 0
                if (filled != prevFilled) rowTransitions++
                prevFilled = filled
            }
            if (!prevFilled) rowTransitions++ // right wall counts as filled
        }

        var colTransitions = 0
        for (c in 0 until BOARD_COLS) {
            var prevFilled = false // open sky above the stack counts as empty
            for (r in 0 until BOARD_ROWS) {
                val filled = board[r][c] != 0
                if (filled != prevFilled) colTransitions++
                prevFilled = filled
            }
            if (!prevFilled) colTransitions++ // floor counts as filled
        }

        return w.aggregateHeight * aggregateHeight +
            w.completeLines * linesCleared +
            w.holes * holes +
            w.bumpiness * bumpiness +
            w.rowTransitions * rowTransitions +
            w.colTransitions * colTransitions
    }
}
