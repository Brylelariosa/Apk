package com.steve.tetris.ai

import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.PieceType
import com.steve.tetris.game.Tetromino
import kotlin.math.abs

data class Move(val rotation: Int, val col: Int)

private data class SimResult(val board: Array<IntArray>, val linesCleared: Int)

/**
 * Brute-force placement search: for every legal (rotation, column) pair,
 * simulate dropping the piece there, evaluate the resulting board with the
 * given weights, and keep the best-scoring placement. This is the standard
 * approach used by classic Tetris-playing bots.
 */
object TetrisAI {

    fun bestMove(board: Array<IntArray>, type: PieceType, weights: HeuristicWeights): Move? {
        var bestScore = Double.NEGATIVE_INFINITY
        var bestMove: Move? = null

        val rotationCount = if (type == PieceType.O) 1 else 4
        for (rotation in 0 until rotationCount) {
            val shape = Tetromino.cellsFor(type, rotation)
            val minCol = -shape.minOf { it.second }
            val maxCol = BOARD_COLS - 1 - shape.maxOf { it.second }
            if (minCol > maxCol) continue
            for (col in minCol..maxCol) {
                val dropRow = findDropRow(board, shape, col) ?: continue
                val sim = simulateDrop(board, shape, col, dropRow, type)
                val score = evaluate(sim.board, sim.linesCleared, weights)
                if (score > bestScore) {
                    bestScore = score
                    bestMove = Move(rotation, col)
                }
            }
        }
        return bestMove
    }

    private fun findDropRow(board: Array<IntArray>, shape: List<Pair<Int, Int>>, col: Int): Int? {
        var row = -2
        while (fits(board, shape, row + 1, col)) row += 1
        return if (fits(board, shape, row, col)) row else null
    }

    private fun fits(board: Array<IntArray>, shape: List<Pair<Int, Int>>, row: Int, col: Int): Boolean {
        for ((r, c) in shape) {
            val br = r + row
            val bc = c + col
            if (bc !in 0 until BOARD_COLS) return false
            if (br >= BOARD_ROWS) return false
            if (br >= 0 && board[br][bc] != 0) return false
        }
        return true
    }

    private fun simulateDrop(
        board: Array<IntArray>,
        shape: List<Pair<Int, Int>>,
        col: Int,
        row: Int,
        type: PieceType
    ): SimResult {
        val copy = Array(BOARD_ROWS) { r -> board[r].copyOf() }
        val color = Tetromino.colorIndex.getValue(type)
        for ((r, c) in shape) {
            val br = r + row
            val bc = c + col
            if (br in 0 until BOARD_ROWS) copy[br][bc] = color
        }
        val remaining = copy.filter { r -> r.any { it == 0 } }
        val cleared = BOARD_ROWS - remaining.size
        val newRows = List(cleared) { IntArray(BOARD_COLS) }
        return SimResult((newRows + remaining).toTypedArray(), cleared)
    }

    fun evaluate(board: Array<IntArray>, linesCleared: Int, w: HeuristicWeights): Double {
        val heights = IntArray(BOARD_COLS)
        for (c in 0 until BOARD_COLS) {
            var h = 0
            for (r in 0 until BOARD_ROWS) {
                if (board[r][c] != 0) {
                    h = BOARD_ROWS - r
                    break
                }
            }
            heights[c] = h
        }
        val aggregateHeight = heights.sum()

        var holes = 0
        for (c in 0 until BOARD_COLS) {
            var blockFound = false
            for (r in 0 until BOARD_ROWS) {
                if (board[r][c] != 0) blockFound = true
                else if (blockFound) holes++
            }
        }

        var bumpiness = 0
        for (c in 0 until BOARD_COLS - 1) {
            bumpiness += abs(heights[c] - heights[c + 1])
        }

        return w.aggregateHeight * aggregateHeight +
            w.completeLines * linesCleared +
            w.holes * holes +
            w.bumpiness * bumpiness
    }
}
