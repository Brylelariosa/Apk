package com.steve.tetris.game

enum class PieceType { I, O, T, S, Z, J, L }

/**
 * Piece shapes are defined once (rotation state 0, on a 4x4 grid) and every
 * other rotation is derived mathematically. This avoids the classic bug of
 * hand-typing four coordinate lists per piece and getting one of them wrong.
 */
object Tetromino {

    private val baseShapes: Map<PieceType, List<Pair<Int, Int>>> = mapOf(
        PieceType.I to listOf(1 to 0, 1 to 1, 1 to 2, 1 to 3),
        PieceType.O to listOf(0 to 1, 0 to 2, 1 to 1, 1 to 2),
        PieceType.T to listOf(0 to 1, 1 to 0, 1 to 1, 1 to 2),
        PieceType.S to listOf(0 to 1, 0 to 2, 1 to 0, 1 to 1),
        PieceType.Z to listOf(0 to 0, 0 to 1, 1 to 1, 1 to 2),
        PieceType.J to listOf(0 to 0, 1 to 0, 1 to 1, 1 to 2),
        PieceType.L to listOf(0 to 2, 1 to 0, 1 to 1, 1 to 2)
    )

    // Rotate the occupied cells of a 4x4 box 90 degrees clockwise.
    private fun rotateCW(cells: List<Pair<Int, Int>>): List<Pair<Int, Int>> =
        cells.map { (r, c) -> c to (3 - r) }

    /** All 4 rotation states per piece, precomputed once at class init. */
    val rotations: Map<PieceType, List<List<Pair<Int, Int>>>> = baseShapes.mapValues { (type, base) ->
        if (type == PieceType.O) {
            // The O piece is visually identical in every rotation state.
            List(4) { base }
        } else {
            val states = mutableListOf(base)
            repeat(3) { states.add(rotateCW(states.last())) }
            states
        }
    }

    fun cellsFor(type: PieceType, rotation: Int): List<Pair<Int, Int>> =
        rotations.getValue(type)[((rotation % 4) + 4) % 4]

    val colorIndex: Map<PieceType, Int> = mapOf(
        PieceType.I to 1, PieceType.O to 2, PieceType.T to 3,
        PieceType.S to 4, PieceType.Z to 5, PieceType.J to 6, PieceType.L to 7
    )
}
