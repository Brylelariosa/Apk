package com.steve.tetris.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

private enum class Screen { HOME, PLAY, WATCH_AI, TRAIN_AI }

@Composable
fun AppRoot() {
    var screen by remember { mutableStateOf(Screen.HOME) }

    ImmersiveMode(enabled = screen == Screen.PLAY || screen == Screen.WATCH_AI)

    when (screen) {
        Screen.HOME -> HomeScreen(
            onPlay = { screen = Screen.PLAY },
            onWatchAI = { screen = Screen.WATCH_AI },
            onTrainAI = { screen = Screen.TRAIN_AI }
        )
        Screen.PLAY -> PlayScreen(onBack = { screen = Screen.HOME })
        Screen.WATCH_AI -> AIScreen(onBack = { screen = Screen.HOME })
        Screen.TRAIN_AI -> TrainScreen(onBack = { screen = Screen.HOME })
    }
}
