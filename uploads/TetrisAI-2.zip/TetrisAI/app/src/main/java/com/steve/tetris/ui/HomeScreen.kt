package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(onPlay: () -> Unit, onWatchAI: () -> Unit, onTrainAI: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LogoBlocks()
        Spacer(Modifier.height(20.dp))
        Text(
            "TETRIS AI",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE6E9EF)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Play it yourself, or watch an AI evolve its own strategy.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF8A93A3)
        )
        Spacer(Modifier.height(36.dp))
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Play") }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onWatchAI, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Watch AI Play") }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onTrainAI, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Train AI") }
    }
}

@Composable
private fun LogoBlocks() {
    val colors = listOf(pieceColors[1], pieceColors[3], pieceColors[2], pieceColors[5])
    Row {
        colors.forEachIndexed { i, color ->
            Column(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(color)
                    .then(if (i == 1) Modifier.padding(top = 32.dp) else Modifier)
            ) {}
        }
    }
}
