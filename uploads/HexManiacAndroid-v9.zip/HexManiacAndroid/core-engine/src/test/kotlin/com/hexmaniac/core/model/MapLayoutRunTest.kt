package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class MapLayoutRunTest {

    private fun modelWithBytes(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size) { -1 } // 0xFF backdrop, like real ROM free space
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    @Test
    fun `create computes length from block-grid dimensions`() {
        val format = MapLayoutFormat(blockTileWidth = 20, blockTileHeight = 16, blocksetAddress = 0)
        val run = MapLayoutRun.create(RomDataModel(ByteArray(0x1000)), 0, format)
        assertEquals(20 * 16 * 2, run.length)
    }

    @Test
    fun `create throws when the layout would run past the end of the ROM`() {
        val format = MapLayoutFormat(blockTileWidth = 100, blockTileHeight = 100, blocksetAddress = 0)
        assertFailsWith<MapFormatException> { MapLayoutRun.create(RomDataModel(ByteArray(0x10)), 0, format) }
    }

    @Test
    fun `writeEntry then readEntry round-trips at a given cell`() {
        val format = MapLayoutFormat(blockTileWidth = 4, blockTileHeight = 4, blocksetAddress = 0)
        val model = RomDataModel(ByteArray(0x100))
        val layout = MapLayoutRun.create(model, 0, format)
        val token = ModelDelta()

        layout.writeEntry(model, 2, 1, BlockEntry(blockIndex = 5, collisionIndex = 3), token)

        assertEquals(BlockEntry(5, 3), layout.readEntry(model, 2, 1))
        assertEquals(BlockEntry(0), layout.readEntry(model, 0, 0)) // untouched cell stays default
    }

    @Test
    fun `writeEntry rejects coordinates outside the layout's grid`() {
        val format = MapLayoutFormat(blockTileWidth = 4, blockTileHeight = 4, blocksetAddress = 0)
        val model = RomDataModel(ByteArray(0x100))
        val layout = MapLayoutRun.create(model, 0, format)
        assertFailsWith<IllegalArgumentException> { layout.writeEntry(model, 4, 0, BlockEntry(0), ModelDelta()) }
    }

    @Test
    fun `getPixels composites the opaque bottom layer and the transparent-on-zero top layer`() {
        // tile 0: a single marker pixel (value 5) at its own (0,0), rest 0; tile 1: uniform value 3.
        val tile0 = intArrayOf(0x05) + IntArray(31)
        val tile1 = IntArray(32) { 0x33 }
        val tilesetBytes = tile0 + tile1
        val tilesetFormat = SpriteFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 1, compressed = false)

        // bottom layer: all 4 quadrants use tile 0, palette 0 (always opaque when composed)
        val bottomEntries = List(4) { TilemapEntry(tileIndex = 0, paletteIndex = 0) }
        // top layer: quadrant 0 is opaque tile 1 (palette 1); quadrants 1-3 are mostly-transparent
        // tile 0 (palette 2) - only its own marker pixel is non-zero and so visible
        val topEntries = listOf(
            TilemapEntry(tileIndex = 1, paletteIndex = 1),
            TilemapEntry(tileIndex = 0, paletteIndex = 2),
            TilemapEntry(tileIndex = 0, paletteIndex = 2),
            TilemapEntry(tileIndex = 0, paletteIndex = 2),
        )
        val blockBytes = (bottomEntries + topEntries)
            .flatMap { e -> val p = e.pack(); listOf(p and 0xFF, (p shr 8) and 0xFF) }
            .toIntArray()

        val mapEntryPacked = BlockEntry(blockIndex = 0).pack()
        val mapBytes = intArrayOf(mapEntryPacked and 0xFF, (mapEntryPacked shr 8) and 0xFF)

        val model = modelWithBytes(0x300, 0 to tilesetBytes, 0x100 to blockBytes, 0x200 to mapBytes)
        model.addRun(SpriteRun.create(model, 0, tilesetFormat))
        model.addRun(BlocksetRun.create(model, 0x100, BlocksetFormat(blockCount = 1, tilesetAddress = 0)))
        val layout = MapLayoutRun.create(model, 0x200, MapLayoutFormat(blockTileWidth = 1, blockTileHeight = 1, blocksetAddress = 0x100))

        val pixels = layout.getPixels(model)
        val width = 16 // one block = 16x16 pixels

        assertEquals(3 + (1 shl 4), pixels[0 * width + 0]) // quadrant 0: top is opaque here, wins
        assertEquals(5 + (2 shl 4), pixels[0 * width + 8]) // quadrant 1: top's own marker is non-zero, wins
        assertEquals(0, pixels[0 * width + 9]) // quadrant 1 elsewhere: top transparent, bottom (0) shows through
    }

    @Test
    fun `getPixels returns a blank grid when the blockset isn't defined`() {
        val format = MapLayoutFormat(blockTileWidth = 2, blockTileHeight = 2, blocksetAddress = 0x999)
        val model = RomDataModel(ByteArray(0x40)) // nothing registered at 0x999
        val layout = MapLayoutRun.create(model, 0, format)
        assertEquals(IntArray(32 * 32).toList(), layout.getPixels(model).toList())
    }

    @Test
    fun `getPixels returns a blank grid when the blockset's tileset isn't defined`() {
        val model = modelWithBytes(0x200, 0x100 to IntArray(16)) // an all-zero blockset, no tileset at 0
        model.addRun(BlocksetRun.create(model, 0x100, BlocksetFormat(blockCount = 1, tilesetAddress = 0x999)))
        val layout = MapLayoutRun.create(model, 0, MapLayoutFormat(blockTileWidth = 1, blockTileHeight = 1, blocksetAddress = 0x100))
        assertEquals(IntArray(16 * 16).toList(), layout.getPixels(model).toList())
    }
}
