package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class MapFormatTest {

    @Test
    fun `parses a blockset format`() {
        val format = MapFormat.parseBlockset("`blk512|1A2B3C`")
        assertEquals(BlocksetFormat(blockCount = 512, tilesetAddress = 0x1A2B3C), format)
    }

    @Test
    fun `blockset format resolves a tileset address via the anchor resolver when not valid hex`() {
        val format = MapFormat.parseBlockset("`blk512|data.some.tileset`") { name ->
            if (name == "data.some.tileset") 0x777 else null
        }
        assertEquals(0x777, format.tilesetAddress)
    }

    @Test
    fun `rejects a blockset format missing its tileset address`() {
        assertFailsWith<MapFormatException> { MapFormat.parseBlockset("`blk512`") }
    }

    @Test
    fun `rejects a blockset format with an invalid block count`() {
        assertFailsWith<MapFormatException> { MapFormat.parseBlockset("`blknotanumber|100`") }
    }

    @Test
    fun `parses a map layout format`() {
        val format = MapFormat.parseMapLayout("`map20x16|400000`")
        assertEquals(MapLayoutFormat(blockTileWidth = 20, blockTileHeight = 16, blocksetAddress = 0x400000), format)
    }

    @Test
    fun `map layout format resolves a blockset address via the anchor resolver when not valid hex`() {
        val format = MapFormat.parseMapLayout("`map20x16|data.some.blockset`") { name ->
            if (name == "data.some.blockset") 0x888 else null
        }
        assertEquals(0x888, format.blocksetAddress)
    }

    @Test
    fun `rejects a map layout format missing a dimension`() {
        assertFailsWith<MapFormatException> { MapFormat.parseMapLayout("`map20|400000`") }
    }

    @Test
    fun `rejects an address that resolves via neither hex nor the resolver`() {
        assertFailsWith<MapFormatException> { MapFormat.parseMapLayout("`map20x16|nonexistent.name`") }
    }
}
