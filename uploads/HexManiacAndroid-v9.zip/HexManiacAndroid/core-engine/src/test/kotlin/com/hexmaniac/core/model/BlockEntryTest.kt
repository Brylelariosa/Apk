package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals

class BlockEntryTest {

    @Test
    fun `pack matches the low-10-bits-index high-6-bits-collision layout`() {
        val entry = BlockEntry(blockIndex = 0x105, collisionIndex = 0x2A)
        assertEquals(0xA905, entry.pack())
    }

    @Test
    fun `unpack is the inverse of pack across a spread of values`() {
        for (blockIndex in listOf(0, 1, 0x3FF, 0x105)) {
            for (collisionIndex in listOf(0, 1, 0x3F, 0x2A)) {
                val entry = BlockEntry(blockIndex, collisionIndex)
                assertEquals(entry, BlockEntry.unpack(entry.pack()))
            }
        }
    }
}
