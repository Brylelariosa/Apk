package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class GbaColorTest {

    @Test
    fun `black and white map to their argb equivalents`() {
        assertEquals(0xFF000000.toInt(), GbaColor.toArgb8888(0x0000))
        assertEquals(0xFFFFFFFF.toInt(), GbaColor.toArgb8888(0x7FFF))
    }

    @Test
    fun `each raw channel maps to the correct argb channel`() {
        // Red is bits 0-4, green bits 5-9, blue bits 10-14 - see GbaColor's doc comment for why
        // that's the direct mapping despite the original's own PaletteRun going through an
        // internal double-flip to get there.
        assertEquals(0xFFFF0000.toInt(), GbaColor.toArgb8888(0x001F)) // red only
        assertEquals(0xFF00FF00.toInt(), GbaColor.toArgb8888(0x03E0)) // green only
        assertEquals(0xFF0000FF.toInt(), GbaColor.toArgb8888(0x7C00)) // blue only
    }

    @Test
    fun `5-bit to 8-bit scaling reaches full brightness, not 248`() {
        // 31 * 255 / 31 = 255, not 31 << 3 = 248 - see the doc comment on why this must be the
        // division form.
        val argb = GbaColor.toArgb8888(0x001F)
        assertEquals(255, (argb shr 16) and 0xFF)
    }

    @Test
    fun `boundary colors round-trip exactly through argb and back`() {
        for (raw in listOf(0x0000, 0x001F, 0x03E0, 0x7C00, 0x7FFF)) {
            assertEquals(raw, GbaColor.fromArgb8888(GbaColor.toArgb8888(raw)), "raw=0x${raw.toString(16)}")
        }
    }

    @Test
    fun `editing a color and reading it back unchanged is a no-op`() {
        // fromArgb8888 uses a truncating >> 3, matching the original's own color-picker
        // downscale, specifically so this round trip holds even though a rounding *31/255
        // scale would also be defensible in isolation.
        val original = 0x1234
        val unedited = GbaColor.toArgb8888(original)
        assertEquals(original, GbaColor.fromArgb8888(unedited))
    }

    @Test
    fun `grayscaleRamp starts black, ends white, and is monotonically non-decreasing`() {
        val ramp = GbaColor.grayscaleRamp(16)
        assertEquals(0xFF000000.toInt(), ramp.first())
        assertEquals(0xFFFFFFFF.toInt(), ramp.last())
        for (i in 1 until ramp.size) {
            val prevRed = (ramp[i - 1] shr 16) and 0xFF
            val red = (ramp[i] shr 16) and 0xFF
            assertTrue(red >= prevRed, "expected a non-decreasing ramp at index $i")
        }
    }

    @Test
    fun `grayscaleRamp of a single color doesn't divide by zero`() {
        val ramp = GbaColor.grayscaleRamp(1)
        assertEquals(1, ramp.size)
        assertEquals(0xFF000000.toInt(), ramp[0])
    }
}
