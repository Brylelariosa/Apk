package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class KnownTablesTest {

    @Test
    fun `parses a simple line with all 9 addresses the same, and no format text`() {
        val line = "data.pokemon.names,144,144,144,144,144,144,144,144,144"
        val result = KnownTables.parse(line)
        for (gameCode in KnownTables.GAME_CODES) {
            assertEquals(listOf(KnownTableEntry("data.pokemon.names", 0x144, "")), result[gameCode], "for $gameCode")
        }
    }

    @Test
    fun `captures the format-string column verbatim`() {
        val line = "data.pokemon.names,144,144,144,144,144,144,144,144,144,[name\"\"11]"
        val result = KnownTables.parse(line)
        assertEquals("[name\"\"11]", result.getValue("AXVE0").single().formatText)
    }

    @Test
    fun `a blank address column is skipped for that game only`() {
        val line = "data.only.in.emerald,,,,,,,,,183b4,[foo]"
        val result = KnownTables.parse(line)
        assertEquals(emptyList(), result["AXVE0"])
        assertEquals(listOf(KnownTableEntry("data.only.in.emerald", 0x183b4, "[foo]")), result["BPEE0"])
    }

    @Test
    fun `comment and blank lines are ignored`() {
        val text = "// a comment\n\ndata.real.entry,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf(KnownTableEntry("data.real.entry", 0x10, "[x]")), result["AXVE0"])
    }

    @Test
    fun `a leading UTF-8 BOM on the first line doesn't break parsing`() {
        val text = "\uFEFF//games, header, comment, line\ndata.real,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf(KnownTableEntry("data.real", 0x10, "[x]")), result["AXVE0"])
    }

    @Test
    fun `a format string containing its own commas is captured whole, and doesn't disturb address parsing`() {
        val line = "data.tricky,10,10,10,10,10,10,10,10,10,|s=pocket(0=a|1=b|2=c) some,thing,with,commas"
        val result = KnownTables.parse(line)
        val entry = result.getValue("AXVE0").single()
        assertEquals(0x10, entry.address)
        assertEquals("|s=pocket(0=a|1=b|2=c) some,thing,with,commas", entry.formatText)
    }

    @Test
    fun `a line with too few columns is skipped rather than partially parsed`() {
        val text = "incomplete,10,10\ndata.real,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf(KnownTableEntry("data.real", 0x10, "[x]")), result["AXVE0"])
    }

    @Test
    fun `the bundled resource parses to a substantial table for every known game`() {
        val bundled = KnownTables.bundled
        for (gameCode in KnownTables.GAME_CODES) {
            val count = bundled[gameCode]?.size ?: 0
            assertTrue(count > 100, "expected >100 entries for $gameCode, got $count")
        }
    }

    @Test
    fun `the bundled resource has the well-known pokemon names table for Emerald`() {
        val emerald = KnownTables.bundled.getValue("BPEE0").associate { it.name to it.address }
        assertEquals(0x144, emerald["data.pokemon.names"])
    }

    @Test
    fun `the bundled resource's simple direct palette entry parses with this project's own format parser`() {
        // graphics.pokemon.palettes.egg is a real entry whose format string happens to already
        // be a simple single-palette definition, not a table - exactly the subset
        // RomSessionRepository's format-hint auto-fill relies on being able to hand straight to
        // ImageFormat with no translation. If this ever regresses (the reference file changes
        // this specific entry), the auto-fill feature quietly stops working for it without an
        // obviously-related test failure elsewhere, so it's checked directly here against the
        // real bundled data, not just a hand-written snippet.
        val emerald = KnownTables.bundled.getValue("BPEE0").associateBy { it.name }
        val paletteFormatText = emerald.getValue("graphics.pokemon.palettes.egg").formatText
        assertEquals(PaletteFormat(bits = 4, compressed = false), ImageFormat.parsePalette(paletteFormatText))
    }
}
