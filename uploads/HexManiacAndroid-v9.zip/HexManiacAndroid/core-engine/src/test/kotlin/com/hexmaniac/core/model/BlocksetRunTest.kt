package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class BlocksetRunTest {

    private fun modelWithBytes(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size) { -1 } // 0xFF backdrop, like real ROM free space
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    @Test
    fun `create computes length as blockCount times 16`() {
        val format = BlocksetFormat(blockCount = 4, tilesetAddress = 0)
        val run = BlocksetRun.create(RomDataModel(ByteArray(0x100)), 0, format)
        assertEquals(64, run.length)
    }

    @Test
    fun `create throws when the blockset would run past the end of the ROM`() {
        val format = BlocksetFormat(blockCount = 100, tilesetAddress = 0)
        assertFailsWith<MapFormatException> { BlocksetRun.create(RomDataModel(ByteArray(0x10)), 0, format) }
    }

    @Test
    fun `readBlock returns its 8 sub-tile entries in order`() {
        // block 0: 8 entries, each a distinct recognizable value
        val entries = listOf(
            TilemapEntry(1, hFlip = false, vFlip = false, paletteIndex = 0),
            TilemapEntry(2, hFlip = true, vFlip = false, paletteIndex = 1),
            TilemapEntry(3, hFlip = false, vFlip = true, paletteIndex = 2),
            TilemapEntry(4, hFlip = true, vFlip = true, paletteIndex = 3),
            TilemapEntry(5, paletteIndex = 4),
            TilemapEntry(6, paletteIndex = 5),
            TilemapEntry(7, paletteIndex = 6),
            TilemapEntry(8, paletteIndex = 7),
        )
        val bytes = entries.flatMap { e -> val p = e.pack(); listOf(p and 0xFF, (p shr 8) and 0xFF) }.toIntArray()
        val model = modelWithBytes(0x100, 0 to bytes)
        val run = BlocksetRun.create(model, 0, BlocksetFormat(blockCount = 1, tilesetAddress = 0))

        assertEquals(entries, run.readBlock(model, 0))
    }

    @Test
    fun `readBlock returns default entries for an out-of-range block index`() {
        val model = modelWithBytes(0x100)
        val run = BlocksetRun.create(model, 0, BlocksetFormat(blockCount = 4, tilesetAddress = 0))
        assertEquals(List(8) { TilemapEntry(0) }, run.readBlock(model, 99))
        assertEquals(List(8) { TilemapEntry(0) }, run.readBlock(model, -1))
    }
}
