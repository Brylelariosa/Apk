package com.hexmaniac.core.model

/**
 * Converts between the GBA's native 15-bit color format and 32-bit ARGB. Reference:
 * PaletteRun.cs / DataFormats.cs's UncompressedPaletteColor (this project uses HMA's source as
 * a spec to read, not code to reuse - see README).
 *
 * The GBA packs a color into 15 bits of a 16-bit little-endian half-word: bits 0-4 are red,
 * bits 5-9 are green, bits 10-14 are blue, bit 15 is unused - which is why this format is
 * sometimes called "BGR555" (reading the hex digits high-to-low visually puts blue first).
 * HMA's own C# actually stores this as a *double*-flipped intermediate value internally
 * (`PaletteRun.FlipColorChannels`, applied once when reading bytes into its `short`
 * representation and effectively undone again by `UncompressedPaletteColor.ToRGB`'s own
 * bit positions) purely so the result matches WPF's built-in `PixelFormats.Bgr555` in-memory
 * layout for its `WriteableBitmap`. Both flips together are a no-op on the actual mapping from
 * raw stored bits to displayed R/G/B - confirmed by cross-referencing PaletteRun.cs against
 * IndexedPng.cs's PNG-export scaling (`(color >> 10 & 31) * 255 / 31` for red) and
 * TileImage.cs's color-picker downscale (`color.R >> 3` packed at bit 0) - so [toArgb8888]/
 * [fromArgb8888] below go directly from raw stored bits to on-screen color with no
 * intermediate flip step; Android has no equivalent of WPF's `Bgr555` format to match anyway,
 * since [toArgb8888]'s output feeds `android.graphics.Bitmap.createBitmap`'s `ARGB_8888`
 * directly (see ImageEditorScreen).
 *
 * Named generically ("toArgb8888", not an Android-specific type) since this file has zero
 * Android dependency, same rule every other core-engine file follows (see README's
 * architecture section) - it just happens that packing alpha/red/green/blue into a 32-bit Int
 * in that byte order is a general convention `android.graphics.Bitmap`/`android.graphics.Color`
 * also use, not something that requires importing them.
 */
object GbaColor {
    private const val CHANNEL_BITS = 0x1F // 5 bits, so 0-31 per channel

    /** Raw 15-bit GBA color (as read little-endian from 2 ROM bytes) to 0xAARRGGBB, alpha always 0xFF. */
    fun toArgb8888(raw: Int): Int {
        val r8 = scale5to8(raw and CHANNEL_BITS)
        val g8 = scale5to8((raw shr 5) and CHANNEL_BITS)
        val b8 = scale5to8((raw shr 10) and CHANNEL_BITS)
        return (0xFF shl 24) or (r8 shl 16) or (g8 shl 8) or b8
    }

    /**
     * 0xAARRGGBB (alpha ignored) back to a raw 15-bit GBA color. Lossy in the same direction
     * HMA's own color picker is: `>> 3`, not a rounding `* 31 / 255` - see TileImage.cs's
     * `newColor` construction. Matching that exactly (rather than a "more correct" rounding
     * scale) matters here: it's what makes editing a color and reading it back without
     * changing it a no-op, the same way it is on the PC version.
     */
    fun fromArgb8888(argb: Int): Int {
        val r5 = scale8to5((argb shr 16) and 0xFF)
        val g5 = scale8to5((argb shr 8) and 0xFF)
        val b5 = scale8to5(argb and 0xFF)
        return (b5 shl 10) or (g5 shl 5) or r5
    }

    /** 0-31 to 0-255. Integer division, same as `IndexedPng.cs`'s `* 255 / 31` - not `<< 3`,
     *  which would leave the top end short (31 -> 248, not 255). */
    private fun scale5to8(channel5: Int): Int = channel5 * 255 / 31

    /** 0-255 to 0-31, truncating - see [fromArgb8888]'s doc comment for why this isn't a rounding scale. */
    private fun scale8to5(channel8: Int): Int = channel8 shr 3

    /**
     * An even grayscale ramp of [count] ARGB colors, for rendering a paletted image before any
     * real palette has been paired with it - matches `SpriteTool.CreateDefaultPalette` in the
     * original exactly (`shade = 31 * i / (count - 1)`, packed as a raw GBA color with all three
     * channels equal - which [toArgb8888] resolves correctly regardless of channel order, since
     * a color with R=G=B is unaffected by which channel is which).
     */
    fun grayscaleRamp(count: Int): IntArray = IntArray(count) { i ->
        val shade = if (count <= 1) 0 else 31 * i / (count - 1)
        toArgb8888((shade shl 10) or (shade shl 5) or shade)
    }
}
