package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * A map's block layout occupying ROM bytes from [start]: [MapLayoutFormat.blockTileWidth] x
 * [MapLayoutFormat.blockTileHeight] [BlockEntry] cells, each 2 bytes, always uncompressed - see
 * [MapLayoutFormat]'s doc comment. This is deliberately just the layout grid, not a full map:
 * headers, connections, warps/NPCs/signs, and wild encounters are all out of scope for this pass
 * - see the README's phase notes for what a map-editing feature needs beyond this to be
 * complete, and why this piece came first (nothing else about a map means anything without it).
 */
data class MapLayoutRun(
    override val start: Int,
    val format: MapLayoutFormat,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    companion object {
        /** Builds a [MapLayoutRun] at [start], validating it fits [model] - see
         *  [SpriteRun.create]'s doc comment for why that check lives here rather than in every caller. */
        fun create(model: RomDataModel, start: Int, format: MapLayoutFormat, pointerSources: List<Int> = emptyList()): MapLayoutRun {
            val length = format.decompressedLength
            if (start + length > model.size) {
                throw MapFormatException("This map layout would run past the end of the ROM.")
            }
            return MapLayoutRun(start, format, length, pointerSources)
        }
    }
}

/** The [BlockEntry] at block-grid position ([blockX], [blockY]). Out-of-bounds coordinates read
 *  as an all-zero entry, same fallback used throughout this project's other Run types. */
fun MapLayoutRun.readEntry(model: RomDataModel, blockX: Int, blockY: Int): BlockEntry {
    if (blockX !in 0 until format.blockTileWidth || blockY !in 0 until format.blockTileHeight) return BlockEntry(0)
    val offset = start + (blockY * format.blockTileWidth + blockX) * 2
    return BlockEntry.unpack(model[offset] or (model[offset + 1] shl 8))
}

/**
 * Writes a single [BlockEntry] at ([blockX], [blockY]), always in place. Unlike
 * [SpriteRun.setPixels]/[PaletteRun.setColors]/[TilemapRun.writeEntry], this never relocates and
 * so has no relocated run to return: a [MapLayoutRun] is never compressed (see
 * [MapLayoutFormat]'s doc comment) and this pass doesn't implement resizing a map, so its length
 * can't change for any reason this function would need to react to.
 */
fun MapLayoutRun.writeEntry(model: RomDataModel, blockX: Int, blockY: Int, entry: BlockEntry, token: ModelDelta) {
    require(blockX in 0 until format.blockTileWidth && blockY in 0 until format.blockTileHeight) {
        "($blockX, $blockY) is outside this map's ${format.blockTileWidth}x${format.blockTileHeight} grid."
    }
    val offset = start + (blockY * format.blockTileWidth + blockX) * 2
    val packed = entry.pack()
    token.setByte(model, offset, packed and 0xFF)
    token.setByte(model, offset + 1, (packed shr 8) and 0xFF)
}

/**
 * Composes the full map image: resolves the paired [MapLayoutFormat.blocksetAddress] blockset
 * and its own tileset, then for every cell draws its block's bottom 4 sub-tiles (always opaque)
 * followed by its top 4 (drawn over the bottom, with the top tile's own palette-index-0 pixels
 * left transparent so the bottom shows through). Reference: `BlockmapRun.RenderBlock`/`Read` in
 * the original, whose per-tile "transparent color" argument is exactly this "index 0 is
 * see-through, but only for the top 4 sub-tiles" rule - verified against an independent Python
 * simulation before being trusted here (see [Lz77]'s doc comment for why that extra step, for
 * this kind of bit-level compositing logic specifically).
 *
 * Falls back to an all-zero grid if the blockset or its tileset isn't defined yet, same
 * graceful "still inspectable before its dependencies exist" fallback [TilemapRun.getPixels] uses.
 */
fun MapLayoutRun.getPixels(model: RomDataModel): IntArray {
    val pixelWidth = format.pixelWidth
    val pixelHeight = format.pixelHeight
    val blank = IntArray(pixelWidth * pixelHeight)
    val blockset = model.getRunAt(format.blocksetAddress) as? BlocksetRun ?: return blank
    val tileset = model.getRunAt(blockset.format.tilesetAddress) as? SpriteRun ?: return blank

    val tilesetBytes = tileset.decodedBytes(model)
    val tileByteSize = tileset.format.bitsPerPixel * 8
    val pixels = IntArray(pixelWidth * pixelHeight)

    for (by in 0 until format.blockTileHeight) {
        val yStart = by * 16
        for (bx in 0 until format.blockTileWidth) {
            val xStart = bx * 16
            val entry = readEntry(model, bx, by)
            val subTiles = blockset.readBlock(model, entry.blockIndex)

            for (sub in 0 until 8) {
                val subEntry = subTiles[sub]
                val quadrant = sub % 4
                val layer = sub / 4
                val qx = (quadrant % 2) * 8
                val qy = (quadrant / 2) * 8
                val tileStart = subEntry.tileIndex * tileByteSize
                val tilePixels = decodeTilePixels(tilesetBytes, tileStart, 1, 1, tileset.format.bitsPerPixel)

                for (yy in 0 until 8) {
                    for (xx in 0 until 8) {
                        val inX = if (subEntry.hFlip) 7 - xx else xx
                        val inY = if (subEntry.vFlip) 7 - yy else yy
                        val rawIndex = tilePixels[inY * 8 + inX]
                        if (layer == 1 && rawIndex == 0) continue // top layer: transparent, bottom shows through
                        pixels[(yStart + qy + yy) * pixelWidth + (xStart + qx + xx)] = rawIndex + (subEntry.paletteIndex shl 4)
                    }
                }
            }
        }
    }
    return pixels
}
