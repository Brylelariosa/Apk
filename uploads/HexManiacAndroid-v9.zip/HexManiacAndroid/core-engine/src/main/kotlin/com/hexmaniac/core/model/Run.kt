package com.hexmaniac.core.model

/**
 * A typed span of bytes within the ROM, mirroring HexManiacAdvance's IFormattedRun/BaseRun.
 *
 * Runs are immutable value objects: "modifying" one (e.g. adding a pointer source) produces
 * a new Run rather than mutating in place, same as the original's Clone-on-write pattern.
 *
 * This is `sealed`, not open, on purpose: every case lives in this file or one of
 * [TableRun]/[StringRun]/[SpriteRun]/[PaletteRun]/[TilemapRun]/[BlocksetRun]/[MapLayoutRun]'s own
 * files, all in this same package. Nothing in the codebase switches over every case at once
 * today - each editor narrows to the specific Run type it cares about instead (e.g.
 * `romSession.runAt(address) is TableRun`, or [TilemapRun.getPixels]'s `getRunAt(...) as?
 * SpriteRun` to find its tileset) - but the moment something does need to, an exhaustive
 * `when (run)` over it will fail to compile as soon as a future phase adds another case, until
 * that `when` is updated too - the compiler catching what code review might miss.
 */
sealed interface Run {
    val start: Int
    val length: Int

    /** Addresses of pointers elsewhere in the ROM that reference this run's start. */
    val pointerSources: List<Int>

    val end: Int get() = start + length
}

operator fun Run.contains(address: Int): Boolean = address >= start && address < end

/** An uninterpreted span of bytes - the default state before any structure is recognized. */
data class UnknownRun(
    override val start: Int,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run

/** A 4-byte little-endian GBA pointer. Raw stored value = fileOffset + 0x08000000. */
data class PointerRun(
    override val start: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    override val length: Int get() = 4
}
