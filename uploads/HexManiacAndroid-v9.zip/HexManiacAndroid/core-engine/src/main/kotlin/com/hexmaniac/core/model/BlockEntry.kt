package com.hexmaniac.core.model

/**
 * One cell of a [MapLayoutRun]: which block from the paired [BlocksetRun] to draw, plus a
 * collision/elevation value the game engine uses for movement rules. Reference:
 * `BlockMapViewModel.GetBlock`/`DrawBlock` in the original C# (this project uses HMA's source as
 * a spec to read, not code to reuse - see README) - the same 10-bits-index/6-bits-metadata split
 * [TilemapEntry] uses for its flip/palette bits, just with a different meaning for the upper
 * bits here. [collisionIndex] is read and preserved by this port but not interpreted or exposed
 * for editing yet - see [MapLayoutRun]'s doc comment for what that leaves out of scope.
 */
data class BlockEntry(
    val blockIndex: Int,
    val collisionIndex: Int = 0,
) {
    fun pack(): Int = (blockIndex and 0x3FF) or ((collisionIndex and 0x3F) shl 10)

    companion object {
        fun unpack(raw: Int): BlockEntry = BlockEntry(
            blockIndex = raw and 0x3FF,
            collisionIndex = (raw shr 10) and 0x3F,
        )
    }
}
