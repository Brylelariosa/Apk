package com.hexmaniac.core.model

/**
 * One line of `tableReference.txt` for one specific game version: a known name, the address it
 * lives at in that exact ROM, and the original's own format-string text for it (untouched,
 * un-translated - see [KnownTables]'s doc comment for what a caller can and can't safely do
 * with [formatText]).
 */
data class KnownTableEntry(val name: String, val address: Int, val formatText: String)

/**
 * Parses HexManiacAdvance's own `tableReference.txt` - reference: `Models/Code/tableReference.txt`
 * in the original source, bundled verbatim as a resource on this module's classpath
 * (`core-engine/src/main/resources/tableReference.txt`) rather than retyped, since transcribing
 * ~800 hardcoded hex addresses by hand risks introducing exactly the kind of error this project's
 * Python-verification habit (see [Lz77]'s doc comment) exists to avoid - copying the original
 * file mechanically and parsing it doesn't have that risk, and dropping in a newer copy of the
 * same file is enough to pick up future additions.
 *
 * Each line is `name, <address for each of 9 game versions>, format string`. The format-string
 * column uses a much richer grammar (nested and dynamic-length arrays, switch/record fields,
 * bit-arrays, cross-references to other tables' lengths, ...) than this project's simplified
 * [TableFormat]/[ImageFormat] DSL supports, and this object makes no attempt to translate it -
 * doing that correctly for ~800 entries without being able to compile-check any of it would be a
 * separate, much larger, and much riskier undertaking than parsing hex out of a CSV-like column.
 *
 * What it *is* safe to do, and what
 * [RomSessionRepository][com.hexmaniac.app.data.RomSessionRepository] does with [formatText]:
 * hand it as-is to [TableFormat.parse]/[ImageFormat.parseSprite]/[parsePalette][ImageFormat.parsePalette]/
 * [parseTilemap][ImageFormat.parseTilemap] and see whether it happens to parse. A meaningful
 * fraction of real entries - anything that's already a single sprite/palette/tilemap or a simple
 * table rather than a nested/dynamic structure - use exactly this project's own syntax, since
 * that syntax was itself modeled on the original's for the cases it covers (see e.g.
 * `` `lzs4x8x8` ``/`` `lzp4` `` appearing verbatim in the real file). No translation happens
 * either way: either the original's own text parses as-is, or it's left for the person to type a
 * format themselves, exactly as if this bundled data didn't exist for that entry.
 */
object KnownTables {
    /** The 9 game-version codes this reference file has columns for, in column order - see
     *  [GameCode] for what a code looks like and how it's read from a ROM. */
    val GAME_CODES = listOf("AXVE0", "AXPE0", "AXVE1", "AXPE1", "BPRE0", "BPGE0", "BPRE1", "BPGE1", "BPEE0")

    /** Every known [KnownTableEntry] for [gameCode], parsed once and cached - this is static
     *  reference data, not something that varies per ROM instance. */
    val bundled: Map<String, List<KnownTableEntry>> by lazy {
        val text = javaClass.getResourceAsStream("/tableReference.txt")
            ?.bufferedReader(Charsets.UTF_8)
            ?.readText()
            .orEmpty()
        parse(text)
    }

    /**
     * Parses [referenceText] in the format described in this object's doc comment. Exposed
     * separately from [bundled] so it's testable against small hand-written snippets without
     * needing the real ~40KB resource file in play.
     */
    fun parse(referenceText: String): Map<String, List<KnownTableEntry>> {
        val byGame = GAME_CODES.associateWith { mutableListOf<KnownTableEntry>() }
        for (rawLine in referenceText.lineSequence()) {
            val line = rawLine.trim().removePrefix("\uFEFF") // tolerate a leading UTF-8 BOM on the first line
            if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) continue

            val columns = line.split(",", limit = GAME_CODES.size + 2)
            if (columns.size < GAME_CODES.size + 1) continue
            val name = columns[0].trim()
            if (name.isEmpty()) continue
            val formatText = columns.getOrNull(GAME_CODES.size + 1)?.trim().orEmpty()

            for ((i, gameCode) in GAME_CODES.withIndex()) {
                val address = columns[1 + i].trim().toIntOrNull(16) ?: continue
                byGame.getValue(gameCode).add(KnownTableEntry(name, address, formatText))
            }
        }
        return byGame
    }
}
