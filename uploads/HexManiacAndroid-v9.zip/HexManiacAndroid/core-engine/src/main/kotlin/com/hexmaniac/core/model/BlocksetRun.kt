package com.hexmaniac.core.model

/**
 * A flat table of blocks occupying ROM bytes from [start], never compressed - see
 * [BlocksetFormat]'s doc comment for why. Each block is 8 [TilemapEntry]-shaped sub-tile
 * references (4 bottom-layer, 4 top-layer): a "block" is a tiny fixed-size tilemap (2x2 tiles
 * per layer) bundled into one reusable, nameable 16x16-pixel unit, which [MapLayoutRun] then
 * arranges into a full map the same way a [TilemapRun] arranges individual tiles - see
 * [MapLayoutRun.getPixels] for how the two layers combine.
 */
data class BlocksetRun(
    override val start: Int,
    val format: BlocksetFormat,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    companion object {
        /** Builds a [BlocksetRun] at [start], validating it fits [model] - see
         *  [SpriteRun.create]'s doc comment for why that check lives here rather than in every caller. */
        fun create(model: RomDataModel, start: Int, format: BlocksetFormat, pointerSources: List<Int> = emptyList()): BlocksetRun {
            val length = format.decompressedLength
            if (start + length > model.size) {
                throw MapFormatException("This blockset would run past the end of the ROM.")
            }
            return BlocksetRun(start, format, length, pointerSources)
        }
    }
}

/**
 * The 8 sub-tile [TilemapEntry] values making up block [blockIndex]: entries 0-3 are the bottom
 * layer (always opaque when composed), 4-7 are the top layer (drawn over the bottom, with the
 * top tile's own palette-index-0 pixels left transparent - see [MapLayoutRun.getPixels]). A
 * [blockIndex] outside `0 until` [BlocksetFormat.blockCount] reads as 8 all-zero entries rather
 * than throwing, the same missing-data fallback used throughout this project's other Run types.
 */
fun BlocksetRun.readBlock(model: RomDataModel, blockIndex: Int): List<TilemapEntry> {
    if (blockIndex !in 0 until format.blockCount) return List(8) { TilemapEntry(0) }
    val blockStart = start + blockIndex * format.bytesPerBlock
    return (0 until 8).map { i ->
        val offset = blockStart + i * 2
        TilemapEntry.unpack(model[offset] or (model[offset + 1] shl 8))
    }
}
