package com.hexmaniac.core.model

/** Thrown by [MapFormat]'s parse functions with a message meant to be shown directly to the user. */
class MapFormatException(message: String) : Exception(message)

/**
 * A flat table of [blockCount] blocks, each a 16x16-pixel unit made of 8 [TilemapEntry]-shaped
 * sub-tile references into the [tilesetAddress] tileset - see [BlocksetRun]'s doc comment for
 * why a block is "just" 8 of those glued together rather than its own pixel format.
 *
 * The original splits every real map's blocks across two tilesets ("primary", shared by many
 * maps in a region, and "secondary", specific to one area) with a substantial amount of
 * merging/estimation logic between them (`BlocksetModel` in `BlockmapRun.cs` is ~330 lines just
 * for that). This project simplifies to one blockset per map, referencing one tileset - see the
 * README's "differs from the original" note for why that's a deliberate, documented scope cut
 * rather than a half-finished version of the real split.
 */
data class BlocksetFormat(
    val blockCount: Int,
    val tilesetAddress: Int,
) {
    init {
        require(blockCount in 1..1024) { "blockCount must be 1-1024, was $blockCount." }
        require(tilesetAddress >= 0) { "Tileset address must be non-negative." }
    }

    /** 8 sub-tile entries per block, 2 bytes each - the same fixed layout real GBA map data
     *  uses, not something this project chose independently. */
    val bytesPerBlock: Int get() = 16
    val decompressedLength: Int get() = blockCount * bytesPerBlock
}

/**
 * A map's block layout: [blockTileWidth] x [blockTileHeight] cells, each a 2-byte [BlockEntry]
 * referencing a block in the [blocksetAddress] blockset. Reference: the `map<>` field of the
 * original's `layout<[...]>` structure (see [BlocksetRun]'s doc comment for the rest of that
 * structure this project doesn't otherwise model - map headers, connections, events, wild
 * encounters are all out of scope for this pass; see the README).
 *
 * Always uncompressed - real Gen 3 map layout data isn't LZ-compressed the way sprites/tilesets/
 * palettes almost always are (only the referenced tileset's own graphics are), so unlike
 * [SpriteFormat]/[PaletteFormat]/[TilemapFormat] there's no compressed variant to parse here.
 */
data class MapLayoutFormat(
    val blockTileWidth: Int,
    val blockTileHeight: Int,
    val blocksetAddress: Int,
) {
    init {
        require(blockTileWidth in 1..255) { "blockTileWidth must be 1-255, was $blockTileWidth." }
        require(blockTileHeight in 1..255) { "blockTileHeight must be 1-255, was $blockTileHeight." }
        require(blocksetAddress >= 0) { "Blockset address must be non-negative." }
    }

    val bytesPerEntry: Int get() = 2
    val decompressedLength: Int get() = blockTileWidth * blockTileHeight * bytesPerEntry
    val pixelWidth: Int get() = blockTileWidth * 16
    val pixelHeight: Int get() = blockTileHeight * 16
}

/**
 * Parses this project's own compact format strings for [BlocksetFormat]/[MapLayoutFormat] - not
 * translations of anything in the original's format-string grammar (unlike [TableFormat]/
 * [ImageFormat], which do mirror HMA's own DSL, just a documented subset of it - see their doc
 * comments). A block layout isn't one of the ~800 [KnownTables] entries either, so there's no
 * existing notation from the original to stay compatible with here the way there was for
 * sprites/palettes/tilemaps.
 *
 *   - Blockset: `` `blk{blockCount}|{tilesetAddress}` ``, e.g. `` `blk512|1A2B3C` ``
 *   - Map layout: `` `map{blockTileWidth}x{blockTileHeight}|{blocksetAddress}` ``, e.g. `` `map20x16|400000` ``
 *
 * Both address slots accept a [KnownTables]/user-defined anchor name in place of hex, via the
 * same optional `resolveAddress` callback [ImageFormat.parseTilemap] uses for its tileset
 * reference, for the same reason - see that function's doc comment.
 */
object MapFormat {
    fun parseBlockset(formatText: String, resolveAddress: (String) -> Int? = { null }): BlocksetFormat {
        val body = unwrap(formatText, "blk")
        val pipeIndex = body.indexOf('|')
        if (pipeIndex < 0) {
            throw MapFormatException("Expected '`blk{blockCount}|{tilesetAddress}`', e.g. '`blk512|1A2B3C`'.")
        }
        val countText = body.substring(0, pipeIndex)
        val blockCount = countText.toIntOrNull() ?: throw MapFormatException("'$countText' isn't a valid block count.")

        val addressText = body.substring(pipeIndex + 1).trim().removePrefix("0x")
        val tilesetAddress = addressText.toIntOrNull(16)
            ?: resolveAddress(addressText)
            ?: throw MapFormatException("'$addressText' isn't a valid hex address or known name.")

        return try {
            BlocksetFormat(blockCount, tilesetAddress)
        } catch (e: IllegalArgumentException) {
            throw MapFormatException(e.message ?: "Invalid blockset format.")
        }
    }

    fun parseMapLayout(formatText: String, resolveAddress: (String) -> Int? = { null }): MapLayoutFormat {
        val body = unwrap(formatText, "map")
        val pipeIndex = body.indexOf('|')
        if (pipeIndex < 0) {
            throw MapFormatException("Expected '`map{width}x{height}|{blocksetAddress}`', e.g. '`map20x16|400000`'.")
        }
        val dimensions = body.substring(0, pipeIndex).split("x")
        if (dimensions.size != 2) {
            throw MapFormatException("Expected '{width}x{height}' before '|', got '${body.substring(0, pipeIndex)}'.")
        }
        val width = dimensions[0].toIntOrNull() ?: throw MapFormatException("'${dimensions[0]}' isn't a valid width.")
        val height = dimensions[1].toIntOrNull() ?: throw MapFormatException("'${dimensions[1]}' isn't a valid height.")

        val addressText = body.substring(pipeIndex + 1).trim().removePrefix("0x")
        val blocksetAddress = addressText.toIntOrNull(16)
            ?: resolveAddress(addressText)
            ?: throw MapFormatException("'$addressText' isn't a valid hex address or known name.")

        return try {
            MapLayoutFormat(width, height, blocksetAddress)
        } catch (e: IllegalArgumentException) {
            throw MapFormatException(e.message ?: "Invalid map layout format.")
        }
    }

    private fun unwrap(formatText: String, prefix: String): String {
        val text = formatText.trim()
        if (!text.startsWith("`$prefix") || !text.endsWith("`")) {
            throw MapFormatException("Expected a format starting with '`$prefix'.")
        }
        return text.substring(1 + prefix.length, text.length - 1)
    }
}
