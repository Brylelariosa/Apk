package com.hexmaniac.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

/**
 * A searchable list of known anchor names, so finding e.g. `data.pokemon.names` means scrolling
 * or typing a few letters of it rather than needing to already know - or type - its exact hex
 * address. The UI counterpart to
 * [com.hexmaniac.app.data.RomSessionRepository.knownAnchorNames]/`formatHintAt`, used by every
 * editor's address field via a "Browse" button next to it.
 *
 * Shown inline, not as a dialog - swapping part of the form for a result in place, the same way
 * every other in-place state change in this app works (an open table replacing its own define
 * form, an edit bar appearing under a selected cell), rather than introducing this app's first
 * use of a floating overlay for something that fits perfectly well inline on a phone screen.
 */
@Composable
fun AnchorBrowser(
    names: List<String>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(names, query) {
        if (query.isBlank()) names else names.filter { it.contains(query, ignoreCase = true) }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search ${names.size} known names") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
        Spacer(modifier = Modifier.height(4.dp))
        if (names.isEmpty()) {
            Text(
                "No known names for this ROM - its header wasn't recognized as one of the base " +
                    "games this app has reference data for (see the README).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp),
            )
        } else if (filtered.isEmpty()) {
            Text(
                "No known name matches \"$query\".",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp),
            )
        } else {
            LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                items(filtered) { name ->
                    Text(
                        text = name,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(name) }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                    )
                }
            }
        }
    }
}
