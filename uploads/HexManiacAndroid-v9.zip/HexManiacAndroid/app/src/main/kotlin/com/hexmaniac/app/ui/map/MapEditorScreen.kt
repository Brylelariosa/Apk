package com.hexmaniac.app.ui.map

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hexmaniac.app.ui.EmptyRomState
import com.hexmaniac.app.ui.HexManiacTopBar
import com.hexmaniac.app.ui.PixelGridImage

/**
 * A blockset definition form, then a map layout definition form that references it, then the
 * composed map with tap-a-cell editing - the same define-then-edit shape every other editor in
 * this app uses. See [MapEditorViewModel]'s doc comment for exactly what this covers and what it
 * deliberately doesn't yet (block contents, headers, connections, events, wild encounters).
 */
@Composable
fun MapEditorScreen(
    viewModel: MapEditorViewModel,
    onBack: () -> Unit,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    val state = viewModel.uiState

    Scaffold(
        topBar = {
            HexManiacTopBar(
                title = "Map Editor",
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    TextButton(onClick = onSaveRomRequested, enabled = state.romLoaded) { Text("Save") }
                    TextButton(onClick = viewModel::undo, enabled = state.canUndo) { Text("Undo") }
                    TextButton(onClick = viewModel::redo, enabled = state.canRedo) { Text("Redo") }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (!state.romLoaded) {
                EmptyRomState("Open a .gba file before viewing a map.", onOpenRomRequested)
            } else {
                Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
                    BlocksetSection(viewModel, state)
                    Spacer(modifier = Modifier.height(16.dp))
                    LayoutSection(viewModel, state)
                }
            }
            Text(
                text = state.statusMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun BlocksetSection(viewModel: MapEditorViewModel, state: MapEditorUiState) {
    val blockset = state.blockset
    if (blockset == null) {
        Text("Blockset", style = MaterialTheme.typography.titleSmall)
        DefineRow(
            addressText = state.blocksetAddressText,
            onAddressChange = viewModel::updateBlocksetAddressText,
            formatText = state.blocksetFormatText,
            onFormatChange = viewModel::updateBlocksetFormatText,
            formatHint = "`blk512|<tileset addr>`",
            onDefine = viewModel::defineBlockset,
        )
        return
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            "Blockset 0x${blockset.start.toString(16).uppercase()} - ${blockset.format.blockCount} blocks",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = viewModel::clearBlockset) { Text("Close") }
    }
}

@Composable
private fun LayoutSection(viewModel: MapEditorViewModel, state: MapEditorUiState) {
    val layout = state.layout
    if (layout == null) {
        Text("Map layout", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
        DefineRow(
            addressText = state.layoutAddressText,
            onAddressChange = viewModel::updateLayoutAddressText,
            formatText = state.layoutFormatText,
            onFormatChange = viewModel::updateLayoutFormatText,
            formatHint = "`map20x16|<blockset addr>`",
            onDefine = viewModel::defineLayout,
        )
        return
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            "Layout 0x${layout.start.toString(16).uppercase()} - ${layout.format.blockTileWidth}x${layout.format.blockTileHeight} blocks",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = viewModel::clearLayout) { Text("Close") }
    }

    val pixels = viewModel.renderedLayoutPixels()
    if (pixels != null) {
        PixelGridImage(
            pixelsArgb = pixels,
            width = layout.format.pixelWidth,
            height = layout.format.pixelHeight,
            onSelect = { px, py -> viewModel.selectBlock(px / 16, py / 16) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        )
    }

    if (state.selectedBlockX != null && state.selectedBlockY != null) {
        BlockEditBar(viewModel, state)
    }
}

@Composable
private fun BlockEditBar(viewModel: MapEditorViewModel, state: MapEditorUiState) {
    val x = state.selectedBlockX ?: return
    val y = state.selectedBlockY ?: return
    val entry = viewModel.selectedBlockEntry()
    var text by remember(x, y, state.revision) {
        mutableStateOf(entry?.pack()?.toString(16)?.uppercase()?.padStart(4, '0') ?: "0000")
    }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            "Block ($x, $y)" + (entry?.let { ": block ${it.blockIndex.toString(16).uppercase()}, collision ${it.collisionIndex.toString(16).uppercase()}" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(4) },
                modifier = Modifier.width(96.dp),
                singleLine = true,
                placeholder = { Text("hex entry") },
            )
            TextButton(onClick = { viewModel.writeSelectedBlock(text) }, modifier = Modifier.padding(start = 8.dp)) { Text("Set") }
        }
    }
}

@Composable
private fun DefineRow(
    addressText: String,
    onAddressChange: (String) -> Unit,
    formatText: String,
    onFormatChange: (String) -> Unit,
    formatHint: String,
    onDefine: () -> Unit,
) {
    OutlinedTextField(
        value = addressText,
        onValueChange = onAddressChange,
        label = { Text("Start address (hex or name)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
        value = formatText,
        onValueChange = onFormatChange,
        label = { Text("Format") },
        placeholder = { Text(formatHint) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(12.dp))
    TextButton(onClick = onDefine) { Text("Define") }
}
