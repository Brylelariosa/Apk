package com.hexmaniac.app.ui.text

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hexmaniac.app.ui.AnchorBrowser
import com.hexmaniac.app.ui.EmptyRomState
import com.hexmaniac.app.ui.HexManiacTopBar
import com.hexmaniac.core.model.StringRun

// Text actions instead of icons, same reasoning as HexViewerScreen/TableEditorScreen:
// material-icons-extended was deliberately dropped for APK size.

@Composable
fun TextEditorScreen(
    viewModel: TextEditorViewModel,
    onBack: () -> Unit,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    val state = viewModel.uiState
    val run = state.stringRun

    Scaffold(
        topBar = {
            HexManiacTopBar(
                title = "Text Editor",
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    if (run != null) {
                        TextButton(onClick = viewModel::clearString) { Text("New") }
                    }
                    // Saves the whole ROM session, same as every other screen's Save - see
                    // TableEditorScreen's comment on its own Save button for why.
                    TextButton(onClick = onSaveRomRequested, enabled = state.romLoaded) { Text("Save") }
                    TextButton(onClick = viewModel::undo, enabled = state.canUndo) { Text("Undo") }
                    TextButton(onClick = viewModel::redo, enabled = state.canRedo) { Text("Redo") }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                !state.romLoaded -> EmptyRomState("Open a .gba file before editing text.", onOpenRomRequested)
                run == null -> DefineStringForm(viewModel, state)
                else -> StringEditor(viewModel, state, run, modifier = Modifier.weight(1f))
            }
            Text(
                text = state.statusMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun DefineStringForm(viewModel: TextEditorViewModel, state: TextEditorUiState) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text("Open a string", style = MaterialTheme.typography.titleMedium)
        Text(
            "Address in hex, or a known name. Reads PCS text forward from there until the " +
                "terminator - most characters show up as themselves; anything else becomes a " +
                "\\-escape token (see PcsString for exactly which).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
        )
        if (state.showBrowser) {
            AnchorBrowser(
                names = viewModel.knownNames(),
                onSelect = viewModel::selectFromBrowser,
                onDismiss = viewModel::toggleBrowser,
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = state.addressText,
                    onValueChange = viewModel::updateAddressText,
                    label = { Text("Start address (hex or name)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = viewModel::toggleBrowser) { Text("Browse") }
            }
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(onClick = viewModel::openString) { Text("Open") }
        }
    }
}

@Composable
private fun StringEditor(
    viewModel: TextEditorViewModel,
    state: TextEditorUiState,
    run: StringRun,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth().padding(16.dp)) {
        Text(
            "0x${run.start.toString(16).uppercase()} - ${run.length} bytes",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = state.text,
            onValueChange = viewModel::updateEditText,
            singleLine = false,
            modifier = Modifier.fillMaxWidth().weight(1f),
        )
        Spacer(modifier = Modifier.height(8.dp))
        // "Set" to match TableEditorScreen's per-cell commit button - "Save" is reserved for
        // writing the whole ROM session to disk (the button in the top bar).
        TextButton(onClick = viewModel::writeString) { Text("Set") }
    }
}
