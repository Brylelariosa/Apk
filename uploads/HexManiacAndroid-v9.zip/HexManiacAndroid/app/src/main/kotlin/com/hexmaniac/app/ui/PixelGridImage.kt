package com.hexmaniac.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize

/**
 * Renders [pixelsArgb] ([width] x [height], row-major) as a real [Bitmap] rather than a grid of
 * individual Composables - unlike [HexViewerScreen]'s byte grid, an image here can be tens of
 * thousands of pixels (a full tileset, a large tilemap, a map), and a `Box` per pixel at that
 * scale is both slower to compose and a worse visual result (no true image scaling) than letting
 * Android's own Bitmap pipeline do it. [FilterQuality.None] keeps pixel art crisp when scaled up
 * rather than blurring it.
 *
 * Shared by [com.hexmaniac.app.ui.image.ImageEditorScreen] (sprites and tilemaps) and
 * [com.hexmaniac.app.ui.map.MapEditorScreen] (composed maps) - each of those has its own
 * per-pixel color/palette logic, but the actual "turn a row-major ARGB array into a tappable,
 * crisply-scaled image" concern is identical, so it lives here once rather than three times.
 *
 * [onSelect] always reports *pixel* coordinates; a caller working in a coarser unit (e.g.
 * selecting a whole 8x8 tile or 16x16 block) divides down itself, which keeps this composable
 * generic rather than baking in a "cell size" concept only some callers have.
 */
@Composable
fun PixelGridImage(
    pixelsArgb: IntArray,
    width: Int,
    height: Int,
    onSelect: (x: Int, y: Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val bitmap = remember(pixelsArgb.contentHashCode(), width, height) {
        Bitmap.createBitmap(pixelsArgb, width, height, Bitmap.Config.ARGB_8888).asImageBitmap()
    }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }

    Image(
        bitmap = bitmap,
        contentDescription = null,
        filterQuality = FilterQuality.None,
        modifier = modifier
            .aspectRatio(width.toFloat() / height.toFloat())
            .onSizeChanged { boxSize = it }
            .pointerInput(width, height) {
                detectTapGestures(onTap = { offset ->
                    val size = boxSize
                    if (size.width <= 0 || size.height <= 0) return@detectTapGestures
                    val x = (offset.x / size.width * width).toInt().coerceIn(0, width - 1)
                    val y = (offset.y / size.height * height).toInt().coerceIn(0, height - 1)
                    onSelect(x, y)
                })
            },
    )
}
