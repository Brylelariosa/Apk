package com.hexmaniac.app.ui.map

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.app.data.RomSessionRepository
import com.hexmaniac.core.model.BlockEntry
import com.hexmaniac.core.model.BlocksetRun
import com.hexmaniac.core.model.GbaColor
import com.hexmaniac.core.model.MapFormat
import com.hexmaniac.core.model.MapFormatException
import com.hexmaniac.core.model.MapLayoutRun
import com.hexmaniac.core.model.SpriteRun
import com.hexmaniac.core.model.getPixels
import com.hexmaniac.core.model.readEntry
import com.hexmaniac.core.model.writeEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

data class MapEditorUiState(
    val romLoaded: Boolean = false,

    val blocksetAddressText: String = "",
    val blocksetFormatText: String = "",
    val blockset: BlocksetRun? = null,

    val layoutAddressText: String = "",
    val layoutFormatText: String = "",
    val layout: MapLayoutRun? = null,
    val selectedBlockX: Int? = null,
    val selectedBlockY: Int? = null,

    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Define a blockset, then a map layout that references it.",
    val revision: Int = 0,
)

/**
 * Map layout viewing and cell editing: a blockset (a table of 16x16-pixel blocks, each 8
 * sub-tile references into a [SpriteRun] tileset - see [BlocksetRun]'s doc comment) and a map
 * layout (a grid of which block goes where, plus a collision value - see [MapLayoutRun]'s doc
 * comment). The underlying tileset is defined through the existing Sprite panel
 * ([com.hexmaniac.app.ui.image.ImageEditorViewModel]), not duplicated here - a blockset's format
 * string references it by address (or [KnownTables][com.hexmaniac.core.model.KnownTables]/
 * user-defined anchor name) exactly the way a tilemap's format string references its tileset,
 * so defining one sprite once is reusable from both editors.
 *
 * This is deliberately narrower than a full map editor: it shows the composed map and lets a
 * cell's *block index* be changed, not a block's own *contents* (which sub-tiles make it up) or
 * anything about map headers, connections, events, or wild encounters - see [MapLayoutRun]'s doc
 * comment and the README for what that leaves for a later pass, and why this piece - the layout
 * grid itself - came first.
 */
@HiltViewModel
class MapEditorViewModel @Inject constructor(
    private val romSession: RomSessionRepository,
) : ViewModel() {

    var uiState by mutableStateOf(MapEditorUiState(romLoaded = romSession.session.romLoaded))
        private set

    fun syncFromSession() {
        uiState = uiState.copy(
            romLoaded = romSession.session.romLoaded,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
        )
    }

    fun updateBlocksetAddressText(text: String) { uiState = uiState.copy(blocksetAddressText = text) }
    fun updateBlocksetFormatText(text: String) { uiState = uiState.copy(blocksetFormatText = text) }
    fun updateLayoutAddressText(text: String) { uiState = uiState.copy(layoutAddressText = text) }
    fun updateLayoutFormatText(text: String) { uiState = uiState.copy(layoutFormatText = text) }

    // --- blockset ---

    fun clearBlockset() {
        uiState = uiState.copy(blockset = null, statusMessage = "Define a blockset, then a map layout that references it.")
    }

    fun defineBlockset() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }
        val address = romSession.resolveAddress(uiState.blocksetAddressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.blocksetAddressText}' isn't a valid address or known name in this ROM.")
            return
        }

        val existing = romSession.runAt(address)
        val run = if (existing is BlocksetRun) {
            existing
        } else {
            val format = try {
                MapFormat.parseBlockset(uiState.blocksetFormatText, resolveAddress = romSession::resolveAddress)
            } catch (e: MapFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
                return
            }
            try {
                BlocksetRun.create(model, address, format).also { romSession.addRun(it) }
            } catch (e: MapFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid blockset data.")
                return
            }
        }

        val tilesetFound = model.getRunAt(run.format.tilesetAddress) is SpriteRun
        val anchor = romSession.anchorAt(address)?.let { "$it - " } ?: ""
        val tilesetNote = if (tilesetFound) "" else {
            " No sprite is defined at 0x${run.format.tilesetAddress.toString(16).uppercase()} yet, so blocks will render blank."
        }
        uiState = uiState.copy(
            blockset = run,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "$anchor${run.format.blockCount} blocks, ${run.length} bytes.$tilesetNote",
            revision = uiState.revision + 1,
        )
    }

    // --- map layout ---

    fun clearLayout() {
        uiState = uiState.copy(layout = null, selectedBlockX = null, selectedBlockY = null)
    }

    fun defineLayout() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }
        val address = romSession.resolveAddress(uiState.layoutAddressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.layoutAddressText}' isn't a valid address or known name in this ROM.")
            return
        }

        val existing = romSession.runAt(address)
        val run = if (existing is MapLayoutRun) {
            existing
        } else {
            val format = try {
                MapFormat.parseMapLayout(uiState.layoutFormatText, resolveAddress = romSession::resolveAddress)
            } catch (e: MapFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
                return
            }
            try {
                MapLayoutRun.create(model, address, format).also { romSession.addRun(it) }
            } catch (e: MapFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid map layout data.")
                return
            }
        }

        val blocksetFound = model.getRunAt(run.format.blocksetAddress) is BlocksetRun
        val anchor = romSession.anchorAt(address)?.let { "$it - " } ?: ""
        val blocksetNote = if (blocksetFound) "" else {
            " No blockset is defined at 0x${run.format.blocksetAddress.toString(16).uppercase()} yet, so the map will render blank."
        }
        uiState = uiState.copy(
            layout = run,
            selectedBlockX = null,
            selectedBlockY = null,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "$anchor${run.format.blockTileWidth}x${run.format.blockTileHeight} blocks, ${run.length} bytes.$blocksetNote",
            revision = uiState.revision + 1,
        )
    }

    fun selectBlock(blockX: Int, blockY: Int) {
        uiState = uiState.copy(selectedBlockX = blockX, selectedBlockY = blockY)
    }

    /** The [BlockEntry] at the currently-selected cell, for prefilling the edit field. */
    fun selectedBlockEntry(): BlockEntry? {
        val run = uiState.layout ?: return null
        val model = romSession.currentModel ?: return null
        val x = uiState.selectedBlockX ?: return null
        val y = uiState.selectedBlockY ?: return null
        return run.readEntry(model, x, y)
    }

    /** Composed ARGB pixels for the currently-open map layout - see [MapLayoutRun.getPixels]'s
     *  doc comment for how bottom/top block layers combine. Unlike the Image Editor's sprite/
     *  tilemap panels, there's no palette to pair here: a block's own palette-index nibble
     *  (folded in by [MapLayoutRun.getPixels] the same way a tilemap's is) has nowhere to look
     *  up real colors without also modeling a map's multiple palette slots, so this always
     *  renders against [GbaColor.grayscaleRamp] - real color support is future work, not this
     *  pass. A composed index can run up to 255 regardless of the tileset's own bit depth (a
     *  4bpp tile's palette nibble alone can push it past 15), so the ramp always covers the
     *  full range - see [com.hexmaniac.app.ui.image.ImageEditorViewModel.renderedTilemapPixels]
     *  for the identical reasoning. */
    fun renderedLayoutPixels(): IntArray? {
        val run = uiState.layout ?: return null
        val model = romSession.currentModel ?: return null
        val indices = run.getPixels(model)
        val colors = GbaColor.grayscaleRamp(256)
        return IntArray(indices.size) { i -> colors.getOrElse(indices[i]) { BLACK_ARGB } }
    }

    fun writeSelectedBlock(hexEntryText: String) {
        val run = uiState.layout ?: return
        val model = romSession.currentModel ?: return
        val x = uiState.selectedBlockX ?: return
        val y = uiState.selectedBlockY ?: return

        val raw = hexEntryText.trim().removePrefix("0x").toIntOrNull(16)
        if (raw == null || raw !in 0..0xFFFF) {
            uiState = uiState.copy(statusMessage = "'$hexEntryText' isn't a valid 16-bit hex block entry.")
            return
        }
        val entry = BlockEntry.unpack(raw)

        romSession.applyEdit { m, token -> run.writeEntry(m, x, y, entry, token) }
        uiState = uiState.copy(
            statusMessage = "Saved (block ${entry.blockIndex.toString(16).uppercase()}, collision ${entry.collisionIndex.toString(16).uppercase()}).",
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    fun undo() {
        romSession.undo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Undid last edit.",
            revision = uiState.revision + 1,
        )
    }

    fun redo() {
        romSession.redo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Redid edit.",
            revision = uiState.revision + 1,
        )
    }

    private companion object {
        const val BLACK_ARGB = 0xFF000000.toInt()
    }
}
