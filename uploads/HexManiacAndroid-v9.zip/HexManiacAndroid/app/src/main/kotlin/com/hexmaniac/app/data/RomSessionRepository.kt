package com.hexmaniac.app.data

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hexmaniac.core.model.GameCode
import com.hexmaniac.core.model.KnownTables
import com.hexmaniac.core.model.PointerScanner
import com.hexmaniac.core.model.RomDataModel
import com.hexmaniac.core.model.Run
import com.hexmaniac.core.undo.ModelDelta
import com.hexmaniac.core.undo.UndoRedoStack
import java.io.ByteArrayOutputStream
import java.util.BitSet
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the currently-loaded ROM - bytes, runs, anchors, and undo history - as a single
 * [Singleton] source of truth. Every screen (hex viewer, table editor, and whatever later phases
 * add) reads and writes through here instead of holding its own copy, so an edit made on one
 * screen is immediately visible, undoable, and included when saving from any other.
 *
 * On [load], if the ROM's header identifies it as one of the known base games (see [GameCode]),
 * every address [KnownTables] has on record for that exact version is auto-named via
 * [RomDataModel.setAnchor] - the same "open a recognized ROM and its known tables are already
 * there" experience the original gives for its own hardcoded games, for the subset of that data
 * this project bundles (see [KnownTables]'s doc comment for what that subset is). A romhack
 * based on one of these games, or an unrecognized ROM entirely, gets none of this - there's no
 * anchor to load without an exact header match, the same way the original can't either.
 *
 * Extracted out of what was originally [com.hexmaniac.app.ui.HexViewerViewModel]'s private state,
 * at the point a second screen needed the same ROM - see that class's doc comment. Screens are
 * responsible for pulling fresh values from [session] when they become visible again (see
 * `syncFromSession()` on each screen's ViewModel); this class doesn't push updates to them, to
 * avoid taking on a Flow/StateFlow dependency for two screens that don't need one yet.
 */
@Singleton
class RomSessionRepository @Inject constructor() {

    private var model: RomDataModel? = null
    private var undoRedo = UndoRedoStack()

    // BitSet, not Set<Int>: a 32MB ROM can have millions of pointer-covered bytes - one bit
    // each instead of a boxed Integer each matters at that scale (same reasoning as the
    // original HexViewerViewModel had for this field).
    private var pointerHighlights = BitSet()

    // The original's own format-string text for whichever KnownTables entries landed an anchor
    // in load() below, keyed by address - UI-only presentation data (see formatHintAt's doc
    // comment for what it's for), not core ROM state, so it lives here rather than on
    // RomDataModel alongside the anchors themselves.
    private var formatHintByAddress: Map<Int, String> = emptyMap()

    var session by mutableStateOf(RomSession())
        private set

    /** The live model, for callers that need direct read/write access (e.g. table field I/O). */
    val currentModel: RomDataModel? get() = model

    val pointerByteCount: Int get() = pointerHighlights.cardinality()

    fun load(resolver: ContentResolver, uri: Uri): Boolean {
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            input.copyTo(buffer)
            buffer.toByteArray()
        } ?: return false

        val newModel = RomDataModel(bytes)
        val gameCode = GameCode.read(newModel)
        val knownEntries = gameCode?.let { KnownTables.bundled[it] }.orEmpty()
        val hints = mutableMapOf<Int, String>()
        for (entry in knownEntries) {
            if (entry.address !in 0 until newModel.size) continue
            newModel.setAnchor(entry.address, entry.name)
            if (entry.formatText.isNotEmpty()) hints[entry.address] = entry.formatText
        }

        model = newModel
        undoRedo = UndoRedoStack()
        pointerHighlights = BitSet()
        formatHintByAddress = hints
        session = RomSession(
            romLoaded = true,
            romName = uri.lastPathSegment ?: "ROM",
            romSize = bytes.size,
            gameName = gameCode?.let { GameCode.displayName(it) },
        )
        return true
    }

    fun save(resolver: ContentResolver, uri: Uri): Boolean {
        val m = model ?: return false
        resolver.openOutputStream(uri)?.use { out -> out.write(m.snapshotBytes()) }
        return true
    }

    fun byteAt(index: Int): Int? = model?.let { if (index < it.size) it[index] else null }

    fun isPointerByte(index: Int): Boolean = pointerHighlights.get(index)

    fun runAt(address: Int): Run? = model?.getRunAt(address)

    /** The anchor name at [address], if one has been set - either by [load]'s auto-detection or
     *  by [nameAddress]. */
    fun anchorAt(address: Int): String? = model?.anchorAt(address)

    /**
     * Every currently-known anchor name, sorted - what a "browse instead of type an address"
     * picker in any editor's address field shows, so finding e.g. `data.pokemon.names` means
     * scrolling/searching a list rather than needing to already know it exists or how to spell
     * it. Empty before a ROM is loaded, or for a ROM [load] didn't recognize - see that
     * function's doc comment for why (unrecognized ROMs have nothing bundled to name).
     */
    fun knownAnchorNames(): List<String> = model?.anchors?.values?.sorted().orEmpty()

    /**
     * The original's own format-string text for [address], if [load] found one alongside its
     * anchor - for an editor to try parsing with its own format parser
     * ([com.hexmaniac.core.model.TableFormat.parse]/
     * [com.hexmaniac.core.model.ImageFormat.parseSprite]/etc.) and, when that succeeds, skip
     * asking the person to type a format at all. See [KnownTables]'s doc comment for why this is
     * always either the original's exact text or nothing - never a translated/adapted version.
     */
    fun formatHintAt(address: Int): String? = formatHintByAddress[address]

    /** Attaches [name] to [address] as a user-defined anchor - the manual counterpart to
     *  [load]'s auto-detection, for a structure the bundled reference data doesn't know about.
     *  Like [addRun], not undoable - see [RomDataModel.setAnchor]'s doc comment. */
    fun nameAddress(address: Int, name: String) {
        model?.setAnchor(address, name)
        bumpRevision()
    }

    /**
     * Interprets [text] as either a hex address or a known anchor name, so every address field
     * in the app accepts both interchangeably - matching how the original's own address fields
     * do, per [load]'s doc comment. Hex is tried first: an anchor name always contains a `.`
     * (every entry in [KnownTables] and every name this app lets a user type - see
     * `TableEditorViewModel`/`TextEditorViewModel`/`ImageEditorViewModel`'s address fields - uses
     * that convention), which by itself is never valid hex, so there's no real ambiguity between
     * the two in practice. Returns null if neither resolves, the ROM isn't loaded, or the
     * resolved address is out of range.
     */
    fun resolveAddress(text: String): Int? {
        val m = model ?: return null
        val trimmed = text.trim()
        val address = trimmed.removePrefix("0x").removePrefix("0X").toIntOrNull(16)
            ?: m.addressForAnchor(trimmed)
            ?: return null
        return address.takeIf { it in 0 until m.size }
    }

    /**
     * Registers a newly-recognized [Run] (e.g. a table a user just defined). Not undoable -
     * only byte content goes through [applyEdit]; recognizing a shape in existing bytes isn't a
     * content edit, same as how the original's pointer scan never touched undo history either.
     */
    fun addRun(run: Run) {
        model?.addRun(run)
        bumpRevision()
    }

    /**
     * Runs [edit] as one undoable step, then pushes it. [edit] receives the live model and a
     * fresh [ModelDelta] token to write through - same contract [ModelDelta.setByte] itself uses.
     * A no-op [edit] is safe: [UndoRedoStack.push] already ignores empty deltas.
     */
    fun applyEdit(edit: (RomDataModel, ModelDelta) -> Unit) {
        val m = model ?: return
        val delta = ModelDelta()
        edit(m, delta)
        undoRedo.push(delta)
        bumpRevision()
    }

    fun scanForPointers(): Int {
        val m = model ?: return 0
        val found = PointerScanner.scan(m)
        val bits = BitSet(m.size)
        for (run in found) for (i in run.start until run.start + run.length) bits.set(i)
        pointerHighlights = bits
        bumpRevision()
        return found.size
    }

    fun undo() {
        val m = model ?: return
        undoRedo.undo(m)
        bumpRevision()
    }

    fun redo() {
        val m = model ?: return
        undoRedo.redo(m)
        bumpRevision()
    }

    private fun bumpRevision() {
        session = session.copy(
            canUndo = undoRedo.canUndo,
            canRedo = undoRedo.canRedo,
            revision = session.revision + 1,
        )
    }
}

data class RomSession(
    val romLoaded: Boolean = false,
    val romName: String? = null,
    val romSize: Int = 0,
    /** A display name like "Emerald" if [load] recognized the ROM's header - see [GameCode]. */
    val gameName: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val revision: Int = 0,
)
