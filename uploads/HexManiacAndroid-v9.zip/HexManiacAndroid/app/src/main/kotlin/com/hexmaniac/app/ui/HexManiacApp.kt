package com.hexmaniac.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.hexmaniac.app.ui.image.ImageEditorScreen
import com.hexmaniac.app.ui.image.ImageEditorViewModel
import com.hexmaniac.app.ui.map.MapEditorScreen
import com.hexmaniac.app.ui.map.MapEditorViewModel
import com.hexmaniac.app.ui.table.TableEditorScreen
import com.hexmaniac.app.ui.table.TableEditorViewModel
import com.hexmaniac.app.ui.text.TextEditorScreen
import com.hexmaniac.app.ui.text.TextEditorViewModel

/**
 * Top-level screens the app can show. There's no deeper stack yet - see [HexManiacApp]'s doc
 * comment for why this is a plain sealed interface instead of Navigation Compose.
 */
sealed interface HexManiacScreen {
    data object HexViewer : HexManiacScreen
    data object TableEditor : HexManiacScreen
    data object TextEditor : HexManiacScreen
    data object ImageEditor : HexManiacScreen
    data object MapEditor : HexManiacScreen
}

/**
 * Root composable: owns which top-level screen is showing, routes the system back button, and
 * re-syncs each destination's ViewModel from [com.hexmaniac.app.data.RomSessionRepository] at
 * the moment it becomes visible - an edit made on another screen wouldn't otherwise be
 * reflected, since each ViewModel's `uiState` is its own plain `mutableStateOf`, not something
 * that reacts to the repository automatically. See `syncFromSession()` on
 * [HexViewerViewModel]/[TableEditorViewModel]/[TextEditorViewModel]/[ImageEditorViewModel]/
 * [MapEditorViewModel].
 *
 * Deliberately not Jetpack Navigation Compose: a handful of top-level tool screens, all exactly
 * one level deep (everything routes back to the hex viewer, nothing nests further) and no deep
 * links, is more easily and transparently handled by the `when` below than by a NavHost - which
 * would also add two more dependency versions this sandbox has no way to compile-check (see the
 * README's build-verification note). Worth revisiting once a later phase needs an actual
 * multi-level back stack.
 */
@Composable
fun HexManiacApp(
    hexViewerViewModel: HexViewerViewModel,
    tableEditorViewModel: TableEditorViewModel,
    textEditorViewModel: TextEditorViewModel,
    imageEditorViewModel: ImageEditorViewModel,
    mapEditorViewModel: MapEditorViewModel,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    var screen by remember { mutableStateOf<HexManiacScreen>(HexManiacScreen.HexViewer) }

    fun goToHexViewer() {
        hexViewerViewModel.syncFromSession()
        screen = HexManiacScreen.HexViewer
    }

    fun goToTableEditor(prefillAddress: Int?) {
        tableEditorViewModel.syncFromSession(prefillAddress)
        screen = HexManiacScreen.TableEditor
    }

    fun goToTextEditor(prefillAddress: Int?) {
        textEditorViewModel.syncFromSession(prefillAddress)
        screen = HexManiacScreen.TextEditor
    }

    fun goToImageEditor(prefillAddress: Int?) {
        imageEditorViewModel.syncFromSession(prefillAddress)
        screen = HexManiacScreen.ImageEditor
    }

    fun goToMapEditor() {
        mapEditorViewModel.syncFromSession()
        screen = HexManiacScreen.MapEditor
    }

    BackHandler(enabled = screen != HexManiacScreen.HexViewer) { goToHexViewer() }

    when (screen) {
        HexManiacScreen.HexViewer -> HexViewerScreen(
            viewModel = hexViewerViewModel,
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
            onOpenTableEditor = { address -> goToTableEditor(address) },
            onOpenTextEditor = { address -> goToTextEditor(address) },
            onOpenImageEditor = { address -> goToImageEditor(address) },
            onOpenMapEditor = { goToMapEditor() },
        )
        HexManiacScreen.TableEditor -> TableEditorScreen(
            viewModel = tableEditorViewModel,
            onBack = { goToHexViewer() },
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
        )
        HexManiacScreen.TextEditor -> TextEditorScreen(
            viewModel = textEditorViewModel,
            onBack = { goToHexViewer() },
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
        )
        HexManiacScreen.ImageEditor -> ImageEditorScreen(
            viewModel = imageEditorViewModel,
            onBack = { goToHexViewer() },
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
        )
        HexManiacScreen.MapEditor -> MapEditorScreen(
            viewModel = mapEditorViewModel,
            onBack = { goToHexViewer() },
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
        )
    }
}
