package com.torrix.app

import android.app.Application
import android.content.Context
import com.torrix.app.diag.CrashLog
import com.torrix.app.engine.EngineController
import com.torrix.app.service.Notifier

class TorrixApp : Application() {
    lateinit var engine: EngineController
        private set

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // First thing in the process: from here on every crash is written to Download/Torrix-log-*.txt
        CrashLog.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        CrashLog.note("Application.onCreate")
        Notifier.createChannels(this)
        CrashLog.note("notification channels ready")
        engine = EngineController(this)
        CrashLog.note("EngineController created")
        engine.start()
        CrashLog.note("engine.start() returned")
    }
}
