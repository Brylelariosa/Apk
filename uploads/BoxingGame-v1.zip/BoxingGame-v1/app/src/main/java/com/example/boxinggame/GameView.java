package com.example.boxinggame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    // ── Game states ───────────────────────────────────────────
    private enum State { MENU, COUNTDOWN, FIGHTING, ROUND_END, GAME_OVER }

    // ── Thread ────────────────────────────────────────────────
    private Thread      thread;
    private volatile boolean running = false;
    private final SurfaceHolder holder;

    // ── Game state ────────────────────────────────────────────
    private State  state      = State.MENU;
    private Boxer  player, opp;
    private int    round      = 1;
    private static final int MAX_ROUNDS = 3;
    private int    roundTimer = 60 * 60;
    private int    cdVal      = 3;          // countdown 3 2 1
    private int    cdFrames   = 60;
    private int    roundEndFrames = 0;
    private String roundEndMsg   = "";
    private String winnerMsg     = "";
    private boolean fightBannerActive = false;
    private int    fightBannerFrames  = 0;

    // ── Screen ────────────────────────────────────────────────
    private float W = 1, H = 1, S = 1;
    private boolean sizeKnown = false;

    // ── Buttons  [0]=stepBack [1]=stepFwd [2]=jab [3]=cross [4]=hook [5]=block ──
    private final RectF[] btnRects = new RectF[6];
    {  for (int i = 0; i < 6; i++) btnRects[i] = new RectF(); }
    private final boolean[] btnDown      = new boolean[6];
    private final int[]     btnPointer   = {-1,-1,-1,-1,-1,-1};

    // ── Hit FX ────────────────────────────────────────────────
    private float  hitFxX = 0, hitFxY = 0;
    private int    hitFxTimer = 0;
    private float  shakeX = 0, shakeY = 0;
    private int    shakeFrames = 0;

    // ── Combo ─────────────────────────────────────────────────
    private int playerCombo      = 0;
    private int comboShowFrames  = 0;

    // ── Paints ────────────────────────────────────────────────
    private Paint pBg, pRing, pFloor, pShadow;
    private Paint pSkin, pSkinOpp, pGloveRed, pGloveBlue;
    private Paint pShortsRed, pShortsBlue, pBlack, pWhite, pOrange;
    private Paint pHudBg;
    private Paint pBarBg, pBarHp, pBarHpLow, pBarSt;
    private Paint pBtnBg, pBtnBorder;

    // ─────────────────────────────────────────────────────────
    public GameView(Context ctx) {
        super(ctx);
        holder = getHolder();
        holder.addCallback(this);
        setFocusable(true);
        initPaints();
    }

    // ── Paint helpers ─────────────────────────────────────────
    private Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        return p;
    }
    private Paint stroke(int color, float w) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w);
        return p;
    }
    private Paint text(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color); p.setTextAlign(Paint.Align.CENTER);
        return p;
    }

    private void initPaints() {
        pBg       = fill(Color.rgb(15,10,8));
        pRing     = fill(Color.rgb(205,182,138));
        pFloor    = fill(Color.rgb(185,160,115));
        pShadow   = fill(Color.argb(70,0,0,0));
        pSkin     = fill(Color.rgb(215,165,115));
        pSkinOpp  = fill(Color.rgb(185,130,80));
        pGloveRed = fill(Color.rgb(200,40,40));
        pGloveBlue= fill(Color.rgb(40,80,205));
        pShortsRed= fill(Color.rgb(175,25,25));
        pShortsBlue=fill(Color.rgb(25,55,175));
        pBlack    = fill(Color.rgb(20,15,10));
        pWhite    = fill(Color.WHITE);
        pOrange   = fill(Color.rgb(255,160,0));
        pHudBg    = fill(Color.argb(170,0,0,0));
        pBarBg    = fill(Color.argb(180,40,40,40));
        pBarHp    = fill(Color.rgb(220,50,50));
        pBarHpLow = fill(Color.rgb(255,200,0));
        pBarSt    = fill(Color.rgb(50,130,220));
        pBtnBg    = fill(Color.argb(160,30,30,50));
        pBtnBorder= stroke(Color.argb(90,255,255,255), 0);
    }

    // ── Surface callbacks ─────────────────────────────────────
    @Override public void surfaceCreated(SurfaceHolder h)  { resume(); }
    @Override public void surfaceDestroyed(SurfaceHolder h){ pause();  }

    @Override
    public void surfaceChanged(SurfaceHolder h, int fmt, int w, int ht) {
        W = w; H = ht; S = H / 700f;
        layoutButtons();
        if (!sizeKnown) { initGame(); sizeKnown = true; }
    }

    private void initGame() {
        float gy = H * 0.73f;
        player = new Boxer(W * 0.28f, gy, true,  true);
        opp    = new Boxer(W * 0.72f, gy, false, false);
        opp.aiDifficulty = 1;
        round = 1; state = State.MENU;
    }

    private void layoutButtons() {
        float bBot = H - 6f * S;
        float bH   = 58f * S;
        float bTop = bBot - bH;

        // Step buttons (left side)
        float stW = 55f * S;
        btnRects[0].set(6*S,       bTop, 6*S + stW,        bBot); // step back
        btnRects[1].set(68*S,      bTop, 68*S + stW,       bBot); // step fwd

        // Attack buttons (right side, 4 equal)
        float attR  = W - 6f * S;
        float attW  = 62f * S;
        float gap   = 5f  * S;
        btnRects[5].set(attR - attW,             bTop, attR,              bBot); // block
        btnRects[4].set(attR - attW*2 - gap,     bTop, attR - attW - gap, bBot); // hook
        btnRects[3].set(attR - attW*3 - gap*2,   bTop, attR - attW*2 - gap*2, bBot); // cross
        btnRects[2].set(attR - attW*4 - gap*3,   bTop, attR - attW*3 - gap*3, bBot); // jab
    }

    // ── Thread ────────────────────────────────────────────────
    public void resume() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop);
        thread.start();
    }

    public void pause() {
        running = false;
        try { if (thread != null) thread.join(2000); } catch (InterruptedException ignored) {}
    }

    private void loop() {
        final long TARGET = 16L;
        while (running) {
            long t0 = System.currentTimeMillis();
            if (sizeKnown) update();
            Canvas c = holder.lockCanvas();
            if (c != null) {
                try { if (sizeKnown) draw(c); else c.drawColor(Color.BLACK); }
                finally { holder.unlockCanvasAndPost(c); }
            }
            long dt = System.currentTimeMillis() - t0;
            if (dt < TARGET) { try { Thread.sleep(TARGET - dt); } catch (InterruptedException e) { break; } }
        }
    }

    // ═══════════════════════ UPDATE ════════════════════════════

    private void update() {
        switch (state) {
            case MENU:      break;
            case COUNTDOWN: updateCountdown(); break;
            case FIGHTING:  updateFighting();  break;
            case ROUND_END:
                roundEndFrames--;
                if (roundEndFrames <= 0) nextRoundOrEnd();
                break;
            case GAME_OVER: break;
        }
    }

    private void updateCountdown() {
        cdFrames--;
        if (cdFrames <= 0) {
            cdVal--;
            if (cdVal <= 0) {
                state = State.FIGHTING;
                fightBannerActive = true;
                fightBannerFrames = 45;
            } else {
                cdFrames = 60;
            }
        }
    }

    private void updateFighting() {
        // Fight! banner timer
        if (fightBannerActive) {
            fightBannerFrames--;
            if (fightBannerFrames <= 0) fightBannerActive = false;
        }

        // Block hold
        if (btnDown[5]) player.startBlock(); else player.stopBlock();

        // Step buttons (applied every frame while held)
        if (btnDown[0]) player.moveBack();
        if (btnDown[1]) player.moveForward();

        // Keep facing correct direction
        player.facingRight = (player.x < opp.x);
        opp.facingRight    = (opp.x   < player.x);

        // Update both boxers
        float margin = 80f * S;
        player.update(margin, W - margin);
        opp.update(margin, W - margin);

        // Prevent overlap
        float minDist = 60f * S;
        float dist    = Math.abs(player.x - opp.x);
        if (dist < minDist && dist > 0.01f) {
            float push = (minDist - dist) * 0.5f;
            if (player.x < opp.x) { player.x -= push; opp.x += push; }
            else                  { player.x += push; opp.x -= push; }
        }

        // Hit detection
        processHit(player, opp, true);
        processHit(opp, player, false);

        // AI
        updateAI();

        // Screen shake
        if (shakeFrames > 0) {
            shakeFrames--;
            float mag = shakeFrames * 0.35f;
            shakeX = (float)(Math.random() * mag * 2 - mag);
            shakeY = (float)(Math.random() * mag * 2 - mag);
        } else { shakeX = shakeY = 0; }

        // Hit spark timer
        if (hitFxTimer > 0) hitFxTimer--;

        // Combo display
        if (comboShowFrames > 0) comboShowFrames--;

        // Round timer
        roundTimer--;
        if (roundTimer <= 0) {
            if (player.health > opp.health) endRound("YOU WIN
by Decision", true);
            else if (opp.health > player.health) endRound("OPPONENT WINS
by Decision", false);
            else endRound("DRAW", false);
            return;
        }

        // KO check
        if (player.isKO()) endRound("K.O.!
Opponent Wins", false);
        else if (opp.isKO()) endRound("K.O.!
You Win!", true);
    }

    private void processHit(Boxer attacker, Boxer defender, boolean fromPlayer) {
        if (!attacker.isActiveFistFrame()) return;
        if (attacker.hitDealt) return;

        float fx = attacker.fistScreenX(S);
        float fy = attacker.fistScreenY(S);
        float fr = attacker.fistRadius(S);

        if (fx + fr > defender.bodyLeft(S) && fx - fr < defender.bodyRight(S) &&
            fy + fr > defender.bodyTop(S)  && fy - fr < defender.bodyBottom(S)) {

            attacker.hitDealt = true;
            float dmg = attacker.getAttackDamage();
            float kb  = attacker.getAttackKnockback(S);
            defender.receiveHit(dmg, kb);

            hitFxX = fx; hitFxY = fy;
            hitFxTimer = 14;
            if (dmg >= 14f) shakeFrames = (int)(dmg * 0.9f);
            else if (dmg >= 8f) shakeFrames = 6;

            if (fromPlayer && !defender.isBlocking()) {
                playerCombo++;
                comboShowFrames = 90;
            }
        }
    }

    private void updateAI() {
        if (opp.action == Boxer.Action.KNOCKED_DOWN) return;
        if (opp.aiCooldown > 0) return;

        float dist = Math.abs(player.x - opp.x);
        float atkRange = 130f * S;

        // React to incoming punch: try to block
        if (player.isActiveFistFrame() && dist < atkRange * 1.1f) {
            int blockPct = 18 + opp.aiDifficulty * 12;   // 30%/42%/54%
            if ((int)(Math.random() * 100) < blockPct) {
                opp.startBlock();
                opp.aiCooldown = 18;
                return;
            }
        } else {
            if (!player.isActiveFistFrame()) opp.stopBlock();
        }

        switch (opp.aiState) {
            case APPROACH:
                if (dist > atkRange * 1.1f) {
                    opp.moveForward();
                } else {
                    opp.aiState = Boxer.AIState.AGGRESSIVE;
                    opp.aiCooldown = 8 + (int)(Math.random() * 16);
                }
                break;

            case AGGRESSIVE:
                if (dist > atkRange * 1.25f) {
                    opp.aiState = Boxer.AIState.APPROACH;
                    break;
                }
                if (dist < atkRange) {
                    int r = (int)(Math.random() * 10);
                    boolean attacked;
                    if      (r < 4) attacked = opp.doJab();
                    else if (r < 7) attacked = opp.doCross();
                    else            attacked = opp.doHook();

                    if (attacked) {
                        int baseCd = 22 - opp.aiDifficulty * 4;   // diff 1=18 2=14 3=10
                        opp.aiCooldown = baseCd + (int)(Math.random() * 30);
                        if (Math.random() < 0.28) opp.aiState = Boxer.AIState.BACKING_OFF;
                    }
                } else {
                    opp.moveForward();
                }
                break;

            case BACKING_OFF:
                opp.moveBack();
                opp.aiCooldown = 12;
                if (Math.random() < 0.12) opp.aiState = Boxer.AIState.APPROACH;
                break;

            case DEFENSIVE:
                opp.startBlock();
                opp.aiCooldown = 10;
                if (Math.random() < 0.06) opp.aiState = Boxer.AIState.AGGRESSIVE;
                break;
        }
    }

    private void endRound(String msg, boolean playerWon) {
        roundEndMsg = msg;
        roundEndFrames = 200;
        state = State.ROUND_END;
        if (playerWon) player.roundsWon++;
        else           opp.roundsWon++;
        playerCombo = 0;
    }

    private void nextRoundOrEnd() {
        int needed = (MAX_ROUNDS / 2) + 1;
        if (player.roundsWon >= needed) {
            winnerMsg = "YOU WIN THE MATCH!"; state = State.GAME_OVER;
        } else if (opp.roundsWon >= needed) {
            winnerMsg = "OPPONENT WINS";       state = State.GAME_OVER;
        } else if (round >= MAX_ROUNDS) {
            if      (player.roundsWon > opp.roundsWon) winnerMsg = "YOU WIN THE MATCH!";
            else if (opp.roundsWon > player.roundsWon)  winnerMsg = "OPPONENT WINS";
            else                                         winnerMsg = "IT'S A DRAW";
            state = State.GAME_OVER;
        } else {
            round++;
            opp.aiDifficulty = Math.min(3, round);
            player.resetForRound(W * 0.28f);
            opp.resetForRound(W * 0.72f);
            roundTimer = 60 * 60;
            cdVal = 3; cdFrames = 60;
            state = State.COUNTDOWN;
        }
    }

    // ═══════════════════════ DRAW ══════════════════════════════

    private void draw(Canvas c) {
        c.save();
        c.translate(shakeX, shakeY);

        switch (state) {
            case MENU:
                drawMenu(c); break;
            case COUNTDOWN:
                drawArena(c); drawBoxers(c); drawHUD(c);
                drawCountdown(c); break;
            case FIGHTING:
                drawArena(c); drawBoxers(c); drawHitFx(c); drawHUD(c);
                drawButtons(c); drawCombo(c);
                if (fightBannerActive) drawFightBanner(c);
                break;
            case ROUND_END:
                drawArena(c); drawBoxers(c); drawHUD(c); drawRoundEnd(c); break;
            case GAME_OVER:
                drawArena(c); drawBoxers(c); drawGameOver(c); break;
        }
        c.restore();
    }

    // ── Menu ──────────────────────────────────────────────────
    private void drawMenu(Canvas c) {
        c.drawRect(0, 0, W, H, pBg);

        Paint glow = fill(Color.argb(40, 255, 200, 0));
        c.drawOval(new RectF(W*0.3f, H*0.1f, W*0.7f, H*0.7f), glow);

        Paint title = text(Color.rgb(255,220,50));
        title.setTextSize(85*S); title.setFakeBoldText(true);
        c.drawText("BOXING", W/2, H*0.32f, title);
        c.drawText("CHAMP", W/2, H*0.46f, title);

        Paint sub = text(Color.rgb(210,210,210));
        sub.setTextSize(20*S);
        c.drawText("3 ROUNDS  •  60 SECONDS EACH", W/2, H*0.58f, sub);
        sub.setTextSize(15*S); sub.setColor(Color.rgb(160,160,160));
        c.drawText("◄ ►  MOVE        JAB  CROSS  HOOK  BLOCK", W/2, H*0.66f, sub);

        long ms = System.currentTimeMillis();
        if ((ms / 600) % 2 == 0) {
            Paint tap = text(Color.WHITE); tap.setTextSize(26*S); tap.setFakeBoldText(true);
            c.drawText("TAP TO START", W/2, H*0.80f, tap);
        }
    }

    // ── Arena (ring) ──────────────────────────────────────────
    private void drawArena(Canvas c) {
        c.drawRect(0, 0, W, H, pBg);

        // Audience gradient suggestion (just dark rects at edges)
        Paint crowd = fill(Color.argb(60, 80, 60, 40));
        c.drawRect(0, 0, W, H*0.14f, crowd);

        // Ring canvas
        c.drawRoundRect(new RectF(W*0.015f, H*0.13f, W*0.985f, H*0.80f), 18*S, 18*S, pRing);

        // Floor panel
        c.drawRoundRect(new RectF(W*0.015f, H*0.70f, W*0.985f, H*0.80f), 10*S, 10*S, pFloor);

        // Center line
        Paint cLine = stroke(Color.argb(50,0,0,0), 2*S);
        c.drawLine(W/2, H*0.13f, W/2, H*0.80f, cLine);

        // Ropes (3 colors)
        int[]   ropeColors = { Color.rgb(195,45,45), Color.rgb(230,230,230), Color.rgb(45,85,195) };
        float[] ropeYs     = { H*0.195f, H*0.295f, H*0.395f };
        for (int i = 0; i < 3; i++) {
            Paint rp = stroke(ropeColors[i], 5*S);
            rp.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(W*0.018f, ropeYs[i], W*0.982f, ropeYs[i], rp);
        }

        // Corner posts
        Paint post = fill(Color.rgb(90,70,50));
        float pw = 11*S;
        for (float px : new float[]{ W*0.018f, W*0.982f }) {
            c.drawRect(px - pw, H*0.13f, px + pw, H*0.80f, post);
        }
        // Post highlights
        Paint postHl = fill(Color.argb(50,255,255,200));
        for (float px : new float[]{ W*0.018f, W*0.982f }) {
            c.drawRect(px - pw, H*0.13f, px - pw*0.3f, H*0.80f, postHl);
        }
    }

    // ── Boxers ────────────────────────────────────────────────
    private void drawBoxers(Canvas c) {
        drawShadow(c, player);
        drawShadow(c, opp);
        drawBoxer(c, player, pShortsRed,  pGloveRed,  pSkin);
        drawBoxer(c, opp,    pShortsBlue, pGloveBlue, pSkinOpp);
    }

    private void drawShadow(Canvas c, Boxer b) {
        float sw = 42*S, sh = 10*S;
        c.drawOval(new RectF(b.x-sw, b.y-sh, b.x+sw, b.y+sh), pShadow);
    }

    private void drawBoxer(Canvas c, Boxer b,
            Paint shortsPaint, Paint glovePaint, Paint skinPaint) {

        if (b.action == Boxer.Action.KNOCKED_DOWN) {
            drawKO(c, b, shortsPaint, glovePaint, skinPaint);
            return;
        }

        float bx = b.x, by = b.y, s = S;
        boolean fr = b.facingRight;

        // Flash white on hit
        Paint skin = (b.flashTimer > 0 && (b.flashTimer % 3) < 2) ? pWhite : skinPaint;
        Paint glove = (b.flashTimer > 0 && (b.flashTimer % 3) < 2) ? pWhite : glovePaint;

        // Idle bob offset
        float bob = 0f;
        if (b.action == Boxer.Action.IDLE || b.action == Boxer.Action.BLOCK) {
            bob = (float)(Math.sin(b.idleBob * Math.PI / 30.0) * 2.2 * s);
        }

        // ── Key Y positions ──
        float feetY      = by;
        float hipY       = feetY - 60f*s;
        float torsoBot   = hipY + 5f*s;
        float torsoTop   = feetY - 210f*s + bob;
        float shoulderY  = feetY - 205f*s + bob;
        float headCY     = feetY - 242f*s + bob;
        float headR      = 32f*s;

        // ── Shoes ──
        float shoeW = 28f*s, shoeH = 9f*s;
        float lShoeX = bx - 18f*s, rShoeX = bx + 18f*s;
        c.drawRoundRect(new RectF(lShoeX-shoeW*0.5f, feetY-shoeH, lShoeX+shoeW*0.8f, feetY), 4*s, 4*s, pBlack);
        c.drawRoundRect(new RectF(rShoeX-shoeW*0.8f, feetY-shoeH, rShoeX+shoeW*0.5f, feetY), 4*s, 4*s, pBlack);
        // shoe stripe
        Paint shoeStripe = fill(Color.argb(120,255,255,255));
        c.drawRect(lShoeX-shoeW*0.5f+2*s, feetY-shoeH+2*s, lShoeX+shoeW*0.8f-2*s, feetY-shoeH+5*s, shoeStripe);
        c.drawRect(rShoeX-shoeW*0.8f+2*s, feetY-shoeH+2*s, rShoeX+shoeW*0.5f-2*s, feetY-shoeH+5*s, shoeStripe);

        // ── Legs ──
        float thighW = 18f*s;
        float kneeY  = feetY - 35f*s;
        float legBobL = (float)(Math.sin(b.idleBob * Math.PI / 30.0) * 1.5 * s);
        float legBobR = -legBobL;

        // Left thigh
        c.drawRoundRect(new RectF(bx - 26f*s, hipY, bx - 26f*s + thighW, kneeY + legBobL), thighW*0.5f, thighW*0.5f, skin);
        // Left shin
        c.drawRoundRect(new RectF(bx - 26f*s + 1*s, kneeY + legBobL, bx - 26f*s + thighW - 1*s, feetY - shoeH + 2*s), thighW*0.4f, thighW*0.4f, skin);

        // Right thigh
        c.drawRoundRect(new RectF(bx + 26f*s - thighW, hipY, bx + 26f*s, kneeY + legBobR), thighW*0.5f, thighW*0.5f, skin);
        // Right shin
        c.drawRoundRect(new RectF(bx + 26f*s - thighW + 1*s, kneeY + legBobR, bx + 26f*s - 1*s, feetY - shoeH + 2*s), thighW*0.4f, thighW*0.4f, skin);

        // ── Shorts ──
        c.drawRoundRect(new RectF(bx - 50f*s, hipY - 5f*s, bx + 50f*s, hipY + 22f*s), 6*s, 6*s, shortsPaint);
        // Shorts stripe
        Paint sStripe = fill(Color.argb(70,255,255,255));
        c.drawRect(bx - 4f*s, hipY - 5f*s, bx + 4f*s, hipY + 22f*s, sStripe);

        // ── Torso ──
        float torsoW = 46f*s;
        c.drawRoundRect(new RectF(bx - torsoW, torsoTop, bx + torsoW, torsoBot), 12*s, 12*s, skin);
        // Torso shading (darker on sides)
        Paint torsoShade = fill(Color.argb(30,0,0,0));
        c.drawRoundRect(new RectF(bx - torsoW, torsoTop, bx - torsoW*0.6f, torsoBot), 12*s, 12*s, torsoShade);
        c.drawRoundRect(new RectF(bx + torsoW*0.6f, torsoTop, bx + torsoW, torsoBot), 12*s, 12*s, torsoShade);

        // ── Arms ──
        float leadShX = fr ? bx - 36f*s : bx + 36f*s;
        float powerShX= fr ? bx + 36f*s : bx - 36f*s;

        float[] lf = getLeadFist(b, bx, by, s, fr);
        float[] pf = getPowerFist(b, bx, by, s, fr);

        drawArm(c, leadShX,  shoulderY, lf[0], lf[1], 14f*s, skin, glove);
        drawArm(c, powerShX, shoulderY, pf[0], pf[1], 14f*s, skin, glove);

        // ── Head ──
        c.drawCircle(bx, headCY, headR, skin);
        // Ear
        c.drawCircle(fr ? bx - headR*0.9f : bx + headR*0.9f, headCY + 3*s, 6*s, skin);
        // Headgear
        Paint hg = new Paint(shortsPaint); hg.setAlpha(200);
        c.drawArc(new RectF(bx-headR, headCY-headR, bx+headR, headCY+headR), 180, 180, false, hg);
        c.drawLine(bx - headR, headCY, bx - headR, headCY + 10*s, hg);
        c.drawLine(bx + headR, headCY, bx + headR, headCY + 10*s, hg);
        // Headgear padding top
        Paint hgPad = fill(Color.argb(100,255,255,255));
        c.drawArc(new RectF(bx-headR+2*s, headCY-headR+2*s, bx+headR-2*s, headCY+headR-2*s), 185, 170, false, hgPad);

        // Eyes
        float eyeY = headCY - 4f*s;
        float eyeXNear = fr ? bx - 6f*s : bx + 6f*s;
        float eyeXFar  = fr ? bx - 18f*s : bx + 18f*s;
        Paint eyePaint  = fill(Color.rgb(25,15,8));
        Paint eyeWhite  = fill(Color.WHITE);
        if (b.action == Boxer.Action.HURT) {
            // Squint/grimace
            Paint grimace = stroke(Color.rgb(25,15,8), 1.5f*s);
            c.drawLine(eyeXFar-3*s, eyeY, eyeXFar+3*s, eyeY-2*s, grimace);
            c.drawLine(eyeXNear-3*s, eyeY, eyeXNear+3*s, eyeY-2*s, grimace);
        } else {
            c.drawCircle(eyeXFar,  eyeY, 3.5f*s, eyeWhite);
            c.drawCircle(eyeXNear, eyeY, 3.5f*s, eyeWhite);
            c.drawCircle(eyeXFar  + (fr ? 1f : -1f)*s, eyeY, 2f*s, eyePaint);
            c.drawCircle(eyeXNear + (fr ? 1f : -1f)*s, eyeY, 2f*s, eyePaint);
        }
        // Mouthguard
        Paint mg = fill(Color.rgb(180,220,255)); mg.setAlpha(160);
        c.drawRoundRect(new RectF(bx-8*s, headCY+10*s, bx+8*s, headCY+16*s), 3*s, 3*s, mg);
        // Nose
        c.drawOval(new RectF(
            fr ? bx - 18f*s : bx + 10f*s, headCY + 2f*s,
            fr ? bx - 10f*s : bx + 18f*s, headCY + 9f*s), fill(Color.argb(40,0,0,0)));
    }

    /** Guard / jab fist position for the lead arm (in screen pixels). */
    private float[] getLeadFist(Boxer b, float bx, float by, float s, boolean fr) {
        float t  = b.actionDuration > 0 ? (float)b.actionTimer / b.actionDuration : 0f;
        float fx, fy;

        if (b.action == Boxer.Action.JAB) {
            float ext = Math.min(1f, t * 3f);
            if (t > 0.55f) ext = Math.max(0f, 1f - (t - 0.55f) * 3f);
            fx = fr ? bx + (65f + ext * 65f)*s : bx - (65f + ext * 65f)*s;
            fy = by - (195f - ext * 50f)*s;
        } else if (b.action == Boxer.Action.BLOCK) {
            fx = fr ? bx - 10f*s : bx + 10f*s;
            fy = by - 220f*s;
        } else if (b.action == Boxer.Action.HURT) {
            fx = fr ? bx - 20f*s : bx + 20f*s;
            fy = by - 190f*s;
        } else {
            // Guard
            fx = fr ? bx + 60f*s : bx - 60f*s;
            fy = by - 195f*s;
        }
        return new float[]{ fx, fy };
    }

    /** Guard / cross / hook fist position for the power arm (in screen pixels). */
    private float[] getPowerFist(Boxer b, float bx, float by, float s, boolean fr) {
        float t  = b.actionDuration > 0 ? (float)b.actionTimer / b.actionDuration : 0f;
        float fx, fy;

        if (b.action == Boxer.Action.CROSS) {
            float ext = Math.min(1f, t * 2.5f);
            if (t > 0.6f) ext = Math.max(0f, 1f - (t - 0.6f) * 3f);
            fx = fr ? bx + (55f + ext * 60f)*s : bx - (55f + ext * 60f)*s;
            fy = by - (185f - ext * 45f)*s;
        } else if (b.action == Boxer.Action.HOOK) {
            float angle = (float)(t * Math.PI * 0.75);
            if (t > 0.65f) angle = (float)((1f - (t - 0.65f) / 0.35f) * Math.PI * 0.75);
            float swingR = 110f*s;
            float baseX  = fr ? bx + 36f*s : bx - 36f*s;
            fx = fr ? baseX + (float)(Math.sin(angle) * swingR)
                    : baseX - (float)(Math.sin(angle) * swingR);
            fy = by - 185f*s - (float)(Math.cos(angle) * 20f*s);
        } else if (b.action == Boxer.Action.BLOCK) {
            fx = fr ? bx + 10f*s : bx - 10f*s;
            fy = by - 220f*s;
        } else if (b.action == Boxer.Action.HURT) {
            fx = fr ? bx + 20f*s : bx - 20f*s;
            fy = by - 175f*s;
        } else {
            // Guard
            fx = fr ? bx + 50f*s : bx - 50f*s;
            fy = by - 175f*s;
        }
        return new float[]{ fx, fy };
    }

    /** Draw an arm as two segments (upper-arm + forearm) with a glove circle. */
    private void drawArm(Canvas c, float sx, float sy, float fx, float fy,
                         float thick, Paint skinPaint, Paint glovePaint) {
        float mx = sx + (fx - sx) * 0.48f;
        float my = sy + (fy - sy) * 0.40f + thick * 0.5f; // slight elbow droop

        Paint arm = new Paint(skinPaint);
        arm.setStyle(Paint.Style.STROKE);
        arm.setStrokeCap(Paint.Cap.ROUND);

        arm.setStrokeWidth(thick * 1.7f);
        c.drawLine(sx, sy, mx, my, arm);
        arm.setStrokeWidth(thick * 1.45f);
        c.drawLine(mx, my, fx, fy, arm);

        // Glove
        c.drawCircle(fx, fy, thick * 1.6f, glovePaint);
        // Glove highlight
        Paint hl = fill(Color.argb(55,255,255,255));
        c.drawCircle(fx - thick*0.5f, fy - thick*0.5f, thick*0.8f, hl);
        // Glove seam
        Paint seam = stroke(Color.argb(40,0,0,0), thick*0.25f);
        c.drawLine(fx - thick, fy, fx + thick, fy, seam);
    }

    /** Draw a knocked-down boxer lying on the canvas. */
    private void drawKO(Canvas c, Boxer b, Paint shortsPaint, Paint glovePaint, Paint skinPaint) {
        float bx = b.x, by = b.y - 8f*S, s = S;
        float dir = b.facingRight ? 1f : -1f;

        // Body horizontal
        c.drawRoundRect(new RectF(bx - 50f*s*dir, by - 18f*s, bx + 50f*s*dir, by + 18f*s), 14*s, 14*s, skinPaint);
        // Shorts
        c.drawRoundRect(new RectF(bx - 50f*s*dir, by - 16f*s, bx - 5f*s*dir, by + 16f*s), 12*s, 12*s, shortsPaint);
        // Head
        c.drawCircle(bx + 58f*s*dir, by - 6f*s, 30f*s, skinPaint);
        // Headgear
        Paint hg = new Paint(shortsPaint); hg.setAlpha(190);
        c.drawArc(new RectF(bx+58f*s*dir-30f*s, by-36f*s, bx+58f*s*dir+30f*s, by+24f*s), 180, 180, false, hg);
        // Arms flopped out
        c.drawLine(bx, by + 15f*s, bx + 38f*s*dir, by + 28f*s, skinPaint);
        c.drawCircle(bx + 38f*s*dir, by + 28f*s, 18f*s, glovePaint);
    }

    // ── HUD ───────────────────────────────────────────────────
    private void drawHUD(Canvas c) {
        float hudH = 48f*S;
        c.drawRect(0, 0, W, hudH + 14f*S, pHudBg);

        float barH = 13f*S;
        float stH  = 7f*S;
        float barW = W * 0.34f;
        float barY = 7f*S;
        float stY  = barY + barH + 3f*S;
        float pX   = W * 0.04f;
        float oX   = W - pX - barW;

        // ── Player health bar ──
        c.drawRoundRect(new RectF(pX, barY, pX+barW, barY+barH), barH/2, barH/2, pBarBg);
        float phpRatio = player.health / 100f;
        Paint phpPaint = phpRatio > 0.50f ? pBarHp : phpRatio > 0.25f ? pOrange : pBarHpLow;
        c.drawRoundRect(new RectF(pX, barY, pX + barW*phpRatio, barY+barH), barH/2, barH/2, phpPaint);
        // Player stamina bar
        c.drawRoundRect(new RectF(pX, stY, pX+barW, stY+stH), stH/2, stH/2, pBarBg);
        c.drawRoundRect(new RectF(pX, stY, pX+barW*(player.stamina/100f), stY+stH), stH/2, stH/2, pBarSt);

        // ── Opponent health bar (right-aligned, fills from right) ──
        c.drawRoundRect(new RectF(oX, barY, oX+barW, barY+barH), barH/2, barH/2, pBarBg);
        float ohpRatio = opp.health / 100f;
        c.drawRoundRect(new RectF(oX+barW*(1f-ohpRatio), barY, oX+barW, barY+barH), barH/2, barH/2, pBarHp);
        // Opponent stamina bar
        c.drawRoundRect(new RectF(oX, stY, oX+barW, stY+stH), stH/2, stH/2, pBarBg);
        float ostam = opp.stamina / 100f;
        c.drawRoundRect(new RectF(oX+barW*(1f-ostam), stY, oX+barW, stY+stH), stH/2, stH/2, pBarSt);

        // Labels
        Paint lbl = text(Color.argb(200,255,255,255)); lbl.setTextSize(11f*S);
        lbl.setTextAlign(Paint.Align.LEFT);
        c.drawText("YOU", pX, barY - 1f*S, lbl);
        lbl.setTextAlign(Paint.Align.RIGHT);
        c.drawText("OPP", oX + barW, barY - 1f*S, lbl);

        // HP numbers
        Paint hpNum = text(Color.WHITE); hpNum.setTextSize(10f*S);
        hpNum.setTextAlign(Paint.Align.LEFT);
        c.drawText((int)player.health + "HP", pX, barY + barH + 1f*S, hpNum);
        hpNum.setTextAlign(Paint.Align.RIGHT);
        c.drawText((int)opp.health + "HP", oX + barW, barY + barH + 1f*S, hpNum);

        // ── Center: round + timer ──
        Paint roundP = text(Color.rgb(255,210,80));
        roundP.setTextSize(13f*S); roundP.setFakeBoldText(true);
        c.drawText("ROUND " + round + " / " + MAX_ROUNDS, W/2, 15f*S, roundP);

        // Rounds won dots
        float dotR = 5f*S, dotY = 27f*S;
        for (int i = 0; i < MAX_ROUNDS; i++) {
            float dotX = W/2f + (i - (MAX_ROUNDS-1)/2f) * 14f*S;
            if (i < player.roundsWon)        c.drawCircle(dotX, dotY, dotR, pBarHp);
            else if (i >= MAX_ROUNDS - opp.roundsWon) c.drawCircle(dotX, dotY, dotR, pGloveBlue);
            else {
                Paint empty = fill(Color.argb(100,150,150,150));
                c.drawCircle(dotX, dotY, dotR, empty);
            }
        }

        // Timer
        int secs = roundTimer / 60;
        String timerStr = secs >= 60 ? "1:00" : "0:" + String.format("%02d", secs);
        Paint timerP = text(secs <= 10 ? Color.rgb(255,80,80) : Color.WHITE);
        timerP.setTextSize(18f*S); timerP.setFakeBoldText(true);
        c.drawText(timerStr, W/2, 44f*S, timerP);
    }

    // ── Buttons ───────────────────────────────────────────────
    private void drawButtons(Canvas c) {
        String[] lbl   = { "◄", "►", "JAB", "CROSS", "HOOK", "BLK" };
        int[]   colors = {
            Color.argb(160, 40, 60, 80),
            Color.argb(160, 40, 60, 80),
            Color.argb(160, 30,140, 50),   // jab – green
            Color.argb(160,140,100, 25),   // cross – gold
            Color.argb(160,150, 50, 20),   // hook – red-orange
            Color.argb(160, 40, 40,140)    // block – blue
        };
        int[] pressedColors = {
            Color.argb(220, 80,120,170),
            Color.argb(220, 80,120,170),
            Color.argb(220, 70,210, 90),
            Color.argb(220,210,160, 50),
            Color.argb(220,220,100, 50),
            Color.argb(220, 90, 90,220)
        };

        for (int i = 0; i < 6; i++) {
            // Background
            Paint bp = fill(btnDown[i] ? pressedColors[i] : colors[i]);
            c.drawRoundRect(btnRects[i], 8*S, 8*S, bp);

            // Border
            pBtnBorder.setStrokeWidth(1.5f*S);
            c.drawRoundRect(btnRects[i], 8*S, 8*S, pBtnBorder);

            // Label
            Paint tp = text(Color.WHITE); tp.setFakeBoldText(true);
            tp.setTextSize(i < 2 ? 24f*S : 13f*S);
            c.drawText(lbl[i], btnRects[i].centerX(), btnRects[i].centerY() + tp.getTextSize()*0.38f, tp);

            // Stamina-availability bar on attack buttons
            if (i >= 2 && i <= 4) {
                float cost = i == 2 ? 10f : i == 3 ? 16f : 22f;
                float bLeft = btnRects[i].left + 4f*S;
                float bRight= btnRects[i].right - 4f*S;
                float bBot  = btnRects[i].bottom - 6f*S;
                float bTop2 = bBot - 4f*S;
                Paint sbg = fill(Color.argb(80,0,0,0));
                c.drawRoundRect(new RectF(bLeft, bTop2, bRight, bBot), 2, 2, sbg);
                float fill2 = Math.min(1f, player.stamina / 100f);
                Paint sfg = fill(player.stamina >= cost ? Color.rgb(50,200,230) : Color.rgb(160,50,50));
                c.drawRoundRect(new RectF(bLeft, bTop2, bLeft + (bRight-bLeft)*fill2, bBot), 2, 2, sfg);
            }
        }
    }

    // ── Combo text ────────────────────────────────────────────
    private void drawCombo(Canvas c) {
        if (playerCombo < 2 || comboShowFrames <= 0) return;
        float alpha = Math.min(1f, comboShowFrames / 30f);
        Paint cp = text(Color.argb((int)(alpha*255), 255, 215, 0));
        cp.setTextSize(28f*S); cp.setFakeBoldText(true);
        cp.setTextAlign(Paint.Align.LEFT);
        c.drawText("COMBO x" + playerCombo + "!", W*0.05f, H*0.62f, cp);
    }

    // ── Hit spark FX ──────────────────────────────────────────
    private void drawHitFx(Canvas c) {
        if (hitFxTimer <= 0) return;
        float age   = 1f - hitFxTimer / 14f;
        float alpha = (1f - age) * 220f;
        Paint sp = stroke(Color.argb((int)alpha, 255, 220, 50), 2.5f*S);
        sp.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            float angle = i * 45f + age * 120f;
            float rad   = (float)Math.toRadians(angle);
            float len   = age * 30f * S;
            float startR= 8f * S;
            c.drawLine(
                hitFxX + (float)Math.cos(rad)*startR,
                hitFxY + (float)Math.sin(rad)*startR,
                hitFxX + (float)Math.cos(rad)*(startR+len),
                hitFxY + (float)Math.sin(rad)*(startR+len), sp);
        }
    }

    // ── Countdown overlay ─────────────────────────────────────
    private void drawCountdown(Canvas c) {
        float alpha = cdFrames / 60f;
        Paint p = text(Color.argb((int)(alpha*255), 255,255,255));
        p.setTextSize(110f*S); p.setFakeBoldText(true);
        c.drawText(String.valueOf(cdVal), W/2, H*0.58f, p);
    }

    // ── "FIGHT!" banner ───────────────────────────────────────
    private void drawFightBanner(Canvas c) {
        float alpha = Math.min(1f, fightBannerFrames / 15f);
        Paint p = text(Color.argb((int)(alpha*255), 255, 80, 80));
        p.setTextSize(90f*S); p.setFakeBoldText(true);
        c.drawText("FIGHT!", W/2, H*0.58f, p);
    }

    // ── Round end overlay ─────────────────────────────────────
    private void drawRoundEnd(Canvas c) {
        Paint dim = fill(Color.argb(155,0,0,0));
        c.drawRect(0,0,W,H,dim);

        Paint title = text(Color.rgb(255,215,50)); title.setTextSize(38f*S); title.setFakeBoldText(true);
        c.drawText("ROUND " + round + " OVER", W/2, H*0.38f, title);

        Paint msg = text(Color.WHITE); msg.setTextSize(26f*S); msg.setFakeBoldText(true);
        String[] lines = roundEndMsg.split("\n");
        for (int i = 0; i < lines.length; i++)
            c.drawText(lines[i], W/2, H*0.50f + i*34f*S, msg);

        Paint score = text(Color.rgb(200,200,200)); score.setTextSize(18f*S);
        c.drawText("YOU: " + player.roundsWon + "   OPP: " + opp.roundsWon, W/2, H*0.70f, score);
        if (round < MAX_ROUNDS) {
            score.setTextSize(15f*S); score.setColor(Color.rgb(160,160,160));
            c.drawText("Next round starting...", W/2, H*0.78f, score);
        }
    }

    // ── Game over ─────────────────────────────────────────────
    private void drawGameOver(Canvas c) {
        Paint dim = fill(Color.argb(175,0,0,0));
        c.drawRect(0,0,W,H,dim);

        Paint title = text(Color.rgb(255,215,50)); title.setTextSize(46f*S); title.setFakeBoldText(true);
        c.drawText("FINAL RESULT", W/2, H*0.33f, title);

        Paint wm = text(Color.WHITE); wm.setTextSize(34f*S); wm.setFakeBoldText(true);
        c.drawText(winnerMsg, W/2, H*0.46f, wm);

        Paint score = text(Color.rgb(200,200,200)); score.setTextSize(18f*S);
        c.drawText("YOU: " + player.roundsWon + " rounds   OPP: " + opp.roundsWon + " rounds", W/2, H*0.58f, score);

        if ((System.currentTimeMillis() / 700) % 2 == 0) {
            Paint tap = text(Color.WHITE); tap.setTextSize(22f*S); tap.setFakeBoldText(true);
            c.drawText("TAP TO PLAY AGAIN", W/2, H*0.76f, tap);
        }
    }

    // ═══════════════════════ TOUCH ═════════════════════════════

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action  = ev.getActionMasked();
        int pIdx    = ev.getActionIndex();
        int pid     = ev.getPointerId(pIdx);
        float px    = ev.getX(pIdx);
        float py    = ev.getY(pIdx);

        if (state == State.MENU) {
            if (action == MotionEvent.ACTION_DOWN) startGame();
            return true;
        }
        if (state == State.GAME_OVER) {
            if (action == MotionEvent.ACTION_DOWN) restartGame();
            return true;
        }
        if (state != State.FIGHTING && state != State.COUNTDOWN) return true;

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            handlePress(px, py, pid);
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            handleRelease(pid);
        } else if (action == MotionEvent.ACTION_CANCEL) {
            clearInput();
        }
        return true;
    }

    private void handlePress(float px, float py, int pid) {
        for (int i = 0; i < 6; i++) {
            if (btnRects[i].contains(px, py) && btnPointer[i] == -1) {
                btnDown[i] = true;
                btnPointer[i] = pid;
                if (state == State.FIGHTING) {
                    if (i == 2) player.doJab();
                    else if (i == 3) player.doCross();
                    else if (i == 4) player.doHook();
                }
                break;
            }
        }
    }

    private void handleRelease(int pid) {
        for (int i = 0; i < 6; i++) {
            if (btnPointer[i] == pid) {
                btnDown[i] = false;
                btnPointer[i] = -1;
            }
        }
    }

    private void clearInput() {
        for (int i = 0; i < 6; i++) { btnDown[i] = false; btnPointer[i] = -1; }
    }

    // ── Game flow ─────────────────────────────────────────────
    private void startGame() {
        if (player == null) return;
        round = 1;
        player.roundsWon = 0; opp.roundsWon = 0;
        player.resetForRound(W * 0.28f);
        opp.resetForRound(W * 0.72f);
        opp.aiDifficulty = 1;
        roundTimer = 60 * 60;
        cdVal = 3; cdFrames = 60;
        playerCombo = 0; comboShowFrames = 0;
        hitFxTimer = 0; shakeFrames = 0;
        state = State.COUNTDOWN;
    }

    private void restartGame() { startGame(); }
}
