package com.example.boxinggame;

/**
 * Holds position, health, action state and (for opponent) AI state.
 * All dimensional constants are in "design units" (DU).
 * Caller multiplies by scale = screenHeight / 700f to get screen pixels.
 */
public class Boxer {

    public enum Action { IDLE, JAB, CROSS, HOOK, BLOCK, HURT, KNOCKED_DOWN }
    public enum AIState { APPROACH, AGGRESSIVE, BACKING_OFF, DEFENSIVE }

    // ── Position ──────────────────────────────────────────────
    public float x, y;   // center-x, feet-y in screen pixels
    public float vx = 0f;

    // ── Stats ─────────────────────────────────────────────────
    public float health  = 100f;
    public float stamina = 100f;

    // ── Identity ──────────────────────────────────────────────
    public final boolean isPlayer;
    public boolean facingRight;

    // ── Action state machine ──────────────────────────────────
    public Action action        = Action.IDLE;
    public int    actionTimer   = 0;
    public int    actionDuration = 0;
    public int    hitFrameStart = 0;
    public int    hitFrameEnd   = 0;
    public boolean hitDealt     = false;

    // ── Visual feedback ───────────────────────────────────────
    public int   flashTimer = 0;
    public int   idleBob    = 0;   // 0-59 counter for idle bounce

    // ── AI fields ─────────────────────────────────────────────
    public AIState aiState     = AIState.APPROACH;
    public int     aiCooldown  = 0;
    public int     aiDifficulty = 1;   // 1 easy  2 medium  3 hard

    // ── Match score ───────────────────────────────────────────
    public int roundsWon = 0;

    // ─────────────────────────────────────────────────────────
    public Boxer(float x, float y, boolean isPlayer, boolean facingRight) {
        this.x = x; this.y = y;
        this.isPlayer = isPlayer;
        this.facingRight = facingRight;
    }

    public void resetForRound(float startX) {
        x = startX; health = 100f; stamina = 100f;
        action = Action.IDLE; actionTimer = 0; actionDuration = 0;
        vx = 0f; flashTimer = 0;
        aiState = AIState.APPROACH; aiCooldown = 0;
        hitDealt = false;
    }

    // ── Queries ───────────────────────────────────────────────
    public boolean canAct()       { return action == Action.IDLE || action == Action.BLOCK; }
    public boolean isBlocking()   { return action == Action.BLOCK; }
    public boolean isKO()         { return action == Action.KNOCKED_DOWN && health <= 0; }

    public boolean isActiveFistFrame() {
        return (action == Action.JAB || action == Action.CROSS || action == Action.HOOK)
            && actionTimer >= hitFrameStart && actionTimer <= hitFrameEnd;
    }

    // ── Hit-box helpers (screen pixels) ──────────────────────
    // S = scale passed from GameView (H/700)
    public float bodyLeft(float S)   { return x - 46f * S; }
    public float bodyRight(float S)  { return x + 46f * S; }
    public float bodyTop(float S)    { return y - 240f * S; }
    public float bodyBottom(float S) { return y - 10f  * S; }

    /** Absolute screen X of the active fist. */
    public float fistScreenX(float S) {
        boolean active = isActiveFistFrame();
        float ext;
        if (action == Action.JAB)   ext = active ? 130f : 70f;
        else if (action == Action.CROSS) ext = active ?  95f : 55f;
        else if (action == Action.HOOK) {
            if (active) {
                float t = actionDuration > 0 ? (float)actionTimer / actionDuration : 0f;
                float angle = (float)(t * Math.PI * 0.7);
                float baseOff = 36f;
                float swingOff = (float)(Math.sin(angle) * 110f);
                ext = baseOff + swingOff;
            } else { ext = 50f; }
        }
        else ext = 70f;
        return facingRight ? x + ext * S : x - ext * S;
    }

    /** Absolute screen Y of the active fist. */
    public float fistScreenY(float S) {
        if (action == Action.JAB   && isActiveFistFrame()) return y - 145f * S;
        if (action == Action.CROSS && isActiveFistFrame()) return y - 138f * S;
        if (action == Action.HOOK  && isActiveFistFrame()) {
            float t = actionDuration > 0 ? (float)actionTimer / actionDuration : 0f;
            float angle = (float)(t * Math.PI * 0.7);
            return y - 160f * S - (float)(Math.cos(angle) * 20f * S);
        }
        return y - 182f * S;  // guard position
    }

    public float fistRadius(float S) { return 22f * S; }

    // ── Attacks ───────────────────────────────────────────────
    public boolean doJab() {
        if (!canAct() || stamina < 10f) return false;
        action = Action.JAB; actionDuration = 20;
        hitFrameStart = 6; hitFrameEnd = 13;
        actionTimer = 0; hitDealt = false; stamina -= 10f;
        return true;
    }

    public boolean doCross() {
        if (!canAct() || stamina < 16f) return false;
        action = Action.CROSS; actionDuration = 28;
        hitFrameStart = 9; hitFrameEnd = 18;
        actionTimer = 0; hitDealt = false; stamina -= 16f;
        return true;
    }

    public boolean doHook() {
        if (!canAct() || stamina < 22f) return false;
        action = Action.HOOK; actionDuration = 34;
        hitFrameStart = 11; hitFrameEnd = 22;
        actionTimer = 0; hitDealt = false; stamina -= 22f;
        return true;
    }

    public float getAttackDamage() {
        if (action == Action.JAB)   return 8f;
        if (action == Action.CROSS) return 14f;
        if (action == Action.HOOK)  return 22f;
        return 0f;
    }

    public float getAttackKnockback(float S) {
        if (action == Action.JAB)   return  4f * S;
        if (action == Action.CROSS) return  8f * S;
        if (action == Action.HOOK)  return 14f * S;
        return 0f;
    }

    // ── Receiving damage ──────────────────────────────────────
    public void receiveHit(float damage, float knockback) {
        flashTimer = 10;
        if (isBlocking()) {
            health  -= damage * 0.12f;
            stamina -= 22f;
            vx = facingRight ? -knockback * 0.3f : knockback * 0.3f;
        } else {
            health -= damage;
            if (health <= 0f) {
                health = 0f;
                action = Action.KNOCKED_DOWN;
                actionDuration = 999; actionTimer = 0;
            } else {
                action = Action.HURT;
                actionDuration = 16; actionTimer = 0;
                hitDealt = false;
                vx = facingRight ? -knockback : knockback;
            }
        }
        health  = Math.max(0f, health);
        stamina = Math.max(0f, stamina);
    }

    // ── Block control ─────────────────────────────────────────
    public void startBlock() { if (action == Action.IDLE) action = Action.BLOCK; }
    public void stopBlock()  { if (action == Action.BLOCK) action = Action.IDLE; }

    // ── Movement ──────────────────────────────────────────────
    public void moveForward() {
        if (!canAct()) return;
        vx = facingRight ? 4.5f : -4.5f;
    }
    public void moveBack() {
        if (!canAct()) return;
        vx = facingRight ? -4.5f : 4.5f;
    }

    // ── Per-frame update ──────────────────────────────────────
    public void update(float minX, float maxX) {
        // Stamina regen / drain
        if (action != Action.BLOCK) stamina = Math.min(100f, stamina + 0.45f);
        else                        stamina = Math.max(0f,   stamina - 0.22f);

        // Advance action timer
        if (action != Action.IDLE && action != Action.BLOCK) {
            actionTimer++;
            if (action != Action.KNOCKED_DOWN && actionTimer >= actionDuration) {
                action = Action.IDLE;
                actionTimer = 0;
            }
        }

        if (flashTimer > 0) flashTimer--;
        idleBob = (idleBob + 1) % 60;

        x += vx;
        vx *= 0.7f;
        if (Math.abs(vx) < 0.05f) vx = 0f;

        x = Math.max(minX, Math.min(maxX, x));

        if (!isPlayer && aiCooldown > 0) aiCooldown--;
    }
}
