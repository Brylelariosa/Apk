package com.zipapkbuilder

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var tvOwnerInfo: TextView
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnDownloadApk: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: NestedScrollView

    private lateinit var btnManageZips: Button   // multi-select delete, always enabled
    private lateinit var btnWorkflowLog: Button  // in-app log viewer
    private lateinit var btnCopyLog: Button
    private lateinit var btnSaveLog: Button

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    private var lastOwner      = ""
    private var lastRemotePath = ""
    private var lastFileSha: String? = null
    private var lastRunId: Long = -1L

    // ── Embedded workflow YAML ────────────────────────────────────────────────
    // • paths: ['uploads/**'] → only triggers when a ZIP is actually pushed; old ZIPs never
    //   retrigger a build on unrelated commits.
    // • ZIPs deleted after both success AND failure with [skip ci] to stop recursion.
    private val WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Build APK

on:
  push:
    branches: [ main, master ]
    paths:
      - 'uploads/**'
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          token: ${d}{{ secrets.GITHUB_TOKEN }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Cache NDK and CMake
        id: cache-ndk
        uses: actions/cache@v4
        with:
          path: |
            ${d}{{ env.ANDROID_HOME }}/ndk/25.2.9519653
            ${d}{{ env.ANDROID_HOME }}/ndk/25.1.8937393
            ${d}{{ env.ANDROID_HOME }}/cmake/3.22.1
          key: ndk-25.2.9519653-25.1.8937393-cmake-3.22.1

      - name: Install NDK and CMake
        run: |
          for NDK_VER in "25.2.9519653" "25.1.8937393"; do
            if [ ! -d "${d}ANDROID_SDK_ROOT/ndk/${d}NDK_VER" ]; then
              echo "Installing NDK ${d}NDK_VER..."
              sdkmanager --install "ndk;${d}NDK_VER"
            else
              echo "NDK ${d}NDK_VER already present"
            fi
          done
          if [ ! -d "${d}ANDROID_SDK_ROOT/cmake/3.22.1" ]; then
            sdkmanager --install "cmake;3.22.1"
          fi
          echo "ANDROID_NDK_HOME=${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" >> ${d}GITHUB_ENV

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'
          cache-read-only: false

      - name: Unzip project
        run: |
          ZIP=${d}(find . -path './.git' -prune -o -maxdepth 3 -name "*.zip" -printf "%T@ %p\n" | sort -rn | head -1 | cut -d" " -f2-)
          if [ -z "${d}ZIP" ]; then
            echo "##[error]No ZIP file found in repository!"
            exit 1
          fi
          ZIP_NAME=${d}(basename "${d}ZIP" .zip)
          echo "zip_name=${d}ZIP_NAME" >> ${d}GITHUB_ENV
          echo "zip_path=${d}ZIP" >> ${d}GITHUB_ENV
          echo "Found zip: ${d}ZIP"
          unzip -q "${d}ZIP" -d extracted

      - name: Find project directory
        id: find_project
        run: |
          RESULT=${d}(find extracted -maxdepth 4 \( -name "settings.gradle" -o -name "settings.gradle.kts" \) | head -1)
          if [ -z "${d}RESULT" ]; then
            echo "##[error]No settings.gradle found inside the zip!"
            find extracted | sort
            exit 1
          fi
          PROJECT_DIR=${d}(dirname "${d}RESULT")
          echo "Found project at: ${d}PROJECT_DIR"
          echo "project_dir=${d}PROJECT_DIR" >> ${d}GITHUB_OUTPUT

      - name: Cache CMake / C++ build outputs
        uses: actions/cache@v4
        with:
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/.cxx
          key: cxx-debug-${d}{{ hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp') }}
          restore-keys: cxx-debug-

      - name: Fetch gradle-wrapper.jar
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          GRADLE_VERSION="8.6"
          JAR="gradle/wrapper/gradle-wrapper.jar"
          mkdir -p gradle/wrapper
          curl --fail --silent --show-error --location \
            "https://raw.githubusercontent.com/gradle/gradle/v${d}{GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar" \
            -o "${d}JAR"
          SIZE=${d}(stat -c%s "${d}JAR")
          if [ "${d}SIZE" -lt 10000 ]; then
            echo "ERROR: gradle-wrapper.jar too small (${d}{SIZE} bytes)"
            exit 1
          fi

      - name: Make gradlew executable
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: chmod +x gradlew && sed -i 's/\r//' gradlew

      - name: Build Debug APK
        id: build
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: ./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
        env:
          ANDROID_NDK_HOME: ${d}{{ env.ANDROID_NDK_HOME }}

      - name: Upload APK artifact
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ${d}{{ env.zip_name }}-debug-v${d}{{ github.run_number }}
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/build/outputs/apk/debug/*.apk
          retention-days: 30

      - name: Clean up - delete zip after successful build
        if: success()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP after build #${d}{{ github.run_number }} [skip ci]"
            git push
          fi

      - name: Clean up - delete zip after failed build
        if: failure()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP (build failed #${d}{{ github.run_number }}) [skip ci]"
            git push
          fi
        """.trimIndent()
    }

    // ── File picker ──────────────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        btnDownloadApk = findViewById(R.id.btnDownloadApk)
        btnManageZips  = findViewById(R.id.btnManageZips)
        btnWorkflowLog = findViewById(R.id.btnWorkflowLog)
        btnCopyLog     = findViewById(R.id.btnCopyLog)
        btnSaveLog     = findViewById(R.id.btnSaveLog)
        tvLog          = findViewById(R.id.tvLog)
        scrollLog      = findViewById(R.id.scrollLog)

        etToken.setText(prefs.getString("token", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) startFlow() }
        btnDownloadApk.setOnClickListener  { artifactDownloadUrl?.let { downloadArtifact(it) } }
        btnManageZips.setOnClickListener   { if (!isBusy) showManageFilesDialog() }
        btnWorkflowLog.setOnClickListener  { if (!isBusy) fetchAndShowWorkflowLog() }
        btnCopyLog.setOnClickListener      { copyLogToClipboard() }
        btnSaveLog.setOnClickListener      { saveLogToFile() }

        setStatus("Idle")
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub Personal Access Token."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name."); return }
        if (uri == null)     { appendLog("⚠ Pick a ZIP file first."); return }

        prefs.edit()
            .putString("token", token)
            .putString("repo", repo)
            .putString("branch", branch)
            .apply()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl = null
        btnDownloadApk.isEnabled = false
        lastOwner      = ""
        lastRemotePath = ""
        lastFileSha    = null
        lastRunId      = -1L
        mainHandler.post {
            tvOwnerInfo.text = ""
            btnWorkflowLog.isEnabled = false
        }

        thread { runFlow(token, repo, branch, uri) }
    }

    // ── Main flow ────────────────────────────────────────────────────────────
    private fun runFlow(token: String, repo: String, branch: String, uri: Uri) {
        try {
            setStatus("Verifying token…")
            appendLog("Verifying GitHub token…")
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network. Make sure your PAT has 'repo' scope.")
            appendLog("✓  Signed in as @$owner")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner" }

            setStatus("Checking repo…")
            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            setStatus("Setting up workflow…")
            ensureWorkflow(token, owner, repo, branch)

            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {
                throw Exception("ZIP too large for GitHub Contents API (> ~70 MB raw).")
            }

            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath  = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch", branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            val (upCode, upBody) = httpPut(token, apiContents(owner, repo, remotePath), uploadJson)
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            lastRemotePath = remotePath
            lastFileSha = try {
                JSONObject(upBody).optJSONObject("content")?.optString("sha")
            } catch (_: Exception) { null }
            appendLog("Upload OK — GitHub Actions will start shortly…")

            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                    "Check that build.yml is on the $branch branch.")
            lastRunId = runId
            mainHandler.post { btnWorkflowLog.isEnabled = true }
            appendLog("Run #$runId started — streaming live build log…")
            appendLog("─────────────────────────────────────")

            setStatus("Building…")
            val success = streamBuildLog(token, owner, repo, runId)
            if (!success) throw Exception("Build failed. Tap '🔍 Build Log' for the full output.")

            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifact found.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")
            mainHandler.post { btnDownloadApk.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── Auto-setup helpers ────────────────────────────────────────────────────

    private fun fetchOwner(token: String): String? = try {
        val (code, body) = httpGet(token, "https://api.github.com/user")
        if (code == 200) JSONObject(body).optString("login").takeIf { it.isNotEmpty() }
        else null
    } catch (_: Exception) { null }

    private fun ensureRepo(token: String, owner: String, repo: String) {
        val (code, _) = httpGet(token, "https://api.github.com/repos/$owner/$repo")
        if (code == 200) { appendLog("Repo already exists ✓"); return }
        appendLog("Repo not found — creating github.com/$owner/$repo …")
        val body = JSONObject().apply {
            put("name", repo)
            put("private", false)
            put("auto_init", true)
            put("description", "APK build repo — managed by ZipApkBuilder")
        }.toString()
        val (createCode, createBody) = httpPost(token, "https://api.github.com/user/repos", body)
        if (createCode !in 200..201) throw Exception("Could not create repo ($createCode): ${createBody.take(300)}")
        appendLog("Repo created ✓ — waiting for GitHub to initialise it…")
        Thread.sleep(4_000)
    }

    private fun ensureWorkflow(token: String, owner: String, repo: String, branch: String) {
        val path = ".github/workflows/build.yml"
        val existingSha = fetchFileSha(token, owner, repo, path)
        if (existingSha != null) { appendLog("Workflow already present ✓"); return }
        appendLog("Committing build workflow to repo…")
        val encoded = Base64.encodeToString(WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("message", "ci: add GitHub Actions build workflow")
            put("content", encoded)
            put("branch", branch)
        }.toString()
        val (code, body) = httpPut(token, apiContents(owner, repo, path), payload)
        if (code !in 200..201) throw Exception("Could not commit workflow ($code): ${body.take(300)}")
        appendLog("Workflow committed ✓")
        Thread.sleep(2_000)
    }

    // ── GitHub API helpers ────────────────────────────────────────────────────

    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run   = runs.getJSONObject(i)
                        val runMs = parseIso8601(run.getString("created_at"))
                        if (runMs >= afterMs - 15_000) return run.getLong("id")
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    /**
     * Shows live step-by-step progress while the job runs (GitHub's log text API
     * only returns content after the job completes, so we use the jobs/steps endpoint
     * which updates in real time). After completion, fetches the full log text and
     * appends new lines to the console. Returns true on success.
     */
    private fun streamBuildLog(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline = System.currentTimeMillis() + 45 * 60_000L

        // Track which steps we've already reported as started/finished
        val stepStarted   = mutableSetOf<Int>()
        val stepFinished  = mutableSetOf<Int>()

        val tsRegex   = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val ansiRegex = Regex("""\x1B\[[0-9;]*[A-Za-z]""")

        var conclusion = ""

        // ── Phase 1: live step progress ──────────────────────────────────────
        while (System.currentTimeMillis() < deadline) {
            try {
                val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
                if (jCode == 200) {
                    val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                    if (jobsArr != null && jobsArr.length() > 0) {
                        val job   = jobsArr.getJSONObject(0)
                        val steps = job.optJSONArray("steps")
                        if (steps != null) {
                            for (i in 0 until steps.length()) {
                                val step       = steps.getJSONObject(i)
                                val num        = step.getInt("number")
                                val name       = step.getString("name")
                                val status     = step.optString("status", "")
                                val stepConc   = step.optString("conclusion", "")

                                if (status == "in_progress" && !stepStarted.contains(num)) {
                                    stepStarted.add(num)
                                    appendLog("▶ $name")
                                }
                                if (status == "completed" && !stepFinished.contains(num)) {
                                    stepFinished.add(num)
                                    if (!stepStarted.contains(num)) appendLog("▶ $name")
                                    val icon = if (stepConc == "success") "✓" else "✗"
                                    // Calculate duration if timestamps present
                                    val started   = step.optString("started_at", "")
                                    val completed = step.optString("completed_at", "")
                                    val durSec = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                        try {
                                            val s = parseIso8601(started)
                                            val e = parseIso8601(completed)
                                            if (e > s) "  ${(e - s) / 1000}s" else ""
                                        } catch (_: Exception) { "" }
                                    } else ""
                                    appendLog("  $icon $name$durSec")
                                }
                            }
                        }
                    }
                }

                // Check overall run status
                val (sCode, sBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (sCode == 200) {
                    val obj    = JSONObject(sBody)
                    val status = obj.getString("status")
                    conclusion = obj.optString("conclusion", "")
                    if (status == "completed") break
                }

            } catch (_: Exception) {}
            Thread.sleep(5_000)
        }

        // ── Phase 2: fetch full log text and append new lines ─────────────────
        try {
            val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jCode == 200) {
                val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                if (jobsArr != null && jobsArr.length() > 0) {
                    val jobId  = jobsArr.getJSONObject(0).getLong("id")
                    val logUrl = "https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs"
                    val conn1  = (URL(logUrl).openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("Authorization", "token $token")
                        setRequestProperty("Accept", "application/vnd.github.v3+json")
                        instanceFollowRedirects = false
                        connectTimeout = 20_000; readTimeout = 60_000
                    }
                    val code1 = conn1.responseCode
                    val rawLog: String? = when {
                        code1 in 301..308 -> {
                            val loc = conn1.getHeaderField("Location")
                            conn1.disconnect()
                            try {
                                val conn2 = (URL(loc).openConnection() as java.net.HttpURLConnection).apply {
                                    requestMethod = "GET"; connectTimeout = 20_000; readTimeout = 60_000
                                }
                                if (conn2.responseCode == 200)
                                    conn2.inputStream.bufferedReader().readText().also { conn2.disconnect() }
                                else { conn2.disconnect(); null }
                            } catch (_: Exception) { null }
                        }
                        code1 == 200 -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                        else -> { conn1.disconnect(); null }
                    }
                    if (rawLog != null) {
                        appendLog("─────────────────────────────────────")
                        val groupRegex = Regex("""^##\[(?:group|endgroup)\]""")
                        for (raw in rawLog.lines()) {
                            val noTs   = tsRegex.replace(raw, "")
                            val noAnsi = ansiRegex.replace(noTs, "")
                            if (groupRegex.containsMatchIn(noAnsi) || noAnsi.isBlank()) continue
                            appendLog(noAnsi)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        appendLog("─────────────────────────────────────")
        appendLog(if (conclusion == "success") "✓ Build completed successfully" else "✗ Build $conclusion")
        return conclusion == "success"
    }

    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download & install ────────────────────────────────────────────────────

    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        btnDownloadApk.isEnabled = false
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP…")
        val token = etToken.text.toString().trim()

        thread {
            try {
                var conn = URL(downloadUrl).openConnection() as HttpURLConnection
                conn.setRequestProperty("Authorization", "token $token")
                conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 30_000
                conn.readTimeout    = 30_000
                conn.connect()

                val realUrl = if (conn.responseCode in 301..308) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect(); loc
                } else downloadUrl

                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 180_000
                val total = dlConn.contentLength
                appendLog("Downloading… (${if (total > 0) "${total / 1024} KB" else "size unknown"})")

                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(artifactZip).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("Downloaded: ${artifactZip.length() / 1024} KB")

                val tempApk = extractApkToTemp(artifactZip)
                    ?: throw Exception("No .apk found inside the artifact ZIP.")

                appendLog("APK ready — choose a filename to save.")
                setStatus("Ready ✓")
                mainHandler.post {
                    btnDownloadApk.isEnabled = true
                    showRenameAndSaveDialog(tempApk)
                }
            } catch (e: Exception) {
                appendLog("✗ Download error: ${e.message}")
                setStatus("Download failed")
                mainHandler.post { btnDownloadApk.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    /** Extracts the first .apk from [zipFile] into a temp file in cacheDir. */
    private fun extractApkToTemp(zipFile: File): File? {
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".apk")) {
                    val dest = File(cacheDir, "temp_apk_${System.currentTimeMillis()}.apk")
                    FileOutputStream(dest).use { zis.copyTo(it) }
                    return dest
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return null
    }

    /** Shows a rename dialog then copies [tempApk] to Downloads with the chosen name. */
    private fun showRenameAndSaveDialog(tempApk: File) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val et = EditText(this).apply {
            setText("app_$stamp.apk")
            selectAll()
            setPadding(48, 32, 48, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("💾  Save APK As")
            .setMessage("Choose a filename for Downloads:")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                var name = et.text.toString().trim()
                if (name.isEmpty()) name = "app-debug.apk"
                if (!name.endsWith(".apk")) name += ".apk"
                thread {
                    try {
                        val downloadsDir = Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS)
                        downloadsDir.mkdirs()
                        val dest = File(downloadsDir, name)
                        tempApk.copyTo(dest, overwrite = true)
                        appendLog("✓ Saved to Downloads: $name")
                        appendLog("  Path: ${dest.absolutePath}")
                        appendLog("  Size: ${dest.length() / 1024} KB")
                        mainHandler.post { offerInstall(dest) }
                    } catch (e: Exception) {
                        appendLog("✗ Save error: ${e.message}")
                    }
                }
            }
            .setNegativeButton("Cancel") { _, _ ->
                appendLog("Save cancelled.")
            }
            .show()
    }

    /**
     * Fires the system package-installer for [apkFile].
     * Because the APK is in Downloads, the user can also find and reinstall it any time
     * via their file manager.
     */
    private fun offerInstall(apkFile: File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(intent)
    }

    // ── Manage ZIPs dialog ────────────────────────────────────────────────────

    private fun showManageFilesDialog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Listing ZIPs in repo uploads/ …")

        thread {
            try {
                val owner = if (lastOwner.isNotEmpty()) lastOwner else {
                    fetchOwner(token) ?: throw Exception("Could not verify token.")
                }
                if (lastOwner.isEmpty()) lastOwner = owner

                val (code, body) = httpGet(token, apiContents(owner, repo, "uploads"))
                when {
                    code == 404 -> {
                        mainHandler.post {
                            setBusy(false)
                            appendLog("No uploads/ directory found in repo yet.")
                        }
                        return@thread
                    }
                    code != 200 -> throw Exception("Could not list uploads/ (HTTP $code)")
                }

                val arr      = JSONArray(body)
                val zipFiles = mutableListOf<Triple<String, String, String>>() // path, sha, name
                for (i in 0 until arr.length()) {
                    val obj  = arr.getJSONObject(i)
                    val type = obj.optString("type")
                    val name = obj.getString("name")
                    val path = obj.getString("path")
                    val sha  = obj.optString("sha")
                    if (type == "file" && name.lowercase().endsWith(".zip")) {
                        zipFiles.add(Triple(path, sha, name))
                    }
                }

                mainHandler.post {
                    setBusy(false)
                    if (zipFiles.isEmpty()) {
                        appendLog("No ZIP files in uploads/ — repo is already clean.")
                        return@post
                    }
                    showZipSelectionDialog(token, owner, repo, zipFiles)
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    private fun showZipSelectionDialog(
        token: String,
        owner: String,
        repo: String,
        zipFiles: List<Triple<String, String, String>>
    ) {
        val names   = zipFiles.map { it.third }.toTypedArray()
        val checked = BooleanArray(zipFiles.size) { false }

        AlertDialog.Builder(this)
            .setTitle("🗂️  Select ZIPs to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = zipFiles.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { appendLog("No files selected."); return@setPositiveButton }
                val names2 = toDelete.joinToString("\n• ", prefix = "• ") { it.third }
                AlertDialog.Builder(this)
                    .setTitle("Confirm Deletion")
                    .setMessage("Permanently delete ${toDelete.size} file(s) from repo?\n\n$names2")
                    .setPositiveButton("Delete") { _, _ ->
                        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
                        setBusy(true)
                        thread { deleteSelectedFiles(token, owner, repo, branch, toDelete) }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteSelectedFiles(
        token: String,
        owner: String,
        repo: String,
        branch: String,
        files: List<Triple<String, String, String>>
    ) {
        try {
            for ((path, sha, name) in files) {
                appendLog("Deleting $name …")
                val body = JSONObject().apply {
                    put("message", "ci: delete $path via ZipApkBuilder [skip ci]")
                    put("sha", sha)
                    put("branch", branch)
                }.toString()
                val (code, respBody) = httpDelete(token, apiContents(owner, repo, path), body)
                if (code in 200..204) {
                    appendLog("✓ Deleted: $name")
                    if (path == lastRemotePath) lastFileSha = null
                } else {
                    appendLog("✗ Failed to delete $name ($code): ${respBody.take(120)}")
                }
            }
        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    // ── In-app workflow log viewer ────────────────────────────────────────────

    private fun fetchAndShowWorkflowLog() {
        if (lastRunId == -1L || lastOwner.isEmpty()) {
            appendLog("⚠ No workflow run yet — build a project first.")
            return
        }
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()

        setBusy(true)
        appendLog("Fetching build log from GitHub…")

        thread {
            try {
                // 1. Get job list for this run
                val (jobsCode, jobsBody) = httpGet(token, "${apiRuns(lastOwner, repo)}/$lastRunId/jobs")
                if (jobsCode != 200) throw Exception("Could not fetch jobs (HTTP $jobsCode)")

                val jobsArr = JSONObject(jobsBody).getJSONArray("jobs")
                if (jobsArr.length() == 0) throw Exception("No jobs found for run #$lastRunId")

                val job     = jobsArr.getJSONObject(0)
                val jobId   = job.getLong("id")
                val jobName = job.optString("name", "build")
                appendLog("Loading logs for '$jobName' (job #$jobId)…")

                // 2. GitHub returns 302 → S3 presigned URL with raw log text
                val logApiUrl = "https://api.github.com/repos/$lastOwner/$repo/actions/jobs/$jobId/logs"
                val conn1 = (URL(logApiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    instanceFollowRedirects = false
                    connectTimeout = 30_000
                    readTimeout    = 30_000
                }

                val code1 = conn1.responseCode
                val logText: String

                if (code1 in 301..308) {
                    val redirectUrl = conn1.getHeaderField("Location")
                    conn1.disconnect()
                    // Follow without auth — S3 presigned URLs reject extra auth headers
                    val conn2 = (URL(redirectUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 30_000
                        readTimeout   = 120_000
                    }
                    val code2 = conn2.responseCode
                    logText = if (code2 == 200) {
                        conn2.inputStream.bufferedReader().readText().also { conn2.disconnect() }
                    } else {
                        conn2.disconnect()
                        throw Exception("Failed to download log (HTTP $code2)")
                    }
                } else if (code1 == 200) {
                    logText = conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                } else {
                    val err = conn1.errorStream?.bufferedReader()?.readText() ?: ""
                    conn1.disconnect()
                    throw Exception("Log API returned HTTP $code1: ${err.take(200)}")
                }

                appendLog("✓ Log loaded: ${logText.length / 1024} KB, ${logText.lines().size} lines")
                mainHandler.post { showLogDialog(logText, lastRunId) }

            } catch (e: Exception) {
                appendLog("✗ Log error: ${e.message}")
            } finally {
                setBusy(false)
            }
        }
    }

    private fun showLogDialog(logText: String, runId: Long) {
        val lines      = logText.lines()
        val totalLines = lines.size
        val maxLines   = 300
        val truncated  = totalLines > maxLines
        val displayText = buildString {
            if (truncated) append("⚠ Showing last $maxLines of $totalLines lines. Use 'Copy All' for full log.\n\n")
            append((if (truncated) lines.takeLast(maxLines) else lines).joinToString("\n"))
        }

        val scrollView = ScrollView(this)
        val tv = TextView(this).apply {
            text = displayText
            textSize = 9.5f
            setTextColor(0xFFCCCCCC.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
        }
        scrollView.addView(tv)
        // Scroll to bottom (latest output) after layout
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }

        AlertDialog.Builder(this)
            .setTitle("🔍  Build Log — Run #$runId")
            .setView(scrollView)
            .setPositiveButton("Copy All") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Build Log", logText))
                appendLog("✓ Full log copied (${logText.length / 1024} KB).")
            }
            .setNeutralButton("Tail to Console") { _, _ ->
                appendLog("=== Workflow Log — Run #$runId ===")
                lines.takeLast(60).forEach { appendLog(it) }
                appendLog("=== End of Log ===")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ── Clipboard & share ─────────────────────────────────────────────────────

    private fun copyLogToClipboard() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Build Log", text))
        appendLog("✓ Log copied to clipboard.")
    }

    private fun saveLogToFile() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        thread {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                val file  = File(cacheDir, "build_log_$stamp.txt")
                file.writeText(text)
                val uri = FileProvider.getUriForFile(this, "${packageName}.provider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                mainHandler.post { startActivity(Intent.createChooser(intent, "Share Build Log")) }
            } catch (e: Exception) {
                appendLog("✗ Share error: ${e.message}")
            }
        }
    }

    // ── Low-level HTTP ────────────────────────────────────────────────────────

    private fun httpGet(token: String, urlStr: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        return readResponse(conn)
    }

    private fun httpPut(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput       = true
            connectTimeout = 120_000
            readTimeout    = 120_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun httpPost(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput       = true
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun httpDelete(token: String, urlStr: String, body: String): Pair<Int, String> {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput       = true
            connectTimeout = 30_000
            readTimeout    = 30_000
        }
        conn.outputStream.bufferedWriter().use { it.write(body) }
        return readResponse(conn)
    }

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code   = conn.responseCode
            val stream = if (code < 400) conn.inputStream else conn.errorStream
            Pair(code, stream?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(when {
            text.contains("✓") || text.startsWith("Ready") || text.startsWith("Done") ->
                0xFF4CAF50.toInt()
            text.contains("✗") || text.startsWith("Fail") ->
                0xFFFF5252.toInt()
            else -> 0xFFFFFFFF.toInt()
        })
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
        btnManageZips.isEnabled  = !busy
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        name = name.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
