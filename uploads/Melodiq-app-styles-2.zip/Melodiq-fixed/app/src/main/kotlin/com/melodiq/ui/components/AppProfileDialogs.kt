package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.melodiq.R
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.overlay.InstalledApp
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.SurfaceDark
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White10

/*
 * The pieces of the "Floating lyrics per app" section of Settings: the rows of the list, the app picker,
 * the editor of one style, and the explanation of "Usage access".
 */

// ── Rows of the list ─────────────────────────────────────────────────────────

/** One row of the list: an icon, a title and a short line about the style. */
@Composable
fun StyleRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text     = title,
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text  = subtitle,
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** The row of an app that has a style of its own. */
@Composable
fun AppProfileRow(app: AppLyricsProfile, onClick: () -> Unit) {
    StyleRow(
        title    = app.label,
        subtitle = describeStyle(app.style, app.visible),
        onClick  = onClick
    ) {
        AppIcon(packageName = app.packageName, size = 40.dp)
    }
}

/** A rounded tile with a symbol, for the rows that are not an app (the home screen, all other apps). */
@Composable
fun StyleSlotIcon(iconRes: Int) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .background(White10, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        VectorIcon(id = iconRes, tint = AccentViolet, size = 22.dp)
    }
}

/** A short line about a style: where the window sits, how many lines, how big the text is. */
fun describeStyle(style: FloatingLyricsSettings, visible: Boolean = true): String {
    if (!visible) return "Hidden here"
    val lines = if (style.lines == 1) "1 line" else style.lines.toString() + " lines"
    return positionName(style.posX, style.posY) + " \u00B7 " + lines + " \u00B7 " + style.textSizeSp.toInt() + " sp"
}

private fun positionName(x: Float, y: Float): String {
    val vertical = when {
        y < 0.34f -> "Top"
        y < 0.67f -> "Middle"
        else      -> "Bottom"
    }
    val horizontal = when {
        x < 0.34f -> "left"
        x < 0.67f -> "centre"
        else      -> "right"
    }
    return if (vertical == "Middle" && horizontal == "centre") "Centre of the screen" else "$vertical $horizontal"
}

// ── Usage access ─────────────────────────────────────────────────────────────

/** Explains why Melodiq needs "Usage access" before sending the user to the system screen. */
@Composable
fun UsageAccessDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_floating, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Allow usage access") },
        text  = {
            Text(
                "To give every app its own floating lyrics, Melodiq has to know which app is on screen. " +
                    "It only sees the name of the app in front, never what is inside it. " +
                    "On the next screen, choose Melodiq and switch on \"Allow usage access\", then come back."
            )
        },
        confirmButton = {
            TextButton(onClick = onOpenSettings) { Text("Open settings", color = AccentViolet) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not now", color = TextSecondary) }
        }
    )
}

// ── Choosing an app ──────────────────────────────────────────────────────────

/** A searchable list of the apps on the phone. [alreadyAdded] are marked, tapping any of them calls [onPick]. */
@Composable
fun AppPickerDialog(
    alreadyAdded: Set<String>,
    loadApps: suspend () -> List<InstalledApp>,
    onPick: (InstalledApp) -> Unit,
    onDismiss: () -> Unit
) {
    val apps by produceState<List<InstalledApp>?>(initialValue = null) { value = loadApps() }
    var query by remember { mutableStateOf("") }

    MelodiqDialog(onDismiss = onDismiss, tall = true) {
        Text(
            text     = "Choose an app",
            color    = TextPrimary,
            style    = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )
        OutlinedTextField(
            value         = query,
            onValueChange = { query = it },
            singleLine    = true,
            placeholder   = { Text("Search apps", color = TextMuted) },
            colors        = melodiqFieldColors(),
            modifier      = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        val all = apps
        if (all == null) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryPurple)
            }
        } else {
            val shown = remember(all, query) {
                val needle = query.trim()
                all.filter { it.label.contains(needle, ignoreCase = true) }
            }
            if (shown.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No app found", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    items(shown, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(packageName = app.packageName, size = 40.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(
                                text     = app.label,
                                color    = TextPrimary,
                                style    = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (app.packageName in alreadyAdded) {
                                Text(
                                    text  = "Has a style",
                                    color = TextMuted,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── The editor of one style ──────────────────────────────────────────────────

/**
 * Full-screen editor of one floating-lyrics style: the style of an app, of the home screen & menu, or the
 * default style. It offers the same options everywhere ([FloatingStyleControls]); the parts that only make
 * sense for some of them are optional: [visible] adds a "show here" switch, [onUseDefault] and [onRemove]
 * add the buttons at the bottom. Every change is saved at once.
 */
@Composable
fun StyleEditorDialog(
    title: String,
    icon: @Composable () -> Unit,
    style: FloatingLyricsSettings,
    onStyleChange: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit,
    onClose: () -> Unit,
    whereTitle: String,
    note: String? = null,
    visible: Boolean? = null,
    onVisibleChange: (Boolean) -> Unit = {},
    onUseDefault: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null,
    removeLabel: String = "Remove this app"
) {
    Dialog(
        onDismissRequest = onClose,
        properties       = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = SurfaceDark) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconActionButton(
                        icon               = R.drawable.ic_arrow_back,
                        contentDescription = "Back",
                        onClick            = onClose,
                        tint               = Color.White,
                        buttonSize         = 48.dp,
                        iconSize           = 24.dp
                    )
                    icon()
                    Text(
                        text     = title,
                        style    = MaterialTheme.typography.titleLarge,
                        color    = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .weight(1f)
                    )
                }

                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp)
                ) {
                    FloatingPreview(style)

                    if (visible != null || note != null) {
                        SettingsSection(whereTitle) {
                            if (visible != null) {
                                SwitchRow(
                                    title    = "Show floating lyrics here",
                                    subtitle = "Off keeps the window away while this is on screen.",
                                    checked  = visible,
                                    onChange = onVisibleChange
                                )
                            }
                            if (note != null) {
                                Text(
                                    text     = note,
                                    color    = TextSecondary,
                                    style    = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    SettingsSection("Style") {
                        FloatingStyleControls(floating = style, update = onStyleChange)
                    }

                    if (onUseDefault != null || onRemove != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (onUseDefault != null) {
                                MelodiqButton(
                                    text     = "Use the default style",
                                    onClick  = onUseDefault,
                                    style    = ButtonStyle.Outlined,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (onRemove != null) {
                                MelodiqButton(
                                    text     = removeLabel,
                                    onClick  = onRemove,
                                    style    = ButtonStyle.Outlined,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
