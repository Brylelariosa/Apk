package com.melodiq.overlay

import android.content.Context
import android.content.Intent
import com.melodiq.data.model.HOME_SCREEN_KEY
import com.melodiq.data.model.HOME_SCREEN_LABEL

/** An app the user can open from the launcher. */
data class InstalledApp(val packageName: String, val label: String)

/** Looks up apps for the per-app floating lyrics: names for the list, and the apps to choose from. */
object InstalledApps {

    /**
     * The name to show for [key]: an app's package name, or the home-screen slot. When Android does not
     * let Melodiq see the app, the package name itself is shown.
     */
    fun label(context: Context, key: String): String {
        if (key == HOME_SCREEN_KEY) return HOME_SCREEN_LABEL
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(key, 0)).toString().ifBlank { key }
        } catch (e: Exception) {
            key
        }
    }

    /**
     * The launchers (home screens) installed on the phone. The app menu and the recent-apps screen belong to
     * the launcher, so while one of these is in front, no app is open. (The manifest's <queries> makes
     * them visible.)
     */
    fun homePackages(context: Context): Set<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val found = try {
            context.packageManager.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }
        return found
            // Settings has a stand-in "home" with a very low priority that is not a launcher.
            .filter { it.priority >= 0 }
            .map { it.activityInfo.packageName }
            .toSet()
    }

    /** Every app with a launcher icon, sorted by name, without the launchers (they are the home screen). */
    fun launchable(context: Context): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = try {
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }
        val homes = homePackages(context)
        return found
            .map { InstalledApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.packageName !in homes }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
