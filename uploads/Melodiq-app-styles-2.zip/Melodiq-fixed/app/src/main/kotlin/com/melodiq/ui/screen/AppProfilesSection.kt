package com.melodiq.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.HOME_SCREEN_KEY
import com.melodiq.data.model.HOME_SCREEN_LABEL
import com.melodiq.overlay.UsageAccessPermission
import com.melodiq.ui.components.AppIcon
import com.melodiq.ui.components.AppPickerDialog
import com.melodiq.ui.components.AppProfileRow
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.SettingsSection
import com.melodiq.ui.components.StyleEditorDialog
import com.melodiq.ui.components.StyleRow
import com.melodiq.ui.components.StyleSlotIcon
import com.melodiq.ui.components.SubHeading
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.UsageAccessDialog
import com.melodiq.ui.components.describeStyle
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.AppProfilesViewModel

/** What the editor is open for, besides an app's package name and [HOME_SCREEN_KEY]. */
private const val DEFAULT_KEY = "#default"

/**
 * Settings → "Floating lyrics per app": the floating lyrics can sit in a different place, and look different,
 * in every app. There are three kinds of style:
 *
 *  - **an app's own** — made by dragging the window while that app is open, or with "Add an app";
 *  - **the home screen & menu** — used while no app is open (home screen, app menu, recent apps);
 *  - **all other apps** — the default style, the one in the Floating lyrics section above. Every app
 *    without a style of its own looks the same.
 */
@Composable
fun AppProfilesSection(viewModel: AppProfilesViewModel = hiltViewModel()) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val defaultStyle by viewModel.defaultStyle.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var usageAllowed by remember { mutableStateOf(UsageAccessPermission.isGranted(context)) }
    var showUsageDialog by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }

    // Back from the system "Usage access" page: pick up the new permission.
    OnResumeEffect { usageAllowed = UsageAccessPermission.isGranted(context) }

    if (showUsageDialog) {
        UsageAccessDialog(
            onDismiss = { showUsageDialog = false },
            onOpenSettings = {
                showUsageDialog = false
                UsageAccessPermission.openSettings(context)
            }
        )
    }

    if (picking) {
        AppPickerDialog(
            alreadyAdded = remember(profiles.apps) { profiles.apps.map { it.packageName }.toSet() },
            loadApps     = { viewModel.launchableApps() },
            onPick       = { app ->
                viewModel.addApp(app)
                picking = false
                editing = app.packageName
            },
            onDismiss    = { picking = false }
        )
    }

    // ── The editor: for all other apps, for the home screen, or for one app ──────────────────────
    val openKey = editing
    val home = profiles.find(HOME_SCREEN_KEY)
    when (openKey) {
        null -> Unit

        DEFAULT_KEY -> StyleEditorDialog(
            title         = "All other apps",
            icon          = { StyleSlotIcon(R.drawable.ic_floating) },
            style         = defaultStyle,
            onStyleChange = { transform -> viewModel.updateDefaultStyle(transform) },
            onClose       = { editing = null },
            whereTitle    = "Default style",
            note          = "Every app that has no style of its own looks like this. " +
                "The home screen & menu and any app in the list below can have theirs."
        )

        HOME_SCREEN_KEY -> StyleEditorDialog(
            title           = HOME_SCREEN_LABEL,
            icon            = { StyleSlotIcon(R.drawable.ic_home) },
            style           = home?.style ?: defaultStyle,
            onStyleChange   = { transform -> viewModel.updateStyle(HOME_SCREEN_KEY, HOME_SCREEN_LABEL, transform) },
            onClose         = { editing = null },
            whereTitle      = "On the home screen & menu",
            note            = "Used while no app is open: the home screen, the app menu and the recent apps. " +
                "Drag the window there and Melodiq remembers the spot.",
            visible         = home?.visible ?: true,
            onVisibleChange = { visible -> viewModel.setVisible(HOME_SCREEN_KEY, HOME_SCREEN_LABEL, visible) },
            onRemove        = {
                editing = null
                viewModel.remove(HOME_SCREEN_KEY)
            },
            removeLabel     = "Same as all other apps"
        )

        else -> {
            val app = profiles.find(openKey)
            if (app != null) {
                StyleEditorDialog(
                    title           = app.label,
                    icon            = { AppIcon(packageName = app.packageName, size = 32.dp) },
                    style           = app.style,
                    onStyleChange   = { transform -> viewModel.updateStyle(app.packageName, app.label, transform) },
                    onClose         = { editing = null },
                    whereTitle      = "In this app",
                    note            = "Tip: drag the window while you are in this app and Melodiq remembers " +
                        "the spot. The position sliders are under Style \u2192 Window.",
                    visible         = app.visible,
                    onVisibleChange = { visible -> viewModel.setVisible(app.packageName, app.label, visible) },
                    onUseDefault    = { viewModel.useDefaultStyle(app.packageName, app.label) },
                    onRemove        = {
                        editing = null
                        viewModel.remove(app.packageName)
                    }
                )
            }
        }
    }

    // ── The section ──────────────────────────────────────────────────────────────────────────────
    SettingsSection("Floating lyrics per app") {
        SwitchRow(
            title    = "A style for each app",
            subtitle = "Drag the lyrics while an app is open and Melodiq remembers the spot for that app. " +
                "The home screen & menu have a style of their own, and every other app looks the same.",
            checked  = profiles.enabled,
            onChange = { on -> viewModel.setEnabled(on) }
        )

        if (profiles.enabled) {
            if (!usageAllowed) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text  = "Melodiq needs \"Usage access\" to see which app is on screen. " +
                            "Until then every app uses the default style.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    MelodiqButton(text = "Allow usage access", onClick = { showUsageDialog = true })
                }
            }

            StyleRow(
                title    = HOME_SCREEN_LABEL,
                subtitle = if (home != null) describeStyle(home.style, home.visible) else "Same as all other apps",
                onClick  = { editing = HOME_SCREEN_KEY }
            ) {
                StyleSlotIcon(R.drawable.ic_home)
            }
            StyleRow(
                title    = "All other apps",
                subtitle = "Default \u00B7 " + describeStyle(defaultStyle),
                onClick  = { editing = DEFAULT_KEY }
            ) {
                StyleSlotIcon(R.drawable.ic_floating)
            }

            SubHeading("Apps with their own style")
            val apps = remember(profiles.apps) { profiles.appsOnly.sortedBy { it.label.lowercase() } }
            if (apps.isEmpty()) {
                Text(
                    text     = "None yet. Open an app and drag the floating lyrics where you want them, " +
                        "or add an app below.",
                    color    = TextSecondary,
                    style    = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            } else {
                for (app in apps) {
                    key(app.packageName) {
                        AppProfileRow(app = app, onClick = { editing = app.packageName })
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.Start
            ) {
                MelodiqButton(
                    text    = "Add an app",
                    onClick = { picking = true },
                    icon    = R.drawable.ic_add,
                    style   = ButtonStyle.Tonal
                )
            }
            if (apps.isNotEmpty()) {
                ResetRow(text = "Remove all app styles", onReset = { viewModel.removeAllApps() })
            }
        }
    }
}
