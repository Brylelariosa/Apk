package com.melodiq.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.AppLyricsProfile
import com.melodiq.data.model.AppProfiles
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.HOME_SCREEN_KEY
import com.melodiq.data.model.sanitized
import com.melodiq.data.repository.AppProfileRepository
import com.melodiq.data.repository.SettingsRepository
import com.melodiq.overlay.InstalledApp
import com.melodiq.overlay.InstalledApps
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * The floating-lyrics styles per app: what the "per app" section of Settings shows and changes. A style
 * belongs to an app ([key] = its package name), to the home screen & menu ([HOME_SCREEN_KEY]), or it is the
 * default that everything else uses.
 */
@HiltViewModel
class AppProfilesViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: AppProfileRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val profiles: StateFlow<AppProfiles> = repository.state

    /** What every app (and the home screen) without a style of its own gets: the Floating lyrics settings. */
    val defaultStyle: StateFlow<FloatingLyricsSettings> = settingsRepository.settings
        .map { it.floating }
        .stateIn(viewModelScope, SharingStarted.Eagerly, settingsRepository.settings.value.floating)

    fun setEnabled(on: Boolean) = repository.setEnabled(on)

    /** Gives [app] a style of its own, starting from the default one. Does nothing if it has one already. */
    fun addApp(app: InstalledApp) {
        if (profiles.value.find(app.packageName) != null) return
        repository.upsert(
            AppLyricsProfile(app.packageName, app.label, visible = true, style = defaultStyle.value)
        )
    }

    // The functions below take a [key] (package name or HOME_SCREEN_KEY) and its [label]. The label only
    // matters for the home screen, which has no profile until the first change.

    fun setVisible(key: String, label: String, visible: Boolean) =
        repository.change(key, label, defaultStyle.value) { it.copy(visible = visible) }

    fun updateStyle(key: String, label: String, transform: (FloatingLyricsSettings) -> FloatingLyricsSettings) =
        repository.change(key, label, defaultStyle.value) { it.copy(style = transform(it.style).sanitized()) }

    /** Back to the default look; the spot the user chose is kept. */
    fun useDefaultStyle(key: String, label: String) =
        repository.change(key, label, defaultStyle.value) { slot ->
            slot.copy(style = defaultStyle.value.copy(posX = slot.style.posX, posY = slot.style.posY))
        }

    /** Changes the default style itself (the one in the Floating lyrics section). */
    fun updateDefaultStyle(transform: (FloatingLyricsSettings) -> FloatingLyricsSettings) =
        settingsRepository.update { it.copy(floating = transform(it.floating).sanitized()) }

    fun remove(key: String) = repository.remove(key)

    /** Removes the style of every app. The home screen keeps its own, it has a button of its own. */
    fun removeAllApps() = repository.update { current ->
        current.copy(apps = current.apps.filter { it.packageName == HOME_SCREEN_KEY })
    }

    /** The apps to choose from. Reads every app's name, so it runs off the main thread. */
    suspend fun launchableApps(): List<InstalledApp> =
        withContext(Dispatchers.Default) { InstalledApps.launchable(context) }
}
