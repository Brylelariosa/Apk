package com.melodiq.data.model

import androidx.compose.runtime.Immutable

/**
 * The slot of the home screen, the app menu and the recent-apps screen. While one of them is on screen no
 * app is open, so this slot's style is used. It is stored like an app (see [AppLyricsProfile.packageName]);
 * the "#" keeps it from ever being a real package name.
 */
const val HOME_SCREEN_KEY = "#home"

/** What the home-screen slot is called in lists. */
const val HOME_SCREEN_LABEL = "Home screen & menu"

/**
 * How the floating lyrics look in ONE app (Instagram, YouTube …) or on the home screen & menu.
 *
 * [style] is a complete set of floating-lyrics options: position, size, colours, lines and so on. The four
 * "when to show" switches inside it are not used: they stay global, see [withBehaviorOf].
 */
@Immutable
data class AppLyricsProfile(
    /** The app's package name, or [HOME_SCREEN_KEY] for the home screen & menu. */
    val packageName: String,
    /** The app's name when the profile was made, so the list needs no package lookup. */
    val label: String,
    /** False keeps the window hidden while this app is on screen. */
    val visible: Boolean = true,
    val style: FloatingLyricsSettings = FloatingLyricsSettings()
)

/** Everything stored about per-app styles. */
@Immutable
data class AppProfiles(
    /** Master switch. Off = every app uses the default style (the Floating lyrics settings). */
    val enabled: Boolean = true,
    val apps: List<AppLyricsProfile> = emptyList()
) {
    fun find(packageName: String?): AppLyricsProfile? =
        if (packageName == null) null else apps.firstOrNull { it.packageName == packageName }

    /** The profiles of real apps, without the home-screen slot (which has its own place in the list). */
    val appsOnly: List<AppLyricsProfile>
        get() = apps.filter { it.packageName != HOME_SCREEN_KEY }
}

/** What the floating window should look like right now. */
@Immutable
data class ResolvedFloating(
    val style: FloatingLyricsSettings,
    /**
     * The app (or [HOME_SCREEN_KEY]) whose style is in use or would be created by dragging. Null when
     * styles are not per app at the moment: then dragging changes the default style.
     */
    val packageName: String?,
    /** False while the app on screen asked for no floating window. */
    val visible: Boolean
)

/** Keeps this style but takes the "when to show" switches from [behavior]: those are the same for every app. */
fun FloatingLyricsSettings.withBehaviorOf(behavior: FloatingLyricsSettings): FloatingLyricsSettings = copy(
    enabled              = behavior.enabled,
    showOnlyWhilePlaying = behavior.showOnlyWhilePlaying,
    hideInApp            = behavior.hideInApp,
    hideWhenNoLyrics     = behavior.hideWhenNoLyrics
)

/** The same limits the Settings screen offers, so a stored value can never be out of range. */
fun FloatingLyricsSettings.sanitized(): FloatingLyricsSettings = copy(
    lines           = lines.coerceIn(1, 5),
    textSizeSp      = textSizeSp.coerceIn(10f, 40f),
    inactiveAlpha   = inactiveAlpha.coerceIn(0.1f, 1f),
    backgroundAlpha = backgroundAlpha.coerceIn(0f, 1f),
    cornerRadiusDp  = cornerRadiusDp.coerceIn(0, 40),
    windowAlpha     = windowAlpha.coerceIn(0.2f, 1f),
    widthFraction   = widthFraction.coerceIn(0.4f, 1f),
    posX            = posX.coerceIn(0f, 1f),
    posY            = posY.coerceIn(0f, 1f),
    animationMs     = animationMs.coerceIn(100, 800)
)

/**
 * Chooses the style for the app on screen: its own profile if it has one, otherwise the default
 * ([global]). Pure function, so it is the one place that decides.
 */
fun resolveFloating(
    global: FloatingLyricsSettings,
    profiles: AppProfiles,
    foregroundPackage: String?
): ResolvedFloating {
    if (!profiles.enabled || foregroundPackage == null) {
        return ResolvedFloating(style = global, packageName = null, visible = true)
    }
    val profile = profiles.find(foregroundPackage)
        ?: return ResolvedFloating(style = global, packageName = foregroundPackage, visible = true)
    return ResolvedFloating(
        style       = profile.style.withBehaviorOf(global),
        packageName = foregroundPackage,
        visible     = profile.visible
    )
}
