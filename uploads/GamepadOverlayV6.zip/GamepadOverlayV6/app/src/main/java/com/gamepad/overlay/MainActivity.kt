package com.gamepad.overlay

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupUI()
        setupCustomizeSection()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        syncSwitches()
    }

    // ── Permission / launch UI ────────────────────────────────────────────────

    private fun setupUI() {
        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnLaunchOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please grant overlay permission first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this,
                "Overlay launched! Drag each button on top of the game's matching button.",
                Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
        findViewById<Button>(R.id.btnStopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatus() {
        val overlayGranted = Settings.canDrawOverlays(this)
        val accessEnabled  = isAccessibilityServiceEnabled()

        findViewById<TextView>(R.id.tvOverlayStatus).apply {
            text = if (overlayGranted) "✅  Overlay Permission: Granted"
                   else "❌  Overlay Permission: Not Granted"
            setTextColor(if (overlayGranted) 0xFF7aff9a.toInt() else 0xFFff6060.toInt())
        }
        findViewById<TextView>(R.id.tvAccessibilityStatus).apply {
            text = if (accessEnabled) "✅  Accessibility Service: Enabled"
                   else "❌  Accessibility Service: Disabled"
            setTextColor(if (accessEnabled) 0xFF7aff9a.toInt() else 0xFFff9060.toInt())
        }
        findViewById<Button>(R.id.btnLaunchOverlay).isEnabled = overlayGranted
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabled.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    // ── Customization section ─────────────────────────────────────────────────

    private fun setupCustomizeSection() {

        // ── Visibility switches ───────────────────────────────────────────────
        val switchMap = mapOf(
            R.id.swJoystick  to "show_joystick",
            R.id.swDpad      to "show_dpad",
            R.id.swABXY      to "show_abxy",
            R.id.swShoulder  to "show_shoulder",
            R.id.swCenter    to "show_center"
        )
        for ((viewId, prefKey) in switchMap) {
            findViewById<Switch>(viewId).setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(prefKey, isChecked).apply()
                refreshOverlay()
            }
        }

        // ── Vibration switch ──────────────────────────────────────────────────
        findViewById<Switch>(R.id.swVibration).setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration_enabled", isChecked).apply()
            // No overlay refresh needed — OverlayService reads pref at vibrate() time
        }

        // ── Individual button presets ─────────────────────────────────────────
        // Face buttons
        data class Preset(val label: String, val color: Int)

        val faceButtons = listOf(
            Preset("A",  Color.argb(220,   0, 160,  70)),
            Preset("B",  Color.argb(220, 210,  40,  40)),
            Preset("X",  Color.argb(220,  20, 100, 210)),
            Preset("Y",  Color.argb(220, 200, 160,   0))
        )
        val dpadButtons = listOf(
            Preset("▲",  Color.argb(200,  70,  70, 110)),
            Preset("▼",  Color.argb(200,  70,  70, 110)),
            Preset("◄",  Color.argb(200,  70,  70, 110)),
            Preset("►",  Color.argb(200,  70,  70, 110))
        )
        val shoulderButtons = listOf(
            Preset("LB", Color.argb(200,  60,  60, 160)),
            Preset("RB", Color.argb(200,  60,  60, 160)),
            Preset("LT", Color.argb(200,  40,  40, 130)),
            Preset("RT", Color.argb(200,  40,  40, 130))
        )
        val extraButtons = listOf(
            Preset("L3",  Color.argb(200,  60,  60, 100)),
            Preset("R3",  Color.argb(200,  60,  60, 100)),
            Preset("ZL",  Color.argb(200,  30, 100, 130)),
            Preset("ZR",  Color.argb(200,  30, 100, 130)),
            Preset("Z",   Color.argb(200,  80,  50, 150)),
            Preset("C",   Color.argb(200, 150, 120,  20)),
            Preset("⚡",  Color.argb(200, 160,  80,   0)),
            Preset("★",   Color.argb(200, 160, 130,   0))
        )

        val allPresets = faceButtons + dpadButtons + shoulderButtons + extraButtons

        val presetContainer = findViewById<LinearLayout>(R.id.presetBtnContainer)
        presetContainer.removeAllViews()

        for (preset in allPresets) {
            val btn = Button(this).apply {
                text = "+ ${preset.label}"
                textSize = 12f
                setTextColor(Color.WHITE)
                val bg = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 24f * resources.displayMetrics.density
                    setColor(preset.color)
                }
                background = bg
                val dp8 = (8 * resources.displayMetrics.density).toInt()
                setPadding(dp8 * 2, dp8, dp8 * 2, dp8)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp8, 0, dp8, 0) }
                setOnClickListener { addExtraButton(preset.label, preset.color) }
            }
            presetContainer.addView(btn)
        }

        // ── Custom label button ───────────────────────────────────────────────
        findViewById<Button>(R.id.btnAddCustom).setOnClickListener {
            showAddCustomDialog()
        }

        // ── Reset positions ───────────────────────────────────────────────────
        findViewById<Button>(R.id.btnResetPositions).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset Button Positions")
                .setMessage("Return all buttons to their default positions?")
                .setPositiveButton("Reset") { _, _ ->
                    val edit = prefs.edit()
                    val posKeys = prefs.all.keys.filter { it.endsWith("_x") || it.endsWith("_y") }
                    posKeys.forEach { edit.remove(it) }
                    edit.apply()
                    refreshOverlay()
                    Toast.makeText(this, "Positions reset", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // ── Remove one extra button ───────────────────────────────────────────
        findViewById<Button>(R.id.btnRemoveOne).setOnClickListener {
            showRemoveOneDialog()
        }

        // ── Clear all extra buttons ───────────────────────────────────────────
        findViewById<Button>(R.id.btnClearExtra).setOnClickListener {
            val count = prefs.getInt("extra_btn_count", 0)
            if (count == 0) {
                Toast.makeText(this, "No extra buttons to remove", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("Remove All Extra Buttons")
                .setMessage("Remove all $count custom extra button(s)?")
                .setPositiveButton("Remove All") { _, _ ->
                    val edit = prefs.edit()
                    for (i in 0 until count) {
                        val t = "extra_$i"
                        edit.remove("${t}_label").remove("${t}_color")
                            .remove("${t}_x").remove("${t}_y")
                    }
                    edit.putInt("extra_btn_count", 0).apply()
                    refreshOverlay()
                    Toast.makeText(this, "All extra buttons removed", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun syncSwitches() {
        val switchMap = mapOf(
            R.id.swJoystick  to "show_joystick",
            R.id.swDpad      to "show_dpad",
            R.id.swABXY      to "show_abxy",
            R.id.swShoulder  to "show_shoulder",
            R.id.swCenter    to "show_center"
        )
        for ((viewId, prefKey) in switchMap) {
            val sw = findViewById<Switch>(viewId)
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = prefs.getBoolean(prefKey, true)
            sw.setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(prefKey, isChecked).apply()
                refreshOverlay()
            }
        }
        // Sync vibration switch
        val swVib = findViewById<Switch>(R.id.swVibration)
        swVib.setOnCheckedChangeListener(null)
        swVib.isChecked = prefs.getBoolean("vibration_enabled", true)
        swVib.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration_enabled", isChecked).apply()
        }
    }

    private fun addExtraButton(label: String, color: Int) {
        val idx = prefs.getInt("extra_btn_count", 0)
        val tag = "extra_$idx"
        prefs.edit()
            .putInt("extra_btn_count", idx + 1)
            .putString("${tag}_label", label)
            .putInt("${tag}_color", color)
            .apply()
        refreshOverlay()
        Toast.makeText(this,
            "Added \"$label\" button — go to game and drag it into position",
            Toast.LENGTH_LONG).show()
    }

    // ── Remove one extra button by index, compacting the list ─────────────────
    private fun showRemoveOneDialog() {
        val count = prefs.getInt("extra_btn_count", 0)
        if (count == 0) {
            Toast.makeText(this, "No extra buttons to remove", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = Array(count) { i ->
            prefs.getString("extra_${i}_label", "?") ?: "?"
        }
        AlertDialog.Builder(this)
            .setTitle("Remove Which Button?")
            .setItems(labels) { _, which ->
                removeExtraButtonAt(which)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeExtraButtonAt(index: Int) {
        val count = prefs.getInt("extra_btn_count", 0)
        if (index < 0 || index >= count) return
        val label = prefs.getString("extra_${index}_label", "?") ?: "?"
        val edit = prefs.edit()
        // Shift all entries after `index` down by one
        for (i in index until count - 1) {
            val nextTag = "extra_${i + 1}"
            val thisTag = "extra_$i"
            edit.putString("${thisTag}_label", prefs.getString("${nextTag}_label", "?"))
            edit.putInt("${thisTag}_color",   prefs.getInt("${nextTag}_color",   Color.argb(200, 90, 60, 160)))
            // Carry saved position too
            if (prefs.contains("${nextTag}_x")) {
                edit.putFloat("${thisTag}_x", prefs.getFloat("${nextTag}_x", 0.5f))
                edit.putFloat("${thisTag}_y", prefs.getFloat("${nextTag}_y", 0.5f))
            } else {
                edit.remove("${thisTag}_x").remove("${thisTag}_y")
            }
        }
        // Remove the last slot (now a duplicate)
        val lastTag = "extra_${count - 1}"
        edit.remove("${lastTag}_label").remove("${lastTag}_color")
            .remove("${lastTag}_x").remove("${lastTag}_y")
        edit.putInt("extra_btn_count", count - 1).apply()
        refreshOverlay()
        Toast.makeText(this, "Removed \"$label\"", Toast.LENGTH_SHORT).show()
    }

    private fun showAddCustomDialog() {
        val dp = resources.displayMetrics.density
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (20 * dp).toInt()
            setPadding(pad, pad, pad, 0)
        }
        val labelInput = EditText(this).apply {
            hint = "Label (1-3 chars, e.g. L3, ⚡, Z)"
            maxLines = 1
        }
        val colorLabel = TextView(this).apply {
            text = "Color:"
            setTextColor(Color.LTGRAY)
            val mt = (12 * dp).toInt()
            setPadding(0, mt, 0, 4)
        }
        val colors = listOf(
            "Green"  to Color.argb(220,   0, 160,  70),
            "Blue"   to Color.argb(220,  20, 100, 210),
            "Red"    to Color.argb(220, 210,  40,  40),
            "Yellow" to Color.argb(220, 200, 160,   0),
            "Purple" to Color.argb(220,  90,  60, 160),
            "Teal"   to Color.argb(220,  30, 140, 130),
            "Gray"   to Color.argb(220,  80,  80,  80)
        )
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                colors.map { it.first })
        }
        container.addView(labelInput)
        container.addView(colorLabel)
        container.addView(spinner)

        AlertDialog.Builder(this)
            .setTitle("Add Custom Button")
            .setView(container)
            .setPositiveButton("Add") { _, _ ->
                val label = labelInput.text.toString().trim().take(3)
                if (label.isEmpty()) {
                    Toast.makeText(this, "Enter a label", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val color = colors[spinner.selectedItemPosition].second
                addExtraButton(label, color)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshOverlay() {
        val refreshIntent = Intent(this, OverlayService::class.java).apply {
            action = "ACTION_REFRESH"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(refreshIntent)
        else startService(refreshIntent)
    }
}
