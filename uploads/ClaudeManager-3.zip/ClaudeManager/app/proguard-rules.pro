# R8 is on for release builds. Compose, Room, Lifecycle and coroutines ship their own
# consumer rules; the two rules below repeat the ones for classes that are created by name,
# so a release build can never lose them.

# Names stay readable so a crash log from the release APK points at the real class and method.
# Remove this line for a somewhat smaller dex (stack traces then need mapping.txt to read).
-dontobfuscate

# AndroidViewModel is built through reflection by the default ViewModel factory.
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}

# Room looks up AppDatabase_Impl by name.
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
