package com.claudemanager.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.claudemanager.app.data.ActivityStatus

// Chrome stays quiet and blue-grey; the status colours are the only loud thing on screen.

private val InkScheme = darkColorScheme(
    primary = Color(0xFF7FB0FF),
    onPrimary = Color(0xFF06142E),
    primaryContainer = Color(0xFF1E3566),
    onPrimaryContainer = Color(0xFFD8E5FF),
    secondary = Color(0xFFB0BCD6),
    onSecondary = Color(0xFF17202F),
    background = Color(0xFF0E1422),
    onBackground = Color(0xFFE8ECF5),
    surface = Color(0xFF151D2F),
    onSurface = Color(0xFFE8ECF5),
    surfaceVariant = Color(0xFF1D2740),
    onSurfaceVariant = Color(0xFF9FAAC4),
    outline = Color(0xFF44506C),
    outlineVariant = Color(0xFF27324B),
    error = Color(0xFFFF7A7A),
    onError = Color(0xFF3B0B0B)
)

private val PaperScheme = lightColorScheme(
    primary = Color(0xFF2457E6),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9E3FF),
    onPrimaryContainer = Color(0xFF0A1F5C),
    secondary = Color(0xFF55607A),
    onSecondary = Color(0xFFFFFFFF),
    background = Color(0xFFEDF0F6),
    onBackground = Color(0xFF141A29),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF141A29),
    surfaceVariant = Color(0xFFE2E7F1),
    onSurfaceVariant = Color(0xFF4B566F),
    outline = Color(0xFF8792AC),
    outlineVariant = Color(0xFFCDD5E4),
    error = Color(0xFFD93636),
    onError = Color(0xFFFFFFFF)
)

val StarGold = Color(0xFFF5B301)
val ResetGreen = Color(0xFF1F9D57)

fun statusColor(status: ActivityStatus): Color = when (status) {
    ActivityStatus.READY -> Color(0xFF8C96AB)
    ActivityStatus.RUNNING -> Color(0xFF2FBF71)
    ActivityStatus.BUILDING -> Color(0xFF3B82F6)
    ActivityStatus.TESTING -> Color(0xFFA266F0)
    ActivityStatus.WAITING -> Color(0xFFF2A93B)
    ActivityStatus.FINISHED -> Color(0xFFB7BECC)
    ActivityStatus.ERROR -> Color(0xFFEF4B4B)
    ActivityStatus.CUSTOM -> Color(0xFFE8579B)
}

@Composable
fun ClaudeManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) InkScheme else PaperScheme,
        content = content
    )
}
