package com.claudemanager.app.ui

import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityEvent
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.displayName
import com.claudemanager.app.data.findByName
import com.claudemanager.app.util.TimeUtil
import java.util.Calendar
import kotlinx.coroutines.flow.Flow

fun durationMillisOf(hours: String, minutes: String): Long =
    (hours.toLongOrNull() ?: 0L) * 3_600_000L + (minutes.toLongOrNull() ?: 0L) * 60_000L

/** Hours and minutes inputs, digits only. */
@Composable
fun DurationFields(
    hours: String,
    minutes: String,
    onHoursChange: (String) -> Unit,
    onMinutesChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = hours,
            onValueChange = { onHoursChange(it.filter { c -> c.isDigit() }.take(3)) },
            modifier = Modifier.weight(1f),
            label = { Text("Hours") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = minutes,
            onValueChange = { onMinutesChange(it.filter { c -> c.isDigit() }.take(2)) },
            modifier = Modifier.weight(1f),
            label = { Text("Minutes") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

/** One-tap status change: picking a row saves immediately. */
@Composable
fun StatusPickerDialog(
    project: Project,
    onSelect: (ActivityStatus) -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text("Change status") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                for (s in ActivityStatus.values()) {
                    val selected = s == project.activityStatus
                    val c = statusColor(s)
                    val label = if (s == ActivityStatus.CUSTOM && selected && project.customStatusLabel.isNotBlank()) {
                        "CUSTOM: ${project.customStatusLabel}"
                    } else {
                        s.name
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(s) }
                            .padding(horizontal = 4.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected,
                            onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = c,
                                unselectedColor = c.copy(alpha = 0.7f)
                            )
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = cs.onSurface
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CustomStatusDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Custom status") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24) },
                label = { Text("Status label") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Set status") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun NoteDialog(project: Project, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(project.activityNote) }
    val isError = project.activityStatus == ActivityStatus.ERROR
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (isError) "Error note" else "Note") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(140) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(if (isError) "Build failed - Gradle dependency error" else "Building APK")
                },
                minLines = 2,
                maxLines = 4
            )
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Save note") } },
        dismissButton = {
            Row {
                if (project.activityNote.isNotEmpty()) {
                    TextButton(onClick = { onSave("") }) { Text("Clear") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

/** Create (project == null) or edit a project. Can also add an account inline: just its email. */
@Composable
fun EditProjectDialog(
    project: Project?,
    accounts: List<Account>,
    defaultDurationMillis: Long,
    onSave: (
        name: String,
        accountId: Long?,
        newAccountEmail: String?,
        durationMillis: Long
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(project?.name ?: "") }
    var accountId by remember {
        mutableStateOf<Long?>(if (project != null) project.accountId else accounts.firstOrNull()?.id)
    }
    var creating by remember { mutableStateOf(project == null && accounts.isEmpty()) }
    var newEmail by remember { mutableStateOf("") }
    val initialMillis = project?.defaultDurationMillis ?: defaultDurationMillis
    var hours by remember { mutableStateOf((initialMillis / 3_600_000L).toString()) }
    var minutes by remember { mutableStateOf(((initialMillis / 60_000L) % 60L).toString()) }
    var menuOpen by remember { mutableStateOf(false) }

    val durationMillis = durationMillisOf(hours, minutes)
    val canSave = name.isNotBlank() && durationMillis > 0L && (!creating || newEmail.isNotBlank())
    val selectedAccount = accounts.firstOrNull { it.id == accountId }
    val alreadyListed = creating && newEmail.isNotBlank() && accounts.findByName(newEmail) != null

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (project == null) "New project" else "Edit project") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Project name") },
                    singleLine = true
                )

                if (creating) {
                    OutlinedTextField(
                        value = newEmail,
                        onValueChange = { newEmail = it.take(60) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Account email") },
                        placeholder = { Text("name@gmail.com") },
                        supportingText = { if (alreadyListed) Text("Already in your list. It will be used.") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    TextButton(onClick = { creating = false }) {
                        Text(
                            if (accounts.isNotEmpty()) "Use an existing account"
                            else "Skip the account for now"
                        )
                    }
                } else {
                    Box {
                        OutlinedButton(
                            onClick = { menuOpen = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = selectedAccount?.displayName ?: "No account",
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text("\u25BE")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            for (a in accounts) {
                                DropdownMenuItem(
                                    text = { Text(a.displayName) },
                                    onClick = {
                                        accountId = a.id
                                        menuOpen = false
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("No account") },
                                onClick = {
                                    accountId = null
                                    menuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("New account...") },
                                onClick = {
                                    menuOpen = false
                                    creating = true
                                }
                            )
                        }
                    }
                }

                Text(
                    text = "Default timer",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                DurationFields(
                    hours = hours,
                    minutes = minutes,
                    onHoursChange = { hours = it },
                    onMinutesChange = { minutes = it }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        name,
                        if (creating) null else accountId,
                        if (creating) newEmail else null,
                        durationMillis
                    )
                },
                enabled = canSave
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/**
 * Pick the reset as a clock time, like setting an alarm: 9:00 picked at 10:00 means 9:00 tomorrow.
 * Uses the system time picker, so it follows the phone's 12h/24h setting. The status is not touched.
 */
@Composable
fun ResetTimeDialog(project: Project, onSet: (Long) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val currentOnSet by rememberUpdatedState(onSet)
    val currentOnDismiss by rememberUpdatedState(onDismiss)

    DisposableEffect(project.id) {
        val openedAt = System.currentTimeMillis()
        val end = project.timerEndTimestamp
        // Start from the current reset time, or from "now + the default window" when there is none.
        val initial = Calendar.getInstance().apply {
            timeInMillis = if (end != null && end > openedAt) end else openedAt + project.defaultDurationMillis
        }
        val dialog = TimePickerDialog(
            context,
            { _, hour, minute ->
                currentOnSet(TimeUtil.nextOccurrence(hour, minute, System.currentTimeMillis()))
            },
            initial.get(Calendar.HOUR_OF_DAY),
            initial.get(Calendar.MINUTE),
            DateFormat.is24HourFormat(context)
        )
        dialog.setTitle("Reset time")
        dialog.setOnCancelListener { currentOnDismiss() }
        dialog.show()
        onDispose { dialog.dismiss() }
    }
}

private sealed interface HistoryRow {
    data class Header(val text: String) : HistoryRow
    data class Entry(val event: ActivityEvent) : HistoryRow
}

/** Day-grouped history: newest day first, events in time order inside each day. */
@Composable
fun HistoryDialog(
    project: Project,
    events: Flow<List<ActivityEvent>>,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val list by events.collectAsStateWithLifecycle(initialValue = emptyList())
    val rows = remember(list) {
        val now = System.currentTimeMillis()
        val out = mutableListOf<HistoryRow>()
        val byDay = list.groupBy { TimeUtil.dayKey(it.timestamp) }
        for ((_, dayEvents) in byDay) {
            out.add(HistoryRow.Header(TimeUtil.dayLabel(dayEvents.first().timestamp, now)))
            val ordered = dayEvents.sortedWith(compareBy<ActivityEvent> { it.timestamp }.thenBy { it.id })
            for (e in ordered) out.add(HistoryRow.Entry(e))
        }
        out
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(project.name) },
        text = {
            if (rows.isEmpty()) {
                Text(
                    text = "No activity yet. Every status change shows up here.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    items(rows) { row ->
                        when (row) {
                            is HistoryRow.Header -> Text(
                                text = row.text,
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = cs.primary
                            )
                            is HistoryRow.Entry -> {
                                val e = row.event
                                Column(Modifier.padding(vertical = 4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = TimeUtil.formatTime(context, e.timestamp),
                                            modifier = Modifier.width(76.dp),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = cs.onSurfaceVariant
                                        )
                                        StatusDot(statusColor(e.status), 9.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = statusLabel(e.status, e.customLabel),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = cs.onSurface
                                        )
                                    }
                                    if (e.note.isNotBlank()) {
                                        Text(
                                            text = e.note,
                                            modifier = Modifier.padding(start = 93.dp),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = cs.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            if (rows.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Clear history") }
            }
        }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = cs.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Add or edit an account. An account is just its email, so that is the only field. */
@Composable
fun AccountDialog(
    initial: Account?,
    accounts: List<Account>,
    onSave: (email: String) -> Unit,
    onDismiss: () -> Unit
) {
    var email by remember { mutableStateOf(initial?.displayName ?: "") }
    val value = email.trim()
    val taken = value.isNotEmpty() && accounts.findByName(value, exceptId = initial?.id) != null
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "New account" else "Edit account") },
        text = {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it.take(60) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Email") },
                placeholder = { Text("name@gmail.com") },
                isError = taken,
                supportingText = { if (taken) Text("Already in your list") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(value) }, enabled = value.isNotEmpty() && !taken) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
