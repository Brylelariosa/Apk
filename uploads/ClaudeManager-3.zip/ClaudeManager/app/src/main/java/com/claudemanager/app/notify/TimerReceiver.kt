package com.claudemanager.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.claudemanager.app.util.ProjectTitle

/** Fires at the reset time and rings the alarm notification. */
class TimerReceiver : BroadcastReceiver() {

    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val id = intent.getLongExtra(TimerScheduler.EXTRA_ID, 0L)
        val name = intent.getStringExtra(TimerScheduler.EXTRA_NAME) ?: "Project"
        val account = intent.getStringExtra(TimerScheduler.EXTRA_ACCOUNT).orEmpty()
        val resetAt = intent.getLongExtra(TimerScheduler.EXTRA_TRIGGER_AT, System.currentTimeMillis())

        TimerScheduler.ensureChannel(context)

        // Named like the cards: the account first, the project name next to the status line.
        val title = ProjectTitle.of(name, account)
        val status = "Claude limit reset \u2014 ready to use"
        val notification = NotificationCompat.Builder(context, TimerScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${title.primary} has reset")
            .setContentText(title.secondary?.let { "$it \u00B7 $status" } ?: status)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setWhen(resetAt)
            .setShowWhen(true)
            .setContentIntent(TimerScheduler.openAppIntent(context, id.toInt()))
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(id.toInt(), notification)
    }
}
