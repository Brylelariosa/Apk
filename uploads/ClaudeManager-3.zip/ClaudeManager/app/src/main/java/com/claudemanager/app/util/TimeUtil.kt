package com.claudemanager.app.util

import android.content.Context
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeUtil {

    /**
     * "2h 17m", "42m", "9m 05s", "45s".
     * Minutes are floored, so a fresh 2h 30m timer reads 2h 29m a second later.
     */
    fun formatRemaining(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return when {
            h > 0L -> "${h}h ${m}m"
            m >= 10L -> "${m}m"
            m > 0L -> "${m}m ${s.toString().padStart(2, '0')}s"
            else -> "${s}s"
        }
    }

    /** "5h", "2h 30m", "45m". */
    fun formatDuration(ms: Long): String {
        val totalMin = ms.coerceAtLeast(0L) / 60_000L
        val h = totalMin / 60L
        val m = totalMin % 60L
        return when {
            h > 0L && m > 0L -> "${h}h ${m}m"
            h > 0L -> "${h}h"
            else -> "${m}m"
        }
    }

    /** Clock time in the phone's 12h/24h style. */
    fun formatTime(context: Context, ms: Long): String =
        DateFormat.getTimeFormat(context).format(Date(ms))

    private fun sameDay(a: Long, b: Long): Boolean {
        val ca = Calendar.getInstance().apply { timeInMillis = a }
        val cb = Calendar.getInstance().apply { timeInMillis = b }
        return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR) &&
            ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR)
    }

    /** Clock time, prefixed with the weekday when it is not today. */
    fun formatClock(context: Context, ms: Long, now: Long): String {
        val time = formatTime(context, ms)
        if (sameDay(ms, now)) return time
        val day = SimpleDateFormat("EEE", Locale.getDefault()).format(Date(ms))
        return "$day $time"
    }

    /**
     * The next moment the wall clock reads [hour]:[minute], strictly after [now].
     * Like setting an alarm: 9:00 picked at 10:00 means 9:00 tomorrow.
     */
    fun nextOccurrence(hour: Int, minute: Int, now: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun dayKey(ms: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun dayLabel(ms: Long, now: Long): String {
        if (sameDay(ms, now)) return "Today"
        if (sameDay(ms, now - 24L * 60L * 60L * 1000L)) return "Yesterday"
        return SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(ms))
    }
}
