package com.claudemanager.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings

enum class Screen { HOME, ACCOUNTS, SETTINGS }

/** Which dialog is open. Dialogs look their project up by id so they always show live data. */
sealed interface DialogState {
    val projectId: Long?

    data class StatusPicker(override val projectId: Long) : DialogState
    data class CustomStatus(override val projectId: Long) : DialogState
    data class Note(override val projectId: Long) : DialogState
    data class EditProject(override val projectId: Long?) : DialogState
    data class SetTimer(override val projectId: Long) : DialogState
    data class History(override val projectId: Long) : DialogState
    data class ConfirmDelete(override val projectId: Long) : DialogState
}

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    val accounts by vm.accounts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val now by vm.ticker.collectAsStateWithLifecycle()

    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var dialog by remember { mutableStateOf<DialogState?>(null) }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    val actions = remember(vm) {
        ProjectActions(
            onStatusClick = { id -> dialog = DialogState.StatusPicker(id) },
            onSetStatus = { id, status -> vm.setStatus(id, status) },
            onStart = { id -> vm.start(id) },
            onResetTimer = { id -> vm.resetTimer(id) },
            onToggleFavorite = { id -> vm.toggleFavorite(id) },
            onEditNote = { id -> dialog = DialogState.Note(id) },
            onSetTimer = { id -> dialog = DialogState.SetTimer(id) },
            onHistory = { id -> dialog = DialogState.History(id) },
            onEdit = { id -> dialog = DialogState.EditProject(id) },
            onDelete = { id -> dialog = DialogState.ConfirmDelete(id) }
        )
    }

    when (screen) {
        Screen.HOME -> {
            HomeScreen(
                projects = projects,
                accounts = accounts,
                now = now,
                alarmOn = settings.notificationsEnabled,
                actions = actions,
                onAdd = { dialog = DialogState.EditProject(null) },
                onOpenAccounts = { screen = Screen.ACCOUNTS },
                onOpenSettings = { screen = Screen.SETTINGS }
            )
            DialogLayer(
                dialog = dialog,
                projects = projects,
                accounts = accounts,
                settings = settings,
                vm = vm,
                setDialog = { dialog = it }
            )
        }
        Screen.ACCOUNTS -> {
            AccountsScreen(
                accounts = accounts,
                projects = projects ?: emptyList(),
                onBack = { screen = Screen.HOME },
                onSave = { id, email -> vm.saveAccount(id, email) },
                onDelete = { id -> vm.deleteAccount(id) }
            )
        }
        Screen.SETTINGS -> {
            SettingsScreen(
                settings = settings,
                onBack = { screen = Screen.HOME },
                onChange = { vm.updateSettings(it) }
            )
        }
    }
}

@Composable
private fun DialogLayer(
    dialog: DialogState?,
    projects: List<Project>?,
    accounts: List<Account>,
    settings: Settings,
    vm: AppViewModel,
    setDialog: (DialogState?) -> Unit
) {
    if (dialog == null) return

    val project: Project? = dialog.projectId?.let { id -> projects?.firstOrNull { it.id == id } }
    val dismiss: () -> Unit = { setDialog(null) }

    when (dialog) {
        is DialogState.StatusPicker -> {
            if (project != null) {
                StatusPickerDialog(
                    project = project,
                    onSelect = { status ->
                        if (status == ActivityStatus.CUSTOM) {
                            setDialog(DialogState.CustomStatus(project.id))
                        } else {
                            vm.setStatus(project.id, status)
                            setDialog(null)
                        }
                    },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.CustomStatus -> {
            if (project != null) {
                CustomStatusDialog(
                    initial = project.customStatusLabel,
                    onSave = { label ->
                        vm.setStatus(project.id, ActivityStatus.CUSTOM, label)
                        setDialog(null)
                    },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.Note -> {
            if (project != null) {
                NoteDialog(
                    project = project,
                    onSave = { text ->
                        vm.setNote(project.id, text)
                        setDialog(null)
                    },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.EditProject -> {
            if (dialog.projectId == null || project != null) {
                EditProjectDialog(
                    project = project,
                    accounts = accounts,
                    defaultDurationMillis = settings.defaultDurationMillis,
                    onSave = { name, accountId, newEmail, durationMillis ->
                        vm.saveProject(dialog.projectId, name, accountId, newEmail, durationMillis)
                        setDialog(null)
                    },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.SetTimer -> {
            if (project != null) {
                ResetTimeDialog(
                    project = project,
                    onSet = { resetAt ->
                        vm.setResetAt(project.id, resetAt)
                        setDialog(null)
                    },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.History -> {
            if (project != null) {
                val events = remember(project.id) { vm.events(project.id) }
                HistoryDialog(
                    project = project,
                    events = events,
                    onClear = { vm.clearHistory(project.id) },
                    onDismiss = dismiss
                )
            }
        }
        is DialogState.ConfirmDelete -> {
            if (project != null) {
                ConfirmDialog(
                    title = "Delete ${project.name}?",
                    message = "The project and its activity history will be removed. The account stays.",
                    confirmLabel = "Delete",
                    onConfirm = {
                        vm.deleteProject(project.id)
                        setDialog(null)
                    },
                    onDismiss = dismiss
                )
            }
        }
    }
}
