package com.claudemanager.app.notify

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.claudemanager.app.MainActivity
import com.claudemanager.app.data.AppDatabase
import com.claudemanager.app.data.Prefs
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.displayName

/**
 * Sets one alarm-clock alarm per project, at the project's reset time.
 *
 * It uses [AlarmManager.setAlarmClock], the same call the Clock app uses: it fires on the exact
 * minute, also in Doze and battery saver. Alarms are lost on reboot and on app update, which is
 * what [BootReceiver] and [rescheduleAll] are for.
 */
object TimerScheduler {

    const val CHANNEL_ID = "reset_alarm"
    const val EXTRA_ID = "project_id"
    const val EXTRA_NAME = "project_name"
    const val EXTRA_ACCOUNT = "account_label"
    const val EXTRA_TRIGGER_AT = "trigger_at"

    /** The old quiet channel. Android never lets an app upgrade a channel's sound, so it is replaced. */
    private const val LEGACY_CHANNEL_ID = "timer_reset"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.deleteNotificationChannel(LEGACY_CHANNEL_ID)
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return

        // Alarm usage: plays on the alarm volume, even when the ringer is silent.
        val sound = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Reset alarms",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Rings when an account's Claude limit resets"
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), sound)
            enableVibration(true)
            vibrationPattern = longArrayOf(0L, 400L, 200L, 400L, 200L, 400L)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
    }

    /** Opens the app. Shared by the notification tap and the system's "next alarm" shortcut. */
    fun openAppIntent(context: Context, requestCode: Int): PendingIntent =
        PendingIntent.getActivity(
            context,
            requestCode,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(context: Context, project: Project, accountName: String?, enabled: Boolean) {
        val end = project.timerEndTimestamp
        if (!enabled || end == null || end <= System.currentTimeMillis()) {
            cancel(context, project.id)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TimerReceiver::class.java).apply {
            putExtra(EXTRA_ID, project.id)
            putExtra(EXTRA_NAME, project.name)
            putExtra(EXTRA_ACCOUNT, accountName.orEmpty())
            putExtra(EXTRA_TRIGGER_AT, end)
        }
        val operation = PendingIntent.getBroadcast(
            context,
            project.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setAlarm(alarmManager, end, operation, openAppIntent(context, project.id.toInt()))
    }

    private fun setAlarm(
        alarmManager: AlarmManager,
        triggerAt: Long,
        operation: PendingIntent,
        show: PendingIntent
    ) {
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            alarmManager.canScheduleExactAlarms()
        if (exactAllowed) {
            try {
                alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), operation)
                return
            } catch (e: SecurityException) {
                // Exact alarms were switched off in system settings: use the inexact one below.
            }
        }
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, operation)
    }

    fun cancel(context: Context, projectId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending: PendingIntent? = PendingIntent.getBroadcast(
            context,
            projectId.toInt(),
            Intent(context, TimerReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }

    /** Re-creates every alarm from the database. Safe to call as often as needed. */
    suspend fun rescheduleAll(context: Context) {
        val app = context.applicationContext
        val dao = AppDatabase.get(app).dao()
        val names = dao.getAccounts().associate { it.id to it.displayName }
        val enabled = Prefs(app).load().notificationsEnabled
        for (project in dao.getProjects()) {
            schedule(app, project, project.accountId?.let { names[it] }, enabled)
        }
    }
}
