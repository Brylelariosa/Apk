package com.claudemanager.app.util

/**
 * How a project is named wherever it is listed: the account first (the Claude limit belongs to
 * it), the project's own name under it. Cards, the active strip and the reset alarm all build
 * their text from here, so they can never disagree.
 */
data class ProjectTitle(
    val primary: String,
    val secondary: String? = null
) {

    /** One-line form for places with no room for two lines, such as "Main Claude · VoxelSandbox". */
    val singleLine: String
        get() = if (secondary == null) primary else "$primary \u00B7 $secondary"

    companion object {
        private const val UNTITLED = "Untitled project"

        fun of(projectName: String, accountName: String?): ProjectTitle {
            val project = projectName.trim()
            val account = accountName.orEmpty().trim()
            return when {
                // No account: the project name is the title.
                account.isEmpty() -> ProjectTitle(project.ifEmpty { UNTITLED })
                // Same text twice would only repeat itself.
                project.isEmpty() || project.equals(account, ignoreCase = true) -> ProjectTitle(account)
                else -> ProjectTitle(account, project)
            }
        }
    }
}
