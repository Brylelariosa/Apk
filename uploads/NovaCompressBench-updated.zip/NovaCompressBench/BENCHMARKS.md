# NovaCompress benchmark log

One entry per targeted change, following the same "one subsystem, one
measured improvement" process throughout: identify the biggest weakness in
one subsystem, fix only that, benchmark before/after, keep or revert based
on the numbers.

## Entry 1: repeat-offset distance coding (MatchFieldCoder)

### Methodology

Same constraint as the "Verification" section of the main README: no
Android SDK, Gradle, or network access in this sandbox, and this time not
even a Kotlin or Java *compiler* (only a JRE) - so the Kotlin project itself
couldn't be built or run here either. The approach was the same one the
README already documents for the original implementation: port the
highest-risk logic to a language actually runnable in the sandbox, verify
it round-trips correctly, measure before/after, and only then port the
verified change into the Kotlin source.

Concretely: the full encode/decode pipeline (`LongRangeMatcher`,
`MultiLevelDictionary`, `ContextPredictor`, `FreqModel`/`RangeEncoder`/
`RangeDecoder`, `MatchFieldCoder`, `EntropyCoderSelector`'s range-coder path,
`NovaSegmentCodec`) was ported line-for-line to Python, including the exact
32-bit hash/multiply wraparound arithmetic `LongRangeMatcher` and
`ContextPredictor` depend on. That port's *baseline* output was checked
against real numbers pasted from a device run of this app's own
Research Mode (`NovaCompress Bench` + `NovaCompress Research Mode` output,
all six built-in sample datasets) - ratio, token counts, match counts, and
prediction-hit counts all matched within noise (the only inputs that aren't
bit-identical are the PRNG streams generating the synthetic fixtures; same
structure, different bytes). That gave confidence the port's behavior, and
therefore its before/after measurements, reflect the real Kotlin code.

The Huffman fallback path in `EntropyCoderSelector` was not ported (the
range coder path was) - irrelevant to this change, since better context
modeling only ever shrinks the range-coded size further, making it *more*
likely to beat Huffman, never less.

### Where the bytes were actually going

Breaking the *baseline* encoder's own output down by component, across the
four sample types where NovaCompress trails Deflate/Bzip2/LZMA2/Zstd
(text, JSON, tabular/structured, executable-like):

| dataset    | total size | main entropy stream | match side-channel (dist+len) |
|------------|-----------:|---------------------:|-------------------------------:|
| text       |     39,728 |         2,519 (6.3%) |               37,209 (93.7%) |
| json       |     30,938 |         4,359 (14.1%)|               26,579 (85.9%) |
| table      |     39,478 |        11,143 (28.2%)|               28,335 (71.8%) |
| executable |     87,573 |        21,106 (24.1%)|               66,467 (75.9%) |

For comparison, on `synthetic_image.bmp` - the one sample type NovaCompress
already *wins* on (4.07x vs LZMA2's 3.03x, per the pasted device benchmark)
- the split is the opposite: 99.2% main stream, 0.8% side-channel, because
matches are rare there (0.1% match share) and `ContextPredictor` is doing
almost all the work (83% hit rate). That contrast is what pointed at the
match side-channel specifically, not the predictor, matcher, or main
entropy coder, as the thing to fix.

Digging one level further into the side-channel itself (distance and length
each split into an entropy-coded "slot" plus raw, uncompressed "extra
bits" - see `MatchFieldCoder`'s KDoc for the scheme): the raw *distance*
extra-bits alone were 56-69% of the total side-channel on every one of
those four datasets - by far the single largest component, ahead of the
distance slots, the length slots, and the length extra-bits combined.

### Root cause

`MatchFieldCoder` entropy-codes a distance's *slot* (its bit-length) but
always writes the bits *within* that slot raw, on the assumption that they're
close to uniformly distributed. That's a reasonable assumption for a
genuinely varied set of distances, but the matcher's own repeat-offset list
(`MultiLevelDictionary.repDistances`) already biases real files toward
reusing a *handful* of distances heavily - and periodic/structured data
(fixed-width records, columnar binary, anything with a repeating stride)
takes that further: the matcher keeps finding the exact same distance value
match after match, because the structure itself repeats. The slot compressed
away fine (adaptive model, one dominant symbol) - but the raw extra bits
were regenerated from scratch every single time even when the value never
changed, because nothing recognized "this is the same distance as before."

### The fix

Scoped to one subsystem: **entropy coding**, specifically how match
*distances* are encoded in `MatchFieldCoder`. Added a small (4-entry) MRU
cache of recently-used distance values, tracked independently inside
`MatchFieldCoder` itself (not the matcher's own repeat-offset list - this
one exists purely so the entropy coder can say "same as before" for free).
When a distance matches a cached entry, it costs one cheap, entropy-coded
symbol and *zero* extra bits, the same idea as LZMA's rep0-rep3 codes. When
it doesn't, encoding falls back to the original slot-plus-extra-bits scheme
unchanged. Match *lengths* are untouched - a length doesn't recur the way a
periodic structure's distance does, and MIN_MATCH-rebasing already gives the
single most common length the cheapest code.

Files touched:
- `entropy/MatchFieldCoder.kt` - the actual change (MRU cache, alphabet
  size now depends on `repSlots`, `pack`/`unpack` updated to match).
- `NovaSegmentCodec.kt` - one line, opting the *distance* `FieldWriter` into
  the new cache (`repSlots = MatchFieldCoder.DIST_REPEAT_SLOTS`); the length
  `FieldWriter` is constructed the same way as before (`repSlots` defaults
  to 0), and `decode()` needed no changes at all, since `unpack()`'s new
  `distRepSlots` parameter defaults to `DIST_REPEAT_SLOTS` - the value
  `encode()` always uses for the real distance writer.
- `MatchFieldCoderTest.kt` - added coverage for the new cache (round-trip
  correctness with a mix of hot/fresh distances, fewer unique values than
  cache slots, empty/single-value edges, and a size assertion that a
  constantly-recurring distance collapses to well under half its baseline
  size). Every pre-existing test in this file still constructs
  `FieldWriter()` with no arguments and therefore still exercises the exact
  original code path (`repSlots` defaults to 0) - none of them needed to
  change to keep passing.

One bug caught during verification, worth recording: an early version of
`unpack()` hardcoded `DIST_REPEAT_SLOTS` for the distance alphabet instead
of taking it as a parameter. That's harmless for the real `NovaSegmentCodec`
call site (which always uses `DIST_REPEAT_SLOTS` on the encode side too,
same as a fixed `minMatch` never being ambiguous there), but it would have
silently corrupted every pre-existing `MatchFieldCoderTest` case, since
those all encode distances with the *default* `repSlots = 0` and would
then have been decoded assuming `repSlots = 4` - an alphabet-size mismatch
that desyncs the range decoder into producing wrong values rather than
throwing. Caught by running the equivalent scenario through the Python
harness (reproduced in an isolated case: encoding `[5, 100, 7, 4, 4, 4]`
with `repSlots=0` and decoding with `repSlots=4` returns
`[0, 2, 0, 0, 0, 44]`) before this ever reached the Kotlin side. Fixed by
making `distRepSlots` an explicit `unpack()` parameter (defaulting to
`DIST_REPEAT_SLOTS`, so the real call site still needs no change) instead
of an assumed constant, and re-verified every test scenario, old and new,
against the harness afterward.

The rest of the pipeline - `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `Segmenter`, `RegionClassifier`, the container format -
is untouched.

### Results

Six built-in sample datasets, before vs. after, measured on the verified
Python port (byte-identical algorithm to the Kotlin change described
above), with every case round-trip-verified lossless:

| dataset    |    original | before (baseline) | after (this change) | ratio before | ratio after | size change |
|------------|------------:|-------------------:|----------------------:|--------------:|-------------:|------------:|
| text       |     262,144 |              39,728 |                 39,726 |         6.60x |        6.60x |      -0.01% |
| json       |     262,144 |              30,938 |                 30,703 |         8.47x |        8.54x |      -0.76% |
| **table**  | **262,144** |          **39,478** |             **19,267** |     **6.64x** |   **13.61x** |  **-51.20%**|
| image      |     196,608 |              48,167 |                 48,166 |         4.08x |        4.08x |      -0.00% |
| executable |     262,144 |              87,573 |                 87,463 |         2.99x |        3.00x |      -0.13% |
| random     |     262,144 |             267,323 |                267,323 |         0.98x |        0.98x |       0.00% |
| **total**  | 1,507,328   |             513,207 |                492,648 |         2.94x |        3.06x |      -4.01% |

(`random` isn't handled by the pipeline this change touches in the real
app - the segmenter routes incompressible input to STORE before it ever
reaches the matcher/entropy stage - so its baseline ratio here is slightly
below the app's real ~1.00x; that's a limitation of the Python harness, not
this change, and doesn't affect any of the numbers above it.)

The fixed-stride tabular case - exactly the kind of periodic/structured
binary data this fix targets - more than doubles its compression ratio
(6.64x -> 13.61x), moving it from clearly behind Deflate/Bzip2/Zstd
(per the pasted device benchmark: 7.77x/8.01x/22.08x) to solidly ahead of
Deflate and Bzip2 and within reach of LZMA2's 14.07x. JSON and
executable-like data get smaller, consistent (~0.1-0.8%) gains from the
same mechanism, matching the fact that they had *some* repeated-distance
structure but less than the tabular case's constant stride. Text, image,
and random data are unchanged to within rounding, as expected: text's match
distances are driven by scattered word positions with little offset reuse,
image data barely uses the matcher at all (0.1% match share - the predictor
already does the work there), and random data has no matches to encode.

No dataset regressed. Net effect across the full six-dataset suite: **-4.0%
total compressed size** (2.94x -> 3.06x aggregate ratio), driven almost
entirely by the one dataset the root-cause analysis predicted it should
help.

### Verdict

Kept. Improves one dataset dramatically, several others modestly, regresses
none, stays losslessly round-trip-verified throughout (including the new
Kotlin unit tests, checked against the same logic in the Python harness
since no Kotlin compiler was available to run them directly here), and the
change is contained to the entropy-coding of match distances specifically -
no changes to the matcher's search strategy, the predictor, the dictionary,
segmentation, or the container format.

### Suggested next subsystem

With the distance side-channel's dominant cost fixed, the *length* side of
`MatchFieldCoder` is the next largest remaining component on these same
datasets (2,971-7,477 bytes of length-slot entropy plus 4,684-6,008 bytes
of raw length extra-bits per dataset, from the same breakdown above) and
would likely benefit from a similar treatment - lengths cluster around a
small set of common values on structured data too, just not via a literal
repeat-offset mechanism the way distances do. After that, `text.txt` is the
dataset with the least headroom found in this pass (+0.01%) despite still
trailing Bzip2 by nearly 2x (6.60x vs 11.86x); its side-channel is 93.7% of
its output with very little of it concentrated in repeated distances, which
points more at the **matcher**'s parsing strategy (greedy + 1-step lazy
matching vs. LZMA-style optimal parsing, which would choose shorter/more
numerous matches when that leads to cheaper-to-encode distances) than at
anything in the entropy coder.

## Entry 2: adaptive segmentation (Segmenter + NovaContainerFormat)

### Starting point

Every one of the six built-in sample datasets reports "segments 1" in
Research Mode (Entry 1's pasted device benchmark confirms this on the
*current* build, post-Entry-1). That's not wrong for those specific files -
each one really is internally uniform (`table.bin` is fixed-stride records
throughout, `synthetic_text.txt` is prose throughout) - but it meant
`Segmenter` had never actually been exercised on the kind of file it exists
for: something that changes character partway through. The old `Segmenter`
only ever produced a new segment on a STORE<->NOVA strategy change; two
adjacent regions of very different content that both happened to classify
as NOVA (prose text next to a binary table, JSON next to image pixel data,
...) stayed one segment, sharing one dictionary and one entropy model
regardless of how different their statistics actually were.

### A correctness bug found while investigating

Before getting to compression ratio: reading `NovaContainerFormat.encodeChunk`
to understand what a segment boundary actually *does* to the encoded output
turned up a real data-corruption bug, not a hypothetical one.

The old design concatenated every NOVA-strategy segment's bytes into one
shared buffer, in file order - but a STORE segment that traded up to NOVA
after trial-compression (see Entry 1's methodology note on that mechanism;
it predates this entry) got appended to the *end* of that shared buffer,
regardless of where it actually sat in the file. `decodeChunk` then read
that buffer with a single sequential cursor, walking segments in file
order and assuming the buffer's layout matched. Whenever a promoted STORE
segment wasn't already the last segment in the chunk, that assumption was
false: decode would silently read the *next* NOVA segment's bytes in its
place, and everything from there on desyncs.

Reproduced directly, isolated from any Kotlin code, as a minimal trace:
segments `A(NOVA)="AAAA"`, `B(STORE, promoted)="BBBB"`, `C(NOVA)="CCCC"`
encode to a shared buffer `"AAAACCCCBBBB"` (B pushed to the end); decoding
that with a sequential per-segment cursor reads back `"AAAACCCCBBBB"` -
not the original `"AAAABBBBCCCC"`. Confirmed again on a realistic (not
adversarial) file: 128KB each of prose text, a fixed-stride binary table,
executable-like bytes, and genuinely random bytes, concatenated - the
table region classifies STORE (its within-window repetition is below the
classifier's detection threshold - a known blind spot, see
`RegionClassifier`'s KDoc) but compresses well on trial and gets promoted,
sitting between two NOVA regions. Round-tripping that file through the
pre-this-entry `encodeChunk`/`decodeChunk` **failed** - reconstructed
bytes didn't match the input.

This wasn't reachable by any existing test (`NovaContainerFormatTest`'s
`mixedRealisticChunk` alternates text and *genuinely* random bytes, which
never promotes, so the desync condition never fired), and doesn't show up
on any of the six single-character-family sample files (each is one
segment, so there's nothing to desync between). It's exactly the condition
genuine adaptive segmentation makes *more* likely to occur - more, smaller,
more-varied segments mean more opportunities for a STORE segment to land
between two NOVA ones - so it had to be fixed as part of this change, not
filed separately.

### The fix

Two parts, one for each half of the problem:

**Segmenter** now splits a run on two conditions instead of one:

1. A STORE<->NOVA strategy change - unconditional, as before (this is a
   structural requirement, not a heuristic: literal bytes and an encoded
   block aren't interchangeable).
2. A *structural* change - the window's `RegionKind` differs from the
   current run's, or its entropy has drifted more than
   `ENTROPY_DELTA_THRESHOLD` (1.0 bits/byte) from the run's average so far -
   once the run has reached `MIN_SEGMENT_SIZE` (16KB, four analyzer
   windows). The size gate exists so a single noisy window can't fragment
   a file into segments too small to be worth their own block; verified
   directly that it does its job (see Testing below).

Kind changes cover "repeated structures" (`REPETITIVE_BINARY` is its own
kind), "long literal regions" (a `BINARY_UNKNOWN`/non-repetitive stretch
reads differently than its neighbors), and general transitions between
data characteristics directly. The entropy check catches drift *within*
one kind family that a coarse kind bucket alone would miss - verified at
the unit level, independent of any kind change: two synthetic same-kind
regions with a deliberate entropy jump between them split correctly at
`ENTROPY_DELTA_THRESHOLD = 1.0`, and raising the threshold past the jump's
size correctly stops the split (`FileAnalyzerSegmenterTest.entropyDeltaSplitsIndependentlyOfKind`).

Segmenter only ever proposes *candidate* boundaries from these signals -
it has no way to know whether splitting there actually pays for itself
once a fresh model's warm-up cost and per-block framing overhead are
accounted for. That decision moved to where it can actually be measured:

**NovaContainerFormat.encodeChunk** now does two things differently:

- The STORE-vs-promote trial-compression is per-segment instead of pooled
  across the whole chunk - strictly more accurate (different STORE regions
  can have different real compressibility; a pooled trial only sees their
  average), and a natural consequence of processing segments individually
  rather than via one global concatenation.
- Every maximal run of consecutive effective-NOVA segments becomes one or
  more blocks, always in file order (fixing the corruption bug above as a
  side effect - a block only ever covers the exact segments it was built
  from, at their real position, so there's no shared buffer to desync). A
  run of more than one segment is trial-encoded *both* ways - merged into
  one block, and split into one block per segment - and whichever produces
  fewer total bytes, including each block's own ~28-byte framing overhead,
  is what's kept. This is the literal implementation of "split into
  multiple compression blocks only when benchmarks show a benefit": not a
  heuristic guess about when splitting helps, an actual trial encode and a
  byte-count comparison, every time.

This is a real, if bounded, cost: a multi-segment run gets trial-encoded
twice (merged + split) before the smaller one is kept, on top of the
per-segment STORE trial. Same tradeoff Entry 1 (and the STORE-promotion
mechanism, predating both entries) already accepted: pay a spare encode
call to *measure* instead of guess.

File format note: this changes the on-disk chunk layout (segment
boundaries now map to a variable number of blocks instead of always 0 or
1), so `NovaContainerFormat.VERSION` moved from 1 to 2 - streams compressed
with the old build won't decode with this one, and vice versa. There's no
existing format-stability promise in this repo to violate (the README
already labels NovaCompress "experimental"), so this is a clean version
bump rather than a compatibility break of anything documented as stable.

Files touched:
- `segment/Segmenter.kt` - the structural-transition logic described above
  (`MIN_SEGMENT_SIZE`, `ENTROPY_DELTA_THRESHOLD`).
- `format/NovaContainerFormat.kt` - per-segment STORE trial, run-based block
  construction with the merge-vs-split trial, block-sequenced decode (fixes
  the ordering bug), `VERSION` bump. This is more than a one-line wiring
  change (unlike Entry 1's touch on `NovaSegmentCodec.kt`) because making
  segment boundaries actually affect the compressed output - not just the
  STORE/NOVA choice, which is all they affected before - requires it: the
  old design concatenated every NOVA segment into one block regardless of
  how many segments existed, so a smarter `Segmenter` alone would have
  changed nothing about the compressed bytes without this half of the fix.
- `FileAnalyzerSegmenterTest.kt`, `NovaContainerFormatTest.kt` - coverage
  for the new behavior, including a direct regression test for the
  ordering bug (`promotedStoreSegmentSandwichedBetweenNovaSegmentsRoundTrips`)
  built from exactly the NOVA/promoted-STORE/NOVA shape described above.

The matcher, predictor, dictionary, entropy coder, and analyzer
(`FileAnalyzer`/`RegionClassifier`/`EntropyCalculator`) are untouched -
`Segmenter` and `NovaContainerFormat` only *consume* the analyzer's
per-window classification, they don't change how it's computed.

### Methodology

Same sandbox constraints as Entry 1 (no Android SDK/Gradle/Kotlin compiler
available here), same approach: port the relevant logic to Python, verify
it against real device numbers, measure before/after there, then apply the
identical logic to the Kotlin source. This entry additionally ported
`FileAnalyzer`/`RegionClassifier`/`EntropyCalculator` (straightforward -
no bit-level arithmetic, just counts and ratios) and both the old and new
`Segmenter`/`NovaContainerFormat` logic, including the old design's
ordering bug (kept bug-for-bug faithful on purpose, specifically so the
corruption could be demonstrated directly rather than just described).

The existing six sample datasets are each internally uniform, so they
can't exercise structural-transition segmentation at all - a second set of
heterogeneous fixtures was built specifically for this entry: text
directly followed by a fixed-stride binary table; a table directly
followed by random bytes; text/random/text; JSON followed by image pixel
data; a four-way mix of text/table/executable-like/random; and a
fine-grained (6KB-burst) alternation between text and table, to stress-test
whether `MIN_SEGMENT_SIZE` and the merge-vs-split trial actually prevent
pathological over-fragmentation on noisy input (they do - see Results).

A late correctness check on the harness itself is worth recording: the
per-block framing overhead was initially miscounted as 6 length-prefix
ints (24 bytes) in both the Kotlin constant and the Python harness, when
`writeBlock` actually writes 7 (originalLength, symbolCount, tokenCount,
matchTokenCount, predictHitCount, entropyBytes.size, sideChannelBytes.size
- 28 bytes). This doesn't affect losslessness (it only feeds the
merge-vs-split size *comparison*, not the encoding itself), but it would
have made that trial very slightly over-eager to choose "split." Fixed in
both the Kotlin constant and the Python harness before the final numbers
below; re-running the affected comparisons after the fix changed no
merge-vs-split decision and shifted total sizes by only a few bytes per
chunk.

### Results

Round-trip-verified lossless on every case below (including, critically,
the previously-corrupting one). "orig" is the file size; "old"/"new" are
total encoded chunk size (segment metadata + block framing + payloads;
excludes ~9 bytes of fixed chunk-level header common to both designs, so
absolute sizes are each about 9 bytes smaller than real on-disk output,
but ratios and deltas between old and new are unaffected by that).

**The six existing (uniform) sample datasets - checking for regressions:**

| dataset    |    orig | old total | new total | delta   |
|------------|--------:|----------:|----------:|--------:|
| text       | 262,144 |    39,769 |    39,772 |  +0.01% |
| json       | 262,144 |    30,746 |    30,749 |  +0.01% |
| table      | 262,144 |    19,310 |    19,313 |  +0.02% |
| image      | 196,608 |    48,209 |    48,212 |  +0.01% |
| executable | 262,144 |    87,506 |    87,509 |  +0.00% |
| random     | 262,144 |   262,159 |   262,162 |  +0.00% |

Every one of these stays exactly one segment, exactly one block - the new
structural-transition logic correctly finds nothing to split (each file
really is uniform), so the only difference is 3 fixed bytes of chunk-level
framing (a `blocks.size` int replacing a 1-byte `hasNova` flag). Immaterial
at any real file size, and exactly the "cost nothing when there's nothing
to split" half of "only split when benchmarks show a benefit."

**Heterogeneous files - where old design could never do anything but STORE/NOVA:**

| dataset                        |    orig | old total | old ok? | new total | new segs | new blocks | delta   |
|---------------------------------|--------:|----------:|:-------:|----------:|---------:|-----------:|--------:|
| text_then_table                 | 524,288 |    59,357 |   yes   |    59,155 |        2 |          2 |  -0.34% |
| json_then_image                 | 458,560 |   124,204 |   yes   |   123,306 |        2 |          2 |  -0.72% |
| four_way_mix (text/table/exe/rand) | 262,144 |   105,012 | **no**  |   103,184 |        4 |          3 |  n/a*   |
| fine_grained_alternating (6KB bursts) | 196,608 |    24,980 | **no**  |    26,204 |       32 |          1 |  n/a*   |

\* Old design's "total" for these two isn't a usable number - it's the
size of an output that doesn't decode back to the original (`old ok? = no`).
It's included to show the corrupted encoding wasn't even *smaller* for a
good reason (`fine_grained_alternating`'s old total looks smaller than
new's, but that's a broken encoding, not a more efficient one - see below).

`text_then_table` and `json_then_image` are the clean "genuine structural
transition, splitting helps" cases: two very different kinds of content,
each getting its own block instead of one shared model diluted between
them, for a real (if modest at these file sizes) size reduction.

`four_way_mix` is the standout: it's the exact real-world-shaped case that
triggers the ordering bug under the old design (verified: `old ok? = no`,
decoded output doesn't match input) - and the new design not only fixes
that, it also produces an encoding about 1.7% smaller (103,184 vs the old
design's 105,012 bytes - not shown as a delta in the table above, since the
old number is a broken encoding rather than a valid comparison point) by
splitting text/table/executable-like into 3 separate blocks (the
merge-vs-split trial's split side won) while correctly recognizing the
random quarter isn't worth encoding at all (stored inline, 0 blocks spent
on it).

`fine_grained_alternating` is the "don't fragment on noise" check:
`Segmenter` proposes 32 candidate segments (alternating every 6KB, finer
than `MIN_SEGMENT_SIZE`, so the entropy/kind signal alone doesn't suppress
splitting here - the old design's segment count agrees: also 16-32-ish),
but `encodeChunk`'s merge-vs-split trial measures that splitting this
finely doesn't pay for itself and correctly collapses everything back down
to a **single block** regardless. New total is slightly larger than the
old (broken) design's number, which is expected and fine: the old number
represents an encoding that doesn't round-trip, not a more efficient one -
comparing against it is comparing against something that doesn't actually
work. What matters is that the trial-based merge decision, not
`MIN_SEGMENT_SIZE` alone, is what's actually protecting against pathological
fragmentation here, which is the intended design (see "The fix" above).

### Testing

`min_segment_size` and `entropy_delta` were swept (8KB-64KB;
0.5-1.5 bits/byte) across every fixture above; results were insensitive to
`entropy_delta` in that range for these specific fixtures (their
transitions all happen to co-occur with a kind change too, so the entropy
check rarely fires alone here - verified independently at the unit level
instead, see `entropyDeltaSplitsIndependentlyOfKind`) and only mildly
sensitive to `min_segment_size` (smaller values propose more candidate
segments, which costs a little in fixed per-segment metadata and trial-encode
time without changing the final block count, since the merge-vs-split trial
already converges to the same answer regardless). `16KB` / `1.0 bits/byte`
were kept as defaults - not because they're uniquely optimal, but because
the result is robust in a reasonable neighborhood around them, which is a
better property than a sharply-tuned value that happens to score best on
exactly these six fixtures.

Kotlin-side coverage added: `FileAnalyzerSegmenterTest` gets three new
cases (kind-transition splitting, entropy-delta splitting isolated from any
kind change, and `MIN_SEGMENT_SIZE` suppressing a sub-threshold blip);
`NovaContainerFormatTest` gets three new cases (the ordering-bug regression
test described above, a heterogeneous-chunk-produces-multiple-segments
check, and a uniform-chunk-stays-one-segment check for the "only when it
helps" half). Every pre-existing test in both files is unchanged and still
passes under the new logic (verified against the Python harness rather
than a Kotlin compiler, per Entry 1's methodology note).

### Verdict

Kept. Fixes a real, previously-undetected data-corruption bug (not a
theoretical one - reproduced on a realistic, non-adversarial file), gives
a measurable compression benefit on genuinely heterogeneous content
(-0.3% to -1.7% in these tests, likely more on real-world files that mix
content types more often than clean synthetic benchmarks do), costs
nothing measurable on uniform content, and the "only split when it
measurably helps" requirement is enforced by an actual trial-encode
comparison in `encodeChunk` rather than a tuned heuristic threshold -
verified directly on an adversarial fine-grained-alternation input where
`Segmenter` proposes 32 segments and the trial correctly collapses them
back to one block.

### Suggested next subsystem

The merge-vs-split trial currently only considers two shapes per run -
fully merged, or fully split into one block per segment - not partial
groupings (e.g. segments 1+2 merged, segment 3 separate). A run of many
short alternating segments (like `fine_grained_alternating`) always
resolves to "merge everything," even if some sub-grouping within the run
would do better; the fully-merged-vs-fully-split trial can't see that
option. Extending it to consider boundaries individually (or a bounded
dynamic-programming search over partition points) is bounded, well-scoped
follow-up work if a real file surfaces this pattern.

Separately, and unrelated to segmentation: `text.txt` is still the
dataset with the least headroom found across both entries so far (Entry 1:
+0.01%; this entry: +0.01%, since it's already one uniform segment) despite
still trailing Bzip2 by nearly 2x. Its side-channel is dominated by match
tokens with little concentrated repeated-distance structure for Entry 1's
fix to catch, which points at the **matcher**'s parsing strategy (greedy +
1-step lazy matching vs. LZMA-style optimal parsing) as the next place to
look, same conclusion Entry 1 reached.

## Entry 3: FileAnalyzer/RegionClassifier periodicity blind spot (investigated, not fixed)

### Starting point

A targeted request to review `FileAnalyzer` for ratio-limiting classification
gaps, prompted by `RegionClassifier`'s own KDoc and Entry 2's aside ("the
table region classifies STORE ... a known blind spot") - i.e. is this known,
accepted gap actually costing anything, or just noted-and-never-checked?

### Methodology

Same sandbox constraint as Entries 1-2 (no Android SDK/Gradle/network, and
this time not even a Kotlin compiler - only a JRE), same approach: port the
relevant logic to a runnable language, verify the port against real numbers,
measure, decide. This time the *entire* encode-side pipeline was ported (not
just the piece under test) - `EntropyCalculator`, `RegionClassifier`,
`FileAnalyzer`, `Segmenter`, `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `MatchFieldCoder`, `FreqModel`/`RangeEncoder`,
`HuffmanCoder`, `EntropyCoderSelector`, `NovaSegmentCodec`, and
`NovaContainerFormat.encodeChunk`'s trial/merge/split/framing logic - to Java,
since a ratio question about `FileAnalyzer` can't be answered by looking at
`FileAnalyzer`'s output in isolation; it has to be traced all the way through
to final on-disk bytes. The port's baseline (original, unmodified classifier)
reproduced the six-dataset device benchmark within ~1% on every file (e.g.
table 13.62x here vs. 13.57x on device, image 4.07x vs. 4.07x, executable
2.998x vs. 3.00x) - same caveat as Entries 1-2: PRNG streams for the
synthetic fixtures differ, structure doesn't.

### Root cause, confirmed

`synthetic_table.bin`'s 4KB windows measure entropy ~7.95 bits/byte and
shingle-repetition ~0.227 - just under `REPETITIVE_STRUCTURE_THRESHOLD`
(0.25) - so every window falls through to `ALREADY_COMPRESSED_OR_ENCRYPTED`
and the whole file classifies STORE, exactly as `RegionClassifier`'s KDoc
already flagged as a known gap. Root cause: the 24-byte record's arithmetic-
ramp fields change every record, so most of its 8-byte non-overlapping
shingles never repeat within one window regardless of alignment - a
byte-value histogram plus content-defined-but-non-overlapping shingle
hashing both miss "predictable from position" structure that isn't literal
repetition. A stride-autocorrelation check (does byte N match, or differ by
a constant delta from, byte N-stride for small candidate strides) correctly
reclassifies it as `REPETITIVE_BINARY` and doesn't misfire on genuinely
random data (checked directly: `synthetic_random.bin`'s classification is
unchanged).

### Why the fix doesn't change compressed size

`NovaContainerFormat.encodeChunk` (added in Entry 2, for an unrelated
correctness bug) trial-encodes every STORE-classified segment and promotes
it to the NOVA pipeline whenever that trial actually compresses smaller than
verbatim storage - and `ContextPredictor`'s tier-3 linear/delta fallback
(`predicted = 2*prev - prevPrev`) exactly predicts an arithmetic-ramp field
regardless of segment size, so the isolated trial on a misclassified segment
like this one always succeeds and promotes it. Once promoted, a segment is
grouped into the same effectively-NOVA run as its neighbors and hits the
same merge-vs-split trial either way - so the final encoded bytes are
byte-for-byte identical whether the classifier got the label right the first
time or got it wrong and was corrected downstream.

Measured on all nine fixtures tried (the six built-in samples, plus three
synthetic `20KB JSON + N KB table + 20KB JSON` mixes at N=1/3/8, built
specifically to stress-test whether a *small, embedded* misclassified region
behaves differently from a whole-file one): **0.00% change in final
compressed size on every single one.** The only measured difference is
redundant work: a misclassified-then-promoted segment gets
`NovaSegmentCodec.encode()`'d twice (once for the isolated STORE trial, once
more building its block) instead of once - 50% fewer `encode()` calls on
`table.bin` alone (2 -> 1), 20% fewer on the two larger mixed fixtures - a
real but purely computational saving, not a ratio one.

### Verdict

**Reverted / not shipped.** The fix is correct and the root cause is real,
but it moved zero bytes on every fixture tested, including deliberately
adversarial mixed-content ones - `encodeChunk`'s trial-and-promote safety
net (see Entry 2) already fully absorbs this specific class of
classification error, provided the misclassified content is genuinely
compressible, which it always was in every case tried here. Shipping a
classifier change with a measured ratio benefit of zero doesn't meet this
project's "keep or revert based on the numbers" bar. `FileAnalyzer.kt`,
`RegionClassifier.kt`, and `EntropyCalculator.kt` are unchanged from before
this entry; only a KDoc note in `RegionClassifier.kt` was added, pointing
back here so the gap doesn't get "rediscovered" as unverified in a future
pass.

### Suggested next subsystem

Not `FileAnalyzer` - the safety net means classification accuracy isn't
where the compressed bytes are being lost. Redoing this entry's full-pipeline
byte breakdown on the current (post-Entry-1) build confirms Entries 1 and
2 both already pointed at the right place: the match side-channel is still
75-94% of total output on text/json/executable (`text` 93.5%, `json` 85.7%,
`executable` 75.9%, `table` 41.9% - lower only because Entry 1's
repeat-offset cache already helps its constant record stride specifically).
A direct `MIN_MATCH` sensitivity sweep (4/5/6/8/10/12/16) on these four
datasets shows raising the threshold shuffles bytes between the main entropy
stream and the side-channel but doesn't reliably shrink the total - e.g.
`executable.bin` stays within 2,996-90,668 bytes of its baseline across the
whole sweep with no consistent winner - confirming this isn't a threshold
worth just re-tuning. It's a parsing-strategy gap: `LongRangeMatcher` takes
any match >= `MIN_MATCH` and does one step of lazy lookahead comparing raw
match *length*, with no model of what that match actually costs to encode
(a fresh, expensive-to-encode distance vs. a free repeat-offset slot). Cost-
aware / LZMA-style optimal parsing - preferring a match only when its real
encoded cost beats the literals (or a cheaper match) it replaces - is the
next well-evidenced target, same conclusion both prior entries reached
independently.

## Entry 4: LongRangeMatcher cost-aware candidate ranking

### Starting point

Entry 3's "suggested next subsystem": the matcher takes any match >=
`MIN_MATCH` and ranks candidates (both the hash-chain walk and the 1-step
lazy lookahead) by raw byte length alone, with no model of what a match
actually costs to encode. Goal: raise ratio on `text`/`json`/`executable`
without hurting speed, touching only the matcher.

### Methodology

Same full-pipeline Java port as Entry 3 (this sandbox still has no
Kotlin/Gradle/Android SDK), extended with a toggleable `LongRangeMatcher`
so `COST_AWARE=false` reproduces the shipped matcher byte-for-byte -
confirmed: every one of the eight fixtures below round-trips to the exact
"BEFORE" total in the table. Two designs were tried, measured, and
reverted before the one that shipped; recording why, since both looked
reasonable on paper.

### Attempt 1 (reverted): analytic bit-cost model

Estimated each match's real encoded cost from `MatchFieldCoder`'s own
scheme (slot symbol + extra bits, repeat-offset slots cheap) and each
candidate literal run's cost from a fixed bits-per-byte constant, then
accepted only matches with positive estimated savings. Result: `json`
-7.4%, `table` -5.8%, `text` roughly flat - but `executable.bin` got
*worse*, +0.9% to +2.8% across every constant tried. Root cause: the
formula's implied ~31-bit cost for a short fresh-distance match was
roughly 1.6x the ~18.75-bit real average (typical matches in this content
turned out to have small, cheap-to-encode distances - opcodes recur every
few bytes - not the near-max-file-size distances the formula implicitly
assumed).

### Attempt 2 (reverted): self-calibrated per-byte-value literal cost

Replaced the fixed literal-cost constant with a per-file order-0 byte
histogram (Laplace-smoothed, prefix-summed for O(1) range queries), so
common bytes cost less than rare ones instead of a flat guess. Made
`executable.bin` *worse still* (+0.9% to +2.8%, literal count nearly
tripled from 18,150 to 42,751): a *global*, position-blind histogram can't
represent that this content's real entropy coder splits literal
statistics by context (`EntropyCoderSelector`'s post-match vs.
post-literal split - see Entry 1), and ~87% of this file's bytes come
from a ~10-value opcode alphabet mixed with near-uniform random operand
bytes, a distribution shape a single formula couldn't fit for both this
and text/JSON/table at once without per-content tuning - exactly the kind
of fragility Entry 3 flagged analytic literal-cost modeling as risking.

### What shipped: ranking-only repeat-offset preference

Dropped cost *estimation* entirely in favor of the one piece of that
reasoning that needs no calibration: a repeat-offset distance is *always*
cheaper to encode than a fresh one (one MRU slot symbol vs. a slot symbol
plus up to ~17-18 raw extra bits), so it's worth ranking above a modestly
longer fresh-distance candidate - never accepting a *worse* match outright,
only preferring a cheaper one when candidates are close. Swept
`REPEAT_BONUS` (the length credit given to a qualifying repeat-offset
candidate) x `REPEAT_BONUS_MIN_LEN` (the repeat candidate's own minimum
length before it's eligible for the bonus - guards against a bare
4-byte repeat undercutting a genuinely longer fresh match) against real
encoded output on all six built-in fixtures plus two synthetic
`20KB JSON + N KB table + 20KB JSON` mixes (N=3,8). `minLen=8, bonus=2` was
the strongest point found where **no fixture got worse**, only smaller or
unchanged:

| fixture | before | after | ratio before -> after |
|---|---:|---:|---|
| `text.txt` | 39,843 | 39,807 | 6.579x -> 6.585x |
| `records.json` | 30,659 | 30,348 | 8.550x -> 8.638x |
| `random.bin` | 262,171 | 262,171 | 1.000x -> 1.000x (unchanged) |
| `table.bin` | 19,246 | 18,146 | 13.621x -> 14.446x |
| `image.bmp` | 48,331 | 48,331 | 4.069x -> 4.069x (unchanged) |
| `executable.bin` | 87,431 | 87,429 | 2.998x -> 2.998x |
| mixed json+3K table+json | 3,281 | 3,210 | 13.420x -> 13.717x |
| mixed json+8K table+json | 3,964 | 3,885 | 12.400x -> 12.652x |

All eight numbers are through the real `encodeChunk` path (full framing
overhead included, not just the raw codec), with the classifier untouched
from Entry 3's shipped state.

### Verdict

**Shipped.** Genuine gains on two of the three targeted types (`text`,
`json`) plus `table` and both mixed-content stress fixtures, `executable`
effectively flat (-2 bytes, technically a tiny improvement, not the
regression either analytic attempt produced), and zero fixtures worse than
before. Change is contained to `LongRangeMatcher.kt`: `rankScore` adds one
4-element array scan per candidate already being evaluated - no new O(n)
passes, no touched `FileAnalyzer`/`ContextPredictor`/`EntropyCoderSelector`/
`NovaContainerFormat`. Token semantics, decode logic, and match validity
constraints (`length >= MIN_MATCH`, `distance <= i`) are all unchanged, so
losslessness holds by the same argument as the original matcher: decode
doesn't care *which* valid match was chosen, only that it *is* valid.

### Suggested next subsystem

The ranking-only fix is deliberately conservative - it changes which
*already-found* candidate wins, not how thoroughly candidates are searched
for. Genuine LZMA-style optimal parsing (a real DP over the token graph,
minimizing actual encoded bits rather than an approximation) is still on
the table for a further ratio gain, but Attempts 1-2 above are a concrete
warning that its per-symbol cost function needs to be sourced from the
*real*, context-split, adaptive model `EntropyCoderSelector` and
`MatchFieldCoder` actually use - not a hand-derived formula - or it risks
the same executable.bin-shaped failure mode twice.
