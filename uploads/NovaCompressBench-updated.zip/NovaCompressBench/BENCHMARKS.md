# Benchmark: repeat-offset distance coding (MatchFieldCoder)

This documents one targeted change to NovaCompress and the measurements
behind it, following the same "one subsystem, one measured improvement"
process as the rest of this repo.

## Methodology

Same constraint as the "Verification" section of the main README: no
Android SDK, Gradle, or network access in this sandbox, and this time not
even a Kotlin or Java *compiler* (only a JRE) - so the Kotlin project itself
couldn't be built or run here either. The approach was the same one the
README already documents for the original implementation: port the
highest-risk logic to a language actually runnable in the sandbox, verify
it round-trips correctly, measure before/after, and only then port the
verified change into the Kotlin source.

Concretely: the full encode/decode pipeline (`LongRangeMatcher`,
`MultiLevelDictionary`, `ContextPredictor`, `FreqModel`/`RangeEncoder`/
`RangeDecoder`, `MatchFieldCoder`, `EntropyCoderSelector`'s range-coder path,
`NovaSegmentCodec`) was ported line-for-line to Python, including the exact
32-bit hash/multiply wraparound arithmetic `LongRangeMatcher` and
`ContextPredictor` depend on. That port's *baseline* output was checked
against real numbers pasted from a device run of this app's own
Research Mode (`NovaCompress Bench` + `NovaCompress Research Mode` output,
all six built-in sample datasets) - ratio, token counts, match counts, and
prediction-hit counts all matched within noise (the only inputs that aren't
bit-identical are the PRNG streams generating the synthetic fixtures; same
structure, different bytes). That gave confidence the port's behavior, and
therefore its before/after measurements, reflect the real Kotlin code.

The Huffman fallback path in `EntropyCoderSelector` was not ported (the
range coder path was) - irrelevant to this change, since better context
modeling only ever shrinks the range-coded size further, making it *more*
likely to beat Huffman, never less.

## Where the bytes were actually going

Breaking the *baseline* encoder's own output down by component, across the
four sample types where NovaCompress trails Deflate/Bzip2/LZMA2/Zstd
(text, JSON, tabular/structured, executable-like):

| dataset    | total size | main entropy stream | match side-channel (dist+len) |
|------------|-----------:|---------------------:|-------------------------------:|
| text       |     39,728 |         2,519 (6.3%) |               37,209 (93.7%) |
| json       |     30,938 |         4,359 (14.1%)|               26,579 (85.9%) |
| table      |     39,478 |        11,143 (28.2%)|               28,335 (71.8%) |
| executable |     87,573 |        21,106 (24.1%)|               66,467 (75.9%) |

For comparison, on `synthetic_image.bmp` - the one sample type NovaCompress
already *wins* on (4.07x vs LZMA2's 3.03x, per the pasted device benchmark)
- the split is the opposite: 99.2% main stream, 0.8% side-channel, because
matches are rare there (0.1% match share) and `ContextPredictor` is doing
almost all the work (83% hit rate). That contrast is what pointed at the
match side-channel specifically, not the predictor, matcher, or main
entropy coder, as the thing to fix.

Digging one level further into the side-channel itself (distance and length
each split into an entropy-coded "slot" plus raw, uncompressed "extra
bits" - see `MatchFieldCoder`'s KDoc for the scheme): the raw *distance*
extra-bits alone were 56-69% of the total side-channel on every one of
those four datasets - by far the single largest component, ahead of the
distance slots, the length slots, and the length extra-bits combined.

## Root cause

`MatchFieldCoder` entropy-codes a distance's *slot* (its bit-length) but
always writes the bits *within* that slot raw, on the assumption that they're
close to uniformly distributed. That's a reasonable assumption for a
genuinely varied set of distances, but the matcher's own repeat-offset list
(`MultiLevelDictionary.repDistances`) already biases real files toward
reusing a *handful* of distances heavily - and periodic/structured data
(fixed-width records, columnar binary, anything with a repeating stride)
takes that further: the matcher keeps finding the exact same distance value
match after match, because the structure itself repeats. The slot compressed
away fine (adaptive model, one dominant symbol) - but the raw extra bits
were regenerated from scratch every single time even when the value never
changed, because nothing recognized "this is the same distance as before."

## The fix

Scoped to one subsystem: **entropy coding**, specifically how match
*distances* are encoded in `MatchFieldCoder`. Added a small (4-entry) MRU
cache of recently-used distance values, tracked independently inside
`MatchFieldCoder` itself (not the matcher's own repeat-offset list - this
one exists purely so the entropy coder can say "same as before" for free).
When a distance matches a cached entry, it costs one cheap, entropy-coded
symbol and *zero* extra bits, the same idea as LZMA's rep0-rep3 codes. When
it doesn't, encoding falls back to the original slot-plus-extra-bits scheme
unchanged. Match *lengths* are untouched - a length doesn't recur the way a
periodic structure's distance does, and MIN_MATCH-rebasing already gives the
single most common length the cheapest code.

Files touched:
- `entropy/MatchFieldCoder.kt` - the actual change (MRU cache, alphabet
  size now depends on `repSlots`, `pack`/`unpack` updated to match).
- `NovaSegmentCodec.kt` - one line, opting the *distance* `FieldWriter` into
  the new cache (`repSlots = MatchFieldCoder.DIST_REPEAT_SLOTS`); the length
  `FieldWriter` is constructed the same way as before (`repSlots` defaults
  to 0), and `decode()` needed no changes at all, since `unpack()`'s new
  `distRepSlots` parameter defaults to `DIST_REPEAT_SLOTS` - the value
  `encode()` always uses for the real distance writer.
- `MatchFieldCoderTest.kt` - added coverage for the new cache (round-trip
  correctness with a mix of hot/fresh distances, fewer unique values than
  cache slots, empty/single-value edges, and a size assertion that a
  constantly-recurring distance collapses to well under half its baseline
  size). Every pre-existing test in this file still constructs
  `FieldWriter()` with no arguments and therefore still exercises the exact
  original code path (`repSlots` defaults to 0) - none of them needed to
  change to keep passing.

One bug caught during verification, worth recording: an early version of
`unpack()` hardcoded `DIST_REPEAT_SLOTS` for the distance alphabet instead
of taking it as a parameter. That's harmless for the real `NovaSegmentCodec`
call site (which always uses `DIST_REPEAT_SLOTS` on the encode side too,
same as a fixed `minMatch` never being ambiguous there), but it would have
silently corrupted every pre-existing `MatchFieldCoderTest` case, since
those all encode distances with the *default* `repSlots = 0` and would
then have been decoded assuming `repSlots = 4` - an alphabet-size mismatch
that desyncs the range decoder into producing wrong values rather than
throwing. Caught by running the equivalent scenario through the Python
harness (reproduced in an isolated case: encoding `[5, 100, 7, 4, 4, 4]`
with `repSlots=0` and decoding with `repSlots=4` returns
`[0, 2, 0, 0, 0, 44]`) before this ever reached the Kotlin side. Fixed by
making `distRepSlots` an explicit `unpack()` parameter (defaulting to
`DIST_REPEAT_SLOTS`, so the real call site still needs no change) instead
of an assumed constant, and re-verified every test scenario, old and new,
against the harness afterward.

The rest of the pipeline - `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `Segmenter`, `RegionClassifier`, the container format -
is untouched.

## Results

Six built-in sample datasets, before vs. after, measured on the verified
Python port (byte-identical algorithm to the Kotlin change described
above), with every case round-trip-verified lossless:

| dataset    |    original | before (baseline) | after (this change) | ratio before | ratio after | size change |
|------------|------------:|-------------------:|----------------------:|--------------:|-------------:|------------:|
| text       |     262,144 |              39,728 |                 39,726 |         6.60x |        6.60x |      -0.01% |
| json       |     262,144 |              30,938 |                 30,703 |         8.47x |        8.54x |      -0.76% |
| **table**  | **262,144** |          **39,478** |             **19,267** |     **6.64x** |   **13.61x** |  **-51.20%**|
| image      |     196,608 |              48,167 |                 48,166 |         4.08x |        4.08x |      -0.00% |
| executable |     262,144 |              87,573 |                 87,463 |         2.99x |        3.00x |      -0.13% |
| random     |     262,144 |             267,323 |                267,323 |         0.98x |        0.98x |       0.00% |
| **total**  | 1,507,328   |             513,207 |                492,648 |         2.94x |        3.06x |      -4.01% |

(`random` isn't handled by the pipeline this change touches in the real
app - the segmenter routes incompressible input to STORE before it ever
reaches the matcher/entropy stage - so its baseline ratio here is slightly
below the app's real ~1.00x; that's a limitation of the Python harness, not
this change, and doesn't affect any of the numbers above it.)

The fixed-stride tabular case - exactly the kind of periodic/structured
binary data this fix targets - more than doubles its compression ratio
(6.64x -> 13.61x), moving it from clearly behind Deflate/Bzip2/Zstd
(per the pasted device benchmark: 7.77x/8.01x/22.08x) to solidly ahead of
Deflate and Bzip2 and within reach of LZMA2's 14.07x. JSON and
executable-like data get smaller, consistent (~0.1-0.8%) gains from the
same mechanism, matching the fact that they had *some* repeated-distance
structure but less than the tabular case's constant stride. Text, image,
and random data are unchanged to within rounding, as expected: text's match
distances are driven by scattered word positions with little offset reuse,
image data barely uses the matcher at all (0.1% match share - the predictor
already does the work there), and random data has no matches to encode.

No dataset regressed. Net effect across the full six-dataset suite: **-4.0%
total compressed size** (2.94x -> 3.06x aggregate ratio), driven almost
entirely by the one dataset the root-cause analysis predicted it should
help.

## Verdict

Kept. Improves one dataset dramatically, several others modestly, regresses
none, stays losslessly round-trip-verified throughout (including the new
Kotlin unit tests, checked against the same logic in the Python harness
since no Kotlin compiler was available to run them directly here), and the
change is contained to the entropy-coding of match distances specifically -
no changes to the matcher's search strategy, the predictor, the dictionary,
segmentation, or the container format.

## Suggested next subsystem

With the distance side-channel's dominant cost fixed, the *length* side of
`MatchFieldCoder` is the next largest remaining component on these same
datasets (2,971-7,477 bytes of length-slot entropy plus 4,684-6,008 bytes
of raw length extra-bits per dataset, from the same breakdown above) and
would likely benefit from a similar treatment - lengths cluster around a
small set of common values on structured data too, just not via a literal
repeat-offset mechanism the way distances do. After that, `text.txt` is the
dataset with the least headroom found in this pass (+0.01%) despite still
trailing Bzip2 by nearly 2x (6.60x vs 11.86x); its side-channel is 93.7% of
its output with very little of it concentrated in repeated distances, which
points more at the **matcher**'s parsing strategy (greedy + 1-step lazy
matching vs. LZMA-style optimal parsing, which would choose shorter/more
numerous matches when that leads to cheaper-to-encode distances) than at
anything in the entropy coder.
