package com.novacompress.bench.novacompress.matcher

sealed class Token {
    data class Literal(val byte: Byte) : Token()
    data class Match(val distance: Int, val length: Int) : Token()
}
