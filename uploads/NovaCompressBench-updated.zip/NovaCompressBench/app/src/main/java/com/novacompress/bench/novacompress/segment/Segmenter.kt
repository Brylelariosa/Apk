package com.novacompress.bench.novacompress.segment

import com.novacompress.bench.novacompress.analyzer.Region
import com.novacompress.bench.novacompress.analyzer.RegionKind

enum class SegmentStrategy { STORE, NOVA }

data class Segment(
    val offset: Int,
    val length: Int,
    val strategy: SegmentStrategy,
    val dominantKind: RegionKind,
    val avgEntropy: Double,
)

/**
 * Stage 2 ("Adaptive Segmentation" in the spec): merges the analyzer's
 * fixed-size classified windows into variable-length segments, each
 * assigned a strategy.
 *
 * Only two strategies exist: STORE for regions the analyzer flagged as
 * already-high-entropy (already compressed or encrypted - matching and
 * entropy coding both fail to help there, and the round-trip tests confirm
 * NovaCompress mildly *expands* pure-random input, so storing verbatim is
 * strictly better) and NOVA for everything else. This is a deliberately
 * small strategy set rather than one strategy per [RegionKind]; the kind
 * and entropy are still recorded per segment for Research Mode reporting
 * and to inform future, more granular strategies.
 */
object Segmenter {
    fun segment(regions: List<Region>): List<Segment> {
        if (regions.isEmpty()) return emptyList()

        val segments = ArrayList<Segment>()
        var runStart = regions[0].offset
        var runLength = regions[0].length
        var runStrategy = strategyFor(regions[0].kind)
        var runDominantKind = regions[0].kind
        var entropySum = regions[0].stats.entropy
        var windowCount = 1

        for (i in 1 until regions.size) {
            val r = regions[i]
            val s = strategyFor(r.kind)
            if (s == runStrategy) {
                runLength += r.length
                entropySum += r.stats.entropy
                windowCount++
                // dominant kind stays as the first window's kind in the run;
                // good enough for reporting purposes without extra bookkeeping.
            } else {
                segments.add(Segment(runStart, runLength, runStrategy, runDominantKind, entropySum / windowCount))
                runStart = r.offset
                runLength = r.length
                runStrategy = s
                runDominantKind = r.kind
                entropySum = r.stats.entropy
                windowCount = 1
            }
        }
        segments.add(Segment(runStart, runLength, runStrategy, runDominantKind, entropySum / windowCount))
        return segments
    }

    private fun strategyFor(kind: RegionKind): SegmentStrategy = when (kind) {
        RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED -> SegmentStrategy.STORE
        else -> SegmentStrategy.NOVA
    }
}
