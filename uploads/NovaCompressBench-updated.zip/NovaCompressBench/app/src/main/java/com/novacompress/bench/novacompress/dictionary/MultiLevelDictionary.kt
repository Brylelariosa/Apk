package com.novacompress.bench.novacompress.dictionary

/**
 * Backing state for [com.novacompress.bench.novacompress.matcher.LongRangeMatcher].
 * One instance is created per [com.novacompress.bench.novacompress.matcher.LongRangeMatcher.tokenize]
 * call.
 *
 * The spec asks for four cooperating dictionary levels (global / block /
 * local / micro). Rather than four separate maps, this is one hash table
 * whose effective *scope* is controlled by how much data the caller passes
 * into a single [tokenize] call, plus a small repeat-offset list:
 *
 *  - **Micro**: [repDistances], a 4-entry MRU list of recently used match
 *    distances ("repeat offsets" - a technique borrowed from LZMA/Zstd).
 *    Checked first because repeats are cheaper to encode.
 *  - **Local**: the default - tokenizing one segment's bytes gives a
 *    dictionary scoped to that segment.
 *  - **Block / Global**: tokenizing several segments' bytes concatenated
 *    together (what NovaCompressAlgorithm does for files small enough to
 *    stay in one "block") gives the *same* mechanism whole-file reach, with
 *    no separate seeding step required.
 *
 * [head] alone only remembers the single most-recent position per hash
 * bucket. [prev] turns that into a bounded hash *chain*: `prev[i]` is
 * whatever `head[hash(i)]` held right before position `i` overwrote it, so
 * walking `prev` from `head[h]` backward visits successively older
 * occurrences of the same 4-byte prefix, letting [LongRangeMatcher] check
 * more than just the newest one.
 *
 * One real constraint drove this design: segments compressed in *parallel*
 * (Stage 8) can't share a dictionary that's built sequentially as you go -
 * that's a fundamental tension between "global dictionary" and "use all
 * CPU cores" also present in production parallel compressors (pigz, zstd's
 * multithreaded mode), which make the same trade. NovaCompressAlgorithm
 * resolves it by tokenizing whole-file-at-once below a size threshold
 * (genuine global reach, single-threaded) and per-chunk above it (bounded
 * local reach per chunk, but parallel across cores) - see its KDoc.
 */
class MultiLevelDictionary(hashBits: Int = 17, dataSize: Int) {
    val hashSize = 1 shl hashBits
    val hashMask = hashSize - 1
    val head = IntArray(hashSize) { -1 }
    val prev = IntArray(dataSize)
    val repDistances = intArrayOf(1, 2, 3, 4)
}
