package com.novacompress.bench.novacompress.matcher

import com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary

/**
 * Finds repeated byte sequences across the whole buffer passed to
 * [tokenize] - not a small fixed sliding window like Deflate's 32KB, hence
 * "long-range". Matches are tried against the repeat-offset list first
 * (cheap to encode), then a whole-buffer hash table.
 *
 * Originally ported unchanged in structure from a Java prototype verified
 * via 29 round-trip tests (edge cases, random data, repeated/text/JSON-like
 * structures, self-overlapping runs, fuzzed mixes) plus a 4MB correctness +
 * throughput check - see README "Verification". That version's dictionary
 * only ever remembered the single most-recent position per hash, and every
 * match was taken the moment it hit [MIN_MATCH] - both leave ratio on the
 * table against multi-candidate, lazy matchers like LZMA/Zstd. This version
 * walks a bounded hash *chain* ([MultiLevelDictionary.prev], up to
 * [MAX_CHAIN] candidates) instead of trusting only the newest occurrence,
 * and does one step of lazy-match lookahead (would starting one byte later
 * find something longer?) before committing - both changes contained to
 * this file and [MultiLevelDictionary]. Token semantics are unchanged: a
 * [Token.Match] still just says "copy this many bytes from this distance
 * back," so [MatchFieldCoder] and everything downstream needs no changes.
 */
object LongRangeMatcher {
    const val MIN_MATCH = 4
    private const val HASH_BITS = 17
    private const val HASH_SIZE = 1 shl HASH_BITS
    private const val MAX_MATCH = 1 shl 18
    private const val MAX_CHAIN = 64 // candidates walked per hash bucket; higher = better ratio, slower
    private const val MIX_CONST = -1640531535 // 0x9E3779B1 as signed Int

    private fun hash4(d: ByteArray, i: Int): Int {
        var h = ((d[i].toInt() and 0xFF) shl 24) or
            ((d[i + 1].toInt() and 0xFF) shl 16) or
            ((d[i + 2].toInt() and 0xFF) shl 8) or
            (d[i + 3].toInt() and 0xFF)
        h *= MIX_CONST
        return (h ushr (32 - HASH_BITS)) and (HASH_SIZE - 1)
    }

    private fun matchLen(d: ByteArray, p: Int, i: Int, n: Int): Int {
        var len = 0
        val max = minOf(MAX_MATCH, n - i)
        while (len < max && d[p + len] == d[i + len]) len++
        return len
    }

    /**
     * Best match at [i] against the repeat-offset list and the hash chain
     * for [i]'s 4-byte prefix, walking up to [MAX_CHAIN] prior positions -
     * not just the single most recent one - so a closer-but-shorter repeat
     * can't hide a longer one further back. Always inserts [i] into the
     * chain as a side effect whenever there's room for a 4-byte key, same
     * as the original single-candidate version did.
     */
    private fun bestMatchAt(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Token.Match? {
        if (i + MIN_MATCH > n) return null
        var bestLen = 0
        var bestDist = 0

        for (rd in rep) {
            if (rd <= i) {
                val len = matchLen(data, i - rd, i, n)
                if (len >= MIN_MATCH && len > bestLen) {
                    bestLen = len; bestDist = rd
                }
            }
        }

        val h = hash4(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < MAX_CHAIN) {
            val len = matchLen(data, cand, i, n)
            if (len > bestLen) {
                bestLen = len; bestDist = i - cand
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i

        return if (bestLen >= MIN_MATCH) Token.Match(bestDist, bestLen) else null
    }

    fun tokenize(data: ByteArray): List<Token> {
        val tokens = ArrayList<Token>()
        val n = data.size
        val dict = MultiLevelDictionary(HASH_BITS, n)
        val head = dict.head
        val prev = dict.prev
        val rep = dict.repDistances

        var i = 0
        var pending: Token.Match? = null
        while (i < n) {
            val found = pending ?: bestMatchAt(data, i, n, head, prev, rep)
            pending = null

            if (found != null) {
                // Lazy matching: a longer match starting one byte later is
                // usually worth more than the literal byte it costs to get
                // there, so peek ahead before committing (classic zlib-style
                // lookahead). This call also inserts i+1 into the chain, so
                // the "remaining positions" loop below starts at i+2 to
                // avoid indexing it a second time.
                val next = bestMatchAt(data, i + 1, n, head, prev, rep)
                if (next != null && next.length > found.length) {
                    tokens.add(Token.Literal(data[i]))
                    i++
                    pending = next
                    continue
                }

                tokens.add(found)
                if (found.distance != rep[0]) {
                    val idx = rep.indexOf(found.distance).let { if (it < 0) rep.size - 1 else it }
                    for (m in idx downTo 1) rep[m] = rep[m - 1]
                    rep[0] = found.distance
                }

                var p = i + 2
                while (p < i + found.length && p + MIN_MATCH <= n) {
                    val ph = hash4(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += found.length
            } else {
                tokens.add(Token.Literal(data[i]))
                i++
            }
        }
        return tokens
    }
}
