package com.novacompress.bench.novacompress.format

import com.novacompress.bench.novacompress.NovaEncodedBlock
import com.novacompress.bench.novacompress.NovaSegmentCodec
import com.novacompress.bench.novacompress.analyzer.FileAnalyzer
import com.novacompress.bench.novacompress.segment.Segment
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.novacompress.segment.Segmenter
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.OutputStream

data class ChunkResearchStats(
    val segments: List<Segment>,
    val symbolCount: Int,
    val tokenCount: Int,
    val matchTokenCount: Int,
    val predictHitCount: Int,
    val novaInputBytes: Int,
    val storeInputBytes: Int,
)

data class EncodedChunk(val bytes: ByteArray, val stats: ChunkResearchStats)

/**
 * On-disk format for a NovaCompress stream: a header, then a sequence of
 * length-framed chunks, then an end marker. Chunks are processed
 * independently (see [NovaCompressAlgorithm] for why), so [encodeChunk] is
 * a pure function - no stream state - safe to call concurrently from
 * multiple coroutines, with the caller responsible for writing results to
 * the output stream in order afterward.
 *
 * Within a chunk: all NOVA-strategy segments' bytes are concatenated and
 * run through [NovaSegmentCodec] as a *single* block (one dictionary, one
 * entropy-coded stream for the whole chunk). STORE-strategy segments are
 * verified rather than trusted outright - [encodeChunk] trial-compresses
 * them and only keeps them as raw inline bytes if that's genuinely smaller,
 * promoting them into the shared block otherwise (see [encodeChunk] for
 * why the classifier can be wrong here). A segment's metadata (classifier
 * strategy, length, dominant kind, average entropy) is always recorded for
 * Research Mode reporting, even when its bytes end up living in the shared
 * block instead of inline.
 */
object NovaContainerFormat {
    const val MAGIC = 0x4E564331 // ASCII "NVC1"
    const val VERSION = 1
    const val MARKER_MORE = 0xC1
    const val MARKER_END = 0xFF

    fun writeHeader(out: DataOutputStream) {
        out.writeInt(MAGIC)
        out.writeByte(VERSION)
    }

    fun readAndVerifyHeader(din: DataInputStream) {
        val magic = din.readInt()
        require(magic == MAGIC) { "Not a NovaCompress stream (bad magic number)" }
        val version = din.readUnsignedByte()
        require(version == VERSION) { "Unsupported NovaCompress stream version: $version" }
    }

    fun writeEndMarker(out: DataOutputStream) {
        out.writeByte(MARKER_END)
    }

    /** Analyzes, segments, and compresses one chunk's raw bytes. Pure
     *  function - safe to run on any dispatcher/thread. */
    fun encodeChunk(chunkData: ByteArray): EncodedChunk {
        val regions = FileAnalyzer.analyze(chunkData)
        val segments = Segmenter.segment(regions)

        val novaBuffer = ByteArrayOutputStream()
        val storeBuffer = ByteArrayOutputStream()
        for (seg in segments) {
            if (seg.strategy == SegmentStrategy.NOVA) {
                novaBuffer.write(chunkData, seg.offset, seg.length)
            } else {
                storeBuffer.write(chunkData, seg.offset, seg.length)
            }
        }

        // The classifier's repetitionRatio proxy only samples within one
        // FileAnalyzer window, so it can miss redundancy whose period is
        // longer than that window and misroute genuinely compressible data
        // to STORE (e.g. fixed-stride records whose repeating fields recur
        // every few window-lengths). Rather than widen the window or tune
        // the heuristic further - which only relocates the same blind spot
        // to a different period length - verify its STORE calls directly:
        // try compressing what it flagged, and only keep it as STORE if
        // that's actually smaller. Segments the classifier already got
        // right (text, JSON, genuinely-random data) pay one extra encode
        // call here for nothing; segments it got wrong get compressed
        // instead of stored verbatim.
        val storeBytes = storeBuffer.toByteArray()
        var promoteStore = false
        if (storeBytes.isNotEmpty()) {
            val trial = NovaSegmentCodec.encode(storeBytes)
            if (trial.entropyBytes.size + trial.sideChannelBytes.size < storeBytes.size) {
                promoteStore = true
                novaBuffer.write(storeBytes)
            }
        }

        val novaBytes = novaBuffer.toByteArray()
        val novaBlock: NovaEncodedBlock? = if (novaBytes.isNotEmpty()) NovaSegmentCodec.encode(novaBytes) else null

        val out = ByteArrayOutputStream()
        val d = DataOutputStream(out)
        d.writeByte(MARKER_MORE)
        d.writeInt(chunkData.size)
        d.writeInt(segments.size)
        d.writeByte(if (novaBlock != null) 1 else 0)
        if (novaBlock != null) {
            d.writeInt(novaBytes.size)
            d.writeInt(novaBlock.symbolCount)
            d.writeInt(novaBlock.tokenCount)
            d.writeInt(novaBlock.matchTokenCount)
            d.writeInt(novaBlock.predictHitCount)
            d.writeInt(novaBlock.entropyBytes.size)
            d.write(novaBlock.entropyBytes)
            d.writeInt(novaBlock.sideChannelBytes.size)
            d.write(novaBlock.sideChannelBytes)
        }
        for (seg in segments) {
            val effectiveNova = seg.strategy == SegmentStrategy.NOVA || promoteStore
            d.writeByte(if (effectiveNova) 1 else 0)
            d.writeInt(seg.length)
            d.writeByte(seg.dominantKind.ordinal)
            d.writeDouble(seg.avgEntropy)
            if (!effectiveNova) {
                d.write(chunkData, seg.offset, seg.length)
            }
        }

        val stats = ChunkResearchStats(
            segments = segments,
            symbolCount = novaBlock?.symbolCount ?: 0,
            tokenCount = novaBlock?.tokenCount ?: 0,
            matchTokenCount = novaBlock?.matchTokenCount ?: 0,
            predictHitCount = novaBlock?.predictHitCount ?: 0,
            novaInputBytes = novaBytes.size,
            storeInputBytes = chunkData.size - novaBytes.size,
        )
        return EncodedChunk(out.toByteArray(), stats)
    }

    /**
     * Reads and reconstructs ONE chunk from [din], writing its original
     * bytes to [output]. [din] must be positioned immediately after a
     * marker byte the caller already confirmed equals [MARKER_MORE].
     */
    fun decodeChunk(din: DataInputStream, output: OutputStream) {
        din.readInt() // originalChunkLength - informational only, reconstruction is driven by per-segment lengths below
        val segmentCount = din.readInt()
        val hasNova = din.readUnsignedByte() == 1

        var novaBuffer: ByteArray? = null
        if (hasNova) {
            val novaOriginalLength = din.readInt()
            val symbolCount = din.readInt()
            din.readInt() // tokenCount - reporting only, already folded into the encoder's output sizes
            val matchTokenCount = din.readInt()
            din.readInt() // predictHitCount - reporting only, already folded into the encoder's output sizes
            val entropyLen = din.readInt()
            val entropyBytes = ByteArray(entropyLen)
            din.readFully(entropyBytes)
            val sideLen = din.readInt()
            val sideBytes = ByteArray(sideLen)
            din.readFully(sideBytes)
            val block = NovaEncodedBlock(symbolCount, entropyBytes, sideBytes, 0, matchTokenCount, 0)
            novaBuffer = NovaSegmentCodec.decode(block, novaOriginalLength)
        }

        var novaPos = 0
        repeat(segmentCount) {
            val strategy = din.readUnsignedByte()
            val length = din.readInt()
            din.readUnsignedByte() // dominantKind - reporting only
            din.readDouble() // avgEntropy - reporting only
            if (strategy == 0) {
                val raw = ByteArray(length)
                din.readFully(raw)
                output.write(raw)
            } else {
                output.write(novaBuffer!!, novaPos, length)
                novaPos += length
            }
        }
    }
}
