package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.format.NovaContainerFormat
import org.junit.Assert.assertArrayEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import kotlin.random.Random

class NovaContainerFormatTest {
    private fun roundTripChunk(chunkData: ByteArray): ByteArray {
        val encoded = NovaContainerFormat.encodeChunk(chunkData)
        val din = DataInputStream(ByteArrayInputStream(encoded.bytes))
        val marker = din.readUnsignedByte()
        check(marker == NovaContainerFormat.MARKER_MORE)
        val out = ByteArrayOutputStream()
        NovaContainerFormat.decodeChunk(din, out)
        return out.toByteArray()
    }

    @Test fun mixedRealisticChunk() {
        val r = Random(2024)
        val out = ByteArrayOutputStream()
        while (out.size() < 50000) {
            if (r.nextBoolean()) {
                val words = listOf("alpha", "beta", "gamma", "research")
                repeat(1 + r.nextInt(30)) { out.write((words[r.nextInt(words.size)] + " ").toByteArray()) }
            } else {
                val b = ByteArray(200 + r.nextInt(1000))
                r.nextBytes(b)
                out.write(b)
            }
        }
        val data = out.toByteArray().copyOf(50000)
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun allHighEntropyChunk() {
        val data = ByteArray(20000)
        Random(1).nextBytes(data)
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun allTextChunk() {
        val data = "the quick brown fox ".repeat(2000).toByteArray()
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun tinyChunk() = assertArrayEquals(byteArrayOf(1, 2, 3), roundTripChunk(byteArrayOf(1, 2, 3)))
}

class NovaCompressAlgorithmTest {
    private fun roundTrip(data: ByteArray): ByteArray {
        val algo = NovaCompressAlgorithm()
        val compressed = ByteArrayOutputStream()
        algo.compress(ByteArrayInputStream(data), compressed)
        val decompressed = ByteArrayOutputStream()
        algo.decompress(ByteArrayInputStream(compressed.toByteArray()), decompressed)
        return decompressed.toByteArray()
    }

    @Test fun emptyFile() = assertArrayEquals(ByteArray(0), roundTrip(ByteArray(0)))

    @Test fun smallFileOneChunk() {
        val data = "hello NovaCompress ".repeat(500).toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun multiChunkFile() {
        // Larger than NovaCompressAlgorithm.CHUNK_SIZE forces multiple chunks
        // and exercises the parallel-batch compression path.
        val r = Random(7)
        val out = ByteArrayOutputStream()
        val chunkTarget = NovaCompressAlgorithm.CHUNK_SIZE * 3 + 12345
        while (out.size() < chunkTarget) {
            if (r.nextInt(5) == 0) {
                val b = ByteArray(50000)
                r.nextBytes(b)
                out.write(b)
            } else {
                out.write("repeated structured record field value ".repeat(50).toByteArray())
            }
        }
        val data = out.toByteArray().copyOf(chunkTarget)
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun researchReportIsConsistentWithOutput() {
        val data = "{\"a\":1,\"b\":2}\n".repeat(3000).toByteArray()
        val algo = NovaCompressAlgorithm()
        val compressed = ByteArrayOutputStream()
        val report = algo.compressWithReport(ByteArrayInputStream(data), compressed)

        val decompressed = ByteArrayOutputStream()
        algo.decompress(ByteArrayInputStream(compressed.toByteArray()), decompressed)

        assertArrayEquals(data, decompressed.toByteArray())
        org.junit.Assert.assertEquals(data.size.toLong(), report.originalSize)
        org.junit.Assert.assertEquals(compressed.toByteArray().size.toLong(), report.compressedSize)
        org.junit.Assert.assertTrue("Highly repetitive JSON should find match tokens", report.totalMatchTokens > 0)
    }
}
