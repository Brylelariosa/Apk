# CHANGELOG — Fifteenth pass

Scope note: `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`. Prompted
by a retest reporting all three still-open symptoms at once: ROM detection
still failing on both transports, Wi-Fi disconnect not reaching the other
phone, and lag on Bluetooth. Two logcat dumps (one per transport) were
attached as evidence for the ROM-detection question specifically.

Reading those two dumps first, before touching any source, is what this
pass actually turned on: neither contained a single line from anywhere near
an actual link attempt — both covered barely 200ms of real time, entirely
boot-time noise. That's items 1-2 below. Item 3 is a design gap every prior
FIX 9-12 comment already described the intent for but never actually
enforced, found by re-reading `mgba_jni.c` end to end rather than from the
logs (which had no signal to read). Item 4 is the clipboard tool itself,
updated to match.

**None of this is confirmed to fix the reported symptoms** — see
KNOWN_LIMITATIONS.md's Fifteenth-pass entry for exactly what would. Items
1-2 are a confirmed, demonstrated bug (the evidence is the two attached
files) whose fix is straightforward; item 3 is a hardening whose actual
impact is unknown. What every item together should reliably produce,
even if the underlying multiplayer bug turns out to be something else
entirely, is a next debug-log capture that finally contains something to
read.

---

## 1. Filtered mGBA's own core logging out of `jni_log()`

**Category:** Bug fix (diagnostic capture) / possible general performance
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `jni_log()` — the callback that forwards mGBA's internal
logger to Android's logcat — forwarded every core log line, at every
level, to `LOGI` under the `mGBA-JNI` tag, with `(void)level` explicitly
discarding the one piece of information that would have let it filter
anything. Confirmed directly from both logcat files attached this pass:
every line in both was genuinely `mGBA-JNI` (the tag filter was never the
issue), but both covered barely 166-241ms of real time — pure boot-time
`"Starting DMA ..."` / `"Read from write-only I/O register: ..."` spam,
nothing from anywhere near an actual multiplayer attempt. Confirmed
against mgba-emu/mgba's real source this pass (not inferred): the latter
message is logged at `mLOG_STUB`, the same level FIX 12 already
identified for the (now-removed) `rawWrite16` no-op warnings. This chatter
is completely unrelated to link/multiplayer — any DMA-heavy ROM produces
dozens of these lines every single frame — so it was never specific to
this investigation, it just happened to be what finally made the capture
tool's output visibly useless enough to trace.
**Solution:** `jni_log()` now drops `mLOG_DEBUG`/`mLOG_STUB`/
`mLOG_GAME_ERROR` before they reach `LOGI`, matching mGBA's own
`src/platform/libretro/libretro.c` under `NDEBUG` (this project's own
`CMakeLists.txt` also builds with `NDEBUG`). `FATAL`/`ERROR`/`WARN`/`INFO`
are unaffected. Belt-and-suspenders on top of the level check: also drops
the two specific message prefixes actually observed flooding both attached
logs, regardless of level, in case either isn't DEBUG/STUB after all.
**Reason:** Directly demonstrated by the two files W attached — see
mgba_jni.c's own FIX 13 comment for the full trail.
**Expected improvement:** The next `Copy link log` capture should cover
much more real time and actually contain FIX 11's SIO trace lines and
LinkMultiplayer.kt's own connection-lifecycle logging, instead of nothing.
Secondary, unconfirmed: `__android_log_print` is a real syscall: cutting
dozens of avoidable calls per frame, on every ROM, may also just be a
general performance improvement — not only for the Bluetooth lag this pass
was asked about.
**Side effects:** None expected — pure log suppression, no behavior
change. If DEBUG/STUB-level core tracing is ever needed again for
unrelated debugging, this is the one place to temporarily loosen.
**Verification:** No compiler in this sandbox, as every pass. The two
attached logs are direct evidence the *problem* is real; the fix itself
(which specific mLogLevel constants exist, and that STUB is used for
exactly this "wrong-direction register access" case) is checked against
mgba-emu/mgba's real source this pass, not assumed.

---

## 2. Bumped the debug-log capture window, updated its guidance

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** `copyLinkDebugLog()`'s `logcat -t 2000` limit, combined with
Item 1's since-fixed noise, meant the window covered a fraction of a
second in practice.
**Solution:** Bumped `2000` to `8000`. Purely a safety margin on top of
Item 1's real fix, not a substitute for it — the comment above the
function, and the empty-state dialog message, were both updated to say so
and to explicitly mention re-testing the disconnect scenario (tap
Disconnect, wait a few seconds, then read the log), since that's now also
something this capture is meant to help diagnose.
**Reason:** Cheap extra headroom now that each line is worth far more
signal than before.
**Expected improvement:** A long test session (multiple connect/play/
disconnect cycles) is less likely to scroll early evidence back out.
**Side effects:** Slightly larger clipboard payload and dialog text in the
worst case; a plain monospace `TextView` inside a `ScrollView` handles a
few thousand lines fine.
**Verification:** Not runnable here (no device). Read-through only.

---

## 3. Host-gated the native SIO exchange trigger

**Category:** Hardening (protocol correctness) — impact unconfirmed
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()`'s exchange branch fired on *any*
SIOCNT write with the Start bit set, regardless of which role's own ROM
made that write. FIX 9's original comment already claimed this branch
"correctly never fires" on a child device, on the theory that a child ROM
never performs that write (GBATEK: Start/Busy is read-only for slaves) —
but nothing in the code actually enforced that; it was resting entirely on
that assumption holding for both test ROMs.
**Solution:** Added `&& g_link_is_host` to the branch condition; simplified
the two `g_link_is_host ? … : …` blocks inside it that the guard now makes
unreachable in the child case. The FIX 11 diagnostic warning is now also
host-gated, deliberately not logging the (now-expected) child case at all,
to avoid reintroducing Item 1's problem if a ROM's child-role code hits
this on every poll iteration.
**Reason:** Re-reading `mgba_jni.c` end to end for anything FIX 9-12 might
have missed, since the attached logs had no signal to point at anything
more specific. If either test ROM's link code shares one code path between
parent/child roles (plausible — Nintendo's SDK is commonly used that way)
and doesn't itself distinguish, this would have let a child device trigger
a second, spurious exchange of its own alongside the correct
network-triggered one — sending an unsolicited packet the host's *next*
real exchange could then consume as that round's reply. Fits the reported
symptom set well: identical ROM-detection failure on both transports (this
file is shared, unlike the already-hardened transport-specific Kotlin) and
worse lag specifically on Bluetooth (`BT_XCHG_MS=50` vs `WIFI_XCHG_MS=30` —
a stolen reply costs more there). Also may bear on the Twelfth-pass
KNOWN_LIMITATIONS entry that flagged suspiciously rapid repeated exchanges
in an earlier capture, never followed up.
**Expected improvement:** Unconfirmed — see KNOWN_LIMITATIONS.md. Cheap and
safe either way: host behavior is completely unchanged, since `is_host` was
already true on every path that used to run.
**Side effects:** None expected for the host role. For the child role. only
removes a call this design was never supposed to make in the first place.
**Verification:** Not runnable here. Design-intent gap identified by
reading, not by a build or device test.

---

## 4. Added specific reason logging to every disconnect/peer-lost path

**Category:** Bug fix (diagnostic capture)
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `disconnect()`'s outgoing BYE send had a bare
`catch (_: Exception) {}` — completely silent whether it succeeded, was
skipped (null socket/peer), or threw. Separately, all 8 call sites of
`handlePeerLost()` logged one identical generic line regardless of which
of the 6 listener locations detected it or why (explicit BYE vs. the 8s
liveness timeout). A captured log couldn't have distinguished "peer's BYE
never arrived", "it arrived but something else consumed it first", and
"neither side has sent one yet, still waiting on the watchdog" — three
very different bugs that all look identical from the report "if I
disconnect, it doesn't disconnect on the other phone."
**Solution:** `disconnect()` now logs the BYE send's outcome specifically
(sent + destination, skipped + which of socket/peer was null, or the
exception). `handlePeerLost()` now takes a `reason: String`; every call
site names itself and, where relevant, the specific trigger (BYE received
vs. timeout duration).
**Reason:** Purely additive — no timing or protocol logic changed, only
what gets logged and how specifically.
**Expected improvement:** The next capture of a disconnect test should say
exactly which side sent a BYE, whether it was received, and if not,
whether the other side eventually gave up via the 8s watchdog instead —
enough to actually localize the reported bug instead of re-guessing at it.
**Side effects:** None expected. Slightly more log volume on disconnect
specifically (a handful of lines, not per-frame) — not a concern after
Item 1.
**Verification:** Not runnable here. Read-through only; every call site
cross-checked to confirm none were missed (`grep -n "handlePeerLost("`).

---

## Not changed this pass

- The actual WiFi disconnect-propagation bug, if it's not just Item 3
  above or a timing/testing artifact — nothing else found it by reading.
- The actual Bluetooth ROM-detection failure and lag, beyond Items 1 and 3
  above — same.
- `BT_XCHG_MS`/`WIFI_XCHG_MS` themselves — no evidence yet that the
  timeout values are wrong rather than the timeouts being hit at all.
- Everything else FIX 9-14 already covers.



Scope note: one-line fix, `MainActivity.kt` only, prompted by a real CI
build log the user attached (the Thirteenth pass's zip failed
`compileReleaseKotlin`).

---

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (compile error)
**Files modified:** `MainActivity.kt`
**Problem:** `showLinkDebugLogDialog(text: String)`'s parameter name
collided with `TextView`'s own `text` property. Inside `TextView(this)
.apply { text = shown }`, the bare `text` on the left of the assignment
resolved to the outer parameter (immutable) rather than the receiver's
property, so the compiler rejected it as reassigning a `val`. Everywhere
else in the file, the same kind of assignment goes through an explicit
variable (`row.text = ...`), which is never ambiguous — this was the one
bare/unqualified case, and it happened to collide.
**Solution:** Renamed the parameter to `logText`; the function body's one
reference to it (`text.ifBlank { ... }`) updated to match, `text = shown`
inside the `apply` block left as-is since it's now unambiguous.
**Reason:** Real `compileReleaseKotlin` failure from an actual CI run —
see the attached build log's `14_Build APK.txt`.
**Expected improvement:** Build succeeds.
**Side effects:** None — pure rename, no behavior change. The one caller
(`copyLinkDebugLog()`) passes its argument positionally, so it's
unaffected by the parameter's internal name.
**Verification:** No compiler available in this sandbox, as always — but
this fix is about as close to "verified" as this project gets without
one: the failure came from a real Gradle/Kotlin compiler run, the
collision was fully diagnosed against the exact reported line/column, and
grepping confirmed no other function in either of the last two passes'
additions has a parameter name that collides with a property name used
bare inside a nested `apply`/similar block.

---

# CHANGELOG — Thirteenth pass

Scope note: this pass covered `MainActivity.kt` only. Purely additive —
no existing save/load behavior changed, nothing multiplayer/link-related
touched.

---

## 1. Save-state thumbnails

**Category:** New feature
**Files modified:** `MainActivity.kt`
**Problem:** The save-state slot picker only ever showed a per-slot
timestamp (or "Empty") as plain text — no way to tell slots apart by what
was actually happening in the game at that point, and no way to see
what's currently in a slot before overwriting it.
**Solution:** `showSaveStateSlotDialog()` now uses a custom `ArrayAdapter`
(same general shape as `showGameMenu()`'s) whose row (`stateSlotRow()`)
pairs an `ImageView` thumbnail with the existing text label. The
thumbnail is captured by `captureStateThumbnail()` right after a
successful save, reusing `takeScreenshot()`'s exact `PixelCopy` technique
against the live `SurfaceView` rather than adding any new native/JNI
surface, and written as `<rom>.state<N>.png` next to the state file
itself (`stateThumbFile()`). `PixelCopy.request()`'s callback is turned
into a plain blocking call via a `CountDownLatch` so the whole capture
stays on the existing background save thread instead of splitting across
two async paths.
**Reason:** Directly requested.
**Expected improvement:** Slots are recognizable at a glance; overwriting
a slot is now an informed choice instead of a guess from a timestamp.
**Side effects:** One extra small PNG file per used slot
(`statesDir()/<rom>.state<N>.png`, ~a few KB at 200px wide). Picked up by
the existing `backupIfExists()` rolling-backup mechanism automatically
(called on the thumbnail path too, right alongside the state file).
**Verification:** No Android toolchain in this sandbox (unchanged
constraint). New block checked directly for brace/paren balance (26/26,
107/107); confirmed by grep that `showSaveStateSlotDialog()` has exactly
one other call site (`showSaveStateMenu()`, itself already-dead code per
the Tenth-pass notes below) and that both remain source-compatible with
the signature change.

---

# CHANGELOG — Twelfth pass

Scope note: this pass covered `MainActivity.kt` only — added
`copyLinkDebugLog()` and `showLinkDebugLogDialog()`, plus one new "Copy
link log" row in `showGameMenu()`. Nothing else was touched: not
`LinkMultiplayer.kt`, not `EmulatorEngine.kt`, not `mgba_jni.c`. **This
pass is a diagnostic tool, not a fix** — the "ROM never reacts to a
completed link" issue from the Sixth–Ninth passes is still open and still
reproduces exactly as before; see KNOWN_LIMITATIONS.md.

---

## 1. In-app link debug log capture

**Category:** New diagnostic feature
**Files modified:** `MainActivity.kt`
**Problem:** Every pass since the Sixth has agreed on what would actually
move the "ROM stuck on its own in-game link/multiplayer wait screen"
issue forward: real logcat from an attempt, filtered to `mGBA-JNI` (and
ideally `mGBA-Link`/`mGBA`), checked for whether any `SIO write addr=...`
line appears at all. No pass has had a way to actually get that output —
this sandbox has no Android device, and nothing in this project's history
implies an adb/PC workflow; development happens entirely from the phone
itself.
**Solution:** Added a "Copy link log" row to the quick game menu. It
shells out to the `logcat` binary already on-device (`logcat -d -t 2000
-v threadtime -s mGBA-JNI:* mGBA-Link:* mGBA:*`), which needs no root and
no `READ_LOGS` permission — that restriction only applies to reading
*other* processes' logs, never your own — copies the result to the
clipboard, and also shows it in a selectable on-screen dialog in case the
clipboard isn't available.
**Reason:** This is exactly the missing piece the Eighth pass identified
("What would actually move the remaining issue forward...") and the Ninth
re-confirmed without being able to act on.
**Expected improvement:** Lets a user reproduce the "please wait" symptom
on both phones and immediately pull the one piece of evidence that tells
the two live hypotheses apart — SIO writes never reaching the driver at
all, vs. reaching it but failing the exchange — without needing a
computer.
**Side effects:** None on emulation. If an OEM restricts logcat further
than stock Android, the dialog explains the `adb logcat` fallback instead
of failing silently.
**Verification:** Read only — no Android toolchain available in this
environment either (same constraint as every prior pass). The new block
was checked directly for brace/paren balance; `showGameMenu()`'s existing
`needsRom` indices were left untouched by placing the new row after Reset
and before Close, shifting only Close's index (9 → 10).

---

# CHANGELOG — Eleventh pass

Scope note: this pass covered `MainActivity.kt` only (2827 → 2847 lines) —
specifically `gameMenuRow()`, the row view backing the Tenth pass's
restyled quick game menu. Nothing else was touched: not
`buildSettingsMenu()`/`settingsRow()`, not `LinkMultiplayer.kt`, not
`EmulatorEngine.kt`, not `mgba_jni.c`.

---

## 1. Quick game menu — every row silently did nothing when tapped

**Category:** Bug fix — regression introduced by the Tenth pass
**Files modified:** `MainActivity.kt` (`gameMenuRow()`)
**Problem:** User report: tapping Settings, Link remote, Save, or Load in
the ⚙ quick game menu did nothing at all. Root cause: `gameMenuRow()` set
`isClickable = true; isFocusable = true` on the row view — copied from
`settingsRow()` (a plain `LinearLayout` child that needs those flags plus
its own `setOnClickListener` because it has no other click path) without
noticing this row is a different kind of view entirely: the convertView
inside `showGameMenu()`'s `ListView` (`AlertDialog.setAdapter`), whose
*only* click handling is that `ListView`'s own `OnItemClickListener` — the
`{ _, which -> ... }` lambda passed to `setAdapter()`. A clickable/
focusable row steals the touch before the `ListView` ever gets to fire
that listener. The ripple still played on every tap (the background is a
pressed-state drawable, and `ListView` forwards pressed state to whichever
child is under the touch regardless of its own clickable flag), which is
presumably why this read as working during the Tenth pass's own review —
it *looked* responsive even though nothing behind it ever fired.
**Solution:** Removed `isClickable = true; isFocusable = true` from
`gameMenuRow()`. Nothing else about the row, or about `showGameMenu()`
itself, changed.
**Reason:** Restores the same plain-list-item click behavior the old
`.setItems()` version (pre-Tenth-pass) had, which never hit this problem
because default system list rows aren't independently clickable either —
`ListView` alone handled both the visual feedback and the click dispatch.
**Expected improvement:** Every row in the quick game menu — Load, Save,
Fast forward, Cheats, Settings, Link remote, Link local, Screenshot,
Reset, Close — should respond to a tap again.
**Side effects:** None. The ripple/pressed-state visual is unchanged;
only the touch-swallowing flags were removed.

---

# CHANGELOG — Tenth pass

Scope note: this pass covered `MainActivity.kt` only (2644 → 2827 lines) —
specifically the quick game menu, Settings screen, and window/immersive
setup, prompted by a reference screenshot of My Boy's own pause menu.
`LinkMultiplayer.kt`, `EmulatorEngine.kt`, and `mgba_jni.c` were not
touched. Unlike the Fifth pass's note below, this one **is** a UI
restyle/reorganization by request — the quick game menu's visual style and
item list changed; Settings only lost two rows, nothing else about it
changed.

---

## 1. Quick game menu — restyled and expanded to match reference

**Category:** UI redesign
**Files modified:** `MainActivity.kt` (`showGameMenu()`, new `gameMenuRow()`)
**Problem:** The menu button opened a bare `.setItems()` AlertDialog —
default system list-row styling, and only 5 of the reference's 10 items.
**Solution:** Custom `ArrayAdapter` over plain-text rows (`gameMenuRow()`),
a pinned dark rounded-corner dialog background, and `Link remote` /
`Link local` / `Screenshot` / `Reset` / `Close` folded in alongside the
original five, matching the reference's full scrollable list.
**Reason:** Directly requested, reference screenshots attached.
**Expected improvement:** Visual match to the requested reference; five
more actions reachable in one tap instead of only through Settings.
**Side effects:** None functional — Settings' own `Link remote`/
`Link local` rows are unchanged and still work; these are just a second,
faster path to the same two dialogs.

## 2. Settings screen — removed Change ROM and Save States rows

**Category:** UI simplification
**Files modified:** `MainActivity.kt` (`buildSettingsMenu()`)
**Problem/Reason:** Directly requested. Both actions are now reachable
elsewhere — `changeRom()` via the initial "▶ Load ROM" button and the new
`Close` action; Save/Load via the quick game menu's own rows (which
already called `showSaveStateSlotDialog()` directly, not through this
screen).
**Solution:** Removed both `addView(settingsRow(...))` calls.
**Side effects:** `showSaveStateMenu()` (the removed row's old target) is
now unused — left in place rather than deleted.

## 3. Immersive mode — now re-applied on every focus regain

**Category:** Bug fix
**Files modified:** `MainActivity.kt` (new `onWindowFocusChanged()`)
**Problem:** `setImmersive()` ran once, at the end of `onCreate()`. Any
dialog taking focus away and back (which is constant in this app) silently
undid it, so the system bars crept back in.
**Solution:** `onWindowFocusChanged(hasFocus)` now calls `setImmersive()`
again whenever `hasFocus` becomes true.
**Expected improvement:** Immersive mode actually holds for the whole
session instead of only right after launch.
**Side effects:** None.

## 4. Camera-cutout area — no longer shows a black bar

**Category:** Bug fix
**Files modified:** `MainActivity.kt` (`onCreate()`)
**Problem:** `layoutInDisplayCutoutMode` was never set, so the default
mode letterboxed around the cutout — very visible on this landscape-locked
app, since the cutout (the phone's physical top edge, a "short" edge)
lands in the middle of the horizontal game view.
**Solution:** Set `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES` in
`onCreate()`, guarded to API 28+ (no-op below that, where this constant
doesn't exist).
**Expected improvement:** Game view extends under/past the cutout instead
of leaving a black gap there.
**Side effects:** None below API 28.

## 5. Screenshot, Reset, Close — new quick-menu actions

**Category:** New features
**Files modified:** `MainActivity.kt` (`takeScreenshot()`,
`saveScreenshotBitmap()`, `resetGame()`, `closeGame()`)
**Description:** See `FEATURES_ADDED.md`'s Tenth-pass entries for each.
**Reason:** Directly requested, to fill out the reference menu's
remaining three items.
**Side effects:** None on existing flows — `Reset` reuses
`nativeLoadROM()` rather than a new JNI export (see the code comment on
`resetGame()` for why), and `Close` reuses the existing idle-state UI
(`loadRomBtn`) rather than adding a new one.

---

# CHANGELOG — Fifth pass

Scope note: this pass reviewed `LinkMultiplayer.kt` (482 → 574 lines),
`MainActivity.kt` (2436 → 2549 lines), `EmulatorEngine.kt` (unchanged),
`mgba_jni.c` (unchanged, but read in full), `AndroidManifest.xml`,
`gradle.properties`, `app/build.gradle.kts`, `settings.gradle.kts`,
`gradle-wrapper.properties`, and `proguard-rules.pro` — the entire project.
Four previous passes (documented in `README_SETUP.md`) had already covered
audio, rendering, ROM-swap safety, permissions, and the control layout
editor in depth, so this pass concentrated on multiplayer/link internals,
which hadn't had a dedicated pass yet, plus a general pass over the rest
looking for anything the previous four missed. No UI was redesigned,
restyled, or reorganized — every change below is either backend-only or,
where it touches a screen, additive and off by default.

---

## 1. `LinkMultiplayer.kt` — cross-thread visibility on the connection state

**Category:** Bug fix — thread safety / race condition
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `dataSocket`, `peerAddr`, `peerDataPort`, `btSocket`, `btIn`,
`btOut` were plain `var` fields. They're written on a setup thread (the
host's discovery thread, or the client's connect thread) and read from
`jniExchangeData()` — called from native code on the game-loop thread,
which is frequently already running by the time a connection finishes
setting up. Without `@Volatile`, the JVM memory model does not guarantee
that thread ever observes the write.
**Solution:** Marked all six fields `@Volatile`.
**Reason:** `isConnected`/`mode` were already `@Volatile`; these were the
actual gap that made the "publish a connection" pattern incomplete.
**Expected improvement:** Removes a class of "multiplayer connects but
never actually exchanges data until you background/foreground the app"
failures that would otherwise depend on unrelated incidental memory
barriers to work at all.
**Side effects:** None — `@Volatile` only affects visibility/ordering, not
behavior.

## 2. `LinkMultiplayer.kt` — discovery socket wasn't actually tracked

**Category:** Bug fix — resource cleanup / disconnect handling
**Files modified:** `LinkMultiplayer.kt`
**Problem:** A `discSocket` field existed but nothing ever assigned the
live host-broadcast or client-scan socket to it, so `disconnect()`'s
`discSocket?.close()` call was a permanent no-op. A pending
`DatagramSocket.receive()` in either thread could then only ever unblock
via its own timeout (200 ms–4000 ms depending on which one), not
immediately on disconnect.
**Solution:** Both sockets are now assigned to `discSocket` when created
and cleared when their thread finishes; `disconnect()`'s existing
`discSocket?.close()` call now actually does something.
**Reason:** Matches the same "close the live socket to force an immediate
unblock" pattern already used correctly for `dataSocket`/`btServer`.
**Expected improvement:** Backing out of a host/join screen mid-search now
tears down its background thread immediately instead of after a multi
-second delay.
**Side effects:** None.

## 3. `LinkMultiplayer.kt` — Wi-Fi packet seq byte now actually checked

**Category:** Bug fix — packet ordering / synchronization
**Files modified:** `LinkMultiplayer.kt`
**Problem:** The packet-layout doc comment described the `seq` byte as
being "for out-of-order discard," and it was populated on send, but
nothing on the receive side ever validated it. A stale reply that arrived
late — after its own round had already timed out — could be silently
accepted by whichever `receive()` call next popped it off the socket
queue, corrupting SIO data without ever looking like a connection problem.
**Solution:** `wifiExchange()` now tracks the last accepted `seq`
(`lastRxSeq`) and discards an exact repeat.
**Reason:** Implements what the existing doc comment already claimed,
cheaply and with no risk of a false-positive drop.
**Expected improvement:** Removes one source of silent, hard-to-diagnose
multiplayer desync under Wi-Fi jitter.
**Side effects:** This is a partial mitigation, not full modular
sequence-ordering — see `KNOWN_LIMITATIONS.md`.

## 4. `LinkMultiplayer.kt` — stale/abandoned connection attempts

**Category:** Bug fix — race condition / reconnect / disconnect handling
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `showLinkDialog()` only blocks re-opening the connect flow
once `isConnected` is `true` — nothing stopped starting a second
connection attempt while a first was still mid-handshake (e.g. host, back
out, join — all within the 15 s handshake window). Whichever attempt
finished last would silently win, potentially clobbering the other's
sockets. Separately, `connectBluetooth()` only recorded its socket in a
class field *after* `sock.connect()` succeeded, so `disconnect()` had
nothing to close to cancel an attempt already in progress — a Bluetooth
`connect()` call can block for 10+ seconds on its own OS-level timeout.
**Solution:** Added a `connectGeneration` counter, bumped by every
`start*`/`connect*` call and by `disconnect()`; each background attempt
captures it and re-checks before mutating shared state or firing a
callback. Added `btPendingSocket`, published *before* the blocking
`connect()` call so `disconnect()` can close it to force an immediate
abort.
**Reason:** Makes "cancel and try something else" actually cancel, instead
of leaving a zombie attempt that can complete unpredictably later.
**Expected improvement:** More reliable behavior when a user backs out of
a connection attempt and immediately tries a different host/method.
**Side effects:** None — the guard is purely additive; the normal
single-attempt path behaves identically.

## 5. `MainActivity.kt` — ROM swap while linked left the UI/state inconsistent

**Category:** Bug fix — multiplayer / lifecycle consistency
**Files modified:** `MainActivity.kt`
**Problem:** `mgba_jni.c`'s ROM-swap path already protects itself from a
dangling pointer when a new ROM loads mid-link-session, by dropping the
native SIO driver registration — but it has no way to tell the Kotlin side
this happened. `changeRomBtn`/`loadRomBtn` never checked `link.isConnected`
before launching the ROM picker, so the Kotlin-side state and the "🔗 ✓"
button kept claiming "Connected" after a swap even though the link no
longer actually exchanged data.
**Solution:** The ROM-load background thread now calls `stopLink()` first
if `link.isConnected`.
**Reason:** Keeps native and Kotlin state in agreement instead of a silent,
user-visible inconsistency.
**Expected improvement:** No more "still says Connected but multiplayer
stopped working" after changing ROMs mid-session.
**Side effects:** Changing ROMs while linked now explicitly disconnects
instead of leaving a non-functional link silently in place — this is a
user-facing behavior change, but the link was already non-functional in
that state; this just makes the UI say so.

## 6. `MainActivity.kt` — ROM-load completion callback could run post-teardown

**Category:** Bug fix — lifecycle / resource leak
**Files modified:** `MainActivity.kt`
**Problem:** The ROM-load background thread posts its completion callback
to the main thread with no check that the Activity is still alive. If
`onDestroy()` already ran (e.g. the user backed out of the app during a
slow load — a large ROM, or a slow SAF/cloud-backed URI) by the time the
callback posts, it would re-initialize `AudioTrack` and start a brand-new
game thread + `Choreographer` registration *after* the native core was
already destroyed — resources with nothing left to ever clean them up.
**Solution:** Added an `isFinishing || isDestroyed` guard at the top of the
callback.
**Reason:** Standard defensive pattern for posted callbacks that can
outlive the component that scheduled them.
**Expected improvement:** Removes a narrow-window resource leak (orphaned
`AudioTrack` + thread + frame-callback registration).
**Side effects:** None.

## 7. `MainActivity.kt` — auto-backup before an overwrite

**Category:** Feature — data safety
**Files modified:** `MainActivity.kt`
**Problem:** The battery save file is re-opened read/write and mapped
fresh on every ROM load; a save-state slot is truncated the instant "Save
State" is tapped. Either one being interrupted mid-write (app killed,
storage full, a bad ROM writing where it shouldn't) had no recovery path.
**Solution:** Added `backupIfExists()` — copies the existing file to a
sibling `.bak` before it's touched. Best-effort and silent: a backup
failure is logged, never blocks the actual save.
**Reason:** Directly requested ("Auto save backups") and low-risk — purely
additive file management, no native or UI changes.
**Expected improvement:** One level of rollback if a session's save turns
out to be corrupt.
**Side effects:** Uses a small, bounded amount of extra storage (one extra
copy per save file/state slot). There is no in-app restore UI yet — see
`KNOWN_LIMITATIONS.md`.

## 8. `MainActivity.kt` — optional performance overlay

**Category:** Feature — diagnostics
**Files modified:** `MainActivity.kt`
**Problem:** No on-screen way to see whether the emulator is keeping up
(core FPS) or whether audio is underrunning, short of reading logcat.
**Solution:** Added a small corner text overlay showing core FPS (every
emulated GBA frame, including fast-forward sub-frames) and the existing
`AudioTrack.getUnderrunCount()` figure. Off by default; toggled from
⚙ Settings → Misc; included in "Reset settings to defaults".
**Reason:** Directly requested ("Performance monitor", "FPS counter") and
implementable with zero UI redesign — same visual pattern as the existing
link-status/fast-forward overlays, opt-in only.
**Expected improvement:** At-a-glance performance diagnosis without
attaching logcat.
**Side effects:** None when off (default) — the counting code doesn't run
at all unless the toggle is on, so there's no cost on the audio-pacing
thread in the default configuration.

## 9–10. `AndroidManifest.xml` — two unused permissions removed

**Category:** Security / Android best practices
**Files modified:** `AndroidManifest.xml`
**Problem:** `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN` were both
declared but never referenced or relied upon anywhere in the code (checked
by grepping the whole `kotlin/` tree for both). ROM loading is 100% SAF
(`OpenDocument`), which needs no storage permission; the app only calls
`getBondedDevices()` and RFCOMM connect/listen/accept, which need
`BLUETOOTH_CONNECT`, never `startDiscovery()`/BLE scanning, which is what
`BLUETOOTH_SCAN` actually gates.
**Solution:** Removed both declarations.
**Reason:** Unused dangerous-adjacent permissions increase the app's
attack surface/review footprint for no functional benefit.
**Expected improvement:** Smaller permission footprint; nothing to break,
since grep confirms zero usage of either.
**Side effects:** None.

## 11. `gradle.properties` — Jetifier disabled

**Category:** Build / technical debt
**Files modified:** `gradle.properties`
**Problem:** `android.enableJetifier=true` rewrites legacy
`android.support.*` bytecode to AndroidX at build time — but only
`androidx.core:core-ktx` and `androidx.appcompat:appcompat` remain as
dependencies (Material Components was already removed in an earlier pass),
both AndroidX-native since first publication. Jetifier was scanning every
dependency on every build for a rewrite it never had to make.
**Solution:** Set `android.enableJetifier=false`, with a comment
explaining the reasoning and when to re-enable it.
**Reason:** Verified via the dependency list in `app/build.gradle.kts` —
zero support-lib-namespaced dependencies remain.
**Expected improvement:** Slightly faster builds (one fewer full
dependency-scanning pass).
**Side effects:** None, provided no future dependency reintroduces the
legacy support-lib namespace (the comment left in place flags this).

---

## Not changed this pass

`EmulatorEngine.kt` and `mgba_jni.c` were both read in full and found to
already correctly implement what this pass would otherwise have flagged —
`g_core_mutex` already guards every native entry point, the ROM-swap path
already avoids the dangling-pointer risk it exists to avoid, and
`proguard-rules.pro` already protects `jniExchangeData` (the one method R8
could otherwise rename and silently break, since it's only ever resolved
reflectively from native code via `GetMethodID`). No changes were made to
any of these files.
