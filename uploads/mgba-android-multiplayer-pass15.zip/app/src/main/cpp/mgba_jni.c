/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fixes applied in this revision
 * ───────────────────────────────
 * FIX 1  pthread_mutex_t g_core_mutex protects g_core / g_fb.
 * FIX 2  core->loadConfig(core, &core->config) instead of mCoreLoadConfig.
 * FIX 3  nativeRunFrame pixel copy respects info.stride.
 * FIX 4  nativeReadAudioSamples — new function to drain mGBA blip buffers
 *         for Android AudioTrack. Uses blip_read_samples with stereo=1 to
 *         produce interleaved L/R PCM in one pass each channel.
 * FIX 5  nativeRunFrame(bitmap=NULL) skips the pixel-copy blit entirely.
 *         Used for fast-forward sub-frames that get overwritten before
 *         they're ever displayed — emulation and audio still run in full,
 *         only the wasted 240x160 copy is skipped.
 * FIX 6  Link SIO exchange now reads the outgoing byte from SIOMLT_SEND
 *         (0x400012A) instead of the receive-only SIOMULTI0 (0x4000120).
 *         Previously the link connected fine at the socket level but no
 *         real game data ever crossed it, since we were echoing back
 *         stale received bytes instead of what the ROM wrote to send.
 * FIX 7  SUPERSEDES FIX 6's approach. Polling SIOCNT after runFrame() and
 *         poking SIOMULTI0-3 with rawWrite16 never actually worked, because
 *         mGBA's own SIO controller (src/gba/sio.c) intercepts every SIOCNT
 *         write the instant the game makes it: if no GBASIODriver is
 *         registered for the active mode, it resolves the Start bit itself
 *         via a built-in "dummy driver" fallback, synchronously, before
 *         our post-runFrame check ever runs. So the raw pokes were mostly
 *         racing (and losing to) the core's own default behavior.
 *         The real fix is a proper GBASIODriver, registered with
 *         GBASIOSetDriver() in nativeLinkStart/Stop, whose writeRegister
 *         callback intercepts the Start-bit write synchronously and does
 *         the JNI exchange right there.
 *         See link_sio_write_register() near the bottom of this file.
 * FIX 8  Corrections after the first real CI build against the actual
 *         mGBA 0.10.3 headers (this project's pinned tag) turned up two
 *         places where mgba.io's current docs/master branch don't match
 *         0.10.3's actual API:
 *           - GBASIOSetDriver() takes 3 args here (sio, driver, mode), not
 *             2 — this build's compile error was "too few arguments to
 *             function call, expected 3, have 2".
 *           - struct GBASIODriver has no processEvents member on this
 *             revision — "no member named 'processEvents'".
 *         Also, GBASIOMultiplayerFinishTransfer() — the internal call the
 *         core's own drivers use to finish a transfer — triggered an
 *         implicit-declaration warning even with sio.h included, meaning
 *         it isn't exposed on this revision either; link_sio_write_register
 *         now writes SIOMULTI0-3 directly instead of risking an unresolved
 *         symbol at link time. Net effect: transfers complete correctly,
 *         but this build doesn't automatically raise the SIO IRQ the way
 *         hardware would — only relevant for a game that waits on that
 *         interrupt instead of polling SIOCNT's Start bit.
 *         Also fixed: struct LinkSIODriver / g_link_driver / g_link_gba were
 *         declared below nativeLoadROM and nativeRunFrame despite being used
 *         inside them — moved up next to the other link-cable globals.
 * FEATURE 9  Battery/cart save persistence + save states.
 *         nativeLoadROM now takes a second path and hands the core a real,
 *         app-managed VFile via core->loadSave() so SRAM/Flash/EEPROM
 *         writes survive app restarts (see the comment at that call site).
 *         nativeSaveState/nativeLoadState wrap mCoreSaveStateNamed()/
 *         mCoreLoadStateNamed() for full-snapshot save-state slots, keyed
 *         by whatever path the Kotlin layer passes in.
 * FIX 9  Root-caused why multiplayer still never got a ROM past its own
 *         "waiting for link" screen even once the two phones' network
 *         handshake succeeded. Two separate, GBATEK-confirmed bugs:
 *           (a) Nothing ever set SIOCNT's parent/child (bit 2) or
 *               all-ready (bit 3) status bits, both of which GBATEK
 *               documents games as checking *before* ever attempting a
 *               transfer — so a ROM that checks first could spin forever
 *               regardless of the network state. Fixed in
 *               link_sio_write_register() by reflecting both on every
 *               SIOCNT write, not just Start-bit ones.
 *           (b) GBATEK: the Start/Busy bit is "Read Only for Slaves" — a
 *               child unit never triggers its own transfer, only the
 *               parent does. Since the exchange branch below is keyed off
 *               *this device's own* Start-bit write, it correctly never
 *               fired on a child device — meaning a child's wifiExchange()/
 *               btExchange() (the only thing that ever answered the
 *               parent's request) was simply never called. The parent's
 *               every request timed out, deterministically, every time.
 *               Fixed with a new passive-responder entry point,
 *               nativeLinkChildExchange(), called from a background Kotlin
 *               thread the instant a request arrives over the network
 *               instead of waiting on a local SIOCNT write that was never
 *               coming. See its own comment below for the full picture,
 *               and LinkMultiplayer.kt for the Kotlin-side listener threads
 *               that call it.
 *         Also added: ID bits (4-5) and the Error bit (6) are now set
 *         correctly on the parent's side after each transfer (previously
 *         left at whatever the ROM had last written, which is undefined
 *         behavior per GBATEK for bit 4-5 before the first transfer).
 * FIX 10 Root-caused why SIOCNT/data-register correctness (FIX 9) still
 *         wasn't enough to get either test game (Yu-Gi-Oh! World
 *         Championship 2006, The Legend of Zelda: Four Swords) off their
 *         own link-wait screens: FIX 8 already flagged, but left
 *         unaddressed, that nothing here ever raises the SIO IRQ. Real GBA
 *         multiplayer code overwhelmingly uses the BIOS IntrWait/
 *         VBlankIntrWait pattern (enable INT_SERIAL in IE, then sleep for
 *         that interrupt) rather than busy-polling SIOCNT bit 7 in a spin
 *         loop — busy-polling burns battery on real hardware and every
 *         GBA-dev tutorial (Tonc, gbadev) teaches IntrWait for exactly this
 *         reason — so a transfer that completes correctly but never
 *         interrupts leaves that (very common) style of ROM asleep
 *         forever, waiting for a wake-up that's never coming, even though
 *         the bytes themselves crossed the network correctly. This also
 *         explains the fast-forward symptom reported after FIX 9: an
 *         interrupt-driven ROM sitting in that sleep state isn't hitting
 *         the Start-bit write per frame at all (it wrote it once, then went
 *         to sleep waiting on the IRQ), so there's nothing left to make
 *         link_exchange()'s blocking network round-trip pace the frame
 *         rate — fast-forward looks and feels completely normal precisely
 *         *because* the link exchange has stalled, not because it's
 *         keeping up.
 *
 *         Confirmed against mGBA's actual src/gba/sio.c (read directly from
 *         the mgba-emu/mgba source this pass, not inferred): the real
 *         GBASIOWriteSIOCNT() calls exactly
 *         `GBARaiseIRQ(sio->p, GBA_IRQ_SIO, 0)` — same pattern already used
 *         for every other GBA interrupt source (timers, DMA, keypad) — but
 *         only from its own dummy-driver fallback, and only for Normal
 *         mode; SIO_MULTI's dummy-driver case does no IRQ work at all.
 *         That means for Multi-Player mode specifically, raising this
 *         interrupt has only ever been a registered driver's own job —
 *         exactly the role link_sio_write_register()/
 *         nativeLinkChildExchange() play here — it was just never done.
 *         Fixed by calling GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0) at the
 *         same point each function already finishes a transfer (after the
 *         four SIOMULTI0-3 writes), on both the host and child paths, once
 *         per device since each phone is a fully separate process with its
 *         own core. Deliberately unconditional on the timedOut branch too:
 *         real Multi-Player transfers are clocked by the parent's fixed
 *         baud rate (see GBASIOCyclesPerTransfer in the real sio.c) and
 *         complete — and interrupt — on that schedule regardless of
 *         whether a given child answered in time, which is exactly why
 *         FIX 9 already gives a timed-out round real 0xFFFF data and the
 *         Error bit instead of silently withholding the round entirely.
 *         `<mgba/internal/gba/gba.h>` is already included above (needed
 *         for `struct GBA` itself), and GBARaiseIRQ/GBA_IRQ_SIO live in
 *         that same header, so no new include was needed.
 *         Caveat: read directly from real mGBA source this pass (a real
 *         improvement over guessing from memory, which is how FIX 7/8's
 *         signature mismatches happened), but not from a byte-identical
 *         checkout of the exact pinned 0.10.3 tag, and still never
 *         compiled in this sandbox — this foundational an interrupt API
 *         (shared by every hardware peripheral, not link-specific) is a
 *         poor candidate for a breaking signature change, but if the CI
 *         build disagrees, this is the first place to check.
 * FIX 11 User re-tested FIX 10: no change at all, on either game, over
 *         either transport — "Connected" still shows, the ROM still
 *         doesn't react, fast-forward is still completely unthrottled.
 *         An identical, unimproved symptom after a real fix to a real gap
 *         is itself informative: it suggests link_sio_write_register()
 *         may never be firing at all, for either game, rather than firing
 *         and hitting some remaining logic bug. That would make sense of
 *         everything at once — GBASIOSetDriver() registers this driver
 *         only for SIO_MULTI, and the core re-picks its *active* driver
 *         from sio->drivers.* every time the ROM's own RCNT/SIOCNT mode
 *         bits change (see GBASIOWriteSIOCNT in FIX 10's citation); if
 *         either ROM's link handshake spends its time in a different mode
 *         (or never gets past an earlier stage at all), this driver simply
 *         never gets consulted, and FIX 9/10 together would have zero
 *         observable effect — exactly what was reported. Rather than guess
 *         at a fourth protocol theory with no way to check it from this
 *         sandbox, this pass adds permanent, cheap trace logging instead:
 *         every SIOCNT/SIOMLT_SEND write this driver handles is logged
 *         (tag mGBA-JNI), plus a separate warning if the Start bit is set
 *         but the exchange gets skipped, naming exactly which of
 *         env/g_link_obj/g_link_xchg_mid/g_core was unexpectedly null/
 *         false. Silence in logcat for this tag during a real link attempt
 *         is itself the answer: it means the mode-dispatch theory above is
 *         right and the next fix has to happen earlier in the handshake,
 *         not inside this driver. Real log output settles this in one
 *         test, instead of another pass of unverifiable guessing.
 * FIX 13 User re-tested FIX 12 (plus the Kotlin-side thumbnail/logcat-tool
 *         passes since): still stuck on ROM detection, on both transports,
 *         plus Wi-Fi disconnect not reaching the other phone and lag on
 *         Bluetooth. The two logcat dumps attached as evidence turned out to
 *         be the actual finding: both are real "mGBA-JNI"-tag captures (the
 *         tag filter in copyLinkDebugLog() is not the problem), but both
 *         cover barely 200ms of real time — pure boot-time DMA/register
 *         spam, nothing from anywhere near an actual link attempt. Root
 *         cause: jni_log() (this file's mLogger callback, registered once
 *         at core init) forwarded every mGBA core log line, at every level,
 *         to LOGI — including mLOG_STUB/mLOG_DEBUG chatter like "Starting
 *         DMA ..." and "Read from write-only I/O register: ..." that fires
 *         dozens of times per frame for any ROM, completely unrelated to
 *         link. copyLinkDebugLog()'s `logcat -t 2000` (most recent 2000
 *         matching lines) never had a chance against that volume — by the
 *         time W finished a test and copied the log, everything from the
 *         actual multiplayer attempt had long since scrolled out from under
 *         routine gameplay's own DMA/register traffic, boot alone was
 *         enough to fill the window before anything link-related even
 *         started.
 *         Fix: jni_log() now drops mLOG_DEBUG/mLOG_STUB/mLOG_GAME_ERROR
 *         before they reach LOGI (mirrors mGBA's own libretro frontend
 *         under NDEBUG), plus a belt-and-suspenders prefix check on the two
 *         specific messages actually observed. FATAL/ERROR/WARN/INFO, and
 *         everything either this file's own LOGI/LOGW calls or
 *         LinkMultiplayer.kt's Log.i/Log.w calls produce, are unaffected.
 *         Full detail in jni_log() itself, below. Not a fix for the
 *         reported symptoms directly — a fix for why every piece of
 *         evidence gathered about them so far has been empty. The next
 *         capture, taken after actually reaching both ROMs' link screens
 *         (not right after boot), should finally show FIX 11's SIO trace
 *         and LinkMultiplayer.kt's own connection-lifecycle logging instead
 *         of nothing.
 * FIX 14 Same pass as FIX 13, found while re-reading this file end to end
 *         looking for anything FIX 9-12 might have missed rather than
 *         anything the (empty) logcat evidence pointed at. link_sio_write_
 *         register()'s exchange branch was never actually gated on
 *         g_link_is_host — every FIX 9-12 comment already *describes* the
 *         design as host-only (a child only ever answers via the network-
 *         driven nativeLinkChildExchange(), never its own SIO write; FIX 9's
 *         own comment claimed this branch "correctly never fires" on a
 *         child) but nothing enforced it. GBATEK says Start/Busy is
 *         hardware-read-only for a slave, so a compliant ROM's own child-
 *         role write should already be inert — but if either test ROM
 *         shares parent/child code through one Sio API (plausible; Nintendo's
 *         own SDK is commonly used that way) and doesn't distinguish, this
 *         branch would have treated that write as a real trigger and run a
 *         second, spurious wifiExchange()/btExchange() from the child's own
 *         thread — sending an unsolicited DATA packet the host's *next*
 *         real exchange could then race against and consume as that round's
 *         reply. Fits the symptom set well: identical ROM-detection failure
 *         on both transports (this file is shared; the transport-specific
 *         Kotlin already got FIX 9-12's full attention) and worse lag
 *         specifically on Bluetooth (BT_XCHG_MS=50 vs WIFI_XCHG_MS=30 — a
 *         stolen-reply timeout costs more there).
 *         Fix: added `&& g_link_is_host` to the branch condition; simplified
 *         the two blocks inside it that used to switch on g_link_is_host,
 *         since it's now always true there. The FIX 11 diagnostic warning
 *         is now also host-gated, so a child's now-correctly-ignored
 *         Start-bit write doesn't get logged every occurrence — see that
 *         `else if` for why logging it at all would risk reintroducing
 *         FIX 13's problem.
 *         Not confirmed — same caveat as every pass, no NDK/device here —
 *         and unlike FIX 12, this one wasn't reached by reading an actual
 *         logcat, it's a design-intent gap this file's own comments already
 *         flagged without closing. Genuinely possible this changes nothing
 *         for either reported bug. FIX 13's improved logging is what would
 *         actually show whether a child device was ever hitting the old
 *         unguarded branch in the first place — if the next capture's
 *         "SIO write ... active=1 host=0" lines never carry the Start bit
 *         at all, this fix was a no-op hardening, not the cause.
 */


#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>

#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>
#include <mgba/core/config.h>
#include <mgba/core/log.h>
#include <mgba/core/serialize.h>     /* mCoreSaveStateNamed/mCoreLoadStateNamed,
                                       * SAVESTATE_* flags — save states. */
#include <mgba/core/blip_buf.h>      /* blip_t, blip_samples_avail, blip_read_samples
                                       * — this is mGBA's public wrapper header that
                                       * re-exports src/third-party/blip_buf/blip_buf.h.
                                       * The bare "mgba-util/blip_buf.h" path used
                                       * previously does not exist in the mGBA tree. */
#include <mgba-util/vfs.h>           /* VFileOpen/struct VFile — battery save +
                                       * save-state I/O both go through explicit
                                       * VFiles rather than mCore's slot/directory
                                       * API, since this app never sets up
                                       * core->dirs (no mDirectorySetAttachBase
                                       * call anywhere) — see nativeLoadROM,
                                       * nativeSaveState, nativeLoadState. */

#ifndef mColor
typedef uint32_t mColor;
#endif
#include <mgba/gba/core.h>
#include <mgba/gba/interface.h>       /* struct GBASIODriver */
#include <mgba/internal/gba/gba.h>    /* struct GBA — needed to reach gba->sio via core->board */
#include <mgba/internal/gba/sio.h>    /* GBASIOSetDriver, enum GBASIOMode (SIO_MULTI) */

#define LOG_TAG        "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* GBA ARM7TDMI clock — used as the blip_buf input clock rate.
 * mGBA advances blip buffers at the CPU clock, so this must match. */
#define GBA_AUDIO_CLOCK 16777216

/* ── Globals — all access must hold g_core_mutex ────────────────────────── */

static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore   *g_core   = NULL;
static mColor         *g_fb     = NULL;
static int             g_width  = 240;
static int             g_height = 160;

/* ── Link cable state — also protected by g_core_mutex ──────────────────── */

static jobject   g_link_obj      = NULL;
static jmethodID g_link_xchg_mid = NULL;
static bool      g_link_active   = false;
static bool      g_link_is_host  = false;

/* FIX 8 (build-log driven): these were previously declared far below, in the
 * "GBA LINK CABLE MULTIPLAYER" section — but nativeLoadROM and nativeRunFrame
 * both reference them earlier in the file than that, which doesn't compile
 * in C (confirmed by the actual build log: "use of undeclared identifier
 * 'g_link_gba'" / "'g_link_driver'" at the point of use). Declared here
 * instead, alongside the other link-cable globals, so every use site is
 * after the declaration regardless of where in the file it appears. */
struct LinkSIODriver {
    struct GBASIODriver d;
    JNIEnv  *env;       /* only valid while nativeRunFrame is on the stack */
    uint16_t localSend; /* last value the ROM wrote to SIOMLT_SEND (0x12A) */
};
static struct LinkSIODriver g_link_driver;
static struct GBA          *g_link_gba = NULL;

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);

    /* FIX 13: this used to forward every single mGBA core log line, at any
     * level, to LOGI under the same "mGBA-JNI" tag FIX 11's link-diagnostic
     * trace also uses (see copyLinkDebugLog() in MainActivity.kt, which
     * greps logcat by tag). Confirmed this pass, both from mgba-emu/mgba's
     * real source and directly from the two logcat dumps W attached: normal
     * GBA emulation is extremely DMA/register-heavy — "Starting DMA 3
     * 0x..." and "Read from write-only I/O register: 0xNN" (the latter is
     * mLOG_STUB — see src/gba/io.c's own use of that level for exactly this
     * "wrote/read an unimplemented or wrong-direction register" case) fire
     * dozens of times per single video frame, every frame, for any ROM —
     * completely unrelated to link/multiplayer.
     * copyLinkDebugLog()'s `logcat -t 2000` grabs the most recent 2000
     * lines matching the tag filter, combined across mGBA-JNI/mGBA-Link/
     * mGBA — but with this noise included, 2000 lines is nowhere near
     * enough: both logs W attached this pass covered barely 200ms of real
     * time each, entirely boot-time DMA/register spam, nothing from
     * anywhere near the actual multiplayer attempt. (KNOWN_LIMITATIONS.md's
     * Thirteenth-pass entry describes an *earlier* capture that did contain
     * real signal — but that was this same noise co-occurring with the
     * rawWrite16 STUB spam FIX 12 has since removed, not evidence this
     * window was ever reliably wide enough.) The tag filter itself was
     * never the problem — every line in both dumps genuinely was
     * "mGBA-JNI" — the volume was.
     * Fix: drop mLOG_DEBUG/mLOG_STUB/mLOG_GAME_ERROR here before they ever
     * reach LOGI. This mirrors mGBA's own src/platform/libretro/libretro.c
     * under NDEBUG (which this project's own CMakeLists.txt also builds
     * with) — GBARetroLog() drops exactly these same three levels outright
     * in a release build. FATAL/ERROR/WARN/INFO still come through
     * unfiltered. Belt-and-suspenders on top of the level check: also drop
     * the two specific message prefixes actually observed flooding both of
     * this pass's logs, in case either turns out not to be DEBUG/STUB after
     * all — this costs nothing and directly guarantees the exact noise seen
     * is gone regardless.
     * Side benefit, not just a multiplayer fix: this logging tax has been
     * paid on *every* frame of *every* ROM since FIX 1 first wired up
     * mLogSetDefaultLogger — general gameplay was never link-related but
     * was never exempt from it either. __android_log_print is a real
     * syscall (a socket write to logd), not free; removing dozens of these
     * per frame is a plausible contributor to general perf/lag complaints
     * older than this specific multiplayer investigation, not only the
     * "lag on Bluetooth" this pass was asked about. */
    if (level & (mLOG_DEBUG | mLOG_STUB | mLOG_GAME_ERROR)) return;
    if (!strncmp(buf, "Starting DMA", 12))         return;
    if (!strncmp(buf, "Read from write-only", 21)) return;
    if (!strncmp(buf, "Write to read-only", 19))   return;

    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup — CALLER MUST HOLD g_core_mutex ───────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath, jstring jSavePath)
{
    /* FIX (residual risk from prior pass): the old core used to be destroyed
     * unconditionally here, before the new ROM was even opened. If any step
     * below failed (bad/corrupt file, core init failure, OOM), the in-progress
     * session was already gone with nothing to fall back to.
     *
     * Now the new core is built entirely in local variables — g_core/g_fb are
     * never touched — and the old core is only torn down once every step has
     * succeeded. On any failure path the caller's existing session (if any)
     * is left running exactly as it was. */

    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    LOGI("Loading ROM: %s", path);

    struct mCore *core = GBACoreCreate();
    if (!core) {
        LOGE("GBACoreCreate failed");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    mCoreInitConfig(core, "mgba-android");

    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios     = true;
    opts.useBios      = false;
    opts.sampleRate   = 44100;
    opts.audioBuffers = 1024;
    opts.volume       = 256;
    mCoreConfigLoadDefaults(&core->config, &opts);
    /* AUDIO FIX (root cause, not a symptom patch): this MUST be the single-
     * argument mCoreLoadConfig(core), not core->loadConfig(core, &core->config)
     * directly.
     *
     * mCoreLoadConfig() internally calls mCoreLoadForeignConfig(), which does
     * two things before it ever reaches the vtable loadConfig:
     *   1. mCoreConfigMap(config, &core->opts)  -- maps the "volume" key we
     *      just set above (opts.volume = 256) into core->opts.volume.
     *   2. core->setAudioBufferSize(core, core->opts.audioBuffers).
     * Only THEN does it call core->loadConfig(core, config), which for the
     * GBA core runs:  gba->audio.masterVolume = core->opts.volume;
     *
     * Calling core->loadConfig() directly (as this file previously did)
     * skips step 1 entirely, so core->opts.volume is left at its
     * zero-initialized default and every ROM's audio mixer comes up
     * permanently muted at masterVolume=0 -- silent regardless of anything
     * downstream (AudioTrack, blip_buf, etc. all work correctly; they're
     * just relaying real zeroes). This was the actual cause of "no sound";
     * the AudioTrack/AudioFocus work in the Kotlin layer was correct but
     * couldn't fix a mixer that was muted at the native layer. */
    mCoreLoadConfig(core);

    const unsigned w = 240, h = 160;

    mColor *fb = (mColor *)calloc((size_t)w * (size_t)h, sizeof(mColor));
    if (!fb) {
        LOGE("framebuffer alloc failed (%ux%u)", w, h);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, fb, (size_t)w);

    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed: %s", path);
        free(fb);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* FEATURE: battery/cart save (SRAM/Flash/EEPROM) persistence.
     * core->loadSave() hands the core a VFile it owns for the rest of this
     * core's lifetime — mGBA's savedata backend mmaps it, and every in-game
     * write (a menu's "Save the game?" prompt, an action game's checkpoint,
     * etc.) lands directly in the mapped pages, which the kernel writes back
     * to [savePath] on its own — the same durability model any mmap-backed
     * store relies on (mGBA's own VFS layer calls msync when explicitly
     * syncing mapped data). The core closes this VFile itself as part of
     * core->deinit() (see destroy_core()), so it is NOT closed here.
     *
     * O_CREAT | O_RDWR, no O_TRUNC: a fresh save is created empty and the
     * savedata backend grows it to the detected size (SRAM/Flash/EEPROM) on
     * first write; an existing file's contents are preserved untouched, so
     * re-loading the same ROM later (see MainActivity.deriveRomBaseName)
     * resumes the same in-game save.
     *
     * Order matters: this MUST run after mCoreLoadFile (the save type is
     * detected from the ROM header while loading) and before core->reset()
     * below — the same order every mGBA frontend uses (see e.g.
     * src/platform/sdl/main.c: mCoreLoadFile → mCoreAutoloadSave → … →
     * reset happens once the emulation thread actually starts). Reset only
     * reinitialises CPU/PPU/etc. state; it does not touch already-loaded
     * save data, exactly like a real GBA's power button doesn't erase the
     * cartridge's battery save. */
    if (jSavePath) {
        const char *savePath = (*env)->GetStringUTFChars(env, jSavePath, NULL);
        if (savePath) {
            struct VFile *saveVf = VFileOpen(savePath, O_CREAT | O_RDWR);
            if (saveVf) {
                if (!core->loadSave(core, saveVf)) {
                    LOGW("core->loadSave failed for %s (ROM may have no battery save)", savePath);
                }
            } else {
                LOGW("VFileOpen failed for save path: %s", savePath);
            }
            (*env)->ReleaseStringUTFChars(env, jSavePath, savePath);
        }
    } else {
        LOGW("nativeLoadROM: no save path given — battery save will not persist");
    }

    core->reset(core);

    /* ── FIX: Explicitly set blip buffer sample rates after reset ────────
     * mCoreConfigLoadDefaults+loadConfig should configure this, but on some
     * mGBA build variants loadConfig doesn't call blip_set_rates until a
     * subsequent reset — which is circular.  Calling it here unconditionally
     * after the reset guarantees both blip buffers are live before any frame
     * is rendered.  If rates were already set correctly this is a safe no-op. */
    {
        blip_t *left  = core->getAudioChannel(core, 0);
        blip_t *right = core->getAudioChannel(core, 1);
        if (left && right) {
            blip_set_rates(left,  GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            blip_set_rates(right, GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            LOGI("blip_set_rates: clock=%d  sampleRate=%d",
                 GBA_AUDIO_CLOCK, (int)opts.sampleRate);
        } else {
            LOGW("getAudioChannel returned NULL — audio will be silent");
        }
    }

    /* Swap in the fully-loaded new core and only now tear down whatever was
     * running before. destroy_core() operates on the (still-old) globals, so
     * we snapshot them, install the new core, then deinit the snapshot —
     * all under one lock, so nativeRunFrame/nativeReadAudioSamples/etc. never
     * observe a half-swapped state. */
    pthread_mutex_lock(&g_core_mutex);
    struct mCore *old_core = g_core;
    mColor       *old_fb   = g_fb;
    /* SAFETY: g_link_gba points into the OLD core's GBA struct, which
     * old_core->deinit() below is about to free. If a link session was left
     * running across a ROM swap, drop it now rather than leave a dangling
     * pointer for link_sio_write_register to dereference on the next
     * transfer — the Kotlin side will see the link drop and can restart it
     * against the new ROM if the user still wants it. */
    if (g_link_active) {
        g_link_active = false;
        g_link_gba    = NULL;
        LOGW("ROM swapped while a link session was active — link stopped");
    }
    g_core   = core;
    g_fb     = fb;
    g_width  = (int)w;
    g_height = (int)h;
    pthread_mutex_unlock(&g_core_mutex);

    if (old_core) {
        old_core->deinit(old_core);
    }
    free(old_fb);

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, (int)w, (int)h);
    return JNI_TRUE;
}

/* Forward declaration */
static uint32_t link_exchange(JNIEnv *env, uint32_t local_data);

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core || !g_fb) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* FIX 7: give the SIO driver callback a valid JNIEnv* for the duration of
     * this call only — it fires synchronously, on this same thread, from
     * inside runFrame() the instant the game writes the Start bit, so it can
     * safely borrow this call's env rather than needing one of its own. */
    g_link_driver.env = g_link_active ? env : NULL;
    g_core->runFrame(g_core);
    g_link_driver.env = NULL;

    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (bitmap == NULL) {
        /* PERF: fast-forward sub-frames that will never reach the screen
         * (see the Kotlin call site in MainActivity.startGameLoop — only the
         * LAST sub-frame of a fast-forward batch is displayed) pass NULL
         * here to skip the pixel copy below entirely. Emulation and audio
         * still run in full above; only the wasted blit is skipped. */
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    for (int row = 0; row < g_height; row++) {
        const mColor *srcRow = g_fb + (size_t)row * (size_t)g_width;
        uint32_t     *dstRow = (uint32_t *)((uint8_t *)pixels
                                            + (size_t)row * info.stride);
        for (int col = 0; col < g_width; col++) {
            dstRow[col] = (srcRow[col] & 0x00FFFFFFu) | 0xFF000000u;
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeReadAudioSamples ─────────────────────────────────────────────── */
/*
 * FIX 4 — drain mGBA blip buffers into a Java short[] for AudioTrack.
 *
 * blip_read_samples(buf, arr, count, stereo=1) writes to every OTHER element
 * when stereo=1, so we can interleave L and R in one pass each:
 *   L → arr[0], arr[2], arr[4]…
 *   R → arr[1], arr[3], arr[5]…
 *
 * Returns the number of stereo sample PAIRS written (array elements used = n*2).
 * Returns 0 when no samples are available or the core is not initialised.
 *
 * Called from the game thread immediately after nativeRunFrame(), so the mutex
 * is always available (no nested locking).
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeReadAudioSamples(
        JNIEnv *env, jobject thiz, jshortArray jbuf, jint maxSamples)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    blip_t *left  = g_core->getAudioChannel(g_core, 0);
    blip_t *right = g_core->getAudioChannel(g_core, 1);
    if (!left || !right) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    int availL = blip_samples_avail(left);
    int availR = blip_samples_avail(right);
    /* AUDIO FIX: previously only availL was checked and re-used for both
     * blip_read_samples() calls, on the assumption the two channels are
     * always in lockstep (true for mGBA's GBA core in normal operation, but
     * not something the JNI layer should silently assume — reading more
     * samples than a channel actually has buffered is undefined behavior in
     * blip_buf, not a safely-clamped no-op). Take the minimum of both. */
    int avail = (availL < availR) ? availL : availR;
    int count = (avail < (int)maxSamples) ? avail : (int)maxSamples;
    if (count <= 0) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    jshort *arr = (*env)->GetShortArrayElements(env, jbuf, NULL);
    if (!arr) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    /* stereo=1: write to every other element, perfect for L/R interleaving */
    blip_read_samples(left,  arr,     count, 1);   /* → [0],[2],[4]…  */
    blip_read_samples(right, arr + 1, count, 1);   /* → [1],[3],[5]…  */

    (*env)->ReleaseShortArrayElements(env, jbuf, arr, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return (jint)count;
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint w = (jint)g_width;
    pthread_mutex_unlock(&g_core_mutex);
    return w;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint h = (jint)g_height;
    pthread_mutex_unlock(&g_core_mutex);
    return h;
}

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("mGBA core destroyed");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * SAVE STATES
 * ═══════════════════════════════════════════════════════════════════════════
 * Full emulator snapshots (CPU/PPU/audio/in-flight save data/RTC — enough to
 * resume mid-frame exactly where you left off), independent of the battery
 * save handled in nativeLoadROM above. Written via mCoreSaveStateNamed()/
 * mCoreLoadStateNamed() against a plain VFile at whatever path the Kotlin
 * layer passes in.
 *
 * These *Named variants (not mCoreSaveState()/mCoreLoadState()'s slot-number
 * API) are used deliberately: the slot API resolves numbered slots through
 * core->dirs.state, a VDir this app never sets up (mCoreInitConfig() above
 * only loads config values — see nativeLoadROM — it doesn't attach
 * directories the way a desktop frontend's mDirectorySetAttachBase() call
 * would). The Named variants take an explicit VFile instead and need no
 * such setup; MainActivity.kt manages "slots" itself as plain files.
 *
 * Flags: SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA.
 * SAVESTATE_SCREENSHOT is deliberately excluded — this build has USE_PNG and
 * USE_ZLIB both OFF (see CMakeLists.txt), and PNG-embedded screenshot
 * support in src/core/serialize.c is gated behind USE_PNG. SAVESTATE_CHEATS
 * is excluded because this app never attaches a cheat device. */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSaveState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeSaveState: no ROM loaded");
        return JNI_FALSE;
    }

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) {
        pthread_mutex_unlock(&g_core_mutex);
        return JNI_FALSE;
    }

    /* O_TRUNC: a save-state slot is always a single complete snapshot that
     * fully replaces whatever was there before — never appended to or
     * merged (matches src/feature/gui/gui-runner.c's own slot-write
     * pattern: O_CREAT | O_TRUNC | O_RDWR). */
    struct VFile *vf = VFileOpen(path, O_CREAT | O_TRUNC | O_RDWR);
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    if (!vf) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGE("nativeSaveState: VFileOpen failed");
        return JNI_FALSE;
    }

    bool ok = mCoreSaveStateNamed(g_core, vf,
        SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    vf->close(vf);
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("nativeSaveState: %s", ok ? "OK" : "FAILED");
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeLoadState: no ROM loaded");
        return JNI_FALSE;
    }

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) {
        pthread_mutex_unlock(&g_core_mutex);
        return JNI_FALSE;
    }

    struct VFile *vf = VFileOpen(path, O_RDONLY);
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    if (!vf) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGW("nativeLoadState: slot file missing or unreadable");
        return JNI_FALSE;
    }

    bool ok = mCoreLoadStateNamed(g_core, vf,
        SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    vf->close(vf);
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("nativeLoadState: %s", ok ? "OK" : "FAILED");
    return ok ? JNI_TRUE : JNI_FALSE;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * GBA LINK CABLE MULTIPLAYER
 * ═══════════════════════════════════════════════════════════════════════════ */

static uint32_t link_exchange(JNIEnv *env, uint32_t local_data)
{
    if (!env || !g_link_obj || !g_link_xchg_mid) return 0xFFFFFFFFu;
    jint r = (*env)->CallIntMethod(env, g_link_obj,
                                    g_link_xchg_mid, (jint)local_data);
    if ((*env)->ExceptionOccurred(env)) {
        (*env)->ExceptionClear(env);
        return 0xFFFFFFFFu;
    }
    return (uint32_t)r;
}

/* ── FIX 7: real GBASIODriver, registered with the core's SIO subsystem ──
 *
 * This is what src/gba/sio.c actually dispatches to when the game writes
 * SIOCNT or SIOMLT_SEND — as opposed to the old approach of reading those
 * registers back out after the fact, which the core's own dummy-driver
 * fallback had usually already resolved by the time we looked.
 *
 * struct GBASIODriver only specifies the callback layout; every real driver
 * in mGBA (see src/gba/hardware.c's Game Boy Player driver for the pattern
 * this mirrors) wraps it in its own struct with whatever extra state it
 * needs, and casts back to that wrapper inside its callbacks.
 * (struct LinkSIODriver / g_link_driver / g_link_gba are declared up near
 * the other link-cable globals — see FIX 8.)
 *
 * address here is the register OFFSET from the 0x4000000 IO base (mGBA's
 * own dispatcher indexes memory.io[] with it), so SIOCNT is 0x128 and
 * SIOMLT_SEND is 0x12A — not the full 0x04000128 / 0x400012A addresses. */
static uint16_t link_sio_write_register(struct GBASIODriver *driver,
                                         uint32_t address, uint16_t value)
{
    struct LinkSIODriver *ld = (struct LinkSIODriver *)driver;

    /* FIX 11 (diagnostic): this callback only ever runs while the core's
     * own SIO mode is SIO_MULTI (GBASIOSetDriver registers us per-mode;
     * the core re-picks its active driver from sio->drivers.* every time
     * the ROM's own RCNT/SIOCNT mode bits change). If nothing shows up in
     * logcat for this tag while a real link attempt is in progress, the
     * ROM is either never reaching Multi-Player mode at all (e.g. sitting
     * in an earlier General-Purpose handshake, or using Normal mode
     * instead), or nativeLinkStart()/GBASIOSetDriver() never actually took
     * effect — both very different problems from anything FIX 9/10
     * touched. This is intentionally left in as a permanent, cheap trace;
     * it only fires on real SIOCNT/SIOMLT_SEND writes, not every frame. */
    LOGI("SIO write addr=0x%03X value=0x%04X active=%d host=%d",
         (unsigned)address, (unsigned)value,
         (int)g_link_active, (int)g_link_is_host);

    if (address == 0x12Au) {                 /* SIOMLT_SEND: just latch it */
        ld->localSend = value;
        return value;
    }

    if (address != 0x128u) return value;

    /* FIX 9 (GBATEK-verified: gbatek "SIO Multi-Player Mode" register table).
     * Reflect link status on *every* SIOCNT write, not only ones with the
     * Start bit set:
     *   Bit 2 (SI-Terminal): 0=Parent, 1=Child            — read-only status
     *   Bit 3 (SD-Terminal): 0=Bad connection, 1=All Ready — read-only status
     * Both are hardware-read-only — real GBAs don't let the CPU set them,
     * they always reflect true link state — and GBATEK's own Multi-Player
     * initialization sequence has every ROM read both BEFORE ever attempting
     * a transfer ("Read SIOCNT Bit 3 to verify that all GBAs are in
     * Multi-Player mode" / "...Bit 2 to detect whether this is the Parent").
     * Nothing previously set either bit, so a ROM doing that check first —
     * before ever writing the Start bit — would see bit 3 permanently 0,
     * indistinguishable from "no cable plugged in", and could sit on a
     * "waiting for link" screen forever even after the phones' own network
     * handshake had already succeeded. Applying this on every write (not
     * just Start-bit ones) means it's already correct by the time the ROM's
     * *first* SIOCNT write (the one that merely selects multiplayer mode,
     * Start bit still 0) happens, with no dependency on transfer timing. */
    if (g_link_active) {
        value |= 0x0008u;                                                      /* bit3: ready */
        value = (uint16_t)((value & ~0x0004u) | (g_link_is_host ? 0u : 0x0004u)); /* bit2 */
    }

    /* FIX 14: added the g_link_is_host guard. Every FIX 9-12 comment in this
     * file already describes the intended design as "the child never
     * triggers its own exchange, only nativeLinkChildExchange() (driven by
     * the network, not a local SIO write) ever runs on a child" — GBATEK is
     * explicit that Start/Busy is read-only for slaves — but nothing here
     * actually enforced that: this branch fired for *either* role's own
     * Start-bit write, unconditionally. On real hardware a child's write to
     * this bit is physically ignored, so if either test ROM's link code is
     * shared between parent/child paths (common — Nintendo's own SDK
     * exposes one Sio API either role calls) and doesn't distinguish, a
     * child device would already have been triggering a second, spurious,
     * protocol-violating exchange of its own alongside nativeLinkChildExchange()
     * answering the real one from the network side — sending an unsolicited
     * DATA packet the *host*'s next real wifiExchange()/btExchange() round
     * could then race against and consume as if it were that round's reply.
     * That would explain the reported symptom set unusually well: identical
     * ROM-detection failure on both transports (this file is shared by
     * both, unlike the transport-specific Kotlin code, which FIX 9-12
     * already hardened per-transport) and worse lag specifically on
     * Bluetooth (BT_XCHG_MS=50 vs WIFI_XCHG_MS=30 — a stolen-reply timeout
     * costs more there). Not confirmed — this sandbox can't attach a
     * debugger to a real link session — but cheap, safe (host behavior is
     * completely unchanged; is_host is already true on every path that used
     * to run), and consistent with what every prior pass already said the
     * design should be. See KNOWN_LIMITATIONS.md for what would actually
     * confirm or rule this out.
     * Simplified below to match: hostData/childData and the ID-bit write
     * near the bottom of this block both had a `g_link_is_host ? … : …`
     * branch for the child-role case that this guard now makes unreachable
     * — removed rather than left as dead code that looks live. */
    if ((value & 0x0080u) && g_link_is_host && ld->env
        && g_link_obj && g_link_xchg_mid && g_core) {  /* Start/Busy bit */
        uint32_t remote_data = link_exchange(ld->env, (uint32_t)ld->localSend);
        bool     timedOut    = (remote_data == 0xFFFFFFFFu);
        uint16_t remote16    = (uint16_t)(remote_data & 0xFFFFu);
        uint16_t hostData    = ld->localSend;
        uint16_t childData   = remote16;
        /* FIX 8 (build-log driven): GBASIOMultiplayerFinishTransfer() was the
         * "correct" internal call for this — same one the core's own drivers
         * use — but the previous build log showed it as an implicit
         * (undeclared) function even with sio.h included, meaning it isn't
         * actually exposed on the mGBA revision this project pins (0.10.3);
         * that header apparently gained it later. Rather than risk an
         * unresolved symbol at link time, write the four multiplayer data
         * registers directly.
         * FIX 12: "directly" now means memory.io[], not rawWrite16(). See
         * FIX 12's entry at the top of this file — rawWrite16 silently
         * no-ops for the entire I/O region (it's GBAPatch16 underneath,
         * and GBAPatch16 only backs EWRAM/IWRAM/palette RAM), so these were
         * never actually reaching SIOMULTI0-3. This used to also skip the
         * SIO IRQ that the internal call would have raised automatically —
         * see FIX 10 below, which now raises it explicitly instead. */
        g_link_gba->memory.io[0x0120u >> 1] = hostData;
        g_link_gba->memory.io[0x0122u >> 1] = childData;
        g_link_gba->memory.io[0x0124u >> 1] = 0xFFFFu;
        g_link_gba->memory.io[0x0126u >> 1] = 0xFFFFu;
        /* FIX 10: the transfer is done — raise the interrupt an
         * interrupt-driven ROM (IntrWait/VBlankIntrWait on INT_SERIAL,
         * the standard GBA-dev pattern) is asleep waiting for. A
         * poll-driven ROM just ignores this (IF gets a bit set that
         * nothing ever checks) — safe either way. See FIX 10 above for
         * why this is unconditional on timedOut. */
        GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0);
        value &= ~0x0080u;   /* Start/Busy bit: transfer already complete */
        /* FIX 9: per GBATEK, ID bits (4-5) are undefined until the first
         * transfer completes (00=parent, 01=1st child) — games use this,
         * alongside bit 2 above, to tell their own role apart. Bit 6 (Error)
         * flags a round where the peer didn't answer in time, instead of
         * silently handing the ROM a stale 0xFFFF indistinguishable from
         * real "not connected" data — GBATEK explicitly expects parent-side
         * error checking here ("parent unit might... perform error
         * checking"), so this gives it something real to check. */
        value = (uint16_t)(value & ~0x0030u);   /* ID bits: 0 = parent (see FIX 14 above — this device is always host inside this block now) */
        value = timedOut ? (uint16_t)(value | 0x0040u) : (uint16_t)(value & ~0x0040u);
    } else if ((value & 0x0080u) && g_link_is_host) {
        /* FIX 11 (diagnostic): Start bit was set, but the exchange above was
         * skipped — this driver callback fired, so mode selection isn't the
         * problem, but one of these four is unexpectedly null/false. ld->env
         * is only non-NULL for the duration of a runFrame() call (see nativeRunFrame),
         * so JNI is not the issue if we got this far at all; g_link_obj/
         * g_link_xchg_mid come from nativeLinkStart, g_core from ROM load.
         * FIX 14: this condition now also requires g_link_is_host, so it
         * no longer fires for the (now-expected, see FIX 14 above) case of
         * a child's own SIOCNT write carrying the Start bit — that's not
         * logged at all, deliberately: if a ROM's child-role code path
         * writes this on every poll iteration, logging it unconditionally
         * would reintroduce the exact volume problem FIX 13 just fixed. */
        LOGW("Start bit set but exchange skipped: env=%p obj=%p mid=%p core=%p",
             (void *)ld->env, (void *)g_link_obj,
             (void *)g_link_xchg_mid, (void *)g_core);
    }
    return value;
}

/* FIX 9 — passive-child responder entry point.
 *
 * GBATEK is explicit that the Start/Busy bit is "Read Only for Slaves" — on
 * real hardware a child unit never triggers a transfer itself, it only ever
 * reacts to the parent's clock. link_sio_write_register()'s exchange branch
 * above is keyed off *this device's own* SIOCNT Start-bit write; the
 * original version of this comment (FIX 9) claimed that branch therefore
 * "correctly never fires" on a child device, matching real hardware — but
 * that was an assumption resting entirely on child ROM code never actually
 * performing that write, not anything this file enforced. FIX 14 (see
 * above) added the missing g_link_is_host guard so it's now actually true
 * regardless of what a child ROM's own code does. Either way, a child's
 * local jniExchangeData()/wifiExchange()/btExchange() call (the only thing
 * that ever answered the parent's request packet) never happened by itself,
 * so the parent's every attempt timed out waiting for a reply nothing was
 * ever going to send: multiplayer could never progress past a "waiting for
 * players" screen, regardless of whether the two phones' own network
 * connection was fine.
 *
 * Called from a background Kotlin thread (LinkMultiplayer's dedicated Wi-Fi
 * child-listener thread, or its Bluetooth reader thread acting in child
 * mode) the instant a request arrives from the parent over the network —
 * never from anything the local ROM does. It writes this device's own
 * SIOMULTI0/1 exactly as the parent side does above, so this device's ROM
 * sees a completed transfer next time it reads those registers, and returns
 * this device's latched SIOMLT_SEND value so the Kotlin caller can send it
 * back to the parent as that round's reply.
 *
 * Deliberately does NOT touch SIOCNT itself (unlike the parent-side branch
 * above): doing so correctly would mean preserving the mode/baud bits the
 * ROM already wrote, which needs reading the register back first, and
 * there's no confirmed-working raw-read counterpart to rawWrite16 in this
 * file yet to verify that against a real build. Bits 2/3 are still handled
 * correctly for a child (see the write-register comment above — those
 * apply on the child's own initial mode-setup write, which it does still
 * make); only the post-transfer ID/Error bits (4-6) are not mirrored on the
 * child's own SIOCNT. See KNOWN_LIMITATIONS.md.
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(
        JNIEnv *env, jobject thiz, jint hostData)
{
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_core_mutex);
    if (!g_link_active || g_link_is_host || !g_link_gba || !g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        return (jint)0xFFFF;
    }
    uint16_t childData = g_link_driver.localSend;
    /* FIX 12: see the top-of-file entry and the host-side branch above —
     * rawWrite16 is GBAPatch16 underneath and silently no-ops for the I/O
     * region, so this was never actually reaching SIOMULTI0-3 either. */
    g_link_gba->memory.io[0x0120u >> 1] = (uint16_t)hostData;
    g_link_gba->memory.io[0x0122u >> 1] = childData;
    g_link_gba->memory.io[0x0124u >> 1] = 0xFFFFu;
    g_link_gba->memory.io[0x0126u >> 1] = 0xFFFFu;
    /* FIX 10: same reasoning as the host side above — this device is a
     * separate process with its own core, so it needs its own IRQ raised
     * on its own GBA struct for an interrupt-driven child ROM to ever wake
     * up and notice the transfer that just landed in its SIOMULTI regs. */
    GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return (jint)childData;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStart(
        JNIEnv *env, jobject thiz, jobject link_obj, jboolean is_host)
{
    (void)thiz;
    if (g_link_obj) { (*env)->DeleteGlobalRef(env, g_link_obj); g_link_obj = NULL; }

    jclass cls = (*env)->GetObjectClass(env, link_obj);
    g_link_xchg_mid = (*env)->GetMethodID(env, cls, "jniExchangeData", "(I)I");
    if (!g_link_xchg_mid) {
        LOGE("LinkMultiplayer.jniExchangeData(I)I not found");
        return JNI_FALSE;
    }
    g_link_obj     = (*env)->NewGlobalRef(env, link_obj);
    g_link_is_host = (bool)is_host;

    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGE("nativeLinkStart called with no ROM loaded");
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
        return JNI_FALSE;
    }

    /* FIX 7/8: register a real driver with the core's SIO subsystem instead
     * of relying on post-frame register polling. GBASIOSetDriver() on this
     * mGBA revision takes a mode argument (confirmed by the build log: the
     * 2-argument call I wrote from mgba's current docs failed to compile —
     * "too few arguments to function call, expected 3, have 2" — this
     * revision's signature apparently predates that simplification), and
     * struct GBASIODriver has no processEvents member on this revision
     * either (also confirmed by the build log). */
    g_link_gba = (struct GBA *)g_core->board;
    g_link_driver.d.init          = 0;
    g_link_driver.d.deinit        = 0;
    g_link_driver.d.load          = 0;
    g_link_driver.d.unload        = 0;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env             = NULL;
    g_link_driver.localSend       = 0xFFFFu;
    GBASIOSetDriver(&g_link_gba->sio, &g_link_driver.d, SIO_MULTI);

    g_link_active = true;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("Link multiplayer started (host=%d)", (int)is_host);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStop(JNIEnv *env, jobject thiz)
{
    (void)thiz;
    pthread_mutex_lock(&g_core_mutex);
    g_link_active = false;
    if (g_link_gba) {
        GBASIOSetDriver(&g_link_gba->sio, NULL, SIO_MULTI);   /* core reverts to its own dummy driver */
        g_link_gba = NULL;
    }
    pthread_mutex_unlock(&g_core_mutex);

    if (g_link_obj) {
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
    }
    g_link_xchg_mid = NULL;
    LOGI("Link multiplayer stopped");
}
