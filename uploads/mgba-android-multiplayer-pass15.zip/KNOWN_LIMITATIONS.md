# KNOWN_LIMITATIONS — Fifteenth pass

## The honest state of things right now

W re-tested FIX 12 (plus everything since) and reported all three
still-open symptoms at once: ROM detection still failing on both Wi-Fi and
Bluetooth, a Wi-Fi disconnect not reaching the other phone, and lag on
Bluetooth specifically — attaching one logcat capture per transport as
evidence.

Neither logcat capture actually contained any evidence. Both are genuine,
correctly tag-filtered captures — 1994 lines each, effectively 100%
`mGBA-JNI` — but both cover barely 166-241ms of real elapsed time,
entirely boot-time DMA/register-read spam. Nothing from anywhere near an
actual multiplayer attempt survived to be captured. Root cause (this
pass's real finding, detailed in `mgba_jni.c`'s FIX 13 and CHANGELOG.md
item 1): the core's own routine per-frame logging was being forwarded to
the same tag, completely unfiltered, at a volume that reliably wins
against `copyLinkDebugLog()`'s 2000-line window before anything
link-related even gets a chance to appear in it. **This means the
Fourteenth-and-earlier passes' conclusions about FIX 12's effect are still
exactly as uncertain as they were the moment FIX 12 was written** — no
on-device evidence of any kind has actually been collected since then, the
tool collecting it just hasn't been telling anyone.

Two things were done about that: the logging noise is now filtered at the
source (FIX 13), and every disconnect/peer-lost code path now logs
specifically what happened instead of one shared generic line (FIX 15 in
`LinkMultiplayer.kt` — see its own file-header entry). Separately, re-
reading `mgba_jni.c` end to end (with no log evidence to point at anything
narrower) turned up a real design gap: the native exchange trigger was
never actually gated to the host role, despite every FIX 9-12 comment
describing that as the intended design. Closed in FIX 14. Whether it was
ever actually being hit by either test ROM is unknown.

**None of this touches the actual reported bugs.** It's diagnostic
infrastructure and one hardening whose impact is unconfirmed. The honest
summary: after fifteen passes, there is still no on-device evidence, of
any kind, of what happens once a real link attempt begins — every logcat
gathered so far (including the one behind FIX 12's own rawWrite16 finding,
which happened to survive only because it was a tight, easily-captured
repeating pattern) has either shown a narrow slice of one specific
already-fixed bug or, like this pass's two files, nothing at all.

## What would actually move this forward

A real build, installed on both phones, with this specific sequence:

1. Connect over Wi-Fi. Actually navigate **both** ROMs into their in-game
   link/multiplayer menus — not just the app-level "Connected" toast — and
   give it a few seconds.
2. Open `Copy link log` on **both** phones (not just one) right after.
   Whether `"SIO write addr=0x128 ..."` lines appear at all, on both
   devices, with `host=1` on one and `host=0` on the other, is the
   specific thing no capture so far has actually shown. If they appear on
   the `host=0` device *with the Start bit set* (value `& 0x0080` nonzero),
   that's the FIX 14 gap actually being hit — direct confirmation, not
   just plausible theory.
3. With that same session still connected, tap Disconnect on one phone,
   wait 10 seconds (past both the immediate-BYE case and the 8s watchdog
   fallback), then check the other phone's UI state and pull its log too.
   `"Sent BYE"` / `"Peer connection lost: ..."` (now naming which of the 6
   listener sites and why) should make it possible to say exactly where
   propagation stops, if it still does.
4. Repeat 1-3 over Bluetooth, and separately note whether lag is still
   present now that Item 1's per-frame logging tax is gone.

This is the same "next step" every recent pass has named — a real
build and an actual on-device test — but for the first time since FIX 11
was written, the tool meant to report back on it should actually do so.

## Found but not addressed this pass

- The Twelfth-pass entry below (still present, unmoved since) flagged
  suspiciously rapid repeated exchanges — many four-line groups within a
  single 16ms window — as faster than a real transfer should allow, and
  left it for later. FIX 14 is a plausible mechanism for exactly that (a
  child device firing its own spurious exchange back-to-back with the
  network-triggered one answering the real request) but this pass did not
  go back and re-derive the timing math to check whether it actually
  fits — that capture predates FIX 12 by several passes and it's not
  obvious the same log would even reproduce the same way now. Worth
  revisiting once a fresh capture exists.
- Whether `WIFI_XCHG_MS`/`BT_XCHG_MS` (30/50ms) are appropriately sized is
  still unknown either way — no evidence yet distinguishes "timeouts are
  fine, they're just being hit due to a real protocol bug" from "timeouts
  themselves are too aggressive for real Bluetooth RFCOMM latency on
  W's specific phones."
- Everything the Thirteenth pass listed below is still open and still
  applies.

# KNOWN_LIMITATIONS — Thirteenth pass

## The honest state of things right now

The Twelfth pass's fork-in-the-road is answered, and by evidence this time,
not another read-through: a real on-device logcat (filtered to `mGBA-JNI`)
during a live attempt shows hundreds of `"Unimplemented memory Patch16:
0x0400012{0,2,4,6}"` lines, in tight repeating groups of four, the whole
time the ROM sat on its link screen. That line is not this project's own —
it's `GBAPatch16`'s own stub, confirmed this pass directly from
mgba-emu/mgba's real source (`src/gba/core.c`, `src/gba/memory.c`): the GBA
core's `rawWrite16` is a one-line wrapper around `GBAPatch16`, and
`GBAPatch16` has an explicit `GBA_REGION_IO` case that logs this and does
nothing — it never actually writes. Every one of `link_sio_write_register()`
and `nativeLinkChildExchange()`'s four `rawWrite16(..., 0x0400012{0,2,4,6}u,
...)` calls has been silently discarded since FIX 7 introduced them. See
FIX 12 in `mgba_jni.c` for the full citation trail and the fix itself
(writing `g_link_gba->memory.io[]` directly instead, the same array mGBA's
own memory.c uses internally — no rawWrite16, no GBAPatch16, no new include
needed since struct GBA is already complete in this file).

This also finally explains *why* the symptom has looked exactly the way it
has for twelve passes: SIOCNT's status bits (FIX 9) go through this driver's
`writeRegister` return value, a completely different, never-broken path —
so "is the link ready" correctly reads yes, and the SIO IRQ (FIX 10) really
does fire. Only the actual data payload (SIOMULTI0-3) was silently failing
to land, every single time, on both devices, over both transports — which a
ROM checking its handshake data can't tell apart from "transfer reported
success but the bytes are garbage," and which explains "connected at the
app level, ROM never reacts" far better than any single protocol-bit theory
from the Sixth-through-Eleventh passes did.

## What would actually move this forward

The obvious next step, unchanged in kind from every pass before it: a real
build (this sandbox still has no NDK/compiler) installed on both phones,
both ROMs actually navigated into their in-game link/multiplayer mode, and
either game reported as progressing past its wait screen or not. If it
still doesn't progress, the next `Copy link log` capture is what settles
the next question — specifically whether `"SIO write addr=0x128 ..."` lines
now appear *interleaved* with real gameplay (not just the four data-register
lines this pass's fix removes the noise from), which would confirm the
driver is still firing correctly with the noisy no-op path gone.

## Found but not addressed this pass

- The rate of repetition in the captured log (many four-line groups inside
  a single 16ms window) is faster than a GBA Multi-Player transfer's own
  clocked duration (`GBASIOCyclesPerTransfer`) should allow if each group
  corresponds to one completed exchange. Possible explanations not yet
  checked: `link_exchange()` returning near-instantly on a timeout/fast-fail
  path rather than actually blocking for the network round-trip, or a ROM
  busy-polling the Start bit far more aggressively than the interrupt-driven
  assumption FIX 10 was built around. Worth a dedicated look once the FIX 12
  rebuild confirms or rules out the main fix, not before — no sense chasing
  a timing theory on top of a data path that may not even be the last bug.
- Everything the Twelfth pass listed below is still open and still applies
  except the fork-in-the-road question itself, which this pass answers.

# KNOWN_LIMITATIONS — Twelfth pass

## The honest state of things right now

W's retest this pass — app-level link reporting success, only slight
lag, but both ROMs' own in-game link/multiplayer screens still stuck on
their "please wait" message — is exactly the Sixth-through-Ninth-pass
issue, unchanged. This pass re-read `mgba_jni.c`'s SIO driver/dispatch
code and `LinkMultiplayer.kt`'s exchange logic in full and cross-checked
the driver-registration architecture against mGBA's own upstream source
(the pinned-version fork with 3-arg `GBASIOSetDriver` and separate
`drivers.normal`/`.multiplayer`/`.joybus` slots plus one shared
`activeDriver` pointer). Nothing found there contradicts what's already
been fixed, and nothing found there rises to the level of a
confirmed new bug — everything reads as internally consistent on paper.
That's a real limit of this environment, not a clean bill of health: this
sandbox still cannot build, install, or run the app, so "reads correctly"
and "behaves correctly on-device" remain two different claims.

## What actually changed this pass

Not a fix. A "Copy link log" tool was added to the quick game menu (see
`BUGS_FIXED.md`) so the exact evidence the Eighth pass asked for is
finally retrievable without a PC. **Next step, concretely:** start a link
attempt on both phones, get both ROMs onto their "please wait" screen,
open the quick menu → Copy link log on each phone, and send both. Whether
any `"SIO write addr=..."` line shows up at all is still the fork in the
road:

- **None on either phone** → confirms the eighth pass's mode-dispatch
  hypothesis (or something adjacent to it) — the ROM's own writes aren't
  reaching the custom driver at all, which points back at *when*/*how*
  `GBASIOSetDriver()` is called relative to the ROM's own mode-select
  writes, not at the exchange protocol.
- **Present on the host, absent on the child (or vice versa)** → points
  at the per-role wiring (`startWifiChildResponder()` /
  `nativeLinkChildExchange()`) instead of the driver registration itself.
- **Present on both, but exchanges are timing out or returning wrong
  data** → points at the Wi-Fi/Bluetooth transport or packet framing,
  not the SIO layer at all.

## Found but not addressed this pass

- **Some OEM Android builds restrict even an app's own logcat access
  further than stock Android.** If "Copy link log" comes back empty on a
  given phone even after actually reproducing the symptom, that's the
  more likely explanation, not "no matching lines" — the dialog's own
  empty-state text says as much, and `adb logcat` from a PC (if one
  becomes available even temporarily) is the fallback.
- Everything the Ninth pass listed below is still open and still applies
  unchanged; not repeated here.

---

# KNOWN_LIMITATIONS — Ninth pass

## The honest state of things right now

This pass fixed one real, independently-verifiable bug (Wi-Fi host-side
liveness-watchdog starvation — see `BUGS_FIXED.md`) but did **not** touch,
and cannot yet explain, the deeper question the eighth pass's logging was
added for: why the ROM itself never reacts to a completed link, which the
user's Bluetooth retest this pass shows is still happening exactly as
before. Fixing the Wi-Fi disconnect doesn't get closer to answering that —
it just means Wi-Fi can now *stay* connected long enough to ask the same
question Bluetooth already could.

## What would actually move the remaining issue forward

Unchanged from the eighth pass: real logcat, filtered to `mGBA-JNI` (and
ideally `mGBA-Link`/`mGBA`), from an attempt where both phones' ROMs are
actually navigated into their in-game link/multiplayer mode (not just the
app-level "Connected" toast). Specifically whether any `"SIO write
addr=..."` lines appear at all. This pass did not add a new theory about
why they might not — the eighth pass's mode-dispatch hypothesis
(`GBASIOSetDriver()` only registers for `SIO_MULTI`; the core re-picks its
active driver whenever the ROM's own mode bits change) is still the
leading, unconfirmed candidate, and still needs exactly that log output to
settle either way.

## Found but not addressed this pass

- **The Wi-Fi fix's 8-second window is a mitigation, not a guarantee.** If
  a real router/hotspot is dropping device-to-device traffic outright
  (e.g. AP/client isolation — common on public or guest Wi-Fi, uncommon on
  a normal home network or a phone's own mobile hotspot), the app-level
  handshake likely wouldn't succeed at all, so this is unlikely to be what
  was observed — but it's worth ruling out if a future retest still shows
  Wi-Fi dropping, since no code change can fix a network policy silently
  discarding the packets in the first place.
- **`drainHostWifiKeepalives()` uses a 100 ms per-receive timeout while
  draining.** Chosen to be comfortably longer than a same-subnet Wi-Fi
  round-trip but short enough not to noticeably delay the keepalive
  thread's own 2-second cycle even if several packets are queued. Not
  tunable from anywhere else; if a very congested network needs longer,
  this is the one constant to revisit.
- **No build was run, no device/emulator testing.** Same as every pass —
  this sandbox has no Android SDK/NDK, no Kotlin compiler, no way to
  install or run the app. Verified by careful reading, full brace/paren
  balance checking, and tracing `wifiSocketLock`'s three use sites
  (declaration, `wifiExchange()`, `drainHostWifiKeepalives()`) by hand.
  Recommend the normal GitHub Actions build before relying on this.

# KNOWN_LIMITATIONS — Eighth pass

## The honest state of things right now

Seven passes in, still no confirmed working link on real hardware, and
this pass's re-test result (identical symptom on both games, both
transports, after a real fix to a real gap) is a sign that continuing to
find and fix hypothetical protocol bugs by reading code — without ever
seeing what the device actually does — has real diminishing returns from
here. This pass deliberately did not add a fourth speculative fix. It
added trace logging (see `FILE_CHANGES.md`) and stops there.

## What would actually move this forward

Real logcat output from a real attempt, filtered to `mGBA-JNI` (this
project's tag) and ideally also `mGBA-Link`/`mGBA` (the Kotlin-side tags).
Specifically, whether *any* `"SIO write addr=..."` lines appear at all
during an attempt tells us something no amount of further code reading
can: if none appear, the problem is upstream of this driver entirely
(wrong SIO mode selected by the ROM, or the driver never actually got
registered) and the next pass should look there instead of inside
`link_sio_write_register()` again.

## Environment constraints on this pass itself

Same as always — no SDK/NDK/compiler, no way to run either game. Unlike
every previous pass, this one did not lean on either code-reading or an
external reference (GBATEK, real mGBA source) as its main verification
tool, on purpose: both have already been used as far as they productively
go without a real device confirming any of it.

# KNOWN_LIMITATIONS — Seventh pass

## Environment constraints on this pass itself

Identical constraints to every pass before it: no Android SDK/NDK, no
Kotlin/C compiler, no network access to fetch either, so `GBARaiseIRQ`
was never actually called against a real build. What's different this
pass: instead of reasoning from memory about mGBA's internal API (the
approach that produced the FIX 7/8 signature mismatches, later corrected
by real build-log output), this pass fetched and read mGBA's actual
`src/gba/sio.c` from its real source repository and confirmed the exact
call — `GBARaiseIRQ(sio->p, GBA_IRQ_SIO, 0)` — used for exactly this
purpose elsewhere in the same file (Normal-mode SIO, in the core's own
dummy-driver fallback). That's real evidence the call and constant name
are right, not a guess, but it's still not a build log against this
project's exact pinned tag (0.10.3) — see "Found but not fixed" below.

## Found but deliberately not fixed this pass

- **Still no way to confirm this against real hardware or even a CI
  build from inside this sandbox.** The recommendation from every
  previous pass stands: run the real build (GitHub Actions or a local
  Android Studio checkout) before assuming this is done. If
  `GBARaiseIRQ`'s signature has changed since whatever revision the
  fetched `sio.c` reflects, the compiler will say so immediately and
  loudly (wrong argument count/type) — that's a much cheaper failure
  mode than the silent "compiles fine, still doesn't work in-game"
  failure this pass was diagnosing.
- **The child's own SIOCNT still doesn't get ID/Error bits set** — unchanged
  from the sixth pass (see that section below); this pass's fix only
  touches the interrupt controller (IF/IE), not SIOCNT itself, so it
  doesn't need the risky raw-read that finding was blocked on, but it
  also doesn't resolve it.
- **If a game turns out to need the IRQ raised on a more precise cycle
  count than "immediately"** (real Multi-Player transfers take a
  baud-rate-dependent number of cycles — see `GBASIOCyclesPerTransfer` in
  the real `sio.c`, which this project's network-bound transfer already
  can't match exactly since it's paced by a Wi-Fi/Bluetooth round-trip,
  not a shift-register clock) — this could in principle matter for a game
  doing very fine-grained timing assumptions around the interrupt, but no
  such requirement is documented in GBATEK for the interrupt itself (only
  for the data-ready timing), so this wasn't treated as a blocking
  concern.

# KNOWN_LIMITATIONS — Sixth pass

## Environment constraints on this pass itself

Same sandbox constraints as every previous pass: no Android SDK/NDK, no
Kotlin/C compiler, no network access to fetch either — so nothing here was
actually built, and nothing was tested against a real ROM on real
hardware. Verification this pass leaned unusually hard on an external
source, though: the core diagnosis (a child GBA never triggers its own SIO
transfer; SIOCNT bits 2/3/4-5/6 have documented, specific meanings) was
cross-checked against GBATEK — the community-maintained GBA hardware
reference — rather than inferred purely from reading this codebase. That
makes the *protocol* reasoning solid, but it's still no substitute for
actually running two phones against a real link-cable game. Recommend
testing with a game known to have a straightforward multiplayer mode (a
simple homebrew link test, if one is available, is easier to reason about
than a full commercial title's menu logic) before assuming this is
completely done.

## Found but deliberately not fixed this pass

- **The child side's own SIOCNT doesn't get the ID/Error bits (4-6) set
  after a transfer** — only the parent's does. Setting them correctly on
  the child would require reading the register's current value first (to
  preserve whatever mode/baud bits its own ROM wrote) before OR-ing in the
  status bits, and this codebase has no confirmed-working raw-register-read
  call yet (only `rawWrite16`, used elsewhere and presumably CI-validated
  given it's unchanged from earlier passes). Guessing at a `rawRead16`
  signature and being wrong would fail the whole build rather than degrade
  gracefully, so this was left alone. The child's bit 2/3 (parent/child,
  ready) status is still correct — that part happens on the child's own
  initial mode-setup write, which it does still make; it's only the
  post-transfer ID/Error bits that aren't mirrored on that side. If a game
  turns out to specifically check its OWN Error bit or re-derive its role
  from its OWN ID bits (as opposed to bit 2, which is now correct) rather
  than just checking bit 2 once up front, this is where to look first.

- **The fifth pass's Wi-Fi out-of-order-packet guard and SIO-exchange-
  holds-the-core-mutex items are unchanged** — see the fifth-pass section
  below, still accurate.

- Everything else in the fifth-pass list below is unchanged and still
  applies (no build/device testing capability in this sandbox, no
  armeabi-v7a/x86 support, no pinned Gradle wrapper checksum, no automated
  tests).

# KNOWN_LIMITATIONS — Fifth pass

## Environment constraints on this pass itself

- **No build was run.** This sandbox has a JDK but no Android SDK, no NDK,
  no Kotlin compiler, and no network access to fetch any of them — so
  `./gradlew assembleDebug` was never actually invoked here. Every change
  was verified by careful manual reading, full brace/paren-balance
  checking across both edited Kotlin files, and cross-referencing every
  new identifier against its declaration and every use site. That is real
  verification, but it is not the same thing as a green CI build, and it
  cannot catch every class of compiler-level error (e.g. a subtle type
  mismatch). Recommend running the normal GitHub Actions workflow on this
  ZIP before relying on it.
- **No device/emulator testing.** Nothing here was exercised on real or
  virtual hardware. This particularly matters for the multiplayer fixes —
  they were reasoned through against the JVM memory model and the existing
  code's own logic, not observed fixing an actual repro.
- **No network access for supply-chain verification.** See the Gradle
  wrapper checksum item below.

## Found but deliberately not fixed this pass

- **Wi-Fi link protocol: only exact-duplicate packets are discarded, not
  full out-of-order sequences.** `wifiExchange()` now discards a packet
  whose `seq` byte exactly repeats the last one accepted, which covers the
  simplest and most common stale-packet case. It does not implement full
  modular sequence-number correlation (comparing a received packet's `seq`
  against what was actually expected for the current round, with wraparound
  handling). Doing that properly requires deciding how the protocol should
  behave after any packet loss causes the two sides' sequence counters to
  drift — a real design question, not just a bug fix, and not something to
  guess at without a way to test against real network conditions.

- **An SIO exchange holds the native core mutex for its full network
  round-trip.** `link_sio_write_register()` runs synchronously inside
  `runFrame()` (already inside `g_core_mutex`) and calls back into Kotlin's
  `jniExchangeData()`, which does a blocking socket operation (up to 30 ms
  for Wi-Fi, 50 ms for Bluetooth) before returning. In the current
  architecture this is safe (verified: everything in the hot path runs
  sequentially on the same game thread, so there's no self-deadlock, and a
  cross-thread caller like `nativeSaveState`/`nativeDestroy` just waits a
  bounded amount of time for the mutex) but it does mean a game that
  performs SIO transfers very frequently could see its effective frame rate
  capped by the network round-trip time during active multiplayer. Fixing
  this properly would mean redesigning the SIO/network interaction to be
  asynchronous — a substantial change that needs real hardware and
  real-game testing to get right, not something to attempt blind in one
  pass.

- **`WifiManager.getConnectionInfo()`/`.dhcpInfo` remain deprecated but
  in use**, already wrapped in `@Suppress("DEPRECATION")` from an earlier
  pass. A modern replacement exists (`ConnectivityManager` +
  `LinkProperties`, both available since well below this project's
  minSdk 24) but this exact code path has already been root-caused and
  fixed multiple times across prior passes (per `README_SETUP.md`), and a
  rewrite can't be validated against real Wi-Fi hardware in this
  environment. Left as-is rather than risk regressing a working,
  hard-won fix.

- **Gradle wrapper has no pinned `distributionSha256Sum`.** Adding one is
  good supply-chain practice, but doing it correctly requires the real
  published checksum for `gradle-8.6-bin.zip` from Gradle's own
  release-checksums page — this sandbox has no network access to fetch it,
  and a guessed/incorrect value would hard-fail every build. Recommend
  pulling the real value from `https://gradle.org/release-checksums/` and
  adding it directly.

- **No armeabi-v7a/x86/x86_64 ABI support** (arm64-v8a only). Reasonable
  given `minSdk 24` — 32-bit-ARM-only devices are effectively extinct at
  that API level — but noted here for completeness since it wasn't changed
  or re-evaluated this pass.

- **No automated tests exist for the multiplayer fixes made this pass** (or
  for the codebase generally). The fixes were verified by reasoning through
  the JVM memory model and the existing control flow, not by a test that
  could catch a future regression. Adding instrumented/unit test coverage
  for `LinkMultiplayer.kt` would be a reasonable next investment, especially
  given how much of this pass's value was in exactly this file.

## Not revisited this pass (out of scope, not found broken)

`MainActivity.kt`'s touch-handling, control-layout editor, and rendering
code were read but intentionally not modified — nothing broken was found,
and this code implements the exact visual "outline skin" the brief asked
to preserve unchanged. Audio/render pipeline internals were the subject of
two previous dedicated passes and were only re-read here to confirm this
pass's changes don't interact with them, not re-audited from scratch.
