# BUGS_FIXED — Fifteenth pass

This pass fixed one clearly demonstrated bug (item 1 — the evidence is the
two logcat files W attached), one diagnostic gap that made every disconnect
report hard to read (item 2), and applied one hardening whose actual effect
is genuinely unconfirmed (item 3, included here anyway in the interest of
not burying it — see its own honesty note). **None of the three symptoms
reported this pass — ROM detection on either transport, Wi-Fi disconnect
propagation, Bluetooth lag — are confirmed fixed.** See
KNOWN_LIMITATIONS.md.

- **Fixed: the multiplayer debug-log capture tool was capturing nothing
  useful.** `jni_log()` in `mgba_jni.c` forwarded every mGBA core log line,
  at every level, to logcat under the same tag `copyLinkDebugLog()` greps
  — including `"Starting DMA ..."` and `"Read from write-only I/O
  register: ..."` chatter that fires dozens of times per frame for any
  ROM, unrelated to link. Both logs W attached this pass are direct proof:
  2000 lines each, tag-filtered correctly, but covering barely 200ms of
  real time — pure boot noise, nothing from anywhere near an actual
  multiplayer attempt. Fixed by dropping `mLOG_DEBUG`/`mLOG_STUB`/
  `mLOG_GAME_ERROR` at the source (mirrors mGBA's own libretro frontend
  under `NDEBUG`, which this project also builds with), plus a
  belt-and-suspenders check on the two exact message prefixes observed.
  Also bumped the capture window from 2000 to 8000 lines as extra
  headroom. This doesn't fix any of the three reported symptoms by
  itself — it fixes why nothing gathered about them so far has been
  readable.
- **Fixed: disconnect/peer-lost events were logged with no distinguishing
  detail.** `disconnect()`'s BYE send had a silent `catch (_: Exception)
  {}` — no record of whether it sent, was skipped, or failed. Every one of
  `handlePeerLost()`'s 8 call sites logged the exact same generic line
  regardless of which of 6 listener locations fired or why. A captured log
  could not have told "peer's BYE never arrived" apart from "arrived but
  something else consumed it" apart from "neither side ever sent one, the
  8s watchdog just gave up" — three different bugs, all invisible from the
  old logging. Every disconnect/peer-lost path now logs specifically what
  happened. Purely additive; no protocol or timing logic changed.
- **Hardened, not confirmed as a fix: native SIO exchange trigger was not
  gated to the host role.** `link_sio_write_register()`'s exchange branch
  ran on *any* device's own Start-bit SIOCNT write — FIX 9's original
  comment already claimed a child device's write "correctly never" reaches
  it, but nothing enforced that; it depended entirely on the assumption
  that a child ROM's own code never performs that write. Now explicitly
  gated on `g_link_is_host`. If either test ROM's link code doesn't
  actually respect that split (plausible if parent/child share one code
  path), this would have let a child device fire a second, spurious
  exchange alongside the correct network-triggered one, potentially
  stealing the host's real reply out from under it — a mechanism that
  would explain identical ROM-detection failure on both transports plus
  worse Bluetooth lag specifically (longer timeout there). Genuinely don't
  know if this was happening. Cheap and safe regardless: host behavior is
  completely unchanged.

---

# BUGS_FIXED — Fourteenth pass

This pass fixed one real compile error, caught by an actual CI build
against the Thirteenth pass's zip — the first real compiler signal since
the Eleventh pass's menu fix. No multiplayer/link code touched.

- **Fixed: `compileReleaseKotlin` failed — "Val cannot be reassigned" at
  `MainActivity.kt:2272:13`.** `showLinkDebugLogDialog(text: String)`
  had a parameter named `text`, and inside `TextView(this).apply { text =
  shown }` a few lines later, that bare `text` resolved to the outer
  `text: String` parameter (a `val`, hence not reassignable) instead of
  the `TextView`'s own settable `text` property. Every other `.text =`
  assignment elsewhere in this file (`row.text = ...`,
  `(row.getChildAt(1) as TextView).text = ...`) goes through an explicit
  variable reference and was never ambiguous; this was the one spot
  written as a bare identifier inside an `apply` block whose enclosing
  function happened to have a parameter with the exact same name. Fixed
  by renaming the parameter to `logText` — removes the collision
  entirely rather than papering over it with an explicit `this.text =`,
  so there's nothing left for a future pass to trip over here again.

---

# BUGS_FIXED — Twelfth pass

This pass added one diagnostic feature to `MainActivity.kt` only — no
multiplayer/link *logic* touched, and the underlying "ROM never reacts to
a completed link" issue is **not fixed** by this pass. It reproduces
exactly as before (see KNOWN_LIMITATIONS.md).

- **Added: in-app link debug log capture ("Copy link log" in the quick
  game menu).** Every pass since the Sixth agreed real logcat, filtered
  to `mGBA-JNI`/`mGBA-Link`/`mGBA`, is what's actually needed to tell
  apart the two remaining hypotheses for the still-open link issue — but
  no pass had a way to retrieve it, since this sandbox has no device and
  nothing in this project implies an adb/PC workflow exists. A process
  can always read back its *own* logcat output without root or the
  `READ_LOGS` permission (that restriction is specifically about reading
  *other* processes' logs), so this shells out to `logcat -d -t 2000 -v
  threadtime -s mGBA-JNI:* mGBA-Link:* mGBA:*`, copies the result to the
  clipboard, and shows it in a selectable dialog. Not a fix — a way to
  finally get the evidence the last two passes said was the actual
  blocker.

---

# BUGS_FIXED — Eleventh pass

This pass covered only `gameMenuRow()`, the row view for the quick game
menu (⚙ button) added last pass — no multiplayer/link code touched.

- **Fixed: every row in the quick game menu silently did nothing when
  tapped.** `gameMenuRow()` marked each row `isClickable = true;
  isFocusable = true`, which is correct for `settingsRow()` (a manual
  `LinearLayout` child with its own `setOnClickListener`) but wrong here —
  this row is a `ListView` item inside `showGameMenu()`'s `AlertDialog`,
  where clicks are meant to be handled entirely by the `ListView`'s own
  `OnItemClickListener` (the `{ _, which -> ... }` lambda passed to
  `setAdapter()`). Making the row itself clickable/focusable let it
  intercept the touch before the `ListView` could ever dispatch that
  listener — so tapping Load, Save, Fast forward, Cheats, Settings, Link
  remote, Link local, Screenshot, Reset, or Close all produced a ripple
  (the background drawable still animates on touch, since `ListView`
  forwards pressed state to the child under the touch regardless of its
  own clickable flag) but triggered nothing. Fixed by removing the two
  flags from `gameMenuRow()` — the row's tap now correctly falls through
  to the `ListView`, exactly like the old `.setItems()` version (before
  the Tenth pass's restyle) always did.

---

# BUGS_FIXED — Tenth pass

This pass covered the quick game menu (⚙ button), Settings, and window/
immersive setup — no multiplayer/link code touched.

- **Fixed: immersive mode didn't stick.** `setImmersive()` was only ever
  called once, at the end of `onCreate()`. Every `AlertDialog` this app
  opens — the game menu itself, every Settings category, save-state
  prompts — takes window focus away and back, and that silently resets the
  old `systemUiVisibility` flags, so the status/nav bars crept back the
  first time any dialog was shown and dismissed. Fixed by re-applying
  `setImmersive()` from a new `onWindowFocusChanged()` override whenever
  focus is regained, not just at launch.

- **Fixed: black bar in the camera-cutout area.** Nothing in the theme or
  code ever set `layoutInDisplayCutoutMode`, so
  `LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT` applied — which letterboxes
  around the cutout on whichever edge it sits on. Very visible here since
  the app is locked to landscape: the cutout (normally the phone's
  physical top edge, a "short" edge) ends up intruding into the middle of
  the horizontal game view instead of sitting inside a status bar that's
  already hidden. Fixed by setting
  `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES` in `onCreate()` (API 28+,
  guarded — no-op below that).

---

# BUGS_FIXED — Ninth pass

User report this pass separated the two transports for the first time:
Wi-Fi connects, then drops on its own a few seconds later; Bluetooth stays
connected but the ROM still doesn't react (same symptom the eighth pass's
logging is still waiting on real logcat to explain — see
`KNOWN_LIMITATIONS.md`, not touched further this pass).

- **Fixed: the Wi-Fi HOST role's liveness watchdog could fire on a
  perfectly healthy connection.** The sixth pass's watchdog
  (`lastPeerActivityMs`, checked in `startKeepalive()`) only advances when
  something actually calls `dataSocket.receive()`. The child role always
  has that covered — `startWifiChildResponder()` reads continuously from
  the moment it connects. The host role didn't: its only other call to
  `receive()` was inside `wifiExchange()`, which doesn't run until *this
  device's own ROM* starts making real SIO transfers — something that can
  easily take longer than the watchdog's 8-second timeout if both phones
  still need navigating into their ROMs' own link menus after the
  app-level handshake succeeds. Until then, the client's keepalives just
  sat unread in the host's socket buffer, the host's own
  `lastPeerActivityMs` never advanced past connect time, and the same
  watchdog check would deterministically call `handlePeerLost()` — tearing
  down a connection whose peer was never actually gone, and sending it a
  BYE in the process (which is why both sides appeared to drop together).
  Bluetooth was never exposed to this, since `startBtReader()` already
  runs continuously for both roles, not just the child.

  Fixed with a new `drainHostWifiKeepalives()`, called from the host
  branch of the existing keepalive loop, giving the host the same kind of
  always-listening liveness coverage the child role already had. Guarded
  by a new `wifiSocketLock` (shared with `wifiExchange()`, which now also
  holds it for its own send+receive) so the two can never race over the
  same socket — the drain uses `tryLock()` and simply skips its turn if a
  real SIO exchange is already in flight, since that's already proof of
  life on its own.

# BUGS_FIXED — Eighth pass

Nothing fixed this pass — see `KNOWN_LIMITATIONS.md` and `FILE_CHANGES.md`
("Eighth pass") for why: the seventh pass's IRQ fix was real, but user
re-testing showed zero change on either game or transport, which points
further upstream than anything fixable by more protocol guessing from this
sandbox. Added trace logging instead of a fourth speculative fix; next
pass should be grounded in the resulting logcat output rather than more
static-only reasoning.

# BUGS_FIXED — Seventh pass

Root-caused why the sixth pass's (real, correct) SIO protocol fixes still
didn't get either test game — Yu-Gi-Oh! World Championship 2006, The
Legend of Zelda: Four Swords — off their own "waiting for link" screens.

- **Fixed: the SIO IRQ was never raised, so any interrupt-driven ROM
  never woke up to notice a completed transfer.** This was flagged as a
  known gap back at FIX 8 ("this build doesn't automatically raise the
  SIO IRQ the way hardware would") but never acted on, on the assumption
  it would only matter for unusual ROMs. It's the opposite: BIOS
  `IntrWait`/`VBlankIntrWait` — enable the interrupt, then sleep for it —
  is the standard GBA-dev pattern for waiting on *any* interrupt,
  serial included, precisely because busy-polling wastes battery on real
  hardware. A ROM using that pattern would make its one SIOCNT Start-bit
  write, then go to sleep waiting for an interrupt that was never coming
  — indistinguishable, from the player's side, from the link simply not
  working, even though the underlying byte exchange (sixth pass) was
  correct. Fixed by calling `GBARaiseIRQ(gba, GBA_IRQ_SIO, 0)` at the
  point each side (host in `link_sio_write_register()`, child in
  `nativeLinkChildExchange()`) finishes writing that round's data to
  SIOMULTI0-3. Confirmed the exact call against mGBA's real
  `src/gba/sio.c` rather than reasoning from memory — see `FIX 10` in
  `mgba_jni.c` and `KNOWN_LIMITATIONS.md` for the full citation and the
  one remaining caveat (no build-log confirmation yet, same as every
  other change across every pass).

- **Explains, not just fixes:** the user also reported fast-forward
  staying available during an active "Connected" session, unlike real
  mGBA, where it doesn't. That's downstream of the same bug — an
  interrupt-driven ROM stuck asleep isn't re-triggering the Start bit
  every frame, so there's no per-frame blocking network round-trip left
  to throttle fast-forward against. Nothing needed fixing in the
  fast-forward code itself; it was accurately reporting a game that had
  stalled.

# BUGS_FIXED — Sixth pass

This pass root-caused the two symptoms reported after the fifth pass: the
app claims "Connected" but the ROM's own link/multiplayer menu never gets
past "waiting", and a peer disconnecting on one phone was never noticed by
the other. Both were real, deterministic bugs (not flakiness) — confirmed
against GBATEK's documented Multi-Player SIO register semantics, not just
inferred from this codebase.

- **Fixed: a child (non-host) device never actually answered the host's
  link requests.** GBATEK: the Start/Busy bit is "Read Only for Slaves" — a
  GBA child unit never triggers its own SIO transfer, only the parent does.
  Since the exchange logic in `link_sio_write_register()` is keyed off
  *this device's own* Start-bit write, it correctly never fired on a child
  device — meaning a child's `wifiExchange()`/`btExchange()` (the only thing
  that ever answered the host's request packet) was never called. The
  host's every request timed out waiting for a reply nothing was ever going
  to send. This is why it was 100%-reproducible rather than intermittent.
  Fixed with a new native entry point, `nativeLinkChildExchange()`, called
  from a new passive-responder thread on the child side
  (`startWifiChildResponder()` for Wi-Fi; the existing `startBtReader()`
  thread now does the same inline for Bluetooth) the instant a request
  arrives over the network, instead of waiting on a local SIO write that
  hardware-correctly never comes.

- **Fixed: nothing ever set SIOCNT's parent/child or all-ready status
  bits.** GBATEK documents games checking SIOCNT bit 2 (parent/child) and
  bit 3 (all GBAs ready) *before* ever attempting a transfer. Neither bit
  was ever set, so a ROM that checks first could sit on its "waiting for
  link" screen indefinitely — indistinguishable from no cable being
  plugged in — regardless of whether the phones' own network handshake had
  already succeeded. Fixed by reflecting both on every SIOCNT write, not
  only ones with the Start bit set.

- **Fixed: the ID bits and Error bit were never set after a transfer.**
  GBATEK: bits 4-5 (Multi-Player ID) are undefined before the first
  transfer and meaningful after; games use them, alongside bit 2, to tell
  their own role apart. Bit 6 (Error) is meant to flag a round the peer
  didn't answer in time. Neither was ever touched, so even a
  timed-out/failed round looked identical to a real one from the ROM's
  point of view. Now set correctly on the parent's side after every
  transfer.

- **Fixed: a disconnected peer was never detected.** `isConnected` only
  ever went back to `false` via this device's own local `disconnect()`
  call — a dead socket, a force-closed peer app, or Bluetooth going out of
  range all left this side claiming "Connected" forever. Fixed with a BYE
  packet sent best-effort on `disconnect()` (so the peer notices instantly
  in the common case) plus a liveness watchdog checking time-since-last-
  peer-activity inside the existing keepalive loop (fallback for a crash or
  anything else that never gets to send a BYE). `LinkMultiplayer.onPeerLost`
  is the new hook MainActivity uses to reflect this in the UI.

- **Fixed: Bluetooth sessions never ran the keepalive loop at all.**
  `startKeepalive()` was only ever called from the two Wi-Fi connect-success
  paths; `startBluetoothHost()`/`connectBluetooth()` never called it. Beyond
  losing the periodic keepalive traffic, this pass also put the new
  liveness-watchdog check inside that same loop — so without this, a dead
  Bluetooth peer would never have been detected at all. Now called from all
  four connect-success paths.

# BUGS_FIXED — Fifth pass

- **Fixed a cross-thread visibility gap in the multiplayer link state.**
  `dataSocket`/`peerAddr`/`peerDataPort`/`btSocket`/`btIn`/`btOut` were
  written on a setup thread and read on the native game-loop thread without
  `@Volatile`, so a completed connection could go unnoticed by the thread
  that actually exchanges link data.

- **Fixed discovery-socket cleanup on disconnect.** A `discSocket` field
  existed but nothing ever assigned the live socket to it, so
  `disconnect()`'s cleanup call on it was a silent no-op; backing out of a
  host/join screen mid-search waited out a multi-second timeout instead of
  closing immediately.

- **Fixed a non-functional out-of-order-packet guard.** The Wi-Fi packet
  format's `seq` byte was documented as being for stale/out-of-order
  discard but was never actually checked on receive; a late-arriving stale
  reply could be silently accepted as current data.

- **Fixed stale/abandoned multiplayer connection attempts.** Starting a
  second connection attempt while a first was still mid-handshake (the UI
  never blocked this) could let the abandoned attempt's eventual completion
  clobber the newer one's state or fire a callback for an operation the
  user had already backed out of.

- **Fixed an uncancellable in-progress Bluetooth connection attempt.**
  `connectBluetooth()`'s socket was only tracked in a class field *after*
  `connect()` succeeded, so `disconnect()` had nothing to close to actually
  cancel an attempt in progress (which can otherwise block for 10+ seconds).

- **Fixed a ROM-swap/link-state inconsistency.** Loading or changing a ROM
  while linked left the Kotlin-side state and the link button UI claiming
  "Connected" even after the native SIO driver behind the exchange had
  already been silently dropped by the ROM swap.

- **Fixed a post-teardown resource leak in the ROM-load callback.** A slow
  ROM load whose completion callback ran after the user had already backed
  out of the app (and `onDestroy()` had already run) would re-initialize
  `AudioTrack` and start a new game thread/`Choreographer` registration
  with nothing left to ever clean them up.

- **Removed two unused, dangerous-adjacent permissions.**
  `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN` were declared in the
  manifest but never referenced or relied upon anywhere in the code.
