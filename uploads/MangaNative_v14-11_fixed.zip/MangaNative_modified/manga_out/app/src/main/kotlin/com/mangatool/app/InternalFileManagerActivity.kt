package com.mangatool.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.adapter.FileEntry
import com.mangatool.app.adapter.FileManagerAdapter
import java.io.File

/**
 * Built-in file manager for browsing and selecting manga files (MHTML, images).
 *
 * Does NOT use SAF or an external app — navigates the real file system directly,
 * so the user can reach any folder on their device without leaving MIE.
 *
 * Returns selected file URIs via FileProvider so processFiles() can open them
 * with contentResolver.openInputStream() like any other picked file.
 */
class InternalFileManagerActivity : AppCompatActivity() {

    companion object {
        const val RESULT_URIS = "result_uris"

        private val SUPPORTED_EXTS = setOf(
            "mhtml", "mht",
            "jpg", "jpeg", "png", "webp", "gif"
        )

        /** Common starting roots, tried in order — first readable one is used. */
        private val CANDIDATE_ROOTS = listOf(
            Environment.getExternalStorageDirectory(),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            File("/storage/emulated/0"),
            File("/sdcard")
        )
    }

    private lateinit var adapter: FileManagerAdapter
    private lateinit var tvPath: TextView
    private lateinit var tvSelected: TextView
    private lateinit var btnOpen: Button
    private lateinit var tvEmpty: TextView

    /** Stack of visited dirs — enables Back-to-navigate. */
    private val navStack = ArrayDeque<File>()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_manager)

        tvPath     = findViewById(R.id.tvCurrentPath)
        tvSelected = findViewById(R.id.tvSelectedCount)
        btnOpen    = findViewById(R.id.btnOpenSelected)
        tvEmpty    = findViewById(R.id.tvEmpty)

        val btnBack      = findViewById<ImageButton>(R.id.btnFmBack)
        val btnSelectAll = findViewById<Button>(R.id.btnSelectAll)
        val rv           = findViewById<RecyclerView>(R.id.rvFiles)

        adapter = FileManagerAdapter(
            onFolderClick    = { dir -> navigateTo(dir) },
            onSelectionChanged = { sel ->
                val n = sel.size
                tvSelected.text = if (n == 0) "Tap files to select"
                                  else "$n file${if (n == 1) "" else "s"} selected"
                btnOpen.isEnabled = n > 0
            }
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter        = adapter
        rv.setItemViewCacheSize(20)
        rv.overScrollMode = View.OVER_SCROLL_NEVER

        btnBack.setOnClickListener      { handleBack() }
        btnSelectAll.setOnClickListener { adapter.selectAll() }

        btnOpen.setOnClickListener {
            val selected = adapter.getSelected()
            if (selected.isEmpty()) return@setOnClickListener
            val authority = "${packageName}.fileprovider"
            val uriStrings = selected.mapNotNull { file ->
                runCatching { FileProvider.getUriForFile(this, authority, file).toString() }.getOrNull()
            }
            if (uriStrings.isEmpty()) {
                Toast.makeText(this, "Could not access selected files", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            setResult(Activity.RESULT_OK, Intent().apply {
                putStringArrayListExtra(RESULT_URIS, ArrayList(uriStrings))
            })
            finish()
        }

        // Navigate to the first readable root
        val startDir = CANDIDATE_ROOTS.firstOrNull { it.exists() && it.canRead() }
            ?: run {
                Toast.makeText(this, "Cannot access storage", Toast.LENGTH_LONG).show()
                finish()
                return
            }
        navigateTo(startDir)
    }

    @Deprecated("Use handleBack()")
    override fun onBackPressed() { handleBack() }

    // ── Navigation ────────────────────────────────────────────────────────────

    private fun handleBack() {
        if (navStack.size > 1) {
            navStack.removeLast()          // pop current
            val prev = navStack.removeLast() // pop previous (navigateTo will re-push)
            navigateTo(prev)
        } else {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }

    private fun navigateTo(dir: File) {
        if (!dir.canRead()) {
            Toast.makeText(this, "Cannot read: ${dir.name}", Toast.LENGTH_SHORT).show()
            return
        }
        navStack.addLast(dir)

        // ── Path label ────────────────────────────────────────────────────────
        val extRoot = Environment.getExternalStorageDirectory().absolutePath
        val display = dir.absolutePath
            .replace(extRoot, "📱 Internal Storage")
            .replace("/storage/emulated/0", "📱 Internal Storage")
        tvPath.text = display

        // ── Build entry list ──────────────────────────────────────────────────
        val files   = dir.listFiles() ?: emptyArray()
        val entries = mutableListOf<FileEntry>()

        // Parent folder entry (except at root candidates)
        val parent = dir.parentFile
        if (parent != null && parent.canRead() && !CANDIDATE_ROOTS.any { it.canonicalPath == dir.canonicalPath }) {
            entries.add(FileEntry(parent, isParent = true))
        }

        val folders = files
            .filter { it.isDirectory && !it.name.startsWith('.') && it.canRead() }
            .sortedBy { it.name.lowercase() }

        val supportedFiles = files
            .filter { it.isFile && it.extension.lowercase() in SUPPORTED_EXTS }
            .sortedBy { it.name.lowercase() }

        entries.addAll(folders.map { FileEntry(it) })
        entries.addAll(supportedFiles.map { FileEntry(it) })

        adapter.setEntries(entries)

        tvEmpty.visibility    = if (entries.isEmpty()) View.VISIBLE else View.GONE
        btnOpen.isEnabled     = false
        tvSelected.text       = "Tap files to select"
    }
}
