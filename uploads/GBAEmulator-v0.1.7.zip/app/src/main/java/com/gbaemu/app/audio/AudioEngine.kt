package com.gbaemu.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** Streams interleaved 16-bit stereo PCM at the core's fixed 32768 Hz output rate. */
class AudioEngine {
    private var track: AudioTrack? = null
    private val sampleRate = 32768

    fun start() {
        if (track != null) return
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        // Quarter-second of stereo 16-bit PCM, in bytes: rate * 2 channels * 2 bytes.
        val quarterSecondBytes = sampleRate * 4
        // A larger multiple of the platform minimum gives more headroom against
        // underrun-caused crackling if delivery from the emulation thread is
        // ever irregular, at the cost of a bit more audio latency.
        val bufferSize = (minBufferSize * 4).coerceAtLeast(quarterSecondBytes)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
    }

    fun write(samples: ShortArray) {
        if (samples.isEmpty()) return
        track?.write(samples, 0, samples.size, AudioTrack.WRITE_NON_BLOCKING)
    }

    fun stop() {
        track?.apply {
            stop()
            release()
        }
        track = null
    }
}
