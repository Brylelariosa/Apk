package com.gbaemu.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Shown in place of the normal UI right after a crash (see GbaApplication).
 * The text is selectable — long-press to copy the whole trace to send along.
 */
class CrashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = getSharedPreferences("crash_report", MODE_PRIVATE)
            .getString("last_crash", null) ?: "No crash details were recorded."

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CrashScreen(trace) { finish() }
            }
        }
    }
}

@Composable
private fun CrashScreen(trace: String, onDismiss: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("GBA Emulator crashed", color = Color(0xFFFF6666))
        Text("Long-press the text below to select and copy it.", color = Color(0xFFAAAAAA))
        SelectionContainer(modifier = Modifier.weight(1f)) {
            Box(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    trace,
                    color = Color(0xFF66FF66),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
            }
        }
        Button(onClick = onDismiss) { Text("Close") }
    }
}
