package com.gbaemu.app.ui.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

private const val GBA_WIDTH = 240
private const val GBA_HEIGHT = 160
private const val PIXEL_COUNT = GBA_WIDTH * GBA_HEIGHT

/**
 * Renders raw ARGB8888 frames from the core. [submitFrame] is called from
 * the emulation thread and must stay fast and non-blocking -- actual
 * presentation (lockCanvas/drawBitmap/unlockCanvasAndPost, any of which can
 * stall on the compositor) happens on a dedicated render thread instead.
 *
 * [submitFrame]'s array argument is reused by the native layer across
 * calls (see jni_bridge.cpp), so it's copied into an owned buffer
 * synchronously here rather than handed to the render thread by reference
 * -- otherwise a fast emulation thread could overwrite the native array's
 * contents before the render thread finishes reading the old frame from it.
 */
class EmulatorSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    private val bitmap = Bitmap.createBitmap(GBA_WIDTH, GBA_HEIGHT, Bitmap.Config.ARGB_8888)
    private val paint = Paint().apply { isFilterBitmap = false } // nearest-neighbor keeps pixel edges crisp
    private val srcRect = Rect(0, 0, GBA_WIDTH, GBA_HEIGHT)

    @Volatile private var surfaceReady = false
    @Volatile private var running = false
    private var renderThread: Thread? = null

    private val frameBuffer = IntArray(PIXEL_COUNT)
    private val bufferLock = Any()
    private val frameSignal = Semaphore(0)

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        running = true
        renderThread = Thread({
            while (running) {
                if (frameSignal.tryAcquire(100, TimeUnit.MILLISECONDS)) {
                    frameSignal.drainPermits() // coalesce: only the latest frame matters
                    renderFrame()
                }
            }
        }, "EmulatorRenderThread").apply { start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        running = false
        renderThread?.join(200)
        renderThread = null
    }

    /** Fast and non-blocking: copies into an owned buffer and signals the render thread. */
    fun submitFrame(pixels: IntArray) {
        if (pixels.size != PIXEL_COUNT) return
        synchronized(bufferLock) {
            System.arraycopy(pixels, 0, frameBuffer, 0, PIXEL_COUNT)
        }
        frameSignal.release()
    }

    private fun renderFrame() {
        if (!surfaceReady) return
        synchronized(bufferLock) {
            bitmap.setPixels(frameBuffer, 0, GBA_WIDTH, 0, 0, GBA_WIDTH, GBA_HEIGHT)
        }

        val canvas = try {
            holder.lockCanvas()
        } catch (_: Exception) {
            null
        } ?: return

        try {
            val scale = minOf(canvas.width.toFloat() / GBA_WIDTH, canvas.height.toFloat() / GBA_HEIGHT)
            val dstWidth = (GBA_WIDTH * scale).toInt()
            val dstHeight = (GBA_HEIGHT * scale).toInt()
            val left = (canvas.width - dstWidth) / 2
            val top = (canvas.height - dstHeight) / 2
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bitmap, srcRect, Rect(left, top, left + dstWidth, top + dstHeight), paint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }
}
