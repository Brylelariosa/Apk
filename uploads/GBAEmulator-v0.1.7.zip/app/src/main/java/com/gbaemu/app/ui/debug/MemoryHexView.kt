package com.gbaemu.app.ui.debug

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

fun hex(v: Int): String = "0x" + v.toUInt().toString(16).uppercase().padStart(8, '0')

/** Address field + Go button; calls [onGo] with the parsed address (hex, "0x" prefix optional). */
@Composable
fun MemoryAddressBar(addressText: String, onAddressTextChange: (String) -> Unit, onGo: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = addressText,
            onValueChange = onAddressTextChange,
            label = { Text("Address") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            modifier = Modifier.height(56.dp),
        )
        Button(
            onClick = {
                addressText.removePrefix("0x").removePrefix("0X").toLongOrNull(16)?.let { onGo(it.toInt()) }
            },
            modifier = Modifier.padding(start = 8.dp),
        ) { Text("Go") }
    }
}

@Composable
fun MemoryHexView(baseAddr: Int, bytes: ByteArray, modifier: Modifier = Modifier.height(160.dp)) {
    LazyColumn(modifier = modifier) {
        val rows = bytes.size / 16
        items(rows) { row ->
            val offset = row * 16
            val hexPart = (0 until 16).joinToString(" ") { col ->
                if (offset + col < bytes.size) "%02X".format(bytes[offset + col]) else "  "
            }
            val asciiPart = (0 until 16).map { col ->
                if (offset + col < bytes.size) {
                    val b = bytes[offset + col].toInt().toChar()
                    if (b.code in 32..126) b else '.'
                } else {
                    ' '
                }
            }.joinToString("")
            Text(
                "${hex(baseAddr + offset)}  $hexPart  $asciiPart",
                color = Color(0xFFAAAAFF),
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}
