package com.gbaemu.app.ui.debug

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.gbaemu.app.core.EmulatorCore
import kotlinx.coroutines.delay

private val regNames = listOf(
    "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7",
    "R8", "R9", "R10", "R11", "R12", "SP", "LR", "PC",
)

@Composable
fun DebuggerScreen(core: EmulatorCore, paused: Boolean, onClose: () -> Unit) {
    var registers by remember { mutableStateOf(IntArray(17)) }
    var disasm by remember { mutableStateOf(listOf<Pair<Int, String>>()) }
    var breakpoints by remember { mutableStateOf(setOf<Int>()) }
    var memBase by remember { mutableStateOf(0x08000000) }
    var memBaseText by remember { mutableStateOf(hex(0x08000000)) }
    var memory by remember { mutableStateOf(ByteArray(0)) }

    fun refresh() {
        val regs = core.debugGetRegisters()
        val thumb = (regs[16] and (1 shl 5)) != 0
        val step = if (thumb) 2 else 4
        val pc = regs[15]
        val lines = core.debugDisassemble(pc, 14)
        registers = regs
        disasm = lines.mapIndexed { i, text -> (pc + i * step) to text }
        breakpoints = core.debugGetBreakpoints().toSet()
        memory = core.debugReadMemory(memBase, 128)
    }

    LaunchedEffect(paused) {
        while (true) {
            refresh()
            if (!paused) delay(200) else delay(80)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE0B0B14)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(onClick = { if (paused) core.debugResume() else core.debugPause() }) {
                    Text(if (paused) "Resume" else "Pause")
                }
                Button(onClick = { core.debugStep(); refresh() }, enabled = paused) { Text("Step") }
                Button(onClick = onClose) { Text("Close") }
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))

            Text("Registers", color = Color.White)
            RegisterGrid(registers)

            HorizontalDivider(Modifier.padding(vertical = 8.dp))

            Text("Disassembly (tap a line to toggle a breakpoint)", color = Color.White)
            LazyColumn(modifier = Modifier.height(260.dp)) {
                items(disasm) { (addr, text) ->
                    val isPc = addr == registers[15]
                    val hasBp = breakpoints.contains(addr)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isPc) Color(0x552255FF) else Color.Transparent)
                            .clickable {
                                if (hasBp) core.debugRemoveBreakpoint(addr) else core.debugAddBreakpoint(addr)
                                refresh()
                            }
                            .padding(vertical = 2.dp),
                    ) {
                        Text(
                            if (hasBp) "\u25CF" else " ",
                            color = Color(0xFFFF5555),
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 4.dp),
                        )
                        Text(
                            "${hex(addr)}  $text",
                            color = if (isPc) Color(0xFFFFD166) else Color(0xFFCCCCCC),
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))

            Text("Memory", color = Color.White)
            MemoryAddressBar(
                addressText = memBaseText,
                onAddressTextChange = { memBaseText = it },
                onGo = { addr -> memBase = addr; refresh() },
            )
            MemoryHexView(memBase, memory)
        }
    }
}

@Composable
private fun RegisterGrid(registers: IntArray) {
    Column {
        for (row in 0 until 4) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (col in 0 until 4) {
                    val i = row * 4 + col
                    Text(
                        "${regNames[i]}=${hex(registers[i])}",
                        color = Color(0xFF9FE3A0),
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(2.dp),
                    )
                }
            }
        }
        val cpsr = registers[16]
        val flags = buildString {
            append(if ((cpsr shr 31) and 1 == 1) "N" else "-")
            append(if ((cpsr shr 30) and 1 == 1) "Z" else "-")
            append(if ((cpsr shr 29) and 1 == 1) "C" else "-")
            append(if ((cpsr shr 28) and 1 == 1) "V" else "-")
            append("  ")
            append(if ((cpsr shr 5) and 1 == 1) "THUMB" else "ARM")
        }
        Text("CPSR=${hex(cpsr)}  [$flags]", color = Color(0xFF9FE3A0), fontFamily = FontFamily.Monospace)
    }
}
