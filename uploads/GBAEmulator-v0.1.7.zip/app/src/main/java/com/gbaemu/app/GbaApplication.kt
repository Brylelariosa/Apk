package com.gbaemu.app

import android.app.Application
import android.content.Intent
import android.os.Process
import android.util.Log
import kotlin.system.exitProcess

/**
 * With no logcat access available, an instant, silent crash is undiagnosable.
 * This replaces the default "app just disappears" behavior with an on-screen
 * stack trace, so the failure is visible without adb, a computer, or root —
 * screenshot or copy what [CrashActivity] shows and that's the real answer.
 */
class GbaApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val trace = Log.getStackTraceString(throwable)
                Log.e("GbaCrash", "Uncaught exception on ${thread.name}:\n$trace")
                getSharedPreferences("crash_report", MODE_PRIVATE)
                    .edit()
                    .putString("last_crash", trace)
                    .commit() // synchronous on purpose — the process may die right after this line

                startActivity(
                    Intent(this, CrashActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
                )
            } catch (_: Throwable) {
                // If the handler itself fails, there's nothing more we can do here.
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }
}
