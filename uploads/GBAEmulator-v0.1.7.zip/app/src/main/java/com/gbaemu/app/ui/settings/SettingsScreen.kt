package com.gbaemu.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Placeholder — intentionally empty for now, just the entry point and a way back out. */
@Composable
fun SettingsScreen(onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xEE0B0B14))) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Button(onClick = onClose) { Text("Close") }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Settings", color = Color.White)
        }
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Nothing here yet.", color = Color(0xFF888888))
        }
    }
}
