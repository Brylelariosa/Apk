package com.gbaemu.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gbaemu.app.ui.game.GameActivity
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                RomLibraryScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomLibraryScreen() {
    val context = LocalContext.current
    val romsDir = remember { File(context.filesDir, "roms").apply { mkdirs() } }
    var roms by remember { mutableStateOf(romsDir.listFiles()?.toList().orEmpty()) }
    val versionName = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        } catch (_: Exception) {
            null
        }
    }

    val pickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importRom(context, uri, romsDir)
            roms = romsDir.listFiles()?.toList().orEmpty()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("GBA Emulator" + (versionName?.let { " v$it" } ?: "")) })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { pickerLauncher.launch(arrayOf("*/*")) }) {
                Text("+")
            }
        },
    ) { padding ->
        if (roms.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No ROMs yet \u2014 tap + to add one.")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
                items(roms) { file ->
                    ListItem(
                        headlineContent = { Text(file.name) },
                        trailingContent = {
                            Text(
                                "\u2715",
                                modifier = Modifier
                                    .clickable {
                                        file.delete()
                                        roms = romsDir.listFiles()?.toList().orEmpty()
                                    }
                                    .padding(8.dp),
                            )
                        },
                        modifier = Modifier.clickable {
                            context.startActivity(
                                Intent(context, GameActivity::class.java)
                                    .putExtra(GameActivity.EXTRA_ROM_PATH, file.absolutePath),
                            )
                        },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

private val romExtensions = listOf(".gba", ".agb", ".bin")

private fun importRom(context: Context, uri: Uri, romsDir: File) {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
    val displayName = queryDisplayName(context, uri) ?: "rom_${System.currentTimeMillis()}.gba"

    // ZIP local-file-header magic: 'P' 'K' 0x03 0x04 — GBA ROMs are very often
    // shared zipped, and loading the archive's raw bytes as if they were the
    // ROM produces exactly this: garbage CPU execution from byte 0.
    val isZip = bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() &&
        bytes[2] == 0x03.toByte() && bytes[3] == 0x04.toByte()

    if (isZip) {
        val extracted = extractRomFromZip(bytes, romsDir)
        if (extracted != null) return
        // No recognizable ROM extension found inside — save the zip itself
        // so it's at least visible rather than silently doing nothing.
        File(romsDir, displayName).writeBytes(bytes)
    } else {
        val name = if (romExtensions.any { displayName.endsWith(it, ignoreCase = true) }) displayName else "$displayName.gba"
        File(romsDir, name).writeBytes(bytes)
    }
}

/** Returns the saved File if a ROM was found and extracted, null otherwise. */
private fun extractRomFromZip(zipBytes: ByteArray, romsDir: File): File? {
    ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
        var entry = zis.nextEntry
        while (entry != null) {
            val entryName = entry.name
            if (!entry.isDirectory && romExtensions.any { entryName.endsWith(it, ignoreCase = true) }) {
                val outFile = File(romsDir, File(entryName).name) // strip any folder path inside the zip
                outFile.outputStream().use { out -> zis.copyTo(out) }
                return outFile
            }
            entry = zis.nextEntry
        }
    }
    return null
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
    }
    return null
}
