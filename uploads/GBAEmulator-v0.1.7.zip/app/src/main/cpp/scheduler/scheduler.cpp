#include "scheduler.h"

namespace gba {

void Scheduler::Init() {
    Reset();
}

void Scheduler::Reset() {
    now_ = 0;
    nextEventTime_ = std::numeric_limits<u64>::max();
    for (auto& e : entries_) {
        e.timestamp = 0;
        e.active = false;
    }
}

void Scheduler::Schedule(EventType type, u64 cyclesFromNow) {
    auto& e = entries_[static_cast<size_t>(type)];
    e.timestamp = now_ + cyclesFromNow;
    e.type = type;
    e.active = true;
    if (e.timestamp < nextEventTime_) nextEventTime_ = e.timestamp;
}

void Scheduler::Cancel(EventType type) {
    // Not recomputing nextEventTime_ here on purpose: if this happened to be
    // the entry backing the cached value, the cache is left pointing a
    // little early. Tick() below then does one harmless extra full scan
    // (finds nothing due, recomputes correctly) rather than this doing a
    // scan on every single cancel -- cancels are rare compared to ticks.
    entries_[static_cast<size_t>(type)].active = false;
}

bool Scheduler::IsScheduled(EventType type) const {
    return entries_[static_cast<size_t>(type)].active;
}

u64 Scheduler::CyclesUntilNextEvent() const {
    return (nextEventTime_ > now_) ? (nextEventTime_ - now_) : 0;
}

void Scheduler::Tick(u64 cycles) {
    now_ += cycles;

    // Fast path: this runs once per emulated CPU instruction -- millions of
    // times per second -- and the overwhelming majority of those calls have
    // nothing due yet. Skip the array scan entirely for those.
    if (now_ < nextEventTime_) return;

    // Fire everything that's now due. A handler is allowed to reschedule its
    // own event (that's how periodic events like HBlank/VBlank re-arm
    // themselves), so we loop until nothing is due rather than doing one pass
    // -- that also naturally handles a handler firing more than once if the
    // caller ticked by a large number of cycles in one go.
    bool firedAny = true;
    while (firedAny) {
        firedAny = false;
        for (size_t i = 0; i < entries_.size(); ++i) {
            Entry& e = entries_[i];
            if (e.active && e.timestamp <= now_) {
                e.active = false;
                u64 lateBy = now_ - e.timestamp;
                if (handlers_[i]) {
                    handlers_[i](lateBy);
                }
                firedAny = true;
            }
        }
    }

    // Recompute the cache from whatever's still active (handlers above may
    // have rescheduled themselves or each other via Schedule(), which keeps
    // the cache updated incrementally, but a cancellation without a matching
    // reschedule needs this full recompute to shrink back down correctly).
    nextEventTime_ = std::numeric_limits<u64>::max();
    for (const auto& e : entries_) {
        if (e.active && e.timestamp < nextEventTime_) nextEventTime_ = e.timestamp;
    }
}

} // namespace gba
