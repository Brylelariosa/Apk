// Top-level build file. Plugin versions live here; modules apply them without versions.
//
// Version matrix (kept in sync with the CI workflow, which pins Gradle 8.6 + JDK 17):
//   AGP 8.4.2  -> needs Gradle >= 8.6, JDK 17
//   Kotlin 2.0.21 -> supports Gradle 6.8.3 .. 8.8
plugins {
    id("com.android.application") version "8.4.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.jvm") version "2.0.21" apply false
}
