# HexManiac for Android

Android remake of HexManiacAdvance (GBA ROM hex / table editor).
Built by the GitHub Actions "Build APK" workflow: zip this folder, push it to `uploads/`, download the APK artifact.

## What works (step 1)

- Open a ROM through the system file picker (`.gba`, any size up to 64 MB), save in place or "Save as".
- Hex dump with address column, pointer highlighting, optional text column in the game's character set (PCS).
- Tap = select a byte, double-tap = follow a pointer, long-press = edit the selected bytes; −1 / +1 / Word resize the selection.
- Go to (offset or `08xxxxxx` pointer), Find (hex with `??` wildcards, or `"text"` in the game's character set), Find next.
- Undo / redo with labelled steps, unsaved-changes guard, automatic backups of opened ROMs (last four, app-private storage).
- IPS and UPS patches: apply (UPS also removes), create against an original ROM.
- ROM info: title, game code, language/version, size, CRC-32.

## Layout

```
core/   pure Kotlin/JVM engine, no Android classes, unit tested (./gradlew :core:test)
  rom/    RomData, RomDocument (undo/redo), header + game detection, search, hex text, RomInfo
  text/   PCS text codec (decoder, encoder, reference parser, macros)
  patch/  IPS, UPS, CRC-32, Patches facade
  io/     ResourceSource (class-path access to the data files in src/main/resources/hma)
app/    thin Android shell: MainActivity (wiring), HexView (canvas hex dump), Dialogs, RomFiles (SAF I/O)
```

Rules that keep the engine portable: `core` uses only Java 8 library APIs (it runs on Android API 24+), never touches
`android.*`, and reads its data files through `ResourceSource`. The app only draws and forwards input.

## Build matrix

Gradle 8.6, AGP 8.4.2, Kotlin 2.0.21, JDK 17, compileSdk/targetSdk 34, minSdk 24.

## Next steps

Table and anchor model (tableReference / metadata TOML), table browser and editor, text repointing, LZ77 sprites and
palettes, script viewer.
