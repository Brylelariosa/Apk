package dev.hexmaniac.core.rom

import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchQueryTest {
    private val pcs = PcsTable.DEFAULT

    private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

    @Test
    fun hexQueryWithWildcards() {
        val pattern = SearchQuery.parse("0A ?? FF", pcs, "")
        assertNotNull(pattern)
        assertEquals(3, pattern!!.length)
        assertTrue(pattern.matchesAt(bytes(0, 0x0A, 0x55, 0xFF), 1))
        assertFalse(pattern.matchesAt(bytes(0, 0x0A, 0x55, 0xFE), 1))
    }

    @Test
    fun blankOrInvalidQueriesGiveNoPattern() {
        assertNull(SearchQuery.parse("", pcs, ""))
        assertNull(SearchQuery.parse("   ", pcs, ""))
        assertNull(SearchQuery.parse("hello world", pcs, ""))
    }

    @Test
    fun closedTextIncludesTheTerminator() {
        val closed = SearchQuery.parse("\"AB\"", pcs, "BPRE0")
        val open = SearchQuery.parse("\"AB", pcs, "BPRE0")
        assertNotNull(closed)
        assertNotNull(open)
        assertEquals(open!!.length + 1, closed!!.length)
        assertEquals(0xFF, closed.valueAt(closed.length - 1))
    }

    @Test
    fun openTextMatchesAsAPrefix() {
        val open = SearchQuery.parse("\"AB", pcs, "BPRE0")!!
        val encoded = pcs.encode("\"ABC\"", "BPRE0").bytes
        assertTrue(open.matchesAt(encoded, 0))
        assertFalse(open.matchesAt(bytes(0xBB, 0xBD, 0xBE), 0))
    }

    @Test
    fun foundInsideARom() {
        val rom = ByteArray(64)
        val text = pcs.encode("\"ABC\"", "BPRE0").bytes
        text.copyInto(rom, 20)
        val pattern = SearchQuery.parse("\"ABC\"", pcs, "BPRE0")!!
        assertEquals(20, RomSearch.findWrapping(rom, pattern, 0))
    }
}
