package dev.hexmaniac.core.rom

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RomDocumentTest {
    private fun doc(size: Int = 64) = RomDocument("test.gba", ByteArray(size) { it.toByte() })

    @Test
    fun writeUndoRedo() {
        val d = doc()
        d.write(4, byteArrayOf(0x11, 0x22))
        assertEquals(0x11, d.rom[4])
        assertEquals(0x22, d.rom[5])
        assertTrue(d.undo())
        assertEquals(4, d.rom[4])
        assertEquals(5, d.rom[5])
        assertTrue(d.redo())
        assertEquals(0x11, d.rom[4])
        assertFalse(d.redo())
    }

    @Test
    fun dirtyFlagFollowsSavePoint() {
        val d = doc()
        assertFalse(d.isDirty)
        d.writeByte(0, 0xAA)
        assertTrue(d.isDirty)
        d.markSaved()
        assertFalse(d.isDirty)
        d.undo()
        assertTrue(d.isDirty)
        d.redo()
        assertFalse(d.isDirty)
        d.undo()
        d.writeByte(1, 0xBB) // a new edit replaces the redo branch
        assertTrue(d.isDirty)
    }

    @Test
    fun groupedEditIsOneUndoStep() {
        val d = doc()
        d.edit("two writes") {
            d.writeByte(0, 0xA0)
            d.writeByte(10, 0xB0)
        }
        assertEquals("two writes", d.undoLabel)
        d.undo()
        assertEquals(0, d.rom[0])
        assertEquals(10, d.rom[10])
        assertFalse(d.canUndo)
    }

    @Test
    fun identicalWriteRecordsNothing() {
        val d = doc()
        d.writeByte(3, 3)
        assertFalse(d.canUndo)
        assertFalse(d.isDirty)
    }

    @Test
    fun resizeShrinkAndGrowAreUndoable() {
        val d = doc(32)
        d.resize(16)
        assertEquals(16, d.rom.size)
        d.resize(40)
        assertEquals(40, d.rom.size)
        assertEquals(0, d.rom[39])
        d.undo()
        assertEquals(16, d.rom.size)
        d.undo()
        assertEquals(32, d.rom.size)
        assertEquals(31, d.rom[31]) // bytes cut off by the shrink came back
    }

    @Test
    fun replaceAllRecordsOnlyDifferences() {
        val d = doc(100)
        val original = d.rom.bytes.copyOf()
        val target = original.copyOf(120)
        target[3] = 0x7F
        target[80] = 0x7E
        target[110] = 0x55
        d.replaceAll(target, "patch")
        assertArrayEquals(target, d.rom.bytes)
        assertEquals("patch", d.undoLabel)
        d.undo()
        assertArrayEquals(original, d.rom.bytes)
        assertFalse(d.canUndo)
        d.redo()
        assertArrayEquals(target, d.rom.bytes)
        val shorter = target.copyOf(50)
        d.replaceAll(shorter, "shrink")
        assertArrayEquals(shorter, d.rom.bytes)
        d.undo()
        assertArrayEquals(target, d.rom.bytes)
    }

    @Test(expected = IllegalArgumentException::class)
    fun writeOutsideRomIsRejected() {
        doc(8).write(6, ByteArray(4))
    }

    @Test
    fun listenersAreNotified() {
        val d = doc()
        var calls = 0
        d.addListener { calls++ }
        d.writeByte(0, 9)
        d.undo()
        d.redo()
        assertEquals(3, calls)
    }

    @Test
    fun readsOutsideTheImageAreZero() {
        val d = doc(4)
        assertEquals(0, d.rom[-1])
        assertEquals(0, d.rom[4])
        assertEquals(0x03020100, d.rom.readWord(0))
        assertEquals(0x0100, d.rom.readShort(0))
    }
}
