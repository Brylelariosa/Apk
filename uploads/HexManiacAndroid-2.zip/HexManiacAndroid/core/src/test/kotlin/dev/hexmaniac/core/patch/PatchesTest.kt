package dev.hexmaniac.core.patch

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Random

class PatchesTest {
    private fun randomBytes(size: Int, seed: Long): ByteArray = ByteArray(size).also { Random(seed).nextBytes(it) }

    private fun edited(original: ByteArray): ByteArray {
        val copy = original.copyOf()
        copy[10] = (copy[10] + 1).toByte()
        copy[500] = (copy[500] + 1).toByte()
        return copy
    }

    private fun ascii(text: String): ByteArray = text.toByteArray(Charsets.US_ASCII)

    @Test
    fun detectsTheFormatFromTheHeader() {
        assertEquals(PatchFormat.Ips, Patches.detect(ascii("PATCHEOF")))
        assertEquals(PatchFormat.Ups, Patches.detect(ascii("UPS1")))
        assertNull(Patches.detect(ascii("PATC")))
        assertNull(Patches.detect(ascii("BPS1")))
        assertNull(Patches.detect(ByteArray(0)))
    }

    @Test
    fun ipsRoundTripThroughTheFacade() {
        val original = randomBytes(1000, 1)
        val changed = edited(original)
        val patch = Patches.build(PatchFormat.Ips, original, changed)
        val outcome = Patches.apply(original, patch)
        assertArrayEquals(changed, outcome.data)
        assertEquals("IPS patch applied", outcome.message)
    }

    @Test
    fun upsWorksForwardAndBackward() {
        val original = randomBytes(1000, 2)
        val changed = edited(original)
        val patch = Patches.build(PatchFormat.Ups, original, changed)

        val forward = Patches.apply(original, patch)
        assertArrayEquals(changed, forward.data)
        assertEquals("UPS patch applied", forward.message)

        val backward = Patches.apply(changed, patch)
        assertArrayEquals(original, backward.data)
        assertEquals("UPS patch removed", backward.message)
    }

    @Test
    fun upsRefusesTheWrongRom() {
        val original = randomBytes(1000, 3)
        val patch = Patches.build(PatchFormat.Ups, original, edited(original))
        try {
            Patches.apply(randomBytes(1000, 4), patch)
            fail("a patch for another ROM must not apply")
        } catch (e: PatchException) {
            assertTrue(e.message!!.isNotEmpty())
        }
    }

    @Test
    fun rejectsUnsupportedFiles() {
        try {
            Patches.apply(randomBytes(100, 5), ascii("not a patch"))
            fail("unknown formats must be rejected")
        } catch (e: PatchException) {
            assertTrue(e.message!!.contains("Unsupported"))
        }
    }

    @Test
    fun formatsKnowTheirFileExtension() {
        assertEquals("ips", PatchFormat.Ips.extension)
        assertEquals("ups", PatchFormat.Ups.extension)
    }
}
