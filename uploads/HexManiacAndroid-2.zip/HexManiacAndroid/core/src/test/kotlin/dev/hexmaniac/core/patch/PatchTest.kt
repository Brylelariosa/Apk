package dev.hexmaniac.core.patch

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Random

class PatchTest {
    private fun randomBytes(size: Int, seed: Long): ByteArray = ByteArray(size).also { Random(seed).nextBytes(it) }

    private fun modified(source: ByteArray, extra: Int = 0): ByteArray {
        val dest = source.copyOf(source.size + extra)
        dest[0] = (dest[0] + 1).toByte()
        for (i in 100 until 200) dest[i] = 0x42 // a run of identical bytes becomes an RLE hunk
        for (i in 1000 until 1007) dest[i] = (i and 0x7F).toByte()
        for (i in source.size until dest.size) dest[i] = (i * 7).toByte()
        return dest
    }

    @Test
    fun ipsRoundTrip() {
        val source = randomBytes(5000, 1)
        for (extra in listOf(0, 300)) {
            val dest = modified(source, extra)
            val patch = Ips.build(source, dest)
            val result = Ips.apply(source, patch)
            assertArrayEquals(dest, result.data)
            assertEquals(0, result.firstOffset)
        }
    }

    @Test
    fun ipsUsesRleForLongRuns() {
        val source = ByteArray(300)
        val dest = ByteArray(300)
        for (i in 10 until 110) dest[i] = 0x33
        val patch = Ips.build(source, dest)
        // PATCH + offset(3) + 0,0 + count(2) + value(1) + EOF
        assertEquals(5 + 3 + 2 + 2 + 1 + 3, patch.size)
        assertArrayEquals(dest, Ips.apply(source, patch).data)
    }

    @Test
    fun ipsSplitsHugeChanges() {
        val source = ByteArray(200_000)
        val dest = randomBytes(200_000, 2)
        val patch = Ips.build(source, dest)
        assertArrayEquals(dest, Ips.apply(source, patch).data)
    }

    @Test
    fun ipsToleratesTruncatedPatches() {
        val source = randomBytes(2000, 3)
        val dest = modified(source)
        val patch = Ips.build(source, dest)
        val truncated = patch.copyOf(patch.size - 10)
        val result = Ips.apply(source, truncated) // must not throw
        assertEquals(source.size, result.data.size)
    }

    @Test(expected = PatchException::class)
    fun ipsRejectsOtherFormats() {
        Ips.apply(ByteArray(10), "NOTAPATCHATALL".toByteArray())
    }

    @Test(expected = PatchException::class)
    fun ipsRefusesFilesAbove16Mb() {
        Ips.build(ByteArray(10), ByteArray(0x1000001))
    }

    @Test
    fun variableWidthIntegersRoundTrip() {
        for (value in listOf(0, 1, 0x7F, 0x80, 0x3FFF, 0x4000, 0xFFFFF, 0x1234567)) {
            val out = ByteArrayOutputStream()
            Ups.writeVwi(out, value)
            val bytes = out.toByteArray()
            val (read, next) = Ups.readVwiAt(bytes, 0)
            assertEquals(value, read)
            assertEquals(bytes.size, next)
        }
    }

    @Test
    fun upsForwardAndReverse() {
        val source = randomBytes(4000, 4)
        val dest = modified(source)
        val patch = Ups.build(source, dest)
        val forward = Ups.apply(source, patch) as UpsResult.Success
        assertArrayEquals(dest, forward.data)
        assertEquals(UpsDirection.SourceToDestination, forward.direction)
        val back = Ups.apply(dest, patch) as UpsResult.Success
        assertArrayEquals(source, back.data)
        assertEquals(UpsDirection.DestinationToSource, back.direction)
    }

    @Test
    fun upsWithGrowth() {
        val source = randomBytes(3000, 5)
        val dest = modified(source, 500)
        val patch = Ups.build(source, dest)
        assertArrayEquals(dest, (Ups.apply(source, patch) as UpsResult.Success).data)
        assertArrayEquals(source, (Ups.apply(dest, patch) as UpsResult.Success).data)
    }

    @Test
    fun upsFailureCodes() {
        val source = randomBytes(3000, 6)
        val dest = modified(source)
        val patch = Ups.build(source, dest)

        assertEquals(-1, (Ups.apply(source, "UPS2".toByteArray() + ByteArray(30)) as UpsResult.Failure).code)
        assertEquals(-2, (Ups.apply(randomBytes(3000, 99), patch) as UpsResult.Failure).code)

        val damaged = patch.copyOf()
        damaged[damaged.size / 2] = (damaged[damaged.size / 2] + 1).toByte()
        assertEquals(-3, (Ups.apply(source, damaged) as UpsResult.Failure).code)
        assertTrue((Ups.apply(randomBytes(3000, 99), patch, ignoreChecksums = true)) is UpsResult.Success)
    }

    @Test
    fun crc32MatchesKnownValue() {
        // CRC-32 of "123456789" is 0xCBF43926
        assertEquals(0xCBF43926.toInt(), Crc32.compute("123456789".toByteArray()))
    }
}
