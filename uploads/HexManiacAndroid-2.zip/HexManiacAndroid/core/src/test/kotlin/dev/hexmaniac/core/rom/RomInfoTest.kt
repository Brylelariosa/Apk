package dev.hexmaniac.core.rom

import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RomInfoTest {
    private fun ascii(rom: ByteArray, offset: Int, text: String) {
        for (i in text.indices) rom[offset + i] = text[i].code.toByte()
    }

    private fun fireRed(): RomDocument {
        val rom = ByteArray(0x200)
        ascii(rom, 0xA0, "POKEMON FIRE")
        ascii(rom, 0xAC, "BPRE")
        ascii(rom, 0xB0, "01")
        return RomDocument("fire.gba", rom)
    }

    @Test
    fun summaryHasThreeLines() {
        val doc = fireRed()
        val lines = RomInfo.cursorSummary(doc, "fire.gba", 0, PcsTable.DEFAULT).split('\n')
        assertEquals(3, lines.size)
        assertEquals("fire.gba  FireRed (English) v0", lines[0])
        assertTrue(lines[1].startsWith("@000000  u8 00  u16 0000  u32 00000000"))
    }

    @Test
    fun summaryMarksUnsavedChangesAndPointers() {
        val doc = fireRed()
        doc.write(0x100, byteArrayOf(0xF0.toByte(), 0x01, 0x00, 0x08), "pointer")
        val lines = RomInfo.cursorSummary(doc, "fire.gba", 0x100, PcsTable.DEFAULT).split('\n')
        assertTrue(lines[0].startsWith("● "))
        assertTrue(lines[1].contains("u32 080001F0"))
        assertTrue(lines[1].endsWith("→ 0001F0"))
    }

    @Test
    fun unknownGamesAreNamedAsSuch() {
        val doc = RomDocument("blank.gba", ByteArray(0x200))
        val first = RomInfo.cursorSummary(doc, "blank.gba", 0, PcsTable.DEFAULT).substringBefore('\n')
        assertEquals("blank.gba  unknown game", first)
    }

    @Test
    fun detailsListTheHeaderFields() {
        val doc = fireRed()
        val details = RomInfo.details(doc, "fire.gba")
        assertTrue(details.contains("File: fire.gba"))
        assertTrue(details.contains("Size: 512 bytes (0 KB)"))
        assertTrue(details.contains("Title: POKEMON FIRE"))
        assertTrue(details.contains("Game code: BPRE0"))
        assertTrue(details.contains("Maker: 01"))
        assertTrue(details.contains("CRC-32: "))
        assertTrue(details.endsWith("Unsaved changes: no"))
        doc.writeByte(0x10, 1, "edit")
        assertTrue(RomInfo.details(doc, "fire.gba").endsWith("Unsaved changes: yes"))
        assertFalse(RomInfo.details(doc, "fire.gba").contains("unknown"))
    }
}
