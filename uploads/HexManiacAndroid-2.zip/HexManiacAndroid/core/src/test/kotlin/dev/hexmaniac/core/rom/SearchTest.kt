package dev.hexmaniac.core.rom

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchTest {
    @Test
    fun parseBytesAcceptsCommonSyntax() {
        assertArrayEquals(byteArrayOf(0x0A, 0x1B, 0xFF.toByte()), HexText.parseBytes("0A 1b ff"))
        assertArrayEquals(byteArrayOf(0x0A, 0x1B), HexText.parseBytes("0x0A,0x1B"))
        assertArrayEquals(byteArrayOf(0x0A, 0x1B), HexText.parseBytes("0A1B"))
        assertNull(HexText.parseBytes("0"))
        assertNull(HexText.parseBytes("GG"))
        assertNull(HexText.parseBytes("  "))
    }

    @Test
    fun parseAddressHandlesPointers() {
        assertEquals(0x123456, HexText.parseAddress("123456"))
        assertEquals(0x123456, HexText.parseAddress("0x08123456"))
        assertEquals(255, HexText.parseAddress("\$FF"))
        assertNull(HexText.parseAddress("ZZ"))
        assertNull(HexText.parseAddress("123456789"))
    }

    @Test
    fun formatAndHex() {
        assertEquals("0A 0B FF", HexText.format(byteArrayOf(10, 11, -1), 0, 3))
        assertEquals("00001F", HexText.hex(0x1F, 6))
    }

    @Test
    fun wildcardSearch() {
        val data = byteArrayOf(1, 2, 3, 9, 2, 7, 3, 4, 2, 5, 3)
        val p = BytePattern.parse("02 ?? 03")!!
        assertEquals(4, RomSearch.find(data, p, 0))
        assertEquals(4, RomSearch.find(data, p, 2))
        assertEquals(8, RomSearch.find(data, p, 5))
        assertEquals(-1, RomSearch.find(data, p, 9))
        assertEquals(4, RomSearch.findWrapping(data, p, 9))
        assertEquals(8, RomSearch.findPreviousWrapping(data, p, 0))
        assertEquals(4, RomSearch.findPreviousWrapping(data, p, 7))
    }

    @Test
    fun exactPatternAndMatchesAt() {
        val p = BytePattern.exact(byteArrayOf(5, 6))!!
        assertTrue(p.matchesAt(byteArrayOf(0, 5, 6), 1))
        assertEquals(false, p.matchesAt(byteArrayOf(0, 5, 6), 2))
        assertNull(BytePattern.parse("zz"))
        assertNull(BytePattern.exact(ByteArray(0)))
    }

    @Test
    fun pointerSearchAndTarget() {
        val data = ByteArray(0x20)
        data[8] = 0x10
        data[9] = 0x00
        data[10] = 0x00
        data[11] = 0x08
        val rom = RomData(data)
        assertEquals(listOf(8), RomSearch.pointersTo(data, 0x10))
        assertEquals(0x10, rom.pointerTarget(8))
        assertEquals(-1, rom.pointerTarget(4))
        // points outside the file
        data[8] = 0x00
        data[9] = 0x01
        assertEquals(-1, RomData(data).pointerTarget(8))
    }

    @Test
    fun headerAndGameCode() {
        val data = ByteArray(0x200)
        "POKEMON FIRE".forEachIndexed { i, c -> data[0xA0 + i] = c.code.toByte() }
        "BPRE".forEachIndexed { i, c -> data[0xAC + i] = c.code.toByte() }
        "01".forEachIndexed { i, c -> data[0xB0 + i] = c.code.toByte() }
        data[0xBC] = 0
        val header = RomHeader.read(RomData(data))
        assertEquals("POKEMON FIRE", header.title)
        val game = header.game
        assertNotNull(game)
        assertEquals("BPRE0", game!!.full)
        assertTrue(game.hasTableSupport)
        assertEquals("FireRed (English) v0", game.displayName)
        assertNull(RomHeader.read(RomData(ByteArray(0x200))).game)
        assertNull(RomHeader.read(RomData(ByteArray(10))).game)
    }
}
