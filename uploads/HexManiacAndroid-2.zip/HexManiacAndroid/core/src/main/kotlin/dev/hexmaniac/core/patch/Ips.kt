package dev.hexmaniac.core.patch

import java.io.ByteArrayOutputStream

/** Thrown when a patch cannot be built or is not a patch at all. */
class PatchException(message: String) : Exception(message)

/** Output of [Ips.apply]: the patched image and the offset of the first hunk (-1 when the patch is empty). */
class IpsResult(val data: ByteArray, val firstOffset: Int)

/**
 * IPS patches: "PATCH", hunks of (3 byte offset, 2 byte length, payload) where length 0 introduces an
 * RLE hunk (2 byte count, 1 byte value), then "EOF". Port of HexManiac's Patcher IPS code.
 */
object Ips {
    private const val MAX_FILE = 0x1000000
    private const val EOF_OFFSET = 0x454F46 // a hunk at "EOF" would be read as the end marker

    /** Builds a patch that turns [source] into [destination]. IPS cannot address files above 16 MB. */
    fun build(source: ByteArray, destination: ByteArray): ByteArray {
        if (destination.size > MAX_FILE) throw PatchException("IPS patches only support files up to 16 MB. Use UPS instead.")
        val out = ByteArrayOutputStream()
        out.write("PATCH".toByteArray(Charsets.US_ASCII))
        var i = 0
        while (i < destination.size) {
            if (sameAt(source, destination, i)) {
                i++
                continue
            }
            var j = i + 1
            while (j < destination.size && !sameAt(source, destination, j) && j - i < 0xFFFF) j++
            var start = i
            if (start == EOF_OFFSET) start-- // begin one byte earlier so the offset is not mistaken for "EOF"
            if (j - start > 0xFFFF) j = start + 0xFFFF
            writeHunk(out, destination, start, j - start)
            i = j
        }
        out.write("EOF".toByteArray(Charsets.US_ASCII))
        return out.toByteArray()
    }

    /** Applies [patch] to a copy of [rom]; the result grows (zero filled) when hunks reach past the end. */
    fun apply(rom: ByteArray, patch: ByteArray): IpsResult {
        if (patch.size < 8 || String(patch, 0, 5, Charsets.US_ASCII) != "PATCH") throw PatchException("This is not an IPS patch.")
        var out = rom.copyOf()
        var pos = 5
        var first = -1
        while (pos + 3 <= patch.size) {
            if (patch[pos] == 'E'.code.toByte() && patch[pos + 1] == 'O'.code.toByte() && patch[pos + 2] == 'F'.code.toByte()) break
            if (pos + 5 > patch.size) break
            val offset = (u(patch[pos]) shl 16) or (u(patch[pos + 1]) shl 8) or u(patch[pos + 2])
            var length = (u(patch[pos + 3]) shl 8) or u(patch[pos + 4])
            pos += 5
            if (first < 0) first = offset
            if (length > 0) {
                if (pos + length > patch.size) break // truncated patch: keep what was applied so far
                if (offset + length > out.size) out = out.copyOf(offset + length)
                System.arraycopy(patch, pos, out, offset, length)
                pos += length
            } else {
                if (pos + 3 > patch.size) break
                length = (u(patch[pos]) shl 8) or u(patch[pos + 1])
                val value = patch[pos + 2]
                pos += 3
                if (offset + length > out.size) out = out.copyOf(offset + length)
                java.util.Arrays.fill(out, offset, offset + length, value)
            }
        }
        return IpsResult(out, first)
    }

    private fun sameAt(source: ByteArray, destination: ByteArray, index: Int): Boolean =
        (if (index < source.size) source[index] else 0.toByte()) == destination[index]

    private fun writeHunk(out: ByteArrayOutputStream, data: ByteArray, start: Int, length: Int) {
        out.write(start ushr 16)
        out.write(start ushr 8)
        out.write(start)
        val first = data[start]
        var rle = length > 4
        if (rle) {
            for (k in 1 until length) {
                if (data[start + k] != first) {
                    rle = false
                    break
                }
            }
        }
        if (rle) {
            out.write(0)
            out.write(0)
            out.write(length ushr 8)
            out.write(length)
            out.write(first.toInt())
        } else {
            out.write(length ushr 8)
            out.write(length)
            out.write(data, start, length)
        }
    }

    private fun u(b: Byte): Int = b.toInt() and 0xFF
}
