package dev.hexmaniac.core.text

/**
 * The raw ingredients of a [PcsTable]: what `PCSString`'s static constructor builds from `pcsReference.txt`
 * (or from its built-in defaults when that file is absent).
 *
 * @property tokens text for each of the 256 byte values, null for bytes without a text form.
 * @property controlCodeLengths explicit byte counts (code byte included) for function-escape control codes.
 * @property macros per game code, macro name (including the brackets) to the bytes it stands for, in file order.
 */
internal class PcsReferenceData(
    val tokens: Array<String?>,
    val controlCodeLengths: Map<Int, Int>,
    val macros: Map<String, Map<String, ByteArray>>,
)

/**
 * Reads the PCS reference file.
 *
 * Syntax (one entry per line, `#` starts a comment):
 *  * `0xNN = "chars"` assigns the characters, one per byte, starting at byte NN; `0xNN = token` assigns a single token.
 *  * `CC_NN = n` says control code NN takes n argument bytes.
 *  * `[name] HH HH ...` defines a text macro; `@!game(AAAA_BBBB)` restricts the macros that follow to those games.
 */
internal object PcsReferenceParser {
    /** The games that get their own macro set. Macros before the first `@!game` line belong to every game. */
    val MACRO_GAMES: List<String> = listOf("AXVE", "AXPE", "BPRE", "BPGE", "BPEE")

    /** Parses the text of `pcsReference.txt`. Malformed lines are skipped. */
    fun parse(referenceText: String): PcsReferenceData {
        val lines = referenceText.removePrefix("﻿").lines()
        return PcsReferenceData(parseTokens(lines), parseControlCodeLengths(lines), parseMacros(lines))
    }

    /** The table used when no reference file is available: the English character set, five control codes, no macros. */
    fun defaults(): PcsReferenceData {
        val pcs = arrayOfNulls<String>(0x100)

        pcs[0] = " "
        fill(pcs, "ÀÁÂÇÈÉÊËÌ", 0x01)
        fill(pcs, "ÎÏÒÓÔ", 0x0B)
        fill(pcs, "ŒÙÚÛÑßàá", 0x10)
        fill(pcs, "çèéêëì", 0x19)
        fill(pcs, "îïòóôœùúûñºª", 0x20)
        pcs[0x2C] = "\\e"
        fill(pcs, "& \\+", 0x2D)
        fill(pcs, "\\Lv = ;", 0x34)

        pcs[0x48] = "\\r"

        fill(pcs, "¿ ¡ \\pk \\mn \\Po \\Ke \\Bl \\Lo \\Ck Í", 0x51)

        fill(pcs, "%()", 0x5B)

        pcs[0x68] = "â"
        pcs[0x6F] = "í"

        fill(pcs, "\\au \\ad \\al \\ar", 0x79)

        pcs[0x84] = "\\d"
        fill(pcs, "\\< \\>", 0x85)

        fill(pcs, "0123456789", 0xA1)
        // \. -> ellipsis, \qo \qc -> quote open/close, \sm \sf -> male/female symbols
        fill(pcs, "! ? . - ‧ \\. \\qo \\qc ‘ ' \\sm \\sf $ , * /", 0xAB)

        fill(pcs, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", 0xBB)
        fill(pcs, "abcdefghijklmnopqrstuvwxyz", 0xD5)

        fill(pcs, ":ÄÖÜäöü", 0xF0)

        pcs[PcsBytes.DYNAMIC_ESCAPE] = "\\?"
        pcs[PcsBytes.BUTTON_ESCAPE] = "\\btn"
        pcs[PcsBytes.SPECIAL_CHARACTER_ESCAPE] = "\\9"
        pcs[PcsBytes.LINE_FEED] = "\\l"
        pcs[PcsBytes.PARAGRAPH] = "\\pn"
        pcs[PcsBytes.FUNCTION_ESCAPE] = "\\CC"
        pcs[PcsBytes.ESCAPE] = "\\\\"
        pcs[PcsBytes.NEWLINE] = "\\n"
        pcs[PcsBytes.TERMINATOR] = "\""

        val lengths = mapOf(
            0x04 to 4, // text, shadow, highlight -> 3 parameters
            0x09 to 1, // pause: no parameters
            0x0A to 1, // wait for sound effect
            0x0B to 3, // play background music: 1 variable that takes 2 bytes
            0x10 to 3, // play sound effect: 2 variables
        )
        return PcsReferenceData(pcs, lengths, emptyMap())
    }

    private fun fill(array: Array<String?>, characters: String, startIndex: Int) {
        var index = startIndex
        if (characters.contains(' ')) {
            for (part in characters.split(' ')) array[index++] = part
        } else {
            for (c in characters) array[index++] = c.toString()
        }
    }

    private fun parseTokens(lines: List<String>): Array<String?> {
        val tokens = arrayOfNulls<String>(0x100)
        for (raw in lines) {
            if (!raw.startsWith("0x")) continue
            val line = raw.substring(2).substringBefore('#').trim()
            val equals = line.indexOf('=')
            if (equals < 0) continue
            val start = PcsHex.parseNumber(line.substring(0, equals).trim()) ?: continue
            var value = line.substring(equals + 1).trim()
            if (value.length > 1 && value.startsWith('"') && value.endsWith('"')) {
                value = value.substring(1, value.length - 1)
                for (j in value.indices) assign(tokens, start + j, value[j].toString())
            } else {
                assign(tokens, start, value)
            }
        }
        return tokens
    }

    private fun assign(tokens: Array<String?>, byte: Long, token: String) {
        if (byte in 0L..0xFFL && token.isNotEmpty()) tokens[byte.toInt()] = token
    }

    private fun parseControlCodeLengths(lines: List<String>): Map<Int, Int> {
        val lengths = LinkedHashMap<Int, Int>()
        for (raw in lines) {
            if (!raw.startsWith("CC_")) continue
            val line = raw.substring(3).substringBefore('#').trim()
            val equals = line.indexOf('=')
            if (equals < 0) continue
            val code = PcsHex.parseNumber(line.substring(0, equals).trim())?.takeIf { it <= 0xFF } ?: continue
            val argumentCount = parseDecimalByte(line.substring(equals + 1).trim()) ?: continue
            lengths[code.toInt()] = (argumentCount + 1) and 0xFF
        }
        return lengths
    }

    /** `byte.TryParse(text)`: optional sign, decimal digits, value 0..255. */
    private fun parseDecimalByte(text: String): Int? {
        var digits = text
        var negative = false
        if (digits.startsWith("+")) digits = digits.substring(1)
        else if (digits.startsWith("-")) { negative = true; digits = digits.substring(1) }
        if (digits.isEmpty() || digits.length > 4 || digits.any { it !in '0'..'9' }) return null
        val value = digits.toInt()
        if (value > 0xFF || (negative && value != 0)) return null
        return value
    }

    private fun parseMacros(lines: List<String>): Map<String, Map<String, ByteArray>> {
        val result = LinkedHashMap<String, Map<String, ByteArray>>()
        for (game in MACRO_GAMES) result[game] = parseMacrosForGame(lines, game)
        return result
    }

    private fun parseMacrosForGame(lines: List<String>, game: String): Map<String, ByteArray> {
        var inSection = true
        val macros = LinkedHashMap<String, ByteArray>()
        for (line in lines) {
            if (line.trim().startsWith("@!game(")) inSection = line.contains(game)
            if (!inSection || !line.startsWith("[")) continue
            val close = line.indexOf(']')
            if (close < 0) continue
            val bytes = parseByteList(line.substring(close + 1).substringBefore('#').trim()) ?: continue
            macros[line.substring(0, close + 1)] = bytes
        }
        return macros
    }

    /** Parses "FD 01"-style text; null when any part is not hexadecimal. */
    private fun parseByteList(text: String): ByteArray? {
        val parts = text.split(' ', '\t').filter { it.isNotEmpty() }
        val bytes = ByteArray(parts.size)
        for (i in parts.indices) {
            val value = PcsHex.parseNumber(parts[i]) ?: return null
            bytes[i] = value.toByte()
        }
        return bytes
    }
}

/**
 * The text macros of one game: names such as `[player]` that stand for a fixed byte sequence.
 * Lookup order follows the order in the reference file, as in HexManiac.
 */
internal class PcsMacroSet(macros: Map<String, ByteArray>) {
    /** One macro: its name including the brackets and the bytes it stands for. */
    class Macro(val name: String, val bytes: ByteArray)

    private val byName = LinkedHashMap<String, Macro>()
    private val byLeadByte = arrayOfNulls<MutableList<Macro>>(0x100)

    init {
        for ((name, bytes) in macros) {
            val macro = Macro(name, bytes)
            byName[name] = macro
            if (bytes.isEmpty()) continue
            val lead = bytes[0].toInt() and 0xFF
            val list = byLeadByte[lead] ?: ArrayList<Macro>().also { byLeadByte[lead] = it }
            list.add(macro)
        }
    }

    /** All macro names, in definition order. */
    val names: Set<String> get() = byName.keys

    /** The bytes behind the macro called [name] (brackets included), or null. */
    fun bytesFor(name: String): ByteArray? = byName[name]?.bytes

    /** The first macro, in definition order, whose bytes appear in [data] at [index]; null when none does. */
    fun findAt(data: ByteArray, index: Int): Macro? {
        if (index < 0 || index >= data.size) return null
        val candidates = byLeadByte[data[index].toInt() and 0xFF] ?: return null
        for (macro in candidates) {
            val bytes = macro.bytes
            var matches = true
            var i = 0
            while (i < bytes.size && matches) {
                matches = data.size > index + i && bytes[i] == data[index + i]
                i++
            }
            if (matches) return macro
        }
        return null
    }

    /** True when some macro name starts with [prefix]. */
    fun anyNameStartsWith(prefix: String): Boolean = byName.keys.any { it.startsWith(prefix) }
}
