package dev.hexmaniac.core.patch

/** Standard CRC-32 (IEEE 802.3), the checksum UPS patches use. */
object Crc32 {
    fun compute(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): Int {
        val crc = java.util.zip.CRC32()
        crc.update(data, offset, length)
        return crc.value.toInt()
    }
}
