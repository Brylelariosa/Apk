package dev.hexmaniac.core.rom

import dev.hexmaniac.core.patch.Crc32
import dev.hexmaniac.core.text.PcsTable

/** Plain-text descriptions of a ROM and of the bytes under the cursor, so any front end can show them. */
object RomInfo {
    /** How many bytes after the cursor are decoded as text. */
    private const val TEXT_PREVIEW_BYTES = 24

    /**
     * Three lines for the info strip: file and game, the value at [offset] in several widths
     * (with the pointer target when it is a pointer), and the text starting at [offset].
     */
    fun cursorSummary(document: RomDocument, fileName: String, offset: Int, pcs: PcsTable): String {
        val rom = document.rom
        val game = document.header.game
        val sb = StringBuilder()
        if (document.isDirty) sb.append("● ")
        sb.append(fileName).append("  ").append(game?.displayName ?: "unknown game").append('\n')
        sb.append('@').append(HexText.hex(offset, 6))
        sb.append("  u8 ").append(HexText.hex(rom[offset], 2))
        sb.append("  u16 ").append(HexText.hex(rom.readShort(offset), 4))
        sb.append("  u32 ").append(HexText.hex(rom.readWord(offset), 8))
        val target = rom.pointerTarget(offset)
        if (target >= 0) sb.append(" → ").append(HexText.hex(target, 6))
        sb.append('\n')
        sb.append(pcs.decode(rom.bytes, offset, TEXT_PREVIEW_BYTES, game?.full ?: "").replace('\n', '¶'))
        return sb.toString()
    }

    /** The multi-line "ROM info" dialog text. */
    fun details(document: RomDocument, fileName: String): String {
        val header = document.header
        val game = header.game
        val size = document.rom.size
        return buildString {
            append("File: ").append(fileName).append('\n')
            append("Size: ").append(size).append(" bytes (").append(size / 1024).append(" KB)\n")
            append("Title: ").append(header.title).append('\n')
            append("Game code: ").append(game?.full ?: "unknown").append('\n')
            if (game != null) {
                append("Game: ").append(game.displayName).append('\n')
                append("Table data for this game: ")
                    .append(if (game.hasTableSupport) "available (coming soon)" else "not available").append('\n')
            }
            append("Maker: ").append(header.maker).append('\n')
            append("CRC-32: ").append(HexText.hex(Crc32.compute(document.rom.bytes), 8)).append('\n')
            append("Unsaved changes: ").append(if (document.isDirty) "yes" else "no")
        }
    }
}
