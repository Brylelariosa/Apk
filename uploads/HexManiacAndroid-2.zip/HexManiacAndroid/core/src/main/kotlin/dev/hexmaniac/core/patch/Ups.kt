package dev.hexmaniac.core.patch

import java.io.ByteArrayOutputStream

/** Which way a UPS patch was applied. */
enum class UpsDirection { SourceToDestination, DestinationToSource }

/** Outcome of [Ups.apply]. Failure codes match HexManiac's: -1 .. -7. */
sealed interface UpsResult {
    class Success(val data: ByteArray, val firstEdit: Int, val direction: UpsDirection) : UpsResult
    class Failure(val code: Int, val reason: String) : UpsResult
}

/**
 * UPS patches: "UPS1", variable width source and destination sizes, XOR chunks (each a skip count
 * followed by XOR bytes and a 0 terminator) and three CRC-32s (source, destination, patch).
 * Because the format is XOR based the same patch also reverts a patched file.
 */
object Ups {
    /** Builds a patch that turns [source] into [destination]. */
    fun build(source: ByteArray, destination: ByteArray): ByteArray {
        val patch = ByteArrayOutputStream()
        patch.write("UPS1".toByteArray(Charsets.US_ASCII))
        writeVwi(patch, source.size)
        writeVwi(patch, destination.size)
        var offset = 0
        var writing = false
        for (i in destination.indices) {
            val sourceValue = if (i < source.size) source[i].toInt() and 0xFF else 0
            val destinationValue = destination[i].toInt() and 0xFF
            if (sourceValue == destinationValue) {
                if (writing) {
                    writing = false
                    offset = i + 1
                    patch.write(0)
                }
                continue
            }
            if (!writing) {
                writeVwi(patch, i - offset)
                writing = true
            }
            patch.write(sourceValue xor destinationValue)
        }
        if (writing) patch.write(0)
        writeLe32(patch, Crc32.compute(source))
        writeLe32(patch, Crc32.compute(destination))
        writeLe32(patch, Crc32.compute(patch.toByteArray()))
        return patch.toByteArray()
    }

    /**
     * Applies [patch] to [rom] in whichever direction its checksums allow. With [ignoreChecksums] a ROM
     * that matches neither side is patched forward anyway.
     */
    fun apply(rom: ByteArray, patch: ByteArray, ignoreChecksums: Boolean = false): UpsResult {
        if (patch.size < 18 || String(patch, 0, 4, Charsets.US_ASCII) != "UPS1") {
            return UpsResult.Failure(-1, "This is not a UPS patch.")
        }
        val sourceCrc = readLe32(patch, patch.size - 12)
        val destinationCrc = readLe32(patch, patch.size - 8)
        val patchCrc = readLe32(patch, patch.size - 4)
        val currentCrc = Crc32.compute(rom)
        var direction: UpsDirection? = null
        if (currentCrc == sourceCrc) direction = UpsDirection.SourceToDestination
        if (currentCrc == destinationCrc) direction = UpsDirection.DestinationToSource
        if (direction == null) {
            if (!ignoreChecksums) return UpsResult.Failure(-2, "This ROM is not the one the patch was made for (checksum mismatch).")
            direction = UpsDirection.SourceToDestination
        }
        if (Crc32.compute(patch, 0, patch.size - 4) != patchCrc) {
            return UpsResult.Failure(-3, "The patch file is damaged (checksum mismatch).")
        }
        try {
            val cursor = Cursor(4)
            var sourceSize = readVwi(patch, cursor)
            var destinationSize = readVwi(patch, cursor)
            if (direction == UpsDirection.DestinationToSource) {
                val swap = sourceSize
                sourceSize = destinationSize
                destinationSize = swap
            }
            if (sourceSize != rom.size && !ignoreChecksums) {
                return UpsResult.Failure(-4, "The ROM size does not match what the patch expects.")
            }
            val work = rom.copyOf(maxOf(rom.size, destinationSize))
            val firstEdit = runChunks(patch, cursor, work, destinationSize)
            if (firstEdit == ERROR_PAST_END) return UpsResult.Failure(-7, "The patch writes past the end of the file.")
            val result = if (work.size == destinationSize) work else work.copyOf(destinationSize)
            if (!ignoreChecksums) {
                val finalCrc = Crc32.compute(result)
                val expected = if (direction == UpsDirection.SourceToDestination) destinationCrc else sourceCrc
                if (finalCrc != expected) return UpsResult.Failure(-5, "The patched file does not have the expected checksum.")
            }
            if (direction == UpsDirection.SourceToDestination && cursor.pos != patch.size - 12) {
                return UpsResult.Failure(-6, "The patch did not end where expected.")
            }
            return UpsResult.Success(result, if (firstEdit == Int.MAX_VALUE) -1 else firstEdit, direction)
        } catch (e: IndexOutOfBoundsException) {
            return UpsResult.Failure(-6, "The patch is truncated.")
        }
    }

    private const val ERROR_PAST_END = -7

    private class Cursor(var pos: Int)

    private fun runChunks(patch: ByteArray, cursor: Cursor, work: ByteArray, destinationSize: Int): Int {
        var writeIndex = 0
        var firstEdit = Int.MAX_VALUE
        while (cursor.pos < patch.size - 12 && writeIndex < destinationSize) {
            val skip = readVwi(patch, cursor)
            writeIndex += skip
            if (writeIndex > destinationSize) return ERROR_PAST_END
            if (firstEdit == Int.MAX_VALUE) firstEdit = skip
            while (patch[cursor.pos].toInt() != 0 && writeIndex < destinationSize) {
                work[writeIndex] = (patch[cursor.pos].toInt() xor work[writeIndex].toInt()).toByte()
                cursor.pos++
                writeIndex++
                if (writeIndex > destinationSize) return ERROR_PAST_END
            }
            cursor.pos++
            writeIndex++
        }
        return firstEdit
    }

    internal fun writeVwi(out: ByteArrayOutputStream, start: Int) {
        var value = start
        do {
            var payload = value and 0x7F
            value = value ushr 7
            if (value == 0) payload = payload or 0x80
            value -= 1
            out.write(payload)
        } while (value >= 0)
    }

    private fun readVwi(data: ByteArray, cursor: Cursor): Int {
        var result = 0
        var shift = 0
        while (true) {
            val b = data[cursor.pos].toInt() and 0xFF
            cursor.pos++
            result += (b and 0x7F) shl shift
            if (b and 0x80 != 0) return result
            shift += 7
            if (shift > 28) throw IndexOutOfBoundsException("variable width integer too long")
            result += 1 shl shift
        }
    }

    internal fun readVwiAt(data: ByteArray, start: Int): Pair<Int, Int> {
        val cursor = Cursor(start)
        val value = readVwi(data, cursor)
        return Pair(value, cursor.pos)
    }

    private fun readLe32(data: ByteArray, offset: Int): Int =
        (data[offset].toInt() and 0xFF) or ((data[offset + 1].toInt() and 0xFF) shl 8) or
            ((data[offset + 2].toInt() and 0xFF) shl 16) or ((data[offset + 3].toInt() and 0xFF) shl 24)

    private fun writeLe32(out: ByteArrayOutputStream, value: Int) {
        out.write(value)
        out.write(value ushr 8)
        out.write(value ushr 16)
        out.write(value ushr 24)
    }
}
