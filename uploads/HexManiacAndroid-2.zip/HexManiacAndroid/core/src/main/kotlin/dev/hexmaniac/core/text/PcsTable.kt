package dev.hexmaniac.core.text

import dev.hexmaniac.core.io.ResourceSource

/**
 * The Pokemon Character Set: how the bytes of a GBA Pokemon ROM map to text and back.
 * This is the Kotlin counterpart of HexManiac's static `PCSString`, but as an immutable object built from
 * `pcsReference.txt` (or from the built-in defaults), so tests and tools can use their own tables.
 *
 * Text form: starts with a double quote; the 0xFF terminator is the closing quote; bytes without a character are
 * written `\!XX`; names in square brackets such as `[player]` stand for fixed byte sequences of the given game.
 */
class PcsTable internal constructor(
    reference: PcsReferenceData,
    /** The line separator used when decoding and encoding multi-line text. */
    val newline: String = "\n",
) {
    /** One character or escape code of the table. */
    class Entry(val token: String, val byte: Int, val isEscape: Boolean)

    private val tokens: Array<String?> = reference.tokens
    private val controlCodeLengths: Map<Int, Int> = reference.controlCodeLengths
    private val macroSets: Map<String, PcsMacroSet> = reference.macros.mapValues { PcsMacroSet(it.value) }

    internal val doubleNewline: String = newline + newline

    /** Every entry, in byte order (the order the text encoder tries them in). */
    internal val encodableEntries: List<Entry> = (0..0xFF).mapNotNull { b ->
        tokens[b]?.let { Entry(it, b, it.isNotEmpty() && it[0] == '\\') }
    }

    /** Proper prefixes of every escape token, e.g. `\`, `\C` for `\CC`. */
    internal val validInProgressEscapes: Set<String> = HashSet<String>().also { set ->
        for (token in tokens) {
            if (token == null || !token.startsWith("\\")) continue
            for (i in 0 until token.length - 1) set.add(token.substring(0, i + 1))
        }
    }

    internal fun tokenFor(byte: Int): String? = tokens[byte and 0xFF]

    /** Number of bytes (code included) of the function escape (0xFC) with this code. */
    internal fun controlCodeLength(code: Int): Int {
        controlCodeLengths[code and 0xFF]?.let { return it }
        return if ((code and 0xFF) > 0x14) 1 else 2
    }

    /** The macros of a game ("BPRE0" or "BPRE" selects FireRed's); null when the game has none. */
    internal fun macroSetFor(gameCode: String): PcsMacroSet? {
        if (gameCode.length < 4) return null
        val set = macroSets[gameCode.substring(0, 4)] ?: return null
        return if (set.names.isEmpty()) null else set
    }

    /** The token for one byte (e.g. "A", "\n", "\pk"), or null when the byte has no text form. */
    fun charFor(byte: Int): String? = tokens[byte and 0xFF]

    /** A one-character display for a hex-view text column: the character itself, or '·' for anything else. */
    fun columnChar(byte: Int): String {
        val token = tokens[byte and 0xFF]
        return if (token != null && token.length == 1 && token != "\"") token else "·"
    }

    /**
     * Text form of [length] bytes starting at [start]. [gameCode] ("BPRE0") selects the macro set;
     * with [includeNewlineCharacters] explicit `\n` / `\l` / `\pn` markers are written in front of line breaks.
     */
    fun decode(
        data: ByteArray,
        start: Int,
        length: Int,
        gameCode: String = "",
        includeNewlineCharacters: Boolean = false,
    ): String = PcsDecoder.decode(this, data, start, length, gameCode, includeNewlineCharacters)

    /** Encodes text (a leading quote is ignored); the result always ends with the 0xFF terminator. */
    fun encode(text: String, gameCode: String = ""): EncodeResult = PcsEncoder.encode(this, text, gameCode)

    /**
     * Length in bytes, including the 0xFF terminator, of the string that starts at [start]; -1 when the bytes
     * are not plausible text (unknown bytes, more than three equal bytes in a row unless [allowRepeats],
     * mostly spaces, or no terminator within [maxLength]).
     */
    fun readStringLength(data: ByteArray, start: Int, allowRepeats: Boolean = false, maxLength: Int = Int.MAX_VALUE): Int {
        if (start < 0 || start >= data.size) return -1
        var length = 0
        var recent = data[start].toInt() and 0xFF
        var repeatCount = 0
        var spacesCount = 0
        while (start + length < data.size && length <= maxLength) {
            val current = data[start + length].toInt() and 0xFF
            if (current == recent) {
                repeatCount++
            } else {
                repeatCount = 1
                recent = current
            }
            if (current == 0x00) spacesCount++
            if (repeatCount > 3 && !allowRepeats) return -1
            if (tokens[recent] == null) return -1
            if (current == PcsBytes.TERMINATOR) {
                if (spacesCount * 2 > length + 1 && spacesCount != length) return -1
                return length + 1
            }
            if (PcsBytes.takesOneArgument(current)) {
                length++
            } else if (current == PcsBytes.FUNCTION_ESCAPE) {
                val code = if (start + length + 1 < data.size) data[start + length + 1].toInt() and 0xFF else 0
                length += controlCodeLength(code)
            }
            length++
        }
        return -1
    }

    companion object {
        /** A table built from the built-in defaults (English characters, no macros). */
        val DEFAULT: PcsTable by lazy { fromReference(null) }

        /** Loads `pcsReference.txt` from [resources]; falls back to the built-in defaults when it is missing. */
        fun load(resources: ResourceSource): PcsTable = fromReference(resources.readText("pcsReference.txt"))

        /** Parses reference-file text; null selects the built-in defaults. */
        fun fromReference(referenceText: String?): PcsTable =
            PcsTable(if (referenceText == null) PcsReferenceParser.defaults() else PcsReferenceParser.parse(referenceText))
    }
}
