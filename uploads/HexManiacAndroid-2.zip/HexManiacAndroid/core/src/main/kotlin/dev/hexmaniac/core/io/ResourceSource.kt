package dev.hexmaniac.core.io

/**
 * Supplies the bundled reference files (tableReference.txt, default.toml, pcsReference.txt, ...).
 *
 * The engine never touches the file system or Android APIs directly; everything that ships with the
 * app is read through this interface so tests can substitute in-memory data.
 */
interface ResourceSource {
    /** Text of the named file (UTF-8, plain file name such as "tableReference.txt"), or null when it does not exist. */
    fun readText(name: String): String?

    /** Names of every available file. */
    fun list(): List<String>
}

/** A [ResourceSource] backed by a fixed map; handy for tests. */
class MapResources(private val files: Map<String, String>) : ResourceSource {
    override fun readText(name: String): String? = files[name]
    override fun list(): List<String> = files.keys.sorted()
}

/**
 * Reads the files packaged under `/hma/` on the class path (they live in `core/src/main/resources/hma`).
 * Works identically on the JVM and inside an Android APK because Java resources of library modules are
 * merged into the APK. `index.txt` lists the file names since class-path folders cannot be enumerated.
 */
class ClasspathResources(
    private val loader: ClassLoader = ClasspathResources::class.java.classLoader!!,
    private val folder: String = "hma",
) : ResourceSource {
    override fun readText(name: String): String? {
        val stream = loader.getResourceAsStream("$folder/$name") ?: return null
        return stream.use { String(it.readBytes(), Charsets.UTF_8) }
    }

    override fun list(): List<String> =
        readText("index.txt")?.lineSequence()?.map { it.trim() }?.filter { it.isNotEmpty() }?.toList() ?: emptyList()
}
