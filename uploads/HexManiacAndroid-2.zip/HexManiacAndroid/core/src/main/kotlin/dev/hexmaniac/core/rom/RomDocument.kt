package dev.hexmaniac.core.rom

/** One reversible modification of a [RomData]. */
sealed interface Change {
    fun undo(rom: RomData)
    fun redo(rom: RomData)
}

/** Overwrites [before] with [after] at [offset]. */
class BytesChange(val offset: Int, val before: ByteArray, val after: ByteArray) : Change {
    override fun undo(rom: RomData) = rom.setRange(offset, before)
    override fun redo(rom: RomData) = rom.setRange(offset, after)
}

/** Resizes the image; [removed] holds the bytes cut off when shrinking so the change can be undone. */
class ResizeChange(val oldSize: Int, val newSize: Int, val removed: ByteArray) : Change {
    override fun undo(rom: RomData) {
        rom.resize(oldSize)
        if (removed.isNotEmpty()) rom.setRange(newSize, removed)
    }

    override fun redo(rom: RomData) = rom.resize(newSize)
}

/**
 * A ROM being edited: the bytes, an undo/redo history and a "dirty" flag.
 *
 * All modifications go through [write], [resize], [replaceAll] or [edit]; each public call is one
 * undo step, and [edit] merges several calls into a single step. Not thread safe: use from one thread.
 */
class RomDocument(val name: String, initial: ByteArray) {
    val rom = RomData(initial)

    /** Header information (title, game code, ...), read fresh from the current bytes. */
    val header: RomHeader get() = RomHeader.read(rom)

    fun interface Listener {
        fun onDocumentChanged()
    }

    private class Step(val label: String) {
        val changes = ArrayList<Change>()
    }

    private val undoSteps = ArrayList<Step>()
    private val redoSteps = ArrayList<Step>()
    private val listeners = ArrayList<Listener>()
    private var current: Step? = null
    private var depth = 0
    private var savedStep: Step? = null

    val canUndo: Boolean get() = undoSteps.isNotEmpty()
    val canRedo: Boolean get() = redoSteps.isNotEmpty()
    val undoLabel: String? get() = undoSteps.lastOrNull()?.label
    val redoLabel: String? get() = redoSteps.lastOrNull()?.label

    /** True when the content differs from the last [markSaved] (or from the loaded file). */
    val isDirty: Boolean get() = undoSteps.lastOrNull() !== savedStep

    fun addListener(listener: Listener) {
        listeners.add(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    /** Records the current state as the saved one. */
    fun markSaved() {
        savedStep = undoSteps.lastOrNull()
        notifyChanged()
    }

    /** Runs [block]; every change made inside becomes one undo step labelled [label]. */
    fun <T> edit(label: String, block: () -> T): T {
        if (current == null) current = Step(label)
        depth++
        try {
            return block()
        } finally {
            depth--
            if (depth == 0) {
                val step = current!!
                current = null
                if (step.changes.isNotEmpty()) {
                    undoSteps.add(step)
                    redoSteps.clear()
                    if (undoSteps.size > MAX_STEPS) undoSteps.removeAt(0)
                    notifyChanged()
                }
            }
        }
    }

    /** Overwrites bytes at [offset]. The range must lie inside the image. */
    fun write(offset: Int, data: ByteArray, label: String = "Edit bytes") {
        require(offset >= 0 && offset + data.size <= rom.size) { "Write outside the ROM" }
        edit(label) {
            val before = rom.copyRange(offset, data.size)
            if (!before.contentEquals(data)) record(BytesChange(offset, before, data.copyOf()))
        }
    }

    fun writeByte(offset: Int, value: Int, label: String = "Edit byte") = write(offset, byteArrayOf(value.toByte()), label)

    /** Grows (zero filled) or shrinks the ROM to [newSize] bytes. */
    fun resize(newSize: Int, label: String = "Resize") {
        require(newSize >= 0) { "Negative size" }
        if (newSize == rom.size) return
        edit(label) {
            val removed = if (newSize < rom.size) rom.copyRange(newSize, rom.size - newSize) else ByteArray(0)
            record(ResizeChange(rom.size, newSize, removed))
        }
    }

    /**
     * Makes the ROM equal to [newBytes] by recording only the bytes that differ (so undo stays cheap
     * for patches that touch a small part of a large file).
     */
    fun replaceAll(newBytes: ByteArray, label: String) {
        edit(label) {
            val oldSize = rom.size
            if (newBytes.size > oldSize) resize(newBytes.size, label)
            val common = minOf(newBytes.size, rom.size)
            var i = 0
            while (i < common) {
                if (rom[i] == (newBytes[i].toInt() and 0xFF)) {
                    i++
                    continue
                }
                // Extend the span until 16 consecutive equal bytes are seen, so nearby edits merge.
                var end = i + 1
                var equalRun = 0
                var j = i + 1
                while (j < common && equalRun < 16) {
                    if (rom[j] == (newBytes[j].toInt() and 0xFF)) equalRun++ else {
                        equalRun = 0
                        end = j + 1
                    }
                    j++
                }
                write(i, newBytes.copyOfRange(i, end), label)
                i = end
            }
            if (newBytes.size < rom.size) resize(newBytes.size, label)
        }
    }

    fun undo(): Boolean {
        if (undoSteps.isEmpty()) return false
        val step = undoSteps.removeAt(undoSteps.size - 1)
        for (i in step.changes.indices.reversed()) step.changes[i].undo(rom)
        redoSteps.add(step)
        notifyChanged()
        return true
    }

    fun redo(): Boolean {
        if (redoSteps.isEmpty()) return false
        val step = redoSteps.removeAt(redoSteps.size - 1)
        for (change in step.changes) change.redo(rom)
        undoSteps.add(step)
        notifyChanged()
        return true
    }

    private fun record(change: Change) {
        change.redo(rom)
        current!!.changes.add(change)
    }

    private fun notifyChanged() {
        for (listener in ArrayList(listeners)) listener.onDocumentChanged()
    }

    private companion object {
        const val MAX_STEPS = 300
    }
}
