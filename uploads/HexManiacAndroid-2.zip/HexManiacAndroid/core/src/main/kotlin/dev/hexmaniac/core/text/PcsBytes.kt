package dev.hexmaniac.core.text

/**
 * Byte values that have a fixed meaning in Pokemon Character Set (PCS) text.
 *
 * The bytes are given as unsigned values (0..255) so they can be compared directly with
 * `data[i].toInt() and 0xFF`.
 */
object PcsBytes {
    /** `\?` : "dynamic" placeholder that is followed by one argument byte. */
    const val DYNAMIC_ESCAPE = 0xF7

    /** `\btn` : button glyph, followed by one argument byte that selects the button. */
    const val BUTTON_ESCAPE = 0xF8

    /** `\9` : special glyph, followed by one argument byte that selects the glyph. */
    const val SPECIAL_CHARACTER_ESCAPE = 0xF9

    /** `\l` : line feed, scroll the text box up by one line once the player presses a button. */
    const val LINE_FEED = 0xFA

    /** `\pn` : paragraph feed, clear the text box once the player presses a button. */
    const val PARAGRAPH = 0xFB

    /** `\CC` : function escape (control code); the following byte selects the function and its arguments. */
    const val FUNCTION_ESCAPE = 0xFC

    /** `\\` : escape character, the following byte is taken as a raw value. */
    const val ESCAPE = 0xFD

    /** `\n` : wrap to the next line of the text box. */
    const val NEWLINE = 0xFE

    /** End-of-string marker, shown as the closing quotation mark. */
    const val TERMINATOR = 0xFF

    /** True for the escapes that are followed by exactly one raw argument byte. */
    internal fun takesOneArgument(byte: Int): Boolean =
        byte == ESCAPE || byte == DYNAMIC_ESCAPE || byte == BUTTON_ESCAPE || byte == SPECIAL_CHARACTER_ESCAPE

    /** True for the three bytes that move the text cursor to another line. */
    internal fun isNewlineByte(byte: Int): Boolean = byte == LINE_FEED || byte == PARAGRAPH || byte == NEWLINE
}

/**
 * The outcome of turning text into PCS bytes with [PcsTable.encode].
 *
 * @property bytes the encoded bytes; always ends with the 0xFF terminator.
 * @property hasBadCharacters true when part of the input could not be represented and was skipped.
 */
class EncodeResult(val bytes: ByteArray, val hasBadCharacters: Boolean) {
    override fun equals(other: Any?): Boolean =
        other is EncodeResult && hasBadCharacters == other.hasBadCharacters && bytes.contentEquals(other.bytes)

    override fun hashCode(): Int = 31 * bytes.contentHashCode() + hasBadCharacters.hashCode()

    override fun toString(): String =
        "EncodeResult(bytes=${bytes.joinToString(" ") { (it.toInt() and 0xFF).toString(16).padStart(2, '0').uppercase() }}, " +
            "hasBadCharacters=$hasBadCharacters)"
}

/** Hexadecimal helpers shared by the PCS reference parser, decoder and encoder. */
internal object PcsHex {
    private const val DIGITS = "0123456789ABCDEF"

    /** Value of the hexadecimal digit [c] (ASCII only), or -1 when it is not one. */
    fun digit(c: Char): Int = when (c) {
        in '0'..'9' -> c - '0'
        in 'A'..'F' -> c - 'A' + 10
        in 'a'..'f' -> c - 'a' + 10
        else -> -1
    }

    /** Appends [value] (0..255) to [out] as two upper-case hexadecimal digits. */
    fun appendByte(out: StringBuilder, value: Int) {
        out.append(DIGITS[(value shr 4) and 0xF]).append(DIGITS[value and 0xF])
    }

    /** Parses 1 to 8 hexadecimal digits (no sign, no prefix, no spaces); null when [text] is not such a number. */
    fun parseNumber(text: String): Long? {
        if (text.isEmpty() || text.length > 8) return null
        var value = 0L
        for (c in text) {
            val d = digit(c)
            if (d < 0) return null
            value = value * 16 + d
        }
        return value
    }

    private fun isNumberWhitespace(c: Char): Boolean = c == ' ' || (c in '\t'..'\r')

    /**
     * Reads the two characters of [text] starting at [index] as one hexadecimal byte, the way .NET's
     * `byte.TryParse(chars, NumberStyles.HexNumber)` does: two digits, or one digit with white space on one
     * side. Returns the byte value (0..255), or -1 when the characters are not a hexadecimal byte.
     */
    fun parseTwoCharacters(text: String, index: Int): Int {
        if (index < 0 || index + 1 >= text.length) return -1
        val c1 = text[index]
        val c2 = text[index + 1]
        val d1 = digit(c1)
        val d2 = digit(c2)
        return when {
            d1 >= 0 && d2 >= 0 -> (d1 shl 4) or d2
            d1 >= 0 && isNumberWhitespace(c2) -> d1
            d2 >= 0 && isNumberWhitespace(c1) -> d2
            else -> -1
        }
    }
}

/** A minimal growable byte list that avoids boxing. */
internal class ByteBuilder(initialCapacity: Int = 32) {
    private var buffer = ByteArray(maxOf(initialCapacity, 4))

    /** Number of bytes added so far. */
    var size = 0
        private set

    /** Appends the low eight bits of [value]. */
    fun add(value: Int) {
        if (size == buffer.size) buffer = buffer.copyOf(size * 2)
        buffer[size++] = value.toByte()
    }

    /** Appends every byte of [values]. */
    fun addAll(values: ByteArray) {
        for (v in values) add(v.toInt())
    }

    /** The most recently added byte as an unsigned value. */
    fun last(): Int = buffer[size - 1].toInt() and 0xFF

    /** A trimmed copy of the contents. */
    fun toByteArray(): ByteArray = buffer.copyOf(size)
}
