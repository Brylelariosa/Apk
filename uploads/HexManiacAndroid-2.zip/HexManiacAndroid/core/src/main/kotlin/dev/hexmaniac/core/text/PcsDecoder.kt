package dev.hexmaniac.core.text

/**
 * Bytes to text. This is `PCSString.Convert(gameCode, data, start, length, includeNewlineCharacters)`.
 *
 * Line breaks are the interesting part. A text box alternates between "wrap" breaks (`\n`, 0xFE) that start
 * the text box's second line and "feed" breaks (`\l`, 0xFA) that scroll further lines; a paragraph (`\pn`, 0xFB)
 * clears the box and starts over with a wrap. The decoder writes the break that is expected next as a plain
 * line separator and spells out any other one (`\n`, `\l`) in front of the separator, so ordinary dialogue reads
 * as ordinary lines of text.
 */
internal object PcsDecoder {
    fun decode(
        table: PcsTable,
        data: ByteArray,
        start: Int,
        length: Int,
        gameCode: String,
        includeNewlineCharacters: Boolean,
    ): String {
        val out = StringBuilder()
        out.append('"')
        if (start < 0 || start >= data.size) return out.toString()

        val limit = minOf(length, data.size - start)
        val macros = table.macroSetFor(gameCode)
        val newline = table.newline
        val showsSeveralBytes = length > 1
        var expectWrap = true

        var i = 0
        while (i < limit) {
            if (macros != null) {
                val macro = macros.findAt(data, start + i)
                if (macro != null) {
                    out.append(macro.name)
                    i += macro.bytes.size
                    continue
                }
            }

            val current = data[start + i].toInt() and 0xFF
            val token = table.tokenFor(current)

            if (showsSeveralBytes && PcsBytes.isNewlineByte(current)) {
                if (current == PcsBytes.PARAGRAPH) {
                    if (includeNewlineCharacters) out.append("\\pn")
                    out.append(newline).append(newline)
                    expectWrap = true
                } else if (current == PcsBytes.NEWLINE && expectWrap) {
                    if (includeNewlineCharacters) out.append("\\n")
                    out.append(newline)
                    expectWrap = false
                } else if (current == PcsBytes.LINE_FEED && !expectWrap) {
                    if (includeNewlineCharacters) out.append("\\l")
                    out.append(newline)
                } else {
                    // a break that is not the one expected here: spell it out so it survives a round trip
                    if (token != null) out.append(token)
                    out.append(newline)
                    expectWrap = false
                }
            } else if (token == null) {
                out.append("\\!")
                PcsHex.appendByte(out, current)
            } else {
                out.append(token)
            }

            if (length == 1) break

            if (PcsBytes.takesOneArgument(current) && i < limit - 1) {
                PcsHex.appendByte(out, data[start + i + 1].toInt() and 0xFF)
                i++
            }
            if (current == PcsBytes.FUNCTION_ESCAPE) {
                val codeIndex = start + i + 1
                if (codeIndex < data.size) {
                    val escapeLength = table.controlCodeLength(data[codeIndex].toInt() and 0xFF)
                    for (j in 0 until escapeLength) {
                        val argumentIndex = codeIndex + j
                        if (argumentIndex < data.size) PcsHex.appendByte(out, data[argumentIndex].toInt() and 0xFF)
                    }
                    i += escapeLength
                }
            }

            if (current == PcsBytes.TERMINATOR) break
            i++
        }
        return out.toString()
    }
}
