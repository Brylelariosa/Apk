package dev.hexmaniac.core.rom

/** A byte pattern in which some positions may be wildcards. */
class BytePattern private constructor(private val values: IntArray) {
    /** Number of bytes matched. */
    val length: Int get() = values.size

    /** True when [data] matches at [offset] (the whole pattern must fit). */
    fun matchesAt(data: ByteArray, offset: Int): Boolean {
        if (offset < 0 || offset + values.size > data.size) return false
        for (k in values.indices) {
            val expected = values[k]
            if (expected >= 0 && (data[offset + k].toInt() and 0xFF) != expected) return false
        }
        return true
    }

    internal fun valueAt(index: Int): Int = values[index]

    companion object {
        /** A pattern with no wildcards. */
        fun exact(bytes: ByteArray): BytePattern? =
            if (bytes.isEmpty()) null else BytePattern(IntArray(bytes.size) { bytes[it].toInt() and 0xFF })

        /**
         * Parses hex bytes where "??" (or "?" / "**") matches any byte, e.g. "0A ?? FF 08".
         * Returns null for empty or malformed input.
         */
        fun parse(text: String): BytePattern? {
            val values = ArrayList<Int>()
            for (token in HexText.tokens(text)) {
                if (token == "??" || token == "?" || token == "**") {
                    values.add(-1)
                    continue
                }
                val bytes = HexText.parseBytes(token) ?: return null
                for (b in bytes) values.add(b.toInt() and 0xFF)
            }
            return if (values.isEmpty()) null else BytePattern(values.toIntArray())
        }
    }
}

/** Searching a ROM image. All functions return -1 when nothing is found. */
object RomSearch {
    /** First match whose start lies in [from, end - pattern.length]. */
    fun find(data: ByteArray, pattern: BytePattern, from: Int, end: Int = data.size): Int {
        val n = pattern.length
        val limit = minOf(end, data.size) - n
        val first = pattern.valueAt(0)
        var i = maxOf(0, from)
        while (i <= limit) {
            if (first >= 0 && (data[i].toInt() and 0xFF) != first) {
                i++
                continue
            }
            if (pattern.matchesAt(data, i)) return i
            i++
        }
        return -1
    }

    /** First match at or after [from], continuing from the start of the file when needed. */
    fun findWrapping(data: ByteArray, pattern: BytePattern, from: Int): Int {
        val hit = find(data, pattern, from)
        if (hit >= 0) return hit
        return find(data, pattern, 0, minOf(data.size, from + pattern.length - 1))
    }

    /** Last match starting at or before [from], wrapping to the end of the file when needed. */
    fun findPreviousWrapping(data: ByteArray, pattern: BytePattern, from: Int): Int {
        var i = minOf(from, data.size - pattern.length)
        while (i >= 0) {
            if (pattern.matchesAt(data, i)) return i
            i--
        }
        i = data.size - pattern.length
        while (i > from) {
            if (pattern.matchesAt(data, i)) return i
            i--
        }
        return -1
    }

    /** Offsets of every 4-aligned word that points at file offset [target]. */
    fun pointersTo(data: ByteArray, target: Int): List<Int> {
        val value = 0x08000000 + target
        val b0 = value and 0xFF
        val b1 = (value ushr 8) and 0xFF
        val b2 = (value ushr 16) and 0xFF
        val b3 = (value ushr 24) and 0xFF
        val hits = ArrayList<Int>()
        var i = 0
        while (i + 4 <= data.size) {
            if ((data[i].toInt() and 0xFF) == b0 && (data[i + 1].toInt() and 0xFF) == b1 &&
                (data[i + 2].toInt() and 0xFF) == b2 && (data[i + 3].toInt() and 0xFF) == b3
            ) hits.add(i)
            i += 4
        }
        return hits
    }
}
