package dev.hexmaniac.core.rom

/**
 * The bytes of a ROM image with bounds-safe little-endian accessors.
 *
 * Reads never throw: anything outside the image reads as 0. Mutation is only possible through
 * [RomDocument] (the setters here are `internal`) so every edit lands in the undo history.
 */
class RomData(initial: ByteArray) {
    /** The backing array. It is replaced when the image is resized, so do not cache it across edits. */
    var bytes: ByteArray = initial
        private set

    val size: Int get() = bytes.size

    /** Unsigned byte at [offset]; 0 when out of range. */
    operator fun get(offset: Int): Int = if (offset >= 0 && offset < bytes.size) bytes[offset].toInt() and 0xFF else 0

    /** Unsigned little-endian 16-bit value. */
    fun readShort(offset: Int): Int = this[offset] or (this[offset + 1] shl 8)

    /** Little-endian 32-bit value (negative when the top bit is set). */
    fun readWord(offset: Int): Int =
        this[offset] or (this[offset + 1] shl 8) or (this[offset + 2] shl 16) or (this[offset + 3] shl 24)

    /**
     * If the four bytes at [offset] look like a GBA ROM pointer into this image
     * (high byte 0x08 or 0x09, target inside the file) returns the file offset it points to, else -1.
     */
    fun pointerTarget(offset: Int): Int {
        if (offset < 0 || offset + 4 > bytes.size) return -1
        val high = this[offset + 3]
        if (high != 0x08 && high != 0x09) return -1
        val target = readWord(offset) and 0x01FFFFFF
        return if (target < bytes.size) target else -1
    }

    /** Copy of up to [length] bytes starting at [offset], clamped to the image. */
    fun copyRange(offset: Int, length: Int): ByteArray {
        val start = offset.coerceIn(0, bytes.size)
        val end = (offset.toLong() + length).coerceIn(start.toLong(), bytes.size.toLong()).toInt()
        return bytes.copyOfRange(start, end)
    }

    internal fun setRange(offset: Int, data: ByteArray) {
        System.arraycopy(data, 0, bytes, offset, data.size)
    }

    /** Grows (zero filled) or shrinks the image. */
    internal fun resize(newSize: Int) {
        if (newSize != bytes.size) bytes = bytes.copyOf(newSize)
    }
}
