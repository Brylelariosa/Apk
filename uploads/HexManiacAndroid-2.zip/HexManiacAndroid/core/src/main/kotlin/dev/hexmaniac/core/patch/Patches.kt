package dev.hexmaniac.core.patch

/** The patch file formats the app can read and write. */
enum class PatchFormat(val extension: String) {
    Ips("ips"),
    Ups("ups"),
}

/** A patched ROM together with a short description of what happened, ready to show the user. */
class PatchOutcome(val data: ByteArray, val message: String)

/** One entry point for the patch formats: detect a file's format, apply it, or build a new patch. */
object Patches {
    /** The format of [patch] judged by its header, or null when it is neither IPS nor UPS. */
    fun detect(patch: ByteArray): PatchFormat? = when {
        startsWith(patch, "PATCH") -> PatchFormat.Ips
        startsWith(patch, "UPS1") -> PatchFormat.Ups
        else -> null
    }

    /**
     * Applies [patch] to [rom]. A UPS patch also works backwards: given the patched ROM it restores the original.
     * @throws PatchException when the file is not a supported patch or does not match [rom].
     */
    fun apply(rom: ByteArray, patch: ByteArray): PatchOutcome = when (detect(patch)) {
        PatchFormat.Ips -> PatchOutcome(Ips.apply(rom, patch).data, "IPS patch applied")
        PatchFormat.Ups -> when (val result = Ups.apply(rom, patch)) {
            is UpsResult.Success -> PatchOutcome(
                result.data,
                if (result.direction == UpsDirection.SourceToDestination) "UPS patch applied" else "UPS patch removed",
            )
            is UpsResult.Failure -> throw PatchException(result.reason)
        }
        null -> throw PatchException("Unsupported patch file. Only IPS and UPS patches can be applied.")
    }

    /**
     * Builds a patch that turns [original] into [edited].
     * @throws PatchException when the format cannot represent the change (IPS is limited to 16 MB).
     */
    fun build(format: PatchFormat, original: ByteArray, edited: ByteArray): ByteArray = when (format) {
        PatchFormat.Ips -> Ips.build(original, edited)
        PatchFormat.Ups -> Ups.build(original, edited)
    }

    private fun startsWith(data: ByteArray, magic: String): Boolean {
        if (data.size < magic.length) return false
        for (i in magic.indices) if (data[i].toInt() != magic[i].code) return false
        return true
    }
}
