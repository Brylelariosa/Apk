package dev.hexmaniac.core.rom

import dev.hexmaniac.core.text.PcsTable

/** Turns what the user typed into the search box into a [BytePattern]. */
object SearchQuery {
    /**
     * `0A ?? FF` searches for bytes (`??` matches any byte); `"HELLO` searches for text encoded in the game's
     * character set. A text query without a closing quote matches as a prefix, so partial words are found too.
     * Returns null when the text is empty or not a valid query.
     */
    fun parse(text: String, pcs: PcsTable, gameCode: String): BytePattern? {
        val query = text.trim()
        if (query.isEmpty()) return null
        if (!query.startsWith("\"")) return BytePattern.parse(query)
        val closed = query.length > 1 && query.endsWith("\"")
        var bytes = pcs.encode(query, gameCode).bytes
        // The encoder always appends the string terminator; without a closing quote it must not be searched for.
        if (!closed && bytes.isNotEmpty()) bytes = bytes.copyOf(bytes.size - 1)
        return BytePattern.exact(bytes)
    }
}
