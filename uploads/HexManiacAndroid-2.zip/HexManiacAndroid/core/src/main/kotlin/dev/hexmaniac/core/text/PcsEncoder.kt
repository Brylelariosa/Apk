package dev.hexmaniac.core.text

/**
 * Text to bytes. This is `PCSString.Convert(input, macroSet, out containsBadCharacters)`.
 *
 * The scan works left to right and at every position tries, in this order: a macro such as `[player]`, a raw
 * `\!XX` byte, a line separator, and finally every table entry in byte order. Backslash escapes (`\n`, `\Lv`,
 * `\CC`...) ignore upper/lower case unless the text is the start of a longer escape. Line separators in the input
 * become wrap (0xFE), feed (0xFA) or paragraph (0xFB) bytes depending on what came before, so that text written by
 * [PcsDecoder] encodes back to the same bytes.
 */
internal object PcsEncoder {
    private enum class NewlineMode { NONE, EXPLICIT, WRAP, FEED, PARAGRAPH }

    fun encode(table: PcsTable, text: String, gameCode: String): EncodeResult {
        var input = if (text.startsWith('"')) text.substring(1) else text
        // Editors on Windows-style text hand in CRLF; fold it so it counts as one line separator.
        if (table.newline == "\n" && input.indexOf('\r') >= 0) input = input.replace("\r\n", "\n")

        val newline = table.newline
        val doubleNewline = table.doubleNewline
        val macros = table.macroSetFor(gameCode)
        val entries = table.encodableEntries
        val result = ByteBuilder(input.length + 1)
        var hasBadCharacters = false

        var lastNewline = NewlineMode.NONE
        var nextNewline = NewlineMode.WRAP

        var index = 0
        while (index < input.length) {
            // macros: [name]
            if (macros != null && input[index] == '[') {
                val close = input.indexOf(']', index)
                if (close > index) {
                    val bytes = macros.bytesFor(input.substring(index, close + 1))
                    if (bytes != null) {
                        result.addAll(bytes)
                        index = close + 1
                        continue
                    }
                }
            }

            // raw byte: \!XX
            if (index < input.length - 4 && input[index] == '\\' && input[index + 1] == '!') {
                val value = PcsHex.parseTwoCharacters(input, index + 2)
                result.add(if (value < 0) 0 else value)
                index += 4
                continue
            }

            // line separators. After an explicit \n, \l or \pn the separator that follows is only formatting and is
            // skipped by the character scan below (which counts it as an unknown character, like HexManiac does).
            if (nextNewline != NewlineMode.EXPLICIT && input.startsWith(newline, index)) {
                if (input.startsWith(doubleNewline, index)) {
                    lastNewline = NewlineMode.PARAGRAPH
                    nextNewline = NewlineMode.WRAP
                    result.add(PcsBytes.PARAGRAPH)
                    index += doubleNewline.length
                } else if (nextNewline == NewlineMode.WRAP) {
                    lastNewline = NewlineMode.WRAP
                    nextNewline = NewlineMode.FEED
                    result.add(PcsBytes.NEWLINE)
                    index += newline.length
                } else {
                    lastNewline = NewlineMode.FEED
                    nextNewline = NewlineMode.FEED
                    result.add(PcsBytes.LINE_FEED)
                    index += newline.length
                }
                continue
            }

            // table entries and escape codes
            var foundMatch = false
            for (entry in entries) {
                val token = entry.token
                if (input.length < index + token.length) continue
                if (!matchesAt(table, input, index, entry)) continue

                val byte = entry.byte
                // a double quote is only the terminator when it is the very last character
                if (byte != PcsBytes.TERMINATOR || index == input.length - 1) result.add(byte)
                index += token.length - 1

                if (PcsBytes.takesOneArgument(byte) && input.length > index + 2) {
                    val argument = PcsHex.parseTwoCharacters(input, index + 1)
                    if (argument >= 0) result.add(argument)
                    index += 2
                }
                if (byte == PcsBytes.FUNCTION_ESCAPE && input.length > index + 2) {
                    val code = PcsHex.parseTwoCharacters(input, index + 1)
                    if (code >= 0) {
                        val codeLength = table.controlCodeLength(code)
                        result.add(code)
                        for (j in 1 until codeLength) {
                            if (input.length > index + 4) {
                                val argument = PcsHex.parseTwoCharacters(input, index + 3)
                                if (argument >= 0) result.add(argument)
                            }
                            index += 2
                        }
                    }
                    index += 2
                }

                if (PcsBytes.isNewlineByte(byte)) {
                    // HexManiac keeps the explicit break's kind swapped between wrap and paragraph; kept as is.
                    nextNewline = NewlineMode.EXPLICIT
                    lastNewline = when (byte) {
                        PcsBytes.LINE_FEED -> NewlineMode.FEED
                        PcsBytes.PARAGRAPH -> NewlineMode.WRAP
                        else -> NewlineMode.PARAGRAPH
                    }
                } else if (nextNewline == NewlineMode.EXPLICIT) {
                    nextNewline = if (lastNewline == NewlineMode.PARAGRAPH) NewlineMode.WRAP else NewlineMode.FEED
                }

                foundMatch = true
                break
            }
            if (!foundMatch) hasBadCharacters = true

            index++ // always move on, even when nothing matched
        }

        // every string ends with the 0xFF terminator
        if (result.size == 0 || result.last() != PcsBytes.TERMINATOR) result.add(PcsBytes.TERMINATOR)
        return EncodeResult(result.toByteArray(), hasBadCharacters)
    }

    /**
     * Does [entry]'s text appear in [input] at [index]? Plain characters must match exactly. A backslash escape also
     * matches with different capitalisation, unless the characters there are the beginning of a longer escape.
     * The caller has already checked that the input is long enough.
     */
    private fun matchesAt(table: PcsTable, input: String, index: Int, entry: PcsTable.Entry): Boolean {
        val token = entry.token
        if (input.startsWith(token, index)) return true
        if (!entry.isEscape) return false
        for (i in token.indices) {
            if (input[index + i].uppercaseChar() != token[i].uppercaseChar()) return false
        }
        return !table.validInProgressEscapes.contains(input.substring(index, index + token.length))
    }
}
