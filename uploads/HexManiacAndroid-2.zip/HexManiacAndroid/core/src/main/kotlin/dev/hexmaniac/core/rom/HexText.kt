package dev.hexmaniac.core.rom

/** Parsing and formatting of the hexadecimal text users type and read. */
object HexText {
    private const val DIGITS = "0123456789ABCDEF"

    /** Upper-case hex of [value] padded to [digits] digits. */
    fun hex(value: Int, digits: Int): String {
        val chars = CharArray(digits)
        var v = value
        for (i in digits - 1 downTo 0) {
            chars[i] = DIGITS[v and 0xF]
            v = v ushr 4
        }
        return String(chars)
    }

    /** "0A 1B 2C" for [length] bytes starting at [offset] (clamped to the data). */
    fun format(data: ByteArray, offset: Int, length: Int): String {
        val sb = StringBuilder()
        val end = minOf(data.size, offset + length)
        for (i in offset until end) {
            if (sb.isNotEmpty()) sb.append(' ')
            val b = data[i].toInt() and 0xFF
            sb.append(DIGITS[b ushr 4]).append(DIGITS[b and 0xF])
        }
        return sb.toString()
    }

    /**
     * Parses "0A 1b ff", "0x0A,0x1B" or "0A1B" into bytes. Returns null when the text is empty,
     * contains anything but hex digits/separators or has an odd number of digits in a token.
     */
    fun parseBytes(text: String): ByteArray? {
        val out = java.io.ByteArrayOutputStream()
        for (token in tokens(text)) {
            val digits = stripPrefix(token)
            if (digits.isEmpty() || digits.length % 2 != 0 || !digits.all { isHex(it) }) return null
            var i = 0
            while (i < digits.length) {
                out.write(digits.substring(i, i + 2).toInt(16))
                i += 2
            }
        }
        val result = out.toByteArray()
        return if (result.isEmpty()) null else result
    }

    /**
     * Parses a ROM address: "1A2B3C", "0x1A2B3C", "$1A2B3C". A GBA pointer (08xxxxxx / 09xxxxxx) is
     * converted to the file offset it refers to. Returns null when it is not a valid address.
     */
    fun parseAddress(text: String): Int? {
        val digits = stripPrefix(text.trim())
        if (digits.isEmpty() || digits.length > 8 || !digits.all { isHex(it) }) return null
        val value = digits.toLong(16)
        if (value in 0x08000000L..0x0BFFFFFFL) return (value and 0x01FFFFFFL).toInt()
        return if (value <= Int.MAX_VALUE) value.toInt() else null
    }

    internal fun tokens(text: String): List<String> =
        text.replace(',', ' ').split(' ', '\t', '\n', '\r').filter { it.isNotEmpty() }

    internal fun stripPrefix(token: String): String = when {
        token.startsWith("0x") || token.startsWith("0X") -> token.substring(2)
        token.startsWith("$") -> token.substring(1)
        else -> token
    }

    private fun isHex(c: Char) = c in '0'..'9' || c in 'a'..'f' || c in 'A'..'F'
}
