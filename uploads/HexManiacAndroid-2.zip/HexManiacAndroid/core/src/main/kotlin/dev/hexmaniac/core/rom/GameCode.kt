package dev.hexmaniac.core.rom

/**
 * The four character game code at 0xAC plus the version byte at 0xBC, e.g. "BPRE" + 0 = "BPRE0"
 * (FireRed 1.0 US). HexManiac keys all of its per-game reference data on this value.
 */
data class GameCode(val code: String, val version: Int) {
    /** Code and version joined, e.g. "BPRE0". */
    val full: String get() = "$code$version"

    /** Human readable game, or null for games HexManiac has no name for. */
    val gameName: String?
        get() = when (code.take(3)) {
            "AXV" -> "Ruby"
            "AXP" -> "Sapphire"
            "BPE" -> "Emerald"
            "BPR" -> "FireRed"
            "BPG" -> "LeafGreen"
            else -> null
        }

    val language: String?
        get() = when (code.getOrNull(3)) {
            'E' -> "English"
            'F' -> "French"
            'I' -> "Italian"
            'S' -> "Spanish"
            'D' -> "German"
            'J' -> "Japanese"
            else -> null
        }

    /** True for the releases whose data tables HexManiac knows. */
    val hasTableSupport: Boolean get() = full in SUPPORTED

    /** "FireRed (English) rev 0", or the raw code when the game is unknown. */
    val displayName: String
        get() {
            val game = gameName ?: return full
            return buildString {
                append(game)
                language?.let { append(" (").append(it).append(")") }
                append(" v").append(version)
            }
        }

    companion object {
        val SUPPORTED: Set<String> = setOf(
            "AXVE0", "AXPE0", "BPEE0", "BPRE0", "BPGE0", "AXVE1", "AXPE1", "BPRE1", "BPGE1",
            "BPRF0", "BPRI0", "BPEF0", "BPEI0",
        )
    }
}

/** The cartridge header fields HexManiac cares about. */
class RomHeader(val title: String, val game: GameCode?, val maker: String) {
    companion object {
        private const val TITLE = 0xA0
        private const val GAME_CODE = 0xAC
        private const val MAKER = 0xB0
        private const val VERSION = 0xBC

        fun read(rom: RomData): RomHeader {
            if (rom.size <= VERSION) return RomHeader("", null, "")
            val title = readAscii(rom, TITLE, 12)
            val code = readAscii(rom, GAME_CODE, 4)
            val maker = readAscii(rom, MAKER, 2)
            val valid = code.length == 4 && code.all { it in 'A'..'Z' || it in '0'..'9' }
            return RomHeader(title, if (valid) GameCode(code, rom[VERSION]) else null, maker)
        }

        private fun readAscii(rom: RomData, offset: Int, length: Int): String {
            val sb = StringBuilder()
            for (i in 0 until length) {
                val b = rom[offset + i]
                if (b == 0) break
                sb.append(if (b in 0x20..0x7E) b.toChar() else '?')
            }
            return sb.toString()
        }
    }
}
