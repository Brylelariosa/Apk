import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// Pure-JVM engine: ROM model, table-format DSL, text codec, compression, patching, graphics.
// No Android dependencies, so it is unit-testable on any JVM.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}

tasks.test {
    useJUnit()
}
