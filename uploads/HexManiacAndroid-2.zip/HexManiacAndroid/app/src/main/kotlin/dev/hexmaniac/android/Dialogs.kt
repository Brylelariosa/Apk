package dev.hexmaniac.android

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.text.InputType
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast

/** Density-independent pixels to pixels. */
fun Activity.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun Activity.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun Activity.showMessage(title: String, message: String) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton("OK", null)
        .show()
}

/** Asks for one line of text (monospace, no suggestions) and calls [onOk] with it. */
fun Activity.promptText(
    title: String,
    message: String?,
    initial: String,
    hint: String,
    positive: String = "OK",
    onOk: (String) -> Unit,
) {
    val input = EditText(this)
    input.setText(initial)
    input.hint = hint
    input.typeface = Typeface.MONOSPACE
    input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    input.setSelectAllOnFocus(true)
    val box = FrameLayout(this)
    box.setPadding(dp(20), dp(8), dp(20), 0)
    box.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    val builder = AlertDialog.Builder(this).setTitle(title).setView(box)
    if (message != null) builder.setMessage(message)
    builder.setPositiveButton(positive) { _, _ -> onOk(input.text.toString()) }
    builder.setNegativeButton("Cancel", null)
    val dialog = builder.create()
    dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    dialog.show()
}

fun Activity.confirm(title: String, message: String, positive: String, onYes: () -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(positive) { _, _ -> onYes() }
        .setNegativeButton("Cancel", null)
        .show()
}

fun Activity.choose(title: String, items: Array<String>, onPick: (Int) -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setItems(items) { _, which -> onPick(which) }
        .show()
}
