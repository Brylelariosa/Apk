package dev.hexmaniac.android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.OverScroller
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.text.PcsTable
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * A scrollable hex dump of a [RomDocument]: address column, hex bytes (pointers tinted, 00/FF dimmed)
 * and an optional text column that shows each byte in the game's character set.
 *
 * Gestures: drag/fling to scroll, drag the right edge to jump through the file, pinch to zoom,
 * tap to select a byte, double-tap or long-press to act on it (see [onFollowRequested] / [onEditRequested]).
 * The view only draws and reports taps; editing is done by the activity through the document.
 */
class HexView(context: Context) : View(context) {

    /** The ROM being shown; setting it resets selection and scroll position. */
    var document: RomDocument? = null
        set(value) {
            field = value
            selStart = 0
            selLength = 1
            scrollPx = 0
            layoutDirty = true
            invalidate()
        }

    /** Character set used by the text column. */
    var pcs: PcsTable = PcsTable.DEFAULT
        set(value) {
            field = value
            columnChars = Array(256) { value.columnChar(it) }
            invalidate()
        }

    var showText: Boolean = true
        set(value) {
            field = value
            layoutDirty = true
            invalidate()
        }

    /** First selected byte. */
    var selStart: Int = 0
        private set

    /** Number of selected bytes (at least 1). */
    var selLength: Int = 1
        private set

    var onSelectionChanged: (() -> Unit)? = null
    var onEditRequested: (() -> Unit)? = null
    var onFollowRequested: (() -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scroller = OverScroller(context)
    private var columnChars: Array<String> = Array(256) { PcsTable.DEFAULT.columnChar(it) }
    private val digits = "0123456789ABCDEF".toCharArray()
    private val pair = CharArray(2)
    private val addressBuffer = CharArray(8)

    private var textSizeSp = 14f
    private var layoutDirty = true
    private var laidOutWidth = -1
    private var charWidth = 1f
    private var rowHeight = 1
    private var baseline = 0f
    private var bytesPerRow = 8
    private var addressDigits = 6
    private var scrollPx = 0
    private var fastScrolling = false

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            scroller.forceFinished(true)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            scrollPx += distanceY.toInt()
            clampScroll()
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            scroller.fling(0, scrollPx, 0, (-velocityY).toInt(), 0, 0, 0, maxScroll())
            postInvalidateOnAnimation()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val offset = offsetAt(e.x, e.y)
            if (offset >= 0) select(offset, 1)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val offset = offsetAt(e.x, e.y)
            if (offset >= 0) {
                if (offset < selStart || offset >= selStart + selLength) select(offset, 1)
                onFollowRequested?.invoke()
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            val offset = offsetAt(e.x, e.y)
            if (offset >= 0) {
                if (offset < selStart || offset >= selStart + selLength) select(offset, 1)
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                onEditRequested?.invoke()
            }
        }
    })

    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val topOffset = (scrollPx / rowHeight) * bytesPerRow
            textSizeSp = (textSizeSp * detector.scaleFactor).coerceIn(8f, 30f)
            layoutDirty = true
            ensureLayout()
            scrollPx = (topOffset / bytesPerRow) * rowHeight
            clampScroll()
            invalidate()
            return true
        }
    })

    // ---------------------------------------------------------------- public API

    /** Redraws after the document changed (also fixes scroll/selection if the ROM got smaller). */
    fun refresh() {
        val doc = document
        if (doc != null && selStart >= doc.rom.size) {
            selStart = max(0, doc.rom.size - 1)
            selLength = 1
        }
        layoutDirty = true
        clampScroll()
        invalidate()
    }

    /** Selects [length] bytes at [offset] and scrolls them into view (a third of the way down the screen). */
    fun goTo(offset: Int, length: Int = 1) {
        if (document == null) return
        if (width == 0) {
            post { goTo(offset, length) }
            return
        }
        ensureLayout()
        setSelection(offset, length)
        scrollPx = (selStart / bytesPerRow) * rowHeight - height / 3
        clampScroll()
        scroller.forceFinished(true)
        invalidate()
    }

    /** Selects [length] bytes at [offset], scrolling only when the selection is off screen. */
    fun select(offset: Int, length: Int = 1) {
        if (document == null) return
        setSelection(offset, length)
        ensureLayout()
        val top = (selStart / bytesPerRow) * rowHeight
        if (top < scrollPx || top + rowHeight > scrollPx + height) {
            scrollPx = top - height / 3
            clampScroll()
        }
        invalidate()
    }

    /** Grows or shrinks the selection by [delta] bytes (never below one byte). */
    fun resizeSelection(delta: Int) {
        select(selStart, selLength + delta)
    }

    /** Selects the 4-byte word containing the current selection start. */
    fun selectWord() {
        select(selStart and 3.inv(), 4)
    }

    // ---------------------------------------------------------------- layout

    private fun spToPx(sp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)

    private fun dpToPx(dp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

    private fun charsNeeded(n: Int): Int = addressDigits + 2 + n * 3 + (if (showText) 1 + n else 0)

    private fun ensureLayout() {
        if (!layoutDirty && width == laidOutWidth) return
        paint.typeface = Typeface.MONOSPACE
        paint.textSize = spToPx(textSizeSp)
        charWidth = paint.measureText("0")
        val metrics = paint.fontMetrics
        rowHeight = max(1, ceil(metrics.descent - metrics.ascent + dpToPx(4f)).toInt())
        baseline = -metrics.ascent + dpToPx(2f)
        val size = document?.rom?.size ?: 0
        addressDigits = if (size > 0x1000000) 7 else 6
        val usable = width - 2 * dpToPx(PADDING_DP) - dpToPx(SCROLL_ZONE_DP)
        val chars = (usable / charWidth).toInt()
        var n = 32
        while (n > 4 && charsNeeded(n) > chars) n -= 4
        bytesPerRow = n
        layoutDirty = false
        laidOutWidth = width
        clampScroll()
    }

    private fun totalRows(): Int {
        val size = document?.rom?.size ?: return 0
        return (size + bytesPerRow - 1) / bytesPerRow
    }

    private fun maxScroll(): Int {
        val content = totalRows().toLong() * rowHeight
        return max(0L, content - height).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    }

    private fun clampScroll() {
        scrollPx = scrollPx.coerceIn(0, maxScroll())
    }

    private fun hexStartX(): Float = dpToPx(PADDING_DP) + (addressDigits + 2) * charWidth

    private fun textStartX(): Float = hexStartX() + bytesPerRow * 3 * charWidth + charWidth

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutDirty = true
    }

    // ---------------------------------------------------------------- selection

    private fun setSelection(offset: Int, length: Int) {
        val size = document?.rom?.size ?: return
        if (size == 0) return
        selStart = offset.coerceIn(0, size - 1)
        selLength = length.coerceIn(1, size - selStart)
        onSelectionChanged?.invoke()
    }

    /** The byte under a touch point, or -1 when there is none. */
    private fun offsetAt(x: Float, y: Float): Int {
        val size = document?.rom?.size ?: return -1
        if (size == 0) return -1
        ensureLayout()
        val row = (scrollPx + y.toInt()) / rowHeight
        val textX = textStartX()
        val column = if (showText && x >= textX - charWidth * 0.5f) {
            ((x - textX) / charWidth).toInt()
        } else {
            ((x - hexStartX() + charWidth * 0.5f) / (3 * charWidth)).toInt()
        }
        val offset = row * bytesPerRow + column.coerceIn(0, bytesPerRow - 1)
        return offset.coerceIn(0, size - 1)
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)
        if (scaler.isInProgress) return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (document != null && event.x > width - dpToPx(SCROLL_ZONE_DP)) {
                    fastScrolling = true
                    scroller.forceFinished(true)
                    fastScrollTo(event.y)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (fastScrolling) {
                    fastScrollTo(event.y)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (fastScrolling) {
                    fastScrolling = false
                    invalidate()
                    return true
                }
            }
        }
        return gestures.onTouchEvent(event)
    }

    private fun thumbHeight(): Float {
        val content = totalRows().toLong() * rowHeight
        if (content <= 0) return height.toFloat()
        return max(dpToPx(36f), height.toFloat() * height / content)
    }

    private fun fastScrollTo(y: Float) {
        ensureLayout()
        val thumb = thumbHeight()
        val travel = max(1f, height - thumb)
        val ratio = ((y - thumb / 2) / travel).coerceIn(0f, 1f)
        scrollPx = (ratio * maxScroll()).toInt()
        invalidate()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollPx = scroller.currY
            clampScroll()
            postInvalidateOnAnimation()
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun drawByte(canvas: Canvas, value: Int, x: Float, y: Float) {
        pair[0] = digits[value ushr 4]
        pair[1] = digits[value and 15]
        canvas.drawText(pair, 0, 2, x, y, paint)
    }

    private fun drawAddress(canvas: Canvas, value: Int, x: Float, y: Float) {
        var shift = (addressDigits - 1) * 4
        for (i in 0 until addressDigits) {
            addressBuffer[i] = digits[(value ushr shift) and 15]
            shift -= 4
        }
        canvas.drawText(addressBuffer, 0, addressDigits, x, y, paint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(COLOR_BG)
        val doc = document
        if (doc == null) {
            paint.typeface = Typeface.DEFAULT
            paint.textSize = spToPx(16f)
            paint.color = COLOR_ADDRESS
            canvas.drawText("Open a ROM from the menu.", dpToPx(16f), dpToPx(48f), paint)
            layoutDirty = true
            return
        }
        ensureLayout()
        val rom = doc.rom
        val n = bytesPerRow
        val rows = totalRows()
        if (rows == 0) return
        val padding = dpToPx(PADDING_DP)
        val firstRow = max(0, scrollPx / rowHeight)
        val lastRow = min(rows - 1, (scrollPx + height) / rowHeight)
        val hexX0 = hexStartX()
        val textX0 = textStartX()
        val selEnd = selStart + selLength
        val half = charWidth * 0.5f
        for (row in firstRow..lastRow) {
            val top = row * rowHeight - scrollPx
            val y = top + baseline
            val rowStart = row * n
            paint.color = COLOR_ADDRESS
            drawAddress(canvas, rowStart, padding, y)
            for (i in 0 until n) {
                val offset = rowStart + i
                if (offset >= rom.size) break
                val value = rom[offset]
                val x = hexX0 + i * 3 * charWidth
                val selected = offset >= selStart && offset < selEnd
                val pointer = rom.pointerTarget(offset and 3.inv()) >= 0
                if (selected) {
                    paint.color = COLOR_SELECTION
                    canvas.drawRect(x - half, top.toFloat(), x + charWidth * 2.5f, (top + rowHeight).toFloat(), paint)
                }
                paint.color = when {
                    selected -> COLOR_SELECTION_TEXT
                    pointer -> COLOR_POINTER
                    value == 0 || value == 0xFF -> COLOR_DIM
                    else -> COLOR_TEXT
                }
                drawByte(canvas, value, x, y)
                if (showText) {
                    val tx = textX0 + i * charWidth
                    if (selected) {
                        paint.color = COLOR_SELECTION
                        canvas.drawRect(tx, top.toFloat(), tx + charWidth, (top + rowHeight).toFloat(), paint)
                        paint.color = COLOR_SELECTION_TEXT
                    }
                    canvas.drawText(columnChars[value], tx, y, paint)
                }
            }
        }
        drawScrollbar(canvas)
    }

    private fun drawScrollbar(canvas: Canvas) {
        val content = totalRows().toLong() * rowHeight
        if (content <= height) return
        val thumb = thumbHeight()
        val maxScroll = maxScroll()
        val ratio = if (maxScroll > 0) scrollPx.toFloat() / maxScroll else 0f
        val thumbTop = ratio * (height - thumb)
        val barWidth = if (fastScrolling) dpToPx(10f) else dpToPx(4f)
        val right = width - dpToPx(2f)
        paint.color = if (fastScrolling) COLOR_THUMB_ACTIVE else COLOR_THUMB
        canvas.drawRect(right - barWidth, thumbTop, right, thumbTop + thumb, paint)
    }

    private companion object {
        const val PADDING_DP = 8f
        const val SCROLL_ZONE_DP = 28f

        val COLOR_BG = 0xFF101820.toInt()
        val COLOR_ADDRESS = 0xFF6B7A90.toInt()
        val COLOR_TEXT = 0xFFD6DEE8.toInt()
        val COLOR_DIM = 0xFF4A5565.toInt()
        val COLOR_POINTER = 0xFF6EC1FF.toInt()
        val COLOR_SELECTION = 0xFF2F5C8F.toInt()
        val COLOR_SELECTION_TEXT = 0xFFFFFFFF.toInt()
        val COLOR_THUMB = 0x668FA3BF.toInt()
        val COLOR_THUMB_ACTIVE = 0xCC8FA3BF.toInt()
    }
}
