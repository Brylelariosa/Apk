package dev.hexmaniac.android

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.patch.PatchFormat
import dev.hexmaniac.core.patch.Patches
import dev.hexmaniac.core.rom.BytePattern
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.rom.RomInfo
import dev.hexmaniac.core.rom.RomSearch
import dev.hexmaniac.core.rom.SearchQuery
import dev.hexmaniac.core.text.PcsTable

/**
 * The single screen of the app: a hex dump of the open ROM, an info strip with the value under the cursor
 * and a row of selection buttons. File access, patching and searching live in the menu.
 * All ROM logic is in the `core` module; this class only wires views, dialogs and the file picker.
 */
class MainActivity : Activity() {

    private lateinit var hexView: HexView
    private lateinit var infoText: TextView

    private val pcs: PcsTable by lazy { loadPcs() }
    private var document: RomDocument? = null
    private var fileUri: Uri? = null
    private var displayName: String = ""
    private val backStack = ArrayList<Int>()
    private var lastPattern: BytePattern? = null
    private var busyDialog: AlertDialog? = null
    private var pendingPatch: ByteArray? = null
    private var pendingPatchFormat: PatchFormat = PatchFormat.Ips

    private val documentListener = RomDocument.Listener { onDocumentChanged() }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "HexManiac"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF101820.toInt())

        infoText = TextView(this)
        infoText.typeface = Typeface.MONOSPACE
        infoText.textSize = 12f
        infoText.setTextColor(0xFFB8C4D4.toInt())
        infoText.setBackgroundColor(0xFF18222E.toInt())
        infoText.setPadding(dp(10), dp(6), dp(10), dp(6))
        infoText.minLines = 3
        infoText.maxLines = 3

        hexView = HexView(this)
        hexView.pcs = pcs
        hexView.onSelectionChanged = { updateInfo() }
        hexView.onEditRequested = { editSelection() }
        hexView.onFollowRequested = { followPointer() }

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xFF18222E.toInt())
        bar.addView(barButton("−1") { hexView.resizeSelection(-1) }, barParams())
        bar.addView(barButton("+1") { hexView.resizeSelection(1) }, barParams())
        bar.addView(barButton("Word") { hexView.selectWord() }, barParams())
        bar.addView(barButton("Edit") { editSelection() }, barParams())
        bar.addView(barButton("Follow") { followPointer() }, barParams())
        bar.addView(barButton("Back") { goBack() }, barParams())

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        root.addView(infoText, LinearLayout.LayoutParams(match, wrap))
        root.addView(hexView, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(match, wrap))
        setContentView(root)
        updateInfo()
    }

    override fun onDestroy() {
        hideBusy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val doc = document
        if (doc != null && doc.isDirty) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved changes")
                .setMessage("Leave without saving?")
                .setPositiveButton("Save and exit") { _, _ -> save(thenFinish = true) }
                .setNegativeButton("Discard") { _, _ -> finish() }
                .setNeutralButton("Cancel", null)
                .show()
        } else {
            super.onBackPressed()
        }
    }

    private fun barButton(label: String, action: () -> Unit): Button {
        val button = Button(this)
        button.text = label
        button.textSize = 12f
        button.isAllCaps = false
        button.minWidth = 0
        button.minimumWidth = 0
        button.setPadding(dp(4), dp(8), dp(4), dp(8))
        button.setOnClickListener { action() }
        return button
    }

    private fun barParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun loadPcs(): PcsTable = try {
        PcsTable.load(ClasspathResources())
    } catch (e: Throwable) {
        PcsTable.DEFAULT
    }

    // ------------------------------------------------------------------ menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        addItem(menu, ID_OPEN, "Open ROM…", MenuItem.SHOW_AS_ACTION_IF_ROOM)
        addItem(menu, ID_SAVE, "Save", MenuItem.SHOW_AS_ACTION_IF_ROOM)
        addItem(menu, ID_UNDO, "Undo", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_REDO, "Redo", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_GOTO, "Go to…", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_FIND, "Find…", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_FIND_NEXT, "Find next", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_SAVE_AS, "Save as…", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_APPLY_PATCH, "Apply patch (IPS/UPS)…", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_CREATE_PATCH, "Create patch…", MenuItem.SHOW_AS_ACTION_NEVER)
        addItem(menu, ID_INFO, "ROM info", MenuItem.SHOW_AS_ACTION_NEVER)
        val text = menu.add(Menu.NONE, ID_TOGGLE_TEXT, Menu.NONE, "Text column")
        text.setCheckable(true)
        text.setChecked(hexView.showText)
        text.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER)
        return true
    }

    private fun addItem(menu: Menu, id: Int, label: String, showAs: Int) {
        menu.add(Menu.NONE, id, Menu.NONE, label).setShowAsAction(showAs)
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val doc = document
        val open = doc != null
        for (id in intArrayOf(ID_SAVE, ID_SAVE_AS, ID_GOTO, ID_FIND, ID_APPLY_PATCH, ID_CREATE_PATCH, ID_INFO)) {
            menu.findItem(id)?.setEnabled(open)
        }
        menu.findItem(ID_FIND_NEXT)?.setEnabled(open && lastPattern != null)
        val undoLabel = doc?.undoLabel
        menu.findItem(ID_UNDO)?.setEnabled(doc?.canUndo == true)
        menu.findItem(ID_UNDO)?.setTitle(if (undoLabel != null) "Undo: $undoLabel" else "Undo")
        val redoLabel = doc?.redoLabel
        menu.findItem(ID_REDO)?.setEnabled(doc?.canRedo == true)
        menu.findItem(ID_REDO)?.setTitle(if (redoLabel != null) "Redo: $redoLabel" else "Redo")
        menu.findItem(ID_SAVE)?.setTitle(if (doc != null && doc.isDirty) "Save •" else "Save")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            ID_OPEN -> openRom()
            ID_SAVE -> save(thenFinish = false)
            ID_SAVE_AS -> saveAs()
            ID_UNDO -> document?.undo()
            ID_REDO -> document?.redo()
            ID_GOTO -> promptGoto()
            ID_FIND -> promptFind()
            ID_FIND_NEXT -> findNext()
            ID_APPLY_PATCH -> pickFile(REQ_OPEN_PATCH)
            ID_CREATE_PATCH -> startCreatePatch()
            ID_INFO -> showInfo()
            ID_TOGGLE_TEXT -> {
                hexView.showText = !hexView.showText
                item.setChecked(hexView.showText)
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ------------------------------------------------------------------ file picking

    private fun pickFile(requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION,
        )
        startActivityForResult(intent, requestCode)
    }

    private fun createFile(requestCode: Int, suggestedName: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/octet-stream"
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName)
        startActivityForResult(intent, requestCode)
    }

    private fun openRom() {
        val doc = document
        if (doc != null && doc.isDirty) {
            confirm("Unsaved changes", "Open another ROM and discard the changes to ${displayName}?", "Discard") {
                pickFile(REQ_OPEN_ROM)
            }
        } else {
            pickFile(REQ_OPEN_ROM)
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        val uri = data.data ?: return
        when (requestCode) {
            REQ_OPEN_ROM -> {
                try {
                    val keep = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    contentResolver.takePersistableUriPermission(uri, keep)
                } catch (e: Exception) {
                    // the grant stays valid for this session even if it cannot be made permanent
                }
                loadRom(uri)
            }
            REQ_SAVE_AS -> saveTo(uri, makeCurrent = true, thenFinish = false)
            REQ_OPEN_PATCH -> applyPatchFrom(uri)
            REQ_PICK_ORIGINAL -> buildPatchAgainst(uri)
            REQ_CREATE_PATCH -> writePendingPatch(uri)
        }
    }

    // ------------------------------------------------------------------ open / save

    private fun loadRom(uri: Uri) {
        runBusy("Opening…", {
            val bytes = RomFiles.read(contentResolver, uri)
            val name = RomFiles.displayName(contentResolver, uri)
            Backups.save(this, name, bytes)
            RomDocument(name, bytes)
        }) { doc ->
            document?.removeListener(documentListener)
            document = doc
            fileUri = uri
            displayName = doc.name
            backStack.clear()
            lastPattern = null
            doc.addListener(documentListener)
            hexView.document = doc
            hexView.goTo(0)
            title = doc.name
            updateInfo()
            invalidateOptionsMenu()
        }
    }

    private fun save(thenFinish: Boolean) {
        val uri = fileUri
        if (document == null) return
        if (uri == null) saveAs() else saveTo(uri, makeCurrent = false, thenFinish = thenFinish)
    }

    private fun saveAs() {
        if (document == null) return
        createFile(REQ_SAVE_AS, displayName.ifEmpty { "rom.gba" })
    }

    private fun saveTo(uri: Uri, makeCurrent: Boolean, thenFinish: Boolean) {
        val doc = document ?: return
        runBusy("Saving…", { RomFiles.write(contentResolver, uri, doc.rom.bytes) }) {
            if (makeCurrent) fileUri = uri
            doc.markSaved()
            toast("Saved")
            if (thenFinish) finish()
        }
    }

    // ------------------------------------------------------------------ navigation and editing

    private fun onDocumentChanged() {
        hexView.refresh()
        updateInfo()
        invalidateOptionsMenu()
    }

    private fun promptGoto() {
        val doc = document ?: return
        promptText("Go to", "Hex offset, or a pointer like 08123456", HexText.hex(hexView.selStart, 6), "offset") { text ->
            val address = HexText.parseAddress(text)
            if (address == null || address >= doc.rom.size) {
                toast("Not a valid offset (the ROM has ${doc.rom.size} bytes)")
            } else {
                pushBack()
                hexView.goTo(address)
            }
        }
    }

    private fun pushBack() {
        backStack.add(hexView.selStart)
        if (backStack.size > 100) backStack.removeAt(0)
    }

    private fun goBack() {
        if (backStack.isEmpty()) {
            toast("Nothing to go back to")
            return
        }
        hexView.goTo(backStack.removeAt(backStack.size - 1))
    }

    private fun followPointer() {
        val doc = document ?: return
        val start = hexView.selStart
        var target = doc.rom.pointerTarget(start)
        if (target < 0) target = doc.rom.pointerTarget(start and 3.inv())
        if (target < 0) {
            toast("No pointer here")
            return
        }
        pushBack()
        hexView.goTo(target)
    }

    private fun editSelection() {
        val doc = document ?: return
        val start = hexView.selStart
        val current = HexText.format(doc.rom.bytes, start, hexView.selLength)
        promptText("Edit bytes at ${HexText.hex(start, 6)}", "Hex bytes, overwritten from the selection start", current, "0A 1B 2C") { text ->
            val bytes = HexText.parseBytes(text)
            when {
                bytes == null -> toast("Enter hex bytes like 0A 1B 2C")
                start + bytes.size > doc.rom.size -> toast("That runs past the end of the ROM")
                else -> {
                    doc.write(start, bytes, "Edit ${HexText.hex(start, 6)}")
                    hexView.select(start, bytes.size)
                }
            }
        }
    }

    // ------------------------------------------------------------------ search

    private fun promptFind() {
        if (document == null) return
        promptText(
            "Find",
            "Hex bytes (?? matches any byte), or \"text\" in the game's character set",
            "",
            "0A ?? FF  or  \"HELLO\"",
        ) { text ->
            val pattern = SearchQuery.parse(text, pcs, document?.header?.game?.full ?: "")
            if (pattern == null) {
                toast("Enter hex bytes like 0A ?? FF, or text in quotes")
            } else {
                lastPattern = pattern
                invalidateOptionsMenu()
                search(pattern, hexView.selStart)
            }
        }
    }

    private fun findNext() {
        val pattern = lastPattern ?: return
        search(pattern, hexView.selStart + 1)
    }

    private fun search(pattern: BytePattern, from: Int) {
        val doc = document ?: return
        runBusy("Searching…", { RomSearch.findWrapping(doc.rom.bytes, pattern, from) }) { hit ->
            if (hit < 0) toast("Not found") else hexView.goTo(hit, pattern.length)
        }
    }

    // ------------------------------------------------------------------ patches

    private fun applyPatchFrom(uri: Uri) {
        val doc = document ?: return
        runBusy("Applying patch…", {
            Patches.apply(doc.rom.bytes, RomFiles.read(contentResolver, uri))
        }) { outcome ->
            doc.replaceAll(outcome.data, "Apply patch")
            toast(outcome.message)
        }
    }

    private fun startCreatePatch() {
        if (document == null) return
        choose("Create patch", arrayOf("IPS (ROMs up to 16 MB)", "UPS (any size, with checksums)")) { index ->
            pendingPatchFormat = if (index == 0) PatchFormat.Ips else PatchFormat.Ups
            confirm(
                "Original ROM",
                "Pick the original, unmodified ROM. The patch will turn it into the ROM you are editing now.",
                "Pick file",
            ) { pickFile(REQ_PICK_ORIGINAL) }
        }
    }

    private fun buildPatchAgainst(uri: Uri) {
        val doc = document ?: return
        val format = pendingPatchFormat
        runBusy("Building patch…", {
            Patches.build(format, RomFiles.read(contentResolver, uri), doc.rom.bytes)
        }) { patch ->
            pendingPatch = patch
            val base = displayName.substringBeforeLast('.', displayName).ifEmpty { "rom" }
            createFile(REQ_CREATE_PATCH, "$base.${format.extension}")
        }
    }

    private fun writePendingPatch(uri: Uri) {
        val patch = pendingPatch ?: return
        runBusy("Saving patch…", { RomFiles.write(contentResolver, uri, patch) }) {
            pendingPatch = null
            toast("Patch saved")
        }
    }

    // ------------------------------------------------------------------ info

    private fun updateInfo() {
        val doc = document
        infoText.text = if (doc == null) {
            "No ROM open.\nMenu → Open ROM…\nTap = select, double-tap = follow pointer, long-press = edit."
        } else {
            RomInfo.cursorSummary(doc, displayName, hexView.selStart, pcs)
        }
    }

    private fun showInfo() {
        val doc = document ?: return
        showMessage("ROM info", RomInfo.details(doc, displayName))
    }

    // ------------------------------------------------------------------ background work

    /** Runs [work] on a background thread behind a modal "busy" dialog and delivers the result on the UI thread. */
    private fun <T> runBusy(message: String, work: () -> T, done: (T) -> Unit) {
        showBusy(message)
        Thread {
            var result: T? = null
            var failure: Throwable? = null
            try {
                result = work()
            } catch (t: Throwable) {
                failure = t
            }
            runOnUiThread {
                hideBusy()
                if (failure != null) {
                    showError(failure)
                } else {
                    try {
                        @Suppress("UNCHECKED_CAST")
                        done(result as T)
                    } catch (t: Throwable) {
                        showError(t)
                    }
                }
            }
        }.start()
    }

    private fun showBusy(message: String) {
        hideBusy()
        val dialog = AlertDialog.Builder(this).setMessage(message).setCancelable(false).create()
        dialog.show()
        busyDialog = dialog
    }

    private fun hideBusy() {
        busyDialog?.dismiss()
        busyDialog = null
    }

    private fun showError(t: Throwable) {
        val text = when (t) {
            is OutOfMemoryError -> "Out of memory."
            else -> t.message ?: t.javaClass.simpleName
        }
        showMessage("Error", text)
    }

    private companion object {
        const val REQ_OPEN_ROM = 1
        const val REQ_SAVE_AS = 2
        const val REQ_OPEN_PATCH = 3
        const val REQ_PICK_ORIGINAL = 4
        const val REQ_CREATE_PATCH = 5

        const val ID_OPEN = 1
        const val ID_SAVE = 2
        const val ID_UNDO = 3
        const val ID_REDO = 4
        const val ID_GOTO = 5
        const val ID_FIND = 6
        const val ID_FIND_NEXT = 7
        const val ID_SAVE_AS = 8
        const val ID_APPLY_PATCH = 9
        const val ID_CREATE_PATCH = 10
        const val ID_INFO = 11
        const val ID_TOGGLE_TEXT = 12
    }
}
