# Project state

Last updated: 2026-11-11 (session 1)

## Delivered (this ZIP)
- Stage 1: Gradle + Cargo workspace, JNI bridge, UI shell (9 screens), device + GPU detection.
- Stage 2: Vulkan (ash) + OpenGL ES (EGL) probing, wgpu GPU engine, CPU engine.
- Stage 3: CPU vs GPU benchmarks, monitor screen.
- Stage 4: hybrid CPU+GPU engine, 8 distribution modes, automatic balancer, validation, concurrency measurement.
- Part of Stage 6: results history, compare, JSON/CSV export, rule-based bottleneck analysis, driver status screen
  with verified backend switching.

## NOT done yet
- Stage 5: rendering benchmark (triangles, 2D/3D, textures, lighting, shadows, particles, post-processing,
  draw calls, quality levels, resolution selection), FPS / 1% low, experimental CPU+GPU split rendering.
  The Dashboard says "Current FPS: not measured yet" because nothing renders yet - that is intentional.
- Physics (N-body, per-step CPU<->GPU exchange) and geometry workloads, software rasterizer.
- Stage 7: performance tuning from real device numbers, low-RAM tuning, release signing.

## Verification status (be honest)
- The sandbox that produced this code had **no Rust toolchain and no network**, so **nothing was compiled
  or run by the author**. The first CI build is the first compile. Expect to send back compiler errors;
  all wgpu calls are in `crates/gpu_engine`, all ash calls in `crates/driver_detection/src/vulkan.rs`.
- Pure-logic unit tests exist (`cargo test --lib`): thread pool, matmul vs reference, vector, particles,
  image filter, partitioning, balancer, stats. They run in CI (non-blocking) and print results in the log.
- Needs the real Infinix X675: Vulkan/GLES init, GPU kernels, timestamps, hybrid overlap, thermals.
  Nothing about device behaviour has been observed yet.

## Known design choices / risks
- wgpu pinned to `22.x` (API known). Cargo.lock is not shipped; CI resolves latest compatible crates.
- Hybrid reserves one CPU core for GPU submission when >= 3 threads.
- Workgroup sizes are small (64 invocations) so low-end GPUs (limit 128) work.
- OpenGL ES backend of wgpu needs ES 3.1 compute; otherwise GPU modes report "unavailable" with the reason.
