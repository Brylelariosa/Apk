// Particle integration for particles [offset, offset + count). State is [x, y, vx, vy].
// Mirrors cpu_engine::particles::step_one exactly (same operation order).
struct Params {
    count: u32,
    offset: u32,
    steps: u32,
    pad: u32,
    dt: f32,
    k: f32,
    damp: f32,
    swirl: f32,
}

@group(0) @binding(0) var<storage, read> src: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> dst: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read> attractors: array<vec2<f32>>;
@group(0) @binding(3) var<uniform> p: Params;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(num_workgroups) nwg: vec3<u32>) {
    let i = gid.y * (nwg.x * 64u) + gid.x;
    if (i >= p.count) {
        return;
    }
    var s: vec4<f32> = src[p.offset + i];
    for (var t: u32 = 0u; t < p.steps; t = t + 1u) {
        let c = attractors[t];
        let ax = (c.x - s.x) * p.k - s.z * p.damp - (s.y - c.y) * p.swirl;
        let ay = (c.y - s.y) * p.k - s.w * p.damp + (s.x - c.x) * p.swirl;
        s.z = s.z + ax * p.dt;
        s.w = s.w + ay * p.dt;
        s.x = s.x + s.z * p.dt;
        s.y = s.y + s.w * p.dt;
    }
    dst[i] = s;
}
