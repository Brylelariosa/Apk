// C = A x B for square N x N f32 matrices. Computes rows [row_start, row_start + rows) of C.
// The output buffer holds only those rows (row-relative indexing).
// 8x8 shared-memory tiles: 64 invocations per workgroup is valid on every Vulkan/GLES device.
struct Params {
    n: u32,
    row_start: u32,
    rows: u32,
    pad: u32,
}

@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> c: array<f32>;
@group(0) @binding(3) var<uniform> p: Params;

const TILE: u32 = 8u;

var<workgroup> tile_a: array<f32, 64>;
var<workgroup> tile_b: array<f32, 64>;

@compute @workgroup_size(8, 8, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>) {
    let col = gid.x;
    let local_row = gid.y;
    let row = p.row_start + local_row;
    let lr = lid.y;
    let lc = lid.x;
    var acc: f32 = 0.0;
    let tiles = (p.n + TILE - 1u) / TILE;
    for (var t: u32 = 0u; t < tiles; t = t + 1u) {
        let a_col = t * TILE + lc;
        let b_row = t * TILE + lr;
        var av: f32 = 0.0;
        if (row < p.n && local_row < p.rows && a_col < p.n) {
            av = a[row * p.n + a_col];
        }
        var bv: f32 = 0.0;
        if (b_row < p.n && col < p.n) {
            bv = b[b_row * p.n + col];
        }
        tile_a[lr * TILE + lc] = av;
        tile_b[lr * TILE + lc] = bv;
        workgroupBarrier();
        for (var k: u32 = 0u; k < TILE; k = k + 1u) {
            acc = fma(tile_a[lr * TILE + k], tile_b[k * TILE + lc], acc);
        }
        workgroupBarrier();
    }
    if (local_row < p.rows && col < p.n) {
        c[local_row * p.n + col] = acc;
    }
}
