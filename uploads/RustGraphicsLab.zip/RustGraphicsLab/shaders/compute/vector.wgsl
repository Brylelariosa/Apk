// y[i] = chain of `iters` fused multiply-adds applied to x[offset + i], for i in [0, count).
// 2D dispatch is flattened so very large vectors never exceed the per-dimension workgroup limit.
struct Params {
    count: u32,
    offset: u32,
    iters: u32,
    pad: u32,
    a: f32,
    b: f32,
    pad2: f32,
    pad3: f32,
}

@group(0) @binding(0) var<storage, read> x: array<f32>;
@group(0) @binding(1) var<storage, read_write> y: array<f32>;
@group(0) @binding(2) var<uniform> p: Params;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(num_workgroups) nwg: vec3<u32>) {
    let i = gid.y * (nwg.x * 64u) + gid.x;
    if (i >= p.count) {
        return;
    }
    var v: f32 = x[p.offset + i];
    for (var k: u32 = 0u; k < p.iters; k = k + 1u) {
        v = fma(v, p.a, p.b);
    }
    y[i] = v;
}
