// 3x3 Gaussian blur + contrast curve on packed RGBA8 pixels (integer math only).
// Mirrors cpu_engine::image::filter_pixel exactly. Output holds only rows [row_start, row_start + rows).
struct Params {
    width: u32,
    height: u32,
    row_start: u32,
    rows: u32,
}

@group(0) @binding(0) var<storage, read> src: array<u32>;
@group(0) @binding(1) var<storage, read_write> dst: array<u32>;
@group(0) @binding(2) var<uniform> p: Params;

fn fetch(x: i32, y: i32) -> u32 {
    let cx = clamp(x, 0, i32(p.width) - 1);
    let cy = clamp(y, 0, i32(p.height) - 1);
    return src[u32(cy) * p.width + u32(cx)];
}

fn curve(v: u32) -> u32 {
    let s = i32((v + 8u) >> 4u);
    let o = ((s - 128) * 3) / 2 + 128;
    return u32(clamp(o, 0, 255));
}

@compute @workgroup_size(8, 8, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    if (gid.x >= p.width || gid.y >= p.rows) {
        return;
    }
    let x = i32(gid.x);
    let y = i32(p.row_start + gid.y);
    var r: u32 = 0u;
    var g: u32 = 0u;
    var b: u32 = 0u;
    for (var dy: i32 = -1; dy <= 1; dy = dy + 1) {
        for (var dx: i32 = -1; dx <= 1; dx = dx + 1) {
            let wt = u32((2 - abs(dx)) * (2 - abs(dy)));
            let px = fetch(x + dx, y + dy);
            r = r + wt * (px & 255u);
            g = g + wt * ((px >> 8u) & 255u);
            b = b + wt * ((px >> 16u) & 255u);
        }
    }
    let center = fetch(x, y);
    dst[gid.y * p.width + gid.x] = curve(r) | (curve(g) << 8u) | (curve(b) << 16u) | (center & 0xFF000000u);
}
