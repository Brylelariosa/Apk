# Rust Android Graphics Laboratory

A native Android app, written Rust-first, that measures what your phone's CPU and GPU can do - alone
and **together**. It detects the real graphics hardware and drivers, benchmarks CPU, GPU and a
cooperative CPU + GPU engine on identical workloads, validates every result against an independent
CPU reference and exports the measurements.

Target: Infinix X675 (Android 11, ARM64, 720 x 1600). Nothing is assumed about the hardware: everything
is detected at run time and anything the device hides is shown as *unavailable*.

> **Status: Stages 1-4 of 7 + results export.** See `PROJECT_STATE.md` for exactly what exists, what is
> verified and what is not. The rendering benchmark / split rendering (Stage 5) is not in this build.

## What works in this build

| Area | What it does |
| --- | --- |
| Device info | CPU cores/layout/frequencies, SoC props, RAM, thermal zones, battery, Android thermal status |
| GPU detection | Vulkan (direct, via `ash`): versions, extensions, limits, memory heaps, queues. OpenGL ES (real EGL context): version, renderer, extensions, limits, compute. wgpu adapters. |
| Drivers | Shows system driver / ANGLE / game-driver status, per-app driver settings, Developer-options steps. Lets the app switch its **own** backend (Auto / Vulkan / OpenGL ES) and *verifies the switch by initializing a device and running a compute kernel*. It never pretends to replace the system driver. |
| CPU engine | Multithreaded matrix multiply (4-row register blocking, FMA on ARM64), vector math, particle simulation, 3x3 image filter. Dynamic chunk scheduling for big.LITTLE. |
| GPU engine | wgpu compute (WGSL): same five workloads, GPU timestamp queries, asynchronous submission, resident input buffers. |
| Hybrid engine | CPU and GPU compute **different ranges of the same problem at the same time**; results are merged into one output. Modes: CPU priority, GPU priority, Balanced (calibrated), 25/75, 50/50, 75/25, Automatic (measured throughput + GPU overhead model), Custom (slider adjustable while running). |
| Benchmarks | Warm-up, validation run, N measured iterations, min/avg/max/p95, nominal Gops/s, CPU load, memory, battery temperature, thermal status, measured CPU/GPU overlap time. |
| Safety | Pauses to cool when warm, aborts when hot, time limit per mode, Stop button, no background work when idle. |
| Results | History (local), side-by-side compare with configuration differences highlighted, JSON and CSV export (Android file picker). |
| Analysis | Bottleneck findings quoting the measurement they come from (transfer-, sync-, CPU-, GPU-, memory-bandwidth-, thermal-bound, correctness failures). |

## Architecture

```
RustGraphicsLab/
  Cargo.toml                  Rust workspace (also the Gradle project root)
  crates/
    core/            lab_core        logging, stats, sysinfo (/proc, /sys, props), platform state, UI section helpers
    cpu_engine/      cpu_engine      std-only thread scheduling + kernels (matmul, vector, particles, image)
    gpu_engine/      gpu_engine      wgpu device/adapter selection, buffers, kernels, async submit + timestamps
    hybrid_engine/   hybrid_engine   Workload trait, partitioning, balancer, concurrent runner, 5 workloads
    driver_detection/ driver_detection  ash Vulkan probe, EGL/GLES probe, driver option report
    benchmark/       benchmark       sessions, thermal guard, results, history, export, analysis, monitor
    android_bridge/  graphicslab     cdylib: one JNI function  Native.call(command, json) -> json
  shaders/compute/   WGSL kernels (embedded at build time)
  app/               Kotlin shell: navigation, platform APIs (battery, thermal status), file picker
```

* **Rust-first.** All computation, scheduling, benchmarking, detection and reporting are Rust. Kotlin only
  does what needs Android APIs: drawing views, battery/thermal-status, package/settings lookups, the file
  picker. The UI has no dependencies (plain Views, no AndroidX).
* **One narrow boundary.** `Native.call(cmd, json)` returns display-ready JSON "sections" (rows, tables,
  charts), so the UI is a generic renderer and logic is testable on a PC (`cargo test --lib`).
* **Workloads are pure range functions** `output = f(input, range)`. That is what makes real concurrent
  CPU + GPU execution safe: disjoint ranges, immutable inputs, one merged output.
* **Every wgpu call lives in `gpu_engine`.** wgpu is pinned to 22.x; upgrading touches one crate.

### How a hybrid run works

1. GPU range: encode + submit (returns immediately, GPU starts executing).
2. CPU range: computed on worker threads *while the GPU runs* (one core is reserved for GPU submission).
3. A waiter thread records the exact moment the GPU finished; results are read back and merged.

Reported per run: CPU time, GPU wall time, GPU execution time (timestamp queries when supported), submit,
readback, merge, main-thread wait, and the **measured overlap** during which both processors were busy.
Hybrid is only called a win if the measured total beats the best single processor.

## Building (GitHub Actions, no PC)

The existing `build.yml` workflow builds this project unchanged: put the ZIP in `uploads/`.
It finds `settings.gradle`, detects `Cargo.toml` (workspace root), builds `libgraphicslab.so` with
`cargo ndk ... build --release` into `app/src/main/jniLibs/arm64-v8a`, then runs Gradle with
`-PrustPrebuilt=true`. ABIs come from `rustAbis=` in `gradle.properties` (default `arm64-v8a`).
The workflow also runs `cargo test --lib` (non-blocking) - the log shows the unit-test results.

## Honest limits

* GPU load, GPU frequency and CPU temperature are not readable by normal apps on Android; they are shown as
  *unavailable*, never invented. Power draw is an *estimate* from battery current x voltage when exposed.
* Operation counts behind "Gops/s" are nominal estimates of the workload; use them to compare modes of
  the same workload, not different workloads.
* Android does not let an app replace the system graphics driver. The Drivers screen explains the Developer
  options route and detects what exists.
