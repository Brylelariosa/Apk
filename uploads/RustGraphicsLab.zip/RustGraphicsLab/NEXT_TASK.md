# Next task

1. Upload this ZIP via the existing workflow; if the Rust build fails, fix compile errors from the cargo log
   (start with `crates/gpu_engine` and `crates/driver_detection/src/vulkan.rs`).
2. Run on the Infinix X675: Dashboard -> "Run quick hybrid test", then each workload on the Hybrid screen.
   Check: validation = OK for all modes, hybrid "overlap" > 0, GPU timestamps supported or n/a.
3. Stage 5: rendering benchmark + FPS monitor + experimental split rendering (new `renderer` crate:
   wgpu offscreen render targets, identical scenes on Vulkan and GLES, CPU rasterizer for the split half).
4. Stage 4b: N-body physics workload (per-step exchange, sync-bound demo) and geometry transform workload.
5. Stage 7: tune chunk sizes / tile sizes from measured data.
