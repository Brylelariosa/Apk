# Changelog

## 0.1.0
- Initial release: stages 1-4, results export, driver status, bottleneck analysis.
