package com.graphicslab.app

import org.json.JSONObject

/** The single JNI entry point into the Rust engine (libgraphicslab.so). */
object Native {
    init {
        System.loadLibrary("graphicslab")
    }

    @JvmStatic
    external fun call(command: String, args: String): String
}

/** Convenience wrapper: JSON in, JSON out, never throws. */
object Rust {
    fun call(cmd: String, args: JSONObject? = null): JSONObject {
        val raw = try {
            Native.call(cmd, args?.toString() ?: "{}")
        } catch (t: Throwable) {
            return JSONObject().put("ok", false).put("error", "native call failed: $t")
        }
        return try {
            JSONObject(raw)
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", "unreadable response from the engine")
        }
    }

    /** Data payload on success, null on failure. */
    fun data(cmd: String, args: JSONObject? = null): JSONObject? {
        val r = call(cmd, args)
        if (!r.optBoolean("ok", false)) return null
        return r.optJSONObject("data") ?: JSONObject()
    }

    fun error(r: JSONObject): String = r.optString("error", "unknown error")
}
