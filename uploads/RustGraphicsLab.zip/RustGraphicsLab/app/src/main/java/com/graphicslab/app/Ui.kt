package com.graphicslab.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Colour palette; follows the system light / dark setting. */
object Pal {
    var night = false
    var bg = 0
    var card = 0
    var text = 0
    var sub = 0
    var line = 0
    var primary = 0
    var cpu = 0
    var gpu = 0
    var hybrid = 0
    var warn = 0
    var bad = 0
    var ok = 0

    fun init(ctx: Context) {
        night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (night) {
            bg = 0xFF0F1316.toInt(); card = 0xFF1A2025.toInt(); text = 0xFFE8ECEF.toInt()
            sub = 0xFF9AA5AE.toInt(); line = 0xFF2B343B.toInt(); primary = 0xFF4DB6AC.toInt()
            cpu = 0xFF64B5F6.toInt(); gpu = 0xFF81C784.toInt(); hybrid = 0xFFFFB74D.toInt()
            warn = 0xFFFFD54F.toInt(); bad = 0xFFEF5350.toInt(); ok = 0xFF66BB6A.toInt()
        } else {
            bg = 0xFFF3F5F7.toInt(); card = 0xFFFFFFFF.toInt(); text = 0xFF1B2227.toInt()
            sub = 0xFF5F6B75.toInt(); line = 0xFFDDE2E6.toInt(); primary = 0xFF00796B.toInt()
            cpu = 0xFF1976D2.toInt(); gpu = 0xFF388E3C.toInt(); hybrid = 0xFFEF6C00.toInt()
            warn = 0xFFF9A825.toInt(); bad = 0xFFD32F2F.toInt(); ok = 0xFF2E7D32.toInt()
        }
    }

    fun color(name: String): Int = when (name) {
        "cpu" -> cpu
        "gpu" -> gpu
        "hybrid" -> hybrid
        "warn" -> warn
        "bad" -> bad
        else -> primary
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, bottom: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.topMargin = dp(top)
    p.bottomMargin = dp(bottom)
    return p
}

fun Context.text(s: CharSequence, sizeSp: Float = 14f, color: Int = Pal.text, bold: Boolean = false, mono: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
    t.setTextColor(color)
    if (bold) t.setTypeface(Typeface.DEFAULT_BOLD)
    if (mono) t.setTypeface(Typeface.MONOSPACE)
    return t
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    return l
}

fun Context.roundBg(fill: Int, stroke: Int, radiusDp: Float, strokeDp: Int = 1): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dpf(radiusDp)
    if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke)
    return g
}

fun Context.card(title: String?): LinearLayout {
    val c = vbox()
    c.background = roundBg(Pal.card, Pal.line, 12f)
    val pad = dp(14)
    c.setPadding(pad, pad, pad, pad)
    if (!title.isNullOrEmpty()) c.addView(text(title, 15f, Pal.text, bold = true), lp(bottom = 6))
    return c
}

fun Context.button(label: String, filled: Boolean = true, onClick: () -> Unit): TextView {
    val b = text(label, 14f, if (filled) Color.WHITE else Pal.primary, bold = true)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(16), dp(11), dp(16), dp(11))
    b.background = if (filled) roundBg(Pal.primary, Pal.primary, 10f, 0) else roundBg(Color.TRANSPARENT, Pal.primary, 10f, 1)
    b.isClickable = true
    b.setOnClickListener { onClick() }
    return b
}

fun Context.spinner(items: List<String>, selected: Int, onSelect: (Int) -> Unit): Spinner {
    val s = Spinner(this)
    val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
    ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    s.adapter = ad
    s.setSelection(selected.coerceIn(0, maxOf(0, items.size - 1)))
    s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            onSelect(position)
        }

        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
    return s
}

/** Single-choice segmented control. */
class Segmented(
    ctx: Context,
    options: List<String>,
    initial: Int,
    private val onChange: (Int) -> Unit
) : LinearLayout(ctx) {
    var selected: Int = initial
        private set
    private val cells = ArrayList<TextView>()

    init {
        orientation = LinearLayout.HORIZONTAL
        background = ctx.roundBg(Pal.card, Pal.line, 10f)
        for ((i, label) in options.withIndex()) {
            val t = ctx.text(label, 13f, Pal.text, bold = true)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(6), ctx.dp(10), ctx.dp(6), ctx.dp(10))
            t.setOnClickListener { select(i, true) }
            cells.add(t)
            addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint()
    }

    fun select(i: Int, notify: Boolean) {
        selected = i
        paint()
        if (notify) onChange(i)
    }

    private fun paint() {
        for ((i, t) in cells.withIndex()) {
            val on = i == selected
            t.setTextColor(if (on) Color.WHITE else Pal.text)
            t.background = if (on) context.roundBg(Pal.primary, Pal.primary, 10f, 0) else null
        }
    }
}

/** Labelled slider with a live value read-out. */
class SeekRow(
    ctx: Context,
    title: String,
    private val lo: Int,
    hi: Int,
    initial: Int,
    private val fmt: (Int) -> String,
    private val onChange: ((Int) -> Unit)? = null
) : LinearLayout(ctx) {
    private val head: TextView = ctx.text("", 13f, Pal.text, bold = true)
    private val bar: SeekBar = SeekBar(ctx)

    var value: Int
        get() = lo + bar.progress
        set(v) {
            bar.progress = v - lo
            head.text = fmt(v)
        }

    init {
        orientation = LinearLayout.VERTICAL
        val row = ctx.hbox()
        row.addView(ctx.text(title, 13f, Pal.sub), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(head, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        bar.max = hi - lo
        bar.progress = initial - lo
        head.text = fmt(initial)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = lo + progress
                head.text = fmt(v)
                if (fromUser) onChange?.invoke(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
    }
}

/** Multi-series line chart drawn on a Canvas (no libraries). */
class LineChartView(ctx: Context) : View(ctx) {
    private class Series(val name: String, val color: Int, val values: DoubleArray)

    private var series: List<Series> = emptyList()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        linePaint.style = Paint.Style.STROKE
        linePaint.strokeWidth = ctx.dpf(2f)
        linePaint.strokeJoin = Paint.Join.ROUND
        gridPaint.color = Pal.line
        gridPaint.strokeWidth = 1f
        textPaint.color = Pal.sub
        textPaint.textSize = ctx.dpf(10f)
        fillPaint.style = Paint.Style.FILL
    }

    fun setData(chart: JSONObject) {
        val arr = chart.optJSONArray("series") ?: JSONArray()
        val list = ArrayList<Series>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            val vals = s.optJSONArray("values") ?: JSONArray()
            val d = DoubleArray(vals.length()) { k -> vals.optDouble(k, 0.0) }
            list.add(Series(s.optString("name", ""), Pal.color(s.optString("color", "")), d))
        }
        series = list
        invalidate()
    }

    private fun fmt(v: Double): String = when {
        abs(v) >= 100 -> String.format("%.0f", v)
        abs(v) >= 10 -> String.format("%.1f", v)
        else -> String.format("%.2f", v)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val padL = context.dpf(44f)
        val padR = context.dpf(8f)
        val padT = context.dpf(24f)
        val padB = context.dpf(8f)
        val w = width - padL - padR
        val h = height - padT - padB
        var n = 0
        var mn = Double.MAX_VALUE
        var mx = -Double.MAX_VALUE
        for (s in series) {
            if (s.values.size > n) n = s.values.size
            for (v in s.values) {
                if (v < mn) mn = v
                if (v > mx) mx = v
            }
        }
        if (n == 0) {
            canvas.drawText("No data yet", padL, height / 2f, textPaint)
            return
        }
        val origMin = mn
        if (mx - mn < 1e-9) {
            mx += 1.0
            mn -= 1.0
        } else {
            val m = (mx - mn) * 0.08
            mx += m
            mn -= m
        }
        if (origMin >= 0 && mn < 0) mn = 0.0
        // grid + labels
        for (k in 0..3) {
            val y = padT + h * k / 3f
            canvas.drawLine(padL, y, padL + w, y, gridPaint)
            val value = mx - (mx - mn) * k / 3.0
            canvas.drawText(fmt(value), 2f, y + textPaint.textSize / 3f, textPaint)
        }
        // lines
        for (s in series) {
            if (s.values.isEmpty()) continue
            linePaint.color = s.color
            if (s.values.size == 1) {
                fillPaint.color = s.color
                val y = padT + (h * (1.0 - (s.values[0] - mn) / (mx - mn))).toFloat()
                canvas.drawCircle(padL, y, context.dpf(3f), fillPaint)
                continue
            }
            val path = Path()
            for (i in s.values.indices) {
                val x = padL + w * i / maxOf(1, n - 1).toFloat()
                val y = padT + (h * (1.0 - (s.values[i] - mn) / (mx - mn))).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, linePaint)
        }
        // legend
        var lx = padL
        for (s in series) {
            fillPaint.color = s.color
            canvas.drawRect(lx, context.dpf(6f), lx + context.dpf(10f), context.dpf(16f), fillPaint)
            canvas.drawText(s.name, lx + context.dpf(14f), context.dpf(15f), textPaint)
            lx += context.dpf(14f) + textPaint.measureText(s.name) + context.dpf(14f)
        }
    }
}

/** Renders the display-ready "sections" JSON produced by the Rust engine. */
object Sections {
    fun render(ctx: Context, host: LinearLayout, sections: JSONArray?) {
        host.removeAllViews()
        if (sections == null) return
        for (i in 0 until sections.length()) {
            val s = sections.optJSONObject(i) ?: continue
            host.addView(sectionView(ctx, s), ctx.lp(top = if (i == 0) 0 else 12))
        }
    }

    private fun tagColor(tag: String): Int = when (tag) {
        "measured" -> Pal.ok
        "estimated" -> Pal.warn
        "unavailable" -> Pal.sub
        "high" -> Pal.bad
        "medium" -> Pal.warn
        "low" -> Pal.sub
        else -> Pal.primary
    }

    fun sectionView(ctx: Context, s: JSONObject): View {
        val card = ctx.card(s.optString("title", ""))
        val note = s.optString("note", "")
        if (note.isNotEmpty()) card.addView(ctx.text(note, 12f, Pal.sub), ctx.lp(bottom = 6))
        val rows = s.optJSONArray("rows")
        if (rows != null) {
            for (r in 0 until rows.length()) {
                val row = rows.optJSONArray(r) ?: continue
                card.addView(rowView(ctx, row), ctx.lp(top = 6))
            }
        }
        val table = s.optJSONObject("table")
        if (table != null) card.addView(tableView(ctx, table), ctx.lp(top = 6))
        val chart = s.optJSONObject("chart")
        if (chart != null) {
            val cv = LineChartView(ctx)
            cv.setData(chart)
            card.addView(cv, ctx.lp(h = ctx.dp(190), top = 6))
        }
        val items = s.optJSONArray("items")
        if (items != null && items.length() > 0) {
            card.addView(itemsView(ctx, s.optString("items_title", "Details"), items), ctx.lp(top = 8))
        }
        return card
    }

    private fun rowView(ctx: Context, r: JSONArray): View {
        val box = ctx.hbox()
        val label = ctx.text(r.optString(0, ""), 13f, Pal.sub)
        val right = ctx.vbox()
        right.addView(ctx.text(r.optString(1, ""), 13f, Pal.text))
        val tag = r.optString(2, "")
        if (tag.isNotEmpty()) right.addView(ctx.text(tag, 10f, tagColor(tag)))
        box.addView(label, LinearLayout.LayoutParams(0, WRAP, 0.42f))
        box.addView(right, LinearLayout.LayoutParams(0, WRAP, 0.58f))
        return box
    }

    private fun tableView(ctx: Context, t: JSONObject): View {
        val cols = t.optJSONArray("columns") ?: JSONArray()
        val rows = t.optJSONArray("rows") ?: JSONArray()
        val narrow = cols.length() <= 4
        val scroll = HorizontalScrollView(ctx)
        scroll.isHorizontalScrollBarEnabled = false
        val grid = ctx.vbox()
        fun addRow(cells: JSONArray, header: Boolean) {
            val line = ctx.hbox()
            for (c in 0 until cols.length()) {
                val w = if (c == 0) (if (narrow) 96 else 120) else (if (narrow) 120 else 66)
                val tv = ctx.text(cells.optString(c, ""), 11f, if (header) Pal.sub else Pal.text, bold = header)
                line.addView(tv, LinearLayout.LayoutParams(ctx.dp(w), WRAP))
            }
            grid.addView(line, ctx.lp(top = if (header) 0 else 5))
        }
        addRow(cols, true)
        for (r in 0 until rows.length()) addRow(rows.optJSONArray(r) ?: JSONArray(), false)
        scroll.addView(grid)
        return scroll
    }

    private fun itemsView(ctx: Context, title: String, items: JSONArray): View {
        val box = ctx.vbox()
        val sb = StringBuilder()
        for (i in 0 until items.length()) sb.append(items.optString(i, "")).append('\n')
        val toggle = ctx.text("Show $title (${items.length()})", 13f, Pal.primary, bold = true)
        toggle.setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        val body = ctx.text(sb.toString().trimEnd(), 11f, Pal.sub, mono = true)
        body.visibility = View.GONE
        body.setTextIsSelectable(true)
        toggle.setOnClickListener {
            val show = body.visibility != View.VISIBLE
            body.visibility = if (show) View.VISIBLE else View.GONE
            toggle.text = (if (show) "Hide " else "Show ") + title + " (" + items.length() + ")"
        }
        box.addView(toggle)
        box.addView(body, ctx.lp(top = 4))
        return box
    }
}
