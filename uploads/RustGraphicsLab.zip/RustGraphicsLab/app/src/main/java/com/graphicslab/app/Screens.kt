package com.graphicslab.app

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

abstract class Screen(val act: MainActivity) {
    abstract val title: String
    abstract val iconRes: Int
    abstract fun build(): View
    open fun onShow() {}
    open fun onHide() {}
    open fun tick() {}

    protected val ctx: Context get() = act

    protected fun page(content: View): ScrollView {
        val sv = ScrollView(act)
        val box = act.vbox()
        box.setPadding(act.dp(14), act.dp(6), act.dp(14), act.dp(24))
        box.addView(content, LinearLayout.LayoutParams(MATCH, WRAP))
        sv.addView(box)
        return sv
    }
}

// ------------------------------------------------------------------------------------------ Dashboard

class DashboardScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Dashboard"
    override val iconRes: Int = R.drawable.ic_dashboard
    private lateinit var host: LinearLayout
    private var busy = false
    private var warmed = false
    private var ticks = 0

    override fun build(): View {
        val root = ctx.vbox()
        root.addView(ctx.button("Run quick hybrid test (matrix 512)") { act.startQuickTest() }, ctx.lp(bottom = 12))
        host = ctx.vbox()
        root.addView(host)
        return page(root)
    }

    override fun onShow() {
        refresh()
        if (!warmed) {
            warmed = true
            // Detect the GPU once so the dashboard can name it (runs a real initialization).
            act.async {
                Rust.call("gpu.report")
                act.ui { refresh() }
            }
        }
    }

    override fun tick() {
        ticks++
        if (ticks % 2 == 0) refresh()
    }

    private fun refresh() {
        if (busy) return
        busy = true
        act.async {
            val d = Rust.data("dashboard")
            act.ui {
                busy = false
                if (d != null) Sections.render(ctx, host, d.optJSONArray("sections"))
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ Device

class DeviceScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Device Information"
    override val iconRes: Int = R.drawable.ic_device
    private lateinit var sysHost: LinearLayout
    private lateinit var gpuHost: LinearLayout
    private lateinit var gpuStatus: TextView

    override fun build(): View {
        val root = ctx.vbox()
        sysHost = ctx.vbox()
        gpuHost = ctx.vbox()
        gpuStatus = ctx.text("", 12f, Pal.sub)
        root.addView(ctx.button("Refresh", false) { load() }, ctx.lp(bottom = 10))
        root.addView(sysHost)
        root.addView(ctx.text("Graphics hardware", 16f, Pal.text, bold = true), ctx.lp(top = 16, bottom = 4))
        root.addView(gpuStatus)
        root.addView(gpuHost, ctx.lp(top = 6))
        return page(root)
    }

    override fun onShow() {
        load()
    }

    private fun load() {
        gpuStatus.text = "Detecting GPU, Vulkan and OpenGL ES (runs a real initialization)..."
        act.async {
            val d = Rust.data("device.report")
            act.ui {
                if (d != null) Sections.render(ctx, sysHost, d.optJSONArray("sections"))
            }
            val g = Rust.call("gpu.report")
            act.ui {
                if (g.optBoolean("ok", false)) {
                    gpuStatus.text = ""
                    Sections.render(ctx, gpuHost, g.optJSONObject("data")?.optJSONArray("sections"))
                } else {
                    gpuStatus.text = Rust.error(g)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ Drivers

class DriversScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Graphics Drivers"
    override val iconRes: Int = R.drawable.ic_driver
    private lateinit var seg: Segmented
    private lateinit var verifyHost: LinearLayout
    private lateinit var reportHost: LinearLayout
    private val ids = listOf("auto", "vulkan", "gles")

    override fun build(): View {
        val root = ctx.vbox()
        val c = ctx.card("Compute backend of this app")
        c.addView(
            ctx.text(
                "Choose which graphics API the engine uses. The change only counts if a real device initialization succeeds.",
                12f, Pal.sub
            ),
            ctx.lp(bottom = 8)
        )
        seg = Segmented(ctx, listOf("Auto", "Vulkan", "OpenGL ES"), 0) { }
        c.addView(seg, ctx.lp(bottom = 10))
        val row = ctx.hbox()
        val p1 = ctx.lp(w = 0, weight = 1f)
        p1.rightMargin = ctx.dp(8)
        row.addView(ctx.button("Apply and verify") { apply(ids[seg.selected]) }, p1)
        row.addView(ctx.button("Reset to Auto", false) { seg.select(0, false); apply("auto") }, ctx.lp(w = 0, weight = 1f))
        c.addView(row)
        root.addView(c)
        verifyHost = ctx.vbox()
        root.addView(verifyHost, ctx.lp(top = 12))
        root.addView(ctx.button("Open Developer options", false) { act.openDeveloperOptions() }, ctx.lp(top = 12))
        reportHost = ctx.vbox()
        root.addView(reportHost, ctx.lp(top = 12))
        return page(root)
    }

    override fun onShow() {
        load()
    }

    private fun load() {
        act.async {
            val d = Rust.data("drivers.report")
            act.ui {
                if (d != null) {
                    val pref = d.optString("pref", "auto")
                    val idx = ids.indexOf(pref)
                    if (idx >= 0) seg.select(idx, false)
                    Sections.render(ctx, reportHost, d.optJSONArray("sections"))
                }
            }
        }
    }

    private fun apply(id: String) {
        verifyHost.removeAllViews()
        verifyHost.addView(ctx.text("Initializing and testing the backend...", 13f, Pal.sub))
        act.async {
            val r = Rust.call("backend.set", JSONObject().put("backend", id))
            act.ui {
                if (r.optBoolean("ok", false)) {
                    Sections.render(ctx, verifyHost, r.optJSONObject("data")?.optJSONArray("sections"))
                    load()
                } else {
                    verifyHost.removeAllViews()
                    verifyHost.addView(ctx.text(Rust.error(r), 13f, Pal.bad))
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ Benchmarks

/** One screen class serves the CPU, GPU and Hybrid benchmark entries. */
class BenchScreen(act: MainActivity, private val kind: String) : Screen(act) {
    override val title: String = when (kind) {
        "cpu" -> "CPU Benchmark"
        "gpu" -> "GPU Benchmark"
        else -> "Hybrid Engine"
    }
    override val iconRes: Int = when (kind) {
        "cpu" -> R.drawable.ic_cpu
        "gpu" -> R.drawable.ic_gpu
        else -> R.drawable.ic_hybrid
    }

    private var workloads = JSONArray()
    private var dists = JSONArray()
    private var backends = JSONArray()
    private var cores = 1
    private var wlIndex = 0
    private var scaleIndex = 1
    private var distIndex = 0
    private var backendIndex = 0
    private var compareAll = true
    private var settings = JSONObject()
    private var settingsApplied = false
    private var shownId = ""
    private var lastRid = ""
    private var polling = false

    private lateinit var scaleSpinner: Spinner
    private lateinit var descView: TextView
    private lateinit var customRow: SeekRow
    private lateinit var iterRow: SeekRow
    private lateinit var warmRow: SeekRow
    private lateinit var threadRow: SeekRow
    private lateinit var startBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var liveHost: LinearLayout
    private lateinit var resultHost: LinearLayout

    private fun label(s: String): TextView = ctx.text(s, 12f, Pal.sub)

    private fun distId(): String = dists.optJSONObject(distIndex)?.optString("id") ?: "auto"

    override fun build(): View {
        val cat = Rust.data("bench.catalog") ?: JSONObject()
        workloads = cat.optJSONArray("workloads") ?: JSONArray()
        dists = cat.optJSONArray("distributions") ?: JSONArray()
        backends = cat.optJSONArray("backends") ?: JSONArray()
        cores = cat.optInt("cores", 1)

        val root = ctx.vbox()
        val setup = ctx.card("Test setup")

        // workload + size
        setup.addView(label("Workload"))
        val names = (0 until workloads.length()).map { workloads.getJSONObject(it).optString("name") }
        setup.addView(ctx.spinner(names, 0) { wlIndex = it; updateScales() }, ctx.lp(bottom = 4))
        descView = ctx.text("", 12f, Pal.sub)
        setup.addView(descView, ctx.lp(bottom = 8))
        setup.addView(label("Problem size"))
        scaleSpinner = Spinner(ctx)
        scaleSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                scaleIndex = position
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        setup.addView(scaleSpinner, ctx.lp(bottom = 8))
        updateScales()

        // backend
        if (kind != "cpu") {
            setup.addView(label("Graphics backend"))
            val bnames = (0 until backends.length()).map { backends.getJSONObject(it).optString("label") }
            setup.addView(ctx.spinner(bnames, 0) { backendIndex = it }, ctx.lp(bottom = 8))
        }

        // distribution (hybrid only)
        customRow = SeekRow(
            ctx, "CPU share of the work (adjustable while running)", 0, 100, 40,
            fmt = { "$it% CPU / ${100 - it}% GPU" },
            onChange = { pct -> act.async { Rust.call("bench.set_cpu_pct", JSONObject().put("pct", pct.toDouble())) } }
        )
        customRow.visibility = View.GONE
        if (kind == "hybrid") {
            setup.addView(label("CPU / GPU work distribution"))
            val dnames = (0 until dists.length()).map { dists.getJSONObject(it).optString("label") }
            setup.addView(
                ctx.spinner(dnames, 0) {
                    distIndex = it
                    customRow.visibility = if (distId() == "custom") View.VISIBLE else View.GONE
                },
                ctx.lp(bottom = 6)
            )
            setup.addView(customRow, ctx.lp(bottom = 8))
            setup.addView(label("Comparison"))
            setup.addView(Segmented(ctx, listOf("Hybrid only", "CPU + GPU + Hybrid"), 1) { compareAll = it == 1 }, ctx.lp(bottom = 8))
        }

        // threads / iterations
        threadRow = SeekRow(ctx, "CPU threads", 0, maxOf(1, cores), 0, fmt = { if (it == 0) "Auto ($cores)" else "$it" })
        if (kind != "gpu") setup.addView(threadRow, ctx.lp(bottom = 8))
        iterRow = SeekRow(ctx, "Measured iterations", 1, 50, 10, fmt = { "$it" })
        setup.addView(iterRow, ctx.lp(bottom = 8))
        warmRow = SeekRow(ctx, "Warm-up runs (not recorded)", 0, 10, 3, fmt = { "$it" })
        setup.addView(warmRow, ctx.lp(bottom = 10))

        val btns = ctx.hbox()
        startBtn = ctx.button("Start benchmark") { start() }
        stopBtn = ctx.button("Stop", false) { act.async { Rust.call("bench.stop") } }
        val p1 = ctx.lp(w = 0, weight = 1f)
        p1.rightMargin = ctx.dp(8)
        btns.addView(startBtn, p1)
        btns.addView(stopBtn, ctx.lp(w = 0, weight = 1f))
        setup.addView(btns, ctx.lp(top = 4))
        root.addView(setup)

        val statusCard = ctx.card(null)
        statusText = ctx.text("Idle", 13f, Pal.text)
        progressBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 1000
        statusCard.addView(statusText)
        statusCard.addView(progressBar, ctx.lp(top = 6))
        root.addView(statusCard, ctx.lp(top = 12))
        liveHost = ctx.vbox()
        root.addView(liveHost, ctx.lp(top = 12))
        resultHost = ctx.vbox()
        root.addView(resultHost, ctx.lp(top = 12))
        setRunning(false)
        return page(root)
    }

    private fun scaleNames(): List<String> {
        val w = workloads.optJSONObject(wlIndex) ?: return emptyList()
        val s = w.optJSONArray("scales") ?: return emptyList()
        return (0 until s.length()).map { s.optString(it) }
    }

    private fun updateScales() {
        val names = scaleNames()
        val ad = ArrayAdapter(ctx, android.R.layout.simple_spinner_item, names)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        scaleSpinner.adapter = ad
        val w = workloads.optJSONObject(wlIndex)
        scaleIndex = (w?.optInt("default_scale", 1) ?: 1).coerceIn(0, maxOf(0, names.size - 1))
        scaleSpinner.setSelection(scaleIndex)
        descView.text = w?.optString("description", "") ?: ""
    }

    private fun setRunning(running: Boolean) {
        startBtn.isEnabled = !running
        startBtn.alpha = if (running) 0.4f else 1f
        stopBtn.isEnabled = running
        stopBtn.alpha = if (running) 1f else 0.4f
    }

    private fun start() {
        val wl = workloads.optJSONObject(wlIndex) ?: return
        val cfg = JSONObject()
        cfg.put("workload", wl.optString("id"))
        cfg.put("scale", scaleIndex)
        val modes: List<String> = when (kind) {
            "cpu" -> listOf("cpu")
            "gpu" -> listOf("gpu")
            else -> if (compareAll) listOf("cpu", "gpu", "hybrid") else listOf("hybrid")
        }
        cfg.put("modes", JSONArray(modes))
        cfg.put("distribution", distId())
        if (kind == "hybrid") cfg.put("custom_cpu_pct", customRow.value.toDouble())
        cfg.put("iterations", iterRow.value)
        cfg.put("warmup", warmRow.value)
        cfg.put("threads", threadRow.value)
        if (kind != "cpu") cfg.put("backend", backends.optJSONObject(backendIndex)?.optString("id") ?: "auto")
        cfg.put("max_seconds", settings.optDouble("max_seconds", 20.0))
        cfg.put("cooldown_s", settings.optDouble("cooldown_s", 2.0))
        cfg.put("max_batt_temp_c", settings.optDouble("max_batt_temp_c", 43.0))
        shownId = lastRid
        resultHost.removeAllViews()
        liveHost.removeAllViews()
        statusText.text = "Starting..."
        act.async {
            val r = Rust.call("bench.start", cfg)
            act.ui {
                if (!r.optBoolean("ok", false)) statusText.text = Rust.error(r)
            }
        }
    }

    override fun onShow() {
        if (!settingsApplied) {
            settingsApplied = true
            act.async {
                val s = Rust.data("settings.get")
                act.ui {
                    if (s != null) {
                        settings = s
                        iterRow.value = s.optInt("iterations", 10).coerceIn(1, 50)
                        warmRow.value = s.optInt("warmup", 3).coerceIn(0, 10)
                        threadRow.value = s.optInt("threads", 0).coerceIn(0, maxOf(1, cores))
                    }
                }
            }
        }
        tick()
    }

    override fun tick() {
        if (polling) return
        polling = true
        act.async {
            val st = Rust.data("bench.status")
            act.ui {
                polling = false
                if (st != null) applyStatus(st)
            }
        }
    }

    private fun applyStatus(st: JSONObject) {
        val running = st.optBoolean("running", false)
        setRunning(running)
        val phase = st.optString("phase", "")
        val msg = st.optString("message", "")
        progressBar.progress = (st.optDouble("fraction", 0.0) * 1000).toInt()
        statusText.text = if (phase.isEmpty()) "Idle" else if (msg.isNotEmpty()) "$phase - $msg" else phase
        val err = if (st.isNull("error")) "" else st.optString("error", "")
        val rid = if (st.isNull("result_id")) "" else st.optString("result_id", "")
        if (rid.isNotEmpty()) lastRid = rid
        if (running) {
            Sections.render(ctx, liveHost, st.optJSONArray("sections"))
        } else if (err.isNotEmpty()) {
            liveHost.removeAllViews()
            liveHost.addView(ctx.text(err, 13f, Pal.bad))
        } else if (rid.isNotEmpty() && rid != shownId) {
            shownId = rid
            liveHost.removeAllViews()
            loadResult(rid)
        }
    }

    private fun loadResult(id: String) {
        act.async {
            val d = Rust.data("history.get", JSONObject().put("id", id))
            act.ui {
                resultHost.removeAllViews()
                if (d != null) {
                    resultHost.addView(ctx.text("Result", 16f, Pal.text, bold = true), ctx.lp(bottom = 8))
                    val inner = ctx.vbox()
                    Sections.render(ctx, inner, d.optJSONArray("sections"))
                    resultHost.addView(inner)
                } else {
                    resultHost.addView(ctx.text("Could not load the saved result.", 13f, Pal.bad))
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ Monitor

class MonitorScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Performance Monitor"
    override val iconRes: Int = R.drawable.ic_monitor
    private lateinit var host: LinearLayout
    private var busy = false

    override fun build(): View {
        val root = ctx.vbox()
        root.addView(
            ctx.text(
                "Samples are taken once per second only while this screen is open, so the monitor itself costs almost nothing. " +
                    "Values marked unavailable are not exposed by this device.",
                12f, Pal.sub
            ),
            ctx.lp(bottom = 10)
        )
        host = ctx.vbox()
        root.addView(host)
        return page(root)
    }

    override fun onShow() {
        tick()
    }

    override fun tick() {
        if (busy) return
        busy = true
        act.async {
            val d = Rust.data("monitor.sample")
            act.ui {
                busy = false
                if (d != null) Sections.render(ctx, host, d.optJSONArray("sections"))
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ Results

class ResultsScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Results Comparison"
    override val iconRes: Int = R.drawable.ic_results
    private val selected = ArrayList<String>()
    private var items = JSONArray()
    private lateinit var listHost: LinearLayout
    private lateinit var detailHost: LinearLayout
    private lateinit var hint: TextView

    override fun build(): View {
        val root = ctx.vbox()
        hint = ctx.text("Tap a result to select it. Select one to view it, or two to compare them side by side.", 12f, Pal.sub)
        root.addView(hint, ctx.lp(bottom = 8))

        val r1 = ctx.hbox()
        val p1 = ctx.lp(w = 0, weight = 1f)
        p1.rightMargin = ctx.dp(8)
        r1.addView(ctx.button("View selected") { viewSelected() }, p1)
        r1.addView(ctx.button("Compare A / B") { compareSelected() }, ctx.lp(w = 0, weight = 1f))
        root.addView(r1, ctx.lp(bottom = 8))

        val r2 = ctx.hbox()
        val p2 = ctx.lp(w = 0, weight = 1f)
        p2.rightMargin = ctx.dp(8)
        val p3 = ctx.lp(w = 0, weight = 1f)
        p3.rightMargin = ctx.dp(8)
        r2.addView(ctx.button("Export JSON", false) { act.exportResults("json", ids()) }, p2)
        r2.addView(ctx.button("Export CSV", false) { act.exportResults("csv", ids()) }, p3)
        r2.addView(ctx.button("Delete all", false) { confirmDelete() }, ctx.lp(w = 0, weight = 1f))
        root.addView(r2, ctx.lp(bottom = 12))

        detailHost = ctx.vbox()
        root.addView(detailHost, ctx.lp(bottom = 12))
        root.addView(ctx.text("Saved results", 16f, Pal.text, bold = true), ctx.lp(bottom = 8))
        listHost = ctx.vbox()
        root.addView(listHost)
        return page(root)
    }

    private fun ids(): List<String> = selected.toList()

    override fun onShow() {
        reload()
    }

    private fun reload() {
        act.async {
            val d = Rust.data("history.list")
            act.ui {
                items = d?.optJSONArray("items") ?: JSONArray()
                val keep = ArrayList<String>()
                for (i in 0 until items.length()) {
                    val id = items.getJSONObject(i).optString("id")
                    if (selected.contains(id)) keep.add(id)
                }
                selected.clear()
                selected.addAll(keep)
                renderList()
            }
        }
    }

    private fun renderList() {
        listHost.removeAllViews()
        if (items.length() == 0) {
            listHost.addView(ctx.text("No saved results yet. Run a benchmark first.", 13f, Pal.sub))
            return
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val id = item.optString("id")
            val sel = selected.indexOf(id)
            val c = ctx.card(null)
            c.background = ctx.roundBg(Pal.card, if (sel >= 0) Pal.primary else Pal.line, 12f, if (sel >= 0) 2 else 1)
            c.addView(ctx.text(item.optString("title"), 14f, Pal.text, bold = true))
            c.addView(ctx.text(item.optString("subtitle"), 12f, Pal.sub), ctx.lp(top = 2))
            val meta = fmt.format(Date(item.optLong("time"))) + "  |  " + item.optString("gpu") + " (" + item.optString("backend") + ")" +
                (if (sel >= 0) "   selected as " + (if (sel == 0) "A" else "B") else "")
            c.addView(ctx.text(meta, 11f, if (sel >= 0) Pal.primary else Pal.sub), ctx.lp(top = 4))
            c.setOnClickListener { toggle(id) }
            listHost.addView(c, ctx.lp(bottom = 8))
        }
    }

    private fun toggle(id: String) {
        if (selected.contains(id)) {
            selected.remove(id)
        } else {
            if (selected.size >= 2) selected.removeAt(0)
            selected.add(id)
        }
        renderList()
    }

    private fun viewSelected() {
        if (selected.size != 1) {
            act.toast("Select exactly one result to view")
            return
        }
        val id = selected[0]
        act.async {
            val d = Rust.data("history.get", JSONObject().put("id", id))
            act.ui {
                detailHost.removeAllViews()
                if (d != null) {
                    detailHost.addView(ctx.text(d.optString("title"), 16f, Pal.text, bold = true), ctx.lp(bottom = 8))
                    val inner = ctx.vbox()
                    Sections.render(ctx, inner, d.optJSONArray("sections"))
                    detailHost.addView(inner)
                }
            }
        }
    }

    private fun compareSelected() {
        if (selected.size != 2) {
            act.toast("Select two results to compare")
            return
        }
        val a = selected[0]
        val b = selected[1]
        act.async {
            val d = Rust.data("history.compare", JSONObject().put("a", a).put("b", b))
            act.ui {
                detailHost.removeAllViews()
                if (d != null) {
                    detailHost.addView(ctx.text("Comparison: A (first selected) vs B", 16f, Pal.text, bold = true), ctx.lp(bottom = 8))
                    val inner = ctx.vbox()
                    Sections.render(ctx, inner, d.optJSONArray("sections"))
                    detailHost.addView(inner)
                }
            }
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(act)
            .setTitle("Delete all saved results?")
            .setMessage("This removes the local benchmark history. Exported files are not affected.")
            .setPositiveButton("Delete") { _, _ ->
                act.async {
                    Rust.call("history.clear")
                    act.ui {
                        selected.clear()
                        detailHost.removeAllViews()
                        reload()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

// ------------------------------------------------------------------------------------------ Settings

class SettingsScreen(act: MainActivity) : Screen(act) {
    override val title: String = "Settings"
    override val iconRes: Int = R.drawable.ic_settings
    private lateinit var threadRow: SeekRow
    private lateinit var iterRow: SeekRow
    private lateinit var warmRow: SeekRow
    private lateinit var secRow: SeekRow
    private lateinit var coolRow: SeekRow
    private lateinit var tempRow: SeekRow
    private lateinit var logView: TextView
    private lateinit var saved: TextView

    override fun build(): View {
        val cores = Runtime.getRuntime().availableProcessors()
        val root = ctx.vbox()
        val c = ctx.card("Benchmark defaults")
        threadRow = SeekRow(ctx, "CPU threads", 0, maxOf(1, cores), 0, fmt = { if (it == 0) "Auto ($cores)" else "$it" })
        iterRow = SeekRow(ctx, "Measured iterations", 1, 50, 10, fmt = { "$it" })
        warmRow = SeekRow(ctx, "Warm-up runs", 0, 10, 3, fmt = { "$it" })
        secRow = SeekRow(ctx, "Time limit per mode", 5, 120, 20, fmt = { "$it s" })
        coolRow = SeekRow(ctx, "Cooling pause between tests", 0, 20, 2, fmt = { "$it s" })
        tempRow = SeekRow(ctx, "Pause when battery reaches", 38, 48, 43, fmt = { "$it C" })
        for (r in listOf(threadRow, iterRow, warmRow, secRow, coolRow, tempRow)) c.addView(r, ctx.lp(bottom = 10))
        c.addView(
            ctx.text(
                "Benchmarks pause to cool down when the battery or Android's thermal status gets warm, and stop completely " +
                    "if the device gets hot. Nothing runs in the background when no test is active.",
                12f, Pal.sub
            ),
            ctx.lp(bottom = 10)
        )
        saved = ctx.text("", 12f, Pal.ok)
        c.addView(ctx.button("Save settings") { save() })
        c.addView(saved, ctx.lp(top = 6))
        root.addView(c)

        val about = ctx.card("Appearance and about")
        about.addView(
            ctx.text(
                "The app follows the system light / dark theme. Rust Android Graphics Laboratory 0.1 (stages 1-4: detection, " +
                    "CPU and GPU engines, benchmarks, hybrid CPU + GPU execution, results export).",
                13f, Pal.text
            )
        )
        root.addView(about, ctx.lp(top = 12))

        val log = ctx.card("Engine log")
        log.addView(ctx.button("Show recent log", false) { showLog() })
        logView = ctx.text("", 10f, Pal.sub, mono = true)
        logView.setTextIsSelectable(true)
        log.addView(logView, ctx.lp(top = 8))
        root.addView(log, ctx.lp(top = 12))
        return page(root)
    }

    override fun onShow() {
        act.async {
            val s = Rust.data("settings.get")
            act.ui {
                if (s != null) {
                    threadRow.value = s.optInt("threads", 0)
                    iterRow.value = s.optInt("iterations", 10).coerceIn(1, 50)
                    warmRow.value = s.optInt("warmup", 3).coerceIn(0, 10)
                    secRow.value = s.optDouble("max_seconds", 20.0).toInt().coerceIn(5, 120)
                    coolRow.value = s.optDouble("cooldown_s", 2.0).toInt().coerceIn(0, 20)
                    tempRow.value = s.optDouble("max_batt_temp_c", 43.0).toInt().coerceIn(38, 48)
                }
            }
        }
    }

    private fun save() {
        val o = JSONObject()
        o.put("threads", threadRow.value)
        o.put("iterations", iterRow.value)
        o.put("warmup", warmRow.value)
        o.put("max_seconds", secRow.value.toDouble())
        o.put("cooldown_s", coolRow.value.toDouble())
        o.put("max_batt_temp_c", tempRow.value.toDouble())
        act.async {
            val r = Rust.call("settings.set", o)
            act.ui {
                saved.text = if (r.optBoolean("ok", false)) "Saved." else Rust.error(r)
            }
        }
    }

    private fun showLog() {
        act.async {
            val d = Rust.data("log.recent")
            act.ui {
                val lines = d?.optJSONArray("lines") ?: JSONArray()
                val sb = StringBuilder()
                for (i in 0 until lines.length()) sb.append(lines.optString(i)).append('\n')
                logView.text = if (sb.isEmpty()) "(log is empty)" else sb.toString()
            }
        }
    }
}
