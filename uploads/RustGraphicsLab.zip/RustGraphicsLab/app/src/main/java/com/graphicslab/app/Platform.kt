package com.graphicslab.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/** Values only Android platform APIs can provide. Pushed to the Rust engine, never assumed there. */
object Platform {
    private val angleCandidates = listOf("com.android.angle", "com.google.android.angle")
    private val driverCandidates = listOf("com.android.gamedriver", "com.google.android.gamedriver")
    private val driverSettings = listOf(
        "angle_gl_driver_selection_pkgs",
        "angle_gl_driver_selection_values",
        "angle_debug_package",
        "game_driver_all_apps",
        "game_driver_opt_in_apps",
        "game_driver_prerelease_opt_in_apps",
        "game_driver_opt_out_apps",
        "updatable_driver_all_apps",
        "updatable_driver_production_opt_in_apps",
        "updatable_driver_prerelease_opt_in_apps",
        "updatable_driver_production_opt_out_apps"
    )

    fun staticInfo(ctx: Context): JSONObject {
        val o = JSONObject()
        o.put("manufacturer", Build.MANUFACTURER)
        o.put("model", Build.MODEL)
        o.put("brand", Build.BRAND)
        o.put("device", Build.DEVICE)
        o.put("board", Build.BOARD)
        o.put("hardware", Build.HARDWARE)
        o.put("release", Build.VERSION.RELEASE)
        o.put("sdk", Build.VERSION.SDK_INT)
        o.put("patch", Build.VERSION.SECURITY_PATCH)
        o.put("abis", Build.SUPPORTED_ABIS.joinToString(", "))
        val dm = ctx.resources.displayMetrics
        o.put("display", "${dm.widthPixels} x ${dm.heightPixels} px, ${dm.densityDpi} dpi")

        val pm = ctx.packageManager
        val angle = JSONArray()
        for (pkg in angleCandidates) {
            try {
                val pi = pm.getPackageInfo(pkg, 0)
                angle.put((pkg + " " + (pi.versionName ?: "")).trim())
            } catch (e: Exception) {
                // not installed or not visible
            }
        }
        o.put("angle_packages", angle)
        val drivers = JSONArray()
        for (pkg in driverCandidates) {
            try {
                val pi = pm.getPackageInfo(pkg, 0)
                drivers.put((pkg + " " + (pi.versionName ?: "")).trim())
            } catch (e: Exception) {
                // not installed or not visible
            }
        }
        o.put("driver_packages", drivers)

        val settings = JSONObject()
        for (k in driverSettings) {
            val v = try {
                Settings.Global.getString(ctx.contentResolver, k)
            } catch (e: Exception) {
                null
            }
            settings.put(k, v ?: "")
        }
        o.put("settings", settings)
        val dev = try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (e: Exception) {
            false
        }
        o.put("dev_options", dev)

        try {
            for (f in pm.systemAvailableFeatures) {
                val n = f.name
                if (n == "android.hardware.vulkan.version") o.put("vulkan_version", f.version)
                if (n == "android.hardware.vulkan.level") o.put("vulkan_level", f.version)
                if (n == null) o.put("gles_version_req", f.reqGlEsVersion)
            }
        } catch (e: Exception) {
            // ignore
        }
        return o
    }

    fun dynamicInfo(ctx: Context): JSONObject {
        val o = JSONObject()
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                if (t != Int.MIN_VALUE) o.put("battery_temp_c", t / 10.0)
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) o.put("battery_level", level * 100 / scale)
                val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                if (v > 0) o.put("voltage_mv", v)
            }
        } catch (e: Exception) {
            // ignore
        }
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (cur != Int.MIN_VALUE && cur != 0) o.put("current_ua", cur)
        } catch (e: Exception) {
            // ignore
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val pmgr = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                o.put("thermal_status", pmgr.currentThermalStatus)
            }
        } catch (e: Exception) {
            // ignore
        }
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            o.put("low_memory", mi.lowMemory)
            o.put("avail_mem_mb", mi.availMem / 1048576L)
        } catch (e: Exception) {
            // ignore
        }
        return o
    }
}
