package com.graphicslab.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Thin Android shell: navigation, platform data for the engine, file export. All logic is in Rust. */
class MainActivity : Activity() {
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    private val handler = Handler(Looper.getMainLooper())
    private val screens = ArrayList<Screen>()
    private val views = ArrayList<View?>()
    private val navIcons = ArrayList<ImageView>()
    private val navLabels = ArrayList<TextView>()
    private val navItems = ArrayList<View>()
    private lateinit var navScroll: HorizontalScrollView
    private var current = -1
    private lateinit var content: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView
    private var pendingExport: Triple<String, String, String>? = null

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Pal.init(this)
        Rust.call("app.init", JSONObject().put("files_dir", filesDir.absolutePath))
        Rust.call("platform.static", Platform.staticInfo(this))
        Rust.call("platform.update", Platform.dynamicInfo(this))

        screens.add(DashboardScreen(this))
        screens.add(DeviceScreen(this))
        screens.add(DriversScreen(this))
        screens.add(BenchScreen(this, "cpu"))
        screens.add(BenchScreen(this, "gpu"))
        screens.add(BenchScreen(this, "hybrid"))
        screens.add(MonitorScreen(this))
        screens.add(ResultsScreen(this))
        screens.add(SettingsScreen(this))
        for (s in screens) views.add(null)
        buildShell()
        showScreen(0)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        pool.shutdown()
    }

    private fun buildShell() {
        val root = vbox()
        root.setBackgroundColor(Pal.bg)

        val top = hbox()
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(16), dp(12), dp(16), dp(8))
        titleView = text("", 20f, Pal.text, bold = true)
        statusView = text("", 12f, Pal.sub)
        statusView.gravity = Gravity.END
        top.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(statusView, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val divider = View(this)
        divider.setBackgroundColor(Pal.line)
        root.addView(divider, LinearLayout.LayoutParams(MATCH, 1))

        navScroll = HorizontalScrollView(this)
        navScroll.isHorizontalScrollBarEnabled = false
        navScroll.setBackgroundColor(Pal.card)
        val navRow = hbox()
        navScroll.addView(navRow)
        val labels = listOf("Dashboard", "Device", "Drivers", "CPU", "GPU", "Hybrid", "Monitor", "Results", "Settings")
        for ((i, s) in screens.withIndex()) {
            val item = vbox()
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(dp(6), dp(8), dp(6), dp(8))
            val icon = ImageView(this)
            icon.setImageResource(s.iconRes)
            icon.setColorFilter(Pal.sub)
            item.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            val label = text(labels[i], 10f, Pal.sub)
            label.gravity = Gravity.CENTER
            item.addView(label, LinearLayout.LayoutParams(WRAP, WRAP))
            item.setOnClickListener { showScreen(i) }
            navIcons.add(icon)
            navLabels.add(label)
            navItems.add(item)
            navRow.addView(item, LinearLayout.LayoutParams(dp(78), WRAP))
        }
        root.addView(navScroll, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    fun showScreen(i: Int) {
        if (i == current) return
        if (current >= 0) screens[current].onHide()
        current = i
        val v = views[i] ?: screens[i].build().also { views[i] = it }
        content.removeAllViews()
        content.addView(v)
        titleView.text = screens[i].title
        for (k in navIcons.indices) {
            val on = k == i
            navIcons[k].setColorFilter(if (on) Pal.primary else Pal.sub)
            navLabels[k].setTextColor(if (on) Pal.primary else Pal.sub)
        }
        navScroll.post { navScroll.smoothScrollTo(maxOf(0, navItems[i].left - dp(90)), 0) }
        screens[i].onShow()
    }

    private fun tick() {
        val dyn = Platform.dynamicInfo(this)
        Rust.call("platform.update", dyn)
        val t = dyn.optDouble("battery_temp_c", Double.NaN)
        statusView.text = if (t.isNaN()) "" else String.format("%.1f C", t)
        if (current >= 0) screens[current].tick()
    }

    fun async(work: () -> Unit) {
        pool.execute { work() }
    }

    fun ui(f: () -> Unit) {
        runOnUiThread { f() }
    }

    fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    /** Runs the default comparison (matrix multiply, CPU vs GPU vs Hybrid) and opens the Hybrid screen. */
    fun startQuickTest() {
        val cfg = JSONObject()
        cfg.put("workload", "matmul")
        cfg.put("scale", 1)
        cfg.put("modes", JSONArray(listOf("cpu", "gpu", "hybrid")))
        cfg.put("distribution", "auto")
        cfg.put("iterations", 8)
        cfg.put("warmup", 3)
        async {
            val r = Rust.call("bench.start", cfg)
            ui {
                if (!r.optBoolean("ok", false)) toast(Rust.error(r)) else showScreen(5)
            }
        }
    }

    fun openDeveloperOptions() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                toast("Cannot open the system settings on this device")
            }
        }
    }

    fun exportResults(format: String, ids: List<String>) {
        val args = JSONObject().put("format", format)
        if (ids.isNotEmpty()) args.put("ids", JSONArray(ids))
        async {
            val r = Rust.call("history.export", args)
            ui {
                if (!r.optBoolean("ok", false)) {
                    toast(Rust.error(r))
                } else {
                    val d = r.optJSONObject("data")
                    if (d != null) saveDocument(d.optString("name"), d.optString("mime"), d.optString("content"))
                }
            }
        }
    }

    private fun saveDocument(name: String, mime: String, content: String) {
        pendingExport = Triple(name, mime, content)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_TITLE, name)
        try {
            startActivityForResult(i, REQ_EXPORT)
        } catch (e: ActivityNotFoundException) {
            pendingExport = null
            toast("No file picker is available on this device")
        }
    }

    @Deprecated("Platform API; fine for a simple SAF save dialog")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_EXPORT) return
        val p = pendingExport
        pendingExport = null
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null && p != null) {
            pool.execute {
                val ok = try {
                    contentResolver.openOutputStream(uri)?.use { it.write(p.third.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    false
                }
                runOnUiThread { toast(if (ok) "Saved " + p.first else "Could not save the file") }
            }
        }
    }

    companion object {
        private const val REQ_EXPORT = 4711
    }
}
