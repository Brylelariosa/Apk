//! Live monitor: sampled only when the UI asks (no background thread, no wasted battery).
use std::collections::VecDeque;
use std::time::Instant;

use lab_core::platform;
use lab_core::sysinfo;
use lab_core::util::{row, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

const KEEP: usize = 120;

pub struct Monitor {
    last_cpu: f64,
    last_wall: Instant,
    cpu_pct: VecDeque<f64>,
    rss_mb: VecDeque<f64>,
    batt_temp: VecDeque<f64>,
    avail_mb: VecDeque<f64>,
}

fn push(q: &mut VecDeque<f64>, v: f64) {
    if q.len() >= KEEP {
        q.pop_front();
    }
    q.push_back(v);
}

fn chart(title: &str, unit: &str, color: &str, q: &VecDeque<f64>) -> Value {
    let values: Vec<f64> = q.iter().cloned().collect();
    json!({
        "title": title,
        "chart": { "unit": unit, "series": [ { "name": title, "color": color, "values": values } ] }
    })
}

impl Monitor {
    pub fn new() -> Monitor {
        Monitor {
            last_cpu: sysinfo::process_cpu_seconds(),
            last_wall: Instant::now(),
            cpu_pct: VecDeque::new(),
            rss_mb: VecDeque::new(),
            batt_temp: VecDeque::new(),
            avail_mb: VecDeque::new(),
        }
    }

    /// Takes one sample and returns the display sections.
    pub fn sample(&mut self) -> Vec<Value> {
        let now = Instant::now();
        let cpu_now = sysinfo::process_cpu_seconds();
        let dt = now.duration_since(self.last_wall).as_secs_f64();
        let cores = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1) as f64;
        let mut cpu = 0.0;
        if dt > 0.05 {
            cpu = ((cpu_now - self.last_cpu) / dt / cores * 100.0).clamp(0.0, 100.0);
            self.last_cpu = cpu_now;
            self.last_wall = now;
            push(&mut self.cpu_pct, cpu);
        } else if let Some(last) = self.cpu_pct.back() {
            cpu = *last;
        }
        let rss = sysinfo::process_rss_kb().map(|k| k as f64 / 1024.0);
        if let Some(r) = rss {
            push(&mut self.rss_mb, r);
        }
        let snap = platform::snapshot();
        if let Some(t) = snap.battery_temp_c {
            push(&mut self.batt_temp, t);
        }
        let avail = sysinfo::mem_available_kb().map(|k| k as f64 / 1024.0);
        if let Some(a) = avail {
            push(&mut self.avail_mb, a);
        }

        let mut rows = Vec::new();
        rows.push(row("App CPU load (all cores)", format!("{:.0} %", cpu), MEASURED));
        match rss {
            Some(r) => rows.push(row("App memory (resident)", format!("{:.0} MB", r), MEASURED)),
            None => rows.push(row("App memory (resident)", "not readable", UNAVAILABLE)),
        }
        match avail {
            Some(a) => rows.push(row("System RAM available", format!("{:.0} MB", a), MEASURED)),
            None => rows.push(row("System RAM available", "not readable", UNAVAILABLE)),
        }
        match snap.battery_temp_c {
            Some(t) => rows.push(row("Battery temperature", format!("{:.1} C", t), MEASURED)),
            None => rows.push(row("Battery temperature", "waiting for platform data", UNAVAILABLE)),
        }
        match snap.thermal_status {
            Some(s) => rows.push(row("Thermal status", platform::thermal_status_name(s), MEASURED)),
            None => rows.push(row("Thermal status", "not available", UNAVAILABLE)),
        }
        let zones = sysinfo::thermal_zones();
        if let Some((name, c)) = zones.iter().max_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)) {
            rows.push(row("Hottest readable zone", format!("{} {:.1} C", name, c), MEASURED));
        } else {
            rows.push(row("CPU temperature", "not readable by apps on this device", UNAVAILABLE));
        }
        rows.push(row("GPU load / FPS", "not measurable without root; FPS arrives with the rendering benchmark", UNAVAILABLE));

        let mut out = vec![json!({ "title": "Live metrics", "rows": rows })];
        out.push(chart("App CPU load (%)", "%", "cpu", &self.cpu_pct));
        out.push(chart("App memory (MB)", "MB", "hybrid", &self.rss_mb));
        out.push(chart("System RAM available (MB)", "MB", "gpu", &self.avail_mb));
        if !self.batt_temp.is_empty() {
            out.push(chart("Battery temperature (C)", "C", "warn", &self.batt_temp));
        }
        out
    }
}

impl Default for Monitor {
    fn default() -> Monitor {
        Monitor::new()
    }
}
