//! Local persistence: settings and benchmark history (JSON lines).
use std::fs;
use std::io::Write;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::model::BenchmarkResult;

const MAX_HISTORY: usize = 60;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub threads: usize,
    pub iterations: usize,
    pub warmup: usize,
    pub max_seconds: f64,
    pub cooldown_s: f64,
    pub max_batt_temp_c: f64,
}

impl Default for Settings {
    fn default() -> Settings {
        Settings {
            threads: 0,
            iterations: 10,
            warmup: 3,
            max_seconds: 20.0,
            cooldown_s: 2.0,
            max_batt_temp_c: 43.0,
        }
    }
}

pub fn load_settings(dir: &Path) -> Settings {
    fs::read_to_string(dir.join("settings.json"))
        .ok()
        .and_then(|s| serde_json::from_str::<Settings>(&s).ok())
        .unwrap_or_default()
}

pub fn save_settings(dir: &Path, s: &Settings) -> Result<(), String> {
    let text = serde_json::to_string_pretty(s).map_err(|e| e.to_string())?;
    fs::write(dir.join("settings.json"), text).map_err(|e| e.to_string())
}

/// Oldest first.
pub fn load_history(dir: &Path) -> Vec<BenchmarkResult> {
    let text = fs::read_to_string(dir.join("history.jsonl")).unwrap_or_default();
    text.lines()
        .filter(|l| !l.trim().is_empty())
        .filter_map(|l| serde_json::from_str::<BenchmarkResult>(l).ok())
        .collect()
}

fn rewrite(dir: &Path, items: &[BenchmarkResult]) -> Result<(), String> {
    let mut text = String::new();
    for r in items {
        let line = serde_json::to_string(r).map_err(|e| e.to_string())?;
        text.push_str(&line);
        text.push('\n');
    }
    fs::write(dir.join("history.jsonl"), text).map_err(|e| e.to_string())
}

pub fn append_history(dir: &Path, r: &BenchmarkResult) -> Result<(), String> {
    let mut items = load_history(dir);
    if items.len() >= MAX_HISTORY {
        let drop = items.len() + 1 - MAX_HISTORY;
        items.drain(0..drop);
        rewrite(dir, &items)?;
    }
    let line = serde_json::to_string(r).map_err(|e| e.to_string())?;
    let mut f = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join("history.jsonl"))
        .map_err(|e| e.to_string())?;
    writeln!(f, "{}", line).map_err(|e| e.to_string())
}

pub fn clear_history(dir: &Path) -> Result<(), String> {
    match fs::remove_file(dir.join("history.jsonl")) {
        Ok(()) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(e.to_string()),
    }
}
