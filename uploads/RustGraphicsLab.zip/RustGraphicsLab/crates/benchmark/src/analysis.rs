//! Evidence-based bottleneck diagnosis. Every finding quotes the measurement it is based on.
use lab_core::sysinfo;

use crate::model::{BenchmarkResult, Diagnosis, ModeResult};

fn d(kind: &str, confidence: &str, evidence: String, recommendation: &str) -> Diagnosis {
    Diagnosis {
        kind: kind.to_string(),
        confidence: confidence.to_string(),
        evidence,
        recommendation: recommendation.to_string(),
    }
}

fn mean(v: &[f64]) -> f64 {
    if v.is_empty() {
        0.0
    } else {
        v.iter().sum::<f64>() / v.len() as f64
    }
}

pub fn diagnose(r: &BenchmarkResult) -> Vec<Diagnosis> {
    let mut out: Vec<Diagnosis> = Vec::new();
    let cpu = r.modes.iter().find(|m| m.mode == "cpu");
    let gpu = r.modes.iter().find(|m| m.mode == "gpu");
    let hyb = r.modes.iter().find(|m| m.mode == "hybrid");

    // correctness first
    for m in &r.modes {
        if m.iterations > 0 && !m.validation.ok {
            out.push(d(
                "Correctness failure",
                "high",
                format!(
                    "{}: {} of {} checked values differ from the CPU reference (max error {:.2e}).",
                    m.label, m.validation.mismatches, m.validation.checked, m.validation.max_abs_err
                ),
                "Do not trust timings from this mode. The GPU driver may mis-compile the kernel; try the other backend (Vulkan / OpenGL ES) on the Graphics Drivers screen.",
            ));
        }
    }

    // GPU-only: transfer / synchronisation
    if let Some(g) = gpu {
        if g.total_ms.mean > 0.0 {
            let overhead = g.submit_ms_avg + g.readback_ms_avg;
            let share = overhead / g.total_ms.mean;
            if share > 0.35 {
                out.push(d(
                    "Data-transfer-bound (GPU)",
                    "medium",
                    format!(
                        "{:.0}% of the GPU-only run ({:.2} of {:.2} ms) is submission and result readback.",
                        share * 100.0,
                        overhead,
                        g.total_ms.mean
                    ),
                    "Keep data resident on the GPU between runs, read back less data, or batch more work per dispatch.",
                ));
            }
            if let Some(b) = &g.gpu_busy_ms {
                let busy_share = b.mean / g.total_ms.mean;
                if busy_share < 0.5 {
                    out.push(d(
                        "Synchronization-bound (GPU)",
                        "medium",
                        format!(
                            "The GPU executed for {:.2} ms (timestamp queries) but the run took {:.2} ms: it was idle {:.0}% of the time.",
                            b.mean,
                            g.total_ms.mean,
                            (1.0 - busy_share) * 100.0
                        ),
                        "Use asynchronous execution with fewer synchronization points, or a larger problem so launch/sync cost is amortized.",
                    ));
                }
            }
        }
    }

    // CPU-only: parallel efficiency
    if let Some(c) = cpu {
        if let Some(bc) = c.busy_cores {
            let ratio = bc / c.threads.max(1) as f64;
            if ratio < 0.6 && c.threads > 1 {
                out.push(d(
                    "Parallelism-limited (CPU)",
                    "medium",
                    format!(
                        "On average only {:.1} of {} CPU threads were busy ({:.0}%).",
                        bc,
                        c.threads,
                        ratio * 100.0
                    ),
                    "Improve parallelism: smaller chunks, fewer serial sections, or check that other apps are not using the CPU.",
                ));
            } else if let Some(g) = gpu {
                if ratio >= 0.85 && c.total_ms.mean > g.total_ms.mean * 1.3 {
                    out.push(d(
                        "CPU-bound",
                        "high",
                        format!(
                            "CPU threads were {:.0}% busy and the CPU run ({:.2} ms) is {:.1}x slower than the GPU run ({:.2} ms).",
                            ratio * 100.0,
                            c.total_ms.mean,
                            c.total_ms.mean / g.total_ms.mean,
                            g.total_ms.mean
                        ),
                        "Move more of this workload to the GPU (hybrid with a larger GPU share) or reduce the CPU workload.",
                    ));
                }
            }
        }
    }

    // memory bandwidth indication
    if r.workload.id == "vector_bw" {
        for m in &r.modes {
            if m.total_ms.mean > 0.0 {
                let gbs = r.workload.bytes / (m.total_ms.mean * 1e6);
                out.push(d(
                    "Memory-bandwidth-bound (likely)",
                    "medium",
                    format!(
                        "{}: one multiply-add per element moves {:.2} GB/s (nominal bytes / time). With so little arithmetic the run is limited by DRAM, which CPU and GPU share on a phone.",
                        m.label, gbs
                    ),
                    "Hybrid cannot add bandwidth here. Increase arithmetic per byte (fuse passes) or reduce data size.",
                ));
            }
        }
    }

    // hybrid analysis
    if let Some(h) = hyb {
        let best_single = [cpu, gpu]
            .iter()
            .filter_map(|m| m.map(|x| (x.mode.clone(), x.total_ms.mean)))
            .filter(|(_, v)| *v > 0.0)
            .fold(None, |acc: Option<(String, f64)>, cur| match acc {
                Some(a) if a.1 <= cur.1 => Some(a),
                _ => Some(cur),
            });
        if let Some((name, best)) = best_single {
            if h.total_ms.mean > 0.0 {
                let speedup = best / h.total_ms.mean;
                if speedup < 0.98 {
                    out.push(d(
                        "Hybrid slower than the best single processor",
                        "high",
                        format!(
                            "Hybrid {:.2} ms vs {} only {:.2} ms (speedup {:.2}x); CPU and GPU were active together for {:.2} ms.",
                            h.total_ms.mean, name, best, speedup, h.overlap_ms.mean
                        ),
                        "The workload is probably too small to pay for GPU launch + readback, or CPU and GPU contend for memory bandwidth and thermal budget. Try a larger size or Automatic balancing.",
                    ));
                } else {
                    out.push(d(
                        "Hybrid speedup",
                        "high",
                        format!(
                            "Hybrid {:.2} ms vs best single processor ({}) {:.2} ms: {:.2}x. CPU share {:.0}%, overlap {:.2} ms.",
                            h.total_ms.mean,
                            name,
                            best,
                            speedup,
                            h.cpu_fraction_avg * 100.0,
                            h.overlap_ms.mean
                        ),
                        "Cooperative execution helps for this configuration.",
                    ));
                }
            }
        }
        if h.cpu_ms.mean > 0.0 && h.gpu_wall_ms.mean > 0.0 {
            let (c, g) = (h.cpu_ms.mean, h.gpu_wall_ms.mean);
            if g > c * 1.25 {
                out.push(d(
                    "GPU-bound (hybrid imbalance)",
                    "high",
                    format!("The CPU part took {:.2} ms but the GPU part {:.2} ms; the CPU waited {:.2} ms.", c, g, h.wait_ms.mean),
                    "Give the CPU a larger share or use Automatic balancing; reduce shader complexity or resolution.",
                ));
            } else if c > g * 1.25 {
                out.push(d(
                    "CPU-bound (hybrid imbalance)",
                    "high",
                    format!("The CPU part took {:.2} ms but the GPU part only {:.2} ms; the GPU sat idle.", c, g),
                    "Give the GPU a larger share or use Automatic balancing.",
                ));
            }
        }
        let wait_share = if h.total_ms.mean > 0.0 { h.wait_ms.mean / h.total_ms.mean } else { 0.0 };
        if wait_share > 0.3 && h.overlap_ms.mean < 0.5 * h.total_ms.mean {
            out.push(d(
                "Synchronization-bound (hybrid)",
                "medium",
                format!("The main thread waited {:.0}% of the run for the GPU and the processors overlapped only {:.0}% of it.", wait_share * 100.0, h.overlap_ms.mean / h.total_ms.mean * 100.0),
                "Use fewer, larger GPU submissions and keep the CPU busy with independent work while the GPU runs.",
            ));
        }
    }

    // thermal
    for m in &r.modes {
        let n = m.series_total_ms.len();
        if n >= 6 {
            let third = n / 3;
            let first = mean(&m.series_total_ms[..third]);
            let last = mean(&m.series_total_ms[n - third..]);
            if first > 0.0 && last / first > 1.15 {
                let hot = m.max_thermal_status.unwrap_or(0) >= 2;
                let temp = match (m.batt_temp_start, m.batt_temp_end) {
                    (Some(a), Some(b)) => format!(" Battery temperature {:.1} -> {:.1} C.", a, b),
                    _ => String::new(),
                };
                out.push(d(
                    "Thermal-throttling-bound (suspected)",
                    if hot { "high" } else { "medium" },
                    format!("{}: the last third of the runs is {:.0}% slower than the first third.{}", m.label, (last / first - 1.0) * 100.0, temp),
                    "Allow cooling periods between tests, lower the thread count or the workload size.",
                ));
            }
        }
    }

    // memory capacity
    if let Some(total_kb) = sysinfo::mem_total_kb() {
        let total_mb = total_kb as f64 / 1024.0;
        let peak = r.modes.iter().filter_map(|m| m.rss_peak_mb).fold(0.0, f64::max);
        if peak > 0.5 * total_mb {
            out.push(d(
                "Memory-capacity-bound (risk)",
                "medium",
                format!("Peak app memory {:.0} MB is {:.0}% of the device RAM ({:.0} MB).", peak, peak / total_mb * 100.0, total_mb),
                "Use a smaller problem size to avoid the low-memory killer.",
            ));
        }
    }

    if out.is_empty() {
        out.push(d(
            "No dominant bottleneck detected",
            "low",
            "None of the measured indicators crossed its threshold.".to_string(),
            "Try a larger size, or run all three modes (CPU, GPU, Hybrid) so the analyzer can compare them.",
        ));
    }
    out
}

/// Convenience for tests and reports.
pub fn find_mode<'a>(r: &'a BenchmarkResult, mode: &str) -> Option<&'a ModeResult> {
    r.modes.iter().find(|m| m.mode == mode)
}
