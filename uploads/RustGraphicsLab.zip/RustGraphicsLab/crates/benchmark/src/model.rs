//! Data model: benchmark configuration, results and live progress.
use hybrid_engine::{GpuPrep, Validation, WorkloadInfo};
use lab_core::stats::Stats;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct BenchConfig {
    pub workload: String,
    pub scale: usize,
    /// Any of "cpu", "gpu", "hybrid".
    pub modes: Vec<String>,
    pub distribution: String,
    pub custom_cpu_pct: f64,
    pub iterations: usize,
    pub warmup: usize,
    /// 0 = every logical core.
    pub threads: usize,
    pub backend: String,
    /// Wall-clock cap per mode.
    pub max_seconds: f64,
    pub cooldown_s: f64,
    pub max_batt_temp_c: f64,
}

impl Default for BenchConfig {
    fn default() -> BenchConfig {
        BenchConfig {
            workload: "matmul".to_string(),
            scale: 1,
            modes: vec!["cpu".to_string(), "gpu".to_string(), "hybrid".to_string()],
            distribution: "auto".to_string(),
            custom_cpu_pct: 40.0,
            iterations: 10,
            warmup: 3,
            threads: 0,
            backend: "auto".to_string(),
            max_seconds: 20.0,
            cooldown_s: 2.0,
            max_batt_temp_c: 43.0,
        }
    }
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct ModeResult {
    /// "cpu", "gpu" or "hybrid".
    pub mode: String,
    pub label: String,
    pub distribution: String,
    /// Average share of work units computed by the CPU (1.0 = CPU only, 0.0 = GPU only).
    pub cpu_fraction_avg: f64,
    pub threads: usize,
    pub iterations: usize,
    pub total_ms: Stats,
    pub cpu_ms: Stats,
    pub gpu_wall_ms: Stats,
    pub gpu_busy_ms: Option<Stats>,
    pub overlap_ms: Stats,
    pub wait_ms: Stats,
    pub submit_ms_avg: f64,
    pub readback_ms_avg: f64,
    pub merge_ms_avg: f64,
    /// Nominal giga-operations per second (operation counts are workload estimates).
    pub gops: f64,
    pub validation: Validation,
    pub cpu_util_pct: Option<f64>,
    pub busy_cores: Option<f64>,
    pub rss_start_mb: Option<f64>,
    pub rss_peak_mb: Option<f64>,
    pub batt_temp_start: Option<f64>,
    pub batt_temp_end: Option<f64>,
    pub max_thermal_status: Option<i64>,
    pub notes: Vec<String>,
    pub aborted: Option<String>,
    pub series_total_ms: Vec<f64>,
    pub series_cpu_ms: Vec<f64>,
    pub series_gpu_ms: Vec<f64>,
    pub series_fraction: Vec<f64>,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Diagnosis {
    pub kind: String,
    pub confidence: String,
    pub evidence: String,
    pub recommendation: String,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct BenchmarkResult {
    pub id: String,
    pub timestamp_ms: u64,
    pub app_version: String,
    pub config: BenchConfig,
    pub workload: WorkloadInfo,
    pub gpu_prep: Option<GpuPrep>,
    pub device: Value,
    pub gpu: Value,
    pub modes: Vec<ModeResult>,
    pub diagnosis: Vec<Diagnosis>,
    pub notes: Vec<String>,
}

#[derive(Clone, Debug, Default)]
pub struct SeriesData {
    pub name: String,
    pub color: String,
    pub values: Vec<f64>,
}

#[derive(Clone, Debug, Default)]
pub struct ChartData {
    pub title: String,
    pub unit: String,
    pub series: Vec<SeriesData>,
}

impl ChartData {
    pub fn to_json(&self) -> Value {
        let series: Vec<Value> = self
            .series
            .iter()
            .map(|s| json!({ "name": s.name, "color": s.color, "values": s.values }))
            .collect();
        json!({ "title": self.title, "chart": { "unit": self.unit, "series": series } })
    }
}

/// Live state shared between the benchmark thread and the UI poller.
#[derive(Clone, Debug, Default)]
pub struct Progress {
    pub running: bool,
    pub phase: String,
    pub fraction: f64,
    pub message: String,
    pub rows: Vec<(String, String, String)>,
    pub charts: Vec<ChartData>,
    pub result_id: Option<String>,
    pub error: Option<String>,
}

impl Progress {
    pub fn push_point(&mut self, chart: &str, unit: &str, series: &str, color: &str, v: f64) {
        let ci = match self.charts.iter().position(|c| c.title == chart) {
            Some(i) => i,
            None => {
                self.charts.push(ChartData {
                    title: chart.to_string(),
                    unit: unit.to_string(),
                    series: Vec::new(),
                });
                self.charts.len() - 1
            }
        };
        let c = &mut self.charts[ci];
        let si = match c.series.iter().position(|s| s.name == series) {
            Some(i) => i,
            None => {
                c.series.push(SeriesData {
                    name: series.to_string(),
                    color: color.to_string(),
                    values: Vec::new(),
                });
                c.series.len() - 1
            }
        };
        let s = &mut c.series[si];
        s.values.push(v);
        if s.values.len() > 400 {
            s.values.remove(0);
        }
    }

    pub fn to_json(&self) -> Value {
        let mut sections: Vec<Value> = Vec::new();
        if !self.rows.is_empty() {
            let rows: Vec<Value> = self
                .rows
                .iter()
                .map(|(a, b, c)| json!([a, b, c]))
                .collect();
            sections.push(json!({ "title": "Live", "rows": rows }));
        }
        for c in &self.charts {
            sections.push(c.to_json());
        }
        json!({
            "running": self.running,
            "phase": self.phase,
            "fraction": self.fraction,
            "message": self.message,
            "result_id": self.result_id,
            "error": self.error,
            "sections": sections,
        })
    }
}
