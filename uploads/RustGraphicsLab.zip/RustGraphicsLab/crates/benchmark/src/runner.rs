//! Benchmark session: runs the same workload on CPU only, GPU only and hybrid (CPU + GPU at the
//! same time), with warm-up, validation against a CPU reference, thermal protection and live
//! progress for the UI.
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use cpu_engine::CpuEngine;
use gpu_engine::GpuContext;
use hybrid_engine::{calibrate, run_once, Balancer, Distribution, Partition, Validation, Workload, WorkloadInfo};
use lab_core::platform;
use lab_core::stats::Stats;
use lab_core::sysinfo;
use lab_core::util::{round_to, unix_ms};
use serde_json::Value;

use crate::analysis;
use crate::model::{BenchConfig, BenchmarkResult, ModeResult, Progress};

/// Everything a session needs from the app.
pub struct SessionEnv {
    pub gpu: Option<GpuContext>,
    pub gpu_error: Option<String>,
    pub device: Value,
    pub gpu_info: Value,
    pub progress: Arc<Mutex<Progress>>,
    pub stop: Arc<AtomicBool>,
    /// CPU share in permille for the "custom" distribution; the UI may change it during a run.
    pub custom_permille: Arc<AtomicU32>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Kind {
    Cpu,
    Gpu,
    Hybrid,
}

impl Kind {
    fn id(self) -> &'static str {
        match self {
            Kind::Cpu => "cpu",
            Kind::Gpu => "gpu",
            Kind::Hybrid => "hybrid",
        }
    }

    fn name(self) -> &'static str {
        match self {
            Kind::Cpu => "CPU",
            Kind::Gpu => "GPU",
            Kind::Hybrid => "Hybrid",
        }
    }
}

enum Guard {
    Fine,
    Abort(String),
    EndEarly(String),
}

struct Counters {
    done: usize,
    planned: usize,
}

fn with_progress(env: &SessionEnv, f: impl FnOnce(&mut Progress)) {
    if let Ok(mut p) = env.progress.lock() {
        f(&mut p);
    }
}

fn stopped(env: &SessionEnv) -> bool {
    env.stop.load(Ordering::Relaxed)
}

fn sleep_interruptible(env: &SessionEnv, secs: f64) {
    let t0 = Instant::now();
    while t0.elapsed().as_secs_f64() < secs && !stopped(env) {
        std::thread::sleep(Duration::from_millis(100));
    }
}

fn avg(v: &[f64]) -> f64 {
    if v.is_empty() {
        0.0
    } else {
        v.iter().sum::<f64>() / v.len() as f64
    }
}

fn r3(a: &str, b: String, c: &str) -> (String, String, String) {
    (a.to_string(), b, c.to_string())
}

fn thermal_guard(cfg: &BenchConfig, env: &SessionEnv, hot_count: &mut u32, max_status: &mut i64) -> Guard {
    let snap = platform::snapshot();
    let status = snap.thermal_status.unwrap_or(0);
    if status > *max_status {
        *max_status = status;
    }
    if status >= 4 {
        return Guard::Abort(format!(
            "Aborted to protect the device: Android thermal status is {}",
            platform::thermal_status_name(status)
        ));
    }
    if let Some(t) = snap.battery_temp_c {
        if t >= cfg.max_batt_temp_c + 3.0 {
            return Guard::Abort(format!("Aborted to protect the device: battery reached {:.1} C", t));
        }
    }
    let hot = status >= 2 || snap.battery_temp_c.map(|t| t >= cfg.max_batt_temp_c).unwrap_or(false);
    if hot {
        *hot_count += 1;
        with_progress(env, |p| {
            p.message = "Device is warm - cooling before the next run".to_string();
        });
        sleep_interruptible(env, 8.0);
        if *hot_count >= 3 {
            return Guard::EndEarly(
                "Ended early (automatic workload reduction): the device stayed warm after repeated cooling pauses".to_string(),
            );
        }
    }
    Guard::Fine
}

pub fn run_session(cfg: &BenchConfig, env: &SessionEnv) -> Result<BenchmarkResult, String> {
    let mut wl: Box<dyn Workload> = hybrid_engine::create(&cfg.workload, cfg.scale)?;
    let info = wl.info();
    let mut result = BenchmarkResult {
        id: unix_ms().to_string(),
        timestamp_ms: unix_ms(),
        app_version: env!("CARGO_PKG_VERSION").to_string(),
        config: cfg.clone(),
        workload: info.clone(),
        device: env.device.clone(),
        gpu: env.gpu_info.clone(),
        ..Default::default()
    };

    let want = |m: &str| cfg.modes.iter().any(|x| x == m);
    let run_cpu = want("cpu");
    let mut run_gpu = want("gpu");
    let mut run_hybrid = want("hybrid");

    if (run_gpu || run_hybrid) && env.gpu.is_none() {
        result.notes.push(format!(
            "GPU modes skipped: {}",
            env.gpu_error.clone().unwrap_or_else(|| "no GPU backend available".to_string())
        ));
        run_gpu = false;
        run_hybrid = false;
    }
    if run_gpu || run_hybrid {
        if let Some(gpu) = env.gpu.as_ref() {
            with_progress(env, |p| {
                p.phase = "Preparing GPU".to_string();
                p.message = "Compiling shaders and uploading input data".to_string();
            });
            match wl.gpu_prepare(gpu) {
                Ok(prep) => result.gpu_prep = Some(prep),
                Err(e) => {
                    result.notes.push(format!("GPU modes skipped: {}", e));
                    run_gpu = false;
                    run_hybrid = false;
                }
            }
        }
    }
    if !run_cpu && !run_gpu && !run_hybrid {
        return Err("Nothing to run: no usable processor mode was selected".to_string());
    }

    let full = CpuEngine::new(cfg.threads);
    // In hybrid runs one core is left for the GPU driver / waiter thread so GPU submission and
    // result readback are not starved by the CPU workers.
    let hybrid_threads = if full.threads >= 3 { full.threads - 1 } else { full.threads };
    let hybrid_cpu = CpuEngine::new(hybrid_threads);

    let mut kinds: Vec<Kind> = Vec::new();
    if run_cpu {
        kinds.push(Kind::Cpu);
    }
    if run_gpu {
        kinds.push(Kind::Gpu);
    }
    if run_hybrid {
        kinds.push(Kind::Hybrid);
    }
    let mut counters = Counters {
        done: 0,
        planned: kinds.len() * (cfg.warmup + 1 + cfg.iterations),
    };

    for (idx, kind) in kinds.iter().enumerate() {
        if stopped(env) {
            result.notes.push("Stopped by user".to_string());
            break;
        }
        if idx > 0 && cfg.cooldown_s > 0.0 {
            with_progress(env, |p| {
                p.message = "Cooling pause between tests".to_string();
            });
            sleep_interruptible(env, cfg.cooldown_s);
        }
        let engine = if *kind == Kind::Hybrid { &hybrid_cpu } else { &full };
        let mr = run_mode(&mut *wl, cfg, env, *kind, engine, &info, &mut counters)?;
        let aborted = mr.aborted.is_some();
        result.modes.push(mr);
        if aborted {
            break;
        }
    }
    result.diagnosis = analysis::diagnose(&result);
    Ok(result)
}

fn run_mode(
    wl: &mut dyn Workload,
    cfg: &BenchConfig,
    env: &SessionEnv,
    kind: Kind,
    engine: &CpuEngine,
    info: &WorkloadInfo,
    counters: &mut Counters,
) -> Result<ModeResult, String> {
    let total_units = info.units;
    let gran = info.granularity;
    let dist = Distribution::parse(&cfg.distribution);
    let mut notes: Vec<String> = Vec::new();
    let label = match kind {
        Kind::Cpu => "CPU only".to_string(),
        Kind::Gpu => "GPU only".to_string(),
        Kind::Hybrid => format!("Hybrid - {}", dist.label()),
    };
    with_progress(env, |p| {
        p.phase = label.clone();
        p.message = String::new();
    });
    if kind == Kind::Hybrid {
        let full_threads = CpuEngine::new(cfg.threads).threads;
        if engine.threads < full_threads {
            notes.push(format!(
                "{} CPU worker threads (one core reserved for GPU submission and synchronization)",
                engine.threads
            ));
        } else {
            notes.push(format!("{} CPU worker threads", engine.threads));
        }
    }

    let mut aborted: Option<String> = None;
    let mut balancer: Option<Balancer> = None;
    let mut fixed: Option<f64> = None;
    if kind == Kind::Hybrid && (dist == Distribution::Auto || dist == Distribution::Balanced) {
        with_progress(env, |p| {
            p.phase = format!("{}: calibrating", label);
            p.message = "Measuring standalone CPU and GPU throughput".to_string();
        });
        match calibrate(wl, engine, total_units, gran) {
            Ok(b) => {
                if dist == Distribution::Balanced {
                    fixed = Some(b.hybrid_fraction());
                }
                notes.push(format!(
                    "Calibration: CPU {:.1} units/ms, GPU {:.1} units/ms, GPU fixed overhead {:.2} ms",
                    b.r_cpu, b.r_gpu, b.overhead_ms
                ));
                balancer = Some(b);
            }
            Err(e) => aborted = Some(format!("Calibration failed: {}", e)),
        }
    }

    let fraction = |bal: &Option<Balancer>| -> f64 {
        match kind {
            Kind::Cpu => 1.0,
            Kind::Gpu => 0.0,
            Kind::Hybrid => match dist {
                Distribution::Custom => env.custom_permille.load(Ordering::Relaxed) as f64 / 1000.0,
                Distribution::Auto => bal.as_ref().map(|b| b.hybrid_fraction()).unwrap_or(0.5),
                Distribution::Balanced => fixed.unwrap_or(0.5),
                other => other.fixed_fraction().unwrap_or(0.5),
            },
        }
    };
    let make_part = |f: f64| -> Partition {
        match kind {
            Kind::Cpu => Partition::all_cpu(total_units),
            Kind::Gpu => Partition::all_gpu(total_units),
            Kind::Hybrid => Partition::split(total_units, f, gran),
        }
    };
    let adaptive = kind == Kind::Hybrid && dist == Distribution::Auto;

    // ---- warm-up (also lets Automatic balancing converge)
    for i in 0..cfg.warmup {
        if aborted.is_some() {
            break;
        }
        if stopped(env) {
            aborted = Some("Stopped by user".to_string());
            break;
        }
        let part = make_part(fraction(&balancer));
        match run_once(wl, engine, &part) {
            Ok(obs) => {
                if adaptive {
                    if let Some(b) = balancer.as_mut() {
                        b.observe(&obs);
                    }
                }
            }
            Err(e) => {
                aborted = Some(format!("Run failed: {}", e));
                break;
            }
        }
        counters.done += 1;
        let (d, pl) = (counters.done, counters.planned);
        with_progress(env, |p| {
            p.fraction = d as f64 / pl.max(1) as f64;
            p.phase = format!("{}: warm-up {}/{}", label, i + 1, cfg.warmup);
        });
    }

    // ---- validation run (output poisoned first, then compared with a CPU reference)
    let mut validation = Validation::default();
    if aborted.is_none() {
        with_progress(env, |p| {
            p.phase = format!("{}: validating against CPU reference", label);
        });
        wl.clear_output();
        let part = make_part(fraction(&balancer));
        match run_once(wl, engine, &part) {
            Ok(_) => {
                validation = wl.validate(part.boundary());
                if !validation.ok {
                    notes.push(format!(
                        "VALIDATION FAILED: {} of {} checked values differ from the reference",
                        validation.mismatches, validation.checked
                    ));
                }
            }
            Err(e) => aborted = Some(format!("Run failed: {}", e)),
        }
        counters.done += 1;
    }

    // ---- measured iterations
    let mut totals: Vec<f64> = Vec::new();
    let mut cpus: Vec<f64> = Vec::new();
    let mut gpus: Vec<f64> = Vec::new();
    let mut busys: Vec<f64> = Vec::new();
    let mut overlaps: Vec<f64> = Vec::new();
    let mut waits: Vec<f64> = Vec::new();
    let mut fracs: Vec<f64> = Vec::new();
    let mut submits: Vec<f64> = Vec::new();
    let mut readbacks: Vec<f64> = Vec::new();
    let mut merges: Vec<f64> = Vec::new();
    let mut series_cpu: Vec<f64> = Vec::new();
    let mut series_gpu: Vec<f64> = Vec::new();

    let cpu_t0 = sysinfo::process_cpu_seconds();
    let rss_start = sysinfo::process_rss_kb().map(|k| k as f64 / 1024.0);
    let snap0 = platform::snapshot();
    let mut max_status: i64 = snap0.thermal_status.unwrap_or(0);
    let mut hot_count = 0u32;
    let mut active_ms = 0.0f64;
    let loop_start = Instant::now();
    let mut i = 0usize;
    while aborted.is_none() && i < cfg.iterations {
        if stopped(env) {
            aborted = Some("Stopped by user".to_string());
            break;
        }
        if i >= 3 && loop_start.elapsed().as_secs_f64() > cfg.max_seconds {
            notes.push(format!(
                "Stopped after {} iterations: the {:.0} s time limit was reached",
                i, cfg.max_seconds
            ));
            break;
        }
        match thermal_guard(cfg, env, &mut hot_count, &mut max_status) {
            Guard::Fine => {}
            Guard::Abort(r) => {
                aborted = Some(r);
                break;
            }
            Guard::EndEarly(r) => {
                notes.push(r);
                break;
            }
        }
        let part = make_part(fraction(&balancer));
        let obs = match run_once(wl, engine, &part) {
            Ok(o) => o,
            Err(e) => {
                aborted = Some(format!("Run failed: {}", e));
                break;
            }
        };
        let frac = part.cpu_fraction();
        if adaptive {
            if let Some(b) = balancer.as_mut() {
                b.observe(&obs);
            }
        }
        active_ms += obs.total_ms;
        totals.push(obs.total_ms);
        fracs.push(frac);
        let gpu_total = obs.gpu_wall_ms + obs.gpu_readback_ms;
        series_cpu.push(obs.cpu_ms);
        series_gpu.push(gpu_total);
        if obs.cpu_units > 0 {
            cpus.push(obs.cpu_ms);
        }
        if obs.gpu_units > 0 {
            gpus.push(obs.gpu_wall_ms);
            waits.push(obs.gpu_wait_ms);
            submits.push(obs.gpu_submit_ms);
            readbacks.push(obs.gpu_readback_ms);
            merges.push(obs.merge_ms);
            if let Some(b) = obs.gpu_busy_ms {
                busys.push(b);
            }
        }
        if obs.cpu_units > 0 && obs.gpu_units > 0 {
            overlaps.push(obs.overlap_ms);
        }
        counters.done += 1;
        i += 1;

        let (d, pl) = (counters.done, counters.planned);
        let (done_i, total_i) = (i, cfg.iterations);
        with_progress(env, |p| {
            p.fraction = d as f64 / pl.max(1) as f64;
            p.phase = format!("{}: iteration {}/{}", label, done_i, total_i);
            p.message = String::new();
            let mut rows = vec![
                r3("Mode", label.clone(), ""),
                r3("Last run", format!("{:.2} ms", obs.total_ms), "measured"),
            ];
            if obs.cpu_units > 0 {
                rows.push(r3(
                    "CPU part",
                    format!("{:.2} ms for {:.0}% of the work", obs.cpu_ms, frac * 100.0),
                    "measured",
                ));
            }
            if obs.gpu_units > 0 {
                rows.push(r3(
                    "GPU part",
                    format!("{:.2} ms for {:.0}% of the work (until data is on the host)", gpu_total, (1.0 - frac) * 100.0),
                    "measured",
                ));
                if let Some(b) = obs.gpu_busy_ms {
                    rows.push(r3("GPU execution", format!("{:.2} ms (timestamp queries)", b), "measured"));
                }
            }
            if obs.cpu_units > 0 && obs.gpu_units > 0 {
                rows.push(r3("Both processors busy together", format!("{:.2} ms", obs.overlap_ms), "measured"));
            }
            p.rows = rows;
            p.push_point("Run time per iteration", "ms", kind.name(), kind.id(), obs.total_ms);
            if kind == Kind::Hybrid {
                p.push_point("CPU part vs GPU part per iteration (hybrid)", "ms", "CPU part", "cpu", obs.cpu_ms);
                p.push_point("CPU part vs GPU part per iteration (hybrid)", "ms", "GPU part", "gpu", gpu_total);
                p.push_point("CPU share of the work (hybrid)", "%", "CPU share", "hybrid", frac * 100.0);
            }
        });
    }

    let n = totals.len();
    let active_s = active_ms / 1000.0;
    let cpu_used = sysinfo::process_cpu_seconds() - cpu_t0;
    let logical = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1) as f64;
    let (cpu_util_pct, busy_cores) = if active_s > 0.05 && n > 0 {
        (
            Some(round_to(cpu_used / active_s / logical * 100.0, 1)),
            Some(round_to(cpu_used / active_s, 2)),
        )
    } else {
        (None, None)
    };
    let snap1 = platform::snapshot();
    let total_stats = Stats::from_samples(&totals);
    let gops = if total_stats.mean > 0.0 { info.flops / (total_stats.mean * 1e6) } else { 0.0 };
    if let Some(a) = &aborted {
        notes.push(a.clone());
    }
    Ok(ModeResult {
        mode: kind.id().to_string(),
        label,
        distribution: if kind == Kind::Hybrid { dist.id().to_string() } else { String::new() },
        cpu_fraction_avg: avg(&fracs),
        threads: engine.threads,
        iterations: n,
        total_ms: total_stats,
        cpu_ms: Stats::from_samples(&cpus),
        gpu_wall_ms: Stats::from_samples(&gpus),
        gpu_busy_ms: if busys.is_empty() { None } else { Some(Stats::from_samples(&busys)) },
        overlap_ms: Stats::from_samples(&overlaps),
        wait_ms: Stats::from_samples(&waits),
        submit_ms_avg: avg(&submits),
        readback_ms_avg: avg(&readbacks),
        merge_ms_avg: avg(&merges),
        gops,
        validation,
        cpu_util_pct,
        busy_cores,
        rss_start_mb: rss_start,
        rss_peak_mb: sysinfo::process_peak_rss_kb().map(|k| k as f64 / 1024.0),
        batt_temp_start: snap0.battery_temp_c,
        batt_temp_end: snap1.battery_temp_c,
        max_thermal_status: if snap0.thermal_status.is_some() || snap1.thermal_status.is_some() { Some(max_status) } else { None },
        notes,
        aborted,
        series_total_ms: totals,
        series_cpu_ms: series_cpu,
        series_gpu_ms: series_gpu,
        series_fraction: fracs,
    })
}
