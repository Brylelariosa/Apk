//! Benchmark orchestration: CPU vs GPU vs hybrid sessions, results, history, export,
//! bottleneck analysis and the live monitor.
pub mod analysis;
pub mod model;
pub mod monitor;
pub mod report;
pub mod runner;
pub mod store;

pub use model::{BenchConfig, BenchmarkResult, ChartData, Diagnosis, ModeResult, Progress, SeriesData};
pub use monitor::Monitor;
pub use runner::{run_session, SessionEnv};
pub use store::Settings;
