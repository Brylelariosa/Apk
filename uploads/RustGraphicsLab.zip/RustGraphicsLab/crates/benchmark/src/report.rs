//! Display sections, side-by-side comparison and JSON / CSV export of benchmark results.
use lab_core::platform;
use lab_core::util::{human_bytes, row, unix_ms, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

use crate::model::{BenchmarkResult, ModeResult};

fn jstr(v: &Value, k: &str) -> String {
    match v.get(k) {
        Some(Value::String(s)) => s.clone(),
        Some(Value::Null) | None => String::new(),
        Some(o) => o.to_string(),
    }
}

fn short_mode(m: &str) -> &'static str {
    match m {
        "cpu" => "CPU",
        "gpu" => "GPU",
        "hybrid" => "Hybrid",
        _ => "?",
    }
}

fn ms(v: f64) -> String {
    if v >= 100.0 {
        format!("{:.1}", v)
    } else {
        format!("{:.2}", v)
    }
}

/// One entry of the history list.
pub fn history_item(r: &BenchmarkResult) -> Value {
    let parts: Vec<String> = r
        .modes
        .iter()
        .map(|m| format!("{} {} ms", short_mode(&m.mode), ms(m.total_ms.mean)))
        .collect();
    let mut flags = String::new();
    if r.modes.iter().any(|m| m.iterations > 0 && !m.validation.ok) {
        flags.push_str("  [validation failed]");
    }
    json!({
        "id": r.id,
        "title": r.workload.name,
        "subtitle": format!("{}{}", parts.join("  |  "), flags),
        "time": r.timestamp_ms,
        "gpu": jstr(&r.gpu, "name"),
        "backend": jstr(&r.gpu, "backend"),
    })
}

pub fn result_sections(r: &BenchmarkResult) -> Vec<Value> {
    let mut out: Vec<Value> = Vec::new();

    // ---- summary
    let mut s: Vec<Value> = Vec::new();
    s.push(row("Workload", r.workload.name.clone(), MEASURED));
    s.push(row("Parameters", r.workload.params.clone(), MEASURED));
    let model = jstr(&r.device, "model");
    if !model.is_empty() {
        s.push(row("Device", format!("{} (Android {})", model, jstr(&r.device, "android")), MEASURED));
    }
    let cpu = jstr(&r.device, "cpu");
    if !cpu.is_empty() {
        s.push(row("CPU", cpu, MEASURED));
    }
    let gname = jstr(&r.gpu, "name");
    if !gname.is_empty() {
        s.push(row("GPU", format!("{} via {}", gname, jstr(&r.gpu, "backend")), MEASURED));
        let drv = jstr(&r.gpu, "driver");
        if !drv.is_empty() {
            s.push(row("Graphics driver", drv, MEASURED));
        }
    } else {
        s.push(row("GPU", "not used (no GPU backend)", UNAVAILABLE));
    }
    s.push(row(
        "Iterations",
        format!("{} measured after {} warm-up runs", r.config.iterations, r.config.warmup),
        MEASURED,
    ));
    if let Some(p) = &r.gpu_prep {
        s.push(row(
            "GPU one-time setup",
            format!(
                "shader build {} ms, input upload {} ms ({})",
                ms(p.build_ms),
                ms(p.upload_ms),
                human_bytes(p.upload_bytes)
            ),
            MEASURED,
        ));
    }
    out.push(json!({ "title": "Summary", "rows": s }));

    // ---- results table
    let base = r
        .modes
        .iter()
        .find(|m| m.mode == "cpu")
        .or(r.modes.first())
        .map(|m| m.total_ms.mean);
    let mut rows: Vec<Value> = Vec::new();
    for m in &r.modes {
        let vs = match base {
            Some(b) if m.total_ms.mean > 0.0 => format!("{:.2}x", b / m.total_ms.mean),
            _ => "-".to_string(),
        };
        let load = match m.cpu_util_pct {
            Some(v) => format!("{:.0}%", v),
            None => "n/a".to_string(),
        };
        let valid = if m.iterations == 0 {
            "-"
        } else if m.validation.ok {
            "OK"
        } else {
            "FAILED"
        };
        rows.push(json!([
            m.label,
            ms(m.total_ms.mean),
            ms(m.total_ms.min),
            ms(m.total_ms.max),
            ms(m.total_ms.p95),
            vs,
            format!("{:.2}", m.gops),
            load,
            valid
        ]));
    }
    out.push(json!({
        "title": "Results (time per run, lower is better)",
        "note": "Gops/s uses nominal operation counts of the workload, so compare it only between modes of the same workload.",
        "table": {
            "columns": ["Mode", "Avg ms", "Min", "Max", "P95", "vs CPU", "Gops/s", "CPU load", "Valid"],
            "rows": rows
        }
    }));

    // ---- cooperative details
    let mut det: Vec<Value> = Vec::new();
    for m in r.modes.iter().filter(|m| m.mode != "cpu") {
        let busy = m
            .gpu_busy_ms
            .as_ref()
            .map(|s| ms(s.mean))
            .unwrap_or_else(|| "n/a".to_string());
        let cpu_ms = if m.cpu_ms.count > 0 { ms(m.cpu_ms.mean) } else { "-".to_string() };
        let ovl = if m.overlap_ms.count > 0 { ms(m.overlap_ms.mean) } else { "-".to_string() };
        det.push(json!([
            short_mode(&m.mode),
            format!("{:.0}%", m.cpu_fraction_avg * 100.0),
            cpu_ms,
            ms(m.gpu_wall_ms.mean),
            busy,
            ovl,
            ms(m.wait_ms.mean),
            ms(m.submit_ms_avg),
            ms(m.readback_ms_avg),
            ms(m.merge_ms_avg)
        ]));
    }
    if !det.is_empty() {
        out.push(json!({
            "title": "GPU / cooperative execution details (averages, ms)",
            "note": "'Overlap' is the measured time both processors worked at the same time. 'GPU busy' comes from GPU timestamp queries and is n/a when the driver does not support them.",
            "table": {
                "columns": ["Mode", "CPU share", "CPU", "GPU wall", "GPU busy", "Overlap", "Main waited", "Submit", "Readback", "Merge"],
                "rows": det
            }
        }));
    }

    // ---- charts
    let series: Vec<Value> = r
        .modes
        .iter()
        .filter(|m| !m.series_total_ms.is_empty())
        .map(|m| json!({ "name": short_mode(&m.mode), "color": m.mode, "values": m.series_total_ms }))
        .collect();
    if !series.is_empty() {
        out.push(json!({ "title": "Run time per iteration (ms)", "chart": { "unit": "ms", "series": series } }));
    }
    if let Some(h) = r.modes.iter().find(|m| m.mode == "hybrid") {
        if !h.series_cpu_ms.is_empty() {
            out.push(json!({
                "title": "Hybrid: CPU part vs GPU part per iteration (ms)",
                "chart": { "unit": "ms", "series": [
                    { "name": "CPU part", "color": "cpu", "values": h.series_cpu_ms },
                    { "name": "GPU part", "color": "gpu", "values": h.series_gpu_ms }
                ] }
            }));
            let pct: Vec<f64> = h.series_fraction.iter().map(|f| f * 100.0).collect();
            out.push(json!({
                "title": "Hybrid: CPU share of the work (%)",
                "chart": { "unit": "%", "series": [ { "name": "CPU share", "color": "hybrid", "values": pct } ] }
            }));
        }
    }

    // ---- validation
    let mut v: Vec<Value> = Vec::new();
    for m in &r.modes {
        if m.iterations == 0 {
            continue;
        }
        let text = if m.validation.ok {
            format!("OK - {}", m.validation.detail)
        } else {
            format!(
                "FAILED - {} of {} values wrong (max error {:.2e}); {}",
                m.validation.mismatches, m.validation.checked, m.validation.max_abs_err, m.validation.detail
            )
        };
        v.push(row(&m.label, text, MEASURED));
    }
    if !v.is_empty() {
        out.push(json!({ "title": "Correctness (output vs independent CPU reference)", "rows": v }));
    }

    // ---- resources
    let mut res: Vec<Value> = Vec::new();
    for m in &r.modes {
        if m.iterations == 0 {
            continue;
        }
        let mut parts: Vec<String> = Vec::new();
        if let (Some(u), Some(b)) = (m.cpu_util_pct, m.busy_cores) {
            parts.push(format!("CPU {:.0}% of all cores ({:.1} cores busy)", u, b));
        }
        if let (Some(a), Some(p)) = (m.rss_start_mb, m.rss_peak_mb) {
            parts.push(format!("app memory {:.0} MB, peak {:.0} MB", a, p));
        }
        if let (Some(a), Some(b)) = (m.batt_temp_start, m.batt_temp_end) {
            parts.push(format!("battery {:.1} -> {:.1} C", a, b));
        }
        if let Some(s) = m.max_thermal_status {
            parts.push(format!("max thermal status {}", platform::thermal_status_name(s)));
        }
        if parts.is_empty() {
            res.push(row(&m.label, "no resource data available", UNAVAILABLE));
        } else {
            res.push(row(&m.label, parts.join("; "), MEASURED));
        }
    }
    if !res.is_empty() {
        out.push(json!({ "title": "Resources during the run", "rows": res }));
    }

    // ---- diagnosis
    let diag: Vec<Value> = r
        .diagnosis
        .iter()
        .map(|d| row(&d.kind, format!("{} Recommendation: {}", d.evidence, d.recommendation), &d.confidence))
        .collect();
    if !diag.is_empty() {
        out.push(json!({
            "title": "Bottleneck analysis",
            "note": "Each finding quotes the measurement it is based on. The tag is the confidence level.",
            "rows": diag
        }));
    }

    // ---- notes
    let mut notes: Vec<String> = r.notes.clone();
    for m in &r.modes {
        for n in &m.notes {
            notes.push(format!("{}: {}", short_mode(&m.mode), n));
        }
    }
    if !notes.is_empty() {
        out.push(json!({ "title": "Notes", "items_title": "Notes", "items": notes }));
    }
    out
}

fn mode_avg(r: &BenchmarkResult, id: &str) -> Option<f64> {
    r.modes
        .iter()
        .find(|m| m.mode == id && m.iterations > 0)
        .map(|m| m.total_ms.mean)
}

fn threads_of(r: &BenchmarkResult) -> String {
    r.modes
        .iter()
        .map(|m: &ModeResult| format!("{}={}", short_mode(&m.mode), m.threads))
        .collect::<Vec<_>>()
        .join(", ")
}

/// Side-by-side comparison. Differences in configuration are listed first so that results from
/// different setups are never silently mixed.
pub fn compare_sections(a: &BenchmarkResult, b: &BenchmarkResult) -> Vec<Value> {
    let mut diffs: Vec<Value> = Vec::new();
    {
        let mut add = |label: &str, x: String, y: String| {
            if x != y {
                diffs.push(json!([label, x, y]));
            }
        };
        add("Workload", a.workload.name.clone(), b.workload.name.clone());
        add("Parameters", a.workload.params.clone(), b.workload.params.clone());
        add(
            "GPU / backend",
            format!("{} / {}", jstr(&a.gpu, "name"), jstr(&a.gpu, "backend")),
            format!("{} / {}", jstr(&b.gpu, "name"), jstr(&b.gpu, "backend")),
        );
        add("Graphics driver", jstr(&a.gpu, "driver"), jstr(&b.gpu, "driver"));
        add("Device", jstr(&a.device, "model"), jstr(&b.device, "model"));
        add("CPU threads", threads_of(a), threads_of(b));
        add(
            "Iterations",
            a.config.iterations.to_string(),
            b.config.iterations.to_string(),
        );
        let hyb = |r: &BenchmarkResult| -> String {
            if r.modes.iter().any(|m| m.mode == "hybrid") {
                r.config.distribution.clone()
            } else {
                "n/a".to_string()
            }
        };
        add("Hybrid distribution", hyb(a), hyb(b));
        add("App version", a.app_version.clone(), b.app_version.clone());
    }

    let mut out: Vec<Value> = Vec::new();
    if diffs.is_empty() {
        out.push(json!({
            "title": "Configuration",
            "note": "Both results used the same workload, device, GPU backend, threads and iteration count, so they can be compared directly."
        }));
    } else {
        out.push(json!({
            "title": "Configuration differences",
            "note": "These results were NOT produced with identical settings. Read the comparison below with these differences in mind.",
            "table": { "columns": ["Setting", "A", "B"], "rows": diffs }
        }));
    }

    let mut rows: Vec<Value> = Vec::new();
    for (id, name) in [("cpu", "CPU only"), ("gpu", "GPU only"), ("hybrid", "Hybrid")] {
        let (x, y) = (mode_avg(a, id), mode_avg(b, id));
        if x.is_none() && y.is_none() {
            continue;
        }
        let change = match (x, y) {
            (Some(x), Some(y)) if x > 0.0 => {
                let pct = (y - x) / x * 100.0;
                if pct >= 0.0 {
                    format!("{:+.1}% (B slower)", pct)
                } else {
                    format!("{:+.1}% (B faster)", pct)
                }
            }
            _ => "-".to_string(),
        };
        rows.push(json!([
            name,
            x.map(ms).unwrap_or_else(|| "-".to_string()),
            y.map(ms).unwrap_or_else(|| "-".to_string()),
            change
        ]));
    }
    out.push(json!({
        "title": "Average time per run (ms)",
        "table": { "columns": ["Mode", "A", "B", "B vs A"], "rows": rows }
    }));
    out
}

fn csv_escape(f: &str) -> String {
    if f.contains(',') || f.contains('"') || f.contains('\n') {
        format!("\"{}\"", f.replace('"', "\"\""))
    } else {
        f.to_string()
    }
}

fn opt(v: Option<f64>) -> String {
    match v {
        Some(x) => format!("{:.3}", x),
        None => String::new(),
    }
}

pub fn to_csv(results: &[BenchmarkResult]) -> String {
    let mut s = String::from(
        "id,timestamp_ms,app_version,device_model,android,gpu,backend,driver,workload,parameters,mode,distribution,cpu_fraction_avg,threads,iterations,avg_ms,min_ms,max_ms,median_ms,p95_ms,stddev_ms,gops_nominal,cpu_ms_avg,gpu_wall_ms_avg,gpu_busy_ms_avg,overlap_ms_avg,main_wait_ms_avg,submit_ms_avg,readback_ms_avg,merge_ms_avg,validation_ok,validation_checked,validation_mismatches,max_abs_err,cpu_util_pct,rss_peak_mb,batt_temp_start_c,batt_temp_end_c,max_thermal_status\n",
    );
    for r in results {
        for m in &r.modes {
            let fields: Vec<String> = vec![
                r.id.clone(),
                r.timestamp_ms.to_string(),
                r.app_version.clone(),
                jstr(&r.device, "model"),
                jstr(&r.device, "android"),
                jstr(&r.gpu, "name"),
                jstr(&r.gpu, "backend"),
                jstr(&r.gpu, "driver"),
                r.workload.name.clone(),
                r.workload.params.clone(),
                m.mode.clone(),
                m.distribution.clone(),
                format!("{:.4}", m.cpu_fraction_avg),
                m.threads.to_string(),
                m.iterations.to_string(),
                format!("{:.4}", m.total_ms.mean),
                format!("{:.4}", m.total_ms.min),
                format!("{:.4}", m.total_ms.max),
                format!("{:.4}", m.total_ms.median),
                format!("{:.4}", m.total_ms.p95),
                format!("{:.4}", m.total_ms.stddev),
                format!("{:.4}", m.gops),
                format!("{:.4}", m.cpu_ms.mean),
                format!("{:.4}", m.gpu_wall_ms.mean),
                opt(m.gpu_busy_ms.as_ref().map(|s| s.mean)),
                format!("{:.4}", m.overlap_ms.mean),
                format!("{:.4}", m.wait_ms.mean),
                format!("{:.4}", m.submit_ms_avg),
                format!("{:.4}", m.readback_ms_avg),
                format!("{:.4}", m.merge_ms_avg),
                m.validation.ok.to_string(),
                m.validation.checked.to_string(),
                m.validation.mismatches.to_string(),
                format!("{:.6}", m.validation.max_abs_err),
                opt(m.cpu_util_pct),
                opt(m.rss_peak_mb),
                opt(m.batt_temp_start),
                opt(m.batt_temp_end),
                m.max_thermal_status.map(|v| v.to_string()).unwrap_or_default(),
            ];
            let line: Vec<String> = fields.iter().map(|f| csv_escape(f)).collect();
            s.push_str(&line.join(","));
            s.push('\n');
        }
    }
    s
}

pub fn to_json(results: &[BenchmarkResult]) -> String {
    let doc = json!({
        "app": "Rust Android Graphics Laboratory",
        "exported_at_unix_ms": unix_ms(),
        "result_count": results.len(),
        "results": results,
    });
    serde_json::to_string_pretty(&doc).unwrap_or_else(|_| "{}".to_string())
}
