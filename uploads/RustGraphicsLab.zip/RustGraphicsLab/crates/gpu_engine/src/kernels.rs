//! WGSL sources (kept as real files under shaders/compute and embedded at build time).
pub const SELFTEST: &str = include_str!("../../../shaders/compute/selftest.wgsl");
pub const MATMUL: &str = include_str!("../../../shaders/compute/matmul.wgsl");
pub const VECTOR: &str = include_str!("../../../shaders/compute/vector.wgsl");
pub const PARTICLES: &str = include_str!("../../../shaders/compute/particles.wgsl");
pub const IMAGE: &str = include_str!("../../../shaders/compute/image.wgsl");
