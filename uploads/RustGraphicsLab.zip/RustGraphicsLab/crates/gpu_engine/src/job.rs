//! One asynchronous compute dispatch + result readback.
//! `submit_range` returns immediately after queue submission, so the caller can do real CPU work
//! while the GPU executes. A dedicated waiter thread records the exact completion time.
use std::sync::Arc;
use std::time::{Duration, Instant};

use lab_core::util::ms_since;

use crate::context::GpuContext;
use crate::kernel::Kernel;

pub struct RangeJob<'a> {
    pub kernel: &'a Kernel,
    pub bind_group: &'a wgpu::BindGroup,
    pub groups: (u32, u32, u32),
    /// Uniform buffer + its new contents (written before the dispatch).
    pub params: Option<(&'a wgpu::Buffer, Vec<u8>)>,
    /// Buffer the kernel writes results into (results start at offset 0).
    pub out: &'a wgpu::Buffer,
    pub staging: Arc<wgpu::Buffer>,
    /// Bytes copied back to the host (multiple of 4).
    pub read_bytes: u64,
}

#[derive(Clone, Debug)]
pub struct GpuTiming {
    /// GPU execution time from timestamp queries, when supported.
    pub busy_ms: Option<f64>,
    /// Time spent mapping and copying the result into host memory.
    pub readback_ms: f64,
    /// Instant at which the GPU work was observed complete.
    pub done_at: Instant,
}

pub struct Pending {
    handle: std::thread::JoinHandle<Result<(Vec<u8>, GpuTiming), String>>,
    /// Instant the submission started (encoding included).
    pub submitted_at: Instant,
    /// Host time spent encoding and submitting.
    pub submit_ms: f64,
}

impl Pending {
    pub fn wait(self) -> Result<(Vec<u8>, GpuTiming), String> {
        match self.handle.join() {
            Ok(r) => r,
            Err(_) => Err("GPU wait thread panicked".to_string()),
        }
    }
}

pub fn submit_range(ctx: &GpuContext, job: RangeJob<'_>) -> Result<Pending, String> {
    if job.read_bytes == 0 || job.read_bytes % 4 != 0 {
        return Err(format!("invalid GPU read size: {} bytes", job.read_bytes));
    }
    let t0 = Instant::now();
    if let Some((buf, bytes)) = &job.params {
        ctx.queue.write_buffer(buf, 0, bytes);
    }
    let use_ts = ctx.timestamps;
    let query_set = if use_ts {
        Some(ctx.device.create_query_set(&wgpu::QuerySetDescriptor {
            label: Some("lab-ts"),
            ty: wgpu::QueryType::Timestamp,
            count: 2,
        }))
    } else {
        None
    };
    let resolve = if use_ts {
        Some(ctx.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("lab-ts-resolve"),
            size: 16,
            usage: wgpu::BufferUsages::QUERY_RESOLVE | wgpu::BufferUsages::COPY_SRC,
            mapped_at_creation: false,
        }))
    } else {
        None
    };
    let mut enc = ctx
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("lab-job") });
    {
        let ts_writes = query_set.as_ref().map(|qs| wgpu::ComputePassTimestampWrites {
            query_set: qs,
            beginning_of_pass_write_index: Some(0),
            end_of_pass_write_index: Some(1),
        });
        let mut pass = enc.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("lab-pass"),
            timestamp_writes: ts_writes,
        });
        pass.set_pipeline(&job.kernel.pipeline);
        pass.set_bind_group(0, job.bind_group, &[]);
        pass.dispatch_workgroups(job.groups.0, job.groups.1, job.groups.2);
    }
    enc.copy_buffer_to_buffer(job.out, 0, &job.staging, 0, job.read_bytes);
    let ts_off = (job.read_bytes + 15) / 16 * 16;
    if let (Some(qs), Some(rb)) = (query_set.as_ref(), resolve.as_ref()) {
        enc.resolve_query_set(qs, 0..2, rb, 0);
        enc.copy_buffer_to_buffer(rb, 0, &job.staging, ts_off, 16);
    }
    ctx.queue.submit(std::iter::once(enc.finish()));
    let submit_ms = ms_since(t0);

    let staging = job.staging.clone();
    let read_bytes = job.read_bytes;
    let ctx2 = ctx.clone();
    let handle = std::thread::Builder::new()
        .name("gpu-wait".to_string())
        .spawn(move || wait_for_job(ctx2, staging, read_bytes, ts_off, use_ts))
        .map_err(|e| format!("cannot start GPU wait thread: {}", e))?;
    Ok(Pending {
        handle,
        submitted_at: t0,
        submit_ms,
    })
}

fn read_u64(b: &[u8], o: usize) -> Option<u64> {
    let s = b.get(o..o + 8)?;
    let mut a = [0u8; 8];
    a.copy_from_slice(s);
    Some(u64::from_le_bytes(a))
}

fn wait_for_job(
    ctx: GpuContext,
    staging: Arc<wgpu::Buffer>,
    read_bytes: u64,
    ts_off: u64,
    use_ts: bool,
) -> Result<(Vec<u8>, GpuTiming), String> {
    let (tx, rx) = std::sync::mpsc::channel::<bool>();
    staging.slice(..).map_async(wgpu::MapMode::Read, move |r| {
        let _ = tx.send(r.is_ok());
    });
    let _ = ctx.device.poll(wgpu::Maintain::Wait);
    let done_at = Instant::now();
    let ok = rx.recv_timeout(Duration::from_secs(30)).unwrap_or(false);
    if !ok {
        return Err("GPU job failed or timed out (result buffer could not be mapped)".to_string());
    }
    let t_read = Instant::now();
    let slice = staging.slice(..);
    let view = slice.get_mapped_range();
    let bytes = view[..read_bytes as usize].to_vec();
    let busy_ms = if use_ts {
        match (read_u64(&view, ts_off as usize), read_u64(&view, ts_off as usize + 8)) {
            (Some(a), Some(b)) if b > a => {
                let ms = (b - a) as f64 * ctx.timestamp_period_ns as f64 / 1.0e6;
                if ms < 60_000.0 {
                    Some(ms)
                } else {
                    None
                }
            }
            _ => None,
        }
    } else {
        None
    };
    drop(view);
    staging.unmap();
    Ok((
        bytes,
        GpuTiming {
            busy_ms,
            readback_ms: ms_since(t_read),
            done_at,
        },
    ))
}
