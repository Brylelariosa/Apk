//! GPU compute engine built on wgpu (Vulkan first, OpenGL ES fallback).
//! Every wgpu call lives in this crate so a wgpu upgrade touches one place only.
pub mod context;
pub mod job;
pub mod kernel;
pub mod kernels;

pub use context::{enumerate_adapters, vendor_name, AdapterSummary, BackendPref, GpuContext, GpuInner};
pub use job::{submit_range, GpuTiming, Pending, RangeJob};
pub use kernel::{BindKind, Kernel};
/// Re-exported so dependent crates use exactly the same wgpu version.
pub use wgpu;
