//! A compiled compute pipeline plus its bind group layout.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BindKind {
    StorageRead,
    StorageRw,
    Uniform,
}

pub struct Kernel {
    pub pipeline: wgpu::ComputePipeline,
    pub layout: wgpu::BindGroupLayout,
    pub name: String,
}
