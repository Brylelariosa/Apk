//! Adapter selection, device creation and resource helpers.
use std::future::Future;
use std::sync::Arc;
use std::time::Instant;

use lab_core::util::ms_since;
use serde::Serialize;

use crate::kernel::{BindKind, Kernel};

/// Minimal executor: wgpu futures on native targets complete without an async runtime.
pub fn block_on<F: Future>(fut: F) -> F::Output {
    use std::task::{Context, Poll, Wake, Waker};
    struct ThreadWaker(std::thread::Thread);
    impl Wake for ThreadWaker {
        fn wake(self: Arc<Self>) {
            self.0.unpark();
        }
    }
    let waker = Waker::from(Arc::new(ThreadWaker(std::thread::current())));
    let mut cx = Context::from_waker(&waker);
    let mut fut = Box::pin(fut);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => std::thread::park(),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BackendPref {
    Auto,
    Vulkan,
    Gles,
}

impl BackendPref {
    pub fn parse(s: &str) -> BackendPref {
        match s {
            "vulkan" => BackendPref::Vulkan,
            "gles" | "gl" => BackendPref::Gles,
            _ => BackendPref::Auto,
        }
    }

    pub fn id(&self) -> &'static str {
        match self {
            BackendPref::Auto => "auto",
            BackendPref::Vulkan => "vulkan",
            BackendPref::Gles => "gles",
        }
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct AdapterSummary {
    pub name: String,
    pub vendor_id: u32,
    pub vendor: String,
    pub device_id: u32,
    pub device_type: String,
    pub backend: String,
    pub driver: String,
    pub driver_info: String,
    pub is_software: bool,
}

pub fn vendor_name(id: u32) -> &'static str {
    match id {
        0x13B5 => "ARM (Mali)",
        0x5143 => "Qualcomm (Adreno)",
        0x1010 => "Imagination (PowerVR)",
        0x10DE => "NVIDIA",
        0x1002 => "AMD",
        0x8086 => "Intel",
        0x1AE0 => "Google (SwiftShader)",
        0x144D => "Samsung",
        0x19E5 => "Huawei",
        0 => "unknown",
        _ => "other",
    }
}

fn summarize(info: &wgpu::AdapterInfo) -> AdapterSummary {
    AdapterSummary {
        name: info.name.clone(),
        vendor_id: info.vendor,
        vendor: vendor_name(info.vendor).to_string(),
        device_id: info.device,
        device_type: format!("{:?}", info.device_type),
        backend: format!("{:?}", info.backend),
        driver: info.driver.clone(),
        driver_info: info.driver_info.clone(),
        is_software: info.device_type == wgpu::DeviceType::Cpu,
    }
}

/// Lists every adapter wgpu can see (all backends). Does not create a device.
pub fn enumerate_adapters() -> Vec<AdapterSummary> {
    let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::default());
    instance
        .enumerate_adapters(wgpu::Backends::all())
        .iter()
        .map(|a| summarize(&a.get_info()))
        .collect()
}

fn rank(i: &wgpu::AdapterInfo) -> u8 {
    match i.device_type {
        wgpu::DeviceType::DiscreteGpu => 0,
        wgpu::DeviceType::IntegratedGpu => 1,
        wgpu::DeviceType::VirtualGpu => 2,
        wgpu::DeviceType::Other => 3,
        _ => 4,
    }
}

pub struct GpuInner {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub info: AdapterSummary,
    pub limits: wgpu::Limits,
    /// True when GPU timestamp queries are supported and enabled.
    pub timestamps: bool,
    pub timestamp_period_ns: f32,
    pub init_ms: f64,
    _instance: wgpu::Instance,
}

/// Cheap-to-clone handle to a live GPU device.
#[derive(Clone)]
pub struct GpuContext {
    inner: Arc<GpuInner>,
}

impl std::ops::Deref for GpuContext {
    type Target = GpuInner;
    fn deref(&self) -> &GpuInner {
        &self.inner
    }
}

fn try_backend(backends: wgpu::Backends) -> Result<GpuInner, String> {
    let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
        backends,
        ..Default::default()
    });
    let mut adapters: Vec<wgpu::Adapter> = instance.enumerate_adapters(backends);
    if adapters.is_empty() {
        return Err("no adapter found".to_string());
    }
    adapters.sort_by_key(|a| rank(&a.get_info()));
    let adapter = adapters.remove(0);
    let info = adapter.get_info();
    let downlevel = adapter.get_downlevel_capabilities();
    if !downlevel.flags.contains(wgpu::DownlevelFlags::COMPUTE_SHADERS) {
        return Err(format!("adapter '{}' does not support compute shaders", info.name));
    }
    let timestamps = adapter.features().contains(wgpu::Features::TIMESTAMP_QUERY);
    let mut required = wgpu::Features::empty();
    if timestamps {
        required |= wgpu::Features::TIMESTAMP_QUERY;
    }
    let limits = adapter.limits();
    let desc = wgpu::DeviceDescriptor {
        label: Some("graphics-lab"),
        required_features: required,
        required_limits: limits.clone(),
        memory_hints: wgpu::MemoryHints::Performance,
    };
    let (device, queue) = block_on(adapter.request_device(&desc, None))
        .map_err(|e| format!("request_device failed: {}", e))?;
    device.on_uncaptured_error(Box::new(|e| {
        lab_core::lab_warn!("wgpu error: {}", e);
    }));
    let period = queue.get_timestamp_period();
    Ok(GpuInner {
        device,
        queue,
        info: summarize(&info),
        limits,
        timestamps,
        timestamp_period_ns: period,
        init_ms: 0.0,
        _instance: instance,
    })
}

impl GpuContext {
    /// Creates a device on the preferred backend. Auto tries Vulkan, then OpenGL ES.
    /// A backend only counts as working if a real compute self-test runs on it.
    pub fn new(pref: BackendPref) -> Result<GpuContext, String> {
        let t0 = Instant::now();
        let order: Vec<wgpu::Backends> = match pref {
            BackendPref::Auto => vec![wgpu::Backends::VULKAN, wgpu::Backends::GL],
            BackendPref::Vulkan => vec![wgpu::Backends::VULKAN],
            BackendPref::Gles => vec![wgpu::Backends::GL],
        };
        let mut errors: Vec<String> = Vec::new();
        for b in order {
            match try_backend(b) {
                Ok(mut inner) => {
                    inner.init_ms = ms_since(t0);
                    let ctx = GpuContext { inner: Arc::new(inner) };
                    match self_test(&ctx) {
                        Ok(()) => return Ok(ctx),
                        Err(e) => errors.push(format!("{:?} self-test failed: {}", b, e)),
                    }
                }
                Err(e) => errors.push(format!("{:?}: {}", b, e)),
            }
        }
        Err(errors.join(" | "))
    }
}

fn align4(v: u64) -> u64 {
    (v + 3) / 4 * 4
}

impl GpuInner {
    /// Largest storage buffer this device accepts.
    pub fn max_storage_bytes(&self) -> u64 {
        (self.limits.max_storage_buffer_binding_size as u64).min(self.limits.max_buffer_size)
    }

    pub fn check_storage(&self, bytes: u64) -> Result<(), String> {
        if bytes > self.max_storage_bytes() {
            Err(format!(
                "buffer of {} MiB exceeds the device limit of {} MiB",
                bytes >> 20,
                self.max_storage_bytes() >> 20
            ))
        } else {
            Ok(())
        }
    }

    pub fn create_storage_buffer(&self, label: &str, size: u64) -> wgpu::Buffer {
        self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(label),
            size: align4(size).max(16),
            usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::COPY_SRC,
            mapped_at_creation: false,
        })
    }

    pub fn create_uniform_buffer(&self, label: &str, size: u64) -> wgpu::Buffer {
        self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(label),
            size: align4(size).max(16),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        })
    }

    /// Host-readable staging buffer large enough for `max_bytes` of results plus timestamps.
    pub fn create_staging_buffer(&self, label: &str, max_bytes: u64) -> Arc<wgpu::Buffer> {
        let size = (max_bytes + 15) / 16 * 16 + 16;
        Arc::new(self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(label),
            size,
            usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        }))
    }

    pub fn upload(&self, buf: &wgpu::Buffer, offset: u64, data: &[u8]) {
        self.queue.write_buffer(buf, offset, data);
    }

    /// Submits pending uploads and waits until the GPU has consumed them.
    pub fn flush(&self) {
        self.queue.submit(std::iter::empty::<wgpu::CommandBuffer>());
        let _ = self.device.poll(wgpu::Maintain::Wait);
    }

    pub fn build_kernel(&self, label: &str, wgsl: &str, entry: &str, binds: &[BindKind]) -> Result<Kernel, String> {
        self.device.push_error_scope(wgpu::ErrorFilter::Validation);
        let entries: Vec<wgpu::BindGroupLayoutEntry> = binds
            .iter()
            .enumerate()
            .map(|(i, k)| {
                let ty = match k {
                    BindKind::StorageRead => wgpu::BufferBindingType::Storage { read_only: true },
                    BindKind::StorageRw => wgpu::BufferBindingType::Storage { read_only: false },
                    BindKind::Uniform => wgpu::BufferBindingType::Uniform,
                };
                wgpu::BindGroupLayoutEntry {
                    binding: i as u32,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                }
            })
            .collect();
        let layout = self.device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some(label),
            entries: &entries,
        });
        let pipeline_layout = self.device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some(label),
            bind_group_layouts: &[&layout],
            push_constant_ranges: &[],
        });
        let module = self.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some(label),
            source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl)),
        });
        let pipeline = self.device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
            label: Some(label),
            layout: Some(&pipeline_layout),
            module: &module,
            entry_point: entry.into(),
            compilation_options: wgpu::PipelineCompilationOptions::default(),
            cache: None,
        });
        if let Some(err) = block_on(self.device.pop_error_scope()) {
            return Err(format!("kernel '{}' failed to build: {}", label, err));
        }
        Ok(Kernel {
            pipeline,
            layout,
            name: label.to_string(),
        })
    }

    /// Binds buffers to binding slots 0..n in order.
    pub fn bind(&self, kernel: &Kernel, buffers: &[&wgpu::Buffer]) -> wgpu::BindGroup {
        let entries: Vec<wgpu::BindGroupEntry> = buffers
            .iter()
            .enumerate()
            .map(|(i, b)| wgpu::BindGroupEntry {
                binding: i as u32,
                resource: b.as_entire_binding(),
            })
            .collect();
        self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("lab-bind"),
            layout: &kernel.layout,
            entries: &entries,
        })
    }
}

/// Runs a tiny kernel and verifies its output; proves the backend really computes.
fn self_test(ctx: &GpuContext) -> Result<(), String> {
    use crate::job::{submit_range, RangeJob};
    let k = ctx.build_kernel(
        "selftest",
        crate::kernels::SELFTEST,
        "main",
        &[BindKind::StorageRead, BindKind::StorageRw],
    )?;
    let n = 1024usize;
    let input: Vec<f32> = (0..n).map(|i| i as f32 * 0.5).collect();
    let inb = ctx.create_storage_buffer("st-in", (n * 4) as u64);
    let outb = ctx.create_storage_buffer("st-out", (n * 4) as u64);
    let staging = ctx.create_staging_buffer("st-staging", (n * 4) as u64);
    ctx.upload(&inb, 0, lab_core::util::as_bytes_f32(&input));
    let bind = ctx.bind(&k, &[&inb, &outb]);
    let pending = submit_range(
        ctx,
        RangeJob {
            kernel: &k,
            bind_group: &bind,
            groups: ((n as u32 + 63) / 64, 1, 1),
            params: None,
            out: &outb,
            staging: staging.clone(),
            read_bytes: (n * 4) as u64,
        },
    )?;
    let (bytes, _timing) = pending.wait()?;
    let mut got = vec![0f32; n];
    lab_core::util::bytes_into_f32(&bytes, &mut got);
    for i in 0..n {
        let expect = input[i] * 2.0 + 1.0;
        if (got[i] - expect).abs() > 1e-4 {
            return Err(format!("wrong result at {}: got {} expected {}", i, got[i], expect));
        }
    }
    Ok(())
}
