//! Turns raw probe results into display-ready sections for the Graphics Drivers screens.
use gpu_engine::AdapterSummary;
use lab_core::util::{row, section, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

use crate::gles::{self, GlesReport};
use crate::vulkan::{self, VulkanReport};

pub struct ProbeBundle {
    pub vulkan: VulkanReport,
    pub gles: GlesReport,
    pub adapters: Vec<AdapterSummary>,
}

/// Runs every probe. Each probe uses its own thread so graphics state of the caller is untouched.
pub fn probe_all() -> ProbeBundle {
    let vulkan = std::thread::spawn(vulkan::probe).join().unwrap_or_default();
    let gles = gles::probe();
    let adapters = std::thread::spawn(gpu_engine::enumerate_adapters)
        .join()
        .unwrap_or_default();
    ProbeBundle { vulkan, gles, adapters }
}

fn strings(v: &Value, key: &str) -> Vec<String> {
    v.get(key)
        .and_then(|x| x.as_array())
        .map(|a| a.iter().filter_map(|e| e.as_str().map(|s| s.to_string())).collect())
        .unwrap_or_default()
}

fn yes_no(b: bool) -> &'static str {
    if b {
        "yes"
    } else {
        "no"
    }
}

/// Sections for the GPU part of "Device Information" and the top of "Graphics Drivers".
pub fn gpu_sections(
    b: &ProbeBundle,
    active: Option<&AdapterSummary>,
    active_error: Option<&str>,
    init_ms: Option<f64>,
) -> Vec<Value> {
    let mut out = Vec::new();

    // ---- active compute backend
    let mut rows = Vec::new();
    match active {
        Some(a) => {
            rows.push(row("Compute backend in use", a.backend.clone(), MEASURED));
            rows.push(row("GPU", a.name.clone(), MEASURED));
            rows.push(row("Manufacturer", format!("{} (0x{:04X})", a.vendor, a.vendor_id), MEASURED));
            rows.push(row(
                "Processor type",
                if a.is_software { "CPU software rendering" } else { "Hardware GPU" },
                MEASURED,
            ));
            rows.push(row("Adapter class", a.device_type.clone(), MEASURED));
            if !a.driver.is_empty() || !a.driver_info.is_empty() {
                rows.push(row("Driver", format!("{} {}", a.driver, a.driver_info).trim().to_string(), MEASURED));
            } else {
                rows.push(row("Driver", "name not reported by the driver", UNAVAILABLE));
            }
            if let Some(ms) = init_ms {
                rows.push(row("Initialization time", format!("{:.0} ms", ms), MEASURED));
            }
            rows.push(row("Verified by a real compute kernel", "yes", MEASURED));
        }
        None => {
            rows.push(row("Compute backend in use", "none", UNAVAILABLE));
            rows.push(row(
                "Reason",
                active_error.unwrap_or("GPU not initialised yet").to_string(),
                UNAVAILABLE,
            ));
        }
    }
    out.push(section("Active GPU compute backend", rows));

    // ---- hardware acceleration summary
    let vk_hw = b.vulkan.devices.iter().any(|d| d.device_type != "CPU");
    let vk_sw = b.vulkan.devices.iter().any(|d| d.device_type == "CPU");
    let gl_hw = b.gles.available && !b.gles.is_software;
    let mut s = Vec::new();
    s.push(row("Vulkan hardware GPU", yes_no(vk_hw), MEASURED));
    s.push(row("Vulkan CPU software device", yes_no(vk_sw), MEASURED));
    s.push(row(
        "OpenGL ES hardware rendering",
        if b.gles.available { yes_no(gl_hw) } else { "unavailable" },
        if b.gles.available { MEASURED } else { UNAVAILABLE },
    ));
    s.push(row(
        "Vulkan compute queue",
        yes_no(b.vulkan.devices.iter().any(|d| d.has_compute_queue)),
        MEASURED,
    ));
    s.push(row(
        "OpenGL ES compute (3.1+)",
        yes_no(b.gles.max_compute_invocations.is_some()),
        if b.gles.available { MEASURED } else { UNAVAILABLE },
    ));
    out.push(section("Hardware acceleration status", s));

    out.extend(vulkan::sections(&b.vulkan));
    out.extend(gles::sections(&b.gles));

    // ---- wgpu adapters
    let table_rows: Vec<Value> = b
        .adapters
        .iter()
        .map(|a| json!([a.backend, a.name, a.device_type, format!("{} {}", a.driver, a.driver_info).trim()]))
        .collect();
    let mut sec = json!({ "title": "Adapters visible to the compute engine (wgpu)" });
    if table_rows.is_empty() {
        sec["note"] = json!("No adapter was reported.");
    } else {
        sec["table"] = json!({ "columns": ["Backend", "Adapter", "Type", "Driver"], "rows": table_rows });
    }
    out.push(sec);
    out
}

/// Sections for the Graphics Drivers screen: options, status and how to change them.
pub fn driver_sections(
    b: &ProbeBundle,
    st: &Value,
    pref: &str,
    active: Option<&AdapterSummary>,
) -> Vec<Value> {
    let mut out = Vec::new();

    let mut app = Vec::new();
    app.push(row("Backend preference of this app", pref, MEASURED));
    match active {
        Some(a) => app.push(row("Active compute backend", format!("{} on {}", a.backend, a.name), MEASURED)),
        None => app.push(row("Active compute backend", "none (not initialised or failed)", UNAVAILABLE)),
    }
    let mut sec = section("This app", app);
    sec["note"] = json!(
        "Selecting a backend below creates a new GPU device and runs a real compute kernel on it. \
         The label only changes if that initialization succeeds."
    );
    out.push(sec);

    // ---- driver options
    let mut rows = Vec::new();
    let vk_loaded = b.vulkan.available;
    rows.push(row(
        "System graphics driver",
        format!(
            "always present; Vulkan {}; OpenGL ES {}",
            if vk_loaded { "loaded" } else { "not available" },
            if b.gles.available { b.gles.gl_renderer.clone() } else { "not available".to_string() }
        ),
        MEASURED,
    ));
    let angle_pkgs = strings(st, "angle_packages");
    if b.gles.is_angle {
        rows.push(row("ANGLE", "in use by this app's OpenGL ES context", MEASURED));
    } else if !angle_pkgs.is_empty() {
        rows.push(row("ANGLE", format!("installed: {} (not used by this app now)", angle_pkgs.join(", ")), MEASURED));
    } else {
        rows.push(row("ANGLE", "no ANGLE package visible to this app", UNAVAILABLE));
    }
    let drv_pkgs = strings(st, "driver_packages");
    if drv_pkgs.is_empty() {
        rows.push(row("Updated / game driver packages", "none visible to this app", UNAVAILABLE));
    } else {
        rows.push(row("Updated / game driver packages", drv_pkgs.join(", "), MEASURED));
    }
    let dev = st.get("dev_options").and_then(|v| v.as_bool());
    match dev {
        Some(v) => rows.push(row("Developer options enabled", yes_no(v), MEASURED)),
        None => rows.push(row("Developer options enabled", "unknown", UNAVAILABLE)),
    }
    if let Some(obj) = st.get("settings").and_then(|x| x.as_object()) {
        let mut any = false;
        for (k, v) in obj {
            if let Some(s) = v.as_str() {
                if !s.is_empty() {
                    rows.push(row(&format!("Setting {}", k), s.to_string(), MEASURED));
                    any = true;
                }
            }
        }
        if !any {
            rows.push(row("Per-app driver settings", "none set (system default is used)", MEASURED));
        }
    }
    let mut sec = section("Graphics driver options on this device", rows);
    sec["note"] = json!(
        "Package visibility rules on Android 11+ can hide installed packages from apps, \
         so 'none visible' is not proof that a driver is absent."
    );
    out.push(sec);

    // ---- instructions
    let steps = vec![
        "Open Settings > System > Developer options (enable it first by tapping Build number 7 times in About phone).",
        "Look for 'Graphics Driver Preferences' (Android 10+) or 'Updatable GPU driver' entries. Many budget Unisoc/MediaTek firmwares do not include them.",
        "If present, select 'Graphics Lab' and choose Default, Game Driver, Prerelease driver or System graphics driver. On devices with ANGLE you may also see an ANGLE option.",
        "Force-stop and reopen this app, then use 'Verify backend' here: the active backend and driver shown above come from a real device initialization.",
        "To restore the default: set the app back to 'Default' in the same Developer options screen, and press 'Reset to Auto' in this app.",
    ];
    let mut sec = json!({ "title": "How to select a driver for this app" });
    sec["items_title"] = json!("Steps");
    sec["items"] = json!(steps);
    sec["note"] = json!(
        "Android does not let an app replace the system graphics driver, and this app does not try. \
         It never needs root, Shizuku or a PC: it can only switch its own backend (Vulkan or OpenGL ES) \
         and report what the system driver options are."
    );
    out.push(sec);
    out
}
