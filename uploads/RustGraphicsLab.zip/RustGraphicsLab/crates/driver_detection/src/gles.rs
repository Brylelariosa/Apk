//! OpenGL ES probing through a real EGL pbuffer context (Android only).
//! Runs on a fresh thread so it can never disturb a context that another thread has current.
use lab_core::util::{row, section, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

#[derive(Clone, Debug, Default)]
pub struct GlesReport {
    pub available: bool,
    pub error: Option<String>,
    pub egl_version: String,
    pub egl_vendor: String,
    pub gl_vendor: String,
    pub gl_renderer: String,
    pub gl_version: String,
    pub glsl_version: String,
    pub major: i32,
    pub minor: i32,
    pub extensions: Vec<String>,
    pub max_texture_size: i32,
    pub max_renderbuffer_size: i32,
    pub max_vertex_attribs: i32,
    pub max_texture_units: i32,
    pub max_compute_invocations: Option<i32>,
    pub max_compute_shared_mem: Option<i32>,
    pub is_angle: bool,
    pub is_software: bool,
}

pub fn probe() -> GlesReport {
    match std::thread::Builder::new()
        .name("gles-probe".to_string())
        .spawn(imp::probe_blocking)
    {
        Ok(h) => h.join().unwrap_or_else(|_| GlesReport {
            error: Some("OpenGL ES probe thread crashed".to_string()),
            ..Default::default()
        }),
        Err(e) => GlesReport {
            error: Some(format!("cannot start probe thread: {}", e)),
            ..Default::default()
        },
    }
}

#[cfg(target_os = "android")]
mod imp {
    use super::GlesReport;
    use std::ffi::CStr;
    use std::os::raw::{c_char, c_void};
    use std::ptr::null_mut;

    const EGL_VENDOR: i32 = 0x3053;
    const EGL_VERSION: i32 = 0x3054;
    const EGL_SURFACE_TYPE: i32 = 0x3033;
    const EGL_PBUFFER_BIT: i32 = 0x0001;
    const EGL_RENDERABLE_TYPE: i32 = 0x3040;
    const EGL_OPENGL_ES2_BIT: i32 = 0x0004;
    const EGL_OPENGL_ES3_BIT: i32 = 0x0040;
    const EGL_RED_SIZE: i32 = 0x3024;
    const EGL_GREEN_SIZE: i32 = 0x3023;
    const EGL_BLUE_SIZE: i32 = 0x3022;
    const EGL_NONE: i32 = 0x3038;
    const EGL_WIDTH: i32 = 0x3057;
    const EGL_HEIGHT: i32 = 0x3056;
    const EGL_CONTEXT_CLIENT_VERSION: i32 = 0x3098;
    const EGL_OPENGL_ES_API: u32 = 0x30A0;

    const GL_VENDOR: u32 = 0x1F00;
    const GL_RENDERER: u32 = 0x1F01;
    const GL_VERSION: u32 = 0x1F02;
    const GL_EXTENSIONS: u32 = 0x1F03;
    const GL_SHADING_LANGUAGE_VERSION: u32 = 0x8B8C;
    const GL_MAX_TEXTURE_SIZE: u32 = 0x0D33;
    const GL_MAX_VERTEX_ATTRIBS: u32 = 0x8869;
    const GL_MAX_TEXTURE_IMAGE_UNITS: u32 = 0x8872;
    const GL_MAX_RENDERBUFFER_SIZE: u32 = 0x84E8;
    const GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS: u32 = 0x90EB;
    const GL_MAX_COMPUTE_SHARED_MEMORY_SIZE: u32 = 0x8262;

    #[link(name = "EGL")]
    extern "C" {
        fn eglGetDisplay(display_id: *mut c_void) -> *mut c_void;
        fn eglInitialize(dpy: *mut c_void, major: *mut i32, minor: *mut i32) -> u32;
        fn eglBindAPI(api: u32) -> u32;
        fn eglChooseConfig(
            dpy: *mut c_void,
            attrib_list: *const i32,
            configs: *mut *mut c_void,
            config_size: i32,
            num_config: *mut i32,
        ) -> u32;
        fn eglCreateContext(
            dpy: *mut c_void,
            config: *mut c_void,
            share_context: *mut c_void,
            attrib_list: *const i32,
        ) -> *mut c_void;
        fn eglCreatePbufferSurface(dpy: *mut c_void, config: *mut c_void, attrib_list: *const i32) -> *mut c_void;
        fn eglMakeCurrent(dpy: *mut c_void, draw: *mut c_void, read: *mut c_void, ctx: *mut c_void) -> u32;
        fn eglDestroyContext(dpy: *mut c_void, ctx: *mut c_void) -> u32;
        fn eglDestroySurface(dpy: *mut c_void, surface: *mut c_void) -> u32;
        fn eglQueryString(dpy: *mut c_void, name: i32) -> *const c_char;
        fn eglGetError() -> i32;
    }

    #[link(name = "GLESv3")]
    extern "C" {
        fn glGetString(name: u32) -> *const u8;
        fn glGetIntegerv(pname: u32, data: *mut i32);
        fn glGetError() -> u32;
    }

    unsafe fn cstr(p: *const c_char) -> String {
        if p.is_null() {
            String::new()
        } else {
            CStr::from_ptr(p).to_string_lossy().into_owned()
        }
    }

    unsafe fn gl_string(name: u32) -> String {
        cstr(glGetString(name) as *const c_char)
    }

    unsafe fn gl_int(pname: u32) -> Option<i32> {
        let mut v: i32 = 0;
        glGetIntegerv(pname, &mut v);
        if glGetError() != 0 {
            None
        } else {
            Some(v)
        }
    }

    fn parse_es_version(s: &str) -> (i32, i32) {
        // "OpenGL ES 3.2 vendor-string"
        let rest = s.split("OpenGL ES").nth(1).unwrap_or("").trim_start();
        let ver: String = rest.chars().take_while(|c| c.is_ascii_digit() || *c == '.').collect();
        let mut it = ver.split('.');
        let major = it.next().and_then(|x| x.parse::<i32>().ok()).unwrap_or(0);
        let minor = it.next().and_then(|x| x.parse::<i32>().ok()).unwrap_or(0);
        (major, minor)
    }

    pub fn probe_blocking() -> GlesReport {
        unsafe { probe_unsafe() }
    }

    unsafe fn probe_unsafe() -> GlesReport {
        let mut r = GlesReport::default();
        let dpy = eglGetDisplay(null_mut());
        if dpy.is_null() {
            r.error = Some("eglGetDisplay returned no display".to_string());
            return r;
        }
        let (mut maj, mut min) = (0i32, 0i32);
        if eglInitialize(dpy, &mut maj, &mut min) == 0 {
            r.error = Some(format!("eglInitialize failed (error 0x{:x})", eglGetError()));
            return r;
        }
        r.egl_version = cstr(eglQueryString(dpy, EGL_VERSION));
        r.egl_vendor = cstr(eglQueryString(dpy, EGL_VENDOR));
        eglBindAPI(EGL_OPENGL_ES_API);

        let mut cfg: *mut c_void = null_mut();
        let mut n: i32 = 0;
        let mut es3 = true;
        let attribs3 = [
            EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
            EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_NONE,
        ];
        if eglChooseConfig(dpy, attribs3.as_ptr(), &mut cfg, 1, &mut n) == 0 || n < 1 {
            es3 = false;
            let attribs2 = [
                EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_NONE,
            ];
            n = 0;
            if eglChooseConfig(dpy, attribs2.as_ptr(), &mut cfg, 1, &mut n) == 0 || n < 1 {
                r.error = Some("no EGL config supports OpenGL ES".to_string());
                return r;
            }
        }
        let ctx_attribs = [EGL_CONTEXT_CLIENT_VERSION, if es3 { 3 } else { 2 }, EGL_NONE];
        let ctx = eglCreateContext(dpy, cfg, null_mut(), ctx_attribs.as_ptr());
        if ctx.is_null() {
            r.error = Some(format!("eglCreateContext failed (error 0x{:x})", eglGetError()));
            return r;
        }
        let pb = [EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE];
        let surf = eglCreatePbufferSurface(dpy, cfg, pb.as_ptr());
        if surf.is_null() || eglMakeCurrent(dpy, surf, surf, ctx) == 0 {
            r.error = Some(format!("cannot make the EGL context current (error 0x{:x})", eglGetError()));
            if !surf.is_null() {
                eglDestroySurface(dpy, surf);
            }
            eglDestroyContext(dpy, ctx);
            return r;
        }
        r.gl_vendor = gl_string(GL_VENDOR);
        r.gl_renderer = gl_string(GL_RENDERER);
        r.gl_version = gl_string(GL_VERSION);
        r.glsl_version = gl_string(GL_SHADING_LANGUAGE_VERSION);
        let (major, minor) = parse_es_version(&r.gl_version);
        r.major = major;
        r.minor = minor;
        r.extensions = gl_string(GL_EXTENSIONS).split_whitespace().map(|s| s.to_string()).collect();
        r.max_texture_size = gl_int(GL_MAX_TEXTURE_SIZE).unwrap_or(0);
        r.max_renderbuffer_size = gl_int(GL_MAX_RENDERBUFFER_SIZE).unwrap_or(0);
        r.max_vertex_attribs = gl_int(GL_MAX_VERTEX_ATTRIBS).unwrap_or(0);
        r.max_texture_units = gl_int(GL_MAX_TEXTURE_IMAGE_UNITS).unwrap_or(0);
        if major > 3 || (major == 3 && minor >= 1) {
            r.max_compute_invocations = gl_int(GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS);
            r.max_compute_shared_mem = gl_int(GL_MAX_COMPUTE_SHARED_MEMORY_SIZE);
        }
        let lower = r.gl_renderer.to_lowercase();
        r.is_angle = lower.contains("angle");
        r.is_software = lower.contains("llvmpipe") || lower.contains("swiftshader") || lower.contains("softpipe") || lower.contains("software");
        r.available = true;
        eglMakeCurrent(dpy, null_mut(), null_mut(), null_mut());
        eglDestroySurface(dpy, surf);
        eglDestroyContext(dpy, ctx);
        r
    }
}

#[cfg(not(target_os = "android"))]
mod imp {
    use super::GlesReport;

    pub fn probe_blocking() -> GlesReport {
        GlesReport {
            error: Some("OpenGL ES probing is only available on Android".to_string()),
            ..Default::default()
        }
    }
}

pub fn sections(r: &GlesReport) -> Vec<Value> {
    let mut rows = Vec::new();
    rows.push(row("OpenGL ES available", if r.available { "yes" } else { "no" }, MEASURED));
    if let Some(e) = &r.error {
        rows.push(row("Detail", e.clone(), UNAVAILABLE));
    }
    if r.available {
        rows.push(row("OpenGL ES version", r.gl_version.clone(), MEASURED));
        rows.push(row("GLSL ES version", r.glsl_version.clone(), MEASURED));
        rows.push(row("Renderer", r.gl_renderer.clone(), MEASURED));
        rows.push(row("Vendor", r.gl_vendor.clone(), MEASURED));
        rows.push(row("EGL", format!("{} ({})", r.egl_version, r.egl_vendor), MEASURED));
        rows.push(row(
            "Rendering path",
            if r.is_software {
                "CPU software rendering"
            } else if r.is_angle {
                "ANGLE (OpenGL ES translated to Vulkan)"
            } else {
                "Hardware GPU through the system driver"
            },
            MEASURED,
        ));
        rows.push(row("Max texture size", r.max_texture_size, MEASURED));
        rows.push(row("Max renderbuffer size", r.max_renderbuffer_size, MEASURED));
        rows.push(row("Max vertex attributes", r.max_vertex_attribs, MEASURED));
        rows.push(row("Max texture image units", r.max_texture_units, MEASURED));
        match r.max_compute_invocations {
            Some(v) => rows.push(row("Compute shaders (ES 3.1+)", format!("yes, {} invocations/workgroup", v), MEASURED)),
            None => rows.push(row("Compute shaders (ES 3.1+)", "not available on this context", UNAVAILABLE)),
        }
        if let Some(v) = r.max_compute_shared_mem {
            rows.push(row("Max compute shared memory", v, MEASURED));
        }
        rows.push(row("Extensions", r.extensions.len(), MEASURED));
    }
    let mut sec = section("OpenGL ES", rows);
    if !r.extensions.is_empty() {
        sec["items_title"] = json!("OpenGL ES extensions");
        sec["items"] = json!(r.extensions);
    }
    vec![sec]
}
