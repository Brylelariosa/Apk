//! Graphics driver and hardware detection: Vulkan (ash), OpenGL ES (EGL), wgpu adapters and
//! the Android driver-selection options. Nothing here is assumed: every value is read from the
//! device or reported as unavailable.
pub mod gles;
pub mod report;
pub mod vulkan;

pub use report::{driver_sections, gpu_sections, probe_all, ProbeBundle};
