//! Direct Vulkan probing with ash: instance/device properties, extensions, limits, memory heaps.
use ash::{vk, Entry};
use gpu_engine::vendor_name;
use lab_core::util::{human_bytes, row, section, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

#[derive(Clone, Debug, Default)]
pub struct VulkanDevice {
    pub name: String,
    pub device_type: String,
    pub vendor_id: u32,
    pub device_id: u32,
    pub api_version: String,
    pub driver_version_raw: u32,
    pub has_compute_queue: bool,
    pub max_compute_invocations: u32,
    pub max_compute_workgroup_size: [u32; 3],
    pub max_compute_shared_mem: u32,
    pub max_storage_buffer_range: u32,
    pub max_image_dim_2d: u32,
    pub timestamp_period_ns: f32,
    pub timestamps_supported: bool,
    pub extensions: Vec<String>,
    /// (size in bytes, device local)
    pub heaps: Vec<(u64, bool)>,
    /// Selected feature names that the device reports as enabled.
    pub features: Vec<String>,
}

#[derive(Clone, Debug, Default)]
pub struct VulkanReport {
    pub available: bool,
    pub error: Option<String>,
    pub instance_version: String,
    pub instance_extensions: Vec<String>,
    pub devices: Vec<VulkanDevice>,
}

fn c_str(raw: &[std::os::raw::c_char]) -> String {
    let bytes: Vec<u8> = raw.iter().take_while(|&&c| c != 0).map(|&c| c as u8).collect();
    String::from_utf8_lossy(&bytes).to_string()
}

fn version_string(v: u32) -> String {
    format!(
        "{}.{}.{}",
        vk::api_version_major(v),
        vk::api_version_minor(v),
        vk::api_version_patch(v)
    )
}

pub fn probe() -> VulkanReport {
    let entry = match unsafe { Entry::load() } {
        Ok(e) => e,
        Err(e) => {
            return VulkanReport {
                available: false,
                error: Some(format!("Vulkan loader (libvulkan.so) could not be loaded: {}", e)),
                ..Default::default()
            }
        }
    };
    let inst_ver = match unsafe { entry.try_enumerate_instance_version() } {
        Ok(Some(v)) => v,
        _ => vk::API_VERSION_1_0,
    };
    let instance_extensions: Vec<String> = unsafe { entry.enumerate_instance_extension_properties(None) }
        .unwrap_or_default()
        .iter()
        .map(|e| c_str(&e.extension_name))
        .collect();
    let app_info = vk::ApplicationInfo::default().api_version(vk::API_VERSION_1_0);
    let create_info = vk::InstanceCreateInfo::default().application_info(&app_info);
    let instance = match unsafe { entry.create_instance(&create_info, None) } {
        Ok(i) => i,
        Err(e) => {
            return VulkanReport {
                available: false,
                error: Some(format!("vkCreateInstance failed: {:?}", e)),
                instance_version: version_string(inst_ver),
                instance_extensions,
                devices: Vec::new(),
            }
        }
    };
    let physical = unsafe { instance.enumerate_physical_devices() }.unwrap_or_default();
    let mut devices = Vec::new();
    for pd in physical {
        let props = unsafe { instance.get_physical_device_properties(pd) };
        let feats = unsafe { instance.get_physical_device_features(pd) };
        let mem = unsafe { instance.get_physical_device_memory_properties(pd) };
        let exts: Vec<String> = unsafe { instance.enumerate_device_extension_properties(pd) }
            .unwrap_or_default()
            .iter()
            .map(|e| c_str(&e.extension_name))
            .collect();
        let queues = unsafe { instance.get_physical_device_queue_family_properties(pd) };
        let has_compute = queues.iter().any(|q| q.queue_flags.contains(vk::QueueFlags::COMPUTE));
        let mut heaps = Vec::new();
        for i in 0..(mem.memory_heap_count as usize).min(16) {
            let h = mem.memory_heaps[i];
            heaps.push((h.size, h.flags.contains(vk::MemoryHeapFlags::DEVICE_LOCAL)));
        }
        let flag_list: Vec<(&str, vk::Bool32)> = vec![
            ("shaderFloat64", feats.shader_float64),
            ("shaderInt64", feats.shader_int64),
            ("shaderInt16", feats.shader_int16),
            ("geometryShader", feats.geometry_shader),
            ("tessellationShader", feats.tessellation_shader),
            ("samplerAnisotropy", feats.sampler_anisotropy),
            ("textureCompressionETC2", feats.texture_compression_etc2),
            ("textureCompressionASTC_LDR", feats.texture_compression_astc_ldr),
            ("fragmentStoresAndAtomics", feats.fragment_stores_and_atomics),
            ("multiDrawIndirect", feats.multi_draw_indirect),
            ("depthClamp", feats.depth_clamp),
            ("independentBlend", feats.independent_blend),
        ];
        let features: Vec<String> = flag_list
            .iter()
            .filter(|(_, v)| *v != 0)
            .map(|(n, _)| n.to_string())
            .collect();
        devices.push(VulkanDevice {
            name: c_str(&props.device_name),
            device_type: format!("{:?}", props.device_type),
            vendor_id: props.vendor_id,
            device_id: props.device_id,
            api_version: version_string(props.api_version),
            driver_version_raw: props.driver_version,
            has_compute_queue: has_compute,
            max_compute_invocations: props.limits.max_compute_work_group_invocations,
            max_compute_workgroup_size: props.limits.max_compute_work_group_size,
            max_compute_shared_mem: props.limits.max_compute_shared_memory_size,
            max_storage_buffer_range: props.limits.max_storage_buffer_range,
            max_image_dim_2d: props.limits.max_image_dimension2_d,
            timestamp_period_ns: props.limits.timestamp_period,
            timestamps_supported: props.limits.timestamp_compute_and_graphics != 0,
            extensions: exts,
            heaps,
            features,
        });
    }
    unsafe {
        instance.destroy_instance(None);
    }
    VulkanReport {
        available: !devices.is_empty(),
        error: if devices.is_empty() { Some("Vulkan loaded but no physical device is exposed".to_string()) } else { None },
        instance_version: version_string(inst_ver),
        instance_extensions,
        devices,
    }
}

pub fn sections(r: &VulkanReport) -> Vec<Value> {
    let mut out = Vec::new();
    let mut head = Vec::new();
    head.push(row("Vulkan available", if r.available { "yes" } else { "no" }, MEASURED));
    if let Some(e) = &r.error {
        head.push(row("Detail", e.clone(), UNAVAILABLE));
    }
    if !r.instance_version.is_empty() {
        head.push(row("Loader / instance version", r.instance_version.clone(), MEASURED));
        head.push(row("Instance extensions", r.instance_extensions.len(), MEASURED));
    }
    let mut sec = section("Vulkan", head);
    if !r.instance_extensions.is_empty() {
        sec["items_title"] = json!("Instance extensions");
        sec["items"] = json!(r.instance_extensions);
    }
    out.push(sec);
    for (i, d) in r.devices.iter().enumerate() {
        let mut rows = Vec::new();
        rows.push(row("Name", d.name.clone(), MEASURED));
        rows.push(row("Type", d.device_type.clone(), MEASURED));
        rows.push(row(
            "Vendor",
            format!("0x{:04X} ({})", d.vendor_id, vendor_name(d.vendor_id)),
            MEASURED,
        ));
        rows.push(row("Device ID", format!("0x{:04X}", d.device_id), MEASURED));
        rows.push(row("Vulkan API version", d.api_version.clone(), MEASURED));
        rows.push(row(
            "Driver version (raw)",
            format!("0x{:08X} (vendor-specific encoding)", d.driver_version_raw),
            MEASURED,
        ));
        rows.push(row("Compute queue", if d.has_compute_queue { "yes" } else { "no" }, MEASURED));
        rows.push(row("Max compute invocations / workgroup", d.max_compute_invocations, MEASURED));
        rows.push(row(
            "Max compute workgroup size",
            format!(
                "{} x {} x {}",
                d.max_compute_workgroup_size[0], d.max_compute_workgroup_size[1], d.max_compute_workgroup_size[2]
            ),
            MEASURED,
        ));
        rows.push(row("Max shared memory / workgroup", human_bytes(d.max_compute_shared_mem as u64), MEASURED));
        rows.push(row("Max storage buffer range", human_bytes(d.max_storage_buffer_range as u64), MEASURED));
        rows.push(row("Max 2D texture dimension", d.max_image_dim_2d, MEASURED));
        rows.push(row(
            "GPU timestamps",
            if d.timestamps_supported {
                format!("supported ({:.1} ns per tick)", d.timestamp_period_ns)
            } else {
                "not supported".to_string()
            },
            MEASURED,
        ));
        for (hi, (size, local)) in d.heaps.iter().enumerate() {
            rows.push(row(
                &format!("Memory heap {}", hi),
                format!("{} ({})", human_bytes(*size), if *local { "device local" } else { "host" }),
                MEASURED,
            ));
        }
        rows.push(row("Device extensions", d.extensions.len(), MEASURED));
        if !d.features.is_empty() {
            rows.push(row("Enabled features", d.features.join(", "), MEASURED));
        }
        let mut sec = section(&format!("Vulkan device {}: {}", i, d.name), rows);
        if !d.extensions.is_empty() {
            sec["items_title"] = json!("Device extensions");
            sec["items"] = json!(d.extensions);
        }
        out.push(sec);
    }
    out
}
