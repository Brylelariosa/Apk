//! Automatic CPU/GPU balancing from measured execution times.
//!
//! Model: the CPU needs `x / r_cpu` ms for x units. The GPU needs a fixed overhead `o` (submit,
//! queue latency, synchronisation, readback) plus `y / r_gpu`. Both finish together when
//! `x / r_cpu = o + (N - x) / r_gpu`. The overhead term is why 50/50 is rarely optimal.
use crate::runner::RunObservation;

#[derive(Clone, Debug)]
pub struct Balancer {
    /// CPU throughput in units per millisecond (measured while running concurrently).
    pub r_cpu: f64,
    /// GPU throughput in units per millisecond, excluding the fixed overhead.
    pub r_gpu: f64,
    /// Fixed GPU-side cost per run in milliseconds.
    pub overhead_ms: f64,
    pub observations: usize,
    total: f64,
    granularity: usize,
}

fn ema(old: f64, new: f64, alpha: f64) -> f64 {
    if !new.is_finite() || new <= 0.0 {
        return old;
    }
    old * (1.0 - alpha) + new * alpha
}

impl Balancer {
    pub fn new(total: usize, granularity: usize) -> Balancer {
        Balancer {
            r_cpu: 1.0,
            r_gpu: 1.0,
            overhead_ms: 0.0,
            observations: 0,
            total: total.max(1) as f64,
            granularity: granularity.max(1),
        }
    }

    pub fn seed(&mut self, r_cpu: f64, r_gpu: f64, overhead_ms: f64) {
        if r_cpu.is_finite() && r_cpu > 0.0 {
            self.r_cpu = r_cpu;
        }
        if r_gpu.is_finite() && r_gpu > 0.0 {
            self.r_gpu = r_gpu;
        }
        if overhead_ms.is_finite() && overhead_ms >= 0.0 {
            self.overhead_ms = overhead_ms;
        }
    }

    /// CPU share (0..1) at which both processors are predicted to finish together.
    pub fn fraction(&self) -> f64 {
        let rc = self.r_cpu.max(1e-9);
        let rg = self.r_gpu.max(1e-9);
        let o = self.overhead_ms.max(0.0);
        let x = (o + self.total / rg) / (1.0 / rc + 1.0 / rg);
        (x / self.total).clamp(0.0, 1.0)
    }

    /// Same, but keeps at least one granule on each side so both processors stay measurable.
    pub fn hybrid_fraction(&self) -> f64 {
        let min = (self.granularity as f64 / self.total).max(0.02).min(0.45);
        self.fraction().clamp(min, 1.0 - min)
    }

    pub fn observe(&mut self, obs: &RunObservation) {
        const ALPHA: f64 = 0.4;
        if obs.cpu_units > 0 && obs.cpu_ms > 0.05 {
            self.r_cpu = ema(self.r_cpu, obs.cpu_units as f64 / obs.cpu_ms, ALPHA);
        }
        if obs.gpu_units > 0 {
            let t = obs.gpu_wall_ms + obs.gpu_readback_ms;
            let eff = (t - self.overhead_ms).max(0.1 * t).max(0.05);
            self.r_gpu = ema(self.r_gpu, obs.gpu_units as f64 / eff, ALPHA);
        }
        self.observations += 1;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn equal_processors_without_overhead_split_evenly() {
        let mut b = Balancer::new(1000, 8);
        b.seed(2.0, 2.0, 0.0);
        assert!((b.fraction() - 0.5).abs() < 1e-9);
    }

    #[test]
    fn faster_gpu_gets_more_work_and_overhead_shifts_work_to_cpu() {
        let mut b = Balancer::new(1000, 8);
        b.seed(1.0, 3.0, 0.0);
        let f0 = b.fraction();
        assert!(f0 < 0.5);
        b.seed(1.0, 3.0, 100.0);
        assert!(b.fraction() > f0);
    }

    #[test]
    fn hybrid_fraction_never_hits_the_extremes() {
        let mut b = Balancer::new(1000, 8);
        b.seed(1.0, 1000.0, 0.0);
        assert!(b.hybrid_fraction() >= 0.02);
        b.seed(1000.0, 1.0, 0.0);
        assert!(b.hybrid_fraction() <= 0.98);
    }
}
