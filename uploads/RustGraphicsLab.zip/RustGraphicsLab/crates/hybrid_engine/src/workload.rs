//! The workload abstraction shared by the CPU, GPU and hybrid runners.
//!
//! A workload is a pure function `output = f(input, range)` over contiguous "work units"
//! (matrix rows, particles, image rows, vector elements). Because inputs are immutable and
//! ranges are disjoint, the CPU and the GPU can compute different ranges of the same problem
//! at the same time and the results are simply merged into one output buffer.
use std::ops::Range;

use cpu_engine::CpuEngine;
use gpu_engine::{GpuContext, Pending};
use serde::{Deserialize, Serialize};

use crate::workloads;

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct WorkloadInfo {
    pub id: String,
    pub name: String,
    /// Total number of divisible work units.
    pub units: usize,
    pub unit_name: String,
    /// Partition boundaries are aligned to this many units (GPU tile size).
    pub granularity: usize,
    /// Floating point / integer operations for one full run.
    pub flops: f64,
    /// Bytes read + written by one full run (for bandwidth estimates).
    pub bytes: f64,
    pub params: String,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Validation {
    pub ok: bool,
    pub checked: usize,
    pub mismatches: usize,
    pub max_abs_err: f64,
    pub detail: String,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct GpuPrep {
    /// Shader/pipeline compilation time.
    pub build_ms: f64,
    /// One-time upload of the input data to GPU memory.
    pub upload_ms: f64,
    pub upload_bytes: u64,
    /// GPU memory allocated by this workload.
    pub gpu_buffer_bytes: u64,
}

pub trait Workload: Send {
    fn info(&self) -> WorkloadInfo;
    /// Computes `range` on the CPU (blocking, multithreaded) into the shared output.
    fn cpu_compute(&mut self, cpu: &CpuEngine, range: Range<usize>);
    /// Compiles kernels and uploads inputs once. Required before `gpu_submit`.
    fn gpu_prepare(&mut self, ctx: &GpuContext) -> Result<GpuPrep, String>;
    /// Encodes and submits `range` to the GPU and returns immediately.
    fn gpu_submit(&mut self, range: Range<usize>) -> Result<Pending, String>;
    /// Copies GPU results for `range` into the shared output.
    fn gpu_merge(&mut self, range: Range<usize>, bytes: &[u8]);
    /// Poisons the output so unwritten regions are detected by `validate`.
    fn clear_output(&mut self);
    /// Compares the shared output with an independent CPU reference.
    /// `boundary` is the CPU/GPU split point (checked with extra care).
    fn validate(&mut self, boundary: Option<usize>) -> Validation;
}

pub struct CatalogEntry {
    pub id: &'static str,
    pub name: &'static str,
    pub description: &'static str,
    pub scales: Vec<String>,
    pub default_scale: usize,
}

fn strs(v: &[&str]) -> Vec<String> {
    v.iter().map(|s| s.to_string()).collect()
}

pub fn catalog() -> Vec<CatalogEntry> {
    vec![
        CatalogEntry {
            id: "matmul",
            name: "Matrix multiplication",
            description: "Dense f32 C = A x B. Split by output rows: CPU computes some rows, GPU the rest.",
            scales: strs(&["256 x 256", "512 x 512", "768 x 768", "1024 x 1024"]),
            default_scale: 1,
        },
        CatalogEntry {
            id: "vector_fma",
            name: "Vector math (compute-bound)",
            description: "64 dependent fused multiply-adds per element. Split by element ranges.",
            scales: strs(&["1M elements", "2M elements", "4M elements", "8M elements"]),
            default_scale: 1,
        },
        CatalogEntry {
            id: "vector_bw",
            name: "Vector stream (memory-bound)",
            description: "One multiply-add per element: limited by memory bandwidth, not arithmetic.",
            scales: strs(&["1M elements", "2M elements", "4M elements", "8M elements"]),
            default_scale: 1,
        },
        CatalogEntry {
            id: "particles",
            name: "Particle simulation",
            description: "64 integration steps per particle toward a CPU-driven attractor. Split by particle groups.",
            scales: strs(&["50k particles", "100k particles", "200k particles", "400k particles"]),
            default_scale: 1,
        },
        CatalogEntry {
            id: "image",
            name: "Image processing",
            description: "3x3 Gaussian blur + contrast on RGBA8. Split by image regions (rows); results must match exactly.",
            scales: strs(&["512 x 512", "720 x 1600 (native)", "1080 x 2400", "1440 x 3200"]),
            default_scale: 1,
        },
    ]
}

pub fn create(id: &str, scale: usize) -> Result<Box<dyn Workload>, String> {
    let s = scale.min(3);
    match id {
        "matmul" => Ok(Box::new(workloads::matmul::MatMul::new([256usize, 512, 768, 1024][s]))),
        "vector_fma" => Ok(Box::new(workloads::vector::VectorOp::new(
            "vector_fma",
            [1usize << 20, 2 << 20, 4 << 20, 8 << 20][s],
            64,
        ))),
        "vector_bw" => Ok(Box::new(workloads::vector::VectorOp::new(
            "vector_bw",
            [1usize << 20, 2 << 20, 4 << 20, 8 << 20][s],
            1,
        ))),
        "particles" => Ok(Box::new(workloads::particles::Particles::new(
            [50_000usize, 100_000, 200_000, 400_000][s],
            64,
        ))),
        "image" => {
            let (w, h) = [(512usize, 512usize), (720, 1600), (1080, 2400), (1440, 3200)][s];
            Ok(Box::new(workloads::image::ImageFilter::new(w, h)))
        }
        _ => Err(format!("unknown workload '{}'", id)),
    }
}
