//! Executes one run of a workload with a given CPU/GPU partition.
//!
//! Timeline of a hybrid run:
//!   1. GPU: encode + submit its range (returns immediately, GPU starts working)
//!   2. CPU: compute its range on worker threads  <-- overlaps with the GPU execution
//!   3. Join the GPU waiter thread, merge GPU results into the shared output
use std::time::Instant;

use cpu_engine::CpuEngine;
use gpu_engine::Pending;
use lab_core::util::{ms_between, ms_since};
use serde::{Deserialize, Serialize};

use crate::balancer::Balancer;
use crate::partition::Partition;
use crate::workload::Workload;

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct RunObservation {
    /// Wall time of the whole run.
    pub total_ms: f64,
    /// CPU compute time (0 when the CPU had no work).
    pub cpu_ms: f64,
    /// Submission start to GPU completion, as observed by the waiter thread.
    pub gpu_wall_ms: f64,
    /// Pure GPU execution time from timestamp queries (None if unsupported).
    pub gpu_busy_ms: Option<f64>,
    /// Host time spent encoding + submitting GPU work.
    pub gpu_submit_ms: f64,
    /// Time to map and copy GPU results back to host memory.
    pub gpu_readback_ms: f64,
    /// Time the main thread sat idle waiting for the GPU after its own CPU work finished.
    pub gpu_wait_ms: f64,
    /// Time to merge GPU results into the shared output.
    pub merge_ms: f64,
    /// Time during which the CPU and the GPU were both working (measured).
    pub overlap_ms: f64,
    pub cpu_units: usize,
    pub gpu_units: usize,
}

pub fn run_once(w: &mut dyn Workload, cpu: &CpuEngine, part: &Partition) -> Result<RunObservation, String> {
    let t_start = Instant::now();
    let mut obs = RunObservation {
        cpu_units: part.cpu.len(),
        gpu_units: part.gpu.len(),
        ..Default::default()
    };

    // 1. GPU submission (non-blocking)
    let mut pending: Option<Pending> = None;
    if !part.gpu.is_empty() {
        let p = w.gpu_submit(part.gpu.clone())?;
        obs.gpu_submit_ms = p.submit_ms;
        pending = Some(p);
    }

    // 2. CPU work, concurrent with the GPU
    let cpu_start = Instant::now();
    if !part.cpu.is_empty() {
        w.cpu_compute(cpu, part.cpu.clone());
    }
    let cpu_end = Instant::now();
    if !part.cpu.is_empty() {
        obs.cpu_ms = ms_between(cpu_start, cpu_end);
    }

    // 3. Wait for the GPU and merge
    if let Some(p) = pending {
        let submitted_at = p.submitted_at;
        let (bytes, timing) = p.wait()?;
        let joined = Instant::now();
        obs.gpu_wait_ms = ms_between(cpu_end, joined);
        obs.gpu_wall_ms = ms_between(submitted_at, timing.done_at);
        obs.gpu_busy_ms = timing.busy_ms;
        obs.gpu_readback_ms = timing.readback_ms;
        if !part.cpu.is_empty() {
            let s = if cpu_start > submitted_at { cpu_start } else { submitted_at };
            let e = if cpu_end < timing.done_at { cpu_end } else { timing.done_at };
            obs.overlap_ms = ms_between(s, e);
        }
        let tm = Instant::now();
        w.gpu_merge(part.gpu.clone(), &bytes);
        obs.merge_ms = ms_since(tm);
    }
    obs.total_ms = ms_since(t_start);
    Ok(obs)
}

/// Measures standalone CPU and GPU throughput (and the GPU's fixed overhead) with small probe
/// runs so Balanced / Automatic distribution starts from real data instead of a guess.
pub fn calibrate(
    w: &mut dyn Workload,
    cpu: &CpuEngine,
    total: usize,
    granularity: usize,
) -> Result<Balancer, String> {
    let g = granularity.max(1);
    let align = |u: usize| -> usize { ((u / g).max(1) * g).min(total) };
    let q_cpu = align(total / 4);
    let q1 = align(total / 8);
    let q2 = align(total / 2).max(q1);

    let mut t_cpu = f64::MAX;
    for _ in 0..2 {
        let obs = run_once(w, cpu, &Partition { cpu: 0..q_cpu, gpu: q_cpu..q_cpu })?;
        t_cpu = t_cpu.min(obs.cpu_ms);
    }
    let t1 = gpu_probe(w, cpu, q1)?;
    let t2 = gpu_probe(w, cpu, q2)?;

    let r_cpu = if t_cpu > 0.0 { q_cpu as f64 / t_cpu } else { 1.0 };
    let (r_gpu, overhead) = if q2 > q1 && t2 > t1 * 1.05 {
        let r = (q2 - q1) as f64 / (t2 - t1);
        (r, (t1 - q1 as f64 / r).max(0.0))
    } else {
        (q2 as f64 / t2.max(1e-6), 0.0)
    };
    let mut b = Balancer::new(total, granularity);
    b.seed(r_cpu, r_gpu, overhead);
    Ok(b)
}

/// Best-of-two wall time of a GPU-only run over the first `q` units.
fn gpu_probe(w: &mut dyn Workload, cpu: &CpuEngine, q: usize) -> Result<f64, String> {
    let mut best = f64::MAX;
    for _ in 0..2 {
        let obs = run_once(w, cpu, &Partition { cpu: 0..0, gpu: 0..q })?;
        best = best.min(obs.total_ms);
    }
    Ok(best)
}
