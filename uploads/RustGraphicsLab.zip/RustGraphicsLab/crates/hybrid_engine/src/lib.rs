//! Hybrid CPU + GPU execution: workloads, partitioning, automatic balancing and the runner that
//! lets both processors compute different parts of the same problem at the same time.
pub mod balancer;
pub mod partition;
pub mod runner;
pub mod workload;
pub mod workloads;

pub use balancer::Balancer;
pub use partition::{Distribution, Partition};
pub use runner::{calibrate, run_once, RunObservation};
pub use workload::{catalog, create, CatalogEntry, GpuPrep, Validation, Workload, WorkloadInfo};
