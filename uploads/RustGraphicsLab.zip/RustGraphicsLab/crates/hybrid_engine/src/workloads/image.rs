//! Image processing workload (units = image rows). Integer-only, so CPU and GPU output must be
//! bit-identical; any seam between the CPU region and the GPU region would be detected.
use std::ops::Range;
use std::sync::Arc;
use std::time::Instant;

use cpu_engine::image as cpu_image;
use cpu_engine::CpuEngine;
use gpu_engine::wgpu;
use gpu_engine::{kernels, submit_range, BindKind, GpuContext, Kernel, Pending, RangeJob};
use lab_core::util::{as_bytes_u32, bytes_into_u32, ms_since};

use crate::workload::{GpuPrep, Validation, Workload, WorkloadInfo};

const POISON: u32 = 0xDEAD_BEEF;

struct Gpu {
    ctx: GpuContext,
    kernel: Kernel,
    bind: wgpu::BindGroup,
    params: wgpu::Buffer,
    out: wgpu::Buffer,
    staging: Arc<wgpu::Buffer>,
    _src: wgpu::Buffer,
}

pub struct ImageFilter {
    w: usize,
    h: usize,
    src: Vec<u32>,
    out: Vec<u32>,
    gpu: Option<Gpu>,
}

impl ImageFilter {
    pub fn new(w: usize, h: usize) -> ImageFilter {
        ImageFilter {
            w,
            h,
            src: cpu_image::make_image(w, h, 0x494D_4147),
            out: vec![POISON; w * h],
            gpu: None,
        }
    }
}

impl Workload for ImageFilter {
    fn info(&self) -> WorkloadInfo {
        WorkloadInfo {
            id: "image".to_string(),
            name: format!("Image filter {}x{} (RGBA8)", self.w, self.h),
            units: self.h,
            unit_name: "rows".to_string(),
            granularity: 8,
            flops: 70.0 * (self.w * self.h) as f64,
            bytes: 8.0 * (self.w * self.h) as f64,
            params: format!("{}x{} px, 3x3 Gaussian + contrast, ~70 integer ops/pixel (nominal)", self.w, self.h),
        }
    }

    fn cpu_compute(&mut self, cpu: &CpuEngine, range: Range<usize>) {
        let w = self.w;
        let slice = &mut self.out[range.start * w..range.end * w];
        cpu_image::filter_rows(cpu, &self.src, w, self.h, range.start, range.end, slice);
    }

    fn gpu_prepare(&mut self, ctx: &GpuContext) -> Result<GpuPrep, String> {
        let nbytes = (self.w * self.h * 4) as u64;
        ctx.check_storage(nbytes)?;
        let t0 = Instant::now();
        let kernel = ctx.build_kernel(
            "image",
            kernels::IMAGE,
            "main",
            &[BindKind::StorageRead, BindKind::StorageRw, BindKind::Uniform],
        )?;
        let build_ms = ms_since(t0);
        let src = ctx.create_storage_buffer("img-src", nbytes);
        let out = ctx.create_storage_buffer("img-dst", nbytes);
        let params = ctx.create_uniform_buffer("img-params", 16);
        let staging = ctx.create_staging_buffer("img-staging", nbytes);
        let t1 = Instant::now();
        ctx.upload(&src, 0, as_bytes_u32(&self.src));
        ctx.flush();
        let upload_ms = ms_since(t1);
        let bind = ctx.bind(&kernel, &[&src, &out, &params]);
        self.gpu = Some(Gpu {
            ctx: ctx.clone(),
            kernel,
            bind,
            params,
            out,
            staging,
            _src: src,
        });
        Ok(GpuPrep {
            build_ms,
            upload_ms,
            upload_bytes: nbytes,
            gpu_buffer_bytes: nbytes * 2,
        })
    }

    fn gpu_submit(&mut self, range: Range<usize>) -> Result<Pending, String> {
        let g = self.gpu.as_ref().ok_or_else(|| "GPU not prepared".to_string())?;
        let rows = range.len() as u32;
        let w = self.w as u32;
        let mut p: Vec<u8> = Vec::with_capacity(16);
        for v in [w, self.h as u32, range.start as u32, rows] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        submit_range(
            &g.ctx,
            RangeJob {
                kernel: &g.kernel,
                bind_group: &g.bind,
                groups: ((w + 7) / 8, (rows + 7) / 8, 1),
                params: Some((&g.params, p)),
                out: &g.out,
                staging: g.staging.clone(),
                read_bytes: rows as u64 * w as u64 * 4,
            },
        )
    }

    fn gpu_merge(&mut self, range: Range<usize>, bytes: &[u8]) {
        let w = self.w;
        bytes_into_u32(bytes, &mut self.out[range.start * w..range.end * w]);
    }

    fn clear_output(&mut self) {
        for v in self.out.iter_mut() {
            *v = POISON;
        }
    }

    fn validate(&mut self, boundary: Option<usize>) -> Validation {
        let (w, h) = (self.w, self.h);
        let mut rows: Vec<usize> = vec![0, h - 1];
        let mut y = 0;
        while y < h {
            rows.push(y);
            y += 5;
        }
        if let Some(b) = boundary {
            for d in 0..6usize {
                rows.push((b + d).saturating_sub(3).min(h - 1));
            }
        }
        rows.sort_unstable();
        rows.dedup();
        let mut mismatches = 0usize;
        let mut checked = 0usize;
        for &y in &rows {
            for x in 0..w {
                checked += 1;
                if self.out[y * w + x] != cpu_image::filter_pixel(&self.src, w, h, x, y) {
                    mismatches += 1;
                }
            }
        }
        Validation {
            ok: mismatches == 0,
            checked,
            mismatches,
            max_abs_err: 0.0,
            detail: format!("{} full rows of {} compared bit-exactly (split seam included)", rows.len(), h),
        }
    }
}
