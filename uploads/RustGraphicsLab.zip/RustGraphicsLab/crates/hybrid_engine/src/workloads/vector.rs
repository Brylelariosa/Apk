//! Vector workload (units = elements). iters = 1 is memory-bound, iters = 64 is compute-bound.
use std::ops::Range;
use std::sync::Arc;
use std::time::Instant;

use cpu_engine::vector as cpu_vector;
use cpu_engine::CpuEngine;
use gpu_engine::wgpu;
use gpu_engine::{kernels, submit_range, BindKind, GpuContext, Kernel, Pending, RangeJob};
use lab_core::util::{as_bytes_f32, bytes_into_f32, ms_since, Lcg};

use crate::workload::{GpuPrep, Validation, Workload, WorkloadInfo};

const COEF_A: f32 = 0.9995;
const COEF_B: f32 = 0.001;

struct Gpu {
    ctx: GpuContext,
    kernel: Kernel,
    bind: wgpu::BindGroup,
    params: wgpu::Buffer,
    out: wgpu::Buffer,
    staging: Arc<wgpu::Buffer>,
    _x: wgpu::Buffer,
}

pub struct VectorOp {
    id: &'static str,
    len: usize,
    iters: u32,
    x: Vec<f32>,
    out: Vec<f32>,
    gpu: Option<Gpu>,
}

impl VectorOp {
    pub fn new(id: &'static str, len: usize, iters: u32) -> VectorOp {
        let mut rng = Lcg::new(0x5645_4354);
        let x: Vec<f32> = (0..len).map(|_| rng.next_signed() * 4.0).collect();
        VectorOp {
            id,
            len,
            iters,
            x,
            out: vec![0.0; len],
            gpu: None,
        }
    }
}

impl Workload for VectorOp {
    fn info(&self) -> WorkloadInfo {
        let kind = if self.iters <= 1 { "stream (memory-bound)" } else { "FMA chain (compute-bound)" };
        WorkloadInfo {
            id: self.id.to_string(),
            name: format!("Vector {} - {}M elements", kind, self.len as f64 / 1048576.0),
            units: self.len,
            unit_name: "elements".to_string(),
            granularity: 256,
            flops: 2.0 * self.len as f64 * self.iters as f64,
            bytes: 8.0 * self.len as f64,
            params: format!("elements={}, fma/element={}", self.len, self.iters),
        }
    }

    fn cpu_compute(&mut self, cpu: &CpuEngine, range: Range<usize>) {
        let slice = &mut self.out[range.start..range.end];
        cpu_vector::fma_chain_range(cpu, &self.x, slice, range.start, COEF_A, COEF_B, self.iters);
    }

    fn gpu_prepare(&mut self, ctx: &GpuContext) -> Result<GpuPrep, String> {
        let nbytes = (self.len * 4) as u64;
        ctx.check_storage(nbytes)?;
        let t0 = Instant::now();
        let kernel = ctx.build_kernel(
            "vector",
            kernels::VECTOR,
            "main",
            &[BindKind::StorageRead, BindKind::StorageRw, BindKind::Uniform],
        )?;
        let build_ms = ms_since(t0);
        let x = ctx.create_storage_buffer("vec-x", nbytes);
        let out = ctx.create_storage_buffer("vec-y", nbytes);
        let params = ctx.create_uniform_buffer("vec-params", 32);
        let staging = ctx.create_staging_buffer("vec-staging", nbytes);
        let t1 = Instant::now();
        ctx.upload(&x, 0, as_bytes_f32(&self.x));
        ctx.flush();
        let upload_ms = ms_since(t1);
        let bind = ctx.bind(&kernel, &[&x, &out, &params]);
        self.gpu = Some(Gpu {
            ctx: ctx.clone(),
            kernel,
            bind,
            params,
            out,
            staging,
            _x: x,
        });
        Ok(GpuPrep {
            build_ms,
            upload_ms,
            upload_bytes: nbytes,
            gpu_buffer_bytes: nbytes * 2,
        })
    }

    fn gpu_submit(&mut self, range: Range<usize>) -> Result<Pending, String> {
        let g = self.gpu.as_ref().ok_or_else(|| "GPU not prepared".to_string())?;
        let count = range.len() as u32;
        let mut p: Vec<u8> = Vec::with_capacity(32);
        for v in [count, range.start as u32, self.iters, 0u32] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        for v in [COEF_A, COEF_B, 0.0f32, 0.0f32] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        let total_groups = (count + 63) / 64;
        let max_dim = g.ctx.limits.max_compute_workgroups_per_dimension.max(1);
        let gx = total_groups.min(max_dim).max(1);
        let gy = ((total_groups + gx - 1) / gx).max(1);
        submit_range(
            &g.ctx,
            RangeJob {
                kernel: &g.kernel,
                bind_group: &g.bind,
                groups: (gx, gy, 1),
                params: Some((&g.params, p)),
                out: &g.out,
                staging: g.staging.clone(),
                read_bytes: count as u64 * 4,
            },
        )
    }

    fn gpu_merge(&mut self, range: Range<usize>, bytes: &[u8]) {
        bytes_into_f32(bytes, &mut self.out[range.start..range.end]);
    }

    fn clear_output(&mut self) {
        for v in self.out.iter_mut() {
            *v = f32::NAN;
        }
    }

    fn validate(&mut self, boundary: Option<usize>) -> Validation {
        let n = self.len;
        let stride = (n / 200_000).max(1);
        let mut idx: Vec<usize> = (0..n).step_by(stride).collect();
        if let Some(b) = boundary {
            for d in 0..64usize {
                idx.push(b.saturating_sub(32) + d);
            }
        }
        idx.push(n - 1);
        let mut mismatches = 0usize;
        let mut checked = 0usize;
        let mut max_err = 0f64;
        for &i in &idx {
            if i >= n {
                continue;
            }
            let r = cpu_vector::fma_chain_ref(self.x[i], COEF_A, COEF_B, self.iters);
            let err = (self.out[i] as f64 - r).abs();
            checked += 1;
            if !(err <= 1e-4 + 1e-4 * r.abs()) {
                mismatches += 1;
            }
            if err.is_finite() && err > max_err {
                max_err = err;
            }
        }
        Validation {
            ok: mismatches == 0,
            checked,
            mismatches,
            max_abs_err: max_err,
            detail: format!("{} sampled elements of {} (split point included)", checked, n),
        }
    }
}
