//! Particle simulation workload (units = particles). Particles are independent, so a CPU group
//! and a GPU group can be integrated simultaneously and merged into one simulation state.
use std::ops::Range;
use std::sync::Arc;
use std::time::Instant;

use cpu_engine::particles::{self as cpu_particles, ParticleParams};
use cpu_engine::CpuEngine;
use gpu_engine::wgpu;
use gpu_engine::{kernels, submit_range, BindKind, GpuContext, Kernel, Pending, RangeJob};
use lab_core::util::{as_bytes_f32, bytes_into_f32, ms_since, Lcg};

use crate::workload::{GpuPrep, Validation, Workload, WorkloadInfo};

struct Gpu {
    ctx: GpuContext,
    kernel: Kernel,
    bind: wgpu::BindGroup,
    params: wgpu::Buffer,
    out: wgpu::Buffer,
    staging: Arc<wgpu::Buffer>,
    _src: wgpu::Buffer,
    _att: wgpu::Buffer,
}

pub struct Particles {
    n: usize,
    steps: usize,
    params: ParticleParams,
    attractors: Vec<[f32; 2]>,
    src: Vec<f32>,
    out: Vec<f32>,
    gpu: Option<Gpu>,
}

impl Particles {
    pub fn new(n: usize, steps: usize) -> Particles {
        let mut rng = Lcg::new(0x5041_5254);
        let mut src: Vec<f32> = Vec::with_capacity(n * 4);
        for _ in 0..n {
            src.push(rng.next_signed() * 0.9);
            src.push(rng.next_signed() * 0.9);
            src.push(rng.next_signed() * 0.3);
            src.push(rng.next_signed() * 0.3);
        }
        Particles {
            n,
            steps,
            params: ParticleParams::default(),
            attractors: cpu_particles::make_attractors(steps),
            src,
            out: vec![0.0; n * 4],
            gpu: None,
        }
    }
}

impl Workload for Particles {
    fn info(&self) -> WorkloadInfo {
        WorkloadInfo {
            id: "particles".to_string(),
            name: format!("Particle simulation - {} particles x {} steps", self.n, self.steps),
            units: self.n,
            unit_name: "particles".to_string(),
            granularity: 64,
            flops: 16.0 * self.n as f64 * self.steps as f64,
            bytes: 32.0 * self.n as f64,
            params: format!("particles={}, steps={}, ~16 flops/particle/step (nominal)", self.n, self.steps),
        }
    }

    fn cpu_compute(&mut self, cpu: &CpuEngine, range: Range<usize>) {
        let slice = &mut self.out[range.start * 4..range.end * 4];
        cpu_particles::step_range(cpu, &self.src, slice, range.start, &self.attractors, &self.params);
    }

    fn gpu_prepare(&mut self, ctx: &GpuContext) -> Result<GpuPrep, String> {
        let nbytes = (self.n * 16) as u64;
        ctx.check_storage(nbytes)?;
        let t0 = Instant::now();
        let kernel = ctx.build_kernel(
            "particles",
            kernels::PARTICLES,
            "main",
            &[
                BindKind::StorageRead,
                BindKind::StorageRw,
                BindKind::StorageRead,
                BindKind::Uniform,
            ],
        )?;
        let build_ms = ms_since(t0);
        let flat: Vec<f32> = self.attractors.iter().flat_map(|a| a.iter().cloned()).collect();
        let att_bytes = (flat.len() * 4) as u64;
        let src = ctx.create_storage_buffer("pt-src", nbytes);
        let out = ctx.create_storage_buffer("pt-dst", nbytes);
        let att = ctx.create_storage_buffer("pt-att", att_bytes);
        let params = ctx.create_uniform_buffer("pt-params", 32);
        let staging = ctx.create_staging_buffer("pt-staging", nbytes);
        let t1 = Instant::now();
        ctx.upload(&src, 0, as_bytes_f32(&self.src));
        ctx.upload(&att, 0, as_bytes_f32(&flat));
        ctx.flush();
        let upload_ms = ms_since(t1);
        let bind = ctx.bind(&kernel, &[&src, &out, &att, &params]);
        self.gpu = Some(Gpu {
            ctx: ctx.clone(),
            kernel,
            bind,
            params,
            out,
            staging,
            _src: src,
            _att: att,
        });
        Ok(GpuPrep {
            build_ms,
            upload_ms,
            upload_bytes: nbytes + att_bytes,
            gpu_buffer_bytes: nbytes * 2 + att_bytes,
        })
    }

    fn gpu_submit(&mut self, range: Range<usize>) -> Result<Pending, String> {
        let g = self.gpu.as_ref().ok_or_else(|| "GPU not prepared".to_string())?;
        let count = range.len() as u32;
        let mut p: Vec<u8> = Vec::with_capacity(32);
        for v in [count, range.start as u32, self.steps as u32, 0u32] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        for v in [self.params.dt, self.params.k, self.params.damp, self.params.swirl] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        let total_groups = (count + 63) / 64;
        let max_dim = g.ctx.limits.max_compute_workgroups_per_dimension.max(1);
        let gx = total_groups.min(max_dim).max(1);
        let gy = ((total_groups + gx - 1) / gx).max(1);
        submit_range(
            &g.ctx,
            RangeJob {
                kernel: &g.kernel,
                bind_group: &g.bind,
                groups: (gx, gy, 1),
                params: Some((&g.params, p)),
                out: &g.out,
                staging: g.staging.clone(),
                read_bytes: count as u64 * 16,
            },
        )
    }

    fn gpu_merge(&mut self, range: Range<usize>, bytes: &[u8]) {
        bytes_into_f32(bytes, &mut self.out[range.start * 4..range.end * 4]);
    }

    fn clear_output(&mut self) {
        for v in self.out.iter_mut() {
            *v = f32::NAN;
        }
    }

    fn validate(&mut self, boundary: Option<usize>) -> Validation {
        let n = self.n;
        let stride = (n / 20_000).max(1);
        let mut idx: Vec<usize> = (0..n).step_by(stride).collect();
        if let Some(b) = boundary {
            for d in 0..64usize {
                idx.push(b.saturating_sub(32) + d);
            }
        }
        idx.push(n - 1);
        let mut mismatches = 0usize;
        let mut checked = 0usize;
        let mut max_err = 0f64;
        for &i in &idx {
            if i >= n {
                continue;
            }
            let init = [self.src[i * 4], self.src[i * 4 + 1], self.src[i * 4 + 2], self.src[i * 4 + 3]];
            let r = cpu_particles::reference(init, &self.attractors, &self.params);
            for c in 0..4 {
                let err = (self.out[i * 4 + c] as f64 - r[c]).abs();
                checked += 1;
                if !(err <= 2e-3) {
                    mismatches += 1;
                }
                if err.is_finite() && err > max_err {
                    max_err = err;
                }
            }
        }
        Validation {
            ok: mismatches == 0,
            checked,
            mismatches,
            max_abs_err: max_err,
            detail: format!("{} state values of {} particles vs f64 reference", checked, n),
        }
    }
}
