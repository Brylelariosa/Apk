//! Matrix multiplication workload (units = output rows).
use std::ops::Range;
use std::sync::Arc;
use std::time::Instant;

use cpu_engine::matmul as cpu_matmul;
use cpu_engine::CpuEngine;
use gpu_engine::wgpu;
use gpu_engine::{kernels, submit_range, BindKind, GpuContext, Kernel, Pending, RangeJob};
use lab_core::util::{as_bytes_f32, bytes_into_f32, ms_since, Lcg};

use crate::workload::{GpuPrep, Validation, Workload, WorkloadInfo};

struct Gpu {
    ctx: GpuContext,
    kernel: Kernel,
    bind: wgpu::BindGroup,
    params: wgpu::Buffer,
    out: wgpu::Buffer,
    staging: Arc<wgpu::Buffer>,
    _a: wgpu::Buffer,
    _b: wgpu::Buffer,
}

pub struct MatMul {
    n: usize,
    a: Vec<f32>,
    b: Vec<f32>,
    out: Vec<f32>,
    gpu: Option<Gpu>,
}

impl MatMul {
    pub fn new(n: usize) -> MatMul {
        let mut rng = Lcg::new(0x4D41_544D);
        let a: Vec<f32> = (0..n * n).map(|_| rng.next_signed()).collect();
        let b: Vec<f32> = (0..n * n).map(|_| rng.next_signed()).collect();
        MatMul {
            n,
            a,
            b,
            out: vec![0.0; n * n],
            gpu: None,
        }
    }
}

impl Workload for MatMul {
    fn info(&self) -> WorkloadInfo {
        WorkloadInfo {
            id: "matmul".to_string(),
            name: format!("Matrix multiplication {0}x{0} (f32)", self.n),
            units: self.n,
            unit_name: "rows".to_string(),
            granularity: 8,
            flops: 2.0 * (self.n as f64).powi(3),
            bytes: 3.0 * ((self.n * self.n * 4) as f64),
            params: format!("N={}", self.n),
        }
    }

    fn cpu_compute(&mut self, cpu: &CpuEngine, range: Range<usize>) {
        let n = self.n;
        let slice = &mut self.out[range.start * n..range.end * n];
        cpu_matmul::matmul_rows(cpu, &self.a, &self.b, n, range.start, range.end, slice);
    }

    fn gpu_prepare(&mut self, ctx: &GpuContext) -> Result<GpuPrep, String> {
        let nbytes = (self.n * self.n * 4) as u64;
        ctx.check_storage(nbytes)?;
        let t0 = Instant::now();
        let kernel = ctx.build_kernel(
            "matmul",
            kernels::MATMUL,
            "main",
            &[
                BindKind::StorageRead,
                BindKind::StorageRead,
                BindKind::StorageRw,
                BindKind::Uniform,
            ],
        )?;
        let build_ms = ms_since(t0);
        let a = ctx.create_storage_buffer("mm-a", nbytes);
        let b = ctx.create_storage_buffer("mm-b", nbytes);
        let out = ctx.create_storage_buffer("mm-c", nbytes);
        let params = ctx.create_uniform_buffer("mm-params", 16);
        let staging = ctx.create_staging_buffer("mm-staging", nbytes);
        let t1 = Instant::now();
        ctx.upload(&a, 0, as_bytes_f32(&self.a));
        ctx.upload(&b, 0, as_bytes_f32(&self.b));
        ctx.flush();
        let upload_ms = ms_since(t1);
        let bind = ctx.bind(&kernel, &[&a, &b, &out, &params]);
        self.gpu = Some(Gpu {
            ctx: ctx.clone(),
            kernel,
            bind,
            params,
            out,
            staging,
            _a: a,
            _b: b,
        });
        Ok(GpuPrep {
            build_ms,
            upload_ms,
            upload_bytes: nbytes * 2,
            gpu_buffer_bytes: nbytes * 3,
        })
    }

    fn gpu_submit(&mut self, range: Range<usize>) -> Result<Pending, String> {
        let g = self.gpu.as_ref().ok_or_else(|| "GPU not prepared".to_string())?;
        let n = self.n as u32;
        let rows = range.len() as u32;
        let mut p: Vec<u8> = Vec::with_capacity(16);
        for v in [n, range.start as u32, rows, 0u32] {
            p.extend_from_slice(&v.to_le_bytes());
        }
        submit_range(
            &g.ctx,
            RangeJob {
                kernel: &g.kernel,
                bind_group: &g.bind,
                groups: ((n + 7) / 8, (rows + 7) / 8, 1),
                params: Some((&g.params, p)),
                out: &g.out,
                staging: g.staging.clone(),
                read_bytes: rows as u64 * n as u64 * 4,
            },
        )
    }

    fn gpu_merge(&mut self, range: Range<usize>, bytes: &[u8]) {
        let n = self.n;
        bytes_into_f32(bytes, &mut self.out[range.start * n..range.end * n]);
    }

    fn clear_output(&mut self) {
        for v in self.out.iter_mut() {
            *v = f32::NAN;
        }
    }

    fn validate(&mut self, boundary: Option<usize>) -> Validation {
        let n = self.n;
        let mut rows: Vec<usize> = vec![0, n - 1];
        let samples = 48usize.min(n);
        for i in 0..samples {
            rows.push(i * n / samples);
        }
        if let Some(b) = boundary {
            for d in [b.saturating_sub(1), b, b + 1] {
                rows.push(d.min(n - 1));
            }
        }
        rows.sort_unstable();
        rows.dedup();
        let mut mismatches = 0usize;
        let mut checked = 0usize;
        let mut max_err = 0f64;
        for &r in &rows {
            let reference = cpu_matmul::matmul_ref_row(&self.a, &self.b, n, r);
            for j in 0..n {
                let got = self.out[r * n + j] as f64;
                let err = (got - reference[j]).abs();
                checked += 1;
                if !(err <= 2e-3 + 2e-4 * reference[j].abs()) {
                    mismatches += 1;
                }
                if err.is_finite() && err > max_err {
                    max_err = err;
                }
            }
        }
        Validation {
            ok: mismatches == 0,
            checked,
            mismatches,
            max_abs_err: max_err,
            detail: format!("{} sampled rows of {} (CPU/GPU boundary rows included)", rows.len(), n),
        }
    }
}
