//! How a workload's units are divided between the CPU and the GPU.
use std::ops::Range;

/// CPU takes units [0, k), GPU takes [k, total). The numbers are real unit counts, never
/// "pretend" utilisation percentages.
#[derive(Clone, Debug)]
pub struct Partition {
    pub cpu: Range<usize>,
    pub gpu: Range<usize>,
}

impl Partition {
    /// Splits `total` units giving the CPU `cpu_fraction`, aligned to `granularity` units.
    pub fn split(total: usize, cpu_fraction: f64, granularity: usize) -> Partition {
        let g = granularity.max(1);
        let f = if cpu_fraction.is_finite() { cpu_fraction.clamp(0.0, 1.0) } else { 0.5 };
        let mut cpu_units = (((total as f64) * f / g as f64).round() as usize) * g;
        if cpu_units > total {
            cpu_units = total;
        }
        Partition {
            cpu: 0..cpu_units,
            gpu: cpu_units..total,
        }
    }

    pub fn all_cpu(total: usize) -> Partition {
        Partition { cpu: 0..total, gpu: total..total }
    }

    pub fn all_gpu(total: usize) -> Partition {
        Partition { cpu: 0..0, gpu: 0..total }
    }

    pub fn cpu_fraction(&self) -> f64 {
        let t = self.cpu.len() + self.gpu.len();
        if t == 0 {
            0.0
        } else {
            self.cpu.len() as f64 / t as f64
        }
    }

    /// The CPU/GPU seam, if both sides have work.
    pub fn boundary(&self) -> Option<usize> {
        if self.cpu.is_empty() || self.gpu.is_empty() {
            None
        } else {
            Some(self.cpu.end)
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Distribution {
    CpuPriority,
    GpuPriority,
    Balanced,
    Cpu25,
    Cpu50,
    Cpu75,
    Auto,
    Custom,
}

impl Distribution {
    pub fn parse(s: &str) -> Distribution {
        match s {
            "cpu_priority" => Distribution::CpuPriority,
            "gpu_priority" => Distribution::GpuPriority,
            "balanced" => Distribution::Balanced,
            "cpu25" => Distribution::Cpu25,
            "cpu50" => Distribution::Cpu50,
            "cpu75" => Distribution::Cpu75,
            "custom" => Distribution::Custom,
            _ => Distribution::Auto,
        }
    }

    pub fn id(&self) -> &'static str {
        match self {
            Distribution::CpuPriority => "cpu_priority",
            Distribution::GpuPriority => "gpu_priority",
            Distribution::Balanced => "balanced",
            Distribution::Cpu25 => "cpu25",
            Distribution::Cpu50 => "cpu50",
            Distribution::Cpu75 => "cpu75",
            Distribution::Auto => "auto",
            Distribution::Custom => "custom",
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            Distribution::CpuPriority => "CPU priority (80% CPU / 20% GPU)",
            Distribution::GpuPriority => "GPU priority (20% CPU / 80% GPU)",
            Distribution::Balanced => "Balanced (calibrated split)",
            Distribution::Cpu25 => "CPU 25% / GPU 75%",
            Distribution::Cpu50 => "CPU 50% / GPU 50%",
            Distribution::Cpu75 => "CPU 75% / GPU 25%",
            Distribution::Auto => "Automatic balancing",
            Distribution::Custom => "Custom distribution",
        }
    }

    /// Fixed CPU share for modes that have one.
    pub fn fixed_fraction(&self) -> Option<f64> {
        match self {
            Distribution::CpuPriority => Some(0.8),
            Distribution::GpuPriority => Some(0.2),
            Distribution::Cpu25 => Some(0.25),
            Distribution::Cpu50 => Some(0.5),
            Distribution::Cpu75 => Some(0.75),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_is_aligned_and_complete() {
        let p = Partition::split(512, 0.3, 8);
        assert_eq!(p.cpu.start, 0);
        assert_eq!(p.cpu.end % 8, 0);
        assert_eq!(p.cpu.end, p.gpu.start);
        assert_eq!(p.gpu.end, 512);
        assert!((p.cpu_fraction() - 0.3).abs() < 0.02);
    }

    #[test]
    fn extremes() {
        assert!(Partition::split(100, 0.0, 8).cpu.is_empty());
        assert!(Partition::split(100, 1.0, 8).gpu.is_empty());
        assert_eq!(Partition::split(100, 1.0, 8).cpu.end, 100);
    }

    #[test]
    fn parse_roundtrip() {
        for d in [
            Distribution::CpuPriority,
            Distribution::GpuPriority,
            Distribution::Balanced,
            Distribution::Cpu25,
            Distribution::Cpu50,
            Distribution::Cpu75,
            Distribution::Auto,
            Distribution::Custom,
        ] {
            assert_eq!(Distribution::parse(d.id()), d);
        }
    }
}
