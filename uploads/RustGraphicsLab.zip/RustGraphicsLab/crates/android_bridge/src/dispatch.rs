//! Command router. Every command returns display-ready JSON so the UI stays a thin shell.
use std::panic::AssertUnwindSafe;
use std::sync::atomic::Ordering;
use std::sync::{Arc, MutexGuard};
use std::time::Instant;

use benchmark::{report, store, BenchConfig, Progress, SessionEnv, Settings};
use gpu_engine::{BackendPref, GpuContext};
use lab_core::platform;
use lab_core::sysinfo;
use lab_core::util::{row, section, unix_ms, MEASURED, UNAVAILABLE};
use serde_json::{json, Value};

use crate::state::{self, App, GpuSlot};

pub fn handle(cmd: &str, args: &str) -> String {
    let a: Value = serde_json::from_str(args).unwrap_or(Value::Null);
    match route(cmd, &a) {
        Ok(v) => json!({ "ok": true, "data": v }).to_string(),
        Err(e) => json!({ "ok": false, "error": e }).to_string(),
    }
}

fn need_app() -> Result<&'static App, String> {
    state::app().ok_or_else(|| "app not initialised (app.init was not called)".to_string())
}

fn get_str(a: &Value, k: &str) -> Option<String> {
    a.get(k).and_then(|v| v.as_str()).map(|s| s.to_string())
}

fn lock_gpu(app: &App) -> MutexGuard<'_, GpuSlot> {
    match app.gpu.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    }
}

fn route(cmd: &str, a: &Value) -> Result<Value, String> {
    match cmd {
        "app.init" => cmd_init(a),
        "platform.static" => {
            platform::set_static(a.clone());
            Ok(Value::Null)
        }
        "platform.update" => {
            platform::update(a);
            Ok(Value::Null)
        }
        "dashboard" => cmd_dashboard(),
        "device.report" => Ok(json!({ "sections": sysinfo::device_sections() })),
        "gpu.report" => cmd_gpu_report(),
        "drivers.report" => cmd_drivers_report(),
        "backend.set" => cmd_backend(a),
        "bench.catalog" => Ok(cmd_catalog()),
        "bench.start" => cmd_bench_start(a),
        "bench.stop" => {
            let app = need_app()?;
            app.stop.store(true, Ordering::SeqCst);
            Ok(Value::Null)
        }
        "bench.status" => {
            let app = need_app()?;
            let p = match app.progress.lock() {
                Ok(p) => p.clone(),
                Err(e) => e.into_inner().clone(),
            };
            Ok(p.to_json())
        }
        "bench.set_cpu_pct" => {
            let app = need_app()?;
            let pct = a.get("pct").and_then(|v| v.as_f64()).unwrap_or(50.0).clamp(0.0, 100.0);
            app.custom_permille.store((pct * 10.0).round() as u32, Ordering::Relaxed);
            Ok(Value::Null)
        }
        "monitor.sample" => {
            let app = need_app()?;
            let mut m = match app.monitor.lock() {
                Ok(m) => m,
                Err(e) => e.into_inner(),
            };
            Ok(json!({ "sections": m.sample() }))
        }
        "history.list" => {
            let app = need_app()?;
            let mut items = store::load_history(&app.files_dir);
            items.reverse();
            let list: Vec<Value> = items.iter().map(report::history_item).collect();
            Ok(json!({ "items": list }))
        }
        "history.get" => {
            let app = need_app()?;
            let id = get_str(a, "id").unwrap_or_default();
            let items = store::load_history(&app.files_dir);
            match items.iter().find(|r| r.id == id) {
                Some(r) => Ok(json!({ "title": r.workload.name, "time": r.timestamp_ms, "sections": report::result_sections(r) })),
                None => Err("result not found".to_string()),
            }
        }
        "history.compare" => {
            let app = need_app()?;
            let (ia, ib) = (get_str(a, "a").unwrap_or_default(), get_str(a, "b").unwrap_or_default());
            let items = store::load_history(&app.files_dir);
            let ra = items.iter().find(|r| r.id == ia);
            let rb = items.iter().find(|r| r.id == ib);
            match (ra, rb) {
                (Some(x), Some(y)) => Ok(json!({ "sections": report::compare_sections(x, y) })),
                _ => Err("select two saved results to compare".to_string()),
            }
        }
        "history.export" => cmd_export(a),
        "history.clear" => {
            let app = need_app()?;
            store::clear_history(&app.files_dir)?;
            Ok(Value::Null)
        }
        "settings.get" => {
            let app = need_app()?;
            let s = match app.settings.lock() {
                Ok(s) => s.clone(),
                Err(e) => e.into_inner().clone(),
            };
            serde_json::to_value(&s).map_err(|e| e.to_string())
        }
        "settings.set" => {
            let app = need_app()?;
            let mut s: Settings = serde_json::from_value(a.clone()).map_err(|e| e.to_string())?;
            s.threads = s.threads.min(64);
            s.iterations = s.iterations.clamp(1, 200);
            s.warmup = s.warmup.min(20);
            s.max_seconds = s.max_seconds.clamp(2.0, 300.0);
            s.cooldown_s = s.cooldown_s.clamp(0.0, 60.0);
            s.max_batt_temp_c = s.max_batt_temp_c.clamp(35.0, 50.0);
            store::save_settings(&app.files_dir, &s)?;
            match app.settings.lock() {
                Ok(mut g) => *g = s.clone(),
                Err(e) => *e.into_inner() = s.clone(),
            }
            serde_json::to_value(&s).map_err(|e| e.to_string())
        }
        "log.recent" => Ok(json!({ "lines": lab_core::log::recent(120) })),
        _ => Err(format!("unknown command '{}'", cmd)),
    }
}

fn cmd_init(a: &Value) -> Result<Value, String> {
    let dir = get_str(a, "files_dir").ok_or_else(|| "files_dir is required".to_string())?;
    state::init(&dir);
    Ok(json!({ "version": env!("CARGO_PKG_VERSION"), "arch": std::env::consts::ARCH }))
}

fn st_str(st: &Value, key: &str, prop: &str) -> String {
    st.get(key)
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
        .or_else(|| sysinfo::sysprop(prop))
        .unwrap_or_default()
}

fn device_json() -> Value {
    let st = platform::static_info();
    json!({
        "model": st_str(&st, "model", "ro.product.model"),
        "android": st_str(&st, "release", "ro.build.version.release"),
        "sdk": st_str(&st, "sdk", "ro.build.version.sdk"),
        "cpu": sysinfo::cpu_summary(),
        "ram_mb": sysinfo::mem_total_kb().map(|k| k / 1024),
    })
}

fn gpu_json(ctx: &Option<GpuContext>) -> Value {
    match ctx {
        Some(c) => json!({
            "name": c.info.name,
            "backend": c.info.backend,
            "driver": format!("{} {}", c.info.driver, c.info.driver_info).trim(),
            "vendor": c.info.vendor,
            "device_type": c.info.device_type,
            "software": c.info.is_software,
            "timestamps": c.timestamps,
            "init_ms": c.init_ms,
        }),
        None => Value::Null,
    }
}

/// Returns the GPU context for `pref_id`, creating (or re-creating) it when needed.
fn ensure_gpu(app: &App, pref_id: &str) -> (Option<GpuContext>, Option<String>) {
    let want = BackendPref::parse(pref_id);
    let mut slot = lock_gpu(app);
    if slot.ctx.is_some() && slot.pref == want {
        return (slot.ctx.clone(), None);
    }
    match GpuContext::new(want) {
        Ok(ctx) => {
            slot.ctx = Some(ctx.clone());
            slot.error = None;
            slot.pref = want;
            (Some(ctx), None)
        }
        Err(e) => {
            slot.ctx = None;
            slot.error = Some(e.clone());
            slot.pref = want;
            (None, Some(e))
        }
    }
}

fn probes(app: &App) -> Arc<driver_detection::ProbeBundle> {
    if let Ok(g) = app.probes.lock() {
        if let Some(p) = g.as_ref() {
            return p.clone();
        }
    }
    let p = Arc::new(driver_detection::probe_all());
    if let Ok(mut g) = app.probes.lock() {
        *g = Some(p.clone());
    }
    p
}

fn cmd_gpu_report() -> Result<Value, String> {
    let app = need_app()?;
    // fresh probe every time the report is requested
    let fresh = Arc::new(driver_detection::probe_all());
    if let Ok(mut g) = app.probes.lock() {
        *g = Some(fresh.clone());
    }
    let pref_id = lock_gpu(app).pref.id().to_string();
    let (ctx, err) = ensure_gpu(app, &pref_id);
    let info = ctx.as_ref().map(|c| c.info.clone());
    let init_ms = ctx.as_ref().map(|c| c.init_ms);
    let sections = driver_detection::gpu_sections(&fresh, info.as_ref(), err.as_deref(), init_ms);
    Ok(json!({ "sections": sections }))
}

fn cmd_drivers_report() -> Result<Value, String> {
    let app = need_app()?;
    let p = probes(app);
    let (info, pref_id) = {
        let slot = lock_gpu(app);
        (slot.ctx.as_ref().map(|c| c.info.clone()), slot.pref.id().to_string())
    };
    let sections = driver_detection::driver_sections(&p, &platform::static_info(), &pref_id, info.as_ref());
    Ok(json!({ "sections": sections, "pref": pref_id }))
}

fn cmd_backend(a: &Value) -> Result<Value, String> {
    let app = need_app()?;
    if app.running.load(Ordering::SeqCst) {
        return Err("Stop the running benchmark before changing the backend".to_string());
    }
    let pref_id = get_str(a, "backend").unwrap_or_else(|| "auto".to_string());
    let pref = BackendPref::parse(&pref_id);
    let t0 = Instant::now();
    let mut rows = vec![row("Requested backend", pref_id.clone(), MEASURED)];
    let ok;
    match GpuContext::new(pref) {
        Ok(ctx) => {
            ok = true;
            rows.push(row(
                "Result",
                "initialized: a real compute kernel ran on it and its output was verified",
                MEASURED,
            ));
            rows.push(row("Backend", ctx.info.backend.clone(), MEASURED));
            rows.push(row("GPU", ctx.info.name.clone(), MEASURED));
            rows.push(row(
                "Processor type",
                if ctx.info.is_software { "CPU software rendering" } else { "Hardware GPU" },
                MEASURED,
            ));
            rows.push(row("Initialization time", format!("{:.0} ms", t0.elapsed().as_secs_f64() * 1000.0), MEASURED));
            let mut slot = lock_gpu(app);
            slot.ctx = Some(ctx);
            slot.error = None;
            slot.pref = pref;
        }
        Err(e) => {
            ok = false;
            rows.push(row("Result", format!("FAILED: {}", e), UNAVAILABLE));
            rows.push(row(
                "Active backend",
                "unchanged (the previous working backend stays active if there was one)",
                MEASURED,
            ));
        }
    }
    Ok(json!({ "ok": ok, "pref": pref.id(), "sections": [section("Backend verification", rows)] }))
}

fn cmd_catalog() -> Value {
    let workloads: Vec<Value> = hybrid_engine::catalog()
        .iter()
        .map(|c| {
            json!({
                "id": c.id,
                "name": c.name,
                "description": c.description,
                "scales": c.scales,
                "default_scale": c.default_scale,
            })
        })
        .collect();
    let dists: Vec<Value> = [
        hybrid_engine::Distribution::Auto,
        hybrid_engine::Distribution::Balanced,
        hybrid_engine::Distribution::CpuPriority,
        hybrid_engine::Distribution::GpuPriority,
        hybrid_engine::Distribution::Cpu25,
        hybrid_engine::Distribution::Cpu50,
        hybrid_engine::Distribution::Cpu75,
        hybrid_engine::Distribution::Custom,
    ]
    .iter()
    .map(|d| json!({ "id": d.id(), "label": d.label() }))
    .collect();
    json!({
        "workloads": workloads,
        "distributions": dists,
        "backends": [
            { "id": "auto", "label": "Automatic (Vulkan, then OpenGL ES)" },
            { "id": "vulkan", "label": "Vulkan" },
            { "id": "gles", "label": "OpenGL ES" }
        ],
        "cores": std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1),
    })
}

fn cmd_bench_start(a: &Value) -> Result<Value, String> {
    let app = need_app()?;
    let mut cfg: BenchConfig = serde_json::from_value(a.clone()).map_err(|e| format!("bad configuration: {}", e))?;
    cfg.scale = cfg.scale.min(3);
    cfg.iterations = cfg.iterations.clamp(1, 200);
    cfg.warmup = cfg.warmup.min(20);
    cfg.threads = cfg.threads.min(64);
    cfg.max_seconds = cfg.max_seconds.clamp(2.0, 300.0);
    cfg.cooldown_s = cfg.cooldown_s.clamp(0.0, 60.0);
    cfg.max_batt_temp_c = cfg.max_batt_temp_c.clamp(35.0, 50.0);
    cfg.custom_cpu_pct = cfg.custom_cpu_pct.clamp(0.0, 100.0);
    if cfg.modes.is_empty() {
        return Err("select at least one mode".to_string());
    }
    if app
        .running
        .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
        .is_err()
    {
        return Err("A benchmark is already running".to_string());
    }
    app.stop.store(false, Ordering::SeqCst);
    app.custom_permille.store((cfg.custom_cpu_pct * 10.0).round() as u32, Ordering::Relaxed);
    if let Ok(mut p) = app.progress.lock() {
        *p = Progress {
            running: true,
            phase: "Starting".to_string(),
            ..Default::default()
        };
    }
    let spawned = std::thread::Builder::new().name("benchmark".to_string()).spawn(move || {
        let app = match state::app() {
            Some(a) => a,
            None => return,
        };
        let res = std::panic::catch_unwind(AssertUnwindSafe(|| run_bench(app, &cfg)));
        if let Ok(mut p) = app.progress.lock() {
            match res {
                Ok(Ok(id)) => {
                    p.result_id = Some(id);
                    p.phase = "Finished".to_string();
                    p.fraction = 1.0;
                }
                Ok(Err(e)) => {
                    p.error = Some(e);
                    p.phase = "Failed".to_string();
                }
                Err(_) => {
                    p.error = Some("internal error (panic) - see the log".to_string());
                    p.phase = "Failed".to_string();
                }
            }
            p.running = false;
            p.message = String::new();
        }
        app.running.store(false, Ordering::SeqCst);
    });
    if let Err(e) = spawned {
        app.running.store(false, Ordering::SeqCst);
        return Err(format!("cannot start benchmark thread: {}", e));
    }
    Ok(Value::Null)
}

fn run_bench(app: &'static App, cfg: &BenchConfig) -> Result<String, String> {
    let needs_gpu = cfg.modes.iter().any(|m| m == "gpu" || m == "hybrid");
    let (mut gpu, mut gpu_err) = (None, None);
    if needs_gpu {
        if let Ok(mut p) = app.progress.lock() {
            p.phase = "Initializing GPU backend".to_string();
            p.message = "Creating the device and running a verification kernel".to_string();
        }
        let r = ensure_gpu(app, &cfg.backend);
        gpu = r.0;
        gpu_err = r.1;
    }
    let env = SessionEnv {
        gpu_info: gpu_json(&gpu),
        gpu,
        gpu_error: gpu_err,
        device: device_json(),
        progress: app.progress.clone(),
        stop: app.stop.clone(),
        custom_permille: app.custom_permille.clone(),
    };
    let result = benchmark::run_session(cfg, &env)?;
    if let Err(e) = store::append_history(&app.files_dir, &result) {
        lab_core::lab_warn!("could not save history: {}", e);
    }
    Ok(result.id)
}

fn cmd_export(a: &Value) -> Result<Value, String> {
    let app = need_app()?;
    let format = get_str(a, "format").unwrap_or_else(|| "json".to_string());
    let mut items = store::load_history(&app.files_dir);
    if let Some(ids) = a.get("ids").and_then(|v| v.as_array()) {
        let wanted: Vec<String> = ids.iter().filter_map(|v| v.as_str().map(|s| s.to_string())).collect();
        if !wanted.is_empty() {
            items.retain(|r| wanted.contains(&r.id));
        }
    }
    if items.is_empty() {
        return Err("there are no saved results to export yet".to_string());
    }
    let (name, mime, content) = if format == "csv" {
        (format!("graphicslab-results-{}.csv", unix_ms()), "text/csv", report::to_csv(&items))
    } else {
        (format!("graphicslab-results-{}.json", unix_ms()), "application/json", report::to_json(&items))
    };
    Ok(json!({ "name": name, "mime": mime, "content": content, "count": items.len() }))
}

fn cmd_dashboard() -> Result<Value, String> {
    let app = need_app()?;
    let snap = platform::snapshot();
    let mut sections: Vec<Value> = Vec::new();

    // ---- graphics
    let mut g: Vec<Value> = Vec::new();
    let active = app
        .gpu
        .try_lock()
        .ok()
        .and_then(|slot| slot.ctx.as_ref().map(|c| (c.info.clone(), c.timestamps)));
    match active {
        Some((info, ts)) => {
            g.push(row("GPU", info.name.clone(), MEASURED));
            g.push(row("Active rendering/compute backend", info.backend.clone(), MEASURED));
            g.push(row(
                "Processor type",
                if info.is_software { "CPU software rendering" } else { "Hardware GPU" },
                MEASURED,
            ));
            g.push(row("GPU timestamps", if ts { "supported" } else { "not supported" }, MEASURED));
        }
        None => {
            let cached = app.probes.try_lock().ok().and_then(|p| p.clone());
            match cached {
                Some(p) => {
                    let name = p
                        .vulkan
                        .devices
                        .first()
                        .map(|d| d.name.clone())
                        .or_else(|| if p.gles.available { Some(p.gles.gl_renderer.clone()) } else { None });
                    match name {
                        Some(n) => g.push(row("GPU", n, MEASURED)),
                        None => g.push(row("GPU", "not detected", UNAVAILABLE)),
                    }
                    g.push(row("Active backend", "not initialised yet (starts with the first GPU test)", UNAVAILABLE));
                }
                None => {
                    g.push(row("GPU", "detecting... open Device Info or Graphics Drivers", UNAVAILABLE));
                }
            }
        }
    }
    g.push(row(
        "Current FPS",
        "not measured yet (the rendering benchmark with FPS arrives in Stage 5)",
        UNAVAILABLE,
    ));
    sections.push(section("Graphics", g));

    // ---- processor
    let mut c: Vec<Value> = Vec::new();
    c.push(row("CPU", sysinfo::cpu_summary(), MEASURED));
    let gpu_state = {
        let slot = app.gpu.try_lock();
        match slot {
            Ok(s) => {
                if s.ctx.is_some() {
                    "ready".to_string()
                } else if let Some(e) = &s.error {
                    format!("unavailable ({})", e)
                } else {
                    "not initialised".to_string()
                }
            }
            Err(_) => "initialising".to_string(),
        }
    };
    let running = app.running.load(Ordering::SeqCst);
    c.push(row("CPU status", if running { "benchmark running" } else { "idle" }, MEASURED));
    c.push(row("GPU status", gpu_state, MEASURED));
    sections.push(section("Processors", c));

    // ---- device status
    let mut s: Vec<Value> = Vec::new();
    match snap.battery_temp_c {
        Some(t) => s.push(row("Battery temperature", format!("{:.1} C", t), MEASURED)),
        None => s.push(row("Battery temperature", "waiting for platform data", UNAVAILABLE)),
    }
    if let Some(t) = snap.thermal_status {
        s.push(row("Thermal status", platform::thermal_status_name(t), MEASURED));
    }
    if let Some(k) = sysinfo::mem_available_kb() {
        s.push(row("RAM available", format!("{} MB", k / 1024), MEASURED));
    }
    sections.push(section("Device status", s));

    // ---- latest benchmark
    let history = store::load_history(&app.files_dir);
    let mut l: Vec<Value> = Vec::new();
    match history.last() {
        Some(r) => {
            l.push(row("Workload", r.workload.name.clone(), MEASURED));
            for m in &r.modes {
                let valid = if m.iterations == 0 {
                    "no data"
                } else if m.validation.ok {
                    "output verified"
                } else {
                    "VALIDATION FAILED"
                };
                l.push(row(&m.label, format!("{:.2} ms avg - {}", m.total_ms.mean, valid), MEASURED));
            }
            let single = r
                .modes
                .iter()
                .filter(|m| m.mode != "hybrid" && m.total_ms.mean > 0.0)
                .map(|m| m.total_ms.mean)
                .fold(f64::MAX, f64::min);
            if let Some(h) = r.modes.iter().find(|m| m.mode == "hybrid" && m.total_ms.mean > 0.0) {
                if single < f64::MAX {
                    l.push(row(
                        "Hybrid vs best single processor",
                        format!("{:.2}x", single / h.total_ms.mean),
                        MEASURED,
                    ));
                }
            }
        }
        None => l.push(row("Latest benchmark", "none yet - run one from the CPU, GPU or Hybrid screen", UNAVAILABLE)),
    }
    sections.push(section("Latest benchmark result", l));
    Ok(json!({ "sections": sections }))
}
