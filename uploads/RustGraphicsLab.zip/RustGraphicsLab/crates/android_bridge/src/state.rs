//! Process-wide application state (created once by `app.init`).
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU32};
use std::sync::{Arc, Mutex, OnceLock};

use benchmark::{Monitor, Progress, Settings};
use driver_detection::ProbeBundle;
use gpu_engine::{BackendPref, GpuContext};

pub struct GpuSlot {
    pub ctx: Option<GpuContext>,
    pub error: Option<String>,
    pub pref: BackendPref,
}

pub struct App {
    pub files_dir: PathBuf,
    pub gpu: Mutex<GpuSlot>,
    pub probes: Mutex<Option<Arc<ProbeBundle>>>,
    pub progress: Arc<Mutex<Progress>>,
    pub stop: Arc<AtomicBool>,
    pub custom_permille: Arc<AtomicU32>,
    /// True while the benchmark thread is alive.
    pub running: AtomicBool,
    pub monitor: Mutex<Monitor>,
    pub settings: Mutex<Settings>,
}

static APP: OnceLock<App> = OnceLock::new();

pub fn init(files_dir: &str) -> &'static App {
    APP.get_or_init(|| {
        let dir = PathBuf::from(files_dir);
        let _ = std::fs::create_dir_all(&dir);
        let settings = benchmark::store::load_settings(&dir);
        App {
            files_dir: dir,
            gpu: Mutex::new(GpuSlot {
                ctx: None,
                error: None,
                pref: BackendPref::Auto,
            }),
            probes: Mutex::new(None),
            progress: Arc::new(Mutex::new(Progress::default())),
            stop: Arc::new(AtomicBool::new(false)),
            custom_permille: Arc::new(AtomicU32::new(400)),
            running: AtomicBool::new(false),
            monitor: Mutex::new(Monitor::new()),
            settings: Mutex::new(settings),
        }
    })
}

pub fn app() -> Option<&'static App> {
    APP.get()
}
