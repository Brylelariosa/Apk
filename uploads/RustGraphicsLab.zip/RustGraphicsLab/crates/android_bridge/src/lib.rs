//! JNI entry point. The Kotlin shell talks to Rust through one function:
//! `Native.call(command, argsJson) -> responseJson`. All logic lives in the other crates.
mod dispatch;
mod state;

use jni::objects::{JClass, JString};
use jni::sys::{jint, jstring, JNI_VERSION_1_6};
use jni::JNIEnv;

#[no_mangle]
pub extern "system" fn JNI_OnLoad(_vm: *mut jni::sys::JavaVM, _reserved: *mut std::ffi::c_void) -> jint {
    lab_core::log::install_panic_hook();
    lab_core::lab_log!("libgraphicslab loaded (version {})", env!("CARGO_PKG_VERSION"));
    JNI_VERSION_1_6
}

#[no_mangle]
pub extern "system" fn Java_com_graphicslab_app_Native_call<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    command: JString<'local>,
    args: JString<'local>,
) -> jstring {
    let cmd: String = env.get_string(&command).map(|s| s.into()).unwrap_or_default();
    let arg: String = env.get_string(&args).map(|s| s.into()).unwrap_or_default();
    let out = std::panic::catch_unwind(|| dispatch::handle(&cmd, &arg))
        .unwrap_or_else(|_| "{\"ok\":false,\"error\":\"internal error (panic) - see the log\"}".to_string());
    match env.new_string(out) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}
