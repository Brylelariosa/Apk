//! Descriptive statistics for benchmark samples.
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Stats {
    pub count: usize,
    pub min: f64,
    pub max: f64,
    pub mean: f64,
    pub median: f64,
    pub stddev: f64,
    pub p95: f64,
}

impl Stats {
    pub fn from_samples(samples: &[f64]) -> Stats {
        let mut s: Vec<f64> = samples.iter().cloned().filter(|v| v.is_finite()).collect();
        if s.is_empty() {
            return Stats::default();
        }
        s.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let n = s.len();
        let mean = s.iter().sum::<f64>() / n as f64;
        let var = s.iter().map(|v| (v - mean) * (v - mean)).sum::<f64>() / n as f64;
        let median = if n % 2 == 1 {
            s[n / 2]
        } else {
            0.5 * (s[n / 2 - 1] + s[n / 2])
        };
        let p95 = s[((n as f64 - 1.0) * 0.95).round() as usize];
        Stats {
            count: n,
            min: s[0],
            max: s[n - 1],
            mean,
            median,
            stddev: var.sqrt(),
            p95,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic_stats() {
        let s = Stats::from_samples(&[1.0, 2.0, 3.0, 4.0]);
        assert_eq!(s.count, 4);
        assert_eq!(s.min, 1.0);
        assert_eq!(s.max, 4.0);
        assert!((s.mean - 2.5).abs() < 1e-12);
        assert!((s.median - 2.5).abs() < 1e-12);
    }

    #[test]
    fn empty_is_default() {
        assert_eq!(Stats::from_samples(&[]).count, 0);
    }
}
