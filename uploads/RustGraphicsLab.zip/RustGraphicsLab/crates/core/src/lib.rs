//! Shared helpers: logging, timing, statistics, platform state and system probing.
pub mod log;
pub mod platform;
pub mod stats;
pub mod sysinfo;
pub mod util;
