//! Values that only Android platform APIs can provide (battery, thermal status, ...).
//! The Kotlin shell pushes them in; Rust never assumes they exist.
use serde_json::Value;
use std::sync::RwLock;
use std::time::Instant;

struct Inner {
    dynamic: Value,
    static_info: Value,
    updated: Option<Instant>,
}

static STATE: RwLock<Inner> = RwLock::new(Inner {
    dynamic: Value::Null,
    static_info: Value::Null,
    updated: None,
});

#[derive(Clone, Debug, Default)]
pub struct PlatformSnapshot {
    /// True when the Kotlin side pushed fresh values in the last few seconds.
    pub fresh: bool,
    pub battery_temp_c: Option<f64>,
    /// android.os.PowerManager thermal status: 0 none .. 6 shutdown.
    pub thermal_status: Option<i64>,
    pub battery_level: Option<i64>,
    pub current_ua: Option<i64>,
    pub voltage_mv: Option<i64>,
    pub low_memory: bool,
    pub avail_mem_mb: Option<i64>,
}

pub fn update(v: &Value) {
    if let Ok(mut s) = STATE.write() {
        s.dynamic = v.clone();
        s.updated = Some(Instant::now());
    }
}

pub fn set_static(v: Value) {
    if let Ok(mut s) = STATE.write() {
        s.static_info = v;
    }
}

pub fn static_info() -> Value {
    STATE
        .read()
        .map(|s| s.static_info.clone())
        .unwrap_or(Value::Null)
}

pub fn snapshot() -> PlatformSnapshot {
    let guard = match STATE.read() {
        Ok(g) => g,
        Err(_) => return PlatformSnapshot::default(),
    };
    let fresh = guard
        .updated
        .map(|t| t.elapsed().as_secs() < 8)
        .unwrap_or(false);
    if !fresh {
        return PlatformSnapshot::default();
    }
    let d = &guard.dynamic;
    PlatformSnapshot {
        fresh: true,
        battery_temp_c: d.get("battery_temp_c").and_then(|v| v.as_f64()),
        thermal_status: d.get("thermal_status").and_then(|v| v.as_i64()),
        battery_level: d.get("battery_level").and_then(|v| v.as_i64()),
        current_ua: d.get("current_ua").and_then(|v| v.as_i64()),
        voltage_mv: d.get("voltage_mv").and_then(|v| v.as_i64()),
        low_memory: d.get("low_memory").and_then(|v| v.as_bool()).unwrap_or(false),
        avail_mem_mb: d.get("avail_mem_mb").and_then(|v| v.as_i64()),
    }
}

pub fn thermal_status_name(s: i64) -> &'static str {
    match s {
        0 => "None",
        1 => "Light",
        2 => "Moderate",
        3 => "Severe",
        4 => "Critical",
        5 => "Emergency",
        6 => "Shutdown",
        _ => "Unknown",
    }
}
