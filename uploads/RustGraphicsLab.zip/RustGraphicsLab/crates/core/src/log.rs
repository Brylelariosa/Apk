//! Tiny logger: ring buffer for the in-app log + Android logcat when available.
use std::collections::VecDeque;
use std::sync::Mutex;

static RING: Mutex<VecDeque<String>> = Mutex::new(VecDeque::new());

pub fn log_line(level: &str, msg: &str) {
    if let Ok(mut r) = RING.lock() {
        if r.len() >= 300 {
            r.pop_front();
        }
        r.push_back(format!("[{}] {}", level, msg));
    }
    platform_write(level, msg);
}

/// Most recent log lines (oldest first).
pub fn recent(max: usize) -> Vec<String> {
    match RING.lock() {
        Ok(r) => {
            let skip = r.len().saturating_sub(max);
            r.iter().skip(skip).cloned().collect()
        }
        Err(_) => Vec::new(),
    }
}

#[cfg(target_os = "android")]
fn platform_write(level: &str, msg: &str) {
    use std::ffi::CString;
    use std::os::raw::{c_char, c_int};
    #[link(name = "log")]
    extern "C" {
        fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }
    let prio = match level {
        "E" => 6,
        "W" => 5,
        "D" => 3,
        _ => 4,
    };
    let tag = CString::new("GraphicsLab").unwrap_or_default();
    let text = CString::new(msg.replace('\0', " ")).unwrap_or_default();
    unsafe {
        __android_log_write(prio, tag.as_ptr(), text.as_ptr());
    }
}

#[cfg(not(target_os = "android"))]
fn platform_write(level: &str, msg: &str) {
    eprintln!("[{}] {}", level, msg);
}

/// Routes Rust panics into the log instead of silently aborting.
pub fn install_panic_hook() {
    std::panic::set_hook(Box::new(|info| {
        log_line("E", &format!("panic: {}", info));
    }));
}

#[macro_export]
macro_rules! lab_log {
    ($($arg:tt)*) => { $crate::log::log_line("I", &format!($($arg)*)) };
}

#[macro_export]
macro_rules! lab_warn {
    ($($arg:tt)*) => { $crate::log::log_line("W", &format!($($arg)*)) };
}
