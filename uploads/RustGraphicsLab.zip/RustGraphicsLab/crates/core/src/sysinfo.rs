//! Hardware / OS probing through /proc, /sys and Android system properties.
//! Everything is best-effort: anything the OS hides is reported as unavailable, never guessed.
use serde_json::Value;
use std::collections::BTreeMap;
use std::fs;

use crate::platform;
use crate::util::{human_bytes, row, section, ESTIMATED, MEASURED, UNAVAILABLE};

pub fn read_trim(path: &str) -> Option<String> {
    fs::read_to_string(path).ok().map(|s| s.trim().to_string())
}

#[cfg(target_os = "android")]
pub fn sysprop(name: &str) -> Option<String> {
    use std::ffi::CString;
    use std::os::raw::{c_char, c_int};
    extern "C" {
        fn __system_property_get(name: *const c_char, value: *mut c_char) -> c_int;
    }
    let cname = CString::new(name).ok()?;
    let mut buf = [0 as c_char; 96];
    let n = unsafe { __system_property_get(cname.as_ptr(), buf.as_mut_ptr()) };
    if n <= 0 {
        return None;
    }
    let bytes: Vec<u8> = buf.iter().take_while(|&&c| c != 0).map(|&c| c as u8).collect();
    let s = String::from_utf8_lossy(&bytes).to_string();
    if s.is_empty() {
        None
    } else {
        Some(s)
    }
}

#[cfg(not(target_os = "android"))]
pub fn sysprop(_name: &str) -> Option<String> {
    None
}

fn parse_hex(s: &str) -> Option<u32> {
    u32::from_str_radix(s.trim().trim_start_matches("0x"), 16).ok()
}

/// Known ARM core part numbers (implementer 0x41).
pub fn arm_part_name(implementer: u32, part: u32) -> Option<&'static str> {
    if implementer != 0x41 {
        return None;
    }
    Some(match part {
        0xd03 => "Cortex-A53",
        0xd04 => "Cortex-A35",
        0xd05 => "Cortex-A55",
        0xd07 => "Cortex-A57",
        0xd08 => "Cortex-A72",
        0xd09 => "Cortex-A73",
        0xd0a => "Cortex-A75",
        0xd0b => "Cortex-A76",
        0xd0d => "Cortex-A77",
        0xd41 => "Cortex-A78",
        0xd44 => "Cortex-X1",
        0xd46 => "Cortex-A510",
        0xd47 => "Cortex-A710",
        0xd48 => "Cortex-X2",
        0xd4d => "Cortex-A715",
        0xd4e => "Cortex-X3",
        0xd80 => "Cortex-A520",
        0xd81 => "Cortex-A720",
        0xd82 => "Cortex-X4",
        _ => return None,
    })
}

#[derive(Clone, Debug, Default)]
pub struct CpuInfo {
    pub logical_cores: usize,
    pub hardware: String,
    pub features: Vec<String>,
    /// One entry per logical core, in index order.
    pub core_names: Vec<String>,
}

pub fn cpu_info() -> CpuInfo {
    let text = fs::read_to_string("/proc/cpuinfo").unwrap_or_default();
    let mut parts: Vec<(Option<u32>, Option<u32>)> = Vec::new();
    let mut hardware = String::new();
    let mut features = String::new();
    let mut model_name = String::new();
    for line in text.lines() {
        let mut it = line.splitn(2, ':');
        let key = it.next().unwrap_or("").trim();
        let val = it.next().unwrap_or("").trim();
        match key {
            "processor" => parts.push((None, None)),
            "CPU implementer" => {
                if let Some(p) = parts.last_mut() {
                    p.0 = parse_hex(val);
                }
            }
            "CPU part" => {
                if let Some(p) = parts.last_mut() {
                    p.1 = parse_hex(val);
                }
            }
            "Hardware" => hardware = val.to_string(),
            "Features" => {
                if features.is_empty() {
                    features = val.to_string();
                }
            }
            "model name" | "Processor" => {
                if model_name.is_empty() {
                    model_name = val.to_string();
                }
            }
            _ => {}
        }
    }
    let logical = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(parts.len().max(1));
    let core_names: Vec<String> = parts
        .iter()
        .map(|(i, p)| match (i, p) {
            (Some(i), Some(p)) => arm_part_name(*i, *p)
                .map(|s| s.to_string())
                .unwrap_or_else(|| format!("impl 0x{:x} part 0x{:x}", i, p)),
            _ => "unknown".to_string(),
        })
        .collect();
    let hw = if !hardware.is_empty() { hardware } else { model_name };
    CpuInfo {
        logical_cores: logical,
        hardware: hw,
        features: features.split_whitespace().map(|s| s.to_string()).collect(),
        core_names,
    }
}

fn core_layout(names: &[String]) -> String {
    let mut groups: Vec<(String, usize)> = Vec::new();
    for n in names {
        if let Some(g) = groups.iter_mut().find(|g| &g.0 == n) {
            g.1 += 1;
        } else {
            groups.push((n.clone(), 1));
        }
    }
    groups
        .iter()
        .map(|(n, c)| format!("{}x {}", c, n))
        .collect::<Vec<_>>()
        .join(", ")
}

/// `kind` is "cpuinfo_max_freq" or "scaling_cur_freq".
pub fn cpu_freq_khz(core: usize, kind: &str) -> Option<u64> {
    read_trim(&format!("/sys/devices/system/cpu/cpu{}/cpufreq/{}", core, kind))
        .and_then(|s| s.parse::<u64>().ok())
}

pub fn meminfo() -> BTreeMap<String, u64> {
    let mut m = BTreeMap::new();
    if let Ok(t) = fs::read_to_string("/proc/meminfo") {
        for line in t.lines() {
            let mut it = line.splitn(2, ':');
            if let (Some(k), Some(v)) = (it.next(), it.next()) {
                let num = v.trim().split_whitespace().next().and_then(|x| x.parse::<u64>().ok());
                if let Some(n) = num {
                    m.insert(k.trim().to_string(), n);
                }
            }
        }
    }
    m
}

pub fn mem_total_kb() -> Option<u64> {
    meminfo().get("MemTotal").cloned()
}

pub fn mem_available_kb() -> Option<u64> {
    meminfo().get("MemAvailable").cloned()
}

fn status_kb(key: &str) -> Option<u64> {
    let t = fs::read_to_string("/proc/self/status").ok()?;
    for line in t.lines() {
        if let Some(rest) = line.strip_prefix(key) {
            return rest
                .trim_start_matches(':')
                .trim()
                .split_whitespace()
                .next()?
                .parse::<u64>()
                .ok();
        }
    }
    None
}

pub fn process_rss_kb() -> Option<u64> {
    status_kb("VmRSS")
}

pub fn process_peak_rss_kb() -> Option<u64> {
    status_kb("VmHWM")
}

/// CPU seconds consumed by this process so far (all threads).
pub fn process_cpu_seconds() -> f64 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    let r = unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) };
    if r != 0 {
        return 0.0;
    }
    ts.tv_sec as f64 + ts.tv_nsec as f64 / 1e9
}

pub fn thermal_zones() -> Vec<(String, f64)> {
    let mut out = Vec::new();
    if let Ok(rd) = fs::read_dir("/sys/class/thermal") {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if !name.starts_with("thermal_zone") {
                continue;
            }
            let base = format!("/sys/class/thermal/{}", name);
            let ty = read_trim(&format!("{}/type", base)).unwrap_or_else(|| name.clone());
            if let Some(t) = read_trim(&format!("{}/temp", base)).and_then(|s| s.parse::<f64>().ok()) {
                let c = if t.abs() >= 1000.0 { t / 1000.0 } else { t };
                out.push((ty, c));
            }
        }
    }
    out
}

/// One-line CPU description for the dashboard.
pub fn cpu_summary() -> String {
    let ci = cpu_info();
    let layout = core_layout(&ci.core_names);
    let soc = sysprop("ro.soc.model")
        .or_else(|| sysprop("ro.board.platform"))
        .or_else(|| sysprop("ro.hardware"))
        .unwrap_or_else(|| ci.hardware.clone());
    let mut s = format!("{} cores", ci.logical_cores);
    if !layout.is_empty() && !layout.contains("unknown") {
        s.push_str(&format!(" ({})", layout));
    }
    if !soc.is_empty() {
        s.push_str(&format!(", {}", soc));
    }
    s
}

fn jstr(v: &Value, k: &str) -> Option<String> {
    v.get(k).and_then(|x| match x {
        Value::String(s) => Some(s.clone()),
        Value::Number(n) => Some(n.to_string()),
        Value::Bool(b) => Some(b.to_string()),
        _ => None,
    })
}

fn opt_row(label: &str, v: Option<String>) -> Value {
    match v {
        Some(s) => row(label, s, MEASURED),
        None => row(label, "not exposed by this device", UNAVAILABLE),
    }
}

/// UI sections for the Device Information screen.
pub fn device_sections() -> Vec<Value> {
    let ci = cpu_info();
    let st = platform::static_info();
    let snap = platform::snapshot();
    let mut out = Vec::new();

    // ---- System
    let mut sys = Vec::new();
    sys.push(opt_row("Manufacturer", jstr(&st, "manufacturer").or_else(|| sysprop("ro.product.manufacturer"))));
    sys.push(opt_row("Model", jstr(&st, "model").or_else(|| sysprop("ro.product.model"))));
    sys.push(opt_row("Device", jstr(&st, "device").or_else(|| sysprop("ro.product.device"))));
    sys.push(opt_row("Android", jstr(&st, "release").or_else(|| sysprop("ro.build.version.release"))));
    sys.push(opt_row("API level", jstr(&st, "sdk").or_else(|| sysprop("ro.build.version.sdk"))));
    sys.push(opt_row("Security patch", jstr(&st, "patch").or_else(|| sysprop("ro.build.version.security_patch"))));
    sys.push(opt_row("Supported ABIs", jstr(&st, "abis").or_else(|| sysprop("ro.product.cpu.abilist"))));
    sys.push(opt_row("Display", jstr(&st, "display")));
    out.push(section("System", sys));

    // ---- CPU
    let mut cpu = Vec::new();
    cpu.push(row("Architecture", std::env::consts::ARCH, MEASURED));
    cpu.push(row("Logical cores", ci.logical_cores, MEASURED));
    let layout = core_layout(&ci.core_names);
    if layout.is_empty() || layout.contains("unknown") {
        cpu.push(row("Core layout", "not exposed (cpuinfo hides core IDs)", UNAVAILABLE));
    } else {
        cpu.push(row("Core layout", layout, MEASURED));
    }
    let soc = sysprop("ro.soc.manufacturer")
        .map(|m| format!("{} {}", m, sysprop("ro.soc.model").unwrap_or_default()))
        .or_else(|| sysprop("ro.board.platform"))
        .or_else(|| sysprop("ro.hardware"))
        .or_else(|| jstr(&st, "hardware"))
        .or_else(|| if ci.hardware.is_empty() { None } else { Some(ci.hardware.clone()) });
    cpu.push(opt_row("SoC / platform", soc));
    let mut maxf = Vec::new();
    let mut curf = Vec::new();
    for i in 0..ci.logical_cores {
        if let Some(k) = cpu_freq_khz(i, "cpuinfo_max_freq") {
            maxf.push(format!("cpu{} {} MHz", i, k / 1000));
        }
        if let Some(k) = cpu_freq_khz(i, "scaling_cur_freq") {
            curf.push(format!("cpu{} {} MHz", i, k / 1000));
        }
    }
    if maxf.is_empty() {
        cpu.push(row("Max frequency", "not readable by apps on this device", UNAVAILABLE));
    } else {
        cpu.push(row("Max frequency", maxf.join(", "), MEASURED));
    }
    if !curf.is_empty() {
        cpu.push(row("Current frequency (now)", curf.join(", "), MEASURED));
    }
    let has = |f: &str| ci.features.iter().any(|x| x == f);
    let neon = cfg!(target_arch = "aarch64") || has("neon") || has("asimd");
    cpu.push(row("NEON / AdvSIMD", if neon { "yes" } else { "no" }, MEASURED));
    if !ci.features.is_empty() {
        cpu.push(row("fp16 vector (asimdhp)", if has("asimdhp") { "yes" } else { "no" }, MEASURED));
        cpu.push(row("Dot product (asimddp)", if has("asimddp") { "yes" } else { "no" }, MEASURED));
        cpu.push(row("Atomics (LSE)", if has("atomics") { "yes" } else { "no" }, MEASURED));
    }
    out.push(section("CPU", cpu));

    // ---- Memory
    let mut mem = Vec::new();
    match mem_total_kb() {
        Some(k) => mem.push(row("RAM total", human_bytes(k * 1024), MEASURED)),
        None => mem.push(row("RAM total", "not readable", UNAVAILABLE)),
    }
    match mem_available_kb() {
        Some(k) => mem.push(row("RAM available", human_bytes(k * 1024), MEASURED)),
        None => mem.push(row("RAM available", "not readable", UNAVAILABLE)),
    }
    if let Some(k) = process_rss_kb() {
        mem.push(row("This app (resident)", human_bytes(k * 1024), MEASURED));
    }
    if let Some(k) = process_peak_rss_kb() {
        mem.push(row("This app (peak resident)", human_bytes(k * 1024), MEASURED));
    }
    out.push(section("Memory", mem));

    // ---- Thermal / power
    let mut th = Vec::new();
    match snap.battery_temp_c {
        Some(t) => th.push(row("Battery temperature", format!("{:.1} C", t), MEASURED)),
        None => th.push(row("Battery temperature", "waiting for platform data", UNAVAILABLE)),
    }
    match snap.thermal_status {
        Some(s) => th.push(row("Thermal status (Android)", platform::thermal_status_name(s), MEASURED)),
        None => th.push(row("Thermal status (Android)", "not available (needs Android 10+)", UNAVAILABLE)),
    }
    if let Some(l) = snap.battery_level {
        th.push(row("Battery level", format!("{} %", l), MEASURED));
    }
    if let (Some(i), Some(v)) = (snap.current_ua, snap.voltage_mv) {
        if i != 0 {
            let w = (i.abs() as f64 / 1e6) * (v as f64 / 1e3);
            th.push(row("Power draw (battery current x voltage)", format!("{:.2} W", w), ESTIMATED));
        }
    }
    let zones = thermal_zones();
    if zones.is_empty() {
        th.push(row("Thermal zones", "not readable by apps on this device", UNAVAILABLE));
    } else {
        for (name, c) in zones.iter().take(8) {
            th.push(row(&format!("Zone {}", name), format!("{:.1} C", c), MEASURED));
        }
    }
    out.push(section("Thermal and power", th));
    out
}
