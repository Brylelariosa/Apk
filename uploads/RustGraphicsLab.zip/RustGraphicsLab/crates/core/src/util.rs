//! Small shared helpers (timing, byte views, deterministic RNG, UI section builders).
use serde_json::{json, Value};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

/// Tag for values read directly from the device.
pub const MEASURED: &str = "measured";
/// Tag for values derived from measurements.
pub const ESTIMATED: &str = "estimated";
/// Tag for values the device does not expose.
pub const UNAVAILABLE: &str = "unavailable";

pub fn ms_since(t: Instant) -> f64 {
    t.elapsed().as_secs_f64() * 1000.0
}

/// Milliseconds from `a` to `b` (0 if `b` is earlier).
pub fn ms_between(a: Instant, b: Instant) -> f64 {
    b.saturating_duration_since(a).as_secs_f64() * 1000.0
}

pub fn unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

pub fn round_to(v: f64, decimals: i32) -> f64 {
    if !v.is_finite() {
        return v;
    }
    let m = 10f64.powi(decimals);
    (v * m).round() / m
}

pub fn as_bytes_f32(v: &[f32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(v.as_ptr() as *const u8, std::mem::size_of_val(v)) }
}

pub fn as_bytes_u32(v: &[u32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(v.as_ptr() as *const u8, std::mem::size_of_val(v)) }
}

/// Copies little-endian bytes into an f32 slice (as many elements as fit).
pub fn bytes_into_f32(src: &[u8], dst: &mut [f32]) {
    let n = dst.len().min(src.len() / 4);
    unsafe {
        std::ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr() as *mut u8, n * 4);
    }
}

/// Copies little-endian bytes into a u32 slice (as many elements as fit).
pub fn bytes_into_u32(src: &[u8], dst: &mut [u32]) {
    let n = dst.len().min(src.len() / 4);
    unsafe {
        std::ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr() as *mut u8, n * 4);
    }
}

pub fn human_bytes(b: u64) -> String {
    let f = b as f64;
    if f >= 1073741824.0 {
        format!("{:.2} GiB", f / 1073741824.0)
    } else if f >= 1048576.0 {
        format!("{:.1} MiB", f / 1048576.0)
    } else if f >= 1024.0 {
        format!("{:.1} KiB", f / 1024.0)
    } else {
        format!("{} B", b)
    }
}

/// UI row: [label, value, tag].
pub fn row(label: &str, value: impl ToString, tag: &str) -> Value {
    json!([label, value.to_string(), tag])
}

/// UI section with key/value rows.
pub fn section(title: &str, rows: Vec<Value>) -> Value {
    json!({ "title": title, "rows": rows })
}

/// Deterministic 64-bit LCG used to generate identical benchmark inputs everywhere.
pub struct Lcg {
    s: u64,
}

impl Lcg {
    pub fn new(seed: u64) -> Lcg {
        Lcg {
            s: seed
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407),
        }
    }

    pub fn next_u32(&mut self) -> u32 {
        self.s = self
            .s
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        (self.s >> 32) as u32
    }

    /// Uniform in [0, 1).
    pub fn next_f32(&mut self) -> f32 {
        (self.next_u32() >> 8) as f32 / 16777216.0
    }

    /// Uniform in [-1, 1).
    pub fn next_signed(&mut self) -> f32 {
        self.next_f32() * 2.0 - 1.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lcg_is_deterministic_and_in_range() {
        let mut a = Lcg::new(7);
        let mut b = Lcg::new(7);
        for _ in 0..1000 {
            let x = a.next_signed();
            assert_eq!(x, b.next_signed());
            assert!(x >= -1.0 && x < 1.0);
        }
    }

    #[test]
    fn byte_roundtrip() {
        let v = vec![1.5f32, -2.25, 3.0];
        let mut out = vec![0f32; 3];
        bytes_into_f32(as_bytes_f32(&v), &mut out);
        assert_eq!(v, out);
    }
}
