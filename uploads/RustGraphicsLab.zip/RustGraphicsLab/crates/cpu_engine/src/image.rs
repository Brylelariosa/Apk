//! Image workload on packed RGBA8 (u32) pixels: 3x3 Gaussian blur followed by a contrast curve.
//! Pure integer math, so CPU and GPU results must be bit-identical.
use crate::pool::CpuEngine;
use lab_core::util::Lcg;

/// Deterministic test image: smooth gradients plus noise, opaque alpha.
pub fn make_image(w: usize, h: usize, seed: u64) -> Vec<u32> {
    let mut rng = Lcg::new(seed);
    let mut img = vec![0u32; w * h];
    for y in 0..h {
        for x in 0..w {
            let noise = (rng.next_u32() & 63) as u32;
            let r = ((x * 255) / w.max(1)) as u32;
            let g = ((y * 255) / h.max(1)) as u32;
            let b = (((x + y) * 255) / (w + h).max(1)) as u32;
            let r = (r + noise).min(255);
            let g = (g + noise / 2).min(255);
            let b = (b + noise / 3).min(255);
            img[y * w + x] = r | (g << 8) | (b << 16) | 0xFF00_0000;
        }
    }
    img
}

/// Filtered value of a single pixel (edge pixels clamp to the border).
pub fn filter_pixel(src: &[u32], w: usize, h: usize, x: usize, y: usize) -> u32 {
    let (mut r, mut g, mut b) = (0u32, 0u32, 0u32);
    for dy in -1i32..=1 {
        let yy = (y as i32 + dy).clamp(0, h as i32 - 1) as usize;
        for dx in -1i32..=1 {
            let xx = (x as i32 + dx).clamp(0, w as i32 - 1) as usize;
            let wt = ((2 - dx.abs()) * (2 - dy.abs())) as u32;
            let p = src[yy * w + xx];
            r += wt * (p & 255);
            g += wt * ((p >> 8) & 255);
            b += wt * ((p >> 16) & 255);
        }
    }
    let curve = |v: u32| -> u32 {
        let v = ((v + 8) >> 4) as i32;
        let o = ((v - 128) * 3) / 2 + 128;
        o.clamp(0, 255) as u32
    };
    curve(r) | (curve(g) << 8) | (curve(b) << 16) | (src[y * w + x] & 0xFF00_0000)
}

/// Filters rows [y0, y1); `dst` holds exactly those rows (w * (y1 - y0) pixels).
pub fn filter_rows(engine: &CpuEngine, src: &[u32], w: usize, h: usize, y0: usize, y1: usize, dst: &mut [u32]) {
    if y1 <= y0 || w == 0 {
        return;
    }
    let rows = y1 - y0;
    let dst = &mut dst[..rows * w];
    let rpc = ((rows + engine.threads * 4 - 1) / (engine.threads * 4)).max(1);
    engine.par_chunks_mut(dst, rpc * w, |ci, chunk| {
        let row0 = y0 + ci * rpc;
        for (ri, line) in chunk.chunks_mut(w).enumerate() {
            let y = row0 + ri;
            for x in 0..w {
                line[x] = filter_pixel(src, w, h, x, y);
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constant_image_only_gets_the_contrast_curve() {
        let (w, h) = (9, 7);
        let c = 200u32;
        let px = c | (c << 8) | (c << 16) | 0xFF00_0000;
        let src = vec![px; w * h];
        let expect = (((c as i32 - 128) * 3) / 2 + 128).clamp(0, 255) as u32;
        let out = filter_pixel(&src, w, h, 0, 0);
        assert_eq!(out & 255, expect);
        assert_eq!(out >> 24, 255);
    }

    #[test]
    fn row_range_equals_per_pixel() {
        let (w, h) = (33, 21);
        let src = make_image(w, h, 5);
        let eng = CpuEngine::new(3);
        let mut dst = vec![0u32; w * 10];
        filter_rows(&eng, &src, w, h, 4, 14, &mut dst);
        for y in 4..14 {
            for x in 0..w {
                assert_eq!(dst[(y - 4) * w + x], filter_pixel(&src, w, h, x, y));
            }
        }
    }
}
