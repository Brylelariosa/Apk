//! Multithreaded CPU compute kernels. std-only: scoped threads, no unsafe scheduling code.
pub mod image;
pub mod matmul;
pub mod particles;
pub mod pool;
pub mod vector;

pub use pool::CpuEngine;
