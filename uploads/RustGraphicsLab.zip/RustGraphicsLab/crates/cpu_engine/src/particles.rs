//! Particle simulation: each particle is [x, y, vx, vy] and is integrated for several steps
//! towards a moving attractor (spring + damping + swirl). Particles are independent, so any
//! contiguous particle range can be computed by the CPU or the GPU and merged afterwards.
use crate::pool::CpuEngine;

#[derive(Clone, Copy, Debug)]
pub struct ParticleParams {
    pub dt: f32,
    pub k: f32,
    pub damp: f32,
    pub swirl: f32,
}

impl Default for ParticleParams {
    fn default() -> ParticleParams {
        ParticleParams {
            dt: 0.016,
            k: 6.0,
            damp: 1.2,
            swirl: 2.0,
        }
    }
}

/// Sequential "scene logic" run on the CPU: attractor position for every step.
pub fn make_attractors(steps: usize) -> Vec<[f32; 2]> {
    (0..steps)
        .map(|t| {
            let a = t as f32 * 0.11;
            [0.45 * a.cos(), 0.45 * (a * 1.3).sin()]
        })
        .collect()
}

#[inline(always)]
fn step_one(s: &mut [f32; 4], c: [f32; 2], p: &ParticleParams) {
    let ax = (c[0] - s[0]) * p.k - s[2] * p.damp - (s[1] - c[1]) * p.swirl;
    let ay = (c[1] - s[1]) * p.k - s[3] * p.damp + (s[0] - c[0]) * p.swirl;
    s[2] += ax * p.dt;
    s[3] += ay * p.dt;
    s[0] += s[2] * p.dt;
    s[1] += s[3] * p.dt;
}

const PER_CHUNK: usize = 4096;

/// Integrates particles [start, start + dst.len() / 4) from `src` into `dst`.
pub fn step_range(
    engine: &CpuEngine,
    src: &[f32],
    dst: &mut [f32],
    start: usize,
    attractors: &[[f32; 2]],
    p: &ParticleParams,
) {
    engine.par_chunks_mut(dst, PER_CHUNK * 4, |ci, out| {
        let first = start + ci * PER_CHUNK;
        let count = out.len() / 4;
        for i in 0..count {
            let base = (first + i) * 4;
            let mut s = [src[base], src[base + 1], src[base + 2], src[base + 3]];
            for c in attractors.iter() {
                step_one(&mut s, *c, p);
            }
            out[i * 4..i * 4 + 4].copy_from_slice(&s);
        }
    });
}

/// Independent f64 reference for one particle.
pub fn reference(init: [f32; 4], attractors: &[[f32; 2]], p: &ParticleParams) -> [f64; 4] {
    let mut s = [init[0] as f64, init[1] as f64, init[2] as f64, init[3] as f64];
    let (dt, k, damp, swirl) = (p.dt as f64, p.k as f64, p.damp as f64, p.swirl as f64);
    for c in attractors {
        let (cx, cy) = (c[0] as f64, c[1] as f64);
        let ax = (cx - s[0]) * k - s[2] * damp - (s[1] - cy) * swirl;
        let ay = (cy - s[1]) * k - s[3] * damp + (s[0] - cx) * swirl;
        s[2] += ax * dt;
        s[3] += ay * dt;
        s[0] += s[2] * dt;
        s[1] += s[3] * dt;
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cpu_matches_f64_reference() {
        let n = 5000;
        let mut src = vec![0f32; n * 4];
        for i in 0..n {
            src[i * 4] = (i as f32 * 0.001).sin();
            src[i * 4 + 1] = (i as f32 * 0.002).cos();
            src[i * 4 + 2] = 0.1;
            src[i * 4 + 3] = -0.1;
        }
        let att = make_attractors(32);
        let p = ParticleParams::default();
        let eng = CpuEngine::new(2);
        let mut dst = vec![0f32; 4000 * 4];
        step_range(&eng, &src, &mut dst, 1000, &att, &p);
        for i in (0..4000).step_by(97) {
            let g = 1000 + i;
            let r = reference([src[g * 4], src[g * 4 + 1], src[g * 4 + 2], src[g * 4 + 3]], &att, &p);
            for c in 0..4 {
                assert!((dst[i * 4 + c] as f64 - r[c]).abs() < 1e-3);
            }
        }
    }
}
