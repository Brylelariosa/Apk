//! Work distribution over scoped threads with dynamic (work-stealing style) chunk scheduling.
//! Dynamic scheduling matters on big.LITTLE phones: fast cores simply take more chunks.
use std::sync::Mutex;

#[derive(Clone, Debug)]
pub struct CpuEngine {
    pub threads: usize,
}

impl CpuEngine {
    /// `threads == 0` means "use every logical core".
    pub fn new(threads: usize) -> CpuEngine {
        let t = if threads == 0 { Self::detected_threads() } else { threads };
        CpuEngine { threads: t.max(1) }
    }

    pub fn detected_threads() -> usize {
        std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1)
    }

    /// Runs `f(chunk_index, chunk)` over disjoint mutable chunks of `data`, in parallel.
    pub fn par_chunks_mut<T, F>(&self, data: &mut [T], chunk_len: usize, f: F)
    where
        T: Send,
        F: Fn(usize, &mut [T]) + Sync,
    {
        if data.is_empty() {
            return;
        }
        let chunk_len = chunk_len.max(1);
        let n_chunks = (data.len() + chunk_len - 1) / chunk_len;
        if self.threads <= 1 || n_chunks <= 1 {
            for (i, c) in data.chunks_mut(chunk_len).enumerate() {
                f(i, c);
            }
            return;
        }
        let workers = self.threads.min(n_chunks);
        let queue = Mutex::new(data.chunks_mut(chunk_len).enumerate());
        std::thread::scope(|s| {
            for _ in 0..workers {
                s.spawn(|| loop {
                    let item = { queue.lock().unwrap().next() };
                    match item {
                        Some((i, c)) => f(i, c),
                        None => break,
                    }
                });
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_element_is_written_once() {
        for threads in [1usize, 2, 5] {
            let eng = CpuEngine::new(threads);
            let mut v = vec![0u32; 1003];
            eng.par_chunks_mut(&mut v, 100, |ci, chunk| {
                for (k, x) in chunk.iter_mut().enumerate() {
                    *x = (ci * 100 + k) as u32 + 1;
                }
            });
            for (i, x) in v.iter().enumerate() {
                assert_eq!(*x, i as u32 + 1);
            }
        }
    }
}
