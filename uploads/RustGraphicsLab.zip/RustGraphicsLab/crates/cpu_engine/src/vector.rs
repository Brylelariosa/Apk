//! Vector workload: y[i] = chain of `iters` fused multiply-adds applied to x[i].
//! iters = 1 is a streaming (memory-bound) test, large iters is compute-bound.
use crate::pool::CpuEngine;

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn fmadd(v: f32, a: f32, b: f32) -> f32 {
    v.mul_add(a, b)
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn fmadd(v: f32, a: f32, b: f32) -> f32 {
    v * a + b
}

const CHUNK: usize = 16384;

/// Processes x[start .. start + out.len()] into `out`.
pub fn fma_chain_range(
    engine: &CpuEngine,
    x: &[f32],
    out: &mut [f32],
    start: usize,
    a: f32,
    b: f32,
    iters: u32,
) {
    engine.par_chunks_mut(out, CHUNK, |ci, chunk| {
        let base = start + ci * CHUNK;
        let src = &x[base..base + chunk.len()];
        process(src, chunk, a, b, iters);
    });
}

fn process(src: &[f32], dst: &mut [f32], a: f32, b: f32, iters: u32) {
    let n = src.len();
    let mut i = 0;
    while i + 8 <= n {
        let mut v = [0f32; 8];
        v.copy_from_slice(&src[i..i + 8]);
        for _ in 0..iters {
            for l in 0..8 {
                v[l] = fmadd(v[l], a, b);
            }
        }
        dst[i..i + 8].copy_from_slice(&v);
        i += 8;
    }
    while i < n {
        let mut v = src[i];
        for _ in 0..iters {
            v = fmadd(v, a, b);
        }
        dst[i] = v;
        i += 1;
    }
}

/// Independent f64 reference for a single element.
pub fn fma_chain_ref(x: f32, a: f32, b: f32, iters: u32) -> f64 {
    let (a, b) = (a as f64, b as f64);
    let mut v = x as f64;
    for _ in 0..iters {
        v = v * a + b;
    }
    v
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn matches_reference() {
        let x: Vec<f32> = (0..1000).map(|i| i as f32 * 0.01 - 5.0).collect();
        let eng = CpuEngine::new(2);
        let mut out = vec![0f32; 1000 - 100];
        fma_chain_range(&eng, &x, &mut out, 100, 0.999, 0.001, 64);
        for i in 0..out.len() {
            let r = fma_chain_ref(x[100 + i], 0.999, 0.001, 64);
            assert!((out[i] as f64 - r).abs() < 1e-4);
        }
    }
}
