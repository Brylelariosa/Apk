//! Dense f32 matrix multiply C = A x B (square, row-major), computed per row range.
//! 4-row register blocking + k-blocking; fused multiply-add on aarch64.
use crate::pool::CpuEngine;

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn fmadd(v: f32, a: f32, b: f32) -> f32 {
    v.mul_add(a, b)
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn fmadd(v: f32, a: f32, b: f32) -> f32 {
    v * a + b
}

const KB: usize = 128;

/// Computes rows [r0, r1) of C. `out` holds exactly those rows ((r1 - r0) * n floats).
pub fn matmul_rows(
    engine: &CpuEngine,
    a: &[f32],
    b: &[f32],
    n: usize,
    r0: usize,
    r1: usize,
    out: &mut [f32],
) {
    if r1 <= r0 || n == 0 {
        return;
    }
    let rows = r1 - r0;
    let out = &mut out[..rows * n];
    // ~4 chunks per thread so slow cores do not stall the whole run; multiple of 4 rows
    let target_chunks = engine.threads * 4;
    let mut rpc = (rows + target_chunks - 1) / target_chunks;
    rpc = ((rpc + 3) / 4) * 4;
    if rpc == 0 {
        rpc = 4;
    }
    engine.par_chunks_mut(out, rpc * n, |ci, chunk| {
        let first_row = r0 + ci * rpc;
        let nrows = chunk.len() / n;
        block(a, b, n, first_row, nrows, chunk);
    });
}

fn block(a: &[f32], b: &[f32], n: usize, first_row: usize, nrows: usize, out: &mut [f32]) {
    for v in out.iter_mut() {
        *v = 0.0;
    }
    let mut kk = 0;
    while kk < n {
        let kend = (kk + KB).min(n);
        let mut r = 0;
        while r + 4 <= nrows {
            let (c0, rest) = out[r * n..(r + 4) * n].split_at_mut(n);
            let (c1, rest) = rest.split_at_mut(n);
            let (c2, c3) = rest.split_at_mut(n);
            let (c0, c1, c2, c3) = (&mut c0[..n], &mut c1[..n], &mut c2[..n], &mut c3[..n]);
            let base = first_row + r;
            let a0 = &a[base * n..(base + 1) * n];
            let a1 = &a[(base + 1) * n..(base + 2) * n];
            let a2 = &a[(base + 2) * n..(base + 3) * n];
            let a3 = &a[(base + 3) * n..(base + 4) * n];
            for k in kk..kend {
                let brow = &b[k * n..(k + 1) * n];
                let (x0, x1, x2, x3) = (a0[k], a1[k], a2[k], a3[k]);
                for j in 0..n {
                    let bv = brow[j];
                    c0[j] = fmadd(bv, x0, c0[j]);
                    c1[j] = fmadd(bv, x1, c1[j]);
                    c2[j] = fmadd(bv, x2, c2[j]);
                    c3[j] = fmadd(bv, x3, c3[j]);
                }
            }
            r += 4;
        }
        while r < nrows {
            let crow = &mut out[r * n..(r + 1) * n];
            let base = first_row + r;
            let arow = &a[base * n..(base + 1) * n];
            for k in kk..kend {
                let brow = &b[k * n..(k + 1) * n];
                let x = arow[k];
                for (cv, bv) in crow.iter_mut().zip(brow.iter()) {
                    *cv = fmadd(*bv, x, *cv);
                }
            }
            r += 1;
        }
        kk = kend;
    }
}

/// Independent reference for one output row, accumulated in f64.
pub fn matmul_ref_row(a: &[f32], b: &[f32], n: usize, row: usize) -> Vec<f64> {
    let mut out = vec![0f64; n];
    for k in 0..n {
        let av = a[row * n + k] as f64;
        for j in 0..n {
            out[j] += av * b[k * n + j] as f64;
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fill(v: &mut [f32], seed: u32) {
        let mut s = seed;
        for x in v.iter_mut() {
            s = s.wrapping_mul(1664525).wrapping_add(1013904223);
            *x = ((s >> 8) as f32 / 8388608.0) - 1.0;
        }
    }

    #[test]
    fn partial_row_range_matches_reference() {
        let n = 37;
        let mut a = vec![0f32; n * n];
        let mut b = vec![0f32; n * n];
        fill(&mut a, 1);
        fill(&mut b, 2);
        let eng = CpuEngine::new(3);
        let (r0, r1) = (5, n);
        let mut out = vec![f32::NAN; (r1 - r0) * n];
        matmul_rows(&eng, &a, &b, n, r0, r1, &mut out);
        for r in r0..r1 {
            let reference = matmul_ref_row(&a, &b, n, r);
            for j in 0..n {
                let got = out[(r - r0) * n + j] as f64;
                assert!((got - reference[j]).abs() < 1e-3, "row {} col {}", r, j);
            }
        }
    }
}
