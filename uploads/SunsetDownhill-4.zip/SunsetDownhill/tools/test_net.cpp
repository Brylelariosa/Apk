// test_net: the LAN multiplayer protocol end to end on the loopback interface - discovery, joining, the room roster, a synchronised
// start, state relay with interpolation, leaving / timeouts, a full room, and a barrage of malformed or spoofed packets.
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "net.h"

using namespace sd;

namespace {

int failures = 0;
#define CHECK(cond, ...)                                          \
    do {                                                          \
        if (!(cond)) {                                            \
            ++failures;                                           \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond); \
            std::printf(__VA_ARGS__);                             \
            std::printf("\n");                                    \
        }                                                         \
    } while (0)

constexpr uint32_t kLoopback = 0x7F000001u;

NetConfig config(uint16_t port, std::vector<uint16_t> beaconTo = {}) {
    NetConfig c;
    c.port = port;
    for (uint16_t p : beaconTo) c.discoveryTargets.push_back({kLoopback, p});
    return c;
}

void pump(int frames, std::initializer_list<LanSession*> sessions) {
    for (int i = 0; i < frames; ++i)
        for (LanSession* s : sessions) s->update(1.0f / 60.0f);
}

// A bare UDP endpoint for forging packets.
struct Raw {
    int fd = -1;
    uint16_t port = 0;
    Raw() {
        fd = ::socket(AF_INET, SOCK_DGRAM, 0);
        sockaddr_in a;
        std::memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(kLoopback);
        a.sin_port = 0;
        ::bind(fd, reinterpret_cast<sockaddr*>(&a), sizeof(a));
        socklen_t l = sizeof(a);
        ::getsockname(fd, reinterpret_cast<sockaddr*>(&a), &l);
        port = ntohs(a.sin_port);
        timeval tv{0, 20000};
        ::setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    }
    ~Raw() { if (fd >= 0) ::close(fd); }
    void send(uint16_t to, const std::vector<uint8_t>& bytes) {
        sockaddr_in a;
        std::memset(&a, 0, sizeof(a));
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(kLoopback);
        a.sin_port = htons(to);
        ::sendto(fd, bytes.data(), bytes.size(), 0, reinterpret_cast<sockaddr*>(&a), sizeof(a));
    }
    // Next datagram, empty when none.
    std::vector<uint8_t> recv() {
        uint8_t buf[1024];
        const ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
        return n > 0 ? std::vector<uint8_t>(buf, buf + n) : std::vector<uint8_t>();
    }
};

void put32(std::vector<uint8_t>& v, uint32_t x) { for (int i = 0; i < 4; ++i) v.push_back(static_cast<uint8_t>(x >> (8 * i))); }
void putF(std::vector<uint8_t>& v, float f) { uint32_t b; std::memcpy(&b, &f, 4); put32(v, b); }
std::vector<uint8_t> header(uint8_t type, uint8_t slot) { return {0x53, 0x44, 0x48, 0x32, type, slot, 0, 0}; }

std::vector<uint8_t> joinPacket(const char* name) {
    std::vector<uint8_t> p = header(2, 255);
    put32(p, 0xABCD1234u);
    for (int i = 0; i < kNetNameLen; ++i) p.push_back(i < static_cast<int>(std::strlen(name)) ? static_cast<uint8_t>(name[i]) : 0);
    return p;
}

// `ts` is the sender's race time when the state was true (the receiver plays states back by it)
std::vector<uint8_t> statePacket(uint8_t slot, uint32_t raceId, float s, float x, float speed, float junk = 0.0f, float ts = 0.0f) {
    std::vector<uint8_t> p = header(7, slot);
    put32(p, raceId);
    const float f[13] = {s, x, 0, 0, speed, junk, 0.5f, 0, 0, 0, 0, 0, s};
    for (float v : f) putF(p, v);
    put32(p, 777);
    p.push_back(0);
    p.push_back(1);
    putF(p, 0.0f);   // height above the road
    putF(p, 0.0f);   // finish time
    putF(p, ts);
    return p;
}

}  // namespace

int main() {
    // ---- discovery and joining -------------------------------------------------------------------------------------------
    LanSession host(config(47830, {47831, 47832, 47833})), a(config(47831)), b(config(47832)), c(config(47833));
    CHECK(host.host("Host Phone!"), "host failed: %s", host.error().c_str());
    CHECK(host.isHost() && host.selfSlot() == 0, "host role/slot");
    CHECK(std::strcmp(host.players()[0].name, "HOST PHONE") == 0, "name sanitised: '%s'", host.players()[0].name);
    CHECK(a.search("Alice") && b.search("bob"), "search");
    pump(130, {&host, &a, &b});
    CHECK(a.hosts().size() == 1 && b.hosts().size() == 1, "hosts found: %zu / %zu", a.hosts().size(), b.hosts().size());
    if (a.hosts().empty() || b.hosts().empty()) {
        std::printf("discovery failed - aborting\n");
        return 1;
    }
    CHECK(std::strcmp(a.hosts()[0].name, "HOST PHONE") == 0 && a.hosts()[0].players == 1, "beacon content: %s %d", a.hosts()[0].name, a.hosts()[0].players);
    CHECK(host.hosts().empty(), "a host does not list itself");

    CHECK(a.join(0), "join call");
    pump(40, {&host, &a, &b});
    CHECK(a.inRoom() && a.selfSlot() == 1, "a joined as slot %d", a.selfSlot());
    CHECK(host.playerCount() == 2, "host sees %d players", host.playerCount());
    CHECK(std::strcmp(a.players()[0].name, "HOST PHONE") == 0 && std::strcmp(host.players()[1].name, "ALICE") == 0, "roster names '%s' '%s'", a.players()[0].name, host.players()[1].name);
    CHECK(b.join(0), "b join call");
    pump(40, {&host, &a, &b});
    CHECK(b.inRoom() && b.selfSlot() == 2 && host.playerCount() == 3 && a.playerCount() == 3 && b.playerCount() == 3, "three in the room: %d %d %d", host.playerCount(),
          a.playerCount(), b.playerCount());
    CHECK(std::strcmp(b.players()[1].name, "ALICE") == 0 && b.players()[2].self && !b.players()[1].self, "b's roster view");

    // ---- a raw peer for forging: it joins legitimately, then misbehaves ---------------------------------------------------
    Raw raw;
    raw.send(47830, joinPacket("raw peer"));
    pump(20, {&host, &a, &b});
    CHECK(host.playerCount() == 4, "raw peer joined: %d", host.playerCount());

    // ---- a synchronised start --------------------------------------------------------------------------------------------
    CHECK(host.canStart(), "host can start");
    CHECK(!a.canStart(), "clients cannot start");
    host.setGoal(1500.0f);
    CHECK(a.clockSynced() && b.clockSynced() && host.clockSynced(), "clocks synced before the race");
    CHECK(host.startRace(), "start");
    uint32_t hostSeed = 0, aSeed = 0, bSeed = 0;
    CHECK(host.takeStart(hostSeed), "host gets its own start");
    pump(90, {&host, &a, &b});
    float aLag = -1.0f, bLag = -1.0f;
    CHECK(a.takeStart(aSeed, aLag) && b.takeStart(bSeed, bLag), "clients got the start");
    CHECK(aLag >= 0.0f && aLag < 0.5f && bLag >= 0.0f && bLag < 0.5f, "start lag is small on a local network: %.3f %.3f", aLag, bLag);
    CHECK(host.goal() == 1500.0f && a.goal() == 1500.0f && b.goal() == 1500.0f, "finish line distance shared: %.0f %.0f %.0f", host.goal(), a.goal(), b.goal());
    CHECK(aSeed == hostSeed && bSeed == hostSeed, "same seed everywhere: %u %u %u", hostSeed, aSeed, bSeed);
    uint32_t again;
    CHECK(!a.takeStart(again) && !b.takeStart(again) && !host.takeStart(again), "a start is delivered exactly once (repeats are ignored)");
    CHECK(host.roomRacing() && a.roomRacing(), "room is racing");

    uint32_t raceId = 0;   // the raw peer reads it from the START packet it received
    for (int i = 0; i < 40 && !raceId; ++i) {
        const std::vector<uint8_t> pk = raw.recv();
        if (pk.size() >= 16 && pk[4] == 6) raceId = pk[8] | (pk[9] << 8) | (pk[10] << 16) | (static_cast<uint32_t>(pk[11]) << 24);
    }
    CHECK(raceId != 0, "raw peer saw the race id");

    // ---- state relay + interpolation -------------------------------------------------------------------------------------
    float hs = 100.0f, as = 90.0f, bs = 80.0f;
    for (int i = 0; i < 180; ++i) {
        hs += 20.0f / 60.0f; as += 22.0f / 60.0f; bs += 18.0f / 60.0f;
        RiderNet h, ra, rb;
        h.s = hs; h.x = 1.8f; h.speed = 20.0f; h.score = 500 + i; h.distance = hs;
        ra.s = as; ra.x = -1.0f; ra.speed = 22.0f; ra.score = 300; ra.tuck = 1.0f; ra.distance = as;
        rb.s = bs; rb.x = 0.5f; rb.speed = 18.0f; rb.score = 100; rb.crashed = false; rb.distance = bs;
        host.setLocal(h, PeerPhase::Racing);
        a.setLocal(ra, PeerPhase::Racing);
        b.setLocal(rb, PeerPhase::Racing);
        pump(1, {&host, &a, &b});
    }
    RiderNet r;
    CHECK(a.sampleRider(0, r), "a sees the host");
    CHECK(std::fabs(r.s - (hs - 20.0f * 0.14f)) < 2.5f, "host rider on a: s=%.2f (host at %.2f)", r.s, hs);
    CHECK(b.sampleRider(1, r) && std::fabs(r.s - (as - 22.0f * 0.14f)) < 2.5f && r.tuck > 0.99f, "relayed rider a on b: s=%.2f (a at %.2f) tuck=%.2f", r.s, as, r.tuck);
    CHECK(host.sampleRider(2, r) && std::fabs(r.x - 0.5f) < 0.01f, "b on the host");
    CHECK(!a.sampleRider(1, r), "a never sees itself");
    CHECK(a.players()[0].score >= 500 && a.players()[2].score == 100, "scores shared: %d %d", a.players()[0].score, a.players()[2].score);
    CHECK(host.players()[1].phase == PeerPhase::Racing, "phases shared");
    {   // b crosses the finish line: everybody learns the time
        RiderNet f;
        f.s = bs; f.speed = 18.0f; f.distance = bs; f.finished = true; f.finishTime = 83.25f; f.yRel = 1.5f; f.airborne = true;
        b.setLocal(f, PeerPhase::Finished);
        pump(40, {&host, &a, &b});
        RiderNet got;
        CHECK(host.players()[2].crossed && std::fabs(host.players()[2].finishTime - 83.25f) < 0.01f && a.players()[2].crossed, "finish line crossing shared");
        CHECK(host.sampleRider(2, got) && got.finished && got.airborne && std::fabs(got.yRel - 1.5f) < 0.05f, "height and finish flags travel with the state");
    }

    // ---- spoofing and garbage --------------------------------------------------------------------------------------------
    Raw stranger;   // never joined
    stranger.send(47830, statePacket(1, raceId, 99999.0f, 0, 10));          // pretends to be slot 1
    raw.send(47830, statePacket(1, raceId, 88888.0f, 0, 10));                // a real peer pretending to be somebody else
    const float hostileTs = static_cast<float>(host.raceTime());
    raw.send(47830, statePacket(3, raceId, 1000.0f, 1.0f, std::nanf(""), INFINITY, hostileTs));   // its own slot, hostile values
    raw.send(47830, statePacket(3, raceId + 5, 55555.0f, 0, 10));            // stale race id
    pump(20, {&host, &a, &b});
    CHECK(host.sampleRider(1, r) && r.s < 1000.0f, "spoofed state ignored (slot 1 s=%.1f)", r.s);
    CHECK(host.sampleRider(3, r) && std::isfinite(r.speed) && std::isfinite(r.lean) && r.speed <= 200.0f && r.s == 1000.0f, "hostile values cleaned: speed=%.1f lean=%.2f s=%.1f", r.speed, r.lean, r.s);
    {   // a burst of packets, as after a Wi-Fi hiccup: playback follows the senders' timestamps, not the arrival times, so motion stays smooth
        const double now = host.raceTime();
        for (int k = 0; k < 10; ++k) {
            const float ts = static_cast<float>(now + 0.15 + static_cast<double>(k) / 30.0);
            raw.send(47830, statePacket(3, raceId, 1000.0f + 20.0f * (ts - hostileTs), 0.0f, 20.0f, 0.0f, ts));
        }
        pump(2, {&host});
        float prev = -1.0f, minStep = 1e9f, maxStep = 0.0f;
        RiderNet q;
        for (int i = 0; i < 24; ++i) {
            pump(1, {&host});
            if (!host.sampleRider(3, q)) continue;
            if (prev >= 0.0f) {
                minStep = std::min(minStep, q.s - prev);
                maxStep = std::max(maxStep, q.s - prev);
            }
            prev = q.s;
        }
        CHECK(minStep > 0.25f && maxStep < 0.42f, "a burst of packets plays back smoothly: step %.3f..%.3f m per frame (20 m/s at 60 fps = 0.333)", minStep, maxStep);
    }
    srand(7);
    for (int i = 0; i < 400; ++i) {   // random garbage of every length, plus truncated real packets
        std::vector<uint8_t> junk(static_cast<size_t>(rand() % 300));
        for (uint8_t& v : junk) v = static_cast<uint8_t>(rand());
        if (i % 3 == 0 && junk.size() >= 8) { junk[0] = 0x53; junk[1] = 0x44; junk[2] = 0x48; junk[3] = 0x32; junk[4] = static_cast<uint8_t>(1 + rand() % 9); }
        stranger.send(47830, junk);
        stranger.send(47831, junk);
        stranger.send(47832, junk);
        std::vector<uint8_t> trunc = statePacket(1, raceId, 1, 1, 1);
        trunc.resize(static_cast<size_t>(8 + rand() % 50));
        stranger.send(47830, trunc);
    }
    raw.send(47830, [] { std::vector<uint8_t> k = header(9, 3); k.push_back(1); return k; }());   // keep-alive: the raw peer is still a player
    pump(30, {&host, &a, &b});
    CHECK(host.isHost() && a.inRoom() && b.inRoom(), "sessions survived the garbage");
    CHECK(host.playerCount() == 4, "no phantom players: %d", host.playerCount());

    // ---- a late joiner is turned away during a race ------------------------------------------------------------------------
    CHECK(c.search("Carl"), "c search");
    pump(130, {&host, &a, &b, &c});
    CHECK(c.hosts().size() == 1 && c.hosts()[0].racing, "c sees a racing room");
    c.join(0);
    pump(30, {&host, &a, &b, &c});
    CHECK(!c.inRoom() && !c.joining() && std::strstr(c.error().c_str(), "RACE") != nullptr, "c turned away: '%s'", c.error().c_str());
    c.leave();

    // ---- leaving, timeouts, the end of the race -------------------------------------------------------------------------
    a.leave();
    pump(20, {&host, &b});
    CHECK(host.playerCount() == 3 && !host.players()[1].present, "a left: %d players", host.playerCount());
    for (int i = 0; i < 60 * 8; ++i) host.update(1.0f / 60.0f);   // b and the raw peer go silent
    CHECK(host.playerCount() == 1, "silent players dropped: %d left", host.playerCount());

    CHECK(host.roomRacing(), "room still marked racing until the host stops");
    RiderNet done;
    host.setLocal(done, PeerPhase::Finished);
    pump(200, {&host});
    CHECK(!host.roomRacing() && host.canStart(), "room opens again once nobody is racing");

    // ---- a full room -----------------------------------------------------------------------------------------------------
    {
        LanSession full(config(47840, {47841})), late(config(47841));
        full.host("Full House");
        std::vector<Raw> filler(5);
        for (Raw& f : filler) f.send(47840, joinPacket("filler"));
        pump(20, {&full});
        CHECK(full.playerCount() == kNetMaxPlayers, "room full: %d", full.playerCount());
        late.search("Late");
        pump(130, {&full, &late});
        CHECK(late.hosts().size() == 1 && late.hosts()[0].players == kNetMaxPlayers, "late client sees the full room");
        late.join(0);
        pump(30, {&full, &late});
        CHECK(!late.inRoom() && std::strstr(late.error().c_str(), "FULL") != nullptr, "turned away: '%s'", late.error().c_str());
    }

    // ---- the host leaves: everybody is told -------------------------------------------------------------------------------
    LanSession h2(config(47850, {47851})), j(config(47851));
    h2.host("Boss");
    j.search("Joe");
    pump(130, {&h2, &j});
    j.join(0);
    pump(30, {&h2, &j});
    CHECK(j.inRoom(), "j joined h2");
    h2.leave();
    pump(10, {&j});
    CHECK(j.role() == NetRole::Off && std::strstr(j.error().c_str(), "HOST") != nullptr, "client told the host left: '%s'", j.error().c_str());

    std::printf(failures == 0 ? "net OK\n" : "net FAILED (%d)\n", failures);
    return failures == 0 ? 0 : 1;
}
