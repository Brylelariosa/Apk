// render_lan: two engines race over loopback; one of them is rendered through the real renderer (headless software GLES 3 via Mesa
// EGL), so the other rider, its name tag and the standings can be reviewed as a player would see them.
//   ./render_lan [width height outDir]
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>

#include <cstdio>
#include <cstdlib>
#include <memory>
#include <vector>

#include "engine.h"

using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            const unsigned char* s = &px[((h - 1 - y) * w + x) * 4];
            unsigned char* d = &out[(y * w + x) * 3];
            d[0] = s[0]; d[1] = s[1]; d[2] = s[2];
        }
    FILE* f = std::fopen(path, "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
    std::fwrite(out.data(), 1, out.size(), f);
    std::fclose(f);
}

int main(int argc, char** argv) {
    const int W = argc > 1 ? std::atoi(argv[1]) : 1600;
    const int H = argc > 2 ? std::atoi(argv[2]) : 720;
    const char* dir = argc > 3 ? argv[3] : "/tmp/lan";

    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min;
    eglInitialize(dpy, &maj, &min);
    eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
                         EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg;
    EGLint n;
    eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);

    const uint32_t lo = 0x7F000001u;
    NetConfig hc, cc;
    hc.port = 47910; hc.discoveryTargets.push_back({lo, 47911});
    cc.port = 47911;
    Engine a(hc), b(cc);          // a is rendered, b is the other phone (headless)
    a.setPlayerName("Infinix HOT 11");
    b.setPlayerName("Pixel 7 Pro");
    a.renderer().setQualityTier(3);
    a.onSurfaceCreated();
    a.onSurfaceChanged(W, H);
    b.onSurfaceChanged(W, H);
    if (!a.renderer().ready()) { std::fprintf(stderr, "renderer not ready\n"); return 2; }

    auto step = [&](int frames) { for (int i = 0; i < frames; ++i) { a.stepFrame(1.0f / 60.0f); b.stepFrame(1.0f / 60.0f); } };
    auto tap = [](Engine& e, const Rect& r) { const float x = r.x + r.w * 0.5f, y = r.y + r.h * 0.5f; e.onTouch(0, 1, x, y); e.onTouch(2, 1, x, y); };
    auto shot = [&](const char* name) {
        a.stepFrame(1.0f / 60.0f);
        char path[256];
        std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, name);
        savePPM(path, W, H);
        std::fprintf(stderr, "wrote %s\n", name);
    };

    step(10);
    tap(a, a.controls().layout().multiMenu); tap(b, b.controls().layout().multiMenu);
    step(5);
    shot("lobby_choose");
    tap(a, lobbyRects(a.controls().layout()).host);
    tap(b, lobbyRects(b.controls().layout()).search);
    step(150);
    tap(b, lobbyRects(b.controls().layout()).rows[0]);
    step(80);
    shot("lobby_room");
    tap(a, lobbyRects(a.controls().layout()).start);
    step(60 * 4);
    // b rides in a tuck (it holds the TUCK button down) and pulls ahead; a holds SLIDE and drops back, so b is in front of a's camera
    const Vec2 tuck = b.controls().layout().center(ButtonId::Tuck);
    const Vec2 slide = a.controls().layout().center(ButtonId::Slide);
    b.onTouch(0, 2, tuck.x, tuck.y);
    a.onTouch(0, 2, slide.x, slide.y);
    for (int t = 0; t < 16; ++t) {
        step(60);
        const MpModel mp = a.hudModel().mp;
        std::fprintf(stderr, "t=%2d a.s=%.0f b.s=%.0f tags=%d", t, a.game().riderNet().s, b.game().riderNet().s, mp.tagCount);
        for (int i = 0; i < mp.tagCount; ++i) std::fprintf(stderr, "  [%s at %.0f,%.0f ahead %.0f alpha %.2f]", mp.tags[i].name, mp.tags[i].pos.x, mp.tags[i].pos.y, mp.tags[i].ahead, mp.tags[i].alpha);
        std::fprintf(stderr, "\n");
        if (t == 9) shot("race_a");
        if (t == 13) shot("race_b");
    }
    return 0;
}
