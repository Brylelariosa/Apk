# Desktop tools

These are optional developer tools for the platform independent engine in
`app/src/main/cpp/core`. They are **not** part of the Android build.

```bash
cmake -S tools -B build-tools && cmake --build build-tools -j
./build-tools/sim_physics        # speed / crash balance of the skater physics
./build-tools/sim_game           # autopilot plays full runs with obstacles and traffic
./build-tools/audio_dump         # synthesises a test session to /tmp/audio_test.wav
./build-tools/test_controls      # control schemes, button layout editor, tilt maths, HUD fit on every aspect ratio
./build-tools/test_audio         # no engine-like tone may follow the wheel speed (guards the "flapping / gear change" bug)
./build-tools/dump_ui /tmp/ui    # the HUD, the CONTROLS screen, the font sheet and the LAN screens as PPM images (no GPU needed)
./build-tools/test_traffic 240 6 # drivers vs. cones, rocks and each other on 6 seeds (add "weave" for a rider crossing both lanes)
./build-tools/test_net           # the LAN protocol on loopback: discovery, join, start, relay, spoofed / malformed packets
ctest --test-dir build-tools     # runs test_controls, test_audio, test_traffic, test_net (+ test_mp_engine with EGL)
# needs Mesa EGL/GLES (apt install libegl-dev libgles-dev libgl1-mesa-dri):
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_session 1600 720 /tmp/shots 3
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_models 1000 700 /tmp/models     # close-ups: rider poses and every car type
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_traffic 1400 630 /tmp/traffic   # autopilot rides through traffic: cars, brake lights, signals
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_lan 1600 720 /tmp/lan           # two phones race over loopback; one is rendered
./build-tools/test_mp_engine     # three engines run a whole LAN race through the lobby screens (no GPU needed at run time)
```

`render_session` runs the real engine on a software GLES 3 context and writes PPM screenshots
(`python3 -c "from PIL import Image; Image.open('a_menu.ppm').save('a_menu.png')"` converts them).
All gameplay constants live in `core/config.h`.

`test_controls`, `test_audio` and `dump_ui` need neither a GPU nor a phone: the control code (`controls*.cpp`, `tilt.cpp`,
`input.cpp`, `hud.cpp`) is platform independent and free of OpenGL on purpose.

## test_race

`test_race` (GPU free) checks the rider mesh budget, that cliff-jump zones are valid and stand above the ground, that 190+ simulated
kicker jumps (different speeds, seeds and bends) land on the shortcut deck and that the deck is faster than the road, that a race with
a goal ends at the finish line, and that a late START fast-forwards the countdown so GO is simultaneous.
