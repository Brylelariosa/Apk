// Race rules and the cliff jump (no GPU needed):
//  - the rider meshes stay inside the 16-bit index budget of the dynamic mesh, six riders at once
//  - cliff jump zones: valid, the shortcut deck stands above the ground, support / rail rules are consistent
//  - the kicker delivers the rider onto the deck at any sensible speed and the deck is a real shortcut
//  - the finish line ends a race, and a late START message fast-forwards the countdown so that GO is simultaneous
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "autopilot.h"
#include "game.h"
#include "skater_model.h"
#include "track.h"

using namespace sd;

static int g_fails = 0, g_checks = 0;
#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_fails;                                                              \
            std::printf("  FAIL line %d: %s  ", __LINE__, #cond);                   \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

static void testMeshBudget() {
    std::printf("rider mesh budget\n");
    size_t worst = 0, worstLow = 0;
    for (int style = 0; style < kRiderStyleCount; ++style) {
        for (int pose = 0; pose < 6; ++pose) {
            SkaterPose p;
            p.origin = Vec3(0, 0, 0); p.right = Vec3(1, 0, 0); p.up = Vec3(0, 1, 0); p.fwd = Vec3(0, 0, 1); p.time = 1.3f;
            if (pose == 1) p.tuck = 1.0f;
            if (pose == 2) { p.push = 1.0f; p.pushPhase = 0.4f; }
            if (pose == 3) { p.slide = 1.0f; p.slip = 1.1f; p.slideDir = -1.0f; }
            if (pose == 4) { p.crashed = true; p.crashTime = 0.7f; p.crashSpeed = 14.0f; }
            if (pose == 5) { p.lean = 0.5f; p.tuck = 0.5f; }
            MeshData full, low;
            p.lowDetail = false; buildSkaterMesh(p, full, riderStyle(style));
            p.lowDetail = true; buildSkaterMesh(p, low, riderStyle(style));
            worst = std::max(worst, full.vertices.size());
            worstLow = std::max(worstLow, low.vertices.size());
        }
    }
    std::printf("  full detail %zu vertices, low detail %zu\n", worst, worstLow);
    CHECK(worst <= kRiderVertexBudget, "full detail rider %zu > budget %zu", worst, kRiderVertexBudget);
    CHECK(worstLow <= kRemoteRiderVertexBudget, "low detail rider %zu > budget %zu", worstLow, kRemoteRiderVertexBudget);
    CHECK(worst + 5 * worstLow + 8000 <= kDynamicMeshVertexLimit, "the local rider + five remote riders + the world's own dynamic geometry must fit 16-bit indices");
}

static void testZones() {
    std::printf("cliff jump zones\n");
    int zones = 0;
    for (uint32_t seed = 1; seed <= 30; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4000.0f);
        const auto& list = tr.shortcuts();
        for (size_t zi = 0; zi < list.size(); ++zi) {
            const ShortcutZone& z = list[zi];
            ++zones;
            CHECK(z.sRamp0 < z.sLip && z.sLip < z.sDeck0 && z.sDeck0 + 60.0f < z.sDeck1, "ordering seed %u", seed);
            CHECK(zi == 0 || list[zi - 1].sDeck1 + 300.0f < z.sRamp0, "zones are spaced");
            CHECK(z.drop >= 1.0f && z.drop <= 7.0f, "drop %.2f", z.drop);
            CHECK(std::fabs(z.h.back()) < 1e-3f && std::fabs(z.h.front() + z.drop) < 1e-3f, "the deck ends level with the road and starts `drop` below it");
            bool aboveGround = true, sane = true;
            for (size_t k = 0; k < z.c.size(); k += 3) {
                const float s = z.sDeck0 + cfg::kTrackStep * static_cast<float>(k);
                if (z.c[k] - z.hw[k] < 7.0f) continue;   // (where it has come back next to the road it is a paved shoulder, not a bridge)
                for (float e : {-1.0f, 0.0f, 1.0f})
                    if (tr.terrainHeight(s, z.side * (z.c[k] + e * z.hw[k])) > z.h[k] - 1.0f) aboveGround = false;
                if (!(z.hw[k] > 0.5f && z.c[k] > 3.0f)) sane = false;
            }
            CHECK(aboveGround, "the deck stands at least 1 m above the (carved) ground, seed %u", seed);
            CHECK(sane, "deck widths and offsets");
            int kind = -1;
            const float sk = z.sRamp0 + 5.0f;
            CHECK(tr.supportHeight(sk, z.side * 3.8f, &kind) > 0.1f && kind == Track::kKicker, "kicker carries the rider");
            CHECK(tr.supportHeight(z.sLip + 3.0f, z.side * 3.8f, &kind) == 0.0f && kind == Track::kRoad, "road after the lip");
            tr.supportHeight(z.sLip + 3.0f, z.side * 12.0f, &kind);
            CHECK(kind == Track::kVoid, "nothing carries a rider between the road and the platform");
            float c, hw, h;
            const float sm = 0.5f * (z.sDeck0 + z.sDeck1);
            z.deckAt(sm, c, hw, h);
            CHECK(std::fabs(tr.supportHeight(sm, z.side * c, &kind) - h) < 1e-3f && kind == Track::kDeck, "deck carries the rider");
            CHECK(tr.railGap(z.sLip, z.side) && !tr.railGap(z.sLip, -z.side) && !tr.railGap(z.sRamp0 - 20.0f, z.side), "rail gap at the kicker only");
            float lo, hi;
            tr.lateralWindow(z.sLip, Track::kKicker, &lo, &hi);
            CHECK((z.side > 0 ? hi : -lo) > 100.0f, "no rail beside the kicker");
            tr.lateralWindow(sm, Track::kDeck, &lo, &hi);
            CHECK(hi - lo > 6.0f && hi - lo < 16.0f, "deck window %.1f", hi - lo);
            CHECK(tr.shortcutBlocks(sm, z.side * (c + 1.0f), 4.0f) && !tr.shortcutBlocks(sm, -z.side * 20.0f, 4.0f), "scenery keeps off the deck, not the other side of the road");
        }
    }
    std::printf("  %d zones over 30 seeds x 4 km\n", zones);
    CHECK(zones >= 20, "zones are common enough: %d", zones);
}

struct JumpResult { bool deck = false, crashed = false; float t = 0.0f; };

static JumpResult ride(const Track& tr, const ShortcutZone& z, float v0, bool takeKicker) {
    Skater sk;
    sk.reset(z.sRamp0 - 110.0f, v0);
    if (takeKicker) sk.x = 0.5f * (z.rampX0 + z.rampX1) * z.side;
    AutoPilot ap;
    std::vector<Obstacle> none;
    JumpResult r;
    bool wasAir = false;
    const float dt = 1.0f / 120.0f;
    for (int i = 0; i < 120 * 60 && sk.s < z.sDeck1 + 30.0f; ++i) {
        if (sk.s < z.sLip - 1.0f) sk.speed = v0;   // the entry speed is the test's input
        if (takeKicker) {
            if (sk.surface == Track::kDeck && !sk.airborne) {
                float c, hw, h;
                z.deckAt(std::min(sk.s + 14.0f, z.sDeck1), c, hw, h);
                ap.forcedX = c * z.side;
            } else if (sk.s < z.sLip + 1.0f) {
                ap.forcedX = 0.5f * (z.rampX0 + z.rampX1) * z.side;
            } else {
                ap.forcedX = 1e9f;
            }
        }
        sk.step(ap.compute(tr, none, sk), tr, dt);
        if (wasAir && !sk.airborne && !sk.crashed && sk.lastLandKind == Track::kDeck) r.deck = true;
        wasAir = sk.airborne;
        r.t += dt;
        if (sk.crashed) { r.crashed = true; break; }
    }
    return r;
}

static void testJumps() {
    std::printf("kicker jumps\n");
    int total = 0, good = 0, compared = 0;
    double saved = 0.0;
    for (uint32_t seed = 1; seed <= 12; ++seed) {
        Track tr(seed * 7919u + 13u);
        tr.ensureGenerated(4000.0f);
        for (const ShortcutZone& z : tr.shortcuts()) {
            for (float v : {14.0f, 18.0f, 22.0f, 26.0f}) {
                const JumpResult a = ride(tr, z, v, true), b = ride(tr, z, v, false);
                ++total;
                if (a.deck && !a.crashed) {
                    ++good;
                    if (!b.crashed) { saved += b.t - a.t; ++compared; }
                }
            }
        }
    }
    const double rate = total ? static_cast<double>(good) / total : 0.0;
    const double mean = compared ? saved / compared : 0.0;
    std::printf("  %d/%d jumps landed on the deck and rode it out; the deck saves %.2f s on average\n", good, total, mean);
    CHECK(total >= 100, "enough jumps tested: %d", total);
    CHECK(rate >= 0.97, "landing rate %.3f", rate);
    CHECK(mean > 0.6, "the shortcut must be faster: %.2f s", mean);
}

static void testFinishLine() {
    std::printf("finish line and simultaneous start\n");
    int finished = 0;
    for (uint32_t seed = 1; seed <= 4; ++seed) {
        Game g;
        g.startRunSeeded(seed, 0.0f, 400.0f);
        g.autopilot() = AutoPilot();
        const float dt = 1.0f / 60.0f;
        float t = 0.0f;
        bool wasFinished = false;
        while (t < 120.0f && g.phase() != Phase::GameOver) {
            SkaterInput in;
            if (g.phase() == Phase::Running) in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
            g.update(dt, in);
            if (g.finished()) wasFinished = true;
            t += dt;
        }
        if (wasFinished) {
            ++finished;
            CHECK(g.goalMeters() == 400.0f && g.finishTime() > 12.0f && g.finishTime() < 90.0f, "finish time %.1f", g.finishTime());
            CHECK(g.riderNet().finished && std::fabs(g.riderNet().finishTime - g.finishTime()) < 1e-3f, "the finish travels with the rider's network state");
            CHECK(g.phase() == Phase::GameOver && !g.skater().crashed, "the standings come up after the finish");
        }
    }
    CHECK(finished >= 3, "%d of 4 autopilot runs reached a 400 m finish line", finished);

    // A START that arrives 1.2 s late: that phone's countdown is fast-forwarded and its GO is simultaneous with the host's
    Game host, late;
    host.startRunSeeded(5, 0.0f, 1000.0f);
    late.startRunSeeded(5, 1.2f, 1000.0f);
    const float dt = 1.0f / 60.0f;
    int goHost = -1, goLate = -1;
    for (int i = 0; i < 60 * 6; ++i) {
        host.update(dt, SkaterInput());
        late.update(dt, SkaterInput());
        if (goHost < 0 && host.phase() == Phase::Running) goHost = i;
        if (goLate < 0 && late.phase() == Phase::Running) goLate = i;
    }
    CHECK(goHost > 0 && goLate > 0, "both reach GO");
    CHECK(std::fabs(static_cast<float>(goHost - goLate) * dt - 1.2f) < 0.05f, "GO of the late phone is 1.2 s earlier than a phone that started on time: %d vs %d frames", goLate, goHost);
    Game absurd;
    absurd.startRunSeeded(5, 500.0f, 0.0f);   // a lag outside any sane range is clamped
    absurd.update(dt, SkaterInput());
    CHECK(absurd.phase() == Phase::Countdown || absurd.phase() == Phase::Running, "absurd lag is harmless");
}

int main() {
    testMeshBudget();
    testZones();
    testJumps();
    testFinishLine();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fails);
    return g_fails == 0 ? 0 : 1;
}
