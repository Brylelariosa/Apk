// render_traffic: the autopilot rides through the traffic and the tool saves screenshots of the interesting moments - cars ahead,
// brake lights, indicators and cars waiting at cone tapers (headless software GLES 3 via Mesa EGL, surfaceless).
//   ./render_traffic [width height outDir]
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

#include "game.h"
#include "renderer.h"
#include "scene_builder.h"

using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            const unsigned char* s = &px[((h - 1 - y) * w + x) * 4];
            unsigned char* d = &out[(y * w + x) * 3];
            d[0] = s[0]; d[1] = s[1]; d[2] = s[2];
        }
    FILE* f = std::fopen(path, "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
    std::fwrite(out.data(), 1, out.size(), f);
    std::fclose(f);
}

int main(int argc, char** argv) {
    const int W = argc > 1 ? std::atoi(argv[1]) : 1400;
    const int H = argc > 2 ? std::atoi(argv[2]) : 630;
    const char* dir = argc > 3 ? argv[3] : "/tmp/traffic";

    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min;
    eglInitialize(dpy, &maj, &min);
    eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
                         EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg;
    EGLint n;
    eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);

    Renderer r;
    r.setQualityTier(3);
    r.onContextCreated();
    r.onResize(W, H);
    if (!r.ready()) { std::fprintf(stderr, "renderer not ready\n"); return 2; }

    enum { kCarAhead, kBraking, kSignal, kWaiting, kShotKinds };
    const char* names[kShotKinds] = {"car", "brake", "signal", "waiting"};
    int taken[kShotKinds] = {0, 0, 0, 0};
    const int want = 3;
    const float dt = 1.0f / 60.0f;

    for (uint32_t seed = 1; seed <= 14; ++seed) {
        Game g;
        g.setBaseSeed(seed * 1000 + 17);
        g.startRun();
        float t = 0.0f, lastShot = -99.0f;
        while (t < 240.0f && g.phase() != Phase::GameOver) {
            SkaterInput in;
            if (g.phase() == Phase::Running) in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
            g.update(dt, in);
            t += dt;
            if (g.phase() != Phase::Running || t - lastShot < 4.0f) continue;
            const Skater& sk = g.skater();
            int kind = -1;
            for (const Obstacle& o : g.world().obstacles()) {
                if (o.kind != ObstacleKind::Car) continue;
                const float ahead = o.s - sk.s;
                if (ahead < 12.0f || ahead > 55.0f) continue;
                if (o.car.waiting && o.car.speed < 0.5f && taken[kWaiting] < want) kind = kWaiting;
                else if (o.car.signal != 0 && std::fabs(o.car.vx) > 0.2f && taken[kSignal] < want) kind = kSignal;
                else if (o.car.brake > 0.7f && taken[kBraking] < want) kind = kBraking;
                else if (taken[kCarAhead] < want && ahead < 28.0f) kind = kCarAhead;
                if (kind >= 0) break;
            }
            if (kind < 0) continue;
            SceneGeometry geo;
            FrameParams fp = buildScene(g, 1.0f, geo);
            UiBatch ui;
            ui.setScreen(static_cast<float>(W), static_cast<float>(H));
            r.render(fp, geo, ui);
            char path[256];
            std::snprintf(path, sizeof(path), "%s/%s_%d.ppm", dir, names[kind], taken[kind]);
            savePPM(path, W, H);
            std::fprintf(stderr, "wrote %s (seed %u, t=%.0f s)\n", path, seed, t);
            ++taken[kind];
            lastShot = t;
        }
        bool done = true;
        for (int k = 0; k < kShotKinds; ++k) done = done && taken[k] >= want;
        if (done) break;
    }
    return 0;
}
