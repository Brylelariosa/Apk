// render_models: close-up studio shots of the procedural models (rider + longboard poses, every car type) through the real renderer
// (headless software GLES 3 via Mesa EGL, surfaceless), so the artwork can be reviewed without a phone.
//   ./render_models [width height outDir]
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

#include "atmosphere.h"
#include "mesh_library.h"
#include "renderer.h"
#include "skater_model.h"

using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            const unsigned char* s = &px[((h - 1 - y) * w + x) * 4];
            unsigned char* d = &out[(y * w + x) * 3];
            d[0] = s[0]; d[1] = s[1]; d[2] = s[2];
        }
    FILE* f = std::fopen(path, "wb");
    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
    std::fwrite(out.data(), 1, out.size(), f);
    std::fclose(f);
}

namespace {

struct Shot {
    const char* name;
    Vec3 target;        // look-at point (world)
    float yawDeg;       // camera azimuth around the target: 0 = behind the model (looking along +Z), 90 = from its left side...
    float pitchDeg;     // camera elevation
    float dist;
    float fov;
};

void render(Renderer& r, int W, int H, const char* dir, const Shot& s, const SceneGeometry& geoWorld, const Atmosphere& atmo, float sunAz) {
    const float yaw = s.yawDeg * kDeg2Rad, pitch = s.pitchDeg * kDeg2Rad;
    // camera sits on a sphere around the target, looking at it
    const Vec3 offset(-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch));
    CameraView cam;
    cam.pos = s.target + offset * s.dist;
    cam.fwd = normalize(s.target - cam.pos);
    cam.right = normalize(cross(cam.fwd, Vec3(0, 1, 0)));
    cam.up = normalize(cross(cam.right, cam.fwd));
    cam.fovY = s.fov;
    // the geometry was built around the origin (absolute = world); make it camera-relative
    SceneGeometry geo;
    geo.clear();
    geo.dynamicMesh.append(geoWorld.dynamicMesh, Mat4::translation(-cam.pos));
    for (int b = 0; b < kBatchCount; ++b)
        for (Instance i : geoWorld.instances[b]) {
            i.x -= cam.pos.x; i.y -= cam.pos.y; i.z -= cam.pos.z;
            geo.instances[b].push_back(i);
        }
    FrameParams fp;
    fp.cam = cam;
    fp.atmo = atmo;
    fp.time = 1.0f;
    fp.speed01 = 0.0f;
    fp.shadowFocus = s.target;
    UiBatch ui;
    ui.setScreen(static_cast<float>(W), static_cast<float>(H));
    r.render(fp, geo, ui);
    char path[256];
    std::snprintf(path, sizeof(path), "%s/%s.ppm", dir, s.name);
    savePPM(path, W, H);
    std::fprintf(stderr, "wrote %s\n", s.name);
    (void)sunAz;
}

SkaterPose basePose() {
    SkaterPose p;
    p.origin = Vec3(0, 0, 0);
    p.right = Vec3(1, 0, 0);
    p.up = Vec3(0, 1, 0);
    p.fwd = Vec3(0, 0, 1);
    p.roadUp = Vec3(0, 1, 0);
    p.time = 1.0f;
    return p;
}

void ground(MeshData& m) {
    const Rgba8 asphalt = rgba(0.20f, 0.19f, 0.22f);
    m.addBox(Mat4::translation(Vec3(0, -0.06f, 0)), Vec3(30.0f, 0.06f, 30.0f), asphalt, asphalt);
}

}  // namespace

int main(int argc, char** argv) {
    const int W = argc > 1 ? std::atoi(argv[1]) : 1200;
    const int H = argc > 2 ? std::atoi(argv[2]) : 800;
    const char* dir = argc > 3 ? argv[3] : "/tmp/models";

    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min;
    eglInitialize(dpy, &maj, &min);
    eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
                         EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg;
    EGLint n;
    eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);

    Renderer r;
    r.setQualityTier(3);
    r.onContextCreated();
    r.onResize(W, H);
    if (!r.ready()) { std::fprintf(stderr, "renderer not ready\n"); return 2; }
    const float sunAz = argc > 4 ? static_cast<float>(std::atof(argv[4])) * kDeg2Rad : 3.4f;
    const Atmosphere atmo = makeAtmosphere(0.05f, sunAz);

    // ---- rider poses
    struct PoseDef { const char* name; SkaterPose p; };
    std::vector<PoseDef> poses;
    { SkaterPose p = basePose(); poses.push_back({"stand", p}); }
    { SkaterPose p = basePose(); p.tuck = 1.0f; poses.push_back({"tuck", p}); }
    { SkaterPose p = basePose(); p.lean = 0.35f; p.tuck = 0.3f; poses.push_back({"lean", p}); }
    { SkaterPose p = basePose(); p.slide = 1.0f; p.slideDir = 1.0f; p.slip = 1.1f; p.tuck = 0.6f; poses.push_back({"slide", p}); }
    { SkaterPose p = basePose(); p.push = 1.0f; p.pushPhase = 0.35f; poses.push_back({"push", p}); }
    { SkaterPose p = basePose(); p.crashed = true; p.crashTime = 0.55f; p.crashSpeed = 12.0f; poses.push_back({"crash", p}); }
    const Shot riderShots[] = {
        {"back", Vec3(0, 0.95f, 0), 0, 8, 4.2f, 0.62f},
        {"back34", Vec3(0, 0.95f, 0), 35, 10, 4.2f, 0.62f},
        {"side", Vec3(0, 0.95f, 0), 90, 6, 4.4f, 0.62f},
        {"front34", Vec3(0, 0.95f, 0), 150, 12, 4.2f, 0.62f},
    };
    for (const PoseDef& pd : poses) {
        SceneGeometry g;
        g.clear();
        ground(g.dynamicMesh);
        buildSkaterMesh(pd.p, g.dynamicMesh);
        for (const Shot& base : riderShots) {
            if (pd.p.crashed && base.yawDeg == 0) continue;
            Shot s = base;
            char name[96];
            std::snprintf(name, sizeof(name), "rider_%s_%s", pd.name, base.name);
            s.name = name;
            if (pd.p.crashed) s.target = Vec3(0, 0.5f, 2.0f);
            render(r, W, H, dir, s, g, atmo, sunAz);
        }
    }

    // ---- cars: one lineup per direction, every car batch side by side
    {
        SceneGeometry g;
        g.clear();
        ground(g.dynamicMesh);
        int count = 0;
        count = kCarBatchCount;
        const Rgba8 paints[] = {{214, 60, 52, 255}, {70, 120, 200, 255}, {232, 200, 70, 255}, {90, 170, 120, 255}, {230, 230, 235, 255}, {60, 60, 70, 255}};
        for (int k = 0; k < count; ++k) {
            Instance i{};
            i.x = (static_cast<float>(k) - (count - 1) * 0.5f) * 3.6f;
            i.y = 0.0f;
            i.z = 0.0f;
            i.yaw = kPi;   // the model's nose is -Z: turn it to face +Z like the rider
            i.sx = 1.0f; i.sy = 1.0f;
            const Rgba8 c = paints[k % 6];
            i.r = c.r; i.g = c.g; i.b = c.b; i.a = 0;
            g.instances[kBatchCar + k].push_back(i);
        }
        const Shot carShots[] = {
            {"cars_rear34", Vec3(0, 0.8f, 0), 30, 12, 14.0f * (count > 3 ? 1.0f : 0.7f), 0.55f},
            {"cars_front34", Vec3(0, 0.8f, 0), 155, 12, 14.0f * (count > 3 ? 1.0f : 0.7f), 0.55f},
            {"cars_side", Vec3(0, 0.8f, 0), 90, 4, 15.0f * (count > 3 ? 1.0f : 0.7f), 0.55f},
        };
        for (const Shot& s : carShots) render(r, W, H, dir, s, g, atmo, sunAz);
        // single car close-ups
        for (int k = 0; k < count; ++k) {
            SceneGeometry one;
            one.clear();
            ground(one.dynamicMesh);
            Instance i = g.instances[kBatchCar + k][0];
            i.x = 0.0f;
            one.instances[kBatchCar + k].push_back(i);
            char a[64], b[64];
            std::snprintf(a, sizeof(a), "car%d_rear34", k);
            std::snprintf(b, sizeof(b), "car%d_front34", k);
            render(r, W, H, dir, Shot{a, Vec3(0, 0.8f, 0), 30, 14, 7.0f, 0.55f}, one, atmo, sunAz);
            render(r, W, H, dir, Shot{b, Vec3(0, 0.8f, 0), 150, 14, 7.0f, 0.55f}, one, atmo, sunAz);
        }
    }
    return 0;
}
