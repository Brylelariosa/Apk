// test_traffic: lets the drivers loose on long stretches of road (the rider cruises through the traffic) and checks that they
// behave: no car ever overlaps a cone, a rock or another car, they stay on the road, nobody gets stuck for good, and the interesting
// manoeuvres (steering around obstacles, overtaking, waiting for oncoming traffic) actually happen.
//   ./test_traffic [seconds-per-seed] [seed-count] [weave]     (weave: the rider swings across both lanes - the worst case for drivers)
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <set>
#include <utility>
#include <vector>

#include "world.h"

using namespace sd;

namespace {

struct CarLog {
    float maxOffLane = 0.0f;     // furthest the car got from the centre of its lane
    float maxWait = 0.0f;        // longest time it stood still
    float minSpeed = 99.0f, maxSpeed = 0.0f;
    bool signalled = false;
    bool braked = false;
    int kind = 0;
};

bool overlap(const Obstacle& a, const Obstacle& b, float slack) {
    return std::fabs(a.x - b.x) < a.hx + b.hx - slack && std::fabs(a.s - b.s) < a.hs + b.hs - slack;
}

}  // namespace

int main(int argc, char** argv) {
    const float seconds = argc > 1 ? static_cast<float>(std::atof(argv[1])) : 360.0f;
    const int seeds = argc > 2 ? std::atoi(argv[2]) : 6;
    const float dt = 1.0f / 60.0f;
    const float riderSpeed = 17.0f;
    const bool weave = argc > 3;

    long carStatic = 0, carCar = 0, nonFinite = 0, offRoad = 0;
    std::set<std::pair<uint32_t, uint32_t>> staticPairs, carPairs;
    std::map<uint32_t, CarLog> cars;
    int firstReports = 0, longWaitReports = 0;
    long steps = 0;

    for (int seed = 1; seed <= seeds; ++seed) {
        World w(static_cast<uint32_t>(seed) * 7919u);
        w.setObstaclesEnabled(true);
        float s = 20.0f;
        const long n = static_cast<long>(seconds / dt);
        for (long i = 0; i < n; ++i) {
            s += riderSpeed * dt;
            PlayerRef p;
            p.s = s; p.x = weave ? 1.8f * std::cos(0.25f * static_cast<float>(i) * dt) : 1.8f; p.speed = riderSpeed; p.active = true;
            w.update(dt, p);
            ++steps;
            const std::vector<Obstacle>& obs = w.obstacles();
            for (size_t a = 0; a < obs.size(); ++a) {
                const Obstacle& c = obs[a];
                if (c.kind != ObstacleKind::Car) continue;
                CarLog& log = cars[c.id + static_cast<uint32_t>(seed) * 1000000u];
                log.maxOffLane = std::max(log.maxOffLane, std::fabs(c.x - c.car.laneX));
                if (c.car.waitT > 12.0f && log.maxWait <= 12.0f && longWaitReports++ < 6) {
                    // what is the car waiting for? list the nearest things around it
                    std::printf("  long wait seed %d t=%.1f: car %u dir=%.0f s=%.1f x=%.2f lane=%.2f target=%.2f free=%.1f\n", seed, static_cast<float>(i) * dt, c.id, c.car.dir,
                                c.s, c.x, c.car.laneX, c.car.targetX, c.car.freeAhead);
                    for (const Obstacle& o : obs) {
                        const float ahead = c.car.dir * (o.s - c.s);
                        if (&o == &c || ahead < -15.0f || ahead > 200.0f) continue;
                        std::printf("      %s at %+.1f m ahead, x=%.2f, v=%.1f dir=%.0f%s\n", o.kind == ObstacleKind::Cone ? "cone" : o.kind == ObstacleKind::Rock ? "rock" : "car ", ahead, o.x,
                                    o.kind == ObstacleKind::Car ? o.car.speed : 0.0f, o.kind == ObstacleKind::Car ? o.car.dir : 0.0f, o.hit ? " (hit)" : "");
                    }
                }
                log.maxWait = std::max(log.maxWait, c.car.waitT);
                log.minSpeed = std::min(log.minSpeed, c.car.speed);
                log.maxSpeed = std::max(log.maxSpeed, c.car.speed);
                log.signalled = log.signalled || c.car.signal != 0;
                log.braked = log.braked || c.car.brake > 0.5f;
                if (!std::isfinite(c.x) || !std::isfinite(c.s) || !std::isfinite(c.car.speed) || !std::isfinite(c.yaw)) ++nonFinite;
                if (std::fabs(c.x) > 3.4f) ++offRoad;
                for (size_t b = 0; b < obs.size(); ++b) {
                    if (a == b) continue;
                    const Obstacle& o = obs[b];
                    if (o.hit) continue;
                    if (o.kind == ObstacleKind::Car) {
                        if (b < a || !overlap(c, o, 0.05f)) continue;
                        ++carCar;
                        const auto key = std::make_pair(std::min(c.id, o.id) + seed * 1000000u, std::max(c.id, o.id) + seed * 1000000u);
                        if (carPairs.insert(key).second && firstReports++ < 6)
                            std::printf("  car/car overlap seed %d t=%.1f: car %u (s=%.1f x=%.2f v=%.1f dir=%.0f) vs car %u (s=%.1f x=%.2f v=%.1f dir=%.0f)\n", seed,
                                        static_cast<float>(i) * dt, c.id, c.s, c.x, c.car.speed, c.car.dir, o.id, o.s, o.x, o.car.speed, o.car.dir);
                    } else if (overlap(c, o, 0.05f)) {
                        ++carStatic;
                        if (staticPairs.insert(std::make_pair(c.id + seed * 1000000u, o.id + seed * 1000000u)).second && firstReports++ < 6)
                            std::printf("  car/%s overlap seed %d t=%.1f: car %u (s=%.1f x=%.2f v=%.1f dir=%.0f target=%.2f vx=%.2f) vs obstacle (s=%.1f x=%.2f)\n", o.kind == ObstacleKind::Cone ? "cone" : "rock",
                                        seed, static_cast<float>(i) * dt, c.id, c.s, c.x, c.car.speed, c.car.dir, c.car.targetX, c.car.vx, o.s, o.x);
                    }
                }
            }
        }
    }

    int total = 0, changedLane = 0, signalled = 0, braked = 0, stopped = 0, longWait = 0, sameDir = 0;
    float worstWait = 0.0f;
    for (const auto& kv : cars) {
        const CarLog& l = kv.second;
        ++total;
        changedLane += l.maxOffLane > 1.2f;
        signalled += l.signalled;
        braked += l.braked;
        stopped += l.minSpeed < 0.3f;
        longWait += l.maxWait > 15.0f;
        worstWait = std::max(worstWait, l.maxWait);
        (void)sameDir;
    }
    std::printf("simulated %ld steps over %d seeds; %d cars seen\n", steps, seeds, total);
    std::printf("  overlaps: car/cone-or-rock %ld steps (%zu pairs), car/car %ld steps (%zu pairs), non-finite %ld, off-road steps %ld\n", carStatic, staticPairs.size(),
                carCar, carPairs.size(), nonFinite, offRoad);
    std::printf("  behaviour: %d changed lane (>1.2 m off their lane centre), %d signalled, %d used the brakes, %d came to a stop, %d waited > 15 s (worst %.1f s)\n",
                changedLane, signalled, braked, stopped, longWait, worstWait);
    const bool ok = carStatic == 0 && carCar == 0 && nonFinite == 0 && offRoad == 0;
    std::printf(ok ? "traffic OK\n" : "traffic FAILED\n");
    return ok ? 0 : 1;
}
