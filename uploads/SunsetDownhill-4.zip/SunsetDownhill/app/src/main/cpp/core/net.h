// net.h - LAN multiplayer: find a race on the local Wi-Fi, join it, start together and see each other ride.
//
// Everything runs on UDP datagrams polled from the game thread (no threads, no locks). One phone HOSTS a lobby and advertises it with a
// broadcast beacon; the others SEARCH, pick a host and JOIN. The host assigns slots (0 = host), starts the race for everybody with a shared
// course seed, and relays every rider's state to the others (a star: only the host's address matters, so it also works on a phone hotspot).
// Every phone simulates its own rider; the others are drawn from the interpolated state they broadcast. Cones and rocks come from the
// seed, so everybody rides the same road; the cars are local to each phone. No rider-to-rider collisions.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "rider_net.h"

namespace sd {

constexpr int kNetMaxPlayers = 6;
constexpr int kNetNameLen = 14;
constexpr uint16_t kNetDefaultPort = 47825;

enum class NetRole : uint8_t { Off, Host, Searching, Joined };
enum class PeerPhase : uint8_t { Lobby = 0, Racing = 1, Finished = 2 };

struct NetPlayer {
    bool present = false;
    bool self = false;
    char name[kNetNameLen + 1] = {};
    PeerPhase phase = PeerPhase::Lobby;
    int score = 0;
    float distance = 0.0f;
    float s = 0.0f;             // position on the road (the finish line is a road position)
    bool crashed = false;
    bool crossed = false;       // crossed the finish line
    float finishTime = 0.0f;    // seconds from GO
};

struct FoundHost {
    char name[kNetNameLen + 1] = {};
    int players = 0, maxPlayers = kNetMaxPlayers;
    bool racing = false;
    uint32_t ip = 0;       // host byte order
    uint16_t port = 0;
    uint32_t lobbyId = 0;
    double lastSeen = 0.0;
};

struct NetConfig {
    uint16_t port = kNetDefaultPort;
    struct Target {
        uint32_t ip;       // host byte order
        uint16_t port;
    };
    // Where the host's beacon goes. Empty = the broadcast address of every network interface of the device.
    std::vector<Target> discoveryTargets;
};

class LanSession {
public:
    explicit LanSession(const NetConfig& config = NetConfig());
    ~LanSession();
    LanSession(const LanSession&) = delete;
    LanSession& operator=(const LanSession&) = delete;

    // ---- lifecycle
    bool host(const std::string& playerName);     // open a lobby others can find
    bool search(const std::string& playerName);   // look for lobbies on the network
    bool join(int hostIndex);                     // join one of hosts()
    void leave();                                 // close everything (the others are told)
    void update(float dt);                        // poll the socket, send, resend, time out - call every frame

    // ---- state of the connection
    NetRole role() const { return role_; }
    const std::string& error() const { return error_; }   // short reason when something failed, "" otherwise
    void clearError() { error_.clear(); }
    bool joining() const { return joining_; }
    bool inRoom() const { return role_ == NetRole::Host || (role_ == NetRole::Joined && selfSlot_ >= 0); }
    bool isHost() const { return role_ == NetRole::Host; }
    int selfSlot() const { return inRoom() ? selfSlot_ : -1; }
    const std::vector<FoundHost>& hosts() const { return hosts_; }
    const NetPlayer* players() const { return players_; }   // kNetMaxPlayers entries
    int playerCount() const;
    bool roomRacing() const { return roomRacing_; }
    std::vector<std::string> localAddresses() const;        // for the screen, e.g. "192.168.1.23"
    double clock() const { return clock_; }

    // ---- racing together
    bool canStart() const;                         // host: nobody is mid-race
    bool startRace();                              // host: start for everybody (a seed is chosen)
    bool takeStart(uint32_t& seed);                // everyone: true once per race start
    // Same, and also says how many seconds ago the host pressed START (so the countdown ends at the same moment on every phone).
    bool takeStart(uint32_t& seed, float& lagSeconds);
    void setGoal(float meters);                    // host: finish line distance for the next race (0 = endless run)
    float goal() const { return goal_; }           // finish line of the current race (0 = none)
    double raceTime() const { return clock_ - raceT0_; }   // seconds since GO on the host's timeline
    bool clockSynced() const { return role_ == NetRole::Host || offsetValid_; }
    void setLocal(const RiderNet& me, PeerPhase phase);   // what to tell the others about this rider (call every frame)
    bool sampleRider(int slot, RiderNet& out) const;      // smoothed state of another rider
    bool riderKnown(int slot) const;

private:
    struct Peer {                                   // host side: who is behind a slot
        uint32_t ip = 0;
        uint16_t port = 0;
        double lastHeard = 0.0;
        uint32_t nonce = 0;
    };
    struct Snap {
        double t = 0.0;                            // sender's race time when it sent this state
        RiderNet r;
    };
    struct Remote {
        Snap snaps[16];
        int count = 0, head = 0;                   // ring buffer
        bool init = false;
        float slackEma = 0.0f, jit = 0.01f;        // arrival slack and its jitter -> how far in the past this rider is drawn
        float delay = 0.09f;
    };
    struct PingSample {
        float rtt = 0.0f;
        double offset = 0.0;                       // host clock - my clock
    };

    bool open();
    void closeSocket();
    void reset(NetRole role);
    void fail(const char* why);

    void receiveAll();
    void handle(const uint8_t* data, size_t len, uint32_t ip, uint16_t port);
    void onBeacon(const uint8_t* p, size_t n, uint32_t ip, uint16_t port);
    void onJoin(uint8_t slotField, const uint8_t* p, size_t n, uint32_t ip, uint16_t port);
    void onState(uint8_t slot, const uint8_t* all, size_t len, const uint8_t* p, size_t n, uint32_t ip, uint16_t port);
    void pushSnap(int slot, const RiderNet& r, double ts);
    void sendPong(uint32_t ip, uint16_t port, double stamp);
    void addPing(float rtt, double offset);

    void hostTick(float dt);
    void clientTick(float dt);
    void sendBeacon();
    void sendRoster();
    void sendJoin();
    void sendKeepAlive();
    void sendStart(uint32_t ip, uint16_t port);
    void sendOwnState();
    void sendToPeers(const uint8_t* data, size_t len, int exceptSlot);
    void sendTo(uint32_t ip, uint16_t port, const uint8_t* data, size_t len);
    void removePeer(int slot);
    int slotOf(uint32_t ip, uint16_t port) const;
    int freeSlot() const;
    uint32_t random32();

    NetConfig cfg_;
    int sock_ = -1;
    NetRole role_ = NetRole::Off;
    std::string error_;
    std::string name_;
    double clock_ = 0.0;
    uint32_t rngState_ = 0x9E3779B9u;

    NetPlayer players_[kNetMaxPlayers];
    Peer peers_[kNetMaxPlayers];
    Remote remote_[kNetMaxPlayers];
    int selfSlot_ = -1;
    uint32_t lobbyId_ = 0;
    bool roomRacing_ = false;
    double raceStartedAt_ = 0.0;
    double raceT0_ = 0.0;          // my clock at the moment race time was 0 (GO of the host's countdown)
    float goal_ = 0.0f;            // finish line of the current race
    float hostGoal_ = 2000.0f;     // host: what the next race will use
    float pendingLag_ = 0.0f;

    // host
    float beaconTimer_ = 0.0f, rosterTimer_ = 0.0f;
    bool rosterDirty_ = false;
    int startRepeats_ = 0;
    float startTimer_ = 0.0f;
    uint32_t raceId_ = 0, raceSeed_ = 0;

    // client
    std::vector<FoundHost> hosts_;
    bool joining_ = false;
    uint32_t hostIp_ = 0;
    uint16_t hostPort_ = 0;
    uint32_t joinNonce_ = 0;
    float joinTimer_ = 0.0f, joinAge_ = 0.0f;
    double lastHostHeard_ = 0.0;
    float keepAliveTimer_ = 0.0f;
    uint32_t lastStartRace_ = 0;
    PingSample pings_[8];
    int pingCount_ = 0, pingHead_ = 0, pingBurst_ = 0;
    float pingTimer_ = 0.0f;
    double hostOffset_ = 0.0;      // host clock - my clock, from the best round trip
    bool offsetValid_ = false;

    // shared
    bool pendingStart_ = false;
    uint32_t pendingSeed_ = 0;
    RiderNet local_;
    PeerPhase localPhase_ = PeerPhase::Lobby;
    float stateTimer_ = 0.0f;
    uint16_t stateSeq_ = 0;
};

}  // namespace sd
