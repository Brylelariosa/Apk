// track.h - procedural mountain road: centre line, frames, curvature, terrain profile.
#pragma once

#include <cstdint>
#include <vector>

#include "config.h"
#include "math3d.h"
#include "rng.h"

namespace sd {

struct TrackSample {
    Vec3 pos;          // road centre line (road surface)
    Vec3 fwd;          // unit tangent, includes pitch
    Vec3 right0;       // horizontal right vector (unbanked)
    Vec3 up0;          // unbanked surface normal
    Vec3 right, up;    // banked frame
    float s = 0.0f;
    float heading = 0.0f;    // yaw, + turns right
    float pitch = 0.0f;      // + descends
    float curvature = 0.0f;  // 1/m, + right turn
    float bank = 0.0f;       // + lowers the right edge
};

// A cliff jump. On the inside of a long bend whose inside is the downhill side there is a kicker at the edge of the road and, below the
// cliff, a shortcut road on stilts: it starts with a wide landing platform some way down, hugs the inside of the bend (a shorter way
// round), and merges back into the road. Everything is a pure function of the seed, so every phone in a LAN race has the same ones.
struct ShortcutZone {
    float side = 1.0f;                    // +1 right, -1 left: the inside of the bend = the cliff side
    float sRamp0 = 0.0f, sLip = 0.0f;     // the kicker: where it starts and its lip
    float rampX0 = 2.6f, rampX1 = 5.1f;   // its lateral extent (measured toward the cliff side)
    float lipHeight = 1.25f;
    float sDeck0 = 0.0f, sDeck1 = 0.0f;   // the shortcut road: landing platform ... where it has merged into the road again
    float drop = 0.0f;                    // how far below the road the landing platform lies
    std::vector<float> c, hw, h;          // per ring from sDeck0: lateral centre (toward the cliff side), half width, height above the road plane
    void deckAt(float s, float& centre, float& halfWidth, float& height) const;
    float rampHeight(float s, float xs) const;   // xs = lateral position toward the cliff side
};

class Track {
public:
    enum Surface { kVoid = 0, kRoad = 1, kKicker = 2, kDeck = 3 };

    explicit Track(uint32_t seed = 1u);
    void reset(uint32_t seed);
    uint32_t seed() const { return seed_; }

    void ensureGenerated(float sMax);
    float generatedLength() const { return samples_.empty() ? 0.0f : samples_.back().s; }
    int sampleCount() const { return static_cast<int>(samples_.size()); }
    const TrackSample& sampleAt(int i) const { return samples_[static_cast<size_t>(i)]; }

    // Interpolated frame at distance s (clamped to the generated range).
    TrackSample at(float s) const;

    float curvatureAt(float s) const;
    float pitchAt(float s) const;
    float difficultyAt(float s) const;
    float hillBias(float s) const;   // -1..1, + means the right side is the uphill side

    static float bankDrop(float lateral, float bank);
    static float insideLimit(float curvature);

    // Height of the terrain above the road plane at lateral offset d.
    float terrainHeight(float s, float d) const;
    // World position of terrain-mesh vertex (ring, column).
    Vec3 ringVertex(int ring, int col) const;
    // World position on the terrain mesh at (s, d), consistent with the rendered mesh.
    Vec3 terrainPoint(float s, float d) const;
    // Point on the banked road surface at lateral offset, plus a height above it.
    static Vec3 surfacePoint(const TrackSample& f, float lateral, float height = 0.0f);

    // ---- cliff jumps (see ShortcutZone)
    const std::vector<ShortcutZone>& shortcuts() const { return zones_; }
    const ShortcutZone* zoneAt(float s) const;   // the zone whose kicker / deck is near s, or null
    // Height (above the road plane) of whatever carries a rider at (s, x); `kind` says what it is. Where nothing does, the terrain.
    float supportHeight(float s, float x, int* kind = nullptr) const;
    // How far a grounded rider on `kind` may go to either side (the rails), including the gaps at the kicker and the merge.
    void lateralWindow(float s, int kind, float* lo, float* hi) const;
    bool railGap(float s, float side) const;   // no guard rail here on that side (kicker, merge)
    bool shortcutBlocks(float s, float d, float margin) const;   // trees and rocks keep out of the kicker, flight path and deck

private:
    struct Segment {
        float s0, len, k;   // start, length, peak curvature (0 = straight)
        bool jump = false;  // a tight bend on a cliff: it gets a kicker and a shortcut road (see ShortcutZone)
    };

    void generateNext();
    void planUntil(float sTarget);
    void planShortcuts();
    float carve(float s, float d, float h) const;
    static void buildFrame(TrackSample& t);

    uint32_t seed_ = 1u;
    Rng rng_;
    std::vector<TrackSample> samples_;
    std::vector<Segment> segments_;
    std::vector<ShortcutZone> zones_;
    size_t scanIdx_ = 0;
    float lastJumpBend_ = -1e6f;
    float planEnd_ = 0.0f;
    float planHeading_ = 0.0f;
    float lastDir_ = 1.0f;
    bool lastWasStraight_ = true;
    float phase_[6] = {0, 0, 0, 0, 0, 0};
};

}  // namespace sd
