// ui_font.h - monoline stroke font (digits, A-Z and a little punctuation) rendered from a signed-distance atlas.
//
// Every glyph is ONE textured quad, so translucent text never shows overlapping strokes, fades evenly, and stays crisp at any size.
#pragma once

#include <cstdint>
#include <vector>

#include "ui_batch.h"

namespace sd {

enum class TextAlign { Left, Center, Right };

// `size` is the cap height in pixels. (x, y) is the top of the text; returns the width of its ink (see textWidth).
// `halo` (0..1) adds a soft dark outline behind the glyphs for legibility; it fades together with the colour's alpha.
float drawText(UiBatch& ui, const char* text, float x, float y, float size, Rgba8 color, TextAlign align = TextAlign::Left, float halo = 0.0f);

// Width of the drawn ink: from the text origin to the right edge of the last glyph (no trailing letter spacing).
float textWidth(const char* text, float size);
// Height of the drawn ink for a cap height of `size`: the caps plus one stroke. Lets callers align baselines exactly.
inline float textHeight(float size) { return size * (1.0f + 1.05f / 6.0f); }

// The R8 atlas (kAtlasSize x kAtlasSize) that the glyph quads sample. Built on first use, then cached.
const std::vector<uint8_t>& fontAtlasPixels();

}  // namespace sd
