#include "track.h"

#include <algorithm>
#include <cmath>

namespace sd {

Track::Track(uint32_t seed) { reset(seed); }

void Track::reset(uint32_t seed) {
    seed_ = seed;
    rng_.reseed(seed * 2654435761U + 17U);
    samples_.clear();
    segments_.clear();
    zones_.clear();
    scanIdx_ = 0;
    lastJumpBend_ = -1e6f;
    planHeading_ = 0.0f;
    lastDir_ = 1.0f;
    for (float& p : phase_) p = rng_.range(0.0f, kTwoPi);

    TrackSample first;
    first.pitch = pitchAt(0.0f);
    buildFrame(first);
    samples_.push_back(first);

    segments_.push_back({0.0f, 120.0f, 0.0f});  // opening straight
    planEnd_ = 120.0f;
    lastWasStraight_ = true;
    ensureGenerated(64.0f);
}

void Track::ensureGenerated(float sMax) {
    while (generatedLength() < sMax) generateNext();
    planUntil(sMax + 320.0f);   // (the plan is a pure function of the seed, so looking further ahead changes nothing)
    planShortcuts();
}

float Track::difficultyAt(float s) const { return saturate(s / cfg::kDifficultyDistance); }

float Track::pitchAt(float s) const {
    const float d = difficultyAt(s);
    const float base = lerpf(5.2f, 7.4f, d) * kDeg2Rad;
    float p = base + 2.4f * kDeg2Rad * std::sin(s / 210.0f + phase_[0]) +
              1.5f * kDeg2Rad * std::sin(s / 77.0f + phase_[1]);
    p = std::max(p, 2.2f * kDeg2Rad);
    return p * lerpf(0.6f, 1.0f, smoothstep(0.0f, 70.0f, s));  // already rolling at the start line
}

float Track::hillBias(float s) const {
    return clampf(0.85f * std::sin(s / 380.0f + phase_[2]) + 0.35f * std::sin(s / 113.0f + phase_[3]), -1.0f, 1.0f);
}

float Track::curvatureAt(float s) const {
    if (segments_.empty()) return 0.0f;
    auto it = std::upper_bound(segments_.begin(), segments_.end(), s,
                               [](float v, const Segment& seg) { return v < seg.s0; });
    if (it == segments_.begin()) return 0.0f;
    --it;
    if (it->k == 0.0f) return 0.0f;
    const float u = (s - it->s0) / it->len;
    if (u < 0.0f || u > 1.0f) return 0.0f;
    constexpr float r = 0.25f;  // clothoid-like ramps
    float e = 1.0f;
    if (u < r) e = smoothstep(0.0f, r, u);
    else if (u > 1.0f - r) e = smoothstep(1.0f, 1.0f - r, u);
    return it->k * e;
}

void Track::planUntil(float sTarget) {
    while (planEnd_ < sTarget) {
        const float diff = difficultyAt(planEnd_);
        if (!lastWasStraight_) {
            float len = lerpf(150.0f, 55.0f, diff) * rng_.range(0.55f, 1.4f);
            if (rng_.chance(0.25f)) len *= 0.35f;  // linked corners
            segments_.push_back({planEnd_, len, 0.0f});
            planEnd_ += len;
            lastWasStraight_ = true;
        } else {
            float radius = std::max(cfg::kMinCurveRadius, lerpf(125.0f, 58.0f, diff) * rng_.range(0.8f, 1.3f));
            float angle = rng_.range(24.0f, 68.0f) * kDeg2Rad * lerpf(0.9f, 1.15f, diff);
            float dir;
            if (std::fabs(planHeading_) > 45.0f * kDeg2Rad) dir = -sign1(planHeading_);
            else dir = rng_.chance(0.72f) ? -lastDir_ : lastDir_;
            // A bend that is worth a shortcut: tighter and longer than the others, on a stretch where its inside is the downhill side (so
            // the kicker is at a real cliff). The inside lane of a bend like that is much shorter than the road.
            bool jump = false;
            if (planEnd_ > 300.0f && planEnd_ - lastJumpBend_ > 650.0f) {
                const float jr = std::max(cfg::kMinCurveRadius, 55.0f * rng_.range(0.98f, 1.08f));
                const float ja = rng_.range(95.0f, 118.0f) * kDeg2Rad;
                const float jlen = ja * jr / 0.75f;
                bool cliff = true;
                for (int i = 0; i <= 6; ++i) {
                    const float sp = planEnd_ + jlen * static_cast<float>(i) / 6.0f;
                    if (hillBias(sp) * dir > -0.06f) cliff = false;
                }
                if (cliff && rng_.chance(0.9f)) {
                    radius = jr;
                    angle = ja;
                    jump = true;
                    lastJumpBend_ = planEnd_;
                }
            }
            const float k = dir / radius;
            const float len = angle * radius / 0.75f;  // the smooth envelope averages 0.75
            segments_.push_back({planEnd_, len, k, jump});
            planEnd_ += len;
            planHeading_ += dir * angle;
            lastDir_ = dir;
            lastWasStraight_ = false;
        }
    }
}

void Track::buildFrame(TrackSample& t) {
    const float ch = std::cos(t.heading), sh = std::sin(t.heading);
    const float cp = std::cos(t.pitch), sp = std::sin(t.pitch);
    t.fwd = Vec3(sh * cp, -sp, -ch * cp);
    t.right0 = Vec3(ch, 0.0f, sh);
    t.up0 = cross(t.right0, t.fwd);
    const float cb = std::cos(t.bank), sb = std::sin(t.bank);
    t.up = t.up0 * cb + t.right0 * sb;
    t.right = t.right0 * cb - t.up0 * sb;
}

void Track::generateNext() {
    const TrackSample cur = samples_.back();
    const float step = cfg::kTrackStep;
    const float sNext = cur.s + step;
    planUntil(sNext + 8.0f);
    const float sMid = cur.s + step * 0.5f;
    const float kMid = curvatureAt(sMid);
    const float headingMid = cur.heading + kMid * step * 0.5f;
    const float pitchMid = pitchAt(sMid);

    TrackSample n;
    n.s = sNext;
    n.heading = cur.heading + kMid * step;
    n.pitch = pitchAt(sNext);
    n.curvature = curvatureAt(sNext);
    n.bank = clampf(n.curvature * 46.0f, -0.10f, 0.10f);
    const Vec3 dir(std::sin(headingMid) * std::cos(pitchMid), -std::sin(pitchMid),
                   -std::cos(headingMid) * std::cos(pitchMid));
    n.pos = cur.pos + dir * step;
    buildFrame(n);
    samples_.push_back(n);
}

TrackSample Track::at(float s) const {
    const int n = static_cast<int>(samples_.size());
    float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float f = u - static_cast<float>(i);
    if (i < 0) { i = 0; f = 0.0f; }
    if (i >= n - 1) { i = n - 2; f = 1.0f; }
    const TrackSample& a = samples_[static_cast<size_t>(i)];
    const TrackSample& b = samples_[static_cast<size_t>(i) + 1];
    TrackSample r;
    r.s = lerpf(a.s, b.s, f);
    r.pos = lerp(a.pos, b.pos, f);
    r.fwd = normalize(lerp(a.fwd, b.fwd, f));
    r.right0 = normalize(lerp(a.right0, b.right0, f));
    r.up0 = normalize(lerp(a.up0, b.up0, f));
    r.right = normalize(lerp(a.right, b.right, f));
    r.up = normalize(lerp(a.up, b.up, f));
    r.heading = lerpf(a.heading, b.heading, f);
    r.pitch = lerpf(a.pitch, b.pitch, f);
    r.curvature = lerpf(a.curvature, b.curvature, f);
    r.bank = lerpf(a.bank, b.bank, f);
    return r;
}

float Track::bankDrop(float lateral, float bank) {
    return -clampf(lateral, -cfg::kShoulderOuter, cfg::kShoulderOuter) * bank;
}

float Track::insideLimit(float curvature) {
    const float k = std::fabs(curvature);
    return k > 1e-4f ? 0.82f / k : 1e6f;
}

float Track::terrainHeight(float s, float d) const {
    const float ad = std::fabs(d);
    if (ad <= cfg::kShoulderOuter) {
        return ad > cfg::kRoadHalfWidth ? -0.04f * (ad - cfg::kRoadHalfWidth) : 0.0f;
    }
    const float away = ad - cfg::kShoulderOuter;
    const float hill = hillBias(s) * (d >= 0.0f ? 1.0f : -1.0f);  // +1: this side is the uphill side
    const float slope = lerpf(-0.52f, 0.62f, hill * 0.5f + 0.5f);
    const float limit = slope > 0.0f ? 34.0f : 30.0f;
    float h = limit * std::tanh(away * slope / limit);
    const float n = fbm2(s * 0.018f + 11.0f, ad * 0.021f, seed_, 3) - 0.5f;
    const float amp = 2.0f * smoothstep(2.0f, 14.0f, away) + 11.0f * smoothstep(18.0f, 70.0f, away);
    h += n * 2.0f * amp;
    return carve(s, d, h - 0.064f);
}

Vec3 Track::surfacePoint(const TrackSample& f, float lateral, float height) {
    return f.pos + f.right0 * lateral + f.up0 * (bankDrop(lateral, f.bank) + height);
}

Vec3 Track::ringVertex(int ring, int col) const {
    const TrackSample& f = samples_[static_cast<size_t>(ring)];
    const float dNom = cfg::kTerrainOffsets[col];
    float d = dNom;
    if ((d > 0.0f && f.curvature > 0.0f) || (d < 0.0f && f.curvature < 0.0f)) {
        const float lim = insideLimit(f.curvature);
        if (std::fabs(d) > lim) d = sign1(d) * lim;  // keep the inside of tight bends from folding over
    }
    const float h = terrainHeight(f.s, dNom);
    return f.pos + f.right0 * d + f.up0 * (bankDrop(d, f.bank) + h);
}

Vec3 Track::terrainPoint(float s, float d) const {
    const int n = static_cast<int>(samples_.size());
    const float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float fs = u - static_cast<float>(i);
    if (i < 0) { i = 0; fs = 0.0f; }
    if (i > n - 2) { i = n - 2; fs = 1.0f; }
    int j = 0;
    while (j < cfg::kTerrainCols - 2 && d > cfg::kTerrainOffsets[j + 1]) ++j;
    const float d0 = cfg::kTerrainOffsets[j], d1 = cfg::kTerrainOffsets[j + 1];
    const float fd = clampf((d - d0) / (d1 - d0), 0.0f, 1.0f);
    const Vec3 a = lerp(ringVertex(i, j), ringVertex(i, j + 1), fd);
    const Vec3 b = lerp(ringVertex(i + 1, j), ringVertex(i + 1, j + 1), fd);
    return lerp(a, b, fs);
}

// ---------------------------------------------------------------------------------------------------------------------------
// Cliff jumps
// ---------------------------------------------------------------------------------------------------------------------------

void ShortcutZone::deckAt(float s, float& centre, float& halfWidth, float& height) const {
    const int n = static_cast<int>(c.size());
    const float u = clampf((s - sDeck0) / cfg::kTrackStep, 0.0f, static_cast<float>(n - 1));
    const int i = std::min(static_cast<int>(u), n - 2);
    const float f = u - static_cast<float>(i);
    centre = lerpf(c[static_cast<size_t>(i)], c[static_cast<size_t>(i) + 1], f);
    halfWidth = lerpf(hw[static_cast<size_t>(i)], hw[static_cast<size_t>(i) + 1], f);
    height = lerpf(h[static_cast<size_t>(i)], h[static_cast<size_t>(i) + 1], f);
}

float ShortcutZone::rampHeight(float s, float xs) const {
    if (s < sRamp0 || s > sLip || xs < rampX0 || xs > rampX1) return -1e9f;
    const float u = (s - sRamp0) / (sLip - sRamp0);
    const float edge = smoothstep(0.0f, 0.45f, std::min(xs - rampX0, rampX1 - xs));   // the sides slope away: no step to ride into
    return lipHeight * std::pow(u, 1.6f) * edge;
}

void Track::planShortcuts() {
    while (scanIdx_ < segments_.size()) {
        const size_t idx = scanIdx_++;
        const Segment sg = segments_[idx];
        if (!sg.jump) continue;
        const float absK = std::fabs(sg.k), side = sg.k > 0.0f ? 1.0f : -1.0f;

        ShortcutZone z;
        z.side = side;
        z.sLip = sg.s0 + 22.0f;                 // the kicker sits where the bend is just starting
        z.sRamp0 = z.sLip - 7.0f;
        z.sDeck0 = z.sLip + 6.0f;               // the landing platform begins just beyond the lip, down in the valley
        z.sDeck1 = sg.s0 + 0.97f * sg.len;
        if (z.sDeck1 - z.sDeck0 < 60.0f) continue;
        const float step = cfg::kTrackStep;
        const int n = static_cast<int>((z.sDeck1 - z.sDeck0) / step) + 1;
        const float dCruise = clampf(0.45f / absK, 13.0f, 18.0f);   // lateral offset of the lane on the inside of the bend
        z.c.resize(static_cast<size_t>(n));
        z.hw.resize(static_cast<size_t>(n));
        z.h.resize(static_cast<size_t>(n));
        for (int i = 0; i < n; ++i) {
            const float s = z.sDeck0 + step * static_cast<float>(i);
            const float u = (s - z.sDeck0) / (z.sDeck1 - z.sDeck0);
            // The deck is described by its two edges so that neither moves sideways faster than a rider can follow: a wide landing
            // platform (7 m .. 20 m from the road's centre line), then a roomy two-lane deck on the inside of the bend, then it comes
            // back next to the road and tapers out onto it.
            const float m = smoothstep(0.04f, 0.36f, u);
            float inner = lerpf(7.0f, dCruise - 4.6f, m), outer = lerpf(20.0f, dCruise + 4.6f, m);
            const float back = smoothstep(0.40f, 0.88f, u);
            inner = lerpf(inner, 3.5f, back);
            outer = lerpf(outer, 12.2f, back);
            const float tip = smoothstep(0.86f, 1.0f, u);
            inner = lerpf(inner, 3.6f, tip);
            outer = lerpf(outer, 5.4f, tip);
            z.c[static_cast<size_t>(i)] = 0.5f * (inner + outer);
            z.hw[static_cast<size_t>(i)] = 0.5f * (outer - inner);
        }
        // Height: the deck keeps the road's slope along ITS path, which is shorter than the road's. So relative to the road it rises, and
        // it ends level with the road where it merges; the platform therefore starts `drop` metres below the road.
        std::vector<float> raw(static_cast<size_t>(n), 0.0f);
        for (int i = 0; i + 1 < n; ++i) {
            const float sm = z.sDeck0 + step * (static_cast<float>(i) + 0.5f);
            const float x = side * 0.5f * (z.c[static_cast<size_t>(i)] + z.c[static_cast<size_t>(i) + 1]);
            const float f = 1.0f - curvatureAt(sm) * x;
            const float dd = z.c[static_cast<size_t>(i) + 1] - z.c[static_cast<size_t>(i)];
            const float path = std::sqrt(step * f * step * f + dd * dd);
            raw[static_cast<size_t>(i) + 1] = raw[static_cast<size_t>(i)] + std::tan(pitchAt(sm)) * (step - path);
        }
        z.drop = raw[static_cast<size_t>(n) - 1];
        if (z.drop < 1.0f || z.drop > 7.0f) continue;   // too little to be worth the jump / too far to fall
        for (int i = 0; i < n; ++i) z.h[static_cast<size_t>(i)] = raw[static_cast<size_t>(i)] - z.drop;
        zones_.push_back(std::move(z));
    }
}

const ShortcutZone* Track::zoneAt(float s) const {
    if (zones_.empty()) return nullptr;
    auto it = std::upper_bound(zones_.begin(), zones_.end(), s + 14.0f, [](float v, const ShortcutZone& z) { return v < z.sRamp0; });
    if (it == zones_.begin()) return nullptr;
    --it;
    return (s >= it->sRamp0 - 14.0f && s <= it->sDeck1 + 16.0f) ? &*it : nullptr;
}

float Track::supportHeight(float s, float x, int* kind) const {
    float best = -1e9f;
    int bk = kVoid;
    if (std::fabs(x) <= cfg::kRailOffset + 0.05f) { best = 0.0f; bk = kRoad; }
    if (const ShortcutZone* z = zoneAt(s)) {
        const float xs = x * z->side;
        const float hr = z->rampHeight(s, xs);
        if (hr > best) { best = hr; bk = kKicker; }
        if (s >= z->sDeck0 && s <= z->sDeck1) {
            float c, hw, h;
            z->deckAt(s, c, hw, h);
            if (std::fabs(xs - c) <= hw + 0.05f && h > best + 0.001f) { best = h; bk = kDeck; }
        }
    }
    if (bk == kVoid) best = terrainHeight(s, x);   // nothing carries the rider: the ground far below
    if (kind) *kind = bk;
    return best;
}

bool Track::railGap(float s, float side) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z || z->side != side) return false;
    return (s >= z->sRamp0 - 3.0f && s <= z->sLip + 7.0f) || (s >= z->sDeck1 - 42.0f && s <= z->sDeck1 + 6.0f);
}

void Track::lateralWindow(float s, int kind, float* lo, float* hi) const {
    *lo = -cfg::kRailOffset;
    *hi = cfg::kRailOffset;
    const ShortcutZone* z = zoneAt(s);
    if (!z) return;
    // work in the zone's frame (+ toward the cliff side), then mirror back
    float inner = -cfg::kRailOffset, outer = cfg::kRailOffset;
    const bool onDeckRange = s >= z->sDeck0 && s <= z->sDeck1;
    float c = 0.0f, hw = 0.0f, h = 0.0f;
    if (onDeckRange) z->deckAt(s, c, hw, h);
    const bool merging = s >= z->sDeck1 - 42.0f && s <= z->sDeck1 + 6.0f;
    if (kind == kDeck) {
        inner = merging ? -cfg::kRailOffset : c - hw;
        outer = c + hw;
    } else {
        if (railGap(s, z->side)) outer = 1e6f;
        else if (merging && onDeckRange) outer = std::max(outer, c + hw);
    }
    if (z->side > 0.0f) { *lo = inner; *hi = outer; }
    else { *lo = -outer; *hi = -inner; }
}

bool Track::shortcutBlocks(float s, float d, float margin) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z) return false;
    const float xs = d * z->side;
    if (xs < 2.5f || s < z->sRamp0 - 6.0f || s > z->sDeck1 + 10.0f) return false;
    float far = 18.0f;   // the flight corridor in front of the platform
    if (s >= z->sDeck0 - 2.0f) {
        float c, hw, h;
        z->deckAt(s, c, hw, h);
        far = c + hw;
    }
    return xs <= far + margin;
}

// The cliff below the shortcut: the ground is cut away under the deck (and the bay the rider flies over), so the deck stands on stilts
// above a drop instead of being buried in the hillside.
float Track::carve(float s, float d, float h) const {
    const ShortcutZone* z = zoneAt(s);
    if (!z || d * z->side <= 0.0f || s < z->sDeck0 - 10.0f || s > z->sDeck1 - 8.0f) return h;
    float c, hw, hd;
    z->deckAt(s, c, hw, hd);
    const float along = smoothstep(z->sDeck0 - 10.0f, z->sDeck0 - 1.0f, s) * (1.0f - smoothstep(z->sDeck1 - 44.0f, z->sDeck1 - 8.0f, s));   // (where the deck rejoins the road there is nothing to cut)
    const float w = along * (1.0f - smoothstep(hw + 0.5f, hw + 9.0f, std::fabs(d * z->side - c)));
    return lerpf(h, std::min(h, hd - 1.6f), w);
}

}  // namespace sd
