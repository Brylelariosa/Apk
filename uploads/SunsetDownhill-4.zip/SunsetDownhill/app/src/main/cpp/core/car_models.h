// car_models.h - the traffic: five body styles (sedan, hatchback, SUV, pickup, van) built from smooth lofted shapes.
//
// Local space: the nose points to -Z, +X is the car's right, the wheels touch Y = 0. The paint is tinted per instance (Material.tint).
#pragma once

#include "mesh_data.h"

namespace sd {

enum CarType : int { kCarSedan = 0, kCarHatch, kCarSuv, kCarPickup, kCarVan, kCarTypeCount };

struct CarDims {
    float halfLength, halfWidth, height;   // body extents (collision uses these)
    float tailZ, tailX, tailY;             // centre of the right taillight (mirror x for the left one)
    float lampW, lampH;                    // size of a taillight lens
    float noseZ, noseX, noseY;             // centre of the right front corner (indicator)
    float wheelFront, wheelRear;           // z of the axles
};

MeshData buildCarMesh(int type);
const CarDims& carDims(int type);

}  // namespace sd
