// scene_builder.h - converts the game state into renderer input (geometry + frame parameters).
#pragma once

#include <vector>

#include "game.h"
#include "rider_net.h"
#include "renderer.h"
#include "scene_types.h"

namespace sd {

// Clears and refills `geo`; returns the per-frame render parameters.
// Another player's rider in a LAN race, drawn in their colours.
struct RemoteRider {
    RiderNet net;
    int style = 0;
};

FrameParams buildScene(Game& game, float treeDensity, SceneGeometry& geo, const std::vector<RemoteRider>* remotes = nullptr);

}  // namespace sd
