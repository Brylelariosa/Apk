#include "autopilot.h"

#include <algorithm>
#include <cmath>

namespace sd {

SkaterInput AutoPilot::compute(const Track& track, const std::vector<Obstacle>& obstacles, const Skater& sk) {
    SkaterInput in;
    const float v = std::max(sk.speed, 4.0f);

    // ---- pick a lateral target: preferred lane unless something blocks it
    // look far enough to react to fast closing traffic
    float closingMax = v;
    for (const Obstacle& o : obstacles) {
        const float ds = o.s - sk.s;
        if (ds > 0.0f && ds < 260.0f) closingMax = std::max(closingMax, v - o.vel);
    }
    const float look = (30.0f + closingMax * 3.2f) * (0.6f + 0.4f * skill);
    static const float kCandidates[] = {cfg::kLaneCenter, -cfg::kLaneCenter, 0.0f, 2.8f, -2.8f};
    float best = cfg::kLaneCenter;
    float bestScore = -1e9f;
    bool blocked = false;
    // the kicker of a cliff jump is an obstacle for a driver that doesn't want to jump
    const ShortcutZone* rz = track.zoneAt(sk.s);
    const bool nearKicker = rz && sk.s > rz->sRamp0 - 50.0f && sk.s < rz->sLip + 4.0f;
    for (float cx : kCandidates) {
        if (nearKicker && cx * rz->side > rz->rampX0 - 1.4f) continue;
        float clearance = 99.0f;
        for (const Obstacle& o : obstacles) {
            if (o.hit) continue;
            const float ds = o.s - sk.s;
            if (ds < -2.0f || ds > look) continue;
            const float gap = std::fabs(o.x - cx) - (o.hx + 0.55f);
            clearance = std::min(clearance, gap);
        }
        const float score = std::min(clearance, 1.4f) * 2.0f - std::fabs(cx - cfg::kLaneCenter) * 0.35f - std::fabs(cx - sk.x) * 0.15f;
        if (cx == cfg::kLaneCenter && clearance < 0.3f) blocked = true;
        if (score > bestScore) { bestScore = score; best = cx; }
    }
    if (forcedX < 1e8f) best = forcedX;
    targetX_ += (best - targetX_) * 0.35f;

    // ---- steering: follow the road, then correct lateral error through the heading
    const float kAhead = track.curvatureAt(sk.s + v * 0.30f);
    const float wMax = std::max(0.05f, std::min(cfg::kYawRateMax * (1.0f + 0.4f * sk.slide), sk.gripNow() / std::max(sk.speed, 3.0f)));
    const float alphaTarget = clampf((targetX_ - sk.x) * 0.15f, -0.30f, 0.30f);
    const float omega = kAhead * sk.speed * (1.0f - cfg::kAutoFollow) + 2.6f * (alphaTarget - sk.alpha) + cfg::kStability * sk.alpha;
    in.steer = clampf(omega / wMax, -1.0f, 1.0f);

    // ---- speed management: lateral grip limit for the sharpest curve ahead
    float maxK = 0.0f;
    const float horizon = 22.0f + v * 2.6f * (0.6f + 0.4f * skill);
    for (float d = 0.0f; d <= horizon; d += 8.0f) maxK = std::max(maxK, std::fabs(track.curvatureAt(sk.s + d)));
    const float vSafe = std::sqrt(cfg::kGrip * 0.78f / (std::max(maxK, 1e-3f) * (1.0f - cfg::kAutoFollow)));
    const float cap = std::min(speedCap, vSafe);
    if (sk.speed > cap * 1.02f) braking_ = true;
    if (sk.speed < cap * 0.92f) braking_ = false;
    in.slide = braking_;

    in.tuck = allowTuck && !braking_ && maxK < 0.004f && !blocked && std::fabs(sk.x - targetX_) < 0.9f &&
              std::fabs(sk.alpha) < 0.12f && sk.speed < cap * 0.9f;
    return in;
}

}  // namespace sd
