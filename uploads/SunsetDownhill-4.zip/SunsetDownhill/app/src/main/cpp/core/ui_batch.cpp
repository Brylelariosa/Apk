#include "ui_batch.h"

#include <cmath>

namespace sd {

void UiBatch::triangle(Vec2 a, Vec2 b, Vec2 c, Rgba8 col) {
    push(a.x, a.y, col);
    push(b.x, b.y, col);
    push(c.x, c.y, col);
}

void UiBatch::quad(Vec2 a, Vec2 b, Vec2 c, Vec2 d, Rgba8 col) {
    triangle(a, b, c, col);
    triangle(a, c, d, col);
}

void UiBatch::rect(float x, float y, float w, float h, Rgba8 c) {
    quad({x, y}, {x + w, y}, {x + w, y + h}, {x, y + h}, c);
}

void UiBatch::rectGradient(float x, float y, float w, float h, Rgba8 top, Rgba8 bottom) {
    push(x, y, top); push(x + w, y, top); push(x + w, y + h, bottom);
    push(x, y, top); push(x + w, y + h, bottom); push(x, y + h, bottom);
}

void UiBatch::roundRect(float x, float y, float w, float h, float radius, Rgba8 c) {
    const float r = std::fmin(radius, std::fmin(w, h) * 0.5f);
    const int seg = 6;
    std::vector<Vec2> pts;
    // corners clockwise on screen: top-right, bottom-right, bottom-left, top-left
    const float cx[4] = {x + w - r, x + w - r, x + r, x + r};
    const float cy[4] = {y + r, y + h - r, y + h - r, y + r};
    for (int corner = 0; corner < 4; ++corner) {
        const float start = -kPi * 0.5f + static_cast<float>(corner) * kPi * 0.5f;
        for (int i = 0; i <= seg; ++i) {
            const float a = start + (kPi * 0.5f) * static_cast<float>(i) / static_cast<float>(seg);
            pts.push_back({cx[corner] + std::cos(a) * r, cy[corner] + std::sin(a) * r});
        }
    }
    const Vec2 centre{x + w * 0.5f, y + h * 0.5f};
    for (size_t i = 0; i < pts.size(); ++i) triangle(centre, pts[i], pts[(i + 1) % pts.size()], c);
}

void UiBatch::circle(float cx, float cy, float r, Rgba8 c, int segments) {
    for (int i = 0; i < segments; ++i) {
        const float a0 = kTwoPi * static_cast<float>(i) / static_cast<float>(segments);
        const float a1 = kTwoPi * static_cast<float>(i + 1) / static_cast<float>(segments);
        triangle({cx, cy}, {cx + std::cos(a0) * r, cy + std::sin(a0) * r}, {cx + std::cos(a1) * r, cy + std::sin(a1) * r}, c);
    }
}

void UiBatch::ring(float cx, float cy, float r0, float r1, Rgba8 c, int segments, float a0, float a1) {
    for (int i = 0; i < segments; ++i) {
        const float t0 = a0 + (a1 - a0) * static_cast<float>(i) / static_cast<float>(segments);
        const float t1 = a0 + (a1 - a0) * static_cast<float>(i + 1) / static_cast<float>(segments);
        const Vec2 p0{cx + std::cos(t0) * r0, cy + std::sin(t0) * r0}, p1{cx + std::cos(t0) * r1, cy + std::sin(t0) * r1};
        const Vec2 p2{cx + std::cos(t1) * r1, cy + std::sin(t1) * r1}, p3{cx + std::cos(t1) * r0, cy + std::sin(t1) * r0};
        quad(p0, p1, p2, p3, c);
    }
}

void UiBatch::line(Vec2 a, Vec2 b, float thickness, Rgba8 c, bool squareCaps) {
    Vec2 d = b - a;
    const float len = std::sqrt(d.x * d.x + d.y * d.y);
    if (len < 1e-4f) {
        if (squareCaps) rect(a.x - thickness * 0.5f, a.y - thickness * 0.5f, thickness, thickness, c);
        return;
    }
    d = d * (1.0f / len);
    const Vec2 n{-d.y * thickness * 0.5f, d.x * thickness * 0.5f};
    const float ext = squareCaps ? thickness * 0.5f : 0.0f;
    const Vec2 a2 = a - d * ext, b2 = b + d * ext;
    quad(a2 + n, b2 + n, b2 - n, a2 - n, c);
}

void UiBatch::glyphQuad(float x, float y, float w, float h, float u0, float v0, float u1, float v1, Rgba8 c, uint8_t halo) {
    const UiVertex tl{x, y, u0, v0, c.r, c.g, c.b, c.a, halo, {0, 0, 0}};
    const UiVertex tr{x + w, y, u1, v0, c.r, c.g, c.b, c.a, halo, {0, 0, 0}};
    const UiVertex br{x + w, y + h, u1, v1, c.r, c.g, c.b, c.a, halo, {0, 0, 0}};
    const UiVertex bl{x, y + h, u0, v1, c.r, c.g, c.b, c.a, halo, {0, 0, 0}};
    v_.push_back(tl); v_.push_back(tr); v_.push_back(br);
    v_.push_back(tl); v_.push_back(br); v_.push_back(bl);
}

}  // namespace sd
