// autopilot.h - simple driver used for the menu demo and for automated balancing tests.
#pragma once

#include <vector>

#include "skater.h"
#include "track.h"
#include "world.h"

namespace sd {

class AutoPilot {
public:
    float speedCap = 99.0f;      // m/s, brakes above this
    float skill = 1.0f;          // 0..1, scales how early it reacts (tests)
    bool allowTuck = true;
    float forcedX = 1e9f;        // tests: ride this lateral line instead of choosing a lane (e.g. to take a kicker)

    SkaterInput compute(const Track& track, const std::vector<Obstacle>& obstacles, const Skater& sk);

private:
    bool braking_ = false;
    float targetX_ = cfg::kLaneCenter;
};

}  // namespace sd
