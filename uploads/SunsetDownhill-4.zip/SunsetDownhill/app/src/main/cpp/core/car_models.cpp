#include "car_models.h"

#include <algorithm>
#include <cmath>
#include <vector>

#include "model_kit.h"

namespace sd {
namespace {

using kit::Ring;

const Material kPaint{255, 0, 0, 0};   // takes the per-instance tint
const Material kPlain{};

Rgba8 grey(float v) { return rgba(v, v, v); }
Mat4 at(float x, float y, float z) { return Mat4::translation(Vec3(x, y, z)); }

// One cross-section of a lofted body: z along the car, bottom/top heights and half widths, corner radii.
struct Station {
    float z, yb, yt, wb, wt, rb, rt;
};

std::vector<Ring> rings(const std::vector<Station>& st) {
    std::vector<Ring> out;
    out.reserve(st.size());
    for (const Station& s : st) out.push_back(kit::roundedSection(s.z, s.yb, s.yt, s.wb, s.wt, s.rb, s.rt, 3));
    return out;
}

struct Spec {
    CarDims dims;
    std::vector<Station> body, cabin;
    float wheelR, wheelW, wheelX;      // tyre radius / width / distance of the wheel centre from the middle
    float headX, headY;                // headlight centre (right one); z = nose
    float mirrorZ, mirrorY;
    float bodyLow;                     // bottom of the painted body (sills)
    bool paintedCabin;                 // van: the upper body is paint, glass is added as panels
};

// ---- parts ----------------------------------------------------------------------------------------------------------------
void addWheel(MeshData& m, float x, float z, float r, float w, int side) {
    const Rgba8 tire = grey(0.05f), rim = rgba(0.72f, 0.74f, 0.78f), dark = grey(0.18f);
    const float s = static_cast<float>(side);
    const Vec3 ax(s, 0.0f, 0.0f), fw(0.0f, 0.0f, 1.0f);
    const Vec3 third = cross(fw, ax);
    m.addFrustum(Mat4::fromBasis(fw, ax, third, Vec3(x - s * w * 0.5f, r, z)), r, r, w, 14, tire, tire, kPlain, 0.0f, true, true);
    m.addFrustum(Mat4::fromBasis(fw, ax, third, Vec3(x + s * (w * 0.5f - 0.02f), r, z)), r * 0.64f, r * 0.60f, 0.035f, 12, rim, rim, kPlain, 0.0f, true, true);
    m.addFrustum(Mat4::fromBasis(fw, ax, third, Vec3(x + s * (w * 0.5f + 0.005f), r, z)), r * 0.22f, r * 0.20f, 0.03f, 8, dark, dark, kPlain, 0.0f, true, true);
}

// Dark disc on the body side behind the tyre: reads as the wheel arch.
void addArch(MeshData& m, float bodyX, float z, float r, int side) {
    const float s = static_cast<float>(side);
    const Vec3 ax(s, 0.0f, 0.0f), fw(0.0f, 0.0f, 1.0f);
    m.addFrustum(Mat4::fromBasis(fw, ax, cross(fw, ax), Vec3(bodyX - s * 0.03f, r, z)), r * 1.30f, r * 1.30f, 0.05f, 14, grey(0.03f), grey(0.03f), kPlain, 0.0f, true, true);
}

void lamp(MeshData& m, float x, float y, float z, const Vec3& half, Rgba8 c, uint8_t emissive) {
    m.addBox(at(x, y, z), half, c, Material{0, emissive, 0, 0});
}

Rgba8 paintBody(const Vec3& p, const Vec3& n, Material& m, const Spec& sp) {
    const float len = sp.dims.halfLength;
    if (n.y < -0.55f || p.y < sp.bodyLow + 0.03f) { m = kPlain; return grey(0.05f); }               // underbody and sills
    if (std::fabs(p.z) > len - 0.50f && p.y < sp.bodyLow + 0.26f) { m = kPlain; return grey(0.10f); }  // bumper skirts: black plastic
    m = kPaint;
    const float t = saturate((p.y - sp.bodyLow) / std::max(0.2f, sp.dims.height * 0.62f));
    return grey(lerpf(0.70f, 1.0f, t));
}

Rgba8 paintCabin(const Vec3& p, const Vec3& n, Material& m, const Spec& sp) {
    if (sp.paintedCabin || n.y > 0.72f) {
        m = kPaint;
        return grey(lerpf(0.90f, 1.0f, saturate(n.y)));   // roof catches the sky
    }
    m = kPlain;
    const float t = saturate((p.y - sp.bodyLow) / std::max(0.2f, sp.dims.height - sp.bodyLow));
    return mix(rgba(0.05f, 0.07f, 0.11f), rgba(0.20f, 0.26f, 0.35f), t);   // tinted glass, brighter near the top (reflects the sky)
}

void addGlassPanel(MeshData& m, const Vec3& centre, const Vec3& across, const Vec3& normal, float halfAcross, float halfUp) {
    const Vec3 up = cross(across, normal);
    m.addBox(Mat4::fromBasis(across, normal, up, centre + normal * 0.012f), Vec3(halfAcross, 0.012f, halfUp), rgba(0.07f, 0.09f, 0.14f), rgba(0.16f, 0.21f, 0.30f), kPlain);
}

void buildCommon(MeshData& m, const Spec& sp) {
    const CarDims& d = sp.dims;
    kit::addLoft(m, Mat4::identity(), rings(sp.body), [&](const Vec3& p, const Vec3& n, Material& mat) { return paintBody(p, n, mat, sp); }, kPaint);
    if (!sp.cabin.empty())
        kit::addLoft(m, Mat4::identity(), rings(sp.cabin), [&](const Vec3& p, const Vec3& n, Material& mat) { return paintCabin(p, n, mat, sp); }, kPlain);

    // wheels and arches
    for (int side = -1; side <= 1; side += 2) {
        for (int axle = 0; axle < 2; ++axle) {
            const float z = axle == 0 ? d.wheelFront : d.wheelRear;
            addArch(m, static_cast<float>(side) * d.halfWidth, z, sp.wheelR, side);
            addWheel(m, static_cast<float>(side) * sp.wheelX, z, sp.wheelR, sp.wheelW, side);
        }
    }

    // lamps, grille and plates
    for (int side = -1; side <= 1; side += 2) {
        const float s = static_cast<float>(side);
        lamp(m, s * sp.headX, sp.headY, d.noseZ - 0.005f, Vec3(0.17f, 0.065f, 0.035f), rgba(1.0f, 0.96f, 0.82f), 255);      // headlight
        lamp(m, s * (sp.headX + 0.10f), sp.headY - 0.10f, d.noseZ + 0.005f, Vec3(0.07f, 0.03f, 0.03f), rgba(1.0f, 0.62f, 0.12f), 70);   // indicator
        lamp(m, s * d.tailX, d.tailY, d.tailZ + 0.005f, Vec3(d.lampW * 0.5f, d.lampH * 0.5f, 0.035f), rgba(0.85f, 0.04f, 0.03f), 150);  // taillight
        // mirrors on stalks
        m.addBox(at(s * (d.halfWidth + 0.06f), sp.mirrorY, sp.mirrorZ), Vec3(0.09f, 0.065f, 0.05f), grey(0.85f), grey(1.0f), kPaint);
        m.addBox(at(s * (d.halfWidth - 0.02f), sp.mirrorY - 0.04f, sp.mirrorZ + 0.03f), Vec3(0.05f, 0.015f, 0.025f), grey(0.08f), kPlain);
        // door seams
        for (int k = 0; k < 2; ++k) {
            const float z = lerpf(d.wheelFront + 0.55f, d.wheelRear - 0.75f, static_cast<float>(k));
            m.addBox(at(s * (d.halfWidth + 0.004f), sp.bodyLow + 0.40f, z), Vec3(0.006f, 0.30f, 0.008f), grey(0.07f), kPlain);
        }
        m.addBox(at(s * (d.halfWidth + 0.01f), sp.bodyLow + 0.62f, d.wheelFront + 0.72f), Vec3(0.008f, 0.012f, 0.06f), grey(0.80f), kPlain);   // handle
    }
    m.addBox(at(0.0f, sp.bodyLow + 0.30f, d.noseZ - 0.01f), Vec3(0.34f, 0.07f, 0.03f), grey(0.03f), kPlain);                            // grille
    m.addBox(at(0.0f, sp.bodyLow + 0.14f, d.noseZ - 0.03f), Vec3(0.20f, 0.06f, 0.012f), grey(0.92f), kPlain);                           // front plate
    m.addBox(at(0.0f, d.tailY - 0.18f, d.tailZ + 0.03f), Vec3(0.20f, 0.06f, 0.012f), grey(0.92f), kPlain);                              // rear plate
}

// ---- the five bodies ------------------------------------------------------------------------------------------------------
Spec sedan() {
    Spec s{};
    s.dims = {2.25f, 0.93f, 1.42f, 2.22f, 0.66f, 0.80f, 0.26f, 0.10f, -2.22f, 0.74f, 0.68f, -1.42f, 1.38f};
    s.body = {{-2.25f, 0.42f, 0.74f, 0.70f, 0.66f, 0.10f, 0.12f}, {-2.15f, 0.30f, 0.80f, 0.84f, 0.80f, 0.14f, 0.16f},
              {-1.70f, 0.28f, 0.86f, 0.92f, 0.88f, 0.14f, 0.18f}, {-0.90f, 0.28f, 0.95f, 0.93f, 0.88f, 0.12f, 0.20f},
              {0.40f, 0.28f, 0.97f, 0.93f, 0.88f, 0.12f, 0.20f},  {1.60f, 0.28f, 0.98f, 0.92f, 0.86f, 0.12f, 0.20f},
              {2.10f, 0.30f, 0.93f, 0.86f, 0.80f, 0.14f, 0.16f},  {2.25f, 0.40f, 0.86f, 0.74f, 0.68f, 0.10f, 0.12f}};
    s.cabin = {{-0.95f, 0.93f, 0.99f, 0.82f, 0.80f, 0.04f, 0.04f}, {-0.35f, 0.93f, 1.30f, 0.84f, 0.72f, 0.05f, 0.14f},
               {0.05f, 0.93f, 1.42f, 0.84f, 0.70f, 0.05f, 0.16f},  {0.95f, 0.93f, 1.42f, 0.84f, 0.70f, 0.05f, 0.16f},
               {1.45f, 0.93f, 1.24f, 0.84f, 0.72f, 0.05f, 0.14f},  {1.80f, 0.93f, 1.00f, 0.82f, 0.78f, 0.04f, 0.04f}};
    s.wheelR = 0.32f; s.wheelW = 0.22f; s.wheelX = 0.83f;
    s.headX = 0.62f; s.headY = 0.70f;
    s.mirrorZ = -0.55f; s.mirrorY = 1.02f; s.bodyLow = 0.28f;
    return s;
}

Spec hatch() {
    Spec s{};
    s.dims = {1.98f, 0.89f, 1.50f, 1.96f, 0.62f, 0.86f, 0.18f, 0.20f, -1.96f, 0.70f, 0.70f, -1.25f, 1.15f};
    s.body = {{-1.98f, 0.42f, 0.72f, 0.68f, 0.64f, 0.10f, 0.12f}, {-1.88f, 0.30f, 0.78f, 0.80f, 0.76f, 0.14f, 0.16f},
              {-1.45f, 0.28f, 0.84f, 0.88f, 0.84f, 0.14f, 0.18f}, {-0.80f, 0.28f, 0.92f, 0.89f, 0.85f, 0.12f, 0.20f},
              {0.40f, 0.28f, 0.96f, 0.89f, 0.85f, 0.12f, 0.20f},  {1.55f, 0.28f, 0.98f, 0.88f, 0.82f, 0.12f, 0.18f},
              {1.88f, 0.34f, 0.94f, 0.80f, 0.74f, 0.12f, 0.14f},  {1.98f, 0.44f, 0.88f, 0.70f, 0.64f, 0.10f, 0.12f}};
    s.cabin = {{-0.80f, 0.92f, 0.98f, 0.80f, 0.78f, 0.04f, 0.04f}, {-0.30f, 0.92f, 1.30f, 0.82f, 0.70f, 0.05f, 0.14f},
               {0.10f, 0.92f, 1.45f, 0.82f, 0.68f, 0.05f, 0.16f},  {1.15f, 0.92f, 1.50f, 0.82f, 0.68f, 0.05f, 0.16f},
               {1.70f, 0.92f, 1.40f, 0.82f, 0.70f, 0.05f, 0.14f},  {1.90f, 0.92f, 1.05f, 0.80f, 0.74f, 0.05f, 0.08f}};
    s.wheelR = 0.30f; s.wheelW = 0.20f; s.wheelX = 0.80f;
    s.headX = 0.58f; s.headY = 0.68f;
    s.mirrorZ = -0.45f; s.mirrorY = 1.02f; s.bodyLow = 0.28f;
    return s;
}

Spec suv() {
    Spec s{};
    s.dims = {2.30f, 0.97f, 1.78f, 2.28f, 0.72f, 0.98f, 0.16f, 0.24f, -2.28f, 0.78f, 0.94f, -1.50f, 1.45f};
    s.body = {{-2.30f, 0.52f, 0.86f, 0.72f, 0.68f, 0.10f, 0.12f}, {-2.20f, 0.38f, 0.98f, 0.86f, 0.82f, 0.14f, 0.16f},
              {-1.75f, 0.36f, 1.06f, 0.94f, 0.90f, 0.14f, 0.18f}, {-0.95f, 0.36f, 1.12f, 0.96f, 0.92f, 0.12f, 0.20f},
              {0.60f, 0.36f, 1.14f, 0.96f, 0.92f, 0.12f, 0.20f},  {1.90f, 0.36f, 1.14f, 0.95f, 0.91f, 0.12f, 0.18f},
              {2.22f, 0.40f, 1.08f, 0.88f, 0.84f, 0.12f, 0.14f},  {2.30f, 0.50f, 1.00f, 0.78f, 0.72f, 0.10f, 0.12f}};
    s.cabin = {{-1.05f, 1.10f, 1.15f, 0.84f, 0.82f, 0.04f, 0.04f}, {-0.45f, 1.10f, 1.55f, 0.86f, 0.76f, 0.05f, 0.12f},
               {0.00f, 1.10f, 1.78f, 0.86f, 0.74f, 0.05f, 0.14f},  {1.80f, 1.10f, 1.78f, 0.86f, 0.74f, 0.05f, 0.14f},
               {2.12f, 1.10f, 1.60f, 0.86f, 0.78f, 0.05f, 0.10f},  {2.22f, 1.10f, 1.30f, 0.84f, 0.80f, 0.05f, 0.06f}};
    s.wheelR = 0.38f; s.wheelW = 0.26f; s.wheelX = 0.86f;
    s.headX = 0.66f; s.headY = 0.92f;
    s.mirrorZ = -0.70f; s.mirrorY = 1.28f; s.bodyLow = 0.36f;
    return s;
}

Spec pickup() {
    Spec s{};
    s.dims = {2.75f, 0.97f, 1.78f, 2.74f, 0.76f, 1.02f, 0.16f, 0.20f, -2.64f, 0.80f, 0.94f, -1.65f, 1.80f};
    // lower body: hood + cab, ending behind the cab; the bed is built from panels
    s.body = {{-2.65f, 0.50f, 0.90f, 0.74f, 0.70f, 0.10f, 0.12f}, {-2.55f, 0.38f, 1.02f, 0.88f, 0.84f, 0.14f, 0.16f},
              {-2.10f, 0.36f, 1.08f, 0.95f, 0.91f, 0.14f, 0.18f}, {-1.20f, 0.36f, 1.12f, 0.97f, 0.93f, 0.12f, 0.20f},
              {0.35f, 0.36f, 1.14f, 0.97f, 0.93f, 0.12f, 0.20f},  {0.50f, 0.36f, 1.14f, 0.97f, 0.93f, 0.12f, 0.20f}};
    s.cabin = {{-1.10f, 1.10f, 1.15f, 0.84f, 0.82f, 0.04f, 0.04f}, {-0.55f, 1.10f, 1.50f, 0.86f, 0.76f, 0.05f, 0.12f},
               {-0.10f, 1.10f, 1.78f, 0.86f, 0.74f, 0.05f, 0.14f}, {0.30f, 1.10f, 1.76f, 0.86f, 0.74f, 0.05f, 0.14f},
               {0.48f, 1.10f, 1.45f, 0.86f, 0.78f, 0.05f, 0.10f}};
    s.wheelR = 0.38f; s.wheelW = 0.26f; s.wheelX = 0.86f;
    s.headX = 0.68f; s.headY = 0.94f;
    s.mirrorZ = -0.75f; s.mirrorY = 1.30f; s.bodyLow = 0.36f;
    return s;
}

Spec van() {
    Spec s{};
    s.dims = {2.45f, 0.97f, 1.92f, 2.44f, 0.76f, 1.00f, 0.14f, 0.30f, -2.42f, 0.76f, 0.98f, -1.55f, 1.55f};
    s.body = {{-2.45f, 0.46f, 0.96f, 0.74f, 0.70f, 0.12f, 0.14f}, {-2.38f, 0.36f, 1.12f, 0.88f, 0.84f, 0.14f, 0.16f},
              {-2.20f, 0.34f, 1.22f, 0.94f, 0.90f, 0.14f, 0.18f}, {-1.00f, 0.34f, 1.24f, 0.96f, 0.92f, 0.12f, 0.20f},
              {1.00f, 0.34f, 1.24f, 0.97f, 0.93f, 0.12f, 0.20f},  {2.20f, 0.34f, 1.24f, 0.96f, 0.92f, 0.12f, 0.18f},
              {2.40f, 0.40f, 1.20f, 0.92f, 0.88f, 0.12f, 0.14f},  {2.45f, 0.46f, 1.14f, 0.86f, 0.80f, 0.10f, 0.12f}};
    // upper body: the windshield rakes up from the hood, then a long roof to the tailgate
    s.cabin = {{-1.95f, 1.20f, 1.30f, 0.88f, 0.86f, 0.04f, 0.04f}, {-1.20f, 1.20f, 1.86f, 0.94f, 0.88f, 0.05f, 0.16f},
               {-1.00f, 1.20f, 1.92f, 0.95f, 0.90f, 0.05f, 0.18f}, {2.20f, 1.20f, 1.92f, 0.95f, 0.90f, 0.05f, 0.18f},
               {2.40f, 1.20f, 1.86f, 0.92f, 0.86f, 0.05f, 0.14f}, {2.45f, 1.20f, 1.70f, 0.88f, 0.82f, 0.05f, 0.10f}};
    s.wheelR = 0.36f; s.wheelW = 0.24f; s.wheelX = 0.86f;
    s.headX = 0.66f; s.headY = 0.92f;
    s.mirrorZ = -1.30f; s.mirrorY = 1.42f; s.bodyLow = 0.34f;
    s.paintedCabin = true;
    return s;
}

void extras(MeshData& m, int type, const Spec& sp) {
    const CarDims& d = sp.dims;
    switch (type) {
        case kCarSuv: {
            for (int side = -1; side <= 1; side += 2)   // roof rails
                m.addBox(at(static_cast<float>(side) * 0.62f, 1.82f, 0.85f), Vec3(0.025f, 0.03f, 1.35f), grey(0.10f), kPlain);
            break;
        }
        case kCarPickup: {
            const float z0 = 0.55f, z1 = 2.72f, zc = (z0 + z1) * 0.5f, hz = (z1 - z0) * 0.5f;
            m.addBox(at(0.0f, 0.60f, zc), Vec3(0.90f, 0.03f, hz), grey(0.06f), kPlain);                                // bed liner
            for (int side = -1; side <= 1; side += 2) {
                const float s = static_cast<float>(side);
                m.addBox(at(s * 0.89f, 0.90f, zc), Vec3(0.05f, 0.28f, hz), grey(0.78f), grey(1.0f), kPaint);              // side wall
                m.addBox(at(s * 0.89f, 1.19f, zc), Vec3(0.065f, 0.02f, hz), grey(0.95f), grey(1.0f), kPaint);             // rail cap
            }
            m.addBox(at(0.0f, 0.90f, z0 + 0.04f), Vec3(0.86f, 0.28f, 0.04f), grey(0.78f), grey(1.0f), kPaint);          // bulkhead
            m.addBox(at(0.0f, 0.90f, z1), Vec3(0.92f, 0.28f, 0.045f), grey(0.80f), grey(1.0f), kPaint);                  // tailgate
            m.addBox(at(0.0f, 1.19f, z1), Vec3(0.94f, 0.02f, 0.06f), grey(0.95f), grey(1.0f), kPaint);
            m.addBox(at(0.0f, 0.44f, d.tailZ + 0.06f), Vec3(0.92f, 0.09f, 0.06f), grey(0.08f), kPlain);                // rear bumper
            for (int side = -1; side <= 1; side += 2)                                                                   // wheel-arch humps in the bed
                m.addBox(at(static_cast<float>(side) * 0.70f, 0.78f, d.wheelRear), Vec3(0.18f, 0.16f, 0.46f), grey(0.80f), grey(1.0f), kPaint);
            break;
        }
        case kCarVan: {
            // glass panels lie on the body surface: the raked windshield and the side / rear windows
            const Vec3 slope = normalize(Vec3(0.0f, 0.56f, 0.75f)), n = Vec3(0.0f, slope.z, -slope.y);
            const float zw = -1.58f, yw = 1.30f + (zw + 1.95f) / 0.75f * 0.56f;   // the roof line at that z
            addGlassPanel(m, Vec3(0.0f, yw, zw) + n * 0.02f, Vec3(1.0f, 0.0f, 0.0f), n, 0.70f, 0.36f);
            for (int side = -1; side <= 1; side += 2) {
                const float sg = static_cast<float>(side);
                const Vec3 sideN(sg, 0.0f, 0.0f);
                addGlassPanel(m, Vec3(sg * 0.925f, 1.54f, -1.15f), Vec3(0.0f, 0.0f, 1.0f), sideN, 0.50f, 0.24f);
                addGlassPanel(m, Vec3(sg * 0.925f, 1.54f, 1.55f), Vec3(0.0f, 0.0f, 1.0f), sideN, 0.30f, 0.20f);
                m.addBox(at(sg * (d.halfWidth + 0.006f), 1.00f, 0.20f), Vec3(0.008f, 0.012f, 1.20f), grey(0.12f), kPlain);   // sliding-door rail
            }
            addGlassPanel(m, Vec3(0.0f, 1.55f, 2.45f), Vec3(1.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 1.0f), 0.62f, 0.24f);       // rear window
            m.addBox(at(0.0f, 0.46f, d.tailZ + 0.04f), Vec3(0.90f, 0.08f, 0.05f), grey(0.08f), kPlain);
            break;
        }
        default: break;
    }
}

const CarDims& dimsFor(int type) {
    static const CarDims table[kCarTypeCount] = {sedan().dims, hatch().dims, suv().dims, pickup().dims, van().dims};
    return table[std::max(0, std::min(type, kCarTypeCount - 1))];
}

}  // namespace

const CarDims& carDims(int type) { return dimsFor(type); }

MeshData buildCarMesh(int type) {
    MeshData m;
    Spec sp;
    switch (type) {
        case kCarHatch: sp = hatch(); break;
        case kCarSuv: sp = suv(); break;
        case kCarPickup: sp = pickup(); break;
        case kCarVan: sp = van(); break;
        default: sp = sedan(); type = kCarSedan; break;
    }
    buildCommon(m, sp);
    extras(m, type, sp);
    return m;
}

}  // namespace sd
