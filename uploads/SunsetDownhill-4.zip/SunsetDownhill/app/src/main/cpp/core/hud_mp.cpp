#include "hud_mp.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

#include "ui_font.h"
#include "ui_widgets.h"

namespace sd {

using namespace widgets;

Rgba8 riderColor(int style) {
    static const Rgba8 colors[6] = {{255, 128, 36, 255}, {236, 62, 62, 255}, {40, 200, 196, 255}, {178, 100, 235, 255}, {156, 214, 52, 255}, {255, 100, 168, 255}};
    return colors[((style % 6) + 6) % 6];
}

LobbyRects lobbyRects(const UiLayout& L) {
    LobbyRects r;
    const float u = L.u, cx = L.w * 0.5f;
    r.back = L.controlsMenu;
    const float cw = std::min(600.0f * u, (L.w - 2.0f * L.margin - 60.0f * u) * 0.5f), ch = 290.0f * u, gap = 60.0f * u, cy = L.h * 0.30f;
    r.host = {cx - cw - gap * 0.5f, cy, cw, ch};
    r.search = {cx + gap * 0.5f, cy, cw, ch};
    const float rw = std::min(860.0f * u, L.w - 2.0f * L.margin), rh = 72.0f * u, rg = 10.0f * u, ry = L.h * 0.27f;
    for (int i = 0; i < kMpRows; ++i) r.rows[i] = {cx - rw * 0.5f, ry + static_cast<float>(i) * (rh + rg), rw, rh};
    r.start = {cx - 230.0f * u, L.h - L.margin - 100.0f * u, 460.0f * u, 100.0f * u};
    r.goal = {cx - 230.0f * u, r.start.y - 80.0f * u, 460.0f * u, 66.0f * u};
    return r;
}

namespace {

void card(UiBatch& ui, const Rect& r, const char* title, const char* line1, const char* line2, Rgba8 tint, float u) {
    ui.roundRect(r.x, r.y, r.w, r.h, 36.0f * u, Rgba8{30, 20, 60, 205});
    ui.roundRect(r.x, r.y, r.w, 10.0f * u, 5.0f * u, tint);
    text(ui, title, r.x + r.w * 0.5f, r.y + 62.0f * u, fitSize(title, 56.0f * u, r.w * 0.86f), kWhite, TextAlign::Center);
    text(ui, line1, r.x + r.w * 0.5f, r.y + 170.0f * u, fitSize(line1, 25.0f * u, r.w * 0.9f), alpha(kWhite, 0.85f), TextAlign::Center);
    text(ui, line2, r.x + r.w * 0.5f, r.y + 208.0f * u, fitSize(line2, 25.0f * u, r.w * 0.9f), alpha(kWhite, 0.85f), TextAlign::Center);
}

void rowBackground(UiBatch& ui, const Rect& r, float u, bool self, bool dim) {
    const float a = dim ? 0.35f : 1.0f;
    ui.roundRect(r.x, r.y, r.w, r.h, r.h * 0.32f, alpha(self ? Rgba8{70, 44, 20, 220} : Rgba8{30, 20, 60, 200}, a));
    if (self) ui.roundRect(r.x, r.y, 8.0f * u, r.h, 4.0f * u, alpha(kAccent, a));
}

}  // namespace

void drawLobby(UiBatch& ui, const UiLayout& L, const MpModel& mp, float time) {
    const float u = L.u, cx = L.w * 0.5f;
    const LobbyRects r = lobbyRects(L);
    ui.rect(0, 0, L.w, L.h, Rgba8{10, 4, 24, 165});

    const char* title = "LAN MULTIPLAYER";
    const char* sub = "RACE YOUR FRIENDS ON THE SAME WI-FI OR HOTSPOT";
    switch (mp.screen) {
        case MpModel::Screen::Search:
            title = "FIND A RACE";
            sub = "TAP A RACE TO JOIN IT";
            break;
        case MpModel::Screen::Room:
            title = mp.isHost ? "YOUR RACE" : "RACE LOBBY";
            sub = mp.isHost ? "RIDERS ON YOUR WI-FI CAN FIND THIS RACE" : "WAITING FOR THE HOST TO START";
            break;
        default: break;
    }
    text(ui, title, cx, L.h * 0.07f, 70.0f * u, kGold, TextAlign::Center);
    text(ui, sub, cx, L.h * 0.07f + 92.0f * u, fitSize(sub, 26.0f * u, L.w - 2.0f * L.margin), alpha(kWhite, 0.8f), TextAlign::Center);
    if (mp.status[0]) text(ui, mp.status, cx, L.h * 0.07f + 140.0f * u, fitSize(mp.status, 30.0f * u, L.w - 2.0f * L.margin), kRed, TextAlign::Center);
    pill(ui, r.back, mp.screen == MpModel::Screen::Choose ? "BACK" : "LEAVE", 34.0f * u);

    switch (mp.screen) {
        case MpModel::Screen::Choose: {
            card(ui, r.host, "HOST A RACE", "OPEN A LOBBY - YOUR FRIENDS", "FIND IT AUTOMATICALLY", kAccent, u);
            card(ui, r.search, "JOIN A RACE", "LOOK FOR A LOBBY ON", "YOUR WI-FI AND JOIN IT", kCyan, u);
            const float y = r.host.y + r.host.h + 70.0f * u;
            if (mp.address[0]) {
                char buf[80];
                std::snprintf(buf, sizeof(buf), "THIS PHONE  %s", mp.address);
                text(ui, buf, cx, y, 30.0f * u, alpha(kWhite, 0.85f), TextAlign::Center);
            } else {
                const char* msg = "NO WI-FI FOUND - CONNECT TO WI-FI OR TURN ON A HOTSPOT";
                text(ui, msg, cx, y, fitSize(msg, 30.0f * u, L.w - 2.0f * L.margin), kRed, TextAlign::Center);
            }
            break;
        }
        case MpModel::Screen::Search: {
            for (int i = 0; i < mp.rowCount && i < kMpRows; ++i) {
                const MpRow& row = mp.rows[i];
                const Rect& rc = r.rows[i];
                rowBackground(ui, rc, u, false, row.racing);
                text(ui, row.name, rc.x + 36.0f * u, rc.y + rc.h * 0.5f - 17.0f * u, fitSize(row.name, 34.0f * u, rc.w * 0.5f), alpha(kWhite, row.racing ? 0.5f : 1.0f));
                char buf[32];
                if (row.racing) std::snprintf(buf, sizeof(buf), "RACING");
                else std::snprintf(buf, sizeof(buf), "%d/%d RIDERS", row.players, kMpRows);
                text(ui, buf, rc.x + rc.w - 36.0f * u, rc.y + rc.h * 0.5f - 15.0f * u, 30.0f * u, row.racing ? alpha(kAccent, 0.7f) : kCyan, TextAlign::Right);
            }
            if (mp.rowCount == 0) {
                char buf[24];
                std::snprintf(buf, sizeof(buf), "SEARCHING%.*s", 1 + static_cast<int>(time * 2.0f) % 3, "...");
                text(ui, buf, cx, L.h * 0.40f, 52.0f * u, alpha(kWhite, 0.9f), TextAlign::Center);
                const char* hint = "ASK A FRIEND TO OPEN A RACE - BOTH PHONES MUST BE ON THE SAME WI-FI";
                text(ui, hint, cx, L.h * 0.40f + 90.0f * u, fitSize(hint, 25.0f * u, L.w - 2.0f * L.margin), alpha(kWhite, 0.7f), TextAlign::Center);
            }
            if (mp.joining) text(ui, "JOINING...", cx, L.h - L.margin - 70.0f * u, 54.0f * u, alpha(kGold, 0.7f + 0.3f * std::sin(time * 6.0f)), TextAlign::Center);
            break;
        }
        case MpModel::Screen::Room: {
            int firstEmpty = kMpRows;
            for (int i = 0; i < kMpRows; ++i) {
                if (!(i < mp.rowCount && mp.rows[i].name[0] != '\0')) { firstEmpty = i; break; }
            }
            for (int i = 0; i < kMpRows; ++i) {
                const Rect& rc = r.rows[i];
                const bool filled = i < mp.rowCount && mp.rows[i].name[0] != '\0';
                const MpRow dummy;
                const MpRow& row = filled ? mp.rows[i] : dummy;
                rowBackground(ui, rc, u, filled && row.self, !filled);
                if (!filled) {
                    if (i == firstEmpty) text(ui, "WAITING FOR RIDERS...", rc.x + 36.0f * u, rc.y + rc.h * 0.5f - 14.0f * u, 28.0f * u, alpha(kWhite, 0.45f));
                    continue;
                }
                ui.circle(rc.x + 54.0f * u, rc.y + rc.h * 0.5f, 20.0f * u, riderColor(row.style), 28);
                ui.ring(rc.x + 54.0f * u, rc.y + rc.h * 0.5f, 17.0f * u, 21.0f * u, alpha(kWhite, 0.8f), 28);
                text(ui, row.name, rc.x + 100.0f * u, rc.y + rc.h * 0.5f - 17.0f * u, fitSize(row.name, 34.0f * u, rc.w * 0.5f), kWhite);
                char tag[24] = {};
                if (row.host && row.self) std::snprintf(tag, sizeof(tag), "HOST  YOU");
                else if (row.host) std::snprintf(tag, sizeof(tag), "HOST");
                else if (row.self) std::snprintf(tag, sizeof(tag), "YOU");
                if (tag[0]) text(ui, tag, rc.x + rc.w - 36.0f * u, rc.y + rc.h * 0.5f - 15.0f * u, 30.0f * u, row.host ? kGold : kAccent, TextAlign::Right);
            }
            if (mp.isHost) {
                char goalText[32];
                if (mp.goalM > 0.0f) std::snprintf(goalText, sizeof(goalText), "GOAL  %.0f KM", mp.goalM / 1000.0f);
                else std::snprintf(goalText, sizeof(goalText), "GOAL  ENDLESS");
                pill(ui, r.goal, goalText, 34.0f * u, mp.canStart ? 0.9f : 0.5f, mp.canStart);
                pill(ui, r.start, mp.canStart ? "START RACE" : "RACE RUNNING...", 46.0f * u, mp.canStart ? 1.0f : 0.5f, mp.canStart);
            } else {
                text(ui, "WAITING FOR THE HOST TO START", cx, r.start.y + r.start.h * 0.5f - 20.0f * u, 40.0f * u, alpha(kGold, 0.65f + 0.35f * std::sin(time * 3.2f)),
                     TextAlign::Center);
            }
            break;
        }
        default: break;
    }
}

UiAction lobbyTap(const UiLayout& L, const MpModel& mp, float x, float y, int* index) {
    const LobbyRects r = lobbyRects(L);
    if (r.back.contains(x, y)) return mp.screen == MpModel::Screen::Choose ? UiAction::LobbyBack : UiAction::LobbyLeave;
    switch (mp.screen) {
        case MpModel::Screen::Choose:
            if (r.host.contains(x, y)) return UiAction::LobbyHost;
            if (r.search.contains(x, y)) return UiAction::LobbySearch;
            break;
        case MpModel::Screen::Search:
            if (mp.joining) break;
            for (int i = 0; i < mp.rowCount && i < kMpRows; ++i) {
                if (r.rows[i].contains(x, y) && !mp.rows[i].racing) {
                    if (index) *index = i;
                    return UiAction::LobbyJoin;
                }
            }
            break;
        case MpModel::Screen::Room:
            if (mp.isHost && mp.canStart && r.start.contains(x, y)) return UiAction::LobbyStart;
            if (mp.isHost && mp.canStart && r.goal.contains(x, y)) return UiAction::LobbyGoal;
            break;
        default: break;
    }
    return UiAction::None;
}

namespace {
// 83.2 s -> "1:23.2"
void formatRaceTime(char* out, size_t cap, float seconds) {
    const int minutes = static_cast<int>(seconds / 60.0f);
    std::snprintf(out, cap, "%d:%04.1f", minutes, seconds - 60.0f * static_cast<float>(minutes));
}

// The first `n` characters of a name (the standings are narrow).
void shortName(char* out, size_t cap, const char* name, size_t n) {
    size_t i = 0;
    for (; i < n && i + 1 < cap && name[i]; ++i) out[i] = name[i];
    while (i > 0 && out[i - 1] == ' ') --i;
    out[i] = '\0';
}
}  // namespace

void drawStandings(UiBatch& ui, const UiLayout& L, const MpModel& mp) {
    const float u = L.u;
    const float x = L.margin, y0 = L.margin + 178.0f * u;
    const float size = 24.0f * u, pitch = 36.0f * u;
    for (int i = 0; i < mp.rowCount && i < kMpRows; ++i) {
        const MpRow& r = mp.rows[i];
        const float y = y0 + pitch * static_cast<float>(i);
        const float a = (r.crashed || r.finished) && !r.self ? 0.55f : 1.0f;
        const Rgba8 col = alpha(r.self ? kGold : kWhite, a);
        char buf[24], nm[16];
        std::snprintf(buf, sizeof(buf), "%d", i + 1);
        text(ui, buf, x, y, size, col);
        ui.circle(x + 40.0f * u, y + size * 0.6f, 9.0f * u, alpha(riderColor(r.style), a), 20);
        shortName(nm, sizeof(nm), r.name, 11);
        text(ui, nm, x + 62.0f * u, y, fitSize(nm, size, 230.0f * u), col);
        if (mp.goalM > 0.0f) {
            if (r.crossed) formatRaceTime(buf, sizeof(buf), r.finishTime);
            else if (r.crashed) std::snprintf(buf, sizeof(buf), "OUT");
            else std::snprintf(buf, sizeof(buf), "%d M", static_cast<int>(std::max(0.0f, r.toGoM)));
        } else {
            std::snprintf(buf, sizeof(buf), "%d", r.score);
        }
        text(ui, buf, x + 440.0f * u, y, size, col, TextAlign::Right);
    }
}

void drawNameTags(UiBatch& ui, const UiLayout& L, const MpModel& mp) {
    const float u = L.u;
    for (int i = 0; i < mp.tagCount && i < kMpRows; ++i) {
        const MpTag& t = mp.tags[i];
        const Rgba8 c = riderColor(t.style);
        const float a = t.alpha * (t.crashed ? 0.6f : 1.0f);
        char buf[24];
        std::snprintf(buf, sizeof(buf), "%+d M", static_cast<int>(t.ahead));
        text(ui, t.name, t.pos.x, t.pos.y - 46.0f * u, 24.0f * u, alpha(c, a), TextAlign::Center);
        text(ui, buf, t.pos.x, t.pos.y - 18.0f * u, 18.0f * u, alpha(kWhite, 0.85f * a), TextAlign::Center);
        ui.triangle({t.pos.x - 9.0f * u, t.pos.y + 6.0f * u}, {t.pos.x + 9.0f * u, t.pos.y + 6.0f * u}, {t.pos.x, t.pos.y + 20.0f * u}, alpha(c, a));
    }
}

void drawResults(UiBatch& ui, const UiLayout& L, const MpModel& mp, float a, float time) {
    const float u = L.u;
    const int rows = std::max(1, std::min(mp.rowCount, kMpRows));
    const float rowH = 76.0f * u;
    const float pw = std::min(900.0f * u, L.w - 2.0f * L.margin), ph = 230.0f * u + rowH * static_cast<float>(rows);
    const float px = L.w * 0.5f - pw * 0.5f, py = std::max(L.margin * 0.5f, L.h * 0.46f - ph * 0.5f);
    ui.roundRect(px, py, pw, ph, 36.0f * u, alpha(kPanel, a));
    ui.roundRect(px, py, pw, 10.0f * u, 5.0f * u, alpha(kAccent, a));
    const float cx = L.w * 0.5f;
    const char* title = mp.allDone ? "RACE RESULTS" : "WAITING FOR THE OTHERS";
    text(ui, title, cx, py + 34.0f * u, fitSize(title, 62.0f * u, pw * 0.9f), alpha(kWhite, a), TextAlign::Center);
    for (int i = 0; i < rows && i < mp.rowCount; ++i) {
        const MpRow& r = mp.rows[i];
        const float y = py + 128.0f * u + rowH * static_cast<float>(i);
        if (r.self) ui.roundRect(px + 20.0f * u, y - 8.0f * u, pw - 40.0f * u, rowH - 6.0f * u, 18.0f * u, alpha(Rgba8{90, 56, 24, 200}, a));
        const Rgba8 col = alpha(r.self ? kGold : kWhite, a);
        char buf[48];
        std::snprintf(buf, sizeof(buf), "%d", i + 1);
        text(ui, buf, px + 60.0f * u, y + 6.0f * u, 38.0f * u, col, TextAlign::Center);
        ui.circle(px + 118.0f * u, y + 26.0f * u, 14.0f * u, alpha(riderColor(r.style), a), 24);
        text(ui, r.name, px + 150.0f * u, y, fitSize(r.name, 34.0f * u, pw - 150.0f * u - 250.0f * u), col);
        if (!r.finished && !r.crashed) {
            text(ui, "STILL RIDING", px + 150.0f * u, y + 47.0f * u, 20.0f * u, alpha(kCyan, a * (0.6f + 0.4f * std::sin(time * 5.0f))));
        } else if (r.crossed) {
            char tm[24];
            formatRaceTime(tm, sizeof(tm), r.finishTime);
            std::snprintf(buf, sizeof(buf), "FINISHED  %s", tm);
            text(ui, buf, px + 150.0f * u, y + 47.0f * u, 20.0f * u, alpha(kGold, a));
        } else {
            std::snprintf(buf, sizeof(buf), "%.2f KM%s", r.distanceM / 1000.0f, r.crashed ? "  WIPEOUT" : "");
            text(ui, buf, px + 150.0f * u, y + 47.0f * u, 20.0f * u, alpha(kAccent, a));
        }
        std::snprintf(buf, sizeof(buf), "%d", r.score);
        text(ui, buf, px + pw - 50.0f * u, y + 2.0f * u, 44.0f * u, col, TextAlign::Right);
    }
    const float b = 0.6f + 0.4f * std::sin(time * 3.2f);
    text(ui, "TAP FOR THE LOBBY", cx, py + ph - 66.0f * u, 42.0f * u, alpha(kWhite, a * b), TextAlign::Center);
}

}  // namespace sd
