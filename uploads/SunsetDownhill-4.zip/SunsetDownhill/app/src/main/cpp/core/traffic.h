// traffic.h - how the cars drive.
//
// Every car perceives the road around it (cones, rocks, other cars and the rider) and behaves like a careful driver: it keeps its
// lane, keeps a safe following distance (Intelligent Driver Model), slows for curves, brakes in time for anything in its path,
// steers around obstacles - but only after signalling and only when the line it wants is free of oncoming traffic and nobody is
// alongside or closing fast from behind - and otherwise stops and waits its turn. It never drives into a cone or a rock.
#pragma once

#include <vector>

#include "world.h"

namespace sd {

void stepTraffic(std::vector<Obstacle>& obstacles, const Track& track, float dt, const PlayerRef& player);

}  // namespace sd
