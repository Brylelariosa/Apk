// game.h - platform independent game simulation: state machine, scoring, effects.
#pragma once

#include <cstdint>

#include "atmosphere.h"
#include "autopilot.h"
#include "rider_net.h"
#include "camera.h"
#include "particles.h"
#include "skater.h"
#include "skater_model.h"
#include "world.h"

namespace sd {

enum class Phase : uint8_t { Menu, Countdown, Running, Crashed, GameOver, Paused };

// One-shot notifications consumed by the shell (audio, UI) once per frame.
struct GameEvents {
    bool crash = false;
    bool scrape = false;
    bool nearMiss = false;
    bool coneHit = false;
    bool go = false;
    bool push = false;     // a kick-push plants its foot on the road
    bool footOn = false;   // the kicking foot is back on the deck
    bool newBest = false;
    int tick = 0;  // 3, 2, 1 when the countdown number changes
};

class Game {
public:
    Game();

    void update(float dt, const SkaterInput& input);

    // ---- commands
    void startRun();   // from Menu or GameOver
    void pause();
    void resume();
    void toMenu();
    bool handleBack(); // returns true if the press was consumed

    // ---- queries
    Phase phase() const { return phase_; }
    float phaseTime() const { return phaseTime_; }
    float time() const { return time_; }
    GameEvents takeEvents();

    World& world() { return world_; }
    const World& world() const { return world_; }
    const Skater& skater() const { return skater_; }
    const ChaseCamera& camera() const { return camera_; }
    const ParticleSystem& particles() const { return fx_; }
    const Atmosphere& atmosphere() const { return atmo_; }
    SkaterPose skaterPose(const Vec3& origin) const;

    float speedKmh() const { return skater_.speed * 3.6f; }
    float distanceM() const { return skater_.distance; }
    int score() const { return static_cast<int>(skater_.distance + style_); }
    int best() const { return best_; }
    void setBest(int b) { best_ = b; }
    float topSpeedKmh() const { return skater_.topSpeed * 3.6f; }
    int nearMisses() const { return nearMisses_; }
    int crashObstacleKind() const { return crashKind_; }   // -1 = rail / stall
    bool newBest() const { return newBest_; }
    int countdownNumber() const;   // 3,2,1 then 0 (GO)
    float countdownProgress() const;
    const char* popupText() const { return popupText_; }
    float popupAlpha() const;
    float popupAge() const { return popupAge_; }
    float speed01() const { return saturate(skater_.speed / 36.0f); }
    float crashFlash() const { return flash_; }
    float goalMeters() const { return goal_; }
    float goalS() const { return goalS_; }                        // road position of the finish line
    float goalRemaining() const { return goal_ > 0.0f ? goalS_ - skater_.s : 0.0f; }
    bool finished() const { return finished_; }
    float finishTime() const { return finishTime_; }              // seconds from GO to the line

    // Test hooks
    AutoPilot& autopilot() { return autopilot_; }
    void setBaseSeed(uint32_t seed) { baseSeed_ = seed; }

    // LAN races: every phone starts from the same course seed.
    // `lagSeconds`: how long ago the host pressed START (the countdown is fast-forwarded so GO is simultaneous); `goalMeters`: finish line
    // distance (0 = endless).
    void startRunSeeded(uint32_t seed, float lagSeconds = 0.0f, float goalMeters = 0.0f);
    // What this rider tells the others (see net.h).
    RiderNet riderNet() const;
    void setLocalStyle(int style) { localStyle_ = style; }   // rider colour (0 = classic)
    int localStyle() const { return localStyle_; }

private:
    void resetDemo();
    void collide();
    PlayerRef playerRef() const;
    void onCrash();
    void finishRun();
    void crossFinishLine();
    void showPopup(const char* text);
    void beginRun(uint32_t worldSeed);
    void skaterFrame(Vec3& pos, Vec3& right, Vec3& up, Vec3& fwd, Vec3* roadUp = nullptr) const;
    void emitFx(float dt, bool scraping);
    void burst(const Vec3& pos, int smoke, int sparks, const Vec3& dir);

    Phase phase_ = Phase::Menu;
    Phase pausedFrom_ = Phase::Running;
    float phaseTime_ = 0.0f;
    float time_ = 0.0f;

    World world_;
    Skater skater_;
    AutoPilot autopilot_;
    ChaseCamera camera_;
    ParticleSystem fx_;
    Atmosphere atmo_;
    Rng fxRng_;

    uint32_t baseSeed_ = 1u;
    int localStyle_ = 0;
    uint32_t runCounter_ = 0u;
    uint32_t demoCounter_ = 0u;

    float style_ = 0.0f;
    float driftPoints_ = 0.0f;
    int nearMisses_ = 0;
    int crashKind_ = -1;
    int best_ = 0;
    bool newBest_ = false;
    int lastTick_ = 99;
    float orbit_ = 1.0f;
    float sunAz_ = 0.4f;
    float smokeAcc_ = 0.0f, sparkAcc_ = 0.0f, dustAcc_ = 0.0f;
    float popupAge_ = 99.0f;
    char popupText_[40] = {0};
    float flash_ = 0.0f;
    int seenTakeoffs_ = 0, seenLandings_ = 0;
    float goal_ = 0.0f, goalS_ = 0.0f;     // race length and the road position of the finish line (0 = endless run)
    bool finished_ = false;
    float finishTime_ = 0.0f, finishTimer_ = 0.0f;
    int lastPushSteps_ = 0, lastPushLands_ = 0;
    GameEvents events_;
};

// Board frame of a rider at road position (s, x), heading `heading` radians off the road tangent, leaning `lean`.
void riderFrame(const Track& track, float s, float x, float heading, float lean, Vec3& pos, Vec3& right, Vec3& up, Vec3& fwd, Vec3* roadUp = nullptr, float yRel = 0.0f);
// Pose of a rider received over the network, relative to `origin`.
SkaterPose poseFromRiderNet(const Track& track, const RiderNet& r, const Vec3& origin, float time);

}  // namespace sd
