#include "ui_font.h"

#include <algorithm>
#include <cctype>
#include <cmath>

namespace sd {
namespace {

constexpr float kStroke = 1.05f;      // stroke thickness in glyph units (1 unit = cap height / 6)
constexpr float kPad = 0.8f;          // empty margin around the ink inside a cell; also the distance range stored in the field
constexpr int kTexelsPerUnit = 8;
constexpr int kCellW = 54;            // (4 + stroke + 2 * pad) * 8 = 53.2 texels
constexpr int kCellH = 70;            // (6 + stroke + 2 * pad) * 8 = 69.2 texels
constexpr int kColumns = kAtlasSize / kCellW;
constexpr int kRows = kAtlasSolidMin / kCellH;

// Glyphs live on a 4 x 6 grid (y up). Polylines are separated by ';', points by spaces, each point is "xy".
const char* glyphStrokes(char c) {
    switch (c) {
        case 'A': return "00 26 40;12 32";
        case 'B': return "00 06 36 45 44 33 03;33 42 41 30 00";
        case 'C': return "45 36 16 05 01 10 30 41";
        case 'D': return "00 06 36 45 41 30 00";
        case 'E': return "46 06 00 40;03 33";
        case 'F': return "46 06 00;03 33";
        case 'G': return "45 36 16 05 01 10 30 41 43 23";
        case 'H': return "00 06;40 46;03 43";
        case 'I': return "16 36;26 20;10 30";
        case 'J': return "46 41 30 10 01";
        case 'K': return "00 06;46 03 40";
        case 'L': return "06 00 40";
        case 'M': return "00 06 24 46 40";
        case 'N': return "00 06 40 46";
        case 'O': return "10 01 05 16 36 45 41 30 10";
        case 'P': return "00 06 36 45 44 33 03";
        case 'Q': return "10 01 05 16 36 45 41 30 10;22 40";
        case 'R': return "00 06 36 45 44 33 03;23 40";
        case 'S': return "45 36 16 05 04 13 33 42 41 30 10 01";
        case 'T': return "06 46;26 20";
        case 'U': return "06 01 10 30 41 46";
        case 'V': return "06 20 46";
        case 'W': return "06 10 23 30 46";
        case 'X': return "00 46;06 40";
        case 'Y': return "06 23 46;23 20";
        case 'Z': return "06 46 00 40";
        case '0': return "10 01 05 16 36 45 41 30 10";
        case '1': return "15 26 20;10 30";
        case '2': return "05 16 36 45 44 00 40";
        case '3': return "05 16 36 45 44 33 13;33 42 41 30 10 01";
        case '4': return "30 36 02 42";
        case '5': return "46 06 03 33 42 41 30 10 01";
        case '6': return "45 36 16 05 01 10 30 41 42 33 03";
        case '7': return "06 46 20";
        case '8': return "13 04 05 16 36 45 44 33 13;13 02 01 10 30 41 42 33";
        case '9': return "01 10 30 41 45 36 16 05 04 13 43";
        case '.': return "00 01";
        case ':': return "01 02;04 05";
        case '-': return "13 33";
        case '/': return "00 46";
        case '!': return "26 23;20 21";
        case '+': return "21 25;03 43";
        case '?': return "05 16 36 45 44 23 22;20 21";
        case '%': return "05 15 16 06 05;30 40 41 31 30;00 46";
        case '_': return "00 40";
        case '(': return "36 15 11 30";
        case ')': return "16 35 31 10";
        case ',': return "21 10";
        case '\'': return "26 25";
        case '#': return "10 16;30 36;02 42;04 44";
        case '*': return "21 25;02 44;04 42";
        case '<': return "45 03 41";
        case '>': return "05 43 01";
        case '=': return "02 42;04 44";
        default: return nullptr;
    }
}

float advanceUnits(char c) {
    switch (c) {
        case '.': case ':': case '!': case ',': case '\'': return 3.0f;
        case ' ': return 4.0f;
        default: return 6.0f;
    }
}

char upper(char c) { return static_cast<char>(std::toupper(static_cast<unsigned char>(c))); }

// ---- metrics (cheap; independent of the atlas) -----------------------------------------------------------------------------
// Right edge of a glyph's ink, in units from its origin: widest grid column used plus one stroke.
float inkRightUnits(char c) {
    const char* g = glyphStrokes(c);
    if (!g) return 0.0f;
    int maxGx = 0;
    for (const char* s = g; *s;) {
        if (*s == ';' || *s == ' ') { ++s; continue; }
        maxGx = std::max(maxGx, s[0] - '0');
        s += 2;
    }
    return static_cast<float>(maxGx) + kStroke;
}

struct Metrics {
    float right[128];
    Metrics() {
        for (int i = 0; i < 128; ++i) right[i] = inkRightUnits(static_cast<char>(i));
    }
};

const Metrics& metrics() {
    static const Metrics m;
    return m;
}

// ---- signed-distance atlas -------------------------------------------------------------------------------------------------
// One shape of a glyph: an oriented box (a stroke segment with flat ends, or the square patch on a vertex).
struct Box {
    float cx, cy;      // centre, glyph units (origin = top-left of the ink box, y down)
    float hx, hy;      // half extents along the box's own axes
    float cs, sn;      // direction of the box's x axis
};

float boxDistance(const Box& b, float px, float py) {
    const float dx = px - b.cx, dy = py - b.cy;
    const float lx = dx * b.cs + dy * b.sn;
    const float ly = -dx * b.sn + dy * b.cs;
    const float qx = std::fabs(lx) - b.hx, qy = std::fabs(ly) - b.hy;
    const float ox = std::max(qx, 0.0f), oy = std::max(qy, 0.0f);
    return std::sqrt(ox * ox + oy * oy) + std::min(std::max(qx, qy), 0.0f);
}

void renderGlyph(const char* strokes, int cellX, int cellY, std::vector<uint8_t>& px) {
    std::vector<Box> boxes;
    float prevX = 0.0f, prevY = 0.0f;
    bool havePrev = false;
    for (const char* s = strokes; *s;) {
        if (*s == ';') { havePrev = false; ++s; continue; }
        if (*s == ' ') { ++s; continue; }
        const int gx = s[0] - '0', gy = s[1] - '0';
        s += 2;
        const float x = static_cast<float>(gx) + kStroke * 0.5f;
        const float y = static_cast<float>(6 - gy) + kStroke * 0.5f;
        if (havePrev) {
            const float dx = x - prevX, dy = y - prevY;
            const float len = std::sqrt(dx * dx + dy * dy);
            if (len > 1e-5f) boxes.push_back({(x + prevX) * 0.5f, (y + prevY) * 0.5f, len * 0.5f, kStroke * 0.5f, dx / len, dy / len});
        }
        boxes.push_back({x, y, kStroke * 0.5f, kStroke * 0.5f, 1.0f, 0.0f});   // square patch fills the corner without diagonal spurs
        prevX = x;
        prevY = y;
        havePrev = true;
    }

    std::vector<float> dist(static_cast<size_t>(kCellW) * kCellH, 2.0f * kPad);
    const float S = static_cast<float>(kTexelsPerUnit);
    for (const Box& b : boxes) {
        const float r = std::sqrt(b.hx * b.hx + b.hy * b.hy) + kPad;   // everything within the field range of this box
        const int x0 = std::max(0, static_cast<int>(std::floor((b.cx - r + kPad) * S)));
        const int x1 = std::min(kCellW - 1, static_cast<int>(std::ceil((b.cx + r + kPad) * S)));
        const int y0 = std::max(0, static_cast<int>(std::floor((b.cy - r + kPad) * S)));
        const int y1 = std::min(kCellH - 1, static_cast<int>(std::ceil((b.cy + r + kPad) * S)));
        for (int ty = y0; ty <= y1; ++ty) {
            const float uy = (static_cast<float>(ty) + 0.5f) / S - kPad;
            for (int tx = x0; tx <= x1; ++tx) {
                const float ux = (static_cast<float>(tx) + 0.5f) / S - kPad;
                float& d = dist[static_cast<size_t>(ty) * kCellW + tx];
                d = std::min(d, boxDistance(b, ux, uy));
            }
        }
    }
    for (int ty = 0; ty < kCellH; ++ty) {
        for (int tx = 0; tx < kCellW; ++tx) {
            const float d = dist[static_cast<size_t>(ty) * kCellW + tx];
            const float v = std::min(1.0f, std::max(0.0f, 0.5f - d / (2.0f * kPad)));   // 0.5 = the glyph's edge, 1 = deep inside
            px[static_cast<size_t>(cellY + ty) * kAtlasSize + (cellX + tx)] = static_cast<uint8_t>(v * 255.0f + 0.5f);
        }
    }
}

struct Glyph {
    bool ink = false;
    float u0 = 0.0f, v0 = 0.0f, u1 = 0.0f, v1 = 0.0f;
};

struct Atlas {
    std::vector<uint8_t> pixels;
    Glyph glyphs[128];

    Atlas() : pixels(static_cast<size_t>(kAtlasSize) * kAtlasSize, 0) {
        int slot = 0;
        for (int c = 33; c < 127; ++c) {
            const char* strokes = glyphStrokes(static_cast<char>(c));
            if (!strokes) continue;
            const int col = slot % kColumns, row = slot / kColumns;
            if (row >= kRows) break;
            ++slot;
            const int ox = col * kCellW, oy = row * kCellH;
            renderGlyph(strokes, ox, oy, pixels);
            Glyph& g = glyphs[c];
            g.ink = true;
            g.u0 = static_cast<float>(ox) / kAtlasSize;
            g.v0 = static_cast<float>(oy) / kAtlasSize;
            g.u1 = static_cast<float>(ox + kCellW) / kAtlasSize;
            g.v1 = static_cast<float>(oy + kCellH) / kAtlasSize;
        }
        for (int y = kAtlasSolidMin; y < kAtlasSize; ++y)
            for (int x = kAtlasSolidMin; x < kAtlasSize; ++x) pixels[static_cast<size_t>(y) * kAtlasSize + x] = 255;
    }
};

const Atlas& atlas() {
    static const Atlas a;
    return a;
}

}  // namespace

const std::vector<uint8_t>& fontAtlasPixels() { return atlas().pixels; }

float textWidth(const char* text, float size) {
    const Metrics& m = metrics();
    const float u = size / 6.0f;
    float pen = 0.0f, end = 0.0f;
    for (const char* p = text; *p; ++p) {
        const char ch = upper(*p);
        const unsigned idx = static_cast<unsigned char>(ch);
        if (idx < 128 && m.right[idx] > 0.0f) end = pen + m.right[idx] * u;
        pen += advanceUnits(ch) * u;
    }
    return end;
}

float drawText(UiBatch& ui, const char* text, float x, float y, float size, Rgba8 color, TextAlign align, float halo) {
    const float width = textWidth(text, size);
    if (color.a == 0) return width;
    const Atlas& at = atlas();
    const float u = size / 6.0f;
    float pen = x;
    if (align == TextAlign::Center) pen = x - width * 0.5f;
    else if (align == TextAlign::Right) pen = x - width;
    const uint8_t halo8 = static_cast<uint8_t>(std::min(1.0f, std::max(0.0f, halo)) * 255.0f + 0.5f);
    const float cellW = static_cast<float>(kCellW) / kTexelsPerUnit * u;
    const float cellH = static_cast<float>(kCellH) / kTexelsPerUnit * u;

    for (const char* p = text; *p; ++p) {
        const char ch = upper(*p);
        const unsigned idx = static_cast<unsigned char>(ch);
        if (idx < 128 && at.glyphs[idx].ink) {
            const Glyph& g = at.glyphs[idx];
            ui.glyphQuad(pen - kPad * u, y - kPad * u, cellW, cellH, g.u0, g.v0, g.u1, g.v1, color, halo8);
        }
        pen += advanceUnits(ch) * u;
    }
    return width;
}

}  // namespace sd
