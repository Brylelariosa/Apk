// hud_mp.h - the LAN multiplayer screens: lobby (choose / search / room), live standings with name tags, and the results table.
// Pure presentation: the engine fills an MpModel from the network session and draws / hit-tests it through these functions.
#pragma once

#include "math3d.h"
#include "ui_action.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

constexpr int kMpRows = 6;

struct MpRow {
    char name[16] = {};
    int score = 0;
    float distanceM = 0.0f;
    int style = 0;            // rider colour (the slot)
    bool self = false;
    bool crashed = false;
    bool finished = false;    // this player's run is over
    bool crossed = false;     // crossed the finish line
    float finishTime = 0.0f;  // seconds from GO to the line
    float toGoM = 0.0f;       // metres still to ride to the finish line
    bool host = false;
    int players = 0;          // found hosts: how many are in that room
    bool racing = false;      // found hosts: a race is running there (cannot join)
};

struct MpTag {
    Vec2 pos;                 // anchor on screen, above the rider's head
    char name[16] = {};
    int style = 0;
    float ahead = 0.0f;       // metres ahead of me (negative = behind)
    bool crashed = false;
    float alpha = 1.0f;
};

struct MpModel {
    enum class Screen { Off, Choose, Search, Room };
    Screen screen = Screen::Off;   // lobby screens shown over the menu
    bool racing = false;           // a LAN race is the current run: standings, name tags, no pausing
    bool isHost = false, canStart = false, joining = false;
    char status[56] = {};          // why something failed, or progress
    char address[48] = {};         // this device's Wi-Fi address
    int rowCount = 0;              // the room's players, the found hosts, or the standings (best first)
    MpRow rows[kMpRows];
    int rank = 0;                  // my place in the standings (1-based)
    bool allDone = false;          // everybody's run is over
    float goalM = 0.0f;            // race length (0 = endless); in the room screen: what the host has picked
    int tagCount = 0;
    MpTag tags[kMpRows];
};

struct LobbyRects {
    Rect back;                     // top-left: BACK (choose) / LEAVE (search, room)
    Rect host, search;             // choose: the two big cards
    Rect start;                    // room: START (host only)
    Rect goal;                     // room: GOAL button (host only)
    Rect rows[kMpRows];            // room: the players; search: the found hosts
};
LobbyRects lobbyRects(const UiLayout& L);

Rgba8 riderColor(int style);

void drawLobby(UiBatch& ui, const UiLayout& L, const MpModel& mp, float time);
UiAction lobbyTap(const UiLayout& L, const MpModel& mp, float x, float y, int* index);
void drawStandings(UiBatch& ui, const UiLayout& L, const MpModel& mp);   // left side, under the speed readout
void drawNameTags(UiBatch& ui, const UiLayout& L, const MpModel& mp);
void drawResults(UiBatch& ui, const UiLayout& L, const MpModel& mp, float alpha, float time);   // the game-over panel of a LAN race

}  // namespace sd
