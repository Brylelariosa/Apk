// model_kit.h - building blocks for the procedural models (cars, rider, longboard): smooth lofted bodies, tubes and ellipsoids
// on top of MeshData's boxes and frusta.
#pragma once

#include <functional>
#include <vector>

#include "mesh_data.h"

namespace sd {
namespace kit {

using Ring = std::vector<Vec3>;
// Colour of a surface point, from its position and outward normal (both in the loft's local space). `mat` starts as the loft's
// material and may be changed per vertex (e.g. paint that takes the car's tint next to plain black plastic).
using Painter = std::function<Rgba8(const Vec3& pos, const Vec3& normal, Material& mat)>;

// Closed outline of a rounded trapezoid in the local XY plane at depth z: bottom edge halfWBottom wide at yBottom, top edge halfWTop wide
// at yTop, corner radii rBottom / rTop. Every ring made with the same cornerSegments has the same number of points.
Ring roundedSection(float z, float yBottom, float yTop, float halfWBottom, float halfWTop, float rBottom, float rTop, int cornerSegments = 3,
                    float xCentre = 0.0f);

// Smooth-shaded solid through `stations` (rings with equal point counts, ordered along the body). Normals are averaged over the
// surface so the form reads as one rounded body; the optional end caps are flat.
void addLoft(MeshData& m, const Mat4& xf, const std::vector<Ring>& stations, const Painter& paint, Material mat, bool capStart = true,
             bool capEnd = true);

// Tapered tube between two points (limbs, axles, pipes).
void addTube(MeshData& m, const Vec3& a, const Vec3& b, float rA, float rB, int segments, Rgba8 cA, Rgba8 cB, Material mat = {},
             bool capA = true, bool capB = true, const Vec3& hint = Vec3(0.0f, 0.0f, 1.0f));

// Smooth ellipsoid (helmet shell, joints, pads).
void addEllipsoid(MeshData& m, const Mat4& xf, const Vec3& radii, int subdiv, Rgba8 bottom, Rgba8 top, Material mat = {});

// One point of a lathe profile: radius, position along the axis (local +Y), colour and material at that point.
struct LathePoint {
    float r = 0.0f, y = 0.0f;
    Rgba8 color;
    Material mat;
    bool crease = false;   // hard edge: the surface normal jumps here (the point is emitted twice, once per side)
};

// Surface of revolution around the local Y axis (wheels, bushings, nuts, discs). The profile is walked from one end of the axis to
// the other with the outside on the right: start on the -Y end, go outwards, run up the side, come back in on the +Y end. Normals
// follow the profile (smooth, except at crease points), so rounded shoulders light like real rounded urethane.
void addLathe(MeshData& m, const Mat4& xf, const std::vector<LathePoint>& profile, int segments);

}  // namespace kit
}  // namespace sd
