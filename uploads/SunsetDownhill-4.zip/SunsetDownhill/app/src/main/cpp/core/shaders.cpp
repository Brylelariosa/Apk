#include "shaders.h"

namespace sd {
namespace shaders {
namespace {

const char* kVersion = "#version 300 es\n";
const char* kFragPrecision = "precision highp float;\nprecision highp int;\n";

// ---------------------------------------------------------------------------------------
const char* kNoise = R"GLSL(
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float fbm(vec2 p) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < 4; ++i) {
        s += a * vnoise(p);
        p = p * 2.03 + 17.1;
        a *= 0.5;
    }
    return s;
}
)GLSL";

// Lighting uniforms + helpers shared by terrain and mesh fragment shaders.
const char* kLit = R"GLSL(
uniform vec3 u_sunDir;
uniform vec3 u_sunColor;
uniform vec3 u_ambSky;
uniform vec3 u_ambGround;
uniform vec3 u_fogColor;
uniform vec3 u_fogSun;
uniform float u_fogDensity;
uniform float u_time;
uniform float u_shadowOn;
uniform vec2 u_shadowTexel;
uniform highp sampler2DShadow u_shadowMap;

vec3 fogColorDir(vec3 dir) {
    float s = clamp(dot(dir, u_sunDir), 0.0, 1.0);
    return mix(u_fogColor, u_fogSun, pow(s, 3.0));
}
vec3 finishColor(vec3 c) {
    return 1.0 - exp(-c * 1.25);
}
// sc is already in [0,1] shadow-map space (bias matrix baked into u_shadowMat).
float shadowFactor(vec4 sc) {
    if (u_shadowOn < 0.5) return 1.0;
    vec3 p = sc.xyz / sc.w;
    vec2 e = abs(p.xy - 0.5) * 2.0;
    float fade = 1.0 - smoothstep(0.78, 1.0, max(e.x, e.y));
    if (p.z >= 1.0 || fade <= 0.0) return 1.0;
    float bias = 0.0006;
    float s = 0.0;
    s += texture(u_shadowMap, vec3(p.xy + vec2(-0.75, -0.25) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2( 0.25, -0.75) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2( 0.75,  0.25) * u_shadowTexel, p.z - bias));
    s += texture(u_shadowMap, vec3(p.xy + vec2(-0.25,  0.75) * u_shadowTexel, p.z - bias));
    return mix(1.0, s * 0.25, fade);
}
)GLSL";

// Per-instance transform; with disabled instance arrays the constants give an identity transform.
const char* kInstance = R"GLSL(
layout(location = 0) in vec3 a_pos;
layout(location = 1) in vec3 a_nrm;
layout(location = 2) in vec4 a_col;
layout(location = 3) in vec4 a_mat;
layout(location = 4) in vec4 i_posYaw;
layout(location = 5) in vec4 i_scale;
layout(location = 6) in vec4 i_tint;
uniform float u_time;

void instanceTransform(out vec3 wpos, out vec3 wnrm) {
    float cy = cos(i_posYaw.w);
    float sy = sin(i_posYaw.w);
    float ca = cos(-i_scale.w);
    float sa = sin(-i_scale.w);
    vec3 p = a_pos * vec3(i_scale.x, i_scale.y, i_scale.x);
    float h = a_pos.y * i_scale.y;
    float sway = a_mat.w * (sin(u_time * 1.4 + i_scale.z) + 0.5 * sin(u_time * 2.3 + i_scale.z * 1.7)) * 0.012 * h;
    p.x += sway;
    vec3 n = a_nrm;
    p = vec3(p.x, ca * p.y - sa * p.z, sa * p.y + ca * p.z);
    n = vec3(n.x, ca * n.y - sa * n.z, sa * n.y + ca * n.z);
    p = vec3(cy * p.x - sy * p.z, p.y, sy * p.x + cy * p.z);
    n = vec3(cy * n.x - sy * n.z, n.y, sy * n.x + cy * n.z);
    wpos = i_posYaw.xyz + p;
    wnrm = n;
}
)GLSL";

}  // namespace

// ---------------------------------------------------------------------------------------
// Sky
// ---------------------------------------------------------------------------------------
std::string skyVertex() {
    return std::string(kVersion) + R"GLSL(
out vec2 v_ndc;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_ndc = p * 2.0 - 1.0;
    gl_Position = vec4(v_ndc, 1.0, 1.0);
}
)GLSL";
}

std::string skyFragment() {
    return std::string(kVersion) + kFragPrecision + kNoise + R"GLSL(
uniform vec3 u_camRight;
uniform vec3 u_camUp;
uniform vec3 u_camFwd;
uniform vec2 u_tanFov;
uniform float u_time;
uniform vec3 u_sunDir;
uniform vec3 u_sunColor;
uniform vec3 u_skyTop;
uniform vec3 u_skyMid;
uniform vec3 u_fogColor;
uniform vec3 u_fogSun;
uniform vec3 u_cloudLit;
uniform vec3 u_cloudShade;
uniform vec3 u_mtnNear;
uniform vec3 u_mtnFar;
in vec2 v_ndc;
out vec4 o_col;

vec3 hazeDir(vec3 dir) {
    float s = clamp(dot(dir, u_sunDir), 0.0, 1.0);
    return mix(u_fogColor, u_fogSun, pow(s, 3.0));
}

vec3 mountains(vec3 rd, vec3 col, vec3 haze, float sunAz) {
    vec2 dxz = normalize(rd.xz + vec2(1e-5));
    float el = rd.y;
    float fade = 0.25 + 0.75 * smoothstep(0.0, 0.05, el);
    float sunSide = pow(clamp(dot(dxz, normalize(u_sunDir.xz + vec2(1e-5))) * 0.5 + 0.5, 0.0, 1.0), 2.0);
    for (int i = 0; i < 3; ++i) {
        float fi = float(i);
        float n = vnoise(dxz * (2.2 + fi * 1.4) + vec2(fi * 31.7, fi * 11.3)) * 0.65
                + vnoise(dxz * (7.0 + fi * 3.0) + vec2(fi * 7.1, 3.0)) * 0.35;
        float ridge = (0.050 - 0.016 * fi) + n * (0.150 - 0.035 * fi);
        float cover = (1.0 - smoothstep(ridge - 0.0025, ridge + 0.0025, el)) * fade;
        vec3 base = mix(u_mtnFar, u_mtnNear, fi * 0.5);
        vec3 mc = mix(base, haze, 0.55 - 0.22 * fi);
        // sunlit snowy crests on the far ranges
        float snow = smoothstep(ridge - 0.050, ridge - 0.012, el) * (1.0 - 0.45 * fi) * smoothstep(0.45, 0.75, n);
        vec3 snowCol = mix(vec3(0.62, 0.55, 0.82), u_sunColor * 0.85, sunSide);
        mc = mix(mc, snowCol, snow * 0.85);
        col = mix(col, mc, cover);
    }
    return col;
}

void main() {
    vec3 rd = normalize(u_camFwd + u_camRight * (v_ndc.x * u_tanFov.x) + u_camUp * (v_ndc.y * u_tanFov.y));
    float el = rd.y;
    float sd = clamp(dot(rd, u_sunDir), 0.0, 1.0);
    vec3 haze = hazeDir(rd);
    if (el < -0.036) {   // below the horizon the sky is pure haze; the terrain covers most of it anyway
        o_col = vec4(1.0 - exp(-haze * 1.25), 1.0);
        return;
    }

    vec3 col = mix(haze, u_skyMid, smoothstep(0.0, 0.30, el));
    col = mix(col, u_skyTop, smoothstep(0.12, 0.85, el));

    // sun glow and disc
    col += u_sunColor * (pow(sd, 6.0) * 0.30 + pow(sd, 80.0) * 0.85);
    col = mix(col, vec3(2.0, 1.5, 1.05), smoothstep(0.99962, 0.99987, sd));

    // layered clouds, lit from the low sun
    if (el > 0.005) {
        vec2 cuv = rd.xz / (el + 0.10);
        float cn = fbm(cuv * vec2(0.42, 0.95) + vec2(u_time * 0.006, 3.0));
        float cov = smoothstep(0.50, 0.80, cn) * smoothstep(0.005, 0.12, el);
        float sunSide = pow(clamp(dot(normalize(rd.xz + vec2(1e-5)), normalize(u_sunDir.xz + vec2(1e-5))) * 0.5 + 0.5, 0.0, 1.0), 2.0);
        float thick = smoothstep(0.55, 0.95, cn);
        vec3 cc = mix(u_cloudShade, u_cloudLit, clamp(sunSide * (1.15 - 0.55 * thick), 0.0, 1.0));
        cc = mix(cc, vec3(1.7, 1.1, 0.9), pow(sd, 10.0) * 0.6 * (1.0 - thick));
        col = mix(col, cc, cov * 0.88);
    }

    col = mountains(rd, col, haze, 0.0);

    // below the horizon: atmospheric haze (the terrain mesh covers most of this)
    col = mix(col, haze, 1.0 - smoothstep(-0.035, 0.015, el));

    o_col = vec4(1.0 - exp(-col * 1.25), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Terrain / road
// ---------------------------------------------------------------------------------------
std::string terrainVertex() {
    return std::string(kVersion) + R"GLSL(
uniform mat4 u_viewProj;
uniform mat4 u_shadowMat;
layout(location = 0) in vec3 a_pos;
layout(location = 1) in vec3 a_nrm;
layout(location = 2) in vec3 a_surf;
out vec3 v_pos;
out vec3 v_nrm;
out vec3 v_surf;
out vec4 v_sh;
void main() {
    v_pos = a_pos;
    v_nrm = a_nrm;
    v_surf = a_surf;
    v_sh = u_shadowMat * vec4(a_pos + a_nrm * 0.12, 1.0);
    gl_Position = u_viewProj * vec4(a_pos, 1.0);
}
)GLSL";
}

std::string terrainFragment() {
    return std::string(kVersion) + kFragPrecision + kNoise + kLit + R"GLSL(
in vec3 v_pos;
in vec3 v_nrm;
in vec3 v_surf;
in vec4 v_sh;
out vec4 o_col;

float lineMask(float x, float c, float hw, float aa) {
    return 1.0 - smoothstep(hw - aa, hw + aa, abs(x - c));
}

void main() {
    float d = v_surf.x;
    float s = v_surf.y;
    float edge = v_surf.z;
    float ad = abs(d);
    vec3 N = normalize(v_nrm);
    float dist = length(v_pos);
    vec3 V = -v_pos / max(dist, 0.001);
    float detail = 1.0 - smoothstep(50.0, 200.0, dist);
    float nFine = vnoise(vec2(s * 1.3, d * 1.3));
    float nMed = vnoise(vec2(s * 0.11, d * 0.11));
    float aa = fwidth(d) * 1.1 + 0.002;

    // asphalt with wheel tracks, worn double-yellow centre line and white edge lines
    vec3 asphalt = vec3(0.140, 0.138, 0.148) + (nFine - 0.5) * 0.05 * detail + (nMed - 0.5) * 0.045;
    float wheel = exp(-pow((ad - 1.75) / 0.6, 2.0));
    asphalt *= 1.0 - 0.22 * wheel;
    float yellow = max(lineMask(d, -0.16, 0.055, aa), lineMask(d, 0.16, 0.055, aa));
    float white = max(lineMask(d, -3.3, 0.07, aa), lineMask(d, 3.3, 0.07, aa));
    float worn = 0.78 + 0.22 * vnoise(vec2(s * 0.6, d * 3.0));
    asphalt = mix(asphalt, vec3(0.93, 0.70, 0.10), yellow * 0.92 * worn);
    asphalt = mix(asphalt, vec3(0.86), white * 0.88 * worn);

    vec3 gravel = vec3(0.30, 0.265, 0.235) + (nFine - 0.5) * 0.08 * detail;

    vec3 grassDry = vec3(0.37, 0.31, 0.12);
    vec3 grassGreen = vec3(0.17, 0.25, 0.09);
    vec3 dirt = vec3(0.30, 0.21, 0.14);
    vec3 rock = vec3(0.30, 0.27, 0.27);
    float grassPatch = vnoise(vec2(s, d) * 0.04 + 7.0);
    vec3 ground = mix(grassGreen, grassDry, smoothstep(0.35, 0.70, grassPatch));
    ground = mix(ground, dirt, smoothstep(0.55, 0.85, nMed * 0.6 + nFine * 0.4) * 0.55);
    ground = mix(ground, rock, smoothstep(0.30, 0.52, 1.0 - N.y));
    ground *= 0.88 + 0.24 * nFine * detail;
    ground = mix(ground, dirt * 0.9, (1.0 - smoothstep(5.2, 7.5, ad)) * 0.6);

    float onRoad = 1.0 - smoothstep(3.6 - aa - 0.04, 3.6 + aa + 0.04, ad);
    float onShoulder = 1.0 - smoothstep(5.1, 5.3, ad);
    vec3 albedo = mix(ground, gravel, onShoulder);
    albedo = mix(albedo, asphalt, onRoad);
    float gloss = onRoad * 0.55 * (1.0 - yellow * 0.7 - white * 0.5);

    float ndl = max(dot(N, u_sunDir), 0.0);
    float sh = shadowFactor(v_sh);
    vec3 amb = mix(u_ambGround, u_ambSky, N.y * 0.5 + 0.5);
    vec3 col = albedo * (u_sunColor * ndl * sh + amb);

    // glossy sheen: sun streak + sky reflection at grazing angles
    vec3 H = normalize(u_sunDir + V);
    float spec = pow(max(dot(N, H), 0.0), 36.0) * gloss * 1.4 * sh;
    float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0);
    vec3 skyRefl = fogColorDir(reflect(-V, N));
    col += u_sunColor * spec + skyRefl * fres * gloss * 0.65;

    float f = 1.0 - exp(-pow(dist * u_fogDensity, 2.0));
    f = max(f, smoothstep(0.55, 1.0, edge));
    col = mix(col, fogColorDir(-V), f);
    o_col = vec4(finishColor(col), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Instanced scenery + dynamic mesh
// ---------------------------------------------------------------------------------------
std::string meshVertex() {
    return std::string(kVersion) + kInstance + R"GLSL(
uniform mat4 u_viewProj;
uniform mat4 u_shadowMat;
out vec3 v_pos;
out vec3 v_nrm;
out vec4 v_col;
out vec4 v_mat;
out vec4 v_tint;
out vec4 v_sh;
void main() {
    vec3 wp, wn;
    instanceTransform(wp, wn);
    v_pos = wp;
    v_nrm = wn;
    v_col = a_col;
    v_mat = a_mat;
    v_tint = i_tint;
    v_sh = u_shadowMat * vec4(wp + wn * 0.06, 1.0);
    gl_Position = u_viewProj * vec4(wp, 1.0);
}
)GLSL";
}

std::string meshFragment() {
    return std::string(kVersion) + kFragPrecision + kLit + R"GLSL(
in vec3 v_pos;
in vec3 v_nrm;
in vec4 v_col;
in vec4 v_mat;
in vec4 v_tint;
in vec4 v_sh;
out vec4 o_col;
void main() {
    vec3 N = normalize(v_nrm);
    float dist = length(v_pos);
    vec3 V = -v_pos / max(dist, 0.001);
    vec3 albedo = v_col.rgb * mix(vec3(1.0), v_tint.rgb, v_mat.x);
    float ndl = dot(N, u_sunDir);
    float foliage = v_mat.z;
    float wrap = mix(max(ndl, 0.0), clamp(ndl * 0.5 + 0.5, 0.0, 1.0), foliage * 0.7);
    float sh = shadowFactor(v_sh);
    vec3 amb = mix(u_ambGround, u_ambSky, N.y * 0.5 + 0.5);
    vec3 col = albedo * (u_sunColor * wrap * sh + amb);

    // back light: sun behind the object as seen from the camera
    float back = clamp(-dot(V, u_sunDir), 0.0, 1.0);
    float rim = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
    col += u_sunColor * albedo * (back * back) * (foliage * 0.9 + rim * 0.35 * sh);
    col += v_col.rgb * v_mat.y * 2.5;

    float f = 1.0 - exp(-pow(dist * u_fogDensity, 2.0));
    f = max(f, v_tint.a);
    col = mix(col, fogColorDir(-V), f);
    o_col = vec4(finishColor(col), 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Shadow depth pass
// ---------------------------------------------------------------------------------------
std::string shadowVertex() {
    return std::string(kVersion) + kInstance + R"GLSL(
uniform mat4 u_lightVP;
void main() {
    vec3 wp, wn;
    instanceTransform(wp, wn);
    gl_Position = u_lightVP * vec4(wp, 1.0);
}
)GLSL";
}

std::string shadowFragment() {
    return std::string(kVersion) + "precision mediump float;\nvoid main() {}\n";
}

// ---------------------------------------------------------------------------------------
// Particles
// ---------------------------------------------------------------------------------------
std::string particleVertex() {
    return std::string(kVersion) + R"GLSL(
uniform mat4 u_view;
uniform mat4 u_proj;
layout(location = 0) in vec2 a_corner;
layout(location = 1) in vec4 i_posSize;
layout(location = 2) in vec4 i_color;
layout(location = 3) in vec3 i_vel;
out vec2 v_uv;
out vec4 v_color;
void main() {
    vec3 vp = (u_view * vec4(i_posSize.xyz, 1.0)).xyz;
    vec3 vv = (u_view * vec4(i_vel, 0.0)).xyz;
    float vl = length(vv.xy);
    vec2 off = a_corner * i_posSize.w;
    if (vl > 0.01) {
        vec2 ax = vv.xy / vl;
        vec2 ay = vec2(-ax.y, ax.x);
        float len = i_posSize.w * (1.0 + vl * 0.09);
        off = ax * a_corner.x * len + ay * a_corner.y * i_posSize.w;
    }
    vp.xy += off;
    gl_Position = u_proj * vec4(vp, 1.0);
    v_uv = a_corner;
    v_color = i_color;
}
)GLSL";
}

std::string particleFragment() {
    return std::string(kVersion) + kFragPrecision + R"GLSL(
uniform vec3 u_light;
uniform float u_additive;
in vec2 v_uv;
in vec4 v_color;
out vec4 o_col;
void main() {
    float d = length(v_uv);
    float a = 1.0 - smoothstep(0.25, 1.0, d);
    if (a <= 0.003) discard;
    vec3 rgb = mix(v_color.rgb * u_light, v_color.rgb * 2.2, u_additive);
    o_col = vec4(1.0 - exp(-rgb * 1.25), v_color.a * a);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// Post processing
// ---------------------------------------------------------------------------------------
std::string postVertex() {
    return std::string(kVersion) + R"GLSL(
out vec2 v_uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
)GLSL";
}

std::string postFragment() {
    return std::string(kVersion) + kFragPrecision + kNoise + R"GLSL(
uniform sampler2D u_scene;
uniform vec2 u_texel;
uniform float u_aspect;
uniform float u_speed;
uniform float u_slide;
uniform float u_flash;
uniform float u_time;
uniform vec2 u_center;
uniform vec2 u_sunUv;
uniform float u_sunVis;
uniform vec3 u_sunColor;
uniform float u_fxaa;
uniform float u_sharpen;
uniform int u_taps;
in vec2 v_uv;
out vec4 o_col;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec3 fxaaSample(vec2 uv) {
    vec3 rgbM = texture(u_scene, uv).rgb;
    if (u_fxaa < 0.5) return rgbM;
    vec3 rgbNW = texture(u_scene, uv + vec2(-1.0, -1.0) * u_texel).rgb;
    vec3 rgbNE = texture(u_scene, uv + vec2( 1.0, -1.0) * u_texel).rgb;
    vec3 rgbSW = texture(u_scene, uv + vec2(-1.0,  1.0) * u_texel).rgb;
    vec3 rgbSE = texture(u_scene, uv + vec2( 1.0,  1.0) * u_texel).rgb;
    float lM = luma(rgbM), lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * (0.25 / 8.0), 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * u_texel;
    vec3 rgbA = 0.5 * (texture(u_scene, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture(u_scene, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture(u_scene, uv + dir * -0.5).rgb + texture(u_scene, uv + dir * 0.5).rgb);
    float lB = luma(rgbB);
    return (lB < lMin || lB > lMax) ? rgbA : rgbB;
}

// Light unsharp mask limited to the local min/max so it can't ring; hides some of the softness of an upscaled scene.
vec3 sharpenSample(vec2 uv, vec3 c) {
    if (u_sharpen < 0.01) return c;
    vec3 n = texture(u_scene, uv + vec2(0.0, -1.0) * u_texel).rgb;
    vec3 s = texture(u_scene, uv + vec2(0.0,  1.0) * u_texel).rgb;
    vec3 e = texture(u_scene, uv + vec2( 1.0, 0.0) * u_texel).rgb;
    vec3 w = texture(u_scene, uv + vec2(-1.0, 0.0) * u_texel).rgb;
    vec3 mn = min(c, min(min(n, s), min(e, w)));
    vec3 mx = max(c, max(max(n, s), max(e, w)));
    return clamp(c + (c - (n + s + e + w) * 0.25) * u_sharpen, mn, mx);
}

void main() {
    vec2 uv = v_uv;
    vec2 aspectVec = vec2(u_aspect, 1.0);
    vec2 toC = uv - u_center;
    float r = length(toC * aspectVec);

    vec3 col = sharpenSample(uv, fxaaSample(uv));

    // radial speed blur + chromatic aberration toward the edges
    float blurAmt = u_speed * smoothstep(0.26, 0.98, r) + u_slide * 0.10 * smoothstep(0.30, 0.90, r);
    if (blurAmt > 0.003) {
        vec3 acc = col;
        float wsum = 1.0;
        float inv = 1.0 / float(max(u_taps - 1, 1));
        for (int i = 1; i < 10; ++i) {
            if (i >= u_taps) break;
            float t = float(i) * inv;
            vec2 suv = uv - toC * (t * blurAmt * 0.10);
            float w = 1.0 - t * 0.6;
            acc += texture(u_scene, suv).rgb * w;
            wsum += w;
        }
        col = mix(col, acc / wsum, clamp(blurAmt * 4.0, 0.0, 1.0));
        vec2 ca = toC * blurAmt * 0.0045;
        col.r = mix(col.r, texture(u_scene, uv - ca).r, 0.6);
        col.b = mix(col.b, texture(u_scene, uv + ca).b, 0.6);
    }

    // speed streaks near the edges at high speed
    vec2 q = toC * aspectVec;
    float ang = atan(q.y, q.x) * (40.0 / 6.2831853);
    float cell = floor(ang);
    float rnd = hash12(vec2(cell, floor(u_time * 22.0)));
    float line = (1.0 - smoothstep(0.03, 0.10, abs(fract(ang) - 0.5))) * step(0.80, rnd);
    col += line * smoothstep(0.40, 0.90, r) * pow(u_speed, 2.5) * 0.16;

    // sun glare, only when the sun disc is not hidden by the scene
    vec2 sdv = (uv - u_sunUv) * aspectVec;
    float gd = dot(sdv, sdv);
    float occ = u_sunVis * smoothstep(0.30, 0.75, luma(texture(u_scene, clamp(u_sunUv, vec2(0.0), vec2(1.0))).rgb));
    col += u_sunColor * (exp(-gd * 12.0) * 0.16 + exp(-gd * 110.0) * 0.30) * occ;

    // vignette, grade, dither, crash flash
    col *= 1.0 - smoothstep(0.45, 1.30, r) * (0.26 + 0.26 * u_speed);
    float l = luma(col);
    col = mix(col, col * vec3(1.06, 0.99, 0.91), smoothstep(0.35, 0.90, l));
    col = mix(col, col * vec3(0.90, 0.96, 1.10), 1.0 - smoothstep(0.0, 0.35, l));
    col += (hash12(gl_FragCoord.xy + fract(u_time) * 61.0) - 0.5) / 255.0;
    col = mix(col, vec3(1.0, 0.93, 0.85), u_flash);
    o_col = vec4(col, 1.0);
}
)GLSL";
}

// ---------------------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------------------
std::string uiVertex() {
    return std::string(kVersion) + R"GLSL(
uniform vec2 u_screen;
layout(location = 0) in vec2 a_pos;
layout(location = 1) in vec2 a_uv;
layout(location = 2) in vec4 a_col;
layout(location = 3) in float a_halo;
out vec4 v_col;
out vec2 v_uv;
out float v_halo;
void main() {
    v_col = a_col;
    v_uv = a_uv;
    v_halo = a_halo;
    gl_Position = vec4(a_pos.x / u_screen.x * 2.0 - 1.0, 1.0 - a_pos.y / u_screen.y * 2.0, 0.0, 1.0);
}
)GLSL";
}

// Plain shapes sample the atlas' solid block (distance 1.0 -> full coverage, so the output is exactly the vertex colour).
// Glyphs sample their signed-distance cell: 0.5 is the edge of the stroke. The fill and the soft dark halo behind it are
// composited here with correct "over" maths, so a glyph is one fragment per pixel and translucent text fades evenly.
std::string uiFragment() {
    return std::string(kVersion) + kFragPrecision + R"GLSL(
uniform highp sampler2D u_atlas;
in vec4 v_col;
in vec2 v_uv;
in float v_halo;
out vec4 o_col;
void main() {
    float d = texture(u_atlas, v_uv).r;
    float w = max(fwidth(d) * 0.75, 0.0005);
    float fill = smoothstep(0.5 - w, 0.5 + w, d);
    float halo = v_halo * 0.62 * smoothstep(0.26, 0.5, d) * (1.0 - fill);
    float aFill = v_col.a * fill;
    float aHalo = v_col.a * halo;
    float a = aFill + aHalo * (1.0 - aFill);
    vec3 haloCol = vec3(0.094, 0.031, 0.141);
    vec3 rgb = (v_col.rgb * aFill + haloCol * aHalo * (1.0 - aFill)) / max(a, 0.0001);
    o_col = vec4(rgb, a);
}
)GLSL";
}

}  // namespace shaders
}  // namespace sd
