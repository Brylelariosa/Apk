#include "model_kit.h"

#include <algorithm>
#include <cmath>

namespace sd {
namespace kit {

Ring roundedSection(float z, float yBottom, float yTop, float halfWBottom, float halfWTop, float rBottom, float rTop, int cornerSegments,
                    float xCentre) {
    const float halfH = std::max(0.0005f, (yTop - yBottom) * 0.5f);
    const float rb = std::max(0.0f, std::min({rBottom, halfWBottom, halfH}));
    const float rt = std::max(0.0f, std::min({rTop, halfWTop, halfH}));
    const int segs = std::max(1, cornerSegments);
    // corner centres: bottom-right, top-right, top-left, bottom-left; each arc sweeps 90 degrees counter-clockwise
    const float cx[4] = {xCentre + halfWBottom - rb, xCentre + halfWTop - rt, xCentre - halfWTop + rt, xCentre - halfWBottom + rb};
    const float cy[4] = {yBottom + rb, yTop - rt, yTop - rt, yBottom + rb};
    const float rad[4] = {rb, rt, rt, rb};
    Ring ring;
    ring.reserve(static_cast<size_t>(4 * (segs + 1)));
    for (int k = 0; k < 4; ++k) {
        const float a0 = -kPi * 0.5f + kPi * 0.5f * static_cast<float>(k);
        for (int s = 0; s <= segs; ++s) {
            const float a = a0 + kPi * 0.5f * static_cast<float>(s) / static_cast<float>(segs);
            ring.push_back(Vec3(cx[k] + rad[k] * std::cos(a), cy[k] + rad[k] * std::sin(a), z));
        }
    }
    return ring;
}

namespace {

Vec3 centroid(const Ring& r) {
    Vec3 c(0.0f, 0.0f, 0.0f);
    for (const Vec3& p : r) c += p;
    return c * (1.0f / static_cast<float>(std::max<size_t>(1, r.size())));
}

}  // namespace

void addLoft(MeshData& m, const Mat4& xf, const std::vector<Ring>& st, const Painter& paint, Material mat, bool capStart, bool capEnd) {
    const size_t S = st.size();
    if (S < 2) return;
    const size_t N = st[0].size();
    if (N < 3) return;
    for (const Ring& r : st)
        if (r.size() != N) return;

    std::vector<Vec3> ctr(S);
    for (size_t i = 0; i < S; ++i) ctr[i] = centroid(st[i]);

    // smooth vertex normals: sum of the (outward-oriented) quad normals around each vertex
    std::vector<Vec3> nrm(S * N, Vec3(0.0f, 0.0f, 0.0f));
    for (size_t i = 0; i + 1 < S; ++i) {
        for (size_t j = 0; j < N; ++j) {
            const size_t j1 = (j + 1) % N;
            const Vec3 &a = st[i][j], &b = st[i][j1], &c = st[i + 1][j1], &d = st[i + 1][j];
            Vec3 n = cross(c - a, d - b);
            const Vec3 centre = (a + b + c + d) * 0.25f;
            const Vec3 mid = (ctr[i] + ctr[i + 1]) * 0.5f;
            if (dot(n, centre - mid) < 0.0f) n = -n;
            nrm[i * N + j] += n;
            nrm[i * N + j1] += n;
            nrm[(i + 1) * N + j1] += n;
            nrm[(i + 1) * N + j] += n;
        }
    }
    std::vector<uint16_t> ids(S * N);
    for (size_t i = 0; i < S; ++i) {
        for (size_t j = 0; j < N; ++j) {
            const Vec3 ln = dot(nrm[i * N + j], nrm[i * N + j]) > 1e-14f ? normalize(nrm[i * N + j]) : Vec3(0.0f, 1.0f, 0.0f);
            Material vm = mat;
            const Rgba8 col = paint(st[i][j], ln, vm);
            ids[i * N + j] = m.addVertex(xf.transformPoint(st[i][j]), normalize(xf.transformDir(ln)), col, vm);
        }
    }
    for (size_t i = 0; i + 1 < S; ++i)
        for (size_t j = 0; j < N; ++j) {
            const size_t j1 = (j + 1) % N;
            m.addQuad(ids[i * N + j], ids[i * N + j1], ids[(i + 1) * N + j1], ids[(i + 1) * N + j]);
        }

    auto cap = [&](size_t i, const Vec3& axisDir) {
        const Vec3 ln = normalize(axisDir);
        const Vec3 wn = normalize(xf.transformDir(ln));
        Material cm = mat;
        const Rgba8 cc = paint(ctr[i], ln, cm);
        const uint16_t centre = m.addVertex(xf.transformPoint(ctr[i]), wn, cc, cm);
        std::vector<uint16_t> ring(N);
        for (size_t j = 0; j < N; ++j) {
            Material vm = mat;
            const Rgba8 col = paint(st[i][j], ln, vm);
            ring[j] = m.addVertex(xf.transformPoint(st[i][j]), wn, col, vm);
        }
        for (size_t j = 0; j < N; ++j) m.addTriangle(centre, ring[j], ring[(j + 1) % N]);
    };
    if (capStart) cap(0, ctr[0] - ctr[1]);
    if (capEnd) cap(S - 1, ctr[S - 1] - ctr[S - 2]);
}

void addTube(MeshData& m, const Vec3& a, const Vec3& b, float rA, float rB, int segments, Rgba8 cA, Rgba8 cB, Material mat, bool capA, bool capB,
             const Vec3& hint) {
    const Vec3 d = b - a;
    const float len = length(d);
    if (len < 1e-5f) return;
    const Basis ba = basisFromY(d, hint);
    m.addFrustum(Mat4::fromBasis(ba.x, ba.y, ba.z, a), rA, rB, len, segments, cA, cB, mat, 0.0f, capA, capB);
}

void addEllipsoid(MeshData& m, const Mat4& xf, const Vec3& radii, int subdiv, Rgba8 bottom, Rgba8 top, Material mat) {
    m.addBlob(xf, radii, 0u, subdiv, 0.0f, false, bottom, top, mat, 0.0f);
}

void addLathe(MeshData& m, const Mat4& xf, const std::vector<LathePoint>& p, int segments) {
    const size_t P = p.size();
    if (P < 2 || segments < 3) return;
    // outward normal of every profile segment, in the (radius, axis) half plane
    std::vector<float> segR(P - 1), segY(P - 1);
    for (size_t i = 0; i + 1 < P; ++i) {
        const float dr = p[i + 1].r - p[i].r, dy = p[i + 1].y - p[i].y;
        const float len = std::sqrt(dr * dr + dy * dy);
        segR[i] = len > 1e-7f ? dy / len : 0.0f;
        segY[i] = len > 1e-7f ? -dr / len : 1.0f;
    }
    struct ProfileVertex { float r, y, nr, ny; Rgba8 c; Material mat; };
    std::vector<ProfileVertex> pv;
    std::vector<size_t> before(P), after(P);   // the profile vertex that closes segment i-1 / opens segment i
    auto unit = [](float a, float b, float& oa, float& ob) {
        const float l = std::sqrt(a * a + b * b);
        oa = l > 1e-7f ? a / l : 0.0f;
        ob = l > 1e-7f ? b / l : 1.0f;
    };
    for (size_t i = 0; i < P; ++i) {
        const bool hasPrev = i > 0, hasNext = i + 1 < P;
        float pr = hasPrev ? segR[i - 1] : segR[i], py = hasPrev ? segY[i - 1] : segY[i];
        float nr = hasNext ? segR[i] : segR[i - 1], ny = hasNext ? segY[i] : segY[i - 1];
        if (p[i].crease && hasPrev && hasNext) {
            before[i] = pv.size();
            pv.push_back({p[i].r, p[i].y, pr, py, p[i].color, p[i].mat});
            after[i] = pv.size();
            pv.push_back({p[i].r, p[i].y, nr, ny, p[i].color, p[i].mat});
        } else {
            float ar, ay;
            unit(pr + nr, py + ny, ar, ay);
            before[i] = after[i] = pv.size();
            pv.push_back({p[i].r, p[i].y, ar, ay, p[i].color, p[i].mat});
        }
    }
    const size_t S = static_cast<size_t>(segments);
    std::vector<uint16_t> ids(pv.size() * S);
    for (size_t j = 0; j < pv.size(); ++j) {
        for (size_t k = 0; k < S; ++k) {
            const float a = kTwoPi * static_cast<float>(k) / static_cast<float>(segments);
            const float ca = std::cos(a), sa = std::sin(a);
            const Vec3 pos(ca * pv[j].r, pv[j].y, sa * pv[j].r);
            const Vec3 n(ca * pv[j].nr, pv[j].ny, sa * pv[j].nr);
            ids[j * S + k] = m.addVertex(xf.transformPoint(pos), normalize(xf.transformDir(n)), pv[j].c, pv[j].mat);
        }
    }
    for (size_t i = 0; i + 1 < P; ++i) {
        const size_t a = after[i], b = before[i + 1];
        for (size_t k = 0; k < S; ++k) {
            const size_t k1 = (k + 1) % S;
            m.addQuad(ids[a * S + k], ids[a * S + k1], ids[b * S + k1], ids[b * S + k]);
        }
    }
}

}  // namespace kit
}  // namespace sd
