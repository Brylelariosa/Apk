// ui_widgets.h - drawing helpers shared by the HUD and the controls editor, so every button looks the same.
#pragma once

#include "color.h"
#include "ui_batch.h"
#include "ui_font.h"
#include "ui_layout.h"

namespace sd {
namespace widgets {

inline const Rgba8 kWhite = {255, 255, 255, 255};
inline const Rgba8 kAccent = {255, 170, 70, 255};
inline const Rgba8 kGold = {255, 220, 110, 255};
inline const Rgba8 kPanel = {22, 14, 42, 170};
inline const Rgba8 kCyan = {110, 235, 255, 255};
inline const Rgba8 kRed = {255, 90, 70, 255};
inline const Rgba8 kInk = {40, 16, 60, 255};   // dark text on the orange accent

Rgba8 alpha(Rgba8 c, float a);   // scales the colour's own alpha

// Text with a soft dark halo that fades together with the text. (x, y) is the top of the text, size the cap height.
float text(UiBatch& ui, const char* s, float x, float y, float size, Rgba8 c, TextAlign a = TextAlign::Left);
// The largest size <= `size` at which `s` still fits into maxWidth.
float fitSize(const char* s, float size, float maxWidth);

void arrowHead(UiBatch& ui, float cx, float cy, float s, int dir, Rgba8 c);   // dir: -1 = left, +1 = right

// Round control buttons. `opacity` scales everything (the player's button transparency setting).
void roundButton(UiBatch& ui, Vec2 c, float r, bool down, const char* label, float labelSize, Rgba8 tint, float opacity = 1.0f);
void arrowButton(UiBatch& ui, Vec2 c, float r, int dir, bool down, Rgba8 tint, float opacity = 1.0f);

// One of the player's control buttons (TUCK, SLIDE, left / right arrow) at its place in the layout.
void controlButton(UiBatch& ui, const UiLayout& L, ButtonId b, bool down, float opacity);

// A rounded label button (MENU, CONTROLS, DONE ...).
void pill(UiBatch& ui, const Rect& r, const char* label, float labelSize, float opacity = 1.0f, bool accent = false);

// Horizontal steering gauge at the bottom centre: shows what the phone tilt is doing right now.
void tiltGauge(UiBatch& ui, const UiLayout& L, float steer, float opacity, bool withLabel);

}  // namespace widgets
}  // namespace sd
