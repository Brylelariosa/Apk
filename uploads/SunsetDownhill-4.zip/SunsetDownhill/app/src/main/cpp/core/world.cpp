#include "world.h"

#include <algorithm>
#include <cmath>

#include "traffic.h"

namespace sd {
namespace {

Instance makeInstance(const Vec3& p, float yaw, float sx, float sy, float phase, float pitch, Rgba8 tint) {
    Instance in;
    in.x = p.x; in.y = p.y; in.z = p.z;
    in.yaw = yaw;
    in.sx = sx; in.sy = sy;
    in.phase = phase;
    in.pitch = pitch;
    in.r = tint.r; in.g = tint.g; in.b = tint.b; in.a = tint.a;
    return in;
}

// NOTE: the alpha channel of an instance tint is "extra fog" (0 = none, 255 = completely fogged), not opacity.
const Rgba8 kCarColors[] = {
    {217, 26, 26, 0}, {26, 77, 204, 0}, {235, 235, 235, 0}, {242, 191, 26, 0},
    {26, 153, 77, 0}, {153, 158, 168, 0}, {41, 41, 46, 0}, {230, 110, 30, 0}};

// Brake lights and blinking indicators: small emissive boxes in the car's own frame (the same transform the mesh shader applies).
void addCarLights(MeshData& m, const Vec3& q, float yaw, float pitch, const Obstacle& o, float time) {
    const CarState& cs = o.car;
    const bool braking = cs.brake > 0.25f;
    const bool blink = cs.signal != 0 && std::fmod(time * 1.6f + 0.17f * static_cast<float>(cs.type), 1.0f) < 0.5f;
    if (!braking && !blink) return;
    const float cy = std::cos(yaw), sy = std::sin(yaw), ca = std::cos(-pitch), sa = std::sin(-pitch);
    const Mat4 frame = Mat4::fromBasis(Vec3(cy, 0.0f, sy), Vec3(-sy * sa, ca, cy * sa), Vec3(-sy * ca, -sa, cy * ca), q);
    const CarDims& d = carDims(cs.type);
    if (braking) {
        const Rgba8 red = rgba(1.0f, 0.10f, 0.06f);
        for (int side = -1; side <= 1; side += 2)
            m.addBox(frame * Mat4::translation(Vec3(static_cast<float>(side) * d.tailX, d.tailY, d.tailZ + 0.045f)), Vec3(d.lampW * 0.56f, d.lampH * 0.62f, 0.02f), red,
                     Material{0, 255, 0, 0});
    }
    if (blink) {
        const float side = cs.signal > 0 ? 1.0f : -1.0f;   // the car's own right is +X in model space
        const Rgba8 amber = rgba(1.0f, 0.62f, 0.08f);
        m.addBox(frame * Mat4::translation(Vec3(side * (d.noseX + 0.04f), d.noseY, d.noseZ - 0.03f)), Vec3(0.10f, 0.05f, 0.02f), amber, Material{0, 255, 0, 0});
        m.addBox(frame * Mat4::translation(Vec3(side * (d.tailX + d.lampW * 0.5f + 0.12f), d.tailY, d.tailZ + 0.045f)), Vec3(0.09f, 0.05f, 0.02f), amber,
                 Material{0, 255, 0, 0});
    }
}

}  // namespace

void World::reset(uint32_t seed) {
    track_.reset(seed);
    obstacleRng_.reseed(seed ^ 0x51ED270Bu);
    obstacles_.clear();
    chunks_.clear();
    nextObstacleS_ = 190.0f;
    nextId_ = 1;
    track_.ensureGenerated(cfg::kViewAhead + 200.0f);
}

void World::update(float dt, const PlayerRef& player) {
    const float playerS = player.s;
    track_.ensureGenerated(playerS + cfg::kViewAhead + 160.0f);
    spawnUpTo(playerS + 440.0f);
    stepTraffic(obstacles_, track_, dt, player);
    for (Obstacle& o : obstacles_) {
        if (o.hit) o.hitTime += dt;
    }
    obstacles_.erase(std::remove_if(obstacles_.begin(), obstacles_.end(),
                                    [playerS](const Obstacle& o) { return o.s < playerS - 70.0f || o.s > playerS + 900.0f || (o.hit && o.hitTime > 1.5f) || o.car.gone; }),
                     obstacles_.end());
    const int keepFrom = static_cast<int>(std::floor((playerS - 160.0f) / cfg::kChunkLength));
    for (auto it = chunks_.begin(); it != chunks_.end();) {
        if (it->first < keepFrom) it = chunks_.erase(it);
        else ++it;
    }
}

// A car may only appear where it overlaps nothing (cones, rocks and other cars) and leaves a safe gap.
bool World::spawnClear(const Obstacle& cand) const {
    for (const Obstacle& o : obstacles_) {
        if (o.hit) continue;
        if (std::fabs(o.s - cand.s) < o.hs + cand.hs + 14.0f && std::fabs(o.x - cand.x) < o.hx + cand.hx + 1.2f) return false;
    }
    return true;
}

void World::spawnUpTo(float sLimit) {
    while (nextObstacleS_ < sLimit) {
        const float s = nextObstacleS_;
        const float diff = track_.difficultyAt(s);
        nextObstacleS_ += lerpf(150.0f, 80.0f, diff) * obstacleRng_.range(0.75f, 1.35f);
        // Always consume the same random numbers so the course is identical whatever the settings.
        const float roll = obstacleRng_.uniform();
        const float a = obstacleRng_.uniform(), b = obstacleRng_.uniform(), c = obstacleRng_.uniform();
        const int colorIdx = obstacleRng_.rangeInt(0, 7);
        const float d1 = obstacleRng_.uniform(), d2 = obstacleRng_.uniform(), d3 = obstacleRng_.uniform();   // car style / lane habit / following gap
        if (!obstaclesEnabled_) continue;

        // Cones and rocks are a pure function of the seed (every player on a LAN race sees the same course); a car that happens
        // to stand where one appears is simply removed - it is still far beyond the horizon.
        auto evictCars = [this](const Obstacle& st) {
            obstacles_.erase(std::remove_if(obstacles_.begin(), obstacles_.end(),
                                            [&st](const Obstacle& car) {
                                                return car.kind == ObstacleKind::Car && std::fabs(car.s - st.s) < car.hs + st.hs + 6.0f &&
                                                       std::fabs(car.x - st.x) < car.hx + st.hx + 1.0f;
                                            }),
                             obstacles_.end());
        };

        const bool carsAllowed = s > 380.0f;
        if (roll < 0.36f || (!carsAllowed && roll > 0.6f)) {
            // diagonal taper of cones that pushes the rider toward the middle
            const float side = a < 0.5f ? -1.0f : 1.0f;
            const int n = 4 + static_cast<int>(b * 2.99f);
            for (int i = 0; i < n; ++i) {
                Obstacle o;
                o.kind = ObstacleKind::Cone;
                o.s = s + 2.6f * static_cast<float>(i);
                o.x = side * (3.0f - 0.55f * static_cast<float>(i));
                o.hs = 0.28f; o.hx = 0.28f;
                evictCars(o);
                o.id = nextId_++;
                obstacles_.push_back(o);
            }
        } else if (roll < 0.58f) {
            Obstacle o;
            o.kind = ObstacleKind::Rock;
            o.s = s;
            o.x = (a - 0.5f) * 5.0f;
            o.scale = 0.75f + b * 0.55f;
            o.hs = 0.78f * o.scale; o.hx = 0.78f * o.scale;
            o.yaw = c * kTwoPi;
            o.tint = rgba(0.75f + 0.25f * a, 0.72f + 0.2f * b, 0.7f, 0.0f);
            evictCars(o);
            o.id = nextId_++;
            obstacles_.push_back(o);
        } else {
            Obstacle o;
            o.kind = ObstacleKind::Car;
            o.s = s;
            CarState& cs = o.car;
            const int type = d1 < 0.30f ? kCarSedan : d1 < 0.55f ? kCarHatch : d1 < 0.75f ? kCarSuv : d1 < 0.90f ? kCarPickup : kCarVan;
            const CarDims& dims = carDims(type);
            cs.type = static_cast<uint8_t>(type);
            cs.baseHs = dims.halfLength;
            cs.baseHx = dims.halfWidth;
            o.hs = cs.baseHs;
            o.hx = cs.baseHx;
            o.tint = kCarColors[colorIdx];
            const bool oncoming = roll >= 0.8f;
            cs.dir = oncoming ? -1.0f : 1.0f;
            cs.laneX = cs.dir * cfg::kLaneCenter + (d2 - 0.5f) * 0.4f;   // some drivers hug the line, some the verge
            cs.targetX = cs.laneX;
            o.x = cs.laneX;
            cs.desiredSpeed = (oncoming ? 10.0f : 9.0f) + 4.0f * b;       // 32 - 50 km/h on this mountain road
            cs.speed = cs.desiredSpeed;
            cs.timeGap = 1.2f + 0.9f * d3;
            o.vel = cs.dir * cs.speed;
            o.yaw = oncoming ? kPi : 0.0f;
            if (spawnClear(o)) {
                o.id = nextId_++;
                obstacles_.push_back(o);
            }
        }
    }
}

// --------------------------------------------------------------------------------------
// Scenery
// --------------------------------------------------------------------------------------

const World::Chunk& World::chunkAt(int index) {
    auto it = chunks_.find(index);
    if (it != chunks_.end()) return it->second;
    Chunk& c = chunks_[index];
    generateChunk(index, c);
    return c;
}

void World::generateChunk(int index, Chunk& chunk) {
    const float L = cfg::kChunkLength;
    const float s0 = static_cast<float>(index) * L;
    track_.ensureGenerated(s0 + L + 12.0f);

    for (int side = 0; side < 2; ++side) {
        const float sd = side == 0 ? -1.0f : 1.0f;
        Rng r(hash2(track_.seed(), static_cast<uint32_t>(index * 2 + side + 1000)));

        // ---- trees
        for (int k = 0; k < 22; ++k) {
            const float da = 9.0f + std::pow(r.uniform(), 1.5f) * 46.0f;
            const float s = s0 + r.uniform() * L;
            const float rank = r.uniform();
            const float typeRoll = r.uniform();
            const float hRand = r.uniform(), wRand = r.uniform(), yawRand = r.uniform(), shade = r.uniform();
            const float hueA = r.uniform(), hueB = r.uniform();
            if (s < 24.0f && da < 16.0f) continue;  // keep the start area open
            if (track_.shortcutBlocks(s, sd * da, 6.0f)) continue;   // keep clear of the kicker, the flight path and the shortcut deck
            const TrackSample f = track_.at(s);
            if (sd * f.curvature > 0.0f && da > Track::insideLimit(f.curvature) * 0.92f) continue;
            const Vec3 p = track_.terrainPoint(s, sd * da);
            const float edge = smoothstep(0.55f, 1.0f, da / cfg::kTerrainMaxOffset);
            Rgba8 tint;
            Batch batch;
            float sy;
            if (typeRoll < 0.74f) {
                batch = kBatchPine;
                sy = 0.8f + 0.75f * hRand;
                const float b = 0.62f + 0.38f * shade;
                tint = rgba(b * (0.85f + 0.15f * hueA), b, b * (0.75f + 0.25f * hueB), edge);
            } else {
                batch = kBatchAutumn;
                sy = 0.70f + 0.45f * hRand;
                tint = rgba(0.85f + 0.15f * hueA, 0.55f + 0.45f * hueB * hueB, 0.35f + 0.5f * shade * hueA, edge);
            }
            const float sx = sy * (0.82f + 0.36f * wRand);
            chunk.items[batch].push_back({makeInstance(p - Vec3(0.0f, 0.12f, 0.0f), yawRand * kTwoPi, sx, sy, hueA * 6.28f, 0.0f, tint), rank});
        }

        // ---- boulders near the road
        const int nRocks = r.rangeInt(0, 2);
        for (int k = 0; k < nRocks; ++k) {
            const float da = 5.9f + r.uniform() * 9.0f;
            const float s = s0 + r.uniform() * L;
            const float sc = 0.6f + r.uniform() * 1.7f;
            const float yaw = r.uniform() * kTwoPi;
            const float lum = r.uniform();
            if (s < 24.0f) continue;
            if (track_.shortcutBlocks(s, sd * da, 6.0f)) continue;
            const TrackSample f = track_.at(s);
            if (sd * f.curvature > 0.0f && da > Track::insideLimit(f.curvature) * 0.92f) continue;
            const Vec3 p = track_.terrainPoint(s, sd * da);
            chunk.items[kBatchRock].push_back({makeInstance(p - Vec3(0.0f, 0.18f * sc, 0.0f), yaw, sc, sc * 0.9f, 0.0f, 0.0f,
                                                            rgba(0.7f + 0.3f * lum, 0.68f + 0.25f * lum, 0.66f + 0.2f * lum, 0.0f)), 0.0f});
        }

        // ---- guard rails (where the ground drops away) and delineator posts
        const int r0 = static_cast<int>(std::ceil(s0 / 4.0f)), r1 = static_cast<int>(std::ceil((s0 + L) / 4.0f));
        for (int k = r0; k < r1; ++k) {
            const float sc = 4.0f * static_cast<float>(k) + 2.0f;
            if (sc < 6.0f) continue;
            if (track_.hillBias(sc) * sd >= 0.10f) continue;
            if (track_.railGap(sc, sd)) continue;   // the kicker and the merge: no rail
            const TrackSample f = track_.at(sc);
            const Vec3 p = track_.terrainPoint(sc, sd * 5.5f);
            const float yaw = f.heading + (sd < 0.0f ? kPi : 0.0f);
            const float pitch = sd < 0.0f ? -f.pitch : f.pitch;
            chunk.items[kBatchRail].push_back({makeInstance(p, yaw, 1.0f, 1.0f, 0.0f, pitch, Rgba8{255, 255, 255, 0}), 0.0f});
        }
        const int p0 = static_cast<int>(std::ceil(s0 / 12.0f)), p1 = static_cast<int>(std::ceil((s0 + L) / 12.0f));
        for (int k = p0; k < p1; ++k) {
            const float sp = 12.0f * static_cast<float>(k);
            if (sp < 6.0f || track_.hillBias(sp) * sd < 0.10f) continue;  // rails already cover it
            if (track_.railGap(sp, sd)) continue;
            const Vec3 p = track_.terrainPoint(sp, sd * 5.3f);
            chunk.items[kBatchPost].push_back({makeInstance(p, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, Rgba8{255, 255, 255, 0}), 0.0f});
        }
    }
}

void World::buildScenery(float focusS, const Vec3& origin, const Vec3& camFwd, float density, SceneGeometry& out) {
    const float L = cfg::kChunkLength;
    const int c0 = std::max(0, static_cast<int>(std::floor((focusS - 50.0f) / L)));
    const int c1 = static_cast<int>(std::floor((focusS + cfg::kViewAhead - 24.0f) / L));
    for (int c = c0; c <= c1; ++c) {
        const Chunk& ch = chunkAt(c);
        for (int b = 0; b < kBatchCount; ++b) {
            for (const Placed& p : ch.items[b]) {
                if (p.rank > density) continue;
                Instance in = p.inst;
                in.x -= origin.x; in.y -= origin.y; in.z -= origin.z;
                if (in.x * camFwd.x + in.y * camFwd.y + in.z * camFwd.z < -16.0f) continue;
                out.instances[b].push_back(in);
            }
        }
    }
}

void World::buildObstacles(const Vec3& origin, SceneGeometry& out, float time) const {
    for (const Obstacle& o : obstacles_) {
        const TrackSample f = track_.at(o.s);
        Vec3 p = Track::surfacePoint(f, o.x);
        float yaw = f.heading + o.yaw;
        float pitch = 0.0f;
        float spin = 0.0f;
        switch (o.kind) {
            case ObstacleKind::Cone: {
                if (o.hit) {
                    const float t = o.hitTime;
                    const float dy = std::max(0.0f, 3.6f * t - 4.9f * t * t);
                    p += f.right0 * (o.knockDir * 3.2f * t) + f.fwd * (4.0f * t) + Vec3(0.0f, dy, 0.0f);
                    spin = t * 9.0f;
                }
                const Vec3 q = p - origin;
                Instance in = makeInstance(q, yaw + spin, 1.0f, 1.0f, 0.0f, spin * 0.5f, Rgba8{255, 255, 255, 0});
                out.instances[kBatchCone].push_back(in);
                break;
            }
            case ObstacleKind::Rock: {
                const Vec3 q = p - origin - Vec3(0.0f, 0.15f * o.scale, 0.0f);
                out.instances[kBatchRock].push_back(makeInstance(q, yaw, o.scale, o.scale * 0.9f, 0.0f, 0.0f, withAlpha(o.tint, 0.0f)));
                break;
            }
            case ObstacleKind::Car: {
                const CarState& cs = o.car;
                pitch = (cs.dir < 0.0f ? -f.pitch : f.pitch) + cs.dive;
                const Vec3 q = p - origin;
                out.instances[kBatchCar + cs.type].push_back(makeInstance(q, yaw, 1.0f, 1.0f, 0.0f, pitch, withAlpha(o.tint, 0.0f)));
                addCarLights(out.dynamicMesh, q, yaw, pitch, o, time);
                break;
            }
        }
    }
}

void World::buildShortcuts(float focusS, const Vec3& origin, SceneGeometry& out) const {
    const float sLo = focusS - 45.0f, sHi = focusS + 330.0f;
    MeshData& m = out.dynamicMesh;
    const Rgba8 asphalt = rgba(0.17f, 0.165f, 0.175f), concrete = rgba(0.60f, 0.60f, 0.62f), concreteDark = rgba(0.38f, 0.38f, 0.40f);
    const Rgba8 yellow = rgba(1.0f, 0.78f, 0.08f), black = rgba(0.05f, 0.05f, 0.06f), lineWhite = rgba(0.92f, 0.92f, 0.9f);
    const Rgba8 woodA = rgba(0.62f, 0.44f, 0.24f), woodB = rgba(0.52f, 0.36f, 0.19f);
    for (const ShortcutZone& z : track_.shortcuts()) {
        if (z.sDeck1 < sLo || z.sRamp0 > sHi) continue;
        const float side = z.side;
        auto at = [&](float s, float x, float h) { return Track::surfacePoint(track_.at(s), x, h) - origin; };
        auto boxFrame = [&](const Vec3& a, const Vec3& b, const Vec3& up, Vec3& centre, float& len) {
            centre = (a + b) * 0.5f;
            const Vec3 d = b - a;
            len = length(d);
            const Vec3 fw = len > 1e-4f ? d / len : Vec3(0.0f, 0.0f, 1.0f);
            const Vec3 r = normalize(cross(up, fw));
            return Mat4::fromBasis(r, cross(fw, r), fw, centre);
        };

        // ---- the kicker: a wooden wedge whose sides taper into the road, with a hazard-striped lip
        if (z.sLip > sLo && z.sRamp0 < sHi) {
            const int nz = 7, nx = 4;
            std::vector<uint16_t> ids;
            for (int i = 0; i <= nz; ++i) {
                const float s = lerpf(z.sRamp0, z.sLip, static_cast<float>(i) / static_cast<float>(nz));
                const TrackSample f = track_.at(s);
                for (int j = 0; j <= nx; ++j) {
                    const float xs = lerpf(z.rampX0, z.rampX1, static_cast<float>(j) / static_cast<float>(nx));
                    const float e = 0.15f;
                    const float h0 = std::max(0.0f, z.rampHeight(s, xs));
                    const float hs = (std::max(0.0f, z.rampHeight(std::min(s + e, z.sLip), xs)) - std::max(0.0f, z.rampHeight(std::max(s - e, z.sRamp0), xs))) / (2.0f * e);
                    const float hx = (std::max(0.0f, z.rampHeight(s, std::min(xs + e, z.rampX1))) - std::max(0.0f, z.rampHeight(s, std::max(xs - e, z.rampX0)))) / (2.0f * e) * side;
                    const Vec3 n = normalize(f.up0 - f.fwd * hs - f.right0 * hx);
                    const Rgba8 c = i == nz ? (j & 1 ? black : yellow) : ((i & 1) ? woodA : woodB);
                    ids.push_back(m.addVertex(Track::surfacePoint(f, side * xs, h0 + 0.02f) - origin, n, c, i == nz ? Material{0, 50, 0, 0} : Material{}));
                }
            }
            const size_t row = static_cast<size_t>(nx) + 1;
            for (int i = 0; i < nz; ++i)
                for (int j = 0; j < nx; ++j) {
                    const size_t k = static_cast<size_t>(i) * row + static_cast<size_t>(j);
                    m.addQuad(ids[k], ids[k + 1], ids[k + row + 1], ids[k + row]);
                }
            // the lip's vertical face
            const TrackSample fl = track_.at(z.sLip);
            std::vector<uint16_t> face;
            for (int j = 0; j <= nx; ++j) {
                const float xs = lerpf(z.rampX0, z.rampX1, static_cast<float>(j) / static_cast<float>(nx));
                const float h0 = std::max(0.0f, z.rampHeight(z.sLip, xs));
                face.push_back(m.addVertex(Track::surfacePoint(fl, side * xs, h0 + 0.02f) - origin, fl.fwd, concreteDark, Material{}));
                face.push_back(m.addVertex(Track::surfacePoint(fl, side * xs, 0.0f) - origin, fl.fwd, concreteDark, Material{}));
            }
            for (int j = 0; j < nx; ++j) m.addQuad(face[static_cast<size_t>(2 * j)], face[static_cast<size_t>(2 * j) + 1], face[static_cast<size_t>(2 * j) + 3], face[static_cast<size_t>(2 * j) + 2]);
        }

        // ---- the warning sign before the kicker: a yellow diamond with a dark chevron
        {
            const float ss = z.sRamp0 - 38.0f;
            if (ss > sLo && ss < sHi) {
                const TrackSample f = track_.at(ss);
                const Vec3 bz = cross(f.right0, f.up0);
                const Vec3 base = Track::surfacePoint(f, side * 6.6f, 0.0f) - origin;
                m.addBox(Mat4::fromBasis(f.right0, f.up0, bz, base + f.up0 * 1.2f), Vec3(0.06f, 1.2f, 0.06f), rgba(0.75f, 0.75f, 0.78f), rgba(0.75f, 0.75f, 0.78f));
                const Vec3 rr = normalize(f.right0 + f.up0), uu = normalize(f.up0 - f.right0);
                m.addBox(Mat4::fromBasis(rr, uu, bz, base + f.up0 * 2.7f), Vec3(0.62f, 0.62f, 0.04f), yellow, yellow, Material{0, 60, 0, 0});
                m.addBox(Mat4::fromBasis(rr, uu, bz, base + f.up0 * 2.7f - bz * 0.05f), Vec3(0.40f, 0.12f, 0.03f), black, black);
                m.addBox(Mat4::fromBasis(rr, uu, bz, base + f.up0 * 2.7f - bz * 0.05f), Vec3(0.12f, 0.40f, 0.03f), black, black);
            }
        }

        // ---- the shortcut deck on stilts
        const int n = static_cast<int>(z.c.size());
        const int k0 = std::max(0, static_cast<int>(std::floor((sLo - z.sDeck0) / cfg::kTrackStep)));
        const int k1 = std::min(n - 1, static_cast<int>(std::ceil((sHi - z.sDeck0) / cfg::kTrackStep)));
        if (k1 - k0 < 1) continue;
        std::vector<uint16_t> topIn, topOut, skIn0, skIn1, skOut0, skOut1;
        for (int k = k0; k <= k1; ++k) {
            const float s = z.sDeck0 + cfg::kTrackStep * static_cast<float>(k);
            const TrackSample f = track_.at(s);
            const float c = z.c[static_cast<size_t>(k)], hw = z.hw[static_cast<size_t>(k)], h = z.h[static_cast<size_t>(k)] - 0.03f;   // a hair below the road, so where they overlap the asphalt wins
            const Vec3 pIn = Track::surfacePoint(f, side * (c - hw), h) - origin, pOut = Track::surfacePoint(f, side * (c + hw), h) - origin;
            const bool hazard = k < 6;
            const Rgba8 col = hazard ? ((k & 1) ? yellow : black) : asphalt;
            topIn.push_back(m.addVertex(pIn, f.up0, col, hazard ? Material{0, 40, 0, 0} : Material{}));
            topOut.push_back(m.addVertex(pOut, f.up0, col, hazard ? Material{0, 40, 0, 0} : Material{}));
            const Vec3 toRoad = f.right0 * (-side), awayRoad = f.right0 * side;
            const Vec3 down = f.up0 * 0.55f;
            skIn0.push_back(m.addVertex(pIn, toRoad, concrete, Material{}));
            skIn1.push_back(m.addVertex(pIn - down, toRoad, concreteDark, Material{}));
            skOut0.push_back(m.addVertex(pOut, awayRoad, concrete, Material{}));
            skOut1.push_back(m.addVertex(pOut - down, awayRoad, concreteDark, Material{}));
        }
        for (size_t k = 0; k + 1 < topIn.size(); ++k) {
            m.addQuad(topIn[k], topOut[k], topOut[k + 1], topIn[k + 1]);
            m.addQuad(skIn0[k], skIn1[k], skIn1[k + 1], skIn0[k + 1]);
            m.addQuad(skOut0[k], skOut1[k], skOut1[k + 1], skOut0[k + 1]);
        }
        // the front edge of the landing platform faces the kicker
        if (k0 == 0) {
            const TrackSample f = track_.at(z.sDeck0);
            const float c = z.c[0], hw = z.hw[0], h = z.h[0] - 0.03f;
            const Vec3 a = Track::surfacePoint(f, side * (c - hw), h) - origin, b = Track::surfacePoint(f, side * (c + hw), h) - origin;
            const Vec3 down = f.up0 * 0.55f;
            const uint16_t v0 = m.addVertex(a, -f.fwd, concrete, Material{}), v1 = m.addVertex(b, -f.fwd, concrete, Material{});
            const uint16_t v2 = m.addVertex(b - down, -f.fwd, concreteDark, Material{}), v3 = m.addVertex(a - down, -f.fwd, concreteDark, Material{});
            m.addQuad(v0, v1, v2, v3);
        }
        for (int k = k0; k < k1; k += 2) {   // concrete barriers along the edges (the inside edge opens up where the deck merges)
            const float s = z.sDeck0 + cfg::kTrackStep * static_cast<float>(k);
            const int kk = std::min(k + 2, n - 1);
            const float s2 = z.sDeck0 + cfg::kTrackStep * static_cast<float>(kk);
            const TrackSample f = track_.at(s);
            for (int e = 0; e < 2; ++e) {
                if (e == 0 && s > z.sDeck1 - 44.0f) continue;
                const float sg = e == 0 ? -1.0f : 1.0f;   // 0 = inside edge, 1 = outside edge
                const float c1 = z.c[static_cast<size_t>(k)] + sg * z.hw[static_cast<size_t>(k)], c2 = z.c[static_cast<size_t>(kk)] + sg * z.hw[static_cast<size_t>(kk)];
                const float inset = e == 0 ? 0.14f : -0.14f;
                const Vec3 a = Track::surfacePoint(f, side * (c1 + inset), z.h[static_cast<size_t>(k)] - 0.03f + 0.38f) - origin;
                const Vec3 b = Track::surfacePoint(track_.at(s2), side * (c2 + inset), z.h[static_cast<size_t>(kk)] - 0.03f + 0.38f) - origin;
                Vec3 centre;
                float len;
                const Mat4 fr = boxFrame(a, b, f.up0, centre, len);
                m.addBox(fr, Vec3(0.13f, 0.38f, 0.5f * len + 0.02f), (k / 2) & 1 ? concrete : rgba(0.85f, 0.35f, 0.25f), (k / 2) & 1 ? concrete : rgba(0.85f, 0.35f, 0.25f));
            }
        }
        for (int k = std::max(k0, 0); k <= k1; ++k) {   // stilts and the centre dashes
            const float s = z.sDeck0 + cfg::kTrackStep * static_cast<float>(k);
            const float c = z.c[static_cast<size_t>(k)], hw = z.hw[static_cast<size_t>(k)], h = z.h[static_cast<size_t>(k)];
            if (k % 4 == 0 && s < z.sDeck1 - 6.0f) {
                for (int e = -1; e <= 1; e += 2) {
                    const float xl = side * (c + 0.5f * hw * static_cast<float>(e));
                    const Vec3 top = at(s, xl, h - 0.55f);
                    const Vec3 foot = track_.terrainPoint(s, xl) - origin;
                    const float hy = 0.5f * (top.y - foot.y);
                    if (hy < 0.15f) continue;
                    m.addBox(Mat4::translation(Vec3(top.x, foot.y + hy, top.z)), Vec3(0.45f, hy, 0.45f), concreteDark, concrete);
                }
            }
            if (k % 4 == 1 && s > z.sDeck0 + 24.0f && s < z.sDeck1 - 50.0f && hw > 3.0f) {
                const TrackSample f = track_.at(s);
                const Vec3 bz = cross(f.right0, f.up0);
                m.addBox(Mat4::fromBasis(f.right0, f.up0, bz, Track::surfacePoint(f, side * c, h - 0.03f + 0.03f) - origin), Vec3(0.07f, 0.02f, 1.5f), lineWhite, lineWhite);
            }
        }
    }
}

void World::buildStartGate(float focusS, const Vec3& origin, SceneGeometry& out) const {
    if (focusS > 150.0f) return;
    const TrackSample f = track_.at(14.0f);
    const Vec3 bz = cross(f.right0, f.up0);
    auto frame = [&](const Vec3& worldPos) { return Mat4::fromBasis(f.right0, f.up0, bz, worldPos - origin); };
    const Rgba8 steel = rgba(0.78f, 0.78f, 0.8f);
    const Rgba8 orange = rgba(1.0f, 0.42f, 0.10f);
    for (int sgn = -1; sgn <= 1; sgn += 2) {
        const Vec3 base = Track::surfacePoint(f, 4.7f * static_cast<float>(sgn));
        MeshData& m = out.dynamicMesh;
        m.addBox(frame(base + f.up0 * 2.7f), Vec3(0.17f, 2.7f, 0.17f), steel, Material{});
        m.addBox(frame(base + f.up0 * 0.2f), Vec3(0.34f, 0.2f, 0.34f), rgba(0.3f, 0.3f, 0.32f), Material{});
    }
    const Vec3 mid = Track::surfacePoint(f, 0.0f, 5.2f);
    out.dynamicMesh.addBox(frame(mid), Vec3(4.85f, 0.5f, 0.14f), orange, Material{0, 70, 0, 0});
    const int n = 22;
    for (int i = 0; i < n; ++i) {
        const float lx = -4.4f + 8.8f * (static_cast<float>(i) + 0.5f) / static_cast<float>(n);
        for (int row = 0; row < 2; ++row) {
            const bool white = ((i + row) & 1) == 0;
            const Vec3 pos = mid + f.right0 * lx + f.up0 * (0.18f - 0.2f * static_cast<float>(row));
            out.dynamicMesh.addBox(frame(pos), Vec3(0.2f, 0.1f, 0.16f), white ? rgba(0.95f, 0.95f, 0.95f) : rgba(0.06f, 0.06f, 0.07f), Material{});
        }
    }
}

// --------------------------------------------------------------------------------------
// Terrain mesh
// --------------------------------------------------------------------------------------

void World::buildTerrain(float focusS, const Vec3& origin, SceneGeometry& out) const {
    constexpr int cols = cfg::kTerrainCols;
    constexpr int rings = cfg::kTerrainRings;
    int i0 = static_cast<int>(std::floor((focusS - cfg::kViewBehind) / cfg::kTrackStep));
    i0 = std::max(i0, 1);
    const int maxStart = track_.sampleCount() - rings - 2;
    if (maxStart < 1) {
        out.terrain.clear();
        return;
    }
    i0 = std::min(i0, maxStart);

    scratch_.resize(static_cast<size_t>(rings + 2) * cols);
    for (int r = 0; r < rings + 2; ++r) {
        for (int j = 0; j < cols; ++j) scratch_[static_cast<size_t>(r) * cols + static_cast<size_t>(j)] = track_.ringVertex(i0 - 1 + r, j);
    }
    out.terrain.resize(static_cast<size_t>(rings) * cols);
    for (int r = 0; r < rings; ++r) {
        const TrackSample& f = track_.sampleAt(i0 + r);
        for (int j = 0; j < cols; ++j) {
            const size_t center = static_cast<size_t>(r + 1) * cols + static_cast<size_t>(j);
            const Vec3 ds = scratch_[center + cols] - scratch_[center - cols];
            const Vec3 dd = scratch_[static_cast<size_t>(r + 1) * cols + static_cast<size_t>(std::min(j + 1, cols - 1))] -
                            scratch_[static_cast<size_t>(r + 1) * cols + static_cast<size_t>(std::max(j - 1, 0))];
            Vec3 n = normalize(cross(dd, ds));
            if (n.y < 0.0f) n = -n;
            const Vec3 p = scratch_[center] - origin;
            TerrainVertex& v = out.terrain[static_cast<size_t>(r) * cols + static_cast<size_t>(j)];
            v.px = p.x; v.py = p.y; v.pz = p.z;
            v.nx = n.x; v.ny = n.y; v.nz = n.z;
            v.d = cfg::kTerrainOffsets[j];
            v.s = f.s;
            v.edge = std::fabs(cfg::kTerrainOffsets[j]) / cfg::kTerrainMaxOffset;
        }
    }
}

}  // namespace sd
