// ui_atlas.h - layout constants of the UI texture atlas, shared by the batch builder, the font, the renderer and the desktop tools.
//
// The atlas is a single 8-bit texture that holds (a) a signed-distance field for every glyph of the stroke font and (b) a small
// solid block that plain shapes (rects, circles, rings ...) sample, so the whole HUD is one vertex format and one draw call.
#pragma once

namespace sd {

constexpr int kAtlasSize = 512;                     // square, one byte per texel (R8)
constexpr int kAtlasSolidMin = 496;                 // the bottom-right 16 x 16 texels are solid (255)
constexpr float kAtlasSolidUV = 504.0f / 512.0f;    // centre of that block

}  // namespace sd
