#include "net.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <random>

#include <arpa/inet.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include "log.h"

namespace sd {
namespace {

constexpr uint32_t kMagic = 0x32484453u;   // the bytes "SDH2": protocol identifier + version (v2: timestamps, clock sync, finish line)
enum PacketType : uint8_t { kBeacon = 1, kJoin, kWelcome, kReject, kRoster, kStart, kState, kLeave, kKeepAlive, kPong };
constexpr size_t kHeaderSize = 8;          // magic u32, type u8, sender slot u8, sequence u16
constexpr size_t kMaxPacket = 512;
constexpr float kBeaconPeriod = 1.0f;
constexpr float kRosterPeriod = 0.5f;
constexpr float kStatePeriod = 1.0f / 30.0f;
constexpr float kKeepAlivePeriod = 1.0f;
constexpr double kPeerTimeout = 6.0;       // a silent player is dropped
constexpr double kHostTimeout = 6.0;
constexpr double kHostListTimeout = 4.0;   // a host that stopped beaconing disappears from the list
constexpr float kMaxExtrapolation = 0.20f; // past the newest update a rider keeps going at its last speed for at most this long
constexpr float kAssumedLatency = 0.03f;   // used for the start countdown if no clock sync sample has arrived yet
constexpr uint8_t kRejectFull = 1, kRejectRacing = 2;

struct Writer {
    uint8_t* buf;
    size_t cap, n = 0;
    Writer(uint8_t* b, size_t c) : buf(b), cap(c) {}
    void u8(uint8_t v) {
        if (n < cap) buf[n++] = v;
    }
    void u16(uint16_t v) { u8(static_cast<uint8_t>(v & 0xFF)); u8(static_cast<uint8_t>(v >> 8)); }
    void u32(uint32_t v) { u16(static_cast<uint16_t>(v & 0xFFFF)); u16(static_cast<uint16_t>(v >> 16)); }
    void f32(float f) {
        uint32_t b;
        std::memcpy(&b, &f, 4);
        u32(b);
    }
    void f64(double d) {
        uint64_t b;
        std::memcpy(&b, &d, 8);
        u32(static_cast<uint32_t>(b & 0xFFFFFFFFu));
        u32(static_cast<uint32_t>(b >> 32));
    }
    void name(const char* s) {
        bool end = false;
        for (int i = 0; i < kNetNameLen; ++i) {
            if (!end && s[i] == '\0') end = true;
            u8(end ? 0 : static_cast<uint8_t>(s[i]));
        }
    }
};

struct Reader {
    const uint8_t* p;
    size_t n, i = 0;
    bool ok = true;
    Reader(const uint8_t* d, size_t len) : p(d), n(len) {}
    uint8_t u8() {
        if (i >= n) { ok = false; return 0; }
        return p[i++];
    }
    uint16_t u16() { const uint16_t a = u8(); const uint16_t b = u8(); return static_cast<uint16_t>(a | (b << 8)); }
    uint32_t u32() { const uint32_t a = u16(); const uint32_t b = u16(); return a | (b << 16); }
    float f32() {
        const uint32_t b = u32();
        float f;
        std::memcpy(&f, &b, 4);
        return f;
    }
    double f64() {
        const uint64_t lo = u32();
        const uint64_t hi = u32();
        const uint64_t b = lo | (hi << 32);
        double d;
        std::memcpy(&d, &b, 8);
        return d;
    }
    size_t left() const { return n > i ? n - i : 0; }
    // Reads a fixed-size name field; whatever arrives is reduced to the characters the HUD font can draw.
    void name(char* out) {
        bool end = false;
        int len = 0;
        for (int k = 0; k < kNetNameLen; ++k) {
            const uint8_t c = u8();
            if (end || c == 0) { end = true; continue; }
            char ch = static_cast<char>(c);
            if (ch >= 'a' && ch <= 'z') ch = static_cast<char>(ch - 'a' + 'A');
            const bool okc = (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == ' ' || ch == '.' || ch == '-' || ch == '_';
            out[len++] = okc ? ch : '?';
        }
        out[len] = '\0';
    }
};

float clean(float v, float lo, float hi) { return std::isfinite(v) ? std::min(hi, std::max(lo, v)) : 0.0f; }

std::string sanitizeName(const std::string& in) {
    std::string out;
    for (char c : in) {
        if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
        const bool okc = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ' || c == '.' || c == '-' || c == '_';
        if (!okc) continue;
        if (c == ' ' && (out.empty() || out.back() == ' ')) continue;
        out.push_back(c);
        if (static_cast<int>(out.size()) >= kNetNameLen) break;
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out.empty() ? "RIDER" : out;
}

struct IfaceInfo {
    uint32_t ip, broadcast;
};

// The device's usable IPv4 networks (Wi-Fi, hotspot, ethernet); cellular and loopback are skipped.
std::vector<IfaceInfo> interfaces() {
    std::vector<IfaceInfo> out;
    ifaddrs* list = nullptr;
    if (getifaddrs(&list) != 0) return out;
    for (const ifaddrs* it = list; it; it = it->ifa_next) {
        if (!it->ifa_addr || it->ifa_addr->sa_family != AF_INET) continue;
        if (!(it->ifa_flags & IFF_UP) || (it->ifa_flags & (IFF_LOOPBACK | IFF_POINTOPOINT)) || !(it->ifa_flags & IFF_BROADCAST)) continue;
        const uint32_t ip = ntohl(reinterpret_cast<const sockaddr_in*>(it->ifa_addr)->sin_addr.s_addr);
        uint32_t mask = 0xFFFFFF00u;
        if (it->ifa_netmask) mask = ntohl(reinterpret_cast<const sockaddr_in*>(it->ifa_netmask)->sin_addr.s_addr);
        out.push_back({ip, (ip & mask) | ~mask});
    }
    freeifaddrs(list);
    return out;
}

size_t writeHeader(uint8_t* buf, uint8_t type, int slot, uint16_t seq) {
    Writer w(buf, kMaxPacket);
    w.u32(kMagic);
    w.u8(type);
    w.u8(static_cast<uint8_t>(slot < 0 ? 255 : slot));
    w.u16(seq);
    return w.n;
}

float lerpf2(float a, float b, float t) { return a + (b - a) * t; }

}  // namespace

// ---- lifecycle ------------------------------------------------------------------------------------------------------------
LanSession::LanSession(const NetConfig& config) : cfg_(config) {
    try {
        std::random_device rd;
        rngState_ = rd() ^ 0x9E3779B9u;
    } catch (...) {
        rngState_ = static_cast<uint32_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    }
    if (rngState_ == 0) rngState_ = 0x1234567u;
}

LanSession::~LanSession() { leave(); }

uint32_t LanSession::random32() {
    rngState_ ^= rngState_ << 13;
    rngState_ ^= rngState_ >> 17;
    rngState_ ^= rngState_ << 5;
    return rngState_;
}

bool LanSession::open() {
    if (sock_ >= 0) return true;
    const int s = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        error_ = "NO NETWORK";
        return false;
    }
    int one = 1;
    ::setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    ::setsockopt(s, SOL_SOCKET, SO_BROADCAST, &one, sizeof(one));
    const int flags = ::fcntl(s, F_GETFL, 0);
    ::fcntl(s, F_SETFL, flags | O_NONBLOCK);
    sockaddr_in a;
    std::memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(cfg_.port);
    if (::bind(s, reinterpret_cast<sockaddr*>(&a), sizeof(a)) != 0) {
        ::close(s);
        error_ = "PORT IN USE";
        return false;
    }
    sock_ = s;
    return true;
}

void LanSession::closeSocket() {
    if (sock_ >= 0) ::close(sock_);
    sock_ = -1;
}

void LanSession::reset(NetRole role) {
    role_ = role;
    for (int i = 0; i < kNetMaxPlayers; ++i) {
        players_[i] = NetPlayer();
        peers_[i] = Peer();
        remote_[i] = Remote();
    }
    hosts_.clear();
    selfSlot_ = -1;
    lobbyId_ = 0;
    roomRacing_ = false;
    rosterDirty_ = false;
    startRepeats_ = 0;
    joining_ = false;
    pendingStart_ = false;
    lastStartRace_ = 0;
    raceId_ = 0;
    raceT0_ = 0.0;
    goal_ = 0.0f;
    pendingLag_ = 0.0f;
    pingCount_ = pingHead_ = pingBurst_ = 0;
    pingTimer_ = 0.0f;
    hostOffset_ = 0.0;
    offsetValid_ = false;
    beaconTimer_ = rosterTimer_ = startTimer_ = keepAliveTimer_ = stateTimer_ = 0.0f;
}

void LanSession::fail(const char* why) {
    leave();
    error_ = why;
}

bool LanSession::host(const std::string& playerName) {
    leave();
    error_.clear();
    if (!open()) return false;
    reset(NetRole::Host);
    name_ = sanitizeName(playerName);
    selfSlot_ = 0;
    NetPlayer& me = players_[0];
    me.present = true;
    me.self = true;
    std::strncpy(me.name, name_.c_str(), kNetNameLen);
    me.phase = PeerPhase::Lobby;
    lobbyId_ = random32() | 1u;
    rosterDirty_ = true;
    return true;
}

bool LanSession::search(const std::string& playerName) {
    leave();
    error_.clear();
    if (!open()) return false;
    reset(NetRole::Searching);
    name_ = sanitizeName(playerName);
    return true;
}

bool LanSession::join(int hostIndex) {
    if (role_ != NetRole::Searching || hostIndex < 0 || hostIndex >= static_cast<int>(hosts_.size())) return false;
    const FoundHost& h = hosts_[static_cast<size_t>(hostIndex)];
    error_.clear();
    hostIp_ = h.ip;
    hostPort_ = h.port;
    joinNonce_ = random32() | 1u;
    joining_ = true;
    joinAge_ = 0.0f;
    joinTimer_ = 0.0f;
    return true;
}

void LanSession::leave() {
    if (sock_ >= 0) {
        uint8_t buf[kMaxPacket];
        const size_t n = writeHeader(buf, kLeave, selfSlot_, 0);
        if (role_ == NetRole::Host) sendToPeers(buf, n, -1);
        else if (role_ == NetRole::Joined) sendTo(hostIp_, hostPort_, buf, n);
    }
    closeSocket();
    reset(NetRole::Off);
}

int LanSession::playerCount() const {
    int n = 0;
    for (const NetPlayer& p : players_) n += p.present ? 1 : 0;
    return n;
}

std::vector<std::string> LanSession::localAddresses() const {
    std::vector<std::string> out;
    for (const IfaceInfo& i : interfaces()) {
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%u.%u.%u.%u", (i.ip >> 24) & 255u, (i.ip >> 16) & 255u, (i.ip >> 8) & 255u, i.ip & 255u);
        out.push_back(buf);
    }
    return out;
}

// ---- sending --------------------------------------------------------------------------------------------------------------
void LanSession::sendTo(uint32_t ip, uint16_t port, const uint8_t* data, size_t len) {
    if (sock_ < 0) return;
    sockaddr_in a;
    std::memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(ip);
    a.sin_port = htons(port);
    ::sendto(sock_, data, len, 0, reinterpret_cast<const sockaddr*>(&a), sizeof(a));   // best effort: UDP, errors are ignored
}

void LanSession::sendToPeers(const uint8_t* data, size_t len, int exceptSlot) {
    for (int i = 1; i < kNetMaxPlayers; ++i) {
        if (!players_[i].present || i == exceptSlot) continue;
        sendTo(peers_[i].ip, peers_[i].port, data, len);
    }
}

void LanSession::sendBeacon() {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kBeacon, 0, 0);
    w.u32(lobbyId_);
    w.u8(roomRacing_ ? 1 : 0);
    w.u8(static_cast<uint8_t>(playerCount()));
    w.u8(static_cast<uint8_t>(kNetMaxPlayers));
    w.name(players_[0].name);
    if (!cfg_.discoveryTargets.empty()) {
        for (const NetConfig::Target& t : cfg_.discoveryTargets) sendTo(t.ip, t.port, buf, w.n);
        return;
    }
    const std::vector<IfaceInfo> ifs = interfaces();
    if (ifs.empty()) sendTo(0xFFFFFFFFu, cfg_.port, buf, w.n);
    for (const IfaceInfo& i : ifs) sendTo(i.broadcast, cfg_.port, buf, w.n);
}

void LanSession::sendRoster() {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kRoster, 0, 0);
    w.u32(lobbyId_);
    w.u8(roomRacing_ ? 1 : 0);
    for (int i = 0; i < kNetMaxPlayers; ++i) {
        w.u8(players_[i].present ? 1 : 0);
        w.u8(static_cast<uint8_t>(players_[i].phase));
        w.name(players_[i].name);
    }
    sendToPeers(buf, w.n, -1);
}

void LanSession::sendJoin() {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kJoin, -1, 0);
    w.u32(joinNonce_);
    char nm[kNetNameLen + 1] = {};
    std::strncpy(nm, name_.c_str(), kNetNameLen);
    w.name(nm);
    sendTo(hostIp_, hostPort_, buf, w.n);
}

void LanSession::sendKeepAlive() {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kKeepAlive, selfSlot_, 0);
    w.u8(static_cast<uint8_t>(localPhase_));
    w.f64(clock_);   // echoed back by the host: round trip time + the host's clock = clock sync
    sendTo(hostIp_, hostPort_, buf, w.n);
}

void LanSession::sendPong(uint32_t ip, uint16_t port, double stamp) {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kPong, 0, 0);
    w.f64(stamp);
    w.f64(clock_);
    sendTo(ip, port, buf, w.n);
}

// Keeps the last few round trips; the one with the shortest trip has the least queueing in it, so it gives the best clock offset.
void LanSession::addPing(float rtt, double offset) {
    pings_[pingHead_] = {rtt, offset};
    pingHead_ = (pingHead_ + 1) % 8;
    pingCount_ = std::min(pingCount_ + 1, 8);
    int best = 0;
    for (int i = 1; i < pingCount_; ++i)
        if (pings_[i].rtt < pings_[best].rtt) best = i;
    hostOffset_ = pings_[best].offset;
    offsetValid_ = true;
}

void LanSession::sendStart(uint32_t ip, uint16_t port) {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kStart, 0, 0);
    w.u32(raceId_);
    w.u32(raceSeed_);
    w.f64(raceStartedAt_);   // host clock when START was pressed: clients subtract their lag so GO happens together
    w.f32(goal_);
    sendTo(ip, port, buf, w.n);
}

void LanSession::sendOwnState() {
    uint8_t buf[kMaxPacket];
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kState, selfSlot_, stateSeq_++);
    w.u32(raceId_);
    const RiderNet& r = local_;
    for (float f : {r.s, r.x, r.alpha, r.yawVis, r.speed, r.lean, r.tuck, r.slide, r.pushAmount, r.pushPhase, r.crashTime, r.crashSpeed, r.distance}) w.f32(f);
    w.u32(static_cast<uint32_t>(r.score));
    w.u8(static_cast<uint8_t>((r.crashed ? 1 : 0) | (r.slideDir < 0.0f ? 2 : 0) | (r.airborne ? 4 : 0) | (r.finished ? 8 : 0)));
    w.u8(static_cast<uint8_t>(localPhase_));
    w.f32(r.yRel);
    w.f32(r.finishTime);
    w.f32(static_cast<float>(raceTime()));   // when this state was true, on the shared race clock: receivers play it back by this, not by arrival time
    if (role_ == NetRole::Host) sendToPeers(buf, w.n, -1);
    else sendTo(hostIp_, hostPort_, buf, w.n);
}

// ---- receiving ------------------------------------------------------------------------------------------------------------
void LanSession::receiveAll() {
    uint8_t buf[kMaxPacket + 64];
    for (int guard = 0; guard < 96; ++guard) {
        sockaddr_in from;
        socklen_t fl = sizeof(from);
        const ssize_t n = ::recvfrom(sock_, buf, sizeof(buf), 0, reinterpret_cast<sockaddr*>(&from), &fl);
        if (n < 0) break;
        if (n < static_cast<ssize_t>(kHeaderSize) || n > static_cast<ssize_t>(kMaxPacket)) continue;
        handle(buf, static_cast<size_t>(n), ntohl(from.sin_addr.s_addr), ntohs(from.sin_port));
    }
}

int LanSession::slotOf(uint32_t ip, uint16_t port) const {
    for (int i = 1; i < kNetMaxPlayers; ++i)
        if (players_[i].present && peers_[i].ip == ip && peers_[i].port == port) return i;
    return -1;
}

int LanSession::freeSlot() const {
    for (int i = 1; i < kNetMaxPlayers; ++i)
        if (!players_[i].present) return i;
    return -1;
}

void LanSession::handle(const uint8_t* data, size_t len, uint32_t ip, uint16_t port) {
    Reader r(data, len);
    if (r.u32() != kMagic) return;
    const uint8_t type = r.u8();
    const uint8_t slotField = r.u8();
    r.u16();   // sequence (reserved)
    const uint8_t* body = data + kHeaderSize;
    const size_t bodyLen = len - kHeaderSize;

    switch (type) {
        case kBeacon:
            if (role_ == NetRole::Searching) onBeacon(body, bodyLen, ip, port);
            break;
        case kJoin:
            if (role_ == NetRole::Host) onJoin(slotField, body, bodyLen, ip, port);
            break;
        case kWelcome: {
            if (role_ != NetRole::Searching || !joining_ || ip != hostIp_ || port != hostPort_) break;
            Reader b(body, bodyLen);
            const uint32_t lobby = b.u32();
            const uint8_t slot = b.u8();
            if (!b.ok || slot == 0 || slot >= kNetMaxPlayers) break;
            role_ = NetRole::Joined;
            joining_ = false;
            selfSlot_ = slot;
            lobbyId_ = lobby;
            lastHostHeard_ = clock_;
            players_[slot].self = true;
            players_[slot].present = true;
            std::strncpy(players_[slot].name, name_.c_str(), kNetNameLen);
            keepAliveTimer_ = 0.0f;
            pingBurst_ = 5;   // a few quick round trips right away so the clock offset is known before the first race
            pingTimer_ = 0.0f;
            break;
        }
        case kReject: {
            if (role_ != NetRole::Searching || !joining_ || ip != hostIp_ || port != hostPort_) break;
            Reader b(body, bodyLen);
            const uint8_t why = b.u8();
            joining_ = false;
            error_ = why == kRejectRacing ? "RACE ALREADY RUNNING" : "THAT ROOM IS FULL";
            break;
        }
        case kRoster: {
            if (role_ != NetRole::Joined || ip != hostIp_ || port != hostPort_) break;
            Reader b(body, bodyLen);
            const uint32_t lobby = b.u32();
            const bool racing = b.u8() != 0;
            NetPlayer next[kNetMaxPlayers];
            for (int i = 0; i < kNetMaxPlayers; ++i) {
                next[i].present = b.u8() != 0;
                const uint8_t ph = b.u8();
                next[i].phase = ph <= 2 ? static_cast<PeerPhase>(ph) : PeerPhase::Lobby;
                b.name(next[i].name);
            }
            if (!b.ok || lobby != lobbyId_) break;
            lastHostHeard_ = clock_;
            roomRacing_ = racing;
            for (int i = 0; i < kNetMaxPlayers; ++i) {
                NetPlayer& p = players_[i];
                p.present = next[i].present;
                std::memcpy(p.name, next[i].name, sizeof(p.name));
                if (i != selfSlot_) p.phase = next[i].phase;
                p.self = i == selfSlot_;
                if (!p.present) remote_[i] = Remote();
            }
            if (!players_[selfSlot_].present) fail("REMOVED FROM THE ROOM");
            break;
        }
        case kStart: {
            if (role_ != NetRole::Joined || ip != hostIp_ || port != hostPort_) break;
            Reader b(body, bodyLen);
            const uint32_t race = b.u32();
            const uint32_t seed = b.u32();
            const double t0 = b.f64();
            const float goal = b.f32();
            if (!b.ok) break;
            lastHostHeard_ = clock_;
            if (race == lastStartRace_) break;   // a repeat of a start we already acted on
            lastStartRace_ = race;
            raceId_ = race;
            roomRacing_ = true;
            for (int i = 0; i < kNetMaxPlayers; ++i) remote_[i] = Remote();
            // how long ago the host pressed START, on the host's clock; the countdown is fast-forwarded by that much
            double lag = offsetValid_ ? (clock_ + hostOffset_ - t0) : static_cast<double>(kAssumedLatency);
            if (!std::isfinite(lag)) lag = static_cast<double>(kAssumedLatency);
            lag = std::min(3.0, std::max(0.0, lag));
            raceT0_ = clock_ - lag;
            pendingLag_ = static_cast<float>(lag);
            goal_ = clean(goal, 0.0f, 20000.0f);
            pendingStart_ = true;
            pendingSeed_ = seed;
            break;
        }
        case kState:
            onState(slotField, data, len, body, bodyLen, ip, port);
            break;
        case kKeepAlive: {
            if (role_ != NetRole::Host) break;
            const int slot = slotOf(ip, port);
            if (slot < 0) break;
            Reader b(body, bodyLen);
            const uint8_t ph = b.u8();
            peers_[slot].lastHeard = clock_;
            if (b.ok && ph <= 2) players_[slot].phase = static_cast<PeerPhase>(ph);
            if (b.ok && b.left() >= 8) sendPong(ip, port, b.f64());
            break;
        }
        case kPong: {
            if (role_ != NetRole::Joined || ip != hostIp_ || port != hostPort_) break;
            Reader b(body, bodyLen);
            const double echo = b.f64();
            const double hostClock = b.f64();
            if (!b.ok) break;
            lastHostHeard_ = clock_;
            const double rtt = clock_ - echo;
            if (rtt >= 0.0 && rtt < 3.0 && std::isfinite(hostClock)) addPing(static_cast<float>(rtt), hostClock + rtt * 0.5 - clock_);
            break;
        }
        case kLeave: {
            if (role_ == NetRole::Host) {
                const int slot = slotOf(ip, port);
                if (slot > 0) removePeer(slot);
            } else if (role_ == NetRole::Joined && ip == hostIp_ && port == hostPort_) {
                fail("THE HOST LEFT");
            }
            break;
        }
        default: break;
    }
}

void LanSession::onBeacon(const uint8_t* p, size_t n, uint32_t ip, uint16_t port) {
    Reader r(p, n);
    FoundHost h;
    h.lobbyId = r.u32();
    h.racing = r.u8() != 0;
    h.players = r.u8();
    h.maxPlayers = r.u8();
    r.name(h.name);
    if (!r.ok) return;
    h.players = std::min(h.players, kNetMaxPlayers);
    h.maxPlayers = std::min(std::max(h.maxPlayers, 1), kNetMaxPlayers);
    h.ip = ip;
    h.port = port;
    h.lastSeen = clock_;
    for (FoundHost& e : hosts_) {
        if (e.ip == ip && e.port == port) {
            e = h;
            return;
        }
    }
    if (hosts_.size() < 8) hosts_.push_back(h);
}

void LanSession::onJoin(uint8_t, const uint8_t* p, size_t n, uint32_t ip, uint16_t port) {
    Reader r(p, n);
    const uint32_t nonce = r.u32();
    char nm[kNetNameLen + 1] = {};
    r.name(nm);
    if (!r.ok) return;

    uint8_t buf[kMaxPacket];
    const int existing = slotOf(ip, port);
    int slot = existing;
    if (existing < 0) {
        if (roomRacing_ || (slot = freeSlot()) < 0) {
            Writer w(buf, sizeof(buf));
            w.n = writeHeader(buf, kReject, 0, 0);
            w.u8(roomRacing_ ? kRejectRacing : kRejectFull);
            sendTo(ip, port, buf, w.n);
            return;
        }
        NetPlayer& pl = players_[slot];
        pl = NetPlayer();
        pl.present = true;
        std::memcpy(pl.name, nm, sizeof(pl.name));
        peers_[slot].ip = ip;
        peers_[slot].port = port;
        peers_[slot].nonce = nonce;
        remote_[slot] = Remote();
        rosterDirty_ = true;
    }
    peers_[slot].lastHeard = clock_;
    Writer w(buf, sizeof(buf));
    w.n = writeHeader(buf, kWelcome, 0, 0);
    w.u32(lobbyId_);
    w.u8(static_cast<uint8_t>(slot));
    sendTo(ip, port, buf, w.n);
}

// Snapshots are stamped with the SENDER's race time, so network jitter and bursts of packets don't make riders stutter. How far in the
// past a rider is drawn adapts to the jitter measured on its packets (about 60 ms on a quiet network, up to 220 ms on a bad one).
void LanSession::pushSnap(int slot, const RiderNet& r, double ts) {
    Remote& rm = remote_[slot];
    if (rm.count > 0 && ts <= rm.snaps[(rm.head + 15) % 16].t + 1e-4) return;   // duplicate or out of order
    const float slack = static_cast<float>(raceTime() - ts);
    if (!rm.init) {
        rm.init = true;
        rm.slackEma = slack;
    }
    rm.slackEma += (slack - rm.slackEma) * 0.06f;
    rm.jit += (std::fabs(slack - rm.slackEma) - rm.jit) * 0.06f;
    const float target = std::min(0.22f, std::max(0.06f, 0.040f + 2.5f * rm.jit));
    rm.delay += (target - rm.delay) * 0.04f;
    rm.snaps[rm.head].t = ts;
    rm.snaps[rm.head].r = r;
    rm.head = (rm.head + 1) % 16;
    rm.count = std::min(rm.count + 1, 16);
}

void LanSession::onState(uint8_t slot, const uint8_t* all, size_t len, const uint8_t* p, size_t n, uint32_t ip, uint16_t port) {
    if (slot >= kNetMaxPlayers) return;
    if (role_ == NetRole::Host) {
        if (slot == 0 || slotOf(ip, port) != slot) return;   // only the player who owns the slot may speak for it
    } else if (role_ == NetRole::Joined) {
        if (ip != hostIp_ || port != hostPort_ || slot == selfSlot_) return;   // everything arrives via the host
        lastHostHeard_ = clock_;
    } else {
        return;
    }
    Reader r(p, n);
    const uint32_t race = r.u32();
    RiderNet s;
    s.s = clean(r.f32(), -1e6f, 1e7f);
    s.x = clean(r.f32(), -30.0f, 30.0f);
    s.alpha = clean(r.f32(), -3.5f, 3.5f);
    s.yawVis = clean(r.f32(), -3.5f, 3.5f);
    s.speed = clean(r.f32(), 0.0f, 200.0f);
    s.lean = clean(r.f32(), -2.0f, 2.0f);
    s.tuck = clean(r.f32(), 0.0f, 1.0f);
    s.slide = clean(r.f32(), 0.0f, 1.0f);
    s.pushAmount = clean(r.f32(), 0.0f, 1.0f);
    s.pushPhase = clean(r.f32(), 0.0f, 1000.0f);
    s.crashTime = clean(r.f32(), 0.0f, 600.0f);
    s.crashSpeed = clean(r.f32(), 0.0f, 200.0f);
    s.distance = clean(r.f32(), 0.0f, 1e7f);
    s.score = static_cast<int32_t>(r.u32());
    const uint8_t flags = r.u8();
    const uint8_t ph = r.u8();
    s.yRel = clean(r.f32(), -200.0f, 200.0f);
    s.finishTime = clean(r.f32(), 0.0f, 100000.0f);
    const double ts = static_cast<double>(clean(r.f32(), -10.0f, 100000.0f));
    if (!r.ok) return;
    s.crashed = (flags & 1) != 0;
    s.slideDir = (flags & 2) ? -1.0f : 1.0f;
    s.airborne = (flags & 4) != 0;
    s.finished = (flags & 8) != 0;
    s.score = std::max(0, std::min(s.score, 100000000));
    if (role_ == NetRole::Host) peers_[slot].lastHeard = clock_;
    if (race != raceId_) return;   // a straggler from another race: keep the liveness update, drop the data

    NetPlayer& pl = players_[slot];
    if (pl.present) {
        pl.score = s.score;
        pl.distance = s.distance;
        pl.s = s.s;
        pl.crashed = s.crashed;
        pl.crossed = s.finished;
        pl.finishTime = s.finishTime;
        if (ph <= 2) pl.phase = static_cast<PeerPhase>(ph);
    }
    pushSnap(slot, s, ts);
    if (role_ == NetRole::Host) sendToPeers(all, len, slot);   // relay to everybody else
}

void LanSession::removePeer(int slot) {
    if (slot <= 0 || slot >= kNetMaxPlayers) return;
    players_[slot] = NetPlayer();
    peers_[slot] = Peer();
    remote_[slot] = Remote();
    rosterDirty_ = true;
}

// ---- per-frame work -------------------------------------------------------------------------------------------------------
void LanSession::update(float dt) {
    clock_ += static_cast<double>(dt);
    if (role_ == NetRole::Off || sock_ < 0) return;
    receiveAll();
    if (role_ == NetRole::Off) return;   // a packet may have ended the session (the host left)
    if (role_ == NetRole::Host) hostTick(dt);
    else clientTick(dt);
}

void LanSession::hostTick(float dt) {
    beaconTimer_ -= dt;
    if (beaconTimer_ <= 0.0f) {
        sendBeacon();
        beaconTimer_ = roomRacing_ ? 2.0f * kBeaconPeriod : kBeaconPeriod;
    }
    for (int i = 1; i < kNetMaxPlayers; ++i)
        if (players_[i].present && clock_ - peers_[i].lastHeard > kPeerTimeout) removePeer(i);

    // the room is open again once nobody is racing any more
    if (roomRacing_ && clock_ - raceStartedAt_ > 2.0) {
        bool anyRacing = false;
        for (const NetPlayer& p : players_) anyRacing = anyRacing || (p.present && p.phase == PeerPhase::Racing);
        if (!anyRacing) {
            roomRacing_ = false;
            rosterDirty_ = true;
        }
    }

    rosterTimer_ -= dt;
    if (rosterDirty_ || rosterTimer_ <= 0.0f) {
        sendRoster();
        rosterDirty_ = false;
        rosterTimer_ = roomRacing_ ? 2.0f * kRosterPeriod : kRosterPeriod;
    }
    if (startRepeats_ > 0) {
        startTimer_ -= dt;
        if (startTimer_ <= 0.0f) {
            for (int i = 1; i < kNetMaxPlayers; ++i)
                if (players_[i].present) sendStart(peers_[i].ip, peers_[i].port);
            --startRepeats_;
            startTimer_ = 0.12f;
        }
    }
    stateTimer_ -= dt;
    if (stateTimer_ <= 0.0f && localPhase_ != PeerPhase::Lobby) {
        sendOwnState();
        stateTimer_ = localPhase_ == PeerPhase::Racing ? kStatePeriod : 0.25f;
    }
}

void LanSession::clientTick(float dt) {
    if (role_ == NetRole::Searching) {
        hosts_.erase(std::remove_if(hosts_.begin(), hosts_.end(), [this](const FoundHost& h) { return clock_ - h.lastSeen > kHostListTimeout; }), hosts_.end());
        if (joining_) {
            joinAge_ += dt;
            joinTimer_ -= dt;
            if (joinTimer_ <= 0.0f) {
                sendJoin();
                joinTimer_ = 0.4f;
            }
            if (joinAge_ > 5.0f) {
                joining_ = false;
                error_ = "NO ANSWER FROM THE HOST";
            }
        }
        return;
    }
    // joined
    if (clock_ - lastHostHeard_ > kHostTimeout) {
        fail("LOST THE HOST");
        return;
    }
    stateTimer_ -= dt;
    if (localPhase_ == PeerPhase::Racing || (localPhase_ == PeerPhase::Finished && roomRacing_)) {
        if (stateTimer_ <= 0.0f) {
            sendOwnState();
            stateTimer_ = localPhase_ == PeerPhase::Racing ? kStatePeriod : 0.25f;
        }
    }
    keepAliveTimer_ -= dt;
    if (keepAliveTimer_ <= 0.0f) {
        sendKeepAlive();
        keepAliveTimer_ = kKeepAlivePeriod;
    }
    if (pingBurst_ > 0) {
        pingTimer_ -= dt;
        if (pingTimer_ <= 0.0f) {
            sendKeepAlive();
            pingTimer_ = 0.1f;
            --pingBurst_;
        }
    }
}

// ---- racing together ------------------------------------------------------------------------------------------------------
bool LanSession::canStart() const { return role_ == NetRole::Host && !roomRacing_; }

bool LanSession::startRace() {
    if (!canStart()) return false;
    raceId_ = random32() | 1u;
    raceSeed_ = random32();
    roomRacing_ = true;
    raceStartedAt_ = clock_;
    raceT0_ = clock_;
    goal_ = hostGoal_;
    pendingLag_ = 0.0f;
    for (int i = 0; i < kNetMaxPlayers; ++i) {
        remote_[i] = Remote();
        if (players_[i].present) {
            players_[i].score = 0;
            players_[i].distance = 0.0f;
            players_[i].crashed = false;
            players_[i].crossed = false;
            players_[i].finishTime = 0.0f;
            if (i != selfSlot_) players_[i].phase = PeerPhase::Racing;
        }
    }
    startRepeats_ = 6;
    startTimer_ = 0.0f;
    rosterDirty_ = true;
    pendingStart_ = true;
    pendingSeed_ = raceSeed_;
    return true;
}

bool LanSession::takeStart(uint32_t& seed) {
    float lag = 0.0f;
    return takeStart(seed, lag);
}

bool LanSession::takeStart(uint32_t& seed, float& lagSeconds) {
    if (!pendingStart_) return false;
    pendingStart_ = false;
    seed = pendingSeed_;
    lagSeconds = pendingLag_;
    return true;
}

void LanSession::setGoal(float meters) {
    hostGoal_ = clean(meters, 0.0f, 20000.0f);
}

void LanSession::setLocal(const RiderNet& me, PeerPhase phase) {
    local_ = me;
    localPhase_ = phase;
    if (selfSlot_ >= 0 && inRoom()) {
        NetPlayer& p = players_[selfSlot_];
        p.phase = phase;
        p.score = me.score;
        p.distance = me.distance;
        p.s = me.s;
        p.crashed = me.crashed;
        p.crossed = me.finished;
        p.finishTime = me.finishTime;
    }
}

bool LanSession::riderKnown(int slot) const { return slot >= 0 && slot < kNetMaxPlayers && remote_[slot].count > 0; }

bool LanSession::sampleRider(int slot, RiderNet& out) const {
    if (!riderKnown(slot)) return false;
    const Remote& rm = remote_[slot];
    const double t = raceTime() - static_cast<double>(rm.delay);
    const Snap* older = nullptr;
    const Snap* newer = nullptr;
    for (int k = 0; k < rm.count; ++k) {   // newest first
        const Snap& s = rm.snaps[(rm.head - 1 - k + 32) % 16];
        if (s.t <= t) { older = &s; break; }
        newer = &s;
    }
    if (!older) {                           // everything is newer than the render time: show the oldest we have
        out = rm.snaps[(rm.head - rm.count + 32) % 16].r;
        return true;
    }
    if (!newer) {                           // past the newest update: keep going for a moment at the last known speed
        out = older->r;
        const float ahead = static_cast<float>(std::min(t - older->t, static_cast<double>(kMaxExtrapolation)));
        if (!out.crashed && !out.finished) {
            out.s += out.speed * ahead;
            out.distance += out.speed * ahead;
        }
        return true;
    }
    const float span = static_cast<float>(newer->t - older->t);
    const float f = span > 1e-4f ? std::min(1.0f, std::max(0.0f, static_cast<float>(t - older->t) / span)) : 1.0f;
    const RiderNet &a = older->r, &b = newer->r;
    out = b;
    out.s = lerpf2(a.s, b.s, f);
    out.x = lerpf2(a.x, b.x, f);
    out.alpha = lerpf2(a.alpha, b.alpha, f);
    out.yawVis = lerpf2(a.yawVis, b.yawVis, f);
    out.speed = lerpf2(a.speed, b.speed, f);
    out.lean = lerpf2(a.lean, b.lean, f);
    out.tuck = lerpf2(a.tuck, b.tuck, f);
    out.slide = lerpf2(a.slide, b.slide, f);
    out.pushAmount = lerpf2(a.pushAmount, b.pushAmount, f);
    out.pushPhase = lerpf2(a.pushPhase, b.pushPhase, f);
    out.crashTime = lerpf2(a.crashTime, b.crashTime, f);
    out.distance = lerpf2(a.distance, b.distance, f);
    out.yRel = lerpf2(a.yRel, b.yRel, f);
    return true;
}

}  // namespace sd
