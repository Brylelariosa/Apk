#include "engine.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "audio_synth.h"
#include "log.h"

namespace sd {

namespace {
constexpr float kGoals[] = {1000.0f, 2000.0f, 3000.0f, 5000.0f, 0.0f};   // race lengths the host can pick; 0 = endless run
constexpr int kGoalCount = static_cast<int>(sizeof(kGoals) / sizeof(kGoals[0]));
}  // namespace

Engine::Engine(const NetConfig& netConfig) : net_(netConfig) {}

void Engine::setSettings(int bestScore, bool soundOn) {
    game_.setBest(bestScore);
    best_.store(bestScore);
    soundOn_.store(soundOn);
}

void Engine::setControls(const std::string& text) {
    controls_.setConfig(ControlsConfig::parse(text));
}

void Engine::onSurfaceCreated() {
    renderer_.onContextCreated();
    haveLast_ = false;
    warmup_ = 4.0f;
    govTimer_ = govFrameTime_ = 0.0f;
    govFrames_ = 0;
    controls_.releaseAll();
}

void Engine::onSurfaceChanged(int width, int height) {
    width_ = std::max(1, width);
    height_ = std::max(1, height);
    controls_.setScreen(static_cast<float>(width_), static_cast<float>(height_));
    renderer_.onResize(width_, height_);
}

void Engine::onTouch(int action, int pointerId, float x, float y) {
    controls_.onTouch(action, pointerId, x, y);
}

bool Engine::requestBack() {
    if (phase_.load() == static_cast<int>(Phase::Menu) && !editorOpen_.load() && !mpOpen_.load()) return false;
    backRequested_.store(true);
    return true;
}

void Engine::onDrawFrame() {
    const auto now = std::chrono::steady_clock::now();
    float dt = 1.0f / 60.0f;
    if (haveLast_) dt = std::chrono::duration<float>(now - last_).count();
    last_ = now;
    haveLast_ = true;
    stepFrame(dt);
}

HudModel Engine::makeHudModel() const {
    HudModel m;
    m.phase = game_.phase();
    m.phaseTime = game_.phaseTime();
    m.time = game_.time();
    m.speedKmh = game_.speedKmh();
    m.distanceM = game_.distanceM();
    m.score = game_.score();
    m.best = game_.best();
    m.newBest = game_.newBest();
    m.topSpeedKmh = game_.topSpeedKmh();
    m.nearMisses = game_.nearMisses();
    m.countdown = game_.countdownNumber();
    m.countdownProgress = game_.countdownProgress();
    m.popup = game_.popupText();
    m.popupAlpha = game_.popupAlpha();
    m.popupAge = game_.popupAge();
    m.soundOn = soundOn_.load();
    m.mode = controls_.mode();
    m.steerActive = controls_.steerActive();
    m.stickOrigin = controls_.stickOrigin();
    m.stickKnob = controls_.stickKnob();
    m.tuckDown = controls_.tuckDown();
    m.slideDown = controls_.slideDown();
    m.leftDown = controls_.leftDown();
    m.rightDown = controls_.rightDown();
    m.tilt = controls_.tiltSteer();
    m.opacity = controls_.opacity();
    m.goalM = game_.goalMeters();
    m.toGoM = game_.goalRemaining();
    m.finished = game_.finished();
    m.finishTime = game_.finishTime();
    fillMultiplayer(m);
    m.finishRank = m.finished && mpRace_ ? m.mp.rank : 0;
    return m;
}

void Engine::applyAction(UiAction action, int index) {
    switch (action) {
        case UiAction::Start:
            controls_.releaseAll();
            game_.startRun();
            break;
        case UiAction::Retry:
            controls_.releaseAll();
            if (mpRace_) {   // after a LAN race "retry" means back to the lobby, where the host starts the next one
                game_.toMenu();
                mpRace_ = false;
            } else {
                game_.startRun();
            }
            break;
        case UiAction::Pause: game_.pause(); break;
        case UiAction::Resume: game_.resume(); break;
        case UiAction::Menu:
            controls_.releaseAll();
            if (mpRace_ || mpScreen_ != MpScreen::Off) {   // leaving the menu of a LAN race = leaving the room
                net_.leave();
                net_.clearError();
                mpRace_ = false;
                mpScreen_ = MpScreen::Off;
                mpStatus_.clear();
            }
            game_.toMenu();
            break;
        case UiAction::ToggleSound:
            soundOn_.store(!soundOn_.load());
            markSettingsChanged();
            break;
        case UiAction::OpenControls: controls_.openEditor(); break;

        case UiAction::OpenLobby:
            mpScreen_ = MpScreen::Lobby;
            mpStatus_.clear();
            net_.clearError();
            break;
        case UiAction::LobbyHost:
            mpStatus_.clear();
            if (!net_.host(playerName_)) mpStatus_ = net_.error();
            break;
        case UiAction::LobbySearch:
            mpStatus_.clear();
            if (!net_.search(playerName_)) mpStatus_ = net_.error();
            break;
        case UiAction::LobbyJoin: net_.join(index); break;
        case UiAction::LobbyGoal:
            goalIndex_ = (goalIndex_ + 1) % kGoalCount;
            net_.setGoal(kGoals[goalIndex_]);
            break;
        case UiAction::LobbyStart: {
            uint32_t seed = 0;
            net_.setGoal(kGoals[goalIndex_]);
            if (net_.startRace() && net_.takeStart(seed)) beginLanRace(seed, 0.0f, net_.goal());
            break;
        }
        case UiAction::LobbyLeave:   // search / room -> back to the choice
            net_.leave();
            net_.clearError();
            mpStatus_.clear();
            break;
        case UiAction::LobbyBack:    // the choice -> back to the main menu
            mpScreen_ = MpScreen::Off;
            mpStatus_.clear();
            net_.clearError();
            break;
        case UiAction::None: break;
    }
}

namespace {

// Screen position of a world point, or false when it is behind the camera / off screen.
bool projectToScreen(const CameraView& cam, float aspect, const Vec3& p, float w, float h, Vec2& out) {
    const Vec3 rel = p - cam.pos;
    const float z = dot(rel, cam.fwd);
    if (z < 2.0f) return false;
    const float t = std::tan(cam.fovY * 0.5f);
    const float nx = dot(rel, cam.right) / (z * t * aspect);
    const float ny = dot(rel, cam.up) / (z * t);
    out = Vec2((nx * 0.5f + 0.5f) * w, (1.0f - (ny * 0.5f + 0.5f)) * h);
    return nx > -1.05f && nx < 1.05f && ny > -1.1f && ny < 1.1f;
}

void copyName(char* dst, size_t cap, const char* src) {
    std::strncpy(dst, src, cap - 1);
    dst[cap - 1] = '\0';
}

}  // namespace

// Everything the multiplayer screens need, from the network session and the remote riders.
void Engine::fillMultiplayer(HudModel& m) const {
    MpModel& mp = m.mp;
    mp.racing = mpRace_;
    if (mpScreen_ == MpScreen::Off && !mpRace_) return;
    copyName(mp.status, sizeof(mp.status), !net_.error().empty() ? net_.error().c_str() : mpStatus_.c_str());
    copyName(mp.address, sizeof(mp.address), mpAddress_.c_str());
    mp.isHost = net_.isHost();
    mp.goalM = mpRace_ ? game_.goalMeters() : kGoals[goalIndex_];
    mp.canStart = net_.canStart();
    mp.joining = net_.joining();
    const NetPlayer* pl = net_.players();

    if (!mpRace_) {
        mp.screen = net_.role() == NetRole::Off ? MpModel::Screen::Choose : (net_.inRoom() ? MpModel::Screen::Room : MpModel::Screen::Search);
        if (mp.screen == MpModel::Screen::Search) {
            const std::vector<FoundHost>& hosts = net_.hosts();
            mp.rowCount = static_cast<int>(std::min<size_t>(hosts.size(), kMpRows));
            for (int i = 0; i < mp.rowCount; ++i) {
                copyName(mp.rows[i].name, sizeof(mp.rows[i].name), hosts[static_cast<size_t>(i)].name);
                mp.rows[i].players = hosts[static_cast<size_t>(i)].players;
                mp.rows[i].racing = hosts[static_cast<size_t>(i)].racing;
            }
        } else if (mp.screen == MpModel::Screen::Room) {
            mp.rowCount = kMpRows;
            for (int i = 0; i < kMpRows; ++i) {
                if (!pl[i].present) continue;
                copyName(mp.rows[i].name, sizeof(mp.rows[i].name), pl[i].name);
                mp.rows[i].style = i;
                mp.rows[i].self = pl[i].self;
                mp.rows[i].host = i == 0;
            }
        }
        return;
    }

    // racing: standings, best first
    int order[kNetMaxPlayers];
    int n = 0;
    for (int i = 0; i < kNetMaxPlayers; ++i)
        if (pl[i].present) order[n++] = i;
    const bool goalRace = game_.goalMeters() > 0.0f;
    std::sort(order, order + n, [pl, goalRace](int a, int b) {
        if (goalRace) {   // a race to a finish line: those who crossed it by their time, the rest by how far they got
            if (pl[a].crossed != pl[b].crossed) return pl[a].crossed;
            if (pl[a].crossed) return pl[a].finishTime < pl[b].finishTime || (pl[a].finishTime == pl[b].finishTime && a < b);
            const int ma = static_cast<int>(pl[a].s), mb = static_cast<int>(pl[b].s);   // whole metres: every phone orders ties the same way
            return ma != mb ? ma > mb : a < b;
        }
        if (pl[a].score != pl[b].score) return pl[a].score > pl[b].score;
        return pl[a].distance > pl[b].distance || (pl[a].distance == pl[b].distance && a < b);
    });
    mp.rowCount = std::min(n, kMpRows);
    mp.allDone = true;
    for (int r = 0; r < mp.rowCount; ++r) {
        const int i = order[r];
        MpRow& row = mp.rows[r];
        copyName(row.name, sizeof(row.name), pl[i].name);
        row.score = pl[i].score;
        row.distanceM = pl[i].distance;
        row.style = i;
        row.self = pl[i].self;
        row.crashed = pl[i].crashed;
        row.crossed = pl[i].crossed;
        row.finishTime = pl[i].finishTime;
        row.toGoM = goalRace ? game_.goalS() - pl[i].s : 0.0f;
        row.finished = pl[i].phase == PeerPhase::Finished;
        if (pl[i].phase == PeerPhase::Racing && !pl[i].crashed) mp.allDone = false;
        if (pl[i].self) mp.rank = r + 1;
    }
    if (game_.phase() == Phase::GameOver) {   // my own run is certainly over, whatever the last packet said
        for (int r = 0; r < mp.rowCount; ++r)
            if (mp.rows[r].self) mp.rows[r].finished = true;
    }

    // name tags over the riders who are on screen
    const CameraView& cam = game_.camera().view();
    const float aspect = width_ > 0 && height_ > 0 ? static_cast<float>(width_) / static_cast<float>(height_) : 16.0f / 9.0f;
    const UiLayout& layout = controls_.layout();
    for (const RemoteRider& rr : remotes_) {
        if (mp.tagCount >= kMpRows) break;
        const TrackSample f = game_.world().track().at(rr.net.s);
        const Vec3 head = Track::surfacePoint(f, rr.net.x) + f.up * (rr.net.crashed ? 1.0f : 2.45f);
        Vec2 pos;
        if (!projectToScreen(cam, aspect, head, layout.w, layout.h, pos)) continue;
        const float ahead = rr.net.s - game_.skater().s;
        if (ahead > 260.0f || ahead < -70.0f) continue;
        MpTag& tag = mp.tags[mp.tagCount++];
        tag.pos = pos;
        copyName(tag.name, sizeof(tag.name), pl[rr.style].name);
        tag.style = rr.style;
        tag.ahead = ahead;
        tag.crashed = rr.net.crashed;
        tag.alpha = 1.0f - saturate((std::fabs(ahead) - 150.0f) / 110.0f);
    }
}

// A LAN race starts: everybody is on the same seed, so the road and the cones are identical on every phone.
void Engine::beginLanRace(uint32_t seed, float lag, float goal) {
    controls_.releaseAll();
    game_.setLocalStyle(std::max(0, net_.selfSlot()));
    game_.startRunSeeded(seed, lag, goal);
    mpRace_ = game_.phase() == Phase::Countdown;
}

void Engine::updateMultiplayer(float dt) {
    net_.update(dt);
    mpAddrTimer_ -= dt;
    if (mpAddrTimer_ <= 0.0f && mpScreen_ != MpScreen::Off) {
        mpAddrTimer_ = 1.0f;
        const std::vector<std::string> addrs = net_.localAddresses();
        mpAddress_ = addrs.empty() ? std::string() : addrs.front();
    }
    uint32_t seed = 0;
    float lag = 0.0f;
    if (net_.takeStart(seed, lag) && net_.inRoom() && (game_.phase() == Phase::Menu || game_.phase() == Phase::GameOver)) beginLanRace(seed, lag, net_.goal());
    if (mpRace_ && !net_.inRoom()) {   // the room is gone (the host left or the connection dropped): the run goes on solo
        mpRace_ = false;
        mpStatus_ = net_.error();
    }
    if (mpScreen_ == MpScreen::Off && !mpRace_ && net_.role() != NetRole::Off) net_.leave();
    mpOpen_.store(mpScreen_ != MpScreen::Off || mpRace_);
}

void Engine::updateQuality(float dt) {
    if (!renderer_.ready() || game_.phase() == Phase::Paused) return;
    if (warmup_ > 0.0f) {
        warmup_ -= dt;
        return;
    }
    raiseLockout_ = std::max(0.0f, raiseLockout_ - dt);
    sinceRaise_ += dt;
    govFrameTime_ += dt;
    ++govFrames_;
    govTimer_ += dt;
    if (govTimer_ < 1.5f) return;
    const float avgMs = govFrameTime_ / static_cast<float>(govFrames_) * 1000.0f;
    govTimer_ = govFrameTime_ = 0.0f;
    govFrames_ = 0;
    const int tier = renderer_.qualityTier();
    if (avgMs > 24.0f && tier > 0) {
        if (sinceRaise_ < 20.0f) noRaise_ = true;   // the last increase was too much: stop trying
        renderer_.setQualityTier(tier - 1);
        raiseLockout_ = 25.0f;
        stableTime_ = 0.0f;
        SD_LOGI("quality -> tier %d (avg %.1f ms)", tier - 1, avgMs);
    } else if (avgMs < 17.8f && tier < kQualityTiers - 1 && !noRaise_) {
        stableTime_ += 1.5f;
        if (stableTime_ >= 7.5f && raiseLockout_ <= 0.0f) {
            renderer_.setQualityTier(tier + 1);
            raiseLockout_ = 25.0f;
            sinceRaise_ = 0.0f;
            stableTime_ = 0.0f;
            SD_LOGI("quality -> tier %d (avg %.1f ms)", tier + 1, avgMs);
        }
    } else {
        stableTime_ = 0.0f;
    }
}

void Engine::updateAudio(const GameEvents& ev) {
    AudioSynth& audio = audioSynth();
    if (ev.tick) audio.trigger(AudioEvent::Tick);
    if (ev.go) audio.trigger(AudioEvent::Go);
    if (ev.push) audio.trigger(AudioEvent::Push);
    if (ev.footOn) audio.trigger(AudioEvent::FootOn);
    if (ev.crash) audio.trigger(AudioEvent::Crash);
    if (ev.scrape) audio.trigger(AudioEvent::Scrape);
    if (ev.nearMiss) audio.trigger(AudioEvent::NearMiss);
    if (ev.coneHit) audio.trigger(AudioEvent::ConeHit);
    if (ev.newBest) audio.trigger(AudioEvent::NewBest);

    const Skater& sk = game_.skater();
    const Phase ph = game_.phase();
    AudioState s;
    const bool silent = !soundOn_.load() || ph == Phase::Paused;
    s.speed = ph == Phase::Paused ? 0.0f : sk.speed * (ph == Phase::Menu ? 0.7f : 1.0f);
    s.slide = sk.slide;
    s.offroad = sk.onShoulder && !sk.crashed ? 1.0f : 0.0f;
    s.tuck = sk.tuck;
    s.master = silent ? 0.0f : (ph == Phase::Menu ? 0.6f : 1.0f);
    audio.setState(s);
}

void Engine::stepFrame(float dt) {
    dt = clampf(dt, 0.0f, 0.1f);
    updateQuality(dt);
    updateMultiplayer(dt);

    if (pauseRequested_.exchange(false) && !mpRace_) game_.pause();   // (a LAN race cannot be paused: the others keep riding)
    if (backRequested_.exchange(false)) {
        if (controls_.editorOpen()) {
            controls_.closeEditor();   // Back leaves the CONTROLS screen first
        } else if (mpRace_) {
            applyAction(UiAction::Menu);   // leaving a LAN race means leaving the room
        } else if (mpScreen_ != MpScreen::Off && game_.phase() == Phase::Menu) {
            applyAction(net_.role() != NetRole::Off ? UiAction::LobbyLeave : UiAction::LobbyBack);
        } else {
            game_.handleBack();
        }
    }

    Vec2 tap;
    while (!controls_.editorOpen() && controls_.popTap(tap)) {
        int index = 0;
        const UiAction action = hudHandleTap(controls_.layout(), makeHudModel(), tap.x, tap.y, &index);
        applyAction(action, index);
    }

    const Phase phase = game_.phase();
    controls_.update(dt, phase == Phase::Countdown, phase == Phase::Running);
    const SkaterInput input = phase == Phase::Running ? controls_.skaterInput() : SkaterInput();
    game_.setLocalStyle(mpRace_ ? std::max(0, net_.selfSlot()) : 0);
    game_.update(dt, input);
    if (mpRace_) net_.setLocal(game_.riderNet(), game_.phase() == Phase::GameOver ? PeerPhase::Finished : PeerPhase::Racing);
    else net_.setLocal(RiderNet(), PeerPhase::Lobby);
    updateAudio(game_.takeEvents());
    phase_.store(static_cast<int>(game_.phase()));
    editorOpen_.store(controls_.editorOpen());
    if (game_.best() != best_.load()) {
        best_.store(game_.best());
        markSettingsChanged();
    }
    if (controls_.takeChanged()) markSettingsChanged();

    // the other riders of a LAN race, smoothed
    remotes_.clear();
    if (mpRace_ && net_.inRoom()) {
        for (int slot = 0; slot < kNetMaxPlayers; ++slot) {
            if (slot == net_.selfSlot() || !net_.players()[slot].present) continue;
            RemoteRider rr;
            if (!net_.sampleRider(slot, rr.net)) continue;
            rr.style = slot;
            remotes_.push_back(rr);
        }
    }

    const float density = qualityPreset(renderer_.qualityTier()).treeDensity;
    const FrameParams fp = buildScene(game_, density, geo_, &remotes_);
    const UiLayout& layout = controls_.layout();
    ui_.clear();
    ui_.setScreen(layout.w, layout.h);
    if (controls_.editorOpen()) controls_.drawEditor(ui_);
    else drawHud(ui_, layout, makeHudModel());
    renderer_.render(fp, geo_, ui_);
}

}  // namespace sd
