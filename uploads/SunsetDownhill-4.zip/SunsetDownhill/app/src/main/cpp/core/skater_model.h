// skater_model.h - procedural rider + longboard built from lofted shapes, tubes and ellipsoids each frame.
#pragma once

#include "color.h"
#include "math3d.h"
#include "mesh_data.h"

namespace sd {

struct SkaterPose {
    Vec3 origin;            // board centre on the road surface
    Vec3 right, up, fwd;    // board basis (orthonormal)
    Vec3 roadUp = Vec3(0.0f, 1.0f, 0.0f);   // road surface normal (hands and feet are planted on this plane)
    float tuck = 0.0f;      // 0..1 crouch
    float lean = 0.0f;      // rider lean into the turn (rad, + right)
    float slide = 0.0f;     // 0..1 Coleman slide (deep crouch, hand on the road)
    float slideDir = 1.0f;  // side of the slide (+1 right, -1 left)
    float slip = 0.0f;      // board angle to the travel direction (rad, + = nose to the right)
    float push = 0.0f;      // 0..1 kick-push pose weight
    float pushPhase = 0.0f; // kick cycles since the first kick (0 = foot planted, ready to drive)
    float time = 0.0f;
    bool crashed = false;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
    bool lowDetail = false; // remote riders: fewer segments and subdivisions (keeps six riders inside the 16-bit mesh budget)
};

// Colours of one rider: jacket, helmet, deck and the glow of the wheels. Multiplayer gives every player their own.
struct RiderStyle {
    Rgba8 jacket, jacketHi;   // jacket body, dark -> light
    Rgba8 sleeve;
    Rgba8 accent;             // stripes, cuffs, glove pucks, helmet stripe
    Rgba8 pants;
    Rgba8 helmet;
    Rgba8 deck;
    Rgba8 wheel;
};

constexpr int kRiderStyleCount = 6;
const RiderStyle& riderStyle(int index);   // wraps around; 0 is the classic orange look

// Most vertices one rider (full detail) may add to a mesh; scene_builder uses it to stay inside the 16-bit index range.
constexpr size_t kRiderVertexBudget = 11000;
constexpr size_t kRemoteRiderVertexBudget = 6000;     // low-detail riders
constexpr size_t kDynamicMeshVertexLimit = 64000;    // indices are 16-bit

void buildSkaterMesh(const SkaterPose& pose, MeshData& out, const RiderStyle& style);
inline void buildSkaterMesh(const SkaterPose& pose, MeshData& out) { buildSkaterMesh(pose, out, riderStyle(0)); }

}  // namespace sd
