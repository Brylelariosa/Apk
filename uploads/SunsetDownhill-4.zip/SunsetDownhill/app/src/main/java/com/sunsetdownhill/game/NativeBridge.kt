package com.sunsetdownhill.game

/**
 * Thin JNI surface of the native engine (see app/src/main/cpp/jni_bridge.cpp).
 * All game logic, rendering and audio synthesis live in C++; Kotlin only hosts the window,
 * forwards input and feeds the audio device.
 */
object NativeBridge {
    init {
        System.loadLibrary("sunset_downhill")
    }

    // Touch action codes, mirrored from core/input.h
    const val TOUCH_DOWN = 0
    const val TOUCH_MOVE = 1
    const val TOUCH_UP = 2
    const val TOUCH_CANCEL = 3

    /**
     * [controls] is the saved controls layout (empty = factory layout); see [controlsString].
     * [playerName] is what the other riders of a LAN race see (the device model).
     */
    @JvmStatic external fun create(best: Int, soundOn: Boolean, controls: String, playerName: String)
    @JvmStatic external fun surfaceCreated()
    @JvmStatic external fun surfaceChanged(width: Int, height: Int)
    @JvmStatic external fun drawFrame()
    @JvmStatic external fun touch(action: Int, id: Int, x: Float, y: Float)
    @JvmStatic external fun pause()

    /** Returns true if the game consumed the back press (otherwise the Activity should finish). */
    @JvmStatic external fun back(): Boolean
    @JvmStatic external fun bestScore(): Int
    @JvmStatic external fun soundEnabled(): Boolean

    /** Phone tilt: the direction of "up" in the screen plane in m/s^2 (x right, y up). Safe from any thread. */
    @JvmStatic external fun setTilt(x: Float, y: Float)
    @JvmStatic external fun setTiltAvailable(available: Boolean)

    /** Moves whenever the best score, the sound toggle or the controls layout changed and should be saved. */
    @JvmStatic external fun settingsRevision(): Int

    /** The controls layout as a short text; hand it back to [create] on the next start. GL thread only. */
    @JvmStatic external fun controlsString(): String

    /** Fills [buffer] with [frames] mono 16-bit samples at 22050 Hz. Safe to call from any thread. */
    @JvmStatic external fun fillAudio(buffer: ShortArray, frames: Int)
}
