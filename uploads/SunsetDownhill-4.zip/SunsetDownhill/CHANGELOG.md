# Changelog

## Update 4 (from SunsetDownhill-3): sharper picture, new board / wheels / rider, race goal, cliff jumps, multiplayer sync

**Why the picture was soft (and what changed)**
- The 3D scene is drawn into an offscreen target and stretched to the screen. It used 55 / 70 / 85 / 100 % of the display
  resolution, started at 85 %, dropped a step whenever frames averaged slower than 24 ms, and a hard cap of 1920 px on the long side
  meant a typical 2400 px wide phone could never get above 80 %. Wheels and board are only a few pixels across at the chase camera,
  so a soft upscale and hard jagged edges (no multisampling, FXAA only on the middle tiers) hit them first.
- Presets are now 60 / 75 / 90 / 100 % and the cap is 2560 px. The top tier renders at the full display resolution with **4x MSAA**
  (`gl_util.*`, `renderer.*`: a multisampled twin of the scene target that is resolved into the texture the post pass reads; if the
  device can't do it the scene falls back to FXAA). The post pass has a small clamped **sharpen** that grows with the amount of upscaling.
  The governor is unchanged: it still steps down when frames get slow and back up when they are fast.

**Models** (`skater_model.cpp`, `model_kit.*`)
- New `kit::addLathe` (surface of revolution with smooth or creased normals).
- Wheels: rounded urethane tyre with shoulders and a slightly crowned tread (it was a 10-sided puck), dark groove, bright hub with an
  axle recess and a steel nut. Trucks: riser pad, rounded baseplate, tapered hanger, two coloured bushings, axle.
- Deck: concave, rounded rails, a real grip-tape top (the old one was never visible), centre and flank stripes, tip bands.
- Rider: smoother limbs and joints, lofted shoes (gum sole, toe bumper, laces, heel tab), smoother helmet, a glowing sunset badge on the
  back (the part you look at all run). Remote riders use a cheaper model (`SkaterPose::lowDetail`) and are skipped if the 16-bit index
  range of the dynamic mesh would overflow (`scene_builder.cpp`).

**Race goal (multiplayer)**
- The host picks the race length in the room (**GOAL 1 / 2 / 3 / 5 KM or ENDLESS**, default 2 km). First across the line wins; the
  standings show metres to go or the finish time; crossing the line gives FINISH banner, +500 and the results with times.
  Finish times are measured from GO on a shared clock. A rider who crashes is out (DNF) as before. Single-player stays endless.

**Cliff jumps** (`track.*`, `skater.*`, `world.*`)
- Some bends are now tight (about 55 m radius, 95-118 degrees) on stretches where the inside is the downhill side. There the road has a
  wooden **kicker** at the cliff edge (warning sign before it, no guard rail beside it). Hit it and you fly out over the cliff and land
  on a wide platform that continues as a **shortcut road on stilts** on the inside of the bend and merges back into the road.
  The inside lane covers the bend in less road: about 1 s saved on average in the tests. The board is aimed at the platform by the
  kicker (`Skater::aimJump` simulates the flight for the current speed and bend), landing on the deck gives +300, flights over 0.6 s
  give "AIR TIME", missing the deck or landing from a great height is a crash.
- Physics: height above the road (`yRel`, `vy`), flight with arcade gravity, lateral rail windows that follow the deck, terrain carved
  away under the deck so it really stands above a drop. Zones are a pure function of the seed (same on every phone) and show up about
  once a kilometre. The autopilot keeps off the kicker.

**Multiplayer: delay and sync** (`net.*`)
- Other riders used to be drawn by *arrival* time 120 ms in the past at 20 Hz, so Wi-Fi jitter and bursts of packets showed up
  directly as stutter and lag. Now every state carries the sender's race time; receivers play it back by that timestamp with a
  jitter-adaptive delay (about 60 ms on a quiet network, up to 220 ms on a bad one) and a short extrapolation. 30 updates per second.
- **Clock sync:** clients ping the host (round trip + host clock), keep the best of the last 8, and the START message carries the host's
  clock. A phone that gets START late fast-forwards its countdown by the difference, so **GO is the same moment everywhere**
  (before, each phone counted down from whenever its START packet arrived; lost packets made it worse).
- Android: a **Wi-Fi low-latency lock** (`LanSupport.kt`, `WAKE_LOCK` permission). Wi-Fi power saving batches packets and delivers
  them 100-200 ms late - a big part of "multiplayer is delayed".
- Protocol is now "SDH2" (an old build can't join a new one). New: pong, finish line distance in START, height / airborne / finish
  fields in the state. `tools/test_net` covers clock sync, goal sharing, finish reporting and playback of a burst of packets.

**Tests**: `tools/test_race` (mesh budget, cliff jump zones, 196 simulated kicker jumps, finish line, simultaneous start).

## Update 3 (from SunsetDownhill-2): HUD text, new models, drivers, LAN multiplayer

**HUD text (the "overlapping strokes / fading" problem)**
- The stroke font used to be built from many overlapping translucent quads per glyph, so any text that was not fully opaque (the
  drop shadow, the fading popups and countdown, the distance readout) showed the strokes through each other and looked patchy.
  Every glyph is now a single quad sampled from a signed-distance atlas (`ui_font.cpp`, `ui_atlas.h`): even opacity, crisp edges at
  any size, and a soft dark halo instead of the offset shadow.
- `textWidth` used to leave out the stroke thickness, so the "KM/H" label sat on top of the last digit. It now returns the exact ink
  width, and the label shares the baseline of the digits.
- `UiVertex` grew texture coordinates and a halo strength (24 bytes); the UI shader samples the atlas (`shaders.cpp`, `renderer.cpp`).

**Models**
- Rider: full-face helmet with visor, chin bar, stripe and spoiler; lofted jacket with accent band and reflective stripe; hood;
  round limbs with joint balls; knee pads; cuffs; slide gloves with pucks; skate shoes. Same rig and poses as before (`skater_model.cpp`).
  Six colour styles (one per LAN slot).
- Longboard: pintail outline with kicked nose and tail, grip tape with centre stripe, trucks (baseplate, hanger, axle, bushing) and
  glowing wheels with cores. Built once per style and re-posed with a matrix.
- Cars: five lofted body styles - sedan, hatchback, SUV, pickup, van - with wheels, rims, arches, lamps, mirrors, plates and door
  seams (`car_models.cpp`). New helpers in `model_kit.*` (loft, tube, ellipsoid); `addBlob` now caches the icosphere topology.

**Traffic**
- Cars used to drive straight through cones and rocks. `traffic.cpp` gives every car a driver: lane keeping, Intelligent Driver Model
  speed control, curve speed limit, brake lights, indicators, mirror checks, gap acceptance, steering around obstacles through free
  lanes, waiting for a gap with room to pull out, keeping clear of the rider. `tools/test_traffic`: zero overlaps with cones, rocks or
  other cars on many seeds, also with a rider weaving across both lanes.
- Cones and rocks are a pure function of the seed (cars no longer influence where they appear).

**LAN multiplayer** (see README): `net.*` (UDP protocol, polled from the game thread), `hud_mp.*` (lobby, standings, name tags,
results), engine integration, `LanSupport.kt` (multicast lock, Wi-Fi binding, device name), new permissions in the manifest.
`tools/test_net` (protocol, spoofing, garbage) and `tools/test_mp_engine` (three engines play a race through the lobby screens).

**Tools**: `test_traffic`, `test_net`, `test_mp_engine`, `render_models`, `render_traffic`, `render_lan`; `dump_ui` renders the font sheet
and the LAN screens.
