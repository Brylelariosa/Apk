@file:OptIn(ExperimentalTextApi::class)

package com.melodiq.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.R
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LyricLine

/** The few lines shown in the floating window: [lines] with the current one at [active]. */
data class LyricWindow(
    /** Changes whenever the current line changes — what the line animation reacts to. */
    val key: Int,
    val lines: List<String>,
    val active: Int
)

/**
 * Cuts [count] lines (1..5) out of the lyrics around [activeIndex]. Missing neighbours at the start
 * or end of the song are blank lines, so the window keeps the same height all the time.
 * Before the first line the current line shows a note symbol.
 */
fun buildLyricWindow(lines: List<LyricLine>, activeIndex: Int, count: Int): LyricWindow {
    val timedCount = lines.count { it.isTimed }
    val total  = count.coerceIn(1, 5)
    val before = (total - 1) / 2
    val after  = total - 1 - before

    val texts = ArrayList<String>(total)
    var activePosition = 0
    for (i in (activeIndex - before)..(activeIndex + after)) {
        if (i == activeIndex) activePosition = texts.size
        val text = when {
            i in 0 until timedCount -> lines[i].text
            i == activeIndex        -> "♪"
            else                    -> " "
        }
        texts.add(text)
    }
    return LyricWindow(key = activeIndex, lines = texts, active = activePosition)
}

// ── One height for the whole song ────────────────────────────────────────────
//
// The floating window is as tall as its content (WRAP_CONTENT), so every change of the content's height
// is a real resize of an Android window: the background grew and shrank with every long line, and the
// resize happened frame by frame while the line animation ran, which looked like flicker. So the card
// never lets the words decide its height any more:
//
//  - every line has a row of a fixed height (text size x ROW_HEIGHT_FACTOR); the lines around the sung
//    one get one row, the sung line gets one row or two, the same for the WHOLE song;
//  - a line that is too long for its rows is drawn a little smaller until it fits (never below 70 %),
//    and only what still does not fit is cut off with "…";
//  - when the line changes the window size is not animated, only the text.

/** Height of a row compared to its text size. */
private const val ROW_HEIGHT_FACTOR = 1.25f

/** The lines around the sung one are drawn a little smaller. */
private const val NEIGHBOUR_SCALE = 0.82f

/** Sizes tried, biggest first, to make a line fit its rows (1 = the size set in Settings). */
private val FIT_STEPS = floatArrayOf(1f, 0.9f, 0.8f, 0.7f)

/**
 * The smallest size a line may be shrunk to when it only has ONE row. A song gets two rows for its sung
 * line as soon as one of its lines needs more than this.
 */
private const val ONE_ROW_MIN_SCALE = 0.8f

/** No glyph is wider than this many times the text size (full-width letters are the widest). */
private const val WIDEST_GLYPH_EM = 1.2f

private val RowLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim      = LineHeightStyle.Trim.None
)

/** The style that decides how a line breaks. The same one measures a line and draws it. */
private fun rowStyle(family: FontFamily, weight: FontWeight, sizeSp: Float): TextStyle = TextStyle(
    fontFamily      = family,
    fontWeight      = weight,
    fontSize        = sizeSp.sp,
    lineHeight      = (sizeSp * ROW_HEIGHT_FACTOR).sp,
    lineHeightStyle = RowLineHeight
)

/** How many lines [text] takes in a row [availablePx] wide. */
private fun lineCountOf(measurer: TextMeasurer, text: String, style: TextStyle, availablePx: Int): Int =
    measurer.measure(
        text        = AnnotatedString(text),
        style       = style,
        constraints = Constraints(maxWidth = availablePx)
    ).lineCount

/**
 * The biggest size at which [text] fits in [rows] rows: [baseSp] itself, then smaller, but never below
 * [minScale] times [baseSp]. A line that does not fit even then gets the smallest size and is cut off.
 */
private fun fitSizeSp(
    measurer: TextMeasurer,
    text: String,
    family: FontFamily,
    weight: FontWeight,
    baseSp: Float,
    rows: Int,
    minScale: Float,
    availablePx: Int
): Float {
    if (text.isBlank() || availablePx <= 0) return baseSp
    for (scale in FIT_STEPS) {
        if (scale < minScale) break
        val sizeSp = baseSp * scale
        if (lineCountOf(measurer, text, rowStyle(family, weight, sizeSp), availablePx) <= rows) return sizeSp
    }
    return baseSp * minScale
}

/**
 * How many rows the sung line gets in this song: 1, or 2 when some line is too long for one row even
 * when drawn at [ONE_ROW_MIN_SCALE]. It looks at the whole song, so the answer — and with it the height
 * of the card — does not change while the song plays. It stops at the first long line, and lines too
 * short to fill a row are not even measured.
 */
private fun sungRowsOf(
    measurer: TextMeasurer,
    texts: List<String>,
    family: FontFamily,
    weight: FontWeight,
    baseSp: Float,
    availablePx: Int,
    density: Density
): Int {
    if (availablePx <= 0) return 1
    val probeSp = baseSp * ONE_ROW_MIN_SCALE
    val probe = rowStyle(family, weight, probeSp)
    val widestGlyphPx = with(density) { probeSp.sp.toPx() } * WIDEST_GLYPH_EM
    val surelyFits = (availablePx / widestGlyphPx).toInt()
    for (text in texts) {
        if (text.length <= surelyFits) continue
        if (lineCountOf(measurer, text, probe, availablePx) > 1) return 2
    }
    return 1
}

/**
 * The floating lyrics window: a rounded card with the lines, an optional title and optional
 * playback buttons. The same composable draws the real window (inside the music service) and the
 * live preview in Settings, so the preview is exactly what you get.
 *
 * [songLines] are all the lines of the song (not only the few in [window]): they decide how many rows the
 * sung line gets, so the card has the same height from the first line to the last (see above).
 */
@Composable
fun FloatingLyricsCard(
    window: LyricWindow,
    settings: FloatingLyricsSettings,
    modifier: Modifier = Modifier,
    title: String? = null,
    isPlaying: Boolean = true,
    songLines: List<String> = window.lines,
    onPrevious: () -> Unit = {},
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {}
) {
    val shape = RoundedCornerShape(settings.cornerRadiusDp.dp)
    val textColor = Color(settings.textColor)
    val duration = settings.animationMs
    val measurer = rememberTextMeasurer(cacheSize = 24)

    Column(
        modifier = modifier
            .alpha(settings.windowAlpha)
            .clip(shape)
            .background(Color(settings.backgroundColor).copy(alpha = settings.backgroundAlpha))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = settings.alignment.toHorizontal()
    ) {
        if (title != null) {
            Text(
                text     = title,
                color    = textColor.copy(alpha = 0.6f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
        }

        // The width the words get is needed to know which lines are too long, so measure it here.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val availablePx = if (constraints.hasBoundedWidth) constraints.maxWidth else 0
            val density = LocalDensity.current
            val family = settings.font.toFontFamily()
            val weight = settings.weight.toFontWeight()
            val sungRows = remember(songLines, availablePx, settings.textSizeSp, family, weight, density) {
                sungRowsOf(measurer, songLines, family, weight, settings.textSizeSp, availablePx, density)
            }

            AnimatedContent(
                targetState = window,
                transitionSpec = {
                    val change = when (settings.animation) {
                        LineAnimation.NONE ->
                            EnterTransition.None togetherWith ExitTransition.None
                        LineAnimation.FADE ->
                            fadeIn(tween(duration)) togetherWith fadeOut(tween(duration))
                        LineAnimation.SLIDE ->
                            (slideInVertically(tween(duration)) { it / 2 } + fadeIn(tween(duration))) togetherWith
                                (slideOutVertically(tween(duration)) { -it / 2 } + fadeOut(tween(duration)))
                        LineAnimation.POP ->
                            (scaleIn(tween(duration), initialScale = 0.85f) + fadeIn(tween(duration))) togetherWith
                                (scaleOut(tween(duration), targetScale = 1.1f) + fadeOut(tween(duration)))
                    }
                    // Only the text moves. The size of the window is never animated: that would resize an
                    // Android window on every frame.
                    change using SizeTransform(clip = true) { _, _ -> snap() }
                },
                label = "floating_lyrics"
            ) { shown ->
                LyricLines(
                    window      = shown,
                    settings    = settings,
                    sungRows    = sungRows,
                    availablePx = availablePx,
                    measurer    = measurer
                )
            }
        }

        if (settings.showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconActionButton(
                    icon = R.drawable.ic_skip_previous,
                    contentDescription = "Previous song",
                    onClick = onPrevious,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
                IconActionButton(
                    icon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    tint = textColor,
                    buttonSize = 44.dp,
                    iconSize = 26.dp
                )
                IconActionButton(
                    icon = R.drawable.ic_skip_next,
                    contentDescription = "Next song",
                    onClick = onNext,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
            }
        }
    }
}

@Composable
private fun LyricLines(
    window: LyricWindow,
    settings: FloatingLyricsSettings,
    sungRows: Int,
    availablePx: Int,
    measurer: TextMeasurer
) {
    Column(horizontalAlignment = settings.alignment.toHorizontal()) {
        window.lines.forEachIndexed { index, text ->
            val sung = index == window.active
            FloatingLyricRow(
                text        = text,
                sung        = sung,
                settings    = settings,
                rows        = if (sung) sungRows else 1,
                availablePx = availablePx,
                measurer    = measurer
            )
        }
    }
}

/** One line in a row of its own: [rows] rows tall whatever the words are, the text fitted into it. */
@Composable
private fun FloatingLyricRow(
    text: String,
    sung: Boolean,
    settings: FloatingLyricsSettings,
    rows: Int,
    availablePx: Int,
    measurer: TextMeasurer
) {
    val density = LocalDensity.current
    val family = settings.font.toFontFamily()
    val weight = if (sung) settings.weight.toFontWeight() else FontWeight.Normal
    val baseSp = if (sung) settings.textSizeSp else settings.textSizeSp * NEIGHBOUR_SCALE
    // A song with two rows may shrink a long line further; with one row every line fits at 80 % already.
    val minScale = if (rows > 1) FIT_STEPS.last() else ONE_ROW_MIN_SCALE
    val sizeSp = remember(text, family, weight, baseSp, rows, minScale, availablePx, density) {
        fitSizeSp(measurer, text, family, weight, baseSp, rows, minScale, availablePx)
    }

    val color  = Color(settings.textColor)
    val shadow = if (settings.textShadow) {
        Shadow(color = Color.Black.copy(alpha = 0.85f), offset = Offset(0f, 2f), blurRadius = 6f)
    } else {
        null
    }
    val style = rowStyle(family, weight, sizeSp).copy(
        color     = if (sung) color else color.copy(alpha = color.alpha * settings.inactiveAlpha),
        textAlign = settings.alignment.toTextAlign(),
        shadow    = shadow
    )
    // The row's height comes from the size set in Settings, not from the fitted one, so it never changes.
    val rowHeight = with(density) { (baseSp * ROW_HEIGHT_FACTOR * rows).sp.toDp() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .height(rowHeight),
        contentAlignment = Alignment.Center
    ) {
        BasicText(
            text     = text,
            style    = style,
            overflow = TextOverflow.Ellipsis,
            maxLines = rows,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
