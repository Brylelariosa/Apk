//! Value network: sparse piece features -> h1 -> h2 -> 1 (ReLU). Port of core/net.cpp.
//!
//! The input has exactly one active feature per piece slot (see encoder.rs), so the first layer is the sum of a
//! few weight rows. The output is the estimated number of moves to the solved puzzle divided by VALUE_SCALE. All
//! parameters live in one flat float array so copying, Adam updates and checkpoints are trivial.

use crate::encoder::Encoder;
use crate::puzzle::Puzzle;
use crate::rng::Rng;

pub const MAX_H1: usize = 256;
pub const MAX_H2: usize = 128;
pub const VALUE_SCALE: f32 = 10.0;

#[derive(Clone, Default)]
pub struct NetSpec {
    pub n_feat: usize,
    pub h1: usize,
    pub h2: usize,
    pub active: usize,
    pub off_w1: usize,
    pub off_b1: usize,
    pub off_w2: usize,
    pub off_b2: usize,
    pub off_w3: usize,
    pub off_b3: usize,
    pub count: usize,
}

impl NetSpec {
    pub fn new(features: usize, hidden1: usize, hidden2: usize, active_features: usize) -> NetSpec {
        let mut s = NetSpec {
            n_feat: features,
            h1: hidden1,
            h2: hidden2,
            active: if active_features > 0 { active_features } else { 1 },
            ..Default::default()
        };
        let sane = features > 0
            && hidden1 > 0
            && hidden1 <= MAX_H1
            && hidden1 % 4 == 0
            && hidden2 > 0
            && hidden2 <= MAX_H2
            && hidden2 % 4 == 0;
        if !sane {
            s.n_feat = 0;
            return s;
        }
        let mut o = 0usize;
        s.off_w1 = o;
        o += s.n_feat * s.h1;
        s.off_b1 = o;
        o += s.h1;
        s.off_w2 = o;
        o += s.h1 * s.h2;
        s.off_b2 = o;
        o += s.h2;
        s.off_w3 = o;
        o += s.h2;
        s.off_b3 = o;
        o += 1;
        s.count = o;
        s
    }
}

/// Everything the learned solver needs for one puzzle.
pub struct Model {
    pub puzzle: &'static Puzzle,
    pub enc: Encoder,
    pub spec: NetSpec,
}

impl Model {
    pub fn new(p: &'static Puzzle) -> Model {
        let enc = Encoder::new(p);
        let spec = NetSpec::new(enc.features(), p.hidden1, p.hidden2, enc.active());
        Model { puzzle: p, enc, spec }
    }
    pub fn ok(&self) -> bool {
        self.enc.ok() && self.spec.n_feat > 0
    }
}

pub struct Activations {
    pub z1: [f32; MAX_H1],
    pub a1: [f32; MAX_H1],
    pub z2: [f32; MAX_H2],
    pub a2: [f32; MAX_H2],
    pub act: [usize; MAX_H1], // indices of the positive first-layer units
    pub n_act: usize,
}

impl Activations {
    pub fn new() -> Activations {
        Activations {
            z1: [0.0; MAX_H1],
            a1: [0.0; MAX_H1],
            z2: [0.0; MAX_H2],
            a2: [0.0; MAX_H2],
            act: [0; MAX_H1],
            n_act: 0,
        }
    }
}

pub fn init_params(sp: &NetSpec, p: &mut Vec<f32>, rng: &mut Rng) {
    p.clear();
    p.resize(sp.count, 0.0);
    // The first layer sums `active` rows, so scale rows by 1/sqrt(active).
    let s1 = 0.67 / (sp.active as f32).sqrt();
    let s2 = (2.0 / sp.h1 as f32).sqrt();
    let s3 = 0.02f32;
    for i in 0..(sp.n_feat * sp.h1) {
        p[sp.off_w1 + i] = rng.gaussian() * s1;
    }
    for i in 0..(sp.h1 * sp.h2) {
        p[sp.off_w2 + i] = rng.gaussian() * s2;
    }
    for i in 0..sp.h2 {
        p[sp.off_w3 + i] = rng.gaussian() * s3;
    }
}

/// Returns the raw network output (before VALUE_SCALE).
pub fn forward(sp: &NetSpec, p: &[f32], feats: &[usize], nf: usize, a: &mut Activations) -> f32 {
    let h1 = sp.h1;
    let h2 = sp.h2;

    for i in 0..h1 {
        a.z1[i] = p[sp.off_b1 + i];
    }
    for k in 0..nf {
        let base = sp.off_w1 + feats[k] * h1;
        let w = &p[base..base + h1];
        for i in 0..h1 {
            a.z1[i] += w[i];
        }
    }
    let mut na = 0usize;
    for i in 0..h1 {
        let v = a.z1[i];
        a.a1[i] = if v > 0.0 { v } else { 0.0 };
        a.act[na] = i;
        if v > 0.0 {
            na += 1;
        }
    }
    a.n_act = na;

    for j in 0..h2 {
        a.z2[j] = p[sp.off_b2 + j];
    }
    for t in 0..na {
        let i = a.act[t];
        let x = a.a1[i];
        let base = sp.off_w2 + i * h2;
        let row = &p[base..base + h2];
        for j in 0..h2 {
            a.z2[j] += x * row[j];
        }
    }

    let mut s = 0.0f32;
    for j in 0..h2 {
        let v = if a.z2[j] > 0.0 { a.z2[j] } else { 0.0 };
        a.a2[j] = v;
        s += v * p[sp.off_w3 + j];
    }
    p[sp.off_b3] + s
}

/// Accumulates d(loss)/d(params) into g given d(loss)/d(raw output).
pub fn backward(sp: &NetSpec, p: &[f32], g: &mut [f32], feats: &[usize], nf: usize, a: &Activations, d_out: f32) {
    let h1 = sp.h1;
    let h2 = sp.h2;

    g[sp.off_b3] += d_out;
    let mut dz2 = [0.0f32; MAX_H2];
    for j in 0..h2 {
        g[sp.off_w3 + j] += d_out * a.a2[j];
        let d = if a.z2[j] > 0.0 { d_out * p[sp.off_w3 + j] } else { 0.0 };
        dz2[j] = d;
        g[sp.off_b2 + j] += d;
    }

    let mut dz1 = [0.0f32; MAX_H1];
    for t in 0..a.n_act {
        let i = a.act[t];
        let x = a.a1[i];
        let base = sp.off_w2 + i * h2;
        let mut s = 0.0f32;
        for j in 0..h2 {
            s += p[base + j] * dz2[j];
            g[base + j] += x * dz2[j];
        }
        dz1[i] = s;
    }

    for i in 0..h1 {
        g[sp.off_b1 + i] += dz1[i];
    }
    for k in 0..nf {
        let base = sp.off_w1 + feats[k] * h1;
        for i in 0..h1 {
            g[base + i] += dz1[i];
        }
    }
}

/// Estimated cost-to-go in moves for a state that is known not to be solved (never negative).
pub fn value_of(m: &Model, params: &[f32], state: &[u8]) -> f32 {
    let mut feats = [0usize; 64];
    let n = m.enc.encode(state, &mut feats);
    if n < 0 {
        return 1.0e6; // not a valid arrangement of the pieces
    }
    let mut act = Activations::new();
    let v = forward(&m.spec, params, &feats, n as usize, &mut act) * VALUE_SCALE;
    if v > 0.0 {
        v
    } else {
        0.0
    }
}

/// Same, but exactly 0 for a solved state.
pub fn estimate_cost(m: &Model, params: &[f32], state: &[u8]) -> f32 {
    if m.puzzle.is_solved(state) {
        return 0.0;
    }
    value_of(m, params, state)
}
