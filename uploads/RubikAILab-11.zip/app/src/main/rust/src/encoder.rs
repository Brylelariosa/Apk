//! Turns a puzzle state into sparse network input (port of core/encoder.cpp).
//!
//! Every piece position ("slot") that the solver's moves can change contributes exactly one active feature:
//! "piece P sits in slot S with orientation O". Pieces of one orbit class are told apart by the set of colours
//! they carry in the solved puzzle, so that set must be unique inside a class.

use crate::puzzle::Puzzle;

#[derive(Clone)]
struct Cls {
    pieces: usize,   // slots (= pieces) in the class
    k: usize,        // stickers per piece
    non_fixed: usize, // slots that take part in the encoding
    offset: usize,   // first feature index
    max_moved: usize,
    piece_of_mask: [i8; 64],
    ref_color: [u8; 64], // reference colour of each piece (lowest colour of its solved set)
}

#[derive(Clone, Default)]
struct Enc {
    cls: usize,
    local: usize, // index among the class's non-fixed slots
    n: usize,
    st: [usize; 3],
    solved_feature: usize,
}

pub struct Encoder {
    ok: bool,
    features: usize,
    active: usize,
    classes: Vec<Cls>,
    slots: Vec<Enc>,
}

impl Encoder {
    pub fn new(p: &Puzzle) -> Encoder {
        let mut e = Encoder { ok: false, features: 0, active: 0, classes: Vec::new(), slots: Vec::new() };
        if !p.valid || !p.ai_supported {
            return e;
        }
        let n_classes = p.class_count;
        let mut classes: Vec<Cls> = vec![
            Cls {
                pieces: 0,
                k: 0,
                non_fixed: 0,
                offset: 0,
                max_moved: 1,
                piece_of_mask: [-1; 64],
                ref_color: [0; 64],
            };
            n_classes
        ];
        let mut class_slots: Vec<Vec<usize>> = vec![Vec::new(); n_classes];
        for (s, slot) in p.slots.iter().enumerate() {
            class_slots[slot.cls].push(s);
        }

        for c in 0..n_classes {
            let members = &class_slots[c];
            let cl = &mut classes[c];
            cl.pieces = members.len();
            cl.k = p.slots[members[0]].n;
            for pi in 0..cl.pieces {
                let slot = &p.slots[members[pi]];
                let mut mask = 0usize;
                for k in 0..slot.n {
                    mask |= 1 << p.solved[slot.stickers[k]];
                }
                if cl.piece_of_mask[mask] >= 0 {
                    return e; // two pieces of a class carry the same colours
                }
                cl.piece_of_mask[mask] = pi as i8;
                let mut r = 0usize;
                while ((mask >> r) & 1) == 0 {
                    r += 1;
                }
                cl.ref_color[pi] = r as u8;
            }
            for &s in members.iter() {
                if !p.slot_fixed[s] {
                    cl.non_fixed += 1;
                }
            }
        }

        let mut offset = 0usize;
        for cl in classes.iter_mut() {
            cl.offset = offset;
            offset += cl.non_fixed * cl.pieces * cl.k;
        }
        e.features = offset;

        let mut counter = vec![0usize; n_classes];
        for (s, slot) in p.slots.iter().enumerate() {
            if p.slot_fixed[s] {
                continue;
            }
            let mut en = Enc::default();
            en.cls = slot.cls;
            en.local = counter[slot.cls];
            counter[slot.cls] += 1;
            en.n = slot.n;
            for k in 0..slot.n {
                en.st[k] = slot.stickers[k];
            }
            e.slots.push(en);
        }
        e.active = e.slots.len();
        e.classes = classes;

        // Features of the solved puzzle, used to count misplaced pieces.
        let mut feats = [0usize; 64];
        e.ok = true;
        if e.encode(&p.solved, &mut feats) != e.active as i32 {
            e.ok = false;
            return e;
        }
        for i in 0..e.active {
            e.slots[i].solved_feature = feats[i];
        }

        // How many pieces of each class can one solver move change?
        for c in 0..n_classes {
            let mut best = 1usize;
            for &m in p.ai_moves.iter() {
                let pm = &p.perm[m];
                let mut touched = 0usize;
                for (s, slot) in p.slots.iter().enumerate() {
                    if slot.cls != c || p.slot_fixed[s] {
                        continue;
                    }
                    for k in 0..slot.n {
                        if pm[slot.stickers[k]] as usize != slot.stickers[k] {
                            touched += 1;
                            break;
                        }
                    }
                }
                if touched > best {
                    best = touched;
                }
            }
            e.classes[c].max_moved = best;
        }
        e
    }

    pub fn ok(&self) -> bool {
        self.ok
    }
    pub fn features(&self) -> usize {
        self.features
    }
    pub fn active(&self) -> usize {
        self.active
    }
    pub fn classes(&self) -> usize {
        self.classes.len()
    }
    pub fn max_moved(&self, cls: usize) -> usize {
        self.classes[cls].max_moved
    }

    /// Writes one feature index per active slot. Returns active(), or -1 when the colours are not a valid
    /// arrangement of the puzzle's pieces.
    pub fn encode(&self, s: &[u8], out: &mut [usize]) -> i32 {
        let mut n = 0usize;
        for e in self.slots.iter() {
            let cl = &self.classes[e.cls];
            let mut mask = 0usize;
            let mut c = [0u8; 3];
            for k in 0..e.n {
                c[k] = s[e.st[k]];
                if c[k] > 5 {
                    return -1;
                }
                mask |= 1 << c[k];
            }
            let piece = cl.piece_of_mask[mask];
            if piece < 0 {
                return -1;
            }
            let piece = piece as usize;
            let mut ori = 0usize;
            if e.n > 1 {
                let r = cl.ref_color[piece];
                let mut found: i32 = -1;
                for k in 0..e.n {
                    if c[k] == r {
                        found = k as i32;
                    }
                }
                if found < 0 {
                    return -1;
                }
                ori = found as usize;
            }
            out[n] = cl.offset + (e.local * cl.pieces + piece) * cl.k + ori;
            n += 1;
        }
        n as i32
    }

    /// Number of pieces not at home, per class (wrong[classes()]). Returns the total, -1 when invalid.
    pub fn misplaced(&self, s: &[u8], wrong: &mut [usize]) -> i32 {
        let mut feats = [0usize; 64];
        let n = self.encode(s, &mut feats);
        if n < 0 {
            return -1;
        }
        for c in 0..self.classes.len() {
            wrong[c] = 0;
        }
        let mut total = 0;
        for i in 0..n as usize {
            if feats[i] != self.slots[i].solved_feature {
                wrong[self.slots[i].cls] += 1;
                total += 1;
            }
        }
        total
    }
}
