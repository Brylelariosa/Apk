//! Weighted A* search over puzzle states, with pluggable heuristics (port of core/search.cpp).
//!
//!   f(n) = lambda * g(n) + h(n)
//!
//! lambda = 1 is classic A*, smaller values trade solution length for speed (lambda = 0 is greedy). The search
//! only ever sees the colours of the stickers: it has no idea how the puzzle was scrambled.

use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap};
use std::sync::atomic::{AtomicBool, Ordering as AtomicOrdering};
use std::time::Instant;

use crate::net::{estimate_cost, Model};
use crate::puzzle::K_MAX_AI_STICKERS;

pub trait Heuristic {
    fn estimate(&self, state: &[u8]) -> f32;
}

/// Learned heuristic: the value network.
pub struct NetHeuristic<'a> {
    pub model: &'a Model,
    pub params: &'a [f32],
}

impl<'a> Heuristic for NetHeuristic<'a> {
    fn estimate(&self, state: &[u8]) -> f32 {
        estimate_cost(self.model, self.params, state)
    }
}

/// Conventional baseline (no learning): one move changes at most max_moved(c) pieces of class c, so
/// ceil(wrong pieces of c / max_moved(c)) is an admissible lower bound; use the largest over all classes.
pub struct MisplacedHeuristic<'a> {
    pub model: &'a Model,
}

impl<'a> Heuristic for MisplacedHeuristic<'a> {
    fn estimate(&self, state: &[u8]) -> f32 {
        let mut wrong = [0usize; 64];
        if self.model.enc.misplaced(state, &mut wrong) < 0 {
            return 1.0e6;
        }
        let mut best = 0usize;
        for c in 0..self.model.enc.classes() {
            let per = self.model.enc.max_moved(c);
            let h = (wrong[c] + per - 1) / per;
            if h > best {
                best = h;
            }
        }
        best as f32
    }
}

pub const K_SOLVED: i32 = 0;
pub const K_NODE_LIMIT: i32 = 1;
pub const K_TIMEOUT: i32 = 2;
pub const K_CANCELLED: i32 = 3;
pub const K_INVALID: i32 = 4;

#[derive(Clone, Copy)]
pub struct SearchConfig {
    pub max_expansions: i32,
    pub max_nodes: i32,
    pub lambda: f32,
    pub timeout_ms: i32,
}

impl Default for SearchConfig {
    fn default() -> Self {
        SearchConfig { max_expansions: 20000, max_nodes: 400000, lambda: 0.6, timeout_ms: 20000 }
    }
}

#[derive(Clone, Default)]
pub struct SearchResult {
    pub status: i32,
    pub expanded: i32,
    pub generated: i32,
    pub elapsed_ms: i32,
    pub moves: Vec<u8>, // move indices, in the order they must be applied
}

#[derive(Clone, Copy)]
struct Node {
    s: [u8; K_MAX_AI_STICKERS],
    mv: i8,
    g: i16,
    parent: i32,
    hash: u64,
}

#[derive(Clone, Copy)]
struct Item {
    f: f32,
    idx: i32,
}

impl PartialEq for Item {
    fn eq(&self, o: &Item) -> bool {
        self.f == o.f && self.idx == o.idx
    }
}
impl Eq for Item {}
impl PartialOrd for Item {
    fn partial_cmp(&self, o: &Item) -> Option<Ordering> {
        Some(self.cmp(o))
    }
}
// BinaryHeap pops the greatest element: the smallest f is "greatest"; ties prefer newer nodes.
impl Ord for Item {
    fn cmp(&self, o: &Item) -> Ordering {
        match o.f.partial_cmp(&self.f) {
            Some(Ordering::Equal) | None => self.idx.cmp(&o.idx),
            Some(ord) => ord,
        }
    }
}

pub fn solve_weighted_astar(
    model: &Model,
    start: &[u8],
    heuristic: &dyn Heuristic,
    cfg: &SearchConfig,
    cancel: &AtomicBool,
) -> SearchResult {
    let mut res = SearchResult::default();
    let pz = model.puzzle;
    let t0 = Instant::now();
    let elapsed_ms = || t0.elapsed().as_millis() as i32;

    let mut probe = [0usize; 64];
    if pz.stickers > K_MAX_AI_STICKERS || model.enc.encode(start, &mut probe) < 0 {
        res.status = K_INVALID;
        return res;
    }
    if pz.is_solved(start) {
        res.status = K_SOLVED;
        return res;
    }

    let mut nodes: Vec<Node> = Vec::with_capacity(4096);
    let mut best: HashMap<u64, i16> = HashMap::with_capacity(4096);
    let mut open: BinaryHeap<Item> = BinaryHeap::new();

    let mut root = Node { s: [0u8; K_MAX_AI_STICKERS], mv: -1, g: 0, parent: -1, hash: 0 };
    root.s[..pz.stickers].copy_from_slice(&start[..pz.stickers]);
    root.hash = pz.hash(start);
    best.insert(root.hash, 0);
    open.push(Item { f: heuristic.estimate(&root.s), idx: 0 });
    nodes.push(root);

    res.status = K_NODE_LIMIT;
    let mut finished = false;
    while !finished {
        let top = match open.pop() {
            Some(t) => t,
            None => break,
        };
        if (res.expanded & 15) == 0 {
            if cancel.load(AtomicOrdering::Relaxed) {
                res.status = K_CANCELLED;
                break;
            }
            if elapsed_ms() > cfg.timeout_ms {
                res.status = K_TIMEOUT;
                break;
            }
        }

        let cur = nodes[top.idx as usize]; // copy: push below may reallocate
        if let Some(&known) = best.get(&cur.hash) {
            if known < cur.g {
                continue; // a cheaper path to this state exists
            }
        }
        if res.expanded >= cfg.max_expansions {
            res.status = K_NODE_LIMIT;
            break;
        }
        res.expanded += 1;

        for &m in pz.ai_moves.iter() {
            if cur.mv >= 0 && m as i32 == ((cur.mv as i32) ^ 1) {
                continue; // never undo the previous move
            }
            let mut child = Node { s: [0u8; K_MAX_AI_STICKERS], mv: m as i8, g: cur.g + 1, parent: top.idx, hash: 0 };
            pz.apply(&cur.s, &mut child.s, m);
            child.hash = pz.hash(&child.s);

            if pz.is_solved(&child.s) {
                let mut reversed: Vec<u8> = vec![m as u8];
                let mut i = top.idx;
                while i >= 0 && nodes[i as usize].mv >= 0 {
                    reversed.push(nodes[i as usize].mv as u8);
                    i = nodes[i as usize].parent;
                }
                reversed.reverse();
                res.moves = reversed;
                res.status = K_SOLVED;
                finished = true;
                break;
            }

            if let Some(&seen) = best.get(&child.hash) {
                if seen <= child.g {
                    continue;
                }
            }
            if nodes.len() as i32 >= cfg.max_nodes {
                res.status = K_NODE_LIMIT;
                finished = true;
                break;
            }
            best.insert(child.hash, child.g);
            let h = heuristic.estimate(&child.s);
            let f = cfg.lambda * child.g as f32 + h;
            nodes.push(child);
            open.push(Item { f, idx: nodes.len() as i32 - 1 });
            res.generated += 1;
        }
    }

    res.elapsed_ms = elapsed_ms();
    res
}
