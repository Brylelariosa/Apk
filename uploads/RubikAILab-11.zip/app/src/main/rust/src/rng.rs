//! Small deterministic random generator (SplitMix64). Identical results on every ABI.

#[derive(Clone)]
pub struct Rng {
    state: u64,
}

impl Default for Rng {
    fn default() -> Self {
        Rng::new(0x9E37_79B9_7F4A_7C15)
    }
}

impl Rng {
    pub fn new(seed: u64) -> Rng {
        let mut r = Rng { state: 0 };
        r.reseed(seed);
        r
    }

    pub fn reseed(&mut self, seed: u64) {
        self.state = seed ^ 0xD1B5_4A32_D192_ED03;
        self.next();
        self.next();
    }

    /// Raw generator state, so a checkpoint can resume the exact random stream.
    pub fn state(&self) -> u64 {
        self.state
    }

    pub fn set_state(&mut self, state: u64) {
        self.state = state;
    }

    pub fn next(&mut self) -> u64 {
        self.state = self.state.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }

    /// Uniform integer in [0, n). n must be > 0.
    pub fn below(&mut self, n: u32) -> u32 {
        (((self.next() >> 32) * n as u64) >> 32) as u32
    }

    /// Uniform float in [0, 1).
    pub fn uniform(&mut self) -> f32 {
        (self.next() >> 40) as f32 * (1.0 / 16_777_216.0)
    }

    /// Standard normal (Box-Muller).
    pub fn gaussian(&mut self) -> f32 {
        let mut u1 = self.uniform();
        if u1 < 1e-7 {
            u1 = 1e-7;
        }
        let u2 = self.uniform();
        (-2.0 * u1.ln()).sqrt() * (6.283_185_3 * u2).cos()
    }
}
