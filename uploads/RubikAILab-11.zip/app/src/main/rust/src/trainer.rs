//! Approximate value iteration trainer (port of core/trainer.cpp).
//!
//!   target(s) = 0                         if s is solved
//!             = 1 + min_m J_target(m(s))  otherwise
//!
//! J is the value network. The learner never sees how a puzzle was scrambled, only the colours of the stickers:
//! the training label of a state comes from the puzzle rules and the lagging target network, never from the
//! scramble that produced it, so there is no "reverse the scramble" shortcut anywhere.
//!
//! Each training round works on a pool of random states:
//!   1. fill: draw states, compute their targets once with the frozen target network;
//!   2. fit: several epochs of minibatch Adam over that pool;
//!   3. the target network is refreshed and the scramble depth range grows once the fit is good enough.

use std::collections::HashSet;
use std::fs::File;
use std::io::{Read, Write};
use std::sync::Arc;
use std::time::Instant;

use crate::net::{backward, forward, init_params, value_of, Activations, Model, VALUE_SCALE};
use crate::puzzle::{Puzzle, K_MAX_AI_STICKERS};
use crate::rng::Rng;

/// Random walk from the solved puzzle using the solver's moves (never undoes the previous move, never turns the
/// same layer three times in a row). `out` must hold at least `stickers` bytes.
pub fn random_scramble(pz: &Puzzle, rng: &mut Rng, depth: i32, out: &mut [u8]) {
    pz.set_solved(out);
    let mut tmp = [0u8; K_MAX_AI_STICKERS];
    let mut prev: i32 = -1;
    let mut prev2: i32 = -1;
    let n = pz.ai_moves.len() as u32;
    for _ in 0..depth {
        let mut m: i32;
        loop {
            m = pz.ai_moves[rng.below(n) as usize] as i32;
            if !(prev >= 0 && (m == (prev ^ 1) || (m == prev && prev2 == prev))) {
                break;
            }
        }
        pz.apply(out, &mut tmp, m as usize);
        out[..pz.stickers].copy_from_slice(&tmp[..pz.stickers]);
        prev2 = prev;
        prev = m;
    }
}

/// Fixed, reproducible test scrambles (depth 1..MAX_DEPTH, PER_DEPTH each). Every test state with a scramble
/// length of at least MIN_EXCLUDED_DEPTH is excluded from the training distribution, whichever scramble depth
/// would have produced it.
pub struct TestSet {
    puzzle: &'static Puzzle,
    states: Vec<u8>,
    held_out: HashSet<u64>,
}

impl TestSet {
    pub const MAX_DEPTH: i32 = 20;
    pub const PER_DEPTH: i32 = 50;
    pub const MIN_EXCLUDED_DEPTH: i32 = 5;

    pub fn new(pz: &'static Puzzle) -> TestSet {
        let stride = pz.stickers;
        let per = Self::PER_DEPTH as usize;
        let mut states = vec![0u8; Self::MAX_DEPTH as usize * per * stride];
        let mut held_out: HashSet<u64> = HashSet::new();
        for d in 1..=Self::MAX_DEPTH {
            for i in 0..Self::PER_DEPTH {
                let off = ((d - 1) as usize * per + i as usize) * stride;
                let dst = &mut states[off..off + stride];
                let seed = 0x7E57_5EEDu64
                    .wrapping_add(d as u64 * 1_000_003)
                    .wrapping_add(i as u64 * 7919)
                    .wrapping_add(pz.id as u64 * 104_729);
                let mut rng = Rng::new(seed);
                for _ in 0..16 {
                    random_scramble(pz, &mut rng, d, dst);
                    if !pz.is_solved(dst) {
                        break;
                    }
                }
                if d >= Self::MIN_EXCLUDED_DEPTH {
                    held_out.insert(pz.hash(dst));
                }
            }
        }
        TestSet { puzzle: pz, states, held_out }
    }

    pub fn state(&self, depth: i32, index: i32) -> &[u8] {
        let d = depth.clamp(1, Self::MAX_DEPTH);
        let i = index.clamp(0, Self::PER_DEPTH - 1);
        let stride = self.puzzle.stickers;
        let off = ((d - 1) as usize * Self::PER_DEPTH as usize + i as usize) * stride;
        &self.states[off..off + stride]
    }

    pub fn is_held_out(&self, hash: u64) -> bool {
        self.held_out.contains(&hash)
    }
}

#[derive(Clone, Copy)]
pub struct TrainConfig {
    pub batch: i32,
    pub lr: f32,
    pub max_depth: i32,
    pub threads: i32,
    pub start_depth: i32,
    pub pool: i32,           // states per round
    pub min_epochs: i32,     // fit at least this many passes over the pool ...
    pub max_epochs: i32,     // ... and at most this many
    pub acc_threshold: f32,  // fraction of states within 0.5 moves of their target
    pub frontier_mix: f32,   // share of states drawn at the newest depths
}

impl Default for TrainConfig {
    fn default() -> Self {
        TrainConfig {
            batch: 256,
            lr: 1.0e-3,
            max_depth: 12,
            threads: 1,
            start_depth: 3,
            pool: 8192,
            min_epochs: 2,
            max_epochs: 4,
            acc_threshold: 0.85,
            frontier_mix: 0.3,
        }
    }
}

#[derive(Clone, Copy, Default)]
pub struct TrainStats {
    pub steps: i64,
    pub samples: i64,
    pub iterations: i32,
    pub depth: i32,
    pub loss: f32,
    pub mae: f32,
    pub accuracy: f32,
    pub samples_per_sec: f32,
    pub lr: f32,
    pub phase: i32,      // 0 = computing targets, 1 = fitting the network
    pub progress: f32,   // 0..1 within the current round
    pub epoch: i32,
    pub threads: i32,
    pub batch: i32,
    pub pool: i32,
    pub max_depth: i32,
    pub chunk_steps: i32,
}

#[derive(Default)]
struct Worker {
    grad: Vec<f32>,
    rng: Rng,
    loss_sum: f64,
    abs_sum: f64,
    hits: i32,
    count: i32,
}

#[derive(Clone, Copy, PartialEq)]
enum Phase {
    Fill,
    Fit,
}

const MAGIC: &[u8; 4] = b"RAIL";
const END_MARK: &[u8; 4] = b"END!";
const VERSION: u32 = 3; // 3: per-puzzle networks, round/pool state is not stored

fn shuffle(order: &mut Vec<usize>, rng: &mut Rng) {
    let mut i = order.len();
    while i > 1 {
        let j = rng.below(i as u32) as usize;
        order.swap(i - 1, j);
        i -= 1;
    }
}

fn sample_state(pz: &Puzzle, tests: &TestSet, frontier_mix: f32, depth_cur: i32, rng: &mut Rng, out: &mut [u8]) {
    for _ in 0..8 {
        let depth = if depth_cur >= 2 && rng.uniform() < frontier_mix {
            depth_cur - 1 + rng.below(2) as i32
        } else {
            rng.below((depth_cur + 1) as u32) as i32
        };
        random_scramble(pz, rng, depth, out);
        if !tests.is_held_out(pz.hash(out)) {
            return; // held-out states never reach training, at any depth
        }
    }
    pz.set_solved(out); // practically unreachable; keeps the held-out guarantee strict
}

fn adam_update(net: &mut [f32], m: &mut [f32], v: &mut [f32], g: &[f32], adam_t: &mut i64, lr: f32) {
    *adam_t += 1;
    let b1 = 0.9f32;
    let b2 = 0.999f32;
    let eps = 1.0e-8f32;
    let t = *adam_t as f32;
    let c1 = 1.0 - b1.powf(t);
    let c2 = 1.0 - b2.powf(t);
    let lr_t = lr * c2.sqrt() / c1;
    for i in 0..net.len() {
        let gi = g[i];
        m[i] = b1 * m[i] + (1.0 - b1) * gi;
        v[i] = b2 * v[i] + (1.0 - b2) * gi * gi;
        net[i] -= lr_t * m[i] / (v[i].sqrt() + eps);
    }
}

#[allow(clippy::too_many_arguments)]
fn fill_range(
    pz: &Puzzle,
    model: &Model,
    tests: &TestSet,
    target: &[f32],
    frontier_mix: f32,
    depth: i32,
    rng: &mut Rng,
    feats: &mut [usize],
    tgts: &mut [f32],
    a: usize,
) {
    let mut s = [0u8; K_MAX_AI_STICKERS];
    let mut c = [0u8; K_MAX_AI_STICKERS];
    for k in 0..tgts.len() {
        sample_state(pz, tests, frontier_mix, depth, rng, &mut s);
        let mut tgt = 0.0f32;
        if !pz.is_solved(&s) {
            let mut best = 1.0e9f32;
            for &m in pz.ai_moves.iter() {
                pz.apply(&s, &mut c, m);
                let v = if pz.is_solved(&c) { 0.0 } else { value_of(model, target, &c) };
                if v < best {
                    best = v;
                }
            }
            tgt = 1.0 + best;
        }
        let f = &mut feats[k * a..(k + 1) * a];
        if model.enc.encode(&s, f) != a as i32 {
            // cannot happen for states reached by legal moves
            model.enc.encode(&pz.solved, f);
            tgt = 0.0;
        }
        tgts[k] = tgt;
    }
}

pub struct Trainer {
    model: Arc<Model>,
    puzzle: &'static Puzzle,
    tests: Arc<TestSet>,
    cfg: TrainConfig,
    rng: Rng,
    net: Vec<f32>,
    target: Vec<f32>,
    m: Vec<f32>,
    v: Vec<f32>,
    workers: Vec<Worker>,
    active: usize,

    // Current round.
    phase: Phase,
    pool_feat: Vec<usize>,
    pool_tgt: Vec<f32>,
    order: Vec<usize>,
    pool_fill: usize,
    cursor: usize,
    epoch: i32,
    epoch_hits: i32,
    epoch_count: i32,

    steps: i64,
    samples: i64,
    adam_t: i64,
    iterations: i32,
    depth: i32,
    ema_loss: f32,
    ema_mae: f32,
    ema_acc: f32,
    samples_per_sec: f32,
    chunk_steps: i32,
}

impl Trainer {
    pub fn new(model: Arc<Model>, tests: Arc<TestSet>) -> Trainer {
        let puzzle = model.puzzle;
        let active = if model.enc.active() > 0 { model.enc.active() } else { 1 };
        let mut cfg = TrainConfig::default();
        cfg.max_depth = puzzle.default_max_depth;
        let mut t = Trainer {
            model,
            puzzle,
            tests,
            cfg,
            rng: Rng::new(1),
            net: Vec::new(),
            target: Vec::new(),
            m: Vec::new(),
            v: Vec::new(),
            workers: Vec::new(),
            active,
            phase: Phase::Fill,
            pool_feat: Vec::new(),
            pool_tgt: Vec::new(),
            order: Vec::new(),
            pool_fill: 0,
            cursor: 0,
            epoch: 0,
            epoch_hits: 0,
            epoch_count: 0,
            steps: 0,
            samples: 0,
            adam_t: 0,
            iterations: 0,
            depth: 3,
            ema_loss: 0.0,
            ema_mae: 0.0,
            ema_acc: 0.0,
            samples_per_sec: 0.0,
            chunk_steps: 0,
        };
        t.reset(1);
        t
    }

    pub fn reset(&mut self, seed: u64) {
        self.rng.reseed(seed);
        init_params(&self.model.spec, &mut self.net, &mut self.rng);
        self.target = self.net.clone();
        let n = self.model.spec.count;
        self.m = vec![0.0; n];
        self.v = vec![0.0; n];
        self.steps = 0;
        self.samples = 0;
        self.adam_t = 0;
        self.iterations = 0;
        self.depth = self.cfg.start_depth.min(self.cfg.max_depth);
        self.ema_loss = 0.0;
        self.ema_mae = 0.0;
        self.ema_acc = 0.0;
        self.samples_per_sec = 0.0;
        self.chunk_steps = 0;
        self.start_fill();
    }

    pub fn set_config(&mut self, input: TrainConfig) {
        let old_pool = self.cfg.pool;
        let old_batch = self.cfg.batch;
        let mut c = input;
        c.batch = c.batch.clamp(32, 2048);
        c.pool = c.pool.clamp(c.batch * 4, 32768);
        c.lr = c.lr.clamp(1.0e-5, 1.0e-1);
        c.max_depth = c.max_depth.clamp(2, TestSet::MAX_DEPTH);
        c.threads = c.threads.clamp(1, 8);
        c.start_depth = c.start_depth.clamp(1, c.max_depth);
        c.min_epochs = c.min_epochs.clamp(1, 16);
        c.max_epochs = c.max_epochs.clamp(c.min_epochs, 32);
        c.acc_threshold = c.acc_threshold.clamp(0.3, 0.99);
        c.frontier_mix = c.frontier_mix.clamp(0.0, 0.9);
        self.cfg = c;
        self.depth = self.depth.clamp(1, self.cfg.max_depth);
        if self.cfg.pool != old_pool || self.cfg.batch != old_batch {
            self.start_fill();
        }
    }

    pub fn config(&self) -> TrainConfig {
        self.cfg
    }

    pub fn params(&self) -> &Vec<f32> {
        &self.net
    }

    fn ensure_workers(&mut self, threads: usize) {
        while self.workers.len() < threads {
            self.workers.push(Worker::default());
        }
    }

    fn start_fill(&mut self) {
        self.phase = Phase::Fill;
        self.pool_fill = 0;
        self.cursor = 0;
        self.epoch = 0;
        self.epoch_hits = 0;
        self.epoch_count = 0;
        let p = self.cfg.pool as usize;
        self.pool_tgt = vec![0.0; p];
        self.pool_feat = vec![0usize; p * self.active];
    }

    fn start_fit(&mut self) {
        self.phase = Phase::Fit;
        self.order = (0..self.cfg.pool as usize).collect();
        shuffle(&mut self.order, &mut self.rng);
        self.cursor = 0;
        self.epoch = 0;
        self.epoch_hits = 0;
        self.epoch_count = 0;
    }

    fn end_epoch(&mut self) {
        let acc = if self.epoch_count > 0 { self.epoch_hits as f32 / self.epoch_count as f32 } else { 0.0 };
        self.epoch += 1;
        self.ema_acc = acc;
        self.epoch_hits = 0;
        self.epoch_count = 0;
        let learned = self.epoch >= self.cfg.min_epochs && acc >= self.cfg.acc_threshold;
        let done = learned || self.epoch >= self.cfg.max_epochs;
        if !done {
            shuffle(&mut self.order, &mut self.rng);
            self.cursor = 0;
            return;
        }
        self.target = self.net.clone();
        self.iterations += 1;
        if learned && self.depth < self.cfg.max_depth {
            self.depth += 1;
        }
        self.start_fill();
    }

    fn fill_step(&mut self) {
        let p = self.cfg.pool as usize;
        let a = self.active;
        let threads = self.cfg.threads.clamp(1, 8) as usize;
        self.ensure_workers(threads);
        let chunk = (p - self.pool_fill).min(128 * threads);
        let base = self.rng.next();
        for t in 0..threads {
            self.workers[t].rng.reseed(base.wrapping_add(0x9E37u64.wrapping_mul(t as u64 + 1)));
        }

        let pz: &Puzzle = self.puzzle;
        let model: &Model = &self.model;
        let tests: &TestSet = &self.tests;
        let target: &[f32] = &self.target;
        let fm = self.cfg.frontier_mix;
        let depth = self.depth;
        let fill0 = self.pool_fill;
        let mut feat_rest: &mut [usize] = &mut self.pool_feat[fill0 * a..(fill0 + chunk) * a];
        let mut tgt_rest: &mut [f32] = &mut self.pool_tgt[fill0..fill0 + chunk];

        if threads == 1 {
            let w = &mut self.workers[0];
            fill_range(pz, model, tests, target, fm, depth, &mut w.rng, feat_rest, tgt_rest, a);
        } else {
            std::thread::scope(|sc| {
                for (t, w) in self.workers.iter_mut().take(threads).enumerate() {
                    let lo = chunk * t / threads;
                    let hi = chunk * (t + 1) / threads;
                    let cnt = hi - lo;
                    let (fh, fnext) = std::mem::take(&mut feat_rest).split_at_mut(cnt * a);
                    feat_rest = fnext;
                    let (th, tnext) = std::mem::take(&mut tgt_rest).split_at_mut(cnt);
                    tgt_rest = tnext;
                    sc.spawn(move || {
                        fill_range(pz, model, tests, target, fm, depth, &mut w.rng, fh, th, a);
                    });
                }
            });
        }

        self.pool_fill += chunk;
        if self.pool_fill >= p {
            self.start_fit();
        }
    }

    fn fit_step(&mut self) {
        let batch = self.cfg.batch as usize;
        let a = self.active;
        let threads = self.cfg.threads.clamp(1, 8) as usize;
        self.ensure_workers(threads);
        let count = self.model.spec.count;
        for t in 0..threads {
            let w = &mut self.workers[t];
            if w.grad.len() != count {
                w.grad = vec![0.0; count];
            } else {
                for x in w.grad.iter_mut() {
                    *x = 0.0;
                }
            }
            w.loss_sum = 0.0;
            w.abs_sum = 0.0;
            w.hits = 0;
            w.count = 0;
        }

        {
            let spec = &self.model.spec;
            let net: &[f32] = &self.net;
            let inv_batch = 1.0 / batch as f32;
            let delta = 2.0f32; // Huber threshold in moves
            let first = self.cursor;
            let pool_feat = &self.pool_feat;
            let pool_tgt = &self.pool_tgt;
            let order = &self.order;
            let work = |w: &mut Worker, b0: usize, b1: usize| {
                let mut act = Activations::new();
                for b in b0..b1 {
                    let idx = order[first + b];
                    let feats = &pool_feat[idx * a..(idx + 1) * a];
                    let tgt = pool_tgt[idx];
                    let out = forward(spec, net, feats, a, &mut act);
                    let err = out * VALUE_SCALE - tgt;
                    let aerr = err.abs();
                    w.abs_sum += aerr as f64;
                    w.loss_sum += if aerr <= delta {
                        0.5 * (err as f64) * (err as f64)
                    } else {
                        (delta * (aerr - 0.5 * delta)) as f64
                    };
                    if aerr < 0.5 {
                        w.hits += 1;
                    }
                    w.count += 1;
                    let clipped = err.clamp(-delta, delta);
                    backward(spec, net, &mut w.grad, feats, a, &act, clipped * VALUE_SCALE * inv_batch);
                }
            };
            if threads == 1 {
                work(&mut self.workers[0], 0, batch);
            } else {
                std::thread::scope(|sc| {
                    for (t, w) in self.workers.iter_mut().take(threads).enumerate() {
                        let b0 = batch * t / threads;
                        let b1 = batch * (t + 1) / threads;
                        let work_ref = &work;
                        sc.spawn(move || work_ref(w, b0, b1));
                    }
                });
            }
        }

        {
            let (first_w, rest_w) = self.workers.split_at_mut(1);
            let g = &mut first_w[0].grad;
            for t in 1..threads {
                let o = &rest_w[t - 1].grad;
                for i in 0..count {
                    g[i] += o[i];
                }
            }
            let mut sq = 0.0f32;
            for &x in g.iter() {
                sq += x * x;
            }
            let norm = sq.sqrt();
            let clip_norm = 20.0f32;
            if norm.is_finite() {
                if norm > clip_norm {
                    let scale = clip_norm / norm;
                    for x in g.iter_mut() {
                        *x *= scale;
                    }
                }
                adam_update(&mut self.net, &mut self.m, &mut self.v, &g[..], &mut self.adam_t, self.cfg.lr);
            }
        }

        let mut loss = 0.0f64;
        let mut abs_err = 0.0f64;
        let mut hits = 0i32;
        let mut n = 0i32;
        for t in 0..threads {
            let w = &self.workers[t];
            loss += w.loss_sum;
            abs_err += w.abs_sum;
            hits += w.hits;
            n += w.count;
        }
        if n > 0 {
            let bl = (loss / n as f64) as f32;
            let bm = (abs_err / n as f64) as f32;
            let al = if self.steps == 0 { 1.0f32 } else { 0.1f32 };
            self.ema_loss += al * (bl - self.ema_loss);
            self.ema_mae += al * (bm - self.ema_mae);
            self.epoch_hits += hits;
            self.epoch_count += n;
            // Live accuracy: running value inside the epoch, replaced by the exact epoch figure at its end.
            self.ema_acc += 0.1 * (hits as f32 / n as f32 - self.ema_acc);
        }

        self.steps += 1;
        self.samples += batch as i64;
        self.cursor += batch;
        if self.cursor + batch > self.cfg.pool as usize {
            self.end_epoch();
        }
    }

    fn step(&mut self) {
        if self.phase == Phase::Fill {
            self.fill_step();
        } else {
            self.fit_step();
        }
    }

    /// Trains until the time budget is spent (at least one unit of work).
    pub fn run(&mut self, budget_ms: i32) -> TrainStats {
        let t0 = Instant::now();
        let start_samples = self.samples;
        self.chunk_steps = 0;
        loop {
            self.step();
            self.chunk_steps += 1;
            if t0.elapsed().as_millis() as i64 >= budget_ms as i64 {
                break;
            }
        }
        let sec = t0.elapsed().as_secs_f64();
        self.samples_per_sec = if sec > 0.0 { ((self.samples - start_samples) as f64 / sec) as f32 } else { 0.0 };
        self.stats()
    }

    pub fn stats(&self) -> TrainStats {
        let mut s = TrainStats::default();
        s.steps = self.steps;
        s.samples = self.samples;
        s.iterations = self.iterations;
        s.depth = self.depth;
        s.loss = self.ema_loss;
        s.mae = self.ema_mae;
        s.accuracy = self.ema_acc;
        s.samples_per_sec = self.samples_per_sec;
        s.lr = self.cfg.lr;
        s.phase = if self.phase == Phase::Fill { 0 } else { 1 };
        if self.phase == Phase::Fill {
            s.progress = if self.cfg.pool > 0 { self.pool_fill as f32 / self.cfg.pool as f32 } else { 0.0 };
        } else {
            let e = self.epoch as f32 + if self.cfg.pool > 0 { self.cursor as f32 / self.cfg.pool as f32 } else { 0.0 };
            s.progress = (e / self.cfg.max_epochs.max(1) as f32).min(1.0);
        }
        s.epoch = self.epoch;
        s.threads = self.cfg.threads;
        s.batch = self.cfg.batch;
        s.pool = self.cfg.pool;
        s.max_depth = self.cfg.max_depth;
        s.chunk_steps = self.chunk_steps;
        s
    }

    // ---------------------------------------------------------------------------------- checkpoints

    pub fn save(&self, f: &mut File) -> bool {
        let sp = &self.model.spec;
        let mut buf: Vec<u8> = Vec::new();
        buf.extend_from_slice(MAGIC);
        buf.extend_from_slice(&VERSION.to_le_bytes());
        buf.extend_from_slice(&(self.puzzle.id as u32).to_le_bytes());
        for d in [sp.n_feat as u32, sp.h1 as u32, sp.h2 as u32, sp.count as u32] {
            buf.extend_from_slice(&d.to_le_bytes());
        }
        buf.extend_from_slice(&self.steps.to_le_bytes());
        buf.extend_from_slice(&self.samples.to_le_bytes());
        buf.extend_from_slice(&self.adam_t.to_le_bytes());
        buf.extend_from_slice(&self.iterations.to_le_bytes());
        buf.extend_from_slice(&self.depth.to_le_bytes());
        buf.extend_from_slice(&self.ema_loss.to_le_bytes());
        buf.extend_from_slice(&self.ema_mae.to_le_bytes());
        buf.extend_from_slice(&self.ema_acc.to_le_bytes());
        buf.extend_from_slice(&self.rng.state().to_le_bytes());
        for vec in [&self.net, &self.target, &self.m, &self.v] {
            for x in vec.iter() {
                buf.extend_from_slice(&x.to_le_bytes());
            }
        }
        buf.extend_from_slice(END_MARK);
        f.write_all(&buf).is_ok()
    }

    pub fn load(&mut self, f: &mut File) -> bool {
        let mut data: Vec<u8> = Vec::new();
        if f.read_to_end(&mut data).is_err() {
            return false;
        }
        let mut r = Reader { data: &data, pos: 0 };
        let sp = self.model.spec.clone();
        match r.take(4) {
            Some(m) if m == MAGIC => {}
            _ => return false,
        }
        if r.u32() != Some(VERSION) {
            return false;
        }
        if r.u32() != Some(self.puzzle.id as u32) {
            return false;
        }
        let dims = [r.u32(), r.u32(), r.u32(), r.u32()];
        if dims[0] != Some(sp.n_feat as u32)
            || dims[1] != Some(sp.h1 as u32)
            || dims[2] != Some(sp.h2 as u32)
            || dims[3] != Some(sp.count as u32)
        {
            return false;
        }
        let n = sp.count;
        let steps = r.i64();
        let samples = r.i64();
        let adam_t = r.i64();
        let iterations = r.i32();
        let depth = r.i32();
        let ema_loss = r.f32();
        let ema_mae = r.f32();
        let ema_acc = r.f32();
        let rng_state = r.u64();
        let net = r.floats(n);
        let target = r.floats(n);
        let m = r.floats(n);
        let v = r.floats(n);
        let end = r.take(4);
        let (steps, samples, adam_t, iterations, depth, ema_loss, ema_mae, ema_acc, rng_state) =
            match (steps, samples, adam_t, iterations, depth, ema_loss, ema_mae, ema_acc, rng_state) {
                (Some(a), Some(b), Some(c), Some(d), Some(e), Some(f2), Some(g), Some(h), Some(i)) => {
                    (a, b, c, d, e, f2, g, h, i)
                }
                _ => return false,
            };
        let (net, target, m, v) = match (net, target, m, v) {
            (Some(a), Some(b), Some(c), Some(d)) => (a, b, c, d),
            _ => return false,
        };
        match end {
            Some(e) if e == END_MARK => {}
            _ => return false,
        }
        let finite = |x: &Vec<f32>| x.iter().all(|y| y.is_finite());
        if !finite(&net) || !finite(&target) || !finite(&m) || !finite(&v) {
            return false;
        }
        if steps < 0 || samples < 0 || adam_t < 0 || iterations < 0 || depth < 1 {
            return false;
        }

        self.net = net;
        self.target = target;
        self.m = m;
        self.v = v;
        self.steps = steps;
        self.samples = samples;
        self.adam_t = adam_t;
        self.iterations = iterations;
        self.depth = depth.clamp(1, self.cfg.max_depth);
        self.ema_loss = ema_loss;
        self.ema_mae = ema_mae;
        self.ema_acc = ema_acc;
        self.rng.set_state(rng_state);
        self.samples_per_sec = 0.0;
        self.chunk_steps = 0;
        self.start_fill(); // the pool of an interrupted round is not stored
        true
    }
}

struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> Option<&'a [u8]> {
        if self.pos + n > self.data.len() {
            return None;
        }
        let s = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Some(s)
    }
    fn u32(&mut self) -> Option<u32> {
        self.take(4).map(|b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }
    fn i32(&mut self) -> Option<i32> {
        self.take(4).map(|b| i32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }
    fn f32(&mut self) -> Option<f32> {
        self.take(4).map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }
    fn i64(&mut self) -> Option<i64> {
        self.take(8).map(|b| i64::from_le_bytes([b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]]))
    }
    fn u64(&mut self) -> Option<u64> {
        self.take(8).map(|b| u64::from_le_bytes([b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]]))
    }
    fn floats(&mut self, n: usize) -> Option<Vec<f32>> {
        let bytes = self.take(n * 4)?;
        let mut out = Vec::with_capacity(n);
        for c in bytes.chunks_exact(4) {
            out.push(f32::from_le_bytes([c[0], c[1], c[2], c[3]]));
        }
        Some(out)
    }
}
