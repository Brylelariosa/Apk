//! "Method learning": solvers whose knowledge is learned from the move rules alone, with nothing prerecorded.
//!
//! * Small puzzles (2x2, Pyraminx, Skewb): a breadth-first table of every state within a few moves of solved,
//!   learned by exploring the rules; a short search from the scrambled state meets the table (optimal-ish).
//! * 3x3: a CFOP-shaped method. Tables for the cross and each first-two-layers pair are learned by BFS over the
//!   positions of the tracked stickers. The last layer is solved with algorithms (macros) that the program
//!   discovers itself by searching for move sequences that change only the last layer, then a Dijkstra over all
//!   62208 last-layer states learns which algorithm to apply to each (OLL/PLL style, nothing stored).

use std::cmp::Reverse;
use std::collections::{BTreeMap, BinaryHeap, HashMap};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::OnceLock;
use std::time::Instant;

use crate::puzzle::{puzzle_by_id, Puzzle, K_CUBE2, K_CUBE3, K_PYRAMINX, K_SKEWB};
use crate::search::{K_CANCELLED, K_NODE_LIMIT, K_TIMEOUT};

pub struct Budget<'a> {
    start: Instant,
    timeout_ms: i32,
    cancel: &'a AtomicBool,
    pub nodes: u64,
}

impl<'a> Budget<'a> {
    pub fn new(timeout_ms: i32, cancel: &'a AtomicBool) -> Budget<'a> {
        Budget { start: Instant::now(), timeout_ms, cancel, nodes: 0 }
    }
    fn tick(&mut self) -> Result<(), i32> {
        self.nodes += 1;
        if self.nodes & 0x3FFF == 0 {
            if self.cancel.load(Ordering::Relaxed) {
                return Err(K_CANCELLED);
            }
            if self.start.elapsed().as_millis() as i64 > self.timeout_ms as i64 {
                return Err(K_TIMEOUT);
            }
        }
        Ok(())
    }
}

pub enum Method {
    Mitm(Mitm),
    Cube3(Staged3),
}

impl Method {
    /// `state` must be in the canonical frame. Returns solver moves, or a search status code on failure.
    pub fn solve(&self, pz: &Puzzle, state: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        match self {
            Method::Mitm(m) => m.solve(pz, state, b),
            Method::Cube3(s) => s.solve(pz, state, b),
        }
    }
}

static METHODS: [OnceLock<Option<Method>>; 6] =
    [OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new()];

/// The learned method of a puzzle, learning it first (once per process) when needed.
pub fn method_for(id: i32) -> Option<&'static Method> {
    if !(0..6).contains(&id) {
        return None;
    }
    METHODS[id as usize]
        .get_or_init(|| {
            let pz = puzzle_by_id(id)?;
            if !pz.valid || !pz.ai_supported {
                return None;
            }
            match id {
                K_CUBE2 => Some(Method::Mitm(Mitm::learn(pz, 8))),
                K_SKEWB => Some(Method::Mitm(Mitm::learn(pz, 7))),
                K_PYRAMINX => Some(Method::Mitm(Mitm::learn(pz, 7))),
                K_CUBE3 => Some(Method::Cube3(Staged3::learn(pz, 10))),
                _ => None,
            }
        })
        .as_ref()
}

/// Starts learning in the background so the first solve does not wait.
pub fn start_learning(id: i32) {
    if (0..6).contains(&id) {
        std::thread::spawn(move || {
            let _ = method_for(id);
        });
    }
}

// ------------------------------------------------------------------------------------------ small puzzles

pub struct Mitm {
    table: HashMap<u64, u8>,
}

impl Mitm {
    fn learn(pz: &Puzzle, depth: usize) -> Mitm {
        let mut table: HashMap<u64, u8> = HashMap::new();
        let mut s0 = vec![0u8; pz.stickers];
        pz.set_solved(&mut s0);
        table.insert(pz.hash(&s0), 0);
        let mut cur: Vec<Vec<u8>> = vec![s0];
        for d in 1..=depth {
            let mut next: Vec<Vec<u8>> = Vec::new();
            for a in cur.iter() {
                for &m in pz.ai_moves.iter() {
                    let mut b = vec![0u8; pz.stickers];
                    pz.apply(a, &mut b, m);
                    let h = pz.hash(&b);
                    if !table.contains_key(&h) {
                        table.insert(h, d as u8);
                        next.push(b);
                    }
                }
            }
            cur = next;
        }
        Mitm { table }
    }

    fn dfs(
        &self,
        pz: &Puzzle,
        s: &[u8; 54],
        g: usize,
        lim: usize,
        prev: i32,
        path: &mut Vec<u8>,
        b: &mut Budget,
    ) -> Result<bool, i32> {
        b.tick()?;
        if self.table.contains_key(&pz.hash(s)) {
            return Ok(true);
        }
        if g == lim {
            return Ok(false);
        }
        for &m in pz.ai_moves.iter() {
            if prev >= 0 && m as i32 == (prev ^ 1) {
                continue;
            }
            let mut t = [0u8; 54];
            pz.apply(s, &mut t, m);
            path.push(m as u8);
            if self.dfs(pz, &t, g + 1, lim, m as i32, path, b)? {
                return Ok(true);
            }
            path.pop();
        }
        Ok(false)
    }

    fn solve(&self, pz: &Puzzle, start: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        let mut s = [0u8; 54];
        s[..pz.stickers].copy_from_slice(&start[..pz.stickers]);
        for lim in 0..=12usize {
            let mut path: Vec<u8> = Vec::new();
            if self.dfs(pz, &s, 0, lim, -1, &mut path, b)? {
                let mut cur = s;
                let mut t = [0u8; 54];
                for &m in path.iter() {
                    pz.apply(&cur, &mut t, m as usize);
                    cur = t;
                }
                // Finish by walking down the table.
                while !pz.is_solved(&cur) {
                    let d = match self.table.get(&pz.hash(&cur)) {
                        Some(&d) => d,
                        None => return Err(K_NODE_LIMIT),
                    };
                    let mut moved = false;
                    for &m in pz.ai_moves.iter() {
                        pz.apply(&cur, &mut t, m);
                        if let Some(&d2) = self.table.get(&pz.hash(&t)) {
                            if d2 + 1 == d {
                                cur = t;
                                path.push(m as u8);
                                moved = true;
                                break;
                            }
                        }
                    }
                    if !moved {
                        return Err(K_NODE_LIMIT);
                    }
                }
                return Ok(path);
            }
        }
        Err(K_NODE_LIMIT)
    }
}

// ------------------------------------------------------------------------------------------ 3x3 (CFOP-shaped)

const DOWN: u8 = 3; // colour index of the D face (faces are U R F D L B)

#[derive(Clone, Copy)]
struct Tracker {
    mask: usize,
    want: u8,
}

fn home_of(pz: &Puzzle, t: &Tracker) -> Option<usize> {
    for s in pz.slots.iter() {
        let mut mk = 0usize;
        for k in 0..s.n {
            mk |= 1 << pz.solved[s.stickers[k]];
        }
        if mk == t.mask {
            for k in 0..s.n {
                if pz.solved[s.stickers[k]] == t.want {
                    return Some(s.stickers[k]);
                }
            }
        }
    }
    None
}

fn pos_in(pz: &Puzzle, st: &[u8], t: &Tracker) -> Option<usize> {
    for s in pz.slots.iter() {
        let mut mk = 0usize;
        for k in 0..s.n {
            mk |= 1 << st[s.stickers[k]];
        }
        if mk == t.mask {
            for k in 0..s.n {
                if st[s.stickers[k]] == t.want {
                    return Some(s.stickers[k]);
                }
            }
        }
    }
    None
}

struct Macro {
    moves: Vec<u8>,
    inv: [u8; 20],
}

pub struct Staged3 {
    inv: [[u8; 54]; 12], // after move m the sticker at p sits at inv[m][p]
    cross_t: [Tracker; 4],
    pair_c: [Tracker; 4],
    pair_e: [Tracker; 4],
    cross_tab: Vec<u8>,
    pair_tab: [Vec<u8>; 4],
    keep_pos: Vec<usize>,
    ll_pos: Vec<usize>,
    macros: Vec<Macro>,
    ll_parent: Vec<i32>,
    ll_macro: Vec<i32>,
    ll_index: HashMap<u64, usize>,
}

fn cidx(p: &[u8]) -> usize {
    ((p[0] as usize * 54 + p[1] as usize) * 54 + p[2] as usize) * 54 + p[3] as usize
}
fn pidx(a: u8, b: u8) -> usize {
    a as usize * 54 + b as usize
}
fn hash_ll(a: &[u8; 20]) -> u64 {
    let mut h: u64 = 1469598103934665603;
    for &b in a.iter() {
        h ^= b as u64;
        h = h.wrapping_mul(1099511628211);
    }
    h ^ (h >> 29)
}

fn dfs_macros(
    pz: &Puzzle,
    keep: &[usize],
    ll: &[usize],
    max_depth: usize,
    s: &[u8; 54],
    path: &mut Vec<u8>,
    best: &mut BTreeMap<[u8; 20], Vec<u8>>,
) {
    let g = path.len();
    if g > 0 && keep.iter().all(|&p| s[p] as usize == p) {
        let mut key = [0u8; 20];
        let mut same = true;
        for i in 0..20 {
            key[i] = s[ll[i]];
            if key[i] as usize != ll[i] {
                same = false;
            }
        }
        if !same {
            let better = match best.get(&key) {
                Some(old) => old.len() > path.len(),
                None => true,
            };
            if better {
                best.insert(key, path.clone());
            }
        }
    }
    if g == max_depth {
        return;
    }
    let prev: i32 = if g > 0 { path[g - 1] as i32 } else { -1 };
    let prev2: i32 = if g > 1 { path[g - 2] as i32 } else { -1 };
    for m in 0..6usize {
        if prev >= 0 && (m as i32 == (prev ^ 1) || (m as i32 == prev && prev2 == prev)) {
            continue;
        }
        let mut t = [0u8; 54];
        for i in 0..54 {
            t[i] = s[pz.perm[m][i] as usize];
        }
        path.push(m as u8);
        dfs_macros(pz, keep, ll, max_depth, &t, path, best);
        path.pop();
    }
}

struct Ida<'a> {
    st: &'a Staged3,
    stage: usize,
    n: usize,
    home: [u8; 12],
    limit: usize,
    path: Vec<u8>,
}

impl<'a> Ida<'a> {
    fn heur(&self, p: &[u8; 12]) -> usize {
        let mut h = self.st.cross_tab[cidx(p)] as usize;
        for k in 0..self.stage {
            let v = self.st.pair_tab[k][pidx(p[4 + 2 * k], p[5 + 2 * k])] as usize;
            if v > h {
                h = v;
            }
        }
        h
    }

    fn dfs(&mut self, p: &[u8; 12], g: usize, prev: i32, prev2: i32, b: &mut Budget) -> Result<bool, i32> {
        b.tick()?;
        let h = self.heur(p);
        if h == 0 && (0..self.n).all(|i| p[i] == self.home[i]) {
            return Ok(true);
        }
        if g + h > self.limit || g == self.limit {
            return Ok(false);
        }
        for m in 0..12usize {
            if prev >= 0 {
                if m as i32 == (prev ^ 1) {
                    continue;
                }
                if m as i32 == prev && prev2 == prev {
                    continue;
                }
                let fm = m / 2;
                let fp = (prev / 2) as usize;
                if fm % 3 == fp % 3 && fm < fp {
                    continue;
                }
            }
            let mut q = [0u8; 12];
            for i in 0..self.n {
                q[i] = self.st.inv[m][p[i] as usize];
            }
            self.path.push(m as u8);
            if self.dfs(&q, g + 1, m as i32, prev, b)? {
                return Ok(true);
            }
            self.path.pop();
        }
        Ok(false)
    }
}

impl Staged3 {
    fn learn(pz: &Puzzle, macro_depth: usize) -> Staged3 {
        let mut inv = [[0u8; 54]; 12];
        for m in 0..12 {
            for q in 0..54 {
                inv[m][pz.perm[m][q] as usize] = q as u8;
            }
        }
        let faces = [2usize, 1, 5, 4]; // F R B L
        let dm = 1usize << DOWN;
        let mut cross_t = [Tracker { mask: 0, want: DOWN }; 4];
        let mut pair_c = cross_t;
        let mut pair_e = cross_t;
        for i in 0..4 {
            cross_t[i] = Tracker { mask: dm | (1 << faces[i]), want: DOWN };
            let a = faces[i];
            let b = faces[(i + 1) % 4];
            pair_c[i] = Tracker { mask: dm | (1 << a) | (1 << b), want: DOWN };
            pair_e[i] = Tracker { mask: (1 << a) | (1 << b), want: a as u8 };
        }

        // Cross table: BFS over the positions of the four D edges (one tracked sticker each).
        let mut cross_tab = vec![255u8; 54 * 54 * 54 * 54];
        {
            let mut h = [0u8; 4];
            for i in 0..4 {
                h[i] = home_of(pz, &cross_t[i]).unwrap_or(0) as u8;
            }
            cross_tab[cidx(&h)] = 0;
            let mut cur: Vec<[u8; 4]> = vec![h];
            let mut d = 0u8;
            while !cur.is_empty() {
                let mut next: Vec<[u8; 4]> = Vec::new();
                for s in cur.iter() {
                    for m in 0..12 {
                        let mut t = [0u8; 4];
                        for i in 0..4 {
                            t[i] = inv[m][s[i] as usize];
                        }
                        let ix = cidx(&t);
                        if cross_tab[ix] == 255 {
                            cross_tab[ix] = d + 1;
                            next.push(t);
                        }
                    }
                }
                cur = next;
                d += 1;
            }
        }
        // Pair tables: BFS over the positions of one corner sticker and one edge sticker.
        let mut pair_tab: [Vec<u8>; 4] = [Vec::new(), Vec::new(), Vec::new(), Vec::new()];
        for k in 0..4 {
            let mut tab = vec![255u8; 54 * 54];
            let h = [home_of(pz, &pair_c[k]).unwrap_or(0) as u8, home_of(pz, &pair_e[k]).unwrap_or(0) as u8];
            tab[pidx(h[0], h[1])] = 0;
            let mut cur: Vec<[u8; 2]> = vec![h];
            let mut d = 0u8;
            while !cur.is_empty() {
                let mut next: Vec<[u8; 2]> = Vec::new();
                for s in cur.iter() {
                    for m in 0..12 {
                        let t = [inv[m][s[0] as usize], inv[m][s[1] as usize]];
                        let ix = pidx(t[0], t[1]);
                        if tab[ix] == 255 {
                            tab[ix] = d + 1;
                            next.push(t);
                        }
                    }
                }
                cur = next;
                d += 1;
            }
            pair_tab[k] = tab;
        }

        // Last layer: stickers of the eight last-layer pieces; everything else must stay home in an algorithm.
        let mut keep_pos: Vec<usize> = Vec::new();
        let mut ll_pos: Vec<usize> = Vec::new();
        for s in pz.slots.iter() {
            let mut mk = 0usize;
            for k in 0..s.n {
                mk |= 1 << pz.solved[s.stickers[k]];
            }
            let has_u = (mk & 1) != 0 && s.n > 1;
            for k in 0..s.n {
                if has_u {
                    ll_pos.push(s.stickers[k]);
                } else {
                    keep_pos.push(s.stickers[k]);
                }
            }
        }

        // Discover algorithms: short sequences of U, R, F turns that leave the first two layers intact.
        let mut ident = [0u8; 54];
        for i in 0..54 {
            ident[i] = i as u8;
        }
        let mut best: BTreeMap<[u8; 20], Vec<u8>> = BTreeMap::new();
        let mut path: Vec<u8> = Vec::new();
        dfs_macros(pz, &keep_pos, &ll_pos, macro_depth, &ident, &mut path, &mut best);
        let mut pos_of = [0usize; 54];
        for i in 0..20 {
            pos_of[ll_pos[i]] = i;
        }
        let mut macros: Vec<Macro> = Vec::new();
        for (key, moves) in best.iter() {
            let mut perm = [0u8; 20];
            let mut minv = [0u8; 20];
            for i in 0..20 {
                perm[i] = pos_of[key[i] as usize] as u8;
            }
            for i in 0..20 {
                minv[perm[i] as usize] = i as u8;
            }
            macros.push(Macro { moves: moves.clone(), inv: minv });
        }

        // Dijkstra over last-layer states from the solved layer, applying inverse algorithms.
        let mut solved_ll = [0u8; 20];
        for i in 0..20 {
            solved_ll[i] = pz.solved[ll_pos[i]];
        }
        let mut states: Vec<[u8; 20]> = vec![solved_ll];
        let mut ll_parent: Vec<i32> = vec![-1];
        let mut ll_macro: Vec<i32> = vec![-1];
        let mut cost: Vec<i32> = vec![0];
        let mut ll_index: HashMap<u64, usize> = HashMap::new();
        ll_index.insert(hash_ll(&solved_ll), 0);
        let mut heap: BinaryHeap<Reverse<(i32, usize)>> = BinaryHeap::new();
        heap.push(Reverse((0, 0)));
        while let Some(Reverse((c0, id))) = heap.pop() {
            if c0 > cost[id] {
                continue;
            }
            let cur = states[id];
            for (mi, mc) in macros.iter().enumerate() {
                let mut t = [0u8; 20];
                for i in 0..20 {
                    t[i] = cur[mc.inv[i] as usize];
                }
                let c = c0 + mc.moves.len() as i32;
                let h = hash_ll(&t);
                match ll_index.get(&h).copied() {
                    None => {
                        let nid = states.len();
                        states.push(t);
                        ll_parent.push(id as i32);
                        ll_macro.push(mi as i32);
                        cost.push(c);
                        ll_index.insert(h, nid);
                        heap.push(Reverse((c, nid)));
                    }
                    Some(nid) => {
                        if c < cost[nid] {
                            ll_parent[nid] = id as i32;
                            ll_macro[nid] = mi as i32;
                            cost[nid] = c;
                            heap.push(Reverse((c, nid)));
                        }
                    }
                }
            }
        }

        Staged3 {
            inv,
            cross_t,
            pair_c,
            pair_e,
            cross_tab,
            pair_tab,
            keep_pos,
            ll_pos,
            macros,
            ll_parent,
            ll_macro,
            ll_index,
        }
    }

    fn solve(&self, pz: &Puzzle, start: &[u8], b: &mut Budget) -> Result<Vec<u8>, i32> {
        let mut s = [0u8; 54];
        s[..54].copy_from_slice(&start[..54]);
        let mut tmp = [0u8; 54];
        let mut sol: Vec<u8> = Vec::new();

        for stage in 0..=4usize {
            let mut tr: Vec<Tracker> = self.cross_t.to_vec();
            for k in 0..stage {
                tr.push(self.pair_c[k]);
                tr.push(self.pair_e[k]);
            }
            let n = tr.len();
            let mut pos = [0u8; 12];
            let mut home = [0u8; 12];
            for i in 0..n {
                pos[i] = pos_in(pz, &s, &tr[i]).ok_or(K_NODE_LIMIT)? as u8;
                home[i] = home_of(pz, &tr[i]).ok_or(K_NODE_LIMIT)? as u8;
            }
            let mut ida = Ida { st: self, stage, n, home, limit: 0, path: Vec::new() };
            let mut found = false;
            for lim in 0..=18usize {
                ida.limit = lim;
                ida.path.clear();
                if ida.dfs(&pos, 0, -1, -1, b)? {
                    found = true;
                    break;
                }
            }
            if !found {
                return Err(K_NODE_LIMIT);
            }
            for &m in ida.path.iter() {
                pz.apply(&s, &mut tmp, m as usize);
                s = tmp;
                sol.push(m);
            }
        }

        // Last layer.
        for &p in self.keep_pos.iter() {
            if s[p] != pz.solved[p] {
                return Err(K_NODE_LIMIT);
            }
        }
        let mut cur = [0u8; 20];
        for i in 0..20 {
            cur[i] = s[self.ll_pos[i]];
        }
        let mut id = match self.ll_index.get(&hash_ll(&cur)) {
            Some(&i) => i,
            None => return Err(K_NODE_LIMIT),
        };
        while self.ll_parent[id] >= 0 {
            let mc = &self.macros[self.ll_macro[id] as usize];
            for &m in mc.moves.iter() {
                pz.apply(&s, &mut tmp, m as usize);
                s = tmp;
                sol.push(m);
            }
            id = self.ll_parent[id] as usize;
        }
        if pz.is_solved(&s) {
            Ok(sol)
        } else {
            Err(K_NODE_LIMIT)
        }
    }
}
