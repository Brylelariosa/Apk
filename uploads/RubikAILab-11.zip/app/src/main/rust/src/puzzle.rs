//! Generic twisty puzzle model (Rust port of core/puzzle.cpp, same geometry, same move tables).
//!
//! A puzzle is a set of stickers (flat polygons with a colour) and a set of moves. A state is one byte per
//! sticker holding its colour. Every move is a rotation about an axis through the origin of all the stickers
//! whose centre projects into [lo, hi] on that axis; its permutation table is generated from this geometry, and
//! the renderer animates the very same rotation, so simulation and drawing cannot disagree.
//!
//! Conventions
//!   * Move index = base * 2 + direction. Direction 0 is clockwise seen from outside the turning layer.
//!     inverse(m) = m ^ 1.
//!   * After a move: new[i] = old[perm[move][i]].
//!   * Cube axes: x = R, y = U, z = F. Faces U R F D L B, N*N stickers each, row-major as seen from outside.

use std::ops::{Add, Mul, Sub};
use std::sync::OnceLock;

pub const K_CUBE2: i32 = 0;
pub const K_CUBE3: i32 = 1;
pub const K_CUBE4: i32 = 2;
pub const K_CUBE5: i32 = 3;
pub const K_PYRAMINX: i32 = 4;
pub const K_SKEWB: i32 = 5;
pub const K_PUZZLE_COUNT: i32 = 6;

pub const K_MAX_STICKERS: usize = 150; // 5x5 cube
pub const K_MAX_AI_STICKERS: usize = 54; // the learning solver never sees more than this
pub const K_MAX_MOVES: usize = 40;

#[derive(Clone, Debug, Default)]
pub struct MoveInfo {
    pub axis: [f32; 3],
    pub angle_deg: f32,
    pub lo: f32,
    pub hi: f32,
    pub inverse: i32,
    pub name: String,
}

/// One physical piece position: the stickers that always travel together.
#[derive(Clone, Debug, Default)]
pub struct Slot {
    pub cls: usize,
    pub n: usize,
    pub stickers: [usize; 3],
}

#[derive(Clone, Debug, Default)]
pub struct BodyPiece {
    pub cls: [f32; 3],
    pub tris: Vec<f32>, // 12 floats per triangle: three vertices, then the outward normal
}

#[derive(Default)]
pub struct Puzzle {
    pub id: i32,
    pub name: String,
    pub short_name: String,
    pub valid: bool,

    pub stickers: usize,
    pub colors: i32,
    pub faces: usize,
    pub verts: Vec<f32>,
    pub vcount: Vec<u8>,
    pub normal: Vec<f32>,
    pub centroid: Vec<f32>,
    pub solved: Vec<u8>,
    pub face_of: Vec<u8>,
    pub face_begin: Vec<usize>,
    pub face_list: Vec<usize>,

    pub moves: usize,
    pub play_moves: usize,
    pub mv: Vec<MoveInfo>,
    pub perm: Vec<Vec<u8>>,

    pub ai_supported: bool,
    pub ai_moves: Vec<usize>,
    pub needs_canon: bool,
    pub default_max_depth: i32,
    pub hidden1: usize,
    pub hidden2: usize,
    pub slots: Vec<Slot>,
    pub slot_of: Vec<i32>,
    pub class_count: usize,
    pub slot_fixed: Vec<bool>,
    pub rotations: Vec<Vec<u8>>,
    pub conj: Vec<Vec<i32>>,
    pub ref_stickers: Vec<usize>,

    pub radius: f32,
    pub sticker_inset: f32,
    pub sticker_round: f32,
    pub sticker_lift: f32,
    pub bodies: Vec<BodyPiece>,
    pub core: Vec<f32>,
}

// ------------------------------------------------------------------------------------------ vectors

#[derive(Clone, Copy, Debug)]
struct V3 {
    x: f32,
    y: f32,
    z: f32,
}

impl Add for V3 {
    type Output = V3;
    fn add(self, o: V3) -> V3 {
        V3 { x: self.x + o.x, y: self.y + o.y, z: self.z + o.z }
    }
}
impl Sub for V3 {
    type Output = V3;
    fn sub(self, o: V3) -> V3 {
        V3 { x: self.x - o.x, y: self.y - o.y, z: self.z - o.z }
    }
}
impl Mul<f32> for V3 {
    type Output = V3;
    fn mul(self, s: f32) -> V3 {
        V3 { x: self.x * s, y: self.y * s, z: self.z * s }
    }
}

fn v3(x: f32, y: f32, z: f32) -> V3 {
    V3 { x, y, z }
}
fn dot(a: V3, b: V3) -> f32 {
    a.x * b.x + a.y * b.y + a.z * b.z
}
fn cross(a: V3, b: V3) -> V3 {
    V3 { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }
}
fn length(a: V3) -> f32 {
    dot(a, a).sqrt()
}
fn unit(a: V3) -> V3 {
    let l = length(a);
    if l > 0.0 {
        a * (1.0 / l)
    } else {
        a
    }
}

const MATCH_TOL: f32 = 2.0e-3; // centre / normal matching
const LAYER_TOL: f32 = 1.0e-3; // layer membership

/// v rotated by angle_deg about the unit axis a (right-hand rule).
fn rotate_about(a: V3, angle_deg: f32, v: V3) -> V3 {
    let th = angle_deg as f64 * std::f64::consts::PI / 180.0;
    let c = th.cos() as f32;
    let s = th.sin() as f32;
    v * c + cross(a, v) * s + a * (dot(a, v) * (1.0 - c))
}

fn centroid_of(p: &Puzzle, i: usize) -> V3 {
    v3(p.centroid[i * 3], p.centroid[i * 3 + 1], p.centroid[i * 3 + 2])
}
fn normal_of(p: &Puzzle, i: usize) -> V3 {
    v3(p.normal[i * 3], p.normal[i * 3 + 1], p.normal[i * 3 + 2])
}
fn vertex_of(p: &Puzzle, i: usize, k: usize) -> V3 {
    let o = i * 12 + k * 3;
    v3(p.verts[o], p.verts[o + 1], p.verts[o + 2])
}
fn axis_of(m: &MoveInfo) -> V3 {
    v3(m.axis[0], m.axis[1], m.axis[2])
}
fn in_layer(m: &MoveInfo, point: V3) -> bool {
    let pr = dot(point, axis_of(m));
    pr >= m.lo - LAYER_TOL && pr <= m.hi + LAYER_TOL
}

// ------------------------------------------------------------------------------------------ building blocks

/// Corners are counter-clockwise as seen from outside, so the first three give the outward normal.
fn add_sticker(p: &mut Puzzle, color: i32, face: i32, v: &[V3], n: usize) {
    let mut c = v3(0.0, 0.0, 0.0);
    for k in 0..4 {
        let q = v[if k < n { k } else { n - 1 }];
        p.verts.push(q.x);
        p.verts.push(q.y);
        p.verts.push(q.z);
    }
    for k in 0..n {
        c = c + v[k];
    }
    c = c * (1.0 / n as f32);
    let nrm = unit(cross(v[1] - v[0], v[2] - v[0]));
    p.vcount.push(n as u8);
    p.normal.push(nrm.x);
    p.normal.push(nrm.y);
    p.normal.push(nrm.z);
    p.centroid.push(c.x);
    p.centroid.push(c.y);
    p.centroid.push(c.z);
    p.solved.push(color as u8);
    p.face_of.push(face as u8);
    p.stickers += 1;
}

/// Adds a clockwise / counter-clockwise pair of turns of one layer.
fn add_move_pair(p: &mut Puzzle, name: &str, axis: V3, step_deg: f32, lo: f32, hi: f32) {
    let base = p.mv.len() as i32;
    let a = unit(axis);
    for dir in 0..2 {
        let m = MoveInfo {
            axis: [a.x, a.y, a.z],
            angle_deg: if dir == 0 { -step_deg } else { step_deg },
            lo,
            hi,
            inverse: base + (1 - dir),
            name: if dir == 0 { name.to_string() } else { format!("{}'", name) },
        };
        p.mv.push(m);
    }
    p.moves = p.mv.len();
}

// ------------------------------------------------------------------------------------------ solid pieces
//
// Every puzzle is cut into rigid pieces by the planes its moves turn about. A piece is one cell of that plane
// arrangement inside the outer solid, so it lies entirely inside or entirely outside every turning layer and
// therefore turns with a layer or stays put, never half of each. Cells are pulled half a gap away from every cut
// plane, and their edges are chamfered a little so the pieces read as moulded plastic. All arithmetic is in double
// precision; only the result is stored as float.
mod solid {
    use super::{BodyPiece, Puzzle};
    use std::ops::{Add, Mul, Sub};

    #[derive(Clone, Copy, Debug)]
    pub struct Vd {
        pub x: f64,
        pub y: f64,
        pub z: f64,
    }

    impl Add for Vd {
        type Output = Vd;
        fn add(self, o: Vd) -> Vd {
            Vd { x: self.x + o.x, y: self.y + o.y, z: self.z + o.z }
        }
    }
    impl Sub for Vd {
        type Output = Vd;
        fn sub(self, o: Vd) -> Vd {
            Vd { x: self.x - o.x, y: self.y - o.y, z: self.z - o.z }
        }
    }
    impl Mul<f64> for Vd {
        type Output = Vd;
        fn mul(self, s: f64) -> Vd {
            Vd { x: self.x * s, y: self.y * s, z: self.z * s }
        }
    }

    pub fn vd(x: f64, y: f64, z: f64) -> Vd {
        Vd { x, y, z }
    }
    fn dotv(a: Vd, b: Vd) -> f64 {
        a.x * b.x + a.y * b.y + a.z * b.z
    }
    fn crossv(a: Vd, b: Vd) -> Vd {
        Vd { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }
    }
    fn normv(a: Vd) -> f64 {
        dotv(a, a).sqrt()
    }
    fn unitv(a: Vd) -> Vd {
        let l = normv(a);
        if l > 0.0 {
            a * (1.0 / l)
        } else {
            a
        }
    }

    /// The half-space dot(n, x) <= d, with |n| = 1.
    #[derive(Clone, Copy, Debug)]
    pub struct Plane {
        pub n: Vd,
        pub d: f64,
    }

    type Poly = Vec<Vd>;

    const ON: f64 = 1.0e-9; // a point closer than this to a plane lies on it

    /// Sutherland-Hodgman: the part of a convex polygon inside the half-space.
    fn clip_poly(inp: &Poly, pl: &Plane) -> Poly {
        let mut out: Poly = Vec::new();
        let cnt = inp.len();
        for i in 0..cnt {
            let a = inp[i];
            let b = inp[(i + 1) % cnt];
            let da = dotv(pl.n, a) - pl.d;
            let db = dotv(pl.n, b) - pl.d;
            let sa: i32 = if da > ON { 1 } else if da < -ON { -1 } else { 0 };
            let sb: i32 = if db > ON { 1 } else if db < -ON { -1 } else { 0 };
            if sa <= 0 {
                out.push(a);
            }
            if sa * sb < 0 {
                out.push(a + (b - a) * (da / (da - db)));
            }
        }
        out
    }

    fn poly_area(p: &Poly) -> f64 {
        let mut s = vd(0.0, 0.0, 0.0);
        for i in 0..p.len() {
            s = s + crossv(p[i], p[(i + 1) % p.len()]);
        }
        0.5 * normv(s)
    }

    fn drop_repeats(p: &mut Poly) {
        let mut q: Poly = Vec::new();
        for &a in p.iter() {
            if q.is_empty() || normv(a - *q.last().unwrap()) > 1.0e-7 {
                q.push(a);
            }
        }
        while q.len() > 1 && normv(q[0] - *q.last().unwrap()) <= 1.0e-7 {
            q.pop();
        }
        *p = q;
    }

    fn poly_centre(p: &Poly) -> Vd {
        let mut c = vd(0.0, 0.0, 0.0);
        for &v in p.iter() {
            c = c + v;
        }
        if p.is_empty() {
            c
        } else {
            c * (1.0 / p.len() as f64)
        }
    }

    /// A convex solid given by its half-spaces; faces[i] is the part of plane i that bounds it (empty if
    /// redundant), counter-clockwise seen from outside.
    #[derive(Clone)]
    pub struct Convex {
        pub hs: Vec<Plane>,
        pub faces: Vec<Poly>,
    }

    fn face_of(hs: &[Plane], i: usize) -> Poly {
        let pl = hs[i];
        let helper = if pl.n.x.abs() < 0.9 { vd(1.0, 0.0, 0.0) } else { vd(0.0, 1.0, 0.0) };
        let u = unitv(crossv(pl.n, helper));
        let v = crossv(pl.n, u); // u x v = n, so the square below runs counter-clockwise seen from outside
        let c = pl.n * pl.d;
        let big = 64.0;
        let mut poly: Poly = vec![
            c - u * big - v * big,
            c + u * big - v * big,
            c + u * big + v * big,
            c - u * big + v * big,
        ];
        let mut j = 0;
        while j < hs.len() && !poly.is_empty() {
            if j != i {
                poly = clip_poly(&poly, &hs[j]);
            }
            j += 1;
        }
        drop_repeats(&mut poly);
        if poly.len() < 3 || poly_area(&poly) < 1.0e-7 {
            poly.clear();
        }
        poly
    }

    pub fn build_faces(s: &mut Convex) {
        let mut faces: Vec<Poly> = Vec::with_capacity(s.hs.len());
        for i in 0..s.hs.len() {
            faces.push(face_of(&s.hs, i));
        }
        s.faces = faces;
    }

    pub fn convex_centre(s: &Convex) -> Vd {
        let mut c = vd(0.0, 0.0, 0.0);
        let mut n = 0usize;
        for f in s.faces.iter() {
            for &v in f.iter() {
                c = c + v;
                n += 1;
            }
        }
        if n > 0 {
            c * (1.0 / n as f64)
        } else {
            c
        }
    }

    /// Smallest and largest signed distance of the solid's corners from a plane.
    fn spread(s: &Convex, pl: &Plane) -> (f64, f64) {
        let mut lo = 1.0e30;
        let mut hi = -1.0e30;
        for f in s.faces.iter() {
            for &v in f.iter() {
                let t = dotv(pl.n, v) - pl.d;
                if t < lo {
                    lo = t;
                }
                if t > hi {
                    hi = t;
                }
            }
        }
        (lo, hi)
    }

    fn same_plane(a: &Plane, b: &Plane) -> bool {
        normv(a.n - b.n) < 1.0e-6 && (a.d - b.d).abs() < 1.0e-6
    }

    /// The distinct planes that the moves turn about and that pass through the inside of the outer solid.
    pub fn cut_planes(p: &Puzzle, outer: &Convex) -> Vec<Plane> {
        let mut cuts: Vec<Plane> = Vec::new();
        // Only the moves of the real puzzle cut it into pieces; free extra moves (the Skewb's single-corner
        // twists) turn a whole piece or part of one and must not split it.
        let real = if p.play_moves > 0 { p.play_moves } else { p.mv.len() };
        for mi in 0..real {
            let m = &p.mv[mi];
            let a = unitv(vd(m.axis[0] as f64, m.axis[1] as f64, m.axis[2] as f64));
            let bounds = [m.lo as f64, m.hi as f64];
            for k in 0..2 {
                let mut pl = Plane { n: a, d: bounds[k] };
                let lead = if a.x.abs() > 1.0e-6 {
                    a.x
                } else if a.y.abs() > 1.0e-6 {
                    a.y
                } else {
                    a.z
                };
                if lead < 0.0 {
                    pl = Plane { n: a * -1.0, d: -bounds[k] }; // one description per plane
                }
                let (lo, hi) = spread(outer, &pl);
                if !(lo < -1.0e-4 && hi > 1.0e-4) {
                    continue; // misses the solid (or only grazes it)
                }
                let mut known = false;
                for c in cuts.iter() {
                    known = known || same_plane(c, &pl);
                }
                if !known {
                    cuts.push(pl);
                }
            }
        }
        cuts
    }

    /// Splits the outer solid by every cut plane, keeping `gap` between the two sides of each cut.
    pub fn cells_of(outer_planes: &[Plane], cuts: &[Plane], gap: f64) -> Vec<Convex> {
        let mut first = Convex { hs: outer_planes.to_vec(), faces: Vec::new() };
        build_faces(&mut first);
        let mut cells: Vec<Convex> = vec![first];
        for cut in cuts.iter() {
            let mut next: Vec<Convex> = Vec::new();
            for c in cells.iter() {
                let (lo, hi) = spread(c, cut);
                if lo < -1.0e-6 && hi > 1.0e-6 {
                    let mut below = c.clone();
                    let mut above = c.clone();
                    below.hs.push(Plane { n: cut.n, d: cut.d - gap * 0.5 });
                    above.hs.push(Plane { n: cut.n * -1.0, d: -(cut.d + gap * 0.5) });
                    build_faces(&mut below);
                    build_faces(&mut above);
                    next.push(below);
                    next.push(above);
                } else {
                    next.push(c.clone());
                }
            }
            cells = next;
        }
        cells
    }

    /// Cuts a flat chamfer of width `c` along every edge of the solid.
    pub fn chamfer_edges(s: &mut Convex, c_in: f64) {
        let n = s.hs.len();
        let ctr = convex_centre(s);
        let mut inner = 1.0e30_f64; // distance from the centre to the nearest face
        for i in 0..n {
            if !s.faces[i].is_empty() {
                inner = inner.min(s.hs[i].d - dotv(s.hs[i].n, ctr));
            }
        }
        let c = c_in.min(0.3 * inner);
        if c < 1.0e-5 {
            return;
        }
        let mut extra: Vec<Plane> = Vec::new();
        for i in 0..n {
            if s.faces[i].is_empty() {
                continue;
            }
            for j in (i + 1)..n {
                if s.faces[j].is_empty() {
                    continue;
                }
                let mut shared: Vec<Vd> = Vec::new(); // corners of face i that lie on plane j: the edge between them
                for &v in s.faces[i].iter() {
                    if (dotv(s.hs[j].n, v) - s.hs[j].d).abs() < 1.0e-7 {
                        shared.push(v);
                    }
                }
                if shared.len() < 2 {
                    continue;
                }
                let mut pa = shared[0];
                let mut pb = shared[0];
                let mut longest = 0.0;
                for a in 0..shared.len() {
                    for b in (a + 1)..shared.len() {
                        let len = normv(shared[a] - shared[b]);
                        if len > longest {
                            longest = len;
                            pa = shared[a];
                            pb = shared[b];
                        }
                    }
                }
                if longest < 1.0e-5 {
                    continue;
                }
                let bis = s.hs[i].n + s.hs[j].n;
                if normv(bis) < 0.2 {
                    continue; // nearly opposite faces: no real edge
                }
                let mid = (pa + pb) * 0.5;
                let dir = unitv(pb - pa);
                let mut inward = poly_centre(&s.faces[i]) - mid;
                inward = unitv(inward - dir * dotv(inward, dir)); // into face i, away from the edge
                let nc = unitv(bis);
                extra.push(Plane { n: nc, d: dotv(nc, mid + inward * c) });
            }
        }
        for pl in extra {
            s.hs.push(pl);
        }
        build_faces(s);
    }

    pub fn emit_triangles(s: &Convex, bp: &mut BodyPiece) {
        for i in 0..s.hs.len() {
            let f = &s.faces[i];
            if f.len() < 3 {
                continue;
            }
            let nrm = s.hs[i].n;
            for k in 1..(f.len() - 1) {
                let t = [f[0], f[k], f[k + 1]];
                for q in 0..3 {
                    bp.tris.push(t[q].x as f32);
                    bp.tris.push(t[q].y as f32);
                    bp.tris.push(t[q].z as f32);
                }
                bp.tris.push(nrm.x as f32);
                bp.tris.push(nrm.y as f32);
                bp.tris.push(nrm.z as f32);
            }
        }
    }
}

/// Fills p.bodies: one chamfered solid per piece of the puzzle, found by cutting the outer solid (given as its
/// bounding planes) with every plane that a move turns about.
fn add_solid_bodies(p: &mut Puzzle, outer: &[solid::Plane], gap: f64, chamfer: f64) {
    let mut root = solid::Convex { hs: outer.to_vec(), faces: Vec::new() };
    solid::build_faces(&mut root);
    let cuts = solid::cut_planes(p, &root);
    let cells = solid::cells_of(outer, &cuts, gap);
    for mut cell in cells {
        let mut bp = BodyPiece::default();
        let ctr = solid::convex_centre(&cell); // decides which layers the piece is in
        bp.cls = [ctr.x as f32, ctr.y as f32, ctr.z as f32];
        solid::chamfer_edges(&mut cell, chamfer);
        solid::emit_triangles(&cell, &mut bp);
        p.bodies.push(bp);
    }
}

/// The six bounding planes of an axis-aligned cube of half-width h.
fn cube_planes(h: f64) -> Vec<solid::Plane> {
    let mut out = Vec::new();
    for a in 0..3 {
        for sgn in [-1.0_f64, 1.0_f64] {
            let mut n = solid::vd(0.0, 0.0, 0.0);
            match a {
                0 => n.x = sgn,
                1 => n.y = sgn,
                _ => n.z = sgn,
            }
            out.push(solid::Plane { n, d: h });
        }
    }
    out
}

fn find_sticker(p: &Puzzle, c: V3, n: V3) -> i32 {
    for j in 0..p.stickers {
        if length(centroid_of(p, j) - c) < MATCH_TOL && length(normal_of(p, j) - n) < MATCH_TOL {
            return j as i32;
        }
    }
    -1
}

/// perm[m][j] = i means: after the move, position j shows what position i showed before.
fn build_perms(p: &mut Puzzle) -> bool {
    let s = p.stickers;
    let mut all: Vec<Vec<u8>> = Vec::with_capacity(p.moves);
    for m in 0..p.moves {
        let mv = p.mv[m].clone();
        let mut pm: Vec<u8> = (0..s).map(|i| i as u8).collect();
        let axis = axis_of(&mv);
        let mut in_set = vec![false; s];
        let mut hit = vec![false; s];
        for i in 0..s {
            in_set[i] = in_layer(&mv, centroid_of(p, i));
        }
        for i in 0..s {
            if !in_set[i] {
                continue;
            }
            let c2 = rotate_about(axis, mv.angle_deg, centroid_of(p, i));
            let n2 = rotate_about(axis, mv.angle_deg, normal_of(p, i));
            let j = find_sticker(p, c2, n2);
            // The turning layer must be carried onto itself, one sticker per position.
            if j < 0 || !in_set[j as usize] || hit[j as usize] {
                return false;
            }
            hit[j as usize] = true;
            pm[j as usize] = i as u8;
        }
        all.push(pm);
    }
    p.perm = all;
    true
}

fn build_face_lists(p: &mut Puzzle) {
    p.face_begin = vec![0; p.faces + 1];
    p.face_list.clear();
    for f in 0..p.faces {
        p.face_begin[f] = p.face_list.len();
        for i in 0..p.stickers {
            if p.face_of[i] as usize == f {
                p.face_list.push(i);
            }
        }
    }
    p.face_begin[p.faces] = p.face_list.len();
}

// ------------------------------------------------------------------------------------------ cubes

const FACE_NORMAL: [[f32; 3]; 6] =
    [[0.0, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, -1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, -1.0]];
const FACE_UP: [[f32; 3]; 6] =
    [[0.0, 0.0, -1.0], [0.0, 1.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [0.0, 1.0, 0.0]];
const FACE_RIGHT: [[f32; 3]; 6] =
    [[1.0, 0.0, 0.0], [0.0, 0.0, -1.0], [1.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [-1.0, 0.0, 0.0]];
const FACE_NAME: [char; 6] = ['U', 'R', 'F', 'D', 'L', 'B'];

fn face_vec(table: &[[f32; 3]; 6], f: usize) -> V3 {
    v3(table[f][0], table[f][1], table[f][2])
}

fn build_cube(p: &mut Puzzle, n: i32) {
    p.id = n - 2;
    p.name = format!("{}x{} Cube", n, n);
    p.short_name = format!("{}x{}", n, n);
    p.colors = 6;
    p.faces = 6;
    let half = n as f32 * 0.5;
    let mid = (n - 1) as f32 * 0.5;

    for f in 0..6usize {
        let nrm = face_vec(&FACE_NORMAL, f);
        let up = face_vec(&FACE_UP, f);
        let right = face_vec(&FACE_RIGHT, f);
        for r in 0..n {
            for c in 0..n {
                let ctr = nrm * half + right * (c as f32 - mid) + up * (mid - r as f32);
                let corners = [
                    ctr - right * 0.5 - up * 0.5,
                    ctr + right * 0.5 - up * 0.5,
                    ctr + right * 0.5 + up * 0.5,
                    ctr - right * 0.5 + up * 0.5,
                ];
                add_sticker(p, f as i32, f as i32, &corners, 4);
            }
        }
    }

    // Face turns (the outer layer), then the inner slices counted from U, R and F.
    for f in 0..6usize {
        add_move_pair(p, &FACE_NAME[f].to_string(), face_vec(&FACE_NORMAL, f), 90.0, half - 1.0, half + 0.01);
    }
    for f in 0..3usize {
        for k in 1..=(n - 2) {
            let cc = half - k as f32 - 0.5;
            let name = format!("{}{}", k + 1, FACE_NAME[f]);
            add_move_pair(p, &name, face_vec(&FACE_NORMAL, f), 90.0, cc - 0.5, cc + 0.5);
        }
    }

    // Bodies: one chamfered block per cubie (the cells of the layer planes), a hair apart so layers turn freely.
    add_solid_bodies(p, &cube_planes(half as f64), 0.010, 0.022);

    p.radius = half * 1.7320508 + 0.05;
    p.sticker_inset = 0.03; // dark margin around every sticker, in cubie widths
    p.sticker_round = 0.11; // corner radius of the coloured tile
    p.sticker_lift = 0.006; // tile height above the block

    p.ai_supported = n <= 3;
    if n == 2 {
        for m in 0..6 {
            p.ai_moves.push(m); // U, R, F: the corner D-L-B never moves
        }
        p.default_max_depth = 12;
        p.hidden1 = 128;
        p.hidden2 = 64;
    } else if n == 3 {
        for m in 0..12 {
            p.ai_moves.push(m);
        }
        p.default_max_depth = 16;
        p.hidden1 = 192;
        p.hidden2 = 96;
    }
}

// ------------------------------------------------------------------------------------------ Pyraminx

fn build_pyraminx(p: &mut Puzzle) {
    p.id = K_PYRAMINX;
    p.name = "Pyraminx".to_string();
    p.short_name = "Pyraminx".to_string();
    p.colors = 4;
    p.faces = 4;
    let r: f32 = 2.3;
    let rho = r * 0.942_809_04; // sqrt(8) / 3
    // 0 = U (top), 1 = L, 2 = R, 3 = B
    let vert = [
        v3(0.0, r, 0.0),
        v3(-rho * 0.866_025_4, -r / 3.0, rho * 0.5),
        v3(rho * 0.866_025_4, -r / 3.0, rho * 0.5),
        v3(0.0, -r / 3.0, -rho),
    ];
    // Face f lies opposite vertex f; face 3 is the front face (U, L, R).
    let face_verts: [[usize; 3]; 4] = [[1, 2, 3], [0, 2, 3], [0, 1, 3], [0, 1, 2]];

    for f in 0..4usize {
        let p0 = vert[face_verts[f][0]];
        let mut p1 = vert[face_verts[f][1]];
        let mut p2 = vert[face_verts[f][2]];
        if dot(cross(p1 - p0, p2 - p0), p0 + p1 + p2) < 0.0 {
            std::mem::swap(&mut p1, &mut p2); // counter-clockwise from outside
        }
        let q = |i: i32, j: i32| p0 + (p1 - p0) * (i as f32 / 3.0) + (p2 - p0) * (j as f32 / 3.0);
        for i in 0..3 {
            for j in 0..3 {
                if i + j > 2 {
                    continue;
                }
                let up = [q(i, j), q(i + 1, j), q(i, j + 1)];
                add_sticker(p, f as i32, f as i32, &up, 3);
                if i + j <= 1 {
                    let down = [q(i + 1, j), q(i + 1, j + 1), q(i, j + 1)];
                    add_sticker(p, f as i32, f as i32, &down, 3);
                }
            }
        }
    }

    let layer_names = ["U", "L", "R", "B"];
    let tip_names = ["u", "l", "r", "b"];
    for v in 0..4usize {
        add_move_pair(p, layer_names[v], vert[v], 120.0, r / 9.0, r + 1.0);
        add_move_pair(p, tip_names[v], vert[v], 120.0, 5.0 * r / 9.0, r + 1.0);
    }

    // Bodies: the 15 real pieces (4 tips, 4 axial pieces, 6 edges and the hidden core), cut by the layer planes.
    let mut faces: Vec<solid::Plane> = Vec::new();
    for f in 0..4usize {
        let a0 = vert[face_verts[f][0]];
        let a1 = vert[face_verts[f][1]];
        let a2 = vert[face_verts[f][2]];
        let mut nrm = unit(cross(a1 - a0, a2 - a0));
        if dot(nrm, a0) < 0.0 {
            nrm = nrm * -1.0;
        }
        faces.push(solid::Plane {
            n: solid::vd(nrm.x as f64, nrm.y as f64, nrm.z as f64),
            d: dot(nrm, a0) as f64,
        });
    }
    add_solid_bodies(p, &faces, 0.020, 0.032);

    p.radius = r + 0.05;
    p.sticker_inset = 0.045;
    p.sticker_round = 0.09;
    p.sticker_lift = 0.006;
    p.ai_supported = true;
    for m in 0..p.moves {
        p.ai_moves.push(m);
    }
    p.default_max_depth = 11;
    p.hidden1 = 128;
    p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ Skewb

fn build_skewb(p: &mut Puzzle) {
    p.id = K_SKEWB;
    p.name = "Skewb".to_string();
    p.short_name = "Skewb".to_string();
    p.colors = 6;
    p.faces = 6;
    let s: f32 = 1.5;

    for f in 0..6usize {
        let nrm = face_vec(&FACE_NORMAL, f);
        let up = face_vec(&FACE_UP, f);
        let right = face_vec(&FACE_RIGHT, f);
        let pt = |a: f32, b: f32| (nrm + right * a + up * b) * s;
        let diamond = [pt(1.0, 0.0), pt(0.0, 1.0), pt(-1.0, 0.0), pt(0.0, -1.0)];
        add_sticker(p, f as i32, f as i32, &diamond, 4);
        let t0 = [pt(1.0, 1.0), pt(0.0, 1.0), pt(1.0, 0.0)];
        let t1 = [pt(-1.0, 1.0), pt(-1.0, 0.0), pt(0.0, 1.0)];
        let t2 = [pt(-1.0, -1.0), pt(0.0, -1.0), pt(-1.0, 0.0)];
        let t3 = [pt(1.0, -1.0), pt(1.0, 0.0), pt(0.0, -1.0)];
        add_sticker(p, f as i32, f as i32, &t0, 3);
        add_sticker(p, f as i32, f as i32, &t1, 3);
        add_sticker(p, f as i32, f as i32, &t2, 3);
        add_sticker(p, f as i32, f as i32, &t3, 3);
    }

    // The four corners the solver turns come first; the other four are their opposites.
    let corners: [[i32; 3]; 8] =
        [[1, 1, 1], [1, 1, -1], [1, -1, 1], [-1, 1, 1], [-1, -1, -1], [-1, -1, 1], [-1, 1, -1], [1, -1, -1]];
    for k in 0..8usize {
        let mut name = String::new();
        name.push(if corners[k][1] > 0 { 'U' } else { 'D' });
        name.push(if corners[k][0] > 0 { 'R' } else { 'L' });
        name.push(if corners[k][2] > 0 { 'F' } else { 'B' });
        let axis = v3(corners[k][0] as f32, corners[k][1] as f32, corners[k][2] as f32);
        add_move_pair(p, &name, axis, 120.0, 0.0, 100.0);
    }
    p.play_moves = p.moves; // the sixteen real half-turn twists

    // Free extras that a real Skewb cannot do: turn one corner piece on its own, about its own diagonal. The layer
    // is the slab beyond 1.45 on the corner's axis, which holds exactly the three stickers (and the one solid
    // piece) of that corner. Names are lower case.
    for k in 0..8usize {
        let mut name = String::new();
        name.push(if corners[k][1] > 0 { 'u' } else { 'd' });
        name.push(if corners[k][0] > 0 { 'r' } else { 'l' });
        name.push(if corners[k][2] > 0 { 'f' } else { 'b' });
        let axis = v3(corners[k][0] as f32, corners[k][1] as f32, corners[k][2] as f32);
        add_move_pair(p, &name, axis, 120.0, 1.45, 100.0);
    }

    // Bodies: the 14 real pieces (6 centres and 8 corners), cut by the four planes through the middle.
    add_solid_bodies(p, &cube_planes(s as f64), 0.016, 0.03);

    p.radius = s * 1.7320508 + 0.05;
    p.sticker_inset = 0.045;
    p.sticker_round = 0.10;
    p.sticker_lift = 0.006;
    p.ai_supported = true;
    for m in 0..8 {
        p.ai_moves.push(m); // corners U-R-F, U-R-B, D-R-F, U-L-F; corner D-L-B never moves
    }
    p.default_max_depth = 12;
    p.hidden1 = 128;
    p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ structure

struct UnionFind {
    parent: Vec<usize>,
}

impl UnionFind {
    fn new(n: usize) -> UnionFind {
        UnionFind { parent: (0..n).collect() }
    }
    fn find(&mut self, mut a: usize) -> usize {
        while self.parent[a] != a {
            let gp = self.parent[self.parent[a]];
            self.parent[a] = gp;
            a = self.parent[a];
        }
        a
    }
    fn unite(&mut self, a: usize, b: usize) {
        let a = self.find(a);
        let b = self.find(b);
        if a != b {
            let hi = a.max(b);
            let lo = a.min(b);
            self.parent[hi] = lo;
        }
    }
}

fn share_corner(p: &Puzzle, a: usize, b: usize) -> bool {
    for i in 0..p.vcount[a] as usize {
        for j in 0..p.vcount[b] as usize {
            if length(vertex_of(p, a, i) - vertex_of(p, b, j)) < 1.0e-3 {
                return true;
            }
        }
    }
    false
}

/// Pieces = groups of touching stickers that lie in exactly the same turning layers. Classes = pieces that can
/// change places under the solver's moves. Fixed pieces never move under the solver's moves.
fn build_structure(p: &mut Puzzle) -> bool {
    let sn = p.stickers;
    let mut sig = vec![0u64; sn];
    for i in 0..sn {
        for m in 0..p.moves {
            if in_layer(&p.mv[m], centroid_of(p, i)) {
                sig[i] |= 1u64 << m;
            }
        }
    }
    let mut uf = UnionFind::new(sn);
    for i in 0..sn {
        for j in (i + 1)..sn {
            if sig[i] == sig[j] && share_corner(p, i, j) {
                uf.unite(i, j);
            }
        }
    }
    p.slots.clear();
    p.slot_of = vec![-1; sn];
    let mut comp_slot: Vec<i32> = vec![-1; sn];
    for i in 0..sn {
        let root = uf.find(i);
        if comp_slot[root] < 0 {
            comp_slot[root] = p.slots.len() as i32;
            p.slots.push(Slot::default());
        }
        let si = comp_slot[root] as usize;
        if p.slots[si].n >= 3 {
            return false;
        }
        let at = p.slots[si].n;
        p.slots[si].stickers[at] = i;
        p.slots[si].n += 1;
        p.slot_of[i] = si as i32;
    }

    let n_slots = p.slots.len();
    let mut orbit = UnionFind::new(n_slots);
    for &m in p.ai_moves.iter() {
        let pm = &p.perm[m];
        for i in 0..sn {
            if pm[i] as usize != i {
                orbit.unite(p.slot_of[i] as usize, p.slot_of[pm[i] as usize] as usize);
            }
        }
    }
    let mut class_of_root: Vec<i32> = vec![-1; n_slots];
    p.class_count = 0;
    for s in 0..n_slots {
        let root = orbit.find(s);
        if class_of_root[root] < 0 {
            class_of_root[root] = p.class_count as i32;
            p.class_count += 1;
        }
        p.slots[s].cls = class_of_root[root] as usize;
    }
    // Pieces in one class must all have the same number of stickers.
    let mut class_size: Vec<i32> = vec![-1; p.class_count];
    for s in p.slots.iter() {
        let sz = &mut class_size[s.cls];
        if *sz < 0 {
            *sz = s.n as i32;
        }
        if *sz != s.n as i32 {
            return false;
        }
    }

    p.slot_fixed = vec![true; n_slots];
    for &m in p.ai_moves.iter() {
        let pm = &p.perm[m];
        for i in 0..sn {
            if pm[i] as usize != i {
                p.slot_fixed[p.slot_of[i] as usize] = false;
            }
        }
    }
    true
}

// ------------------------------------------------------------------------------------------ symmetry

type Mat = [i32; 9];

fn mat_mul(a: &Mat, b: &Mat) -> Mat {
    let mut r = [0i32; 9];
    for i in 0..3 {
        for j in 0..3 {
            let mut s = 0;
            for k in 0..3 {
                s += a[i * 3 + k] * b[k * 3 + j];
            }
            r[i * 3 + j] = s;
        }
    }
    r
}

fn build_rotations(p: &mut Puzzle) -> bool {
    let identity: Mat = [1, 0, 0, 0, 1, 0, 0, 0, 1];
    let rx: Mat = [1, 0, 0, 0, 0, -1, 0, 1, 0]; // (x, y, z) -> (x, -z, y)
    let ry: Mat = [0, 0, 1, 0, 1, 0, -1, 0, 0]; // (x, y, z) -> (z, y, -x)
    let mut group: Vec<Mat> = vec![identity];
    let mut at = 0;
    while at < group.len() {
        for g in [rx, ry] {
            let next = mat_mul(&g, &group[at]);
            if !group.contains(&next) {
                group.push(next);
            }
        }
        at += 1;
    }
    if group.len() != 24 {
        return false;
    }

    let sn = p.stickers;
    let mut rotations: Vec<Vec<u8>> = Vec::new();
    for m in group.iter() {
        let apply = |v: V3| {
            v3(
                m[0] as f32 * v.x + m[1] as f32 * v.y + m[2] as f32 * v.z,
                m[3] as f32 * v.x + m[4] as f32 * v.y + m[5] as f32 * v.z,
                m[6] as f32 * v.x + m[7] as f32 * v.y + m[8] as f32 * v.z,
            )
        };
        let mut rot = vec![0u8; sn];
        for j in 0..sn {
            let i = find_sticker(p, apply(centroid_of(p, j)), apply(normal_of(p, j)));
            if i < 0 {
                return false;
            }
            rot[i as usize] = j as u8; // the sticker at j travels to i
        }
        rotations.push(rot);
    }

    // conj[r][m]: the physical move that, applied to the unrotated puzzle, matches solver move m applied to the
    // puzzle rotated by r. perm' = R o perm_m o R^-1 as index maps.
    let mut conj: Vec<Vec<i32>> = vec![vec![-1; p.moves]; rotations.len()];
    for r in 0..rotations.len() {
        let rot = &rotations[r];
        let mut inv = vec![0usize; sn];
        for i in 0..sn {
            inv[rot[i] as usize] = i;
        }
        for &m in p.ai_moves.iter() {
            let mut target = vec![0u8; sn];
            for j in 0..sn {
                target[j] = rot[p.perm[m][inv[j]] as usize];
            }
            let mut found: i32 = -1;
            for q in 0..p.moves {
                if p.perm[q] == target {
                    found = q as i32;
                    break;
                }
            }
            if found < 0 {
                return false;
            }
            conj[r][m] = found;
        }
    }
    p.rotations = rotations;
    p.conj = conj;

    p.ref_stickers.clear();
    for s in 0..p.slots.len() {
        if !p.slot_fixed[s] {
            continue;
        }
        for k in 0..p.slots[s].n {
            p.ref_stickers.push(p.slots[s].stickers[k]);
        }
    }
    !p.ref_stickers.is_empty()
}

fn build(id: i32) -> Puzzle {
    let mut p = Puzzle::default();
    match id {
        K_CUBE2 => build_cube(&mut p, 2),
        K_CUBE3 => build_cube(&mut p, 3),
        K_CUBE4 => build_cube(&mut p, 4),
        K_CUBE5 => build_cube(&mut p, 5),
        K_PYRAMINX => build_pyraminx(&mut p),
        K_SKEWB => build_skewb(&mut p),
        _ => return p,
    }
    if p.play_moves == 0 {
        p.play_moves = p.moves;
    }
    build_face_lists(&mut p);
    let mut ok = p.stickers <= K_MAX_STICKERS && p.moves <= K_MAX_MOVES && build_perms(&mut p);
    if ok && p.ai_supported {
        ok = p.stickers <= K_MAX_AI_STICKERS && build_structure(&mut p);
        p.needs_canon = p.ai_moves.len() < p.moves;
        if ok && p.needs_canon {
            ok = build_rotations(&mut p);
        }
    }
    p.valid = ok;
    p
}

// ------------------------------------------------------------------------------------------ Puzzle

impl Puzzle {
    pub fn ai_move(&self, m: usize) -> bool {
        self.ai_moves.contains(&m)
    }

    pub fn set_solved(&self, s: &mut [u8]) {
        s[..self.stickers].copy_from_slice(&self.solved[..self.stickers]);
    }

    pub fn is_solved(&self, s: &[u8]) -> bool {
        for f in 0..self.faces {
            let b = self.face_begin[f];
            let e = self.face_begin[f + 1];
            let c = s[self.face_list[b]];
            for k in (b + 1)..e {
                if s[self.face_list[k]] != c {
                    return false;
                }
            }
        }
        true
    }

    /// src and dst must not alias.
    pub fn apply(&self, src: &[u8], dst: &mut [u8], mv: usize) {
        let pm = &self.perm[mv];
        for i in 0..self.stickers {
            dst[i] = src[pm[i] as usize];
        }
    }

    pub fn hash(&self, s: &[u8]) -> u64 {
        let mut h: u64 = 1469598103934665603;
        for i in 0..self.stickers {
            h ^= s[i] as u64;
            h = h.wrapping_mul(1099511628211);
        }
        h ^= h >> 29;
        h
    }

    /// Whole-puzzle rotation r applied to a state: out[i] = s[rotations[r][i]].
    pub fn rotate(&self, s: &[u8], r: usize, out: &mut [u8]) {
        if self.rotations.is_empty() {
            out[..self.stickers].copy_from_slice(&s[..self.stickers]);
            return;
        }
        let rp = &self.rotations[r];
        for i in 0..self.stickers {
            out[i] = s[rp[i] as usize];
        }
    }

    /// Index of the rotation that puts the reference piece home (needs_canon), 0 otherwise, -1 if none fits.
    pub fn canon_rotation(&self, s: &[u8]) -> i32 {
        if !self.needs_canon {
            return 0;
        }
        for r in 0..self.rotations.len() {
            let mut matched = true;
            for &i in self.ref_stickers.iter() {
                if s[self.rotations[r][i] as usize] != self.solved[i] {
                    matched = false;
                    break;
                }
            }
            if matched {
                return r as i32;
            }
        }
        -1
    }
}

/// Builds a puzzle once and keeps it for the lifetime of the process. Returns None for a bad id.
pub fn puzzle_by_id(id: i32) -> Option<&'static Puzzle> {
    static CACHE: [OnceLock<Puzzle>; 6] =
        [OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new(), OnceLock::new()];
    if id < 0 || id >= K_PUZZLE_COUNT {
        return None;
    }
    Some(CACHE[id as usize].get_or_init(|| build(id)))
}
