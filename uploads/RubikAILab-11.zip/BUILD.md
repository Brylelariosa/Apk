# Build and test

## Android (the owner's CI)
`./gradlew assembleDebug` (JDK 17, Gradle 8.6, NDK 25.2.9519653, CMake 3.22.1). minSdk 24, framework views only
(no AndroidX). The native library is built from `app/src/main/cpp/CMakeLists.txt`.

## Host tests of the native core (g++, no Android needed)
```
sh tests/run_host_tests.sh          # puzzle tests + engine end-to-end test
sh tests/run_host_tests.sh full     # also the full state-count checks (2x2, Skewb, Pyraminx)
```
`tests/bench.cpp` trains a puzzle for N seconds and prints solve rates:
`g++ -std=c++17 -O3 -fno-math-errno -Iapp/src/main/cpp tests/bench.cpp app/src/main/cpp/core/*.cpp -o bench -pthread`
then `./bench <puzzleId 0..5> <seconds> <threads> [maxDepth] [pool] [maxEpochs] [frontierMix]`.

## Look at the puzzles without a phone (v2.2)
`tests/preview/` has a software renderer that mirrors the app's camera, shading and mesh rules (PuzzleRenderer.kt,
StickerShape.kt) and a Python port of the swipe logic (Picker.kt):
```
g++ -std=c++17 -O1 -Iapp/src/main/cpp tests/preview/dump_geometry.cpp app/src/main/cpp/core/puzzle.cpp -o /tmp/dump_geometry
for i in 0 1 2 3 4 5; do /tmp/dump_geometry $i > /tmp/geo_$i.txt; done
python3 tests/preview/preview.py /tmp/geo_4.txt /tmp/pyraminx.png -42 24        # resting view: yaw pitch
python3 tests/preview/preview.py /tmp/geo_1.txt /tmp/turn.png -35 28 0 0.5      # move 0 half way through its turn
python3 tests/preview/picker_check.py /tmp                                      # picking and swipe-to-move checks
python3 tests/preview/skewb_sweep.py /tmp                                      # Skewb: every corner swipe twists that corner, none dead; taps, holds, near misses (336 views)
python3 tests/sound/make_sounds.py app/src/main/res/raw --report                # regenerate the cube turn sounds (res/raw/turn_*.wav), numpy only
```
Needs numpy and Pillow. If you change the mesh or sticker code in Kotlin, change the Python mirror too.

## What was and was not verified (v2)
- Verified on the host: puzzle geometry and move tables, group facts and state counts, piece structure,
  canonical-frame solving, solver end-to-end on physical scrambles, checkpoint round trip, AddressSanitizer
  and UBSan runs of the tests.
- Verified by script: swipe-to-move maths (Python mirror of gl/Picker.kt) is consistent with the real rotation
  for five puzzles; vector icons render as intended.
- CI run 1868 (release): all four native ABI builds succeeded (one harmless `-Wunused-private-field` warning for
  `Encoder::puzzle_`); Kotlin failed on PlayPage.kt `timerView` init order, fixed in v2.1. No other compiler error was reported.
- NOT verified: the Android build itself. The authoring sandbox had no Android SDK and no Kotlin compiler, so the
  Kotlin code was only linted (imports, brackets) and reviewed by hand. Expect to fix a typo if CI complains.

## Rust core
Needs `cargo` (GitHub ubuntu runners have it). Gradle runs `rustup target add` + `cargo build --release` for the
four ABIs and packages build/rustJniLibs. If it fails, set `useRust=false` in gradle.properties (C++ core).
