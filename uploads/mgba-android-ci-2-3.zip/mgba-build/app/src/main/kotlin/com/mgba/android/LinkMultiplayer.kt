package com.mgba.android

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * GBA Link Cable multiplayer over Wi-Fi (UDP) or Bluetooth (RFCOMM).
 *
 * Wi-Fi protocol — two UDP sockets:
 *   Port 55798  broadcast discovery  (host announces itself every 500 ms)
 *   Port 55799  SIO data exchange    (used only by the game loop thread)
 *
 * Packet layout (8 bytes):
 *   [0..1] magic  "GK"
 *   [2]    type   0=HANDSHAKE 1=DATA 2=KEEPALIVE 3=BYE
 *   [3]    seq    (uint8, wrapping — for out-of-order discard)
 *   [4..7] data   (uint32 LE — GBA SIO payload)
 *
 * jniExchangeData() is the hot path: called by the C SIO driver every time
 * the GBA game initiates a serial transfer.  It sends our data and blocks
 * until the peer replies (≤ 30 ms on local Wi-Fi, ≤ 50 ms on Bluetooth).
 * A timeout returns -1 which the driver maps to 0xFFFF (disconnected peer).
 */
class LinkMultiplayer(private val context: Context) {

    // ── Constants ─────────────────────────────────────────────────────────

    companion object {
        private const val TAG             = "mGBA-Link"
        private const val DISC_PORT       = 55798            // discovery broadcast
        private const val DATA_PORT       = 55799            // SIO data exchange
        private const val MAGIC_G         = 'G'.code.toByte()
        private const val MAGIC_K         = 'K'.code.toByte()
        private const val TYPE_HANDSHAKE  = 0.toByte()
        private const val TYPE_DATA       = 1.toByte()
        private const val TYPE_KEEPALIVE  = 2.toByte()
        private const val TYPE_BYE        = 3.toByte()
        private const val PKT             = 8
        private const val WIFI_XCHG_MS    = 30L
        private const val BT_XCHG_MS      = 50L
        private val BT_UUID               = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val DISC_INTERVAL   = 500L
        private const val HANDSHAKE_TIMEOUT = 15_000L
    }

    // ── State ─────────────────────────────────────────────────────────────

    enum class Mode { NONE, WIFI, BLUETOOTH }

    @Volatile var isConnected  = false
    @Volatile var isHost       = false
    @Volatile var mode         = Mode.NONE

    // Wi-Fi
    private var discSocket:  DatagramSocket? = null   // discovery, background
    private var dataSocket:  DatagramSocket? = null   // SIO exchange, game thread
    private var peerAddr:    InetAddress?    = null
    private var peerDataPort = DATA_PORT
    @Volatile private var txSeq = 0

    // Bluetooth
    private var btSocket:    BluetoothSocket?       = null
    private var btServer:    BluetoothServerSocket?  = null
    private var btIn:        InputStream?            = null
    private var btOut:       OutputStream?           = null

    // Background threads
    private var discThread:  Thread? = null
    private var keepAliveThread: Thread? = null

    // ── Wi-Fi: Host ───────────────────────────────────────────────────────

    fun startWifiHost(
        onReady:     (myIp: String) -> Unit,
        onConnected: () -> Unit,
        onError:     (String)  -> Unit
    ) {
        isHost = true
        mode   = Mode.WIFI

        try {
            val dataSock = DatagramSocket(DATA_PORT)
            dataSocket = dataSock

            val myIp = localIp()
            Handler(Looper.getMainLooper()).post { onReady(myIp) }

            // Broadcast presence + wait for client handshake
            discThread = Thread {
                val bcast  = DatagramSocket(DISC_PORT)
                bcast.broadcast = true
                val ann    = "MGBA_HOST $myIp".toByteArray()
                val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT
                var connected = false

                while (!Thread.currentThread().isInterrupted && !connected
                    && System.currentTimeMillis() < deadline) {
                    // Broadcast announcement
                    bcast.send(DatagramPacket(ann, ann.size,
                        InetAddress.getByName("255.255.255.255"), DISC_PORT))

                    // Listen for handshake on the data socket (100 ms window)
                    dataSock.soTimeout = 100
                    val buf = ByteArray(PKT)
                    val pkt = DatagramPacket(buf, PKT)
                    try {
                        dataSock.receive(pkt)
                        if (isHandshake(buf)) {
                            peerAddr     = pkt.address
                            peerDataPort = pkt.port
                            sendPkt(dataSock, TYPE_HANDSHAKE, 0, 0L,
                                pkt.address, pkt.port)
                            isConnected = true
                            connected   = true
                            startKeepalive()
                            Handler(Looper.getMainLooper()).post { onConnected() }
                        }
                    } catch (_: SocketTimeoutException) { }
                }
                bcast.close()
                if (!connected)
                    Handler(Looper.getMainLooper()).post { onError("No client connected") }
            }.also { it.name = "link-host-disc"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Wi-Fi: discover hosts ─────────────────────────────────────────────

    fun discoverWifiHosts(
        onFound: (List<String>) -> Unit,   // list of "IP:port" strings
        onError: (String) -> Unit
    ) {
        val found = mutableListOf<String>()
        discThread = Thread {
            try {
                val sock = DatagramSocket(DISC_PORT)
                sock.soTimeout = 4000
                val buf = ByteArray(64)
                val pkt = DatagramPacket(buf, 64)
                val deadline = System.currentTimeMillis() + 4000L
                while (System.currentTimeMillis() < deadline) {
                    try {
                        sock.receive(pkt)
                        val msg = String(buf, 0, pkt.length)
                        if (msg.startsWith("MGBA_HOST ")) {
                            val ip = msg.removePrefix("MGBA_HOST ").trim()
                            if (ip !in found) found += ip
                        }
                    } catch (_: SocketTimeoutException) { break }
                }
                sock.close()
                Handler(Looper.getMainLooper()).post { onFound(found) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "Scan error") }
            }
        }.also { it.name = "link-disc"; it.isDaemon = true; it.start() }
    }

    // ── Wi-Fi: Client ─────────────────────────────────────────────────────

    fun connectWifi(
        hostIp:      String,
        onConnected: () -> Unit,
        onError:     (String) -> Unit
    ) {
        isHost = false
        mode   = Mode.WIFI
        try {
            val sock = DatagramSocket()
            sock.soTimeout = 3000
            dataSocket = sock
            val host = InetAddress.getByName(hostIp)
            peerAddr  = host
            peerDataPort = DATA_PORT

            Thread {
                try {
                    // Send handshake, wait for ack
                    repeat(5) {
                        sendPkt(sock, TYPE_HANDSHAKE, 0, 0L, host, DATA_PORT)
                        val buf = ByteArray(PKT)
                        val pkt = DatagramPacket(buf, PKT)
                        try {
                            sock.receive(pkt)
                            if (isHandshake(buf)) {
                                isConnected = true
                                startKeepalive()
                                Handler(Looper.getMainLooper()).post { onConnected() }
                                return@Thread
                            }
                        } catch (_: SocketTimeoutException) { }
                    }
                    Handler(Looper.getMainLooper()).post { onError("Host not responding") }
                } catch (e: Exception) {
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "Connect error") }
                }
            }.also { it.name = "link-client"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────

    fun getBluetoothAdapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)
            ?.adapter

    fun getBondedDevices(): List<BluetoothDevice> =
        getBluetoothAdapter()?.bondedDevices?.toList() ?: emptyList()

    fun startBluetoothHost(onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = true
        mode   = Mode.BLUETOOTH
        Thread {
            try {
                val adapter = getBluetoothAdapter() ?: throw IOException("No BT adapter")
                val server  = adapter.listenUsingInsecureRfcommWithServiceRecord(
                    "mGBA-Link", BT_UUID)
                btServer = server
                val sock   = server.accept(HANDSHAKE_TIMEOUT.toInt())
                server.close()
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT host error") }
            }
        }.also { it.name = "link-bt-host"; it.isDaemon = true; it.start() }
    }

    fun connectBluetooth(device: BluetoothDevice, onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = false
        mode   = Mode.BLUETOOTH
        Thread {
            try {
                val sock = device.createInsecureRfcommSocketToServiceRecord(BT_UUID)
                sock.connect()
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT connect error") }
            }
        }.also { it.name = "link-bt-client"; it.isDaemon = true; it.start() }
    }

    // ── jniExchangeData — HOT PATH, called from C on the game loop thread ─

    /**
     * Called by the C SIO driver inside g_core->runFrame().
     * Sends [localData] to the peer and returns the peer's data.
     * Returns -1 (0xFFFFFFFF unsigned) on timeout or disconnect.
     */
    @Suppress("unused") // called from JNI via g_link_xchg_mid
    fun jniExchangeData(localData: Int): Int {
        return when (mode) {
            Mode.WIFI      -> wifiExchange(localData)
            Mode.BLUETOOTH -> btExchange(localData)
            Mode.NONE      -> -1
        }
    }

    private fun wifiExchange(localData: Int): Int {
        val sock = dataSocket ?: return -1
        val peer = peerAddr   ?: return -1
        val seq  = (txSeq++ and 0xFF).toByte()

        return try {
            sendPkt(sock, TYPE_DATA, seq.toInt(), localData.toLong(), peer, peerDataPort)
            sock.soTimeout = WIFI_XCHG_MS.toInt()
            val buf = ByteArray(PKT)
            val pkt = DatagramPacket(buf, PKT)
            sock.receive(pkt)
            if (buf[0] != MAGIC_G || buf[1] != MAGIC_K || buf[2] != TYPE_DATA) -1
            else ByteBuffer.wrap(buf, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: SocketTimeoutException) { -1 }
        catch (_: Exception)                { -1 }
    }

    private fun btExchange(localData: Int): Int {
        val out = btOut ?: return -1
        val inp = btIn  ?: return -1
        return try {
            val send = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                .put(TYPE_DATA).putInt(localData).array()
            out.write(send); out.flush()
            val deadline = System.currentTimeMillis() + BT_XCHG_MS
            val recv = ByteArray(5)
            var n = 0
            while (n < 5 && System.currentTimeMillis() < deadline) {
                if (inp.available() > 0) n += inp.read(recv, n, 5 - n)
                else Thread.sleep(1)
            }
            if (n < 5 || recv[0] != TYPE_DATA) -1
            else ByteBuffer.wrap(recv, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: Exception) { -1 }
    }

    // ── Disconnect ────────────────────────────────────────────────────────

    fun disconnect() {
        isConnected = false
        discThread?.interrupt();      discThread = null
        keepAliveThread?.interrupt(); keepAliveThread = null

        try { dataSocket?.close() }  catch (_: Exception) {}
        try { discSocket?.close() }  catch (_: Exception) {}
        try { btSocket?.close() }    catch (_: Exception) {}
        try { btServer?.close() }    catch (_: Exception) {}

        dataSocket = null; discSocket = null
        btSocket   = null; btServer   = null
        btIn = null; btOut = null
        peerAddr = null
        mode = Mode.NONE
        Log.i(TAG, "Disconnected")
    }

    // ── Keepalive (prevents UDP NAT timeout on routers) ───────────────────

    private fun startKeepalive() {
        keepAliveThread = Thread {
            while (!Thread.currentThread().isInterrupted && isConnected) {
                try {
                    val sock = dataSocket
                    val peer = peerAddr
                    if (sock != null && peer != null && mode == Mode.WIFI) {
                        sendPkt(sock, TYPE_KEEPALIVE, 0, 0L, peer, peerDataPort)
                    }
                    Thread.sleep(2000)
                } catch (_: Exception) { break }
            }
        }.also { it.name = "link-keepalive"; it.isDaemon = true; it.start() }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    fun localIp(): String {
        val wm = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val ip = wm?.connectionInfo?.ipAddress ?: 0
        if (ip == 0) return "0.0.0.0"
        return "%d.%d.%d.%d".format(ip and 0xFF, ip shr 8 and 0xFF,
            ip shr 16 and 0xFF, ip shr 24 and 0xFF)
    }

    private fun sendPkt(
        sock: DatagramSocket, type: Byte, seq: Int, data: Long,
        addr: InetAddress, port: Int
    ) {
        val buf = ByteBuffer.allocate(PKT).order(ByteOrder.LITTLE_ENDIAN)
            .put(MAGIC_G).put(MAGIC_K)
            .put(type).put(seq.toByte())
            .putInt(data.toInt())
            .array()
        try { sock.send(DatagramPacket(buf, PKT, addr, port)) } catch (_: Exception) {}
    }

    private fun isHandshake(buf: ByteArray) =
        buf.size >= 3 && buf[0] == MAGIC_G && buf[1] == MAGIC_K && buf[2] == TYPE_HANDSHAKE
}
