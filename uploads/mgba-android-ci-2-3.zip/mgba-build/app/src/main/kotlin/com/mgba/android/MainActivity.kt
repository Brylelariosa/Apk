package com.mgba.android

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn:  Button
    private lateinit var linkBtn:     TextView
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    private val buttons     = mutableListOf<ButtonDef>()
    private var controlsTop = 0f
    @Volatile private var pickerLive = false
    private lateinit var link: LinkMultiplayer

    companion object {
        private const val TAG           = "mGBA"
        private const val GAME_FRACTION = 0.52f
    }

    private data class ButtonDef(val rect: RectF, val keyMask: Int, val label: String, val color: Int)

    // ── ROM picker ───────────────────────────────────────────────────────────

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        Thread {
            try {
                val tmp = cacheDir.resolve("rom_loaded.gba")
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                } ?: run { uiToast("Cannot read selected file"); return@Thread }
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)
                Handler(Looper.getMainLooper()).post {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth()
                        val h = EmulatorEngine.nativeGetHeight()
                        frameBitmap = Bitmap.createBitmap(
                            w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        romLoaded = true
                        loadRomBtn.visibility = View.GONE
                        linkBtn.visibility    = View.VISIBLE
                        startGameLoop()
                    } else { uiToast("Unsupported ROM format") }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        link = LinkMultiplayer(this)
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK); textSize = 16f
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })
        linkBtn = TextView(this).apply {
            text = "🔗 Link"; textSize = 13f
            setTextColor(Color.WHITE); setPadding(20, 10, 20, 10)
            setBackgroundColor(Color.parseColor("#44000000"))
            visibility = View.GONE
            setOnClickListener { showLinkDialog() }
        }
        root.addView(linkBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 8 })
        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // ── Surface ───────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) { updateGameMatrix(w.toFloat(), h.toFloat()); if (!running) startGameLoop() }
    }

    // ── Game loop ─────────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bmp = frameBitmap ?: return; val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat(); val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) { buildControlLayout(sw, sh); updateGameMatrix(sw, sh) }
        running = true
        gameThread = Thread {
            val targetNs = 1_000_000_000L / 60
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    EmulatorEngine.nativeSetKeys(currentKeys.get())
                    EmulatorEngine.nativeRunFrame(bmp)
                    renderFrame(bmp)
                    val sleep = (targetNs - (System.nanoTime() - t0)) / 1_000_000L
                    if (sleep > 0L) Thread.sleep(sleep)
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() { running = false; gameThread?.join(500); gameThread = null }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Link cable UI ─────────────────────────────────────────────────────────

    private fun showLinkDialog() {
        if (link.isConnected) {
            AlertDialog.Builder(this).setTitle("Link Connected ✓")
                .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("GBA Link Cable")
            .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi",
                               "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady      = { ip -> uiToast("Waiting…\nIP: $ip"); updateLinkBtn("⏳ Hosting…") },
                        onConnected  = { onLinkConnected(true,  "Wi-Fi") },
                        onError      = { uiToast("Host error: $it"); updateLinkBtn("🔗 Link") })
                    1 -> { updateLinkBtn("🔗 Scanning…")
                           link.discoverWifiHosts(
                               onFound = { hosts ->
                                   if (hosts.isEmpty()) showIpDialog()
                                   else AlertDialog.Builder(this)
                                       .setTitle("Select host")
                                       .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                       .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show() },
                               onError = { showIpDialog() }) }
                    2 -> { updateLinkBtn("⏳ BT Host…")
                           link.startBluetoothHost(
                               onConnected = { onLinkConnected(true,  "Bluetooth") },
                               onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") }) }
                    3 -> { val devs = link.getBondedDevices()
                           if (devs.isEmpty()) { uiToast("No paired devices"); return@setItems }
                           AlertDialog.Builder(this).setTitle("Choose device")
                               .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                   updateLinkBtn("⏳ BT…")
                                   link.connectBluetooth(devs[j],
                                       onConnected = { onLinkConnected(false, "Bluetooth") },
                                       onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") })
                               }.show() }
                }
            }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        updateLinkBtn("⏳ Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it"); updateLinkBtn("🔗 Link") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        updateLinkBtn("🔗 $via ✓")
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        updateLinkBtn("🔗 Link"); uiToast("Disconnected")
    }

    private fun updateLinkBtn(t: String) = Handler(Looper.getMainLooper()).post { linkBtn.text = t }

    // ── Link status overlay ───────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Matrix ────────────────────────────────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp = frameBitmap ?: return; val gameH = sh * GAME_FRACTION
        val scale = minOf(sw / bmp.width, gameH / bmp.height)
        gameMatrix.reset(); gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate((sw - bmp.width * scale) / 2f, (gameH - bmp.height * scale) / 2f)
    }

    // ── Controls ──────────────────────────────────────────────────────────────

    private fun buildControlLayout(sw: Float, sh: Float) {
        buttons.clear(); controlsTop = sh * GAME_FRACTION
        val padH = sh - controlsTop; val btnSz = minOf(padH * 0.24f, sw * 0.084f)
        val abSz = btnSz * 0.94f; val step = btnSz * 1.1f
        val dpCx = sw * 0.18f; val dpCy = controlsTop + padH * 0.52f
        fun pad(dx: Float, dy: Float, m: Int, l: String) = ButtonDef(
            RectF(dpCx+dx-btnSz/2,dpCy+dy-btnSz/2,dpCx+dx+btnSz/2,dpCy+dy+btnSz/2),m,l,Color.parseColor("#555566"))
        buttons += pad(0f,-step,EmulatorEngine.KEY_UP,"▲"); buttons += pad(0f,+step,EmulatorEngine.KEY_DOWN,"▼")
        buttons += pad(-step,0f,EmulatorEngine.KEY_LEFT,"◀"); buttons += pad(+step,0f,EmulatorEngine.KEY_RIGHT,"▶")
        val abCx = sw * 0.82f; val abCy = controlsTop + padH * 0.52f; val abGap = abSz * 1.2f
        buttons += ButtonDef(RectF(abCx+abGap-abSz/2,abCy-abSz/2,abCx+abGap+abSz/2,abCy+abSz/2),EmulatorEngine.KEY_A,"A",Color.parseColor("#CF6679"))
        buttons += ButtonDef(RectF(abCx-abGap-abSz/2,abCy-abSz/2,abCx-abGap+abSz/2,abCy+abSz/2),EmulatorEngine.KEY_B,"B",Color.parseColor("#4FC3F7"))
        val ssW=sw*0.11f;val ssH=sh*0.038f;val ssCy=controlsTop+padH*0.82f;val gap=sw*0.07f
        buttons += ButtonDef(RectF(sw/2f-gap-ssW,ssCy,sw/2f-gap,ssCy+ssH),EmulatorEngine.KEY_SELECT,"SEL",Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw/2f+gap,ssCy,sw/2f+gap+ssW,ssCy+ssH),EmulatorEngine.KEY_START,"STA",Color.parseColor("#444455"))
        val lrW=sw*0.13f;val lrH=sh*0.042f;val lrY=controlsTop+padH*0.06f
        buttons += ButtonDef(RectF(sw*0.03f,lrY,sw*0.03f+lrW,lrY+lrH),EmulatorEngine.KEY_L,"L",Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw-sw*0.03f-lrW,lrY,sw-sw*0.03f,lrY+lrH),EmulatorEngine.KEY_R,"R",Color.parseColor("#444455"))
    }

    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return
        fillPaint.color = Color.parseColor("#CC111122")
        canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)
        val keys = currentKeys.get()
        for (btn in buttons) {
            fillPaint.color = btn.color; fillPaint.alpha = if (keys and btn.keyMask != 0) 220 else 140
            canvas.drawRoundRect(btn.rect, 12f, 12f, fillPaint)
            labelPaint.textSize = (btn.rect.height() * 0.46f).coerceAtLeast(14f)
            canvas.drawText(btn.label, btn.rect.centerX(), btn.rect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        }
    }

    private fun onGameTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> {
                var keys = 0
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i); val y = event.getY(i)
                    for (btn in buttons) if (btn.rect.contains(x,y)) keys = keys or btn.keyMask
                }
                currentKeys.set(keys)
            }
            else -> currentKeys.set(0)
        }
    }

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
