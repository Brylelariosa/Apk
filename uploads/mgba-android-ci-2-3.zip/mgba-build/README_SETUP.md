# mGBA Android

Built and distributed via GitHub Actions.  
Push this ZIP to your `uploads/` folder in the repo — the workflow handles everything else.

---

## How to build

### Via GitHub Actions (normal workflow)

```
uploads/
└── mgba-android.zip   ← push this file; workflow triggers automatically
```

The workflow:
1. Extracts the ZIP, finds `settings.gradle.kts`
2. Downloads `gradle-wrapper.jar` for Gradle 8.6
3. Installs NDK 25.2.9519653 + CMake 3.22.1
4. Runs `./gradlew assembleDebug`

CMake auto-fetches the mGBA 0.10.3 source from GitHub on the first build
(via `FetchContent_Declare`).  The downloaded source lands in `app/.cxx/`
which the workflow caches, so subsequent builds skip the download entirely.

The APK is uploaded as a workflow artifact (retained 30 days).

### Locally (Android Studio)

1. Clone mGBA alongside the project:
   ```bash
   git clone --depth 1 --branch 0.10.3 https://github.com/mgba-emu/mgba.git mgba-core
   ```
   CMakeLists.txt checks for this folder first and skips the FetchContent download.

2. Open the project in Android Studio (Hedgehog+) and hit Run.

---

## Fixes applied vs the original

| File | Change |
|------|--------|
| `MainActivity.kt` | `catch (e: Throwable)` — was `Exception`, which silently missed `UnsatisfiedLinkError` |
| `MainActivity.kt` | Game loop body wrapped in try/catch; surface-recreate restarts the loop |
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` — required alongside `useLegacyPackaging=true` |
| `mgba_jni.c` | `pthread_mutex_t` guards `g_core`/`g_fb` — eliminates race with `nativeDestroy` |
| `mgba_jni.c` | `core->loadConfig(core)` replaces `mCoreLoadConfig(core)` — opts actually applied now |
| `mgba_jni.c` | Stride-correct pixel copy in `nativeRunFrame` — no more row-shift on padded bitmaps |
| `CMakeLists.txt` | FetchContent fallback auto-downloads mGBA 0.10.3 when no local clone is present |
| `CMakeLists.txt` | `--strip-debug` replaces `--strip-all`; `pthread` added to link targets |
| `app/build.gradle.kts` | Removed `-DM_CORE_GB=ON` (was a no-op; FORCE in CMakeLists always won) |
| `gradle-wrapper.properties` | Gradle 8.6 to match the workflow's hard-coded `GRADLE_VERSION="8.6"` |
