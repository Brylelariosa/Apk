# HexManiac Android

A native Android rewrite of [HexManiacAdvance](https://github.com/haven1433/HexManiacAdvance) (HMA),
the C#/WPF hex editor for GBA Pokémon ROM hacking. HMA itself isn't portable (WPF/WinForms are
Windows-only, and its scripting system depends on IronPython) - this rebuilds the feature set
natively in Kotlin, using HMA's source as the reference spec rather than code to reuse.

## Status: Phase 4 - image editor, plus known-table auto-detection

Phase 1 was the foundation (open/view/edit raw bytes, undo/redo, pointer scan). Phase 2 added
table editing. Phase 3 added real PCS text. Phase 4 adds images: GBA LZ77 (de)compression, sprite/
tileset/palette/tilemap `Run` types, and an Image Editor screen with three sub-panels (Sprite,
Palette, Tilemap). A cross-cutting addition after Phase 4 (v7 below) adds anchor names and
auto-detection for known games, closing most of the "why do I have to type an offset" gap between
this port and the original - see that section for the full story and what's still manual.

**Working (Phase 1):**
- Open any file via SAF, view it as a scrollable hex grid (address | hex | tap-to-edit)
- Byte-accurate undo/redo, tracked per edit
- Pointer auto-detection scan (GBA convention: 4-byte LE value, top byte `0x08`/`0x09`,
  value − `0x08000000` = file offset), with detected bytes highlighted in the grid
- Save back to a file via SAF

**Working (Phase 2):**
- Define a table by address + format string (`[hp. attack: name""10 next<>]20` - see
  `TableFormat`'s doc comment for the exact marker syntax and what's deliberately not supported
  yet: enum fields, bit arrays, calculated fields, auto-detected or table-linked element counts)
- Browse it as a scrollable, horizontally-scrollable grid; tap a cell to edit its value
- Numeric, pointer, and text fields (real PCS as of Phase 3 - see below), each validated on write
- Hex viewer, table editor, and text editor all share one ROM session (`RomSessionRepository`) -
  an edit made on any screen is immediately visible, undoable, and included when saving from
  another
- `core-engine` unit tests covering all three phases (pointer round-trip, scanner, undo/redo
  ordering, run containment lookup at boundaries, format-string parsing and its error messages,
  table layout math, every field type's read/write round-trip, PCS encode/decode, free-space
  search, and pointer repointing)

**Working (Phase 3):**
- `PcsString`: real PCS character encoding/decoding - see its doc comment for exactly which parts
  of the real format this covers (every printable character plus the common single-byte and
  multi-byte control codes, all byte-exact) and which it deliberately doesn't (per-game
  color/button/buffer macro names, pixel-width overflow checking)
- Table text fields now decode/encode as real PCS instead of raw Latin-1 - same fields, same
  `TableRun.readText`/`writeText` call sites, just correct now (see the "known rough edges" note
  v3 left about this)
- A new Text Editor screen: type an address, edit the decoded string in a multi-line field, Set
  to write it back
- Auto-repoint: if the saved text's PCS encoding no longer fits in its current slot, it's
  relocated to freshly-found free space and every pointer that targeted the old address is
  rewritten to the new one - all as one atomic, undoable edit (`StringRun.writeText`, backed by
  `Repointer`)

**Working (Phase 4):**
- `Lz77`: the GBA BIOS's LZ77 variant, used to compress nearly every sprite/tileset/tilemap/
  palette in a real ROM - decompress, compress, and compressed-length detection, all byte-exact
  (see its doc comment for the overlapping-copy and odd-offset details that make this easy to get
  subtly wrong)
- `GbaColor`: 15-bit GBA color <-> 32-bit ARGB, matching the original's own asymmetric 5-to-8/
  8-to-5 scaling exactly (see its doc comment for why editing a color and saving it unedited has
  to be a no-op, and why that requires the scale-up and scale-down directions to use *different*
  formulas rather than one reversible one)
- `SpriteRun`, `PaletteRun`, `TilemapRun`: three new `Run` cases, each either raw or
  `Lz77`-compressed, covering sprites, tilesets (the same type - see `SpriteFormat`'s doc comment),
  palettes (including multi-page), and GBA background tilemaps (tile index + flip + palette-page
  per cell). `ImageFormat` parses their format strings (`` `ucs4x4x4` ``/`` `lzs4x4x4` ``,
  `` `ucp4:03` ``/`` `lzp4` ``, `` `ucm4x4x4|<tileset addr>` ``/`` `lzm4x4x4|<tileset addr>` ``) -
  see its doc comment for exactly which parts of HMA's grammar this covers and which it
  simplifies
- A new Image Editor screen (`ui/image/`) with three sub-panels sharing one screen
  (`ImageEditorMode`): define-and-view a sprite/tileset (tap a pixel, type its new palette index),
  a palette (tap a swatch, type its new color as RRGGBB hex), and a tilemap (tap a tile, type its
  new entry as raw hex, with a decoded `tile XX, palette Y, h-flip` breakdown alongside). A sprite
  or tilemap renders with whichever palette is currently open, falling back to a grayscale ramp
  when none is (matching `SpriteTool.CreateDefaultPalette` in the original) - all three panels
  stay open simultaneously so pairing a palette with a sprite doesn't mean losing either one.
  `HexViewerScreen` got an "Images" button next to "Text", same prefill-from-selection pattern as
  the other two
- `core-engine` unit tests for all four phases, now including: LZ77 round trips against hand-
  traced token streams and a hand-constructed compressed blob this code didn't itself produce,
  tile-pixel packing for every supported bit depth, GBA color conversion (including the provable-
  by-construction "edit and revert is a no-op" property), image format-string parsing and its
  deliberate subset, and `SpriteRun`/`PaletteRun`/`TilemapRun` covering multi-page reads, in-place
  writes, and - the highest-risk path - a compressed write that recompresses to a *different*
  size than before and has to relocate and repoint mid-edit

**Not yet implemented** (see the phase order below): maps, code/scripts, patches. As of v7 below,
a recognized ROM's known addresses are auto-named and every address field accepts a name in place
of hex - but only the *name*, not the *shape*: none of the ~800 reference table entries' format
strings are auto-applied, so opening a known table still means typing its format once (see v7's
"known rough edges" for exactly why that part is out of scope, and the README's own "differs from
the original" note on `TableFormat`/`ImageFormat` for what those format strings can't express yet
even if they were). An unrecognized ROM - anything other than an exact-header-match Ruby, Sapphire,
Emerald, FireRed, or LeafGreen, including most romhacks - gets no auto-naming at all. The backend
for naming your own discoveries already exists (`RomSessionRepository.nameAddress`, tested via
`RomDataModel`'s anchor tests) but nothing in the UI calls it yet - see v7's "known rough edges"
for that gap specifically. PCS's per-game macro names (`[player]`, color codes, button names)
aren't decoded to friendly text either - see `PcsString`'s doc comment for the byte-exact fallback
that stands in for them.

## Architecture

Two modules, one direction of dependency:

```
core-engine/   pure Kotlin/JVM, zero Android dependency
  model/       Run (sealed interface): UnknownRun, PointerRun, TableRun, StringRun,
               SpriteRun, PaletteRun, TilemapRun
               FieldSegment (sealed interface): NumericField, PointerField, TextField
               RomDataModel (runs + anchors), PointerScanner, TableFormat (format-string parser)
               PcsString (PCS text encode/decode), Repointer (free-space search + repointing)
               Lz77 (GBA LZ77 codec), GbaColor (15-bit <-> ARGB), ImageFormat (sprite/
               palette/tilemap format-string parser)
               GameCode (ROM header -> game version), KnownTables (per-game name+address
               reference data)
  resources/   tableReference.txt - bundled verbatim from the original source; see KnownTables
  undo/        ModelDelta, UndoRedoStack

app/           Android application (Compose, Material3, Hilt)
  data/        RomSessionRepository - single shared source of truth for the loaded ROM
  ui/          HexManiacApp (screen router), HexManiacTopBar, EmptyRomState,
               HexViewerViewModel, HexViewerScreen, theme/
  ui/table/    TableEditorViewModel, TableEditorScreen
  ui/text/     TextEditorViewModel, TextEditorScreen
  ui/image/    ImageEditorViewModel, ImageEditorScreen
```

`core-engine` doesn't know Android exists, on purpose - it's plain JVM, so its tests run in
milliseconds with no emulator, and it stays reusable if a desktop or CLI front end ever makes
sense. `app` depends on it; never the reverse.

**Where this deliberately differs from the original:**
- `Run` is a Kotlin `sealed interface` (`UnknownRun`, `PointerRun`, `TableRun`, `StringRun`, and
  now `SpriteRun`/`PaletteRun`/`TilemapRun`). Nothing switches over every case at once today (see
  `Run`'s doc comment), but the day something does, an exhaustive `when (run)` fails to compile
  until updated for a new case - HMA's C# base-class version doesn't get that check for free.
  `FieldSegment` (a table row's fields: `NumericField`/`PointerField`/`TextField`) is sealed for
  the same reason.
- All byte mutation is `internal` on `RomDataModel`; the only public write path is through a
  `ModelDelta`. It's not possible to accidentally make a non-undoable edit. Table field writes
  (`TableRun.writeNumeric`/`writePointerField`/`writeText`), `StringRun.writeText`, and now
  `SpriteRun.setPixels`/`PaletteRun.setColors`/`TilemapRun.writeEntry` are all built on the same
  `ModelDelta` contract, not a parallel one - true even for the repoint case every one of the
  latter four can hit, where freeing the old bytes, writing the new ones, and rewriting every
  pointer that targeted the old address all happen inside one `ModelDelta`.
- Repointing a string - or, as of this phase, a compressed sprite/palette/tilemap - that's
  outgrown its slot finds new free space and rewrites every reference to it via one live linear
  scan (`Repointer.repointReferences`), not a persisted reverse-pointer index - `PointerScanner`'s
  own doc comment already covers why this project doesn't keep one of those. Same cost class as
  the pointer-scan button the app already has, just triggered by Save instead of Scan.
- Pointer-highlight membership uses `BitSet` instead of a boxed `Set<Int>` - relevant once a ROM
  (up to 32MB) has a dense pointer table; one bit per byte instead of ~20 bytes per entry.
- The ROM session (bytes, runs, undo history) moved out of `HexViewerViewModel` and into
  `RomSessionRepository`, a `@Singleton` every screen's ViewModel injects, once a second screen
  (the table editor) needed the same ROM. Each ViewModel still owns its own screen-local state
  (selection, form text, status message) and pulls fresh shared state from the repository
  imperatively - explicitly on mutation, and via a `syncFromSession()` call at the moment a
  screen becomes visible again - rather than reactively via `StateFlow`/`collectAsState`. That
  keeps this at zero new dependencies; if a screen's state needs finer-grained reactivity than
  "resync on becoming visible," that's the point to reconsider it.
- Screen switching (`HexManiacApp`) is a hand-rolled sealed-interface + `when`, not Jetpack
  Navigation Compose - see that file's doc comment for why, and when to revisit it. The Image
  Editor's Sprite/Palette/Tilemap switch is a level below that, inside `ImageEditorUiState`, since
  none of the three ever needs to survive independently of the screen the way the top-level
  screens do (see `ImageEditorMode`'s doc comment).
- `SpriteRun` covers both what HMA calls a sprite and what it calls a tileset - the same
  `Run`/format handles a standalone image and a tilemap's source tiles, rather than two classes
  sharing static pixel-packing helpers the way `SpriteRun`/`TilesetRun` do in the original. A
  tilemap identifies its tileset - and a palette identifies which slice of a larger virtual
  palette it occupies - by raw hex address rather than an anchor name, the same substitution
  tables and strings already make; see `ImageFormat`'s doc comment for the complete list of what
  else this project's format-string grammar simplifies out of HMA's.
- `SpriteRun.create`/`PaletteRun.create`/`TilemapRun.create` all validate that `start + length`
  fits the model before handing back a `Run`, even for the uncompressed case where the original
  has nothing to check that against (a compressed run's length is self-limited by
  `Lz77.compressedLength` never reading past the model's end; an uncompressed one's isn't, since
  it comes straight from the format). Small, but it turns a wrong-tile-count typo into a caught
  `ImageFormatException` at definition time instead of an out-of-bounds read the first time
  something tries to decode it.
- Known-table auto-detection (v7) loads name+address pairs from a bundled copy of the original's
  own `tableReference.txt`, but stops there rather than also applying each entry's format string -
  see `KnownTables`'s doc comment for why translating ~800 format strings written in HMA's full
  `ArrayRun` grammar is a separate, much larger undertaking than this project's own simplified
  `TableFormat`/`ImageFormat` DSL was to begin with, and out of scope for the same reason a wider
  format grammar has been all along.

## Build order (why this order)

1. **Data engine + hex viewer** *(done)* - nothing else works without it
2. **Table editor** *(done)* - Pokémon/move/item/trainer grids; highest value-to-effort,
   most-used day to day. Format-string-driven and manually addressed for now (see Status above);
   auto-detected/named tables are a natural follow-up but aren't required to make this useful.
3. **Text editor** *(done)* - PCS string encoding, auto-repoint on edit
4. **Image editor** *(this phase)* - sprites, tilemaps, palettes
5. **Map editor** - maps, events, connections, warps, wild encounters
6. **Code editor + patch DSL** - Thumb disassembler, event/battle/AI scripts, the `.hma` patch
   format - hardest subsystem, saved for once the engine's proven under real use

IronPython's live-scripting console (table automation) has no clean Android equivalent and isn't
scoped into any phase yet; it's the one piece of the original worth deferring rather than
matching feature-for-feature.

## Building

Same pipeline as the rest of the projects - zip this folder, push through ZipApkBuilder. No NDK/
CMake needed (pure Kotlin, no native code), though the workflow installing them anyway is
harmless. Toolchain: JDK 17, Gradle 8.6, AGP 8.4.0, Kotlin 2.0.0.

Local validation note: this sandbox had a JRE but no `javac`/network, so the core algorithms
(pointer encode/decode, scanning, undo/redo ordering, run lookup at boundaries) were verified with
a throwaway Python harness before the Kotlin was written, then ported into the real `core-engine`
tests above. Gradle/Kotlin compilation itself only happens for real in CI, which is where the two
issues below actually surfaced.

## v2 - CI fixes + APK size pass

**Fixed, from run 1559's failure log:**
- `HexViewerScreen.kt` explicitly imported `androidx.compose.foundation.layout.weight`. That path
  resolves to Compose Foundation's *internal* `RowColumnParentData.weight` property, not the
  `ColumnScope`/`RowScope` member extension the code actually wants - hence
  `Cannot access 'val RowColumnParentData?.weight: Float': it is internal in file`. Fix: delete the
  import. `Modifier.weight(1f)` needs no import at all inside a `Column`/`Row` content lambda; it
  resolves via the implicit `ColumnScope`/`RowScope` receiver. (This is the same class of bug as
  Outcrop's outstanding `.weight(1f)` import error - worth checking there too.)
- `TopAppBar` is `@ExperimentalMaterial3Api` in Compose BOM 2024.06.00, which is a hard compile
  error without an opt-in, not just a warning. Fix: `@OptIn(ExperimentalMaterial3Api::class)` on
  `HexViewerScreen`.

**APK size, no features removed, no ABI split:**
- ABI splits wouldn't do anything here anyway - there's no native code/JNI, so there's nothing
  architecture-specific being bundled in the first place.
- `isMinifyEnabled = true` + `isShrinkResources = true` for release only (debug stays fast/
  unminified for iteration). This is the actual lever: R8 strips unreachable code, which matters
  most for `material3` since the app only calls a handful of its components, and shrinkResources
  drops resources nothing reachable references. `proguard-rules.pro` documents why this is safe
  for this codebase specifically (no reflection, no serialization, vanilla Hilt usage that its own
  consumer rules already cover) and keeps source-file/line-number info so release crashes still
  produce a readable stack trace.
- `resourceConfigurations += setOf("en")` in `defaultConfig` - the app has zero i18n of its own, so
  this only drops *other libraries'* bundled non-English strings (mostly accessibility labels),
  not anything the app presents. Flagging this one specifically since it's the one change here
  that's a real trade-off rather than a pure win: a non-English device will see those library
  labels fall back to English instead of their own language.
- No dependency changes needed - `material-icons-extended` was already avoided (see `app/build.gradle.kts`).

Compiles cleanly against the CI log's actual failure now; the R8 config is reasoned through but,
same as everything Gradle-related, not locally build-tested (no network in this sandbox) - worth
double-checking the release APK actually launches and behaves correctly on-device, not just that
CI goes green, since R8 issues are sometimes runtime-only.

## v3 - Phase 2: table editor

**New in `core-engine`:** `FieldSegment` (`NumericField`/`PointerField`/`TextField`), `TableFormat`
(the `[name.]N`-style format-string parser - deliberate subset, see its doc comment), `TableRun`
(the row-major table `Run` plus typed field read/write). `RomDataModel.readPointer`/`writePointer`
were refactored to share a new `internal readLittleEndian`/`writeLittleEndian` pair with table
numeric fields, instead of each re-deriving little-endian byte packing - behavior-preserving
(same bounds checks, same GBA-address validation stays on the pointer-specific methods), covered
by the existing pointer tests plus new ones for the shared primitive via table fields.

**New in `app`:** `RomSessionRepository` (`data/`) is now the single owner of the loaded ROM;
`HexViewerViewModel` was refactored to delegate to it rather than hold the model/undo stack
itself - its public API to `HexViewerScreen` is unchanged, so that screen needed no changes
beyond a new "Tables" button. `TableEditorViewModel`/`TableEditorScreen` (`ui/table/`) are new:
address+format form when no table is open, otherwise a scrollable editable grid. `HexManiacApp`
is a new small root composable that switches between the two screens and keeps them in sync with
the repository - see its doc comment for why that's a hand-rolled sealed `when` rather than
Navigation Compose (short version: zero new dependency versions to get wrong in a sandbox with no
way to compile-check them, for a two-screen app that doesn't need a real back stack yet).

**Known rough edges, honestly:**
- Table editor has no Save button of its own - go back to the hex viewer to save, since both
  screens share the same ROM bytes anyway. Small, but worth a real button if this gets used a lot.
- Text fields are raw Latin-1 with a `0xFF` terminator, not the game's actual PCS character map
  (that's Phase 3). The byte-level contract (terminator + zero padding) is deliberately the same
  one PCS will use, so upgrading a field's decoding later shouldn't change what's on disk.
- No enum-typed fields (e.g. a move's type rendered by name instead of a raw byte), bit arrays,
  or calculated fields - `TableFormat` throws a specific message rather than misparsing these.
- Table *recognition* is manual (you type the address + format); there's no hardcoded/per-game
  table database like HMA's own. Once defined, a table is remembered for the rest of the session
  (`RomSessionRepository` keeps it in the model's `runs`), just not before that.

Same caveat as v2, worth repeating rather than assuming it stopped applying: this sandbox has a
JDK but no Android SDK, no Gradle, and no network, so none of this was actually compiled here.
Every method signature this phase depends on (`ModelDelta.setByte`, `RomDataModel.get`/
`readPointer`/`writePointer`, `UndoRedoStack.push`, `Run`'s properties) was checked against the
real Phase 1 source rather than assumed, and the new engine logic (format parsing, table layout
math, every field type's read/write) has direct unit test coverage - but the same
build-verification gap as always applies to the Compose/Hilt wiring specifically. Worth a real
`./gradlew build` (or a CI run) before trusting it further, same as v2 was.

## v4 - top bar title fix + table editor Save

**Fixed:** the title in every screen's top bar was wrapping one or two characters per line
("HexManiac" as "He" / "xM" / "ani" / "ac") instead of displaying normally. Root cause: Material3's
`TopAppBar` measures its `actions` slot first, at up to the bar's *entire* width, and only gives
`title` whatever's left over (`TopAppBarLayout` in Material3's `AppBar.kt`) - harmless for a
couple of icon buttons, but both screens' actions are full-width text buttons in a
`horizontalScroll` row, and on a narrow phone their natural width claims nearly the whole bar,
leaving the title only a handful of pixels to wrap into. Fix: `HexManiacTopBar` (`app/ui/`), a
small composable shared by both screens - title on its own full-width row, the scrollable actions
row below it, so the title can't be starved no matter how many actions a future screen adds.
Bonus: this also drops the `TopAppBar`/`ExperimentalMaterial3Api` opt-in both screens needed (see
the v2 notes on why that opt-in existed in the first place) - one less experimental API this BOM
could break on a future bump.

**New:** the table editor now has its own Save button, wired to the same `onSaveRomRequested`
callback (and so the same `RomSessionRepository`-backed SAF write) the hex viewer already used -
closes the "no Save button of its own" rough edge the v3 notes flagged. `HexManiacApp` now threads
`onSaveRomRequested` to both screens instead of just the hex viewer; `MainActivity` needed no
changes, since that callback was already screen-agnostic.

Same caveat as v2 and v3: this sandbox still has no Android SDK, no Gradle, and no network, so
none of this was compiled here either - `HexManiacTopBar`'s Compose usage (a real `Row`/`Column`
this time, not `TopAppBar`'s internal layout, so `Modifier.weight` resolves the normal way) was
checked by hand against the same Material3 BOM the rest of the app targets, but a real
`./gradlew build` is worth running before trusting it further.

## v5 - Phase 3: text editor

**New in `core-engine`:** `PcsString` (PCS character encode/decode - see its doc comment for the
exact subset covered), `StringRun` (a free-floating PCS string `Run`, plus `readText`/`writeText`
extensions - the latter does the actual auto-repoint), `Repointer` (`findFreeSpace` +
`repointReferences`, the two primitives `writeText` composes). `RomDataModel` gained `removeRun`,
the inverse of the existing `addRun` - needed once a run's address can change out from under it
(a relocated string), which nothing before this phase did. `TableRun.readText`/`writeText` now
delegate to `PcsString` instead of the raw-Latin-1 placeholder from v3 - same call sites, same
byte-level contract (terminator + zero padding), different (correct) byte values, which is exactly
what the v3 notes said this upgrade would mean. One existing test checked a raw byte value
directly rather than going through `readText`; updated to the real PCS value instead of just
made to pass.

**New in `app`:** `TextEditorViewModel`/`TextEditorScreen` (`ui/text/`) - address form when
nothing's open, otherwise a multi-line editable field and a Set button, following the same
open/edit/status-message shape `TableEditorViewModel` already established. `HexViewerScreen` got
a "Text" button next to "Tables", passing the current hex-grid selection through as a prefill
address, same pattern "Tables" already used. `HexManiacApp` grew a third `HexManiacScreen` case -
still a flat `when`, no more reason to reach for Navigation Compose with three screens than with
two (see that file's updated doc comment). Two small extractions along the way, same spirit as
`HexManiacTopBar` last pass: `EmptyRomState` (Table Editor's "no ROM loaded" body) moved to
`app/ui/` so Text Editor could use it too instead of a second copy; `TableEditorViewModel` now
catches `PcsEncodingException` around its text-field write, the same way it already caught
`TableFormatException` around table definition - a real fix, not new scope: `TableRun.writeText`
can throw that now that it runs real PCS encoding, and an uncaught exception there would have
crashed the screen on the first unsupported character someone typed into a name field.

**Known rough edges, honestly:**
- PCS's per-game macro layer - `[player]`/`[rival]`/buffer-variable names, per-game color codes,
  button-icon names - isn't decoded to a friendly name; those bytes round-trip byte-exactly as
  raw hex escapes instead (`\CC`, `\btn`, ...). Naming them needs a detected game code and
  per-game tables this project doesn't have yet. See `PcsString`'s doc comment for the complete
  list of what is and isn't covered.
- Table field text truncation (when saved text is longer than the fixed-width slot) is
  byte-level, not escape-aware - content that used a multi-byte PCS escape right at the cut point
  could truncate mid-escape. Free-floating strings don't have this problem (they repoint instead
  of truncating); only table cells do, and only ones long enough to hit the limit in the first
  place, which named/labeled fields rarely are.
- String *recognition* is manual, same as tables - type the address, no hardcoded per-game string
  table. Once opened, a string is remembered for the rest of the session, same as a table.
- A relocated string's *new* run registration isn't itself undoable, only the underlying bytes
  are - hit undo after a repoint and the bytes correctly revert, but the session may still show
  the string "open" at its new (now-reverted-away-from) address until you navigate back to the
  old one. `TableEditorViewModel.defineTable`'s own run registration already wasn't undoable
  either (see v3); this phase inherits that rather than fixing it, since fixing it for real means
  threading run-registration changes through `ModelDelta` too - a bigger change than this phase's
  scope.
- `findFreeSpace` treats any run of 0xFF bytes not already claimed by a registered `Run` as
  available. That's the right convention for GBA ROMs (unused space is 0xFF-filled - it's also
  why 0xFF is the PCS terminator), but this app doesn't recognize every byte's purpose yet, so a
  region that's genuinely meaningful data, happens to be 0xFF, and hasn't been scanned or defined
  as a run could theoretically be treated as free. Same class of risk as HMA's own free-space
  search, not something new here.

Same caveat as v2 through v4: this sandbox still has no Android SDK, no Gradle, and no network, so
none of this was compiled here either. The PCS character table was transcribed by hand from HMA's
own `pcsReference.txt`/`PCSString.cs` and checked byte-range-by-byte-range against them rather
than retyped from memory; `PcsString`, `Repointer`, and `StringRun`'s tests trace concrete byte
sequences end to end (not just round-trip through the code's own encode/decode, which can hide a
bug that's wrong the same way in both directions) - but the Compose/Hilt wiring has the same
unverified-by-compiler status it always has here. Worth a real `./gradlew build` before trusting
any of this further, same as every phase before it.

## v6 - Phase 4: image editor

**New in `core-engine`:** `Lz77` (GBA BIOS LZ77 variant - `decompress`/`compress`/
`compressedLength`, transcribed from `LZRun.cs` line by line rather than reused, since it's C#).
`GbaColor` (raw 15-bit GBA color <-> 32-bit ARGB). `ImageFormat` plus its three format structs
(`SpriteFormat`, `PaletteFormat`, `TilemapFormat`) - the format-string parser and the deliberate
subset it covers, same relationship `TableFormat` has to `FieldSegment`. Three new `Run` cases:
`SpriteRun` (doubles as a tileset - see its and `SpriteFormat`'s doc comments), `PaletteRun`,
`TilemapRun` (`TilemapEntry` for the packed per-cell tile/flip/palette record, plus `readEntry`/
`writeEntry`/`getPixels` - the last resolving and compositing a paired tileset, with a graceful
blank-grid fallback if it isn't defined yet, matching `LzTilemapRun.GetPixels`'s own fallback in
the original). All three factories validate the run fits the model before returning it - see the
Architecture section's note on why that's new here even though the equivalent check already
existed implicitly for compressed data.

Every algorithmic piece here - the LZ77 codec's bit-level token format, the 1/2/4/8bpp tile <->
pixel packing, the raw-color <-> ARGB channel math, the tilemap entry's bit layout - was
independently verified with a throwaway Python harness (round trips, hand-traced token sequences,
a hand-constructed compressed stream this code didn't itself produce, a full pixel/flip/palette-
offset composition traced by an independent second implementation of `getPixels`' logic) before
being trusted in the Kotlin, the same practice the v2 notes describe using for Phase 1's own
bit-level logic - warranted doubly here, since a wrong bit shift or an off-by-one in a nibble
offset produces a plausible-looking image instead of an obvious crash. That process caught two
real mistakes before they became permanent: a wrong expected value in an early `Lz77Test` case
(hand arithmetic said "AB", the harness said "ABAB" - the harness was right), and a test that
placed a 64-byte tileset and a 4-byte tilemap at overlapping ROM addresses in the same model.

**New in `app`:** `ImageEditorViewModel`/`ImageEditorScreen` (`ui/image/`) - three sub-panels
(`ImageEditorMode`: Sprite, Palette, Tilemap) sharing one screen and one `ImageEditorUiState`,
each following the same define-then-edit shape as Table/Text Editor. A sprite/tileset renders as
a real `android.graphics.Bitmap` (via `PixelGridImage`) rather than a grid of individual
Composables the way the hex viewer's byte grid does - at up to tens of thousands of pixels for a
full tileset or tilemap, that's both faster to compose and a visually correct scaled image rather
than a wall of boxes; `FilterQuality.None` keeps it crisp instead of blurred when scaled up.
Editing stays at the same granularity as every other screen: tap a pixel/swatch/tile, type its
new value as hex, Set. `HexViewerScreen` got an "Images" button next to "Text", same prefill
pattern as before. `HexManiacApp` grew a fourth `HexManiacScreen` case, still a flat `when`.

**Known rough edges, honestly:**
- Editing a sprite/tileset's pixels or a tilemap's per-cell entries is graph-paper-precise (tap a
  cell, type a value) rather than drag-to-paint or a color picker - matches every other editor's
  interaction model in this app (type hex, Set) and needed no new gesture code beyond a single
  tap, but it's slower for genuinely redrawing a sprite than HMA's own click-and-drag canvas.
- No full-image import/export (PNG in, indexed-and-retiled PNG out). HMA's own version of that
  needs a tile-deduplication/matching pass (`GetUniqueTiles`/`FindOrAddTile` in the original) this
  phase doesn't implement; today's editor works directly on tiles/colors/entries already in the
  ROM, not on an external image file.
- The 1-byte-per-tilemap-entry legacy format isn't supported, only the standard 2-byte layout -
  see `TilemapRun`'s doc comment.
- Same run-registration-vs-undo caveat v5 already documented for a relocated string applies here
  too, for the identical reason: `SpriteRun.setPixels`/`PaletteRun.setColors`/
  `TilemapRun.writeEntry`'s relocate case re-registers the run inside the same `applyEdit` call
  (see `ImageEditorViewModel`'s doc comment), and that registration change isn't itself part of
  the `ModelDelta` that undo/redo operates on.
- Sprite/tileset and tilemap pairing with a palette is manual and address-based, consistent with
  table/string recognition elsewhere in this app - see the Architecture section and `ImageFormat`'s
  doc comment for what this simplifies out of HMA's own hint/anchor system.

Same caveat as v2 through v5: this sandbox still has no Android SDK, no Gradle, and no network -
Compose/Hilt wiring, the exact `detectTapGestures`/`Image`/`ButtonDefaults.textButtonColors`
signatures used in `ImageEditorScreen`, and `Bitmap.createBitmap`'s behavior on-device, all have
the same unverified-by-compiler status every phase before this one has had. What *could* be
checked outside Gradle - every core-engine algorithm above - was, with an independent Python
implementation rather than by re-reading the Kotlin and convincing myself it was right. Worth a
real `./gradlew build` before trusting any of this further, same as every phase before it.

## v7 - known-table auto-detection + anchors

Prompted by a fair question: does the original really make you type a hex offset to look at
`data.pokemon.names`? No. Digging into the source turned up the actual mechanism, and this
version closes most (not all - see below) of the gap between it and what v1 through v6 built.

**How the original actually does it:** every GBA cartridge has a standard 5-character header field
identifying its exact build (`GameCode` below - not Pokemon-specific, every GBA game and emulator
reads the same two header offsets). HMA ships a reference file
(`Models/Code/tableReference.txt`, ~800 lines) mapping known table/sprite/palette names to their
exact hex address in each of 9 official ROM versions - vanilla Ruby, Sapphire, Emerald, FireRed,
LeafGreen, and their 1.1 patches. On opening a ROM, it reads the header, looks up that exact
version in the reference file, and auto-labels every address it has on record. Nothing more
magical than a big lookup table keyed by an exact ROM identity - which is also exactly why it
only works for those 9 specific builds and not, say, a romhack based on one of them with things
moved around.

**New in `core-engine`:**
- `GameCode`: reads the header field above (`0xAC`/`0xBC`) and maps it to a display name for the
  5 base games (`AXVE0`/`AXPE0`/... -> "Ruby"/"Sapphire"/...) - reference: `GetGameCode` in the
  original's `IDataModel.cs`
- `KnownTables`: parses the name+address columns of a bundled, byte-verified-identical copy of
  the original's own `tableReference.txt` (`core-engine/src/main/resources/`) - copied rather than
  retyped, since hand-transcribing ~800 hex addresses is exactly the kind of mistake this
  project's Python-verification habit exists to catch, and copying the original file outright
  can't have that particular mistake. Deliberately doesn't touch the format-string column - see
  its doc comment and the Architecture section's new bullet for why that's a separate, much
  larger undertaking than parsing hex out of a CSV column
- `RomDataModel` gained anchor storage: `setAnchor`/`removeAnchor`/`anchorAt`/`addressForAnchor`,
  bidirectional and O(1) both ways, with the same "metadata, not a content edit, so not on the
  undo stack" reasoning `addRun`/`removeRun` already established (now actually documented on
  `addRun` itself, which - turns out - hadn't been)
- `ImageFormat.parseTilemap` gained an optional `resolveAddress` callback so a tilemap's embedded
  tileset reference (`` `ucm4x4x4|data.some.tileset` ``) can resolve a name too, without the
  parser itself needing to know `RomDataModel` exists - every existing call site and test that
  only ever passed hex keeps working unchanged, since the default never resolves anything

**New in `app`:**
- `RomSessionRepository.load` now reads the game code and auto-anchors every matching
  `KnownTables` entry that fits the loaded ROM's size, before the ROM is even handed back to the
  UI
- `RomSessionRepository.resolveAddress(text)`: the one place "hex or anchor name" gets decided,
  used by all three editors' address fields so this doesn't get implemented three slightly-
  different ways
- Table/Text/Image editors: address fields now say "hex or name," resolve through
  `resolveAddress`, and show the known anchor name (if any) in the status line once something's
  open - e.g. opening a table shows `data.pokemon.names - 386 rows x 1 fields.` instead of just
  the row/field counts
- The hex viewer's title bar shows the recognized game name next to the file name (e.g.
  `pokeemerald.gba (Emerald)`) as visible confirmation that detection worked, and its status line
  says so explicitly right after loading

**Known rough edges, honestly:**
- Format strings aren't auto-applied - opening a known table still means typing its format once,
  same as before v7, just no longer needing to hunt down its address first. See the Architecture
  section's new bullet and `KnownTables`'s doc comment for exactly why.
- No UI yet for naming your *own* discoveries on an unrecognized ROM. The backend
  (`RomSessionRepository.nameAddress`, backed by `RomDataModel.setAnchor`) is written and tested,
  but nothing calls it - the natural next step is a small "name this address" affordance in each
  editor's already-open view, not a new concept.
- Only the 9 exact vanilla-plus-1.1-patch header matches get auto-detection, same limitation the
  original has for the same reason (see "how the original actually does it" above) - a romhack,
  a translation patch, or a ROM with an edited header gets none of it, even if its data is 99%
  identical to a game that would.
- `resolveAddress`'s hex-vs-name disambiguation (anchor names always contain a `.`, which is
  never valid hex) hasn't needed to handle an edge case where that's not true, because nothing in
  `KnownTables` or this app's own naming ever produces a dot-free name - worth a real check if a
  future phase lets names be freeform.

Same caveat as every phase before it: no Android SDK, no Gradle, no network here, so
`RomSessionRepository`'s wiring and the Compose changes to three screens' address fields are
unverified by any compiler. What could be checked without one - `GameCode`'s header math,
`KnownTables`'s CSV-ish parsing (including a hand-checked UTF-8 BOM on the reference file's first
line, and a deliberately comma-containing format-string column to confirm it doesn't disturb the
address columns before it), and `RomDataModel`'s new anchor bookkeeping - has real `kotlin.test`
coverage now, same bar every prior phase set. Worth a real `./gradlew build`, and worth manually
confirming against a real Ruby/Sapphire/Emerald/FireRed/LeafGreen ROM that at least a handful of
the ~800 bundled addresses still line up - copying the reference file correctly and reading the
header correctly are each verified, but nothing in this sandbox could load an actual ROM to check
the two together end to end.
