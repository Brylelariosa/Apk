package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * A PCS-encoded text string: content bytes from [start] up to and including the 0xFF terminator
 * - so [length] already covers the terminator, the same convention [PointerRun]'s fixed length
 * and [TableRun]'s element length both follow. Mirrors HexManiacAdvance's PCSRun, minus the
 * font-width/overflow bookkeeping that belongs to a real in-game text renderer, which this isn't.
 *
 * Like every [Run], immutable: [writeText] returns a new [StringRun] rather than mutating this
 * one in place, since a repoint changes [start] and [length] both. Callers must re-register the
 * result themselves (`model.removeRun`/`model.addRun`) - that step, unlike the byte writes
 * [writeText] already makes through its [ModelDelta], isn't part of undo. [RomDataModel.addRun]
 * is a plain mutation with no [ModelDelta] parameter to route through; this app has never made
 * recognizing a run's shape undoable, only the byte content within one, and this phase doesn't
 * change that.
 */
data class StringRun(
    override val start: Int,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run

/**
 * Decodes fresh from [model] every call rather than caching - same reasoning as every other
 * per-cell/per-byte read in this app (see e.g. TableEditorViewModel.cellText's doc comment).
 */
fun StringRun.readText(model: RomDataModel): String = PcsString.decode(model, start, start + length).text

/**
 * Writes [newText], relocating to freshly-found free space first if its PCS encoding no longer
 * fits in this run's current length - see [Repointer]. Relocation always finds a brand new spot
 * rather than trying to grow in place even when the bytes right after this run happen to be
 * free: simpler, and it never risks a false-positive "free space" read stomping on data no run
 * has been told about yet. Every pointer that targeted the old address is rewritten to the new
 * one as part of the same [token], so a relocating save is never a moment where a pointer is left
 * dangling - freed old bytes, new bytes, and every retargeted pointer are one atomic, undoable
 * edit, same invariant as every other edit path in this app.
 *
 * Returns the resulting run - always a *new* value, even when nothing moved (a shorter string
 * still gets a new, shorter [StringRun.length]). See [StringRun]'s doc comment for the
 * re-registration step this function doesn't do for you.
 */
fun StringRun.writeText(model: RomDataModel, newText: String, token: ModelDelta): StringRun {
    val encoded = PcsString.encode(newText)
    val newLength = encoded.size
    val relocated = newLength > length

    val target = if (relocated) {
        Repointer.findFreeSpace(model, newLength)
            ?: throw PcsEncodingException("No free space big enough for $newLength bytes was found - try shorter text.")
    } else {
        start
    }

    if (relocated) {
        for (i in start until start + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    } else if (newLength < length) {
        for (i in target + newLength until target + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    }
    for (i in encoded.indices) token.setByte(model, target + i, encoded[i])

    val sources = if (relocated) Repointer.repointReferences(model, start, target, token) else pointerSources
    return StringRun(start = target, length = newLength, pointerSources = sources)
}
