package com.hexmaniac.core.model

/**
 * One named field within a table row - HexManiacAdvance calls this ArrayRunElementSegment.
 * Sealed for the same reason [Run] is: every exhaustive `when` over a row's fields (see
 * TableRun.kt) fails to compile until it's updated for a new field kind, instead of silently
 * falling through.
 *
 * Deliberately a smaller set than the original spec's: no enum-lookup, bit-array, calculated, or
 * nested-struct fields yet. See [TableFormat] for exactly what's supported and why.
 */
sealed interface FieldSegment {
    val name: String

    /** Bytes this field occupies within one row. */
    val length: Int
}

/** A 1-4 byte little-endian unsigned integer - stats, IDs, counts, and similar plain numbers. */
data class NumericField(override val name: String, override val length: Int) : FieldSegment {
    init { require(length in 1..4) { "Numeric field '$name' must be 1-4 bytes, was $length." } }
}

/** A 4-byte GBA pointer field - same encoding [RomDataModel.readPointer]/[RomDataModel.writePointer] already handle. */
data class PointerField(override val name: String) : FieldSegment {
    override val length: Int get() = 4
}

/**
 * A fixed-width text field, PCS-encoded with a terminator and zero-padding (the GBA convention)
 * - see [TableRun.readText]/[TableRun.writeText] for the encoding itself and exactly what it
 * covers, and [PcsString] for the character set those delegate to.
 */
data class TextField(override val name: String, override val length: Int) : FieldSegment {
    init { require(length >= 1) { "Text field '$name' must be at least 1 byte, was $length." } }
}
