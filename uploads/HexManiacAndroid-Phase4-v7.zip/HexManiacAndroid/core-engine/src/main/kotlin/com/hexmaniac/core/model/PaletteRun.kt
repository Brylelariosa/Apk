package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * A palette occupying ROM bytes from [start]: [PaletteFormat.pages] banks of raw 15-bit GBA
 * colors (2 bytes each - see [GbaColor]), either stored directly or [Lz77]-compressed.
 *
 * [length] is the ROM byte length - see [SpriteRun]'s doc comment for why a compressed run
 * needs its length computed against [RomDataModel] at construction time rather than derived
 * from the format alone, via [create].
 */
data class PaletteRun(
    override val start: Int,
    val format: PaletteFormat,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    companion object {
        /**
         * Builds a [PaletteRun] at [start], computing [length] from [model] if compressed.
         *
         * For an uncompressed 8-bit palette, length is always exactly 512 bytes regardless of
         * [PaletteFormat.pages]: 256 colors already is the entire palette space a GBA background
         * can address, so there's nothing a second "page" could mean - matching the original's
         * `PaletteRun` constructor, which hardcodes this same special case. For 1/2/4-bit
         * palettes, length is `bytesPerPage * pages` - the original only actually implements
         * this multiplication for 4-bit (`Pages * 32`) and leaves 1-bit/2-bit uncompressed
         * unhandled entirely (parseable, but its own constructor never assigns them a `Length`);
         * this generalizes the same 4-bit formula to all three rather than reproducing that gap.
         *
         * Also validates that `start + length` fits within [model] - see [SpriteRun.create]'s
         * doc comment for why that check belongs here rather than in each caller.
         */
        fun create(model: RomDataModel, start: Int, format: PaletteFormat, pointerSources: List<Int> = emptyList()): PaletteRun {
            val length = if (format.compressed) {
                Lz77.compressedLength(model, start, format.allowLengthErrors)
                    ?: throw ImageFormatException("No valid compressed palette data was found at this address.")
            } else if (format.bits == 8) {
                format.bytesPerPage
            } else {
                format.bytesPerPage * format.pages
            }
            if (start + length > model.size) {
                throw ImageFormatException("This palette would run past the end of the ROM.")
            }
            return PaletteRun(start, format, length, pointerSources)
        }
    }
}

/** The full decoded (decompressed, if needed) byte buffer this run's colors are packed into. */
fun PaletteRun.decodedBytes(model: RomDataModel): IntArray {
    if (!format.compressed) return IntArray(length) { model[start + it] }
    return Lz77.decompress(model, start, format.allowLengthErrors)
        ?: throw ImageFormatException("Could not decompress palette data at this address.")
}

/**
 * Raw 15-bit GBA colors (see [GbaColor]) for [page] (0-based, within [PaletteFormat.pages]).
 * These are indices *within this run's own pages*, not absolute palette-page numbers - add
 * [PaletteFormat.initialBlankPages] yourself when matching a [TilemapRun]'s per-tile palette
 * nibble, which is expressed in absolute terms. Missing bytes (a truncated/`allowLengthErrors`
 * buffer) read as color 0, same fallback [decodeTilePixels] uses for missing pixel bytes.
 */
fun PaletteRun.getColors(model: RomDataModel, page: Int = 0): IntArray {
    val data = decodedBytes(model)
    val pageStart = (page % format.pages) * format.bytesPerPage
    return IntArray(format.colorCount) { i ->
        val offset = pageStart + i * 2
        if (offset + 1 < data.size) data[offset] or (data[offset + 1] shl 8) else 0
    }
}

/**
 * Writes [colors] (exactly [PaletteFormat.colorCount] raw 15-bit values) back for [page]. Same
 * fixed-length-in-place vs. recompress-and-maybe-relocate split as [SpriteRun.setPixels] - see
 * its doc comment for why a compressed run can't just assume its new content still fits.
 */
fun PaletteRun.setColors(model: RomDataModel, colors: IntArray, token: ModelDelta, page: Int = 0): PaletteRun {
    require(colors.size == format.colorCount) { "Expected ${format.colorCount} colors, got ${colors.size}." }
    val pageStart = (page % format.pages) * format.bytesPerPage

    if (!format.compressed) {
        for (i in colors.indices) {
            val offset = start + pageStart + i * 2
            token.setByte(model, offset, colors[i] and 0xFF)
            token.setByte(model, offset + 1, (colors[i] shr 8) and 0xFF)
        }
        return this
    }

    val data = decodedBytes(model)
    val newData = data.copyOf()
    for (i in colors.indices) {
        val offset = pageStart + i * 2
        if (offset + 1 < newData.size) {
            newData[offset] = colors[i] and 0xFF
            newData[offset + 1] = (colors[i] shr 8) and 0xFF
        }
    }

    val recompressed = Lz77.compress(newData)
    val relocated = recompressed.size > length
    val target = if (relocated) {
        Repointer.findFreeSpace(model, recompressed.size)
            ?: throw ImageFormatException("No free space big enough for ${recompressed.size} compressed bytes was found.")
    } else {
        start
    }

    if (relocated) {
        for (i in start until start + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    } else if (recompressed.size < length) {
        for (i in target + recompressed.size until target + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    }
    for (i in recompressed.indices) token.setByte(model, target + i, recompressed[i])

    val sources = if (relocated) Repointer.repointReferences(model, start, target, token) else pointerSources
    return PaletteRun(start = target, format = format, length = recompressed.size, pointerSources = sources)
}
