package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * A tile image occupying ROM bytes from [start]: either raw pixel bytes
 * ([SpriteFormat.compressed] `false`) or an [Lz77]-compressed blob of them. Serves both roles
 * HMA keeps as separate classes for - a standalone sprite, and a [TilemapRun]'s tileset - see
 * [SpriteFormat]'s doc comment for why this project folds them into one [Run] case instead.
 *
 * [length] is the *ROM* byte length - for a compressed run that's the compressed size (which
 * can differ from a same-content re-save; see [setPixels]), computed once via
 * [Lz77.compressedLength] at construction time by [create]. Prefer [create] over calling this
 * constructor directly, unless you already have a valid, freshly-computed `length` in hand
 * (e.g. this file's own `copy()` calls after a successful write).
 */
data class SpriteRun(
    override val start: Int,
    val format: SpriteFormat,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    companion object {
        /**
         * Builds a [SpriteRun] at [start], computing [length] from [model] - see the class doc
         * comment. Also validates that `start + length` actually fits within [model] - for a
         * compressed run this is already guaranteed by [Lz77.compressedLength] never reading
         * past the model's end, but an uncompressed run's length comes entirely from [format]
         * with nothing to check it against, so a too-large declared size (e.g. a mistyped tile
         * count) would otherwise only surface later as an out-of-bounds read inside
         * [decodedBytes] - checking it here instead, at the one place every [SpriteRun] is
         * constructed, means every caller gets this for free rather than having to remember it.
         */
        fun create(model: RomDataModel, start: Int, format: SpriteFormat, pointerSources: List<Int> = emptyList()): SpriteRun {
            val length = if (format.compressed) {
                Lz77.compressedLength(model, start, format.allowLengthErrors)
                    ?: throw ImageFormatException("No valid compressed sprite data was found at this address.")
            } else {
                format.bytesPerPage
            }
            if (start + length > model.size) {
                throw ImageFormatException("This sprite would run past the end of the ROM.")
            }
            return SpriteRun(start, format, length, pointerSources)
        }
    }
}

/**
 * How many [SpriteFormat.bytesPerPage]-sized frames this run holds - always 1 when
 * uncompressed (its length is entirely the format's own dimensions, with nowhere to declare
 * "more than one"); for a compressed run, read straight from the LZ header, same as HMA's own
 * `LzSpriteRun.Pages`, so this doesn't require a full decompression just to know the count.
 */
fun SpriteRun.pageCount(model: RomDataModel): Int {
    if (!format.compressed) return 1
    val decompressedLength = model.readLittleEndian(start + 1, 3)
    return (decompressedLength / format.bytesPerPage).coerceAtLeast(1)
}

/** The full decoded (decompressed, if needed) byte buffer this run's pixels are packed into. */
fun SpriteRun.decodedBytes(model: RomDataModel): IntArray {
    if (!format.compressed) return IntArray(length) { model[start + it] }
    return Lz77.decompress(model, start, format.allowLengthErrors)
        ?: throw ImageFormatException("Could not decompress sprite data at this address.")
}

/** Palette-index pixels for [page] (0 for a single-page run), row-major - see [decodeTilePixels]. */
fun SpriteRun.getPixels(model: RomDataModel, page: Int = 0): IntArray {
    val data = decodedBytes(model)
    val pageStart = (page % pageCount(model)) * format.bytesPerPage
    return decodeTilePixels(data, pageStart, format.tileWidth, format.tileHeight, format.bitsPerPixel)
}

/**
 * Writes [pixels] (row-major, [SpriteFormat.pixelWidth] x [SpriteFormat.pixelHeight], one page)
 * back for [page]. An uncompressed run always writes in place, byte for byte - its length can
 * never change, so there's nothing to relocate. A compressed run recompresses the *whole*
 * multi-page buffer (all pages, not just the edited one) and, if the result is longer than
 * what's here now, relocates to freshly-found free space and repoints every reference to it -
 * same [Repointer]-based pattern as [StringRun.writeText], and for the same reason: even an
 * edit that doesn't change pixel dimensions can still compress to a different byte count than
 * before, so "will it still fit" has to be answered after re-encoding, not assumed from the
 * pixel data's size alone.
 *
 * Returns the resulting run - always new, even when nothing moved. Callers that get back a
 * relocated run must re-register it themselves ([RomDataModel.removeRun]/[RomDataModel.addRun]),
 * same as [StringRun.writeText]'s callers already do.
 */
fun SpriteRun.setPixels(model: RomDataModel, pixels: IntArray, token: ModelDelta, page: Int = 0): SpriteRun {
    require(pixels.size == format.pixelWidth * format.pixelHeight) {
        "Expected ${format.pixelWidth * format.pixelHeight} pixels, got ${pixels.size}."
    }

    if (!format.compressed) {
        val bytes = encodeTilePixels(pixels, format.pixelWidth, format.pixelHeight, format.bitsPerPixel)
        for (i in bytes.indices) token.setByte(model, start + i, bytes[i])
        return this
    }

    val pages = pageCount(model)
    val data = decodedBytes(model)
    val pageStart = (page % pages) * format.bytesPerPage
    val newPageBytes = encodeTilePixels(pixels, format.pixelWidth, format.pixelHeight, format.bitsPerPixel)
    val newData = data.copyOf()
    for (i in newPageBytes.indices) if (pageStart + i < newData.size) newData[pageStart + i] = newPageBytes[i]

    val recompressed = Lz77.compress(newData)
    val relocated = recompressed.size > length
    val target = if (relocated) {
        Repointer.findFreeSpace(model, recompressed.size)
            ?: throw ImageFormatException("No free space big enough for ${recompressed.size} compressed bytes was found.")
    } else {
        start
    }

    if (relocated) {
        for (i in start until start + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    } else if (recompressed.size < length) {
        for (i in target + recompressed.size until target + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    }
    for (i in recompressed.indices) token.setByte(model, target + i, recompressed[i])

    val sources = if (relocated) Repointer.repointReferences(model, start, target, token) else pointerSources
    return SpriteRun(start = target, format = format, length = recompressed.size, pointerSources = sources)
}

// --- Shared tile <-> pixel packing. `internal`, not `private`: TilemapRun.kt's getPixels calls
// these directly to pull individual tiles out of a tileset buffer by index, rather than
// duplicating this packing logic - the one place it lives, same reasoning
// RomDataModel.readLittleEndian's doc comment gives for itself. Reference: SpriteRun.GetPixels/
// SetPixels in the original C#, verified against a throwaway Python harness before being
// trusted here - see Lz77's doc comment for why that extra step, for this phase specifically. ---

/**
 * Unpacks [tileWidth] x [tileHeight] tiles' worth of [bitsPerPixel]-bit pixel data starting at
 * [dataStart] in [data] into a row-major `IntArray` of palette indices, [tileWidth]*8 wide.
 * Missing source bytes (running off the end of a truncated/`allowLengthErrors` buffer) read as
 * 0, matching the original's own `tileStart + i < data.Count ? data[...] : 0` fallback.
 */
internal fun decodeTilePixels(data: IntArray, dataStart: Int, tileWidth: Int, tileHeight: Int, bitsPerPixel: Int): IntArray {
    val pixelWidth = tileWidth * 8
    val pixels = IntArray(pixelWidth * tileHeight * 8)
    fun byteAt(offset: Int): Int = if (offset in data.indices) data[offset] else 0
    fun set(x: Int, y: Int, value: Int) { pixels[y * pixelWidth + x] = value }

    for (ty in 0 until tileHeight) {
        val yOffset = ty * 8
        for (tx in 0 until tileWidth) {
            val tileStart = ((ty * tileWidth) + tx) * 8 * bitsPerPixel + dataStart
            val xOffset = tx * 8
            when (bitsPerPixel) {
                4 -> for (i in 0 until 32) {
                    val xx = i % 4; val yy = i / 4
                    val raw = byteAt(tileStart + i)
                    set(xOffset + xx * 2 + 0, yOffset + yy, raw and 0xF)
                    set(xOffset + xx * 2 + 1, yOffset + yy, raw shr 4)
                }
                8 -> for (i in 0 until 64) {
                    val xx = i % 8; val yy = i / 8
                    set(xOffset + xx, yOffset + yy, byteAt(tileStart + i))
                }
                2 -> for (i in 0 until 16) {
                    var xx = i % 2; val yy = i / 2
                    xx = 1 - xx
                    val raw = byteAt(tileStart + i)
                    set(xOffset + xx * 4 + 0, yOffset + yy, (raw shr 6) and 3)
                    set(xOffset + xx * 4 + 1, yOffset + yy, (raw shr 4) and 3)
                    set(xOffset + xx * 4 + 2, yOffset + yy, (raw shr 2) and 3)
                    set(xOffset + xx * 4 + 3, yOffset + yy, (raw shr 0) and 3)
                }
                1 -> for (i in 0 until 8) {
                    val raw = byteAt(tileStart + i)
                    for (bitIndex in 0 until 8) set(xOffset + bitIndex, yOffset + i, (raw shr bitIndex) and 1)
                }
                else -> throw ImageFormatException("Unsupported bits-per-pixel: $bitsPerPixel")
            }
        }
    }
    return pixels
}

/**
 * The inverse of [decodeTilePixels]: packs a row-major pixel grid back into tile-ordered bytes.
 * Each packed component is defensively masked to its bit width (`and 0xF`, `and 0x3`, ...)
 * before being shifted into place - the original's C# doesn't (it trusts every pixel value is
 * already in range, since its own reader never produces anything else), but masking is a
 * strict improvement: a no-op for any value that was already valid, and it stops an
 * out-of-range value from corrupting a neighboring pixel packed into the same byte instead of
 * silently doing so.
 */
internal fun encodeTilePixels(pixels: IntArray, pixelWidth: Int, pixelHeight: Int, bitsPerPixel: Int): IntArray {
    val tileWidth = pixelWidth / 8
    val tileHeight = pixelHeight / 8
    val out = IntArray(tileWidth * tileHeight * 8 * bitsPerPixel)
    fun get(x: Int, y: Int): Int = pixels[y * pixelWidth + x]
    var pos = 0

    for (ty in 0 until tileHeight) {
        val yOffset = ty * 8
        for (tx in 0 until tileWidth) {
            val xOffset = tx * 8
            when (bitsPerPixel) {
                4 -> for (i in 0 until 32) {
                    if (pos >= out.size) break
                    val xx = i % 4; val yy = i / 4
                    val lo = get(xOffset + xx * 2 + 0, yOffset + yy) and 0xF
                    val hi = get(xOffset + xx * 2 + 1, yOffset + yy) and 0xF
                    out[pos] = (hi shl 4) or lo
                    pos++
                }
                8 -> for (i in 0 until 64) {
                    if (pos >= out.size) break
                    val xx = i % 8; val yy = i / 8
                    out[pos] = get(xOffset + xx, yOffset + yy) and 0xFF
                    pos++
                }
                2 -> for (i in 0 until 16) {
                    if (pos >= out.size) break
                    var xx = i % 2; val yy = i / 2
                    xx = 1 - xx
                    val a = get(xOffset + xx * 4 + 0, yOffset + yy) and 0x3
                    val b = get(xOffset + xx * 4 + 1, yOffset + yy) and 0x3
                    val c = get(xOffset + xx * 4 + 2, yOffset + yy) and 0x3
                    val d = get(xOffset + xx * 4 + 3, yOffset + yy) and 0x3
                    out[pos] = (a shl 6) or (b shl 4) or (c shl 2) or d
                    pos++
                }
                1 -> for (i in 0 until 8) {
                    if (pos >= out.size) break
                    var value = 0
                    for (bitIndex in 0 until 8) value = value or ((get(xOffset + bitIndex, yOffset + i) and 1) shl bitIndex)
                    out[pos] = value
                    pos++
                }
                else -> throw ImageFormatException("Unsupported bits-per-pixel: $bitsPerPixel")
            }
        }
    }
    return out
}
