package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * A table: [elementCount] fixed-size rows of [segments], laid out back-to-back starting at
 * [start]. Mirrors HexManiacAdvance's ArrayRun/ITableRun - see [TableFormat] for the format
 * string this normally gets built from. Implements [Run], so it slots into
 * [RomDataModel.addRun]/[RomDataModel.getRunAt] for free, same as [UnknownRun]/[PointerRun].
 *
 * Like every [Run], this is an immutable value object with no reference to the model it
 * describes; the read/write functions below take the model as a parameter instead, same
 * reasoning as [PointerScanner].
 */
data class TableRun(
    override val start: Int,
    val segments: List<FieldSegment>,
    val elementCount: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    init {
        require(segments.isNotEmpty()) { "A table must have at least one field." }
        require(elementCount >= 1) { "A table must have at least one row." }
    }

    val elementLength: Int = segments.sumOf { it.length }
    override val length: Int get() = elementLength * elementCount

    /** Byte offset of row [elementIndex]'s first byte. */
    fun rowStart(elementIndex: Int): Int {
        require(elementIndex in 0 until elementCount) { "Row $elementIndex out of range 0..<$elementCount." }
        return start + elementIndex * elementLength
    }

    /** Byte offset of the [segmentIndex] field within row [elementIndex]. */
    fun fieldStart(elementIndex: Int, segmentIndex: Int): Int {
        var offset = rowStart(elementIndex)
        for (i in 0 until segmentIndex) offset += segments[i].length
        return offset
    }
}

fun TableRun.readNumeric(model: RomDataModel, elementIndex: Int, segmentIndex: Int): Int {
    val segment = segments[segmentIndex]
    require(segment is NumericField) { "Segment '${segment.name}' is not numeric." }
    return model.readLittleEndian(fieldStart(elementIndex, segmentIndex), segment.length)
}

fun TableRun.writeNumeric(model: RomDataModel, elementIndex: Int, segmentIndex: Int, value: Int, token: ModelDelta) {
    val segment = segments[segmentIndex]
    require(segment is NumericField) { "Segment '${segment.name}' is not numeric." }
    model.writeLittleEndian(fieldStart(elementIndex, segmentIndex), segment.length, value, token)
}

/** Reuses [RomDataModel.readPointer]'s existing GBA pointer decoding - no need to re-derive it. */
fun TableRun.readPointerField(model: RomDataModel, elementIndex: Int, segmentIndex: Int): Int {
    val segment = segments[segmentIndex]
    require(segment is PointerField) { "Segment '${segment.name}' is not a pointer." }
    return model.readPointer(fieldStart(elementIndex, segmentIndex))
}

fun TableRun.writePointerField(model: RomDataModel, elementIndex: Int, segmentIndex: Int, fileOffset: Int, token: ModelDelta) {
    val segment = segments[segmentIndex]
    require(segment is PointerField) { "Segment '${segment.name}' is not a pointer." }
    model.writePointer(fieldStart(elementIndex, segmentIndex), fileOffset, token)
}

/** Real PCS decoding as of this phase - see [PcsString] for exactly what that covers and what
 *  it deliberately doesn't. */
fun TableRun.readText(model: RomDataModel, elementIndex: Int, segmentIndex: Int): String {
    val segment = segments[segmentIndex]
    require(segment is TextField) { "Segment '${segment.name}' is not text." }
    val start = fieldStart(elementIndex, segmentIndex)
    return PcsString.decode(model, start, start + segment.length).text
}

/**
 * Encodes as PCS, then fits the fixed-width slot: written as-is (0x00-padded after the
 * terminator) if it fits, or truncated with a fresh terminator forced into the last byte if not.
 * Table fields don't repoint when text is too long - see [StringRun.writeText] for the
 * free-floating strings that do - so oversized text is simply cut, same as before this phase.
 * Truncation is byte-level, not escape-aware: content that used one of PCS's multi-byte escapes
 * right at the cut point could truncate mid-escape. Harmless for the short plain-text names and
 * labels table fields are normally used for, but worth knowing for anything longer or more exotic.
 */
fun TableRun.writeText(model: RomDataModel, elementIndex: Int, segmentIndex: Int, text: String, token: ModelDelta) {
    val segment = segments[segmentIndex]
    require(segment is TextField) { "Segment '${segment.name}' is not text." }
    val start = fieldStart(elementIndex, segmentIndex)
    val content = PcsString.encode(text).dropLast(1).take(segment.length - 1) // reserve 1 byte for the terminator
    for (i in 0 until segment.length) {
        val value = when {
            i < content.size -> content[i]
            i == content.size -> PcsString.TERMINATOR
            else -> 0x00
        }
        token.setByte(model, start + i, value)
    }
}
