package com.hexmaniac.core.model

/**
 * Parses the name+address columns of HexManiacAdvance's own `tableReference.txt` - reference:
 * `Models/Code/tableReference.txt` in the original source, bundled verbatim as a resource on
 * this module's classpath (`core-engine/src/main/resources/tableReference.txt`) rather than
 * retyped, since transcribing ~800 hardcoded hex addresses by hand risks introducing exactly the
 * kind of error this project's Python-verification habit (see [Lz77]'s doc comment) exists to
 * avoid - copying the original file mechanically and parsing it doesn't have that risk, and
 * dropping in a newer copy of the same file is enough to pick up future additions.
 *
 * Each line is `name, <address for each of 9 game versions>, format string...`; this only
 * extracts the name and addresses, using [String.split] with a limit so the trailing format-
 * string column - which is free to contain its own commas - is captured whole and ignored
 * rather than needing to be parsed. That column uses a much richer grammar (nested and dynamic-
 * length arrays, switch/record fields, bit-arrays, cross-references to other tables' lengths,
 * ...) than this project's simplified [TableFormat]/[ImageFormat] DSL supports; translating
 * ~800 of them correctly without being able to compile-check any of it is a separate, much
 * larger, and much riskier undertaking than parsing plain hex addresses out of a CSV-like
 * column - see the README's "known rough edges" for what that leaves manual.
 */
object KnownTables {
    /** The 9 game-version codes this reference file has columns for, in column order - see
     *  [GameCode] for what a code looks like and how it's read from a ROM. */
    val GAME_CODES = listOf("AXVE0", "AXPE0", "AXVE1", "AXPE1", "BPRE0", "BPGE0", "BPRE1", "BPGE1", "BPEE0")

    /** Every known (name, address) pair for [gameCode], parsed once and cached - this is static
     *  reference data, not something that varies per ROM instance. */
    val bundled: Map<String, List<Pair<String, Int>>> by lazy {
        val text = javaClass.getResourceAsStream("/tableReference.txt")
            ?.bufferedReader(Charsets.UTF_8)
            ?.readText()
            .orEmpty()
        parse(text)
    }

    /**
     * Parses [referenceText] in the format described in this object's doc comment. Exposed
     * separately from [bundled] so it's testable against small hand-written snippets without
     * needing the real ~40KB resource file in play.
     */
    fun parse(referenceText: String): Map<String, List<Pair<String, Int>>> {
        val byGame = GAME_CODES.associateWith { mutableListOf<Pair<String, Int>>() }
        for (rawLine in referenceText.lineSequence()) {
            val line = rawLine.trim().removePrefix("\uFEFF") // tolerate a leading UTF-8 BOM on the first line
            if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) continue

            val columns = line.split(",", limit = GAME_CODES.size + 2)
            if (columns.size < GAME_CODES.size + 1) continue
            val name = columns[0].trim()
            if (name.isEmpty()) continue

            for ((i, gameCode) in GAME_CODES.withIndex()) {
                val address = columns[1 + i].trim().toIntOrNull(16) ?: continue
                byGame.getValue(gameCode).add(name to address)
            }
        }
        return byGame
    }
}
