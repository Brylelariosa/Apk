package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * Finds space for, and repoints references to, a [StringRun] whose new content no longer fits
 * in its old slot - the "auto-repoint on edit" this phase adds. [StringRun.writeText] is the
 * only caller; see its doc comment for how the pieces here fit together into one atomic edit.
 *
 * This project has no persistent index of "what points where" yet - [PointerScanner]'s doc
 * comment covers why: the existing pointer scan is highlight-only, nothing gets registered as a
 * run for it. [repointReferences] answers "who points at this address" the same way that scan
 * answers "is this 4 bytes a pointer": a live, linear pass over the whole ROM. Same O(ROM size)
 * cost class as a button the app already has, so paying it again here, on a deliberate user
 * action (Save), isn't a new performance concern - just not something to also run per keystroke.
 */
object Repointer {
    /**
     * Conventional GBA "this space is unused" filler byte - also [PcsString.TERMINATOR]'s value,
     * which is exactly why a string naturally stops where free space begins. Named separately
     * here since the two constants mean different things (end-of-content vs. available-to-use)
     * even though they share a value.
     */
    const val FREE_SPACE_BYTE = 0xFF

    /**
     * The first address at or after [searchFrom] where at least [minLength] consecutive bytes
     * are both [FREE_SPACE_BYTE] and unclaimed by any run already in [model] - or null if the
     * ROM has no such stretch. A stretch that merely looks free (0xFF) but is already inside some
     * other recognized [Run] is skipped, since treating it as available would silently corrupt
     * that run; bytes nothing has recognized yet are fair game, same as everywhere else in this
     * app that hasn't been told otherwise.
     */
    fun findFreeSpace(model: RomDataModel, minLength: Int, searchFrom: Int = 0): Int? {
        require(minLength >= 1) { "minLength must be at least 1, was $minLength." }
        var i = searchFrom.coerceAtLeast(0)
        while (i + minLength <= model.size) {
            if (model[i] != FREE_SPACE_BYTE || model.getRunAt(i) != null) {
                i++
                continue
            }
            val candidateStart = i
            var found = 0
            while (found < minLength && i < model.size && model[i] == FREE_SPACE_BYTE && model.getRunAt(i) == null) {
                found++
                i++
            }
            if (found >= minLength) return candidateStart
        }
        return null
    }

    /**
     * Rewrites every 4-byte GBA pointer in [model] that currently targets [oldAddress] to target
     * [newAddress] instead, as part of [token]. Returns the address of each pointer rewritten -
     * exactly what the relocated run's [Run.pointerSources] should become.
     */
    fun repointReferences(model: RomDataModel, oldAddress: Int, newAddress: Int, token: ModelDelta): List<Int> {
        val rewritten = mutableListOf<Int>()
        for (i in 0..model.size - 4) {
            if (model.readPointer(i) == oldAddress) {
                model.writePointer(i, newAddress, token)
                rewritten.add(i)
            }
        }
        return rewritten
    }
}
