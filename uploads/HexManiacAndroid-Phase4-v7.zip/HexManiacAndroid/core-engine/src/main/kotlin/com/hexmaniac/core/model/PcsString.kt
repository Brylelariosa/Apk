package com.hexmaniac.core.model

/** Thrown by [PcsString.encode] with a message meant to be shown directly to the user. */
class PcsEncodingException(message: String) : Exception(message)

/**
 * Encodes/decodes the Pokemon Gen 3 "PCS" text character set - not ASCII, a game-specific byte
 * mapping. Reference: pcsReference.txt / PCSString.cs in the original C# source (this project
 * uses HMA's source as a spec to read, not code to reuse - see README). Replaces the raw-Latin-1
 * placeholder [TableRun.readText]/[TableRun.writeText] used before this phase - see [TextField]'s
 * doc comment - and backs the new free-floating [StringRun] this phase also adds.
 *
 * Deliberate subset of the real system:
 *   - Every printable character (letters, digits, accented characters, common punctuation)
 *     decodes and encodes losslessly, byte for byte.
 *   - 0xFE, the standard newline control code, round-trips as an actual `\n` in the decoded
 *     Kotlin string - the common case for multi-line dialogue, and the natural thing for a
 *     multi-line text field to produce when the person presses enter.
 *   - The handful of other single-byte special glyphs (male/female marks, arrows, the "Lv" and
 *     "PokeBlock" logo glyphs, the 0xFA/0xFB line-feed/paragraph-feed codes, ...) round-trip as
 *     literal backslash-escape tokens matching HMA's own notation (`\Lv`, `\sm`, `\au`, `\l`,
 *     `\pn`, ...), so they're never lost even though they don't have a friendly Kotlin Char.
 *   - The five multi-byte escapes - 0xF7/0xF8/0xF9/0xFD (prefix + 1 raw byte) and 0xFC (prefix +
 *     sub-code + a sub-code-dependent number of argument bytes, matching HMA's own length table)
 *     - round-trip as their escape token followed by raw hex digits, e.g. `\CC0900`, rather than
 *     a friendly name: HMA's named-macro layer for these (`[player]`, per-game color names,
 *     button names, ...) needs a detected game code plus per-game tables this project doesn't
 *     have yet. Byte-exact round-tripping still holds; only the friendly name doesn't.
 *   - A byte with no entry at all in the reference table round-trips as `\!XX` raw hex, also
 *     matching HMA's own fallback notation.
 * Not supported: pixel-width textbox-overflow checking (needs a per-game font-width table this
 * project doesn't detect) and the auto-newline-mode inference HMA's own editor does (guessing
 * feed vs. wrap vs. paragraph from surrounding context) - 0xFA/0xFB are always explicit tokens
 * here instead of something `\n` sometimes silently means.
 */
object PcsString {
    const val TERMINATOR = 0xFF

    private const val NEWLINE = 0xFE
    private const val ESCAPE = 0xFD // "next byte is raw" - used by the [player]/[buffer]/[rival] macros
    private const val DYNAMIC_ESCAPE = 0xF7
    private const val BUTTON_ESCAPE = 0xF8
    private const val SPECIAL_CHAR_ESCAPE = 0xF9
    private const val FUNCTION_ESCAPE = 0xFC // prefix + sub-code + functionEscapeLength(subCode)-1 argument bytes
    private val ONE_BYTE_ARG_ESCAPES = setOf(ESCAPE, DYNAMIC_ESCAPE, BUTTON_ESCAPE, SPECIAL_CHAR_ESCAPE)

    private val table: Array<String?> = buildTable()

    data class Decoded(val text: String, val byteLength: Int)

    /**
     * Decodes from [start] up to (and including) the terminator, or up to [limit] if no
     * terminator is found first. [Decoded.byteLength] is how many bytes this string occupies -
     * the same convention every [Run] uses for its own [Run.length].
     */
    fun decode(model: RomDataModel, start: Int, limit: Int = model.size): Decoded {
        val text = StringBuilder()
        val end = limit.coerceAtMost(model.size)
        var i = start
        while (i < end) {
            val byte = model[i]
            if (byte == TERMINATOR) {
                i++
                break
            }
            if (byte == NEWLINE) {
                text.append('\n')
                i++
                continue
            }
            if (byte in ONE_BYTE_ARG_ESCAPES) {
                text.append(table[byte])
                i++
                if (i < end) {
                    text.append(model[i].toPcsHex())
                    i++
                }
                continue
            }
            if (byte == FUNCTION_ESCAPE) {
                text.append(table[byte])
                i++
                if (i < end) {
                    val subCode = model[i]
                    text.append(subCode.toPcsHex())
                    i++
                    var remaining = functionEscapeLength(subCode) - 1
                    while (remaining > 0 && i < end) {
                        text.append(model[i].toPcsHex())
                        i++
                        remaining--
                    }
                }
                continue
            }
            text.append(table[byte] ?: "\\!${byte.toPcsHex()}")
            i++
        }
        return Decoded(text.toString(), i - start)
    }

    /** Encodes [text] to PCS bytes, always ending with [TERMINATOR]. Throws [PcsEncodingException]
     *  for a character the format has no byte for. */
    fun encode(text: String): List<Int> {
        val bytes = mutableListOf<Int>()
        var i = 0
        while (i < text.length) {
            if (text[i] == '\n') {
                bytes.add(NEWLINE)
                i++
                continue
            }
            if (text.startsWith("\\!", i) && i + 4 <= text.length) {
                val raw = text.substring(i + 2, i + 4).toIntOrNull(16)
                if (raw != null) {
                    bytes.add(raw)
                    i += 4
                    continue
                }
            }

            val matched = (0..0xFF).firstOrNull { candidate ->
                table[candidate]?.let { text.startsWith(it, i) } == true
            } ?: throw PcsEncodingException(
                "Character '${text[i]}' at position $i isn't in the PCS character set. " +
                    "Use \\!XX to insert a raw byte."
            )

            bytes.add(matched)
            i += table[matched]!!.length
            when {
                matched in ONE_BYTE_ARG_ESCAPES -> i = readHexByte(text, i, bytes)
                matched == FUNCTION_ESCAPE -> {
                    val subCodeText = text.substring(i, (i + 2).coerceAtMost(text.length))
                    val subCode = subCodeText.toIntOrNull(16) ?: throw PcsEncodingException(
                        "'\\CC$subCodeText' near position $i needs a 2-digit hex sub-code, e.g. '\\CC09'."
                    )
                    bytes.add(subCode)
                    i += 2
                    repeat(functionEscapeLength(subCode) - 1) { i = readHexByte(text, i, bytes) }
                }
            }
        }
        bytes.add(TERMINATOR)
        return bytes
    }

    private fun readHexByte(text: String, index: Int, into: MutableList<Int>): Int {
        val hex = text.substring(index, (index + 2).coerceAtMost(text.length))
        val value = hex.toIntOrNull(16)
            ?: throw PcsEncodingException("'$hex' near position $index isn't a valid 2-digit hex byte.")
        into.add(value)
        return index + 2
    }

    /**
     * How many bytes follow a 0xFC prefix, including the sub-code byte itself - e.g. 2 means
     * "sub-code + 1 argument byte". Mirrors HMA's handful of overrides (pcsReference.txt's CC_xx
     * entries) plus its default rule for everything else: sub-codes above 0x14 take no
     * arguments, everything else takes exactly one.
     */
    private fun functionEscapeLength(subCode: Int): Int = when (subCode) {
        0x04 -> 4 // text shadow/highlight: 3 argument bytes
        0x09, 0x0A -> 1 // pause / wait-for-sound-effect: no arguments
        0x0B, 0x10 -> 3 // play background music / play sound effect: a 2-byte argument
        else -> if (subCode > 0x14) 1 else 2
    }

    private fun Int.toPcsHex(): String = toString(16).uppercase().padStart(2, '0')

    private fun buildTable(): Array<String?> {
        val pcs = arrayOfNulls<String>(256)
        pcs[0x00] = " "
        fillChars(pcs, 0x01, "ÀÁÂÇÈÉÊËÌ")
        fillChars(pcs, 0x0B, "ÎÏÒÓÔ")
        fillChars(pcs, 0x10, "ŒÙÚÛÑßàá")
        fillChars(pcs, 0x19, "çèéêëì")
        fillChars(pcs, 0x20, "îïòóôœùúûñºª")
        pcs[0x2C] = "\\e"
        fillTokens(pcs, 0x2D, "&", "\\+")
        fillTokens(pcs, 0x34, "\\Lv", "=", ";")
        pcs[0x48] = "\\r"
        fillTokens(pcs, 0x51, "¿", "¡", "\\pk", "\\mn", "\\Po", "\\Ke", "\\Bl", "\\Lo", "\\Ck", "Í")
        fillChars(pcs, 0x5B, "%()")
        pcs[0x68] = "â"
        pcs[0x6F] = "í"
        fillTokens(pcs, 0x79, "\\au", "\\ad", "\\al", "\\ar")
        pcs[0x84] = "\\d"
        fillTokens(pcs, 0x85, "\\<", "\\>")
        fillChars(pcs, 0xA1, "0123456789")
        fillTokens(
            pcs, 0xAB,
            "!", "?", ".", "-", "‧", "\\.", "\\qo", "\\qc", "‘", "'", "\\sm", "\\sf", "$", ",", "*", "/",
        )
        fillChars(pcs, 0xBB, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        fillChars(pcs, 0xD5, "abcdefghijklmnopqrstuvwxyz")
        fillChars(pcs, 0xF0, ":ÄÖÜäöü")
        pcs[0xF7] = "\\?"
        pcs[0xF8] = "\\btn"
        pcs[0xF9] = "\\9"
        pcs[0xFA] = "\\l"
        pcs[0xFB] = "\\pn"
        pcs[0xFC] = "\\CC"
        pcs[0xFD] = "\\\\"
        // 0xFE (newline) and 0xFF (terminator) are handled as special cases above, not through
        // this table - see NEWLINE/TERMINATOR.
        return pcs
    }

    private fun fillChars(pcs: Array<String?>, start: Int, chars: String) {
        for (i in chars.indices) pcs[start + i] = chars[i].toString()
    }

    private fun fillTokens(pcs: Array<String?>, start: Int, vararg tokens: String) {
        for (i in tokens.indices) pcs[start + i] = tokens[i]
    }
}
