package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * Holds the raw ROM bytes plus the sorted collection of interpreted [Run]s layered over them,
 * and the anchor names ([anchorAt]/[addressForAnchor]) attached to some of those addresses.
 * Mirrors HexManiacAdvance's IDataModel, minus the table/map-editor-specific concerns that
 * belong to later phases.
 *
 * Direct byte mutation is `internal` on purpose: every edit must go through a [ModelDelta] so
 * it is always undoable. UI code reads via [get]/[readPointer] but can only write via
 * [ModelDelta.setByte] or [writePointer] - there is no public path that bypasses undo tracking.
 */
class RomDataModel(private val data: ByteArray) {

    val size: Int get() = data.size

    // Parallel sorted list of run-start addresses, kept in sync with runsByStart, so
    // getRunAt() can binary-search instead of scanning - matters once a ROM has
    // thousands of detected runs.
    private val runStarts = mutableListOf<Int>()
    private val runsByStart = mutableMapOf<Int, Run>()

    val runs: List<Run> get() = runStarts.map { runsByStart.getValue(it) }

    operator fun get(index: Int): Int = data[index].toInt() and 0xFF

    internal operator fun set(index: Int, value: Int) {
        data[index] = value.toByte()
    }

    /** Returns a defensive copy of the current bytes, e.g. for saving to a file. */
    fun snapshotBytes(): ByteArray = data.copyOf()

    /** Reads a little-endian 4-byte GBA pointer at [address]; returns the file offset, or -1 if invalid. */
    fun readPointer(address: Int): Int {
        if (address < 0 || address + 4 > data.size) return -1
        val value = readLittleEndian(address, 4)
        val topByte = (value ushr 24) and 0xFF
        if (topByte != 0x08 && topByte != 0x09) return -1 // not in GBA ROM address space
        val fileOffset = value - POINTER_OFFSET
        if (fileOffset < 0 || fileOffset >= data.size) return -1
        return fileOffset
    }

    /** Writes [fileOffset] as a 4-byte GBA pointer at [address], tracked by [token] so it can be undone. */
    fun writePointer(address: Int, fileOffset: Int, token: ModelDelta) {
        writeLittleEndian(address, 4, fileOffset + POINTER_OFFSET, token)
    }

    /**
     * Reads [byteCount] (1-4) bytes starting at [address] as an unsigned little-endian integer.
     * `internal`, not `private`: Phase 2's table numeric fields reuse this exact primitive
     * (see TableRun.kt) rather than re-deriving little-endian packing a second time - this is
     * the one place that logic lives. [readPointer] above is the 4-byte, GBA-address-space-
     * validated special case of the same primitive.
     */
    internal fun readLittleEndian(address: Int, byteCount: Int): Int {
        var value = 0
        for (i in 0 until byteCount) value = value or (this[address + i] shl (8 * i))
        return value
    }

    /** Writes [value]'s low [byteCount] bytes starting at [address], little-endian, tracked by [token]. See [readLittleEndian]. */
    internal fun writeLittleEndian(address: Int, byteCount: Int, value: Int, token: ModelDelta) {
        for (i in 0 until byteCount) token.setByte(this, address + i, (value ushr (8 * i)) and 0xFF)
    }

    /**
     * Registers [run] at its own [Run.start]. Not tracked by a [ModelDelta]: recognizing a
     * shape in bytes that are already there - "these bytes are a table" - isn't a content edit
     * the way changing one of those bytes is, so it doesn't belong on the undo stack. [setAnchor]
     * below follows the same reasoning for the same reason: naming an address isn't editing it.
     */
    fun addRun(run: Run) {
        val i = runStarts.binarySearch(run.start)
        if (i < 0) runStarts.add(-(i + 1), run.start)
        runsByStart[run.start] = run
    }

    /**
     * Removes whatever run starts exactly at [start], if any - the inverse of [addRun]. Needed
     * when a run's identity changes out from under its old address (e.g. [StringRun.writeText]
     * relocating a string): without this, the old registration would keep claiming bytes that
     * are free space again, and [getRunAt] would never see the relocation.
     */
    fun removeRun(start: Int) {
        val i = runStarts.binarySearch(start)
        if (i < 0) return
        runStarts.removeAt(i)
        runsByStart.remove(start)
    }

    /** Returns the run containing [address], or null if none does. O(log n). */
    fun getRunAt(address: Int): Run? {
        val i = runStarts.binarySearch(address)
        val floorIndex = if (i >= 0) i else -(i + 1) - 1
        if (floorIndex < 0) return null
        val run = runsByStart.getValue(runStarts[floorIndex])
        return if (address in run) run else null
    }

    // Anchors: human-readable names for addresses (HMA calls the same concept an anchor), e.g.
    // "data.pokemon.names" for wherever that table currently lives - either set by the user, or
    // auto-populated for a recognized game from KnownTables (see RomSessionRepository). Kept as
    // two maps, not one plus a reverse scan, so both directions - "what's this address called"
    // and "where is this name" - are O(1); an address field anywhere in the app can accept
    // either a hex offset or a name (see RomSessionRepository.resolveAddress) precisely because
    // this lookup is cheap enough to try on every keystroke's worth of parsing.
    private val anchorByAddress = mutableMapOf<Int, String>()
    private val addressByAnchor = mutableMapOf<String, Int>()

    /** The anchor name at [address], if one has been set. */
    fun anchorAt(address: Int): String? = anchorByAddress[address]

    /** The address named [anchor], if one has been set. */
    fun addressForAnchor(anchor: String): Int? = addressByAnchor[anchor]

    /** Every known (address, name) pair, for a "known tables" browse/search UI. */
    val anchors: Map<Int, String> get() = anchorByAddress

    /**
     * Names [address] as [anchor], replacing any previous name at that address and any previous
     * address for that name, so a name and an address are always in a 1:1 relationship. Like
     * [addRun]/[removeRun], this is metadata about existing bytes, not a content edit, so it
     * isn't tracked by a [ModelDelta] - see [addRun]'s doc comment for the same reasoning.
     */
    fun setAnchor(address: Int, anchor: String) {
        anchorByAddress[address]?.let { addressByAnchor.remove(it) }
        addressByAnchor[anchor]?.let { anchorByAddress.remove(it) }
        anchorByAddress[address] = anchor
        addressByAnchor[anchor] = address
    }

    /** Removes whatever name is attached to [address], if any - the inverse of [setAnchor]. */
    fun removeAnchor(address: Int) {
        anchorByAddress.remove(address)?.let { addressByAnchor.remove(it) }
    }

    companion object {
        const val POINTER_OFFSET = 0x08000000
    }
}
