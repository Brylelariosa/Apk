package com.hexmaniac.core.model

/**
 * Reads the GBA ROM header's game code: a fixed 4-character ASCII code plus a 1-digit version
 * number (e.g. `"BPEE0"` for the English Emerald). This is the same key [KnownTables]' reference
 * data is organized by, and the same value the original's `GetGameCode()` extension method
 * computes - reference: `IDataModel.cs`'s `GameCodeStart`/`GameVersionStart`/`GetGameCode`.
 *
 * This is a standard, documented field of every GBA cartridge header, not something specific to
 * Pokemon or to HMA - real hardware and every emulator read the same two offsets to identify a
 * cartridge, so this isn't a heuristic guess the way, say, sniffing a file extension would be.
 */
object GameCode {
    private const val CODE_START = 0xAC
    private const val VERSION_START = 0xBC

    /** e.g. `"BPEE0"`, or null if [model] is too small to have a header at all. */
    fun read(model: RomDataModel): String? {
        if (model.size <= VERSION_START) return null
        val code = String(CharArray(4) { i -> model[CODE_START + i].toChar() })
        return code + model[VERSION_START].toString()
    }

    /**
     * A human-readable name for a code [read] returned, for display only - e.g. in a title bar,
     * confirming "yes, this ROM was recognized" without the user needing to know what "BPEE0"
     * means. Returns null for anything not in [KnownTables.GAME_CODES], including a valid-looking
     * code from an unrecognized romhack base.
     */
    fun displayName(code: String): String? = when (code) {
        "AXVE0", "AXVE1" -> "Ruby"
        "AXPE0", "AXPE1" -> "Sapphire"
        "BPEE0" -> "Emerald"
        "BPRE0", "BPRE1" -> "FireRed"
        "BPGE0", "BPGE1" -> "LeafGreen"
        else -> null
    }
}
