package com.hexmaniac.core.model

/**
 * The GBA BIOS's LZ77 variant (`SWI 11h LZ77UnCompWram`/`Vram`), used to compress nearly every
 * sprite, tileset, tilemap, and palette in a real GBA Pokemon ROM. Reference: LZRun.cs in the
 * original C# source (this project uses HMA's source as a spec to read, not code to reuse -
 * see README) - every method below was checked line-by-line against it, then independently
 * verified with a throwaway Python harness (round trips, hand-traced token sequences, a
 * hand-constructed compressed stream this code didn't itself produce) before being trusted
 * here, same practice the README says Phase 1 used for its own bit-level logic.
 *
 * Layout: a 4-byte header (`0x10` magic, then a 3-byte little-endian decompressed length),
 * then repeating groups of one bit-field byte (high bit first) followed by up to 8 tokens - a
 * `0` bit means "1 literal byte follows", a `1` bit means "2 bytes follow encoding a
 * back-reference" (4-bit length-minus-3, 12-bit offset-minus-1, both big-endian-within-the-
 * pair despite the format being little-endian everywhere else - see [readBackReference]).
 * Compression tokens can copy from bytes the same copy is still in the middle of writing
 * (`index - runOffset` can land inside the output already produced by this same copy), which
 * is what lets a handful of bytes expand into a long repeated run - both [decompress] and
 * [compress] preserve that rather than special-casing non-overlapping copies.
 */
object Lz77 {
    private const val MAGIC = 0x10
    private const val MIN_MATCH_LENGTH = 3
    private const val MAX_MATCH_LENGTH = 18
    private const val MAX_MATCH_OFFSET = 0x1000

    /**
     * How many compressed bytes occupy the ROM starting at [start] - a full walk of the token
     * stream (not just the 4-byte header), since only that reveals where the last group ends.
     * A [SpriteRun]/[PaletteRun]/[TilemapRun] needs this the moment it's constructed, to know
     * its own [Run.length] - the same reason [PcsString.decode] returns a byte length rather
     * than making every [StringRun] recompute it.
     *
     * Returns null if [start] isn't valid compressed data at all, or - unless
     * [allowLengthErrors] - if the stream's actual decompressed size doesn't match the length
     * declared in its header (a real mismatch some ROM hacks intentionally rely on; see
     * [SpriteFormat.allowLengthErrors]/[PaletteFormat.allowLengthErrors]).
     */
    fun compressedLength(model: RomDataModel, start: Int, allowLengthErrors: Boolean = false): Int? {
        val declaredLength = readHeaderLength(model, start) ?: return null
        var pos = start + 4
        var index = 0
        while (index < declaredLength && pos < model.size) {
            var bitField = model[pos]
            pos++
            for (bit in 0 until 8) {
                if (index > declaredLength) break
                if (index == declaredLength) return if (bitField == 0) pos - start else null
                val compressed = (bitField and 0x80) != 0
                bitField = (bitField shl 1) and 0xFF
                if (!compressed) {
                    index++
                    pos++
                } else {
                    if (pos + 2 > model.size) return null
                    val (runLength, runOffset) = readBackReference(model[pos], model[pos + 1])
                    pos += 2
                    if (index - runOffset < 0) return null
                    index += runLength
                }
            }
        }
        val hasLengthErrors = index != declaredLength || pos > model.size
        return when {
            allowLengthErrors -> pos - start
            !hasLengthErrors -> pos - start
            else -> null
        }
    }

    /**
     * Decompresses the data at [start], or null if it isn't valid (unless [allowLengthErrors] -
     * see [compressedLength]). Bytes as `Int` (0-255), matching every other byte-buffer
     * convention in this codebase (see e.g. [PcsString.encode]'s `List<Int>`) rather than
     * Kotlin's signed `Byte`.
     */
    fun decompress(model: RomDataModel, start: Int, allowLengthErrors: Boolean = false): IntArray? {
        val length = readHeaderLength(model, start) ?: return null
        var pos = start + 4
        var index = 0
        val result = IntArray(length)
        while (index < length) {
            if (pos >= model.size) return null
            var bitField = model[pos]
            pos++
            for (bit in 0 until 8) {
                if (index > length) break
                if (index == length) return if (bitField == 0) result else null
                val compressed = (bitField and 0x80) != 0
                bitField = (bitField shl 1) and 0xFF
                if (!compressed) {
                    if (pos >= model.size) return null
                    result[index] = model[pos]
                    index++
                    pos++
                } else {
                    if (pos + 2 > model.size) return null
                    val (runLength, runOffset) = readBackReference(model[pos], model[pos + 1])
                    pos += 2
                    if (index - runOffset < 0) return null
                    for (j in 0 until runLength) {
                        if (index + j < result.size) result[index + j] = result[index + j - runOffset]
                    }
                    index += runLength
                }
            }
            if (bitField != 0) return null
        }
        return if (allowLengthErrors || index == length) result else null
    }

    /**
     * Compresses [data] (only the [length] bytes from [start]) with a straightforward greedy
     * longest-match tokenizer - simpler than the reference compressor an emulator's BIOS call
     * would use, but every real GBA LZ77 decompressor (including [decompress] above) accepts
     * any input that follows the format, regardless of which encoder produced it, so this
     * doesn't need to match HMA's compressed *bytes* exactly - only decompress back to the
     * same content, which the round-trip tests confirm.
     */
    fun compress(data: IntArray, start: Int = 0, length: Int = data.size - start): IntArray {
        data class Token(val isRun: Boolean, val literal: Int = 0, val runLength: Int = 0, val runOffset: Int = 0)

        val tokens = mutableListOf<Token>()
        var index = start
        val end = start + length
        while (index < end) {
            val (runLength, runOffset) = findLongestMatch(data, index, start, end)
            if (runLength < MIN_MATCH_LENGTH) {
                tokens.add(Token(isRun = false, literal = data[index]))
                index++
            } else {
                tokens.add(Token(isRun = true, runLength = runLength, runOffset = runOffset))
                index += runLength
            }
        }

        val result = mutableListOf(MAGIC, length and 0xFF, (length shr 8) and 0xFF, (length shr 16) and 0xFF)
        var i = 0
        while (i < tokens.size) {
            val group = tokens.subList(i, minOf(i + 8, tokens.size))
            var bitField = 0
            for ((j, token) in group.withIndex()) {
                if (token.isRun) bitField = bitField or (1 shl (7 - j))
            }
            result.add(bitField)
            for (token in group) {
                if (token.isRun) {
                    val offset = (token.runOffset - 1).coerceIn(0, 0xFFF)
                    val len = (token.runLength - MIN_MATCH_LENGTH).coerceIn(0, 0xF)
                    result.add((len shl 4) or (offset shr 8))
                    result.add(offset and 0xFF)
                } else {
                    result.add(token.literal)
                }
            }
            i += 8
        }
        return result.toIntArray()
    }

    private fun readHeaderLength(model: RomDataModel, start: Int): Int? {
        if (start < 0 || start + 4 > model.size) return null
        if (model[start] != MAGIC) return null
        return model.readLittleEndian(start + 1, 3)
    }

    /** The 2-byte back-reference token: byte1's high nibble is length-minus-3, byte1's low
     *  nibble plus all of byte2 form the 12-bit offset-minus-1 (byte1 first despite the format
     *  being little-endian everywhere else - see LZRun.cs's `ReadCompressedToken`). */
    private fun readBackReference(byte1: Int, byte2: Int): Pair<Int, Int> {
        val runLength = (byte1 shr 4) + MIN_MATCH_LENGTH
        val runOffset = (((byte1 and 0xF) shl 8) or byte2) + 1
        return runLength to runOffset
    }

    /**
     * Longest match ending before [start] (searching back at most [MAX_MATCH_OFFSET] bytes, not
     * before [earliest]), capped at [MAX_MATCH_LENGTH]. Returns (2, -1) - "no match" - both when
     * nothing qualifies and when [start] is odd: real GBA decompressors (`SWI 11h`) don't allow
     * a compressed token to start on an odd output byte, so the encoder must never emit one
     * there either. Overlapping matches (offset shorter than length) are allowed on purpose,
     * same as [decompress]'s copy loop - it's what lets a short repeating pattern compress well.
     */
    private fun findLongestMatch(data: IntArray, start: Int, earliest: Int, end: Int): Pair<Int, Int> {
        if (start % 2 == 1) return 2 to -1
        var bestLength = 2
        var bestOffset = -1
        var runOffset = 2
        while (runOffset <= MAX_MATCH_OFFSET && start - runOffset >= earliest) {
            var runLength = 0
            while (start + runLength < end &&
                runLength < MAX_MATCH_LENGTH &&
                data[start - runOffset + runLength] == data[start + runLength]
            ) {
                runLength++
            }
            if (runLength > bestLength) {
                bestLength = runLength
                bestOffset = runOffset
            }
            runOffset += 2
        }
        return bestLength to bestOffset
    }
}
