package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * One cell of a [TilemapRun]: which tile to draw from the paired tileset, optionally flipped,
 * plus which 16-color palette page to draw it with (only meaningful for a 4-bit-per-pixel
 * tileset - see [TilemapRun.getPixels]'s doc comment). [pack]/[unpack] mirror the GBA's own
 * hardware tilemap entry layout exactly, which is also exactly what HMA's `ReadTileData`/
 * `WriteTileData` implement - there's no HMA-specific reinterpretation here, unlike the
 * format-string DSL this project simplifies elsewhere.
 */
data class TilemapEntry(
    val tileIndex: Int,
    val hFlip: Boolean = false,
    val vFlip: Boolean = false,
    val paletteIndex: Int = 0,
) {
    fun pack(): Int {
        var value = tileIndex and 0x3FF
        if (hFlip) value = value or (1 shl 10)
        if (vFlip) value = value or (1 shl 11)
        value = value or ((paletteIndex and 0xF) shl 12)
        return value
    }

    override fun toString(): String {
        val flips = listOfNotNull("h".takeIf { hFlip }, "v".takeIf { vFlip }).joinToString("")
        val flipPart = if (flips.isEmpty()) "" else " $flips-flip"
        return "tile ${tileIndex.toString(16).uppercase()}, palette ${paletteIndex.toString(16).uppercase()}$flipPart"
    }

    companion object {
        fun unpack(raw: Int): TilemapEntry = TilemapEntry(
            tileIndex = raw and 0x3FF,
            hFlip = (raw shr 10) and 1 == 1,
            vFlip = (raw shr 11) and 1 == 1,
            paletteIndex = (raw shr 12) and 0xF,
        )
    }
}

/**
 * A GBA background tilemap occupying ROM bytes from [start]: [TilemapFormat.tileWidth] x
 * [TilemapFormat.tileHeight] [TilemapEntry] records, each 2 bytes, either stored directly or
 * [Lz77]-compressed. Only the standard 2-bytes-per-entry format is supported - the original
 * also has a 1-byte-per-entry legacy fallback (`ReadTileData`'s `bytesPerTile == 1` branch,
 * used when the decompressed data is too short for the 2-byte layout, encoding just a bare
 * tile index with no flip/palette bits) for a handful of older or hand-crafted tilemaps; this
 * project's format-string DSL has no way to request it, so it's out of scope rather than
 * half-supported.
 *
 * [length] is the ROM byte length - see [SpriteRun]'s doc comment for why a compressed run
 * needs its length computed against [RomDataModel] at construction time, via [create].
 */
data class TilemapRun(
    override val start: Int,
    val format: TilemapFormat,
    override val length: Int,
    override val pointerSources: List<Int> = emptyList(),
) : Run {
    companion object {
        /** Builds a [TilemapRun] at [start], computing [length] from [model] if compressed, and
         *  validating that `start + length` fits within [model] - see [SpriteRun.create]'s doc
         *  comment for why that check belongs here rather than in each caller. */
        fun create(model: RomDataModel, start: Int, format: TilemapFormat, pointerSources: List<Int> = emptyList()): TilemapRun {
            val length = if (format.compressed) {
                Lz77.compressedLength(model, start, format.allowLengthErrors)
                    ?: throw ImageFormatException("No valid compressed tilemap data was found at this address.")
            } else {
                format.decompressedLength
            }
            if (start + length > model.size) {
                throw ImageFormatException("This tilemap would run past the end of the ROM.")
            }
            return TilemapRun(start, format, length, pointerSources)
        }
    }
}

/** The full decoded (decompressed, if needed) byte buffer this run's tile entries are packed into. */
fun TilemapRun.decodedBytes(model: RomDataModel): IntArray {
    if (!format.compressed) return IntArray(length) { model[start + it] }
    return Lz77.decompress(model, start, format.allowLengthErrors)
        ?: throw ImageFormatException("Could not decompress tilemap data at this address.")
}

/** The [TilemapEntry] at tile-grid position ([tileX], [tileY]). Out-of-bounds coordinates or a
 *  truncated buffer read as an all-zero entry, same missing-data fallback used throughout this
 *  file's sibling Run types. */
fun TilemapRun.readEntry(model: RomDataModel, tileX: Int, tileY: Int): TilemapEntry {
    val data = decodedBytes(model)
    val offset = (tileY * format.tileWidth + tileX) * 2
    val raw = if (offset + 1 < data.size) data[offset] or (data[offset + 1] shl 8) else 0
    return TilemapEntry.unpack(raw)
}

/**
 * Writes a single [TilemapEntry] at ([tileX], [tileY]). Same fixed-length-in-place vs.
 * recompress-and-maybe-relocate split as [SpriteRun.setPixels]/[PaletteRun.setColors] - see
 * [SpriteRun.setPixels]'s doc comment for why a compressed run can't just assume its new
 * content still fits in the same space.
 */
fun TilemapRun.writeEntry(model: RomDataModel, tileX: Int, tileY: Int, entry: TilemapEntry, token: ModelDelta): TilemapRun {
    require(tileX in 0 until format.tileWidth && tileY in 0 until format.tileHeight) {
        "($tileX, $tileY) is outside this tilemap's ${format.tileWidth}x${format.tileHeight} grid."
    }
    val entryOffset = (tileY * format.tileWidth + tileX) * 2
    val packed = entry.pack()

    if (!format.compressed) {
        token.setByte(model, start + entryOffset, packed and 0xFF)
        token.setByte(model, start + entryOffset + 1, (packed shr 8) and 0xFF)
        return this
    }

    val data = decodedBytes(model)
    val newData = data.copyOf()
    if (entryOffset + 1 < newData.size) {
        newData[entryOffset] = packed and 0xFF
        newData[entryOffset + 1] = (packed shr 8) and 0xFF
    }

    val recompressed = Lz77.compress(newData)
    val relocated = recompressed.size > length
    val target = if (relocated) {
        Repointer.findFreeSpace(model, recompressed.size)
            ?: throw ImageFormatException("No free space big enough for ${recompressed.size} compressed bytes was found.")
    } else {
        start
    }

    if (relocated) {
        for (i in start until start + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    } else if (recompressed.size < length) {
        for (i in target + recompressed.size until target + length) token.setByte(model, i, Repointer.FREE_SPACE_BYTE)
    }
    for (i in recompressed.indices) token.setByte(model, target + i, recompressed[i])

    val sources = if (relocated) Repointer.repointReferences(model, start, target, token) else pointerSources
    return TilemapRun(start = target, format = format, length = recompressed.size, pointerSources = sources)
}

/**
 * Composes the full image: for every cell, looks up its tile in the [TilemapFormat.matchingTilesetAddress]
 * tileset (must already be a [SpriteRun]; if it isn't, or nothing is there yet, this returns an
 * all-zero grid rather than throwing - a tilemap is still meaningful to inspect and edit before
 * its tileset is defined, the same graceful fallback the original's `LzTilemapRun.GetPixels` uses).
 *
 * A 4-bit-per-pixel tile's palette-index nibble (see [TilemapEntry.paletteIndex]) is folded into
 * the result as `+ (paletteIndex shl 4)`, giving an absolute index into a combined 256-color
 * palette - see [PaletteFormat.initialBlankPages] for how a [PaletteRun] with fewer than 16
 * pages lines its own colors up against these absolute indices. This offset is added
 * unconditionally, even for an 8-bit-per-pixel tileset, matching the original exactly - real
 * GBA hardware ignores the palette nibble for 8bpp tiles (an 8bpp tile already selects from the
 * full 256-color palette directly), but HMA's own renderer doesn't special-case it either, so
 * neither does this.
 */
fun TilemapRun.getPixels(model: RomDataModel): IntArray {
    val pixelWidth = format.tileWidth * 8
    val pixelHeight = format.tileHeight * 8
    val blank = IntArray(pixelWidth * pixelHeight)
    val tileset = model.getRunAt(format.matchingTilesetAddress) as? SpriteRun ?: return blank

    val mapData = decodedBytes(model)
    val tilesetBytes = tileset.decodedBytes(model)
    val tileByteSize = format.bitsPerPixel * 8
    val pixels = IntArray(pixelWidth * pixelHeight)

    for (ty in 0 until format.tileHeight) {
        val yStart = ty * 8
        for (tx in 0 until format.tileWidth) {
            val xStart = tx * 8
            val entryOffset = (ty * format.tileWidth + tx) * 2
            val raw = if (entryOffset + 1 < mapData.size) mapData[entryOffset] or (mapData[entryOffset + 1] shl 8) else 0
            val entry = TilemapEntry.unpack(raw)
            val paletteOffset = entry.paletteIndex shl 4
            val tileStart = entry.tileIndex * tileByteSize
            val tilePixels = decodeTilePixels(tilesetBytes, tileStart, 1, 1, format.bitsPerPixel)

            for (yy in 0 until 8) {
                for (xx in 0 until 8) {
                    val inX = if (entry.hFlip) 7 - xx else xx
                    val inY = if (entry.vFlip) 7 - yy else yy
                    pixels[(yStart + yy) * pixelWidth + (xStart + xx)] = tilePixels[inY * 8 + inX] + paletteOffset
                }
            }
        }
    }
    return pixels
}
