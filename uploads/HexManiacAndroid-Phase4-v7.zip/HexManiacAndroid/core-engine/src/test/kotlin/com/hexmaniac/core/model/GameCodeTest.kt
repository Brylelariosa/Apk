package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class GameCodeTest {

    private fun modelWithHeader(code: String, version: Int): RomDataModel {
        val data = ByteArray(0xC0)
        for (i in code.indices) data[0xAC + i] = code[i].code.toByte()
        data[0xBC] = version.toByte()
        return RomDataModel(data)
    }

    @Test
    fun `reads a 4-character code plus version digit`() {
        val model = modelWithHeader("BPEE", 0)
        assertEquals("BPEE0", GameCode.read(model))
    }

    @Test
    fun `version byte is its own decimal value, not an ASCII digit character`() {
        // byte value 1 (0x01), not the ASCII character '1' (0x31) - see the doc comment on why
        // that distinction matters for how the original computes this same string.
        val model = modelWithHeader("AXVE", 1)
        assertEquals("AXVE1", GameCode.read(model))
    }

    @Test
    fun `returns null for a model too small to have a header`() {
        val model = RomDataModel(ByteArray(0x10))
        assertNull(GameCode.read(model))
    }

    @Test
    fun `displayName covers every known base game and its revisions`() {
        assertEquals("Ruby", GameCode.displayName("AXVE0"))
        assertEquals("Ruby", GameCode.displayName("AXVE1"))
        assertEquals("Sapphire", GameCode.displayName("AXPE0"))
        assertEquals("Emerald", GameCode.displayName("BPEE0"))
        assertEquals("FireRed", GameCode.displayName("BPRE0"))
        assertEquals("LeafGreen", GameCode.displayName("BPGE1"))
    }

    @Test
    fun `displayName is null for a code that isn't one of the known games`() {
        assertNull(GameCode.displayName("ABCD9"))
    }
}
