package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class SpriteRunTest {

    // 1x1 tile = a single 8x8-pixel sprite - the smallest useful size, keeps the compressed
    // byte sequences below (independently derived with a throwaway Python harness - see Lz77's
    // doc comment) small enough to read at a glance.
    private val uncompressed4bpp = SpriteFormat(bitsPerPixel = 4, tileWidth = 1, tileHeight = 1, compressed = false)
    private val compressed4bpp = SpriteFormat(bitsPerPixel = 4, tileWidth = 1, tileHeight = 1, compressed = true)

    private fun modelWithBytes(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size) { -1 } // 0xFF backdrop, like real ROM free space
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    @Test
    fun `create computes length from the format for an uncompressed sprite`() {
        val model = RomDataModel(ByteArray(0x40))
        val run = SpriteRun.create(model, 0, uncompressed4bpp)
        assertEquals(32, run.length) // 1 tile, 4bpp: 8*8*4/8 bytes
    }

    @Test
    fun `create computes length from the LZ header for a compressed sprite`() {
        val compressedZeroTile = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val model = modelWithBytes(0x40, 0 to compressedZeroTile)
        val run = SpriteRun.create(model, 0, compressed4bpp)
        assertEquals(11, run.length)
    }

    @Test
    fun `create throws when an uncompressed sprite would run past the end of the ROM`() {
        val model = RomDataModel(ByteArray(16)) // far smaller than the 32 bytes a 1x1 tile needs
        assertFailsWith<ImageFormatException> { SpriteRun.create(model, 0, uncompressed4bpp) }
    }

    @Test
    fun `create throws when there's no valid compressed data at the address`() {
        val model = RomDataModel(ByteArray(0x40) { -1 })
        assertFailsWith<ImageFormatException> { SpriteRun.create(model, 0, compressed4bpp) }
    }

    @Test
    fun `decoding unpacks a 4bpp byte's low and high nibble into adjacent pixels`() {
        val model = RomDataModel(ByteArray(0x40))
        val run = SpriteRun.create(model, 0, uncompressed4bpp)
        val token = ModelDelta()
        token.setByte(model, 0, 0x21)

        val pixels = run.getPixels(model)
        assertEquals(1, pixels[0]) // (x=0, y=0): low nibble
        assertEquals(2, pixels[1]) // (x=1, y=0): high nibble
    }

    @Test
    fun `uncompressed setPixels writes in place and round-trips through getPixels`() {
        val model = RomDataModel(ByteArray(0x40))
        val run = SpriteRun.create(model, 0, uncompressed4bpp)
        val token = ModelDelta()

        val pixels = IntArray(64) { it % 16 }
        val result = run.setPixels(model, pixels, token)

        assertEquals(0, result.start) // an uncompressed run's length can't change, so it never relocates
        assertEquals(pixels.toList(), result.getPixels(model).toList())
    }

    @Test
    fun `compressed setPixels that still fits overwrites in place`() {
        val compressedZeroTile = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val model = modelWithBytes(0x40, 0 to compressedZeroTile)
        val run = SpriteRun.create(model, 0, compressed4bpp)
        val token = ModelDelta()

        val allFives = IntArray(64) { 5 } // compresses to the same 11 bytes as the all-zero original
        val result = run.setPixels(model, allFives, token)

        assertEquals(0, result.start)
        assertEquals(11, result.length)
        assertEquals(allFives.toList(), result.getPixels(model).toList())
    }

    @Test
    fun `compressed setPixels that no longer fits relocates and repoints every reference`() {
        val compressedZeroTile = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val pointerToSprite = intArrayOf(0x00, 0x00, 0x00, 0x08) // GBA pointer to file offset 0
        val model = modelWithBytes(0x40, 0 to compressedZeroTile, 0x30 to pointerToSprite)
        val run = SpriteRun.create(model, 0, compressed4bpp)
        model.addRun(run)
        val token = ModelDelta()

        // varied enough to no longer compress down to 11 bytes (verified with the same Python
        // harness that checked Lz77 itself: this recompresses to 18 bytes)
        val variedPixels = IntArray(64) { it % 16 }
        val result = run.setPixels(model, variedPixels, token)

        assertEquals(11, result.start) // the first free stretch, right after the old run's own 11 bytes
        assertEquals(18, result.length)
        assertEquals(variedPixels.toList(), result.getPixels(model).toList())

        for (i in 0 until 11) assertEquals(Repointer.FREE_SPACE_BYTE, model[i]) // old space reclaimed
        assertEquals(result.start, model.readPointer(0x30)) // the reference now points at the new address
        assertEquals(listOf(0x30), result.pointerSources)
    }

    @Test
    fun `pageCount and getPixels read the correct page of a multi-page compressed sprite`() {
        // two 32-byte pages: page 0 all zero, page 1 all pixel-value-1 (byte 0x11 = both nibbles 1)
        val twoPageCompressed = intArrayOf(
            0x10, 0x40, 0x00, 0x00, 0x33, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01, 0x11, 0x11, 0xf0, 0x01, 0x90, 0x01,
        )
        val model = modelWithBytes(0x40, 0 to twoPageCompressed)
        val run = SpriteRun.create(model, 0, compressed4bpp)

        assertEquals(2, run.pageCount(model))
        assertTrue(run.getPixels(model, page = 0).all { it == 0 })
        assertTrue(run.getPixels(model, page = 1).all { it == 1 })
    }
}
