package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class StringRunTest {

    @Test
    fun `readText decodes fresh from the model`() {
        val model = RomDataModel(ByteArray(0x10) { -1 })
        val delta = ModelDelta()
        val bytes = PcsString.encode("Hi") // [0xC2, 0xDD, 0xFF]
        for (i in bytes.indices) delta.setByte(model, i, bytes[i])
        val run = StringRun(start = 0, length = bytes.size)

        assertEquals("Hi", run.readText(model))
    }

    @Test
    fun `writeText overwrites in place when the new text is the same length`() {
        val model = RomDataModel(ByteArray(0x10) { -1 })
        val delta = ModelDelta()
        val initial = PcsString.encode("Hi")
        for (i in initial.indices) delta.setByte(model, i, initial[i])
        val run = StringRun(start = 0, length = initial.size)

        val updated = run.writeText(model, "Ho", delta)

        assertEquals(0, updated.start) // fits in place - never moved
        assertEquals(3, updated.length) // "Ho" + terminator
        assertEquals("Ho", updated.readText(model))
    }

    @Test
    fun `writeText shrinks in place and frees the leftover tail`() {
        val model = RomDataModel(ByteArray(0x10) { -1 })
        val delta = ModelDelta()
        val initial = PcsString.encode("Hello") // 5 chars + terminator = 6 bytes
        for (i in initial.indices) delta.setByte(model, i, initial[i])
        val run = StringRun(start = 0, length = initial.size)

        val updated = run.writeText(model, "Hi", delta)

        assertEquals(0, updated.start)
        assertEquals(3, updated.length) // "Hi" + terminator
        assertEquals("Hi", updated.readText(model))
        assertEquals(0xFF, model[3]) // leftover tail freed, not left as stale "Hello" bytes
        assertEquals(0xFF, model[4])
        assertEquals(0xFF, model[5])
    }

    @Test
    fun `writeText relocates to free space and repoints references when the new text no longer fits`() {
        val model = RomDataModel(ByteArray(0x40) { -1 }) // 0xFF backdrop - plenty of free space
        val delta = ModelDelta()
        val initial = PcsString.encode("Hi") // [0xC2, 0xDD, 0xFF], 3 bytes
        for (i in initial.indices) delta.setByte(model, i, initial[i])
        model.writePointer(0x30, 0x00, delta) // a pointer targeting this string's current address

        val run = StringRun(start = 0, length = initial.size, pointerSources = listOf(0x30))
        model.addRun(run) // registered, so free-space search won't overlap this run's own bytes

        val updated = run.writeText(model, "Hello there", delta) // too long for the old 3-byte slot

        assertEquals(3, updated.start) // relocated just past the old (now-freed) slot
        assertEquals(12, updated.length) // "Hello there" (11 chars) + terminator
        assertEquals("Hello there", updated.readText(model))
        assertEquals(0xFF, model[0]) // old slot freed
        assertEquals(0xFF, model[1])
        assertEquals(0xFF, model[2])
        assertEquals(listOf(0x30), updated.pointerSources)
        assertEquals(updated.start, model.readPointer(0x30)) // the pointer now targets the new address
    }

    @Test
    fun `writeText throws when no free space is big enough for the new text`() {
        val model = RomDataModel(ByteArray(4)) // tiny ROM, nothing free anywhere
        val delta = ModelDelta()
        val run = StringRun(start = 0, length = 1)

        assertFailsWith<PcsEncodingException> { run.writeText(model, "Hello", delta) }
    }
}
