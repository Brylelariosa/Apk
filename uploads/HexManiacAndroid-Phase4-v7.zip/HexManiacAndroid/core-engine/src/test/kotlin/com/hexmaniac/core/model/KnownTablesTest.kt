package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class KnownTablesTest {

    @Test
    fun `parses a simple line with all 9 addresses the same`() {
        val line = "data.pokemon.names,144,144,144,144,144,144,144,144,144,[name\"\"11]"
        val result = KnownTables.parse(line)
        for (gameCode in KnownTables.GAME_CODES) {
            assertEquals(listOf("data.pokemon.names" to 0x144), result[gameCode], "for $gameCode")
        }
    }

    @Test
    fun `a blank address column is skipped for that game only`() {
        val line = "data.only.in.emerald,,,,,,,,,183b4,[foo]"
        val result = KnownTables.parse(line)
        assertEquals(emptyList(), result["AXVE0"])
        assertEquals(listOf("data.only.in.emerald" to 0x183b4), result["BPEE0"])
    }

    @Test
    fun `comment and blank lines are ignored`() {
        val text = "// a comment\n\ndata.real.entry,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf("data.real.entry" to 0x10), result["AXVE0"])
    }

    @Test
    fun `a leading UTF-8 BOM on the first line doesn't break parsing`() {
        val text = "\uFEFF//games, header, comment, line\ndata.real,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf("data.real" to 0x10), result["AXVE0"])
    }

    @Test
    fun `a format string containing its own commas doesn't disturb address parsing`() {
        val line = "data.tricky,10,10,10,10,10,10,10,10,10,|s=pocket(0=a|1=b|2=c) some,thing,with,commas"
        val result = KnownTables.parse(line)
        assertEquals(listOf("data.tricky" to 0x10), result["AXVE0"])
    }

    @Test
    fun `a line with too few columns is skipped rather than partially parsed`() {
        val text = "incomplete,10,10\ndata.real,10,10,10,10,10,10,10,10,10,[x]"
        val result = KnownTables.parse(text)
        assertEquals(listOf("data.real" to 0x10), result["AXVE0"])
    }

    @Test
    fun `the bundled resource parses to a substantial table for every known game`() {
        val bundled = KnownTables.bundled
        for (gameCode in KnownTables.GAME_CODES) {
            val count = bundled[gameCode]?.size ?: 0
            assertTrue(count > 100, "expected >100 entries for $gameCode, got $count")
        }
    }

    @Test
    fun `the bundled resource has the well-known pokemon names table for Emerald`() {
        val emerald = KnownTables.bundled.getValue("BPEE0").toMap()
        assertEquals(0x144, emerald["data.pokemon.names"])
    }
}
