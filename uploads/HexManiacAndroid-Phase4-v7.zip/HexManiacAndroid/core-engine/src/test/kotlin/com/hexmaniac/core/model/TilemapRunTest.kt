package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class TilemapRunTest {

    private fun modelWithBytes(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size) { -1 } // 0xFF backdrop, like real ROM free space
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    // --- TilemapEntry: pure bit-packing, no model needed ---

    @Test
    fun `TilemapEntry pack matches the GBA hardware tilemap entry layout`() {
        val entry = TilemapEntry(tileIndex = 0x105, hFlip = true, vFlip = false, paletteIndex = 7)
        assertEquals(0x7505, entry.pack())
    }

    @Test
    fun `TilemapEntry unpack is the inverse of pack across a spread of values`() {
        for (tileIndex in listOf(0, 1, 0x3FF, 0x105)) {
            for (hFlip in listOf(false, true)) {
                for (vFlip in listOf(false, true)) {
                    for (pal in listOf(0, 7, 0xF)) {
                        val entry = TilemapEntry(tileIndex, hFlip, vFlip, pal)
                        assertEquals(entry, TilemapEntry.unpack(entry.pack()))
                    }
                }
            }
        }
    }

    // --- create ---

    @Test
    fun `create computes length from the format for an uncompressed tilemap`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0, compressed = false)
        val run = TilemapRun.create(RomDataModel(ByteArray(0x40)), 0, format)
        assertEquals(8, run.length) // 4 entries * 2 bytes
    }

    @Test
    fun `create throws when an uncompressed tilemap would run past the end of the ROM`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0, compressed = false)
        val model = RomDataModel(ByteArray(4)) // far smaller than the 8 bytes 4 entries need
        assertFailsWith<ImageFormatException> { TilemapRun.create(model, 0, format) }
    }

    @Test
    fun `create throws when there's no valid compressed data at the address`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0, compressed = true)
        val model = RomDataModel(ByteArray(0x40) { -1 })
        assertFailsWith<ImageFormatException> { TilemapRun.create(model, 0, format) }
    }

    // --- readEntry / writeEntry ---

    @Test
    fun `uncompressed writeEntry writes in place and round-trips through readEntry`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 1, matchingTilesetAddress = 0, compressed = false)
        val model = RomDataModel(ByteArray(0x40))
        val run = TilemapRun.create(model, 0, format)
        val token = ModelDelta()

        run.writeEntry(model, 0, 0, TilemapEntry(tileIndex = 3, hFlip = true, vFlip = false, paletteIndex = 1), token)
        run.writeEntry(model, 1, 0, TilemapEntry(tileIndex = 9, hFlip = false, vFlip = true, paletteIndex = 5), token)

        assertEquals(TilemapEntry(3, hFlip = true, vFlip = false, paletteIndex = 1), run.readEntry(model, 0, 0))
        assertEquals(TilemapEntry(9, hFlip = false, vFlip = true, paletteIndex = 5), run.readEntry(model, 1, 0))
    }

    @Test
    fun `writeEntry rejects coordinates outside the tilemap's grid`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0, compressed = false)
        val model = RomDataModel(ByteArray(0x40))
        val run = TilemapRun.create(model, 0, format)
        assertFailsWith<IllegalArgumentException> { run.writeEntry(model, 2, 0, TilemapEntry(0), ModelDelta()) }
    }

    @Test
    fun `compressed writeEntry that no longer fits relocates and repoints every reference`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0, compressed = true)
        val allZeroCompressed = intArrayOf(0x10, 0x08, 0x00, 0x00, 0x20, 0x00, 0x00, 0x30, 0x01) // 9 bytes
        val pointerToTilemap = intArrayOf(0x00, 0x00, 0x00, 0x08)
        val model = modelWithBytes(0x40, 0 to allZeroCompressed, 0x30 to pointerToTilemap)
        val run = TilemapRun.create(model, 0, format)
        model.addRun(run)
        val token = ModelDelta()

        // verified with the same Python harness that checked Lz77 itself: writing this one
        // entry recompresses the 8-byte buffer to 11 bytes, no longer fitting in the original 9.
        val entry = TilemapEntry(tileIndex = 5, hFlip = true, vFlip = false, paletteIndex = 3)
        val result = run.writeEntry(model, 0, 0, entry, token)

        assertEquals(9, result.start)
        assertEquals(11, result.length)
        assertEquals(entry, result.readEntry(model, 0, 0))
        assertEquals(TilemapEntry(0), result.readEntry(model, 1, 0)) // untouched cell stays default

        for (i in 0 until 9) assertEquals(Repointer.FREE_SPACE_BYTE, model[i])
        assertEquals(result.start, model.readPointer(0x30))
    }

    // --- getPixels: tile selection, flips, and palette-page composition ---

    @Test
    fun `getPixels selects the right tile, applies flips, and folds in the palette offset`() {
        // tileset: tile 0 has a single marker pixel at its own (0,0); tile 1 is uniformly 2.
        val tile0 = intArrayOf(0x01) + IntArray(31)
        val tile1 = IntArray(32) { 0x22 }
        val tilesetBytes = tile0 + tile1
        val tilesetFormat = SpriteFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 1, compressed = false)

        val tilemapFormat = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 1, matchingTilesetAddress = 0, compressed = false)
        // cell (0,0): tile 0, h-flipped, palette 0 -> marker moves from local (0,0) to local (7,0)
        val cell0 = TilemapEntry(tileIndex = 0, hFlip = true, vFlip = false, paletteIndex = 0).pack()
        // cell (1,0): tile 1, no flip, palette 2 -> every pixel is 2 + (2 << 4) = 34
        val cell1 = TilemapEntry(tileIndex = 1, hFlip = false, vFlip = false, paletteIndex = 2).pack()
        val tilemapBytes = intArrayOf(cell0 and 0xFF, (cell0 shr 8) and 0xFF, cell1 and 0xFF, (cell1 shr 8) and 0xFF)

        val model = modelWithBytes(0x100, 0 to tilesetBytes, 0x80 to tilemapBytes)
        model.addRun(SpriteRun.create(model, 0, tilesetFormat))
        val tilemap = TilemapRun.create(model, 0x80, tilemapFormat)

        val pixels = tilemap.getPixels(model) // 16 wide x 8 tall
        val width = 16

        assertEquals(1, pixels[0 * width + 7]) // marker, h-flipped into the top-right of the left cell
        assertEquals(0, pixels[0 * width + 0]) // marker is no longer at its unflipped position
        assertEquals(0, pixels[7 * width + 7]) // not v-flipped, so not at the bottom either
        for (y in 0 until 8) for (x in 8 until 16) assertEquals(34, pixels[y * width + x]) // right cell: tile 1 + palette 2
    }

    @Test
    fun `getPixels returns a blank grid when the tileset address isn't a sprite`() {
        val format = TilemapFormat(bitsPerPixel = 4, tileWidth = 2, tileHeight = 2, matchingTilesetAddress = 0x999, compressed = false)
        val model = RomDataModel(ByteArray(0x40)) // nothing registered at 0x999
        val run = TilemapRun.create(model, 0, format)

        assertEquals(IntArray(16 * 16).toList(), run.getPixels(model).toList())
    }
}
