package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class PcsStringTest {

    private fun modelOf(vararg bytes: Int): RomDataModel {
        val model = RomDataModel(ByteArray(bytes.size))
        val delta = ModelDelta()
        for (i in bytes.indices) delta.setByte(model, i, bytes[i])
        return model
    }

    @Test
    fun `encode maps plain letters, digits, and punctuation to their PCS bytes`() {
        // 'A'=0xBB (start of the A-Z run), 'B'=0xBC, ' '=0x00, '1'=0xA2 (0xA1 is '0'), '!'=0xAB
        assertEquals(listOf(0xBB, 0xBC, 0x00, 0xA2, 0xAB, 0xFF), PcsString.encode("AB 1!"))
    }

    @Test
    fun `decode reads plain characters and stops at the terminator, ignoring bytes after it`() {
        val model = modelOf(0xBB, 0xBC, 0xFF, 0xAA)
        val decoded = PcsString.decode(model, 0)
        assertEquals("AB", decoded.text)
        assertEquals(3, decoded.byteLength) // 2 content bytes + the terminator
    }

    @Test
    fun `decode stops at the given limit even with no terminator in range`() {
        val model = modelOf(0xBB, 0xBC, 0xBD)
        val decoded = PcsString.decode(model, 0, limit = 2)
        assertEquals("AB", decoded.text)
        assertEquals(2, decoded.byteLength)
    }

    @Test
    fun `encode and decode round-trip a real newline through 0xFE`() {
        val bytes = PcsString.encode("A\nB")
        assertEquals(listOf(0xBB, 0xFE, 0xBC, 0xFF), bytes)

        val model = RomDataModel(ByteArray(bytes.size))
        val delta = ModelDelta()
        for (i in bytes.indices) delta.setByte(model, i, bytes[i])
        assertEquals("A\nB", PcsString.decode(model, 0).text)
    }

    @Test
    fun `decode falls back to a raw hex escape for a byte with no table entry`() {
        // 0x30 falls in a genuine gap in the reference table (between \+ at 0x2E and \Lv at 0x34).
        val model = modelOf(0x30, 0xFF)
        val decoded = PcsString.decode(model, 0)
        assertEquals("\\!30", decoded.text)
        assertEquals(2, decoded.byteLength)
    }

    @Test
    fun `encode parses a raw hex escape back to its exact byte`() {
        assertEquals(listOf(0x30, 0xFF), PcsString.encode("\\!30"))
    }

    @Test
    fun `single-byte special glyphs round-trip as their escape token`() {
        // 0x34 is the "Lv" logo glyph - a single byte with no argument.
        val model = modelOf(0x34, 0xFF)
        assertEquals("\\Lv", PcsString.decode(model, 0).text)
        assertEquals(listOf(0x34, 0xFF), PcsString.encode("\\Lv"))
    }

    @Test
    fun `a one-argument-byte escape round-trips its raw argument as hex`() {
        // 0xF7 (DynamicEscape) always consumes exactly one raw byte after it.
        val model = modelOf(0xF7, 0x05, 0xFF)
        val decoded = PcsString.decode(model, 0)
        assertEquals("\\?05", decoded.text)
        assertEquals(3, decoded.byteLength)
        assertEquals(listOf(0xF7, 0x05, 0xFF), PcsString.encode("\\?05"))
    }

    @Test
    fun `a no-argument function escape round-trips with just its sub-code`() {
        // sub-code 0x09 (pause) takes no arguments per the reference's CC_09 entry.
        val model = modelOf(0xFC, 0x09, 0xFF)
        val decoded = PcsString.decode(model, 0)
        assertEquals("\\CC09", decoded.text)
        assertEquals(3, decoded.byteLength)
        assertEquals(listOf(0xFC, 0x09, 0xFF), PcsString.encode("\\CC09"))
    }

    @Test
    fun `a multi-argument function escape round-trips every argument byte`() {
        // sub-code 0x04 (text shadow/highlight) takes 3 argument bytes per the reference's CC_04 entry.
        val model = modelOf(0xFC, 0x04, 0x01, 0x02, 0x03, 0xFF)
        val decoded = PcsString.decode(model, 0)
        assertEquals("\\CC04010203", decoded.text)
        assertEquals(6, decoded.byteLength)
        assertEquals(listOf(0xFC, 0x04, 0x01, 0x02, 0x03, 0xFF), PcsString.encode("\\CC04010203"))
    }

    @Test
    fun `encode always appends a terminator, even for empty input`() {
        assertEquals(listOf(0xFF), PcsString.encode(""))
    }

    @Test
    fun `encode rejects a character outside the PCS set, naming it and its position`() {
        val exception = assertFailsWith<PcsEncodingException> { PcsString.encode("Hi@") }
        assertTrue(exception.message!!.contains("@"))
        assertTrue(exception.message!!.contains("2")) // position of '@' in "Hi@"
    }
}
