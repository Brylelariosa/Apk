package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class ImageFormatTest {

    // --- sprite ---

    @Test
    fun `parses an uncompressed sprite format`() {
        val format = ImageFormat.parseSprite("`ucs4x4x4`")
        assertEquals(SpriteFormat(bitsPerPixel = 4, tileWidth = 4, tileHeight = 4, compressed = false), format)
    }

    @Test
    fun `parses a compressed sprite format`() {
        val format = ImageFormat.parseSprite("`lzs4x8x8`")
        assertEquals(SpriteFormat(bitsPerPixel = 4, tileWidth = 8, tileHeight = 8, compressed = true), format)
    }

    @Test
    fun `parses a sprite format's trailing allow-length-errors flag`() {
        val format = ImageFormat.parseSprite("`lzs8x4x4!`")
        assertTrue(format.allowLengthErrors)
    }

    @Test
    fun `rejects a sprite format with the wrong prefix`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parseSprite("`ucp4`") }
    }

    @Test
    fun `rejects a sprite format with an invalid bits-per-pixel`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parseSprite("`ucs3x4x4`") }
    }

    @Test
    fun `rejects a sprite format missing a dimension`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parseSprite("`ucs4x4`") }
    }

    // --- palette ---

    @Test
    fun `parses a single-page palette format`() {
        val format = ImageFormat.parsePalette("`ucp4`")
        assertEquals(PaletteFormat(bits = 4, pages = 1, initialBlankPages = 0, compressed = false), format)
    }

    @Test
    fun `parses a multi-page compressed palette format`() {
        val format = ImageFormat.parsePalette("`lzp4:03`")
        assertEquals(PaletteFormat(bits = 4, pages = 4, initialBlankPages = 0, compressed = true), format)
    }

    @Test
    fun `parses a palette page range that doesn't start at zero`() {
        val format = ImageFormat.parsePalette("`ucp4:24`")
        assertEquals(2, format.initialBlankPages)
        assertEquals(3, format.pages) // slots 2, 3, 4 inclusive
    }

    @Test
    fun `rejects a palette page range written end-before-start`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parsePalette("`ucp4:40`") }
    }

    @Test
    fun `rejects a palette format with an invalid bit depth`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parsePalette("`ucp6`") }
    }

    // --- tilemap ---

    @Test
    fun `parses a tilemap format with its tileset address`() {
        val format = ImageFormat.parseTilemap("`lzm4x4x4|1A2B3C`")
        assertEquals(TilemapFormat(bitsPerPixel = 4, tileWidth = 4, tileHeight = 4, matchingTilesetAddress = 0x1A2B3C, compressed = true), format)
    }

    @Test
    fun `parses a tilemap tileset address with a leading 0x`() {
        val format = ImageFormat.parseTilemap("`ucm8x2x2|0x100`")
        assertEquals(0x100, format.matchingTilesetAddress)
    }

    @Test
    fun `rejects a tilemap format missing its tileset address`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parseTilemap("`lzm4x4x4`") }
    }

    @Test
    fun `rejects a tilemap format with a non-hex tileset address`() {
        assertFailsWith<ImageFormatException> { ImageFormat.parseTilemap("`lzm4x4x4|notanaddress`") }
    }
}
