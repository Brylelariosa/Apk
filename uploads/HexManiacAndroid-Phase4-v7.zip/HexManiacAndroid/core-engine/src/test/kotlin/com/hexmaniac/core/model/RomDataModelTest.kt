package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class RomDataModelTest {

    @Test
    fun `pointer round-trips through write and read`() {
        val model = RomDataModel(ByteArray(0x100))
        val delta = ModelDelta()
        model.writePointer(0x10, 0x50, delta)
        assertEquals(0x50, model.readPointer(0x10))
        assertEquals(0x08, model[0x13]) // top address byte for the 0x08000000 GBA ROM space
    }

    @Test
    fun `all-zero bytes are not a valid pointer`() {
        val model = RomDataModel(ByteArray(4))
        assertEquals(-1, model.readPointer(0))
    }

    @Test
    fun `all-0xFF bytes are not a valid pointer`() {
        val model = RomDataModel(byteArrayOf(-1, -1, -1, -1))
        assertEquals(-1, model.readPointer(0))
    }

    @Test
    fun `pointer scanner finds planted pointers amid noise`() {
        val data = ByteArray(0x200) { -1 } // 0xFF noise that must not look like a pointer
        val model = RomDataModel(data)
        val delta = ModelDelta()
        model.writePointer(0x20, 0x100, delta)
        model.writePointer(0x40, 0x180, delta)

        val found = PointerScanner.scan(model).map { it.start }.toSet()
        assertTrue(0x20 in found)
        assertTrue(0x40 in found)
        assertTrue(found.none { it > 0x44 && it < 0x1F8 })
    }

    @Test
    fun `run lookup finds the containing run at its start, middle, and last byte`() {
        val model = RomDataModel(ByteArray(0x50))
        model.addRun(UnknownRun(0x10, 0x10)) // covers [0x10, 0x20)
        model.addRun(PointerRun(0x30))        // covers [0x30, 0x34)

        assertEquals(0x10, model.getRunAt(0x10)?.start)
        assertEquals(0x10, model.getRunAt(0x15)?.start)
        assertEquals(0x10, model.getRunAt(0x1F)?.start)
        assertNull(model.getRunAt(0x25))
        assertEquals(0x30, model.getRunAt(0x32)?.start)
    }

    @Test
    fun `removeRun undoes a previous addRun so the address looks unclaimed again`() {
        val model = RomDataModel(ByteArray(0x20))
        model.addRun(UnknownRun(0x10, 0x8))
        assertEquals(0x10, model.getRunAt(0x12)?.start)

        model.removeRun(0x10)

        assertNull(model.getRunAt(0x12))
    }

    @Test
    fun `removeRun is a no-op for an address with nothing registered`() {
        val model = RomDataModel(ByteArray(0x20))
        model.removeRun(0x10) // should not throw
        assertNull(model.getRunAt(0x10))
    }

    @Test
    fun `anchor names resolve in both directions`() {
        val model = RomDataModel(ByteArray(0x100))
        model.setAnchor(0x50, "data.pokemon.names")
        assertEquals("data.pokemon.names", model.anchorAt(0x50))
        assertEquals(0x50, model.addressForAnchor("data.pokemon.names"))
        assertNull(model.anchorAt(0x60))
        assertNull(model.addressForAnchor("data.unset"))
    }

    @Test
    fun `re-anchoring an address drops its old name`() {
        val model = RomDataModel(ByteArray(0x100))
        model.setAnchor(0x50, "old.name")
        model.setAnchor(0x50, "new.name")
        assertEquals("new.name", model.anchorAt(0x50))
        assertNull(model.addressForAnchor("old.name")) // the old name must not still resolve anywhere
    }

    @Test
    fun `naming a second address with an existing name steals it from the first`() {
        val model = RomDataModel(ByteArray(0x100))
        model.setAnchor(0x50, "shared.name")
        model.setAnchor(0x60, "shared.name")
        assertEquals(0x60, model.addressForAnchor("shared.name")) // name always resolves to exactly one address
        assertNull(model.anchorAt(0x50)) // its previous address no longer claims the name
        assertEquals("shared.name", model.anchorAt(0x60))
    }

    @Test
    fun `removeAnchor clears both directions`() {
        val model = RomDataModel(ByteArray(0x100))
        model.setAnchor(0x50, "data.pokemon.names")
        model.removeAnchor(0x50)
        assertNull(model.anchorAt(0x50))
        assertNull(model.addressForAnchor("data.pokemon.names"))
    }

    @Test
    fun `anchors map exposes every known (address, name) pair`() {
        val model = RomDataModel(ByteArray(0x100))
        model.setAnchor(0x50, "a")
        model.setAnchor(0x60, "b")
        assertEquals(mapOf(0x50 to "a", 0x60 to "b"), model.anchors)
    }
}
