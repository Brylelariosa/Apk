package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull

class TableRunTest {

    private fun sampleTable(start: Int = 0x10, count: Int = 4) = TableRun(
        start = start,
        segments = listOf(NumericField("hp", 1), NumericField("id", 2), PointerField("desc"), TextField("name", 6)),
        elementCount = count,
    )

    @Test
    fun `element length is the sum of its fields`() {
        val table = sampleTable()
        assertEquals(1 + 2 + 4 + 6, table.elementLength)
        assertEquals(table.elementLength * 4, table.length)
    }

    @Test
    fun `rowStart and fieldStart follow row-major layout`() {
        val table = sampleTable(start = 0x100)
        assertEquals(0x100, table.rowStart(0))
        assertEquals(0x100 + table.elementLength, table.rowStart(1))
        assertEquals(0x100 + table.elementLength, table.fieldStart(1, 0))
        assertEquals(0x100 + table.elementLength + 1, table.fieldStart(1, 1)) // past "hp"
        assertEquals(0x100 + table.elementLength + 1 + 2, table.fieldStart(1, 2)) // past "hp" + "id"
    }

    @Test
    fun `rowStart rejects an out-of-range row`() {
        val table = sampleTable(count = 4)
        assertFailsWith<IllegalArgumentException> { table.rowStart(4) }
        assertFailsWith<IllegalArgumentException> { table.rowStart(-1) }
    }

    @Test
    fun `numeric field round-trips through write and read at every supported width`() {
        val model = RomDataModel(ByteArray(0x100))
        val table = TableRun(
            start = 0,
            segments = listOf(NumericField("a", 1), NumericField("b", 2), NumericField("c", 3), NumericField("d", 4)),
            elementCount = 1,
        )
        val delta = ModelDelta()
        table.writeNumeric(model, 0, 0, 0xAB, delta)
        table.writeNumeric(model, 0, 1, 0xBEEF, delta)
        table.writeNumeric(model, 0, 2, 0xC0FFEE, delta)
        table.writeNumeric(model, 0, 3, -1, delta) // all-0xFF bit pattern at 4 bytes wide

        assertEquals(0xAB, table.readNumeric(model, 0, 0))
        assertEquals(0xBEEF, table.readNumeric(model, 0, 1))
        assertEquals(0xC0FFEE, table.readNumeric(model, 0, 2))
        assertEquals(-1, table.readNumeric(model, 0, 3))
    }

    @Test
    fun `pointer field reuses RomDataModel's own GBA pointer encoding`() {
        val model = RomDataModel(ByteArray(0x100))
        val table = TableRun(start = 0x20, segments = listOf(PointerField("target")), elementCount = 1)
        val delta = ModelDelta()
        table.writePointerField(model, 0, 0, 0x50, delta)

        assertEquals(0x50, table.readPointerField(model, 0, 0))
        assertEquals(0x50, model.readPointer(0x20)) // identical bytes RomDataModel itself would read
    }

    @Test
    fun `text field round-trips, padding with 00 and terminating with FF`() {
        val model = RomDataModel(ByteArray(0x20))
        val table = TableRun(start = 0, segments = listOf(TextField("name", 6)), elementCount = 1)
        val delta = ModelDelta()
        table.writeText(model, 0, 0, "Bob", delta)

        assertEquals("Bob", table.readText(model, 0, 0))
        assertEquals(0xBC, model[0]) // PCS 'B' (0xBB + 1), not ASCII 0x42 - see PcsString
        assertEquals(0xFF, model[3]) // terminator right after the 3 written characters
        assertEquals(0x00, model[4]) // padding
        assertEquals(0x00, model[5])
    }

    @Test
    fun `text field truncates input that doesn't fit, reserving a byte for the terminator`() {
        val model = RomDataModel(ByteArray(0x20))
        val table = TableRun(start = 0, segments = listOf(TextField("name", 4)), elementCount = 1)
        val delta = ModelDelta()
        table.writeText(model, 0, 0, "TooLongAName", delta)

        assertEquals("Too", table.readText(model, 0, 0)) // 3 chars + 1 terminator byte = 4
    }

    @Test
    fun `calling the wrong accessor for a field's actual type fails loudly instead of misreading bytes`() {
        val model = RomDataModel(ByteArray(0x20))
        val table = TableRun(start = 0, segments = listOf(NumericField("hp", 1)), elementCount = 1)
        assertFailsWith<IllegalArgumentException> { table.readText(model, 0, 0) }
        assertFailsWith<IllegalArgumentException> { table.readPointerField(model, 0, 0) }
    }

    @Test
    fun `slots into RomDataModel's run lookup like any other Run`() {
        val model = RomDataModel(ByteArray(0x100))
        val table = sampleTable(start = 0x10, count = 4)
        model.addRun(table)

        assertEquals(0x10, model.getRunAt(0x10)?.start)
        assertEquals(0x10, model.getRunAt(0x10 + table.elementLength * 2)?.start) // inside row 2
        assertNull(model.getRunAt(0x10 + table.length)) // just past the table's last byte
    }
}
