package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class RepointerTest {

    @Test
    fun `findFreeSpace finds the first run of 0xFF at least as long as requested`() {
        val data = ByteArray(0x20) { 0x00 } // not free space by default
        for (i in 0x10..0x1F) data[i] = -1 // 0xFF for 16 bytes
        val model = RomDataModel(data)

        assertEquals(0x10, Repointer.findFreeSpace(model, minLength = 8))
    }

    @Test
    fun `findFreeSpace skips a run of 0xFF that's too short before finding a long enough one`() {
        val data = ByteArray(0x30) { 0x00 }
        for (i in 0x05..0x07) data[i] = -1 // only 3 bytes free - too short
        for (i in 0x20..0x2F) data[i] = -1 // 16 bytes free - long enough
        val model = RomDataModel(data)

        assertEquals(0x20, Repointer.findFreeSpace(model, minLength = 10))
    }

    @Test
    fun `findFreeSpace returns null when nothing is long enough`() {
        val model = RomDataModel(ByteArray(0x20) { -1 }) // all free, but only 0x20 bytes total
        assertNull(Repointer.findFreeSpace(model, minLength = 0x30))
    }

    @Test
    fun `findFreeSpace skips 0xFF bytes that another run already claims`() {
        val model = RomDataModel(ByteArray(0x20) { -1 }) // entirely 0xFF
        model.addRun(UnknownRun(0x00, 0x10)) // claims [0x00, 0x10) even though it's 0xFF-filled

        assertEquals(0x10, Repointer.findFreeSpace(model, minLength = 8))
    }

    @Test
    fun `repointReferences rewrites every pointer targeting the old address and only those`() {
        // 0xFF backdrop (not zero) so a stray 4-byte window can never misread as a pointer -
        // GBA pointers always have 0x08 or 0x09 as their top byte, which an all-0xFF window
        // (top byte 0xFF) can't produce even by partial overlap with a real, planted pointer.
        val model = RomDataModel(ByteArray(0x40) { -1 })
        val delta = ModelDelta()
        model.writePointer(0x00, 0x30, delta) // targets the address being moved
        model.writePointer(0x10, 0x31, delta) // targets a different address - must not change
        model.writePointer(0x20, 0x30, delta) // also targets the address being moved

        val rewritten = Repointer.repointReferences(model, oldAddress = 0x30, newAddress = 0x38, delta)

        assertEquals(setOf(0x00, 0x20), rewritten.toSet())
        assertEquals(0x38, model.readPointer(0x00))
        assertEquals(0x31, model.readPointer(0x10)) // untouched
        assertEquals(0x38, model.readPointer(0x20))
    }
}
