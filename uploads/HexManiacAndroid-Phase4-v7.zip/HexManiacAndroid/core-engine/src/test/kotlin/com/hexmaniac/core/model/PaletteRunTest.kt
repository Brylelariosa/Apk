package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class PaletteRunTest {

    private val uncompressed4bit = PaletteFormat(bits = 4, pages = 1, initialBlankPages = 0, compressed = false)
    private val compressed4bit = PaletteFormat(bits = 4, pages = 1, initialBlankPages = 0, compressed = true)

    private fun modelWithBytes(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size) { -1 } // 0xFF backdrop, like real ROM free space
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    private fun modelWithBytesZeroBackdrop(size: Int, vararg contentAt: Pair<Int, IntArray>): RomDataModel {
        val data = ByteArray(size)
        for ((offset, bytes) in contentAt) for (i in bytes.indices) data[offset + i] = bytes[i].toByte()
        return RomDataModel(data)
    }

    @Test
    fun `create computes length as bytesPerPage times pages for a 4-bit uncompressed palette`() {
        val format = PaletteFormat(bits = 4, pages = 3, initialBlankPages = 0, compressed = false)
        val run = PaletteRun.create(RomDataModel(ByteArray(0x100)), 0, format)
        assertEquals(96, run.length) // 3 pages * 16 colors * 2 bytes
    }

    @Test
    fun `create always uses 512 bytes for an 8-bit uncompressed palette, regardless of pages`() {
        // 256 colors already is the entire space a GBA background palette can address - see
        // PaletteRun.create's doc comment for why "pages" doesn't multiply this, matching the
        // original's own hardcoded special case.
        val format = PaletteFormat(bits = 8, pages = 3, initialBlankPages = 0, compressed = false)
        val run = PaletteRun.create(RomDataModel(ByteArray(0x400)), 0, format)
        assertEquals(512, run.length)
    }

    @Test
    fun `create computes length from the LZ header for a compressed palette`() {
        val compressedZero = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val model = modelWithBytes(0x40, 0 to compressedZero)
        val run = PaletteRun.create(model, 0, compressed4bit)
        assertEquals(11, run.length)
    }

    @Test
    fun `create throws when an uncompressed palette would run past the end of the ROM`() {
        val model = RomDataModel(ByteArray(16)) // far smaller than the 32 bytes a 16-color palette needs
        assertFailsWith<ImageFormatException> { PaletteRun.create(model, 0, uncompressed4bit) }
    }

    @Test
    fun `create throws when there's no valid compressed data at the address`() {
        val model = RomDataModel(ByteArray(0x40) { -1 })
        assertFailsWith<ImageFormatException> { PaletteRun.create(model, 0, compressed4bit) }
    }

    @Test
    fun `getColors reads raw 15-bit values little-endian`() {
        val model = modelWithBytesZeroBackdrop(
            0x40,
            0 to intArrayOf(0x00, 0x00), // color 0: black
            2 to intArrayOf(0x1F, 0x00), // color 1: red (bits 0-4)
            4 to intArrayOf(0xFF, 0x7F), // color 2: white
        )
        val run = PaletteRun.create(model, 0, uncompressed4bit)
        val colors = run.getColors(model)

        assertEquals(0x0000, colors[0])
        assertEquals(0x001F, colors[1])
        assertEquals(0x7FFF, colors[2])
    }

    @Test
    fun `uncompressed setColors writes in place and round-trips through getColors`() {
        val model = RomDataModel(ByteArray(0x40))
        val run = PaletteRun.create(model, 0, uncompressed4bit)
        val token = ModelDelta()

        val colors = IntArray(16) { it * 0x111 } // 16 distinct raw 15-bit-ish values
        val result = run.setColors(model, colors, token)

        assertEquals(0, result.start)
        assertEquals(colors.toList(), result.getColors(model).toList())
    }

    @Test
    fun `compressed setColors that still fits overwrites in place`() {
        val compressedZero = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val model = modelWithBytes(0x40, 0 to compressedZero)
        val run = PaletteRun.create(model, 0, compressed4bit)
        val token = ModelDelta()

        val allBlack = IntArray(16) // still compresses to 11 bytes, same as the all-zero original
        val result = run.setColors(model, allBlack, token)

        assertEquals(0, result.start)
        assertEquals(11, result.length)
        assertEquals(allBlack.toList(), result.getColors(model).toList())
    }

    @Test
    fun `compressed setColors that no longer fits relocates and repoints every reference`() {
        val compressedZero = intArrayOf(0x10, 0x20, 0x00, 0x00, 0x30, 0x00, 0x00, 0xf0, 0x01, 0x90, 0x01)
        val pointerToPalette = intArrayOf(0x00, 0x00, 0x00, 0x08) // GBA pointer to file offset 0
        val model = modelWithBytes(0x80, 0 to compressedZero, 0x50 to pointerToPalette)
        val run = PaletteRun.create(model, 0, compressed4bit)
        model.addRun(run)
        val token = ModelDelta()

        // 16 distinct colors - verified with the same Python harness that checked Lz77 itself:
        // this recompresses to 40 bytes, no longer fitting in the original 11.
        val distinctColors = IntArray(16) { it }
        val result = run.setColors(model, distinctColors, token)

        assertEquals(11, result.start) // the first free stretch, right after the old run's own 11 bytes
        assertEquals(40, result.length)
        assertEquals(distinctColors.toList(), result.getColors(model).toList())

        for (i in 0 until 11) assertEquals(Repointer.FREE_SPACE_BYTE, model[i]) // old space reclaimed
        assertEquals(result.start, model.readPointer(0x50))
        assertEquals(listOf(0x50), result.pointerSources)
    }

    @Test
    fun `a second page reads from its own offset, independent of the first`() {
        val format = PaletteFormat(bits = 4, pages = 2, initialBlankPages = 0, compressed = false)
        val model = RomDataModel(ByteArray(0x40))
        val run = PaletteRun.create(model, 0, format)
        val token = ModelDelta()

        run.setColors(model, IntArray(16) { 0 }, token, page = 0)
        run.setColors(model, IntArray(16) { 0x1F }, token, page = 1)

        assertEquals(List(16) { 0 }, run.getColors(model, page = 0).toList())
        assertEquals(List(16) { 0x1F }, run.getColors(model, page = 1).toList())
    }
}
