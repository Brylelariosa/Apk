package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class Lz77Test {

    private fun modelOf(vararg bytes: Int): RomDataModel = RomDataModel(ByteArray(bytes.size) { bytes[it].toByte() })

    @Test
    fun `decompresses an all-literal stream`() {
        // header says 5 bytes, one bitfield 0x00 (5 literals, the trailing 3 bitfield slots unused)
        val model = modelOf(0x10, 0x05, 0x00, 0x00, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55)
        val result = Lz77.decompress(model, 0)
        assertEquals(listOf(0x11, 0x22, 0x33, 0x44, 0x55), result?.toList())
    }

    @Test
    fun `decompresses a back-reference that copies bytes still being written`() {
        // "AB" (2 literals) then a run copying 4 bytes from 2 back -> "AB" + "ABAB" = "ABABAB",
        // an overlapping copy since offset(2) is shorter than length(4).
        val bitField = 0b00100000 // slot0=literal, slot1=literal, slot2=compressed
        val model = modelOf(0x10, 0x06, 0x00, 0x00, bitField, 0x41, 0x42, 0x10, 0x01)
        val result = Lz77.decompress(model, 0)
        assertEquals("ABABAB", result?.map { it.toChar() }?.joinToString(""))
    }

    @Test
    fun `compress then decompress round-trips repeating data smaller than the original`() {
        val original = IntArray(20) { 0xAB }
        val compressed = Lz77.compress(original)
        assertEquals(original.toList(), Lz77.decompress(modelOfBytes(compressed), 0)?.toList())
        assert(compressed.size < original.size) { "repeating data should compress smaller than raw" }
    }

    @Test
    fun `compress then decompress round-trips varied data`() {
        val original = IntArray(4 * 4 * 8 * 4) { (it * 37 + 11) % 256 } // sized like a 4x4-tile 4bpp sprite
        val compressed = Lz77.compress(original)
        assertEquals(original.toList(), Lz77.decompress(modelOfBytes(compressed), 0)?.toList())
    }

    @Test
    fun `compress then decompress round-trips all-literal data too short to match`() {
        val original = intArrayOf(1, 2, 3, 4)
        val compressed = Lz77.compress(original)
        // hand-traced: no 3-byte match is possible in 4 bytes of strictly-increasing data, so
        // every byte is a literal - 4 header bytes + 1 bitfield byte + 4 literal bytes.
        assertEquals(9, compressed.size)
        assertEquals(original.toList(), Lz77.decompress(modelOfBytes(compressed), 0)?.toList())
    }

    @Test
    fun `compressedLength matches the actual number of bytes compress produced`() {
        val data = IntArray(64) { (it * 13) % 256 }
        val compressed = Lz77.compress(data)
        assertEquals(compressed.size, Lz77.compressedLength(modelOfBytes(compressed), 0))
    }

    @Test
    fun `compressedLength and decompress both see through leading offset and trailing free space`() {
        val sprite = IntArray(4 * 4 * 8 * 4) { i -> if ((i / 8) % 3 == 0) 0 else (i * 7 + 3) % 256 }
        val compressed = Lz77.compress(sprite)
        val rom = ByteArray(4096) { -1 } // 0xFF backdrop, like real ROM free space
        for (i in compressed.indices) rom[0x100 + i] = compressed[i].toByte()
        val model = RomDataModel(rom)

        assertEquals(compressed.size, Lz77.compressedLength(model, 0x100))
        assertEquals(sprite.toList(), Lz77.decompress(model, 0x100)?.toList())
    }

    @Test
    fun `rejects data that doesn't start with the LZ77 magic byte`() {
        val model = modelOf(0x11, 0x04, 0x00, 0x00, 0x00, 1, 2, 3, 4)
        assertNull(Lz77.decompress(model, 0))
        assertNull(Lz77.compressedLength(model, 0))
    }

    @Test
    fun `rejects a stream that runs off the end of the model`() {
        val model = modelOf(0x10, 0xFF, 0x00, 0x00) // claims 255 bytes decompressed, then nothing follows
        assertNull(Lz77.decompress(model, 0))
        assertNull(Lz77.compressedLength(model, 0))
    }

    @Test
    fun `a declared length shorter than the real content is rejected unless allowLengthErrors is set`() {
        // Same bytes as the back-reference test above, but the header now claims only 4 bytes
        // decompressed even though the token stream actually produces 6 ("ABABAB") - the
        // trailing compressed-token bit is still 1 in the bitfield when index reaches the
        // (wrong) declared length, which is exactly the mismatch allowLengthErrors exists for.
        val bitField = 0b00100000
        val model = modelOf(0x10, 0x04, 0x00, 0x00, bitField, 0x41, 0x42, 0x10, 0x01)
        assertNull(Lz77.decompress(model, 0, allowLengthErrors = false))
        assertNull(Lz77.compressedLength(model, 0, allowLengthErrors = false))

        // The declared length (4) is still what gets allocated, so the result is truncated to
        // 4 bytes ("ABAB"), not the full 6 the token stream implies - allowLengthErrors relaxes
        // the "did it end cleanly" check, it doesn't change how much space was reserved.
        val lenient = Lz77.decompress(model, 0, allowLengthErrors = true)
        assertEquals("ABAB", lenient?.map { it.toChar() }?.joinToString(""))
    }

    private fun modelOfBytes(bytes: IntArray): RomDataModel = RomDataModel(ByteArray(bytes.size) { bytes[it].toByte() })
}
