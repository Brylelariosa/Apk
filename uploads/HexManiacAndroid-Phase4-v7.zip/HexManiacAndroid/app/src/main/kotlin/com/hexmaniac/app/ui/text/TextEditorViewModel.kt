package com.hexmaniac.app.ui.text

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.app.data.RomSessionRepository
import com.hexmaniac.core.model.PcsEncodingException
import com.hexmaniac.core.model.PcsString
import com.hexmaniac.core.model.StringRun
import com.hexmaniac.core.model.readText
import com.hexmaniac.core.model.writeText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

data class TextEditorUiState(
    val romLoaded: Boolean = false,
    val addressText: String = "",
    val stringRun: StringRun? = null,
    val text: String = "",
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Enter a start address, then Open.",
    // Same forced-recompose trick HexViewerViewModel/HexViewerScreen use - see that screen's
    // HexRow comment for why plain field reads need this instead of Compose State.
    val revision: Int = 0,
)

/**
 * Manual string definition (address typed in, same reasoning as [TableEditorViewModel][
 * com.hexmaniac.app.ui.table.TableEditorViewModel] - no auto-detected string table here either)
 * plus free-text editing, on the same [RomSessionRepository] session every screen shares.
 *
 * Unlike a table cell, a string here isn't fixed-width: saving text longer than what's currently
 * there can relocate it and repoint whatever pointed at the old address. [StringRun.writeText]
 * does the actual work; this class is mostly the same open/edit/status-message shape
 * [TableEditorViewModel][com.hexmaniac.app.ui.table.TableEditorViewModel] already established.
 */
@HiltViewModel
class TextEditorViewModel @Inject constructor(
    private val romSession: RomSessionRepository,
) : ViewModel() {

    var uiState by mutableStateOf(TextEditorUiState(romLoaded = romSession.session.romLoaded))
        private set

    /**
     * Call when this screen becomes visible: refreshes ROM-loaded/undo state in case another
     * screen changed it, and optionally prefills the address field (e.g. from a hex-grid
     * selection handed off via the "Text" button).
     */
    fun syncFromSession(prefillAddress: Int? = null) {
        uiState = uiState.copy(
            romLoaded = romSession.session.romLoaded,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
            addressText = prefillAddress?.let { it.toString(16).uppercase() } ?: uiState.addressText,
        )
    }

    fun updateAddressText(text: String) {
        uiState = uiState.copy(addressText = text)
    }

    fun updateEditText(text: String) {
        uiState = uiState.copy(text = text)
    }

    /** Drops the open string and returns to the address form, without touching ROM content. */
    fun clearString() {
        uiState = uiState.copy(
            stringRun = null,
            text = "",
            statusMessage = "Enter a start address, then Open.",
        )
    }

    fun openString() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }

        val address = romSession.resolveAddress(uiState.addressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.addressText}' isn't a valid address or known name in this ROM.")
            return
        }

        // If this address is already a string (opened earlier this session), reuse it - same
        // "remember for the rest of the session" reasoning TableEditorViewModel.defineTable
        // follows for tables. Otherwise decode fresh and register it as a new run.
        val existing = romSession.runAt(address)
        val run = if (existing is StringRun) {
            existing
        } else {
            val decoded = PcsString.decode(model, address)
            StringRun(start = address, length = decoded.byteLength).also { romSession.addRun(it) }
        }

        val anchor = romSession.anchorAt(address)
        uiState = uiState.copy(
            stringRun = run,
            text = run.readText(model),
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "${anchor?.let { "$it - " } ?: ""}${run.length} bytes.",
            revision = uiState.revision + 1,
        )
    }

    fun writeString() {
        val run = uiState.stringRun ?: return
        if (romSession.currentModel == null) return

        var result: StringRun? = null
        val message = try {
            romSession.applyEdit { model, token ->
                val updated = run.writeText(model, uiState.text, token)
                if (updated.start != run.start) model.removeRun(run.start)
                model.addRun(updated)
                result = updated
            }
            val updated = requireNotNull(result) // applyEdit ran the lambda synchronously above
            if (updated.start != run.start) {
                val count = updated.pointerSources.size
                "Saved - moved to 0x${updated.start.toString(16).uppercase()} " +
                    "($count reference${if (count == 1) "" else "s"} repointed)."
            } else {
                "Saved."
            }
        } catch (e: PcsEncodingException) {
            e.message ?: "Invalid text."
        }

        uiState = uiState.copy(
            stringRun = result ?: uiState.stringRun, // keep the old run's address on failure
            statusMessage = message,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    fun undo() {
        romSession.undo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Undid last edit.",
            revision = uiState.revision + 1,
        )
    }

    fun redo() {
        romSession.redo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Redid edit.",
            revision = uiState.revision + 1,
        )
    }
}
