package com.hexmaniac.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * App bar shared by every top-level screen: a full-width title row, then a second row of
 * actions that scrolls horizontally instead of wrapping or clipping.
 *
 * Deliberately not built on Material3's [androidx.compose.material3.TopAppBar]. That composable
 * measures its `actions` slot first, at up to the bar's *entire* width, and only gives `title`
 * whatever is left over (`TopAppBarLayout` in Material3's `AppBar.kt`). That's harmless for a
 * couple of icon buttons, but this app's actions are full-width text buttons in a
 * `horizontalScroll` row - on a narrow phone their natural width can claim the whole bar, leaving
 * the title only a handful of pixels. Since a single word has no space to break on, Compose wraps
 * it mid-word instead - one or two characters per line ("HexManiac" as "He" / "xM" / "ani" /
 * "ac", as seen on the hex viewer). Giving the title its own full-width row first, and the
 * scrollable actions a row below it, means the title can't be starved no matter how many actions
 * a future screen adds. It also drops the `TopAppBar` / `ExperimentalMaterial3Api` opt-in this
 * BOM requires (see the README's v2 notes), since nothing here needs it.
 *
 * @param navigationIcon typically a "Back" [androidx.compose.material3.TextButton]; the default
 *   (nothing) suits top-level screens with nowhere to go back to.
 * @param actions one or more [androidx.compose.material3.TextButton]s. The row they're placed in
 *   already scrolls horizontally - callers shouldn't wrap them in another `horizontalScroll` Row.
 */
@Composable
fun HexManiacTopBar(
    title: String,
    modifier: Modifier = Modifier,
    navigationIcon: @Composable () -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
) {
    Surface(modifier = modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                navigationIcon()
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 16.dp),
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                content = actions,
            )
        }
    }
}
