package com.hexmaniac.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Shared "nothing to do yet" body for any screen that needs a ROM loaded before it's useful -
 * the hex viewer is the only place that can actually open one, so every other screen just points
 * back to it. Was Table Editor's own private composable; Text Editor needs the exact same body,
 * so it moved here rather than being copied - same reasoning as [HexManiacTopBar].
 */
@Composable
fun EmptyRomState(message: String, onOpenRomRequested: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("No ROM loaded", style = MaterialTheme.typography.titleMedium)
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
        )
        TextButton(onClick = onOpenRomRequested) { Text("Open ROM") }
    }
}
