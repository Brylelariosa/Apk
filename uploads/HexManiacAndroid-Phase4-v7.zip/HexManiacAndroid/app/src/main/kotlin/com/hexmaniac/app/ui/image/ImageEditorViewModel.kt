package com.hexmaniac.app.ui.image

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.app.data.RomSessionRepository
import com.hexmaniac.core.model.GbaColor
import com.hexmaniac.core.model.ImageFormat
import com.hexmaniac.core.model.ImageFormatException
import com.hexmaniac.core.model.PaletteRun
import com.hexmaniac.core.model.RomDataModel
import com.hexmaniac.core.model.SpriteRun
import com.hexmaniac.core.model.TilemapEntry
import com.hexmaniac.core.model.TilemapRun
import com.hexmaniac.core.model.getColors
import com.hexmaniac.core.model.getPixels
import com.hexmaniac.core.model.pageCount
import com.hexmaniac.core.model.readEntry
import com.hexmaniac.core.model.setColors
import com.hexmaniac.core.model.setPixels
import com.hexmaniac.core.model.writeEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/** Which of the three sub-editors [ImageEditorScreen] is currently showing. Lives in
 *  [ImageEditorUiState] alongside everything else on this screen, rather than a Screen-local
 *  `remember`, so all three sub-editors' state - including which one is visible - survives a
 *  configuration change together and through the same single source of truth. All three keep
 *  their own data alive at once regardless of which is visible: switching away from Sprite to
 *  pair a palette, then switching back, doesn't lose the open sprite. This is a Screen-level
 *  concern, not a new top-level destination - see [com.hexmaniac.app.ui.HexManiacScreen]'s doc
 *  comment for the different question of when a *screen* switch belongs in that sealed
 *  interface instead. */
enum class ImageEditorMode { SPRITE, PALETTE, TILEMAP }

data class ImageEditorUiState(
    val romLoaded: Boolean = false,
    val mode: ImageEditorMode = ImageEditorMode.SPRITE,

    val spriteAddressText: String = "",
    val spriteFormatText: String = "",
    val sprite: SpriteRun? = null,
    val spritePage: Int = 0,
    val spritePageCount: Int = 1,
    val selectedPixelX: Int? = null,
    val selectedPixelY: Int? = null,

    val paletteAddressText: String = "",
    val paletteFormatText: String = "",
    val palette: PaletteRun? = null,
    val palettePage: Int = 0,
    val selectedSwatch: Int? = null,

    val tilemapAddressText: String = "",
    val tilemapFormatText: String = "",
    val tilemap: TilemapRun? = null,
    val selectedTileX: Int? = null,
    val selectedTileY: Int? = null,

    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Enter a start address and format, then Open.",
    // Same forced-recompose trick HexViewerViewModel/HexViewerScreen use - see that screen's
    // HexRow comment for why plain field reads need this instead of Compose State.
    val revision: Int = 0,
)

/**
 * Sprite/tileset, palette, and tilemap editing - manual address + format-string definition, same
 * reasoning [TableEditorViewModel][com.hexmaniac.app.ui.table.TableEditorViewModel] and
 * [TextEditorViewModel][com.hexmaniac.app.ui.text.TextEditorViewModel] give for why there's no
 * auto-detection here either - on the same [RomSessionRepository] session every screen shares.
 *
 * The three sub-editors are independent data (a sprite doesn't need a palette or a tilemap to be
 * open), but sprites and tilemaps *render* using whichever palette is currently open, the same
 * pairing the original's `SpriteTool` keeps its sprite/palette address fields side by side for -
 * see [renderedSpritePixels]/[renderedTilemapPixels]. A [SpriteRun] doubles as a tilemap's
 * tileset too (see [SpriteFormat][com.hexmaniac.core.model.SpriteFormat]'s doc comment), so
 * there's no fourth "tileset" concept here to keep in sync.
 *
 * Every write (a pixel, a swatch, a tile entry) goes through [RomSessionRepository.applyEdit]
 * and re-registers the run exactly the way
 * [TextEditorViewModel.writeString][com.hexmaniac.app.ui.text.TextEditorViewModel] does for a
 * relocating [StringRun][com.hexmaniac.core.model.StringRun] - see that function's comment for
 * why the re-registration happens inside the same `applyEdit` call instead of after it, and the
 * README's "known rough edges" for the undo-consistency caveat that comes with it.
 */
@HiltViewModel
class ImageEditorViewModel @Inject constructor(
    private val romSession: RomSessionRepository,
) : ViewModel() {

    var uiState by mutableStateOf(ImageEditorUiState(romLoaded = romSession.session.romLoaded))
        private set

    /**
     * Call when this screen becomes visible: refreshes ROM-loaded/undo state in case another
     * screen changed it, and optionally prefills the sprite address field (e.g. from a hex-grid
     * selection handed off via the "Images" button).
     */
    fun syncFromSession(prefillAddress: Int? = null) {
        uiState = uiState.copy(
            romLoaded = romSession.session.romLoaded,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
            spriteAddressText = prefillAddress?.let { it.toString(16).uppercase() } ?: uiState.spriteAddressText,
        )
    }

    fun setMode(mode: ImageEditorMode) {
        uiState = uiState.copy(mode = mode)
    }

    fun updateSpriteAddressText(text: String) { uiState = uiState.copy(spriteAddressText = text) }
    fun updateSpriteFormatText(text: String) { uiState = uiState.copy(spriteFormatText = text) }
    fun updatePaletteAddressText(text: String) { uiState = uiState.copy(paletteAddressText = text) }
    fun updatePaletteFormatText(text: String) { uiState = uiState.copy(paletteFormatText = text) }
    fun updateTilemapAddressText(text: String) { uiState = uiState.copy(tilemapAddressText = text) }
    fun updateTilemapFormatText(text: String) { uiState = uiState.copy(tilemapFormatText = text) }

    /** Anchor name at [address], for enriching a status message the same way
     *  TableEditorViewModel.openTable/TextEditorViewModel.openString do. */
    private fun anchorSuffix(address: Int): String = romSession.anchorAt(address)?.let { "$it - " } ?: ""

    // --- sprite / tileset ---

    /** Drops the open sprite and returns to the definition form, without touching ROM content. */
    fun clearSprite() {
        uiState = uiState.copy(
            sprite = null,
            spritePage = 0,
            spritePageCount = 1,
            selectedPixelX = null,
            selectedPixelY = null,
            statusMessage = "Enter a start address and format, then Open.",
        )
    }

    fun openSprite() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }
        val address = romSession.resolveAddress(uiState.spriteAddressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.spriteAddressText}' isn't a valid address or known name in this ROM.")
            return
        }

        // If this address is already a sprite (opened earlier this session, or defined as a
        // tileset for a tilemap), just reopen it - same reasoning
        // TableEditorViewModel.defineTable follows for tables.
        val existing = romSession.runAt(address)
        val run = if (existing is SpriteRun) {
            existing
        } else {
            val format = try {
                ImageFormat.parseSprite(uiState.spriteFormatText)
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
                return
            }
            try {
                SpriteRun.create(model, address, format).also { romSession.addRun(it) }
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid sprite data.")
                return
            }
        }

        val pages = run.pageCount(model)
        uiState = uiState.copy(
            sprite = run,
            spritePage = 0,
            spritePageCount = pages,
            selectedPixelX = null,
            selectedPixelY = null,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "${anchorSuffix(address)}${run.format.pixelWidth}x${run.format.pixelHeight}px, ${run.length} bytes" +
                (if (pages > 1) ", $pages pages" else "") + ".",
            revision = uiState.revision + 1,
        )
    }

    fun setSpritePage(page: Int) {
        if (uiState.sprite == null) return
        uiState = uiState.copy(
            spritePage = page.coerceIn(0, uiState.spritePageCount - 1),
            selectedPixelX = null,
            selectedPixelY = null,
        )
    }

    fun selectPixel(x: Int, y: Int) {
        uiState = uiState.copy(selectedPixelX = x, selectedPixelY = y)
    }

    /** The raw palette index at the currently-selected pixel, for prefilling the edit field -
     *  same role [HexViewerViewModel.byteAt] plays for [com.hexmaniac.app.ui.HexViewerScreen]'s
     *  edit bar. */
    fun selectedPixelIndex(): Int? {
        val run = uiState.sprite ?: return null
        val model = romSession.currentModel ?: return null
        val x = uiState.selectedPixelX ?: return null
        val y = uiState.selectedPixelY ?: return null
        return run.getPixels(model, uiState.spritePage)[y * run.format.pixelWidth + x]
    }

    /**
     * Row-major ARGB pixels for the currently-open sprite, using the paired palette if one is
     * open or a grayscale ramp otherwise - matching `SpriteTool`'s own default-palette fallback
     * in the original (see [defaultGrayscaleArgb]). Recomputed on every call, not cached: a
     * ROM-hacking-sized sprite is at most a few thousand pixels, cheap enough to decode fresh
     * each time rather than add cache-invalidation surface for something this small.
     */
    fun renderedSpritePixels(): IntArray? {
        val run = uiState.sprite ?: return null
        val model = romSession.currentModel ?: return null
        val indices = run.getPixels(model, uiState.spritePage)
        val colors = paletteArgbColors(model) ?: defaultGrayscaleArgb(1 shl run.format.bitsPerPixel)
        return IntArray(indices.size) { i -> colors.getOrElse(indices[i]) { BLACK_ARGB } }
    }

    fun writeSelectedPixel(hexIndexText: String) {
        val run = uiState.sprite ?: return
        val model = romSession.currentModel ?: return
        val x = uiState.selectedPixelX ?: return
        val y = uiState.selectedPixelY ?: return

        val maxIndex = (1 shl run.format.bitsPerPixel) - 1
        val value = hexIndexText.trim().removePrefix("0x").toIntOrNull(16)
        if (value == null || value !in 0..maxIndex) {
            uiState = uiState.copy(statusMessage = "Palette index must be 0-${maxIndex.toString(16).uppercase()} for a ${run.format.bitsPerPixel}bpp image.")
            return
        }

        var result: SpriteRun? = null
        romSession.applyEdit { m, token ->
            val pixels = run.getPixels(m, uiState.spritePage)
            pixels[y * run.format.pixelWidth + x] = value
            val updated = run.setPixels(m, pixels, token, uiState.spritePage)
            if (updated.start != run.start) m.removeRun(run.start)
            m.addRun(updated)
            result = updated
        }

        val updated = result ?: return
        uiState = uiState.copy(
            sprite = updated,
            statusMessage = movedOrSavedMessage(run.start, updated.start, updated.pointerSources.size, "sprite"),
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    // --- palette ---

    fun clearPalette() {
        uiState = uiState.copy(
            palette = null,
            palettePage = 0,
            selectedSwatch = null,
            statusMessage = "Enter a start address and format, then Open.",
        )
    }

    fun openPalette() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }
        val address = romSession.resolveAddress(uiState.paletteAddressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.paletteAddressText}' isn't a valid address or known name in this ROM.")
            return
        }

        val existing = romSession.runAt(address)
        val run = if (existing is PaletteRun) {
            existing
        } else {
            val format = try {
                ImageFormat.parsePalette(uiState.paletteFormatText)
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
                return
            }
            try {
                PaletteRun.create(model, address, format).also { romSession.addRun(it) }
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid palette data.")
                return
            }
        }

        uiState = uiState.copy(
            palette = run,
            palettePage = 0,
            selectedSwatch = null,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "${anchorSuffix(address)}${run.format.colorCount} colors x ${run.format.pages} page${if (run.format.pages == 1) "" else "s"}, ${run.length} bytes.",
            revision = uiState.revision + 1,
        )
    }

    fun setPalettePage(page: Int) {
        val run = uiState.palette ?: return
        uiState = uiState.copy(palettePage = page.coerceIn(0, run.format.pages - 1), selectedSwatch = null)
    }

    fun selectSwatch(index: Int) {
        uiState = uiState.copy(selectedSwatch = index)
    }

    /** The ARGB color of the currently-selected swatch, for prefilling the edit field as
     *  RRGGBB hex. */
    fun selectedSwatchArgb(): Int? {
        val model = romSession.currentModel ?: return null
        val index = uiState.selectedSwatch ?: return null
        return paletteArgbColors(model)?.getOrNull(index)
    }

    /** ARGB colors for the currently-open palette's current page, or null if no palette is open -
     *  shared by the palette editor's own swatches and by [renderedSpritePixels]/
     *  [renderedTilemapPixels] to color a paired sprite or tilemap. */
    fun paletteSwatchArgbColors(): IntArray? = romSession.currentModel?.let { paletteArgbColors(it) }

    private fun paletteArgbColors(model: RomDataModel): IntArray? {
        val palette = uiState.palette ?: return null
        val raw = palette.getColors(model, uiState.palettePage)
        return IntArray(raw.size) { GbaColor.toArgb8888(raw[it]) }
    }

    /** Matches `SpriteTool.CreateDefaultPalette` in the original: an even grayscale ramp, shown
     *  when no palette has been paired yet so a sprite or tilemap is still visible. */
    private fun defaultGrayscaleArgb(count: Int): IntArray = IntArray(count) { i ->
        val shade = if (count <= 1) 0 else 31 * i / (count - 1)
        GbaColor.toArgb8888((shade shl 10) or (shade shl 5) or shade)
    }

    fun writeSelectedSwatch(hexColorText: String) {
        val run = uiState.palette ?: return
        val model = romSession.currentModel ?: return
        val index = uiState.selectedSwatch ?: return

        val hex = hexColorText.trim().removePrefix("#").removePrefix("0x")
        val rgb24 = hex.toIntOrNull(16)
        if (rgb24 == null || hex.isEmpty() || hex.length > 6) {
            uiState = uiState.copy(statusMessage = "'$hexColorText' isn't a valid RRGGBB hex color.")
            return
        }
        val argb = (0xFF shl 24) or rgb24

        var result: PaletteRun? = null
        romSession.applyEdit { m, token ->
            val colors = run.getColors(m, uiState.palettePage)
            colors[index] = GbaColor.fromArgb8888(argb)
            val updated = run.setColors(m, colors, token, uiState.palettePage)
            if (updated.start != run.start) m.removeRun(run.start)
            m.addRun(updated)
            result = updated
        }

        val updated = result ?: return
        uiState = uiState.copy(
            palette = updated,
            statusMessage = movedOrSavedMessage(run.start, updated.start, updated.pointerSources.size, "palette"),
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    // --- tilemap ---

    fun clearTilemap() {
        uiState = uiState.copy(
            tilemap = null,
            selectedTileX = null,
            selectedTileY = null,
            statusMessage = "Enter a start address and format, then Open.",
        )
    }

    fun openTilemap() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }
        val address = romSession.resolveAddress(uiState.tilemapAddressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.tilemapAddressText}' isn't a valid address or known name in this ROM.")
            return
        }

        val existing = romSession.runAt(address)
        val run = if (existing is TilemapRun) {
            existing
        } else {
            val format = try {
                ImageFormat.parseTilemap(uiState.tilemapFormatText, resolveAddress = romSession::resolveAddress)
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
                return
            }
            try {
                TilemapRun.create(model, address, format).also { romSession.addRun(it) }
            } catch (e: ImageFormatException) {
                uiState = uiState.copy(statusMessage = e.message ?: "Invalid tilemap data.")
                return
            }
        }

        val tilesetFound = model.getRunAt(run.format.matchingTilesetAddress) is SpriteRun
        val tilesetAnchor = romSession.anchorAt(run.format.matchingTilesetAddress)
        val tilesetLabel = tilesetAnchor ?: "0x${run.format.matchingTilesetAddress.toString(16).uppercase()}"
        val tilesetNote = if (tilesetFound) "" else " No sprite is defined at $tilesetLabel yet, so it's shown blank."
        uiState = uiState.copy(
            tilemap = run,
            selectedTileX = null,
            selectedTileY = null,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "${anchorSuffix(address)}${run.format.tileWidth}x${run.format.tileHeight} tiles, ${run.length} bytes.$tilesetNote",
            revision = uiState.revision + 1,
        )
    }

    fun selectTile(x: Int, y: Int) {
        uiState = uiState.copy(selectedTileX = x, selectedTileY = y)
    }

    /** The [TilemapEntry] at the currently-selected cell, for prefilling the edit field. */
    fun selectedTileEntry(): TilemapEntry? {
        val run = uiState.tilemap ?: return null
        val model = romSession.currentModel ?: return null
        val x = uiState.selectedTileX ?: return null
        val y = uiState.selectedTileY ?: return null
        return run.readEntry(model, x, y)
    }

    /** Composed ARGB pixels for the currently-open tilemap - see [TilemapRun.getPixels]'s doc
     *  comment for how tile, flip, and palette-page selection combine. A composed index can run
     *  all the way up to 255 regardless of the tileset's own bit depth (a 4bpp tile's palette
     *  nibble alone can push it past 15), so the grayscale fallback always covers the full
     *  range rather than just `2^bitsPerPixel` entries. */
    fun renderedTilemapPixels(): IntArray? {
        val run = uiState.tilemap ?: return null
        val model = romSession.currentModel ?: return null
        val indices = run.getPixels(model)
        val colors = paletteArgbColors(model) ?: defaultGrayscaleArgb(256)
        return IntArray(indices.size) { i -> colors.getOrElse(indices[i]) { BLACK_ARGB } }
    }

    fun writeSelectedTile(hexEntryText: String) {
        val run = uiState.tilemap ?: return
        val model = romSession.currentModel ?: return
        val x = uiState.selectedTileX ?: return
        val y = uiState.selectedTileY ?: return

        val raw = hexEntryText.trim().removePrefix("0x").toIntOrNull(16)
        if (raw == null || raw !in 0..0xFFFF) {
            uiState = uiState.copy(statusMessage = "'$hexEntryText' isn't a valid 16-bit hex tilemap entry.")
            return
        }
        val entry = TilemapEntry.unpack(raw)

        var result: TilemapRun? = null
        romSession.applyEdit { m, token ->
            val updated = run.writeEntry(m, x, y, entry, token)
            if (updated.start != run.start) m.removeRun(run.start)
            m.addRun(updated)
            result = updated
        }

        val updated = result ?: return
        uiState = uiState.copy(
            tilemap = updated,
            statusMessage = movedOrSavedMessage(run.start, updated.start, updated.pointerSources.size, "tilemap", extra = " ($entry)"),
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    // --- shared ---

    private fun movedOrSavedMessage(oldStart: Int, newStart: Int, referenceCount: Int, kind: String, extra: String = ""): String =
        if (newStart != oldStart) {
            "Saved - $kind moved to 0x${newStart.toString(16).uppercase()} " +
                "($referenceCount reference${if (referenceCount == 1) "" else "s"} repointed).$extra"
        } else {
            "Saved.$extra"
        }

    fun undo() {
        romSession.undo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Undid last edit.",
            revision = uiState.revision + 1,
        )
    }

    fun redo() {
        romSession.redo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Redid edit.",
            revision = uiState.revision + 1,
        )
    }

    private companion object {
        const val BLACK_ARGB = 0xFF000000.toInt()
    }
}
