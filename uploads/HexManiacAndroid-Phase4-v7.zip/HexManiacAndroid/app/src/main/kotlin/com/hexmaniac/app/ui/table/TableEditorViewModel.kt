package com.hexmaniac.app.ui.table

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.app.data.RomSessionRepository
import com.hexmaniac.core.model.NumericField
import com.hexmaniac.core.model.PcsEncodingException
import com.hexmaniac.core.model.PointerField
import com.hexmaniac.core.model.TableFormat
import com.hexmaniac.core.model.TableFormatException
import com.hexmaniac.core.model.TableRun
import com.hexmaniac.core.model.TextField
import com.hexmaniac.core.model.readNumeric
import com.hexmaniac.core.model.readPointerField
import com.hexmaniac.core.model.readText
import com.hexmaniac.core.model.writeNumeric
import com.hexmaniac.core.model.writePointerField
import com.hexmaniac.core.model.writeText
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

data class TableEditorUiState(
    val romLoaded: Boolean = false,
    val addressText: String = "",
    val formatText: String = "",
    val table: TableRun? = null,
    val selectedRow: Int? = null,
    val selectedField: Int? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Enter a start address and format, then Define.",
    // Same forced-recompose trick HexViewerViewModel/HexViewerScreen use - see that screen's
    // HexRow comment for why plain field reads need this instead of Compose State.
    val revision: Int = 0,
)

/**
 * Manual table definition plus grid cell editing, on the same [RomSessionRepository] session the
 * hex viewer uses - an edit made here is immediately visible, undoable, and save-able from
 * either screen, because both go through the same repository instead of keeping separate copies.
 *
 * Table *detection* is deliberately manual (address + format string typed in), not automatic:
 * HMA's own auto-detection leans on a per-game hardcoded table/anchor database that's out of
 * scope here - see [TableFormat]'s doc comment for what the format parser itself defers.
 */
@HiltViewModel
class TableEditorViewModel @Inject constructor(
    private val romSession: RomSessionRepository,
) : ViewModel() {

    var uiState by mutableStateOf(TableEditorUiState(romLoaded = romSession.session.romLoaded))
        private set

    /**
     * Call when this screen becomes visible: refreshes ROM-loaded/undo state in case the hex
     * viewer changed it, and optionally prefills the address field (e.g. from a hex-grid
     * selection handed off via the "Tables" button).
     */
    fun syncFromSession(prefillAddress: Int? = null) {
        uiState = uiState.copy(
            romLoaded = romSession.session.romLoaded,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
            addressText = prefillAddress?.let { it.toString(16).uppercase() } ?: uiState.addressText,
        )
    }

    fun updateAddressText(text: String) {
        uiState = uiState.copy(addressText = text)
    }

    fun updateFormatText(text: String) {
        uiState = uiState.copy(formatText = text)
    }

    /** Drops the open table and returns to the definition form, without touching ROM content. */
    fun clearTable() {
        uiState = uiState.copy(
            table = null,
            selectedRow = null,
            selectedField = null,
            statusMessage = "Enter a start address and format, then Define.",
        )
    }

    fun defineTable() {
        val model = romSession.currentModel
        if (model == null) {
            uiState = uiState.copy(statusMessage = "Open a ROM first.")
            return
        }

        val address = romSession.resolveAddress(uiState.addressText)
        if (address == null) {
            uiState = uiState.copy(statusMessage = "'${uiState.addressText}' isn't a valid address or known name in this ROM.")
            return
        }

        // If this address is already a table (defined earlier this session), just reopen it -
        // no need to require the format text again.
        val existing = romSession.runAt(address)
        if (existing is TableRun) {
            openTable(existing)
            return
        }

        val parsed = try {
            TableFormat.parse(uiState.formatText)
        } catch (e: TableFormatException) {
            uiState = uiState.copy(statusMessage = e.message ?: "Invalid format.")
            return
        }

        // Long arithmetic here on purpose: a mistyped huge count would otherwise overflow Int
        // and could pass this check when it shouldn't.
        val elementLength = parsed.segments.sumOf { it.length }
        if (address + elementLength.toLong() * parsed.elementCount > model.size) {
            uiState = uiState.copy(statusMessage = "That table would run past the end of the ROM - check the count.")
            return
        }

        val table = TableRun(start = address, segments = parsed.segments, elementCount = parsed.elementCount)
        romSession.addRun(table)
        openTable(table)
    }

    private fun openTable(table: TableRun) {
        val anchor = romSession.anchorAt(table.start)
        uiState = uiState.copy(
            table = table,
            selectedRow = null,
            selectedField = null,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "${anchor?.let { "$it - " } ?: ""}${table.elementCount} rows x ${table.segments.size} fields.",
            revision = uiState.revision + 1,
        )
    }

    fun selectCell(row: Int, field: Int) {
        uiState = uiState.copy(selectedRow = row, selectedField = field)
    }

    /** Current display text for one cell - read fresh from the model every call, not cached. */
    fun cellText(row: Int, fieldIndex: Int): String {
        val model = romSession.currentModel ?: return ""
        val table = uiState.table ?: return ""
        return when (table.segments[fieldIndex]) {
            is NumericField -> table.readNumeric(model, row, fieldIndex).toString()
            is PointerField -> table.readPointerField(model, row, fieldIndex).let {
                if (it < 0) "<none>" else it.toString(16).uppercase()
            }
            is TextField -> table.readText(model, row, fieldIndex)
        }
    }

    fun writeSelectedCell(text: String) {
        if (romSession.currentModel == null) return
        val table = uiState.table ?: return
        val row = uiState.selectedRow ?: return
        val fieldIndex = uiState.selectedField ?: return
        val segment = table.segments[fieldIndex]
        val hex = text.trim().removePrefix("0x")

        val message = when (segment) {
            is NumericField -> {
                val value = hex.toIntOrNull(16)
                if (value == null) {
                    "'$text' isn't valid hex."
                } else {
                    romSession.applyEdit { m, token -> table.writeNumeric(m, row, fieldIndex, value, token) }
                    "Row $row, ${segment.name} = $value"
                }
            }
            is PointerField -> {
                val address = hex.toIntOrNull(16)
                if (address == null) {
                    "'$text' isn't valid hex."
                } else {
                    romSession.applyEdit { m, token -> table.writePointerField(m, row, fieldIndex, address, token) }
                    "Row $row, ${segment.name} -> ${address.toString(16).uppercase()}"
                }
            }
            is TextField -> try {
                romSession.applyEdit { m, token -> table.writeText(m, row, fieldIndex, text, token) }
                "Row $row, ${segment.name} = \"$text\""
            } catch (e: PcsEncodingException) {
                e.message ?: "Invalid text."
            }
        }

        uiState = uiState.copy(
            statusMessage = message,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = uiState.revision + 1,
        )
    }

    fun undo() {
        romSession.undo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Undid last edit.",
            revision = uiState.revision + 1,
        )
    }

    fun redo() {
        romSession.redo()
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            statusMessage = "Redid edit.",
            revision = uiState.revision + 1,
        )
    }
}
