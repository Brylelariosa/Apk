#pragma once
// ============================================================================
// HZCM v13 — DebugOverlay.h
//
// Responsibilities:
//   • WorldDebugStats struct — plain POD snapshot filled by World::getDebugStats()
//   • DebugOverlay class     — visibility toggle + thread-safe stats cache
//
// Rendering split:
//   • GL bar overlay (thermal/RD coloured bars) lives in Renderer::renderDebugOverlay()
//   • Text overlay (the full stats panel) is rendered on the Android/Java layer.
//     Java polls nativeGetDebugStats() every 250 ms via a Handler and displays
//     the result in a monospace TextView overlay above the GL surface.
//
// Design notes:
//   • WorldDebugStats has NO includes from the rest of the engine — zero
//     circular-dependency risk even though World.h includes this header.
//   • The stats cache uses a std::mutex rather than per-field atomics:
//     simple, correct, and the 250 ms Java poll interval means lock contention
//     is negligible.
//   • renderDebugUI() is a stub — actual rendering is delegated to Renderer.
// ============================================================================
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>

// ── Stats snapshot ────────────────────────────────────────────────────────────
// All values are approximate/best-effort; no locking guarantees are made
// across fields (the struct is filled in a single GL-thread call and read
// on the JNI/Java thread with coarse mutex protection in DebugOverlay).
struct WorldDebugStats {
    // Rendering
    float    fps              = 60.f;
    int      requestedRD      = 0;
    int      effectiveRadius  = 0;
    int      visibleDraws     = 0;

    // Streaming
    int      loadedChunks     = 0;
    int      pendingChunks    = 0;   // unsubmitted candidates remaining
    int      submittedChunks  = 0;
    int      uploadBacklog    = 0;
    int      workerCount      = 0;

    // Chunk completeness diagnostics (v14)
    int      totalInRadius         = 0;  // total positions in load radius
    int      missingChunks         = 0;  // positions absent from m_chunks
    int      candidateRebuildCount = 0;  // how many times candidate list rebuilt
    int      strandedChunks        = 0;  // chunks re-queued by stranded-recovery
    int      candidateIdx          = 0;  // current position in candidate list

    // Thermal
    char     thermalState[12] = "COOL";   // "COOL" | "WARM" | "HOT" | "CRITICAL"
    float    thermalScale     = 1.f;      // radiusScale() value (informational only)
    float    thermalPressure  = 0.f;      // [0..1]
    float    thermalEmaMs     = 16.7f;    // EMA frame time in ms

    // Job queue
    uint32_t queueSize        = 0;
    uint32_t queueFree        = 0;
    uint32_t queueCapacity    = 0;
    int      retryQueueSize   = 0;
    int      overflowTotal    = 0;

    // Memory (MegaBuffer)
    uint32_t megaUsedFaces    = 0;
    uint32_t megaTotalFaces   = 0;

    // Fix #6: GPU memory health
    int      gpuAllocFails    = 0;   // total PageAllocator allocation failures
    int      gpuEvictedMeshes = 0;   // total mesh evictions by eviction pass
    int      gpuRetryQueueSz  = 0;   // upload tasks waiting for retry (alloc fail)
    float    gpuUsagePct      = 0.f; // usedFaces / totalFaces × 100

    // Cluster lifecycle breakdown (v19)
    // Diagnosing invisible chunks requires knowing where clusters are stuck.
    //   DIRTY  > 0 while READY == 0  → rebuild workers not running / stuck
    //   MESHED > 0                   → CPU mesh built, GPU upload pending
    //   READY  unexpectedly low      → upload succeeded but draw culled
    int      clustersReady    = 0;
    int      clustersMeshed   = 0;
    int      clustersDirty    = 0;
    int      clustersEmpty    = 0;
    int      watchdogRescues  = 0;   // cumulative DIRTY clusters re-queued by watchdog

    // ── Task 1: new pipeline-stage counters ───────────────────────────────────
    // generatedChunks : chunks that completed Chunk::generate() (terrain voxels ready)
    // meshFacesTotal  : sum of all PackedFace entries across every MESHED cluster (debug)
    // visibleVertices : visibleDraws cluster faces × 6 vertices this frame
    // drawCalls       : identical to visibleDraws — kept for naming clarity
    int      generatedChunks  = 0;
    int      meshFacesTotal   = 0;   // incremented in updateGPU when faces>0 uploaded
    int      visibleVertices  = 0;   // m_lastVisibleFaces * 6
    int      drawCalls        = 0;   // == visibleDraws
    float    camY             = 0.f;  // world Y — confirm player on terrain
    float    camPitch         = 0.f;  // pitch degrees — confirm not looking at sky

    // Position
    int      camCX            = 0;
    int      camCZ            = 0;
};

// ── DebugOverlay ──────────────────────────────────────────────────────────────
class DebugOverlay {
public:
    DebugOverlay() = default;

    // ── Visibility state (GL-thread only; no atomic needed) ───────────────────
    bool debugVisible         = false;
    bool advancedDebugVisible = false;

    // toggleDebug() — tap on DBG button.
    // Hides advanced panel automatically when the main panel closes.
    void toggleDebug() {
        debugVisible = !debugVisible;
        if (!debugVisible) advancedDebugVisible = false;
    }

    // toggleAdvanced() — long-press on DBG button (or separate action).
    // Auto-opens the basic panel if it was closed.
    void toggleAdvanced() {
        if (!debugVisible) debugVisible = true;
        advancedDebugVisible = !advancedDebugVisible;
    }

    bool isVisible()  const { return debugVisible;         }
    bool isAdvanced() const { return advancedDebugVisible; }

    // ── Stats cache ───────────────────────────────────────────────────────────
    // updateDebugStats() — called from GL thread once per frame when visible.
    // getStats()         — called from JNI/Java thread every 250 ms.
    void updateDebugStats(const WorldDebugStats& s) {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        m_stats = s;
    }

    WorldDebugStats getStats() const {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        return m_stats;
    }

    // ── Freeze / snapshot system (v20) ────────────────────────────────────────
    //
    // freezeSnapshot() captures the current live stats as an immutable snapshot.
    // The Java layer calls this via JNI when the user taps the FREEZE button.
    // After freezing, getFrozenStats() returns the captured snapshot until
    // unfreeze() is called.  The live update cycle continues on the GL thread
    // uninterrupted — only the Java UI stops polling getStats() and switches to
    // getFrozenStats() instead.
    void freezeSnapshot() {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        m_frozenStats = m_stats;
        m_frozen = true;
    }

    void unfreeze() {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        m_frozen = false;
    }

    bool isFrozen() const {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        return m_frozen;
    }

    // Returns the frozen snapshot if frozen; live stats otherwise.
    WorldDebugStats getFrozenOrLiveStats() const {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        return m_frozen ? m_frozenStats : m_stats;
    }

    // ── renderDebugUI() ───────────────────────────────────────────────────────
    // Stub — satisfies the spec's class-structure requirement.
    // The coloured-bar GL overlay is rendered by Renderer::renderDebugOverlay().
    // The text panel overlay is rendered by the Android Java layer.
    void renderDebugUI() { /* delegated to Renderer + Java */ }

private:
    mutable std::mutex m_statsMtx;
    WorldDebugStats    m_stats{};
    WorldDebugStats    m_frozenStats{};
    bool               m_frozen = false;
};
