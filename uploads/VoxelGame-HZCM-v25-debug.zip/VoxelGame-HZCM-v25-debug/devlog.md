# VoxelGame HZCM — Development Log

---

## v25-debug  (2026-06-10)

### Context
v24-debug build ran on device. Screen **still solid sky-blue**.
Pipeline counters unchanged and healthy:

| Counter | Value |
|---|---|
| Generated | 289 chunks |
| Meshed | 1156 clusters READY |
| Uploaded | 33 246 faces resident |
| Rendered | 394 draw calls |
| Vertices | 199 476 |
| CamY | 35.0 |

### Conclusions from v24-debug result

**Divisors (Bug F) are NOT the root cause on this device.**
The Mali-G52 MC2 (Helio G85) does NOT reset `glVertexAttribDivisor` on
`glVertexAttribIPointer` calls. The fix was correct logic but the driver doesn't
exhibit that bug. The divisor re-assertion inside `issueDraws` is harmless and stays.

With 394 real draw calls, 199 476 vertices, and all pipeline counters healthy, the
geometry IS being submitted to the GPU. The blue screen means one of two things:

**Path A — Triangles are rasterised but output sky colour.**
Shader logic bug. The most likely cause: `uFogEnd` uniform has its GLSL default
value of `0.0` (never set, because `m_uFogEnd == -1`). With `uFogEnd = 0`:
```
fogStart  = 0 * 0.90 = 0
denominator = 0 - 0 + 0.001 = 0.001
vFog = clamp(dist / 0.001, 0, 1) = 1.0  ← for ANY non-zero dist
→ fragColor = mix(lit, SKY, 1.0) = SKY
```
Every fragment outputs sky blue even though the geometry is fully correct.

**Path B — Triangles are NOT rasterised (zero screen-space area).**
Vertex/clip-space bug. Most likely: `uCamPos` uniform has its GLSL default of
`(0,0,0)`. With `uCamPos = (0,0,0)`, `relPos = wpos` (un-subtracted). The MVP is
built for an eye at world origin; terrain at y = 26 produces:
```
relPos.y = 26 (not 26-35 = -9)
NDC_y   = 1.428 × 26 / 16 ≈ 2.32   ← above top of screen, clipped
```
All surface terrain (y = 20–40) disappears above the frustum. Only y ≈ 0 geometry
(deep underground, no exposed faces) would fall inside — giving an empty screen.

### Diagnostic plan (v25-debug)

#### Phase 1 — magenta fragment override (THIS BUILD)
Fragment shader unconditionally outputs magenta and returns. Bypasses texture,
lighting, and fog entirely.

- **Screen turns magenta** → triangles ARE reaching the rasteriser.
  Bug is in the fragment shader. Most likely cause: `uFogEnd = 0`.
  Next action: check logcat for `init: uFogEnd=-1`, then enable the
  `// vFog = 0.0;` line in the vertex shader and rebuild (Phase 2A).

- **Screen stays blue** → triangles are NOT reaching the rasteriser.
  Bug is in the vertex / clip stage. Most likely cause: `uCamPos = (0,0,0)`.
  Next action: activate `DIAG_VERTEX` block in vertex shader (remove `/*` and
  `*/` markers), rebuild (Phase 2B).

#### Phase 2A — fog-zero (if Phase 1 = magenta)
Uncomment `// vFog = 0.0;` in vertex shader, remove the magenta override.
If terrain appears with correct texture → confirm `uFogEnd` is the bug.
Fix: ensure `m_uFogEnd ≥ 0` (log confirms it), or hardcode `uFogEnd = 89.6`
as a sanity test.

#### Phase 2B — vertex tracer (if Phase 1 = still blue)
Activate `DIAG_VERTEX` block in vertex shader (the `/* … */` block). This
outputs a fixed-NDC triangle at screen-top-centre for instance 0 of every
cluster, using NO uniforms.
- **Triangle appears** → vertex shader runs, divisors are fine, bug is in
  `relPos` / `uMVP` computation.  Check logcat for `uMVP = -1` or `uCamPos = -1`.
- **Nothing appears** → draw calls are not executing at all — GL error, VAO
  misconfiguration, or program not linked.

### Changes made (v25-debug)
| File | Change |
|---|---|
| `Renderer.cpp` | Magenta fragment override **ENABLED** (Phase 1 diagnostic) |
| `Renderer.cpp` | Vertex tracer `DIAG_VERTEX` added as block comment (Phase 2B, inactive) |
| `Renderer.cpp` | `// vFog = 0.0;` comment added below fog calculation (Phase 2A, inactive) |

---

## v24-debug  (2026-06-10)

### Context
v23-debug build ran on device. All five pipeline counters still confirmed working
(441 draw calls, 38 758 faces resident). Screen **still solid sky-blue**.

### Root-cause analysis

#### Bug F — v23 divisor re-assertion placed in the wrong location (incomplete Bug D fix)

The v23 fix called `glVertexAttribDivisor(0,1); (1,1)` **once, before `issueDraws()`**:

```
glBindVertexArray(m_clusterVao);
glVertexAttribDivisor(0, 1);   ← asserted here …
glVertexAttribDivisor(1, 1);
world.gatherAndDraw(…);        ← … but inside this, per cluster:
                               │  glVertexAttribIPointer(0, …)  ← resets divisor[0] → 0
                               │  glVertexAttribIPointer(1, …)  ← resets divisor[1] → 0
                               │  glDrawArraysInstanced(…)      ← fires with divisor=0  ✗
```

With divisor = 0 the attribute is non-instanced: `gl_VertexID` (0–5) advances the
pointer, so the 6 vertices of every triangle read from 6 **different** faces.
The resulting triangle corners are at 3 unrelated world positions — zero screen-space
area — and rasterise nothing. All 441 draw calls produce degenerate geometry.
The pre-loop assert fired exactly once and was immediately overwritten by the first
`glVertexAttribIPointer` call inside the loop. Every subsequent cluster was equally
broken.

**Fix**: move both `glVertexAttribDivisor` calls **inside `DrawBatcher::issueDraws`,
immediately after the two `glVertexAttribIPointer` calls and before
`glDrawArraysInstanced`**:

```cpp
glVertexAttribIPointer(0, …);
glVertexAttribIPointer(1, …);
glVertexAttribDivisor(0, 1);   // ← re-assert AFTER IPointer, BEFORE draw  ✓
glVertexAttribDivisor(1, 1);
glDrawArraysInstanced(GL_TRIANGLES, 0, 6, faceCount);
```

The pre-loop assert in `Renderer.cpp` is kept as belt-and-suspenders but is no longer
load-bearing. The two extra GL calls per cluster (~882/frame) are trivial state writes
with no pipeline stall.

### Changes made (v24-debug)
| File | Change |
|---|---|
| `DrawBatcher.h` | `glVertexAttribDivisor(0,1); (1,1)` moved inside `issueDraws` loop, after IPointer pair, before draw (Bug F fix) |
| `Renderer.cpp` | Pre-loop divisor assert comment updated — clarified as belt-and-suspenders only |

### Expected outcome
With correct divisors per draw call:
- `gl_InstanceID` 0…faceCount−1 advances `aGeom`/`aMat` one packed face per instance.
- `gl_VertexID` 0…5 selects the correct corner via `FRONT_CI` / `BACK_CI`.
- Each `glDrawArraysInstanced` produces `faceCount` valid quads → terrain should appear.

### If screen is still blue after this fix
The divisor reset is confirmed not the cause on this driver. Next steps in order:
1. **Uncomment the magenta diagnostic** in the fragment shader (two lines already in place).
   Rebuild. If screen turns magenta → geometry reaches rasteriser, shader logic is wrong.
   If still blue → triangles are still degenerate.
2. **Check logcat** for `render frame 1:` line — verify `MVP col0` is not all zeros.
3. **Check logcat** for `init: uMVP=` — must be ≥ 0.
4. If MVP is valid and screen is still blue after magenta test → suspect camera inside
   terrain at spawn. `contH = 28 + contN×14` gives range [14, 42]; at seed 42 the
   origin column could be taller than y = 35. Fix: raise spawn to y = 80 and add
   snap-to-ground on first loaded frame.

---

## v23-debug  (2026-06-09)

### Context
All five v22 pipeline-stage counters confirmed working on first run:
- Generated: 323 chunks  ✅
- Meshed: 1292 clusters READY  ✅
- Uploaded: 38 758 faces resident  ✅
- Rendered: 441 draw calls  ✅
- Vertices: 232 548 visible verts  ✅

Pipeline is fully functional end-to-end. Screen is **still solid sky-blue** despite draw calls being issued.

### Root-cause analysis

#### Bug A — Camera spawns 46 blocks above terrain (y = 72 → terrain ≈ y 26)
With `pitch = 0` (horizontal view) and `RD = 7`:
- Y+ (top) faces of terrain blocks are **edge-on** — zero screen-space area — never rasterised.
- Side faces only enter the frustum at ≥ 66 blocks forward distance.
- At that range, fog (`fogStart = 0.70 × fogEnd = 63 blocks`) already tints terrain 10–100% sky colour.
- Result: either a sub-pixel strip at the screen bottom, or nothing visible at all.

**Fix**: `Camera::position.y` changed from `72` to `35` (≈ 9 blocks above surface). At y = 35 with horizontal pitch, terrain at y = 26 appears at NDC_y ≈ −0.86 from just 15 blocks forward, with vFog = 0 (well inside fog-clear zone).

#### Bug B — `GL_CULL_FACE` enabled with unverified winding
`glEnable(GL_CULL_FACE)` was active during all cluster draws.  The winding of faces in screen space has **never been independently verified** on a device:
- At certain camera orientations, CW faces are discarded even though the geometry is correct.
- With 100 % of faces potentially back-face-culled, the screen stays at clear colour (sky blue).

**Fix**: `glDisable(GL_CULL_FACE)` for this debugging session. Re-enable once winding is confirmed correct with visible geometry.

#### Bug C — Uniform locations never validated
`glGetUniformLocation` silently returns `-1` if the uniform name is misspelled, optimised out, or the program failed to link.  `glUniform*(-1, …)` is a no-op:
- `m_uMVP = -1` → `uMVP` stays as the default zero matrix → all `gl_Position = (0,0,0,0)` → degenerate triangles → nothing rasterises.
- `m_uOrigin = -1` → all clusters placed at world origin → all geometry stacked in a 16³ cube that may be outside the frustum.

**Fix**: After `glGetUniformLocation`, log each location value; `LOGE` with a descriptive message for any `-1`.

#### Bug D — `glVertexAttribDivisor` reset by driver on `glVertexAttribIPointer`
`DrawBatcher::issueDraws` calls `glVertexAttribIPointer(0/1, …)` once per cluster (~441×/frame).  On several known GLES3 drivers (Adreno 3xx/4xx, certain Mali) this silently resets the divisor from 1 back to 0, turning instanced into non-instanced rendering.  With divisor = 0 every vertex reads the same `aGeom`/`aMat` (the first face's data), producing degenerate same-position triangles for all 6 vertices.

**Fix**: Call `glVertexAttribDivisor(0, 1); glVertexAttribDivisor(1, 1)` immediately after `glBindVertexArray(m_clusterVao)` each frame.

#### Bug E — Fog onset too aggressive for current RD = 7
`fogStart = uFogEnd × 0.70`.  With `fogEnd = 7 × 16 × 0.8 = 89.6`:
- fogStart = 62.7 blocks.
- Nearest visible terrain (from spawn y = 35, horizontal): ≈ 13 blocks → vFog = 0 ✅ (this is fine now that spawn y is fixed).
- But at the old y = 72 spawn this was the reason any terrain that DID reach the screen appeared sky-coloured.

**Fix**: `fogStart = uFogEnd × 0.90` — reduces fog zone to the outermost 10 % of render distance.

### Changes made (v23-debug)
| File | Change |
|---|---|
| `Camera.h` | Spawn `position.y` 72 → 35 |
| `Renderer.cpp` | `glDisable(GL_CULL_FACE)` |
| `Renderer.cpp` | LOGI/LOGE for all uniform locations after link |
| `Renderer.cpp` | `glVertexAttribDivisor(0,1); (1,1)` after VAO bind each frame |
| `Renderer.cpp` | Fog onset 70 % → 90 % in vertex shader |
| `Renderer.cpp` | Per-frame log includes `camPos`, MVP column-0 values |
| `Renderer.cpp` | Commented diagnostic `fragColor = magenta` in frag shader |
| `DebugOverlay.h` | Added `camY`, `camPitch` fields to `WorldDebugStats` |
| `World.h` | Added `m_lastCamY` member |
| `World.cpp` | `update()` stores `m_lastCamY = camY` |
| `World.cpp` | `getDebugStats()` exposes `s.camY` |
| `jni_bridge.cpp` | DBG panel shows `CamY` in `[POSITION]` section |

### How to read the next debug run
1. Open logcat, filter `HZCMRenderer`.
2. Look for `init: prog=N uMVP=M …` — **all locations must be ≥ 0**.
3. Look for `render frame 1: MVP col0=(…)` — **must NOT be all zeros**.
4. Check `CamY` in DBG panel — **should be ~35 after landing, ~26-28 when on ground**.
5. If screen is still blue, uncomment the two `fragColor = magenta` lines in `Renderer.cpp` (fragment shader), rebuild, confirm screen turns magenta.  If it does → geometry correct, shader logic wrong.  If still blue → triangles degenerate, check MVP column-0 log.

---

## v23  (2026-06-09)

### Bug fix — `genTotal` used outside its scope
`genTotal` was declared inside the `if (!chunk->generated)` block (first-time generation path) but referenced in the mesh-logging loop below, which also runs for already-generated chunks being re-meshed.

**Fix**: replaced `genTotal` reference with a fresh `m_generatedChunks.load()` read named `genSoFar`.

---

## v22-fixed → v23 (initial debug instrumentation, 2026-06-09)

### Five pipeline-stage debug counters added
Required to diagnose the "only sky, no terrain" symptom by pinpointing which stage of the pipeline fails.

| Counter | Source |
|---|---|
| Generated Chunks | `m_generatedChunks` atomic, incremented in `workerChunkBuild` |
| Meshed Clusters READY | count of `ClusterState::READY` clusters across all chunks |
| Faces Resident | sum of `clusterFaceCount` for READY clusters |
| Draw Calls | `m_lastVisibleDraws` (unchanged) |
| Visible Vertices | `m_lastVisibleFaces × 6` |

### Culling disabled (Task 5)
`DISABLE_ALL_CULLING = true` in `gatherAndDraw()` bypasses:
- HierarchicalVisibility chunk-level cull
- Residency gate (`hasAnyResidentCluster`)
- Neighbour-in-flight soft guard
- Frustum AABB test
- Per-cluster sky/underground visibility
- Cluster state gate (READY/MESHED check)

The hard safety check (`offset == MEGA_INVALID || count == 0`) is **kept** — it only skips clusters with no actual GPU data and cannot hide valid geometry.

### Generation / mesh / upload logging
- `CHUNK_GENERATED (cx,cz) total=N` — first 50 chunks + every 100th.
- `MESH_FACES chunk(0,0) ci=N faces=N` — origin chunk logged on every build.
- `MESH_FACES_ZERO chunk(cx,cz) ci=N` — WARN for zero-face ground clusters.
- `GPU_UPLOAD OK chunk(cx,cz) ci=N faces=N` — first 20 uploads + origin chunk.

### Stats always updated
Removed `m_debugOverlay.isVisible()` gate — stats are refreshed every frame so counters are current the instant DBG is opened.

---

## v22 (baseline — world not rendering)

### Symptoms
- Game launches, UI renders (joystick, crosshair, health bar, DBG panel).
- Screen shows only sky colour.
- No world geometry visible regardless of player movement.

### Known fixes applied in v22
- `precision highp int` added to both vertex and fragment shaders (`flat out/in highp int vTexLayer` was rejected by strict Adreno/Mali/PowerVR drivers, causing `glLinkProgram` to fail silently and `glUseProgram(0)` to output solid blue).
- Atlas `glActiveTexture(GL_TEXTURE0)` made explicit before every bind.
- `glTexImage3D` error-checked immediately after upload.

### Open at end of v22
Despite shader precision fix, screen remains blue. Root causes identified in v23-debug session (see above).
