# Performance Report — v28

Same methodology note as v27: this is a source-level review, not a profiled
one — there's no Android SDK/emulator or Gradle in the environment this
update was written in, so nothing here is a measured before/after number.
Treat "expected impact" as reasoning from the code's allocation patterns,
loop/thread behavior, and I/O calls, not a benchmark.

## Bottlenecks Found

### 1. One `Handler.post` per streamed log line, for potentially thousands of lines
`streamBuildLog()`'s full-log print (fetched once, after the build finishes)
called `appendLog()` — which does a `mainHandler.post {}` — separately for
every non-blank, non-group-marker line in the raw job log. A verbose Gradle
build's log can run to thousands of lines.

**Expected impact:** the exact same final text now reaches `tvLog` via one
batched append instead of potentially thousands of individually-posted ones —
fewer main-thread message-queue entries, and the length-cap trim
(`LOG_CHAR_CAP`) now runs at most once for this block instead of once per
line if the cap was exceeded partway through.

### 2. Two independent copies of the same three regexes
`streamBuildLog()` and `showLogDialog()` each defined their own local copies
of the ANSI-code-strip, timestamp-strip, and group-marker regexes used to
clean a raw GitHub Actions log line — same patterns, compiled twice, in two
different places that could silently drift apart if one was ever tweaked
without the other.

**Expected impact:** negligible on its own (`Regex` construction is cheap and
each was already only compiled once per function call, not per line), but
removes a real duplicate-logic / drift risk — see `FILE_CHANGES.md`.

### 3. A dropped connection meant re-downloading (or re-uploading) from zero
Neither the download loop nor the upload path retried anything — any network
hiccup (a dropped Wi-Fi connection, a switch to mobile data, a transient
GitHub/CDN 503) failed the operation outright, and re-running it re-fetched
or re-sent 100% of the bytes from scratch, however far the previous attempt
had gotten.

**Expected impact:** on a real, less-than-perfect mobile connection, this is
likely the single biggest practical performance/data-usage win in this
release — resuming a 90%-complete APK download after a brief signal drop now
costs the last 10%, not another full download. See `V28_RELEASE_NOTES.md` for
the full mechanism.

## APK Size
The release build now turns on R8 code shrinking/obfuscation and resource
shrinking (both were off in every version through v27):
```
minifyEnabled true
shrinkResources true
```
This was judged safe rather than applied blindly — the app was specifically
checked for the things that commonly break under shrinking/obfuscation before
enabling it:
- **No reflection-based (de)serialization.** JSON is parsed by hand with
  `org.json` (`JSONObject`/`JSONArray`), not Gson/Moshi/kotlinx.serialization,
  so there are no data classes relying on field names surviving renaming.
- **No WebView JavaScript interface**, no `Class.forName()` /
  `getMethod()`-style runtime lookups of the app's own classes.
- Manifest-declared components (the Activity, the `FileProvider`) are already
  kept automatically by the Android Gradle Plugin's default R8 configuration
  — nothing extra needed there.
- AndroidX Security/Keystore APIs (used by the token-encryption helper) go
  through the standard JVM crypto SPI (`Cipher.getInstance`,
  `KeyGenerator.getInstance`), which R8 already knows not to strip.

The new `proguard-rules.pro` keeps source file names and line numbers (so a
release-build stack trace from a bug report is still readable) and otherwise
intentionally adds almost nothing, documenting *why* each thing wasn't needed
rather than leaving a future contributor to wonder if it was an oversight.

**Expected impact:** R8 shrinking + obfuscation + resource shrinking
typically yields a meaningfully smaller release APK (unused code paths,
unused resources, and identifier strings all shrink) — no measured number
available in this environment, but this is one of the highest-leverage,
lowest-risk levers available for release APK size, and the app was checked
first for the specific failure modes that make it unsafe elsewhere. If a
release build ever crashes only in `release` (not `debug`) after this change,
that's the first thing to suspect — see `KNOWN_LIMITATIONS.md`.

## Memory Improvements
- No new unbounded buffers introduced: `verifyZipIntegrity()`'s CRC re-check
  reads each ZIP entry through a fixed 64KB sink buffer (discarding as it
  goes), not into a growing in-memory buffer, regardless of the ZIP's size.
- The resumable download engine writes straight to disk in 32KB chunks (as
  the v27 loop already did) — resuming doesn't hold previously-downloaded
  bytes in memory, only whatever's still on disk from the prior attempt.

## Battery
The only new always-on-ish primitive this release adds is a
`ConnectivityManager.NetworkCallback`, and it's scoped tightly: registered
only when a download/upload is actually blocked waiting on connectivity
(`waitForNetwork()`), and unregistered the moment that wait ends — on
reconnect, on cancellation, and defensively again in `onDestroy()` so one can
never outlive the Activity. It is never left registered during normal
(connected, actively transferring) operation, so it adds no continuous
background battery cost outside of an actual outage.

## What Was Reviewed but Left Alone
- **Retrying uploads from scratch instead of resuming them.** GitHub's
  upload endpoints (Contents API PUT, and the blob/tree/commit sequence) have
  no partial-request mechanism the way a download's `Range` header does, so
  true byte-resume isn't available here regardless of effort spent. A full
  redo of a large upload after a network blip is the correct trade-off — not
  a gap left for later — because the redo is cheap (content-addressed blobs)
  rather than wasteful.
- **Base64 upload memory footprint** (raw bytes → Base64 string → JSON
  payload → UTF-8 bytes, all resident at once for a large ZIP) — already
  reviewed in `PERFORMANCE_REPORT.md` v27 (#5, `largeHeap`); unchanged here,
  and out of scope for this release's network-reliability focus.
- The embedded GitHub Actions workflow YAML, and the overall single-file/
  single-Activity architecture — both already reviewed in v27 and still
  believed correct; re-reviewing them here would be re-litigating a decision
  the brief already asked to leave alone unless something was actually wrong.

---

# Performance Report — v27

A note on methodology first: this was a source-level review, not a profiled
one — there's no way to actually run the app or a Gradle build in the
environment this update was written in. Every item below is reasoned from
what the code does (allocation patterns, thread/loop behavior, I/O calls), not
from measured before/after numbers. Treat the "expected impact" notes as
reasoning, not benchmarks.

## Bottlenecks Found

### 1. Unbounded ad hoc thread creation
25 separate call sites did `thread { ... }`, each spinning up a brand-new OS
thread (with its own ~512KB–1MB default stack) for what's usually a short
network call. No ceiling existed on how many could be alive at once.

**Expected impact:** fewer thread creations/teardowns per session and a lower
worst-case memory footprint from live thread stacks — most noticeable on a
low-RAM device under normal use (a handful of actions in a session), and it
also removes a real (if unlikely) failure mode where rapid tapping could have
spawned many concurrent threads with no bound.

### 2. Redundant scroll-to-bottom during log streaming
`appendLog()` queued a `fullScroll()` pass for every single line appended.
A verbose Gradle build streams hundreds of lines; that's hundreds of queued
scroll passes, most of them made obsolete by the next line arriving
microseconds later.

**Expected impact:** far fewer scroll passes during a build's log streaming —
this is the single most repeated code path in the whole app during active use,
so it's the one most worth trimming.

### 3. Line-number gutter recomputed on every keystroke
The file editor's line-number column re-split the *entire document* and
rebuilt the whole `"1\n2\n3\n…\nN"` gutter string on every character typed,
regardless of whether that character could have changed the line count.

**Expected impact:** this is the fix most likely to be *felt* directly — typing
in a file of any real size (a few hundred lines or more) should no longer lag,
since the expensive path now only runs on edits that actually touch a newline
(pressing Enter, deleting a line, pasting multi-line text), not on ordinary
typing.

### 4. Wasted polling after success
`promptCreateRepo()`'s `repeat(10) { return@repeat }` loop could not exit
early on success — `return@repeat` only skips to the next iteration. Once the
repo became reachable, the loop kept sleeping 2s and re-checking for every
remaining iteration anyway.

**Expected impact:** up to ~18 fewer seconds of pure waiting on the "create new
repo" path (the exact amount depends on which iteration first succeeded).

### 5. Memory pressure on large project uploads
The Git Data API upload path can hold several full copies of a project ZIP in
memory at once during encoding (raw bytes → Base64 string → JSON-wrapped
payload → UTF-8 byte array). For a ZIP approaching the app's own 99MB cap,
that's a meaningful multiple of 99MB resident at once, without the app
requesting a larger heap.

**Expected impact:** `android:largeHeap="true"` raises the ceiling the OS gives
the app before it would OOM-kill on this path — a standard mitigation for an
app that legitimately needs to hold a large buffer temporarily, rather than a
rewrite of the (working, tested) upload logic itself.

### 6. Duplicated dialog construction
`downloadArtifact()` hand-built its own ~115-line copy of the download-progress
dialog that `buildDownloadProgressDialog()` already provides — extra bytecode,
and two copies that could silently drift apart over time.

**Expected impact:** smaller method, one less thing to keep in sync, no
behavior change (verified the resulting dialog wiring — pause/resume/cancel —
is identical to what the hand-built version did).

## Memory Improvements
- `android:largeHeap="true"` (see #5 above).
- Console log (`tvLog`) now capped at ~200k characters, trimmed from the
  oldest end, so a long or looping build — or just a long-lived session across
  several builds — can't grow its backing buffer without bound.
- The artifact ZIP cached during download is now deleted immediately after
  being copied to Downloads, instead of accumulating in `cacheDir` forever.
- A one-time stale-cache sweep on cold start catches any leftover temp files
  from a session that was killed before its own cleanup ran.
- Bounding background threads to 4 also bounds worst-case memory spent on
  live thread stacks.

## Build Speed
This refers to two different things worth separating:
- **This app's own APK build speed** wasn't a target here — this is a hand-
  maintained app, not a generated one, and its own build wasn't observed to
  be slow.
- **The GitHub Actions builds this app triggers for other projects**: the
  embedded workflow was reviewed for caching/speed opportunities and is
  already in good shape — `gradle/actions/setup-gradle` for dependency
  caching, a dedicated NDK/CMake cache, a hash-keyed incremental cache for
  C++/CMake build outputs, and `--configuration-cache --build-cache --parallel`
  on the actual Gradle invocation. Nothing was changed here; adding another
  cache layer on top would be redundant rather than additive, and the CI
  workflow is the highest-blast-radius part of the whole system to get wrong.
- Fixed the ~18s of wasted polling in new-repo creation (see #4).

## Battery
Nothing here draws obvious continuous battery beyond what the app already
did (network polling during a build, which is inherent to the design). The
executor change indirectly helps a little: fewer live threads means less
scheduler overhead, and the app is no longer capable of accumulating an
unbounded number of concurrently-running background threads if someone taps
around quickly.

## What Was Reviewed but Left Alone
- The `HttpURLConnection` + `.disconnect()` pattern used throughout: this is
  a deliberate, consistent choice (guarantees resource cleanup) rather than an
  oversight, and changing it to optimize for connection-pool reuse would be a
  behavior change to network code with no way to verify it here — not worth
  the risk for a marginal gain.
- The embedded GitHub Actions workflow YAML (see above) — already
  well-optimized.
- The overall single-file, single-Activity architecture — the brief was
  explicit about not rewriting working systems, and a structural refactor
  (e.g. splitting the ~4,700-line file into multiple classes) is a much
  higher-risk change for a codebase that can't be compiled in this
  environment to verify. Everything in this update is a targeted, in-place
  change instead.
