# Review Report — v28

This is the record of the "review every previous fix, review every modified
file, verify compilation" pass the brief asked for. It's split into (1) how
correctness was checked in an environment with no Android SDK/emulator and no
network access, (2) what was verified from v27, and (3) what was checked on
v28's own new code.

## Methodology & Its Limits

This environment has a JDK but **no `kotlinc`, no Android SDK, no Gradle, and
no network access** (outbound requests are blocked by the sandbox's egress
allowlist — confirmed directly, not assumed). That means **no real compile,
and no real build, happened at any point in this process.** Everything below
is static review, not a build log. Concretely, the following was done instead:

1. **Structural balance checking.** A script stripped every string literal,
   line comment, and block comment from the file (handling escape sequences
   so a `\"` inside a string can't be mistaken for its end), then counted
   `{}`/`()`/`[]` in what remained. Braces and brackets balance exactly
   (verified before and after every edit in this session). Parentheses show
   a constant `+2` "imbalance" — but this exact same `+2` is present in the
   **untouched, pristine v27 source** too (confirmed by running the identical
   script against the original ZIP), which means it's an artifact of the
   checking script itself (most likely a literal `(`/`)` appearing
   unpaired inside a single string's English prose, which the script — by
   design — doesn't count at all, so an imbalance *inside* one string can't
   actually affect real code balance). Since the count didn't change from the
   baseline after any edit in this session, no edit introduced a new
   imbalance.
2. **Manual line-by-line reading** of every function added or changed this
   release, tracing call sites, thread ownership (which functions run on
   `bgExecutor` vs. the main thread), and lifecycle (what `onDestroy()` needs
   to clean up) by hand.
3. **Cross-referencing against the pristine original.** The uploaded v27 ZIP
   was kept unextracted-but-available throughout, so every "is this actually
   a bug" question could be checked against real, unmodified baseline source
   rather than against memory of what a previous pass might have changed.
4. **Whole-file mechanical scans** for specific risk patterns: every
   unguarded `!!` (found and triaged each one — see below), every import
   (checked each is actually referenced elsewhere in the file), every private
   member function (checked each is actually called somewhere, accounting for
   Kotlin's trailing-lambda call syntax which a naive `name(` search misses),
   and every stream-opening call (`openInputStream`/`FileOutputStream`/
   `ZipInputStream`/etc., checked each is wrapped in `.use {}` or otherwise
   guaranteed to close).
5. **Resource file diffing.** Every file under `app/src/main/res/` was
   diffed against the original byte-for-byte, not spot-checked, to confirm
   the "keep the UI visually identical" requirement actually holds rather
   than assuming it.
6. **Whole-project file diffing against the pristine original**, beyond just
   `res/` — this is how the missing `gradle/wrapper/gradle-wrapper.jar` (see
   `KNOWN_LIMITATIONS.md`) was confirmed to be a pre-existing gap rather than
   something lost during this session's work: `gradlew` and
   `gradle-wrapper.properties` are byte-for-byte identical to the untouched
   original, and the jar was never present in either.

None of this substitutes for a real `./gradlew assembleRelease`. If anything
in this release doesn't compile, it's most likely to be a small, mechanical
issue (a typo'd identifier, a mismatched type) rather than a structural one —
see `KNOWN_LIMITATIONS.md`.

## Verification of Previous (v27) Fixes

Each fix in `BUGS_FIXED.md`'s v27 section was re-checked against the current
source:

| # | v27 fix | Verified |
|---|---------|----------|
| 1 | Owner-chip brace bug in `restoreSavedBuildState()` | ✅ still braced correctly |
| 2 | `promptCreateRepo()` uses `for`/`break`, not `repeat`/`return@repeat` | ✅ confirmed (`for (attempt in 1..10) { ...; break }`) |
| 3 | File editor gutter only recomputes on a newline-spanning edit | ✅ present, unchanged |
| 4 | MediaStore path reported matches the actually-saved name | ✅ present, unchanged |
| 5 | Batch delete continues past a single failed item | ✅ present, unchanged |
| 6 | Artifact ZIP cache copy deleted after saving to Downloads | ✅ present; this release adds a second, longer-lived cache lifecycle for *unfinished* downloads specifically (see `BUGS_FIXED.md` v28 #1) without touching the original delete-on-success behavior |
| 7 | Single class-level `fmtBytes()`, no duplicates | ✅ confirmed no other `fmtBytes` definitions exist |

`bgExecutor` (the shared 4-thread pool replacing 25 ad hoc `thread {}` calls)
was also spot-checked: confirmed every long-running loop found this release
(`performResumableDownload`'s retry/backoff waits, `withUploadRetry`'s waits)
runs from within an existing `bgExecutor.execute {}` call site, not on the
main thread — grepped every `Thread.sleep(` call site in the file and
inspected its enclosing function for this specifically.

## New Code Review Notes (v28)

- **Thread/dialog ownership audited end-to-end** for the new download/upload
  code: `buildDownloadProgressDialog()` is called directly (main-thread
  context) from `downloadArtifact()` but via a `mainHandler.post` +
  `CountDownLatch` bridge from `downloadLatestRunLogs()` (which runs
  entirely inside `bgExecutor.execute {}`) — confirmed both call sites match
  what the function actually needs, rather than assuming consistency.
- **`DownloadDialogHolder`/`UploadDialogHolder` field names** cross-checked
  against every read/write site across `performResumableDownload`,
  `offerManualRetry`, `notifyRetrying`, and `withUploadRetry` — no
  mismatches.
- **Cancellation is checked at the top of every retry-loop iteration**, in
  `performResumableDownload` and `withUploadRetry` alike, including
  immediately after both `sleepCancellable()` and `waitForNetwork()` return
  early due to cancellation — so a mid-backoff or mid-outage Cancel tap is
  never missed regardless of which wait it interrupts.
- **The one-time HTTP `416` auto-restart is guarded against looping forever**
  (a `rangeRestartUsed` flag) — a repeat `416` on the fresh 0%-restarted
  attempt is treated as fatal instead of silently retrying indefinitely.
- **`onDestroy()` cleans up the new `ConnectivityManager.NetworkCallback`**
  defensively, in addition to `waitForNetwork()`'s own normal
  register/unregister pairing, so a callback registered right as the
  Activity is torn down can't leak. Confirmed the Activity's
  `android:configChanges="orientation|screenSize|keyboardHidden"` means
  `onDestroy()` only fires on real termination, not rotation, so this isn't
  masking a much-more-frequent recreate/leak cycle.
- **Compile-shape spot checks**: confirmed `Pair<Int, String>` destructuring
  (`.also { (code, body) -> ... }`) used in the upload-retry wiring is valid
  Kotlin for any type with `component1()`/`component2()`, which `Pair`
  provides; confirmed `kotlin.io.*` (needed for `File.inputStream()` /
  `InputStream.buffered()` used in `verifyZipIntegrity()`) is part of
  Kotlin's implicit default imports, so no new import was needed for it.

## Files Reviewed But Requiring No Change

`settings.gradle`, `gradle.properties`, root `build.gradle`, `gradlew`,
`gradle-wrapper.properties`, every file under `app/src/main/res/`, and the
embedded `WORKFLOW_YAML` / `KEYSTORE_WORKFLOW_YAML` strings — all reviewed,
none found to need a v28 change.
