# ZipApkBuilder release shrinking rules (added in v28 alongside minifyEnabled/
# shrinkResources — see PERFORMANCE_REPORT.md and CHANGELOG.md for why this
# was judged safe to turn on).
#
# This app has no reflection-based (de)serialization (JSON is parsed by hand
# with org.json, not Gson/Moshi/kotlinx.serialization), no WebView JavaScript
# interface, and doesn't look up its own classes/methods by name at runtime —
# so it needs very few explicit keep rules. Manifest-declared components
# (the Activity, the FileProvider) are already kept automatically by the
# default Android Gradle Plugin R8 configuration; nothing extra is needed for
# those here.

# Keep source file names + line numbers so a release-build stack trace (e.g.
# from Play Console / a bug report) is still readable, without keeping full
# class names to the same extent obfuscation still removes elsewhere.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# AndroidX Security / Keystore APIs used by TokenCrypto rely on standard JVM
# crypto SPI lookup (javax.crypto.Cipher.getInstance / KeyGenerator.getInstance),
# not app-side reflection, so no keep rule is needed for TokenCrypto itself.
# Kept here only as a documented no-op so a future contributor doesn't wonder
# whether it was simply forgotten.
# -keep class com.zipapkbuilder.TokenCrypto { *; }  # intentionally NOT needed

# If a future dependency introduces reflection-based (de)serialization
# (Gson/Moshi/Room/etc.), add matching -keep rules for the affected data
# classes at that point — see KNOWN_LIMITATIONS.md.
