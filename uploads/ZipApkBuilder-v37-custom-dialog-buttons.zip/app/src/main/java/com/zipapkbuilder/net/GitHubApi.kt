package com.zipapkbuilder.net

import java.net.HttpURLConnection
import java.net.URL

/**
 * Thin, stateless wrapper around `HttpURLConnection` for the handful of
 * GitHub REST endpoints this app calls (Contents API, Actions API, Git Data
 * API). Every call takes the token explicitly rather than the client holding
 * one, since the token can change between calls (the user may edit the token
 * field between actions) — this mirrors how the endpoints were called before
 * this was split out of the Activity, just without the duplication of
 * `HttpURLConnection` boilerplate across five near-identical functions.
 */
object GitHubApi {

    fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    /**
     * PATCH via POST + X-HTTP-Method-Override so it works on Android's
     * HttpURLConnection which may not support PATCH natively on API < 29.
     */
    fun httpPatch(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("X-HTTP-Method-Override", "PATCH")
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    /**
     * POST with chunked streaming so large bodies show upload progress.
     * [isCancelled] is polled between chunks so the caller's own cancel flag
     * (e.g. the upload dialog's Cancel button) can abort mid-flight.
     */
    fun httpPostWithProgress(
        token: String, urlStr: String, body: String,
        isCancelled: () -> Boolean,
        onProgress: (written: Long, total: Long) -> Unit
    ): Pair<Int, String> {
        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000; readTimeout = 300_000
            setFixedLengthStreamingMode(bodyBytes.size.toLong())
        }
        conn.connect()
        val chunkSize = 65_536
        var written = 0
        conn.outputStream.use { out ->
            while (written < bodyBytes.size) {
                if (isCancelled()) { conn.disconnect(); throw Exception("Cancelled by user") }
                val end = minOf(written + chunkSize, bodyBytes.size)
                out.write(bodyBytes, written, end - written)
                written = end
                onProgress(written.toLong(), bodyBytes.size.toLong())
            }
            out.flush()
        }
        return try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }
    }

    /** PUT with chunked writes so upload progress can be tracked. */
    fun httpPutWithProgress(
        token: String,
        urlStr: String,
        body: String,
        isCancelled: () -> Boolean,
        onProgress: (written: Long, total: Long) -> Unit
    ): Pair<Int, String> {
        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000; readTimeout = 120_000
            setFixedLengthStreamingMode(bodyBytes.size.toLong())
        }
        conn.connect()
        val chunkSize = 65_536
        var written = 0
        conn.outputStream.use { out ->
            while (written < bodyBytes.size) {
                if (isCancelled()) { conn.disconnect(); throw Exception("Cancelled by user") }
                val end = minOf(written + chunkSize, bodyBytes.size)
                out.write(bodyBytes, written, end - written)
                written = end
                onProgress(written.toLong(), bodyBytes.size.toLong())
            }
            out.flush()
        }
        return try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }
    }
}
