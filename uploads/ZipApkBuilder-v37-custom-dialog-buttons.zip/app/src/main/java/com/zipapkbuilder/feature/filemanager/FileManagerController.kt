package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.net.Uri
import android.util.Base64
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.BoundedListView
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.core.setStartIcon
import com.zipapkbuilder.core.styleButton
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import org.json.JSONObject

/**
 * Browses, views, edits, creates, deletes, and moves files in the target
 * GitHub repo via the Contents API — a lightweight in-app alternative to
 * cloning the repo just to tweak a config file or check what's there. Every
 * mutation (edit/create/delete/move) re-fetches the containing directory
 * afterward via [fetchAndBrowse] rather than patching the in-memory list, so
 * the view can never drift from what's actually on GitHub.
 */
class FileManagerController(private val activity: MainActivity) {

    /** Maps a file extension to a color used for its name in the browser list. */
    private fun fileTypeColor(name: String): Int {
        val ext = name.substringAfterLast(".", "").lowercase()
        return when (ext) {
            "kt", "java", "py", "js", "ts", "c", "cpp", "h", "rs", "go", "rb", "swift" -> 0xFF5B8DEF.toInt() // code — blue
            "yml", "yaml", "gradle", "properties", "toml", "json", "lock" -> 0xFFF5A623.toInt()             // config/build — amber
            "xml", "md", "txt", "html", "css" -> 0xFF2ECC71.toInt()                                          // markup/docs — green
            "png", "jpg", "jpeg", "webp", "svg", "gif", "ico" -> 0xFFE066A8.toInt()                          // images — pink
            else -> 0xFF7C6BFF.toInt()                                                                       // everything else — original purple
        }
    }

    // ── File Manager (browse/edit repo files) ─────────────────────────────────

    fun showManageFilesDialog() {
        val token = activity.etToken.text.toString().trim()
        val repo  = activity.etRepo.text.toString().trim()
        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        // Allow opening the create-repo dialog even without a repo name
        if (repo.isEmpty()) {
            lateinit var dlg: AlertDialog
            val content = activity.dialogWithActions(
                activity.dialogMessage("No repo entered. Would you like to create a new repo?"),
                DialogAction("Create Repo", ButtonTone.GREEN, R.drawable.ic_add) { dlg.dismiss(); promptCreateRepo(token) },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
            )
            dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("📂 File Manager")
                .setView(content)
                .show()
            return
        }

        // If owner is already cached, go straight to browsing
        if (activity.lastOwner.isNotEmpty()) {
            fetchAndBrowse(token, activity.lastOwner, repo, branch, "")
            return
        }

        // Otherwise look it up (same pattern as browseAllArtifacts / downloadLatestRunLogs)
        activity.setBusy(true)
        activity.appendLog("Verifying token…")
        activity.bgExecutor.execute {
            val owner = activity.buildFlowController.fetchOwner(token)
            if (owner == null) {
                activity.appendLog("✗ Could not verify token — check it has 'repo' scope.")
                activity.mainHandler.post { activity.setBusy(false) }
                return@execute
            }
            activity.lastOwner = owner
            activity.mainHandler.post {
                activity.tvOwnerInfo.text = "✓  @$owner / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE
                fetchAndBrowse(token, owner, repo, branch, "")
            }
        }
    }

    /** Fetches directory contents and opens the browser dialog. */
    fun fetchAndBrowse(token: String, owner: String, repo: String, branch: String, path: String) {
        activity.setBusy(true)
        activity.appendLog("Browsing ${if (path.isEmpty()) "repo root" else "/$path"} …")
        activity.bgExecutor.execute {
            try {
                val items = mutableListOf<RepoItem>()
                val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, path.ifEmpty { "" }))
                when {
                    code == 404  -> { /* empty dir — show empty browser */ }
                    code != 200  -> throw Exception("HTTP $code listing /${path.ifEmpty { "" }}")
                    else -> {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            items.add(RepoItem(
                                type = obj.getString("type"),
                                name = obj.getString("name"),
                                path = obj.getString("path"),
                                sha  = obj.optString("sha", ""),
                                size = obj.optLong("size", 0L)
                            ))
                        }
                        // Folders first, then files, alphabetical within each group
                        items.sortWith(compareBy({ if (it.type == "dir") 0 else 1 }, { it.name }))
                    }
                }
                activity.mainHandler.post { activity.setBusy(false); showBrowserDialog(token, owner, repo, branch, path, items) }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /** Main browsing dialog — tap folder to navigate, tap file to act on it. */
    private fun showBrowserDialog(
        token: String, owner: String, repo: String, branch: String,
        path: String, items: List<RepoItem>
    ) {
        val dp = activity.resources.displayMetrics.density

        // ── Custom title: header bar + action chips + breadcrumb ──────────
        val segments = if (path.isEmpty()) emptyList() else path.split("/")

        val titleRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#1C2038"))
        }

        // Top bar: icon + repo path
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
        }
        val folderIv = android.widget.ImageView(activity).apply {
            setImageResource(R.drawable.ic_folder)
            imageTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF9F43"))
            layoutParams = LinearLayout.LayoutParams((18 * dp).toInt(), (18 * dp).toInt()).also {
                it.marginEnd = (10 * dp).toInt()
            }
        }
        val titleTv = TextView(activity).apply {
            text      = "$owner / $repo"
            textSize  = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor("#E8EAED"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchChip = TextView(activity).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        topBar.addView(folderIv); topBar.addView(titleTv); topBar.addView(branchChip)
        titleRoot.addView(topBar)

        // Action chips row
        var pendingDialog: AlertDialog? = null
        val chipRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), (2*dp).toInt(), (14*dp).toInt(), (8*dp).toInt())
        }
        val switchChip = activity.pillButton("Switch", ButtonTone.SURFACE, R.drawable.ic_switch) {
            pendingDialog?.dismiss(); activity.repoSwitcher.showSavedReposDialog()
        }
        switchChip.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.marginEnd = (8*dp).toInt() }
        chipRow.addView(switchChip)
        chipRow.addView(activity.pillButton("Trigger", ButtonTone.ORANGE, R.drawable.ic_flash) {
            pendingDialog?.dismiss()
            activity.buildFlowController.triggerWorkflowDispatch(token, owner, repo, branch)
        })
        titleRoot.addView(chipRow)

        // Breadcrumb strip
        val breadScroll = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), (12 * dp).toInt())
        }
        val breadRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }

        fun crumb(label: String, targetPath: String?, isLast: Boolean) = TextView(activity).apply {
            text     = label
            textSize = 13f
            setTextColor(if (isLast)
                android.graphics.Color.parseColor("#9AA0B8")
            else
                android.graphics.Color.parseColor("#7C6BFF"))
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
            if (!isLast && targetPath != null) setOnClickListener {
                pendingDialog?.dismiss()
                fetchAndBrowse(token, owner, repo, branch, targetPath)
            }
        }
        fun sep() = TextView(activity).apply {
            text = " / "; textSize = 13f
            setTextColor(android.graphics.Color.parseColor("#3A4060"))
        }

        breadRow.addView(crumb("root", "", segments.isEmpty()))
        segments.forEachIndexed { i, seg ->
            breadRow.addView(sep())
            breadRow.addView(crumb(seg, segments.take(i + 1).joinToString("/"), i == segments.lastIndex))
        }
        breadScroll.addView(breadRow)
        breadScroll.post { breadScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
        titleRoot.addView(breadScroll)

        // Search/filter box — only useful with something to filter, so it's only
        // shown when the folder actually has entries. Its View is created and
        // placed here for the right visual position (right below the breadcrumb);
        // the actual filtering behavior is wired up further down, once
        // filteredItems/adapter exist.
        val etFileSearch = EditText(activity).apply {
            hint = "Filter files in this folder…"
            textSize = 12f; isSingleLine = true
            setTextColor(0xFFE8EAED.toInt())
            setHintTextColor(0xFF50587A.toInt())
            setBackgroundColor(0xFF161B22.toInt())
            setPadding((12*dp).toInt(), (7*dp).toInt(), (12*dp).toInt(), (7*dp).toInt())
        }
        if (items.isNotEmpty()) {
            titleRoot.addView(etFileSearch, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.leftMargin = (16*dp).toInt(); it.rightMargin = (16*dp).toInt(); it.bottomMargin = (10*dp).toInt() })
        }

        // Thin accent line at bottom of title
        titleRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(android.graphics.Color.parseColor("#232747"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Build nav list ───────────────────────────────────────────────
        val navItems = mutableListOf<RepoItem>()
        if (path.isNotEmpty()) {
            val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
            navItems.add(RepoItem(type = "__up__", name = "..", path = parentPath, sha = ""))
        }
        navItems.addAll(items)

        // ── Custom ArrayAdapter using item_file.xml ──────────────────────
        // filteredItems (not navItems directly) is what getCount/getItem/getView
        // all read from — this is what the search box below filters via
        // notifyDataSetChanged(), without relying on ArrayAdapter's own built-in
        // filtering machinery (which filters by toString() and wouldn't line up
        // with this adapter's custom getView()).
        val filteredItems = navItems.toMutableList()
        val adapter = object : android.widget.ArrayAdapter<RepoItem>(
            activity, R.layout.item_file, navItems
        ) {
            override fun getCount() = filteredItems.size
            override fun getItem(pos: Int) = filteredItems[pos]
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val row = convertView ?: activity.layoutInflater.inflate(R.layout.item_file, parent, false)
                row.setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
                val item = filteredItems[pos]
                val ivIcon  = row.findViewById<android.widget.ImageView>(R.id.ivFileIcon)
                val tvName  = row.findViewById<TextView>(R.id.tvFileName)
                val tvType  = row.findViewById<TextView>(R.id.tvFileType)
                val ivChev  = row.findViewById<android.widget.ImageView>(R.id.ivChevron)

                when (item.type) {
                    "__up__" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#9AA0B8"))
                        tvName.text = ".. (up one level)"
                        tvName.setTextColor(android.graphics.Color.parseColor("#9AA0B8"))
                        tvType.text = "parent folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    "dir" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#FF9F43"))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        tvType.text = "folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    else -> {
                        ivIcon.setImageResource(R.drawable.ic_file)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(fileTypeColor(item.name))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        val ext = item.name.substringAfterLast(".", "")
                        val extLabel = if (ext.isNotEmpty()) ext.uppercase() else "file"
                        tvType.text = if (item.size > 0) "$extLabel  ·  ${Formatters.fmtBytes(item.size)}" else extLabel
                        ivChev.visibility = android.view.View.GONE
                    }
                }
                return row
            }
        }

        etFileSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val query = (s?.toString() ?: "").trim()
                filteredItems.clear()
                filteredItems.addAll(
                    if (query.isEmpty()) navItems
                    // "up one level" stays visible under any filter — filtering
                    // out the only way to navigate back up would strand the user.
                    else navItems.filter { it.type == "__up__" || it.name.contains(query, ignoreCase = true) }
                )
                adapter.notifyDataSetChanged()
            }
        })

        // ── List + action buttons ────────────────────────────────────────
        // Built as one custom content view (BoundedListView + dialogWithActions row)
        // rather than the AlertDialog's own `.setAdapter()` + `.setPositiveButton()`
        // button bar — see dialogWithActions' doc for why: the platform button bar's
        // OEM-dependent sizing took three rounds to get even approximately right and
        // still looked oversized, while this exact pillButton look is already proven
        // fine elsewhere (Switch/Trigger chips above).
        val maxListHeight = (activity.resources.displayMetrics.heightPixels * 0.5f).toInt()
        val listView: android.widget.ListView? = if (navItems.isEmpty()) null else
            BoundedListView(activity, maxListHeight).apply {
                this.adapter = adapter
                setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
                divider = android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1C2038"))
                dividerHeight = 1
                setOnItemClickListener { _, _, which, _ ->
                    val item = filteredItems[which]
                    when {
                        item.type == "__up__" || item.type == "dir" -> {
                            pendingDialog?.dismiss()
                            fetchAndBrowse(token, owner, repo, branch, item.path)
                        }
                        else -> {
                            val colorInfo = 0xFF4DA6FF.toInt()
                            val colorRed  = 0xFFFF6B6B.toInt()
                            val actionRows = listOf(
                                IconMenuRow("View / Edit",   R.drawable.ic_eye,    colorInfo),
                                IconMenuRow("Copy content",  R.drawable.ic_copy,   colorInfo),
                                IconMenuRow("Move / Rename",  R.drawable.ic_edit,   colorInfo),
                                IconMenuRow("Delete",         R.drawable.ic_delete, colorRed, labelColor = colorRed)
                            )
                            // No Cancel button here — this is a plain tap-to-pick list,
                            // and dialogs already dismiss on outside-tap/back by default.
                            AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                                .setTitle(item.name)
                                .setAdapter(IconMenuAdapter(activity, actionRows)) { _, action ->
                                    when (action) {
                                        0 -> fetchAndViewFile(token, owner, repo, branch, item, path)
                                        1 -> fetchAndCopyFile(token, owner, repo, item)
                                        2 -> {
                                            val input = EditText(activity).apply {
                                                setText(item.path)
                                                hint = "new/path/filename.ext"
                                                inputType = android.text.InputType.TYPE_CLASS_TEXT
                                                setPadding(64, 24, 64, 24)
                                                setSelection(text.length)
                                            }
                                            lateinit var moveDlg: AlertDialog
                                            val moveBody = LinearLayout(activity).apply {
                                                orientation = LinearLayout.VERTICAL
                                                addView(activity.dialogMessage("Enter the new path for this file:"))
                                                addView(input)
                                            }
                                            val moveContent = activity.dialogWithActions(
                                                moveBody,
                                                DialogAction("Move", ButtonTone.TEAL, R.drawable.ic_edit) {
                                                    val newPath = input.text.toString().trim().trimStart('/')
                                                    if (newPath.isEmpty() || newPath == item.path) {
                                                        activity.appendLog("⚠ Path unchanged.")
                                                    } else {
                                                        moveDlg.dismiss()
                                                        activity.setBusy(true)
                                                        activity.bgExecutor.execute { moveRepoFile(token, owner, repo, branch, item, newPath, path) }
                                                    }
                                                },
                                                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { moveDlg.dismiss() }
                                            )
                                            moveDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                                                .setTitle("Move / Rename").setView(moveContent).show()
                                        }
                                        3 -> {
                                            lateinit var delDlg: AlertDialog
                                            val delContent = activity.dialogWithActions(
                                                activity.dialogMessage("Delete from repo?\n\n• ${item.name}"),
                                                DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                                                    delDlg.dismiss()
                                                    activity.setBusy(true)
                                                    activity.bgExecutor.execute {
                                                        deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                                                        activity.setBusy(false)
                                                        activity.mainHandler.post { fetchAndBrowse(token, owner, repo, branch, path) }
                                                    }
                                                },
                                                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { delDlg.dismiss() }
                                            )
                                            delDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                                                .setTitle("Confirm Delete").setView(delContent).show()
                                        }
                                    }
                                }
                                .show()
                        }
                    }
                }
            }

        val bodyView: android.view.View = listView ?: activity.dialogMessage("(empty folder)")

        val actions = mutableListOf<DialogAction>()
        actions += DialogAction("New", ButtonTone.GREEN, R.drawable.ic_add) {
            pendingDialog?.dismiss(); showNewItemDialog(token, owner, repo, branch, path)
        }
        if (items.isNotEmpty()) {
            actions += DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                pendingDialog?.dismiss(); showDeleteDialog(token, owner, repo, branch, path, items)
            }
        } else if (path.isEmpty()) {
            actions += DialogAction("New Repo", ButtonTone.GREEN, R.drawable.ic_add) {
                pendingDialog?.dismiss(); promptCreateRepo(token)
            }
        }
        actions += DialogAction(
            if (path.isNotEmpty()) "Up" else "Close", ButtonTone.SURFACE,
            if (path.isNotEmpty()) R.drawable.ic_arrow_up else R.drawable.ic_close
        ) {
            pendingDialog?.dismiss()
            if (path.isNotEmpty()) {
                val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
                fetchAndBrowse(token, owner, repo, branch, parentPath)
            }
        }

        val browserContent = activity.dialogWithActions(bodyView, *actions.toTypedArray())
        pendingDialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(browserContent)
            .show()
    }

    // ── View / Edit file ─────────────────────────────────────────────────────

    /** Fetches file content from GitHub and opens the editor dialog. */
    private fun fetchAndViewFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, currentPath: String
    ) {
        activity.setBusy(true)
        activity.appendLog("Loading ${item.name} …")
        activity.bgExecutor.execute {
            try {
                val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
                if (code != 200) throw Exception("HTTP $code fetching ${item.path}")
                val obj = org.json.JSONObject(body)
                val sha  = obj.optString("sha", item.sha)
                val size = obj.optLong("size", 0)
                // GitHub wraps base64 at 60 chars — strip all whitespace before decoding
                val raw  = obj.optString("content", "").replace("\n", "").replace("\r", "")
                val bytes = try { android.util.Base64.decode(raw, android.util.Base64.DEFAULT) } catch (e: Exception) { ByteArray(0) }
                val text = if (bytes.isEmpty()) "(binary or empty file — not editable)" else {
                    try { String(bytes, Charsets.UTF_8) } catch (e: Exception) { "(binary file — not editable as text)" }
                }
                activity.mainHandler.post {
                    activity.setBusy(false)
                    showFileEditorDialog(token, owner, repo, branch, item.copy(sha = sha), text, currentPath)
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /** Shows the improved file editor dialog — line numbers, horizontal scroll, status bar. */
    /**
     * Applies lightweight, generic syntax coloring to [editable] — comments,
     * quoted strings, numbers, and `key:` / `key =` style declarations. This
     * editor opens whatever text file a project happens to contain (YAML,
     * Gradle, Kotlin, XML, JSON, Markdown…), so rather than a real per-language
     * parser (well beyond what's practical here), the rules below are the
     * handful of patterns that read reasonably across all of them.
     *
     * Applied once when a file is opened, not on every keystroke: re-running
     * these regexes across the whole document on every character typed would
     * add real, visible lag on a large file (the same reasoning the line-number
     * gutter sync already applies) for a cosmetic feature that doesn't need to
     * track edits live. Freshly typed text simply stays the default color until
     * the file is reopened — a reasonable trade-off for a settings/config
     * editor that's read far more often than typed into character-by-character.
     */
    private fun applySyntaxHighlighting(editable: android.text.Editable) {
        val text = editable.toString()
        fun color(regex: Regex, colorInt: Int) {
            for (m in regex.findAll(text)) {
                editable.setSpan(
                    android.text.style.ForegroundColorSpan(colorInt),
                    m.range.first, m.range.last + 1,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        // Order matters: later calls painting over earlier ones is fine since
        // comments/strings are checked first and rarely overlap with the rest.
        color(Regex("""(?m)^\s*#.*$"""), 0xFF6A9955.toInt())               // YAML/shell/gradle-kts comments
        color(Regex("""(?m)^\s*//.*$"""), 0xFF6A9955.toInt())               // C-style comments
        color(Regex("""<!--[\s\S]*?-->"""), 0xFF6A9955.toInt())            // XML comments
        color(Regex("\"(?:[^\"\\\\]|\\\\.)*\""), 0xFFCE9178.toInt())         // "double-quoted strings"
        color(Regex("""'(?:[^'\\]|\\.)*'"""), 0xFFCE9178.toInt())         // 'single-quoted strings'
        color(Regex("""\b\d+(\.\d+)?\b"""), 0xFFB5CEA8.toInt())            // numbers
        color(Regex("""(?m)^\s*[A-Za-z0-9_.\-]+(?=\s*:)"""), 0xFF7EC4E8.toInt()) // yaml `key:` / gradle `key =`
    }

    private fun showFileEditorDialog(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, content: String, currentPath: String
    ) {
        val dp       = activity.resources.displayMetrics.density
        val screenH  = activity.resources.displayMetrics.heightPixels
        val screenW  = activity.resources.displayMetrics.widthPixels
        val isBinary = content.startsWith("(binary")

        // ── Colour palette (GitHub dark) ─────────────────────────────────
        val bgEditor   = 0xFF0D1117.toInt()
        val bgGutter   = 0xFF161B22.toInt()
        val bgTitleBar = 0xFF1C2038.toInt()
        val bgStatus   = 0xFF161B22.toInt()
        val clrCode    = 0xFFE6EDF3.toInt()
        val clrGutter  = 0xFF495570.toInt()
        val clrInfo    = 0xFF9AA0B8.toInt()
        val clrBadge   = 0xFF7C6BFF.toInt()

        val lines = content.lines()
        val lineCount = lines.size

        // ── Top info bar ─────────────────────────────────────────────────
        val infoBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgTitleBar)
            setPadding((12*dp).toInt(), (8*dp).toInt(), (12*dp).toInt(), (8*dp).toInt())
        }
        val ext = item.name.substringAfterLast(".", "").uppercase().takeIf { it.isNotEmpty() } ?: "TXT"
        val extBadge = TextView(activity).apply {
            text = ext
            textSize = 9.5f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(clrBadge)
            setPadding((6*dp).toInt(), (2*dp).toInt(), (6*dp).toInt(), (2*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (10*dp).toInt() }
        }
        val infoTv = TextView(activity).apply {
            val sizeStr = when {
                content.length >= 1024 -> "${content.length / 1024} KB"
                else -> "${content.length} B"
            }
            text = "$lineCount lines  ·  $sizeStr  ·  UTF-8"
            textSize = 11f
            setTextColor(clrInfo)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchBadge = TextView(activity).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        infoBar.addView(extBadge); infoBar.addView(infoTv); infoBar.addView(branchBadge)

        // ── Line numbers ─────────────────────────────────────────────────
        val lineNumberStr = (1..lineCount).joinToString("\n")
        val lineNumTv = TextView(activity).apply {
            text = lineNumberStr
            textSize = 11.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgGutter)
            setPadding((10*dp).toInt(), (14*dp).toInt(), (10*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.END
            setLineSpacing(0f, 1.35f)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // ── Code EditText ─────────────────────────────────────────────────
        val etContent = EditText(activity).apply {
            setText(content)
            inputType = if (isBinary) android.text.InputType.TYPE_CLASS_TEXT
                        else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            isEnabled = !isBinary
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11.5f
            setTextColor(clrCode)
            setHintTextColor(clrGutter)
            setBackgroundColor(bgEditor)
            setPadding((14*dp).toInt(), (14*dp).toInt(), (24*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            minLines = 5
            setLineSpacing(0f, 1.35f)
            isSingleLine = false
            maxLines = Integer.MAX_VALUE
            // Make wide enough for horizontal scroll to be useful
            minWidth = (screenW * 2.5f).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            // Sync line numbers on edit — but only actually rebuild the gutter (an
            // O(file size) pass over the whole document) when the edit could have
            // changed the line count. Typing/deleting an ordinary character never
            // does; only a newline being inserted or removed can. Without this
            // guard, every single keystroke in a large file re-split the entire
            // document and rebuilt the whole "1\n2\n3\n…\nN" gutter string —
            // visible typing lag on any file with more than a few hundred lines.
            var oldChunkHasNewline = false
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                    oldChunkHasNewline = s?.subSequence(start, start + count)?.contains('\n') == true
                }
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val newChunkHasNewline = s?.subSequence(start, start + count)?.contains('\n') == true
                    if (oldChunkHasNewline || newChunkHasNewline) {
                        val n = (s?.toString() ?: "").lines().size
                        lineNumTv.text = (1..n).joinToString("\n")
                    }
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })

            // One-time pass, not on every keystroke — see applySyntaxHighlighting's
            // kdoc. Size-guarded: a huge file (rare, but possible) would make even
            // a one-time regex pass over the whole document noticeably slow, and
            // this is a cosmetic feature not worth that cost.
            if (!isBinary && content.length < 200_000) {
                applySyntaxHighlighting(this.text)
            }
        }

        // Horizontal scroll wraps the code EditText only
        val hScroll = HorizontalScrollView(activity).apply {
            setBackgroundColor(bgEditor)
            isHorizontalScrollBarEnabled = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(etContent)
        }

        // Side-by-side: gutter + hScroll
        val editorRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bgEditor)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        editorRow.addView(lineNumTv)
        editorRow.addView(hScroll)

        // Outer vertical scroll for the code area
        val nsv = androidx.core.widget.NestedScrollView(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (screenH * 0.54f).toInt()
            )
            isFillViewport = true
            setBackgroundColor(bgEditor)
            addView(editorRow)
        }

        // ── Status bar ────────────────────────────────────────────────────
        val statusBar = TextView(activity).apply {
            text = if (isBinary) "Binary file — read only" else "Tap to edit  ·  Save commits to $branch"
            textSize = 10.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgStatus)
            setPadding((12*dp).toInt(), (6*dp).toInt(), (12*dp).toInt(), (6*dp).toInt())
        }

        // ── Search bar: find in file, next/prev match, go to line ──────────
        val searchMatches = mutableListOf<Int>()
        var currentMatch = -1
        var searchSpans: List<Any> = emptyList()

        fun clearSearchHighlights() {
            val editable = etContent.text
            for (span in searchSpans) editable.removeSpan(span)
            searchSpans = emptyList()
        }

        fun scrollToOffset(offset: Int) {
            val layout = etContent.layout ?: return
            val line = layout.getLineForOffset(offset)
            val y = layout.getLineTop(line)
            nsv.post { nsv.scrollTo(0, y) }
        }

        val tvMatchCount = TextView(activity).apply {
            text = ""; textSize = 10.5f; setTextColor(clrInfo)
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((8*dp).toInt(), 0, (8*dp).toInt(), 0)
        }

        fun runSearch(query: String) {
            clearSearchHighlights()
            searchMatches.clear()
            currentMatch = -1
            if (query.isEmpty()) { tvMatchCount.text = ""; return }
            val text = etContent.text.toString()
            var idx = text.indexOf(query, 0, ignoreCase = true)
            while (idx >= 0) {
                searchMatches.add(idx)
                idx = text.indexOf(query, idx + 1, ignoreCase = true)
            }
            if (searchMatches.isEmpty()) { tvMatchCount.text = "0/0"; return }
            val editable = etContent.text
            searchSpans = searchMatches.map { pos ->
                android.text.style.BackgroundColorSpan(0xFF5A4E1F.toInt()).also { span ->
                    editable.setSpan(span, pos, pos + query.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            currentMatch = 0
            tvMatchCount.text = "1/${searchMatches.size}"
            scrollToOffset(searchMatches[0])
        }

        val etSearch = EditText(activity).apply {
            hint = "Find in file…"; textSize = 11f; isSingleLine = true
            setTextColor(clrCode); setHintTextColor(clrGutter)
            setBackgroundColor(bgGutter)
            setPadding((10*dp).toInt(), (6*dp).toInt(), (10*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { runSearch(s?.toString() ?: "") }
            })
        }
        val btnPrevMatch = activity.iconButton(R.drawable.ic_chevron_left, clrInfo, sizeDp = 16, paddingDp = 6) {
            if (searchMatches.isEmpty()) return@iconButton
            currentMatch = (currentMatch - 1 + searchMatches.size) % searchMatches.size
            tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
            scrollToOffset(searchMatches[currentMatch])
        }
        val btnNextMatch = activity.iconButton(R.drawable.ic_chevron_right, clrInfo, sizeDp = 16, paddingDp = 6) {
            if (searchMatches.isEmpty()) return@iconButton
            currentMatch = (currentMatch + 1) % searchMatches.size
            tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
            scrollToOffset(searchMatches[currentMatch])
        }
        val btnGoToLine = activity.iconButton(R.drawable.ic_hash, clrInfo, sizeDp = 16, paddingDp = 6) {
            val input = EditText(activity).apply {
                hint = "Line 1–$lineCount"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            lateinit var goDlg: AlertDialog
            val goContent = activity.dialogWithActions(
                input,
                DialogAction("Go", ButtonTone.TEAL, R.drawable.ic_hash) {
                    val n = input.text.toString().toIntOrNull()
                    if (n != null && n in 1..lineCount) {
                        goDlg.dismiss()
                        etContent.layout?.let { nsv.post { nsv.scrollTo(0, it.getLineTop(n - 1)) } }
                    } else {
                        activity.appendLog("⚠ Line must be between 1 and $lineCount.")
                    }
                },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { goDlg.dismiss() }
            )
            goDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Go to Line")
                .setView(goContent)
                .show()
        }
        val searchBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgGutter)
            setPadding((8*dp).toInt(), (4*dp).toInt(), (4*dp).toInt(), (4*dp).toInt())
            addView(etSearch); addView(tvMatchCount)
            addView(btnPrevMatch); addView(btnNextMatch); addView(btnGoToLine)
        }

        // ── Container ─────────────────────────────────────────────────────
        val editorRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgEditor)
        }
        editorRoot.addView(infoBar)
        // Thin separator
        editorRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })
        if (!isBinary) editorRoot.addView(searchBar)
        editorRoot.addView(nsv)
        editorRoot.addView(statusBar)

        lateinit var editorDlg: AlertDialog
        val editorContent = activity.dialogWithActions(
            editorRoot,
            DialogAction(if (isBinary) "Close" else "Save", ButtonTone.TEAL, if (isBinary) R.drawable.ic_close else R.drawable.ic_save) {
                editorDlg.dismiss()
                if (!isBinary) {
                    val newText = etContent.text.toString()
                    activity.setBusy(true)
                    activity.bgExecutor.execute { saveFileContent(token, owner, repo, branch, item, newText, currentPath) }
                }
            },
            DialogAction("Copy", ButtonTone.BLUE, R.drawable.ic_copy) {
                editorDlg.dismiss()
                val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, etContent.text.toString()))
                activity.appendLog("📋 Copied ${item.name} to clipboard.")
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { editorDlg.dismiss() }
        )
        editorDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📄  ${item.name}")
            .setView(editorContent)
            .show()
    }

    /** Encodes and PUTs the new file content to GitHub. */
    private fun saveFileContent(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newContent: String, refreshPath: String
    ) {
        try {
            val encoded = android.util.Base64.encodeToString(
                newContent.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
            )
            val payload = org.json.JSONObject().apply {
                put("message", "edit: update ${item.path} via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, item.path), payload)
            if (code in 200..201) {
                activity.appendLog("✓ Saved: ${item.path}")
                activity.mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
            } else {
                activity.appendLog("✗ Save failed ($code): ${body.take(150)}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
            activity.mainHandler.post { activity.setBusy(false) }
        }
    }

    /** Fetches a file's content from GitHub and copies it to the clipboard. */
    private fun fetchAndCopyFile(token: String, owner: String, repo: String, item: RepoItem) {
        activity.setBusy(true)
        activity.appendLog("Fetching ${item.name} for copy …")
        activity.bgExecutor.execute {
            try {
                val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
                if (code != 200) throw Exception("HTTP $code")
                val raw = org.json.JSONObject(body).optString("content", "")
                    .replace("\n", "").replace("\r", "")
                val bytes = android.util.Base64.decode(raw, android.util.Base64.DEFAULT)
                val text  = String(bytes, Charsets.UTF_8)
                activity.mainHandler.post {
                    activity.setBusy(false)
                    val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, text))
                    activity.appendLog("📋 Copied ${item.name} to clipboard (${text.length} chars).")
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }


    /** Sub-menu: create a folder or a file. */
    private fun showNewItemDialog(token: String, owner: String, repo: String, branch: String, currentPath: String) {
        val newItemRows = listOf(
            IconMenuRow("New Folder",  R.drawable.ic_folder, 0xFFFF9F43.toInt()),
            IconMenuRow("New File",    R.drawable.ic_file,   0xFF2ECC71.toInt()),
            IconMenuRow("Upload File", R.drawable.ic_upload, 0xFF4DA6FF.toInt())
        )
        AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("Create New…")
            .setAdapter(IconMenuAdapter(activity, newItemRows)) { _, which ->
                when (which) {
                    0 -> promptCreateFolder(token, owner, repo, branch, currentPath)
                    1 -> promptCreateFile(token, owner, repo, branch, currentPath)
                    2 -> {
                        // Store context so the activity-result callback knows where to upload
                        activity.pendingUploadToken  = token
                        activity.pendingUploadOwner  = owner
                        activity.pendingUploadRepo   = repo
                        activity.pendingUploadBranch = branch
                        activity.pendingUploadPath   = currentPath
                        activity.pickUploadFile.launch(arrayOf("*/*"))
                    }
                }
            }
            .show()
    }

    private fun promptCreateFolder(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val input = EditText(activity).apply {
            hint = "folder-name"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        lateinit var dlg: AlertDialog
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("A .gitkeep file will be placed inside\n(GitHub doesn't allow empty folders)."))
            addView(input)
        }
        val content = activity.dialogWithActions(
            body,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    activity.appendLog("⚠ Folder name cannot be empty.")
                } else {
                    dlg.dismiss()
                    val filePath = if (parentPath.isEmpty()) "$name/.gitkeep" else "$parentPath/$name/.gitkeep"
                    activity.setBusy(true)
                    activity.bgExecutor.execute { createRepoFile(token, owner, repo, branch, filePath, "", parentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📁 New Folder")
            .setView(content)
            .show()
    }

    private fun promptCreateFile(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 16, 64, 8)
        }
        val etName = EditText(activity).apply {
            hint = "filename.txt"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val etContent = EditText(activity).apply {
            hint = "File content (optional)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        container.addView(etName)
        container.addView(etContent)

        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            container,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                val name    = etName.text.toString().trim()
                val fileContent = etContent.text.toString()
                if (name.isEmpty()) {
                    activity.appendLog("⚠ File name cannot be empty.")
                } else {
                    dlg.dismiss()
                    val filePath = if (parentPath.isEmpty()) name else "$parentPath/$name"
                    activity.setBusy(true)
                    activity.bgExecutor.execute { createRepoFile(token, owner, repo, branch, filePath, fileContent, parentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📄 New File")
            .setView(content)
            .show()
    }

    private fun createRepoFile(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, content: String, refreshPath: String
    ) {
        try {
            val encoded = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val payload = JSONObject().apply {
                put("message", "chore: create $filePath via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("branch",  branch)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, filePath), payload)
            if (code in 200..201) {
                activity.appendLog("✓ Created: $filePath")
                activity.mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
            } else {
                activity.appendLog("✗ Create failed ($code): ${body.take(150)}")
                activity.setBusy(false)
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
            activity.setBusy(false)
        }
    }

    // ── Upload local file to repo ─────────────────────────────────────────────

    /**
     * Reads [uri] from the device, base-64 encodes it, and PUTs it to GitHub.
     * Binary files (images, zips, APKs…) are handled the same way as text — the
     * GitHub Contents API accepts any base-64 payload regardless of MIME type.
     * Files > ~50 MB will be rejected by the API; we warn early.
     */
    fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String
    ) {
        try {
            val bytes = UriUtils.openInputStreamOrThrow(activity.contentResolver, uri).use { it.readBytes() }
            if (bytes.size > 50 * 1024 * 1024) {
                activity.appendLog("✗ File too large for GitHub Contents API (> 50 MB)."); return
            }
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            activity.appendLog("  Size: ${bytes.size / 1024} KB")

            val existingSha = activity.buildFlowController.fetchFileSha(token, owner, repo, filePath)
            val payload = JSONObject().apply {
                put("message", "upload: $filePath via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("branch",  branch)
                if (existingSha != null) put("sha", existingSha)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, filePath), payload)
            if (code in 200..201) {
                activity.appendLog("✓ Uploaded: $filePath")
            } else {
                activity.appendLog("✗ Upload failed ($code): ${body.take(200)}")
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
        }
    }

    // ── Create repo from file manager ────────────────────────────────────────

    /**
     * Shows a dialog to create a brand-new GitHub repo without starting a build.
     * Resolves the owner from the token first (cached in [activity.lastOwner]).
     */
    private fun promptCreateRepo(token: String) {
        val input = EditText(activity).apply {
            hint = "my-new-repo"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        lateinit var dlg: AlertDialog
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("Enter a name for the new GitHub repo.\n⚠ Spaces will be replaced with hyphens."))
            addView(input)
        }
        val content = activity.dialogWithActions(
            body,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                // Sanitize: trim, replace spaces/invalid chars with hyphens, collapse runs
                val rawName = input.text.toString().trim()
                val repoName = rawName
                    .replace(Regex("[^A-Za-z0-9._-]"), "-")  // only letters/digits/./−/_ allowed
                    .replace(Regex("-{2,}"), "-")             // collapse consecutive hyphens
                    .trim('-')                                 // strip leading/trailing hyphens
                when {
                    rawName.isEmpty() -> activity.appendLog("⚠ Repo name cannot be empty.")
                    repoName.isEmpty() -> activity.appendLog("⚠ Repo name invalid after sanitisation.")
                    else -> {
                        if (repoName != rawName) activity.appendLog("ℹ Repo name adjusted to: $repoName")
                        dlg.dismiss()
                        activity.setBusy(true)
                        activity.appendLog("Creating repo: $repoName …")
                        activity.bgExecutor.execute {
                            try {
                                val owner = if (activity.lastOwner.isNotEmpty()) activity.lastOwner else {
                                    val o = activity.buildFlowController.fetchOwner(token) ?: throw Exception("Could not verify token.")
                                    activity.lastOwner = o
                                    activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$o / $repoName"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }
                                    o
                                }
                                val reqBody = JSONObject().apply {
                                    put("name",        repoName)
                                    put("private",     false)
                                    put("auto_init",   true)
                                    put("description", "Repo created via ZipApkBuilder")
                                }.toString()
                                val (code, resp) = GitHubApi.httpPost(token, "https://api.github.com/user/repos", reqBody)
                                if (code !in 200..201) {
                                    activity.appendLog("✗ Create repo failed ($code): ${resp.take(200)}")
                                    activity.setBusy(false); return@execute
                                }
                                activity.appendLog("✓ Repo created: github.com/$owner/$repoName")

                                // Auto-fill the repo field
                                activity.mainHandler.post {
                                    activity.etRepo.setText(repoName)
                                    activity.prefs.edit().putString(PrefKeys.PREF_REPO, repoName).apply()
                                }

                                // Poll until GitHub has initialised the repo (up to ~20 s)
                                val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }
                                activity.appendLog("Waiting for GitHub to initialise repo…")
                                var ready = false
                                for (attempt in 1..10) {
                                    Thread.sleep(2_000)
                                    val (chk, _) = GitHubApi.httpGet(token, "https://api.github.com/repos/$owner/$repoName")
                                    if (chk == 200) { ready = true; break }
                                }
                                if (!ready) {
                                    activity.appendLog("⚠ Repo created but not yet reachable — open file manager manually.")
                                    activity.setBusy(false); return@execute
                                }
                                activity.appendLog("Repo ready ✓")
                                activity.mainHandler.post { fetchAndBrowse(token, owner, repoName, branch, "") }
                            } catch (e: Exception) {
                                activity.appendLog("✗ ${e.message}")
                                activity.setBusy(false)
                            }
                        }
                    }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("🆕 Create Repository")
            .setView(content)
            .show()
    }

    /** Multi-select delete dialog. `setMultiChoiceItems` can't be combined with a custom
     *  `setView()` body, so this outer picker keeps the platform button bar (styleButton) —
     *  the nested confirm step below uses the newer dialogWithActions like everything else. */
    private fun showDeleteDialog(
        token: String, owner: String, repo: String, branch: String,
        currentPath: String, items: List<RepoItem>
    ) {
        val names   = items.map { if (it.type == "dir") "📁  ${it.name}" else "📄  ${it.name}" }.toTypedArray()
        val checked = BooleanArray(items.size)
        val listDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("🗑️  Select to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = items.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { activity.appendLog("Nothing selected."); return@setPositiveButton }
                val hasFolders = toDelete.any { it.type == "dir" }
                val list = toDelete.joinToString("\n• ", prefix = "• ") {
                    "${if (it.type == "dir") "📁" else "📄"} ${it.name}"
                }
                val warning = if (hasFolders) "\n\n⚠ Folders will be deleted recursively." else ""
                lateinit var confirmDlg: AlertDialog
                val confirmContent = activity.dialogWithActions(
                    activity.dialogMessage("Delete ${toDelete.size} item(s)?$warning\n\n$list"),
                    DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                        confirmDlg.dismiss()
                        activity.setBusy(true)
                        activity.bgExecutor.execute { deleteItemsRecursive(token, owner, repo, branch, toDelete, currentPath) }
                    },
                    DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { confirmDlg.dismiss() }
                )
                confirmDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                    .setTitle("Confirm Deletion").setView(confirmContent).show()
            }
            .setNegativeButton("Cancel", null).show()
        listDlg.styleButton(activity, AlertDialog.BUTTON_POSITIVE, ButtonTone.RED, R.drawable.ic_delete)
        listDlg.styleButton(activity, AlertDialog.BUTTON_NEGATIVE, ButtonTone.SURFACE, R.drawable.ic_close)
    }

    private fun deleteItemsRecursive(
        token: String, owner: String, repo: String, branch: String,
        items: List<RepoItem>, refreshPath: String
    ) {
        // Each item is attempted independently — one folder failing to list (or any
        // other error) used to abort the whole batch via a shared try/catch, silently
        // skipping every remaining selected item with no indication of what happened.
        var failed = 0
        for (item in items) {
            try {
                if (item.type == "file") {
                    deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                } else {
                    deleteFolderRecursive(token, owner, repo, branch, item.path)
                }
            } catch (e: Exception) {
                failed++
                activity.appendLog("✗ ${item.name}: ${e.message}")
            }
        }
        if (items.size > 1) {
            val ok = items.size - failed
            activity.appendLog(if (failed == 0) "✓ Deleted all $ok item(s)." else "⚠ Deleted $ok item(s), $failed failed.")
        }
        activity.mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
    }

    /** Recursively lists and deletes every file inside a folder. */
    private fun deleteFolderRecursive(token: String, owner: String, repo: String, branch: String, path: String) {
        activity.appendLog("📁 Deleting folder: $path …")
        val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, path))
        if (code == 404) { activity.appendLog("  (already gone)"); return }
        if (code != 200) throw Exception("HTTP $code listing $path")
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val obj  = arr.getJSONObject(i)
            val type = obj.getString("type")
            val childPath = obj.getString("path")
            val childSha  = obj.optString("sha", "")
            val childName = obj.getString("name")
            if (type == "dir") deleteFolderRecursive(token, owner, repo, branch, childPath)
            else deleteRepoFile(token, owner, repo, branch, childPath, childSha, childName)
        }
    }

    private fun deleteRepoFile(
        token: String, owner: String, repo: String, branch: String,
        path: String, sha: String, name: String
    ) {
        val payload = JSONObject().apply {
            put("message", "chore: delete $path via ZipApkBuilder [skip ci]")
            put("sha",     sha)
            put("branch",  branch)
        }.toString()
        val (code, resp) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, path), payload)
        if (code in 200..204) {
            activity.appendLog("✓ Deleted: $name")
            if (path == activity.lastRemotePath) activity.lastFileSha = null
        } else {
            activity.appendLog("✗ Failed to delete $name ($code): ${resp.take(120)}")
        }
    }

    /**
     * Moves/renames a file by reading its content, creating it at [newPath],
     * then deleting the original. Refreshes the browser at [refreshPath] when done.
     */
    private fun moveRepoFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newPath: String, refreshPath: String
    ) {
        try {
            activity.appendLog("Moving ${item.name} → $newPath …")

            // 1. Read current file content (base64) from GitHub
            val (getCode, getBody) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
            if (getCode != 200) throw Exception("Could not read file ($getCode)")
            val encodedContent = JSONObject(getBody).getString("content")
                .replace("\n", "").replace("\r", "") // GitHub wraps base64 at 60 chars

            // 2. Create file at new path
            val createPayload = JSONObject().apply {
                put("message", "chore: move ${item.path} → $newPath via ZipApkBuilder [skip ci]")
                put("content", encodedContent)
                put("branch",  branch)
            }.toString()
            val (putCode, putBody) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, newPath), createPayload)
            if (putCode !in 200..201) throw Exception("Could not create at $newPath ($putCode): ${putBody.take(150)}")

            // 3. Delete original
            val deletePayload = JSONObject().apply {
                put("message", "chore: remove ${item.path} after move [skip ci]")
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (delCode, delBody) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, item.path), deletePayload)
            if (delCode !in 200..204) throw Exception("Moved but failed to delete original ($delCode): ${delBody.take(150)}")

            activity.appendLog("✓ Moved to: $newPath")
            if (item.path == activity.lastRemotePath) activity.lastRemotePath = newPath

            activity.mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
        } catch (e: Exception) {
            activity.appendLog("✗ Move failed: ${e.message}")
        } finally {
            activity.setBusy(false)
        }
    }

}
