package com.zipapkbuilder.core

import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import com.zipapkbuilder.R

/**
 * One design token per semantic action color, each pairing a filled/rippled
 * pill background with the text/icon color that reads correctly on it.
 * [PillButton] and [DialogButtonStyler] both build on this — it's what lets
 * every button in the app (dialog button-bar buttons, chips, small action
 * buttons) share one consistent, rounded, rippled look instead of each call
 * site picking its own flat color and corner radius.
 *
 * Semantic convention used app-wide (documented here since it's easy for the
 * mapping to drift otherwise):
 *  - [GREEN]   creation / success / positive  — New, Create, Resume, Download
 *  - [TEAL]    primary confirm                — Save, Move, Go
 *  - [ORANGE]  trigger / build                — Trigger workflow
 *  - [RED]     destructive                    — Delete, Cancel (download), Remove
 *  - [BLUE]    informational / view            — View/Edit, Copy, Pause, View Log
 *  - [PURPLE]  secondary accent                — reserved for special emphasis
 *  - [SURFACE] neutral / dismiss               — Cancel, Close, Up, Switch, Refresh
 *  - [PRIMARY] app-brand default               — reserved for a dialog's main CTA
 */
enum class ButtonTone(@DrawableRes val background: Int, @ColorRes val textColor: Int) {
    PRIMARY(R.drawable.bg_btn_primary_ripple, R.color.text_on_color),
    TEAL(R.drawable.bg_btn_teal_ripple, R.color.text_on_color),
    PURPLE(R.drawable.bg_btn_purple_ripple, R.color.text_on_color),
    GREEN(R.drawable.bg_btn_green_ripple, R.color.text_on_color),
    ORANGE(R.drawable.bg_btn_orange_ripple, R.color.text_on_color),
    RED(R.drawable.bg_btn_red_ripple, R.color.text_on_color),
    BLUE(R.drawable.bg_btn_blue_ripple, R.color.text_on_color),
    SURFACE(R.drawable.bg_btn_surface_ripple, R.color.text_primary),
}
