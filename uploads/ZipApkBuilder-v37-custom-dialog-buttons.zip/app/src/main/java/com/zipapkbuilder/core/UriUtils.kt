package com.zipapkbuilder.core

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import java.io.InputStream
import java.io.OutputStream

/**
 * Shared `ContentResolver`/`Uri` helpers. [openInputStreamOrThrow] and
 * [openOutputStreamOrThrow] are used anywhere a user- or system-picked `Uri`
 * needs to be read or written (project zip selection, repo file uploads,
 * saving a downloaded artifact); [resolveZipFileName] and
 * [resolveUploadFileName] both look up a picked document's display name via
 * the same `OpenableColumns.DISPLAY_NAME` query, then diverge on how the name
 * gets sanitized for their respective use.
 */
object UriUtils {

    /**
     * Opens [uri] for reading, or throws a clear message instead of letting a
     * bare `!!` produce a generic NullPointerException.
     * `ContentResolver.openInputStream()` returns null (rather than throwing)
     * when the underlying document provider can no longer serve the URI —
     * e.g. the picked file was moved, deleted, or its access grant was
     * revoked since selection — which is common enough for a user-picked
     * file that it deserves its own message.
     */
    fun openInputStreamOrThrow(resolver: ContentResolver, uri: Uri): InputStream =
        resolver.openInputStream(uri)
            ?: throw Exception("Could not open the selected file — it may have been moved, deleted, or its access permission revoked. Please pick it again.")

    /** Output-stream counterpart of [openInputStreamOrThrow], for the same reason. */
    fun openOutputStreamOrThrow(resolver: ContentResolver, uri: Uri): OutputStream =
        resolver.openOutputStream(uri)
            ?: throw Exception("Could not open the destination for writing — the storage location may be unavailable.")

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        var name: String? = null
        resolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        return name
    }

    /** Resolves a picked project archive's display name, forcing a `.zip` extension. */
    fun resolveZipFileName(resolver: ContentResolver, uri: Uri): String {
        var name = queryDisplayName(resolver, uri) ?: "project.zip"
        name = name.replace(Regex("[^a-zA-Z0-9._ \\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    /** Like [resolveZipFileName] but keeps whatever extension the file already has — used for
     *  repo uploads where .cs, .txt, .png etc. must stay as-is. */
    fun resolveUploadFileName(resolver: ContentResolver, uri: Uri): String {
        val name = queryDisplayName(resolver, uri) ?: "upload_${System.currentTimeMillis()}"
        return name.replace(Regex("[^a-zA-Z0-9._ \\-]"), "_")
    }
}
