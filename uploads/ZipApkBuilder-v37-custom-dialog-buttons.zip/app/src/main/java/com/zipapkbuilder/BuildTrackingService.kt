package com.zipapkbuilder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Keeps this app's process alive, via a low-priority ongoing notification,
 * while a build is in flight — so the polling already happening in
 * `MainActivity` (`waitForRun` / `streamBuildLog`, running on the shared
 * `bgExecutor`) isn't silently killed by Android's background process
 * management just because the user switched to another app during a long
 * build.
 *
 * Deliberately does **not** duplicate any of the actual build-polling logic:
 * that would mean maintaining a second copy of the GitHub API/parsing code
 * inside a Service, in direct conflict with "don't rewrite working systems."
 * Instead this is a thin foreground-service shell — `MainActivity` starts it
 * when a build begins, updates its notification text as the build moves
 * through phases (via [start], reused for updates), and stops it when the
 * build concludes, posting a separate, dismissible result notification via
 * [postResult]. The actual mechanism that keeps a build alive in the
 * background is simply that *a foreground service is running in this
 * process* — the elevated process priority that comes with it applies to the
 * whole process, including `MainActivity`'s already-running background
 * threads. The notification the user sees is the OS-mandated visible side
 * effect of that, not the point in itself.
 *
 * All companion functions are safe to call from any thread and swallow their
 * own failures (a rejected foreground-service start, a missing notification
 * permission, etc.) rather than throw, since build tracking is a layered-on
 * nice-to-have — the build itself must keep working with or without it.
 */
class BuildTrackingService : Service() {

    companion object {
        private const val CHANNEL_ID_ONGOING = "build_tracking"
        private const val CHANNEL_ID_RESULT  = "build_results"
        private const val NOTIF_ID_ONGOING   = 1001
        private const val NOTIF_ID_RESULT    = 1002
        private const val EXTRA_STATUS_TEXT  = "status_text"

        /**
         * Starts the ongoing build-tracking notification, or — if already
         * running — updates its text in place (posting to the same
         * notification ID replaces it rather than stacking a new one).
         * Call once per build phase change; cheap enough to call often.
         */
        fun start(context: Context, statusText: String) {
            ensureChannels(context)
            try {
                val intent = Intent(context, BuildTrackingService::class.java)
                    .putExtra(EXTRA_STATUS_TEXT, statusText)
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
                // Rare OS-level background-start restrictions can reject this;
                // the build keeps running via MainActivity's own threads regardless.
            }
        }

        /** Alias for [start] — same call, named for readability at update call sites. */
        fun updateStatus(context: Context, statusText: String) = start(context, statusText)

        /** Stops the ongoing tracking notification/service. Safe to call even if not running. */
        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, BuildTrackingService::class.java))
            } catch (_: Exception) {
                // Nothing meaningful to do if this fails — worst case the ongoing
                // notification lingers until the next build phase update replaces it.
            }
        }

        /**
         * Posts a standalone "build finished" notification — deliberately
         * independent of the service's own lifecycle, since it's posted as the
         * service stops and needs to stay visible afterward. Silently does
         * nothing if the app can't post notifications right now (permission
         * not granted, or the user disabled them), rather than risk a
         * `SecurityException` on API 33+.
         */
        fun postResult(context: Context, title: String, text: String) {
            ensureChannels(context)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
            ) return

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context, 1, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID_RESULT)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pending)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
            try {
                NotificationManagerCompat.from(context).notify(NOTIF_ID_RESULT, notification)
            } catch (_: SecurityException) {
                // Permission was revoked between the check above and this call — ignore.
            }
        }

        /** Creates both notification channels if they don't already exist. Idempotent. */
        private fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val mgr = context.getSystemService(NotificationManager::class.java) ?: return
            if (mgr.getNotificationChannel(CHANNEL_ID_ONGOING) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID_ONGOING, "Build tracking", NotificationManager.IMPORTANCE_LOW).apply {
                        description = "An ongoing notification shown while a build is running, " +
                            "so you can leave the app and still be notified when it finishes."
                        setShowBadge(false)
                    }
                )
            }
            if (mgr.getNotificationChannel(CHANNEL_ID_RESULT) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID_RESULT, "Build results", NotificationManager.IMPORTANCE_DEFAULT).apply {
                        description = "Notifies you when a build succeeds, fails, or is cancelled."
                    }
                )
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val statusText = intent?.getStringExtra(EXTRA_STATUS_TEXT) ?: "Building…"
        val notification = buildNotification(statusText)
        // startForeground() must be called within seconds of the service starting
        // (an OS-enforced limit) — done here synchronously and first, before any
        // other work, so that's never at risk regardless of what triggered this call.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID_ONGOING, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID_ONGOING, notification)
        }
        // Deliberately not "sticky": if the OS kills this process, the build flow
        // it was tracking is gone too, so there'd be nothing for a resurrected
        // empty service to meaningfully track.
        return START_NOT_STICKY
    }

    private fun buildNotification(statusText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID_ONGOING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("ZipApkBuilder")
            .setContentText(statusText)
            .setOngoing(true)
            .setOnlyAlertOnce(true) // update in place silently; don't re-alert per phase change
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pending)
            .build()
    }
}
