package com.zipapkbuilder.core

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts the GitHub Personal Access Token before it's written to
 * SharedPreferences, instead of storing it as plain text on disk.
 *
 * Uses an AES-256/GCM key that lives only inside the Android Keystore
 * (hardware-backed where the device supports it) — the raw key material
 * never leaves the secure element, and never enters the app's process.
 */
internal object TokenCrypto {
    private const val KEYSTORE_ALIAS  = "zipapk_pat_key"
    private const val TRANSFORMATION  = "AES/GCM/NoPadding"
    private const val GCM_TAG_LEN_BITS = 128
    private const val GCM_IV_LEN_BYTES = 12
    private const val MAGIC = "ENC1:" // marks values written by this encryptor

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        keyGen.init(
            KeyGenParameterSpec.Builder(
                KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return keyGen.generateKey()
    }

    /** Encrypts [plain] into a value that's safe to persist in SharedPreferences. */
    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            }
            val combined = cipher.iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            MAGIC + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            plain // fail open rather than silently losing the token
        }
    }

    /**
     * Decrypts a value previously produced by [encrypt]. Values saved by an
     * older version of the app (before encryption was added) won't have the
     * [MAGIC] prefix — those are returned as-is so existing users don't get
     * logged out; they'll be re-saved in encrypted form the next time the
     * token is written.
     */
    fun decrypt(stored: String): String {
        if (stored.isEmpty()) return ""
        if (!stored.startsWith(MAGIC)) return stored // legacy plaintext value
        return try {
            val combined   = Base64.decode(stored.removePrefix(MAGIC), Base64.NO_WRAP)
            val iv         = combined.copyOfRange(0, GCM_IV_LEN_BYTES)
            val cipherText = combined.copyOfRange(GCM_IV_LEN_BYTES, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_LEN_BITS, iv))
            }
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (e: Exception) {
            "" // key invalidated or data corrupted — caller should prompt re-entry
        }
    }
}
