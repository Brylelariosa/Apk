package com.zipapkbuilder.core

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Small, stateless formatting helpers shared by every feature — human-readable
 * byte counts/durations, a friendlier spin on common network exceptions, and
 * GitHub's `created_at`-style timestamp parsing. Kept as pure functions with no
 * Activity/Context dependency so any feature controller can call them directly.
 */
object Formatters {

    fun fmtBytes(b: Long) = when {
        b < 1024L               -> "${b} B"
        b < 1024L * 1024        -> "${"%.1f".format(b / 1024.0)} KB"
        b < 1024L * 1024 * 1024 -> "${"%.1f".format(b / (1024.0 * 1024))} MB"
        else                    -> "${"%.2f".format(b / (1024.0 * 1024 * 1024))} GB"
    }

    fun fmtDuration(ms: Long): String {
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return if (m > 0) "${m}m ${s}s" else "${s}s"
    }

    /**
     * Maps common low-level exception types to a short, human hint appended after
     * the raw message — "No internet connection" reads better than a bare
     * UnknownHostException, especially since spotty mobile data is the single
     * most common reason this app's network calls fail.
     */
    fun friendlyError(e: Exception): String {
        val hint = when (e) {
            is java.net.UnknownHostException -> "No internet connection."
            is java.net.SocketTimeoutException -> "Request timed out — check your connection."
            is javax.net.ssl.SSLException -> "Secure connection failed — check your connection or device date/time."
            is java.net.ConnectException -> "Could not reach GitHub — check your connection."
            else -> null
        }
        val msg = e.message ?: e.javaClass.simpleName
        return if (hint != null) "$msg ($hint)" else msg
    }

    fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
