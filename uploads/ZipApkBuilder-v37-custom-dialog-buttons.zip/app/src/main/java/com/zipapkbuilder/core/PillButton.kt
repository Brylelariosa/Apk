package com.zipapkbuilder.core

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/**
 * Builds a small filled, rounded, rippled action label — the one shared look
 * behind every standalone (non-dialog-button-bar) clickable chip/button in
 * the app: the file browser's Switch/Trigger chips, the download manager's
 * Pause/Resume/Cancel/Retry/Remove row, the build log's status filter chips,
 * and the "Clear finished" link.
 *
 * These used to be five near-identical local closures (`actionChip`, `chip`,
 * `smallBtn`, `filterChip`, ...), each hand-rolling its own flat
 * `setBackgroundColor` rectangle with square corners, no ripple, and a
 * different padding scale from its neighbors. This is the one implementation
 * they should all share instead.
 */
fun Context.pillButton(
    label: String,
    tone: ButtonTone,
    @DrawableRes iconRes: Int? = null,
    textSizeSp: Float = 11.5f,
    iconSizeDp: Int = 14,
    horizontalPaddingDp: Int = 12,
    verticalPaddingDp: Int = 7,
    onClick: (() -> Unit)? = null
): TextView {
    val dp = resources.displayMetrics.density
    val textColor = ContextCompat.getColor(this, tone.textColor)
    return TextView(this).apply {
        text = label
        textSize = textSizeSp
        setTextColor(textColor)
        setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        background = ContextCompat.getDrawable(this@pillButton, tone.background)
        setPadding(
            (horizontalPaddingDp * dp).toInt(), (verticalPaddingDp * dp).toInt(),
            (horizontalPaddingDp * dp).toInt(), (verticalPaddingDp * dp).toInt()
        )
        if (iconRes != null) setStartIcon(this@pillButton, iconRes, textColor, sizeDp = iconSizeDp)
        isClickable = onClick != null
        isFocusable = onClick != null
        if (onClick != null) setOnClickListener { onClick() }
    }
}

/**
 * A compact, circular, ripple-backed icon-only button — used for the
 * find-in-file/find-in-log navigation controls (previous match, next match,
 * go to line) that used to be bare "◀"/"▶"/"#️⃣" glyphs on a plain TextView
 * with no background and no touch feedback at all.
 */
fun Context.iconButton(
    @DrawableRes iconRes: Int,
    @ColorInt tint: Int,
    sizeDp: Int = 18,
    paddingDp: Int = 8,
    onClick: (() -> Unit)? = null
): ImageView {
    val dp = resources.displayMetrics.density
    val pad = (paddingDp * dp).toInt()
    return ImageView(this).apply {
        setImageResource(iconRes)
        imageTintList = ColorStateList.valueOf(tint)
        background = ContextCompat.getDrawable(this@iconButton, R.drawable.bg_icon_btn_ripple)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(pad, pad, pad, pad)
        layoutParams = LinearLayout.LayoutParams((sizeDp * dp).toInt() + pad * 2, (sizeDp * dp).toInt() + pad * 2)
        isClickable = onClick != null
        isFocusable = onClick != null
        if (onClick != null) setOnClickListener { onClick() }
    }
}
