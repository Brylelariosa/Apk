package com.zipapkbuilder.core

import android.content.Context
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.graphics.drawable.DrawableCompat

/**
 * Sets a tinted vector icon at the start of this label's text.
 *
 * Receiver is [TextView] rather than [Button] so the same helper covers both real dialog
 * buttons (a [Button] IS-A [TextView]) and the app's clickable "chip" labels (plain [TextView]s
 * with a colored background, e.g. the Switch/Trigger chips) — one implementation, no duplicated
 * drawable/tint boilerplate per call site.
 *
 * Used in place of the old convention of prefixing labels with an emoji glyph (e.g. "🗑 Delete",
 * "🔀 Switch"). Emoji glyph support varies by device/system font, so unsupported ones can fall
 * back to a generic "tofu" box instead of the intended symbol. A real vector drawable always
 * renders the same everywhere and matches the app's own icon set and color system.
 *
 * @param iconRes drawable to show, tinted to a flat, single color.
 * @param tint icon color; pass the same color used for the label's text for a cohesive look.
 * @param sizeDp rendered icon size in dp, independent of the source drawable's own intrinsic
 *   size — lets one icon set be reused at different scales (small chips vs. dialog buttons).
 * @param paddingDp gap between the icon and the text, in dp.
 */
fun TextView.setStartIcon(
    context: Context,
    @DrawableRes iconRes: Int,
    @ColorInt tint: Int,
    sizeDp: Int = 16,
    paddingDp: Int = 6
) {
    val icon = AppCompatResources.getDrawable(context, iconRes)?.mutate() ?: return
    DrawableCompat.setTint(icon, tint)
    val sizePx = (sizeDp * context.resources.displayMetrics.density).toInt()
    icon.setBounds(0, 0, sizePx, sizePx)
    setCompoundDrawablesRelative(icon, null, null, null)
    compoundDrawablePadding = (paddingDp * context.resources.displayMetrics.density).toInt()
}
