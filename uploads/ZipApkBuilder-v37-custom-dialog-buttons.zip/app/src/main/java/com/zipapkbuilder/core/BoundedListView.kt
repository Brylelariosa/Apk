package com.zipapkbuilder.core

import android.content.Context
import android.view.View
import android.widget.ListView

/**
 * A [ListView] that behaves like `wrap_content` up to [maxHeightPx], then scrolls.
 * A plain `ListView` placed inside a non-scrolling parent (like the `LinearLayout`
 * [dialogWithActions] builds) only measures tall enough for one row unless its height
 * is bounded like this — it's what lets a custom dialog body host a real scrolling list
 * the same way `AlertDialog.Builder.setAdapter(...)`'s own built-in list did.
 */
class BoundedListView(context: Context, private val maxHeightPx: Int) : ListView(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val bounded = View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, bounded)
    }
}
