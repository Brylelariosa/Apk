package com.zipapkbuilder.core

import android.app.AlertDialog
import android.content.Context
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat

/**
 * Styles one of an already-shown [AlertDialog]'s built-in button-bar buttons
 * (`BUTTON_POSITIVE` / `BUTTON_NEUTRAL` / `BUTTON_NEGATIVE`) with a filled,
 * rounded, rippled [tone] background, a matching vector [iconRes], and
 * spacing from its neighbors — call it right after `.show()`.
 *
 * Why this has to happen in code rather than the dialog theme: `Theme.App.Dialog`
 * declares `buttonBarPositiveButtonStyle`/`buttonBarNegativeButtonStyle`/
 * `buttonBarNeutralButtonStyle`, but those attrs are only honored by
 * androidx.appcompat's own `AlertDialog` implementation. Every dialog in this
 * app is built with the platform `android.app.AlertDialog` (see the import at
 * the top of every caller), which silently ignores them — so unless a button
 * is explicitly styled like this, it falls back to the platform's bare
 * default look (flat, no fill, no icon), which is why only the handful of
 * dialogs that already called this pattern manually looked right.
 *
 * Sizing here is deliberately tight: the platform's button-bar container
 * (`ButtonBarLayout`) silently switches from a horizontal row to one giant
 * full-width button per line the moment the row doesn't fit — so a 3-button
 * dialog with generous padding can flip from three small pills into three
 * huge stacked bars with no warning. Small icon, small text, small padding
 * keeps every realistic 2–3-button combo on one row.
 */
fun AlertDialog.styleButton(
    context: Context,
    which: Int,
    tone: ButtonTone,
    @DrawableRes iconRes: Int,
    iconSizeDp: Int = 12
) {
    val button = getButton(which) ?: return
    val dp = context.resources.displayMetrics.density
    val textColor = ContextCompat.getColor(context, tone.textColor)

    button.textSize = 11.5f
    button.setTextColor(textColor)
    button.setStartIcon(context, iconRes, textColor, sizeDp = iconSizeDp, paddingDp = 4)
    button.background = ContextCompat.getDrawable(context, tone.background)
    button.setPadding((9 * dp).toInt(), (5 * dp).toInt(), (9 * dp).toInt(), (5 * dp).toInt())
    button.minWidth = 0
    button.minimumWidth = 0

    // Best-effort spacing between adjacent pill buttons in the bar — safe to
    // skip if the platform ever hands back a different LayoutParams type.
    (button.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
        lp.marginStart = (3 * dp).toInt()
        lp.marginEnd = (3 * dp).toInt()
        lp.topMargin = (3 * dp).toInt()
        lp.bottomMargin = (3 * dp).toInt()
        button.layoutParams = lp
    }
}
