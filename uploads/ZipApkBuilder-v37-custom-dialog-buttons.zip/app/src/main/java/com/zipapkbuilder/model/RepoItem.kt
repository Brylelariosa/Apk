package com.zipapkbuilder.model

/** Represents one entry returned by the GitHub Contents API. */
data class RepoItem(val type: String, val name: String, val path: String, val sha: String, val size: Long = 0L)
