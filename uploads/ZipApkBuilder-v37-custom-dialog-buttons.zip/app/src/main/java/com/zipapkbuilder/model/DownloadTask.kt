package com.zipapkbuilder.model

import java.io.File

/**
 * One download the Download Manager knows about — everything the manager UI
 * needs to render a row and everything the download engine needs to run it,
 * bundled together so multiple downloads can each have their own independent
 * pause/cancel/progress state instead of sharing one set of flags (only one
 * download could be tracked at a time before this existed). Every field is
 * `@Volatile`: written from whichever download-worker thread is running this
 * task, read from the main thread by the Download Manager dialog's periodic
 * refresh — `@Volatile` is sufficient for that single-writer/single-reader-role
 * pattern without needing a lock.
 *
 * [resolveUrl] is a lambda rather than a fixed URL because GitHub's
 * artifact/log redirect URLs are short-lived signed links, so it needs to be
 * re-resolved on every connection attempt, not just once when the task is
 * created.
 *
 * [onSuccess] runs on the download-worker thread once the raw transfer and
 * integrity check both succeed — this is where the "save to Downloads, log
 * the result" logic for each of the two download kinds (artifact ZIP,
 * build-log ZIP) plugs in.
 */
class DownloadTask(
    val id: String,
    val displayName: String,
    val destFile: File,
    val resolveUrl: () -> String,
    val onSuccess: (DownloadTask) -> Unit
) {
    enum class Status { QUEUED, CONNECTING, DOWNLOADING, PAUSED, RETRYING, WAITING_FOR_NETWORK, VERIFYING, SAVING, COMPLETED, FAILED, CANCELLED }

    @Volatile var status: Status = Status.QUEUED
    @Volatile var downloadedBytes: Long = 0L
    @Volatile var totalBytes: Long = -1L
    @Volatile var speedBps: Long = 0L
    @Volatile var etaSeconds: Long = -1L
    @Volatile var detailText: String = "Queued…"
    @Volatile var errorMessage: String? = null
    @Volatile var savedPath: String? = null
    val createdAtMs: Long = System.currentTimeMillis()

    // Read by the download engine's loop; set by the manager UI's
    // per-row Pause/Resume/Cancel buttons.
    @Volatile var pauseRequested: Boolean = false
    @Volatile var cancelRequested: Boolean = false

    val isTerminal: Boolean
        get() = status == Status.COMPLETED || status == Status.FAILED || status == Status.CANCELLED
}
