package com.zipapkbuilder.core

import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/** One row in an [IconMenuAdapter] — an icon-led, optionally two-line, tappable menu item. */
data class IconMenuRow(
    val label: String,
    @DrawableRes val iconRes: Int,
    @ColorInt val iconTint: Int? = null,
    val subtitle: String? = null,
    @ColorInt val labelColor: Int? = null
)

/**
 * Renders a list of [IconMenuRow] as consistent, rippled, icon-led rows —
 * the shared look behind every "pick an action" or "pick an item" dialog
 * list in the app: the file action menu (View/Edit, Copy content,
 * Move/Rename, Delete), the "Create New…" menu (New Folder, New File,
 * Upload File), and the Switch Repository picker.
 *
 * Replaces plain `.setItems(arrayOf("👁  View / Edit", …))` calls — whose
 * rows are unstyled system list items with an emoji prefix, no ripple, and
 * no visual relationship to the rest of the app — and RepoSwitcher's
 * one-off bespoke `ArrayAdapter`, with a single adapter used everywhere via
 * `.setAdapter(IconMenuAdapter(context, rows), listener)`.
 */
class IconMenuAdapter(
    private val context: Context,
    private val rows: List<IconMenuRow>
) : BaseAdapter() {

    override fun getCount() = rows.size
    override fun getItem(position: Int): IconMenuRow = rows[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val dp = context.resources.displayMetrics.density
        val row = rows[position]
        val defaultLabelColor = ContextCompat.getColor(context, R.color.text_primary)
        val defaultIconTint = ContextCompat.getColor(context, R.color.primary_light)

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ContextCompat.getDrawable(context, R.drawable.bg_file_item_ripple)
            setPadding((16 * dp).toInt(), (13 * dp).toInt(), (16 * dp).toInt(), (13 * dp).toInt())
        }
        container.addView(ImageView(context).apply {
            setImageResource(row.iconRes)
            imageTintList = ColorStateList.valueOf(row.iconTint ?: defaultIconTint)
            layoutParams = LinearLayout.LayoutParams((20 * dp).toInt(), (20 * dp).toInt()).also {
                it.marginEnd = (14 * dp).toInt()
            }
        })
        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textCol.addView(TextView(context).apply {
            text = row.label
            textSize = 14f
            setTextColor(row.labelColor ?: defaultLabelColor)
        })
        if (row.subtitle != null) {
            textCol.addView(TextView(context).apply {
                text = row.subtitle
                textSize = 11f
                setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
            })
        }
        container.addView(textCol)
        return container
    }
}
