package com.zipapkbuilder.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Shared network-reliability policy for anything that talks to GitHub over a
 * possibly-flaky mobile connection: [performResumableDownload]-style downloads
 * and the upload-retry path both need the exact same "is this a genuine
 * connectivity outage (pause + auto-resume) or a transient server error
 * (bounded retry with backoff) or something fatal (give up immediately)"
 * policy, so it lives in one place instead of two copies.
 *
 * One instance is owned by the Activity for its whole lifetime; [unregisterActiveCallback]
 * must be called from `onDestroy` in case a [waitForNetwork] call is still
 * registered when the Activity is destroyed.
 */
class NetworkReliability(private val context: Context) {

    companion object {
        // ── Resumable download / upload-retry policy ───────────────────────
        // How many times a download or upload retries a *server-side* failure
        // (HTTP 429/5xx, or an I/O error that occurs while the network still
        // tests as available) before giving up and surfacing a manual Retry
        // button. A connectivity outage (device genuinely offline) never
        // counts against this — that's an automatic-resume wait, not a failure.
        const val MAX_DOWNLOAD_RETRIES     = 5
        const val INITIAL_RETRY_BACKOFF_MS = 2_000L
        const val MAX_RETRY_BACKOFF_MS     = 30_000L

        // HTTP statuses worth an automatic retry: rate-limited or a transient
        // server-side/edge problem. Anything else (401/403/404/410…) is treated
        // as fatal immediately — no retry count fixes an expired token or an
        // artifact that's actually gone.
        val RETRYABLE_HTTP_CODES = setOf(429, 500, 502, 503, 504)
    }

    /**
     * Tracks the currently-registered network callback (if any) from
     * [waitForNetwork], so the Activity can defensively unregister it in
     * `onDestroy` — e.g. if the Activity is destroyed while a download is
     * paused waiting out a connectivity outage.
     */
    private var activeNetworkCallback: ConnectivityManager.NetworkCallback? = null

    private val connectivityManager: ConnectivityManager?
        get() = context.getSystemService(ConnectivityManager::class.java)

    /**
     * Recognizes an `"... (503)"`-style HTTP status embedded in a thrown
     * exception's message as one of [RETRYABLE_HTTP_CODES], without needing
     * every call site to return a structured error type.
     */
    fun retryableHttpCodeIn(message: String?): Int? {
        val code = message?.let { Regex("""\((\d{3})\)""").find(it)?.groupValues?.get(1)?.toIntOrNull() }
        return code?.takeIf { it in RETRYABLE_HTTP_CODES }
    }

    /**
     * Sleeps up to [ms] in short slices, waking early as soon as [isCancelled]
     * turns true. No default: with per-task download state there's no single
     * shared "the current operation was cancelled" flag to fall back to, so
     * every call site names its own — a task's `{ task.cancelRequested }`, or
     * uploads' `{ uploadCancelled }`.
     */
    fun sleepCancellable(ms: Long, isCancelled: () -> Boolean) {
        val deadline = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < deadline) {
            if (isCancelled()) return
            Thread.sleep(200L.coerceAtMost((deadline - System.currentTimeMillis()).coerceAtLeast(1)))
        }
    }

    /**
     * True if the device currently has a network with working internet
     * access. Requires ACCESS_NETWORK_STATE (declared in the manifest).
     */
    fun isNetworkAvailable(): Boolean {
        val cm = connectivityManager ?: return true // can't check — don't block a download on a guess
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Blocks the calling background thread until the device regains network
     * connectivity, or [isCancelled] becomes true — whichever comes first.
     * Registers one [ConnectivityManager.NetworkCallback] (tracked in
     * [activeNetworkCallback] so `onDestroy` can defensively unregister it
     * too) and always unregisters it before returning. Returns false only on
     * cancellation. No default — see [sleepCancellable] for why; each
     * download task and the upload-retry path each name their own flag.
     */
    fun waitForNetwork(isCancelled: () -> Boolean): Boolean {
        val cm = connectivityManager ?: return true
        val latch = CountDownLatch(1)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { latch.countDown() }
        }
        activeNetworkCallback = callback
        try {
            cm.registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {
            activeNetworkCallback = null
            return true // can't monitor connectivity — don't block the download on it
        }
        try {
            while (!latch.await(300, TimeUnit.MILLISECONDS)) {
                if (isCancelled()) return false
            }
        } finally {
            try { cm.unregisterNetworkCallback(callback) } catch (_: Exception) {}
            activeNetworkCallback = null
        }
        return true
    }

    /** Defensively unregisters any still-active network callback — call from `onDestroy`. */
    fun unregisterActiveCallback() {
        activeNetworkCallback?.let { cb ->
            try { connectivityManager?.unregisterNetworkCallback(cb) } catch (_: Exception) {}
            activeNetworkCallback = null
        }
    }
}
