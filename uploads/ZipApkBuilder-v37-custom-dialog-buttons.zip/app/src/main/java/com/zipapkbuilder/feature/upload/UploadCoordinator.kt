package com.zipapkbuilder.feature.upload

import android.app.AlertDialog
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch

/**
 * Drives a single reliable, progress-tracked upload to GitHub: the upload
 * progress dialog, retry-with-backoff policy, and the large-file Git Data API
 * path (blob → tree → commit → ref update) that [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
 * uses for anything too big for a single Contents API PUT.
 */
class UploadCoordinator(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    /** Set by the upload dialog's Cancel button; polled by every chunked write and retry loop. */
    @Volatile var uploadCancelled = false

    class UploadDialogHolder(
        val dialog:     AlertDialog,
        val onProgress: (written: Long, total: Long) -> Unit,
        val setStatus:  (text: String) -> Unit
    )

    /**
     * Must be called from a background thread. Creates the dialog on the main thread
     * via a latch, then returns the holder so the caller can drive progress updates.
     */
    fun showUploadProgressDialog(fileName: String, totalBytes: Long): UploadDialogHolder {
        val dp = activity.resources.displayMetrics.density

        val totalStr = Formatters.fmtBytes(totalBytes)

        // Build views (safe from any thread before attaching to window)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (20*dp).toInt(), (20*dp).toInt(), (12*dp).toInt())
            setBackgroundColor(0xFF13162A.toInt())
        }

        val tvName = TextView(activity).apply {
            text = fileName; textSize = 13f
            setTextColor(0xFFE8EAED.toInt())
            setTypeface(null, Typeface.BOLD)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        }

        val tvSize = TextView(activity).apply {
            text = "0 B / $totalStr"; textSize = 11f
            setTextColor(0xFF9AA0B8.toInt())
            setPadding(0, (4*dp).toInt(), 0, (10*dp).toInt())
        }

        val progressBar = ProgressBar(activity, null,
            android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = 0
            progressDrawable = LayerDrawable(arrayOf(
                ColorDrawable(0xFF1C2038.toInt()),
                ClipDrawable(
                    ColorDrawable(0xFF7B68EE.toInt()), // purple for upload
                    Gravity.START,
                    ClipDrawable.HORIZONTAL
                )
            )).also { ld -> ld.setId(0, android.R.id.background); ld.setId(1, android.R.id.progress) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (8*dp).toInt()
            ).also { it.bottomMargin = (4*dp).toInt() }
        }

        val tvPercent = TextView(activity).apply {
            text = "0%"; textSize = 11f; setTextColor(0xFF7B68EE.toInt())
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val tvSpeed = TextView(activity).apply {
            text = ""; textSize = 10.5f; setTextColor(0xFF50587A.toInt())
            setPadding(0, (6*dp).toInt(), 0, (2*dp).toInt())
        }

        val btnRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, (14*dp).toInt(), 0, 0)
        }

        val btnCancel = Button(activity).apply {
            text = "✕ Cancel"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6B2020.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
        }

        btnRow.addView(btnCancel)
        root.addView(tvName); root.addView(tvSize); root.addView(progressBar)
        root.addView(tvPercent); root.addView(tvSpeed); root.addView(btnRow)

        val holderRef = arrayOfNulls<UploadDialogHolder>(1)
        val latch = CountDownLatch(1)

        activity.mainHandler.post {
            val dialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setCustomTitle(TextView(activity).apply {
                    text = "📤  Uploading"; textSize = 15f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(0xFFE8EAED.toInt())
                    setPadding((20*dp).toInt(), (18*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
                    setBackgroundColor(0xFF1C2038.toInt())
                })
                .setView(root).setCancelable(false).create()

            btnCancel.setOnClickListener { uploadCancelled = true; dialog.dismiss() }

            var lastSpeedTime  = System.currentTimeMillis()
            var lastSpeedBytes = 0L

            val onProgress: (Long, Long) -> Unit = { written, total ->
                val now     = System.currentTimeMillis()
                val elapsed = now - lastSpeedTime
                if (elapsed >= 200) {
                    val speedBps = (written - lastSpeedBytes) * 1000L / elapsed.coerceAtLeast(1)
                    lastSpeedTime  = now; lastSpeedBytes = written
                    val pct    = if (total > 0) (written * 1000L / total).toInt() else 0
                    val dlStr  = Formatters.fmtBytes(written)
                    val spdStr = "${Formatters.fmtBytes(speedBps)}/s"
                    val pctStr = if (total > 0) "${"%.1f".format(written * 100.0 / total)}%" else "…"
                    activity.mainHandler.post {
                        progressBar.progress = pct
                        tvPercent.text = pctStr
                        tvSize.text    = "$dlStr / $totalStr"
                        tvSpeed.text   = spdStr
                    }
                }
            }

            dialog.show()
            holderRef[0] = UploadDialogHolder(
                dialog, onProgress,
                setStatus = { text -> tvSpeed.text = text }
            )
            latch.countDown()
        }

        latch.await()
        return holderRef[0]!!
    }

    /**
     * Applies the same network-reliability policy downloads get from the
     * download engine to a single upload attempt — without byte-level
     * resume, since none of GitHub's upload endpoints (Contents API PUT, or
     * the blob/tree/commit sequence in [uploadViaGitDataApi]) support
     * resuming a partial request the way a download's Range header does.
     * Instead, a failed attempt is retried *from scratch*, which is safe here
     * because every step involved is naturally idempotent or cheap to redo:
     * Git blobs and trees are content-addressed (recreating one with the same
     * bytes just returns the same SHA, at negligible cost), and a retried
     * commit/ref-update simply produces one small additional commit rather
     * than corrupting anything.
     *
     * - A dropped connection while genuinely offline pauses (shown via
     *   [UploadDialogHolder.setStatus]) and resumes automatically the instant
     *   connectivity returns — this never counts against [maxRetries].
     * - A transient HTTP failure (429/500/502/503/504, recognized via
     *   [NetworkReliability.retryableHttpCodeIn] since these arrive as thrown
     *   messages, not return codes) or an I/O error while the network still
     *   tests as reachable retries with exponential backoff, up to
     *   [maxRetries] times.
     * - Anything else (auth failure, payload too large, cancellation) is
     *   fatal immediately.
     *
     * Must be called from a background thread.
     */
    fun <T> withUploadRetry(
        dlUi: UploadDialogHolder,
        maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES,
        attempt: () -> T
    ): T {
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        while (true) {
            if (uploadCancelled) throw Exception("Cancelled by user")
            try {
                return attempt()
            } catch (e: Exception) {
                if (e.message == "Cancelled by user" || uploadCancelled) throw e

                val retryableCode = networkReliability.retryableHttpCodeIn(e.message)
                val isIoIssue = e is java.io.IOException

                if (isIoIssue && !networkReliability.isNetworkAvailable()) {
                    activity.mainHandler.post { dlUi.setStatus("⚠ Paused (No Internet) — will resume automatically") }
                    val reconnected = networkReliability.waitForNetwork { uploadCancelled }
                    if (!reconnected) throw Exception("Cancelled by user")
                    activity.appendLog("↻ Back online — retrying upload…")
                    continue
                }

                if (isIoIssue || retryableCode != null) {
                    retryAttempt++
                    if (retryAttempt > maxRetries) {
                        throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                    }
                    activity.mainHandler.post { dlUi.setStatus("Retrying in ${backoffMs / 1000}s… (attempt $retryAttempt/$maxRetries)") }
                    networkReliability.sleepCancellable(backoffMs) { uploadCancelled }
                    backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                    continue
                }

                throw e // not network/transient-server-related — fatal
            }
        }
    }

    /**
     * Uploads [b64Content] (base64-encoded file bytes) to [filePath] using the
     * Git Data API.  This path bypasses the Contents API's 50 MB file limit and
     * supports up to ~99 MB raw.
     *
     * Steps: create blob → get branch tip → get base tree →
     *        create tree → create commit → advance ref.
     *
     * Returns the blob SHA (stored as lastFileSha for later ops).
     */
    fun uploadViaGitDataApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, b64Content: String, displayName: String,
        onProgress: (Long, Long) -> Unit
    ): String? {
        // 1. Create blob (largest network call — drives the progress bar)
        activity.appendLog("  Uploading blob…")
        val blobBody = "{\"content\":${JSONObject.quote(b64Content)},\"encoding\":\"base64\"}"
        val (blobCode, blobResp) = GitHubApi.httpPostWithProgress(
            token, "https://api.github.com/repos/$owner/$repo/git/blobs",
            blobBody, isCancelled = { uploadCancelled }, onProgress = onProgress
        )
        if (blobCode !in 200..201)
            throw Exception("Blob upload failed ($blobCode): ${blobResp.take(300)}")
        val blobSha = JSONObject(blobResp).getString("sha")
        activity.appendLog("  Blob created ✓ (${blobSha.take(12)}…)")

        // 2. Get the current branch tip commit SHA
        val (refCode, refBody) = GitHubApi.httpGet(token,
            "https://api.github.com/repos/$owner/$repo/git/ref/heads/$branch")
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        // 3. Get base tree SHA from tip commit
        val (commitCode, commitBody) = GitHubApi.httpGet(token,
            "https://api.github.com/repos/$owner/$repo/git/commits/$tipSha")
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        val baseSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

        // 4. Create a new tree with the file
        activity.appendLog("  Creating tree…")
        val treeBody = JSONObject().apply {
            put("base_tree", baseSha)
            put("tree", JSONArray().put(JSONObject().apply {
                put("path", filePath)
                put("mode", "100644")
                put("type", "blob")
                put("sha",  blobSha)
            }))
        }.toString()
        val (treeCode, treeResp) = GitHubApi.httpPost(token,
            "https://api.github.com/repos/$owner/$repo/git/trees", treeBody)
        if (treeCode !in 200..201)
            throw Exception("Tree creation failed ($treeCode): ${treeResp.take(300)}")
        val newTreeSha = JSONObject(treeResp).getString("sha")

        // 5. Create new commit
        activity.appendLog("  Committing…")
        val newCommitBody = JSONObject().apply {
            put("message", "ci: upload $displayName [run ${System.currentTimeMillis()}]")
            put("tree",    newTreeSha)
            put("parents", JSONArray().put(tipSha))
        }.toString()
        val (newCommitCode, newCommitResp) = GitHubApi.httpPost(token,
            "https://api.github.com/repos/$owner/$repo/git/commits", newCommitBody)
        if (newCommitCode !in 200..201)
            throw Exception("Commit failed ($newCommitCode): ${newCommitResp.take(300)}")
        val newCommitSha = JSONObject(newCommitResp).getString("sha")

        // 6. Advance branch ref
        activity.appendLog("  Advancing branch ref…")
        val refPatchBody = JSONObject().apply {
            put("sha",   newCommitSha)
            put("force", false)
        }.toString()
        val (patchCode, patchResp) = GitHubApi.httpPatch(token,
            "https://api.github.com/repos/$owner/$repo/git/refs/heads/$branch", refPatchBody)
        if (patchCode !in 200..201)
            throw Exception("Ref update failed ($patchCode): ${patchResp.take(300)}")

        return blobSha
    }
}
