# Known Limitations — v28

Per the brief: "Only leave something unresolved if it is technically
impossible, and explain why." Everything below is either a genuine
architectural constraint (GitHub's APIs, Android's platform APIs) or an
explicit, reasoned trade-off — not something skipped for lack of time.

## Pre-Existing: `gradle-wrapper.jar` Is Missing From the Project

**This predates v28** — confirmed by diffing against the untouched original
v27 upload, byte-for-byte identical in both `gradlew` and
`gradle/wrapper/gradle-wrapper.properties`, and this file was never part of
either version to begin with. Flagging it here anyway because it directly
affects the "must compile successfully" requirement for anyone running a bare
`./gradlew` in this project specifically.

**What's there:** `gradlew` (a complete, correct POSIX wrapper script — read
through it line by line to confirm) and
`gradle/wrapper/gradle-wrapper.properties` (correctly points at Gradle 8.6).
**What's missing:** `gradle/wrapper/gradle-wrapper.jar` — the small binary
that `gradlew`'s `CLASSPATH` line points at and that actually bootstraps
downloading/running the real Gradle distribution. Without it, `./gradlew
<any task>` fails immediately (`ClassNotFoundException:
org.gradle.wrapper.GradleWrapperMain` or similar) before Gradle itself ever
starts.

**Why this couldn't be fixed here:** this environment has no network access
(confirmed directly — outbound requests are blocked by the sandbox's egress
allowlist), so there's no way to download the real jar from Gradle's
distribution servers, and fabricating a fake one would be worse than leaving
it out (a confusing runtime failure instead of a clearly-documented gap).

**How to fix it, if needed** (any of these takes seconds, doesn't require
touching any other file, and is standard practice — this file isn't
typically hand-edited or expected to need manual reconstruction): open the
project in Android Studio, which detects the missing wrapper and offers to
regenerate it automatically; or, with any local Gradle install, run `gradle
wrapper --gradle-version 8.6` from the project root.

## Environment Constraints

- **No real compile happened**, beyond the point above. This environment has
  no Android SDK, no Gradle, and no `kotlinc`. Every claim of correctness in
  `REVIEW_REPORT.md` comes from careful static review (brace/paren balance
  checking, manual tracing, cross-referencing against the pristine original),
  not from a build log. Once the wrapper jar is restored (see above), running
  `./gradlew assembleRelease` is the natural next step — if anything doesn't
  compile, it's most likely to be a small, mechanical issue (a typo'd
  identifier or mismatched type) rather than a structural one, given how
  thoroughly the structure itself was checked.
- **R8/shrinking was enabled based on static analysis of what the app does**
  (no reflection-based serialization, no WebView JS interface — see
  `PERFORMANCE_REPORT.md`), not by building both a shrunk and unshrunk APK and
  comparing behavior, since no build is possible here. If a release build
  (specifically — not debug) ever crashes with a `ClassNotFoundException`,
  `NoSuchMethodException`, or a missing-resource error that doesn't reproduce
  in a debug build, that's the first thing to suspect; the fix is almost
  always one additional `-keep` rule in `proguard-rules.pro` for whatever
  class/method R8 removed.

## Architectural Constraints (Not Fixable Without Changing the Server-Side API)

- **Uploads cannot resume byte-by-byte the way downloads do.** GitHub's
  Contents API (single PUT) and Git Data API (blob/tree/commit) have no
  partial-request mechanism — there's no equivalent of a download's `Range`
  header for an upload. A failed upload retries the *whole attempt* from
  scratch instead (see `PERFORMANCE_REPORT.md` for why that's still safe and
  cheap here). True chunked/resumable upload would require GitHub to offer a
  different API than the ones this app uses.
- **The keystore-alias display fix is forward-looking only.** If an install
  already has an incorrect alias stored locally from before this fix (from
  using "Use Existing" on a keystore with a different real alias), v28
  doesn't retroactively detect or correct that stored value — there's no way
  to recover the *actual* alias after the fact, since GitHub never reveals a
  Secret's value. The fix stops the bad data from being written going
  forward; it doesn't scrub what might already be there.
- **Single-file uploads through the file browser stay capped at 50MB**
  (`uploadFileToRepo()`, unchanged from v27). This is GitHub's own Contents
  API limit for a single PUT, not a self-imposed one, and there's no
  chunked-upload alternative for this endpoint to fall back to.

## Deliberate Trade-offs

- **"Paused (No Internet)" is based on `NetworkCapabilities.NET_CAPABILITY_INTERNET`,
  not `NET_CAPABILITY_VALIDATED`.** The former means the network *should* have
  internet access; the latter confirms Android has actually verified it does.
  On a captive-portal network (hotel/airport Wi-Fi that intercepts traffic
  until you log in through a browser), this can report "available" slightly
  before the connection is genuinely usable — the immediate resume attempt
  would fail again, but it then falls back into the normal backoff-retry path
  and recovers once the portal is passed, rather than getting stuck. This was
  a deliberate choice: `NET_CAPABILITY_VALIDATED` can be slower to flip true
  and occasionally stays false on networks that are actually fine (some
  VPNs, some enterprise networks), which risks the opposite failure mode —
  waiting indefinitely on a connection that already works.
- **"Configurable retry count" was implemented as a single named constant**
  (`MAX_DOWNLOAD_RETRIES`, passed as a default parameter to
  `performResumableDownload()` / `withUploadRetry()`), not as an end-user-
  facing Settings toggle. Adding a UI control for it would mean a new visible
  element, which conflicts with "keep the UI visually identical unless a tiny
  change is absolutely required" — a retry count isn't something most users
  would need to change, so this was read as "not hardcoded as a magic number
  in five places" rather than "user-adjustable in Settings." If end-user
  control over this was actually the intent, it's a small, low-risk addition
  from here (one more row in the existing Settings dialog).
- **Partial downloads are kept for 7 days, not forever.** The brief asks to
  "never delete partial downloads unless they are corrupted," but with no
  retention limit at all, a partial file for an artifact/run the user never
  comes back to would sit in the app's cache indefinitely, one per
  never-finished download, forever. 7 days was chosen as long enough that
  closing the app and resuming "tomorrow" (or even next week) always works,
  while still bounding worst-case storage growth from truly abandoned
  attempts. See `BUGS_FIXED.md` v28 #1 for the related bug this replaced.
- **A repeat HTTP 416 after the one automatic restart-from-0% is fatal, not
  retried further.** If the *fresh* attempt (no local bytes, no `Range`
  header sent at all) still gets a 416, that's not a resume-mismatch anymore
  — something else is wrong server-side — so this is surfaced as an error
  rather than retried, to avoid a genuinely-broken download looping forever.

## Not Investigated This Release

- VPN reconnect and Wi-Fi↔mobile-data handoff are handled by the same
  general `ConnectivityManager`-based mechanism as any other connectivity
  change, but neither was specifically tested against (no way to simulate
  either in this environment) — they're expected to work because they go
  through the same "is there a network with internet capability right now"
  check as every other reconnect case, not because they were separately
  verified.
- DNS-specific failures are handled as a generic `IOException`
  (`UnknownHostException` is a subclass) and fall into the same
  online-but-flaky retry path as any other I/O error; there's no DNS-specific
  diagnostic or message.
