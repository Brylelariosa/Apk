# Features Added — v29

## Background Build Tracking + Notifications
**Where:** Automatic — applies to every 🚀 Upload & Build run.

**What it does:** Builds can take anywhere from a couple of minutes to
(rarely) tens of minutes. Previously, the app had to stay open and in the
foreground the whole time for its polling to keep running reliably — Android
can and does reclaim background app processes to save memory/battery, which
risked silently losing track of a build if you switched to another app.

Now:
- The moment a build starts, an ongoing, low-priority notification appears —
  "ZipApkBuilder: Starting build…" — and updates live as the build moves
  through each phase (Uploading → Waiting for build → Building → Fetching
  APK), mirroring the same status text already shown in the app itself.
- That notification isn't just informational — its presence is what keeps
  the app's process (and the build-polling already happening inside it)
  alive if you switch away, exactly the way a music app's "now playing"
  notification keeps audio playing after you leave the app.
- When the build finishes, the ongoing notification is replaced with a
  normal, dismissible one: "✓ Build succeeded" (with how long it took) or
  "✗ Build failed" (with the reason). Tapping either reopens the app.
- Cancelling a build yourself doesn't post a result notification — you're
  already in the app when you do that, so one would just be redundant.
- On Android 13+, the first build you start will prompt for notification
  permission. Declining it doesn't affect the build at all — it just means
  you won't see the notifications; everything else works exactly as before.

---

# Features Added — v28

## Resumable Downloads
**Where:** Automatic — applies to both 📲 Download & Install APK and the
build-log ZIP download.

**What it does:** Downloads now behave like a proper download manager instead
of an all-or-nothing transfer:
- If the connection drops, the download **pauses automatically** — the dialog
  shows "⚠ Paused (No Internet) — will resume automatically" — and **resumes
  the instant connectivity returns**, with no action needed from you.
- Resume continues from the **exact byte** it stopped at (via HTTP `Range`
  requests) whenever the server supports it, instead of starting over.
- A transient server hiccup (rate-limited, or a temporary GitHub/CDN error)
  now retries automatically with increasing delays (2s, 4s, 8s… up to 30s)
  before giving up.
- If every automatic retry is exhausted, a **Retry button** appears and
  reuses the same partial bytes rather than discarding them.
- Progress now also shows **remaining size** and **ETA**, alongside the
  existing downloaded/total and speed.
- Progress survives **fully closing and reopening the app** — an interrupted
  download picks up where it left off even after a restart, for at least 7
  days (see `BUGS_FIXED.md` #1 for why not indefinitely).

## Upload Reliability
**Where:** Automatic — applies to 🚀 Upload & Build's upload step, both the
small-file path and the large-ZIP (Git Data API) path.

**What it does:** Previously, any network hiccup during upload failed the
whole build immediately. Uploads now get the same offline-pause and
backoff-retry treatment as downloads: a dropped connection waits for
connectivity to return, and a transient server error retries automatically.
True byte-level resume isn't possible for GitHub's upload APIs, so a retry
re-sends the attempt from scratch — safe to do because the underlying steps
(Git blobs/trees are content-addressed) make a retry cheap and harmless
rather than corrupting or duplicating anything.

## Download Integrity Verification (ZIP + APK)
**Where:** Automatic — runs right after any artifact or build-log ZIP finishes
downloading, before it's saved to Downloads.

**What it does:** Two layers, matching the two things that can go wrong:
- **ZIP-level:** fully re-reads the downloaded ZIP and verifies every entry's
  CRC-32 checksum matches what's stored in the ZIP itself — the standard
  signal that a file was truncated or corrupted in transit. A file that fails
  this check is deleted and offered for retry, instead of being silently
  saved to your Downloads folder and reported as a success when it isn't
  actually usable.
- **APK-level:** for an artifact ZIP specifically, the extracted `.apk` is
  separately verified as a real, parseable APK (its manifest, package name,
  version, and SDK range are all read back out — see the existing APK Info
  Viewer, which now explicitly reports "✓ Integrity verified" as part of its
  output). This catches the rarer case of an APK that's byte-perfect (passes
  the ZIP check) but still isn't a structurally valid APK.

---

# Features Added — v27

## Build History
**Where:** Settings (⚙) → scroll down to **Build History**, below Download History.

**What it does:** Every time you run 🚀 Upload & Build, the outcome (success /
failed / cancelled), the repo and branch, and how long it took are recorded
locally on-device. The section shows your last 30 builds, newest first, with
an icon (✓ / ✗ / ⊘) so you can scan outcomes at a glance. Tap **Clear** to wipe
the history.

**Why it's separate from "Build Log":** the existing Build Log button already
lets you browse any past GitHub Actions run in detail, but that requires a
couple of live API calls just to open. Build History is instant and free —
it's a local log of what *this device* has triggered, not a window into
GitHub's data.

## Build Statistics
**Where:** Same Settings section, shown as a single line above the list
(e.g. *"14 build(s) · 86% success · avg 3m 42s"*).

**What it does:** Success rate is computed over all recorded builds; average
duration is computed only from successful ones, so a quick network failure
doesn't drag the "typical build time" number down misleadingly.

## Build Duration Timer
**Where:** Automatic — shown in the console log at the end of every build
(*"⏱ Build finished in 3m 58s"*) and stored with each Build History entry.

**What it does:** Times the full flow — verifying the token, checking/creating
the repo, uploading the ZIP, waiting for the run, and downloading the
artifact — end to end, as experienced from the phone, not just GitHub's own
run duration.

## APK Info Viewer
**Where:** Automatic — appears in the console log right after a successful
📲 Download & Install APK.

**What it does:** Peeks inside the downloaded artifact ZIP for the `.apk` file
and reports:
- Package name
- Version name and version code
- Minimum and target SDK
- APK size

This is a quick way to confirm what actually got built (right package name,
expected version bump, sane SDK range) without needing to install the APK
first. If the artifact doesn't contain an `.apk` (e.g. a logs-only artifact),
nothing is shown — this never blocks or slows down the download itself.

## Pre-Upload ZIP Validation
**Where:** Automatic — runs right after you pick a ZIP and tap 🚀 Upload & Build,
before the upload starts.

**What it does:** Scans the ZIP's entry names (already-loaded bytes, no extra
reads) for `settings.gradle`/`settings.gradle.kts` and `gradlew`. If either is
missing, a warning appears in the log *before* the upload happens — the same
files the workflow's own "Find project directory" and "Make gradlew
executable" steps require. This catches the single most common mistake
(wrong ZIP, or a folder zipped one level off) before spending an upload and a
full CI run finding out.

## Storage Space Check
**Where:** Automatic — runs right before any artifact or build-log download
starts.

**What it does:** Checks that the destination has enough free space for the
incoming file (with a 10MB safety margin). If not, the download fails
immediately with a clear message instead of partway through with a confusing
I/O error.

## Automatic Stale-Cache Cleanup
**Where:** Automatic — runs once, quietly, on app startup.

**What it does:** If a previous session was killed (force-close, low-memory
kill, crash) before it could clean up its own temp files, this sweeps any
leftover artifact/log/APK-info temp files older than a couple of minutes out
of the app's cache. You'll see a short log line only if it actually found
something to clean up.
