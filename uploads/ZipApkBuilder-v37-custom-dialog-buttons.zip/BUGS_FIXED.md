# Bugs Fixed — v28

## 1. Cold-start cache sweep could delete a download you hadn't given up on
**Where:** `cleanupStaleCacheFiles()`

**Root cause:** this sweep predates resumable downloads. In v27, any leftover
`artifact_*.zip` / `logs_tmp_*.zip` file in cache really was always garbage —
the only way one could exist was a process kill in the narrow window between
finishing a download and deleting the cache copy after saving to Downloads —
so a flat "delete anything of this name older than 2 minutes" rule was safe.
v28 repurposes these exact same files as the resumable-download engine's
partial-progress state (see the Network Reliability section of
`V28_RELEASE_NOTES.md`), but the sweep's 2-minute rule was never updated to
match — so on the very next cold start after closing the app mid-download and
waiting more than 2 minutes, the sweep would delete the partial file before
the user ever got a chance to resume it.

**Fix:** split the sweep into two tiers. `apkinfo_*.apk` (a same-function
scratch file that's always deleted in its own `finally` block, so a leftover
one is still always garbage) keeps the original 2-minute window.
`artifact_*.zip` / `logs_tmp_*.zip` now get a 7-day window instead — long
enough that closing the app and resuming "tomorrow" always works, short
enough that a truly abandoned partial doesn't sit in cache forever.

**Effect if unfixed:** interrupt a download, leave the app closed for a few
minutes, reopen it — the partial download silently vanishes and the next
attempt starts over from 0%, directly contradicting the download-resume
feature this same release adds.

## 2. Resuming a stale/mismatched partial download could fail permanently
**Where:** `performResumableDownload()`

**Root cause:** an HTTP `416 Range Not Satisfiable` response (the server
rejecting a `Range` request because the local partial no longer corresponds
to what it has — e.g. a replaced artifact) fell into the generic "non-2xx,
non-retryable" path, which is fatal by design (retrying a permanently-invalid
request forever would be worse than failing fast). But a 416 specifically
means *the request* is unsatisfiable, not that the download is unrecoverable
— a fresh, non-ranged request for the same URL would normally succeed.

**Fix:** treat 416 as its own case: discard the mismatched local partial and
restart the download from 0% once. A second 416 on that fresh attempt is
treated as fatal (something else is wrong), so this can't loop forever.

**Effect if unfixed:** a download whose local partial became invalid for any
reason would fail with no recovery path other than manually clearing app
storage.

## 3. Two unguarded `!!` file-stream opens could crash with a raw NPE
**Where:** the project-ZIP read in `runFlow()`, and the single-file upload
read in `uploadFileToRepo()` — both did `contentResolver.openInputStream(uri)!!`

**Root cause:** `ContentResolver.openInputStream()` returns `null` (it
doesn't throw) when the underlying document provider can no longer serve a
previously-picked URI — most commonly because the file was moved, deleted, or
its access grant was revoked since the user picked it. Both call sites forced
that nullable result with `!!`, so this ordinary, fairly common situation
surfaced as a generic `NullPointerException` rather than a clear message.
(Both were already inside a `try`/`catch`, so this was never an *uncaught*
crash — but the resulting message wasn't useful.)

**Fix:** added `openInputStreamOrThrow()` / `openOutputStreamOrThrow()`
helpers that throw a clear, actionable message instead, and used them at
every one of the 4 call sites that previously each opened a stream this way
(2 input, 2 output).

**Effect if unfixed:** picking a file, then having it become unavailable
before the app reads it (deleted, moved, permission revoked — all realistic
on Android's storage model), showed a bare "NullPointerException"-style
message instead of "please pick it again."

## 4. "Use Existing" keystore could store a made-up alias
**Where:** `generateKeystore()`'s "Keystore Already Configured" dialog

**Root cause:** GitHub's Secrets API confirms a secret *exists* but never
reveals its value, so `checkExistingKeystore()` can only tell the app the
existing keystore's **filename**, never the alias it was actually generated
with. The "Use Existing" button nonetheless saved the currently-typed (or
freshly timestamp-generated, if left blank) alias into local prefs as if it
were confirmed fact.

**Fix:** store and display the verified filename instead of a guessed alias
when using an existing keystore; only the "Generate New" path (which really
does know the alias, since it just chose it) stores an alias.

**Effect if unfixed:** the Settings keystore-status line could show a
plausible-looking but simply wrong alias for any existing keystore where the
alias field was left blank or didn't match the original.

## 5. A misplaced doc comment described the wrong function
**Where:** just above `logApkInfoFromZip()`

**Root cause:** a doc comment for `saveZipToDownloads()` (MediaStore vs.
direct-file-write behavior, return value) was left behind, at its old textual
position, by an earlier refactor that split that function into a thin
history-recording wrapper plus `saveZipToDownloadsInternal()` — the comment
never moved with the code it described, and ended up sitting directly above
an unrelated function instead.

**Fix:** moved the comment back above `saveZipToDownloadsInternal()` (the
function it actually documents), and added a one-line comment on the thin
wrapper pointing to it.

**Effect if unfixed:** not a runtime bug, but actively misleading for any
future reader trying to understand `logApkInfoFromZip()` from its (wrong)
preceding comment.

## Verified from v27 (no change needed)
Every fix listed below `# Bugs Fixed — v27` was re-checked against the
current source and confirmed still correct and in place — see
`REVIEW_REPORT.md` for the specific verification performed on each.

---

# Bugs Fixed — v27

## 1. Owner chip visibility ignored its own condition
**Where:** `restoreSavedBuildState()`

**Root cause:** a semicolon-separated single-line `if` —
```kotlin
if (savedOwner.isNotEmpty()) tvOwnerInfo.text = "..."; tvOwnerInfo.visibility = VISIBLE
```
Kotlin (like Java/C) only scopes the *first* statement after an unbraced `if`
to that condition. The semicolon ends the `if`, so `tvOwnerInfo.visibility =
VISIBLE` ran on every call to this function regardless of `savedOwner`.

**Fix:** wrapped both statements in braces so both are conditional, matching
the evident original intent.

**Effect if unfixed:** in the edge case where a saved build exists but
`savedOwner` is empty (e.g. data from a much older version, before that field
existed), the owner chip would be shown visible with stale or blank text
instead of staying hidden.

## 2. New-repo creation polled ~18s longer than necessary
**Where:** `promptCreateRepo()`

**Root cause:**
```kotlin
repeat(10) {
    Thread.sleep(2_000)
    ...
    if (chk == 200) { ready = true; return@repeat }
}
```
`return@repeat` returns from the *current lambda invocation* of `repeat`'s
block — it's the equivalent of `continue`, not `break`. There is no way to
exit a Kotlin `repeat { }` early with a labeled return; it always runs the
full count.

**Fix:** replaced with `for (attempt in 1..10) { ...; if (chk == 200) { ready
= true; break } }`, which can actually stop as soon as the repo is reachable.

**Effect if unfixed:** every new-repo creation waited out all 10 iterations
(20s) even when the repo became reachable on, say, the 2nd check (4s) —
wasting up to ~16-18 extra seconds every time, on top of whatever the actual
wait should have been.

## 3. File editor line-number gutter recomputed on every keystroke
**Where:** `showFileEditorDialog()`'s `TextWatcher`

**Root cause:** `afterTextChanged` unconditionally did
`(s.toString()).lines().size` (a full copy + split of the entire document) and
rebuilt the whole gutter string, on every single character typed or deleted —
work proportional to file size, repeated on every keystroke regardless of
whether the edit could possibly have changed the line count.

**Fix:** capture whether the replaced region (in `beforeTextChanged`) or the
newly-inserted region (in `onTextChanged`) contains a newline; only recompute
the gutter when at least one of those is true. Ordinary character typing
never touches a newline, so it now skips the expensive path entirely.

**Effect if unfixed:** visible typing lag in the in-app file editor for any
file of meaningful size — including, notably, this app's own ~4,700-line
`MainActivity.kt` if someone ever opened it through the file browser.

## 4. Reported download path could not match the actual saved file
**Where:** `saveZipToDownloadsInternal()` (Android 10+ / MediaStore branch)

**Root cause:** the returned path was built by string-joining the public
Downloads directory with the *requested* filename. MediaStore, however,
silently renames on a collision (`artifact.zip` → `artifact.zip (1)`) rather
than overwriting or failing — so re-downloading the same artifact name twice
could report a path pointing at a file that isn't the one actually written.

**Fix:** after the write completes, query the item's actual
`MediaStore.Downloads.DISPLAY_NAME` back from the `ContentResolver` and use
that in the returned path (and therefore in the log line and Download History
entry too).

## 5. One failed item aborted an entire batch delete
**Where:** `deleteItemsRecursive()`

**Root cause:** the loop over selected items and the whole operation shared
one `try`/`catch`; a folder that failed to list (or any other error partway
through) threw out of the loop entirely, silently skipping every remaining
selected item with no indication of which ones were or weren't deleted.

**Fix:** each item is now attempted in its own `try`/`catch`; failures are
counted and logged per-item, and a summary ("Deleted 4 item(s), 1 failed.")
is reported once all items have been attempted.

## 6. Artifact ZIP leaked into the app cache on every download
**Where:** `downloadArtifact()`

**Root cause:** the temp file created at `cacheDir/artifact_<timestamp>.zip`
was copied to Downloads via `saveZipToDownloads()` but never deleted
afterward — unlike the equivalent temp file in `downloadLatestRunLogs()`,
which already correctly deletes its own copy. Since each file's name includes
a timestamp, they never overwrote each other; they just accumulated.

**Fix:** the cache copy is deleted immediately after the log/history entry is
recorded. A one-time startup sweep (`cleanupStaleCacheFiles()`) also catches
any files left behind by sessions from before this fix existed, or by a
session killed mid-flow before reaching the delete call.

## 7. Four inconsistent implementations of the same byte-formatting logic
**Where:** class-level `fmtBytes()` plus three local duplicates inside
`downloadLatestRunLogs()`, `downloadArtifact()`, and `showUploadProgressDialog()`

**Root cause:** the three local copies were simpler than the class-level one
— integer-only KB (no decimal), and no GB tier at all, so a hypothetical
artifact over 1GB would display as e.g. "1500.0 MB" from the local copies but
correctly as "1.46 GB" from the class-level one. Not incorrect, just
inconsistent, and four copies of the same logic is its own maintenance risk.

**Fix:** removed all three local copies; every call site now resolves to the
single class-level `fmtBytes()`.
