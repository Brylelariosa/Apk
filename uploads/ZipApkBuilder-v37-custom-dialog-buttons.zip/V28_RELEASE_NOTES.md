# ZipApkBuilder v28 — Release Notes

## Executive Summary

v28 is a network-reliability and bug-review release. The centerpiece is a
real resumable-download engine — byte-level HTTP Range resume, automatic
pause/resume on connectivity loss, and exponential-backoff retry — replacing
v27's single-attempt download loop, plus the same reliability policy extended
to uploads. Alongside that: every v27 fix was re-verified against the current
source, a handful of new (mostly small, one more consequential) bugs were
found and fixed, release-build APK size is now reduced via R8 shrinking, and
a downloaded ZIP's integrity is verified before it's ever handed to the user
as a success. The UI is pixel-for-pixel unchanged — verified by diffing every
resource file against the original, not assumed — and no existing feature was
removed or altered.

## New Features

- **Resumable downloads.** Both the APK artifact download and the build-log
  ZIP download now survive a dropped connection: they pause automatically,
  show "Paused (No Internet)," and resume from the exact byte they stopped at
  the instant connectivity returns — including after fully closing and
  reopening the app (progress is kept for up to 7 days).
- **Automatic retry with backoff.** A transient server error (HTTP 429, or a
  5xx from GitHub/its CDN) retries on its own with increasing delays (2s →
  4s → 8s → … capped at 30s, 5 attempts) before asking the user to do
  anything.
- **Manual Retry.** If automatic retries are exhausted, a Retry button
  appears in the same dialog and continues from the same partial bytes
  rather than starting over.
- **Upload reliability.** The exact same offline-pause / backoff-retry
  treatment now also covers uploading a project ZIP — previously, any
  network hiccup during upload failed the whole build immediately with no
  retry at all.
- **Download integrity verification.** Every downloaded ZIP (artifact and
  build log) is fully re-checked (CRC-32 per entry) before being saved to
  Downloads. A corrupted or truncated result is caught immediately and
  offered for retry instead of being silently saved and reported as success.
- **Richer download progress.** Remaining bytes and ETA are now shown
  alongside downloaded/total and speed.

## Performance Improvements

- A verbose build's full log print (previously up to one `Handler.post` per
  line — potentially thousands for a large Gradle build) is now cleaned and
  joined into a single append. Same resulting text, far fewer main-thread
  posts.
- Removed a duplicate set of log-cleaning regexes (two independent copies of
  the same ANSI-strip/timestamp-strip/group-marker patterns, one per log
  viewer) in favor of one shared, compiled-once implementation.
- **Release APK size**: R8 code shrinking/obfuscation and resource shrinking
  are now both enabled (were off through v27), after specifically checking
  the app has none of the common things that break under shrinking
  (reflection-based serialization, WebView JS interfaces). See
  `PERFORMANCE_REPORT.md` for the full reasoning and `proguard-rules.pro` for
  the resulting (intentionally minimal) keep-rule set.

## Bug Fixes

The one worth calling out specifically: **a cold-start cleanup sweep could
delete a download you hadn't given up on yet.** The sweep that correctly
clears truly-orphaned temp files was, before this fix, also applied to
resumable-download partials with the same short (2-minute) staleness window —
so closing the app and coming back later than that would silently erase
download progress before you ever saw a Resume option. Partial downloads now
get a 7-day window instead.

Four smaller fixes: two file-read paths that could crash with a raw
`NullPointerException` (instead of a clear message) if a picked file became
unavailable; a keystore-configuration dialog that could store a guessed
(possibly wrong) alias for a keystore that already existed on GitHub instead
of admitting it doesn't actually know the alias; and a misplaced doc comment
left behind by an earlier refactor. Full detail, including root cause and
effect-if-unfixed for each, is in `BUGS_FIXED.md`.

Every fix from v27 was individually re-verified against the current source
rather than assumed still correct — see `REVIEW_REPORT.md` for the specific
check performed on each one.

## Reliability Improvements

- Network loss during a download or upload is now a handled, expected case
  rather than a failure: automatic detection via `ConnectivityManager`,
  automatic pause, automatic resume.
- A resumable download's local partial file is now protected from two
  different ways it could previously be lost: the cache-sweep bug above, and
  (new in v28) a corrupted/mismatched partial getting stuck retrying forever
  — an HTTP 416 (Range Not Satisfiable) now triggers exactly one
  discard-and-restart-from-0%, rather than failing with no path forward.
- A corrupted download is now caught (CRC verification) before it's saved or
  reported as successful, rather than silently handed to the user.

## Download & Upload Improvements

See "New Features" and "Reliability Improvements" above — this release's
download/upload changes are extensive enough that they're covered there
rather than repeated here. In one sentence: downloads now behave like a
professional download manager (pause/resume/retry/backoff, exactly as the
v28 brief specified), and uploads get the same reliability policy applied to
the extent GitHub's upload APIs make possible (full-attempt retry rather than
byte-level resume, since the latter isn't available server-side).

## Internal Optimizations

- Generalized two existing helper functions (`sleepCancellable()`,
  `waitForNetwork()`) to accept which cancellation flag to watch, so the new
  upload-retry path could reuse them instead of duplicating both.
- Replaced the last two unguarded `contentResolver.open*Stream(uri)!!` call
  sites with helpers that throw a clear message instead.
- Verified (systematically, not spot-checked) there are no unused imports and
  no unreferenced private functions left anywhere in the file.

## Known Limitations

Full detail in `KNOWN_LIMITATIONS.md`. The headline ones:
- **`gradle/wrapper/gradle-wrapper.jar` is missing from the project** —
  confirmed pre-existing (identical in the untouched original v27 upload, not
  something this release changed), and not fixable here since this
  environment has no network access to fetch the real jar. `gradlew` itself
  is complete and correct; it just points at a jar that isn't there. Fixed in
  seconds by opening the project in Android Studio (which offers to
  regenerate it automatically) or running `gradle wrapper --gradle-version
  8.6` locally.
- No real compile was possible in this environment beyond the point above (no
  Android SDK/Gradle/network access) — correctness here rests on thorough
  static review, not a build log.
- True byte-level upload resume isn't possible — GitHub's upload APIs have no
  partial-request mechanism to resume against, unlike downloads. A failed
  upload retries the whole attempt instead, which is safe and cheap here but
  isn't the same guarantee downloads get.
- Partial downloads are kept for 7 days, not forever, to bound storage growth
  from attempts nobody returns to.

## Future Recommendations

- **Profile on a real device once buildable.** Every performance claim in
  this and the v27 report is reasoned from source, not measured — a real
  device profile (especially of the log-streaming path during a large build,
  and the resumable-download loop's chunk size/UI-update frequency) would
  either confirm or correct that reasoning.
- **Consider a Settings-exposed retry-count/backoff control** if users
  actually want to tune it — this release implemented it as a named constant
  rather than a UI toggle specifically to avoid an unnecessary UI change; see
  `KNOWN_LIMITATIONS.md` for the reasoning, but it's a small addition from
  here if wanted.
- **Watch for release-only crashes after this release specifically**, given
  R8 shrinking is newly enabled — if one shows up, it's almost always a
  missing `-keep` rule in `proguard-rules.pro`, not a logic bug.
- **If GitHub ever ships chunked/resumable upload support**, revisit
  `withUploadRetry()` — right now it retries whole attempts because that's
  all the current API allows, not because resuming wouldn't be better.
