package com.bru.gameboost.data

import android.content.Context
import androidx.core.content.edit
import com.bru.gameboost.domain.SettingsRepository
import com.bru.gameboost.domain.model.BoostSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.updateAndGet

/**
 * Holds the current settings in a StateFlow (so the UI and the service both see
 * changes immediately) and mirrors every change to SharedPreferences.
 */
class SettingsRepositoryImpl(context: Context) : SettingsRepository {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(readFromDisk())
    override val settings: StateFlow<BoostSettings> = _settings.asStateFlow()

    override fun setSilenceNotifications(enabled: Boolean) =
        update { it.copy(silenceNotifications = enabled) }

    override fun setFreeRamOnBoost(enabled: Boolean) =
        update { it.copy(freeRamOnBoost = enabled) }

    private fun update(transform: (BoostSettings) -> BoostSettings) {
        val next = _settings.updateAndGet(transform)
        prefs.edit {
            putBoolean(KEY_SILENCE_NOTIFICATIONS, next.silenceNotifications)
            putBoolean(KEY_FREE_RAM, next.freeRamOnBoost)
        }
    }

    private fun readFromDisk(): BoostSettings {
        val defaults = BoostSettings()
        return BoostSettings(
            silenceNotifications = prefs.getBoolean(KEY_SILENCE_NOTIFICATIONS, defaults.silenceNotifications),
            freeRamOnBoost = prefs.getBoolean(KEY_FREE_RAM, defaults.freeRamOnBoost)
        )
    }

    private companion object {
        const val PREFS_NAME = "gameboost_settings"
        const val KEY_SILENCE_NOTIFICATIONS = "silence_notifications"
        const val KEY_FREE_RAM = "free_ram_on_boost"
    }
}
