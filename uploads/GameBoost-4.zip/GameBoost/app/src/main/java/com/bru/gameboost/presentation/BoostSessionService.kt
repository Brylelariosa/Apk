package com.bru.gameboost.presentation

import android.app.KeyguardManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import com.bru.gameboost.GameBoostApp
import com.bru.gameboost.di.AppContainer
import com.bru.gameboost.domain.AutoEndPolicy
import com.bru.gameboost.domain.ForegroundTracker
import com.bru.gameboost.domain.OverheatGuard
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.CleanResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns one boost session end-to-end: silence notifications, free RAM, launch
 * the game, keep a live-updating notification (the "overlay" for this app — no
 * SYSTEM_ALERT_WINDOW needed), warn if the phone overheats, and end the
 * session either manually (the notification action) or automatically once the
 * user has genuinely left the game, detected via Usage Access.
 *
 * Session state (the job, the token) is only touched on the main thread; the
 * coroutines hop to Main to end the session.
 */
class BoostSessionService : Service() {

    private lateinit var container: AppContainer
    private lateinit var notifications: BoostNotifications

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var sessionJob: Job? = null
    private var sessionToken: Any? = null // identifies the live session, so a stale end request can't end its successor

    private val powerManager: PowerManager? by lazy { getSystemService(PowerManager::class.java) }
    private val keyguardManager: KeyguardManager? by lazy { getSystemService(KeyguardManager::class.java) }

    override fun onCreate() {
        super.onCreate()
        container = (application as GameBoostApp).container
        notifications = BoostNotifications(this).also { it.ensureChannels() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when {
            intent != null && action == ACTION_START -> handleStart(intent)
            action == ACTION_STOP -> endSession()
            sessionJob == null -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME)
        val label = intent.getStringExtra(EXTRA_LABEL)
        val game = if (packageName != null && label != null) BoostableGame(packageName, label) else null

        // startForegroundService() obliges us to call startForeground() promptly — even on
        // the path below that bails out straight away.
        startForeground(
            BoostNotifications.SESSION_ID,
            notifications.session(
                title = if (game != null) "Boosting ${game.label}" else "GameBoost",
                text = "Starting up…"
            )
        )
        if (game == null) {
            endSession()
            return
        }
        beginSession(game)
    }

    private fun beginSession(game: BoostableGame) {
        // Tapping Boost on a second game swaps the session over instead of being silently ignored.
        sessionJob?.cancel()
        val token = Any()
        sessionToken = token
        container.sessionStateHolder.setActive(game)
        sessionJob = serviceScope.launch { runSession(game, token) }
    }

    private suspend fun runSession(game: BoostableGame, token: Any) {
        val settings = container.settingsRepository.settings.value

        if (settings.silenceNotifications) container.dndController.applyBoost()

        if (settings.freeRamOnBoost) {
            val result = cleanRam(game)
            if (result != null) container.sessionStateHolder.setCleanResult(result)
        }

        // Created before the launch, so the game's first resume event can't fall into a gap.
        val tracker = container.foregroundAppMonitor.newTracker()
        if (!launchGame(game)) {
            endSessionIfCurrent(token)
            return
        }

        coroutineScope {
            launch { publishStats(game) }
            launch { watchForAutoEnd(game, tracker, token) }
        }
    }

    /** A failed clean must never stop the boost itself; cancellation still has to propagate. */
    private suspend fun cleanRam(game: BoostableGame): CleanResult? = try {
        container.memoryCleaner.cleanBackground(protectedPackages = setOf(game.packageName))
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private fun launchGame(game: BoostableGame): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(game.packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { startActivity(launchIntent) }.isSuccess
    }

    private suspend fun publishStats(game: BoostableGame) {
        val overheat = OverheatGuard()
        var lastText: String? = null

        container.deviceStatsRepository.observeSnapshot(STATS_INTERVAL_MS).collect { snapshot ->
            // Dark screen: nobody can read the notification, so skip the work entirely.
            if (powerManager?.isInteractive == false) return@collect

            val wasHot = overheat.isHot
            val isHot = overheat.update(snapshot)
            if (isHot && !wasHot) notifications.postHeatWarning(snapshot.batteryTempC, snapshot.isCharging)
            if (!isHot && wasHot) notifications.clearHeatWarning()

            val cleanResult = (container.sessionStateHolder.state.value as? BoostSessionState.Active)?.cleanResult
            val text = SnapshotFormatter.notificationText(snapshot, cleanResult)
            // Re-posting identical text only makes SystemUI redraw for nothing.
            if (text != lastText) {
                lastText = text
                notifications.updateSession("Boosting ${game.label}", text)
            }
        }
    }

    private suspend fun watchForAutoEnd(game: BoostableGame, tracker: ForegroundTracker, token: Any) {
        val monitor = container.foregroundAppMonitor
        val policy = AutoEndPolicy(game.packageName)

        while (true) {
            delay(WATCH_INTERVAL_MS)
            val canObserve = monitor.isAccessGranted()
            val foreground = if (canObserve) tracker.poll() else null
            if (policy.onTick(foreground, canObserve, isUserPresent()) == AutoEndPolicy.Verdict.END) {
                endSessionIfCurrent(token)
                return
            }
        }
    }

    /** Screen on and unlocked — the only time "the game isn't in front" means the user left it. */
    private fun isUserPresent(): Boolean {
        val screenOn = powerManager?.isInteractive ?: true
        val locked = keyguardManager?.isKeyguardLocked ?: false
        return screenOn && !locked
    }

    private suspend fun endSessionIfCurrent(token: Any) {
        withContext(Dispatchers.Main) {
            if (sessionToken === token) endSession()
        }
    }

    private fun endSession() {
        sessionJob?.cancel()
        sessionJob = null
        sessionToken = null
        container.dndController.revertBoost()
        container.sessionStateHolder.setIdle()
        notifications.clearHeatWarning()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        // Safety net for teardown paths that skip endSession(): never leave notifications
        // silenced with no way back short of the Settings app. Both calls are no-ops when
        // there is nothing to undo.
        container.dndController.revertBoost()
        container.sessionStateHolder.setIdle()
        notifications.clearHeatWarning()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.bru.gameboost.action.START"
        const val ACTION_STOP = "com.bru.gameboost.action.STOP"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_LABEL = "extra_label"

        // Polling every 5 s instead of 3 s: the readout isn't worth waking the CPU more often mid-game.
        private const val STATS_INTERVAL_MS = 5_000L
        private const val WATCH_INTERVAL_MS = 5_000L // AutoEndPolicy's tick counts assume this
    }
}
