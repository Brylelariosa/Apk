package com.bru.gameboost.domain

import com.bru.gameboost.domain.model.DeviceSnapshot

/**
 * Turns a stream of snapshots into "started / stopped running hot" transitions.
 * Enter and exit thresholds differ on purpose: a phone hovering around a single
 * number would otherwise flap and re-alert every few seconds.
 */
class OverheatGuard(
    private val hotAtC: Float = DEFAULT_HOT_AT_C,
    private val coolBelowC: Float = DEFAULT_COOL_BELOW_C
) {
    var isHot: Boolean = false
        private set

    /** Feeds one snapshot and returns whether the device counts as hot afterwards. */
    fun update(snapshot: DeviceSnapshot): Boolean {
        val tempC = snapshot.batteryTempC
        val throttling = snapshot.thermalStatus?.isSevere == true
        isHot = when {
            throttling -> true
            tempC == null -> false
            isHot -> tempC >= coolBelowC
            else -> tempC >= hotAtC
        }
        return isHot
    }

    companion object {
        const val DEFAULT_HOT_AT_C = 43f
        const val DEFAULT_COOL_BELOW_C = 41f
    }
}
