package com.bru.gameboost.presentation

import android.app.Application
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bru.gameboost.GameBoostApp
import com.bru.gameboost.domain.BoostSessionStateHolder
import com.bru.gameboost.domain.DeviceStatsRepository
import com.bru.gameboost.domain.DndController
import com.bru.gameboost.domain.ForegroundAppMonitor
import com.bru.gameboost.domain.GameRepository
import com.bru.gameboost.domain.MemoryCleaner
import com.bru.gameboost.domain.SettingsRepository
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostSettings
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.PermissionState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** UI state for the "Free RAM" button: whether a clean is running, and the last result shown under it. */
data class RamCleanState(
    val running: Boolean = false,
    val last: CleanResult? = null
)

class GameBoostViewModel(
    application: Application,
    private val gameRepository: GameRepository,
    deviceStatsRepository: DeviceStatsRepository,
    private val settingsRepository: SettingsRepository,
    private val memoryCleaner: MemoryCleaner,
    private val dndController: DndController,
    private val foregroundAppMonitor: ForegroundAppMonitor,
    sessionStateHolder: BoostSessionStateHolder
) : AndroidViewModel(application) {

    val addedGames: StateFlow<List<BoostableGame>> = gameRepository.observeAddedGames()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val sessionState: StateFlow<BoostSessionState> = sessionStateHolder.state

    val settings: StateFlow<BoostSettings> = settingsRepository.settings

    /** Light in-app preview so the picker screen isn't blank before boosting. */
    val deviceSnapshot: StateFlow<DeviceSnapshot?> = deviceStatsRepository
        .observeSnapshot(PREVIEW_INTERVAL_MS)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _permissionState = MutableStateFlow(readPermissionState())
    val permissionState: StateFlow<PermissionState> = _permissionState.asStateFlow()

    private val _ramClean = MutableStateFlow(RamCleanState())
    val ramClean: StateFlow<RamCleanState> = _ramClean.asStateFlow()

    /** Call from Activity.onResume — permissions are granted in a separate Settings screen. */
    fun refreshPermissionState() {
        _permissionState.value = readPermissionState()
    }

    fun setSilenceNotifications(enabled: Boolean) = settingsRepository.setSilenceNotifications(enabled)

    fun setFreeRamOnBoost(enabled: Boolean) = settingsRepository.setFreeRamOnBoost(enabled)

    fun addGame(game: BoostableGame) = viewModelScope.launch { gameRepository.addGame(game) }

    fun removeGame(packageName: String) = viewModelScope.launch { gameRepository.removeGame(packageName) }

    suspend fun queryLaunchableApps(): List<BoostableGame> = gameRepository.queryLaunchableApps()

    fun boostAndLaunch(game: BoostableGame) {
        val context = getApplication<GameBoostApp>()
        val intent = Intent(context, BoostSessionService::class.java).apply {
            action = BoostSessionService.ACTION_START
            putExtra(BoostSessionService.EXTRA_PACKAGE_NAME, game.packageName)
            putExtra(BoostSessionService.EXTRA_LABEL, game.label)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun endBoost() {
        val context = getApplication<GameBoostApp>()
        context.startService(Intent(context, BoostSessionService::class.java).apply {
            action = BoostSessionService.ACTION_STOP
        })
    }

    /** The standalone "Free RAM" button; spares the game if a session is running. */
    fun freeRamNow() {
        if (_ramClean.value.running) return
        val activeGame = (sessionState.value as? BoostSessionState.Active)?.game?.packageName
        val protectedPackages: Set<String> = if (activeGame != null) setOf(activeGame) else emptySet()

        viewModelScope.launch {
            val previous = _ramClean.value.last
            _ramClean.value = RamCleanState(running = true, last = previous)
            val result = try {
                memoryCleaner.cleanBackground(protectedPackages)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            _ramClean.value = RamCleanState(running = false, last = result ?: previous)
        }
    }

    private fun readPermissionState(): PermissionState {
        val context = getApplication<GameBoostApp>()
        return PermissionState(
            notificationPolicyAccessGranted = dndController.isAccessGranted(),
            usageAccessGranted = foregroundAppMonitor.isAccessGranted(),
            // The honest check on every API level. Before Android 13 there is no POST_NOTIFICATIONS
            // grant at all, so asking for that permission reports "denied" forever.
            notificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        )
    }

    private companion object {
        const val PREVIEW_INTERVAL_MS = 3_000L
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val container = (application as GameBoostApp).container
            return GameBoostViewModel(
                application = application,
                gameRepository = container.gameRepository,
                deviceStatsRepository = container.deviceStatsRepository,
                settingsRepository = container.settingsRepository,
                memoryCleaner = container.memoryCleaner,
                dndController = container.dndController,
                foregroundAppMonitor = container.foregroundAppMonitor,
                sessionStateHolder = container.sessionStateHolder
            ) as T
        }
    }
}
