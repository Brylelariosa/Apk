package com.bru.gameboost.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.bru.gameboost.presentation.screens.AddGameScreen
import com.bru.gameboost.presentation.screens.GamePickerScreen
import com.bru.gameboost.presentation.theme.GameBoostTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GameBoostViewModel by viewModels {
        GameBoostViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProvideLifecycleOwnerCompat {
                GameBoostTheme {
                    // Saveable, so rotating the phone doesn't throw the user back to the list.
                    var showAddGame by rememberSaveable { mutableStateOf(false) }

                    // Two screens, one Activity: without this, Back (right there in 3-button
                    // navigation) would exit the app from the Add screen instead of returning.
                    BackHandler(enabled = showAddGame) { showAddGame = false }

                    if (showAddGame) {
                        AddGameScreen(
                            viewModel = viewModel,
                            onDone = { showAddGame = false }
                        )
                    } else {
                        GamePickerScreen(
                            viewModel = viewModel,
                            onAddGameClick = { showAddGame = true }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // The DND / usage-access grants happen in a separate Settings screen,
        // so this is the reliable point to notice the user came back from it.
        viewModel.refreshPermissionState()
    }
}
