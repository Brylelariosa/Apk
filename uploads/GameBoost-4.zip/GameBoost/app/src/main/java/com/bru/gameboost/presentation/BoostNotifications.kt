package com.bru.gameboost.presentation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.bru.gameboost.R

/**
 * Builds and posts every notification the boost flow uses, so the service
 * only decides *when* something should be shown, not what it looks like.
 */
class BoostNotifications(private val context: Context) {

    private val manager: NotificationManager =
        context.getSystemService(NotificationManager::class.java)

    fun ensureChannels() {
        manager.createNotificationChannel(
            NotificationChannel(
                SESSION_CHANNEL_ID,
                "Boost session",
                NotificationManager.IMPORTANCE_LOW // no sound/heads-up for a stats readout
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                HEAT_CHANNEL_ID,
                "Overheating alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(null, null) // may pop up, but never makes noise over the game
                enableVibration(false)
            }
        )
    }

    /** The ongoing session notification; also what the service hands to startForeground(). */
    fun session(title: String, text: String): Notification {
        val stopIntent = PendingIntent.getService(
            context,
            0,
            Intent(context, BoostSessionService::class.java).setAction(BoostSessionService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            ),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(context, SESSION_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_notification_boost)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "End boost", stopIntent)
            .build()
    }

    fun updateSession(title: String, text: String) {
        manager.notify(SESSION_ID, session(title, text))
    }

    fun postHeatWarning(tempC: Float?, charging: Boolean?) {
        val text = buildString {
            if (tempC != null) append("Battery at ${SnapshotFormatter.temperature(tempC)}. ")
            append("Lower the graphics or take a short break")
            append(if (charging == true) ", and unplug the charger while you play." else ".")
        }
        val notification = NotificationCompat.Builder(context, HEAT_CHANNEL_ID)
            .setContentTitle("Phone is running hot")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_notification_boost)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        manager.notify(HEAT_ID, notification)
    }

    fun clearHeatWarning() {
        manager.cancel(HEAT_ID)
    }

    companion object {
        const val SESSION_ID = 1001
        private const val HEAT_ID = 1002
        private const val SESSION_CHANNEL_ID = "boost_session"
        private const val HEAT_CHANNEL_ID = "overheat_alert"
    }
}
