package com.bru.gameboost.presentation.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.gameboost.domain.model.BoostSessionState
import com.bru.gameboost.domain.model.BoostSettings
import com.bru.gameboost.domain.model.BoostableGame
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.PermissionState
import com.bru.gameboost.presentation.GameBoostViewModel
import com.bru.gameboost.presentation.RamCleanState
import com.bru.gameboost.presentation.SnapshotFormatter

// The FAB (56 dp + margins) floats over the bottom-right corner, exactly where the last
// row's Boost/Remove buttons sit. Without this much room under the list they're unreachable.
private val FabClearance = 88.dp

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar
@Composable
fun GamePickerScreen(
    viewModel: GameBoostViewModel,
    onAddGameClick: () -> Unit
) {
    val context = LocalContext.current
    val games by viewModel.addedGames.collectAsStateWithLifecycle()
    val permissionState by viewModel.permissionState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val snapshot by viewModel.deviceSnapshot.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val ramClean by viewModel.ramClean.collectAsStateWithLifecycle()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshPermissionState() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("GameBoost") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddGameClick) {
                Icon(Icons.Default.Add, contentDescription = "Add game")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = FabClearance),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                DeviceStatsCard(
                    snapshot = snapshot,
                    ramClean = ramClean,
                    onFreeRam = viewModel::freeRamNow,
                    onOpenBatterySaver = {
                        context.openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                    }
                )
            }

            if (!permissionState.allGranted) {
                item {
                    PermissionsCard(
                        state = permissionState,
                        onRequestNotifications = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                // No runtime prompt exists before Android 13; the switch lives in Settings.
                                context.openNotificationSettings()
                            }
                        },
                        onOpenDndSettings = {
                            context.openSettings(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        },
                        onOpenUsageSettings = { context.openUsageAccessSettings() }
                    )
                }
            }

            val activeState = sessionState as? BoostSessionState.Active
            if (activeState != null) {
                item {
                    ActiveSessionCard(state = activeState, onEndBoost = viewModel::endBoost)
                }
            }

            item {
                BoostOptionsCard(
                    settings = settings,
                    onSilenceNotificationsChange = viewModel::setSilenceNotifications,
                    onFreeRamChange = viewModel::setFreeRamOnBoost
                )
            }

            if (games.isEmpty()) {
                item { EmptyGamesHint() }
            } else {
                items(games, key = { it.packageName }) { game ->
                    GameRow(
                        game = game,
                        isBoosting = game.packageName == activeState?.game?.packageName,
                        onBoostClick = { viewModel.boostAndLaunch(game) },
                        onRemoveClick = { viewModel.removeGame(game.packageName) }
                    )
                }
            }
        }
    }
}

private val PermissionState.allGranted: Boolean
    get() = notificationPolicyAccessGranted && usageAccessGranted && notificationsEnabled

@Composable
private fun DeviceStatsCard(
    snapshot: DeviceSnapshot?,
    ramClean: RamCleanState,
    onFreeRam: () -> Unit,
    onOpenBatterySaver: () -> Unit
) {
    val lastClean = ramClean.last
    val cleanLine = when {
        ramClean.running -> "Closing cached background apps…"
        lastClean != null -> SnapshotFormatter.cleanSummary(lastClean)
        else -> "Closes cached background apps to free memory."
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("This device right now", style = MaterialTheme.typography.titleMedium)
            SnapshotFormatter.screenLines(snapshot).forEach { line ->
                Text(
                    line,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (snapshot?.powerSaveMode == true) {
                TextWithAction(
                    text = "Battery Saver is on — it can limit performance while you play.",
                    actionLabel = "Settings",
                    onAction = onOpenBatterySaver,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            TextWithAction(
                text = cleanLine,
                actionLabel = "Free RAM",
                onAction = onFreeRam,
                actionEnabled = !ramClean.running,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun BoostOptionsCard(
    settings: BoostSettings,
    onSilenceNotificationsChange: (Boolean) -> Unit,
    onFreeRamChange: (Boolean) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("When boosting", style = MaterialTheme.typography.titleMedium)
            SwitchRow(
                label = "Silence notifications (Do Not Disturb)",
                checked = settings.silenceNotifications,
                onCheckedChange = onSilenceNotificationsChange
            )
            SwitchRow(
                label = "Free RAM first (closes cached background apps)",
                checked = settings.freeRamOnBoost,
                onCheckedChange = onFreeRamChange
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

/** Small explanatory text with one action on the right; the text yields space to the button, not the reverse. */
@Composable
private fun TextWithAction(
    text: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
    actionEnabled: Boolean = true
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(onClick = onAction, enabled = actionEnabled) { Text(actionLabel) }
    }
}

@Composable
private fun PermissionsCard(
    state: PermissionState,
    onRequestNotifications: () -> Unit,
    onOpenDndSettings: () -> Unit,
    onOpenUsageSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("A few permissions unlock more of this", style = MaterialTheme.typography.titleMedium)
            Text(
                "Everything works without them too — boosting just does less.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            if (!state.notificationsEnabled) {
                PermissionRow("Show the live boost notification", onRequestNotifications)
            }
            if (!state.notificationPolicyAccessGranted) {
                PermissionRow("Do Not Disturb access (silences alerts while boosting)", onOpenDndSettings)
            }
            if (!state.usageAccessGranted) {
                PermissionRow("Usage access (ends the boost automatically when you quit)", onOpenUsageSettings)
            }
        }
    }
}

@Composable
private fun PermissionRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        TextButton(onClick = onClick) { Text("Grant") }
    }
}

@Composable
private fun ActiveSessionCard(state: BoostSessionState.Active, onEndBoost: () -> Unit) {
    val cleanResult = state.cleanResult
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text("Boosting ${state.game.label}", style = MaterialTheme.typography.titleMedium)
                if (cleanResult != null) {
                    Text(
                        SnapshotFormatter.cleanSummary(cleanResult),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            TextButton(onClick = onEndBoost) { Text("End") }
        }
    }
}

@Composable
private fun EmptyGamesHint() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No games added yet", style = MaterialTheme.typography.titleMedium)
        Text(
            "Tap + to pick one from your installed apps.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun GameRow(
    game: BoostableGame,
    isBoosting: Boolean,
    onBoostClick: () -> Unit,
    onRemoveClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // weight(1f): a long title wraps or truncates instead of squeezing the buttons off the card.
            Text(
                game.label,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onBoostClick, enabled = !isBoosting) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Text(if (isBoosting) " Boosting" else " Boost", modifier = Modifier.padding(start = 4.dp))
                }
                IconButton(onClick = onRemoveClick) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove ${game.label}")
                }
            }
        }
    }
}

/** Settings screens differ by OEM; a missing one should do nothing rather than crash the app. */
private fun Context.openSettings(intent: Intent) {
    runCatching { startActivity(intent) }
}

private fun Context.openUsageAccessSettings() {
    // Android 10+ can jump straight to this app's toggle; fall back to the full list where that isn't honored.
    val forThisApp = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.fromParts("package", packageName, null))
    if (runCatching { startActivity(forThisApp) }.isFailure) {
        openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}

private fun Context.openNotificationSettings() {
    openSettings(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    )
}
