package com.bru.gameboost.domain.model

/** An installed, launchable app the user has added to their boost list. */
data class BoostableGame(
    val packageName: String,
    val label: String
)

/**
 * PowerManager's thermal levels (API 29+), mirrored here so the domain layer
 * doesn't leak a platform enum. UNKNOWN covers API < 29 or a failed read —
 * callers should hide the thermal row rather than show a false reading.
 */
enum class ThermalStatus {
    NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNKNOWN;

    /** True once the platform itself reports throttling heavy enough to cost frame rate. */
    val isSevere: Boolean get() = this in SEVERE..SHUTDOWN
}

/**
 * One tick of device stats. Every field is nullable and independently
 * optional — a read that fails (or isn't available on this API level)
 * degrades that one field rather than the whole snapshot.
 *
 * [batteryTempC] is the dependable heat signal: not every vendor feeds
 * PowerManager's thermal status, while the battery sensor is always there.
 */
data class DeviceSnapshot(
    val cpuLoadPercent: Float?,
    val ramUsedMb: Long?,
    val ramTotalMb: Long?,
    val batteryPercent: Int?,
    val batteryTempC: Float?,
    val isCharging: Boolean?,
    val thermalStatus: ThermalStatus?,
    val powerSaveMode: Boolean?
)

/** What a RAM clean achieved; [freedMb] is an estimate from before/after free-memory readings. */
data class CleanResult(
    val appsChecked: Int,
    val freedMb: Long
)

/** The on/off switches for the individual steps of a boost. */
data class BoostSettings(
    val silenceNotifications: Boolean = true,
    val freeRamOnBoost: Boolean = true
)

/** Which of the special, Settings-granted permissions this app currently holds. */
data class PermissionState(
    val notificationPolicyAccessGranted: Boolean,
    val usageAccessGranted: Boolean,
    val notificationsEnabled: Boolean
)

/** Whether a boost session is currently applied, and for which game. */
sealed interface BoostSessionState {
    data object Idle : BoostSessionState
    data class Active(
        val game: BoostableGame,
        val cleanResult: CleanResult? = null
    ) : BoostSessionState
}
