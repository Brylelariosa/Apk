package com.bru.gameboost.presentation

import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.ThermalStatus
import java.util.Locale
import kotlin.math.roundToInt

/** The one place snapshots become text, so the notification and the picker screen never disagree. */
object SnapshotFormatter {

    /** Notification body: stats on the first line, then what the RAM clean freed (if one ran). */
    fun notificationText(snapshot: DeviceSnapshot?, cleanResult: CleanResult?): String {
        val stats = if (snapshot == null) {
            "Starting up…"
        } else {
            listOfNotNull(
                "CPU ${cpu(snapshot)}",
                "RAM ${ram(snapshot)}",
                snapshot.batteryTempC?.let { temperature(it) },
                "Batt ${battery(snapshot)}",
                throttling(snapshot)
            ).joinToString(" · ")
        }
        return if (cleanResult == null) stats else "$stats\n${cleanSummary(cleanResult)}"
    }

    /** Lines for the picker's device card. */
    fun screenLines(snapshot: DeviceSnapshot?): List<String> {
        if (snapshot == null) return listOf("Reading…")
        return listOfNotNull(
            "CPU ${cpu(snapshot)} · RAM ${ram(snapshot)}",
            listOfNotNull(
                "Battery ${battery(snapshot)}",
                snapshot.batteryTempC?.let { temperature(it) }
            ).joinToString(" · "),
            throttling(snapshot)
        )
    }

    fun cleanSummary(result: CleanResult): String =
        if (result.freedMb > 0) {
            "Freed ≈ ${result.freedMb} MB · ${result.appsChecked} apps checked"
        } else {
            "Nothing left to free · ${result.appsChecked} apps checked"
        }

    fun temperature(tempC: Float): String = String.format(Locale.getDefault(), "%.1f°C", tempC)

    private fun cpu(snapshot: DeviceSnapshot): String =
        snapshot.cpuLoadPercent?.let { "${it.roundToInt()}%" } ?: "—"

    private fun ram(snapshot: DeviceSnapshot): String {
        val used = snapshot.ramUsedMb
        val total = snapshot.ramTotalMb
        return if (used != null && total != null) "${gigabytes(used)}/${gigabytes(total)} GB" else "—"
    }

    private fun gigabytes(mb: Long): String = String.format(Locale.getDefault(), "%.1f", mb / 1024.0)

    private fun battery(snapshot: DeviceSnapshot): String {
        val percent = snapshot.batteryPercent?.let { "$it%" } ?: "—"
        return if (snapshot.isCharging == true) "$percent (charging)" else percent
    }

    /** Only worth a mention once the platform itself reports throttling. */
    private fun throttling(snapshot: DeviceSnapshot): String? {
        val status = snapshot.thermalStatus ?: return null
        if (status == ThermalStatus.NONE || status == ThermalStatus.UNKNOWN) return null
        return "Thermal ${status.name.lowercase()}"
    }
}
