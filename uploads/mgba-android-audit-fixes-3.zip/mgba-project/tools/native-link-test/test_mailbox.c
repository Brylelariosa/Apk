#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "../../app/src/main/cpp/link_mailbox.h"

static int fails = 0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)

/* ---- a fake child "game thread": every ~frame_us it does what nativeRunFrame does ---- */
typedef struct {
    LinkMailbox *mb;
    volatile int run;
    int frame_us;
    int frame_work_us;
    volatile uint16_t send_reg;     /* the ROM's SIOMLT_SEND */
    volatile uint16_t seen_host;    /* what the ISR last read from SIOMULTI0 */
    volatile int isr_count;
    volatile int frames;
    uint16_t seen_log[4096];
    int seen_n;
} FakeChild;

static void *game_thread(void *arg) {
    FakeChild *c = arg;
    while (c->run) {
        uint16_t h, st; bool delivered = lm_take_request(c->mb, &h, &st); (void)st;
        if (delivered) {
            lm_set_reply(c->mb, c->send_reg);          /* data on the wire = SIOMLT_SEND at delivery time */
            c->seen_host = h;                          /* "regs written + IRQ raised" */
            lm_complete(c->mb);                        /* released at delivery, as in link_child_deliver_pending() */
        }
        usleep((useconds_t)c->frame_work_us);          /* runFrame(): the ISR runs in here */
        if (delivered) {
            c->isr_count++;
            c->seen_log[c->seen_n++ % 4096] = c->seen_host;
            c->send_reg = (uint16_t)(c->seen_host + 1000);   /* ISR stages next word from what it received */
        }
        c->frames++;
        usleep((useconds_t)(c->frame_us - c->frame_work_us > 0 ? c->frame_us - c->frame_work_us : 0));
    }
    return NULL;
}

typedef struct { LinkMailbox *mb; int rc; uint16_t data; int timeout_ms; } Waiter;
static void *waiter_fn(void *a) {
    Waiter *x = a; uint32_t rr = 0;
    x->rc = lm_post_and_wait(x->mb, x->data, 0, x->timeout_ms, &rr);
    return NULL;
}


/* helpers used by the clock-tie tests below (file scope: nested functions that capture locals need an
 * executable stack and crash under ASan) */
typedef struct { LinkMailbox *mb; int rc; uint32_t reply; uint16_t data; uint16_t stamp; int delay_us; int timeout_ms; } PostJob;
static void *post_job_thread(void *a) {
    PostJob *x = a;
    if (x->delay_us) usleep((useconds_t)x->delay_us);
    x->rc = lm_post_and_wait(x->mb, x->data, x->stamp, x->timeout_ms, &x->reply);
    return NULL;
}
typedef struct { LinkMailbox *mb; int delay_us; } CloseJob;
static void *close_job_thread(void *a) { CloseJob *x = a; usleep((useconds_t)x->delay_us); lm_close(x->mb); return NULL; }

int main(void) {
    LinkMailbox mb; lm_init(&mb);

    printf("== closed mailbox refuses work\n");
    { uint32_t r=0; CHECK(lm_post_and_wait(&mb,1,0,50,&r)==LM_ABORTED,"post on a closed mailbox -> ABORTED"); }

    lm_open(&mb);
    FakeChild ch = { .mb=&mb, .run=1, .frame_us=16000, .frame_work_us=3000, .send_reg=0x1111 };
    pthread_t gt; pthread_create(&gt,NULL,game_thread,&ch);

    printf("== lock-step: 200 back-to-back requests, none lost, none duplicated, replies in order\n");
    {
        int ok=0, bad_reply=0; uint32_t prevReply = 0x1111;
        for (int i = 0; i < 200; i++) {
            uint32_t reply = 0;
            int rc = lm_post_and_wait(&mb, (uint16_t)(0x4000 + i), (uint16_t)i, 500, &reply);
            if (rc == LM_OK) {
                ok++;
                /* reply must be the child's word staged by the ISR for the PREVIOUS transfer */
                uint16_t expect = (i == 0) ? 0x1111 : (uint16_t)((0x4000 + i - 1) + 1000);
                if (reply != expect) bad_reply++;
            }
            (void)prevReply;
        }
        /* The 200th reply is released at delivery, so that frame's ISR is still running; let it finish. */
        for (int w = 0; w < 200 && ch.isr_count < 200; w++) usleep(1000);
        CHECK(ok==200,"all 200 requests got a reply");
        CHECK(bad_reply==0,"every reply carried the data the ISR staged for the PREVIOUS transfer (no aliasing, no merging)");
        CHECK(ch.isr_count==200,"child ISR ran exactly once per transfer (200)");
        int in_order = 1; for (int i=0;i<200;i++) if (ch.seen_log[i] != (uint16_t)(0x4000+i)) in_order = 0;
        CHECK(in_order,"child saw host words 0x4000..0x40C7 in order, none skipped");
    }

    printf("== at most one transfer per child frame (the lock-step guarantee)\n");
    {
        struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a);
        for (int i=0;i<20;i++){ uint32_t r; lm_post_and_wait(&mb,(uint16_t)i,0,500,&r); }
        clock_gettime(CLOCK_MONOTONIC,&b);
        double ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        printf("      20 exchanges took %.0f ms (%.1f ms each, child frame = 16 ms)\n", ms, ms/20);
        CHECK(ms/20 > 8.0 && ms/20 < 40.0,"throughput is capped at one transfer per child frame (not zero latency, not runaway)");
    }

    printf("== timeout when the child isn't running frames\n");
    ch.run = 0; pthread_join(gt,NULL);
    {
        uint32_t r=0; struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a);
        int rc = lm_post_and_wait(&mb, 7, 0, 80, &r);
        clock_gettime(CLOCK_MONOTONIC,&b);
        double ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        CHECK(rc==LM_TIMEOUT,"no game thread -> TIMEOUT");
        CHECK(ms>=70 && ms<200,"... after about the requested 80 ms");
        /* the withdrawn request must not be delivered later */
        uint16_t h, st; CHECK(!lm_take_request(&mb,&h,&st),"withdrawn request is not delivered afterwards");
    }

    printf("== waiter gives up mid-frame (DELIVERED), then slot recovers\n");
    {
        /* manual game thread so we control timing */
        uint16_t h, st; uint32_t r=0;
        pthread_t t;
        Waiter w = { &mb, 99, 0xAAAA, 60 };
        pthread_create(&t,NULL,waiter_fn,&w);
        usleep(10000);
        CHECK(lm_take_request(&mb,&h,&st) && h==0xAAAA,"game thread takes the request");
        lm_set_reply(&mb,0xBBBB);
        pthread_join(t,NULL);                         /* waiter times out before the game thread finishes with the slot */
        CHECK(w.rc==LM_TIMEOUT,"waiter times out while the slot is still DELIVERED");
        lm_complete(&mb);                             /* must free the slot, not signal a stale DONE */
        r = 0;
        pthread_t g2; ch.run=1; pthread_create(&g2,NULL,game_thread,&ch);
        int rc = lm_post_and_wait(&mb, 0xCCCC, 0, 500, &r);
        CHECK(rc==LM_OK,"next request works normally after an abandoned frame");
        ch.run=0; pthread_join(g2,NULL);
        lm_close(&mb); lm_open(&mb);
    }

    printf("== close wakes a blocked waiter\n");
    {
        Waiter w = { &mb, 99, 1, 5000 };
        pthread_t t; pthread_create(&t,NULL,waiter_fn,&w);
        usleep(30000);
        struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a);
        lm_close(&mb);
        pthread_join(t,NULL);
        clock_gettime(CLOCK_MONOTONIC,&b);
        double ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        CHECK(w.rc==LM_ABORTED && ms < 200,"lm_close() releases a 5 s waiter immediately with ABORTED");
        uint16_t h, st; CHECK(!lm_take_request(&mb,&h,&st),"closed mailbox delivers nothing");
    }

    printf("== clock tie: stamp travels with the word; the 32-bit reply (word + flags) survives\n");
    {
        lm_close(&mb); lm_open(&mb);
        uint16_t h = 0, st = 0;
        pthread_t t;
        PostJob pj = { &mb, 99, 0, 0x2468, 0xBEEF, 0, 500 };
        pthread_create(&t, NULL, post_job_thread, &pj);
        usleep(15000);
        CHECK(lm_peek_request(&mb, &h, &st) && h == 0x2468 && st == 0xBEEF, "peek shows word and stamp without taking them");
        CHECK(lm_peek_request(&mb, &h, &st), "peeking twice still shows it (nothing was consumed)");
        CHECK(lm_take_request(&mb, &h, &st) && h == 0x2468 && st == 0xBEEF, "take returns the same word and stamp");
        CHECK(!lm_peek_request(&mb, &h, &st), "after take there is nothing to peek");
        lm_set_reply(&mb, 0x00010000u | 0xABCD);                 /* flags 0x01 in bits 16-23, word 0xABCD */
        lm_complete(&mb);
        pthread_join(t, NULL);
        CHECK(pj.rc == LM_OK && pj.reply == 0x0001ABCDu, "waiter gets the full 32-bit reply (word + flags)");
    }

    printf("== clock tie: lm_wait_posted — the child's 'hold'\n");
    {
        lm_close(&mb); lm_open(&mb);
        struct timespec a, b; double ms; uint16_t h, st;
        clock_gettime(CLOCK_MONOTONIC, &a);
        bool got = lm_wait_posted(&mb, 40);
        clock_gettime(CLOCK_MONOTONIC, &b);
        ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        CHECK(!got && ms >= 35 && ms < 150, "nothing posted: returns false after about the timeout");

        pthread_t t;
        PostJob late = { &mb, 99, 0, 0x7777, 3, 15000, 500 };
        pthread_create(&t, NULL, post_job_thread, &late);
        clock_gettime(CLOCK_MONOTONIC, &a);
        got = lm_wait_posted(&mb, 500);
        clock_gettime(CLOCK_MONOTONIC, &b);
        ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        CHECK(got && ms >= 10 && ms < 200, "a word posted during the wait wakes it at once (true)");
        CHECK(lm_take_request(&mb,&h,&st) && h==0x7777 && st==3, "...and it is still there to take");
        lm_set_reply(&mb, 1); lm_complete(&mb); pthread_join(t, NULL);

        PostJob early = { &mb, 99, 0, 0x8888, 0, 0, 300 };
        pthread_create(&t, NULL, post_job_thread, &early);
        usleep(20000);
        clock_gettime(CLOCK_MONOTONIC, &a); got = lm_wait_posted(&mb, 500); clock_gettime(CLOCK_MONOTONIC, &b);
        ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        CHECK(got && ms < 20, "already posted: returns immediately");
        lm_take_request(&mb,&h,&st); lm_set_reply(&mb, 1); lm_complete(&mb); pthread_join(t, NULL);

        CloseJob cj = { &mb, 15000 };
        pthread_create(&t, NULL, close_job_thread, &cj);
        clock_gettime(CLOCK_MONOTONIC, &a); got = lm_wait_posted(&mb, 2000); clock_gettime(CLOCK_MONOTONIC, &b);
        ms = (b.tv_sec-a.tv_sec)*1000.0 + (b.tv_nsec-a.tv_nsec)/1e6;
        pthread_join(t, NULL);
        CHECK(!got && ms < 300, "lm_close() wakes the wait immediately (false)");
    }

    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
