/* Shared stand-ins for the JNI / mGBA types that the code extracted from
 * app/src/main/cpp/mgba_jni.c touches. Used by test_sio_regs.c and
 * sim_dev.c. Everything here is deliberately tiny: just enough of each API for
 * the REAL link code to compile and run unmodified on a desktop with gcc.
 *
 * The timing queue is a real sorted list (the old one-slot stub could not hold
 * the clock-tie tick and the transfer-completion event at the same time) and,
 * like mGBA's own queue, it is threaded through the events themselves — so
 * scheduling an event that is already queued is counted as a corruption. */
#ifndef LINK_TEST_STUBS_H
#define LINK_TEST_STUBS_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

/* ---- JNI ---------------------------------------------------------------- */
typedef int jint; typedef void *jobject; typedef void *jmethodID; typedef void *jthrowable;
typedef void *jclass; typedef void *jstring; typedef unsigned char jboolean;
#define JNI_TRUE 1
#define JNI_FALSE 0
struct JNINativeInterface_;
typedef const struct JNINativeInterface_ *JNIEnv;
struct JNINativeInterface_ {
    jint       (*CallIntMethod)(JNIEnv *, jobject, jmethodID, ...);
    jthrowable (*ExceptionOccurred)(JNIEnv *);
    void       (*ExceptionClear)(JNIEnv *);
    jclass     (*GetObjectClass)(JNIEnv *, jobject);
    jmethodID  (*GetMethodID)(JNIEnv *, jclass, const char *, const char *);
    void       (*DeleteLocalRef)(JNIEnv *, jobject);
    jobject    (*NewGlobalRef)(JNIEnv *, jobject);
    void       (*DeleteGlobalRef)(JNIEnv *, jobject);
    const char*(*GetStringUTFChars)(JNIEnv *, jstring, jboolean *);
    void       (*ReleaseStringUTFChars)(JNIEnv *, jstring, const char *);
};
#define JNIEXPORT
#define JNICALL

/* The "Kotlin" side of jniExchangeData(I,I): whoever includes this header sets
 * the hook. Default = the scripted reply the register tests use. */
static int g_calls = 0, g_last_sent = -1, g_last_stamp = -1;
static jint g_script_reply = 0;
static jint (*g_xchg_hook)(int data, int stamp) = NULL;
static char g_method_sig[32] = {0};
static jint f_call(JNIEnv *e, jobject o, jmethodID m, ...) {
    (void)e; (void)o; (void)m;
    va_list ap; va_start(ap, m);
    int d = va_arg(ap, int); int st = va_arg(ap, int);
    va_end(ap);
    g_calls++; g_last_sent = d; g_last_stamp = st;
    return g_xchg_hook ? g_xchg_hook(d, st) : g_script_reply;
}
static jthrowable f_exc(JNIEnv *e) { (void)e; return NULL; }
static void f_clr(JNIEnv *e) { (void)e; }
static int g_dummy_class, g_dummy_mid;
static jclass f_getclass(JNIEnv *e, jobject o) { (void)e; (void)o; return &g_dummy_class; }
static jmethodID f_getmid(JNIEnv *e, jclass c, const char *n, const char *sig) {
    (void)e; (void)c; (void)n; snprintf(g_method_sig, sizeof g_method_sig, "%s", sig);
    return strcmp(n, "jniExchangeData") == 0 ? (jmethodID)&g_dummy_mid : NULL;
}
static void f_delref(JNIEnv *e, jobject o) { (void)e; (void)o; }
static jobject f_newglobal(JNIEnv *e, jobject o) { (void)e; return o; }
static const char *f_getstr(JNIEnv *e, jstring s, jboolean *c) { (void)e; (void)c; return (const char *)s; }
static void f_relstr(JNIEnv *e, jstring s, const char *c) { (void)e; (void)s; (void)c; }
static const struct JNINativeInterface_ g_iface = {
    f_call, f_exc, f_clr, f_getclass, f_getmid, f_delref, f_newglobal, f_delref, f_getstr, f_relstr
};
static JNIEnv g_env = &g_iface;

/* ---- mGBA --------------------------------------------------------------- */
struct GBASIODriver {
    void *p;
    bool (*init)(struct GBASIODriver *); void (*deinit)(struct GBASIODriver *);
    bool (*load)(struct GBASIODriver *);  bool (*unload)(struct GBASIODriver *);
    uint16_t (*writeRegister)(struct GBASIODriver *, uint32_t, uint16_t);
};
struct GBASIO { uint16_t rcnt, siocnt; struct GBASIODriver *drv; };
enum { SIO_MULTI = 2 };
static void GBASIOSetDriver(struct GBASIO *sio, struct GBASIODriver *drv, int mode) { (void)mode; sio->drv = drv; }

struct mTiming;
struct mTimingEvent {
    void *context; void (*callback)(struct mTiming *, void *, uint32_t);
    const char *name; uint32_t when; unsigned priority;
    int64_t when64; struct mTimingEvent *next; bool queued;
};
struct mTiming { struct mTimingEvent *head; int64_t now; };
struct GBA { struct GBASIO sio; struct { uint16_t io[0x200]; } memory; struct mTiming timing; };
static int g_double_schedules = 0, g_schedule_calls = 0;
static void mTimingSchedule(struct mTiming *t, struct mTimingEvent *e, int32_t when) {
    g_schedule_calls++;
    if (e->queued) { g_double_schedules++; return; }       /* real mGBA would corrupt its list */
    e->when64 = t->now + when; e->queued = true;
    struct mTimingEvent **pp = &t->head;
    while (*pp && (*pp)->when64 <= e->when64) pp = &(*pp)->next;
    e->next = *pp; *pp = e;
}
/* Advance emulated time by `cycles`, firing every event that falls due, in order
 * (events may re-schedule themselves). */
static void timing_advance(struct GBA *g, int64_t cycles) {
    struct mTiming *t = &g->timing;
    int64_t target = t->now + cycles;
    for (;;) {
        struct mTimingEvent *e = t->head;
        if (!e || e->when64 > target) break;
        t->head = e->next; e->next = NULL; e->queued = false;
        t->now = e->when64;
        e->callback(t, e->context, 0u);
    }
    t->now = target;
}
static void timing_clear(struct GBA *g) {
    struct mTimingEvent *e = g->timing.head;
    while (e) { struct mTimingEvent *n = e->next; e->next = NULL; e->queued = false; e = n; }
    g->timing.head = NULL;
}
struct mCore { void *board; };
#define GBA_IRQ_SIO 7
#define GBA_AUDIO_CLOCK 16777216
static int g_irq_count = 0;
static void GBARaiseIRQ(struct GBA *g, int irq, int late) { (void)g; (void)irq; (void)late; g_irq_count++; }

/* Logging: tests keep it silent; the simulator redefines LINK_TEST_LOG before including. */
#ifdef LINK_TEST_LOG
void link_test_log(const char *level, const char *fmt, ...);
#define LOGI(...) link_test_log("I", __VA_ARGS__)
#define LOGW(...) link_test_log("W", __VA_ARGS__)
#define LOGE(...) link_test_log("E", __VA_ARGS__)
#else
#define LOGI(...) do {} while (0)
#define LOGW(...) do {} while (0)
#define LOGE(...) do {} while (0)
#endif

/* File-level pieces mgba_jni.c normally provides before the extracted regions. */
static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore g_core_obj; static struct mCore *g_core = &g_core_obj;
#ifndef LINK_TEST_REAL_LOG
static pthread_mutex_t g_link_log_mutex = PTHREAD_MUTEX_INITIALIZER;
static FILE *g_link_log_file = NULL;
static char g_link_log_path[512] = {0};
static void link_log_begin_locked(void) {}
static void link_log_write_locked(const char *level, const char *tag, const char *msg) {
    (void)level; (void)tag; (void)msg;
}
#endif

#endif
