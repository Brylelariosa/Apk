/* Tests the REAL link-log file code extracted from mgba_jni.c: format, session begin, size-cap rotation
 * (no data loss across the two newest segments), and — the bug that motivated it — that concurrent
 * writers (native lines from several threads + Kotlin lines through nativeLinkLog) never corrupt
 * or interleave each other's lines. */
#define LINK_TEST_REAL_LOG
#include "link_test_stubs.h"
#include <regex.h>
#include <sys/stat.h>
#define LOG_TAG "mGBA-JNI"
#include "extracted_rlog.c"
#include "extracted_r5.c"

static int fails = 0;
#define CHECK(c, m) do { if (c) printf("PASS  %s\n", m); else { printf("FAIL  %s\n", m); fails++; } } while (0)

static long fsize(const char *p) { struct stat st; return stat(p, &st) == 0 ? (long)st.st_size : -1; }
static char *slurp(const char *p, long *n) {
    FILE *f = fopen(p, "rb"); if (!f) { *n = -1; return NULL; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)sz + 1); size_t r = fread(b, 1, (size_t)sz, f); b[r] = 0; fclose(f); *n = (long)r; return b;
}
static int count_lines(const char *b) { int n = 0; for (; *b; b++) if (*b == '\n') n++; return n; }

static void *writer_native(void *a) {
    int id = (int)(intptr_t)a; char m[64];
    for (int i = 0; i < 400; i++) { snprintf(m, sizeof m, "native t%d line %d payload-payload-payload", id, i); link_log_write("I", m); }
    return NULL;
}
static void *writer_kotlin(void *a) {
    (void)a; char m[64];
    for (int i = 0; i < 400; i++) { snprintf(m, sizeof m, "kotlin line %d payload-payload-payload", i);
        Java_com_mgba_android_EmulatorEngine_nativeLinkLog(&g_env, NULL, i % 3, (jstring)m); }
    return NULL;
}

int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    char path[] = "/tmp/linklogtestXXXXXX"; int fd = mkstemp(path); close(fd);
    snprintf(g_link_log_path, sizeof g_link_log_path, "%s", path);
    char prev[600]; snprintf(prev, sizeof prev, "%s.1", path);

    printf("== no file open: writes are dropped, nothing crashes\n");
    link_log_write("I", "dropped"); 
    CHECK(g_link_log_file == NULL, "no FILE* opened by a write");

    printf("== nativeLinkLogBegin: fresh file, header format\n");
    Java_com_mgba_android_EmulatorEngine_nativeLinkLogBegin(&g_env, NULL);
    link_log_write("I", "hello");
    Java_com_mgba_android_EmulatorEngine_nativeLinkLog(&g_env, NULL, 1, (jstring)"from kotlin");
    long n; char *b = slurp(path, &n);
    regex_t re; regcomp(&re, "^[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\\.[0-9][0-9][0-9] [IWE] [A-Za-z-]+: .*$", REG_EXTENDED | REG_NEWLINE);
    CHECK(n > 0 && strstr(b, " I mGBA-JNI: hello\n") && strstr(b, " W mGBA-Link: from kotlin\n"), "native line tagged mGBA-JNI, Kotlin line tagged mGBA-Link with level W");
    CHECK(regexec(&re, b, 0, NULL, 0) == 0, "lines match the logcat-style layout");
    free(b);

    printf("== Begin again: truncates, drops the older segment\n");
    { FILE *f = fopen(prev, "w"); fputs("old segment\n", f); fclose(f); }
    Java_com_mgba_android_EmulatorEngine_nativeLinkLogBegin(&g_env, NULL);
    CHECK(fsize(path) == 0 && fsize(prev) == -1, "file empty again, '.1' removed");

    printf("== concurrent writers: no corrupted or interleaved lines\n");
    pthread_t t[5];
    for (int i = 0; i < 4; i++) pthread_create(&t[i], NULL, writer_native, (void *)(intptr_t)i);
    pthread_create(&t[4], NULL, writer_kotlin, NULL);
    for (int i = 0; i < 5; i++) pthread_join(t[i], NULL);
    b = slurp(path, &n);
    int lines = count_lines(b);
    CHECK(lines == 4 * 400 + 400, "all 2000 lines present");
    int bad = 0; char *save = NULL; char *cp = strdup(b);
    for (char *ln = strtok_r(cp, "\n", &save); ln; ln = strtok_r(NULL, "\n", &save)) {
        char one[512]; snprintf(one, sizeof one, "%s\n", ln);
        if (regexec(&re, one, 0, NULL, 0) != 0) bad++;
        else if (!(strstr(ln, "payload-payload-payload") && (strstr(ln, "native t") || strstr(ln, "kotlin line")))) bad++;
    }
    free(cp); free(b);
    CHECK(bad == 0, "every line is complete and well-formed (single writer, append mode)");

    printf("== size cap: rotates to '.1', keeps the newest two segments, loses nothing recent\n");
    /* shrink the cap for the test by writing past it: use a tiny effective cap via the byte counter */
    Java_com_mgba_android_EmulatorEngine_nativeLinkLogBegin(&g_env, NULL);
    long cap = LINK_LOG_MAX_BYTES;
    char big[1024]; memset(big, 'x', 1000); big[1000] = 0;
    long written = 0; int seq = 0;
    while (written < cap * 2 + 5000) {              /* ~24 MB: enough for two rotations */
        char m[1100]; snprintf(m, sizeof m, "seq=%06d %s", seq++, big);
        link_log_write("I", m); written += 1000;
    }
    long cur = fsize(path), old = fsize(prev);
    CHECK(old > 0 && cur >= 0 && cur <= cap + 2000, "current segment stays within the cap; '.1' exists");
    char *bc = slurp(path, &n); char *bp = slurp(prev, &n);
    char want[32]; snprintf(want, sizeof want, "seq=%06d ", seq - 1);
    CHECK(strstr(bc, want) != NULL, "the very last line written is in the current segment");
    /* the last line of '.1' and the first of current must be consecutive (nothing lost at the seam) */
    int last_prev = -1, first_cur = -1;
    { char *p = bp; char *q; while ((q = strstr(p, "seq=")) != NULL) { last_prev = atoi(q + 4); p = q + 4; } }
    first_cur = atoi(strstr(bc, "seq=") + 4);
    CHECK(last_prev + 1 == first_cur, "no line lost at the rotation seam");
    CHECK(old + cur >= cap, "at least one full cap of history survives");
    free(bc); free(bp);

    regfree(&re);
    remove(path); remove(prev);
    printf("\n%s (%d failure(s))\n", fails ? "FAILED" : "ALL PASSED", fails);
    return fails ? 1 : 0;
}
