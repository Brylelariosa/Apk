#!/usr/bin/env bash
# Host-side test of the link code in mgba_jni.c: link_sio_write_register(), the clock-tie tick,
# the child's tick-driven delivery / hold, link_child_apply(), the lock-step
# nativeLinkChildExchange(), nativeLinkStart/Stop — extracted verbatim from the real source and
# run against stubbed JNI/mGBA types (link_test_stubs.h). Needs gcc only.
set -euo pipefail
cd "$(dirname "$0")"
python3 extract.py
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer test_sio_regs.c -o test_sio_regs -lpthread
./test_sio_regs
# the real log-file code (rotation / single writer / append mode)
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer test_log.c -o test_log -lpthread
./test_log
rm -f test_sio_regs test_log extracted_r*.c extracted_rlog.c
