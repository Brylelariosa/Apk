"""Cuts the link code out of app/src/main/cpp/mgba_jni.c into extracted_r*.c for the host-side tests.
Shared by run_regs.sh and run_sim.sh. Fails loudly if a marker moved."""
s = open('../../app/src/main/cpp/mgba_jni.c', encoding='utf-8').read()
def cut(a_marker, b_marker, name, include_b=False):
    a = s.index(a_marker)
    b = s.index(b_marker, a) if b_marker else len(s)
    if include_b and b_marker: b += len(b_marker)
    open(name, 'w', encoding='utf-8').write(s[a:b])
# r1: link globals + clock-tie constants/state, mailbox accessor, forward declarations
cut('static jobject   g_link_obj      = NULL;', 'static void jni_log(', 'extracted_r1.c')
# r2: pacing leftovers, SIO helpers, child delivery, deferred completion, tick, SIO write callback
cut('static struct timespec g_link_last_exchange_ts;', '/* FIX 9 — passive-child responder entry point.', 'extracted_r2.c')
# r3: nativeLinkChildExchange
cut('/* AUDIT FIX (multiplayer): this no longer touches the core at all.',
    'JNIEXPORT jboolean JNICALL\nJava_com_mgba_android_EmulatorEngine_nativeLinkStart(', 'extracted_r3.c')
# r4: nativeLinkStart / nativeLinkStop (last functions in the file)
cut('JNIEXPORT jboolean JNICALL\nJava_com_mgba_android_EmulatorEngine_nativeLinkStart(', None, 'extracted_r4.c')
# r5: nativeLinkLogBegin / nativeLinkLog
cut('/* THIS PASS: starts a brand-new session log (truncates the file, drops the older',
    '/* ── FIX 20: experimental exchange pacing', 'extracted_r5.c')
# rlog: the real log-file implementation (rotation, single writer, append mode)
cut('#define LINK_LOG_MAX_BYTES', '/* Replaces the old direct __android_log_print() call', 'extracted_rlog.c')
