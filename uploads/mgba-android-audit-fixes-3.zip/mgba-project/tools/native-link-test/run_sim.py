import subprocess, sys, time, os, signal

port = [47100]
fails = 0
def check(cond, msg):
    global fails
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond: fails += 1

def kv(line):
    return dict(p.split('=', 1) for p in line.split()[1:])

def run(name, seconds, oneway_ms, sync, child_enter_s=0.0, fastpath=1, loss=0.0, pause_child=None):
    port[0] += 2
    a, b = port[0], port[0] + 1
    args = lambda role, me, peer, enter: ['./sim_dev', role, str(me), str(peer), str(seconds), str(oneway_ms), str(sync), str(enter), str(fastpath), '0', str(loss)]
    c = subprocess.Popen(args('child', a, b, child_enter_s), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    h = subprocess.Popen(args('host', b, a, 0), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if pause_child:
        time.sleep(pause_child[0]); os.kill(c.pid, signal.SIGSTOP)
        time.sleep(pause_child[1]); os.kill(c.pid, signal.SIGCONT)
    try:
        ho, he = h.communicate(timeout=seconds + 40)
        co, ce = c.communicate(timeout=40)
    except subprocess.TimeoutExpired:
        h.kill(); c.kill()
        check(False, f"{name}: DEADLOCK — a process did not finish")
        return None, None
    if h.returncode or c.returncode:
        print(he[-1500:]); print(ce[-1500:])
        check(False, f"{name}: a process crashed / sanitizer error (host rc={h.returncode}, child rc={c.returncode})")
        return None, None
    hr = [l for l in ho.splitlines() if l.startswith('RESULT')][0]
    cr = [l for l in co.splitlines() if l.startswith('RESULT')][0]
    print(f"   host : {hr}\n   child: {cr}")
    return kv(hr), kv(cr)

print("== 1. OLD behaviour (clock sync OFF = one host word per child frame), Wi-Fi-like 3 ms one-way")
H, C = run("legacy", 9, 3, 0)
if H:
    check(H['detected'] == '0' and C['synced'] == '0', "neither ROM detects the other (reproduces the captured failure)")
    check(int(C['reinits']) >= 8, f"child ROM keeps resetting its link hardware ({C['reinits']} times in 9 s; the capture showed one reset every ~100 ms)")
    check(int(C['valid_packets']) == 0, "the child never completes one 16-word packet inside its 6-frame deadline")
    check(float(H['fps_before_detect']) < 10, f"host emulates at ~{float(H['fps_before_detect']):.1f} fps while probing (the capture: ~2.5 fps)")

print("== 2. NEW behaviour (clock sync ON), same 3 ms delay, child ROM already in link mode")
H, C = run("sync", 9, 3, 1)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "both sides detect each other")
    check(float(H['detected_at']) < 3.0, f"...within {H['detected_at']} s of starting")
    check(int(C['reinits_after_sync']) == 0, "once synced the child ROM never resets its link hardware again")
    check(int(H['ok_packets']) >= 20, f"host keeps getting fully valid ACK packets ({H['ok_packets']})")
    check(float(H['fps_after_detect']) > 8, f"connected phase (16 words EVERY frame, a worst case) runs at {float(H['fps_after_detect']):.1f} fps — bounded by network round trips")
    check(float(C['fps_avg']) > 8, f"child averages {float(C['fps_avg']):.1f} fps")

print("== 3. NEW behaviour, child ROM enters link mode 4 s AFTER the host started probing")
H, C = run("late child", 10, 3, 1, child_enter_s=4.0)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "detected after the child arrives")
    check(4.0 <= float(H['detected_at']) < 8.0, f"...at t={H['detected_at']} s (child arrived at 4 s)")
    check(int(H['fast_skips']) > 100, f"host stopped waiting on the absent child ({H['fast_skips']} exchanges answered locally)")
    check(float(H['fps_before_detect']) > 25, f"host ran at ~{float(H['fps_before_detect']):.0f} fps while the child wasn't ready")
print("== 3b. same, fast path disabled (how the host behaved before)")
H, C = run("late child, no fast path", 8, 3, 1, child_enter_s=3.0, fastpath=0)
if H:
    check(float(H['fps_before_detect']) < 20, f"host crawls at ~{float(H['fps_before_detect']):.0f} fps while waiting for the child — the lag the fast path removes")

print("== 4. NEW behaviour over a Bluetooth-like 15 ms one-way delay")
H, C = run("bt", 14, 15, 1)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "still detects (slower link, same lock-step)")
    check(int(C['reinits_after_sync']) == 0, "and stays in sync")

print("== 5. NEW behaviour, 8 ms one-way (poor Wi-Fi)")
H, C = run("poor wifi", 12, 8, 1)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "detects")

print("== 6. NEW behaviour, 3 ms + 1% and 5% packet loss each way (resend, duplicate handling, free-run governor)")
for loss in (0.01, 0.05):
    H, C = run(f"lossy {loss}", 14, 3, 1, loss=loss)
    if H:
        check(H['detected'] == '1' and C['synced'] == '1', f"{loss*100:.0f}% loss: detects")
        allowed = 0 if loss <= 0.01 else 4
        check(int(C['reinits_after_sync']) <= allowed, f"{loss*100:.0f}% loss: child ROM link resets after syncing: {C['reinits_after_sync']} (allowed {allowed}; "
              f"without the free-run governor the same runs had 13 at 1% and 45 at 5%)")
        check(int(H['ok_packets']) >= 0.85 * int(H['packets']) - 2, f"{loss*100:.0f}% loss: {H['ok_packets']} of {H['packets']} packets came back fully valid")

print("== 7. the child's app is frozen for 2.5 s mid-run (host must not freeze with it)")
H0, C0 = run("no pause", 9, 3, 1, child_enter_s=0.0)
H, C = run("paused child", 9, 3, 1, pause_child=(3.0, 2.5))
if H and H0:
    check(int(H['xchg_fail']) >= 1 and int(H['fast_skips']) > 0, f"host noticed ({H['xchg_fail']} timeouts) and stopped waiting ({H['fast_skips']} exchanges answered locally)")
    check(float(H['fps_avg']) > 12, f"host averaged {float(H['fps_avg']):.1f} fps over the run including the freeze")

print(f"\n{'FAILED' if fails else 'ALL PASSED'} ({fails} failure(s))")
sys.exit(1 if fails else 0)
