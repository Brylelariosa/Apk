# native-link-test

Host-side tests for the multiplayer code in `app/src/main/cpp/` — they need only `gcc` and `python3`.
`extract.py` cuts the **real** functions out of `mgba_jni.c` (so a test can't drift from the shipping code)
and the tests compile them against the tiny JNI/mGBA stand-ins in `link_test_stubs.h`.

| script | what it runs | time |
|---|---|---|
| `run.sh` | `test_mailbox.c` — the child's lock-step mailbox, under ASan+UBSan and ThreadSanitizer | ~10 s |
| `run_regs.sh` | `test_sio_regs.c` — SIO register semantics, the clock-tie tick, the child's tick-driven delivery / hold / governor, `nativeLinkStart/Stop`; `test_log.c` — the real log-file code (format, rotation, concurrent writers) | ~15 s |
| `run_sim.sh` | `sim_dev.c` ×2 — **two simulated phones** (separate processes running the real link code) joined by UDP with an artificial delay: old behaviour (reproduces the captured failure), new behaviour over Wi-Fi / poor Wi-Fi / Bluetooth-like delay, packet loss, a not-ready child, a frozen child | ~2 min |

The simulation's ROM is a **model** built from the two real captures (a host that probes with a 16-word packet,
a child whose ROM resets its link hardware if a packet isn't complete within 6 of its own frames). It checks
that the code does what the clock-tie fix claims and cannot deadlock; it cannot say what a particular real ROM does.
