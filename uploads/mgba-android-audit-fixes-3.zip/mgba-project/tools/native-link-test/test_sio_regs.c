#include "link_test_stubs.h"
#include "../../app/src/main/cpp/link_mailbox.h"

/* ---- code under test, pulled verbatim from mgba_jni.c ---- */
#include "extracted_r1.c"
static void link_frame_prologue(JNIEnv *env);
#include "extracted_r2.c"
#include "extracted_r3.c"
#include "extracted_r4.c"
#include "extracted_r5.c"

static int fails = 0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)
static struct GBA gba;

static void reset_world(bool host, uint16_t siocnt, uint16_t rcnt) {
    memset(&gba, 0, sizeof gba);
    gba.sio.siocnt = siocnt; gba.sio.rcnt = rcnt;
    g_link_gba = &gba; g_link_active = true; g_link_is_host = host;
    g_link_obj = (jobject)&g_iface; g_link_xchg_mid = (jmethodID)&g_iface;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env = &g_env; g_link_driver.localSend = 0xFFFF;
    g_calls = 0; g_irq_count = 0; g_link_pace_window_active = false;
    link_host_deferred_reset(true); g_link_done_event_inited = false; g_link_done_scheduled = false; g_link_done_core = NULL;
    g_double_schedules = 0; g_schedule_calls = 0; timing_clear(&gba);
    /* clock tie: the register tests exercise the legacy one-word-per-frame child path unless a test turns it on */
    g_link_clock_sync = false; g_link_tick = 0; g_link_tick_inited = false; g_link_tick_scheduled = false; g_link_tick_core = NULL;
    g_ch_have_prev = false; g_ch_burst = false; g_ch_hold_ms = 20; g_ch_wait_ewma_us = 5000; g_ch_gov_active = false;
    g_st_have_ts = false; g_last_stamp = -1;
    __atomic_store_n(&g_link_child_multi, link_sio_is_multi(&gba), __ATOMIC_RELAXED);
    lm_close(link_mbox());
}

typedef struct { int hostData; int stamp; jint rc; } ChildCall;
static void *child_call_thread(void *a){ ChildCall *c=a; c->rc = Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(&g_env,NULL,c->hostData,c->stamp); return NULL; }


typedef struct { ChildCall *c; int delay_us; } DelayedCall;
static void *delayed_call_thread(void *p){ DelayedCall *d=p; usleep(d->delay_us); child_call_thread(d->c); return NULL; }
static void *delayed_close_thread(void *p){ (void)p; usleep(10000); lm_close(link_mbox()); return NULL; }

int main(void) {
    printf("== HOST: SIOCNT Start write (multi mode, IRQ enabled, 115200 baud) — completion is DEFERRED\n");
    reset_world(true, 0x6003, 0);
    gba.memory.io[0x120>>1] = 0x1111; gba.memory.io[0x122>>1] = 0x2222;      /* stale values from an earlier transfer */
    link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);          /* ROM stages SIOMLT_SEND */
    g_script_reply = 0x0CD2;
    uint16_t out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==1 && g_last_sent==0x00AB,"exchange runs once and sends the staged SIOMLT_SEND");
    CHECK((out & 0x0080)!=0,"write RETURNS with Start/Busy still set (hardware: a transfer takes time)");
    CHECK(g_irq_count==0,"no IRQ inside the write (the ROM's next instruction runs before any ISR)");
    CHECK(gba.memory.io[0x120>>1]==0x1111 && gba.memory.io[0x122>>1]==0x2222,"SIOMULTI registers not updated yet");
    CHECK((out & 0x0008)!=0 && (out & 0x0004)==0 && (out & 0x0030)==0,"SD set, SI clear (parent), ID=0");
    CHECK((out & 0x6000)==0x6000,"mode bits and IRQ-enable preserved");
    gba.sio.siocnt = out;                                              /* mGBA stores what the driver returns */
    timing_advance(&gba, 6409);
    CHECK(g_irq_count==0 && (gba.sio.siocnt & 0x0080)!=0,"still busy one cycle before the 115200-baud transfer time (6410)");
    timing_advance(&gba, 1);
    CHECK((gba.sio.siocnt & 0x0080)==0,"busy clears when the event fires");
    CHECK(gba.memory.io[0x120>>1]==0x00AB && gba.memory.io[0x122>>1]==0x0CD2 && gba.memory.io[0x124>>1]==0xFFFF && gba.memory.io[0x126>>1]==0xFFFF,"SIOMULTI0=host, SIOMULTI1=child, SIOMULTI2/3=0xFFFF delivered at completion");
    CHECK(g_irq_count==1,"SIO IRQ raised exactly once, at completion");
    CHECK((gba.sio.siocnt & 0x0040)==0 && (gba.sio.siocnt & 0x0030)==0 && (gba.sio.siocnt & 0x6000)==0x6000,"no error, ID 0, mode/IRQ bits intact");
    CHECK(gba.memory.io[0x128>>1]==gba.sio.siocnt,"memory.io mirror consistent");

    printf("== HOST: transfer time follows the baud bits\n");
    { int expect[4]={76900,19225,12820,6410};
      for (int baud=0; baud<4; baud++) {
        reset_world(true, 0x6000|baud, 0); g_script_reply=1;
        out = link_sio_write_register(&g_link_driver.d, 0x128, (uint16_t)(0x6080|baud)); gba.sio.siocnt = out;
        timing_advance(&gba, expect[baud]-1); int early = (gba.sio.siocnt & 0x80)!=0;
        timing_advance(&gba, 1); int done = (gba.sio.siocnt & 0x80)==0;
        char m[80]; snprintf(m,sizeof m,"baud bits %d -> completes at exactly %d cycles",baud,expect[baud]); CHECK(early && done,m);
      } }

    printf("== HOST: a second Start (or a clearing write) while busy is ignored\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    int callsBefore = g_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_calls==callsBefore && g_schedule_calls==1,"second Start: no second exchange, no second event");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003); gba.sio.siocnt = out;
    CHECK((out & 0x0080)!=0,"software cannot clear Start/Busy mid-transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"still exactly one completion");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==callsBefore+1,"a new Start after completion starts a new transfer");

    printf("== HOST: SIO IRQ disabled by the ROM -> no IRQ at completion\n");
    reset_world(true, 0x2003, 0); g_script_reply = 0x1111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x2083); gba.sio.siocnt = out;
    timing_advance(&gba, 7000);
    CHECK(g_calls==1 && g_irq_count==0 && (gba.sio.siocnt & 0x0080)==0,"transfer completes, IRQ NOT raised when SIOCNT bit14=0");

    printf("== HOST: no answer from child -> error flag appears at completion, not before\n");
    reset_world(true, 0x6003, 0); g_script_reply = -1;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK((out & 0x0040)==0,"error flag not set inside the write");
    timing_advance(&gba, 7000);
    CHECK((gba.sio.siocnt & 0x0040)!=0 && gba.memory.io[0x122>>1]==0xFFFF,"timeout -> error bit set, SIOMULTI1=0xFFFF at completion");
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"transfer still completes (busy cleared, IRQ raised)");

    printf("== HOST: teardown while a transfer is in flight\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0222;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    link_host_deferred_reset(false);                                     /* link stopped; core + queue live on */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_xfer_pending,"stop mid-transfer clears Start/Busy (no ROM stuck waiting)");
    int sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;   /* restarted inside the old event's window */
    CHECK(g_double_schedules==0 && g_schedule_calls==sched,"event still queued -> NOT scheduled twice (queue corruption guard)");
    CHECK((out & 0x0080)==0 && g_irq_count==1,"...falls back to instant completion for that one transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1,"the stale event later fires as a harmless no-op");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && (out & 0x0080)!=0,"after it has fired, deferral works again");
    timing_advance(&gba, 7000);

    printf("== HOST: core swap / save-state load discards the queue\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0333;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    timing_clear(&gba); link_host_deferred_reset(true);                  /* what GBADeserialize does to the queue + our hook */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_done_scheduled,"load mid-transfer: busy cleared, nothing considered scheduled");
    sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && g_double_schedules==0 && (out & 0x0080)!=0,"next transfer defers normally (no permanent fallback)");
    timing_advance(&gba, 7000);

    printf("== CHILD role: SIOCNT writes\n");
    reset_world(false, 0x6003, 0);
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);       /* child ROM writes Start by mistake */
    CHECK(g_calls==0,"child never starts a transfer of its own");
    CHECK((out & 0x0080)==0,"child's Start/Busy write is ignored (read-only for slaves)");
    CHECK((out & 0x000C)==0x000C,"SD and SI (child) set");
    CHECK((out & 0x0030)==0x0010,"ID bits = 01 survive an ordinary SIOCNT write (used to be reset to 0)");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003 | 0x0030);
    CHECK((out & 0x0030)==0x0010,"ROM can't overwrite the read-only ID bits");

    printf("== CHILD: lock-step delivery through the mailbox\n");
    reset_world(false, 0x6003, 0);
    lm_open(link_mbox());
    g_link_driver.localSend = 0x1234;
    ChildCall cc = { 0x5A5A, 0, 99 }; pthread_t t; pthread_create(&t,NULL,child_call_thread,&cc);
    bool took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    CHECK(took,"game thread takes the posted request");
    CHECK(gba.memory.io[0x120>>1]==0x5A5A && gba.memory.io[0x122>>1]==0x1234,"SIOMULTI0=host word, SIOMULTI1=child's own word");
    CHECK(gba.sio.siocnt==0x601F,"REAL gba->sio.siocnt updated: mode/IRQ bits kept, SD+SI set, ID=1, busy clear (0x601F)");
    CHECK(gba.memory.io[0x128>>1]==0x601F,"memory.io mirror kept consistent");
    CHECK(g_irq_count==1,"child SIO IRQ raised once");
    pthread_join(t,NULL);
    CHECK(cc.rc==0x1234,"network thread released at delivery with the child's staged word (0x1234)");
    /* one transfer per frame: a second request must wait for the NEXT frame start */
    g_link_driver.localSend = 0x9999;                       /* "ISR staged the next word during the frame" */
    ChildCall cc2 = { 0x6B6B, 0, 99 }; pthread_t t2; pthread_create(&t2,NULL,child_call_thread,&cc2);
    usleep(30000);
    CHECK(cc2.rc==99 && gba.memory.io[0x120>>1]==0x5A5A,"2nd request is NOT delivered mid-frame (registers still show the 1st)");
    took = link_child_deliver_pending();
    pthread_join(t2,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x6B6B && cc2.rc==0x9999,"next frame start delivers it, and the reply reflects the word staged in between");
    CHECK(g_irq_count==2,"one IRQ per delivered transfer");

    printf("== CHILD not in Multi-Player mode: answered at once on the network thread, flagged, registers untouched\n");
    reset_world(false, 0x0000, 0);
    lm_open(link_mbox());
    gba.memory.io[0x120>>1]=0x7777; g_link_driver.localSend = 0x4321;
    cc.hostData=0x1111; cc.stamp=0; cc.rc=99;
    { struct timespec a0,b0; clock_gettime(CLOCK_MONOTONIC,&a0); child_call_thread(&cc); clock_gettime(CLOCK_MONOTONIC,&b0);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms<20,"no game thread needed: the reply is immediate (no frame wait)"); }
    CHECK(cc.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)),"reply = 0xFFFF with the NOT_MULTI flag in bits 16-23");
    CHECK(gba.memory.io[0x120>>1]==0x7777 && gba.sio.siocnt==0x0000 && g_irq_count==0,"registers and SIOCNT untouched (SIODATA32 shares those addresses)");
    /* a word posted while the ROM WAS in multi mode, then the ROM left it before the game thread got to it */
    reset_world(false, 0x6003, 0); lm_open(link_mbox());
    cc.hostData=0x1111; cc.rc=99; pthread_create(&t,NULL,child_call_thread,&cc);
    usleep(20000);
    gba.sio.siocnt = 0x0000; gba.memory.io[0x120>>1]=0x7777;
    took = link_child_deliver_pending();
    pthread_join(t,NULL);
    CHECK(took && cc.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)) && gba.memory.io[0x120>>1]==0x7777 && g_irq_count==0,"left multi mode meanwhile: flagged reply, nothing written");

    printf("== CHILD with SIO IRQ disabled: data lands, no IRQ\n");
    reset_world(false, 0x2003, 0); lm_open(link_mbox()); g_link_driver.localSend = 0x0001;
    cc.hostData=0x2222; pthread_create(&t,NULL,child_call_thread,&cc);
    took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    pthread_join(t,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x2222 && g_irq_count==0,"no IRQ when SIOCNT bit14=0");

    printf("== link closed / nobody running frames\n");
    lm_close(link_mbox());
    cc.hostData=1; cc.rc=99; child_call_thread(&cc);
    CHECK(cc.rc==-1,"closed link -> -1 (host's 'no answer')");
    reset_world(false, 0x6003, 0); lm_open(link_mbox());
    cc.rc=99; struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a); child_call_thread(&cc); clock_gettime(CLOCK_MONOTONIC,&b);
    double ms=(b.tv_sec-a.tv_sec)*1000.0+(b.tv_nsec-a.tv_nsec)/1e6;
    CHECK(cc.rc==-1 && ms>=90 && ms<400,"no game thread: -1 after about LINK_CHILD_WAIT_MS (100 ms)");


    /* ================= CLOCK TIE ================= */
    printf("== CLOCK TIE: the tick event is armed once, ticks every 6410 cycles, and stamps host words\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true;
    link_frame_prologue(&g_env);
    CHECK(g_link_tick_scheduled && g_schedule_calls==1,"prologue arms the tick");
    link_frame_prologue(&g_env);
    CHECK(g_schedule_calls==1 && g_double_schedules==0,"calling it every frame does not queue it twice");
    timing_advance(&gba, 6409);  CHECK(g_link_tick==0,"no tick one cycle early");
    timing_advance(&gba, 1);     CHECK(g_link_tick==1,"first tick at exactly 6410 cycles");
    timing_advance(&gba, 6410*10); CHECK(g_link_tick==11 && g_double_schedules==0,"keeps ticking, still one event in the queue");
    g_script_reply = 0x0001;
    link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_calls==1 && g_last_stamp==11,"host passes its tick count (11) to Kotlin as the stamp");
    timing_advance(&gba, 7000);
    CHECK(g_last_stamp==11 && (gba.sio.siocnt & 0x80)==0,"transfer completion coexists with the tick in one queue");

    printf("== CLOCK TIE: stop lets the tick lapse; restart inside the stale window does not double-queue\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    timing_advance(&gba, 6410*3);
    g_link_active = false;
    timing_advance(&gba, 6410*5);
    CHECK(g_link_tick==3 && !g_link_tick_scheduled && gba.timing.head==NULL,"after stop the event fires once, does nothing, and is gone");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    g_link_active = false; g_link_active = true;
    link_frame_prologue(&g_env);
    CHECK(g_schedule_calls==1 && g_double_schedules==0,"stop+restart before the event fired: not scheduled again");
    timing_advance(&gba, 6410*2);
    CHECK(g_link_tick==2,"...and it simply keeps going");

    printf("== CLOCK TIE: save-state load / core swap discards the queue; the next frame re-arms\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    timing_clear(&gba); link_tick_reset(true);
    CHECK(!g_link_tick_scheduled,"bookkeeping cleared");
    link_frame_prologue(&g_env);
    CHECK(g_link_tick_scheduled && g_schedule_calls==2 && g_double_schedules==0,"prologue puts the tick back");

    printf("== CLOCK TIE: legacy path (clock sync off) never arms a tick\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = false; link_frame_prologue(&g_env);
    CHECK(!g_link_tick_scheduled && g_schedule_calls==0,"no tick event when g_link_clock_sync is false");

    printf("== CLOCK TIE: child delivers at the host's spacing, holds mid-burst, runs free when sparse\n");
    reset_world(false, 0x6003, 0); g_link_clock_sync = true; lm_open(link_mbox());
    g_link_driver.localSend = 0x1000; link_frame_prologue(&g_env);
    ChildCall w = { 0xA001, 100, 99 }; pthread_t tw;
    pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    CHECK(w.rc==99,"word 1 (stamp 100) is waiting for a tick, not delivered mid-nothing");
    timing_advance(&gba, 6410);                                           /* tick 1 */
    pthread_join(tw,NULL);
    CHECK(w.rc==0x1000 && gba.memory.io[0x120>>1]==0xA001 && gba.memory.io[0x122>>1]==0x1000 && g_irq_count==1,"no history -> delivered at the first tick; reply = the staged word; one IRQ");
    CHECK(!g_ch_burst,"one word is not yet a burst");
    g_link_driver.localSend = 0x2000;                                     /* the ISR staged the next reply */
    w.hostData=0xA002; w.stamp=101; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    timing_advance(&gba, 6410);                                           /* tick 2: gap 1, only 1 tick since delivery -> due */
    pthread_join(tw,NULL);
    CHECK(w.rc==0x2000 && gba.memory.io[0x120>>1]==0xA002 && g_irq_count==2,"word 2 (gap 1) delivered one tick later, reply reflects the word staged in between");
    CHECK(g_ch_burst,"two words 1 tick apart = a burst");

    /* tick 3: nothing posted, burst on -> the child HOLDS. A helper thread posts word 3 ~8 ms into the hold. */
    g_link_driver.localSend = 0x3000;
    { ChildCall w3 = { 0xA003, 102, 99 }; DelayedCall dc = { &w3, 8000 };
      struct timespec a0,b0;
      pthread_t tposter;
      pthread_create(&tposter,NULL,delayed_call_thread,&dc);               /* posts word 3 about 8 ms into the hold */
      clock_gettime(CLOCK_MONOTONIC,&a0);
      timing_advance(&gba, 6410);                                         /* tick 3: holds, wakes on the post, delivers */
      clock_gettime(CLOCK_MONOTONIC,&b0);
      pthread_join(tposter,NULL);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=6 && ms<19,"the child's emulation waited for the next word (hold), then continued as soon as it arrived");
      CHECK(w3.rc==0x3000 && gba.memory.io[0x120>>1]==0xA003 && g_irq_count==3,"word 3 delivered inside the same tick");
      CHECK(g_st_ch_holds==1,"one successful hold counted"); }

    /* word 4 arrives with gap 3: the child must run 3 ticks before delivering */
    g_link_driver.localSend = 0x4000;
    w.hostData=0xA004; w.stamp=105; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    timing_advance(&gba, 6410);  CHECK(w.rc==99 && g_irq_count==3,"tick 4: 1 tick since last delivery < gap 3 -> not yet");
    timing_advance(&gba, 6410);  CHECK(w.rc==99 && g_irq_count==3,"tick 5: 2 ticks -> not yet");
    timing_advance(&gba, 6410);  pthread_join(tw,NULL);
    CHECK(w.rc==0x4000 && g_irq_count==4,"tick 6: 3 ticks -> delivered (the host's spacing reproduced)");

    /* word 4b: a frame-periodic host idles ~28 ticks between blocks. The burst must SURVIVE that gap. */
    g_link_driver.localSend = 0x4100;
    w.hostData=0xA0B4; w.stamp=133; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);   /* 105 + 28 */
    { int before = g_irq_count, guard = 0; while (g_irq_count == before && guard++ < 60) timing_advance(&gba, 6410); }
    pthread_join(tw,NULL);
    CHECK(w.rc==0x4100 && g_irq_count==5 && g_ch_burst && (g_link_tick - g_ch_prev_tick)==0,"a 28-tick idle gap between blocks: delivered at the host's spacing and burst mode persists");
    CHECK(g_link_tick == 34,"...exactly 28 ticks after the previous word (tick 6 + 28)");
    g_irq_count = 4;   /* the checks below were written against the earlier count */

    /* the burst has ended: the next tick holds for the hold time, then gives up and runs free */
    { struct timespec a0,b0; int hold = g_ch_hold_ms;
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410); clock_gettime(CLOCK_MONOTONIC,&b0);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=hold-2 && ms<hold+60,"no next word: the hold times out after about g_ch_hold_ms");
      CHECK(!g_ch_burst && g_st_ch_hold_to==1,"...and the child runs free again (burst cleared)");
      CHECK(g_ch_gov_active,"the free-run governor is armed when the hold gives up");
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410*100); clock_gettime(CLOCK_MONOTONIC,&b0);
      ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=25 && ms<90,"free-run is governed to real time: 100 ticks (38 ms emulated) take ~35 ms, not ~0 (no catch-up burst)"); }

    /* sparse: a word stamped (ticks-run-so-far + 40) host ticks after the previous one is held back until the child has run those ticks too */
    g_ch_prev_tick = g_link_tick; g_ch_gov_active = false;   /* as if a word had just been delivered */
    { uint32_t since0 = g_link_tick - g_ch_prev_tick; unsigned gapw = since0 + 40u;
      CHECK(gapw <= 128u,"setup: the gap is within the spacing window");
      uint16_t st = (uint16_t)(g_ch_prev_h + gapw);
      jint expect = (jint)g_link_driver.localSend;
      w.hostData=0xA005; w.stamp=st; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      int need = (int)gapw - (int)(g_link_tick - g_ch_prev_tick); int base = g_irq_count;
      CHECK(need == 40,"setup: the child still has to run 40 more ticks");
      { struct timespec a1,b1; clock_gettime(CLOCK_MONOTONIC,&a1);
        timing_advance(&gba, 6410LL*(need-1));
        clock_gettime(CLOCK_MONOTONIC,&b1);
        double ms1=(b1.tv_sec-a1.tv_sec)*1000.0+(b1.tv_nsec-a1.tv_nsec)/1e6;
        CHECK(ms1<15,"running ticks to reach a POSTED word's slot is not throttled (the host's clock did advance that far)"); }
      CHECK(g_irq_count==base,"one tick before the host's gap has elapsed: still waiting");
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && w.rc==expect,"delivered exactly when the host's gap has elapsed"); }
    /* a gap beyond ~3 frames ends burst mode */
    g_ch_burst = true; g_ch_have_prev = true; g_ch_prev_h = 1000; g_ch_prev_tick = g_link_tick;
    { int base = g_irq_count;
      w.hostData=0xA0C0; w.stamp=(uint16_t)(1000+200); w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && !g_ch_burst,"a 200-tick gap ends burst mode (delivered at once, no spacing)"); }
    /* a huge gap (the host sat idle): no spacing is enforced */
    { int base = g_irq_count;
      w.hostData=0xA006; w.stamp=5000; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && !g_ch_burst,"gap > 128 ticks: delivered at the very next tick, not a burst"); }

    printf("== CLOCK TIE: the governor wakes for a word and is released by the delivery\n");
    g_ch_gov_active = true; g_ch_burst = false; g_ch_have_prev = true; g_ch_prev_h = 100; g_ch_prev_tick = g_link_tick;
    clock_gettime(CLOCK_MONOTONIC,&g_ch_gov_ts); g_ch_gov_tick0 = g_link_tick;
    { ChildCall wg = { 0xA0D0, 100+500, 99 }; DelayedCall dcg = { &wg, 10000 };
      int base = g_irq_count; struct timespec a1,b1; pthread_t tg;
      pthread_create(&tg,NULL,delayed_call_thread,&dcg);
      clock_gettime(CLOCK_MONOTONIC,&a1); timing_advance(&gba, 6410*400); clock_gettime(CLOCK_MONOTONIC,&b1);   /* 153 ms emulated */
      pthread_join(tg,NULL);
      double ms1=(b1.tv_sec-a1.tv_sec)*1000.0+(b1.tv_nsec-a1.tv_nsec)/1e6;
      CHECK(g_irq_count==base+1 && !g_ch_gov_active,"a word posted while the child is being governed is delivered during the sleep and releases the governor");
      CHECK(ms1 < 140,"...after which time runs unthrottled again (400 ticks took well under their 153 ms of emulated time)"); }

    printf("== CLOCK TIE: the child's multi-mode flag follows the ROM and short-circuits the network thread\n");
    gba.sio.siocnt = 0x0000; timing_advance(&gba, 6410);
    CHECK(!__atomic_load_n(&g_link_child_multi, __ATOMIC_RELAXED),"ROM left Multi-Player mode: flag cleared on the next tick");
    w.hostData=0xBEEF; w.stamp=1; w.rc=99; child_call_thread(&w);
    CHECK(w.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)),"network thread answers 'not multi' without a frame");
    gba.sio.siocnt = 0x6003; timing_advance(&gba, 6410);
    CHECK(__atomic_load_n(&g_link_child_multi, __ATOMIC_RELAXED),"back in Multi-Player mode: flag set again");

    printf("== CLOCK TIE: a link stop wakes a holding child immediately\n");
    reset_world(false, 0x6003, 0); g_link_clock_sync = true; lm_open(link_mbox()); link_frame_prologue(&g_env);
    g_ch_burst = true; g_ch_have_prev = true; g_ch_prev_tick = 0; g_ch_hold_ms = 120;
    timing_advance(&gba, 6410);                                           /* tick 1 would hold 120 ms ... */
    { struct timespec a0,b0; g_ch_burst = true; g_ch_prev_tick = 1;
      pthread_t tc; pthread_create(&tc,NULL,delayed_close_thread,NULL);
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410); clock_gettime(CLOCK_MONOTONIC,&b0);
      pthread_join(tc,NULL);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms<60,"lm_close() ends the hold at once instead of waiting out 120 ms"); }

    printf("== nativeLinkStart / nativeLinkStop: state is reset, signature matches Kotlin, tick armed by the prologue\n");
    {
      reset_world(true, 0x6003, 0);
      g_core_obj.board = &gba;
      g_link_gba = NULL; g_link_active = false;
      g_link_clock_sync = false; g_link_tick = 77; g_ch_have_prev = true; g_ch_burst = true;
      jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1);
      CHECK(ok==JNI_TRUE,"nativeLinkStart succeeds");
      CHECK(strcmp(g_method_sig,"(II)I")==0,"looks up jniExchangeData with signature (II)I");
      CHECK(g_link_active && g_link_is_host && g_link_clock_sync && g_link_tick==0 && !g_ch_have_prev && !g_ch_burst,"session state reset; clockSync taken from the argument");
      CHECK(gba.sio.drv==&g_link_driver.d,"driver registered with the SIO subsystem");
      link_frame_prologue(&g_env);
      CHECK(g_link_tick_scheduled,"the first frame arms the tick");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      CHECK(!g_link_active && gba.sio.drv==NULL && g_link_gba==NULL,"nativeLinkStop tears the link down");
      timing_advance(&gba, 6410*3);
      CHECK(!g_link_tick_scheduled && g_link_tick==0,"the tick lapses after stop");
    }

    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
