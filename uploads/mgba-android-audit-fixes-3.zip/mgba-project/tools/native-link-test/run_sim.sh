#!/usr/bin/env bash
# Two-device simulation of the link: two sim_dev processes (host + child) running the REAL
# link code extracted from mgba_jni.c, joined by UDP on loopback with an artificial one-way delay.
# Reproduces the captured failure with the old one-word-per-frame behaviour, then checks the
# clock-tie fix (and that it cannot deadlock). ~1 minute. Needs gcc + python3.
set -euo pipefail
cd "$(dirname "$0")"
python3 extract.py
gcc -std=gnu11 -O1 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -Wno-unused-variable -g \
    -fsanitize=address,undefined -fno-omit-frame-pointer sim_dev.c -o sim_dev -lpthread -lm
python3 run_sim.py
rm -f sim_dev extracted_r*.c
