package com.mgba.android

import android.graphics.Bitmap

/**
 * Thin Kotlin wrapper around the mGBA JNI layer.
 *
 * Key bitmask values match enum GBAKey in mgba/internal/gba/input.h:
 *   A=0, B=1, SELECT=2, START=3, RIGHT=4, LEFT=5, UP=6, DOWN=7, R=8, L=9
 */
object EmulatorEngine {

    // ── GBA key bitmasks ──────────────────────────────────────────────────────
    const val KEY_A      = 1 shl 0   // 0x001
    const val KEY_B      = 1 shl 1   // 0x002
    const val KEY_SELECT = 1 shl 2   // 0x004
    const val KEY_START  = 1 shl 3   // 0x008
    const val KEY_RIGHT  = 1 shl 4   // 0x010
    const val KEY_LEFT   = 1 shl 5   // 0x020
    const val KEY_UP     = 1 shl 6   // 0x040
    const val KEY_DOWN   = 1 shl 7   // 0x080
    const val KEY_R      = 1 shl 8   // 0x100
    const val KEY_L      = 1 shl 9   // 0x200

    init {
        System.loadLibrary("mgba-jni")
    }

    /**
     * Auto-detects ROM type, initialises the core, and loads the file at
     * [path].
     *
     * GBA only — this build's CMakeLists.txt forces M_CORE_GB off, so
     * despite the name this never actually auto-detects GB/GBC regardless
     * of what's passed in (previously claimed GB/GBC support here; stale —
     * see CMakeLists.txt's own comment on M_CORE_GB for why, and
     * RomZipUtils/the ROM browser's zip scanner, which both correctly only
     * ever look for .gba, matching what this can actually load).
     *
     * [savePath] is where the cartridge's battery save (SRAM/Flash/EEPROM —
     * the game's own in-game save system, e.g. a "Save the game?" prompt)
     * is read from and persisted to. It's opened read/write and handed to
     * the core, so an existing save at that path is picked up automatically
     * and every subsequent in-game save write lands there. Pass a stable,
     * per-ROM path (see MainActivity.batterySaveFile) so re-loading the same
     * ROM later resumes the same save data.
     * @return true on success
     */
    external fun nativeLoadROM(path: String, savePath: String): Boolean

    /**
     * Runs exactly one emulated frame.
     * If [bitmap] is non-null, writes the result into it (must be
     * ARGB_8888, width = nativeGetWidth(), height = nativeGetHeight()).
     * If [bitmap] is null, the frame still fully emulates (and its audio is
     * still readable via [nativeReadAudioSamples]) but the pixel copy is
     * skipped — use this for fast-forward sub-frames that get overwritten
     * before they're ever displayed, so their pixels are never copied.
     */
    external fun nativeRunFrame(bitmap: Bitmap?)

    /**
     * Updates the current key state.  [keys] is a bitmask of KEY_* constants.
     * All bits not set are treated as released.
     */
    external fun nativeSetKeys(keys: Int)

    /** Returns the emulated screen width in pixels (GBA = 240). */
    external fun nativeGetWidth(): Int

    /** Returns the emulated screen height in pixels (GBA = 160). */
    external fun nativeGetHeight(): Int

    /** Frees the native core and framebuffer.  Call from onDestroy. */
    external fun nativeDestroy()

    /**
     * Drains the mGBA blip audio buffers into [buf] as interleaved stereo PCM.
     * [buf] must have at least [maxSamples] * 2 elements (L+R pairs).
     * @return number of stereo pairs written (0 if no samples available).
     * Call this immediately after nativeRunFrame() on the game thread.
     */
    external fun nativeReadAudioSamples(buf: ShortArray, maxSamples: Int): Int

    /**
     * Fills [buf] with [length] bytes read live off the running core's
     * memory bus, starting at [address] — the same GBA address space the
     * core itself uses (0x02000000 = EWRAM, 0x03000000 = IWRAM, etc.), not
     * an offset into any one region's own buffer. Read-only: this only
     * inspects, never modifies, live state (see MainActivity.showMemoryViewer()
     * for the feature this backs and why it stays read-only for now).
     * [buf] must have at least [length] elements — same "caller allocates,
     * native fills" shape as [nativeReadAudioSamples] above.
     * @return number of bytes actually written — 0 if no ROM is loaded or
     * [length] isn't positive, otherwise always [length] (an address with
     * nothing meaningful mapped there still reads as *something*, same as
     * real hardware open-bus behavior — there's no distinct "invalid
     * address" failure case to report here).
     */
    external fun nativeReadMemory(address: Int, buf: ByteArray, length: Int): Int

    // ── Save states ────────────────────────────────────────────────────────
    // Full emulator snapshots (CPU/PPU/audio/save data/RTC), independent of
    // the battery save above — these let you resume from an exact mid-game
    // moment rather than wherever the game itself last let you save.

    /**
     * Writes a full snapshot of the currently-running emulator to [path],
     * overwriting anything already there.
     * @return true on success; false if no ROM is loaded or the write failed.
     */
    external fun nativeSaveState(path: String): Boolean

    /**
     * Restores a full snapshot previously written by [nativeSaveState].
     * The running ROM is not reloaded or reset first — the snapshot's CPU/
     * memory/save-data state simply replace the current ones in place.
     * @return true on success; false if [path] doesn't exist, isn't a valid
     * state for the currently loaded ROM, or no ROM is loaded.
     */
    external fun nativeLoadState(path: String): Boolean

    // ── Link cable multiplayer ─────────────────────────────────────────────

    /**
     * FIX 17 — points the native link-debug trace at a private, app-owned
     * file so it can be read back without relying on OS logcat access,
     * which some OEM builds restrict even for an app reading its own
     * output (see KNOWN_LIMITATIONS.md, "The debug-log tool doesn't work
     * on every phone", and copyLinkDebugLog() in MainActivity.kt, which
     * now reads this file directly instead of shelling out to `logcat`).
     * Call once, early (MainActivity.onCreate(), before any link session
     * starts) with a path under this app's own filesDir.
     *
     * Only the path is recorded at this point — the file itself is opened
     * by [nativeLinkLogBegin] (called when a connection ATTEMPT starts) or,
     * failing that, in append mode by [nativeLinkStart], not here, so a
     * single-player session that never starts a link session never pays for
     * the file I/O this backs at all. Each capture reflects one connection
     * attempt rather than accumulating across a whole app session.
     * @return true if the path was recorded; only false if [path] itself
     * couldn't be read from the JNI call.
     */
    external fun nativeSetLinkLogPath(path: String): Boolean

    /**
     * Starts a brand-new link session log: truncates the file (and drops the
     * rotated ".1" segment). LinkMultiplayer calls it at the start of every
     * Host / Join / Bluetooth attempt, so the whole story — handshake
     * included — lands in one file.
     */
    external fun nativeLinkLogBegin()

    /**
     * The ONLY way Kotlin writes to the link log file (the native side is the
     * single writer — two writers with separate file offsets corrupted each
     * other's lines). [level]: 0 info, 1 warning, 2 error.
     */
    external fun nativeLinkLog(level: Int, msg: String)

    /**
     * @param clockSync tie this device's emulated clock to the peer's (the multiplayer fix — see
     *   the CLOCK TIE comment in mgba_jni.c). false = the old one-word-per-frame behavior, kept
     *   for A/B comparison (Settings → Debug → "Link clock sync").
     */
    external fun nativeLinkStart(link: LinkMultiplayer, isHost: Boolean, clockSync: Boolean): Boolean
    external fun nativeLinkStop()

    /**
     * Passive-child responder — call this (never on the game/UI thread's
     * critical path, always from LinkMultiplayer's own background listener
     * threads) whenever a transfer request arrives *from the network* while
     * this device is the child/non-host side of a link session.
     *
     * A child GBA never triggers its own SIO transfer (the Start/Busy bit
     * is read-only for slaves), so nothing on this side ever calls
     * nativeRunFrame-driven SIO code in response to the parent's request —
     * this is the substitute for that. Writes this device's own SIOMULTI0/1
     * so its ROM sees the completed transfer, and returns this device's own
     * latched outgoing value so the caller can send it back to the parent.
     * @param hostData the host's SIO word (16 bits).
     * @param stamp the host's tick count when its ROM started the transfer (16 bits) — lets the
     *   child re-create the host's spacing between words in its own emulated time.
     * @return -1 = no answer (the game thread didn't take it in time, or no link session is
     * active); otherwise bits 0-15 are this device's own SIOMLT_SEND value and bits 16-23 are
     * reply flags (bit 0: this ROM is not in Multi-Player mode, so nobody answered).
     */
    external fun nativeLinkChildExchange(hostData: Int, stamp: Int): Int
}
