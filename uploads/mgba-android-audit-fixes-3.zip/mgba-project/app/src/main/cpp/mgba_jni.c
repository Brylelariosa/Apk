/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fixes applied in this revision
 * ───────────────────────────────
 * FIX 1  pthread_mutex_t g_core_mutex protects g_core / g_fb.
 * FIX 2  core->loadConfig(core, &core->config) instead of mCoreLoadConfig.
 * FIX 3  nativeRunFrame pixel copy respects info.stride.
 * FIX 4  nativeReadAudioSamples — new function to drain mGBA blip buffers
 *         for Android AudioTrack. Uses blip_read_samples with stereo=1 to
 *         produce interleaved L/R PCM in one pass each channel.
 * FIX 5  nativeRunFrame(bitmap=NULL) skips the pixel-copy blit entirely.
 *         Used for fast-forward sub-frames that get overwritten before
 *         they're ever displayed — emulation and audio still run in full,
 *         only the wasted 240x160 copy is skipped.
 * FIX 6  Link SIO exchange now reads the outgoing byte from SIOMLT_SEND
 *         (0x400012A) instead of the receive-only SIOMULTI0 (0x4000120).
 *         Previously the link connected fine at the socket level but no
 *         real game data ever crossed it, since we were echoing back
 *         stale received bytes instead of what the ROM wrote to send.
 * FIX 7  SUPERSEDES FIX 6's approach. Polling SIOCNT after runFrame() and
 *         poking SIOMULTI0-3 with rawWrite16 never actually worked, because
 *         mGBA's own SIO controller (src/gba/sio.c) intercepts every SIOCNT
 *         write the instant the game makes it: if no GBASIODriver is
 *         registered for the active mode, it resolves the Start bit itself
 *         via a built-in "dummy driver" fallback, synchronously, before
 *         our post-runFrame check ever runs. So the raw pokes were mostly
 *         racing (and losing to) the core's own default behavior.
 *         The real fix is a proper GBASIODriver, registered with
 *         GBASIOSetDriver() in nativeLinkStart/Stop, whose writeRegister
 *         callback intercepts the Start-bit write synchronously and does
 *         the JNI exchange right there.
 *         See link_sio_write_register() near the bottom of this file.
 * FIX 8  Corrections after the first real CI build against the actual
 *         mGBA 0.10.3 headers (this project's pinned tag) turned up two
 *         places where mgba.io's current docs/master branch don't match
 *         0.10.3's actual API:
 *           - GBASIOSetDriver() takes 3 args here (sio, driver, mode), not
 *             2 — this build's compile error was "too few arguments to
 *             function call, expected 3, have 2".
 *           - struct GBASIODriver has no processEvents member on this
 *             revision — "no member named 'processEvents'".
 *         Also, GBASIOMultiplayerFinishTransfer() — the internal call the
 *         core's own drivers use to finish a transfer — triggered an
 *         implicit-declaration warning even with sio.h included, meaning
 *         it isn't exposed on this revision either; link_sio_write_register
 *         now writes SIOMULTI0-3 directly instead of risking an unresolved
 *         symbol at link time. Net effect: transfers complete correctly,
 *         but this build doesn't automatically raise the SIO IRQ the way
 *         hardware would — only relevant for a game that waits on that
 *         interrupt instead of polling SIOCNT's Start bit.
 *         Also fixed: struct LinkSIODriver / g_link_driver / g_link_gba were
 *         declared below nativeLoadROM and nativeRunFrame despite being used
 *         inside them — moved up next to the other link-cable globals.
 * FEATURE 9  Battery/cart save persistence + save states.
 *         nativeLoadROM now takes a second path and hands the core a real,
 *         app-managed VFile via core->loadSave() so SRAM/Flash/EEPROM
 *         writes survive app restarts (see the comment at that call site).
 *         nativeSaveState/nativeLoadState wrap mCoreSaveStateNamed()/
 *         mCoreLoadStateNamed() for full-snapshot save-state slots, keyed
 *         by whatever path the Kotlin layer passes in.
 * FIX 9  Root-caused why multiplayer still never got a ROM past its own
 *         "waiting for link" screen even once the two phones' network
 *         handshake succeeded. Two separate, GBATEK-confirmed bugs:
 *           (a) Nothing ever set SIOCNT's parent/child (bit 2) or
 *               all-ready (bit 3) status bits, both of which GBATEK
 *               documents games as checking *before* ever attempting a
 *               transfer — so a ROM that checks first could spin forever
 *               regardless of the network state. Fixed in
 *               link_sio_write_register() by reflecting both on every
 *               SIOCNT write, not just Start-bit ones.
 *           (b) GBATEK: the Start/Busy bit is "Read Only for Slaves" — a
 *               child unit never triggers its own transfer, only the
 *               parent does. Since the exchange branch below is keyed off
 *               *this device's own* Start-bit write, it correctly never
 *               fired on a child device — meaning a child's wifiExchange()/
 *               btExchange() (the only thing that ever answered the
 *               parent's request) was simply never called. The parent's
 *               every request timed out, deterministically, every time.
 *               Fixed with a new passive-responder entry point,
 *               nativeLinkChildExchange(), called from a background Kotlin
 *               thread the instant a request arrives over the network
 *               instead of waiting on a local SIOCNT write that was never
 *               coming. See its own comment below for the full picture,
 *               and LinkMultiplayer.kt for the Kotlin-side listener threads
 *               that call it.
 *         Also added: ID bits (4-5) and the Error bit (6) are now set
 *         correctly on the parent's side after each transfer (previously
 *         left at whatever the ROM had last written, which is undefined
 *         behavior per GBATEK for bit 4-5 before the first transfer).
 * FIX 10 Root-caused why SIOCNT/data-register correctness (FIX 9) still
 *         wasn't enough to get either test game (Yu-Gi-Oh! World
 *         Championship 2006, The Legend of Zelda: Four Swords) off their
 *         own link-wait screens: FIX 8 already flagged, but left
 *         unaddressed, that nothing here ever raises the SIO IRQ. Real GBA
 *         multiplayer code overwhelmingly uses the BIOS IntrWait/
 *         VBlankIntrWait pattern (enable INT_SERIAL in IE, then sleep for
 *         that interrupt) rather than busy-polling SIOCNT bit 7 in a spin
 *         loop — busy-polling burns battery on real hardware and every
 *         GBA-dev tutorial (Tonc, gbadev) teaches IntrWait for exactly this
 *         reason — so a transfer that completes correctly but never
 *         interrupts leaves that (very common) style of ROM asleep
 *         forever, waiting for a wake-up that's never coming, even though
 *         the bytes themselves crossed the network correctly. This also
 *         explains the fast-forward symptom reported after FIX 9: an
 *         interrupt-driven ROM sitting in that sleep state isn't hitting
 *         the Start-bit write per frame at all (it wrote it once, then went
 *         to sleep waiting on the IRQ), so there's nothing left to make
 *         link_exchange()'s blocking network round-trip pace the frame
 *         rate — fast-forward looks and feels completely normal precisely
 *         *because* the link exchange has stalled, not because it's
 *         keeping up.
 *
 *         Confirmed against mGBA's actual src/gba/sio.c (read directly from
 *         the mgba-emu/mgba source this pass, not inferred): the real
 *         GBASIOWriteSIOCNT() calls exactly
 *         `GBARaiseIRQ(sio->p, GBA_IRQ_SIO, 0)` — same pattern already used
 *         for every other GBA interrupt source (timers, DMA, keypad) — but
 *         only from its own dummy-driver fallback, and only for Normal
 *         mode; SIO_MULTI's dummy-driver case does no IRQ work at all.
 *         That means for Multi-Player mode specifically, raising this
 *         interrupt has only ever been a registered driver's own job —
 *         exactly the role link_sio_write_register()/
 *         nativeLinkChildExchange() play here — it was just never done.
 *         Fixed by calling GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0) at the
 *         same point each function already finishes a transfer (after the
 *         four SIOMULTI0-3 writes), on both the host and child paths, once
 *         per device since each phone is a fully separate process with its
 *         own core. Deliberately unconditional on the timedOut branch too:
 *         real Multi-Player transfers are clocked by the parent's fixed
 *         baud rate (see GBASIOCyclesPerTransfer in the real sio.c) and
 *         complete — and interrupt — on that schedule regardless of
 *         whether a given child answered in time, which is exactly why
 *         FIX 9 already gives a timed-out round real 0xFFFF data and the
 *         Error bit instead of silently withholding the round entirely.
 *         `<mgba/internal/gba/gba.h>` is already included above (needed
 *         for `struct GBA` itself), and GBARaiseIRQ/GBA_IRQ_SIO live in
 *         that same header, so no new include was needed.
 *         Caveat: read directly from real mGBA source this pass (a real
 *         improvement over guessing from memory, which is how FIX 7/8's
 *         signature mismatches happened), but not from a byte-identical
 *         checkout of the exact pinned 0.10.3 tag, and still never
 *         compiled in this sandbox — this foundational an interrupt API
 *         (shared by every hardware peripheral, not link-specific) is a
 *         poor candidate for a breaking signature change, but if the CI
 *         build disagrees, this is the first place to check.
 * FIX 11 User re-tested FIX 10: no change at all, on either game, over
 *         either transport — "Connected" still shows, the ROM still
 *         doesn't react, fast-forward is still completely unthrottled.
 *         An identical, unimproved symptom after a real fix to a real gap
 *         is itself informative: it suggests link_sio_write_register()
 *         may never be firing at all, for either game, rather than firing
 *         and hitting some remaining logic bug. That would make sense of
 *         everything at once — GBASIOSetDriver() registers this driver
 *         only for SIO_MULTI, and the core re-picks its *active* driver
 *         from sio->drivers.* every time the ROM's own RCNT/SIOCNT mode
 *         bits change (see GBASIOWriteSIOCNT in FIX 10's citation); if
 *         either ROM's link handshake spends its time in a different mode
 *         (or never gets past an earlier stage at all), this driver simply
 *         never gets consulted, and FIX 9/10 together would have zero
 *         observable effect — exactly what was reported. Rather than guess
 *         at a fourth protocol theory with no way to check it from this
 *         sandbox, this pass adds permanent, cheap trace logging instead:
 *         every SIOCNT/SIOMLT_SEND write this driver handles is logged
 *         (tag mGBA-JNI), plus a separate warning if the Start bit is set
 *         but the exchange gets skipped, naming exactly which of
 *         env/g_link_obj/g_link_xchg_mid/g_core was unexpectedly null/
 *         false. Silence in logcat for this tag during a real link attempt
 *         is itself the answer: it means the mode-dispatch theory above is
 *         right and the next fix has to happen earlier in the handshake,
 *         not inside this driver. Real log output settles this in one
 *         test, instead of another pass of unverifiable guessing.
 * FIX 13 User re-tested FIX 12 (plus the Kotlin-side thumbnail/logcat-tool
 *         passes since): still stuck on ROM detection, on both transports,
 *         plus Wi-Fi disconnect not reaching the other phone and lag on
 *         Bluetooth. The two logcat dumps attached as evidence turned out to
 *         be the actual finding: both are real "mGBA-JNI"-tag captures (the
 *         tag filter in copyLinkDebugLog() is not the problem), but both
 *         cover barely 200ms of real time — pure boot-time DMA/register
 *         spam, nothing from anywhere near an actual link attempt. Root
 *         cause: jni_log() (this file's mLogger callback, registered once
 *         at core init) forwarded every mGBA core log line, at every level,
 *         to LOGI — including mLOG_STUB/mLOG_DEBUG chatter like "Starting
 *         DMA ..." and "Read from write-only I/O register: ..." that fires
 *         dozens of times per frame for any ROM, completely unrelated to
 *         link. copyLinkDebugLog()'s `logcat -t 2000` (most recent 2000
 *         matching lines) never had a chance against that volume — by the
 *         time W finished a test and copied the log, everything from the
 *         actual multiplayer attempt had long since scrolled out from under
 *         routine gameplay's own DMA/register traffic, boot alone was
 *         enough to fill the window before anything link-related even
 *         started.
 *         Fix: jni_log() now drops mLOG_DEBUG/mLOG_STUB/mLOG_GAME_ERROR
 *         before they reach LOGI (mirrors mGBA's own libretro frontend
 *         under NDEBUG), plus a belt-and-suspenders prefix check on the two
 *         specific messages actually observed. FATAL/ERROR/WARN/INFO, and
 *         everything either this file's own LOGI/LOGW calls or
 *         LinkMultiplayer.kt's Log.i/Log.w calls produce, are unaffected.
 *         Full detail in jni_log() itself, below. Not a fix for the
 *         reported symptoms directly — a fix for why every piece of
 *         evidence gathered about them so far has been empty. The next
 *         capture, taken after actually reaching both ROMs' link screens
 *         (not right after boot), should finally show FIX 11's SIO trace
 *         and LinkMultiplayer.kt's own connection-lifecycle logging instead
 *         of nothing.
 * FIX 14 Same pass as FIX 13, found while re-reading this file end to end
 *         looking for anything FIX 9-12 might have missed rather than
 *         anything the (empty) logcat evidence pointed at. link_sio_write_
 *         register()'s exchange branch was never actually gated on
 *         g_link_is_host — every FIX 9-12 comment already *describes* the
 *         design as host-only (a child only ever answers via the network-
 *         driven nativeLinkChildExchange(), never its own SIO write; FIX 9's
 *         own comment claimed this branch "correctly never fires" on a
 *         child) but nothing enforced it. GBATEK says Start/Busy is
 *         hardware-read-only for a slave, so a compliant ROM's own child-
 *         role write should already be inert — but if either test ROM
 *         shares parent/child code through one Sio API (plausible; Nintendo's
 *         own SDK is commonly used that way) and doesn't distinguish, this
 *         branch would have treated that write as a real trigger and run a
 *         second, spurious wifiExchange()/btExchange() from the child's own
 *         thread — sending an unsolicited DATA packet the host's *next*
 *         real exchange could then race against and consume as that round's
 *         reply. Fits the symptom set well: identical ROM-detection failure
 *         on both transports (this file is shared; the transport-specific
 *         Kotlin already got FIX 9-12's full attention) and worse lag
 *         specifically on Bluetooth (BT_XCHG_MS=50 vs WIFI_XCHG_MS=30 — a
 *         stolen-reply timeout costs more there).
 *         Fix: added `&& g_link_is_host` to the branch condition; simplified
 *         the two blocks inside it that used to switch on g_link_is_host,
 *         since it's now always true there. The FIX 11 diagnostic warning
 *         is now also host-gated, so a child's now-correctly-ignored
 *         Start-bit write doesn't get logged every occurrence — see that
 *         `else if` for why logging it at all would risk reintroducing
 *         FIX 13's problem.
 *         Not confirmed — same caveat as every pass, no NDK/device here —
 *         and unlike FIX 12, this one wasn't reached by reading an actual
 *         logcat, it's a design-intent gap this file's own comments already
 *         flagged without closing. Genuinely possible this changes nothing
 *         for either reported bug. FIX 13's improved logging is what would
 *         actually show whether a child device was ever hitting the old
 *         unguarded branch in the first place — if the next capture's
 *         "SIO write ... active=1 host=0" lines never carry the Start bit
 *         at all, this fix was a no-op hardening, not the cause.
 * FIX 16 First real evidence this project has had: FIX 13's logging fix
 *         worked exactly as intended, and W sent back four logs, three with
 *         genuine content. What they show is a real step forward, not a
 *         fix: wifi_host.text (host role) recorded 1124 Start-bit writes in
 *         1.67 seconds — far too fast to be hitting WIFI_XCHG_MS=30 on each
 *         one (that alone would take 30+ seconds) — so the great majority
 *         were completing fast, not timing out, meaning the network layer
 *         itself is very likely fine: replies are coming back quickly.
 *         Two things stand out in what's actually being exchanged. First,
 *         the host's outgoing SIOMLT_SEND values aren't random — they cycle
 *         through what looks like the same ~20-value probe sequence over
 *         and over (2002, 4921, several 0000s, 0001, 0020, more 0000s,
 *         FEFE, then two values that drift by ±1 between cycles — 4007→
 *         4008, 56B4→56B3 — a live counter embedded in an otherwise fixed
 *         sequence), never advancing to new content. Second, wifi_join.text
 *         and bluetoth__1_.text (child role, separate sessions, ~2 minutes
 *         apart from the host capture — not simultaneous, so these three
 *         logs can't be directly cross-referenced against each other) show
 *         the child repeatedly re-running its own SIOCNT/RCNT setup
 *         sequence roughly every 200ms, never stabilizing, host=0
 *         throughout — consistent with a ROM that keeps abandoning its own
 *         negotiation attempt and starting over.
 *         Best current theory, NOT confirmed: each side's own link
 *         negotiation state machine is independently timing out and
 *         resetting because whatever it reads back from the other side
 *         doesn't satisfy it — plausible if a network round trip
 *         frequently lands mid-reset on the far side, since a child mid-
 *         reset has nothing better than a stale/placeholder SIOMLT_SEND
 *         value to hand back. That's a guess about game-specific protocol
 *         behavior neither GBATEK nor this sandbox can confirm, not a
 *         mechanism found in this code.
 *         What's certain: this file could not have shown that either way
 *         before this pass, because the only thing ever traced was the
 *         write that *triggers* an exchange, never the exchange's own
 *         result, and nativeLinkChildExchange() — the entire receive path
 *         on a child — had no logging at all, in either its early-exit or
 *         its success case. Both fixed below (still just logging, no
 *         behavior changed): the host branch now logs what link_exchange()
 *         actually returned and whether it timed out; nativeLinkChildExchange()
 *         now logs every call, success or skipped, with both directions'
 *         data. Bumped the clipboard tool's capture window 8000→20000 lines
 *         to match — genuine exchange activity, once happening, is far
 *         higher-volume than the boot noise FIX 13 removed, and this pass
 *         roughly doubles the host-side trace volume on top of that.
 *         Also confirmed, separately from all of the above: the multiplayer
 *         debug-log tool itself doesn't work on every device — W reported
 *         (and screenshotted) an empty capture on one phone while the other
 *         produced real output. Very likely a normal, expected Android
 *         restriction (self-logcat access for a non-privileged, non-
 *         debuggable app varies by OS version/OEM policy — Shizuku, which W
 *         already has on the working phone, is a common workaround, not
 *         evidence of a bug in this app), not something this pass attempts
 *         to fix — see KNOWN_LIMITATIONS.md.
 * FIX 17 W sent a new pair this pass — wifi_host__1_.text / wifi_join__1_.text,
 *         both taken with FIX 16's exchange-result/child-exchange logging
 *         already in place, so for the first time the *content* of what
 *         each side sends and receives is directly visible, not just that
 *         an exchange happened.
 *
 *         Host: 704 completed exchanges in ~1.6s, 694 (98.6%) real replies,
 *         not timeouts (10 timed out, each correctly surfaced as
 *         recv=0xFFFF — FIX 9's own placeholder, not silently dropped) —
 *         the network layer replying this fast, this reliably, is real
 *         evidence it isn't the bottleneck. But all 694 real replies were
 *         either 0xFEFE (544) or 0x0000 (150) — never anything resembling
 *         the host's own varied outgoing data (the same repeating ~20-value
 *         probe plus two slowly-incrementing counter bytes Sixteenth pass
 *         already described). Child: wifi_join__1_.text is a separate
 *         session, roughly 3 minutes after the host capture — still not a
 *         truly simultaneous pair, see KNOWN_LIMITATIONS.md — but it
 *         independently confirms *why*: across all 1586 of this capture's
 *         own nativeLinkChildExchange() calls, childData (this device's own
 *         g_link_driver.localSend — whatever its ROM most recently wrote to
 *         SIOMLT_SEND) is 0xFEFE or 0x0000 and literally nothing else. This
 *         is a directly-traced local write, not a network relay — the child
 *         ROM itself never writes anything past these two placeholders. Its
 *         SIOCNT/RCNT/SIOMLT_SEND writes repeat the same five-write reset
 *         sequence roughly every 200ms (10 RCNT=0x0000 writes across the
 *         ~2s capture, 194-209ms apart each time) — a GBATEK-consistent
 *         Multi-Player re-initialization (RCNT bit 14-15 + SIOCNT bit 12-13
 *         jointly select the mode; writing RCNT=0 here is part of
 *         *selecting* Multi-Player mode, not a drop to Normal), just one
 *         that never gets past its own opening move.
 *
 *         Re-checked FIX 9's bit2/bit3 reflection specifically this pass,
 *         since "the child's own SIOCNT read never shows bit3 (all-ready)"
 *         would perfectly explain a ROM stuck re-initializing — but that
 *         code already applies `if (g_link_active) { bit3|=1; bit2=... }`
 *         unconditionally on *every* SIOCNT write regardless of
 *         g_link_is_host, not just inside the host-gated exchange branch
 *         below it. On paper the child ROM should already see bit3=1 from
 *         its very first poll onward, for the entire time g_link_active is
 *         true — which this whole capture confirms it is, since
 *         nativeLinkChildExchange() never once hit its own early-exit path.
 *         No bug found here this pass, consistent with the Twelfth pass's
 *         own read-through conclusion — noted explicitly rather than
 *         silently re-confirmed, since it was the single most likely
 *         candidate going in.
 *
 *         Best current theory, updated but still NOT confirmed: per
 *         DeepWiki's generated documentation of mgba-emu/mgba's own real
 *         src/gba/sio/lockstep.c (a secondary source describing the real
 *         file, cross-referencing real line ranges — not fetched directly
 *         this pass), mGBA's *own* multiplayer implementation (used by its
 *         Qt frontend for local multi-instance play; unrelated to this
 *         project's code but the source FIX 8's GBASIOMultiplayerFinishTransfer
 *         reference came from) is built around a lockstep coordinator that
 *         enqueues a transfer-start event to every secondary player and
 *         explicitly waits for all of them to acknowledge before a transfer
 *         completes, timed to GBASIOCyclesPerTransfer. This file's own
 *         exchange is a single blocking network round-trip with no
 *         equivalent "every player acknowledged" concept and no attempt to
 *         pace completion against real transfer-cycle timing — it finishes
 *         the instant one UDP/RFCOMM round trip returns, which real SIO
 *         hardware (and mGBA's own lockstep driver) never would. That same
 *         documentation lists "desynchronization due to timing issues" as
 *         the most common multiplayer bug class in mGBA's reference
 *         implementation — independent support for timing/synchronization
 *         being a real candidate category here, not a guess invented from
 *         nothing, though still not evidence this codebase's specific
 *         instance of that category is what's actually happening.
 *         Deliberately not acted on this pass: reworking the exchange to be
 *         event-paced instead of one blocking call is a real design change,
 *         not a logging addition, and per every prior pass's own stated
 *         policy this isn't attempted blind without real device feedback to
 *         check it against.
 *
 *         The actual fix this pass: durable, logcat-independent link
 *         logging. W's report this round — real evidence on one phone,
 *         nothing on the other — confirms the logcat-access gap Sixteenth
 *         pass flagged but didn't fix is still blocking the one thing every
 *         pass since the Twelfth has asked for: a capture from *both*
 *         phones during the *same* attempt, the only way to actually test
 *         the theory above (or any theory) instead of comparing two windows
 *         minutes apart. copyLinkDebugLog() (MainActivity.kt) no longer
 *         shells out to `logcat` at all — every LOGI/LOGW/LOGE call in this
 *         file now also appends to a private file this app owns outright
 *         (path handed in once from Kotlin at startup — see
 *         nativeSetLinkLogPath() below), through a new jni_log_line() that
 *         LOGI/LOGW/LOGE now expand to; every existing call site is
 *         unchanged, since those are still plain macros. Needs no
 *         logcat/READ_LOGS access of any kind, on any OEM build — that
 *         restriction only ever applied to reading logcat itself, never to
 *         a plain file this app writes in its own private storage.
 *         Re-truncated at the start of every nativeLinkStart() — one
 *         capture is one connection attempt, not an ever-growing
 *         accumulation across a whole app session — with an 8MB backstop
 *         cap in link_log_write() for the rare session that runs long
 *         before anyone reads it. [SUPERSEDED by FIX 23 below: the file is
 *         now started by nativeLinkLogBegin() when a connection attempt
 *         begins, written only by this side, in append mode, and rotated
 *         to ".1" at the cap instead of being emptied.] See LinkMultiplayer.kt's own FIX 17 entry
 *         for the Kotlin-side half: the 7 connection-lifecycle log lines
 *         Fifteenth pass added now mirror into this same file, so one file
 *         has everything the old 3-tag logcat filter used to combine.
 * FIX 18 First real matched capture: two logs, one per phone, timestamps
 *         overlapping to the second (07-16 14:02:58–14:03:00) instead of
 *         minutes apart — FIX 17's logging is what finally made this
 *         possible. Cross-referencing both sides directly (not just each
 *         side's own aggregate stats, for the first time) confirms Sixteenth/
 *         Seventeenth pass's read: the host's own live, changing outgoing
 *         values (its counter-embedded probe sequence) show up correctly as
 *         `hostData` in the child's own exchange log, and the child's fixed
 *         0x0000/0xFEFE show up correctly as `recv` in the host's own
 *         exchange log. Data crosses the network both ways, correctly,
 *         confirmed from both ends at once — not a relay/corruption bug.
 *         New finding: nativeLinkChildExchange() writes SIOMULTI0-3 and
 *         raises the SIO IRQ, but — per its own prior comment — never
 *         touched the child device's own SIOCNT. GBATEK documents Multi-
 *         Player SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection
 *         of the parent's clock line on every connected unit, not something
 *         a child's CPU sets — polling it for "a transfer just landed" is a
 *         normal technique alongside, or instead of, the IRQ this file
 *         already raises. Since nothing here ever pulsed that bit on the
 *         child's device, a child ROM using that technique would see a flat,
 *         never-changing value, indistinguishable from no transfer ever
 *         having happened — regardless of the IRQ or the data registers
 *         already being correct. Fixed: nativeLinkChildExchange() now
 *         refreshes bits 2/3/4-5/7 on the child's own SIOCNT after every
 *         exchange, preserving every other bit (mode/baud/IRQ-enable)
 *         exactly as the ROM last set them. See that function's own updated
 *         comment for the full reasoning.
 *         Not confirmed — no device in this sandbox, same as every fix
 *         before it — but grounded in a gap the code already admitted to
 *         itself, cross-referenced against GBATEK, not a new guess about
 *         either test ROM's internals. See KNOWN_LIMITATIONS.md for what
 *         would actually confirm or rule this out.
 * FIX 19 Re-tested FIX 18 against a real matched capture: no observed
 *         change. The child's own exchange log still shows `childData` as
 *         only ever 0x0000/0xFEFE, same two values as every pass back to
 *         the Sixth — mirroring the transfer-complete state onto the
 *         child's own SIOCNT did not unstick it, at least not for this
 *         test ROM. Doesn't rule the theory out for every ROM (a different
 *         game's SIO code could still poll that bit), but it's not the
 *         whole answer here. No revert — the change is still a correctness
 *         fix on its own terms (mirrors what real hardware does) and cost
 *         nothing observable in this capture.
 *         Separately (Kotlin side, MainActivity.kt): the two phones'
 *         capture windows in this test ended up covering different real-
 *         world spans — not a phone bug, just the host's code logging
 *         ~3 lines per exchange (two SIO writes + one result) against the
 *         child's ~1 (one "Child exchange" line), so the same 40,000-
 *         character cap holds less real time on the denser, host side.
 *         copyLinkDebugLog() now appends a "copied at MM-DD HH:MM:SS.mmm"
 *         line (same layout link_log_write_locked() already uses) so two
 *         captures can be aligned by eye without needing both sides to
 *         still be mid-exchange at the moment of the tap.
 * FIX 20 New matched host+child capture (log.text/logt.text, 07-17) shows
 *         the exact same unresolved symptom as FIX 18/19, unchanged across
 *         everything in between (Twentieth-Twenty-fourth pass touched
 *         Storage folder, save-state perf, and UI — nothing in this file).
 *         The child's own SIOMLT_SEND is still only ever 0x0000/0xFEFE for
 *         the whole capture, and its own RCNT/SIOCNT setup sequence still
 *         restarts roughly every 200ms (18:37:59.699 / .908 / 18:38:00.102
 *         / .309 / .506 in this capture — 194-209ms apart each time, same
 *         period documented since the Sixteenth pass), while the host's own
 *         hostData keeps arriving at the child correctly and varying
 *         exactly as it always has (0x4921/0x2002/0x0001/0x0020 plus the
 *         drifting 0x56xx/0x40xx counter bytes).
 *
 *         New this pass, from the user directly rather than from a log:
 *         confirmed the ROM itself is not the problem — the same game's
 *         multiplayer works outside this app. That closes off the "maybe
 *         this ROM's own link code is just unusual" possibility every pass
 *         since the Sixteenth has had to leave open, and answers Nineteenth
 *         pass's other standing question (both screens genuinely stuck on
 *         their own "waiting for link" menu, nothing wrong in this file at
 *         all) — a ROM that works elsewhere and fails only here means the
 *         bug is this app's own link implementation, not a game-specific
 *         quirk or a menu/input miss.
 *
 *         That re-focuses attention on the one theory every pass since the
 *         Seventeenth has named as the most likely remaining explanation
 *         but never acted on: this driver resolves every SIO transfer as
 *         one instantaneous, blocking network round-trip, with no
 *         equivalent of real hardware's (or mGBA's own lockstep driver's)
 *         per-transfer cycle cost — see GBASIOCyclesPerTransfer, cited
 *         since FIX 10. The concrete mechanism worth naming this pass:
 *         host-triggered exchanges fire as fast as the network replies
 *         (hundreds per second — 1124 in 1.67s in the Sixteenth pass's own
 *         capture, a similar rate here), but a GBA frame is only ~16.7ms,
 *         and nativeLinkChildExchange() runs on a background Kotlin thread
 *         completely uncorrelated with when the child's own
 *         nativeRunFrame() actually lets its CPU execute. At the observed
 *         rate, roughly a dozen exchanges land — each one overwriting
 *         SIOMULTI0-3 and re-pulsing the IRQ — for every single frame's
 *         worth of CPU time the child ROM gets to actually run in. A
 *         negotiation loop expecting to observe and respond to each
 *         transfer in turn would instead see whatever the last of a dozen
 *         overlapping updates happened to leave behind, effectively random
 *         from its own perspective — which fits every symptom on file:
 *         real, varying data demonstrably arrives (FIX 18's own capture
 *         already proved that), yet the child ROM's own response never
 *         advances.
 *
 *         A fully correct fix means pacing transfer completion against
 *         mGBA's own cycle-accurate scheduler (mTiming), the way
 *         GBASIOLockstepDriver actually does it — genuinely letting the
 *         child's CPU run between transfers instead of racing a background
 *         thread against it. That's real scheduler integration, not a
 *         logging or bit-flip change, and every pass that has named this
 *         theory (Seventeenth onward) has also declined to attempt it
 *         blind, without a device to check it against — this pass agrees
 *         with that judgment and does not attempt it either.
 *
 *         What this pass does instead: a small, bounded, OFF-able
 *         experiment that tests the theory above cheaply, without
 *         redesigning anything. link_pace_exchange() (below) makes a
 *         host-triggered exchange wait until at least one emulated frame
 *         (LINK_MIN_EXCHANGE_INTERVAL_NS, ~16.74ms — deliberately much
 *         coarser than GBASIOCyclesPerTransfer's real ~0.19-8.5ms
 *         per-transfer cost, chosen to match how often the child's CPU
 *         actually gets to run rather than real hardware's true transfer
 *         rate) has passed since the previous one, sleeping out the
 *         difference before starting the network round-trip. This is not a
 *         claim that ~16.7ms is the "correct" real-hardware interval — real
 *         Multi-Player mode is designed to run many transfers per frame,
 *         and coalescing them down to one per frame is a real deviation
 *         from the protocol a fully correct fix would not make. It exists
 *         only to answer one narrow, cheap-to-test question: does giving
 *         the child's own CPU a chance to observe each exchange before the
 *         next one overwrites it change the symptom at all? If the ~200ms
 *         reset pattern and the 0x0000/0xFEFE ceiling persist unchanged
 *         with this on, the aliasing theory above is very likely wrong (or
 *         not the whole story) and the next pass should look elsewhere
 *         without re-spending effort here. If either changes — even
 *         partially, even if the connection still doesn't fully work —
 *         that's real evidence pointing at real scheduler integration as
 *         the next, bigger investment. Toggle with LINK_PACE_EXCHANGES
 *         (below); set to 0 to fall back to this file's exact prior
 *         behavior with nothing else changed.
 *         Not confirmed — no device in this sandbox, as always. Verified by
 *         reading and a standalone compile of the pacing/timeout math
 *         (GBA frame length, cycles-to-ns conversion) against a minimal
 *         stand-in for clock_gettime/nanosleep, not against real NDK
 *         headers — see FILE_CHANGES.md for what that standalone test
 *         actually checked.
 * FIX 21 First real device evidence back on FIX 20 (07-18), and it's the
 *         most informative result this project has had in a long time —
 *         two different findings, pointing in opposite directions.
 *
 *         Good news first: a fresh matched capture with FIX 20 active shows
 *         real movement for the first time ever. The child's own
 *         SIOMLT_SEND is no longer stuck at only 0x0000/0xFEFE — this
 *         capture shows it writing genuinely varying values (0x003C,
 *         0x0019/0xFFDA, 0x022F/0xFDC4, 0x0047/0xFFAC, 0x005D/0xFF96,
 *         0x0279/0xFD7A, 0x0084/0xFF6F...), and the ~200ms restart loop
 *         documented since the Sixteenth pass is gone, replaced by full
 *         negotiation attempts roughly 15-17s apart. That's the aliasing
 *         theory's predicted signature, and it's the first time in this
 *         project's history the child ROM has done anything other than
 *         repeat two placeholder values. It still doesn't fully connect,
 *         though — each attempt gets a burst of real variation for
 *         roughly a second, then both sides write SIOCNT with Start
 *         cleared (0x2003) and sit there for several seconds before the
 *         whole thing restarts from RCNT=0 again. That stall is a new,
 *         different, so-far-unexplained bottleneck, now visible for the
 *         first time only because FIX 20 got past the one before it.
 *
 *         The other result, from the user directly: tried against Dragon
 *         Ball Z: Supersonic Warriors (a real-time versus/co-op fighting
 *         game — a much less forgiving link user than whatever slower,
 *         retry-tolerant negotiation the capture above came from) and got
 *         an immediate "communication error", plus noticeable in-game lag.
 *         No capture from that specific attempt to confirm it directly,
 *         but this is exactly FIX 20's own documented cost: it added up to
 *         ~16.74ms to *every* host-triggered exchange, for the *entire*
 *         session, with no way to turn itself off once a connection
 *         stabilized. A game that depends on fast, frequent exchanges for
 *         real-time gameplay — not just a slow initial handshake — would
 *         feel that as lag and could easily time out its own link checks
 *         well inside real hardware's actual budget.
 *
 *         So: the mechanism looks real (it unstuck something nothing else
 *         in 20 fixes had touched), but applying it as a flat, permanent,
 *         whole-session cost is too blunt an instrument — it risks trading
 *         one game's stuck handshake for another game's broken real-time
 *         play. This pass bounds it instead of removing it: pacing now
 *         only runs inside a short LINK_PACE_WINDOW_NS (3s) grace window,
 *         armed once in nativeLinkStart() and re-armed every time the
 *         local device writes RCNT — which, per every capture on file,
 *         including this pass's, is exactly what happens both at session
 *         start and at every negotiation restart. Chosen from this pass's
 *         own capture: comfortably longer than the ~1.3s real variation
 *         actually took to show up after a reset, comfortably shorter than
 *         the ~15-17s a stuck attempt took to give up and restart on its
 *         own. Outside an armed window — meaning: an established
 *         connection well past its last restart, exactly the situation an
 *         in-progress real-time game would be in — link_pace_exchange()
 *         is a single boolean check and nothing else, identical in cost to
 *         FIX 20 being off entirely.
 *
 *         This does not resolve either open question. Whether 3 seconds is
 *         the right window, whether the new SIOCNT=0x2003 stall this pass's
 *         capture exposed is the next real bottleneck, and whether Dragon
 *         Ball Z: Supersonic Warriors' instant failure was really pacing
 *         latency or something else about that ROM entirely, all still
 *         need a real device and a real capture to know — ideally one from
 *         that specific game, which this pass doesn't have.
 * FIX 22 Got that Dragon Ball Z: Supersonic Warriors capture. Same shape as
 *         the Twenty-sixth pass's: ~1.2s of real handshake activity, then
 *         *both* sides write SIOCNT=0x2003 (Start cleared) within 65ms of
 *         each other and go quiet — no further Start-bit writes from
 *         either side — until the whole thing restarts ~11.5s later. FIX 21
 *         changed nothing about this shape, confirming it isn't a pacing
 *         question. Directly confirmed by the user this pass: the phones
 *         already show the communication error *during* that quiet
 *         stretch — well before this file's own ~11.5s retry gives up.
 *         Something is deciding this has failed faster and on different
 *         grounds than anything this driver tracks.
 *
 *         Looked up GBATEK's actual documented Multi-Player procedure
 *         rather than continuing to reason from this file's own comments
 *         about it (gbatek-sio-multi-player-mode, rust-console/gbatek-
 *         gbaonly). One line in it reframes a lot: the parent sends
 *         blindly regardless of whether a child has processed the last
 *         transfer, so a child is expected to insert its own delays and/or
 *         *signal it isn't ready by temporarily switching out of
 *         Multi-Player mode entirely* — not by any bit this driver
 *         inspects at all.
 *
 *         That matters here specifically because of how this driver is
 *         wired up: GBASIOSetDriver() (FIX 7) registers link_sio_write_
 *         register() for SIO_MULTI only, the same way every real per-mode
 *         SIO driver in mGBA's own source is scoped to one mode (the Game
 *         Boy Player driver included) — this file's own FIX 11 comment
 *         already says as much: "this callback only ever runs while the
 *         core's own SIO mode is SIO_MULTI". If either ROM ever takes
 *         GBATEK's documented exit — leaves Multi-Player mode to signal
 *         not-ready — every write it makes until it switches back would
 *         route to a different per-mode driver slot (or none at all;
 *         General-Purpose mode has no driver of its own in mGBA's real
 *         dispatch table either) and never reach this file's logging at
 *         all. Which means every "restart" this project has been reading
 *         as the negotiation failing and beginning again from scratch —
 *         all the way back to the Sixteenth pass — might instead be this:
 *         the ROM legitimately doing exactly what GBATEK says it should,
 *         completely invisibly to a driver that only ever hears from
 *         Multi-Player mode. This driver has never relayed anything about
 *         *mode*, only actual Multi-Player transfers — so even where this
 *         theory is right, the other device would have no way to see its
 *         partner's not-ready signal either way.
 *
 *         Tempting next step: add init/load/unload to this file's driver
 *         (currently all 0/unset — see the FIX 8 struct below) to log
 *         entry/exit directly. Deliberately not done this pass: FIX 7's
 *         own comment already records this exact category of mistake once
 *         — GBASIOSetDriver() taking 3 arguments instead of 2, caught only
 *         by a real build log, not by reasoning about it in advance — and
 *         load/unload's exact signature isn't something this sandbox can
 *         check against the pinned mGBA headers any better than that
 *         argument count was. Guessing it wrong doesn't corrupt anything,
 *         it just fails the build, but that's still a wasted round trip
 *         worth avoiding when there's a safer option.
 *
 *         That safer option is what this pass actually does: read
 *         sio.rcnt/sio.siocnt directly in nativeRunFrame(), instead of
 *         adding a new driver callback. Both are plain uint16_t fields
 *         readable off the same core->board-derived struct this file
 *         already dereferences successfully for GBASIOSetDriver() itself
 *         (g_link_gba->sio) — confirmed present at that path in mGBA's own
 *         public header, if not confirmed byte-for-byte against this
 *         pinned 0.10.3 build specifically. Reading them straight off the
 *         core bypasses the per-mode driver question entirely: whatever
 *         mode is actually selected, on either device, for the whole
 *         session, this now gets logged the moment it changes. If the
 *         next matched capture shows an "SIO mode" line moving away from
 *         Multi-Player's selection during exactly the quiet stretch above,
 *         that confirms the theory outright and makes the case for
 *         load/unload (or a lower-risk equivalent) worth the build-log
 *         round trip. If rcnt/siocnt just sit still through the whole
 *         quiet stretch instead, the theory's wrong and this was a cheap
 *         way to find that out before touching anything riskier.
 * FIX 23 (audit-fix pass 6) The two captures from the same attempt (host + child)
 *         finally showed the cause behind everything above, and it is a clock
 *         problem, not a data problem. The host's ROM probes with 16-word
 *         packets sent back to back; each word cost a network round trip, so
 *         the host's EMULATED clock crawled at ~4% of real time (~107
 *         transfers/s x 0.38 ms emulated each) — the "lag" — while the
 *         child's ran at full speed receiving one word per frame, and its
 *         ROM reset its Multi-Player hardware every ~100 ms (~6 frames)
 *         having seen 7-9 of the 16 words. Fix: both cores run a periodic
 *         tick event; the host stamps each word with its tick count; the
 *         child delivers inside the emulation at the host's spacing, holds
 *         for the next word mid-burst, and is governed to real time after a
 *         hold gives up (see the CLOCK TIE comment at the link globals).
 *         Also: a host stops waiting on a child that isn't in Multi-Player
 *         mode (LinkMultiplayer.jniExchangeData), and the link log became a
 *         single-writer, rotating, exportable file (nativeLinkLogBegin /
 *         nativeLinkLog; MainActivityDebugLog.kt saves it to Downloads).
 *         Tested by running THIS code under tools/native-link-test: unit
 *         tests, and a two-process simulation that reproduces the capture
 *         with the old behaviour and passes with the new.
 */


#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>

#include <errno.h>                   /* write_all_fd() EINTR handling, open() error text */
#include <fcntl.h>
#include <unistd.h>                  /* write/fsync/close — save-state file output */
#include "link_mailbox.h"            /* lock-step child hand-off (see that header) */
#include <stdarg.h>                  /* va_list — jni_log_line() (FIX 17) */
#include <stdint.h>
#include <stdio.h>                    /* FILE/fopen/fprintf/fflush — FIX 17's link_log_write() */
#include <stdlib.h>
#include <string.h>
#include <time.h>                     /* clock_gettime/localtime_r — FIX 17's log timestamps */

#include <mgba/core/core.h>
#include <mgba/core/config.h>
#include <mgba/core/log.h>
#include <mgba/core/serialize.h>     /* mCoreSaveStateNamed/mCoreLoadStateNamed,
                                       * SAVESTATE_* flags — save states. */
#include <mgba/core/blip_buf.h>      /* blip_t, blip_samples_avail, blip_read_samples
                                       * — this is mGBA's public wrapper header that
                                       * re-exports src/third-party/blip_buf/blip_buf.h.
                                       * The bare "mgba-util/blip_buf.h" path used
                                       * previously does not exist in the mGBA tree. */
#include <mgba-util/vfs.h>           /* VFileOpen/struct VFile/VFileMemChunk —
                                       * battery save + save-state I/O both go
                                       * through explicit VFiles rather than
                                       * mCore's slot/directory API, since this
                                       * app never sets up core->dirs (no
                                       * mDirectorySetAttachBase call anywhere)
                                       * — see nativeLoadROM, nativeSaveState,
                                       * nativeLoadState. VFileMemChunk is the
                                       * same growable in-memory VFile mGBA's
                                       * own src/core/rewind.c uses for its
                                       * rewind buffer — nativeSaveState/
                                       * nativeLoadState (this pass) use it too,
                                       * to hold a full save state in memory
                                       * for compression/decompression. */
#include <zlib.h>                    /* compress2/uncompress/compressBound —
                                       * save-state compression (this pass).
                                       * System zlib via the NDK, not a new
                                       * source dependency — see this file's
                                       * own SAVE STATES comment and
                                       * CMakeLists.txt's target_link_libraries
                                       * for why, and why this is unrelated to
                                       * mGBA's own (still OFF) USE_ZLIB. */

#ifndef mColor
typedef uint32_t mColor;
#endif
#include <mgba/gba/core.h>
#include <mgba/gba/interface.h>       /* struct GBASIODriver */
#include <mgba/internal/gba/gba.h>    /* struct GBA — needed to reach gba->sio via core->board */
#include <mgba/internal/gba/sio.h>    /* GBASIOSetDriver, enum GBASIOMode (SIO_MULTI) */

#define LOG_TAG        "mGBA-JNI"

/* ── FIX 17: durable, logcat-independent link debug logging ─────────────
 *
 * See this file's own FIX 17 comment above for the full "why". Summary:
 * copyLinkDebugLog() (MainActivity.kt) used to shell out to `logcat`,
 * which some OEM builds restrict even for an app reading back its own
 * output — confirmed by W's own device split (works on one phone, empty
 * on the other). Everything below instead writes to a plain private file
 * this app owns outright, which needs no logcat/READ_LOGS access at all.
 *
 * g_link_log_path is recorded once from Kotlin at startup
 * (nativeSetLinkLogPath(), near nativeLinkStart() below); g_link_log_file
 * itself is only actually opened later, in truncate mode, at the start of
 * every nativeLinkStart() call — see this pass's own fix at
 * nativeSetLinkLogPath() for why the open moved there instead of
 * happening immediately at startup too. Either way, a capture still
 * reflects one connection attempt, not an accumulation across a whole app
 * session. g_link_log_mutex is deliberately its own lock, never g_core_mutex
 * — LOGI/LOGW calls happen from code paths that already hold g_core_mutex
 * (e.g. inside link_sio_write_register(), called from nativeRunFrame()),
 * and pthread_mutex_t is non-recursive, so reusing it here would
 * self-deadlock the first time a log call happened on a thread already
 * holding it. */
/* THIS PASS (multiplayer log export): three defects in the old file handling
 * made a captured log less useful than it looked:
 *   1. The Kotlin side (LinkMultiplayer.linkLog) appended to the SAME file
 *      with File.appendText() while this side wrote through its own FILE*
 *      opened with "w" — two writers, two unrelated file offsets, so each
 *      could overwrite the other's bytes.
 *   2. The file was truncated in nativeLinkStart(), AFTER the Kotlin side had
 *      already logged the whole connection lifecycle (host started, client
 *      handshake, connected) — exactly the lines that matter most for
 *      "connects but the ROM sees nothing" were erased a moment later.
 *   3. At the size cap the file was reset to EMPTY, losing everything.
 * Now: this side is the ONLY writer (Kotlin forwards through nativeLinkLog()),
 * a new session starts with nativeLinkLogBegin() (called when a connection
 * ATTEMPT starts), and at the cap the file rotates to "<path>.1" instead of
 * being emptied, so the most recent two segments always survive. The export
 * in MainActivityDebugLog.kt concatenates ".1" + current. */
#define LINK_LOG_MAX_BYTES (12L * 1024 * 1024)   /* per segment — see link_log_rotate_locked() */

static pthread_mutex_t g_link_log_mutex = PTHREAD_MUTEX_INITIALIZER;
static FILE  *g_link_log_file  = NULL;
static char   g_link_log_path[512] = {0};
static long   g_link_log_bytes = 0;   /* bytes in the CURRENT segment (counted, not ftell() — external truncation can't confuse it) */

/* CALLER MUST HOLD g_link_log_mutex. */
static void link_log_rotate_locked(void)
{
    if (g_link_log_file) { fclose(g_link_log_file); g_link_log_file = NULL; }
    if (!g_link_log_path[0]) return;
    char prev[sizeof(g_link_log_path) + 4];
    snprintf(prev, sizeof(prev), "%s.1", g_link_log_path);
    rename(g_link_log_path, prev);                 /* replaces an older ".1" */
    g_link_log_file  = fopen(g_link_log_path, "a");
    g_link_log_bytes = 0;
}

/* CALLER MUST HOLD g_link_log_mutex. Starts a brand-new session log:
 * truncates the file and drops the older segment. */
static void link_log_begin_locked(void)
{
    if (g_link_log_file) { fclose(g_link_log_file); g_link_log_file = NULL; }
    if (!g_link_log_path[0]) return;
    char prev[sizeof(g_link_log_path) + 4];
    snprintf(prev, sizeof(prev), "%s.1", g_link_log_path);
    remove(prev);
    g_link_log_file  = fopen(g_link_log_path, "w");
    g_link_log_bytes = 0;
}

/* CALLER MUST HOLD g_link_log_mutex. */
static void link_log_write_locked(const char *level, const char *tag, const char *msg)
{
    if (!g_link_log_file) return;   /* no session log is open (nothing has called nativeLinkLogBegin()/nativeLinkStart() yet) */

    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    struct tm tmv;
    localtime_r(&ts.tv_sec, &tmv);
    /* Mirrors logcat's own "-v threadtime" layout (MM-DD HH:MM:SS.mmm) on
     * purpose — every existing capture in this project's history already
     * reads this way, and eyeballing/sorting two devices' logs against each
     * other by wall-clock time still works the same. */
    int n = fprintf(g_link_log_file, "%02d-%02d %02d:%02d:%02d.%03d %s %s: %s\n",
            tmv.tm_mon + 1, tmv.tm_mday, tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
            (int)(ts.tv_nsec / 1000000L), level, tag, msg);
    fflush(g_link_log_file);   /* readable by an export immediately, no clean close needed */
    if (n > 0) g_link_log_bytes += n;
    if (g_link_log_bytes > LINK_LOG_MAX_BYTES) link_log_rotate_locked();
}

static void link_log_write(const char *level, const char *msg)
{
    pthread_mutex_lock(&g_link_log_mutex);
    link_log_write_locked(level, LOG_TAG, msg);
    pthread_mutex_unlock(&g_link_log_mutex);
}

/* Replaces the old direct __android_log_print() call: still logs to
 * logcat exactly as before (so Android Studio / a real debugger attached
 * to a working device sees no change at all), and additionally mirrors
 * the same formatted line into the file above. Formats the string once
 * (not twice) and hands the plain result to both sinks. Every existing
 * LOGI(...)/LOGW(...)/LOGE(...) call site in this file is unchanged —
 * these are still plain macros, just expanding to this instead of
 * __android_log_print() directly. */
static void jni_log_line(int prio, const char *level, const char *fmt, ...)
{
    char buf[512];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    __android_log_print(prio, LOG_TAG, "%s", buf);
    link_log_write(level, buf);
}

#define LOGI(...) jni_log_line(ANDROID_LOG_INFO,  "I", __VA_ARGS__)
#define LOGW(...) jni_log_line(ANDROID_LOG_WARN,  "W", __VA_ARGS__)
#define LOGE(...) jni_log_line(ANDROID_LOG_ERROR, "E", __VA_ARGS__)

/* GBA ARM7TDMI clock — used as the blip_buf input clock rate.
 * mGBA advances blip buffers at the CPU clock, so this must match. */
#define GBA_AUDIO_CLOCK 16777216

/* ── Globals — all access must hold g_core_mutex ────────────────────────── */

static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore   *g_core   = NULL;
static mColor         *g_fb     = NULL;
static int             g_width  = 240;
static int             g_height = 160;

/* ── Link cable state — also protected by g_core_mutex ──────────────────── */

static jobject   g_link_obj      = NULL;
static jmethodID g_link_xchg_mid = NULL;
static bool      g_link_active   = false;
static bool      g_link_is_host  = false;

/* FIX 8 (build-log driven): these were previously declared far below, in the
 * "GBA LINK CABLE MULTIPLAYER" section — but nativeLoadROM and nativeRunFrame
 * both reference them earlier in the file than that, which doesn't compile
 * in C (confirmed by the actual build log: "use of undeclared identifier
 * 'g_link_gba'" / "'g_link_driver'" at the point of use). Declared here
 * instead, alongside the other link-cable globals, so every use site is
 * after the declaration regardless of where in the file it appears. */
struct LinkSIODriver {
    struct GBASIODriver d;
    JNIEnv  *env;       /* only valid while nativeRunFrame is on the stack */
    uint16_t localSend; /* last value the ROM wrote to SIOMLT_SEND (0x12A) */
};
static struct LinkSIODriver g_link_driver;
static struct GBA          *g_link_gba = NULL;

/* FIX 22 (diagnostic): last sio.rcnt/sio.siocnt values logged by
 * nativeRunFrame()'s change-detector, and whether anything has been logged
 * yet this run (so the very first check always logs a baseline instead of
 * silently depending on 0x0000/0x0000 not being a real value the ROM uses —
 * RCNT=0x0000 is exactly the Multi-Player-select value seen throughout this
 * project's own captures, so a sentinel bool is needed, not a sentinel
 * value). Declared here for the same reason as the two lines above it. */
static uint16_t g_link_last_sio_rcnt   = 0;
static uint16_t g_link_last_sio_siocnt = 0;
static bool     g_link_sio_mode_logged = false;

/* AUDIT FIX (multiplayer, host side): 1 = a transfer the host's ROM starts
 * COMPLETES a realistic number of emulated cycles later, via mGBA's event
 * timer, instead of inside the very register write that started it. 0 = the
 * previous behaviour (instant completion). If the build log ever complains
 * about mTimingSchedule / struct mTimingEvent / gba->timing — this is the only
 * code in the file that touches mGBA's timing API — set this to 0 and
 * everything else keeps working. See link_host_defer_completion(). */
#define LINK_HOST_DEFERRED_COMPLETION 1
/* How long the child's network thread waits for its game thread to take a
 * request and finish a frame with it. Must stay below the host's own wait
 * (LinkMultiplayer.kt WIFI_XCHG_MS / BT_XCHG_MS) so a child that can't answer
 * says so before the host gives up on its own. */
#define LINK_CHILD_WAIT_MS 100
static LinkMailbox    g_link_mbox;
static pthread_once_t g_link_mbox_once = PTHREAD_ONCE_INIT;
static void link_mbox_init_once(void) { lm_init(&g_link_mbox); }
static inline LinkMailbox *link_mbox(void)
{
    pthread_once(&g_link_mbox_once, link_mbox_init_once);
    return &g_link_mbox;
}

/* ── CLOCK TIE (this pass) — the actual multiplayer fix ─────────────────────
 *
 * What the two captures W sent show (host + child, same attempt):
 *   - HOST: ~107 transfers/s, each blocking 2-22 ms in the network round trip,
 *     while a transfer is only 6,410 EMULATED cycles (0.38 ms). So the host's
 *     emulated clock advanced at about 4% of real time (~2.5 fps) for as long
 *     as its ROM probed — that is the "lag the host".
 *   - CHILD: its emulation ran at full speed (60 fps) the whole time, receiving
 *     ONE host word per frame, and its ROM reset its Multi-Player hardware
 *     (RCNT=0, SIOCNT=0x2000..0x601F) every ~100 ms (~6 child frames), having
 *     seen only 7-9 of the 16 words the host sends per packet. On hardware a
 *     16-word packet arrives in ~0.4 frame; here it needed ~9 child frames, so
 *     the ROM's receive timeout fired first, every time, and neither ROM ever
 *     "detected" the other.
 * Both symptoms are one problem: the two emulated clocks were not tied. The
 * host's was stretched by the network, the child's was not, so the child's
 * ROM saw the host as ~25x slower than a real cable.
 *
 * The fix keeps the lock-step data path and ties the clocks:
 *   - Both cores run a periodic TICK event every LINK_TICK_CYCLES (one
 *     115,200-baud transfer time) of EMULATED time, counted from link start.
 *   - The host stamps every word it sends with its tick count.
 *   - The child delivers each word at the same SPACING (in its own ticks) the
 *     host's words had, not at "the start of the next frame", and — while the
 *     host is mid-burst (words closer than LINK_BURST_GAP_TICKS) — WAITS for
 *     the next word instead of running ahead (the "hold").
 *   So a burst is also a burst in the child's emulated time. While the host is
 *   idle or sending sparsely nothing is held: both run at real-time speed.
 * g_link_clock_sync = false (Settings -> Debug) restores the previous
 * one-word-per-frame behaviour for an A/B comparison. */
#define LINK_TICK_CYCLES        6410     /* one 115,200-baud 2-unit transfer — same figure as link_transfer_cycles() */
#define LINK_BURST_GAP_TICKS    12u      /* host words closer together than this = "back to back" */
#define LINK_SPACING_MAX_TICKS  128u     /* reproduce the host's gap between two words up to this long (~3 frames) */
#define LINK_HOLD_MIN_MS        12
#define LINK_HOLD_MAX_MS        120
#define LINK_GOV_SLACK_TICKS    8u       /* free-run governor: ~3 ms of emulated time of leeway over real time */
/* Flags in bits 16-23 of the child's reply (child -> host). */
#define LINK_RF_NOT_MULTI       0x01u    /* the child's ROM is not in Multi-Player mode: nobody answers this transfer */

static bool        g_link_clock_sync     = true;
static uint32_t    g_link_tick           = 0;       /* ticks of emulated time since link start (this device) */
static struct mTimingEvent g_link_tick_event;
static bool        g_link_tick_inited    = false;
static bool        g_link_tick_scheduled = false;   /* the event is in g_link_tick_core's queue */
static struct GBA *g_link_tick_core      = NULL;

/* Child-side delivery state (game thread, g_core_mutex held). */
static bool        g_ch_have_prev  = false;   /* a previous word was delivered this session */
static uint16_t    g_ch_prev_h     = 0;       /* ...its host stamp... */
static uint32_t    g_ch_prev_tick  = 0;       /* ...and the child tick it was delivered at */
static bool        g_ch_burst      = false;   /* the host is sending bursts: after each word, hold for the next one */
static int         g_ch_hold_ms    = 20;      /* how long to hold; adapts to how long the next word really takes */
static int64_t     g_ch_wait_ewma_us = 5000;
/* Free-run governor. When a hold gives up (the host went quiet, or its next word was delayed by a lost
 * packet) the child runs free again — but its game loop has just been stalled, so the audio-paced loop
 * CATCHES UP at full CPU speed, and a few real milliseconds of waiting become several emulated frames of
 * lead over the host (the two-device simulation with 1-5% packet loss showed exactly that tripping the
 * ROM's receive timeout). Until the next word lands, emulated time may therefore not run faster than
 * real time, counted from the moment the hold gave up. It is NOT applied while a word is posted: spacing
 * a word out to the host's gap advances time the host's own clock really did advance. */
static bool            g_ch_gov_active = false;
static struct timespec g_ch_gov_ts;
static uint32_t        g_ch_gov_tick0  = 0;
/* Published by the game thread for the network thread, read with __atomic_load_n: is the child's ROM in
 * Multi-Player mode right now? If not, the network thread answers at once instead of queueing a word that
 * would only be answered with "nobody here" a frame later. */
static bool        g_link_child_multi = false;

/* Cheap per-category log rate limiter: lets `perSec` lines through per second of real time and counts the
 * rest (reported in the STAT line). Needed because a host whose child is not ready answers transfers locally
 * at emulated speed — thousands per second — and an unthrottled "X" line each would bury the log and cost
 * three syscalls apiece on the game thread. */
typedef struct { uint32_t windowStartMs; uint32_t used; uint32_t suppressed; } LinkLogLimiter;
static LinkLogLimiter g_lim_x = {0, 0, 0}, g_lim_w = {0, 0, 0};
static inline bool link_log_limit(LinkLogLimiter *l, uint32_t perSec)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    const uint32_t ms = (uint32_t)((uint64_t)ts.tv_sec * 1000u + (uint64_t)ts.tv_nsec / 1000000u);
    if ((uint32_t)(ms - l->windowStartMs) >= 1000u) { l->windowStartMs = ms; l->used = 0; }
    if (l->used < perSec) { l->used++; return true; }
    l->suppressed++;
    return false;
}

/* Diagnostics, reported as one "STAT" line per second of real time. */
static uint32_t g_st_host_xfers = 0, g_st_host_to = 0, g_st_host_notmulti = 0;
static uint64_t g_st_host_rtt_us_sum = 0;
static uint32_t g_st_host_rtt_us_max = 0;
static uint32_t g_st_ch_delivered = 0, g_st_ch_holds = 0, g_st_ch_hold_to = 0;
static struct timespec g_st_last_ts;
static uint32_t g_st_last_tick = 0;
static bool     g_st_have_ts = false;

/* Defined with the rest of the link driver below; declared here because
 * nativeLoadROM()/nativeLoadState() (earlier in the file) call it. */
static void link_host_deferred_reset(bool queueDiscarded);
static void link_tick_reset(bool queueDiscarded);

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);

    /* FIX 13: this used to forward every single mGBA core log line, at any
     * level, to LOGI under the same "mGBA-JNI" tag FIX 11's link-diagnostic
     * trace also uses (see copyLinkDebugLog() in MainActivity.kt, which
     * greps logcat by tag). Confirmed this pass, both from mgba-emu/mgba's
     * real source and directly from the two logcat dumps W attached: normal
     * GBA emulation is extremely DMA/register-heavy — "Starting DMA 3
     * 0x..." and "Read from write-only I/O register: 0xNN" (the latter is
     * mLOG_STUB — see src/gba/io.c's own use of that level for exactly this
     * "wrote/read an unimplemented or wrong-direction register" case) fire
     * dozens of times per single video frame, every frame, for any ROM —
     * completely unrelated to link/multiplayer.
     * copyLinkDebugLog()'s `logcat -t 2000` grabs the most recent 2000
     * lines matching the tag filter, combined across mGBA-JNI/mGBA-Link/
     * mGBA — but with this noise included, 2000 lines is nowhere near
     * enough: both logs W attached this pass covered barely 200ms of real
     * time each, entirely boot-time DMA/register spam, nothing from
     * anywhere near the actual multiplayer attempt. (KNOWN_LIMITATIONS.md's
     * Thirteenth-pass entry describes an *earlier* capture that did contain
     * real signal — but that was this same noise co-occurring with the
     * rawWrite16 STUB spam FIX 12 has since removed, not evidence this
     * window was ever reliably wide enough.) The tag filter itself was
     * never the problem — every line in both dumps genuinely was
     * "mGBA-JNI" — the volume was.
     * Fix: drop mLOG_DEBUG/mLOG_STUB/mLOG_GAME_ERROR here before they ever
     * reach LOGI. This mirrors mGBA's own src/platform/libretro/libretro.c
     * under NDEBUG (which this project's own CMakeLists.txt also builds
     * with) — GBARetroLog() drops exactly these same three levels outright
     * in a release build. FATAL/ERROR/WARN/INFO still come through
     * unfiltered. Belt-and-suspenders on top of the level check: also drop
     * the two specific message prefixes actually observed flooding both of
     * this pass's logs, in case either turns out not to be DEBUG/STUB after
     * all — this costs nothing and directly guarantees the exact noise seen
     * is gone regardless.
     * Side benefit, not just a multiplayer fix: this logging tax has been
     * paid on *every* frame of *every* ROM since FIX 1 first wired up
     * mLogSetDefaultLogger — general gameplay was never link-related but
     * was never exempt from it either. __android_log_print is a real
     * syscall (a socket write to logd), not free; removing dozens of these
     * per frame is a plausible contributor to general perf/lag complaints
     * older than this specific multiplayer investigation, not only the
     * "lag on Bluetooth" this pass was asked about. */
    if (level & (mLOG_DEBUG | mLOG_STUB | mLOG_GAME_ERROR)) return;
    if (!strncmp(buf, "Starting DMA", 12))         return;
    if (!strncmp(buf, "Read from write-only", 21)) return;
    if (!strncmp(buf, "Write to read-only", 19))   return;

    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup — CALLER MUST HOLD g_core_mutex ───────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath, jstring jSavePath)
{
    /* FIX (residual risk from prior pass): the old core used to be destroyed
     * unconditionally here, before the new ROM was even opened. If any step
     * below failed (bad/corrupt file, core init failure, OOM), the in-progress
     * session was already gone with nothing to fall back to.
     *
     * Now the new core is built entirely in local variables — g_core/g_fb are
     * never touched — and the old core is only torn down once every step has
     * succeeded. On any failure path the caller's existing session (if any)
     * is left running exactly as it was. */

    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    LOGI("Loading ROM: %s", path);

    struct mCore *core = GBACoreCreate();
    if (!core) {
        LOGE("GBACoreCreate failed");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    mCoreInitConfig(core, "mgba-android");

    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios     = true;
    opts.useBios      = false;
    opts.sampleRate   = 44100;
    opts.audioBuffers = 1024;
    opts.volume       = 256;
    mCoreConfigLoadDefaults(&core->config, &opts);
    /* AUDIO FIX (root cause, not a symptom patch): this MUST be the single-
     * argument mCoreLoadConfig(core), not core->loadConfig(core, &core->config)
     * directly.
     *
     * mCoreLoadConfig() internally calls mCoreLoadForeignConfig(), which does
     * two things before it ever reaches the vtable loadConfig:
     *   1. mCoreConfigMap(config, &core->opts)  -- maps the "volume" key we
     *      just set above (opts.volume = 256) into core->opts.volume.
     *   2. core->setAudioBufferSize(core, core->opts.audioBuffers).
     * Only THEN does it call core->loadConfig(core, config), which for the
     * GBA core runs:  gba->audio.masterVolume = core->opts.volume;
     *
     * Calling core->loadConfig() directly (as this file previously did)
     * skips step 1 entirely, so core->opts.volume is left at its
     * zero-initialized default and every ROM's audio mixer comes up
     * permanently muted at masterVolume=0 -- silent regardless of anything
     * downstream (AudioTrack, blip_buf, etc. all work correctly; they're
     * just relaying real zeroes). This was the actual cause of "no sound";
     * the AudioTrack/AudioFocus work in the Kotlin layer was correct but
     * couldn't fix a mixer that was muted at the native layer. */
    mCoreLoadConfig(core);

    const unsigned w = 240, h = 160;

    mColor *fb = (mColor *)calloc((size_t)w * (size_t)h, sizeof(mColor));
    if (!fb) {
        LOGE("framebuffer alloc failed (%ux%u)", w, h);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, fb, (size_t)w);

    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed: %s", path);
        free(fb);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* FEATURE: battery/cart save (SRAM/Flash/EEPROM) persistence.
     * core->loadSave() hands the core a VFile it owns for the rest of this
     * core's lifetime — mGBA's savedata backend mmaps it, and every in-game
     * write (a menu's "Save the game?" prompt, an action game's checkpoint,
     * etc.) lands directly in the mapped pages, which the kernel writes back
     * to [savePath] on its own — the same durability model any mmap-backed
     * store relies on (mGBA's own VFS layer calls msync when explicitly
     * syncing mapped data). The core closes this VFile itself as part of
     * core->deinit() (see destroy_core()), so it is NOT closed here.
     *
     * O_CREAT | O_RDWR, no O_TRUNC: a fresh save is created empty and the
     * savedata backend grows it to the detected size (SRAM/Flash/EEPROM) on
     * first write; an existing file's contents are preserved untouched, so
     * re-loading the same ROM later (see MainActivity.deriveRomBaseName)
     * resumes the same in-game save.
     *
     * Order matters: this MUST run after mCoreLoadFile (the save type is
     * detected from the ROM header while loading) and before core->reset()
     * below — the same order every mGBA frontend uses (see e.g.
     * src/platform/sdl/main.c: mCoreLoadFile → mCoreAutoloadSave → … →
     * reset happens once the emulation thread actually starts). Reset only
     * reinitialises CPU/PPU/etc. state; it does not touch already-loaded
     * save data, exactly like a real GBA's power button doesn't erase the
     * cartridge's battery save. */
    if (jSavePath) {
        const char *savePath = (*env)->GetStringUTFChars(env, jSavePath, NULL);
        if (savePath) {
            struct VFile *saveVf = VFileOpen(savePath, O_CREAT | O_RDWR);
            if (saveVf) {
                if (!core->loadSave(core, saveVf)) {
                    LOGW("core->loadSave failed for %s (ROM may have no battery save)", savePath);
                }
            } else {
                LOGW("VFileOpen failed for save path: %s", savePath);
            }
            (*env)->ReleaseStringUTFChars(env, jSavePath, savePath);
        }
    } else {
        LOGW("nativeLoadROM: no save path given — battery save will not persist");
    }

    core->reset(core);

    /* ── FIX: Explicitly set blip buffer sample rates after reset ────────
     * mCoreConfigLoadDefaults+loadConfig should configure this, but on some
     * mGBA build variants loadConfig doesn't call blip_set_rates until a
     * subsequent reset — which is circular.  Calling it here unconditionally
     * after the reset guarantees both blip buffers are live before any frame
     * is rendered.  If rates were already set correctly this is a safe no-op. */
    {
        blip_t *left  = core->getAudioChannel(core, 0);
        blip_t *right = core->getAudioChannel(core, 1);
        if (left && right) {
            blip_set_rates(left,  GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            blip_set_rates(right, GBA_AUDIO_CLOCK, (double)opts.sampleRate);
            LOGI("blip_set_rates: clock=%d  sampleRate=%d",
                 GBA_AUDIO_CLOCK, (int)opts.sampleRate);
        } else {
            LOGW("getAudioChannel returned NULL — audio will be silent");
        }
    }

    /* Swap in the fully-loaded new core and only now tear down whatever was
     * running before. destroy_core() operates on the (still-old) globals, so
     * we snapshot them, install the new core, then deinit the snapshot —
     * all under one lock, so nativeRunFrame/nativeReadAudioSamples/etc. never
     * observe a half-swapped state. */
    pthread_mutex_lock(&g_core_mutex);
    struct mCore *old_core = g_core;
    mColor       *old_fb   = g_fb;
    /* SAFETY: g_link_gba points into the OLD core's GBA struct, which
     * old_core->deinit() below is about to free. If a link session was left
     * running across a ROM swap, drop it now rather than leave a dangling
     * pointer for link_sio_write_register to dereference on the next
     * transfer — the Kotlin side will see the link drop and can restart it
     * against the new ROM if the user still wants it. */
    link_host_deferred_reset(true);   /* the old core's event queue goes away with it */
    link_tick_reset(true);
    if (g_link_active) {
        g_link_active = false;
        g_link_gba    = NULL;
        lm_close(link_mbox());
        LOGW("ROM swapped while a link session was active — link stopped");
    }
    g_core   = core;
    g_fb     = fb;
    g_width  = (int)w;
    g_height = (int)h;
    pthread_mutex_unlock(&g_core_mutex);

    if (old_core) {
        old_core->deinit(old_core);
    }
    free(old_fb);

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, (int)w, (int)h);
    return JNI_TRUE;
}

/* Forward declaration — defined with the rest of the link driver below. */
static void link_frame_prologue(JNIEnv *env);

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core || !g_fb) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* FIX 7: the SIO driver callback needs a valid JNIEnv* for the duration of
     * this call only — it fires synchronously, on this same thread, from
     * inside runFrame() the instant the game writes the Start bit.
     * THIS PASS: that, plus everything else the link needs at the start of a
     * frame (keeping the clock-tie tick armed; on the legacy path, landing a
     * child's pending word), moved into link_frame_prologue() so the logic is
     * in one place and can be unit-tested (tools/native-link-test). */
    link_frame_prologue(env);
    g_core->runFrame(g_core);
    g_link_driver.env = NULL;

    /* FIX 22 (diagnostic — see the FIX 22 comment at the top of this file):
     * link_sio_write_register() above only ever runs while this core's own
     * SIO mode is SIO_MULTI — GBASIOSetDriver() registered it for that mode
     * only, same as every real per-mode SIO driver in mGBA (Game Boy Player
     * included). If either ROM's own code ever changes mode away from
     * Multi-Player — which GBATEK documents as the real mechanism a child
     * uses to signal "not ready" — every write until it changes back would
     * go completely unlogged by anything above, indistinguishable from the
     * ROM simply doing nothing. This reads the core's own raw sio.rcnt/
     * sio.siocnt directly instead, which exist regardless of which per-mode
     * driver (if any) is currently active, and logs only on a real change —
     * once per actual mode/setting transition, not once per frame. Read
     * only, no behavior here depends on the value; if the field names or
     * layout don't match this pinned mGBA build, this fails to compile and
     * says so, the same way FIX 7 originally caught its own 3-arg/2-arg
     * GBASIOSetDriver mismatch against a real build log rather than a guess. */
    if (g_link_active && g_link_gba) {
        uint16_t cur_rcnt   = g_link_gba->sio.rcnt;
        /* THIS PASS: only the mode/baud/IRQ-enable bits (the busy and status bits
         * toggle on every transfer and would log a line per frame for nothing). */
        uint16_t cur_siocnt = (uint16_t)(g_link_gba->sio.siocnt & 0x7003u);
        if (!g_link_sio_mode_logged
            || cur_rcnt != g_link_last_sio_rcnt
            || cur_siocnt != g_link_last_sio_siocnt) {
            LOGI("SIO mode: rcnt=0x%04X siocnt(mode/baud/irq)=0x%04X host=%d",
                 (unsigned)cur_rcnt, (unsigned)cur_siocnt, (int)g_link_is_host);
            g_link_last_sio_rcnt   = cur_rcnt;
            g_link_last_sio_siocnt = cur_siocnt;
            g_link_sio_mode_logged = true;
        }
    }

    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (bitmap == NULL) {
        /* PERF: fast-forward sub-frames that will never reach the screen
         * (see the Kotlin call site in MainActivity.startGameLoop — only the
         * LAST sub-frame of a fast-forward batch is displayed) pass NULL
         * here to skip the pixel copy below entirely. Emulation and audio
         * still run in full above; only the wasted blit is skipped. */
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    /* FIX (audit F2): the pixel-copy loop below treats the locked buffer as
     * uint32_t* unconditionally. Checked here, before locking, so there is
     * nothing to unlock on this path — a bitmap in any other config would
     * otherwise silently corrupt memory (4-byte writes into a differently-
     * sized buffer) instead of failing loudly. Same fail-safe shape as
     * nativeReadMemory's own guard clauses elsewhere in this file. */
    /* AUDIT FIX (JNI hardening): the copy loop below writes g_height rows of
     * g_width pixels at info.stride spacing straight into the bitmap's pixel
     * memory, and until now simply trusted the Kotlin side to have passed a
     * bitmap that large. A smaller one (a stale frame buffer left over from
     * before a core swap, say) would be a native heap overflow rather than
     * an exception. Skip the frame instead, logging once, not at 60 Hz. */
    if (info.width  < (uint32_t)g_width ||
        info.height < (uint32_t)g_height ||
        info.stride < (uint32_t)g_width * 4u) {
        static bool s_size_warned = false;
        if (!s_size_warned) {
            s_size_warned = true;
            LOGW("nativeRunFrame: bitmap %ux%u (stride %u) smaller than core frame %dx%d, skipping frames",
                 info.width, info.height, info.stride, g_width, g_height);
        }
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        LOGW("nativeRunFrame: unexpected bitmap format %d (expected RGBA_8888), skipping frame",
             (int)info.format);
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    for (int row = 0; row < g_height; row++) {
        const mColor *srcRow = g_fb + (size_t)row * (size_t)g_width;
        uint32_t     *dstRow = (uint32_t *)((uint8_t *)pixels
                                            + (size_t)row * info.stride);
        for (int col = 0; col < g_width; col++) {
            dstRow[col] = (srcRow[col] & 0x00FFFFFFu) | 0xFF000000u;
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeReadAudioSamples ─────────────────────────────────────────────── */
/*
 * FIX 4 — drain mGBA blip buffers into a Java short[] for AudioTrack.
 *
 * blip_read_samples(buf, arr, count, stereo=1) writes to every OTHER element
 * when stereo=1, so we can interleave L and R in one pass each:
 *   L → arr[0], arr[2], arr[4]…
 *   R → arr[1], arr[3], arr[5]…
 *
 * Returns the number of stereo sample PAIRS written (array elements used = n*2).
 * Returns 0 when no samples are available or the core is not initialised.
 *
 * Called from the game thread immediately after nativeRunFrame(), so the mutex
 * is always available (no nested locking).
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeReadAudioSamples(
        JNIEnv *env, jobject thiz, jshortArray jbuf, jint maxSamples)
{
    /* AUDIT FIX (JNI hardening): `maxSamples` is a count of stereo PAIRS the
     * caller claims jbuf has room for (2 shorts each). It was never checked
     * against the array's real length, so a mismatched call would write
     * past the end of the Java array's backing memory. Clamp to what the
     * array can actually hold. */
    if (jbuf == NULL || maxSamples <= 0) return 0;
    {
        const jint maxPairs = (jint)((*env)->GetArrayLength(env, jbuf) / 2);
        if (maxPairs <= 0) return 0;
        if (maxSamples > maxPairs) maxSamples = maxPairs;
    }

    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    blip_t *left  = g_core->getAudioChannel(g_core, 0);
    blip_t *right = g_core->getAudioChannel(g_core, 1);
    if (!left || !right) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    int availL = blip_samples_avail(left);
    int availR = blip_samples_avail(right);
    /* AUDIO FIX: previously only availL was checked and re-used for both
     * blip_read_samples() calls, on the assumption the two channels are
     * always in lockstep (true for mGBA's GBA core in normal operation, but
     * not something the JNI layer should silently assume — reading more
     * samples than a channel actually has buffered is undefined behavior in
     * blip_buf, not a safely-clamped no-op). Take the minimum of both. */
    int avail = (availL < availR) ? availL : availR;
    int count = (avail < (int)maxSamples) ? avail : (int)maxSamples;
    if (count <= 0) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    jshort *arr = (*env)->GetShortArrayElements(env, jbuf, NULL);
    if (!arr) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    /* stereo=1: write to every other element, perfect for L/R interleaving */
    blip_read_samples(left,  arr,     count, 1);   /* → [0],[2],[4]…  */
    blip_read_samples(right, arr + 1, count, 1);   /* → [1],[3],[5]…  */

    (*env)->ReleaseShortArrayElements(env, jbuf, arr, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return (jint)count;
}

/* Upper bound on one nativeReadMemory() call. The memory viewer asks for 512
 * bytes; 64 KiB leaves ample headroom while keeping any single read (done
 * under g_core_mutex) short. */
#define MGBA_MEM_READ_MAX 0x10000

/* ── nativeReadMemory ────────────────────────────────────────────────────── */
/*
 * Live memory inspector (requested feature — watching a Pokémon battle's
 * live RAM was the specific example). Fills [jbuf] with [length] bytes read
 * one at a time from core->busRead8(core, address), address incrementing by
 * one each call — the exact same busRead8/16/32 dispatch mGBA's own cheat
 * system reads through (src/core/cheats.c's _readMem()), just always 8-bit
 * width here since a hex-dump viewer wants raw bytes, not typed values.
 * Same "caller allocates, native fills" shape as nativeReadAudioSamples()
 * above.
 *
 * Read-only by design — see EmulatorEngine.nativeReadMemory()'s own doc
 * comment for why a busWrite8() counterpart isn't included here even
 * though it would be a small, symmetric addition.
 *
 * Held under g_core_mutex for the whole read, same discipline as every
 * other g_core access in this file — this can be called from the UI
 * thread's Handler.postDelayed() refresh loop (see
 * MainActivity.scheduleMemoryRefresh()), not just the game thread, so it
 * cannot assume it already holds the lock the way some game-thread-only
 * functions elsewhere in this file safely do.
 *
 * Returns 0 (jbuf left untouched) if the core isn't initialised (no ROM
 * loaded) or [length] isn't positive. Otherwise returns the number of bytes
 * read — [length], clamped to jbuf's size and MGBA_MEM_READ_MAX:
 * busRead8() on an address with nothing meaningfully mapped there still
 * returns *some* value (open bus, same as real hardware) rather than
 * failing, so there's no distinct "bad address" case for this function to
 * report — an unmapped/meaningless region is for the viewer to show, not
 * for this function to detect.
 */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeReadMemory(
        JNIEnv *env, jobject thiz, jint address, jbyteArray jbuf, jint length)
{
    /* AUDIT FIX (JNI hardening): `length` was trusted to fit jbuf, and was
     * unbounded — a bad value both overflowed the array and held the core
     * mutex (blocking the game thread) for the whole read loop. Clamp it to
     * the array's real size and to MGBA_MEM_READ_MAX. The return value is
     * the number of bytes actually read, which the caller already uses
     * rather than assuming `length`. */
    if (length <= 0 || jbuf == NULL) return 0;
    {
        const jsize jbufLen = (*env)->GetArrayLength(env, jbuf);
        if (length > (jint)jbufLen) length = (jint)jbufLen;
        if (length > MGBA_MEM_READ_MAX) length = MGBA_MEM_READ_MAX;
        if (length <= 0) return 0;
    }

    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    jbyte *arr = (*env)->GetByteArrayElements(env, jbuf, NULL);
    if (!arr) { pthread_mutex_unlock(&g_core_mutex); return 0; }

    for (jint i = 0; i < length; i++) {
        arr[i] = (jbyte)g_core->busRead8(g_core, (uint32_t)address + (uint32_t)i);
    }

    (*env)->ReleaseByteArrayElements(env, jbuf, arr, 0);
    pthread_mutex_unlock(&g_core_mutex);
    return length;
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint w = (jint)g_width;
    pthread_mutex_unlock(&g_core_mutex);
    return w;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint h = (jint)g_height;
    pthread_mutex_unlock(&g_core_mutex);
    return h;
}

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("mGBA core destroyed");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * SAVE STATES
 * ═══════════════════════════════════════════════════════════════════════════
 * Full emulator snapshots (CPU/PPU/audio/in-flight save data/RTC — enough to
 * resume mid-frame exactly where you left off), independent of the battery
 * save handled in nativeLoadROM above. Written via mCoreSaveStateNamed()/
 * mCoreLoadStateNamed() — completely unmodified, and always against an
 * ordinary VFile exactly as before — at whatever path the Kotlin layer
 * passes in. As of this pass that VFile is an in-memory one (VFileMemChunk)
 * during the actual save/load call, with this file compressing/decompressing
 * on the file-backed side of it; see the compression comment right below
 * this one for the full "why" and the on-disk format.
 *
 * These *Named variants (not mCoreSaveState()/mCoreLoadState()'s slot-number
 * API) are used deliberately: the slot API resolves numbered slots through
 * core->dirs.state, a VDir this app never sets up (mCoreInitConfig() above
 * only loads config values — see nativeLoadROM — it doesn't attach
 * directories the way a desktop frontend's mDirectorySetAttachBase() call
 * would). The Named variants take an explicit VFile instead and need no
 * such setup; MainActivity.kt manages "slots" itself as plain files.
 *
 * Flags: SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA.
 * SAVESTATE_SCREENSHOT is deliberately excluded — this build has USE_PNG and
 * USE_ZLIB both OFF (see CMakeLists.txt), and PNG-embedded screenshot
 * support in src/core/serialize.c is gated behind USE_PNG. SAVESTATE_CHEATS
 * is excluded because this app never attaches a cheat device. (This pass
 * links system zlib directly into this file for the compression wrapper
 * below — see CMakeLists.txt's target_link_libraries — which is unrelated
 * to mGBA's own USE_ZLIB CACHE var above, still OFF, still only gating the
 * PNG/SAVESTATE_SCREENSHOT path just described.) */

/* ── Save-state compression (this pass) ──────────────────────────────────
 *
 * Direct ask: shrink save-state files on disk without changing mGBA's own
 * serialized-state format or touching mCoreSaveStateNamed()/
 * mCoreLoadStateNamed() themselves.
 *
 * Shape: mCoreSaveStateNamed() writes its complete, unmodified output —
 * core state plus the SAVESTATE_SAVEDATA/RTC/METADATA extdata, all of it,
 * exactly as it already interleaves them — into a growable in-memory VFile
 * (VFileMemChunk(0, 0), the same call mGBA's own src/core/rewind.c already
 * uses to hold a full save state for its rewind buffer) instead of a
 * file-backed one. That buffer is then compressed as one opaque blob and
 * written to `path` behind a small header; mCoreSaveStateNamed() never
 * knows its output didn't go straight to a file. Loading reverses this:
 * decompress back into another VFileMemChunk and hand that to
 * mCoreLoadStateNamed() exactly as a file-backed VFile would have been.
 * The mGBA-internal state bytes are never altered or reinterpreted, only
 * moved through memory once each way.
 *
 * Library: this project has no Zstd anywhere — adding it would mean a
 * whole second FetchContent dependency alongside mGBA's own, a new CMake
 * target, and real CI build-time cost, for a single-shot buffer compress/
 * decompress that doesn't need anything Zstd-specific. zlib, by contrast,
 * ships with every Android NDK as a system library (like `log`/`android`/
 * `jnigraphics` already linked below — nothing to fetch or vendor), and
 * its one-shot compress2()/uncompress() calls are exactly this job.
 * Level Z_BEST_SPEED (1, zlib's fastest) for the same reason the direct
 * ask wanted Zstd level 1-2 over higher ratios: Quick Save should never
 * feel slower than it already did.
 *
 * On-disk format: [magic:4]["MGCZ", 4 ASCII bytes — a real mGBA save state
 * begins with binary core-state fields, not ASCII, so this can't reasonably
 * collide][version:4][original_size:8][compressed_size:8][zlib payload,
 * compressed_size bytes]. Every header field is written/read individually
 * (never a raw struct read/write) so on-disk layout can't drift with
 * compiler struct padding; all are native-endian, which is fine — these
 * files are only ever written and read back by this same app on the same
 * device.
 *
 * Loading detects the header by its magic before doing anything else, and
 * only decompresses when it's actually present — an existing uncompressed
 * save state has no such prefix and falls straight through to the exact
 * original file-backed-VFile-into-mCoreLoadStateNamed() path, unchanged.
 * A version mismatch, an implausible size field, a truncated payload, or a
 * failed decompression are all rejected safely (return false, nothing
 * freed twice, nothing left open) rather than risking a crash or loading
 * garbage into the core. Size fields are capped well below what a real
 * save state could ever need before either is ever passed to malloc(), so
 * a corrupted or hand-crafted header can't force a huge allocation.
 *
 * Nothing about the numbered-slot/Quick-Save/thumbnail/delete system above
 * this file changes: every one of those still just hands nativeSaveState()/
 * nativeLoadState() a path and reads back a bool, exactly as before. */

static const uint8_t MGBA_STATE_MAGIC[4] = { 'M', 'G', 'C', 'Z' };
#define MGBA_STATE_FORMAT_VERSION 1u
#define MGBA_STATE_HEADER_SIZE 24 /* 4 (magic) + 4 (version) + 8 (original_size) + 8 (compressed_size) */

/* A real GBA save state (core state + SAVESTATE_SAVEDATA/RTC/METADATA
 * extdata) is at most a few hundred KB — nowhere near this. 64 MiB is
 * ~100x that with room to spare, while still safely rejecting a corrupted
 * or malicious size field before it ever reaches malloc(). Applied to
 * both original_size and compressed_size. */
#define MGBA_STATE_MAX_SIZE (64u * 1024u * 1024u)

/* ── Save-state file output helper ───────────────────────────────────────
 *
 * write() can legally write fewer bytes than asked (and be interrupted by a
 * signal), so a single call is not enough to know a whole buffer landed.
 * Plain POSIX here rather than the VFile wrapper: the save path below needs
 * fsync() before close, and going through open()/write()/fsync()/close()
 * directly keeps that guarantee independent of how this pinned mGBA
 * revision's VFile sync() is declared. */
static bool write_all_fd(int fd, const void *buf, size_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    while (len > 0) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (n == 0) return false;
        p   += (size_t)n;
        len -= (size_t)n;
    }
    return true;
}

/* AUDIT FIX (native save/load lock scope). g_core_mutex used to be held for
 * the ENTIRE duration of nativeSaveState()/nativeLoadState() — including the
 * zlib compress/decompress and every file read/write. The game thread takes
 * that same mutex for every nativeRunFrame()/nativeReadAudioSamples() call,
 * so on slow or busy storage a Quick Save froze emulation (and starved the
 * AudioTrack into an underrun) for as long as the disk took.
 *
 * The lock is now held only for the two calls that actually touch the core:
 * mCoreSaveStateNamed() (which snapshots the core into a private in-memory
 * VFile) and mCoreLoadStateNamed() (which reads a private in-memory VFile
 * back in). Everything else — compressing, decompressing, reading the slot
 * file, writing the slot file — works on buffers nothing else can see, so it
 * runs unlocked. The emitted bytes and the on-disk format are unchanged.
 *
 * Also new: the compressed state is fsync()ed before the file is closed.
 * SaveEntry.commitWrite() (Kotlin) renames this file over the real slot; a
 * rename is only crash-safe if the data it publishes has already reached
 * storage, otherwise a power loss can leave the renamed-into-place slot
 * empty. */
JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSaveState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    (void)thiz;

    /* All locals declared up front: the single `done:` exit below jumps over
     * the code between here and there. */
    jboolean      result    = JNI_FALSE;
    const char   *path      = NULL;
    struct VFile *memVf     = NULL;
    void         *stateBuf  = NULL;
    size_t        origSize  = 0;
    ssize_t       origSizeS = 0;
    uint8_t      *destBuf   = NULL;
    uLong         destCap   = 0;
    uLongf        destLen   = 0;
    int           zret      = Z_OK;
    bool          haveCore  = false;
    bool          snapOk    = false;
    int           fd        = -1;
    uint8_t       header[MGBA_STATE_HEADER_SIZE];
    uint32_t      version   = MGBA_STATE_FORMAT_VERSION;
    uint64_t      origSize64 = 0;
    uint64_t      compSize64 = 0;
    bool          wrote     = false;
    bool          synced    = false;
    bool          closed    = false;

    path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;

    memVf = VFileMemChunk(0, 0);
    if (!memVf) {
        LOGE("nativeSaveState: VFileMemChunk failed");
        goto done;
    }

    /* The only locked section: snapshot the core into memVf. */
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) {
        haveCore = true;
        snapOk = mCoreSaveStateNamed(g_core, memVf,
            SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    }
    pthread_mutex_unlock(&g_core_mutex);

    if (!haveCore) {
        LOGW("nativeSaveState: no ROM loaded");
        goto done;
    }
    if (!snapOk) {
        LOGE("nativeSaveState: mCoreSaveStateNamed failed");
        goto done;
    }

    origSizeS = memVf->size(memVf);
    if (origSizeS <= 0 || (size_t)origSizeS > MGBA_STATE_MAX_SIZE) {
        LOGE("nativeSaveState: implausible state size %zd", origSizeS);
        goto done;
    }
    origSize = (size_t)origSizeS;

    stateBuf = memVf->map(memVf, origSize, MAP_READ);
    if (!stateBuf) {
        LOGE("nativeSaveState: map(MAP_READ) failed");
        goto done;
    }

    /* compressBound()'s own worst-case bound is always >= origSize, so this
     * single allocation is guaranteed enough regardless of how compressible
     * the state turns out to be — no retry-with-bigger-buffer path needed. */
    destCap = compressBound((uLong)origSize);
    destBuf = malloc(destCap);
    if (!destBuf) {
        LOGE("nativeSaveState: compression buffer alloc failed (%lu bytes)",
             (unsigned long)destCap);
        goto done;
    }
    destLen = destCap;
    zret = compress2(destBuf, &destLen, (const Bytef *)stateBuf,
                     (uLong)origSize, Z_BEST_SPEED);
    if (zret != Z_OK) {
        LOGE("nativeSaveState: compress2 failed (%d)", zret);
        goto done;
    }

    /* Nothing above has touched `path`: any failure before this point leaves
     * whatever was there exactly as it was. */
    fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) {
        LOGE("nativeSaveState: open failed: %s", strerror(errno));
        goto done;
    }

    memcpy(header, MGBA_STATE_MAGIC, 4);
    memcpy(header + 4, &version, 4);
    origSize64 = (uint64_t)origSize;
    memcpy(header + 8, &origSize64, 8);
    compSize64 = (uint64_t)destLen;
    memcpy(header + 16, &compSize64, 8);

    wrote  = write_all_fd(fd, header, MGBA_STATE_HEADER_SIZE) &&
             write_all_fd(fd, destBuf, (size_t)destLen);
    synced = wrote && fsync(fd) == 0;
    closed = close(fd) == 0;   /* close exactly once, success or not */
    fd = -1;
    if (!wrote || !synced || !closed) {
        LOGE("nativeSaveState: writing compressed state failed (wrote=%d synced=%d closed=%d)",
             (int)wrote, (int)synced, (int)closed);
        goto done;
    }

    LOGI("nativeSaveState: OK (%zu -> %lu bytes)", origSize, (unsigned long)destLen);
    result = JNI_TRUE;

done:
    free(destBuf);
    if (stateBuf) memVf->unmap(memVf, stateBuf, origSize);
    if (memVf)    memVf->close(memVf);
    if (path)     (*env)->ReleaseStringUTFChars(env, jpath, path);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadState(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    (void)thiz;

    jboolean      result      = JNI_FALSE;
    const char   *path        = NULL;
    struct VFile *vf          = NULL;   /* the slot file on disk */
    struct VFile *memVf       = NULL;   /* decompressed copy, compressed case only */
    struct VFile *loadVf      = NULL;   /* whichever of the two goes to the core */
    uint8_t      *compBuf     = NULL;
    void         *dst         = NULL;
    const char   *kind        = "uncompressed";
    uint8_t       header[MGBA_STATE_HEADER_SIZE];
    ssize_t       headerRead  = 0;
    bool          isCompressed = false;
    uint32_t      version     = 0;
    uint64_t      origSize64  = 0;
    uint64_t      compSize64  = 0;
    ssize_t       fileSize    = 0;
    bool          sizesValid  = false;
    size_t        origSize    = 0;
    size_t        compSize    = 0;
    ssize_t       compRead    = 0;
    uLongf        destLen     = 0;
    int           zret        = Z_OK;
    bool          haveCore    = false;
    bool          ok          = false;

    path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    vf = VFileOpen(path, O_RDONLY);
    (*env)->ReleaseStringUTFChars(env, jpath, path);   /* not needed past this point */
    if (!vf) {
        LOGW("nativeLoadState: slot file missing or unreadable");
        return JNI_FALSE;
    }

    /* Peek at the header before deciding how to read the rest of the file —
     * never decompress blindly. An existing uncompressed save state (or
     * anything short/foreign) has no MGBA_STATE_MAGIC prefix and must keep
     * loading exactly as it always did. */
    headerRead = vf->read(vf, header, MGBA_STATE_HEADER_SIZE);
    isCompressed = headerRead == MGBA_STATE_HEADER_SIZE &&
        memcmp(header, MGBA_STATE_MAGIC, 4) == 0;

    if (!isCompressed) {
        vf->seek(vf, 0, SEEK_SET);
        loadVf = vf;
    } else {
        kind = "compressed";
        memcpy(&version, header + 4, 4);
        memcpy(&origSize64, header + 8, 8);
        memcpy(&compSize64, header + 16, 8);

        fileSize = vf->size(vf);
        sizesValid = version == MGBA_STATE_FORMAT_VERSION &&
            origSize64 > 0 && origSize64 <= MGBA_STATE_MAX_SIZE &&
            compSize64 > 0 && compSize64 <= MGBA_STATE_MAX_SIZE &&
            fileSize >= 0 &&
            (uint64_t)fileSize >= (uint64_t)MGBA_STATE_HEADER_SIZE + compSize64;
        if (!sizesValid) {
            LOGE("nativeLoadState: corrupt compressed-state header (version=%u)", version);
            goto done;
        }
        origSize = (size_t)origSize64;
        compSize = (size_t)compSize64;

        compBuf = malloc(compSize);
        if (!compBuf) {
            LOGE("nativeLoadState: compressed-buffer alloc failed (%zu bytes)", compSize);
            goto done;
        }
        compRead = vf->read(vf, compBuf, compSize);
        if (compRead != (ssize_t)compSize) {
            LOGE("nativeLoadState: truncated compressed payload");
            goto done;
        }

        /* Decompress straight into a fresh in-memory VFile's own backing
         * buffer — truncate() grows it, then map(..., MAP_WRITE) hands back
         * a pointer into that same allocation — so this never holds two
         * full copies of the decompressed state at once. */
        memVf = VFileMemChunk(0, 0);
        if (!memVf) {
            LOGE("nativeLoadState: VFileMemChunk failed");
            goto done;
        }
        memVf->truncate(memVf, origSize);
        dst = memVf->map(memVf, origSize, MAP_WRITE);
        if (!dst) {
            LOGE("nativeLoadState: map(MAP_WRITE) failed");
            goto done;
        }
        destLen = (uLongf)origSize;
        zret = uncompress((Bytef *)dst, &destLen, (const Bytef *)compBuf, (uLong)compSize);
        memVf->unmap(memVf, dst, origSize);
        dst = NULL;
        if (zret != Z_OK || destLen != origSize) {
            LOGE("nativeLoadState: uncompress failed (%d)", zret);
            goto done;
        }
        memVf->seek(memVf, 0, SEEK_SET);
        loadVf = memVf;
    }

    /* The only locked section: hand the ready-to-read VFile to the core. */
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) {
        haveCore = true;
        ok = mCoreLoadStateNamed(g_core, loadVf,
            SAVESTATE_SAVEDATA | SAVESTATE_RTC | SAVESTATE_METADATA);
    }
    pthread_mutex_unlock(&g_core_mutex);

    if (!haveCore) {
        LOGW("nativeLoadState: no ROM loaded");
        goto done;
    }
    /* AUDIT FIX: a successful load rebuilds the core's event queue, dropping
     * the link driver's transfer-complete event if one was in flight. */
    if (ok) {
        pthread_mutex_lock(&g_core_mutex);
        link_host_deferred_reset(true);
        link_tick_reset(true);   /* the tick event was in that queue too; link_frame_prologue() puts it back next frame */
        pthread_mutex_unlock(&g_core_mutex);
    }
    LOGI("nativeLoadState: %s (%s)", ok ? "OK" : "FAILED", kind);
    result = ok ? JNI_TRUE : JNI_FALSE;

done:
    free(compBuf);
    if (vf)    vf->close(vf);
    if (memVf) memVf->close(memVf);
    return result;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * GBA LINK CABLE MULTIPLAYER
 * ═══════════════════════════════════════════════════════════════════════════ */

/* FIX 17 — see the file-header comment and link_log_write() above. Call
 * once, early (MainActivity.onCreate(), before any link session can
 * start) with a path under this app's own filesDir — always writable, no
 * permission needed, unlike reading back OS logcat.
 *
 * FIX (this pass — audit finding: every qualifying core log line, from
 * anywhere in the core, paid a real fprintf+fflush+ftell for the entire
 * app session, single-player included, because this used to open the file
 * immediately and unconditionally): now only records the path.
 * nativeLinkStart() below already unconditionally (re-)opens the file in
 * truncate mode at the start of every actual link session — see its own
 * "fresh log per connection attempt" block — so no other change is needed
 * for the file to still open correctly the first time a session starts;
 * this function simply no longer opens it *before* that point. Every
 * LOGI/LOGW/LOGE call made before the first link session now hits
 * link_log_write_locked()'s existing `if (!g_link_log_file) return;`
 * short-circuit — a cheap mutex lock/unlock and a NULL check, no real
 * file I/O — instead of a full formatted write. */
JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetLinkLogPath(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    (void)thiz;
    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;

    pthread_mutex_lock(&g_link_log_mutex);
    strncpy(g_link_log_path, path, sizeof(g_link_log_path) - 1);
    g_link_log_path[sizeof(g_link_log_path) - 1] = '\0';
    pthread_mutex_unlock(&g_link_log_mutex);

    (*env)->ReleaseStringUTFChars(env, jpath, path);
    LOGI("Link log path recorded: %s (opens once a link session actually starts)", g_link_log_path);
    return JNI_TRUE;
}

/* THIS PASS: starts a brand-new session log (truncates the file, drops the older
 * ".1" segment). Kotlin calls it when a connection ATTEMPT begins — Host /
 * Join / Bluetooth — so the whole story, handshake included, is in one file. */
JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkLogBegin(JNIEnv *env, jobject thiz)
{
    (void)env; (void)thiz;
    pthread_mutex_lock(&g_link_log_mutex);
    link_log_begin_locked();
    pthread_mutex_unlock(&g_link_log_mutex);
}

/* THIS PASS: the Kotlin side's only way into the log file (see the comment at
 * LINK_LOG_MAX_BYTES for why there must be exactly one writer). level: 0 info,
 * 1 warning, 2 error. */
JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkLog(
        JNIEnv *env, jobject thiz, jint level, jstring jmsg)
{
    (void)thiz;
    if (!jmsg) return;
    const char *msg = (*env)->GetStringUTFChars(env, jmsg, NULL);
    if (!msg) return;
    pthread_mutex_lock(&g_link_log_mutex);
    link_log_write_locked(level >= 2 ? "E" : (level == 1 ? "W" : "I"), "mGBA-Link", msg);
    pthread_mutex_unlock(&g_link_log_mutex);
    (*env)->ReleaseStringUTFChars(env, jmsg, msg);
}

/* ── FIX 20: experimental exchange pacing — see the FIX 20 comment at the
 * top of this file for the full reasoning. This block is a self-contained,
 * OFF-able diagnostic: set LINK_PACE_EXCHANGES to 0 to remove every effect
 * of it and fall back to this file's exact prior (unpaced) behavior. ── */
#define LINK_PACE_EXCHANGES 1

/* One emulated GBA video frame, in cycles, at the GBA's fixed 16.777216MHz
 * clock (GBA_AUDIO_CLOCK above — reused here rather than a second constant
 * for the same real hardware clock rate). 280896 cycles/frame is the real,
 * fixed GBA value (308*228 dots/frame at 4 cycles/dot) — this yields the
 * well-known ~59.7275Hz refresh rate, not a guess or a round number. */
#define LINK_GBA_CYCLES_PER_FRAME 280896L
#define LINK_MIN_EXCHANGE_INTERVAL_NS \
    ((int64_t)LINK_GBA_CYCLES_PER_FRAME * 1000000000LL / GBA_AUDIO_CLOCK)

/* CLOCK_MONOTONIC, not CLOCK_REALTIME — this is an interval measurement,
 * not a log timestamp (link_log_write_locked() above uses REALTIME for
 * exactly that reason; this is deliberately the other one), so it can't be
 * upset by a wall-clock adjustment mid-session. Reset in nativeLinkStart()
 * so a fresh connection attempt never paces its very first exchange against
 * a stale timestamp left over from a previous session. */
static struct timespec g_link_last_exchange_ts;
static bool            g_link_last_exchange_set = false;

/* FIX 21 — bounds FIX 20's pacing to a short window per negotiation attempt
 * instead of the whole session. See the FIX 21 comment at the top of this
 * file for the evidence this responds to. Armed (window restarted) in
 * nativeLinkStart() and every time the local device writes RCNT — i.e. at
 * the start of a session and again every time the ROM's own negotiation
 * restarts itself — and expires on its own after LINK_PACE_WINDOW_NS with
 * no further action needed. Outside an armed window, link_pace_exchange()
 * does nothing at all: no clock read, no possible sleep. */
#define LINK_PACE_WINDOW_NS (3000000000LL)   /* 3s: comfortably longer than
   the ~1.3s a real capture took to start producing varied childData after
   a reset, comfortably shorter than the ~15-17s a stuck attempt took to
   give up and reset again — see FIX 21 comment for the capture this is
   read from. Long enough to cover the part pacing actually seems to help,
   short enough that it can't become a standing tax on an established,
   real-time-sensitive connection. */
static struct timespec g_link_pace_window_start;
static bool            g_link_pace_window_active = false;

static void link_pace_arm_window(void)
{
#if LINK_PACE_EXCHANGES
    clock_gettime(CLOCK_MONOTONIC, &g_link_pace_window_start);
    g_link_pace_window_active = true;
    g_link_last_exchange_set  = false;  /* don't pace the window's own first exchange against a stale gap */
#endif
}

/* CALLER MUST HOLD g_core_mutex (same requirement as link_exchange() right
 * below, which every caller already holds it for). Blocks the calling
 * thread only while an window armed by link_pace_arm_window() is still
 * open — already expected here in that case, since link_exchange() itself
 * already blocks for a real network round-trip immediately after this
 * returns. A no-op (no clock read at all) once the window has expired. */
__attribute__((unused))   /* no longer called at all — see the CLOCK TIE comment; kept for reference */
static void link_pace_exchange(void)
{
#if LINK_PACE_EXCHANGES
    if (!g_link_pace_window_active) return;

    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);

    int64_t since_armed_ns = (int64_t)(now.tv_sec - g_link_pace_window_start.tv_sec) * 1000000000LL
                            + (int64_t)(now.tv_nsec - g_link_pace_window_start.tv_nsec);
    if (since_armed_ns >= LINK_PACE_WINDOW_NS) {
        g_link_pace_window_active = false;   /* window expired: go back to full speed, no sleep this call either */
        return;
    }

    if (g_link_last_exchange_set) {
        int64_t elapsed_ns = (int64_t)(now.tv_sec - g_link_last_exchange_ts.tv_sec) * 1000000000LL
                            + (int64_t)(now.tv_nsec - g_link_last_exchange_ts.tv_nsec);
        int64_t remaining_ns = LINK_MIN_EXCHANGE_INTERVAL_NS - elapsed_ns;
        if (remaining_ns > 0) {
            struct timespec req;
            req.tv_sec  = (time_t)(remaining_ns / 1000000000LL);
            req.tv_nsec = (long)(remaining_ns % 1000000000LL);
            nanosleep(&req, NULL);   /* best-effort; an early wake (signal) just paces slightly less than the target */
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &g_link_last_exchange_ts);
    g_link_last_exchange_set = true;
#endif
}

/* THIS PASS: also hands the host's tick count (the "stamp") to Kotlin so it
 * travels with the word — see the CLOCK TIE comment near the link globals. The
 * return value is -1 (0xFFFFFFFF) for "no answer", otherwise bits 0-15 = the
 * child's word and bits 16-23 = LINK_RF_* flags. */
static uint32_t link_exchange(JNIEnv *env, uint32_t local_data, uint16_t stamp)
{
    if (!env || !g_link_obj || !g_link_xchg_mid) return 0xFFFFFFFFu;
    jint r = (*env)->CallIntMethod(env, g_link_obj,
                                    g_link_xchg_mid, (jint)local_data, (jint)stamp);
    if ((*env)->ExceptionOccurred(env)) {
        (*env)->ExceptionClear(env);
        return 0xFFFFFFFFu;
    }
    return (uint32_t)r;
}

/* ── AUDIT FIX (multiplayer): shared SIO register helpers ─────────────────
 *
 * Both are called with g_core_mutex held, from the GAME thread only.
 *
 * link_sio_is_multi(): true while the ROM has the core's SIO in Multi-Player
 * mode (RCNT bits 15-14 = 0, SIOCNT bits 13-12 = 2). SIOMULTI0-3 share
 * addresses with SIODATA32 and friends, so they must only be written while
 * the ROM is actually in this mode.
 *
 * link_child_apply(): lands one transfer in the CHILD's registers.
 *
 *  - SIOCNT is updated in the core's real register, gba->sio.siocnt, as well
 *    as in memory.io[]. This is the important fix: mGBA serves ROM reads of
 *    SIOCNT from the GBASIO struct (the very field nativeRunFrame() already
 *    logs and FIX 22 reads), not from memory.io[], and FIX 18 only ever wrote
 *    memory.io[]. So on the child the ROM never saw its player ID (bits 4-5
 *    = 1), never saw the busy bit pulse, and could not tell it was child 1 —
 *    plausibly why both phones' ROMs behaved as if they were player 0. Both
 *    places are written so this is correct whichever one a given mGBA build
 *    reads.
 *  - Mode bits 12-13, baud and IRQ-enable are preserved exactly as the ROM
 *    set them; only bits 2, 3, 4-5 and 7 are normalised.
 *  - The SIO IRQ is raised only if the ROM enabled it (SIOCNT bit 14), as on
 *    hardware. It used to be raised unconditionally, so a ROM polling with
 *    its SIO IRQ disabled but IE.SERIAL set got interrupts a real GBA would
 *    never deliver. */
static bool link_sio_is_multi(const struct GBA *gba)
{
    return (gba->sio.rcnt & 0xC000u) == 0u && (gba->sio.siocnt & 0x3000u) == 0x2000u;
}

static void link_child_apply(uint16_t hostData, uint16_t childData)
{
    struct GBA *gba = g_link_gba;
    gba->memory.io[0x0120u >> 1] = hostData;
    gba->memory.io[0x0122u >> 1] = childData;
    gba->memory.io[0x0124u >> 1] = 0xFFFFu;
    gba->memory.io[0x0126u >> 1] = 0xFFFFu;
    uint16_t siocnt = gba->sio.siocnt;
    siocnt |= 0x000Cu;                                   /* bit3: all ready, bit2: child */
    siocnt = (uint16_t)((siocnt & ~0x0030u) | 0x0010u);  /* bits 4-5: child ID 1 */
    siocnt &= (uint16_t)~0x0080u;                        /* bit7: transfer complete */
    gba->sio.siocnt = siocnt;
    gba->memory.io[0x0128u >> 1] = siocnt;
    if (siocnt & 0x4000u) GBARaiseIRQ(gba, GBA_IRQ_SIO, 0);
}

static inline uint32_t link_elapsed_us(const struct timespec *a, const struct timespec *b)
{
    int64_t d = (int64_t)(b->tv_sec - a->tv_sec) * 1000000LL + (int64_t)(b->tv_nsec - a->tv_nsec) / 1000LL;
    if (d < 0) return 0u;
    if (d > 0xFFFFFFFFLL) return 0xFFFFFFFFu;
    return (uint32_t)d;
}

/* Lands one host word in the CHILD core, picks the reply and releases the
 * waiting network thread (game thread, g_core_mutex held).
 *
 * The reply is the word this child's ROM had staged in SIOMLT_SEND at THIS
 * moment — what a real child puts on the wire when the parent clocks the
 * transfer. It is released now, at delivery: what keeps the exchange in
 * lock-step is WHEN delivery happens (once per link tick at most, at the host's
 * own spacing — see link_child_tick()), so the host's next word can only
 * arrive after this core has run the ISR that stages the next one.
 * A ROM that is not in Multi-Player mode answers 0xFFFF and says so in the
 * flags, so the host can stop waiting on it (see LinkMultiplayer.kt). */
static void link_child_land(uint16_t hostData, uint16_t stamp, unsigned gap)
{
    uint16_t childData = 0xFFFFu;
    uint32_t reply     = 0xFFFFu;
    const bool multi = link_sio_is_multi(g_link_gba);
    if (multi) {
        childData = g_link_driver.localSend;
        link_child_apply(hostData, childData);
        reply = childData;
    } else {
        reply = 0xFFFFu | ((uint32_t)LINK_RF_NOT_MULTI << 16);
    }
    lm_set_reply(link_mbox(), reply);
    lm_complete(link_mbox());
    g_st_ch_delivered++;
    LOGI("D h=%u c=%u gap=%u in=%04X out=%04X multi=%d",
         (unsigned)stamp, (unsigned)g_link_tick, gap,
         (unsigned)hostData, (unsigned)childData, (int)multi);
}

/* LEGACY path (g_link_clock_sync == false): called at the start of every
 * nativeRunFrame() on a link child. Takes the host's pending request, if any,
 * and lands it — at most ONE transfer per frame, which is exactly what made a
 * 16-word host packet take ~9 child frames (see the CLOCK TIE comment).
 * Kept only so the old behaviour can be A/B-compared. Returns true if a
 * request was handled. */
static bool link_child_deliver_pending(void)
{
    uint16_t hostData = 0, stamp = 0;
    if (!lm_take_request(link_mbox(), &hostData, &stamp)) return false;
    link_child_land(hostData, stamp, 0u);
    return true;
}

/* hold time = 2 x the typical wait for the host's next word + 8 ms, clamped. */
static void link_hold_recompute(void)
{
    int ms = (int)(g_ch_wait_ewma_us / 500) + 8;
    g_ch_hold_ms = ms < LINK_HOLD_MIN_MS ? LINK_HOLD_MIN_MS : (ms > LINK_HOLD_MAX_MS ? LINK_HOLD_MAX_MS : ms);
}

/* CLOCK TIE, child half. Runs on every link tick of the child's core, i.e.
 * inside runFrame(), on the game thread, with g_core_mutex held.
 *
 *  1. If the host's word is waiting, deliver it — but when the host's previous
 *     word was close behind (gap <= LINK_SPACING_MAX_TICKS) only once THIS
 *     core has run as many ticks since the last delivery as the host's clock
 *     did between the two words. That reproduces the host's timing in the
 *     child's emulated time. A word that arrives late (this core already ran
 *     past its slot) is delivered at once.
 *  2. If nothing is waiting and the host is mid-burst (two words closer than
 *     LINK_BURST_GAP_TICKS, and since then every gap <= LINK_SPACING_MAX_TICKS),
 *     run ONE tick (the ISR for the word just delivered stages the next
 *     reply), then WAIT for the next word instead of running ahead. If none
 *     comes within g_ch_hold_ms the burst is over (or the host stalled) and
 *     this core runs free again.
 * Traffic that never gets two words close together — one word per frame, say —
 * never holds anything. */
static void link_child_tick(void)
{
    LinkMailbox *mb = link_mbox();
    __atomic_store_n(&g_link_child_multi, link_sio_is_multi(g_link_gba), __ATOMIC_RELAXED);

    for (int guard = 0; guard < 3; guard++) {
        uint16_t word = 0, stamp = 0;
        if (lm_peek_request(mb, &word, &stamp)) {
            unsigned gap = 0;
            bool due = true;
            if (g_ch_have_prev) {
                gap = (uint16_t)(stamp - g_ch_prev_h);
                if (gap >= 1u && gap <= LINK_SPACING_MAX_TICKS)
                    due = (uint32_t)(g_link_tick - g_ch_prev_tick) >= gap;
            }
            if (!due) return;                                    /* early: keep running, look again next tick */
            if (!lm_take_request(mb, &word, &stamp)) continue;   /* withdrawn since the peek */
            link_child_land(word, stamp, gap);
            g_ch_gov_active = false;                      /* tied to the host's clock again */
            /* Burst mode starts on two words close together and then PERSISTS while words keep
             * coming within LINK_SPACING_MAX_TICKS (~3 frames): a frame-periodic ROM sends a block of
             * words, idles for the rest of its frame, then sends the next block, and the idle gap
             * between blocks must not end the burst — the two-device simulation showed why: a child
             * that ran free through that gap, then caught up on its drained audio buffer, ran ~6
             * frames ahead of the host and tripped its ROM's receive timeout. */
            g_ch_burst     = g_ch_have_prev && gap >= 1u &&
                             (gap <= LINK_BURST_GAP_TICKS || (g_ch_burst && gap <= LINK_SPACING_MAX_TICKS));
            g_ch_have_prev = true;
            g_ch_prev_h    = stamp;
            g_ch_prev_tick = g_link_tick;
            return;
        }
        if (g_ch_burst && g_ch_have_prev) {
            if ((uint32_t)(g_link_tick - g_ch_prev_tick) < 1u) return;   /* give the ISR for the last word one tick first */

            struct timespec t0, t1;
            clock_gettime(CLOCK_MONOTONIC, &t0);
            const bool got = lm_wait_posted(mb, g_ch_hold_ms);
            clock_gettime(CLOCK_MONOTONIC, &t1);
            const uint32_t waited_us = link_elapsed_us(&t0, &t1);
            if (got) {
                g_st_ch_holds++;
                g_ch_wait_ewma_us = (3 * g_ch_wait_ewma_us + (int64_t)waited_us) / 4;
                link_hold_recompute();
                continue;                                             /* look at the word that just arrived */
            }
            g_st_ch_hold_to++;
            g_ch_burst = false;                                       /* burst over (or the host stalled): run free... */
            g_ch_gov_active = true;                                   /* ...but no faster than real time from here */
            g_ch_gov_ts     = t1;
            g_ch_gov_tick0  = g_link_tick;
            /* A timeout is evidence the next word takes longer than we allowed (a slow link — Bluetooth —
             * or just the end of a burst). Grow the estimate so a slow link adapts within a few words; the
             * next successful hold pulls it back down. (The simulation caught this: recomputing only on
             * success left hold_ms stuck at its start value and a 30 ms round trip never held at all.) */
            g_ch_wait_ewma_us = g_ch_wait_ewma_us * 3 / 2 + 1000;
            if (g_ch_wait_ewma_us > (int64_t)LINK_HOLD_MAX_MS * 500) g_ch_wait_ewma_us = (int64_t)LINK_HOLD_MAX_MS * 500;
            link_hold_recompute();
            return;
        }

        if (g_ch_gov_active) {
            struct timespec now;
            clock_gettime(CLOCK_MONOTONIC, &now);
            const uint32_t el_us   = link_elapsed_us(&g_ch_gov_ts, &now);
            const uint32_t allowed = (uint32_t)(((uint64_t)el_us * GBA_AUDIO_CLOCK) / ((uint64_t)LINK_TICK_CYCLES * 1000000ull));
            const uint32_t used    = g_link_tick - g_ch_gov_tick0;
            if (used > allowed + LINK_GOV_SLACK_TICKS) {
                const uint32_t ahead = used - allowed - LINK_GOV_SLACK_TICKS;
                int ms = (int)(((uint64_t)ahead * LINK_TICK_CYCLES * 1000ull) / GBA_AUDIO_CLOCK) + 1;
                if (ms > 20) ms = 20;
                if (lm_wait_posted(mb, ms)) continue;                 /* a word arrived while we waited: handle it */
            }
        }
        return;
    }
}

/* ── AUDIT FIX (multiplayer, host side): deferred transfer completion ─────
 *
 * link_sio_write_register() used to perform the WHOLE transfer inside the
 * ROM's SIOCNT write: exchange over the network, fill SIOMULTI0-3, raise the
 * SIO interrupt and hand the register back with Start/Busy already clear.
 * On a real GBA none of that is instantaneous — a Multi-Player transfer takes
 * on the order of a millisecond (roughly 6,000 cycles at 115,200 baud, up to
 * ~77,000 at 9,600) — and link code is written around that gap. The usual
 * shape is
 *
 *     REG_SIOCNT |= START;       // kick off the transfer
 *     state = TRANSFER_PENDING;  // bookkeeping AFTER the kick
 *     ... later, in the SIO interrupt: state = TRANSFER_DONE;
 *
 * Here the interrupt fired between the first line and the second (the CPU
 * takes a pending IRQ before the next instruction), so the ISR ran, marked
 * the transfer done, and then the main code overwrote that with PENDING —
 * leaving the ROM waiting forever for an interrupt that had already come and
 * gone. Polling code that checks the busy bit never saw it set at all.
 *
 * Now the network exchange still happens inside the write (it has to block
 * somewhere, and the emulator is paused meanwhile, so emulated time is
 * unaffected), but its RESULT is held back: the write returns with
 * Start/Busy still set, and an mGBA timing event delivers the data, clears
 * busy, sets/clears the error flag and raises the IRQ link_transfer_cycles()
 * cycles later — in emulated time, so it is the same on every phone.
 *
 * All state below is touched only with g_core_mutex held (the write callback
 * and the timing callback both run inside nativeRunFrame()).
 *
 * Teardown hazards, all handled by link_host_deferred_reset():
 *  - the event lives in the core's own queue, which a ROM swap destroys and a
 *    save-state load rebuilds, so our "scheduled" bookkeeping has to be
 *    cleared at both or the next transfer could never be scheduled;
 *  - stopping the link mid-transfer must not leave Start/Busy stuck set. */
static struct mTimingEvent g_link_done_event;
static bool     g_link_done_event_inited = false;
static bool     g_link_done_scheduled    = false;   /* event is in g_link_done_core's queue */
static struct GBA *g_link_done_core      = NULL;
static bool     g_link_xfer_pending      = false;   /* a started transfer awaits completion */
static uint16_t g_link_pend_host         = 0;
static uint16_t g_link_pend_child        = 0xFFFFu;
static bool     g_link_pend_timeout      = false;

/* Emulated cycles one 2-unit Multi-Player transfer takes, by SIOCNT baud
 * bits 0-1 (0 = 9,600, 1 = 38,400, 2 = 57,600, 3 = 115,200 baud): 44 bit
 * times (two units x (start + 16 data + stop) plus inter-frame gaps) at
 * 16,777,216 Hz. Approximate, deliberately — what matters is "about a
 * millisecond, not zero", not matching the exact figure of any one game. */
static int32_t link_transfer_cycles(uint16_t siocnt)
{
    static const int32_t k_cycles[4] = { 76900, 19225, 12820, 6410 };
    return k_cycles[siocnt & 3u];
}

/* Timing-event callback: the transfer "finishes" now. */
static void link_host_transfer_done(struct mTiming *timing, void *context, uint32_t cyclesLate)
{
    (void)timing; (void)context;
    g_link_done_scheduled = false;
    if (!g_link_xfer_pending) return;
    g_link_xfer_pending = false;
    struct GBA *gba = g_link_gba;
    if (!g_link_active || !g_link_is_host || !gba || gba != g_link_done_core) return;

    gba->memory.io[0x0120u >> 1] = g_link_pend_host;
    gba->memory.io[0x0122u >> 1] = g_link_pend_child;
    gba->memory.io[0x0124u >> 1] = 0xFFFFu;
    gba->memory.io[0x0126u >> 1] = 0xFFFFu;

    uint16_t siocnt = gba->sio.siocnt;             /* whatever the ROM has set meanwhile (IRQ enable, ...) */
    siocnt = (uint16_t)(siocnt & ~0x0080u);        /* Start/Busy: done */
    siocnt = (uint16_t)(siocnt & ~0x0030u);        /* ID 0 = parent */
    siocnt = g_link_pend_timeout ? (uint16_t)(siocnt | 0x0040u)
                                 : (uint16_t)(siocnt & ~0x0040u);
    gba->sio.siocnt = siocnt;
    gba->memory.io[0x0128u >> 1] = siocnt;
    /* (No log line here any more: one per transfer doubled the log's volume for nothing — the "X"
     * line written when the transfer STARTED already carries the result, and completion happens a
     * fixed LINK_TICK_CYCLES-ish later by construction.) */
    if (siocnt & 0x4000u) GBARaiseIRQ(gba, GBA_IRQ_SIO, (int)cyclesLate);
}

/* Schedules the completion of the transfer that was just exchanged. Returns
 * false if it could not (the caller then completes instantly, the previous
 * behaviour). */
static bool link_host_defer_completion(uint16_t hostData, uint16_t childData,
                                       bool timedOut, uint16_t siocnt)
{
#if LINK_HOST_DEFERRED_COMPLETION
    struct GBA *gba = g_link_gba;
    if (!gba) return false;
    if (!g_link_done_event_inited) {
        memset(&g_link_done_event, 0, sizeof(g_link_done_event));
        g_link_done_event.name     = "link transfer complete";
        g_link_done_event.callback = link_host_transfer_done;
        g_link_done_event.context  = NULL;
        g_link_done_event.priority = 0x80;
        g_link_done_event_inited   = true;
    }
    /* Never schedule an event that is already in the queue: mGBA's queue is a
     * linked list threaded through the event itself, so a double insert
     * corrupts it. (Only reachable if the link was stopped and restarted
     * within one transfer's duration.) */
    if (g_link_done_scheduled && g_link_done_core == gba) return false;
    g_link_pend_host    = hostData;
    g_link_pend_child   = childData;
    g_link_pend_timeout = timedOut;
    g_link_xfer_pending = true;
    g_link_done_core    = gba;
    g_link_done_scheduled = true;
    mTimingSchedule(&gba->timing, &g_link_done_event, link_transfer_cycles(siocnt));
    return true;
#else
    (void)hostData; (void)childData; (void)timedOut; (void)siocnt;
    return false;
#endif
}

/* Forget any in-flight deferred transfer; call with g_core_mutex held. If a
 * transfer was pending on a LIVE core, Start/Busy is cleared so the ROM does
 * not wait on it forever.
 *
 * [queueDiscarded] says what happened to the core's event queue:
 *  - true  (ROM swap, save-state load): the queue that held our event was
 *    destroyed or rebuilt without it, so the event is simply gone and a new
 *    one may be scheduled at once;
 *  - false (link stopped): the core and its queue live on, our event is STILL
 *    IN IT and will fire later (as a no-op, since nothing is pending any
 *    more). It must not be scheduled again until it has — mGBA's queue is a
 *    linked list threaded through the event, so a second insert corrupts it —
 *    which is why g_link_done_scheduled / g_link_done_core are kept. */
static void link_host_deferred_reset(bool queueDiscarded)
{
    if (g_link_xfer_pending && g_link_gba) {
        g_link_gba->sio.siocnt = (uint16_t)(g_link_gba->sio.siocnt & ~0x0080u);
        g_link_gba->memory.io[0x0128u >> 1] = g_link_gba->sio.siocnt;
    }
    g_link_xfer_pending = false;
    if (queueDiscarded) {
        g_link_done_scheduled = false;
        g_link_done_core      = NULL;
    }
}
/* ── CLOCK TIE: the tick event (see the CLOCK TIE comment near the link globals) ──
 *
 * One periodic timing event per link session, on whichever core is linked,
 * scheduled with the same mTimingSchedule() the deferred-completion event
 * above already uses. All state is touched with g_core_mutex held (the
 * callback runs inside runFrame()).
 *
 * Teardown hazards mirror link_host_deferred_reset():
 *  - a ROM swap or save-state load destroys/rebuilds the core's event queue, so
 *    the "scheduled" bookkeeping must be cleared there (link_tick_reset(true))
 *    and, on a load with the link still up, the tick re-armed;
 *  - stopping the link leaves the event in the (still living) queue. It must
 *    not be scheduled a second time before it has fired — mGBA's queue is a
 *    linked list threaded through the event, so a double insert corrupts it —
 *    which is why g_link_tick_scheduled / g_link_tick_core are kept; the stale
 *    event fires once more, sees the link is down and simply doesn't re-arm. */
static void link_tick_reset(bool queueDiscarded)
{
    if (queueDiscarded) {
        g_link_tick_scheduled = false;
        g_link_tick_core      = NULL;
    }
}

static void link_stats_maybe_report(void)
{
    if ((g_link_tick & 31u) != 0u) return;            /* a clock read every 32 ticks is plenty */
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    if (!g_st_have_ts) {
        g_st_last_ts = now; g_st_last_tick = g_link_tick; g_st_have_ts = true;
        return;
    }
    const uint32_t dt_us = link_elapsed_us(&g_st_last_ts, &now);
    if (dt_us < 1000000u) return;
    const uint32_t dticks = g_link_tick - g_st_last_tick;
    /* speed = emulated time / real time: 100% is a real GBA's pace, ~4% is what
     * the host showed in the capture that led to the clock tie. */
    const int speed = (int)(((uint64_t)dticks * LINK_TICK_CYCLES * 100ull * 1000000ull)
                            / ((uint64_t)GBA_AUDIO_CLOCK * (uint64_t)dt_us));
    if (g_link_is_host) {
        const uint32_t n = g_st_host_xfers;
        LOGI("STAT host (last ~1s): speed=%d%% ticks=%u xfers=%u timeouts=%u peer-not-multi=%u rtt_avg=%uus rtt_max=%uus log-suppressed=%u",
             speed, dticks, n, g_st_host_to, g_st_host_notmulti,
             n ? (unsigned)(g_st_host_rtt_us_sum / n) : 0u, g_st_host_rtt_us_max,
             (unsigned)(g_lim_x.suppressed + g_lim_w.suppressed));
    } else {
        LOGI("STAT child (last ~1s): speed=%d%% ticks=%u delivered=%u holds=%u hold_timeouts=%u hold_ms=%d multi=%d burst=%d log-suppressed=%u",
             speed, dticks, g_st_ch_delivered, g_st_ch_holds, g_st_ch_hold_to, g_ch_hold_ms,
             (int)g_link_child_multi, (int)g_ch_burst, (unsigned)g_lim_w.suppressed);
    }
    g_st_host_xfers = g_st_host_to = g_st_host_notmulti = 0;
    g_st_host_rtt_us_sum = 0; g_st_host_rtt_us_max = 0;
    g_st_ch_delivered = g_st_ch_holds = g_st_ch_hold_to = 0;
    g_lim_x.suppressed = g_lim_w.suppressed = 0;
    g_st_last_ts = now; g_st_last_tick = g_link_tick;
}

static void link_tick_cb(struct mTiming *timing, void *context, uint32_t cyclesLate)
{
    (void)timing; (void)context;
    g_link_tick_scheduled = false;
    struct GBA *gba = g_link_gba;
    if (!g_link_active || !gba || gba != g_link_tick_core) return;   /* link stopped / core replaced: let the tick lapse */
    g_link_tick++;
    link_stats_maybe_report();
    if (!g_link_is_host) link_child_tick();                          /* may WAIT for the host's next word (the hold) */
    if (!g_link_active || g_link_gba != gba) return;
    g_link_tick_scheduled = true;
    mTimingSchedule(&gba->timing, &g_link_tick_event,
                    (int32_t)LINK_TICK_CYCLES - (int32_t)(cyclesLate > 2000u ? 2000u : cyclesLate));
}

/* Puts the tick on the linked core's queue unless it is already there.
 * CALLER HOLDS g_core_mutex. */
static void link_tick_arm(void)
{
    struct GBA *gba = g_link_gba;
    if (!gba) return;
    if (!g_link_tick_inited) {
        memset(&g_link_tick_event, 0, sizeof(g_link_tick_event));
        g_link_tick_event.name     = "link tick";
        g_link_tick_event.callback = link_tick_cb;
        g_link_tick_event.context  = NULL;
        g_link_tick_event.priority = 0x80;
        g_link_tick_inited         = true;
    }
    if (g_link_tick_scheduled && g_link_tick_core == gba) return;
    g_link_tick_core      = gba;
    g_link_tick_scheduled = true;
    mTimingSchedule(&gba->timing, &g_link_tick_event, LINK_TICK_CYCLES);
}

/* Everything the link needs at the start of nativeRunFrame() (g_core_mutex
 * held). The SIO driver callback borrows this call's JNIEnv for the duration of
 * runFrame(); the clock-tie tick is kept armed (self-healing: if anything ever
 * drops it from the queue it is back one frame later); and on the legacy path
 * a child lands its pending word here, one per frame. */
static void link_frame_prologue(JNIEnv *env)
{
    g_link_driver.env = g_link_active ? env : NULL;
    if (!g_link_active || !g_link_gba) return;
    if (!g_link_is_host)
        __atomic_store_n(&g_link_child_multi, link_sio_is_multi(g_link_gba), __ATOMIC_RELAXED);
    if (g_link_clock_sync) {
        if (!g_link_tick_scheduled) link_tick_arm();
    } else if (!g_link_is_host) {
        (void)link_child_deliver_pending();
    }
}

/* ── FIX 7: real GBASIODriver, registered with the core's SIO subsystem ──
 *
 * This is what src/gba/sio.c actually dispatches to when the game writes
 * SIOCNT or SIOMLT_SEND — as opposed to the old approach of reading those
 * registers back out after the fact, which the core's own dummy-driver
 * fallback had usually already resolved by the time we looked.
 *
 * struct GBASIODriver only specifies the callback layout; every real driver
 * in mGBA (see src/gba/hardware.c's Game Boy Player driver for the pattern
 * this mirrors) wraps it in its own struct with whatever extra state it
 * needs, and casts back to that wrapper inside its callbacks.
 * (struct LinkSIODriver / g_link_driver / g_link_gba are declared up near
 * the other link-cable globals — see FIX 8.)
 *
 * address here is the register OFFSET from the 0x4000000 IO base (mGBA's
 * own dispatcher indexes memory.io[] with it), so SIOCNT is 0x128 and
 * SIOMLT_SEND is 0x12A — not the full 0x04000128 / 0x400012A addresses. */
static uint16_t link_sio_write_register(struct GBASIODriver *driver,
                                         uint32_t address, uint16_t value)
{
    struct LinkSIODriver *ld = (struct LinkSIODriver *)driver;

    /* FIX 11 (diagnostic): this callback only ever runs while the core's
     * own SIO mode is SIO_MULTI (GBASIOSetDriver registers us per-mode;
     * the core re-picks its active driver from sio->drivers.* every time
     * the ROM's own RCNT/SIOCNT mode bits change). If nothing shows up in
     * logcat for this tag while a real link attempt is in progress, the
     * ROM is either never reaching Multi-Player mode at all (e.g. sitting
     * in an earlier General-Purpose handshake, or using Normal mode
     * instead), or nativeLinkStart()/GBASIOSetDriver() never actually took
     * effect — both very different problems from anything FIX 9/10
     * touched. This is intentionally left in as a permanent, cheap trace;
     * it only fires on real SIOCNT/SIOMLT_SEND writes, not every frame. */
    /* THIS PASS: this used to log EVERY register write — three or four lines
     * per transfer (SIOMLT_SEND, SIOCNT, the result, "transfer complete"), which
     * both buried the lines that matter and made a capture cover barely a
     * second. Now a transfer is ONE line (the "X"/"D" lines below and in
     * link_child_land()); only the writes that are NOT part of a transfer are
     * logged here — RCNT, and SIOCNT writes that don't start a host transfer —
     * i.e. exactly the Multi-Player (re)initialisation sequence a ROM runs when
     * its own link code restarts (the child capture showed it every ~100 ms). */
    if ((address == 0x134u || (address == 0x128u && !(g_link_is_host && (value & 0x0080u))))
        && link_log_limit(&g_lim_w, 40u)) {
        LOGI("W %s=0x%04X host=%d", address == 0x134u ? "RCNT" : "SIOCNT",
             (unsigned)value, (int)g_link_is_host);
    }

    if (address == 0x12Au) {                 /* SIOMLT_SEND: just latch it */
        ld->localSend = value;
        return value;
    }

    /* FIX 21: RCNT is what both FIX 9's own comment and this file's FIX 20
     * comment already identify as part of the ROM's Multi-Player
     * re-initialization sequence — every capture on file writes it right
     * at the start of a session and again every time the ROM's own
     * negotiation restarts itself. Re-arming the pacing window here (not
     * just once in nativeLinkStart()) is what keeps each restart getting
     * its own short paced grace period instead of only the very first one.
     * Deliberately unconditional on value or role: on the host this covers
     * every RCNT write link_sio_write_register() ever sees at all (the
     * function only special-cases 0x12A and 0x128 elsewhere), and it's
     * cheap enough (a clock read and two writes, no sleep) not to need to
     * be pickier than that. */
    if (address == 0x134u) {
        link_pace_arm_window();
    }

    if (address != 0x128u) return value;

    /* FIX 9 (GBATEK-verified: gbatek "SIO Multi-Player Mode" register table).
     * Reflect link status on *every* SIOCNT write, not only ones with the
     * Start bit set:
     *   Bit 2 (SI-Terminal): 0=Parent, 1=Child            — read-only status
     *   Bit 3 (SD-Terminal): 0=Bad connection, 1=All Ready — read-only status
     * Both are hardware-read-only — real GBAs don't let the CPU set them,
     * they always reflect true link state — and GBATEK's own Multi-Player
     * initialization sequence has every ROM read both BEFORE ever attempting
     * a transfer ("Read SIOCNT Bit 3 to verify that all GBAs are in
     * Multi-Player mode" / "...Bit 2 to detect whether this is the Parent").
     * Nothing previously set either bit, so a ROM doing that check first —
     * before ever writing the Start bit — would see bit 3 permanently 0,
     * indistinguishable from "no cable plugged in", and could sit on a
     * "waiting for link" screen forever even after the phones' own network
     * handshake had already succeeded. Applying this on every write (not
     * just Start-bit ones) means it's already correct by the time the ROM's
     * *first* SIOCNT write (the one that merely selects multiplayer mode,
     * Start bit still 0) happens, with no dependency on transfer timing. */
    if (g_link_active) {
        value |= 0x0008u;                                                      /* bit3: ready */
        value = (uint16_t)((value & ~0x0004u) | (g_link_is_host ? 0u : 0x0004u)); /* bit2 */
        /* AUDIT FIX: bits 4-5 (player ID) and, on a child, bit 7 (Start/Busy)
         * are read-only hardware status. They were left exactly as the ROM
         * wrote them, so every SIOCNT write by a child ROM reset its ID to 0
         * (parent) until the next transfer landed. Keep them correct on every
         * write, for both roles. */
        value = (uint16_t)((value & ~0x0030u) | (g_link_is_host ? 0u : 0x0010u));
        if (!g_link_is_host) value &= (uint16_t)~0x0080u;
    }

    /* FIX 14: added the g_link_is_host guard. Every FIX 9-12 comment in this
     * file already describes the intended design as "the child never
     * triggers its own exchange, only nativeLinkChildExchange() (driven by
     * the network, not a local SIO write) ever runs on a child" — GBATEK is
     * explicit that Start/Busy is read-only for slaves — but nothing here
     * actually enforced that: this branch fired for *either* role's own
     * Start-bit write, unconditionally. On real hardware a child's write to
     * this bit is physically ignored, so if either test ROM's link code is
     * shared between parent/child paths (common — Nintendo's own SDK
     * exposes one Sio API either role calls) and doesn't distinguish, a
     * child device would already have been triggering a second, spurious,
     * protocol-violating exchange of its own alongside nativeLinkChildExchange()
     * answering the real one from the network side — sending an unsolicited
     * DATA packet the *host*'s next real wifiExchange()/btExchange() round
     * could then race against and consume as if it were that round's reply.
     * That would explain the reported symptom set unusually well: identical
     * ROM-detection failure on both transports (this file is shared by
     * both, unlike the transport-specific Kotlin code, which FIX 9-12
     * already hardened per-transport) and worse lag specifically on
     * Bluetooth (BT_XCHG_MS=50 vs WIFI_XCHG_MS=30 — a stolen-reply timeout
     * costs more there). Not confirmed — this sandbox can't attach a
     * debugger to a real link session — but cheap, safe (host behavior is
     * completely unchanged; is_host is already true on every path that used
     * to run), and consistent with what every prior pass already said the
     * design should be. See KNOWN_LIMITATIONS.md for what would actually
     * confirm or rule this out.
     * Simplified below to match: hostData/childData and the ID-bit write
     * near the bottom of this block both had a `g_link_is_host ? … : …`
     * branch for the child-role case that this guard now makes unreachable
     * — removed rather than left as dead code that looks live. */
    /* AUDIT FIX: while a deferred transfer is in flight, Start/Busy is
     * read-only hardware status — a second Start is ignored and the bit
     * cannot be cleared from software. */
    if (g_link_is_host && g_link_xfer_pending) {
        return (uint16_t)(value | 0x0080u);
    }
    if ((value & 0x0080u) && g_link_is_host && ld->env
        && g_link_obj && g_link_xchg_mid && g_core) {  /* Start/Busy bit */
        /* FIX 20 (experimental — see top-of-file comment): wait out the
         * rest of one emulated frame since the last exchange, if any is
         * left, before starting this one. Deliberately placed before the
         * network round-trip, not after — pacing when the *next* attempt
         * is allowed to start, not adding a flat delay to every one. */
        /* (Wall-clock pacing, FIX 20/21, is gone for good: the child-side
         * lock-step and now the clock tie are what keep the two ROMs in step.) */
        const uint16_t stamp = (uint16_t)g_link_tick;   /* this host's emulated time, in ticks — the child re-creates the spacing from it */
        struct timespec x0, x1;
        clock_gettime(CLOCK_MONOTONIC, &x0);
        uint32_t remote_data = link_exchange(ld->env, (uint32_t)ld->localSend, stamp);
        clock_gettime(CLOCK_MONOTONIC, &x1);
        const uint32_t rtt_us = link_elapsed_us(&x0, &x1);
        bool     timedOut    = (remote_data == 0xFFFFFFFFu);
        uint16_t remote16    = (uint16_t)(remote_data & 0xFFFFu);
        const uint8_t rflags = timedOut ? 0u : (uint8_t)((remote_data >> 16) & 0xFFu);
        uint16_t hostData    = ld->localSend;
        uint16_t childData   = remote16;
        if (rflags & LINK_RF_NOT_MULTI) childData = 0xFFFFu;   /* the child's ROM isn't in Multi-Player mode: nobody answered */
        g_st_host_xfers++;
        if (timedOut) g_st_host_to++;
        if (rflags & LINK_RF_NOT_MULTI) g_st_host_notmulti++;
        g_st_host_rtt_us_sum += rtt_us;
        if (rtt_us > g_st_host_rtt_us_max) g_st_host_rtt_us_max = rtt_us;
        /* FIX 16: this callback already traced every write that *triggers*
         * an exchange (FIX 11, above) but never what came back. W's latest
         * wifi_host.text showed 1124 Start-bit writes in 1.67s — far too
         * fast to be hitting WIFI_XCHG_MS=30 each time (that'd take over
         * 30s for that many) — so most of these were almost certainly
         * getting real, fast replies rather than timing out, but nothing
         * confirmed that or showed what the replies actually contained.
         * Logged unconditionally, same as the write trace above: this is
         * exactly the signal this diagnostic exists for, not noise to
         * filter like FIX 13's target was. */
        if ((!timedOut && !(rflags & LINK_RF_NOT_MULTI)) || link_log_limit(&g_lim_x, 20u)) {
            LOGI("X h=%u sent=%04X recv=%04X rtt=%u.%02ums%s%s",
                 (unsigned)stamp, (unsigned)hostData, (unsigned)remote16,
                 (unsigned)(rtt_us / 1000u), (unsigned)((rtt_us % 1000u) / 10u),
                 timedOut ? " TIMEOUT" : "",
                 (rflags & LINK_RF_NOT_MULTI) ? " child-not-multi" : "");
        }
        /* FIX 8 (build-log driven): GBASIOMultiplayerFinishTransfer() was the
         * "correct" internal call for this — same one the core's own drivers
         * use — but the previous build log showed it as an implicit
         * (undeclared) function even with sio.h included, meaning it isn't
         * actually exposed on the mGBA revision this project pins (0.10.3);
         * that header apparently gained it later. Rather than risk an
         * unresolved symbol at link time, write the four multiplayer data
         * registers directly.
         * FIX 12: "directly" now means memory.io[], not rawWrite16(). See
         * FIX 12's entry at the top of this file — rawWrite16 silently
         * no-ops for the entire I/O region (it's GBAPatch16 underneath,
         * and GBAPatch16 only backs EWRAM/IWRAM/palette RAM), so these were
         * never actually reaching SIOMULTI0-3. This used to also skip the
         * SIO IRQ that the internal call would have raised automatically —
         * see FIX 10 below, which now raises it explicitly instead. */
        /* AUDIT FIX: the result is normally held back and delivered by
         * link_host_transfer_done() a realistic number of cycles later (see
         * the long comment above link_host_defer_completion()); the code
         * below is the old instant-completion path, still used when that
         * can't be scheduled or LINK_HOST_DEFERRED_COMPLETION is 0. */
        if (link_host_defer_completion(hostData, childData, timedOut, value)) {
            value = (uint16_t)(value | 0x0080u);    /* still Start/Busy until the event fires */
            value = (uint16_t)(value & ~0x0070u);   /* ID = 0, error flag reported at completion */
        } else {
            g_link_gba->memory.io[0x0120u >> 1] = hostData;
            g_link_gba->memory.io[0x0122u >> 1] = childData;
            g_link_gba->memory.io[0x0124u >> 1] = 0xFFFFu;
            g_link_gba->memory.io[0x0126u >> 1] = 0xFFFFu;
            /* FIX 10: the transfer is done — raise the interrupt an
             * interrupt-driven ROM (IntrWait/VBlankIntrWait on INT_SERIAL,
             * the standard GBA-dev pattern) is asleep waiting for. A
             * poll-driven ROM just ignores this (IF gets a bit set that
             * nothing ever checks) — safe either way. See FIX 10 above for
             * why this is unconditional on timedOut. */
            /* AUDIT FIX: only if the ROM enabled the SIO IRQ (SIOCNT bit 14) —
             * see link_child_apply(). `value` is what the ROM just wrote. */
            if (value & 0x4000u) GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0);
            value &= ~0x0080u;   /* Start/Busy bit: transfer already complete */
            /* FIX 9: per GBATEK, ID bits (4-5) are undefined until the first
             * transfer completes (00=parent, 01=1st child) — games use this,
             * alongside bit 2 above, to tell their own role apart. Bit 6 (Error)
             * flags a round where the peer didn't answer in time, instead of
             * silently handing the ROM a stale 0xFFFF indistinguishable from
             * real "not connected" data — GBATEK explicitly expects parent-side
             * error checking here ("parent unit might... perform error
             * checking"), so this gives it something real to check. */
            value = (uint16_t)(value & ~0x0030u);   /* ID bits: 0 = parent (see FIX 14 above — this device is always host inside this block now) */
            value = timedOut ? (uint16_t)(value | 0x0040u) : (uint16_t)(value & ~0x0040u);
        }
    } else if ((value & 0x0080u) && g_link_is_host) {
        /* FIX 11 (diagnostic): Start bit was set, but the exchange above was
         * skipped — this driver callback fired, so mode selection isn't the
         * problem, but one of these four is unexpectedly null/false. ld->env
         * is only non-NULL for the duration of a runFrame() call (see nativeRunFrame),
         * so JNI is not the issue if we got this far at all; g_link_obj/
         * g_link_xchg_mid come from nativeLinkStart, g_core from ROM load.
         * FIX 14: this condition now also requires g_link_is_host, so it
         * no longer fires for the (now-expected, see FIX 14 above) case of
         * a child's own SIOCNT write carrying the Start bit — that's not
         * logged at all, deliberately: if a ROM's child-role code path
         * writes this on every poll iteration, logging it unconditionally
         * would reintroduce the exact volume problem FIX 13 just fixed. */
        LOGW("Start bit set but exchange skipped: env=%p obj=%p mid=%p core=%p",
             (void *)ld->env, (void *)g_link_obj,
             (void *)g_link_xchg_mid, (void *)g_core);
    }
    return value;
}

/* FIX 9 — passive-child responder entry point.
 *
 * GBATEK is explicit that the Start/Busy bit is "Read Only for Slaves" — on
 * real hardware a child unit never triggers a transfer itself, it only ever
 * reacts to the parent's clock. link_sio_write_register()'s exchange branch
 * above is keyed off *this device's own* SIOCNT Start-bit write; the
 * original version of this comment (FIX 9) claimed that branch therefore
 * "correctly never fires" on a child device, matching real hardware — but
 * that was an assumption resting entirely on child ROM code never actually
 * performing that write, not anything this file enforced. FIX 14 (see
 * above) added the missing g_link_is_host guard so it's now actually true
 * regardless of what a child ROM's own code does. Either way, a child's
 * local jniExchangeData()/wifiExchange()/btExchange() call (the only thing
 * that ever answered the parent's request packet) never happened by itself,
 * so the parent's every attempt timed out waiting for a reply nothing was
 * ever going to send: multiplayer could never progress past a "waiting for
 * players" screen, regardless of whether the two phones' own network
 * connection was fine.
 *
 * Called from a background Kotlin thread (LinkMultiplayer's dedicated Wi-Fi
 * child-listener thread, or its Bluetooth reader thread acting in child
 * mode) the instant a request arrives from the parent over the network —
 * never from anything the local ROM does. It writes this device's own
 * SIOMULTI0/1 exactly as the parent side does above, so this device's ROM
 * sees a completed transfer next time it reads those registers, and returns
 * this device's latched SIOMLT_SEND value so the Kotlin caller can send it
 * back to the parent as that round's reply.
 *
 * Until FIX 18, deliberately did not touch SIOCNT itself (unlike the
 * parent-side branch above), reasoning that doing so correctly would mean
 * preserving the mode/baud bits the ROM already wrote, which needs reading
 * the register back first. It now does exactly that — reads the current
 * value via memory.io[] (the same direct-array technique FIX 12 already
 * uses for SIOMULTI0-3) rather than risking an unconfirmed raw-read helper,
 * and only touches bits 2/3/4-5/7. See FIX 18's own comment at the call
 * site below, and KNOWN_LIMITATIONS.md.
 */
/* AUDIT FIX (multiplayer): this no longer touches the core at all. It runs
 * on a network thread; the core belongs to the game thread. It posts the host's
 * word (and its tick stamp — see the CLOCK TIE comment) into the mailbox and
 * BLOCKS until the game thread has delivered it: inside runFrame(), at the
 * host's own spacing, from link_child_tick() (or, on the legacy path, at the
 * start of the next frame). Returns the child's reply — bits 0-15 its word,
 * bits 16-23 LINK_RF_* flags — or -1 (0xFFFFFFFF, the host's "no answer"
 * marker) if the game thread didn't take it in time or the link isn't active.
 *
 * Everything the older versions of this comment explain about WHY a child
 * must answer at all (the parent is the only side that starts transfers) and
 * about what the registers must look like (FIX 9/10/12/16/18) still holds —
 * that logic lives in link_child_apply(), run by the game thread. */
JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(
        JNIEnv *env, jobject thiz, jint hostData, jint stamp)
{
    (void)env; (void)thiz;
    /* A ROM that is not in Multi-Player mode answers nobody. Say so right here
     * on the network thread instead of queueing the word for the game thread to
     * answer with the same thing a frame later: the host learns it at network
     * speed and stops waiting on every transfer (LinkMultiplayer.jniExchangeData). */
    if (!__atomic_load_n(&g_link_child_multi, __ATOMIC_RELAXED)) {
        return (jint)(0xFFFFu | ((uint32_t)LINK_RF_NOT_MULTI << 16));
    }
    uint32_t reply = 0xFFFFu;
    int rc = lm_post_and_wait(link_mbox(), (uint16_t)hostData, (uint16_t)stamp,
                              LINK_CHILD_WAIT_MS, &reply);
    if (rc == LM_OK) return (jint)reply;
    LOGW("Child exchange: no reply (%s) hostData=0x%04X",
         rc == LM_TIMEOUT ? "game thread did not take it in time" : "link closed",
         (unsigned)(uint16_t)hostData);
    return (jint)-1;
}

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStart(
        JNIEnv *env, jobject thiz, jobject link_obj, jboolean is_host, jboolean clock_sync)
{
    (void)thiz;

    /* FIX 23: g_link_obj/g_link_xchg_mid/g_link_is_host are read under
     * g_core_mutex everywhere else — link_sio_write_register(), called
     * from nativeRunFrame() while it holds this same lock, is what
     * actually uses them. These three used to be written here before any
     * lock was taken at all — the one gap in an otherwise-consistent
     * "always under g_core_mutex" rule for every global in this file (see
     * the "Globals — all access must hold g_core_mutex" comment above).
     * Practical risk was low (pointer/bool-sized writes are naturally
     * atomic on ARM, so a torn read was never realistic) but it was still
     * unsynchronized concurrent access by the letter of the C standard,
     * and the fix is small enough not to leave sitting once found.
     * GetObjectClass()/GetMethodID() are pure JNIEnv reflection calls that
     * touch no shared state, so they stay outside the lock; only the
     * three assignments themselves move inside it, together with
     * nativeLinkStop()'s teardown of the same three below. One small,
     * deliberate behavior change from before: on the !g_core failure path
     * just below, this no longer touches any *previous* g_link_obj at
     * all (the old code unconditionally cleared it right at the top,
     * before even checking g_core) — now all three are only ever written
     * together, under the lock, on the success path, so there's no
     * window where g_link_obj is NULL while g_link_xchg_mid still holds a
     * stale-but-valid method ID or vice versa. */

    /* AUDIT FIX (JNI hardening): a NULL link_obj would crash inside
     * GetObjectClass, and NewGlobalRef can return NULL under memory
     * pressure — which would then be stored as g_link_obj and dereferenced
     * by every later exchange. */
    if (link_obj == NULL) {
        LOGE("nativeLinkStart: null link object");
        return JNI_FALSE;
    }
    jclass cls = (*env)->GetObjectClass(env, link_obj);
    jmethodID mid = (*env)->GetMethodID(env, cls, "jniExchangeData", "(II)I");
    (*env)->DeleteLocalRef(env, cls);
    if (!mid) {
        LOGE("LinkMultiplayer.jniExchangeData(II)I not found");
        return JNI_FALSE;
    }
    jobject new_ref = (*env)->NewGlobalRef(env, link_obj);
    if (!new_ref) {
        LOGE("nativeLinkStart: NewGlobalRef failed");
        return JNI_FALSE;
    }

    pthread_mutex_lock(&g_core_mutex);
    if (!g_core) {
        pthread_mutex_unlock(&g_core_mutex);
        LOGE("nativeLinkStart called with no ROM loaded");
        (*env)->DeleteGlobalRef(env, new_ref);
        return JNI_FALSE;
    }

    if (g_link_obj) (*env)->DeleteGlobalRef(env, g_link_obj);
    g_link_obj      = new_ref;
    g_link_xchg_mid = mid;
    g_link_is_host  = (bool)is_host;

    /* FIX 7/8: register a real driver with the core's SIO subsystem instead
     * of relying on post-frame register polling. GBASIOSetDriver() on this
     * mGBA revision takes a mode argument (confirmed by the build log: the
     * 2-argument call I wrote from mgba's current docs failed to compile —
     * "too few arguments to function call, expected 3, have 2" — this
     * revision's signature apparently predates that simplification), and
     * struct GBASIODriver has no processEvents member on this revision
     * either (also confirmed by the build log). */
    g_link_gba = (struct GBA *)g_core->board;
    g_link_driver.d.init          = 0;
    g_link_driver.d.deinit        = 0;
    g_link_driver.d.load          = 0;
    g_link_driver.d.unload        = 0;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env             = NULL;
    g_link_driver.localSend       = 0xFFFFu;
    GBASIOSetDriver(&g_link_gba->sio, &g_link_driver.d, SIO_MULTI);

    /* FIX 20: never pace this session's first exchange against a timestamp
     * left over from a previous connection attempt. FIX 21: also arm this
     * session's first pacing window here — RCNT writes re-arm it again
     * after this, see link_sio_write_register(). FIX 22: force the next
     * nativeRunFrame() mode check to log a fresh baseline rather than
     * possibly matching a stale value left over from a previous session. */
    g_link_last_exchange_set = false;
    link_pace_arm_window();
    g_link_sio_mode_logged = false;

    /* CLOCK TIE: a fresh session starts from tick 0 with no history. The tick
     * event itself is put on the core's queue by link_frame_prologue() at the
     * start of the next frame (game thread — same place everything else that
     * touches the queue runs), not from here. */
    g_link_clock_sync  = (bool)clock_sync;
    g_link_tick        = 0;
    g_ch_have_prev     = false;
    g_ch_burst         = false;
    g_ch_hold_ms       = 20;
    g_ch_wait_ewma_us  = 5000;
    g_ch_gov_active    = false;
    g_st_host_xfers = g_st_host_to = g_st_host_notmulti = 0;
    g_st_host_rtt_us_sum = 0; g_st_host_rtt_us_max = 0;
    g_st_ch_delivered = g_st_ch_holds = g_st_ch_hold_to = 0;
    g_st_have_ts = false;
    memset(&g_lim_x, 0, sizeof g_lim_x); memset(&g_lim_w, 0, sizeof g_lim_w);

    g_link_active = true;
    lm_open(link_mbox());
    __atomic_store_n(&g_link_child_multi, link_sio_is_multi(g_link_gba), __ATOMIC_RELAXED);
    /* AUDIT FIX: the SD (bit 3) / SI (bit 2) / ID (bits 4-5) status is only
     * ever refreshed on a SIOCNT write by the ROM. If the ROM was already in
     * Multi-Player mode when the link came up (the player opened the game's
     * link menu BEFORE connecting the phones), it would not write SIOCNT
     * again and would keep reading "no link". Set it now. */
    if (link_sio_is_multi(g_link_gba)) {
        uint16_t sc = (uint16_t)(g_link_gba->sio.siocnt | 0x0008u);
        sc = g_link_is_host ? (uint16_t)(sc & ~0x0034u)
                            : (uint16_t)((sc | 0x0004u | 0x0010u) & ~0x0020u);
        g_link_gba->sio.siocnt = sc;
        g_link_gba->memory.io[0x0128u >> 1] = sc;
    }
    pthread_mutex_unlock(&g_core_mutex);

    /* FIX 17 / THIS PASS: the log is now started by nativeLinkLogBegin(), which
     * Kotlin calls when a connection ATTEMPT begins (so the connect/handshake
     * lines survive). This only makes sure a file is open, in APPEND mode,
     * if that call was somehow skipped — it never truncates. */
    pthread_mutex_lock(&g_link_log_mutex);
    if (!g_link_log_file && g_link_log_path[0]) {
        g_link_log_file = fopen(g_link_log_path, "a");
    }
    pthread_mutex_unlock(&g_link_log_mutex);

    LOGI("Link multiplayer started (host=%d clockSync=%d)", (int)is_host, (int)clock_sync);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStop(JNIEnv *env, jobject thiz)
{
    (void)thiz;
    lm_close(link_mbox());   /* wake a blocked child network thread first; takes only the mailbox lock */
    pthread_mutex_lock(&g_core_mutex);
    link_host_deferred_reset(false);   /* before g_link_gba is cleared: unsticks Start/Busy; the core (and its queue) lives on */
    g_link_active = false;
    if (g_link_gba) {
        GBASIOSetDriver(&g_link_gba->sio, NULL, SIO_MULTI);   /* core reverts to its own dummy driver */
        g_link_gba = NULL;
    }
    /* FIX 23: moved inside the lock — see nativeLinkStart()'s matching
     * comment above. DeleteGlobalRef() is a plain JNIEnv call, safe to
     * make while holding g_core_mutex (nativeLinkStart()'s own !g_core
     * failure path already did the equivalent safely). */
    if (g_link_obj) {
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
    }
    g_link_xchg_mid = NULL;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("Link multiplayer stopped (ticks=%u)", (unsigned)g_link_tick);
}
