#!/usr/bin/env bash
# Host-side test of the pure save logic in app/src/main/kotlin/com/mgba/android/saves/ — which in-game save a ROM
# opens (name-keyed, adopted from older per-build saves), the key/file-name rules, and the background session
# persister that keeps closing a game off the UI thread. Compiles the REAL sources next to SaveLogicTest.kt, so the
# test can't drift from the shipping code. Needs a Kotlin compiler (kotlinc) and a JDK; no Android SDK, no Gradle.
#
#   KOTLINC=/path/to/kotlinc ./run.sh      (defaults to `kotlinc` on PATH)
set -euo pipefail
cd "$(dirname "$0")"
KOTLINC="${KOTLINC:-kotlinc}"
SRC=../../app/src/main/kotlin/com/mgba/android/saves
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
"$KOTLINC" -language-version 1.9 -api-version 1.9 -jvm-target 17 -nowarn \
    "$SRC"/*.kt SaveLogicTest.kt -d "$OUT/classes"
CP="$OUT/classes:$(dirname "$(dirname "$(readlink -f "$(command -v "$KOTLINC")")")")/lib/kotlin-stdlib.jar"
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$CP" com.mgba.android.saves.SaveLogicTestKt
