# frame-pacer-test

Host-side tests for `app/src/main/kotlin/com/mgba/android/pacing/` — the pure-Kotlin part of "the game loop stays at
the right speed when the audio write does not pace it". They need only a Kotlin compiler (`kotlinc`, any 1.9+ / 2.x)
and a JDK 17+; no Android, no Gradle, no JUnit.

```
KOTLINC=/path/to/kotlinc/bin/kotlinc ./run.sh      # prints "ALL <n> CHECKS PASSED", exit code 1 on any failure
```

`run.sh` compiles the **real** `pacing/*.kt` next to `FramePacerTest.kt`, so a test cannot drift from the shipping
code. Time is a virtual clock (`LoopSim`), so a run is deterministic and takes milliseconds however many seconds of game
time it covers; a `Thread.sleep` that wakes late is modelled with a seeded random overshoot.

| section | what it pins down |
|---|---|
| audio-paced iteration | no wait whatever the clock says |
| schedule start | a fallback schedule starts at its own iteration's start, so time already spent (the emulation, a write that blocked before giving up) counts toward its budget |
| steady state, no drift | every iteration waits out the rest of its frame; 6000 frames with late wake-ups still end at the real GBA rate (within 0.02%) |
| falling behind | a short stumble is repaid and the long-run schedule kept; a long stall (more than `maxLagNs`) is given up instead of played back as a burst; the exact threshold |
| speed and frames | the budget is per emulated frame (`frames / speed`): batches at 2x / 4x / 16x, 0.5x, fractional speeds, a device too slow for the speed runs flat out; bad input (speed 0, negative or NaN; 0 frames) never becomes an endless sleep |
| hand-over | audio -> fallback -> audio: no stale deadline and no burst; the game speed holds through an outage and the recovery |
| clock wrap | a clock that wraps around mid-run changes nothing |

A mutation check (breaking the logic on purpose, one change at a time, and confirming a test fails) was used while
writing these — 13 breakages, all caught; a change to `pacing/` should keep every section meaningful the same way.

What this does **not** cover: the wiring in `MainActivityRender.kt` / `MainActivityAudio.kt` (`writePcm()` returning
whether it paced, the loop calling the pacer) needs the Android classes. For this pass those functions were also
compiled against stand-ins and run against a simulated audio device, as a one-off — see the top of `CHANGELOG.md`.
