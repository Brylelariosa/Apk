package com.mgba.android.pacing

import java.util.Random
import kotlin.math.abs
import kotlin.system.exitProcess

// Host-side tests for app/src/main/kotlin/com/mgba/android/pacing/FallbackFramePacer.kt — the wall-clock pacer the
// game loop falls back on when the blocking AudioTrack write did not pace it (no track, a failed or zero-progress
// write, a frame with no audio). run.sh compiles the REAL source next to this file, so a test cannot drift from the
// shipping code. No Android, no JUnit: a tiny assert harness and a virtual clock, so the run is deterministic and takes
// milliseconds however many "seconds" of game time it covers.

private var checks = 0
private val failures = ArrayList<String>()

private fun check(cond: Boolean, what: String) {
    checks++
    if (!cond) { failures += what; println("  FAIL: $what") }
}

private fun <T> checkEq(actual: T, expected: T, what: String) =
    check(actual == expected, "$what — expected <$expected> but was <$actual>")

private fun checkNear(actual: Long, expected: Long, tolNs: Long, what: String) =
    check(abs(actual - expected) <= tolNs, "$what — expected <$expected> ±$tolNs ns but was <$actual>")

private fun checkRate(actual: Double, expected: Double, relTol: Double, what: String) =
    check(abs(actual - expected) <= expected * relTol, "$what — expected <$expected> ±${relTol * 100}% but was <$actual>")

private fun section(name: String) = println("• $name")

private const val MS = 1_000_000L
private const val MAX_LAG = 100_000_000L
// The same arithmetic as FALLBACK_FRAME_NS in MainActivityShared.kt: the GBA's real frame period (~16.74 ms), not 1/60 s.
private val FRAME = 280_896L * 1_000_000_000L / 16_777_216L
private val FRAME_RATE = 1e9 / FRAME   // ~59.7275 frames per second

/**
 * A virtual clock driving the pacer the way the game thread does: run the frame(s), maybe block in the audio write,
 * ask the pacer, sleep for what it says. [maxOvershootNs] models Thread.sleep waking up late by up to that much.
 */
private class LoopSim(
    val pacer: FallbackFramePacer = FallbackFramePacer(FRAME, MAX_LAG),
    var now: Long = 1_000_000_000L,
    private val rng: Random? = null,
    private val maxOvershootNs: Long = 0L
) {
    val startedAt = now
    var frames = 0L

    /** One loop iteration; returns the wait the pacer asked for. */
    fun iteration(
        computeNs: Long,
        framesRun: Int = 1,
        speed: Float = 1f,
        audioPaced: Boolean = false,
        audioBlockNs: Long = 0L
    ): Long {
        val start = now
        now += computeNs + audioBlockNs
        val wait = pacer.waitNs(audioPaced, start, now, framesRun, speed)
        if (wait > 0L) {
            now += wait
            if (rng != null && maxOvershootNs > 0L) now += (rng.nextDouble() * maxOvershootNs).toLong()
        }
        frames += framesRun
        return wait
    }

    val elapsedNs: Long get() = now - startedAt
    val rate: Double get() = frames * 1e9 / elapsedNs   // emulated frames per second of game time
}

// ── tests ───────────────────────────────────────────────────────────────────────────────────────────────────────

private fun audioPacedIterations() {
    section("audio-paced iteration: no wait, whatever the clock says")
    val p = FallbackFramePacer(FRAME, MAX_LAG)
    checkEq(p.waitNs(true, 0L, 0L, 1, 1f), 0L, "no time used")
    checkEq(p.waitNs(true, 0L, 1 * MS, 1, 1f), 0L, "1 ms used")
    checkEq(p.waitNs(true, 0L, 500 * MS, 4, 4f), 0L, "a very long iteration")
}

private fun scheduleStartsAtTheIterationStart() {
    section("a fallback schedule starts at its own iteration's start, so time already spent counts")
    val start = 5_000_000_000L
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 3 * MS, 1, 1f), FRAME - 3 * MS,
        "3 ms of emulation → wait out the rest of the frame")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 12 * MS, 1, 1f), FRAME - 12 * MS,
        "an audio write that blocked ~10 ms before giving up (paused track) is not waited out a second time")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 20 * MS, 1, 1f), 0L,
        "already past the frame period → no wait at all")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start, 1, 1f), FRAME,
        "nothing used yet → a whole frame period")
}

private fun steadyState() {
    section("steady state: every iteration waits exactly the rest of its frame")
    val sim = LoopSim()
    var allEqual = true
    repeat(200) { if (sim.iteration(3 * MS) != FRAME - 3 * MS) allEqual = false }
    check(allEqual, "200 iterations of 3 ms emulation each wait FRAME - 3 ms")
    checkNear(sim.elapsedNs, 200 * FRAME, 2L, "200 frames take 200 frame periods")
}

private fun noDriftFromLateSleeps() {
    section("sleeps that wake late are paid back, not accumulated as drift")
    val sim = LoopSim(rng = Random(12345), maxOvershootNs = 1_500_000L)   // every sleep wakes 0-1.5 ms late
    val rng = Random(99)
    repeat(6000) { sim.iteration(computeNs = 1 * MS + (rng.nextDouble() * 3 * MS).toLong()) }   // 1-4 ms of emulation
    checkRate(sim.rate, FRAME_RATE, 0.0002, "6000 frames (~100 s) run at the real GBA rate to within 0.02%")
}

private fun fallingBehind() {
    section("a short stumble is repaid, the long-run schedule is kept")
    run {
        val sim = LoopSim()
        val s = sim.now
        sim.iteration(3 * MS)                                 // on schedule
        checkEq(sim.iteration(40 * MS), 0L, "one slow frame (40 ms) → no sleep while behind")
        checkEq(sim.iteration(3 * MS), 0L, "still behind → still no sleep")
        val catchUp = sim.iteration(3 * MS)
        check(catchUp in 1 until FRAME - 3 * MS, "the iteration that closes the gap only waits for the remainder (was $catchUp)")
        checkEq(sim.iteration(3 * MS), FRAME - 3 * MS, "back to a normal wait")
        checkNear(sim.now - s, 5 * FRAME, 2L, "5 iterations ended exactly 5 frame periods after the start — nothing lost, nothing gained")
    }

    section("a long stall is given up, not played back as a burst")
    run {
        val sim = LoopSim()
        sim.iteration(3 * MS)
        checkEq(sim.iteration(500 * MS), 0L, "a 500 ms stall → no sleep")
        var burst = false
        repeat(30) { if (sim.iteration(2 * MS) < FRAME - 3 * MS) burst = true }
        check(!burst, "afterwards every frame is paced again (no run of unthrottled frames winning the 500 ms back)")
    }

    section("the give-up threshold: exactly MAX_LAG behind is repaid, one ns more is given up")
    run {
        // Late by `lag` at the end of the first iteration; the second iteration takes no time, so its wait shows
        // whether the schedule was kept (the lag still has to be repaid → 0) or restarted (a whole frame period).
        fun secondWait(lag: Long): Long {
            val p = FallbackFramePacer(FRAME, MAX_LAG)
            val s = 7_000_000_000L
            val end = s + FRAME + lag
            p.waitNs(false, s, end, 1, 1f)
            return p.waitNs(false, end, end, 1, 1f)
        }
        checkEq(secondWait(MAX_LAG), 0L, "lag == MAX_LAG: schedule kept")
        checkEq(secondWait(MAX_LAG + 1), FRAME, "lag == MAX_LAG + 1: schedule restarted from now")
    }
}

private fun speedAndFrames() {
    section("speed and frame count: the budget is per emulated frame")
    fun budget(frames: Int, speed: Float): Long {
        val s = 1_000_000_000L
        return FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, s, s, frames, speed)
    }
    checkNear(budget(1, 1f), FRAME, 1L, "1 frame at 1x")
    checkNear(budget(1, 2f), FRAME / 2, 1L, "1 frame at 2x")
    checkNear(budget(2, 2f), FRAME, 1L, "a 2-frame batch at 2x takes one frame period (not a quarter of one)")
    checkNear(budget(4, 4f), FRAME, 1L, "a 4-frame batch at 4x takes one frame period")
    checkNear(budget(16, 16f), FRAME, 1L, "a 16-frame batch at 16x takes one frame period")
    checkNear(budget(24, 16f), FRAME * 3 / 2, 1L, "24 frames at 16x")
    checkNear(budget(1, 0.5f), 2 * FRAME, 1L, "1 frame at 0.5x takes two frame periods")
    checkNear(budget(3, 1f), 3 * FRAME, 1L, "3 frames at 1x take three frame periods")

    section("bad input never turns into an endless sleep")
    checkNear(budget(1, 0f), FRAME, 1L, "speed 0 is treated as 1x")
    checkNear(budget(1, -3f), FRAME, 1L, "negative speed is treated as 1x")
    checkNear(budget(1, Float.NaN), FRAME, 1L, "NaN speed is treated as 1x")
    check(budget(1, Float.POSITIVE_INFINITY) in 0L..1L, "infinite speed waits for nothing")
    checkNear(budget(0, 1f), FRAME, 1L, "0 frames counts as 1")
    checkNear(budget(-5, 1f), FRAME, 1L, "negative frames counts as 1")
    check(budget(Int.MAX_VALUE, 1f) > 0L, "absurd frame counts do not overflow into a negative wait")
}

private fun fractionalFastForward() {
    section("fast-forward at a fractional speed: batches of 1 and 2 frames average out to the selected speed")
    val sim = LoopSim(rng = Random(5), maxOvershootNs = 500_000L)
    var i = 0
    repeat(3000) { sim.iteration(computeNs = 1 * MS, framesRun = if (i++ % 2 == 0) 1 else 2, speed = 1.5f) }
    checkRate(sim.rate, FRAME_RATE * 1.5, 0.0005, "1.5x runs at 1.5 times the real GBA rate")

    section("fast-forward 4x as 4-frame batches")
    val ff = LoopSim(rng = Random(6), maxOvershootNs = 500_000L)
    repeat(3000) { ff.iteration(computeNs = 6 * MS, framesRun = 4, speed = 4f) }
    checkRate(ff.rate, FRAME_RATE * 4, 0.0005, "4x runs at 4 times the real GBA rate")

    section("a device too slow for the selected speed runs flat out instead of piling up debt")
    val slow = LoopSim()
    repeat(200) { slow.iteration(computeNs = 40 * MS, framesRun = 4, speed = 4f) }   // 4 frames need 40 ms; 4x allows 16.7
    checkNear(slow.elapsedNs, 200 * 40 * MS, 1L, "no sleeping at all while the schedule cannot be met")
}

private fun audioComesAndGoes() {
    section("audio pacing and the fallback hand over cleanly (no stale deadline, no burst)")
    run {
        val sim = LoopSim()
        repeat(10) { sim.iteration(2 * MS) }                                   // fallback
        repeat(3) { sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) }   // audio paced three frames
        checkEq(sim.iteration(2 * MS), FRAME - 2 * MS,
            "first fallback iteration after audio paced: a fresh schedule, not a deadline left over from before")
    }
    run {
        val sim = LoopSim()
        repeat(10) { sim.iteration(2 * MS) }
        repeat(300) { sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) }  // ~5 s of audio pacing
        checkEq(sim.iteration(2 * MS), FRAME - 2 * MS, "... also after a long stretch of audio pacing")
    }

    section("audio drops out and comes back: game speed holds in every phase")
    val sim = LoopSim(rng = Random(7), maxOvershootNs = 1 * MS)
    fun phase(seconds: Int, audio: Boolean): Double {
        val f0 = sim.frames
        val t0 = sim.now
        while (sim.now < t0 + seconds * 1_000_000_000L) {
            // audio ok: the blocking write holds the iteration to one frame period. audio gone: it returns at once
            // (or there is no track), so nothing but the pacer slows the loop down.
            if (audio) sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) else sim.iteration(2 * MS)
        }
        return (sim.frames - f0) * 1e9 / (sim.now - t0)
    }
    checkRate(phase(5, audio = true), FRAME_RATE, 0.001, "audio working")
    checkRate(phase(5, audio = false), FRAME_RATE, 0.001, "audio gone — paced by the clock alone")
    checkRate(phase(5, audio = true), FRAME_RATE, 0.001, "audio back")
    checkRate(phase(1, audio = false), FRAME_RATE, 0.01, "a one-second blip")
    checkRate(sim.rate, FRAME_RATE, 0.001, "whole run")
}

private fun clockWrap() {
    section("a clock that wraps around mid-run changes nothing")
    val sim = LoopSim(now = Long.MAX_VALUE - 3 * FRAME)
    var ok = true
    repeat(20) { if (sim.iteration(2 * MS) != FRAME - 2 * MS) ok = false }
    check(ok, "20 iterations across the wrap-around all wait FRAME - 2 ms")
    check(sim.now < 0L, "(the test clock really did wrap)")
}

private fun construction() {
    section("constructor guards")
    fun throwsIae(block: () -> Unit) = try { block(); false } catch (_: IllegalArgumentException) { true }
    check(throwsIae { FallbackFramePacer(0L, MAX_LAG) }, "frameNs = 0 rejected")
    check(throwsIae { FallbackFramePacer(-1L, MAX_LAG) }, "negative frameNs rejected")
    check(throwsIae { FallbackFramePacer(FRAME, -1L) }, "negative maxLagNs rejected")
    check(!throwsIae { FallbackFramePacer(FRAME, 0L) }, "maxLagNs = 0 is allowed (never carries any debt)")
}

fun main() {
    audioPacedIterations()
    scheduleStartsAtTheIterationStart()
    steadyState()
    noDriftFromLateSleeps()
    fallingBehind()
    speedAndFrames()
    fractionalFastForward()
    audioComesAndGoes()
    clockWrap()
    construction()
    println()
    if (failures.isEmpty()) {
        println("ALL $checks CHECKS PASSED")
    } else {
        println("${failures.size} OF $checks CHECKS FAILED")
        exitProcess(1)
    }
}
