#!/usr/bin/env bash
# Host-side test of the pure pacing logic in app/src/main/kotlin/com/mgba/android/pacing/ — the wall-clock pacer the
# game loop falls back on when the blocking AudioTrack write did not pace it. Compiles the REAL sources next to
# FramePacerTest.kt, so the test can't drift from the shipping code. Needs a Kotlin compiler (kotlinc) and a JDK; no
# Android SDK, no Gradle.
#
#   KOTLINC=/path/to/kotlinc ./run.sh      (defaults to `kotlinc` on PATH)
set -euo pipefail
cd "$(dirname "$0")"
KOTLINC="${KOTLINC:-kotlinc}"
SRC=../../app/src/main/kotlin/com/mgba/android/pacing
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
"$KOTLINC" -language-version 1.9 -api-version 1.9 -jvm-target 17 -nowarn \
    "$SRC"/*.kt FramePacerTest.kt -d "$OUT/classes"
CP="$OUT/classes:$(dirname "$(dirname "$(readlink -f "$(command -v "$KOTLINC")")")")/lib/kotlin-stdlib.jar"
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$CP" com.mgba.android.pacing.FramePacerTestKt
