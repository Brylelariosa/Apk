package com.mgba.android

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import java.io.File

/**
 * FEATURE — "Link local": two games linked on ONE phone, like My Boy!'s local link ("it opens another game and
 * they link").
 *
 * The emulator core is global state in the native library — one core per process — so a second game cannot
 * share the first one's process. This is the same activity, [MainActivity], declared in AndroidManifest.xml with
 * `android:process=":p2"`: Android starts a second process with its own copy of the native library and its own
 * core. The first window (the host) starts listening on the loopback address (LinkMultiplayer.startWifiHost with
 * `local = true`), launches this window next to itself in split-screen, and this window — as soon as its game
 * has loaded — joins that host over 127.0.0.1 (joinLocalHost()). From there it is the ordinary link: the same
 * lock-step protocol and clock tie as over Wi-Fi, on a socket whose round trip is a fraction of a millisecond,
 * so the host no longer waits for the network (compare the capture: ~4 ms per word over Wi-Fi).
 *
 * What the second process must not share with the first, and how that is handled:
 *  - SharedPreferences — two processes writing one file overwrite each other's changes. This window reads and
 *    writes [PREFS_PLAYER_TWO], seeded once per process from the first window's file (getSharedPreferences()
 *    override below). Because every settings access goes through getSharedPreferences(PREFS, ...) on the
 *    activity, nothing else had to change.
 *  - files in cacheDir (the staged ROM copies) and filesDir (the link log) — names carry [instanceFileTag].
 *  - battery saves, save states, cheats — keyed by the ROM's save key, which gets a "p2" prefix in this window
 *    (romReadableName() / SaveKeys.readableName()), so two copies of the SAME game never share a .sav (a Pokemon trade needs two
 *    saves) and this window's saves never touch the first window's.
 *  - audio focus — this window does not request it (requestAudioFocus()).
 *
 * UNVERIFIED on a real device (this sandbox has no Android runtime, and no Kotlin compiler). What is checked is
 * the part that does not need one: the loopback transport and the link protocol (tools/native-link-test).
 */
class PlayerTwoActivity : MainActivity() {

    override val isPlayerTwo: Boolean get() = true

    override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences =
        super.getSharedPreferences(if (name == PREFS) PREFS_PLAYER_TWO else name, mode)

    override fun onCreate(savedInstanceState: Bundle?) {
        seedPlayerTwoPrefs()
        pendingLocalLinkJoin = intent?.getBooleanExtra(EXTRA_LOCAL_LINK_JOIN, false) == true
        super.onCreate(savedInstanceState)
    }

    /** "Link local" pressed again in the first window while this one is still open (singleTask: the existing
     *  window is reused). Join right away if a game is already running here, else as soon as one has loaded. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_LOCAL_LINK_JOIN, false)) {
            if (romLoaded) joinLocalHost() else pendingLocalLinkJoin = true
        }
    }

    /** Copies the first window's settings file to this window's own, once per process — only while this
     *  process has not opened it yet (a file replaced under an open SharedPreferences is not re-read). */
    private fun seedPlayerTwoPrefs() {
        if (prefsSeeded) return
        prefsSeeded = true
        try {
            val dir = File(applicationInfo.dataDir, "shared_prefs")
            val src = File(dir, "$PREFS.xml")
            val dst = File(dir, "$PREFS_PLAYER_TWO.xml")
            if (src.isFile) {
                dir.mkdirs()
                src.copyTo(dst, overwrite = true)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Couldn't copy the settings for the second window — it starts with defaults", e)
        }
    }

    private companion object {
        /** Per process: this process's PlayerTwoActivity may be created again (rotation of the window, a second
         *  launch) after it already holds the prefs file open. */
        var prefsSeeded = false
    }
}
