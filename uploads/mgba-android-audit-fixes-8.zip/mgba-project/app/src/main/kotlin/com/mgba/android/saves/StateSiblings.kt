package com.mgba.android.saves

/** A file as the folder scan sees it: only what the matching below needs. */
internal class NamedFile(val name: String, val size: Long, val modified: Long)

/** Another build of the same game that has save states: [key] is its full state key `<readable>_<crc>`. */
internal class StateSibling(val key: String, val crc: String, val modified: Long)

/**
 * Finds other builds of a game that have save states, so the player can be offered to use them for this build too.
 * Pure — the Android side only has to list file names, sizes and dates.
 *
 * Only save states count here. The in-game save is shared by name already ([BatterySaveResolver]); states are a
 * snapshot of one build's memory, so reusing another build's is a choice the player makes, not a default.
 */
internal object StateSiblings {

    /** The most recently written state of any build of [readable] other than [ownCrc], or null. A build counts
     *  when it has at least one non-empty state file (numbered slot, quicksave or autosave); thumbnails alone say
     *  nothing, and neither do battery saves. */
    fun find(readable: String, ownCrc: String, files: Iterable<NamedFile>): StateSibling? {
        val newest = HashMap<String, Long>()
        for (f in files) {
            if (f.size <= 0L) continue
            val parsed = SaveKeys.parseBuildFile(readable, f.name) ?: continue
            if (parsed.crc == ownCrc) continue
            if (!SaveKeys.isStateExtension(parsed.extension) || SaveKeys.isThumbnailExtension(parsed.extension)) continue
            val prev = newest[parsed.crc]
            if (prev == null || f.modified > prev) newest[parsed.crc] = f.modified
        }
        val best = newest.entries.maxByOrNull { it.value } ?: return null
        return StateSibling(SaveKeys.buildKey(readable, best.key), best.key, best.value)
    }

    /** Does [key] have at least one non-empty state file (`<key>.state<N>`, `.quicksave`, `.autosave`)? */
    fun hasStates(key: String, files: Iterable<NamedFile>): Boolean {
        val prefix = "$key."
        return files.any { f ->
            f.size > 0L && f.name.startsWith(prefix) && !f.name.contains(".tmp-") &&
                f.name.substring(prefix.length).let {
                    SaveKeys.isStateExtension(it) && !SaveKeys.isThumbnailExtension(it)
                }
        }
    }
}
