package com.mgba.android.pacing

/**
 * Wall-clock frame pacer for the game loop's *fallback* path.
 *
 * The loop is normally paced by the blocking AudioTrack write (see `writePcm()` in MainActivityAudio.kt): the audio
 * hardware's clock is steadier than any sleep, so tying the core to it leaves no drift. That only works while the
 * write really blocks. When it does not — there is no AudioTrack, a write fails or makes no progress, a frame produced
 * no audio at all — nothing else slows the loop down (rendering runs on its own thread and the native core never
 * sleeps), and the emulator runs as fast as the CPU allows: wrong game speed, a pegged core, a warm phone.
 *
 * This class supplies the missing pacing from the monotonic clock for exactly those iterations, and does nothing on
 * every iteration the audio write paced. It is asked once per game-loop iteration, after the frame(s) and the audio
 * write, and answers with how long the loop should still wait:
 *
 *  - **Audio paced the iteration** (`audioPaced == true`): no wait, and any schedule is dropped. A later failure starts
 *    a fresh schedule instead of "catching up" to a deadline that went stale while audio was doing the pacing, which
 *    would play as a burst of unthrottled frames.
 *  - **It did not**: the iteration is held to `frames` emulated frames at `speed`x real time.
 *
 * Deadline-based rather than "sleep one frame period after every frame". Each iteration moves an absolute deadline
 * forward by what its frames are worth, so a sleep that overshoots (the scheduler is late, a sleep rounds up) is paid
 * back by a shorter wait next time instead of piling up as drift — and time the iteration has already spent (the
 * emulation itself, or an audio write that blocked for a while before giving up) counts toward its own budget instead
 * of being waited out a second time.
 *
 * Falling behind is handled in two steps. A short stumble (a GC pause, one slow frame) is repaid: the wait is zero and
 * the deadline stays where it was, so the next few frames run back to back until the schedule is met again. A long
 * one — more than `maxLagNs` behind — is given up: the deadline restarts from "now", because sprinting to win back
 * half a second would show as a visible fast-forward burst, and a device that is simply too slow for full speed would
 * otherwise carry an ever-growing debt it can never pay.
 *
 * Pure on purpose: no Android types and no sleeping — the caller passes the clock readings in (`System.nanoTime()`,
 * monotonic) and sleeps for the returned time, which keeps every rule above unit-testable on a plain JVM
 * (`tools/frame-pacer-test`). Not thread-safe; owned by the one game thread.
 *
 * @param frameNs one emulated frame at 1x, in nanoseconds (the GBA's real ~16.74 ms, not 1/60 s).
 * @param maxLagNs how far behind schedule the pacer may fall before it gives the lost time up.
 */
internal class FallbackFramePacer(
    private val frameNs: Long,
    private val maxLagNs: Long
) {
    init {
        require(frameNs > 0L) { "frameNs must be positive" }
        require(maxLagNs >= 0L) { "maxLagNs must not be negative" }
    }

    /** Absolute time (monotonic ns) by which the work scheduled so far should be finished. Meaningful only while
     *  [scheduled]. All comparisons are differences of two readings, so a wrapping clock cannot confuse them. */
    private var deadlineNs = 0L
    private var scheduled = false

    /**
     * How long the game loop should still wait before starting its next iteration, in nanoseconds (0 = not at all).
     *
     * @param audioPaced true if the blocking audio write accepted every sample of this iteration — see `writePcm()`.
     * @param iterationStartNs the clock reading taken when this iteration began. A schedule that starts with this
     *        iteration is anchored here, so the time it has already used counts against its budget.
     * @param nowNs the clock reading now, after the emulation and the audio write.
     * @param frames how many emulated frames this iteration ran (1 normally; a fast-forward batch runs several).
     * @param speed the selected speed multiplier (1 = real time, 2 = twice as fast, 0.5 = half). Zero, negative and
     *        NaN values are treated as 1 so a bad setting can never turn into an endless sleep.
     */
    fun waitNs(audioPaced: Boolean, iterationStartNs: Long, nowNs: Long, frames: Int, speed: Float): Long {
        if (audioPaced) {
            scheduled = false
            return 0L
        }
        if (!scheduled) {
            deadlineNs = iterationStartNs
            scheduled = true
        }
        val safeSpeed = if (speed > 0f) speed.toDouble() else 1.0
        // What `frames` frames are worth at this speed. Per emulated frame, not per iteration: a fast-forward batch
        // already runs about `speed` frames, so dividing one frame's period by `speed` *again* per iteration would
        // make the batch race at roughly speed-squared.
        deadlineNs += (frames.coerceAtLeast(1) * frameNs / safeSpeed).toLong()

        val waitNs = deadlineNs - nowNs
        if (waitNs > 0L) return waitNs
        if (-waitNs > maxLagNs) deadlineNs = nowNs   // too far behind to win back: restart the schedule from now
        return 0L
    }
}
