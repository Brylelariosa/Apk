package com.mgba.android.saves

/** What to do about the in-game save of a game the first time it is loaded under name-keyed saves. */
internal sealed class AdoptionPlan {
    /** Nothing to carry over: open the name-keyed file as it is (a fresh one is created if it does not exist). */
    object UseShared : AdoptionPlan()

    /** Exactly one distinct save exists, and it is not the name-keyed file: copy [from] over it. */
    class Adopt(val from: SaveFileInfo) : AdoptionPlan()

    /** Two or more different saves exist: the player has to pick. [options] is newest first, one per distinct
     *  content; the name-keyed file itself may be one of them. */
    class Ask(val options: List<SaveFileInfo>) : AdoptionPlan()
}

/**
 * Decides how the in-game saves that exist for one game are brought together under its name-keyed file
 * (`<readable>.sav`). Pure: it only looks at the [SaveFileInfo]s it is given, so every case is testable.
 *
 * The in-game save used to be filed per ROM build — `<readable>_<crc>.sav` — so a patched ROM renamed to the
 * original's name started a new game, and any other ROM build with that name had its own save. Now the name alone
 * decides. The files of the old scheme are the only source of progress to carry over; nothing here deletes or
 * rewrites them, the caller copies.
 *
 * The name-keyed file may already exist before this runs, and then it is NOT a new file: for a game saved before
 * the CRC suffix existed it is that old save (the CRC-era app copied it to the first build that loaded it and never
 * wrote it again), or it is a file the player dropped in by hand. So it is weighed like the others, with one
 * exception — see [isSuperseded].
 */
internal object BatteryAdoption {

    /**
     * @param shared the name-keyed file as it exists now, null if there is none
     * @param builds the old-style per-build files `<readable>_<crc>.sav` found for this game
     */
    fun plan(shared: SaveFileInfo?, builds: List<SaveFileInfo>): AdoptionPlan {
        val realBuilds = builds.filter { it.real }
        val realShared = shared?.takeIf { it.real && !isSuperseded(it, realBuilds) }

        val pool = ArrayList<SaveFileInfo>(realBuilds.size + 1)
        pool.addAll(realBuilds)
        if (realShared != null) pool.add(realShared)
        if (pool.isEmpty()) return AdoptionPlan.UseShared

        // One entry per distinct content. The name-keyed file represents its own group (copying it onto itself
        // would only churn it); otherwise the newest file of the group does.
        val representatives = pool.groupBy { it.digest + ":" + it.size }.values.map { group ->
            group.firstOrNull { it === realShared } ?: group.maxByOrNull { it.modified }!!
        }
        if (representatives.size == 1) {
            val only = representatives[0]
            return if (only === realShared) AdoptionPlan.UseShared else AdoptionPlan.Adopt(only)
        }
        return AdoptionPlan.Ask(representatives.sortedByDescending { it.modified })
    }

    /**
     * An old name-only file is an ancestor, not a rival, of a per-build file that holds different bytes and is at
     * least as new: the CRC-era app made that file by copying the name-only one and then played on it, so it
     * already contains the older save's progress. Treating the ancestor as a separate save would ask a question
     * about every game that was ever saved before the CRC suffix existed.
     *
     * "At least as new" needs two known dates: a document provider that reports no modification time (0) cannot
     * prove anything, and guessing wrong here would let an older file replace a newer save — so it is asked instead.
     */
    private fun isSuperseded(shared: SaveFileInfo, realBuilds: List<SaveFileInfo>): Boolean =
        shared.modified > 0L && realBuilds.any {
            (it.digest != shared.digest || it.size != shared.size) && it.modified > 0L && it.modified >= shared.modified
        }
}
