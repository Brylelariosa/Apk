package com.mgba.android

// The Android side of the name-keyed in-game save. The decisions live in the pure, JVM-tested package
// com.mgba.android.saves (BatterySaveResolver / BatteryAdoption — see tools/save-logic-test); this file only
// supplies what they need from the device: the files (app folder and the chosen Storage folder, both reached through
// SaveEntry), the SharedPreferences facts, and the question dialog. Same extension-function file layout as the rest
// of MainActivity's split-out files.

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.text.format.DateFormat
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.mgba.android.saves.BatteryResolution
import com.mgba.android.saves.BatterySaveResolver
import com.mgba.android.saves.BatteryStore
import com.mgba.android.saves.ConflictChooser
import com.mgba.android.saves.RomIdentity
import com.mgba.android.saves.SaveContentAnalyzer
import com.mgba.android.saves.SaveFileInfo
import com.mgba.android.saves.SaveKeys
import com.mgba.android.saves.SaveRegistry
import java.io.File
import java.io.InputStream
import java.util.Date

/**
 * The registry lives in its OWN preferences file, not in the settings file ([PREFS]): the second Link-local window
 * runs in another process with a private, once-seeded copy of the settings (see PlayerTwoActivity), and two
 * processes sharing one preferences file overwrite each other's changes. Each process writes only its own file —
 * [instanceFileTag] is "" for the first window and "_p2" for the second — and it has no settings to clash with.
 */
private const val SAVE_REGISTRY_PREFS = "mgba_save_registry"

/**
 * The in-game save this ROM opens: `<name>.sav`, shared by every ROM with that name — see [BatterySaveResolver].
 * Called on the ROM LOADER THREAD, right before the core is loaded: it reads and copies files, and may show a dialog
 * and wait for the answer (never call it on the main thread). Never throws: if anything unexpected goes wrong the
 * ROM simply opens its own per-ROM save file, exactly as it did before.
 */
internal fun MainActivity.resolveBatterySave(identity: RomIdentity): BatteryResolution {
    val resolution = try {
        batteryResolver().resolve(identity)
    } catch (e: Exception) {
        Log.w(TAG, "in-game save lookup failed — using this ROM's own save file", e)
        BatteryResolution(identity.buildKey, BatteryResolution.Outcome.FAILED, null)
    }
    when (resolution.outcome) {
        BatteryResolution.Outcome.ADOPTED -> {
            // Say so only when the save really came from another version of this ROM; carrying a ROM's own old file
            // over to its new name-keyed one is bookkeeping the player never needs to hear about.
            val from = resolution.adoptedFrom
            if (from?.crc != null && from.crc != identity.crc) {
                uiToast("Continuing the in-game save from another version of this ROM")
            }
        }
        BatteryResolution.Outcome.DEFERRED ->
            uiToast("Using this ROM's own in-game save for now — you'll be asked again next time")
        BatteryResolution.Outcome.FAILED ->
            uiToast("Couldn't switch to the shared in-game save — using this ROM's own save for now")
        BatteryResolution.Outcome.SHARED -> Unit
    }
    return resolution
}

/**
 * Call once the ROM has really loaded on the name-keyed in-game save: this ROM build's session is then the latest one
 * on it, which is what lets [BatteryResolution.autosaveMatchesSave] tell a later load of ANOTHER build — or of this
 * one, after another had played — that its autosave no longer describes the save. Cheap (one preferences write) and
 * never throws.
 */
internal fun MainActivity.recordBatterySession(identity: RomIdentity) {
    try {
        batteryResolver().sessionStarted(identity)
    } catch (e: Exception) {
        Log.w(TAG, "could not record which ROM build last used the in-game save", e)
    }
}

private fun MainActivity.batteryResolver() = BatterySaveResolver(
    store = AndroidBatteryStore(this),
    registry = PrefsSaveRegistry(getSharedPreferences(SAVE_REGISTRY_PREFS + instanceFileTag, Context.MODE_PRIVATE)),
    chooser = DialogConflictChooser(this),
    log = { Log.w(TAG, it) }
)

/**
 * The folder side of [BatterySaveResolver]. A file's content is what a load would actually open: the Storage-folder
 * document when a folder is chosen and has one (that is what batteryMirrorPath() stages into the local file),
 * otherwise the local file in the app's saves folder. Reading and writing go through [MainActivity.SaveEntry], which
 * hides which of the two a file lives in, and writes use its crash-safe stage/commit pair.
 */
internal class AndroidBatteryStore(private val activity: MainActivity) : BatteryStore {

    override fun statShared(key: String): SaveFileInfo? = describe(key, crc = null)

    override fun scanBuildSaves(readable: String): List<SaveFileInfo> {
        val crcs = LinkedHashSet<String>()
        activity.savesDir().list()?.forEach { name -> SaveKeys.parseBuildBattery(readable, name)?.let { crcs.add(it) } }
        try {
            activity.dataSubfolder("save")?.listFiles()?.forEach { doc ->
                val name = doc.name ?: return@forEach
                SaveKeys.parseBuildBattery(readable, name)?.let { crcs.add(it) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Storage-folder scan for earlier per-ROM saves skipped", e)
        }
        return crcs.mapNotNull { crc -> describe(SaveKeys.buildKey(readable, crc), crc) }
    }

    override fun copy(from: SaveFileInfo, toKey: String): Boolean =
        copyBytes(from.key, activity.batterySaveEntry(toKey))

    override fun snapshot(key: String, label: String): Boolean {
        val dest = activity.SaveEntry(File(activity.savesDir(), "${SaveKeys.batteryFileName(key)}.$label"), "save")
        if (dest.exists()) return true
        val ok = copyBytes(key, dest)
        if (ok) dest.mirrorToAutoFolder()
        return ok
    }

    private class Source(val stream: InputStream, val modified: Long)

    private fun open(key: String): Source? {
        try {
            val entry = activity.batterySaveEntry(key)
            // The date is read BEFORE the stream is opened: if the provider throws here, there is no open stream
            // left behind to leak.
            var modified = entry.lastModified()
            // Some document providers report no modification time; the local copy, if any, knows one.
            if (modified <= 0L) modified = activity.batterySaveFile(key).lastModified()
            val stream = entry.inputStream()
            if (stream != null) return Source(stream, modified)
        } catch (e: Exception) {
            Log.w(TAG, "AndroidBatteryStore.open($key) via the Storage folder failed — trying the local file", e)
        }
        val local = activity.batterySaveFile(key)
        return try {
            if (local.isFile) Source(local.inputStream(), local.lastModified()) else null
        } catch (e: Exception) {
            Log.w(TAG, "AndroidBatteryStore.open($key) failed", e)
            null
        }
    }

    private fun describe(key: String, crc: String?): SaveFileInfo? {
        val source = open(key) ?: return null
        return try {
            source.stream.use { input ->
                val a = SaveContentAnalyzer.analyze(input)
                SaveFileInfo(key, crc, a.size.toLong(), source.modified, a.real, a.digest)
            }
        } catch (e: Exception) {
            Log.w(TAG, "AndroidBatteryStore.describe($key) failed", e)
            null
        }
    }

    private fun copyBytes(fromKey: String, dest: MainActivity.SaveEntry): Boolean {
        val source = open(fromKey) ?: return false
        val staged = dest.stageForWrite()
        return try {
            source.stream.use { input -> File(staged).outputStream().use { out -> input.copyTo(out) } }
            dest.commitWrite(staged)
        } catch (e: Exception) {
            Log.w(TAG, "AndroidBatteryStore: copying $fromKey failed", e)
            dest.discardWrite(staged)
            false
        }
    }
}

/**
 * The facts the resolver keeps between runs, in a SharedPreferences file of their own.
 *
 * The facts that gate a file operation — "this name has been unified", "this build has opened the shared save" — are
 * written with commit(): they are recorded AFTER the files were copied or snapshotted, and an apply() that a process
 * kill loses would send the next load through the whole decision (and the dialog) again. They run on the loader
 * thread, so the synchronous write costs the UI nothing. "Which build ran last" is only a hint and uses apply().
 */
internal class PrefsSaveRegistry(private val prefs: SharedPreferences) : SaveRegistry {
    private fun unifiedKey(readable: String) = "battery_unified_$readable"
    private fun buildsKey(readable: String) = "battery_builds_$readable"
    private fun lastKey(readable: String) = "battery_last_$readable"

    override fun isUnified(readable: String): Boolean = prefs.getBoolean(unifiedKey(readable), false)

    override fun markUnified(readable: String, builds: Set<String>) {
        val all = HashSet(builds)
        all.addAll(builds(readable))
        prefs.edit().putBoolean(unifiedKey(readable), true).putStringSet(buildsKey(readable), all).commit()
    }

    override fun builds(readable: String): Set<String> =
        HashSet(prefs.getStringSet(buildsKey(readable), null) ?: emptySet<String>())

    override fun addBuild(readable: String, crc: String) {
        val all = HashSet(builds(readable))
        all.add(crc)
        prefs.edit().putStringSet(buildsKey(readable), all).commit()
    }

    override fun lastBuild(readable: String): String? = prefs.getString(lastKey(readable), null)

    override fun setLastBuild(readable: String, crc: String) {
        prefs.edit().putString(lastKey(readable), crc).apply()
    }
}

/**
 * "Which in-game save should this game use?" — shown only when two different real saves exist for one game name.
 * One button per save (newest first, with its date and where it came from) and "Decide later". Runs through
 * [awaitDialog], so the loader thread waits for it and every way out (Back, a tap outside, the activity going away)
 * answers "decide later".
 */
internal class DialogConflictChooser(private val activity: MainActivity) : ConflictChooser {

    override fun choose(readable: String, options: List<SaveFileInfo>, ownCrc: String?): SaveFileInfo? =
        activity.awaitDialog<SaveFileInfo?>(null) { answer -> build(readable, options, ownCrc, answer) }

    private fun build(
        readable: String, options: List<SaveFileInfo>, ownCrc: String?, answer: (SaveFileInfo?) -> Unit
    ): AlertDialog {
        val ctx = activity
        lateinit var dialog: AlertDialog
        val body = ctx.dialogContentLayout().apply {
            addView(TextView(ctx).apply {
                text = "There is more than one in-game save for “$readable”. The one you pick is used from now " +
                    "on by every ROM with this name, including patched or renamed copies. Nothing is deleted: the " +
                    "other saves stay in your saves folder, and the current file is backed up first."
                textSize = 14f
                setTextColor(Color.WHITE)
            })
            options.forEachIndexed { index, option ->
                addView(Button(ctx).apply {
                    text = describe(option, ownCrc, newest = index == 0)
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.parseColor("#553A3A4A"))
                    setOnClickListener {
                        answer(option)
                        dialog.dismiss()
                    }
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = ctx.dp(12) })
            }
        }
        dialog = AlertDialog.Builder(ctx)
            .setTitle("Which in-game save?")
            .setView(ScrollView(ctx).apply { addView(body) })
            .setNegativeButton("Decide later", null)
            .create()
        dialog.window?.setBackgroundDrawable(ctx.roundedDialogBackground())
        return dialog
    }

    private fun describe(option: SaveFileInfo, ownCrc: String?, newest: Boolean): String {
        val whenText = if (option.modified > 0L) {
            val date = Date(option.modified)
            "${DateFormat.getMediumDateFormat(activity).format(date)} ${DateFormat.getTimeFormat(activity).format(date)}"
        } else {
            "date unknown"
        }
        val whose = when {
            option.crc == null -> "the existing “${option.key}.sav” file"
            option.crc == ownCrc -> "this ROM's own save"
            else -> "another version of this ROM (${option.crc})"
        }
        return "${if (newest) "Most recent — " else ""}$whenText\n$whose"
    }
}
