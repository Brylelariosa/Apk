package com.mgba.android.saves

import java.util.concurrent.ExecutionException
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Runs the work that ends a play session — copying the battery save out to the Storage-folder and automatic mirrors,
 * writing the autosave and its thumbnail — one job at a time on a background thread, so the UI thread never has to
 * wait for slow storage.
 *
 * Why it exists: closing a game used to start a worker for that work and then block the UI thread on it for up to
 * 2.5 seconds (`Thread.join`). On phones with slow flash storage — or whenever the Storage folder lives behind a
 * slow document provider — the fsync and the cross-process copies routinely take longer than a frame budget by an
 * order of magnitude, which is the "closing the game lags" the player sees. Nothing about closing needs the result:
 * the session is over, the process is not going away, and whatever starts next (loading a ROM, Reset, destroying the
 * activity) calls [awaitIdle] first, so it can never overlap a flush that is still running.
 *
 * Jobs run in submission order. A job that throws is reported through [onError] and does not stop later ones. The
 * thread is a daemon and goes away when idle, so a provider that never answers cannot keep the process alive or leak
 * a parked thread.
 */
internal class SessionPersister(
    private val threadName: String = "mGBA-persist",
    private val onError: (label: String, error: Throwable) -> Unit = { _, _ -> }
) {
    // corePoolSize 0 + an unbounded queue: at most one worker thread, started on demand, retired after 20 s idle.
    private val executor = ThreadPoolExecutor(
        0, 1, 20L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>(),
        ThreadFactory { r -> Thread(r, threadName).apply { isDaemon = true } }
    )

    /** Queues [job]. The returned future completes once it has run, also when it threw. Null after [shutdown]. */
    fun submit(label: String, job: () -> Unit): Future<*>? = try {
        executor.submit(Runnable {
            try {
                job()
            } catch (t: Throwable) {
                onError(label, t)
            }
        })
    } catch (_: RejectedExecutionException) {
        null
    }

    /** Waits for [job] for at most [timeoutMs]. True if it has finished, false if still running (or interrupted). */
    fun await(job: Future<*>, timeoutMs: Long): Boolean = try {
        job.get(timeoutMs.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
        true
    } catch (_: TimeoutException) {
        false
    } catch (_: ExecutionException) {
        true   // submit() already caught the job's own failure; this is only the wrapper completing
    } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
        false
    }

    /** Waits until every job submitted before this call has finished, at most [timeoutMs]. True if the queue is
     *  drained, false if something is still running when the time is up. */
    fun awaitIdle(timeoutMs: Long): Boolean {
        val marker = submit("idle-marker") { } ?: return true
        return await(marker, timeoutMs)
    }

    /** No new jobs; the ones already queued still run. */
    fun shutdown() {
        executor.shutdown()
    }
}
