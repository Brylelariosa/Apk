package com.mgba.android.saves

import java.io.InputStream
import java.security.MessageDigest

/**
 * What [BatteryAdoption] needs to know about one in-game save file. [key] is the file's base name without ".sav";
 * [crc] is the ROM build an old-style `<readable>_<crc>.sav` file belongs to, null for the name-only file.
 * Equal [digest] and [size] mean equal contents.
 */
internal class SaveFileInfo(
    val key: String,
    val crc: String?,
    val size: Long,
    val modified: Long,
    val real: Boolean,
    val digest: String
) {
    override fun toString(): String = "SaveFileInfo($key, crc=$crc, size=$size, modified=$modified, real=$real)"
}

/** Reads a save file once and says whether it has been played into, plus a digest of its contents. */
internal object SaveContentAnalyzer {
    /** A GBA save is at most 128 KiB; anything bigger is not one, and reading further would only cost time. */
    const val MAX_ANALYZED_BYTES = 256 * 1024

    class Analysis(val size: Int, val real: Boolean, val digest: String)

    /**
     * "Real" means played into: not empty, not entirely 0x00 (fresh SRAM) and not entirely 0xFF (erased Flash or
     * EEPROM, which is what mGBA creates for a save that has not been written to yet). Anything in between — even
     * only zeros and 0xFFs mixed — is treated as real: wrongly calling a fresh file real only costs a question,
     * wrongly calling a real save fresh would hide it.
     */
    fun analyze(input: InputStream): Analysis {
        val sha = MessageDigest.getInstance("SHA-1")
        val buf = ByteArray(8192)
        var total = 0
        var anyNonZero = false
        var anyNonFF = false
        while (total < MAX_ANALYZED_BYTES) {
            val n = input.read(buf, 0, minOf(buf.size, MAX_ANALYZED_BYTES - total))
            if (n < 0) break
            if (!(anyNonZero && anyNonFF)) {
                for (i in 0 until n) {
                    val b = buf[i].toInt() and 0xFF
                    if (b != 0x00) anyNonZero = true
                    if (b != 0xFF) anyNonFF = true
                }
            }
            sha.update(buf, 0, n)
            total += n
        }
        return Analysis(total, total > 0 && anyNonZero && anyNonFF, hex(sha.digest()))
    }

    private fun hex(bytes: ByteArray): String {
        val out = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            out.append(HEX[v ushr 4]).append(HEX[v and 0x0F])
        }
        return out.toString()
    }

    private const val HEX = "0123456789abcdef"
}
