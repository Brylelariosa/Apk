package com.mgba.android

import android.app.Dialog
import android.os.Looper
import android.util.Log
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Shows a dialog on the UI thread and makes the calling BACKGROUND thread — in practice the ROM loader thread —
 * wait for the player's answer.
 *
 * [show] builds the dialog (it must not call show() itself) and receives `answer`, which the dialog's buttons and
 * list items call with their result. [fallback] is returned when the dialog is dismissed without an answer (Back, a
 * tap outside), could not be shown, or the activity went away while it was up.
 *
 * Every way out releases the caller: the wait is released by the dialog's own dismiss listener (which fires for a
 * button, Back, a tap outside and cancel alike), an exception while building or showing it releases it too, and
 * the wait itself is a loop of 500 ms slices that gives up with [fallback] once the activity is finishing or
 * destroyed — so a dialog that vanished with its window can never leave the loader hanging.
 *
 * Never call it on the UI thread: waiting there would block the very thread that has to show the dialog. If that
 * ever happens it fails safe with [fallback] instead of freezing the app.
 */
internal fun <T> MainActivity.awaitDialog(fallback: T, show: (answer: (T) -> Unit) -> Dialog): T {
    if (Looper.myLooper() == Looper.getMainLooper()) return fallback
    val latch = CountDownLatch(1)
    val answer = AtomicReference(fallback)
    runOnUiThread {
        try {
            if (isFinishing || isDestroyed) {
                latch.countDown()
                return@runOnUiThread
            }
            val dialog = show { value -> answer.set(value) }
            dialog.setOnDismissListener { latch.countDown() }   // fires on every way out
            dialog.show()
        } catch (t: Throwable) {
            Log.w(TAG, "dialog could not be shown", t)
            latch.countDown()
        }
    }
    while (!latch.await(500, TimeUnit.MILLISECONDS)) {
        if (isFinishing || isDestroyed) return fallback
    }
    return answer.get()
}
