package com.mgba.android.saves

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Where the in-game saves live. The Android implementation covers the app's own folder and the chosen Storage
 *  folder; the tests use an in-memory one. */
internal interface BatteryStore {
    /** The name-keyed save `<key>.sav` as it exists right now, or null. */
    fun statShared(key: String): SaveFileInfo?

    /** The old-style per-build saves `<readable>_<crc>.sav` of this game (empty once nothing is left to carry over). */
    fun scanBuildSaves(readable: String): List<SaveFileInfo>

    /** Makes `<toKey>.sav` hold the bytes of [from], crash-safely. True on success; on failure the previous
     *  `<toKey>.sav`, if any, is left as it was. */
    fun copy(from: SaveFileInfo, toKey: String): Boolean

    /** Keeps a copy of `<key>.sav` as `<key>.sav.<label>`. Never overwrites an existing snapshot of that label.
     *  True if the snapshot exists afterwards. */
    fun snapshot(key: String, label: String): Boolean
}

/** Small persistent facts the resolver needs between runs (SharedPreferences on Android). */
internal interface SaveRegistry {
    /** True once the in-game save of [readable] has been brought together under its name-keyed file. */
    fun isUnified(readable: String): Boolean

    /** Records that [readable]'s name-keyed file is now authoritative; [builds] are the ROM builds (CRCs) whose
     *  progress it is known to hold. */
    fun markUnified(readable: String, builds: Set<String>)

    /** ROM builds (CRCs) that have opened the name-keyed file of [readable]. */
    fun builds(readable: String): Set<String>

    fun addBuild(readable: String, crc: String)

    /** The ROM build (CRC) whose session was the last one to run on [readable]'s name-keyed save, or null. */
    fun lastBuild(readable: String): String?

    fun setLastBuild(readable: String, crc: String)
}

/** Asks the player which of several different saves a game should use. Called on the loader thread; may block. */
internal fun interface ConflictChooser {
    /** The chosen option, or null if the player backed out. */
    fun choose(readable: String, options: List<SaveFileInfo>, ownCrc: String?): SaveFileInfo?
}

/**
 * [key] is the in-game save this session opens: the name-keyed one, or — [Outcome.DEFERRED], [Outcome.FAILED] — the
 * build's own.
 *
 * [autosaveMatchesSave] says whether this build's own autosave (and its other save states) still describe the
 * in-game save that is about to be opened. A save state carries the save RAM, so loading one puts ITS copy of the
 * in-game save back — harmless when that copy is what the file holds, a rewind (or a wipe) when another version of
 * the game has played on, or another save has been carried over, since the state was made. The caller must not
 * auto-load the autosave when this is false.
 */
internal class BatteryResolution(
    val key: String,
    val outcome: Outcome,
    val adoptedFrom: SaveFileInfo?,
    val autosaveMatchesSave: Boolean = true
) {
    enum class Outcome {
        /** The name-keyed save is in use; nothing was carried over this time. */
        SHARED,

        /** A save from another file of this game was carried over into the name-keyed one just now. */
        ADOPTED,

        /** The player backed out of the question. This session runs on the build's own file; asked again next time. */
        DEFERRED,

        /** Carrying a save over failed (disk full, ...). This session runs on the build's own file; retried next time. */
        FAILED
    }

    val usesBuildFile: Boolean get() = outcome == Outcome.DEFERRED || outcome == Outcome.FAILED
}

/**
 * Picks the in-game save a ROM opens: `<readable>.sav`, shared by every ROM with that name, so a patched ROM renamed
 * to the original's name continues the original's game.
 *
 * Steady state (the name has been unified before) costs two small registry reads and nothing else. The first load
 * of a name under this scheme brings the saves of the old per-build scheme together — [BatteryAdoption] decides how,
 * the player is asked only when two different real saves exist.
 *
 * Safety net: nothing is ever deleted, an existing real name-keyed save is snapshotted before it is overwritten, and
 * the first time a ROM build that has not used the name-keyed save before opens it, the save is snapshotted too — if
 * it turns out to be a different game that merely shares the name and trashes the save, the pre-open copy is still on
 * disk next to it (`<readable>.sav.before-<crc>`).
 */
internal class BatterySaveResolver(
    private val store: BatteryStore,
    private val registry: SaveRegistry,
    private val chooser: ConflictChooser,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val log: (String) -> Unit = {}
) {
    fun resolve(id: RomIdentity): BatteryResolution {
        val key = id.batteryKey
        var adopted: SaveFileInfo? = null
        val autosaveFits: Boolean

        if (registry.isUnified(id.readable)) {
            // An unknown CRC cannot be tracked and behaves as before: nothing is ever held back for it.
            autosaveFits = id.crc == null || registry.lastBuild(id.readable) == id.crc
        } else {
            val shared = store.statShared(key)
            val builds = store.scanBuildSaves(id.readable)
            when (val plan = BatteryAdoption.plan(shared, builds)) {
                is AdoptionPlan.UseShared -> Unit
                is AdoptionPlan.Adopt -> {
                    if (!carryOver(plan.from, key)) return fallback(id, BatteryResolution.Outcome.FAILED)
                    adopted = plan.from
                }
                is AdoptionPlan.Ask -> {
                    val picked = chooser.choose(id.readable, plan.options, id.crc)
                        ?: return fallback(id, BatteryResolution.Outcome.DEFERRED)
                    if (picked.key != key) {
                        if (!carryOver(picked, key)) return fallback(id, BatteryResolution.Outcome.FAILED)
                        adopted = picked
                    }
                }
            }
            autosaveFits = autosaveFitsAfterUnifying(id, shared, builds, adopted)
            registry.markUnified(id.readable, setOfNotNull(adopted?.crc))
        }

        protectOtherBuilds(id, key)
        val outcome = if (adopted != null) BatteryResolution.Outcome.ADOPTED else BatteryResolution.Outcome.SHARED
        return BatteryResolution(key, outcome, adopted, autosaveFits)
    }

    /** Call once the ROM has actually loaded on the name-keyed save: this build's session is now the latest one. */
    fun sessionStarted(id: RomIdentity) {
        id.crc?.let { registry.setLastBuild(id.readable, it) }
    }

    /**
     * Do this build's save states still describe the in-game save about to be opened? Only provably-yes counts.
     * Asked the first time a name is unified (afterwards it is "was this build the last one to run on the shared
     * save", see [resolve]); the autosave was written next to the build's own old per-build file, so:
     *  - a save carried over from THIS build's own old file: yes;
     *  - a save carried over from another build (or from the old name-only file): no;
     *  - nothing carried over and no real save at all: yes, there is nothing for a state to rewind;
     *  - nothing carried over and a real name-keyed file in place: yes only if this build's own old file holds the
     *    very same bytes, otherwise the autosave may belong to a different save than the one that stays.
     */
    private fun autosaveFitsAfterUnifying(
        id: RomIdentity, shared: SaveFileInfo?, builds: List<SaveFileInfo>, adopted: SaveFileInfo?
    ): Boolean {
        val crc = id.crc ?: return true
        if (adopted != null) return adopted.crc == crc
        if (shared == null || !shared.real) return true
        return builds.any { it.crc == crc && it.digest == shared.digest && it.size == shared.size }
    }

    /** Copies [from] over the name-keyed file, keeping whatever real save was there first. */
    private fun carryOver(from: SaveFileInfo, key: String): Boolean {
        val existing = store.statShared(key)
        if (existing != null && existing.real && !store.snapshot(key, "before-adopt-${stamp()}")) {
            log("not carrying ${from.key} over $key: could not keep a copy of the existing save")
            return false
        }
        val ok = store.copy(from, key)
        if (!ok) log("could not copy ${from.key} to $key")
        return ok
    }

    /** First time this ROM build opens a name-keyed save that other builds have used: keep a copy of it as it is. */
    private fun protectOtherBuilds(id: RomIdentity, key: String) {
        val crc = id.crc ?: return
        val seen = registry.builds(id.readable)
        if (crc in seen) return
        if (seen.isNotEmpty() && store.statShared(key)?.real == true && !store.snapshot(key, "before-$crc")) {
            log("could not snapshot $key before build $crc opens it; will retry next load")
            return
        }
        registry.addBuild(id.readable, crc)
    }

    private fun fallback(id: RomIdentity, outcome: BatteryResolution.Outcome) =
        BatteryResolution(id.buildKey, outcome, null)

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(Date(clock()))
}
