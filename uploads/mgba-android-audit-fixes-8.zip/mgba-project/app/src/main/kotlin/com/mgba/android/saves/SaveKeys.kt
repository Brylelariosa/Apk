package com.mgba.android.saves

/**
 * Naming rules for everything the emulator files per game. Pure Kotlin (no Android types), so the rules can be
 * exercised on a plain JVM — see tools/save-logic-test.
 *
 * Two identities are in play and this file is where the split between them lives:
 *
 *  - the GAME  → `<readable>`            "the game the player thinks they are playing": the ROM's file name without
 *    its extension, made filesystem-safe. The in-game (battery) save is filed by this alone, so a patched copy that
 *    has been renamed to the original's name — or any other ROM carrying the same name — opens the same in-game
 *    save, the way it does in every other emulator.
 *
 *  - the BUILD → `<readable>_<crc32>`    "this exact ROM file". Save states (numbered slots, quicksave, autosave and
 *    their thumbnails) are a snapshot of one build's memory; loading one into a patched build can glitch or crash,
 *    so those stay per build. Before the in-game save moved to the game identity, the battery save was filed under
 *    this key too — the `<readable>_<crc32>.sav` files of that era are what [BatteryAdoption] carries over.
 */
internal object SaveKeys {
    const val MAX_READABLE_LENGTH = 48
    const val MAX_LEGACY_LENGTH = 80
    const val PLAYER_TWO_PREFIX = "p2-"
    const val BATTERY_EXTENSION = "sav"
    const val CRC_LENGTH = 8

    private val UNSAFE_CHARS = Regex("[^\\p{L}\\p{N}_-]")
    private val LEGACY_UNSAFE_CHARS = Regex("[^A-Za-z0-9_-]")
    private val ENDS_WITH_CRC = Regex("_[0-9a-f]{8}$")
    private val BUILD_FILE_REST = Regex("^([0-9a-f]{8})\\.(.+)$")

    /**
     * The readable half of every key: [rawBaseName] (the ROM's display name minus its extension) with everything
     * except Unicode letters/digits, '_' and '-' replaced by '_', cut to [MAX_READABLE_LENGTH] characters, "rom" if
     * nothing is left. The second game window of Link local ([playerTwo]) gets a "p2-" prefix: that is what keeps
     * its saves apart from the first window's even for the very same ROM file — a trade between two copies of a
     * game needs two saves.
     */
    fun readableName(rawBaseName: String, playerTwo: Boolean = false): String {
        val name = rawBaseName.replace(UNSAFE_CHARS, "_").take(MAX_READABLE_LENGTH).ifBlank { "rom" }
        return if (playerTwo) PLAYER_TWO_PREFIX + name else name
    }

    /** The sanitizer from before the CRC suffix existed, verbatim. Only used to find files to carry over. */
    fun legacyName(rawBaseName: String): String =
        rawBaseName.replace(LEGACY_UNSAFE_CHARS, "_").take(MAX_LEGACY_LENGTH).ifBlank { "rom" }

    fun isCrc(text: String): Boolean =
        text.length == CRC_LENGTH && text.all { it in '0'..'9' || it in 'a'..'f' }

    /** `<readable>_<crc>`, or just `<readable>` when the ROM's CRC could not be computed. Save states, quicksave,
     *  autosave and thumbnails are filed under this. */
    fun buildKey(readable: String, crc: String?): String =
        if (crc != null) "${readable}_$crc" else readable

    /**
     * The key of the in-game save: the game's name. A name that itself ends in "_" plus eight hex digits
     * ("Hack_20261026") gets one more "_" so the file can never be mistaken for the old per-build file of another
     * ROM called "Hack" with that CRC — see [parseBuildBattery].
     */
    fun batteryKey(readable: String): String =
        if (ENDS_WITH_CRC.containsMatchIn(readable)) "${readable}_" else readable

    /** `<key>.sav` */
    fun batteryFileName(key: String): String = "$key.$BATTERY_EXTENSION"

    /** A file filed under a build key: `<readable>_<crc>.<extension>`. */
    class BuildFile(val crc: String, val extension: String)

    /** Parses [fileName] as `<readable>_<crc>.<extension>`; null for anything else (other games, temp files). */
    fun parseBuildFile(readable: String, fileName: String): BuildFile? {
        val prefix = "${readable}_"
        if (!fileName.startsWith(prefix) || fileName.contains(".tmp-")) return null
        val m = BUILD_FILE_REST.matchEntire(fileName.substring(prefix.length)) ?: return null
        return BuildFile(m.groupValues[1], m.groupValues[2])
    }

    /** The CRC of an old-style per-build battery file `<readable>_<crc>.sav`, or null if [fileName] is not one. */
    fun parseBuildBattery(readable: String, fileName: String): String? =
        parseBuildFile(readable, fileName)?.takeIf { it.extension == BATTERY_EXTENSION }?.crc

    /** True for the extension of a save state file or its thumbnail: "state<N>", "quicksave", "autosave" (+ ".png"). */
    fun isStateExtension(extension: String): Boolean {
        val base = extension.removeSuffix(".png")
        return base == "quicksave" || base == "autosave" ||
            (base.startsWith("state") && base.length > 5 && base.substring(5).all { it in '0'..'9' })
    }

    /** True for a state thumbnail's extension — it says nothing about whether a state exists by itself. */
    fun isThumbnailExtension(extension: String): Boolean = extension.endsWith(".png")
}

/**
 * Which ROM is being loaded: the [readable] game name and the [crc] of this exact build (null if it could not be
 * computed). Everything else — the in-game save key, the state key — is derived from these two.
 */
internal class RomIdentity(val readable: String, val crc: String?) {
    /** Key of the in-game save: shared by every ROM that carries this name. */
    val batteryKey: String get() = SaveKeys.batteryKey(readable)

    /** Key of this exact ROM build: save states, quicksave, autosave and thumbnails. */
    val buildKey: String get() = SaveKeys.buildKey(readable, crc)

    override fun toString(): String = "RomIdentity($readable, crc=$crc)"
}
