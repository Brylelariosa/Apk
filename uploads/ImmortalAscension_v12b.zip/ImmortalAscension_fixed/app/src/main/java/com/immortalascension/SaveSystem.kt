package com.immortalascension

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.lang.reflect.Field

object SaveSystem {

    private const val PREF_NAME    = "immortal_save"
    private const val KEY_GAME     = "game_state"
    private const val KEY_LAST_SAVE= "last_save_time"

    private val gson: Gson = GsonBuilder().serializeNulls().create()

    fun save(context: Context, engine: GameEngine) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_GAME, gson.toJson(engine.state))
            .putLong(KEY_LAST_SAVE, System.currentTimeMillis())
            .apply()
    }

    fun load(context: Context): GameState? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json  = prefs.getString(KEY_GAME, null) ?: return null
        return try {
            val state = gson.fromJson(json, GameState::class.java) ?: return null
            fixNulls(state)
            state
        } catch (e: Exception) {
            android.util.Log.e("SaveSystem", "Load failed: ${e.message}", e)
            null
        }
    }

    /**
     * Gson bypasses constructors and sets non-nullable Kotlin MutableList/Object
     * fields to null when the JSON key is missing or null.
     * Kotlin's type system then emits "Condition always false" warnings for null
     * checks — meaning safe checks are compiled away.
     *
     * Fix: use Java reflection to directly read and replace null fields,
     * bypassing Kotlin's compile-time non-null assumptions entirely.
     */
    private fun fixNulls(state: GameState) {
        // ── Player ────────────────────────────────────────────────────────────
        val p = state.player ?: run { state.player = Player(); state.player }
        fixField(p, "techniques",  ::emptyMutable)
        fixField(p, "inventory",   ::emptyMutable)
        fixField(p, "titles",      ::emptyMutable)
        fixField(p, "daoInsights", ::emptyMutable)
        fixField(p, "mentalScars", ::emptyMutable)
        if (getField(p, "reputationState") == null)
            setField(p, "reputationState", ReputationState())
        val rep = getField(p, "reputationState") as? ReputationState
        rep?.let {
            fixField(it, "rumours",     ::emptyMutable)
            fixField(it, "knownTitles", ::emptyMutable)
        }

        // ── World ─────────────────────────────────────────────────────────────
        val w = state.world ?: run { state.world = WorldState(); state.world }
        fixField(w, "discoveredPlaces") { mutableListOf("azure_wind_village") }
        fixField(w, "activeEvents",  ::emptyMutable)
        fixField(w, "eventHistory",  ::emptyMutable)
        // Sanitize location ID
        val locId = getField(w, "locationId") as? String
        if (locId.isNullOrBlank() || !LocationSystem.ALL_LOCATIONS.containsKey(locId)) {
            setField(w, "locationId", "azure_wind_village")
            setField(w, "location",   "Azure Wind Village")
        }

        // ── NPCs ──────────────────────────────────────────────────────────────
        if (getField(state, "npcs") == null) setField(state, "npcs", mutableListOf<NPC>())
        (getField(state, "npcs") as? MutableList<*>)?.forEach { npc ->
            (npc as? NPC)?.let { n ->
                fixField(n, "goals",            ::emptyMutable)
                fixField(n, "npcRelationships", ::emptyMutable)
                fixField(n, "techniques",       ::emptyMutable)
                fixField(n, "lifeEvents",       ::emptyMutable)
                // Fix invalid location
                val nLoc = getField(n, "currentLocation") as? String
                if (nLoc.isNullOrBlank() || !LocationSystem.ALL_LOCATIONS.containsKey(nLoc)) {
                    setField(n, "currentLocation", LocationSystem.ALL_LOCATIONS.keys.first())
                }
            }
        }

        // ── Missions / News / Log ─────────────────────────────────────────────
        fixField(state, "activeMissions", ::emptyMutable)
        fixField(state, "worldNews",      ::emptyMutable)
        fixField(state, "log",            ::emptyMutable)

        // ── Combat (clear stale/corrupt combat state) ─────────────────────────
        val cs = getField(state, "combat")
        if (cs != null) {
            val effects = getField(cs, "playerEffects")
            if (effects == null) setField(state, "combat", null)
        }
    }

    // ── Reflection helpers ────────────────────────────────────────────────────

    private fun emptyMutable() = mutableListOf<Any>()

    private fun fixField(obj: Any, name: String, default: () -> Any) {
        try {
            val f = findField(obj.javaClass, name) ?: return
            f.isAccessible = true
            if (f.get(obj) == null) f.set(obj, default())
        } catch (e: Exception) {
            android.util.Log.w("SaveSystem", "fixField $name: ${e.message}")
        }
    }

    private fun getField(obj: Any, name: String): Any? {
        return try {
            val f = findField(obj.javaClass, name) ?: return null
            f.isAccessible = true
            f.get(obj)
        } catch (e: Exception) { null }
    }

    private fun setField(obj: Any, name: String, value: Any?) {
        try {
            val f = findField(obj.javaClass, name) ?: return
            f.isAccessible = true
            f.set(obj, value)
        } catch (e: Exception) {
            android.util.Log.w("SaveSystem", "setField $name: ${e.message}")
        }
    }

    /** Walk the class hierarchy to find the field (handles inheritance). */
    private fun findField(cls: Class<*>, name: String): Field? {
        var c: Class<*>? = cls
        while (c != null) {
            try { return c.getDeclaredField(name) } catch (_: NoSuchFieldException) {}
            c = c.superclass
        }
        return null
    }

    fun hasSave(context: Context): Boolean =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).contains(KEY_GAME)

    fun deleteSave(context: Context) =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().clear().apply()
}
