// Top-level build file. The game itself is Rust (see Cargo.toml and src/); Gradle only wraps the compiled
// library into an APK. There is no Kotlin or Java code, so no Kotlin plugin is needed.
plugins {
    id("com.android.application") version "8.3.2" apply false
}
