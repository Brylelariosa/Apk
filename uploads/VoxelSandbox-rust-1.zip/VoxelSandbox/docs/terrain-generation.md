# Terrain generation (v15)

The rule for this work: **every existing seed generates exactly the world it generated in v14**, bit for bit, and a change stays
only if it was measured to help. The result: one change survived (per-thread working memory: 58 % less garbage per chunk), one
was tried and removed (reusing the border samples of neighbouring chunks), and **the CPU time per chunk did not change beyond
the noise of the machine**. This is a generation that was already compact; its cost is the noise functions themselves.

## How it was checked

`tools/gen-check/run_golden.sh` generates 9 seeds (0, 1, 12345, 20261023, -1, 25214903917, two random 64-bit seeds, Long.MAX / MIN),
396 chunks each (the origin and the spawn point, negative coordinates, chunks 100 000 and 1 000 000 blocks out, and two places of each
biome the v14 generator has: plains, forest, birch forest, taiga and snowy taiga, savanna, desert, swamp, beach, lake, ocean, deep
ocean, mountains, snowy peaks, snowy plains, snowy shore; chosen once, with the v14 generator) and compares, bit for bit (raw double bits for the floating-point lattices), with what the **original v14 generator**
produced (`golden-v14.txt`, 3.5 KB; `golden-v14.chunks.txt` names the first chunk that differs): every block of every chunk, the
height maps, cave mouths, which sub-chunks exist, and the public query lattices (terrain shape, climate, biome, caves, spawn
point). Every seed is also generated again on three threads in shuffled order and must give the same hashes (the working memory
below is per thread; this is what would catch it leaking between chunks).

- v15 generator: **9 / 9 seeds identical**, also under three threads.
- The check can fail: with one constant changed on purpose (`waterDepth > 8` to `> 9`, a threshold deep in the column filler) it
  reports 8 of 9 seeds different and the first differing chunks.

## Where the time goes (profile)

Sampling profile (JFR, this machine, 1 thread, 3564 chunks; inclusive shares of the sampled stacks):

| what | share of a chunk |
|---|---|
| ground height (`TerrainShape.heightOf`: 400 samples per chunk, the 16 x 16 columns and a border of two) | about 35 % |
| the rock under the soil (`rockBlock`), of which the ore and pocket noise (`sampleRockCell`: two `noise3D` per 2 x 2 x 2-block cell, only where a block asks) is about 24 % | about 31 % |
| caves (`CaveCarver.carve`: a 5 x 5 lattice, caverns, tunnels) | about 15 % |
| climate / biome per column | about 12 % |
| the rest: trees, plants, the other block writes | the remainder |

So three quarters of the time is evaluating simplex noise. A noise value is a pure function of the position, and the rule is bit-identity,
so no expression may be reordered (floating-point addition is not associative): what remains open is memory, and not computing
a sample twice.

## What changed: working memory per thread (`TerrainGenerator.Scratch`)

`generate` allocated, for every chunk, about 35 KB of working arrays: the raw heights (an `IntArray` and a `DoubleArray` of 400),
the despiked heights, the column tables and, the big part, the rock noise (two `FloatArray(3072)` and a `BooleanArray(3072)`). Two of
these are over 12 KB, above which Android's runtime allocates an array in a separate space, which is slower to allocate and is only
freed by a full collection. They now live in one `Scratch` per generating thread (a `ThreadLocal`, like the cave carver's; created
with `initialValue()` so it works on API 24, where `ThreadLocal.withInitial` does not exist), and every array is overwritten in
full by each call (the rock noise is marked unsampled again), so nothing of one chunk can reach the next.

| | before | after |
|---|---|---|
| garbage per chunk, the game's order, 2 threads | 60 391 bytes | **25 253 bytes** (-58 %) |
| garbage per chunk, scan order, 1 thread | 63 320 bytes | **28 136 bytes** (-56 %) |
| young collections, 4551 chunks x 6 rounds, 8 MB young generation | 247 | **104** (-58 %) |
| total pause of those collections | 95 ms | 86 ms (within noise) |
| CPU per chunk, 2 threads, game order (separate runs, alternating) | 1.18 / 1.26 / 1.30 / 1.33 ms | 1.24 / 1.28 / 1.31 ms |
| wall time per chunk, 1 thread, scan order (median of the steady rounds, two passes) | 1.35 / 1.62 ms | 1.36 / 1.53 ms |

(The first two "after" runs of each row still had the border-sample cache that is described, and was removed, below.)

What remains (25 KB) is the chunk itself: the block arrays of the sub-chunks that hold ground (five of them for typical land), the
height map and the trees.

The **CPU time did not move beyond the machine's own spread** (a 2-core shared container: +-10 % from one run to the next, so the
runs were alternated and repeated); no speed-up is claimed. What is claimed is the garbage, which is exact (bytes allocated, per
thread, from the JVM), and that fewer collections cost a phone less than they do this JVM.

## Tried and removed: reusing the border samples of the neighbours

Every chunk samples 400 heights for 256 columns (the 16 x 16 and a border of two, so a column's slope and the lone-bump filter are exact
without the neighbours), and a neighbour's window overlaps it by four columns. Copying the overlap from the windows of the last eight
chunks of the same thread is bit-identical (the golden check passed) and saves 25.7 % of the samples **in scan order**. But the game
does not generate in scan order: workers take the chunk nearest to the player, so consecutive chunks of a thread are not neighbours.
In the game's order the same cache reused **1.4 % of the samples (1 thread) to 2.9 % (2 threads)**. Not a win, so it was removed;
the code is not in the project. (Sharing windows between threads would need room for every chunk in flight, ~150 windows, and an
eviction scheme, for at most 12 % of the total.)

## Not done (and why)

- `noise3D` micro-optimisations (a pre-reduced gradient table for `% 12`, sign-selected adds in place of multiplications by 0 / +-1):
  estimated at 2-3 % at most (not measured), and the second one changes the sign of a zero, which is bit-identical only if every use is a comparison;
  not worth the proof.
- Skipping the second rock noise where the first already decided (`coal > threshold`): coal is rare.
- Skipping caverns by a bound on the noise: needs a rigorous Lipschitz bound; a margin from experiments is not a proof.
- Scheduling: the workers already run just below background priority, park by the work budget, and a chunk is a single job, so
  nothing blocks the render thread; unchanged.

## Re-running

    export KOTLINC=... ANDROID_JAR=.../android-34/android.jar STDLIB=.../kotlin-stdlib.jar
    tools/gen-check/run_golden.sh                       # bit-identity against v14 (about 40 s)
    tools/gen-check/run_bench.sh stream 12 2 22         # game order, 2 threads, CPU and bytes per chunk
    tools/gen-check/run_bench.sh chunks tools/gen-check/golden-sites.txt 14
    PROJECT_ROOT=/other/tree tools/gen-check/run_bench.sh ...   # the same, on another tree, to compare (alternate the runs)
    JAVA_EXTRA="-Xmn8m -Xlog:gc:file=gc.log" tools/gen-check/run_bench.sh stream 6 2 22   # count the collections

These are numbers of a desktop JVM, not of a phone; the Android runtime's collector and allocator differ, and nothing here has been run
on a device.
