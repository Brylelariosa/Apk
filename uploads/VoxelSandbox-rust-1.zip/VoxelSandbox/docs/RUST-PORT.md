# Rust port notes

## Layout

| Path | What lives there | Builds on a PC? |
|---|---|---|
| `src/core` | maths, Kotlin-exact `Random` (so seeds shuffle noise like before), logging | yes |
| `src/world` | blocks, chunks (copy-on-write sections), fluids, world storage, streaming with worker threads | yes |
| `src/gen` | noise, climate, land shape, caves, trees, chunk generator — a 1:1 port of the v15 generator | yes |
| `src/mesh` | chunk mesher (culling, ambient occlusion, cave darkening, biome tint, water, plants) | yes |
| `src/tex` | the 34 pixel-art tiles (generated from the Kotlin tables by `tools/gen_tiles.py`) + texture array data | yes |
| `src/game` | player, physics, flight, raycast, placement, hotbar, settings, saves, engine | yes |
| `src/ui` | pixel font, 2D batch, touch tracking, HUD, all screens (`ui/app.rs`) | yes |
| `src/render` | OpenGL ES 3.0 renderer, shaders | Android only |
| `src/platform` | EGL, NativeActivity event loop, touch + back key | Android only |

Everything except `render` and `platform` is plain Rust and is unit-tested on the build machine
(`cargo test --lib`, run by the workflow).

## Threads

The main thread owns the world and the GL context. Worker threads (up to 3) generate chunks and build meshes
from cheap snapshots (chunk sections are `Arc`s, so a snapshot is a few pointer copies and an edit copies only the
section it touches). Results come back through a channel; the renderer uploads at most a few meshes per frame.

## Ported

World generation (continents, rivers, lakes, swamps, mountains, climate biomes, caves, ores, trees, plants),
terrain meshing with ambient occlusion and biome-tinted grass/leaves, animated-height water, procedural clouds
and sky, fog, walking + creative flight, double-tap-jump flight, auto-jump, break / place, "laser" tunnel tool,
fluid simulation, hotbar + creative inventory, touch HUD (joystick, look pad, buttons), settings, world saving.

## Not ported yet

* Far-terrain LOD (the v15 game drew 64 chunks; this version draws the detailed world up to 24 chunks,
  default 10, with distance fog).
* HUD customise mode (drag / resize buttons), break particles, creative-inventory search, the in-app
  diagnostic log / crash share screen (replaced by a simple "last error report" screen in the main menu).
* Greedy meshing and the region packer (the renderer uses one mesh per chunk column).

## Saves

`world.bin` in the app's private files directory: seed, player, hotbar and every *edited* chunk (run-length coded).
Untouched terrain is regenerated from the seed. The format is new (v15 saves are not readable).

## Diagnosing a problem on a phone

* A panic anywhere is written to `last_panic.txt`; the main menu then shows "VIEW LAST ERROR REPORT".
* Shader compile errors are drawn on screen.
* CI prints the cargo output and the unit-test summary; on failure the cargo logs are uploaded with the reports.
