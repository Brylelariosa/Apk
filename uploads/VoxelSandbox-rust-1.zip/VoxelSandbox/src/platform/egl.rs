//! EGL: the bridge between an Android window and OpenGL ES, declared by hand against `libEGL`.

#![allow(non_snake_case, dead_code)]

use std::os::raw::{c_uint, c_void};
use std::ptr::{null, null_mut};

pub type EGLDisplay = *mut c_void;
pub type EGLSurface = *mut c_void;
pub type EGLContext = *mut c_void;
pub type EGLConfig = *mut c_void;
pub type EGLNativeDisplayType = *mut c_void;
pub type EGLNativeWindowType = *mut c_void;
pub type EGLint = i32;
pub type EGLBoolean = c_uint;

const EGL_NO_DISPLAY: EGLDisplay = null_mut();
const EGL_NO_SURFACE: EGLSurface = null_mut();
const EGL_NO_CONTEXT: EGLContext = null_mut();
const EGL_DEFAULT_DISPLAY: EGLNativeDisplayType = null_mut();

const EGL_SURFACE_TYPE: EGLint = 0x3033;
const EGL_WINDOW_BIT: EGLint = 0x0004;
const EGL_RENDERABLE_TYPE: EGLint = 0x3040;
const EGL_OPENGL_ES3_BIT: EGLint = 0x0040;
const EGL_RED_SIZE: EGLint = 0x3024;
const EGL_GREEN_SIZE: EGLint = 0x3023;
const EGL_BLUE_SIZE: EGLint = 0x3022;
const EGL_DEPTH_SIZE: EGLint = 0x3025;
const EGL_NONE: EGLint = 0x3038;
const EGL_CONTEXT_CLIENT_VERSION: EGLint = 0x3098;
const EGL_WIDTH: EGLint = 0x3057;
const EGL_HEIGHT: EGLint = 0x3056;

pub const EGL_BAD_SURFACE: EGLint = 0x300D;
pub const EGL_BAD_NATIVE_WINDOW: EGLint = 0x300B;
pub const EGL_CONTEXT_LOST: EGLint = 0x300E;

#[link(name = "EGL")]
extern "C" {
    fn eglGetDisplay(display_id: EGLNativeDisplayType) -> EGLDisplay;
    fn eglInitialize(dpy: EGLDisplay, major: *mut EGLint, minor: *mut EGLint) -> EGLBoolean;
    fn eglTerminate(dpy: EGLDisplay) -> EGLBoolean;
    fn eglChooseConfig(
        dpy: EGLDisplay,
        attrib_list: *const EGLint,
        configs: *mut EGLConfig,
        config_size: EGLint,
        num_config: *mut EGLint,
    ) -> EGLBoolean;
    fn eglCreateContext(dpy: EGLDisplay, config: EGLConfig, share_context: EGLContext, attrib_list: *const EGLint) -> EGLContext;
    fn eglCreateWindowSurface(
        dpy: EGLDisplay,
        config: EGLConfig,
        win: EGLNativeWindowType,
        attrib_list: *const EGLint,
    ) -> EGLSurface;
    fn eglMakeCurrent(dpy: EGLDisplay, draw: EGLSurface, read: EGLSurface, ctx: EGLContext) -> EGLBoolean;
    fn eglSwapBuffers(dpy: EGLDisplay, surface: EGLSurface) -> EGLBoolean;
    fn eglDestroySurface(dpy: EGLDisplay, surface: EGLSurface) -> EGLBoolean;
    fn eglDestroyContext(dpy: EGLDisplay, ctx: EGLContext) -> EGLBoolean;
    fn eglQuerySurface(dpy: EGLDisplay, surface: EGLSurface, attribute: EGLint, value: *mut EGLint) -> EGLBoolean;
    fn eglSwapInterval(dpy: EGLDisplay, interval: EGLint) -> EGLBoolean;
    fn eglGetError() -> EGLint;
}

/// One display, one OpenGL ES 3 context, and (while the app is visible) one window surface. The context
/// outlives the surface, so textures and buffers survive the app going to the background.
pub struct Egl {
    display: EGLDisplay,
    config: EGLConfig,
    context: EGLContext,
    surface: EGLSurface,
}

impl Egl {
    pub fn new() -> Result<Egl, String> {
        unsafe {
            let display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
            if display == EGL_NO_DISPLAY {
                return Err("eglGetDisplay returned no display".to_string());
            }
            let mut major: EGLint = 0;
            let mut minor: EGLint = 0;
            if eglInitialize(display, &mut major as *mut EGLint, &mut minor as *mut EGLint) == 0 {
                return Err(format!("eglInitialize failed (0x{:x})", eglGetError()));
            }
            let mut config: EGLConfig = null_mut();
            let mut found = false;
            for depth in [24, 16] {
                let attribs: [EGLint; 15] = [
                    EGL_RENDERABLE_TYPE,
                    EGL_OPENGL_ES3_BIT,
                    EGL_SURFACE_TYPE,
                    EGL_WINDOW_BIT,
                    EGL_RED_SIZE,
                    8,
                    EGL_GREEN_SIZE,
                    8,
                    EGL_BLUE_SIZE,
                    8,
                    EGL_DEPTH_SIZE,
                    depth,
                    EGL_NONE,
                    EGL_NONE,
                    EGL_NONE,
                ];
                let mut count: EGLint = 0;
                if eglChooseConfig(display, attribs.as_ptr(), &mut config as *mut EGLConfig, 1, &mut count as *mut EGLint) != 0
                    && count > 0
                {
                    found = true;
                    break;
                }
            }
            if !found {
                return Err(format!("no OpenGL ES 3 window config (0x{:x})", eglGetError()));
            }
            let ctx_attribs: [EGLint; 3] = [EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE];
            let context = eglCreateContext(display, config, EGL_NO_CONTEXT, ctx_attribs.as_ptr());
            if context == EGL_NO_CONTEXT {
                return Err(format!("eglCreateContext failed (0x{:x})", eglGetError()));
            }
            crate::logi!("EGL {}.{} ready", major, minor);
            Ok(Egl { display, config, context, surface: EGL_NO_SURFACE })
        }
    }

    /// Creates the window surface for `window` (an `ANativeWindow*`) and makes the context current.
    pub fn attach_window(&mut self, window: *mut c_void) -> Result<(), String> {
        unsafe {
            self.detach_window();
            let surface = eglCreateWindowSurface(self.display, self.config, window, null());
            if surface == EGL_NO_SURFACE {
                return Err(format!("eglCreateWindowSurface failed (0x{:x})", eglGetError()));
            }
            if eglMakeCurrent(self.display, surface, surface, self.context) == 0 {
                let code = eglGetError();
                eglDestroySurface(self.display, surface);
                return Err(format!("eglMakeCurrent failed (0x{:x})", code));
            }
            eglSwapInterval(self.display, 1);
            self.surface = surface;
            Ok(())
        }
    }

    /// Releases the window surface (the window is going away); the context stays alive.
    pub fn detach_window(&mut self) {
        unsafe {
            if self.surface != EGL_NO_SURFACE {
                eglMakeCurrent(self.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
                eglDestroySurface(self.display, self.surface);
                self.surface = EGL_NO_SURFACE;
            }
        }
    }

    pub fn has_surface(&self) -> bool {
        self.surface != EGL_NO_SURFACE
    }

    /// Current surface size in pixels.
    pub fn size(&self) -> (i32, i32) {
        let mut w: EGLint = 0;
        let mut h: EGLint = 0;
        unsafe {
            eglQuerySurface(self.display, self.surface, EGL_WIDTH, &mut w as *mut EGLint);
            eglQuerySurface(self.display, self.surface, EGL_HEIGHT, &mut h as *mut EGLint);
        }
        (w, h)
    }

    /// Shows the frame. On failure returns the EGL error code.
    pub fn swap(&self) -> Result<(), i32> {
        unsafe {
            if eglSwapBuffers(self.display, self.surface) == 0 {
                Err(eglGetError())
            } else {
                Ok(())
            }
        }
    }
}

impl Drop for Egl {
    fn drop(&mut self) {
        unsafe {
            eglMakeCurrent(self.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            if self.surface != EGL_NO_SURFACE {
                eglDestroySurface(self.display, self.surface);
            }
            if self.context != EGL_NO_CONTEXT {
                eglDestroyContext(self.display, self.context);
            }
            eglTerminate(self.display);
        }
    }
}
