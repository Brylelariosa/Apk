//! The Android shell: lifecycle, the window / GL context, touch events and the frame loop. Everything
//! interesting happens in `ui::app::App`; this file only connects it to the system.

mod egl;

use std::os::raw::c_void;
use std::path::PathBuf;
use std::time::{Duration, Instant};

use android_activity::input::{InputEvent, KeyAction, Keycode, MotionAction};
use android_activity::{AndroidApp, InputStatus, MainEvent, PollEvent};

use crate::render::Renderer;
use crate::ui::app::App;
use egl::Egl;

struct Shell {
    app: App,
    android: AndroidApp,
    data_dir: PathBuf,
    egl: Option<Egl>,
    renderer: Option<Renderer>,
    window_ready: bool,
    needs_reinit: bool,
    last_frame: Instant,
    surface_size: (i32, i32),
    back_consumed: bool,
}

/// Records a panic where the main menu can show it on the next start (nobody has a debugger on a phone).
fn install_panic_hook(dir: PathBuf) {
    std::panic::set_hook(Box::new(move |info| {
        let thread = std::thread::current();
        let name = thread.name().unwrap_or("unnamed").to_string();
        let message = if let Some(s) = info.payload().downcast_ref::<&str>() {
            s.to_string()
        } else if let Some(s) = info.payload().downcast_ref::<String>() {
            s.clone()
        } else {
            "panic".to_string()
        };
        let location = match info.location() {
            Some(l) => format!("{}:{}", l.file(), l.line()),
            None => "unknown location".to_string(),
        };
        let text = format!("THREAD {}\n{}\nAT {}\n", name, message, location);
        crate::loge!("PANIC {}", text);
        let _ = std::fs::write(dir.join("last_panic.txt"), &text);
    }));
}

impl Shell {
    fn new(app: App, android: AndroidApp, data_dir: PathBuf) -> Shell {
        Shell {
            app,
            android,
            data_dir,
            egl: None,
            renderer: None,
            window_ready: false,
            needs_reinit: false,
            last_frame: Instant::now(),
            surface_size: (0, 0),
            back_consumed: false,
        }
    }

    /// Logs a setup failure and leaves it where the main menu can show it on the next start.
    fn report_fatal(&mut self, what: &str) {
        crate::loge!("{}", what);
        let _ = std::fs::write(self.data_dir.join("last_panic.txt"), format!("SETUP FAILED\n{}\n", what));
    }

    /// (Re)creates the surface for the current native window and, if needed, the context and renderer.
    fn init_window(&mut self) {
        let window = match self.android.native_window() {
            Some(w) => w,
            None => return,
        };
        let ptr = window.ptr().as_ptr() as *mut c_void;
        if self.egl.is_none() {
            match Egl::new() {
                Ok(e) => self.egl = Some(e),
                Err(err) => {
                    self.report_fatal(&format!("EGL setup failed: {}", err));
                    return;
                }
            }
        }
        let attached = match self.egl.as_mut() {
            Some(egl) => egl.attach_window(ptr),
            None => return,
        };
        if let Err(err) = attached {
            self.report_fatal(&format!("window attach failed: {}", err));
            return;
        }
        if self.renderer.is_none() {
            match Renderer::new() {
                Ok(r) => self.renderer = Some(r),
                Err(err) => {
                    self.report_fatal(&format!("renderer setup failed: {}", err));
                    return;
                }
            }
        }
        if let Some(egl) = self.egl.as_ref() {
            let (w, h) = egl.size();
            if w > 0 && h > 0 {
                self.app.resize(w as f32, h as f32);
                self.surface_size = (w, h);
            }
        }
        self.window_ready = true;
        self.needs_reinit = false;
        self.last_frame = Instant::now();
    }

    fn term_window(&mut self) {
        self.window_ready = false;
        if let Some(egl) = self.egl.as_mut() {
            egl.detach_window();
        }
    }

    /// The GL context died (rare): start over with a fresh one and re-upload every mesh.
    fn reset_gl(&mut self) {
        crate::logw!("GL context lost: rebuilding");
        if let Some(r) = self.renderer.as_mut() {
            r.forget_gpu_objects();
        }
        self.renderer = None;
        self.egl = None;
        self.window_ready = false;
        if let Some(e) = self.app.engine.as_mut() {
            e.manager.invalidate_all_meshes();
        }
        self.needs_reinit = true;
    }

    fn handle_motion(&mut self, m: &android_activity::input::MotionEvent<'_>) {
        match m.action() {
            MotionAction::Down | MotionAction::PointerDown => {
                let p = m.pointer_at_index(m.pointer_index());
                self.app.touch_down(p.pointer_id(), p.x(), p.y());
            }
            MotionAction::Move => {
                for p in m.pointers() {
                    self.app.touch_move(p.pointer_id(), p.x(), p.y());
                }
            }
            MotionAction::Up | MotionAction::PointerUp => {
                let p = m.pointer_at_index(m.pointer_index());
                self.app.touch_up(p.pointer_id(), false);
            }
            MotionAction::Cancel => {
                for p in m.pointers() {
                    self.app.touch_up(p.pointer_id(), true);
                }
            }
            _ => {}
        }
    }

    fn handle_event(&mut self, event: &InputEvent<'_>) -> InputStatus {
        match event {
            InputEvent::MotionEvent(m) => {
                self.handle_motion(m);
                InputStatus::Handled
            }
            InputEvent::KeyEvent(k) => {
                if k.key_code() == Keycode::Back {
                    match k.action() {
                        KeyAction::Down => {
                            self.back_consumed = self.app.back_pressed();
                            if self.back_consumed {
                                InputStatus::Handled
                            } else {
                                InputStatus::Unhandled
                            }
                        }
                        KeyAction::Up => {
                            let consumed = self.back_consumed;
                            self.back_consumed = false;
                            if consumed {
                                InputStatus::Handled
                            } else {
                                InputStatus::Unhandled
                            }
                        }
                        _ => InputStatus::Unhandled,
                    }
                } else {
                    InputStatus::Unhandled
                }
            }
            _ => InputStatus::Unhandled,
        }
    }

    fn drain_input(&mut self) {
        let android = self.android.clone();
        let mut iter = match android.input_events_iter() {
            Ok(i) => i,
            Err(_) => return,
        };
        loop {
            let more = iter.next(|event| self.handle_event(event));
            if !more {
                break;
            }
        }
    }

    fn frame(&mut self) {
        if self.needs_reinit {
            self.init_window();
        }
        if !self.window_ready {
            return;
        }
        let (egl, renderer) = match (self.egl.as_ref(), self.renderer.as_mut()) {
            (Some(e), Some(r)) => (e, r),
            _ => return,
        };
        if !egl.has_surface() {
            return;
        }
        let (w, h) = egl.size();
        if w <= 0 || h <= 0 {
            return;
        }
        if (w, h) != self.surface_size {
            self.surface_size = (w, h);
            self.app.resize(w as f32, h as f32);
        }
        let now = Instant::now();
        let dt = now.duration_since(self.last_frame).as_secs_f32().min(0.1);
        self.last_frame = now;
        self.app.update(dt);
        renderer.render(&mut self.app, w, h, dt);
        let swapped = egl.swap();
        if let Err(code) = swapped {
            if code == egl::EGL_CONTEXT_LOST {
                self.reset_gl();
            } else if code == egl::EGL_BAD_SURFACE || code == egl::EGL_BAD_NATIVE_WINDOW {
                self.window_ready = false;
            } else {
                crate::logw!("eglSwapBuffers failed: 0x{:x}", code);
            }
        }
    }
}

/// The entry point called by `android-activity` on the app's own thread.
#[no_mangle]
fn android_main(app: AndroidApp) {
    let data_dir = match app.internal_data_path() {
        Some(p) => p,
        None => PathBuf::from("/data/data/com.voxelsandbox.game/files"),
    };
    let _ = std::fs::create_dir_all(&data_dir);
    install_panic_hook(data_dir.clone());
    crate::logi!("Voxel Sandbox (Rust) starting, data in {:?}", data_dir);

    let mut shell = Shell::new(App::new(data_dir.clone()), app.clone(), data_dir);
    let mut quit = false;
    while !quit {
        let timeout = if shell.window_ready { Duration::from_millis(0) } else { Duration::from_millis(100) };
        app.poll_events(Some(timeout), |event| {
            if let PollEvent::Main(main_event) = event {
                match main_event {
                    MainEvent::InitWindow { .. } => shell.init_window(),
                    MainEvent::TerminateWindow { .. } => shell.term_window(),
                    MainEvent::Pause { .. } => shell.app.on_background(),
                    MainEvent::Destroy { .. } => quit = true,
                    _ => {}
                }
            }
        });
        shell.drain_input();
        shell.frame();
    }
    crate::logi!("Voxel Sandbox shutting down");
}
