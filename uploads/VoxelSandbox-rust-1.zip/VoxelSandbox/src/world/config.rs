//! Sizing constants of the voxel world (identical to the v15 game).

pub const CHUNK_SIZE: i32 = 16;
pub const SECTION_HEIGHT: i32 = 16;
pub const SECTIONS: usize = 16;
pub const WORLD_HEIGHT: i32 = 256;
pub const SEA_LEVEL: i32 = 64;
pub const SECTION_VOLUME: usize = 4096;
pub const BYTES_PER_CHUNK: usize = 65536;
pub const MAX_INTERACT_REACH: f32 = 6.0;
/// Falling below this Y puts the player back above the terrain.
pub const VOID_Y: f32 = -16.0;
