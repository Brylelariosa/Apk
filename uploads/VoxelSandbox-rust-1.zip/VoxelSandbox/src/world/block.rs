//! The block registry: ids, behaviour flags and texture layers. Ids match the v15 game, so saved
//! worlds and the creative catalogue keep their meaning.

use crate::tex::cells;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
#[repr(u8)]
pub enum Block {
    Air = 0,
    Grass = 1,
    Dirt = 2,
    Stone = 3,
    Sand = 4,
    Wood = 5,
    Leaves = 6,
    CoalOre = 7,
    Water = 8,
    BirchWood = 9,
    BirchLeaves = 10,
    SpruceWood = 11,
    SpruceLeaves = 12,
    Snow = 13,
    Gravel = 14,
    Sandstone = 15,
    DryGrass = 16,
    TallGrass = 17,
    Poppy = 18,
    Dandelion = 19,
    DeadBush = 20,
    Cactus = 21,
    LilyPad = 22,
    SwampGrass = 23,
    Seagrass = 24,
    DeepStone = 25,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum Face {
    Top = 0,
    Bottom = 1,
    North = 2,
    South = 3,
    East = 4,
    West = 5,
}

impl Face {
    pub const ALL: [Face; 6] = [Face::Top, Face::Bottom, Face::North, Face::South, Face::East, Face::West];

    pub fn dx(self) -> i32 {
        match self {
            Face::East => 1,
            Face::West => -1,
            _ => 0,
        }
    }

    pub fn dy(self) -> i32 {
        match self {
            Face::Top => 1,
            Face::Bottom => -1,
            _ => 0,
        }
    }

    pub fn dz(self) -> i32 {
        match self {
            Face::South => 1,
            Face::North => -1,
            _ => 0,
        }
    }
}

pub struct BlockInfo {
    pub id: u8,
    pub name: &'static str,
    pub solid: bool,
    pub opaque: bool,
    pub breakable: bool,
    pub top: i32,
    pub side: i32,
    pub bottom: i32,
    /// Foliage: texture has see-through holes (alpha-tested), does not hide neighbours' faces.
    pub cutout: bool,
    /// Cross-shaped decoration; walk-through, broken instantly, replaced when something is placed.
    pub plant: bool,
    /// A plant that is one flat quad at the bottom of its cell (lily pad).
    pub flat: bool,
}

const fn info(
    id: u8,
    name: &'static str,
    solid: bool,
    opaque: bool,
    breakable: bool,
    top: i32,
    side: i32,
    bottom: i32,
    cutout: bool,
    plant: bool,
    flat: bool,
) -> BlockInfo {
    BlockInfo { id, name, solid, opaque, breakable, top, side, bottom, cutout, plant, flat }
}

const BLOCK_DEFS: [BlockInfo; 26] = [
    info(0, "Air", false, false, false, -1, -1, -1, false, false, false),
    info(1, "Grass", true, true, true, cells::GRASS_TOP, cells::GRASS_SIDE, cells::DIRT, false, false, false),
    info(2, "Dirt", true, true, true, cells::DIRT, cells::DIRT, cells::DIRT, false, false, false),
    info(3, "Stone", true, true, true, cells::STONE, cells::STONE, cells::STONE, false, false, false),
    info(4, "Sand", true, true, true, cells::SAND, cells::SAND, cells::SAND, false, false, false),
    info(5, "Oak Wood", true, true, true, cells::OAK_RINGS, cells::OAK_BARK, cells::OAK_RINGS, false, false, false),
    info(6, "Oak Leaves", true, false, true, cells::OAK_LEAVES, cells::OAK_LEAVES, cells::OAK_LEAVES, true, false, false),
    info(7, "Coal Ore", true, true, true, cells::COAL_ORE, cells::COAL_ORE, cells::COAL_ORE, false, false, false),
    info(8, "Water", false, false, false, cells::WATER, cells::WATER, cells::WATER, false, false, false),
    info(9, "Birch Wood", true, true, true, cells::BIRCH_RINGS, cells::BIRCH_BARK, cells::BIRCH_RINGS, false, false, false),
    info(10, "Birch Leaves", true, false, true, cells::BIRCH_LEAVES, cells::BIRCH_LEAVES, cells::BIRCH_LEAVES, true, false, false),
    info(11, "Spruce Wood", true, true, true, cells::SPRUCE_RINGS, cells::SPRUCE_BARK, cells::SPRUCE_RINGS, false, false, false),
    info(12, "Spruce Leaves", true, false, true, cells::SPRUCE_LEAVES, cells::SPRUCE_LEAVES, cells::SPRUCE_LEAVES, true, false, false),
    info(13, "Snow", true, true, true, cells::SNOW, cells::SNOW_SIDE, cells::DIRT, false, false, false),
    info(14, "Gravel", true, true, true, cells::GRAVEL, cells::GRAVEL, cells::GRAVEL, false, false, false),
    info(15, "Sandstone", true, true, true, cells::SANDSTONE_TOP, cells::SANDSTONE_SIDE, cells::SANDSTONE_TOP, false, false, false),
    info(16, "Dry Grass", true, true, true, cells::DRY_GRASS_TOP, cells::DRY_GRASS_SIDE, cells::DIRT, false, false, false),
    info(17, "Tall Grass", false, false, true, cells::TALL_GRASS, cells::TALL_GRASS, cells::TALL_GRASS, false, true, false),
    info(18, "Poppy", false, false, true, cells::POPPY, cells::POPPY, cells::POPPY, false, true, false),
    info(19, "Dandelion", false, false, true, cells::DANDELION, cells::DANDELION, cells::DANDELION, false, true, false),
    info(20, "Dead Bush", false, false, true, cells::DEAD_BUSH, cells::DEAD_BUSH, cells::DEAD_BUSH, false, true, false),
    info(21, "Cactus", true, true, true, cells::CACTUS_TOP, cells::CACTUS_SIDE, cells::CACTUS_TOP, false, false, false),
    info(22, "Lily Pad", false, false, true, cells::LILY_PAD, cells::LILY_PAD, cells::LILY_PAD, false, true, true),
    info(23, "Swamp Grass", true, true, true, cells::SWAMP_GRASS_TOP, cells::SWAMP_GRASS_SIDE, cells::DIRT, false, false, false),
    info(24, "Seagrass", false, false, true, cells::SEAGRASS_A, cells::SEAGRASS_A, cells::SEAGRASS_A, false, true, false),
    info(25, "Deep Stone", true, true, true, cells::DEEP_STONE, cells::DEEP_STONE, cells::DEEP_STONE, false, false, false),
];

static BLOCKS: [BlockInfo; 26] = BLOCK_DEFS;

pub const ALL_BLOCKS: [Block; 26] = [
    Block::Air,
    Block::Grass,
    Block::Dirt,
    Block::Stone,
    Block::Sand,
    Block::Wood,
    Block::Leaves,
    Block::CoalOre,
    Block::Water,
    Block::BirchWood,
    Block::BirchLeaves,
    Block::SpruceWood,
    Block::SpruceLeaves,
    Block::Snow,
    Block::Gravel,
    Block::Sandstone,
    Block::DryGrass,
    Block::TallGrass,
    Block::Poppy,
    Block::Dandelion,
    Block::DeadBush,
    Block::Cactus,
    Block::LilyPad,
    Block::SwampGrass,
    Block::Seagrass,
    Block::DeepStone,
];

/// Block ids are below this; per-id tables use it so a corrupt byte can never index out of bounds.
pub const TABLE_SIZE: usize = 32;

const fn opaque_table() -> [bool; TABLE_SIZE] {
    let mut t = [false; TABLE_SIZE];
    let mut i = 0;
    while i < BLOCK_DEFS.len() {
        t[BLOCK_DEFS[i].id as usize] = BLOCK_DEFS[i].opaque;
        i += 1;
    }
    t
}

const fn solid_table() -> [bool; TABLE_SIZE] {
    let mut t = [false; TABLE_SIZE];
    let mut i = 0;
    while i < BLOCK_DEFS.len() {
        t[BLOCK_DEFS[i].id as usize] = BLOCK_DEFS[i].solid;
        i += 1;
    }
    t
}

const fn cutout_table() -> [bool; TABLE_SIZE] {
    let mut t = [false; TABLE_SIZE];
    let mut i = 0;
    while i < BLOCK_DEFS.len() {
        t[BLOCK_DEFS[i].id as usize] = BLOCK_DEFS[i].cutout;
        i += 1;
    }
    t
}

/// Per-id "hides the face behind it".
pub static OPAQUE_BY_ID: [bool; TABLE_SIZE] = opaque_table();
/// Per-id "blocks movement" (leaves count; plants and water do not).
pub static SOLID_BY_ID: [bool; TABLE_SIZE] = solid_table();
/// Per-id foliage flag.
pub static CUTOUT_BY_ID: [bool; TABLE_SIZE] = cutout_table();

impl Block {
    /// Block for a raw block byte (the water fill level lives in the top three bits and is ignored).
    pub fn from_raw(raw: u8) -> Block {
        let i = (raw & 31) as usize;
        if i < ALL_BLOCKS.len() {
            ALL_BLOCKS[i]
        } else {
            Block::Air
        }
    }

    pub fn id(self) -> u8 {
        self as u8
    }

    pub fn info(self) -> &'static BlockInfo {
        &BLOCKS[self as usize]
    }

    pub fn name(self) -> &'static str {
        self.info().name
    }

    pub fn solid(self) -> bool {
        self.info().solid
    }

    pub fn opaque(self) -> bool {
        self.info().opaque
    }

    pub fn breakable(self) -> bool {
        self.info().breakable
    }

    pub fn cutout(self) -> bool {
        self.info().cutout
    }

    pub fn plant(self) -> bool {
        self.info().plant
    }

    pub fn flat(self) -> bool {
        self.info().flat
    }

    /// True if a block being placed may overwrite this cell (air, water or a plant).
    pub fn replaceable(self) -> bool {
        self == Block::Air || self == Block::Water || self.plant()
    }

    /// True for plain water and a water-logged plant (seagrass).
    pub fn holds_water(self) -> bool {
        self == Block::Water || self == Block::Seagrass
    }

    pub fn is_leaves(self) -> bool {
        self == Block::Leaves || self == Block::BirchLeaves || self == Block::SpruceLeaves
    }

    pub fn is_log(self) -> bool {
        self == Block::Wood || self == Block::BirchWood || self == Block::SpruceWood
    }

    pub fn cell_for(self, face: Face) -> i32 {
        let i = self.info();
        match face {
            Face::Top => i.top,
            Face::Bottom => i.bottom,
            _ => i.side,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ids_are_contiguous_and_round_trip() {
        for (i, b) in ALL_BLOCKS.iter().enumerate() {
            assert_eq!(b.id() as usize, i);
            assert_eq!(BLOCK_DEFS[i].id as usize, i);
            assert_eq!(Block::from_raw(b.id()), *b);
        }
    }

    #[test]
    fn water_fill_bits_do_not_change_the_block() {
        assert_eq!(Block::from_raw(Block::Water.id() | (3 << 5)), Block::Water);
    }

    #[test]
    fn tables_match_flags() {
        assert!(OPAQUE_BY_ID[Block::Stone.id() as usize]);
        assert!(!OPAQUE_BY_ID[Block::Leaves.id() as usize]);
        assert!(SOLID_BY_ID[Block::Leaves.id() as usize]);
        assert!(!SOLID_BY_ID[Block::Water.id() as usize]);
    }
}
