//! Spreads and drains water. A source is permanent; flowing water exists only while a neighbour feeds it,
//! falls straight down, and thins by one per block sideways.

use std::collections::{HashSet, VecDeque};

use super::block::Block;
use super::config::WORLD_HEIGHT;
use super::fluid::{self, SOURCE};
use super::world::World;

const TICK_SECONDS: f32 = 0.2;
const MAX_UPDATES_PER_TICK: usize = 256;
const MAX_PENDING: usize = 40000;

type Cell = (i32, i32, i32);

pub struct FluidSim {
    queue: VecDeque<Cell>,
    set: HashSet<Cell>,
    clock: f32,
}

fn water_among(world: &World, x: i32, y: i32, z: i32) -> bool {
    fluid::amount_of(world.get_raw(x, y, z)) > 0
        || fluid::amount_of(world.get_raw(x + 1, y, z)) > 0
        || fluid::amount_of(world.get_raw(x - 1, y, z)) > 0
        || fluid::amount_of(world.get_raw(x, y, z + 1)) > 0
        || fluid::amount_of(world.get_raw(x, y, z - 1)) > 0
        || fluid::amount_of(world.get_raw(x, y + 1, z)) > 0
        || fluid::amount_of(world.get_raw(x, y - 1, z)) > 0
}

fn can_fall(world: &World, x: i32, y: i32, z: i32) -> bool {
    if y <= 0 {
        return false;
    }
    let below = world.get_raw(x, y - 1, z);
    if fluid::amount_of(below) == SOURCE {
        return false;
    }
    Block::from_raw(below).replaceable()
}

fn side_supply(world: &World, nx: i32, y: i32, nz: i32) -> i32 {
    let mut amount = fluid::amount_of(world.get_raw(nx, y, nz));
    if amount == 0 {
        return 0;
    }
    if can_fall(world, nx, y, nz) {
        return 0; // that water is busy falling
    }
    if amount != SOURCE && fluid::amount_of(world.get_raw(nx, y + 1, nz)) > 0 {
        amount = SOURCE;
    }
    amount - 1
}

fn target_amount(world: &World, x: i32, y: i32, z: i32) -> i32 {
    if fluid::amount_of(world.get_raw(x, y + 1, z)) > 0 {
        return 7;
    }
    let mut best = side_supply(world, x + 1, y, z);
    let b = side_supply(world, x - 1, y, z);
    if b > best {
        best = b;
    }
    let c = side_supply(world, x, y, z + 1);
    if c > best {
        best = c;
    }
    let d = side_supply(world, x, y, z - 1);
    if d > best {
        best = d;
    }
    best
}

impl FluidSim {
    pub fn new() -> FluidSim {
        FluidSim { queue: VecDeque::new(), set: HashSet::new(), clock: 0.0 }
    }

    pub fn clear(&mut self) {
        self.queue.clear();
        self.set.clear();
        self.clock = 0.0;
    }

    fn schedule(&mut self, x: i32, y: i32, z: i32) {
        if y < 0 || y >= WORLD_HEIGHT {
            return;
        }
        if self.queue.len() >= MAX_PENDING {
            return;
        }
        if self.set.insert((x, y, z)) {
            self.queue.push_back((x, y, z));
        }
    }

    /// Call after any block change (player edit): wakes the water around it.
    pub fn on_block_changed(&mut self, world: &World, x: i32, y: i32, z: i32) {
        if !water_among(world, x, y, z) {
            return;
        }
        self.schedule(x, y, z);
        self.schedule(x + 1, y, z);
        self.schedule(x - 1, y, z);
        self.schedule(x, y, z + 1);
        self.schedule(x, y, z - 1);
        self.schedule(x, y + 1, z);
        self.schedule(x, y - 1, z);
    }

    pub fn update(&mut self, world: &mut World, dt: f32) {
        if self.queue.is_empty() {
            self.clock = 0.0;
            return;
        }
        self.clock += dt;
        if self.clock < TICK_SECONDS {
            return;
        }
        self.clock = 0.0;
        let mut batch: Vec<Cell> = Vec::new();
        while batch.len() < MAX_UPDATES_PER_TICK {
            match self.queue.pop_front() {
                Some(c) => {
                    self.set.remove(&c);
                    batch.push(c);
                }
                None => break,
            }
        }
        for (x, y, z) in batch {
            self.update_cell(world, x, y, z);
        }
    }

    fn update_cell(&mut self, world: &mut World, x: i32, y: i32, z: i32) {
        let raw = world.get_raw(x, y, z);
        let current = fluid::amount_of(raw);
        if current == SOURCE {
            return; // a source never changes by itself
        }
        if current == 0 && !Block::from_raw(raw).replaceable() {
            return; // solid blocks hold no water
        }
        let target = target_amount(world, x, y, z);
        if target == current {
            return;
        }
        let new_raw = if target == 0 { 0 } else { fluid::raw_for(target) };
        if !world.set_raw(x, y, z, new_raw, false) {
            return;
        }
        self.schedule(x + 1, y, z);
        self.schedule(x - 1, y, z);
        self.schedule(x, y, z + 1);
        self.schedule(x, y, z - 1);
        self.schedule(x, y + 1, z);
        self.schedule(x, y - 1, z);
    }
}

impl Default for FluidSim {
    fn default() -> FluidSim {
        FluidSim::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::chunk::ChunkData;
    use crate::world::pos::ChunkPos;

    #[test]
    fn water_spreads_over_a_flat_floor_and_stops() {
        let mut world = World::new();
        let mut c = ChunkData::new();
        for x in 0..16 {
            for z in 0..16 {
                c.set(x, 10, z, Block::Stone);
            }
        }
        world.insert(ChunkPos::new(0, 0), c, false);
        world.set_raw(8, 11, 8, fluid::raw_for(SOURCE), false);
        let mut sim = FluidSim::new();
        sim.on_block_changed(&world, 8, 11, 8);
        for _ in 0..200 {
            sim.update(&mut world, 0.25);
        }
        assert!(fluid::amount_of(world.get_raw(9, 11, 8)) > 0);
        assert_eq!(fluid::amount_of(world.get_raw(8, 11, 8)), SOURCE);
        assert_eq!(fluid::amount_of(world.get_raw(8 + 8, 11, 8)), 0);
    }
}
