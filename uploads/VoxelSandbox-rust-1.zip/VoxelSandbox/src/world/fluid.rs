//! How full a cell of water is, packed into the spare top three bits of the block byte:
//! 0 = a source (full, permanent), 1..7 = flowing water of amount `8 - bits`.

use super::block::Block;

/// The amount a source block counts as.
pub const SOURCE: i32 = 8;

/// 0 if `raw` is not water, `SOURCE` for a source (and a water-logged plant), else 1..7.
pub fn amount_of(raw: u8) -> i32 {
    let id = raw & 31;
    if id == Block::Seagrass as u8 {
        return SOURCE;
    }
    if id != Block::Water as u8 {
        return 0;
    }
    let bits = ((raw >> 5) & 7) as i32;
    if bits == 0 {
        SOURCE
    } else {
        8 - bits
    }
}

/// The block byte for a cell holding `amount` (1..8) of water.
pub fn raw_for(amount: i32) -> u8 {
    let water = Block::Water as u8;
    if amount >= SOURCE {
        water
    } else {
        water | (((8 - amount) as u8) << 5)
    }
}

/// Height of the water surface in its cell (0..1). A source sits a little below the top.
pub fn height_of(amount: i32) -> f32 {
    if amount >= SOURCE {
        0.875
    } else {
        amount as f32 * 0.125
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn amounts_round_trip() {
        assert_eq!(amount_of(raw_for(SOURCE)), SOURCE);
        for a in 1..8 {
            assert_eq!(amount_of(raw_for(a)), a);
        }
        assert_eq!(amount_of(Block::Stone as u8), 0);
        assert_eq!(amount_of(Block::Seagrass as u8), SOURCE);
    }
}
