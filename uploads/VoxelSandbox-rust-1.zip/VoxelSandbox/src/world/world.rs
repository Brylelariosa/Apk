//! The set of loaded chunks and block access in world coordinates.

use std::collections::HashMap;

use super::block::{Block, SOLID_BY_ID};
use super::chunk::ChunkData;
use super::config::WORLD_HEIGHT;
use super::pos::ChunkPos;

pub struct ChunkEntry {
    pub data: ChunkData,
    /// Changed by the player or the fluid simulation: must be kept and saved.
    pub edited: bool,
    /// Needs (re)meshing.
    pub dirty: bool,
    /// Dirty because of an edit: mesh with top priority.
    pub urgent: bool,
    /// A mesh job for this chunk is queued or running.
    pub in_flight: bool,
    /// Bumped on every change; a finished mesh carries the version it was built from.
    pub version: u64,
}

pub struct World {
    chunks: HashMap<ChunkPos, ChunkEntry>,
}

impl World {
    pub fn new() -> World {
        World { chunks: HashMap::new() }
    }

    pub fn len(&self) -> usize {
        self.chunks.len()
    }

    pub fn is_empty(&self) -> bool {
        self.chunks.is_empty()
    }

    pub fn contains(&self, pos: ChunkPos) -> bool {
        self.chunks.contains_key(&pos)
    }

    pub fn entry(&self, pos: ChunkPos) -> Option<&ChunkEntry> {
        self.chunks.get(&pos)
    }

    pub fn entry_mut(&mut self, pos: ChunkPos) -> Option<&mut ChunkEntry> {
        self.chunks.get_mut(&pos)
    }

    pub fn positions(&self) -> Vec<ChunkPos> {
        self.chunks.keys().copied().collect()
    }

    pub fn insert(&mut self, pos: ChunkPos, data: ChunkData, edited: bool) {
        self.chunks.insert(
            pos,
            ChunkEntry { data, edited, dirty: true, urgent: false, in_flight: false, version: 1 },
        );
    }

    pub fn remove(&mut self, pos: ChunkPos) -> Option<ChunkEntry> {
        self.chunks.remove(&pos)
    }

    pub fn iter(&self) -> impl Iterator<Item = (&ChunkPos, &ChunkEntry)> {
        self.chunks.iter()
    }

    /// The whole block byte at world (x, y, z): 0 (air) above, below and outside the loaded area.
    pub fn get_raw(&self, x: i32, y: i32, z: i32) -> u8 {
        if y < 0 || y >= WORLD_HEIGHT {
            return 0;
        }
        match self.chunks.get(&ChunkPos::of_block(x, z)) {
            Some(e) => e.data.get_raw(x.rem_euclid(16), y, z.rem_euclid(16)),
            None => 0,
        }
    }

    pub fn get_block(&self, x: i32, y: i32, z: i32) -> Block {
        Block::from_raw(self.get_raw(x, y, z))
    }

    /// Blocks movement. Cells in chunks that are not loaded count as solid, so nothing falls out of the
    /// world while the ground is still being generated.
    pub fn is_solid(&self, x: i32, y: i32, z: i32) -> bool {
        if y < 0 {
            return true;
        }
        if y >= WORLD_HEIGHT {
            return false;
        }
        match self.chunks.get(&ChunkPos::of_block(x, z)) {
            Some(e) => SOLID_BY_ID[(e.data.get_raw(x.rem_euclid(16), y, z.rem_euclid(16)) & 31) as usize],
            None => true,
        }
    }

    pub fn is_loaded_at(&self, x: i32, z: i32) -> bool {
        self.chunks.contains_key(&ChunkPos::of_block(x, z))
    }

    fn touch(&mut self, pos: ChunkPos, urgent: bool, edited: bool) {
        if let Some(e) = self.chunks.get_mut(&pos) {
            e.dirty = true;
            e.version += 1;
            if urgent {
                e.urgent = true;
            }
            if edited {
                e.edited = true;
            }
        }
    }

    /// Writes a block byte. Returns false when nothing changed (chunk not loaded, outside the world, same
    /// value). The chunk (and, on a border, its neighbours) is queued for re-meshing.
    pub fn set_raw(&mut self, x: i32, y: i32, z: i32, raw: u8, urgent: bool) -> bool {
        if y < 0 || y >= WORLD_HEIGHT {
            return false;
        }
        let pos = ChunkPos::of_block(x, z);
        let lx = x.rem_euclid(16);
        let lz = z.rem_euclid(16);
        match self.chunks.get_mut(&pos) {
            Some(e) => {
                if e.data.get_raw(lx, y, lz) == raw {
                    return false;
                }
                e.data.set_raw(lx, y, lz, raw);
            }
            None => return false,
        }
        let mut xs = vec![0];
        if lx == 0 {
            xs.push(-1);
        }
        if lx == 15 {
            xs.push(1);
        }
        let mut zs = vec![0];
        if lz == 0 {
            zs.push(-1);
        }
        if lz == 15 {
            zs.push(1);
        }
        for dz in zs.iter() {
            for dx in xs.iter() {
                let p = ChunkPos::new(pos.x + dx, pos.z + dz);
                self.touch(p, urgent, *dx == 0 && *dz == 0);
            }
        }
        true
    }

    pub fn set_block(&mut self, x: i32, y: i32, z: i32, block: Block, urgent: bool) -> bool {
        self.set_raw(x, y, z, block as u8, urgent)
    }

    /// Y of the top solid, non-foliage block of a column (from the stored height map), if the chunk is loaded.
    pub fn column_height(&self, x: i32, z: i32) -> Option<i32> {
        self.chunks
            .get(&ChunkPos::of_block(x, z))
            .map(|e| e.data.height_map[(z.rem_euclid(16) * 16 + x.rem_euclid(16)) as usize] as i32)
    }
}

impl Default for World {
    fn default() -> World {
        World::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn edits_mark_neighbours_on_borders() {
        let mut w = World::new();
        for dz in -1..=1 {
            for dx in -1..=1 {
                w.insert(ChunkPos::new(dx, dz), ChunkData::new(), false);
            }
        }
        for dz in -1..=1 {
            for dx in -1..=1 {
                if let Some(e) = w.entry_mut(ChunkPos::new(dx, dz)) {
                    e.dirty = false;
                }
            }
        }
        assert!(w.set_block(0, 10, 0, Block::Stone, true));
        assert!(w.entry(ChunkPos::new(0, 0)).unwrap().dirty);
        assert!(w.entry(ChunkPos::new(0, 0)).unwrap().edited);
        assert!(w.entry(ChunkPos::new(-1, 0)).unwrap().dirty);
        assert!(w.entry(ChunkPos::new(0, -1)).unwrap().dirty);
        assert!(w.entry(ChunkPos::new(-1, -1)).unwrap().dirty);
        assert!(!w.entry(ChunkPos::new(1, 1)).unwrap().dirty);
        assert!(!w.entry(ChunkPos::new(-1, 0)).unwrap().edited);
        assert_eq!(w.get_block(0, 10, 0), Block::Stone);
        assert!(!w.set_block(0, 10, 0, Block::Stone, true));
    }

    #[test]
    fn unloaded_chunks_are_solid_but_not_visible_blocks() {
        let w = World::new();
        assert!(w.is_solid(100, 70, 100));
        assert_eq!(w.get_block(100, 70, 100), Block::Air);
    }
}
