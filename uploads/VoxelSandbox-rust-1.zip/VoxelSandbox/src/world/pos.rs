//! Chunk-grid coordinates (one unit = one 16-block column).

use super::config::CHUNK_SIZE;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct ChunkPos {
    pub x: i32,
    pub z: i32,
}

impl ChunkPos {
    pub fn new(x: i32, z: i32) -> ChunkPos {
        ChunkPos { x, z }
    }

    /// The chunk that contains block column (wx, wz).
    pub fn of_block(wx: i32, wz: i32) -> ChunkPos {
        ChunkPos { x: wx.div_euclid(CHUNK_SIZE), z: wz.div_euclid(CHUNK_SIZE) }
    }

    pub fn from_world(wx: f32, wz: f32) -> ChunkPos {
        ChunkPos::of_block(wx.floor() as i32, wz.floor() as i32)
    }

    pub fn dist_sq(self, other: ChunkPos) -> i64 {
        let dx = (self.x - other.x) as i64;
        let dz = (self.z - other.z) as i64;
        dx * dx + dz * dz
    }

    pub fn origin_x(self) -> i32 {
        self.x * CHUNK_SIZE
    }

    pub fn origin_z(self) -> i32 {
        self.z * CHUNK_SIZE
    }
}
