//! Keeps the world around the player alive: generates and meshes chunks on worker threads, unloads far
//! ones (keeping edited chunks), and hands finished meshes to the renderer.

use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap, HashSet};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Condvar, Mutex};
use std::thread::JoinHandle;

use super::chunk::ChunkData;
use super::pos::ChunkPos;
use super::world::World;
use crate::gen::terrain::TerrainGenerator;
use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
use crate::mesh::mesher::{build_chunk_mesh, MeshContext, MeshInput};
use crate::mesh::ChunkMeshData;

enum Job {
    Generate(ChunkPos),
    Mesh { pos: ChunkPos, version: u64, input: MeshInput },
}

enum JobResult {
    Generated(ChunkPos, ChunkData),
    Meshed { pos: ChunkPos, version: u64, mesh: ChunkMeshData },
}

struct Prio {
    prio: i64,
    seq: u64,
    job: Job,
}

impl PartialEq for Prio {
    fn eq(&self, other: &Prio) -> bool {
        self.prio == other.prio && self.seq == other.seq
    }
}

impl Eq for Prio {}

impl PartialOrd for Prio {
    fn partial_cmp(&self, other: &Prio) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Prio {
    /// Reversed, so the `BinaryHeap` (a max-heap) pops the smallest priority first.
    fn cmp(&self, other: &Prio) -> Ordering {
        other.prio.cmp(&self.prio).then(other.seq.cmp(&self.seq))
    }
}

struct QueueState {
    heap: BinaryHeap<Prio>,
    shutdown: bool,
}

type Shared = Arc<(Mutex<QueueState>, Condvar)>;

fn lock_state(shared: &Shared) -> std::sync::MutexGuard<'_, QueueState> {
    match shared.0.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    }
}

fn worker_loop(shared: Shared, tx: Sender<JobResult>, gen: Arc<TerrainGenerator>, ctx: Arc<MeshContext>) {
    loop {
        let job = {
            let mut st = lock_state(&shared);
            loop {
                if st.shutdown {
                    return;
                }
                if let Some(p) = st.heap.pop() {
                    break p.job;
                }
                st = match shared.1.wait(st) {
                    Ok(g) => g,
                    Err(p) => p.into_inner(),
                };
            }
        };
        let result = match job {
            Job::Generate(pos) => {
                let data = match catch_unwind(AssertUnwindSafe(|| gen.generate(pos))) {
                    Ok(d) => d,
                    Err(_) => {
                        crate::loge!("terrain generation panicked at {:?}", pos);
                        ChunkData::new()
                    }
                };
                JobResult::Generated(pos, data)
            }
            Job::Mesh { pos, version, input } => {
                let mesh = match catch_unwind(AssertUnwindSafe(|| build_chunk_mesh(&input, &ctx))) {
                    Ok(m) => m,
                    Err(_) => {
                        crate::loge!("meshing panicked at {:?}", pos);
                        ChunkMeshData::empty()
                    }
                };
                JobResult::Meshed { pos, version, mesh }
            }
        };
        if tx.send(result).is_err() {
            return;
        }
    }
}

struct JobPool {
    shared: Shared,
    results: Receiver<JobResult>,
    seq: u64,
    workers: Vec<JoinHandle<()>>,
}

impl JobPool {
    fn new(threads: usize, gen: Arc<TerrainGenerator>, ctx: Arc<MeshContext>) -> JobPool {
        let shared: Shared = Arc::new((Mutex::new(QueueState { heap: BinaryHeap::new(), shutdown: false }), Condvar::new()));
        let (tx, rx) = channel();
        let mut workers = Vec::new();
        for i in 0..threads {
            let s = shared.clone();
            let t = tx.clone();
            let g = gen.clone();
            let c = ctx.clone();
            let builder = std::thread::Builder::new().name(format!("vs-worker-{}", i));
            match builder.spawn(move || worker_loop(s, t, g, c)) {
                Ok(h) => workers.push(h),
                Err(e) => crate::loge!("could not start worker thread: {}", e),
            }
        }
        JobPool { shared, results: rx, seq: 0, workers }
    }

    fn submit(&mut self, prio: i64, job: Job) {
        self.seq += 1;
        let seq = self.seq;
        let mut st = lock_state(&self.shared);
        st.heap.push(Prio { prio, seq, job });
        drop(st);
        self.shared.1.notify_one();
    }
}

impl Drop for JobPool {
    fn drop(&mut self) {
        {
            let mut st = lock_state(&self.shared);
            st.shutdown = true;
            st.heap.clear();
        }
        self.shared.1.notify_all();
        for h in self.workers.drain(..) {
            let _ = h.join();
        }
    }
}

pub struct WorldManager {
    pub world: World,
    pub gen: Arc<TerrainGenerator>,
    pool: JobPool,
    /// Edited chunks that are currently out of range (kept so edits survive walking away).
    edited_store: HashMap<ChunkPos, ChunkData>,
    gen_pending: HashSet<ChunkPos>,
    meshed: HashSet<ChunkPos>,
    view_radius: i32,
    max_gen_pending: usize,
    max_mesh_in_flight: usize,
    mesh_in_flight: usize,
    uploads: Vec<(ChunkPos, ChunkMeshData)>,
    removed: Vec<ChunkPos>,
}

impl WorldManager {
    pub fn new(seed: i64, view_radius: i32) -> WorldManager {
        let gen = Arc::new(TerrainGenerator::new(seed));
        let ctx = Arc::new(MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        });
        let cores = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        let threads = cores.saturating_sub(1).max(1).min(3);
        let pool = JobPool::new(threads, gen.clone(), ctx);
        WorldManager {
            world: World::new(),
            gen,
            pool,
            edited_store: HashMap::new(),
            gen_pending: HashSet::new(),
            meshed: HashSet::new(),
            view_radius,
            max_gen_pending: threads * 4 + 8,
            max_mesh_in_flight: threads * 2 + 4,
            mesh_in_flight: 0,
            uploads: Vec::new(),
            removed: Vec::new(),
        }
    }

    pub fn view_radius(&self) -> i32 {
        self.view_radius
    }

    pub fn set_view_radius(&mut self, r: i32) {
        self.view_radius = r.max(2);
    }

    pub fn chunk_count(&self) -> usize {
        self.world.len()
    }

    pub fn meshed_count(&self) -> usize {
        self.meshed.len()
    }

    pub fn pending_count(&self) -> usize {
        self.gen_pending.len() + self.mesh_in_flight
    }

    /// Hands over meshes that finished since the last call (the renderer uploads them).
    pub fn take_uploads(&mut self) -> Vec<(ChunkPos, ChunkMeshData)> {
        std::mem::take(&mut self.uploads)
    }

    /// Chunks that were unloaded since the last call (the renderer frees their GPU meshes).
    pub fn take_removed(&mut self) -> Vec<ChunkPos> {
        std::mem::take(&mut self.removed)
    }

    /// Forgets every GPU mesh (after the GL context was lost): all chunks are re-meshed.
    pub fn invalidate_all_meshes(&mut self) {
        self.meshed.clear();
        let positions = self.world.positions();
        for p in positions {
            if let Some(e) = self.world.entry_mut(p) {
                e.dirty = true;
                e.version += 1;
            }
        }
    }

    /// True once every chunk within `radius` of `center` is loaded and has a mesh.
    pub fn area_ready(&self, center: ChunkPos, radius: i32) -> bool {
        for dz in -radius..=radius {
            for dx in -radius..=radius {
                if dx * dx + dz * dz > radius * radius {
                    continue;
                }
                let p = ChunkPos::new(center.x + dx, center.z + dz);
                if !self.world.contains(p) || !self.meshed.contains(&p) {
                    return false;
                }
            }
        }
        true
    }

    /// Edited chunks (loaded and stored) as `(position, serialized blocks)`, for saving.
    pub fn collect_edited(&self) -> Vec<(ChunkPos, Vec<u8>)> {
        let mut out = Vec::new();
        for (pos, e) in self.world.iter() {
            if e.edited {
                out.push((*pos, e.data.serialize()));
            }
        }
        for (pos, data) in self.edited_store.iter() {
            out.push((*pos, data.serialize()));
        }
        out
    }

    /// Chunks restored from a save; they replace generation when their area loads.
    pub fn import_edited(&mut self, chunks: Vec<(ChunkPos, ChunkData)>) {
        for (pos, data) in chunks {
            self.edited_store.insert(pos, data);
        }
    }

    pub fn has_edits(&self) -> bool {
        !self.edited_store.is_empty() || self.world.iter().any(|(_, e)| e.edited)
    }

    pub fn update(&mut self, center_x: f32, center_z: f32) {
        let center = ChunkPos::from_world(center_x, center_z);
        self.drain_results();
        self.unload_far(center);
        self.request_loads(center);
        self.request_meshes(center);
    }

    fn drain_results(&mut self) {
        loop {
            let r = match self.pool.results.try_recv() {
                Ok(r) => r,
                Err(_) => break,
            };
            match r {
                JobResult::Generated(pos, data) => {
                    self.gen_pending.remove(&pos);
                    if !self.world.contains(pos) {
                        self.world.insert(pos, data, false);
                    }
                }
                JobResult::Meshed { pos, version: _, mesh } => {
                    // the job is finished whether or not its chunk is still around
                    if self.mesh_in_flight > 0 {
                        self.mesh_in_flight -= 1;
                    }
                    if let Some(e) = self.world.entry_mut(pos) {
                        e.in_flight = false;
                        self.meshed.insert(pos);
                        self.uploads.push((pos, mesh));
                    }
                }
            }
        }
    }

    fn unload_far(&mut self, center: ChunkPos) {
        let keep = self.view_radius + 3;
        let keep_sq = (keep * keep) as i64;
        let far: Vec<ChunkPos> = self.world.iter().filter(|(p, _)| p.dist_sq(center) > keep_sq).map(|(p, _)| *p).collect();
        for pos in far {
            if let Some(entry) = self.world.remove(pos) {
                if entry.edited {
                    self.edited_store.insert(pos, entry.data);
                }
            }
            self.meshed.remove(&pos);
            self.removed.push(pos);
        }
    }

    fn request_loads(&mut self, center: ChunkPos) {
        // two rings beyond the meshed area: every chunk that gets meshed has all eight neighbours loaded
        let r = self.view_radius + 2;
        let r_sq = (r * r) as i64;
        let mut wanted: Vec<(i64, ChunkPos)> = Vec::new();
        for dz in -r..=r {
            for dx in -r..=r {
                let d = (dx * dx + dz * dz) as i64;
                if d > r_sq {
                    continue;
                }
                let p = ChunkPos::new(center.x + dx, center.z + dz);
                if self.world.contains(p) || self.gen_pending.contains(&p) {
                    continue;
                }
                wanted.push((d, p));
            }
        }
        wanted.sort_by_key(|w| w.0);
        for (d, p) in wanted {
            if let Some(data) = self.edited_store.remove(&p) {
                self.world.insert(p, data, true);
                continue;
            }
            if self.gen_pending.len() >= self.max_gen_pending {
                break;
            }
            self.gen_pending.insert(p);
            self.pool.submit(d, Job::Generate(p));
        }
    }

    fn neighbours_loaded(&self, pos: ChunkPos) -> bool {
        for dz in -1..=1 {
            for dx in -1..=1 {
                if !self.world.contains(ChunkPos::new(pos.x + dx, pos.z + dz)) {
                    return false;
                }
            }
        }
        true
    }

    fn request_meshes(&mut self, center: ChunkPos) {
        let r = self.view_radius;
        let r_sq = (r * r) as i64;
        let mut candidates: Vec<(i64, ChunkPos, bool)> = Vec::new();
        for (pos, e) in self.world.iter() {
            if !e.dirty || e.in_flight {
                continue;
            }
            let d = pos.dist_sq(center);
            if d > r_sq {
                continue;
            }
            candidates.push((if e.urgent { -1 } else { d }, *pos, e.urgent));
        }
        candidates.sort_by_key(|c| c.0);
        for (prio, pos, urgent) in candidates {
            if !urgent && self.mesh_in_flight >= self.max_mesh_in_flight {
                break;
            }
            if !self.neighbours_loaded(pos) {
                continue;
            }
            let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
            for dz in -1..=1 {
                for dx in -1..=1 {
                    let p = ChunkPos::new(pos.x + dx, pos.z + dz);
                    chunks[((dz + 1) * 3 + (dx + 1)) as usize] = self.world.entry(p).map(|e| e.data.clone());
                }
            }
            let version = match self.world.entry_mut(pos) {
                Some(e) => {
                    e.dirty = false;
                    e.urgent = false;
                    e.in_flight = true;
                    e.version
                }
                None => continue,
            };
            self.mesh_in_flight += 1;
            self.pool.submit(prio, Job::Mesh { pos, version, input: MeshInput { pos, chunks } });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    #[test]
    fn streaming_generates_and_meshes_the_area_around_the_player() {
        let mut m = WorldManager::new(4242, 3);
        let spawn = m.gen.find_spawn();
        let x = spawn.x as f32;
        let z = spawn.z as f32;
        let center = ChunkPos::from_world(x, z);
        let start = Instant::now();
        loop {
            m.update(x, z);
            if m.area_ready(center, 1) {
                break;
            }
            assert!(start.elapsed().as_secs() < 90, "the area around the spawn never became ready");
            std::thread::sleep(Duration::from_millis(5));
        }
        assert!(!m.take_uploads().is_empty());
        assert!(m.chunk_count() > 9);
    }

    #[test]
    fn far_chunks_are_unloaded_and_reported() {
        let mut m = WorldManager::new(99, 2);
        let start = Instant::now();
        while !m.area_ready(ChunkPos::new(0, 0), 1) {
            m.update(8.0, 8.0);
            assert!(start.elapsed().as_secs() < 90);
            std::thread::sleep(Duration::from_millis(5));
        }
        // walk far away: the old area must be dropped
        for _ in 0..200 {
            m.update(8000.0, 8000.0);
            std::thread::sleep(Duration::from_millis(2));
        }
        assert!(!m.world.contains(ChunkPos::new(0, 0)));
        assert!(!m.take_removed().is_empty());
    }
}
