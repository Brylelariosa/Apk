//! The block data of one 16 x 256 x 16 chunk column. Sections (16 layers each) are reference counted, so
//! a snapshot for a mesher thread is just a handful of pointer copies and edits copy only the section
//! they touch.

use std::sync::Arc;

use super::block::Block;
use super::config::*;

pub type Section = [u8; SECTION_VOLUME];

#[derive(Clone)]
pub struct ChunkData {
    pub sections: [Option<Arc<Section>>; SECTIONS],
    /// Y of the topmost solid, non-foliage block per column (index `lz * 16 + lx`).
    pub height_map: Vec<i16>,
    /// A cave entrance is close: the interior stays meshed.
    pub cave_mouth: bool,
}

#[inline]
fn section_index(lx: i32, ly: i32, lz: i32) -> usize {
    ((((ly & 15) * 16 + (lz & 15)) * 16) + (lx & 15)) as usize
}

impl ChunkData {
    pub fn new() -> ChunkData {
        ChunkData {
            sections: std::array::from_fn(|_| None),
            height_map: vec![0i16; 256],
            cave_mouth: false,
        }
    }

    pub fn get_raw(&self, lx: i32, y: i32, lz: i32) -> u8 {
        if y < 0 || y >= WORLD_HEIGHT {
            return 0;
        }
        match &self.sections[(y >> 4) as usize] {
            Some(sec) => sec[section_index(lx, y & 15, lz)],
            None => 0,
        }
    }

    pub fn get(&self, lx: i32, y: i32, lz: i32) -> Block {
        Block::from_raw(self.get_raw(lx, y, lz))
    }

    /// Writable section `sub`, allocated (all air) and unshared on demand.
    pub fn section_mut(&mut self, sub: usize) -> &mut Section {
        if self.sections[sub].is_none() {
            self.sections[sub] = Some(Arc::new([0u8; SECTION_VOLUME]));
        }
        match self.sections[sub].as_mut() {
            Some(arc) => Arc::make_mut(arc),
            None => unreachable!(),
        }
    }

    pub fn set_raw(&mut self, lx: i32, y: i32, lz: i32, raw: u8) {
        if y < 0 || y >= WORLD_HEIGHT {
            return;
        }
        let sub = (y >> 4) as usize;
        if raw == 0 && self.sections[sub].is_none() {
            return;
        }
        let idx = section_index(lx, y & 15, lz);
        self.section_mut(sub)[idx] = raw;
    }

    pub fn set(&mut self, lx: i32, y: i32, lz: i32, block: Block) {
        self.set_raw(lx, y, lz, block as u8);
    }

    /// Index of the highest section that exists, or -1 for an empty chunk.
    pub fn top_section(&self) -> i32 {
        let mut i = SECTIONS as i32 - 1;
        while i >= 0 {
            if self.sections[i as usize].is_some() {
                return i;
            }
            i -= 1;
        }
        -1
    }

    /// Recomputes `height_map` from the blocks (for chunks restored from a save).
    pub fn compute_height_map(&mut self) {
        for lz in 0..16 {
            for lx in 0..16 {
                let mut y = WORLD_HEIGHT - 1;
                while y > 0 {
                    let b = self.get(lx, y, lz);
                    if b.solid() && !b.is_leaves() && !b.is_log() && b != Block::Cactus {
                        break;
                    }
                    y -= 1;
                }
                self.height_map[(lz * 16 + lx) as usize] = y as i16;
            }
        }
    }

    /// All blocks as one `BYTES_PER_CHUNK` buffer (section by section, absent sections are zeros).
    pub fn serialize(&self) -> Vec<u8> {
        let mut out = vec![0u8; BYTES_PER_CHUNK];
        for (i, sec) in self.sections.iter().enumerate() {
            if let Some(s) = sec {
                let start = i * SECTION_VOLUME;
                out[start..start + SECTION_VOLUME].copy_from_slice(&s[..]);
            }
        }
        out
    }

    /// Inverse of `serialize`; `None` if the buffer has the wrong size.
    pub fn deserialize(data: &[u8]) -> Option<ChunkData> {
        if data.len() != BYTES_PER_CHUNK {
            return None;
        }
        let mut chunk = ChunkData::new();
        for i in 0..SECTIONS {
            let slice = &data[i * SECTION_VOLUME..(i + 1) * SECTION_VOLUME];
            if slice.iter().any(|&b| b != 0) {
                let mut arr = [0u8; SECTION_VOLUME];
                arr.copy_from_slice(slice);
                chunk.sections[i] = Some(Arc::new(arr));
            }
        }
        chunk.compute_height_map();
        Some(chunk)
    }
}

impl Default for ChunkData {
    fn default() -> ChunkData {
        ChunkData::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_get_round_trip_and_serialize() {
        let mut c = ChunkData::new();
        c.set(3, 70, 5, Block::Stone);
        c.set(15, 255, 15, Block::Dirt);
        assert_eq!(c.get(3, 70, 5), Block::Stone);
        assert_eq!(c.get(0, 70, 0), Block::Air);
        let bytes = c.serialize();
        let d = ChunkData::deserialize(&bytes).unwrap();
        assert_eq!(d.get(3, 70, 5), Block::Stone);
        assert_eq!(d.get(15, 255, 15), Block::Dirt);
    }

    #[test]
    fn snapshots_are_copy_on_write() {
        let mut a = ChunkData::new();
        a.set(1, 10, 1, Block::Sand);
        let snapshot = a.clone();
        a.set(1, 10, 1, Block::Gravel);
        assert_eq!(snapshot.get(1, 10, 1), Block::Sand);
        assert_eq!(a.get(1, 10, 1), Block::Gravel);
    }
}
