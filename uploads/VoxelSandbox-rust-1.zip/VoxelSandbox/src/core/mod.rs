//! Platform-independent building blocks: maths, the Kotlin-compatible random generator and logging.

pub mod log;
pub mod math;
pub mod rng;
