//! Tiny logging facade: logcat on Android, stderr everywhere else (unit tests, host tools).

#[cfg(target_os = "android")]
mod sys {
    use std::os::raw::c_char;

    #[link(name = "log")]
    extern "C" {
        pub fn __android_log_write(prio: i32, tag: *const c_char, text: *const c_char) -> i32;
    }
}

/// Android log priorities.
pub const INFO: i32 = 4;
pub const WARN: i32 = 5;
pub const ERROR: i32 = 6;

#[cfg(target_os = "android")]
pub fn write(prio: i32, msg: &str) {
    use std::ffi::CString;
    let tag = match CString::new("VoxelSandbox") {
        Ok(t) => t,
        Err(_) => return,
    };
    let text = match CString::new(msg.replace('\0', " ")) {
        Ok(t) => t,
        Err(_) => return,
    };
    unsafe {
        sys::__android_log_write(prio, tag.as_ptr(), text.as_ptr());
    }
}

#[cfg(not(target_os = "android"))]
pub fn write(prio: i32, msg: &str) {
    let level = match prio {
        INFO => "I",
        WARN => "W",
        _ => "E",
    };
    eprintln!("[{}] {}", level, msg);
}

pub fn info(msg: &str) {
    write(INFO, msg);
}

pub fn warn(msg: &str) {
    write(WARN, msg);
}

pub fn error(msg: &str) {
    write(ERROR, msg);
}

#[macro_export]
macro_rules! logi {
    ($($arg:tt)*) => { $crate::core::log::info(&format!($($arg)*)) };
}

#[macro_export]
macro_rules! logw {
    ($($arg:tt)*) => { $crate::core::log::warn(&format!($($arg)*)) };
}

#[macro_export]
macro_rules! loge {
    ($($arg:tt)*) => { $crate::core::log::error(&format!($($arg)*)) };
}
