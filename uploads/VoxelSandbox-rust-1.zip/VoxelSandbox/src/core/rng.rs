//! A bit-exact copy of Kotlin's `Random(seed: Long)` (XorWow), so a seed shuffles the noise
//! permutation tables exactly like the JVM version of the game did.

pub struct KotlinRandom {
    x: i32,
    y: i32,
    z: i32,
    w: i32,
    v: i32,
    addend: i32,
}

impl KotlinRandom {
    pub fn new(seed: i64) -> KotlinRandom {
        let seed1 = seed as i32;
        let seed2 = (seed >> 32) as i32;
        let mut r = KotlinRandom {
            x: seed1,
            y: seed2,
            z: 0,
            w: 0,
            v: !seed1,
            addend: seed1.wrapping_shl(10) ^ (((seed2 as u32) >> 4) as i32),
        };
        for _ in 0..64 {
            r.next_int();
        }
        r
    }

    pub fn next_int(&mut self) -> i32 {
        let mut t = self.x;
        t ^= ((t as u32) >> 2) as i32;
        self.x = self.y;
        self.y = self.z;
        self.z = self.w;
        let v0 = self.v;
        self.w = v0;
        t = (t ^ t.wrapping_shl(1)) ^ v0 ^ v0.wrapping_shl(4);
        self.v = t;
        self.addend = self.addend.wrapping_add(362437);
        t.wrapping_add(self.addend)
    }

    fn next_bits(&mut self, bit_count: i32) -> i32 {
        if bit_count <= 0 {
            return 0;
        }
        let r = self.next_int();
        (((r as u32) >> (32 - bit_count as u32)) as i32) & ((-bit_count) >> 31)
    }

    /// Uniform in `0 until bound` (bound > 0), like `Random.nextInt(until)`.
    pub fn next_int_below(&mut self, bound: i32) -> i32 {
        let n = bound;
        if n & n.wrapping_neg() == n {
            let bit_count = 31 - n.leading_zeros() as i32;
            self.next_bits(bit_count)
        } else {
            loop {
                let bits = ((self.next_int() as u32) >> 1) as i32;
                let v = bits % n;
                if bits.wrapping_sub(v).wrapping_add(n - 1) >= 0 {
                    return v;
                }
            }
        }
    }
}

/// A small, fast generator for effects that do not need to match anything (particles, spawn jitter).
pub struct SplitMix64 {
    state: u64,
}

impl SplitMix64 {
    pub fn new(seed: u64) -> SplitMix64 {
        SplitMix64 { state: seed }
    }

    pub fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }

    /// Uniform in [0, 1).
    pub fn next_f32(&mut self) -> f32 {
        ((self.next_u64() >> 40) as f32) / 16_777_216.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn same_seed_same_sequence() {
        let mut a = KotlinRandom::new(12345);
        let mut b = KotlinRandom::new(12345);
        for _ in 0..100 {
            assert_eq!(a.next_int(), b.next_int());
        }
    }

    #[test]
    fn bounded_values_stay_in_range() {
        let mut r = KotlinRandom::new(-987654321);
        for i in 1..300 {
            let v = r.next_int_below(i);
            assert!(v >= 0 && v < i);
        }
    }
}
