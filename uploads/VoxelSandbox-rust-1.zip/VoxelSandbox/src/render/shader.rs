//! Compiling and linking GLSL programs.

use std::ffi::CString;
use std::os::raw::c_void;

use super::gl::*;

pub struct Program {
    pub id: GLuint,
}

fn compile(kind: GLenum, src: &str) -> Result<GLuint, String> {
    unsafe {
        let shader = glCreateShader(kind);
        if shader == 0 {
            return Err("glCreateShader failed".to_string());
        }
        let ptr = src.as_ptr() as *const GLchar;
        let len = src.len() as GLint;
        glShaderSource(shader, 1, &ptr as *const *const GLchar, &len as *const GLint);
        glCompileShader(shader);
        let mut ok: GLint = 0;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &mut ok as *mut GLint);
        if ok == 0 {
            let mut log_len: GLint = 0;
            glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &mut log_len as *mut GLint);
            let mut buf = vec![0u8; log_len.max(1) as usize];
            let mut written: GLsizei = 0;
            glGetShaderInfoLog(shader, buf.len() as GLsizei, &mut written as *mut GLsizei, buf.as_mut_ptr() as *mut GLchar);
            glDeleteShader(shader);
            let text = String::from_utf8_lossy(&buf[..(written.max(0) as usize).min(buf.len())]).to_string();
            let kind_name = if kind == GL_VERTEX_SHADER { "vertex" } else { "fragment" };
            return Err(format!("{} shader: {}", kind_name, text));
        }
        Ok(shader)
    }
}

impl Program {
    pub fn new(vs_src: &str, fs_src: &str) -> Result<Program, String> {
        let vs = compile(GL_VERTEX_SHADER, vs_src)?;
        let fs = match compile(GL_FRAGMENT_SHADER, fs_src) {
            Ok(f) => f,
            Err(e) => {
                unsafe { glDeleteShader(vs) };
                return Err(e);
            }
        };
        unsafe {
            let id = glCreateProgram();
            glAttachShader(id, vs);
            glAttachShader(id, fs);
            glLinkProgram(id);
            glDeleteShader(vs);
            glDeleteShader(fs);
            let mut ok: GLint = 0;
            glGetProgramiv(id, GL_LINK_STATUS, &mut ok as *mut GLint);
            if ok == 0 {
                let mut log_len: GLint = 0;
                glGetProgramiv(id, GL_INFO_LOG_LENGTH, &mut log_len as *mut GLint);
                let mut buf = vec![0u8; log_len.max(1) as usize];
                let mut written: GLsizei = 0;
                glGetProgramInfoLog(id, buf.len() as GLsizei, &mut written as *mut GLsizei, buf.as_mut_ptr() as *mut GLchar);
                glDeleteProgram(id);
                let text = String::from_utf8_lossy(&buf[..(written.max(0) as usize).min(buf.len())]).to_string();
                return Err(format!("link: {}", text));
            }
            Ok(Program { id })
        }
    }

    pub fn use_program(&self) {
        unsafe { glUseProgram(self.id) };
    }

    pub fn uniform(&self, name: &str) -> GLint {
        match CString::new(name) {
            Ok(c) => unsafe { glGetUniformLocation(self.id, c.as_ptr() as *const GLchar) },
            Err(_) => -1,
        }
    }
}

/// Uploads a column-major 4x4 matrix.
pub fn set_mat4(location: GLint, m: &[f32; 16]) {
    unsafe { glUniformMatrix4fv(location, 1, GL_FALSE, m.as_ptr()) };
}

/// A buffer handle plus the size of the last upload.
pub fn gen_buffer() -> GLuint {
    let mut id: GLuint = 0;
    unsafe { glGenBuffers(1, &mut id as *mut GLuint) };
    id
}

pub fn gen_vertex_array() -> GLuint {
    let mut id: GLuint = 0;
    unsafe { glGenVertexArrays(1, &mut id as *mut GLuint) };
    id
}

pub fn delete_buffer(id: GLuint) {
    unsafe { glDeleteBuffers(1, &id as *const GLuint) };
}

pub fn delete_vertex_array(id: GLuint) {
    unsafe { glDeleteVertexArrays(1, &id as *const GLuint) };
}

pub fn upload_buffer<T>(target: GLenum, data: &[T], usage: GLenum) {
    unsafe {
        glBufferData(target, std::mem::size_of_val(data) as GLsizeiptr, data.as_ptr() as *const c_void, usage);
    }
}
