//! Draws a frame: sky, clouds, the chunk meshes in four passes, the block outline and finally the UI.

use std::collections::{HashMap, VecDeque};
use std::ffi::CStr;
use std::os::raw::{c_char, c_void};

use super::gl::*;
use super::shader::*;
use super::shaders::*;
use crate::core::math::{mat4_mul, mat4_ortho_pixels, mat4_perspective, mat4_view_dir, Frustum, Vec3};
use crate::mesh::{ChunkMeshData, PASS_CUTOUT, PASS_DOUBLE, PASS_OPAQUE, PASS_WATER, VERTEX_SIZE};
use crate::tex::{self, cells};
use crate::ui::app::{App, CameraState, Screen};
use crate::ui::batch::{UiBatch, UI_VERTEX_SIZE};
use crate::ui::font;
use crate::world::pos::ChunkPos;

const FOV_DEGREES: f32 = 70.0;
const NEAR_PLANE: f32 = 0.1;
const HORIZON: [f32; 3] = [0.66, 0.79, 0.93];
const ZENITH: [f32; 3] = [0.27, 0.48, 0.85];
const UNDERWATER: [f32; 3] = [0.16, 0.36, 0.70];
const SUN: [f32; 3] = [0.5156, 0.4688, -0.6282];
const CLOUD_HEIGHT: f32 = 200.0;
const CLOUD_HALF: f32 = 3000.0;

struct GpuChunk {
    vao: GLuint,
    vbo: GLuint,
    ibo: GLuint,
    ranges: [(u32, u32); 4],
    max_y: f32,
}

struct TerrainProg {
    prog: Program,
    view_proj: GLint,
    offset: GLint,
    tex: GLint,
    fog_color: GLint,
    fog_start: GLint,
    fog_end: GLint,
    alpha_test: GLint,
}

struct WaterProg {
    prog: Program,
    view_proj: GLint,
    offset: GLint,
    tex: GLint,
    fog_color: GLint,
    fog_start: GLint,
    fog_end: GLint,
    time: GLint,
}

struct SkyProg {
    prog: Program,
    forward: GLint,
    right: GLint,
    up: GLint,
    tan: GLint,
    horizon: GLint,
    zenith: GLint,
    sun: GLint,
}

struct CloudProg {
    prog: Program,
    view_proj: GLint,
    cam: GLint,
    cloud_y: GLint,
    half: GLint,
    time: GLint,
}

struct LineProg {
    prog: Program,
    view_proj: GLint,
    color: GLint,
}

struct UiProg {
    prog: Program,
    proj: GLint,
    tex: GLint,
    font: GLint,
}

struct WorldGl {
    terrain: TerrainProg,
    water: WaterProg,
    sky: SkyProg,
    cloud: CloudProg,
    line: LineProg,
}

impl WorldGl {
    fn new() -> Result<WorldGl, String> {
        let tp = Program::new(TERRAIN_VS, TERRAIN_FS).map_err(|e| format!("terrain {}", e))?;
        let terrain = TerrainProg {
            view_proj: tp.uniform("uViewProj"),
            offset: tp.uniform("uOffset"),
            tex: tp.uniform("uTex"),
            fog_color: tp.uniform("uFogColor"),
            fog_start: tp.uniform("uFogStart"),
            fog_end: tp.uniform("uFogEnd"),
            alpha_test: tp.uniform("uAlphaTest"),
            prog: tp,
        };
        let wp = Program::new(TERRAIN_VS, WATER_FS).map_err(|e| format!("water {}", e))?;
        let water = WaterProg {
            view_proj: wp.uniform("uViewProj"),
            offset: wp.uniform("uOffset"),
            tex: wp.uniform("uTex"),
            fog_color: wp.uniform("uFogColor"),
            fog_start: wp.uniform("uFogStart"),
            fog_end: wp.uniform("uFogEnd"),
            time: wp.uniform("uTime"),
            prog: wp,
        };
        let sp = Program::new(SKY_VS, SKY_FS).map_err(|e| format!("sky {}", e))?;
        let sky = SkyProg {
            forward: sp.uniform("uForward"),
            right: sp.uniform("uRight"),
            up: sp.uniform("uUp"),
            tan: sp.uniform("uTan"),
            horizon: sp.uniform("uHorizon"),
            zenith: sp.uniform("uZenith"),
            sun: sp.uniform("uSunDir"),
            prog: sp,
        };
        let cp = Program::new(CLOUD_VS, CLOUD_FS).map_err(|e| format!("cloud {}", e))?;
        let cloud = CloudProg {
            view_proj: cp.uniform("uViewProj"),
            cam: cp.uniform("uCam"),
            cloud_y: cp.uniform("uCloudY"),
            half: cp.uniform("uHalf"),
            time: cp.uniform("uTime"),
            prog: cp,
        };
        let lp = Program::new(LINE_VS, LINE_FS).map_err(|e| format!("line {}", e))?;
        let line = LineProg { view_proj: lp.uniform("uViewProj"), color: lp.uniform("uColor"), prog: lp };
        Ok(WorldGl { terrain, water, sky, cloud, line })
    }
}

struct Visible {
    off: [f32; 3],
    dist2: f32,
    vao: GLuint,
    ranges: [(u32, u32); 4],
}

pub struct Renderer {
    ui: UiProg,
    world: Option<WorldGl>,
    error: Option<String>,
    block_tex: GLuint,
    font_tex: GLuint,
    ui_vao: GLuint,
    ui_vbo: GLuint,
    line_vao: GLuint,
    line_vbo: GLuint,
    dummy_vao: GLuint,
    chunks: HashMap<ChunkPos, GpuChunk>,
    pending: VecDeque<(ChunkPos, ChunkMeshData)>,
    time: f32,
    error_batch: UiBatch,
}

fn create_block_texture() -> GLuint {
    let rgba = tex::build_layers_rgba();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D_ARRAY, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage3D(
            GL_TEXTURE_2D_ARRAY,
            0,
            GL_RGBA8,
            tex::TILE_SIZE as GLsizei,
            tex::TILE_SIZE as GLsizei,
            cells::TILE_COUNT as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
    }
    id
}

fn create_font_texture() -> GLuint {
    let rgba = font::build_atlas();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            font::ATLAS_W as GLsizei,
            font::ATLAS_H as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    id
}

fn gl_string(name: GLenum) -> String {
    unsafe {
        let p = glGetString(name);
        if p.is_null() {
            return String::from("?");
        }
        CStr::from_ptr(p as *const c_char).to_string_lossy().to_string()
    }
}

fn draw_range(first: u32, count: u32) {
    if count > 0 {
        unsafe {
            glDrawElements(GL_TRIANGLES, count as GLsizei, GL_UNSIGNED_INT, (first as usize * 4) as *const c_void);
        }
    }
}

fn push_box(out: &mut Vec<f32>, min: [f32; 3], max: [f32; 3]) {
    let c = |x: usize, y: usize, z: usize| -> [f32; 3] {
        [if x == 0 { min[0] } else { max[0] }, if y == 0 { min[1] } else { max[1] }, if z == 0 { min[2] } else { max[2] }]
    };
    let faces: [[[usize; 3]; 4]; 6] = [
        [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]],
        [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
        [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
        [[1, 0, 0], [1, 0, 1], [1, 1, 1], [1, 1, 0]],
        [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
        [[0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]],
    ];
    for f in faces.iter() {
        let idx = [0usize, 1, 2, 0, 2, 3];
        for &i in idx.iter() {
            let p = c(f[i][0], f[i][1], f[i][2]);
            out.extend_from_slice(&p);
        }
    }
}

/// The twelve edges of a box as thin boxes (a wireframe that is the same thickness on every screen).
fn outline_vertices(min: [f32; 3], max: [f32; 3], t: f32) -> Vec<f32> {
    let mut out = Vec::with_capacity(12 * 36 * 3);
    for axis in 0..3 {
        for a in 0..2 {
            for b in 0..2 {
                let mut lo = [0.0f32; 3];
                let mut hi = [0.0f32; 3];
                for k in 0..3 {
                    if k == axis {
                        lo[k] = min[k] - t;
                        hi[k] = max[k] + t;
                    } else {
                        let which = if (k + 3 - axis) % 3 == 1 { a } else { b };
                        let v = if which == 0 { min[k] } else { max[k] };
                        lo[k] = v - t;
                        hi[k] = v + t;
                    }
                }
                push_box(&mut out, lo, hi);
            }
        }
    }
    out
}

impl Renderer {
    /// Needs a current GL context. Fails only if the UI itself cannot be drawn.
    pub fn new() -> Result<Renderer, String> {
        crate::logi!("GL {} on {}", gl_string(GL_VERSION), gl_string(GL_RENDERER));
        let up = Program::new(UI_VS, UI_FS).map_err(|e| format!("ui {}", e))?;
        let ui = UiProg { proj: up.uniform("uProj"), tex: up.uniform("uTex"), font: up.uniform("uFont"), prog: up };
        let (world, error) = match WorldGl::new() {
            Ok(w) => (Some(w), None),
            Err(e) => {
                crate::loge!("world shaders failed: {}", e);
                (None, Some(e))
            }
        };
        let block_tex = create_block_texture();
        let font_tex = create_font_texture();

        let ui_vao = gen_vertex_array();
        let ui_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, ui_vbo);
            let stride = UI_VERTEX_SIZE as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 8 as *const c_void);
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 16 as *const c_void);
            glEnableVertexAttribArray(3);
            glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, 20 as *const c_void);
            glBindVertexArray(0);
        }
        let line_vao = gen_vertex_array();
        let line_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(line_vao);
            glBindBuffer(GL_ARRAY_BUFFER, line_vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 12, 0 as *const c_void);
            glBindVertexArray(0);
        }
        let dummy_vao = gen_vertex_array();

        let mut error_batch = UiBatch::new();
        if let Some(e) = error.as_ref() {
            let mut y = 20.0;
            error_batch.text(20.0, y, 3.0, "SHADER ERROR - WORLD NOT DRAWN", [255, 120, 120, 255]);
            y += 40.0;
            for line in e.lines().take(14) {
                let short: String = line.chars().take(70).collect();
                error_batch.text(20.0, y, 2.0, &short, [255, 255, 255, 255]);
                y += 20.0;
            }
        }

        Ok(Renderer {
            ui,
            world,
            error,
            block_tex,
            font_tex,
            ui_vao,
            ui_vbo,
            line_vao,
            line_vbo,
            dummy_vao,
            chunks: HashMap::new(),
            pending: VecDeque::new(),
            time: 0.0,
            error_batch,
        })
    }

    pub fn has_world_pipeline(&self) -> bool {
        self.world.is_some()
    }

    /// The GL context is gone: forget every handle (they are invalid anyway).
    pub fn forget_gpu_objects(&mut self) {
        self.chunks.clear();
        self.pending.clear();
    }

    fn remove_chunk(&mut self, pos: ChunkPos) {
        if let Some(g) = self.chunks.remove(&pos) {
            delete_vertex_array(g.vao);
            delete_buffer(g.vbo);
            delete_buffer(g.ibo);
        }
    }

    fn clear_chunks(&mut self) {
        let keys: Vec<ChunkPos> = self.chunks.keys().copied().collect();
        for k in keys {
            self.remove_chunk(k);
        }
    }

    fn upload_chunk(&mut self, pos: ChunkPos, mesh: ChunkMeshData) {
        self.remove_chunk(pos);
        if mesh.is_empty() {
            return;
        }
        let vao = gen_vertex_array();
        let vbo = gen_buffer();
        let ibo = gen_buffer();
        unsafe {
            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            upload_buffer(GL_ARRAY_BUFFER, &mesh.vertices, GL_STATIC_DRAW);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
            upload_buffer(GL_ELEMENT_ARRAY_BUFFER, &mesh.indices, GL_STATIC_DRAW);
            let stride = VERTEX_SIZE as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 12 as *const c_void);
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 20 as *const c_void);
            glEnableVertexAttribArray(3);
            glVertexAttribIPointer(3, 4, GL_UNSIGNED_BYTE, stride, 24 as *const c_void);
            glBindVertexArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }
        self.chunks.insert(pos, GpuChunk { vao, vbo, ibo, ranges: mesh.ranges, max_y: mesh.max_y });
    }

    /// Draws one frame of `app` into the current surface (`width` x `height` pixels).
    pub fn render(&mut self, app: &mut App, width: i32, height: i32, dt: f32) {
        self.time += dt;
        // keep GPU meshes in step with the world
        match app.engine.as_mut() {
            Some(engine) => {
                for p in engine.manager.take_removed() {
                    self.remove_chunk(p);
                }
                for up in engine.manager.take_uploads() {
                    self.pending.push_back(up);
                }
            }
            None => {
                if !self.chunks.is_empty() {
                    self.clear_chunks();
                }
                self.pending.clear();
            }
        }
        let budget = if app.screen == Screen::Loading { 24 } else { 4 };
        for _ in 0..budget {
            let (p, m) = match self.pending.pop_front() {
                Some(x) => x,
                None => break,
            };
            let alive = match app.engine.as_ref() {
                Some(e) => e.manager.world.contains(p),
                None => false,
            };
            if alive {
                self.upload_chunk(p, m);
            }
        }

        let cam = app.camera();
        unsafe {
            glViewport(0, 0, width, height);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
            let sky = match cam {
                Some(c) if c.underwater => UNDERWATER,
                _ => HORIZON,
            };
            glClearColor(sky[0], sky[1], sky[2], 1.0);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        }
        if app.world_visible() {
            if let Some(c) = cam {
                self.draw_world(app, &c, width, height);
            }
        } else if self.world.is_some() {
            self.draw_menu_sky(app.time, width, height);
        }
        self.draw_ui(&app.ui, width, height);
        if self.error.is_some() {
            let batch = std::mem::take(&mut self.error_batch);
            self.draw_ui(&batch, width, height);
            self.error_batch = batch;
        }
    }

    fn bind_textures(&self) {
        unsafe {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D_ARRAY, self.block_tex);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, self.font_tex);
            glActiveTexture(GL_TEXTURE0);
        }
    }

    /// A slowly turning sky behind the main menu.
    fn draw_menu_sky(&self, time: f32, width: i32, height: i32) {
        let wg = match self.world.as_ref() {
            Some(w) => w,
            None => return,
        };
        let yaw = time * 0.05;
        let pitch = 0.25f32;
        self.draw_sky(wg, yaw, pitch, width as f32 / height.max(1) as f32);
    }

    fn draw_sky(&self, wg: &WorldGl, yaw: f32, pitch: f32, aspect: f32) {
        let cp = pitch.cos();
        let f = Vec3::new(cp * yaw.sin(), pitch.sin(), -cp * yaw.cos());
        let right = f.cross(Vec3::new(0.0, 1.0, 0.0)).normalized();
        let up = right.cross(f);
        let tan_half = (FOV_DEGREES.to_radians() * 0.5).tan();
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
            glDisable(GL_CULL_FACE);
            wg.sky.prog.use_program();
            glUniform3f(wg.sky.forward, f.x, f.y, f.z);
            glUniform3f(wg.sky.right, right.x, right.y, right.z);
            glUniform3f(wg.sky.up, up.x, up.y, up.z);
            glUniform2f(wg.sky.tan, tan_half * aspect, tan_half);
            glUniform3f(wg.sky.horizon, HORIZON[0], HORIZON[1], HORIZON[2]);
            glUniform3f(wg.sky.zenith, ZENITH[0], ZENITH[1], ZENITH[2]);
            glUniform3f(wg.sky.sun, SUN[0], SUN[1], SUN[2]);
            glBindVertexArray(self.dummy_vao);
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
        }
    }

    fn draw_world(&self, app: &App, cam: &CameraState, width: i32, height: i32) {
        let wg = match self.world.as_ref() {
            Some(w) => w,
            None => return,
        };
        let aspect = width as f32 / height.max(1) as f32;
        let fov = FOV_DEGREES.to_radians();
        let view_chunks = app.settings.render_distance as f32;
        let fog_end_clear = (view_chunks * 16.0 - 8.0).max(48.0);
        let (fog_start, fog_end, fog_color) = if cam.underwater {
            (0.0, 26.0, UNDERWATER)
        } else {
            (fog_end_clear * 0.55, fog_end_clear, HORIZON)
        };
        let far = (fog_end * 1.08 + 24.0).max(64.0);

        let cp = cam.pitch.cos();
        let forward = Vec3::new(cp * cam.yaw.sin(), cam.pitch.sin(), -cp * cam.yaw.cos());
        let view = mat4_view_dir(forward, Vec3::new(0.0, 1.0, 0.0));
        let vp = mat4_mul(&mat4_perspective(fov, aspect, NEAR_PLANE, far), &view);
        let frustum = Frustum::from_matrix(&vp);

        // sky and clouds go behind everything
        if !cam.underwater {
            self.draw_sky(wg, cam.yaw, cam.pitch, aspect);
            if app.settings.clouds {
                let vp_far = mat4_mul(&mat4_perspective(fov, aspect, 1.0, 9000.0), &view);
                unsafe {
                    glDisable(GL_DEPTH_TEST);
                    glDepthMask(GL_FALSE);
                    glDisable(GL_CULL_FACE);
                    glEnable(GL_BLEND);
                    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                    wg.cloud.prog.use_program();
                    set_mat4(wg.cloud.view_proj, &vp_far);
                    glUniform3f(wg.cloud.cam, cam.x as f32, cam.y as f32, cam.z as f32);
                    glUniform1f(wg.cloud.cloud_y, CLOUD_HEIGHT);
                    glUniform1f(wg.cloud.half, CLOUD_HALF);
                    glUniform1f(wg.cloud.time, self.time);
                    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
                    glDisable(GL_BLEND);
                    glDepthMask(GL_TRUE);
                }
            }
        }

        // visible chunks, nearest first
        let reach = far + 24.0;
        let reach2 = reach * reach;
        let mut visible: Vec<Visible> = Vec::new();
        for (pos, g) in self.chunks.iter() {
            let ox = (pos.x as f64 * 16.0 - cam.x) as f32;
            let oz = (pos.z as f64 * 16.0 - cam.z) as f32;
            let oy = (0.0 - cam.y) as f32;
            let cx = ox + 8.0;
            let cz = oz + 8.0;
            let d2 = cx * cx + cz * cz;
            if d2 > reach2 {
                continue;
            }
            if !frustum.box_visible([ox, oy, oz], [ox + 16.0, oy + g.max_y, oz + 16.0]) {
                continue;
            }
            visible.push(Visible { off: [ox, oy, oz], dist2: d2, vao: g.vao, ranges: g.ranges });
        }
        visible.sort_by(|a, b| a.dist2.partial_cmp(&b.dist2).unwrap_or(std::cmp::Ordering::Equal));

        self.bind_textures();
        unsafe {
            glEnable(GL_DEPTH_TEST);
            glDepthFunc(GL_LEQUAL);
            glDepthMask(GL_TRUE);
            glEnable(GL_CULL_FACE);
            glCullFace(GL_BACK);
            glFrontFace(GL_CCW);
            glDisable(GL_BLEND);

            let t = &wg.terrain;
            t.prog.use_program();
            set_mat4(t.view_proj, &vp);
            glUniform1i(t.tex, 0);
            glUniform3f(t.fog_color, fog_color[0], fog_color[1], fog_color[2]);
            glUniform1f(t.fog_start, fog_start);
            glUniform1f(t.fog_end, fog_end);

            // opaque
            glUniform1f(t.alpha_test, 0.0);
            for v in visible.iter() {
                glUniform3f(t.offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_OPAQUE].0, v.ranges[PASS_OPAQUE].1);
            }
            // leaves: alpha tested, one-sided
            glUniform1f(t.alpha_test, 1.0);
            for v in visible.iter() {
                if v.ranges[PASS_CUTOUT].1 == 0 {
                    continue;
                }
                glUniform3f(t.offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_CUTOUT].0, v.ranges[PASS_CUTOUT].1);
            }
            // plants: alpha tested, both sides
            glDisable(GL_CULL_FACE);
            for v in visible.iter() {
                if v.ranges[PASS_DOUBLE].1 == 0 {
                    continue;
                }
                glUniform3f(t.offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_DOUBLE].0, v.ranges[PASS_DOUBLE].1);
            }
        }

        // the block the player is aiming at
        if let Some(engine) = app.engine.as_ref() {
            if let Some(hit) = engine.last_hit {
                if app.screen == Screen::Playing {
                    let min = [hit.bx as f32 - cam.x as f32 - 0.003, hit.by as f32 - cam.y as f32 - 0.003, hit.bz as f32 - cam.z as f32 - 0.003];
                    let max = [min[0] + 1.006, min[1] + 1.006, min[2] + 1.006];
                    let verts = outline_vertices(min, max, 0.012);
                    unsafe {
                        glEnable(GL_BLEND);
                        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                        glDepthMask(GL_FALSE);
                        wg.line.prog.use_program();
                        set_mat4(wg.line.view_proj, &vp);
                        glUniform4f(wg.line.color, 0.0, 0.0, 0.0, 0.78);
                        glBindVertexArray(self.line_vao);
                        glBindBuffer(GL_ARRAY_BUFFER, self.line_vbo);
                        upload_buffer(GL_ARRAY_BUFFER, &verts, GL_STREAM_DRAW);
                        glDrawArrays(GL_TRIANGLES, 0, (verts.len() / 3) as GLsizei);
                        glBindVertexArray(0);
                        glDepthMask(GL_TRUE);
                        glDisable(GL_BLEND);
                    }
                }
            }
        }

        // water last, far to near
        unsafe {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(GL_FALSE);
            glDisable(GL_CULL_FACE);
            let w = &wg.water;
            w.prog.use_program();
            set_mat4(w.view_proj, &vp);
            glUniform1i(w.tex, 0);
            glUniform3f(w.fog_color, fog_color[0], fog_color[1], fog_color[2]);
            glUniform1f(w.fog_start, fog_start);
            glUniform1f(w.fog_end, fog_end);
            glUniform1f(w.time, self.time);
            for v in visible.iter().rev() {
                if v.ranges[PASS_WATER].1 == 0 {
                    continue;
                }
                glUniform3f(w.offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_WATER].0, v.ranges[PASS_WATER].1);
            }
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }
    }

    fn draw_ui(&self, batch: &UiBatch, width: i32, height: i32) {
        if batch.verts.is_empty() {
            return;
        }
        self.bind_textures();
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_CULL_FACE);
            glDepthMask(GL_FALSE);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            self.ui.prog.use_program();
            set_mat4(self.ui.proj, &mat4_ortho_pixels(width as f32, height as f32));
            glUniform1i(self.ui.tex, 0);
            glUniform1i(self.ui.font, 1);
            glBindVertexArray(self.ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, self.ui_vbo);
            upload_buffer(GL_ARRAY_BUFFER, &batch.verts, GL_STREAM_DRAW);
            glDrawArrays(GL_TRIANGLES, 0, batch.verts.len() as GLsizei);
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }
    }
}
