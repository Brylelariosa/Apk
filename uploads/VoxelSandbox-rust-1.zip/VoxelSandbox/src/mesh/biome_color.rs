//! Biome tinting. Grass, tall grass and leaves are drawn in a neutral green; the mesher multiplies them by
//! `field colour / anchor colour` (the anchor is the tile's own mean colour), so a biome's colour is a smooth
//! function of the climate instead of a hard per-biome switch.

use std::sync::Arc;

use crate::gen::climate::Climate;
use crate::gen::shape::TerrainShape;
use crate::tex;
use crate::tex::cells;
use crate::world::config::SEA_LEVEL;

pub const COLD_SHIFT: [f32; 3] = [0.86, 0.92, 1.40];
/// Leaves take this much of the grass tint.
pub const LEAF_STRENGTH: f32 = 0.7;

/// The anchor colours: the means of the neutral grass tiles.
#[derive(Clone, Debug)]
pub struct BiomePalette {
    pub grass: [f32; 3],
    pub dry: [f32; 3],
    pub swamp: [f32; 3],
    pub cold: [f32; 3],
}

impl BiomePalette {
    pub fn from_tiles() -> BiomePalette {
        fn mean(cell: i32) -> [f32; 3] {
            match tex::tile_argb(cell) {
                Some(t) => {
                    let m = tex::average_rgb(&t);
                    [m[0] as f32, m[1] as f32, m[2] as f32]
                }
                None => [128.0, 128.0, 128.0],
            }
        }
        let grass = mean(cells::GRASS_TOP);
        BiomePalette {
            grass,
            dry: mean(cells::DRY_GRASS_TOP),
            swamp: mean(cells::SWAMP_GRASS_TOP),
            cold: [grass[0] * COLD_SHIFT[0], grass[1] * COLD_SHIFT[1], grass[2] * COLD_SHIFT[2]],
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Anchor {
    Grass,
    Dry,
    Swamp,
}

/// How a tile is tinted: `mode` 1 = the whole texture, 2 = only the grass fringe (the shader masks it).
#[derive(Clone, Copy, Debug)]
pub struct TintInfo {
    pub anchor: Anchor,
    pub mode: u8,
    pub strength: f32,
}

pub fn tint_for_cell(cell: i32) -> Option<TintInfo> {
    let whole = |anchor: Anchor, strength: f32| Some(TintInfo { anchor, mode: 1, strength });
    let fringe = |anchor: Anchor| Some(TintInfo { anchor, mode: 2, strength: 1.0 });
    match cell {
        cells::GRASS_TOP => whole(Anchor::Grass, 1.0),
        cells::GRASS_SIDE => fringe(Anchor::Grass),
        cells::DRY_GRASS_TOP => whole(Anchor::Dry, 1.0),
        cells::DRY_GRASS_SIDE => fringe(Anchor::Dry),
        cells::SWAMP_GRASS_TOP => whole(Anchor::Swamp, 1.0),
        cells::SWAMP_GRASS_SIDE => fringe(Anchor::Swamp),
        cells::TALL_GRASS => whole(Anchor::Grass, 1.0),
        cells::OAK_LEAVES | cells::BIRCH_LEAVES | cells::SPRUCE_LEAVES => whole(Anchor::Grass, LEAF_STRENGTH),
        _ => None,
    }
}

/// The colour of the ground cover at a point, from the climate fields.
pub struct BiomeColorField {
    climate: Arc<Climate>,
    shape: Arc<TerrainShape>,
    pub palette: BiomePalette,
}

impl BiomeColorField {
    pub fn new(climate: Arc<Climate>, shape: Arc<TerrainShape>, palette: BiomePalette) -> BiomeColorField {
        BiomeColorField { climate, shape, palette }
    }

    /// Grass colour (0..255 per channel) for a point with known ground height, base elevation, sea-level
    /// temperature and humidity.
    pub fn grass(&self, wx: f64, wz: f64, ground: f64, coast: f64, t0: f64, hum: f64) -> [f32; 3] {
        let p = &self.palette;
        let alt = ground - SEA_LEVEL as f64;
        let te = self.climate.ground_temperature(t0, self.climate.temperature_jitter(wx, wz), ground);
        let hu = hum + self.climate.humidity_jitter(wx, wz);
        let cold = self.climate.coldness(te) as f32;
        let dry = self.climate.dryness(te, hu) as f32;
        let swamp = self.climate.swampiness(self.climate.swamp_weight_with(wx, wz, coast, hum, t0), alt) as f32;
        let mut c = p.grass;
        for k in 0..3 {
            c[k] += (p.cold[k] - c[k]) * cold;
        }
        for k in 0..3 {
            c[k] += (p.dry[k] - c[k]) * dry;
        }
        for k in 0..3 {
            c[k] += (p.swamp[k] - c[k]) * swamp;
        }
        for k in 0..3 {
            c[k] = c[k].max(0.0).min(255.0);
        }
        c
    }

    /// The grass colour at a block column (samples the land-form for its height).
    pub fn grass_at(&self, wx: f64, wz: f64) -> [f32; 3] {
        let (ground, coast) = self.shape.height_and_coast(wx, wz, 0);
        self.grass(wx, wz, ground, coast, self.climate.base_temperature(wx, wz), self.climate.humidity(wx, wz))
    }
}
