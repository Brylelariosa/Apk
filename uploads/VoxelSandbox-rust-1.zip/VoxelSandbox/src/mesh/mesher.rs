//! Turns a chunk (plus a one-block apron from its eight neighbours) into triangles: culled cube faces with
//! per-vertex ambient occlusion, cave darkening and biome tint, crossed-quad plants and animated-height water.

use std::sync::Arc;

use super::biome_color::{tint_for_cell, Anchor, BiomeColorField, BiomePalette, TintInfo};
use super::{ChunkMeshData, Vertex, PASS_COUNT, PASS_CUTOUT, PASS_DOUBLE, PASS_OPAQUE, PASS_WATER};
use crate::tex::cells;
use crate::world::block::{Block, Face, CUTOUT_BY_ID, OPAQUE_BY_ID, SOLID_BY_ID};
use crate::world::chunk::ChunkData;
use crate::world::config::{SEA_LEVEL, WORLD_HEIGHT};
use crate::world::fluid;
use crate::world::pos::ChunkPos;

const PAD_XZ: usize = 18;
const PAD_Y: usize = 258;

/// Corner brightness for ambient-occlusion level 0 (boxed in) .. 3 (open).
const AO_SHADE: [f32; 4] = [0.58, 0.72, 0.86, 1.0];
/// Shade per face, in `Face` order: top, bottom, north, south, east, west.
const FACE_SHADE: [f32; 6] = [1.0, 0.4, 0.82, 0.82, 0.70, 0.70];
const CAVE_DARK_START: i32 = 3;
const CAVE_DARK_RATE: f32 = 0.03;
const MAX_LIGHT_STEP: i32 = 21;

const FACE_NORMAL: [[i32; 3]; 6] = [[0, 1, 0], [0, -1, 0], [0, 0, -1], [0, 0, 1], [1, 0, 0], [-1, 0, 0]];

/// Quad corners per face, counter-clockwise seen from outside.
const FACE_CORNERS: [[[i32; 3]; 4]; 6] = [
    [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]],
    [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
    [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
    [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
];

const UV_TOP: [[f32; 2]; 4] = [[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]];
const UV_BOTTOM: [[f32; 2]; 4] = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
const UV_SIDE: [[f32; 2]; 4] = [[0.0, 1.0], [1.0, 1.0], [1.0, 0.0], [0.0, 0.0]];

const FLIP_X: u8 = 1;
const FLIP_Y: u8 = 2;
const SWAP: u8 = 4;

/// Which mirror / rotate tricks keep a tile looking right (they break up the repetition of the ground).
fn variant_flags(layer: i32) -> u8 {
    match layer {
        cells::GRASS_TOP
        | cells::DIRT
        | cells::STONE
        | cells::SAND
        | cells::OAK_RINGS
        | cells::OAK_LEAVES
        | cells::COAL_ORE
        | cells::BIRCH_LEAVES
        | cells::SPRUCE_LEAVES
        | cells::BIRCH_RINGS
        | cells::SPRUCE_RINGS
        | cells::SNOW
        | cells::GRAVEL
        | cells::SANDSTONE_TOP
        | cells::DRY_GRASS_TOP
        | cells::CACTUS_TOP
        | cells::SWAMP_GRASS_TOP
        | cells::DEEP_STONE => FLIP_X | FLIP_Y | SWAP,
        cells::OAK_BARK | cells::BIRCH_BARK | cells::SPRUCE_BARK => FLIP_X | FLIP_Y,
        cells::GRASS_SIDE
        | cells::SNOW_SIDE
        | cells::SANDSTONE_SIDE
        | cells::DRY_GRASS_SIDE
        | cells::CACTUS_SIDE
        | cells::SWAMP_GRASS_SIDE => FLIP_X,
        _ => 0,
    }
}

/// A snapshot of a chunk and its eight neighbours (index `(dz + 1) * 3 + (dx + 1)`, centre = 4).
pub struct MeshInput {
    pub pos: ChunkPos,
    pub chunks: [Option<ChunkData>; 9],
}

/// Shared, read-only data the mesher needs.
pub struct MeshContext {
    pub color_field: Arc<BiomeColorField>,
}

#[inline]
fn pidx(x: i32, y: i32, z: i32) -> usize {
    (((y + 1) as usize * PAD_XZ + (z + 1) as usize) * PAD_XZ) + (x + 1) as usize
}

/// Per-block brightness multiplier in `1 - range ..= 1`, a pure function of position.
fn variation(x: i32, y: i32, z: i32, range: f32) -> f32 {
    let mut h = x.wrapping_mul(73856093) ^ y.wrapping_mul(19349663) ^ z.wrapping_mul(83492791);
    h ^= ((h as u32) >> 15) as i32;
    h = h.wrapping_mul(739982445);
    h ^= ((h as u32) >> 13) as i32;
    1.0 - range * ((((h as u32) >> 8) & 0xFF) as f32 / 255.0)
}

fn hash3(x: i32, y: i32, z: i32) -> u32 {
    let mut h = x.wrapping_mul(374761393).wrapping_add(y.wrapping_mul(668265263)).wrapping_add(z.wrapping_mul(1274126177));
    h = (h ^ (((h as u32) >> 13) as i32)).wrapping_mul(-1028477387);
    ((h ^ (((h as u32) >> 16) as i32)) as u32) & 0x7FFF_FFFF
}

struct Builder<'a> {
    pad: Vec<u8>,
    hpad: Vec<i16>,
    base_x: i32,
    base_z: i32,
    palette: &'a BiomePalette,
    tint_grid: [[f32; 3]; 25],
    verts: Vec<Vertex>,
    idx: [Vec<u32>; PASS_COUNT],
}

fn pack_u8(v: f32) -> u8 {
    let x = v * 255.0 + 0.5;
    if x <= 0.0 {
        0
    } else if x >= 255.0 {
        255
    } else {
        x as u8
    }
}

impl<'a> Builder<'a> {
    #[inline]
    fn raw(&self, x: i32, y: i32, z: i32) -> u8 {
        self.pad[pidx(x, y, z)]
    }

    #[inline]
    fn opaque(&self, x: i32, y: i32, z: i32) -> bool {
        OPAQUE_BY_ID[(self.raw(x, y, z) & 31) as usize]
    }

    #[inline]
    fn ground(&self, x: i32, z: i32) -> i32 {
        self.hpad[((z + 1) as usize) * PAD_XZ + (x + 1) as usize] as i32
    }

    fn field_at(&self, vx: f32, vz: f32) -> [f32; 3] {
        let fx = (vx / 4.0).max(0.0).min(3.999);
        let fz = (vz / 4.0).max(0.0).min(3.999);
        let gx = fx as usize;
        let gz = fz as usize;
        let tx = fx - gx as f32;
        let tz = fz - gz as f32;
        let a = &self.tint_grid[gz * 5 + gx];
        let b = &self.tint_grid[gz * 5 + gx + 1];
        let c = &self.tint_grid[(gz + 1) * 5 + gx];
        let d = &self.tint_grid[(gz + 1) * 5 + gx + 1];
        let mut out = [0.0f32; 3];
        for k in 0..3 {
            let top = a[k] + (b[k] - a[k]) * tx;
            let bot = c[k] + (d[k] - c[k]) * tx;
            out[k] = top + (bot - top) * tz;
        }
        out
    }

    /// The colour bytes and tint mode for a vertex of a tile at chunk-local (vx, vz).
    fn tint_bytes(&self, info: Option<TintInfo>, vx: f32, vz: f32) -> ([u8; 3], u8) {
        let info = match info {
            Some(i) => i,
            None => return ([128, 128, 128], 0),
        };
        let f = self.field_at(vx, vz);
        let anchor = match info.anchor {
            Anchor::Grass => &self.palette.grass,
            Anchor::Dry => &self.palette.dry,
            Anchor::Swamp => &self.palette.swamp,
        };
        let mut out = [0u8; 3];
        for k in 0..3 {
            let factor = f[k] / anchor[k].max(1.0);
            let t = 1.0 + (factor - 1.0) * info.strength;
            out[k] = pack_u8(t * 0.5);
        }
        (out, info.mode)
    }

    fn push_vertex(&mut self, pos: [f32; 3], uv: [f32; 2], rgb: [u8; 3], shade: f32, layer: i32, mode: u8) -> u32 {
        let i = self.verts.len() as u32;
        self.verts.push(Vertex {
            pos,
            uv,
            color: [rgb[0], rgb[1], rgb[2], pack_u8(shade)],
            info: [layer as u8, mode, 0, 0],
        });
        i
    }

    fn push_quad(&mut self, pass: usize, v: [u32; 4], flip: bool) {
        let list = &mut self.idx[pass];
        if !flip {
            list.extend_from_slice(&[v[0], v[1], v[2], v[0], v[2], v[3]]);
        } else {
            list.extend_from_slice(&[v[1], v[2], v[3], v[1], v[3], v[0]]);
        }
    }

    // ------------------------------------------------------------------ cube faces

    fn ao_level(&self, x: i32, y: i32, z: i32, face: usize, corner: [i32; 3]) -> usize {
        let n = FACE_NORMAL[face];
        let bx = x + n[0];
        let by = y + n[1];
        let bz = z + n[2];
        // the two tangent axes of this face
        let mut axes = [0usize; 2];
        let mut k = 0;
        for a in 0..3 {
            if n[a] == 0 {
                axes[k] = a;
                k += 1;
            }
        }
        let sign = |a: usize| if corner[a] == 1 { 1 } else { -1 };
        let mut s1 = [0i32; 3];
        let mut s2 = [0i32; 3];
        s1[axes[0]] = sign(axes[0]);
        s2[axes[1]] = sign(axes[1]);
        let side1 = self.opaque(bx + s1[0], by + s1[1], bz + s1[2]);
        let side2 = self.opaque(bx + s2[0], by + s2[1], bz + s2[2]);
        let corner_occ = self.opaque(bx + s1[0] + s2[0], by + s1[1] + s2[1], bz + s1[2] + s2[2]);
        if side1 && side2 {
            0
        } else {
            3 - (side1 as usize + side2 as usize + corner_occ as usize)
        }
    }

    fn cube_face(&mut self, block: Block, face: Face, x: i32, y: i32, z: i32) {
        let fi = face as usize;
        let n = FACE_NORMAL[fi];
        let ny = y + n[1];
        if ny < 0 {
            return; // below the world floor: never visible
        }
        let nraw = self.raw(x + n[0], ny, z + n[2]);
        let nid = (nraw & 31) as usize;
        if OPAQUE_BY_ID[nid] {
            return;
        }
        if block.cutout() && CUTOUT_BY_ID[nid] {
            return;
        }
        let layer = block.cell_for(face);
        if layer < 0 {
            return;
        }
        // cave darkening: faces looking into a cell that lies well under the ground get darker with depth
        let mut light = 1.0f32;
        if y <= self.ground(x, z) - CAVE_DARK_START {
            let buried = self.ground(x + n[0], z + n[2]) - ny;
            if buried >= CAVE_DARK_START {
                let mut step = buried - CAVE_DARK_START;
                if step > MAX_LIGHT_STEP {
                    step = MAX_LIGHT_STEP;
                }
                light = 1.0 - step as f32 * CAVE_DARK_RATE;
            }
        }
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        let range = if block.cutout() { 0.14 } else { 0.07 };
        let shade = FACE_SHADE[fi] * light * variation(wx, y, wz, range);

        // texture orientation variant
        let flags = variant_flags(layer);
        let h = hash3(wx, y, wz).wrapping_add((fi as u32).wrapping_mul(0x9E37_79B1));
        let h = h ^ (h >> 15);
        let do_fx = flags & FLIP_X != 0 && (h & 1) != 0;
        let do_fy = flags & FLIP_Y != 0 && (h & 2) != 0;
        let do_sw = flags & SWAP != 0 && (h & 4) != 0;

        let uvs = match face {
            Face::Top => &UV_TOP,
            Face::Bottom => &UV_BOTTOM,
            _ => &UV_SIDE,
        };
        let tint = tint_for_cell(layer);
        let mut ids = [0u32; 4];
        let mut ao = [3usize; 4];
        for c in 0..4 {
            let corner = FACE_CORNERS[fi][c];
            ao[c] = self.ao_level(x, y, z, fi, corner);
            let mut u = uvs[c][0];
            let mut t = uvs[c][1];
            if do_fx {
                u = 1.0 - u;
            }
            if do_fy {
                t = 1.0 - t;
            }
            if do_sw {
                std::mem::swap(&mut u, &mut t);
            }
            let vx = (x + corner[0]) as f32;
            let vy = (y + corner[1]) as f32;
            let vz = (z + corner[2]) as f32;
            let (rgb, mode) = self.tint_bytes(tint, vx, vz);
            ids[c] = self.push_vertex([vx, vy, vz], [u, t], rgb, shade * AO_SHADE[ao[c]], layer, mode);
        }
        let flip = (ao[0] + ao[2]) < (ao[1] + ao[3]);
        let pass = if block.cutout() { PASS_CUTOUT } else { PASS_OPAQUE };
        self.push_quad(pass, ids, flip);
    }

    // ------------------------------------------------------------------ plants

    fn plant(&mut self, block: Block, x: i32, y: i32, z: i32) {
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        let h = hash3(wx, y, wz);
        let layer = if block == Block::Seagrass {
            if h & 1 == 0 {
                cells::SEAGRASS_A
            } else {
                cells::SEAGRASS_B
            }
        } else {
            block.cell_for(Face::Top)
        };
        if layer < 0 {
            return;
        }
        let tint = tint_for_cell(layer);
        let var = variation(wx, y, wz, 0.16);
        let fx = x as f32;
        let fz = z as f32;
        let fy = y as f32;

        if block.flat() {
            // lily pad: one flat quad just above the water surface
            let py = fy - 0.115;
            let corners = [[0.0f32, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]];
            let mut ids = [0u32; 4];
            for (c, corner) in corners.iter().enumerate() {
                let (rgb, mode) = self.tint_bytes(tint, fx + corner[0], fz + corner[1]);
                let (u, t) = if h & 2 == 0 { (corner[0], corner[1]) } else { (corner[1], corner[0]) };
                ids[c] = self.push_vertex([fx + corner[0], py, fz + corner[1]], [u, t], rgb, 0.95 * var, layer, mode);
            }
            self.push_quad(PASS_DOUBLE, ids, false);
            return;
        }

        // two crossed quads through the cell diagonals, nudged by a per-cell offset
        let ox = (((h >> 8) & 15) as f32 / 15.0) * 0.3 - 0.15;
        let oz = (((h >> 12) & 15) as f32 / 15.0) * 0.3 - 0.15;
        let lo = 0.1f32;
        let hi = 0.9f32;
        let quads: [[[f32; 2]; 2]; 2] = [[[lo, lo], [hi, hi]], [[hi, lo], [lo, hi]]];
        for q in quads.iter() {
            let a = q[0];
            let b = q[1];
            let corners = [
                ([a[0], 0.0, a[1]], [0.0f32, 1.0], 0.78f32),
                ([b[0], 0.0, b[1]], [1.0, 1.0], 0.78),
                ([b[0], 1.0, b[1]], [1.0, 0.0], 1.0),
                ([a[0], 1.0, a[1]], [0.0, 0.0], 1.0),
            ];
            let mut ids = [0u32; 4];
            for (c, (p, uv, s)) in corners.iter().enumerate() {
                let px = fx + p[0] + ox;
                let pz = fz + p[2] + oz;
                let (rgb, mode) = self.tint_bytes(tint, px, pz);
                ids[c] = self.push_vertex([px, fy + p[1], pz], *uv, rgb, s * var, layer, mode);
            }
            self.push_quad(PASS_DOUBLE, ids, false);
        }
    }

    // ------------------------------------------------------------------ water

    fn water_corner_height(&self, x: i32, y: i32, z: i32, cx: i32, cz: i32) -> f32 {
        let mut sum = 0.0f32;
        let mut wsum = 0.0f32;
        for dz in (cz - 1)..=cz {
            for dx in (cx - 1)..=cx {
                let nx = x + dx;
                let nz = z + dz;
                let r = self.raw(nx, y, nz);
                let a = fluid::amount_of(r);
                if a > 0 {
                    if fluid::amount_of(self.raw(nx, y + 1, nz)) > 0 {
                        return 1.0;
                    }
                    let w = if a >= fluid::SOURCE { 10.0 } else { 1.0 };
                    sum += fluid::height_of(a) * w;
                    wsum += w;
                } else if !SOLID_BY_ID[(r & 31) as usize] {
                    wsum += 1.0; // air or a plant: counts as height 0
                }
            }
        }
        if wsum <= 0.0 {
            0.0
        } else {
            sum / wsum
        }
    }

    fn water(&mut self, x: i32, y: i32, z: i32) {
        let depth = (SEA_LEVEL - y).max(0) as f32;
        let depth_shade = (1.0 - 0.012 * depth).max(0.5);
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        let uv_x = (wx.rem_euclid(256)) as f32;
        let uv_z = (wz.rem_euclid(256)) as f32;
        let above = fluid::amount_of(self.raw(x, y + 1, z));
        let layer = cells::WATER;
        let rgb = [128u8, 128, 128];

        if above == 0 {
            let mut ids = [0u32; 4];
            for c in 0..4 {
                let corner = FACE_CORNERS[Face::Top as usize][c];
                let h = self.water_corner_height(x, y, z, corner[0], corner[2]);
                ids[c] = self.push_vertex(
                    [(x + corner[0]) as f32, y as f32 + h, (z + corner[2]) as f32],
                    [uv_x + corner[0] as f32, uv_z + corner[2] as f32],
                    rgb,
                    depth_shade,
                    layer,
                    0,
                );
            }
            self.push_quad(PASS_WATER, ids, false);
        }

        for face in [Face::North, Face::South, Face::East, Face::West] {
            let fi = face as usize;
            let n = FACE_NORMAL[fi];
            let nraw = self.raw(x + n[0], y, z + n[2]);
            if fluid::amount_of(nraw) > 0 || OPAQUE_BY_ID[(nraw & 31) as usize] {
                continue;
            }
            let mut ids = [0u32; 4];
            for c in 0..4 {
                let corner = FACE_CORNERS[fi][c];
                let top = if corner[1] == 1 { self.water_corner_height(x, y, z, corner[0], corner[2]) } else { 0.0 };
                ids[c] = self.push_vertex(
                    [(x + corner[0]) as f32, y as f32 + top, (z + corner[2]) as f32],
                    [uv_x + uv_z + (corner[0] + corner[2]) as f32, y as f32 + top],
                    rgb,
                    0.8 * depth_shade,
                    layer,
                    0,
                );
            }
            self.push_quad(PASS_WATER, ids, false);
        }

        if y > 0 {
            let below = self.raw(x, y - 1, z);
            if fluid::amount_of(below) == 0 && !OPAQUE_BY_ID[(below & 31) as usize] {
                let mut ids = [0u32; 4];
                for c in 0..4 {
                    let corner = FACE_CORNERS[Face::Bottom as usize][c];
                    ids[c] = self.push_vertex(
                        [(x + corner[0]) as f32, y as f32, (z + corner[2]) as f32],
                        [uv_x + corner[0] as f32, uv_z + corner[2] as f32],
                        rgb,
                        0.6 * depth_shade,
                        layer,
                        0,
                    );
                }
                self.push_quad(PASS_WATER, ids, false);
            }
        }
    }
}

/// Builds the mesh of the centre chunk of `input`. All eight neighbours should be present (a missing one
/// reads as air).
pub fn build_chunk_mesh(input: &MeshInput, ctx: &MeshContext) -> ChunkMeshData {
    let center = match &input.chunks[4] {
        Some(c) => c,
        None => return ChunkMeshData::empty(),
    };
    let top_sub = center.top_section();
    if top_sub < 0 {
        return ChunkMeshData::empty();
    }
    let max_y = std::cmp::min(top_sub * 16 + 15, WORLD_HEIGHT - 1);

    // padded copy of the blocks and the height map, so neighbour lookups need no chunk arithmetic
    let mut pad = vec![0u8; PAD_XZ * PAD_XZ * PAD_Y];
    let mut hpad = vec![0i16; PAD_XZ * PAD_XZ];
    for pz in 0..PAD_XZ as i32 {
        for px in 0..PAD_XZ as i32 {
            let lx = px - 1;
            let lz = pz - 1;
            let cdx: usize = if lx < 0 { 0 } else if lx >= 16 { 2 } else { 1 };
            let cdz: usize = if lz < 0 { 0 } else if lz >= 16 { 2 } else { 1 };
            let chunk = match &input.chunks[cdz * 3 + cdx] {
                Some(c) => c,
                None => continue,
            };
            let mx = lx.rem_euclid(16);
            let mz = lz.rem_euclid(16);
            hpad[(pz as usize) * PAD_XZ + px as usize] = chunk.height_map[(mz * 16 + mx) as usize];
            for sub in 0..16usize {
                if let Some(sec) = &chunk.sections[sub] {
                    for ly in 0..16i32 {
                        let y = sub as i32 * 16 + ly;
                        pad[pidx(lx, y, lz)] = sec[(((ly * 16 + mz) * 16) + mx) as usize];
                    }
                }
            }
        }
    }

    let base_x = input.pos.x * 16;
    let base_z = input.pos.z * 16;
    let palette = &ctx.color_field.palette;
    let mut tint_grid = [[0.0f32; 3]; 25];
    for gz in 0..5 {
        for gx in 0..5 {
            tint_grid[gz * 5 + gx] =
                ctx.color_field.grass_at((base_x + gx as i32 * 4) as f64, (base_z + gz as i32 * 4) as f64);
        }
    }

    let mut b = Builder {
        pad,
        hpad,
        base_x,
        base_z,
        palette,
        tint_grid,
        verts: Vec::with_capacity(4096),
        idx: [Vec::new(), Vec::new(), Vec::new(), Vec::new()],
    };

    let mut top_block_y = 0;
    for y in 0..=max_y {
        for z in 0..16 {
            for x in 0..16 {
                let raw = b.raw(x, y, z);
                if raw == 0 {
                    continue;
                }
                if y > top_block_y {
                    top_block_y = y;
                }
                let block = Block::from_raw(raw);
                if fluid::amount_of(raw) > 0 {
                    b.water(x, y, z);
                }
                if block.plant() {
                    b.plant(block, x, y, z);
                    continue;
                }
                if block == Block::Water {
                    continue;
                }
                for face in Face::ALL.iter() {
                    b.cube_face(block, *face, x, y, z);
                }
            }
        }
    }

    let mut indices: Vec<u32> = Vec::with_capacity(b.idx.iter().map(|v| v.len()).sum());
    let mut ranges = [(0u32, 0u32); PASS_COUNT];
    for p in 0..PASS_COUNT {
        ranges[p] = (indices.len() as u32, b.idx[p].len() as u32);
        indices.extend_from_slice(&b.idx[p]);
    }
    ChunkMeshData { vertices: b.verts, indices, ranges, max_y: (top_block_y + 2) as f32 }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::terrain::TerrainGenerator;
    use crate::mesh::biome_color::BiomePalette;

    fn context(gen: &TerrainGenerator) -> MeshContext {
        MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        }
    }

    fn input_for(gen: &TerrainGenerator, pos: ChunkPos) -> MeshInput {
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
        for dz in -1..=1 {
            for dx in -1..=1 {
                chunks[((dz + 1) * 3 + (dx + 1)) as usize] = Some(gen.generate(ChunkPos::new(pos.x + dx, pos.z + dz)));
            }
        }
        MeshInput { pos, chunks }
    }

    #[test]
    fn terrain_chunk_produces_a_consistent_mesh() {
        let gen = TerrainGenerator::new(555);
        let ctx = context(&gen);
        let mesh = build_chunk_mesh(&input_for(&gen, ChunkPos::new(0, 0)), &ctx);
        assert!(!mesh.vertices.is_empty());
        assert_eq!(mesh.indices.len() % 3, 0);
        for &i in mesh.indices.iter() {
            assert!((i as usize) < mesh.vertices.len());
        }
        let total: u32 = mesh.ranges.iter().map(|r| r.1).sum();
        assert_eq!(total as usize, mesh.indices.len());
    }

    #[test]
    fn single_block_has_six_faces() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        if let Some(c) = chunks[4].as_mut() {
            c.set(5, 100, 5, Block::Stone);
        }
        let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks }, &ctx);
        assert_eq!(mesh.vertices.len(), 24);
        assert_eq!(mesh.indices.len(), 36);
    }
}
