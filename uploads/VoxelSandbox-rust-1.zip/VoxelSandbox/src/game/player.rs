//! The player: position, look direction and movement mode.

use crate::core::math::{clampf, Vec3};

pub const WIDTH: f32 = 0.6;
pub const HEIGHT: f32 = 1.8;
pub const EYE_HEIGHT: f32 = 1.62;
/// About 89 degrees; avoids a camera flip at the poles.
pub const MAX_PITCH: f32 = 1.5533;

pub struct Player {
    /// Feet position (centre of the footprint).
    pub position: Vec3,
    pub velocity: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub on_ground: bool,
    pub flying: bool,
    /// Held in place until the ground under the spawn point exists.
    pub waiting_for_spawn: bool,
}

impl Player {
    pub fn new() -> Player {
        Player {
            position: Vec3::new(0.0, 48.0, 0.0),
            velocity: Vec3::ZERO,
            yaw: 0.0,
            pitch: 0.0,
            on_ground: false,
            flying: false,
            waiting_for_spawn: true,
        }
    }

    pub fn add_look(&mut self, d_yaw: f32, d_pitch: f32) {
        self.yaw += d_yaw;
        self.pitch = clampf(self.pitch + d_pitch, -MAX_PITCH, MAX_PITCH);
    }

    pub fn eye_x(&self) -> f32 {
        self.position.x
    }

    pub fn eye_y(&self) -> f32 {
        self.position.y + EYE_HEIGHT
    }

    pub fn eye_z(&self) -> f32 {
        self.position.z
    }

    /// Unit vector the player looks along.
    pub fn look_dir(&self) -> Vec3 {
        let cp = self.pitch.cos();
        Vec3::new(cp * self.yaw.sin(), self.pitch.sin(), -cp * self.yaw.cos())
    }
}

impl Default for Player {
    fn default() -> Player {
        Player::new()
    }
}
