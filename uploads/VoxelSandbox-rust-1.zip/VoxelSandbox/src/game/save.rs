//! Saving and loading one world: the seed, the player and every chunk that was edited.
//!
//! Layout (little endian): magic `VSXR`, version u32, seed i64, player (x y z yaw pitch f32, flying u8),
//! hotbar (8 ids, selected u8), chunk count u32, then per chunk: x i32, z i32, byte length u32 and the run-length
//! coded blocks (`count u16, value u8` pairs).

use std::fs;
use std::path::{Path, PathBuf};

use super::hotbar::SIZE as HOTBAR_SIZE;
use crate::world::chunk::ChunkData;
use crate::world::config::BYTES_PER_CHUNK;
use crate::world::pos::ChunkPos;

const MAGIC: [u8; 4] = *b"VSXR";
const VERSION: u32 = 1;
const MAX_CHUNKS: u32 = 200_000;

pub struct LoadedSave {
    pub seed: i64,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub yaw: f32,
    pub pitch: f32,
    pub flying: bool,
    pub hotbar: [u8; HOTBAR_SIZE],
    pub hotbar_selected: u8,
    pub chunks: Vec<(ChunkPos, ChunkData)>,
}

/// Everything `write` needs.
pub struct SaveData<'a> {
    pub seed: i64,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub yaw: f32,
    pub pitch: f32,
    pub flying: bool,
    pub hotbar: [u8; HOTBAR_SIZE],
    pub hotbar_selected: u8,
    pub chunks: &'a [(ChunkPos, Vec<u8>)],
}

pub fn rle_encode(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < data.len() {
        let v = data[i];
        let mut run = 1usize;
        while i + run < data.len() && data[i + run] == v && run < 65535 {
            run += 1;
        }
        out.extend_from_slice(&(run as u16).to_le_bytes());
        out.push(v);
        i += run;
    }
    out
}

/// Inverse of `rle_encode`; `None` if the stream is malformed or does not decode to `expected_len` bytes.
pub fn rle_decode(data: &[u8], expected_len: usize) -> Option<Vec<u8>> {
    if data.len() % 3 != 0 {
        return None;
    }
    let mut out = Vec::with_capacity(expected_len);
    let mut i = 0;
    while i < data.len() {
        let run = u16::from_le_bytes([data[i], data[i + 1]]) as usize;
        let v = data[i + 2];
        if run == 0 || out.len() + run > expected_len {
            return None;
        }
        out.resize(out.len() + run, v);
        i += 3;
    }
    if out.len() == expected_len {
        Some(out)
    } else {
        None
    }
}

pub fn file_path(dir: &Path) -> PathBuf {
    dir.join("world.bin")
}

pub fn exists(dir: &Path) -> bool {
    file_path(dir).exists()
}

pub fn delete(dir: &Path) {
    let _ = fs::remove_file(file_path(dir));
}

pub fn write(dir: &Path, data: &SaveData) -> Result<(), String> {
    let mut out: Vec<u8> = Vec::with_capacity(1 << 16);
    out.extend_from_slice(&MAGIC);
    out.extend_from_slice(&VERSION.to_le_bytes());
    out.extend_from_slice(&data.seed.to_le_bytes());
    for v in [data.x, data.y, data.z, data.yaw, data.pitch] {
        out.extend_from_slice(&v.to_le_bytes());
    }
    out.push(if data.flying { 1 } else { 0 });
    out.extend_from_slice(&data.hotbar);
    out.push(data.hotbar_selected);
    out.extend_from_slice(&(data.chunks.len() as u32).to_le_bytes());
    for (pos, blocks) in data.chunks.iter() {
        let packed = rle_encode(blocks);
        out.extend_from_slice(&pos.x.to_le_bytes());
        out.extend_from_slice(&pos.z.to_le_bytes());
        out.extend_from_slice(&(packed.len() as u32).to_le_bytes());
        out.extend_from_slice(&packed);
    }
    let tmp = dir.join("world.bin.tmp");
    fs::write(&tmp, &out).map_err(|e| e.to_string())?;
    fs::rename(&tmp, file_path(dir)).map_err(|e| e.to_string())
}

struct Reader<'a> {
    data: &'a [u8],
    at: usize,
}

impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> Option<&'a [u8]> {
        if self.at + n > self.data.len() {
            return None;
        }
        let s = &self.data[self.at..self.at + n];
        self.at += n;
        Some(s)
    }

    fn u8(&mut self) -> Option<u8> {
        self.take(1).map(|s| s[0])
    }

    fn u32(&mut self) -> Option<u32> {
        self.take(4).map(|s| u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
    }

    fn i32(&mut self) -> Option<i32> {
        self.u32().map(|v| v as i32)
    }

    fn i64(&mut self) -> Option<i64> {
        self.take(8).map(|s| i64::from_le_bytes([s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7]]))
    }

    fn f32(&mut self) -> Option<f32> {
        self.u32().map(f32::from_bits)
    }
}

pub fn read(dir: &Path) -> Option<LoadedSave> {
    let bytes = fs::read(file_path(dir)).ok()?;
    let mut r = Reader { data: &bytes, at: 0 };
    if r.take(4)? != &MAGIC[..] {
        return None;
    }
    if r.u32()? != VERSION {
        return None;
    }
    let seed = r.i64()?;
    let x = r.f32()?;
    let y = r.f32()?;
    let z = r.f32()?;
    let yaw = r.f32()?;
    let pitch = r.f32()?;
    let flying = r.u8()? != 0;
    let mut hotbar = [0u8; HOTBAR_SIZE];
    hotbar.copy_from_slice(r.take(HOTBAR_SIZE)?);
    let hotbar_selected = r.u8()?;
    let count = r.u32()?;
    if count > MAX_CHUNKS {
        return None;
    }
    let mut chunks = Vec::new();
    for _ in 0..count {
        let cx = r.i32()?;
        let cz = r.i32()?;
        let len = r.u32()? as usize;
        let packed = r.take(len)?;
        let blocks = rle_decode(packed, BYTES_PER_CHUNK)?;
        let data = ChunkData::deserialize(&blocks)?;
        chunks.push((ChunkPos::new(cx, cz), data));
    }
    Some(LoadedSave { seed, x, y, z, yaw, pitch, flying, hotbar, hotbar_selected, chunks })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::block::Block;

    #[test]
    fn rle_round_trips() {
        let mut data = vec![0u8; 70000];
        for i in 100..300 {
            data[i] = 3;
        }
        data[69999] = 9;
        let enc = rle_encode(&data);
        assert_eq!(rle_decode(&enc, data.len()).unwrap(), data);
        assert!(rle_decode(&enc, data.len() - 1).is_none());
    }

    #[test]
    fn save_and_load_a_world() {
        let dir = std::env::temp_dir().join("vs_save_test");
        let _ = fs::create_dir_all(&dir);
        let mut chunk = ChunkData::new();
        chunk.set(4, 80, 4, Block::Stone);
        let chunks = vec![(ChunkPos::new(-2, 5), chunk.serialize())];
        let data = SaveData {
            seed: -77,
            x: 1.5,
            y: 70.0,
            z: -3.25,
            yaw: 0.5,
            pitch: -0.25,
            flying: true,
            hotbar: [1, 2, 3, 4, 5, 6, 7, 8],
            hotbar_selected: 3,
            chunks: &chunks,
        };
        write(&dir, &data).unwrap();
        let loaded = read(&dir).expect("readable");
        assert_eq!(loaded.seed, -77);
        assert_eq!(loaded.hotbar_selected, 3);
        assert!(loaded.flying);
        assert_eq!(loaded.chunks.len(), 1);
        assert_eq!(loaded.chunks[0].0, ChunkPos::new(-2, 5));
        assert_eq!(loaded.chunks[0].1.get(4, 80, 4), Block::Stone);
    }
}
