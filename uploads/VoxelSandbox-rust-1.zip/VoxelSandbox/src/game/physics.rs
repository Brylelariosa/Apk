//! Walking physics: gravity, jumping, auto-jump and axis-by-axis collision against solid blocks.

use super::player::{Player, HEIGHT, WIDTH};
use crate::core::math::{Aabb, Vec3};
use crate::world::config::{VOID_Y, WORLD_HEIGHT};
use crate::world::world::World;

pub const GRAVITY: f32 = 32.0;
pub const TERMINAL_VELOCITY: f32 = -55.0;
pub const JUMP_SPEED: f32 = 8.9;
pub const MOVE_SPEED: f32 = 4.3;

pub const BLOCKED_X: i32 = 1;
pub const BLOCKED_Z: i32 = 2;
pub const BLOCKED_UP: i32 = 4;
pub const BLOCKED_DOWN: i32 = 8;

fn box_at(pos: Vec3) -> Aabb {
    let hw = WIDTH / 2.0;
    Aabb::new(pos.x - hw, pos.y, pos.z - hw, pos.x + hw, pos.y + HEIGHT, pos.z + hw)
}

/// Advances a walking player by `dt` seconds. `world_move_*` is the desired horizontal direction in world
/// space (length 0..~1.4).
pub fn step(
    world: &World,
    player: &mut Player,
    world_move_x: f32,
    world_move_z: f32,
    wants_jump: bool,
    auto_jump: bool,
    dt: f32,
) {
    let mut b = box_at(player.position);
    let effective_jump = wants_jump || (auto_jump && player.on_ground && should_auto_jump(world, &b, world_move_x, world_move_z));

    player.velocity.y = (player.velocity.y - GRAVITY * dt).max(TERMINAL_VELOCITY);
    if effective_jump && player.on_ground {
        player.velocity.y = JUMP_SPEED;
    }

    let dx = resolve_horizontal(world, &b, world_move_x * MOVE_SPEED * dt, true);
    b = b.offset(dx, 0.0, 0.0);
    let dz = resolve_horizontal(world, &b, world_move_z * MOVE_SPEED * dt, false);
    b = b.offset(0.0, 0.0, dz);

    let desired_dy = player.velocity.y * dt;
    let dy = resolve_vertical(world, &b, desired_dy);
    if desired_dy < 0.0 && dy > desired_dy {
        player.on_ground = true;
        player.velocity.y = 0.0;
    } else if desired_dy > 0.0 && dy < desired_dy {
        player.velocity.y = 0.0;
        player.on_ground = false;
    } else {
        player.on_ground = false;
    }
    player.position.add(dx, dy, dz);

    if player.position.y < VOID_Y {
        player.position.set(player.position.x, WORLD_HEIGHT as f32 + 8.0, player.position.z);
        player.velocity.set(0.0, 0.0, 0.0);
    }
}

/// Moves a flying player by (dx, dy, dz), colliding with solid blocks (unless already inside one).
/// Returns `BLOCKED_*` bits describing what stopped the move.
pub fn fly_move(world: &World, player: &mut Player, dx: f32, dy: f32, dz: f32) -> i32 {
    player.on_ground = false;
    let inside = world.is_solid(
        player.position.x.floor() as i32,
        (player.position.y + 0.9).floor() as i32,
        player.position.z.floor() as i32,
    );
    if inside {
        player.position.add(dx, dy, dz);
        return 0;
    }
    let mut b = box_at(player.position);
    let mx = resolve_horizontal(world, &b, dx, true);
    b = b.offset(mx, 0.0, 0.0);
    let mz = resolve_horizontal(world, &b, dz, false);
    b = b.offset(0.0, 0.0, mz);
    let my = resolve_vertical(world, &b, dy);
    player.position.add(mx, my, mz);
    if player.position.y < VOID_Y {
        player.position.set(player.position.x, WORLD_HEIGHT as f32 + 8.0, player.position.z);
    }
    let mut blocked = 0;
    if mx != dx {
        blocked |= BLOCKED_X;
    }
    if mz != dz {
        blocked |= BLOCKED_Z;
    }
    if dy > 0.0 && my < dy {
        blocked |= BLOCKED_UP;
    }
    if dy < 0.0 && my > dy {
        blocked |= BLOCKED_DOWN;
        player.on_ground = true;
    }
    blocked
}

/// True when walking into a one-block step: solid at foot level just ahead, free above it.
fn should_auto_jump(world: &World, b: &Aabb, world_move_x: f32, world_move_z: f32) -> bool {
    let len = (world_move_x * world_move_x + world_move_z * world_move_z).sqrt();
    if len < 0.001 {
        return false;
    }
    let dir_x = world_move_x / len;
    let dir_z = world_move_z / len;
    let hw = WIDTH / 2.0;
    let probe_x = (b.min_x + b.max_x) / 2.0 + dir_x * (hw + 0.15);
    let probe_z = (b.min_z + b.max_z) / 2.0 + dir_z * (hw + 0.15);
    let foot_block_y = (b.min_y + 0.05).floor() as i32;
    let block_x = probe_x.floor() as i32;
    let block_z = probe_z.floor() as i32;
    if !world.is_solid(block_x, foot_block_y, block_z) {
        return false;
    }
    !world.is_solid(block_x, foot_block_y + 1, block_z)
}

fn resolve_horizontal(world: &World, b: &Aabb, delta: f32, is_x: bool) -> f32 {
    if delta == 0.0 {
        return 0.0;
    }
    let mut d = delta;
    let moved = if is_x { b.offset(d, 0.0, 0.0) } else { b.offset(0.0, 0.0, d) };
    let min_x = b.min_x.min(moved.min_x).floor() as i32;
    let max_x = (b.max_x.max(moved.max_x) - 0.001).floor() as i32;
    let min_y = (b.min_y + 0.001).floor() as i32;
    let max_y = (b.max_y - 0.001).floor() as i32;
    let min_z = b.min_z.min(moved.min_z).floor() as i32;
    let max_z = (b.max_z.max(moved.max_z) - 0.001).floor() as i32;
    for bx in min_x..=max_x {
        for by in min_y..=max_y {
            for bz in min_z..=max_z {
                if !world.is_solid(bx, by, bz) {
                    continue;
                }
                if is_x {
                    if d > 0.0 {
                        d = d.min(bx as f32 - b.max_x);
                    } else if d < 0.0 {
                        d = d.max((bx + 1) as f32 - b.min_x);
                    }
                } else if d > 0.0 {
                    d = d.min(bz as f32 - b.max_z);
                } else if d < 0.0 {
                    d = d.max((bz + 1) as f32 - b.min_z);
                }
            }
        }
    }
    d
}

fn resolve_vertical(world: &World, b: &Aabb, delta: f32) -> f32 {
    if delta == 0.0 {
        return 0.0;
    }
    let mut d = delta;
    let moved = b.offset(0.0, d, 0.0);
    let min_x = b.min_x.floor() as i32;
    let max_x = (b.max_x - 0.001).floor() as i32;
    let min_y = b.min_y.min(moved.min_y).floor() as i32;
    let max_y = b.max_y.max(moved.max_y).floor() as i32;
    let min_z = b.min_z.floor() as i32;
    let max_z = (b.max_z - 0.001).floor() as i32;
    for bx in min_x..=max_x {
        for by in min_y..=max_y {
            for bz in min_z..=max_z {
                if !world.is_solid(bx, by, bz) {
                    continue;
                }
                d = if d > 0.0 { d.min(by as f32 - b.max_y) } else { d.max((by + 1) as f32 - b.min_y) };
            }
        }
    }
    d
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::block::Block;
    use crate::world::chunk::ChunkData;
    use crate::world::pos::ChunkPos;

    fn flat_world() -> World {
        let mut w = World::new();
        for cz in -1..=1 {
            for cx in -1..=1 {
                let mut c = ChunkData::new();
                for x in 0..16 {
                    for z in 0..16 {
                        c.set(x, 59, z, Block::Stone);
                    }
                }
                w.insert(ChunkPos::new(cx, cz), c, false);
            }
        }
        w
    }

    #[test]
    fn player_falls_and_lands_on_the_floor() {
        let world = flat_world();
        let mut p = Player::new();
        p.position.set(8.0, 70.0, 8.0);
        for _ in 0..400 {
            step(&world, &mut p, 0.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!(p.on_ground);
        assert!((p.position.y - 60.0).abs() < 0.01, "y = {}", p.position.y);
    }

    #[test]
    fn walls_stop_horizontal_movement() {
        let mut world = flat_world();
        for y in 60..64 {
            world.set_block(10, y, 8, Block::Stone, false);
        }
        let mut p = Player::new();
        p.position.set(8.0, 60.0, 8.5);
        p.on_ground = true;
        for _ in 0..240 {
            step(&world, &mut p, 1.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!(p.position.x < 10.0, "x = {}", p.position.x);
    }
}
