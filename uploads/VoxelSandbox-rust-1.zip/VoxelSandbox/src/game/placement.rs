//! Where and whether a block may be placed.

use super::player::{Player, HEIGHT, WIDTH};
use crate::world::block::Block;
use crate::world::config::WORLD_HEIGHT;
use crate::world::world::World;

const MAX_WATER_COLUMN: i32 = 96;

/// The cell a block really goes into: a lily pad floats up to the water surface.
pub fn target_y(world: &World, block: Block, x: i32, y: i32, z: i32) -> i32 {
    if block != Block::LilyPad {
        return y;
    }
    let mut cy = y;
    let mut steps = 0;
    while steps < MAX_WATER_COLUMN && cy + 1 < WORLD_HEIGHT && world.get_block(x, cy, z).holds_water() {
        cy += 1;
        steps += 1;
    }
    cy
}

pub fn can_place(world: &World, block: Block, x: i32, y: i32, z: i32) -> bool {
    if block == Block::Air {
        return false;
    }
    if y < 1 || y >= WORLD_HEIGHT {
        return false;
    }
    let existing = world.get_block(x, y, z);
    if !existing.replaceable() {
        return false;
    }
    let below = world.get_block(x, y - 1, z);
    if block == Block::LilyPad {
        existing == Block::Air && below.holds_water()
    } else if block == Block::Seagrass {
        existing.holds_water() && below.solid()
    } else if block.plant() {
        (existing == Block::Air || existing.plant()) && !existing.holds_water() && below.solid()
    } else {
        true
    }
}

/// True if putting a solid `block` at (x, y, z) would overlap the player.
pub fn traps_player(player: &Player, block: Block, x: i32, y: i32, z: i32) -> bool {
    if !block.solid() {
        return false;
    }
    let hw = WIDTH / 2.0;
    let px = player.position.x;
    let py = player.position.y;
    let pz = player.position.z;
    px + hw > x as f32
        && px - hw < (x + 1) as f32
        && py + HEIGHT > y as f32
        && py < (y + 1) as f32
        && pz + hw > z as f32
        && pz - hw < (z + 1) as f32
}
