//! What the player is asking for this frame, filled by the touch controls and read by the engine.

pub struct InputState {
    pub move_forward: f32,
    pub move_strafe: f32,
    look_dx: f32,
    look_dy: f32,
    pub jump_held: bool,
    pub break_held: bool,
    pub place_held: bool,
    pub descend_held: bool,
    pub laser_held: bool,
    /// A menu or overlay is open: the world ignores input.
    pub ui_blocked: bool,
    flight_toggle: bool,
}

impl InputState {
    pub fn new() -> InputState {
        InputState {
            move_forward: 0.0,
            move_strafe: 0.0,
            look_dx: 0.0,
            look_dy: 0.0,
            jump_held: false,
            break_held: false,
            place_held: false,
            descend_held: false,
            laser_held: false,
            ui_blocked: false,
            flight_toggle: false,
        }
    }

    pub fn request_flight_toggle(&mut self) {
        self.flight_toggle = true;
    }

    pub fn consume_flight_toggle(&mut self) -> bool {
        let v = self.flight_toggle;
        self.flight_toggle = false;
        v
    }

    pub fn add_look_delta(&mut self, dx: f32, dy: f32) {
        self.look_dx += dx;
        self.look_dy += dy;
    }

    pub fn consume_look_delta(&mut self) -> (f32, f32) {
        let r = (self.look_dx, self.look_dy);
        self.look_dx = 0.0;
        self.look_dy = 0.0;
        r
    }

    /// Releases every held control (when a menu opens or the app pauses).
    pub fn release_all(&mut self) {
        self.move_forward = 0.0;
        self.move_strafe = 0.0;
        self.jump_held = false;
        self.break_held = false;
        self.place_held = false;
        self.descend_held = false;
        self.laser_held = false;
    }
}

impl Default for InputState {
    fn default() -> InputState {
        InputState::new()
    }
}
