//! Creative-flight velocity smoothing: a quick exponential ease towards the target speed.

pub const ACCEL_TIME: f32 = 0.10;
pub const BRAKE_TIME: f32 = 0.06;
const CLIMB_FRACTION: f32 = 0.6;
const CLIMB_MIN: f32 = 8.0;
const CLIMB_MAX: f32 = 60.0;

pub fn climb_speed(fly_speed: f32) -> f32 {
    (fly_speed * CLIMB_FRACTION).max(CLIMB_MIN).min(CLIMB_MAX)
}

/// Target velocity `[x, y, z]` for the given stick / button input at `yaw`.
pub fn target_velocity(forward: f32, strafe: f32, ascend: bool, descend: bool, yaw: f32, fly_speed: f32) -> [f32; 3] {
    let mut f = forward;
    let mut s = strafe;
    let len = (f * f + s * s).sqrt();
    if len > 1.0 {
        f /= len;
        s /= len;
    }
    let up_amount: f32 = if ascend { 1.0 } else { 0.0 };
    let down_amount: f32 = if descend { 1.0 } else { 0.0 };
    let up = up_amount - down_amount;
    [
        (f * yaw.sin() + s * yaw.cos()) * fly_speed,
        up * climb_speed(fly_speed),
        (-f * yaw.cos() + s * yaw.sin()) * fly_speed,
    ]
}

/// Eases `velocity[axis]` towards `target` over `dt` and returns the distance travelled in that time.
pub fn advance(velocity: &mut [f32; 3], axis: usize, target: f32, dt: f32) -> f32 {
    let v0 = velocity[axis];
    let tau = if target.abs() < v0.abs() { BRAKE_TIME } else { ACCEL_TIME };
    let k = (-dt / tau).exp();
    velocity[axis] = target + (v0 - target) * k;
    target * dt + (v0 - target) * tau * (1.0 - k)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn velocity_converges_to_target() {
        let mut v = [0.0f32; 3];
        for _ in 0..120 {
            advance(&mut v, 0, 30.0, 1.0 / 60.0);
        }
        assert!((v[0] - 30.0).abs() < 0.1);
    }
}
