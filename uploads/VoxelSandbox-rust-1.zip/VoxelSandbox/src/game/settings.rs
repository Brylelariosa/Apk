//! User settings, stored as simple `key=value` lines.

use std::fs;
use std::path::Path;

pub const MIN_RENDER_CHUNKS: i32 = 4;
pub const MAX_RENDER_CHUNKS: i32 = 24;
pub const DEFAULT_RENDER_CHUNKS: i32 = 10;
pub const MIN_FLY_SPEED: f32 = 8.0;
pub const MAX_FLY_SPEED: f32 = 200.0;
pub const DEFAULT_FLY_SPEED: f32 = 30.0;

#[derive(Clone, Debug)]
pub struct Settings {
    /// Radius (in chunks) of the fully detailed world around the player.
    pub render_distance: i32,
    pub show_fps: bool,
    pub touch_sensitivity: f32,
    pub look_sensitivity: f32,
    pub view_bobbing: bool,
    pub clouds: bool,
    pub auto_jump: bool,
    pub fly_speed: f32,
}

impl Settings {
    pub fn defaults() -> Settings {
        Settings {
            render_distance: DEFAULT_RENDER_CHUNKS,
            show_fps: false,
            touch_sensitivity: 0.5,
            look_sensitivity: 0.5,
            view_bobbing: true,
            clouds: true,
            auto_jump: true,
            fly_speed: DEFAULT_FLY_SPEED,
        }
    }

    /// Reads `path`; anything missing or unreadable falls back to the default.
    pub fn load(path: &Path) -> Settings {
        let mut s = Settings::defaults();
        let text = match fs::read_to_string(path) {
            Ok(t) => t,
            Err(_) => return s,
        };
        for line in text.lines() {
            let mut parts = line.splitn(2, '=');
            let key = parts.next().unwrap_or("").trim();
            let value = parts.next().unwrap_or("").trim();
            match key {
                "render_distance" => {
                    if let Ok(v) = value.parse::<i32>() {
                        s.render_distance = v.max(MIN_RENDER_CHUNKS).min(MAX_RENDER_CHUNKS);
                    }
                }
                "show_fps" => s.show_fps = value == "true",
                "touch_sensitivity" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.touch_sensitivity = v.max(0.0).min(1.0);
                    }
                }
                "look_sensitivity" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.look_sensitivity = v.max(0.0).min(1.0);
                    }
                }
                "view_bobbing" => s.view_bobbing = value == "true",
                "clouds" => s.clouds = value == "true",
                "auto_jump" => s.auto_jump = value == "true",
                "fly_speed" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.fly_speed = v.max(MIN_FLY_SPEED).min(MAX_FLY_SPEED);
                    }
                }
                _ => {}
            }
        }
        s
    }

    pub fn save(&self, path: &Path) {
        let text = format!(
            "render_distance={}\nshow_fps={}\ntouch_sensitivity={}\nlook_sensitivity={}\nview_bobbing={}\nclouds={}\nauto_jump={}\nfly_speed={}\n",
            self.render_distance,
            self.show_fps,
            self.touch_sensitivity,
            self.look_sensitivity,
            self.view_bobbing,
            self.clouds,
            self.auto_jump,
            self.fly_speed
        );
        if let Err(e) = fs::write(path, text) {
            crate::logw!("could not save settings: {}", e);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn settings_round_trip_through_a_file() {
        let dir = std::env::temp_dir().join("vs_settings_test");
        let _ = fs::create_dir_all(&dir);
        let path = dir.join("settings.txt");
        let mut s = Settings::defaults();
        s.render_distance = 14;
        s.show_fps = true;
        s.fly_speed = 55.0;
        s.save(&path);
        let t = Settings::load(&path);
        assert_eq!(t.render_distance, 14);
        assert!(t.show_fps);
        assert_eq!(t.fly_speed, 55.0);
    }
}
