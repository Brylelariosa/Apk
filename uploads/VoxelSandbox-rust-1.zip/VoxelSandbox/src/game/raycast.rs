//! Picks the block the player is looking at by marching along the view ray.

use crate::world::block::Block;
use crate::world::world::World;

#[derive(Clone, Copy, Debug)]
pub struct RaycastHit {
    pub bx: i32,
    pub by: i32,
    pub bz: i32,
    /// Normal of the face that was entered (all zero when the ray started inside the block).
    pub fx: i32,
    pub fy: i32,
    pub fz: i32,
}

const STEP: f32 = 0.05;
const PLANT_MIN: f32 = 0.15;
const PLANT_MAX: f32 = 0.85;
const PLANT_HEIGHT: f32 = 0.8;
const FLAT_HEIGHT: f32 = 0.2;

/// Plants are only "hit" inside their small visible box, so the ray reaches the block behind a tuft.
fn inside_plant_box(block: Block, lx: f32, ly: f32, lz: f32) -> bool {
    if block.flat() {
        return ly < FLAT_HEIGHT;
    }
    lx > PLANT_MIN && lx < PLANT_MAX && lz > PLANT_MIN && lz < PLANT_MAX && ly < PLANT_HEIGHT
}

pub fn cast(
    world: &World,
    ox: f32,
    oy: f32,
    oz: f32,
    dx: f32,
    dy: f32,
    dz: f32,
    max_dist: f32,
) -> Option<RaycastHit> {
    let mut t = 0.0f32;
    let mut last_bx = ox.floor() as i32;
    let mut last_by = oy.floor() as i32;
    let mut last_bz = oz.floor() as i32;
    let mut cell_bx = i32::MIN;
    let mut cell_by = 0;
    let mut cell_bz = 0;
    let mut cell_block = Block::Air;
    while t < max_dist {
        let x = ox + dx * t;
        let y = oy + dy * t;
        let z = oz + dz * t;
        let bx = x.floor() as i32;
        let by = y.floor() as i32;
        let bz = z.floor() as i32;
        if bx != cell_bx || by != cell_by || bz != cell_bz {
            cell_block = world.get_block(bx, by, bz);
            cell_bx = bx;
            cell_by = by;
            cell_bz = bz;
        }
        let block = cell_block;
        if block != Block::Air
            && block != Block::Water
            && (!block.plant() || inside_plant_box(block, x - bx as f32, y - by as f32, z - bz as f32))
        {
            let ddx = last_bx - bx;
            let ddy = last_by - by;
            let ddz = last_bz - bz;
            let (fx, fy, fz) = if ddx != 0 && ddx.abs() >= ddy.abs() && ddx.abs() >= ddz.abs() {
                (ddx, 0, 0)
            } else if ddy != 0 && ddy.abs() >= ddz.abs() {
                (0, ddy, 0)
            } else if ddz != 0 {
                (0, 0, ddz)
            } else {
                (0, 0, 0)
            };
            return Some(RaycastHit { bx, by, bz, fx, fy, fz });
        }
        last_bx = bx;
        last_by = by;
        last_bz = bz;
        t += STEP;
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::chunk::ChunkData;
    use crate::world::pos::ChunkPos;

    #[test]
    fn ray_hits_a_block_and_reports_the_entered_face() {
        let mut w = World::new();
        w.insert(ChunkPos::new(0, 0), ChunkData::new(), false);
        w.set_block(8, 70, 8, Block::Stone, false);
        let hit = cast(&w, 3.5, 70.5, 8.5, 1.0, 0.0, 0.0, 6.0).expect("should hit");
        assert_eq!((hit.bx, hit.by, hit.bz), (8, 70, 8));
        assert_eq!((hit.fx, hit.fy, hit.fz), (-1, 0, 0));
        assert!(cast(&w, 3.5, 70.5, 8.5, -1.0, 0.0, 0.0, 6.0).is_none());
    }
}
