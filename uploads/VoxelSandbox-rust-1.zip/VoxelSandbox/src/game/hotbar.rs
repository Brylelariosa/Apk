//! The eight quick-access slots.

use crate::world::block::Block;

pub const SIZE: usize = 8;
const DEFAULT_LAYOUT: [Block; SIZE] = [
    Block::Grass,
    Block::Dirt,
    Block::Stone,
    Block::Sand,
    Block::Wood,
    Block::Leaves,
    Block::CoalOre,
    Block::Water,
];

pub struct Hotbar {
    ids: [u8; SIZE],
    selected: usize,
}

impl Hotbar {
    pub fn new() -> Hotbar {
        let mut ids = [0u8; SIZE];
        for i in 0..SIZE {
            ids[i] = DEFAULT_LAYOUT[i].id();
        }
        Hotbar { ids, selected: 0 }
    }

    pub fn selected_index(&self) -> usize {
        self.selected
    }

    pub fn block_at(&self, index: usize) -> Block {
        if index < SIZE {
            Block::from_raw(self.ids[index])
        } else {
            Block::Air
        }
    }

    pub fn selected_block(&self) -> Block {
        self.block_at(self.selected)
    }

    pub fn select(&mut self, index: usize) {
        if index < SIZE {
            self.selected = index;
        }
    }

    fn index_of(&self, block: Block) -> Option<usize> {
        self.ids.iter().position(|&i| i == block.id())
    }

    /// Puts `block` where the player can use it: selects its slot if it is already there, else replaces
    /// the selected slot.
    pub fn pick(&mut self, block: Block) {
        if block == Block::Air {
            return;
        }
        if let Some(i) = self.index_of(block) {
            self.selected = i;
            return;
        }
        self.ids[self.selected] = block.id();
    }

    pub fn export_ids(&self) -> [u8; SIZE] {
        self.ids
    }

    pub fn restore(&mut self, saved: &[u8], selected: usize) {
        for i in 0..SIZE {
            let b = if i < saved.len() { Block::from_raw(saved[i]) } else { Block::Air };
            let valid = b != Block::Air && b.id() == saved.get(i).copied().unwrap_or(255);
            self.ids[i] = if valid { b.id() } else { DEFAULT_LAYOUT[i].id() };
        }
        self.selected = if selected < SIZE { selected } else { 0 };
    }
}

impl Default for Hotbar {
    fn default() -> Hotbar {
        Hotbar::new()
    }
}
