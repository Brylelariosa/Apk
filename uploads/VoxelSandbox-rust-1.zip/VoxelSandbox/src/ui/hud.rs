//! The in-game touch controls: a joystick, action buttons, the hotbar and the crosshair.

use super::batch::{rgba, Color, UiBatch};
use super::touch::{Role, Touches};
use crate::game::hotbar::{Hotbar, SIZE as HOTBAR_SIZE};
use crate::game::input::InputState;

pub const BTN_JUMP: u8 = 0;
pub const BTN_BREAK: u8 = 1;
pub const BTN_PLACE: u8 = 2;
pub const BTN_DESCEND: u8 = 3;
pub const BTN_LASER: u8 = 4;
pub const BTN_FLY: u8 = 5;
pub const BTN_INVENTORY: u8 = 6;
pub const BTN_PAUSE: u8 = 7;
/// Buttons up to this id are held while a finger rests on them; the others react to taps.
const LAST_HELD_BUTTON: u8 = BTN_LASER;

const DEAD_ZONE: f32 = 0.12;

#[derive(Clone, Copy, Debug)]
pub struct ButtonDef {
    pub id: u8,
    pub cx: f32,
    pub cy: f32,
    pub r: f32,
    pub label: &'static str,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum TapTarget {
    None,
    Fly,
    Inventory,
    Pause,
    Hotbar(usize),
}

#[derive(Clone, Debug)]
pub struct HudLayout {
    pub joy_cx: f32,
    pub joy_cy: f32,
    pub joy_r: f32,
    pub buttons: Vec<ButtonDef>,
    pub hotbar_x: f32,
    pub hotbar_y: f32,
    pub slot: f32,
    pub gap: f32,
    pub scale: f32,
}

impl HudLayout {
    /// Positions follow the v15 layout; `s` is pixels per dp, `w` x `h` the screen in pixels.
    pub fn compute(w: f32, h: f32, s: f32) -> HudLayout {
        let btn = |id: u8, size_dp: f32, from_right_dp: f32, from_bottom_dp: f32, label: &'static str| ButtonDef {
            id,
            r: size_dp * 0.5 * s,
            cx: w - (from_right_dp + size_dp * 0.5) * s,
            cy: h - (from_bottom_dp + size_dp * 0.5) * s,
            label,
        };
        let top_btn = |id: u8, from_right_dp: f32, label: &'static str| ButtonDef {
            id,
            r: 24.0 * s,
            cx: w - (from_right_dp + 24.0) * s,
            cy: (12.0 + 24.0) * s,
            label,
        };
        let buttons = vec![
            btn(BTN_JUMP, 68.0, 18.0, 18.0, "JUMP"),
            btn(BTN_BREAK, 58.0, 100.0, 18.0, "BREAK"),
            btn(BTN_PLACE, 58.0, 172.0, 18.0, "PLACE"),
            btn(BTN_DESCEND, 58.0, 18.0, 100.0, "DOWN"),
            btn(BTN_LASER, 58.0, 100.0, 90.0, "LASER"),
            top_btn(BTN_FLY, 128.0, "FLY"),
            top_btn(BTN_INVENTORY, 70.0, "INV"),
            top_btn(BTN_PAUSE, 12.0, "II"),
        ];
        let w_dp = w / s;
        let free_dp = w_dp - 2.0 * (128.0 + 48.0 + 8.0);
        let mut slot_dp = free_dp / HOTBAR_SIZE as f32 - 3.0;
        if slot_dp > 44.0 {
            slot_dp = 44.0;
        }
        if slot_dp < 26.0 {
            slot_dp = 26.0;
        }
        let gap = 3.0 * s;
        let slot = slot_dp * s;
        let total = HOTBAR_SIZE as f32 * slot + (HOTBAR_SIZE as f32 - 1.0) * gap;
        HudLayout {
            joy_cx: (18.0 + 75.0) * s,
            joy_cy: h - (18.0 + 75.0) * s,
            joy_r: 75.0 * s,
            buttons,
            hotbar_x: (w - total) * 0.5,
            hotbar_y: 10.0 * s,
            slot,
            gap,
            scale: s,
        }
    }

    fn button_at(&self, x: f32, y: f32) -> Option<ButtonDef> {
        for b in self.buttons.iter() {
            let dx = x - b.cx;
            let dy = y - b.cy;
            if dx * dx + dy * dy <= (b.r * 1.15) * (b.r * 1.15) {
                return Some(*b);
            }
        }
        None
    }

    fn hotbar_slot_at(&self, x: f32, y: f32) -> Option<usize> {
        if y < self.hotbar_y || y > self.hotbar_y + self.slot {
            return None;
        }
        for i in 0..HOTBAR_SIZE {
            let sx = self.hotbar_x + i as f32 * (self.slot + self.gap);
            if x >= sx && x <= sx + self.slot {
                return Some(i);
            }
        }
        None
    }

    /// What a new finger at (x, y) will do for as long as it stays down.
    pub fn assign_role(&self, x: f32, y: f32, joystick_busy: bool) -> Role {
        if let Some(b) = self.button_at(x, y) {
            return if b.id <= LAST_HELD_BUTTON { Role::Button(b.id) } else { Role::Ui };
        }
        if self.hotbar_slot_at(x, y).is_some() {
            return Role::Ui;
        }
        let dx = x - self.joy_cx;
        let dy = y - self.joy_cy;
        if !joystick_busy && dx * dx + dy * dy <= (self.joy_r * 1.3) * (self.joy_r * 1.3) {
            return Role::Joystick;
        }
        Role::Look
    }

    pub fn tap_target(&self, x: f32, y: f32) -> TapTarget {
        if let Some(b) = self.button_at(x, y) {
            return match b.id {
                BTN_FLY => TapTarget::Fly,
                BTN_INVENTORY => TapTarget::Inventory,
                BTN_PAUSE => TapTarget::Pause,
                _ => TapTarget::None,
            };
        }
        if let Some(i) = self.hotbar_slot_at(x, y) {
            return TapTarget::Hotbar(i);
        }
        TapTarget::None
    }
}

/// Turns the current fingers into movement, look and button state.
pub fn apply_touches(layout: &HudLayout, touches: &mut Touches, input: &mut InputState) {
    let mut forward = 0.0f32;
    let mut strafe = 0.0f32;
    let mut jump = false;
    let mut brk = false;
    let mut place = false;
    let mut descend = false;
    let mut laser = false;
    let mut look_dx = 0.0f32;
    let mut look_dy = 0.0f32;
    for t in touches.active.iter_mut() {
        match t.role {
            Role::Joystick => {
                let dx = t.x - layout.joy_cx;
                let dy = t.y - layout.joy_cy;
                let len = (dx * dx + dy * dy).sqrt();
                if len > 0.001 {
                    let mag = (len / layout.joy_r).min(1.0);
                    if mag > DEAD_ZONE {
                        let m = (mag - DEAD_ZONE) / (1.0 - DEAD_ZONE);
                        strafe = dx / len * m;
                        forward = -dy / len * m;
                    }
                }
            }
            Role::Button(id) => match id {
                BTN_JUMP => jump = true,
                BTN_BREAK => brk = true,
                BTN_PLACE => place = true,
                BTN_DESCEND => descend = true,
                BTN_LASER => laser = true,
                _ => {}
            },
            Role::Look => {
                look_dx += t.pending_dx;
                look_dy += t.pending_dy;
                t.pending_dx = 0.0;
                t.pending_dy = 0.0;
            }
            _ => {}
        }
    }
    input.move_forward = forward;
    input.move_strafe = strafe;
    input.jump_held = jump;
    input.break_held = brk;
    input.place_held = place;
    input.descend_held = descend;
    input.laser_held = laser;
    if look_dx != 0.0 || look_dy != 0.0 {
        input.add_look_delta(look_dx, look_dy);
    }
}

fn label_px(label: &str, r: f32) -> f32 {
    let font_px = (label.chars().count() * 6 - 1) as f32;
    ((2.0 * r * 0.72) / font_px).round().max(1.0)
}

fn pressed(touches: &Touches, id: u8) -> bool {
    touches.active.iter().any(|t| t.role == Role::Button(id))
}

pub fn draw(
    layout: &HudLayout,
    batch: &mut UiBatch,
    touches: &Touches,
    hotbar: &Hotbar,
    flying: bool,
    screen_w: f32,
    screen_h: f32,
) {
    let s = layout.scale;
    // joystick
    batch.circle(layout.joy_cx, layout.joy_cy, layout.joy_r, rgba(255, 255, 255, 40), 40);
    batch.ring(layout.joy_cx, layout.joy_cy, layout.joy_r, layout.joy_r - 2.0 * s, rgba(255, 255, 255, 110), 40);
    let mut knob_x = layout.joy_cx;
    let mut knob_y = layout.joy_cy;
    for t in touches.active.iter() {
        if t.role == Role::Joystick {
            let dx = t.x - layout.joy_cx;
            let dy = t.y - layout.joy_cy;
            let len = (dx * dx + dy * dy).sqrt();
            if len > layout.joy_r {
                knob_x = layout.joy_cx + dx / len * layout.joy_r;
                knob_y = layout.joy_cy + dy / len * layout.joy_r;
            } else {
                knob_x = t.x;
                knob_y = t.y;
            }
        }
    }
    batch.circle(knob_x, knob_y, layout.joy_r * 0.38, rgba(255, 255, 255, 120), 32);

    // buttons
    for b in layout.buttons.iter() {
        let held = match b.id {
            BTN_JUMP | BTN_BREAK | BTN_PLACE | BTN_DESCEND | BTN_LASER => pressed(touches, b.id),
            _ => touches.active.iter().any(|t| {
                let dx = t.x - b.cx;
                let dy = t.y - b.cy;
                dx * dx + dy * dy <= b.r * b.r
            }),
        };
        let lit = b.id == BTN_FLY && flying;
        let fill: Color = if held || lit { rgba(255, 255, 255, 120) } else { rgba(20, 24, 32, 110) };
        batch.circle(b.cx, b.cy, b.r, fill, 32);
        batch.ring(b.cx, b.cy, b.r, b.r - 2.0 * s, rgba(255, 255, 255, 140), 32);
        let px = label_px(b.label, b.r);
        let th = UiBatch::text_height(px);
        batch.text_centered(b.cx, b.cy - th * 0.5, px, b.label, rgba(255, 255, 255, 235));
    }

    draw_hotbar(layout, batch, hotbar);

    // crosshair
    let cx = screen_w * 0.5;
    let cy = screen_h * 0.5;
    let len = 9.0 * s;
    let th = 2.0 * s;
    batch.rect(cx - len, cy - th * 0.5, len * 2.0, th, rgba(255, 255, 255, 170));
    batch.rect(cx - th * 0.5, cy - len, th, len * 2.0, rgba(255, 255, 255, 170));
}

/// The eight quick slots along the top of the screen.
pub fn draw_hotbar(layout: &HudLayout, batch: &mut UiBatch, hotbar: &Hotbar) {
    let s = layout.scale;
    for i in 0..HOTBAR_SIZE {
        let sx = layout.hotbar_x + i as f32 * (layout.slot + layout.gap);
        let sy = layout.hotbar_y;
        let selected = i == hotbar.selected_index();
        batch.rect(sx, sy, layout.slot, layout.slot, if selected { rgba(255, 255, 255, 90) } else { rgba(0, 0, 0, 110) });
        batch.border(
            sx,
            sy,
            layout.slot,
            layout.slot,
            if selected { 3.0 * s } else { 1.5 * s },
            if selected { rgba(255, 255, 255, 255) } else { rgba(255, 255, 255, 90) },
        );
        batch.block_icon(hotbar.block_at(i), sx + layout.slot * 0.5, sy + layout.slot * 0.5, layout.slot * 0.72);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn layout_puts_controls_on_screen_and_assigns_roles() {
        let l = HudLayout::compute(1600.0, 720.0, 2.0);
        for b in l.buttons.iter() {
            assert!(b.cx > 0.0 && b.cx < 1600.0 && b.cy > 0.0 && b.cy < 720.0);
        }
        assert_eq!(l.assign_role(l.joy_cx, l.joy_cy, false), Role::Joystick);
        assert_eq!(l.assign_role(l.joy_cx, l.joy_cy, true), Role::Look);
        assert_eq!(l.assign_role(800.0, 360.0, false), Role::Look);
        let jump = l.buttons[0];
        assert_eq!(l.assign_role(jump.cx, jump.cy, false), Role::Button(BTN_JUMP));
        let pause = l.buttons[7];
        assert_eq!(l.tap_target(pause.cx, pause.cy), TapTarget::Pause);
    }
}
