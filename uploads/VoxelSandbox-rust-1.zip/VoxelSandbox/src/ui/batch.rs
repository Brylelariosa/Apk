//! A CPU-side list of 2D triangles (rectangles, circles, text, block icons) that the renderer draws in one go.

use super::font;
use crate::tex::cells;
use crate::world::block::{Block, Face};

/// Marks a vertex as plain colour.
pub const LAYER_SOLID: f32 = -1.0;
/// Marks a vertex as font coverage (the glyph shape is the alpha).
pub const LAYER_FONT: f32 = -2.0;

pub type Color = [u8; 4];

pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Color {
    [r, g, b, a]
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct UiVertex {
    pub pos: [f32; 2],
    pub uv: [f32; 2],
    pub color: [u8; 4],
    /// >= 0: texture-array layer; `LAYER_SOLID`; `LAYER_FONT`.
    pub layer: f32,
}

pub const UI_VERTEX_SIZE: usize = 24;

pub struct UiBatch {
    pub verts: Vec<UiVertex>,
}

impl UiBatch {
    pub fn new() -> UiBatch {
        UiBatch { verts: Vec::with_capacity(8192) }
    }

    pub fn clear(&mut self) {
        self.verts.clear();
    }

    fn quad(&mut self, p: [[f32; 2]; 4], uv: [[f32; 2]; 4], color: Color, layer: f32) {
        let order = [0usize, 1, 2, 0, 2, 3];
        for &i in order.iter() {
            self.verts.push(UiVertex { pos: p[i], uv: uv[i], color, layer });
        }
    }

    pub fn rect(&mut self, x: f32, y: f32, w: f32, h: f32, color: Color) {
        self.quad(
            [[x, y], [x + w, y], [x + w, y + h], [x, y + h]],
            [[0.0, 0.0]; 4],
            color,
            LAYER_SOLID,
        );
    }

    pub fn border(&mut self, x: f32, y: f32, w: f32, h: f32, t: f32, color: Color) {
        self.rect(x, y, w, t, color);
        self.rect(x, y + h - t, w, t, color);
        self.rect(x, y + t, t, h - 2.0 * t, color);
        self.rect(x + w - t, y + t, t, h - 2.0 * t, color);
    }

    pub fn circle(&mut self, cx: f32, cy: f32, r: f32, color: Color, segments: usize) {
        let n = segments.max(8);
        for i in 0..n {
            let a0 = i as f32 / n as f32 * std::f32::consts::TAU;
            let a1 = (i + 1) as f32 / n as f32 * std::f32::consts::TAU;
            let p0 = [cx + a0.cos() * r, cy + a0.sin() * r];
            let p1 = [cx + a1.cos() * r, cy + a1.sin() * r];
            for p in [[cx, cy], p0, p1] {
                self.verts.push(UiVertex { pos: p, uv: [0.0, 0.0], color, layer: LAYER_SOLID });
            }
        }
    }

    pub fn ring(&mut self, cx: f32, cy: f32, r_out: f32, r_in: f32, color: Color, segments: usize) {
        let n = segments.max(8);
        for i in 0..n {
            let a0 = i as f32 / n as f32 * std::f32::consts::TAU;
            let a1 = (i + 1) as f32 / n as f32 * std::f32::consts::TAU;
            let o0 = [cx + a0.cos() * r_out, cy + a0.sin() * r_out];
            let o1 = [cx + a1.cos() * r_out, cy + a1.sin() * r_out];
            let i0 = [cx + a0.cos() * r_in, cy + a0.sin() * r_in];
            let i1 = [cx + a1.cos() * r_in, cy + a1.sin() * r_in];
            self.quad([o0, o1, i1, i0], [[0.0, 0.0]; 4], color, LAYER_SOLID);
        }
    }

    pub fn text_width(s: &str, px: f32) -> f32 {
        let n = s.chars().count();
        if n == 0 {
            return 0.0;
        }
        (n * font::ADVANCE - 1) as f32 * px
    }

    pub fn text(&mut self, x: f32, y: f32, px: f32, s: &str, color: Color) {
        let mut cx = x;
        for c in s.chars() {
            if c != ' ' {
                let (u0, v0, u1, v1) = font::glyph_uv(c.to_ascii_uppercase());
                let w = font::GLYPH_W as f32 * px;
                let h = font::GLYPH_H as f32 * px;
                self.quad(
                    [[cx, y], [cx + w, y], [cx + w, y + h], [cx, y + h]],
                    [[u0, v0], [u1, v0], [u1, v1], [u0, v1]],
                    color,
                    LAYER_FONT,
                );
            }
            cx += font::ADVANCE as f32 * px;
        }
    }

    /// Text with a one-pixel dark drop shadow, so it reads on any background.
    pub fn text_shadow(&mut self, x: f32, y: f32, px: f32, s: &str, color: Color) {
        self.text(x + px, y + px, px, s, [0, 0, 0, (color[3] as u32 * 170 / 255) as u8]);
        self.text(x, y, px, s, color);
    }

    pub fn text_centered(&mut self, cx: f32, y: f32, px: f32, s: &str, color: Color) {
        let w = UiBatch::text_width(s, px);
        self.text_shadow(cx - w / 2.0, y, px, s, color);
    }

    /// Height of one line of text.
    pub fn text_height(px: f32) -> f32 {
        font::GLYPH_H as f32 * px
    }

    pub fn tex_quad(&mut self, x: f32, y: f32, w: f32, h: f32, layer: i32, color: Color) {
        self.quad(
            [[x, y], [x + w, y], [x + w, y + h], [x, y + h]],
            [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]],
            color,
            layer as f32,
        );
    }

    /// An isometric cube (or a flat sprite for plants) of `size` pixels, centred at (cx, cy).
    pub fn block_icon(&mut self, block: Block, cx: f32, cy: f32, size: f32) {
        if block == Block::Air {
            return;
        }
        if block.plant() {
            let layer = if block == Block::Seagrass { cells::SEAGRASS_A } else { block.cell_for(Face::Top) };
            self.tex_quad(cx - size * 0.5, cy - size * 0.5, size, size, layer, [255, 255, 255, 255]);
            return;
        }
        let r = size * 0.5;
        let k = 0.866 * r;
        let ul = [cx - k, cy - r * 0.5];
        let top = [cx, cy - r];
        let ur = [cx + k, cy - r * 0.5];
        let mid = [cx, cy];
        let lr = [cx + k, cy + r * 0.5];
        let bot = [cx, cy + r];
        let ll = [cx - k, cy + r * 0.5];
        let uv = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
        self.quad([ul, top, ur, mid], uv, [255, 255, 255, 255], block.cell_for(Face::Top) as f32);
        self.quad([ul, mid, bot, ll], uv, [205, 205, 205, 255], block.cell_for(Face::West) as f32);
        self.quad([mid, ur, lr, bot], uv, [150, 150, 150, 255], block.cell_for(Face::East) as f32);
    }
}

impl Default for UiBatch {
    fn default() -> UiBatch {
        UiBatch::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rect_and_text_emit_whole_triangles() {
        let mut b = UiBatch::new();
        b.rect(0.0, 0.0, 10.0, 10.0, [255, 255, 255, 255]);
        assert_eq!(b.verts.len(), 6);
        b.text(0.0, 0.0, 2.0, "Hi 1", [255, 255, 255, 255]);
        assert_eq!(b.verts.len(), 6 + 3 * 6);
        b.block_icon(Block::Stone, 5.0, 5.0, 20.0);
        assert_eq!(b.verts.len() % 3, 0);
    }
}
