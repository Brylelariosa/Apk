//! Multi-touch bookkeeping: which finger is doing what, and which short touches count as taps.

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Role {
    /// Not claimed by a control (menus decide through taps).
    None,
    Joystick,
    Look,
    /// A held on-screen button (the id is the HUD button id).
    Button(u8),
    /// Pressed on a control that only reacts to taps; never turns into a look drag.
    Ui,
}

#[derive(Clone, Copy, Debug)]
pub struct Touch {
    pub id: i32,
    pub x: f32,
    pub y: f32,
    pub start_x: f32,
    pub start_y: f32,
    /// Movement since the HUD last read it (for look drags).
    pub pending_dx: f32,
    pub pending_dy: f32,
    pub role: Role,
    pub age: f32,
    pub moved: bool,
}

pub struct Touches {
    pub active: Vec<Touch>,
    taps: Vec<(f32, f32)>,
}

const TAP_MAX_SECONDS: f32 = 0.6;

impl Touches {
    pub fn new() -> Touches {
        Touches { active: Vec::new(), taps: Vec::new() }
    }

    pub fn down(&mut self, id: i32, x: f32, y: f32, role: Role) {
        self.active.retain(|t| t.id != id);
        self.active.push(Touch { id, x, y, start_x: x, start_y: y, pending_dx: 0.0, pending_dy: 0.0, role, age: 0.0, moved: false });
    }

    pub fn moved(&mut self, id: i32, x: f32, y: f32, slop: f32) {
        for t in self.active.iter_mut() {
            if t.id == id {
                t.pending_dx += x - t.x;
                t.pending_dy += y - t.y;
                t.x = x;
                t.y = y;
                let dx = x - t.start_x;
                let dy = y - t.start_y;
                if dx * dx + dy * dy > slop * slop {
                    t.moved = true;
                }
            }
        }
    }

    /// Lifts a finger. A short touch that barely moved is remembered as a tap at its start position.
    pub fn up(&mut self, id: i32, cancelled: bool) {
        let mut tap = None;
        for t in self.active.iter() {
            if t.id == id && !cancelled && !t.moved && t.age < TAP_MAX_SECONDS {
                tap = Some((t.start_x, t.start_y));
            }
        }
        self.active.retain(|t| t.id != id);
        if let Some(p) = tap {
            self.taps.push(p);
        }
    }

    pub fn tick(&mut self, dt: f32) {
        for t in self.active.iter_mut() {
            t.age += dt;
        }
    }

    pub fn take_taps(&mut self) -> Vec<(f32, f32)> {
        std::mem::take(&mut self.taps)
    }

    pub fn clear(&mut self) {
        self.active.clear();
        self.taps.clear();
    }

    pub fn any_inside(&self, x: f32, y: f32, w: f32, h: f32) -> bool {
        self.active.iter().any(|t| t.x >= x && t.x <= x + w && t.y >= y && t.y <= y + h)
    }
}

impl Default for Touches {
    fn default() -> Touches {
        Touches::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn short_still_touch_is_a_tap_but_a_drag_is_not() {
        let mut t = Touches::new();
        t.down(1, 10.0, 10.0, Role::None);
        t.up(1, false);
        assert_eq!(t.take_taps().len(), 1);
        t.down(2, 10.0, 10.0, Role::Look);
        t.moved(2, 80.0, 10.0, 12.0);
        t.up(2, false);
        assert!(t.take_taps().is_empty());
    }
}
