//! Small shared helpers for the terrain generators (pure functions).

/// Hermite blend: 0 below `a`, 1 above `b`, smooth in between.
pub fn smooth_step(a: f64, b: f64, x: f64) -> f64 {
    let mut t = (x - a) / (b - a);
    if t < 0.0 {
        t = 0.0;
    } else if t > 1.0 {
        t = 1.0;
    }
    t * t * (3.0 - 2.0 * t)
}

/// Piecewise-linear interpolation through `(xs[i], ys[i])`; `xs` ascending, inputs outside clamp.
pub fn interpolate(x: f64, xs: &[f64], ys: &[f64]) -> f64 {
    if x <= xs[0] {
        return ys[0];
    }
    let last = xs.len() - 1;
    if x >= xs[last] {
        return ys[last];
    }
    let mut i = 1;
    while x > xs[i] {
        i += 1;
    }
    let t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
    ys[i - 1] + (ys[i] - ys[i - 1]) * t
}

/// Derives an independent noise seed for feature `salt` from the world seed.
pub fn mix_seed(seed: i64, salt: i32) -> i64 {
    seed.wrapping_mul(6364136223846793005i64)
        .wrapping_add((salt as i64).wrapping_mul(1442695040888963407i64))
        .wrapping_add(0x2545F4914F6CDD1Di64)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn smooth_step_endpoints() {
        assert_eq!(smooth_step(0.0, 1.0, -1.0), 0.0);
        assert_eq!(smooth_step(0.0, 1.0, 2.0), 1.0);
        assert!((smooth_step(0.0, 1.0, 0.5) - 0.5).abs() < 1e-12);
    }

    #[test]
    fn interpolate_clamps_and_blends() {
        let xs = [0.0, 10.0, 20.0];
        let ys = [0.0, 100.0, 0.0];
        assert_eq!(interpolate(-5.0, &xs, &ys), 0.0);
        assert_eq!(interpolate(5.0, &xs, &ys), 50.0);
        assert_eq!(interpolate(30.0, &xs, &ys), 0.0);
    }
}
