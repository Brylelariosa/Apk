//! Deterministic seeded simplex noise (2D and 3D). The same seed always reproduces the same world.

use crate::core::rng::KotlinRandom;

const SCALE: f64 = 99.0;
const F3: f64 = 1.0 / 3.0;
const G3: f64 = 1.0 / 6.0;

/// The 12 gradients of 3D simplex noise: midpoints of the edges of a cube.
const G3X: [f64; 12] = [1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 0.0, 0.0, 0.0, 0.0];
const G3Y: [f64; 12] = [1.0, 1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0, -1.0, 1.0, -1.0];
const G3Z: [f64; 12] = [0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0];

pub struct NoiseGenerator {
    perm: [i32; 512],
    gx: [f64; 16],
    gy: [f64; 16],
    f2: f64,
    g2: f64,
}

fn fast_floor(v: f64) -> i32 {
    let i = v as i32;
    if v < i as f64 {
        i - 1
    } else {
        i
    }
}

impl NoiseGenerator {
    pub fn new(seed: i64) -> NoiseGenerator {
        let mut p = [0i32; 256];
        for (i, slot) in p.iter_mut().enumerate() {
            *slot = i as i32;
        }
        let mut rnd = KotlinRandom::new(seed);
        let mut i = 255usize;
        while i >= 1 {
            let j = rnd.next_int_below(i as i32 + 1) as usize;
            p.swap(i, j);
            i -= 1;
        }
        let mut perm = [0i32; 512];
        for (i, slot) in perm.iter_mut().enumerate() {
            *slot = p[i & 255];
        }
        let mut gx = [0.0f64; 16];
        let mut gy = [0.0f64; 16];
        for k in 0..16 {
            let a = (k as f64 + 0.5) * 2.0 * std::f64::consts::PI / 16.0;
            gx[k] = a.cos();
            gy[k] = a.sin();
        }
        NoiseGenerator {
            perm,
            gx,
            gy,
            f2: 0.5 * (3.0f64.sqrt() - 1.0),
            g2: (3.0 - 3.0f64.sqrt()) / 6.0,
        }
    }

    #[inline]
    fn corner(&self, x: f64, y: f64, g: usize) -> f64 {
        let mut t = 0.5 - x * x - y * y;
        if t <= 0.0 {
            return 0.0;
        }
        t *= t;
        t * t * (self.gx[g] * x + self.gy[g] * y)
    }

    /// Single octave of simplex noise, normalised to roughly [-1, 1].
    pub fn noise2d(&self, x: f64, y: f64) -> f64 {
        let g2 = self.g2;
        let s = (x + y) * self.f2;
        let i = fast_floor(x + s);
        let j = fast_floor(y + s);
        let t = ((i + j) as f64) * g2;
        let x0 = x - (i as f64 - t);
        let y0 = y - (j as f64 - t);
        let i1: i32 = if x0 > y0 { 1 } else { 0 };
        let j1: i32 = 1 - i1;
        let x1 = x0 - i1 as f64 + g2;
        let y1 = y0 - j1 as f64 + g2;
        let x2 = x0 - 1.0 + 2.0 * g2;
        let y2 = y0 - 1.0 + 2.0 * g2;
        let ii = (i & 255) as usize;
        let jj = (j & 255) as usize;
        let p = &self.perm;
        let g0 = (p[ii + p[jj] as usize] & 15) as usize;
        let g1 = (p[ii + i1 as usize + p[jj + j1 as usize] as usize] & 15) as usize;
        let g2i = (p[ii + 1 + p[jj + 1] as usize] & 15) as usize;
        SCALE * (self.corner(x0, y0, g0) + self.corner(x1, y1, g1) + self.corner(x2, y2, g2i))
    }

    /// Fractal Brownian motion: several octaves of the base noise. Result is in ~[-1, 1].
    pub fn fbm2d(&self, x: f64, y: f64, octaves: i32, persistence: f64, lacunarity: f64) -> f64 {
        let mut total = 0.0;
        let mut freq = 1.0;
        let mut amp = 1.0;
        let mut max_amp = 0.0;
        for _ in 0..octaves {
            total += self.noise2d(x * freq, y * freq) * amp;
            max_amp += amp;
            amp *= persistence;
            freq *= lacunarity;
        }
        total / max_amp
    }

    /// Ridged multifractal: sharp crests with broad valleys between them. Result is in ~[0, 1].
    pub fn ridged2d(&self, x: f64, y: f64, octaves: i32, lacunarity: f64, gain: f64) -> f64 {
        let mut total = 0.0;
        let mut freq = 1.0;
        let mut amp = 0.5;
        let mut weight = 1.0;
        let mut norm = 0.0;
        for _ in 0..octaves {
            let mut n = 1.0 - self.noise2d(x * freq, y * freq).abs();
            n *= n;
            total += n * amp * weight;
            norm += amp;
            weight = n * gain;
            if weight < 0.0 {
                weight = 0.0;
            } else if weight > 1.0 {
                weight = 1.0;
            }
            freq *= lacunarity;
            amp *= 0.5;
        }
        total / norm
    }

    #[inline]
    fn corner3(x: f64, y: f64, z: f64, g: usize) -> f64 {
        let mut t = 0.6 - x * x - y * y - z * z;
        if t < 0.0 {
            return 0.0;
        }
        t *= t;
        t * t * (G3X[g] * x + G3Y[g] * y + G3Z[g] * z)
    }

    /// Single octave of 3D simplex noise, normalised to roughly [-1, 1] (caves and ore pockets).
    pub fn noise3d(&self, xin: f64, yin: f64, zin: f64) -> f64 {
        let s = (xin + yin + zin) * F3;
        let i = fast_floor(xin + s);
        let j = fast_floor(yin + s);
        let k = fast_floor(zin + s);
        let t = ((i + j + k) as f64) * G3;
        let x0 = xin - (i as f64 - t);
        let y0 = yin - (j as f64 - t);
        let z0 = zin - (k as f64 - t);
        let (i1, j1, k1, i2, j2, k2): (i32, i32, i32, i32, i32, i32) = if x0 >= y0 {
            if y0 >= z0 {
                (1, 0, 0, 1, 1, 0)
            } else if x0 >= z0 {
                (1, 0, 0, 1, 0, 1)
            } else {
                (0, 0, 1, 1, 0, 1)
            }
        } else if y0 < z0 {
            (0, 0, 1, 0, 1, 1)
        } else if x0 < z0 {
            (0, 1, 0, 0, 1, 1)
        } else {
            (0, 1, 0, 1, 1, 0)
        };
        let x1 = x0 - i1 as f64 + G3;
        let y1 = y0 - j1 as f64 + G3;
        let z1 = z0 - k1 as f64 + G3;
        let x2 = x0 - i2 as f64 + 2.0 * G3;
        let y2 = y0 - j2 as f64 + 2.0 * G3;
        let z2 = z0 - k2 as f64 + 2.0 * G3;
        let x3 = x0 - 1.0 + 3.0 * G3;
        let y3 = y0 - 1.0 + 3.0 * G3;
        let z3 = z0 - 1.0 + 3.0 * G3;
        let ii = (i & 255) as usize;
        let jj = (j & 255) as usize;
        let kk = (k & 255) as usize;
        let p = &self.perm;
        let gi0 = (p[ii + p[jj + p[kk] as usize] as usize] % 12) as usize;
        let gi1 = (p[ii + i1 as usize + p[jj + j1 as usize + p[kk + k1 as usize] as usize] as usize] % 12) as usize;
        let gi2 = (p[ii + i2 as usize + p[jj + j2 as usize + p[kk + k2 as usize] as usize] as usize] % 12) as usize;
        let gi3 = (p[ii + 1 + p[jj + 1 + p[kk + 1] as usize] as usize] % 12) as usize;
        32.0 * (Self::corner3(x0, y0, z0, gi0)
            + Self::corner3(x1, y1, z1, gi1)
            + Self::corner3(x2, y2, z2, gi2)
            + Self::corner3(x3, y3, z3, gi3))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn noise_is_deterministic_and_bounded() {
        let a = NoiseGenerator::new(42);
        let b = NoiseGenerator::new(42);
        let c = NoiseGenerator::new(43);
        let mut differs = false;
        for i in 0..200 {
            let x = i as f64 * 0.37 - 20.0;
            let y = i as f64 * 0.91 + 3.0;
            let n = a.noise2d(x, y);
            assert_eq!(n, b.noise2d(x, y));
            assert!(n.abs() < 1.6, "noise out of range: {}", n);
            let n3 = a.noise3d(x, y, x * 0.5);
            assert!(n3.abs() < 1.6, "3d noise out of range: {}", n3);
            if (n - c.noise2d(x, y)).abs() > 1e-9 {
                differs = true;
            }
        }
        assert!(differs, "different seeds must give different noise");
    }
}
