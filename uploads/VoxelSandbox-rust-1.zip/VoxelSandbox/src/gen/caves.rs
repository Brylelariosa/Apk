//! Carves the underground: winding tunnels, big caverns and a few entrance ramps.
//!
//! Everything is a pure function of the seed and the position, evaluated one chunk at a time on a coarse
//! lattice (every 4 blocks) that is interpolated per block. Lattice cells line up with chunk borders, so
//! a cave runs straight across chunks without a seam. Nothing ever comes closer to the surface than a few
//! blocks (more under water); the only openings are entrance ramps. Carved cells that would touch water
//! are put back as rock, so caves never leak.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use super::genmath::{mix_seed, smooth_step};
use super::noise::NoiseGenerator;
use super::shape::TerrainShape;
use crate::world::block::Block;
use crate::world::chunk::ChunkData;
use crate::world::config::{SEA_LEVEL, WORLD_HEIGHT};

const CS: i32 = 16;
const LATTICE: usize = 5;
const LAYERS: usize = 4;
const MAX_NY: usize = 24;
const SEA_I: i32 = SEA_LEVEL;
const Y_LO: i32 = 6;
const Y_CAP: i32 = SEA_LEVEL + 24;
const COVER_LAND: i32 = 6;
const COVER_WATER: i32 = 9;

const FREQ: f64 = 1.0 / 100.0;
const BASE_Y: [f64; LAYERS] = [16.0, 30.0, 45.0, 62.0];
const Y_AMP: f64 = 9.0;
const R_MIN: f64 = 2.0;
const R_MAX: f64 = 4.2;
const SYS_FREQ: f64 = 1.0 / 260.0;
const SYS_LO: f64 = 0.0;
const SYS_HI: f64 = 0.40;

const CAV_FREQ: f64 = 1.0 / 42.0;
const CAV_THRESHOLD: f64 = 0.66;

const SITE_CELL: i32 = 96;
const SITE_CHANCE: f64 = 0.34;
const RAMP_SLOPE: f64 = 0.7;
const MOUTH_ZONE: f64 = 60.0;
const MOUTH_CLEAR: f64 = 12.0;
const MOUTH_REACH: i32 = 52;
const MAX_CACHED_SITES: usize = 40000;

#[derive(Clone, Copy)]
struct Site {
    x: f64,
    z: f64,
    ground_y: i32,
    dir_x: f64,
    dir_z: f64,
    length: i32,
    phase: f64,
}

pub struct CaveCarver {
    salt: i64,
    contour_noise: Vec<NoiseGenerator>,
    detail_noise: Vec<NoiseGenerator>,
    center_noise: Vec<NoiseGenerator>,
    radius_noise: Vec<NoiseGenerator>,
    system_noise: NoiseGenerator,
    cavern_noise: NoiseGenerator,
    shape: Arc<TerrainShape>,
    sites: Mutex<HashMap<i64, Option<Site>>>,
}

fn bilinear(f: &[f32; LATTICE * LATTICE], gx: usize, gz: usize, fx: f64, fz: f64) -> f64 {
    let i = gz * LATTICE + gx;
    let a = f[i] as f64 + ((f[i + 1] - f[i]) as f64) * fx;
    let b = f[i + LATTICE] as f64 + ((f[i + LATTICE + 1] - f[i + LATTICE]) as f64) * fx;
    a + (b - a) * fz
}

#[allow(clippy::too_many_arguments)]
fn trilinear(f: &[f32], gx: usize, gz: usize, gy: usize, ny: usize, fx: f64, fy: f64, fz: f64) -> f64 {
    let i000 = (gz * LATTICE + gx) * ny + gy;
    let i100 = (gz * LATTICE + gx + 1) * ny + gy;
    let i010 = ((gz + 1) * LATTICE + gx) * ny + gy;
    let i110 = ((gz + 1) * LATTICE + gx + 1) * ny + gy;
    let c00 = f[i000] as f64 + ((f[i100] - f[i000]) as f64) * fx;
    let c10 = f[i010] as f64 + ((f[i110] - f[i010]) as f64) * fx;
    let c01 = f[i000 + 1] as f64 + ((f[i100 + 1] - f[i000 + 1]) as f64) * fx;
    let c11 = f[i010 + 1] as f64 + ((f[i110 + 1] - f[i010 + 1]) as f64) * fx;
    let c0 = c00 + (c10 - c00) * fz;
    let c1 = c01 + (c11 - c01) * fz;
    c0 + (c1 - c0) * fy
}

/// True if any of the six neighbours of the cell (inside this chunk) holds water.
fn touches_water(chunk: &ChunkData, lx: i32, y: i32, lz: i32) -> bool {
    if lx > 0 && chunk.get(lx - 1, y, lz).holds_water() {
        return true;
    }
    if lx < CS - 1 && chunk.get(lx + 1, y, lz).holds_water() {
        return true;
    }
    if lz > 0 && chunk.get(lx, y, lz - 1).holds_water() {
        return true;
    }
    if lz < CS - 1 && chunk.get(lx, y, lz + 1).holds_water() {
        return true;
    }
    if y < WORLD_HEIGHT - 1 && chunk.get(lx, y + 1, lz).holds_water() {
        return true;
    }
    if y > 0 && chunk.get(lx, y - 1, lz).holds_water() {
        return true;
    }
    false
}

impl CaveCarver {
    pub fn new(seed: i64, shape: Arc<TerrainShape>) -> CaveCarver {
        let mut contour_noise = Vec::new();
        let mut detail_noise = Vec::new();
        let mut center_noise = Vec::new();
        let mut radius_noise = Vec::new();
        for l in 0..LAYERS as i32 {
            contour_noise.push(NoiseGenerator::new(mix_seed(seed, 50 + l)));
            detail_noise.push(NoiseGenerator::new(mix_seed(seed, 60 + l)));
            center_noise.push(NoiseGenerator::new(mix_seed(seed, 70 + l)));
            radius_noise.push(NoiseGenerator::new(mix_seed(seed, 80 + l)));
        }
        CaveCarver {
            salt: mix_seed(seed, 99),
            contour_noise,
            detail_noise,
            center_noise,
            radius_noise,
            system_noise: NoiseGenerator::new(mix_seed(seed, 90)),
            cavern_noise: NoiseGenerator::new(mix_seed(seed, 91)),
            shape,
            sites: Mutex::new(HashMap::new()),
        }
    }

    /// Carves tunnels, caverns and entrance ramps into `chunk` (whose terrain is already filled in).
    /// `ground` is the top solid Y of each column (index `lz * 16 + lx`), `under_water` says whether it is below the sea.
    pub fn carve(&self, chunk: &mut ChunkData, bx: i32, bz: i32, ground: &[i32], under_water: &[bool]) {
        self.carve_network(chunk, bx, bz, ground, under_water);
        self.carve_mouths(chunk, bx, bz, ground, under_water);
    }

    // ------------------------------------------------------------------ tunnels + caverns

    fn carve_network(&self, chunk: &mut ChunkData, bx: i32, bz: i32, ground: &[i32], under_water: &[bool]) {
        let mut limit = [0i32; 256];
        let mut y_top = 0;
        for i in 0..256 {
            let cover = if under_water[i] { COVER_WATER } else { COVER_LAND };
            let lim = std::cmp::min(ground[i] - cover, Y_CAP);
            limit[i] = lim;
            if lim > y_top {
                y_top = lim;
            }
        }
        if y_top < Y_LO {
            return;
        }

        let mut contour = [[0.0f32; LATTICE * LATTICE]; LAYERS];
        let mut center_y = [[0.0f32; LATTICE * LATTICE]; LAYERS];
        let mut radius = [[0.0f32; LATTICE * LATTICE]; LAYERS];
        let mut system = [0.0f32; LATTICE * LATTICE];

        // 1. sample the fields on the lattice
        for gz in 0..LATTICE {
            for gx in 0..LATTICE {
                let x = (bx + gx as i32 * 4) as f64;
                let z = (bz + gz as i32 * 4) as f64;
                let k = gz * LATTICE + gx;
                system[k] = smooth_step(SYS_LO, SYS_HI, self.system_noise.fbm2d(x * SYS_FREQ, z * SYS_FREQ, 2, 0.5, 2.0)) as f32;
                for l in 0..LAYERS {
                    contour[l][k] = (self.contour_noise[l].noise2d(x * FREQ, z * FREQ)
                        + 0.25 * self.detail_noise[l].noise2d(x * FREQ * 2.6, z * FREQ * 2.6)) as f32;
                    center_y[l][k] = (BASE_Y[l] + Y_AMP * self.center_noise[l].noise2d(x / 90.0, z / 90.0)) as f32;
                    radius[l][k] = (R_MIN + (R_MAX - R_MIN) * (0.5 + 0.5 * self.radius_noise[l].noise2d(x / 55.0, z / 55.0))) as f32;
                }
            }
        }
        let ny = ((y_top - Y_LO) / 4 + 2) as usize;
        let mut cavern = vec![0.0f32; LATTICE * LATTICE * MAX_NY];
        for gz in 0..LATTICE {
            for gx in 0..LATTICE {
                let base = (gz * LATTICE + gx) * ny;
                let x = (bx + gx as i32 * 4) as f64;
                let z = (bz + gz as i32 * 4) as f64;
                for gy in 0..ny {
                    let y = (Y_LO + gy as i32 * 4) as f64;
                    cavern[base + gy] = (0.65 * self.cavern_noise.noise3d(x * CAV_FREQ, y * CAV_FREQ * 1.5, z * CAV_FREQ)
                        + 0.35
                            * self.cavern_noise.noise3d(
                                x * CAV_FREQ * 2.1 + 9.0,
                                y * CAV_FREQ * 3.1,
                                z * CAV_FREQ * 2.1 - 4.0,
                            )) as f32;
                }
            }
        }

        // A lattice cell whose corners are all at or below the threshold contains no cavern block.
        let mut cavern_hot = vec![false; (LATTICE - 1) * (LATTICE - 1) * MAX_NY];
        for gz in 0..LATTICE - 1 {
            for gx in 0..LATTICE - 1 {
                let cell = (gz * (LATTICE - 1) + gx) * MAX_NY;
                for gy in 0..ny - 1 {
                    let i000 = (gz * LATTICE + gx) * ny + gy;
                    let i100 = (gz * LATTICE + gx + 1) * ny + gy;
                    let i010 = ((gz + 1) * LATTICE + gx) * ny + gy;
                    let i110 = ((gz + 1) * LATTICE + gx + 1) * ny + gy;
                    let mut hi = cavern[i000];
                    for idx in [i000 + 1, i100, i100 + 1, i010, i010 + 1, i110, i110 + 1] {
                        if cavern[idx] > hi {
                            hi = cavern[idx];
                        }
                    }
                    cavern_hot[cell + gy] = (hi as f64) > CAV_THRESHOLD;
                }
            }
        }

        // 2. decide, per column, which cells are carved
        let mut carved = vec![false; (CS * WORLD_HEIGHT * CS) as usize];
        for lz in 0..CS {
            for lx in 0..CS {
                let lim = limit[(lz * CS + lx) as usize];
                if lim < Y_LO {
                    continue;
                }
                let gx = (lx >> 2) as usize;
                let gz = (lz >> 2) as usize;
                let fx = (lx & 3) as f64 * 0.25;
                let fz = (lz & 3) as f64 * 0.25;
                let sys = bilinear(&system, gx, gz, fx, fz);
                if sys > 0.01 {
                    for l in 0..LAYERS {
                        self.carve_tunnel(&contour[l], &center_y[l], &radius[l], &mut carved, gx, gz, fx, fz, sys, lim, lx, lz);
                    }
                }
                let hot_base = (gz * (LATTICE - 1) + gx) * MAX_NY;
                for y in Y_LO..=lim {
                    let gy = ((y - Y_LO) >> 2) as usize;
                    if !cavern_hot[hot_base + gy] {
                        continue;
                    }
                    let fy = (((y - Y_LO) & 3) as f64) * 0.25;
                    let c = trilinear(&cavern, gx, gz, gy, ny, fx, fy, fz);
                    let thr = CAV_THRESHOLD
                        + 0.22 * (1.0 - f64::min(1.0, (y - Y_LO) as f64 / 14.0))
                        + 0.25 * (1.0 - f64::min(1.0, (lim - y + 1) as f64 / 10.0));
                    if c > thr {
                        carved[((y * CS + lz) * CS + lx) as usize] = true;
                    }
                }
            }
        }

        // 3. apply: put air in, but never next to water (seals would-be leaks as rock)
        for lz in 0..CS {
            for lx in 0..CS {
                let lim = limit[(lz * CS + lx) as usize];
                for y in Y_LO..=lim {
                    if !carved[((y * CS + lz) * CS + lx) as usize] {
                        continue;
                    }
                    if touches_water(chunk, lx, y, lz) {
                        continue;
                    }
                    chunk.set(lx, y, lz, Block::Air);
                }
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn carve_tunnel(
        &self,
        f: &[f32; LATTICE * LATTICE],
        center_y: &[f32; LATTICE * LATTICE],
        radius: &[f32; LATTICE * LATTICE],
        carved: &mut [bool],
        gx: usize,
        gz: usize,
        fx: f64,
        fz: f64,
        sys: f64,
        lim: i32,
        lx: i32,
        lz: i32,
    ) {
        let i00 = gz * LATTICE + gx;
        let n00 = f[i00] as f64;
        let n10 = f[i00 + 1] as f64;
        let n01 = f[i00 + LATTICE] as f64;
        let n11 = f[i00 + LATTICE + 1] as f64;
        let n = bilinear(f, gx, gz, fx, fz);
        let gxn = ((n10 - n00) + (n11 - n01)) * 0.5 / 4.0;
        let gzn = ((n01 - n00) + (n11 - n10)) * 0.5 / 4.0;
        let gm = f64::max(1.0e-4, (gxn * gxn + gzn * gzn).sqrt());
        let d = n.abs() / gm; // distance (blocks) to the tunnel's centre line, roughly
        if d > R_MAX * sys + 1.0 {
            return;
        }
        let y0 = bilinear(center_y, gx, gz, fx, fz);
        // never come closer to the surface than the cover allows: the tunnel narrows instead
        let r = f64::min(bilinear(radius, gx, gz, fx, fz) * sys, lim as f64 - y0 + 0.5);
        if r < 1.2 || d >= r {
            return;
        }
        let hh = (r * r - d * d).sqrt();
        let ya = std::cmp::max(Y_LO, (y0 - hh).ceil() as i32);
        let yb = std::cmp::min(lim, (y0 + hh).floor() as i32);
        let mut y = ya;
        while y <= yb {
            carved[((y * CS + lz) * CS + lx) as usize] = true;
            y += 1;
        }
    }

    // ------------------------------------------------------------------ entrance ramps

    /// True if a cave mouth is close enough that its (otherwise hidden) interior should always be meshed.
    pub fn cave_mouth_near(&self, cx: i32, cz: i32) -> bool {
        let mx = (cx * CS) as f64 + CS as f64 / 2.0;
        let mz = (cz * CS) as f64 + CS as f64 / 2.0;
        self.any_site_within(mx, mz, MOUTH_ZONE)
    }

    /// True if (wx, wz) is on or beside a ramp's opening, where trees must not stand.
    pub fn near_mouth(&self, wx: f64, wz: f64) -> bool {
        self.any_site_within(wx, wz, MOUTH_CLEAR)
    }

    fn any_site_within(&self, px: f64, pz: f64, radius: f64) -> bool {
        let c0x = ((px - radius) as i32).div_euclid(SITE_CELL);
        let c1x = ((px + radius) as i32).div_euclid(SITE_CELL);
        let c0z = ((pz - radius) as i32).div_euclid(SITE_CELL);
        let c1z = ((pz + radius) as i32).div_euclid(SITE_CELL);
        for cz in c0z..=c1z {
            for cx in c0x..=c1x {
                let site = match self.site_at(cx, cz) {
                    Some(s) => s,
                    None => continue,
                };
                let dx = site.x - px;
                let dz = site.z - pz;
                if dx * dx + dz * dz <= radius * radius {
                    return true;
                }
            }
        }
        false
    }

    fn carve_mouths(&self, chunk: &mut ChunkData, bx: i32, bz: i32, ground: &[i32], under_water: &[bool]) {
        let reach = MOUTH_REACH;
        let c0x = (bx - reach).div_euclid(SITE_CELL);
        let c1x = (bx + CS + reach).div_euclid(SITE_CELL);
        let c0z = (bz - reach).div_euclid(SITE_CELL);
        let c1z = (bz + CS + reach).div_euclid(SITE_CELL);
        for cz in c0z..=c1z {
            for cx in c0x..=c1x {
                if let Some(site) = self.site_at(cx, cz) {
                    self.carve_ramp(chunk, ground, under_water, &site, bx, bz);
                }
            }
        }
    }

    fn carve_ramp(&self, chunk: &mut ChunkData, ground: &[i32], under_water: &[bool], site: &Site, bx: i32, bz: i32) {
        for t in -2..=site.length {
            let tf = t as f64;
            let cx = site.x + site.dir_x * tf;
            let cz = site.z + site.dir_z * tf;
            let cy = site.ground_y as f64 + 1.0 - RAMP_SLOPE * tf;
            let r = if t == site.length { 3.8 } else { 2.5 + 0.6 * (tf * 0.4 + site.phase).sin() };
            self.carve_sphere(chunk, ground, under_water, cx, cy, cz, r, bx, bz);
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn carve_sphere(
        &self,
        chunk: &mut ChunkData,
        ground: &[i32],
        under_water: &[bool],
        cx: f64,
        cy: f64,
        cz: f64,
        r: f64,
        bx: i32,
        bz: i32,
    ) {
        let x0 = std::cmp::max(bx, (cx - r).floor() as i32);
        let x1 = std::cmp::min(bx + CS - 1, (cx + r).ceil() as i32);
        let z0 = std::cmp::max(bz, (cz - r).floor() as i32);
        let z1 = std::cmp::min(bz + CS - 1, (cz + r).ceil() as i32);
        if x0 > x1 || z0 > z1 {
            return;
        }
        let y0 = std::cmp::max(3, (cy - r).floor() as i32);
        let r2 = r * r;
        for z in z0..=z1 {
            for x in x0..=x1 {
                let lx = x - bx;
                let lz = z - bz;
                let col = (lz * CS + lx) as usize;
                if under_water[col] || ground[col] < SEA_I + 2 {
                    continue;
                }
                let y1 = std::cmp::min(ground[col], (cy + r).ceil() as i32);
                let dx = x as f64 + 0.5 - cx;
                let dz = z as f64 + 0.5 - cz;
                for y in y0..=y1 {
                    let dy = y as f64 + 0.5 - cy;
                    if dx * dx + dy * dy + dz * dz > r2 {
                        continue;
                    }
                    let block = chunk.get(lx, y, lz);
                    if block == Block::Air || block.holds_water() {
                        continue;
                    }
                    if touches_water(chunk, lx, y, lz) {
                        continue;
                    }
                    chunk.set(lx, y, lz, Block::Air);
                    if y >= ground[col] {
                        Self::clear_above(chunk, lx, y + 1, lz);
                    }
                }
            }
        }
    }

    /// Removes the plants / cactus standing on a cell whose ground was just carved away.
    fn clear_above(chunk: &mut ChunkData, lx: i32, from_y: i32, lz: i32) {
        let mut y = from_y;
        while y < WORLD_HEIGHT {
            let b = chunk.get(lx, y, lz);
            if b.plant() || b == Block::Cactus {
                chunk.set(lx, y, lz, Block::Air);
                y += 1;
            } else {
                return;
            }
        }
    }

    fn site_at(&self, cell_x: i32, cell_z: i32) -> Option<Site> {
        let key = ((cell_x as i64) << 32) ^ ((cell_z as i64) & 0xFFFF_FFFF);
        {
            let guard = match self.sites.lock() {
                Ok(g) => g,
                Err(p) => p.into_inner(),
            };
            if let Some(v) = guard.get(&key) {
                return *v;
            }
        }
        // computed outside the lock: it samples the terrain height and must not stall other threads
        let computed = self.compute_site(cell_x, cell_z);
        let mut guard = match self.sites.lock() {
            Ok(g) => g,
            Err(p) => p.into_inner(),
        };
        if guard.len() > MAX_CACHED_SITES {
            guard.clear();
        }
        guard.insert(key, computed);
        computed
    }

    fn compute_site(&self, cell_x: i32, cell_z: i32) -> Option<Site> {
        let h = self.hash(cell_x, cell_z);
        let hu = h as u64;
        if ((hu & 0xFFFF) as f64 / 65536.0) >= SITE_CHANCE {
            return None;
        }
        let sx = (cell_x * SITE_CELL) as f64 + 14.0 + (((hu >> 16) & 0xFF) as f64) / 255.0 * (SITE_CELL as f64 - 28.0);
        let sz = (cell_z * SITE_CELL) as f64 + 14.0 + (((hu >> 24) & 0xFF) as f64) / 255.0 * (SITE_CELL as f64 - 28.0);
        let gh = self.shape.height(sx, sz, 0).floor() as i32;
        if gh < SEA_I + 6 || gh > SEA_I + 110 {
            return None;
        }
        // enter the hill: walk towards higher ground; on flat land any direction will do
        let gx = (self.shape.height(sx + 6.0, sz, 0) - self.shape.height(sx - 6.0, sz, 0)) / 12.0;
        let gz = (self.shape.height(sx, sz + 6.0, 0) - self.shape.height(sx, sz - 6.0, 0)) / 12.0;
        let gl = (gx * gx + gz * gz).sqrt();
        let (dir_x, dir_z) = if gl > 0.12 {
            (gx / gl, gz / gl)
        } else {
            let ang = (((hu >> 40) & 0xFFFF) as f64) / 65536.0 * 2.0 * std::f64::consts::PI;
            (ang.cos(), ang.sin())
        };
        let length = 30 + ((hu >> 56) & 0xF) as i32;
        let phase = (((hu >> 32) & 0xFF) as f64) / 255.0 * 6.28;
        Some(Site { x: sx, z: sz, ground_y: gh, dir_x, dir_z, length, phase })
    }

    fn hash(&self, cx: i32, cz: i32) -> i64 {
        let mut z = self
            .salt
            .wrapping_add((cx as i64).wrapping_mul(-7046029254386353131i64))
            .wrapping_add((cz as i64).wrapping_mul(0x632BE59BD9B4E019i64));
        z = (z ^ (((z as u64) >> 30) as i64)).wrapping_mul(-4658895280553007687i64);
        z = (z ^ (((z as u64) >> 27) as i64)).wrapping_mul(-7723592293110705685i64);
        z ^ (((z as u64) >> 31) as i64)
    }
}
