//! Temperature, humidity and forest cover as smooth pure functions of position, plus the rules that
//! turn them (with elevation, slope and the distance to the sea) into a [`Biome`] and a [`SurfaceKind`].

use super::genmath::{mix_seed, smooth_step};
use super::noise::NoiseGenerator;
use crate::core::math::clampd;
use crate::world::config::SEA_LEVEL;

/// What covers the ground at a point of dry land.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SurfaceKind {
    Grass,
    DryGrass,
    Desert,
    Beach,
    Snow,
    Rock,
    Gravel,
    Swamp,
}

impl SurfaceKind {
    /// True where the top block is a thin skin over dirt.
    pub fn soil_sides(self) -> bool {
        matches!(self, SurfaceKind::Grass | SurfaceKind::DryGrass | SurfaceKind::Snow | SurfaceKind::Swamp)
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Biome {
    DeepOcean,
    Ocean,
    Lake,
    Beach,
    SnowyShore,
    Plains,
    Forest,
    BirchForest,
    Taiga,
    SnowyPlains,
    SnowyTaiga,
    Savanna,
    Desert,
    Swamp,
    Mountains,
    SnowyPeaks,
}

impl Biome {
    pub fn display_name(self) -> &'static str {
        match self {
            Biome::DeepOcean => "Deep Ocean",
            Biome::Ocean => "Ocean",
            Biome::Lake => "Lake / River",
            Biome::Beach => "Beach",
            Biome::SnowyShore => "Snowy Shore",
            Biome::Plains => "Plains",
            Biome::Forest => "Forest",
            Biome::BirchForest => "Birch Forest",
            Biome::Taiga => "Taiga",
            Biome::SnowyPlains => "Snowy Plains",
            Biome::SnowyTaiga => "Snowy Taiga",
            Biome::Savanna => "Savanna",
            Biome::Desert => "Desert",
            Biome::Swamp => "Swamp",
            Biome::Mountains => "Mountains",
            Biome::SnowyPeaks => "Snowy Peaks",
        }
    }
}

const SWAMP_SOFT_LO: f64 = 0.10;
const SWAMP_SOFT_HI: f64 = 0.90;
/// Sea-level temperature below which water is cold (gravel beds) and the shore is snowy.
pub const COLD: f64 = -0.30;
const T_FREQ: f64 = 0.00030;
const T_SCALE: f64 = 1.3;
const T_OFFSET: f64 = 0.12;
const H_FREQ: f64 = 0.0005;
const H_SCALE: f64 = 1.5;
const LAPSE: f64 = 0.0055;
const SAVANNA_MIN_T: f64 = 0.18;
const SAVANNA_HU_MILD: f64 = -0.50;
const SAVANNA_HU_WARM: f64 = -0.12;
const SAVANNA_HU_HOT: f64 = 0.40;
const DRY_BAND: f64 = 0.05;
const FROZEN: f64 = -0.55;
const COLD_MAX: f64 = -0.20;
const TEMPERATE_MAX: f64 = 0.38;
const WARM_MAX: f64 = 0.66;
const SNOW_T: f64 = -0.50;
const ROCK_ALT: f64 = 72.0;
const SWAMP_HUM_LO: f64 = -0.05;
const SWAMP_HUM_HI: f64 = 0.20;
const SWAMP_PATCH_LO: f64 = -0.40;
const SWAMP_PATCH_HI: f64 = 0.0;
const SWAMP_MAX_BASE: f64 = 22.0;
const SWAMP_MAX_ALT: f64 = 14.0;
const SEA: f64 = SEA_LEVEL as f64;

pub struct Climate {
    temperature_noise: NoiseGenerator,
    humidity_noise: NoiseGenerator,
    forest_noise: NoiseGenerator,
    jitter_noise: NoiseGenerator,
    variant_noise: NoiseGenerator,
    swamp_noise: NoiseGenerator,
}

impl Climate {
    pub fn new(seed: i64) -> Climate {
        Climate {
            temperature_noise: NoiseGenerator::new(mix_seed(seed, 11)),
            humidity_noise: NoiseGenerator::new(mix_seed(seed, 12)),
            forest_noise: NoiseGenerator::new(mix_seed(seed, 13)),
            jitter_noise: NoiseGenerator::new(mix_seed(seed, 16)),
            variant_noise: NoiseGenerator::new(mix_seed(seed, 17)),
            swamp_noise: NoiseGenerator::new(mix_seed(seed, 18)),
        }
    }

    /// Sea-level temperature in -1 (arctic) .. 1 (tropical).
    pub fn base_temperature(&self, wx: f64, wz: f64) -> f64 {
        clampd(
            self.temperature_noise.fbm2d(wx * T_FREQ + 31.0, wz * T_FREQ - 17.0, 2, 0.5, 2.0) * T_SCALE + T_OFFSET,
            -1.0,
            1.0,
        )
    }

    /// Humidity in -1 (arid) .. 1 (wet).
    pub fn humidity(&self, wx: f64, wz: f64) -> f64 {
        clampd(
            self.humidity_noise.fbm2d(wx * H_FREQ - 70.0, wz * H_FREQ + 44.0, 2, 0.5, 2.0) * H_SCALE,
            -1.0,
            1.0,
        )
    }

    /// Forest-ness in 0..1 (0 = open ground, 1 = dense forest).
    pub fn forest(&self, wx: f64, wz: f64) -> f64 {
        let f = self.forest_noise.fbm2d(wx * 0.011, wz * 0.011, 2, 0.5, 2.0);
        clampd((f + 0.02) / 0.5, 0.0, 1.0)
    }

    /// 0..1: how swampy the land at (wx, wz) is, given the smooth base elevation above sea level.
    pub fn swamp_weight(&self, wx: f64, wz: f64, base_elev: f64) -> f64 {
        if base_elev < -2.5 || base_elev > SWAMP_MAX_BASE {
            return 0.0;
        }
        let hum = self.humidity(wx, wz);
        if hum < SWAMP_HUM_LO {
            return 0.0;
        }
        let t = self.base_temperature(wx, wz);
        self.swamp_weight_from(wx, wz, base_elev, hum, t)
    }

    /// `swamp_weight` for a caller that already has the humidity and the sea-level temperature.
    pub fn swamp_weight_with(&self, wx: f64, wz: f64, base_elev: f64, hum: f64, t: f64) -> f64 {
        if base_elev < -2.5 || base_elev > SWAMP_MAX_BASE {
            return 0.0;
        }
        if hum < SWAMP_HUM_LO {
            return 0.0;
        }
        self.swamp_weight_from(wx, wz, base_elev, hum, t)
    }

    fn swamp_weight_from(&self, wx: f64, wz: f64, base_elev: f64, hum: f64, t: f64) -> f64 {
        if t < -0.15 || t > 0.74 {
            return 0.0;
        }
        let w = smooth_step(SWAMP_HUM_LO, SWAMP_HUM_HI, hum)
            * smooth_step(-0.20, 0.0, t)
            * (1.0 - smooth_step(0.55, 0.72, t))
            * (1.0 - smooth_step(SWAMP_MAX_BASE - 8.0, SWAMP_MAX_BASE, base_elev));
        let patch = smooth_step(
            SWAMP_PATCH_LO,
            SWAMP_PATCH_HI,
            self.swamp_noise.fbm2d(wx * 0.0035 + 9.0, wz * 0.0035 - 4.0, 2, 0.5, 2.0),
        );
        w * patch
    }

    /// Biome of dry land at ground height `h` with local `slope`; `coast` is the smooth base elevation.
    pub fn biome(&self, wx: f64, wz: f64, h: f64, slope: f64, coast: f64) -> Biome {
        self.biome_with(wx, wz, h, slope, coast, self.base_temperature(wx, wz), self.humidity(wx, wz))
    }

    /// Whether the slope can change the answer of `biome` (only the shore rule reads it).
    pub fn slope_matters(&self, h: f64, coast: f64) -> bool {
        coast < 2.4 && h - SEA < 7.0
    }

    #[allow(clippy::too_many_arguments)]
    pub fn biome_with(&self, wx: f64, wz: f64, h: f64, slope: f64, coast: f64, t0: f64, hum: f64) -> Biome {
        let alt = h - SEA;
        let jt = self.temperature_jitter(wx, wz);
        let jh = self.humidity_jitter(wx, wz);
        let te = self.ground_temperature(t0, jt, h);
        let hu = hum + jh;
        let jr = self.jitter_noise.noise2d(wx * 0.05 + 5.0, wz * 0.05 - 3.0);
        if alt >= ROCK_ALT + jr * 6.0 {
            return if te < SNOW_T { Biome::SnowyPeaks } else { Biome::Mountains };
        }
        if self.slope_matters(h, coast) && slope < 1.1 {
            return if t0 + jt < COLD { Biome::SnowyShore } else { Biome::Beach };
        }
        if alt < SWAMP_MAX_ALT && self.swamp_weight_with(wx, wz, coast, hum, t0) > 0.5 {
            return Biome::Swamp;
        }
        if te < FROZEN {
            return if hu > -0.10 { Biome::SnowyTaiga } else { Biome::SnowyPlains };
        }
        if te < COLD_MAX {
            return if hu > -0.22 { Biome::Taiga } else { Biome::Plains };
        }
        if te < TEMPERATE_MAX {
            if hu > 0.10 {
                let v = self.variant_noise.fbm2d(wx * 0.0012 + 3.0, wz * 0.0012 - 8.0, 2, 0.5, 2.0);
                return if v > 0.10 { Biome::BirchForest } else { Biome::Forest };
            }
            if hu < SAVANNA_HU_MILD && te > SAVANNA_MIN_T {
                return Biome::Savanna;
            }
            return Biome::Plains;
        }
        if te < WARM_MAX {
            if hu < SAVANNA_HU_WARM {
                return Biome::Savanna;
            }
            if hu > 0.22 {
                return Biome::Forest;
            }
            return Biome::Plains;
        }
        if hu < 0.0 {
            return Biome::Desert;
        }
        if hu < SAVANNA_HU_HOT {
            return Biome::Savanna;
        }
        Biome::Forest
    }

    pub fn temperature_jitter(&self, wx: f64, wz: f64) -> f64 {
        self.jitter_noise.noise2d(wx * 0.011 + 5.0, wz * 0.011 - 3.0) * 0.07
    }

    pub fn humidity_jitter(&self, wx: f64, wz: f64) -> f64 {
        self.jitter_noise.noise2d(wx * 0.011 - 40.0, wz * 0.011 + 60.0) * 0.07
    }

    /// The temperature `biome` decides by: sea-level temperature plus wobble, minus a lapse rate.
    pub fn ground_temperature(&self, t0: f64, jt: f64, h: f64) -> f64 {
        let up = if h - SEA > 0.0 { h - SEA } else { 0.0 };
        t0 + jt - LAPSE * up
    }

    /// How dry the ground is, 0..1: a smooth version of the savanna / desert part of the biome table.
    pub fn dryness(&self, te: f64, hu: f64) -> f64 {
        let bh = DRY_BAND * 2.0;
        let mild = ((te - SAVANNA_MIN_T) / DRY_BAND).min((SAVANNA_HU_MILD - hu) / bh);
        let warm = ((te - TEMPERATE_MAX) / DRY_BAND).min((SAVANNA_HU_WARM - hu) / bh);
        let hot = ((te - WARM_MAX) / DRY_BAND).min((SAVANNA_HU_HOT - hu) / bh);
        smooth_step(-1.0, 1.0, mild.max(warm.max(hot)))
    }

    /// How cold the grass is, 0..1.
    pub fn coldness(&self, te: f64) -> f64 {
        smooth_step(0.0, FROZEN, te)
    }

    /// How much a point is swamp, 0..1 (a smooth version of the hard rule in `biome`).
    pub fn swampiness(&self, swamp: f64, alt: f64) -> f64 {
        smooth_step(SWAMP_SOFT_LO, SWAMP_SOFT_HI, swamp) * (1.0 - smooth_step(SWAMP_MAX_ALT - 3.0, SWAMP_MAX_ALT + 3.0, alt))
    }

    /// Biome of a water column `depth` blocks below sea level at (wx, wz).
    pub fn water_biome(&self, wx: f64, wz: f64, depth: f64, coast: f64) -> Biome {
        if depth <= 4.5 && coast >= -2.5 && self.swamp_weight(wx, wz, coast) > 0.5 {
            return Biome::Swamp;
        }
        if coast >= 1.0 {
            return Biome::Lake;
        }
        if depth > 14.0 {
            Biome::DeepOcean
        } else {
            Biome::Ocean
        }
    }

    /// Ground cover of dry land in `biome` at height `h` with local `slope`.
    pub fn surface_for(&self, biome: Biome, wx: f64, wz: f64, h: f64, slope: f64) -> SurfaceKind {
        let alt = h - SEA;
        let jitter = self.jitter_noise.noise2d(wx * 0.09 + 5.0, wz * 0.09 - 3.0);
        let kind = match biome {
            Biome::Desert => SurfaceKind::Desert,
            Biome::Savanna => SurfaceKind::DryGrass,
            Biome::Beach => SurfaceKind::Beach,
            Biome::SnowyShore => SurfaceKind::Gravel,
            Biome::SnowyPlains | Biome::SnowyTaiga | Biome::SnowyPeaks => SurfaceKind::Snow,
            Biome::Swamp => SurfaceKind::Swamp,
            Biome::Mountains => {
                if slope < 0.45 && alt < ROCK_ALT + 30.0 && jitter > 0.15 {
                    SurfaceKind::Grass
                } else {
                    SurfaceKind::Rock
                }
            }
            _ => SurfaceKind::Grass,
        };
        if biome == Biome::Beach || biome == Biome::SnowyShore || biome == Biome::Swamp {
            return kind;
        }
        if alt > 3.0 && slope > 1.1 + 0.25 * jitter {
            return SurfaceKind::Rock;
        }
        if biome == Biome::SnowyPeaks {
            return SurfaceKind::Snow;
        }
        if kind != SurfaceKind::Snow && alt > 20.0 && slope > 0.75 + 0.2 * jitter {
            return SurfaceKind::Gravel;
        }
        kind
    }
}
