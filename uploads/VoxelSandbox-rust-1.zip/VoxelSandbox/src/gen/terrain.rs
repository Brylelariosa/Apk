//! Chunk generator: turns the pure land-form / climate functions into blocks, trees and plants.

use std::sync::Arc;

use super::caves::CaveCarver;
use super::climate::{Biome, Climate, SurfaceKind, COLD};
use super::genmath::mix_seed;
use super::noise::NoiseGenerator;
use super::shape::TerrainShape;
use super::trees::{ChunkCanvas, TreeBuilder, TreeSpecies};
use crate::world::block::Block;
use crate::world::chunk::ChunkData;
use crate::world::config::{CHUNK_SIZE, SEA_LEVEL, WORLD_HEIGHT};
use crate::world::pos::ChunkPos;

const CELL: i32 = 4;
const RAW: usize = (CHUNK_SIZE + 4) as usize;
const HEIGHT_N: usize = (CHUNK_SIZE + 2) as usize;
const TREE_REACH: i32 = 4;
const LILY_MAX_DEPTH: i32 = 5;
const SEAGRASS_MIN_DEPTH: i32 = 2;
const SEAGRASS_MAX_DEPTH: i32 = 14;
const DEEP_STONE_Y: i32 = 24;
const ORE_MAX_Y: i32 = SEA_LEVEL + 30;
const COAL_THRESHOLD: f32 = 0.84;
const POCKET_THRESHOLD: f32 = 0.78;
const ORE_CELLS: usize = 8;
const ORE_LEVELS: usize = 48;
const SPAWN_STEP: i32 = 24;
const SPAWN_MAX_RINGS: i32 = 120;
const SPAWN_PROBES: [i32; 16] = [6, 0, -6, 0, 0, 6, 0, -6, 5, 5, -5, 5, 5, -5, -5, -5];

#[derive(Clone, Copy, Debug)]
pub struct SpawnPoint {
    pub x: i32,
    pub z: i32,
}

pub struct TreeSpot {
    pub x: i32,
    pub z: i32,
    pub ground: i32,
    pub species: TreeSpecies,
    pub th: i32,
}

/// Lazily sampled 3D noise for ore pockets, on a 2-block lattice.
struct RockNoise {
    base_x: i32,
    base_z: i32,
    coal: Vec<f32>,
    pocket: Vec<f32>,
    sampled: Vec<bool>,
}

impl RockNoise {
    fn new(base_x: i32, base_z: i32) -> RockNoise {
        let n = ORE_CELLS * ORE_CELLS * ORE_LEVELS;
        RockNoise { base_x, base_z, coal: vec![0.0; n], pocket: vec![0.0; n], sampled: vec![false; n] }
    }
}

pub struct TerrainGenerator {
    pub seed: i64,
    pub climate: Arc<Climate>,
    pub shape: Arc<TerrainShape>,
    caves: CaveCarver,
    ore_noise: NoiseGenerator,
    lily_noise: NoiseGenerator,
    seagrass_noise: NoiseGenerator,
    pocket_noise: NoiseGenerator,
    deep_noise: NoiseGenerator,
    seed_mix: i32,
    trees: TreeBuilder,
}

fn ushr(v: i32, n: u32) -> u32 {
    (v as u32) >> n
}

fn despike(c: i32, n: i32, e: i32, s: i32, w: i32) -> i32 {
    let hi = std::cmp::max(std::cmp::max(n, e), std::cmp::max(s, w));
    let lo = std::cmp::min(std::cmp::min(n, e), std::cmp::min(s, w));
    if c > hi && c - hi == 1 {
        return hi;
    }
    if c < lo && lo - c == 1 {
        return lo;
    }
    c
}

impl TerrainGenerator {
    pub fn new(seed: i64) -> TerrainGenerator {
        let climate = Arc::new(Climate::new(seed));
        let shape = Arc::new(TerrainShape::new(seed, climate.clone()));
        let seed_mix = (seed as i32).wrapping_mul(1274126177);
        TerrainGenerator {
            seed,
            caves: CaveCarver::new(seed, shape.clone()),
            climate,
            shape,
            ore_noise: NoiseGenerator::new(mix_seed(seed, 20)),
            lily_noise: NoiseGenerator::new(mix_seed(seed, 21)),
            seagrass_noise: NoiseGenerator::new(mix_seed(seed, 22)),
            pocket_noise: NoiseGenerator::new(mix_seed(seed, 23)),
            deep_noise: NoiseGenerator::new(mix_seed(seed, 24)),
            seed_mix,
            trees: TreeBuilder::new(seed_mix),
        }
    }

    pub fn generate(&self, pos: ChunkPos) -> ChunkData {
        let mut chunk = ChunkData::new();
        let size = CHUNK_SIZE;
        let base_x = pos.x * size;
        let base_z = pos.z * size;
        let r = RAW;
        let mut raw = [0i32; RAW * RAW];
        let mut coast = [0.0f64; RAW * RAW];
        // Heights of the chunk plus a two-block apron, so slopes and spikes at the edge match the neighbour.
        for gz in 0..r {
            for gx in 0..r {
                let i = gz * r + gx;
                let (h, c) = self.shape.height_and_coast(
                    (base_x + gx as i32 - 2) as f64,
                    (base_z + gz as i32 - 2) as f64,
                    0,
                );
                raw[i] = h.floor() as i32;
                coast[i] = c;
            }
        }
        let g = HEIGHT_N;
        let mut heights = [0i32; HEIGHT_N * HEIGHT_N];
        for gz in 0..g {
            for gx in 0..g {
                let i = (gz + 1) * r + (gx + 1);
                heights[gz * g + gx] = despike(raw[i], raw[i - r], raw[i + 1], raw[i + r], raw[i - 1]);
            }
        }
        let mut ground = [0i32; 256];
        let mut under_water = [false; 256];
        let mut rock = RockNoise::new(base_x, base_z);
        for lz in 0..size as usize {
            for lx in 0..size as usize {
                let i = (lz + 1) * g + (lx + 1);
                let rise = std::cmp::max((heights[i + 1] - heights[i - 1]).abs(), (heights[i + g] - heights[i - g]).abs());
                self.fill_column(
                    &mut chunk,
                    lx as i32,
                    lz as i32,
                    base_x + lx as i32,
                    base_z + lz as i32,
                    heights[i],
                    rise as f64 * 0.5,
                    &mut rock,
                    coast[(lz + 2) * r + (lx + 2)],
                );
                ground[lz * 16 + lx] = heights[i];
                under_water[lz * 16 + lx] = heights[i] < SEA_LEVEL;
                chunk.height_map[lz * 16 + lx] = heights[i] as i16;
            }
        }
        self.caves.carve(&mut chunk, base_x, base_z, &ground, &under_water);
        chunk.cave_mouth = self.caves.cave_mouth_near(pos.x, pos.z);
        {
            let mut canvas = ChunkCanvas::new(&mut chunk, base_x, base_z);
            self.place_trees(&mut canvas, base_x, base_z);
        }
        chunk
    }

    fn raw_height(&self, wx: i32, wz: i32) -> i32 {
        self.shape.height(wx as f64, wz as f64, 0).floor() as i32
    }

    /// Ground height at a block column, as the chunk generator will place it.
    pub fn surface_height(&self, wx: i32, wz: i32) -> i32 {
        despike(
            self.raw_height(wx, wz),
            self.raw_height(wx, wz - 1),
            self.raw_height(wx + 1, wz),
            self.raw_height(wx, wz + 1),
            self.raw_height(wx - 1, wz),
        )
    }

    pub fn forest_factor(&self, wx: i32, wz: i32) -> f64 {
        self.climate.forest(wx as f64, wz as f64)
    }

    /// A dry, gently sloping place near the origin to start on (a spiral search).
    pub fn find_spawn(&self) -> SpawnPoint {
        for ring in 0..=SPAWN_MAX_RINGS {
            let radius = (ring * SPAWN_STEP) as f64;
            let count = if ring == 0 {
                1
            } else {
                std::cmp::max(8, (2.0 * std::f64::consts::PI * radius / SPAWN_STEP as f64) as i32)
            };
            let phase = ring as f64 * 0.61;
            for k in 0..count {
                let a = phase + 2.0 * std::f64::consts::PI * k as f64 / count as f64;
                let x = (radius * a.cos() + 0.5).floor() as i32;
                let z = (radius * a.sin() + 0.5).floor() as i32;
                if self.is_good_spawn(x, z) {
                    return SpawnPoint { x, z };
                }
            }
        }
        SpawnPoint { x: 0, z: 0 }
    }

    fn is_good_spawn(&self, x: i32, z: i32) -> bool {
        let sea = SEA_LEVEL;
        let h = self.surface_height(x, z);
        if h < sea + 3 || h > sea + 24 {
            return false;
        }
        let mut i = 0;
        while i < SPAWN_PROBES.len() {
            let h2 = self.surface_height(x + SPAWN_PROBES[i], z + SPAWN_PROBES[i + 1]);
            if h2 < sea + 1 || (h2 - h).abs() > 5 {
                return false;
            }
            i += 2;
        }
        matches!(
            self.biome_at_ground(x, z, h),
            Biome::Plains | Biome::Forest | Biome::BirchForest | Biome::Savanna | Biome::Taiga
        )
    }

    fn biome_at_ground(&self, wx: i32, wz: i32, ground: i32) -> Biome {
        let rise = std::cmp::max(
            (self.surface_height(wx + 1, wz) - self.surface_height(wx - 1, wz)).abs(),
            (self.surface_height(wx, wz + 1) - self.surface_height(wx, wz - 1)).abs(),
        );
        let x = wx as f64;
        let z = wz as f64;
        self.climate.biome(x, z, ground as f64, rise as f64 * 0.5, self.shape.coast_elevation(x, z))
    }

    /// The biome at a block column (for the on-screen biome name).
    pub fn biome_at(&self, wx: i32, wz: i32) -> Biome {
        let h = self.surface_height(wx, wz);
        if h < SEA_LEVEL {
            return self.climate.water_biome(
                wx as f64,
                wz as f64,
                (SEA_LEVEL - h) as f64,
                self.shape.coast_elevation(wx as f64, wz as f64),
            );
        }
        self.biome_at_ground(wx, wz, h)
    }

    #[allow(clippy::too_many_arguments)]
    fn fill_column(
        &self,
        chunk: &mut ChunkData,
        lx: i32,
        lz: i32,
        wx: i32,
        wz: i32,
        height: i32,
        slope: f64,
        rock: &mut RockNoise,
        coast_elev: f64,
    ) {
        let sea = SEA_LEVEL;
        let x = wx as f64;
        let z = wz as f64;
        let h = height as f64;
        let humid = self.climate.humidity(x, z);
        let mut kind = SurfaceKind::Grass;
        let mut biome = Biome::Plains;
        let mut top_block = Block::Grass;
        let mut soil_block = Block::Dirt;
        let mut soil_layers = 3;
        let mut strata_block = Block::Stone;
        let mut strata_layers = 0;
        let mut swamp_water = false;

        if height < sea {
            let water_depth = sea - height;
            swamp_water = water_depth <= LILY_MAX_DEPTH
                && self.climate.water_biome(x, z, water_depth as f64, coast_elev) == Biome::Swamp;
            let deep = water_depth > 8;
            let cold = self.climate.base_temperature(x, z) < COLD;
            top_block = if swamp_water {
                Block::Dirt
            } else if deep || cold {
                Block::Gravel
            } else {
                Block::Sand
            };
            soil_block = top_block;
            soil_layers = 2;
        } else {
            biome = self.climate.biome_with(x, z, h, slope, coast_elev, self.climate.base_temperature(x, z), humid);
            kind = self.climate.surface_for(biome, x, z, h, slope);
            match kind {
                SurfaceKind::Grass => {}
                SurfaceKind::DryGrass => top_block = Block::DryGrass,
                SurfaceKind::Desert => {
                    top_block = Block::Sand;
                    soil_block = Block::Sand;
                    soil_layers = 3;
                    strata_block = Block::Sandstone;
                    strata_layers = 4;
                }
                SurfaceKind::Beach => {
                    top_block = Block::Sand;
                    soil_block = Block::Sand;
                    soil_layers = 2;
                }
                SurfaceKind::Snow => top_block = Block::Snow,
                SurfaceKind::Swamp => top_block = Block::SwampGrass,
                SurfaceKind::Rock => {
                    top_block = Block::Stone;
                    soil_block = Block::Stone;
                    soil_layers = 0;
                }
                SurfaceKind::Gravel => {
                    top_block = Block::Gravel;
                    soil_block = Block::Gravel;
                    soil_layers = 2;
                }
            }
        }

        let deep_y = DEEP_STONE_Y + (self.deep_noise.noise2d(x * 0.045, z * 0.045) * 5.0) as i32;
        let top_y = std::cmp::max(height, sea);
        for y in 0..=top_y {
            let block = if y > height {
                Block::Water // only below sea level (height < y <= sea)
            } else if y == height {
                top_block
            } else if y == 0 {
                Block::DeepStone
            } else {
                let depth = height - y;
                if depth <= soil_layers {
                    soil_block
                } else if depth <= soil_layers + strata_layers {
                    strata_block
                } else {
                    self.rock_block(lx, y, lz, deep_y, depth, rock)
                }
            };
            let idx = ((((y & 15) * 16 + lz) * 16) + lx) as usize;
            chunk.section_mut((y >> 4) as usize)[idx] = block as u8;
        }

        if height >= sea && height + 2 < WORLD_HEIGHT {
            self.scatter_plants(chunk, lx, lz, wx, wz, height, kind, biome, humid);
        } else if height < sea {
            self.scatter_water_plants(chunk, lx, lz, wx, wz, height, swamp_water);
        }
    }

    fn sample_rock_cell(&self, rock: &mut RockNoise, k: usize) {
        let gy = k % ORE_LEVELS;
        let cell = k / ORE_LEVELS;
        let gx = cell % ORE_CELLS;
        let gz = cell / ORE_CELLS;
        let x = rock.base_x as f64 + gx as f64 * 2.0 + 1.0;
        let z = rock.base_z as f64 + gz as f64 * 2.0 + 1.0;
        let y = gy as f64 * 2.0 + 1.0;
        rock.coal[k] = self.ore_noise.noise3d(x * 0.17, y * 0.17, z * 0.17) as f32;
        rock.pocket[k] = self.pocket_noise.noise3d(x * 0.06, y * 0.08, z * 0.06) as f32;
        rock.sampled[k] = true;
    }

    /// Stone, with coal veins and pockets of gravel / dirt below the soil.
    fn rock_block(&self, lx: i32, y: i32, lz: i32, deep_y: i32, depth: i32, rock: &mut RockNoise) -> Block {
        let stone = if y < deep_y { Block::DeepStone } else { Block::Stone };
        if depth < 6 || y < 4 || y > ORE_MAX_Y {
            return stone;
        }
        let k = ((((lz >> 1) as usize) * ORE_CELLS + (lx >> 1) as usize) * ORE_LEVELS) + (y >> 1) as usize;
        if !rock.sampled[k] {
            self.sample_rock_cell(rock, k);
        }
        if rock.coal[k] > COAL_THRESHOLD {
            return Block::CoalOre;
        }
        let pocket = rock.pocket[k];
        if pocket > POCKET_THRESHOLD {
            return Block::Gravel;
        }
        if pocket < -POCKET_THRESHOLD {
            return Block::Dirt;
        }
        stone
    }

    #[allow(clippy::too_many_arguments)]
    fn scatter_water_plants(&self, chunk: &mut ChunkData, lx: i32, lz: i32, wx: i32, wz: i32, height: i32, swamp_water: bool) {
        let sea = SEA_LEVEL;
        let depth = sea - height;
        let x = wx as f64;
        let z = wz as f64;
        if swamp_water {
            let patch = self.lily_noise.noise2d(x * 0.07 + 13.0, z * 0.07 - 29.0);
            if patch > 0.0 && ((ushr(self.hash3(wx, 11, wz), 7)) & 1) == 0 {
                chunk.set(lx, sea + 1, lz, Block::LilyPad);
            }
            return;
        }
        if depth < SEAGRASS_MIN_DEPTH || depth > SEAGRASS_MAX_DEPTH {
            return;
        }
        let patch = self.seagrass_noise.noise2d(x * 0.045 + 3.0, z * 0.045 - 11.0);
        if patch < 0.05 {
            return;
        }
        let chance = if patch > 0.45 { 0.65 } else { 0.32 };
        let roll = ((ushr(self.hash3(wx, 23, wz), 6) & 0xFF) as f64) / 256.0;
        if roll < chance {
            chunk.set(lx, height + 1, lz, Block::Seagrass);
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn scatter_plants(
        &self,
        chunk: &mut ChunkData,
        lx: i32,
        lz: i32,
        wx: i32,
        wz: i32,
        height: i32,
        kind: SurfaceKind,
        biome: Biome,
        humid: f64,
    ) {
        let bits = self.hash3(wx, 7, wz);
        let u = ((ushr(bits, 8) & 0xFFFF) as f64) / 65536.0;
        let y = height + 1;
        match kind {
            SurfaceKind::Grass => {
                let tufts = 0.10 + 0.14 * (humid + 1.0) * 0.5; // thicker in wet country
                let flowers = match biome {
                    Biome::Plains => 0.035, // meadows are full of flowers
                    Biome::Forest | Biome::BirchForest => 0.016,
                    _ => 0.006,
                };
                if u < tufts {
                    chunk.set(lx, y, lz, Block::TallGrass);
                } else if u < tufts + flowers {
                    chunk.set(lx, y, lz, if (bits & 1) == 0 { Block::Poppy } else { Block::Dandelion });
                }
            }
            SurfaceKind::DryGrass => {
                if u < 0.09 {
                    chunk.set(lx, y, lz, Block::TallGrass);
                } else if u < 0.10 {
                    chunk.set(lx, y, lz, Block::DeadBush);
                }
            }
            SurfaceKind::Swamp => {
                if u < 0.26 {
                    chunk.set(lx, y, lz, Block::TallGrass);
                }
            }
            SurfaceKind::Desert => {
                if u < 0.012 {
                    chunk.set(lx, y, lz, Block::DeadBush);
                } else if u < 0.019 {
                    let cactus_height = 1 + ((ushr(bits, 3) & 3) % 3) as i32;
                    for k in 0..cactus_height {
                        chunk.set(lx, y + k, lz, Block::Cactus);
                    }
                }
            }
            _ => {}
        }
    }

    // ------------------------------------------------------------------ trees

    fn place_trees(&self, canvas: &mut ChunkCanvas, base_x: i32, base_z: i32) {
        let size = CHUNK_SIZE;
        let min_cell_x = (base_x - TREE_REACH).div_euclid(CELL);
        let max_cell_x = (base_x + size - 1 + TREE_REACH).div_euclid(CELL);
        let min_cell_z = (base_z - TREE_REACH).div_euclid(CELL);
        let max_cell_z = (base_z + size - 1 + TREE_REACH).div_euclid(CELL);
        for cz in min_cell_z..=max_cell_z {
            for cx in min_cell_x..=max_cell_x {
                let th = self.cell_hash(cx, cz);
                let wx = cx * CELL + (ushr(th, 8) & 3) as i32;
                let wz = cz * CELL + (ushr(th, 10) & 3) as i32;
                if wx < base_x - TREE_REACH || wx >= base_x + size + TREE_REACH {
                    continue;
                }
                if wz < base_z - TREE_REACH || wz >= base_z + size + TREE_REACH {
                    continue;
                }
                let spot = match self.tree_spot(cx, cz) {
                    Some(s) => s,
                    None => continue,
                };
                self.trees.grow(canvas, spot.species, spot.x, spot.z, spot.ground, spot.th);
            }
        }
    }

    /// The tree standing in jitter cell (cx, cz), if any (a pure function of the world seed).
    pub fn tree_spot(&self, cx: i32, cz: i32) -> Option<TreeSpot> {
        let th = self.cell_hash(cx, cz);
        let wx = cx * CELL + (ushr(th, 8) & 3) as i32;
        let wz = cz * CELL + (ushr(th, 10) & 3) as i32;
        let forest = self.forest_factor(wx, wz);
        let chance = 0.02 + 0.30 * forest * forest; // sparse in open ground, thick in forests
        if ((th & 0xFF) as i32) >= (chance * 256.0) as i32 {
            return None; // cheap early-out
        }
        if self.caves.near_mouth(wx as f64, wz as f64) {
            return None; // keep cave entrances clear
        }
        let (hh, coast0) = self.shape.height_and_coast(wx as f64, wz as f64, 0);
        let c = hh.floor() as i32;
        let n = self.raw_height(wx, wz - 1);
        let e = self.raw_height(wx + 1, wz);
        let s = self.raw_height(wx, wz + 1);
        let w = self.raw_height(wx - 1, wz);
        let ground = despike(c, n, e, s, w);
        if ground < SEA_LEVEL {
            return None; // shallows stay bare
        }
        let mut rise = 0;
        if self.climate.slope_matters(ground as f64, coast0) {
            let ne = self.raw_height(wx + 1, wz - 1);
            let se = self.raw_height(wx + 1, wz + 1);
            let nw = self.raw_height(wx - 1, wz - 1);
            let sw = self.raw_height(wx - 1, wz + 1);
            let ee = self.raw_height(wx + 2, wz);
            let ww = self.raw_height(wx - 2, wz);
            let ss = self.raw_height(wx, wz + 2);
            let nn = self.raw_height(wx, wz - 2);
            rise = std::cmp::max(
                (despike(e, ne, ee, se, c) - despike(w, nw, c, sw, ww)).abs(),
                (despike(s, c, se, ss, sw) - despike(n, nn, ne, c, nw)).abs(),
            );
        }
        let biome = self.climate.biome(wx as f64, wz as f64, ground as f64, rise as f64 * 0.5, coast0);
        if ground <= SEA_LEVEL + 2 && biome != Biome::Swamp {
            return None; // so do beaches
        }
        let density = self.tree_density(biome);
        if density <= 0.0 || ((th & 0xFF) as i32) >= (chance * density * 256.0) as i32 {
            return None;
        }
        let species = self.pick_species(biome, ground, th)?;
        Some(TreeSpot { x: wx, z: wz, ground, species, th })
    }

    pub fn tree_density(&self, biome: Biome) -> f64 {
        match biome {
            Biome::Forest | Biome::BirchForest | Biome::Taiga => 1.0,
            Biome::SnowyTaiga => 0.9,
            Biome::Mountains => 0.45,
            Biome::Swamp => 0.55,
            Biome::Plains => 0.35,
            Biome::SnowyPlains | Biome::Savanna => 0.25,
            _ => 0.0, // desert, shores, oceans, snowy peaks
        }
    }

    fn pick_species(&self, biome: Biome, ground: i32, th: i32) -> Option<TreeSpecies> {
        let roll = ushr(th, 12) & 0xFF;
        match biome {
            Biome::Forest => Some(if roll < 200 { TreeSpecies::Oak } else { TreeSpecies::Birch }),
            Biome::BirchForest => Some(if roll < 215 { TreeSpecies::Birch } else { TreeSpecies::Oak }),
            Biome::Plains => Some(if roll < 190 { TreeSpecies::Oak } else { TreeSpecies::Birch }),
            Biome::Savanna => Some(TreeSpecies::Oak),
            Biome::Taiga => Some(if roll < 235 { TreeSpecies::Spruce } else { TreeSpecies::Birch }),
            Biome::SnowyTaiga | Biome::SnowyPlains => Some(TreeSpecies::Spruce),
            Biome::Swamp => Some(TreeSpecies::Oak),
            Biome::Mountains => {
                if ground < SEA_LEVEL + 55 {
                    Some(TreeSpecies::Spruce)
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    fn cell_hash(&self, x: i32, z: i32) -> i32 {
        let mut h = x
            .wrapping_mul(374761393)
            .wrapping_add(z.wrapping_mul(668265263))
            .wrapping_add((self.seed as i32).wrapping_mul(1274126177));
        h = (h ^ (ushr(h, 13) as i32)).wrapping_mul(-1028477387);
        h ^ (ushr(h, 16) as i32)
    }

    fn hash3(&self, x: i32, y: i32, z: i32) -> i32 {
        let mut h = x
            .wrapping_mul(374761393)
            .wrapping_add(y.wrapping_mul(668265263))
            .wrapping_add(z.wrapping_mul(1274126177))
            .wrapping_add(self.seed_mix);
        h = (h ^ (ushr(h, 13) as i32)).wrapping_mul(-1028477387);
        h ^ (ushr(h, 16) as i32)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn generation_is_deterministic() {
        let a = TerrainGenerator::new(1234);
        let b = TerrainGenerator::new(1234);
        let pos = ChunkPos::new(3, -2);
        let ca = a.generate(pos);
        let cb = b.generate(pos);
        assert_eq!(ca.serialize(), cb.serialize());
    }

    #[test]
    fn chunks_have_bedrock_layer_and_sane_heights() {
        let g = TerrainGenerator::new(77);
        let c = g.generate(ChunkPos::new(0, 0));
        for lz in 0..16 {
            for lx in 0..16 {
                assert_eq!(c.get(lx, 0, lz), Block::DeepStone);
                let h = c.height_map[(lz * 16 + lx) as usize] as i32;
                assert!(h >= 3 && h < WORLD_HEIGHT);
            }
        }
    }

    #[test]
    fn spawn_is_above_the_sea() {
        let g = TerrainGenerator::new(2024);
        let s = g.find_spawn();
        assert!(g.surface_height(s.x, s.z) >= SEA_LEVEL);
    }
}
