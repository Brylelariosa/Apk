# Voxel Sandbox — Rust edition

A from-scratch Rust rewrite of the Kotlin/OpenGL ES voxel sandbox (v15). The game is one native library
(`libvoxelsandbox.so`) running inside Android's `NativeActivity`; there is no Java or Kotlin code. Gradle only
wraps the library into an APK.

See [`docs/RUST-PORT.md`](docs/RUST-PORT.md) for the architecture, what is ported and what is not yet.

## Build (GitHub Actions, as before)

Upload the ZIP to `uploads/` like every other project. The workflow finds `Cargo.toml`, installs Rust + cargo-ndk,
runs the unit tests (non-blocking), builds the library for the ABIs in `gradle.properties` (`rustAbis=`),
then runs Gradle to package the APK. The APK appears as a workflow artifact.

## Build locally

```
rustup target add aarch64-linux-android
cargo install cargo-ndk
cargo test --lib                      # logic tests run on any computer
./gradlew assembleDebug               # builds the Rust library through cargo-ndk, then the APK
```
