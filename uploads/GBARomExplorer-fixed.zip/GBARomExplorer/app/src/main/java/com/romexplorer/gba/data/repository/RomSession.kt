package com.romexplorer.gba.data.repository

import android.net.Uri
import com.romexplorer.gba.core.analysis.model.RomMap
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.core.rom.RomHashes
import com.romexplorer.gba.core.rom.RomHeader
import com.romexplorer.gba.core.rom.RomWarning
import com.romexplorer.gba.core.rom.SaveType

/**
 * Everything in memory about the ROM the user currently has open. One
 * instance lives for as long as that ROM stays open; every screen
 * (info/hex/map/analyzer/patch) reads from the same instance via
 * [RomSessionManager] rather than each re-opening the file.
 */
data class RomSession(
    val uri: Uri,
    val displayName: String,
    val accessor: RomAccessor,
    val header: RomHeader,
    val warnings: List<RomWarning>,
    val hashes: RomHashes? = null,
    val saveType: SaveType? = null,
    val romMap: RomMap? = null,
    val editOverlay: EditOverlay = EditOverlay(),
) {
    /** Best available stable key for caching/bookmarks: the SHA-1 once known,
     * falling back to the URI (unique per pick, though not per file content)
     * until hashing finishes. */
    val cacheKey: String get() = hashes?.sha1 ?: uri.toString()
}
