package com.romexplorer.gba.ui.pokemontables

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.pokemon.DisplayRow
import com.romexplorer.gba.core.pokemon.FieldWriteResult
import com.romexplorer.gba.core.pokemon.FireRedTables
import com.romexplorer.gba.core.pokemon.ItemIconReader
import com.romexplorer.gba.core.pokemon.ItemNameLookup
import com.romexplorer.gba.core.pokemon.NameTableLookup
import com.romexplorer.gba.core.pokemon.NameTableWriter
import com.romexplorer.gba.core.pokemon.PokemonTableReader
import com.romexplorer.gba.core.pokemon.PokemonTableWriter
import com.romexplorer.gba.core.pokemon.SpeciesIconReader
import com.romexplorer.gba.core.pokemon.TableRowFormatter
import com.romexplorer.gba.core.pokemon.TrainerPartyFormatter
import com.romexplorer.gba.core.pokemon.TrainerPartyReader
import com.romexplorer.gba.core.pokemon.TrainerSpriteReader
import com.romexplorer.gba.core.pokemon.UnusedSlotDetector
import com.romexplorer.gba.core.pokemon.model.DisplayHint
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.pokemon.model.TableRow
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.data.repository.CustomTypeNamesRepository
import com.romexplorer.gba.data.repository.RomSession
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class PokemonTablesState {
    data object NotFireRed : PokemonTablesState()
    data object NoRomOpen : PokemonTablesState()
    data class Ready(val availableTables: List<KnownTableSchema>) : PokemonTablesState()
}

/** A selected table, already formatted for display — see [TableRowFormatter]. */
data class PokemonTableSelection(
    val schema: KnownTableSchema,
    val rows: List<DisplayRow>,
)

/**
 * Memoizes one lookup result per ROM, keyed by [RomAccessor] identity rather
 * than equality — different ROMs get different accessor instances, so
 * switching ROMs naturally invalidates the cache instead of serving stale
 * names from whatever was open before. Shared by every name/lookup table
 * this ViewModel reads (items, species, moves, types) so each one is only
 * ever read from the ROM once per session, however many tables get selected.
 */
private class RomKeyedCache<T> {
    private var entry: Pair<RomAccessor, T>? = null

    suspend fun getOrPut(accessor: RomAccessor, compute: suspend () -> T): T {
        entry?.let { (cachedAccessor, value) -> if (cachedAccessor === accessor) return value }
        val value = compute()
        entry = accessor to value
        return value
    }

    /** Forces the next [getOrPut] to recompute — e.g. after a custom type name is added. */
    fun invalidate() {
        entry = null
    }
}

/**
 * Same idea as [RomKeyedCache], but for lookups keyed by an index rather
 * than a single value per ROM — species icons, item icons, trainer
 * sprites. Each decode is real work (LZ77 decompression + tile decode), so
 * this is what makes scrolling back up through an already-viewed table
 * free instead of re-decoding every time.
 */
private class IndexedImageCache {
    private var accessor: RomAccessor? = null
    private val cache = mutableMapOf<Int, DecodedImage?>()

    suspend fun getOrPut(currentAccessor: RomAccessor, index: Int, compute: suspend () -> DecodedImage?): DecodedImage? {
        if (accessor !== currentAccessor) {
            accessor = currentAccessor
            cache.clear()
        }
        if (cache.containsKey(index)) return cache[index]
        return compute().also { cache[index] = it }
    }
}

class PokemonTableViewModel(
    private val sessionManager: RomSessionManager,
    private val customTypeNamesRepository: CustomTypeNamesRepository,
) : ViewModel() {

    val uiState: StateFlow<PokemonTablesState> = sessionManager.session
        .map { toState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), toState(sessionManager.session.value))

    /** For the save-as suggested filename. */
    val romDisplayName: StateFlow<String?> = sessionManager.session
        .map { it?.displayName }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), sessionManager.session.value?.displayName)

    private val _selectedTable = MutableStateFlow<PokemonTableSelection?>(null)
    val selectedTable: StateFlow<PokemonTableSelection?> = _selectedTable.asStateFlow()

    private val _isLoadingTable = MutableStateFlow(false)
    val isLoadingTable: StateFlow<Boolean> = _isLoadingTable.asStateFlow()

    /** Set after a failed edit (out-of-range value, etc.); null when there's nothing to show. */
    private val _editStatus = MutableStateFlow<String?>(null)
    val editStatus: StateFlow<String?> = _editStatus.asStateFlow()

    private val itemNameCache = RomKeyedCache<Map<Int, String>>()
    private val speciesNameCache = RomKeyedCache<Map<Int, String>>()
    private val moveNameCache = RomKeyedCache<Map<Int, String>>()
    private val typeNameCache = RomKeyedCache<Map<Int, String>>()

    private val speciesIconCache = IndexedImageCache()
    private val itemIconCache = IndexedImageCache()
    private val trainerSpriteCache = IndexedImageCache()

    private fun toState(session: RomSession?): PokemonTablesState = when {
        session == null -> PokemonTablesState.NoRomOpen
        session.header.gameCode != FireRedTables.EXPECTED_GAME_CODE -> PokemonTablesState.NotFireRed
        else -> PokemonTablesState.Ready(FireRedTables.all)
    }

    fun selectTable(schema: KnownTableSchema) {
        val session = sessionManager.session.value ?: return
        val accessor = session.accessor
        viewModelScope.launch {
            _isLoadingTable.value = true
            // The overlay is the same one the hex editor writes to, so an edit
            // made on either screen shows up here too — see PokemonTableWriter.
            val table = PokemonTableReader.read(accessor, schema, session.editOverlay)

            val itemNames = if (schema.fields.any { it.displayHint == DisplayHint.ITEM_ID }) itemNamesFor(accessor) else emptyMap()
            val typeNames = if (schema.fields.any { it.displayHint == DisplayHint.TYPE_ID }) typeNamesFor(session) else emptyMap()

            val rows = when (schema) {
                FireRedTables.speciesBaseStats -> {
                    val speciesNames = speciesNamesFor(accessor)
                    table.rows.map { row ->
                        TableRowFormatter.format(schema, row, itemNames, typeNames, externalTitle = speciesNames[row.index])
                    }
                }
                FireRedTables.moves -> {
                    val moveNames = moveNamesFor(accessor)
                    table.rows.map { row ->
                        TableRowFormatter.format(schema, row, itemNames, typeNames, externalTitle = moveNames[row.index])
                    }
                }
                FireRedTables.trainers -> withTrainerParties(accessor, schema, table.rows, itemNames)
                else -> table.rows.map { row -> TableRowFormatter.format(schema, row, itemNames) }
            }

            _selectedTable.value = PokemonTableSelection(schema, rows)
            _isLoadingTable.value = false
        }
    }

    fun clearSelection() {
        _selectedTable.value = null
    }

    /**
     * Writes [newValue] into [field] of row [rowIndex], via the shared
     * [com.romexplorer.gba.core.hex.EditOverlay] — see [PokemonTableWriter].
     * On success, reloads the whole table so every derived bit of display
     * (a resolved name, a trainer's party line) stays consistent rather
     * than patching just the one cell and risking it drifting out of sync.
     */
    fun editField(schema: KnownTableSchema, rowIndex: Int, field: TableField, newValue: Long) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            when (val result = PokemonTableWriter.write(session.accessor, session.editOverlay, schema, rowIndex, field, newValue)) {
                FieldWriteResult.Success -> {
                    sessionManager.persistDraft()
                    selectTable(schema)
                }
                FieldWriteResult.OutOfRange -> {
                    val range = PokemonTableWriter.validRange(field.kind)
                    _editStatus.value = "${field.name} must be between ${range.first} and ${range.last}"
                }
                FieldWriteResult.NotEditable -> _editStatus.value = "${field.name} can't be edited here"
                FieldWriteResult.OutOfBounds -> _editStatus.value = "Couldn't write ${field.name} — out of ROM bounds"
            }
        }
    }

    fun clearEditStatus() {
        _editStatus.value = null
    }

    fun canUndoEdit(): Boolean = sessionManager.session.value?.editOverlay?.canUndo() ?: false

    /** Undoes the most recent edit — from this screen or the hex editor, since they share one overlay — and reloads. */
    fun undoEdit() {
        val session = sessionManager.session.value ?: return
        val schema = _selectedTable.value?.schema ?: return
        session.editOverlay.undo()
        viewModelScope.launch { sessionManager.persistDraft() }
        selectTable(schema)
    }

    /** True if there are edits not yet exported to a saved ROM file (see [exportRom]). */
    fun hasUnsavedEdits(): Boolean = sessionManager.hasUnsavedEdits()

    /** Writes the currently-open ROM, with every edit applied, to [destination] — shared with the Hex Editor, see RomSessionManager.exportEditedRom. */
    fun exportRom(destination: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = sessionManager.exportEditedRom(destination)
            _editStatus.value = if (result.isSuccess) "Saved successfully" else "Save failed: ${result.exceptionOrNull()?.message}"
            onDone(result.isSuccess)
        }
    }

    /** Discards every unsaved edit for the current ROM, reverting every table back to its original bytes. */
    fun discardAllEdits() {
        viewModelScope.launch {
            sessionManager.discardDraft()
            _selectedTable.value?.schema?.let { selectTable(it) }
        }
    }

    /**
     * Registers a custom label for a type ID beyond FireRed's built-in 18
     * (e.g. "FAIRY") — a display name only, not a real new type with its own
     * battle type-effectiveness; see [CustomTypeNamesRepository]. The next
     * free ID above every type currently known (built-in or already-custom)
     * is assigned automatically, so the person naming it is never asked to
     * pick a raw number themselves — the exact problem this whole feature
     * exists to get away from.
     */
    fun addCustomType(name: String, onAdded: (Int) -> Unit) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            val existing = typeNamesFor(session)
            val nextId = (existing.keys.maxOrNull() ?: (FireRedTables.TYPE_COUNT - 1)) + 1
            customTypeNamesRepository.setCustomType(session.cacheKey, nextId, name)
            typeNameCache.invalidate()
            _selectedTable.value?.schema?.let { selectTable(it) }
            onAdded(nextId)
        }
    }

    /**
     * Row indices in [schema] that are genuinely unused and therefore safe
     * to claim as a new entry (see [UnusedSlotDetector]) — empty means every
     * slot in this ROM's copy of the table is already taken, not that
     * something went wrong. Only [FireRedTables.items], [FireRedTables.speciesBaseStats]
     * and [FireRedTables.moves] support this; other schemas return an empty list.
     */
    suspend fun unusedSlotIndices(schema: KnownTableSchema): List<Int> {
        val session = sessionManager.session.value ?: return emptyList()
        val table = PokemonTableReader.read(session.accessor, schema, session.editOverlay)
        return when (schema) {
            FireRedTables.items -> table.rows.filter { UnusedSlotDetector.isUnusedItemSlot(it) }.map { it.index }
            FireRedTables.speciesBaseStats -> {
                val names = speciesNamesFor(session.accessor)
                table.rows.filter { UnusedSlotDetector.isUnusedSpeciesSlot(it, names[it.index]) }.map { it.index }
            }
            FireRedTables.moves -> {
                val names = moveNamesFor(session.accessor)
                table.rows.filter { UnusedSlotDetector.isUnusedMoveSlot(it, names[it.index]) }.map { it.index }
            }
            else -> emptyList()
        }
    }

    /**
     * Names a previously-unused slot (see [unusedSlotIndices]), turning it
     * into a real, functional new entry. This — reusing a reserved-but-blank
     * slot the table already ships with — is what "add a new item/Pokémon/
     * move" means in this app: the table itself is never expanded or
     * relocated (see [UnusedSlotDetector]'s doc for why that's out of
     * scope), so this can never corrupt anything outside the slot claimed.
     */
    fun claimSlot(schema: KnownTableSchema, index: Int, name: String) {
        val session = sessionManager.session.value ?: return
        viewModelScope.launch {
            val result = when (schema) {
                FireRedTables.items -> {
                    val nameField = schema.fields.first { it.kind == FieldKind.POKEMON_STRING }
                    PokemonTableWriter.writeName(session.accessor, session.editOverlay, schema, index, nameField, name)
                }
                FireRedTables.speciesBaseStats -> NameTableWriter.write(
                    session.accessor,
                    session.editOverlay,
                    FireRedTables.SPECIES_NAMES_OFFSET,
                    FireRedTables.SPECIES_NAME_LENGTH,
                    index,
                    name,
                )
                FireRedTables.moves -> NameTableWriter.write(
                    session.accessor,
                    session.editOverlay,
                    FireRedTables.MOVE_NAMES_OFFSET,
                    FireRedTables.MOVE_NAME_LENGTH,
                    index,
                    name,
                )
                else -> FieldWriteResult.NotEditable
            }
            when (result) {
                FieldWriteResult.Success -> {
                    itemNameCache.invalidate()
                    speciesNameCache.invalidate()
                    moveNameCache.invalidate()
                    sessionManager.persistDraft()
                    selectTable(schema)
                    _editStatus.value = "\"$name\" added at slot #$index — scroll down to fill in its other fields"
                }
                else -> _editStatus.value = "Couldn't name this entry"
            }
        }
    }

    /**
     * Called from the UI per visible row (e.g. from `produceState`, not
     * `viewModelScope.launch`) so decoding — real work, LZ77 + tile decode
     * — only happens for rows actually on screen, and stops automatically
     * once a row scrolls away and its composable leaves composition.
     */
    suspend fun loadSpeciesIcon(speciesIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return speciesIconCache.getOrPut(accessor, speciesIndex) { SpeciesIconReader.read(accessor, speciesIndex) }
    }

    suspend fun loadItemIcon(itemIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return itemIconCache.getOrPut(accessor, itemIndex) { ItemIconReader.read(accessor, itemIndex) }
    }

    suspend fun loadTrainerSprite(trainerPicIndex: Int): DecodedImage? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        return trainerSpriteCache.getOrPut(accessor, trainerPicIndex) { TrainerSpriteReader.read(accessor, trainerPicIndex) }
    }

    /**
     * Trainer rows get the same header-field formatting as any other table,
     * plus each trainer's actual party — decoded separately per row since
     * it lives behind its own pointer with a shape that varies by trainer
     * (see [TrainerPartyReader]). Reads run concurrently since there can be
     * ~750 trainers and [RomAccessor] is safe for concurrent access.
     */
    private suspend fun withTrainerParties(
        accessor: RomAccessor,
        schema: KnownTableSchema,
        rows: List<TableRow>,
        itemNames: Map<Int, String>,
    ): List<DisplayRow> {
        val speciesNames = speciesNamesFor(accessor)
        val moveNames = moveNamesFor(accessor)
        return coroutineScope {
            rows.map { row ->
                async {
                    val display = TableRowFormatter.format(schema, row, itemNames)
                    val partyFlags = (row.values["Party Flags"] as? Long)?.toInt() ?: 0
                    val partyPointer = row.values["Party Pointer"] as? Long ?: 0L
                    val partySize = (row.values["Party Size"] as? Long)?.toInt() ?: 0
                    val members = TrainerPartyReader.read(accessor, partyFlags, partyPointer, partySize)
                    val partyLines = TrainerPartyFormatter.format(members, speciesNames, itemNames, moveNames)
                    val trainerPicIndex = (row.values["Trainer Pic"] as? Long)?.toInt()
                    display.copy(partyLines = partyLines, partyMembers = members, trainerPicIndex = trainerPicIndex)
                }
            }.awaitAll()
        }
    }

    private suspend fun itemNamesFor(accessor: RomAccessor): Map<Int, String> =
        itemNameCache.getOrPut(accessor) { ItemNameLookup.build(accessor) }

    private suspend fun speciesNamesFor(accessor: RomAccessor): Map<Int, String> =
        speciesNameCache.getOrPut(accessor) {
            NameTableLookup.build(
                accessor,
                FireRedTables.SPECIES_NAMES_OFFSET,
                FireRedTables.SPECIES_NAME_LENGTH,
                FireRedTables.speciesBaseStats.entryCount,
            )
        }

    private suspend fun moveNamesFor(accessor: RomAccessor): Map<Int, String> =
        moveNameCache.getOrPut(accessor) {
            NameTableLookup.build(accessor, FireRedTables.MOVE_NAMES_OFFSET, FireRedTables.MOVE_NAME_LENGTH, FireRedTables.moves.entryCount)
        }

    /** FireRed's own 18 types plus any custom labels registered for this ROM — see [CustomTypeNamesRepository]. */
    private suspend fun typeNamesFor(session: RomSession): Map<Int, String> =
        typeNameCache.getOrPut(session.accessor) {
            val romTypes = NameTableLookup.build(session.accessor, FireRedTables.TYPE_NAMES_OFFSET, FireRedTables.TYPE_NAME_LENGTH, FireRedTables.TYPE_COUNT)
            val customTypes = customTypeNamesRepository.customTypesFor(session.cacheKey).first()
            romTypes + customTypes
        }

    /** Item ID -> name, for a searchable picker (see [FieldEditDialogs]). */
    suspend fun itemNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return itemNamesFor(session.accessor)
    }

    /** Type ID -> name (built-in + custom), for a searchable picker. */
    suspend fun typeNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return typeNamesFor(session)
    }

    /** Species index -> name, for a searchable picker. */
    suspend fun speciesNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return speciesNamesFor(session.accessor)
    }

    /** Move index -> name, for a searchable picker. */
    suspend fun moveNameOptions(): Map<Int, String> {
        val session = sessionManager.session.value ?: return emptyMap()
        return moveNamesFor(session.accessor)
    }
}
