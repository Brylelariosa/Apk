package com.romexplorer.gba.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import com.romexplorer.gba.core.analysis.AnalysisEngine
import com.romexplorer.gba.core.analysis.AnalysisProgress
import com.romexplorer.gba.core.analysis.RomMapCache
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.FileChannelRomAccessor
import com.romexplorer.gba.core.rom.HashProgress
import com.romexplorer.gba.core.rom.RomHasher
import com.romexplorer.gba.core.rom.RomHeaderParser
import com.romexplorer.gba.core.rom.SaveTypeDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext

/**
 * Owns the single currently-open [RomSession] for the whole app. Screens
 * never open their own [com.romexplorer.gba.core.rom.RomAccessor] — they
 * observe [session] and ask this manager to fill in hashes/save
 * type/analysis on demand, so a ROM is only ever opened once regardless of
 * how many screens the user navigates through.
 */
class RomSessionManager(
    private val context: Context,
    private val recentRomsRepository: RecentRomsRepository,
    private val romMapCache: RomMapCache,
    private val analysisEngine: AnalysisEngine,
    private val editDraftRepository: EditDraftRepository,
) {
    private val _session = MutableStateFlow<RomSession?>(null)
    val session: StateFlow<RomSession?> = _session.asStateFlow()

    suspend fun open(uri: Uri): Result<RomSession> = withContext(Dispatchers.IO) {
        runCatching {
            closeCurrentInternal()

            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )

            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: error("Unable to open ROM: content provider returned no file descriptor")
            val accessor = FileChannelRomAccessor(pfd)
            val (header, warnings) = RomHeaderParser.parse(accessor)
            val displayName = queryDisplayName(uri) ?: header.title.ifBlank { "Unknown ROM" }

            // Restore any not-yet-exported edits from the last time this same ROM was
            // open — otherwise they'd only have lived in the previous session's
            // in-memory EditOverlay, gone the moment that session was replaced (e.g.
            // reopening from Home) or the process was killed in the background. See
            // EditDraftRepository.
            val draftKey = uri.toString()
            val restoredDraft = editDraftRepository.draftFor(draftKey)
            val overlay = EditOverlay().apply { if (restoredDraft.isNotEmpty()) loadSnapshot(restoredDraft) }

            val newSession = RomSession(
                uri = uri,
                displayName = displayName,
                accessor = accessor,
                header = header,
                warnings = warnings,
                editOverlay = overlay,
            )
            _session.value = newSession
            recentRomsRepository.recordOpened(uri.toString(), displayName)
            newSession
        }
    }

    fun closeCurrent() {
        closeCurrentInternal()
        _session.value = null
    }

    private fun closeCurrentInternal() {
        _session.value?.accessor?.close()
    }

    /**
     * Call after any edit to the current session's overlay — a table field,
     * a hex byte, an undo, a redo — so the change survives navigating away,
     * backgrounding, or the process being killed. Cheap: the overlay is a
     * small sparse map even after a long editing session, and this is a
     * plain DataStore write, not a full ROM rewrite.
     */
    suspend fun persistDraft() {
        val current = _session.value ?: return
        editDraftRepository.saveDraft(current.uri.toString(), current.editOverlay.snapshot())
    }

    /** Discards every unsaved edit for the current ROM — in memory and from the persisted draft. */
    suspend fun discardDraft() {
        val current = _session.value ?: return
        current.editOverlay.clear()
        editDraftRepository.clearDraft(current.uri.toString())
    }

    /** True if the current ROM has edits that only exist as an in-memory/draft overlay, not yet exported to a file. */
    fun hasUnsavedEdits(): Boolean = _session.value?.editOverlay?.isDirty ?: false

    /**
     * Writes the currently-open ROM's original bytes with every edit applied
     * to [destination] (a new file, typically picked via SAF's
     * CreateDocument) — the one place "save the edited ROM" is implemented,
     * shared by the Hex Editor and Pokémon Table screens so saving means the
     * same thing and works the same way regardless of which screen the user
     * was editing from. The original file itself is never modified — SAF
     * documents aren't guaranteed to be writable in place, and this ROM
     * analysis toolkit only ever reads the ROM you opened (see
     * [com.romexplorer.gba.core.rom.RomAccessor]).
     */
    suspend fun exportEditedRom(destination: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        val current = _session.value ?: return@withContext Result.failure(IllegalStateException("No ROM open"))
        runCatching {
            val fullOriginal = current.accessor.read(0, current.accessor.sizeBytes.toInt())
            val patched = current.editOverlay.applyTo(fullOriginal)
            context.contentResolver.openOutputStream(destination)?.use { it.write(patched) }
                ?: error("Unable to open output stream")
        }
    }

    /** Streams hashing progress and updates [session] with the final result as soon as it's known. */
    fun computeHashes(): Flow<HashProgress> {
        val current = _session.value ?: return emptyFlow()
        return flow {
            RomHasher.hashWithProgress(current.accessor).collect { progress ->
                if (progress is HashProgress.Done) {
                    _session.value = _session.value?.copy(hashes = progress.hashes)
                }
                emit(progress)
            }
        }
    }

    suspend fun computeSaveType() {
        val current = _session.value ?: return
        if (current.saveType != null) return
        val saveType = SaveTypeDetector.detect(current.accessor)
        _session.value = _session.value?.copy(saveType = saveType)
    }

    /** Streams analysis progress. Checks the on-disk cache first (keyed by
     * ROM hash — call [computeHashes] before this for the cache to be
     * effective; otherwise it falls back to a full re-analysis every time). */
    fun computeRomMap(): Flow<AnalysisProgress> {
        val current = _session.value ?: return emptyFlow()
        return flow {
            val cached = romMapCache.get(current.cacheKey)
            if (cached != null) {
                _session.value = _session.value?.copy(romMap = cached)
                emit(AnalysisProgress.Done(cached))
                return@flow
            }
            analysisEngine.analyze(current.accessor, current.header.gameCode).collect { progress ->
                if (progress is AnalysisProgress.Done) {
                    _session.value = _session.value?.copy(romMap = progress.map)
                    romMapCache.put(current.cacheKey, progress.map)
                }
                emit(progress)
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        }.getOrNull()
    }
}
