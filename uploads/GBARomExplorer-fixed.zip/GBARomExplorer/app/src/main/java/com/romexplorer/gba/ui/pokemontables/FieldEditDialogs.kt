package com.romexplorer.gba.ui.pokemontables

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.romexplorer.gba.core.pokemon.PokemonTableWriter
import com.romexplorer.gba.core.pokemon.model.DisplayHint

/**
 * Routes to the right editor for [target]'s field: a searchable name picker
 * for Item/Type fields (so editing shows and searches real names, not a raw
 * ID the person has to already know — e.g. typing "poison" used to just get
 * silently filtered away since the old box only accepted digits), or a plain
 * numeric box for everything else.
 */
@Composable
fun EditFieldDialog(
    target: EditTarget,
    viewModel: PokemonTableViewModel,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit,
) {
    when (target.field.editableField?.displayHint ?: DisplayHint.RAW) {
        DisplayHint.ITEM_ID -> NamePickerDialog(
            title = "Choose ${target.field.label}",
            unknownLabel = "Item",
            loadOptions = { viewModel.itemNameOptions() },
            onDismiss = onDismiss,
            onSelect = { id -> onConfirm(id.toLong()) },
        )
        DisplayHint.TYPE_ID -> TypePickerDialog(target, viewModel, onDismiss, onSelect = { id -> onConfirm(id.toLong()) })
        DisplayHint.RAW -> NumericEditDialog(target, onDismiss, onConfirm)
    }
}

/**
 * Searchable id -> name list, reused for every "pick from a named table"
 * need in this screen (items, types, and — via [extraContent] — a way to
 * add a custom type inline). Filters by name or by typing the raw id
 * directly, for the rare case someone already knows it.
 */
@Composable
private fun NamePickerDialog(
    title: String,
    unknownLabel: String,
    loadOptions: suspend () -> Map<Int, String>,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
    extraContent: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val options by produceState(initialValue = emptyMap<Int, String>()) { value = loadOptions() }
    var query by remember { mutableStateOf("") }
    val entries = remember(options, query) {
        val sorted = options.entries.sortedBy { it.key }
        if (query.isBlank()) {
            sorted
        } else {
            sorted.filter { it.value.contains(query, ignoreCase = true) || it.key.toString() == query.trim() }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search by name or #") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.height(320.dp)) {
                    items(entries, key = { it.key }) { (id, name) ->
                        Text(
                            text = if (name.isNotBlank()) "#$id  $name" else "#$id  ($unknownLabel, unnamed)",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(id) }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
                extraContent?.invoke(this)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** [NamePickerDialog] for Type fields specifically, with an inline way to register a custom type (e.g. Fairy) when the built-in 18 aren't enough. */
@Composable
private fun TypePickerDialog(
    target: EditTarget,
    viewModel: PokemonTableViewModel,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
) {
    var showAddCustom by remember { mutableStateOf(false) }

    if (showAddCustom) {
        AddCustomTypeDialog(
            onDismiss = { showAddCustom = false },
            onConfirm = { name -> viewModel.addCustomType(name) { newId -> onSelect(newId) } },
        )
    } else {
        NamePickerDialog(
            title = "Choose ${target.field.label}",
            unknownLabel = "Type",
            loadOptions = { viewModel.typeNameOptions() },
            onDismiss = onDismiss,
            onSelect = onSelect,
            extraContent = {
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { showAddCustom = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Add a custom type (e.g. Fairy)")
                }
            },
        )
    }
}

@Composable
private fun AddCustomTypeDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add custom type") },
        text = {
            Column {
                Text(
                    "Names this type everywhere in this app. It won't give it real type-effectiveness matchups in battle — " +
                        "that lives in the game's own compiled code, which this ROM analysis toolkit doesn't modify.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.uppercase() },
                    label = { Text("Name, e.g. FAIRY") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onConfirm(name) }, enabled = name.isNotBlank()) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Plain numeric editor — unchanged behavior for every field that isn't a name-backed id (stats, flags, pointers' raw byte edits, etc.). */
@Composable
private fun NumericEditDialog(target: EditTarget, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    var text by remember(target) { mutableStateOf(target.field.rawValue?.toString().orEmpty()) }
    val range = target.field.editableField?.let { PokemonTableWriter.validRange(it.kind) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit ${target.field.label}") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { input -> text = input.filter { it.isDigit() || it == '-' } },
                label = { Text(if (range != null) "Value (${range.first}..${range.last})" else "Value") },
                singleLine = true,
            )
        },
        confirmButton = {
            TextButton(onClick = { text.toLongOrNull()?.let(onConfirm) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
