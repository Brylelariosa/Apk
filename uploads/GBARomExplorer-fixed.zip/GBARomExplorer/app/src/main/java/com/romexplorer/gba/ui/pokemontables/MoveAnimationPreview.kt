package com.romexplorer.gba.ui.pokemontables

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Approximate, Pokémon-typical color per type name — purely decorative, for theming the preview below. Unknown/custom types fall back to a neutral gray. */
private val typeColors: Map<String, Color> = mapOf(
    "NORMAL" to Color(0xFFA8A878),
    "FIGHT" to Color(0xFFC03028),
    "FIGHTING" to Color(0xFFC03028),
    "FLYING" to Color(0xFFA890F0),
    "POISON" to Color(0xFFA040A0),
    "GROUND" to Color(0xFFE0C068),
    "ROCK" to Color(0xFFB8A038),
    "BUG" to Color(0xFFA8B820),
    "GHOST" to Color(0xFF705898),
    "STEEL" to Color(0xFFB8B8D0),
    "FIRE" to Color(0xFFF08030),
    "WATER" to Color(0xFF6890F0),
    "GRASS" to Color(0xFF78C850),
    "ELECTRIC" to Color(0xFFF8D030),
    "PSYCHIC" to Color(0xFFF85888),
    "ICE" to Color(0xFF98D8D8),
    "DRAGON" to Color(0xFF7038F8),
    "DARK" to Color(0xFF705848),
    "FAIRY" to Color(0xFFEE99AC),
)

private fun colorForType(typeName: String): Color = typeColors[typeName.trim().uppercase()] ?: Color(0xFF9098A0)

/**
 * A stylized, type-themed particle-burst preview — deliberately NOT a
 * decode of the ROM's real battle animation. FireRed's actual move
 * animations are compiled command scripts run by the game's own animation
 * engine at battle time; reproducing them here would mean building a second,
 * from-scratch animation interpreter, well outside what a ROM
 * analysis/hacking toolkit does (see README: "Not an emulator"). This gives
 * a quick, honestly-labeled visual sense of a move's type and power instead.
 */
@Composable
fun MoveAnimationDialog(moveName: String, typeName: String, power: Int, onDismiss: () -> Unit) {
    val color = colorForType(typeName)
    val transition = rememberInfiniteTransition(label = "move_animation_preview")
    val durationMs = (900 + power.coerceIn(0, 250) * 4)
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMs, easing = LinearEasing)),
        label = "progress",
    )
    val particleCount = (6 + power / 12).coerceIn(6, 18)
    val angles = remember(moveName) { List(particleCount) { Random.nextFloat() * (2f * Math.PI.toFloat()) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(moveName) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$typeName · Power $power", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Canvas(modifier = Modifier.size(200.dp)) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val maxRadius = size.minDimension / 2f
                    angles.forEachIndexed { i, angle ->
                        val phase = (progress + i.toFloat() / angles.size) % 1f
                        val radius = maxRadius * phase
                        val alpha = (1f - phase).coerceIn(0f, 1f)
                        drawCircle(
                            color = color.copy(alpha = alpha),
                            radius = 6.dp.toPx() * (1f - phase * 0.5f),
                            center = Offset(center.x + radius * cos(angle), center.y + radius * sin(angle)),
                        )
                    }
                    drawCircle(
                        color = color.copy(alpha = 0.5f),
                        radius = 14.dp.toPx(),
                        center = center,
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Stylized preview, themed by this move's type — not the ROM's real in-game animation.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
