package com.romexplorer.gba.core.rom

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.zip.CRC32

data class RomHashes(
    val crc32: String,
    val md5: String,
    val sha1: String,
)

sealed class HashProgress {
    data class InProgress(val fraction: Float) : HashProgress()
    data class Done(val hashes: RomHashes) : HashProgress()
}

/**
 * Computes CRC32/MD5/SHA-1 over a ROM in a single streaming pass so a 64MB
 * file never needs to be loaded into memory at once. All three digests are
 * updated together per chunk to avoid re-reading the file three times.
 */
object RomHasher {

    private const val CHUNK_SIZE = 1 shl 20 // 1MB

    fun hashWithProgress(rom: RomAccessor) = flow {
        val crc = CRC32()
        val md5 = MessageDigest.getInstance("MD5")
        val sha1 = MessageDigest.getInstance("SHA-1")
        val buffer = ByteArray(CHUNK_SIZE)

        var offset = 0L
        val total = rom.sizeBytes.coerceAtLeast(1)

        while (offset < rom.sizeBytes) {
            val length = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val n = withContext(Dispatchers.IO) { rom.readInto(buffer, offset, length) }
            if (n <= 0) break
            crc.update(buffer, 0, n)
            md5.update(buffer, 0, n)
            sha1.update(buffer, 0, n)
            offset += n
            emit(HashProgress.InProgress(offset.toFloat() / total.toFloat()))
        }

        val hashes = RomHashes(
            crc32 = crc.value.toString(16).uppercase().padStart(8, '0'),
            md5 = md5.digest().toHex(),
            sha1 = sha1.digest().toHex(),
        )
        emit(HashProgress.Done(hashes))
    }

    private fun ByteArray.toHex(): String =
        joinToString("") { "%02X".format(it) }
}
