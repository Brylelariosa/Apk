package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.RomAccessor

/**
 * One Pokémon in a trainer's party, decoded by [TrainerPartyReader].
 * [heldItem] and [moves] are null (not just zero/empty) when this trainer's
 * struct variant doesn't carry that field at all — e.g. a trainer without
 * [com.romexplorer.gba.core.pokemon.FireRedTables] custom-moveset flag set
 * has its Pokémon learn moves the normal way (by level), so there's no
 * moves field to read, and null says that plainly rather than implying an
 * empty movelist.
 */
data class TrainerPartyMember(
    val species: Int,
    val level: Int,
    val heldItem: Int?,
    val moves: List<Int>?,
)

/**
 * Decodes a trainer's party: the variable-length, variable-shape array
 * reached via [FireRedTables.trainers]' "Party Pointer" field. Which of the
 * four possible entry shapes applies is decided by the trainer's own "Party
 * Flags" byte — see the class doc on [FireRedTables] for the source of each
 * shape's layout.
 */
object TrainerPartyReader {
    private const val FLAG_CUSTOM_MOVESET = 0x1
    private const val FLAG_HELD_ITEM = 0x2
    private const val MOVES_PER_MON = 4
    private const val IV_LEVEL_SPECIES_SIZE = 6 // u16 iv + u8 lvl + 1 pad byte + u16 species

    suspend fun read(rom: RomAccessor, partyFlags: Int, partyPointer: Long, partySize: Int): List<TrainerPartyMember> {
        if (partySize <= 0 || partyPointer <= 0) return emptyList()

        val hasItem = partyFlags and FLAG_HELD_ITEM != 0
        val hasCustomMoves = partyFlags and FLAG_CUSTOM_MOVESET != 0
        val entrySize = IV_LEVEL_SPECIES_SIZE + (if (hasItem) 2 else 0) + (if (hasCustomMoves) 2 * MOVES_PER_MON else 0)

        val totalSize = entrySize.toLong() * partySize
        val available = (rom.sizeBytes - partyPointer).coerceAtLeast(0)
        val readableEntries = if (available >= totalSize) partySize else (available / entrySize).toInt().coerceAtLeast(0)
        if (readableEntries <= 0) return emptyList()

        val bytes = rom.read(partyPointer, readableEntries * entrySize)
        return (0 until readableEntries).map { i ->
            val base = i * entrySize
            val level = bytes[base + 2].toInt() and 0xFF
            val species = readU16(bytes, base + 4)
            var offset = base + IV_LEVEL_SPECIES_SIZE
            val heldItem = if (hasItem) readU16(bytes, offset).also { offset += 2 } else null
            val moves = if (hasCustomMoves) {
                List(MOVES_PER_MON) { m -> readU16(bytes, offset + m * 2) }
            } else {
                null
            }
            TrainerPartyMember(species, level, heldItem, moves)
        }
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)
}
