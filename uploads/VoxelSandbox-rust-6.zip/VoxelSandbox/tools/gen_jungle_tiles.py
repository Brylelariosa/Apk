import math, random, json
from PIL import Image

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def grid():
    return [['.' for _ in range(16)] for _ in range(16)]

def rows_of(g):
    return ''.join(''.join(r) for r in g)

tiles = []

# ---------------------------------------------------------------- jungle bark
rng = random.Random(1101)
pal = "1d150e 2a1f15 382a1c 463627 574633 2a3818 3d5222 526a2e".split()
base = [rng.choice([1, 2, 2, 3, 3, 4]) for _ in range(16)]
g = grid()
for y in range(16):
    for x in range(16):
        v = base[x] + rng.choice([-1, 0, 0, 1])
        if x in (2, 7, 12) or (x + (y // 5)) % 9 == 0:
            v -= 1
        g[y][x] = str(clamp(v, 0, 4))
for _ in range(6):
    cx, cy = rng.randrange(16), rng.randrange(16)
    r = rng.choice([1, 1, 2])
    for y in range(16):
        for x in range(16):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + rng.choice([0, 0, 1]):
                g[y][x] = str(rng.choice([5, 6, 6, 7]))
tiles.append(dict(cell=37, name="jungle_bark", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- jungle rings (log end)
rng = random.Random(1102)
pal = "3b2414 4d3220 63422a 7a5535 936a41 ad8450 c79d62".split()
g = grid()
ring_val = [6, 5, 4, 5, 3, 4, 2, 1]
for y in range(16):
    for x in range(16):
        d = max(abs(x - 7.5), abs(y - 7.5))
        ring = int(d)
        v = ring_val[min(ring, 7)] + rng.choice([-1, 0, 0, 0, 1])
        if ring >= 7:
            v = rng.choice([0, 1, 1])
        g[y][x] = str(clamp(v, 0, 6))
tiles.append(dict(cell=38, name="jungle_rings", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- jungle leaves
rng = random.Random(1103)
pal = "0e5a1a 156f21 1e892a 29a334 3ebe44".split()
g = grid()
for y in range(16):
    for x in range(16):
        v = rng.choice([1, 2, 2, 3, 3, 0, 4])
        g[y][x] = str(v)
holes = 0
while holes < 20:
    x, y = rng.randrange(16), rng.randrange(16)
    if g[y][x] != '.':
        g[y][x] = '.'
        holes += 1
tiles.append(dict(cell=39, name="jungle_leaves", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- fern (cross-quad plant)
pal = "184f18 236b1f 328a29 49a63a 6cc44f".split()
g = grid()
fronds = [-70, -42, -18, 0, 18, 42, 70]
for k, deg in enumerate(fronds):
    a = math.radians(deg)
    length = 11 if abs(deg) < 30 else 9
    if deg == 0:
        length = 14
    for t in range(length):
        curve = (t / length) ** 2 * (1.5 if deg > 0 else -1.5 if deg < 0 else 0)
        px = 7.5 + math.sin(a) * t * 0.95 + curve
        py = 15.0 - math.cos(a) * t * 0.95 - (t / length) ** 2 * 1.2
        x, y = int(round(px)), int(round(py))
        if 0 <= x < 16 and 0 <= y < 16:
            idx = 0 + int(4 * t / length)
            g[y][x] = str(clamp(idx, 0, 4))
            if t % 2 == 1 and t > 2:
                for dx in (-1, 1):
                    xx = x + dx
                    if 0 <= xx < 16 and g[y][xx] == '.':
                        g[y][xx] = str(clamp(idx + 1, 1, 4))
tiles.append(dict(cell=40, name="fern", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- vine (hanging strands)
rng = random.Random(1105)
pal = "1a5222 28702b 3b9040 56ae4f".split()
g = grid()
strands = [(2, 16), (5, 11), (8, 15), (11, 9), (13, 14)]
for sx, ln in strands:
    for y in range(ln):
        g[y][sx] = '1' if y % 3 else '2'
        if y % 3 == 1 and y > 0:
            for dx in (-1, 1):
                xx = sx + dx
                if 0 <= xx < 16 and g[y][xx] == '.':
                    g[y][xx] = str(rng.choice([2, 3, 3]))
    g[min(ln, 15)][sx] = '3' if ln < 16 else g[15][sx]
for x in range(1, 15):
    if g[0][x] == '.':
        g[0][x] = '0'
tiles.append(dict(cell=41, name="vine", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- hibiscus (flower)
pal = "236b1f 3b9040 56ae4f a3124f d81b60 f2508a ffd54f fff59d".split()
g = grid()
for y in range(8, 16):
    g[y][7] = '1'
    g[y][8] = '0' if y > 10 else '1'
for (lx, ly) in [(5, 11), (4, 10), (10, 12), (11, 11)]:
    g[ly][lx] = '2'
g[12][6] = '2'
g[13][9] = '2'
cx, cy = 7.5, 5.0
for y in range(16):
    for x in range(16):
        dx, dy = x - cx, y - cy
        r = math.hypot(dx, dy)
        ang = math.atan2(dy, dx)
        reach = 5.6 * (0.62 + 0.38 * math.cos(5 * ang))
        if r <= reach:
            if r < 1.0:
                g[y][x] = '7'
            elif r < 1.9:
                g[y][x] = '6'
            elif r > reach - 1.0:
                g[y][x] = '3'
            else:
                g[y][x] = '5' if (x + y) % 3 else '4'
tiles.append(dict(cell=42, name="hibiscus", palette=pal, rows=rows_of(g)))

# ---------------------------------------------------------------- output
def rust_line(t):
    return '    TileSrc { cell: %d, name: "%s", palette: "%s", rows: "%s", wrap: false },' % (
        t['cell'], t['name'], ' '.join(t['palette']), t['rows'])

with open('/home/claude/work/tools/new_tiles.rs.txt', 'w') as f:
    for t in tiles:
        f.write(rust_line(t) + '\n')

# preview sheet
S = 12
sheet = Image.new('RGB', (len(tiles) * (16 * S + 8) + 8, 16 * S + 16), (90, 120, 160))
means = {}
for i, t in enumerate(tiles):
    lut = [tuple(int(p[j:j + 2], 16) for j in (0, 2, 4)) for p in t['palette']]
    rs, gs, bs, n = 0, 0, 0, 0
    for y in range(16):
        for x in range(16):
            ch = t['rows'][y * 16 + x]
            if ch == '.':
                col = (90 + 20 * ((x + y) % 2), 120, 160)
            else:
                d = int(ch, 36)
                col = lut[d]
                rs += col[0]; gs += col[1]; bs += col[2]; n += 1
            for dy in range(S):
                for dx in range(S):
                    sheet.putpixel((8 + i * (16 * S + 8) + x * S + dx, 8 + y * S + dy), col)
    means[t['name']] = (rs // max(n, 1), gs // max(n, 1), bs // max(n, 1))
sheet.save('/home/claude/work/tools/jungle_tiles_preview.png')
print(json.dumps(means))
