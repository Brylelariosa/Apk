//! A small priority-ordered pool of low-priority worker threads, used for every kind of background work
//! (terrain generation, chunk meshing, far-terrain tiles).
//!
//! Jobs with the smallest priority number run first; equal priorities run in the order they were submitted.
//! Finished results come back through `try_recv`, which never blocks. The workers lower their own thread
//! priority, so on a phone they give way to the game thread and the display instead of competing with it.

use std::cmp::Ordering;
use std::collections::BinaryHeap;
use std::sync::mpsc::{channel, Receiver};
use std::sync::{Arc, Condvar, Mutex};
use std::thread::JoinHandle;

use super::{clock, sched};
use crate::diag::probe::{self, Counter};

struct Prio<J> {
    prio: i64,
    seq: u64,
    job: J,
}

impl<J> PartialEq for Prio<J> {
    fn eq(&self, other: &Prio<J>) -> bool {
        self.prio == other.prio && self.seq == other.seq
    }
}

impl<J> Eq for Prio<J> {}

impl<J> PartialOrd for Prio<J> {
    fn partial_cmp(&self, other: &Prio<J>) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl<J> Ord for Prio<J> {
    /// Reversed, so the `BinaryHeap` (a max-heap) pops the smallest priority first.
    fn cmp(&self, other: &Prio<J>) -> Ordering {
        other.prio.cmp(&self.prio).then(other.seq.cmp(&self.seq))
    }
}

struct QueueState<J> {
    heap: BinaryHeap<Prio<J>>,
    shutdown: bool,
}

type Shared<J> = Arc<(Mutex<QueueState<J>>, Condvar)>;

fn lock_state<J>(shared: &Shared<J>) -> std::sync::MutexGuard<'_, QueueState<J>> {
    match shared.0.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    }
}

/// How many worker threads to use for a pool that may take `share` of the machine: leave two cores for the game
/// thread and the graphics driver, and never more than four (more only competes for memory bandwidth).
pub fn default_workers() -> usize {
    sched::cpu_count().saturating_sub(2).clamp(1, 4)
}

pub struct PriorityPool<J, R> {
    shared: Shared<J>,
    results: Receiver<R>,
    seq: u64,
    workers: Vec<JoinHandle<()>>,
}

impl<J: Send + 'static, R: Send + 'static> PriorityPool<J, R> {
    /// Starts `threads` workers named `<name>-<n>` with the given nice value. `make_handler` is called once per
    /// worker, on the calling thread, and returns the function that turns a job into its result.
    pub fn new<F>(name: &str, threads: usize, nice: i32, make_handler: impl Fn() -> F) -> PriorityPool<J, R>
    where
        F: FnMut(J) -> R + Send + 'static,
    {
        let shared: Shared<J> = Arc::new((Mutex::new(QueueState { heap: BinaryHeap::new(), shutdown: false }), Condvar::new()));
        let (tx, rx) = channel::<R>();
        let mut workers = Vec::new();
        for i in 0..threads {
            let s = shared.clone();
            let t = tx.clone();
            let mut handler = make_handler();
            let builder = std::thread::Builder::new().name(format!("{}-{}", name, i));
            let spawned = builder.spawn(move || {
                sched::set_thread_nice(nice);
                loop {
                    let job = {
                        let mut st = lock_state(&s);
                        loop {
                            if st.shutdown {
                                return;
                            }
                            if let Some(p) = st.heap.pop() {
                                break p.job;
                            }
                            let idle_since = if probe::enabled() { clock::now_ns() } else { 0 };
                            st = match s.1.wait(st) {
                                Ok(g) => g,
                                Err(p) => p.into_inner(),
                            };
                            if idle_since != 0 {
                                probe::count(Counter::WorkerIdleNs, clock::now_ns().saturating_sub(idle_since));
                            }
                        }
                    };
                    let result = handler(job);
                    if t.send(result).is_err() {
                        return;
                    }
                }
            });
            match spawned {
                Ok(h) => workers.push(h),
                Err(e) => crate::loge!("could not start worker thread: {}", e),
            }
        }
        PriorityPool { shared, results: rx, seq: 0, workers }
    }

    /// Number of worker threads that actually started.
    pub fn threads(&self) -> usize {
        self.workers.len()
    }

    pub fn submit(&mut self, prio: i64, job: J) {
        self.seq += 1;
        let seq = self.seq;
        let mut st = lock_state(&self.shared);
        st.heap.push(Prio { prio, seq, job });
        drop(st);
        self.shared.1.notify_one();
    }

    /// A finished job, if there is one (never blocks).
    pub fn try_recv(&self) -> Option<R> {
        self.results.try_recv().ok()
    }

    /// Jobs waiting for a worker.
    pub fn queued(&self) -> usize {
        lock_state(&self.shared).heap.len()
    }

    /// Drops every job that has not started yet (running jobs finish normally).
    pub fn clear_queue(&mut self) -> usize {
        let mut st = lock_state(&self.shared);
        let n = st.heap.len();
        st.heap.clear();
        n
    }
}

impl<J, R> Drop for PriorityPool<J, R> {
    fn drop(&mut self) {
        {
            let mut st = lock_state(&self.shared);
            st.shutdown = true;
            st.heap.clear();
        }
        self.shared.1.notify_all();
        for h in self.workers.drain(..) {
            let _ = h.join();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    fn prio(p: i64, seq: u64) -> Prio<u8> {
        Prio { prio: p, seq, job: 0 }
    }

    #[test]
    fn the_smallest_priority_runs_first_and_ties_keep_their_order() {
        let mut heap = BinaryHeap::new();
        heap.push(prio(50, 1));
        heap.push(prio(3, 2));
        heap.push(prio(3, 3));
        heap.push(prio(-1, 4));
        heap.push(prio(900, 5));
        let order: Vec<(i64, u64)> = std::iter::from_fn(|| heap.pop().map(|p| (p.prio, p.seq))).collect();
        assert_eq!(order, vec![(-1, 4), (3, 2), (3, 3), (50, 1), (900, 5)]);
    }

    #[test]
    fn the_default_worker_count_is_between_one_and_four() {
        assert!((1..=4).contains(&default_workers()));
    }

    #[test]
    fn jobs_run_in_priority_order_on_one_worker() {
        // one worker that is held up by the first job, so everything else is queued by the time it is free
        let gate = Arc::new((Mutex::new(false), Condvar::new()));
        let g2 = gate.clone();
        let mut pool: PriorityPool<u32, u32> = PriorityPool::new("vs-test", 1, 0, move || {
            let g = g2.clone();
            move |job: u32| {
                if job == 0 {
                    let (lock, cv) = &*g;
                    let mut open = lock.lock().unwrap();
                    while !*open {
                        open = cv.wait(open).unwrap();
                    }
                }
                job
            }
        });
        pool.submit(0, 0);
        std::thread::sleep(Duration::from_millis(50)); // the worker is now stuck inside job 0
        for (p, j) in [(30, 3u32), (10, 1), (20, 2), (10, 11)] {
            pool.submit(p, j);
        }
        assert_eq!(pool.queued(), 4);
        {
            let (lock, cv) = &*gate;
            *lock.lock().unwrap() = true;
            cv.notify_all();
        }
        let mut got = Vec::new();
        let start = Instant::now();
        while got.len() < 5 {
            match pool.try_recv() {
                Some(r) => got.push(r),
                None => {
                    assert!(start.elapsed() < Duration::from_secs(10), "jobs did not finish: {:?}", got);
                    std::thread::sleep(Duration::from_millis(2));
                }
            }
        }
        assert_eq!(got, vec![0, 1, 11, 2, 3]);
    }

    #[test]
    fn clearing_the_queue_drops_only_waiting_jobs() {
        let gate = Arc::new((Mutex::new(false), Condvar::new()));
        let g2 = gate.clone();
        let mut pool: PriorityPool<u32, u32> = PriorityPool::new("vs-test", 1, 0, move || {
            let g = g2.clone();
            move |job: u32| {
                if job == 0 {
                    let (lock, cv) = &*g;
                    let mut open = lock.lock().unwrap();
                    while !*open {
                        open = cv.wait(open).unwrap();
                    }
                }
                job
            }
        });
        pool.submit(0, 0);
        std::thread::sleep(Duration::from_millis(50));
        pool.submit(1, 1);
        pool.submit(2, 2);
        assert_eq!(pool.clear_queue(), 2);
        {
            let (lock, cv) = &*gate;
            *lock.lock().unwrap() = true;
            cv.notify_all();
        }
        let start = Instant::now();
        let mut got = Vec::new();
        while got.is_empty() {
            if let Some(r) = pool.try_recv() {
                got.push(r);
            }
            assert!(start.elapsed() < Duration::from_secs(10));
            std::thread::sleep(Duration::from_millis(2));
        }
        std::thread::sleep(Duration::from_millis(50));
        assert_eq!(got, vec![0]);
        assert!(pool.try_recv().is_none());
    }
}
