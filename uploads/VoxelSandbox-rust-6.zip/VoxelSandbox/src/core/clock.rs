//! Cheap clocks for the diagnostics: a monotonic nanosecond counter (a few tens of nanoseconds a call), the CPU
//! time a thread has used, and the wall clock converted to local time.

use std::sync::OnceLock;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

static START: OnceLock<Instant> = OnceLock::new();

/// Call once early so `now_ns` counts from process start.
pub fn init() {
    let _ = START.get_or_init(Instant::now);
}

/// Monotonic nanoseconds since `init` (or the first call).
#[inline]
pub fn now_ns() -> u64 {
    START.get_or_init(Instant::now).elapsed().as_nanos() as u64
}

/// Wall clock in milliseconds since the Unix epoch (0 if the clock is before it).
pub fn unix_ms() -> u64 {
    match SystemTime::now().duration_since(UNIX_EPOCH) {
        Ok(d) => d.as_millis() as u64,
        Err(_) => 0,
    }
}

#[cfg(any(target_os = "linux", target_os = "android"))]
mod sys {
    use std::os::raw::{c_int, c_long};

    #[repr(C)]
    pub struct Timespec {
        pub tv_sec: c_long,
        pub tv_nsec: c_long,
    }

    pub const CLOCK_THREAD_CPUTIME_ID: c_int = 3;

    extern "C" {
        pub fn clock_gettime(clock: c_int, ts: *mut Timespec) -> c_int;
        pub fn localtime_r(t: *const c_long, out: *mut Tm) -> *mut Tm;
        pub fn tzset();
    }

    /// The first nine fields of C's `struct tm`; the tail is over-allocated padding for the platform's extras.
    #[repr(C)]
    pub struct Tm {
        pub fields: [c_int; 9],
        pub _tail: [u64; 4],
    }
}

/// CPU time used so far by the calling thread, in nanoseconds (0 where unsupported).
#[cfg(any(target_os = "linux", target_os = "android"))]
pub fn thread_cpu_ns() -> u64 {
    let mut ts = sys::Timespec { tv_sec: 0, tv_nsec: 0 };
    let rc = unsafe { sys::clock_gettime(sys::CLOCK_THREAD_CPUTIME_ID, &mut ts) };
    if rc != 0 {
        return 0;
    }
    (ts.tv_sec as u64).saturating_mul(1_000_000_000).saturating_add(ts.tv_nsec as u64)
}

#[cfg(not(any(target_os = "linux", target_os = "android")))]
pub fn thread_cpu_ns() -> u64 {
    0
}

/// A calendar time in the device's time zone.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LocalTime {
    pub year: i32,
    pub month: u32,
    pub day: u32,
    pub hour: u32,
    pub min: u32,
    pub sec: u32,
}

/// Re-reads the device's time zone. Android's `localtime_r` only looks the zone up once per process, so the log
/// writer calls this now and then to follow a change of time zone (travelling, daylight saving).
#[cfg(any(target_os = "linux", target_os = "android"))]
pub fn refresh_timezone() {
    unsafe { sys::tzset() }
}

#[cfg(not(any(target_os = "linux", target_os = "android")))]
pub fn refresh_timezone() {}

/// Converts Unix seconds to the device's local time (UTC where the platform cannot say).
#[cfg(any(target_os = "linux", target_os = "android"))]
pub fn local_time(unix_secs: i64) -> LocalTime {
    let t = unix_secs as std::os::raw::c_long;
    let mut tm = sys::Tm { fields: [0; 9], _tail: [0; 4] };
    let p = unsafe { sys::localtime_r(&t, &mut tm) };
    if p.is_null() {
        return utc_time(unix_secs);
    }
    let f = &tm.fields;
    LocalTime {
        year: f[5] + 1900,
        month: (f[4] + 1).max(1) as u32,
        day: f[3].max(1) as u32,
        hour: f[2].max(0) as u32,
        min: f[1].max(0) as u32,
        sec: f[0].max(0) as u32,
    }
}

#[cfg(not(any(target_os = "linux", target_os = "android")))]
pub fn local_time(unix_secs: i64) -> LocalTime {
    utc_time(unix_secs)
}

/// Unix seconds to a UTC calendar time (days-from-civil arithmetic, no tables).
pub fn utc_time(unix_secs: i64) -> LocalTime {
    let days = unix_secs.div_euclid(86_400);
    let rem = unix_secs.rem_euclid(86_400);
    // Howard Hinnant's civil_from_days
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let year = if m <= 2 { y + 1 } else { y };
    LocalTime {
        year: year as i32,
        month: m as u32,
        day: d as u32,
        hour: (rem / 3600) as u32,
        min: ((rem % 3600) / 60) as u32,
        sec: (rem % 60) as u32,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn monotonic_clock_moves_forward() {
        init();
        let a = now_ns();
        let mut x = 0u64;
        for i in 0..20_000u64 {
            x = x.wrapping_add(i * i);
        }
        assert!(x > 0);
        let b = now_ns();
        assert!(b >= a);
    }

    #[test]
    fn utc_conversion_matches_known_dates() {
        let t = utc_time(0);
        assert_eq!((t.year, t.month, t.day, t.hour, t.min, t.sec), (1970, 1, 1, 0, 0, 0));
        // 2026-11-07 00:25:00 UTC
        let t = utc_time(1_794_011_100);
        assert_eq!((t.year, t.month, t.day), (2026, 11, 7));
        assert_eq!((t.hour, t.min, t.sec), (0, 25, 0));
        // a leap day
        let t = utc_time(1_709_164_800); // 2024-02-29 00:00:00
        assert_eq!((t.year, t.month, t.day), (2024, 2, 29));
        // before the epoch
        let t = utc_time(-1);
        assert_eq!((t.year, t.month, t.day, t.hour, t.min, t.sec), (1969, 12, 31, 23, 59, 59));
    }

    #[cfg(any(target_os = "linux", target_os = "android"))]
    #[test]
    fn local_time_is_a_sane_calendar_time() {
        let now = (unix_ms() / 1000) as i64;
        let t = local_time(now);
        assert!(t.year >= 2024);
        assert!(t.month >= 1 && t.month <= 12 && t.day >= 1 && t.day <= 31);
        assert!(t.hour < 24 && t.min < 60 && t.sec < 61);
        // within a day of UTC
        let u = utc_time(now);
        let diff = (t.hour as i32 * 60 + t.min as i32) - (u.hour as i32 * 60 + u.min as i32);
        assert!(diff.abs() <= 14 * 60 || (diff.abs() >= 10 * 60), "unreasonable offset {}", diff);
    }

    #[cfg(any(target_os = "linux", target_os = "android"))]
    #[test]
    fn thread_cpu_time_advances_with_work() {
        let a = thread_cpu_ns();
        let mut x = 1u64;
        for i in 0..3_000_000u64 {
            x = x.wrapping_mul(6364136223846793005).wrapping_add(i);
        }
        assert!(x != 0);
        let b = thread_cpu_ns();
        assert!(b > a);
    }
}
