//! Thread scheduling hints. Background threads (world generation, the log writer) lower their own priority so
//! the thread that draws the frames always wins when the phone's cores are busy.

#[cfg(any(target_os = "linux", target_os = "android"))]
mod sys {
    use std::os::raw::{c_int, c_uint};

    extern "C" {
        pub fn setpriority(which: c_int, who: c_uint, prio: c_int) -> c_int;
        pub fn getpriority(which: c_int, who: c_uint) -> c_int;
    }

    /// `PRIO_PROCESS`; on Linux a "who" of 0 means the calling *thread* (each thread has its own nice value).
    pub const PRIO_PROCESS: c_int = 0;
}

/// Sets the calling thread's nice value (higher = lower priority, 19 is the lowest). Returns whether the
/// system accepted it; nothing depends on it, so failures are fine to ignore.
#[cfg(any(target_os = "linux", target_os = "android"))]
pub fn set_thread_nice(nice: i32) -> bool {
    unsafe { sys::setpriority(sys::PRIO_PROCESS, 0, nice) == 0 }
}

#[cfg(not(any(target_os = "linux", target_os = "android")))]
pub fn set_thread_nice(_nice: i32) -> bool {
    false
}

/// The calling thread's nice value (0 where unsupported).
#[cfg(any(target_os = "linux", target_os = "android"))]
pub fn thread_nice() -> i32 {
    unsafe { sys::getpriority(sys::PRIO_PROCESS, 0) }
}

#[cfg(not(any(target_os = "linux", target_os = "android")))]
pub fn thread_nice() -> i32 {
    0
}

/// Number of CPU cores the process may use (at least 1).
pub fn cpu_count() -> usize {
    std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2).max(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_thread_can_lower_only_its_own_priority() {
        let before = thread_nice();
        let handle = std::thread::spawn(|| {
            let ok = set_thread_nice(10);
            (ok, thread_nice())
        });
        let (ok, inside) = handle.join().unwrap();
        if ok {
            assert!(inside >= 10, "nice inside the thread was {}", inside);
        }
        assert_eq!(thread_nice(), before, "the calling thread must be unaffected");
    }

    #[test]
    fn there_is_at_least_one_core() {
        assert!(cpu_count() >= 1);
    }
}
