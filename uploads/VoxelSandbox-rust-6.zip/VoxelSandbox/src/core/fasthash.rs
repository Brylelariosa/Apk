//! A fast hash for the small integer keys the game uses everywhere (chunk and tile positions).
//!
//! The standard hasher is built to resist deliberately crafted keys, which costs several times more than the
//! lookup itself; keys here are positions made by the game, so a cheap multiplicative hash is plenty.

use std::collections::{HashMap, HashSet};
use std::hash::{BuildHasherDefault, Hasher};

const K: u64 = 0x517c_c1b7_2722_0a95;

#[derive(Default, Clone, Copy)]
pub struct FastHasher(u64);

impl Hasher for FastHasher {
    #[inline]
    fn finish(&self) -> u64 {
        // spread the high bits down: hash tables pick buckets from the low ones
        let h = self.0;
        (h ^ (h >> 32)).wrapping_mul(0x9E37_79B9_7F4A_7C15) ^ (h >> 29)
    }

    #[inline]
    fn write(&mut self, bytes: &[u8]) {
        for &b in bytes {
            self.0 = (self.0.rotate_left(5) ^ b as u64).wrapping_mul(K);
        }
    }

    #[inline]
    fn write_i32(&mut self, i: i32) {
        self.0 = (self.0.rotate_left(5) ^ i as u32 as u64).wrapping_mul(K);
    }

    #[inline]
    fn write_u32(&mut self, i: u32) {
        self.0 = (self.0.rotate_left(5) ^ i as u64).wrapping_mul(K);
    }

    #[inline]
    fn write_u8(&mut self, i: u8) {
        self.0 = (self.0.rotate_left(5) ^ i as u64).wrapping_mul(K);
    }

    #[inline]
    fn write_u64(&mut self, i: u64) {
        self.0 = (self.0.rotate_left(5) ^ i).wrapping_mul(K);
    }

    #[inline]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64);
    }

    #[inline]
    fn write_usize(&mut self, i: usize) {
        self.write_u64(i as u64);
    }
}

pub type FastBuild = BuildHasherDefault<FastHasher>;
pub type FastMap<K, V> = HashMap<K, V, FastBuild>;
pub type FastSet<K> = HashSet<K, FastBuild>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn it_behaves_like_a_map() {
        let mut m: FastMap<(i32, i32), i32> = FastMap::default();
        for x in -50..50 {
            for z in -50..50 {
                m.insert((x, z), x * 1000 + z);
            }
        }
        assert_eq!(m.len(), 10_000);
        assert_eq!(m.get(&(-7, 13)), Some(&(-7 * 1000 + 13)));
        assert_eq!(m.remove(&(3, 3)), Some(3003));
        assert!(m.get(&(3, 3)).is_none());
    }

    #[test]
    fn neighbouring_positions_spread_over_the_buckets() {
        use std::hash::{BuildHasher, Hash};
        let build = FastBuild::default();
        let mut buckets = [0u32; 256];
        for x in 0..64 {
            for z in 0..64 {
                let mut h = build.build_hasher();
                (x as i32, z as i32).hash(&mut h);
                buckets[(h.finish() & 255) as usize] += 1;
            }
        }
        let max = *buckets.iter().max().unwrap();
        // 4096 keys over 256 buckets: 16 per bucket on average; a bad hash piles them up
        assert!(max < 40, "worst bucket holds {}", max);
    }
}
