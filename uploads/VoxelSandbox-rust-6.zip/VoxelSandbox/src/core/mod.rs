//! Platform-independent building blocks: maths, the Kotlin-compatible random generator and logging.

pub mod clock;
pub mod fasthash;
pub mod log;
pub mod math;
pub mod pool;
pub mod rng;
pub mod sched;
