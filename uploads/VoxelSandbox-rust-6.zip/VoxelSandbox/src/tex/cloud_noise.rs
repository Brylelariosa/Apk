//! The cloud shape as a small tileable texture.
//!
//! The clouds used to be calculated for every pixel of the sky (four octaves of value noise, a lot of arithmetic on
//! a phone GPU). The same shape is now made once here, as a 256x256 single-channel picture that repeats without
//! seams, and the cloud shader only looks it up.

/// Texels along one side of the texture.
pub const SIZE: usize = 256;
/// Lattice cells along one side for the first octave; every further octave has twice as many.
pub const BASE_CELLS: usize = 8;
pub const OCTAVES: usize = 4;
/// Size of one first-octave cell in blocks (the cloud pattern's biggest features).
pub const BLOCKS_PER_BASE_CELL: f64 = 312.5;
/// How many blocks one repeat of the texture covers.
pub const BLOCKS_PER_REPEAT: f64 = BASE_CELLS as f64 * BLOCKS_PER_BASE_CELL;

fn hash32(mut x: u32) -> u32 {
    x ^= x >> 16;
    x = x.wrapping_mul(0x7FEB_352D);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846C_A68B);
    x ^ (x >> 16)
}

/// The random value of lattice point (`ix`, `iy`) of an octave, in `0 ..= 1`.
fn lattice_value(ix: usize, iy: usize, octave: usize) -> f32 {
    let h = hash32((ix as u32).wrapping_mul(0x9E37_79B1) ^ hash32((iy as u32) ^ ((octave as u32 + 1).wrapping_mul(0x85EB_CA6B))));
    (h >> 8) as f32 / 16_777_215.0
}

fn smooth(t: f32) -> f32 {
    t * t * (3.0 - 2.0 * t)
}

/// `SIZE * SIZE` texels (row by row) of fractal value noise, 0 = clear sky. Every octave's lattice wraps around, so
/// the picture continues seamlessly past its edges. Values reach about 0.94 at most (the amplitudes add up to
/// 0.9375), and the cloud shader's thresholds (0.50 to 0.68) are chosen for that range.
pub fn generate() -> Vec<u8> {
    let mut sum = vec![0.0f32; SIZE * SIZE];
    let mut amplitude = 0.5f32;
    for octave in 0..OCTAVES {
        let n = BASE_CELLS << octave;
        let cell = SIZE / n;
        let mut lattice = vec![0.0f32; n * n];
        for iy in 0..n {
            for ix in 0..n {
                lattice[iy * n + ix] = lattice_value(ix, iy, octave);
            }
        }
        for ty in 0..SIZE {
            let gy = ty / cell;
            let gy1 = (gy + 1) % n;
            let sy = smooth((ty % cell) as f32 / cell as f32);
            for tx in 0..SIZE {
                let gx = tx / cell;
                let gx1 = (gx + 1) % n;
                let sx = smooth((tx % cell) as f32 / cell as f32);
                let a = lattice[gy * n + gx];
                let b = lattice[gy * n + gx1];
                let c = lattice[gy1 * n + gx];
                let d = lattice[gy1 * n + gx1];
                let top = a + (b - a) * sx;
                let bottom = c + (d - c) * sx;
                sum[ty * SIZE + tx] += amplitude * (top + (bottom - top) * sy);
            }
        }
        amplitude *= 0.5;
    }
    sum.iter().map(|&v| (v * 255.0 + 0.5).max(0.0).min(255.0) as u8).collect()
}

/// Where the cloud picture is under the player: the texture coordinates (0 ..= 1, wrapping) of the point straight
/// above `(x, z)` after the clouds have drifted for `time` seconds. Done in `f64` so it stays exact far from the
/// origin.
pub fn map_origin(x: f64, z: f64, time: f64) -> [f32; 2] {
    let u = (x + time * WIND[0]) / BLOCKS_PER_REPEAT;
    let v = (z + time * WIND[1]) / BLOCKS_PER_REPEAT;
    [(u - u.floor()) as f32, (v - v.floor()) as f32]
}

/// How fast the clouds drift, in blocks per second along x and z: slowly, about one block per second.
pub const WIND: [f64; 2] = [2.2, 0.75];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_picture_has_the_right_size_and_range() {
        let t = generate();
        assert_eq!(t.len(), SIZE * SIZE);
        let max = *t.iter().max().unwrap();
        let min = *t.iter().min().unwrap();
        assert!(max <= 240, "the amplitudes add up to 0.9375 of full scale, got {}", max);
        assert!(max >= 150, "there must be dense clouds, got {}", max);
        assert!(min <= 70, "there must be clear sky, got {}", min);
    }

    #[test]
    fn about_a_third_of_the_sky_is_cloudy() {
        let t = generate();
        let cloudy = t.iter().filter(|&&v| v as f32 / 255.0 > 0.55).count() as f32 / t.len() as f32;
        assert!(cloudy > 0.2 && cloudy < 0.6, "{:.0}% cloudy", cloudy * 100.0);
    }

    #[test]
    fn the_picture_repeats_without_a_seam() {
        let t = generate();
        let diff = |a: u8, b: u8| (a as i32 - b as i32).abs();
        let mut worst_inside = 0;
        let mut worst_seam = 0;
        for y in 0..SIZE {
            for x in 0..SIZE - 1 {
                worst_inside = worst_inside.max(diff(t[y * SIZE + x], t[y * SIZE + x + 1]));
            }
            worst_seam = worst_seam.max(diff(t[y * SIZE + SIZE - 1], t[y * SIZE]));
        }
        for x in 0..SIZE {
            for y in 0..SIZE - 1 {
                worst_inside = worst_inside.max(diff(t[y * SIZE + x], t[(y + 1) * SIZE + x]));
            }
            worst_seam = worst_seam.max(diff(t[(SIZE - 1) * SIZE + x], t[x]));
        }
        assert!(worst_seam <= worst_inside, "seam step {} is bigger than any step inside ({})", worst_seam, worst_inside);
    }

    #[test]
    fn it_is_the_same_every_time() {
        assert_eq!(generate(), generate());
    }

    #[test]
    fn the_map_origin_wraps_and_drifts() {
        let a = map_origin(0.0, 0.0, 0.0);
        assert_eq!(a, [0.0, 0.0]);
        let b = map_origin(BLOCKS_PER_REPEAT, -BLOCKS_PER_REPEAT, 0.0);
        assert!(b[0].abs() < 1e-6 && b[1].abs() < 1e-6, "one whole repeat away is the same spot: {:?}", b);
        let far = map_origin(1.0e7 + 100.0, -3.0e7, 12.0);
        assert!(far[0] >= 0.0 && far[0] < 1.0 && far[1] >= 0.0 && far[1] < 1.0, "{:?}", far);
        let c = map_origin(0.0, 0.0, 100.0);
        assert!(c[0] > 0.0, "the clouds drift");
    }
}
