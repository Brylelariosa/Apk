//! Minimal OpenGL ES 3.0 bindings (just what the renderer uses), declared by hand against `libGLESv3`.

#![allow(non_snake_case, dead_code)]

use std::os::raw::{c_char, c_float, c_int, c_uchar, c_uint, c_void};

pub type GLenum = c_uint;
pub type GLuint = c_uint;
pub type GLint = c_int;
pub type GLsizei = c_int;
pub type GLfloat = c_float;
pub type GLboolean = c_uchar;
pub type GLbitfield = c_uint;
pub type GLchar = c_char;
pub type GLubyte = c_uchar;
pub type GLsizeiptr = isize;
pub type GLintptr = isize;

pub const GL_FALSE: GLboolean = 0;
pub const GL_TRUE: GLboolean = 1;

pub const GL_DEPTH_BUFFER_BIT: GLbitfield = 0x0000_0100;
pub const GL_COLOR_BUFFER_BIT: GLbitfield = 0x0000_4000;

pub const GL_TRIANGLES: GLenum = 0x0004;
pub const GL_TRIANGLE_STRIP: GLenum = 0x0005;

pub const GL_DEPTH_TEST: GLenum = 0x0B71;
pub const GL_CULL_FACE: GLenum = 0x0B44;
pub const GL_BLEND: GLenum = 0x0BE2;
pub const GL_LESS: GLenum = 0x0201;
pub const GL_LEQUAL: GLenum = 0x0203;
pub const GL_BACK: GLenum = 0x0405;
pub const GL_CCW: GLenum = 0x0901;
pub const GL_SRC_ALPHA: GLenum = 0x0302;
pub const GL_ONE_MINUS_SRC_ALPHA: GLenum = 0x0303;

pub const GL_VERTEX_SHADER: GLenum = 0x8B31;
pub const GL_FRAGMENT_SHADER: GLenum = 0x8B30;
pub const GL_COMPILE_STATUS: GLenum = 0x8B81;
pub const GL_LINK_STATUS: GLenum = 0x8B82;
pub const GL_INFO_LOG_LENGTH: GLenum = 0x8B84;

pub const GL_ARRAY_BUFFER: GLenum = 0x8892;
pub const GL_ELEMENT_ARRAY_BUFFER: GLenum = 0x8893;
pub const GL_STATIC_DRAW: GLenum = 0x88E4;
pub const GL_STREAM_DRAW: GLenum = 0x88E0;
pub const GL_DYNAMIC_DRAW: GLenum = 0x88E8;

pub const GL_FLOAT: GLenum = 0x1406;
pub const GL_UNSIGNED_BYTE: GLenum = 0x1401;
pub const GL_UNSIGNED_INT: GLenum = 0x1405;
pub const GL_UNSIGNED_SHORT: GLenum = 0x1403;

pub const GL_TEXTURE_2D: GLenum = 0x0DE1;
pub const GL_TEXTURE_2D_ARRAY: GLenum = 0x8C1A;
pub const GL_TEXTURE0: GLenum = 0x84C0;
pub const GL_TEXTURE2: GLenum = 0x84C2;
pub const GL_TEXTURE1: GLenum = 0x84C1;
pub const GL_TEXTURE_MIN_FILTER: GLenum = 0x2801;
pub const GL_TEXTURE_MAG_FILTER: GLenum = 0x2800;
pub const GL_TEXTURE_WRAP_S: GLenum = 0x2802;
pub const GL_TEXTURE_WRAP_T: GLenum = 0x2803;
pub const GL_NEAREST: GLint = 0x2600;
pub const GL_LINEAR: GLint = 0x2601;
pub const GL_NEAREST_MIPMAP_LINEAR: GLint = 0x2702;
pub const GL_LINEAR_MIPMAP_LINEAR: GLint = 0x2703;
pub const GL_REPEAT: GLint = 0x2901;
pub const GL_CLAMP_TO_EDGE: GLint = 0x812F;
pub const GL_RGBA: GLenum = 0x1908;
pub const GL_RGBA8: GLint = 0x8058;
/// One 8-bit channel (the cloud noise texture).
pub const GL_R8: GLint = 0x8229;
pub const GL_RED: GLenum = 0x1903;
pub const GL_UNPACK_ALIGNMENT: GLenum = 0x0CF5;

pub const GL_RENDERER: GLenum = 0x1F01;
pub const GL_VERSION: GLenum = 0x1F02;
pub const GL_VENDOR: GLenum = 0x1F00;
pub const GL_EXTENSIONS: GLenum = 0x1F03;

pub const GL_SCISSOR_TEST: GLenum = 0x0C11;

// timer queries (GL_EXT_disjoint_timer_query, usable through the ES 3.0 query functions)
pub const GL_TIME_ELAPSED_EXT: GLenum = 0x88BF;
pub const GL_GPU_DISJOINT_EXT: GLenum = 0x8FBB;
pub const GL_QUERY_RESULT: GLenum = 0x8866;
pub const GL_QUERY_RESULT_AVAILABLE: GLenum = 0x8867;

// off-screen render targets (used to draw the 3D world at a lower resolution)
pub const GL_FRAMEBUFFER: GLenum = 0x8D40;
pub const GL_READ_FRAMEBUFFER: GLenum = 0x8CA8;
pub const GL_DRAW_FRAMEBUFFER: GLenum = 0x8CA9;
pub const GL_RENDERBUFFER: GLenum = 0x8D41;
pub const GL_COLOR_ATTACHMENT0: GLenum = 0x8CE0;
pub const GL_DEPTH_ATTACHMENT: GLenum = 0x8D00;
pub const GL_DEPTH_COMPONENT24: GLenum = 0x81A6;
/// `GL_RGBA8` as the enum `glRenderbufferStorage` wants (the texture functions take it as an int).
pub const GL_RGBA8_FORMAT: GLenum = 0x8058;
pub const GL_FRAMEBUFFER_COMPLETE: GLenum = 0x8CD5;
/// `glBlitFramebuffer` filter (an enum there, an int for texture parameters).
pub const GL_LINEAR_FILTER: GLenum = 0x2601;
/// Attachment names of the default framebuffer, for `glInvalidateFramebuffer`.
pub const GL_DEPTH: GLenum = 0x1801;
pub const GL_STENCIL: GLenum = 0x1802;

#[link(name = "GLESv3")]
extern "C" {
    pub fn glClearColor(r: GLfloat, g: GLfloat, b: GLfloat, a: GLfloat);
    pub fn glClear(mask: GLbitfield);
    pub fn glViewport(x: GLint, y: GLint, w: GLsizei, h: GLsizei);
    pub fn glEnable(cap: GLenum);
    pub fn glDisable(cap: GLenum);
    pub fn glDepthFunc(func: GLenum);
    pub fn glDepthMask(flag: GLboolean);
    pub fn glDepthRangef(near: GLfloat, far: GLfloat);
    pub fn glBlendFunc(sfactor: GLenum, dfactor: GLenum);
    pub fn glCullFace(mode: GLenum);
    pub fn glFrontFace(mode: GLenum);

    pub fn glCreateShader(kind: GLenum) -> GLuint;
    pub fn glShaderSource(shader: GLuint, count: GLsizei, string: *const *const GLchar, length: *const GLint);
    pub fn glCompileShader(shader: GLuint);
    pub fn glGetShaderiv(shader: GLuint, pname: GLenum, params: *mut GLint);
    pub fn glGetShaderInfoLog(shader: GLuint, buf_size: GLsizei, length: *mut GLsizei, info_log: *mut GLchar);
    pub fn glDeleteShader(shader: GLuint);
    pub fn glCreateProgram() -> GLuint;
    pub fn glAttachShader(program: GLuint, shader: GLuint);
    pub fn glLinkProgram(program: GLuint);
    pub fn glGetProgramiv(program: GLuint, pname: GLenum, params: *mut GLint);
    pub fn glGetProgramInfoLog(program: GLuint, buf_size: GLsizei, length: *mut GLsizei, info_log: *mut GLchar);
    pub fn glUseProgram(program: GLuint);
    pub fn glDeleteProgram(program: GLuint);
    pub fn glGetUniformLocation(program: GLuint, name: *const GLchar) -> GLint;
    pub fn glUniform1i(location: GLint, v0: GLint);
    pub fn glUniform1f(location: GLint, v0: GLfloat);
    pub fn glUniform2f(location: GLint, v0: GLfloat, v1: GLfloat);
    pub fn glUniform3f(location: GLint, v0: GLfloat, v1: GLfloat, v2: GLfloat);
    pub fn glUniform4f(location: GLint, v0: GLfloat, v1: GLfloat, v2: GLfloat, v3: GLfloat);
    pub fn glUniformMatrix4fv(location: GLint, count: GLsizei, transpose: GLboolean, value: *const GLfloat);

    pub fn glGenBuffers(n: GLsizei, buffers: *mut GLuint);
    pub fn glBindBuffer(target: GLenum, buffer: GLuint);
    pub fn glBufferData(target: GLenum, size: GLsizeiptr, data: *const c_void, usage: GLenum);
    pub fn glDeleteBuffers(n: GLsizei, buffers: *const GLuint);
    pub fn glGenVertexArrays(n: GLsizei, arrays: *mut GLuint);
    pub fn glBindVertexArray(array: GLuint);
    pub fn glDeleteVertexArrays(n: GLsizei, arrays: *const GLuint);
    pub fn glEnableVertexAttribArray(index: GLuint);
    pub fn glVertexAttribPointer(
        index: GLuint,
        size: GLint,
        kind: GLenum,
        normalized: GLboolean,
        stride: GLsizei,
        pointer: *const c_void,
    );
    pub fn glVertexAttribIPointer(index: GLuint, size: GLint, kind: GLenum, stride: GLsizei, pointer: *const c_void);
    pub fn glDrawElements(mode: GLenum, count: GLsizei, kind: GLenum, indices: *const c_void);
    pub fn glDrawArrays(mode: GLenum, first: GLint, count: GLsizei);

    pub fn glGenTextures(n: GLsizei, textures: *mut GLuint);
    pub fn glBindTexture(target: GLenum, texture: GLuint);
    pub fn glTexImage2D(
        target: GLenum,
        level: GLint,
        internal_format: GLint,
        width: GLsizei,
        height: GLsizei,
        border: GLint,
        format: GLenum,
        kind: GLenum,
        pixels: *const c_void,
    );
    pub fn glTexImage3D(
        target: GLenum,
        level: GLint,
        internal_format: GLint,
        width: GLsizei,
        height: GLsizei,
        depth: GLsizei,
        border: GLint,
        format: GLenum,
        kind: GLenum,
        pixels: *const c_void,
    );
    pub fn glTexParameteri(target: GLenum, pname: GLenum, param: GLint);
    pub fn glActiveTexture(texture: GLenum);
    pub fn glGenerateMipmap(target: GLenum);
    pub fn glDeleteTextures(n: GLsizei, textures: *const GLuint);
    pub fn glPixelStorei(pname: GLenum, param: GLint);

    pub fn glGenFramebuffers(n: GLsizei, framebuffers: *mut GLuint);
    pub fn glBindFramebuffer(target: GLenum, framebuffer: GLuint);
    pub fn glDeleteFramebuffers(n: GLsizei, framebuffers: *const GLuint);
    pub fn glGenRenderbuffers(n: GLsizei, renderbuffers: *mut GLuint);
    pub fn glBindRenderbuffer(target: GLenum, renderbuffer: GLuint);
    pub fn glDeleteRenderbuffers(n: GLsizei, renderbuffers: *const GLuint);
    pub fn glRenderbufferStorage(target: GLenum, internal_format: GLenum, width: GLsizei, height: GLsizei);
    pub fn glFramebufferRenderbuffer(target: GLenum, attachment: GLenum, renderbuffer_target: GLenum, renderbuffer: GLuint);
    pub fn glCheckFramebufferStatus(target: GLenum) -> GLenum;
    pub fn glBlitFramebuffer(
        src_x0: GLint,
        src_y0: GLint,
        src_x1: GLint,
        src_y1: GLint,
        dst_x0: GLint,
        dst_y0: GLint,
        dst_x1: GLint,
        dst_y1: GLint,
        mask: GLbitfield,
        filter: GLenum,
    );
    pub fn glInvalidateFramebuffer(target: GLenum, num_attachments: GLsizei, attachments: *const GLenum);

    pub fn glScissor(x: GLint, y: GLint, w: GLsizei, h: GLsizei);
    pub fn glFlush();

    pub fn glGenQueries(n: GLsizei, ids: *mut GLuint);
    pub fn glDeleteQueries(n: GLsizei, ids: *const GLuint);
    pub fn glBeginQuery(target: GLenum, id: GLuint);
    pub fn glEndQuery(target: GLenum);
    pub fn glGetQueryObjectuiv(id: GLuint, pname: GLenum, params: *mut GLuint);
    pub fn glGetIntegerv(pname: GLenum, data: *mut GLint);

    pub fn glGetError() -> GLenum;
    pub fn glGetString(name: GLenum) -> *const GLubyte;
}
