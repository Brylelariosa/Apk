//! GLSL ES 3.00 sources.
//!
//! The shaders are written for a small tile-based GPU (Mali, Adreno): everything that is interpolated between the
//! vertices and the pixels is `mediump` (half the memory traffic of `highp`, which is what limits such GPUs when a
//! scene has hundreds of thousands of triangles), the fog is worked out per vertex instead of per pixel, and the
//! pixel shaders are kept short. Positions and matrices stay `highp`.
//!
//! The terrain pixel shader exists in two variants made from the same text: `TERRAIN_FS` as it is (no `discard`,
//! so the GPU can reject hidden pixels early) for solid blocks, and with `ALPHA_TEST` defined for leaves and plants.

/// `#define`s that switch the variants of a shader (see `Program::with_defines`).
pub const DEFINE_ALPHA_TEST: &str = "ALPHA_TEST";

pub const TERRAIN_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;
layout(location = 3) in uvec4 aInfo;

uniform mat4 uViewProj;
uniform vec3 uOffset;
// x: distance where the fog starts, y: 1 / (distance from the start of the fog to full fog)
uniform vec2 uFog;

out mediump vec2 vUv;
out mediump vec4 vColor;
out mediump float vFog;
// x: texture layer, y: tint mode
flat out mediump vec2 vInfo;

void main() {
    vec3 rel = aPos + uOffset;
    gl_Position = uViewProj * vec4(rel, 1.0);
    vUv = aUv;
    vColor = aColor;
    vFog = clamp((length(rel) - uFog.x) * uFog.y, 0.0, 1.0);
    vInfo = vec2(aInfo.xy);
}
"#;

pub const TERRAIN_FS: &str = r#"#version 300 es
precision mediump float;
precision mediump sampler2DArray;

in vec2 vUv;
in vec4 vColor;
in float vFog;
flat in vec2 vInfo;

uniform sampler2DArray uTex;
uniform vec3 uFogColor;

out vec4 fragColor;

void main() {
    vec4 t = texture(uTex, vec3(vUv, vInfo.x));
#ifdef ALPHA_TEST
    if (t.a < 0.5) discard;
#endif
    vec3 rgb = t.rgb;
    if (vInfo.y > 1.5) {
        float m = clamp((1.0 - t.a) * 12.75, 0.0, 1.0);
        rgb *= mix(vec3(1.0), vColor.rgb * 2.0, m);
    } else if (vInfo.y > 0.5) {
        rgb *= vColor.rgb * 2.0;
    }
    rgb *= vColor.a;
    fragColor = vec4(mix(rgb, uFogColor, vFog), 1.0);
}
"#;

/// Water: the vertex shader only passes things on. (The ripples used to be worked out here, per vertex, but a merged
/// water surface has vertices up to 8 blocks apart, more than a wave is long, so they came out as wide streaks.)
pub const WATER_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;
layout(location = 3) in uvec4 aInfo;

uniform mat4 uViewProj;
uniform vec3 uOffset;
uniform vec2 uFog;

out mediump vec2 vUv;
out mediump float vShade;
out mediump float vFog;
flat out mediump float vLayer;

void main() {
    vec3 rel = aPos + uOffset;
    gl_Position = uViewProj * vec4(rel, 1.0);
    vUv = aUv;
    vShade = aColor.a;
    vFog = clamp((length(rel) - uFog.x) * uFog.y, 0.0, 1.0);
    vLayer = float(aInfo.x);
}
"#;

/// The ripples are three crossing waves worked out per pixel. Their wave numbers are whole multiples of 2 pi / 16, so
/// they repeat seamlessly where the texture coordinates wrap every 16 blocks (see the mesher), and they are
/// computed in high precision because the time grows without bound. Deeper water is more opaque.
pub const WATER_FS: &str = r#"#version 300 es
precision mediump float;
precision mediump sampler2DArray;

in vec2 vUv;
in float vShade;
in float vFog;
flat in float vLayer;

uniform sampler2DArray uTex;
uniform vec3 uFogColor;
uniform highp float uTime;

out vec4 fragColor;

void main() {
    vec3 base = texture(uTex, vec3(vUv, vLayer)).rgb;
    highp float t = uTime;
    float r1 = sin(dot(vUv, vec2(0.78539816, 0.39269908)) + t * 1.3);
    float r2 = sin(dot(vUv, vec2(-0.39269908, 1.17809725)) - t * 1.0);
    float r3 = sin(dot(vUv, vec2(1.17809725, -0.78539816)) + t * 0.7);
    float ripple = (r1 + r2 + r3) * 0.3333;
    vec3 rgb = base * (0.91 + 0.08 * ripple) * vShade;
    rgb += vec3(0.08, 0.10, 0.12) * (max(ripple - 0.15, 0.0) * vShade);
    float depth = clamp((1.0 - vShade) * 2.2, 0.0, 1.0);
    float alpha = mix(mix(0.58, 0.90, depth), 1.0, vFog);
    fragColor = vec4(mix(rgb, uFogColor, vFog), alpha);
}
"#;

/// Far terrain: coloured flat-shaded columns, faded into the fog like the blocks.
pub const FAR_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec4 aColor;

uniform mat4 uViewProj;
uniform vec3 uOffset;
uniform vec2 uFog;

out mediump vec3 vColor;
out mediump float vFog;

void main() {
    vec3 rel = aPos + uOffset;
    gl_Position = uViewProj * vec4(rel, 1.0);
    vColor = aColor.rgb;
    vFog = clamp((length(rel) - uFog.x) * uFog.y, 0.0, 1.0);
}
"#;

pub const FAR_FS: &str = r#"#version 300 es
precision mediump float;

in vec3 vColor;
in float vFog;

uniform vec3 uFogColor;

out vec4 fragColor;

// The face shading is already in the vertex colours (the far terrain is built from flat faces), so all that is
// left is the fog.
void main() {
    fragColor = vec4(mix(vColor, uFogColor, vFog), 1.0);
}
"#;

pub const LINE_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
uniform mat4 uViewProj;
void main() {
    gl_Position = uViewProj * vec4(aPos, 1.0);
}
"#;

pub const LINE_FS: &str = r#"#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main() {
    fragColor = uColor;
}
"#;

/// The sky is one big triangle. The view direction of every pixel is worked out by interpolating the directions of
/// the three corners, so the pixel shader only has to normalise it. The sun's disc is a sharp power function that
/// is only worth evaluating right next to the sun.
pub const SKY_VS: &str = r#"#version 300 es
precision highp float;
uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
out vec3 vDir;
void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vec2 ndc = corner * 2.0 - 1.0;
    vDir = uForward + uRight * (ndc.x * uTan.x) + uUp * (ndc.y * uTan.y);
    gl_Position = vec4(ndc, 1.0, 1.0);
}
"#;

pub const SKY_FS: &str = r#"#version 300 es
precision highp float;
in vec3 vDir;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;
out vec4 fragColor;
void main() {
    vec3 dir = normalize(vDir);
    vec3 col = mix(uHorizon, uZenith, sqrt(clamp(dir.y, 0.0, 1.0)));
    float sd = max(dot(dir, uSunDir), 0.0);
    float s2 = sd * sd;
    float s4 = s2 * s2;
    float s8 = s4 * s4;
    float glow = s8 * s2 * 0.14;
    if (sd > 0.99) {
        glow += pow(sd, 1500.0) * 2.0;
    }
    col += vec3(1.0, 0.90, 0.68) * glow;
    fragColor = vec4(col, 1.0);
}
"#;

/// The cloud layer: one huge quad high above the player. The cloud shape comes from a small tileable noise
/// texture (see `noise`) instead of being calculated for every pixel, which is what made the clouds expensive.
pub const CLOUD_VS: &str = r#"#version 300 es
precision highp float;
uniform mat4 uViewProj;
uniform float uHeight;
uniform float uHalf;
// x, y: noise texture units per block, z, w: the texture coordinate under the player
uniform vec4 uMap;
out vec2 vUv;
out vec2 vRel;
void main() {
    vec2 c = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
    vec2 rel = c * uHalf;
    vRel = rel;
    vUv = rel * uMap.xy + uMap.zw;
    gl_Position = uViewProj * vec4(rel.x, uHeight, rel.y, 1.0);
}
"#;

pub const CLOUD_FS: &str = r#"#version 300 es
precision highp float;
in vec2 vUv;
in vec2 vRel;
uniform sampler2D uNoise;
uniform float uHalf;
out vec4 fragColor;
void main() {
    float n = texture(uNoise, vUv).r;
    float a = smoothstep(0.50, 0.68, n);
    float fade = 1.0 - smoothstep(0.55 * uHalf, 0.98 * uHalf, length(vRel));
    vec3 col = mix(vec3(0.80, 0.85, 0.93), vec3(1.0), smoothstep(0.52, 0.85, n));
    fragColor = vec4(col, a * 0.92 * fade);
}
"#;

pub const UI_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;
layout(location = 3) in float aLayer;
uniform mat4 uProj;
out vec2 vUv;
out vec4 vColor;
flat out float vLayer;
void main() {
    gl_Position = uProj * vec4(aPos, 0.0, 1.0);
    vUv = aUv;
    vColor = aColor;
    vLayer = aLayer;
}
"#;

pub const UI_FS: &str = r#"#version 300 es
precision highp float;
precision highp sampler2DArray;
in vec2 vUv;
in vec4 vColor;
flat in float vLayer;
uniform sampler2DArray uTex;
uniform sampler2D uFont;
out vec4 fragColor;
void main() {
    if (vLayer > -0.5) {
        fragColor = texture(uTex, vec3(vUv, vLayer)) * vColor;
    } else if (vLayer > -1.5) {
        fragColor = vColor;
    } else {
        fragColor = vec4(vColor.rgb, vColor.a * texture(uFont, vUv).a);
    }
}
"#;
