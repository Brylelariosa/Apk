//! The off-screen picture the 3D world is drawn into when the "resolution" setting is below 100%, and when the game
//! is paused.
//!
//! Drawing the world into a smaller buffer and stretching it over the screen cuts the pixel work in proportion
//! (60% resolution = 36% of the pixels). The menus and the HUD are still drawn at the screen's real size on top, so
//! text stays sharp. While the game is paused nothing in the world moves, so its picture is drawn once into a
//! target and only copied to the screen in the frames after, instead of drawing the whole world again and again
//! behind a menu (which heats the phone for nothing).

use super::gl::*;

/// A colour + depth render target.
pub struct SceneTarget {
    fbo: GLuint,
    color: GLuint,
    depth: GLuint,
    width: i32,
    height: i32,
}

/// The size to render at for a screen of `width` x `height` pixels at `percent` of its native resolution.
/// Even numbers, never tiny.
pub fn scaled_size(width: i32, height: i32, percent: i32) -> (i32, i32) {
    let p = percent.max(10).min(100) as i64;
    let w = ((width as i64 * p / 100) as i32).max(64) & !1;
    let h = ((height as i64 * p / 100) as i32).max(64) & !1;
    (w.min(width.max(2)), h.min(height.max(2)))
}

impl SceneTarget {
    /// Creates a target of the given size, or `None` if the driver does not accept it (the caller then draws
    /// straight to the screen).
    pub fn create(width: i32, height: i32) -> Option<SceneTarget> {
        if width < 2 || height < 2 {
            return None;
        }
        let mut fbo: GLuint = 0;
        let mut rbo: [GLuint; 2] = [0, 0];
        unsafe {
            // clear any error left over from earlier code so the check below is about this function only
            while glGetError() != 0 {}
            glGenFramebuffers(1, &mut fbo as *mut GLuint);
            glGenRenderbuffers(2, rbo.as_mut_ptr());
            glBindRenderbuffer(GL_RENDERBUFFER, rbo[0]);
            glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8_FORMAT, width, height);
            glBindRenderbuffer(GL_RENDERBUFFER, rbo[1]);
            glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, width, height);
            glBindRenderbuffer(GL_RENDERBUFFER, 0);
            glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, rbo[0]);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rbo[1]);
            let status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
            let error = glGetError();
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            if status != GL_FRAMEBUFFER_COMPLETE || error != 0 {
                crate::logw!("render target {}x{} refused (status 0x{:x}, error 0x{:x})", width, height, status, error);
                glDeleteFramebuffers(1, &fbo as *const GLuint);
                glDeleteRenderbuffers(2, rbo.as_ptr());
                return None;
            }
        }
        Some(SceneTarget { fbo, color: rbo[0], depth: rbo[1], width, height })
    }

    pub fn size(&self) -> (i32, i32) {
        (self.width, self.height)
    }

    /// Makes this the surface drawing goes to (and sets the viewport to cover it).
    pub fn bind(&self) {
        unsafe {
            glBindFramebuffer(GL_FRAMEBUFFER, self.fbo);
            glViewport(0, 0, self.width, self.height);
        }
    }

    /// Stretches the picture over the screen and goes back to drawing on the screen. Returns false if the driver
    /// reported an error doing it (the caller should stop using targets). With `keep_picture` the picture stays
    /// valid so that `show_kept` can put it on the screen again in later frames; otherwise it is dropped.
    pub fn present(&self, screen_w: i32, screen_h: i32, check: bool, keep_picture: bool) -> bool {
        unsafe {
            if check {
                while glGetError() != 0 {}
            }
            // the depth is never needed after drawing: say so while the target is still the surface being drawn
            // to, so a tile-based GPU does not write it out to memory
            glBindFramebuffer(GL_FRAMEBUFFER, self.fbo);
            let depth: [GLenum; 1] = [GL_DEPTH_ATTACHMENT];
            glInvalidateFramebuffer(GL_FRAMEBUFFER, 1, depth.as_ptr());
            glBindFramebuffer(GL_READ_FRAMEBUFFER, self.fbo);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
            glBlitFramebuffer(0, 0, self.width, self.height, 0, 0, screen_w, screen_h, GL_COLOR_BUFFER_BIT, GL_LINEAR_FILTER);
            let ok = !check || glGetError() == 0;
            if !keep_picture {
                let colour: [GLenum; 1] = [GL_COLOR_ATTACHMENT0];
                glInvalidateFramebuffer(GL_READ_FRAMEBUFFER, 1, colour.as_ptr());
            }
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            glViewport(0, 0, screen_w, screen_h);
            ok
        }
    }

    /// Puts the picture kept by `present(.., keep_picture = true)` on the screen again.
    pub fn show_kept(&self, screen_w: i32, screen_h: i32) {
        unsafe {
            glBindFramebuffer(GL_READ_FRAMEBUFFER, self.fbo);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
            glBlitFramebuffer(0, 0, self.width, self.height, 0, 0, screen_w, screen_h, GL_COLOR_BUFFER_BIT, GL_LINEAR_FILTER);
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            glViewport(0, 0, screen_w, screen_h);
        }
    }

    /// Frees the GPU objects (needs the context that made them).
    pub fn delete(self) {
        unsafe {
            glDeleteFramebuffers(1, &self.fbo as *const GLuint);
            let rbo = [self.color, self.depth];
            glDeleteRenderbuffers(2, rbo.as_ptr());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scaled_sizes_are_even_and_never_bigger_than_the_screen() {
        assert_eq!(scaled_size(2400, 1080, 100), (2400, 1080));
        assert_eq!(scaled_size(2400, 1080, 50), (1200, 540));
        let (w, h) = scaled_size(2401, 1081, 75);
        assert!(w % 2 == 0 && h % 2 == 0 && w <= 2401 && h <= 1081);
        let (w, h) = scaled_size(100, 50, 40);
        assert!(w >= 2 && h >= 2 && w <= 100 && h <= 50, "{}x{}", w, h);
        let (w, h) = scaled_size(3000, 1500, 0);
        assert!(w >= 64 && h >= 64);
    }
}
