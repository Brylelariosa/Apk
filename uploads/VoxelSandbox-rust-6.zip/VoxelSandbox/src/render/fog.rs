//! Distance fog: what the shaders blend far things into.

use super::gl::*;

/// Fog that starts `start` blocks from the camera and is complete at `end` blocks.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Fog {
    pub color: [f32; 3],
    pub start: f32,
    pub end: f32,
}

impl Fog {
    /// What the shaders' `uFog` holds: where the fog starts and one over its length (so the shader multiplies
    /// instead of dividing).
    pub fn params(&self) -> (f32, f32) {
        (self.start, 1.0 / (self.end - self.start).max(0.001))
    }

    /// Sets the fog uniforms of the program that is in use.
    pub fn apply(&self, color_location: GLint, fog_location: GLint) {
        let (start, inverse_length) = self.params();
        unsafe {
            glUniform3f(color_location, self.color[0], self.color[1], self.color[2]);
            glUniform2f(fog_location, start, inverse_length);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_parameters_turn_distance_into_a_fraction() {
        let fog = Fog { color: [0.5; 3], start: 100.0, end: 300.0 };
        let (start, inv) = fog.params();
        let at = |d: f32| ((d - start) * inv).max(0.0).min(1.0);
        assert_eq!(at(50.0), 0.0);
        assert_eq!(at(200.0), 0.5);
        assert_eq!(at(400.0), 1.0);
    }

    #[test]
    fn a_zero_length_fog_does_not_divide_by_zero() {
        let fog = Fog { color: [0.0; 3], start: 10.0, end: 10.0 };
        assert!(fog.params().1.is_finite());
    }
}
