//! Remembering the level the automatic quality control settled on, so the next launch starts there instead of
//! walking down from the player's settings again (a stuttery half minute on a phone that cannot hold them).
//! A tiny text file next to the saved world: "detail resolution", for example `12 100`.

use std::fs;
use std::path::Path;

use super::governor::Quality;

/// The remembered level, if there is a readable file.
pub fn load_quality(path: &Path) -> Option<Quality> {
    parse(&fs::read_to_string(path).ok()?)
}

/// Remembers `q`. Failing to write is not worth a message: the level is just not remembered.
pub fn save_quality(path: &Path, q: Quality) {
    let _ = fs::write(path, format!("{} {}\n", q.detail_chunks, q.resolution_percent));
}

fn parse(text: &str) -> Option<Quality> {
    let mut it = text.split_whitespace();
    let detail: i32 = it.next()?.parse().ok()?;
    let resolution: i32 = it.next()?.parse().ok()?;
    if it.next().is_some() || detail < 1 || detail > 1000 || resolution < 10 || resolution > 100 {
        return None;
    }
    Some(Quality { detail_chunks: detail, resolution_percent: resolution })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_saved_level_comes_back() {
        let dir = std::env::temp_dir().join("vs_quality_memory_test");
        let _ = fs::create_dir_all(&dir);
        let path = dir.join("quality.txt");
        let _ = fs::remove_file(&path);
        assert_eq!(load_quality(&path), None, "nothing saved yet");
        let q = Quality { detail_chunks: 14, resolution_percent: 85 };
        save_quality(&path, q);
        assert_eq!(load_quality(&path), Some(q));
        let _ = fs::remove_file(&path);
    }

    #[test]
    fn garbage_is_not_believed() {
        for text in ["", "12", "a b", "12 100 7", "0 100", "12 5", "-3 100", "12 400", "1e9 100"] {
            assert_eq!(parse(text), None, "{:?}", text);
        }
        assert_eq!(parse("  8   60 \n"), Some(Quality { detail_chunks: 8, resolution_percent: 60 }));
    }
}
