//! The automatic quality controller ("auto performance").
//!
//! The player's settings say the *most* the game may draw: how far real blocks are built (`detail distance`) and
//! how sharp the picture is (`resolution`). The governor looks at how long frames take and walks down a ladder of
//! cheaper combinations when the game cannot keep 60 frames per second, and back up when there is room again.
//!
//! * The ladder (see [`ladder`]) first shortens the real-block distance, because that is where the GPU time goes
//!   on a phone (every extra ring of chunks is hundreds of draw calls and a few hundred thousand triangles; the
//!   far terrain covers the view beyond it at a fraction of the cost), then lowers the resolution.
//! * Going down is quick (two slow seconds in a row, or one very slow second). Going up is slow and is tried as an
//!   experiment: after a long stretch of smooth frames one step is given back, and if the frames get slow again
//!   within a few seconds the step is taken back and the next try waits twice as long. So it settles on the best
//!   level the phone can hold instead of flickering between two.
//! * When the GPU's own frame time is known (timer queries) it is used to see room for a better level without
//!   having to try, because with vertical sync a smooth 60 fps says nothing about how much time is left.

/// The settings the game actually runs with.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Quality {
    /// Chunks of real blocks around the player.
    pub detail_chunks: i32,
    /// Share of the screen's own resolution the 3D world is drawn at.
    pub resolution_percent: i32,
}

/// Why the quality changed.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Why {
    /// Two slow seconds in a row.
    Slow,
    /// One very slow second.
    Severe,
    /// A try at a better level went slow again.
    FailedTry,
    /// Smooth frames for long enough (or a GPU with time to spare): trying a better level.
    Room,
}

impl Why {
    pub fn text(self) -> &'static str {
        match self {
            Why::Slow => "frames are slow",
            Why::Severe => "frames are very slow",
            Why::FailedTry => "that was too much, going back",
            Why::Room => "there is room to spare",
        }
    }
}

/// What one decision did, for the debug log.
#[derive(Clone, Debug, PartialEq)]
pub struct Change {
    pub from: Quality,
    pub to: Quality,
    /// Average frame time of the last second, in ms.
    pub frame_ms: f32,
    /// Average GPU time per frame in ms, when the GPU reports it.
    pub gpu_ms: Option<f32>,
    pub why: Why,
}

impl Change {
    /// One line for the debug log.
    pub fn describe(&self) -> String {
        let gpu = match self.gpu_ms {
            Some(g) => format!(", GPU {:.1} ms", g),
            None => String::new(),
        };
        format!(
            "auto performance: {} -> {} ({}; frames {:.1} ms{})",
            quality_text(&self.from),
            quality_text(&self.to),
            self.why.text(),
            self.frame_ms,
            gpu
        )
    }
}

pub fn quality_text(q: &Quality) -> String {
    format!("{} chunks at {}%", q.detail_chunks, q.resolution_percent)
}

/// Never go below this many chunks of real blocks (the far terrain takes over beyond).
pub const MIN_AUTO_DETAIL: i32 = 6;
/// The real-block distance is lowered to this before the resolution is touched.
pub const COMFORT_DETAIL: i32 = 12;
/// Never draw below this share of the native resolution.
pub const MIN_AUTO_RESOLUTION: i32 = 50;

/// Frames slower than this (about 51 fps) count as slow ...
const SLOW_FRAME_MS: f32 = 19.5;
/// ... faster than this (about 57 fps) as good, and anything between as "fine, leave it".
const FAST_FRAME_MS: f32 = 17.6;
/// A second this slow is acted on at once.
const SEVERE_FRAME_MS: f32 = 30.0;
/// A second this slow (about 22 fps) is acted on at once and by a bigger step.
const VERY_SEVERE_FRAME_MS: f32 = 45.0;
/// One frame never counts for more than this, so a single stall does not look like a slow second.
const FRAME_CLAMP_MS: f32 = 50.0;
const FRAME_BUDGET_MS: f32 = 1000.0 / 60.0;
/// Share of the 60 fps frame time the GPU may use for the level to count as having room to spare.
const GPU_ROOM: f32 = 0.70;
const GPU_PLENTY_OF_ROOM: f32 = 0.50;
const WINDOW_SECS: f32 = 1.0;
/// After a change the frames are not judged for this long (the world is still adjusting).
const SETTLE_SECS: f32 = 2.0;
/// Seconds ignored after the game starts being played (shaders compiling, chunks streaming in).
pub const WARMUP_SECS: f32 = 5.0;
/// Smooth seconds needed before the first attempt to go up, and the longest wait after failed attempts.
const FIRST_HOLD_SECS: f32 = 20.0;
const MAX_HOLD_SECS: f32 = 240.0;
/// An attempt to go up that gets slow within this many seconds has failed.
const PROBE_GRACE_SECS: f32 = 8.0;

/// The levels, best first: the player's own settings, then cheaper and cheaper combinations.
pub fn ladder(max_detail: i32, max_resolution: i32) -> Vec<Quality> {
    let max_detail = max_detail.max(1);
    let max_resolution = max_resolution.max(1);
    let floor_detail = MIN_AUTO_DETAIL.min(max_detail);
    let comfort = COMFORT_DETAIL.min(max_detail).max(floor_detail);
    let resolution_at = |fraction: f32| -> i32 {
        let r = ((max_resolution as f32 * fraction) / 5.0).round() as i32 * 5;
        r.max(MIN_AUTO_RESOLUTION.min(max_resolution)).min(max_resolution)
    };
    let mut steps: Vec<Quality> = Vec::new();
    let mut push = |detail: i32, resolution: i32| {
        let q = Quality { detail_chunks: detail, resolution_percent: resolution };
        if steps.last() != Some(&q) {
            steps.push(q);
        }
    };
    // 1. shorten the block world down to the comfortable distance, two chunks at a time
    let mut d = max_detail;
    while d > comfort {
        push(d, max_resolution);
        d -= 2;
    }
    push(comfort, max_resolution);
    // 2. soften the picture a little
    push(comfort, resolution_at(0.85));
    push(comfort, resolution_at(0.72));
    // 3. shorten the block world further
    let mut d = comfort - 2;
    while d >= floor_detail {
        push(d, resolution_at(0.72));
        d -= 2;
    }
    push(floor_detail, resolution_at(0.72));
    // 4. and finally lower the resolution again
    push(floor_detail, resolution_at(0.60));
    push(floor_detail, resolution_at(0.50));
    steps
}

#[derive(Default)]
struct Window {
    frames: u32,
    secs: f32,
    ms_sum: f32,
    gpu_sum: f32,
    gpu_samples: u32,
}

pub struct Governor {
    enabled: bool,
    max_detail: i32,
    max_resolution: i32,
    ladder: Vec<Quality>,
    level: usize,
    window: Window,
    /// Seconds still to ignore (after starting to play or after a change).
    ignore_secs: f32,
    since_change: f32,
    slow_seconds_in_a_row: u32,
    good_seconds: f32,
    /// Smooth seconds required before trying one level up (grows after failed attempts).
    hold_secs: f32,
    /// The current level was reached by going up and has not proved itself yet.
    probing: bool,
    last_change: Option<Change>,
}

impl Governor {
    pub fn new(max_detail: i32, max_resolution: i32) -> Governor {
        Governor {
            enabled: true,
            max_detail,
            max_resolution,
            ladder: ladder(max_detail, max_resolution),
            level: 0,
            window: Window::default(),
            ignore_secs: WARMUP_SECS,
            since_change: 0.0,
            slow_seconds_in_a_row: 0,
            good_seconds: 0.0,
            hold_secs: FIRST_HOLD_SECS,
            probing: false,
            last_change: None,
        }
    }

    pub fn is_enabled(&self) -> bool {
        self.enabled
    }

    /// Turns the controller on or off. Switched on it starts from the best level and works its way down if it has to.
    pub fn set_enabled(&mut self, on: bool) {
        if on == self.enabled {
            return;
        }
        self.enabled = on;
        self.restart();
    }

    /// The most the player allows. A change starts the search again from the best level.
    pub fn set_limits(&mut self, max_detail: i32, max_resolution: i32) {
        if (max_detail, max_resolution) == (self.max_detail, self.max_resolution) {
            return;
        }
        self.max_detail = max_detail;
        self.max_resolution = max_resolution;
        self.ladder = ladder(max_detail, max_resolution);
        self.restart();
    }

    fn restart(&mut self) {
        self.level = 0;
        self.window = Window::default();
        self.ignore_secs = SETTLE_SECS;
        self.since_change = 0.0;
        self.slow_seconds_in_a_row = 0;
        self.good_seconds = 0.0;
        self.probing = false;
    }

    /// Starts from the level a previous run settled on (the best ladder level that is no better than `q`), so a
    /// phone that cannot hold the player's settings does not have to find that out again at every launch.
    pub fn start_at(&mut self, q: Quality) {
        self.level = self
            .ladder
            .iter()
            .position(|l| l.detail_chunks <= q.detail_chunks && l.resolution_percent <= q.resolution_percent)
            .unwrap_or(self.ladder.len() - 1);
    }

    /// Call when play (re)starts: the first seconds are not judged.
    pub fn begin_play(&mut self, from_loading: bool) {
        self.window = Window::default();
        self.ignore_secs = if from_loading { WARMUP_SECS } else { SETTLE_SECS };
        self.slow_seconds_in_a_row = 0;
        self.good_seconds = 0.0;
    }

    /// What the game should run with now.
    pub fn quality(&self) -> Quality {
        if self.enabled {
            self.ladder[self.level]
        } else {
            Quality { detail_chunks: self.max_detail, resolution_percent: self.max_resolution }
        }
    }

    /// True when it is running below what the player allows.
    pub fn is_reduced(&self) -> bool {
        self.enabled && self.level > 0
    }

    /// The decision made since the last call, if any (for the debug log).
    pub fn take_change(&mut self) -> Option<Change> {
        self.last_change.take()
    }

    /// Feeds one played frame: `dt` seconds since the last one, and the GPU's time for a recent frame if known.
    /// Returns true when the quality changed.
    pub fn observe(&mut self, dt: f32, gpu_ms: Option<f32>) -> bool {
        if !self.enabled || !dt.is_finite() || dt <= 0.0 {
            return false;
        }
        if self.ignore_secs > 0.0 {
            self.ignore_secs -= dt;
            return false;
        }
        self.since_change += dt;
        let w = &mut self.window;
        w.frames += 1;
        w.secs += dt;
        w.ms_sum += (dt * 1000.0).min(FRAME_CLAMP_MS);
        if let Some(g) = gpu_ms {
            if g.is_finite() && g > 0.0 {
                w.gpu_sum += g;
                w.gpu_samples += 1;
            }
        }
        if w.secs < WINDOW_SECS {
            return false;
        }
        let secs = w.secs;
        let frame_ms = w.ms_sum / w.frames.max(1) as f32;
        let gpu = if w.gpu_samples >= 10 { Some(w.gpu_sum / w.gpu_samples as f32) } else { None };
        self.window = Window::default();
        self.judge(frame_ms, gpu, secs)
    }

    fn judge(&mut self, frame_ms: f32, gpu_ms: Option<f32>, secs: f32) -> bool {
        let slow = frame_ms > SLOW_FRAME_MS;
        let severe = frame_ms > SEVERE_FRAME_MS;
        let gpu_has_room = gpu_ms.map(|g| g < GPU_ROOM * FRAME_BUDGET_MS);
        let fast = frame_ms < FAST_FRAME_MS && gpu_has_room != Some(false);

        if self.probing && self.since_change >= PROBE_GRACE_SECS && !slow {
            // the level reached by going up held: it is the new normal
            self.probing = false;
            self.hold_secs = (self.hold_secs * 0.8).max(FIRST_HOLD_SECS);
        }

        if slow {
            self.good_seconds = 0.0;
            self.slow_seconds_in_a_row += 1;
            let failed_try = self.probing;
            if (severe || failed_try || self.slow_seconds_in_a_row >= 2) && self.level + 1 < self.ladder.len() {
                let (why, steps) = if failed_try {
                    self.hold_secs = (self.hold_secs * 2.0).min(MAX_HOLD_SECS);
                    (Why::FailedTry, 1)
                } else if frame_ms > VERY_SEVERE_FRAME_MS {
                    (Why::Severe, 3)
                } else if severe {
                    (Why::Severe, 2)
                } else {
                    (Why::Slow, 1)
                };
                // a phone that is far too slow should not have to be told so level by level
                let target = (self.level + steps).min(self.ladder.len() - 1);
                return self.move_to(target, frame_ms, gpu_ms, why);
            }
            return false;
        }
        self.slow_seconds_in_a_row = 0;
        if !fast || self.level == 0 {
            self.good_seconds = 0.0;
            return false;
        }
        self.good_seconds += secs;
        let plenty = gpu_ms.map_or(false, |g| g < GPU_PLENTY_OF_ROOM * FRAME_BUDGET_MS);
        let hold = if plenty { self.hold_secs * 0.5 } else { self.hold_secs };
        if self.good_seconds >= hold {
            return self.move_to(self.level - 1, frame_ms, gpu_ms, Why::Room);
        }
        false
    }

    fn move_to(&mut self, level: usize, frame_ms: f32, gpu_ms: Option<f32>, why: Why) -> bool {
        let from = self.ladder[self.level];
        let to = self.ladder[level];
        self.level = level;
        self.since_change = 0.0;
        self.ignore_secs = SETTLE_SECS;
        self.good_seconds = 0.0;
        self.slow_seconds_in_a_row = 0;
        // going up is an experiment until it has held for a while; going down is never one
        self.probing = why == Why::Room;
        self.last_change = Some(Change { from, to, frame_ms, gpu_ms, why });
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Runs the governor against a pretend phone whose frame time is `cost(quality)` (vsync keeps it at 16.7 ms or
    /// more) for `seconds` of play, 60 frames per second of simulated time at most.
    fn run(g: &mut Governor, seconds: f32, cost: impl Fn(&Quality) -> f32, with_gpu: bool) -> usize {
        let mut changes = 0;
        let mut t = 0.0;
        while t < seconds {
            let q = g.quality();
            let ms = cost(&q).max(16.67);
            let dt = ms / 1000.0;
            let gpu = if with_gpu { Some(cost(&q)) } else { None };
            if g.observe(dt, gpu) {
                changes += 1;
            }
            t += dt;
        }
        changes
    }

    /// A phone where everything up to 12 chunks is fine and anything more is far too slow.
    fn cliff_phone(q: &Quality) -> f32 {
        if q.detail_chunks >= 14 {
            25.0
        } else {
            10.0
        }
    }

    /// A made-up phone: 4 ms of fixed work plus work that grows with the area of real blocks and the pixel count.
    fn weak_phone(q: &Quality) -> f32 {
        let blocks = (q.detail_chunks * q.detail_chunks) as f32 * 0.075;
        let pixels = (q.resolution_percent as f32 / 100.0).powi(2) * 6.0;
        4.0 + blocks + pixels
    }

    #[test]
    fn the_ladder_goes_from_the_players_settings_to_cheaper_levels() {
        let l = ladder(24, 100);
        assert_eq!(l[0], Quality { detail_chunks: 24, resolution_percent: 100 });
        assert_eq!(l[1], Quality { detail_chunks: 22, resolution_percent: 100 });
        assert!(l.iter().any(|q| q.detail_chunks == COMFORT_DETAIL && q.resolution_percent == 100));
        let last = l.last().unwrap();
        assert_eq!(last.detail_chunks, MIN_AUTO_DETAIL);
        assert_eq!(last.resolution_percent, 50);
        for pair in l.windows(2) {
            assert!(pair[1].detail_chunks <= pair[0].detail_chunks, "{:?} then {:?}", pair[0], pair[1]);
            assert!(pair[1].resolution_percent <= pair[0].resolution_percent, "{:?} then {:?}", pair[0], pair[1]);
            assert_ne!(pair[0], pair[1]);
        }
    }

    #[test]
    fn the_ladder_respects_small_limits() {
        let l = ladder(10, 100);
        assert_eq!(l[0].detail_chunks, 10);
        assert!(l.iter().all(|q| q.detail_chunks <= 10 && q.detail_chunks >= MIN_AUTO_DETAIL));
        let l = ladder(4, 60);
        assert_eq!(l[0], Quality { detail_chunks: 4, resolution_percent: 60 });
        assert!(l.iter().all(|q| q.detail_chunks == 4 && q.resolution_percent <= 60));
        let l = ladder(24, 40);
        assert!(l.iter().all(|q| q.resolution_percent <= 40), "never above the player's own resolution");
    }

    #[test]
    fn a_fast_phone_is_left_alone() {
        let mut g = Governor::new(24, 100);
        let changes = run(&mut g, 300.0, |_| 9.0, true);
        assert_eq!(changes, 0);
        assert_eq!(g.quality(), Quality { detail_chunks: 24, resolution_percent: 100 });
        assert!(!g.is_reduced());
    }

    #[test]
    fn a_slow_phone_is_brought_down_to_what_it_can_hold() {
        let mut g = Governor::new(24, 100);
        run(&mut g, 90.0, weak_phone, false);
        let q = g.quality();
        assert!(q.detail_chunks < 24, "{:?}", q);
        assert!(weak_phone(&q) <= SLOW_FRAME_MS, "settled at {:?} which still costs {:.1} ms", q, weak_phone(&q));
    }

    #[test]
    fn it_settles_instead_of_flickering() {
        let mut g = Governor::new(24, 100);
        run(&mut g, 120.0, cliff_phone, false);
        // from now on only the occasional experiment is allowed: a try up, and going back
        let changes = run(&mut g, 600.0, cliff_phone, false);
        assert!(changes <= 8, "{} changes in ten minutes", changes);
        assert!(g.quality().detail_chunks == 12 || g.probing, "settled at {:?}", g.quality());
    }

    #[test]
    fn a_phone_that_holds_the_comfortable_level_is_not_pushed_lower() {
        let mut g = Governor::new(24, 100);
        run(&mut g, 300.0, cliff_phone, false);
        assert!(g.quality().detail_chunks >= 12, "{:?}", g.quality());
        assert_eq!(g.quality().resolution_percent, 100, "the picture stays sharp while the block distance can still give");
    }

    #[test]
    fn failed_tries_make_the_next_one_wait_longer() {
        let mut g = Governor::new(24, 100);
        run(&mut g, 60.0, cliff_phone, false);
        let before = g.hold_secs;
        run(&mut g, 600.0, cliff_phone, false);
        assert!(g.hold_secs > before, "hold {} then {}", before, g.hold_secs);
        assert!(g.hold_secs <= MAX_HOLD_SECS);
    }

    #[test]
    fn a_very_slow_second_is_acted_on_at_once() {
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        let mut changed = false;
        for _ in 0..40 {
            changed |= g.observe(0.045, None);
        }
        assert!(changed, "45 ms frames must lower the quality within about a second");
        let c = g.take_change().expect("the change is reported");
        assert_eq!(c.why, Why::Severe);
        assert!(c.to.detail_chunks < c.from.detail_chunks);
        assert!(g.take_change().is_none(), "a change is reported once");
    }

    #[test]
    fn a_far_too_slow_phone_skips_levels() {
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        for _ in 0..40 {
            g.observe(0.050, None);
        }
        let c = g.take_change().expect("50 ms frames change the quality at once");
        let at = |q: Quality| ladder(24, 100).iter().position(|l| *l == q).unwrap();
        assert_eq!(at(c.to) - at(c.from), 3, "{:?}", c);
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        for _ in 0..40 {
            g.observe(0.033, None);
        }
        let c = g.take_change().expect("33 ms frames change the quality at once");
        assert_eq!(at(c.to) - at(c.from), 2, "{:?}", c);
    }

    #[test]
    fn it_can_start_from_what_the_last_run_settled_on() {
        let mut g = Governor::new(24, 100);
        g.start_at(Quality { detail_chunks: 12, resolution_percent: 100 });
        assert_eq!(g.quality(), Quality { detail_chunks: 12, resolution_percent: 100 });
        // a level that is not on this ladder (the player's limits changed) lands on the next cheaper one
        g.start_at(Quality { detail_chunks: 13, resolution_percent: 100 });
        assert_eq!(g.quality(), Quality { detail_chunks: 12, resolution_percent: 100 });
        // something better than the player allows is just the best level
        g.start_at(Quality { detail_chunks: 40, resolution_percent: 100 });
        assert_eq!(g.quality(), Quality { detail_chunks: 24, resolution_percent: 100 });
        // worse than everything: the bottom
        g.start_at(Quality { detail_chunks: 1, resolution_percent: 10 });
        assert_eq!(g.quality(), *ladder(24, 100).last().unwrap());
    }

    #[test]
    fn a_remembered_level_that_holds_is_not_a_failed_try() {
        let mut g = Governor::new(24, 100);
        g.start_at(Quality { detail_chunks: 12, resolution_percent: 100 });
        run(&mut g, 60.0, cliff_phone, false);
        assert_eq!(g.quality().detail_chunks, 12, "nothing to fix, nothing changes before the first careful try up");
    }

    #[test]
    fn it_waits_for_the_game_to_settle_before_judging() {
        let mut g = Governor::new(24, 100);
        // the first seconds are slow (shaders compile, chunks stream in) but must not count
        let mut t = 0.0;
        while t < WARMUP_SECS - 0.5 {
            assert!(!g.observe(0.05, None));
            t += 0.05;
        }
        assert_eq!(g.quality().detail_chunks, 24);
    }

    #[test]
    fn a_single_stall_does_not_count_as_a_slow_second() {
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        let mut changed = false;
        for i in 0..60 {
            let dt = if i == 10 { 0.25 } else { 0.0167 };
            changed |= g.observe(dt, None);
        }
        assert!(!changed, "one 250 ms hitch in an otherwise smooth second");
    }

    #[test]
    fn extra_gpu_headroom_allows_going_up_sooner() {
        // GPU time known: the phone is fast enough for the best level, but was pushed down by a temporary slowdown
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        for _ in 0..80 {
            g.observe(0.045, None);
        }
        assert!(g.is_reduced());
        let down = g.quality();
        let mut up_after = None;
        let mut t = 0.0;
        while t < 120.0 {
            if g.observe(0.0167, Some(6.0)) {
                up_after = Some(t);
                break;
            }
            t += 0.0167;
        }
        let up_after = up_after.expect("it should try a better level");
        assert!(up_after < FIRST_HOLD_SECS, "with the GPU mostly idle one try comes after about half the wait, took {:.0} s", up_after);
        assert!(g.quality().detail_chunks > down.detail_chunks);
    }

    #[test]
    fn a_busy_gpu_blocks_going_up_even_at_60_fps() {
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        for _ in 0..80 {
            g.observe(0.045, None);
        }
        let level = g.quality();
        // 60 fps (vsync) but the GPU needs 16 ms of every 16.7: no room
        for _ in 0..(60 * 120) {
            g.observe(0.0167, Some(16.0));
        }
        assert_eq!(g.quality(), level);
    }

    #[test]
    fn changing_the_players_limits_starts_again_from_the_best_level() {
        let mut g = Governor::new(24, 100);
        g.ignore_secs = 0.0;
        for _ in 0..80 {
            g.observe(0.045, None);
        }
        assert!(g.is_reduced());
        g.set_limits(16, 100);
        assert_eq!(g.quality(), Quality { detail_chunks: 16, resolution_percent: 100 });
        g.set_limits(16, 100);
        assert_eq!(g.quality().detail_chunks, 16, "the same limits change nothing");
    }

    #[test]
    fn switched_off_it_runs_the_players_settings() {
        let mut g = Governor::new(24, 90);
        g.ignore_secs = 0.0;
        for _ in 0..80 {
            g.observe(0.045, None);
        }
        assert!(g.is_reduced());
        g.set_enabled(false);
        assert_eq!(g.quality(), Quality { detail_chunks: 24, resolution_percent: 90 });
        assert!(!g.observe(0.1, None));
        g.set_enabled(true);
        assert_eq!(g.quality(), Quality { detail_chunks: 24, resolution_percent: 90 }, "starts from the best level again");
    }

    #[test]
    fn it_stops_at_the_bottom_of_the_ladder() {
        let mut g = Governor::new(24, 100);
        run(&mut g, 600.0, |_| 60.0, false);
        let last = *ladder(24, 100).last().unwrap();
        assert_eq!(g.quality(), last);
    }

    #[test]
    fn a_change_is_described_for_the_log() {
        let c = Change {
            from: Quality { detail_chunks: 24, resolution_percent: 100 },
            to: Quality { detail_chunks: 22, resolution_percent: 100 },
            frame_ms: 27.3,
            gpu_ms: Some(24.9),
            why: Why::Slow,
        };
        let text = c.describe();
        assert!(text.contains("24 chunks at 100%") && text.contains("22 chunks at 100%") && text.contains("27.3") && text.contains("GPU 24.9"), "{}", text);
    }
}
