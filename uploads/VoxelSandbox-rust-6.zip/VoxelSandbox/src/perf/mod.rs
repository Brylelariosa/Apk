//! Keeping the frame rate up on weak phones, without a screen of settings to get right: the `governor` watches
//! how long frames take and lowers (and later raises again) the render resolution and the distance of the real
//! block world, within what the player chose. Pure logic, no GL, so it is tested on any computer.

pub mod governor;
pub mod memory;

pub use governor::{Change, Governor, Quality, Why};
