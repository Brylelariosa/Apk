//! Sets up the debug log for Android: where the file is created (see `storage`) and what the top of the log says
//! about the phone. The log itself (what is measured, how it is written) is in `diag`.

use std::path::{Path, PathBuf};

use android_activity::AndroidApp;

use super::java::JavaHandles;
use super::{device, storage};
use crate::diag::{OpenerFactory, SessionInfo, Telemetry};

/// The telemetry object the shell drives once per frame. Nothing is measured and no file is made until the
/// settings ask for it.
pub fn telemetry(android: &AndroidApp, data_dir: &Path) -> Telemetry {
    let handles = JavaHandles::from_app(android);
    let sdk = AndroidApp::sdk_version();
    // the app's own folders: the external one tells where the shared storage is, both are the fallback
    let mut app_dirs: Vec<PathBuf> = Vec::new();
    if let Some(p) = android.external_data_path() {
        app_dirs.push(p);
    }
    app_dirs.push(data_dir.to_path_buf());

    let factory: OpenerFactory = Box::new(move |file_name: &str| {
        storage::opener(storage::LogPlace { handles, sdk, file_name: file_name.to_string(), app_dirs: app_dirs.clone() })
    });
    Telemetry::new(factory, session_info(sdk))
}

/// What the phone is, as far as it is known before the window exists.
fn session_info(sdk: i32) -> SessionInfo {
    SessionInfo {
        app_version: format!("voxelsandbox {} (Rust)", env!("CARGO_PKG_VERSION")),
        device: device::device_name(),
        os: device::system_name(sdk),
        cpu_cores: std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1),
        notes: vec![device::chip_name()],
        ..SessionInfo::default()
    }
}
