//! Calling Android's own classes from Rust (JNI).
//!
//! The game has no Java or Kotlin code. The few things only the framework can do (hiding the navigation bar,
//! creating a file in the Download folder) are done by calling framework classes through the `jni` crate.
//! The plumbing lives here so the modules that use it stay short and read like the Java they replace.

use std::fmt;

use android_activity::AndroidApp;
use jni::objects::{JObject, JString};
use jni::{JNIEnv, JavaVM};

/// What went wrong in a JNI call, as text that can go straight into the log.
#[derive(Debug)]
pub struct JavaError(pub String);

impl fmt::Display for JavaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl From<jni::errors::Error> for JavaError {
    fn from(e: jni::errors::Error) -> JavaError {
        JavaError(e.to_string())
    }
}

impl From<&str> for JavaError {
    fn from(s: &str) -> JavaError {
        JavaError(s.to_string())
    }
}

impl From<String> for JavaError {
    fn from(s: String) -> JavaError {
        JavaError(s)
    }
}

/// The two pointers `android-activity` hands out (the Java VM and the Activity), kept as integers so they can
/// be copied to the threads that need them.
#[derive(Clone, Copy, Debug)]
pub struct JavaHandles {
    vm: usize,
    activity: usize,
}

impl JavaHandles {
    pub fn from_app(app: &AndroidApp) -> JavaHandles {
        JavaHandles { vm: app.vm_as_ptr() as usize, activity: app.activity_as_ptr() as usize }
    }

    /// Runs `f` on the calling thread with a JNI environment and the Activity.
    ///
    /// The thread is attached to the VM for the duration (and detached afterwards if it was not attached
    /// before). Every local reference made inside `f` is released when it returns, and a Java exception that
    /// is still pending is cleared and turned into an `Err` (a pending exception would crash the next JNI call).
    pub fn with_env<R>(&self, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> Result<R, JavaError>) -> Result<R, JavaError> {
        // SAFETY: both pointers come from `android-activity`, which keeps them valid while the app runs.
        let vm = unsafe { JavaVM::from_raw(self.vm as *mut jni::sys::JavaVM) }?;
        let mut guard = vm.attach_current_thread()?;
        let activity = unsafe { JObject::from_raw(self.activity as jni::sys::jobject) };
        let env: &mut JNIEnv<'_> = &mut guard;
        env.with_local_frame(64, |env| {
            let result = f(env, &activity);
            match take_exception(env) {
                Some(text) => Err(JavaError(text)),
                None => result,
            }
        })
    }
}

/// If a Java exception is pending, clears it and returns its description (for example
/// `java.lang.SecurityException: ...`).
pub fn take_exception(env: &mut JNIEnv<'_>) -> Option<String> {
    if !env.exception_check().unwrap_or(false) {
        return None;
    }
    let throwable = match env.exception_occurred() {
        Ok(t) => t,
        Err(_) => {
            let _ = env.exception_clear();
            return Some("a Java exception".to_string());
        }
    };
    let _ = env.exception_clear();
    let text = env
        .call_method(&throwable, "toString", "()Ljava/lang/String;", &[])
        .and_then(|v| v.l())
        .ok()
        .and_then(|o| read_string(env, o).ok());
    if env.exception_check().unwrap_or(false) {
        let _ = env.exception_clear();
    }
    Some(text.unwrap_or_else(|| "a Java exception".to_string()))
}

/// True for a Java `null` reference.
pub fn is_null(obj: &JObject<'_>) -> bool {
    obj.as_raw().is_null()
}

/// Copies a Java `String` object into a Rust `String`.
pub fn read_string(env: &mut JNIEnv<'_>, obj: JObject<'_>) -> Result<String, JavaError> {
    if is_null(&obj) {
        return Err(JavaError::from("a Java string was null"));
    }
    let js = JString::from(obj);
    let text: String = env.get_string(&js)?.into();
    Ok(text)
}
