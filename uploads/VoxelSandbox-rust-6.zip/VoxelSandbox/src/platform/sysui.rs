//! True full-screen ("immersive") mode: hides the status bar and the navigation bar so no system button covers
//! the game, and keeps them hidden (a swipe from the edge shows them for a moment, then they hide again).
//!
//! All of it is done by calling the framework through JNI on the Java UI thread, so there is no Java code:
//! * Android 11 and newer: `Window.getInsetsController()` -> `setSystemBarsBehavior` + `hide(systemBars)`.
//! * Older Android: `View.setSystemUiVisibility(...)` with the immersive flags.
//!
//! The shell calls `request` when the window is created and whenever the app regains focus, because the system
//! shows the bars again after a dialog, the notification shade or switching apps.

use android_activity::AndroidApp;
use jni::objects::{JObject, JValue};
use jni::JNIEnv;

use super::java::{is_null, take_exception, JavaError, JavaHandles};

/// `WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE`
const BEHAVIOR_TRANSIENT_BARS_BY_SWIPE: i32 = 2;

/// `View.SYSTEM_UI_FLAG_*`: FULLSCREEN | HIDE_NAVIGATION | IMMERSIVE_STICKY | LAYOUT_STABLE |
/// LAYOUT_HIDE_NAVIGATION | LAYOUT_FULLSCREEN
const LEGACY_FLAGS: i32 = 0x0004 | 0x0002 | 0x1000 | 0x0100 | 0x0200 | 0x0400;

/// Android 11 (API 30), the first version with `WindowInsetsController`.
const FIRST_INSETS_CONTROLLER_SDK: i32 = 30;

/// Asks the UI thread to hide the system bars. Returns immediately; the outcome is only logged.
pub fn request(app: &AndroidApp) {
    let handles = JavaHandles::from_app(app);
    let sdk = AndroidApp::sdk_version();
    app.run_on_java_main_thread(Box::new(move || match handles.with_env(|env, activity| apply(env, activity, sdk)) {
        Ok(()) => crate::logi!("full-screen mode applied (Android API {})", sdk),
        Err(e) => crate::logw!("full-screen mode failed: {}", e),
    }));
}

fn apply(env: &mut JNIEnv<'_>, activity: &JObject<'_>, sdk: i32) -> Result<(), JavaError> {
    let window = env.call_method(activity, "getWindow", "()Landroid/view/Window;", &[])?.l()?;
    if is_null(&window) {
        return Err(JavaError::from("the activity has no window yet"));
    }
    if sdk >= FIRST_INSETS_CONTROLLER_SDK {
        match hide_with_insets_controller(env, &window) {
            Ok(()) => return Ok(()),
            Err(e) => {
                // fall back to the old flags; a half-finished attempt may have left an exception behind
                crate::logw!("insets controller failed ({}), using the older full-screen flags", e);
                let _ = take_exception(env);
            }
        }
    }
    hide_with_legacy_flags(env, &window)
}

fn hide_with_insets_controller(env: &mut JNIEnv<'_>, window: &JObject<'_>) -> Result<(), JavaError> {
    // let the window extend under the bars and the camera cut-out
    env.call_method(window, "setDecorFitsSystemWindows", "(Z)V", &[JValue::Bool(0)])?;
    let controller = env.call_method(window, "getInsetsController", "()Landroid/view/WindowInsetsController;", &[])?.l()?;
    if is_null(&controller) {
        return Err(JavaError::from("no insets controller"));
    }
    env.call_method(&controller, "setSystemBarsBehavior", "(I)V", &[JValue::Int(BEHAVIOR_TRANSIENT_BARS_BY_SWIPE)])?;
    let bars = env.call_static_method("android/view/WindowInsets$Type", "systemBars", "()I", &[])?.i()?;
    env.call_method(&controller, "hide", "(I)V", &[JValue::Int(bars)])?;
    Ok(())
}

fn hide_with_legacy_flags(env: &mut JNIEnv<'_>, window: &JObject<'_>) -> Result<(), JavaError> {
    let decor = env.call_method(window, "getDecorView", "()Landroid/view/View;", &[])?.l()?;
    if is_null(&decor) {
        return Err(JavaError::from("the window has no decor view"));
    }
    env.call_method(&decor, "setSystemUiVisibility", "(I)V", &[JValue::Int(LEGACY_FLAGS)])?;
    Ok(())
}
