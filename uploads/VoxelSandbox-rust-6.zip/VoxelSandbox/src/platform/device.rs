//! Facts about the phone for the top of the debug log, read from Android's system properties (no Java needed).

use std::ffi::CString;
use std::os::raw::{c_char, c_int};

extern "C" {
    fn __system_property_get(name: *const c_char, value: *mut c_char) -> c_int;
}

/// `PROP_VALUE_MAX` in `<sys/system_properties.h>`.
const PROP_VALUE_MAX: usize = 92;

/// A system property such as `ro.product.model`; empty when it does not exist.
pub fn property(name: &str) -> String {
    let key = match CString::new(name) {
        Ok(k) => k,
        Err(_) => return String::new(),
    };
    let mut buf = [0 as c_char; PROP_VALUE_MAX];
    // SAFETY: `buf` is PROP_VALUE_MAX bytes, the size the API requires, and `key` is NUL terminated.
    let len = unsafe { __system_property_get(key.as_ptr(), buf.as_mut_ptr()) };
    if len <= 0 {
        return String::new();
    }
    let bytes: Vec<u8> = buf.iter().take(len as usize).map(|&c| c as u8).collect();
    String::from_utf8_lossy(&bytes).into_owned()
}

fn first_non_empty(names: &[&str]) -> String {
    for n in names {
        let v = property(n);
        if !v.is_empty() {
            return v;
        }
    }
    String::new()
}

/// "Samsung SM-S911B"
pub fn device_name() -> String {
    let maker = property("ro.product.manufacturer");
    let model = property("ro.product.model");
    format!("{} {}", maker, model).trim().to_string()
}

/// "Android 14 (API 34)"
pub fn system_name(sdk: i32) -> String {
    format!("Android {} (API {})", property("ro.build.version.release"), sdk)
}

/// "chip s5e9945 / board s5e9945 / abi arm64-v8a"
pub fn chip_name() -> String {
    let chip = first_non_empty(&["ro.soc.model", "ro.hardware.chipname", "ro.board.platform", "ro.hardware"]);
    let board = first_non_empty(&["ro.board.platform", "ro.product.board"]);
    let abi = property("ro.product.cpu.abi");
    format!("chip {} / board {} / abi {}", chip, board, abi)
}
