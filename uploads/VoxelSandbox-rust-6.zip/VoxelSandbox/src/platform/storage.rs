//! Creates the debug log file in the phone's Download folder.
//!
//! * Android 10 and newer ("scoped storage"): the file is created through the system's MediaStore
//!   (`MediaStore.Downloads`). That needs no permission, and the file shows up in Download for every file
//!   manager and share sheet. The calls are made through JNI, so there is no Java code.
//! * Older Android, or if MediaStore refuses: plain file access to `<storage>/Download`.
//! * Last resort: the app's own folder. The Settings screen always says where the file really is.
//!
//! A MediaStore file only gets its final size and listing when the descriptor is closed properly, so the writer
//! closes it whenever the log is flushed (the shell flushes when the app goes to the background) and opens it
//! again in append mode when more has to be written.

use std::fs::File;
use std::io::{self, Write};
use std::mem::ManuallyDrop;
use std::os::unix::io::FromRawFd;
use std::path::{Path, PathBuf};

use jni::objects::{GlobalRef, JObject, JValue};
use jni::JNIEnv;

use super::java::{is_null, read_string, take_exception, JavaError, JavaHandles};
use crate::diag::place;
use crate::diag::{Opened, Opener};

const MIME_TYPE: &str = "text/plain";
/// Android 10 (API 29): the first version with scoped storage and `MediaStore.Downloads`.
const FIRST_MEDIASTORE_DOWNLOADS_SDK: i32 = 29;

/// Everything needed to create the log file.
pub struct LogPlace {
    pub handles: JavaHandles,
    pub sdk: i32,
    pub file_name: String,
    /// The app's own folders (external first), used to find the storage root and as the last resort.
    pub app_dirs: Vec<PathBuf>,
}

/// The function the log writer thread runs to open its file.
pub fn opener(place: LogPlace) -> Opener {
    Box::new(move || open(&place))
}

fn open(p: &LogPlace) -> Result<Opened, String> {
    let mut problems: Vec<String> = Vec::new();

    if p.sdk >= FIRST_MEDIASTORE_DOWNLOADS_SDK {
        match MediaFile::create(p.handles, &p.file_name) {
            Ok(file) => return Ok(Opened { writer: Box::new(file), description: place::download_description(&p.file_name) }),
            Err(e) => problems.push(format!("MEDIASTORE {}", e)),
        }
    }

    for dir in place::download_dir_candidates(&p.app_dirs) {
        match create_in(&dir, &p.file_name) {
            Ok(file) => return Ok(Opened { writer: Box::new(file), description: place::download_description(&p.file_name) }),
            Err(e) => {
                if problems.len() < 3 {
                    problems.push(format!("{} {}", place::friendly_path(&dir), e));
                }
            }
        }
    }

    for dir in p.app_dirs.iter() {
        match create_in(dir, &p.file_name) {
            Ok(file) => {
                let path = dir.join(&p.file_name);
                return Ok(Opened { writer: Box::new(file), description: place::fallback_description(&path, &problems) });
            }
            Err(e) => problems.push(format!("{} {}", place::friendly_path(dir), e)),
        }
    }
    Err(problems.join("; "))
}

fn create_in(dir: &Path, name: &str) -> io::Result<File> {
    let _ = std::fs::create_dir_all(dir);
    File::create(dir.join(name))
}

// ------------------------------------------------------------------------------------------------ MediaStore

/// An open descriptor and the Java object that owns it. Closing the Java object (not just the descriptor) is
/// what tells the system the file is complete.
struct OpenFd {
    file: File,
    pfd: GlobalRef,
}

/// A file created through `MediaStore.Downloads`.
struct MediaFile {
    handles: JavaHandles,
    /// The `content://...` address of the file, for opening it again.
    uri: String,
    open: Option<OpenFd>,
}

impl MediaFile {
    fn create(handles: JavaHandles, name: &str) -> Result<MediaFile, JavaError> {
        let (uri, open) = handles.with_env(|env, activity| {
            let resolver = content_resolver(env, activity)?;
            let item = insert_download_entry(env, &resolver, name)?;
            let text_obj = env.call_method(&item, "toString", "()Ljava/lang/String;", &[])?.l()?;
            let uri = read_string(env, text_obj)?;
            match open_descriptor(env, &resolver, &item, "w") {
                Ok(open) => Ok((uri, open)),
                Err(e) => {
                    // keep the Java exception's text (it says why), and do not leave an empty entry behind
                    let detail = take_exception(env).unwrap_or(e.0);
                    let _ = delete_entry(env, &resolver, &item);
                    let _ = take_exception(env);
                    Err(JavaError(detail))
                }
            }
        })?;
        Ok(MediaFile { handles, uri, open: Some(open) })
    }

    /// Opens the file again, appending to what is already there.
    fn reopen(&mut self) -> Result<(), JavaError> {
        let text = self.uri.clone();
        let open = self.handles.with_env(|env, activity| {
            let resolver = content_resolver(env, activity)?;
            let item = parse_uri(env, &text)?;
            open_descriptor(env, &resolver, &item, "wa")
        })?;
        self.open = Some(open);
        Ok(())
    }

    /// Closes the file properly (the system then updates its size and listing).
    fn release(&mut self) {
        if let Some(open) = self.open.take() {
            let OpenFd { file, pfd } = open;
            drop(file);
            let _ = self.handles.with_env(move |env, _| {
                env.call_method(&pfd, "close", "()V", &[])?;
                Ok(())
            });
        }
    }
}

impl Write for MediaFile {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        if self.open.is_none() {
            self.reopen().map_err(|e| io::Error::new(io::ErrorKind::Other, e.0))?;
        }
        match self.open.as_mut() {
            Some(o) => o.file.write(buf),
            None => Err(io::Error::new(io::ErrorKind::Other, "the log file is closed")),
        }
    }

    /// Finishes the file for now: it is closed, and opened again by the next `write`.
    fn flush(&mut self) -> io::Result<()> {
        if let Some(o) = self.open.as_mut() {
            o.file.flush()?;
        }
        self.release();
        Ok(())
    }
}

impl Drop for MediaFile {
    fn drop(&mut self) {
        self.release();
    }
}

fn content_resolver<'local>(env: &mut JNIEnv<'local>, activity: &JObject<'_>) -> Result<JObject<'local>, JavaError> {
    let resolver = env.call_method(activity, "getContentResolver", "()Landroid/content/ContentResolver;", &[])?.l()?;
    if is_null(&resolver) {
        return Err(JavaError::from("no content resolver"));
    }
    Ok(resolver)
}

fn put_text(env: &mut JNIEnv<'_>, values: &JObject<'_>, key: &str, value: &str) -> Result<(), JavaError> {
    let k: JObject = env.new_string(key)?.into();
    let v: JObject = env.new_string(value)?.into();
    env.call_method(values, "put", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::Object(&k), JValue::Object(&v)])?;
    Ok(())
}

/// `resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, {name, mime type, "Download"})`
fn insert_download_entry<'local>(env: &mut JNIEnv<'local>, resolver: &JObject<'_>, name: &str) -> Result<JObject<'local>, JavaError> {
    let values = env.new_object("android/content/ContentValues", "()V", &[])?;
    put_text(env, &values, "_display_name", name)?;
    put_text(env, &values, "mime_type", MIME_TYPE)?;
    put_text(env, &values, "relative_path", "Download")?;
    let collection = env.get_static_field("android/provider/MediaStore$Downloads", "EXTERNAL_CONTENT_URI", "Landroid/net/Uri;")?.l()?;
    let item = env
        .call_method(
            resolver,
            "insert",
            "(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;",
            &[JValue::Object(&collection), JValue::Object(&values)],
        )?
        .l()?;
    if is_null(&item) {
        return Err(JavaError::from("the system would not create the file"));
    }
    Ok(item)
}

fn parse_uri<'local>(env: &mut JNIEnv<'local>, text: &str) -> Result<JObject<'local>, JavaError> {
    let s: JObject = env.new_string(text)?.into();
    let uri = env.call_static_method("android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", &[JValue::Object(&s)])?.l()?;
    if is_null(&uri) {
        return Err(JavaError::from("bad file address"));
    }
    Ok(uri)
}

/// `resolver.openFileDescriptor(item, mode)`, then our own copy of the descriptor for Rust to write to.
fn open_descriptor(env: &mut JNIEnv<'_>, resolver: &JObject<'_>, item: &JObject<'_>, mode: &str) -> Result<OpenFd, JavaError> {
    let mode_text: JObject = env.new_string(mode)?.into();
    let pfd = env
        .call_method(
            resolver,
            "openFileDescriptor",
            "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;",
            &[JValue::Object(item), JValue::Object(&mode_text)],
        )?
        .l()?;
    if is_null(&pfd) {
        return Err(JavaError::from("the system would not open the file"));
    }
    let fd = env.call_method(&pfd, "getFd", "()I", &[])?.i()?;
    if fd < 0 {
        return Err(JavaError::from("no file descriptor"));
    }
    // The Java object keeps owning `fd`; Rust writes through its own duplicate so the two never close the same
    // descriptor twice.
    // SAFETY: `fd` is open and owned by the ParcelFileDescriptor; `ManuallyDrop` stops us closing it.
    let borrowed = ManuallyDrop::new(unsafe { File::from_raw_fd(fd) });
    let file = borrowed.try_clone().map_err(|e| JavaError(format!("could not copy the descriptor: {}", e)))?;
    let pfd = env.new_global_ref(&pfd)?;
    Ok(OpenFd { file, pfd })
}

fn delete_entry(env: &mut JNIEnv<'_>, resolver: &JObject<'_>, item: &JObject<'_>) -> Result<(), JavaError> {
    let none = JObject::null();
    env.call_method(
        resolver,
        "delete",
        "(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I",
        &[JValue::Object(item), JValue::Object(&none), JValue::Object(&none)],
    )?;
    Ok(())
}
