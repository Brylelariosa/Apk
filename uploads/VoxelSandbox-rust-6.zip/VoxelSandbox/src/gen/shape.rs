//! The land-form of the world as a pure function of (x, z): oceans, continents, hills, mountain ranges,
//! river valleys, lake basins and swamp flats. It knows nothing about blocks or chunks.

use std::sync::Arc;

use super::climate::Climate;
use super::genmath::{interpolate, mix_seed, smooth_step};
use super::noise::NoiseGenerator;
use crate::core::math::clampd;
use crate::world::config::{SEA_LEVEL, WORLD_HEIGHT};

const SEA: f64 = SEA_LEVEL as f64;
const SOFT_CEILING: f64 = SEA + 135.0;
const SOFT_RANGE: f64 = 46.0;
const MASK_FREQ: f64 = 0.00026;
const RIDGE_FREQ: f64 = 0.0006;
const MOUNTAIN_UPLIFT: f64 = 24.0;
const MOUNTAIN_AMP: f64 = 245.0;
const SWAMP_MAX_BASE: f64 = 22.0;
/// Continentalness -> base elevation above sea level.
const BASE_C: [f64; 10] = [-1.0, -0.42, -0.24, -0.11, -0.02, 0.06, 0.20, 0.38, 0.62, 1.0];
const BASE_H: [f64; 10] = [-42.0, -36.0, -20.0, -8.0, 0.8, 5.0, 10.0, 16.0, 23.0, 30.0];

pub struct TerrainShape {
    warp_a: NoiseGenerator,
    warp_b: NoiseGenerator,
    continent: NoiseGenerator,
    mountain_mask: NoiseGenerator,
    ridge: NoiseGenerator,
    roughness: NoiseGenerator,
    hill: NoiseGenerator,
    detail: NoiseGenerator,
    river: NoiseGenerator,
    lake: NoiseGenerator,
    river_width: NoiseGenerator,
    pond: NoiseGenerator,
    climate: Arc<Climate>,
}

impl TerrainShape {
    pub fn new(seed: i64, climate: Arc<Climate>) -> TerrainShape {
        TerrainShape {
            warp_a: NoiseGenerator::new(mix_seed(seed, 1)),
            warp_b: NoiseGenerator::new(mix_seed(seed, 2)),
            continent: NoiseGenerator::new(mix_seed(seed, 3)),
            mountain_mask: NoiseGenerator::new(mix_seed(seed, 4)),
            ridge: NoiseGenerator::new(mix_seed(seed, 5)),
            roughness: NoiseGenerator::new(mix_seed(seed, 6)),
            hill: NoiseGenerator::new(mix_seed(seed, 7)),
            detail: NoiseGenerator::new(mix_seed(seed, 8)),
            river: NoiseGenerator::new(mix_seed(seed, 9)),
            lake: NoiseGenerator::new(mix_seed(seed, 10)),
            river_width: NoiseGenerator::new(mix_seed(seed, 15)),
            pond: NoiseGenerator::new(mix_seed(seed, 19)),
            climate,
        }
    }

    /// Ground height (blocks, continuous). `lod` drops the finest features for distant terrain.
    pub fn height(&self, wx: f64, wz: f64, lod: i32) -> f64 {
        self.height_and_coast(wx, wz, lod).0
    }

    /// The height and, from the same pass, the smooth base elevation (what `coast_elevation` returns).
    pub fn height_and_coast(&self, wx: f64, wz: f64, lod: i32) -> (f64, f64) {
        // 1. domain warp
        let wxw = wx + 90.0 * self.warp_a.fbm2d(wx * 0.0021, wz * 0.0021, 2, 0.5, 2.0);
        let wzw = wz + 90.0 * self.warp_b.fbm2d(wx * 0.0021 + 41.0, wz * 0.0021 - 23.0, 2, 0.5, 2.0);
        // 2. continents -> base elevation
        let continent_octaves = if lod >= 5 {
            2
        } else if lod >= 4 {
            3
        } else {
            4
        };
        let c = self.continent.fbm2d(wxw * 0.00042, wzw * 0.00042, continent_octaves, 0.5, 2.0) + 0.14;
        let base_elev = interpolate(c, &BASE_C, &BASE_H);
        let base = SEA + base_elev;
        let land_w = smooth_step(-0.20, 0.03, c);
        // 3. mountains
        let mountain_gate = smooth_step(0.04, 0.26, c);
        let mut m = 0.0;
        if mountain_gate > 0.0 {
            let mm = self.mountain_mask.fbm2d(wxw * MASK_FREQ + 57.0, wzw * MASK_FREQ - 13.0, 2, 0.3, 2.0);
            m = smooth_step(0.0, 0.40, mm) * mountain_gate;
        }
        let mut mountains = 0.0;
        if m > 0.0 {
            // coarse far-terrain levels sample too sparsely for the fine ridges: they would only add noise
            let ridge_octaves = (6 - (lod - 1).clamp(0, 4)).max(2);
            let r = self.ridge.ridged2d(wxw * RIDGE_FREQ, wzw * RIDGE_FREQ, ridge_octaves, 2.0, 1.8);
            mountains = m * MOUNTAIN_UPLIFT + m.powf(1.6) * clampd(r, 0.0, 1.0).powf(1.4) * MOUNTAIN_AMP;
        }
        // 4. hills
        let hills = if lod >= 4 {
            0.0 // hills are narrower than a cell of the coarsest levels
        } else {
            let rough = clampd(0.5 + 0.7 * self.roughness.fbm2d(wx * 0.0023 + 9.0, wz * 0.0023 + 4.0, 2, 0.5, 2.0), 0.0, 1.0);
            let hill_amp = 1.8 + 15.5 * rough.powf(1.6);
            let coastal = smooth_step(0.0, 14.0, base - SEA);
            let hill_octaves = if lod >= 3 { 1 } else { std::cmp::max(2, 4 - lod) };
            self.hill.fbm2d(wx * 0.0062, wz * 0.0062, hill_octaves, 0.45, 2.0) * hill_amp * 2.0 * (0.22 + 0.78 * coastal)
        };
        let fine = if lod <= 1 && land_w > 0.0 {
            self.detail.fbm2d(wx * 0.03 + 3.3, wz * 0.03 - 7.1, 2, 0.5, 2.0) * 0.5
        } else {
            0.0
        };
        let mut h = base + hills * (0.25 + 0.75 * land_w) + mountains + fine * land_w;
        // 5a. rivers (too thin to show on the coarse far-terrain levels, which skip rivers, lakes and swamps)
        let detailed = lod < 3;
        let lowland = 1.0 - smooth_step(SEA + 7.0, SEA + 20.0, h);
        let shore = smooth_step(-0.05, 0.05, c);
        if detailed && lowland > 0.0 && shore > 0.0 {
            let rv = self.river.fbm2d(wxw * 0.0011 + 222.0, wzw * 0.0011 + 11.0, 3, 0.5, 2.0).abs();
            let rwn = 0.5 + 0.5 * self.river_width.noise2d(wx * 0.004, wz * 0.004);
            let r_in = 0.012 + 0.014 * rwn;
            let r_out = r_in + 0.07;
            let rf = 1.0 - smooth_step(r_in, r_out, rv);
            let fr = rf * lowland * shore;
            let bed = SEA - 3.5 + 2.2 * (1.0 - rf);
            h = h.min(h + (bed - h) * fr);
        }
        // 5b. lakes
        let lake_low = 1.0 - smooth_step(SEA + 10.0, SEA + 22.0, h);
        if detailed && lake_low > 0.0 && shore > 0.0 {
            let lk = self.lake.fbm2d(wxw * 0.0030 + 777.0, wzw * 0.0030 - 333.0, 3, 0.5, 2.0);
            let lf = smooth_step(0.30, 0.46, lk) * lake_low * shore;
            let lake_bed = SEA - 2.0 - 6.0 * lf;
            h = h.min(h + (lake_bed - h) * lf);
        }
        // 6. swamps
        if detailed && base_elev > -2.5 && base_elev < SWAMP_MAX_BASE {
            let sw = self.climate.swamp_weight(wx, wz, base_elev);
            if sw > 0.0 {
                let p = 0.5 + 0.5 * self.pond.fbm2d(wx * 0.022 + 5.0, wz * 0.022 - 9.0, 2, 0.5, 2.0);
                let target = SEA + 1.6 - 3.4 * smooth_step(0.46, 0.66, p);
                let low = 1.0 - smooth_step(SEA + 10.0, SEA + 26.0, h);
                h += (target - h) * smooth_step(0.15, 0.7, sw) * low;
            }
        }
        // soft ceiling so peaks never flat-clip against the top of the world
        if h > SOFT_CEILING {
            h = SOFT_CEILING + SOFT_RANGE * ((h - SOFT_CEILING) / SOFT_RANGE).tanh();
        }
        (clampd(h, 3.0, WORLD_HEIGHT as f64 - 4.0), base_elev)
    }

    /// Smooth base elevation above sea level (continents only): negative out at sea, ~0..2 on a coast.
    pub fn coast_elevation(&self, wx: f64, wz: f64) -> f64 {
        let wxw = wx + 90.0 * self.warp_a.fbm2d(wx * 0.0021, wz * 0.0021, 2, 0.5, 2.0);
        let wzw = wz + 90.0 * self.warp_b.fbm2d(wx * 0.0021 + 41.0, wz * 0.0021 - 23.0, 2, 0.5, 2.0);
        let c = self.continent.fbm2d(wxw * 0.00042, wzw * 0.00042, 4, 0.5, 2.0) + 0.14;
        interpolate(c, &BASE_C, &BASE_H)
    }
}
