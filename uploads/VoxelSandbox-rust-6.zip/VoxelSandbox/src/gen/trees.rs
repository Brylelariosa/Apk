//! Tree shapes. Every shape is a pure function of its arguments, so two chunks that both draw the same
//! tree produce identical blocks on their side of the border.

use crate::world::block::Block;
use crate::world::chunk::ChunkData;
use crate::world::config::{CHUNK_SIZE, WORLD_HEIGHT};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum TreeSpecies {
    Oak,
    Birch,
    Spruce,
    /// A tall jungle tree with a lumpy crown and hanging vines.
    Jungle,
    /// A taller rainforest tree that closes the canopy.
    RainTree,
    /// A giant emergent rainforest tree: a two-block trunk with buttress roots and a wide flat crown.
    Giant,
}

/// Roughly how many blocks above the ground the top of a tree stands (the trunk plus its crown).
pub fn tree_height(species: TreeSpecies, th: i32) -> i32 {
    match species {
        TreeSpecies::Oak => 8 + (ushr(th, 4) % 4) as i32,
        TreeSpecies::Birch => 9 + (ushr(th, 4) % 4) as i32,
        TreeSpecies::Spruce => 8 + (ushr(th, 4) % 7) as i32,
        TreeSpecies::Jungle => 10 + (ushr(th, 4) % 7) as i32,
        TreeSpecies::RainTree => 16 + (ushr(th, 4) % 9) as i32,
        TreeSpecies::Giant => 28 + (ushr(th, 4) % 15) as i32,
    }
}

/// A write window onto one chunk addressed in world coordinates. Writes outside the chunk are dropped,
/// which is what lets every chunk build "its share" of a tree that straddles a border.
pub struct ChunkCanvas<'a> {
    chunk: &'a mut ChunkData,
    base_x: i32,
    base_z: i32,
}

impl<'a> ChunkCanvas<'a> {
    pub fn new(chunk: &'a mut ChunkData, base_x: i32, base_z: i32) -> ChunkCanvas<'a> {
        ChunkCanvas { chunk, base_x, base_z }
    }

    /// Writes `block` at world (wx, y, wz) if that cell lies inside this chunk and is free (air or a
    /// plant; logs may also replace another tree's leaves).
    pub fn put(&mut self, wx: i32, y: i32, wz: i32, block: Block, replace_foliage: bool) {
        if y < 0 || y >= WORLD_HEIGHT {
            return;
        }
        let lx = wx - self.base_x;
        let lz = wz - self.base_z;
        if lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE {
            return;
        }
        let existing = self.chunk.get(lx, y, lz);
        if existing == Block::Air || existing.plant() || (replace_foliage && existing.cutout()) {
            self.chunk.set(lx, y, lz, block);
        }
    }
}

const SPRUCE_RADII: [i32; 12] = [0, 1, 1, 2, 2, 3, 2, 3, 3, 3, 3, 3];

pub struct TreeBuilder {
    seed_mix: i32,
}

fn ushr(v: i32, n: u32) -> u32 {
    (v as u32) >> n
}

impl TreeBuilder {
    pub fn new(seed_mix: i32) -> TreeBuilder {
        TreeBuilder { seed_mix }
    }

    pub fn grow(&self, canvas: &mut ChunkCanvas, species: TreeSpecies, wx: i32, wz: i32, ground: i32, th: i32) {
        let wood = match species {
            TreeSpecies::Birch => Block::BirchWood,
            TreeSpecies::Spruce => Block::SpruceWood,
            TreeSpecies::Oak => Block::Wood,
            TreeSpecies::Jungle | TreeSpecies::RainTree | TreeSpecies::Giant => Block::JungleWood,
        };
        let leaf = match species {
            TreeSpecies::Birch => Block::BirchLeaves,
            TreeSpecies::Spruce => Block::SpruceLeaves,
            TreeSpecies::Oak => Block::Leaves,
            TreeSpecies::Jungle | TreeSpecies::RainTree | TreeSpecies::Giant => Block::JungleLeaves,
        };
        let bushy = species == TreeSpecies::Oak || species == TreeSpecies::Birch || species == TreeSpecies::Jungle;
        if bushy && (ushr(th, 20) & 15) == 0 {
            // a low leafy bush: one log and a small rounded cluster of leaves
            canvas.put(wx, ground + 1, wz, wood, true);
            self.blob(canvas, wx, ground + 2, wz, leaf, 1.7, 1.3);
            return;
        }
        match species {
            TreeSpecies::Spruce => self.grow_spruce(canvas, wx, wz, ground, th, wood, leaf),
            TreeSpecies::Jungle => self.grow_jungle(canvas, wx, wz, ground, th, wood, leaf),
            TreeSpecies::RainTree => self.grow_rain_tree(canvas, wx, wz, ground, th, wood, leaf),
            TreeSpecies::Giant => self.grow_giant(canvas, wx, wz, ground, th, wood, leaf),
            TreeSpecies::Birch => {
                let trunk = 6 + (ushr(th, 4) % 4) as i32; // 6..9, tall and slim
                self.trunk_and_blob(canvas, wx, wz, ground, trunk, wood, leaf, 2.0, 2.8);
            }
            TreeSpecies::Oak => {
                let big = (ushr(th, 24) & 7) == 0; // roughly one in eight is a broad old oak
                if big {
                    let trunk = 7 + (ushr(th, 4) % 3) as i32;
                    self.trunk_and_blob(canvas, wx, wz, ground, trunk, wood, leaf, 3.3, 3.0);
                } else {
                    let trunk = 5 + (ushr(th, 4) % 4) as i32;
                    self.trunk_and_blob(canvas, wx, wz, ground, trunk, wood, leaf, 2.5, 2.3);
                }
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn trunk_and_blob(
        &self,
        canvas: &mut ChunkCanvas,
        wx: i32,
        wz: i32,
        ground: i32,
        trunk: i32,
        wood: Block,
        leaf: Block,
        r_h: f64,
        r_v: f64,
    ) {
        let top_y = ground + trunk;
        for y in (ground + 1)..=top_y {
            canvas.put(wx, y, wz, wood, true);
        }
        self.blob(canvas, wx, top_y - 1, wz, leaf, r_h, r_v);
    }

    /// A rough ellipsoid of leaves; each boundary block is nudged by a position hash so canopies look organic.
    #[allow(clippy::too_many_arguments)]
    fn blob(&self, canvas: &mut ChunkCanvas, cx: i32, cy: i32, cz: i32, leaf: Block, r_h: f64, r_v: f64) {
        let ex = r_h.ceil() as i32;
        let ey = r_v.ceil() as i32;
        for dy in -ey..=ey {
            for dx in -ex..=ex {
                for dz in -ex..=ex {
                    let e = ((dx * dx + dz * dz) as f64) / (r_h * r_h) + ((dy * dy) as f64) / (r_v * r_v);
                    let jitter = ((ushr(self.hash3(cx + dx, cy + dy, cz + dz), 6) & 15) as f64) / 15.0 * 0.5 - 0.15;
                    if e <= 1.0 + jitter {
                        canvas.put(cx + dx, cy + dy, cz + dz, leaf, false);
                    }
                }
            }
        }
    }

    /// Tall tiered cone: a slender boreal conifer, 7..13 blocks of trunk.
    #[allow(clippy::too_many_arguments)]
    fn grow_spruce(&self, canvas: &mut ChunkCanvas, wx: i32, wz: i32, ground: i32, th: i32, wood: Block, leaf: Block) {
        let trunk = 7 + (ushr(th, 4) % 7) as i32;
        let top_y = ground + trunk;
        for y in (ground + 1)..=top_y {
            canvas.put(wx, y, wz, wood, true);
        }
        for y in (ground + 3)..=(top_y + 1) {
            let t = top_y + 1 - y;
            let idx = std::cmp::min(t, SPRUCE_RADII.len() as i32 - 1) as usize;
            let r = SPRUCE_RADII[idx];
            if r == 0 {
                canvas.put(wx, y, wz, leaf, false);
                continue;
            }
            let lim = r * r + r;
            for dx in -r..=r {
                for dz in -r..=r {
                    let d2 = dx * dx + dz * dz;
                    if d2 > lim {
                        continue;
                    }
                    // thin out the outer rim a little so the cone isn't machine-perfect
                    if d2 >= r * r && (self.hash3(wx + dx, y, wz + dz) & 3) == 0 {
                        continue;
                    }
                    canvas.put(wx + dx, y, wz + dz, leaf, false);
                }
            }
        }
    }

    /// `count` strands of vine hanging from height `y` below a crown of radius `radius` around (cx, cz), each
    /// `min_len ..= max_len` blocks long (a vine only grows into free air).
    #[allow(clippy::too_many_arguments)]
    fn hang_vines(&self, canvas: &mut ChunkCanvas, cx: i32, cz: i32, y: i32, radius: i32, count: i32, min_len: i32, max_len: i32) {
        let span = (2 * radius + 1) as u32;
        let lens = (max_len - min_len + 1) as u32;
        for k in 0..count {
            let h = self.hash3(cx + k * 7, y + k, cz - k * 5);
            let dx = (ushr(h, 5) % span) as i32 - radius;
            let dz = (ushr(h, 11) % span) as i32 - radius;
            let len = min_len + (ushr(h, 17) % lens) as i32;
            for d in 0..len {
                canvas.put(cx + dx, y - d, cz + dz, Block::Vine, false);
            }
        }
    }

    /// A jungle tree: a 7..13 block trunk under a lumpy crown, with vines hanging from it.
    #[allow(clippy::too_many_arguments)]
    fn grow_jungle(&self, canvas: &mut ChunkCanvas, wx: i32, wz: i32, ground: i32, th: i32, wood: Block, leaf: Block) {
        let trunk = 7 + (ushr(th, 4) % 7) as i32;
        let top_y = ground + trunk;
        for y in (ground + 1)..=top_y {
            canvas.put(wx, y, wz, wood, true);
        }
        self.blob(canvas, wx, top_y - 1, wz, leaf, 3.4, 2.4);
        for k in 0..3 {
            let h = self.hash3(wx + k, top_y, wz - k);
            let dx = (ushr(h, 4) % 5) as i32 - 2;
            let dz = (ushr(h, 9) % 5) as i32 - 2;
            let dy = (ushr(h, 14) % 3) as i32 - 2;
            self.blob(canvas, wx + dx, top_y + dy, wz + dz, leaf, 2.2, 1.7);
        }
        self.hang_vines(canvas, wx, wz, top_y - 3, 3, 3, 2, 6);
    }

    /// A rainforest tree: a 13..21 block trunk with flared roots and a wide crown that touches its neighbours.
    #[allow(clippy::too_many_arguments)]
    fn grow_rain_tree(&self, canvas: &mut ChunkCanvas, wx: i32, wz: i32, ground: i32, th: i32, wood: Block, leaf: Block) {
        let trunk = 13 + (ushr(th, 4) % 9) as i32;
        let top_y = ground + trunk;
        for y in (ground + 1)..=top_y {
            canvas.put(wx, y, wz, wood, true);
        }
        for (dx, dz) in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
            canvas.put(wx + dx, ground + 1, wz + dz, wood, true);
        }
        self.blob(canvas, wx, top_y - 1, wz, leaf, 4.6, 2.6);
        for k in 0..4 {
            let h = self.hash3(wx - k, top_y + k, wz + k);
            let dx = (ushr(h, 4) % 9) as i32 - 4;
            let dz = (ushr(h, 9) % 9) as i32 - 4;
            let dy = (ushr(h, 14) % 4) as i32 - 3;
            self.blob(canvas, wx + dx, top_y + dy, wz + dz, leaf, 2.6, 1.9);
        }
        self.hang_vines(canvas, wx, wz, top_y - 3, 4, 5, 3, 9);
    }

    /// A giant of the rainforest: a 26..40 block trunk two blocks thick, buttress roots, three side branches and a
    /// huge flat crown of stacked discs, with long vines.
    #[allow(clippy::too_many_arguments)]
    fn grow_giant(&self, canvas: &mut ChunkCanvas, wx: i32, wz: i32, ground: i32, th: i32, wood: Block, leaf: Block) {
        let trunk = 26 + (ushr(th, 4) % 15) as i32;
        let top_y = ground + trunk;
        for y in (ground + 1)..=top_y {
            for (dx, dz) in [(0, 0), (1, 0), (0, 1), (1, 1)] {
                canvas.put(wx + dx, y, wz + dz, wood, true);
            }
        }
        let roots = [(-1, 0), (-1, 1), (2, 0), (2, 1), (0, -1), (1, -1), (0, 2), (1, 2)];
        for (i, &(dx, dz)) in roots.iter().enumerate() {
            canvas.put(wx + dx, ground + 1, wz + dz, wood, true);
            if i % 2 == 0 {
                canvas.put(wx + dx, ground + 2, wz + dz, wood, true);
            }
        }
        // the crown: stacked discs around the trunk, widest in the middle, with a ragged rim
        let y0 = top_y - 2;
        let layers: [(i32, f64); 4] = [(0, 6.5), (1, 8.0), (2, 6.0), (3, 3.5)];
        for &(dy, radius) in layers.iter() {
            let ri = radius.ceil() as i32;
            for dx in -ri..=ri + 1 {
                for dz in -ri..=ri + 1 {
                    let fx = dx as f64 - 0.5;
                    let fz = dz as f64 - 0.5;
                    let d2 = fx * fx + fz * fz;
                    if d2 > radius * radius {
                        continue;
                    }
                    if d2 > (radius - 1.5) * (radius - 1.5) && (self.hash3(wx + dx, y0 + dy, wz + dz) & 3) == 0 {
                        continue;
                    }
                    canvas.put(wx + dx, y0 + dy, wz + dz, leaf, false);
                }
            }
        }
        // three side branches, each ending in a clump of leaves
        for k in 0..3 {
            let h = self.hash3(wx + k * 3, top_y - k, wz - k * 2);
            let dir = (ushr(h, 5) & 3) as i32;
            let (sx, sz) = match dir {
                0 => (1, 0),
                1 => (-1, 0),
                2 => (0, 1),
                _ => (0, -1),
            };
            let by = top_y - 8 - k * 5;
            let bx = if sx > 0 { wx + 1 } else { wx };
            let bz = if sz > 0 { wz + 1 } else { wz };
            for s in 1..=3 {
                canvas.put(bx + sx * s, by + s / 2, bz + sz * s, wood, true);
            }
            self.blob(canvas, bx + sx * 4, by + 2, bz + sz * 4, leaf, 3.0, 2.0);
        }
        self.hang_vines(canvas, wx, wz, y0 - 1, 7, 10, 4, 14);
    }

    fn hash3(&self, x: i32, y: i32, z: i32) -> i32 {
        let mut h = x
            .wrapping_mul(374761393)
            .wrapping_add(y.wrapping_mul(668265263))
            .wrapping_add(z.wrapping_mul(1274126177))
            .wrapping_add(self.seed_mix);
        h = (h ^ (ushr(h, 13) as i32)).wrapping_mul(-1028477387);
        h ^ (ushr(h, 16) as i32)
    }
}
