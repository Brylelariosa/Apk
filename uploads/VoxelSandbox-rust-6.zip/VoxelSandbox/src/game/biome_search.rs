//! Searching the world for a biome. The land form and the climate are pure functions of the seed, so the search
//! never has to generate a chunk: it looks at sample points on square rings around the player, nearest ring first,
//! and the menu gives it a small budget every frame so that the screen keeps moving while it runs.

use crate::gen::climate::Biome;
use crate::gen::terrain::TerrainGenerator;

/// Distance between two sample points, in blocks. Biomes are far wider than this, but a narrow one (a beach, a river
/// mouth) could slip between the points, so the hit is refined with the exact generator afterwards.
pub const SEARCH_STEP: i32 = 48;
/// How far the search goes, in blocks.
pub const SEARCH_RADIUS: i32 = 14_000;

pub struct BiomeSearch {
    target: Biome,
    cx: i32,
    cz: i32,
    ring: i32,
    index: i32,
    max_ring: i32,
    found: Option<(i32, i32)>,
    done: bool,
}

impl BiomeSearch {
    /// A search for `target` around the block column (`cx`, `cz`).
    pub fn new(target: Biome, cx: i32, cz: i32) -> BiomeSearch {
        BiomeSearch { target, cx, cz, ring: 0, index: 0, max_ring: SEARCH_RADIUS / SEARCH_STEP, found: None, done: false }
    }

    pub fn target(&self) -> Biome {
        self.target
    }

    /// Where the search started.
    pub fn origin(&self) -> (i32, i32) {
        (self.cx, self.cz)
    }

    pub fn is_done(&self) -> bool {
        self.done
    }

    /// The nearest block column of the biome that the search found (None while it runs, or if there is none).
    pub fn found(&self) -> Option<(i32, i32)> {
        self.found
    }

    /// How far from the start the search has got, in blocks.
    pub fn radius(&self) -> i32 {
        self.ring * SEARCH_STEP
    }

    /// How much of the area has been searched, 0 to 1.
    pub fn progress(&self) -> f32 {
        let r = self.ring as f32 / self.max_ring as f32;
        (r * r).min(1.0)
    }

    /// Looks at up to `budget` more sample points.
    pub fn advance(&mut self, generator: &TerrainGenerator, budget: u32) {
        let mut left = budget;
        while left > 0 && !self.done {
            let (dx, dz) = ring_point(self.ring, self.index);
            let x = self.cx + dx * SEARCH_STEP;
            let z = self.cz + dz * SEARCH_STEP;
            left -= 1;
            if generator.biome_guess(x, z) == self.target {
                self.found = Some(self.refine(generator, x, z));
                self.done = true;
                return;
            }
            self.index += 1;
            if self.index >= ring_len(self.ring) {
                self.ring += 1;
                self.index = 0;
                if self.ring > self.max_ring {
                    self.done = true;
                }
            }
        }
    }

    /// Moves a hit to a nearby spot that the exact generator agrees is the biome (the quick guess can be a few
    /// blocks off around coasts and cliffs). Keeps the hit itself when nothing close agrees.
    fn refine(&self, generator: &TerrainGenerator, x: i32, z: i32) -> (i32, i32) {
        if generator.biome_at(x, z) == self.target {
            return (x, z);
        }
        let mut r = 4;
        while r <= 40 {
            for k in 0..16 {
                let a = k as f64 * std::f64::consts::TAU / 16.0;
                let px = x + (a.cos() * r as f64).round() as i32;
                let pz = z + (a.sin() * r as f64).round() as i32;
                if generator.biome_at(px, pz) == self.target {
                    return (px, pz);
                }
            }
            r += 6;
        }
        (x, z)
    }
}

/// How many points ring number `ring` has (ring 0 is the centre alone).
fn ring_len(ring: i32) -> i32 {
    if ring == 0 {
        1
    } else {
        8 * ring
    }
}

/// The `index`-th point of the square ring `ring` steps from the centre, as an offset in steps.
fn ring_point(ring: i32, index: i32) -> (i32, i32) {
    if ring == 0 {
        return (0, 0);
    }
    let side = 2 * ring;
    let t = index % side;
    match index / side {
        0 => (-ring + t, -ring),
        1 => (ring, -ring + t),
        2 => (ring - t, ring),
        _ => (-ring, ring - t),
    }
}

/// The compass direction from (`from_x`, `from_z`) to (`to_x`, `to_z`): north is towards negative z, as in the game.
pub fn compass(from_x: i32, from_z: i32, to_x: i32, to_z: i32) -> &'static str {
    const NAMES: [&str; 8] = ["NORTH", "NORTH-EAST", "EAST", "SOUTH-EAST", "SOUTH", "SOUTH-WEST", "WEST", "NORTH-WEST"];
    let dx = (to_x - from_x) as f64;
    let dz = (to_z - from_z) as f64;
    let degrees = dx.atan2(-dz).to_degrees();
    let slot = ((degrees + 22.5).rem_euclid(360.0) / 45.0) as usize;
    NAMES[slot % 8]
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn rings_cover_their_perimeter_exactly_once() {
        for ring in 1..7 {
            let mut seen = HashSet::new();
            for i in 0..ring_len(ring) {
                let p = ring_point(ring, i);
                assert_eq!(p.0.abs().max(p.1.abs()), ring, "ring {} point {}", ring, i);
                assert!(seen.insert(p), "ring {} repeats {:?}", ring, p);
            }
            assert_eq!(seen.len() as i32, 8 * ring);
        }
        assert_eq!(ring_point(0, 0), (0, 0));
    }

    #[test]
    fn compass_points_the_right_way() {
        assert_eq!(compass(0, 0, 0, -100), "NORTH");
        assert_eq!(compass(0, 0, 100, 0), "EAST");
        assert_eq!(compass(0, 0, 0, 100), "SOUTH");
        assert_eq!(compass(0, 0, -100, 0), "WEST");
        assert_eq!(compass(0, 0, 100, -100), "NORTH-EAST");
        assert_eq!(compass(0, 0, -100, 100), "SOUTH-WEST");
    }

    #[test]
    fn the_search_finds_a_biome_that_is_where_it_says() {
        let generator = TerrainGenerator::new(12345);
        let mut search = BiomeSearch::new(Biome::Plains, 0, 0);
        let mut guard = 0;
        while !search.is_done() && guard < 200_000 {
            search.advance(&generator, 64);
            guard += 1;
        }
        assert!(search.is_done());
        let (x, z) = search.found().expect("plains are everywhere");
        assert!(search.radius() <= SEARCH_RADIUS);
        let guess = generator.biome_guess(x, z);
        let exact = generator.biome_at(x, z);
        assert!(guess == Biome::Plains || exact == Biome::Plains, "{:?} {:?}", guess, exact);
    }
}
