//! The creative inventory: every placeable block, sorted into tabs.

use crate::world::block::{Block, ALL_BLOCKS};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Category {
    Terrain,
    StoneAndOre,
    Trees,
    Plants,
    Liquids,
}

impl Category {
    pub const ALL: [Category; 5] =
        [Category::Terrain, Category::StoneAndOre, Category::Trees, Category::Plants, Category::Liquids];

    pub fn label(self) -> &'static str {
        match self {
            Category::Terrain => "TERRAIN",
            Category::StoneAndOre => "STONE & ORE",
            Category::Trees => "TREES",
            Category::Plants => "PLANTS",
            Category::Liquids => "LIQUIDS",
        }
    }
}

pub fn category_of(block: Block) -> Option<Category> {
    match block {
        Block::Grass | Block::DryGrass | Block::SwampGrass | Block::Dirt | Block::Sand | Block::Sandstone | Block::Gravel | Block::Snow => {
            Some(Category::Terrain)
        }
        Block::Stone | Block::DeepStone | Block::CoalOre => Some(Category::StoneAndOre),
        Block::Wood
        | Block::BirchWood
        | Block::SpruceWood
        | Block::JungleWood
        | Block::Leaves
        | Block::BirchLeaves
        | Block::SpruceLeaves
        | Block::JungleLeaves => Some(Category::Trees),
        Block::TallGrass
        | Block::Fern
        | Block::Vine
        | Block::Hibiscus
        | Block::Poppy
        | Block::Dandelion
        | Block::DeadBush
        | Block::Cactus
        | Block::LilyPad
        | Block::Seagrass => {
            Some(Category::Plants)
        }
        Block::Water => Some(Category::Liquids),
        Block::Air => None,
    }
}

/// The blocks of one tab, in id order.
pub fn blocks_in(category: Category) -> Vec<Block> {
    ALL_BLOCKS.iter().copied().filter(|b| category_of(*b) == Some(category)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_block_but_air_is_in_exactly_one_tab() {
        let mut total = 0;
        for c in Category::ALL.iter() {
            total += blocks_in(*c).len();
        }
        assert_eq!(total, ALL_BLOCKS.len() - 1);
    }
}
