//! The running game: owns the world, the player and the rules. Called once per frame with the elapsed time.

use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use super::flight;
use super::hotbar::Hotbar;
use super::input::InputState;
use super::physics;
use super::placement;
use super::player::Player;
use super::raycast::{self, RaycastHit};
use super::save::{self, LoadedSave, SaveData};
use super::settings::Settings;
use crate::core::rng::SplitMix64;
use crate::diag::probe::{self, Stage};
use crate::lod::FarManager;
use crate::world::block::Block;
use crate::world::config::{MAX_INTERACT_REACH, WORLD_HEIGHT};
use crate::world::fluid;
use crate::world::fluid_sim::FluidSim;
use crate::world::pos::ChunkPos;
use crate::world::streaming::WorldManager;

const SPAWN_SEARCH_RADIUS: i32 = 7;
const DOUBLE_TAP_SECONDS: f32 = 0.3;
const LANDING_SECONDS: f32 = 0.12;
const BREAK_INTERVAL: f32 = 0.12;
const PLACE_INTERVAL: f32 = 0.22;
const LASER_RADIUS: i32 = 2;
const LASER_RANGE: i32 = 96;
const LASER_INTERVAL: f32 = 0.1;

pub struct GameEngine {
    pub seed: i64,
    pub manager: WorldManager,
    /// The simplified terrain drawn beyond the block world (see `lod`).
    pub far: FarManager,
    /// False when the renderer cannot draw far terrain (then it is not worth building).
    pub far_available: bool,
    pub player: Player,
    pub hotbar: Hotbar,
    pub input: InputState,
    fluid: FluidSim,
    spawn_chunk: ChunkPos,
    break_cd: f32,
    place_cd: f32,
    bob_phase: f32,
    time_sec: f32,
    last_jump_press: f32,
    last_jump_held: bool,
    landed_for: f32,
    laser_timer: f32,
    flight_vel: [f32; 3],
    pub laser_active: bool,
    pub bob_offset: f32,
    pub last_hit: Option<RaycastHit>,
    /// The camera is inside water.
    pub underwater: bool,
}

fn random_seed() -> i64 {
    let nanos = match SystemTime::now().duration_since(UNIX_EPOCH) {
        Ok(d) => d.as_nanos() as u64,
        Err(_) => 12345,
    };
    SplitMix64::new(nanos).next_u64() as i64
}

fn left_behind(block: Block) -> u8 {
    if block == Block::Seagrass {
        Block::Water as u8
    } else {
        0
    }
}

impl GameEngine {
    /// A saved world, or (with `None`) a new one with a random seed.
    pub fn new(settings: &Settings, saved: Option<LoadedSave>) -> GameEngine {
        let seed = match &saved {
            Some(s) => s.seed,
            None => random_seed(),
        };
        GameEngine::with_seed(settings, saved, seed)
    }

    /// Like `new`, but a new world gets `seed` (tests and benchmarks use this to get the same world every time).
    /// A saved world keeps its own seed.
    pub fn with_seed(settings: &Settings, saved: Option<LoadedSave>, seed: i64) -> GameEngine {
        let seed = match &saved {
            Some(s) => s.seed,
            None => seed,
        };
        let mut manager = WorldManager::new(seed, settings.detail_radius());
        let mut player = Player::new();
        let mut hotbar = Hotbar::new();
        match saved {
            Some(s) => {
                player.position.set(s.x, s.y, s.z);
                player.yaw = s.yaw;
                player.pitch = s.pitch;
                player.flying = s.flying;
                player.waiting_for_spawn = false; // the saved position is known-good ground
                hotbar.restore(&s.hotbar, s.hotbar_selected as usize);
                manager.import_edited(s.chunks);
            }
            None => {
                let spawn = manager.gen.find_spawn();
                player.position.set(spawn.x as f32 + 0.5, 48.0, spawn.z as f32 + 0.5);
            }
        }
        let spawn_chunk = ChunkPos::from_world(player.position.x, player.position.z);
        let far = FarManager::new(manager.gen.clone());
        GameEngine {
            seed,
            manager,
            far,
            far_available: true,
            player,
            hotbar,
            input: InputState::new(),
            fluid: FluidSim::new(),
            spawn_chunk,
            break_cd: 0.0,
            place_cd: 0.0,
            bob_phase: 0.0,
            time_sec: 0.0,
            last_jump_press: -10.0,
            last_jump_held: false,
            landed_for: 0.0,
            laser_timer: 0.0,
            flight_vel: [0.0; 3],
            laser_active: false,
            bob_offset: 0.0,
            last_hit: None,
            underwater: false,
        }
    }

    /// Writes the world to `dir`.
    pub fn save(&self, dir: &Path) -> Result<(), String> {
        let chunks = self.manager.collect_edited();
        let data = SaveData {
            seed: self.seed,
            x: self.player.position.x,
            y: self.player.position.y,
            z: self.player.position.z,
            yaw: self.player.yaw,
            pitch: self.player.pitch,
            flying: self.player.flying,
            hotbar: self.hotbar.export_ids(),
            hotbar_selected: self.hotbar.selected_index() as u8,
            chunks: &chunks,
        };
        save::write(dir, &data)
    }

    pub fn update(&mut self, settings: &Settings, dt: f32) {
        let _engine_time = probe::scope(Stage::Engine);
        let dt = dt.min(0.05); // guards against a huge step after resuming from the background
        {
            // only the nearby chunks are real blocks; everything further out is far terrain (see `lod`)
            let _streaming_time = probe::scope(Stage::Streaming);
            self.manager.set_view_radius(settings.detail_radius());
            self.manager.set_merge_from(settings.merge_from_chunks());
            self.manager.update(self.player.position.x, self.player.position.z);
            self.far.update(
                self.player.position.x as f64,
                self.player.position.z as f64,
                settings.render_distance as f32 * 16.0,
                settings.far_terrain_wanted() && self.far_available,
            );
        }

        if self.player.waiting_for_spawn {
            if self.manager.world.contains(self.spawn_chunk) {
                self.drop_player_to_surface();
                self.player.waiting_for_spawn = false;
            } else {
                return; // hold everything until the spawn column exists
            }
        }

        let (look_dx, look_dy) = self.input.consume_look_delta();
        let blocked = self.input.ui_blocked;
        if !blocked {
            let look_sens = 0.0022 + settings.look_sensitivity * 0.0035;
            self.player.add_look(look_dx * look_sens, -look_dy * look_sens);
        }
        let move_forward = if blocked { 0.0 } else { self.input.move_forward };
        let move_strafe = if blocked { 0.0 } else { self.input.move_strafe };
        let jump_held = !blocked && self.input.jump_held;
        let descend_held = !blocked && self.input.descend_held;

        self.time_sec += dt;
        let mut toggle_flight = self.input.consume_flight_toggle() && !blocked;
        if jump_held && !self.last_jump_held {
            if self.time_sec - self.last_jump_press < DOUBLE_TAP_SECONDS {
                toggle_flight = true;
                self.last_jump_press = -10.0;
            } else {
                self.last_jump_press = self.time_sec;
            }
        }
        self.last_jump_held = jump_held;
        if toggle_flight {
            let f = !self.player.flying;
            self.set_flying(f);
        }

        if self.player.flying {
            self.fly(settings, dt, move_forward, move_strafe, jump_held, descend_held);
            self.update_view_bob(settings, 0.0, 0.0, dt);
        } else {
            let move_sens = 0.6 + settings.touch_sensitivity.max(0.0).min(1.0) * 0.8;
            let forward = move_forward * move_sens;
            let strafe = move_strafe * move_sens;
            let yaw = self.player.yaw;
            let world_move_x = forward * yaw.sin() + strafe * yaw.cos();
            let world_move_z = -forward * yaw.cos() + strafe * yaw.sin();
            physics::step(&self.manager.world, &mut self.player, world_move_x, world_move_z, jump_held, settings.auto_jump, dt);
            self.update_view_bob(settings, world_move_x, world_move_z, dt);
        }

        let ex = self.player.eye_x().floor() as i32;
        let ey = self.player.eye_y().floor() as i32;
        let ez = self.player.eye_z().floor() as i32;
        self.underwater = fluid::amount_of(self.manager.world.get_raw(ex, ey, ez)) > 0;

        self.handle_break_place(dt, blocked);
        self.handle_laser(dt, blocked);
        self.fluid.update(&mut self.manager.world, dt);
    }

    fn set_flying(&mut self, flying: bool) {
        self.player.flying = flying;
        self.player.velocity.set(0.0, 0.0, 0.0);
        self.flight_vel = [0.0; 3];
        self.landed_for = 0.0;
    }

    fn fly(&mut self, settings: &Settings, dt: f32, forward: f32, strafe: f32, ascend: bool, descend: bool) {
        let target = flight::target_velocity(forward, strafe, ascend, descend, self.player.yaw, settings.fly_speed);
        let dx = flight::advance(&mut self.flight_vel, 0, target[0], dt);
        let dy = flight::advance(&mut self.flight_vel, 1, target[1], dt);
        let dz = flight::advance(&mut self.flight_vel, 2, target[2], dt);
        let hit = physics::fly_move(&self.manager.world, &mut self.player, dx, dy, dz);
        if hit & physics::BLOCKED_X != 0 {
            self.flight_vel[0] = 0.0;
        }
        if hit & physics::BLOCKED_Z != 0 {
            self.flight_vel[2] = 0.0;
        }
        if hit & (physics::BLOCKED_UP | physics::BLOCKED_DOWN) != 0 {
            self.flight_vel[1] = 0.0;
        }
        let ceiling = WORLD_HEIGHT as f32 + 200.0;
        if self.player.position.y > ceiling {
            self.player.position.y = ceiling;
        }
        // holding "descend" on the ground for a moment lands the player
        if descend && (hit & physics::BLOCKED_DOWN) != 0 {
            self.landed_for += dt;
            if self.landed_for >= LANDING_SECONDS {
                self.set_flying(false);
            }
        } else {
            self.landed_for = 0.0;
        }
    }

    fn update_view_bob(&mut self, settings: &Settings, world_move_x: f32, world_move_z: f32, dt: f32) {
        if !settings.view_bobbing {
            self.bob_offset = 0.0;
            return;
        }
        let speed = (world_move_x * world_move_x + world_move_z * world_move_z).sqrt();
        if self.player.on_ground && speed > 0.05 {
            self.bob_phase += dt * 9.0;
            self.bob_offset = self.bob_phase.sin() * 0.045;
        } else {
            self.bob_offset *= 0.85;
        }
    }

    fn handle_break_place(&mut self, dt: f32, blocked: bool) {
        self.break_cd -= dt;
        self.place_cd -= dt;
        if blocked {
            self.last_hit = None;
            return;
        }
        let dir = self.player.look_dir();
        let hit = raycast::cast(
            &self.manager.world,
            self.player.eye_x(),
            self.player.eye_y(),
            self.player.eye_z(),
            dir.x,
            dir.y,
            dir.z,
            MAX_INTERACT_REACH,
        );
        self.last_hit = hit;
        let hit = match hit {
            Some(h) => h,
            None => return,
        };
        let target = self.manager.world.get_block(hit.bx, hit.by, hit.bz);

        if self.input.break_held && self.break_cd <= 0.0 {
            if target.breakable() && self.manager.world.set_raw(hit.bx, hit.by, hit.bz, left_behind(target), true) {
                self.fluid.on_block_changed(&self.manager.world, hit.bx, hit.by, hit.bz);
            }
            self.break_cd = BREAK_INTERVAL;
        }

        if self.input.place_held && self.place_cd <= 0.0 {
            let mut px = hit.bx;
            let mut py = hit.by;
            let mut pz = hit.bz;
            let mut can_try = target.plant();
            if !target.plant() && (hit.fx != 0 || hit.fy != 0 || hit.fz != 0) {
                px += hit.fx;
                py += hit.fy;
                pz += hit.fz;
                can_try = true;
            }
            if can_try {
                let selected = self.hotbar.selected_block();
                py = placement::target_y(&self.manager.world, selected, px, py, pz);
                if placement::can_place(&self.manager.world, selected, px, py, pz)
                    && !placement::traps_player(&self.player, selected, px, py, pz)
                    && self.manager.world.set_raw(px, py, pz, selected as u8, true)
                {
                    self.fluid.on_block_changed(&self.manager.world, px, py, pz);
                }
            }
            self.place_cd = PLACE_INTERVAL;
        }
    }

    /// The "laser": clears a 5-block-wide tunnel straight ahead.
    fn handle_laser(&mut self, dt: f32, blocked: bool) {
        self.laser_active = !blocked && self.input.laser_held;
        if !self.laser_active {
            self.laser_timer = 0.0;
            return;
        }
        self.laser_timer -= dt;
        if self.laser_timer > 0.0 {
            return;
        }
        self.laser_timer = LASER_INTERVAL;
        let dir = self.player.look_dir();
        let ex = self.player.eye_x();
        let ey = self.player.eye_y();
        let ez = self.player.eye_z();
        let r = LASER_RADIUS;
        let reach2 = r * r + 1;
        let mut step = 2;
        while step <= LASER_RANGE {
            let s = step as f32;
            let cx = (ex + dir.x * s).floor() as i32;
            let cy = (ey + dir.y * s).floor() as i32;
            let cz = (ez + dir.z * s).floor() as i32;
            for ox in -r..=r {
                for oy in -r..=r {
                    for oz in -r..=r {
                        if ox * ox + oy * oy + oz * oz > reach2 {
                            continue;
                        }
                        let by = cy + oy;
                        if by < 1 || by >= WORLD_HEIGHT {
                            continue;
                        }
                        let bx = cx + ox;
                        let bz = cz + oz;
                        let block = self.manager.world.get_block(bx, by, bz);
                        if block != Block::Air && block.breakable() && self.manager.world.set_raw(bx, by, bz, left_behind(block), true) {
                            self.fluid.on_block_changed(&self.manager.world, bx, by, bz);
                        }
                    }
                }
            }
            step += 1;
        }
    }

    /// Moves the player to the block column (`x`, `z`) wherever it is. The world around the new place is not
    /// loaded yet, so this does what a new game does: the player waits until the column exists and is then put on
    /// the ground there.
    pub fn teleport(&mut self, x: i32, z: i32) {
        self.player.position.set(x as f32 + 0.5, 150.0, z as f32 + 0.5);
        self.player.velocity.set(0.0, 0.0, 0.0);
        self.flight_vel = [0.0; 3];
        self.spawn_chunk = ChunkPos::from_world(self.player.position.x, self.player.position.z);
        self.player.waiting_for_spawn = true;
    }

    fn drop_player_to_surface(&mut self) {
        let bx = self.player.position.x.floor() as i32;
        let bz = self.player.position.z.floor() as i32;
        for ring in 0..=SPAWN_SEARCH_RADIUS {
            for dz in -ring..=ring {
                for dx in -ring..=ring {
                    if dx.abs().max(dz.abs()) != ring {
                        continue;
                    }
                    let feet_y = self.standing_height(bx + dx, bz + dz);
                    if feet_y >= 0 {
                        self.player.position.set((bx + dx) as f32 + 0.5, feet_y as f32, (bz + dz) as f32 + 0.5);
                        return;
                    }
                }
            }
        }
        let mut y = WORLD_HEIGHT - 1;
        while y > 0 && self.manager.world.get_block(bx, y, bz) == Block::Air {
            y -= 1;
        }
        let x = self.player.position.x;
        let z = self.player.position.z;
        self.player.position.set(x, (y + 1) as f32, z);
    }

    /// Feet Y of the first ground you can stand on in a column (solid, not foliage, two free cells above), or -1.
    fn standing_height(&self, x: i32, z: i32) -> i32 {
        let mut y = WORLD_HEIGHT - 3;
        while y > 0 {
            let block = self.manager.world.get_block(x, y, z);
            if block.solid() && !block.cutout() && block != Block::Cactus && self.is_clear(x, y + 1, z) && self.is_clear(x, y + 2, z) {
                return y + 1;
            }
            y -= 1;
        }
        -1
    }

    fn is_clear(&self, x: i32, y: i32, z: i32) -> bool {
        let block = self.manager.world.get_block(x, y, z);
        block == Block::Air || block.plant()
    }

    /// Biome name (and flight state) for the on-screen status line.
    pub fn status_line(&self) -> String {
        let biome = self
            .manager
            .gen
            .biome_at(self.player.position.x.floor() as i32, self.player.position.z.floor() as i32)
            .display_name();
        if self.player.flying {
            format!("{}   |   FLYING", biome)
        } else {
            biome.to_string()
        }
    }

    pub fn debug_stats(&self) -> String {
        format!(
            "chunks {} meshed {} pending {}\npos {:.1} {:.1} {:.1}",
            self.manager.chunk_count(),
            self.manager.meshed_count(),
            self.manager.pending_count(),
            self.player.position.x,
            self.player.position.y,
            self.player.position.z
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    fn small_settings() -> Settings {
        let mut s = Settings::defaults();
        s.render_distance = 4;
        s
    }

    #[test]
    fn a_new_world_puts_the_player_on_the_ground() {
        let settings = small_settings();
        let mut e = GameEngine::new(&settings, None);
        let start = Instant::now();
        while e.player.waiting_for_spawn {
            e.update(&settings, 0.016);
            assert!(start.elapsed().as_secs() < 90, "spawn column never loaded");
            std::thread::sleep(Duration::from_millis(5));
        }
        for _ in 0..180 {
            e.update(&settings, 0.016);
            std::thread::sleep(Duration::from_millis(2));
        }
        assert!(e.player.position.y > 3.0 && e.player.position.y < 250.0, "y = {}", e.player.position.y);
        assert!(e.player.on_ground, "the player should have landed");
    }

    #[test]
    fn breaking_and_placing_edit_the_world() {
        let settings = small_settings();
        let mut e = GameEngine::new(&settings, None);
        let start = Instant::now();
        while e.player.waiting_for_spawn {
            e.update(&settings, 0.016);
            assert!(start.elapsed().as_secs() < 90);
            std::thread::sleep(Duration::from_millis(5));
        }
        // dig straight down under the player's feet, then check the block is gone
        let bx = e.player.position.x.floor() as i32;
        let bz = e.player.position.z.floor() as i32;
        let by = e.player.position.y.floor() as i32 - 1;
        let before = e.manager.world.get_block(bx, by, bz);
        assert!(before != Block::Air);
        assert!(e.manager.world.set_raw(bx, by, bz, 0, true));
        assert_eq!(e.manager.world.get_block(bx, by, bz), Block::Air);
        assert!(e.manager.has_edits());
    }
}
