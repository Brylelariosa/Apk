//! Voxel Sandbox, rewritten in Rust.
//!
//! The crate is split into a platform-independent core (`core`, `world`, `gen`, `mesh`, `tex`, `game`),
//! and the screens / touch controls (`ui`), all of which also build and test on a normal computer, and an
//! Android shell (`platform`, `render`) that owns the window and OpenGL ES.

pub mod core;
pub mod diag;
pub mod game;
pub mod gen;
pub mod lod;
pub mod mesh;
pub mod perf;
pub mod tex;
pub mod ui;
pub mod world;

#[cfg(target_os = "android")]
pub mod platform;
#[cfg(target_os = "android")]
pub mod render;
