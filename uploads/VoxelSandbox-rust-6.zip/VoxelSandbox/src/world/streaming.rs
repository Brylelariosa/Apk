//! Keeps the world around the player alive: generates and meshes chunks on worker threads, unloads far
//! ones (keeping edited chunks), and hands finished meshes to the renderer.
//!
//! The scheduling is written so that a quiet frame costs almost nothing: the nearest-first order of chunks is
//! precomputed (`Spiral`), the scan for missing chunks resumes where it stopped and only restarts when the
//! player crosses into another chunk, and meshing candidates are only searched for when something changed.

use crate::core::fasthash::{FastMap, FastSet};
use std::sync::Arc;

use super::chunk::ChunkData;
use super::jobs::{new_chunk_pool, ChunkPool, Job, JobResult};
use super::pos::ChunkPos;
use super::spiral::Spiral;
use super::world::World;
use crate::core::pool::default_workers;
use crate::gen::terrain::TerrainGenerator;
use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
use crate::mesh::mesher::{MeshContext, MeshInput};
use crate::mesh::ChunkMeshData;

/// Chunks beyond the loaded ring are kept this much longer before they are unloaded (avoids flicker at the edge).
const UNLOAD_MARGIN: i32 = 3;
/// Rings of chunks loaded beyond the meshed area: every chunk that gets meshed has all eight neighbours loaded.
const LOAD_MARGIN: i32 = 2;

/// What the manager is holding and doing, for the debug log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct WorldStats {
    pub loaded: u32,
    pub meshed: u32,
    /// Chunks whose terrain is being generated.
    pub gen_pending: u32,
    /// Chunks whose mesh is being built.
    pub mesh_in_flight: u32,
    /// Jobs waiting for a worker thread.
    pub queued: u32,
    pub workers: u32,
}

/// Where the resumable scan for missing chunks is.
struct LoadScan {
    center: Option<ChunkPos>,
    radius: i32,
    cursor: usize,
    done: bool,
}

pub struct WorldManager {
    pub world: World,
    pub gen: Arc<TerrainGenerator>,
    pool: ChunkPool,
    spiral: Spiral,
    /// Edited chunks that are currently out of range (kept so edits survive walking away).
    edited_store: FastMap<ChunkPos, ChunkData>,
    gen_pending: FastSet<ChunkPos>,
    meshed: FastSet<ChunkPos>,
    view_radius: i32,
    max_gen_pending: usize,
    max_mesh_in_flight: usize,
    mesh_in_flight: usize,
    uploads: Vec<(ChunkPos, ChunkMeshData)>,
    removed: Vec<ChunkPos>,

    last_center: ChunkPos,
    load_scan: LoadScan,
    /// The (centre, radius) the last unload pass was made for.
    unload_key: Option<(ChunkPos, i32)>,
    /// The (centre, radius, merge distance) and world change count the last mesh scan was made for.
    mesh_key: Option<(ChunkPos, i32, i32)>,
    mesh_seen_changes: u64,
    /// The last mesh scan stopped early (all workers busy): look again next frame.
    mesh_scan_pending: bool,
    /// Chunks farther than this get the cheap merged mesh (0 = never merge).
    merge_from: i32,
    // scratch buffers, reused every frame
    candidates: Vec<(i64, ChunkPos, bool, bool)>,
    far: Vec<ChunkPos>,
}

impl WorldManager {
    pub fn new(seed: i64, view_radius: i32) -> WorldManager {
        let gen = Arc::new(TerrainGenerator::new(seed));
        let ctx = Arc::new(MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        });
        let threads = default_workers();
        let pool = new_chunk_pool(threads, gen.clone(), ctx);
        let view_radius = view_radius.max(2);
        WorldManager {
            world: World::new(),
            gen,
            pool,
            spiral: Spiral::new(view_radius + LOAD_MARGIN),
            edited_store: FastMap::default(),
            gen_pending: FastSet::default(),
            meshed: FastSet::default(),
            view_radius,
            max_gen_pending: threads * 4 + 8,
            max_mesh_in_flight: threads * 2 + 4,
            mesh_in_flight: 0,
            uploads: Vec::new(),
            removed: Vec::new(),
            last_center: ChunkPos::new(0, 0),
            load_scan: LoadScan { center: None, radius: 0, cursor: 0, done: false },
            unload_key: None,
            mesh_key: None,
            mesh_seen_changes: 0,
            mesh_scan_pending: true,
            merge_from: 0,
            candidates: Vec::new(),
            far: Vec::new(),
        }
    }

    pub fn view_radius(&self) -> i32 {
        self.view_radius
    }

    pub fn set_view_radius(&mut self, r: i32) {
        self.view_radius = r.max(2);
        if self.view_radius + LOAD_MARGIN > self.spiral.max_radius() {
            self.spiral = Spiral::new(self.view_radius + LOAD_MARGIN);
        }
    }

    /// Chunks farther than `chunks` from the player are built as cheap merged meshes; 0 turns that off.
    pub fn set_merge_from(&mut self, chunks: i32) {
        self.merge_from = chunks.max(0);
    }

    pub fn chunk_count(&self) -> usize {
        self.world.len()
    }

    pub fn meshed_count(&self) -> usize {
        self.meshed.len()
    }

    pub fn pending_count(&self) -> usize {
        self.gen_pending.len() + self.mesh_in_flight
    }

    pub fn stats(&self) -> WorldStats {
        WorldStats {
            loaded: self.world.len() as u32,
            meshed: self.meshed.len() as u32,
            gen_pending: self.gen_pending.len() as u32,
            mesh_in_flight: self.mesh_in_flight as u32,
            queued: self.pool.queued() as u32,
            workers: self.pool.threads() as u32,
        }
    }

    /// Hands over meshes that finished since the last call (the renderer uploads them).
    pub fn take_uploads(&mut self) -> Vec<(ChunkPos, ChunkMeshData)> {
        std::mem::take(&mut self.uploads)
    }

    /// Chunks that were unloaded since the last call (the renderer frees their GPU meshes).
    pub fn take_removed(&mut self) -> Vec<ChunkPos> {
        std::mem::take(&mut self.removed)
    }

    /// Forgets every GPU mesh (after the GL context was lost): all chunks are re-meshed.
    pub fn invalidate_all_meshes(&mut self) {
        self.meshed.clear();
        let positions = self.world.positions();
        for p in positions {
            if let Some(e) = self.world.entry_mut(p) {
                e.dirty = true;
                e.version += 1;
            }
        }
        self.mesh_scan_pending = true;
    }

    /// True once every chunk within `radius` of `center` is loaded and has a mesh.
    pub fn area_ready(&self, center: ChunkPos, radius: i32) -> bool {
        for dz in -radius..=radius {
            for dx in -radius..=radius {
                if dx * dx + dz * dz > radius * radius {
                    continue;
                }
                let p = ChunkPos::new(center.x + dx, center.z + dz);
                if !self.world.contains(p) || !self.meshed.contains(&p) {
                    return false;
                }
            }
        }
        true
    }

    /// Edited chunks (loaded and stored) as `(position, serialized blocks)`, for saving.
    pub fn collect_edited(&self) -> Vec<(ChunkPos, Vec<u8>)> {
        let mut out = Vec::new();
        for (pos, e) in self.world.iter() {
            if e.edited {
                out.push((*pos, e.data.serialize()));
            }
        }
        for (pos, data) in self.edited_store.iter() {
            out.push((*pos, data.serialize()));
        }
        out
    }

    /// Chunks restored from a save; they replace generation when their area loads.
    pub fn import_edited(&mut self, chunks: Vec<(ChunkPos, ChunkData)>) {
        for (pos, data) in chunks {
            self.edited_store.insert(pos, data);
        }
        // positions that were already scanned may now have saved data waiting for them
        self.load_scan.done = false;
        self.load_scan.cursor = 0;
    }

    pub fn has_edits(&self) -> bool {
        !self.edited_store.is_empty() || self.world.iter().any(|(_, e)| e.edited)
    }

    pub fn update(&mut self, center_x: f32, center_z: f32) {
        let center = ChunkPos::from_world(center_x, center_z);
        self.last_center = center;
        self.drain_results();
        self.unload_far(center);
        self.request_loads(center);
        self.request_meshes(center);
    }

    fn drain_results(&mut self) {
        let keep = self.view_radius + UNLOAD_MARGIN;
        let keep_sq = (keep * keep) as i64;
        while let Some(r) = self.pool.try_recv() {
            match r {
                JobResult::Generated(pos, data) => {
                    self.gen_pending.remove(&pos);
                    if !self.world.contains(pos) {
                        self.world.insert(pos, data, false);
                        if pos.dist_sq(self.last_center) > keep_sq {
                            // a late result for an area the player has left: the next unload pass must drop it
                            self.unload_key = None;
                        }
                    }
                }
                JobResult::Meshed { pos, version: _, mesh } => {
                    // the job is finished whether or not its chunk is still around
                    if self.mesh_in_flight > 0 {
                        self.mesh_in_flight -= 1;
                    }
                    if let Some(e) = self.world.entry_mut(pos) {
                        e.in_flight = false;
                        if e.dirty {
                            // edited while it was being meshed: it needs another pass
                            self.mesh_scan_pending = true;
                        }
                        self.meshed.insert(pos);
                        self.uploads.push((pos, mesh));
                    }
                }
            }
        }
    }

    fn unload_far(&mut self, center: ChunkPos) {
        let key = (center, self.view_radius);
        if self.unload_key == Some(key) {
            return;
        }
        self.unload_key = Some(key);
        let keep = self.view_radius + UNLOAD_MARGIN;
        let keep_sq = (keep * keep) as i64;
        self.far.clear();
        for (p, _) in self.world.iter() {
            if p.dist_sq(center) > keep_sq {
                self.far.push(*p);
            }
        }
        for i in 0..self.far.len() {
            let pos = self.far[i];
            if let Some(entry) = self.world.remove(pos) {
                if entry.edited {
                    self.edited_store.insert(pos, entry.data);
                }
            }
            self.meshed.remove(&pos);
            self.removed.push(pos);
        }
    }

    fn request_loads(&mut self, center: ChunkPos) {
        let radius = self.view_radius + LOAD_MARGIN;
        if self.load_scan.center != Some(center) || self.load_scan.radius != radius {
            self.load_scan = LoadScan { center: Some(center), radius, cursor: 0, done: false };
        }
        if self.load_scan.done {
            return;
        }
        let end = self.spiral.count_within(radius);
        let mut i = self.load_scan.cursor;
        while i < end {
            let o = self.spiral.get(i);
            let p = ChunkPos::new(center.x + o.dx, center.z + o.dz);
            if self.world.contains(p) || self.gen_pending.contains(&p) {
                i += 1;
                continue;
            }
            if let Some(data) = self.edited_store.remove(&p) {
                self.world.insert(p, data, true);
                i += 1;
                continue;
            }
            if self.gen_pending.len() >= self.max_gen_pending {
                break;
            }
            self.gen_pending.insert(p);
            self.pool.submit(o.dist_sq as i64, Job::Generate(p));
            i += 1;
        }
        self.load_scan.cursor = i;
        self.load_scan.done = i >= end;
    }

    fn neighbours_loaded(&self, pos: ChunkPos) -> bool {
        for dz in -1..=1 {
            for dx in -1..=1 {
                if !self.world.contains(ChunkPos::new(pos.x + dx, pos.z + dz)) {
                    return false;
                }
            }
        }
        true
    }

    /// Should a chunk `dist_sq` (squared chunks) from the player be built as a merged mesh? A chunk that is already
    /// merged stays merged until it is clearly closer, so walking back and forth over the border does not rebuild
    /// it over and over.
    fn wants_merged(&self, dist_sq: i64, merged_now: bool) -> bool {
        let m = self.merge_from as i64;
        if m <= 0 {
            return false;
        }
        if merged_now {
            dist_sq >= m * m - m
        } else {
            dist_sq > m * m + m
        }
    }

    fn request_meshes(&mut self, center: ChunkPos) {
        let key = (center, self.view_radius, self.merge_from);
        let changes = self.world.changes();
        if !self.mesh_scan_pending && self.mesh_key == Some(key) && self.mesh_seen_changes == changes {
            return;
        }
        self.mesh_key = Some(key);
        self.mesh_seen_changes = changes;
        self.mesh_scan_pending = false;

        let r = self.view_radius;
        let r_sq = (r * r) as i64;
        self.candidates.clear();
        for (pos, e) in self.world.iter() {
            let d = pos.dist_sq(center);
            if d > r_sq {
                continue;
            }
            let merged = self.wants_merged(d, e.merged);
            // a chunk that was meshed in the other mode needs another pass
            let wrong_mode = merged != e.merged && self.meshed.contains(pos);
            if !(e.dirty || wrong_mode) {
                continue;
            }
            if e.in_flight {
                if wrong_mode {
                    self.mesh_scan_pending = true; // look again once the running job is done
                }
                continue;
            }
            self.candidates.push((if e.urgent { -1 } else { d }, *pos, e.urgent, merged));
        }
        self.candidates.sort_unstable_by_key(|c| c.0);
        for i in 0..self.candidates.len() {
            let (prio, pos, urgent, merge) = self.candidates[i];
            if !urgent && self.mesh_in_flight >= self.max_mesh_in_flight {
                self.mesh_scan_pending = true;
                break;
            }
            if !self.neighbours_loaded(pos) {
                continue;
            }
            let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
            for dz in -1..=1 {
                for dx in -1..=1 {
                    let p = ChunkPos::new(pos.x + dx, pos.z + dz);
                    chunks[((dz + 1) * 3 + (dx + 1)) as usize] = self.world.entry(p).map(|e| e.data.clone());
                }
            }
            let version = match self.world.entry_mut(pos) {
                Some(e) => {
                    e.dirty = false;
                    e.urgent = false;
                    e.in_flight = true;
                    e.merged = merge;
                    e.version
                }
                None => continue,
            };
            self.mesh_in_flight += 1;
            self.pool.submit(prio, Job::Mesh { pos, version, input: MeshInput { pos, chunks, merge } });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::block::Block;
    use std::time::{Duration, Instant};

    fn settle(m: &mut WorldManager, x: f32, z: f32, radius: i32) {
        let center = ChunkPos::from_world(x, z);
        let start = Instant::now();
        loop {
            m.update(x, z);
            if m.area_ready(center, radius) {
                break;
            }
            assert!(start.elapsed().as_secs() < 90, "the area around ({}, {}) never became ready", x, z);
            std::thread::sleep(Duration::from_millis(5));
        }
    }

    #[test]
    fn streaming_generates_and_meshes_the_area_around_the_player() {
        let mut m = WorldManager::new(4242, 3);
        let spawn = m.gen.find_spawn();
        let x = spawn.x as f32;
        let z = spawn.z as f32;
        settle(&mut m, x, z, 1);
        assert!(!m.take_uploads().is_empty());
        assert!(m.chunk_count() > 9);
    }

    #[test]
    fn far_chunks_are_unloaded_and_reported() {
        let mut m = WorldManager::new(99, 2);
        settle(&mut m, 8.0, 8.0, 1);
        // walk far away: the old area must be dropped
        for _ in 0..200 {
            m.update(8000.0, 8000.0);
            std::thread::sleep(Duration::from_millis(2));
        }
        assert!(!m.world.contains(ChunkPos::new(0, 0)));
        assert!(!m.take_removed().is_empty());
    }

    #[test]
    fn the_nearest_chunks_are_requested_first() {
        let mut m = WorldManager::new(5, 10);
        m.update(8.0, 8.0);
        assert!(!m.gen_pending.is_empty());
        let farthest_requested = m.gen_pending.iter().map(|p| p.dist_sq(ChunkPos::new(0, 0))).max().unwrap_or(0);
        // everything closer than the farthest requested chunk must have been requested too
        let requested = m.gen_pending.len() as i64;
        let closer = (-12..=12)
            .flat_map(|z| (-12..=12).map(move |x| (x, z)))
            .filter(|(x, z)| (x * x + z * z) as i64 <= farthest_requested)
            .count() as i64;
        assert!(requested >= closer - 8, "requested {} but {} chunks are as near", requested, closer);
        assert!(m.gen_pending.contains(&ChunkPos::new(0, 0)));
    }

    #[test]
    fn a_settled_world_does_no_scanning_and_no_work() {
        let mut m = WorldManager::new(7, 3);
        settle(&mut m, 8.0, 8.0, 3);
        // wait for the outer ring (the margin) to finish too
        let start = Instant::now();
        while m.pending_count() > 0 || m.pool.queued() > 0 {
            m.update(8.0, 8.0);
            assert!(start.elapsed().as_secs() < 90);
            std::thread::sleep(Duration::from_millis(5));
        }
        for _ in 0..3 {
            m.update(8.0, 8.0);
        }
        assert!(m.load_scan.done, "the load scan must have finished");
        let loaded = m.chunk_count();
        let submitted_before = m.pool.queued() + m.gen_pending.len() + m.mesh_in_flight;
        for _ in 0..50 {
            m.update(8.0, 8.0);
        }
        assert_eq!(m.chunk_count(), loaded);
        assert_eq!(m.pool.queued() + m.gen_pending.len() + m.mesh_in_flight, submitted_before);
        assert!(!m.mesh_scan_pending);
    }

    #[test]
    fn an_edit_is_meshed_again_even_if_it_happens_while_the_chunk_is_being_meshed() {
        let mut m = WorldManager::new(11, 3);
        settle(&mut m, 8.0, 8.0, 2);
        let start = Instant::now();
        while m.pending_count() > 0 {
            m.update(8.0, 8.0);
            assert!(start.elapsed().as_secs() < 90);
            std::thread::sleep(Duration::from_millis(5));
        }
        let _ = m.take_uploads();
        // first edit
        assert!(m.world.set_block(3, 150, 3, Block::Stone, true));
        m.update(8.0, 8.0);
        // second edit while the first mesh job may still be running
        assert!(m.world.set_block(4, 150, 3, Block::Stone, true));
        let mut meshes_of_origin = 0;
        let start = Instant::now();
        loop {
            m.update(8.0, 8.0);
            meshes_of_origin += m.take_uploads().iter().filter(|(pos, _)| *pos == ChunkPos::new(0, 0)).count();
            // finished = both edits were turned into a mesh: nothing is left dirty or in flight
            let e = m.world.entry(ChunkPos::new(0, 0)).unwrap();
            if meshes_of_origin >= 1 && !e.dirty && !e.in_flight {
                break;
            }
            assert!(start.elapsed().as_secs() < 60, "the edited chunk was never finished (dirty {}, in flight {})", e.dirty, e.in_flight);
            std::thread::sleep(Duration::from_millis(3));
        }
        assert_eq!(m.world.get_block(4, 150, 3), Block::Stone);
        assert!(m.mesh_in_flight == 0);
    }

    #[test]
    fn stats_describe_what_the_manager_holds() {
        let mut m = WorldManager::new(3, 2);
        m.update(8.0, 8.0);
        let s = m.stats();
        assert!(s.workers >= 1);
        assert_eq!(s.loaded as usize, m.chunk_count());
        assert_eq!(s.gen_pending as usize, m.gen_pending.len());
    }

    #[test]
    fn saved_chunks_come_back_instead_of_being_generated() {
        let mut m = WorldManager::new(21, 2);
        let mut data = ChunkData::new();
        data.set(1, 200, 1, Block::Stone);
        m.update(8.0, 8.0);
        m.import_edited(vec![(ChunkPos::new(50, 50), data)]);
        // walking there loads the saved chunk, not a generated one
        let start = Instant::now();
        while !m.world.contains(ChunkPos::new(50, 50)) {
            m.update(50.0 * 16.0 + 8.0, 50.0 * 16.0 + 8.0);
            assert!(start.elapsed().as_secs() < 90);
            std::thread::sleep(Duration::from_millis(3));
        }
        assert_eq!(m.world.get_block(50 * 16 + 1, 200, 50 * 16 + 1), Block::Stone);
    }
}
