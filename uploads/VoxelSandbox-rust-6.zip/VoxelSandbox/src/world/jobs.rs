//! The chunk jobs the background workers run: generating terrain and building chunk meshes while the game thread
//! keeps drawing. The queue and the threads are the generic `core::pool::PriorityPool`; this file only says what
//! each kind of job does.

use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::Arc;

use super::chunk::ChunkData;
use super::pos::ChunkPos;
use crate::core::pool::PriorityPool;
use crate::core::clock;
use crate::diag::probe::{self, Counter};
use crate::gen::terrain::TerrainGenerator;
use crate::mesh::mesher::{build_chunk_mesh, MeshContext, MeshInput};
use crate::mesh::ChunkMeshData;

/// Nice value of the chunk workers (0 is normal, 19 the lowest priority): they give way to the game thread.
const WORKER_NICE: i32 = 8;

pub enum Job {
    Generate(ChunkPos),
    Mesh { pos: ChunkPos, version: u64, input: MeshInput },
}

pub enum JobResult {
    Generated(ChunkPos, ChunkData),
    Meshed { pos: ChunkPos, version: u64, mesh: ChunkMeshData },
}

pub type ChunkPool = PriorityPool<Job, JobResult>;

/// Runs `f`, adding its duration to the diagnostics counters when they are on.
#[inline]
fn timed<R>(jobs: Counter, nanos: Counter, f: impl FnOnce() -> R) -> R {
    if !probe::enabled() {
        return f();
    }
    let start = clock::now_ns();
    let result = f();
    probe::count(jobs, 1);
    probe::count(nanos, clock::now_ns().saturating_sub(start));
    result
}

/// Does one job. A panic inside the generator or mesher is caught and replaced by an empty result, so one bad
/// chunk cannot kill a worker thread.
fn run(job: Job, gen: &TerrainGenerator, ctx: &MeshContext) -> JobResult {
    match job {
        Job::Generate(pos) => timed(Counter::GenJobs, Counter::GenNs, || {
            let data = match catch_unwind(AssertUnwindSafe(|| gen.generate(pos))) {
                Ok(d) => d,
                Err(_) => {
                    crate::loge!("terrain generation panicked at {:?}", pos);
                    ChunkData::new()
                }
            };
            JobResult::Generated(pos, data)
        }),
        Job::Mesh { pos, version, input } => timed(Counter::MeshJobs, Counter::MeshNs, || {
            let mesh = match catch_unwind(AssertUnwindSafe(|| build_chunk_mesh(&input, ctx))) {
                Ok(m) => m,
                Err(_) => {
                    crate::loge!("meshing panicked at {:?}", pos);
                    ChunkMeshData::empty()
                }
            };
            JobResult::Meshed { pos, version, mesh }
        }),
    }
}

pub fn new_chunk_pool(threads: usize, gen: Arc<TerrainGenerator>, ctx: Arc<MeshContext>) -> ChunkPool {
    PriorityPool::new("vs-worker", threads, WORKER_NICE, move || {
        let gen = gen.clone();
        let ctx = ctx.clone();
        move |job| run(job, &gen, &ctx)
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
    use std::time::{Duration, Instant};

    #[test]
    fn workers_generate_and_report_back() {
        let gen = Arc::new(TerrainGenerator::new(77));
        let ctx = Arc::new(MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        });
        let mut pool = new_chunk_pool(2, gen, ctx);
        assert_eq!(pool.threads(), 2);
        for i in 0..6 {
            pool.submit(i, Job::Generate(ChunkPos::new(i as i32, 0)));
        }
        let mut got = 0;
        let start = Instant::now();
        while got < 6 {
            match pool.try_recv() {
                Some(JobResult::Generated(_, _)) => got += 1,
                Some(JobResult::Meshed { .. }) => panic!("no mesh job was submitted"),
                None => {
                    assert!(start.elapsed() < Duration::from_secs(60), "workers did not finish");
                    std::thread::sleep(Duration::from_millis(2));
                }
            }
        }
        assert_eq!(pool.queued(), 0);
    }
}
