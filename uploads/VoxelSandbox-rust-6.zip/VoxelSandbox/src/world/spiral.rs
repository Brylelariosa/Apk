//! Chunk offsets around a centre, nearest first. Computed once, so streaming never has to sort thousands of
//! positions every frame: to visit everything within a radius it walks a prefix of this list.

/// One offset: how far from the centre in chunks, and the squared distance.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Offset {
    pub dx: i32,
    pub dz: i32,
    pub dist_sq: i32,
}

pub struct Spiral {
    entries: Vec<Offset>,
    max_radius: i32,
}

impl Spiral {
    /// All offsets within `max_radius` (a disc), sorted nearest first; ties are ordered so the walk is
    /// deterministic.
    pub fn new(max_radius: i32) -> Spiral {
        let r = max_radius.max(1);
        let r_sq = r * r;
        let mut entries = Vec::new();
        for dz in -r..=r {
            for dx in -r..=r {
                let d = dx * dx + dz * dz;
                if d <= r_sq {
                    entries.push(Offset { dx, dz, dist_sq: d });
                }
            }
        }
        entries.sort_unstable_by_key(|o| (o.dist_sq, o.dz, o.dx));
        Spiral { entries, max_radius: r }
    }

    pub fn max_radius(&self) -> i32 {
        self.max_radius
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// The offset at `index` (entries are nearest first).
    #[inline]
    pub fn get(&self, index: usize) -> Offset {
        self.entries[index]
    }

    /// How many entries lie within `radius` chunks (the length of the prefix to walk).
    pub fn count_within(&self, radius: i32) -> usize {
        let r_sq = radius.max(0).min(self.max_radius).pow(2);
        self.entries.partition_point(|o| o.dist_sq <= r_sq)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn it_is_a_sorted_disc_starting_at_the_centre() {
        let s = Spiral::new(6);
        assert_eq!(s.get(0), Offset { dx: 0, dz: 0, dist_sq: 0 });
        let mut last = 0;
        for i in 0..s.len() {
            let o = s.get(i);
            assert!(o.dist_sq >= last, "not sorted at {}", i);
            assert_eq!(o.dist_sq, o.dx * o.dx + o.dz * o.dz);
            assert!(o.dist_sq <= 36);
            last = o.dist_sq;
        }
        // the number of lattice points in a radius-6 disc
        let expected = (-6..=6).flat_map(|z| (-6..=6).map(move |x| (x, z))).filter(|(x, z)| x * x + z * z <= 36).count();
        assert_eq!(s.len(), expected);
    }

    #[test]
    fn a_prefix_covers_exactly_the_smaller_disc() {
        let s = Spiral::new(10);
        for r in 0..=10 {
            let n = s.count_within(r);
            let expected = (-r..=r).flat_map(|z| (-r..=r).map(move |x| (x, z))).filter(|(x, z)| x * x + z * z <= r * r).count();
            assert_eq!(n, expected, "radius {}", r);
            for i in 0..n {
                assert!(s.get(i).dist_sq <= r * r);
            }
        }
        assert_eq!(s.count_within(50), s.len(), "a radius beyond the maximum is clamped");
        assert_eq!(s.count_within(-3), 1, "a negative radius still contains the centre");
    }
}
