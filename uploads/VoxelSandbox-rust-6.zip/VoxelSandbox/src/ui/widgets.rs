//! The logic behind the settings widgets, kept free of drawing so it can be unit-tested on the host:
//! the slider mapping for the render distance, "nice number" snapping, the size of a +/- step, and the
//! timing of hold-to-repeat buttons. Holding a button and dragging a slider are what make it quick to
//! cross a range as wide as 4 to 1000 chunks.

/// How a slider maps its 0..1 position onto a value.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Scale {
    Linear,
    /// Exponential: equal slider distances are equal ratios, so small values stay precise.
    Log,
}

/// The granularity values are rounded to on the log scale: fine when small, coarse when large.
pub fn snap_unit(v: i32) -> i32 {
    if v < 40 {
        1
    } else if v < 100 {
        2
    } else if v < 200 {
        5
    } else if v < 500 {
        10
    } else {
        20
    }
}

/// Rounds `v` to a nice number for its size and keeps it inside `min..=max`.
pub fn snap(v: i32, min: i32, max: i32) -> i32 {
    let u = snap_unit(v);
    let r = ((v as f32 / u as f32).round() as i32) * u;
    r.max(min).min(max)
}

/// Slider position (clamped to 0..1) to value.
pub fn value_from_pos(t: f32, min: i32, max: i32, scale: Scale) -> i32 {
    let t = if t.is_nan() { 0.0 } else { t.max(0.0).min(1.0) };
    if t <= 0.0 {
        return min;
    }
    if t >= 1.0 {
        return max;
    }
    match scale {
        Scale::Linear => ((min as f32 + t * (max - min) as f32).round() as i32).max(min).min(max),
        Scale::Log => {
            let lo = (min.max(1) as f32).ln();
            let hi = (max.max(1) as f32).ln();
            let v = (lo + t * (hi - lo)).exp().round() as i32;
            snap(v, min, max)
        }
    }
}

/// Value to slider position in 0..1 (the inverse of `value_from_pos`).
pub fn pos_from_value(v: i32, min: i32, max: i32, scale: Scale) -> f32 {
    if max <= min {
        return 0.0;
    }
    let v = v.max(min).min(max);
    let t = match scale {
        Scale::Linear => (v - min) as f32 / (max - min) as f32,
        Scale::Log => {
            let lo = (min.max(1) as f32).ln();
            let hi = (max.max(1) as f32).ln();
            ((v.max(1) as f32).ln() - lo) / (hi - lo)
        }
    };
    t.max(0.0).min(1.0)
}

/// The value after one press of a `+` (`dir` = 1) or `-` (`dir` = -1) button.
///
/// On the log scale a step is about 1/16 of the current value (never below the snap unit), times `boost`,
/// so the button crosses 4..1000 in a few dozen presses instead of a thousand. On the linear scale a step is
/// `boost`.
pub fn step_value(v: i32, dir: i32, boost: i32, min: i32, max: i32, scale: Scale) -> i32 {
    let dir = if dir < 0 { -1 } else { 1 };
    let boost = boost.max(1);
    let v = v.max(min).min(max);
    let out = match scale {
        Scale::Linear => v + dir * boost,
        Scale::Log => {
            let unit = snap_unit(v);
            let raw = (v / 16).max(1) * boost;
            let step = ((raw + unit - 1) / unit).max(1) * unit;
            snap(v + dir * step, min, max)
        }
    };
    let mut out = out.max(min).min(max);
    // snapping must never swallow a press
    if dir > 0 && out <= v && v < max {
        out = v + 1;
    }
    if dir < 0 && out >= v && v > min {
        out = v - 1;
    }
    out.max(min).min(max)
}

/// Seconds a button must be held before it starts repeating.
pub const REPEAT_DELAY: f32 = 0.38;
const REPEAT_START_INTERVAL: f32 = 0.16;
const REPEAT_MIN_INTERVAL: f32 = 0.035;
const MAX_STEPS_PER_FRAME: u32 = 8;

/// Seconds between repeats after the button has been held for `held` seconds; it speeds up the longer you hold.
pub fn repeat_interval(held: f32) -> f32 {
    (REPEAT_START_INTERVAL - 0.045 * (held - REPEAT_DELAY).max(0.0)).max(REPEAT_MIN_INTERVAL)
}

/// Step multiplier after holding for `held` seconds: long holds take bigger bites.
pub fn repeat_boost(held: f32) -> i32 {
    if held < 0.9 {
        1
    } else if held < 1.7 {
        2
    } else if held < 2.5 {
        4
    } else {
        8
    }
}

/// What a hold-to-repeat button asks for this frame.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Repeat {
    /// How many steps to apply now (the press itself counts as the first).
    pub steps: u32,
    pub boost: i32,
}

/// Hold-to-repeat timing shared by all the `+` / `-` buttons of a screen (only one finger holds one at a time).
#[derive(Clone, Copy, Debug, Default)]
pub struct HoldRepeater {
    id: Option<u32>,
    held: f32,
    next: f32,
}

impl HoldRepeater {
    pub fn new() -> HoldRepeater {
        HoldRepeater::default()
    }

    pub fn reset(&mut self) {
        *self = HoldRepeater::default();
    }

    /// Call once per frame for every repeat button with whether it is held right now.
    pub fn update(&mut self, id: u32, pressed: bool, dt: f32) -> Repeat {
        if !pressed {
            if self.id == Some(id) {
                self.id = None;
            }
            return Repeat { steps: 0, boost: 1 };
        }
        match self.id {
            None => {
                self.id = Some(id);
                self.held = 0.0;
                self.next = REPEAT_DELAY;
                Repeat { steps: 1, boost: 1 }
            }
            Some(current) if current == id => {
                self.held += dt.max(0.0);
                let mut steps = 0;
                while self.held >= self.next && steps < MAX_STEPS_PER_FRAME {
                    steps += 1;
                    self.next += repeat_interval(self.held);
                }
                if steps == MAX_STEPS_PER_FRAME && self.held >= self.next {
                    // a long frame: do not try to catch up on every missed repeat
                    self.next = self.held + repeat_interval(self.held);
                }
                Repeat { steps, boost: repeat_boost(self.held) }
            }
            Some(_) => Repeat { steps: 0, boost: 1 },
        }
    }
}

/// "160 BLOCKS" or "16.0 KM" for a distance in chunks.
pub fn blocks_label(chunks: i32) -> String {
    let blocks = chunks.max(0) as f32 * 16.0;
    if blocks >= 1000.0 {
        format!("{:.1} KM", blocks / 1000.0)
    } else {
        format!("{:.0} BLOCKS", blocks)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const MIN: i32 = 4;
    const MAX: i32 = 1000;

    #[test]
    fn slider_ends_are_exact() {
        assert_eq!(value_from_pos(0.0, MIN, MAX, Scale::Log), MIN);
        assert_eq!(value_from_pos(1.0, MIN, MAX, Scale::Log), MAX);
        assert_eq!(value_from_pos(-3.0, MIN, MAX, Scale::Log), MIN);
        assert_eq!(value_from_pos(7.0, MIN, MAX, Scale::Log), MAX);
        assert_eq!(value_from_pos(f32::NAN, MIN, MAX, Scale::Log), MIN);
        assert_eq!(value_from_pos(1.0, 4, 24, Scale::Linear), 24);
    }

    #[test]
    fn slider_is_monotonic_and_round_trips() {
        let mut last = 0;
        for i in 0..=1000 {
            let t = i as f32 / 1000.0;
            let v = value_from_pos(t, MIN, MAX, Scale::Log);
            assert!(v >= last, "value went backwards at t={}", t);
            assert!(v >= MIN && v <= MAX);
            last = v;
        }
        for v in [4, 10, 24, 64, 128, 333, 512, 1000] {
            let t = pos_from_value(v, MIN, MAX, Scale::Log);
            let back = value_from_pos(t, MIN, MAX, Scale::Log);
            let unit = snap_unit(v);
            assert!((back - v).abs() <= unit, "{} -> {} -> {}", v, t, back);
        }
    }

    #[test]
    fn log_slider_gives_small_values_room() {
        // the middle of the track is a value around 63, not 500
        let mid = value_from_pos(0.5, MIN, MAX, Scale::Log);
        assert!(mid > 40 && mid < 90, "mid = {}", mid);
    }

    #[test]
    fn snapped_values_stay_in_range() {
        for v in 0..1100 {
            let s = snap(v, MIN, MAX);
            assert!(s >= MIN && s <= MAX);
        }
        assert_eq!(snap(1000, MIN, MAX), 1000);
    }

    #[test]
    fn a_press_always_moves_the_value_until_the_end() {
        let mut v = MIN;
        let mut presses = 0;
        while v < MAX {
            let n = step_value(v, 1, 1, MIN, MAX, Scale::Log);
            assert!(n > v, "stuck at {}", v);
            v = n;
            presses += 1;
            assert!(presses < 400, "too many presses");
        }
        assert_eq!(v, MAX);
        while v > MIN {
            let n = step_value(v, -1, 1, MIN, MAX, Scale::Log);
            assert!(n < v, "stuck at {}", v);
            v = n;
        }
        assert_eq!(step_value(MAX, 1, 1, MIN, MAX, Scale::Log), MAX);
        assert_eq!(step_value(MIN, -1, 1, MIN, MAX, Scale::Log), MIN);
    }

    #[test]
    fn small_values_move_by_one_and_boost_makes_bigger_bites() {
        assert_eq!(step_value(10, 1, 1, MIN, MAX, Scale::Log), 11);
        assert_eq!(step_value(10, -1, 1, MIN, MAX, Scale::Log), 9);
        let a = step_value(400, 1, 1, MIN, MAX, Scale::Log);
        let b = step_value(400, 1, 8, MIN, MAX, Scale::Log);
        assert!(b - 400 > 4 * (a - 400), "boost should bite harder: {} vs {}", a, b);
        assert_eq!(step_value(10, 1, 3, 4, 24, Scale::Linear), 13);
    }

    #[test]
    fn button_repeats_after_a_delay_and_speeds_up() {
        let mut h = HoldRepeater::new();
        let r = h.update(1, true, 0.016);
        assert_eq!(r.steps, 1, "the press itself is a step");
        let mut t = 0.0;
        let mut total = 0;
        let mut after_one_second = 0;
        let mut after_three_seconds = 0;
        while t < 3.0 {
            let r = h.update(1, true, 0.016);
            total += r.steps;
            t += 0.016;
            if t < REPEAT_DELAY - 0.03 {
                assert_eq!(total, 0, "no repeat before the delay (t={})", t);
            }
            if after_one_second == 0 && t >= 1.0 {
                after_one_second = total;
            }
        }
        after_three_seconds += total;
        assert!(after_one_second >= 3, "repeats within the first second: {}", after_one_second);
        assert!(after_three_seconds - after_one_second > after_one_second * 2, "it must speed up");
        // releasing stops it and a new press starts over
        let r = h.update(1, false, 0.016);
        assert_eq!(r.steps, 0);
        assert_eq!(h.update(1, true, 0.016).steps, 1);
    }

    #[test]
    fn holding_crosses_the_whole_range_in_a_few_seconds() {
        let mut h = HoldRepeater::new();
        let mut v = MIN;
        let mut t = 0.0;
        let dt = 1.0 / 60.0;
        while v < MAX && t < 10.0 {
            let r = h.update(7, true, dt);
            for _ in 0..r.steps {
                v = step_value(v, 1, r.boost, MIN, MAX, Scale::Log);
            }
            t += dt;
        }
        assert_eq!(v, MAX);
        assert!(t < 4.5, "took {} s to cross the range", t);
    }

    #[test]
    fn only_one_button_is_held_at_a_time() {
        let mut h = HoldRepeater::new();
        assert_eq!(h.update(1, true, 0.016).steps, 1);
        // a second finger on another button does not steal or double the repeat
        assert_eq!(h.update(2, true, 0.016).steps, 0);
        h.update(1, false, 0.016);
        assert_eq!(h.update(2, true, 0.016).steps, 1);
    }

    #[test]
    fn a_long_frame_does_not_flood_steps() {
        let mut h = HoldRepeater::new();
        h.update(1, true, 0.016);
        let r = h.update(1, true, 5.0);
        assert!(r.steps <= MAX_STEPS_PER_FRAME);
    }

    #[test]
    fn distance_labels() {
        assert_eq!(blocks_label(10), "160 BLOCKS");
        assert_eq!(blocks_label(1000), "16.0 KM");
        assert_eq!(blocks_label(63), "1.0 KM");
    }
}
