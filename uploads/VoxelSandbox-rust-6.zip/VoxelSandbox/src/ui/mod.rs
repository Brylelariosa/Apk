//! Screens and touch controls. Everything here is plain Rust that produces `UiBatch` geometry; the Android
//! shell only has to draw it.

pub mod app;
pub mod batch;
pub mod font;
pub mod hud;
pub mod touch;
pub mod widgets;
