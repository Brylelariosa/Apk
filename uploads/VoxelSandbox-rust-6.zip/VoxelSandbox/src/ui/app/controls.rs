//! Reusable menu controls that are more than a plain button: tabs, the slider and the hold-to-repeat
//! `-` / `+` buttons. The timing and value maths live in `ui::widgets`; this file draws and reads touches.

use super::{App, GREY};
use crate::ui::batch::{rgba, UiBatch};
use crate::ui::widgets::{self, Repeat, Scale};

fn inside(px: f32, py: f32, x: f32, y: f32, w: f32, h: f32) -> bool {
    px >= x && px <= x + w && py >= y && py <= y + h
}

impl App {
    /// True while a finger that went down on the rectangle is still on it.
    pub(super) fn held_inside(&self, x: f32, y: f32, w: f32, h: f32) -> bool {
        self.touches
            .active
            .iter()
            .any(|t| inside(t.start_x, t.start_y, x, y, w, h) && inside(t.x, t.y, x, y, w, h))
    }

    /// A button that acts when pressed and keeps acting while it is held, faster the longer you hold.
    /// `id` must be unique among the buttons of a screen.
    pub(super) fn repeat_button(&mut self, id: u32, x: f32, y: f32, w: f32, h: f32, label: &str) -> Repeat {
        let pressed = self.held_inside(x, y, w, h);
        let r = self.repeat.update(id, pressed, self.dt);
        self.draw_button(x, y, w, h, label, pressed);
        self.note_rect(if label == "-" { "repeat-" } else { "repeat+" }, x, y, w, h);
        r
    }

    /// A horizontal slider. Returns the new value while a finger that went down on the slider is dragging it.
    pub(super) fn slider(
        &mut self,
        name: &'static str,
        x: f32,
        y: f32,
        w: f32,
        h: f32,
        value: i32,
        min: i32,
        max: i32,
        scale: Scale,
    ) -> Option<i32> {
        let knob_w = self.dp(14.0);
        let hit_x = x - knob_w * 0.5;
        let hit_w = w + knob_w;
        let mut result = None;
        let mut dragging = false;
        for t in self.touches.active.iter() {
            if inside(t.start_x, t.start_y, hit_x, y, hit_w, h) {
                dragging = true;
                let v = widgets::value_from_pos((t.x - x) / w.max(1.0), min, max, scale);
                if v != value {
                    result = Some(v);
                }
            }
        }
        let shown = result.unwrap_or(value);
        let pos = widgets::pos_from_value(shown, min, max, scale);
        let track_h = self.dp(6.0);
        let ty = y + (h - track_h) * 0.5;
        self.ui.rect(x, ty, w, track_h, rgba(16, 20, 30, 255));
        self.ui.rect(x, ty, w * pos, track_h, rgba(104, 168, 118, 255));
        let line = self.dp(1.0);
        self.ui.border(x, ty, w, track_h, line, rgba(120, 132, 168, 255));
        let kx = x + w * pos - knob_w * 0.5;
        let fill = if dragging { rgba(255, 214, 102, 255) } else { rgba(200, 210, 235, 255) };
        self.ui.rect(kx, y, knob_w, h, fill);
        let edge = self.dp(2.0);
        self.ui.border(kx, y, knob_w, h, edge, rgba(40, 48, 70, 255));
        self.note_rect(name, hit_x, y, hit_w, h);
        result
    }

    /// A labelled slider row: the label and a value readout on top, then `[-] ====o==== [+] [MAX]`.
    /// `id` numbers the hold-to-repeat buttons (it uses `id` and `id + 1`). Returns the new value if it changed.
    pub(super) fn slider_row(
        &mut self,
        id: u32,
        name: &'static str,
        x: f32,
        y: f32,
        w: f32,
        label: &str,
        value_text: &str,
        value: i32,
        range: (i32, i32),
        scale: Scale,
        max_button: bool,
        taps: &[(f32, f32)],
    ) -> Option<i32> {
        let (min, max) = range;
        let lpx = self.font_px(8.0);
        self.ui.text(x, y, lpx, label, GREY);
        let vpx = self.font_px(9.0);
        let vw = UiBatch::text_width(value_text, vpx);
        self.ui.text_shadow(x + w - vw, y, vpx, value_text, super::WHITE);

        let cy = y + self.dp(18.0);
        let b = self.dp(30.0);
        let gap = self.dp(6.0);
        let half_knob = self.dp(7.0);
        let max_w = if max_button { self.dp(50.0) } else { 0.0 };
        let right = x + w;
        let max_x = right - max_w;
        let plus_x = if max_button { max_x - gap - b } else { right - b };
        let minus_x = x;
        let track_x = minus_x + b + gap + half_knob;
        let track_w = (plus_x - gap - half_knob) - track_x;

        let mut v = value;
        let r = self.repeat_button(id, minus_x, cy, b, b, "-");
        for _ in 0..r.steps {
            v = widgets::step_value(v, -1, r.boost, min, max, scale);
        }
        let r = self.repeat_button(id + 1, plus_x, cy, b, b, "+");
        for _ in 0..r.steps {
            v = widgets::step_value(v, 1, r.boost, min, max, scale);
        }
        if let Some(dragged) = self.slider(name, track_x, cy, track_w, b, v, min, max, scale) {
            v = dragged;
        }
        if max_button && self.button(max_x, cy, max_w, b, "MAX", taps) {
            v = max;
        }
        if v != value {
            Some(v)
        } else {
            None
        }
    }

    /// A row of tabs; returns the index of the tab tapped this frame. The active tab gets a gold frame.
    pub(super) fn tab_bar(
        &mut self,
        x: f32,
        y: f32,
        w: f32,
        h: f32,
        labels: &[&str],
        active: usize,
        taps: &[(f32, f32)],
    ) -> Option<usize> {
        let gap = self.dp(6.0);
        let n = labels.len().max(1) as f32;
        let tw = (w - gap * (n - 1.0)) / n;
        let pad = self.dp(3.0);
        let mut picked = None;
        for (i, label) in labels.iter().enumerate() {
            let tx = x + i as f32 * (tw + gap);
            if i == active {
                self.ui.rect(tx - pad, y - pad, tw + pad * 2.0, h + pad * 2.0, rgba(255, 214, 102, 255));
            }
            if self.button(tx, y, tw, h, label, taps) {
                picked = Some(i);
            }
        }
        picked
    }
}
