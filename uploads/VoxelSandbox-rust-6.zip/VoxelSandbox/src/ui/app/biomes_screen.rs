//! The biome finder: pick a biome, the game searches the world for the nearest one (a few milliseconds of work per
//! frame, so the screen keeps moving), and then it can teleport you there.

use super::{App, Screen, GOLD, GREY, WHITE};
use crate::game::biome_search::{compass, BiomeSearch, SEARCH_RADIUS};
use crate::gen::climate::Biome;
use crate::ui::batch::{rgba, UiBatch};
use std::time::Instant;

/// Every biome the finder can look for, in the order of the menu (three to a row).
const FINDABLE: [Biome; 18] = [
    Biome::Plains,
    Biome::Forest,
    Biome::BirchForest,
    Biome::Jungle,
    Biome::Rainforest,
    Biome::Taiga,
    Biome::SnowyPlains,
    Biome::SnowyTaiga,
    Biome::Savanna,
    Biome::Desert,
    Biome::Swamp,
    Biome::Mountains,
    Biome::SnowyPeaks,
    Biome::Beach,
    Biome::SnowyShore,
    Biome::Lake,
    Biome::Ocean,
    Biome::DeepOcean,
];

/// How long the search may work in one frame, in microseconds.
const SEARCH_MICROS_PER_FRAME: u128 = 4000;

impl App {
    pub(super) fn biomes_screen(&mut self, dt: f32, taps: &[(f32, f32)]) {
        // the world stands behind the menu, as it does behind the inventory
        let generator = match self.engine.as_mut() {
            Some(engine) => {
                engine.input.ui_blocked = true;
                engine.update(&self.effective, dt);
                Some(engine.manager.gen.clone())
            }
            None => None,
        };
        // let the search work for a few milliseconds
        if let (Some(search), Some(generator)) = (self.biome_search.as_mut(), generator.as_ref()) {
            let started = Instant::now();
            while !search.is_done() && started.elapsed().as_micros() < SEARCH_MICROS_PER_FRAME {
                search.advance(generator, 16);
            }
        }

        self.dim(170);
        let w = self.width;
        let m = self.dp(14.0);
        let title_px = self.font_px(12.0);
        self.ui.text_shadow(m, m, title_px, "FIND A BIOME", WHITE);
        let close = self.dp(40.0);
        if self.button(w - m - close, m * 0.6, close, close, "X", taps) {
            self.biome_search = None;
            self.go(Screen::Playing);
            return;
        }

        // what the search is doing, copied out so that the buttons below can borrow the app
        let state = self.biome_search.as_ref().map(|s| (s.target(), s.is_done(), s.found(), s.origin(), s.radius(), s.progress()));
        match state {
            None => self.biome_list(taps),
            Some((target, false, _, _, radius, progress)) => {
                let cx = w * 0.5;
                let px = self.font_px(12.0);
                let label = format!("SEARCHING FOR {}", target.display_name());
                let top = self.height * 0.32;
                self.ui.text_centered(cx, top, px, &label, WHITE);
                let bw = self.dp(300.0);
                let bh = self.dp(14.0);
                let x = cx - bw * 0.5;
                let y = top + UiBatch::text_height(px) + self.dp(16.0);
                self.ui.rect(x, y, bw, bh, rgba(255, 255, 255, 50));
                self.ui.rect(x, y, bw * progress, bh, rgba(120, 200, 120, 255));
                let t = self.dp(2.0);
                self.ui.border(x, y, bw, bh, t, rgba(255, 255, 255, 160));
                let np = self.font_px(9.0);
                let info = format!("{} OF {} BLOCKS", radius, SEARCH_RADIUS);
                self.ui.text_centered(cx, y + bh + self.dp(10.0), np, &info, GREY);
                let button_w = self.dp(160.0);
                let button_h = self.dp(40.0);
                if self.button(cx - button_w * 0.5, y + bh + self.dp(40.0), button_w, button_h, "CANCEL", taps) {
                    self.biome_search = None;
                }
            }
            Some((target, true, Some((fx, fz)), (ox, oz), _, _)) => {
                let cx = w * 0.5;
                let dx = (fx - ox) as f32;
                let dz = (fz - oz) as f32;
                let dist = (dx * dx + dz * dz).sqrt();
                let dist_text = if dist >= 2000.0 { format!("{:.1} KM", dist / 1000.0) } else { format!("{} BLOCKS", dist.round() as i32) };
                let top = self.height * 0.24;
                let tp = self.font_px(14.0);
                let title = format!("FOUND {}", target.display_name());
                self.ui.text_centered(cx, top, tp, &title, GOLD);
                let lp = self.font_px(11.0);
                let line = format!("{} {}", dist_text, compass(ox, oz, fx, fz));
                self.ui.text_centered(cx, top + self.dp(34.0), lp, &line, WHITE);
                let cp = self.font_px(9.0);
                let coords = format!("X {}  Z {}", fx, fz);
                self.ui.text_centered(cx, top + self.dp(64.0), cp, &coords, GREY);
                let bw = self.dp(220.0);
                let bh = self.dp(44.0);
                let by = top + self.dp(96.0);
                if self.button(cx - bw * 0.5, by, bw, bh, "TELEPORT", taps) {
                    if let Some(engine) = self.engine.as_mut() {
                        engine.teleport(fx, fz);
                    }
                    self.biome_search = None;
                    self.loading_time = 0.0;
                    self.go(Screen::Loading);
                    return;
                }
                if self.button(cx - bw * 0.5, by + bh + self.dp(10.0), bw, bh, "BACK TO LIST", taps) {
                    self.biome_search = None;
                }
            }
            Some((target, true, None, _, _, _)) => {
                let cx = w * 0.5;
                let top = self.height * 0.30;
                let tp = self.font_px(12.0);
                let line = format!("NO {} WITHIN {} BLOCKS", target.display_name(), SEARCH_RADIUS);
                self.ui.text_centered(cx, top, tp, &line, WHITE);
                let bw = self.dp(220.0);
                let bh = self.dp(44.0);
                if self.button(cx - bw * 0.5, top + self.dp(50.0), bw, bh, "BACK TO LIST", taps) {
                    self.biome_search = None;
                }
            }
        }
    }

    /// The menu of biomes to look for.
    fn biome_list(&mut self, taps: &[(f32, f32)]) {
        let w = self.width;
        let m = self.dp(14.0);
        let cols = 3usize;
        let gap = self.dp(8.0);
        let bw = (w - 2.0 * m - gap * (cols as f32 - 1.0)) / cols as f32;
        let bh = self.dp(36.0);
        let row_gap = self.dp(6.0);
        let top = self.dp(62.0);
        let hint_px = self.font_px(8.0);
        self.ui.text(m, self.dp(38.0), hint_px, "PICK A BIOME: THE GAME SEARCHES FOR THE NEAREST ONE", GREY);
        let mut picked: Option<Biome> = None;
        for (i, biome) in FINDABLE.iter().enumerate() {
            let col = i % cols;
            let row = i / cols;
            let x = m + col as f32 * (bw + gap);
            let y = top + row as f32 * (bh + row_gap);
            if self.button(x, y, bw, bh, biome.display_name(), taps) {
                picked = Some(*biome);
            }
        }
        if let Some(target) = picked {
            if let Some(engine) = self.engine.as_ref() {
                let x = engine.player.position.x.floor() as i32;
                let z = engine.player.position.z.floor() as i32;
                self.biome_search = Some(BiomeSearch::new(target, x, z));
            }
        }
    }
}
