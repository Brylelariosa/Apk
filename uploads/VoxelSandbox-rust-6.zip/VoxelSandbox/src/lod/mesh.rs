//! Turns the cells of a far-terrain tile (see `cells`) into triangles, the way the block world does it, only
//! with bigger blocks:
//!
//! * every land cell is a flat quad at its height;
//! * where a cell stands higher than a neighbour there is a vertical wall down to the neighbour's top;
//! * along the edge of the tile (and along the edge between two quarters of a tile, see below) the wall always goes
//!   a long way down, because the ground next to it may belong to a tile of another level whose heights are
//!   different: the wall hides the crack between the two;
//! * neighbouring sea cells of the same colour are drawn as one big quad.
//!
//! A tile of level `k` is made of four quarters, each exactly one tile of level `k - 1`. Where the finer tile exists
//! the quarter is not drawn, so the triangles are stored quarter by quarter and the renderer draws the quarters it
//! needs (see `draw_runs`). Faces are shaded like the faces of real blocks; the shading is baked into the vertex
//! colours, so the shader has nothing to compute.

use super::cells::{Cell, CellGrid};
use super::tiles::{TileKey, CELLS};

/// What the GPU gets per vertex: position inside the tile (x and z are blocks from the tile's corner, y is the
/// absolute height) and the face colour. Sixteen bytes.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct FarVertex {
    pub pos: [f32; 3],
    pub color: [u8; 4],
}

pub const FAR_VERTEX_SIZE: usize = std::mem::size_of::<FarVertex>();

/// Cells along one side of a quarter.
const HALF: usize = CELLS / 2;
/// Brightness of the walls, by the way they face: the same numbers the block meshes use (the top is 1.0).
const SHADE_NORTH_SOUTH: f32 = 0.82;
const SHADE_EAST_WEST: f32 = 0.70;
/// What 16-bit indices can address.
const MAX_VERTICES: usize = 1 << 16;

/// Quad corners of a cell's top, counter-clockwise seen from above (0 / 1 pick the cell's low / high edge; for the
/// walls the middle number picks the bottom / top).
const TOP_CORNERS: [[u8; 3]; 4] = [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]];
/// The four walls of a cell in the order north (-z), south (+z), east (+x), west (-x), counter-clockwise seen from
/// outside.
const WALL_CORNERS: [[[u8; 3]; 4]; 4] = [
    [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
    [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
];
const WALL_STEP: [(i32, i32); 4] = [(0, -1), (0, 1), (1, 0), (-1, 0)];
const WALL_SHADE: [f32; 4] = [SHADE_NORTH_SOUTH, SHADE_NORTH_SOUTH, SHADE_EAST_WEST, SHADE_EAST_WEST];

/// How far below its top a wall at the edge of a tile (or quarter) reaches at least. Bigger cells can be further
/// out of step with the ground next to them.
pub fn wall_drop(cell: i32) -> f32 {
    ((cell as f32) * 4.0).max(32.0).min(256.0)
}

/// How far merged sea quads are grown, to cover the hairline cracks the rasteriser can leave where one big quad
/// meets several small ones.
fn sea_grow(cell: f32) -> f32 {
    (cell * 0.004).max(0.02)
}

/// A finished tile, ready to be copied into GPU buffers.
pub struct FarTileData {
    pub key: TileKey,
    pub vertices: Vec<FarVertex>,
    pub indices: Vec<u16>,
    /// Quarter `q` (bit `qx + 2 * qz`, as in the hole masks) is `indices[quarter_starts[q]..quarter_starts[q + 1]]`.
    pub quarter_starts: [u32; 5],
    /// Lowest and highest point of the tile including the walls, for frustum culling.
    pub min_y: f32,
    pub max_y: f32,
}

impl FarTileData {
    /// A flat grey tile at height `y`: stands in for a tile whose terrain could not be built.
    pub fn flat(key: TileKey, y: f32) -> FarTileData {
        let grey = [150, 150, 150];
        build_tile_mesh(key, &CellGrid::filled(Cell::land(y, grey, grey)))
    }

    pub fn triangle_count(&self) -> usize {
        self.indices.len() / 3
    }

    /// Memory the GPU buffers will take.
    pub fn bytes(&self) -> usize {
        self.vertices.len() * FAR_VERTEX_SIZE + self.indices.len() * 2
    }
}

/// The parts of a tile's index list to draw when the quarters in `hole_mask` are left out: `(first index, count)`
/// pairs, with neighbouring quarters joined so that a whole tile is a single draw. Returns the runs and how many
/// there are.
pub fn draw_runs(starts: &[u32; 5], hole_mask: u8) -> ([(u32, u32); 4], usize) {
    let mut runs = [(0u32, 0u32); 4];
    let mut n = 0;
    let mut open: Option<u32> = None;
    for q in 0..4 {
        if hole_mask & (1 << q) != 0 {
            // a left-out quarter ends the run that came before it
            if let Some(first) = open.take() {
                runs[n] = (first, starts[q] - first);
                n += 1;
            }
        } else if starts[q + 1] > starts[q] && open.is_none() {
            open = Some(starts[q]);
        }
    }
    if let Some(first) = open {
        runs[n] = (first, starts[4] - first);
        n += 1;
    }
    (runs, n)
}

fn shaded(color: [u8; 3], shade: f32) -> [u8; 4] {
    let c = |v: u8| ((v as f32) * shade).round().min(255.0) as u8;
    [c(color[0]), c(color[1]), c(color[2]), 255]
}

struct Builder {
    vertices: Vec<FarVertex>,
    indices: Vec<u16>,
    min_y: f32,
    max_y: f32,
    /// Set if a tile ever needed more vertices than 16-bit indices can address (it cannot happen: the largest tile
    /// has about a fifth of that; the flag keeps the tests honest).
    overflowed: bool,
}

impl Builder {
    fn new() -> Builder {
        Builder { vertices: Vec::with_capacity(8192), indices: Vec::with_capacity(16384), min_y: f32::MAX, max_y: f32::MIN, overflowed: false }
    }

    fn quad(&mut self, corners: [[f32; 3]; 4], color: [u8; 4]) {
        if self.vertices.len() + 4 > MAX_VERTICES {
            self.overflowed = true;
            return;
        }
        let base = self.vertices.len() as u16;
        for p in corners.iter() {
            self.vertices.push(FarVertex { pos: *p, color });
            self.min_y = self.min_y.min(p[1]);
            self.max_y = self.max_y.max(p[1]);
        }
        self.indices.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
    }

    /// A flat quad covering x `x0..x1`, z `z0..z1` at height `y`.
    fn top(&mut self, x0: f32, z0: f32, x1: f32, z1: f32, y: f32, color: [u8; 3]) {
        let mut corners = [[0.0f32; 3]; 4];
        for (i, c) in TOP_CORNERS.iter().enumerate() {
            corners[i] = [if c[0] == 0 { x0 } else { x1 }, y, if c[2] == 0 { z0 } else { z1 }];
        }
        self.quad(corners, shaded(color, 1.0));
    }

    /// The wall `side` of the cell covering x `x0..x1`, z `z0..z1`, from `top` down to `bottom`.
    fn wall(&mut self, side: usize, x0: f32, z0: f32, x1: f32, z1: f32, top: f32, bottom: f32, color: [u8; 3]) {
        let mut corners = [[0.0f32; 3]; 4];
        for (i, c) in WALL_CORNERS[side].iter().enumerate() {
            corners[i] = [if c[0] == 0 { x0 } else { x1 }, if c[1] == 0 { bottom } else { top }, if c[2] == 0 { z0 } else { z1 }];
        }
        self.quad(corners, shaded(color, WALL_SHADE[side]));
    }
}

fn same_sea(a: &Cell, b: &Cell) -> bool {
    a.water && b.water && a.color == b.color
}

/// The quarter (bit number) a cell of the tile is in.
fn quarter_of(cx: i32, cz: i32) -> usize {
    (cx as usize / HALF) + 2 * (cz as usize / HALF)
}

fn emit_quarter(b: &mut Builder, grid: &CellGrid, level: usize, q: usize, cell: f32, drop: f32) {
    let (qx, qz) = ((q % 2) * HALF, (q / 2) * HALF);
    let grow = sea_grow(cell);
    // tops first: sea cells are merged into rectangles, land cells stay single
    let mut done = [false; HALF * HALF];
    for lz in 0..HALF {
        for lx in 0..HALF {
            if done[lz * HALF + lx] {
                continue;
            }
            let (cx, cz) = ((qx + lx) as i32, (qz + lz) as i32);
            let c = grid.get(cx, cz);
            let (mut w, mut d) = (1usize, 1usize);
            if c.water {
                while lx + w < HALF && !done[lz * HALF + lx + w] && same_sea(grid.get(cx + w as i32, cz), c) {
                    w += 1;
                }
                'rows: while lz + d < HALF {
                    for i in 0..w {
                        if done[(lz + d) * HALF + lx + i] || !same_sea(grid.get(cx + i as i32, cz + d as i32), c) {
                            break 'rows;
                        }
                    }
                    d += 1;
                }
            }
            for j in 0..d {
                for i in 0..w {
                    done[(lz + j) * HALF + lx + i] = true;
                }
            }
            let (x0, z0) = (cx as f32 * cell, cz as f32 * cell);
            let (x1, z1) = (x0 + w as f32 * cell, z0 + d as f32 * cell);
            if c.water {
                b.top(x0 - grow, z0 - grow, x1 + grow, z1 + grow, c.top, c.color);
            } else {
                b.top(x0, z0, x1, z1, c.top, c.color);
            }
        }
    }
    // then the walls of the land cells
    for lz in 0..HALF {
        for lx in 0..HALF {
            let (cx, cz) = ((qx + lx) as i32, (qz + lz) as i32);
            let c = grid.get(cx, cz);
            if c.water {
                continue;
            }
            let (x0, z0) = (cx as f32 * cell, cz as f32 * cell);
            let (x1, z1) = (x0 + cell, z0 + cell);
            for side in 0..4 {
                let (nx, nz) = (cx + WALL_STEP[side].0, cz + WALL_STEP[side].1);
                let n = grid.get(nx, nz);
                let outside = nx < 0 || nz < 0 || nx >= CELLS as i32 || nz >= CELLS as i32;
                // Tiles of level 0 never have a finer tile inside them, so only the outside needs the long wall.
                let other_quarter = !outside && level > 0 && quarter_of(nx, nz) != q;
                let bottom = if outside || other_quarter {
                    n.top.min(c.top - drop)
                } else if n.top < c.top {
                    n.top
                } else {
                    continue;
                };
                b.wall(side, x0, z0, x1, z1, c.top, bottom, c.wall);
            }
        }
    }
}

/// The triangles of a tile.
pub fn build_tile_mesh(key: TileKey, grid: &CellGrid) -> FarTileData {
    let cell = key.cell() as f32;
    let drop = wall_drop(key.cell());
    let mut b = Builder::new();
    let mut quarter_starts = [0u32; 5];
    for q in 0..4 {
        quarter_starts[q] = b.indices.len() as u32;
        emit_quarter(&mut b, grid, key.level(), q, cell, drop);
    }
    quarter_starts[4] = b.indices.len() as u32;
    if b.vertices.is_empty() {
        b.min_y = 0.0;
        b.max_y = 0.0;
    }
    if b.overflowed {
        crate::logw!("far tile {:?} is too big for 16-bit indices, the rest of it was dropped", key);
    }
    b.vertices.shrink_to_fit();
    b.indices.shrink_to_fit();
    FarTileData { key, vertices: b.vertices, indices: b.indices, quarter_starts, min_y: b.min_y, max_y: b.max_y }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn land(top: f32) -> Cell {
        Cell::land(top, [100, 120, 80], [90, 70, 50])
    }

    fn quads(t: &FarTileData) -> usize {
        t.indices.len() / 6
    }

    /// The normal of triangle `i` of a tile (not normalised).
    fn normal(t: &FarTileData, i: usize) -> [f32; 3] {
        let p = |k: usize| t.vertices[t.indices[i * 3 + k] as usize].pos;
        let (a, b, c) = (p(0), p(1), p(2));
        let u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
        let v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
    }

    fn area(t: &FarTileData, i: usize) -> f32 {
        let n = normal(t, i);
        0.5 * (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt()
    }

    #[test]
    fn a_vertex_is_sixteen_bytes() {
        assert_eq!(FAR_VERTEX_SIZE, 16);
    }

    #[test]
    fn a_flat_land_tile_is_one_top_per_cell_and_a_wall_along_the_outside() {
        let g = CellGrid::filled(land(70.0));
        let t = build_tile_mesh(TileKey::new(0, 3, -2), &g);
        assert_eq!(quads(&t), CELLS * CELLS + 4 * CELLS);
        assert_eq!(t.vertices.len(), quads(&t) * 4);
        assert!(t.indices.iter().all(|&i| (i as usize) < t.vertices.len()));
        // coarser tiles also have walls between their quarters (a finer tile may sit in any of them)
        let t1 = build_tile_mesh(TileKey::new(1, 0, 0), &g);
        assert_eq!(quads(&t1), CELLS * CELLS + 4 * CELLS + 2 * 2 * CELLS);
    }

    #[test]
    fn a_step_gets_one_wall_down_to_the_lower_neighbour() {
        let mut g = CellGrid::filled(land(70.0));
        g.set(5, 5, land(80.0));
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        assert_eq!(quads(&t), CELLS * CELLS + 4 * CELLS + 4, "four walls around the raised cell");
        // the walls run exactly from 80 down to 70
        let mut wall_quads = 0;
        for q in 0..quads(&t) {
            let ys: Vec<f32> = (0..4).map(|k| t.vertices[q * 4 + k].pos[1]).collect();
            let (lo, hi) = (ys.iter().cloned().fold(f32::MAX, f32::min), ys.iter().cloned().fold(f32::MIN, f32::max));
            if lo == 70.0 && hi == 80.0 {
                wall_quads += 1;
            }
        }
        assert_eq!(wall_quads, 4);
    }

    #[test]
    fn a_pit_makes_walls_on_the_cells_around_it_not_on_itself() {
        let mut g = CellGrid::filled(land(70.0));
        g.set(10, 10, land(60.0));
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        assert_eq!(quads(&t), CELLS * CELLS + 4 * CELLS + 4);
        // every wall of the pit belongs to a neighbour, so it hangs from 70
        let low_walls = (0..quads(&t))
            .filter(|&q| (0..4).all(|k| t.vertices[q * 4 + k].pos[1] <= 70.0) && (0..4).any(|k| t.vertices[q * 4 + k].pos[1] == 60.0) && (0..4).any(|k| t.vertices[q * 4 + k].pos[1] == 70.0))
            .count();
        assert_eq!(low_walls, 4);
    }

    #[test]
    fn walls_along_the_outside_reach_at_least_the_drop_and_further_for_a_cliff() {
        let mut g = CellGrid::filled(land(100.0));
        let drop = wall_drop(8);
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        assert!((t.min_y - (100.0 - drop)).abs() < 1e-3, "{} vs {}", t.min_y, 100.0 - drop);
        // the tile next door is a lot lower: the wall goes down to it
        g.set(-1, 7, land(10.0));
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        assert!((t.min_y - 10.0).abs() < 1e-3, "{}", t.min_y);
    }

    #[test]
    fn sea_has_no_walls_and_merges_into_one_quad_per_quarter() {
        let g = CellGrid::filled(Cell::sea(63.875, [60, 116, 206]));
        let t = build_tile_mesh(TileKey::new(2, 1, 1), &g);
        assert_eq!(quads(&t), 4);
        for q in 0..4 {
            assert_eq!(t.quarter_starts[q + 1] - t.quarter_starts[q], 6);
        }
        assert!(t.vertices.iter().all(|v| v.pos[1] == 63.875));
    }

    #[test]
    fn sea_of_different_colours_does_not_merge_and_a_shore_wall_goes_down_to_the_water() {
        let mut g = CellGrid::filled(Cell::sea(63.875, [60, 116, 206]));
        for cz in 0..CELLS as i32 {
            g.set(0, cz, Cell::sea(63.875, [90, 150, 210])); // a lighter shallow strip
            g.set(1, cz, land(66.0));
        }
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        // land strip: 32 tops, 32 walls toward the strip (west), 32 toward the sea (east), plus the tile's outside walls
        let walls_to_water = (0..quads(&t)).filter(|&q| (0..4).any(|k| t.vertices[q * 4 + k].pos[1] == 66.0) && (0..4).any(|k| t.vertices[q * 4 + k].pos[1] == 63.875)).count();
        assert_eq!(walls_to_water, 2 * CELLS);
    }

    #[test]
    fn quarters_split_the_index_list_and_each_stays_in_its_own_area() {
        let mut g = CellGrid::filled(land(70.0));
        for cz in 0..CELLS as i32 {
            for cx in 0..CELLS as i32 {
                g.set(cx, cz, land(70.0 + ((cx * 7 + cz * 13) % 5) as f32));
            }
        }
        let t = build_tile_mesh(TileKey::new(1, 0, 0), &g);
        let cell = 16.0;
        let half = HALF as f32 * cell;
        assert_eq!(t.quarter_starts[0], 0);
        assert_eq!(t.quarter_starts[4] as usize, t.indices.len());
        for q in 0..4 {
            assert!(t.quarter_starts[q] < t.quarter_starts[q + 1], "quarter {} is empty", q);
            let (x0, z0) = ((q % 2) as f32 * half, (q / 2) as f32 * half);
            for &i in &t.indices[t.quarter_starts[q] as usize..t.quarter_starts[q + 1] as usize] {
                let p = t.vertices[i as usize].pos;
                assert!(p[0] >= x0 - 1e-3 && p[0] <= x0 + half + 1e-3, "quarter {} x {}", q, p[0]);
                assert!(p[2] >= z0 - 1e-3 && p[2] <= z0 + half + 1e-3, "quarter {} z {}", q, p[2]);
            }
        }
    }

    #[test]
    fn draw_runs_join_neighbouring_quarters() {
        let s = [0u32, 10, 20, 30, 40];
        let runs = |m: u8| {
            let (r, n) = draw_runs(&s, m);
            r[..n].to_vec()
        };
        assert_eq!(runs(0b0000), vec![(0, 40)]);
        assert_eq!(runs(0b0001), vec![(10, 30)]);
        assert_eq!(runs(0b0010), vec![(0, 10), (20, 20)]);
        assert_eq!(runs(0b0100), vec![(0, 20), (30, 10)]);
        assert_eq!(runs(0b1000), vec![(0, 30)]);
        assert_eq!(runs(0b0110), vec![(0, 10), (30, 10)]);
        assert_eq!(runs(0b0101), vec![(10, 10), (30, 10)]);
        assert_eq!(runs(0b1111), vec![]);
        // an empty quarter is skipped
        let (r, n) = draw_runs(&[0, 10, 10, 20, 30], 0);
        assert_eq!(r[..n].to_vec(), vec![(0, 30)]);
    }

    #[test]
    fn the_busiest_possible_tile_fits_in_sixteen_bit_indices() {
        // a chessboard of tall and short columns has the most walls a tile can have
        let mut g = CellGrid::filled(land(70.0));
        for cz in -1..=CELLS as i32 {
            for cx in -1..=CELLS as i32 {
                g.set(cx, cz, land(if (cx + cz) % 2 == 0 { 120.0 } else { 40.0 }));
            }
        }
        for level in [0usize, 3] {
            let key = TileKey::new(level, 0, 0);
            let b = {
                let cell = key.cell() as f32;
                let mut b = Builder::new();
                for q in 0..4 {
                    emit_quarter(&mut b, &g, level, q, cell, wall_drop(key.cell()));
                }
                b
            };
            assert!(!b.overflowed, "level {} needs {} vertices", level, b.vertices.len());
            assert!(b.vertices.len() < MAX_VERTICES);
        }
    }

    #[test]
    fn faces_are_shaded_by_the_way_they_face() {
        let mut g = CellGrid::filled(Cell::land(70.0, [200, 100, 50], [200, 100, 50]));
        g.set(8, 8, Cell::land(80.0, [200, 100, 50], [200, 100, 50]));
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        let (mut top, mut ns, mut ew) = (false, false, false);
        for i in 0..t.triangle_count() {
            let n = normal(&t, i);
            let c = t.vertices[t.indices[i * 3] as usize].color;
            if n[1] > 0.0 {
                assert_eq!(c, [200, 100, 50, 255]);
                top = true;
            } else if n[2].abs() > 0.0 {
                assert_eq!(c, [164, 82, 41, 255]);
                ns = true;
            } else if n[0].abs() > 0.0 {
                assert_eq!(c, [140, 70, 35, 255]);
                ew = true;
            }
        }
        assert!(top && ns && ew);
    }

    #[test]
    fn every_face_points_away_from_the_ground_it_belongs_to() {
        // counter-clockwise seen from outside: tops face up, walls face the lower neighbour
        let mut g = CellGrid::filled(land(70.0));
        g.set(12, 12, land(90.0));
        let t = build_tile_mesh(TileKey::new(0, 0, 0), &g);
        let (cx, cz) = (12.5 * 8.0, 12.5 * 8.0);
        let mut checked = 0;
        for i in 0..t.triangle_count() {
            let n = normal(&t, i);
            let p: Vec<[f32; 3]> = (0..3).map(|k| t.vertices[t.indices[i * 3 + k] as usize].pos).collect();
            let centre = [(p[0][0] + p[1][0] + p[2][0]) / 3.0, (p[0][1] + p[1][1] + p[2][1]) / 3.0, (p[0][2] + p[1][2] + p[2][2]) / 3.0];
            if n[1].abs() > 1e-3 {
                assert!(n[1] > 0.0, "a top faces down");
            } else if (centre[0] - cx).abs() <= 4.01 && (centre[2] - cz).abs() <= 4.01 && centre[1] > 70.0 {
                // a wall of the raised cell: its normal points away from the cell's centre
                let (dx, dz) = (centre[0] - cx, centre[2] - cz);
                assert!(n[0] * dx + n[2] * dz > 0.0, "wall triangle {} faces inwards", i);
                checked += 1;
            }
        }
        assert_eq!(checked, 8, "two triangles for each of the four walls of the raised cell");
    }

    #[test]
    fn the_tops_of_land_cover_the_tile_exactly_once() {
        let mut g = CellGrid::filled(land(70.0));
        for cz in 0..CELLS as i32 {
            for cx in 0..CELLS as i32 {
                g.set(cx, cz, land(60.0 + ((cx * 3 + cz * 5) % 9) as f32));
            }
        }
        let t = build_tile_mesh(TileKey::new(2, 0, 0), &g);
        let side = (CELLS as f32) * 32.0;
        let tops: f32 = (0..t.triangle_count()).filter(|&i| normal(&t, i)[1] > 0.0).map(|i| area(&t, i)).sum();
        assert!((tops - side * side).abs() < 1.0, "{} vs {}", tops, side * side);
    }

    #[test]
    fn the_flat_stand_in_is_a_complete_tile() {
        let t = FarTileData::flat(TileKey::new(4, -1, 2), 64.0);
        assert!(t.triangle_count() >= CELLS * CELLS * 2);
        assert!(t.max_y == 64.0 && t.min_y < 64.0);
        assert!(t.bytes() > 0);
    }

    #[test]
    fn the_drop_grows_with_the_cell_up_to_a_limit() {
        assert_eq!(wall_drop(8), 32.0);
        assert_eq!(wall_drop(16), 64.0);
        assert_eq!(wall_drop(32), 128.0);
        assert_eq!(wall_drop(64), 256.0);
        assert_eq!(wall_drop(256), 256.0);
    }
}
