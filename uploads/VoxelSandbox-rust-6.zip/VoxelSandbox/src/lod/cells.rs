//! The cells of a far-terrain tile before they are turned into triangles.
//!
//! Far terrain is built like the block world, only with bigger blocks: every cell of a tile is a flat-topped column
//! with one height and one colour. The grid also holds a one-cell ring around the tile, so that the walls along the
//! tile's edge know how far down the next tile's column starts.

use super::tiles::CELLS;

/// Cells along one side of a grid: the tile's own cells plus the ring around them.
pub const GRID: usize = CELLS + 2;

/// One column of far terrain.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Cell {
    /// Height of the column's flat top (blocks, absolute).
    pub top: f32,
    /// Colour of the top, with the cell's own brightness already applied (0..255).
    pub color: [u8; 3],
    /// Colour of the walls, before the shading for the direction they face is applied.
    pub wall: [u8; 3],
    /// Sea. Sea cells never have walls, and neighbouring sea cells of one colour are drawn as one big quad.
    pub water: bool,
}

impl Cell {
    pub fn land(top: f32, color: [u8; 3], wall: [u8; 3]) -> Cell {
        Cell { top, color, wall, water: false }
    }

    pub fn sea(top: f32, color: [u8; 3]) -> Cell {
        Cell { top, color, wall: color, water: true }
    }
}

/// `GRID` x `GRID` cells; cell coordinates run from -1 to `CELLS` (inclusive), 0..CELLS being the tile itself.
pub struct CellGrid {
    cells: Vec<Cell>,
}

#[inline]
fn slot(cx: i32, cz: i32) -> usize {
    debug_assert!(cx >= -1 && cz >= -1 && cx <= CELLS as i32 && cz <= CELLS as i32);
    ((cz + 1) as usize) * GRID + (cx + 1) as usize
}

impl CellGrid {
    pub fn filled(cell: Cell) -> CellGrid {
        CellGrid { cells: vec![cell; GRID * GRID] }
    }

    #[inline]
    pub fn get(&self, cx: i32, cz: i32) -> &Cell {
        &self.cells[slot(cx, cz)]
    }

    #[inline]
    pub fn set(&mut self, cx: i32, cz: i32, cell: Cell) {
        self.cells[slot(cx, cz)] = cell;
    }
}

/// A brightness variation for one cell, `0.0 ..= 1.0`, that depends only on where the cell is in the world (so the
/// two tiles on either side of a seam agree). It makes neighbouring columns look like separate blocks.
pub fn cell_noise(level: usize, wx: i64, wz: i64) -> f32 {
    let mut h = (wx as i32).wrapping_mul(73856093) ^ (wz as i32).wrapping_mul(19349663) ^ (level as i32 + 1).wrapping_mul(83492791);
    h ^= ((h as u32) >> 15) as i32;
    h = h.wrapping_mul(739982445);
    h ^= ((h as u32) >> 13) as i32;
    ((h as u32 >> 8) & 0xFF) as f32 / 255.0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_ring_is_addressable_and_cells_do_not_overlap() {
        let mut g = CellGrid::filled(Cell::land(10.0, [1, 2, 3], [4, 5, 6]));
        let mut seen = std::collections::HashSet::new();
        for cz in -1..=CELLS as i32 {
            for cx in -1..=CELLS as i32 {
                assert!(seen.insert(slot(cx, cz)), "slot of ({}, {}) is used twice", cx, cz);
            }
        }
        assert_eq!(seen.len(), GRID * GRID);
        g.set(-1, -1, Cell::sea(1.0, [9, 9, 9]));
        g.set(CELLS as i32, CELLS as i32, Cell::sea(2.0, [8, 8, 8]));
        assert_eq!(g.get(-1, -1).top, 1.0);
        assert_eq!(g.get(CELLS as i32, CELLS as i32).top, 2.0);
        assert_eq!(g.get(0, 0).top, 10.0);
    }

    #[test]
    fn cell_noise_is_stable_in_range_and_varies() {
        let mut min = 1.0f32;
        let mut max = 0.0f32;
        for x in -50..50 {
            for z in -50..50 {
                let n = cell_noise(2, x, z);
                assert!((0.0..=1.0).contains(&n));
                assert_eq!(n, cell_noise(2, x, z));
                min = min.min(n);
                max = max.max(n);
            }
        }
        assert!(min < 0.1 && max > 0.9, "{} .. {}", min, max);
        assert_ne!(cell_noise(1, 5, 5), cell_noise(2, 5, 5));
    }
}
