//! Far terrain: the world beyond the block-by-block chunks, drawn as a few dozen tiles of big coloured blocks
//! (flat-topped columns with vertical cliffs, like the real world seen through a very coarse grid) so that a render
//! distance of 1000 chunks (16 kilometres) costs about as much as a small block world.
//!
//! * `tiles` - where the tiles are (a six-level clipmap around the player);
//! * `cells` - the columns of one tile (height, colours) before they become triangles;
//! * `sampler` - fills the columns from the terrain generator;
//! * `mesh` - turns the columns into triangles (tops, cliff walls, merged sea), stored quarter by quarter;
//! * `manager` - decides which tiles are wanted, builds them on background threads, hands them to the renderer.
//!
//! Nothing here uses OpenGL; the drawing is in `render::far`.

pub mod cells;
pub mod manager;
pub mod mesh;
pub mod sampler;
pub mod tiles;

pub use manager::{FarManager, FarStats};
pub use mesh::{draw_runs, FarTileData, FarVertex, FAR_VERTEX_SIZE};
pub use sampler::FarSampler;
pub use tiles::{TileKey, LEVELS};
