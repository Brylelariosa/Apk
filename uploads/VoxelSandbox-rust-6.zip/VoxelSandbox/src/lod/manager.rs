//! Decides which far-terrain tiles should exist around the player, builds them on background threads, and hands
//! the finished ones to the renderer (and tells it which ones to throw away).
//!
//! A quiet frame costs almost nothing: the wanted tiles are only worked out again when the player moves into a
//! different tile of some level (or the view settings change). Everything else is polling a channel.

use std::collections::{HashSet, VecDeque};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::Arc;

use super::mesh::FarTileData;
use super::sampler::FarSampler;
use super::tiles::{levels_needed, quarter_bit, tile_containing, TileKey, KEEP_RADIUS, LEVELS, WINDOW_RADIUS};
use crate::core::clock;
use crate::core::pool::{default_workers, PriorityPool};
use crate::diag::probe::{self, Counter};
use crate::gen::terrain::TerrainGenerator;
use crate::world::config::SEA_LEVEL;

/// Nice value of the far-terrain workers: lower priority than the chunk workers.
const WORKER_NICE: i32 = 12;
/// Finer levels are built first; inside a level, the nearest tile first.
const LEVEL_PRIORITY: i64 = 1_000_000;

struct FarJob {
    key: TileKey,
}

type FarPool = PriorityPool<FarJob, FarTileData>;

/// What the manager is doing, for the debug log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct FarStats {
    /// Tiles handed to the renderer and still alive.
    pub present: u32,
    /// Tiles the current windows ask for.
    pub wanted: u32,
    /// Tiles queued or being built.
    pub building: u32,
    pub levels: u32,
    pub workers: u32,
}

pub struct FarManager {
    pool: FarPool,
    /// Tiles the renderer has (they take part in the hole masks).
    present: HashSet<TileKey>,
    /// Tiles asked for and not yet handed over.
    requested: HashSet<TileKey>,
    /// Built, waiting for the renderer to take them.
    finished: VecDeque<FarTileData>,
    removed: Vec<TileKey>,
    centers: [Option<(i32, i32)>; LEVELS],
    levels: usize,
    view: f32,
    wanted: u32,
}

fn build(sampler: &FarSampler, key: TileKey) -> FarTileData {
    let start = if probe::enabled() { clock::now_ns() } else { 0 };
    let tile = match catch_unwind(AssertUnwindSafe(|| sampler.build_tile(key))) {
        Ok(t) => t,
        Err(_) => {
            crate::loge!("far terrain panicked at {:?}", key);
            FarTileData::flat(key, SEA_LEVEL as f32)
        }
    };
    if start != 0 {
        probe::count(Counter::FarJobs, 1);
        probe::count(Counter::FarNs, clock::now_ns().saturating_sub(start));
    }
    tile
}

impl FarManager {
    pub fn new(gen: Arc<TerrainGenerator>) -> FarManager {
        FarManager::with_workers(gen, default_workers().min(2))
    }

    pub fn with_workers(gen: Arc<TerrainGenerator>, workers: usize) -> FarManager {
        let sampler = Arc::new(FarSampler::new(gen));
        let pool = PriorityPool::new("vs-far", workers, WORKER_NICE, move || {
            let sampler = sampler.clone();
            move |job: FarJob| build(&sampler, job.key)
        });
        FarManager {
            pool,
            present: HashSet::new(),
            requested: HashSet::new(),
            finished: VecDeque::new(),
            removed: Vec::new(),
            centers: [None; LEVELS],
            levels: 0,
            view: 0.0,
            wanted: 0,
        }
    }

    pub fn stats(&self) -> FarStats {
        FarStats {
            present: self.present.len() as u32,
            wanted: self.wanted,
            building: self.requested.len() as u32,
            levels: self.levels as u32,
            workers: self.pool.threads() as u32,
        }
    }

    /// True while far terrain is switched on.
    pub fn active(&self) -> bool {
        self.levels > 0
    }

    /// Tiles the renderer has (or is about to get).
    pub fn present(&self, key: TileKey) -> bool {
        self.present.contains(&key)
    }

    /// Which quarters of `key` are covered by finer tiles that exist (bit set = leave that quarter out).
    pub fn hole_mask(&self, key: TileKey) -> u8 {
        if key.level() == 0 {
            return 0;
        }
        let mut mask = 0u8;
        for qz in 0..2 {
            for qx in 0..2 {
                if self.present.contains(&key.child(qx, qz)) {
                    mask |= quarter_bit(qx, qz);
                }
            }
        }
        mask
    }

    /// Should a tile that exists stay? (Wider than what is asked for, so tiles do not flicker at the window edge.)
    fn keeps(&self, key: TileKey, x: f64, z: f64) -> bool {
        let level = key.level();
        if level >= self.levels {
            return false;
        }
        let (cx, cz) = match self.centers[level] {
            Some(c) => c,
            None => return false,
        };
        (key.tx - cx).abs() <= KEEP_RADIUS
            && (key.tz - cz).abs() <= KEEP_RADIUS
            && key.min_distance(x, z) <= self.view as f64 + 0.5 * key.size() as f64
    }

    /// Call once per frame with the player's position. `view_blocks` is the render distance in blocks and
    /// `enabled` is false when the render distance fits inside the block world (no far terrain needed).
    pub fn update(&mut self, x: f64, z: f64, view_blocks: f32, enabled: bool) {
        let levels = if enabled { levels_needed(view_blocks) } else { 0 };
        self.collect(x, z);
        if levels == 0 {
            if self.levels != 0 || !self.present.is_empty() || !self.requested.is_empty() {
                self.clear();
            }
            return;
        }
        let mut changed = levels != self.levels || (view_blocks - self.view).abs() > 0.5;
        for level in 0..levels {
            let center = tile_containing(level, x, z);
            if self.centers[level] != Some(center) {
                self.centers[level] = Some(center);
                changed = true;
            }
        }
        if !changed {
            return;
        }
        self.levels = levels;
        self.view = view_blocks;
        for level in levels..LEVELS {
            self.centers[level] = None;
        }
        self.rescan(x, z);
    }

    /// Takes the tiles the workers have finished.
    fn collect(&mut self, x: f64, z: f64) {
        while let Some(tile) = self.pool.try_recv() {
            let key = tile.key;
            if self.present.contains(&key) || self.finished.iter().any(|t| t.key == key) {
                continue; // a duplicate from a request made before a reset
            }
            if self.keeps(key, x, z) {
                self.finished.push_back(tile);
            } else {
                self.requested.remove(&key);
            }
        }
    }

    /// Drops the tiles nobody needs any more and asks for the ones that are missing.
    fn rescan(&mut self, x: f64, z: f64) {
        let gone: Vec<TileKey> = self.present.iter().copied().filter(|k| !self.keeps(*k, x, z)).collect();
        for key in gone {
            self.present.remove(&key);
            self.removed.push(key);
        }
        let stale: Vec<TileKey> = self.finished.iter().map(|t| t.key).filter(|k| !self.keeps(*k, x, z)).collect();
        if !stale.is_empty() {
            self.finished.retain(|t| !stale.contains(&t.key));
            for k in stale {
                self.requested.remove(&k);
            }
        }
        let mut wanted = 0u32;
        for level in 0..self.levels {
            let (cx, cz) = match self.centers[level] {
                Some(c) => c,
                None => continue,
            };
            for tz in (cz - WINDOW_RADIUS)..=(cz + WINDOW_RADIUS) {
                for tx in (cx - WINDOW_RADIUS)..=(cx + WINDOW_RADIUS) {
                    let key = TileKey::new(level, tx, tz);
                    let distance = key.min_distance(x, z);
                    if distance > self.view as f64 {
                        continue; // entirely beyond the fog
                    }
                    wanted += 1;
                    if self.present.contains(&key) || self.requested.contains(&key) {
                        continue;
                    }
                    let priority = level as i64 * LEVEL_PRIORITY + (distance / 8.0) as i64;
                    self.pool.submit(priority, FarJob { key });
                    self.requested.insert(key);
                }
            }
        }
        self.wanted = wanted;
    }

    /// Up to `max` finished tiles for the renderer to upload (they now count as present).
    pub fn take_ready(&mut self, max: usize) -> Vec<FarTileData> {
        let mut out = Vec::new();
        while out.len() < max {
            match self.finished.pop_front() {
                Some(tile) => {
                    self.requested.remove(&tile.key);
                    self.present.insert(tile.key);
                    out.push(tile);
                }
                None => break,
            }
        }
        out
    }

    /// Tiles the renderer should free.
    pub fn take_removed(&mut self) -> Vec<TileKey> {
        std::mem::take(&mut self.removed)
    }

    /// Forgets everything (far terrain switched off, or the GPU lost its buffers).
    pub fn clear(&mut self) {
        self.removed.extend(self.present.drain());
        self.finished.clear();
        self.requested.clear();
        self.pool.clear_queue();
        self.centers = [None; LEVELS];
        self.levels = 0;
        self.view = 0.0;
        self.wanted = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    fn manager() -> FarManager {
        FarManager::with_workers(Arc::new(TerrainGenerator::new(11)), 2)
    }

    /// Runs `update` and uploads everything until nothing is being built any more.
    fn settle(m: &mut FarManager, x: f64, z: f64, view: f32) -> Vec<FarTileData> {
        let mut got = Vec::new();
        let start = Instant::now();
        loop {
            m.update(x, z, view, true);
            got.extend(m.take_ready(8));
            if m.stats().building == 0 && m.finished.is_empty() {
                return got;
            }
            assert!(start.elapsed() < Duration::from_secs(120), "far tiles did not finish: {:?}", m.stats());
            std::thread::sleep(Duration::from_millis(2));
        }
    }

    #[test]
    fn the_windows_around_the_player_get_built() {
        let mut m = manager();
        let got = settle(&mut m, 100.0, 100.0, 1500.0);
        let s = m.stats();
        assert_eq!(s.levels as usize, levels_needed(1500.0));
        assert_eq!(s.present as usize, got.len());
        assert_eq!(s.present, s.wanted);
        assert!(s.present >= 25, "{:?}", s);
        // every tile is within the view and inside its level's window
        for t in got.iter() {
            assert!(t.key.min_distance(100.0, 100.0) <= 1500.0);
            let (cx, cz) = tile_containing(t.key.level(), 100.0, 100.0);
            assert!((t.key.tx - cx).abs() <= WINDOW_RADIUS && (t.key.tz - cz).abs() <= WINDOW_RADIUS);
        }
        // the tile the player stands in exists at every level
        for level in 0..s.levels as usize {
            let (cx, cz) = tile_containing(level, 100.0, 100.0);
            assert!(m.present(TileKey::new(level, cx, cz)), "level {}", level);
        }
    }

    #[test]
    fn a_quiet_frame_asks_for_nothing_new() {
        let mut m = manager();
        settle(&mut m, 0.0, 0.0, 800.0);
        let before = m.stats();
        for _ in 0..100 {
            m.update(5.0, 7.0, 800.0, true);
        }
        assert_eq!(m.stats(), before);
        assert!(m.take_ready(100).is_empty());
        assert!(m.take_removed().is_empty());
    }

    #[test]
    fn walking_into_the_next_tile_builds_only_the_new_row_and_keeps_the_old_ones() {
        let mut m = manager();
        settle(&mut m, 10.0, 10.0, 400.0); // one level
        assert_eq!(m.stats().levels, 1);
        let first = m.stats().present;
        let got = settle(&mut m, 10.0 + 256.0, 10.0, 400.0);
        assert!(!got.is_empty() && got.len() <= 5, "{} new tiles", got.len());
        assert!(got.iter().all(|t| t.key.tx == 3 || t.key.tx == 2 || t.key.tx == 1), "{:?}", got.iter().map(|t| t.key).collect::<Vec<_>>());
        assert!(m.stats().present >= first - 5);
    }

    #[test]
    fn tiles_left_far_behind_are_reported_for_removal() {
        let mut m = manager();
        settle(&mut m, 0.0, 0.0, 400.0);
        let old: Vec<TileKey> = m.present.iter().copied().collect();
        settle(&mut m, 5000.0, 0.0, 400.0);
        let removed = m.take_removed();
        for k in old.iter() {
            assert!(removed.contains(k), "{:?} was not removed", k);
            assert!(!m.present(*k));
        }
    }

    #[test]
    fn a_tile_only_leaves_the_far_edge_after_a_margin() {
        let mut m = manager();
        settle(&mut m, 128.0, 128.0, 700.0);
        let edge = TileKey::new(0, -2, 0);
        assert!(m.present(edge));
        // one tile east: the window moves, but the tile two to the west stays for the hysteresis
        settle(&mut m, 128.0 + 256.0, 128.0, 700.0);
        assert!(m.present(edge), "dropped too early");
        // two tiles further east it is more than KEEP_RADIUS away
        settle(&mut m, 128.0 + 256.0 * 4.0, 128.0, 700.0);
        assert!(!m.present(edge));
    }

    #[test]
    fn holes_follow_the_finer_tiles_that_exist() {
        let mut m = manager();
        settle(&mut m, 0.0, 0.0, 1200.0);
        assert!(m.stats().levels >= 2);
        // the level-1 tile containing the origin is made of four level-0 tiles; all four exist
        let coarse = TileKey::new(1, 0, 0);
        assert_eq!(m.hole_mask(coarse), 0b1111);
        // forget one of the children and that quarter is drawn again
        let child = coarse.child(1, 0);
        m.present.remove(&child);
        assert_eq!(m.hole_mask(coarse), 0b1111 & !quarter_bit(1, 0));
        // level 0 never has holes
        assert_eq!(m.hole_mask(TileKey::new(0, 0, 0)), 0);
    }

    #[test]
    fn switching_far_terrain_off_removes_everything_and_it_can_come_back() {
        let mut m = manager();
        settle(&mut m, 0.0, 0.0, 500.0);
        let n = m.stats().present;
        assert!(n > 0);
        m.update(0.0, 0.0, 500.0, false);
        assert_eq!(m.stats().present, 0);
        assert!(!m.active());
        assert_eq!(m.take_removed().len() as u32, n);
        settle(&mut m, 0.0, 0.0, 500.0);
        assert_eq!(m.stats().present, n);
    }

    #[test]
    fn a_smaller_view_gives_up_the_outer_levels() {
        let mut m = manager();
        settle(&mut m, 0.0, 0.0, 5000.0);
        let big = m.stats();
        settle(&mut m, 0.0, 0.0, 500.0);
        let small = m.stats();
        assert!(small.levels < big.levels);
        assert!(small.present < big.present);
        assert!(m.take_removed().iter().any(|k| k.level() >= 2));
    }

    #[test]
    fn the_nearest_finest_tiles_come_first() {
        // one worker, so the order they finish in is the order they were asked for in
        let mut m = FarManager::with_workers(Arc::new(TerrainGenerator::new(12)), 1);
        let got = settle(&mut m, 0.0, 0.0, 2000.0);
        let levels: Vec<usize> = got.iter().map(|t| t.key.level()).collect();
        let mut sorted = levels.clone();
        sorted.sort();
        assert_eq!(levels, sorted, "finer levels must be built before coarser ones");
    }
}
