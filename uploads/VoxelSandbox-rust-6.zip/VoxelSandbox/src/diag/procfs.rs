//! What the operating system can tell us about our own process: CPU time, memory, threads, free memory and,
//! when the phone allows it, a temperature. Read only by the log writer thread, never by the game thread.
//! Every reader tolerates missing files (newer Android versions hide many of them).

use std::fs;

use super::report::ProcStats;

/// Clock ticks per second in `/proc/<pid>/stat` (always 100 on Android and desktop Linux).
const TICKS_PER_SECOND: f64 = 100.0;

/// utime + stime (in ticks) from the text of `/proc/self/stat`.
pub fn parse_stat_ticks(text: &str) -> Option<u64> {
    // the command name is in parentheses and may itself contain spaces or parentheses
    let rest = &text[text.rfind(')')? + 1..];
    let fields: Vec<&str> = rest.split_whitespace().collect();
    // after the name: state(0) ppid(1) ... utime(11) stime(12)
    let utime: u64 = fields.get(11)?.parse().ok()?;
    let stime: u64 = fields.get(12)?.parse().ok()?;
    Some(utime + stime)
}

/// Resident set size in MB from the text of `/proc/self/statm`.
pub fn parse_statm_rss_mb(text: &str) -> Option<f32> {
    let pages: f64 = text.split_whitespace().nth(1)?.parse().ok()?;
    Some((pages * 4096.0 / (1024.0 * 1024.0)) as f32)
}

pub fn parse_threads(text: &str) -> Option<u32> {
    for line in text.lines() {
        if let Some(v) = line.strip_prefix("Threads:") {
            return v.trim().parse().ok();
        }
    }
    None
}

pub fn parse_mem_available_mb(text: &str) -> Option<f32> {
    for line in text.lines() {
        if let Some(v) = line.strip_prefix("MemAvailable:") {
            let kb: f64 = v.trim().trim_end_matches("kB").trim().parse().ok()?;
            return Some((kb / 1024.0) as f32);
        }
    }
    None
}

/// A temperature in °C from a thermal file: values above 1000 are milli-degrees, above 100 tenths of a degree.
pub fn parse_temperature_c(text: &str) -> Option<f32> {
    let raw: f64 = text.trim().parse().ok()?;
    let c = if raw.abs() >= 1000.0 {
        raw / 1000.0
    } else if raw.abs() >= 100.0 {
        raw / 10.0
    } else {
        raw
    };
    if c > -40.0 && c < 150.0 {
        Some(c as f32)
    } else {
        None
    }
}

/// Reads the numbers once per log line. The slow-changing ones are refreshed only every few calls.
pub struct ProcReader {
    last_ticks: Option<u64>,
    calls: u32,
    threads: u32,
    mem_available_mb: f32,
    temp_c: f32,
    cpu_count: u32,
}

impl ProcReader {
    pub fn new() -> ProcReader {
        ProcReader {
            last_ticks: None,
            calls: 0,
            threads: 0,
            mem_available_mb: 0.0,
            temp_c: f32::NAN,
            cpu_count: crate::core::sched::cpu_count() as u32,
        }
    }

    /// `wall_ns` is the length of the window the previous call's ticks are being compared over.
    pub fn read(&mut self, wall_ns: u64) -> ProcStats {
        let mut out = ProcStats { temp_c: f32::NAN, cpu_count: self.cpu_count, ..ProcStats::default() };
        if let Some(ticks) = fs::read_to_string("/proc/self/stat").ok().and_then(|t| parse_stat_ticks(&t)) {
            if let Some(prev) = self.last_ticks {
                let dticks = ticks.saturating_sub(prev) as f64;
                let secs = (wall_ns.max(1) as f64) / 1e9;
                out.process_cpu_percent = (dticks / TICKS_PER_SECOND / secs * 100.0) as f32;
            }
            self.last_ticks = Some(ticks);
        }
        if let Some(mb) = fs::read_to_string("/proc/self/statm").ok().and_then(|t| parse_statm_rss_mb(&t)) {
            out.rss_mb = mb;
        }
        if self.calls % 5 == 0 {
            if let Some(n) = fs::read_to_string("/proc/self/status").ok().and_then(|t| parse_threads(&t)) {
                self.threads = n;
            }
            if let Some(mb) = fs::read_to_string("/proc/meminfo").ok().and_then(|t| parse_mem_available_mb(&t)) {
                self.mem_available_mb = mb;
            }
            let candidates = ["/sys/class/thermal/thermal_zone0/temp", "/sys/class/power_supply/battery/temp"];
            for path in candidates.iter() {
                if let Some(c) = fs::read_to_string(path).ok().and_then(|t| parse_temperature_c(&t)) {
                    self.temp_c = c;
                    break;
                }
            }
        }
        self.calls = self.calls.wrapping_add(1);
        out.threads = self.threads;
        out.mem_available_mb = self.mem_available_mb;
        out.temp_c = self.temp_c;
        out
    }
}

impl Default for ProcReader {
    fn default() -> ProcReader {
        ProcReader::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stat_line_with_awkward_command_name() {
        let line = "1234 (Voxel (Sandbox) x) S 1 1234 1234 0 -1 4194560 100 0 0 0 250 70 0 0 20 0 24 0 5000 1000000 5000 18446744073709551615";
        assert_eq!(parse_stat_ticks(line), Some(320));
        assert_eq!(parse_stat_ticks("garbage"), None);
    }

    #[test]
    fn other_proc_files() {
        assert!((parse_statm_rss_mb("100000 51200 300 10 0 20000 0").unwrap() - 200.0).abs() < 0.01);
        assert_eq!(parse_threads("Name:\tfoo\nThreads:\t23\nVmRSS: 1 kB\n"), Some(23));
        assert!((parse_mem_available_mb("MemTotal: 1 kB\nMemAvailable:   2097152 kB\n").unwrap() - 2048.0).abs() < 0.01);
        assert_eq!(parse_temperature_c("41000\n"), Some(41.0));
        assert_eq!(parse_temperature_c("385"), Some(38.5));
        assert_eq!(parse_temperature_c("37"), Some(37.0));
        assert_eq!(parse_temperature_c("-999999"), None);
        assert_eq!(parse_temperature_c("n/a"), None);
    }

    #[cfg(any(target_os = "linux", target_os = "android"))]
    #[test]
    fn reading_our_own_process_works_and_measures_cpu() {
        let mut r = ProcReader::new();
        let first = r.read(1_000_000_000);
        assert!(first.rss_mb > 1.0);
        assert!(first.threads >= 1);
        // burn some CPU so the tick counter moves
        let start = std::time::Instant::now();
        let mut x = 1u64;
        while start.elapsed().as_millis() < 120 {
            x = x.wrapping_mul(6364136223846793005).wrapping_add(1);
        }
        assert!(x != 0);
        let second = r.read(120_000_000);
        assert!(second.process_cpu_percent >= 0.0);
    }
}
