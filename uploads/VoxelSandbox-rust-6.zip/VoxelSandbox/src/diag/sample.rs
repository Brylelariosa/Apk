//! Plain data passed from the game thread to the log writer. No formatting happens on the game thread:
//! it fills one of these structs and hands it over, and the background thread turns it into text.

use super::probe::{COUNTER_COUNT, STAGE_COUNT};

/// Upper bounds (ms) of the frame-time histogram buckets; the last bucket is open-ended.
pub const HIST_BOUNDS_MS: [f32; 9] = [8.5, 12.0, 17.5, 21.0, 25.0, 34.0, 50.0, 100.0, f32::INFINITY];
pub const HIST_BUCKETS: usize = 9;

pub fn hist_bucket(ms: f32) -> usize {
    for (i, b) in HIST_BOUNDS_MS.iter().enumerate() {
        if ms <= *b {
            return i;
        }
    }
    HIST_BUCKETS - 1
}

/// Which part of the app was on screen.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum ScreenKind {
    Menu = 0,
    Loading,
    Playing,
    Paused,
    Settings,
    Inventory,
    Other,
}

impl ScreenKind {
    pub fn name(self) -> &'static str {
        match self {
            ScreenKind::Menu => "MENU",
            ScreenKind::Loading => "LOADING",
            ScreenKind::Playing => "PLAYING",
            ScreenKind::Paused => "PAUSED",
            ScreenKind::Settings => "SETTINGS",
            ScreenKind::Inventory => "INVENTORY",
            ScreenKind::Other => "OTHER",
        }
    }
}

/// A snapshot of what the engine is holding and doing (taken once per second).
#[derive(Clone, Copy, Debug)]
pub struct Gauges {
    pub screen: ScreenKind,
    pub in_world: bool,
    pub chunk_x: i32,
    pub chunk_z: i32,
    pub height: f32,
    pub flying: bool,
    pub underwater: bool,
    pub chunks_loaded: u32,
    pub chunks_meshed: u32,
    pub gen_queue: u32,
    pub mesh_queue: u32,
    pub jobs_in_flight: u32,
    pub far_tiles_ready: u32,
    pub far_tiles_wanted: u32,
    pub gpu_chunks: u32,
    pub gpu_tiles: u32,
    pub render_distance: i32,
    pub detail_radius: i32,
    pub resolution_percent: i32,
    pub view_w: u32,
    pub view_h: u32,
    pub workers: u32,
    /// What the GPU itself needed for a recent frame in milliseconds; negative when the driver cannot tell.
    pub gpu_ms: f32,
    /// Triangles drawn by the last frame's passes: far terrain, solid blocks, leaves, plants, water.
    pub pass_tris: [u32; PASS_NAMES.len()],
    /// Draw calls of the same passes.
    pub pass_calls: [u32; PASS_NAMES.len()],
}

/// The draw passes of a frame, in the order of `Gauges::pass_tris`.
pub const PASS_NAMES: [&str; 5] = ["far", "solid", "leaves", "plants", "water"];

impl Default for Gauges {
    fn default() -> Gauges {
        Gauges {
            screen: ScreenKind::Menu,
            in_world: false,
            chunk_x: 0,
            chunk_z: 0,
            height: 0.0,
            flying: false,
            underwater: false,
            chunks_loaded: 0,
            chunks_meshed: 0,
            gen_queue: 0,
            mesh_queue: 0,
            jobs_in_flight: 0,
            far_tiles_ready: 0,
            far_tiles_wanted: 0,
            gpu_chunks: 0,
            gpu_tiles: 0,
            render_distance: 0,
            detail_radius: 0,
            resolution_percent: 100,
            view_w: 0,
            view_h: 0,
            workers: 0,
            gpu_ms: -1.0,
            pass_tris: [0; PASS_NAMES.len()],
            pass_calls: [0; PASS_NAMES.len()],
        }
    }
}

/// One second of the game, summarised.
#[derive(Clone, Debug)]
pub struct SecondSample {
    /// When the second ended (milliseconds since the Unix epoch).
    pub unix_ms: u64,
    /// How long the window really was.
    pub wall_ns: u64,
    pub frames: u32,
    pub interval_sum_ns: u64,
    pub interval_max_ns: u64,
    pub hist: [u16; HIST_BUCKETS],
    pub stage_sum_ns: [u64; STAGE_COUNT],
    pub stage_max_ns: [u64; STAGE_COUNT],
    /// The stage times of the slowest frame in the window.
    pub worst_stages_ns: [u64; STAGE_COUNT],
    pub hitches: u16,
    pub counters: [u64; COUNTER_COUNT],
    /// CPU time the game thread used during the window.
    pub main_cpu_ns: u64,
    pub gauges: Gauges,
}

impl SecondSample {
    pub fn empty() -> SecondSample {
        SecondSample {
            unix_ms: 0,
            wall_ns: 1_000_000_000,
            frames: 0,
            interval_sum_ns: 0,
            interval_max_ns: 0,
            hist: [0; HIST_BUCKETS],
            stage_sum_ns: [0; STAGE_COUNT],
            stage_max_ns: [0; STAGE_COUNT],
            worst_stages_ns: [0; STAGE_COUNT],
            hitches: 0,
            counters: [0; COUNTER_COUNT],
            main_cpu_ns: 0,
            gauges: Gauges::default(),
        }
    }

    pub fn fps(&self) -> f32 {
        if self.wall_ns == 0 {
            return 0.0;
        }
        self.frames as f32 * 1e9 / self.wall_ns as f32
    }

    /// Average frame interval in ms.
    pub fn frame_ms(&self) -> f32 {
        if self.frames == 0 {
            return 0.0;
        }
        self.interval_sum_ns as f32 / self.frames as f32 / 1e6
    }

    pub fn max_ms(&self) -> f32 {
        self.interval_max_ns as f32 / 1e6
    }

    /// Average time of a stage per frame, in ms.
    pub fn stage_ms(&self, stage: super::probe::Stage) -> f32 {
        if self.frames == 0 {
            return 0.0;
        }
        self.stage_sum_ns[stage as usize] as f32 / self.frames as f32 / 1e6
    }

    /// Frame-time percentile in ms, read from the histogram (the upper edge of the bucket that holds it).
    pub fn percentile_ms(&self, p: f32) -> f32 {
        let total: u32 = self.hist.iter().map(|&c| c as u32).sum();
        if total == 0 {
            return 0.0;
        }
        let want = ((total as f32 * p).ceil() as u32).max(1);
        let mut seen = 0;
        for (i, &c) in self.hist.iter().enumerate() {
            seen += c as u32;
            if seen >= want {
                let b = HIST_BOUNDS_MS[i];
                return if b.is_finite() { b } else { self.max_ms() };
            }
        }
        self.max_ms()
    }

    /// Share of the window the game thread was actually running on a CPU core (0..100+).
    pub fn main_cpu_percent(&self) -> f32 {
        if self.wall_ns == 0 {
            return 0.0;
        }
        self.main_cpu_ns as f32 * 100.0 / self.wall_ns as f32
    }

    pub fn counter(&self, c: super::probe::Counter) -> u64 {
        self.counters[c as usize]
    }
}

/// One frame that took far too long.
#[derive(Clone, Debug)]
pub struct HitchSample {
    pub unix_ms: u64,
    pub interval_ns: u64,
    pub stages_ns: [u64; STAGE_COUNT],
    pub screen: ScreenKind,
    pub gen_queue: u32,
    pub mesh_queue: u32,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::diag::probe::Stage;

    #[test]
    fn histogram_buckets_cover_everything() {
        assert_eq!(hist_bucket(0.0), 0);
        assert_eq!(hist_bucket(8.5), 0);
        assert_eq!(hist_bucket(16.7), 2);
        assert_eq!(hist_bucket(33.0), 5);
        assert_eq!(hist_bucket(99.0), 7);
        assert_eq!(hist_bucket(5000.0), HIST_BUCKETS - 1);
    }

    #[test]
    fn percentiles_come_from_the_histogram() {
        let mut s = SecondSample::empty();
        s.frames = 60;
        s.hist[2] = 57; // ~16.7 ms
        s.hist[7] = 3; // slow frames
        s.interval_max_ns = 90_000_000;
        assert_eq!(s.percentile_ms(0.5), 17.5);
        assert_eq!(s.percentile_ms(0.95), 17.5);
        assert_eq!(s.percentile_ms(0.99), 100.0);
    }

    #[test]
    fn derived_numbers_handle_empty_windows() {
        let s = SecondSample::empty();
        assert_eq!(s.fps(), 0.0);
        assert_eq!(s.frame_ms(), 0.0);
        assert_eq!(s.stage_ms(Stage::Render), 0.0);
        assert_eq!(s.percentile_ms(0.95), 0.0);
    }

    #[test]
    fn averages_are_per_frame() {
        let mut s = SecondSample::empty();
        s.frames = 50;
        s.interval_sum_ns = 1_000_000_000;
        s.stage_sum_ns[Stage::Render as usize] = 250_000_000;
        s.main_cpu_ns = 400_000_000;
        assert!((s.fps() - 50.0).abs() < 0.01);
        assert!((s.frame_ms() - 20.0).abs() < 0.01);
        assert!((s.stage_ms(Stage::Render) - 5.0).abs() < 0.01);
        assert!((s.main_cpu_percent() - 40.0).abs() < 0.01);
    }
}
