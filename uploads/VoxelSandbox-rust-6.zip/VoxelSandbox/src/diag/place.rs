//! Where the debug log file lives and what it is called. Plain logic, so it is tested on a normal computer;
//! the Android-only code (`platform::storage`) does the actual creating of the file.

use std::path::{Path, PathBuf};

/// "VoxelSandbox-log_2026-11-07_1.20pm.txt" - the start time is in the name so several runs do not mix.
pub fn log_file_name(stamp: &str) -> String {
    let clean: String = stamp.chars().map(|c| if c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == '_' { c } else { '-' }).collect();
    format!("VoxelSandbox-log_{}.txt", clean)
}

/// The phone's shared storage root, worked out from an app folder such as
/// `/storage/emulated/0/Android/data/<package>/files` (other users have another number than 0).
pub fn shared_storage_root(app_dirs: &[PathBuf]) -> PathBuf {
    for d in app_dirs {
        let text = d.to_string_lossy();
        if let Some(i) = text.find("/Android/") {
            if i > 0 && text.starts_with("/storage/") {
                return PathBuf::from(&text[..i]);
            }
        }
    }
    PathBuf::from("/storage/emulated/0")
}

/// Download folders that can be tried by plain file access (works on older Android, or when the phone allows it).
pub fn download_dir_candidates(app_dirs: &[PathBuf]) -> Vec<PathBuf> {
    let mut out = vec![shared_storage_root(app_dirs).join("Download")];
    let sdcard = PathBuf::from("/sdcard/Download");
    if !out.contains(&sdcard) {
        out.push(sdcard);
    }
    out
}

/// A path as people know it ("Android/data/..."), without the storage prefix.
pub fn friendly_path(p: &Path) -> String {
    let s = p.to_string_lossy().to_string();
    for prefix in ["/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"] {
        if let Some(rest) = s.strip_prefix(prefix) {
            return rest.to_string();
        }
    }
    s
}

/// What the Settings screen shows for a file that is in the Download folder.
pub fn download_description(file_name: &str) -> String {
    format!("DOWNLOAD/{}", file_name)
}

/// What the Settings screen shows for a file that ended up somewhere else, and why.
pub fn fallback_description(path: &Path, problems: &[String]) -> String {
    let mut s = friendly_path(path);
    if !problems.is_empty() {
        s.push_str(" (NOT IN DOWNLOAD: ");
        s.push_str(&problems.join("; "));
        s.push(')');
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_file_name_is_safe_and_carries_the_time() {
        assert_eq!(log_file_name("2026-11-07_1.20pm"), "VoxelSandbox-log_2026-11-07_1.20pm.txt");
        assert_eq!(log_file_name("a/b c:d"), "VoxelSandbox-log_a-b-c-d.txt");
    }

    #[test]
    fn the_storage_root_follows_the_app_folder() {
        let dirs = vec![PathBuf::from("/data/user/0/com.x/files"), PathBuf::from("/storage/emulated/10/Android/data/com.x/files")];
        assert_eq!(shared_storage_root(&dirs), PathBuf::from("/storage/emulated/10"));
        assert_eq!(shared_storage_root(&[]), PathBuf::from("/storage/emulated/0"));
        assert_eq!(download_dir_candidates(&dirs)[0], PathBuf::from("/storage/emulated/10/Download"));
        assert!(download_dir_candidates(&[]).contains(&PathBuf::from("/sdcard/Download")));
    }

    #[test]
    fn paths_are_shown_without_the_storage_prefix() {
        assert_eq!(friendly_path(Path::new("/storage/emulated/0/Android/data/com.x/files/a.txt")), "Android/data/com.x/files/a.txt");
        assert_eq!(friendly_path(Path::new("/data/user/0/com.x/files/a.txt")), "/data/user/0/com.x/files/a.txt");
        let d = fallback_description(Path::new("/storage/emulated/0/Android/data/com.x/files/a.txt"), &["MEDIASTORE: no".to_string()]);
        assert!(d.starts_with("Android/data/com.x/files/a.txt") && d.contains("NOT IN DOWNLOAD: MEDIASTORE: no"), "{}", d);
        assert_eq!(download_description("a.txt"), "DOWNLOAD/a.txt");
    }
}
