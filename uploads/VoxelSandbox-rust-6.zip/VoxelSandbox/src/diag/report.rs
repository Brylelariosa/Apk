//! Turns samples into the text of the log, and decides in plain words what was slowing the game down.
//! Everything here is a pure function (no IO, no clocks), so it is unit-tested on the host and runs only on the
//! background writer thread in the app.

use std::fmt::Write as _;

use super::probe::{Counter, Stage, STAGE_COUNT};
use super::sample::{HitchSample, ScreenKind, SecondSample, PASS_NAMES};
use crate::core::clock::LocalTime;

/// A frame interval above this many milliseconds counts as a hitch worth its own line.
pub const HITCH_MS: f32 = 50.0;

// ------------------------------------------------------------------------------------------------ clock text

fn twelve_hour(hour: u32) -> (u32, &'static str) {
    let suffix = if hour >= 12 { "pm" } else { "am" };
    let h = match hour % 12 {
        0 => 12,
        h => h,
    };
    (h, suffix)
}

/// "1:20:05pm"
pub fn clock_text(t: LocalTime) -> String {
    let (h, s) = twelve_hour(t.hour);
    format!("{}:{:02}:{:02}{}", h, t.min, t.sec, s)
}

/// "1:20pm"
pub fn minute_text(t: LocalTime) -> String {
    let (h, s) = twelve_hour(t.hour);
    format!("{}:{:02}{}", h, t.min, s)
}

/// "2026-11-07"
pub fn date_text(t: LocalTime) -> String {
    format!("{:04}-{:02}-{:02}", t.year, t.month, t.day)
}

/// A file-name friendly stamp such as "2026-11-07_1.20pm".
pub fn file_stamp(t: LocalTime) -> String {
    let (h, s) = twelve_hour(t.hour);
    format!("{}_{}.{:02}{}", date_text(t), h, t.min, s)
}

// ------------------------------------------------------------------------------------------------ verdicts

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    /// Nothing was drawn (paused, or the window was gone).
    Idle,
    Smooth,
    /// Isolated slow frames while the average is fine.
    Hitch,
    /// The game thread was busy with game logic, world streaming or menus.
    Calculation,
    /// The game thread was busy preparing and submitting drawing work.
    RenderCpu,
    /// The game thread was mostly waiting for the GPU or the display.
    Gpu,
    /// The game thread was neither busy nor waiting: it was not getting CPU time.
    Starved,
}

pub const KIND_COUNT: usize = 7;

impl Kind {
    pub fn index(self) -> usize {
        self as usize
    }

    pub fn label(self) -> &'static str {
        match self {
            Kind::Idle => "idle",
            Kind::Smooth => "smooth",
            Kind::Hitch => "HITCHES",
            Kind::Calculation => "LAG: CALCULATION",
            Kind::RenderCpu => "LAG: RENDERING (CPU side)",
            Kind::Gpu => "LAG: GPU/DISPLAY",
            Kind::Starved => "LAG: CPU STARVED",
        }
    }
}

#[derive(Clone, Debug)]
pub struct Verdict {
    pub kind: Kind,
    /// 0 = smooth, 1 = slightly under the target, 2 = clearly lagging.
    pub level: u8,
    /// The part of the frame that cost the most (empty when smooth).
    pub blame: &'static str,
    pub text: String,
}

/// The slowest named part of a frame and its cost in ms. Only "leaf" stages are compared, so nested stages
/// are not counted twice.
pub fn biggest_part(stage_ms: &[f32; STAGE_COUNT]) -> (&'static str, f32, bool) {
    let g = |s: Stage| stage_ms[s as usize];
    let streaming = g(Stage::Streaming);
    let sim = (g(Stage::Engine) - streaming).max(0.0);
    let menus = (g(Stage::Update) - g(Stage::Engine)).max(0.0);
    let render_known = g(Stage::Upload) + g(Stage::Cull) + g(Stage::DrawWorld) + g(Stage::DrawFar) + g(Stage::DrawUi);
    let render_other = (g(Stage::Render) - render_known).max(0.0);
    // (name, ms, is_calculation)
    let parts: [(&'static str, f32, bool); 10] = [
        ("world streaming", streaming, true),
        ("game simulation (physics, interaction)", sim, true),
        ("menus/HUD building", menus, true),
        ("input", g(Stage::Input), true),
        ("mesh upload to GPU", g(Stage::Upload), false),
        ("visibility culling", g(Stage::Cull), false),
        ("world draw calls", g(Stage::DrawWorld), false),
        ("far terrain draw calls", g(Stage::DrawFar), false),
        ("UI drawing", g(Stage::DrawUi), false),
        ("other rendering", render_other, false),
    ];
    let mut best = parts[0];
    for p in parts.iter() {
        if p.1 > best.1 {
            best = *p;
        }
    }
    best
}

fn stage_ms_of(s: &SecondSample) -> [f32; STAGE_COUNT] {
    let mut out = [0.0f32; STAGE_COUNT];
    for (i, o) in out.iter_mut().enumerate() {
        *o = if s.frames == 0 { 0.0 } else { s.stage_sum_ns[i] as f32 / s.frames as f32 / 1e6 };
    }
    out
}

/// Decides what held back this second. `target_hz` is the display's refresh rate (60 unless the game has
/// been seen running faster).
pub fn judge(s: &SecondSample, target_hz: f32) -> Verdict {
    let target_ms = 1000.0 / target_hz.max(20.0);
    if s.frames == 0 {
        return Verdict { kind: Kind::Idle, level: 0, blame: "", text: "no frames".to_string() };
    }
    let frame = s.frame_ms();
    let ratio = frame / target_ms;
    let st = stage_ms_of(s);
    let swap = st[Stage::Swap as usize];
    let busy = st[Stage::Input as usize] + st[Stage::Update as usize] + st[Stage::Render as usize];
    let cpu = s.main_cpu_percent();

    if ratio <= 1.15 {
        if s.max_ms() > HITCH_MS.max(target_ms * 3.0) && s.hitches > 0 {
            let mut worst = [0.0f32; STAGE_COUNT];
            for (i, w) in worst.iter_mut().enumerate() {
                *w = s.worst_stages_ns[i] as f32 / 1e6;
            }
            let (name, ms, _) = biggest_part(&worst);
            let blame = if ms < s.max_ms() * 0.4 { "waiting for the GPU/display or other threads" } else { name };
            return Verdict {
                kind: Kind::Hitch,
                level: 1,
                blame,
                text: format!(
                    "{} slow frame(s), worst {:.0} ms; that frame spent {:.0} ms in {}",
                    s.hitches,
                    s.max_ms(),
                    ms,
                    blame
                ),
            };
        }
        return Verdict { kind: Kind::Smooth, level: 0, blame: "", text: "smooth".to_string() };
    }

    let level = if ratio > 1.45 { 2 } else { 1 };
    let (name, ms, is_calc) = biggest_part(&st);

    if busy >= 0.75 * frame {
        if cpu >= 60.0 {
            let kind = if is_calc { Kind::Calculation } else { Kind::RenderCpu };
            return Verdict {
                kind,
                level,
                blame: name,
                text: format!(
                    "game thread busy {:.1} of {:.1} ms per frame; biggest part: {} {:.1} ms",
                    busy, frame, name, ms
                ),
            };
        }
        return Verdict {
            kind: Kind::Gpu,
            level,
            blame: "blocked inside graphics calls",
            text: format!(
                "game thread spends {:.1} of {:.1} ms inside graphics calls but only {:.0}% of it on the CPU: the GPU is the limit",
                busy, frame, cpu
            ),
        };
    }
    if swap >= 0.30 * frame {
        return Verdict {
            kind: Kind::Gpu,
            level,
            blame: "waiting for the GPU/display",
            text: format!(
                "game thread idle-waits {:.1} of {:.1} ms per frame for the screen/GPU (CPU work is only {:.1} ms)",
                swap, frame, busy
            ),
        };
    }
    Verdict {
        kind: Kind::Starved,
        level,
        blame: "no CPU time",
        text: format!(
            "game thread ran only {:.0}% of the time and is not waiting on the GPU: other threads or CPU throttling are taking its time",
            cpu
        ),
    }
}

/// The display rate the game is probably aiming for, from the best frame rate seen so far.
pub fn target_hz_from_best(best_fps: f32) -> f32 {
    if best_fps > 100.0 {
        120.0
    } else if best_fps > 80.0 {
        90.0
    } else if best_fps > 66.0 {
        72.0
    } else {
        60.0
    }
}

// ------------------------------------------------------------------------------------------------ process info

/// Things only the OS can say, read by the writer thread (never the game thread).
#[derive(Clone, Copy, Debug, Default)]
pub struct ProcStats {
    /// CPU used by the whole process during the last second, in percent of one core (can exceed 100).
    pub process_cpu_percent: f32,
    pub rss_mb: f32,
    pub threads: u32,
    pub mem_available_mb: f32,
    /// A temperature reading in °C if the phone lets us read one, otherwise `NaN`.
    pub temp_c: f32,
    pub cpu_count: u32,
}

// ------------------------------------------------------------------------------------------------ lines

fn k(v: u64) -> String {
    if v >= 10_000_000 {
        format!("{:.1}M", v as f64 / 1e6)
    } else if v >= 10_000 {
        format!("{}k", v / 1000)
    } else {
        v.to_string()
    }
}

/// One line per second.
pub fn second_line(t: LocalTime, s: &SecondSample, p: &ProcStats, v: &Verdict) -> String {
    let mut o = String::with_capacity(512);
    let g = &s.gauges;
    let ms = |st: Stage| s.stage_ms(st);
    let _ = write!(o, "{}  {:<8}", clock_text(t), g.screen.name());
    let _ = write!(
        o,
        " fps {:>5.1} | frame {:>5.1}ms p95 {:>3.0} max {:>3.0}",
        s.fps(),
        s.frame_ms(),
        s.percentile_ms(0.95),
        s.max_ms()
    );
    let _ = write!(
        o,
        " | thread: input {:.1} update {:.1} [engine {:.1} streaming {:.1}] render {:.1} [upload {:.1} cull {:.1} world {:.1} far {:.1} ui {:.1}] swap-wait {:.1}",
        ms(Stage::Input),
        ms(Stage::Update),
        ms(Stage::Engine),
        ms(Stage::Streaming),
        ms(Stage::Render),
        ms(Stage::Upload),
        ms(Stage::Cull),
        ms(Stage::DrawWorld),
        ms(Stage::DrawFar),
        ms(Stage::DrawUi),
        ms(Stage::Swap)
    );
    let _ = write!(o, " | cpu: game-thread {:.0}% process {:.0}%", s.main_cpu_percent(), p.process_cpu_percent);
    if g.in_world {
        let _ = write!(
            o,
            " | world: chunk {},{} y{:.0}{}{} loaded {} meshed {} queue gen {} mesh {} running {}",
            g.chunk_x,
            g.chunk_z,
            g.height,
            if g.flying { " flying" } else { "" },
            if g.underwater { " underwater" } else { "" },
            g.chunks_loaded,
            g.chunks_meshed,
            g.gen_queue,
            g.mesh_queue,
            g.jobs_in_flight
        );
        let gen_n = s.counter(Counter::GenJobs);
        let mesh_n = s.counter(Counter::MeshJobs);
        let far_n = s.counter(Counter::FarJobs);
        let busy_ns = s.counter(Counter::GenNs) + s.counter(Counter::MeshNs) + s.counter(Counter::FarNs);
        let workers = g.workers.max(1) as f32;
        let busy_pct = busy_ns as f32 * 100.0 / (s.wall_ns.max(1) as f32 * workers);
        let avg = |ns: u64, n: u64| if n == 0 { 0.0 } else { ns as f32 / n as f32 / 1e6 };
        let _ = write!(
            o,
            " | workers x{} {:.0}% busy: gen {}/s ({:.2}ms) mesh {}/s ({:.2}ms) far {}/s ({:.2}ms)",
            g.workers,
            busy_pct,
            gen_n,
            avg(s.counter(Counter::GenNs), gen_n),
            mesh_n,
            avg(s.counter(Counter::MeshNs), mesh_n),
            far_n,
            avg(s.counter(Counter::FarNs), far_n)
        );
        if g.gpu_ms >= 0.0 {
            let _ = write!(o, " | gpu-time {:.1}ms/frame (measured by the GPU itself)", g.gpu_ms);
        }
        let _ = write!(
            o,
            " | gpu upload {} chunks {} tiles {} KB | drawn {} chunks {} tiles {} calls {} tris",
            s.counter(Counter::UploadChunks),
            s.counter(Counter::UploadTiles),
            s.counter(Counter::UploadBytes) / 1024,
            s.counter(Counter::ChunksDrawn) / s.frames.max(1) as u64,
            s.counter(Counter::TilesDrawn) / s.frames.max(1) as u64,
            s.counter(Counter::DrawCalls) / s.frames.max(1) as u64,
            k(s.counter(Counter::Triangles) / s.frames.max(1) as u64)
        );
        // which pass the triangles and draw calls belong to (the last frame of the second)
        if g.pass_tris.iter().any(|&n| n > 0) {
            let _ = write!(o, " [");
            for (i, name) in PASS_NAMES.iter().enumerate() {
                if g.pass_calls[i] == 0 {
                    continue;
                }
                let _ = write!(o, "{}{} {}/{}", if i == 0 { "" } else { " " }, name, g.pass_calls[i], k(g.pass_tris[i] as u64));
            }
            let _ = write!(o, " calls/tris]");
        }
        let _ = write!(
            o,
            " | far tiles {}/{} | view {} chunks (detail {}) at {}% ({}x{})",
            g.far_tiles_ready, g.far_tiles_wanted, g.render_distance, g.detail_radius, g.resolution_percent, g.view_w, g.view_h
        );
    }
    let _ = write!(o, " | mem {:.0}MB threads {}", p.rss_mb, p.threads);
    if p.temp_c.is_finite() {
        let _ = write!(o, " temp {:.0}C", p.temp_c);
    }
    let _ = write!(o, " => {}", v.kind.label());
    if v.kind != Kind::Smooth && v.kind != Kind::Idle {
        let _ = write!(o, " ({})", v.text);
    }
    o.push('\n');
    o
}

/// A line for one very slow frame.
pub fn hitch_line(t: LocalTime, h: &HitchSample) -> String {
    let st: Vec<f32> = h.stages_ns.iter().map(|&n| n as f32 / 1e6).collect();
    let mut arr = [0.0f32; STAGE_COUNT];
    arr.copy_from_slice(&st);
    let (name, ms, _) = biggest_part(&arr);
    let accounted = arr[Stage::Input as usize] + arr[Stage::Update as usize] + arr[Stage::Render as usize] + arr[Stage::Swap as usize];
    let total = h.interval_ns as f32 / 1e6;
    let mut o = String::new();
    let _ = write!(
        o,
        "{}  HITCH   one frame took {:.0} ms ({} on screen): update {:.0} [engine {:.0} streaming {:.0}] render {:.0} [upload {:.0} cull {:.0} world {:.0} far {:.0} ui {:.0}] swap-wait {:.0}; biggest part: {} {:.0} ms",
        clock_text(t),
        total,
        h.screen.name(),
        arr[Stage::Update as usize],
        arr[Stage::Engine as usize],
        arr[Stage::Streaming as usize],
        arr[Stage::Render as usize],
        arr[Stage::Upload as usize],
        arr[Stage::Cull as usize],
        arr[Stage::DrawWorld as usize],
        arr[Stage::DrawFar as usize],
        arr[Stage::DrawUi as usize],
        arr[Stage::Swap as usize],
        name,
        ms
    );
    if accounted < total * 0.5 {
        let _ = write!(o, "; {:.0} ms of the frame is unaccounted for (the app was not running: another app, the system or a pause)", total - accounted);
    }
    let _ = write!(o, "; queues gen {} mesh {}", h.gen_queue, h.mesh_queue);
    o.push('\n');
    o
}

// ------------------------------------------------------------------------------------------------ per-minute summary

/// Collects the seconds of one clock minute and prints the summary line block.
#[derive(Clone, Debug)]
pub struct MinuteAgg {
    pub minute: LocalTime,
    seconds: u32,
    active_seconds: u32,
    fps_sum: f64,
    fps_min: f32,
    fps_min_at: LocalTime,
    levels: [u32; 3],
    kinds: [u32; KIND_COUNT],
    blames: Vec<(&'static str, u32)>,
    hitches: u32,
    worst_ms: f32,
    worst_at: LocalTime,
    stage_sum_ms: [f64; STAGE_COUNT],
    busy_pct_sum: f64,
    loading_seconds: u32,
    jobs: [u64; 3],
    screens: [u32; 7],
}

impl MinuteAgg {
    pub fn new(at: LocalTime) -> MinuteAgg {
        MinuteAgg {
            minute: LocalTime { sec: 0, ..at },
            seconds: 0,
            active_seconds: 0,
            fps_sum: 0.0,
            fps_min: f32::MAX,
            fps_min_at: at,
            levels: [0; 3],
            kinds: [0; KIND_COUNT],
            blames: Vec::new(),
            hitches: 0,
            worst_ms: 0.0,
            worst_at: at,
            stage_sum_ms: [0.0; STAGE_COUNT],
            busy_pct_sum: 0.0,
            loading_seconds: 0,
            jobs: [0; 3],
            screens: [0; 7],
        }
    }

    pub fn same_minute(&self, t: LocalTime) -> bool {
        self.minute.year == t.year
            && self.minute.month == t.month
            && self.minute.day == t.day
            && self.minute.hour == t.hour
            && self.minute.min == t.min
    }

    pub fn is_empty(&self) -> bool {
        self.seconds == 0
    }

    pub fn add(&mut self, t: LocalTime, s: &SecondSample, v: &Verdict) {
        self.seconds += 1;
        self.screens[s.gauges.screen as usize] += 1;
        if s.frames == 0 {
            return;
        }
        self.active_seconds += 1;
        let fps = s.fps();
        self.fps_sum += fps as f64;
        if fps < self.fps_min {
            self.fps_min = fps;
            self.fps_min_at = t;
        }
        self.levels[v.level.min(2) as usize] += 1;
        self.kinds[v.kind.index()] += 1;
        if v.level > 0 && !v.blame.is_empty() {
            match self.blames.iter_mut().find(|b| b.0 == v.blame) {
                Some(b) => b.1 += 1,
                None => self.blames.push((v.blame, 1)),
            }
        }
        self.hitches += s.hitches as u32;
        if s.max_ms() > self.worst_ms {
            self.worst_ms = s.max_ms();
            self.worst_at = t;
        }
        for i in 0..STAGE_COUNT {
            self.stage_sum_ms[i] += s.stage_sum_ns[i] as f64 / s.frames as f64 / 1e6;
        }
        let busy_ns = s.counter(Counter::GenNs) + s.counter(Counter::MeshNs) + s.counter(Counter::FarNs);
        self.busy_pct_sum += busy_ns as f64 * 100.0 / (s.wall_ns.max(1) as f64 * s.gauges.workers.max(1) as f64);
        if s.gauges.screen == ScreenKind::Loading {
            self.loading_seconds += 1;
        }
        self.jobs[0] += s.counter(Counter::GenJobs);
        self.jobs[1] += s.counter(Counter::MeshJobs);
        self.jobs[2] += s.counter(Counter::FarJobs);
    }

    /// The summary block for the minute, ending in a newline.
    pub fn summary(&self) -> String {
        let mut o = String::new();
        let n = self.active_seconds.max(1) as f64;
        let _ = writeln!(o, "---- {} summary ({} s logged, {} with the game drawing) ----", minute_text(self.minute), self.seconds, self.active_seconds);
        if self.active_seconds == 0 {
            let _ = writeln!(o, "  nothing was drawn this minute (app in the background?)");
            let _ = writeln!(o, "----");
            return o;
        }
        let _ = writeln!(
            o,
            "  average {:.1} fps; lowest {:.1} fps at {}; slowest single frame {:.0} ms at {}",
            self.fps_sum / n,
            self.fps_min,
            clock_text(self.fps_min_at),
            self.worst_ms,
            clock_text(self.worst_at)
        );
        let _ = writeln!(
            o,
            "  smooth {} s, slightly slow {} s, clearly lagging {} s; hitches (frames over {:.0} ms): {}",
            self.levels[0], self.levels[1], self.levels[2], HITCH_MS, self.hitches
        );
        let mut causes = String::new();
        for kind in [Kind::Calculation, Kind::RenderCpu, Kind::Gpu, Kind::Starved, Kind::Hitch] {
            let c = self.kinds[kind.index()];
            if c > 0 {
                if !causes.is_empty() {
                    causes.push_str(", ");
                }
                let _ = write!(causes, "{} s {}", c, kind.label());
            }
        }
        if causes.is_empty() {
            causes.push_str("none");
        }
        let _ = writeln!(o, "  causes: {}", causes);
        if !self.blames.is_empty() {
            let mut b = self.blames.clone();
            b.sort_by(|x, y| y.1.cmp(&x.1));
            let list: Vec<String> = b.iter().take(3).map(|(name, c)| format!("{} ({} s)", name, c)).collect();
            let _ = writeln!(o, "  most costly parts while lagging: {}", list.join(", "));
        }
        let st = |s: Stage| self.stage_sum_ms[s as usize] / n;
        let _ = writeln!(
            o,
            "  average per frame: update {:.1} ms (engine {:.1}, streaming {:.1}), render {:.1} ms (upload {:.1}, world {:.1}, far {:.1}), swap-wait {:.1} ms",
            st(Stage::Update),
            st(Stage::Engine),
            st(Stage::Streaming),
            st(Stage::Render),
            st(Stage::Upload),
            st(Stage::DrawWorld),
            st(Stage::DrawFar),
            st(Stage::Swap)
        );
        let _ = writeln!(
            o,
            "  background workers {:.0}% busy on average; finished {} chunk generations, {} meshes, {} far-terrain tiles; {} s spent on the loading screen",
            self.busy_pct_sum / n,
            self.jobs[0],
            self.jobs[1],
            self.jobs[2],
            self.loading_seconds
        );
        let _ = writeln!(o, "----");
        o
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::diag::sample::Gauges;

    fn t(h: u32, m: u32, s: u32) -> LocalTime {
        LocalTime { year: 2026, month: 11, day: 7, hour: h, min: m, sec: s }
    }

    /// A one-second window of `frames` frames with the given per-frame stage times (ms).
    fn window(frames: u32, frame_ms: f32, stages: &[(Stage, f32)], cpu_ms_per_frame: f32) -> SecondSample {
        let mut s = SecondSample::empty();
        s.frames = frames;
        s.wall_ns = (frames as f32 * frame_ms * 1e6) as u64;
        s.interval_sum_ns = s.wall_ns;
        s.interval_max_ns = (frame_ms * 1.2 * 1e6) as u64;
        s.hist[crate::diag::sample::hist_bucket(frame_ms)] = frames as u16;
        for (st, ms) in stages {
            s.stage_sum_ns[*st as usize] = (ms * frames as f32 * 1e6) as u64;
        }
        s.main_cpu_ns = (cpu_ms_per_frame * frames as f32 * 1e6) as u64;
        s.gauges = Gauges { screen: ScreenKind::Playing, in_world: true, workers: 3, ..Gauges::default() };
        s
    }

    #[test]
    fn clock_text_uses_twelve_hour_style() {
        assert_eq!(clock_text(t(13, 20, 5)), "1:20:05pm");
        assert_eq!(minute_text(t(13, 21, 59)), "1:21pm");
        assert_eq!(clock_text(t(0, 5, 9)), "12:05:09am");
        assert_eq!(clock_text(t(12, 0, 0)), "12:00:00pm");
        assert_eq!(clock_text(t(23, 59, 59)), "11:59:59pm");
        assert_eq!(file_stamp(t(13, 20, 5)), "2026-11-07_1.20pm");
    }

    #[test]
    fn a_steady_sixty_is_smooth() {
        let s = window(60, 16.7, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 10.5)], 7.0);
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Smooth);
        assert_eq!(v.level, 0);
    }

    #[test]
    fn busy_logic_is_blamed_on_calculation() {
        // 25 fps; the game thread is busy 36 ms of 40, mostly world streaming
        let s = window(
            25,
            40.0,
            &[
                (Stage::Update, 28.0),
                (Stage::Engine, 26.0),
                (Stage::Streaming, 20.0),
                (Stage::Render, 8.0),
                (Stage::DrawWorld, 5.0),
                (Stage::Swap, 1.0),
            ],
            36.0,
        );
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Calculation, "{}", v.text);
        assert_eq!(v.blame, "world streaming");
        assert_eq!(v.level, 2);
    }

    #[test]
    fn busy_drawing_is_blamed_on_rendering() {
        let s = window(
            30,
            33.0,
            &[(Stage::Update, 3.0), (Stage::Engine, 2.0), (Stage::Render, 27.0), (Stage::Upload, 20.0), (Stage::DrawWorld, 5.0), (Stage::Swap, 1.0)],
            30.0,
        );
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::RenderCpu);
        assert_eq!(v.blame, "mesh upload to GPU");
    }

    #[test]
    fn waiting_in_swap_with_little_cpu_work_is_the_gpu() {
        let s = window(30, 33.0, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 26.0)], 6.0);
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Gpu);
        assert_eq!(v.level, 2);
    }

    #[test]
    fn busy_in_graphics_calls_without_cpu_use_is_also_the_gpu() {
        // the time is inside render, but the thread's CPU clock barely moved: blocked in the driver
        let s = window(30, 33.0, &[(Stage::Update, 2.0), (Stage::Render, 28.0), (Stage::DrawWorld, 26.0), (Stage::Swap, 1.0)], 8.0);
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Gpu, "{}", v.text);
    }

    #[test]
    fn neither_busy_nor_waiting_means_starved() {
        let s = window(30, 33.0, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 2.0)], 5.0);
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Starved);
    }

    #[test]
    fn isolated_spikes_are_hitches_with_a_blamed_stage() {
        let mut s = window(60, 16.7, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 10.0)], 7.0);
        s.interval_max_ns = 180_000_000;
        s.hitches = 1;
        s.worst_stages_ns[Stage::Render as usize] = 150_000_000;
        s.worst_stages_ns[Stage::Upload as usize] = 140_000_000;
        let v = judge(&s, 60.0);
        assert_eq!(v.kind, Kind::Hitch);
        assert_eq!(v.blame, "mesh upload to GPU");
    }

    #[test]
    fn no_frames_is_idle() {
        let s = SecondSample::empty();
        assert_eq!(judge(&s, 60.0).kind, Kind::Idle);
    }

    #[test]
    fn target_rate_follows_the_best_seen() {
        assert_eq!(target_hz_from_best(59.0), 60.0);
        assert_eq!(target_hz_from_best(89.0), 90.0);
        assert_eq!(target_hz_from_best(119.0), 120.0);
    }

    #[test]
    fn second_line_has_the_timestamp_and_the_numbers_we_need() {
        let s = window(58, 17.2, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 10.0)], 7.0);
        let v = judge(&s, 60.0);
        let line = second_line(t(13, 20, 5), &s, &ProcStats { process_cpu_percent: 120.0, rss_mb: 400.0, threads: 20, mem_available_mb: 900.0, temp_c: f32::NAN, cpu_count: 8 }, &v);
        assert!(line.starts_with("1:20:05pm"), "{}", line);
        assert!(line.contains("PLAYING"));
        assert!(line.contains("fps"));
        assert!(line.contains("swap-wait"));
        assert!(line.contains("workers x3"));
        assert!(line.contains("=> smooth"));
        assert!(line.ends_with('\n'));
        assert_eq!(line.matches('\n').count(), 1, "one line per second");
    }

    #[test]
    fn hitch_line_names_the_culprit() {
        let mut stages = [0u64; STAGE_COUNT];
        stages[Stage::Render as usize] = 120_000_000;
        stages[Stage::Upload as usize] = 110_000_000;
        stages[Stage::Update as usize] = 3_000_000;
        let h = HitchSample { unix_ms: 0, interval_ns: 130_000_000, stages_ns: stages, screen: ScreenKind::Playing, gen_queue: 4, mesh_queue: 9 };
        let line = hitch_line(t(13, 21, 40), &h);
        assert!(line.starts_with("1:21:40pm"));
        assert!(line.contains("130 ms"));
        assert!(line.contains("mesh upload to GPU"));
    }

    #[test]
    fn minute_summary_counts_the_seconds() {
        let mut agg = MinuteAgg::new(t(13, 20, 0));
        for sec in 0..60 {
            let (s, v) = if sec < 50 {
                let s = window(60, 16.7, &[(Stage::Update, 2.0), (Stage::Render, 4.0), (Stage::Swap, 10.0)], 7.0);
                let v = judge(&s, 60.0);
                (s, v)
            } else {
                let s = window(25, 40.0, &[(Stage::Update, 28.0), (Stage::Engine, 26.0), (Stage::Streaming, 20.0), (Stage::Render, 8.0), (Stage::Swap, 1.0)], 36.0);
                let v = judge(&s, 60.0);
                (s, v)
            };
            assert!(agg.same_minute(t(13, 20, sec)));
            agg.add(t(13, 20, sec), &s, &v);
        }
        assert!(!agg.same_minute(t(13, 21, 0)));
        let text = agg.summary();
        assert!(text.contains("1:20pm summary"), "{}", text);
        assert!(text.contains("smooth 50 s"), "{}", text);
        assert!(text.contains("clearly lagging 10 s"), "{}", text);
        assert!(text.contains("10 s LAG: CALCULATION"), "{}", text);
        assert!(text.contains("world streaming"), "{}", text);
    }

    #[test]
    fn empty_minute_says_so() {
        let agg = MinuteAgg::new(t(1, 2, 3));
        assert!(agg.is_empty());
        let mut a = MinuteAgg::new(t(1, 2, 3));
        a.add(t(1, 2, 3), &SecondSample::empty(), &judge(&SecondSample::empty(), 60.0));
        assert!(a.summary().contains("nothing was drawn"));
    }
}
