//! The log writer: one background thread at the lowest priority that turns samples into text and appends
//! it to the log file. The game thread only ever does a non-blocking `try_send` of a small struct; if the
//! writer falls behind (slow storage) messages are dropped and counted instead of making the game wait.

use std::io::Write;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, RecvTimeoutError, SyncSender, TrySendError};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

use super::procfs::ProcReader;
use super::report::{self, MinuteAgg, ProcStats, Verdict};
use super::sample::{HitchSample, SecondSample};
use crate::core::clock::{self, LocalTime};

/// Where the writer puts its text.
pub struct Opened {
    pub writer: Box<dyn Write + Send>,
    /// A short human description for the settings screen (for example the path of the file).
    pub description: String,
}

/// Opens the destination. It runs on the writer thread, so slow system calls never delay the game.
pub type Opener = Box<dyn FnOnce() -> Result<Opened, String> + Send>;

pub enum Msg {
    Second(Box<SecondSample>),
    Hitch(Box<HitchSample>),
    Event(String),
    /// Write everything out now and signal when done.
    Flush(Arc<FlushAck>),
    Stop,
}

#[derive(Default)]
pub struct FlushAck {
    done: Mutex<bool>,
    cv: Condvar,
}

impl FlushAck {
    fn signal(&self) {
        if let Ok(mut d) = self.done.lock() {
            *d = true;
        }
        self.cv.notify_all();
    }

    fn wait(&self, timeout: Duration) -> bool {
        let guard = match self.done.lock() {
            Ok(g) => g,
            Err(_) => return false,
        };
        match self.cv.wait_timeout_while(guard, timeout, |d| !*d) {
            Ok((g, _)) => *g,
            Err(_) => false,
        }
    }
}

struct Shared {
    dropped: AtomicU64,
    stop: AtomicBool,
    status: Mutex<String>,
}

impl Shared {
    fn set_status(&self, text: String) {
        if let Ok(mut s) = self.status.lock() {
            *s = text;
        }
    }
}

/// Settings of the writer thread (the defaults are what the app uses; tests shrink them).
#[derive(Clone, Copy, Debug)]
pub struct SinkConfig {
    pub channel_capacity: usize,
    pub flush_interval: Duration,
    pub flush_bytes: usize,
    /// After this many bytes only summaries, hitches and events are written.
    pub detail_limit: usize,
    /// After this many bytes nothing more is written.
    pub hard_limit: usize,
}

impl Default for SinkConfig {
    fn default() -> SinkConfig {
        SinkConfig {
            channel_capacity: 256,
            flush_interval: Duration::from_millis(2000),
            flush_bytes: 16 * 1024,
            detail_limit: 12 * 1024 * 1024,
            hard_limit: 16 * 1024 * 1024,
        }
    }
}

/// The game thread's end of the log. Cheap to clone; never blocks.
#[derive(Clone)]
pub struct LogSender {
    tx: SyncSender<Msg>,
    shared: Arc<Shared>,
}

impl LogSender {
    /// Queues a message; if the writer is behind, the message is dropped (and counted).
    pub fn send(&self, msg: Msg) -> bool {
        match self.tx.try_send(msg) {
            Ok(()) => true,
            Err(TrySendError::Full(_)) | Err(TrySendError::Disconnected(_)) => {
                self.shared.dropped.fetch_add(1, Ordering::Relaxed);
                false
            }
        }
    }

    pub fn event(&self, text: String) {
        self.send(Msg::Event(text));
    }

    /// What the settings screen shows: where the log is going, or why it is not.
    pub fn status(&self) -> String {
        match self.shared.status.lock() {
            Ok(s) => s.clone(),
            Err(_) => String::new(),
        }
    }

    pub fn dropped(&self) -> u64 {
        self.shared.dropped.load(Ordering::Relaxed)
    }

    /// Asks the writer to write everything out and waits up to `timeout` (used when the app is going away).
    pub fn flush_blocking(&self, timeout: Duration) -> bool {
        let ack = Arc::new(FlushAck::default());
        if !self.send(Msg::Flush(ack.clone())) {
            return false;
        }
        ack.wait(timeout)
    }

    /// Writes the session footer and ends the writer thread (does not wait for it).
    pub fn stop(&self) {
        self.shared.stop.store(true, Ordering::Relaxed);
        let _ = self.tx.try_send(Msg::Stop);
    }
}

/// Starts the writer thread. `header` is written first.
pub fn start(opener: Opener, header: String, cfg: SinkConfig) -> LogSender {
    let (tx, rx) = sync_channel::<Msg>(cfg.channel_capacity.max(4));
    let shared = Arc::new(Shared { dropped: AtomicU64::new(0), stop: AtomicBool::new(false), status: Mutex::new("LOG: OPENING FILE...".to_string()) });
    let worker_shared = shared.clone();
    let spawned = std::thread::Builder::new().name("vs-log".to_string()).spawn(move || writer_main(rx, opener, header, worker_shared, cfg));
    if let Err(e) = spawned {
        shared.set_status(format!("LOG: COULD NOT START WRITER ({})", e));
    }
    LogSender { tx, shared }
}

struct Writer {
    out: Option<Box<dyn Write + Send>>,
    cfg: SinkConfig,
    shared: Arc<Shared>,
    description: String,
    buf: String,
    written: usize,
    last_flush: Instant,
    failed: bool,
    notified_detail_cap: bool,
    notified_hard_cap: bool,
    minute: Option<MinuteAgg>,
    proc: ProcReader,
    best_fps: f32,
    seconds_logged: u64,
}

impl Writer {
    fn push(&mut self, text: &str) {
        let total = self.written + self.buf.len();
        if total >= self.cfg.hard_limit {
            if !self.notified_hard_cap {
                self.notified_hard_cap = true;
                self.buf.push_str("\n# LOG SIZE LIMIT REACHED: nothing more will be written to this file.\n");
            }
            return;
        }
        self.buf.push_str(text);
    }

    fn detail_allowed(&self) -> bool {
        self.written + self.buf.len() < self.cfg.detail_limit
    }

    /// Writes the buffered text. A `sync` flush also tells the destination to finish its own buffering even when
    /// there is nothing new to write (the Download-folder file uses that to close itself properly, so the file
    /// manager shows the right size while the app is in the background).
    fn flush(&mut self, sync: bool) {
        if self.buf.is_empty() && !sync {
            return;
        }
        if let Some(out) = self.out.as_mut() {
            let mut result = Ok(());
            if !self.buf.is_empty() {
                result = out.write_all(self.buf.as_bytes());
            }
            if result.is_ok() && sync {
                result = out.flush();
            }
            match result {
                Ok(()) => self.written += self.buf.len(),
                Err(e) => {
                    if !self.failed {
                        self.failed = true;
                        self.shared.set_status(format!("LOG: WRITE FAILED ({})", e));
                    }
                    self.out = None;
                }
            }
        }
        self.buf.clear();
        self.last_flush = Instant::now();
    }

    fn maybe_flush(&mut self) {
        if self.buf.len() >= self.cfg.flush_bytes || (!self.buf.is_empty() && self.last_flush.elapsed() >= self.cfg.flush_interval) {
            self.flush(false);
        }
    }

    fn note_dropped(&mut self, at: LocalTime) {
        let n = self.shared.dropped.swap(0, Ordering::Relaxed);
        if n > 0 {
            let line = format!("{}  NOTE    {} log message(s) were dropped because the log writer could not keep up (the game was not slowed down)\n", report::clock_text(at), n);
            self.push(&line);
        }
    }

    fn on_second(&mut self, s: &SecondSample) {
        let local = clock::local_time((s.unix_ms / 1000) as i64);
        if let Some(m) = self.minute.as_ref() {
            if !m.same_minute(local) {
                let text = m.summary();
                self.push(&text);
                self.minute = None;
            }
        }
        if self.minute.is_none() {
            self.minute = Some(MinuteAgg::new(local));
            clock::refresh_timezone();
        }
        self.note_dropped(local);

        if s.frames > 0 {
            self.best_fps = self.best_fps.max(s.fps());
        }
        let verdict: Verdict = report::judge(s, report::target_hz_from_best(self.best_fps));
        let stats: ProcStats = self.proc.read(s.wall_ns);
        self.seconds_logged += 1;
        if self.detail_allowed() {
            let line = report::second_line(local, s, &stats, &verdict);
            self.push(&line);
        } else if !self.notified_detail_cap {
            self.notified_detail_cap = true;
            self.push("\n# DETAIL LIMIT REACHED: from here on only minute summaries, hitches and events are written.\n");
        }
        if let Some(m) = self.minute.as_mut() {
            m.add(local, s, &verdict);
        }
    }

    fn on_hitch(&mut self, h: &HitchSample) {
        let local = clock::local_time((h.unix_ms / 1000) as i64);
        let line = report::hitch_line(local, h);
        self.push(&line);
    }

    fn on_event(&mut self, text: &str) {
        let local = clock::local_time((clock::unix_ms() / 1000) as i64);
        let line = format!("{}  EVENT   {}\n", report::clock_text(local), text);
        self.push(&line);
    }

    fn finish(&mut self) {
        if let Some(m) = self.minute.take() {
            if !m.is_empty() {
                let text = m.summary();
                self.push(&text);
            }
        }
        let local = clock::local_time((clock::unix_ms() / 1000) as i64);
        let line = format!("{}  END     log closed ({} seconds logged)\n", report::clock_text(local), self.seconds_logged);
        self.push(&line);
        self.flush(true);
    }
}

fn writer_main(rx: Receiver<Msg>, opener: Opener, header: String, shared: Arc<Shared>, cfg: SinkConfig) {
    // the writer must never compete with the game for a CPU core
    crate::core::sched::set_thread_nice(19);
    clock::refresh_timezone();

    let mut writer = Writer {
        out: None,
        cfg,
        shared: shared.clone(),
        description: String::new(),
        buf: String::with_capacity(32 * 1024),
        written: 0,
        last_flush: Instant::now(),
        failed: false,
        notified_detail_cap: false,
        notified_hard_cap: false,
        minute: None,
        proc: ProcReader::new(),
        best_fps: 0.0,
        seconds_logged: 0,
    };
    match opener() {
        Ok(opened) => {
            writer.description = opened.description.clone();
            writer.out = Some(opened.writer);
            shared.set_status(format!("LOG: WRITING TO {}", opened.description));
        }
        Err(e) => {
            writer.failed = true;
            shared.set_status(format!("LOG: COULD NOT OPEN FILE ({})", e));
        }
    }
    writer.push(&header);
    if !writer.description.is_empty() {
        let line = format!("# file:     {}\n", writer.description);
        writer.push(&line);
    }
    writer.flush(true);

    loop {
        match rx.recv_timeout(Duration::from_millis(500)) {
            Ok(Msg::Second(s)) => writer.on_second(&s),
            Ok(Msg::Hitch(h)) => writer.on_hitch(&h),
            Ok(Msg::Event(t)) => writer.on_event(&t),
            Ok(Msg::Flush(ack)) => {
                writer.flush(true);
                ack.signal();
            }
            Ok(Msg::Stop) => break,
            Err(RecvTimeoutError::Timeout) => {}
            Err(RecvTimeoutError::Disconnected) => break,
        }
        writer.maybe_flush();
        if shared.stop.load(Ordering::Relaxed) {
            break;
        }
    }
    writer.finish();
}

#[cfg(test)]
pub(crate) mod testing {
    use super::*;

    /// A writer that appends to a shared buffer, optionally slowly.
    #[derive(Clone, Default)]
    pub struct SharedBuf {
        pub data: Arc<Mutex<Vec<u8>>>,
        pub delay: Duration,
    }

    impl Write for SharedBuf {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            if !self.delay.is_zero() {
                std::thread::sleep(self.delay);
            }
            self.data.lock().unwrap().extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    impl SharedBuf {
        pub fn text(&self) -> String {
            String::from_utf8_lossy(&self.data.lock().unwrap()).to_string()
        }
    }

    pub fn opener_for(buf: &SharedBuf) -> Opener {
        let b = buf.clone();
        Box::new(move || Ok(Opened { writer: Box::new(b), description: "TEST-BUFFER".to_string() }))
    }
}

#[cfg(test)]
mod tests {
    use super::testing::*;
    use super::*;
    use crate::diag::probe::Stage;
    use crate::diag::sample::{Gauges, ScreenKind};

    fn sample_at(unix_ms: u64, frames: u32) -> SecondSample {
        let mut s = SecondSample::empty();
        s.unix_ms = unix_ms;
        s.frames = frames;
        s.interval_sum_ns = 1_000_000_000;
        s.interval_max_ns = 20_000_000;
        s.hist[2] = frames as u16;
        s.stage_sum_ns[Stage::Render as usize] = 4_000_000 * frames as u64;
        s.gauges = Gauges { screen: ScreenKind::Playing, in_world: true, workers: 2, ..Gauges::default() };
        s
    }

    fn wait_until(mut f: impl FnMut() -> bool) -> bool {
        let start = Instant::now();
        while start.elapsed() < Duration::from_secs(5) {
            if f() {
                return true;
            }
            std::thread::sleep(Duration::from_millis(5));
        }
        false
    }

    #[test]
    fn header_then_seconds_then_footer_reach_the_file() {
        let buf = SharedBuf::default();
        let log = start(opener_for(&buf), "# HEADER\n".to_string(), SinkConfig::default());
        let base = 1_794_011_100_000u64;
        for i in 0..3 {
            assert!(log.send(Msg::Second(Box::new(sample_at(base + i * 1000, 60)))));
        }
        log.event("world started".to_string());
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.starts_with("# HEADER"), "{}", text);
        assert_eq!(text.matches("PLAYING").count(), 3, "{}", text);
        assert!(text.contains("EVENT   world started"));
        assert!(log.status().contains("WRITING TO TEST-BUFFER"));
        log.stop();
        assert!(wait_until(|| buf.text().contains("log closed (3 seconds logged)")), "{}", buf.text());
    }

    #[test]
    fn a_new_minute_writes_the_summary_of_the_old_one() {
        let buf = SharedBuf::default();
        let log = start(opener_for(&buf), String::new(), SinkConfig::default());
        let base = 1_794_011_100_000u64; // some minute boundary does not matter; cross one explicitly
        let base = base - (base / 1000 % 60) * 1000; // :00 of a minute (UTC); the local zone only shifts whole minutes
        for i in 0..70 {
            log.send(Msg::Second(Box::new(sample_at(base + i * 1000, 60))));
            if i % 16 == 15 {
                // keep the bounded queue from overflowing in this test
                assert!(log.flush_blocking(Duration::from_secs(5)));
            }
        }
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.contains("summary ("), "no minute summary was written:\n{}", text);
        assert!(text.contains("smooth 60 s"), "{}", text);
        log.stop();
    }

    #[test]
    fn a_stalled_disk_never_blocks_the_sender() {
        let buf = SharedBuf { delay: Duration::from_millis(400), ..SharedBuf::default() };
        let cfg = SinkConfig { channel_capacity: 8, flush_interval: Duration::from_millis(1), ..SinkConfig::default() };
        let log = start(opener_for(&buf), "# H\n".to_string(), cfg);
        let started = Instant::now();
        let mut refused = 0;
        for i in 0..2000u64 {
            if !log.send(Msg::Second(Box::new(sample_at(1_794_011_100_000 + i * 1000, 60)))) {
                refused += 1;
            }
        }
        let took = started.elapsed();
        assert!(took < Duration::from_millis(500), "sending 2000 messages took {:?}: the sender must not wait", took);
        assert!(refused > 1000, "most messages should have been dropped, only {} were", refused);
        assert_eq!(log.dropped(), refused);
        log.stop();
    }

    #[test]
    fn dropped_messages_are_reported_in_the_file() {
        let buf = SharedBuf::default();
        let cfg = SinkConfig { channel_capacity: 4, ..SinkConfig::default() };
        let log = start(opener_for(&buf), String::new(), cfg);
        for i in 0..200u64 {
            log.send(Msg::Second(Box::new(sample_at(1_794_011_100_000 + i * 1000, 60))));
        }
        assert!(wait_until(|| log.flush_blocking(Duration::from_millis(500))));
        // one more second after the burst so the writer reports what it missed
        assert!(wait_until(|| log.send(Msg::Second(Box::new(sample_at(1_794_020_000_000, 60))))));
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        if log.dropped() > 0 || text.contains("dropped") {
            assert!(text.contains("log message(s) were dropped") || log.dropped() > 0);
        }
        log.stop();
    }

    #[test]
    fn a_file_that_cannot_be_opened_is_reported_and_harmless() {
        let opener: Opener = Box::new(|| Err("no permission".to_string()));
        let log = start(opener, "# H\n".to_string(), SinkConfig::default());
        for i in 0..5u64 {
            log.send(Msg::Second(Box::new(sample_at(1_794_011_100_000 + i * 1000, 60))));
        }
        log.event("still alive".to_string());
        assert!(log.flush_blocking(Duration::from_secs(5)));
        assert!(log.status().contains("COULD NOT OPEN FILE"));
        assert!(log.status().contains("no permission"));
        log.stop();
    }

    #[test]
    fn the_size_limits_stop_the_detail_and_then_everything() {
        let buf = SharedBuf::default();
        let cfg = SinkConfig { detail_limit: 3000, hard_limit: 6000, flush_interval: Duration::from_millis(1), ..SinkConfig::default() };
        let log = start(opener_for(&buf), String::new(), cfg);
        for i in 0..40u64 {
            log.send(Msg::Second(Box::new(sample_at(1_794_011_100_000 + i * 1000, 60))));
            if i % 8 == 7 {
                assert!(log.flush_blocking(Duration::from_secs(5)));
            }
        }
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.contains("DETAIL LIMIT REACHED"), "{}", text);
        assert!(!text.contains("LOG SIZE LIMIT REACHED"), "after the detail limit events and summaries are still written:\n{}", text);
        assert!(text.matches("PLAYING").count() < 40, "the per-second lines must have stopped");

        // events keep being written until the hard limit, and then nothing more is
        for i in 0..80 {
            log.event(format!("event number {} with some padding so that the line is long enough ..........", i));
            if i % 8 == 7 {
                assert!(log.flush_blocking(Duration::from_secs(5)));
            }
        }
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.contains("LOG SIZE LIMIT REACHED"), "{}", text);
        assert!(text.len() < 6000 + 400, "file grew to {} bytes", text.len());
        log.event("written after the limit".to_string());
        assert!(log.flush_blocking(Duration::from_secs(5)));
        assert!(!buf.text().contains("written after the limit"));
        log.stop();
    }

    #[test]
    fn hitches_and_events_are_timestamped() {
        let buf = SharedBuf::default();
        let log = start(opener_for(&buf), String::new(), SinkConfig::default());
        let mut stages = [0u64; crate::diag::probe::STAGE_COUNT];
        stages[Stage::Upload as usize] = 100_000_000;
        log.send(Msg::Hitch(Box::new(HitchSample {
            unix_ms: 1_794_011_100_000,
            interval_ns: 120_000_000,
            stages_ns: stages,
            screen: ScreenKind::Playing,
            gen_queue: 0,
            mesh_queue: 1,
        })));
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.contains("HITCH"), "{}", text);
        assert!(text.contains("mesh upload to GPU"), "{}", text);
        log.stop();
    }
}
