//! The one object the platform shell talks to. It owns the `Recorder` (per-frame numbers), starts and stops the
//! log file when the setting changes, notes what happened in the log, and keeps the on-screen overlay current.
//!
//! It knows nothing about Android: the shell passes in a function that opens the log file and the facts about the
//! phone, so everything here runs (and is tested) on a normal computer.

use std::time::Duration;

use super::probe;
use super::recorder::Recorder;
use super::report;
use super::sample::{Gauges, ScreenKind};
use super::sink::{self, LogSender, Opener, SinkConfig};
use super::{install_global, place, session_header, SessionInfo};
use crate::core::clock;

/// Builds the opener for a log file with the given name.
pub type OpenerFactory = Box<dyn Fn(&str) -> Opener>;

pub struct Telemetry {
    recorder: Recorder,
    make_opener: OpenerFactory,
    base: SessionInfo,
    log: Option<LogSender>,
    status: String,
    overlay_on: bool,
    last_screen: Option<ScreenKind>,
    last_view: (i32, i32, i32),
}

impl Telemetry {
    pub fn new(make_opener: OpenerFactory, base: SessionInfo) -> Telemetry {
        Telemetry {
            recorder: Recorder::new(None),
            make_opener,
            base,
            log: None,
            status: String::new(),
            overlay_on: false,
            last_screen: None,
            last_view: (0, 0, 0),
        }
    }

    pub fn recorder(&mut self) -> &mut Recorder {
        &mut self.recorder
    }

    /// The facts about the phone that go at the top of the next log file. The shell fills in what it learns late
    /// (the graphics driver, the screen size); a log that is already running keeps the header it started with.
    pub fn session_mut(&mut self) -> &mut SessionInfo {
        &mut self.base
    }

    /// Applies the two debug switches (the log file and the on-screen numbers). Cheap: call it every frame.
    /// `settings_text` is only evaluated when a new log file is started.
    pub fn set_wanted(&mut self, log: bool, overlay: bool, settings_text: impl FnOnce() -> String) {
        self.overlay_on = overlay;
        probe::set_enabled(log || overlay);
        if log && self.log.is_none() {
            self.start_log(settings_text());
        } else if !log && self.log.is_some() {
            self.stop_log("switched off in the settings");
        }
    }

    fn start_log(&mut self, settings_text: String) {
        let now = clock::local_time((clock::unix_ms() / 1000) as i64);
        let name = place::log_file_name(&report::file_stamp(now));
        let mut info = self.base.clone();
        info.started = format!("{} {}", report::date_text(now), report::clock_text(now));
        info.settings = settings_text;
        let header = session_header(&info);
        let sender = sink::start((self.make_opener)(&name), header, SinkConfig::default());
        install_global(Some(sender.clone()));
        self.recorder.set_sender(Some(sender.clone()));
        self.status = sender.status();
        self.log = Some(sender);
        // a fresh file should start with a clean window
        self.recorder.resume();
    }

    fn stop_log(&mut self, why: &str) {
        if let Some(s) = self.log.take() {
            s.event(format!("log stopped: {}", why));
            s.stop();
        }
        install_global(None);
        self.recorder.set_sender(None);
        self.status.clear();
    }

    /// Where the log is going (or why it is not), for the Settings screen. Empty while the log is off.
    pub fn status_text(&self) -> &str {
        &self.status
    }

    pub fn logging(&self) -> bool {
        self.log.is_some()
    }

    /// Writes an EVENT line (the text is only built when a log is open).
    pub fn note(&self, text: impl FnOnce() -> String) {
        self.recorder.event_with(text);
    }

    /// Cheap per-frame bookkeeping: remembers the screen and queue sizes for hitch lines, and writes an EVENT line
    /// when the screen or the view settings change.
    pub fn observe(&mut self, screen: ScreenKind, render: i32, detail: i32, resolution: i32, gen_queue: u32, mesh_queue: u32) {
        self.recorder.screen = screen;
        self.recorder.gen_queue = gen_queue;
        self.recorder.mesh_queue = mesh_queue;
        if self.last_screen != Some(screen) {
            if self.last_screen.is_some() {
                self.recorder.event_with(|| format!("screen: {}", screen.name()));
            }
            self.last_screen = Some(screen);
        }
        let view = (render, detail, resolution);
        if view != self.last_view {
            if self.last_view != (0, 0, 0) {
                self.recorder.event_with(|| {
                    format!("view settings changed: render distance {} chunks, real-block radius {} chunks, resolution {}%", render, detail, resolution)
                });
            }
            self.last_view = view;
        }
    }

    /// Call once per frame after it is on screen (the time between calls is the frame time). Returns true when a
    /// one-second window was just closed (then `overlay_lines` and `status_text` are fresh).
    pub fn end_frame(&mut self, gauges: impl FnOnce() -> Gauges) -> bool {
        if !self.recorder.end_frame() {
            return false;
        }
        self.recorder.close_second(gauges());
        if let Some(s) = self.log.as_ref() {
            self.status = s.status();
        }
        true
    }

    /// The lines for the FPS overlay, when it is switched on.
    pub fn overlay_lines(&self) -> Option<Vec<String>> {
        if self.overlay_on {
            Some(self.recorder.overlay.lines())
        } else {
            None
        }
    }

    /// The app is going to the background: get everything into the file now (so it can be found and sent).
    pub fn pause(&mut self) {
        if let Some(s) = self.log.as_ref() {
            s.event("the app went to the background".to_string());
            s.flush_blocking(Duration::from_millis(250));
        }
    }

    /// The app is back: frame times from before must not count as one huge frame.
    pub fn resume(&mut self) {
        self.recorder.resume();
        self.note(|| "the app is back in the foreground".to_string());
    }

    /// The app is closing.
    pub fn shutdown(&mut self) {
        if let Some(s) = self.log.as_ref() {
            s.event("the app is closing".to_string());
            s.flush_blocking(Duration::from_millis(300));
        }
        self.stop_log("the app is closing");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::diag::probe::{test_lock, Stage};
    use crate::diag::sink::testing::{opener_for, SharedBuf};
    use std::cell::RefCell;
    use std::rc::Rc;
    use std::time::{Duration, Instant};

    fn telemetry(bufs: Rc<RefCell<Vec<(String, SharedBuf)>>>) -> Telemetry {
        let factory: OpenerFactory = Box::new(move |name: &str| {
            let buf = SharedBuf::default();
            bufs.borrow_mut().push((name.to_string(), buf.clone()));
            opener_for(&buf)
        });
        let base = SessionInfo { device: "TestPhone".to_string(), cpu_cores: 4, ..SessionInfo::default() };
        Telemetry::new(factory, base)
    }

    fn wait_for(mut f: impl FnMut() -> bool) -> bool {
        let start = Instant::now();
        while start.elapsed() < Duration::from_secs(5) {
            if f() {
                return true;
            }
            std::thread::sleep(Duration::from_millis(5));
        }
        false
    }

    fn run_frames_for(t: &mut Telemetry, ms: u64) -> bool {
        let start = Instant::now();
        let mut closed = false;
        while start.elapsed() < Duration::from_millis(ms) {
            probe::add_stage(Stage::Update, 3_000_000);
            probe::add_stage(Stage::Render, 3_000_000);
            probe::add_stage(Stage::Swap, 8_000_000);
            std::thread::sleep(Duration::from_millis(14));
            if t.end_frame(|| Gauges { screen: ScreenKind::Playing, in_world: true, workers: 2, ..Gauges::default() }) {
                closed = true;
            }
        }
        closed
    }

    #[test]
    fn switching_the_log_on_creates_a_file_with_a_header_and_per_second_lines() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.set_wanted(true, true, || "render 10, detail 10".to_string());
        assert!(t.logging());
        assert_eq!(files.borrow().len(), 1);
        let (name, buf) = files.borrow()[0].clone();
        assert!(name.starts_with("VoxelSandbox-log_") && name.ends_with(".txt"), "{}", name);
        assert!(run_frames_for(&mut t, 1300), "a second must have been closed");
        assert!(wait_for(|| buf.text().contains("PLAYING")), "{}", buf.text());
        let text = buf.text();
        assert!(text.contains("TestPhone") && text.contains("render 10, detail 10"), "{}", text);
        assert!(t.overlay_lines().map(|l| l.len() >= 2).unwrap_or(false));
        assert!(t.status_text().contains("TEST-BUFFER"), "{}", t.status_text());
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn switching_the_log_off_closes_the_file_and_on_again_starts_a_new_one() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.set_wanted(true, false, || String::new());
        t.set_wanted(false, false, || String::new());
        assert!(!t.logging());
        assert!(t.status_text().is_empty());
        assert!(!probe::enabled(), "nothing wants the measurements, so they must be off");
        let first = files.borrow()[0].1.clone();
        assert!(wait_for(|| first.text().contains("log stopped: switched off in the settings")), "{}", first.text());
        assert!(wait_for(|| first.text().contains("log closed")), "{}", first.text());
        t.set_wanted(true, false, || String::new());
        assert_eq!(files.borrow().len(), 2);
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn what_the_shell_learns_late_goes_into_the_header_of_the_next_log() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.session_mut().gpu = "Adreno (TM) 740".to_string();
        t.session_mut().screen = "2400x1080 px".to_string();
        t.set_wanted(true, false, || String::new());
        let buf = files.borrow()[0].1.clone();
        t.pause();
        let text = buf.text();
        assert!(text.contains("Adreno (TM) 740") && text.contains("2400x1080 px"), "{}", text);
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn repeated_calls_do_not_restart_the_log() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        for _ in 0..50 {
            t.set_wanted(true, true, || String::new());
        }
        assert_eq!(files.borrow().len(), 1);
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn pausing_gets_everything_into_the_file_before_returning() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.set_wanted(true, false, || String::new());
        let buf = files.borrow()[0].1.clone();
        t.pause();
        assert!(buf.text().contains("the app went to the background"), "{}", buf.text());
        t.resume();
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn screen_and_setting_changes_are_noted() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.set_wanted(true, false, || String::new());
        let buf = files.borrow()[0].1.clone();
        t.observe(ScreenKind::Menu, 10, 10, 100, 0, 0);
        t.observe(ScreenKind::Playing, 10, 10, 100, 0, 0);
        t.observe(ScreenKind::Playing, 500, 12, 100, 3, 4);
        t.pause();
        let text = buf.text();
        assert!(text.contains("screen: PLAYING"), "{}", text);
        assert!(text.contains("render distance 500 chunks, real-block radius 12 chunks"), "{}", text);
        assert!(!text.contains("screen: MENU"), "the first screen is not a change");
        t.shutdown();
        probe::set_enabled(false);
    }

    #[test]
    fn with_everything_off_a_frame_costs_nothing_and_writes_nothing() {
        let _g = test_lock();
        let files = Rc::new(RefCell::new(Vec::new()));
        let mut t = telemetry(files.clone());
        t.set_wanted(false, false, || String::new());
        for _ in 0..100 {
            assert!(!t.end_frame(|| panic!("the gauges must not be collected while the diagnostics are off")));
        }
        assert!(files.borrow().is_empty());
        assert!(t.overlay_lines().is_none());
    }
}
