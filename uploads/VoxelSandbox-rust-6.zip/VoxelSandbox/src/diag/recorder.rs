//! The game thread's side of the diagnostics. Once per frame it reads the stage timers, adds them to a
//! one-second window, and once per second it hands a finished `SecondSample` to the log writer thread.
//! The per-frame work is a few additions; nothing is formatted, allocated or written here.

use super::probe::{self, Counter, COUNTER_COUNT, STAGE_COUNT};
use super::report::{self, Kind, HITCH_MS};
use super::sample::{hist_bucket, Gauges, HitchSample, ScreenKind, SecondSample, HIST_BUCKETS};
use super::sink::{LogSender, Msg};
use crate::core::clock;

const WINDOW_NS: u64 = 1_000_000_000;
/// A gap this long between frames means the app was paused, not that a frame was slow.
const PAUSE_GAP_NS: u64 = 2_000_000_000;
const MAX_HITCH_LINES_PER_SECOND: u8 = 3;

struct Agg {
    frames: u32,
    interval_sum: u64,
    interval_max: u64,
    hist: [u16; HIST_BUCKETS],
    stage_sum: [u64; STAGE_COUNT],
    stage_max: [u64; STAGE_COUNT],
    worst_stages: [u64; STAGE_COUNT],
    hitches: u16,
    hitch_lines: u8,
}

impl Agg {
    fn new() -> Agg {
        Agg {
            frames: 0,
            interval_sum: 0,
            interval_max: 0,
            hist: [0; HIST_BUCKETS],
            stage_sum: [0; STAGE_COUNT],
            stage_max: [0; STAGE_COUNT],
            worst_stages: [0; STAGE_COUNT],
            hitches: 0,
            hitch_lines: 0,
        }
    }
}

/// The numbers the FPS overlay shows, refreshed once per second.
#[derive(Clone, Debug)]
pub struct Overlay {
    pub fps: f32,
    pub frame_ms: f32,
    pub update_ms: f32,
    pub render_ms: f32,
    pub swap_ms: f32,
    pub cpu_percent: f32,
    pub kind: Kind,
}

impl Overlay {
    fn empty() -> Overlay {
        Overlay { fps: 0.0, frame_ms: 0.0, update_ms: 0.0, render_ms: 0.0, swap_ms: 0.0, cpu_percent: 0.0, kind: Kind::Idle }
    }

    /// Short lines for the on-screen overlay.
    pub fn lines(&self) -> Vec<String> {
        let verdict = match self.kind {
            Kind::Idle => "IDLE",
            Kind::Smooth => "SMOOTH",
            Kind::Hitch => "HITCHES",
            Kind::Calculation => "LAG: CALCULATION",
            Kind::RenderCpu => "LAG: RENDER (CPU)",
            Kind::Gpu => "LAG: GPU/DISPLAY",
            Kind::Starved => "LAG: CPU STARVED",
        };
        vec![
            format!("FRAME {:.1}MS  UPDATE {:.1}  RENDER {:.1}  WAIT {:.1}", self.frame_ms, self.update_ms, self.render_ms, self.swap_ms),
            format!("GAME THREAD CPU {:.0}%  {}", self.cpu_percent, verdict),
        ]
    }
}

pub struct Recorder {
    sender: Option<LogSender>,
    agg: Agg,
    last_end: u64,
    window_start: u64,
    window_cpu_start: u64,
    stages: [u64; STAGE_COUNT],
    best_fps: f32,
    pub overlay: Overlay,
    /// The screen and queue sizes the next hitch line should mention (set by the shell each frame, cheaply).
    pub screen: ScreenKind,
    pub gen_queue: u32,
    pub mesh_queue: u32,
}

impl Recorder {
    pub fn new(sender: Option<LogSender>) -> Recorder {
        clock::init();
        Recorder {
            sender,
            agg: Agg::new(),
            last_end: 0,
            window_start: 0,
            window_cpu_start: 0,
            stages: [0; STAGE_COUNT],
            best_fps: 0.0,
            overlay: Overlay::empty(),
            screen: ScreenKind::Menu,
            gen_queue: 0,
            mesh_queue: 0,
        }
    }

    pub fn set_sender(&mut self, sender: Option<LogSender>) {
        self.sender = sender;
    }

    pub fn sender(&self) -> Option<&LogSender> {
        self.sender.as_ref()
    }

    pub fn logging(&self) -> bool {
        self.sender.is_some()
    }

    /// Writes a free-form event line (only builds the text when a log is open).
    pub fn event_with<F: FnOnce() -> String>(&self, make: F) {
        if let Some(s) = self.sender.as_ref() {
            s.event(make());
        }
    }

    /// Forget the previous frame's time: call when the app comes back from the background.
    pub fn resume(&mut self) {
        self.last_end = 0;
        self.window_start = 0;
        let mut scratch = [0u64; STAGE_COUNT];
        probe::take_stages(&mut scratch);
    }

    /// Ends a frame. Returns true when a one-second window is complete; the caller then gathers the
    /// gauges and calls `close_second`.
    pub fn end_frame(&mut self) -> bool {
        if !probe::enabled() {
            return false;
        }
        let now = clock::now_ns();
        probe::take_stages(&mut self.stages);
        if self.window_start == 0 {
            self.window_start = now;
            self.window_cpu_start = clock::thread_cpu_ns();
            self.last_end = now;
            return false;
        }
        let interval = now.saturating_sub(self.last_end);
        self.last_end = now;
        if interval >= PAUSE_GAP_NS {
            // the app was away: do not count it as a slow frame, and start a fresh window
            self.window_start = now;
            self.window_cpu_start = clock::thread_cpu_ns();
            self.agg = Agg::new();
            return false;
        }
        let a = &mut self.agg;
        a.frames += 1;
        a.interval_sum += interval;
        let ms = interval as f32 / 1e6;
        let bucket = hist_bucket(ms);
        a.hist[bucket] = a.hist[bucket].saturating_add(1);
        for i in 0..STAGE_COUNT {
            a.stage_sum[i] += self.stages[i];
            if self.stages[i] > a.stage_max[i] {
                a.stage_max[i] = self.stages[i];
            }
        }
        if interval > a.interval_max {
            a.interval_max = interval;
            a.worst_stages = self.stages;
        }
        if ms >= HITCH_MS {
            a.hitches = a.hitches.saturating_add(1);
            if a.hitch_lines < MAX_HITCH_LINES_PER_SECOND {
                a.hitch_lines += 1;
                if let Some(s) = self.sender.as_ref() {
                    s.send(Msg::Hitch(Box::new(HitchSample {
                        unix_ms: clock::unix_ms(),
                        interval_ns: interval,
                        stages_ns: self.stages,
                        screen: self.screen,
                        gen_queue: self.gen_queue,
                        mesh_queue: self.mesh_queue,
                    })));
                }
            }
        }
        now.saturating_sub(self.window_start) >= WINDOW_NS
    }

    /// Finishes the one-second window with a snapshot of what the engine is holding.
    pub fn close_second(&mut self, gauges: Gauges) {
        let now = clock::now_ns();
        let cpu_now = clock::thread_cpu_ns();
        let mut counters = [0u64; COUNTER_COUNT];
        probe::take_counters(&mut counters);
        let a = std::mem::replace(&mut self.agg, Agg::new());
        let sample = SecondSample {
            unix_ms: clock::unix_ms(),
            wall_ns: now.saturating_sub(self.window_start).max(1),
            frames: a.frames,
            interval_sum_ns: a.interval_sum,
            interval_max_ns: a.interval_max,
            hist: a.hist,
            stage_sum_ns: a.stage_sum,
            stage_max_ns: a.stage_max,
            worst_stages_ns: a.worst_stages,
            hitches: a.hitches,
            counters,
            main_cpu_ns: cpu_now.saturating_sub(self.window_cpu_start),
            gauges,
        };
        self.window_start = now;
        self.window_cpu_start = cpu_now;

        if sample.frames > 0 {
            self.best_fps = self.best_fps.max(sample.fps());
        }
        let verdict = report::judge(&sample, report::target_hz_from_best(self.best_fps));
        self.overlay = Overlay {
            fps: sample.fps(),
            frame_ms: sample.frame_ms(),
            update_ms: sample.stage_ms(probe::Stage::Update),
            render_ms: sample.stage_ms(probe::Stage::Render),
            swap_ms: sample.stage_ms(probe::Stage::Swap),
            cpu_percent: sample.main_cpu_percent(),
            kind: verdict.kind,
        };
        if let Some(s) = self.sender.as_ref() {
            s.send(Msg::Second(Box::new(sample)));
        }
    }
}

// keep the counter enum referenced so it is clear which counters the recorder reports
#[allow(dead_code)]
const _COUNTERS_USED: Counter = Counter::GenJobs;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::diag::probe::{test_lock, Stage};
    use crate::diag::sink::testing::{opener_for, SharedBuf};
    use crate::diag::sink::{start, SinkConfig};
    use std::time::{Duration, Instant};

    fn fake_frame(rec: &mut Recorder, work_ms: u64, wait_ms: u64) -> bool {
        probe::add_stage(Stage::Update, work_ms * 1_000_000);
        probe::add_stage(Stage::Render, work_ms * 1_000_000);
        probe::add_stage(Stage::Swap, wait_ms * 1_000_000);
        std::thread::sleep(Duration::from_millis(work_ms + wait_ms));
        rec.end_frame()
    }

    #[test]
    fn a_window_closes_after_a_second_with_averages_and_a_log_line() {
        let _g = test_lock();
        probe::set_enabled(true);
        let buf = SharedBuf::default();
        let log = start(opener_for(&buf), "# H\n".to_string(), SinkConfig::default());
        let mut rec = Recorder::new(Some(log.clone()));
        rec.screen = ScreenKind::Playing;
        let started = Instant::now();
        let mut closed = false;
        while started.elapsed() < Duration::from_secs(3) && !closed {
            if fake_frame(&mut rec, 4, 12) {
                rec.close_second(Gauges { screen: ScreenKind::Playing, in_world: true, workers: 2, ..Gauges::default() });
                closed = true;
            }
        }
        assert!(closed, "the window must close after about a second");
        assert!(rec.overlay.fps > 30.0 && rec.overlay.fps < 90.0, "fps {}", rec.overlay.fps);
        assert!(rec.overlay.update_ms > 3.0 && rec.overlay.update_ms < 8.0, "update {}", rec.overlay.update_ms);
        assert!(rec.overlay.swap_ms > 10.0, "swap {}", rec.overlay.swap_ms);
        assert!(log.flush_blocking(Duration::from_secs(5)));
        let text = buf.text();
        assert!(text.contains("PLAYING") && text.contains("swap-wait"), "{}", text);
        log.stop();
        probe::set_enabled(false);
    }

    #[test]
    fn a_slow_frame_makes_a_hitch_line() {
        let _g = test_lock();
        probe::set_enabled(true);
        let buf = SharedBuf::default();
        let log = start(opener_for(&buf), String::new(), SinkConfig::default());
        let mut rec = Recorder::new(Some(log.clone()));
        fake_frame(&mut rec, 2, 2);
        fake_frame(&mut rec, 2, 2);
        probe::add_stage(Stage::Upload, 90_000_000);
        probe::add_stage(Stage::Render, 90_000_000);
        std::thread::sleep(Duration::from_millis(90));
        rec.end_frame();
        assert!(log.flush_blocking(Duration::from_secs(5)));
        assert!(buf.text().contains("HITCH"), "{}", buf.text());
        log.stop();
        probe::set_enabled(false);
    }

    #[test]
    fn a_long_pause_is_not_a_hitch() {
        let _g = test_lock();
        probe::set_enabled(true);
        let mut rec = Recorder::new(None);
        fake_frame(&mut rec, 2, 2);
        fake_frame(&mut rec, 2, 2);
        rec.resume();
        std::thread::sleep(Duration::from_millis(30));
        rec.end_frame();
        rec.end_frame();
        assert_eq!(rec.agg.hitches, 0);
        probe::set_enabled(false);
    }

    #[test]
    fn disabled_probes_cost_nothing_and_record_nothing() {
        let _g = test_lock();
        probe::set_enabled(false);
        let mut rec = Recorder::new(None);
        for _ in 0..10 {
            assert!(!rec.end_frame());
        }
        assert_eq!(rec.agg.frames, 0);
    }

    #[test]
    fn the_per_frame_cost_is_tiny() {
        let _g = test_lock();
        probe::set_enabled(true);
        let mut rec = Recorder::new(None);
        rec.end_frame();
        let n = 200_000;
        let start = Instant::now();
        for _ in 0..n {
            let _a = probe::scope(Stage::Update);
            let _b = probe::scope(Stage::Render);
            let _c = probe::scope(Stage::DrawWorld);
            probe::count(Counter::DrawCalls, 300);
            if rec.end_frame() {
                rec.close_second(Gauges::default());
            }
        }
        let per_frame_ns = start.elapsed().as_nanos() as f64 / n as f64;
        probe::set_enabled(false);
        // three scopes, a counter and the end-of-frame bookkeeping, in a debug-ish build: far below a microsecond budget of 20 us
        assert!(per_frame_ns < 20_000.0, "diagnostics cost {:.0} ns per frame", per_frame_ns);
    }
}
