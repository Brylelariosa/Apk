//! Near-free instrumentation points.
//!
//! Code anywhere (the frame loop, the engine, the renderer, the worker threads) wraps a piece of work in
//! `let _t = probe::scope(Stage::Upload);` or bumps a counter with `probe::count(..)`. Both are a relaxed
//! atomic add; when the diagnostics are off they are a single relaxed load. Nothing is allocated, locked or
//! written here: the `Recorder` reads and resets the totals once per frame (stages) or per second (counters).

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use crate::core::clock;

/// A timed part of the main thread's frame. Stages nest: `Update` contains `Engine`, which contains
/// `Streaming`; `Render` contains `Upload`, `Cull`, `DrawWorld`, `DrawFar` and `DrawUi`.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(usize)]
pub enum Stage {
    /// Reading touch and key events.
    Input = 0,
    /// All game logic and UI building for the frame (`App::update`).
    Update,
    /// The game engine's tick: physics, flight, block interaction, world streaming.
    Engine,
    /// Keeping the world loaded around the player (scans, queue handling, pulling finished work).
    Streaming,
    /// Everything the renderer does on the CPU for the frame.
    Render,
    /// Copying finished meshes into GPU buffers.
    Upload,
    /// Working out what is visible and sorting it.
    Cull,
    /// Submitting the block-world draw calls.
    DrawWorld,
    /// Submitting the far-terrain draw calls.
    DrawFar,
    /// Drawing the menus and HUD.
    DrawUi,
    /// Waiting inside `eglSwapBuffers` (the display or GPU holding the frame back).
    Swap,
}

pub const STAGE_COUNT: usize = 11;

impl Stage {
    pub const ALL: [Stage; STAGE_COUNT] = [
        Stage::Input,
        Stage::Update,
        Stage::Engine,
        Stage::Streaming,
        Stage::Render,
        Stage::Upload,
        Stage::Cull,
        Stage::DrawWorld,
        Stage::DrawFar,
        Stage::DrawUi,
        Stage::Swap,
    ];

    pub fn name(self) -> &'static str {
        match self {
            Stage::Input => "input",
            Stage::Update => "update",
            Stage::Engine => "engine",
            Stage::Streaming => "streaming",
            Stage::Render => "render",
            Stage::Upload => "upload",
            Stage::Cull => "cull",
            Stage::DrawWorld => "draw-world",
            Stage::DrawFar => "draw-far",
            Stage::DrawUi => "draw-ui",
            Stage::Swap => "swap-wait",
        }
    }
}

/// Totals that background threads and the renderer add to; the recorder turns them into per-second rates.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(usize)]
pub enum Counter {
    GenJobs = 0,
    GenNs,
    MeshJobs,
    MeshNs,
    FarJobs,
    FarNs,
    UploadChunks,
    UploadBytes,
    UploadTiles,
    DrawCalls,
    Triangles,
    ChunksDrawn,
    TilesDrawn,
    /// Time worker threads spent with nothing to do.
    WorkerIdleNs,
}

pub const COUNTER_COUNT: usize = 14;

static ENABLED: AtomicBool = AtomicBool::new(false);

#[allow(clippy::declare_interior_mutable_const)]
const ZERO: AtomicU64 = AtomicU64::new(0);
static STAGE_NS: [AtomicU64; STAGE_COUNT] = [ZERO; STAGE_COUNT];
static COUNTERS: [AtomicU64; COUNTER_COUNT] = [ZERO; COUNTER_COUNT];

const OFF: u64 = u64::MAX;

/// Turns measuring on or off (off by default; the platform shell switches it on when the log or the overlay is).
pub fn set_enabled(on: bool) {
    ENABLED.store(on, Ordering::Relaxed);
}

#[inline]
pub fn enabled() -> bool {
    ENABLED.load(Ordering::Relaxed)
}

/// Times a stage until the returned guard is dropped.
pub struct Scope {
    stage: Stage,
    start: u64,
}

#[inline]
pub fn scope(stage: Stage) -> Scope {
    Scope { stage, start: if enabled() { clock::now_ns() } else { OFF } }
}

impl Drop for Scope {
    #[inline]
    fn drop(&mut self) {
        if self.start != OFF {
            add_stage(self.stage, clock::now_ns().saturating_sub(self.start));
        }
    }
}

#[inline]
pub fn add_stage(stage: Stage, ns: u64) {
    STAGE_NS[stage as usize].fetch_add(ns, Ordering::Relaxed);
}

/// Adds to a counter (does nothing while the diagnostics are off).
#[inline]
pub fn count(counter: Counter, n: u64) {
    if enabled() {
        COUNTERS[counter as usize].fetch_add(n, Ordering::Relaxed);
    }
}

/// Reads and resets the per-frame stage totals.
pub fn take_stages(out: &mut [u64; STAGE_COUNT]) {
    for (i, slot) in STAGE_NS.iter().enumerate() {
        out[i] = slot.swap(0, Ordering::Relaxed);
    }
}

/// Reads and resets the counters.
pub fn take_counters(out: &mut [u64; COUNTER_COUNT]) {
    for (i, slot) in COUNTERS.iter().enumerate() {
        out[i] = slot.swap(0, Ordering::Relaxed);
    }
}

#[cfg(test)]
pub(crate) fn test_lock() -> std::sync::MutexGuard<'static, ()> {
    use std::sync::{Mutex, OnceLock};
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(())).lock().unwrap_or_else(|e| e.into_inner())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scopes_add_up_only_while_enabled() {
        let _g = test_lock();
        let mut out = [0u64; STAGE_COUNT];
        set_enabled(false);
        take_stages(&mut out);
        {
            let _t = scope(Stage::Upload);
            std::thread::sleep(std::time::Duration::from_millis(2));
        }
        take_stages(&mut out);
        assert_eq!(out[Stage::Upload as usize], 0, "a disabled scope must not record");

        set_enabled(true);
        {
            let _t = scope(Stage::Upload);
            std::thread::sleep(std::time::Duration::from_millis(3));
        }
        take_stages(&mut out);
        assert!(out[Stage::Upload as usize] >= 2_000_000, "got {} ns", out[Stage::Upload as usize]);
        take_stages(&mut out);
        assert_eq!(out[Stage::Upload as usize], 0, "taking resets the totals");
        set_enabled(false);
    }

    #[test]
    fn counters_add_from_many_threads() {
        let _g = test_lock();
        set_enabled(true);
        let mut out = [0u64; COUNTER_COUNT];
        take_counters(&mut out);
        let handles: Vec<_> = (0..4)
            .map(|_| {
                std::thread::spawn(|| {
                    for _ in 0..1000 {
                        count(Counter::MeshJobs, 1);
                    }
                })
            })
            .collect();
        for h in handles {
            h.join().unwrap();
        }
        take_counters(&mut out);
        assert_eq!(out[Counter::MeshJobs as usize], 4000);
        set_enabled(false);
        count(Counter::MeshJobs, 5);
        take_counters(&mut out);
        assert_eq!(out[Counter::MeshJobs as usize], 0);
    }

    #[test]
    fn stage_and_counter_tables_are_complete() {
        for (i, s) in Stage::ALL.iter().enumerate() {
            assert_eq!(*s as usize, i);
            assert!(!s.name().is_empty());
        }
        assert_eq!(Counter::WorkerIdleNs as usize + 1, COUNTER_COUNT);
    }
}
