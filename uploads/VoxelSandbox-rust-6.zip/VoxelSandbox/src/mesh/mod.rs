//! CPU-side chunk meshing (no GL): vertices, the mesher and biome tinting.

pub mod biome_color;
pub mod mesher;
pub mod occlusion;
pub mod visibility;

use crate::world::config::SECTIONS;

/// One vertex. `color`: rgb = tint multiplier / 2 (so 128 is 1.0), a = baked shade (face, ambient
/// occlusion, depth). `info`: `[texture layer, tint mode, 0, 0]`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct Vertex {
    pub pos: [f32; 3],
    pub uv: [f32; 2],
    pub color: [u8; 4],
    pub info: [u8; 4],
}

pub const VERTEX_SIZE: usize = 28;

/// Draw groups inside one chunk mesh (index ranges of the shared buffer).
pub const PASS_OPAQUE: usize = 0;
/// Alpha-tested, back faces culled (leaves).
pub const PASS_CUTOUT: usize = 1;
/// Alpha-tested, both sides (plants).
pub const PASS_DOUBLE: usize = 2;
/// Translucent water.
pub const PASS_WATER: usize = 3;
pub const PASS_COUNT: usize = 4;

/// The mesh of one chunk column, in chunk-local coordinates.
pub struct ChunkMeshData {
    pub vertices: Vec<Vertex>,
    pub indices: Vec<u32>,
    /// `(first index, index count)` per pass.
    pub ranges: [(u32, u32); PASS_COUNT],
    /// Where each 16-block-high section of the column starts inside every pass: in pass `p`, section `s` owns
    /// `indices[section_starts[p][s]..section_starts[p][s + 1]]` (positions in the shared index buffer). The mesher
    /// walks the column from the bottom up, so a section's indices are contiguous.
    pub section_starts: [[u32; SECTIONS + 1]; PASS_COUNT],
    /// For every section, which pairs of its faces can see each other (see `visibility`).
    pub vis: [u16; SECTIONS],
    /// Lowest and highest block height with anything in it (0 and 0 for an empty mesh).
    pub min_y: f32,
    pub max_y: f32,
}

impl ChunkMeshData {
    /// A column with nothing to draw (all air).
    pub fn empty() -> ChunkMeshData {
        ChunkMeshData {
            vertices: Vec::new(),
            indices: Vec::new(),
            ranges: [(0, 0); PASS_COUNT],
            section_starts: [[0; SECTIONS + 1]; PASS_COUNT],
            vis: [visibility::OPEN; SECTIONS],
            min_y: 0.0,
            max_y: 0.0,
        }
    }

    pub fn is_empty(&self) -> bool {
        self.indices.is_empty()
    }

    /// Triangles over all passes.
    pub fn triangle_count(&self) -> usize {
        self.indices.len() / 3
    }
}
