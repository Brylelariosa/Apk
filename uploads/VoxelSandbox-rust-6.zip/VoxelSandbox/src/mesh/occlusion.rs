//! Occlusion culling for the block world: which 16-high sections of which chunk columns can be seen from the
//! camera at all, judged only from how open each section is (see `visibility`).
//!
//! The search starts in the camera's section and walks from section to section through their faces, but only
//! from the face it entered by to a face that can see it (a sealed cave is never entered). A straight line of
//! sight never goes both east and west (or both up and down), so the walk is done once for each of the eight
//! octants, in which only three of the six directions are allowed. Every path a line of sight can take is found,
//! so nothing visible is ever left out; sections that merely *might* be visible are kept (that is the price of
//! looking at faces instead of cells), and so are the sections right next to the camera's.
//!
//! The answer only changes when the camera moves into another section or a chunk is built, replaced or removed, so
//! the renderer asks again only then.

use super::visibility::{connected, OPEN};
use crate::world::config::SECTIONS;

/// One chunk column that has a mesh.
#[derive(Clone, Copy, Debug)]
pub struct Column {
    pub x: i32,
    pub z: i32,
    pub vis: [u16; SECTIONS],
}

/// Face numbers as in `visibility`: +x, -x, +y, -y, +z, -z.
const DX: [i32; 6] = [1, -1, 0, 0, 0, 0];
const DY: [i32; 6] = [0, 0, 1, -1, 0, 0];
const DZ: [i32; 6] = [0, 0, 0, 0, 1, -1];
const NO_FACE: u8 = 6;

/// Do not search an area bigger than this many columns (the answer is then "everything is visible").
const MAX_GRID_CELLS: i64 = 20_000;

#[derive(Clone, Copy)]
struct State {
    gx: u16,
    gz: u16,
    sy: u8,
    entered: u8,
}

/// Reusable working memory for `compute`.
pub struct Occlusion {
    /// Column index + 1 for every cell of the grid (0 = no mesh there).
    grid: Vec<u32>,
    /// The openness of every section of the grid (`OPEN` where there is no mesh: unknown counts as see-through).
    vis: Vec<u16>,
    /// Per section and octant: the faces it has already been entered by.
    done: Vec<u8>,
    /// Sections that can be seen.
    seen: Vec<bool>,
    stack: Vec<State>,
}

impl Default for Occlusion {
    fn default() -> Occlusion {
        Occlusion::new()
    }
}

impl Occlusion {
    pub fn new() -> Occlusion {
        Occlusion { grid: Vec::new(), vis: Vec::new(), done: Vec::new(), seen: Vec::new(), stack: Vec::new() }
    }

    /// Fills `out[i]` with the sections of `columns[i]` that can be seen from section `camera_section` of the
    /// column `(camera_x, camera_z)`: bit `s` set = section `s` (its faces) should be drawn.
    pub fn compute(&mut self, camera_x: i32, camera_z: i32, camera_section: usize, columns: &[Column], out: &mut Vec<u16>) {
        out.clear();
        out.resize(columns.len(), 0xFFFF);
        if columns.is_empty() {
            return;
        }
        let (mut min_x, mut max_x, mut min_z, mut max_z) = (camera_x, camera_x, camera_z, camera_z);
        for c in columns {
            min_x = min_x.min(c.x);
            max_x = max_x.max(c.x);
            min_z = min_z.min(c.z);
            max_z = max_z.max(c.z);
        }
        let w = (max_x - min_x + 1) as usize;
        let d = (max_z - min_z + 1) as usize;
        if (w as i64) * (d as i64) > MAX_GRID_CELLS || w > u16::MAX as usize || d > u16::MAX as usize {
            return;
        }
        let cells = w * d;
        self.grid.clear();
        self.grid.resize(cells, 0);
        self.vis.clear();
        self.vis.resize(cells * SECTIONS, OPEN);
        for (i, c) in columns.iter().enumerate() {
            let cell = (c.z - min_z) as usize * w + (c.x - min_x) as usize;
            self.grid[cell] = i as u32 + 1;
            self.vis[cell * SECTIONS..(cell + 1) * SECTIONS].copy_from_slice(&c.vis);
        }
        self.done.clear();
        self.done.resize(cells * SECTIONS * 8, 0);
        self.seen.clear();
        self.seen.resize(cells * SECTIONS, false);

        let start = State {
            gx: (camera_x - min_x) as u16,
            gz: (camera_z - min_z) as u16,
            sy: camera_section.min(SECTIONS - 1) as u8,
            entered: NO_FACE,
        };
        let start_index = (start.gz as usize * w + start.gx as usize) * SECTIONS + start.sy as usize;
        self.seen[start_index] = true;
        for octant in 0..8usize {
            let dirs = [if octant & 1 != 0 { 0usize } else { 1 }, if octant & 2 != 0 { 2usize } else { 3 }, if octant & 4 != 0 { 4usize } else { 5 }];
            self.stack.clear();
            self.stack.push(start);
            while let Some(s) = self.stack.pop() {
                let here = (s.gz as usize * w + s.gx as usize) * SECTIONS + s.sy as usize;
                let open = self.vis[here];
                for &dir in dirs.iter() {
                    if s.entered != NO_FACE && !connected(open, s.entered as usize, dir) {
                        continue;
                    }
                    let nx = s.gx as i32 + DX[dir];
                    let nz = s.gz as i32 + DZ[dir];
                    let ny = s.sy as i32 + DY[dir];
                    if nx < 0 || nz < 0 || nx >= w as i32 || nz >= d as i32 || ny < 0 || ny >= SECTIONS as i32 {
                        continue;
                    }
                    let there = (nz as usize * w + nx as usize) * SECTIONS + ny as usize;
                    let face = (dir ^ 1) as u8;
                    let slot = there * 8 + octant;
                    if self.done[slot] & (1 << face) != 0 {
                        continue;
                    }
                    self.done[slot] |= 1 << face;
                    self.seen[there] = true;
                    self.stack.push(State { gx: nx as u16, gz: nz as u16, sy: ny as u8, entered: face });
                }
            }
        }
        for (i, c) in columns.iter().enumerate() {
            let cell = (c.z - min_z) as usize * w + (c.x - min_x) as usize;
            let mut mask = 0u16;
            for s in 0..SECTIONS {
                if self.seen[cell * SECTIONS + s] {
                    mask |= 1 << s;
                }
            }
            out[i] = mask;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::terrain::TerrainGenerator;
    use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
    use crate::mesh::mesher::{build_chunk_mesh, MeshContext, MeshInput};
    use crate::mesh::visibility::{EAST, WEST};
    use crate::world::block::OPAQUE_BY_ID;
    use crate::world::chunk::ChunkData;
    use crate::world::config::WORLD_HEIGHT;
    use crate::world::pos::ChunkPos;
    use std::collections::HashMap;
    use std::sync::Arc;
    use std::time::Instant;

    fn strip(vis: impl Fn(i32) -> [u16; SECTIONS], len: i32) -> Vec<Column> {
        (0..len).map(|x| Column { x, z: 0, vis: vis(x) }).collect()
    }

    #[test]
    fn open_columns_are_all_visible() {
        let columns: Vec<Column> = (0..5).flat_map(|x| (0..5).map(move |z| Column { x, z, vis: [OPEN; SECTIONS] })).collect();
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(2, 2, 4, &columns, &mut out);
        assert_eq!(out.len(), columns.len());
        assert!(out.iter().all(|m| *m == 0xFFFF), "{:?}", out);
    }

    #[test]
    fn a_solid_column_hides_what_is_behind_it() {
        let columns = strip(|x| if x == 3 { [0; SECTIONS] } else { [OPEN; SECTIONS] }, 7);
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(0, 0, 4, &columns, &mut out);
        assert_eq!(out[1], 0xFFFF);
        assert_ne!(out[3], 0, "the face of the wall that looks at the camera is seen");
        assert_eq!(out[4], 0, "behind the wall nothing is seen");
        assert_eq!(out[6], 0);
        // from the other side of the wall the first columns are the hidden ones
        o.compute(6, 0, 4, &columns, &mut out);
        assert_eq!(out[0], 0);
        assert_eq!(out[2], 0);
        assert_ne!(out[4], 0);
    }

    #[test]
    fn a_tunnel_lets_the_view_through_and_a_sealed_column_does_not() {
        // only section 4 of every column is open, and only from west to east
        let tunnel = {
            let mut v = [0u16; SECTIONS];
            v[4] = (1 << 0) as u16; // pair bit 0 is (east, west)
            assert!(connected(v[4], EAST, WEST));
            v
        };
        let columns = strip(|x| if x == 4 { [0; SECTIONS] } else { tunnel }, 8);
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(0, 0, 4, &columns, &mut out);
        assert_ne!(out[1] & (1 << 4), 0, "the tunnel is seen along its length");
        assert_ne!(out[3] & (1 << 4), 0);
        assert_ne!(out[4], 0, "the plug is seen");
        assert_eq!(out[5], 0, "but nothing behind it");
        assert_eq!(out[1] & (1 << 8), 0, "rock beside the tunnel is not entered");
    }

    #[test]
    fn the_sections_next_to_the_camera_are_always_seen() {
        let columns: Vec<Column> = (0..3).flat_map(|x| (0..3).map(move |z| Column { x, z, vis: [0; SECTIONS] })).collect();
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(1, 1, 5, &columns, &mut out);
        let centre = out[1 * 3 + 1]; // index of (x = 1, z = 1) in the column order above
        assert_ne!(centre & (1 << 5), 0);
        assert_ne!(centre & (1 << 4), 0, "the floor under the camera");
        assert_ne!(centre & (1 << 6), 0, "the ceiling over the camera");
        assert_eq!(centre & (1 << 9), 0);
    }

    #[test]
    fn a_camera_outside_every_column_still_gets_an_answer() {
        let columns = strip(|_| [OPEN; SECTIONS], 3);
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(50, 50, 3, &columns, &mut out);
        assert_eq!(out.len(), 3);
        assert!(out.iter().all(|m| *m != 0));
    }

    #[test]
    fn a_huge_area_falls_back_to_everything_visible() {
        let columns = vec![Column { x: 0, z: 0, vis: [0; SECTIONS] }, Column { x: 5000, z: 5000, vis: [0; SECTIONS] }];
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(0, 0, 0, &columns, &mut out);
        assert_eq!(out, vec![0xFFFF, 0xFFFF]);
    }

    // ---------------------------------------------------------------- the check against real terrain

    struct Region {
        chunks: HashMap<(i32, i32), ChunkData>,
    }

    impl Region {
        fn raw(&self, x: i32, y: i32, z: i32) -> u8 {
            if y < 0 || y >= WORLD_HEIGHT {
                return 0;
            }
            match self.chunks.get(&(x.div_euclid(16), z.div_euclid(16))) {
                Some(c) => c.get_raw(x.rem_euclid(16), y, z.rem_euclid(16)),
                None => 0,
            }
        }

        fn opaque(&self, x: i32, y: i32, z: i32) -> bool {
            OPAQUE_BY_ID[(self.raw(x, y, z) & 31) as usize]
        }
    }

    /// Walks a ray through the cells and notes every section whose faces could be seen along it: the see-through
    /// cells it passes through and the solid cell it stops at.
    fn trace(region: &Region, origin: [f64; 3], dir: [f64; 3], max_len: f64, hit: &mut impl FnMut(i32, i32, usize)) {
        let mut cell = [origin[0].floor() as i32, origin[1].floor() as i32, origin[2].floor() as i32];
        let mut step = [0i32; 3];
        let mut t_max = [f64::MAX; 3];
        let mut t_delta = [f64::MAX; 3];
        for a in 0..3 {
            if dir[a] > 0.0 {
                step[a] = 1;
                t_delta[a] = 1.0 / dir[a];
                t_max[a] = (cell[a] as f64 + 1.0 - origin[a]) / dir[a];
            } else if dir[a] < 0.0 {
                step[a] = -1;
                t_delta[a] = -1.0 / dir[a];
                t_max[a] = (origin[a] - cell[a] as f64) / -dir[a];
            }
        }
        loop {
            if cell[1] < 0 || cell[1] >= WORLD_HEIGHT {
                return;
            }
            let (cx, cz) = (cell[0].div_euclid(16), cell[2].div_euclid(16));
            if !region.chunks.contains_key(&(cx, cz)) {
                return;
            }
            hit(cx, cz, (cell[1] / 16) as usize);
            if region.opaque(cell[0], cell[1], cell[2]) {
                return;
            }
            let axis = if t_max[0] <= t_max[1] && t_max[0] <= t_max[2] {
                0
            } else if t_max[1] <= t_max[2] {
                1
            } else {
                2
            };
            if t_max[axis] > max_len {
                return;
            }
            t_max[axis] += t_delta[axis];
            cell[axis] += step[axis];
        }
    }

    struct Rng(u64);
    impl Rng {
        fn next(&mut self) -> f64 {
            self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            ((self.0 >> 33) as f64) / ((1u64 << 31) as f64)
        }
        fn direction(&mut self) -> [f64; 3] {
            loop {
                let v = [self.next() * 2.0 - 1.0, self.next() * 2.0 - 1.0, self.next() * 2.0 - 1.0];
                let len2 = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
                if len2 > 0.01 && len2 <= 1.0 {
                    let len = len2.sqrt();
                    return [v[0] / len, v[1] / len, v[2] / len];
                }
            }
        }
    }

    fn build_region(seed: i64, cx: i32, cz: i32, radius: i32) -> (Region, Vec<Column>, Vec<[u32; SECTIONS]>) {
        let gen = TerrainGenerator::new(seed);
        let ctx = MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        };
        let mut chunks = HashMap::new();
        for dz in -(radius + 1)..=(radius + 1) {
            for dx in -(radius + 1)..=(radius + 1) {
                chunks.insert((cx + dx, cz + dz), gen.generate(ChunkPos::new(cx + dx, cz + dz)));
            }
        }
        let mut columns = Vec::new();
        let mut counts = Vec::new();
        for dz in -radius..=radius {
            for dx in -radius..=radius {
                let mut arr: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
                for oz in -1..=1 {
                    for ox in -1..=1 {
                        arr[((oz + 1) * 3 + (ox + 1)) as usize] = chunks.get(&(cx + dx + ox, cz + dz + oz)).cloned();
                    }
                }
                let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(cx + dx, cz + dz), chunks: arr, merge: false }, &ctx);
                columns.push(Column { x: cx + dx, z: cz + dz, vis: mesh.vis });
                let mut per_section = [0u32; SECTIONS];
                for sec in 0..SECTIONS {
                    for pass in 0..4 {
                        per_section[sec] += mesh.section_starts[pass][sec + 1] - mesh.section_starts[pass][sec];
                    }
                }
                counts.push(per_section);
            }
        }
        // only the meshed columns take part in the check
        let meshed: Vec<(i32, i32)> = columns.iter().map(|c| (c.x, c.z)).collect();
        chunks.retain(|k, _| meshed.contains(k));
        (Region { chunks }, columns, counts)
    }

    /// Open cells to put the camera in: a few above the ground and a few inside caves.
    fn camera_spots(region: &Region, cx: i32, cz: i32, wanted: usize) -> Vec<[i32; 3]> {
        let mut surface = Vec::new();
        let mut caves = Vec::new();
        let mut rng = Rng(99);
        for _ in 0..4000 {
            let x = cx * 16 + (rng.next() * 16.0) as i32;
            let z = cz * 16 + (rng.next() * 16.0) as i32;
            let mut top = WORLD_HEIGHT - 1;
            while top > 0 && !region.opaque(x, top, z) {
                top -= 1;
            }
            if surface.len() < wanted {
                surface.push([x, top + 2, z]);
            }
            if caves.len() < wanted {
                let y = 8 + (rng.next() * (top as f64 - 16.0).max(1.0)) as i32;
                if y < top - 6 && !region.opaque(x, y, z) && !region.opaque(x, y + 1, z) {
                    caves.push([x, y, z]);
                }
            }
        }
        surface.extend(caves);
        surface
    }

    #[test]
    fn nothing_that_can_be_seen_is_ever_culled() {
        let mut checked_rays = 0u64;
        let mut seen_sections_total = 0usize;
        let mut kept_sections_total = 0usize;
        let mut kept_indices = 0u64;
        let mut all_indices = 0u64;
        for (seed, cx, cz) in [(555i64, 0, 0), (7, 4, -3), (1234, -6, 5)] {
            let radius = 3;
            let (region, columns, counts) = build_region(seed, cx, cz, radius);
            let index: HashMap<(i32, i32), usize> = columns.iter().enumerate().map(|(i, c)| ((c.x, c.z), i)).collect();
            let mut occlusion = Occlusion::new();
            let mut out = Vec::new();
            for spot in camera_spots(&region, cx, cz, 6) {
                let origin = [spot[0] as f64 + 0.5, spot[1] as f64 + 0.5, spot[2] as f64 + 0.5];
                let (ccx, ccz) = (spot[0].div_euclid(16), spot[2].div_euclid(16));
                let section = (spot[1] / 16) as usize;
                occlusion.compute(ccx, ccz, section, &columns, &mut out);
                let mut truly_seen: std::collections::HashSet<(i32, i32, usize)> = std::collections::HashSet::new();
                let mut rng = Rng((spot[0] as i64 * 31 + spot[1] as i64 * 17 + spot[2] as i64) as u64);
                for _ in 0..3000 {
                    let dir = rng.direction();
                    checked_rays += 1;
                    trace(&region, origin, dir, 60.0, &mut |x, z, s| {
                        truly_seen.insert((x, z, s));
                    });
                }
                for (x, z, s) in truly_seen.iter() {
                    let i = index[&(*x, *z)];
                    assert!(
                        out[i] & (1 << s) != 0,
                        "seed {} camera {:?}: section {} of chunk ({}, {}) can be seen by a ray but was culled (mask {:016b})",
                        seed,
                        spot,
                        s,
                        x,
                        z,
                        out[i]
                    );
                }
                seen_sections_total += truly_seen.len();
                kept_sections_total += out.iter().map(|m| m.count_ones() as usize).sum::<usize>();
                for (i, mask) in out.iter().enumerate() {
                    for sec in 0..SECTIONS {
                        all_indices += counts[i][sec] as u64;
                        if mask & (1 << sec) != 0 {
                            kept_indices += counts[i][sec] as u64;
                        }
                    }
                }
            }
        }
        // the point of the whole thing: far fewer sections are kept than there are, but never fewer than are seen
        assert!(kept_sections_total >= seen_sections_total);
        eprintln!(
            "occlusion check: {} rays, {} sections really seen, {} kept; {:.1}% of the triangles are kept",
            checked_rays,
            seen_sections_total,
            kept_sections_total,
            kept_indices as f64 * 100.0 / all_indices as f64
        );
        assert!(kept_indices * 10 < all_indices * 8, "culling should remove at least a fifth of the triangles ({} of {})", kept_indices, all_indices);
    }

    #[test]
    fn the_search_is_quick_enough_to_run_when_the_camera_changes_section() {
        // 2500 columns (a detail radius of 25): a typical terrain mix
        let gen = TerrainGenerator::new(1234);
        let sample = gen.generate(ChunkPos::new(0, 0));
        let ctx = MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        };
        let mut arr: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
        for slot in arr.iter_mut() {
            *slot = Some(sample.clone());
        }
        let vis = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks: arr, merge: false }, &ctx).vis;
        let columns: Vec<Column> = (-25..=25).flat_map(|x| (-25..=25).map(move |z| Column { x, z, vis })).collect();
        let mut o = Occlusion::new();
        let mut out = Vec::new();
        o.compute(0, 0, 4, &columns, &mut out); // warm up the buffers
        let start = Instant::now();
        let runs = 20;
        for _ in 0..runs {
            o.compute(0, 0, 4, &columns, &mut out);
        }
        let ms = start.elapsed().as_secs_f64() * 1000.0 / runs as f64;
        eprintln!("occlusion search over {} columns: {:.2} ms", columns.len(), ms);
        assert!(ms < 12.0, "{} ms is too slow", ms);
    }
}
