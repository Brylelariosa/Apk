//! How open a 16x16x16 section is: which of its six faces can "see" each other through see-through cells.
//!
//! The renderer uses this for occlusion culling. Starting from the section the camera is in, it walks from
//! section to section, and only walks through a section from the face it came in by to a face that can see it.
//! A cave that is sealed off by solid rock is never reached, so its walls are not drawn at all.
//!
//! The answer for one section is a 15-bit mask: one bit for every unordered pair of faces.

/// Face numbers: +x, -x, +y, -y, +z, -z. The opposite face is `face ^ 1`.
pub const EAST: usize = 0;
pub const WEST: usize = 1;
pub const UP: usize = 2;
pub const DOWN: usize = 3;
pub const SOUTH: usize = 4;
pub const NORTH: usize = 5;

/// Every pair of faces can see each other (an empty section).
pub const OPEN: u16 = 0x7FFF;

/// Cells in a section.
pub const CELLS: usize = 4096;
const WORDS: usize = CELLS / 64;

/// `PAIR[a][b]`: the bit for the faces `a` and `b` (the same bit for `(b, a)`; unused for `a == b`).
const PAIR: [[u8; 6]; 6] = build_pairs();

const fn build_pairs() -> [[u8; 6]; 6] {
    let mut table = [[0u8; 6]; 6];
    let mut bit = 0u8;
    let mut a = 0;
    while a < 6 {
        let mut b = a + 1;
        while b < 6 {
            table[a][b] = bit;
            table[b][a] = bit;
            bit += 1;
            b += 1;
        }
        a += 1;
    }
    table
}

/// True when something entering the section through face `a` can leave it through face `b`.
#[inline]
pub fn connected(vis: u16, a: usize, b: usize) -> bool {
    a != b && vis & (1u16 << PAIR[a][b]) != 0
}

#[inline]
fn bit(words: &[u64; WORDS], i: usize) -> bool {
    words[i >> 6] >> (i & 63) & 1 != 0
}

#[inline]
fn set(words: &mut [u64; WORDS], i: usize) {
    words[i >> 6] |= 1u64 << (i & 63);
}

/// Builds the bitset `section_connectivity` wants from a per-cell test (`i = (y * 16 + z) * 16 + x`).
pub fn open_cells(mut is_open: impl FnMut(usize) -> bool) -> [u64; WORDS] {
    let mut words = [0u64; WORDS];
    for i in 0..CELLS {
        if is_open(i) {
            set(&mut words, i);
        }
    }
    words
}

/// Which pairs of faces of a section are joined by a path of open cells (`open`: one bit per cell,
/// `i = (y * 16 + z) * 16 + x`; paths move between cells that share a face).
pub fn section_connectivity(open: &[u64; WORDS]) -> u16 {
    let count: u32 = open.iter().map(|w| w.count_ones()).sum();
    if count == 0 {
        return 0;
    }
    if count as usize == CELLS {
        return OPEN;
    }
    let mut seen = [0u64; WORDS];
    let mut stack = [0u16; CELLS];
    let mut vis = 0u16;
    for w in 0..WORDS {
        loop {
            let pending = open[w] & !seen[w];
            if pending == 0 {
                break;
            }
            let start = (w << 6) + pending.trailing_zeros() as usize;
            let mut faces = 0u8;
            let mut top = 0usize;
            set(&mut seen, start);
            stack[0] = start as u16;
            top += 1;
            while top > 0 {
                top -= 1;
                let c = stack[top] as usize;
                let x = c & 15;
                let z = (c >> 4) & 15;
                let y = c >> 8;
                if x == 0 {
                    faces |= 1 << WEST;
                } else if bit(open, c - 1) && !bit(&seen, c - 1) {
                    set(&mut seen, c - 1);
                    stack[top] = (c - 1) as u16;
                    top += 1;
                }
                if x == 15 {
                    faces |= 1 << EAST;
                } else if bit(open, c + 1) && !bit(&seen, c + 1) {
                    set(&mut seen, c + 1);
                    stack[top] = (c + 1) as u16;
                    top += 1;
                }
                if z == 0 {
                    faces |= 1 << NORTH;
                } else if bit(open, c - 16) && !bit(&seen, c - 16) {
                    set(&mut seen, c - 16);
                    stack[top] = (c - 16) as u16;
                    top += 1;
                }
                if z == 15 {
                    faces |= 1 << SOUTH;
                } else if bit(open, c + 16) && !bit(&seen, c + 16) {
                    set(&mut seen, c + 16);
                    stack[top] = (c + 16) as u16;
                    top += 1;
                }
                if y == 0 {
                    faces |= 1 << DOWN;
                } else if bit(open, c - 256) && !bit(&seen, c - 256) {
                    set(&mut seen, c - 256);
                    stack[top] = (c - 256) as u16;
                    top += 1;
                }
                if y == 15 {
                    faces |= 1 << UP;
                } else if bit(open, c + 256) && !bit(&seen, c + 256) {
                    set(&mut seen, c + 256);
                    stack[top] = (c + 256) as u16;
                    top += 1;
                }
            }
            if faces.count_ones() >= 2 {
                for a in 0..6 {
                    if faces >> a & 1 == 0 {
                        continue;
                    }
                    for b in (a + 1)..6 {
                        if faces >> b & 1 != 0 {
                            vis |= 1u16 << PAIR[a][b];
                        }
                    }
                }
                if vis == OPEN {
                    return vis;
                }
            }
        }
    }
    vis
}

#[cfg(test)]
mod tests {
    use super::*;

    fn index(x: usize, y: usize, z: usize) -> usize {
        (y * 16 + z) * 16 + x
    }

    fn all_pairs() -> Vec<(usize, usize)> {
        let mut v = Vec::new();
        for a in 0..6 {
            for b in (a + 1)..6 {
                v.push((a, b));
            }
        }
        v
    }

    #[test]
    fn pair_bits_are_distinct_and_symmetric() {
        let mut seen = 0u16;
        for (a, b) in all_pairs() {
            let bit = 1u16 << PAIR[a][b];
            assert_eq!(PAIR[a][b], PAIR[b][a]);
            assert_eq!(seen & bit, 0, "pair {} {} reuses a bit", a, b);
            seen |= bit;
        }
        assert_eq!(seen, OPEN);
    }

    #[test]
    fn empty_and_solid_sections() {
        assert_eq!(section_connectivity(&open_cells(|_| true)), OPEN);
        assert_eq!(section_connectivity(&open_cells(|_| false)), 0);
    }

    #[test]
    fn a_tunnel_joins_exactly_its_two_ends() {
        // a one-cell tunnel along x through the middle of solid rock
        let open = open_cells(|i| i >> 8 == 8 && (i >> 4) & 15 == 8);
        let v = section_connectivity(&open);
        assert!(connected(v, EAST, WEST));
        assert!(!connected(v, EAST, UP));
        assert!(!connected(v, UP, DOWN));
        assert_eq!(v.count_ones(), 1);
    }

    #[test]
    fn a_bend_joins_the_faces_it_touches() {
        // along x at y = 3, z = 3, then up the column at x = 15 (so it touches west, east and up)
        let open = open_cells(|i| {
            let (x, y, z) = (i & 15, i >> 8, (i >> 4) & 15);
            (y == 3 && z == 3) || (x == 15 && z == 3)
        });
        let v = section_connectivity(&open);
        assert!(connected(v, WEST, EAST));
        assert!(connected(v, WEST, UP));
        assert!(connected(v, EAST, UP));
        assert!(connected(v, EAST, DOWN));
        assert!(!connected(v, NORTH, SOUTH));
    }

    #[test]
    fn two_separate_tunnels_are_not_joined_to_each_other() {
        // one along x low down, one along z high up: they never touch
        let open = open_cells(|i| {
            let (x, y, z) = (i & 15, i >> 8, (i >> 4) & 15);
            (y == 2 && z == 2) || (y == 12 && x == 5)
        });
        let v = section_connectivity(&open);
        assert!(connected(v, EAST, WEST));
        assert!(connected(v, NORTH, SOUTH));
        assert!(!connected(v, EAST, SOUTH));
        assert!(!connected(v, WEST, NORTH));
        assert_eq!(v.count_ones(), 2);
    }

    #[test]
    fn a_wall_across_the_middle_blocks_everything() {
        // a solid plate at y = 8 with open cells on both sides: the lower half and upper half are separate
        let open = open_cells(|i| i >> 8 != 8);
        let v = section_connectivity(&open);
        assert!(!connected(v, UP, DOWN));
        assert!(connected(v, EAST, WEST), "each half still joins its own sides");
        assert!(connected(v, DOWN, EAST));
        assert!(connected(v, UP, NORTH));
    }

    #[test]
    fn cells_that_only_touch_at_a_corner_are_not_joined() {
        // two cells that touch only along an edge do not make a path (paths need a shared face)
        let a = index(0, 0, 0);
        let b = index(1, 1, 0);
        let open = open_cells(|i| i == a || i == b);
        let v = section_connectivity(&open);
        // each lone cell touches several faces on its own, but (0,0,0) and (1,1,0) are separate components
        assert!(connected(v, WEST, DOWN));
        assert!(!connected(v, EAST, UP));
    }

    #[test]
    fn opposite_faces_differ_by_one_bit() {
        for f in 0..6 {
            assert_eq!(f ^ 1 ^ 1, f);
        }
        assert_eq!(EAST ^ 1, WEST);
        assert_eq!(UP ^ 1, DOWN);
        assert_eq!(SOUTH ^ 1, NORTH);
    }
}
