#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 8: Reality Lock. The spec asks to protect "faces, eyes, text,
// corners, straight lines, thin structures" from aggressive restoration.
// Doing that with an actual face/eye detector would mean shipping a
// pretrained classifier, which the spec explicitly rules out — so this
// protects the same *kind* of content a different way: it identifies
// structurally important pixels directly from the image itself (strong
// edges via gradient magnitude, and corner-like points via a classical
// Harris corner response, both zero-training closed-form measures) and
// dials restoration strength down wherever they're found. Corners, line
// junctions and fine text strokes score highly on both cues; so, usually,
// do eyes and facial features, without needing to know what a "face" is.
class RealityLock {
public:
    // edgeMagnitude: Sobel magnitude of the *original* tile (already
    // computed once per tile by the orchestrator; passed in to avoid
    // recomputing it).
    static FloatImage protect(const FloatImage& restoredY, const FloatImage& originalY,
                               const FloatImage& edgeMagnitude, float protectionStrength);
};

} // namespace crystal
