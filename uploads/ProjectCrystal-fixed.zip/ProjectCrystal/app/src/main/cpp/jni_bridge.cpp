// JNI entry points for Project Crystal's native restoration engine.
//
// Deliberately a single processImage() crossing per run rather than one
// call per pipeline stage: marshalling full-resolution image buffers across
// JNI is the expensive part, so the whole Stage 1-9 pipeline
// (RestorationEngine::run) executes natively in one call, and only the
// final restored bitmap plus small, downsampled diagnostic maps cross back.
// The pipeline itself stays modularized into per-stage classes (see
// restoration_engine.cpp and its includes) for readability and unit
// testability — this file is purely the boundary, not where any algorithm
// lives.

#include <jni.h>
#include <android/log.h>
#include "restoration_engine.h"
#include "jni_utils.h"
#include "blur_estimator.h"
#include "edge_aware_enhancer.h"

#define LOG_TAG "CrystalNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace crystal;

extern "C" JNIEXPORT jobject JNICALL
Java_com_projectcrystal_app_core_native_NativeImageProcessor_processImage(
        JNIEnv* env, jobject /* thiz */,
        jobject inputBitmap, jobject outputBitmap,
        jfloatArray params, jint specialMode, jboolean conservativeMode,
        jint mapMaxDimension) {

    FloatImage input = jniutil::bitmapToFloatImage(env, inputBitmap);
    if (input.empty()) {
        return nullptr; // exception already thrown by bitmapToFloatImage
    }

    RestorationParams restorationParams = jniutil::unpackParams(env, params, specialMode, conservativeMode);
    if (env->ExceptionCheck()) {
        return nullptr;
    }

    LOGI("processImage: %dx%d, tileSize=%d, conservative=%d", input.width(), input.height(),
         restorationParams.tileSize, restorationParams.conservativeMode);

    PipelineOutput result = RestorationEngine::run(input, restorationParams);

    jniutil::floatImageToBitmap(env, outputBitmap, result.restored);
    if (env->ExceptionCheck()) {
        return nullptr;
    }

    LOGI("processImage done in %.1fms across %d tiles, realityScore=%.2f",
         result.stats.totalMs, result.stats.tileCount, result.realityScore);

    return jniutil::buildMetricsObject(env, result, mapMaxDimension);
}

// Lightweight, single-tile-sized entry point used by the live slider
// preview in the editor (Stage 3/6 only — sharpen + halo suppression — on a
// small crop around the user's last touch point). Kept separate from
// processImage() rather than overloading it with a "preview mode" flag,
// since the two have very different performance budgets and this one is
// deliberately allowed to skip Stages 1-2 tiling entirely.
extern "C" JNIEXPORT void JNICALL
Java_com_projectcrystal_app_core_native_NativeImageProcessor_quickPreview(
        JNIEnv* env, jobject /* thiz */,
        jobject inputBitmap, jobject outputBitmap,
        jfloat sharpness, jfloat haloSuppression) {

    FloatImage input = jniutil::bitmapToFloatImage(env, inputBitmap);
    if (input.empty()) return;

    FloatImage ycbcr = input.toYCbCr();
    FloatImage y = ycbcr.channel(0);

    BlurEstimator::Estimate blur = BlurEstimator::estimate(y);
    FloatImage sharpened = EdgeAwareEnhancer::sharpen(y, sharpness, 2.0f + blur.radius, haloSuppression);

    ycbcr.setChannel(0, sharpened);
    FloatImage rgb = FloatImage::fromYCbCr(ycbcr);

    jniutil::floatImageToBitmap(env, outputBitmap, rgb);
}
