#include "edge_aware_enhancer.h"
#include "convolution.h"
#include <algorithm>
#include <cmath>

namespace crystal {

FloatImage EdgeAwareEnhancer::guidedFilter(const FloatImage& guide, const FloatImage& src, int radius, float eps) {
    // Closed-form local linear model: q = a*I + b, fit per-window by least
    // squares, then a/b themselves are averaged across overlapping windows.
    // All of it reduces to box filters, so this is just a handful of mean
    // filters plus elementwise arithmetic — no external solver needed.
    FloatImage meanI = conv::boxBlur(guide, radius);
    FloatImage meanP = conv::boxBlur(src, radius);

    const int n = guide.width() * guide.height();
    FloatImage corrI(guide.width(), guide.height(), 1);
    FloatImage corrIp(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        corrI.raw()[i] = guide.raw()[i] * guide.raw()[i];
        corrIp.raw()[i] = guide.raw()[i] * src.raw()[i];
    }
    corrI = conv::boxBlur(corrI, radius);
    corrIp = conv::boxBlur(corrIp, radius);

    FloatImage a(guide.width(), guide.height(), 1), b(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        float varI = corrI.raw()[i] - meanI.raw()[i] * meanI.raw()[i];
        float covIp = corrIp.raw()[i] - meanI.raw()[i] * meanP.raw()[i];
        a.raw()[i] = covIp / (varI + eps);
        b.raw()[i] = meanP.raw()[i] - a.raw()[i] * meanI.raw()[i];
    }

    FloatImage meanA = conv::boxBlur(a, radius);
    FloatImage meanB = conv::boxBlur(b, radius);

    FloatImage out(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        out.raw()[i] = meanA.raw()[i] * guide.raw()[i] + meanB.raw()[i];
    }
    return out;
}

FloatImage EdgeAwareEnhancer::sharpen(const FloatImage& tileY, float amount, float radius, float haloSuppression) {
    int r = std::max(1, static_cast<int>(std::round(radius)));
    FloatImage base = guidedFilter(tileY, tileY, r, 1e-4f);

    const int n = tileY.width() * tileY.height();
    FloatImage out(tileY.width(), tileY.height(), 1);

    // Overshoot clamp: near an edge, don't let the boosted value exceed the
    // original local [min, max] range by more than a haloSuppression-scaled
    // margin. This is the "prevent halos at the source" half of artifact
    // control; ArtifactDetector (Stage 6) catches whatever slips through.
    FloatImage localMin(tileY.width(), tileY.height(), 1), localMax(tileY.width(), tileY.height(), 1);
    for (int y = 0; y < tileY.height(); ++y) {
        for (int x = 0; x < tileY.width(); ++x) {
            float mn = 1e9f, mx = -1e9f;
            for (int dy = -1; dy <= 1; ++dy) {
                for (int dx = -1; dx <= 1; ++dx) {
                    float v = tileY.sampleClamped(x + dx, y + dy, 0);
                    mn = std::min(mn, v);
                    mx = std::max(mx, v);
                }
            }
            localMin.at(x, y, 0) = mn;
            localMax.at(x, y, 0) = mx;
        }
    }

    float margin = (1.0f - haloSuppression) * 0.25f + 0.02f; // more suppression -> tighter clamp
    for (int i = 0; i < n; ++i) {
        float detail = tileY.raw()[i] - base.raw()[i];
        float boosted = tileY.raw()[i] + amount * detail;
        float lo = localMin.raw()[i] - margin;
        float hi = localMax.raw()[i] + margin;
        out.raw()[i] = std::clamp(boosted, lo, hi);
    }
    out.clamp(0.0f, 1.0f);
    return out;
}

FloatImage EdgeAwareEnhancer::localContrast(const FloatImage& tileY, float amount) {
    // Same detail-boost idea as sharpen(), but with a much larger radius so
    // it acts on mid-frequency tonal structure ("clarity") rather than fine
    // edges, and no overshoot clamp — this is meant to be gentle by
    // construction (small `amount`) rather than clamp-limited.
    int radius = std::max(4, tileY.width() / 8);
    FloatImage base = guidedFilter(tileY, tileY, radius, 1e-3f);
    FloatImage out(tileY.width(), tileY.height(), 1);
    for (int i = 0; i < tileY.width() * tileY.height(); ++i) {
        float detail = tileY.raw()[i] - base.raw()[i];
        out.raw()[i] = std::clamp(tileY.raw()[i] + amount * detail, 0.0f, 1.0f);
    }
    return out;
}

} // namespace crystal
