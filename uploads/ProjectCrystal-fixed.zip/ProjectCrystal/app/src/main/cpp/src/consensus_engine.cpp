#include "consensus_engine.h"
#include <cmath>
#include <algorithm>

namespace crystal {

ConsensusEngine::Result ConsensusEngine::combine(const std::vector<FloatImage>& candidatesY,
                                                  const FloatImage& originalY, bool conservativeMode) {
    Result result;
    const int w = originalY.width(), h = originalY.height();
    result.image = FloatImage(w, h, 1);
    result.confidenceMap = FloatImage(w, h, 1);

    if (candidatesY.empty()) {
        // No candidates to reconcile: fall back to the original untouched.
        // Only reachable if a future caller passes an empty candidate set;
        // RestorationEngine::run always supplies exactly four.
        result.image = originalY.clone();
        result.realityScore = 0.0f;
        return result;
    }

    // Agreement threshold: candidate spread (standard deviation) below this
    // is treated as "the methods agree" and gets averaged; above it, the
    // methods disagree and the most conservative candidate wins instead of
    // an average (spec: "Never average everything together").
    constexpr float kAgreementThreshold = 0.035f;

    double confidenceSum = 0.0;
    const int n = w * h;
    for (int i = 0; i < n; ++i) {
        double mean = 0.0;
        for (const auto& cand : candidatesY) mean += cand.raw()[i];
        mean /= candidatesY.size();

        double variance = 0.0;
        for (const auto& cand : candidatesY) {
            double d = cand.raw()[i] - mean;
            variance += d * d;
        }
        variance /= candidatesY.size();
        double spread = std::sqrt(variance);

        float confidence = static_cast<float>(std::clamp(1.0 - spread / 0.15, 0.0, 1.0));
        result.confidenceMap.raw()[i] = confidence;
        confidenceSum += confidence;

        if (spread <= kAgreementThreshold && !conservativeMode) {
            result.image.raw()[i] = static_cast<float>(mean);
        } else if (spread <= kAgreementThreshold) {
            // Even in agreement, conservative mode nudges slightly toward
            // the original rather than trusting the average outright.
            result.image.raw()[i] = static_cast<float>(mean * 0.85 + originalY.raw()[i] * 0.15);
        } else {
            // Disagreement: pick whichever candidate deviates least from
            // the original pixel — the conservative choice.
            float original = originalY.raw()[i];
            float best = candidatesY[0].raw()[i];
            float bestDist = std::abs(best - original);
            for (size_t k = 1; k < candidatesY.size(); ++k) {
                float v = candidatesY[k].raw()[i];
                float dist = std::abs(v - original);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = v;
                }
            }
            result.image.raw()[i] = best;
        }
    }

    result.realityScore = static_cast<float>(confidenceSum / n);
    return result;
}

} // namespace crystal
