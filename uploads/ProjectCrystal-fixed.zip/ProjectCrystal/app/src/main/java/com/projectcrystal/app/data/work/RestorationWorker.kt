package com.projectcrystal.app.data.work

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.google.gson.Gson
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.data.repository.ImageRepository

/**
 * Runs [ImageRepository.restore] on a WorkManager background thread so
 * restoration survives the app being backgrounded, reports progress back to
 * the editor, and can be cancelled by the user mid-run. This is the *only*
 * way the app triggers a full restoration — EditorViewModel always goes
 * through WorkManager rather than launching a raw coroutine, per the spec's
 * "cancelable operations, no UI freezes" requirement.
 */
class RestorationWorker(appContext: Context, workerParams: WorkerParameters) :
    CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val uriString = inputData.getString(KEY_SOURCE_URI) ?: return Result.failure(
            workDataOf(KEY_ERROR to "Missing source image"),
        )
        val paramsJson = inputData.getString(KEY_PARAMS_JSON) ?: return Result.failure(
            workDataOf(KEY_ERROR to "Missing restoration params"),
        )
        val params = runCatching { Gson().fromJson(paramsJson, RestorationParams::class.java) }
            .getOrNull() ?: return Result.failure(workDataOf(KEY_ERROR to "Malformed restoration params"))

        val repository = ImageRepository(applicationContext)
        return try {
            val result = repository.restore(Uri.parse(uriString), params) { progress ->
                setProgress(workDataOf(KEY_PROGRESS to progress))
            }
            Result.success(workDataOf(KEY_RESULT_PATH to result.restoredImagePath))
        } catch (e: Throwable) {
            // Deliberately catches Throwable, not just Exception: a
            // pathological image (or a future regression in the downscale
            // guard) can throw OutOfMemoryError, which is an Error, not an
            // Exception — left uncaught it would take down the whole
            // process instead of failing just this one restoration.
            // CancellationException must still propagate so WorkManager
            // (and this work's coroutine scope) see the job as cancelled
            // rather than failed.
            if (e is kotlinx.coroutines.CancellationException) throw e
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Restoration failed")))
        }
    }

    companion object {
        const val KEY_SOURCE_URI = "source_uri"
        const val KEY_PARAMS_JSON = "params_json"
        const val KEY_PROGRESS = "progress"
        const val KEY_RESULT_PATH = "result_path"
        const val KEY_ERROR = "error"

        /** Unique work name so re-submitting while one run is already in flight replaces it rather than queuing a second. */
        fun uniqueWorkName(sourceUri: Uri): String = "restore_$sourceUri"

        fun enqueue(context: Context, sourceUri: Uri, params: RestorationParams): androidx.work.Operation {
            val input: Data = workDataOf(
                KEY_SOURCE_URI to sourceUri.toString(),
                KEY_PARAMS_JSON to Gson().toJson(params),
            )
            val request = OneTimeWorkRequestBuilder<RestorationWorker>()
                .setInputData(input)
                .build()
            return WorkManager.getInstance(context)
                .enqueueUniqueWork(uniqueWorkName(sourceUri), ExistingWorkPolicy.REPLACE, request)
        }
    }
}
