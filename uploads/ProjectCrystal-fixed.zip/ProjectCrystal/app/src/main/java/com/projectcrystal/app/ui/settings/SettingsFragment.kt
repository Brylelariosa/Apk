package com.projectcrystal.app.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.navigation.fragment.findNavController
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.projectcrystal.app.R
import com.projectcrystal.app.data.prefs.AppPreferences

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<ListPreference>(AppPreferences.KEY_THEME)?.setOnPreferenceChangeListener { _, newValue ->
            applyTheme(newValue as String)
            true
        }
        findPreference<Preference>("pref_about")?.setOnPreferenceClickListener {
            findNavController().navigate(R.id.aboutFragment)
            true
        }
        findPreference<Preference>("pref_help")?.setOnPreferenceClickListener {
            findNavController().navigate(R.id.helpFragment)
            true
        }
    }

    private fun applyTheme(value: String) {
        AppCompatDelegate.setDefaultNightMode(
            when (value) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            },
        )
    }
}
