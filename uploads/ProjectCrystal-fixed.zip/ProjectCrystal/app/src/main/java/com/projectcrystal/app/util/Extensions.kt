package com.projectcrystal.app.util

import android.content.Context
import android.util.TypedValue
import android.view.View

fun View.visible() { visibility = View.VISIBLE }
fun View.gone() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }
fun View.setVisibleOrGone(isVisible: Boolean) { visibility = if (isVisible) View.VISIBLE else View.GONE }

fun Context.dpToPx(dp: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

/** Clamps to [0, 1] — used pervasively when mapping slider positions to native param floats. */
fun Float.clamp01(): Float = coerceIn(0f, 1f)
