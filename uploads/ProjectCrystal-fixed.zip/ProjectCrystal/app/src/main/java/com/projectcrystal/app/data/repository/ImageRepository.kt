package com.projectcrystal.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.projectcrystal.app.core.diagnostics.BitmapDiff
import com.projectcrystal.app.core.diagnostics.DiagnosticLog
import com.projectcrystal.app.core.model.DiagnosticMap
import com.projectcrystal.app.core.model.ProcessingStats
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.core.model.RestorationResult
import com.projectcrystal.app.core.model.SpecialMode
import com.projectcrystal.app.core.native.NativeImageProcessor
import com.projectcrystal.app.core.native.RestorationMetricsNative
import com.projectcrystal.app.data.db.AppDatabase
import com.projectcrystal.app.data.db.HistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.roundToLong

/**
 * Single choke point between the UI layer and (a) the native restoration
 * engine, (b) on-disk image storage, and (c) the Room history table. Every
 * screen that touches a photo goes through here — ViewModels never call
 * [NativeImageProcessor] or [AppDatabase] directly, which is what keeps the
 * native/DB implementation details swappable without touching UI code.
 */
class ImageRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.historyDao()
    private val gson: Gson = GsonBuilder()
        .registerTypeAdapter(FloatArray::class.java, FloatArrayBase64Adapter())
        .create()

    private val cacheDir: File by lazy {
        File(context.cacheDir, "restoration_cache").apply { mkdirs() }
    }

    /** Private, permanently-app-owned copies of picked/shared source images. See [ensurePrivateSource]. */
    private val originalsDir: File by lazy {
        File(context.filesDir, "originals").apply { mkdirs() }
    }

    fun observeRecent(limit: Int = 12): Flow<List<HistoryEntity>> = dao.observeRecent(limit)
    fun observeAll(): Flow<List<HistoryEntity>> = dao.observeAll()
    fun observeFavorites(): Flow<List<HistoryEntity>> = dao.observeFavorites()

    /**
     * Copies [sourceUri] into app-private storage the first time it's seen,
     * and returns a `file://` URI to that private copy. A no-op (returns
     * [sourceUri] unchanged) if it's already one of our own ingested files.
     *
     * This matters because content URIs handed to the app by the system
     * photo picker or another app's share sheet are only guaranteed
     * readable for the current process's lifetime — by default the system
     * revokes access once the app stops or the device restarts. Since
     * [HistoryEntity.originalPath] is what "edit again" and the History
     * screen re-open later (possibly after the app process has been killed
     * and restarted many times over), persisting the *original* transient
     * URI would eventually throw a [SecurityException] on re-open. Ingesting
     * once, here, means every future read goes through a URI this app will
     * always be able to open — and as a side benefit, collapses what used
     * to be up to three separate reads of [sourceUri] (bounds decode, pixel
     * decode, EXIF) down to one remote/content-provider read followed by
     * fast local-disk reads.
     */
    private suspend fun ensurePrivateSource(sourceUri: Uri): Uri = withContext(Dispatchers.IO) {
        val existingPath = sourceUri.takeIf { it.scheme == "file" }?.path
        if (existingPath != null && File(existingPath).absolutePath.startsWith(originalsDir.absolutePath)) {
            return@withContext sourceUri
        }

        val target = File(originalsDir, "orig_${UUID.randomUUID()}${sourceExtension(sourceUri)}")
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Unable to read source image at $sourceUri")
        Uri.fromFile(target)
    }

    private fun sourceExtension(uri: Uri): String = when {
        context.contentResolver.getType(uri)?.contains("png") == true -> ".png"
        context.contentResolver.getType(uri)?.contains("webp") == true -> ".webp"
        else -> ".jpg"
    }

    /**
     * Decodes [uri] into an EXIF-orientation-corrected, immutable ARGB_8888
     * bitmap. Images above [MAX_PROCESSING_DIMENSION] on their long side are
     * downscaled first: the tile-based pipeline's memory footprint is
     * roughly proportional to (input + output + weight-accumulator) buffers
     * held at full resolution simultaneously, and an unbounded cap risks
     * OOM on the spec's 4GB-RAM device target. This is a deliberate,
     * documented ceiling rather than a true streaming/tiled-I/O pipeline.
     */
    suspend fun decodeForProcessing(uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        val longSide = maxOf(bounds.outWidth, bounds.outHeight)

        // inSampleSize must be a power of two; find the smallest one that
        // brings the long side at or under the cap. (A single
        // Integer.highestOneBit(longSide / MAX) computation looks
        // equivalent but rounds down for any longSide that isn't already a
        // clean multiple of MAX — e.g. a stock 4032px phone photo divided
        // by a 3000px cap gives highestOneBit(1) == 1, i.e. *no*
        // downsampling at all for one of the most common photo sizes there
        // is.)
        var sampleSize = 1
        while (longSide / sampleSize > MAX_PROCESSING_DIMENSION) sampleSize *= 2

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: error("Unable to decode image at $uri")

        val orientedBitmap = applyExifOrientation(context, uri, decoded)
        if (orientedBitmap.config != Bitmap.Config.ARGB_8888) {
            orientedBitmap.copy(Bitmap.Config.ARGB_8888, false).also { orientedBitmap.recycle() }
        } else {
            orientedBitmap
        }
    }

    /**
     * Runs the full native restoration pipeline and persists a history
     * entry. Returns the completed [RestorationResult]. Long-running; call
     * from a background dispatcher (this is exactly what
     * [com.projectcrystal.app.data.work.RestorationWorker] does).
     */
    suspend fun restore(
        sourceUri: Uri,
        params: RestorationParams,
        onProgress: suspend (Float) -> Unit = {},
    ): RestorationResult = withContext(Dispatchers.Default) {
        val privateUri = ensurePrivateSource(sourceUri)
        val input = decodeForProcessing(privateUri)
        onProgress(0.1f)

        DiagnosticLog.log(
            context, TAG_RESTORE,
            "start ${input.width}x${input.height} mode=${params.specialMode} conservative=${params.conservativeMode} " +
                "blur=${params.blurStrength} noise=${params.noiseReduction} sharp=${params.sharpness} " +
                "texture=${params.textureRecovery} halo=${params.haloSuppression} freq=${params.frequencyStrength} " +
                "tile=${params.tileSize} rlIter=${params.richardsonLucyIterations}",
        )

        var output: Bitmap? = null
        var thumb: Bitmap? = null
        try {
            output = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
            val metrics: RestorationMetricsNative? = NativeImageProcessor.processImage(
                input, output,
                NativeImageProcessor.packParams(params),
                params.specialMode.nativeValue,
                params.conservativeMode,
                MAP_MAX_DIMENSION,
            )
            onProgress(0.85f)
            checkNotNull(metrics) { "Native restoration failed — see logcat tag CrystalNative for details" }

            val diff = BitmapDiff.summarize(input, output!!)
            DiagnosticLog.log(
                context, TAG_RESTORE,
                "done tiles=${metrics.tileCount} totalMs=${metrics.totalMs.roundToLong()} " +
                    "(analysis=${metrics.analysisMs.roundToLong()} candidates=${metrics.candidateGenMs.roundToLong()} " +
                    "consensus=${metrics.consensusMs.roundToLong()} artifact=${metrics.artifactMs.roundToLong()} " +
                    "freqGate=${metrics.frequencyGateMs.roundToLong()} realityLock=${metrics.realityLockMs.roundToLong()} " +
                    "blend=${metrics.blendMs.roundToLong()}) realityScore=${metrics.realityScore} | $diff",
            )

            val restoredFile = File(cacheDir, "restored_${UUID.randomUUID()}.png")
            FileOutputStream(restoredFile).use { output.compress(Bitmap.CompressFormat.PNG, 100, it) }

            val thumbnailFile = File(cacheDir, "thumb_${UUID.randomUUID()}.jpg")
            val thumbHeight = (THUMBNAIL_SIZE.toLong() * output.height / output.width).toInt().coerceAtLeast(1)
            thumb = Bitmap.createScaledBitmap(output, THUMBNAIL_SIZE, thumbHeight, true)
            FileOutputStream(thumbnailFile).use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }

            val result = metrics.toResult(restoredFile.absolutePath, params)
            // WorkManager's output Data is capped at ~10KB, far too small for
            // the diagnostic maps (up to 512x512 floats each); RestorationWorker
            // can only hand the UI layer a file path, so the full result is
            // persisted here and re-hydrated via loadResult() once the worker
            // reports success.
            File(metricsPathFor(restoredFile.absolutePath)).writeText(gson.toJson(result))

            dao.insert(
                HistoryEntity(
                    originalPath = privateUri.toString(),
                    restoredPath = restoredFile.absolutePath,
                    thumbnailPath = thumbnailFile.absolutePath,
                    createdAtEpochMs = System.currentTimeMillis(),
                    realityScore = metrics.realityScore,
                    specialMode = params.specialMode.nativeValue,
                    paramsJson = gson.toJson(params),
                ),
            )
            onProgress(1f)
            result
        } finally {
            // These are large (up to MAX_PROCESSING_DIMENSION-square ARGB_8888)
            // buffers; recycle proactively rather than waiting on GC so a
            // batch run doesn't pile several of them up in memory at once.
            input.recycle()
            output?.recycle()
            if (thumb !== output) thumb?.recycle()
        }
    }

    /** Re-hydrates a [RestorationResult] previously written by [restore], keyed by its restored-image path. */
    suspend fun loadResult(restoredImagePath: String): RestorationResult = withContext(Dispatchers.IO) {
        val json = File(metricsPathFor(restoredImagePath)).readText()
        gson.fromJson(json, RestorationResult::class.java)
    }

    private fun metricsPathFor(restoredImagePath: String): String =
        restoredImagePath.substringBeforeLast('.') + ".metrics.json"

    suspend fun toggleFavorite(entity: HistoryEntity) = withContext(Dispatchers.IO) {
        dao.update(entity.copy(isFavorite = !entity.isFavorite))
    }

    suspend fun delete(entity: HistoryEntity) = withContext(Dispatchers.IO) {
        entity.restoredPath?.let {
            File(it).delete()
            File(metricsPathFor(it)).delete()
        }
        entity.thumbnailPath?.let { File(it).delete() }
        dao.delete(entity)

        // Only remove the ingested original once no other history entry
        // still points at it — "edit again" reprocesses the same original
        // into a new row, so several entries can share one originalPath.
        val originalUri = runCatching { Uri.parse(entity.originalPath) }.getOrNull()
        val originalFile = originalUri?.takeIf { it.scheme == "file" }?.path?.let(::File)
        if (originalFile != null &&
            originalFile.absolutePath.startsWith(originalsDir.absolutePath) &&
            dao.countByOriginalPath(entity.originalPath) == 0
        ) {
            originalFile.delete()
        }
    }

    suspend fun paramsFor(entity: HistoryEntity): RestorationParams = withContext(Dispatchers.Default) {
        runCatching { gson.fromJson(entity.paramsJson, RestorationParams::class.java) }
            .getOrDefault(RestorationParams.forSpecialMode(SpecialMode.fromNativeValue(entity.specialMode)))
    }

    suspend fun historyEntryById(id: Long): HistoryEntity? = withContext(Dispatchers.IO) { dao.getById(id) }

    /**
     * Best-effort cleanup of leftover in-app camera captures.
     * [com.projectcrystal.app.ui.home.HomeFragment]'s camera flow writes
     * each photo to a `content://…fileprovider/…`-shared file under
     * `cacheDir/camera_captures/` before it's ever seen by
     * [ensurePrivateSource]; once ingestion copies it into [originalsDir]
     * the cached original is redundant. That Uri can't be mapped back to a
     * filesystem path from inside [ensurePrivateSource] (FileProvider's
     * content:// encoding is opaque), so instead this sweeps anything old
     * enough that it's either already been ingested or was abandoned (the
     * user backed out of the camera before capturing anything). Safe to
     * call at any time; intended to run once per app process at startup.
     */
    suspend fun cleanupStaleCameraCaptures() = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1)
        File(context.cacheDir, "camera_captures")
            .listFiles { file -> file.lastModified() < cutoff }
            ?.forEach { it.delete() }
    }

    private fun RestorationMetricsNative.toResult(restoredPath: String, params: RestorationParams) = RestorationResult(
        restoredImagePath = restoredPath,
        realityScore = realityScore,
        blurMap = DiagnosticMap(mapWidth, mapHeight, blurMap),
        noiseMap = DiagnosticMap(mapWidth, mapHeight, noiseMap),
        edgeMap = DiagnosticMap(mapWidth, mapHeight, edgeMap),
        confidenceMap = DiagnosticMap(mapWidth, mapHeight, confidenceMap),
        artifactMap = DiagnosticMap(mapWidth, mapHeight, artifactMap),
        stats = ProcessingStats(
            analysisMs, candidateGenMs, consensusMs, artifactMs, frequencyGateMs,
            realityLockMs, blendMs, totalMs, tileCount,
        ),
        paramsUsed = params,
    )

    companion object {
        private const val MAX_PROCESSING_DIMENSION = 3000
        private const val MAP_MAX_DIMENSION = 512
        private const val THUMBNAIL_SIZE = 300
        private const val TAG_RESTORE = "Restore"
    }
}

private fun applyExifOrientation(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
    val orientation = context.contentResolver.openInputStream(uri)?.use { stream ->
        ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } ?: ExifInterface.ORIENTATION_NORMAL

    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        else -> return bitmap
    }
    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    if (rotated !== bitmap) bitmap.recycle()
    return rotated
}
