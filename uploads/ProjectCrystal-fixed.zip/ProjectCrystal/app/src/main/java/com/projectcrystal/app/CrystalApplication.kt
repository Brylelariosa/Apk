package com.projectcrystal.app

import android.app.Application
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.work.Configuration
import com.projectcrystal.app.data.prefs.AppPreferences
import com.projectcrystal.app.data.repository.ImageRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

class CrystalApplication : Application(), Configuration.Provider {

    /**
     * Reserved for short, fire-and-forget maintenance work that should
     * happen once per app process and doesn't belong to any single screen's
     * lifecycle (e.g. [ImageRepository.cleanupStaleCameraCaptures]) — as
     * opposed to per-restoration work, which always goes through
     * [com.projectcrystal.app.data.work.RestorationWorker] so it survives
     * the app being backgrounded.
     */
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        applyStoredThemePreference()
        applicationScope.launch { ImageRepository(this@CrystalApplication).cleanupStaleCameraCaptures() }
    }

    /** Applies the last-selected pref_theme value (system/light/dark) before the first Activity inflates. */
    private fun applyStoredThemePreference() {
        when (AppPreferences(this).themeMode()) {
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    /**
     * Each [com.projectcrystal.app.data.work.RestorationWorker] run holds
     * several full-resolution buffers at once (input/output bitmaps plus the
     * native pipeline's own tile accumulators). WorkManager's stock default
     * executor allows enough parallelism that a multi-image batch could run
     * several of those concurrently — fine on a flagship, a real OOM/thermal
     * risk on the app's 2-4GB RAM target devices. Capping it here trades a
     * bit of batch wall-clock time for staying inside a low-end device's
     * memory budget.
     */
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(if (BuildConfig.DEBUG) Log.DEBUG else Log.ERROR)
            .setExecutor(Executors.newFixedThreadPool(RESTORATION_CONCURRENCY))
            .build()

    private companion object {
        const val RESTORATION_CONCURRENCY = 2
    }
}
