package com.projectcrystal.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [HistoryEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        /**
         * v1 -> v2: adds indices backing the date-sort and favorites queries,
         * plus one on originalPath for reference-counted original-file
         * cleanup. Index-only change, no column/table rewrite needed.
         */
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS index_history_entries_createdAtEpochMs ON history_entries(createdAtEpochMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_history_entries_isFavorite_createdAtEpochMs ON history_entries(isFavorite, createdAtEpochMs)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_history_entries_originalPath ON history_entries(originalPath)")
            }
        }

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "project_crystal.db",
                )
                    .addMigrations(MIGRATION_1_2)
                    .build().also { instance = it }
            }
    }
}
