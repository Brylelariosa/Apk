package com.projectcrystal.app.core.model

/** Per-stage timings surfaced in Debug Mode, mirroring crystal::ProcessingStats. */
data class ProcessingStats(
    val analysisMs: Double,
    val candidateGenMs: Double,
    val consensusMs: Double,
    val artifactMs: Double,
    val frequencyGateMs: Double,
    val realityLockMs: Double,
    val blendMs: Double,
    val totalMs: Double,
    val tileCount: Int,
)

/** Single-channel diagnostic map (blur/noise/edge/confidence/artifact), already downsampled by the native layer. */
data class DiagnosticMap(
    val width: Int,
    val height: Int,
    val values: FloatArray,
)

/** Everything a completed restoration run produced, ready for the UI layer. */
data class RestorationResult(
    val restoredImagePath: String,
    val realityScore: Float,
    val blurMap: DiagnosticMap,
    val noiseMap: DiagnosticMap,
    val edgeMap: DiagnosticMap,
    val confidenceMap: DiagnosticMap,
    val artifactMap: DiagnosticMap,
    val stats: ProcessingStats,
    val paramsUsed: RestorationParams,
)
