package com.projectcrystal.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One completed (or in-progress) restoration, persisted so the Home and
 * History screens survive process death. [paramsJson] is the serialized
 * [com.projectcrystal.app.core.model.RestorationParams] used for this run,
 * kept so "edit again" can reopen the editor with the same slider state.
 */
@Entity(
    tableName = "history_entries",
    indices = [
        Index(value = ["createdAtEpochMs"]),
        Index(value = ["isFavorite", "createdAtEpochMs"]),
        Index(value = ["originalPath"]),
    ],
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalPath: String,
    val restoredPath: String?,
    val thumbnailPath: String?,
    val createdAtEpochMs: Long,
    val realityScore: Float?,
    val specialMode: Int,
    val paramsJson: String,
    val isFavorite: Boolean = false,
)
