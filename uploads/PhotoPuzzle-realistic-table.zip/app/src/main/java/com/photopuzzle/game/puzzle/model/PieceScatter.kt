package com.photopuzzle.game.puzzle.model

import kotlin.random.Random

/**
 * Pours the pieces out onto the table: an even, natural-looking spread (each new piece goes to
 * the spot farthest from the pieces already placed, out of a handful of random tries), every
 * piece turned a random way if rotation is part of the game, and each one flying in from above
 * the screen a moment after the previous.
 */
internal object PieceScatter {

    private const val CANDIDATES = 14

    fun scatter(
        game: PuzzleGame,
        random: Random,
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        windowTop: Float,
        rotatePieces: Boolean
    ) {
        val n = game.pieces.size
        val order = IntArray(n) { it }
        for (i in n - 1 downTo 1) {
            val j = random.nextInt(i + 1)
            val t = order[i]
            order[i] = order[j]
            order[j] = t
        }

        val xs = FloatArray(n)
        val zs = FloatArray(n)
        val stagger = minOf(0.04f, 1.0f / n)

        for (k in 0 until n) {
            var bestX = (left + right) * 0.5f
            var bestZ = (top + bottom) * 0.5f
            var bestDistance = -1f
            for (attempt in 0 until CANDIDATES) {
                val cx = left + random.nextFloat() * (right - left)
                val cz = top + random.nextFloat() * (bottom - top)
                var nearest = Float.MAX_VALUE
                for (j in 0 until k) {
                    val dx = cx - xs[j]
                    val dz = cz - zs[j]
                    val d = dx * dx + dz * dz
                    if (d < nearest) nearest = d
                }
                if (nearest > bestDistance) {
                    bestDistance = nearest
                    bestX = cx
                    bestZ = cz
                }
            }
            xs[k] = bestX
            zs[k] = bestZ

            val piece = game.pieces[order[k]]
            piece.x = bestX
            piece.z = bestZ
            piece.angle = if (rotatePieces) (random.nextFloat() * 2f - 1f) * AngleMath.PI_F else 0f
            piece.animX = (random.nextFloat() - 0.5f) * (right - left) * 0.6f
            piece.animZ = -((bestZ - windowTop) + game.minCell * 2f + random.nextFloat() * game.minCell * 3f)
            piece.animAngle = (random.nextFloat() - 0.5f) * 4f * AngleMath.PI_F
            piece.animDelay = k * stagger
        }

        // Later arrivals land on top of earlier ones.
        game.groups.clear()
        for (k in 0 until n) game.groups.add(game.pieces[order[k]].group)
    }
}
