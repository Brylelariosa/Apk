package com.photopuzzle.game.puzzle.render3d

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.photopuzzle.game.puzzle.model.PieceShape
import kotlin.math.ceil
import kotlin.math.max

/** A soft grayscale (alpha-only) image that covers [worldWidth] x [worldHeight] table units. */
internal class SoftMask(val bitmap: Bitmap, val worldWidth: Float, val worldHeight: Float)

/** Pre-blurred silhouettes: one per piece for its shadow, and two shared images for the turn ring. */
internal object ShadowMasks {

    private const val MAX_SIDE_PX = 160f
    private const val MAX_PX_PER_UNIT = 1.2f

    /**
     * The piece's outline, filled and blurred, with [pad] table units of margin all round so the
     * blur has room to fade out. Null if the platform refuses (the piece then simply has no shadow).
     */
    fun forPiece(shape: PieceShape, pad: Float, blur: Float): SoftMask? {
        return try {
            val worldW = shape.maxX - shape.minX + 2f * pad
            val worldH = shape.maxZ - shape.minZ + 2f * pad
            val pxPerUnit = (MAX_SIDE_PX / max(worldW, worldH)).coerceAtMost(MAX_PX_PER_UNIT)
            val w = max(8, ceil(worldW * pxPerUnit).toInt())
            val h = max(8, ceil(worldH * pxPerUnit).toInt())
            val sx = w / worldW
            val sy = h / worldH

            val path = Path()
            val n = shape.polygon.size / 2
            for (i in 0 until n) {
                val x = (shape.polygon[i * 2] - shape.minX + pad) * sx
                val y = (shape.polygon[i * 2 + 1] - shape.minZ + pad) * sy
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()

            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.color = Color.BLACK
            paint.maskFilter = BlurMaskFilter(max(1.5f, blur * sx), BlurMaskFilter.Blur.NORMAL)
            Canvas(bitmap).drawPath(path, paint)
            SoftMask(bitmap, worldW, worldH)
        } catch (error: Throwable) {
            null
        }
    }

    /** A thin glowing circle, filling its image edge to edge (radius 0.92 of the half size). */
    fun ring(): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ALPHA_8)
        val canvas = Canvas(bitmap)
        val c = size / 2f
        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.style = Paint.Style.STROKE
        glow.strokeWidth = 14f
        glow.color = Color.BLACK
        glow.alpha = 140
        try {
            glow.maskFilter = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
        } catch (error: Throwable) {
            // Glow is a nicety; the crisp ring below is enough.
        }
        canvas.drawCircle(c, c, c * RING_RADIUS, glow)
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 4f
        line.color = Color.BLACK
        canvas.drawCircle(c, c, c * RING_RADIUS, line)
        return bitmap
    }

    /** A soft round dot, used to mark where the finger is on the ring. */
    fun dot(): Bitmap {
        val size = 64
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ALPHA_8)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.BLACK
        try {
            paint.maskFilter = BlurMaskFilter(5f, BlurMaskFilter.Blur.NORMAL)
        } catch (error: Throwable) {
            // Fall back to a hard-edged dot.
        }
        Canvas(bitmap).drawCircle(size / 2f, size / 2f, 16f, paint)
        return bitmap
    }

    /** Radius of the ring's circle as a fraction of half the image. */
    const val RING_RADIUS = 0.92f
}
