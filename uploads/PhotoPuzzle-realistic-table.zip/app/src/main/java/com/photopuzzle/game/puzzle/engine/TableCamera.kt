package com.photopuzzle.game.puzzle.engine

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.tan

/**
 * A camera looking down at the table from a little in front of it, with a mild perspective.
 *
 * Table units are chosen so that at zoom 1 one unit is about one screen pixel at the point the
 * camera is aimed at. The table lies in the x/z plane with y up; x grows to the right and z
 * down the screen. All picking goes through [screenToTable], which intersects the touch ray
 * with the table, so panning, zooming and the tilt need no special cases anywhere else.
 */
internal class TableCamera {

    var viewWidth: Int = 1
        private set
    var viewHeight: Int = 1
        private set

    var focusX = 0f
        private set
    var focusZ = 0f
        private set
    var zoom = 1f
        private set

    /** How far the aimed-at point may stray from the middle of the table. */
    var limitX = 1e6f
    var limitZ = 1e6f

    val viewProj = FloatArray(16)

    var eyeX = 0f
        private set
    var eyeY = 0f
        private set
    var eyeZ = 0f
        private set

    private val view = FloatArray(16)
    private val projection = FloatArray(16)
    private val inverse = FloatArray(16)
    private val vecIn = FloatArray(4)
    private val near = FloatArray(4)
    private val far = FloatArray(4)
    private val probe = FloatArray(2)
    private val anchor = FloatArray(2)

    private var animating = false
    private var targetX = 0f
    private var targetZ = 0f
    private var targetZoom = 1f

    fun resize(width: Int, height: Int) {
        viewWidth = max(1, width)
        viewHeight = max(1, height)
        computeMatrices()
    }

    /** Jumps straight to a view. */
    fun snapTo(x: Float, z: Float, zoomLevel: Float) {
        animating = false
        focusX = x
        focusZ = z
        zoom = zoomLevel.coerceIn(MIN_ZOOM, MAX_ZOOM)
        clampFocus()
        computeMatrices()
    }

    /** Glides to a view over the next moments. */
    fun animateTo(x: Float, z: Float, zoomLevel: Float) {
        targetX = x.coerceIn(-limitX, limitX)
        targetZ = z.coerceIn(-limitZ, limitZ)
        targetZoom = zoomLevel.coerceIn(MIN_ZOOM, MAX_ZOOM)
        animating = true
    }

    fun cancelAnimation() {
        animating = false
    }

    fun update(dt: Float) {
        if (!animating) return
        val k = 1f - exp(-dt * ANIMATION_RATE)
        focusX += (targetX - focusX) * k
        focusZ += (targetZ - focusZ) * k
        zoom += (targetZoom - zoom) * k
        if (abs(targetX - focusX) < 0.2f && abs(targetZ - focusZ) < 0.2f && abs(targetZoom - zoom) < 0.002f) {
            focusX = targetX
            focusZ = targetZ
            zoom = targetZoom
            animating = false
        }
        computeMatrices()
    }

    /** Slides the view by a distance in table units. */
    fun panBy(dx: Float, dz: Float) {
        focusX += dx
        focusZ += dz
        clampFocus()
        computeMatrices()
    }

    /** Remembers the table point under a screen position; [applyPinch] keeps it there. */
    fun beginAnchor(sx: Float, sy: Float): Boolean = screenToTable(sx, sy, 0f, anchor)

    /**
     * Multiplies the zoom by [scaleFactor] and slides the view so the anchored table point stays
     * under the screen position ([sx], [sy]) -- which also follows two fingers panning.
     */
    fun applyPinch(scaleFactor: Float, sx: Float, sy: Float) {
        zoom = (zoom * scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        computeMatrices()
        if (screenToTable(sx, sy, 0f, probe)) {
            focusX += anchor[0] - probe[0]
            focusZ += anchor[1] - probe[1]
        }
        clampFocus()
        computeMatrices()
    }

    /**
     * Intersects the ray through screen pixel ([sx], [sy]) with the horizontal plane at height
     * [planeY]; the hit's x / z go to out[0], out[1]. False if the ray is parallel to the plane.
     */
    fun screenToTable(sx: Float, sy: Float, planeY: Float, out: FloatArray): Boolean {
        vecIn[0] = 2f * sx / viewWidth - 1f
        vecIn[1] = 1f - 2f * sy / viewHeight
        vecIn[2] = -1f
        vecIn[3] = 1f
        Matrix.multiplyMV(near, 0, inverse, 0, vecIn, 0)
        vecIn[2] = 1f
        Matrix.multiplyMV(far, 0, inverse, 0, vecIn, 0)
        val nw = near[3]
        val fw = far[3]
        if (abs(nw) < 1e-9f || abs(fw) < 1e-9f) return false
        val ax = near[0] / nw
        val ay = near[1] / nw
        val az = near[2] / nw
        val bx = far[0] / fw
        val by = far[1] / fw
        val bz = far[2] / fw
        val dy = by - ay
        if (abs(dy) < 1e-6f) return false
        val t = (planeY - ay) / dy
        out[0] = ax + (bx - ax) * t
        out[1] = az + (bz - az) * t
        return true
    }

    private fun clampFocus() {
        focusX = focusX.coerceIn(-limitX, limitX)
        focusZ = focusZ.coerceIn(-limitZ, limitZ)
    }

    private fun computeMatrices() {
        val aspect = viewWidth.toFloat() / viewHeight.toFloat()
        val baseDistance = viewHeight / (2f * tan(Math.toRadians(FOV_Y_DEGREES / 2.0)).toFloat())
        val distance = baseDistance / zoom
        eyeX = focusX
        eyeY = distance * cos(TILT_RADIANS)
        eyeZ = focusZ + distance * sin(TILT_RADIANS)
        Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ, focusX, 0f, focusZ, 0f, 0f, -1f)
        Matrix.perspectiveM(projection, 0, FOV_Y_DEGREES, aspect, distance * 0.15f, distance * 8f)
        Matrix.multiplyMM(viewProj, 0, projection, 0, view, 0)
        Matrix.invertM(inverse, 0, viewProj, 0)
    }

    companion object {
        const val FOV_Y_DEGREES = 24f

        /** Tilt from straight down, in radians (28 degrees). */
        const val TILT_RADIANS = 0.489f

        const val MIN_ZOOM = 0.7f
        const val MAX_ZOOM = 4f
        private const val ANIMATION_RATE = 4.5f
    }
}
