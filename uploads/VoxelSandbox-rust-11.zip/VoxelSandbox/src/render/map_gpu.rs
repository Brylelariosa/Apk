//! The GPU side of the world map: the texture its picture is uploaded to and the program that draws it.
//!
//! Both are made the first time the map has something to show, not when the renderer starts. Nothing else depends on
//! them: the menus and the controls are drawn by the UI program alone (see `UiBatch::runs`), so a driver that cannot
//! build the map's program or texture only costs the map, and the game goes on without it.

use std::os::raw::c_void;

use super::gl::*;
use super::programs::{MapProg, MAP_UNIT};
use super::shader::set_mat4;
use crate::map::MapView;

/// The map's program: not tried yet, built, or refused by the driver (it is not tried again).
enum Build {
    Pending,
    Ready(MapProg),
    Failed,
}

pub struct MapGpu {
    /// The picture's texture; 0 until the first upload.
    tex: GLuint,
    /// The size of the picture in `tex`.
    size: (usize, usize),
    /// The `MapView::serial` of what was uploaded last (`u64::MAX`: nothing yet).
    serial: u64,
    prog: Build,
}

fn unit() -> GLenum {
    GL_TEXTURE0 + MAP_UNIT as GLenum
}

/// A texture for the picture. It has no image yet: the first upload gives it one.
fn create_texture() -> GLuint {
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D, id);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    id
}

impl MapGpu {
    pub fn new() -> MapGpu {
        MapGpu { tex: 0, size: (0, 0), serial: u64::MAX, prog: Build::Pending }
    }

    /// Uploads the picture when it changed since the last upload (only while the map is on screen).
    pub fn sync(&mut self, view: &MapView) {
        if !view.wanted() || view.serial() == self.serial {
            return;
        }
        let img = view.image();
        if img.w == 0 || img.h == 0 || img.rgba.len() < img.w * img.h * 4 {
            return;
        }
        unsafe {
            glActiveTexture(unit());
            if self.tex == 0 {
                self.tex = create_texture();
            } else {
                glBindTexture(GL_TEXTURE_2D, self.tex);
            }
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            let pixels = img.rgba.as_ptr() as *const c_void;
            if self.size == (img.w, img.h) {
                glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, img.w as GLsizei, img.h as GLsizei, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
            } else {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, img.w as GLsizei, img.h as GLsizei, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
                self.size = (img.w, img.h);
            }
            glActiveTexture(GL_TEXTURE0);
        }
        self.serial = view.serial();
    }

    /// Makes the map's program current with the picture on its texture unit, ready to draw map vertices. False if there
    /// is nothing to draw them with (no picture yet, or the driver could not build the program): they are then left out.
    pub fn begin_draw(&mut self, proj: &[f32; 16]) -> bool {
        if self.tex == 0 {
            return false;
        }
        if let Build::Pending = self.prog {
            self.prog = match MapProg::new() {
                Ok(p) => Build::Ready(p),
                Err(e) => {
                    crate::loge!("the world map cannot be drawn: {}", e);
                    crate::diag::note(&format!("the world map cannot be drawn: {}", e));
                    Build::Failed
                }
            };
        }
        let p = match &self.prog {
            Build::Ready(p) => p,
            _ => return false,
        };
        p.prog.use_program();
        set_mat4(p.proj, proj);
        unsafe {
            glActiveTexture(unit());
            glBindTexture(GL_TEXTURE_2D, self.tex);
            glUniform1i(p.map, MAP_UNIT);
            glActiveTexture(GL_TEXTURE0);
        }
        true
    }

    /// The GL context is gone and its objects with it: start over (the next picture makes a new texture).
    pub fn forget(&mut self) {
        *self = MapGpu::new();
    }
}
