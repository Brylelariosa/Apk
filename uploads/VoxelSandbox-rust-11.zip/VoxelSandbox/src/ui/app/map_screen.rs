//! The large world map: a dimmed game behind a square map that can be dragged around and zoomed, with the player's
//! position and a few buttons. The map comes from `map::MapView`; the corner map of the HUD shows the same world.

use super::{App, Screen, GREY, WHITE};
use crate::map::view::BIG_PX;
use crate::ui::batch::{rgba, UiBatch};
use crate::ui::map_hud::{self, MapRect, Marker};

const MAP_BUILD_TIME: std::time::Duration = std::time::Duration::from_micros(4000);

impl App {
    pub(super) fn map_screen(&mut self, dt: f32, taps: &[(f32, f32)]) {
        // the world stands behind the map, as it does behind the inventory
        let marker = match self.engine.as_mut() {
            Some(engine) => {
                engine.input.ui_blocked = true;
                engine.update(&self.effective, dt);
                let p = &engine.player.position;
                let at = (p.x as f64, p.z as f64);
                self.map.update(&engine.manager.gen, at, MAP_BUILD_TIME);
                Marker { x: at.0, z: at.1, yaw: engine.player.yaw }
            }
            None => Marker { x: 0.0, z: 0.0, yaw: 0.0 },
        };

        self.dim(190);
        let w = self.width;
        let h = self.height;
        let m = self.dp(10.0);
        let col_w = self.dp(132.0);
        let size = (h - 2.0 * m).min(w - 3.0 * m - col_w).max(self.dp(120.0));
        let rect = MapRect { x: m, y: (h - size) * 0.5, size };

        // dragging the map moves the view; a finger that began on a button does not
        let blocks_per_screen_px = self.map.blocks_per_pixel() as f32 * BIG_PX as f32 / size;
        let (mut dx, mut dy) = (0.0f32, 0.0f32);
        for t in self.touches.active.iter_mut() {
            if rect.contains(t.start_x, t.start_y) && t.moved {
                dx += t.pending_dx;
                dy += t.pending_dy;
            }
            t.pending_dx = 0.0;
            t.pending_dy = 0.0;
        }
        if dx != 0.0 || dy != 0.0 {
            self.map.pan_blocks(-(dx * blocks_per_screen_px) as f64, -(dy * blocks_per_screen_px) as f64);
        }

        map_hud::draw(&mut self.ui, &self.map, rect, marker, self.scale);

        // the column of buttons on the right
        let x = rect.x + rect.size + m * 1.5;
        let bh = self.dp(38.0);
        let gap = self.dp(8.0);
        let mut y = rect.y;
        let tp = self.font_px(10.0);
        let line = UiBatch::text_height(tp) + self.dp(5.0);
        self.ui.text_shadow(x, y, tp, "WORLD MAP", WHITE);
        y += line + gap;
        let half = (col_w - gap) * 0.5;
        if self.button(x, y, half, bh, "+", taps) && self.map.can_zoom_in() {
            self.map.zoom_in();
        }
        if self.button(x + half + gap, y, half, bh, "-", taps) && self.map.can_zoom_out() {
            self.map.zoom_out();
        }
        y += bh + gap;
        let centre_label = if self.map.is_panned() { "CENTER" } else { "ON YOU" };
        if self.button(x, y, col_w, bh, centre_label, taps) {
            self.map.recenter();
        }
        y += bh + gap;
        let on = self.map.visible();
        let corner_label = if on { "MINIMAP: ON" } else { "MINIMAP: OFF" };
        if self.button(x, y, col_w, bh, corner_label, taps) {
            self.settings.show_map = self.map.toggle();
            self.layout.map_on = self.map.visible();
            self.settings.save(&self.data_dir.join("settings.txt"));
        }
        y += bh + gap;
        if self.button(x, y, col_w, bh, "CLOSE", taps) {
            self.go(Screen::Playing);
            return;
        }
        y += bh + gap;

        // where things are
        let sp = self.font_px(8.0);
        let line = UiBatch::text_height(sp) + self.dp(4.0);
        let view = format!("{} BLOCKS WIDE", self.map.blocks_across());
        self.ui.text_shadow(x, y, sp, &view, GREY);
        y += line;
        let you = format!("YOU {},{}", marker.x.floor() as i64, marker.z.floor() as i64);
        self.ui.text_shadow(x, y, sp, &you, GREY);
        y += line;
        if self.map.is_panned() {
            let (cx, cz) = self.map.centre();
            let at = format!("VIEW {},{}", cx.floor() as i64, cz.floor() as i64);
            self.ui.text_shadow(x, y, sp, &at, rgba(255, 214, 102, 255));
        }
        if !self.map.is_complete() {
            let wait = rect.y + rect.size - UiBatch::text_height(sp);
            self.ui.text_shadow(x, wait, sp, "DRAWING...", rgba(255, 214, 102, 255));
        }
    }
}
