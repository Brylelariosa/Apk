//! Drawing the world map: the corner map of the HUD and the large one share this code. The picture itself is
//! made by `map::MapView`; this puts it on the screen, with the player's arrow and the compass.

use super::batch::{rgba, Color, UiBatch};
use crate::map::MapView;

/// A square on the screen, in pixels.
#[derive(Clone, Copy, PartialEq, Debug)]
pub struct MapRect {
    pub x: f32,
    pub y: f32,
    pub size: f32,
}

impl MapRect {
    pub fn contains(&self, px: f32, py: f32) -> bool {
        px >= self.x && px <= self.x + self.size && py >= self.y && py <= self.y + self.size
    }

    pub fn bottom(&self) -> f32 {
        self.y + self.size
    }
}

/// Where the corner map goes: under the biome name, at the top left. `s` is pixels per dp.
pub fn corner_rect(s: f32) -> MapRect {
    MapRect { x: 12.0 * s, y: 30.0 * s, size: 112.0 * s }
}

/// Where the player is and which way he faces (yaw 0 faces north, the top of the map).
#[derive(Clone, Copy, Debug)]
pub struct Marker {
    pub x: f64,
    pub z: f64,
    pub yaw: f32,
}

const FRAME: Color = rgba(235, 238, 248, 255);
const SHADOW: Color = rgba(0, 0, 0, 200);
const ARROW: Color = rgba(255, 70, 60, 255);

/// Draws the picture in `rect`, then the arrow, the compass and the frame. Draws only the frame and a backdrop until
/// the first tiles are built.
pub fn draw(batch: &mut UiBatch, view: &MapView, rect: MapRect, marker: Marker, s: f32) {
    batch.rect(rect.x, rect.y, rect.size, rect.size, rgba(14, 18, 30, 235));
    let img = view.image();
    if img.w > 0 && img.h > 0 {
        batch.map_picture(rect.x, rect.y, rect.size, rect.size);
        let (u, v) = view.to_window(marker.x, marker.z);
        let k = rect.size / img.w as f32;
        let (ax, ay) = (rect.x + u * k, rect.y + v * k);
        if u >= 0.0 && v >= 0.0 && u <= img.w as f32 && v <= img.h as f32 {
            draw_arrow(batch, ax, ay, marker.yaw, 6.5 * s);
        }
    }
    let t = 2.0 * s;
    batch.border(rect.x - t, rect.y - t, rect.size + 2.0 * t, rect.size + 2.0 * t, t, FRAME);
    // north is the top of the map
    let px = s.round().max(1.0);
    batch.text_centered(rect.x + rect.size * 0.5, rect.y + 3.0 * s, px, "N", rgba(255, 255, 255, 235));
}

/// A pointed arrow at (cx, cy) facing `yaw`, with a dark edge so it shows on any ground.
fn draw_arrow(batch: &mut UiBatch, cx: f32, cy: f32, yaw: f32, r: f32) {
    let (dx, dy) = (yaw.sin(), -yaw.cos());
    let (nx, ny) = (-dy, dx);
    let corner = |scale: f32| -> ([f32; 2], [f32; 2], [f32; 2]) {
        let tip = [cx + dx * r * 1.5 * scale, cy + dy * r * 1.5 * scale];
        let left = [cx - dx * r * 0.9 * scale + nx * r * scale, cy - dy * r * 0.9 * scale + ny * r * scale];
        let right = [cx - dx * r * 0.9 * scale - nx * r * scale, cy - dy * r * 0.9 * scale - ny * r * scale];
        (tip, left, right)
    };
    let (a, b, c) = corner(1.25);
    batch.triangle(a, b, c, SHADOW);
    let (a, b, c) = corner(1.0);
    batch.triangle(a, b, c, ARROW);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::terrain::TerrainGenerator;
    use std::time::Duration;

    #[test]
    fn the_corner_map_sits_inside_the_screen_clear_of_the_buttons() {
        let r = corner_rect(2.0);
        assert!(r.x > 0.0 && r.y > 0.0 && r.bottom() < 720.0);
        assert!(r.contains(r.x + 5.0, r.y + 5.0) && !r.contains(r.x - 1.0, r.y));
    }

    #[test]
    fn drawing_adds_the_picture_and_the_arrow_in_whole_triangles() {
        let g = TerrainGenerator::new(1);
        let mut view = MapView::new(true);
        view.update(&g, (0.0, 0.0), Duration::from_secs(60));
        let mut b = UiBatch::new();
        draw(&mut b, &view, corner_rect(2.0), Marker { x: 0.0, z: 0.0, yaw: 0.0 }, 2.0);
        assert_eq!(b.verts.len() % 3, 0);
        assert!(b.verts.iter().any(|v| v.layer == crate::ui::batch::LAYER_MAP), "the picture is in the batch");
    }

    #[test]
    fn nothing_but_a_frame_is_drawn_before_there_is_a_picture() {
        let view = MapView::new(true);
        let mut b = UiBatch::new();
        draw(&mut b, &view, corner_rect(2.0), Marker { x: 0.0, z: 0.0, yaw: 0.0 }, 2.0);
        assert!(b.verts.iter().all(|v| v.layer != crate::ui::batch::LAYER_MAP));
    }
}
