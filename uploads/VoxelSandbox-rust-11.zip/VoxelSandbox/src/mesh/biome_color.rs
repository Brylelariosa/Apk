//! Biome tinting. Grass, tall grass and leaves are drawn in a neutral green; the mesher multiplies them by
//! `field colour / anchor colour` (the anchor is the tile's own mean colour), so a biome's colour is a smooth
//! function of the climate instead of a hard per-biome switch.

use std::sync::Arc;

use crate::gen::climate::Climate;
use crate::gen::shape::TerrainShape;
use crate::tex;
use crate::tex::cells;
use crate::world::config::SEA_LEVEL;

pub const COLD_SHIFT: [f32; 3] = [0.86, 0.92, 1.40];
/// Jungle grass against the temperate grass: less red, a little more green, a little less blue.
pub const LUSH_SHIFT: [f32; 3] = [0.62, 1.08, 0.72];
/// A temperate forest against the open grass: a darker, deeper green (so a forest reads as a forest from far away).
pub const FOREST_SHIFT: [f32; 3] = [0.78, 0.91, 0.72];
/// A birch forest: light, yellow-green.
pub const BIRCH_SHIFT: [f32; 3] = [1.10, 1.05, 0.78];
/// The dense rainforest against the jungle: darker and bluer still.
pub const RAIN_SHIFT: [f32; 3] = [0.72, 0.85, 0.85];
/// Leaves take this much of the grass tint.
pub const LEAF_STRENGTH: f32 = 0.7;

/// The anchor colours: the means of the neutral grass tiles.
#[derive(Clone, Debug)]
pub struct BiomePalette {
    pub grass: [f32; 3],
    pub dry: [f32; 3],
    pub swamp: [f32; 3],
    pub cold: [f32; 3],
    /// The deep, saturated green of the jungle.
    pub lush: [f32; 3],
    pub forest: [f32; 3],
    pub birch: [f32; 3],
    pub rain: [f32; 3],
}

impl BiomePalette {
    pub fn from_tiles() -> BiomePalette {
        fn mean(cell: i32) -> [f32; 3] {
            match tex::tile_argb(cell) {
                Some(t) => {
                    let m = tex::average_rgb(&t);
                    [m[0] as f32, m[1] as f32, m[2] as f32]
                }
                None => [128.0, 128.0, 128.0],
            }
        }
        let grass = mean(cells::GRASS_TOP);
        BiomePalette {
            grass,
            dry: mean(cells::DRY_GRASS_TOP),
            swamp: mean(cells::SWAMP_GRASS_TOP),
            cold: [grass[0] * COLD_SHIFT[0], grass[1] * COLD_SHIFT[1], grass[2] * COLD_SHIFT[2]],
            lush: [grass[0] * LUSH_SHIFT[0], grass[1] * LUSH_SHIFT[1], grass[2] * LUSH_SHIFT[2]],
            forest: [grass[0] * FOREST_SHIFT[0], grass[1] * FOREST_SHIFT[1], grass[2] * FOREST_SHIFT[2]],
            birch: [grass[0] * BIRCH_SHIFT[0], grass[1] * BIRCH_SHIFT[1], grass[2] * BIRCH_SHIFT[2]],
            // the rainforest is the jungle's lush green, darkened further
            rain: [
                grass[0] * LUSH_SHIFT[0] * RAIN_SHIFT[0],
                grass[1] * LUSH_SHIFT[1] * RAIN_SHIFT[1],
                grass[2] * LUSH_SHIFT[2] * RAIN_SHIFT[2],
            ],
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Anchor {
    Grass,
    Dry,
    Swamp,
}

/// How a tile is tinted: `mode` 1 = the whole texture, 2 = only the grass fringe (the shader masks it).
#[derive(Clone, Copy, Debug)]
pub struct TintInfo {
    pub anchor: Anchor,
    pub mode: u8,
    pub strength: f32,
}

pub fn tint_for_cell(cell: i32) -> Option<TintInfo> {
    let whole = |anchor: Anchor, strength: f32| Some(TintInfo { anchor, mode: 1, strength });
    let fringe = |anchor: Anchor| Some(TintInfo { anchor, mode: 2, strength: 1.0 });
    match cell {
        cells::GRASS_TOP => whole(Anchor::Grass, 1.0),
        cells::GRASS_SIDE => fringe(Anchor::Grass),
        cells::DRY_GRASS_TOP => whole(Anchor::Dry, 1.0),
        cells::DRY_GRASS_SIDE => fringe(Anchor::Dry),
        cells::SWAMP_GRASS_TOP => whole(Anchor::Swamp, 1.0),
        cells::SWAMP_GRASS_SIDE => fringe(Anchor::Swamp),
        cells::TALL_GRASS => whole(Anchor::Grass, 1.0),
        cells::FERN | cells::FERN_B => whole(Anchor::Grass, 1.0),
        cells::BROADLEAF | cells::PALM_SAPLING => whole(Anchor::Grass, 0.9),
        cells::VINE => whole(Anchor::Grass, 0.8),
        cells::OAK_LEAVES | cells::BIRCH_LEAVES | cells::SPRUCE_LEAVES | cells::JUNGLE_LEAVES | cells::JUNGLE_LEAVES_B => whole(Anchor::Grass, LEAF_STRENGTH),
        _ => None,
    }
}

/// The colour of the ground cover at a point, from the climate fields.
pub struct BiomeColorField {
    climate: Arc<Climate>,
    shape: Arc<TerrainShape>,
    pub palette: BiomePalette,
}

impl BiomeColorField {
    pub fn new(climate: Arc<Climate>, shape: Arc<TerrainShape>, palette: BiomePalette) -> BiomeColorField {
        BiomeColorField { climate, shape, palette }
    }

    /// Grass colour (0..255 per channel) for a point with known ground height, base elevation, sea-level
    /// temperature and humidity.
    pub fn grass(&self, wx: f64, wz: f64, ground: f64, coast: f64, t0: f64, hum: f64) -> [f32; 3] {
        let p = &self.palette;
        let alt = ground - SEA_LEVEL as f64;
        let te = self.climate.ground_temperature(t0, self.climate.temperature_jitter(wx, wz), ground);
        let hu = hum + self.climate.humidity_jitter(wx, wz);
        let cold = self.climate.coldness(te) as f32;
        let dry = self.climate.dryness(te, hu) as f32;
        let swamp = self.climate.swampiness(self.climate.swamp_weight_with(wx, wz, coast, hum, t0), alt) as f32;
        let lush = self.climate.lushness(te, hu) as f32;
        let wood = self.climate.forestiness(te, hu) as f32;
        let birch = if wood > 0.0 { self.climate.birchiness(wx, wz) as f32 } else { 0.0 };
        let rain = self.climate.rainness(te, hu) as f32 * lush;
        let mut c = p.grass;
        // forests are darker than the open grass, birch forests lighter and yellower
        for k in 0..3 {
            c[k] += (p.forest[k] - c[k]) * wood * (1.0 - birch);
            c[k] += (p.birch[k] - c[k]) * wood * birch;
        }
        for k in 0..3 {
            c[k] += (p.cold[k] - c[k]) * cold;
        }
        for k in 0..3 {
            c[k] += (p.dry[k] - c[k]) * dry;
        }
        for k in 0..3 {
            c[k] += (p.swamp[k] - c[k]) * swamp;
        }
        for k in 0..3 {
            c[k] += (p.lush[k] - c[k]) * lush;
        }
        for k in 0..3 {
            c[k] += (p.rain[k] - c[k]) * rain;
        }
        for k in 0..3 {
            c[k] = c[k].max(0.0).min(255.0);
        }
        c
    }

    /// The grass colour at a block column (samples the land-form for its height).
    pub fn grass_at(&self, wx: f64, wz: f64) -> [f32; 3] {
        let (ground, coast) = self.shape.height_and_coast(wx, wz, 0);
        self.grass(wx, wz, ground, coast, self.climate.base_temperature(wx, wz), self.climate.humidity(wx, wz))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn field() -> BiomeColorField {
        let climate = Arc::new(Climate::new(11));
        let shape = Arc::new(TerrainShape::new(11, climate.clone()));
        BiomeColorField::new(climate, shape, BiomePalette::from_tiles())
    }

    fn luma(c: [f32; 3]) -> f32 {
        0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]
    }

    #[test]
    fn each_kind_of_woodland_has_its_own_colour() {
        let f = field();
        let at = |t0: f64, hum: f64| f.grass(500.0, 500.0, SEA_LEVEL as f64 + 12.0, 30.0, t0, hum);
        let plains = at(0.20, 0.0);
        let forest = at(0.20, 0.34);
        let jungle = at(0.70, 0.40);
        let rain = at(0.80, 0.80);
        assert!(luma(forest) < luma(plains) - 8.0, "forest {:?} plains {:?}", forest, plains);
        assert!(forest[1] < plains[1] - 6.0);
        assert!(luma(rain) < luma(jungle) - 6.0, "rain {:?} jungle {:?}", rain, jungle);
        // and a forest is not the colour of a jungle either
        assert!((forest[0] - jungle[0]).abs() + (forest[1] - jungle[1]).abs() + (forest[2] - jungle[2]).abs() > 12.0, "{:?} {:?}", forest, jungle);
    }

    #[test]
    fn birch_forest_is_lighter_than_oak_forest() {
        let f = field();
        // find one place of each kind of forest noise
        let (mut oak, mut birch) = (None, None);
        for i in 0..400 {
            let (x, z) = (i as f64 * 311.0, i as f64 * -173.0);
            let b = f.climate.birchiness(x, z);
            if b < 0.02 && oak.is_none() {
                oak = Some((x, z));
            }
            if b > 0.98 && birch.is_none() {
                birch = Some((x, z));
            }
        }
        let (ox, oz) = oak.expect("an oak place");
        let (bx, bz) = birch.expect("a birch place");
        let g = |x: f64, z: f64| f.grass(x, z, SEA_LEVEL as f64 + 12.0, 30.0, 0.20, 0.34);
        assert!(luma(g(bx, bz)) > luma(g(ox, oz)) + 10.0);
    }
}
