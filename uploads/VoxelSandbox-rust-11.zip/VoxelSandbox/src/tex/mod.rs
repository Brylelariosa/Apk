//! Block textures: the hand-made 16x16 tiles (decoded from palette tables) packed into the layers of a
//! GL texture array.

pub mod cells;
pub mod cloud_noise;
mod tiles_data;

use tiles_data::{TileSrc, TILE_SRCS};

pub const TILE_SIZE: usize = 16;
pub const TILE_PIXELS: usize = TILE_SIZE * TILE_SIZE;
/// How far the alpha of a tinted "fringe" texel (grass on the side of a soil block) is lowered, so the
/// shader can tell it from the soil. The shader reads `(1 - alpha) * 255 / MASK_ALPHA_DROP` as the mask.
pub const MASK_ALPHA_DROP: u32 = 20;

fn decode(src: &TileSrc) -> [u32; TILE_PIXELS] {
    let lut: Vec<u32> = src
        .palette
        .split(' ')
        .map(|p| 0xFF00_0000 | u32::from_str_radix(p, 16).unwrap_or(0))
        .collect();
    let mut out = [0u32; TILE_PIXELS];
    for (i, ch) in src.rows.chars().enumerate() {
        if i >= TILE_PIXELS {
            break;
        }
        if ch == '.' {
            continue;
        }
        let d = if ch <= '9' { (ch as i32) - ('0' as i32) } else { (ch as i32) - ('a' as i32) + 10 };
        if d >= 0 && (d as usize) < lut.len() {
            out[i] = lut[d as usize];
        }
    }
    out
}

/// The base colour of the water tile (it is made in code, not decoded from a hand-made tile). The tile's texels are
/// this colour made a little darker or lighter, and average out to it, so far-away water (the mip levels, the far
/// terrain's sea) matches the water close by.
pub const WATER_RGB: [u32; 3] = [60, 116, 206];

/// A hash of a lattice point, `0.0 ..= 1.0`, for the noise of the water tile.
fn water_lattice(ix: i32, iy: i32, seed: u32) -> f32 {
    let mut h = (ix as u32).wrapping_mul(0x9E37_79B1) ^ (iy as u32).wrapping_mul(0x85EB_CA6B) ^ seed.wrapping_mul(0xC2B2_AE35);
    h ^= h >> 15;
    h = h.wrapping_mul(0x2C1B_3C6D);
    h ^= h >> 12;
    h = h.wrapping_mul(0x297A_2D39);
    h ^= h >> 15;
    (h & 0xFFFF) as f32 / 65535.0
}

/// Smooth value noise over the tile that repeats seamlessly: the lattice has `16 / step` cells across and wraps
/// around, so neighbouring copies of the tile fit together.
fn water_noise(x: usize, y: usize, step_x: usize, step_y: usize, seed: u32) -> f32 {
    let across_x = (TILE_SIZE / step_x) as i32;
    let across_y = (TILE_SIZE / step_y) as i32;
    let fx = (x % step_x) as f32 / step_x as f32;
    let fy = (y % step_y) as f32 / step_y as f32;
    let ix = (x / step_x) as i32;
    let iy = (y / step_y) as i32;
    let at = |dx: i32, dy: i32| water_lattice((ix + dx).rem_euclid(across_x), (iy + dy).rem_euclid(across_y), seed);
    let sx = fx * fx * (3.0 - 2.0 * fx);
    let sy = fy * fy * (3.0 - 2.0 * fy);
    let top = at(0, 0) + (at(1, 0) - at(0, 0)) * sx;
    let bottom = at(0, 1) + (at(1, 1) - at(0, 1)) * sx;
    top + (bottom - top) * sy
}

/// The water tile: the water colour in four brightness steps, laid out as soft streaks that are wider than they are
/// tall (like ripples seen from the side). The steps are given out by rank, so the share of each is exactly the same
/// in every build and the tile averages to `WATER_RGB`. The water shader reads it twice, drifting in two directions.
fn water_pixels() -> [u32; TILE_PIXELS] {
    let mut vals = [0.0f32; TILE_PIXELS];
    for y in 0..TILE_SIZE {
        for x in 0..TILE_SIZE {
            vals[y * TILE_SIZE + x] = 0.65 * water_noise(x, y, 8, 4, 11) + 0.35 * water_noise(x, y, 4, 2, 29);
        }
    }
    let mut order: Vec<usize> = (0..TILE_PIXELS).collect();
    order.sort_by(|&a, &b| vals[a].partial_cmp(&vals[b]).unwrap_or(std::cmp::Ordering::Equal));
    let mut out = [0u32; TILE_PIXELS];
    for (rank, &i) in order.iter().enumerate() {
        let q = rank as f32 / TILE_PIXELS as f32;
        let k = if q < 0.30 {
            0.91f32
        } else if q < 0.75 {
            1.0
        } else if q < 0.92 {
            1.06
        } else {
            1.14
        };
        let c = |v: u32| -> u32 { (v as f32 * k).round().min(255.0) as u32 };
        out[i] = 0xFF00_0000 | (c(WATER_RGB[0]) << 16) | (c(WATER_RGB[1]) << 8) | c(WATER_RGB[2]);
    }
    out
}

/// The decoded hand-made tile of a layer as ARGB, or `None` for layers made in code (water, white) or unused.
pub fn tile_argb(cell: i32) -> Option<[u32; TILE_PIXELS]> {
    for src in TILE_SRCS.iter() {
        if src.cell as i32 == cell {
            return Some(decode(src));
        }
    }
    None
}

/// Mean colour of the opaque texels of a tile, per channel (integer mean, like the v15 game).
pub fn average_rgb(tile: &[u32; TILE_PIXELS]) -> [u32; 3] {
    let mut r = 0u32;
    let mut g = 0u32;
    let mut b = 0u32;
    let mut n = 0u32;
    for &p in tile.iter() {
        if (p >> 24) < 128 {
            continue;
        }
        r += (p >> 16) & 0xFF;
        g += (p >> 8) & 0xFF;
        b += p & 0xFF;
        n += 1;
    }
    if n == 0 {
        return [128, 128, 128];
    }
    [r / n, g / n, b / n]
}

fn is_grass_texel(argb: u32) -> bool {
    if (argb >> 24) < 128 {
        return false;
    }
    let g = ((argb >> 8) & 0xFF) as i32;
    let r = ((argb >> 16) & 0xFF) as i32;
    g >= r - 4
}

fn is_fringe_cell(cell: usize) -> bool {
    cell as i32 == cells::GRASS_SIDE || cell as i32 == cells::DRY_GRASS_SIDE || cell as i32 == cells::SWAMP_GRASS_SIDE
}

/// All layers as tightly packed RGBA8 (`TILE_COUNT * 16 * 16 * 4` bytes), ready for `glTexImage3D`.
pub fn build_layers_rgba() -> Vec<u8> {
    let mut out = vec![0u8; cells::TILE_COUNT * TILE_PIXELS * 4];
    for layer in 0..cells::TILE_COUNT {
        let mut px = [0u32; TILE_PIXELS];
        let cell = layer as i32;
        if cell == cells::WATER {
            px = water_pixels();
        } else if cell == cells::WHITE {
            for p in px.iter_mut() {
                *p = 0xFFFF_FFFF;
            }
        } else if let Some(tile) = tile_argb(cell) {
            px = tile;
            if is_fringe_cell(layer) {
                for p in px.iter_mut() {
                    if is_grass_texel(*p) {
                        *p = ((255 - MASK_ALPHA_DROP) << 24) | (*p & 0x00FF_FFFF);
                    }
                }
            }
            // Transparent texels take the tile's mean colour, so mip-mapping does not bleed black into the edges.
            let mean = average_rgb(&px);
            let fill = (mean[0] << 16) | (mean[1] << 8) | mean[2];
            for p in px.iter_mut() {
                if (*p >> 24) == 0 {
                    *p = fill;
                }
            }
        }
        for (i, p) in px.iter().enumerate() {
            let o = (layer * TILE_PIXELS + i) * 4;
            out[o] = ((*p >> 16) & 0xFF) as u8;
            out[o + 1] = ((*p >> 8) & 0xFF) as u8;
            out[o + 2] = (*p & 0xFF) as u8;
            out[o + 3] = ((*p >> 24) & 0xFF) as u8;
        }
    }
    out
}

/// How much the alpha of a mip level must be scaled so that the share of texels that pass the pixel shader's
/// see-through test (alpha of at least one half) is `coverage`, the share the base image has. `alphas` are the
/// level's texel alphas (0..255).
fn coverage_scale(alphas: &[f32], coverage: f32) -> f32 {
    let n = alphas.len();
    let keep = ((coverage * n as f32).round() as usize).min(n);
    if keep == 0 {
        return 0.0;
    }
    let mut sorted: Vec<f32> = alphas.to_vec();
    sorted.sort_by(|a, b| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
    let edge = sorted[keep - 1];
    if edge <= 0.0 {
        return 1.0;
    }
    (127.5 / edge).max(0.25).min(8.0)
}

/// The mip levels below the base image of every layer: element `i` holds level `i + 1` (8x8, 4x4, 2x2, 1x1 texels)
/// of all layers, tightly packed RGBA8, ready for `glTexImage3D`.
///
/// Colour is the plain 2x2 box average, like `glGenerateMipmap`. Alpha is not: leaves and plants are drawn with a
/// see-through test (alpha under one half is thrown away), and the plain average of a sparse tile falls under that
/// line after a level or two, so a fern would vanish a few blocks away and flicker in and out as the mip level
/// changes while the player moves (it was very visible in the jungle). Here the alpha of each level is scaled so that
/// the share of texels that pass the test stays what it is in the base image.
pub fn build_mip_chain(base: &[u8]) -> Vec<Vec<u8>> {
    let layers = base.len() / (TILE_PIXELS * 4);
    let mut chain: Vec<Vec<u8>> = Vec::new();
    let mut lvl = 1usize;
    while (TILE_SIZE >> lvl) >= 1 {
        let s = TILE_SIZE >> lvl;
        chain.push(vec![0u8; layers * s * s * 4]);
        lvl += 1;
    }
    for layer in 0..layers {
        let img = &base[layer * TILE_PIXELS * 4..(layer + 1) * TILE_PIXELS * 4];
        let passing = img.chunks_exact(4).filter(|p| p[3] >= 128).count();
        let cutout = passing < TILE_PIXELS;
        let coverage = passing as f32 / TILE_PIXELS as f32;
        for (li, out) in chain.iter_mut().enumerate() {
            let s = TILE_SIZE >> (li + 1);
            let block = TILE_SIZE / s;
            let n = (block * block) as u32;
            let mut alphas: Vec<f32> = Vec::with_capacity(s * s);
            let mut colours: Vec<[u8; 3]> = Vec::with_capacity(s * s);
            for ty in 0..s {
                for tx in 0..s {
                    let (mut sr, mut sg, mut sb, mut sa) = (0u32, 0u32, 0u32, 0u32);
                    for dy in 0..block {
                        for dx in 0..block {
                            let o = ((ty * block + dy) * TILE_SIZE + tx * block + dx) * 4;
                            sr += img[o] as u32;
                            sg += img[o + 1] as u32;
                            sb += img[o + 2] as u32;
                            sa += img[o + 3] as u32;
                        }
                    }
                    colours.push([((sr + n / 2) / n) as u8, ((sg + n / 2) / n) as u8, ((sb + n / 2) / n) as u8]);
                    alphas.push(sa as f32 / n as f32);
                }
            }
            let scale = if cutout { coverage_scale(&alphas, coverage) } else { 1.0 };
            for i in 0..s * s {
                let o = (layer * s * s + i) * 4;
                out[o] = colours[i][0];
                out[o + 1] = colours[i][1];
                out[o + 2] = colours[i][2];
                out[o + 3] = (alphas[i] * scale + 0.5).min(255.0) as u8;
            }
        }
    }
    chain
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_water_tile_averages_to_the_water_colour_and_has_four_steps() {
        let px = water_pixels();
        let mut sum = [0u32; 3];
        let mut distinct = std::collections::HashSet::new();
        for &p in px.iter() {
            assert_eq!(p >> 24, 0xFF);
            sum[0] += (p >> 16) & 0xFF;
            sum[1] += (p >> 8) & 0xFF;
            sum[2] += p & 0xFF;
            distinct.insert(p);
        }
        for k in 0..3 {
            let mean = sum[k] as f32 / TILE_PIXELS as f32;
            assert!((mean - WATER_RGB[k] as f32).abs() < 3.0, "channel {}: {} vs {}", k, mean, WATER_RGB[k]);
        }
        assert!(distinct.len() >= 3 && distinct.len() <= 4, "{} colours", distinct.len());
    }

    #[test]
    fn the_mip_chain_has_four_levels_of_the_right_size() {
        let base = build_layers_rgba();
        let chain = build_mip_chain(&base);
        assert_eq!(chain.len(), 4);
        for (i, level) in chain.iter().enumerate() {
            let s = TILE_SIZE >> (i + 1);
            assert_eq!(level.len(), cells::TILE_COUNT * s * s * 4);
        }
    }

    #[test]
    fn see_through_tiles_do_not_thin_out_in_the_mip_levels() {
        let base = build_layers_rgba();
        let chain = build_mip_chain(&base);
        let s = TILE_SIZE / 2;
        for &cell in &[cells::FERN, cells::HIBISCUS, cells::JUNGLE_LEAVES, cells::HELICONIA_RED] {
            let layer = cell as usize;
            let img = &base[layer * TILE_PIXELS * 4..(layer + 1) * TILE_PIXELS * 4];
            let share = img.chunks_exact(4).filter(|p| p[3] >= 128).count() as f32 / TILE_PIXELS as f32;
            let lvl = &chain[0][layer * s * s * 4..(layer + 1) * s * s * 4];
            let kept = lvl.chunks_exact(4).filter(|p| p[3] >= 128).count() as f32 / (s * s) as f32;
            assert!(kept >= share * 0.7 - 0.02 && kept <= share * 2.0 + 0.05, "cell {}: {} of the texels pass at level 1, {} at level 0", cell, kept, share);
        }
    }

    #[test]
    fn solid_tiles_are_averaged_plainly() {
        let base = build_layers_rgba();
        let chain = build_mip_chain(&base);
        let layer = cells::STONE as usize;
        let last = &chain[3][layer * 4..layer * 4 + 4];
        assert_eq!(last[3], 255);
    }

    #[test]
    fn every_source_tile_decodes_inside_the_array() {
        for src in TILE_SRCS.iter() {
            assert!(src.cell < cells::TILE_COUNT, "tile {} out of range", src.name);
            assert_eq!(src.rows.len(), TILE_PIXELS, "tile {} has the wrong size", src.name);
        }
    }

    #[test]
    fn layer_buffer_has_the_right_size() {
        assert_eq!(build_layers_rgba().len(), cells::TILE_COUNT * TILE_PIXELS * 4);
    }

    #[test]
    fn grass_tiles_have_a_colour() {
        let t = tile_argb(cells::GRASS_TOP).unwrap();
        let m = average_rgb(&t);
        assert!(m[1] > m[0]);
    }
}
