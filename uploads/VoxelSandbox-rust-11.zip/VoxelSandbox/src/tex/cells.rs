//! Layer numbers of the block texture array (one layer per 16x16 tile). Same numbering as the
//! v15 atlas so every tile keeps its identity.

pub const GRASS_TOP: i32 = 0;
pub const GRASS_SIDE: i32 = 1;
pub const DIRT: i32 = 2;
pub const STONE: i32 = 3;
pub const SAND: i32 = 4;
pub const OAK_BARK: i32 = 5;
pub const OAK_RINGS: i32 = 6;
pub const OAK_LEAVES: i32 = 7;
pub const COAL_ORE: i32 = 8;
pub const WATER: i32 = 9;
pub const WHITE: i32 = 10;
pub const BIRCH_BARK: i32 = 11;
pub const BIRCH_LEAVES: i32 = 12;
pub const SPRUCE_LEAVES: i32 = 13;
pub const SPRUCE_BARK: i32 = 14;
pub const RAMP: i32 = 15;
pub const BIRCH_RINGS: i32 = 16;
pub const SPRUCE_RINGS: i32 = 17;
pub const SNOW: i32 = 18;
pub const SNOW_SIDE: i32 = 19;
pub const GRAVEL: i32 = 20;
pub const SANDSTONE_SIDE: i32 = 21;
pub const SANDSTONE_TOP: i32 = 22;
pub const DRY_GRASS_TOP: i32 = 23;
pub const DRY_GRASS_SIDE: i32 = 24;
pub const TALL_GRASS: i32 = 25;
pub const POPPY: i32 = 26;
pub const DANDELION: i32 = 27;
pub const DEAD_BUSH: i32 = 28;
pub const CACTUS_SIDE: i32 = 29;
pub const CACTUS_TOP: i32 = 30;
pub const LILY_PAD: i32 = 31;
pub const SEAGRASS_A: i32 = 32;
pub const SEAGRASS_B: i32 = 33;
pub const SWAMP_GRASS_TOP: i32 = 34;
pub const SWAMP_GRASS_SIDE: i32 = 35;
pub const DEEP_STONE: i32 = 36;
pub const JUNGLE_BARK: i32 = 37;
pub const JUNGLE_RINGS: i32 = 38;
pub const JUNGLE_LEAVES: i32 = 39;
pub const FERN: i32 = 40;
pub const VINE: i32 = 41;
pub const HIBISCUS: i32 = 42;
// Amazon rainforest tiles (see tools/gen_amazon_tiles.py). The mesher picks among them by position, so one
// block can show several looks (ferns, understory flowers, lianas, leaves, bark).
pub const FERN_B: i32 = 43;
pub const BROADLEAF: i32 = 44;
pub const PALM_SAPLING: i32 = 45;
pub const HELICONIA_RED: i32 = 46;
pub const HELICONIA_YELLOW: i32 = 47;
pub const BROMELIAD: i32 = 48;
pub const ORCHID: i32 = 49;
pub const VINE_FLOWER: i32 = 50;
pub const LILY_FLOWER: i32 = 51;
pub const JUNGLE_LEAVES_B: i32 = 52;
pub const JUNGLE_BARK_B: i32 = 53;
pub const FUNGI: i32 = 54;

/// Number of layers in the texture array.
pub const TILE_COUNT: usize = 55;
