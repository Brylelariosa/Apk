//! Underground biomes. The surface climate (and a slow noise of its own, so the underground is not a mirror of the
//! surface) decides what a cave is like: lush under warm, wet country, frozen under cold, sandy under hot dry
//! country, and bare gravel in the deep. A cave biome only changes the floor and the ceiling of what the carver
//! already opened, and only looks up and down, so a chunk decorates the same on its own as next to its neighbours.

use std::sync::Arc;

use super::climate::Climate;
use super::genmath::mix_seed;
use super::noise::NoiseGenerator;
use crate::world::block::Block;
use crate::world::chunk::ChunkData;

/// At and below this height every cave is a deep cave.
pub const DEEP_MAX_Y: i32 = 18;
/// Caves are classified on a lattice this many blocks wide.
const CELL: i32 = 4;
const FREQ: f64 = 1.0 / 170.0;
const WANDER: f64 = 0.22;

const FROZEN_T: f64 = -0.05;
const LUSH_HU: f64 = 0.25;
const LUSH_T: f64 = 0.12;
const SANDY_T: f64 = 0.34;
const SANDY_HU: f64 = 0.0;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum CaveBiome {
    /// Plain rock.
    Stone,
    /// Grass and ferns on the floor, vines from the ceiling.
    Lush,
    /// Snow and gravel on the floor.
    Frozen,
    /// Sand on the floor, sandstone above.
    Sandy,
    /// Gravel on the floor of the deepest caves.
    Deep,
}

impl CaveBiome {
    pub fn name(self) -> &'static str {
        match self {
            CaveBiome::Stone => "Stone Cave",
            CaveBiome::Lush => "Lush Cave",
            CaveBiome::Frozen => "Frozen Cave",
            CaveBiome::Sandy => "Sand Cave",
            CaveBiome::Deep => "Deep Cavern",
        }
    }
}

pub struct CaveBiomes {
    climate: Arc<Climate>,
    noise: NoiseGenerator,
    salt: i32,
}

/// A hash of a block position, for scattering decorations (the same in every chunk that sees the block).
fn hash(x: i32, y: i32, z: i32, salt: i32) -> u32 {
    let mut h = (x.wrapping_mul(374761393) as u32)
        .wrapping_add((y.wrapping_mul(668265263)) as u32)
        .wrapping_add((z.wrapping_mul(1274126177)) as u32)
        .wrapping_add(salt as u32);
    h = (h ^ (h >> 13)).wrapping_mul(3266489917);
    h ^ (h >> 16)
}

fn is_rock(b: Block) -> bool {
    matches!(b, Block::Stone | Block::DeepStone | Block::Dirt | Block::Gravel | Block::Sandstone | Block::Sand)
}

impl CaveBiomes {
    pub fn new(seed: i64, climate: Arc<Climate>) -> CaveBiomes {
        CaveBiomes { climate, noise: NoiseGenerator::new(mix_seed(seed, 92)), salt: mix_seed(seed, 93) as i32 }
    }

    /// The cave biome above the deep (decided by the climate only).
    pub fn column(&self, wx: i32, wz: i32) -> CaveBiome {
        let (x, z) = (wx as f64, wz as f64);
        let t = self.climate.base_temperature(x, z) + WANDER * self.noise.noise2d(x * FREQ + 11.0, z * FREQ - 7.0);
        let h = self.climate.humidity(x, z) + WANDER * self.noise.noise2d(x * FREQ - 31.0, z * FREQ + 19.0);
        if t < FROZEN_T {
            CaveBiome::Frozen
        } else if h > LUSH_HU && t > LUSH_T {
            CaveBiome::Lush
        } else if t > SANDY_T && h < SANDY_HU {
            CaveBiome::Sandy
        } else {
            CaveBiome::Stone
        }
    }

    /// The cave biome at a block.
    pub fn at(&self, wx: i32, y: i32, wz: i32) -> CaveBiome {
        if y <= DEEP_MAX_Y {
            CaveBiome::Deep
        } else {
            self.column(wx, wz)
        }
    }

    /// Dresses the caves of a chunk. `top[lz * 16 + lx]` is the highest Y the carver opened in that column (below
    /// `y_lo` for none); only open cells between `y_lo` and there are touched.
    pub fn decorate(&self, chunk: &mut ChunkData, bx: i32, bz: i32, y_lo: i32, top: &[i32; 256]) {
        if top.iter().all(|&t| t < y_lo) {
            return;
        }
        let mut lattice = [CaveBiome::Stone; 16];
        for cz in 0..4 {
            for cx in 0..4 {
                lattice[(cz * 4 + cx) as usize] = self.column(bx + cx * CELL + CELL / 2, bz + cz * CELL + CELL / 2);
            }
        }
        for lz in 0..16 {
            for lx in 0..16 {
                let lim = top[(lz * 16 + lx) as usize];
                if lim < y_lo {
                    continue;
                }
                let up = lattice[((lz / CELL) * 4 + lx / CELL) as usize];
                let (wx, wz) = (bx + lx, bz + lz);
                for y in y_lo..=lim {
                    if chunk.get(lx, y, lz) != Block::Air {
                        continue;
                    }
                    let biome = if y <= DEEP_MAX_Y { CaveBiome::Deep } else { up };
                    if biome == CaveBiome::Stone {
                        continue;
                    }
                    let h = hash(wx, y, wz, self.salt);
                    if y > 0 {
                        let below = chunk.get(lx, y - 1, lz);
                        if is_rock(below) {
                            self.floor(chunk, biome, lx, y, lz, h, wx, wz);
                        }
                    }
                    if y + 1 < crate::world::config::WORLD_HEIGHT {
                        let above = chunk.get(lx, y + 1, lz);
                        if is_rock(above) {
                            self.ceiling(chunk, biome, lx, y, lz, lim, h);
                        }
                    }
                }
            }
        }
    }

    /// The floor under the open cell (lx, y, lz), and what grows on it.
    #[allow(clippy::too_many_arguments)]
    fn floor(&self, chunk: &mut ChunkData, biome: CaveBiome, lx: i32, y: i32, lz: i32, h: u32, wx: i32, wz: i32) {
        let roll = h % 100;
        match biome {
            CaveBiome::Lush => {
                chunk.set(lx, y - 1, lz, if roll < 88 { Block::Grass } else { Block::Dirt });
                let g = (h >> 8) % 100;
                let plant = if g < 24 {
                    Block::TallGrass
                } else if g < 36 {
                    Block::Fern
                } else if g < 40 {
                    Block::Poppy
                } else if g < 43 {
                    Block::Dandelion
                } else {
                    Block::Air
                };
                if plant != Block::Air {
                    chunk.set(lx, y, lz, plant);
                }
            }
            CaveBiome::Frozen => {
                if roll < 70 {
                    chunk.set(lx, y - 1, lz, Block::Snow);
                } else if roll < 82 {
                    chunk.set(lx, y - 1, lz, Block::Gravel);
                }
            }
            CaveBiome::Sandy => {
                chunk.set(lx, y - 1, lz, if roll < 72 { Block::Sand } else { Block::Sandstone });
                if (h >> 8) % 100 < 5 {
                    chunk.set(lx, y, lz, Block::DeadBush);
                }
            }
            CaveBiome::Deep => {
                // gravel lies in patches, not as speckle
                let patch = self.noise.noise2d(wx as f64 / 9.0 + 3.0, wz as f64 / 9.0 - 5.0);
                if patch > 0.05 && roll < 85 {
                    chunk.set(lx, y - 1, lz, Block::Gravel);
                }
            }
            CaveBiome::Stone => {}
        }
    }

    /// The ceiling over the open cell (lx, y, lz), and what hangs from it.
    #[allow(clippy::too_many_arguments)]
    fn ceiling(&self, chunk: &mut ChunkData, biome: CaveBiome, lx: i32, y: i32, lz: i32, lim: i32, h: u32) {
        match biome {
            CaveBiome::Lush => {
                if (h >> 16) % 100 < 24 {
                    let len = 1 + (h >> 24) % 3;
                    let mut yy = y;
                    for _ in 0..len {
                        if yy < 1 || chunk.get(lx, yy, lz) != Block::Air {
                            break;
                        }
                        chunk.set(lx, yy, lz, Block::Vine);
                        yy -= 1;
                    }
                }
            }
            CaveBiome::Sandy => {
                if (h >> 16) % 100 < 45 && y + 1 <= lim + 1 {
                    chunk.set(lx, y + 1, lz, Block::Sandstone);
                }
            }
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::config::WORLD_HEIGHT;

    fn biomes(seed: i64) -> CaveBiomes {
        CaveBiomes::new(seed, Arc::new(Climate::new(seed)))
    }

    #[test]
    fn the_deep_is_deep_everywhere_and_the_rest_follows_the_climate() {
        let b = biomes(3);
        for i in 0..50 {
            assert_eq!(b.at(i * 977, DEEP_MAX_Y, -i * 311), CaveBiome::Deep);
            assert_eq!(b.at(i * 977, DEEP_MAX_Y + 1, -i * 311), b.column(i * 977, -i * 311));
        }
    }

    #[test]
    fn every_surface_cave_biome_turns_up_over_the_world() {
        let b = biomes(555);
        let mut seen = [0usize; 4];
        for iz in -60..60 {
            for ix in -60..60 {
                match b.column(ix * 400, iz * 400) {
                    CaveBiome::Stone => seen[0] += 1,
                    CaveBiome::Lush => seen[1] += 1,
                    CaveBiome::Frozen => seen[2] += 1,
                    CaveBiome::Sandy => seen[3] += 1,
                    CaveBiome::Deep => panic!("column never says deep"),
                }
            }
        }
        assert!(seen.iter().all(|&n| n > 14400 / 40), "every kind has a fair share: {:?}", seen);
    }

    /// A flat slab of rock with a hollow in it, for the decoration rules.
    fn hollow(y0: i32, y1: i32) -> ChunkData {
        let mut c = ChunkData::new();
        for lz in 0..16 {
            for lx in 0..16 {
                for y in 1..60 {
                    c.set(lx, y, lz, Block::Stone);
                }
                for y in y0..=y1 {
                    c.set(lx, y, lz, Block::Air);
                }
            }
        }
        c
    }

    #[test]
    fn decoration_only_touches_the_floor_and_ceiling_of_open_cells() {
        // find a chunk of each biome so that every rule runs
        let b = biomes(555);
        let mut checked = [false; 3];
        for cx in -400..400 {
            let (bx, bz) = (cx * 16, cx * 7 * 16);
            let kind = b.column(bx + 8, bz + 8);
            let slot = match kind {
                CaveBiome::Lush => 0,
                CaveBiome::Frozen => 1,
                CaveBiome::Sandy => 2,
                _ => continue,
            };
            if checked[slot] {
                continue;
            }
            checked[slot] = true;
            let before = hollow(30, 33);
            let mut after = hollow(30, 33);
            let mut top = [0i32; 256];
            for t in top.iter_mut() {
                *t = 33;
            }
            b.decorate(&mut after, bx, bz, 6, &top);
            let mut changed = 0;
            for lz in 0..16 {
                for lx in 0..16 {
                    for y in 0..WORLD_HEIGHT {
                        let (p, q) = (before.get(lx, y, lz), after.get(lx, y, lz));
                        if p == q {
                            continue;
                        }
                        changed += 1;
                        assert!((29..=34).contains(&y), "{:?} changed at y {}", kind, y);
                        // a rock block turned into another floor / ceiling block or an open cell got a plant or a vine
                        assert!(p != Block::Air || matches!(q, Block::TallGrass | Block::Fern | Block::Poppy | Block::Dandelion | Block::DeadBush | Block::Vine), "{:?}: air became {:?}", kind, q);
                    }
                    // a vine hangs from rock or from another vine
                    for y in 30..=33 {
                        if after.get(lx, y, lz) == Block::Vine {
                            let above = after.get(lx, y + 1, lz);
                            assert!(is_rock(above) || above == Block::Vine, "{:?} vine under {:?}", kind, above);
                        }
                    }
                }
            }
            assert!(changed > 20, "{:?} left the cave as it was ({} changed)", kind, changed);
        }
        assert!(checked.iter().all(|&c| c), "found every kind of chunk: {:?}", checked);
    }

    #[test]
    fn the_deep_gets_gravel_and_the_same_decoration_comes_out_twice() {
        let b = biomes(555);
        let mut top = [0i32; 256];
        for t in top.iter_mut() {
            *t = 14;
        }
        let mut a = hollow(8, 14);
        let mut c = hollow(8, 14);
        b.decorate(&mut a, 160, 320, 6, &top);
        b.decorate(&mut c, 160, 320, 6, &top);
        let mut gravel = 0;
        for lz in 0..16 {
            for lx in 0..16 {
                for y in 0..60 {
                    assert_eq!(a.get(lx, y, lz), c.get(lx, y, lz));
                    if a.get(lx, y, lz) == Block::Gravel {
                        gravel += 1;
                    }
                }
            }
        }
        assert!(gravel > 10, "{}", gravel);
    }

    #[test]
    fn a_chunk_without_caves_is_left_alone() {
        let b = biomes(1);
        let mut c = hollow(30, 33);
        let reference = hollow(30, 33);
        b.decorate(&mut c, 0, 0, 6, &[2; 256]);
        for lz in 0..16 {
            for lx in 0..16 {
                for y in 0..60 {
                    assert_eq!(c.get(lx, y, lz), reference.get(lx, y, lz));
                }
            }
        }
    }
}
