//! Which OpenGL errors are worth a line in the debug log.
//!
//! A driver that objects to something does so at once and keeps objecting, so the renderer reads the error flag only in
//! the first frames after it started (reading it can cost a round trip to the driver), and each error is reported once
//! for each place it was found. The GL calls themselves are the renderer's; this is only the bookkeeping.

/// How many frames after the start the error flag is read.
pub const WATCHED_FRAMES: u32 = 300;
/// The most lines one run puts in the log.
const MAX_REPORTS: usize = 24;

pub struct ErrorWatch {
    frames_left: u32,
    reported: Vec<(u32, &'static str)>,
}

impl ErrorWatch {
    pub fn new() -> ErrorWatch {
        ErrorWatch { frames_left: WATCHED_FRAMES, reported: Vec::new() }
    }

    /// True while the error flag should be read.
    pub fn active(&self) -> bool {
        self.frames_left > 0
    }

    /// Call when a frame is done.
    pub fn end_frame(&mut self) {
        self.frames_left = self.frames_left.saturating_sub(1);
    }

    /// Which frame since the start this is (the first is 1).
    fn frame(&self) -> u32 {
        WATCHED_FRAMES - self.frames_left.min(WATCHED_FRAMES) + 1
    }

    /// An error `code` was found right after drawing `stage`. The line for the log, unless this error was already
    /// reported for this stage or the log has had enough of them.
    pub fn report(&mut self, code: u32, stage: &'static str) -> Option<String> {
        if self.reported.len() >= MAX_REPORTS || self.reported.contains(&(code, stage)) {
            return None;
        }
        self.reported.push((code, stage));
        Some(format!("GL error {} (0x{:04X}) after drawing {} (frame {} of the run)", error_name(code), code, stage, self.frame()))
    }
}

pub fn error_name(code: u32) -> &'static str {
    match code {
        0x0500 => "INVALID_ENUM",
        0x0501 => "INVALID_VALUE",
        0x0502 => "INVALID_OPERATION",
        0x0505 => "OUT_OF_MEMORY",
        0x0506 => "INVALID_FRAMEBUFFER_OPERATION",
        0x0507 => "CONTEXT_LOST",
        _ => "unknown",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_error_is_reported_once_for_each_stage() {
        let mut w = ErrorWatch::new();
        let first = w.report(0x0502, "the UI").expect("a new error is reported");
        assert!(first.contains("INVALID_OPERATION") && first.contains("0x0502") && first.contains("the UI"), "{}", first);
        assert!(w.report(0x0502, "the UI").is_none(), "the same error at the same place is not repeated");
        assert!(w.report(0x0502, "the sky").is_some(), "but the same error somewhere else is news");
        assert!(w.report(0x0501, "the UI").is_some(), "and so is another error at the same place");
    }

    #[test]
    fn the_flag_is_only_read_in_the_first_frames() {
        let mut w = ErrorWatch::new();
        assert!(w.active());
        for _ in 0..WATCHED_FRAMES - 1 {
            w.end_frame();
        }
        assert!(w.active(), "the last watched frame is still watched");
        w.end_frame();
        assert!(!w.active());
        w.end_frame();
        assert!(!w.active(), "and it stays off");
    }

    #[test]
    fn the_report_says_which_frame_it_was() {
        let mut w = ErrorWatch::new();
        for _ in 0..4 {
            w.end_frame();
        }
        let line = w.report(0x0505, "the world").unwrap();
        assert!(line.contains("frame 5 "), "{}", line);
    }

    #[test]
    fn a_log_is_not_flooded() {
        let mut w = ErrorWatch::new();
        let stages: [&'static str; 6] = ["a", "b", "c", "d", "e", "f"];
        let codes = [0x0500u32, 0x0501, 0x0502, 0x0505, 0x0506];
        let mut lines = 0;
        for c in codes {
            for s in stages {
                if w.report(c, s).is_some() {
                    lines += 1;
                }
            }
        }
        assert_eq!(lines, MAX_REPORTS);
    }

    #[test]
    fn errors_have_names() {
        assert_eq!(error_name(0x0502), "INVALID_OPERATION");
        assert_eq!(error_name(0x0505), "OUT_OF_MEMORY");
        assert_eq!(error_name(0x1234), "unknown");
    }
}
