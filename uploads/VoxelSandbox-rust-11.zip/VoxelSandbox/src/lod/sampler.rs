//! Reads the terrain generator to fill the cells of a far-terrain tile: ground height and ground colour at the
//! middle of every cell, taken from the same land-form and climate functions the real chunks are generated from, so
//! the far hills line up with the real ones. Nothing here touches OpenGL, so it runs (and is tested) on a normal
//! computer.

use std::sync::Arc;

use super::cells::{cell_noise, Cell, CellGrid, GRID};
use super::mesh::{build_tile_mesh, FarTileData};
use super::tiles::{TileKey, BASE_CELL, CELLS};
use crate::gen::climate::{Biome, SurfaceKind};
use crate::gen::terrain::{TerrainGenerator, TreeSpot};
use crate::gen::trees::{tree_height, TreeSpecies};
use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
use crate::tex::{self, cells, WATER_RGB};
use crate::world::config::SEA_LEVEL;

const SEA: f64 = SEA_LEVEL as f64;
/// Where the far sea surface is: a little below the top of a block, like the real water.
pub const WATER_TOP: f32 = SEA_LEVEL as f32 - 0.125;
/// How leaves look against the grass they stand on: darker, and a deeper green (leaves of one kind of forest, as fractions of
/// the ground colour). Forests that are not listed in `leaf_tone` use `OAK_LEAVES`.
const OAK_LEAVES: [f32; 3] = [0.50, 0.66, 0.50];
const BIRCH_LEAVES: [f32; 3] = [0.68, 0.80, 0.56];
const SPRUCE_LEAVES: [f32; 3] = [0.40, 0.58, 0.48];
/// How much darker than the ground colour a column's top can be where there are trees: the crowns of single trees are
/// lighter and darker by turns, so that a far forest is a lumpy roof and not a flat carpet.
const CROWN_VARIATION: f32 = 0.24;
/// How much darker than the ground colour a column's top can be (each column gets its own amount, so the columns
/// read as separate blocks).
const LAND_VARIATION: f32 = 0.07;
/// The direction of the sun (towards it), for the shading of slopes: hills that face it are lit, the others darker.
const SUN: [f64; 3] = [-0.45, 0.78, -0.43];
/// Brightness of a slope: `SHADE_BASE + SHADE_GAIN * (normal . sun)`, which is 1.0 on flat ground.
/// (Softer than it was: with the darkest slopes at two thirds of the ground colour, and the walls shaded on top of that,
/// distant mountains came out as dark slate.)
const SHADE_BASE: f32 = 0.594;
const SHADE_GAIN: f32 = 0.52;
const SHADE_MIN: f32 = 0.78;
const SHADE_MAX: f32 = 1.14;
/// Sea depth is rounded to steps of this many blocks, so that stretches of sea of one depth share one colour.
const DEPTH_STEP: f32 = 2.0;
const DEPTH_STEPS: f32 = 12.0;
/// Where inside a cell of the finest levels the ground is also looked at (fractions of the cell from its middle).
const PROBES: [(f64, f64); 4] = [(-0.25, -0.25), (0.25, -0.25), (-0.25, 0.25), (0.25, 0.25)];
/// Levels up to this one (cells of 4, 8 and 16 blocks) draw the crown of every single tree, from the tree positions the
/// chunks are built from; coarser levels can only tell what the forest is like on average (see `FarSampler::canopy_of`).
const CROWN_LEVELS: usize = 2;
/// The widest crown reaches this far from its trunk (`TREE_REACH` in the terrain generator).
const CROWN_REACH: f64 = 9.0;
/// Tree cells are this many blocks wide (`CELL` in the terrain generator).
const TREE_CELL: f64 = 4.0;

/// Average colours of the ground tiles (0..255).
#[derive(Clone, Copy, Debug)]
struct GroundColors {
    sand: [f32; 3],
    gravel: [f32; 3],
    stone: [f32; 3],
    snow: [f32; 3],
    dirt: [f32; 3],
    water: [f32; 3],
}

fn tile_mean(cell: i32) -> [f32; 3] {
    match tex::tile_argb(cell) {
        Some(t) => {
            let m = tex::average_rgb(&t);
            [m[0] as f32, m[1] as f32, m[2] as f32]
        }
        None => [128.0, 128.0, 128.0],
    }
}

impl GroundColors {
    fn from_tiles() -> GroundColors {
        GroundColors {
            sand: tile_mean(cells::SAND),
            gravel: tile_mean(cells::GRAVEL),
            stone: tile_mean(cells::STONE),
            snow: tile_mean(cells::SNOW),
            dirt: tile_mean(cells::DIRT),
            water: [WATER_RGB[0] as f32, WATER_RGB[1] as f32, WATER_RGB[2] as f32],
        }
    }
}

fn mix(a: [f32; 3], b: [f32; 3], t: f32) -> [f32; 3] {
    let t = t.max(0.0).min(1.0);
    [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
}

fn scale(a: [f32; 3], k: f32) -> [f32; 3] {
    [a[0] * k, a[1] * k, a[2] * k]
}

fn to_bytes(c: [f32; 3]) -> [u8; 3] {
    let b = |v: f32| v.max(0.0).min(255.0).round() as u8;
    [b(c[0]), b(c[1]), b(c[2])]
}

/// What the ground of one land column looks like.
struct Ground {
    top: [f32; 3],
    wall: [f32; 3],
    /// How many blocks the crowns of the trees stand above the ground here (0 in open country).
    canopy: f32,
}

/// 0 for a thin tree cover, 1 for a closed forest: how much of the full tree height a column of crowns gets.
fn crown_ramp(cover: f32) -> f32 {
    let t = ((cover - 0.30) / 0.55).max(0.0).min(1.0);
    t * t * (3.0 - 2.0 * t)
}

/// The trees standing in a far cell (see `FarSampler::canopy_of`).
struct Canopy {
    /// Height (absolute, in blocks) of the top of the crowns.
    top: f32,
    /// How much lighter or darker than the usual forest green the leaves of the tallest tree are.
    tone: f32,
}

/// Brightness of the crown of each tree species, so that a far rainforest is not one flat green: palms and
/// cecropias are light, figs dark.
fn crown_tone(species: TreeSpecies) -> f32 {
    match species {
        TreeSpecies::Palm => 1.22,
        TreeSpecies::Cecropia => 1.30,
        TreeSpecies::Shrub => 1.10,
        TreeSpecies::Jungle => 1.05,
        TreeSpecies::Fig => 0.86,
        TreeSpecies::BrazilNut => 0.95,
        TreeSpecies::Giant => 0.97,
        _ => 1.0,
    }
}

/// How far the leaves of a tree reach from its trunk, how much lower than the very top of the tree they are out there, and
/// whether the crown is a cone (a spruce) and not a dome. Taken from the shapes in `gen::trees`.
fn crown_shape(species: TreeSpecies) -> (f32, f32, bool) {
    match species {
        TreeSpecies::Oak => (3.0, 2.8, false),
        TreeSpecies::Birch => (2.4, 2.8, false),
        TreeSpecies::Spruce => (3.0, 5.0, true),
        TreeSpecies::Jungle => (4.6, 2.6, false),
        TreeSpecies::RainTree => (5.8, 2.8, false),
        TreeSpecies::Giant => (8.0, 2.6, false),
        TreeSpecies::Palm => (5.0, 3.0, false),
        TreeSpecies::Cecropia => (4.6, 1.6, false),
        TreeSpecies::BrazilNut => (5.8, 4.4, false),
        TreeSpecies::Fig => (7.2, 3.9, false),
        TreeSpecies::Shrub => (2.2, 1.4, false),
    }
}

/// The trees of a block of tree cells, looked up once for a whole tile: every cell of a fine level asks about all the trees
/// around it, and the answer must not depend on which tile asks (the walls along a shared edge rely on that).
struct TreeGrid {
    first_x: i32,
    first_z: i32,
    nx: usize,
    nz: usize,
    spots: Vec<Option<TreeSpot>>,
}

impl TreeGrid {
    /// The trees that can have leaves over the area `x0..x1` by `z0..z1` (world blocks).
    fn build(terrain: &TerrainGenerator, x0: f64, z0: f64, x1: f64, z1: f64) -> TreeGrid {
        let first_x = ((x0 - CROWN_REACH) / TREE_CELL).floor() as i32 - 1;
        let first_z = ((z0 - CROWN_REACH) / TREE_CELL).floor() as i32 - 1;
        let last_x = ((x1 + CROWN_REACH) / TREE_CELL).floor() as i32;
        let last_z = ((z1 + CROWN_REACH) / TREE_CELL).floor() as i32;
        let nx = (last_x - first_x + 1).max(1) as usize;
        let nz = (last_z - first_z + 1).max(1) as usize;
        let mut spots = Vec::with_capacity(nx * nz);
        for jz in 0..nz {
            for jx in 0..nx {
                spots.push(terrain.tree_spot(first_x + jx as i32, first_z + jz as i32));
            }
        }
        TreeGrid { first_x, first_z, nx, nz, spots }
    }

    /// The tree standing in tree cell (`jx`, `jz`), if there is one (and the cell is inside the grid).
    fn get(&self, jx: i32, jz: i32) -> Option<&TreeSpot> {
        let ix = jx - self.first_x;
        let iz = jz - self.first_z;
        if ix < 0 || iz < 0 || ix >= self.nx as i32 || iz >= self.nz as i32 {
            return None;
        }
        self.spots[iz as usize * self.nx + ix as usize].as_ref()
    }
}

/// The height (absolute, in blocks) of the highest leaves over the point (`x`, `z`) and the tone of the tree they belong to;
/// `None` where no crown reaches it. A crown is a dome (or a cone) as wide as the real tree's leaves, so a far forest is a
/// lumpy roof of rounded crowns and not a field of poles.
fn crown_at(trees: &TreeGrid, x: f64, z: f64) -> Option<(f32, f32)> {
    let jx0 = ((x - CROWN_REACH) / TREE_CELL).floor() as i32 - 1;
    let jx1 = ((x + CROWN_REACH) / TREE_CELL).floor() as i32;
    let jz0 = ((z - CROWN_REACH) / TREE_CELL).floor() as i32 - 1;
    let jz1 = ((z + CROWN_REACH) / TREE_CELL).floor() as i32;
    let mut best: Option<(f32, f32)> = None;
    for jz in jz0..=jz1 {
        for jx in jx0..=jx1 {
            let spot = match trees.get(jx, jz) {
                Some(s) => s,
                None => continue,
            };
            let (reach, thick, cone) = crown_shape(spot.species);
            let reach = reach as f64;
            let dx = spot.x as f64 + 0.5 - x;
            let dz = spot.z as f64 + 0.5 - z;
            let d2 = dx * dx + dz * dz;
            if d2 >= reach * reach {
                continue;
            }
            let t = (d2.sqrt() / reach) as f32;
            let drop = if cone { thick * t } else { thick * t * t };
            let top = (spot.ground + tree_height(spot.species, spot.th)) as f32 - drop;
            let better = match best {
                Some((b, _)) => top > b,
                None => true,
            };
            if better {
                best = Some((top, crown_tone(spot.species)));
            }
        }
    }
    best
}

/// What the crowns of the trees make of a far cell of one of the finest levels.
struct Crowned {
    /// Height (absolute, in blocks) of the leaves over the cell.
    top: f32,
    /// How much of the cell is under leaves, 0..1.
    cover: f32,
    /// How much lighter or darker than the usual forest green the leaves are.
    tone: f32,
}

/// The crowns over cell (`ix`, `iz`) of `level`, found by looking at a few points of the cell: one for the 4-block cells,
/// 2 x 2 for the 8-block ones, 4 x 4 for the 16-block ones. `ground_top` is the height of the column without trees.
/// Returns `None` where no crown covers any of the points.
fn cell_crowns(trees: &TreeGrid, level: usize, ix: i64, iz: i64, ground_top: f32) -> Option<Crowned> {
    let cell = (BASE_CELL as f64) * ((1i64 << level) as f64);
    let n: i32 = match level {
        0 => 1,
        1 => 2,
        _ => 4,
    };
    let mut covered = 0i32;
    let mut sum = 0.0f32;
    let mut tallest = 0.0f32;
    let mut tone = 1.0f32;
    for sz in 0..n {
        for sx in 0..n {
            let x = (ix as f64 + (sx as f64 + 0.5) / (n as f64)) * cell;
            let z = (iz as f64 + (sz as f64 + 0.5) / (n as f64)) * cell;
            if let Some((top, t)) = crown_at(trees, x, z) {
                covered += 1;
                sum += top;
                if top > tallest {
                    tallest = top;
                    tone = t;
                }
            }
        }
    }
    if covered == 0 {
        return None;
    }
    let cover = covered as f32 / (n * n) as f32;
    let mean = sum / covered as f32;
    // a big cell is as high as the middle of its crowns, with a little of its highest tree
    let crowns = mean + (tallest - mean) * 0.3;
    // a cell that is only partly under leaves stands lower
    let weight = (cover * 1.6).min(1.0);
    let top = ground_top + (crowns - ground_top).max(0.0) * weight;
    Some(Crowned { top, cover, tone: 1.0 + (tone - 1.0) * weight })
}

/// World coordinate of the middle of cell number `index` of a level whose cells are `cell` blocks wide.
fn cell_middle(index: i64, cell: f64) -> f64 {
    (index as f64 + 0.5) * cell
}

pub struct FarSampler {
    gen: Arc<TerrainGenerator>,
    field: BiomeColorField,
    colors: GroundColors,
}

impl FarSampler {
    pub fn new(gen: Arc<TerrainGenerator>) -> FarSampler {
        let field = BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles());
        FarSampler { gen, field, colors: GroundColors::from_tiles() }
    }

    /// Colour of the sea over a sea floor `h` blocks high: a blend of the floor and the water colour, darker and
    /// less see-through where it is deep, in a few steps of depth.
    fn sea_color(&self, h: f64) -> [u8; 3] {
        let c = &self.colors;
        let step = (((SEA - h) as f32) / DEPTH_STEP).floor().max(0.0).min(DEPTH_STEPS);
        let depth = step * DEPTH_STEP + DEPTH_STEP * 0.5;
        let shallow = 1.0 - (depth / 10.0).min(1.0);
        let floor = mix(scale(c.gravel, 0.55), c.sand, shallow);
        let tint = scale(c.water, 0.95 - 0.28 * (depth / 20.0).min(1.0));
        to_bytes(mix(floor, tint, 0.62 + 0.28 * (1.0 - shallow)))
    }

    /// Colours of a land column. `slope` is rise over run of the surrounding ground. `crowned` is how much of the column is
    /// under the leaves of single trees (the finest levels know that); `None` where the forest can only be guessed at.
    fn ground(&self, wx: f64, wz: f64, h: f64, coast: f64, slope: f64, crowned: Option<f32>) -> Ground {
        let climate = &self.gen.climate;
        let c = &self.colors;
        let ground = h.floor();
        let t0 = climate.base_temperature(wx, wz);
        let hum = climate.humidity(wx, wz);
        let biome = climate.biome_with(wx, wz, ground, slope, coast, t0, hum);
        let kind = climate.surface_for(biome, wx, wz, ground, slope);
        let (mut top, mut wall) = match kind {
            SurfaceKind::Grass | SurfaceKind::DryGrass | SurfaceKind::Swamp => {
                let grass = self.field.grass(wx, wz, h, coast, t0, hum);
                // the side of a step in grass land is mostly the dirt under the grass
                (grass, mix(grass, c.dirt, 0.6))
            }
            SurfaceKind::Desert | SurfaceKind::Beach => (c.sand, scale(c.sand, 0.96)),
            SurfaceKind::Snow => (c.snow, mix(c.snow, c.dirt, 0.45)),
            SurfaceKind::Rock => {
                // Bands of slightly different rock, so that a cliff shows strata. The rock is as light as the real
                // stone (it used to be darkened a second time for the walls, which turned mountains to slate).
                let tone = match (ground as i32).div_euclid(5).rem_euclid(4) {
                    0 => [1.04, 1.00, 0.93],
                    1 => [0.97, 0.97, 0.98],
                    2 => [1.01, 0.98, 0.92],
                    _ => [0.93, 0.94, 0.97],
                };
                let rock = [c.stone[0] * tone[0], c.stone[1] * tone[1], c.stone[2] * tone[2]];
                (scale(rock, 1.03), rock)
            }
            SurfaceKind::Gravel => (c.gravel, scale(c.gravel, 0.9)),
        };
        // Trees: a forest is a dark green carpet from far away, and a raised one: the crowns stand above the ground.
        let trees = self.gen.tree_density(biome);
        let tropical = biome == Biome::Jungle || biome == Biome::Rainforest;
        let mut canopy_rise = 0.0f32;
        if trees > 0.0 && kind != SurfaceKind::Rock && kind != SurfaceKind::Gravel {
            let cover = match crowned {
                Some(c) => c,
                None => {
                    if tropical {
                        1.0
                    } else {
                        self.gen.tree_cover(biome, climate.forest(wx, wz)) as f32
                    }
                }
            };
            // the leaves of single trees are lighter than the carpet of a whole forest, which has its shade in it
            let carpet = if crowned.is_some() { 1.0 } else { 0.82 };
            let tone = match biome {
                Biome::BirchForest => BIRCH_LEAVES,
                Biome::Taiga | Biome::SnowyTaiga => SPRUCE_LEAVES,
                _ => OAK_LEAVES,
            };
            if cover > 0.0 {
                let canopy = |rgb: [f32; 3]| {
                    if kind == SurfaceKind::Snow {
                        [44.0, 74.0, 52.0]
                    } else if biome == Biome::Rainforest {
                        [22.0, 96.0, 30.0]
                    } else if biome == Biome::Jungle {
                        [30.0, 112.0, 36.0]
                    } else {
                        [rgb[0] * tone[0] * carpet, rgb[1] * tone[1] * carpet, rgb[2] * tone[2] * carpet]
                    }
                };
                let blend = match crowned {
                    Some(c) => 0.92 * c,
                    None => {
                        if tropical {
                            0.92
                        } else {
                            0.8 * cover
                        }
                    }
                };
                top = mix(top, canopy(top), blend);
                wall = mix(wall, canopy(wall), blend);
                let tree_height = match biome {
                    Biome::Rainforest => 24.0,
                    Biome::Jungle => 15.0,
                    Biome::Forest | Biome::BirchForest | Biome::Taiga | Biome::SnowyTaiga => 8.0,
                    _ => 5.0,
                };
                canopy_rise = tree_height * crown_ramp(cover);
            }
        }
        Ground { top, wall, canopy: canopy_rise }
    }

    /// The trees of a far cell of one of the finest levels, from the very tree positions the chunks are built from
    /// (`TerrainGenerator::tree_spot`): the far forest has the trees the blocks will have, so it lines up with the
    /// real forest at the edge of the block world instead of being a carpet of a typical height. A cell looks at
    /// 4 x 4 of the tree cells (4 blocks wide) it covers at most. `ground_top` is the height of the column without
    /// trees. Returns `None` where no tree stands.
    fn canopy_of(&self, level: usize, ix: i64, iz: i64, ground_top: f32) -> Option<Canopy> {
        let cell = (BASE_CELL as i64) << level;
        let count = (cell / 4) as i32;
        let stride = std::cmp::max(count / 4, 1);
        let per_axis = count / stride;
        let jx0 = (ix * cell).div_euclid(4);
        let jz0 = (iz * cell).div_euclid(4);
        let mut found = 0i32;
        let mut sum = 0.0f32;
        let mut tallest = 0.0f32;
        let mut tone = 1.0f32;
        for sz in 0..per_axis {
            for sx in 0..per_axis {
                let jx = (jx0 + (sx * stride) as i64) as i32;
                let jz = (jz0 + (sz * stride) as i64) as i32;
                if let Some(spot) = self.gen.tree_spot(jx, jz) {
                    let t = (spot.ground + tree_height(spot.species, spot.th)) as f32;
                    found += 1;
                    sum += t;
                    if t > tallest {
                        tallest = t;
                        tone = crown_tone(spot.species);
                    }
                }
            }
        }
        if found == 0 {
            return None;
        }
        let samples = (per_axis * per_axis) as f32;
        let mean = sum / found as f32;
        // a small cell is as high as its tallest tree; a big one is more like the canopy than like its tallest tree
        let tallest_share = match level {
            0 | 1 => 1.0f32,
            2 => 0.6,
            3 => 0.4,
            _ => 0.35,
        };
        let crowns = mean + (tallest - mean) * tallest_share;
        // a lone tree stands out of a small cell, but a big cell needs a stand of trees to look like forest
        let weight = match level {
            0 => 1.0,
            1 => (found as f32 / 3.0).min(1.0),
            _ => crown_ramp(found as f32 / samples),
        };
        let top = ground_top + (crowns - ground_top).max(0.0) * weight;
        Some(Canopy { top, tone: 1.0 + (tone - 1.0) * weight })
    }

    /// Height of a land column once its trees are counted, and the brightness factor for the leaves on top (1.0 without
    /// trees). It gives the same answer for a cell wherever it is asked, inside a tile or as the ring around the
    /// neighbouring one (which the walls along the shared edge rely on), so it never looks at the slope.
    #[allow(clippy::too_many_arguments)]
    fn raised_top(&self, level: usize, ix: i64, iz: i64, wx: f64, wz: f64, h: f64, coast: f64, top: f32) -> (f32, f32) {
        if level <= CROWN_LEVELS + 2 {
            return match self.canopy_of(level, ix, iz, top) {
                Some(c) => (top.max(c.top), c.tone),
                None => (top, 1.0),
            };
        }
        // the coarse levels cannot tell trees apart: a forest is a carpet of a typical height there
        let noise = cell_noise(level, ix, iz);
        let rise = self.ground(wx, wz, h, coast, 0.5, None).canopy * (0.7 + 0.6 * noise);
        (top + rise, 1.0)
    }

    /// The columns of a tile and the ring of columns around it.
    pub fn sample_grid(&self, key: TileKey) -> CellGrid {
        let level = key.level();
        // The land-form function drops its finest features for coarse cells. It was written when the finest cells were 8
        // blocks wide, so a cell of that size (level 1 now) gets what level 0 used to get.
        let lod = level.saturating_sub(1) as i32;
        let cell = key.cell() as f64;
        let first_x = key.tx as i64 * CELLS as i64;
        let first_z = key.tz as i64 * CELLS as i64;
        let shape = &self.gen.shape;
        // The trees around the tile (and around the ring of cells beside it), for the levels that draw single crowns.
        let trees = if level <= CROWN_LEVELS {
            let x0 = (first_x - 1) as f64 * cell;
            let z0 = (first_z - 1) as f64 * cell;
            let x1 = (first_x + CELLS as i64 + 1) as f64 * cell;
            let z1 = (first_z + CELLS as i64 + 1) as f64 * cell;
            Some(TreeGrid::build(&self.gen, x0, z0, x1, z1))
        } else {
            None
        };
        // Heights at the middle of every cell (smooth, for colours and slopes) and the lowest height the column
        // should stand on.
        let mut middle = vec![0.0f32; GRID * GRID];
        let mut lowest = vec![0.0f32; GRID * GRID];
        let mut coast = vec![0.0f32; GRID * GRID];
        for gz in 0..GRID {
            for gx in 0..GRID {
                let wx = cell_middle(first_x + gx as i64 - 1, cell);
                let wz = cell_middle(first_z + gz as i64 - 1, cell);
                let (h, c) = shape.height_and_coast(wx, wz, lod);
                let mut low = h;
                if level <= CROWN_LEVELS {
                    // The real blocks are drawn over these columns, and the strip of far terrain right beyond them
                    // is made of such cells: a column must not stand higher than the blocks it stands for, so use the
                    // lowest of a few spots.
                    for (dx, dz) in PROBES.iter() {
                        low = low.min(shape.height(wx + dx * cell, wz + dz * cell, 0));
                    }
                }
                let i = gz * GRID + gx;
                middle[i] = h as f32;
                lowest[i] = low as f32;
                coast[i] = c as f32;
            }
        }
        let mut grid = CellGrid::filled(Cell::land(0.0, [0; 3], [0; 3]));
        for gz in 0..GRID {
            for gx in 0..GRID {
                let i = gz * GRID + gx;
                let (cx, cz) = (gx as i32 - 1, gz as i32 - 1);
                let inside = gx >= 1 && gx <= CELLS && gz >= 1 && gz <= CELLS;
                let h = middle[i] as f64;
                if h < SEA {
                    let color = if inside { self.sea_color(h) } else { [0; 3] };
                    grid.set(cx, cz, Cell::sea(WATER_TOP, color));
                    continue;
                }
                // A block's top face is at floor(height) + 1; the column is one block lower, and never lower than
                // the shore, so that the sea is always the lower of the two.
                let top = lowest[i].floor().max(SEA_LEVEL as f32 + 1.0);
                let ix = first_x + cx as i64;
                let iz = first_z + cz as i64;
                let wx = cell_middle(ix, cell);
                let wz = cell_middle(iz, cell);
                let noise = cell_noise(level, ix, iz);
                // the finest levels know the crown of every single tree, the coarser ones can only guess at the forest
                let crowned = match &trees {
                    Some(t) => cell_crowns(t, level, ix, iz, top),
                    None => None,
                };
                let (column_top, tone) = if level <= CROWN_LEVELS {
                    match &crowned {
                        Some(c) => (c.top, c.tone),
                        None => (top, 1.0),
                    }
                } else {
                    self.raised_top(level, ix, iz, wx, wz, h, coast[i] as f64, top)
                };
                if !inside {
                    // the ring only needs the height, crowns of a forest included, for the walls along the tile's edge
                    grid.set(cx, cz, Cell::land(column_top, [0; 3], [0; 3]));
                    continue;
                }
                let dx = (middle[i + 1] - middle[i - 1]) as f64 / (2.0 * cell);
                let dz = (middle[i + GRID] - middle[i - GRID]) as f64 / (2.0 * cell);
                // heights taken over a whole cell look flatter than the real ground, which has block-sized detail
                let slope_gain = if level >= 3 { 1.4 } else { 1.0 };
                let slope = (dx * dx + dz * dz).sqrt() * slope_gain;
                let cover = if level <= CROWN_LEVELS { Some(crowned.as_ref().map_or(0.0, |c| c.cover)) } else { None };
                let ground = self.ground(wx, wz, h, coast[i] as f64, slope, cover);
                // the sun lights the slopes that face it, so that a hill reads as a hill from far away
                let facing = ((-dx * SUN[0] + SUN[1] - dz * SUN[2]) / (dx * dx + 1.0 + dz * dz).sqrt()) as f32;
                let light = (SHADE_BASE + SHADE_GAIN * facing).max(SHADE_MIN).min(SHADE_MAX);
                // under trees the brightness of a column varies more (see `CROWN_VARIATION`)
                let leafy = if column_top - top > 1.0 { 1.0 } else { 0.0 };
                let variation = LAND_VARIATION + (CROWN_VARIATION - LAND_VARIATION) * leafy;
                let k = light * (1.0 - variation * noise) * tone;
                // forests stand on the ground at the height of their crowns (the real blocks are drawn over them
                // wherever the block world reaches, so the finest level can show its trees too)
                grid.set(cx, cz, Cell::land(column_top, to_bytes(scale(ground.top, k)), to_bytes(scale(ground.wall, k))));
            }
        }
        grid
    }

    /// The finished tile.
    pub fn build_tile(&self, key: TileKey) -> FarTileData {
        build_tile_mesh(key, &self.sample_grid(key))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Instant;

    fn sampler(seed: i64) -> FarSampler {
        FarSampler::new(Arc::new(TerrainGenerator::new(seed)))
    }

    #[test]
    fn neighbouring_tiles_agree_exactly_about_the_cells_along_their_shared_edge() {
        let s = sampler(3);
        for level in [0usize, 1, 2, 4] {
            let a = s.sample_grid(TileKey::new(level, 4, -2));
            let b = s.sample_grid(TileKey::new(level, 5, -2));
            let n = CELLS as i32;
            for cz in 0..n {
                // the ring of one tile is the edge row of the other
                assert_eq!(a.get(n, cz).top, b.get(0, cz).top, "east seam, level {} row {}", level, cz);
                assert_eq!(a.get(n, cz).water, b.get(0, cz).water);
                assert_eq!(b.get(-1, cz).top, a.get(n - 1, cz).top, "west seam, level {} row {}", level, cz);
                assert_eq!(b.get(-1, cz).water, a.get(n - 1, cz).water);
            }
            let c = s.sample_grid(TileKey::new(level, 4, -1));
            for cx in 0..n {
                assert_eq!(a.get(cx, n).top, c.get(cx, 0).top, "south seam, level {} column {}", level, cx);
                assert_eq!(c.get(cx, -1).top, a.get(cx, n - 1).top, "north seam, level {} column {}", level, cx);
            }
        }
    }

    #[test]
    fn building_a_tile_twice_gives_the_same_triangles() {
        let s = sampler(4);
        let k = TileKey::new(1, 3, 3);
        let (a, b) = (s.build_tile(k), s.build_tile(k));
        assert_eq!(a.vertices, b.vertices);
        assert_eq!(a.indices, b.indices);
        assert_eq!(a.quarter_starts, b.quarter_starts);
    }

    #[test]
    fn a_tile_has_triangles_in_every_quarter_and_a_sensible_height_range() {
        let s = sampler(1);
        let t = s.build_tile(TileKey::new(0, 0, 0));
        for q in 0..4 {
            assert!(t.quarter_starts[q + 1] > t.quarter_starts[q], "quarter {} is empty", q);
        }
        assert!(t.min_y < t.max_y);
        assert!(t.vertices.iter().all(|v| v.pos[1] >= t.min_y && v.pos[1] <= t.max_y));
        assert!(t.vertices.iter().all(|v| v.color[3] == 255));
        assert!(t.indices.iter().all(|&i| (i as usize) < t.vertices.len()));
    }

    #[test]
    fn vertex_positions_are_blocks_from_the_tiles_corner() {
        let s = sampler(2);
        let t = s.build_tile(TileKey::new(3, -1, 3)); // cell 32, tile 1024 wide
        // sea quads are grown a little past their cells (see `mesh::sea_grow`), everything else is on the grid
        let slack = 0.2;
        for v in t.vertices.iter() {
            assert!(v.pos[0] >= -slack && v.pos[0] <= 1024.0 + slack && v.pos[2] >= -slack && v.pos[2] <= 1024.0 + slack, "{:?}", v.pos);
            for axis in [0usize, 2] {
                let m = v.pos[axis] % 32.0;
                assert!(m.min(32.0 - m) <= slack, "{:?} is off the 32-block grid", v.pos);
            }
        }
    }

    #[test]
    fn the_far_columns_of_level_zero_follow_the_real_ground_and_its_trees() {
        let gen = Arc::new(TerrainGenerator::new(5));
        let s = FarSampler::new(gen.clone());
        let key = TileKey::new(0, 1, 1); // cells of 4 blocks, the tile starts at block (128, 128)
        let g = s.sample_grid(key);
        let mut checked = 0;
        for cz in (0..CELLS as i32).step_by(3) {
            for cx in (0..CELLS as i32).step_by(3) {
                let c = g.get(cx, cz);
                // the middle of the cell, as a block column
                let wx = 128 + cx * 4 + 2;
                let wz = 128 + cz * 4 + 2;
                let real = gen.surface_height(wx, wz);
                // (the shore itself is a matter of a block here or there, so it is not looked at)
                if real < SEA_LEVEL - 2 {
                    assert!(c.water, "({}, {}) is sea in the real world", wx, wz);
                    assert_eq!(c.top, WATER_TOP);
                    checked += 1;
                } else if real > SEA_LEVEL + 2 {
                    assert!(!c.water, "({}, {}) is land in the real world", wx, wz);
                    // the real top face is at real + 1; despiking can move a column by a block or two, and a column
                    // in a forest stands as high as the tallest tree in it (a giant is 42 blocks high at most)
                    assert!(c.top <= real as f32 + 50.0, "column at ({}, {}) is {} but the real top face is {}", wx, wz, c.top, real + 1);
                    assert!(c.top >= real as f32 - 14.0, "column at ({}, {}) is {} but the real top face is {}", wx, wz, c.top, real + 1);
                    checked += 1;
                }
            }
        }
        assert!(checked > 60, "only {} columns were compared", checked);
    }

    #[test]
    fn a_far_forest_has_the_trees_the_chunks_will_have() {
        let gen = Arc::new(TerrainGenerator::new(11));
        let mut checked = 0;
        'search: for jz in -300..300 {
            for jx in -300..300 {
                if let Some(spot) = gen.tree_spot(jx, jz) {
                    let top = (spot.ground + tree_height(spot.species, spot.th)) as f32;
                    let (x, z) = (spot.x as f64 + 0.5, spot.z as f64 + 0.5);
                    let trees = TreeGrid::build(&gen, x, z, x, z);
                    let (crown, _) = crown_at(&trees, x, z).expect("the crown of a tree covers its own trunk");
                    assert!(crown >= top, "the leaves over the trunk are at {}, the top of its tree is at {}", crown, top);
                    checked += 1;
                    if checked >= 20 {
                        break 'search;
                    }
                }
            }
        }
        assert!(checked >= 5, "found only {} trees", checked);
    }

    #[test]
    fn the_crowns_over_a_point_do_not_depend_on_how_big_a_grid_was_looked_up() {
        let gen = Arc::new(TerrainGenerator::new(11));
        let mut checked = 0;
        'search: for jz in -300..300 {
            for jx in -300..300 {
                if let Some(spot) = gen.tree_spot(jx, jz) {
                    for (dx, dz) in [(0.0f64, 0.0f64), (3.5, -2.0), (-6.0, 5.5), (8.5, 8.5)].iter() {
                        let (x, z) = (spot.x as f64 + dx, spot.z as f64 + dz);
                        let small = TreeGrid::build(&gen, x, z, x, z);
                        let big = TreeGrid::build(&gen, x - 90.0, z - 90.0, x + 90.0, z + 90.0);
                        assert_eq!(crown_at(&small, x, z), crown_at(&big, x, z), "at ({}, {})", x, z);
                    }
                    checked += 1;
                    if checked >= 12 {
                        break 'search;
                    }
                }
            }
        }
        assert!(checked >= 5, "found only {} trees", checked);
    }

    #[test]
    fn a_crown_is_a_dome_high_in_the_middle_and_gone_past_its_reach() {
        // species by species, on a grid that holds the one tree only
        for &species in [TreeSpecies::Oak, TreeSpecies::Spruce, TreeSpecies::Giant, TreeSpecies::Fig, TreeSpecies::Palm].iter() {
            let (reach, thick, _) = crown_shape(species);
            assert!(reach > 1.0 && thick > 0.5 && reach as f64 <= CROWN_REACH, "{:?}", species);
        }
        // the widest crown of all is within what the grid and the generator allow for
        let widest = [
            TreeSpecies::Oak,
            TreeSpecies::Birch,
            TreeSpecies::Spruce,
            TreeSpecies::Jungle,
            TreeSpecies::RainTree,
            TreeSpecies::Giant,
            TreeSpecies::Palm,
            TreeSpecies::Cecropia,
            TreeSpecies::BrazilNut,
            TreeSpecies::Fig,
            TreeSpecies::Shrub,
        ]
        .iter()
        .map(|&s| crown_shape(s).0)
        .fold(0.0f32, |a, b| a.max(b));
        assert!(widest as f64 <= CROWN_REACH);
    }

    #[test]
    fn land_is_always_above_the_sea_plane_and_sea_is_a_flat_blue_sheet() {
        let gen = Arc::new(TerrainGenerator::new(6));
        let s = FarSampler::new(gen);
        let mut water = 0;
        let mut land = 0;
        for tx in -6..6 {
            for tz in -6..6 {
                let g = s.sample_grid(TileKey::new(5, tx, tz));
                for cz in 0..CELLS as i32 {
                    for cx in 0..CELLS as i32 {
                        let c = g.get(cx, cz);
                        if c.water {
                            assert_eq!(c.top, WATER_TOP);
                            if c.color[2] > c.color[0] + 20 {
                                water += 1;
                            }
                        } else {
                            assert!(c.top >= SEA_LEVEL as f32 + 1.0, "land at {}", c.top);
                            land += 1;
                        }
                    }
                }
            }
        }
        assert!(water > 100, "no sea found ({})", water);
        assert!(land > 100, "no land found ({})", land);
    }

    #[test]
    fn colours_are_plausible_ground_colours_and_columns_differ_a_little() {
        let s = sampler(7);
        let g = s.sample_grid(TileKey::new(3, 0, 0));
        let mut sum = [0u64; 3];
        let mut n = 0u64;
        let mut distinct = std::collections::HashSet::new();
        for cz in 0..CELLS as i32 {
            for cx in 0..CELLS as i32 {
                let c = g.get(cx, cz);
                for k in 0..3 {
                    sum[k] += c.color[k] as u64;
                }
                distinct.insert(c.color);
                n += 1;
            }
        }
        for k in 0..3 {
            let avg = sum[k] / n;
            assert!(avg > 20 && avg < 250, "channel {} averages {}", k, avg);
        }
        assert!(distinct.len() > 20, "only {} different colours", distinct.len());
    }

    #[test]
    fn sea_comes_in_few_colours_so_that_it_can_be_merged() {
        let gen = Arc::new(TerrainGenerator::new(6));
        let s = FarSampler::new(gen);
        let mut colours = std::collections::HashSet::new();
        for tx in -4..4 {
            for tz in -4..4 {
                let g = s.sample_grid(TileKey::new(4, tx, tz));
                for cz in 0..CELLS as i32 {
                    for cx in 0..CELLS as i32 {
                        let c = g.get(cx, cz);
                        if c.water {
                            colours.insert(c.color);
                        }
                    }
                }
            }
        }
        assert!(!colours.is_empty());
        assert!(colours.len() <= DEPTH_STEPS as usize + 2, "{} sea colours", colours.len());
    }

    #[test]
    fn a_tile_is_cheap_enough_to_build_in_the_background() {
        let s = sampler(8);
        let start = Instant::now();
        for i in 0..6 {
            s.build_tile(TileKey::new(i, 7, -3));
        }
        let per_tile = start.elapsed().as_secs_f64() / 6.0;
        eprintln!("far tile build: {:.1} ms each", per_tile * 1000.0);
        // (the finest levels look at the real tree positions now, which costs more in forests)
        assert!(per_tile < 2.5, "a tile took {:.2} s", per_tile);
    }
}
