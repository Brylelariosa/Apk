//! Walking physics: gravity, jumping, auto-jump and axis-by-axis collision against solid blocks.

use super::player::{Player, HEIGHT, WIDTH};
use crate::core::math::{Aabb, Vec3};
use crate::world::config::{VOID_Y, WORLD_HEIGHT};
use crate::world::pos::ChunkPos;
use crate::world::world::World;

pub const GRAVITY: f32 = 32.0;
pub const TERMINAL_VELOCITY: f32 = -55.0;
pub const JUMP_SPEED: f32 = 8.9;
pub const MOVE_SPEED: f32 = 4.3;

pub const BLOCKED_X: i32 = 1;
pub const BLOCKED_Z: i32 = 2;
pub const BLOCKED_UP: i32 = 4;
pub const BLOCKED_DOWN: i32 = 8;

/// A box that is this much (or less) inside a block is only touching it: positions are `f32`, so a box that rests
/// against a block can come out a hair inside it.
const MIN_SLACK: f32 = 0.001;
/// How far inside a block a box has to be before the player is lifted out of it.
const EMBED_SLACK: f32 = 0.05;
/// The most the player is lifted per step while climbing out of blocks.
const MAX_LIFT_PER_STEP: f32 = 0.5;

fn box_at(pos: Vec3) -> Aabb {
    let hw = WIDTH / 2.0;
    Aabb::new(pos.x - hw, pos.y, pos.z - hw, pos.x + hw, pos.y + HEIGHT, pos.z + hw)
}

/// Advances a walking player by `dt` seconds. `world_move_*` is the desired horizontal direction in world
/// space (length 0..~1.4).
pub fn step(
    world: &World,
    player: &mut Player,
    world_move_x: f32,
    world_move_z: f32,
    wants_jump: bool,
    auto_jump: bool,
    dt: f32,
) {
    let mut b = box_at(player.position);
    // A player who is really inside blocks (a world loaded from an old save, a tree that grew around them) climbs out of
    // them instead of being stuck.
    let lift = lift_out_of_blocks(world, &b);
    if lift > 0.0 {
        player.position.add(0.0, lift.min(MAX_LIFT_PER_STEP), 0.0);
        player.velocity.y = 0.0;
        player.on_ground = false;
        b = box_at(player.position);
    }
    let effective_jump = wants_jump || (auto_jump && player.on_ground && should_auto_jump(world, &b, world_move_x, world_move_z));

    player.velocity.y = (player.velocity.y - GRAVITY * dt).max(TERMINAL_VELOCITY);
    if effective_jump && player.on_ground {
        player.velocity.y = JUMP_SPEED;
    }

    let dx = resolve_horizontal(world, &b, world_move_x * MOVE_SPEED * dt, true);
    b = b.offset(dx, 0.0, 0.0);
    let dz = resolve_horizontal(world, &b, world_move_z * MOVE_SPEED * dt, false);
    b = b.offset(0.0, 0.0, dz);

    let desired_dy = player.velocity.y * dt;
    let dy = resolve_vertical(world, &b, desired_dy);
    if desired_dy < 0.0 && dy > desired_dy {
        player.on_ground = true;
        player.velocity.y = 0.0;
    } else if desired_dy > 0.0 && dy < desired_dy {
        player.velocity.y = 0.0;
        player.on_ground = false;
    } else {
        player.on_ground = false;
    }
    player.position.add(dx, dy, dz);

    if player.position.y < VOID_Y {
        player.position.set(player.position.x, WORLD_HEIGHT as f32 + 8.0, player.position.z);
        player.velocity.set(0.0, 0.0, 0.0);
    }
}

/// Moves a flying player by (dx, dy, dz), colliding with solid blocks (unless already inside one).
/// Returns `BLOCKED_*` bits describing what stopped the move.
pub fn fly_move(world: &World, player: &mut Player, dx: f32, dy: f32, dz: f32) -> i32 {
    player.on_ground = false;
    let inside = world.is_solid(
        player.position.x.floor() as i32,
        (player.position.y + 0.9).floor() as i32,
        player.position.z.floor() as i32,
    );
    if inside {
        player.position.add(dx, dy, dz);
        return 0;
    }
    let mut b = box_at(player.position);
    let mx = resolve_horizontal(world, &b, dx, true);
    b = b.offset(mx, 0.0, 0.0);
    let mz = resolve_horizontal(world, &b, dz, false);
    b = b.offset(0.0, 0.0, mz);
    let my = resolve_vertical(world, &b, dy);
    player.position.add(mx, my, mz);
    if player.position.y < VOID_Y {
        player.position.set(player.position.x, WORLD_HEIGHT as f32 + 8.0, player.position.z);
    }
    let mut blocked = 0;
    if mx != dx {
        blocked |= BLOCKED_X;
    }
    if mz != dz {
        blocked |= BLOCKED_Z;
    }
    if dy > 0.0 && my < dy {
        blocked |= BLOCKED_UP;
    }
    if dy < 0.0 && my > dy {
        blocked |= BLOCKED_DOWN;
        player.on_ground = true;
    }
    blocked
}

/// True when walking into a one-block step: solid at foot level just ahead, free above it.
fn should_auto_jump(world: &World, b: &Aabb, world_move_x: f32, world_move_z: f32) -> bool {
    let len = (world_move_x * world_move_x + world_move_z * world_move_z).sqrt();
    if len < 0.001 {
        return false;
    }
    let dir_x = world_move_x / len;
    let dir_z = world_move_z / len;
    let hw = WIDTH / 2.0;
    let probe_x = (b.min_x + b.max_x) / 2.0 + dir_x * (hw + 0.15);
    let probe_z = (b.min_z + b.max_z) / 2.0 + dir_z * (hw + 0.15);
    let foot_block_y = (b.min_y + 0.05).floor() as i32;
    let block_x = probe_x.floor() as i32;
    let block_z = probe_z.floor() as i32;
    if !world.is_solid(block_x, foot_block_y, block_z) {
        return false;
    }
    !world.is_solid(block_x, foot_block_y + 1, block_z)
}

/// How much a box edge may be inside a block it only touches. The edges are worked out in `f32`, which is only accurate to
/// about a thousandth of a block ten thousand blocks from the origin, so the slack grows a little with the distance.
fn contact_slack(b: &Aabb) -> f32 {
    let far = b.min_x.abs().max(b.max_x.abs()).max(b.min_z.abs()).max(b.max_z.abs());
    (far * 1.5e-7).max(MIN_SLACK)
}

/// True if any block of the horizontal layer `by`, under the footprint `min_x..=max_x` by `min_z..=max_z`, is solid.
fn layer_blocked(world: &World, by: i32, min_x: i32, max_x: i32, min_z: i32, max_z: i32) -> bool {
    for bx in min_x..=max_x {
        for bz in min_z..=max_z {
            if world.is_solid(bx, by, bz) {
                return true;
            }
        }
    }
    false
}

/// True if any block of the vertical slab at `a` (an x when `is_x`, else a z), over the heights `min_y..=max_y` and the
/// other horizontal axis `min_c..=max_c`, is solid.
fn slab_blocked(world: &World, is_x: bool, a: i32, min_y: i32, max_y: i32, min_c: i32, max_c: i32) -> bool {
    for by in min_y..=max_y {
        for c in min_c..=max_c {
            let solid = if is_x { world.is_solid(a, by, c) } else { world.is_solid(c, by, a) };
            if solid {
                return true;
            }
        }
    }
    false
}

/// How far the box can move along x (`is_x`) or z by `delta` before its leading face meets a solid block. Only blocks
/// that lie ahead of that face count: a block the box is merely touching (or sits a hair inside of) never pushes it back.
fn resolve_horizontal(world: &World, b: &Aabb, delta: f32, is_x: bool) -> f32 {
    // (a move of thousands of blocks in one step can only come from corrupt numbers; do not loop over all of it)
    if delta == 0.0 || delta.is_nan() || delta.abs() >= 4096.0 {
        return 0.0;
    }
    let e = contact_slack(b);
    let min_y = (b.min_y + e).floor() as i32;
    let max_y = (b.max_y - e).floor() as i32;
    let (front_lo, front_hi, side_lo, side_hi) = if is_x {
        (b.min_x, b.max_x, b.min_z, b.max_z)
    } else {
        (b.min_z, b.max_z, b.min_x, b.max_x)
    };
    let min_c = (side_lo + e).floor() as i32;
    let max_c = (side_hi - e).floor() as i32;
    if delta > 0.0 {
        // the slabs the leading face runs into, nearest first
        let first = (front_hi - e).floor() as i32 + 1;
        let last = (front_hi + delta).floor() as i32;
        for a in first..=last {
            if slab_blocked(world, is_x, a, min_y, max_y, min_c, max_c) {
                return delta.min((a as f32 - front_hi).max(0.0));
            }
        }
    } else {
        let first = (front_lo + e).floor() as i32 - 1;
        let last = (front_lo + delta).floor() as i32;
        let mut a = first;
        while a >= last {
            if slab_blocked(world, is_x, a, min_y, max_y, min_c, max_c) {
                return delta.max(((a + 1) as f32 - front_lo).min(0.0));
            }
            a -= 1;
        }
    }
    delta
}

/// How far the box can move up or down by `delta` before its head or its feet meet a solid block. Only the layers
/// ahead of the head (going up) or the feet (going down) count. (Counting the layer a box merely touches was what let a
/// player who bumped their head on a block above them be thrown up on top of it.)
fn resolve_vertical(world: &World, b: &Aabb, delta: f32) -> f32 {
    // (a move of thousands of blocks in one step can only come from corrupt numbers; do not loop over all of it)
    if delta == 0.0 || delta.is_nan() || delta.abs() >= 4096.0 {
        return 0.0;
    }
    let e = contact_slack(b);
    let min_x = (b.min_x + e).floor() as i32;
    let max_x = (b.max_x - e).floor() as i32;
    let min_z = (b.min_z + e).floor() as i32;
    let max_z = (b.max_z - e).floor() as i32;
    if delta > 0.0 {
        // the layers the head runs into, lowest first
        let first = (b.max_y - e).floor() as i32 + 1;
        let last = (b.max_y + delta).floor() as i32;
        for by in first..=last {
            if layer_blocked(world, by, min_x, max_x, min_z, max_z) {
                return delta.min((by as f32 - b.max_y).max(0.0));
            }
        }
    } else {
        // the layers the feet run into, highest first
        let first = (b.min_y + e).floor() as i32 - 1;
        let last = (b.min_y + delta).floor() as i32;
        let mut by = first;
        while by >= last {
            if layer_blocked(world, by, min_x, max_x, min_z, max_z) {
                return delta.max(((by + 1) as f32 - b.min_y).min(0.0));
            }
            by -= 1;
        }
    }
    delta
}

/// If the box is well inside solid blocks, how far up it has to go to stand on the highest of them (0 when it is free).
/// Chunks that are not loaded are not looked at: the world counts their cells as solid, so that nobody walks into the
/// unknown, but a player at the edge of a chunk must not be lifted out of a neighbour that has not arrived yet.
fn lift_out_of_blocks(world: &World, b: &Aabb) -> f32 {
    let e = contact_slack(b).max(EMBED_SLACK);
    let min_x = (b.min_x + e).floor() as i32;
    let max_x = (b.max_x - e).floor() as i32;
    let min_z = (b.min_z + e).floor() as i32;
    let max_z = (b.max_z - e).floor() as i32;
    let min_y = (b.min_y + e).floor() as i32;
    let max_y = (b.max_y - e).floor() as i32;
    let mut highest: Option<i32> = None;
    for by in min_y..=max_y {
        for bx in min_x..=max_x {
            for bz in min_z..=max_z {
                if world.contains(ChunkPos::of_block(bx, bz)) && world.is_solid(bx, by, bz) {
                    highest = Some(by);
                }
            }
        }
    }
    match highest {
        Some(by) => ((by + 1) as f32 - b.min_y).max(0.0),
        None => 0.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::world::block::Block;
    use crate::world::chunk::ChunkData;
    use crate::world::pos::ChunkPos;

    fn flat_world() -> World {
        let mut w = World::new();
        for cz in -1..=1 {
            for cx in -1..=1 {
                let mut c = ChunkData::new();
                for x in 0..16 {
                    for z in 0..16 {
                        c.set(x, 59, z, Block::Stone);
                    }
                }
                w.insert(ChunkPos::new(cx, cz), c, false);
            }
        }
        w
    }

    #[test]
    fn player_falls_and_lands_on_the_floor() {
        let world = flat_world();
        let mut p = Player::new();
        p.position.set(8.0, 70.0, 8.0);
        for _ in 0..400 {
            step(&world, &mut p, 0.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!(p.on_ground);
        assert!((p.position.y - 60.0).abs() < 0.01, "y = {}", p.position.y);
    }

    #[test]
    fn walls_stop_horizontal_movement() {
        let mut world = flat_world();
        for y in 60..64 {
            world.set_block(10, y, 8, Block::Stone, false);
        }
        let mut p = Player::new();
        p.position.set(8.0, 60.0, 8.5);
        p.on_ground = true;
        for _ in 0..240 {
            step(&world, &mut p, 1.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!(p.position.x < 10.0, "x = {}", p.position.x);
    }

    /// A flat stone floor (y = 59) of three by three chunks around the block (`cx`, `cz`).
    fn floor_around(cx: i32, cz: i32) -> World {
        let mut w = World::new();
        let base = ChunkPos::of_block(cx, cz);
        for dz in -1..=1 {
            for dx in -1..=1 {
                let mut c = ChunkData::new();
                for x in 0..16 {
                    for z in 0..16 {
                        c.set(x, 59, z, Block::Stone);
                    }
                }
                w.insert(ChunkPos::new(base.x + dx, base.z + dz), c, false);
            }
        }
        w
    }

    #[test]
    fn a_player_who_bumps_their_head_is_not_thrown_up_through_the_block() {
        // near the origin and far from it, where f32 positions are coarse
        for &(cx, cz) in [(8, 8), (-1608, 3000), (10008, -9000)].iter() {
            for &ceiling in [62, 63].iter() {
                let mut world = floor_around(cx, cz);
                for x in (cx - 6)..=(cx + 6) {
                    for z in (cz - 6)..=(cz + 6) {
                        world.set_block(x, ceiling, z, Block::Stone, false);
                    }
                }
                let mut p = Player::new();
                p.position.set(cx as f32 + 0.5, 60.0, cz as f32 + 0.5);
                p.on_ground = true;
                let mut highest = 0.0f32;
                for i in 0..240 {
                    step(&world, &mut p, 0.0, 0.0, i % 30 < 10, false, 1.0 / 60.0);
                    highest = highest.max(p.position.y);
                }
                assert!(highest < ceiling as f32 - 1.7, "ceiling at {} over ({}, {}): the player got up to y = {}", ceiling, cx, cz, highest);
            }
        }
    }

    #[test]
    fn walls_never_pull_the_player_up_or_through_from_any_side() {
        let pushes = [(1.0f32, 0.0f32), (-1.0, 0.0), (0.0, 1.0), (0.0, -1.0), (1.0, 1.0), (-1.0, -1.0), (1.0, -1.0), (-1.0, 1.0)];
        for &(cx, cz) in [(8, 8), (-1608, 3000), (10008, -9000)].iter() {
            for &(mx, mz) in pushes.iter() {
                let mut world = floor_around(cx, cz);
                // a ring of walls three blocks from the player, three blocks high
                for k in -6..=6 {
                    for y in 60..63 {
                        world.set_block(cx + 3, y, cz + k, Block::Stone, false);
                        world.set_block(cx - 3, y, cz + k, Block::Stone, false);
                        world.set_block(cx + k, y, cz + 3, Block::Stone, false);
                        world.set_block(cx + k, y, cz - 3, Block::Stone, false);
                    }
                }
                let mut p = Player::new();
                p.position.set(cx as f32 + 0.5, 60.0, cz as f32 + 0.5);
                p.on_ground = true;
                for _ in 0..300 {
                    step(&world, &mut p, mx, mz, false, false, 1.0 / 60.0);
                }
                assert!(p.position.y < 60.01, "pushing ({}, {}) at ({}, {}) lifted the player to y = {}", mx, mz, cx, cz, p.position.y);
                let inside = (p.position.x - cx as f32).abs() < 3.5 && (p.position.z - cz as f32).abs() < 3.5;
                assert!(inside, "pushing ({}, {}) at ({}, {}) took the player to ({}, {})", mx, mz, cx, cz, p.position.x, p.position.z);
            }
        }
    }

    #[test]
    fn a_player_inside_a_block_climbs_out_of_it() {
        let mut world = flat_world();
        for y in 60..64 {
            world.set_block(8, y, 8, Block::Stone, false);
        }
        let mut p = Player::new();
        p.position.set(8.5, 60.0, 8.5);
        for _ in 0..120 {
            step(&world, &mut p, 0.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!(p.position.y >= 63.99, "y = {}", p.position.y);
        assert!(p.on_ground);
    }

    #[test]
    fn a_player_at_the_edge_of_the_loaded_world_is_not_lifted_out_of_the_chunk_that_is_missing() {
        let mut world = World::new();
        let mut c = ChunkData::new();
        for x in 0..16 {
            for z in 0..16 {
                c.set(x, 59, z, Block::Stone);
            }
        }
        world.insert(ChunkPos::new(0, 0), c, false);
        let mut p = Player::new();
        p.position.set(0.1, 60.0, 8.5); // half of the box is over the chunk to the west, which is not loaded
        p.on_ground = true;
        for _ in 0..60 {
            step(&world, &mut p, 0.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!((p.position.y - 60.0).abs() < 1e-4, "y = {}", p.position.y);
    }

    #[test]
    fn touching_a_block_is_not_being_inside_it() {
        let mut world = flat_world();
        for y in 60..64 {
            world.set_block(8, y, 8, Block::Stone, false);
        }
        let mut p = Player::new();
        p.position.set(9.3, 60.0, 8.5); // the box starts at the east face of the column
        p.on_ground = true;
        for _ in 0..60 {
            step(&world, &mut p, 0.0, 0.0, false, false, 1.0 / 60.0);
        }
        assert!((p.position.y - 60.0).abs() < 1e-4, "y = {}", p.position.y);
    }
}
