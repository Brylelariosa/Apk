//! The colours of the map. Land is coloured by biome and lit from the north-west so hills and mountain ranges
//! stand out; water gets darker with depth, so shelves and trenches show; high bare mountains turn to snow.

use crate::gen::climate::Biome;
use crate::world::config::SEA_LEVEL;

pub type Rgb = [f32; 3];

/// The colour of a biome seen from above.
pub fn land_color(biome: Biome) -> Rgb {
    match biome {
        Biome::Plains => [138.0, 196.0, 84.0],
        Biome::Forest => [46.0, 120.0, 40.0],
        Biome::BirchForest => [112.0, 170.0, 66.0],
        Biome::Taiga => [48.0, 104.0, 92.0],
        Biome::SnowyPlains => [238.0, 243.0, 250.0],
        Biome::SnowyTaiga => [176.0, 204.0, 204.0],
        Biome::Savanna => [188.0, 172.0, 84.0],
        Biome::Desert => [232.0, 200.0, 120.0],
        Biome::Swamp => [78.0, 104.0, 70.0],
        Biome::Mountains => [128.0, 128.0, 128.0],
        Biome::SnowyPeaks => [250.0, 250.0, 255.0],
        Biome::Jungle => [20.0, 140.0, 40.0],
        Biome::Rainforest => [4.0, 88.0, 28.0],
        Biome::Beach => [226.0, 212.0, 152.0],
        Biome::SnowyShore => [172.0, 176.0, 168.0],
        // water biomes are drawn by `water_color`; these only matter for a column the generator calls water but whose
        // height is above the sea (never on the map)
        Biome::Lake => [60.0, 135.0, 215.0],
        Biome::Ocean => [36.0, 78.0, 160.0],
        Biome::DeepOcean => [14.0, 26.0, 96.0],
    }
}

fn mix(a: Rgb, b: Rgb, t: f32) -> Rgb {
    let t = t.max(0.0).min(1.0);
    [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
}

fn smooth(lo: f32, hi: f32, v: f32) -> f32 {
    let t = ((v - lo) / (hi - lo)).max(0.0).min(1.0);
    t * t * (3.0 - 2.0 * t)
}

/// The colour of water `depth` blocks deep: pale over the shallows, dark over the deep sea.
pub fn water_color(biome: Biome, depth: f64) -> Rgb {
    let d = depth.max(0.0) as f32;
    match biome {
        // rivers and lakes are shallow and a little brighter than the sea
        Biome::Lake => mix([84.0, 156.0, 226.0], [34.0, 92.0, 178.0], smooth(0.0, 12.0, d)),
        Biome::Swamp => mix([86.0, 126.0, 116.0], [52.0, 88.0, 90.0], smooth(0.0, 5.0, d)),
        _ => {
            let shallow = [64.0, 132.0, 214.0];
            let mid = [36.0, 78.0, 160.0];
            let deep = [14.0, 26.0, 96.0];
            if d < 8.0 {
                mix(shallow, mid, smooth(0.0, 8.0, d))
            } else {
                mix(mid, deep, smooth(8.0, 40.0, d))
            }
        }
    }
}

/// The colour of one map pixel. `height` is the ground height at the pixel and `east` / `south` the heights one pixel
/// away (`scale` blocks), which give the slope for the lighting.
pub fn pixel(biome: Biome, height: f64, east: f64, south: f64, scale: f64) -> [u8; 3] {
    let sea = SEA_LEVEL as f64;
    let c = if height < sea {
        water_color(biome, sea - height)
    } else {
        let mut c = land_color(biome);
        if biome == Biome::Mountains {
            // bare rock turns to snow near the tops
            c = mix(c, [246.0, 248.0, 252.0], smooth(sea as f32 + 96.0, sea as f32 + 136.0, height as f32));
        }
        // light from the north-west: ground that rises towards the east and the south faces the light
        let slope = ((east - height) + 0.7 * (south - height)) / scale.max(1.0);
        let lit = (slope * 0.45).max(-0.4).min(0.35) as f32;
        [c[0] * (1.0 + lit), c[1] * (1.0 + lit), c[2] * (1.0 + lit)]
    };
    [to_u8(c[0]), to_u8(c[1]), to_u8(c[2])]
}

fn to_u8(v: f32) -> u8 {
    v.max(0.0).min(255.0).round() as u8
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deeper_water_is_darker() {
        let shallow = pixel(Biome::Ocean, SEA_LEVEL as f64 - 2.0, 0.0, 0.0, 1.0);
        let deep = pixel(Biome::DeepOcean, SEA_LEVEL as f64 - 40.0, 0.0, 0.0, 1.0);
        let sum = |c: [u8; 3]| c[0] as u32 + c[1] as u32 + c[2] as u32;
        assert!(sum(shallow) > sum(deep));
    }

    #[test]
    fn ground_facing_the_light_is_brighter_than_ground_turned_away() {
        let h = SEA_LEVEL as f64 + 20.0;
        let lit = pixel(Biome::Plains, h, h + 4.0, h + 4.0, 2.0);
        let dark = pixel(Biome::Plains, h, h - 4.0, h - 4.0, 2.0);
        assert!(lit[1] > dark[1]);
    }

    #[test]
    fn high_mountains_are_snowy_and_low_ones_are_rock() {
        let sea = SEA_LEVEL as f64;
        let low = pixel(Biome::Mountains, sea + 40.0, sea + 40.0, sea + 40.0, 4.0);
        let high = pixel(Biome::Mountains, sea + 150.0, sea + 150.0, sea + 150.0, 4.0);
        assert!(high[2] > low[2] + 60, "{:?} {:?}", low, high);
    }

    #[test]
    fn every_biome_has_a_colour_that_fits_a_byte() {
        let all = [
            Biome::DeepOcean, Biome::Ocean, Biome::Lake, Biome::Beach, Biome::SnowyShore, Biome::Plains, Biome::Forest,
            Biome::BirchForest, Biome::Taiga, Biome::SnowyPlains, Biome::SnowyTaiga, Biome::Savanna, Biome::Desert,
            Biome::Swamp, Biome::Mountains, Biome::SnowyPeaks, Biome::Jungle, Biome::Rainforest,
        ];
        for &b in all.iter() {
            let c = land_color(b);
            assert!(c.iter().all(|&v| (0.0..=255.0).contains(&v)));
            let p = pixel(b, SEA_LEVEL as f64 + 10.0, SEA_LEVEL as f64 + 12.0, SEA_LEVEL as f64 + 9.0, 4.0);
            assert!(p.iter().any(|&v| v > 0));
        }
    }
}
