//! What the player sees of the map: on or off, the small corner map or the large one, the zoom, panning, and the
//! picture composed from the built tiles for all that. The picture is a plain RGBA buffer plus a serial number that
//! goes up whenever its pixels change, so the renderer can upload it only when it must.

use std::time::{Duration, Instant};

use super::cache::TileCache;
use super::tile::{blocks_per_pixel, TileBuilder, TileKey, MAX_ZOOM, TILE_PX};
use crate::gen::terrain::TerrainGenerator;

/// Side of the corner map, in map pixels.
pub const MINI_PX: usize = 128;
/// Side of the large map, in map pixels.
pub const BIG_PX: usize = 256;
/// The corner map's zoom: 4 blocks to a pixel, so it shows 512 blocks across.
pub const MINI_ZOOM: u8 = 2;
/// The zoom the large map opens at: 16 blocks to a pixel, 4096 across.
pub const BIG_ZOOM_DEFAULT: u8 = 4;
/// The closest the large map goes (2 blocks to a pixel).
pub const BIG_ZOOM_MIN: u8 = 1;

const CACHE_TILES: usize = 512;
/// How many rows of a tile are built between two looks at the clock.
const ROWS_PER_STEP: usize = 3;
/// How far beyond the picture tiles are built ahead, so that moving does not run into unbuilt ground.
const PREFETCH_PX: i64 = TILE_PX as i64;
/// What an unbuilt tile looks like.
const PLACEHOLDER: [u8; 4] = [22, 26, 38, 255];

/// The picture the map shows, `w` x `h` pixels of RGBA, row by row.
pub struct MapImage {
    pub w: usize,
    pub h: usize,
    pub rgba: Vec<u8>,
}

impl MapImage {
    fn empty() -> MapImage {
        MapImage { w: 0, h: 0, rgba: Vec::new() }
    }

    fn resize_filled(&mut self, w: usize, h: usize) {
        self.w = w;
        self.h = h;
        self.rgba.clear();
        self.rgba.reserve(w * h * 4);
        for _ in 0..w * h {
            self.rgba.extend_from_slice(&PLACEHOLDER);
        }
    }
}

/// What a composed picture was made for: the zoom, the map pixel at its top-left corner and its side.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
struct Composed {
    zoom: u8,
    gx: i64,
    gz: i64,
    side: usize,
}

pub struct MapView {
    visible: bool,
    expanded: bool,
    big_zoom: u8,
    /// Where the large map is centred when the player has dragged it away from himself.
    pan: Option<(f64, f64)>,
    player: (f64, f64),
    cache: TileCache,
    builder: Option<TileBuilder>,
    image: MapImage,
    composed: Option<Composed>,
    /// A tile inside the picture was built since it was composed.
    dirty: bool,
    serial: u64,
    /// Every tile of the picture is built.
    complete: bool,
}

impl MapView {
    pub fn new(visible: bool) -> MapView {
        MapView {
            visible,
            expanded: false,
            big_zoom: BIG_ZOOM_DEFAULT,
            pan: None,
            player: (0.0, 0.0),
            cache: TileCache::new(CACHE_TILES),
            builder: None,
            image: MapImage::empty(),
            composed: None,
            dirty: false,
            serial: 0,
            complete: false,
        }
    }

    /// Forgets everything built (a different world).
    pub fn reset(&mut self) {
        self.expanded = false;
        self.pan = None;
        self.cache.clear();
        self.builder = None;
        self.image = MapImage::empty();
        self.composed = None;
        self.dirty = false;
        self.complete = false;
        self.serial += 1;
    }

    // ------------------------------------------------------------------ what is asked for

    pub fn visible(&self) -> bool {
        self.visible
    }

    pub fn set_visible(&mut self, on: bool) {
        self.visible = on;
    }

    /// Turns the corner map on or off; returns whether it is on now.
    pub fn toggle(&mut self) -> bool {
        self.visible = !self.visible;
        self.visible
    }

    /// The map is drawn (so it has to be built): on, or open large.
    pub fn wanted(&self) -> bool {
        self.visible || self.expanded
    }

    pub fn is_expanded(&self) -> bool {
        self.expanded
    }

    /// Opens or closes the large map. Closing it puts the view back on the player.
    pub fn set_expanded(&mut self, on: bool) {
        if self.expanded != on {
            self.expanded = on;
            if !on {
                self.pan = None;
            }
        }
    }

    pub fn zoom(&self) -> u8 {
        if self.expanded {
            self.big_zoom
        } else {
            MINI_ZOOM
        }
    }

    pub fn can_zoom_in(&self) -> bool {
        self.big_zoom > BIG_ZOOM_MIN
    }

    pub fn can_zoom_out(&self) -> bool {
        self.big_zoom < MAX_ZOOM
    }

    pub fn zoom_in(&mut self) {
        if self.can_zoom_in() {
            self.big_zoom -= 1;
        }
    }

    pub fn zoom_out(&mut self) {
        if self.can_zoom_out() {
            self.big_zoom += 1;
        }
    }

    /// Side of the picture in map pixels.
    pub fn window_px(&self) -> usize {
        if self.expanded {
            BIG_PX
        } else {
            MINI_PX
        }
    }

    pub fn blocks_per_pixel(&self) -> i32 {
        blocks_per_pixel(self.zoom())
    }

    /// How many blocks the picture is wide.
    pub fn blocks_across(&self) -> i64 {
        self.window_px() as i64 * self.blocks_per_pixel() as i64
    }

    /// Moves the large map by a number of blocks (dragging it); the view no longer follows the player.
    pub fn pan_blocks(&mut self, dx: f64, dz: f64) {
        if !self.expanded {
            return;
        }
        let (cx, cz) = self.centre();
        self.pan = Some((cx + dx, cz + dz));
    }

    /// Puts the view back on the player.
    pub fn recenter(&mut self) {
        self.pan = None;
    }

    pub fn is_panned(&self) -> bool {
        self.pan.is_some()
    }

    /// The block column in the middle of the picture.
    pub fn centre(&self) -> (f64, f64) {
        self.pan.unwrap_or(self.player)
    }

    // ------------------------------------------------------------------ the picture

    pub fn image(&self) -> &MapImage {
        &self.image
    }

    /// Goes up whenever the pixels of the picture (or its size) change.
    pub fn serial(&self) -> u64 {
        self.serial
    }

    /// Every tile of the picture is built.
    pub fn is_complete(&self) -> bool {
        self.complete
    }

    /// Where a block column is in the picture, in map pixels from its top-left corner (outside 0..side when it is off
    /// the map).
    pub fn to_window(&self, wx: f64, wz: f64) -> (f32, f32) {
        let scale = self.blocks_per_pixel() as f64;
        let (gx, gz) = match self.composed {
            Some(c) => (c.gx, c.gz),
            None => (0, 0),
        };
        ((wx / scale - gx as f64) as f32, (wz / scale - gz as f64) as f32)
    }

    /// Builds tiles for up to `budget` (at least a few rows, so it always gets somewhere) and recomposes the picture when
    /// something in it changed. `player` is where the player stands.
    pub fn update(&mut self, generator: &TerrainGenerator, player: (f64, f64), budget: Duration) {
        self.player = player;
        let started = Instant::now();
        let zoom = self.zoom();
        let side = self.window_px();
        let (gx, gz) = self.origin_px(zoom, side);
        let want = Composed { zoom, gx, gz, side };

        let mut missing = self.tiles_around(&want, PREFETCH_PX);
        missing.retain(|k| !self.cache.contains(k));
        let mut next = 0;
        loop {
            if self.builder.is_none() {
                match missing.get(next) {
                    Some(k) => {
                        self.builder = Some(TileBuilder::new(*k));
                        next += 1;
                    }
                    None => break,
                }
            }
            let done = match self.builder.as_mut() {
                Some(b) => b.advance(generator, ROWS_PER_STEP),
                None => false,
            };
            if done {
                if let Some(b) = self.builder.take() {
                    let key = b.key();
                    if key.zoom == zoom && tile_touches(&key, &want) {
                        self.dirty = true;
                    }
                    self.cache.insert(key, b.finish());
                }
            }
            if started.elapsed() >= budget {
                break;
            }
        }
        self.complete = self.tiles_around(&want, 0).iter().all(|k| self.cache.contains(k));

        if self.dirty || self.composed != Some(want) || self.image.w != side {
            self.compose(want);
        }
    }

    /// The map pixel at the top-left corner of a picture centred on the view's centre.
    fn origin_px(&self, zoom: u8, side: usize) -> (i64, i64) {
        let scale = blocks_per_pixel(zoom) as f64;
        let (cx, cz) = self.centre();
        ((cx / scale).floor() as i64 - side as i64 / 2, (cz / scale).floor() as i64 - side as i64 / 2)
    }

    /// The tiles that touch the picture grown by `margin` pixels on every side, the ones nearest the middle first.
    fn tiles_around(&self, c: &Composed, margin: i64) -> Vec<TileKey> {
        let t = TILE_PX as i64;
        let side = c.side as i64;
        let first = TileKey::containing(c.zoom, c.gx - margin, c.gz - margin);
        let last = TileKey::containing(c.zoom, c.gx + side - 1 + margin, c.gz + side - 1 + margin);
        let mid_x = c.gx as f64 + side as f64 * 0.5;
        let mid_z = c.gz as f64 + side as f64 * 0.5;
        let mut out: Vec<(f64, TileKey)> = Vec::new();
        for tz in first.tz..=last.tz {
            for tx in first.tx..=last.tx {
                let dx = (tx as i64 * t + t / 2) as f64 - mid_x;
                let dz = (tz as i64 * t + t / 2) as f64 - mid_z;
                out.push((dx * dx + dz * dz, TileKey { zoom: c.zoom, tx, tz }));
            }
        }
        out.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        out.into_iter().map(|(_, k)| k).collect()
    }

    fn compose(&mut self, c: Composed) {
        if self.image.w != c.side || self.image.h != c.side {
            self.image.resize_filled(c.side, c.side);
        } else {
            for px in self.image.rgba.chunks_exact_mut(4) {
                px.copy_from_slice(&PLACEHOLDER);
            }
        }
        let t = TILE_PX as i64;
        let side = c.side as i64;
        for key in self.tiles_around(&c, 0) {
            let tile = match self.cache.get(&key) {
                Some(tile) => tile,
                None => continue,
            };
            let (ox, oz) = key.origin_px();
            let x_from = ox.max(c.gx);
            let x_to = (ox + t).min(c.gx + side);
            let z_from = oz.max(c.gz);
            let z_to = (oz + t).min(c.gz + side);
            if x_from >= x_to {
                continue;
            }
            let n = ((x_to - x_from) * 4) as usize;
            for z in z_from..z_to {
                let src = (((z - oz) * t + (x_from - ox)) * 4) as usize;
                let dst = (((z - c.gz) * side + (x_from - c.gx)) * 4) as usize;
                self.image.rgba[dst..dst + n].copy_from_slice(&tile.rgba[src..src + n]);
            }
        }
        self.composed = Some(c);
        self.dirty = false;
        self.serial += 1;
    }
}

fn tile_touches(key: &TileKey, c: &Composed) -> bool {
    let t = TILE_PX as i64;
    let (ox, oz) = key.origin_px();
    ox < c.gx + c.side as i64 && ox + t > c.gx && oz < c.gz + c.side as i64 && oz + t > c.gz
}

#[cfg(test)]
mod tests {
    use super::*;

    const LONG: Duration = Duration::from_secs(120);

    fn built(view: &mut MapView, g: &TerrainGenerator, at: (f64, f64)) {
        let mut guard = 0;
        loop {
            view.update(g, at, LONG);
            if view.is_complete() {
                break;
            }
            guard += 1;
            assert!(guard < 50, "the map never finished");
        }
    }

    #[test]
    fn it_can_be_toggled_and_remembers_nothing_it_should_not() {
        let mut v = MapView::new(true);
        assert!(v.visible() && v.wanted());
        assert!(!v.toggle());
        assert!(!v.visible() && !v.wanted());
        v.set_expanded(true);
        assert!(v.wanted(), "the large map is drawn even with the corner map off");
        v.pan_blocks(100.0, 0.0);
        assert!(v.is_panned());
        v.set_expanded(false);
        assert!(!v.is_panned(), "closing the large map puts the view back on the player");
        v.pan_blocks(100.0, 0.0);
        assert!(!v.is_panned(), "the corner map cannot be dragged");
    }

    #[test]
    fn the_picture_fills_in_and_every_pixel_is_opaque_once_complete() {
        let g = TerrainGenerator::new(3);
        let mut v = MapView::new(true);
        v.update(&g, (100.0, -40.0), Duration::ZERO);
        assert_eq!(v.image().w, MINI_PX);
        assert!(!v.is_complete(), "a zero budget builds only a few rows");
        built(&mut v, &g, (100.0, -40.0));
        let img = v.image();
        assert_eq!(img.rgba.len(), MINI_PX * MINI_PX * 4);
        assert!(img.rgba.chunks(4).all(|p| p[3] == 255));
        assert!(!img.rgba.chunks(4).any(|p| p[..3] == PLACEHOLDER[..3]), "every pixel came from a tile");
    }

    #[test]
    fn the_serial_goes_up_only_when_the_picture_changes() {
        let g = TerrainGenerator::new(3);
        let mut v = MapView::new(true);
        built(&mut v, &g, (0.0, 0.0));
        let s = v.serial();
        v.update(&g, (0.5, 0.5), LONG);
        assert_eq!(v.serial(), s, "a step smaller than a map pixel changes nothing");
        v.update(&g, (200.0, 0.0), LONG);
        assert!(v.serial() > s);
    }

    #[test]
    fn the_player_stays_in_the_middle_and_the_ground_slides_under_him() {
        let g = TerrainGenerator::new(9);
        let mut v = MapView::new(true);
        built(&mut v, &g, (0.0, 0.0));
        let (u0, w0) = v.to_window(0.0, 0.0);
        assert!((u0 - 64.0).abs() <= 1.0 && (w0 - 64.0).abs() <= 1.0, "{} {}", u0, w0);
        // the same block column moves left on the picture when the player walks east
        built(&mut v, &g, (80.0, 0.0));
        let (u1, _) = v.to_window(0.0, 0.0);
        assert!(u1 < u0 - 15.0, "{} {}", u0, u1);
        let (pu, _) = v.to_window(80.0, 0.0);
        assert!((pu - 64.0).abs() <= 1.0);
    }

    #[test]
    fn moving_the_view_reuses_tiles_instead_of_building_them_again() {
        let g = TerrainGenerator::new(9);
        let mut v = MapView::new(true);
        built(&mut v, &g, (0.0, 0.0));
        let before = v.cache.len();
        built(&mut v, &g, (16.0, 0.0)); // four pixels: well inside the tiles already built
        assert!(v.cache.len() <= before + 8, "{} -> {}", before, v.cache.len());
        built(&mut v, &g, (0.0, 0.0));
        assert!(v.cache.len() <= before + 8);
    }

    #[test]
    fn the_large_map_zooms_within_its_limits_and_pans() {
        let g = TerrainGenerator::new(21);
        let mut v = MapView::new(true);
        v.set_expanded(true);
        assert_eq!(v.window_px(), BIG_PX);
        for _ in 0..20 {
            v.zoom_out();
        }
        assert_eq!(v.zoom(), MAX_ZOOM);
        assert!(!v.can_zoom_out());
        for _ in 0..20 {
            v.zoom_in();
        }
        assert_eq!(v.zoom(), BIG_ZOOM_MIN);
        v.pan_blocks(500.0, -300.0);
        assert_eq!(v.centre(), (500.0, -300.0));
        built(&mut v, &g, (0.0, 0.0));
        // the player is 500 blocks west and 300 south of the middle, which is 250 / 150 pixels at 2 blocks a pixel: off the map
        let (u, w) = v.to_window(0.0, 0.0);
        assert!(u < 0.0 || w > BIG_PX as f32, "{} {}", u, w);
        v.recenter();
        assert_eq!(v.centre(), (0.0, 0.0));
    }

    #[test]
    fn reset_drops_what_was_built() {
        let g = TerrainGenerator::new(4);
        let mut v = MapView::new(true);
        built(&mut v, &g, (0.0, 0.0));
        let s = v.serial();
        v.reset();
        assert_eq!(v.image().w, 0);
        assert!(v.serial() > s);
        assert!(!v.is_complete());
    }
}
