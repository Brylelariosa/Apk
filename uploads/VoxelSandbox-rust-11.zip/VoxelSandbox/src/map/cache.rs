//! The tiles that are already built, so panning back and forth or flying over the same ground does not build them
//! again. When it is full the tile used longest ago goes.

use std::collections::HashMap;

use super::tile::{Tile, TileKey};

struct Entry {
    tile: Tile,
    used: u64,
}

pub struct TileCache {
    tiles: HashMap<TileKey, Entry>,
    capacity: usize,
    clock: u64,
}

impl TileCache {
    pub fn new(capacity: usize) -> TileCache {
        TileCache { tiles: HashMap::with_capacity(capacity.min(1024)), capacity: capacity.max(1), clock: 0 }
    }

    pub fn len(&self) -> usize {
        self.tiles.len()
    }

    pub fn is_empty(&self) -> bool {
        self.tiles.is_empty()
    }

    pub fn contains(&self, key: &TileKey) -> bool {
        self.tiles.contains_key(key)
    }

    /// The tile, marking it as used just now.
    pub fn get(&mut self, key: &TileKey) -> Option<&Tile> {
        self.clock += 1;
        let now = self.clock;
        match self.tiles.get_mut(key) {
            Some(e) => {
                e.used = now;
                Some(&e.tile)
            }
            None => None,
        }
    }

    pub fn insert(&mut self, key: TileKey, tile: Tile) {
        self.clock += 1;
        if !self.tiles.contains_key(&key) && self.tiles.len() >= self.capacity {
            let oldest = self.tiles.iter().min_by_key(|(_, e)| e.used).map(|(k, _)| *k);
            if let Some(k) = oldest {
                self.tiles.remove(&k);
            }
        }
        self.tiles.insert(key, Entry { tile, used: self.clock });
    }

    pub fn clear(&mut self) {
        self.tiles.clear();
        self.clock = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn blank() -> Tile {
        Tile { rgba: vec![0u8; 4].into_boxed_slice() }
    }

    fn key(i: i32) -> TileKey {
        TileKey { zoom: 0, tx: i, tz: 0 }
    }

    #[test]
    fn the_least_recently_used_tile_is_dropped_when_full() {
        let mut c = TileCache::new(3);
        c.insert(key(1), blank());
        c.insert(key(2), blank());
        c.insert(key(3), blank());
        assert!(c.get(&key(1)).is_some()); // 1 is fresh now, 2 is the oldest
        c.insert(key(4), blank());
        assert_eq!(c.len(), 3);
        assert!(c.contains(&key(1)) && c.contains(&key(3)) && c.contains(&key(4)));
        assert!(!c.contains(&key(2)));
    }

    #[test]
    fn replacing_a_tile_does_not_evict_another() {
        let mut c = TileCache::new(2);
        c.insert(key(1), blank());
        c.insert(key(2), blank());
        c.insert(key(2), blank());
        assert_eq!(c.len(), 2);
        assert!(c.contains(&key(1)));
    }
}
