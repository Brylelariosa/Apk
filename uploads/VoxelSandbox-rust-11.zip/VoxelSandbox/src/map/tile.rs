//! One square of the map: `TILE_PX` x `TILE_PX` pixels, each standing for `blocks_per_pixel(zoom)` blocks. A tile is a
//! pure function of the seed and its key, so it can be built any time, thrown away and built again. Building one
//! takes about a thousand samples of the land form, so `TileBuilder` can do it a few rows per frame.

use super::palette;
use crate::gen::climate::Biome;
use crate::gen::terrain::TerrainGenerator;

pub const TILE_PX: usize = 32;
const TILE_BYTES: usize = TILE_PX * TILE_PX * 4;
/// The samples of a tile include one more row and column than it has pixels: the slope of a pixel needs the heights
/// of its east and south neighbours.
const GRID: usize = TILE_PX + 1;

/// How many blocks one map pixel covers at each zoom level (0 is the closest).
/// (Farther out than 32 blocks to a pixel the continents are smaller than a few pixels and the map turns to noise.)
pub const ZOOM_BLOCKS: [i32; 6] = [1, 2, 4, 8, 16, 32];
pub const MAX_ZOOM: u8 = (ZOOM_BLOCKS.len() - 1) as u8;

pub fn blocks_per_pixel(zoom: u8) -> i32 {
    ZOOM_BLOCKS[(zoom.min(MAX_ZOOM)) as usize]
}

/// How much land-form detail is worth sampling at a zoom level: rivers and lakes are only in the levels below 3, and
/// far out nothing is narrower than a pixel anyway.
pub fn lod_for_zoom(zoom: u8) -> i32 {
    match zoom {
        0 | 1 => 0,
        2 => 1,
        3 | 4 => 2,
        _ => 3,
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct TileKey {
    pub zoom: u8,
    pub tx: i32,
    pub tz: i32,
}

impl TileKey {
    /// The tile that holds the map pixel (`px`, `pz`) (pixels counted from the world origin at this zoom).
    pub fn containing(zoom: u8, px: i64, pz: i64) -> TileKey {
        TileKey { zoom, tx: px.div_euclid(TILE_PX as i64) as i32, tz: pz.div_euclid(TILE_PX as i64) as i32 }
    }

    /// The map pixel at the top-left corner of the tile.
    pub fn origin_px(&self) -> (i64, i64) {
        (self.tx as i64 * TILE_PX as i64, self.tz as i64 * TILE_PX as i64)
    }
}

/// A finished tile: RGBA, row by row.
pub struct Tile {
    pub rgba: Box<[u8]>,
}

/// Builds a tile row by row.
pub struct TileBuilder {
    key: TileKey,
    heights: Vec<f32>,
    biomes: Vec<Biome>,
    rows_done: usize,
}

impl TileBuilder {
    pub fn new(key: TileKey) -> TileBuilder {
        TileBuilder { key, heights: vec![0.0; GRID * GRID], biomes: vec![Biome::Plains; GRID * GRID], rows_done: 0 }
    }

    pub fn key(&self) -> TileKey {
        self.key
    }

    pub fn is_done(&self) -> bool {
        self.rows_done >= GRID
    }

    /// Samples up to `rows` more rows of the grid. Returns true once the tile can be finished.
    pub fn advance(&mut self, generator: &TerrainGenerator, rows: usize) -> bool {
        let scale = blocks_per_pixel(self.key.zoom) as i64;
        let lod = lod_for_zoom(self.key.zoom);
        let (ox, oz) = self.key.origin_px();
        let mut left = rows;
        while left > 0 && self.rows_done < GRID {
            let row = self.rows_done;
            // sample the middle of the pixel
            let wz = (oz + row as i64) * scale + scale / 2;
            for col in 0..GRID {
                let wx = (ox + col as i64) * scale + scale / 2;
                let (h, biome) = generator.map_column(wx as i32, wz as i32, lod);
                self.heights[row * GRID + col] = h as f32;
                self.biomes[row * GRID + col] = biome;
            }
            self.rows_done += 1;
            left -= 1;
        }
        self.is_done()
    }

    /// Colours the sampled grid. Only call this when `is_done`.
    pub fn finish(self) -> Tile {
        debug_assert!(self.is_done());
        let scale = blocks_per_pixel(self.key.zoom) as f64;
        let mut rgba = vec![255u8; TILE_BYTES];
        for row in 0..TILE_PX {
            for col in 0..TILE_PX {
                let i = row * GRID + col;
                let c = palette::pixel(
                    self.biomes[i],
                    self.heights[i] as f64,
                    self.heights[i + 1] as f64,
                    self.heights[i + GRID] as f64,
                    scale,
                );
                let o = (row * TILE_PX + col) * 4;
                rgba[o] = c[0];
                rgba[o + 1] = c[1];
                rgba[o + 2] = c[2];
            }
        }
        Tile { rgba: rgba.into_boxed_slice() }
    }
}

/// Builds a whole tile at once (for tests and tools).
pub fn build_tile(generator: &TerrainGenerator, key: TileKey) -> Tile {
    let mut b = TileBuilder::new(key);
    b.advance(generator, GRID);
    b.finish()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn keys_cover_negative_pixels_without_a_seam_at_zero() {
        assert_eq!(TileKey::containing(2, 0, 0), TileKey { zoom: 2, tx: 0, tz: 0 });
        assert_eq!(TileKey::containing(2, -1, -1), TileKey { zoom: 2, tx: -1, tz: -1 });
        assert_eq!(TileKey::containing(2, 31, 32), TileKey { zoom: 2, tx: 0, tz: 1 });
        assert_eq!(TileKey { zoom: 2, tx: -1, tz: 2 }.origin_px(), (-32, 64));
    }

    #[test]
    fn zoom_levels_double_and_clamp() {
        assert_eq!(blocks_per_pixel(0), 1);
        assert_eq!(blocks_per_pixel(MAX_ZOOM), 32);
        assert_eq!(blocks_per_pixel(200), 32);
        assert!(lod_for_zoom(0) <= lod_for_zoom(MAX_ZOOM));
    }

    #[test]
    fn a_tile_is_deterministic_and_equal_whether_built_in_one_go_or_in_steps() {
        let g = TerrainGenerator::new(77);
        let key = TileKey { zoom: 3, tx: 4, tz: -3 };
        let whole = build_tile(&g, key);
        let mut b = TileBuilder::new(key);
        let mut steps = 0;
        while !b.advance(&g, 5) {
            steps += 1;
            assert!(steps < 100);
        }
        let stepped = b.finish();
        assert_eq!(whole.rgba, stepped.rgba);
        assert_eq!(whole.rgba.len(), TILE_BYTES);
        assert!(whole.rgba.chunks(4).all(|p| p[3] == 255));
    }

    #[test]
    fn neighbouring_tiles_agree_on_the_shared_edge_row() {
        // the last sampled row of a tile is the first row of the tile below it, so the lighting has no seam
        let g = TerrainGenerator::new(5);
        let a = TileKey { zoom: 2, tx: 0, tz: 0 };
        let mut ba = TileBuilder::new(a);
        ba.advance(&g, GRID);
        let mut bb = TileBuilder::new(TileKey { zoom: 2, tx: 0, tz: 1 });
        bb.advance(&g, 1);
        for col in 0..GRID {
            assert_eq!(ba.heights[TILE_PX * GRID + col], bb.heights[col]);
        }
    }
}
