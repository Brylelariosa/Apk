//! The world map: a top-down picture of the land (oceans, rivers, biomes, relief) like the one on a world-map
//! screen. Like the biome finder it never generates a chunk: the land form and the climate are pure functions of
//! the seed, so any part of the world can be drawn at any time.
//!
//! - `palette`: what colour a column of the world is on the map.
//! - `tile`: one 32 x 32 pixel square of the map, built a few rows at a time.
//! - `cache`: the tiles that are already built.
//! - `view`: what the player has asked for (on or off, small or large, zoom, panning) and the picture composed from
//!   the tiles for it, which the renderer uploads as a texture.
//!
//! Everything here is plain Rust that builds and tests on a normal computer.

pub mod cache;
pub mod palette;
pub mod tile;
pub mod view;

pub use view::{MapImage, MapView};
