package rustandroid;

import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.provider.ListProperty;
import org.gradle.api.provider.Property;

/**
 * The settings of the `rust-android` plugin, as the `rustAndroid { }` block of an app module:
 *
 * <pre>
 * rustAndroid {
 *     libraryName.set("voxelsandbox")   // [lib] name in Cargo.toml
 *     abis.set(listOf("arm64-v8a"))
 *     apiLevel.set(24)                  // the app's minSdk
 * }
 * </pre>
 */
public abstract class RustAndroidExtension {

    /** The folder with Cargo.toml. Default: the root project's folder. */
    public abstract DirectoryProperty getCrateDir();

    /** The library's name in Cargo.toml (`[lib] name`), without `lib` and `.so`. Required. */
    public abstract Property<String> getLibraryName();

    /** The ABIs to build: arm64-v8a, armeabi-v7a, x86_64, x86. Default: arm64-v8a. */
    public abstract ListProperty<String> getAbis();

    /** The lowest Android API level the app supports. Default: 21. */
    public abstract Property<Integer> getApiLevel();

    /** The cargo profile. Default: release. */
    public abstract Property<String> getProfile();

    /** Where the built libraries go, one folder per ABI. Default: the module's src/main/jniLibs. */
    public abstract DirectoryProperty getJniLibsDir();
}
