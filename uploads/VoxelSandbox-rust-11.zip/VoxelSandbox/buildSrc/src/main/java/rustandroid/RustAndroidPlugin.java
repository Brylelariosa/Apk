package rustandroid;

import java.util.Collections;

import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.tasks.TaskProvider;

/**
 * Builds a Rust library into an Android app: `buildRust` compiles it for every ABI and puts it into jniLibs, and the
 * Android Gradle plugin's own tasks wait for it.
 *
 * <p>Pass {@code -PrustPrebuilt=true} when the libraries were already built (by another CI step, say): the task is
 * still there but nothing depends on it.
 */
public class RustAndroidPlugin implements Plugin<Project> {
    public static final String EXTENSION_NAME = "rustAndroid";
    public static final String TASK_NAME = "buildRust";
    /** Set (with any value) to skip building; the jniLibs folder must then already hold the libraries. */
    public static final String PREBUILT_PROPERTY = "rustPrebuilt";

    @Override
    public void apply(Project project) {
        RustAndroidExtension extension = project.getExtensions().create(EXTENSION_NAME, RustAndroidExtension.class);
        extension.getCrateDir().convention(project.getRootProject().getLayout().getProjectDirectory());
        extension.getAbis().convention(Collections.singletonList("arm64-v8a"));
        extension.getApiLevel().convention(21);
        extension.getProfile().convention("release");
        extension.getJniLibsDir().convention(project.getLayout().getProjectDirectory().dir("src/main/jniLibs"));

        TaskProvider<CargoBuildTask> buildRust = project.getTasks().register(TASK_NAME, CargoBuildTask.class, task -> {
            task.setGroup("build");
            task.setDescription("Compiles the Rust library for every ABI into jniLibs");
            task.getCrateDir().set(extension.getCrateDir());
            task.getProjectRoot().set(project.getRootProject().getLayout().getProjectDirectory());
            task.getLibraryName().set(extension.getLibraryName());
            task.getAbis().set(extension.getAbis());
            task.getApiLevel().set(extension.getApiLevel());
            task.getProfile().set(extension.getProfile());
            task.getJniLibsDir().set(extension.getJniLibsDir());
        });

        if (!project.hasProperty(PREBUILT_PROPERTY)) {
            // `preBuild` comes before everything the Android plugin does for a variant, but not every one of its tasks
            // is ordered after it, so the task that gathers the jniLibs folders is tied to the build as well.
            project.getTasks().configureEach(task -> {
                String name = task.getName();
                if (name.equals("preBuild") || (name.startsWith("merge") && name.endsWith("JniLibFolders"))) {
                    task.dependsOn(buildRust);
                }
            });
        }
    }
}
