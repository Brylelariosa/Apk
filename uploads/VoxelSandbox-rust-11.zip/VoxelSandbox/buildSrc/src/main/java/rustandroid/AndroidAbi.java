package rustandroid;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;

import org.gradle.api.GradleException;

/** An Android ABI a Rust library can be built for, with the name each tool knows it by. */
enum AndroidAbi {
    ARM64_V8A("arm64-v8a", "aarch64-linux-android", "aarch64-linux-android"),
    ARMEABI_V7A("armeabi-v7a", "armv7-linux-androideabi", "armv7a-linux-androideabi"),
    X86_64("x86_64", "x86_64-linux-android", "x86_64-linux-android"),
    X86("x86", "i686-linux-android", "i686-linux-android");

    /** The folder name inside an APK's lib/ directory and inside jniLibs. */
    final String abi;
    /** The Rust target triple: what `rustup target add` and `cargo build --target` take. */
    final String rustTriple;
    /** The start of the NDK's clang wrapper names. It differs from the Rust triple for 32-bit ARM ("armv7a"). */
    final String clangPrefix;

    AndroidAbi(String abi, String rustTriple, String clangPrefix) {
        this.abi = abi;
        this.rustTriple = rustTriple;
        this.clangPrefix = clangPrefix;
    }

    /** The triple as cargo spells it inside variable names: {@code CARGO_TARGET_<this>_LINKER}. */
    String cargoEnvName() {
        return rustTriple.toUpperCase(Locale.ROOT).replace('-', '_');
    }

    /** The triple as the `cc` crate spells it inside variable names: {@code CC_<this>}. */
    String ccEnvName() {
        return rustTriple.replace('-', '_');
    }

    static AndroidAbi fromName(String name) {
        for (AndroidAbi candidate : values()) {
            if (candidate.abi.equals(name)) {
                return candidate;
            }
        }
        String valid = Arrays.stream(values()).map(a -> a.abi).collect(Collectors.joining(", "));
        throw new GradleException("Unknown Android ABI '" + name + "' in rustAbis. Use any of: " + valid + ".");
    }
}
