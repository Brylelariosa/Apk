package rustandroid;

import java.io.File;
import java.util.Arrays;
import java.util.Map;

/** Helpers for the environment (a name-to-value map) a child process is started with. */
final class ProcessEnv {
    private static final String[] WINDOWS_EXTENSIONS = {"", ".exe", ".cmd", ".bat"};

    private ProcessEnv() {
    }

    /** Adds `directory` in front of PATH, so what it holds wins over what is already installed. */
    static void prependToPath(Map<String, String> env, String directory) {
        String key = pathKey(env);
        String old = env.get(key);
        env.put(key, old == null || old.isEmpty() ? directory : directory + File.pathSeparator + old);
    }

    /** Adds `directory` at the end of PATH unless it is already there. */
    static void appendToPath(Map<String, String> env, String directory) {
        String key = pathKey(env);
        String old = env.getOrDefault(key, "");
        if (!Arrays.asList(old.split(File.pathSeparator)).contains(directory)) {
            env.put(key, old.isEmpty() ? directory : old + File.pathSeparator + directory);
        }
    }

    /**
     * The full path of the program `name`, looked up in the PATH of `env`. Java starts a child process with the
     * environment it is given but searches for the program in its own PATH, so a PATH that was changed for the child
     * (for example to add ~/.cargo/bin) only works if the program is looked up here. When it is not found the bare name
     * is returned and the system reports the problem.
     */
    static String resolve(Map<String, String> env, String name) {
        String path = env.getOrDefault(pathKey(env), "");
        boolean windows = File.separatorChar == '\\';
        for (String directory : path.split(File.pathSeparator)) {
            if (directory.isEmpty()) {
                continue;
            }
            for (String extension : windows ? WINDOWS_EXTENSIONS : new String[] {""}) {
                File candidate = new File(directory, name + extension);
                if (candidate.isFile() && candidate.canExecute()) {
                    return candidate.getPath();
                }
            }
        }
        return name;
    }

    /** The name PATH has in `env` (Windows spells it "Path"); "PATH" when there is none yet. */
    private static String pathKey(Map<String, String> env) {
        for (String key : env.keySet()) {
            if (key.equalsIgnoreCase("PATH")) {
                return key;
            }
        }
        return "PATH";
    }
}
