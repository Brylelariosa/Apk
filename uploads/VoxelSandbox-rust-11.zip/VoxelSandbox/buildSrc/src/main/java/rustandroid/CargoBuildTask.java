package rustandroid;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.gradle.api.DefaultTask;
import org.gradle.api.GradleException;
import org.gradle.api.file.DirectoryProperty;
import org.gradle.api.provider.ListProperty;
import org.gradle.api.provider.Property;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.Internal;
import org.gradle.api.tasks.TaskAction;
import org.gradle.process.ExecOperations;
import org.gradle.process.ExecResult;
import org.gradle.work.DisableCachingByDefault;

/**
 * Compiles a Rust `cdylib` for each Android ABI and copies the result into `jniLibs`, where the Android Gradle
 * plugin picks it up. Cargo is called directly, with the NDK's clang as the linker (see {@link NdkToolchain}), so
 * nothing but rustup/cargo and the NDK has to be installed: there is no `cargo-ndk` to install.
 *
 * <p>The task has no declared outputs, so it always runs; cargo decides for itself what is out of date, which
 * Gradle could only second-guess.
 */
@DisableCachingByDefault(because = "cargo keeps its own incremental state in the target folder")
public abstract class CargoBuildTask extends DefaultTask {

    /** The folder with Cargo.toml; cargo's `target` folder is created inside it. */
    @Internal
    public abstract DirectoryProperty getCrateDir();

    /** The Gradle root project, where local.properties may say where the Android SDK and NDK are. */
    @Internal
    public abstract DirectoryProperty getProjectRoot();

    /** The library's name in Cargo.toml (`[lib] name`), without `lib` and `.so`. */
    @Input
    public abstract Property<String> getLibraryName();

    /** Android ABI names (arm64-v8a, armeabi-v7a, x86_64, x86). */
    @Input
    public abstract ListProperty<String> getAbis();

    /** The lowest Android API level the app supports (its minSdk): the NDK wrapper for it links the library. */
    @Input
    public abstract Property<Integer> getApiLevel();

    /** The cargo profile: `release`, `dev`, or one of the crate's own. */
    @Input
    public abstract Property<String> getProfile();

    /** Where the libraries go: `<this>/<abi>/lib<name>.so`. */
    @Internal
    public abstract DirectoryProperty getJniLibsDir();

    @Inject
    protected abstract ExecOperations getExecOperations();

    @TaskAction
    public void build() {
        File crateDir = getCrateDir().get().getAsFile();
        File manifest = new File(crateDir, "Cargo.toml");
        if (!manifest.isFile()) {
            throw new GradleException("There is no Cargo.toml in " + crateDir + " (rustAndroid.crateDir says where it is).");
        }
        File targetDir = new File(crateDir, "target");
        int apiLevel = getApiLevel().get();
        String profile = getProfile().get();
        NdkToolchain ndk = NdkToolchain.locate(getProjectRoot().get().getAsFile(), System.getenv());

        for (String abiName : getAbis().get()) {
            AndroidAbi abi = AndroidAbi.fromName(abiName);
            getLogger().lifecycle("Rust: building {} for {} (NDK {}, API {}, profile {})",
                    getLibraryName().get(), abi.abi, ndk.root().getName(), apiLevel, profile);
            Map<String, String> env = withCargoOnPath(ndk.cargoEnvironment(abi, apiLevel, System.getenv()));
            new RustTargets(getExecOperations(), getLogger(), env).ensureInstalled(abi.rustTriple);
            runCargo(manifest, targetDir, abi, profile, env, crateDir);
            install(targetDir, abi, profile);
        }
    }

    private void runCargo(File manifest, File targetDir, AndroidAbi abi, String profile, Map<String, String> env, File workDir) {
        List<String> args = new ArrayList<>(Arrays.asList(
                "build", "--lib",
                "--manifest-path", manifest.getPath(),
                "--target", abi.rustTriple,
                // spelled out so that CARGO_TARGET_DIR or a .cargo/config.toml cannot move the result
                "--target-dir", targetDir.getPath(),
                "--profile", profile));
        ExecResult result;
        try {
            result = getExecOperations().exec(spec -> {
                spec.setExecutable(ProcessEnv.resolve(env, "cargo"));
                spec.setArgs(args);
                spec.setEnvironment(env);
                spec.setWorkingDir(workDir);
                spec.setIgnoreExitValue(true);
            });
        } catch (RuntimeException cannotStart) {
            throw new GradleException("Could not run cargo. Install Rust (https://rustup.rs) and make sure cargo is on PATH.",
                    cannotStart);
        }
        if (result.getExitValue() != 0) {
            throw new GradleException("cargo build failed for " + abi.rustTriple + " (exit " + result.getExitValue()
                    + "). The compiler's messages are above.");
        }
    }

    /** Copies what cargo built to `<jniLibs>/<abi>/lib<name>.so`. */
    private void install(File targetDir, AndroidAbi abi, String profile) {
        String fileName = "lib" + getLibraryName().get() + ".so";
        File built = new File(new File(new File(targetDir, abi.rustTriple), profileFolder(profile)), fileName);
        if (!built.isFile()) {
            throw new GradleException("cargo succeeded but did not produce " + built + ". The crate needs crate-type = [\"cdylib\"] "
                    + "and [lib] name = \"" + getLibraryName().get() + "\". Libraries found there: " + sharedLibraries(built.getParentFile()));
        }
        File destination = new File(new File(getJniLibsDir().get().getAsFile(), abi.abi), fileName);
        try {
            Files.createDirectories(destination.getParentFile().toPath());
            Files.copy(built.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new GradleException("Could not copy " + built + " to " + destination + ": " + e.getMessage(), e);
        }
        getLogger().lifecycle("Rust: {}/{} ready ({} KB)", abi.abi, fileName, destination.length() / 1024);
    }

    /** Cargo's profile names and the folders it builds them in differ for a few of the built-in ones. */
    private static String profileFolder(String profile) {
        switch (profile) {
            case "dev":
            case "test":
                return "debug";
            case "bench":
                return "release";
            default:
                return profile;
        }
    }

    private static String sharedLibraries(File folder) {
        String[] names = folder.list((dir, name) -> name.endsWith(".so"));
        return names == null || names.length == 0 ? "none" : Arrays.stream(names).sorted().collect(Collectors.joining(", "));
    }

    /** Gradle may run with a PATH that lacks ~/.cargo/bin (a daemon started from a desktop launcher, say). */
    private static Map<String, String> withCargoOnPath(Map<String, String> env) {
        File cargoBin = new File(System.getProperty("user.home", ""), ".cargo/bin");
        if (cargoBin.isDirectory()) {
            ProcessEnv.appendToPath(env, cargoBin.getPath());
        }
        return env;
    }
}
