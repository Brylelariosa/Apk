package rustandroid;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.gradle.api.GradleException;

/**
 * The part of the Android NDK a Rust build needs: the clang wrapper scripts (the linker for Rust, the C compiler for
 * the build scripts of dependencies) and the LLVM tools. It finds the NDK the way Android's own tooling does and
 * describes how to point cargo at it, which is the whole job `cargo-ndk` does.
 */
final class NdkToolchain {
    private static final String[] NDK_VARIABLES = {"ANDROID_NDK_HOME", "ANDROID_NDK_ROOT", "ANDROID_NDK", "NDK_HOME"};
    private static final String[] SDK_VARIABLES = {"ANDROID_HOME", "ANDROID_SDK_ROOT"};

    private final File root;
    private final File bin;
    private final boolean windows;

    private NdkToolchain(File root, File bin) {
        this.root = root;
        this.bin = bin;
        this.windows = isWindows();
    }

    /**
     * Looks for an NDK, in this order: the NDK environment variables, `ndk.dir` in local.properties, then the
     * newest NDK inside the Android SDK (from the SDK environment variables or `sdk.dir` in local.properties).
     */
    static NdkToolchain locate(File projectRoot, Map<String, String> env) {
        List<File> candidates = candidates(projectRoot, env);
        for (File dir : candidates) {
            File bin = new File(dir, "toolchains/llvm/prebuilt/" + hostTag() + "/bin");
            if (bin.isDirectory()) {
                return new NdkToolchain(dir, bin);
            }
        }
        StringBuilder message = new StringBuilder("The Android NDK was not found. Set ANDROID_NDK_HOME to an NDK folder ")
                .append("(r23 or newer), or install one with: sdkmanager \"ndk;25.2.9519653\".");
        if (candidates.isEmpty()) {
            message.append(" No NDK or SDK location is set at all.");
        } else {
            message.append(" Looked in:");
            for (File dir : candidates) {
                message.append("\n  ").append(dir);
            }
        }
        throw new GradleException(message.toString());
    }

    File root() {
        return root;
    }

    /**
     * The environment for `cargo build --target <abi's triple>`: the linker for Rust itself, the C compiler and archiver
     * the `cc` crate uses in build scripts, and the NDK on PATH. Everything in `base` is kept.
     */
    Map<String, String> cargoEnvironment(AndroidAbi abi, int apiLevel, Map<String, String> base) {
        Map<String, String> env = new LinkedHashMap<>(base);
        String clang = clang(abi, apiLevel).getPath();
        env.put("CARGO_TARGET_" + abi.cargoEnvName() + "_LINKER", clang);
        env.put("CC_" + abi.ccEnvName(), clang);
        File clangPlusPlus = wrapper(abi, apiLevel, "-clang++");
        if (clangPlusPlus != null) {
            env.put("CXX_" + abi.ccEnvName(), clangPlusPlus.getPath());
        }
        env.put("AR_" + abi.ccEnvName(), tool("llvm-ar").getPath());
        env.put("RANLIB_" + abi.ccEnvName(), tool("llvm-ranlib").getPath());
        env.put("ANDROID_NDK_HOME", root.getPath());
        env.put("ANDROID_NDK_ROOT", root.getPath());
        ProcessEnv.prependToPath(env, bin.getPath());
        return env;
    }

    /** The clang wrapper that compiles and links for `abi` at `apiLevel` (for example aarch64-linux-android24-clang). */
    File clang(AndroidAbi abi, int apiLevel) {
        File found = wrapper(abi, apiLevel, "-clang");
        if (found == null) {
            throw new GradleException("The NDK in " + root + " has no " + abi.clangPrefix + "<api>-clang wrapper for "
                    + abi.abi + " (looked in " + bin + "). Use an NDK r23 or newer.");
        }
        return found;
    }

    private File tool(String name) {
        return new File(bin, name + (windows ? ".exe" : ""));
    }

    /**
     * The wrapper for the requested API level. When the NDK has none for exactly that level (a very old or very new
     * minSdk) the nearest lower level is used, or the lowest there is.
     */
    private File wrapper(AndroidAbi abi, int apiLevel, String suffix) {
        String extension = windows ? ".cmd" : "";
        File exact = new File(bin, abi.clangPrefix + apiLevel + suffix + extension);
        if (exact.isFile()) {
            return exact;
        }
        Pattern name = Pattern.compile("^" + Pattern.quote(abi.clangPrefix) + "(\\d+)" + Pattern.quote(suffix + extension) + "$");
        int below = -1;
        int above = Integer.MAX_VALUE;
        String[] names = bin.list();
        for (String candidate : names == null ? new String[0] : names) {
            Matcher m = name.matcher(candidate);
            if (!m.matches()) {
                continue;
            }
            int level = Integer.parseInt(m.group(1));
            if (level <= apiLevel) {
                below = Math.max(below, level);
            } else {
                above = Math.min(above, level);
            }
        }
        int chosen = below >= 0 ? below : above;
        if (chosen == Integer.MAX_VALUE) {
            return null;
        }
        return new File(bin, abi.clangPrefix + chosen + suffix + extension);
    }

    // ---------------------------------------------------------------------------------------------- discovery

    private static List<File> candidates(File projectRoot, Map<String, String> env) {
        Properties local = localProperties(projectRoot);
        List<File> found = new ArrayList<>();
        for (String variable : NDK_VARIABLES) {
            addIfSet(found, env.get(variable));
        }
        addIfSet(found, local.getProperty("ndk.dir"));
        List<String> sdks = new ArrayList<>();
        for (String variable : SDK_VARIABLES) {
            sdks.add(env.get(variable));
        }
        sdks.add(local.getProperty("sdk.dir"));
        for (String sdk : sdks) {
            if (sdk == null || sdk.trim().isEmpty()) {
                continue;
            }
            found.addAll(newestFirst(new File(sdk.trim(), "ndk")));
            found.add(new File(sdk.trim(), "ndk-bundle"));
        }
        return found;
    }

    private static void addIfSet(List<File> into, String path) {
        if (path != null && !path.trim().isEmpty()) {
            into.add(new File(path.trim()));
        }
    }

    /** The version folders of `<sdk>/ndk` (for example 25.2.9519653), the highest version first. */
    private static List<File> newestFirst(File ndkFolder) {
        File[] children = ndkFolder.listFiles(File::isDirectory);
        List<File> versions = new ArrayList<>(children == null ? new ArrayList<File>() : Arrays.asList(children));
        versions.sort(Comparator.comparing((File f) -> versionParts(f.getName()), NdkToolchain::compareVersions).reversed());
        return versions;
    }

    private static int[] versionParts(String name) {
        String[] pieces = name.split("\\.");
        int[] parts = new int[pieces.length];
        for (int i = 0; i < pieces.length; i++) {
            try {
                parts[i] = Integer.parseInt(pieces[i]);
            } catch (NumberFormatException e) {
                parts[i] = 0;
            }
        }
        return parts;
    }

    private static int compareVersions(int[] a, int[] b) {
        for (int i = 0; i < Math.max(a.length, b.length); i++) {
            int left = i < a.length ? a[i] : 0;
            int right = i < b.length ? b[i] : 0;
            if (left != right) {
                return Integer.compare(left, right);
            }
        }
        return 0;
    }

    private static Properties localProperties(File projectRoot) {
        Properties properties = new Properties();
        File file = new File(projectRoot, "local.properties");
        if (file.isFile()) {
            try (InputStream in = new FileInputStream(file)) {
                properties.load(in);
            } catch (IOException ignored) {
                // an unreadable local.properties is the same as none
            }
        }
        return properties;
    }

    // ---------------------------------------------------------------------------------------------- the host

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    /** The folder name the NDK uses for the machine it runs on. */
    private static String hostTag() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("win")) {
            return "windows-x86_64";
        }
        if (os.contains("mac")) {
            return "darwin-x86_64";
        }
        return "linux-x86_64";
    }
}
