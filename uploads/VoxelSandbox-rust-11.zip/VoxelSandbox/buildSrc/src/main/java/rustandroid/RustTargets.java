package rustandroid;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

import org.gradle.api.GradleException;
import org.gradle.api.logging.Logger;
import org.gradle.process.ExecOperations;

/**
 * Makes sure the Rust standard library for an Android target is installed. A stock Rust toolchain only has its own
 * platform; without this, `cargo build --target aarch64-linux-android` stops with "can't find crate for `core`".
 */
final class RustTargets {
    private final ExecOperations exec;
    private final Logger logger;
    private final Map<String, String> env;

    RustTargets(ExecOperations exec, Logger logger, Map<String, String> env) {
        this.exec = exec;
        this.logger = logger;
        this.env = env;
    }

    /** Installs `triple` with rustup unless it is there already. Without rustup the target has to be installed by hand. */
    void ensureInstalled(String triple) {
        Run listing;
        try {
            listing = rustup("target", "list", "--installed");
        } catch (RuntimeException rustupIsNotInstalled) {
            logger.lifecycle("Rust: rustup was not found, so the Rust target {} is assumed to be installed", triple);
            return;
        }
        if (listing.exitValue == 0 && Arrays.stream(listing.out.split("\\R")).anyMatch(line -> line.trim().equals(triple))) {
            return;
        }
        logger.lifecycle("Rust: installing the Rust target {} (rustup target add)", triple);
        Run added = rustup("target", "add", triple);
        if (added.exitValue != 0) {
            throw new GradleException("`rustup target add " + triple + "` failed (exit " + added.exitValue + "): "
                    + (added.err.isEmpty() ? added.out : added.err));
        }
    }

    /** What a finished rustup process left behind. */
    private static final class Run {
        final int exitValue;
        final String out;
        final String err;

        Run(int exitValue, String out, String err) {
            this.exitValue = exitValue;
            this.out = out;
            this.err = err;
        }
    }

    /** Runs `rustup <args>`. A failing exit value is returned, not thrown; a rustup that cannot start throws. */
    private Run rustup(String... args) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int exitValue = exec.exec(spec -> {
            spec.setExecutable(ProcessEnv.resolve(env, "rustup"));
            spec.setArgs(Arrays.asList(args));
            spec.setEnvironment(env);
            spec.setStandardOutput(out);
            spec.setErrorOutput(err);
            spec.setIgnoreExitValue(true);
        }).getExitValue();
        return new Run(exitValue, utf8(out), utf8(err));
    }

    private static String utf8(ByteArrayOutputStream stream) {
        return new String(stream.toByteArray(), StandardCharsets.UTF_8).trim();
    }
}
