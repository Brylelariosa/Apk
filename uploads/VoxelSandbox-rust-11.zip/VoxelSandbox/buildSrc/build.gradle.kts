// Build logic for the Rust half of the app: the `rust-android` plugin (see src/main/java/rustandroid).
//
// It is plain Java on purpose. It needs only the JDK and Gradle's own API, so it compiles the same way on every
// machine and CI runner, with no extra plugin or library to download.
plugins {
    `java-gradle-plugin`
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(11)
}

gradlePlugin {
    plugins {
        register("rustAndroid") {
            id = "rust-android"
            implementationClass = "rustandroid.RustAndroidPlugin"
        }
    }
}
