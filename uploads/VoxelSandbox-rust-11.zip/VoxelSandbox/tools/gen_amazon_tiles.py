#!/usr/bin/env python3
"""Hand-made Amazon rainforest tiles (cells 43..54) for the VoxelSandbox texture array.

Writes the Rust lines to tools/amazon_tiles.rs.txt (paste them at the end of TILE_SRCS) and a preview sheet to
tools/amazon_tiles_preview.png. Run from the project root:  python3 tools/gen_amazon_tiles.py
"""
import math, random, json, os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def grid():
    return [['.' for _ in range(16)] for _ in range(16)]


def rows_of(g):
    return ''.join(''.join(r) for r in g)


def put(g, x, y, v, over=True):
    x, y = int(round(x)), int(round(y))
    if 0 <= x < 16 and 0 <= y < 16 and (over or g[y][x] == '.'):
        g[y][x] = v if isinstance(v, str) else str(v)


def line(g, x0, y0, x1, y1, v, over=True):
    n = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 1
    for i in range(n + 1):
        t = i / n
        put(g, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, v, over)


def blob(g, cx, cy, rx, ry, v_edge, v_mid, v_hi=None, over=True):
    for y in range(16):
        for x in range(16):
            d = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2
            if d <= 1.0:
                if d > 0.66:
                    put(g, x, y, v_edge, over)
                elif v_hi is not None and d < 0.16 and (x + y) % 2 == 0:
                    put(g, x, y, v_hi, over)
                else:
                    put(g, x, y, v_mid, over)


tiles = []

# ------------------------------------------------------------ 43 fern_b: long arching sword fern
pal = "123f1c 1f5a26 2f7d33 4a9e45 72c25a".split()
g = grid()
for deg in (-78, -52, -26, 0, 26, 52, 78):
    a = math.radians(deg)
    length = 12 if abs(deg) < 60 else 9
    if deg == 0:
        length = 14
    side = 1 if deg > 0 else -1
    pts = []
    for t in range(length + 1):
        k = t / length
        px = 7.5 + math.sin(a) * t * 0.9 + side * 2.4 * k * k * (1 if deg else 0)
        py = 15.0 - math.cos(a) * t * 0.95 + (k ** 3) * (5.0 if abs(deg) > 40 else 1.5)
        pts.append((px, py))
    for i, (px, py) in enumerate(pts):
        k = i / length
        put(g, px, py, clamp(int(1 + 2 * k), 0, 3))
        if i >= 3 and i % 2 == 1:
            for s in (-1, 1):
                put(g, px + s, py + (1 if abs(deg) > 40 else 0), clamp(int(2 + 2 * k), 2, 4), over=False)
tiles.append(dict(cell=43, name="fern_b", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 44 broadleaf: big heart-shaped leaves (philodendron)
pal = "17421a 24602a 358237 4fa046 78c466 2e4a1f".split()
g = grid()
for (x0, y0, x1, y1) in [(7.5, 15, 4, 8), (7.5, 15, 11.5, 6), (7.5, 15, 8, 11)]:
    line(g, x0, y0, x1, y1, 5)
leaves = [(4.0, 5.5, 4.2, 3.6), (11.5, 4.2, 4.2, 3.4), (8.0, 9.3, 3.6, 2.9)]
for (cx, cy, rx, ry) in leaves:
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / rx, (y - cy) / ry
            # heart: a disc with a notch at the stem side (bottom) and a point at the top
            d = dx * dx + dy * dy - (0.15 * dx * dy if dy > 0 else 0)
            notch = dy > 0.55 and abs(dx) < 0.22
            if d <= 1.0 and not notch:
                if d > 0.62:
                    put(g, x, y, 1)
                elif abs(x - cx) < 0.6:
                    put(g, x, y, 4)  # midrib
                else:
                    put(g, x, y, 2 if (x + y) % 3 else 3)
tiles.append(dict(cell=44, name="broadleaf", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 45 palm_sapling: little palm with feather fronds
pal = "1b5a1d 2c7c2c 43a03d 63bf52 8b6f47 6b5233".split()
g = grid()
for y in range(9, 16):
    put(g, 7, y, 5)
    put(g, 8, y, 4 if y % 2 else 5)
for deg in (-84, -58, -32, -8, 8, 32, 58, 84):
    a = math.radians(deg)
    side = 1 if deg > 0 else -1
    length = 8
    for t in range(1, length + 1):
        k = t / length
        px = 7.5 + math.sin(a) * t * 0.95
        py = 9.0 - math.cos(a) * t * 0.55 + (k ** 2) * (3.0 if abs(deg) > 50 else 1.0)
        put(g, px, py, clamp(int(0 + 3 * k), 0, 3))
        if t >= 2 and t % 2 == 0:
            put(g, px, py + 1, clamp(int(1 + 2 * k), 1, 3), over=False)
            put(g, px, py - 1, clamp(int(2 + k), 1, 3), over=False)
tiles.append(dict(cell=45, name="palm_sapling", palette=pal, rows=rows_of(g)))


# ------------------------------------------------------------ heliconia (46 red, 47 yellow)
def heliconia(cell, name, bract_dark, bract_mid, bract_light, tip):
    pal = ["2a6b24", "3f8f37", "58b04a", "7ccd66", bract_dark, bract_mid, bract_light, tip]
    g = grid()
    # two banana-like leaves
    for (x0, x1, yb, yt) in [(7, 2, 15, 9), (8, 13, 15, 8)]:
        line(g, x0, yb, (x0 + x1) / 2, (yb + yt) / 2 + 1, 0)
        cx, cy = (x0 + x1) / 2 + (-1 if x1 < x0 else 1), (yb + yt) / 2 + 0.5
        blob(g, cx, cy, 3.4, 2.0, 1, 2, 3)
    # stem
    for y in range(6, 16):
        put(g, 7, y, 0)
        put(g, 8, y, 1 if y % 3 else 0)
    # zig-zag bracts, widest in the middle (integer columns: the stem is x = 7 and 8)
    ys = [1, 3, 5, 7, 9]
    for i, y in enumerate(ys):
        left = (i % 2 == 0)
        w = 2 if i in (0, 4) else 3
        for dx in range(0, w + 1):
            x = (7 - dx) if left else (8 + dx)
            put(g, x, y, 5 if dx < w else 6)
            put(g, x, y + 1, 4 if dx < w - 1 else 5)
        tipx = (7 - w - 1) if left else (8 + w + 1)
        put(g, tipx, y, 7)
        put(g, tipx, y + 1, 7, over=False)
    put(g, 7, 0, 7)
    put(g, 8, 0, 7)
    for y in range(1, 11):
        put(g, 7, y, 4)
        put(g, 8, y, 5)
    tiles.append(dict(cell=cell, name=name, palette=pal, rows=rows_of(g)))


heliconia(46, "heliconia_red", "a3101a", "d92b25", "ff6a2b", "ffd23f")
heliconia(47, "heliconia_yellow", "d9a21b", "f5c72c", "ffe86b", "7ccd66")

# ------------------------------------------------------------ 48 bromeliad: spiky rosette with a red heart
pal = "1b5a2a 2c7d3a 48a04c 6cc25a b3141c e8352a ff8a2e ffd23f".split()
g = grid()
cx, cy = 7.5, 11.5
for i, deg in enumerate(range(-90, 91, 22)):
    a = math.radians(deg)
    length = 6.5 if abs(deg) < 60 else 5
    for t in range(1, int(length * 2) + 1):
        k = t / (length * 2)
        px = cx + math.sin(a) * t * 0.55
        py = cy - math.cos(a) * t * 0.55 * 0.95 + (k ** 2) * (2.5 if abs(deg) > 50 else 0.5)
        put(g, px, py, clamp(int(0 + 3 * k), 0, 3))
for deg in (-24, 0, 24):
    a = math.radians(deg)
    for t in range(1, 6):
        put(g, cx + math.sin(a) * t * 0.7, cy - math.cos(a) * t * 0.9 - 0.5, clamp(3 + t // 2, 4, 6))
put(g, 7, 6, 7)
put(g, 8, 6, 7)
put(g, 7, 7, 6)
put(g, 8, 7, 6)
for x in range(4, 12):
    for y in range(12, 16):
        d = ((x - cx) / 4.2) ** 2 + ((y - 13) / 2.4) ** 2
        if d <= 1:
            put(g, x, y, 1 if d > 0.5 else 2)
tiles.append(dict(cell=48, name="bromeliad", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 49 orchid: arching stem with pink flowers
pal = "2a6b24 3f8f37 6cc25a c2307e f59ac6 ffd9ec fff4fa 8e2a8c f2d02e".split()
g = grid()
for (x0, y0, x1, y1) in [(7, 15, 3, 9), (8, 15, 13, 10), (7, 15, 5, 12)]:
    line(g, x0, y0, x1, y1, 1)
    line(g, x0 + 1, y0, x1 + 1, y1 + 1, 0, over=False)
stem = [(7.5, 15), (7.5, 12), (8.0, 9), (8.5, 6), (9.5, 4), (10.5, 3)]
for i in range(len(stem) - 1):
    line(g, stem[i][0], stem[i][1], stem[i + 1][0], stem[i + 1][1], 1)


def flower(cx, cy, s=1.0):
    for ang in range(5):
        a = math.radians(ang * 72 - 90)
        for t in (1.0, 2.0):
            put(g, cx + math.cos(a) * t * s, cy + math.sin(a) * t * s, 4 if t < 1.5 else 5)
    put(g, cx, cy, 8)
    put(g, cx, cy + 1, 3)
    put(g, cx - 1, cy + 1, 3)
    put(g, cx + 1, cy + 1, 3)


flower(10, 3, 1.0)
flower(7, 6, 1.0)
flower(11, 8, 0.9)
flower(5, 9, 0.8)
tiles.append(dict(cell=49, name="orchid", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 50 vine_flower: liana with orange trumpet flowers
rng = random.Random(1150)
pal = "1a5222 28702b 3b9040 56ae4f e8481c ff8c2b ffd23f".split()
g = grid()
strands = [(2, 16), (5, 12), (8, 16), (11, 10), (13, 15)]
for sx, ln in strands:
    for y in range(ln):
        put(g, sx, y, 1 if y % 3 else 0)
        if y % 3 == 1 and y > 0:
            for dx in (-1, 1):
                if 0 <= sx + dx < 16 and g[y][sx + dx] == '.':
                    put(g, sx + dx, y, rng.choice([2, 3, 3]))
for (fx, fy) in [(2, 5), (5, 8), (8, 11), (11, 6), (13, 12), (8, 4)]:
    put(g, fx, fy, 5)
    put(g, fx - 1, fy + 1, 4)
    put(g, fx + 1, fy + 1, 4)
    put(g, fx, fy + 1, 6)
    put(g, fx, fy + 2, 4)
for x in range(1, 15):
    if g[0][x] == '.':
        g[0][x] = '0'
tiles.append(dict(cell=50, name="vine_flower", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 51 lily_flower: giant water-lily pad with a pink bloom
pal = "1f6a2a 2e8b3a 49a653 6cc36b ff7fb0 ffc2dc fff3f8 f2e04a 175a22".split()
g = grid()
for y in range(16):
    for x in range(16):
        dx, dy = x - 7.5, y - 7.5
        r = math.hypot(dx, dy)
        ang = math.atan2(dy, dx)
        notch = abs(ang - 0.6) < 0.16 and r > 2
        if r <= 7.4 and not notch:
            if r > 6.2:
                g[y][x] = '8'      # raised rim
            else:
                g[y][x] = '1' if (x * 3 + y * 5) % 7 else '2'
                if int(r) in (3, 5) and (x + y) % 2 == 0:
                    g[y][x] = '3'
for y in range(16):
    for x in range(16):
        dx, dy = x - 7.5, y - 7.5
        r = math.hypot(dx, dy)
        ang = math.atan2(dy, dx)
        reach = 3.2 + 0.7 * math.cos(6 * ang)
        if r <= reach:
            g[y][x] = '4' if r > 1.8 else '5'
            if r > reach - 0.9:
                g[y][x] = '5'
        if r <= 1.1:
            g[y][x] = '7'
tiles.append(dict(cell=51, name="lily_flower", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 52 jungle_leaves_b: lighter, broader leaf blades
rng = random.Random(1152)
pal = "0b4a16 126024 1c7a2a 2a9a38 55c24e".split()
g = grid()
for y in range(16):
    for x in range(16):
        v = rng.choice([1, 2, 2, 2, 3, 0, 3])
        if (x + 2 * y) % 5 == 0:
            v = clamp(v + 1, 0, 4)
        if (x - y) % 7 == 3:
            v = clamp(v - 1, 0, 4)
        g[y][x] = str(v)
for _ in range(4):
    cx, cy = rng.randrange(16), rng.randrange(16)
    g[cy][cx] = '4'
    g[cy][(cx + 1) % 16] = '3'
holes = 0
while holes < 22:
    x, y = rng.randrange(16), rng.randrange(16)
    if g[y][x] != '.':
        g[y][x] = '.'
        holes += 1
tiles.append(dict(cell=52, name="jungle_leaves_b", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 53 jungle_bark_b: pale smooth kapok bark with moss
rng = random.Random(1153)
pal = "3a3832 4b4943 5e5b53 726e64 878277 94907f 56673a 70853f".split()
base = [rng.choice([1, 2, 2, 3, 3, 4]) for _ in range(16)]
g = grid()
for y in range(16):
    for x in range(16):
        v = base[x] + rng.choice([-1, 0, 0, 0, 1])
        if x in (3, 9, 14) or (x + (y // 6)) % 11 == 0:
            v -= 1
        g[y][x] = str(clamp(v, 0, 5))
for _ in range(5):
    cx, cy = rng.randrange(16), rng.randrange(16)
    r = rng.choice([1, 1, 2])
    for y in range(16):
        for x in range(16):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + rng.choice([0, 0, 1]) and rng.random() < 0.8:
                g[y][x] = str(rng.choice([6, 6, 7]))
tiles.append(dict(cell=53, name="jungle_bark_b", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ 54 fungi: forest-floor mushrooms
pal = "2a1c12 4a3a24 6b5a3a d94f2b ff8a5c ffe9d2 d8c8a0 23501d 3a7a2a".split()
g = grid()
for (x0, x1, y) in [(2, 6, 13), (9, 14, 14)]:
    for x in range(x0, x1 + 1):
        put(g, x, y + 1, 7 if x % 2 else 8)
for y in range(8, 15):
    put(g, 5, y, 6)
    put(g, 6, y, 6 if y % 2 else 5)
for y in range(7, 16):
    pass
blob(g, 5.5, 7.0, 4.2, 2.6, 3, 3, 4)
for (dx, dy) in [(-2, -1), (0, -2), (2, 0), (-1, 1), (1, -1)]:
    put(g, 5.5 + dx, 7.0 + dy, 5)
for y in range(11, 16):
    put(g, 12, y, 6)
blob(g, 12.0, 10.0, 2.8, 1.8, 2, 1, 2)
put(g, 11, 9, 5)
put(g, 13, 10, 5)
tiles.append(dict(cell=54, name="fungi", palette=pal, rows=rows_of(g)))

# ------------------------------------------------------------ output
def rust_line(t):
    return '    TileSrc { cell: %d, name: "%s", palette: "%s", rows: "%s", wrap: false },' % (
        t['cell'], t['name'], ' '.join(t['palette']), t['rows'])


with open(os.path.join(HERE, 'amazon_tiles.rs.txt'), 'w') as f:
    for t in tiles:
        assert len(t['rows']) == 256, t['name']
        f.write(rust_line(t) + '\n')

S = 10
cols = 6
rows_n = (len(tiles) + cols - 1) // cols
W = cols * (16 * S + 8) + 8
H = rows_n * (16 * S + 8) + 8
sheet = Image.new('RGB', (W, H), (70, 96, 70))
for i, t in enumerate(tiles):
    lut = [tuple(int(p[j:j + 2], 16) for j in (0, 2, 4)) for p in t['palette']]
    ox = 8 + (i % cols) * (16 * S + 8)
    oy = 8 + (i // cols) * (16 * S + 8)
    for y in range(16):
        for x in range(16):
            ch = t['rows'][y * 16 + x]
            col = (40 + 14 * ((x + y) % 2), 56, 40) if ch == '.' else lut[int(ch, 36)]
            for dy in range(S):
                for dx in range(S):
                    sheet.putpixel((ox + x * S + dx, oy + y * S + dy), col)
sheet.save(os.path.join(HERE, 'amazon_tiles_preview.png'))
print('ok', len(tiles), 'tiles')
