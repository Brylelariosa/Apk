#pragma once
// ============================================================================
// HZCM v13 — DebugOverlay.h
//
// Responsibilities:
//   • WorldDebugStats struct — plain POD snapshot filled by World::getDebugStats()
//   • DebugOverlay class     — visibility toggle + thread-safe stats cache
//
// Rendering split:
//   • GL bar overlay (thermal/RD coloured bars) lives in Renderer::renderDebugOverlay()
//   • Text overlay (the full stats panel) is rendered on the Android/Java layer.
//     Java polls nativeGetDebugStats() every 250 ms via a Handler and displays
//     the result in a monospace TextView overlay above the GL surface.
//
// Design notes:
//   • WorldDebugStats has NO includes from the rest of the engine — zero
//     circular-dependency risk even though World.h includes this header.
//   • The stats cache uses a std::mutex rather than per-field atomics:
//     simple, correct, and the 250 ms Java poll interval means lock contention
//     is negligible.
//   • renderDebugUI() is a stub — actual rendering is delegated to Renderer.
// ============================================================================
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>

// ── Stats snapshot ────────────────────────────────────────────────────────────
// All values are approximate/best-effort; no locking guarantees are made
// across fields (the struct is filled in a single GL-thread call and read
// on the JNI/Java thread with coarse mutex protection in DebugOverlay).
struct WorldDebugStats {
    // Rendering
    float    fps              = 60.f;
    int      requestedRD      = 0;
    int      effectiveRadius  = 0;
    int      visibleDraws     = 0;

    // Streaming
    int      loadedChunks     = 0;
    int      pendingChunks    = 0;   // unsubmitted candidates remaining
    int      submittedChunks  = 0;
    int      uploadBacklog    = 0;
    int      workerCount      = 0;

    // Chunk completeness diagnostics (v14)
    int      totalInRadius         = 0;  // total positions in load radius
    int      missingChunks         = 0;  // positions absent from m_chunks
    int      candidateRebuildCount = 0;  // how many times candidate list rebuilt
    int      strandedChunks        = 0;  // chunks re-queued by stranded-recovery
    int      candidateIdx          = 0;  // current position in candidate list

    // Thermal
    char     thermalState[12] = "COOL";   // "COOL" | "WARM" | "HOT" | "CRITICAL"
    float    thermalScale     = 1.f;      // radiusScale() value (informational only)
    float    thermalPressure  = 0.f;      // [0..1]
    float    thermalEmaMs     = 16.7f;    // EMA frame time in ms

    // Job queue
    uint32_t queueSize        = 0;
    uint32_t queueFree        = 0;
    uint32_t queueCapacity    = 0;
    int      retryQueueSize   = 0;
    int      overflowTotal    = 0;

    // Memory (MegaBuffer)
    uint32_t megaUsedFaces    = 0;
    uint32_t megaTotalFaces   = 0;

    // Position
    int      camCX            = 0;
    int      camCZ            = 0;
};

// ── DebugOverlay ──────────────────────────────────────────────────────────────
class DebugOverlay {
public:
    DebugOverlay() = default;

    // ── Visibility state (GL-thread only; no atomic needed) ───────────────────
    bool debugVisible         = false;
    bool advancedDebugVisible = false;

    // toggleDebug() — tap on DBG button.
    // Hides advanced panel automatically when the main panel closes.
    void toggleDebug() {
        debugVisible = !debugVisible;
        if (!debugVisible) advancedDebugVisible = false;
    }

    // toggleAdvanced() — long-press on DBG button (or separate action).
    // Auto-opens the basic panel if it was closed.
    void toggleAdvanced() {
        if (!debugVisible) debugVisible = true;
        advancedDebugVisible = !advancedDebugVisible;
    }

    bool isVisible()  const { return debugVisible;         }
    bool isAdvanced() const { return advancedDebugVisible; }

    // ── Stats cache ───────────────────────────────────────────────────────────
    // updateDebugStats() — called from GL thread once per frame when visible.
    // getStats()         — called from JNI/Java thread every 250 ms.
    // A plain std::mutex is sufficient; contention at 250 ms polling rate is
    // negligible even on a heavily loaded GL thread.
    void updateDebugStats(const WorldDebugStats& s) {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        m_stats = s;
    }

    WorldDebugStats getStats() const {
        std::lock_guard<std::mutex> lk(m_statsMtx);
        return m_stats;
    }

    // ── renderDebugUI() ───────────────────────────────────────────────────────
    // Stub — satisfies the spec's class-structure requirement.
    // The coloured-bar GL overlay is rendered by Renderer::renderDebugOverlay().
    // The text panel overlay is rendered by the Android Java layer.
    void renderDebugUI() { /* delegated to Renderer + Java */ }

private:
    mutable std::mutex m_statsMtx;
    WorldDebugStats    m_stats{};
};
