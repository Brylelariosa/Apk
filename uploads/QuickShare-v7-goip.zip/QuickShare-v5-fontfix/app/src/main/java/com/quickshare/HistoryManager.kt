package com.quickshare

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object HistoryManager {

    private const val FILE = "qs_history.json"
    private const val MAX  = 50

    fun add(ctx: Context, record: TransferRecord) {
        val list = getAll(ctx).toMutableList()
        list.add(0, record)
        if (list.size > MAX) list.subList(MAX, list.size).clear()
        save(ctx, list)
    }

    fun getAll(ctx: Context): List<TransferRecord> {
        val file = File(ctx.filesDir, FILE)
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText(Charsets.UTF_8))
            (0 until arr.length()).map { i ->
                val obj      = arr.getJSONObject(i)
                val namesArr = obj.getJSONArray("fileNames")
                TransferRecord(
                    id         = obj.getString("id"),
                    timestamp  = obj.getLong("timestamp"),
                    direction  = obj.getString("direction"),
                    fileNames  = (0 until namesArr.length()).map { namesArr.getString(it) },
                    totalBytes = obj.getLong("totalBytes"),
                    peerName   = obj.getString("peerName"),
                    status     = obj.getString("status")
                )
            }
        } catch (_: Exception) { emptyList() }
    }

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    private fun save(ctx: Context, list: List<TransferRecord>) {
        val arr = JSONArray()
        list.forEach { r ->
            val namesArr = JSONArray().also { a -> r.fileNames.forEach(a::put) }
            arr.put(JSONObject().apply {
                put("id",         r.id)
                put("timestamp",  r.timestamp)
                put("direction",  r.direction)
                put("fileNames",  namesArr)
                put("totalBytes", r.totalBytes)
                put("peerName",   r.peerName)
                put("status",     r.status)
            })
        }
        File(ctx.filesDir, FILE).writeText(arr.toString(), Charsets.UTF_8)
    }
}
