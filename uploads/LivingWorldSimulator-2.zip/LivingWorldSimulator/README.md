# Living World Simulator 2.0 (Rust engine)

A procedurally generated planet that is simulated, not painted: plate tectonics build the crust, erosion carves it,
a coupled seasonal climate (sun, pressure belts, winds, ocean gyres, moisture, rain shadows, snow, ice) drives rivers,
lakes, soils and biomes. Everything is rendered live as a streamed, level-of-detail globe from orbit down to the ground.

## Architecture

| Part | Language | Where |
|---|---|---|
| Simulation (noise, tectonics, terrain, climate, hydrology, ecology, "Why?" explanations) | Rust | `rust/src/*.rs` |
| Renderer (OpenGL ES 3, chunk streaming, LOD, clouds, atmosphere), camera, gestures, sim thread | Rust | `render.rs`, `camera.rs`, `app.rs` |
| JNI bridge | Rust (hand-written, no crates) | `jni_bridge.rs` |
| Android shell (window, widgets, dialogs) | Kotlin | `app/src/main/java/...` (3 small files) |

The Rust crate has **no external dependencies**. The CI workflow builds it with `cargo-ndk` (ABIs from `rustAbis=` in
`gradle.properties`) into `app/src/main/jniLibs`, and Gradle only packages the result.

The shared library is named `libvoxelsandbox.so` because the workflow's Rust step looks for exactly that file name.
If you ever want a different name, change both `[lib] name` in `rust/Cargo.toml` + `System.loadLibrary` in `Native.kt`
and the `libvoxelsandbox.so` check in the workflow.

## Controls

* one finger drag - grab the globe (the surface under the finger follows it; slower when the planet is small on screen)
* release - gentle inertia, capped and quickly fading
* pinch - zoom, two-finger twist - rotate the view, two-finger vertical drag - tilt
* double tap - glide to that point and zoom in (zooms back out when already close)
* Reset view, Sun +6h, Step, speed (1 hour/s ... 1 million years/s), SIMULATE/PAUSE, layers (DEBUG), "Why?" explains the point under the crosshair

## What changed from 1.x

* **Net / perforated look on the planet fixed.** The cloud shell was a 64x32 low-poly sphere: between its vertices the flat
  triangles dip a few kilometres *below* the surface, so the depth test cut a regular lattice of holes into it. The shell is now a
  denser cube-sphere whose vertices are pushed outward so the faceted surface can never sink below the true sphere.
* **Clouds follow the simulation.** Cloud opacity is generated from the simulated cloud cover with a soft threshold on
  domain-warped noise: mean coverage is ~59% with clear gaps (the old mapping was ~88% opaque, a white ball).
* **Swipe rotation fixed.** The old pan moved the globe a fixed distance per pixel (huge when zoomed out, so one swipe could
  spin the planet 300 degrees) and flings carried it much further. Now it is a true "grab the globe" drag with altitude-aware
  gain and a capped, quickly damped inertia.
* **Water budget closes.** Evaporation exceeded precipitation by ~22%; the residual is now returned as ocean rain each month
  (land hydrology and biomes are untouched). Debug panel shows the remaining error (~0%).
* **Smooth simulation time.** Time advances continuously (not one jump per second), keeps accumulating while a slow update runs,
  and slow ecosystem updates no longer block the screen with a loading overlay.
* **Faster generation.** Terrain, climate downscaling, soils/biomes and resources run on all cores (deterministic: the same seed
  gives the same planet on every device and thread count).
* Crash/diagnostic log: Rust panics and Java exceptions are written to `files/crash.log` and shown (with a Copy button) on the next
  launch, since device logs are not readable without a PC.

## Tests

`cargo test --lib` (run by the CI workflow, non-blocking) checks the deterministic math, noise, grid lookups, seed parsing and camera.
