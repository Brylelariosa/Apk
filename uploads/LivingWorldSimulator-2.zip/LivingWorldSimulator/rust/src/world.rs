//! World = the whole planet simulation. Heavy work (generation, geological steps) runs on the simulation thread
//! and publishes immutable snapshots; renderers/inspectors read snapshots on any thread without locking the data.

use crate::climate::*;
use crate::ecology::*;
use crate::grid::*;
use crate::mathx::*;
use crate::noise::Noise;
use crate::params::*;
use crate::tectonics::*;
use crate::terrain::*;
use crate::world_data::*;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};

pub fn lk<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

#[derive(Default)]
pub struct EcoPack {
    pub h: HydroData,
    pub e: EcoData,
}

#[derive(Default)]
pub struct ClimatePack {
    pub sl: ClimateSlices,
    pub st: ClimateStatic,
}

pub struct StaticData {
    pub pp: PlanetParams,
    pub dv: Derived,
    pub seed: u64,
    pub seed_str: String,
    pub fg: Arc<CubeGrid>,
    pub cg: Arc<CubeGrid>,
    pub noise: Noise,
    pub tect: Tectonics,
    pub tp: Arc<TerrainData>,
    pub ep: Arc<EcoPack>,
    pub cp: Arc<ClimatePack>,
    pub tect_time_myr: f64,
    pub id: u32,
}
impl StaticData {
    pub fn t(&self) -> &TerrainData {
        &self.tp
    }
    pub fn h(&self) -> &HydroData {
        &self.ep.h
    }
    pub fn e(&self) -> &EcoData {
        &self.ep.e
    }
    pub fn sl(&self) -> &ClimateSlices {
        &self.cp.sl
    }
    pub fn st(&self) -> &ClimateStatic {
        &self.cp.st
    }
}

#[derive(Default)]
pub struct DynamicData {
    pub time_years: f64,
    pub frac_year: f64,
    pub day_frac: f64,
    pub decl_deg: f64,
    pub sun_dir: V3,
    // current-date coarse fields (interpolated between monthly slices)
    pub ta: Vec<f32>,
    pub ts: Vec<f32>,
    pub precip: Vec<f32>,
    pub wvap: Vec<f32>,
    pub cloud: Vec<f32>,
    pub snow: Vec<f32>,
    pub ice: Vec<f32>,
    pub wu: Vec<f32>,
    pub wv: Vec<f32>,
    pub pres: Vec<f32>,
    pub glacier: Vec<f32>,
    pub global_t: f64,
}

#[derive(Clone)]
pub struct View {
    pub s: Arc<StaticData>,
    pub d: Arc<DynamicData>,
}

#[derive(Clone, Copy, Default, Debug)]
pub struct Timings {
    pub gen_total_ms: f64,
    pub terrain_ms: f64,
    pub climate_ms: f64,
    pub eco_ms: f64,
    pub step_ms: f64,
    pub climate_step_ms: f64,
    pub river_ms: f64,
}

struct Published {
    s: Option<Arc<StaticData>>,
    d: Option<Arc<DynamicData>>,
    tm: Timings,
    day_phase: f64,
    time: f64,
}

struct SimState {
    climate: Option<Box<Climate>>,
    veg: Vec<f32>,
    soil_cap: Vec<f32>,
    glacier: Vec<f32>,
    since_slow: f64,
}

pub struct World {
    publ: Mutex<Published>,
    sim: Mutex<SimState>,
    gen: AtomicU32,
}

static GRIDS: Mutex<Option<(Arc<CubeGrid>, Arc<CubeGrid>)>> = Mutex::new(None);

fn get_grids() -> (Arc<CubeGrid>, Arc<CubeGrid>) {
    let mut g = lk(&GRIDS);
    if g.is_none() {
        let mut fine = CubeGrid::default();
        fine.build(NT, false);
        let mut coarse = CubeGrid::default();
        coarse.build(NC, true);
        *g = Some((Arc::new(fine), Arc::new(coarse)));
    }
    match g.as_ref() {
        Some((f, c)) => (Arc::clone(f), Arc::clone(c)),
        None => unreachable!(),
    }
}

/// month slices -> date: returns (m0, m1, weight of m1)
pub fn slice_weights(fy: f64) -> (usize, usize, f32) {
    let ns = NSLICE as i64;
    let u = fy * (NSLICE as f64) - 0.5;
    let fl = u.floor();
    let w = (u - fl) as f32;
    let i = fl as i64;
    let m0 = (((i % ns) + ns) % ns) as usize;
    let m1 = (m0 + 1) % NSLICE;
    (m0, m1, w)
}

pub fn parse_seed(s: &str) -> u64 {
    let tail: &str = match s.rfind('-') {
        Some(p) => &s[p + 1..],
        None => s,
    };
    let mut hex = !tail.is_empty() && tail.len() <= 16;
    let mut v: u64 = 0;
    for ch in tail.chars() {
        let d: u64 = if ch >= '0' && ch <= '9' {
            (ch as u64) - ('0' as u64)
        } else if ch >= 'a' && ch <= 'f' {
            10 + (ch as u64) - ('a' as u64)
        } else if ch >= 'A' && ch <= 'F' {
            10 + (ch as u64) - ('A' as u64)
        } else {
            hex = false;
            break;
        };
        v = (v << 4) | d;
    }
    if hex {
        return mix64(v ^ 0x9E3779B97F4A7C15u64);
    }
    hash_str(s)
}

impl World {
    pub fn new() -> World {
        World {
            publ: Mutex::new(Published { s: None, d: None, tm: Timings::default(), day_phase: 0.5, time: 0.0 }),
            sim: Mutex::new(SimState { climate: None, veg: Vec::new(), soil_cap: Vec::new(), glacier: Vec::new(), since_slow: 0.0 }),
            gen: AtomicU32::new(0),
        }
    }

    pub fn view(&self) -> Option<View> {
        let p = lk(&self.publ);
        match (&p.s, &p.d) {
            (Some(s), Some(d)) => Some(View { s: Arc::clone(s), d: Arc::clone(d) }),
            _ => None,
        }
    }

    pub fn timings(&self) -> Timings {
        lk(&self.publ).tm
    }

    pub fn generation(&self) -> u32 {
        self.gen.load(Ordering::SeqCst)
    }

    pub fn time_years(&self) -> f64 {
        lk(&self.publ).time
    }

    pub fn generate(&self, seed: &str, pp_in: &PlanetParams, progress: Progress) {
        let mut pp = pp_in.clone();
        pp.sanitize();
        {
            let mut sim = lk(&self.sim);
            self.rebuild(&mut sim, &pp, parse_seed(seed), seed, 0.0, false, progress);
            sim.since_slow = 0.0;
        }
        {
            let mut p = lk(&self.publ);
            p.time = 0.0;
            p.day_phase = 0.5; // new planets start at local noon on the prime meridian
        }
        let s = lk(&self.publ).s.clone();
        if let Some(s) = s {
            self.publish_dynamic(&s, 0.0);
        }
    }

    fn rebuild(&self, sim: &mut SimState, pp: &PlanetParams, seed: u64, seed_str: &str, tect_myr: f64, warm: bool, progress: Progress) {
        let total = Timer::new();
        let dv = derive(pp);
        let (fg, cg) = get_grids();
        let noise = Noise::new(seed.wrapping_mul(7919u64).wrapping_add(13u64));
        let mut tect = Tectonics::new(&noise);
        tect.init(seed, pp, &dv, &noise);

        let mut t = Timer::new();
        let mut td = TerrainData::default();
        {
            let pf = |s: &str, f: f32| progress(s, 0.0 + 0.30 * clampv(f / 0.85, 0.0, 1.0));
            generate_terrain(pp, &dv, seed, &noise, &tect, &fg, tect_myr, &mut td, &pf);
        }
        let tp = Arc::new(td);
        let terrain_ms = t.ms();

        t.reset();
        let mut cl = Climate::new(pp, &dv, Arc::clone(&cg), Arc::clone(&fg), Arc::clone(&tp));
        if warm {
            if let Some(old) = sim.climate.as_ref() {
                cl.warm_start_from(old);
            }
        }
        if warm && sim.veg.len() == cg.count {
            cl.set_surface(&sim.veg, &sim.soil_cap, &sim.glacier);
        }
        {
            let pf = |s: &str, f: f32| progress(s, 0.30 + 0.22 * clampv(f, 0.0, 1.0));
            cl.run(3, &pf);
        }
        let mut climate_ms = t.ms();

        t.reset();
        let mut eco_h = HydroData::default();
        let mut eco_e = EcoData::default();
        let mut veg: Vec<f32> = Vec::new();
        let mut cap: Vec<f32> = Vec::new();
        let mut gl: Vec<f32> = Vec::new();
        {
            let pf = |s: &str, f: f32| progress(s, 0.52 + 0.10 * clampv(f, 0.0, 1.0));
            build_hydro_eco(pp, &dv, &noise, &cg, &fg, &tp, &cl.sl, &cl.st, cl.oro_vec(), &mut eco_h, &mut eco_e, &mut veg, &mut cap, &mut gl, &pf);
        }
        cl.set_surface(&veg, &cap, &gl);
        let mut eco_ms = t.ms();

        t.reset();
        {
            let pf = |s: &str, f: f32| progress(s, 0.62 + 0.20 * clampv(f, 0.0, 1.0));
            cl.run(2, &pf);
        }
        climate_ms += t.ms();
        t.reset();
        {
            let pf = |s: &str, f: f32| progress(s, 0.82 + 0.18 * clampv(f, 0.0, 1.0));
            build_hydro_eco(pp, &dv, &noise, &cg, &fg, &tp, &cl.sl, &cl.st, cl.oro_vec(), &mut eco_h, &mut eco_e, &mut veg, &mut cap, &mut gl, &pf);
        }
        eco_ms += t.ms();

        let cp = ClimatePack { sl: std::mem::take(&mut cl.sl), st: cl.st.clone() };
        let cstep = cl.ms_per_step;
        let sd = StaticData {
            pp: pp.clone(),
            dv,
            seed,
            seed_str: seed_str.to_string(),
            fg: Arc::clone(&fg),
            cg: Arc::clone(&cg),
            noise,
            tect,
            tp,
            ep: Arc::new(EcoPack { h: eco_h, e: eco_e }),
            cp: Arc::new(cp),
            tect_time_myr: tect_myr,
            id: self.gen.fetch_add(1, Ordering::SeqCst) + 1,
        };
        sim.climate = Some(Box::new(cl));
        sim.veg = veg;
        sim.soil_cap = cap;
        sim.glacier = gl;
        {
            let mut p = lk(&self.publ);
            p.s = Some(Arc::new(sd));
            p.tm.terrain_ms = terrain_ms;
            p.tm.climate_ms = climate_ms;
            p.tm.eco_ms = eco_ms;
            p.tm.climate_step_ms = cstep;
            p.tm.gen_total_ms = total.ms();
            p.tm.river_ms = eco_ms * 0.4;
        }
        progress("Ready", 1.0);
    }

    fn publish_dynamic(&self, s: &Arc<StaticData>, time_years: f64) {
        let n = s.cg.count;
        let day_phase = lk(&self.publ).day_phase;
        let mut d = DynamicData::default();
        d.time_years = time_years;
        d.frac_year = time_years - time_years.floor();
        let days = time_years * s.dv.solar_days_per_year;
        let dd = days + day_phase;
        d.day_frac = dd - dd.floor();
        let (m0, m1, w) = slice_weights(d.frac_year);
        let sl = s.sl();
        let interp = |src: &Vec<f32>| -> Vec<f32> {
            let mut dst = vec![0f32; n];
            let a = &src[m0 * n..m0 * n + n];
            let b = &src[m1 * n..m1 * n + n];
            for c in 0..n {
                dst[c] = a[c] + (b[c] - a[c]) * w;
            }
            dst
        };
        d.ta = interp(&sl.ta);
        d.ts = interp(&sl.ts);
        d.precip = interp(&sl.precip);
        d.wvap = interp(&sl.wvap);
        d.cloud = interp(&sl.cloud);
        d.snow = interp(&sl.snow);
        d.ice = interp(&sl.ice);
        d.wu = interp(&sl.wu);
        d.wv = interp(&sl.wv);
        d.pres = interp(&sl.pres);
        d.glacier = sl.glacier.clone();
        let (decl, _rinv) = solar_geometry(&s.dv, d.frac_year);
        d.decl_deg = decl * RAD2DEG;
        d.sun_dir = from_lat_lon(decl, -TAU * (d.day_frac - 0.5));
        let mut sa = 0.0f64;
        let mut st = 0.0f64;
        for c in 0..n {
            let a = s.cg.area[c] as f64;
            sa += a;
            st += a * (d.ta[c] as f64);
        }
        d.global_t = st / sa;
        lk(&self.publ).d = Some(Arc::new(d));
    }

    pub fn add_day_hours(&self, hours: f64) {
        let s: Option<Arc<StaticData>>;
        let t: f64;
        {
            let mut p = lk(&self.publ);
            s = p.s.clone();
            let sd = match &s {
                Some(x) => Arc::clone(x),
                None => return,
            };
            p.day_phase += hours / sd.dv.day_hours;
            p.day_phase -= p.day_phase.floor();
            t = p.time;
        }
        if let Some(s) = s {
            self.publish_dynamic(&s, t);
        }
    }

    /// advance by `years` of simulated time; handles every scale from days to millions of years
    pub fn advance(&self, years: f64, progress: Progress) {
        let s: Arc<StaticData> = match lk(&self.publ).s.clone() {
            Some(x) => x,
            None => return,
        };
        if years <= 0.0 {
            return;
        }
        let t0 = Timer::new();
        let time_now: f64;
        {
            let mut p = lk(&self.publ);
            p.time += years;
            let spy = s.dv.solar_days_per_year;
            if years * spy >= 0.25 {
                // coarse steps advance by whole solar days so the time of day (and the terminator) stays put
                p.time = (p.time * spy + 0.5).floor() / spy;
            }
            time_now = p.time;
        }
        if years >= 4.0e5 {
            // geological step: plates move, crust is carried, mountains rise and erode, everything downstream is recomputed
            {
                let mut sim = lk(&self.sim);
                self.rebuild(&mut sim, &s.pp, s.seed, &s.seed_str, s.tect_time_myr + years / 1.0e6, true, progress);
                sim.since_slow = 0.0;
            }
            let ns = lk(&self.publ).s.clone();
            if let Some(ns) = ns {
                self.publish_dynamic(&ns, time_now);
            }
        } else {
            let mut do_slow = false;
            {
                let mut sim = lk(&self.sim);
                sim.since_slow += years;
                if sim.since_slow >= 100.0 && sim.climate.is_some() {
                    sim.since_slow = 0.0;
                    do_slow = true;
                }
            }
            if do_slow {
                self.slow_update(&s, progress);
            }
            let ns = lk(&self.publ).s.clone();
            if let Some(ns) = ns {
                self.publish_dynamic(&ns, time_now);
            }
        }
        lk(&self.publ).tm.step_ms = t0.ms();
    }

    /// slow coupled update: vegetation, soils and glaciers adjust and feed back to climate
    fn slow_update(&self, s: &Arc<StaticData>, progress: Progress) {
        let mut sim = lk(&self.sim);
        let mut cl = match sim.climate.take() {
            Some(c) => c,
            None => return,
        };
        {
            let veg = sim.veg.clone();
            let cap = sim.soil_cap.clone();
            let gl = sim.glacier.clone();
            cl.set_surface(&veg, &cap, &gl);
        }
        {
            let pf = |st: &str, f: f32| progress(st, 0.0 + 0.5 * clampv(f, 0.0, 1.0));
            cl.run(2, &pf);
        }
        let mut eco_h = HydroData::default();
        let mut eco_e = EcoData::default();
        let mut veg: Vec<f32> = Vec::new();
        let mut cap: Vec<f32> = Vec::new();
        let mut gl: Vec<f32> = Vec::new();
        {
            let pf = |st: &str, f: f32| progress(st, 0.5 + 0.5 * clampv(f, 0.0, 1.0));
            build_hydro_eco(
                &s.pp, &s.dv, &s.noise, &s.cg, &s.fg, &s.tp, &cl.sl, &cl.st, cl.oro_vec(), &mut eco_h, &mut eco_e, &mut veg, &mut cap, &mut gl, &pf,
            );
        }
        let cp = ClimatePack { sl: std::mem::take(&mut cl.sl), st: cl.st.clone() };
        let sd2 = StaticData {
            pp: s.pp.clone(),
            dv: s.dv.clone(),
            seed: s.seed,
            seed_str: s.seed_str.clone(),
            fg: Arc::clone(&s.fg),
            cg: Arc::clone(&s.cg),
            noise: s.noise.clone(),
            tect: s.tect.clone(),
            tp: Arc::clone(&s.tp),
            ep: Arc::new(EcoPack { h: eco_h, e: eco_e }),
            cp: Arc::new(cp),
            tect_time_myr: s.tect_time_myr,
            id: self.gen.fetch_add(1, Ordering::SeqCst) + 1,
        };
        sim.veg = veg;
        sim.soil_cap = cap;
        sim.glacier = gl;
        sim.climate = Some(cl);
        lk(&self.publ).s = Some(Arc::new(sd2));
    }
}
