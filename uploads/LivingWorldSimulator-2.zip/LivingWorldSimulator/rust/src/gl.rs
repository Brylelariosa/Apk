//! Minimal OpenGL ES 3.0 bindings (no external crates). On Android these link against libGLESv3;
//! on any other target they are harmless no-ops so the simulation code can be unit-tested on a PC.

#![allow(non_snake_case)]

use std::ffi::c_void;
use std::os::raw::c_char;

pub const GL_DEPTH_TEST: u32 = 0x0B71;
pub const GL_CULL_FACE: u32 = 0x0B44;
pub const GL_BLEND: u32 = 0x0BE2;
pub const GL_COLOR_BUFFER_BIT: u32 = 0x4000;
pub const GL_DEPTH_BUFFER_BIT: u32 = 0x0100;
pub const GL_TRIANGLES: u32 = 0x0004;
pub const GL_POINTS: u32 = 0x0000;
pub const GL_UNSIGNED_SHORT: u32 = 0x1403;
pub const GL_UNSIGNED_BYTE: u32 = 0x1401;
pub const GL_FLOAT: u32 = 0x1406;
pub const GL_ARRAY_BUFFER: u32 = 0x8892;
pub const GL_ELEMENT_ARRAY_BUFFER: u32 = 0x8893;
pub const GL_STATIC_DRAW: u32 = 0x88E4;
pub const GL_VERTEX_SHADER: u32 = 0x8B31;
pub const GL_FRAGMENT_SHADER: u32 = 0x8B30;
pub const GL_COMPILE_STATUS: u32 = 0x8B81;
pub const GL_LINK_STATUS: u32 = 0x8B82;
pub const GL_INFO_LOG_LENGTH: u32 = 0x8B84;
pub const GL_TEXTURE_2D: u32 = 0x0DE1;
pub const GL_TEXTURE0: u32 = 0x84C0;
pub const GL_TEXTURE1: u32 = 0x84C1;
pub const GL_TEXTURE_MIN_FILTER: u32 = 0x2801;
pub const GL_TEXTURE_MAG_FILTER: u32 = 0x2800;
pub const GL_TEXTURE_WRAP_S: u32 = 0x2802;
pub const GL_TEXTURE_WRAP_T: u32 = 0x2803;
pub const GL_LINEAR: u32 = 0x2601;
pub const GL_LINEAR_MIPMAP_LINEAR: u32 = 0x2703;
pub const GL_CLAMP_TO_EDGE: u32 = 0x812F;
pub const GL_REPEAT: u32 = 0x2901;
pub const GL_UNPACK_ALIGNMENT: u32 = 0x0CF5;
pub const GL_RGBA: u32 = 0x1908;
pub const GL_RGBA8: u32 = 0x8058;
pub const GL_R8: u32 = 0x8229;
pub const GL_RED: u32 = 0x1903;
pub const GL_RG8: u32 = 0x822B;
pub const GL_RG: u32 = 0x8227;
pub const GL_SRC_ALPHA: u32 = 0x0302;
pub const GL_ONE_MINUS_SRC_ALPHA: u32 = 0x0303;
pub const GL_ONE: u32 = 1;
pub const GL_RENDERER: u32 = 0x1F01;
pub const GL_VERSION: u32 = 0x1F02;
pub const GL_LEQUAL: u32 = 0x0203;

macro_rules! gl_api {
    ($( fn $name:ident($($arg:ident : $ty:ty),*) $(-> $ret:ty)? ; )*) => {
        #[cfg(target_os = "android")]
        #[link(name = "GLESv3")]
        extern "C" {
            $( pub fn $name($($arg: $ty),*) $(-> $ret)?; )*
        }
        $(
            #[cfg(not(target_os = "android"))]
            #[allow(unused_variables)]
            pub unsafe fn $name($($arg: $ty),*) $(-> $ret)? { Default::default() }
        )*
    };
}

gl_api! {
    fn glClearColor(r: f32, g: f32, b: f32, a: f32);
    fn glClear(mask: u32);
    fn glViewport(x: i32, y: i32, w: i32, h: i32);
    fn glEnable(cap: u32);
    fn glDisable(cap: u32);
    fn glDepthMask(flag: u8);
    fn glDepthFunc(func: u32);
    fn glBlendFunc(sfactor: u32, dfactor: u32);
    fn glCreateShader(ty: u32) -> u32;
    fn glShaderSource(shader: u32, count: i32, string: *const *const c_char, length: *const i32);
    fn glCompileShader(shader: u32);
    fn glGetShaderiv(shader: u32, pname: u32, params: *mut i32);
    fn glGetShaderInfoLog(shader: u32, buf_size: i32, length: *mut i32, info_log: *mut c_char);
    fn glDeleteShader(shader: u32);
    fn glCreateProgram() -> u32;
    fn glAttachShader(program: u32, shader: u32);
    fn glLinkProgram(program: u32);
    fn glGetProgramiv(program: u32, pname: u32, params: *mut i32);
    fn glGetProgramInfoLog(program: u32, buf_size: i32, length: *mut i32, info_log: *mut c_char);
    fn glDeleteProgram(program: u32);
    fn glUseProgram(program: u32);
    fn glGetUniformLocation(program: u32, name: *const c_char) -> i32;
    fn glUniform1f(loc: i32, v0: f32);
    fn glUniform1i(loc: i32, v0: i32);
    fn glUniform3f(loc: i32, v0: f32, v1: f32, v2: f32);
    fn glUniformMatrix4fv(loc: i32, count: i32, transpose: u8, value: *const f32);
    fn glGenBuffers(n: i32, buffers: *mut u32);
    fn glBindBuffer(target: u32, buffer: u32);
    fn glBufferData(target: u32, size: isize, data: *const c_void, usage: u32);
    fn glDeleteBuffers(n: i32, buffers: *const u32);
    fn glEnableVertexAttribArray(index: u32);
    fn glDisableVertexAttribArray(index: u32);
    fn glVertexAttribPointer(index: u32, size: i32, ty: u32, normalized: u8, stride: i32, pointer: *const c_void);
    fn glDrawElements(mode: u32, count: i32, ty: u32, indices: *const c_void);
    fn glDrawArrays(mode: u32, first: i32, count: i32);
    fn glGenVertexArrays(n: i32, arrays: *mut u32);
    fn glBindVertexArray(array: u32);
    fn glDeleteVertexArrays(n: i32, arrays: *const u32);
    fn glGenTextures(n: i32, textures: *mut u32);
    fn glBindTexture(target: u32, texture: u32);
    fn glTexParameteri(target: u32, pname: u32, param: i32);
    fn glTexImage2D(target: u32, level: i32, internalformat: i32, width: i32, height: i32, border: i32, format: u32, ty: u32, pixels: *const c_void);
    fn glGenerateMipmap(target: u32);
    fn glDeleteTextures(n: i32, textures: *const u32);
    fn glActiveTexture(texture: u32);
    fn glPixelStorei(pname: u32, param: i32);
}

#[cfg(target_os = "android")]
extern "C" {
    pub fn glGetString(name: u32) -> *const u8;
}
#[cfg(not(target_os = "android"))]
pub unsafe fn glGetString(_name: u32) -> *const u8 {
    std::ptr::null()
}

pub fn get_string(name: u32) -> String {
    unsafe {
        let p = glGetString(name);
        if p.is_null() {
            return String::from("?");
        }
        let mut len = 0usize;
        while *p.add(len) != 0 && len < 256 {
            len += 1;
        }
        let bytes = std::slice::from_raw_parts(p, len);
        String::from_utf8_lossy(bytes).to_string()
    }
}

// ---------------------------------------------------------------------------------------------------
// logging
// ---------------------------------------------------------------------------------------------------
#[cfg(target_os = "android")]
#[link(name = "log")]
extern "C" {
    fn __android_log_write(prio: i32, tag: *const c_char, text: *const c_char) -> i32;
}

pub fn log(msg: &str) {
    #[cfg(target_os = "android")]
    {
        let clean: String = msg.chars().map(|c| if c == '\0' { ' ' } else { c }).collect();
        if let (Ok(tag), Ok(text)) = (std::ffi::CString::new("LivingWorld"), std::ffi::CString::new(clean)) {
            unsafe {
                __android_log_write(4, tag.as_ptr(), text.as_ptr());
            }
        }
    }
    #[cfg(not(target_os = "android"))]
    {
        eprintln!("[LivingWorld] {}", msg);
    }
}

// ---------------------------------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------------------------------
pub fn compile_program(vs: &str, fs: &str) -> Result<u32, String> {
    unsafe {
        let v = compile_shader(GL_VERTEX_SHADER, vs)?;
        let f = match compile_shader(GL_FRAGMENT_SHADER, fs) {
            Ok(f) => f,
            Err(e) => {
                glDeleteShader(v);
                return Err(e);
            }
        };
        let p = glCreateProgram();
        glAttachShader(p, v);
        glAttachShader(p, f);
        glLinkProgram(p);
        let mut ok = 0i32;
        glGetProgramiv(p, GL_LINK_STATUS, &mut ok);
        if ok == 0 {
            let mut buf = vec![0u8; 1024];
            let mut len = 0i32;
            glGetProgramInfoLog(p, 1024, &mut len, buf.as_mut_ptr() as *mut c_char);
            let l = if len > 0 && (len as usize) <= buf.len() { len as usize } else { 0 };
            let msg = String::from_utf8_lossy(&buf[..l]).to_string();
            glDeleteProgram(p);
            glDeleteShader(v);
            glDeleteShader(f);
            return Err(format!("link: {}", msg));
        }
        glDeleteShader(v);
        glDeleteShader(f);
        Ok(p)
    }
}

unsafe fn compile_shader(ty: u32, src: &str) -> Result<u32, String> {
    let s = glCreateShader(ty);
    let csrc = match std::ffi::CString::new(src) {
        Ok(c) => c,
        Err(_) => return Err(String::from("shader source contains NUL")),
    };
    let ptr = csrc.as_ptr();
    glShaderSource(s, 1, &ptr, std::ptr::null());
    glCompileShader(s);
    let mut ok = 0i32;
    glGetShaderiv(s, GL_COMPILE_STATUS, &mut ok);
    if ok == 0 {
        let mut buf = vec![0u8; 1024];
        let mut len = 0i32;
        glGetShaderInfoLog(s, 1024, &mut len, buf.as_mut_ptr() as *mut c_char);
        let l = if len > 0 && (len as usize) <= buf.len() { len as usize } else { 0 };
        let msg = String::from_utf8_lossy(&buf[..l]).to_string();
        glDeleteShader(s);
        return Err(format!("{}: {}", if ty == GL_VERTEX_SHADER { "vs" } else { "fs" }, msg));
    }
    Ok(s)
}

pub fn uniform_loc(prog: u32, name: &str) -> i32 {
    match std::ffi::CString::new(name) {
        Ok(c) => unsafe { glGetUniformLocation(prog, c.as_ptr()) },
        Err(_) => -1,
    }
}
