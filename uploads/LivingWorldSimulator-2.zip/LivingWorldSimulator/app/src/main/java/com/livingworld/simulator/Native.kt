package com.livingworld.simulator

/**
 * JNI bridge to the Rust engine (libvoxelsandbox.so; the library keeps that file name because the CI workflow
 * checks for it). Everything - simulation, terrain streaming, rendering, camera and gestures - lives in Rust.
 */
object Native {
    init {
        System.loadLibrary("voxelsandbox")
    }

    const val STATE_LEN = 56

    external fun nInit(filesDir: String)
    external fun nGenerate(seed: String, params: DoubleArray)
    external fun nSetRunning(on: Boolean)
    external fun nSetSpeed(yearsPerSecond: Double)
    external fun nStep(years: Double)
    external fun nShiftHours(hours: Double)
    external fun nSetLayer(layer: Int)
    external fun nResetView()
    external fun nDefaultParams(out: DoubleArray)
    external fun nSurfaceCreated()
    external fun nSurfaceChanged(w: Int, h: Int)
    external fun nDrawFrame()
    external fun nTouch(action: Int, n: Int, x0: Double, y0: Double, x1: Double, y1: Double, timeMs: Long)
    external fun nGetState(out: DoubleArray)
    external fun nString(which: Int): String
    external fun nTakeCrash(): String
}

/** Indices into the state array filled by Native.nGetState (must match app.rs). */
object S {
    const val READY = 0
    const val BUSY = 1
    const val SOFT = 2
    const val PROGRESS = 3
    const val ROOTS = 4
    const val RUNNING = 5
    const val EPOCH = 6
    const val INFO = 8
    const val FPS = 24
    const val FRAME_MS = 25
    const val VISIBLE = 26
    const val GPU_CHUNKS = 27
    const val QUEUED = 28
    const val ACTIVE = 29
    const val WORKERS = 30
    const val UPLOADS = 31
    const val TRIS = 32
    const val DRAWS = 33
    const val CAM_LAT = 34
    const val CAM_LON = 35
    const val CAM_ALT = 36
    const val TIMING = 38
    const val LAYER = 48
}

/** Debug layers, same order as the native layer constants. */
object Layers {
    val names = arrayOf(
        "Visual", "Elevation", "Temperature", "Rainfall", "Wind", "Pressure",
        "Rivers", "Tectonic plates", "Plate boundaries", "Biomes", "Soil fertility", "Ocean depth"
    )
}
