# Project Crystal ProGuard / R8 rules.

# Keep JNI-facing classes and members: their names/signatures are referenced
# by exact string from native code (jni_bridge.cpp) and must survive minification.
-keepclasseswithmembers class com.projectcrystal.app.core.native.NativeImageProcessor {
    native <methods>;
}
-keep class com.projectcrystal.app.core.native.AnalysisMapsNative { *; }
-keep class com.projectcrystal.app.core.native.RestorationMetricsNative { *; }
-keep class com.projectcrystal.app.core.model.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
