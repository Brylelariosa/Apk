package com.projectcrystal.app.data.export

enum class ExportFormat(val mimeType: String, val extension: String) {
    PNG("image/png", "png"),
    JPEG("image/jpeg", "jpg"),
    WEBP("image/webp", "webp"),
}

data class ExportOptions(
    val format: ExportFormat = ExportFormat.PNG,
    val quality: Int = 95,
    val filename: String = "crystal_${System.currentTimeMillis()}",
    val preserveMetadata: Boolean = true,
)
