package com.projectcrystal.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.gson.Gson
import com.projectcrystal.app.core.model.DiagnosticMap
import com.projectcrystal.app.core.model.ProcessingStats
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.core.model.RestorationResult
import com.projectcrystal.app.core.model.SpecialMode
import com.projectcrystal.app.core.native.NativeImageProcessor
import com.projectcrystal.app.core.native.RestorationMetricsNative
import com.projectcrystal.app.data.db.AppDatabase
import com.projectcrystal.app.data.db.HistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Single choke point between the UI layer and (a) the native restoration
 * engine, (b) on-disk image storage, and (c) the Room history table. Every
 * screen that touches a photo goes through here — ViewModels never call
 * [NativeImageProcessor] or [AppDatabase] directly, which is what keeps the
 * native/DB implementation details swappable without touching UI code.
 */
class ImageRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.historyDao()
    private val gson = Gson()

    private val cacheDir: File by lazy {
        File(context.cacheDir, "restoration_cache").apply { mkdirs() }
    }

    fun observeRecent(limit: Int = 12): Flow<List<HistoryEntity>> = dao.observeRecent(limit)
    fun observeAll(): Flow<List<HistoryEntity>> = dao.observeAll()
    fun observeFavorites(): Flow<List<HistoryEntity>> = dao.observeFavorites()

    /**
     * Decodes [uri] into an EXIF-orientation-corrected, immutable ARGB_8888
     * bitmap. Images above [MAX_PROCESSING_DIMENSION] on their long side are
     * downscaled first: the tile-based pipeline's memory footprint is
     * roughly proportional to (input + output + weight-accumulator) buffers
     * held at full resolution simultaneously, and an unbounded cap risks
     * OOM on the spec's 4GB-RAM device target. This is a deliberate,
     * documented ceiling rather than a true streaming/tiled-I/O pipeline.
     */
    suspend fun decodeForProcessing(uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        val longSide = maxOf(bounds.outWidth, bounds.outHeight)
        val sampleSize = if (longSide > MAX_PROCESSING_DIMENSION) {
            Integer.highestOneBit(longSide / MAX_PROCESSING_DIMENSION).coerceAtLeast(1)
        } else 1

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: error("Unable to decode image at $uri")

        val orientedBitmap = applyExifOrientation(context, uri, decoded)
        if (orientedBitmap.config != Bitmap.Config.ARGB_8888) {
            orientedBitmap.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            orientedBitmap
        }
    }

    /**
     * Runs the full native restoration pipeline and persists a history
     * entry. Returns the completed [RestorationResult]. Long-running; call
     * from a background dispatcher (this is exactly what
     * [com.projectcrystal.app.data.work.RestorationWorker] does).
     */
    suspend fun restore(
        sourceUri: Uri,
        params: RestorationParams,
        onProgress: (Float) -> Unit = {},
    ): RestorationResult = withContext(Dispatchers.Default) {
        val input = decodeForProcessing(sourceUri)
        onProgress(0.1f)

        val output = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
        val metrics: RestorationMetricsNative? = NativeImageProcessor.processImage(
            input, output,
            NativeImageProcessor.packParams(params),
            params.specialMode.nativeValue,
            params.conservativeMode,
            MAP_MAX_DIMENSION,
        )
        onProgress(0.85f)
        checkNotNull(metrics) { "Native restoration failed — see logcat tag CrystalNative for details" }

        val restoredFile = File(cacheDir, "restored_${System.currentTimeMillis()}.png")
        FileOutputStream(restoredFile).use { output.compress(Bitmap.CompressFormat.PNG, 100, it) }

        val thumbnailFile = File(cacheDir, "thumb_${System.currentTimeMillis()}.jpg")
        val thumb = Bitmap.createScaledBitmap(output, THUMBNAIL_SIZE, THUMBNAIL_SIZE * output.height / output.width, true)
        FileOutputStream(thumbnailFile).use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }

        val result = metrics.toResult(restoredFile.absolutePath, params)
        // WorkManager's output Data is capped at ~10KB, far too small for the
        // diagnostic maps (up to 512x512 floats each); RestorationWorker can
        // only hand the UI layer a file path, so the full result is
        // persisted here and re-hydrated via loadResult() once the worker
        // reports success.
        File(metricsPathFor(restoredFile.absolutePath)).writeText(gson.toJson(result))

        dao.insert(
            HistoryEntity(
                originalPath = sourceUri.toString(),
                restoredPath = restoredFile.absolutePath,
                thumbnailPath = thumbnailFile.absolutePath,
                createdAtEpochMs = System.currentTimeMillis(),
                realityScore = metrics.realityScore,
                specialMode = params.specialMode.nativeValue,
                paramsJson = gson.toJson(params),
            ),
        )
        onProgress(1f)
        result
    }

    /** Re-hydrates a [RestorationResult] previously written by [restore], keyed by its restored-image path. */
    suspend fun loadResult(restoredImagePath: String): RestorationResult = withContext(Dispatchers.IO) {
        val json = File(metricsPathFor(restoredImagePath)).readText()
        gson.fromJson(json, RestorationResult::class.java)
    }

    private fun metricsPathFor(restoredImagePath: String): String =
        restoredImagePath.substringBeforeLast('.') + ".metrics.json"

    suspend fun toggleFavorite(entity: HistoryEntity) = withContext(Dispatchers.IO) {
        dao.update(entity.copy(isFavorite = !entity.isFavorite))
    }

    suspend fun delete(entity: HistoryEntity) = withContext(Dispatchers.IO) {
        entity.restoredPath?.let { File(it).delete() }
        entity.thumbnailPath?.let { File(it).delete() }
        dao.delete(entity)
    }

    suspend fun paramsFor(entity: HistoryEntity): RestorationParams = withContext(Dispatchers.Default) {
        runCatching { gson.fromJson(entity.paramsJson, RestorationParams::class.java) }
            .getOrDefault(RestorationParams.forSpecialMode(SpecialMode.fromNativeValue(entity.specialMode)))
    }

    private fun RestorationMetricsNative.toResult(restoredPath: String, params: RestorationParams) = RestorationResult(
        restoredImagePath = restoredPath,
        realityScore = realityScore,
        blurMap = DiagnosticMap(mapWidth, mapHeight, blurMap),
        noiseMap = DiagnosticMap(mapWidth, mapHeight, noiseMap),
        edgeMap = DiagnosticMap(mapWidth, mapHeight, edgeMap),
        confidenceMap = DiagnosticMap(mapWidth, mapHeight, confidenceMap),
        artifactMap = DiagnosticMap(mapWidth, mapHeight, artifactMap),
        stats = ProcessingStats(
            analysisMs, candidateGenMs, consensusMs, artifactMs, frequencyGateMs,
            realityLockMs, blendMs, totalMs, tileCount,
        ),
        paramsUsed = params,
    )

    companion object {
        private const val MAX_PROCESSING_DIMENSION = 3000
        private const val MAP_MAX_DIMENSION = 512
        private const val THUMBNAIL_SIZE = 300
    }
}

private fun applyExifOrientation(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
    val orientation = context.contentResolver.openInputStream(uri)?.use { stream ->
        ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } ?: ExifInterface.ORIENTATION_NORMAL

    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        else -> return bitmap
    }
    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
}
