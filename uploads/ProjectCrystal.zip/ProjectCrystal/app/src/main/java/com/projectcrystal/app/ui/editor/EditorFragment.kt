package com.projectcrystal.app.ui.editor

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.navArgs
import com.projectcrystal.app.R
import com.projectcrystal.app.core.model.ProcessingState
import com.projectcrystal.app.data.db.AppDatabase
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.FragmentEditorBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * The main editing surface: image preview (zoomable, or before/after
 * compare), the progress overlay while a restoration is running, and the
 * entry points into [ToolBottomSheetFragment] (sliders) and
 * [ExportDialogFragment] (save). All state lives in the shared
 * [EditorViewModel] — this Fragment is a thin renderer of that state plus
 * user-input plumbing, which is what keeps rotation/process-death
 * (ViewModel survives both) from losing the user's in-progress edit.
 */
class EditorFragment : Fragment(), MenuProvider {

    private var _binding: FragmentEditorBinding? = null
    private val binding get() = _binding!!

    private val args: EditorFragmentArgs by navArgs()

    private val editorViewModel: EditorViewModel by activityViewModels {
        ViewModelFactory {
            val appContext = requireContext().applicationContext
            EditorViewModel(appContext, ImageRepository(appContext))
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEditorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        val sourceUri = Uri.parse(args.sourceUri)
        editorViewModel.setSourceImage(sourceUri)
        loadPreview(sourceUri)

        if (args.historyEntryId >= 0) loadHistoryParams(args.historyEntryId)

        binding.openToolsButton.setOnClickListener {
            ToolBottomSheetFragment().show(childFragmentManager, ToolBottomSheetFragment.TAG)
        }
        binding.restoreButton.setOnClickListener { editorViewModel.startRestoration() }
        binding.cancelButton.setOnClickListener { editorViewModel.cancelRestoration() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                editorViewModel.processingState.collect(::renderState)
            }
        }
    }

    private fun loadPreview(uri: Uri) {
        lifecycleScope.launch {
            val bitmap = ImageRepository(requireContext().applicationContext).decodeForProcessing(uri)
            binding.previewImage.setImageBitmap(bitmap)
            binding.previewImage.resetToFit()
        }
    }

    private fun loadHistoryParams(historyEntryId: Long) {
        lifecycleScope.launch {
            val dao = AppDatabase.getInstance(requireContext().applicationContext).historyDao()
            val entity = dao.getById(historyEntryId) ?: return@launch
            val repository = ImageRepository(requireContext().applicationContext)
            editorViewModel.loadParams(repository.paramsFor(entity))
        }
    }

    private fun renderState(state: ProcessingState) {
        val isBusy = state is ProcessingState.Analyzing || state is ProcessingState.Processing
        binding.progressIndicator.setVisibleOrGone(isBusy)
        binding.progressLabel.setVisibleOrGone(isBusy)
        binding.cancelButton.setVisibleOrGone(isBusy)
        binding.restoreButton.isEnabled = !isBusy

        when (state) {
            is ProcessingState.Analyzing -> {
                binding.progressIndicator.isIndeterminate = false
                binding.progressIndicator.setProgressCompat((state.progress * 100).roundToInt(), true)
                binding.progressLabel.text = getString(R.string.processing_analyzing)
            }
            is ProcessingState.Processing -> {
                binding.progressIndicator.isIndeterminate = false
                binding.progressIndicator.setProgressCompat((state.progress * 100).roundToInt(), true)
                binding.progressLabel.text = state.stageLabel
            }
            is ProcessingState.Done -> {
                val restored = BitmapFactory.decodeFile(state.result.restoredImagePath)
                binding.previewImage.setImageBitmap(restored)
                binding.previewImage.resetToFit()
            }
            is ProcessingState.Failed -> {
                (activity as? com.projectcrystal.app.ui.main.MainActivity)
                    ?.showMessage(getString(R.string.processing_failed, state.message))
            }
            ProcessingState.Cancelled, ProcessingState.Idle -> Unit
        }
    }

    // ---- MenuProvider: Compare / Export -----------------------------------

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.editor_toolbar_menu, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean = when (menuItem.itemId) {
        R.id.action_compare -> {
            toggleCompareView()
            true
        }
        R.id.action_export -> {
            ExportDialogFragment().show(childFragmentManager, ExportDialogFragment.TAG)
            true
        }
        else -> false
    }

    private fun toggleCompareView() {
        val state = editorViewModel.processingState.value
        val result = (state as? ProcessingState.Done)?.result ?: return
        val showingCompare = binding.compareView.visibility == View.VISIBLE
        if (showingCompare) {
            binding.compareView.setVisibleOrGone(false)
            binding.previewImage.setVisibleOrGone(true)
        } else {
            val originalUri = editorViewModel.sourceUri.value ?: return
            lifecycleScope.launch {
                val original = ImageRepository(requireContext().applicationContext).decodeForProcessing(originalUri)
                binding.compareView.beforeBitmap = original
                binding.compareView.afterBitmap = BitmapFactory.decodeFile(result.restoredImagePath)
                binding.previewImage.setVisibleOrGone(false)
                binding.compareView.setVisibleOrGone(true)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
