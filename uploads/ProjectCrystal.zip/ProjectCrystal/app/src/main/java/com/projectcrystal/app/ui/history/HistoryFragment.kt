package com.projectcrystal.app.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import androidx.appcompat.widget.PopupMenu
import com.projectcrystal.app.R
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.FragmentHistoryBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    private val args: HistoryFragmentArgs by navArgs()

    private val viewModel: HistoryViewModel by viewModels {
        ViewModelFactory {
            HistoryViewModel(ImageRepository(requireContext().applicationContext), args.favoritesOnly)
        }
    }

    private val adapter = HistoryAdapter(
        onOpen = { entity -> openInEditor(entity) },
        onToggleFavorite = { entity -> viewModel.toggleFavorite(entity) },
        onMore = { entity, anchor -> showMoreMenu(entity, anchor) },
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.historyRecycler.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.historyRecycler.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.entries.collect { entries ->
                    adapter.submitList(entries)
                    binding.emptyLabel.setVisibleOrGone(entries.isEmpty())
                }
            }
        }
    }

    private fun openInEditor(entity: HistoryEntity) {
        findNavController().navigate(
            R.id.action_history_to_editor,
            bundleOf("sourceUri" to entity.originalPath, "historyEntryId" to entity.id),
        )
    }

    private fun showMoreMenu(entity: HistoryEntity, anchor: View) {
        PopupMenu(requireContext(), anchor).apply {
            menu.add(getString(R.string.history_edit_again))
            menu.add(getString(R.string.history_delete))
            setOnMenuItemClickListener { item ->
                when (item.title) {
                    getString(R.string.history_edit_again) -> openInEditor(entity)
                    getString(R.string.history_delete) -> viewModel.delete(entity)
                }
                true
            }
        }.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
