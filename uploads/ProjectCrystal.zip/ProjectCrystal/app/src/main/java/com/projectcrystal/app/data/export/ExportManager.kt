package com.projectcrystal.app.data.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Writes a restored image out to the shared Pictures library. Two code
 * paths, split at API 29 (scoped storage): MediaStore.insert() with
 * RELATIVE_PATH on 29+, and a direct file write into the public Pictures
 * directory (requires the legacy WRITE_EXTERNAL_STORAGE permission, granted
 * by the manifest's maxSdkVersion=28 request) below it. EXIF metadata is
 * copied from the original file when [ExportOptions.preserveMetadata] is
 * set and the target format supports EXIF (JPEG only — PNG/WebP via
 * Android's encoder don't carry it).
 */
class ExportManager(private val context: Context) {

    sealed interface ExportResult {
        data class Success(val displayPath: String) : ExportResult
        data class Failure(val message: String) : ExportResult
    }

    suspend fun export(sourceImagePath: String, originalUriForExif: String?, options: ExportOptions): ExportResult =
        withContext(Dispatchers.IO) {
            try {
                val bitmap = BitmapFactory.decodeFile(sourceImagePath)
                    ?: return@withContext ExportResult.Failure("Unable to read restored image")

                val filename = "${options.filename}.${options.format.extension}"
                val displayPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    exportViaMediaStore(bitmap, filename, options)
                } else {
                    exportLegacy(bitmap, filename, options)
                }

                if (options.preserveMetadata && options.format == ExportFormat.JPEG) {
                    copyExifIfPossible(originalUriForExif, displayPath)
                }

                ExportResult.Success(displayPath)
            } catch (e: Exception) {
                ExportResult.Failure(e.message ?: "Export failed")
            }
        }

    private fun exportViaMediaStore(bitmap: Bitmap, filename: String, options: ExportOptions): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, options.format.mimeType)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/ProjectCrystal")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("MediaStore rejected the insert")

        resolver.openOutputStream(uri)?.use { out -> writeBitmap(bitmap, options, out) }
            ?: error("Unable to open output stream")

        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri.toString()
    }

    private fun exportLegacy(bitmap: Bitmap, filename: String, options: ExportOptions): String {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ProjectCrystal")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, filename)
        FileOutputStream(file).use { out -> writeBitmap(bitmap, options, out) }
        return file.absolutePath
    }

    private fun writeBitmap(bitmap: Bitmap, options: ExportOptions, out: OutputStream) {
        val format = when (options.format) {
            ExportFormat.PNG -> Bitmap.CompressFormat.PNG
            ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
            ExportFormat.WEBP -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION")
                Bitmap.CompressFormat.WEBP
            }
        }
        bitmap.compress(format, options.quality, out)
    }

    private fun copyExifIfPossible(originalUriString: String?, exportedPath: String) {
        val originalUri = originalUriString ?: return
        runCatching {
            val sourceExif = context.contentResolver.openInputStream(android.net.Uri.parse(originalUri))?.use {
                ExifInterface(it)
            } ?: return
            // ExifInterface can only write to a real file path, not a MediaStore uri stream directly
            // on all API levels, so metadata copy is best-effort and silently skipped past that point.
            val targetFile = File(exportedPath.removePrefix("file://"))
            if (!targetFile.exists()) return
            val targetExif = ExifInterface(targetFile.absolutePath)
            EXIF_TAGS_TO_COPY.forEach { tag ->
                sourceExif.getAttribute(tag)?.let { targetExif.setAttribute(tag, it) }
            }
            targetExif.saveAttributes()
        }
    }

    companion object {
        private val EXIF_TAGS_TO_COPY = listOf(
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_GPS_LATITUDE,
            ExifInterface.TAG_GPS_LONGITUDE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MODEL,
        )
    }
}
