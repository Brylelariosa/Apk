package com.projectcrystal.app.ui.editor

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.projectcrystal.app.core.model.ProcessingState
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.core.model.SpecialMode
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.data.work.RestorationWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Owns everything the Editor screen needs: the source image, the current
 * slider state, and the lifecycle of a restoration run. Restoration itself
 * always goes through [RestorationWorker] (never a raw coroutine) so it
 * survives the app being backgrounded and can be cancelled from the UI.
 */
class EditorViewModel(
    private val appContext: Context,
    private val repository: ImageRepository,
) : ViewModel() {

    private val _sourceUri = MutableStateFlow<Uri?>(null)
    val sourceUri: StateFlow<Uri?> = _sourceUri.asStateFlow()

    private val _params = MutableStateFlow(RestorationParams())
    val params: StateFlow<RestorationParams> = _params.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    private val _showingOriginal = MutableStateFlow(false)
    val showingOriginal: StateFlow<Boolean> = _showingOriginal.asStateFlow()

    private var observeJob: Job? = null

    fun setSourceImage(uri: Uri) {
        _sourceUri.value = uri
        _processingState.value = ProcessingState.Idle
    }

    fun loadParams(params: RestorationParams) {
        _params.value = params
    }

    fun updateParams(transform: (RestorationParams) -> RestorationParams) {
        _params.value = transform(_params.value)
    }

    fun applySpecialMode(mode: SpecialMode) {
        _params.value = RestorationParams.forSpecialMode(mode)
    }

    fun toggleBeforeAfter() {
        _showingOriginal.value = !_showingOriginal.value
    }

    fun startRestoration() {
        val uri = _sourceUri.value ?: return
        _processingState.value = ProcessingState.Analyzing(0f)
        RestorationWorker.enqueue(appContext, uri, _params.value)
        observeWork(uri)
    }

    fun cancelRestoration() {
        val uri = _sourceUri.value ?: return
        WorkManager.getInstance(appContext).cancelUniqueWork(RestorationWorker.uniqueWorkName(uri))
        _processingState.value = ProcessingState.Cancelled
    }

    private fun observeWork(uri: Uri) {
        observeJob?.cancel()
        observeJob = viewModelScope.launch {
            WorkManager.getInstance(appContext)
                .getWorkInfosForUniqueWorkFlow(RestorationWorker.uniqueWorkName(uri))
                .collect { infos ->
                    val info = infos.firstOrNull() ?: return@collect
                    handleWorkInfo(info)
                }
        }
    }

    private suspend fun handleWorkInfo(info: WorkInfo) {
        when (info.state) {
            WorkInfo.State.RUNNING, WorkInfo.State.ENQUEUED -> {
                val progress = info.progress.getFloat(RestorationWorker.KEY_PROGRESS, 0f)
                _processingState.value = if (progress < ANALYSIS_PROGRESS_CUTOFF) {
                    ProcessingState.Analyzing(progress)
                } else {
                    ProcessingState.Processing(progress, stageLabelFor(progress))
                }
            }
            WorkInfo.State.SUCCEEDED -> {
                val path = info.outputData.getString(RestorationWorker.KEY_RESULT_PATH)
                if (path == null) {
                    _processingState.value = ProcessingState.Failed("Missing output path")
                    return
                }
                val result = repository.loadResult(path)
                _processingState.value = ProcessingState.Done(result)
            }
            WorkInfo.State.FAILED -> {
                val message = info.outputData.getString(RestorationWorker.KEY_ERROR) ?: "Restoration failed"
                _processingState.value = ProcessingState.Failed(message)
            }
            WorkInfo.State.CANCELLED -> _processingState.value = ProcessingState.Cancelled
            WorkInfo.State.BLOCKED -> Unit
        }
    }

    private fun stageLabelFor(progress: Float): String = when {
        progress < 0.4f -> "Generating restoration candidates"
        progress < 0.6f -> "Building consensus"
        progress < 0.75f -> "Detecting artifacts"
        progress < 0.9f -> "Applying reality lock"
        else -> "Finalizing"
    }

    companion object {
        private const val ANALYSIS_PROGRESS_CUTOFF = 0.15f
    }
}
