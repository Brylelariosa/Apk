package com.projectcrystal.app.ui.batch

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.projectcrystal.app.R
import com.projectcrystal.app.databinding.ItemBatchBinding

class BatchAdapter : ListAdapter<BatchItem, BatchAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBatchBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class ViewHolder(private val binding: ItemBatchBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: BatchItem) {
            Glide.with(binding.thumbnail).load(item.uri).centerCrop().into(binding.thumbnail)

            val (labelRes, iconRes) = when (item.status) {
                BatchStatus.QUEUED -> R.string.batch_queued to R.drawable.ic_history
                BatchStatus.PROCESSING -> R.string.batch_processing to R.drawable.ic_tune
                BatchStatus.DONE -> R.string.batch_done to R.drawable.ic_check
                BatchStatus.FAILED -> R.string.batch_failed to R.drawable.ic_close
            }
            binding.statusLabel.setText(labelRes)
            binding.statusIcon.setImageResource(iconRes)
            binding.itemProgress.isIndeterminate = item.status == BatchStatus.PROCESSING && item.progress <= 0f
            if (!binding.itemProgress.isIndeterminate) {
                binding.itemProgress.setProgressCompat((item.progress * 100).toInt(), true)
            }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<BatchItem>() {
            override fun areItemsTheSame(oldItem: BatchItem, newItem: BatchItem) = oldItem.uri == newItem.uri
            override fun areContentsTheSame(oldItem: BatchItem, newItem: BatchItem) = oldItem == newItem
        }
    }
}
