package com.projectcrystal.app.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.projectcrystal.app.R
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.databinding.ItemHistoryBinding

class HistoryAdapter(
    private val onOpen: (HistoryEntity) -> Unit,
    private val onToggleFavorite: (HistoryEntity) -> Unit,
    private val onMore: (HistoryEntity, android.view.View) -> Unit,
) : ListAdapter<HistoryEntity, HistoryAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entity: HistoryEntity) {
            Glide.with(binding.thumbnail).load(entity.thumbnailPath).centerCrop().into(binding.thumbnail)
            binding.realityScoreLabel.text = entity.realityScore?.let { "${(it * 100).toInt()}%" } ?: "—"
            binding.favoriteButton.setImageResource(
                if (entity.isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border,
            )
            binding.thumbnail.setOnClickListener { onOpen(entity) }
            binding.favoriteButton.setOnClickListener { onToggleFavorite(entity) }
            binding.moreButton.setOnClickListener { onMore(entity, it) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<HistoryEntity>() {
            override fun areItemsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem == newItem
        }
    }
}
