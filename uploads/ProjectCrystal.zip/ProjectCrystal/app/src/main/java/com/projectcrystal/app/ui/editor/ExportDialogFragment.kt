package com.projectcrystal.app.ui.editor

import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.projectcrystal.app.R
import com.projectcrystal.app.core.model.ProcessingState
import com.projectcrystal.app.data.export.ExportFormat
import com.projectcrystal.app.data.export.ExportManager
import com.projectcrystal.app.data.export.ExportOptions
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.DialogExportBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch

/**
 * The spec's export options (format / quality / metadata / filename /
 * output folder) as a single confirm dialog. Resolution re-sampling is
 * intentionally not offered here — the restored bitmap is already at the
 * source photo's resolution, and downsampling on export is a distinct,
 * separately-scoped feature rather than a natural extension of "pick a
 * format and quality".
 */
class ExportDialogFragment : DialogFragment() {

    private val editorViewModel: EditorViewModel by activityViewModels {
        ViewModelFactory {
            val appContext = requireContext().applicationContext
            EditorViewModel(appContext, ImageRepository(appContext))
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val binding = DialogExportBinding.inflate(layoutInflater)

        binding.qualityRow.sliderLabel.setText(R.string.export_quality)
        binding.qualityRow.slider.valueFrom = 10f
        binding.qualityRow.slider.valueTo = 100f
        binding.qualityRow.slider.value = 95f
        binding.qualityRow.sliderValue.text = "95"
        binding.qualityRow.slider.addOnChangeListener { _, value, _ ->
            binding.qualityRow.sliderValue.text = value.toInt().toString()
        }
        binding.qualityRow.root.setVisibleOrGone(false)

        binding.filenameInput.setText("crystal_${System.currentTimeMillis()}")

        binding.formatRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            binding.qualityRow.root.setVisibleOrGone(checkedId != binding.formatPng.id)
        }

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.action_export)
            .setView(binding.root)
            .setPositiveButton(R.string.export_confirm, null)
            .setNegativeButton(R.string.generic_cancel, null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener {
                val format = when (binding.formatRadioGroup.checkedRadioButtonId) {
                    binding.formatJpeg.id -> ExportFormat.JPEG
                    binding.formatWebp.id -> ExportFormat.WEBP
                    else -> ExportFormat.PNG
                }
                val options = ExportOptions(
                    format = format,
                    quality = binding.qualityRow.slider.value.toInt(),
                    filename = binding.filenameInput.text?.toString()?.ifBlank { null }
                        ?: "crystal_${System.currentTimeMillis()}",
                    preserveMetadata = binding.preserveMetadataSwitch.isChecked,
                )
                performExport(options)
                dialog.dismiss()
            }
        }
        return dialog
    }

    private fun performExport(options: ExportOptions) {
        val state = editorViewModel.processingState.value
        val result = (state as? ProcessingState.Done)?.result ?: return
        val sourceUri = editorViewModel.sourceUri.value?.toString()

        lifecycleScope.launch {
            val exportManager = ExportManager(requireContext().applicationContext)
            when (val outcome = exportManager.export(result.restoredImagePath, sourceUri, options)) {
                is ExportManager.ExportResult.Success -> showMessage(getString(R.string.export_success))
                is ExportManager.ExportResult.Failure -> showMessage(outcome.message)
            }
        }
    }

    private fun showMessage(message: String) {
        (activity as? com.projectcrystal.app.ui.main.MainActivity)?.showMessage(message)
    }

    companion object {
        const val TAG = "ExportDialog"
    }
}
