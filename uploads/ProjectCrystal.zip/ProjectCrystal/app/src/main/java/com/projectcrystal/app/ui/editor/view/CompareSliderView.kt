package com.projectcrystal.app.ui.editor.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Split before/after comparison: draws [afterBitmap] full-frame, then the
 * portion of [beforeBitmap] to the left of a draggable vertical divider,
 * with a thin handle the user can drag. Both bitmaps are letterboxed
 * identically (same fit-center transform) so the split lines up pixel-for-
 * pixel regardless of the two images' aspect ratio being briefly
 * mismatched mid-crop.
 */
class CompareSliderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {

    var beforeBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    var afterBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }

    /** 0..1, fraction of the view width where the divider currently sits. */
    var dividerFraction: Float = 0.5f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 4f }
    private val handleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val srcRect = Rect()
    private val destRect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val after = afterBitmap ?: return
        val before = beforeBitmap ?: return

        computeFitRect(after, destRect)
        srcRect.set(0, 0, after.width, after.height)
        canvas.drawBitmap(after, srcRect, destRect, null)

        val dividerX = destRect.left + destRect.width() * dividerFraction
        canvas.save()
        canvas.clipRect(destRect.left, destRect.top, dividerX, destRect.bottom)
        canvas.drawBitmap(before, srcRect, destRect, null)
        canvas.restore()

        canvas.drawLine(dividerX, destRect.top, dividerX, destRect.bottom, handlePaint)
        canvas.drawCircle(dividerX, (destRect.top + destRect.bottom) / 2f, HANDLE_RADIUS_PX, handleFillPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (destRect.width() > 0) {
                    dividerFraction = (event.x - destRect.left) / destRect.width()
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun computeFitRect(bitmap: Bitmap, out: RectF) {
        val viewW = width.toFloat()
        val viewH = height.toFloat()
        val scale = minOf(viewW / bitmap.width, viewH / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        val left = (viewW - w) / 2f
        val top = (viewH - h) / 2f
        out.set(left, top, left + w, top + h)
    }

    companion object {
        private const val HANDLE_RADIUS_PX = 24f
    }
}
