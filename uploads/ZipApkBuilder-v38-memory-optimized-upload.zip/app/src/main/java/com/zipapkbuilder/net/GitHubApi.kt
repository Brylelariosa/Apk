package com.zipapkbuilder.net

import android.util.Base64
import android.util.Base64OutputStream
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Thin, stateless wrapper around `HttpURLConnection` for the handful of
 * GitHub REST endpoints this app calls (Contents API, Actions API, Git Data
 * API). Every call takes the token explicitly rather than the client holding
 * one, since the token can change between calls (the user may edit the token
 * field between actions) — this mirrors how the endpoints were called before
 * this was split out of the Activity, just without the duplication of
 * `HttpURLConnection` boilerplate across five near-identical functions.
 */
object GitHubApi {

    fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    /**
     * PATCH via POST + X-HTTP-Method-Override so it works on Android's
     * HttpURLConnection which may not support PATCH natively on API < 29.
     */
    fun httpPatch(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("X-HTTP-Method-Override", "PATCH")
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    /**
     * The base64-encoded length (no line wrapping, padding included) that
     * [rawByteCount] raw bytes will produce — i.e. what
     * `Base64.encodeToString(bytes, Base64.NO_WRAP).length` would return for
     * a byte array of that size, computed without touching any actual data.
     * Used to size the HTTP request body up front so [uploadStreamingBase64]
     * can stream straight into a fixed-length connection instead of
     * buffering the encoded form to measure it.
     */
    fun base64EncodedLength(rawByteCount: Long): Long = ((rawByteCount + 2) / 3) * 4

    /**
     * Builds the (prefix, suffix) JSON fragments that sandwich a streamed
     * `"content":"…"` field for a Contents API create/update PUT — the same
     * envelope [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
     * and [FileManagerController][com.zipapkbuilder.feature.filemanager.FileManagerController]
     * both need, kept in one place instead of each building its own
     * `JSONObject`. [message] is escaped via [JSONObject.quote]; the content
     * itself is never touched here since [uploadStreamingBase64] streams it
     * separately — base64 output uses no character JSON would need to escape,
     * so it can be written straight into the body between these two pieces.
     */
    fun contentsApiEnvelope(message: String, branch: String, existingSha: String?): Pair<String, String> {
        val prefix = "{\"message\":${JSONObject.quote(message)},\"content\":\""
        val suffix = buildString {
            append("\",\"branch\":").append(JSONObject.quote(branch))
            if (existingSha != null) append(",\"sha\":").append(JSONObject.quote(existingSha))
            append("}")
        }
        return prefix to suffix
    }

    /**
     * Uploads [source] to GitHub as base64-encoded JSON content, streaming
     * the whole way through: raw bytes are read from [source] in small
     * chunks, base64-encoded on the fly by [Base64OutputStream], and written
     * straight into the HTTP request body between [jsonPrefix] and
     * [jsonSuffix]. At no point do the raw file, its base64 form, or the
     * full JSON body exist as one in-memory object — peak extra memory is a
     * single [STREAM_CHUNK_BYTES]-sized read buffer plus whatever small
     * internal buffer `Base64OutputStream` reuses across calls, regardless
     * of how large [source] is. This is what replaces the old
     * `readBytes()` → `Base64.encodeToString()` → `JSONObject` →
     * `toByteArray()` pipeline, which could hold up to four full-size
     * copies of the same data in memory at once.
     *
     * [rawLength] must be the exact byte count [source] will yield — needed
     * up front to compute the fixed `Content-Length` GitHub's API expects
     * (its gateway has been observed to reject large bodies sent without
     * one, so chunked transfer encoding is avoided here).
     *
     * [source] is always closed before this function returns, success,
     * failure, or cancellation — as is the connection's output stream and
     * the `Base64OutputStream` wrapping it (via `use {}`), so no stream is
     * ever left dangling in a field or a callback.
     *
     * [isCancelled] is polled once per chunk — the same granularity the old
     * chunked writers used — so a caller's cancel flag can abort mid-flight.
     */
    fun uploadStreamingBase64(
        token: String,
        urlStr: String,
        method: String,
        jsonPrefix: String,
        source: InputStream,
        rawLength: Long,
        jsonSuffix: String,
        isCancelled: () -> Boolean,
        onProgress: (written: Long, total: Long) -> Unit
    ): Pair<Int, String> {
        val prefixBytes = jsonPrefix.toByteArray(Charsets.UTF_8)
        val suffixBytes = jsonSuffix.toByteArray(Charsets.UTF_8)
        val totalBodyLength = prefixBytes.size + base64EncodedLength(rawLength) + suffixBytes.size

        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000; readTimeout = 300_000
            setFixedLengthStreamingMode(totalBodyLength)
        }
        return try {
            conn.connect()
            source.use { rawSource ->
                conn.outputStream.use { rawOut ->
                    rawOut.write(prefixBytes)
                    var rawSoFar = 0L
                    val buffer = ByteArray(STREAM_CHUNK_BYTES)
                    // NO_CLOSE: closing this flushes the final (possibly padded)
                    // base64 group into rawOut without closing rawOut itself —
                    // the JSON suffix still needs to be written after it.
                    Base64OutputStream(rawOut, Base64.NO_WRAP or Base64.NO_CLOSE).use { b64Out ->
                        while (true) {
                            if (isCancelled()) { conn.disconnect(); throw Exception("Cancelled by user") }
                            val n = rawSource.read(buffer)
                            if (n == -1) break
                            b64Out.write(buffer, 0, n)
                            rawSoFar += n
                            onProgress(prefixBytes.size + base64EncodedLength(rawSoFar), totalBodyLength)
                        }
                    }
                    rawOut.write(suffixBytes)
                    rawOut.flush()
                }
            }
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }
    }

    /** Raw bytes read (and base64-encoded) per streaming step in [uploadStreamingBase64] —
     *  small enough to be a negligible, constant memory cost regardless of file size,
     *  large enough to keep I/O overhead low. */
    private const val STREAM_CHUNK_BYTES = 128 * 1024
}
