package com.zipapkbuilder.feature.keystore

import android.app.AlertDialog
import android.util.Base64
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.feature.build.WorkflowTemplates
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONObject

/**
 * Generates a signing keystore entirely on a GitHub Actions runner (never on
 * the device) and saves it as repo secrets — reuses
 * [com.zipapkbuilder.feature.build.BuildFlowController.ensureRepo] and
 * [com.zipapkbuilder.feature.build.BuildFlowController.fetchFileSha] rather
 * than duplicating that "make sure the repo/workflow file exists" logic a
 * second time here.
 */
class KeystoreController(private val activity: MainActivity) {

    fun generateKeystore() {
        val token    = activity.etToken.text.toString().trim()
        val repo     = activity.etRepo.text.toString().trim()
        val pass     = activity.etKeystorePass.text.toString().trim()
        val rawAlias = activity.etKeyAlias.text.toString().trim()

        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }
        if (pass.length < 6) { activity.appendLog("⚠ Keystore password must be at least 6 characters."); return }

        val ts    = java.text.SimpleDateFormat("yyyyMMddHHmm", java.util.Locale.US).format(java.util.Date())
        val alias = rawAlias.ifEmpty { "key-$ts" }

        // Check GitHub for an existing keystore before showing the dialog
        activity.setBusy(true)
        activity.appendLog("Checking for existing keystore on GitHub…")
        activity.bgExecutor.execute {
            val existingFile: String? = try {
                val owner = activity.buildFlowController.fetchOwner(token)
                if (owner == null) {
                    activity.mainHandler.post { activity.setBusy(false); activity.appendLog("⚠ Token invalid or no network.") }
                    return@execute
                }
                activity.lastOwner = owner
                activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$owner / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }
                checkExistingKeystore(token, owner, repo)
            } catch (_: Exception) {
                null // on any error fall through to normal generation dialog
            }

            activity.mainHandler.post {
                activity.setBusy(false)
                // The check above can take a few seconds; if the user backed out of the
                // app in the meantime, don't pop a new AlertDialog on a dead Activity.
                if (activity.isFinishing || activity.isDestroyed) return@post
                if (existingFile != null) {
                    // ── Keystore already on GitHub ──────────────────────────────
                    AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setTitle("🔑 Keystore Already Configured")
                        .setMessage(
                            "A keystore is already saved on GitHub:\n\n" +
                            "  File : $existingFile\n\n" +
                            "Builds will automatically use it.\n\n" +
                            "Tap \"Use Existing\" to keep it, or\n" +
                            "\"Generate New\" to overwrite."
                        )
                        .setPositiveButton("Use Existing") { _, _ ->
                            // Note: we only know this keystore's *filename* from GitHub
                            // (Secrets values are never revealed by the API) — we were
                            // never told what alias it was actually generated with, so
                            // storing the locally-typed/guessed `alias` here would risk
                            // mislabeling the Settings display with a wrong alias for an
                            // existing keystore. Show the verified filename instead.
                            activity.prefs.edit()
                                .putBoolean(PrefKeys.PREF_KEYSTORE_SAVED, true)
                                .putString(PrefKeys.PREF_KEYSTORE_ALIAS, "(existing — see $existingFile)")
                                .apply()
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.appendLog("✓ Using existing keystore on GitHub")
                            activity.appendLog("  File : $existingFile")
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.tvKeystoreStatus.text = "✓ Keystore ready  •  $existingFile"
                            activity.tvKeystoreStatus.visibility = android.view.View.VISIBLE
                        }
                        .setNegativeButton("Generate New") { _, _ ->
                            activity.setBusy(true)
                            activity.tvKeystoreStatus.visibility = android.view.View.GONE
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.appendLog("🔑 Keystore generation starting…")
                            activity.appendLog("  Alias : $alias")
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.bgExecutor.execute { runKeystoreGeneration(token, repo, alias, pass) }
                        }
                        .setNeutralButton("Cancel", null)
                        .show()
                } else {
                    // ── No existing keystore — original generation dialog ────────
                    AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setTitle("🔑 Generate Keystore")
                        .setMessage(
                            "This will:\n\n" +
                            "• Run the keystore generation workflow\n" +
                            "• Save keystore as GitHub Secrets:\n" +
                            "  KEYSTORE_BASE64, STORE_PASSWORD,\n" +
                            "  KEY_PASSWORD, KEY_ALIAS, KEYSTORE_FILE\n" +
                            "• Save KEYSTORE_FILENAME as a variable\n\n" +
                            "Alias: $alias\n\n" +
                            "Each run creates a uniquely-named keystore.\n" +
                            "Continue?"
                        )
                        .setPositiveButton("Generate") { _, _ ->
                            activity.setBusy(true)
                            activity.tvKeystoreStatus.visibility = android.view.View.GONE
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.appendLog("🔑 Keystore generation starting…")
                            activity.appendLog("  Alias : $alias")
                            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            activity.bgExecutor.execute { runKeystoreGeneration(token, repo, alias, pass) }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }

    /**
     * Returns the KEYSTORE_FILENAME variable value if both the KEYSTORE_BASE64
     * secret and KEYSTORE_FILENAME variable already exist in the repo,
     * or null if either is missing.
     */
    private fun checkExistingKeystore(token: String, owner: String, repo: String): String? {
        // GitHub returns 200 if the secret exists (value is never revealed), 404 if not
        val (secretCode, _) = GitHubApi.httpGet(
            token, "https://api.github.com/repos/$owner/$repo/actions/secrets/KEYSTORE_BASE64")
        if (secretCode != 200) return null

        // Variable endpoint returns the value directly
        val (varCode, varBody) = GitHubApi.httpGet(
            token, "https://api.github.com/repos/$owner/$repo/actions/variables/KEYSTORE_FILENAME")
        if (varCode != 200) return null

        return try {
            JSONObject(varBody).getString("value").takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    private fun runKeystoreGeneration(token: String, repo: String, alias: String, pass: String) {
        try {
            val owner = activity.buildFlowController.fetchOwner(token)
                ?: throw Exception("Token invalid or no network.")
            activity.lastOwner = owner
            activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$owner / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }

            activity.appendLog("Checking github.com/$owner/$repo …")
            activity.buildFlowController.ensureRepo(token, owner, repo)

            // GitHub caches a workflow's trigger list at creation time — updating a file
            // in-place via API never re-registers triggers. Always delete then recreate.
            val wfPath = ".github/workflows/keystore.yml"
            val existingSha = activity.buildFlowController.fetchFileSha(token, owner, repo, wfPath)
            if (existingSha != null) {
                activity.appendLog("Removing old keystore workflow…")
                val delPayload = JSONObject().apply {
                    put("message", "ci: remove old keystore workflow")
                    put("sha", existingSha)
                    put("branch", "main")
                }.toString()
                val (delCode, delBody) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, wfPath), delPayload)
                if (delCode !in 200..204) throw Exception("Could not delete old workflow ($delCode): ${delBody.take(300)}")
                Thread.sleep(3_000)
            }
            activity.appendLog("Committing keystore workflow…")
            val wfEncoded = Base64.encodeToString(
                WorkflowTemplates.KEYSTORE_WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val wfPayload = JSONObject().apply {
                put("message", "ci: add keystore workflow")
                put("content", wfEncoded)
                put("branch",  "main")
                // No "sha" — fresh create forces GitHub to re-register all triggers
            }.toString()
            val (wfCode, wfBody) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, wfPath), wfPayload)
            if (wfCode !in 200..201) throw Exception("Could not commit workflow ($wfCode): ${wfBody.take(300)}")
            activity.appendLog("Keystore workflow ready ✓")

            // Use dispatch itself as readiness probe — 422 means GitHub hasn't finished
            // indexing the new file yet; retry for up to 2 minutes.
            activity.appendLog("Triggering keystore generation workflow…")
            val dispatchBody = JSONObject().apply {
                put("ref", "main")
                put("inputs", JSONObject().apply {
                    put("alias",         alias)
                    put("password",      pass)
                    put("validity_days", "10950")
                    put("pat_token",     token)
                })
            }.toString()
            val dispatchUrl = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/dispatches"
            val dispatchDeadline = System.currentTimeMillis() + 120_000L
            var dCode = 0; var dBody = ""; var attempt = 0
            while (System.currentTimeMillis() < dispatchDeadline) {
                attempt++
                val (c, b) = GitHubApi.httpPost(token, dispatchUrl, dispatchBody)
                dCode = c; dBody = b
                if (c in 200..204) break
                activity.appendLog("  Dispatch attempt $attempt: $c — retrying…")
                Thread.sleep(5_000)
            }
            if (dCode !in 200..204) throw Exception("Dispatch failed ($dCode): ${dBody.take(300)}")
            activity.appendLog("Workflow dispatched ✓ — waiting for run…")

            Thread.sleep(6_000)

            // Wait for the run to appear
            val afterMs  = System.currentTimeMillis() - 15_000L
            val deadline = System.currentTimeMillis() + 3 * 60_000L
            var keystoreRunId = -1L
            while (System.currentTimeMillis() < deadline && keystoreRunId == -1L) {
                try {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/runs?per_page=5"
                    val (code, body) = GitHubApi.httpGet(token, url)
                    if (code == 200) {
                        val runs = JSONObject(body).getJSONArray("workflow_runs")
                        for (i in 0 until runs.length()) {
                            val run = runs.getJSONObject(i)
                            if (Formatters.parseIso8601(run.getString("created_at")) >= afterMs) {
                                keystoreRunId = run.getLong("id"); break
                            }
                        }
                    }
                } catch (_: Exception) {}
                if (keystoreRunId == -1L) Thread.sleep(8_000)
            }
            if (keystoreRunId == -1L) throw Exception("Keystore run did not appear within 3 minutes.")

            activity.appendLog("Run #$keystoreRunId started — polling steps…")
            activity.appendLog("─────────────────────────────────────")

            // Poll until complete, streaming step names
            val runDeadline  = System.currentTimeMillis() + 10 * 60_000L
            var conclusion   = ""
            val stepStarted  = mutableSetOf<Int>()
            val stepFinished = mutableSetOf<Int>()
            while (System.currentTimeMillis() < runDeadline) {
                try {
                    val (jCode, jBody) = GitHubApi.httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId/jobs")
                    if (jCode == 200) {
                        val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                        if (jobsArr != null && jobsArr.length() > 0) {
                            val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                            if (steps != null) {
                                for (i in 0 until steps.length()) {
                                    val step     = steps.getJSONObject(i)
                                    val num      = step.getInt("number")
                                    val name     = step.getString("name")
                                    val status   = step.optString("status", "")
                                    val stepConc = step.optString("conclusion", "")
                                    if (status == "in_progress" && stepStarted.add(num)) activity.appendLog("▶ $name")
                                    if (status == "completed" && stepFinished.add(num)) {
                                        if (!stepStarted.contains(num)) activity.appendLog("▶ $name")
                                        val icon = if (stepConc == "success") "✓" else "✗"
                                        val started   = step.optString("started_at", "")
                                        val completed = step.optString("completed_at", "")
                                        val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                            try {
                                                val e = Formatters.parseIso8601(completed); val s = Formatters.parseIso8601(started)
                                                if (e > s) "  ${(e - s) / 1000}s" else ""
                                            } catch (_: Exception) { "" }
                                        } else ""
                                        activity.appendLog("  $icon $name$dur")
                                    }
                                }
                            }
                        }
                    }
                    val (sCode, sBody) = GitHubApi.httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId")
                    if (sCode == 200) {
                        val obj = JSONObject(sBody)
                        conclusion = obj.optString("conclusion", "")
                        if (obj.getString("status") == "completed") break
                    }
                } catch (_: Exception) {}
                Thread.sleep(6_000)
            }

            activity.appendLog("─────────────────────────────────────")
            if (conclusion != "success") throw Exception("Keystore workflow $conclusion. Check run #$keystoreRunId on GitHub.")

            activity.prefs.edit()
                .putBoolean(PrefKeys.PREF_KEYSTORE_SAVED, true)
                .putString(PrefKeys.PREF_KEYSTORE_ALIAS, alias)
                .apply()

            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            activity.appendLog("✓ Keystore generated successfully!")
            activity.appendLog("  Alias    : $alias")
            activity.appendLog("  Secrets  : KEYSTORE_BASE64, STORE_PASSWORD,")
            activity.appendLog("             KEY_PASSWORD, KEY_ALIAS, KEYSTORE_FILE")
            activity.appendLog("  Variable : KEYSTORE_FILENAME")
            activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            activity.mainHandler.post {
                activity.tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
                activity.tvKeystoreStatus.visibility = android.view.View.VISIBLE
            }

        } catch (e: Exception) {
            activity.appendLog("✗ Keystore error: ${e.message}")
        } finally {
            activity.setBusy(false)
        }
    }
}
