package com.zipapkbuilder.feature.download

import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.FloatingTransferIndicator
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.model.DownloadTask
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Owns every downloaded-artifact concern: the resumable, pausable, multi-task
 * download engine; the Download Manager dialog that watches it; ZIP/APK
 * integrity verification; saving into the public Downloads folder (or a
 * user-picked custom folder); and download history. Runs its own
 * [downloadExecutor] independent of the Activity's general-purpose background
 * executor ([MainActivity.bgExecutor]), so downloads keep transferring and can
 * be paused/resumed/cancelled from the manager dialog no matter what else the
 * app is doing.
 */
class DownloadManager(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    companion object {
        // How long a resumable partial download (artifact_*/logs_tmp_*) is kept
        // in cache before the cold-start sweep treats it as abandoned. Deliberately
        // long — see cleanupStaleCacheFiles() — so closing the app and coming back
        // later never loses download progress.
        private const val STALE_PARTIAL_DOWNLOAD_MS = 7L * 24 * 60 * 60 * 1000
    }

    /** Stops accepting new downloads; call from `onDestroy`. Same reasoning as the
     *  Activity's own executor shutdown — this only stops accepting *new* downloads,
     *  it doesn't interrupt ones already running. */
    fun shutdown() = downloadExecutor.shutdown()

    fun downloadLatestRunLogs() {
        val token  = activity.etToken.text.toString().trim()
        val repo   = activity.etRepo.text.toString().trim()
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }

        activity.setBusy(true)
        activity.setStatus("Fetching latest run…")
        activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        activity.appendLog("📥 Looking up the latest run to download its log…")

        // Only the quick metadata lookup below runs under activity.setBusy — once the
        // DownloadTask is handed to submitDownload(), the actual transfer runs
        // independently on downloadExecutor (see its kdoc), tracked by the
        // Download Manager rather than the global busy flag, so it no longer
        // blocks starting a build or another download while it's in progress.
        activity.bgExecutor.execute {
            try {
                val owner = activity.lastOwner.ifEmpty {
                    (activity.buildFlowController.fetchOwner(token) ?: run {
                        activity.appendLog("✗ Could not verify token.")
                        activity.setStatus("Failed"); activity.setBusy(false); return@execute
                    }).also { activity.lastOwner = it }
                }

                val runsUrl = "${GitHubApi.apiRuns(owner, repo)}?branch=$branch&per_page=1"
                val (code, body) = GitHubApi.httpGet(token, runsUrl)
                if (code != 200) {
                    activity.appendLog("✗ Could not fetch runs (HTTP $code)")
                    activity.setStatus("Failed"); activity.setBusy(false); return@execute
                }
                val runs = JSONObject(body).getJSONArray("workflow_runs")
                if (runs.length() == 0) {
                    activity.appendLog("⚠ No runs found on branch '$branch'")
                    activity.setStatus("No runs"); activity.setBusy(false); return@execute
                }
                val run           = runs.getJSONObject(0)
                val runId         = run.getLong("id")
                val runNum        = run.getInt("run_number")
                val status        = run.optString("status", "")
                val conclusion    = run.optString("conclusion", "")
                val conclusionStr = conclusion.ifEmpty { "in_progress" }
                activity.appendLog("  Run #$runNum  status=$status  conclusion=$conclusionStr")

                // The redirect to the real log ZIP URL is resolved fresh on every
                // attempt inside performResumableDownload rather than just once
                // here — see its doc comment for why a cached redirect isn't safe
                // to reuse across a real pause.
                val logsUrl = "https://api.github.com/repos/$owner/$repo/actions/runs/$runId/logs"
                val baseName = if (activity.selectedZipName.isNotEmpty())
                    activity.selectedZipName.removeSuffix(".zip").removeSuffix(".ZIP") else "logs"
                val fileName = "${baseName}_build_log.zip"
                // Deterministic name (keyed by runId) so a retry — automatic,
                // manual, or after restarting the app — resumes the same partial
                // file instead of starting over from 0%.
                val tmpFile = File(activity.cacheDir, "logs_tmp_${runId}.zip")

                val task = DownloadTask(
                    id = "log_$runId",
                    displayName = fileName,
                    destFile = tmpFile,
                    resolveUrl = {
                        val conn0 = (URL(logsUrl).openConnection() as HttpURLConnection).apply {
                            requestMethod = "GET"
                            setRequestProperty("Authorization", "token $token")
                            setRequestProperty("Accept", "application/vnd.github+json")
                            instanceFollowRedirects = false
                            connectTimeout = 20_000; readTimeout = 60_000
                        }
                        conn0.connect()
                        val respCode = conn0.responseCode
                        when {
                            respCode in 301..308 -> {
                                val loc = conn0.getHeaderField("Location"); conn0.disconnect(); loc ?: logsUrl
                            }
                            respCode == 200 -> { conn0.disconnect(); logsUrl }
                            else -> {
                                conn0.disconnect()
                                throw Exception(if (status == "completed")
                                    "Logs unavailable for run #$runNum (HTTP $respCode) — GitHub deletes logs after 90 days"
                                else
                                    "Logs not ready yet (HTTP $respCode) — run is still in progress, try again shortly")
                            }
                        }
                    },
                    onSuccess = { t ->
                        requireZipIntegrity(t.destFile, "Build log ZIP")
                        val savedPath = saveZipToDownloads(t.destFile, fileName)
                        t.destFile.delete()
                        t.savedPath = savedPath
                        activity.appendLog("✓ Build log saved to Downloads!")
                        activity.appendLog("  File : $fileName")
                        activity.appendLog("  Path : $savedPath")
                    }
                )
                submitDownload(task)
                activity.appendLog("↻ Downloading — watch the floating icon, or tap 📥 in the header for details.")
                activity.setStatus("Ready ✓")

            } catch (e: Exception) {
                activity.appendLog("✗ Error: ${Formatters.friendlyError(e)}")
                activity.setStatus("Failed")
            } finally {
                activity.setBusy(false)
            }
        }
    }


    /** Every download the manager knows about, newest first. Synchronized since
     *  [downloadExecutor] threads and the main thread both touch it. */
    private val downloadTasks = java.util.Collections.synchronizedList(mutableListOf<DownloadTask>())

    /**
     * Separate from [activity.bgExecutor] on purpose: downloads can be numerous and
     * long-running (paused for minutes waiting on connectivity), and shouldn't be
     * able to starve build/API calls — or vice versa — by sharing one pool. 2
     * workers means up to 2 downloads actually transfer at once; more just queue
     * (shown as status QUEUED) until a slot frees up, which keeps a burst of
     * downloads from saturating a mobile connection.
     */
    private val downloadExecutor: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "download-worker").apply { isDaemon = true }
    }


    /**
     * Starts (or resumes) downloading the given artifact via the Download
     * Manager. Unlike the old single-download flow, this no longer blocks on
     * or sets the global busy flag — the transfer itself runs independently on
     * [downloadExecutor], tracked as a [DownloadTask] the user can watch,
     * pause, or cancel from [showDownloadManagerDialog] at any time, whether or
     * not this specific call is what started it.
     */
    fun downloadArtifact(downloadUrl: String) {
        val token = activity.etToken.text.toString().trim()
        val rawName = activity.prefs.getString(PrefKeys.PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        // Deterministic per-artifact id (not a timestamp) so both the file on disk
        // and the task's identity survive a retry — automatic, manual, or after
        // restarting the app — instead of orphaning progress and starting at 0%.
        val artifactId = stableIdFor(downloadUrl)
        val taskId = "artifact_$artifactId"

        // Tapping the button twice (or once from here and once from a saved
        // build's restore path) shouldn't spawn a second copy of the same
        // download — just surface the one already running.
        val alreadyRunning = synchronized(downloadTasks) { downloadTasks.any { it.id == taskId && !it.isTerminal } }
        if (alreadyRunning) {
            activity.appendLog("ℹ Already downloading '$zipFileName' — see the Download Manager.")
            showDownloadManagerDialog()
            return
        }

        val artifactZip = File(activity.cacheDir, "artifact_$artifactId.zip")
        val task = DownloadTask(
            id = taskId,
            displayName = zipFileName,
            destFile = artifactZip,
            // GitHub's artifact redirect URL expires 1 minute after it's issued
            // (per GitHub's REST API docs), so it's re-resolved fresh on every
            // connection attempt inside performResumableDownload rather than
            // resolved once up front.
            resolveUrl = { resolveGithubRedirect(downloadUrl, token) },
            onSuccess = { t ->
                requireZipIntegrity(t.destFile, "Artifact ZIP")
                val savedPath = saveZipToDownloads(t.destFile, zipFileName)
                t.savedPath = savedPath
                activity.appendLog("✓ Artifact saved to Downloads!")
                activity.appendLog("  File : $zipFileName")
                activity.appendLog("  Path : $savedPath")
                activity.appendLog("  Open your Downloads app to find it anytime.")
                logApkInfoFromZip(t.destFile)
                t.destFile.delete() // the cache copy is no longer needed — it's saved to Downloads now
            }
        )
        submitDownload(task)
        activity.appendLog("📥 Downloading — watch the floating icon, or tap 📥 in the header for details.")
    }

    /** Tracks whether the manager is currently on screen, so submitting a new
     *  download while it's already open updates it instead of stacking a
     *  second dialog on top. */
    private var downloadManagerShowing = false

    /**
     * Shows every [DownloadTask] the app currently knows about — queued,
     * downloading, paused, completed, failed, or cancelled — with per-row
     * controls, and refreshes itself every 400ms while open so progress moves
     * live. Downloads keep running via [downloadExecutor] whether or not this
     * dialog is open; opening it just starts watching what's already
     * happening, and closing it doesn't pause or cancel anything.
     */
    fun showDownloadManagerDialog() {
        if (downloadManagerShowing) return
        val dp = activity.resources.displayMetrics.density

        val listContainer = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(activity).apply {
            addView(listContainer)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (420 * dp).toInt()
            )
        }

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
            addView(scroll)
        }

        val titleBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
            setPadding((18*dp).toInt(), (16*dp).toInt(), (10*dp).toInt(), (12*dp).toInt())
            addView(android.widget.ImageView(activity).apply {
                setImageResource(R.drawable.ic_download)
                imageTintList = android.content.res.ColorStateList.valueOf(0xFF4DA6FF.toInt())
                layoutParams = LinearLayout.LayoutParams((18*dp).toInt(), (18*dp).toInt()).also {
                    it.marginEnd = (10*dp).toInt()
                }
            })
            addView(TextView(activity).apply {
                text = "Download Manager"; textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFFE8EAED.toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(activity.pillButton(
                "Clear finished", ButtonTone.SURFACE, R.drawable.ic_delete,
                textSizeSp = 10.5f, iconSizeDp = 12, horizontalPaddingDp = 8, verticalPaddingDp = 6
            ) {
                synchronized(downloadTasks) { downloadTasks.removeAll { it.isTerminal } }
                renderDownloadRows(listContainer, dp) { }
            })
        }

        lateinit var dialog: AlertDialog
        val content = activity.dialogWithActions(
            root,
            DialogAction("Close", ButtonTone.SURFACE, R.drawable.ic_close) { dialog.dismiss() }
        )
        dialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleBar)
            .setView(content)
            .setCancelable(true)
            .create()

        renderDownloadRows(listContainer, dp) { }

        // Live refresh loop: reflects progress/status changes made by
        // downloadExecutor threads without the user needing to reopen this
        // dialog. Cancels itself the moment the dialog is no longer showing —
        // this is the ONLY place that happens, so it can never leak/keep
        // running after the dialog is dismissed.
        val refreshHandler = Handler(Looper.getMainLooper())
        lateinit var refreshRunnable: Runnable
        refreshRunnable = Runnable {
            if (!downloadManagerShowing) return@Runnable
            renderDownloadRows(listContainer, dp) { }
            refreshHandler.postDelayed(refreshRunnable, 400)
        }
        refreshHandler.postDelayed(refreshRunnable, 400)

        downloadManagerShowing = true
        dialog.setOnDismissListener { downloadManagerShowing = false }
        dialog.show()
    }

    /**
     * Rebuilds every row in [container] from the current [downloadTasks]
     * snapshot. Rebuilding wholesale each refresh tick (rather than diffing)
     * matches how every other list in this app (build/download history) is
     * already drawn, and is cheap enough at the realistic scale of a handful
     * of concurrent/queued downloads. [onChanged] runs after any button in a
     * row mutates task state, so the dialog reflects it immediately rather
     * than waiting for the next 400ms tick.
     */
    private fun renderDownloadRows(container: LinearLayout, dp: Float, onChanged: () -> Unit) {
        val snapshot = synchronized(downloadTasks) { downloadTasks.toList() }
        container.removeAllViews()

        if (snapshot.isEmpty()) {
            container.addView(TextView(activity).apply {
                text = "No downloads yet.\nArtifact and log downloads you start will appear here."
                textSize = 12f; setTextColor(0xFF50587A.toInt())
                gravity = android.view.Gravity.CENTER
                setPadding((24*dp).toInt(), (40*dp).toInt(), (24*dp).toInt(), (40*dp).toInt())
            })
            return
        }

        for (task in snapshot) {
            container.addView(buildDownloadTaskRow(task, dp, onChanged))
            container.addView(android.view.View(activity).apply {
                setBackgroundColor(0xFF232747.toInt())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            })
        }
    }

    /** Builds one row for [task]: name, status/progress, and whichever of
     *  Pause/Resume/Cancel/Retry currently apply to its status. */
    private fun buildDownloadTaskRow(task: DownloadTask, dp: Float, onChanged: () -> Unit): View {
        val statusColor = when (task.status) {
            DownloadTask.Status.COMPLETED -> 0xFF2ECC71.toInt()
            DownloadTask.Status.FAILED    -> 0xFFE74C3C.toInt()
            DownloadTask.Status.CANCELLED -> 0xFF9AA0B8.toInt()
            DownloadTask.Status.PAUSED, DownloadTask.Status.WAITING_FOR_NETWORK -> 0xFFF5A623.toInt()
            else        -> 0xFF5B8DEF.toInt()
        }

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18*dp).toInt(), (12*dp).toInt(), (18*dp).toInt(), (12*dp).toInt())
        }

        row.addView(TextView(activity).apply {
            text = task.displayName; textSize = 12.5f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })

        val pct = if (task.totalBytes > 0) (task.downloadedBytes * 1000L / task.totalBytes).toInt() else 0
        val statusLine = when (task.status) {
            DownloadTask.Status.QUEUED       -> "Queued…"
            DownloadTask.Status.CONNECTING   -> task.detailText.ifEmpty { "Connecting…" }
            DownloadTask.Status.DOWNLOADING  -> {
                val sizeStr = if (task.totalBytes > 0)
                    "${Formatters.fmtBytes(task.downloadedBytes)} / ${Formatters.fmtBytes(task.totalBytes)}" else Formatters.fmtBytes(task.downloadedBytes)
                val etaStr = if (task.etaSeconds >= 0) " · ETA ${Formatters.fmtDuration(task.etaSeconds * 1000)}" else ""
                "$sizeStr · ${Formatters.fmtBytes(task.speedBps)}/s$etaStr"
            }
            DownloadTask.Status.PAUSED              -> "⏸ Paused — ${Formatters.fmtBytes(task.downloadedBytes)} so far"
            DownloadTask.Status.WAITING_FOR_NETWORK -> task.detailText
            DownloadTask.Status.RETRYING            -> task.detailText
            DownloadTask.Status.VERIFYING           -> "Verifying…"
            DownloadTask.Status.SAVING              -> "Saving…"
            DownloadTask.Status.COMPLETED           -> "✓ Saved to Downloads"
            DownloadTask.Status.FAILED              -> "✗ ${task.errorMessage ?: "Failed"}"
            DownloadTask.Status.CANCELLED           -> "Cancelled"
        }
        row.addView(TextView(activity).apply {
            text = statusLine; textSize = 10.5f
            setTextColor(statusColor)
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, (3*dp).toInt(), 0, (6*dp).toInt())
        })

        // Progress bar only while there's real progress to show.
        if (task.status == DownloadTask.Status.DOWNLOADING || task.status == DownloadTask.Status.PAUSED || task.status == DownloadTask.Status.RETRYING) {
            row.addView(android.widget.ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 1000; progress = pct
                progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(
                    android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt()),
                    android.graphics.drawable.ClipDrawable(
                        android.graphics.drawable.ColorDrawable(statusColor),
                        android.view.Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL
                    )
                )).also { ld -> ld.setId(0, android.R.id.background); ld.setId(1, android.R.id.progress) }
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (6*dp).toInt())
                    .also { it.bottomMargin = (8*dp).toInt() }
            })
        }

        val btnRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        fun smallBtn(label: String, tone: ButtonTone, iconRes: Int, onClick: () -> Unit) =
            activity.pillButton(label, tone, iconRes, textSizeSp = 10.5f, iconSizeDp = 13) {
                onClick(); onChanged()
            }.also { it.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { lp -> lp.marginEnd = (8*dp).toInt() } }

        when (task.status) {
            DownloadTask.Status.DOWNLOADING, DownloadTask.Status.CONNECTING, DownloadTask.Status.RETRYING, DownloadTask.Status.WAITING_FOR_NETWORK -> {
                btnRow.addView(smallBtn("Pause", ButtonTone.BLUE, R.drawable.ic_pause) { task.pauseRequested = true })
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.PAUSED -> {
                btnRow.addView(smallBtn("Resume", ButtonTone.GREEN, R.drawable.ic_play) { task.pauseRequested = false })
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.QUEUED -> {
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.FAILED, DownloadTask.Status.CANCELLED -> {
                btnRow.addView(smallBtn("Retry", ButtonTone.BLUE, R.drawable.ic_refresh) { retryDownloadTask(task) })
                btnRow.addView(smallBtn("Remove", ButtonTone.SURFACE, R.drawable.ic_delete) {
                    synchronized(downloadTasks) { downloadTasks.remove(task) }
                })
            }
            DownloadTask.Status.COMPLETED -> {
                btnRow.addView(smallBtn("Remove", ButtonTone.SURFACE, R.drawable.ic_delete) {
                    synchronized(downloadTasks) { downloadTasks.remove(task) }
                })
            }
            DownloadTask.Status.VERIFYING, DownloadTask.Status.SAVING -> { /* brief terminal-adjacent states — no user action needed */ }
        }
        if (btnRow.childCount > 0) row.addView(btnRow)

        return row
    }

    /**
     * Resolves a GitHub API URL that responds with a redirect (301-308) to its
     * real, time-limited download location, following exactly one hop. Called
     * fresh before every connection attempt by [performResumableDownload]
     * rather than cached, since GitHub's own artifact redirect URL expires
     * after 1 minute — reusing an old one after a long pause or a backoff
     * wait would fail with an auth error even though the artifact is fine.
     */
    private fun resolveGithubRedirect(apiUrl: String, token: String): String {
        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            instanceFollowRedirects = false
            connectTimeout = 30_000; readTimeout = 30_000
        }
        conn.connect()
        return if (conn.responseCode in 301..308) {
            val loc = conn.getHeaderField("Location")
            conn.disconnect()
            loc ?: apiUrl
        } else {
            conn.disconnect()
            apiUrl
        }
    }

    /**
     * Best-effort stable id for [downloadUrl], used to name the resumable temp
     * file so a retry reuses the same partial bytes instead of starting over.
     * GitHub's artifact download URL embeds the numeric artifact id
     * (".../actions/artifacts/{id}/zip"); anything else falls back to a hash
     * of the full URL so this can never throw.
     */
    private fun stableIdFor(downloadUrl: String): String =
        Regex("artifacts/(\\d+)").find(downloadUrl)?.groupValues?.get(1)
            ?: downloadUrl.hashCode().toString()

    /**
     * Runs [task] end-to-end on the calling thread: the byte transfer via
     * [performResumableDownload], then — on success — [DownloadTask.onSuccess]
     * (which does the save-to-Downloads/integrity-report work specific to each
     * download kind). Leaves [task].status in a terminal state (COMPLETED /
     * FAILED / CANCELLED) no matter how it ends, so the manager UI never has to
     * guess. Must be called from a [downloadExecutor] thread, never the main one.
     */
    private fun runDownloadTask(task: DownloadTask) {
        try {
            performResumableDownload(task)
            task.onSuccess(task)
            task.status = DownloadTask.Status.COMPLETED
            task.detailText = "Done"
            activity.floatingTransferIndicator.complete(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                showDownloadManagerDialog()
            }
        } catch (e: Exception) {
            if (e.message == "Cancelled by user") {
                task.status = DownloadTask.Status.CANCELLED
                task.detailText = "Cancelled"
                activity.appendLog("⚠ Download cancelled: ${task.displayName}")
            } else {
                task.status = DownloadTask.Status.FAILED
                task.errorMessage = Formatters.friendlyError(e)
                task.detailText = "Failed"
                activity.appendLog("✗ Download failed: ${task.displayName} — ${Formatters.friendlyError(e)}")
                activity.floatingTransferIndicator.fail(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                    showDownloadManagerDialog()
                }
            }
        }
    }

    /** Registers [task] with the manager (newest first) and starts it running. */
    private fun submitDownload(task: DownloadTask) {
        downloadTasks.add(0, task)
        downloadExecutor.execute { runDownloadTask(task) }
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showDownloadManagerDialog() }
    }

    /**
     * Resubmits a FAILED or CANCELLED task from scratch. Safe to call any time
     * after [runDownloadTask] has left it in a terminal state — any bytes already
     * on [DownloadTask.destFile] are untouched, so this resumes rather than
     * restarting, exactly like the automatic retry path does.
     */
    private fun retryDownloadTask(task: DownloadTask) {
        if (!task.isTerminal) return
        task.cancelRequested = false
        task.pauseRequested  = false
        task.errorMessage    = null
        task.status = DownloadTask.Status.QUEUED
        task.detailText = "Queued…"
        downloadExecutor.execute { runDownloadTask(task) }
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showDownloadManagerDialog() }
    }

    // ── Floating download bubble ────────────────────────────────────────────
    // Replaces the old behavior of force-opening showDownloadManagerDialog()
    // every time a download started. Instead of tracking live progress on the
    // bubble, it just flashes briefly when a download is queued and again
    // (a bit differently — checkmark/warning instead of the plain download
    // icon) once it finishes; the running percentage/speed detail stays
    // exclusively inside the Download Manager dialog, which the bubble opens
    // on tap. See FloatingTransferIndicator's kdoc for the full rationale.

    /**
     * Downloads from whatever URL [task]'s `resolveUrl` returns into
     * [task].destFile, resuming from any bytes already on disk via an HTTP Range
     * request when the server honors it. Reports all progress and status purely
     * through [task]'s own fields — this function never touches a View or posts
     * to [activity.mainHandler] — so it behaves identically whether or not the Download
     * Manager is currently on screen to show it, and so multiple instances of
     * this function (one per [downloadExecutor] worker) can run at once without
     * fighting over shared state the way the single-download version did.
     *
     * `resolveUrl` is called again before every connection attempt — not just
     * once — because the GitHub endpoints this feeds from redirect to a
     * short-lived signed URL, so a stale cached URL would fail after any real
     * pause.
     *
     * - [task].pauseRequested / [task].cancelRequested are checked continuously
     *   and are driven by the manager UI's per-row buttons, which work whether
     *   or not that UI is currently open.
     * - A dropped connection while the device is genuinely offline pauses
     *   automatically (status `WAITING_FOR_NETWORK`) and resumes the instant
     *   connectivity returns (see [waitForNetwork]) — this never counts against
     *   [maxRetries]; it's a wait, not a failure.
     * - A transient server-side error (HTTP 429/500/502/503/504) or an I/O
     *   error that occurs while the network still tests as reachable retries
     *   with exponential backoff (2s, 4s, 8s… capped at 30s) up to [maxRetries]
     *   times.
     * - A resume the server rejects (HTTP 416 — the local partial no longer
     *   matches what the server has) is discarded and restarted from 0% once;
     *   a repeat 416 on that fresh attempt is fatal rather than looping forever.
     * - Anything else (storage full, HTTP 401/403/404, cancellation) is fatal
     *   immediately.
     *
     * Must be called from a [downloadExecutor] thread. [task].destFile's bytes
     * on disk are preserved across every failure path, so resubmitting the same
     * task later (see [retryDownloadTask]) resumes instead of restarting.
     */
    private fun performResumableDownload(task: DownloadTask, maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES) {
        val destFile = task.destFile
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        var rangeRestartUsed = false

        while (true) {
            if (task.cancelRequested) throw Exception("Cancelled by user")
            val existingBytes = if (destFile.exists()) destFile.length() else 0L
            var conn: HttpURLConnection? = null

            try {
                task.status = DownloadTask.Status.CONNECTING
                task.detailText = if (existingBytes > 0) "Resuming…" else "Connecting…"
                val c = (URL(task.resolveUrl()).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    if (existingBytes > 0) setRequestProperty("Range", "bytes=$existingBytes-")
                    connectTimeout = 60_000
                    readTimeout    = 300_000
                }
                conn = c
                c.connect()
                val code = c.responseCode

                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    c.disconnect()
                    if (code == 416) {
                        if (rangeRestartUsed) {
                            throw Exception("Server rejected the download range even after restarting from 0% (HTTP 416).")
                        }
                        rangeRestartUsed = true
                        task.detailText = "Server rejected resume — restarting from 0%…"
                        destFile.delete()
                        continue
                    }
                    if (code in NetworkReliability.RETRYABLE_HTTP_CODES) {
                        retryAttempt++
                        if (retryAttempt > maxRetries) {
                            throw Exception("Server returned HTTP $code — gave up after $maxRetries retries.")
                        }
                        notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                        networkReliability.sleepCancellable(backoffMs) { task.cancelRequested }
                        backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                        continue
                    }
                    throw Exception("Download failed (HTTP $code).")
                }

                // A server that ignores our Range header sends the whole file
                // again from byte 0 — discard the stale partial bytes rather
                // than corrupt the file by appending fresh content onto it.
                val serverIgnoredRange = existingBytes > 0 && code == HttpURLConnection.HTTP_OK
                if (serverIgnoredRange) destFile.delete()
                val effectiveExisting = if (serverIgnoredRange) 0L else existingBytes

                val contentLen = c.contentLengthLong
                val total = when {
                    code == HttpURLConnection.HTTP_PARTIAL ->
                        c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                            ?: (if (contentLen >= 0) contentLen + effectiveExisting else -1L)
                    contentLen >= 0 -> contentLen + effectiveExisting
                    else -> -1L
                }

                val remainingNeeded = if (total > 0) (total - effectiveExisting).coerceAtLeast(0L) else 0L
                if (!hasEnoughStorage(destFile.parentFile ?: activity.cacheDir, remainingNeeded)) {
                    c.disconnect()
                    throw Exception("Not enough free storage for this download (need ~${Formatters.fmtBytes(remainingNeeded)} more).")
                }

                var downloaded = effectiveExisting
                task.totalBytes      = total
                task.downloadedBytes = downloaded
                task.status          = DownloadTask.Status.DOWNLOADING
                task.detailText       = ""

                val buf = ByteArray(32 * 1024)
                var speedStartTime  = System.currentTimeMillis()
                var speedStartBytes = downloaded

                c.inputStream.use { inp ->
                    FileOutputStream(destFile, effectiveExisting > 0).use { out ->
                        while (true) {
                            if (task.cancelRequested) throw Exception("Cancelled by user")
                            if (task.pauseRequested) {
                                task.status = DownloadTask.Status.PAUSED
                                while (task.pauseRequested) {
                                    if (task.cancelRequested) throw Exception("Cancelled by user")
                                    Thread.sleep(150)
                                }
                                task.status = DownloadTask.Status.DOWNLOADING
                            }

                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n
                            task.downloadedBytes = downloaded

                            val now     = System.currentTimeMillis()
                            val elapsed = now - speedStartTime
                            if (elapsed >= 200) {
                                val speedBps = (downloaded - speedStartBytes) * 1000L / elapsed.coerceAtLeast(1)
                                speedStartTime  = now; speedStartBytes = downloaded
                                task.speedBps = speedBps
                                val remaining = if (total > 0) (total - downloaded).coerceAtLeast(0) else -1L
                                task.etaSeconds = if (total > 0 && speedBps > 0) remaining / speedBps else -1L
                            }
                        }
                    }
                }
                c.disconnect()
                if (task.cancelRequested) throw Exception("Cancelled by user")

                task.downloadedBytes = downloaded
                task.status = DownloadTask.Status.VERIFYING
                task.detailText = "Verifying…"
                return

            } catch (e: Exception) {
                conn?.disconnect()
                if (e.message == "Cancelled by user") throw e
                // Only an I/O-ish failure is eligible for the automatic paths
                // below — e.g. the storage-full Exception thrown above is
                // fatal regardless of connectivity.
                if (e !is java.io.IOException) throw e

                if (!networkReliability.isNetworkAvailable()) {
                    task.status = DownloadTask.Status.WAITING_FOR_NETWORK
                    task.detailText = "⚠ Paused (No Internet) — will resume automatically"
                    val reconnected = networkReliability.waitForNetwork { task.cancelRequested }
                    if (!reconnected) throw Exception("Cancelled by user")
                    task.status = DownloadTask.Status.DOWNLOADING
                    task.detailText = ""
                    continue
                }

                retryAttempt++
                if (retryAttempt > maxRetries) {
                    throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                }
                notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                networkReliability.sleepCancellable(backoffMs) { task.cancelRequested }
                backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
            }
        }
    }

    /** Sets a "retrying in Ns… (attempt X/Y)" status on [task]. */
    private fun notifyRetrying(task: DownloadTask, attempt: Int, max: Int, backoffMs: Long) {
        task.status = DownloadTask.Status.RETRYING
        task.detailText = "Retrying in ${backoffMs / 1000}s… (attempt $attempt/$max)"
    }

    // ── Integrity verification ────────────────────────────────────────────────

    /**
     * Verifies a downloaded ZIP is structurally intact: every entry's data can
     * be fully read and its CRC-32 (stored in the ZIP itself) matches what
     * [ZipInputStream] recomputes while decompressing — the standard signal
     * a ZIP was truncated or corrupted in transit. This is deliberately a full
     * read of every entry's bytes (discarded, not held in memory) rather than
     * just opening the central directory, since a truncated download can
     * still have a readable entry listing but fail partway through the actual
     * data.
     *
     * Used right after a download finishes and before it's saved to Downloads
     * or reported as successful — see [downloadArtifact] and
     * [downloadLatestRunLogs] — so a corrupted result is caught immediately
     * instead of silently handing the user a broken file. An empty ZIP (zero
     * entries) is treated as invalid too: a real artifact or log archive
     * always contains at least one entry.
     *
     * Runs on the calling (background) thread; never touches the UI.
     */
    private fun verifyZipIntegrity(file: File): Boolean {
        if (!file.exists() || file.length() == 0L) return false
        return try {
            var entryCount = 0
            ZipInputStream(file.inputStream().buffered()).use { zis ->
                val sink = ByteArray(64 * 1024)
                var entry = zis.nextEntry
                while (entry != null) {
                    // Fully drain the entry so ZipInputStream verifies its CRC-32
                    // against the value stored in the ZIP — a mismatch throws.
                    while (zis.read(sink) >= 0) { /* discard */ }
                    zis.closeEntry()
                    entryCount++
                    entry = zis.nextEntry
                }
            }
            entryCount > 0
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Throws if [file] fails [verifyZipIntegrity], after deleting it. This is
     * the one case where deleting a download is correct instead of preserving
     * it for a future resume — the brief's own rule is "never delete partial
     * downloads unless they are corrupted," and a failed CRC check is exactly
     * that determination, not a guess. The thrown message is picked up by the
     * caller's existing catch block, which already offers a manual Retry.
     */
    private fun requireZipIntegrity(file: File, label: String) {
        if (!verifyZipIntegrity(file)) {
            file.delete()
            throw Exception("$label failed integrity verification (corrupted or truncated) — please retry.")
        }
    }

    /**
     * Peeks inside a downloaded artifact ZIP for the first `.apk` entry, verifies
     * it as a real APK (via `PackageManager.getPackageArchiveInfo`), and logs its
     * package name, version, and min/target SDK — a quick sanity check of what
     * actually got built, without installing it first. This is the APK-level
     * complement to [verifyZipIntegrity]'s ZIP-level (CRC) check: the ZIP check
     * confirms the bytes arrived intact, this confirms those bytes actually
     * parse as a valid APK. Best-effort: any failure here is logged as a soft
     * note and never interrupts the download flow, since it's a nice-to-have
     * layered on top of the save-to-Downloads path.
     */
    private fun logApkInfoFromZip(zipFile: File) {
        var tempApk: File? = null
        try {
            ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".apk", ignoreCase = true)) {
                        val dest = File(activity.cacheDir, "apkinfo_${System.currentTimeMillis()}.apk")
                        FileOutputStream(dest).use { out -> zis.copyTo(out) }
                        tempApk = dest
                        break
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            val apkFile = tempApk ?: return // no .apk inside (e.g. a logs-only artifact)
            @Suppress("DEPRECATION")
            val pkgInfo = activity.packageManager.getPackageArchiveInfo(apkFile.absolutePath, 0)
            if (pkgInfo == null) {
                // The containing ZIP already passed a full CRC-32 check (see
                // verifyZipIntegrity/requireZipIntegrity), so the .apk's bytes
                // themselves arrived intact — but PackageManager still couldn't
                // parse it as a valid APK (e.g. a malformed manifest). Surface
                // that distinctly rather than silently saying nothing, since
                // it's a real (if rare) signal the build output itself is broken.
                activity.appendLog("⚠ APK integrity check failed — the file could not be parsed as a valid APK.")
                return
            }
            val appInfo = pkgInfo.applicationInfo
            activity.appendLog("─────────────────────────────────────")
            activity.appendLog("📦 APK Info")
            activity.appendLog("  ✓ Integrity verified (manifest parsed OK)")
            activity.appendLog("  Package  : ${pkgInfo.packageName}")
            @Suppress("DEPRECATION")
            activity.appendLog("  Version  : ${pkgInfo.versionName ?: "?"} (code ${pkgInfo.versionCode})")
            if (appInfo != null) {
                activity.appendLog("  SDK      : min ${appInfo.minSdkVersion} · target ${appInfo.targetSdkVersion}")
            }
            activity.appendLog("  APK size : ${Formatters.fmtBytes(apkFile.length())}")
        } catch (e: Exception) {
            activity.appendLog("ℹ Could not read APK info: ${e.message}")
        } finally {
            tempApk?.delete()
        }
    }

    // ── Download History ──────────────────────────────────────────────────────

    private fun addDownloadToHistory(name: String, path: String, sizeBytes: Long) {
        val arr = try {
            JSONArray(activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_HISTORY, "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }

        val entry = JSONObject().apply {
            put("name", name)
            put("path", path)
            put("size", sizeBytes)
            put("time", System.currentTimeMillis())
        }
        // Prepend newest first, cap at 30
        val newArr = JSONArray()
        newArr.put(entry)
        for (i in 0 until minOf(arr.length(), 29)) newArr.put(arr.getJSONObject(i))
        activity.prefs.edit().putString(PrefKeys.PREF_DOWNLOAD_HISTORY, newArr.toString()).apply()
    }

    fun loadDownloadHistory(): List<JSONObject> {
        val arr = try {
            JSONArray(activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_HISTORY, "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }
    private fun saveZipToDownloads(zipFile: File, fileName: String): String {
        val savedPath = saveZipToDownloadsInternal(zipFile, fileName)
        addDownloadToHistory(fileName, savedPath, zipFile.length())
        return savedPath
    }

    /**
     * Saves [zipFile] to the public Downloads directory as [fileName] (a .zip).
     *
     * Android 10+ (API 29+): MediaStore API — no storage permission required.
     * Android 7–9  (API 24–28): direct file write (needs WRITE_EXTERNAL_STORAGE).
     *
     * Returns the absolute path of the saved file.
     */
    private fun saveZipToDownloadsInternal(zipFile: File, fileName: String): String {
        // Use custom folder if the user picked one
        val customUriStr = activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_URI, null)
        if (!customUriStr.isNullOrEmpty()) {
            val treeUri = Uri.parse(customUriStr)
            val docUri  = androidx.documentfile.provider.DocumentFile
                .fromTreeUri(activity, treeUri)
                ?.createFile("application/zip", fileName)
                ?.uri
                ?: throw Exception("Cannot create file in selected folder")
            UriUtils.openOutputStreamOrThrow(activity.contentResolver, docUri).use { out ->
                zipFile.inputStream().use { it.copyTo(out) }
            }
            return docUri.toString()
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — MediaStore.Downloads (no permission needed)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads
                .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = activity.contentResolver.insert(collection, values)
                ?: throw Exception("MediaStore insert failed.")

            UriUtils.openOutputStreamOrThrow(activity.contentResolver, itemUri).use { out ->
                zipFile.inputStream().use { it.copyTo(out) }
            }

            // Clear IS_PENDING so it appears in Downloads app right away
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            activity.contentResolver.update(itemUri, values, null, null)

            // On a filename collision (e.g. downloading the same artifact twice),
            // MediaStore silently renames to "name (1).zip" rather than overwriting —
            // query back the name it actually used instead of assuming our request
            // was honoured verbatim, so the path we report/log/save to history is real.
            val actualName = activity.contentResolver.query(
                itemUri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: fileName

            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .absolutePath + "/$actualName"

        } else {
            // Android 7–9 — direct file write (needs WRITE_EXTERNAL_STORAGE)
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val dest = File(dir, fileName)
            zipFile.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }

    fun cleanupStaleCacheFiles() {
        val shortLived  = setOf("apkinfo_")
        val longLived   = setOf("artifact_", "logs_tmp_")
        val now = System.currentTimeMillis()
        val staleShortBefore = now - 2 * 60_000L
        val stalePartialBefore = now - STALE_PARTIAL_DOWNLOAD_MS
        try {
            var freedBytes = 0L
            var deletedCount = 0
            activity.cacheDir.listFiles()?.forEach { f ->
                val threshold = when {
                    shortLived.any { f.name.startsWith(it) } -> staleShortBefore
                    longLived.any  { f.name.startsWith(it) } -> stalePartialBefore
                    else -> return@forEach
                }
                if (f.lastModified() < threshold) {
                    val len = f.length()
                    if (f.delete()) { deletedCount++; freedBytes += len }
                }
            }
            if (deletedCount > 0) {
                activity.appendLog("🧹 Cleaned up $deletedCount leftover temp file(s) (${Formatters.fmtBytes(freedBytes)}) from a previous session.")
            }
        } catch (_: Exception) {
            // Cache cleanup is a hygiene nice-to-have — never worth surfacing an error for.
        }
    }

    /**
     * Checks the target directory's filesystem for enough free space before
     * starting a download, so a large artifact fails fast with a clear message
     * instead of partway through with a confusing IOException. Content-length
     * of 0 or less (GitHub didn't report a size) skips the check rather than
     * blocking a legitimate download over a number we don't actually have.
     */
    private fun hasEnoughStorage(dir: File, requiredBytes: Long): Boolean {
        if (requiredBytes <= 0) return true
        return try {
            dir.usableSpace > requiredBytes + 10 * 1024 * 1024 // +10 MB safety margin
        } catch (_: Exception) {
            true // if we can't tell, don't block the download over it
        }
    }
}
