"""Checks the swipe logic (a Python port of Picker.kt) on the dumped geometry of every puzzle:
every visible sticker can be picked, and drags turn the layer you expect. Usage: picker_check.py <dir with geo_<id>.txt>"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import preview as P

GEO_DIR = sys.argv[1] if len(sys.argv) > 1 else '.'

MIN_ALIGN, FACE_PEN, TIE = 0.17, 0.7, 0.02

def setup(g, W, H, yaw, pitch):
    VP = P.camera(W, H, g['radius']); O = P.orbit(yaw, pitch)
    return VP @ O

def project(M, p, W, H):
    h = M @ np.array([p[0], p[1], p[2], 1.0]); h = h/h[3]
    return np.array([(h[0]*0.5+0.5)*W, (1-(h[1]*0.5+0.5))*H])

def unproject(Minv, sx, sy, z, W, H):
    v = Minv @ np.array([2*sx/W-1, 1-2*sy/H, z, 1.0]); return v[:3]/v[3]

def inside(s, p):
    n = s['n']; N = s['normal']
    for k in range(n):
        a = s['corners'][k]; b = s['corners'][(k+1) % n]
        if np.dot(np.cross(b-a, p-a), N) < -1e-4: return False
    return True

def pick(g, M, Minv, sx, sy, W, H):
    o = unproject(Minv, sx, sy, -1, W, H); f = unproject(Minv, sx, sy, 1, W, H)
    d = (f-o)/np.linalg.norm(f-o)
    best, bt = -1, 1e30
    for i, s in enumerate(g['stickers']):
        den = float(np.dot(d, s['normal']))
        if den > -1e-5: continue
        t = float(np.dot(s['centroid']-o, s['normal']))/den
        if t < 0 or t >= bt: continue
        if inside(s, o+d*t): best, bt = i, t
    return best

def layer_sizes(g):
    return [sum(1 for s in g['stickers'] if P.in_layer(g, m, s['centroid'])) for m in range(len(g['moves']))]

def swipe(g, M, W, H, sticker, dx, dy, sizes):
    s = g['stickers'][sticker]; c = s['centroid']; nrm = s['normal']
    dl = math.hypot(dx, dy); start = project(M, c, W, H)
    scores = {}; top = -2.0
    for m, mv in enumerate(g['moves']):
        if not P.in_layer(g, m, c): continue
        a = mv['axis']; v = np.cross(a, c)
        if mv['angle'] < 0: v = -v
        vl = np.linalg.norm(v)
        if vl < 1e-3: continue
        e = project(M, c + v*(0.25/vl), W, H) - start; el = np.linalg.norm(e)
        if el < 1e-3: continue
        sc = (dx*e[0]+dy*e[1])/(dl*el)
        if abs(float(np.dot(a, nrm))) > 0.9: sc *= FACE_PEN
        scores[m] = sc; top = max(top, sc)
    if g['name'] == 'Skewb' and s['n'] == 3 and scores:   # a corner twists itself (mirror of Picker.kt)
        d = {m: float(np.dot(c, c) - (np.dot(c, g['moves'][m]['axis'])/np.linalg.norm(g['moves'][m]['axis']))**2) for m in scores}
        dm = min(d.values()); own = min(m for m in d if d[m] <= dm + 1e-4)
        pick = max((own, own ^ 1), key=lambda m: scores.get(m, -2.0))
        if scores.get(pick, -2.0) >= 0.2: return pick
    if top < MIN_ALIGN: return -1
    best = -1
    for m, sc in scores.items():
        if sc >= top - TIE and (best < 0 or sizes[m] < sizes[best]): best = m
    return best

def run(idx, yaw, pitch, W=540, H=720):
    g = P.load(os.path.join(GEO_DIR, f'geo_{idx}.txt')); M = setup(g, W, H, yaw, pitch); Minv = np.linalg.inv(M)
    sizes = layer_sizes(g); names = [m['name'] for m in g['moves']]
    visible = 0; misses = 0; dead = 0; total = 0; tipbad = 0; tips = 0
    for i, s in enumerate(g['stickers']):
        if np.dot(s['normal'], (P.orbit(yaw, pitch)[:3,:3].T @ np.array([0,0,1.0]))) <= 0.05: continue   # facing the camera?
        sp = project(M, s['centroid'], W, H)
        got = pick(g, M, Minv, sp[0], sp[1], W, H)
        visible += 1
        if got != i: misses += 1; continue
        for k in range(16):
            ang = 2*math.pi*k/16; mv = swipe(g, M, W, H, i, 40*math.cos(ang), 40*math.sin(ang), sizes); total += 1
            if mv < 0: dead += 1
        if g['name'] == 'Pyraminx':
            # a tip sticker is in exactly the 3-sticker tip layers: some drag direction must turn that tip alone
            in_tip = [m for m in range(len(names)) if sizes[m] == 3 and P.in_layer(g, m, s['centroid'])]
            if in_tip:
                tips += 1
                moves = {swipe(g, M, W, H, i, 40*math.cos(2*math.pi*k/16), 40*math.sin(2*math.pi*k/16), sizes) for k in range(16)}
                if not (moves & set(in_tip)): tipbad += 1
    print(f"{g['name']:9s} view({yaw},{pitch}): visible stickers {visible}, pick misses {misses}, drags with no move {dead}/{total}, tip stickers {tips} (cannot turn tip alone: {tipbad})")

for idx, yaw, pitch in [(0,-35,28),(1,-35,28),(1,-4,10),(2,-35,28),(3,-35,28),(4,-42,24),(4,140,24),(5,-35,28)]:
    run(idx, yaw, pitch)
