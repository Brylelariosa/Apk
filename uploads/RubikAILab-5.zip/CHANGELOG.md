# Changelog

## 2.4 - 2026-10-23
- Skewb: a swipe on a corner piece (a triangle sticker) now twists that corner, the turn about the axis through it, for any drag that roughly follows the way the sticker travels (12 to 14 of 16 drag directions; before, 0 to 8, so the corner often seemed stuck because a neighbouring corner's turn won). Diamond (centre) stickers choose as before. Host check: tests/preview/picker_check.py mirrors the rule.
- Layout: the puzzle view now fills the whole Play page, under the top bar and the buttons, which float over it. The camera (gl/Camera.kt) sizes the puzzle to the free space between them and centres it there, and fits it tighter (97% of the free width instead of about 81%): the Skewb's resting view is about 79% of the screen width instead of 65%.
- Top band: the camera-hole inset is no longer applied to the whole screen. It goes to the pages (PageView.setTopInset); a small centred hole reserves almost nothing, a wide notch or a hole near a control reserves its full height.
- Kotlin only, not compiled here; bracket-checked, camera and swipe maths checked on the host (tests/preview).

## 2.3 - 2026-10-23
- View: no pitch limit any more, the puzzle can be turned over the top and under the bottom; the sideways drag is mirrored while it is upside down so it follows the finger.
- New face strip (gl/FacePreview.kt) over the puzzle: one small picture per face with its current colours; tap one and the view swings to look straight at that face.
- Play settings (the sliders icon) has a View > Face previews switch that hides or shows the strip; it applies at once and is remembered.
- Fullscreen: status and navigation bars hidden (swipe from the edge to show them briefly) and the window runs under a camera hole or notch (layoutInDisplayCutoutMode shortEdges); controls are padded clear of the cutout.
- Kotlin only, not compiled here (no Kotlin compiler in the authoring sandbox); bracket-checked, and the look-at-face and upside-down drag maths were checked numerically.

## v2.2 (2026-10-22)
Cube and Pyraminx look and handling, from the owner's report: thick block lines, a wrong-looking Pyraminx, black
lines / pieces that did not turn with their layer, and the view spinning freely.
- Pieces: the dark bodies are now real pieces. Each puzzle is cut by the planes its moves turn about (`solid::`
  in core/puzzle.cpp: convex cells by half-space clipping) giving 8 / 27 / 64 / 125 cubies, 15 Pyraminx pieces
  (4 tips, 4 axial, 6 edges, hidden core) and 14 Skewb pieces. Every piece lies entirely inside or outside every
  turning layer, so it turns with a layer or stays, never half of each. This replaces the per-sticker tapered
  "frustum" bodies and the static core, which slid through each other when a Pyraminx layer turned.
- Look: stickers are inset by a fixed margin (`stickerInset`, so every dark line is equally thin on cubes,
  triangles and diamonds) with rounded corners (`stickerRound`, gl/StickerShape.kt) instead of 14% shrink with
  chamfered corners; piece edges are chamfered; the body colour is lighter than the background so the puzzle reads as
  a solid object and its black plastic is visible while layers turn.
- Pyraminx: now a solid tetrahedron of real pieces, starts in an edge-on view where two faces read clearly
  (`Puzzles.viewYaw/viewPitch`; cubes keep -35 / 28). Swiping a tip sticker now turns the tip on its own
  (u / l / r / b): of equally good layers the smallest wins. Before, tips could only turn together with the layer
  below, so tip scrambles could not be undone by hand.
- Gestures: a drag that starts on the puzzle (including its dark lines) never rotates the view any more; it turns a
  layer (within about 80 degrees of the layer's direction) or does nothing. Drag on the empty background, or use
  "Rotate view", to look around. A new puzzle starts in its own default view.
- JNI: `nativePuzzleStyle` now returns [radius, inset, lift, round] (was radius, scale, lift). `PuzzleModel.stickerScale`
  became `stickerInset` and `stickerRound` was added.
- Tests: host tests check the piece counts, that no piece corner lies across a layer boundary (rigid pieces), that
  piece faces point outward and that every sticker sits on a piece that is in exactly its layers.
  `tests/preview/` renders the puzzles on the host (camera, shading and mesh rules mirror the Kotlin renderer) and
  re-checks the swipe logic; see BUILD.md.

## v2.1 (2026-10-21)
- Build fix: CI run 1868 (release build) stopped in compileReleaseKotlin with
  `PlayPage.kt:66:17 Variable 'timerView' must be initialized`. The timer Runnable (`ticker`) was declared
  above the `init` block that assigns `timerView`; it now sits below that block. No behaviour change.
- That run had already built the native library for all four ABIs (x86, x86_64, arm64-v8a, armeabi-v7a)
  without errors, so only the Kotlin step was left to fix. The rebuild has not been run yet.

## v2
- Six puzzles: 2x2, 3x3, 4x4, 5x5, Pyraminx, Skewb, all built from one generic geometry-driven model.
  The 3x3 now also has middle-layer turns.
- AI for 2x2, 3x3, Pyraminx and Skewb with one network and checkpoint per puzzle.
- Training: pool-based value iteration (each expensive target is reused for several gradient steps),
  newest-depth sampling, deeper default curriculum for the 3x3 (16), progress reporting per round.
- Heat: Cool / Balanced / Fast presets, thermal governor with duty cycling, background priority, thread caps.
- Train tab: live view of the AI practising on fresh scrambles, round progress, chart, temperature and effort.
- Play tab: swipe to turn layers, drag to look around, timer with personal bests, turn pad, AI solve.
- Test tab: held-out or fresh scrambles, learned AI or conventional baseline, saved results.
- Layout: every main control fits on one screen without scrolling; vector icons; bottom navigation.
- Checkpoints are now per puzzle (checkpoint_<id>.bin, format version 3). The v1 checkpoint is not read.
