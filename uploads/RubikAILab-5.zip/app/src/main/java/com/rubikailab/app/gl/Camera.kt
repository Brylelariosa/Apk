package com.rubikailab.app.gl

import android.opengl.Matrix
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * The one camera of the app. The renderer and the touch picking both use it, so what is drawn is
 * exactly what is hit. Everything is a pure function of plain numbers, so any thread may call it.
 */
object Camera {
    private const val FOV_DEGREES = 34f

    /** The puzzle's bounding sphere fills this much of the free area, so no turn of the view can clip it. */
    private const val FILL = 0.97f
    private val TAN_HALF = tan(Math.toRadians(FOV_DEGREES / 2.0)).toFloat()

    /**
     * out = projection * view for a viewport of the given size. The view runs under the top bar and the buttons;
     * [freeTop] and [freeBottom] (pixels) are the strips they cover. The puzzle is sized to the free area between
     * them and centred in it, so it uses all the room that is left, from the top bar down to the buttons.
     */
    fun projectionView(out: FloatArray, width: Int, height: Int, radius: Float, freeTop: Float, freeBottom: Float) {
        val h = if (height > 0) height.toFloat() else 1f
        val aspect = if (height > 0) width.toFloat() / h else 1f
        val fraction = ((h - freeTop - freeBottom) / h).coerceIn(0.25f, 1f)
        val u = TAN_HALF * minOf(aspect, fraction) * FILL // tangent of the sphere's apparent half angle
        val dist = radius * sqrt(1f + 1f / (u * u))
        val proj = FloatArray(16)
        val view = FloatArray(16)
        val pv = FloatArray(16)
        val shift = FloatArray(16)
        Matrix.perspectiveM(proj, 0, FOV_DEGREES, aspect, maxOf(0.1f, dist - radius * 2.2f), dist + radius * 2.2f)
        Matrix.setLookAtM(view, 0, 0f, 0f, dist, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(pv, 0, proj, 0, view, 0)
        Matrix.setIdentityM(shift, 0)
        shift[13] = (freeBottom - freeTop) / h // moves the picture to the middle of the free area
        Matrix.multiplyMM(out, 0, shift, 0, pv, 0)
    }

    /** The turn of the whole puzzle by the user's drag: pitch about x after yaw about y. */
    fun orbit(out: FloatArray, yaw: Float, pitch: Float) {
        Matrix.setIdentityM(out, 0)
        Matrix.rotateM(out, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(out, 0, yaw, 0f, 1f, 0f)
    }
}
