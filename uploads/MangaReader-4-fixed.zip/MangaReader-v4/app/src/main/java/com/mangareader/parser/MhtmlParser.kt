package com.mangareader.parser

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.io.File
import java.io.InputStream

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * MHTML stores images as base64-encoded MIME parts separated by a boundary string.
 * We read the file with ISO-8859-1 so byte values are preserved in the char range,
 * split on the boundary, then decode each image part's base64 body.
 *
 * Page ordering:
 * Browsers (Blink/Chrome) cache images in the order they are *fetched*, which is
 * often the reverse of reading order (lazy-loading from the bottom up, or CDN
 * pre-fetch order).  We cannot rely on MIME-part sequence.  Instead we read the
 * Content-Location header on each image part — it contains the original URL whose
 * filename encodes the real page number (e.g. "0116-001.png").  We extract that
 * number and name the output file accordingly so that a simple alphabetical sort
 * produces the correct reading order.
 *
 * Non-page images (logos, icons, etc.) do not follow the "-NNN.ext" pattern and
 * are skipped entirely.
 */
class MhtmlParser(private val context: Context) {

    // Matches the page number right before the extension: "0116-007.png" → "7"
    private val pageNumRegex = Regex("""-0*(\d+)\.\w+\s*$""")

    fun extractImages(mhtmlPath: String, cacheDir: File): List<File> {
        return try {
            val stream: InputStream = if (mhtmlPath.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(mhtmlPath))
                    ?: return emptyList()
            } else {
                File(mhtmlPath).inputStream()
            }
            extractImages(stream, cacheDir)
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun extractImages(inputStream: InputStream, cacheDir: File): List<File> {
        cacheDir.mkdirs()
        val images = mutableListOf<File>()
        // Fallback counter used only when the URL contains no numeric page suffix
        var fallbackIndex = 0

        try {
            // ISO-8859-1 preserves raw bytes 1-to-1 as chars — safe for base64 content
            val content = inputStream.use { it.bufferedReader(Charsets.ISO_8859_1).readText() }

            // Locate MIME boundary
            val boundaryMatch = Regex(
                """boundary=["']?([^"'\r\n;]+)["']?""",
                RegexOption.IGNORE_CASE
            ).find(content) ?: return emptyList()
            val boundary = boundaryMatch.groupValues[1].trim()
            val delimiter = "--$boundary"

            val parts = content.split(delimiter)
            // parts[0] = global headers preamble, skip it
            // parts[last] starts with "--" (end boundary marker), skip it

            for (part in parts.drop(1)) {
                val trimmed = part.trimStart('\r', '\n')
                if (trimmed.startsWith("--")) continue   // closing "--" marker

                // Only handle base64-encoded image parts
                if (!part.contains("Content-Type: image/", ignoreCase = true)) continue
                if (!part.contains("base64", ignoreCase = true)) continue

                // Split headers from body at the first blank line
                val sepIdx = part.indexOf("\r\n\r\n").takeIf { it >= 0 }
                    ?: part.indexOf("\n\n").takeIf { it >= 0 }
                    ?: continue

                val headers = part.substring(0, sepIdx)
                val rawBody = part.substring(sepIdx).trim()

                // --- Determine correct page number from Content-Location URL ---
                val contentUrl = headers
                    .lineSequence()
                    .firstOrNull { it.contains("Content-Location:", ignoreCase = true) }
                    ?.substringAfter("Content-Location:", "")
                    ?.trim()
                    ?: ""

                val pageNum: Int? = pageNumRegex.find(contentUrl)?.groupValues?.get(1)?.toIntOrNull()

                // Skip images whose URLs carry no page-number suffix (logos, icons, etc.)
                if (pageNum == null) continue

                // --- Decode ---
                val ext = when {
                    headers.contains("image/png",  ignoreCase = true) -> "png"
                    headers.contains("image/webp", ignoreCase = true) -> "webp"
                    headers.contains("image/gif",  ignoreCase = true) -> "gif"
                    else -> "jpg"
                }

                // Strip all line endings from base64 text before decoding
                val b64 = rawBody
                    .replace("\r\n", "")
                    .replace("\r",   "")
                    .replace("\n",   "")
                    .trim()

                if (b64.length < 10) continue

                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    if (bytes.size > 200) {   // skip corrupt/tiny fragments
                        // Name file by real page number → alphabetical sort = correct order
                        val out = File(cacheDir, "page_${pageNum.toString().padStart(4, '0')}.$ext")
                        out.writeBytes(bytes)
                        images.add(out)
                    }
                } catch (_: Exception) { /* skip malformed base64 */ }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Sort by filename — now reflects true page order because names come from the URL
        return images.sortedBy { it.name }
    }
}
