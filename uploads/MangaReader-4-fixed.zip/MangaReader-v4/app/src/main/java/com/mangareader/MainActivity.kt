package com.mangareader

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mangareader.data.Chapter
import com.mangareader.data.Series
import com.mangareader.ui.ChapterListScreen
import com.mangareader.ui.LibraryScreen
import com.mangareader.ui.ReaderScreen
import com.mangareader.ui.theme.MangaReaderTheme
import com.mangareader.viewmodel.LibraryViewModel
import com.mangareader.viewmodel.ReaderViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Lay content behind system bars, then hide them all
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Allow content to draw into the camera notch / punch-hole area
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        hideSystemBars()

        setContent {
            MangaReaderTheme {
                MangaReaderApp()
            }
        }
    }

    // Re-hide when coming back from a notification / dialog / recent apps
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        // Hide status bar AND navigation bar
        controller.hide(WindowInsetsCompat.Type.systemBars())
        // Allow swipe-from-edge to temporarily reveal bars (standard immersive behaviour)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}

// ── Navigation ─────────────────────────────────────────────────────────────────

sealed class Screen {
    object Library : Screen()
    data class ChapterList(val series: Series) : Screen()
    data class Reader(
        val chapter: Chapter,
        val chapterIndex: Int,
        val series: Series
    ) : Screen()
}

@Composable
fun MangaReaderApp() {
    val libraryVM: LibraryViewModel = viewModel()
    val readerVM:  ReaderViewModel  = viewModel()

    var screen by remember { mutableStateOf<Screen>(Screen.Library) }

    when (val s = screen) {

        is Screen.Library -> LibraryScreen(
            viewModel     = libraryVM,
            onSeriesClick = { series -> screen = Screen.ChapterList(series) }
        )

        is Screen.ChapterList -> ChapterListScreen(
            series         = s.series,
            progress       = libraryVM.getProgress(s.series.id),
            onChapterClick = { chapter, idx ->
                screen = Screen.Reader(chapter, idx, s.series)
            },
            onBack         = { screen = Screen.Library }
        )

        is Screen.Reader -> ReaderScreen(
            viewModel       = readerVM,
            chapter         = s.chapter,
            chapterIndex    = s.chapterIndex,
            allChapters     = s.series.chapters,
            initialProgress = libraryVM.getProgress(s.series.id),
            onBack          = { screen = Screen.ChapterList(s.series) },
            onChapterChange = { newChapter, newIdx ->
                screen = Screen.Reader(newChapter, newIdx, s.series)
            }
        )
    }
}
