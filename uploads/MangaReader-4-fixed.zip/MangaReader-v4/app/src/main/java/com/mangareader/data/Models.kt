package com.mangareader.data

import java.util.UUID

data class Chapter(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val number: Float,
    val mhtmlPath: String,   // content:// URI string (SAF) or absolute file path (extracted ZIP)
    val seriesId: String
)

data class Series(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sourceFolderUri: String? = null,
    val sourceZipUri: String? = null,
    val chapters: List<Chapter> = emptyList(),
    val addedAt: Long = System.currentTimeMillis()
)

data class ReadingProgress(
    val seriesId: String,
    val chapterIndex: Int = 0,
    val pageIndex: Int = 0,
    val scrollOffset: Int = 0
)
