package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.viewmodel.LibraryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onSeriesClick: (Series) -> Unit
) {
    val seriesList by viewModel.series.collectAsStateWithLifecycle()
    val loading    by viewModel.loading.collectAsStateWithLifecycle()
    val error      by viewModel.error.collectAsStateWithLifecycle()

    var showAddMenu     by remember { mutableStateOf(false) }
    var deleteTarget    by remember { mutableStateOf<Series?>(null) }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { viewModel.addFolder(it) } }

    val zipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.addZip(it) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manga Library") },
                actions = {
                    Box {
                        IconButton(onClick = { showAddMenu = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add manga")
                        }
                        DropdownMenu(
                            expanded = showAddMenu,
                            onDismissRequest = { showAddMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Add folder") },
                                leadingIcon = { Icon(Icons.Default.Folder, null) },
                                onClick = {
                                    showAddMenu = false
                                    folderPicker.launch(null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Add ZIP file") },
                                leadingIcon = { Icon(Icons.Default.Archive, null) },
                                onClick = {
                                    showAddMenu = false
                                    zipPicker.launch(arrayOf("application/zip", "application/x-zip", "*/*"))
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                windowInsets = WindowInsets(0)
            )
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (seriesList.isEmpty() && !loading) {
                LibraryEmpty(
                    onAddFolder = { folderPicker.launch(null) },
                    onAddZip    = { zipPicker.launch(arrayOf("application/zip", "*/*")) }
                )
            } else {
                LazyVerticalGrid(
                    columns             = GridCells.Adaptive(160.dp),
                    contentPadding      = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    modifier              = Modifier.fillMaxSize()
                ) {
                    items(seriesList, key = { it.id }) { series ->
                        SeriesCard(
                            series   = series,
                            progress = viewModel.getProgress(series.id),
                            onClick  = { onSeriesClick(series) },
                            onDelete = { deleteTarget = series },
                            onRefresh = { viewModel.refreshSeries(series) }
                        )
                    }
                }
            }

            if (loading) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Importing…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            error?.let { msg ->
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { viewModel.clearError() }) { Text("OK") }
                    }
                ) { Text(msg) }
            }
        }
    }

    // Delete confirmation
    deleteTarget?.let { series ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Remove Series") },
            text  = { Text("Remove \"${series.title}\" from library?\nCached images will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteSeries(series.id)
                    deleteTarget = null
                }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun SeriesCard(
    series: Series,
    progress: ReadingProgress?,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onRefresh: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        shape  = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick     = onClick,
                onLongClick = { showMenu = true }
            )
    ) {
        Column {
            // Thumbnail placeholder
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.MenuBook,
                    contentDescription = null,
                    modifier = Modifier.size(36.dp),
                    tint     = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                )
                // Chapter count badge
                Text(
                    "${series.chapters.size} ch",
                    style    = MaterialTheme.typography.labelSmall,
                    color    = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                )
            }

            Column(Modifier.padding(10.dp)) {
                Text(
                    text     = series.title,
                    style    = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (progress != null) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text  = "Ch ${progress.chapterIndex + 1} · Pg ${progress.pageIndex + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        DropdownMenu(
            expanded          = showMenu,
            onDismissRequest  = { showMenu = false }
        ) {
            if (series.sourceFolderUri != null) {
                DropdownMenuItem(
                    text         = { Text("Refresh chapters") },
                    leadingIcon  = { Icon(Icons.Default.Refresh, null) },
                    onClick      = { showMenu = false; onRefresh() }
                )
            }
            DropdownMenuItem(
                text        = { Text("Remove from library") },
                leadingIcon = { Icon(Icons.Default.Delete, null) },
                onClick     = { showMenu = false; onDelete() }
            )
        }
    }
}

@Composable
private fun LibraryEmpty(onAddFolder: () -> Unit, onAddZip: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.LibraryBooks,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
        Spacer(Modifier.height(20.dp))
        Text("No manga yet", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(
            "Add a folder or ZIP containing .mhtml files",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onAddFolder) {
                Icon(Icons.Default.Folder, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Folder")
            }
            OutlinedButton(onClick = onAddZip) {
                Icon(Icons.Default.Archive, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("ZIP")
            }
        }
    }
}
