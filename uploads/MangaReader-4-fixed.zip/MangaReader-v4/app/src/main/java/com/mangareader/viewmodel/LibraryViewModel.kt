package com.mangareader.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.manager.LibraryManager
import com.mangareader.manager.ProgressManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val libraryManager  = LibraryManager(app)
    private val progressManager = ProgressManager(app)

    private val _series  = MutableStateFlow<List<Series>>(emptyList())
    val series: StateFlow<List<Series>> = _series

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error   = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init { reload() }

    private fun reload() {
        _series.value = libraryManager.getAllSeries()
    }

    fun addFolder(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addFolder(uri) }
            .onFailure { _error.value = "Could not add folder: ${it.message}" }
        reload(); _loading.value = false
    }

    fun addZip(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addZip(uri) }
            .onFailure { _error.value = "Could not add ZIP: ${it.message}" }
        reload(); _loading.value = false
    }

    fun deleteSeries(seriesId: String) {
        libraryManager.deleteSeries(seriesId)
        reload()
    }

    fun refreshSeries(series: Series) = viewModelScope.launch {
        _loading.value = true
        runCatching { libraryManager.refreshSeries(series) }
        reload(); _loading.value = false
    }

    fun getProgress(seriesId: String): ReadingProgress? =
        progressManager.getProgress(seriesId)

    fun clearError() { _error.value = null }
}
