package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterListScreen(
    series: Series,
    progress: ReadingProgress?,
    onChapterClick: (Chapter, Int) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            series.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${series.chapters.size} chapters",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                windowInsets = WindowInsets(0)
            )
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        val listState = rememberLazyListState()

        // Auto-scroll to the chapter in progress on first load
        LaunchedEffect(Unit) {
            progress?.let {
                if (it.chapterIndex > 0 && it.chapterIndex < series.chapters.size) {
                    listState.scrollToItem(it.chapterIndex)
                }
            }
        }

        LazyColumn(
            state            = listState,
            modifier         = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding   = PaddingValues(vertical = 4.dp)
        ) {
            // "Continue reading" banner at the top if there is progress
            if (progress != null && series.chapters.isNotEmpty()) {
                item(key = "continue_banner") {
                    val ch = series.chapters.getOrNull(progress.chapterIndex)
                    if (ch != null) {
                        ContinueBanner(
                            chapterTitle = ch.title,
                            chapterIndex = progress.chapterIndex,
                            pageIndex    = progress.pageIndex,
                            onClick      = { onChapterClick(ch, progress.chapterIndex) }
                        )
                        HorizontalDivider()
                    }
                }
            }

            itemsIndexed(series.chapters, key = { _, c -> c.id }) { index, chapter ->
                val isCurrent = progress?.chapterIndex == index
                ChapterRow(
                    chapter  = chapter,
                    index    = index,
                    isCurrent = isCurrent,
                    pageHint = if (isCurrent) progress?.pageIndex else null,
                    onClick  = { onChapterClick(chapter, index) }
                )
                if (index < series.chapters.size - 1) {
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

@Composable
private fun ContinueBanner(
    chapterTitle: String,
    chapterIndex: Int,
    pageIndex: Int,
    onClick: () -> Unit
) {
    Surface(
        color    = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.PlayCircle,
                contentDescription = null,
                tint     = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Continue reading",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                )
                Text(
                    "$chapterTitle · Page ${pageIndex + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun ChapterRow(
    chapter: Chapter,
    index: Int,
    isCurrent: Boolean,
    pageHint: Int?,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = {
            Text(
                chapter.title,
                color = if (isCurrent) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface
            )
        },
        supportingContent = if (pageHint != null) {
            { Text("Page ${pageHint + 1} · In progress",
                color = MaterialTheme.colorScheme.secondary) }
        } else null,
        leadingContent = {
            Text(
                "${index + 1}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        trailingContent = if (isCurrent) {
            { Icon(Icons.Default.PlayArrow, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)) }
        } else null,
        colors = ListItemDefaults.colors(
            containerColor = if (isCurrent)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.background
        ),
        modifier = Modifier.clickable(onClick = onClick)
    )
}
