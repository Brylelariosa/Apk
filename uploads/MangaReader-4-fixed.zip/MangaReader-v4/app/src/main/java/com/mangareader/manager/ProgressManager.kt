package com.mangareader.manager

import android.content.Context
import com.google.gson.Gson
import com.mangareader.data.ReadingProgress

class ProgressManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("manga_progress", Context.MODE_PRIVATE)
    private val gson  = Gson()

    fun getProgress(seriesId: String): ReadingProgress? {
        val json = prefs.getString("p_$seriesId", null) ?: return null
        return runCatching { gson.fromJson(json, ReadingProgress::class.java) }.getOrNull()
    }

    fun saveProgress(progress: ReadingProgress) {
        prefs.edit()
            .putString("p_${progress.seriesId}", gson.toJson(progress))
            .apply()
    }

    fun clearProgress(seriesId: String) {
        prefs.edit().remove("p_$seriesId").apply()
    }
}
