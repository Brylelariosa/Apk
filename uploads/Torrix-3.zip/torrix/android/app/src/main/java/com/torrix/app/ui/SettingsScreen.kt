package com.torrix.app.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import com.torrix.app.storage.AppSettings
import com.torrix.app.storage.SaveMode
import com.torrix.app.storage.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: MainViewModel,
    onPickFolder: () -> Unit,
    onBatterySettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s by vm.engine.settings.state.collectAsState()
    val restart by vm.engine.restartRequired.collectAsState()
    val store = vm.engine.settings
    var logText by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    fun edit(change: (AppSettings) -> AppSettings) = store.update(change)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item { Text("Settings", style = MaterialTheme.typography.titleLarge) }

        if (restart) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(
                        "DHT and port changes take effect the next time Torrix starts. Close it from the recent apps screen, then open it again.",
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
        }

        item {
            Section("Download location") {
                RadioRow(
                    "Downloads folder",
                    "Finished files are saved to Downloads/Torrix. No permission needed.",
                    s.saveMode == SaveMode.PUBLIC_DOWNLOADS,
                ) { edit { it.copy(saveMode = SaveMode.PUBLIC_DOWNLOADS) } }
                RadioRow(
                    "Folder I choose",
                    if (s.customTreeUri != null) "Current: ${folderLabel(s.customTreeUri!!)}" else "Pick any folder, including one on an SD card.",
                    s.saveMode == SaveMode.CUSTOM_FOLDER,
                ) {
                    if (s.customTreeUri == null) onPickFolder() else edit { it.copy(saveMode = SaveMode.CUSTOM_FOLDER) }
                }
                RadioRow(
                    "Keep in app storage",
                    "Files stay inside Torrix. Use Save to Downloads in the Completed tab when you want a copy elsewhere.",
                    s.saveMode == SaveMode.APP_ONLY,
                ) { edit { it.copy(saveMode = SaveMode.APP_ONLY) } }
                OutlinedButton(
                    onClick = onPickFolder,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                ) {
                    Icon(TorrixIcons.Folder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Choose folder")
                }
                Note(
                    "Torrents download into private app storage first and are copied to the location above when they finish. " +
                        "Android 11 and newer do not let apps pick the top-level Download folder as a custom folder; choose a subfolder, or use the Downloads folder option.",
                )
            }
        }

        item {
            Section("Downloads") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Simultaneous downloads", style = MaterialTheme.typography.bodyLarge)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        for (n in listOf(1, 2, 3, 4, 5, 6, 8, 10)) {
                            FilterChip(
                                selected = s.maxActive == n,
                                onClick = { edit { it.copy(maxActive = n) } },
                                label = { Text("$n", style = NumberStyle) },
                            )
                        }
                    }
                    Text(
                        "More torrents than this wait in a queue, oldest first.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                NumberRow("Download speed limit", "Leave empty for no limit", s.downKiB) { v -> edit { it.copy(downKiB = v) } }
                NumberRow("Upload speed limit", "Leave empty for no limit", s.upKiB) { v -> edit { it.copy(upKiB = v) } }
                SwitchRow(
                    "Keep seeding after completion",
                    "Uses upload data and battery, and keeps a copy in app storage. Off by default.",
                    s.seedAfterComplete,
                ) { v -> edit { it.copy(seedAfterComplete = v) } }
            }
        }

        item {
            Section("Network and background") {
                SwitchRow(
                    "Download on mobile data",
                    "When off, downloads pause on mobile data and continue on Wi-Fi.",
                    s.allowMobileData,
                ) { v -> edit { it.copy(allowMobileData = v) } }
                SwitchRow(
                    "Use DHT",
                    "Finds peers without a tracker. Needed for most magnet links. Applies after a restart.",
                    s.dhtEnabled,
                ) { v -> edit { it.copy(dhtEnabled = v) } }
                SwitchRow(
                    "Keep the CPU awake while downloading",
                    "Helps downloads continue with the screen off, at the cost of battery.",
                    s.keepAwake,
                ) { v -> edit { it.copy(keepAwake = v) } }
                Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = onBatterySettings) { Text("Battery optimization settings") }
                    Text(
                        "If downloads stall in the background, allow Torrix to run unrestricted in Android's battery settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            Section("Search sources") {
                SwitchRow("Linux distributions", "Official Arch Linux and Debian release torrents.", s.distrosEnabled) { v ->
                    edit { it.copy(distrosEnabled = v) }
                }
                SwitchRow("Internet Archive", "Public-domain and openly licensed media.", s.iaEnabled) { v ->
                    edit { it.copy(iaEnabled = v) }
                }
                TextRow("Torznab indexer address", "Optional. For example http://192.168.1.10:9696/api/v2.0/indexers/all/results/torznab/api", s.torznabUrl, KeyboardType.Uri, false) { v ->
                    edit { it.copy(torznabUrl = v) }
                }
                TextRow("Torznab API key", null, s.torznabKey, KeyboardType.Password, true) { v ->
                    edit { it.copy(torznabKey = v) }
                }
                Note("Torrix does not include or recommend any indexer. You are responsible for what you search for and download.")
            }
        }

        item {
            Section("Appearance") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for ((mode, label) in listOf(ThemeMode.SYSTEM to "System", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark")) {
                        FilterChip(
                            selected = s.theme == mode,
                            onClick = { edit { it.copy(theme = mode) } },
                            label = { Text(label) },
                        )
                    }
                }
            }
        }

        item {
            Section("About") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Torrix 0.1.0", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "A BitTorrent client written in Rust. Only download and share content you have the right to.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(onClick = { vm.loadDiagnostics { logText = it } }) { Text("Show engine log") }
                }
            }
        }
    }

    logText?.let { text ->
        AlertDialog(
            onDismissRequest = { logText = null },
            title = { Text("Engine log") },
            text = {
                Text(
                    text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(text))
                    vm.say("Log copied")
                    logText = null
                }) { Text("Copy") }
            },
            dismissButton = { TextButton(onClick = { logText = null }) { Text("Close") } },
        )
    }
}

private fun folderLabel(uri: String): String =
    Uri.parse(uri).lastPathSegment?.substringAfterLast(':')?.ifBlank { null } ?: "chosen folder"

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp),
        )
        Card(shape = MaterialTheme.shapes.medium, colors = flatCardColors(), border = flatBorder()) {
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), content = content)
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RadioRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(end = 12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NumberRow(title: String, subtitle: String, value: Int, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(if (value == 0) "" else value.toString()) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(7)
                text = digits
                onChange(digits.toIntOrNull() ?: 0)
            },
            modifier = Modifier.width(132.dp),
            singleLine = true,
            placeholder = { Text("No limit") },
            suffix = { Text("KB/s") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
    }
}

@Composable
private fun TextRow(
    title: String,
    hint: String?,
    value: String,
    keyboard: KeyboardType,
    secret: Boolean,
    onChange: (String) -> Unit,
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = { onChange(it.take(1024)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(title) },
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        )
        if (hint != null) {
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
