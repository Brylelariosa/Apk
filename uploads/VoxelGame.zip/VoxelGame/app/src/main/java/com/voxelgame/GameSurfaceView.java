package com.voxelgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameSurfaceView extends GLSurfaceView {

    private final GameRenderer renderer;

    // ── Touch state (dual virtual joystick) ───────────────────────────────────
    private int   leftPointerId  = -1;
    private int   rightPointerId = -1;
    private float leftOriginX, leftOriginY;
    private float rightOriginX, rightOriginY;

    private static final float DEAD_ZONE   = 10f;   // pixels
    private static final float MAX_RADIUS  = 120f;  // pixels
    private static final float LOOK_SENS   = 0.003f; // radians per pixel

    public GameSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);

        // Request RGBA8, 24-bit depth, no stencil, 0 MSAA
        setEGLConfigChooser(8, 8, 8, 0, 24, 0);

        renderer = new GameRenderer();
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int action   = event.getActionMasked();
        final int actionIdx= event.getActionIndex();
        final int pid      = event.getPointerId(actionIdx);
        final float x      = event.getX(actionIdx);
        final float y      = event.getY(actionIdx);
        final float halfW  = getWidth() * 0.5f;

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < halfW && leftPointerId == -1) {
                    leftPointerId = pid;
                    leftOriginX = x;
                    leftOriginY = y;
                } else if (x >= halfW && rightPointerId == -1) {
                    rightPointerId = pid;
                    rightOriginX = x;
                    rightOriginY = y;
                }
                break;

            case MotionEvent.ACTION_MOVE: {
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int p   = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);

                    if (p == leftPointerId) {
                        // Movement joystick (forward/strafe)
                        float dx = px - leftOriginX;
                        float dy = py - leftOriginY;
                        float dist = (float) Math.sqrt(dx * dx + dy * dy);
                        if (dist > MAX_RADIUS) {
                            float scale = MAX_RADIUS / dist;
                            dx *= scale; dy *= scale;
                        }
                        float fwd    = -dy / MAX_RADIUS;  // up = forward
                        float strafe =  dx / MAX_RADIUS;  // right = strafe
                        if (dist < DEAD_ZONE) { fwd = 0; strafe = 0; }
                        nativeSetMovement(fwd, strafe);

                    } else if (p == rightPointerId) {
                        // Look joystick (accumulated delta)
                        float dx = px - rightOriginX;
                        float dy = py - rightOriginY;
                        rightOriginX = px;
                        rightOriginY = py;
                        nativeSetLook(dx * LOOK_SENS, dy * LOOK_SENS);
                    }
                }
                break;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pid == leftPointerId) {
                    leftPointerId = -1;
                    nativeSetMovement(0f, 0f);
                } else if (pid == rightPointerId) {
                    rightPointerId = -1;
                }
                break;
        }
        return true;
    }

    // ── JNI (implemented in jni_bridge.cpp) ───────────────────────────────────
    public native void nativeSetMovement(float forward, float strafe);
    public native void nativeSetLook(float dyaw, float dpitch);
}
