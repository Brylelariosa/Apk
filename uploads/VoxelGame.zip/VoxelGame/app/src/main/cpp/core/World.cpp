#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <condition_variable>

#define TAG  "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Thread pool internals ──────────────────────────────────────────────────────
// We use a slightly extended pool with a condition variable
namespace {
struct Pool {
    std::queue<std::function<void()>> q;
    std::mutex                        mtx;
    std::condition_variable           cv;
    bool                              stop = false;
};
Pool g_pool;
} // anon

World::World() : noise(0) {}

World::~World() {
    {
        std::unique_lock<std::mutex> lock(g_pool.mtx);
        g_pool.stop = true;
    }
    g_pool.cv.notify_all();
    for (auto& t : workers) if (t.joinable()) t.join();
}

void World::workerLoop() {
    while (true) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(g_pool.mtx);
            g_pool.cv.wait(lock, [&]{ return g_pool.stop || !g_pool.q.empty(); });
            if (g_pool.stop && g_pool.q.empty()) return;
            task = std::move(g_pool.q.front());
            g_pool.q.pop();
        }
        task();
    }
}

void World::enqueueTask(std::function<void()> task) {
    {
        std::unique_lock<std::mutex> lock(g_pool.mtx);
        g_pool.q.push(std::move(task));
    }
    g_pool.cv.notify_one();
}

// ── Init ───────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    noise = Noise(seed);

    // Start worker threads (use hardware concurrency, min 2)
    int numThreads = std::max(2, (int)std::thread::hardware_concurrency());
    LOGI("Starting %d worker threads", numThreads);
    for (int i = 0; i < numThreads; i++)
        workers.emplace_back([this]{ workerLoop(); });

    // Create and enqueue generation for all chunks in render area
    for (int cz = -RENDER_RADIUS; cz <= RENDER_RADIUS; cz++) {
        for (int cx = -RENDER_RADIUS; cx <= RENDER_RADIUS; cx++) {
            ChunkKey key{cx, cz};
            auto chunk = std::make_unique<Chunk>(cx, cz);
            Chunk* ptr = chunk.get();
            chunks[key] = std::move(chunk);

            // Enqueue: generate → then mesh
            enqueueTask([this, ptr]() {
                ptr->generate(noise);
                // Meshing requires neighbors; defer until all generated
            });
        }
    }

    // Wait for all chunks to finish generation before meshing
    // (Busy-wait, acceptable at startup)
    LOGI("Waiting for chunk generation...");
    bool allGenerated = false;
    while (!allGenerated) {
        allGenerated = true;
        for (auto& kv : chunks) {
            if (kv.second->state.load(std::memory_order_acquire) < ChunkState::GENERATED) {
                allGenerated = false;
                break;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    LOGI("All %d chunks generated. Building meshes...", (int)chunks.size());

    // Now enqueue meshing (neighbors are available)
    for (auto& kv : chunks) {
        Chunk* ptr = kv.second.get();
        enqueueTask([this, ptr]() {
            rebuildChunkMesh(ptr);
        });
    }
    LOGI("Mesh tasks enqueued");
}

void World::rebuildChunkMesh(Chunk* chunk) {
    int cx = chunk->cx, cz = chunk->cz;
    const Chunk* nxC = getChunk(cx - 1, cz);
    const Chunk* pxC = getChunk(cx + 1, cz);
    const Chunk* nzC = getChunk(cx, cz - 1);
    const Chunk* pzC = getChunk(cx, cz + 1);
    chunk->buildMesh(nxC, pxC, nzC, pzC);
}

// ── updateGPU (GL thread) ──────────────────────────────────────────────────────
void World::updateGPU() {
    // Upload up to 4 meshed chunks per frame to avoid hitches
    int uploaded = 0;
    for (auto& kv : chunks) {
        if (kv.second->state.load(std::memory_order_acquire) == ChunkState::MESHED) {
            kv.second->uploadMesh();
            if (++uploaded >= 4) break;
        }
    }
}

// ── Render ─────────────────────────────────────────────────────────────────────
void World::render(const Frustum& frustum) {
    int visible = 0;
    for (auto& kv : chunks) {
        Chunk* ch = kv.second.get();
        if (ch->state.load(std::memory_order_acquire) != ChunkState::READY) continue;

        float mnX, mnY, mnZ, mxX, mxY, mxZ;
        ch->getAABB(mnX, mnY, mnZ, mxX, mxY, mxZ);

        if (!frustum.testAABB({mnX, mnY, mnZ}, {mxX, mxY, mxZ})) continue;

        ch->render();
        visible++;
    }
    lastVisibleCount = visible;
}

// ── Block lookup ───────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx, cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

BlockType World::getBlock(int wx, int wy, int wz) const {
    if (wy < 0 || wy >= CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx * CHUNK_W;
    int lz = wz - cz * CHUNK_D;
    const Chunk* ch = getChunk(cx, cz);
    return ch ? ch->getBlock(lx, wy, lz) : BLOCK_AIR;
}
