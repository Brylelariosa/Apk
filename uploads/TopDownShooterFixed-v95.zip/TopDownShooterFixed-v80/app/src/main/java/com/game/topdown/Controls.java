package com.game.topdown;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.*;
import android.text.InputType;
import android.view.MotionEvent;
import android.widget.EditText;

// ─── Joystick widget (merged from Joystick.java) ─────────────────────────────
class Joystick {
    private float bx, by, radius;
    private float sx, sy;
    private int   touchId = -1;
    private float nx, ny;
    private boolean active;

    private Paint basePaint  = ring(80);
    private Paint stickPaint = ring(190);
    private int   baseAlpha  = 150;   // outer ring alpha

    public Joystick(float bx, float by, float r) {
        this.bx=bx; this.by=by; this.radius=r; sx=bx; sy=by;
    }

    public void setAlpha(int a) {
        baseAlpha = a;
        basePaint  = ring(a / 3);
        stickPaint = ring(a);
    }

    private static Paint ring(int alpha) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.argb(alpha,255,255,255));
        p.setStyle(Paint.Style.FILL);
        return p;
    }

    public void updateBase(float x, float y) {
        bx=x; by=y; if(!active){sx=x; sy=y;}
    }

    /** Returns true if this joystick claimed the touch. */
    public boolean onTouchDown(int id, float x, float y) {
        if (touchId != -1) return false;
        float dx=x-bx, dy=y-by;
        if (dx*dx+dy*dy <= radius*radius*2.25f) {
            touchId=id; active=true; move(x,y); return true;
        }
        return false;
    }
    public void onTouchMove(int id, float x, float y) { if(touchId==id) move(x,y); }
    public void onTouchUp(int id) {
        if(touchId==id){ touchId=-1; active=false; sx=bx; sy=by; nx=0; ny=0; }
    }
    private void move(float x, float y) {
        if (radius <= 0f) return;   // safety: no-op until surfaceChanged sets real dimensions
        float dx=x-bx, dy=y-by, d=(float)Math.sqrt(dx*dx+dy*dy);
        if(d>radius){ dx=dx/d*radius; dy=dy/d*radius; }
        sx=bx+dx; sy=by+dy; nx=dx/radius; ny=dy/radius;
    }

    public void draw(Canvas c) {
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setColor(Color.argb(baseAlpha / 3, 255, 255, 255));
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(4f);
        c.drawCircle(bx, by, radius, ring);
        c.drawCircle(bx, by, radius, basePaint);
        c.drawCircle(sx, sy, radius * 0.44f, stickPaint);
    }

    public float   getX()     { return nx; }
    public float   getY()     { return ny; }
    public boolean isActive() { return active; }
    public float   getBaseX() { return bx; }
    public float   getBaseY() { return by; }
    public float   getRadius(){ return radius; }
}

// ─── Controls ────────────────────────────────────────────────────────────────
/**
 * Handles all player input, joystick layout, button interactions,
 * weapon-wheel, shop, and settings for GameView.
 *
 * <p>Joystick (previously Joystick.java) is also defined in this file.
 */
class Controls {
    final GameView gv;
    Controls(GameView gv) { this.gv = gv; }

    void initControls() {
        gv.refreshCachedPrefs(); // keep cached values in sync whenever layout is rebuilt
        SharedPreferences prefs = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);   // 0=S 1=M 2=L
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);   // 0=S 1=M 2=L
        int  opacity = prefs.getInt    ("opacity",  1);   // 0=lo 1=med 2=hi

        // Joysticks – use saved base positions if available
        float[] muls = {0.10f, 0.145f, 0.19f};
        float r = Math.min(gv.screenW, gv.screenH) * muls[Math.max(0, Math.min(2, jsSize))];
        float m = r + 18f;
        float lx = swap ? gv.screenW - m : m;
        float rx = swap ? m           : gv.screenW - m;
        float defLy = gv.screenH - m;
        gv.moveStick = new Joystick(
            clamp(prefs.getFloat("js_lx", lx),  r, gv.screenW - r),
            clamp(prefs.getFloat("js_ly", defLy), r, gv.screenH - r), r);
        gv.aimStick  = new Joystick(
            clamp(prefs.getFloat("js_rx", rx),  r, gv.screenW - r),
            clamp(prefs.getFloat("js_ry", defLy), r, gv.screenH - r), r);
        int[] alphas = {90, 160, 225};
        int alpha = alphas[Math.max(0, Math.min(2, opacity))];
        gv.moveStick.setAlpha(alpha);
        gv.aimStick .setAlpha(alpha);

        // Action buttons with saved position + size
        float[] bws = {120f, 160f, 210f};
        float[] bhs = { 46f,  58f,  72f};
        float bw = bws[Math.max(0, Math.min(2, btnSize))];
        float bh = bhs[Math.max(0, Math.min(2, btnSize))];
        float defBx = gv.screenW - bw - 14f;
        // Per-button scale (set via size slider in move mode). 0.4x..2.2x range.
        float switchScale = prefs.getFloat("scale_switch", 1.0f);
        float rldScale    = prefs.getFloat("scale_rld",    1.0f);
        float skillScale2 = prefs.getFloat("scale_skill",  1.0f);
        // Weapon wheel button — independently positioned, square for circle rendering
        float bx = prefs.getFloat("btn_x", defBx);
        float by = prefs.getFloat("btn_y", 14f);
        float swD = bh * switchScale;  // circle diameter scales per-button
        bx = Math.max(0, Math.min(gv.screenW - swD, bx));
        by = Math.max(0, Math.min(gv.screenH - swD, by));
        gv.switchRect = new RectF(bx, by, bx+swD, by+swD);
        // Reload / bomb / drop group — independently positioned
        float rldW = bw * rldScale, rldH = bh * rldScale;
        float rldX = prefs.getFloat("rld_x", defBx);
        float rldY = prefs.getFloat("rld_y", by + swD + 8f);
        rldX = Math.max(0, Math.min(gv.screenW - rldW, rldX));
        rldY = Math.max(0, Math.min(gv.screenH - rldH, rldY));
        gv.reloadRect = new RectF(rldX, rldY, rldX+rldW, rldY+rldH);
        // Bomb — independently positioned
        float bombX = prefs.getFloat("bomb_x", defBx);
        float bombY = prefs.getFloat("bomb_y", by + swD + rldH + 16f);
        bombX = Math.max(0, Math.min(gv.screenW - rldW, bombX));
        bombY = Math.max(0, Math.min(gv.screenH - rldH, bombY));
        gv.bombRect = new RectF(bombX, bombY, bombX+rldW, bombY+rldH);
        // Drop — independently positioned
        float dropX = prefs.getFloat("drop_x", defBx);
        float dropY = prefs.getFloat("drop_y", by + swD + rldH*2 + 24f);
        dropX = Math.max(0, Math.min(gv.screenW - rldW, dropX));
        dropY = Math.max(0, Math.min(gv.screenH - rldH, dropY));
        gv.dropRect = new RectF(dropX, dropY, dropX+rldW, dropY+rldH);

        // Paint mode toggle button — positioned left of reload group, only visible with Paint Launcher
        float pmW = rldW * 0.82f, pmH = rldH;
        float pmX = prefs.getFloat("pm_x", defBx - pmW - 10f);
        float pmY = prefs.getFloat("pm_y", rldY);
        pmX = Math.max(0, Math.min(gv.screenW - pmW, pmX));
        pmY = Math.max(0, Math.min(gv.screenH - pmH, pmY));
        gv.paintModeRect = new RectF(pmX, pmY, pmX + pmW, pmY + pmH);

        // Skill button — circle, independently movable
        float skillDBase = bw * 0.88f;
        float skillD = skillDBase * skillScale2;
        float defSklX = prefs.getFloat("skill_x", bx + (swD - skillD) / 2f);
        float defSklY = prefs.getFloat("skill_y", by + swD * 4 + 32f);
        defSklX = Math.max(0, Math.min(gv.screenW - skillD, defSklX));
        defSklY = Math.max(0, Math.min(gv.screenH - skillD, defSklY));
        gv.skillRect = new RectF(defSklX, defSklY, defSklX + skillD, defSklY + skillD);

        // Size slider track (shown when a button is tapped in move mode)
        float slW = Math.min(gv.screenW * 0.65f, 420f);
        gv.sizeSliderTrack = new RectF(gv.screenW/2f - slW/2f, gv.screenH - 210f, gv.screenW/2f + slW/2f, gv.screenH - 178f);

        // Gear button
        gv.gearRect = new RectF(12, gv.screenH-72, 72, gv.screenH-12);
        gv.wheelRadius = Math.min(gv.screenW, gv.screenH) * 0.20f;

        // Confirm-move button (shown only in gv.btnMoveMode)
        gv.confirmMoveRect = new RectF(gv.screenW/2-70, gv.screenH-90, gv.screenW/2+70, gv.screenH-30);

        // Settings panel — 8 option rows + MOVE BUTTONS + CHANGE NAME
        float pw = Math.min(520f, gv.screenW - 48f);
        float ph = 790f;
        float px = (gv.screenW - pw) / 2f;
        float py = (gv.screenH - ph) / 2f;
        gv.settingsPanel     = new RectF(px, py, px+pw, py+ph);
        gv.closeSettingsRect = new RectF(px+pw-54, py+8, px+pw-8, py+52);

        float optX = px + pw * 0.47f;
        float obw=72f, obh=40f, og=7f;
        // 8 rows, 62px apart
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f, py+500f};
        for(int i=0;i<3;i++) gv.jsSizeOpts[i]  = new RectF(optX+i*(obw+og), rowY[0], optX+i*(obw+og)+obw, rowY[0]+obh);
        for(int i=0;i<2;i++) gv.swapOpts[i]    = new RectF(optX+i*(obw+og), rowY[1], optX+i*(obw+og)+obw, rowY[1]+obh);
        for(int i=0;i<3;i++) gv.btnSizeOpts[i] = new RectF(optX+i*(obw+og), rowY[2], optX+i*(obw+og)+obw, rowY[2]+obh);
        for(int i=0;i<3;i++) gv.aimSensOpts[i] = new RectF(optX+i*(obw+og), rowY[3], optX+i*(obw+og)+obw, rowY[3]+obh);
        for(int i=0;i<3;i++) gv.opacityOpts[i] = new RectF(optX+i*(obw+og), rowY[4], optX+i*(obw+og)+obw, rowY[4]+obh);
        for(int i=0;i<2;i++) gv.gunStatOpts[i] = new RectF(optX+i*(obw+og), rowY[5], optX+i*(obw+og)+obw, rowY[5]+obh);
        for(int i=0;i<2;i++) gv.aimLineOpts[i] = new RectF(optX+i*(obw+og), rowY[6], optX+i*(obw+og)+obw, rowY[6]+obh);
        // Row 7: "RELEASE FIRE ▶" button (opens per-gun overlay)
        gv.relFireOpenBtn = new RectF(optX, rowY[7], optX + obw*2 + og, rowY[7] + obh);
        // Fire threshold: value display + EDIT button
        float ftY = py + 562f;
        float ftEditW = 80f;
        float ftValW  = 90f;
        gv.fireThreshValRect  = new RectF(optX,            ftY, optX+ftValW,          ftY+obh);
        gv.fireThreshEditBtn  = new RectF(optX+ftValW+8f,  ftY, optX+ftValW+8f+ftEditW, ftY+obh);
        float mbY = py + 622f;
        gv.moveBtnsRect = new RectF(px+20, mbY, px+pw-20, mbY+42f);
        float mmY = mbY + 50f;
        gv.mainMenuRect = new RectF(px+20, mmY, px+pw-20, mmY+42f);
        float cnY = mmY + 50f;
        gv.changeNameRect = new RectF(px+20, cnY, px+pw-20, cnY+42f);

        // Per-gun Release Fire secondary panel (two-column grid, 10+10)
        float rfpW = Math.min(520f, gv.screenW - 48f);
        float rfRowH = 38f, rfRowGap = 5f;
        int rfRows = 10;
        float rfpH = 62f + rfRows * (rfRowH + rfRowGap) + 12f;
        float rfpX = (gv.screenW - rfpW) / 2f;
        float rfpY = (gv.screenH - rfpH) / 2f;
        gv.relFirePanel    = new RectF(rfpX, rfpY, rfpX + rfpW, rfpY + rfpH);
        gv.relFireCloseBtn = new RectF(rfpX + rfpW - 54, rfpY + 8, rfpX + rfpW - 8, rfpY + 52);
        float rfColW = rfpW / 2f - 12f;
        float rfTogW = 46f, rfTogGap = 6f;
        float rfContentY = rfpY + 62f;
        for (int i = 0; i < GameView.GUN_NAMES.length; i++) {
            int col = i / rfRows, row = i % rfRows;
            float rfRx = rfpX + 10f + col * (rfColW + 12f);
            float rfRy = rfContentY + row * (rfRowH + rfRowGap);
            float tx = rfRx + rfColW - rfTogW*2 - rfTogGap;
            gv.relFireToggleON[i]  = new RectF(tx,               rfRy + 3, tx + rfTogW,            rfRy + rfRowH - 3);
            gv.relFireToggleOFF[i] = new RectF(tx + rfTogW + rfTogGap, rfRy + 3, tx + rfTogW*2 + rfTogGap, rfRy + rfRowH - 3);
        }
        float defSbx = 82f, defSby = gv.screenH - 72f;
        float sbx = prefs.getFloat("shop_x", defSbx);
        float sby = prefs.getFloat("shop_y", defSby);
        sbx = Math.max(0, Math.min(gv.screenW - 70f, sbx));
        sby = Math.max(0, Math.min(gv.screenH - 60f, sby));
        gv.shopBtn = new RectF(sbx, sby, sbx + 70f, sby + 60f);

        // Shop panel rects  ── gv.shopPanelH field is shared with drawShop() ──
        float spw = Math.min(580f, gv.screenW - 40f);
        gv.shopPanelH = Math.min(gv.screenH - 40f, gv.screenH * 0.94f); // nearly full screen height
        float sph = gv.shopPanelH;
        float spx = (gv.screenW - spw) / 2f;
        float spy = (gv.screenH - sph) / 2f;
        gv.shopCloseRect = new RectF(spx+spw-54, spy+8, spx+spw-8, spy+52);

        // Shop tab buttons
        float tabW = (spw - 24f) / 2f;
        gv.shopTabGuns   = new RectF(spx+12,       spy+58, spx+12+tabW,  spy+98);
        gv.shopTabSkills = new RectF(spx+14+tabW,  spy+58, spx+spw-12,   spy+98);

        // Gun buy rects (2 columns: guns shown side-by-side)
        float colW = (spw - 24f) / 2f;
        float buyW = colW * 0.38f, buyH = 30f, firstRowY = spy + 110f;
        float colPad = 8f;
        for (int i = 0; i < 22; i++) {
            int row = i / 2, col = i % 2;
            float ry = firstRowY + row * (GameView.SHOP_ROW_H + GameView.SHOP_ROW_GAP);
            float cardX = spx + 8f + col * (colW + colPad);
            gv.shopBuyRects[i] = new RectF(cardX + colW - buyW - 4f, ry + (GameView.SHOP_ROW_H - buyH) / 2f,
                                         cardX + colW - 4f,        ry + (GameView.SHOP_ROW_H + buyH) / 2f);
        }

        // Passive skill buy rects
        float skillBuyW = 86f, skillBuyH = 34f;
        float passiveRowY = spy + 132f, skillRowH = 54f, skillRowGap = 4f;
        for (int i = 0; i < 4; i++) {
            float ry = passiveRowY + i*(skillRowH + skillRowGap);
            gv.passiveBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }
        // Active skill buy rects
        float activeRowY = spy + 392f;
        for (int i = 0; i < 4; i++) {
            float ry = activeRowY + i*(skillRowH + skillRowGap);
            gv.activeBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }

        // Training mode panel — three buttons, each independently repositionable
        if (gv.trainingMode) {
            float tbW = 140f, tbH = 46f, tbGap = 8f;
            float defTbX = gv.screenW - tbW - 12f;
            float taDx = prefs.getFloat("train_add_x", defTbX);
            float taDy = prefs.getFloat("train_add_y", 70f);
            taDx = Math.max(0, Math.min(gv.screenW - tbW, taDx));
            taDy = Math.max(0, Math.min(gv.screenH - tbH, taDy));
            gv.trainAddDummyBtn = new RectF(taDx, taDy, taDx+tbW, taDy+tbH);
            float trDx = prefs.getFloat("train_rem_x", defTbX);
            float trDy = prefs.getFloat("train_rem_y", 70f + tbH + tbGap);
            trDx = Math.max(0, Math.min(gv.screenW - tbW, trDx));
            trDy = Math.max(0, Math.min(gv.screenH - tbH, trDy));
            gv.trainRemDummyBtn = new RectF(trDx, trDy, trDx+tbW, trDy+tbH);
            float tmDx = prefs.getFloat("train_money_x", defTbX);
            float tmDy = prefs.getFloat("train_money_y", 70f + 2*(tbH + tbGap));
            tmDx = Math.max(0, Math.min(gv.screenW - tbW, tmDx));
            tmDy = Math.max(0, Math.min(gv.screenH - tbH, tmDy));
            gv.trainAddMoneyBtn = new RectF(tmDx, tmDy, tmDx+tbW, tmDy+tbH);
        }
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);

        // Per-gun Release Fire panel — checked FIRST (gv.settingsOpen is still true behind it)
        if (gv.relFireOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (gv.relFireCloseBtn != null && gv.relFireCloseBtn.contains(x, y)) {
                    gv.relFireOpen = false; return true;
                }
                handleRelFireTap(x, y);
            }
            return true;
        }

        // Settings overlay absorbs all input when open
        if (gv.settingsOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (gv.closeSettingsRect != null && gv.closeSettingsRect.contains(x, y)) {
                    gv.settingsOpen = false; return true;
                }
                handleSettingsTap(x, y);
            }
            return true;
        }

        // Shop overlay absorbs all input when open
        if (gv.shopOpen) {
            switch (act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    gv.shopDragStartY = y;
                    gv.shopDragLastY  = y;
                    gv.shopIsDragging = false;
                    gv.shopScrollVelocity = 0f;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float scrollDelta = gv.shopDragLastY - y;
                    gv.shopDragLastY = y;
                    if (!gv.shopIsDragging && Math.abs(y - gv.shopDragStartY) > 12f) {
                        gv.shopIsDragging = true;
                    }
                    if (gv.shopIsDragging) {
                        gv.shopTabScrollY[gv.shopTab] = Math.max(0f,
                            Math.min(gv.shopTabScrollMax[gv.shopTab],
                                gv.shopTabScrollY[gv.shopTab] + scrollDelta));
                        gv.shopScrollVelocity = gv.shopScrollVelocity * 0.6f + scrollDelta * 0.4f; // track velocity in px/event
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    if (!gv.shopIsDragging) {
                        if (gv.shopCloseRect != null && gv.shopCloseRect.contains(x, y)) {
                            gv.shopOpen = false;
                        } else {
                            handleShopTap(x, y);
                        }
                    }
                    gv.shopIsDragging = false;
                    break;
            }
            return true;
        }

        // Button-move mode: drag switch/reload buttons AND joysticks, tap ✓ to save
        if (gv.btnMoveMode) {
            switch(act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    gv.tapStartX = x; gv.tapStartY = y; gv.tapMoved = false;
                    // Size slider drag — only when a button is selected for sizing
                    if (gv.btnSizingId != -1 && gv.sizeSliderTrack != null) {
                        RectF sliderHit = new RectF(gv.sizeSliderTrack.left - 20, gv.sizeSliderTrack.top - 30,
                                gv.sizeSliderTrack.right + 20, gv.sizeSliderTrack.bottom + 30);
                        if (sliderHit.contains(x, y)) { gv.draggingBtn = 99; break; }
                    }
                    if (gv.confirmMoveRect != null && gv.confirmMoveRect.contains(x, y)) {
                        // Save positions + per-button scales and exit move mode
                        SharedPreferences.Editor ed = gv.getContext().getSharedPreferences(GameView.PREFS, 0).edit();
                        if (gv.switchRect != null) {
                            ed.putFloat("btn_x", gv.switchRect.left); ed.putFloat("btn_y", gv.switchRect.top);
                            SharedPreferences pr2 = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
                            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_switch", gv.switchRect.width() / baseH);
                        }
                        if (gv.reloadRect != null) {
                            ed.putFloat("rld_x", gv.reloadRect.left); ed.putFloat("rld_y", gv.reloadRect.top);
                            SharedPreferences pr2 = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
                            float[] bws2 = {120f,160f,210f};
                            float baseW = bws2[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_rld", gv.reloadRect.width() / baseW);
                        }
                        if (gv.skillRect  != null) {
                            ed.putFloat("skill_x", gv.skillRect.left); ed.putFloat("skill_y", gv.skillRect.top);
                            SharedPreferences pr2 = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
                            float[] bws3 = {120f,160f,210f};
                            float baseW = bws3[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            float baseSkillD = baseW * 0.88f;
                            ed.putFloat("scale_skill", gv.skillRect.width() / baseSkillD);
                        }
                        if (gv.moveStick != null) { ed.putFloat("js_lx", gv.moveStick.getBaseX()); ed.putFloat("js_ly", gv.moveStick.getBaseY()); }
                        if (gv.aimStick  != null) { ed.putFloat("js_rx", gv.aimStick.getBaseX());  ed.putFloat("js_ry", gv.aimStick.getBaseY());  }
                        if (gv.shopBtn   != null) { ed.putFloat("shop_x", gv.shopBtn.left);        ed.putFloat("shop_y", gv.shopBtn.top);          }
                        if (gv.bombRect  != null) { ed.putFloat("bomb_x", gv.bombRect.left);       ed.putFloat("bomb_y", gv.bombRect.top);         }
                        if (gv.dropRect  != null) { ed.putFloat("drop_x", gv.dropRect.left);       ed.putFloat("drop_y", gv.dropRect.top);         }
                        if (gv.paintModeRect != null) { ed.putFloat("pm_x", gv.paintModeRect.left); ed.putFloat("pm_y", gv.paintModeRect.top);     }
                        if (gv.trainingMode) {
                            if (gv.trainAddDummyBtn != null) { ed.putFloat("train_add_x",   gv.trainAddDummyBtn.left); ed.putFloat("train_add_y",   gv.trainAddDummyBtn.top); }
                            if (gv.trainRemDummyBtn != null) { ed.putFloat("train_rem_x",   gv.trainRemDummyBtn.left); ed.putFloat("train_rem_y",   gv.trainRemDummyBtn.top); }
                            if (gv.trainAddMoneyBtn != null) { ed.putFloat("train_money_x", gv.trainAddMoneyBtn.left); ed.putFloat("train_money_y", gv.trainAddMoneyBtn.top); }
                        }
                        ed.apply();
                        gv.btnMoveMode = false; gv.btnSizingId = -1; gv.draggingBtn = -1; break;
                    }
                    if (gv.switchRect != null && gv.switchRect.contains(x, y)) {
                        gv.draggingBtn=0; gv.dragOffX=x-gv.switchRect.left; gv.dragOffY=y-gv.switchRect.top;
                    } else if (gv.reloadRect != null && gv.reloadRect.contains(x, y)) {
                        gv.draggingBtn=1; gv.dragOffX=x-gv.reloadRect.left; gv.dragOffY=y-gv.reloadRect.top;
                    } else if (gv.bombRect != null && gv.bombRect.contains(x, y)) {
                        gv.draggingBtn=6; gv.dragOffX=x-gv.bombRect.left; gv.dragOffY=y-gv.bombRect.top;
                    } else if (gv.dropRect != null && gv.dropRect.contains(x, y)) {
                        gv.draggingBtn=7; gv.dragOffX=x-gv.dropRect.left; gv.dragOffY=y-gv.dropRect.top;
                    } else if (gv.moveStick != null) {
                        float dx=x-gv.moveStick.getBaseX(), dy=y-gv.moveStick.getBaseY();
                        float rr=gv.moveStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ gv.draggingBtn=2; gv.dragOffX=dx; gv.dragOffY=dy; }
                    }
                    if (gv.draggingBtn==-1 && gv.aimStick != null) {
                        float dx=x-gv.aimStick.getBaseX(), dy=y-gv.aimStick.getBaseY();
                        float rr=gv.aimStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ gv.draggingBtn=3; gv.dragOffX=dx; gv.dragOffY=dy; }
                    }
                    if (gv.draggingBtn==-1 && gv.shopBtn != null && gv.shopBtn.contains(x, y)) {
                        gv.draggingBtn=4; gv.dragOffX=x-gv.shopBtn.left; gv.dragOffY=y-gv.shopBtn.top;
                    }
                    if (gv.draggingBtn==-1 && gv.paintModeRect != null && gv.paintModeRect.contains(x, y)) {
                        gv.draggingBtn=8; gv.dragOffX=x-gv.paintModeRect.left; gv.dragOffY=y-gv.paintModeRect.top;
                    }
                    if (gv.draggingBtn==-1 && gv.skillRect != null) {
                        float _sdx=x-gv.skillRect.centerX(), _sdy=y-gv.skillRect.centerY();
                        float _sr=gv.skillRect.width()/2f*1.4f;
                        if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){
                            gv.draggingBtn=5; gv.dragOffX=x-gv.skillRect.left; gv.dragOffY=y-gv.skillRect.top;
                        }
                    }
                    if (gv.draggingBtn==-1 && gv.trainingMode) {
                        if (gv.trainAddDummyBtn != null && gv.trainAddDummyBtn.contains(x, y)) {
                            gv.draggingBtn=10; gv.dragOffX=x-gv.trainAddDummyBtn.left; gv.dragOffY=y-gv.trainAddDummyBtn.top;
                        } else if (gv.trainRemDummyBtn != null && gv.trainRemDummyBtn.contains(x, y)) {
                            gv.draggingBtn=11; gv.dragOffX=x-gv.trainRemDummyBtn.left; gv.dragOffY=y-gv.trainRemDummyBtn.top;
                        } else if (gv.trainAddMoneyBtn != null && gv.trainAddMoneyBtn.contains(x, y)) {
                            gv.draggingBtn=12; gv.dragOffX=x-gv.trainAddMoneyBtn.left; gv.dragOffY=y-gv.trainAddMoneyBtn.top;
                        }
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    float mdx = x - gv.tapStartX, mdy = y - gv.tapStartY;
                    if (mdx*mdx + mdy*mdy > 144f) gv.tapMoved = true; // 12px threshold
                    if (gv.draggingBtn == 99 && gv.sizeSliderTrack != null) {
                        // Dragging the size slider knob
                        float knobX = Math.max(gv.sizeSliderTrack.left, Math.min(gv.sizeSliderTrack.right, x));
                        gv.sizeSliderVal = (knobX - gv.sizeSliderTrack.left) / gv.sizeSliderTrack.width();
                        float scale = 0.4f + gv.sizeSliderVal * 1.8f; // 0.4x .. 2.2x
                        applyBtnSizeScale(gv.btnSizingId, scale);
                    } else if (gv.draggingBtn == 0) {
                        if (gv.switchRect != null) {
                            float bw2 = gv.switchRect.width(), bh2 = gv.switchRect.height();
                            float nx = Math.max(0, Math.min(gv.screenW - bw2, x - gv.dragOffX));
                            float ny = Math.max(0, Math.min(gv.screenH - bh2, y - gv.dragOffY));
                            gv.switchRect.offsetTo(nx, ny);
                        }
                    } else if (gv.draggingBtn == 1) {
                        if (gv.reloadRect != null) {
                            float bw2 = gv.reloadRect.width(), bh2 = gv.reloadRect.height();
                            float nx = Math.max(0, Math.min(gv.screenW - bw2,      x - gv.dragOffX));
                            float ny = Math.max(0, Math.min(gv.screenH - bh2, y - gv.dragOffY));
                            gv.reloadRect.offsetTo(nx, ny);
                        }
                    } else if (gv.draggingBtn == 2 && gv.moveStick != null) {
                        float r2=gv.moveStick.getRadius();
                        gv.moveStick.updateBase(clamp(x-gv.dragOffX,r2,gv.screenW-r2), clamp(y-gv.dragOffY,r2,gv.screenH-r2));
                    } else if (gv.draggingBtn == 3 && gv.aimStick != null) {
                        float r2=gv.aimStick.getRadius();
                        gv.aimStick.updateBase(clamp(x-gv.dragOffX,r2,gv.screenW-r2), clamp(y-gv.dragOffY,r2,gv.screenH-r2));
                    } else if (gv.draggingBtn == 4 && gv.shopBtn != null) {
                        float sw=gv.shopBtn.width(), sh=gv.shopBtn.height();
                        float nx=Math.max(0,Math.min(gv.screenW-sw, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-sh, y-gv.dragOffY));
                        gv.shopBtn.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 5 && gv.skillRect != null) {
                        float sd = gv.skillRect.width();
                        float nx = Math.max(0, Math.min(gv.screenW - sd, x - gv.dragOffX));
                        float ny = Math.max(0, Math.min(gv.screenH - sd, y - gv.dragOffY));
                        gv.skillRect.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 6 && gv.bombRect != null) {
                        float bw2=gv.bombRect.width(), bh2=gv.bombRect.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.bombRect.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 7 && gv.dropRect != null) {
                        float bw2=gv.dropRect.width(), bh2=gv.dropRect.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.dropRect.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 8 && gv.paintModeRect != null) {
                        float bw2=gv.paintModeRect.width(), bh2=gv.paintModeRect.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.paintModeRect.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 10 && gv.trainAddDummyBtn != null) {
                        float bw2=gv.trainAddDummyBtn.width(), bh2=gv.trainAddDummyBtn.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.trainAddDummyBtn.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 11 && gv.trainRemDummyBtn != null) {
                        float bw2=gv.trainRemDummyBtn.width(), bh2=gv.trainRemDummyBtn.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.trainRemDummyBtn.offsetTo(nx, ny);
                    } else if (gv.draggingBtn == 12 && gv.trainAddMoneyBtn != null) {
                        float bw2=gv.trainAddMoneyBtn.width(), bh2=gv.trainAddMoneyBtn.height();
                        float nx=Math.max(0,Math.min(gv.screenW-bw2, x-gv.dragOffX));
                        float ny=Math.max(0,Math.min(gv.screenH-bh2, y-gv.dragOffY));
                        gv.trainAddMoneyBtn.offsetTo(nx, ny);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    // Tap (no drag) on a button → enter per-button size slider mode
                    if (!gv.tapMoved && gv.draggingBtn >= 0 && gv.draggingBtn != 99) {
                        int tappedId = gv.draggingBtn; // 0=wheel, 1=reload, 5=skill
                        if (tappedId == 0 || tappedId == 1 || tappedId == 5) {
                            gv.btnSizingId = tappedId;
                            // Init slider position from current button scale
                            float curScale = 1.0f;
                            SharedPreferences pr = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
                            if (tappedId == 0) curScale = pr.getFloat("scale_switch", 1.0f);
                            else if (tappedId == 1) curScale = pr.getFloat("scale_rld", 1.0f);
                            else curScale = pr.getFloat("scale_skill", 1.0f);
                            gv.sizeSliderVal = Math.max(0f, Math.min(1f, (curScale - 0.4f) / 1.8f));
                        }
                    }
                    gv.draggingBtn = -1; break;
            }
            return true;
        }

        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(gv.gearRect!=null&&gv.gearRect.contains(x,y)){gv.settingsOpen=true;break;}
                if(gv.shopBtn!=null&&gv.shopBtn.contains(x,y)){gv.shopOpen=true;gv.shopTabScrollY[0]=0f;gv.shopTabScrollY[1]=0f;break;}
                // Training mode buttons
                if (gv.trainingMode) {
                    if (gv.trainAddDummyBtn != null && gv.trainAddDummyBtn.contains(x, y)) { gv.spawnDummy(); break; }
                    if (gv.trainRemDummyBtn != null && gv.trainRemDummyBtn.contains(x, y)) { gv.removeLastDummy(); break; }
                    if (gv.trainAddMoneyBtn != null && gv.trainAddMoneyBtn.contains(x, y)) {
                        Player lp2 = gv.localPlayer; if (lp2 != null) lp2.coins += 200; break;
                    }
                }
                if(gv.switchRect!=null&&gv.switchRect.contains(x,y)){openWeaponWheel(pid,x,y);break;}
                if(gv.reloadRect!=null&&gv.reloadRect.contains(x,y)){
                    // Air strike gun has no reload — tap is a no-op
                    if(gv.localPlayer==null||!gv.localPlayer.currentGun().bulletAirStrike) reload();
                    break;
                }
                if(gv.bombRect!=null&&gv.bombRect.contains(x,y)){startBombThrow();break;}
                if(gv.dropRect!=null&&gv.dropRect.contains(x,y)){dropWeapon();break;}
                if(gv.paintModeRect!=null&&gv.paintModeRect.contains(x,y)&&gv.localPlayer!=null&&gv.localPlayer.gunIndex==15){
                    Gun pg=gv.localPlayer.currentGun();
                    pg.paintMode = (pg.paintMode + 1) % 3; // cycle ALT → SLOW → POISON → ALT
                    // Reset toggle so ALT always restarts from poison
                    if (pg.paintMode == 0) pg.paintShotToggle = 2;
                    break;
                }
                if(gv.skillRect!=null){
                    float _sdx=x-gv.skillRect.centerX(),_sdy=y-gv.skillRect.centerY(),_sr=gv.skillRect.width()/2f;
                    if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){gv.useActiveSkill();break;}
                }
                if(!gv.moveStick.onTouchDown(pid,x,y)) gv.aimStick.onTouchDown(pid,x,y);
                // Air Strike: reset ring when aim stick pressed (blocked while reloading)
                { Player _lp=gv.localPlayer; if(_lp!=null&&_lp.currentGun().bulletAirStrike&&!_lp.currentGun().reloading) { gv.asAimAngle=_lp.angle; gv.asAimMag=0f; } }
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    if(gv.wheelOpen && p2==gv.wheelPid){
                        updateWheelHover(e.getX(i), e.getY(i));
                    } else {
                        boolean msWasActive = gv.moveStick.isActive();
                        gv.moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        gv.aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        // Air Strike: update ring aim from stick; hide ring if walking or reloading
                        Player _lp2=gv.localPlayer;
                        if(_lp2!=null && _lp2.currentGun().bulletAirStrike) {
                            if(_lp2.currentGun().reloading) {
                                gv.asAimAngle = Float.NaN; gv.asAimMag = 0f; // clear ring while reloading
                            } else if(gv.moveStick.isActive()) {
                                float _mx=gv.moveStick.getX(), _my=gv.moveStick.getY();
                                if(_mx*_mx+_my*_my > 0.15f*0.15f) {
                                    gv.asAimAngle = Float.NaN; // walking → hide ring
                                }
                            } else if(gv.aimStick.isActive()) {
                                float _ax=gv.aimStick.getX(), _ay=gv.aimStick.getY();
                                gv.asAimMag=(float)Math.sqrt(_ax*_ax+_ay*_ay);
                                if(gv.asAimMag>0.05f) gv.asAimAngle=(float)Math.atan2(_ay,_ax);
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if(gv.wheelOpen && pid==gv.wheelPid){ closeWeaponWheel(); break; }
                float savedAX = gv.aimStick != null ? gv.aimStick.getX() : 0f;
                float savedAY = gv.aimStick != null ? gv.aimStick.getY() : 0f;
                boolean aimWasActive = gv.aimStick != null && gv.aimStick.isActive();
                gv.moveStick.onTouchUp(pid);
                gv.aimStick.onTouchUp(pid);
                if (gv.throwingBomb && aimWasActive && (gv.aimStick == null || !gv.aimStick.isActive())) {
                    executeThrow(savedAX, savedAY);
                }
                // Volt Chakram: release stick → launch all orbiting discs
                if (!gv.throwingBomb && aimWasActive && !gv.aimStick.isActive()) {
                    Player lp2 = gv.localPlayer;
                    if (lp2 != null && lp2.alive && isVoltChakram(lp2.currentGun())) {
                        if (!gv.isHost) gv.pendingVoltLaunch = new float[]{savedAX, savedAY, gv.voltCharge};
                        gv.launchVoltChakrams(lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && isShadowBlade(lp2.currentGun())) {
                        // FIX: capture charge BEFORE gv.launchShadowBlade resets it to 0
                        if (!gv.isHost) gv.pendingShadowBlade = new float[]{savedAX, savedAY, gv.shadowBladeCharge};
                        gv.launchShadowBlade(lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && lp2.currentGun().bulletAirStrike) {
                        // Air Strike: detonate at ring-aimed position on stick release
                        if (!Float.isNaN(gv.asAimAngle)) {
                            Gun ag = lp2.currentGun();
                            if (ag.ammo > 0 && !ag.reloading) {
                                spawnBullets(lp2); ag.markFired();
                            }
                        }
                        gv.asAimAngle = Float.NaN; gv.asAimMag = 0f;
                    } else if (lp2 != null && lp2.alive) {
                        // Per-gun fire-on-release: fire on stick-up if this gun uses REL mode
                        boolean rel = gv.cachedRelFire[lp2.gunIndex]; // FIX: was reading disk on every touch-up
                        if (rel) {
                            float ft = gv.getFireThresh();
                            if (savedAX*savedAX + savedAY*savedAY > ft*ft) {
                                lp2.angle = (float)Math.atan2(savedAY, savedAX);
                                Gun g2 = lp2.currentGun();
                                if (g2.ammo > 0 && !g2.reloading) {
                                    spawnBullets(lp2); g2.markFired();
                                }
                            }
                        }
                    }
                }
                break;
        }
        return true;
    }

    void handleRelFireTap(float x, float y) {
        SharedPreferences.Editor ed = gv.getContext().getSharedPreferences(GameView.PREFS, 0).edit();
        for (int i = 0; i < GameView.GUN_NAMES.length; i++) {
            if (gv.relFireToggleON[i]  != null && gv.relFireToggleON[i].contains(x, y))  { ed.putBoolean("rel_fire_"+i, true);  ed.apply(); gv.refreshCachedPrefs(); return; }
            if (gv.relFireToggleOFF[i] != null && gv.relFireToggleOFF[i].contains(x, y)) { ed.putBoolean("rel_fire_"+i, false); ed.apply(); gv.refreshCachedPrefs(); return; }
        }
    }

    void handleSettingsTap(float x, float y) {
        SharedPreferences.Editor ed = gv.getContext().getSharedPreferences(GameView.PREFS, 0).edit();
        for(int i=0;i<3;i++) if(gv.jsSizeOpts[i]!=null&&gv.jsSizeOpts[i].contains(x,y)){ed.putInt("js_size",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(gv.swapOpts[i]!=null&&gv.swapOpts[i].contains(x,y)){ed.putBoolean("swap",i==1);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(gv.btnSizeOpts[i]!=null&&gv.btnSizeOpts[i].contains(x,y)){ed.putInt("btn_size",i);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(gv.aimSensOpts[i]!=null&&gv.aimSensOpts[i].contains(x,y)){ed.putInt("aim_sens",i);ed.apply();gv.refreshCachedPrefs();return;}
        for(int i=0;i<3;i++) if(gv.opacityOpts[i]!=null&&gv.opacityOpts[i].contains(x,y)){ed.putInt("opacity",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(gv.gunStatOpts[i]!=null&&gv.gunStatOpts[i].contains(x,y)){ed.putBoolean("gun_stats",i==0);ed.apply();gv.refreshCachedPrefs();return;}
        for(int i=0;i<2;i++) if(gv.aimLineOpts[i]!=null&&gv.aimLineOpts[i].contains(x,y)){ed.putBoolean("aim_line",i==0);ed.apply();gv.refreshCachedPrefs();return;}
        if(gv.relFireOpenBtn!=null&&gv.relFireOpenBtn.contains(x,y)){ed.apply();gv.relFireOpen=true;return;}
        if(gv.fireThreshEditBtn!=null&&gv.fireThreshEditBtn.contains(x,y)){ showFireThreshDialog(); return; }
        if(gv.moveBtnsRect!=null&&gv.moveBtnsRect.contains(x,y)){gv.settingsOpen=false;gv.btnMoveMode=true;gv.btnSizingId=-1;return;}
        if(gv.mainMenuRect!=null&&gv.mainMenuRect.contains(x,y)){
            stopGame();
            ((android.app.Activity)gv.getContext()).finish();
            return;
        }
        if(gv.changeNameRect!=null&&gv.changeNameRect.contains(x,y)){showChangeNameDialog();return;}
    }

    /** Live-resize a button RectF during the size slider drag (keeps center fixed). */
    void applyBtnSizeScale(int btnId, float scale) {
        scale = Math.max(0.4f, Math.min(2.2f, scale));
        if (btnId == 0 && gv.switchRect != null) {
            // Wheel circle — keep top-left anchor, resize square
            float cx = gv.switchRect.left, cy = gv.switchRect.top;
            SharedPreferences pr = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))];
            float d = baseH * scale;
            gv.switchRect.set(cx, cy, cx + d, cy + d);
        } else if (btnId == 1 && gv.reloadRect != null) {
            // Keep each button's own top-left anchor, just resize width+height together
            SharedPreferences pr = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
            float[] bws2={120f,160f,210f}; float[] bhs2={46f,58f,72f};
            int sz=Math.max(0,Math.min(2,pr.getInt("btn_size",1)));
            float nw = bws2[sz] * scale, nh = bhs2[sz] * scale;
            gv.reloadRect.set(gv.reloadRect.left, gv.reloadRect.top, gv.reloadRect.left+nw, gv.reloadRect.top+nh);
            if(gv.bombRect!=null) gv.bombRect.set(gv.bombRect.left, gv.bombRect.top, gv.bombRect.left+nw, gv.bombRect.top+nh);
            if(gv.dropRect!=null) gv.dropRect.set(gv.dropRect.left, gv.dropRect.top, gv.dropRect.left+nw, gv.dropRect.top+nh);
        } else if (btnId == 5 && gv.skillRect != null) {
            // Skill circle — keep top-left anchor
            float sx = gv.skillRect.left, sy = gv.skillRect.top;
            SharedPreferences pr = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
            float[] bws3={120f,160f,210f};
            float baseSkillD = bws3[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))] * 0.88f;
            float d = baseSkillD * scale;
            gv.skillRect.set(sx, sy, sx + d, sy + d);
        }
    }

    void switchGun(){
        if(gv.localPlayer==null||!gv.localPlayer.alive) return;
        Player p=gv.localPlayer;
        int next=(p.gunIndex+1)%p.guns.length;
        for(int tries=0;tries<p.guns.length;tries++){
            if(p.unlockedGuns[next]){ p.gunIndex=next; return; }
            next=(next+1)%p.guns.length;
        }
    }

    // ── Weapon Wheel ──────────────────────────────────────────────────────────
    void openWeaponWheel(int pid, float x, float y){
        Player lp=gv.localPlayer; if(lp==null||!lp.alive) return;
        // Build slot list: all unlocked guns + bomb slot if player has bombs
        java.util.List<Integer> slots=new java.util.ArrayList<>();
        for(int i=0;i<lp.guns.length;i++) if(lp.unlockedGuns[i]) slots.add(i);
        // Bomb slot intentionally excluded from weapon wheel — use bomb button instead
        gv.wheelSlots=new int[slots.size()];
        for(int i=0;i<slots.size();i++) gv.wheelSlots[i]=slots.get(i);
        // Centre the wheel on the SWITCH button
        gv.wheelCX=gv.switchRect!=null?gv.switchRect.centerX():x;
        gv.wheelCY=gv.switchRect!=null?gv.switchRect.centerY():y;
        gv.wheelHovered=-1; gv.wheelPid=pid; gv.wheelOpen=true;
    }

    void updateWheelHover(float tx, float ty){
        if(!gv.wheelOpen||gv.wheelSlots==null||gv.wheelSlots.length==0) return;
        float dx=tx-gv.wheelCX, dy=ty-gv.wheelCY;
        // Only register hover when finger has moved away from centre
        if(dx*dx+dy*dy < 18*18){ gv.wheelHovered=-1; return; }
        float angle=(float)Math.atan2(dy,dx); // -π .. π
        // Map angle to slot index (start at top = -π/2, clockwise)
        float adjusted=angle+(float)(Math.PI/2);
        if(adjusted<0) adjusted+=(float)(Math.PI*2);
        float sliceAngle=(float)(Math.PI*2)/gv.wheelSlots.length;
        gv.wheelHovered=(int)(adjusted/sliceAngle)%gv.wheelSlots.length;
    }

    void closeWeaponWheel(){
        if(!gv.wheelOpen) return;
        Player lp=gv.localPlayer;
        if(lp!=null&&lp.alive&&gv.wheelHovered>=0&&gv.wheelSlots!=null&&gv.wheelHovered<gv.wheelSlots.length){
            int sel=gv.wheelSlots[gv.wheelHovered];
            lp.gunIndex=sel;
            gv.asAimAngle = Float.NaN; gv.asAimMag = 0f;
            gv.shadowBladeCharge = 0f; // reset blade charge if switching away
        }
        gv.wheelOpen=false; gv.wheelPid=-1; gv.wheelHovered=-1;
    }
    void reload()   {if(gv.localPlayer!=null&&gv.localPlayer.alive) gv.localPlayer.currentGun().startReload();}

    /**
     * Called (host-only) whenever a player is confirmed killed.
     * Awards coins to the killer with streak bonuses, updates all score counters,
     * and resets the victim's kill streak.
     */
    void onKill(Player killer, Player victim) {
        if (killer == null || victim == null) return;
        // Base reward
        int baseCoins = 25;
        // +3% per active kill in killer's current streak (streak bonus)
        float streakMult = 1f + 0.03f * killer.killStreak;
        int earned = Math.round(baseCoins * streakMult);
        // Bonus for ending a streak: +6 coins per streak level (e.g. 3-streak = +18)
        int streakBreakBonus = victim.killStreak * 6;
        killer.coins += earned + streakBreakBonus;
        killer.kills++;
        killer.killStreak++;
        // Announce streak milestones
        if (killer.killStreak == 3)
            gv.addFeed("🔥 " + killer.name + " is on a 3-kill streak!");
        else if (killer.killStreak == 5)
            gv.addFeed("🔥🔥 " + killer.name + " is on a 5-kill streak!");
        else if (killer.killStreak == 10)
            gv.addFeed("💀 " + killer.name + " — UNSTOPPABLE! 10-kill streak!");
        // Announce streak ending
        if (victim.killStreak >= 3)
            gv.addFeed("💥 " + killer.name + " ended " + victim.name +
                    "'s " + victim.killStreak + "-kill streak! +" + streakBreakBonus + " bonus");
        victim.killStreak = 0;
        victim.deaths++;

        // ── Soul Surge: downgrade victim one tier on death ───────────────────
        Gun victimSoul = victim.guns[20];
        if (victimSoul != null && victimSoul.killCount > 0) {
            int prevLv = victimSoul.soulLevel();
            // Find the kill count for the start of the previous tier
            int[] thresholds = {0, 1, 3, 5, 8, 12, 18, 25, 35};
            int prevTierStart = thresholds[Math.max(0, prevLv - 1)];
            // Drop kill count back to the start of the previous tier
            victimSoul.killCount = prevTierStart;
            victimSoul.lastSoulLevel = -1;   // force re-apply
            victimSoul.applySoulLevel();
            int newLv = victimSoul.soulLevel();
            if (newLv < prevLv) {
                gv.addFeed("💀 " + victim.name + " Soul Surge DOWNGRADED → Tier " + newLv);
            }
        }
    }

    void dropWeapon() {
        Player lp = gv.localPlayer;
        if (lp == null || !lp.alive) return;
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        if (unlockedCount <= 1) return;
        lp.unlockedGuns[lp.gunIndex] = false;
        int next = (lp.gunIndex + 1) % lp.guns.length;
        for (int tries = 0; tries < lp.guns.length; tries++) {
            if (lp.unlockedGuns[next]) { lp.gunIndex = next; return; }
            next = (next + 1) % lp.guns.length;
        }
    }

    void useActiveSkill() {
        Player lp = gv.localPlayer;
        if (lp == null || !lp.alive) return;

        // ── Shadow Blade: skill button = quick slash (no charge needed) ───────
        if (isShadowBlade(lp.currentGun())) {
            long now = System.currentTimeMillis();
            if (now < gv.quickSlashCdEnd) return; // on cooldown
            Gun g = lp.currentGun();
            if (g.ammo <= 0 || g.reloading) return;
            float ax = gv.aimStick != null ? gv.aimStick.getX() : 0f;
            float ay = gv.aimStick != null ? gv.aimStick.getY() : 0f;
            float mag = (float) Math.sqrt(ax*ax + ay*ay);
            // Fall back to player facing angle if stick is neutral
            if (mag < 0.05f) { ax = (float)Math.cos(lp.angle); ay = (float)Math.sin(lp.angle); mag = 1f; }
            if (!gv.isHost) gv.pendingQuickSlash = new float[]{ax/mag, ay/mag};
            gv.quickSlashCdEnd = now + 1000; // 1.0 s cooldown
            gv.launchQuickSlash(lp, ax/mag, ay/mag);
            return;
        }

        if (lp.activeSkillType == Player.ACTIVE_NONE) return;
        if (lp.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        switch (lp.activeSkillType) {
            case Player.ACTIVE_DASH:
                // Dash in the MOVE joystick direction (where you're walking)
                float dashAngle = (gv.moveStick!=null&&gv.moveStick.isActive())
                    ? (float)Math.atan2(gv.moveStick.getY(),gv.moveStick.getX()) : lp.angle;
                float dashDist = 260f;
                // Step along the dash path and stop at the last wall-free position
                float[] dashEnd = dashWithWallStop(lp.x, lp.y, dashAngle, dashDist);
                float nx = dashEnd[0], ny = dashEnd[1];
                // Animate the dash smoothly instead of snapping
                gv.effects.dashAnimStartX = lp.x; gv.effects.dashAnimStartY = lp.y;
                gv.effects.dashAnimEndX   = nx;   gv.effects.dashAnimEndY   = ny;
                gv.effects.dashAnimBegin  = now;  gv.effects.dashAnimating  = true;
                lp.skillCooldownEnd = now + 6000;
                gv.pendingPositionSync = true;
                break;
            case Player.ACTIVE_STEALTH:
                lp.skillActiveUntil = now + 4000;
                lp.skillCooldownEnd = now + 10000;
                break;
            case Player.ACTIVE_HEAL:
                lp.hp = Math.min(100, lp.hp + 40);
                lp.skillCooldownEnd = now + 12000;
                gv.pendingHealEvent = true; // FIX: tell host to apply hp+40 on its authoritative copy
                break;
            case Player.ACTIVE_SHIELD:
                lp.shieldHp = 60f;
                lp.skillActiveUntil = now + 6000;
                lp.skillCooldownEnd = now + 14000;
                break;
        }
    }

    /** Enter throw-aiming mode — bomb is actually thrown when aim stick is released. */
    void startBombThrow() {
        Player lp = gv.localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        // Only one active bomb allowed at a time
        for (Bomb b : gv.activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        if (gv.throwingBomb) { gv.throwingBomb = false; return; }  // tap again to cancel
        gv.throwingBomb = true;
    }

    /** Called when the aim stick is released while gv.throwingBomb is true. */
    void executeThrow(float ax, float ay) {
        gv.throwingBomb = false;
        Player lp = gv.localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.08f) return;
        for (Bomb b : gv.activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        lp.bombs--;
        float vx = ax * Bomb.THROW_SPEED;
        float vy = ay * Bomb.THROW_SPEED;
        float maxRange = mag * Bomb.THROW_RANGE;
        if (gv.isHost) {
            // Host owns all bombs — create directly
            Bomb bomb = new Bomb(lp.x, lp.y, lp.id);
            bomb.vx = vx; bomb.vy = vy; bomb.maxRange = maxRange;
            gv.activeBombs.add(bomb);
        } else {
            // Client: queue for next sendInput so host creates the authoritative bomb
            gv.pendingBombSend = new float[]{vx, vy, maxRange};
        }
    }

    void showFireThreshDialog() {
        android.app.Activity act = (android.app.Activity) gv.getContext();
        act.runOnUiThread(() -> {
            android.widget.EditText input = new android.widget.EditText(gv.getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                    | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            float cur = gv.getFireThresh();
            input.setText(String.format(java.util.Locale.US, "%.2f", cur));
            input.selectAll();
            input.setPadding(40, 24, 40, 24);

            new android.app.AlertDialog.Builder(gv.getContext())
                .setTitle("Fire Threshold")
                .setMessage("How far to push aim stick before firing (0.05 – 0.99)")
                .setView(input)
                .setPositiveButton("Set", (dlg, which) -> {
                    try {
                        float val = Float.parseFloat(input.getText().toString().trim());
                        val = Math.max(0.05f, Math.min(0.99f, val));
                        gv.getContext().getSharedPreferences(GameView.PREFS, 0).edit()
                            .putFloat("fire_thresh_val", val).apply();
                        gv.refreshCachedPrefs();
                    } catch (NumberFormatException ignored) {}
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    void showChangeNameDialog() {
        android.app.Activity act = (android.app.Activity) gv.getContext();
        act.runOnUiThread(() -> {
            android.widget.EditText input = new android.widget.EditText(gv.getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                    | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
            input.setFilters(new android.text.InputFilter[]{
                    new android.text.InputFilter.LengthFilter(16)
            });
            if (gv.localPlayer != null) {
                input.setText(gv.localPlayer.name);
                input.selectAll();
            }
            input.setPadding(40, 24, 40, 24);

            new android.app.AlertDialog.Builder(gv.getContext())
                .setTitle("Change Name")
                .setMessage("Enter a new name (max 16 characters)")
                .setView(input)
                .setPositiveButton("Save", (dlg, which) -> {
                    String newName = input.getText().toString().trim();
                    if (newName.isEmpty()) return;
                    // Update live player name
                    if (gv.localPlayer != null) gv.localPlayer.name = newName;
                    // Persist so the main menu shows it next time
                    gv.getContext().getSharedPreferences(GameView.PREFS, 0).edit()
                        .putString("player_name", newName).apply();
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    void handleShopTap(float x, float y) {
        Player lp=gv.localPlayer; if(lp==null) return;

        // Tab switch (fixed UI — no scroll offset)
        if(gv.shopTabGuns!=null   && gv.shopTabGuns.contains(x,y))   { gv.shopTab=0; gv.shopTabScrollY[0]=0f; return; }
        if(gv.shopTabSkills!=null && gv.shopTabSkills.contains(x,y)) { gv.shopTab=1; gv.shopTabScrollY[1]=0f; return; }

        // Item rows are drawn with scroll offset applied, so adjust tap Y by current scroll
        float sy = y + gv.shopTabScrollY[gv.shopTab];

        if(gv.shopTab==0){
            // Weapon purchases — 2-column layout
            float spw2 = Math.min(580f, gv.screenW - 40f);
            float spx2 = (gv.screenW - spw2) / 2f;
            float firstRowY2 = ((gv.screenH - gv.shopPanelH) / 2f) + 110f;
            float colW2 = (spw2 - 24f) / 2f, colPad2 = 8f;
            for(int i=0;i<gv.shopBuyRects.length;i++){
                int row2 = i / 2, col2 = i % 2;
                float rowTop = firstRowY2 + row2 * (GameView.SHOP_ROW_H + GameView.SHOP_ROW_GAP);
                float rowBot = rowTop + GameView.SHOP_ROW_H;
                float cardX2 = spx2 + 8f + col2 * (colW2 + colPad2);
                boolean inCard = (x >= cardX2 && x <= cardX2 + colW2 && sy >= rowTop && sy < rowBot);
                boolean inBtn  = gv.shopBuyRects[i] != null && gv.shopBuyRects[i].contains(x, sy);
                if(inCard || inBtn){
                    if(!lp.unlockedGuns[i]&&lp.coins>=GameView.GUN_PRICES[i]){
                        lp.coins-=GameView.GUN_PRICES[i];
                        int unlockedCount=0;
                        for(boolean u:lp.unlockedGuns) if(u) unlockedCount++;
                        if(unlockedCount>=2){
                            for(int j=0;j<7;j++){
                                if(lp.unlockedGuns[j]&&j!=lp.gunIndex){ lp.unlockedGuns[j]=false; break; }
                            }
                        }
                        lp.unlockedGuns[i]=true;
                    }
                    return;
                }
            }
        } else {
            // Passive skill purchases
            int[] passLevels ={lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
            for(int i=0;i<4;i++){
                if(gv.passiveBuyRects[i]!=null&&gv.passiveBuyRects[i].contains(x,sy)){
                    int lv=passLevels[i];
                    if(lv<3){
                        int cost=GameView.PASSIVE_SKILL_COSTS[lv];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            if(i==0) lp.skillReload++;
                            else if(i==1) lp.skillFireRate++;
                            else if(i==2) lp.skillRange++;
                            else          lp.skillMoveSpeed++;
                        }
                    }
                    return;
                }
            }
            // Active skill purchases (buy = equip, replaces current)
            int[] actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
            for(int i=0;i<4;i++){
                if(gv.activeBuyRects[i]!=null&&gv.activeBuyRects[i].contains(x,sy)){
                    if(lp.activeSkillType!=actTypes[i]){
                        int cost=GameView.ACTIVE_SKILL_COSTS[i];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            lp.activeSkillType=actTypes[i];
                            lp.skillCooldownEnd=0; lp.skillActiveUntil=0; lp.shieldHp=0;
                        }
                    }
                    return;
                }
            }
        }
    }

}
