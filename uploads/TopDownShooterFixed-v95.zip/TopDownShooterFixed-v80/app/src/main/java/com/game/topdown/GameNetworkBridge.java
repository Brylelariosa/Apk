package com.game.topdown;

import org.json.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Handles network serialization, deserialization, and NetworkManager callbacks for GameView.
 * Instantiated and owned by GameView; accesses game state through the {@code gv} reference.
 */
class GameNetworkBridge {
    final GameView gv;
    GameNetworkBridge(GameView gv) { this.gv = gv; }

    // ═══ NETWORK SERIALIZE ════════════════════════════════════════════════════
    private void broadcast(){
        try{
            JSONObject root=new JSONObject();
            JSONArray pa=new JSONArray();
            Player lp=gv.localPlayer; if(lp!=null) pa.put(pj(lp));
            for(Player p:gv.remote.values()) pa.put(pj(p));
            root.put("p",pa);
            // Bullets — cap at 100 to keep UDP packet inside buffer limits
            JSONArray ba=new JSONArray();
            int bCount=0;
            for(Bullet b:gv.bullets){
                if(bCount++>=100) break;
                JSONObject bj=new JSONObject();
                bj.put("x",(int)b.x); bj.put("y",(int)b.y);
                bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
                bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
                // FIX: sync visual type so clients render gv.bullets with correct appearance
                // 0=normal, 1=homing, 2=explosive, 3=bouncy, 4=piercing, 5=ghost, 6=hookSpear
                int btype = 0;
                if      (b.homing)        btype = 1;
                else if (b.explosive)     btype = 2;
                else if (b.bouncesLeft>0) btype = 3;
                else if (b.piercing)      btype = 4;
                else if (b.ghost)         btype = 5;
                else if (b.hookSpear)     btype = 6;
                bj.put("t", btype);
                bj.put("pc", b.paintColor); // paint color: 0=none, 1=slow(blue), 2=poison(green)
                ba.put(bj);
            }
            root.put("b",ba);
            // Bombs — full physics state so clients render them correctly
            JSONArray bma=new JSONArray();
            for(Bomb b:gv.activeBombs){
                JSONObject bj=new JSONObject();
                bj.put("x",b.x); bj.put("y",b.y); bj.put("o",b.ownerId);
                bj.put("vx",b.vx); bj.put("vy",b.vy);
                bj.put("rx",b.rollVx); bj.put("ry",b.rollVy);
                bj.put("mr",b.maxRange);
                bj.put("ln",b.hasLanded); bj.put("ea",b.explodedAt);
                bj.put("dt",b.deployTime);
                bma.put(bj);
            }
            root.put("bm",bma);
            // VoltChakrams — positions + state for all active discs
            JSONArray vca=new JSONArray();
            for(VoltChakram vc:gv.voltChakrams){
                JSONObject vcj=new JSONObject();
                vcj.put("o",vc.ownerId); vcj.put("x",(int)vc.x); vcj.put("y",(int)vc.y);
                vcj.put("st",vc.state); vcj.put("oi",vc.orbitIdx);
                vcj.put("vx",(int)vc.vx); vcj.put("vy",(int)vc.vy);
                vcj.put("d",(int)vc.damage); vcj.put("dt",(int)vc.distTraveled); vcj.put("mr",(int)vc.maxRange);
                vcj.put("sa",(int)(vc.spinAngle*100)); // sync self-spin angle
                vca.put(vcj);
            }
            root.put("vc",vca);
            // FIX: Sync gv.airStrikes to clients so they see warning circles and explosions.
            // Previously absent — clients saw no airstrike visuals at all.
            JSONArray asa = new JSONArray();
            for (double[] as : gv.airStrikes) {
                JSONObject asj = new JSONObject();
                asj.put("ax",(int)as[0]); asj.put("ay",(int)as[1]);
                asj.put("at",(long)as[2]);  // trigger time (epoch ms)
                asj.put("ao",(int)as[3]);   // ownerId
                asj.put("af",(long)as[4]);  // flashUntil (0 = not yet exploded)
                asj.put("ar",(int)(as.length>5?as[5]:0)); // remaining extra explosions
                asa.put(asj);
            }
            root.put("as",asa);
            // ── Slash trail events — sync so clients see the Shadow Blade arc ──
            // Only send slot-0 entries (the main arc); client reconstructs all slots.
            JSONArray sla = new JSONArray();
            long slaNow = System.currentTimeMillis();
            for (float[] st : gv.effects.slashTrails) {
                if ((int)st[5] == 0 && slaNow - (long)st[3] < 420L) { // only live main-arc slot
                    JSONObject slj = new JSONObject();
                    slj.put("slx", (int)st[0]); slj.put("sly", (int)st[1]);
                    slj.put("slr", (int)st[2]); slj.put("slt", (long)st[3]);
                    slj.put("sla", (double)st[4]); // launch angle
                    sla.put(slj);
                }
            }
            root.put("sl", sla);
            broadcastSnapshot = root.toString(); // hand off to sender thread — never blocks game loop
        }catch(Exception e){ e.printStackTrace(); }
    }
    private JSONObject pj(Player p) throws Exception {
        JSONObject o=new JSONObject();
        o.put("i",p.id); o.put("n",p.name);
        o.put("x",(int)p.x); o.put("y",(int)p.y);
        o.put("a",(double)p.angle);
        o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
        o.put("c",p.coins);
        o.put("kl",p.kills); o.put("de",p.deaths); o.put("ks",p.killStreak);
        o.put("sr",p.skillReload); o.put("sf",p.skillFireRate);
        o.put("sg",p.skillRange);  o.put("sm",p.skillMoveSpeed);
        o.put("sa",p.activeSkillType);
        o.put("ss",(int)p.shieldHp);
        long rem=Math.max(0,p.spawnProtectionUntil-System.currentTimeMillis());
        o.put("sp",(int)rem);
        long aRem=Math.max(0,p.skillActiveUntil-System.currentTimeMillis());
        o.put("se",(int)aRem);
        long hpRem=Math.max(0,p.hookPullUntil-System.currentTimeMillis());
        o.put("hpu",(int)hpRem);
        o.put("hpo",p.hookPullOwnerId);
        // FIX: sync status-effect durations so clients render slow/poison/stun rings
        // on gv.remote players. Previously omitted — all rings were invisible on clients.
        o.put("slw",(int)Math.max(0,p.slowUntil  -System.currentTimeMillis()));
        o.put("slwm", p.slowSpeedMult);
        o.put("poi",(int)Math.max(0,p.poisonUntil-System.currentTimeMillis()));
        o.put("stu",(int)Math.max(0,p.stunUntil  -System.currentTimeMillis()));
        return o;
    }
    private void applyState(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONArray pa=root.getJSONArray("p");
            for(int i=0;i<pa.length();i++){
                JSONObject o=pa.getJSONObject(i);
                int id=o.getInt("i"); boolean alive=o.getBoolean("v");
                float hx=o.getInt("x"), hy=o.getInt("y");
                Player lp=gv.localPlayer;
                if(lp!=null&&id==lp.id){
                    boolean was=lp.alive;
                    lp.hp=o.getInt("h"); lp.alive=alive;
                    lp.coins=o.optInt("c", lp.coins);
                    lp.kills=o.optInt("kl", lp.kills);
                    lp.deaths=o.optInt("de", lp.deaths);
                    lp.killStreak=o.optInt("ks", lp.killStreak);
                    int spMs=o.optInt("sp",0);
                    if(spMs>0) lp.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                    int hpRem=o.optInt("hpu",0);
                    if(hpRem>0){ lp.hookPullUntil=System.currentTimeMillis()+hpRem; lp.hookPullOwnerId=o.optInt("hpo",-1); }
                    else { lp.hookPullUntil=0; }
                    if(was&&!alive) gv.deathTime=System.currentTimeMillis();
                    // Always reconcile position from host — on LAN ~1ms lag, prevents drift
                    float dx=lp.x-hx, dy=lp.y-hy;
                    if(dx*dx+dy*dy > 40*40){
                        // Only snap if significantly off (>40px) to avoid fighting local prediction
                        lp.x=hx; lp.y=hy;
                    }
                    continue;
                }
                Player p=gv.remote.get(id);
                if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();gv.remote.put(id,p);}
                p.name=o.getString("n");
                // ── Dead-reckoning: estimate velocity from successive positions ──
                boolean _first = (p.netUpdateMs < 0);
                long _nowMs = System.currentTimeMillis();
                if (!_first) {
                    long _dt = _nowMs - p.netUpdateMs;
                    if (_dt > 5 && _dt < 150) {
                        p.netVX = (hx - p.netX) / (float)_dt;
                        p.netVY = (hy - p.netY) / (float)_dt;
                    }
                } else { p.netVX = 0f; p.netVY = 0f; }
                p.netX = hx; p.netY = hy; p.netUpdateMs = _nowMs;
                p.x = hx; p.y = hy;
                // Smooth aim angle — lerp instead of snap to avoid jitter between packets
                float _ta = (float)o.getDouble("a");
                p.angle = _first ? _ta : lerpAngle(p.angle, _ta, 0.45f);
                p.hp=o.getInt("h");
                p.gunIndex=o.getInt("g"); p.alive=alive;
                p.skillReload   =o.optInt("sr",p.skillReload);
                p.skillFireRate =o.optInt("sf",p.skillFireRate);
                p.skillRange    =o.optInt("sg",p.skillRange);
                p.skillMoveSpeed=o.optInt("sm",p.skillMoveSpeed);
                p.activeSkillType=o.optInt("sa",p.activeSkillType);
                p.shieldHp      =(float)o.optInt("ss",0);
                p.coins         =o.optInt("c", p.coins);
                p.kills         =o.optInt("kl", p.kills);
                p.deaths        =o.optInt("de", p.deaths);
                p.killStreak    =o.optInt("ks", p.killStreak);
                int spMs=o.optInt("sp",0);
                if(spMs>0) p.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                int aRem=o.optInt("se",0);
                if(aRem>0) p.skillActiveUntil=System.currentTimeMillis()+aRem;
                int hpRem=o.optInt("hpu",0);
                if(hpRem>0){ p.hookPullUntil=System.currentTimeMillis()+hpRem; p.hookPullOwnerId=o.optInt("hpo",-1); }
                else { p.hookPullUntil=0; }
                // FIX: restore status-effect timestamps so slow/poison/stun rings render on clients
                int slwRem=o.optInt("slw",0);   p.slowUntil   = slwRem>0 ? System.currentTimeMillis()+slwRem : 0;
                p.slowSpeedMult = (float)o.optDouble("slwm", StatusEffectConfig.SLOW_SPEED_MULT);
                int poiRem=o.optInt("poi",0);   p.poisonUntil = poiRem>0 ? System.currentTimeMillis()+poiRem : 0;
                int stuRem=o.optInt("stu",0);   p.stunUntil   = stuRem>0 ? System.currentTimeMillis()+stuRem : 0;
            }
            // ── Bullets ──────────────────────────────────────────────────────
            JSONArray ba=root.getJSONArray("b");
            gv.bullets.clear();
            for(int i=0;i<ba.length();i++){
                JSONObject bj=ba.getJSONObject(i);
                Bullet nb=new Bullet(bj.getInt("x"),bj.getInt("y"),
                    bj.getInt("u"),bj.getInt("v"),
                    bj.getInt("o"),bj.getInt("d"),bj.getInt("i"),Float.MAX_VALUE);
                // FIX: restore visual type flags so clients render gv.bullets correctly
                int btype = bj.optInt("t", 0);
                switch(btype){
                    case 1: nb.homing     = true; break;
                    case 2: nb.explosive  = true; break;
                    case 3: nb.bouncesLeft= 1;    break;
                    case 4: nb.piercing   = true; break;
                    case 5: nb.ghost      = true; break;
                    case 6: nb.hookSpear  = true; break;
                }
                nb.paintColor = bj.optInt("pc", 0);
                gv.bullets.add(nb);
            }
            // ── Bombs ─────────────────────────────────────────────────────────
            JSONArray bma=root.optJSONArray("bm");
            if(bma!=null){
                gv.activeBombs.clear();
                for(int i=0;i<bma.length();i++){
                    JSONObject bj=bma.getJSONObject(i);
                    Bomb b=new Bomb((float)bj.getDouble("x"),(float)bj.getDouble("y"),bj.getInt("o"));
                    b.vx=(float)bj.getDouble("vx"); b.vy=(float)bj.getDouble("vy");
                    b.rollVx=(float)bj.getDouble("rx"); b.rollVy=(float)bj.getDouble("ry");
                    b.maxRange=(float)bj.getDouble("mr");
                    b.hasLanded=bj.getBoolean("ln");
                    b.explodedAt=bj.getLong("ea");
                    b.deployTime=bj.getLong("dt");
                    gv.activeBombs.add(b);
                }
            }
            // ── VoltChakrams ──────────────────────────────────────────────────
            JSONArray vca=root.optJSONArray("vc");
            if(vca!=null){
                int lpId=gv.localPlayer!=null?gv.localPlayer.id:-1;
                gv.voltChakrams.removeIf(vc->vc.ownerId!=lpId); // keep local discs, replace gv.remote
                for(int i=0;i<vca.length();i++){
                    JSONObject vcj=vca.getJSONObject(i);
                    int oid=vcj.getInt("o");
                    if(oid==lpId) continue; // local player manages own discs
                    VoltChakram vc=new VoltChakram(oid,vcj.optInt("oi",-1));
                    vc.x=vcj.getInt("x"); vc.y=vcj.getInt("y");
                    vc.state=vcj.getInt("st");
                    vc.vx=vcj.getInt("vx"); vc.vy=vcj.getInt("vy");
                    vc.damage=vcj.getInt("d"); vc.distTraveled=vcj.getInt("dt"); vc.maxRange=vcj.getInt("mr");
                    vc.spinAngle=vcj.optInt("sa",0)/100f; // restore synced spin angle
                    gv.voltChakrams.add(vc);
                }
            }
            // FIX: Receive host's authoritative gv.airStrikes list so clients render
            // warning circles and explosion flashes for all players' air strikes.
            JSONArray asa = root.optJSONArray("as");
            if (asa != null) {
                gv.airStrikes.clear();
                for (int i = 0; i < asa.length(); i++) {
                    JSONObject asj = asa.getJSONObject(i);
                    gv.airStrikes.add(new double[]{
                        asj.getDouble("ax"), asj.getDouble("ay"),
                        asj.getLong("at"),   asj.getInt("ao"),
                        asj.getLong("af"),   asj.optInt("ar", 0)
                    });
                }
            }
            // ── Slash trail events — rebuild on client from host's slot-0 entries ──
            // FIX: slash gv.effects were invisible on clients because slashTrails is only
            // populated locally inside launchShadowBlade (which returns early for clients).
            JSONArray sla = root.optJSONArray("sl");
            if (sla != null) {
                java.util.Set<Long> existingTs = new java.util.HashSet<>();
                for (float[] st : gv.effects.slashTrails) existingTs.add((long)st[3]);
                for (int i = 0; i < sla.length(); i++) {
                    JSONObject slj = sla.getJSONObject(i);
                    long spawnMs = slj.getLong("slt");
                    if (existingTs.contains(spawnMs)) continue;
                    float slx = slj.getInt("slx"), sly = slj.getInt("sly");
                    float slr = slj.getInt("slr");
                    float slAng = (float)slj.getDouble("sla");
                    gv.effects.slashTrails.add(new float[]{slx, sly, slr,        spawnMs, slAng, 0});
                    gv.effects.slashTrails.add(new float[]{slx, sly, slr*0.85f,  spawnMs, slAng, 1});
                    gv.effects.slashTrails.add(new float[]{slx, sly, slr*1.1f,   spawnMs, slAng, 2});
                    gv.effects.slashTrails.add(new float[]{slx, sly, slr*0.6f,   spawnMs, slAng, 3});
                    gv.effects.slashTrails.add(new float[]{slx, sly, slr*1.3f,   spawnMs, slAng, 4});
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }
    private void sendInput(Player lp){
        try{
            JSONObject o=new JSONObject();
            // Joystick (kept for host-side angle/aim logic)
            o.put("0",gv.moveStick.getX()); o.put("1",gv.moveStick.getY());
            o.put("2",gv.aimStick.getX());  o.put("3",gv.aimStick.getY());
            float _ax=gv.aimStick.getX(), _ay=gv.aimStick.getY();
            float _ft=gv.getFireThresh();
            o.put("4", gv.aimStick.isActive() && (_ax*_ax+_ay*_ay) > _ft*_ft);
            o.put("5",lp.gunIndex);
            o.put("6",lp.currentGun().reloading);
            // ── Authoritative client position (avoids dual-simulation drift) ──
            o.put("px", lp.x); o.put("py", lp.y);
            // Passive skill levels
            o.put("7",lp.skillReload);
            o.put("8",lp.skillFireRate);
            o.put("9",lp.skillRange);
            o.put("10",lp.skillMoveSpeed);
            // Active skill
            o.put("11",lp.activeSkillType);
            // FIX Bug6: send ms (not seconds) — previously /1000 caused up to 999ms
            // of early expiry for stealth/shield on the host and other clients.
            long msRem=Math.max(0,lp.skillActiveUntil-System.currentTimeMillis());
            o.put("12",msRem);
            o.put("13",lp.shieldHp);
            // FIX Bug5: Heal event flag — host applies hp+40 on its authoritative copy.
            // Heal is instant (no skillActiveUntil) so host had no way to learn about it,
            // and overwrote the healed hp within 33ms via state update.
            o.put("hlt", gv.pendingHealEvent ? 1 : 0);
            gv.pendingHealEvent = false;
            // Dash position override (already folded into px/py above; flag kept for compat)
            o.put("14", gv.pendingPositionSync ? 1 : 0);
            gv.pendingPositionSync = false;
            // ── Pending bomb throw ─────────────────────────────────────────────
            if (gv.pendingBombSend != null) {
                o.put("bt", 1);
                o.put("bvx", gv.pendingBombSend[0]);
                o.put("bvy", gv.pendingBombSend[1]);
                o.put("bmr", gv.pendingBombSend[2]);
                gv.pendingBombSend = null;
            } else {
                o.put("bt", 0);
            }
            // ── Pending Volt Chakram launch ────────────────────────────────────
            if (gv.pendingVoltLaunch != null) {
                o.put("vcl", 1);
                o.put("vcax", gv.pendingVoltLaunch[0]);
                o.put("vcay", gv.pendingVoltLaunch[1]);
                o.put("vcc",  gv.pendingVoltLaunch[2]);
                gv.pendingVoltLaunch = null;
            } else {
                o.put("vcl", 0);
            }
            // ── Pending Shadow Blade launch ────────────────────────────────────
            if (gv.pendingShadowBlade != null) {
                o.put("sbl", 1);
                o.put("sbax", gv.pendingShadowBlade[0]);
                o.put("sbay", gv.pendingShadowBlade[1]);
                o.put("sbc",  gv.pendingShadowBlade[2]);
                gv.pendingShadowBlade = null;
            } else {
                o.put("sbl", 0);
            }
            // ── Pending Quick Slash ────────────────────────────────────────────
            if (gv.pendingQuickSlash != null) {
                o.put("qsl", 1);
                o.put("qsax", gv.pendingQuickSlash[0]);
                o.put("qsay", gv.pendingQuickSlash[1]);
                gv.pendingQuickSlash = null;
            } else {
                o.put("qsl", 0);
            }
            gv.net.sendInput(o.toString());
        }catch(Exception e){ if(gv.net!=null) e.printStackTrace(); }
    }

    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    void onHostDiscovered(String ip,String n){}
    void onJoined(int id){
        // Network thread — just assign (volatile reference, atomic)
        Player p=new Player(); p.id=id; p.name=gv.savedName; p.guns=Gun.createAll();
        float[] sp=GameView.SPAWNS[id%GameView.SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;  // ← must be set or client stays "dead" forever
        gv.localPlayer=p;
    }
    void onPlayerJoined(int id,String name){
        if(gv.remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=GameView.SPAWNS[id%GameView.SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;
        gv.remote.put(id,p); gv.addFeed(name+" joined");
    }
    // onStateUpdate: handled directly in GameView
    void onDisconnected(){
        gv.addFeed("⚠ Disconnected — reconnecting…");
    }
    void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            gv.inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f,
                (float)o.optInt("7",0),(float)o.optInt("8",0),
                (float)o.optInt("9",0),(float)o.optInt("10",0),
                (float)o.optInt("11",0),(float)o.optLong("12",0),
                (float)o.optDouble("13",0),
                (float)o.optDouble("px",-1),   // [14] authoritative x (-1 = not provided)
                (float)o.optDouble("py",-1),   // [15] authoritative y
                (float)o.optInt("14",0),        // [16] dash flag (unused now, kept for compat)
                (float)o.optInt("hlt",0)        // [17] FIX Bug5: heal event flag
            });
            // FIX: Queue bomb/VC events instead of touching ArrayLists directly from the
            // network thread.  gv.activeBombs and gv.voltChakrams are plain ArrayLists; concurrent
            // modification from two threads causes ConcurrentModificationException crashes.
            // The game thread drains both queues inside drainNetEvents() each frame.
            if(o.optInt("bt",0)==1){
                Player p=gv.remote.get(pid);
                if(p!=null&&p.alive&&p.bombs>0){
                    p.bombs--;
                    gv.netBombQ.add(new float[]{pid, p.x, p.y,
                        (float)o.getDouble("bvx"),
                        (float)o.getDouble("bvy"),
                        (float)o.getDouble("bmr")});
                }
            }
            // ── Volt Chakram launch from client — queued for game thread ──────
            if(o.optInt("vcl",0)==1){
                Player p=gv.remote.get(pid);
                if(p!=null&&p.alive&&gv.isVoltChakram(p.currentGun())){
                    gv.netVcQ.add(new float[]{pid,
                        (float)o.getDouble("vcax"),
                        (float)o.getDouble("vcay"),
                        (float)o.getDouble("vcc")});
                }
            }
            // ── Shadow Blade launch from client — queued for game thread ───────
            // FIX: clients send their aim direction + charge so the host can run
            // launchShadowBlade authoritatively (damage, dash, slash trail).
            if(o.optInt("sbl",0)==1){
                Player p=gv.remote.get(pid);
                if(p!=null&&p.alive&&gv.isShadowBlade(p.currentGun())){
                    gv.netSbQ.add(new float[]{pid,
                        (float)o.getDouble("sbax"),
                        (float)o.getDouble("sbay"),
                        (float)o.optDouble("sbc",1.0)});
                }
            }
            // ── Quick Slash from client — queued for game thread ───────────────
            if(o.optInt("qsl",0)==1){
                Player p=gv.remote.get(pid);
                if(p!=null&&p.alive&&gv.isShadowBlade(p.currentGun())){
                    gv.netQsQ.add(new float[]{pid,
                        (float)o.optDouble("qsax",0),
                        (float)o.optDouble("qsay",0)});
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }
    /**
     * FIX: Drains bomb and Volt-Chakram creation events that were queued by the
     * network thread into game-thread-owned ArrayLists (gv.activeBombs, gv.voltChakrams).
     * Must only be called from the game thread (inside update()).
     */
    private void drainNetEvents() {
        float[] be;
        while ((be = gv.netBombQ.poll()) != null) {
            int bpid = (int) be[0];
            Player bp = gv.remote.get(bpid);
            if (bp != null && bp.alive) {
                // Duplicate check is now safe — we are on the game thread
                boolean hasBomb = false;
                for (Bomb b : gv.activeBombs)
                    if (b.ownerId == bp.id && !b.isDone() && b.explodedAt < 0) { hasBomb = true; break; }
                if (!hasBomb) {
                    Bomb bomb = new Bomb(be[1], be[2], bpid);
                    bomb.vx = be[3]; bomb.vy = be[4]; bomb.maxRange = be[5];
                    gv.activeBombs.add(bomb);
                }
            }
        }
        float[] ve;
        while ((ve = gv.netVcQ.poll()) != null) {
            int vpid = (int) ve[0];
            Player vp = gv.remote.get(vpid);
            if (vp != null && vp.alive && gv.isVoltChakram(vp.currentGun()))
                launchVoltChakrams(vp, ve[1], ve[2], ve[3]);
        }
        // FIX: drain Shadow Blade queue — temporarily set gv.shadowBladeCharge to the
        // client's reported charge so launchShadowBlade picks the right dash/no-dash path.
        float[] sbe;
        while ((sbe = gv.netSbQ.poll()) != null) {
            int sbpid = (int) sbe[0];
            Player sbp = gv.remote.get(sbpid);
            if (sbp != null && sbp.alive && gv.isShadowBlade(sbp.currentGun())) {
                float savedCharge = gv.shadowBladeCharge;
                gv.shadowBladeCharge = sbe[3]; // use client's charge for this call
                launchShadowBlade(sbp, sbe[1], sbe[2]);
                gv.shadowBladeCharge = savedCharge;
            }
        }
        // Drain Quick Slash queue
        float[] qse;
        while ((qse = gv.netQsQ.poll()) != null) {
            int qspid = (int) qse[0];
            Player qsp = gv.remote.get(qspid);
            if (qsp != null && qsp.alive && gv.isShadowBlade(qsp.currentGun())) {
                launchQuickSlash(qsp, qse[1], qse[2]);
            }
        }
    }

}
