package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.viewmodel.ReaderViewModel
import java.io.File
import kotlin.math.roundToInt

private val BAR_BG = Color.Black.copy(alpha = 0.78f)

@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    chapter: Chapter,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialProgress: ReadingProgress?,
    onBack: () -> Unit,
    onChapterChange: (Chapter, Int) -> Unit
) {
    BackHandler { onBack() }

    val pages       by viewModel.pages.collectAsStateWithLifecycle()
    val loading     by viewModel.loading.collectAsStateWithLifecycle()
    val error       by viewModel.error.collectAsStateWithLifecycle()
    val scrollSpeed by viewModel.scrollSpeed.collectAsStateWithLifecycle()
    val minImageDim by viewModel.minImageDimension.collectAsStateWithLifecycle()
    val sortOrder   by viewModel.sortOrder.collectAsStateWithLifecycle()

    // Keyed on chapter.id so scroll position resets to 0 on every chapter change.
    val listState    = remember(chapter.id) { LazyListState() }
    var showControls by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(chapter.id) { viewModel.loadChapter(chapter, chapterIndex) }

    var scrollRestored by remember(chapter.id) { mutableStateOf(false) }
    LaunchedEffect(pages.size) {
        if (pages.isNotEmpty() && !scrollRestored) {
            scrollRestored = true
            if (initialProgress?.chapterIndex == chapterIndex) {
                val target = initialProgress.pageIndex.coerceIn(0, pages.size - 1)
                listState.scrollToItem(target, initialProgress.scrollOffset)
            }
        }
    }

    LaunchedEffect(
        listState.firstVisibleItemIndex,
        listState.firstVisibleItemScrollOffset
    ) {
        if (pages.isNotEmpty()) {
            viewModel.saveProgress(
                pageIndex    = listState.firstVisibleItemIndex,
                scrollOffset = listState.firstVisibleItemScrollOffset
            )
        }
    }

    if (showSettings) {
        ReaderSettingsDialog(
            scrollSpeed   = scrollSpeed,
            minImageDim   = minImageDim,
            sortOrder     = sortOrder,
            onScrollSpeed = { viewModel.setScrollSpeed(it) },
            onMinImageDim = { viewModel.setMinImageDimension(it) },
            onSortOrder   = { viewModel.setSortOrder(it) },
            onReload      = { viewModel.reloadChapter(); showSettings = false },
            onDismiss     = { showSettings = false }
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when {
            loading -> {
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Extracting chapter…",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            error != null -> {
                Column(
                    Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.BrokenImage,
                        contentDescription = null,
                        tint     = Color.Red.copy(alpha = 0.7f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(error ?: "Unknown error", color = Color.White,
                        style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { viewModel.loadChapter(chapter, chapterIndex) }) {
                        Text("Retry")
                    }
                }
            }

            pages.isEmpty() -> {
                Text(
                    "No images found in this chapter",
                    color    = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            else -> {
                LazyColumn(
                    state         = listState,
                    flingBehavior = rememberMomentumFlingBehavior(velocityMultiplier = scrollSpeed),
                    modifier      = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { showControls = !showControls }
                        }
                ) {
                    itemsIndexed(pages, key = { _, f -> f.absolutePath }) { _, file ->
                        MangaPage(file)
                    }
                    item(key = "footer") {
                        ChapterFooter(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                            onNext = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) }
                        )
                    }
                }

                AnimatedVisibility(visible = showControls, enter = fadeIn(), exit = fadeOut()) {
                    Box(Modifier.fillMaxSize()) {
                        ReaderTopBar(
                            chapter       = chapter,
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            currentPage   = listState.firstVisibleItemIndex + 1,
                            totalPages    = pages.size,
                            onBack        = onBack,
                            onSettings    = { showSettings = true },
                            modifier      = Modifier.align(Alignment.TopCenter)
                        )
                        ReaderBottomBar(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                            onNext = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) },
                            modifier      = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }
    }
}

// ── Settings dialog ────────────────────────────────────────────────────────────

@Composable
private fun ReaderSettingsDialog(
    scrollSpeed: Float,
    minImageDim: Int,
    sortOrder: SortOrder,
    onScrollSpeed: (Float) -> Unit,
    onMinImageDim: (Int) -> Unit,
    onSortOrder: (SortOrder) -> Unit,
    onReload: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest  = onDismiss,
        containerColor    = Color(0xFF1C1340),
        titleContentColor = Color.White,
        title = { Text("Reader Settings", style = MaterialTheme.typography.titleMedium) },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {

                // ── Scroll speed ──────────────────────────────────────────────
                SettingHeader("Scroll Speed", "%.1fx".format(scrollSpeed))
                Slider(
                    value         = scrollSpeed,
                    onValueChange = onScrollSpeed,
                    valueRange    = 0.8f..3.0f,
                    steps         = 10,
                    colors        = readerSliderColors()
                )
                SettingHint("How far pages travel after a flick. 1.0x = stock; 2.0x = snappy webtoon feel.")

                Spacer(Modifier.height(14.dp))

                // ── Image filter ──────────────────────────────────────────────
                SettingHeader(
                    "Image Filter",
                    if (minImageDim == 0) "Off" else "${minImageDim}px min"
                )
                // steps=7 → 9 snap positions: 0, 100, 200, 300, 400, 500, 600, 700, 800
                Slider(
                    value         = minImageDim.toFloat(),
                    onValueChange = { onMinImageDim(it.roundToInt()) },
                    valueRange    = 0f..800f,
                    steps         = 7,
                    colors        = readerSliderColors()
                )
                SettingHint(
                    "Drops images smaller than this — removes site icons, ad banners, and " +
                    "other noise. Recommended: 200–400px. Takes effect after cache is cleared."
                )

                Spacer(Modifier.height(14.dp))

                // ── Page order ────────────────────────────────────────────────
                Text(
                    "Page Order",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(Modifier.height(2.dp))

                data class OrderOption(val order: SortOrder, val label: String, val hint: String)
                val options = listOf(
                    OrderOption(
                        SortOrder.AUTO,
                        "Auto",
                        "Use URL numbers if they look sequential; otherwise file order."
                    ),
                    OrderOption(
                        SortOrder.ENCOUNTER,
                        "File order",
                        "Images in the order they appear in the saved file. " +
                        "Try this if Auto gives wrong order — browser MHTML usually " +
                        "stores pages in reading order already."
                    ),
                    OrderOption(
                        SortOrder.URL_PAGE,
                        "URL number",
                        "Always sort by the number in each image's URL. " +
                        "Try this if file order is scrambled but URLs have clear page numbers."
                    )
                )

                Column(Modifier.selectableGroup()) {
                    options.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = sortOrder == opt.order,
                                    role     = Role.RadioButton,
                                    onClick  = { onSortOrder(opt.order) }
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            RadioButton(
                                selected = sortOrder == opt.order,
                                onClick  = null,
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor   = MaterialTheme.colorScheme.primary,
                                    unselectedColor = Color.White.copy(alpha = 0.4f)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    opt.label,
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    opt.hint,
                                    color = Color.White.copy(alpha = 0.42f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(2.dp))
                SettingHint("Page order takes effect after cache is cleared (re-open the chapter).")
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Reload forces a fresh extraction from the MHTML file, clearing
                // any cache that may have been built by an older version of the app.
                OutlinedButton(
                    onClick  = onReload,
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reload chapter from file")
                }
                TextButton(
                    onClick  = onDismiss,
                    modifier = Modifier.align(Alignment.End),
                    colors   = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) { Text("Done") }
            }
        }
    )
}

// ── Shared helpers ─────────────────────────────────────────────────────────────

@Composable
private fun SettingHeader(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.titleSmall)
        Text(value, color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun SettingHint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = Color.White.copy(alpha = 0.42f)
    )
}

@Composable
private fun readerSliderColors() = SliderDefaults.colors(
    thumbColor       = MaterialTheme.colorScheme.primary,
    activeTrackColor = MaterialTheme.colorScheme.primary
)

// ── Sub-composables ────────────────────────────────────────────────────────────

@Composable
private fun MangaPage(file: File) {
    SubcomposeAsyncImage(
        model              = file,
        contentDescription = null,
        contentScale       = ContentScale.FillWidth,
        modifier           = Modifier.fillMaxWidth().wrapContentHeight(),
        loading = {
            Box(
                Modifier.fillMaxWidth().aspectRatio(0.7f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color       = Color.White.copy(alpha = 0.5f),
                    modifier    = Modifier.size(32.dp),
                    strokeWidth = 2.dp
                )
            }
        },
        error = {
            Box(
                Modifier.fillMaxWidth().height(80.dp).background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Text("Page failed to load", color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    )
}

@Composable
private fun ReaderTopBar(
    chapter: Chapter,
    chapterIndex: Int,
    totalChapters: Int,
    currentPage: Int,
    totalPages: Int,
    onBack: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier          = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(chapter.title, color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "Ch ${chapterIndex + 1}/$totalChapters  ·  Pg $currentPage/$totalPages",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ReaderBottomBar(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier              = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = onPrev, enabled = chapterIndex > 0,
                colors  = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.NavigateBefore, null)
                Spacer(Modifier.width(4.dp))
                Text("Prev")
            }
            Text(
                "Ch ${chapterIndex + 1} / $totalChapters",
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium
            )
            TextButton(
                onClick = onNext, enabled = chapterIndex < totalChapters - 1,
                colors  = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Text("Next")
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.NavigateNext, null)
            }
        }
    }
}

@Composable
private fun ChapterFooter(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
        Spacer(Modifier.height(20.dp))

        if (chapterIndex < totalChapters - 1) {
            Button(
                onClick  = onNext,
                modifier = Modifier.fillMaxWidth(0.7f),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.NavigateNext, null)
                Spacer(Modifier.width(6.dp))
                Text("Next Chapter")
            }
        } else {
            Text("You've reached the end!", color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.bodyMedium)
        }

        if (chapterIndex > 0) {
            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = onPrev,
                colors  = ButtonDefaults.textButtonColors(
                    contentColor = Color.White.copy(alpha = 0.6f)
                )
            ) {
                Icon(Icons.Default.NavigateBefore, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Previous Chapter")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
