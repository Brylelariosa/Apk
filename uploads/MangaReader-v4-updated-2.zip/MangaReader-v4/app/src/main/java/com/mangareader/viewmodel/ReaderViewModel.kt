package com.mangareader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.ProgressManager
import com.mangareader.manager.SettingsManager
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReaderViewModel(app: Application) : AndroidViewModel(app) {

    private val mhtmlParser     = MhtmlParser(app)
    private val progressManager = ProgressManager(app)
    private val settingsManager = SettingsManager(app)

    private val _pages   = MutableStateFlow<List<File>>(emptyList())
    val pages: StateFlow<List<File>> = _pages

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // ── Reader settings ────────────────────────────────────────────────────────

    private val _scrollSpeed = MutableStateFlow(settingsManager.scrollSpeed)
    val scrollSpeed: StateFlow<Float> = _scrollSpeed

    private val _minImageDimension = MutableStateFlow(settingsManager.minImageDimension)
    val minImageDimension: StateFlow<Int> = _minImageDimension

    private val _sortOrder = MutableStateFlow(settingsManager.sortOrder)
    val sortOrder: StateFlow<SortOrder> = _sortOrder

    // ── Chapter state ──────────────────────────────────────────────────────────

    private var currentChapter: Chapter? = null
    private var currentSeriesId   = ""
    private var currentChapterIdx = 0

    fun loadChapter(chapter: Chapter, chapterIndex: Int) {
        currentChapter    = chapter
        currentSeriesId   = chapter.seriesId
        currentChapterIdx = chapterIndex

        viewModelScope.launch {
            _loading.value = true
            _error.value   = null
            _pages.value   = emptyList()

            val seriesCacheRoot = File(
                getApplication<Application>().cacheDir, "manga/${chapter.seriesId}"
            )
            val cacheDir    = File(seriesCacheRoot, chapter.id)
            val versionFile = File(cacheDir, ".version")

            runCatching {
                withContext(Dispatchers.IO) {
                    // Read the parser version that was used for the existing cache.
                    // If it doesn't match the current PARSER_VERSION the extraction
                    // logic has changed since the cache was written, so we discard it
                    // and re-extract.  This is what makes fixes like the QP-decode
                    // correction take effect automatically without the user having to
                    // manually clear anything.
                    val cachedVersion = runCatching {
                        versionFile.readText().trim().toInt()
                    }.getOrDefault(-1)

                    val cached = if (cacheDir.exists() && cachedVersion == PARSER_VERSION) {
                        cacheDir.listFiles()
                            ?.filter { it.extension in listOf("jpg","png","webp","gif","bmp") }
                            ?.sortedBy { it.name }
                            .orEmpty()
                    } else emptyList()

                    if (cached.isNotEmpty()) {
                        cacheDir.setLastModified(System.currentTimeMillis())
                        cached
                    } else {
                        // Wipe any stale/version-mismatched cache before re-extracting.
                        if (cacheDir.exists()) cacheDir.deleteRecursively()
                        cacheDir.mkdirs()

                        val extracted = mhtmlParser.extractImages(
                            mhtmlPath         = chapter.mhtmlPath,
                            cacheDir          = cacheDir,
                            minImageDimension = settingsManager.minImageDimension,
                            sortOrder         = settingsManager.sortOrder
                        )
                        // Only stamp the version on a successful (non-empty) extraction
                        // so a partial failure doesn't permanently suppress re-extraction.
                        if (extracted.isNotEmpty()) {
                            versionFile.writeText(PARSER_VERSION.toString())
                        }
                        pruneOldChapterCache(seriesCacheRoot, cacheDir)
                        extracted
                    }
                }
            }.onSuccess { files ->
                _pages.value = files
                if (files.isEmpty()) _error.value = "No images found in this chapter"
            }.onFailure { e ->
                _error.value = "Failed to load chapter: ${e.message}"
            }

            _loading.value = false
        }
    }

    private fun pruneOldChapterCache(seriesCacheRoot: File, keepDir: File, keep: Int = 3) {
        val dirs = seriesCacheRoot.listFiles()?.filter { it.isDirectory } ?: return
        dirs.sortedByDescending { it.lastModified() }
            .drop(keep)
            .filter { it.absolutePath != keepDir.absolutePath }
            .forEach { it.deleteRecursively() }
    }

    fun saveProgress(pageIndex: Int, scrollOffset: Int = 0) {
        if (currentSeriesId.isEmpty()) return
        progressManager.saveProgress(
            ReadingProgress(
                seriesId     = currentSeriesId,
                chapterIndex = currentChapterIdx,
                pageIndex    = pageIndex,
                scrollOffset = scrollOffset
            )
        )
    }

    fun clearCache(chapter: Chapter) {
        File(
            getApplication<Application>().cacheDir,
            "manga/${chapter.seriesId}/${chapter.id}"
        ).deleteRecursively()
    }

    // ── Settings mutators ──────────────────────────────────────────────────────

    fun setScrollSpeed(value: Float) {
        settingsManager.scrollSpeed = value
        _scrollSpeed.value = value
        // Scroll speed is applied live via the fling behaviour — no re-extraction needed.
    }

    fun setMinImageDimension(value: Int) {
        settingsManager.minImageDimension = value
        _minImageDimension.value = value
        reloadCurrentChapter()
    }

    fun setSortOrder(value: SortOrder) {
        settingsManager.sortOrder = value
        _sortOrder.value = value
        reloadCurrentChapter()
    }

    /** Force-clears the cache and re-extracts the current chapter from the MHTML file. */
    fun reloadChapter() = reloadCurrentChapter()

    private fun reloadCurrentChapter() {
        val ch = currentChapter ?: return
        clearCache(ch)
        loadChapter(ch, currentChapterIdx)
    }

    companion object {
        /**
         * Increment this whenever the extraction or sort logic changes so that
         * chapters cached by older builds are automatically re-extracted.
         *
         * History:
         *   1 – initial cache
         *   2 – added dimension filter
         *   3 – HTML-order detection + QP decode (fixes reverse-order sites)
         */
        const val PARSER_VERSION = 3
    }
}
