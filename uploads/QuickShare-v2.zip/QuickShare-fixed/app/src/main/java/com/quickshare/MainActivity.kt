package com.quickshare

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import com.quickshare.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.DecimalFormat

class MainActivity : AppCompatActivity(), WifiP2pManager.ChannelListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver

    private var isWifiP2pEnabled = false
    private var connectedDeviceInfo: WifiP2pInfo? = null
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var deviceAdapter: DeviceAdapter

    // Mode tracking
    private var isReceiverMode = false    // user pressed "Receive" button
    private var isHotspotMode = false     // connected via QR/WiFi hotspot path
    private var boundNetwork: Network? = null
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null

    private var selectedFileUri: Uri? = null
    private var selectedFileName: String = ""
    private var selectedFileSize: Long = 0L

    private val SERVER_PORT = 8988
    // 256 KB buffers — 4x the original, big win for large files
    private val BUFFER_SIZE = 1024 * 256

    private var serverJob: Job? = null
    private var isReceiving = false

    companion object {
        private const val TAG = "QuickShare"
        private const val QR_PREFIX = "QS:"
        // WiFi Direct Group Owner always has this IP on Android
        private const val GO_IP = "192.168.49.1"
    }

    // ── Activity Result Launchers ─────────────────────────────────────────────

    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result: ScanIntentResult ->
        result.contents?.let { parseAndConnectQR(it) }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) initWifiDirect()
        else showToast("Some permissions denied — features may be limited")
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedFileUri = it
            val (name, size) = getFileInfo(it)
            selectedFileName = name
            selectedFileSize = size
            binding.tvSelectedFile.text = "$name (${formatSize(size)})"
            binding.btnSendFile.isEnabled = isConnectedInAnyMode()
            binding.cardSelectedFile.visibility = View.VISIBLE
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        checkPermissionsAndInit()
    }

    override fun onResume() {
        super.onResume()
        if (::receiver.isInitialized) {
            try { registerWifiReceiver() } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        if (::receiver.isInitialized) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serverJob?.cancel()
        releaseNetworkCallback()
    }

    // ── UI Setup ──────────────────────────────────────────────────────────────

    private fun setupUI() {
        deviceAdapter = DeviceAdapter(peers) { device -> connectToDevice(device) }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter

        // 📥 Receive: create group + show QR
        binding.btnReceive.setOnClickListener {
            if (isReceiving) stopReceiveMode() else startReceiveMode()
        }

        // 📷 Scan QR: sender flow — scan receiver's QR
        binding.btnScanQR.setOnClickListener { scanQR() }

        // 🔍 Discover: classic WiFi Direct peer discovery
        binding.btnDiscover.setOnClickListener {
            if (!isWifiP2pEnabled) { showToast("Please enable WiFi"); return@setOnClickListener }
            discoverPeers()
        }

        binding.btnPickFile.setOnClickListener { filePickerLauncher.launch("*/*") }

        binding.btnSendFile.setOnClickListener {
            selectedFileUri?.let { uri ->
                if (isConnectedInAnyMode()) sendFile(uri)
                else showToast("Connect to a receiver first")
            } ?: showToast("Please select a file first")
        }

        binding.btnDisconnect.setOnClickListener { disconnect() }

        updateStatus("Ready — tap 📥 Receive on the receiver, 📷 Scan QR on the sender")
        updateConnectionUI(false)
    }

    private fun isConnectedInAnyMode() = connectedDeviceInfo != null || isHotspotMode

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun checkPermissionsAndInit() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += listOf(
                Manifest.permission.NEARBY_WIFI_DEVICES,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) initWifiDirect() else permissionLauncher.launch(missing.toTypedArray())
    }

    // ── WiFi Direct ───────────────────────────────────────────────────────────

    private fun initWifiDirect() {
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, this)
        receiver = WiFiDirectBroadcastReceiver(manager, channel, this)
        registerWifiReceiver()
    }

    private fun registerWifiReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, filter)
    }

    fun setWifiP2pEnabled(enabled: Boolean) {
        isWifiP2pEnabled = enabled
        if (!enabled) {
            updateStatus("WiFi is OFF — please enable WiFi")
            updateConnectionUI(false)
        }
    }

    private fun discoverPeers() {
        updateStatus("Discovering nearby devices...")
        binding.progressBar.visibility = View.VISIBLE
        if (!hasLocationPerm()) { showToast("Location permission needed"); return }

        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { updateStatus("Scanning for devices...") }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                val msg = when (reason) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported on this device"
                    WifiP2pManager.BUSY -> "System busy — try again"
                    else -> "Discovery failed (code $reason)"
                }
                updateStatus(msg); showToast(msg)
            }
        })
    }

    fun updatePeerList(deviceList: Collection<WifiP2pDevice>) {
        binding.progressBar.visibility = View.GONE
        peers.clear(); peers.addAll(deviceList)
        deviceAdapter.notifyDataSetChanged()
        if (peers.isEmpty()) {
            updateStatus("No devices found — make sure receiver tapped 📥 Receive")
            binding.tvNoPeers.visibility = View.VISIBLE
        } else {
            updateStatus("Found ${peers.size} device(s) — tap to connect")
            binding.tvNoPeers.visibility = View.GONE
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            // KEY FIX: sender prefers client role (0), receiver prefers GO (15).
            // This prevents the sender from becoming the group owner,
            // which previously caused self-connection bugs.
            groupOwnerIntent = if (isReceiverMode) 15 else 0
        }
        if (!hasLocationPerm()) return
        updateStatus("Connecting to ${device.deviceName}...")
        binding.progressBar.visibility = View.VISIBLE

        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { showToast("Connection request sent to ${device.deviceName}") }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                showToast("Connection failed: $reason")
                updateStatus("Connection failed — try again")
            }
        })
    }

    fun onConnectionInfoAvailable(info: WifiP2pInfo) {
        binding.progressBar.visibility = View.GONE
        connectedDeviceInfo = info

        if (info.groupFormed) {
            val role = if (info.isGroupOwner) "Host (GO)" else "Client"
            val goIp = info.groupOwnerAddress?.hostAddress ?: "?"
            updateStatus("✓ P2P Connected as $role — GO IP: $goIp")
            updateConnectionUI(true)

            // KEY FIX: only start server if user chose receive mode AND we're the GO.
            // Old code always started server on GO regardless of intent, causing the
            // sender (when accidentally becoming GO) to block-receive instead of send.
            if (info.isGroupOwner && isReceiverMode && !isReceiving) {
                startReceiveServer()
            }
        }
    }

    private fun disconnect() {
        releaseNetworkCallback()
        if (connectedDeviceInfo != null) {
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = resetConnectionState()
                override fun onFailure(r: Int) = resetConnectionState()
            })
        } else {
            resetConnectionState()
        }
    }

    private fun resetConnectionState() {
        connectedDeviceInfo = null
        isHotspotMode = false
        boundNetwork = null
        isReceiverMode = false
        stopReceiveServer()
        updateConnectionUI(false)
        updateStatus("Disconnected — Ready")
    }

    override fun onChannelDisconnected() {
        showToast("WiFi Direct channel lost — reconnecting...")
        if (::manager.isInitialized) {
            channel = manager.initialize(this, mainLooper, this)
        }
    }

    // ── Receive Mode (QR Hotspot) ─────────────────────────────────────────────
    //
    // Flow: createGroup() → receiver becomes WiFi Direct Group Owner (always IP
    // 192.168.49.1) → requestGroupInfo() grabs SSID+passphrase → show as QR.
    // Sender scans QR and connects to that WiFi network, then sends to 192.168.49.1:8988.

    private fun startReceiveMode() {
        if (!::manager.isInitialized) {
            showToast("WiFi not ready yet — try again")
            return
        }
        isReceiverMode = true
        binding.btnReceive.text = "⏹ Stop Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.red))
        updateStatus("Setting up hotspot…")
        binding.progressBar.visibility = View.VISIBLE

        // Always remove any stale group first to ensure a clean start
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = createGroupForReceiving()
            override fun onFailure(r: Int) = createGroupForReceiving() // ignore — may not exist
        })
    }

    private fun createGroupForReceiving() {
        if (!hasLocationPerm()) {
            binding.progressBar.visibility = View.GONE
            showToast("Location permission needed")
            return
        }
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                // Give the driver ~600ms to fully form the group before requesting info
                lifecycleScope.launch {
                    delay(600)
                    manager.requestGroupInfo(channel) { group ->
                        binding.progressBar.visibility = View.GONE
                        startReceiveServer()
                        if (group != null) {
                            updateStatus("📥 Ready to receive — show the QR to the sender")
                            showQRDialog(group.networkName, group.passphrase)
                        } else {
                            updateStatus("📥 Server active — sender can discover via WiFi Direct")
                        }
                    }
                }
            }

            override fun onFailure(reason: Int) {
                // Group may already exist (reason == BUSY = 2). Try requesting info anyway.
                manager.requestGroupInfo(channel) { group ->
                    binding.progressBar.visibility = View.GONE
                    startReceiveServer()
                    if (group != null) {
                        updateStatus("📥 Ready to receive — show the QR to the sender")
                        showQRDialog(group.networkName, group.passphrase)
                    } else {
                        updateStatus("📥 Server active (createGroup failed: $reason) — use Discover")
                        showToast("Hotspot setup issue — try WiFi Direct discovery as fallback")
                    }
                }
            }
        })
    }

    private fun stopReceiveMode() {
        isReceiverMode = false
        stopReceiveServer()
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(r: Int) {}
        })
        binding.btnReceive.text = "📥 Receive"
        binding.btnReceive.setBackgroundColor(getColor(R.color.green))
        updateStatus("Receive mode stopped")
    }

    // ── QR Code ───────────────────────────────────────────────────────────────

    private fun showQRDialog(ssid: String, passphrase: String) {
        val json = JSONObject().apply { put("s", ssid); put("p", passphrase) }.toString()
        val content = QR_PREFIX + json

        val size = 600
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) for (y in 0 until size) {
            bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }

        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            setPadding(40, 40, 40, 16)
        }

        AlertDialog.Builder(this)
            .setTitle("📥 Ready to Receive")
            .setMessage("Have the sender tap  📷 Scan QR  and scan this code")
            .setView(iv)
            .setPositiveButton("Keep Active") { d, _ -> d.dismiss() }
            .setNegativeButton("Stop Receiving") { d, _ -> d.dismiss(); stopReceiveMode() }
            .setCancelable(false)
            .show()
    }

    private fun scanQR() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Scan the receiver's QR code")
            .setCameraId(0)
            .setBeepEnabled(true)
            .setBarcodeImageEnabled(false)
        qrScanLauncher.launch(options)
    }

    private fun parseAndConnectQR(content: String) {
        try {
            val json = content.removePrefix(QR_PREFIX)
            val obj = JSONObject(json)
            val ssid = obj.getString("s")
            val passphrase = obj.getString("p")
            updateStatus("QR scanned — connecting to $ssid…")
            connectViaHotspot(ssid, passphrase)
        } catch (e: Exception) {
            showToast("Invalid QR code — make sure it's from QuickShare")
            Log.e(TAG, "QR parse error: ${e.message}")
        }
    }

    // ── Hotspot Connection (sender side after QR scan) ────────────────────────

    private fun connectViaHotspot(ssid: String, passphrase: String) {
        binding.progressBar.visibility = View.VISIBLE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            connectViaNetworkSpecifier(ssid, passphrase)
        } else {
            @Suppress("DEPRECATION")
            connectLegacyWifi(ssid, passphrase)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun connectViaNetworkSpecifier(ssid: String, passphrase: String) {
        val specifier = WifiNetworkSpecifier.Builder()
            .setSsid(ssid)
            .setWpa2Passphrase(passphrase)
            .build()

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .setNetworkSpecifier(specifier)
            .build()

        val cm = getSystemService(ConnectivityManager::class.java)
        releaseNetworkCallback()

        wifiNetworkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                boundNetwork = network
                isHotspotMode = true
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("✅ Connected to receiver!\nPick a file and tap 🚀 Send")
                    updateConnectionUI(true)
                }
            }
            override fun onUnavailable() {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("❌ Could not connect — make sure receiver's QR is still active")
                    showToast("Connection failed — receiver may need to restart Receive mode")
                }
            }
            override fun onLost(network: Network) {
                if (boundNetwork == network) {
                    boundNetwork = null; isHotspotMode = false
                    runOnUiThread { updateStatus("Connection lost") }
                }
            }
        }
        cm.requestNetwork(request, wifiNetworkCallback!!)
        updateStatus("Connecting to receiver's hotspot…")
    }

    @Suppress("DEPRECATION")
    private fun connectLegacyWifi(ssid: String, passphrase: String) {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val cfg = WifiConfiguration().apply {
            SSID = "\"$ssid\""
            preSharedKey = "\"$passphrase\""
            allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK)
        }
        val id = wm.addNetwork(cfg)
        if (id == -1) {
            binding.progressBar.visibility = View.GONE
            showToast("Failed to configure WiFi network — try manually connecting to: $ssid")
            return
        }
        wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()
        lifecycleScope.launch {
            delay(4000) // typical association time
            withContext(Dispatchers.Main) {
                binding.progressBar.visibility = View.GONE
                isHotspotMode = true; boundNetwork = null
                updateStatus("✅ Connected to receiver!\nPick a file and tap 🚀 Send")
                updateConnectionUI(true)
            }
        }
    }

    private fun releaseNetworkCallback() {
        wifiNetworkCallback?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) }
            catch (_: Exception) {}
            wifiNetworkCallback = null
        }
    }

    // ── TCP File Server (receiver side) ───────────────────────────────────────

    private fun startReceiveServer() {
        if (isReceiving) return
        isReceiving = true

        serverJob?.cancel()
        serverJob = lifecycleScope.launch(Dispatchers.IO) {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                serverSocket.reuseAddress = true
                serverSocket.receiveBufferSize = BUFFER_SIZE
                Log.d(TAG, "Server listening on :$SERVER_PORT")

                while (isActive && isReceiving) {
                    try {
                        val client = serverSocket.accept()
                        client.receiveBufferSize = BUFFER_SIZE
                        launch { handleIncomingFile(client) }
                    } catch (e: Exception) {
                        if (isActive && isReceiving) Log.e(TAG, "Accept error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server error: ${e.message}")
                withContext(Dispatchers.Main) { showToast("Server error: ${e.message}") }
            } finally {
                serverSocket?.close()
            }
        }
    }

    private fun stopReceiveServer() {
        isReceiving = false
        serverJob?.cancel()
        serverJob = null
    }

    private suspend fun handleIncomingFile(socket: Socket) {
        try {
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))

            // Protocol: [4 bytes name length][name bytes][8 bytes file size][file bytes]
            val nameLen = input.readInt()
            val nameBytes = ByteArray(nameLen)
            input.readFully(nameBytes)
            val fileName = String(nameBytes, Charsets.UTF_8)
            val fileSize = input.readLong()

            Log.d(TAG, "Receiving $fileName ($fileSize bytes)")
            withContext(Dispatchers.Main) {
                updateStatus("Receiving: $fileName (${formatSize(fileSize)})…")
                showProgressUI(true, fileName, fileSize)
            }

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()
            val outFile = File(downloadsDir, getUniqueFileName(downloadsDir, fileName))
            val output = BufferedOutputStream(FileOutputStream(outFile), BUFFER_SIZE)

            val buffer = ByteArray(BUFFER_SIZE)
            var totalReceived = 0L
            val startTime = System.currentTimeMillis()

            while (totalReceived < fileSize) {
                val bytesRead = input.read(buffer, 0, minOf(buffer.size, (fileSize - totalReceived).toInt()))
                if (bytesRead == -1) break
                output.write(buffer, 0, bytesRead)
                totalReceived += bytesRead

                val progress = ((totalReceived * 100) / fileSize).toInt()
                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                val speed = if (elapsed > 0) totalReceived / elapsed / 1024 / 1024 else 0.0
                withContext(Dispatchers.Main) { updateProgress(progress, totalReceived, fileSize, speed) }
            }

            output.flush(); output.close(); input.close(); socket.close()
            val avgSpeed = totalReceived / ((System.currentTimeMillis() - startTime) / 1000.0) / 1024 / 1024

            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("✅ Received: $fileName\n${formatSize(totalReceived)} at ${String.format("%.1f", avgSpeed)} MB/s → Downloads")
                showToast("Saved: ${outFile.name}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Receive error: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive failed: ${e.message}")
            }
        }
    }

    // ── TCP File Send (sender side) ───────────────────────────────────────────

    private fun sendFile(uri: Uri) {
        // Determine host IP:
        //  • QR/hotspot mode  → always 192.168.49.1 (the GO's fixed IP)
        //  • WiFi Direct mode → groupOwnerAddress (we should be the client here after
        //    groupOwnerIntent fix ensures the receiver became the GO)
        val hostIp: String = when {
            isHotspotMode -> GO_IP
            connectedDeviceInfo?.isGroupOwner == false ->
                connectedDeviceInfo?.groupOwnerAddress?.hostAddress ?: run {
                    showToast("Cannot determine receiver IP"); return
                }
            else -> {
                // Edge case: we ended up as GO but wanted to send.
                // Very rare after groupOwnerIntent fix — ask user to retry.
                showToast("Role conflict — tap Disconnect and let the other device Discover you instead")
                return
            }
        }

        lifecycleScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            try {
                withContext(Dispatchers.Main) {
                    updateStatus("Connecting to $hostIp…")
                    showProgressUI(true, selectedFileName, selectedFileSize)
                }

                socket = Socket()
                socket.sendBufferSize = BUFFER_SIZE
                socket.tcpNoDelay = true          // flush immediately — better for large sequential writes
                boundNetwork?.bindSocket(socket)   // bind to the correct WiFi interface (API 21+)
                socket.connect(InetSocketAddress(hostIp, SERVER_PORT), 8000)

                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                // Write header
                val nameBytes = selectedFileName.toByteArray(Charsets.UTF_8)
                output.writeInt(nameBytes.size)
                output.write(nameBytes)
                output.writeLong(selectedFileSize)

                // Write file
                val input = contentResolver.openInputStream(uri)
                    ?: throw IOException("Cannot open file")

                val buffer = ByteArray(BUFFER_SIZE)
                var totalSent = 0L
                val startTime = System.currentTimeMillis()

                while (true) {
                    val bytesRead = input.read(buffer)
                    if (bytesRead == -1) break
                    output.write(buffer, 0, bytesRead)
                    totalSent += bytesRead

                    val progress = if (selectedFileSize > 0) ((totalSent * 100) / selectedFileSize).toInt() else 0
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                    val speed = if (elapsed > 0) totalSent / elapsed / 1024 / 1024 else 0.0
                    withContext(Dispatchers.Main) { updateProgress(progress, totalSent, selectedFileSize, speed) }
                }

                output.flush(); input.close(); output.close()
                val avgSpeed = totalSent / ((System.currentTimeMillis() - startTime) / 1000.0) / 1024 / 1024

                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("✅ Sent: $selectedFileName\n${formatSize(totalSent)} at ${String.format("%.1f", avgSpeed)} MB/s")
                    showToast("File sent successfully!")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Send error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("❌ Send failed: ${e.message}")
                    showToast("Send failed: ${e.message}")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────

    private fun updateStatus(msg: String) { binding.tvStatus.text = msg }

    private fun updateConnectionUI(connected: Boolean) {
        binding.btnDisconnect.visibility = if (connected) View.VISIBLE else View.GONE
        binding.btnSendFile.isEnabled = connected && selectedFileUri != null
        if (!connected) {
            connectedDeviceInfo = null; isHotspotMode = false; boundNetwork = null
        }
    }

    private fun showProgressUI(show: Boolean, fileName: String, fileSize: Long) {
        binding.cardProgress.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            binding.tvProgressFile.text = fileName
            binding.tvProgressSize.text = formatSize(fileSize)
            binding.progressTransfer.progress = 0
            binding.tvProgressPercent.text = "0%"
            binding.tvProgressSpeed.text = ""
        }
    }

    private fun updateProgress(percent: Int, transferred: Long, total: Long, speedMBps: Double) {
        binding.progressTransfer.progress = percent
        binding.tvProgressPercent.text = "$percent%"
        binding.tvProgressTransferred.text = "${formatSize(transferred)} / ${formatSize(total)}"
        binding.tvProgressSpeed.text = "${String.format("%.1f", speedMBps)} MB/s"
    }

    private fun getFileInfo(uri: Uri): Pair<String, Long> {
        var name = "unknown_file"; var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = cursor.getString(ni) ?: name
                if (si >= 0) size = cursor.getLong(si)
            }
        }
        return Pair(name, size)
    }

    private fun getUniqueFileName(dir: File, name: String): String {
        var result = name; var counter = 1
        while (File(dir, result).exists()) {
            val dot = name.lastIndexOf('.')
            result = if (dot > 0) "${name.substring(0, dot)}($counter)${name.substring(dot)}" else "$name($counter)"
            counter++
        }
        return result
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val i = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceAtMost(3)
        return "${DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, i.toDouble()))} ${units[i]}"
    }

    private fun hasLocationPerm() = ActivityCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
