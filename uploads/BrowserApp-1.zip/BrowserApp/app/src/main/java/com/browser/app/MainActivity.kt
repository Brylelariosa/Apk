package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlBar: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnToggle: ImageButton
    private var urlBarVisible = false

    companion object {
        private const val HOME_URL = "https://www.google.com"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Must be called before super.onCreate and setContentView
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        applyImmersiveMode()
        bindViews()
        configureWebView()
    }

    // ──────────────────────────────────────────────────────────────────────
    // Immersive / system-bar handling
    // ──────────────────────────────────────────────────────────────────────

    private fun applyImmersiveMode() {
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    // ──────────────────────────────────────────────────────────────────────
    // View wiring
    // ──────────────────────────────────────────────────────────────────────

    private fun bindViews() {
        webView    = findViewById(R.id.webView)
        urlBar     = findViewById(R.id.urlBar)
        urlInput   = findViewById(R.id.urlInput)
        btnBack    = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnToggle  = findViewById(R.id.btnToggleUrlBar)

        // Translate the bar off-screen after it has been measured
        urlBar.post {
            val h = if (urlBar.height > 0) urlBar.height else 180
            urlBar.translationY = -h.toFloat()
        }

        btnToggle.setOnClickListener  { toggleUrlBar() }
        btnBack.setOnClickListener    { if (webView.canGoBack())    webView.goBack()    }
        btnForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener { webView.reload() }

        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isGo    = actionId == EditorInfo.IME_ACTION_GO
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                          event.action   == KeyEvent.ACTION_DOWN
            if (isGo || isEnter) {
                navigateTo(urlInput.text.toString())
                true
            } else false
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // WebView configuration
    // ──────────────────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled    = true
            domStorageEnabled    = true
            databaseEnabled      = true
            setSupportZoom(true)
            builtInZoomControls  = true
            displayZoomControls  = false
            userAgentString      = DESKTOP_UA
            loadWithOverviewMode = true
            useWideViewPort      = true
            cacheMode            = WebSettings.LOAD_DEFAULT
            allowFileAccess      = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                urlInput.setText(url ?: "")
                syncNavButtons()
            }
            override fun onPageFinished(view: WebView, url: String?) {
                urlInput.setText(url ?: "")
                syncNavButtons()
            }
            // Return false → WebView handles all http/https URLs internally
            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = false
        }

        webView.webChromeClient = WebChromeClient()
        webView.loadUrl(HOME_URL)
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ──────────────────────────────────────────────────────────────────────
    // Navigation
    // ──────────────────────────────────────────────────────────────────────

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    // ──────────────────────────────────────────────────────────────────────
    // URL bar show / hide
    // ──────────────────────────────────────────────────────────────────────

    private fun toggleUrlBar() {
        if (urlBarVisible) hideUrlBar() else showUrlBar()
    }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        urlBar.visibility = View.VISIBLE
        urlBar.animate()
            .translationY(0f)
            .setDuration(270)
            .start()
        // Request focus after animation frame so the keyboard appears smoothly
        urlInput.post { urlInput.requestFocus() }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(220)
            .withEndAction { urlBar.visibility = View.INVISIBLE }
            .start()
    }

    private fun dismissKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    // ──────────────────────────────────────────────────────────────────────
    // Back-press: URL bar → WebView history → exit
    // ──────────────────────────────────────────────────────────────────────

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible      -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            else               -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }
}
