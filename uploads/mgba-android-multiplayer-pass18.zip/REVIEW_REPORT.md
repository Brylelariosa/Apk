# REVIEW_REPORT — Fifth pass

## Methodology and its limits (read this before the scores below)

This review was done by reading every source file in the project in full
(4,080 lines across `MainActivity.kt`, `LinkMultiplayer.kt`,
`EmulatorEngine.kt`, `mgba_jni.c`, `CMakeLists.txt`, plus all Gradle/manifest
config), cross-checking specific claims with `grep` across the whole tree
(e.g. confirming a permission or field really is unused before removing/
flagging it), and reasoning through concurrency and lifecycle paths by
hand.

What this environment could **not** do, which a real production sign-off
normally would:

- **No compilation.** This sandbox has a JDK but no Android SDK, no NDK, no
  Kotlin compiler, and no network access to fetch any of them or any Gradle
  dependency. Nothing here was verified against `./gradlew assembleDebug`.
  Verification is by careful reading, brace/paren-balance checking, and
  cross-referencing every changed identifier against its declaration —
  not a build log.
- **No device or emulator testing.** Nothing was run on real or virtual
  Android hardware. Claims about behavior (e.g. "this removes a class of
  desync bugs") are based on reading the code's logic, not observing it.
- **No profiling.** CPU/memory/battery statements are based on what the
  code does (allocations, lock scope, thread counts), not measurement.

Given that, the scores below are a qualitative code-review judgment, not a
certified benchmark — treat them accordingly.

## Executive summary

This is a well-built, actively-maintained solo project already several
review passes deep (see `README_SETUP.md`'s pass history). The audio
pipeline, render/audio decoupling, ROM-swap safety, and native JNI layer
were already solid going into this pass — `mgba_jni.c` in particular
correctly mutex-guards every entry point and was left untouched. This
pass's main find was that the multiplayer/link-cable subsystem
(`LinkMultiplayer.kt`) hadn't had a dedicated review yet and had a real,
if narrow, set of thread-safety and reconnect-handling gaps, plus a
cross-cutting inconsistency between the native ROM-swap path and the
Kotlin-side link UI. Two small, low-risk backend features were added.
Two genuinely unused permissions and one dead build setting were removed.

## Scores

| | Score | Basis |
|---|---|---|
| Code quality (this pass's view) | 8/10 | Clear structure, extensive and accurate in-code comments explaining *why* not just *what*, consistent style. Docked for `MainActivity.kt`'s size (2,549 lines, one God Activity) — functional today, but harder to review/extend than a split-out architecture would be. |
| Production readiness | 6.5/10 | The concrete bugs found here are fixed. What keeps this from higher: no automated test coverage exists to catch regressions going forward, no CI-verified build happened as part of *this* pass (see limits above), and the multiplayer protocol has a documented, unresolved architectural characteristic (see Known Limitations) that a real multiplayer-heavy game could expose. |

Both numbers describe the codebase as understood through reading, not as
measured through a build/test pipeline this environment doesn't have.

## Critical issues found (and fixed)

- Missing `@Volatile` on multiplayer connection-state fields read across
  threads — see `CHANGELOG.md` #1.
- ROM swap while linked left native and Kotlin/UI state disagreeing about
  whether multiplayer was still connected — see `CHANGELOG.md` #5.
- A ROM-load completion callback with no post-teardown guard — see
  `CHANGELOG.md` #6.

None of these were crash bugs on their own (the existing native mutex and
Kotlin's reference semantics kept them from segfaulting or throwing) — they're
correctness/consistency bugs: things silently not working, or a resource
leak in a narrow timing window, rather than a hard crash.

## Major improvements made

See `CHANGELOG.md` in full; in summary: cross-thread visibility fixes and a
stale-connection-attempt guard in the link/multiplayer layer, ROM-swap/link
consistency, an auto-backup safety net, an opt-in performance overlay, and
two unused-permission removals.

## Performance

No performance regressions were introduced — every change here is either
in a cold path (connection setup/teardown, ROM load, settings dialogs) or,
for the one hot-path addition (the FPS overlay counter), gated behind a
boolean check so it costs nothing when the feature is off (the default).
The audio-pacing game thread's structure is unchanged. No new performance
work was done this pass beyond what's listed above — the audio/render
pipeline was already the subject of two prior dedicated passes (third and
fourth, per `README_SETUP.md`) and wasn't revisited here except to confirm
`mgba_jni.c`'s locking still holds up.

## Multiplayer report

This was the focus of the pass. Found and fixed: cross-thread visibility,
discovery-socket cleanup, a partial out-of-order-packet guard for Wi-Fi,
and stale-connection-attempt handling for all four connect paths (Wi-Fi
host/client, Bluetooth host/client). Found and *not* fixed, with reasoning,
in `KNOWN_LIMITATIONS.md`: full modular sequence-number ordering, and the
fact that an SIO exchange holds the native core mutex for its full network
round-trip (up to 30–50 ms), which bounds effective frame rate during very
frequent link transfers.

## Security report

Two unused dangerous-adjacent permissions removed (`READ_EXTERNAL_STORAGE`,
`BLUETOOTH_SCAN`) after confirming via grep that neither is referenced
anywhere. `proguard-rules.pro` was checked and already correctly protects
the one method (`jniExchangeData`) that R8 could otherwise silently break
by renaming it out from under a native `GetMethodID` lookup — no gap found
there. No exported components beyond the required launcher `Activity`; no
change needed. JNI input handling in `mgba_jni.c` was reviewed and already
guards its native buffers and mutex correctly.

## Architecture report

Single-activity app; `MainActivity.kt` is a large (2,549-line) class
covering UI, the game loop, rendering, and settings. This is consistent
with the project's history of incremental, working-code-first passes and
wasn't restructured here (splitting it is a real, valid future
recommendation — see below — but is exactly the kind of broad,
hard-to-verify-without-compilation change this pass avoided making).
`LinkMultiplayer.kt` and `EmulatorEngine.kt` are both appropriately scoped
and separated already.

## Memory report

No new allocations were added in any hot path. The auto-backup feature
does one `File.copyTo()` per save/state-slot write (cold path, bounded by
save-file size — typically well under a few MB). The performance overlay
allocates one formatted `String` per second, only when enabled.

## Battery report

Not directly addressed this pass (audio/render efficiency was the subject
of the third and fourth passes). Nothing added here runs continuously on
a hot path except the gated FPS counter, which is off by default.

## Compatibility report

minSdk 24 (Android 7.0) through the current API level; single ABI
(arm64-v8a only, unchanged this pass — reasonable given minSdk 24, since
32-bit-only ARM devices are effectively extinct at that API level, but
worth knowing about — see `KNOWN_LIMITATIONS.md`). Both removed permissions
were checked against actual API-level requirements
(`BLUETOOTH_CONNECT`/`BLUETOOTH_SCAN` are API 31+ concepts; the app's
`minSdkVersion="30"`-gated legacy `BLUETOOTH`/`BLUETOOTH_ADMIN`
permissions were left untouched).

## Future recommendations

- Split `MainActivity.kt` (rendering, game loop, settings UI, and touch
  handling are all reasonably separable) — valuable, but real
  compilation/testing should accompany a change that size, which this
  environment can't provide.
- Full modular sequence-number correlation for the Wi-Fi link protocol
  instead of the simple duplicate-discard added this pass.
- A "restore from .bak" UI action to make the new auto-backup feature
  actionable from within the app, not just from a file manager.
- Pin `gradle-wrapper.properties`'s `distributionSha256Sum` for
  supply-chain integrity — not done this pass since this sandbox has no
  network access to fetch the real checksum, and a guessed one would break
  every build.
