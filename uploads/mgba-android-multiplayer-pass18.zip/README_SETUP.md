# mGBA Android

Built and distributed via GitHub Actions.  
Push this ZIP to your `uploads/` folder in the repo — the workflow handles everything else.

---

## How to build

### Via GitHub Actions (normal workflow)

```
uploads/
└── mgba-android.zip   ← push this file; workflow triggers automatically
```

The workflow:
1. Extracts the ZIP, finds `settings.gradle.kts`
2. Downloads `gradle-wrapper.jar` for Gradle 8.6
3. Installs NDK 25.2.9519653 + CMake 3.22.1
4. Runs `./gradlew assembleDebug`

CMake auto-fetches the mGBA 0.10.3 source from GitHub on the first build
(via `FetchContent_Declare`).  The downloaded source lands in `app/.cxx/`
which the workflow caches, so subsequent builds skip the download entirely.

The APK is uploaded as a workflow artifact (retained 30 days).

### Locally (Android Studio)

1. Clone mGBA alongside the project:
   ```bash
   git clone --depth 1 --branch 0.10.3 https://github.com/mgba-emu/mgba.git mgba-core
   ```
   CMakeLists.txt checks for this folder first and skips the FetchContent download.

2. Open the project in Android Studio (Hedgehog+) and hit Run.

---

## Fixes applied vs the original

| File | Change |
|------|--------|
| `MainActivity.kt` | `catch (e: Throwable)` — was `Exception`, which silently missed `UnsatisfiedLinkError` |
| `MainActivity.kt` | Game loop body wrapped in try/catch; surface-recreate restarts the loop |
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` — required alongside `useLegacyPackaging=true` |
| `mgba_jni.c` | `pthread_mutex_t` guards `g_core`/`g_fb` — eliminates race with `nativeDestroy` |
| `mgba_jni.c` | `core->loadConfig(core)` replaces `mCoreLoadConfig(core)` — opts actually applied now |
| `mgba_jni.c` | Stride-correct pixel copy in `nativeRunFrame` — no more row-shift on padded bitmaps |
| `CMakeLists.txt` | FetchContent fallback auto-downloads mGBA 0.10.3 when no local clone is present |
| `CMakeLists.txt` | `--strip-debug` replaces `--strip-all`; `pthread` added to link targets |
| `app/build.gradle.kts` | Removed `-DM_CORE_GB=ON` (was a no-op; FORCE in CMakeLists always won) |
| `gradle-wrapper.properties` | Gradle 8.6 to match the workflow's hard-coded `GRADLE_VERSION="8.6"` |

### Second pass (this audit)

| File | Change |
|------|--------|
| `AndroidManifest.xml` | `android:extractNativeLibs="true"` is now *actually* declared — the row above claimed this but the attribute was never present in the file; AGP's implicit default happened to match, but the doc/code mismatch was real |
| `MainActivity.kt` | Added `onPause()`/`onResume()` — previously absent entirely, so the emulation thread and `AudioTrack` kept running/playing after the app was backgrounded (battery drain, audio leaking behind other apps) until the `Surface` happened to be destroyed, which isn't prompt or guaranteed |
| `MainActivity.kt` | Added a persistent "📂 Change ROM" button — previously `loadRomBtn` was hidden forever after the first successful load with no other UI path to load a different game; switching titles required force-killing the app |
| `MainActivity.kt` / `LinkMultiplayer.kt` | `BLUETOOTH_CONNECT` is a runtime-dangerous permission on API 31+. It was declared in the manifest but never requested, so tapping "Host — Bluetooth", "Join — Bluetooth", or opening the paired-devices list crashed with an uncaught `SecurityException` on every Android 12+ device. Added `ensureBluetoothPermission()` + a permission launcher that requests it on demand and resumes the action once granted |

**Residual risk from the prior pass — now fixed:** `nativeLoadROM()` used to destroy the previous native core unconditionally *before* attempting to load the new file, so a "Change ROM" attempt on an invalid/corrupt file lost the in-progress session with no fallback. `mgba_jni.c` now builds the new core entirely in local variables (create → init → config → load file → reset → audio setup) and only swaps it into the live globals — destroying the old core — after every step succeeds. Any failure now leaves the current session running untouched.

### Fourth pass — render/audio decoupling (crackle, stutter, and speed wobble)

**Root cause.** Rendering (`lockCanvas`/`drawBitmap`/`unlockCanvasAndPost`) ran on
the *same* thread as `writePcm()`, right after it, every frame. Since the
third pass made the blocking `AudioTrack.write()` call *the frame pacer*
itself, any slow render — a GC pause, a busy compositor, a software-canvas
`SurfaceView` on a budget device — delayed the next audio write too. That's
a buffer underrun heard as a click/pop, and the resulting irregular frame
delivery reads as choppiness or a "speed wobble" even though no individual
sample was actually mispitched. This was identified and explicitly deferred
in the third pass rather than fixed.

**Fix.** `MainActivity.kt` now uses three `Bitmap` buffers instead of one,
ping-ponged so the game thread never writes into a buffer the renderer might
be reading. The renderer moved onto its own `Choreographer.postFrameCallback`
loop — paced by the display's vsync, completely independent of the
audio-locked game thread — so a slow frame draw can no longer stall audio.
`startGameLoop()`/`stopGameLoop()` now start/stop that render loop alongside
the game thread; `stopRenderLoop()` is safe to call from a background thread
(the ROM-reload path does) since it only touches a `@Volatile` flag directly
and defers the actual `Choreographer` call to the main thread.

### Third pass — feature build-out (My Boy!/Pizza Boy/RetroArch-parity roadmap)

**#1 Audio — root-caused and rebuilt, not patched.** The old pipeline paced the
game loop with a fixed `Thread.sleep(1/60s)`, which doesn't match the GBA's real
59.7275 Hz refresh rate, and wrote PCM with `WRITE_NON_BLOCKING` while discarding
the return value — so the ~0.46% surplus this mismatch produced was silently
dropped by AudioTrack every few seconds (a periodic stutter, not the "no sound
at all" the brief assumed — this codebase's audio was never fully silent, just
subtly wrong). Rebuilt as an **audio-locked** loop: PCM is now written with a
genuine blocking `AudioTrack.write()`, and that blocking call *is* the frame
pacer for normal-speed play — no `Thread.sleep()` at all, so no drift can
accumulate. A short fallback sleep (using the *correct* GBA frame period, not
1/60s) only covers frames that produce zero audio. Also added: low-latency
performance mode (API 26+) with a graceful single retry if a device's audio HAL
rejects it, dead-object detection + automatic `AudioTrack` recreation, a
symmetric-channel defensive fix in `mgba_jni.c`'s blip-buffer drain, and a
`flush()` on pause so resuming after a long background period doesn't play a
blip of stale audio. Fast-forward still drops audio outright rather than
pitch-shifting it — a deliberate scope decision (see the in-code comment for
why), not an oversight.

**#2 Control layout editor — new subsystem.** Every on-screen button (D-pad ×4,
A, B, Start, Select, L, R, Fast-Forward) is now individually draggable and
resizable via a corner handle, with a per-button opacity override and lock,
live-previewed over the actual running game and persisted to SharedPreferences
as JSON. Reached from ⚙ Settings → "Edit Button Layout…". Positions are stored
as *fractions* of screen size (not raw pixels) and keyed per orientation, so
the storage format is ready for a future portrait mode even though the
activity is currently locked to landscape. Explicitly out of scope for this
pass (documented in-code rather than silently omitted): per-button rotation/
mirroring, snap-to-guides/alignment grid, and named/duplicatable layout
profiles or true per-game layouts (the latter needs a ROM-identity concept —
hash or path — this codebase doesn't have yet).

### Fifth pass — multiplayer thread-safety, ROM-swap/link-state consistency, unused permissions

This pass focused on `LinkMultiplayer.kt`'s connection-handling internals
(the previous four passes had already covered audio, rendering, ROM-swap
safety, and the control layout editor in depth) plus a couple of
cross-cutting consistency and permission-hygiene issues. `mgba_jni.c` was
read in full against every one of the concerns below and found to already
correctly guard `g_core`/`g_fb` behind a mutex on every entry point
(`nativeRunFrame`, `nativeReadAudioSamples`, `nativeSetKeys`,
`nativeSaveState`/`nativeLoadState`, `nativeDestroy`) — no native changes
were needed this pass.

| File | Change |
|------|--------|
| `LinkMultiplayer.kt` | `dataSocket`/`peerAddr`/`peerDataPort`/`btSocket`/`btIn`/`btOut` are now `@Volatile` |
| `LinkMultiplayer.kt` | `discSocket` now actually tracks the live discovery/broadcast socket and is force-closed on `disconnect()` |
| `LinkMultiplayer.kt` | WIFI `DATA` packets now validate the `seq` byte on receive; an exact-duplicate/stale packet is discarded |
| `LinkMultiplayer.kt` | Added `connectGeneration` token + `btPendingSocket` tracking across all four connect paths (`startWifiHost`, `connectWifi`, `startBluetoothHost`, `connectBluetooth`) and `disconnect()` |
| `MainActivity.kt` | Loading/changing a ROM while linked now calls `stopLink()` first, keeping native SIO state and the Kotlin/UI "Connected" state in agreement |
| `MainActivity.kt` | ROM-load completion callback now checks `isFinishing`/`isDestroyed` before re-initializing audio and starting a new game thread |
| `MainActivity.kt` | Added `backupIfExists()` — a single rolling `.bak` copy made before the battery save is re-mapped or a save-state slot is overwritten |
| `MainActivity.kt` | Added an optional performance overlay (core FPS + `AudioTrack` underrun count), off by default, toggled from ⚙ Settings → Misc |
| `AndroidManifest.xml` | Removed `READ_EXTERNAL_STORAGE` — unused; ROM loading is 100% SAF (`OpenDocument`) |
| `AndroidManifest.xml` | Removed `BLUETOOTH_SCAN` — unused; the app only calls `getBondedDevices()`/RFCOMM connect (needs `BLUETOOTH_CONNECT`), never `startDiscovery()` |
| `gradle.properties` | `android.enableJetifier=false` — no support-lib-namespaced dependency remains to jetify (only `androidx.core`/`androidx.appcompat`, both AndroidX-native) |

**The multiplayer fixes, in plain terms.** All four connection-state fields
above were plain `var`s written on a setup thread (host discovery thread,
client connect thread) and read from `jniExchangeData()` on the native
game-loop thread — a different thread that's frequently already running by
the time a connection completes. Without `@Volatile`, the JMM doesn't
guarantee that thread ever sees the write; worst case, an established link
reads as permanently disconnected. Separately, `showLinkDialog()` never
blocked starting a second connection attempt while a first was still
mid-handshake (it only guards on `isConnected`, not "is connecting"), so a
user backing out and retrying could leave an abandoned attempt's eventual
completion clobbering a newer connection's sockets or firing a callback for
an operation already abandoned — `connectGeneration` closes that gap.
`btPendingSocket` specifically lets `disconnect()` actually cancel a
Bluetooth `connect()` call in progress (which can otherwise block for 10+
seconds) instead of only being able to cancel it after the fact.

**The ROM-swap/link fix, in plain terms.** `mgba_jni.c`'s ROM-swap path
already correctly protects *itself* from a dangling pointer when a new ROM
is loaded mid-link-session (see the second-pass note above) by dropping
`g_link_active`/`g_link_gba` — but it has no way to tell the Kotlin side
this happened, so `link.isConnected` and the "🔗 ✓" button kept claiming
"Connected" after a swap even though the native SIO driver behind it was
gone. `changeRomBtn`/`loadRomBtn` now call `stopLink()` first so both sides
agree.

**Housekeeping note, not a code change:** the very first table above
("Fixes applied vs the original") says pthread was *added* to
`CMakeLists.txt`'s link targets. The current file intentionally omits
`-lpthread` (NDK r18+ folded it into `libc`; explicitly linking it can fail
— see the comment in `CMakeLists.txt`), so that historical row no longer
matches the file as it stands. Left as-is rather than edited, since it was
presumably accurate for whatever pass wrote it; noted here so the
discrepancy doesn't cause confusion later.

See `KNOWN_LIMITATIONS.md` for what was found but deliberately *not*
changed this pass (full out-of-order protection for the Wi-Fi link
protocol, the SIO-exchange/core-mutex interaction, and a couple of
supply-chain follow-ups this sandbox couldn't safely make).

### Sixth pass — SIO protocol correctness (child never answers; status bits never set)

Not summarized here in full — this pass's own `BUGS_FIXED.md`,
`FILE_CHANGES.md`, and `KNOWN_LIMITATIONS.md` sections (each headed "Sixth
pass") are the complete record; this entry is just so the index above
doesn't silently skip a pass. Headline result: a child device never
actually answered the host's link requests (GBATEK: the Start/Busy bit is
read-only for slaves, so a child's own `wifiExchange()`/`btExchange()` was
never being called), and nothing ever set SIOCNT's parent/child or
all-ready status bits, both of which real ROMs check before ever
attempting a transfer. Both fixed. Reported as still not fully working
before this next pass could confirm why — see below.

### Seventh pass — the SIO IRQ was never raised

User report after the sixth pass: still not progressing (tested against
Yu-Gi-Oh! World Championship 2006 and The Legend of Zelda: Four Swords),
plus a sharp diagnostic observation — fast-forward stayed available even
while "Connected" was showing, unlike real hardware/mGBA proper, where an
active link exchange's network round-trip should throttle it.

| File | Change |
|------|--------|
| `mgba_jni.c` | `link_sio_write_register()` (host/parent path) now calls `GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0)` right after finishing a transfer |
| `mgba_jni.c` | `nativeLinkChildExchange()` (child path) now does the same, on its own device's core |

**In plain terms.** FIX 8, back in an earlier pass, already left a note
that this build "doesn't automatically raise the SIO IRQ the way hardware
would... only relevant for a game that waits on that interrupt instead of
polling SIOCNT's Start bit" — flagged as a known gap, not acted on. Games
that wait on the interrupt are not a rare edge case: the standard
GBA-dev idiom taught by every tutorial (Tonc, gbadev) for *any* interrupt
wait, serial included, is BIOS `IntrWait`/`VBlankIntrWait` — enable the bit
in IE, then sleep — specifically because busy-polling wastes battery on
real hardware. A ROM built that way had no bug in the data it received
(the sixth pass's fixes were real and correct); it just never woke back up
to look at it. This also fully explains the fast-forward observation:
an interrupt-driven ROM that already made its one Start-bit write and is
now asleep waiting isn't hitting that write again every frame, so there's
no per-frame blocking network round-trip left to throttle anything —
fast-forward looking normal was itself a symptom, not a separate bug.

This pass confirmed the exact call — `GBARaiseIRQ(gba, GBA_IRQ_SIO, 0)` —
by reading mGBA's actual `src/gba/sio.c` directly rather than guessing from
memory (which is what produced the FIX 7/8 signature mismatches two passes
ago). See the `FIX 10` comment block at the top of `mgba_jni.c` for the
full citation and reasoning, including why it's believed safe for
poll-style ROMs too (they simply never enabled the IE bit that would make
this observable). As with every pass, this could not be compiled or run
against real devices in this environment — see `KNOWN_LIMITATIONS.md`.


### Eighth pass — no fix; added logging, because guessing had stopped working

User re-tested the seventh pass's IRQ fix against both games over both
Wi-Fi and Bluetooth: no change at all. Not "still broken in a new way" —
the exact same symptom (Connected shows, ROM doesn't react, fast-forward
unthrottled) as before that fix. That pattern — a real fix, zero observable
difference — is itself a clue: it's consistent with
`link_sio_write_register()` never being invoked in the first place for
either game, since `GBASIOSetDriver()` only registers this driver for
`SIO_MULTI` mode, and the core swaps its active SIO driver every time the
ROM's own mode bits change. If either ROM's handshake is spending its time
in a different mode, or never gets far enough to reach Multi-Player mode,
nothing from the sixth or seventh pass could ever have been observable —
which fits the data better than "the fix has a subtle bug in it."

Rather than add a fourth speculative protocol theory with no way to check
it from this sandbox, this pass added permanent trace logging instead (see
`mgba_jni.c`'s `FIX 11` comment and `FILE_CHANGES.md`) and is explicitly
waiting on real logcat output before the next pass touches the protocol
logic again. Whether any `"SIO write addr=..."` lines show up under tag
`mGBA-JNI` during a real attempt settles, in one test, a question that
static code reading cannot.

### Ninth pass — found a real, separate bug: Wi-Fi host disconnected on its own

User report this pass distinguished the two transports for the first time:
Wi-Fi connects, then disconnects on its own after a few seconds; Bluetooth
stays connected, but the ROM still doesn't react — the same "Connected but
nothing happens in-game" symptom the eighth pass's logging is waiting on
real logcat to explain.

The Bluetooth half is unchanged and still needs that logcat (see the
eighth pass above — nothing new to add there without it, and this pass
deliberately did not add a fourth protocol theory). But the Wi-Fi half
turned out to be a real, independent, fully-diagnosable-by-reading bug,
found by asking a different question: not "is the SIO protocol correct"
(already checked twice), but "why would Wi-Fi specifically, and not
Bluetooth, drop a connection that both sides agree succeeded?"

| File | Change |
|------|--------|
| `LinkMultiplayer.kt` | New `wifiSocketLock`; `wifiExchange()` now holds it for its send+receive |
| `LinkMultiplayer.kt` | New `drainHostWifiKeepalives()`, called from `startKeepalive()`'s Wi-Fi branch, host role only |

**In plain terms.** The FIX 9 liveness watchdog (sixth pass) only ever
learns the peer is alive when something actually calls
`dataSocket.receive()`. The child role always has that covered —
`startWifiChildResponder()` reads continuously the instant it connects.
The host role didn't: its only other call to `receive()` was buried inside
`wifiExchange()`, which doesn't run until *this device's own ROM* starts
making real SIO transfers. Two ROMs' link-cable menus can easily take
longer than the watchdog's 8-second timeout to navigate to after the
app-level "Connected" already shows — so the host's own keepalive-liveness
check would fire first, on a peer that was never actually gone, and tear
the whole thing down (sending the other phone a BYE in the process, so
both sides drop together — matching what was reported). Bluetooth was
never exposed to this: its reader thread (`startBtReader()`) already runs
for both roles.

Fixed by giving the host role the same kind of always-listening coverage
the child already had, without letting it race a real in-flight SIO
exchange for the same socket — see `wifiSocketLock` and both functions'
own comments in `LinkMultiplayer.kt` for exactly how.

As with every pass, this environment has no Kotlin compiler and no device
to test against (see `KNOWN_LIMITATIONS.md`) — verified by careful reading,
brace/paren balance checking, and tracing every new identifier to its
declaration and use sites, same standard as every prior pass, not by an
actual build or a real link session.
