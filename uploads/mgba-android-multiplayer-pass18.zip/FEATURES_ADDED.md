# FEATURES_ADDED — Seventeenth pass

One feature, prompted by hitting a real limitation of Twelfth pass's
original debug-log tool: it depended on OS logcat access, which turns out
not to work on every phone.

## Durable, logcat-independent link debug logging

**Description:** The "Copy link log" tool (quick game menu) no longer
shells out to `logcat`. `mgba_jni.c`'s `LOGI`/`LOGW`/`LOGE` calls, plus
`LinkMultiplayer.kt`'s own connection-lifecycle log lines, now also write
to a plain private file this app owns outright (`filesDir/
link_debug.log`) — no permission needed, no dependency on OS logcat access
of any kind, on any OEM build. The file resets fresh at the start of every
link connection attempt (`nativeLinkStart()`), so a capture reflects one
attempt rather than accumulating across a whole app session, with an 8MB
backstop cap for the rare session that runs long before anyone reads it.

**User benefit:** The debug-log tool now works the same way on every
phone, including the one where the old logcat-based version returned
nothing at all — confirmed by W's own side-by-side test (real output on
one phone, empty on the other, same build, same tool). This specifically
unblocks getting a synchronized capture from *both* phones during the same
connection attempt, which every pass investigating the multiplayer issue
since the Twelfth has needed and not been able to get.

**Files modified:** `mgba_jni.c` (the actual file-writing logic and the
new `nativeSetLinkLogPath()` entry point), `EmulatorEngine.kt` (JNI
declaration), `MainActivity.kt` (calls it once from `onCreate()`;
`copyLinkDebugLog()` reads the file instead of invoking `logcat`),
`LinkMultiplayer.kt` (mirrors its own 7 log lines into the same file via a
new `linkLog()` helper, so one file has everything the old combined
3-tag logcat filter used to).

---

# FEATURES_ADDED — Fourteenth pass

Three related changes from one request, all in `changeRom()`'s neighborhood:
transparent zip loading, an in-app file-manager-style ROM browser to
replace the raw system picker, and a Screen orientation setting. Requested
against a reference screenshot of another emulator's Video settings and
"Load game" screen — matched the general shape (file-manager layout,
five-way orientation dialog) rather than that app's exact code, which
this project has no access to and wouldn't want to depend on anyway (see
storage-permission note below for why the underlying approach couldn't be
identical even if it were available).

## 1. Transparent zip ROM loading

**Description:** Any ROM entry point (system picker or the new browser
below) now accepts a `.zip` containing a `.gba` directly — no separate
extraction step. Detected by the real zip magic bytes ("PK\x03\x04"), not
the file's name, so a misnamed archive still works and a same-named non-zip
file is correctly rejected rather than handed to the core as garbage. See
`stageRomFile()` in `MainActivity.kt`.

**User benefit:** Most GBA ROM distributions are a `.zip` with one `.gba`
inside it (see the reference screenshot's own "Load game" list — almost
every entry is a `.zip`); previously each one had to be extracted by hand
before this app could open it.

**Files modified:** `MainActivity.kt` (new `stageRomFile()`; `romPicker`'s
callback and the new browser's file-tap both route through it now via the
shared `loadRomFromUri()` — see Feature 2).

## 2. In-app ROM folder browser

**Description:** `changeRom()` now opens a custom "Load game" screen
(`romBrowserOverlay`/`buildRomBrowser()`) instead of launching the system
document picker directly: a path readout, an up button, and a plain
scrollable list of subfolders and `.zip`/`.gba` files, styled to match this
app's existing Settings screen rather than the reference screenshot's
Material dialog chrome specifically. Backed by SAF's `OpenDocumentTree` +
`DocumentFile`, asked for once and persisted (`PREF_ROMS_TREE_URI`) —
**not** raw `java.io.File` against a hardcoded path like
`/storage/emulated/0/Download/Roms`.

**Reason for the SAF-tree approach instead of a literal hardcoded-path
file manager:** this app deliberately removed `READ_EXTERNAL_STORAGE`
already (see `AndroidManifest.xml`) so ROM loading needs no storage
permission at all. A literal file-manager rooted at an absolute path would
need that permission at minimum, and on this app's targetSdk 34 (API 30+
scoped storage) realistically `MANAGE_EXTERNAL_STORAGE` ("All files
access") to reach an arbitrary folder like `Download/Roms` — a real
regression from "asks for nothing but the ROM itself." Whatever the
reference app is doing to show a raw path like that, this app matches the
*look* (folders, path, up button) without taking on that permission.

**User benefit:** Browsing for a ROM now looks and works like a file
manager instead of the bare-bones system document picker (which, on many
devices/launchers, defaults to an unhelpful "Recent" view rather than the
ROMs folder).

**Files modified:** `MainActivity.kt` (new `romTreePicker`,
`openRomBrowserAtRoot()`, `refreshRomBrowserList()`, `romBrowserRow()`,
`romBrowserUp()`, `buildRomBrowser()`; `changeRom()` rewritten;
`romPicker`'s callback slimmed down, its body extracted into the new
shared `loadRomFromUri()`). `build.gradle.kts` (added the
`androidx.documentfile` dependency this needs).

**Note:** the classic system picker isn't removed — it's one tap away as
"Use system file picker instead" at the bottom of the new browser, in case
tree-based browsing ever misbehaves for someone's device or storage
provider.

## 3. Screen orientation setting

**Description:** Video settings gained a five-way "Screen orientation"
choice (Auto rotate / Landscape / Reverse landscape / Portrait / System
default), matching the reference screenshot's dialog. Was previously fixed
to landscape both in code (`requestedOrientation` set once in `onCreate`)
and in the manifest (`android:screenOrientation="landscape"`); both are now
driven by a persisted preference instead (`PREF_ORIENTATION`, applied via
the new `applyScreenOrientationPref()`), defaulting to landscape so
existing installs behave identically until this is actually changed.

**Files modified:** `MainActivity.kt` (new `applyScreenOrientationPref()`;
`showVideoSettings()` gained the radio group and its Save handling;
`onCreate()`'s hardcoded orientation line replaced). `AndroidManifest.xml`
(`android:screenOrientation` changed from `"landscape"` to `"unspecified"`
— the existing `android:configChanges` entry already keeps the activity,
and the running core, alive across the resulting orientation change
without a restart, exactly as it did for the old hardcoded value).

---

# FEATURES_ADDED — Thirteenth pass

## 1. Save-state thumbnails

**Description:** Save/Load slot picker now shows a small screenshot of
what's actually in each slot instead of just a timestamp. Captured via the
same `PixelCopy`-against-the-`SurfaceView` technique as the existing
Screenshot feature (no new native/JNI code), written as a PNG sitting
next to the state file itself (`<rom>.state<N>.png`), and displayed via a
custom `ListView` row (`ImageView` + `TextView`) in place of the old
plain-text `setItems()` list.

**User benefit:** Makes the 4 save-state slots recognizable at a glance —
particularly useful before overwriting one, since the save dialog now
shows what's *currently* in a slot rather than just when it was last
written.

**Files modified:** `MainActivity.kt` (`showSaveStateSlotDialog()`
rewritten to use a custom adapter; new `captureStateThumbnail()`,
`stateSlotRow()`, `stateThumbFile()`).

**Reason for implementation:** Directly requested ("add pictures on save
state").

**Note:** A slot saved before this pass has a state file but no `.png`
yet — shown with a plain placeholder box until it's next saved over,
same as a genuinely empty slot's label already distinguishes via text
("Empty" vs. a timestamp). Both cases were handled without needing a
migration step: `stateThumbFile()` simply may or may not exist yet.

---

# FEATURES_ADDED — Tenth pass

All three features below come from the reference screenshot's menu
(`Link remote`/`Link local` were already elsewhere in the app — see
`BUGS_FIXED.md`/`FILE_CHANGES.md` — these three are the genuinely new
ones).

## 1. Screenshot

**Description:** New row in the quick game menu. Captures exactly what's
currently on screen via `PixelCopy` against the `SurfaceView` and saves it
as a PNG under `getExternalFilesDir(null)/Screenshots/`, named after the
current ROM and a timestamp.

**User benefit:** No screenshot capability existed before at all.

**Files modified:** `MainActivity.kt` (`takeScreenshot()`,
`saveScreenshotBitmap()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Screenshot` row.


## 2. Reset

**Description:** New row in the quick game menu. Power-cycles the running
game: reloads the last-loaded ROM (still cached on disk — see
`FILE_CHANGES.md`) against the same battery-save path, exactly like a
fresh load.

**User benefit:** No in-game reset existed before — previously the only
way to restart a game was backgrounding and relaunching the whole app.

**Files modified:** `MainActivity.kt` (`resetGame()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Reset` row. Deliberately implemented by reusing `nativeLoadROM()`
rather than adding a new native `core->reset()` export — see
`FILE_CHANGES.md` for why.


## 3. Close

**Description:** New row in the quick game menu. Stops the current game
(loop, audio) and returns to the "▶ Load ROM" idle state — the same button
shown before anything's ever been loaded.

**User benefit:** No way to cleanly stop a running game and get back to a
"nothing loaded" state existed before, short of leaving the app entirely.

**Files modified:** `MainActivity.kt` (`closeGame()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Close` row.


# FEATURES_ADDED — Fifth pass

Both features below are backend-only or off-by-default additions — neither
changes the existing UI's look, layout, or default behavior.

## 1. Auto save backup

**Description:** Before the battery save file is re-opened/mapped by a new
ROM load, or a save-state slot is overwritten, the existing file (if any)
is copied to a sibling `<name>.bak` file. Best-effort and silent — a
backup failure is logged but never blocks or interrupts the actual save.

**User benefit:** A single level of rollback if a save turns out to be
corrupted (app killed mid-write, storage fills up mid-save, or anything
else goes wrong during the write itself). Previously there was no recovery
path at all — the previous save's on-disk content was already truncated
before the new write completed.

**Files modified:** `MainActivity.kt` (`backupIfExists()`, and its two call
sites in the ROM-load path and the save-state-slot dialog).

**Reason for implementation:** Directly requested ("Auto save backups") in
the review brief, and implementable as pure, low-risk file management with
no native code or UI changes.

## 2. Optional performance overlay

**Description:** A small corner readout showing emulated core FPS
(counting every emulated GBA frame, including fast-forward sub-frames) and
the existing `AudioTrack.getUnderrunCount()` figure. Off by default;
toggled via a checkbox in ⚙ Settings → Misc, alongside the existing
fast-forward-speed setting; included in "Reset settings to defaults".

**User benefit:** At-a-glance answer to "is this actually keeping up right
now?" — useful when troubleshooting a specific device or ROM — without
needing to attach `adb logcat`.

**Files modified:** `MainActivity.kt` (state fields, a gated counter in the
game loop, a draw function following the exact style of the existing
link-status/fast-forward overlays, and the Misc-settings checkbox).

**Reason for implementation:** Directly requested ("Performance monitor",
"FPS counter") in the review brief. Implemented so it costs nothing when
disabled — the counting code inside the game loop (the same thread that
paces audio) is skipped entirely unless the toggle is on.
