# mGBA Android — ProGuard / R8 rules
#
# Keep all JNI-called classes and their native method declarations so R8
# does not rename or strip them.  The native side resolves methods by
# their mangled Java names at runtime; any rename → UnsatisfiedLinkError.

-keep class com.mgba.android.EmulatorEngine {
    native <methods>;
    public static final int KEY_*;
}

# jniExchangeData is looked up by literal name/signature from native code
# via GetMethodID(env, cls, "jniExchangeData", "(I)I") in mgba_jni.c
# (Java_..._nativeLinkStart) — R8 can't see that reflective call, so without
# this rule it would rename/strip the method and silently break link-cable
# multiplayer (GetMethodID returns NULL, logged as "not found", nativeLinkStart
# returns false) the first time someone starts a link session post-shrink.
-keepclassmembers class com.mgba.android.LinkMultiplayer {
    int jniExchangeData(int);
}

# Keep MainActivity so the OS can instantiate it via the manifest class name.
-keep class com.mgba.android.MainActivity { *; }

# Preserve line numbers in stack traces for production crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
