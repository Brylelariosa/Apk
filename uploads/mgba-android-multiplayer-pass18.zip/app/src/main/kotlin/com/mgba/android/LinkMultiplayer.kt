package com.mgba.android

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.text.SimpleDateFormat
import java.util.Locale
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * GBA Link Cable multiplayer over Wi-Fi (UDP) or Bluetooth (RFCOMM).
 *
 * Wi-Fi protocol — two UDP sockets:
 *   Port 55798  broadcast discovery  (host announces itself every 300 ms)
 *   Port 55799  SIO data exchange    (used only by the game loop thread)
 *
 * Packet layout (8 bytes):
 *   [0..1] magic  "GK"
 *   [2]    type   0=HANDSHAKE 1=DATA 2=KEEPALIVE 3=BYE
 *   [3]    seq    (uint8, wrapping — for out-of-order discard)
 *   [4..7] data   (uint32 LE — GBA SIO payload)
 *
 * jniExchangeData() is the hot path: called by the C SIO driver every time
 * the GBA game initiates a serial transfer.  It sends our data and blocks
 * until the peer replies (≤ 30 ms on local Wi-Fi, ≤ 50 ms on Bluetooth).
 * A timeout returns -1 which the driver maps to 0xFFFF (disconnected peer).
 *
 * ── BT FIX ──────────────────────────────────────────────────────────────────
 * Android's BluetoothSocket InputStream.available() always returns 0 on many
 * phones regardless of data availability. The old poll loop therefore timed
 * out on every exchange, making BT link cable completely non-functional.
 * Fix: a dedicated btReaderThread does true blocking reads and pushes 5-byte
 * frames into btReceiveQueue. btExchange() polls the queue with a deadline.
 *
 * ── Wi-Fi FIX ───────────────────────────────────────────────────────────────
 * Three root causes of Wi-Fi connection failures:
 * 1. Missing CHANGE_WIFI_MULTICAST_STATE permission (fixed in manifest).
 * 2. Sockets not setting SO_REUSEADDR — port 55799 stays in TIME_WAIT after
 *    app restart causing "address already in use" on the host side.
 * 3. Client used repeat(5) with a 3-second timeout per attempt. Host only
 *    opened a 100 ms receive window per 500 ms broadcast cycle — the two
 *    windows almost never overlapped. Fix: host uses 200 ms window per
 *    300 ms cycle; client retries every 300 ms over 15 s total.
 *
 * ── FIX 9 ────────────────────────────────────────────────────────────────────
 * Two bugs that together explain "app says Connected, but the ROM's own
 * link/multiplayer menu just sits waiting forever" — and separately, why a
 * peer disconnecting was never noticed by the other side:
 *
 * 1. isConnected here has only ever meant "the two phones' own discovery/
 *    handshake protocol succeeded" — a check-in at the transport level, with
 *    zero connection to whether the GBA-side SIO link is doing anything. The
 *    actual reason the ROM never sees a partner: a real GBA child unit never
 *    triggers its own SIO transfer (confirmed on GBATEK — the Start/Busy bit
 *    is "Read Only for Slaves"), so this app's non-host device never called
 *    wifiExchange()/btExchange() on its own — meaning the host's every
 *    request timed out waiting for a reply nothing was ever going to send,
 *    every single time, regardless of network conditions. Fixed with a
 *    dedicated passive responder for the child role — see
 *    startWifiChildResponder() below and the child-mode branch inside
 *    startBtReader() — which answers the host's requests the instant they
 *    arrive over the network instead of waiting on a local SIO write that
 *    was never coming. The native-side half of this fix is
 *    nativeLinkChildExchange() in mgba_jni.c.
 *
 * 2. Nothing ever detected a peer disappearing. isConnected only ever went
 *    back to false via an explicit local disconnect() call — a dead socket,
 *    a killed peer app, or Bluetooth going out of range all left this side
 *    convinced it was still "Connected" indefinitely. Fixed with: a BYE
 *    packet sent best-effort on disconnect() so the peer notices instantly
 *    in the common case, plus a liveness watchdog (lastPeerActivityMs,
 *    checked inside the existing keepalive loop) as a fallback for the
 *    uncommon case — a crash, a force-close, going out of Bluetooth range —
 *    where no BYE ever arrives.
 *
 * ── FIX 12 ───────────────────────────────────────────────────────────────────
 * FIX 9's liveness watchdog (point 2 above) had its own gap, Wi-Fi-only and
 * host-only: lastPeerActivityMs is only ever refreshed by something that
 * actually calls dataSocket.receive(). The child role always has that
 * covered (startWifiChildResponder() reads continuously from the moment it
 * connects), but the host role previously only ever called receive() inside
 * wifiExchange() — which doesn't run until this device's own ROM starts
 * making real SIO transfers. Until then, the client's keepalives just sat
 * unread, lastPeerActivityMs never advanced past connect time, and the
 * watchdog would deterministically call handlePeerLost() ~8s later — a
 * connection that looked "Connected" then dropped on its own within a few
 * seconds, before either ROM had a real chance to link. Fixed with
 * drainHostWifiKeepalives(), called from the host branch of the existing
 * keepalive loop, sharing wifiSocketLock with wifiExchange() (tryLock, so a
 * real in-flight exchange — itself proof of life — is never starved of the
 * reply it's waiting for). See both functions' own comments.
 *
 * ── FIX 15 ───────────────────────────────────────────────────────────────────
 * User re-tested FIX 9/12 (Wi-Fi's BYE + watchdog): a peer disconnecting is
 * still not being noticed by the other phone. Nothing here was disproven,
 * but nothing could be confirmed either — every disconnect path (this
 * class's disconnect(), and every handlePeerLost() call site) previously
 * logged either nothing at all (the BYE send in disconnect() had a bare
 * `catch (_: Exception) {}`, silent on success, skip, and failure alike) or
 * the exact same generic line regardless of which of the 6 listeners fired
 * or why, so a captured log couldn't distinguish "peer's BYE never arrived"
 * from "it arrived but something else ate it" from "nobody's even sent one
 * yet, still waiting on the 8s watchdog." See mgba_jni.c's own FIX 13 for
 * the other half of why evidence gathered about this so far has been
 * uninformative — the two are unrelated bugs but the same underlying
 * problem: nothing has been logged with enough detail to tell these cases
 * apart. Fix here is purely additive — every disconnect() BYE attempt and
 * every handlePeerLost() call now logs specifically what happened and
 * where — no protocol or timing logic changed. See handlePeerLost()'s own
 * comment.
 */
class LinkMultiplayer(private val context: Context) {

    // ── Constants ─────────────────────────────────────────────────────────

    companion object {
        private const val TAG              = "mGBA-Link"
        private const val DISC_PORT        = 55798            // discovery broadcast
        private const val DATA_PORT        = 55799            // SIO data exchange
        private const val MAGIC_G          = 'G'.code.toByte()
        private const val MAGIC_K          = 'K'.code.toByte()
        private const val TYPE_HANDSHAKE   = 0.toByte()
        private const val TYPE_DATA        = 1.toByte()
        private const val TYPE_KEEPALIVE   = 2.toByte()
        private const val TYPE_BYE         = 3.toByte()
        private const val PKT              = 8
        private const val WIFI_XCHG_MS     = 30L
        private const val BT_XCHG_MS       = 50L
        private val BT_UUID                = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val DISC_INTERVAL_MS = 300L             // host broadcast interval
        private const val HOST_RCV_MS      = 200              // host receive window per cycle
        private const val CLIENT_RETRY_MS  = 300              // client handshake retry period
        private const val HANDSHAKE_TIMEOUT = 15_000L
        // FIX 9: if we haven't heard *anything* from the peer (data, keepalive,
        // or otherwise) for this long, treat it as gone. Must comfortably
        // exceed the 2 s keepalive period so a couple of dropped packets on a
        // flaky Wi-Fi/Bluetooth link don't cause a false "disconnected".
        private const val PEER_TIMEOUT_MS  = 8_000L
    }

    // FIX 17: mirrors every LinkMultiplayer log line into the same private
    // file mgba_jni.c's LOGI/LOGW/LOGE now write to (see EmulatorEngine.
    // nativeSetLinkLogPath, called once from MainActivity.onCreate), in
    // addition to the normal Log.i/Log.w/Log.e call — so a single "Copy
    // link log" read captures the C-side SIO trace and this class's own
    // connection-lifecycle events together, exactly like the old combined
    // logcat tag filter ("mGBA-JNI:* mGBA-Link:* mGBA:*") used to, but
    // without needing OS logcat access at all. Format intentionally
    // mirrors logcat's own "-v threadtime" layout (MM-DD HH:MM:SS.mmm
    // LEVEL TAG: message), matching every native-side line and every
    // existing log excerpt already in this project's history, so a
    // captured file reads the same way throughout — no new format to
    // learn. Best-effort only: a failure here never affects the actual
    // link session, and is silently swallowed rather than logged (logging
    // the failure of logging risks the same problem recursing).
    private fun linkLog(level: Char, msg: String, t: Throwable? = null) {
        when (level) {
            'W' -> if (t != null) Log.w(TAG, msg, t) else Log.w(TAG, msg)
            'E' -> if (t != null) Log.e(TAG, msg, t) else Log.e(TAG, msg)
            else -> Log.i(TAG, msg)
        }
        try {
            val ts = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(java.util.Date())
            val detail = if (t != null) " (${t.javaClass.simpleName}: ${t.message})" else ""
            File(context.filesDir, "link_debug.log").appendText("$ts $level $TAG: $msg$detail\n")
        } catch (_: Exception) {
            // Best-effort only — see comment above.
        }
    }

    // ── State ─────────────────────────────────────────────────────────────

    enum class Mode { NONE, WIFI, BLUETOOTH }

    @Volatile var isConnected  = false
    @Volatile var isHost       = false
    @Volatile var mode         = Mode.NONE

    // Wi-Fi
    // FIX: these were plain `var`, written on a setup/background thread
    // (host discovery thread, client connect thread) and read from
    // jniExchangeData() on the *native game-loop thread* — a different
    // thread that may already be running (and already looping) by the time
    // a connection completes. Without @Volatile the JMM does not guarantee
    // that thread ever observes the write; worst case it keeps reading a
    // stale null and treats an established link as disconnected forever.
    // isConnected/mode were already @Volatile — these were the actual gap.
    @Volatile private var discSocket:  DatagramSocket? = null
    @Volatile private var dataSocket:  DatagramSocket? = null
    @Volatile private var peerAddr:    InetAddress?    = null
    @Volatile private var peerDataPort = DATA_PORT
    @Volatile private var txSeq = 0
    // FIX: last WIFI DATA seq byte actually accepted by wifiExchange() — see
    // the out-of-order/stale-packet guard added there. The packet-layout
    // doc above always described this seq byte as being "for out-of-order
    // discard"; it was populated on send but never checked on receive.
    @Volatile private var lastRxSeq = -1

    // FIX 12: guards every dataSocket.receive() call made on the WI-FI HOST
    // role specifically — wifiExchange() (the real per-round SIO exchange,
    // called synchronously from the game thread) and
    // drainHostWifiKeepalives() (opportunistic liveness draining from the
    // keepalive thread — see its own comment and startKeepalive()'s WIFI
    // branch for why it's needed) both call receive() on the same socket
    // from different threads. Without this they'd race: whichever thread's
    // receive() happened to be the one the OS handed an arriving packet to
    // would "steal" it from the other — most dangerously, a real DATA reply
    // meant for an in-flight wifiExchange() round getting silently consumed
    // by the drain instead, making a working exchange look like a timeout.
    private val wifiSocketLock = ReentrantLock()

    // Bluetooth
    @Volatile private var btSocket:       BluetoothSocket?       = null
    @Volatile private var btServer:       BluetoothServerSocket?  = null
    @Volatile private var btIn:           InputStream?            = null
    @Volatile private var btOut:          OutputStream?           = null
    // FIX: the socket a connectBluetooth() attempt is currently blocked
    // inside .connect() on. Tracked separately from btSocket (which is only
    // set *after* connect() succeeds) purely so disconnect() — or a newer
    // connection attempt — can close it to force the blocking connect()
    // call to abort immediately instead of running for its full OS-level
    // timeout (can be 10+ seconds on some stacks).
    @Volatile private var btPendingSocket: BluetoothSocket? = null
    // FIX: dedicated reader thread + blocking queue replaces inp.available() polling
    private val btReceiveQueue  = LinkedBlockingQueue<ByteArray>()
    private var btReaderThread: Thread? = null

    // Background threads
    private var discThread:      Thread? = null
    private var keepAliveThread: Thread? = null
    // FIX 9: dedicated passive-responder thread for the Wi-Fi *child* role
    // only — see the FIX 9 file-header comment and this thread's own comment
    // near startWifiChildResponder() below. The host role needs no
    // equivalent: it already answers/receives synchronously inside
    // wifiExchange(), which is the correct, protocol-matching place for the
    // parent side.
    private var wifiChildThread: Thread? = null

    // FIX 9: liveness tracking, shared by both transports and both roles.
    // Updated on *any* validly-tagged packet/frame from the peer (data,
    // keepalive, etc.) — see wifiExchange(), startWifiChildResponder(), and
    // startBtReader(). Checked inside the keepalive loop.
    @Volatile private var lastPeerActivityMs = 0L
    @Volatile private var peerLostNotified   = false

    /** FIX 9: fires when the *peer* disappears (timeout or an explicit BYE)
     *  — as opposed to this device's own user-initiated disconnect(). Set
     *  once by MainActivity so it can toast the event the same way a local
     *  disconnect does. Always invoked on the main thread. */
    var onPeerLost: (() -> Unit)? = null

    // FIX: bumped by every start*/connect* call and by disconnect(). Each
    // background attempt captures the value at the start and re-checks it
    // right before touching shared state or firing a callback; if it no
    // longer matches, a newer attempt (or a disconnect) has superseded this
    // one, so the stale result is dropped instead of clobbering the newer
    // connection's sockets or surfacing a callback for an operation the
    // user already backed out of. Reachable in practice: showLinkRemoteDialog()/
    // showLinkLocalDialog() only block re-opening the dialog once isConnected
    // is true — nothing previously stopped starting a second attempt while
    // the first was still mid-handshake.
    @Volatile private var connectGeneration = 0

    // ── Wi-Fi: Host ───────────────────────────────────────────────────────

    fun startWifiHost(
        onReady:     (myIp: String) -> Unit,
        onConnected: () -> Unit,
        onError:     (String)  -> Unit
    ) {
        isHost = true
        mode   = Mode.WIFI
        // FIX: see connectGeneration's field comment — lets this attempt
        // recognise if disconnect()/a newer attempt supersedes it.
        val myGen = ++connectGeneration

        try {
            // FIX: SO_REUSEADDR prevents "address already in use" on app restart
            val dataSock = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(DATA_PORT))
            }
            dataSocket = dataSock

            val myIp = localIp()
            Handler(Looper.getMainLooper()).post { onReady(myIp) }

            discThread = Thread {
                try {
                    // FIX: broadcast = true + reuseAddress on discovery socket
                    val bcast = DatagramSocket(null).apply {
                        reuseAddress = true
                        broadcast    = true
                        bind(InetSocketAddress(DISC_PORT))
                    }
                    // FIX: publish the live socket so disconnect() can force-
                    // close it (previously this class had a `discSocket`
                    // field that nothing ever assigned, so disconnect()'s
                    // cleanup call on it was a silent no-op and a pending
                    // receive() could only ever time out on its own).
                    discSocket = bcast
                    val ann      = "MGBA_HOST $myIp".toByteArray()
                    val bcastDst = InetAddress.getByName(subnetBroadcast())
                    val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT

                    dataSock.soTimeout = HOST_RCV_MS   // 200 ms receive window per cycle

                    while (!Thread.currentThread().isInterrupted && !isConnected
                        && myGen == connectGeneration
                        && System.currentTimeMillis() < deadline) {

                        // Broadcast host announcement
                        try {
                            bcast.send(DatagramPacket(ann, ann.size, bcastDst, DISC_PORT))
                        } catch (_: Exception) { }

                        // Check for client handshake
                        val buf = ByteArray(PKT)
                        val pkt = DatagramPacket(buf, PKT)
                        try {
                            dataSock.receive(pkt)
                            if (isHandshake(buf) && myGen == connectGeneration) {
                                peerAddr     = pkt.address
                                peerDataPort = pkt.port
                                sendPkt(dataSock, TYPE_HANDSHAKE, 0, 0L, pkt.address, pkt.port)
                                isConnected = true
                                startKeepalive()
                                Handler(Looper.getMainLooper()).post { onConnected() }
                            }
                        } catch (_: SocketTimeoutException) {
                            // No client yet — loop back and broadcast again after brief pause
                            val remaining = (DISC_INTERVAL_MS - HOST_RCV_MS).coerceAtLeast(50L)
                            Thread.sleep(remaining)
                        }
                    }
                    bcast.close()
                    if (discSocket === bcast) discSocket = null
                    if (!isConnected && myGen == connectGeneration)
                        Handler(Looper.getMainLooper()).post { onError("No client connected within 15 s") }
                } catch (e: Exception) {
                    if (myGen == connectGeneration)
                        Handler(Looper.getMainLooper()).post { onError(e.message ?: "Host thread error") }
                }
            }.also { it.name = "link-host-disc"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Wi-Fi: discover hosts ─────────────────────────────────────────────

    fun discoverWifiHosts(
        onFound: (List<String>) -> Unit,
        onError: (String) -> Unit
    ) {
        val found = mutableListOf<String>()
        discThread = Thread {
            try {
                // FIX: broadcast = true so the socket can receive broadcast packets
                val sock = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast    = true
                    bind(InetSocketAddress(DISC_PORT))
                    soTimeout    = 4000
                }
                // FIX: publish the live socket — same reasoning as
                // startWifiHost's bcast — so disconnect() or navigating
                // away mid-scan can force-close it immediately.
                discSocket = sock
                val buf = ByteArray(64)
                val pkt = DatagramPacket(buf, 64)
                val deadline = System.currentTimeMillis() + 4000L
                while (System.currentTimeMillis() < deadline) {
                    try {
                        sock.receive(pkt)
                        val msg = String(buf, 0, pkt.length)
                        if (msg.startsWith("MGBA_HOST ")) {
                            val ip = msg.removePrefix("MGBA_HOST ").trim()
                            if (ip !in found) found += ip
                        }
                    } catch (_: SocketTimeoutException) { break }
                }
                sock.close()
                if (discSocket === sock) discSocket = null
                Handler(Looper.getMainLooper()).post { onFound(found) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onError(e.message ?: "Scan error") }
            }
        }.also { it.name = "link-disc"; it.isDaemon = true; it.start() }
    }

    // ── Wi-Fi: Client ─────────────────────────────────────────────────────

    fun connectWifi(
        hostIp:      String,
        onConnected: () -> Unit,
        onError:     (String) -> Unit
    ) {
        isHost = false
        mode   = Mode.WIFI
        val myGen = ++connectGeneration   // FIX: see connectGeneration's field comment
        try {
            // FIX: reuseAddress + shorter per-attempt timeout with continuous retry
            val sock = DatagramSocket(null).apply { reuseAddress = true }
            sock.soTimeout = CLIENT_RETRY_MS.toInt()   // 300 ms timeout per attempt
            dataSocket   = sock
            val host     = InetAddress.getByName(hostIp)
            peerAddr     = host
            peerDataPort = DATA_PORT

            Thread {
                try {
                    val buf      = ByteArray(PKT)
                    val pkt      = DatagramPacket(buf, PKT)
                    val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT

                    // FIX: retry every CLIENT_RETRY_MS instead of waiting 3 s between attempts.
                    // This ensures we hit the host's 200 ms receive window reliably.
                    while (System.currentTimeMillis() < deadline
                        && myGen == connectGeneration
                        && !Thread.currentThread().isInterrupted) {
                        sendPkt(sock, TYPE_HANDSHAKE, 0, 0L, host, DATA_PORT)
                        try {
                            sock.receive(pkt)
                            if (isHandshake(buf) && myGen == connectGeneration) {
                                isConnected = true
                                startKeepalive()
                                // FIX 9: this device is the child/non-host side — see the
                                // FIX 9 file-header comment for why it must actively answer
                                // the host's requests here rather than ever expecting its
                                // own jniExchangeData()/wifiExchange() to be called.
                                startWifiChildResponder()
                                Handler(Looper.getMainLooper()).post { onConnected() }
                                return@Thread
                            }
                        } catch (_: SocketTimeoutException) { }   // retry immediately
                    }
                    if (myGen == connectGeneration)
                        Handler(Looper.getMainLooper()).post { onError("Host not responding (15 s)") }
                } catch (e: Exception) {
                    if (myGen != connectGeneration) return@Thread
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "Connect error") }
                }
            }.also { it.name = "link-client"; it.isDaemon = true; it.start() }

        } catch (e: Exception) {
            onError(e.message ?: "Socket error")
        }
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────

    fun getBluetoothAdapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun getBondedDevices(): List<BluetoothDevice> =
        getBluetoothAdapter()?.bondedDevices?.toList() ?: emptyList()

    fun startBluetoothHost(onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = true
        mode   = Mode.BLUETOOTH
        val myGen = ++connectGeneration   // FIX: see connectGeneration's field comment
        Thread {
            try {
                val adapter = getBluetoothAdapter() ?: throw IOException("No BT adapter")
                val server  = adapter.listenUsingInsecureRfcommWithServiceRecord("mGBA-Link", BT_UUID)
                btServer = server
                val sock   = server.accept(HANDSHAKE_TIMEOUT.toInt())
                server.close()
                if (myGen != connectGeneration) { sock.close(); return@Thread }
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                startBtReader()     // FIX: start the dedicated reader thread
                // FIX 9: previously never called for Bluetooth at all (only
                // the two Wi-Fi paths called it) — meaning a BT session had
                // no keepalive traffic *and*, more importantly, none of the
                // liveness-watchdog staleness checking that now lives in
                // this same loop, so a dead BT peer was never detected.
                startKeepalive()
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                if (myGen == connectGeneration)
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT host error") }
            }
        }.also { it.name = "link-bt-host"; it.isDaemon = true; it.start() }
    }

    fun connectBluetooth(device: BluetoothDevice, onConnected: () -> Unit, onError: (String) -> Unit) {
        isHost = false
        mode   = Mode.BLUETOOTH
        val myGen = ++connectGeneration   // FIX: see connectGeneration's field comment
        Thread {
            try {
                val sock = device.createInsecureRfcommSocketToServiceRecord(BT_UUID)
                // FIX: published *before* the blocking connect() call (which
                // can legitimately run for 10+ seconds) rather than only
                // after it succeeds, so disconnect() has something to close
                // to actually cancel an in-progress attempt instead of
                // leaving it to run out its own OS-level timeout.
                btPendingSocket = sock
                sock.connect()
                btPendingSocket = null
                if (myGen != connectGeneration) { sock.close(); return@Thread }
                btSocket = sock
                btIn     = sock.inputStream
                btOut    = sock.outputStream
                isConnected = true
                startBtReader()     // FIX: start the dedicated reader thread
                startKeepalive()    // FIX 9: see the matching comment in startBluetoothHost()
                Handler(Looper.getMainLooper()).post { onConnected() }
            } catch (e: Exception) {
                btPendingSocket = null
                if (myGen == connectGeneration)
                    Handler(Looper.getMainLooper()).post { onError(e.message ?: "BT connect error") }
            }
        }.also { it.name = "link-bt-client"; it.isDaemon = true; it.start() }
    }

    /**
     * FIX — BT reader thread.
     *
     * Android's BluetoothSocket InputStream.available() is broken on most phones
     * (always returns 0), so the old poll loop in btExchange() timed out on every
     * single exchange, making the link cable completely non-functional in-game.
     *
     * This thread does a true blocking read (how the stream is meant to be used)
     * and places complete 5-byte frames into btReceiveQueue. btExchange() then
     * just calls Queue.poll(timeout) — reliable and not CPU-spinning.
     */
    private fun startBtReader() {
        btReceiveQueue.clear()
        btReaderThread = Thread {
            try {
                val buf = ByteArray(5)
                while (!Thread.currentThread().isInterrupted) {
                    var n = 0
                    while (n < 5) {
                        val r = (btIn ?: return@Thread).read(buf, n, 5 - n)
                        if (r < 0) return@Thread    // stream closed
                        n += r
                    }
                    // FIX 9: any complete frame — of any type — is proof the
                    // peer is still alive. See the keepalive loop's staleness
                    // check.
                    lastPeerActivityMs = System.currentTimeMillis()
                    val frame = buf.copyOf()
                    if (isHost) {
                        // Host role: unchanged — queue it for btExchange(),
                        // called synchronously from the game thread whenever
                        // *this* device's own ROM triggers a transfer (the
                        // correct, protocol-matching trigger for the parent).
                        btReceiveQueue.put(frame)
                    } else {
                        // FIX 9: passive child responder. A GBA child never
                        // triggers its own transfer (GBATEK: Start/Busy is
                        // "Read Only for Slaves"), so btExchange() is never
                        // reached on this device — this is what answers the
                        // host instead, the moment its request arrives. See
                        // startWifiChildResponder()'s comment for the full
                        // picture; this is the same idea over Bluetooth,
                        // reusing the reader thread this class already has.
                        when (frame[0]) {
                            TYPE_BYE -> { handlePeerLost("BYE received (Bluetooth reader)"); return@Thread }
                            TYPE_DATA -> {
                                val hostData = ByteBuffer.wrap(frame, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
                                val childData = EmulatorEngine.nativeLinkChildExchange(hostData)
                                val reply = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                                    .put(TYPE_DATA).putInt(childData).array()
                                try { btOut?.let { it.write(reply); it.flush() } } catch (_: Exception) { return@Thread }
                            }
                            else -> { /* KEEPALIVE — liveness timestamp already refreshed above */ }
                        }
                    }
                }
            } catch (_: Exception) { /* socket closed or interrupted — exit cleanly */ }
            finally {
                // FIX 9: only reaches here with isConnected still true if the
                // connection genuinely died (our own disconnect() already
                // sets it false before closing btSocket, so a self-initiated
                // teardown falls through here harmlessly).
                if (isConnected && mode == Mode.BLUETOOTH) handlePeerLost("Bluetooth reader thread exited (socket closed or read error)")
            }
        }.also { it.name = "link-bt-reader"; it.isDaemon = true; it.start() }
    }

    // ── jniExchangeData — HOT PATH, called from C on the game loop thread ─

    @Suppress("unused") // called from JNI via g_link_xchg_mid
    fun jniExchangeData(localData: Int): Int {
        return when (mode) {
            Mode.WIFI      -> wifiExchange(localData)
            Mode.BLUETOOTH -> btExchange(localData)
            Mode.NONE      -> -1
        }
    }

    private fun wifiExchange(localData: Int): Int {
        val sock = dataSocket ?: return -1
        val peer = peerAddr   ?: return -1
        val seq  = (txSeq++ and 0xFF).toByte()
        // FIX 12: see wifiSocketLock's field comment — this must never run
        // concurrently with drainHostWifiKeepalives()'s receive() on the
        // same socket.
        wifiSocketLock.lock()
        try {
            sendPkt(sock, TYPE_DATA, seq.toInt(), localData.toLong(), peer, peerDataPort)
            sock.soTimeout = WIFI_XCHG_MS.toInt()
            val buf = ByteArray(PKT)
            val pkt = DatagramPacket(buf, PKT)
            sock.receive(pkt)
            if (buf[0] != MAGIC_G || buf[1] != MAGIC_K) return -1
            // FIX 9: any validly-tagged packet — not just the DATA reply
            // we're actually expecting this round — counts as proof the
            // peer is still alive. See the keepalive loop's staleness check.
            lastPeerActivityMs = System.currentTimeMillis()
            if (buf[2] == TYPE_BYE) { handlePeerLost("BYE received (Wi-Fi host wifiExchange)"); return -1 }
            if (buf[2] != TYPE_DATA) return -1
            // FIX: the packet-layout doc above always described this seq
            // byte as being "for out-of-order discard", but nothing ever
            // actually checked it on receive — a stale reply that arrives
            // late (after its own round already timed out) would be
            // silently accepted as the CURRENT round's data by whichever
            // receive() call next happened to pop it off the socket queue,
            // corrupting SIO data without ever looking like a connection
            // problem. This catches the simplest, most common case — an
            // exact repeat of the last packet already accepted — with no
            // risk of a false-positive drop. It is not full modular
            // sequence-ordering (see KNOWN_LIMITATIONS.md).
            val rxSeq = buf[3].toInt() and 0xFF
            if (rxSeq == lastRxSeq) return -1
            lastRxSeq = rxSeq
            return ByteBuffer.wrap(buf, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: SocketTimeoutException) {
            return -1
        } catch (_: Exception) {
            return -1
        } finally {
            wifiSocketLock.unlock()
        }
    }

    /**
     * FIX 9 — Wi-Fi passive child responder.
     *
     * See the FIX 9 file-header comment and nativeLinkChildExchange's C-side
     * comment for the underlying protocol reason this exists: a GBA child
     * unit never triggers a transfer itself (GBATEK: the Start/Busy bit is
     * "Read Only for Slaves"), so nothing on this device's own ROM ever
     * writes SIOCNT's Start bit — meaning jniExchangeData()/wifiExchange()
     * above are simply never reached on a child device. This thread is what
     * actually answers the host: it owns dataSocket entirely for the rest of
     * this link session, listening for the host's request packets and
     * replying to each one immediately with this device's own latched
     * outgoing data (via nativeLinkChildExchange, which also updates this
     * device's local SIOMULTI0/1 so its own ROM sees the completed round).
     *
     * Its own receive timeout doubles as this device's half of peer-liveness
     * detection: if the host goes completely silent (crash, force-close,
     * out of Wi-Fi range) for longer than that timeout, this treats it the
     * same as an explicit BYE.
     */
    private fun startWifiChildResponder() {
        wifiChildThread = Thread {
            val sock = dataSocket
            val peer = peerAddr
            if (sock == null || peer == null) return@Thread
            try { sock.soTimeout = PEER_TIMEOUT_MS.toInt() } catch (_: Exception) {}
            val buf = ByteArray(PKT)
            val pkt = DatagramPacket(buf, PKT)
            try {
                while (!Thread.currentThread().isInterrupted) {
                    try {
                        sock.receive(pkt)
                        if (buf[0] != MAGIC_G || buf[1] != MAGIC_K) continue
                        lastPeerActivityMs = System.currentTimeMillis()
                        when (buf[2]) {
                            TYPE_DATA -> {
                                val hostData = ByteBuffer.wrap(buf, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                                val childData = EmulatorEngine.nativeLinkChildExchange(hostData)
                                sendPkt(sock, TYPE_DATA, (txSeq++ and 0xFF), childData.toLong(), peer, peerDataPort)
                            }
                            TYPE_BYE -> { handlePeerLost("BYE received (Wi-Fi child responder)"); return@Thread }
                            else -> { /* KEEPALIVE — liveness timestamp already refreshed above */ }
                        }
                    } catch (_: SocketTimeoutException) {
                        // host silent for PEER_TIMEOUT_MS — treat as gone
                        handlePeerLost("no packets from host for ${PEER_TIMEOUT_MS}ms (Wi-Fi child responder)")
                        return@Thread
                    }
                }
            } catch (_: Exception) {
                // socket closed (our own disconnect()) or another I/O error
            } finally {
                // FIX 9: only a *genuine* peer loss reaches here with
                // isConnected still true — our own disconnect() already sets
                // it false before closing this socket, so that path falls
                // through here harmlessly (handlePeerLost() is a no-op once
                // peerLostNotified is set, but this check avoids even that).
                if (isConnected && mode == Mode.WIFI) handlePeerLost("Wi-Fi child responder thread exited unexpectedly")
            }
        }.also { it.name = "link-wifi-child"; it.isDaemon = true; it.start() }
    }

    private fun btExchange(localData: Int): Int {
        val out = btOut ?: return -1
        return try {
            val send = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                .put(TYPE_DATA).putInt(localData).array()
            out.write(send); out.flush()

            // FIX: poll the blocking-read queue instead of inp.available() spinning
            val recv = btReceiveQueue.poll(BT_XCHG_MS, TimeUnit.MILLISECONDS) ?: return -1
            // FIX 9: btReaderThread already refreshed lastPeerActivityMs the
            // moment this frame was read off the wire (see its own comment) —
            // just handle an explicit BYE here rather than falling through
            // and treating it as generically-bad data.
            if (recv[0] == TYPE_BYE) { handlePeerLost("BYE received (Bluetooth btExchange)"); return -1 }
            if (recv[0] != TYPE_DATA) -1
            else ByteBuffer.wrap(recv, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
        } catch (_: Exception) { -1 }
    }

    // ── Disconnect ────────────────────────────────────────────────────────

    fun disconnect() {
        // FIX 9: best-effort notify the peer immediately, before touching
        // any state below, so it doesn't have to wait out the liveness
        // watchdog's full timeout just because *we* know we're leaving.
        // Fire-and-forget: if this fails, the watchdog on the other end is
        // still there as a fallback.
        // FIX 15: this used to be entirely silent on success, skip, or
        // failure — logged now, since whether the BYE actually left this
        // device is exactly what's needed to tell "peer didn't process our
        // BYE" apart from "we never actually sent one" when reading back a
        // captured log.
        try {
            when (mode) {
                Mode.WIFI -> {
                    val s = dataSocket; val p = peerAddr
                    if (s != null && p != null) {
                        sendPkt(s, TYPE_BYE, 0, 0L, p, peerDataPort)
                        linkLog('I', "Sent BYE to $p:$peerDataPort (Wi-Fi)")
                    } else {
                        linkLog('W', "disconnect(): BYE not sent — dataSocket=$s peerAddr=$p")
                    }
                }
                Mode.BLUETOOTH -> {
                    val out = btOut
                    if (out != null) {
                        out.write(byteArrayOf(TYPE_BYE, 0, 0, 0, 0)); out.flush()
                        linkLog('I', "Sent BYE (Bluetooth)")
                    } else {
                        linkLog('W', "disconnect(): BYE not sent — btOut is null")
                    }
                }
                Mode.NONE -> {}
            }
        } catch (e: Exception) { linkLog('W', "disconnect(): BYE send threw", e) }

        // FIX: invalidates any start*/connect* attempt still in flight —
        // see connectGeneration's field comment. Must happen before the
        // socket closes below so a background thread that wakes up from
        // one of those closes (rather than its own timeout) also sees a
        // generation mismatch and drops its result instead of reporting it.
        connectGeneration++
        isConnected = false
        discThread?.interrupt();      discThread = null
        keepAliveThread?.interrupt(); keepAliveThread = null
        // FIX 9: stop the Wi-Fi child-responder thread (see its own comment)
        wifiChildThread?.interrupt(); wifiChildThread = null
        // FIX: stop BT reader thread and drain its queue
        btReaderThread?.interrupt();  btReaderThread = null
        btReceiveQueue.clear()

        try { dataSocket?.close() }      catch (_: Exception) {}
        try { discSocket?.close() }      catch (_: Exception) {}
        try { btSocket?.close() }        catch (_: Exception) {}
        try { btServer?.close() }        catch (_: Exception) {}
        // FIX: force-abort a connectBluetooth() attempt still blocked
        // inside .connect() — see btPendingSocket's field comment.
        try { btPendingSocket?.close() } catch (_: Exception) {}

        dataSocket = null; discSocket = null
        btSocket   = null; btServer   = null
        btPendingSocket = null
        btIn = null; btOut = null
        peerAddr = null
        lastRxSeq = -1
        mode = Mode.NONE
        linkLog('I', "Disconnected")
    }

    /**
     * FIX 9 — fires exactly once per session when the *peer* is the one who
     * disappears: either a liveness timeout (see PEER_TIMEOUT_MS) or an
     * explicit BYE arriving from the other side. Distinct from disconnect(),
     * which is this device's own user-initiated teardown — this function
     * calls disconnect() itself (to actually tear down sockets/state) and
     * then additionally notifies onPeerLost, which disconnect() alone never
     * does, since disconnect() is also the normal path for a local
     * "Disconnect" tap and shouldn't re-toast/re-notify on every use.
     * peerLostNotified guards against firing twice (e.g. a socket timeout
     * racing with a BYE that arrives right before it).
     *
     * FIX 15: added the `reason` parameter — every call site used to share
     * one identical generic log line ("no activity for Xms, or peer said
     * bye"), which made a captured log unable to tell an explicit BYE
     * actually arriving apart from the 8s watchdog giving up, or say which
     * of the 3 listeners (wifiExchange, startWifiChildResponder,
     * drainHostWifiKeepalives — plus btExchange/startBtReader on the BT
     * side) saw it. That ambiguity was itself part of why the Wi-Fi
     * disconnect-propagation report couldn't be diagnosed from the evidence
     * gathered so far — see KNOWN_LIMITATIONS.md.
     */
    private fun handlePeerLost(reason: String) {
        if (peerLostNotified) return
        peerLostNotified = true
        linkLog('W', "Peer connection lost: $reason")
        disconnect()
        Handler(Looper.getMainLooper()).post { onPeerLost?.invoke() }
    }

    // ── Keepalive (prevents UDP NAT timeout on routers) ───────────────────
    // FIX 9: also now the liveness watchdog (checks lastPeerActivityMs) and
    // sends over Bluetooth too (previously Wi-Fi only — BT had no periodic
    // traffic at all between real data exchanges, and thus no way for either
    // side to notice a quietly-dead connection between rounds).
    //
    // FIX 12: the WIFI branch below now also drains the host's own socket —
    // see drainHostWifiKeepalives()'s comment just below this function for
    // the gap that closes.

    private fun startKeepalive() {
        lastPeerActivityMs = System.currentTimeMillis()
        peerLostNotified = false
        keepAliveThread = Thread {
            while (!Thread.currentThread().isInterrupted && isConnected) {
                try {
                    when (mode) {
                        Mode.WIFI -> {
                            val sock = dataSocket
                            val peer = peerAddr
                            if (sock != null && peer != null) {
                                sendPkt(sock, TYPE_KEEPALIVE, 0, 0L, peer, peerDataPort)
                                // FIX 12: host role only — the child role
                                // already has startWifiChildResponder()
                                // reading continuously.
                                if (isHost) drainHostWifiKeepalives(sock)
                            }
                        }
                        Mode.BLUETOOTH -> {
                            try { btOut?.let { it.write(byteArrayOf(TYPE_KEEPALIVE, 0, 0, 0, 0)); it.flush() } }
                            catch (_: Exception) { /* btExchange()/reader thread will notice the dead socket too */ }
                        }
                        Mode.NONE -> {}
                    }
                    if (System.currentTimeMillis() - lastPeerActivityMs > PEER_TIMEOUT_MS) {
                        val idleMs = System.currentTimeMillis() - lastPeerActivityMs
                        handlePeerLost("liveness timeout — no peer activity for ${idleMs}ms (keepalive watchdog)")
                        return@Thread
                    }
                    Thread.sleep(2000)
                } catch (_: Exception) { break }
            }
        }.also { it.name = "link-keepalive"; it.isDaemon = true; it.start() }
    }

    /**
     * FIX 12 — closes a host-only gap in the FIX 9 liveness watchdog that
     * let a perfectly healthy Wi-Fi connection look "gone" a few seconds
     * after connecting, well before either ROM had a chance to actually
     * start exchanging link data. This is the most likely explanation for
     * a Wi-Fi session that shows "Connected" and then drops on its own
     * shortly after, with no user action and no obvious network fault.
     *
     * lastPeerActivityMs only ever advances in three places: here, inside
     * wifiExchange(), and inside startWifiChildResponder(). The child role
     * always has startWifiChildResponder() running continuously from the
     * moment it connects, so it keeps hearing the host's keepalives and
     * staying "alive" no matter how long the ROMs take to actually start
     * linking. The HOST role had no equivalent: the only other place it
     * ever called dataSocket.receive() was inside wifiExchange() — which
     * doesn't run until *this device's own ROM* writes SIOCNT's Start bit.
     * Until that first real transfer, the client's keepalives (and its
     * replies to the host's own keepalives) just sat unread in the host's
     * socket buffer, lastPeerActivityMs on the host never advanced past
     * whatever startKeepalive() initialised it to at connect time, and the
     * watchdog check a few lines up would then, deterministically, call
     * handlePeerLost() once PEER_TIMEOUT_MS (8s) had elapsed — tearing down
     * a connection whose peer was still very much there. (Bluetooth doesn't
     * have this gap — startBtReader() already runs, and reads continuously,
     * for both roles — which is why a BT session can stay connected long
     * enough to test whether the ROM itself reacts, while Wi-Fi previously
     * couldn't even get that far.)
     *
     * Shares wifiSocketLock with wifiExchange() using tryLock (not lock), so
     * this never steals a reply a real in-flight SIO round is waiting on —
     * if that lock is already held, a real exchange is in progress and is
     * itself proof of life, so this just skips its turn rather than
     * blocking the keepalive thread until the exchange finishes.
     */
    private fun drainHostWifiKeepalives(sock: DatagramSocket) {
        if (!wifiSocketLock.tryLock()) return   // real exchange in flight — already proves liveness
        try {
            val prevTimeout = try { sock.soTimeout } catch (_: Exception) { 0 }
            try {
                sock.soTimeout = 100
                val buf = ByteArray(PKT)
                val pkt = DatagramPacket(buf, PKT)
                // Drain everything currently queued, not just one packet —
                // a burst of retried keepalives could otherwise take
                // several 2-second cycles to fully clear.
                while (true) {
                    sock.receive(pkt)
                    if (buf[0] != MAGIC_G || buf[1] != MAGIC_K) continue
                    lastPeerActivityMs = System.currentTimeMillis()
                    if (buf[2] == TYPE_BYE) { handlePeerLost("BYE received (Wi-Fi host keepalive drain)"); return }
                }
            } catch (_: SocketTimeoutException) {
                // Nothing left queued — the normal, expected way this ends.
            } finally {
                try { sock.soTimeout = prevTimeout } catch (_: Exception) {}
            }
        } finally {
            wifiSocketLock.unlock()
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    fun localIp(): String {
        @Suppress("DEPRECATION")
        val wm = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val ip = wm?.connectionInfo?.ipAddress ?: 0
        if (ip == 0) return "0.0.0.0"
        return "%d.%d.%d.%d".format(ip and 0xFF, ip shr 8 and 0xFF,
            ip shr 16 and 0xFF, ip shr 24 and 0xFF)
    }

    /**
     * FIX: compute the subnet broadcast address (e.g. 192.168.43.255) instead
     * of always using 255.255.255.255. Some Android Wi-Fi drivers drop the
     * "limited broadcast" (255.255.255.255) from certain hotspot configurations.
     * The directed broadcast (subnet's last address) reaches all hosts reliably.
     */
    private fun subnetBroadcast(): String {
        @Suppress("DEPRECATION")
        val wm   = context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val info = wm?.dhcpInfo ?: return "255.255.255.255"
        @Suppress("DEPRECATION")
        val ipRaw = wm.connectionInfo?.ipAddress ?: 0
        val mask  = info.netmask
        if (ipRaw == 0 || mask == 0) return "255.255.255.255"
        val bcast = (ipRaw and mask) or mask.inv()
        return "%d.%d.%d.%d".format(
            bcast and 0xFF, bcast shr 8 and 0xFF,
            bcast shr 16 and 0xFF, bcast shr 24 and 0xFF)
    }

    private fun sendPkt(
        sock: DatagramSocket, type: Byte, seq: Int, data: Long,
        addr: InetAddress, port: Int
    ) {
        val buf = ByteBuffer.allocate(PKT).order(ByteOrder.LITTLE_ENDIAN)
            .put(MAGIC_G).put(MAGIC_K)
            .put(type).put(seq.toByte())
            .putInt(data.toInt())
            .array()
        try { sock.send(DatagramPacket(buf, PKT, addr, port)) } catch (_: Exception) {}
    }

    private fun isHandshake(buf: ByteArray) =
        buf.size >= 3 && buf[0] == MAGIC_G && buf[1] == MAGIC_K && buf[2] == TYPE_HANDSHAKE
}
