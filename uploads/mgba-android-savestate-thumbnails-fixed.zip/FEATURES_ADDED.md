# FEATURES_ADDED — Thirteenth pass

## 1. Save-state thumbnails

**Description:** Save/Load slot picker now shows a small screenshot of
what's actually in each slot instead of just a timestamp. Captured via the
same `PixelCopy`-against-the-`SurfaceView` technique as the existing
Screenshot feature (no new native/JNI code), written as a PNG sitting
next to the state file itself (`<rom>.state<N>.png`), and displayed via a
custom `ListView` row (`ImageView` + `TextView`) in place of the old
plain-text `setItems()` list.

**User benefit:** Makes the 4 save-state slots recognizable at a glance —
particularly useful before overwriting one, since the save dialog now
shows what's *currently* in a slot rather than just when it was last
written.

**Files modified:** `MainActivity.kt` (`showSaveStateSlotDialog()`
rewritten to use a custom adapter; new `captureStateThumbnail()`,
`stateSlotRow()`, `stateThumbFile()`).

**Reason for implementation:** Directly requested ("add pictures on save
state").

**Note:** A slot saved before this pass has a state file but no `.png`
yet — shown with a plain placeholder box until it's next saved over,
same as a genuinely empty slot's label already distinguishes via text
("Empty" vs. a timestamp). Both cases were handled without needing a
migration step: `stateThumbFile()` simply may or may not exist yet.

---

# FEATURES_ADDED — Tenth pass

All three features below come from the reference screenshot's menu
(`Link remote`/`Link local` were already elsewhere in the app — see
`BUGS_FIXED.md`/`FILE_CHANGES.md` — these three are the genuinely new
ones).

## 1. Screenshot

**Description:** New row in the quick game menu. Captures exactly what's
currently on screen via `PixelCopy` against the `SurfaceView` and saves it
as a PNG under `getExternalFilesDir(null)/Screenshots/`, named after the
current ROM and a timestamp.

**User benefit:** No screenshot capability existed before at all.

**Files modified:** `MainActivity.kt` (`takeScreenshot()`,
`saveScreenshotBitmap()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Screenshot` row.


## 2. Reset

**Description:** New row in the quick game menu. Power-cycles the running
game: reloads the last-loaded ROM (still cached on disk — see
`FILE_CHANGES.md`) against the same battery-save path, exactly like a
fresh load.

**User benefit:** No in-game reset existed before — previously the only
way to restart a game was backgrounding and relaunching the whole app.

**Files modified:** `MainActivity.kt` (`resetGame()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Reset` row. Deliberately implemented by reusing `nativeLoadROM()`
rather than adding a new native `core->reset()` export — see
`FILE_CHANGES.md` for why.


## 3. Close

**Description:** New row in the quick game menu. Stops the current game
(loop, audio) and returns to the "▶ Load ROM" idle state — the same button
shown before anything's ever been loaded.

**User benefit:** No way to cleanly stop a running game and get back to a
"nothing loaded" state existed before, short of leaving the app entirely.

**Files modified:** `MainActivity.kt` (`closeGame()`).

**Reason for implementation:** Directly requested — matches the reference
menu's `Close` row.


# FEATURES_ADDED — Fifth pass

Both features below are backend-only or off-by-default additions — neither
changes the existing UI's look, layout, or default behavior.

## 1. Auto save backup

**Description:** Before the battery save file is re-opened/mapped by a new
ROM load, or a save-state slot is overwritten, the existing file (if any)
is copied to a sibling `<name>.bak` file. Best-effort and silent — a
backup failure is logged but never blocks or interrupts the actual save.

**User benefit:** A single level of rollback if a save turns out to be
corrupted (app killed mid-write, storage fills up mid-save, or anything
else goes wrong during the write itself). Previously there was no recovery
path at all — the previous save's on-disk content was already truncated
before the new write completed.

**Files modified:** `MainActivity.kt` (`backupIfExists()`, and its two call
sites in the ROM-load path and the save-state-slot dialog).

**Reason for implementation:** Directly requested ("Auto save backups") in
the review brief, and implementable as pure, low-risk file management with
no native code or UI changes.

## 2. Optional performance overlay

**Description:** A small corner readout showing emulated core FPS
(counting every emulated GBA frame, including fast-forward sub-frames) and
the existing `AudioTrack.getUnderrunCount()` figure. Off by default;
toggled via a checkbox in ⚙ Settings → Misc, alongside the existing
fast-forward-speed setting; included in "Reset settings to defaults".

**User benefit:** At-a-glance answer to "is this actually keeping up right
now?" — useful when troubleshooting a specific device or ROM — without
needing to attach `adb logcat`.

**Files modified:** `MainActivity.kt` (state fields, a gated counter in the
game loop, a draw function following the exact style of the existing
link-status/fast-forward overlays, and the Misc-settings checkbox).

**Reason for implementation:** Directly requested ("Performance monitor",
"FPS counter") in the review brief. Implemented so it costs nothing when
disabled — the counting code inside the game loop (the same thread that
paces audio) is skipped entirely unless the toggle is on.
