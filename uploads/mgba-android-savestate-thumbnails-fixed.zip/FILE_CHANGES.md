# FILE_CHANGES — Fourteenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-attached CI build log: `compileReleaseKotlin` failed with
`Val cannot be reassigned` at line 2272, column 13.
**What changed:** `showLinkDebugLogDialog(text: String)` →
`showLinkDebugLogDialog(logText: String)`; its one internal reference
(`text.ifBlank { ... }` → `logText.ifBlank { ... }`) updated to match.
Nothing else in the function changed — `text = shown` inside the
`TextView(this).apply { ... }` block a few lines later is untouched, and
is exactly what now compiles correctly once the name collision is gone.
**Why this fixes it:** See `BUGS_FIXED.md`'s Fourteenth-pass entry — in
short, the bare `text` inside that `apply` block was resolving to the
outer function's own `text: String` parameter (immutable) rather than
`TextView`'s settable `text` property, because they had the same name.
**Verification:** No compiler available in this sandbox (same as every
pass), but this one traces directly back to an actual `compileReleaseKotlin`
failure with an exact file/line/column, rather than being read-only
review. Confirmed the fix doesn't ripple anywhere else: `logText` is only
referenced within this one function, and its single caller
(`copyLinkDebugLog()`) passes its argument positionally, so the rename is
invisible there.

---

# FILE_CHANGES — Thirteenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Requested: show a picture for each save-state slot.
**What changed:**
- Two new imports: `android.graphics.BitmapFactory`,
  `java.util.concurrent.CountDownLatch`, `java.util.concurrent.TimeUnit`.
- New `STATE_THUMB_WIDTH_PX = 200` constant next to `SAVE_STATE_SLOTS`.
- New `stateThumbFile(slot)`, right next to `stateSlotFile(slot)`: same
  dir, same base name, `.png` appended.
- New `captureStateThumbnail(slot)`: `PixelCopy`-captures the live
  `SurfaceView` (same technique as `takeScreenshot()`), blocks on a
  `CountDownLatch` until the callback fires (bounded to 500ms), scales to
  `STATE_THUMB_WIDTH_PX` wide with height derived from the surface's
  actual current aspect ratio (not hardcoded, so it can't stretch the
  image regardless of letterboxing/fullscreen state), and writes it as a
  PNG.
- New `stateSlotRow()`: a two-child `LinearLayout` (`ImageView` +
  `TextView`) for the slot picker's `ListView`. Deliberately does **not**
  set `isClickable`/`isFocusable` on the row or either child, and does
  not attach `setOnClickListener` — see its doc comment, which points
  back at the Eleventh pass's `gameMenuRow()` fix; this is the same
  ListView-item-inside-an-AlertDialog shape, so the same bug class
  applies and was avoided from the start rather than reintroduced.
- `showSaveStateSlotDialog()`: rewritten from a plain `setItems(labels)`
  call to a custom `ArrayAdapter<SlotInfo>` using `stateSlotRow()`,
  decoding each slot's thumbnail (if any) via `BitmapFactory.decodeFile()`
  guarded by its own try/catch (a corrupt/partial PNG must not crash
  `getView()`, which runs directly under the framework). The save branch
  now also calls `backupIfExists(stateThumbFile(slot))` alongside the
  existing state-file backup, and `captureStateThumbnail(slot)` after a
  successful save.
**Why this works without new native code:** Thumbnails are a pure
Kotlin/UI-layer addition — same `PixelCopy`-against-`SurfaceView`
mechanism `takeScreenshot()` already uses, no new JNI export, so none of
the build-vs-sandbox risk a hand-written native addition would carry
(see FIX 8 in `mgba_jni.c`) applies here.
**Verification:** No compiler or device available in this sandbox (same
limitation as every previous pass). New block (26 open/26 close braces,
107/107 parens) counted directly; confirmed the row's lack of
`isClickable`/`isFocusable` by re-reading it side by side with the fixed
`gameMenuRow()`; confirmed via grep that `showSaveStateSlotDialog()`'s
only other caller (`showSaveStateMenu()`, already dead code) still
compiles against the unchanged signature.

### `CHANGELOG.md`, `FEATURES_ADDED.md`
**Why:** Keep the running history current — this pass is purely
additive, nothing multiplayer/link-related touched.
**What changed:** New Thirteenth-pass entries prepended above the
existing ones, which are unchanged.

---

# FILE_CHANGES — Twelfth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** W's retest confirms the Sixth-through-Ninth-pass "ROM stuck on
its own in-game link/multiplayer wait screen" issue is still present.
Every pass since the Eighth has agreed the actual next step is real
device logcat, but nothing in this project implies an adb/PC workflow —
W works entirely from the phone.
**What changed:**
- Three new imports: `android.content.ClipData`, `android.content.ClipboardManager`.
- `showGameMenu()`: added `"Copy link log"` to the item list (index 9,
  right after Reset) and its `when` branch calling `copyLinkDebugLog()`.
  `Close` shifts from index 9 → 10; `needsRom = setOf(0, 1, 2, 7, 8)` is
  untouched since none of those indices moved.
- New `copyLinkDebugLog()`: shells out to `logcat -d -t 2000 -v
  threadtime -s mGBA-JNI:* mGBA-Link:* mGBA:*` on a background thread,
  then hands the text to a new `showLinkDebugLogDialog()` on the UI
  thread.
- New `showLinkDebugLogDialog()`: copies the text to the clipboard and
  shows it in a selectable, monospace, scrollable `AlertDialog`.
**Why this works without root:** `logd`'s access control is per-UID — a
process can always read back log entries it wrote itself; `READ_LOGS`
(system/signature-only) only gates reading *other* processes' entries.
Since `mGBA-JNI`/`mGBA-Link`/`mGBA` are all logged by this app's own
process, no special permission is needed.
**Verification:** No compiler or device available in this sandbox (same
limitation as every previous pass). The new block (12 open/12 close
braces, 44/44 parens) was counted directly; the `showGameMenu()` diff was
re-viewed after editing to confirm `needsRom`'s indices still point at
Load/Save/Fast forward/Screenshot/Reset and not at the new row or the
shifted Close.

### `CHANGELOG.md`, `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md`
**Why:** Keep the running history honest — this pass is a diagnostic
tool addition, explicitly not a fix to the underlying link issue.
**What changed:** New Twelfth-pass entries prepended above the existing
Eleventh/Ninth-pass ones, which are unchanged.

---

# FILE_CHANGES — Eleventh pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User report: tapping Settings, Link remote, Save, or Load in the
⚙ quick game menu (added last pass) did nothing.
**What changed:** `gameMenuRow()` — removed `isClickable = true;
isFocusable = true`. Nothing else in the function, or in `showGameMenu()`
itself, changed.
**Why this fixes it:** See `BUGS_FIXED.md`'s Eleventh-pass entry for the
full root-cause explanation — in short, a clickable/focusable `ListView`
row steals its own touch before the `ListView`'s `OnItemClickListener`
(the actual click handler for this menu) ever fires.
**Verification:** No compiler or device available in this sandbox (same
limitation as every previous pass — see `KNOWN_LIMITATIONS.md`). Verified
by full manual reading, a whole-file brace/paren balance check after the
edit (both end at depth 0, neither goes negative anywhere across the
2,847-line file), and by grepping the whole file for every other
`isClickable`/`ArrayAdapter`/`setAdapter` occurrence to confirm this is
the only `ListView`-backed dialog in the project and the only place this
exact bug class could exist — the other three `isClickable` rows
(`settingsRow()`, the Settings header's "✕ Close" chip, and the Settings
overlay's own root-level touch-swallow) are all plain `LinearLayout`/
`View` click targets with their own `setOnClickListener`, an unrelated
and correct pattern that was not touched.

## Not modified

`mgba_jni.c`, `EmulatorEngine.kt`, `LinkMultiplayer.kt`,
`buildSettingsMenu()`/`settingsRow()`, and every build/config file were
not touched this pass.

---

# FILE_CHANGES — Tenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-requested pass: restyle the quick game menu (⚙ button) to
match a reference screenshot of My Boy's own pause menu, trim two rows out
of Settings, make immersive mode actually stick, and fix a black bar
sitting in the camera-cutout area.

**What changed:**
- `showGameMenu()` rebuilt: was a bare `.setItems()` list (5 items, default
  system row styling); now a custom `ArrayAdapter` of plain-text rows (new
  `gameMenuRow()` helper) over a pinned dark rounded-corner dialog
  background, with five rows folded in (`Link remote`, `Link local`,
  `Screenshot`, `Reset`, `Close`) alongside the original `Load`/`Save`/
  `Fast forward`/`Cheats`/`Settings`, matching the reference's ten-item,
  scrollable list. AlertDialog's own internal list view handles the
  scrolling, same as it always did for the old 5-item version.
- `buildSettingsMenu()`: removed the `Change ROM` and `Save States` rows.
  `changeRom()` is still reachable from the initial "▶ Load ROM" button and
  from the new `Close` action below; `showSaveStateMenu()` (the row's old
  target) is now unused but left in place rather than deleted.
- `onCreate()`: now sets `layoutInDisplayCutoutMode =
  LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES` (API 28+, guarded) so the
  window draws into the cutout instead of leaving a black bar there.
- New `onWindowFocusChanged()` override re-applies `setImmersive()` on
  every focus regain, not just once at launch — every dialog this app
  opens was quietly undoing the old one-shot call.
- Three new functions: `takeScreenshot()` / `saveScreenshotBitmap()` (via
  `PixelCopy` against the `SurfaceView`, saved to
  `getExternalFilesDir(null)/Screenshots`), `resetGame()`, `closeGame()`.

**Why this fixes/adds it:** See `BUGS_FIXED.md` and `FEATURES_ADDED.md`'s
Tenth-pass entries for the immersive/cutout root causes and the new
features' design notes respectively — in particular why `resetGame()`
reuses `nativeLoadROM()` instead of a new JNI export.

**Verification:** No compiler or device available in this sandbox (same
limitation as every previous pass — see `KNOWN_LIMITATIONS.md`). Verified
by full manual reading plus a whole-file brace/paren balance check after
every edit (both end at depth 0, neither goes negative anywhere in the
file). Every function the new code calls — `nativeLoadROM`,
`nativeGetWidth`/`nativeGetHeight`, `stopGameLoop`/`startGameLoop`,
`batterySaveFile`, `backupIfExists`, `clearPointerState`, `stopLink` — was
confirmed to already exist with a matching signature before being called.

## Not modified

`mgba_jni.c`, `EmulatorEngine.kt`, `LinkMultiplayer.kt`, and every build/
config file were not touched this pass.

---

# FILE_CHANGES — Ninth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** User report separated the two transports for the first time —
Wi-Fi connects then drops a few seconds later on its own; Bluetooth stays
connected but the ROM still doesn't react (unchanged eighth-pass symptom,
not addressed further this pass — see `KNOWN_LIMITATIONS.md`).
**What changed:** New `wifiSocketLock` (`ReentrantLock`) field.
`wifiExchange()` now acquires it for its send+receive (restructured from an
expression-bodied `return try {...}` to an explicit `try {...} finally {
wifiSocketLock.unlock() }` — same branches, same return values, just able
to guarantee the unlock). New `drainHostWifiKeepalives()` function, called
from `startKeepalive()`'s `Mode.WIFI` branch when `isHost` is true; it
`tryLock()`s the same lock, and if it gets it, drains any queued
KEEPALIVE/BYE packets with a short 100 ms per-receive timeout, refreshing
`lastPeerActivityMs` for each one, before restoring the socket's previous
timeout and releasing the lock.
**Why this fixes it:** see `BUGS_FIXED.md`'s Ninth-pass entry for the full
root-cause explanation — in short, the host role had no code path that
ever read the data socket until real game SIO transfers began, so the
liveness watchdog could starve and fire on a healthy connection well
before that point.
**Verification:** No compiler or device available in this sandbox (see
`KNOWN_LIMITATIONS.md`, unchanged from every pass). Verified by full manual
reading: confirmed `wifiSocketLock` has exactly three use sites (its own
declaration, the `lock()`/`finally unlock()` pair in `wifiExchange()`, and
the `tryLock()`/`finally unlock()` pair in `drainHostWifiKeepalives()`),
confirmed every `return` inside `wifiExchange()`'s rewritten body still
sits inside the `try` whose `finally` releases the lock, and re-ran a
whole-file brace/paren balance check after the edit (both end at depth 0,
neither goes negative at any point in the file).

## Not modified

`mgba_jni.c`, `MainActivity.kt`, `EmulatorEngine.kt`, and every build/config
file were not touched this pass. `mgba_jni.c` in particular was
deliberately left alone: the eighth pass's trace logging there already
covers whatever the next real test needs (the `LOGI("SIO write
addr=...")` line fires on any transport, Wi-Fi or Bluetooth, since it's at
the GBA-core SIO-register level, not the network level), and adding a
fifth protocol theory with no logcat to check it against would repeat the
exact mistake the eighth pass deliberately stopped making.

---

# FILE_CHANGES — Eighth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** Seventh pass's SIO-IRQ fix was re-tested against both games over
both Wi-Fi and Bluetooth — no change at all: "Connected" still shows, the
ROM still doesn't react, fast-forward is still fully available. That's a
different situation from "fix didn't quite work" — an identical, not
merely improved, symptom across every combination tested suggests
`link_sio_write_register()` may never be running at all for either game,
which no amount of correctness inside that function could ever fix.
**What changed:** Two log lines added, no behavior changed. (1) Every
SIOCNT/SIOMLT_SEND write this driver handles is now logged — address,
value, active/host flags — under tag `mGBA-JNI`. (2) If the Start bit is
set but the exchange branch gets skipped, a warning names exactly which
precondition (`ld->env` / `g_link_obj` / `g_link_xchg_mid` / `g_core`) was
unexpectedly null or false.
**Why logging instead of another protocol fix:** `GBASIOSetDriver()`
registers this driver only for `SIO_MULTI` mode, and mGBA's core re-picks
its *active* SIO driver every time the ROM's own RCNT/SIOCNT mode bits
change — so if either ROM's handshake spends time in a different mode (or
never gets far enough to reach Multi-Player mode at all), this driver is
never consulted, and nothing done in the sixth or seventh pass would be
observable either way. That's a plausible, coherent explanation for
"identical symptom, zero change" — but confirming it from a code-reading
pass alone isn't possible; it needs to be checked against what actually
happens on-device. Silence under this tag during a real attempt confirms
it directly; log lines showing up (with what value) point somewhere else
entirely.
**Verification:** None yet — this is instrumentation, not a fix, and is
explicitly meant to be judged by its logcat output on the next real test.

---

# FILE_CHANGES — Seventh pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User re-tested the sixth pass's fix against Yu-Gi-Oh! World
Championship 2006 and The Legend of Zelda: Four Swords — still not
working, plus a new diagnostic detail: fast-forward stays available
during an active "Connected" session, which real hardware/mGBA proper
doesn't allow.
**What changed:** Two calls to `GBARaiseIRQ(g_link_gba, GBA_IRQ_SIO, 0)`
added — one in `link_sio_write_register()`'s Start-bit/exchange branch
(host path), one in `nativeLinkChildExchange()` (child path) — each right
after that side finishes writing SIOMULTI0-3 for the round. Also updated
the now-stale FIX 8 comment that had said raising this IRQ was an
unaddressed gap, since FIX 10 (this pass) addresses it.
**Expected benefit:** Any GBA multiplayer ROM using the standard
interrupt-driven wait (BIOS `IntrWait`/`VBlankIntrWait` on the serial
interrupt, rather than busy-polling SIOCNT) should now actually wake up
and see the transfer the sixth pass's fixes correctly deliver, instead of
sleeping forever waiting for an interrupt that was never coming. Also
explains (without requiring any change to) the fast-forward observation:
a stalled, interrupt-sleeping ROM isn't re-hitting the Start bit every
frame, so fast-forward had nothing left to throttle it against.
**Verification:** Confirmed the exact call/constant name
(`GBARaiseIRQ`/`GBA_IRQ_SIO`) by reading mGBA's real `src/gba/sio.c` this
pass, not from memory — see the `FIX 10` comment block at the top of the
file for the citation, and `KNOWN_LIMITATIONS.md` for what that
verification does and doesn't cover (real source, but not a build log
against this project's exact pinned tag).

## Not modified

`LinkMultiplayer.kt`, `MainActivity.kt`, `EmulatorEngine.kt`, and every
build/config file were not touched this pass — this pass was scoped
tightly to the one root cause found, per the reported symptom.

---

# FILE_CHANGES — Sixth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User report: "Connected" shows in the app but the ROM's own link
menu never progresses, and a peer disconnecting isn't noticed. The fifth
pass's `FILE_CHANGES.md` explicitly says this file was "read in full... no
changes made or needed" — this pass found that assessment was looking for
memory-safety/mutex issues (which is genuinely fine) rather than SIO
protocol correctness against GBATEK, which is where the actual bug was.
**What changed:** `link_sio_write_register()` now reflects SIOCNT's
parent/child (bit 2) and all-ready (bit 3) status on every write, and sets
the ID (bits 4-5) and Error (bit 6) bits correctly after a transfer — all
four were previously never touched. Added `nativeLinkChildExchange()`, a
new JNI entry point a child device's Kotlin-side listener threads call the
instant a request arrives over the network, since a real GBA child never
triggers its own transfer (see `BUGS_FIXED.md` for the full explanation).
**Expected benefit:** This is the fix that should actually let two phones
get a ROM past its own "waiting for link" screen, rather than just the
app-level socket handshake succeeding.

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Kotlin-side declaration for the new native entry point above.
**What changed:** Added `external fun nativeLinkChildExchange(hostData: Int): Int`.
**Expected benefit:** N/A (declaration only).

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** Same report as above, plus: "if I disconnect on other phone the
other phone doesn't detect that and say still connected."
**What changed:** New `startWifiChildResponder()` thread (Wi-Fi child role)
and a new child-mode branch inside the existing `startBtReader()`
(Bluetooth child role), both calling `nativeLinkChildExchange()`; a BYE
packet sent best-effort at the top of `disconnect()`; a liveness watchdog
(`lastPeerActivityMs` / `PEER_TIMEOUT_MS`) checked inside `startKeepalive()`
which now also runs for Bluetooth (previously Wi-Fi only) and sends BT
keepalive traffic too; new `onPeerLost` callback; `wifiExchange()`/
`btExchange()` now recognize an explicit BYE instead of treating it as
generically-bad data. See `BUGS_FIXED.md` for the full list.
**Expected benefit:** Multiplayer should actually reach the ROM; a peer
disconnecting (intentionally or otherwise) should now be reflected in the
UI within a couple of seconds instead of never.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Needs to react when `LinkMultiplayer` detects the peer is gone —
previously there was no such signal to react to.
**What changed:** One line wiring `link.onPeerLost` to the same UI update
`stopLink()` already does (reset the link button, toast), right after
`link` is constructed.
**Expected benefit:** "Connected" no longer lies indefinitely after the
other phone actually leaves.

## Added

- Sixth-pass sections prepended to `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md`,
  and this file, following the project's existing per-pass convention.

## Deleted

None.

## Reviewed and deliberately left unchanged

- **Everything the fifth pass already reviewed** (`CMakeLists.txt`,
  `proguard-rules.pro`, Gradle files, the manifest) — not re-audited from
  scratch this pass; nothing in this pass's changes touches any of them.

# FILE_CHANGES — Fifth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** Dedicated review of the multiplayer/link-cable subsystem, which
hadn't had one yet across the previous four passes.
**What changed:** `@Volatile` added to six connection-state fields; a
`discSocket` field that existed but was never assigned is now actually
used; a `connectGeneration` token and `btPendingSocket` tracking added
across all four connect paths and `disconnect()`; the Wi-Fi `DATA` packet's
`seq` byte is now validated on receive instead of only being populated on
send. See `CHANGELOG.md` items 1–4 for full detail.
**Expected benefit:** More reliable multiplayer connection setup, teardown,
and reconnect handling; a documented-but-previously-nonfunctional packet
check now actually works.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** General review pass plus fixing the cross-cutting issue where a
native-side ROM swap could silently leave the Kotlin-side link state
inconsistent.
**What changed:** ROM load/change now disconnects an active link session
first; the ROM-load completion callback now checks `isFinishing`/
`isDestroyed`; added `backupIfExists()` and wired it into both the battery
-save and save-state-slot write paths; added an opt-in performance overlay
(state fields, game-loop counter, draw function, and a Misc-settings
checkbox). See `CHANGELOG.md` items 5–8.
**Expected benefit:** Consistent link/ROM state, one fewer lifecycle edge
case, a data-safety net, and an optional diagnostic overlay — all without
any visible change to the existing UI unless the new overlay is explicitly
turned on.

### `app/src/main/AndroidManifest.xml`
**Why:** Two declared permissions were confirmed (via grep across the
whole `kotlin/` tree) to be unused.
**What changed:** Removed `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN`,
each with a comment explaining why.
**Expected benefit:** Smaller permission footprint; no functional change,
since neither was ever checked or relied upon.

### `gradle.properties`
**Why:** `android.enableJetifier` was verified to be dead weight given the
current dependency list.
**What changed:** `android.enableJetifier=true` → `false`, with a comment
explaining the reasoning and when to revert it.
**Expected benefit:** Marginally faster builds.

### `README_SETUP.md`
**Why:** The project's own convention (see its "Fixes applied vs the
original" / "Second/Third/Fourth pass" sections) is to document each
review pass in place.
**What changed:** Appended a "Fifth pass" section following the same
format, plus a note (not a retroactive edit) flagging that the original
table's pthread-linking entry no longer matches the current
`CMakeLists.txt`.
**Expected benefit:** Keeps the project's own change history complete and
consistent for whoever reads it next (including a future review pass).

## Added

- `CHANGELOG.md`, `REVIEW_REPORT.md`, `FILE_CHANGES.md` (this file),
  `FEATURES_ADDED.md`, `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md` — the
  documentation deliverables for this pass.

## Deleted

None.

## Reviewed and deliberately left unchanged

- **`app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`** — read in
  full; a clean, minimal JNI facade with no issues found.
- **`app/src/main/cpp/mgba_jni.c`** — read in full (all 731 lines). Every
  entry point already correctly guards `g_core`/`g_fb` behind
  `g_core_mutex` with proper NULL-after-destroy checking, including the
  ROM-swap path. No changes made or needed.
- **`app/src/main/cpp/CMakeLists.txt`** — read in full; the pthread-linking
  decision (intentionally *not* linking `-lpthread`) is correct and already
  well-commented for NDK r18+. No changes made.
- **`app/proguard-rules.pro`** — already correctly protects
  `jniExchangeData` (the one method a native `GetMethodID` lookup depends
  on by exact name) from R8 renaming. No changes needed.
- **`app/build.gradle.kts`, `settings.gradle.kts`,
  `gradle/wrapper/gradle-wrapper.properties`** — reviewed; no functional
  issues found. See `KNOWN_LIMITATIONS.md` for one supply-chain
  recommendation (a pinned wrapper checksum) that wasn't made because this
  sandbox has no network access to fetch the real value.
