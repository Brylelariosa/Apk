# Rust port notes

## Layout

| Path | What lives there | Builds on a PC? |
|---|---|---|
| `src/core` | maths, Kotlin-exact `Random` (so seeds shuffle noise like before), logging, fast hasher, clock, thread pool | yes |
| `src/world` | blocks, chunks (copy-on-write sections), fluids, world storage, streaming with worker threads | yes |
| `src/gen` | noise, climate, land shape, caves, trees, chunk generator — a 1:1 port of the v15 generator | yes |
| `src/mesh` | chunk mesher (culling, ambient occlusion, cave darkening, biome tint, water, plants, merged "greedy" quads), per-section visibility graph, occlusion culling | yes |
| `src/lod` | far terrain: clip-map tiles, the cell sampler, the blocky tile mesher, the tile manager with its worker threads | yes |
| `src/tex` | the 34 pixel-art tiles (generated from the Kotlin tables by `tools/gen_tiles.py`) + texture array data, and the tileable cloud noise (`cloud_noise`) | yes |
| `src/game` | player, physics, flight, raycast, placement, hotbar, settings, saves, engine | yes |
| `src/ui` | pixel font, 2D batch, touch tracking, HUD, all screens (`ui/app.rs`, `ui/app/settings_screen.rs`) | yes |
| `src/diag` | the debug log: probes, per-second recorder, background writer, verdicts, `/proc` readers | yes |
| `src/perf` | the automatic quality control (`governor`: ladder of block distance / resolution, up and down rules) and its memory (`memory`) | yes |
| `src/render` | OpenGL ES 3.0 renderer (real chunks in four passes, far terrain, sky, clouds, off-screen target), shaders, GPU timer, warm-up | Android only |
| `src/platform` | EGL, NativeActivity event loop, touch + back key, full-screen (`sysui`), the log file in Download (`storage`, `device`, `logging`), JNI plumbing (`java`) | Android only |

Everything except `render` and `platform` is plain Rust and is unit-tested on the build machine
(`cargo test --lib`, run by the workflow). `render` was also compiled and run headless against Mesa's software
OpenGL ES 3.2 to check the pictures and `glGetError`; `platform` is only type-checked off the phone.

## Threads

* The **main thread** owns the world and the GL context and runs the frame: input, update, render, swap.
* **Worker threads** (up to 3) generate chunks, build chunk meshes and build far-terrain tiles from cheap snapshots
  (chunk sections are `Arc`s, so a snapshot is a few pointer copies and an edit copies only the section it touches).
  Results come back through channels; the renderer uploads a time-sliced number of meshes per frame.
* **`vs-log`** is the log writer (`diag::sink`): lowest priority (nice 19), the only thread that touches the log file.

## Render distance, detail distance and far terrain

* **Render distance** is in chunks (16 blocks), 4 to 5000 (= 80,000 blocks). Settings has a logarithmic slider, `-` / `+`
  buttons that repeat while held and accelerate, and a MAX button.
* **Detail distance** (4 to 500 chunks, default 10, never above the render distance) is the radius of real blocks: chunks are
  generated, meshed, edited and collided with. This is the expensive part, so the game never builds more than
  `MAX_REAL_BLOCK_CHUNKS` (32) chunks of real blocks, whatever the slider says: a chunk column takes about 0.3 MB, so 500 chunks
  (some 800,000 columns) cannot fit in a phone. The slider then reads, for example, `32 OF 500 CHUNKS`.
* Beyond the detail distance the world is drawn as **far terrain** (`src/lod`), so a 5000-chunk view does not mean a 5000-chunk
  world in memory. It is a clip map of 9 levels (a render distance of 1000 chunks uses the first 6). A level-`k` cell is
  `8 << k` blocks (8, 16, 32 … 2048), a tile is 32 × 32 cells,
  and each level keeps a 5 × 5 window of tiles around the player (level 8 reaches about 131,000 blocks). A tile is made of four
  quarters, and each quarter is one tile of the next finer level, so a finer tile can take over a quarter without a crack
  (the coarse tile just skips that quarter: a "hole").
* The far terrain **looks like blocks on purpose**. Each cell is one flat-topped column with one height and one colour, taken
  from the same generator as the real world (coarse levels sample fewer noise octaves, level 0 takes the lowest of five probes
  so a far column never pokes above the real blocks). Side walls exist only where the neighbour is lower, and on tile and
  quarter borders they always reach down `clamp(4 × cell, 32, 256)` blocks so two levels never show a gap. Sea cells are merged
  into big flat rectangles. A little per-cell brightness noise (the same on both sides of a tile seam) and the baked
  top / north-south / east-west shading keep the stepped look. There are no smooth normals and no vertex blending.
* A tile is 16-byte vertices (`f32 × 3` position + RGBA8 colour) and `u16` indices, one VAO per tile, one draw call per tile
  (a few more when quarters are holes). Draw order (`Renderer::draw_world`): everything opaque is drawn nearest first, so the GPU
  rejects what is hidden before shading it. The real blocks come first (solid, leaves, plants) in the first 60 % of the depth
  buffer (`glDepthRangef`), then the far terrain, nearest tile first, in the rest (out to the fog end, with a near plane that
  grows with the view distance, so an 80 km view keeps its depth precision), then the sky and clouds at depth exactly 1.0, so
  they are only shaded where nothing else was drawn, then the aim outline and the water. There is no depth clear in the middle
  of the frame. Fog blends blocks and far terrain. Underwater the far pass and the sky are skipped.

## Optimisations

Numbers are from a fixed test world and camera (seed 555, 24 chunks of real blocks, 900 × 405), run headless against Mesa.

| What | Where | Effect |
|---|---|---|
| Greedy ("merged") meshing: chunks 6 or more chunks from the player (`Settings::MERGE_FROM_CHUNKS`, independent of the detail distance, so the quality control can change the detail distance without rebuilding the world) are built from merged quads of up to 8 × 8 blocks; the nearer chunks keep the exact per-block look. Hysteresis stops a chunk being rebuilt back and forth at the border. | `mesh/mesher.rs` | 818 k → 241 k triangles together with the next two rows (1,658 → 1,168 draw calls) |
| Merged chunks leave out plants (grass, flowers, lily pads). | `mesh/mesher.rs` | plants 107 k → 9 k triangles, 539 → 49 draw calls (greedy off → on) |
| Merged chunks join flat water surfaces (all four corners at the same height) into quads of up to 16 × 16 blocks; sloping shore cells keep their own quads. | `mesh/mesher.rs` (`WATER_TOP` layer of the merge masks) | water 144 k → 4 k triangles (greedy off → on) |
| Frustum culling: columns are classified Outside / Partial / Inside, and for Partial ones each 16-block section is tested. | `render/chunks.rs`, `mesh/visibility.rs` | fewer draw calls and triangles |
| Occlusion culling: a section is only visited if a ray from the camera can get into it through the open faces of the sections in front of it (a 15-bit connectivity set per section, a search per octant). Conservative: it may draw a hidden section, it never hides a visible one (checked against an 84,000-ray reference). | `mesh/occlusion.rs` | about 13 % fewer triangles |
| Four passes for the blocks: solid (no `discard`, nearest first, so hidden pixels are rejected early), leaves and plants (alpha-tested), water (blended, far to near). | `render/programs.rs`, `render/shaders.rs`, `render/chunks.rs` (`draw_opaque/cutout/plants/water`) | cheaper pixels, early depth rejection |
| `mediump` varyings, fog per vertex (`render/fog.rs`), water ripple per vertex, cloud shape from a 256 × 256 noise texture instead of four noise octaves per pixel (this also fixed the clouds being drawn invisible), a smaller sky shader. | `render/shaders.rs`, `tex/cloud_noise.rs` | the sky and cloud passes cost a few lookups instead of a few hundred operations per pixel |
| All shaders are compiled at start-up by drawing one tiny triangle with each (`Renderer::warm_up`), so there is no 100-200 ms stall the first time a new shader is used. | `render/renderer.rs` | no first-use hitches |
| Auto performance (`perf/governor.rs`): a ladder of (detail distance, resolution) levels derived from the player's maxima; down after 2 slow seconds (or at once, by 2-3 levels, for very slow ones), up only as an experiment after 20+ smooth seconds, with doubling back-off after a failed try; GPU time (timer queries) shortens the wait when the GPU has room. The settled level is remembered (`perf/memory.rs`). | `perf/*`, `ui/app.rs` (`game_settings()` = player's settings, lowered) | holds ~60 fps on weak phones by itself |
| The paused world is drawn once into an off-screen target and copied afterwards (`world_frozen`, `PictureKey`). | `render/renderer.rs`, `render/target.rs` | about 16× less work behind the pause menu |
| Far-terrain LOD (above): the part of the view beyond the detail distance costs a few hundred draw calls instead of thousands of chunks. | `src/lod`, `render/far.rs` | what makes 1000 chunks possible |
| Time-sliced GPU uploads, fast hash maps, back-face culling in the far pass, a render-resolution setting (offscreen target, UI stays at native resolution; the depth is invalidated before the copy so tile-based GPUs do not write it to memory). | `render/*`, `core/fasthash.rs` | smoother frames |

Greedy meshing, occlusion culling and auto performance have switches in Settings → Graphics, so the effect can be compared on the
phone. **Draw calls and triangles** are the GPU cost; if the log says `LAG: GPU/DISPLAY`, look at the `gpu-time` figure and at the
per-pass triangles at the end of the line, and at the `auto performance:` EVENT lines.

### GPU timing

`render/gpu_timer.rs` wraps each frame in a `GL_TIME_ELAPSED_EXT` query (extension `GL_EXT_disjoint_timer_query`, using the
core ES 3.0 query entry points), keeps a ring of four queries so nothing waits for a result, ignores results when the driver
reports a disjoint event, and turns itself off if the driver raises an error on first use. The latest value goes to the log line
(`gpu-time`) and to the governor. On phones without the extension both simply work from the frame times.

## Full-screen

`platform/sysui.rs` hides the status bar and the navigation bar by calling the framework through JNI on the Java UI thread
(no Java code): `WindowInsetsController` on Android 11+, the immersive `setSystemUiVisibility` flags before that. It runs when
the window is created, when focus returns, and when the app resumes (the system shows the bars again after the notification
shade or a dialog). A swipe from the edge shows the bars for a moment and they hide again. The theme also sets
`windowFullscreen` and, on Android 9+, `windowLayoutInDisplayCutoutMode = shortEdges` so the picture goes behind the camera cut-out.

## The debug log (`src/diag`, `platform/{storage,device,logging}.rs`)

Written to the Download folder as `VoxelSandbox-log_<date>_<12-hour time>.txt`, one line per second with the phone's clock
(`1:20:05pm`), then per-stage times of the game thread, worker activity, GPU uploads, draw calls, triangles, far-tile
counts, process CPU, memory and temperature, and a verdict:

| Verdict | Meaning |
|---|---|
| `smooth` | at the display's rate |
| `LAG: CALCULATION` | the game thread was busy with logic, streaming, menus (the biggest part is named) |
| `LAG: RENDERING (CPU side)` | the game thread was busy preparing and submitting drawing work (named: upload, culling, draw calls, UI…) |
| `LAG: GPU/DISPLAY` | the game thread was waiting for the GPU or the screen |
| `LAG: CPU STARVED` | the game thread was neither busy nor waiting: other apps or heat throttling took the CPU |
| `HITCHES` / `HITCH` line | isolated frames over 50 ms, with the stage that took the time and the queue sizes |

Each minute ends with a `---- 1:20pm summary ----` block (average / lowest fps, seconds per verdict, most costly parts).
The top of the file lists the phone, Android version, GPU, screen, settings and a legend.

**Why it does not make the game lag:** the game thread only does relaxed atomic adds (`probe::scope`, `probe::count`) and, once a
second, hands one small record to a bounded channel with `try_send`. A full channel drops the record. The formatting, the file
IO and the `/proc` reads happen on `vs-log` at the lowest priority. Past 12 MB only summaries, hitches and events are written;
past 16 MB nothing more. When the setting is off nothing is measured and no file is made.

**Where the file goes:** Android 10+: `MediaStore.Downloads` through JNI (no permission). Older Android, or if MediaStore
refuses: `<storage>/Download` (needs the Storage permission, declared for Android 9 and older only), then `/sdcard/Download`,
then the app's own folder. Settings → Debug always says where the file really is. A panic is also written to the log
(and to `last_panic.txt` for the main menu) before the app dies.

## Ported

World generation (continents, rivers, lakes, swamps, mountains, climate biomes, caves, ores, trees, plants),
terrain meshing with ambient occlusion and biome-tinted grass/leaves, animated-height water, procedural clouds
and sky, fog, walking + creative flight, double-tap-jump flight, auto-jump, break / place, "laser" tunnel tool,
fluid simulation, hotbar + creative inventory, touch HUD (joystick, look pad, buttons), settings, world saving,
far-terrain LOD, greedy meshing, frustum and occlusion culling, the debug log.

## Not ported yet

* HUD customise mode (drag / resize buttons), break particles, creative-inventory search, a crash *share* screen
  (the main menu shows "VIEW LAST ERROR REPORT" after a panic; the debug log has the same information).
* The region packer (the renderer still uses one mesh per chunk column).
* Far terrain does not show trees, water waves or caves (it is a height field with one colour per cell), and it is not edited
  when you break blocks inside the detail radius (the real chunks cover that part anyway).

## Saves

`world.bin` in the app's private files directory: seed, player, hotbar and every *edited* chunk (run-length coded).
Untouched terrain is regenerated from the seed, and the far terrain is generated from the same seed. The format is new
(v15 saves are not readable).

## Diagnosing a problem on a phone

* **Lag:** the debug log (above). Send the `VoxelSandbox-log_….txt` file from Download.
* A panic anywhere is written to `last_panic.txt`; the main menu then shows "VIEW LAST ERROR REPORT".
* Shader compile errors are drawn on screen.
* CI prints the cargo output and the unit-test summary; on failure the cargo logs are uploaded with the reports.
