plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.netcontrol.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.netcontrol.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        // Only English strings are shipped; this also drops unused locale resources of dependencies.
        resourceConfigurations += listOf("en")
    }

    // Personal-use signing key committed with the project so every CI build has the same signature
    // and updates install over each other. Override with the NETCONTROL_* environment variables.
    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("NETCONTROL_KEYSTORE") ?: "signing/netcontrol-release.p12")
            storePassword = System.getenv("NETCONTROL_STORE_PASSWORD") ?: "netcontrol"
            keyAlias = System.getenv("NETCONTROL_KEY_ALIAS") ?: "netcontrol"
            keyPassword = System.getenv("NETCONTROL_KEY_PASSWORD") ?: "netcontrol"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }

    // Intentionally no per-ABI configuration: one universal APK. The app contains no native code.

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/*.version",
                "/META-INF/*.kotlin_module",
                "/META-INF/DEPENDENCIES",
                "/META-INF/INDEX.LIST",
                "/kotlin/**",
                "/kotlin-tooling-metadata.json",
                "/DebugProbesKt.bin"
            )
        }
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation(project(":engine"))

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

// Prints the release APK size and a content summary right after assembleRelease so the CI log
// carries the numbers (nothing is estimated: it reads the finished file).
tasks.register("reportApkSize") {
    doLast {
        val dir = layout.buildDirectory.dir("outputs/apk/release").get().asFile
        val apks = dir.listFiles { f -> f.extension == "apk" }
        if (apks == null || apks.isEmpty()) {
            println("NETCONTROL_APK_REPORT: no release APK found in $dir")
        } else {
            for (apk in apks) {
                val mb = String.format("%.2f", apk.length() / 1048576.0)
                println("NETCONTROL_APK_REPORT: ${apk.name} = ${apk.length()} bytes ($mb MB)")
                var native = 0
                var dexBytes = 0L
                java.util.zip.ZipFile(apk).use { zip ->
                    for (e in zip.entries().asSequence()) {
                        if (e.name.startsWith("lib/")) native++
                        if (e.name.endsWith(".dex")) dexBytes += e.compressedSize
                    }
                }
                println("NETCONTROL_APK_REPORT: native library entries (lib/) = $native (0 means no ABI-specific code), dex compressed = $dexBytes bytes")
            }
        }
    }
}

afterEvaluate {
    tasks.findByName("assembleRelease")?.finalizedBy("reportApkSize")
}
