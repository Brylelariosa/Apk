package dev.netcontrol.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.net.NetInfo
import dev.netcontrol.app.net.ProbeState
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.components.InfoRow
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard
import dev.netcontrol.app.ui.components.enforcementColor
import dev.netcontrol.app.ui.components.enforcementLabel
import dev.netcontrol.app.ui.components.yesNo
import dev.netcontrol.app.ui.theme.LocalStatusColors
import dev.netcontrol.app.vpn.Phase
import dev.netcontrol.engine.EventLog
import dev.netcontrol.engine.Transport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val stats by vm.engineStats.collectAsStateWithLifecycle()
    val events by vm.netEvents.collectAsStateWithLifecycle()
    val sc = LocalStatusColors.current
    val tfmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.buildReport()
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                Toast.makeText(ctx, if (ok) R.string.diag_saved else R.string.diag_save_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val uidByPkg = apps.associate { it.packageName to it.uid }
    val enforcementLevels = rules.map { (pkg, p) ->
        val uid = uidByPkg[pkg]
        pkg to EnforcementCalculator.levelFor(pkg, p, status, net, if (uid == null) null else stats?.perUid?.get(uid))
    }
    val failures = ArrayList<String>()
    status.error?.let { failures.add(it.kind.toString() + ": " + it.detail) }
    stats?.events?.filter { it.level >= EventLog.WARN }?.forEach {
        failures.add(tfmt.format(Date(it.atMs)) + " " + it.text)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.nav_diagnostics), null)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            SectionCard(stringResource(R.string.diag_service)) {
                InfoRow(
                    stringResource(R.string.diag_service_status),
                    stringResource(
                        when (status.phase) {
                            Phase.RUNNING -> R.string.status_running
                            Phase.STARTING -> R.string.status_starting
                            Phase.STOPPED -> R.string.status_stopped
                        }
                    ),
                    if (status.phase == Phase.RUNNING) sc.ok else sc.warn
                )
                InfoRow(stringResource(R.string.diag_inside), status.captured.size.toString())
                InfoRow(stringResource(R.string.diag_missing), status.missing.size.toString())
                InfoRow(stringResource(R.string.diag_ipv6_handling), yesNo(status.ipv6Active))
                InfoRow(stringResource(R.string.diag_other_vpn), yesNo(net.otherVpnActive))
                InfoRow(stringResource(R.string.diag_cell_requested), yesNo(net.cellularRequested))
                if (status.lastApplyMs != 0L) {
                    InfoRow(stringResource(R.string.detail_last_apply), tfmt.format(Date(status.lastApplyMs)))
                }
            }

            SectionCard(stringResource(R.string.dash_networks)) {
                NetworkBlock(stringResource(R.string.dash_wifi), net.wifi)
                NetworkBlock(stringResource(R.string.dash_cellular), net.cellular)
                InfoRow(stringResource(R.string.dash_default), defaultText(net.defaultNet))
            }

            SectionCard(stringResource(R.string.diag_routes)) {
                Text(
                    stringResource(R.string.diag_routes_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (status.probes.isEmpty()) {
                    Text(stringResource(R.string.diag_routes_none), style = MaterialTheme.typography.bodyMedium)
                }
                for (t in Transport.values()) {
                    val p = status.probes[t] ?: continue
                    InfoRow(
                        stringResource(if (t == Transport.WIFI) R.string.dash_wifi else R.string.dash_cellular),
                        "IPv4 " + probeText(p.v4) + ", IPv6 " + probeText(p.v6),
                        if (p.verified) sc.ok else sc.warn
                    )
                }
                OutlinedButton(onClick = { vm.runRouteCheck() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(painterResource(R.drawable.ic_refresh), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.action_run_check))
                }
            }

            SectionCard(stringResource(R.string.diag_dns)) {
                val s = stats
                if (s == null) {
                    Text(stringResource(R.string.diag_engine_off), style = MaterialTheme.typography.bodyMedium)
                } else {
                    InfoRow(stringResource(R.string.diag_dns_attributed), s.dnsAttributed.toString())
                    InfoRow(stringResource(R.string.diag_dns_unattributed), s.dnsUnattributed.toString())
                }
                Text(
                    stringResource(R.string.diag_dns_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            SectionCard(stringResource(R.string.diag_stack)) {
                InfoRow(
                    stringResource(R.string.dash_wifi),
                    "IPv4 " + yesNoText(net.wifi?.hasV4 == true) + ", IPv6 " + yesNoText(net.wifi?.hasV6 == true)
                )
                InfoRow(
                    stringResource(R.string.dash_cellular),
                    "IPv4 " + yesNoText(net.cellular?.hasV4 == true) + ", IPv6 " + yesNoText(net.cellular?.hasV6 == true)
                )
            }

            SectionCard(stringResource(R.string.diag_engine)) {
                val s = stats
                if (s == null) {
                    Text(stringResource(R.string.diag_engine_off), style = MaterialTheme.typography.bodyMedium)
                } else {
                    InfoRow(stringResource(R.string.diag_active_flows), s.activeTcp.toString() + " TCP, " + s.activeUdp.toString() + " UDP")
                    InfoRow(stringResource(R.string.diag_packets), s.packetsIn.toString() + " / " + s.packetsOut.toString())
                    InfoRow(stringResource(R.string.diag_blocked_flows), s.flowsBlocked.toString())
                    InfoRow(stringResource(R.string.diag_connect_failures), s.connectFailures.toString())
                    InfoRow(
                        stringResource(R.string.diag_violations),
                        s.violations.toString(),
                        if (s.violations > 0) sc.bad else Color.Unspecified
                    )
                    InfoRow(stringResource(R.string.diag_dropped), (s.unparsed + s.otherDropped + s.inboundDropped).toString())
                }
            }

            SectionCard(stringResource(R.string.diag_rules)) {
                if (enforcementLevels.isEmpty()) {
                    Text(stringResource(R.string.diag_none), style = MaterialTheme.typography.bodyMedium)
                }
                for ((pkg, level) in enforcementLevels) {
                    val policy = rules[pkg] ?: continue
                    InfoRow(pkg, enforcementLabel(level, policy), enforcementColor(level))
                }
            }

            SectionCard(stringResource(R.string.diag_changes)) {
                if (events.isEmpty()) Text(stringResource(R.string.diag_none), style = MaterialTheme.typography.bodyMedium)
                for (e in events.take(15)) {
                    Text(
                        tfmt.format(Date(e.atMs)) + "  " + e.text,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            SectionCard(stringResource(R.string.diag_failures)) {
                if (failures.isEmpty()) Text(stringResource(R.string.diag_none), style = MaterialTheme.typography.bodyMedium)
                for (f in failures.take(15)) {
                    Text(f, style = MaterialTheme.typography.bodySmall, color = sc.bad)
                }
            }

            SectionCard(stringResource(R.string.diag_report)) {
                Text(
                    stringResource(R.string.diag_report_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("NetControl report", vm.buildReport()))
                            Toast.makeText(ctx, R.string.diag_copied, Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(painterResource(R.drawable.ic_copy), null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.action_copy))
                    }
                    OutlinedButton(onClick = { saveLauncher.launch("netcontrol-report.txt") }, modifier = Modifier.weight(1f)) {
                        Icon(painterResource(R.drawable.ic_save), null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}

@Composable
private fun NetworkBlock(name: String, n: NetInfo?) {
    val sc = LocalStatusColors.current
    if (n == null) {
        InfoRow(name, stringResource(R.string.net_disconnected))
        return
    }
    InfoRow(
        name,
        stringResource(
            when {
                n.captivePortal -> R.string.net_captive
                n.validated -> R.string.net_validated
                else -> R.string.net_not_validated
            }
        ),
        if (n.validated && !n.captivePortal) sc.ok else sc.warn
    )
    InfoRow(stringResource(R.string.diag_metered), yesNo(n.metered))
    InfoRow(stringResource(R.string.diag_dns_servers), n.dns.size.toString())
}

@Composable
private fun probeText(s: ProbeState): String = stringResource(
    when (s) {
        ProbeState.OK -> R.string.probe_ok
        ProbeState.NO_ROUTE -> R.string.probe_no_route
        ProbeState.MISMATCH -> R.string.probe_mismatch
        ProbeState.UNKNOWN -> R.string.probe_unknown
        ProbeState.ERROR -> R.string.probe_error
    }
)

@Composable
private fun yesNoText(v: Boolean): String = stringResource(if (v) R.string.yes else R.string.no)
