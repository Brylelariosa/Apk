package dev.netcontrol.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.domain.EnforcementLevel
import dev.netcontrol.app.net.DefaultNet
import dev.netcontrol.app.net.NetInfo
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.ProtectionControl
import dev.netcontrol.app.ui.Routes
import dev.netcontrol.app.ui.components.InfoRow
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard
import dev.netcontrol.app.ui.components.StatusPill
import dev.netcontrol.app.ui.components.enforcementColor
import dev.netcontrol.app.ui.components.enforcementLabel
import dev.netcontrol.app.ui.theme.LocalStatusColors
import dev.netcontrol.app.vpn.ErrorKind
import dev.netcontrol.app.vpn.Phase
import dev.netcontrol.engine.Policy

@Composable
fun DashboardScreen(vm: MainViewModel, control: ProtectionControl, onNavigate: (String) -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val stats by vm.engineStats.collectAsStateWithLifecycle()
    val sc = LocalStatusColors.current
    val running = status.phase == Phase.RUNNING
    val starting = status.phase == Phase.STARTING

    val uidByPkg = remember(apps) { apps.associate { it.packageName to it.uid } }
    val visibleRules = if (apps.isEmpty()) rules else rules.filterKeys { uidByPkg.containsKey(it) }
    val levels = visibleRules.map { (pkg, p) ->
        val uid = uidByPkg[pkg]
        EnforcementCalculator.levelFor(pkg, p, status, net, if (uid == null) null else stats?.perUid?.get(uid))
    }
    val overall = EnforcementCalculator.overall(levels)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.app_name), null) {
            IconButton(onClick = { onNavigate(Routes.ABOUT) }) {
                Icon(painterResource(R.drawable.ic_info), stringResource(R.string.nav_about))
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            SectionCard(stringResource(R.string.dash_protection)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(
                            when {
                                running -> R.string.status_running
                                starting -> R.string.status_starting
                                else -> R.string.status_stopped
                            }
                        ),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )
                    StatusPill(
                        stringResource(if (running) R.string.pill_active else R.string.pill_inactive),
                        if (running) sc.ok else sc.warn
                    )
                }
                Text(
                    stringResource(if (running) R.string.dash_running_hint else R.string.dash_stopped_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val err = status.error
                if (err != null) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            stringResource(R.string.err_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = sc.bad
                        )
                        Text(errorMessage(err.kind), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            stringResource(R.string.err_next_step),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = { vm.clearError() }) { Text(stringResource(R.string.action_dismiss)) }
                    }
                } else if (settings.protectionEnabled && !running && !starting) {
                    Text(
                        stringResource(R.string.dash_unexpected_stop),
                        style = MaterialTheme.typography.bodyMedium,
                        color = sc.bad
                    )
                }
                if (running) {
                    OutlinedButton(onClick = { control.stop() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(painterResource(R.drawable.ic_power), null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.action_stop))
                    }
                } else {
                    Button(
                        onClick = { control.requestStart() },
                        enabled = !starting,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(painterResource(R.drawable.ic_power), null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            stringResource(
                                if (settings.protectionEnabled || status.error != null) R.string.action_restart
                                else R.string.action_start
                            )
                        )
                    }
                }
                if (!running && visibleRules.isNotEmpty()) {
                    Text(
                        stringResource(R.string.dash_rules_not_enforced),
                        style = MaterialTheme.typography.bodySmall,
                        color = sc.warn
                    )
                }
            }

            SectionCard(stringResource(R.string.dash_networks)) {
                InfoRow(stringResource(R.string.dash_wifi), wifiText(net.wifi), netColor(net.wifi, sc.ok, sc.warn))
                InfoRow(stringResource(R.string.dash_cellular), cellText(net.cellular), netColor(net.cellular, sc.ok, sc.warn))
                InfoRow(stringResource(R.string.dash_default), defaultText(net.defaultNet))
                InfoRow(
                    stringResource(R.string.dash_vpn),
                    stringResource(
                        when {
                            net.otherVpnActive -> R.string.vpn_other
                            running -> R.string.vpn_ours
                            else -> R.string.vpn_none
                        }
                    ),
                    if (net.otherVpnActive) sc.warn else Color.Unspecified
                )
            }

            SectionCard(stringResource(R.string.dash_rules)) {
                InfoRow(stringResource(R.string.dash_installed), apps.size.toString())
                InfoRow(stringResource(R.string.dash_custom), visibleRules.size.toString())
                InfoRow(
                    stringResource(R.string.dash_wifi_only),
                    visibleRules.values.count { it == Policy.WIFI_ONLY }.toString()
                )
                InfoRow(
                    stringResource(R.string.dash_mobile_only),
                    visibleRules.values.count { it == Policy.MOBILE_ONLY }.toString()
                )
                InfoRow(
                    stringResource(R.string.dash_blocked),
                    visibleRules.values.count { it == Policy.BLOCK }.toString()
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.dash_enforcement),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    val label = if (overall == EnforcementLevel.VERIFIED) {
                        stringResource(R.string.overall_enforced)
                    } else {
                        enforcementLabel(overall, Policy.WIFI_ONLY)
                    }
                    StatusPill(label, enforcementColor(overall))
                }
            }

            SectionCard(null) {
                NavRow(R.drawable.ic_apps, R.string.nav_apps) { onNavigate(Routes.APPS) }
                NavRow(R.drawable.ic_rules, R.string.nav_rules) { onNavigate(Routes.RULES) }
                NavRow(R.drawable.ic_chart, R.string.nav_diagnostics) { onNavigate(Routes.DIAGNOSTICS) }
                NavRow(R.drawable.ic_settings, R.string.nav_settings) { onNavigate(Routes.SETTINGS) }
                NavRow(R.drawable.ic_info, R.string.nav_about) { onNavigate(Routes.ABOUT) }
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}

@Composable
private fun NavRow(icon: Int, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(icon), null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(16.dp))
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Icon(painterResource(R.drawable.ic_chevron), null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun errorMessage(kind: ErrorKind): String = stringResource(
    when (kind) {
        ErrorKind.PERMISSION_DENIED -> R.string.err_permission
        ErrorKind.REVOKED -> R.string.err_revoked
        ErrorKind.ESTABLISH_FAILED -> R.string.err_establish
        ErrorKind.ENGINE_STOPPED -> R.string.err_engine
        ErrorKind.UNEXPECTED -> R.string.err_generic
    }
)

@Composable
private fun wifiText(n: NetInfo?): String = stringResource(
    when {
        n == null -> R.string.net_disconnected
        n.captivePortal -> R.string.net_captive
        n.validated -> R.string.net_validated
        else -> R.string.net_not_validated
    }
)

@Composable
private fun cellText(n: NetInfo?): String = stringResource(
    when {
        n == null -> R.string.net_unavailable
        n.validated -> R.string.net_available_validated
        else -> R.string.net_available_not_validated
    }
)

private fun netColor(n: NetInfo?, ok: Color, warn: Color): Color = when {
    n == null -> Color.Unspecified
    n.validated && !n.captivePortal -> ok
    else -> warn
}

@Composable
internal fun defaultText(d: DefaultNet): String = stringResource(
    when (d) {
        DefaultNet.NONE -> R.string.default_none
        DefaultNet.WIFI -> R.string.default_wifi
        DefaultNet.CELLULAR -> R.string.default_cell
        DefaultNet.VPN -> R.string.default_vpn
        DefaultNet.OTHER -> R.string.default_other
    }
)
