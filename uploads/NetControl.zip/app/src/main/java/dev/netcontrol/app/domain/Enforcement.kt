package dev.netcontrol.app.domain

import dev.netcontrol.app.net.NetSnapshot
import dev.netcontrol.app.vpn.Phase
import dev.netcontrol.app.vpn.ProtectionStatus
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.Transport
import dev.netcontrol.engine.UidStatsView

/**
 * How far a saved rule has actually been carried out. A saved rule is not a protected app:
 * "Protected" (VERIFIED) requires the tunnel to capture the app and the route to be confirmed.
 */
enum class EnforcementLevel {
    NO_RULE,
    SERVICE_STOPPED,
    APPLYING,
    MISSING,
    NETWORK_UNAVAILABLE,
    NOT_VERIFIED,
    VERIFIED,
    FAILURE;

    /** True when the rule is doing what it promises right now (blocking counts as enforcing). */
    val isEnforcing: Boolean get() = this == VERIFIED || this == NETWORK_UNAVAILABLE
}

object EnforcementCalculator {

    fun levelFor(
        pkg: String,
        policy: Policy,
        status: ProtectionStatus,
        net: NetSnapshot,
        stats: UidStatsView?
    ): EnforcementLevel {
        if (policy == Policy.AUTOMATIC) return EnforcementLevel.NO_RULE
        if (status.phase != Phase.RUNNING) return EnforcementLevel.SERVICE_STOPPED
        if (status.missing.contains(pkg)) return EnforcementLevel.MISSING
        if (!status.captured.contains(pkg)) return EnforcementLevel.APPLYING
        if (stats != null && stats.violations > 0) return EnforcementLevel.FAILURE
        return when (policy) {
            Policy.BLOCK -> EnforcementLevel.VERIFIED
            Policy.WIFI_ONLY -> routed(Transport.WIFI, net.wifi != null, status, stats)
            Policy.MOBILE_ONLY -> routed(Transport.CELLULAR, net.cellular != null, status, stats)
            Policy.AUTOMATIC -> EnforcementLevel.NO_RULE
        }
    }

    private fun routed(t: Transport, available: Boolean, status: ProtectionStatus, stats: UidStatsView?): EnforcementLevel {
        if (!available) return EnforcementLevel.NETWORK_UNAVAILABLE
        val probeOk = status.probes[t]?.verified == true
        val flowOk = stats != null && stats.verifiedFlows > 0
        return if (probeOk || flowOk) EnforcementLevel.VERIFIED else EnforcementLevel.NOT_VERIFIED
    }

    /** Dashboard summary over all saved rules. */
    fun overall(levels: Collection<EnforcementLevel>): EnforcementLevel {
        if (levels.isEmpty()) return EnforcementLevel.NO_RULE
        if (levels.contains(EnforcementLevel.FAILURE)) return EnforcementLevel.FAILURE
        if (levels.contains(EnforcementLevel.SERVICE_STOPPED)) return EnforcementLevel.SERVICE_STOPPED
        if (levels.contains(EnforcementLevel.APPLYING)) return EnforcementLevel.APPLYING
        if (levels.contains(EnforcementLevel.NOT_VERIFIED)) return EnforcementLevel.NOT_VERIFIED
        return EnforcementLevel.VERIFIED
    }
}
