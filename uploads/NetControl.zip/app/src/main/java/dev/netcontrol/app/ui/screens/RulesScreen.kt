package dev.netcontrol.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.components.AppIcon
import dev.netcontrol.app.ui.components.PolicyMenu
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard
import dev.netcontrol.app.ui.components.enforcementColor
import dev.netcontrol.app.ui.components.enforcementLabel
import dev.netcontrol.app.ui.components.policyDescription
import dev.netcontrol.app.ui.components.policyIconRes
import dev.netcontrol.app.ui.components.policyLabel
import dev.netcontrol.engine.Policy

@Composable
fun RulesScreen(vm: MainViewModel, onOpenApp: (String) -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val stats by vm.engineStats.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var confirmReset by remember { mutableStateOf(false) }

    val byPkg = remember(apps) { apps.associateBy { it.packageName } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.nav_rules), null)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            SectionCard(stringResource(R.string.rules_howto_title)) {
                for (p in Policy.values()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(painterResource(policyIconRes(p)), null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(policyLabel(p), style = MaterialTheme.typography.titleSmall)
                            Text(
                                policyDescription(p),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            val groups = listOf(Policy.WIFI_ONLY, Policy.MOBILE_ONLY, Policy.BLOCK)
            var any = false
            for (g in groups) {
                val members = rules.filterValues { it == g }.keys.sortedBy { byPkg[it]?.label?.lowercase() ?: it }
                if (members.isEmpty()) continue
                any = true
                SectionCard(policyLabel(g) + " (" + members.size + ")") {
                    for (pkg in members) {
                        val app = byPkg[pkg]
                        val uidStats = if (app == null) null else stats?.perUid?.get(app.uid)
                        val level = EnforcementCalculator.levelFor(pkg, g, status, net, uidStats)
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpenApp(pkg) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(pkg, 36.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    app?.label ?: pkg,
                                    style = MaterialTheme.typography.bodyLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    enforcementLabel(level, g),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = enforcementColor(level),
                                    maxLines = 1
                                )
                            }
                            IconButton(onClick = { vm.setPolicy(pkg, Policy.AUTOMATIC) }) {
                                Icon(painterResource(R.drawable.ic_close), stringResource(R.string.rules_remove))
                            }
                        }
                    }
                }
            }
            if (!any) {
                SectionCard(null) {
                    Text(
                        stringResource(R.string.rules_none),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionCard(stringResource(R.string.rules_default_title)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.rules_default_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    PolicyMenu(settings.defaultPolicy) { vm.setDefaultPolicy(it) }
                }
            }

            SectionCard(stringResource(R.string.rules_limits_title)) {
                Text(stringResource(R.string.rules_limits), style = MaterialTheme.typography.bodyMedium)
            }

            OutlinedButton(
                onClick = { confirmReset = true },
                enabled = rules.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(painterResource(R.drawable.ic_delete), null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.set_reset))
            }
            Spacer(Modifier.size(8.dp))
        }
    }

    if (confirmReset) {
        ResetDialog(onConfirm = {
            confirmReset = false
            vm.resetAllRules()
        }, onDismiss = { confirmReset = false })
    }
}

@Composable
internal fun ResetDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.reset_title)) },
        text = { Text(stringResource(R.string.reset_body)) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(stringResource(R.string.action_reset)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}
