package dev.netcontrol.app.ui

object Routes {
    const val DASHBOARD = "dashboard"
    const val APPS = "apps"
    const val RULES = "rules"
    const val DIAGNOSTICS = "diagnostics"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val PRIVACY = "privacy"
    const val DETAIL = "app/{pkg}"

    fun detail(pkg: String): String = "app/$pkg"
}
