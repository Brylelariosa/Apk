package dev.netcontrol.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import dev.netcontrol.app.data.ThemeMode

@Immutable
class StatusColors(val ok: Color, val warn: Color, val bad: Color, val info: Color)

private val DarkStatus = StatusColors(Color(0xFF5BD18B), Color(0xFFF2B84B), Color(0xFFFF7B72), Color(0xFF7AB8FF))
private val LightStatus = StatusColors(Color(0xFF1B7F45), Color(0xFF8A5A00), Color(0xFFB3261E), Color(0xFF1F5FA8))

val LocalStatusColors = staticCompositionLocalOf { DarkStatus }

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7AB8FF),
    onPrimary = Color(0xFF00243F),
    primaryContainer = Color(0xFF1B3A57),
    onPrimaryContainer = Color(0xFFD3E8FF),
    secondary = Color(0xFF86D5C6),
    onSecondary = Color(0xFF00352E),
    secondaryContainer = Color(0xFF1C3D38),
    onSecondaryContainer = Color(0xFFC4F1E8),
    background = Color(0xFF0E1215),
    onBackground = Color(0xFFE3E7EB),
    surface = Color(0xFF141A1F),
    onSurface = Color(0xFFE3E7EB),
    surfaceVariant = Color(0xFF1C242B),
    onSurfaceVariant = Color(0xFFA9B4BE),
    outline = Color(0xFF3A4651),
    outlineVariant = Color(0xFF2A333B),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3B0A06),
    errorContainer = Color(0xFF4A1612),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1F5FA8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD3E4FF),
    onPrimaryContainer = Color(0xFF001C38),
    secondary = Color(0xFF00695C),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFC4F1E8),
    onSecondaryContainer = Color(0xFF00201B),
    background = Color(0xFFF7F9FB),
    onBackground = Color(0xFF14181C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14181C),
    surfaceVariant = Color(0xFFE6EBF0),
    onSurfaceVariant = Color(0xFF46525D),
    outline = Color(0xFF76828D),
    outlineVariant = Color(0xFFC4CCD3),
    error = Color(0xFFB3261E),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B)
)

@Composable
fun NetControlTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val scheme = if (dark) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            window.navigationBarColor = scheme.background.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalStatusColors provides (if (dark) DarkStatus else LightStatus)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
