package dev.netcontrol.app.vpn

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import dev.netcontrol.app.Graph
import dev.netcontrol.app.MainActivity
import dev.netcontrol.app.R
import dev.netcontrol.app.data.Settings
import dev.netcontrol.app.net.AndroidSocketProvider
import dev.netcontrol.app.net.ConnectionOwnerResolver
import dev.netcontrol.app.net.NetSnapshot
import dev.netcontrol.app.net.ProbeResult
import dev.netcontrol.app.net.RouteProbe
import dev.netcontrol.engine.Addr
import dev.netcontrol.engine.Engine
import dev.netcontrol.engine.EngineConfig
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.RoutingTable
import dev.netcontrol.engine.Transport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Local VPN that captures only the applications that have a custom rule (addAllowedApplication).
 * Everything else, including NetControl itself, never enters the tunnel and keeps normal Android
 * networking. Captured traffic is handled by the user-space packet [Engine].
 */
class NetControlVpnService : VpnService() {

    private class Capture(
        val packages: List<String>,
        val uidPolicies: Map<Int, Policy>,
        val missing: Set<String>
    ) {
        companion object {
            val EMPTY = Capture(emptyList(), emptyMap(), emptySet())
        }
    }

    private class Inputs(val rules: Map<String, Policy>, val net: NetSnapshot, val settings: Settings)

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "netcontrol-service") }
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())

    private var tun: ParcelFileDescriptor? = null
    private var engine: Engine? = null
    private var provider: AndroidSocketProvider? = null
    private var observeJob: Job? = null
    private var capture: Capture = Capture.EMPTY
    private var capturedKey: List<String> = emptyList()
    private var ipv6Active = false
    private var foregroundStarted = false
    private var lastProbeIds: Pair<Long, Long> = Pair(-1L, -1L)
    private var receiverRegistered = false

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            scope.launch {
                try {
                    Graph.apps.applyDefaultPolicyToNew(Graph.apps.load())
                } catch (e: Exception) {
                    // best effort
                }
            }
        }
    }

    // ------------------------------------------------------------------ service callbacks

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                scope.launch { shutdown(true) }
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                scope.launch { reload() }
            }
            else -> {
                val fg: Boolean? = if (intent == null) null else intent.getBooleanExtra(EXTRA_FOREGROUND, true)
                if (fg == true) enterForeground(getString(R.string.notif_starting))
                scope.launch { startProtection(fg) }
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        // Another VPN app took over or the user revoked consent. Do not fight for the VPN slot.
        scope.launch { fail(ErrorKind.REVOKED, getString(R.string.err_revoked)) }
    }

    override fun onDestroy() {
        if (ProtectionState.status.value.phase != Phase.STOPPED) {
            stopAll(ProtectionError(ErrorKind.ENGINE_STOPPED, getString(R.string.err_service_destroyed)))
        } else {
            stopEngine()
        }
        scope.cancel()
        executor.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ lifecycle

    private suspend fun startProtection(fgRequested: Boolean?) {
        if (ProtectionState.status.value.phase == Phase.RUNNING && tun != null) {
            reload()
            return
        }
        ProtectionState.update { it.copy(phase = Phase.STARTING, error = null) }
        val settings = Graph.settings.flow.first()
        if (fgRequested == null && settings.persistentNotification) {
            enterForeground(getString(R.string.notif_starting))
        }
        if (VpnService.prepare(this) != null) {
            fail(ErrorKind.PERMISSION_DENIED, getString(R.string.err_permission))
            return
        }
        val rules = Graph.rules.rules.first()
        try {
            establishAndRun(rules, settings)
        } catch (e: Exception) {
            fail(ErrorKind.ESTABLISH_FAILED, e.message ?: e.javaClass.simpleName)
            return
        }
        Graph.settings.setProtectionEnabled(true)
        registerPackageReceiver()
        observeJob?.cancel()
        observeJob = scope.launch {
            combine(Graph.rules.rules, Graph.network.state, Graph.settings.flow) { r, n, s ->
                Inputs(r, n, s)
            }.collectLatest {
                delay(250)
                applyInputs(it)
            }
        }
    }

    /** Forces a rebuild of the tunnel from the saved rules ("Restore saved connection rules"). */
    private suspend fun reload() {
        if (ProtectionState.status.value.phase != Phase.RUNNING) {
            startProtection(null)
            return
        }
        val rules = Graph.rules.rules.first()
        val settings = Graph.settings.flow.first()
        try {
            establishAndRun(rules, settings)
        } catch (e: Exception) {
            fail(ErrorKind.ESTABLISH_FAILED, e.message ?: e.javaClass.simpleName)
        }
    }

    private suspend fun shutdown(userInitiated: Boolean) {
        stopAll(null)
        if (userInitiated) Graph.settings.setProtectionEnabled(false)
        stopSelf()
    }

    private suspend fun fail(kind: ErrorKind, detail: String) {
        stopAll(ProtectionError(kind, detail))
        if (kind == ErrorKind.PERMISSION_DENIED || kind == ErrorKind.REVOKED) {
            Graph.settings.setProtectionEnabled(false)
        }
        stopSelf()
    }

    @Synchronized
    private fun stopAll(error: ProtectionError?) {
        observeJob?.cancel()
        observeJob = null
        unregisterPackageReceiver()
        stopEngine()
        Graph.network.holdCellular(false)
        Graph.network.setOwnVpn(false)
        ProtectionState.update {
            it.copy(
                phase = Phase.STOPPED,
                error = error,
                captured = emptySet(),
                probes = emptyMap()
            )
        }
        leaveForeground()
    }

    @Synchronized
    private fun stopEngine() {
        val e = engine
        val t = tun
        engine = null
        tun = null
        provider = null
        Graph.engine = null
        if (e != null) {
            e.onTunnelClosed = null
            e.stop { t?.close() }
        } else {
            try {
                t?.close()
            } catch (x: IOException) {
                // ignore
            }
        }
    }

    // ------------------------------------------------------------------ tunnel + engine

    private fun computeCapture(rules: Map<String, Policy>): Capture {
        val pm = packageManager
        val pkgs = ArrayList<String>()
        val uidMap = HashMap<Int, Policy>()
        val missing = HashSet<String>()
        for ((pkg, policy) in rules) {
            if (policy == Policy.AUTOMATIC || pkg == packageName) continue
            val uid: Int = try {
                pm.getApplicationInfo(pkg, 0).uid
            } catch (e: PackageManager.NameNotFoundException) {
                missing.add(pkg)
                continue
            }
            if (uid < RoutingTable.FIRST_APP_UID) continue
            pkgs.add(pkg)
            val prev = uidMap[uid]
            if (prev == null || weight(policy) > weight(prev)) uidMap[uid] = policy
        }
        pkgs.sort()
        return Capture(pkgs, uidMap, missing)
    }

    private fun weight(p: Policy): Int = when (p) {
        Policy.BLOCK -> 3
        Policy.AUTOMATIC -> 0
        else -> 2
    }

    private fun buildTunnel(cap: Capture, ipv6: Boolean): ParcelFileDescriptor? {
        val b = Builder()
            .setSession(getString(R.string.app_name))
            .setMtu(MTU)
            .setBlocking(true)
            .setMetered(false)
            .addAddress(V4_ADDR, 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(V4_DNS)
        if (ipv6) {
            b.addAddress(V6_ADDR, 128)
            b.addRoute("::", 0)
            b.addDnsServer(V6_DNS)
        }
        b.setConfigureIntent(
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        var added = 0
        for (pkg in cap.packages) {
            try {
                b.addAllowedApplication(pkg)
                added++
            } catch (e: PackageManager.NameNotFoundException) {
                // vanished between the scan and now; skipped
            }
        }
        // An empty allowed list would capture every app, so keep the tunnel valid but idle instead.
        if (added == 0) b.addAllowedApplication(packageName)
        return b.establish()
    }

    private fun establishAndRun(rules: Map<String, Policy>, settings: Settings) {
        val cap = computeCapture(rules)
        val pfd = buildTunnel(cap, settings.ipv6)
            ?: throw IllegalStateException(getString(R.string.err_establish_null))
        val prov = AndroidSocketProvider(this)
        val dns6: Addr? = if (settings.ipv6) Addr.of(InetAddress.getByName(V6_DNS)) else null
        val eng = Engine(
            EngineConfig(MTU, Addr.v4(198, 18, 0, 2), dns6, settings.ipv6),
            FileInputStream(pfd.fileDescriptor),
            FileOutputStream(pfd.fileDescriptor),
            prov,
            ConnectionOwnerResolver(this)
        )
        eng.onTunnelClosed = { reason ->
            scope.launch {
                if (engine === eng) fail(ErrorKind.ENGINE_STOPPED, reason)
            }
        }
        val oldEngine = engine
        val oldTun = tun
        engine = eng
        tun = pfd
        provider = prov
        capture = cap
        capturedKey = cap.packages
        ipv6Active = settings.ipv6
        if (oldEngine != null) {
            oldEngine.onTunnelClosed = null
            oldEngine.stop { oldTun?.close() }
        } else {
            oldTun?.close()
        }
        eng.start()
        Graph.engine = eng
        Graph.network.setOwnVpn(true)
        lastProbeIds = Pair(-1L, -1L)
        pushRouting(cap)
        val now = System.currentTimeMillis()
        ProtectionState.update {
            it.copy(
                phase = Phase.RUNNING,
                sinceMs = if (it.phase == Phase.RUNNING && it.sinceMs != 0L) it.sinceMs else now,
                captured = cap.packages.toSet(),
                missing = cap.missing,
                error = null,
                lastApplyMs = now,
                lastApplyOk = true,
                ipv6Active = settings.ipv6
            )
        }
        updateNotification()
        runProbes()
    }

    private suspend fun applyInputs(i: Inputs) {
        if (ProtectionState.status.value.phase != Phase.RUNNING) return
        if (i.settings.persistentNotification && !foregroundStarted) {
            enterForeground(getString(R.string.notif_starting))
        } else if (!i.settings.persistentNotification && foregroundStarted) {
            leaveForeground()
        }
        val cap = computeCapture(i.rules)
        if (cap.packages != capturedKey || i.settings.ipv6 != ipv6Active) {
            try {
                establishAndRun(i.rules, i.settings)
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                // Launched separately: fail() cancels the observer job this code runs in.
                scope.launch { fail(ErrorKind.ESTABLISH_FAILED, msg) }
            }
            return
        }
        capture = cap
        pushRouting(cap)
        ProtectionState.update {
            it.copy(missing = cap.missing, lastApplyMs = System.currentTimeMillis(), lastApplyOk = true)
        }
        updateNotification()
        runProbes()
    }

    /** Hands the current rules and the currently available networks to the engine. */
    private fun pushRouting(cap: Capture) {
        val net = Graph.network.state.value
        val wifi = net.wifi
        val cell = net.cellular
        val table = RoutingTable(cap.uidPolicies, wifi?.toUplink(), cell?.toUplink(), net.defaultTransport)
        engine?.updateRouting(table)
        val needWifi = cap.uidPolicies.values.any { it == Policy.WIFI_ONLY }
        val needCell = cap.uidPolicies.values.any { it == Policy.MOBILE_ONLY }
        Graph.network.holdCellular(needCell)
        try {
            if (needWifi || needCell) {
                val under = ArrayList<Network>()
                if (needWifi && wifi != null) under.add(wifi.network)
                if (needCell && cell != null) under.add(cell.network)
                setUnderlyingNetworks(under.toTypedArray())
            } else {
                setUnderlyingNetworks(null)
            }
        } catch (e: RuntimeException) {
            // cosmetic: only affects how apps perceive metered state
        }
    }

    private fun runProbes() {
        val prov = provider ?: return
        val net = Graph.network.state.value
        val ids = Pair(net.wifi?.network?.networkHandle ?: 0L, net.cellular?.network?.networkHandle ?: 0L)
        if (ids == lastProbeIds) return
        lastProbeIds = ids
        val w = net.wifi?.toUplink()
        val c = net.cellular?.toUplink()
        val results = HashMap<Transport, ProbeResult>()
        if (w != null) results[Transport.WIFI] = RouteProbe.run(prov, w, c)
        if (c != null) results[Transport.CELLULAR] = RouteProbe.run(prov, c, w)
        ProtectionState.update { it.copy(probes = results) }
    }

    // ------------------------------------------------------------------ foreground + receiver

    private fun enterForeground(text: String) {
        try {
            val n = Notifications.build(this, text)
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(
                    this, Notifications.ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(Notifications.ID, n)
            }
            foregroundStarted = true
        } catch (e: RuntimeException) {
            // Android may refuse a foreground start from the background; the VPN still runs.
            foregroundStarted = false
        }
    }

    private fun leaveForeground() {
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
    }

    private fun updateNotification() {
        if (!foregroundStarted) return
        val n = capture.packages.size
        Notifications.notify(this, resources.getQuantityString(R.plurals.notif_running, n, n))
    }

    private fun registerPackageReceiver() {
        if (receiverRegistered) return
        val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED)
        f.addDataScheme("package")
        ContextCompat.registerReceiver(this, packageReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    private fun unregisterPackageReceiver() {
        if (!receiverRegistered) return
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: IllegalArgumentException) {
            // not registered
        }
        receiverRegistered = false
    }

    companion object {
        const val ACTION_START = "dev.netcontrol.app.action.START"
        const val ACTION_STOP = "dev.netcontrol.app.action.STOP"
        const val ACTION_RELOAD = "dev.netcontrol.app.action.RELOAD"
        const val EXTRA_FOREGROUND = "foreground"
        const val MTU = 1500

        private const val V4_ADDR = "198.18.0.1"
        private const val V4_DNS = "198.18.0.2"
        private const val V6_ADDR = "fd6e:6574:636f:6e74::1"
        private const val V6_DNS = "fd6e:6574:636f:6e74::2"

        fun start(ctx: Context, foreground: Boolean) {
            val i = Intent(ctx, NetControlVpnService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_FOREGROUND, foreground)
            if (foreground) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, NetControlVpnService::class.java).setAction(ACTION_STOP))
        }

        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, NetControlVpnService::class.java).setAction(ACTION_RELOAD))
        }
    }
}
