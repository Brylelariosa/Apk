package dev.netcontrol.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkAddress
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import dev.netcontrol.engine.Addr
import dev.netcontrol.engine.Transport
import dev.netcontrol.engine.Uplink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.Inet4Address
import java.net.Inet6Address

enum class DefaultNet { NONE, WIFI, CELLULAR, VPN, OTHER }

/** One usable physical network (Wi-Fi or cellular with the INTERNET capability). */
data class NetInfo(
    val network: Network,
    val transport: Transport,
    val validated: Boolean,
    val captivePortal: Boolean,
    val metered: Boolean,
    val iface: String?,
    val addrs: Set<Addr>,
    val dns: List<Addr>,
    val hasV4: Boolean,
    val hasV6: Boolean
) {
    fun toUplink(): Uplink = Uplink(network.networkHandle, transport, dns, addrs, network)
}

data class NetSnapshot(
    val wifi: NetInfo? = null,
    val cellular: NetInfo? = null,
    val defaultNet: DefaultNet = DefaultNet.NONE,
    val vpnCount: Int = 0,
    val ownVpnRunning: Boolean = false,
    val cellularRequested: Boolean = false
) {
    val otherVpnActive: Boolean get() = vpnCount > (if (ownVpnRunning) 1 else 0)

    val defaultTransport: Transport?
        get() = when (defaultNet) {
            DefaultNet.WIFI -> Transport.WIFI
            DefaultNet.CELLULAR -> Transport.CELLULAR
            else -> null
        }
}

data class NetEvent(val atMs: Long, val text: String)

/**
 * Event-driven view of the device's networks (no polling). Callbacks are registered once for the
 * lifetime of the process; the cellular network is only explicitly requested while protection needs it.
 */
class NetworkMonitor(ctx: Context) {
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val lock = Any()

    private class Entry {
        var caps: NetworkCapabilities? = null
        var lp: LinkProperties? = null
    }

    private val nets = LinkedHashMap<Network, Entry>()
    private val vpnNets = LinkedHashSet<Network>()
    private var defaultNet = DefaultNet.NONE
    private var ownVpn = false
    private var cellCb: ConnectivityManager.NetworkCallback? = null
    private var started = false

    private val stateFlow = MutableStateFlow(NetSnapshot())
    val state: StateFlow<NetSnapshot> = stateFlow.asStateFlow()

    private val eventsFlow = MutableStateFlow<List<NetEvent>>(emptyList())
    val events: StateFlow<List<NetEvent>> = eventsFlow.asStateFlow()

    private val physicalCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            synchronized(lock) { nets.getOrPut(network) { Entry() } }
            recompute()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            synchronized(lock) { nets.getOrPut(network) { Entry() }.caps = networkCapabilities }
            recompute()
        }

        override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
            synchronized(lock) { nets.getOrPut(network) { Entry() }.lp = linkProperties }
            recompute()
        }

        override fun onLost(network: Network) {
            synchronized(lock) { nets.remove(network) }
            recompute()
        }
    }

    private val defaultCb = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            val d = when {
                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> DefaultNet.VPN
                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> DefaultNet.WIFI
                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> DefaultNet.CELLULAR
                else -> DefaultNet.OTHER
            }
            synchronized(lock) { defaultNet = d }
            recompute()
        }

        override fun onLost(network: Network) {
            synchronized(lock) { defaultNet = DefaultNet.NONE }
            recompute()
        }
    }

    private val vpnCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            synchronized(lock) { vpnNets.add(network) }
            recompute()
        }

        override fun onLost(network: Network) {
            synchronized(lock) { vpnNets.remove(network) }
            recompute()
        }
    }

    fun start() {
        synchronized(lock) {
            if (started) return
            started = true
        }
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                physicalCb
            )
            cm.registerDefaultNetworkCallback(defaultCb)
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(),
                vpnCb
            )
        } catch (e: RuntimeException) {
            addEvent("Network monitoring could not start: " + e.javaClass.simpleName)
        }
    }

    /** Called by the VPN service so the monitor can tell NetControl's own VPN from another VPN app. */
    fun setOwnVpn(running: Boolean) {
        synchronized(lock) { ownVpn = running }
        recompute()
    }

    /**
     * Keeps the cellular network requested (so Android does not tear it down while Wi-Fi is the
     * default network). Only needed while at least one app is set to Mobile Data Only.
     */
    fun holdCellular(hold: Boolean) {
        var changed = false
        synchronized(lock) {
            if (hold && cellCb == null) {
                val cb = object : ConnectivityManager.NetworkCallback() {}
                try {
                    cm.requestNetwork(
                        NetworkRequest.Builder()
                            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                            .build(),
                        cb
                    )
                    cellCb = cb
                    changed = true
                } catch (e: RuntimeException) {
                    addEvent("Cellular request failed: " + e.javaClass.simpleName)
                }
            } else if (!hold && cellCb != null) {
                try {
                    cm.unregisterNetworkCallback(cellCb!!)
                } catch (e: RuntimeException) {
                    // already unregistered
                }
                cellCb = null
                changed = true
            }
        }
        if (changed) recompute()
    }

    private fun better(a: NetInfo, b: NetInfo): Boolean = a.validated && !b.validated

    private fun toInfo(net: Network, t: Transport, caps: NetworkCapabilities, lp: LinkProperties): NetInfo {
        val addrs = HashSet<Addr>()
        var v4 = false
        var v6 = false
        fun scan(list: List<LinkAddress>) {
            for (la in list) {
                val a = la.address
                addrs.add(Addr.of(a))
                if (a is Inet4Address) {
                    if (!a.isLinkLocalAddress) v4 = true
                } else if (a is Inet6Address) {
                    if (!a.isLinkLocalAddress && !a.isLoopbackAddress) v6 = true
                }
            }
        }
        scan(lp.linkAddresses)
        for (s in lp.stackedLinks) scan(s.linkAddresses)
        val dns = ArrayList<Addr>()
        for (d in lp.dnsServers) {
            if (d is Inet6Address && d.isLinkLocalAddress) continue
            dns.add(Addr.of(d))
        }
        return NetInfo(
            net, t,
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL),
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED),
            lp.interfaceName, addrs, dns, v4, v6
        )
    }

    private fun recompute() {
        val snap = synchronized(lock) {
            var wifi: NetInfo? = null
            var cell: NetInfo? = null
            for ((net, e) in nets) {
                val caps = e.caps ?: continue
                val lp = e.lp ?: continue
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                val t = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Transport.WIFI
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Transport.CELLULAR
                    else -> continue
                }
                val info = toInfo(net, t, caps, lp)
                if (t == Transport.WIFI) {
                    val cur = wifi
                    if (cur == null || better(info, cur)) wifi = info
                } else {
                    val cur = cell
                    if (cur == null || better(info, cur)) cell = info
                }
            }
            NetSnapshot(wifi, cell, defaultNet, vpnNets.size, ownVpn, cellCb != null)
        }
        val old = stateFlow.value
        if (snap != old) {
            val lines = describe(old, snap)
            stateFlow.value = snap
            for (l in lines) addEvent(l)
        }
    }

    private fun describe(old: NetSnapshot, new: NetSnapshot): List<String> {
        val out = ArrayList<String>()
        fun side(name: String, o: NetInfo?, n: NetInfo?) {
            if (o == null && n != null) {
                out.add(name + " connected" + (if (n.validated) " (validated)" else " (not validated)"))
            } else if (o != null && n == null) {
                out.add(name + " disconnected")
            } else if (o != null && n != null) {
                if (o.network != n.network) {
                    out.add(name + " network changed")
                } else if (o.validated != n.validated) {
                    out.add(name + (if (n.validated) " validated" else " validation lost"))
                }
            }
        }
        side("Wi-Fi", old.wifi, new.wifi)
        side("Cellular", old.cellular, new.cellular)
        if (old.defaultNet != new.defaultNet) out.add("Default network: " + new.defaultNet)
        if (old.vpnCount != new.vpnCount) out.add("VPN networks present: " + new.vpnCount)
        if (old.cellularRequested != new.cellularRequested) {
            out.add(if (new.cellularRequested) "Cellular network requested" else "Cellular request released")
        }
        return out
    }

    private fun addEvent(text: String) {
        synchronized(lock) {
            val list = ArrayList<NetEvent>(eventsFlow.value)
            list.add(0, NetEvent(System.currentTimeMillis(), text))
            while (list.size > 40) list.removeAt(list.size - 1)
            eventsFlow.value = list
        }
    }
}
