package dev.netcontrol.app.diag

import android.content.Context
import android.os.Build
import dev.netcontrol.app.Graph
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.net.NetInfo
import dev.netcontrol.app.vpn.ProtectionStatus
import dev.netcontrol.engine.EngineSnapshot
import dev.netcontrol.engine.Policy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Plain-text diagnostic report. It contains network state, rule names (package names only) and
 * counters. It never contains browsing history, hostnames, addresses of remote servers, credentials
 * or packet contents.
 */
object ReportBuilder {

    fun build(ctx: Context, rules: Map<String, Policy>, status: ProtectionStatus, engine: EngineSnapshot?): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val tfmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        val net = Graph.network.state.value
        val sb = StringBuilder()
        val version = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }

        sb.append("NetControl diagnostic report\n")
        sb.append("Generated: ").append(fmt.format(Date())).append('\n')
        sb.append("App version: ").append(version).append('\n')
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")

        sb.append("[Service]\n")
        sb.append("Phase: ").append(status.phase).append('\n')
        if (status.sinceMs != 0L) sb.append("Running since: ").append(fmt.format(Date(status.sinceMs))).append('\n')
        sb.append("Apps inside the tunnel: ").append(status.captured.size).append('\n')
        sb.append("Rules for apps that are not installed: ").append(status.missing.size).append('\n')
        sb.append("IPv6 handling: ").append(if (status.ipv6Active) "on" else "off").append('\n')
        val err = status.error
        sb.append("Last error: ").append(if (err == null) "none" else err.kind.toString() + " - " + err.detail).append('\n')
        if (status.lastApplyMs != 0L) {
            sb.append("Rules last applied: ").append(tfmt.format(Date(status.lastApplyMs))).append('\n')
        }
        sb.append('\n')

        sb.append("[Networks]\n")
        netLine(sb, "Wi-Fi", net.wifi)
        netLine(sb, "Cellular", net.cellular)
        sb.append("Default network: ").append(net.defaultNet).append('\n')
        sb.append("Other VPN active: ").append(if (net.otherVpnActive) "yes" else "no").append('\n')
        sb.append("Cellular network requested by NetControl: ").append(if (net.cellularRequested) "yes" else "no").append('\n')
        sb.append('\n')

        sb.append("[Route verification] (bound-socket source address, no packets sent)\n")
        if (status.probes.isEmpty()) {
            sb.append("not run\n")
        } else {
            for ((t, p) in status.probes) {
                sb.append(t).append(": IPv4=").append(p.v4).append(" IPv6=").append(p.v6)
                    .append(" at ").append(tfmt.format(Date(p.atMs))).append('\n')
            }
        }
        sb.append('\n')

        sb.append("[Engine]\n")
        if (engine == null) {
            sb.append("not running\n")
        } else {
            sb.append("Uptime ms: ").append(engine.uptimeMs).append('\n')
            sb.append("Active TCP flows: ").append(engine.activeTcp).append(", UDP flows: ").append(engine.activeUdp).append('\n')
            sb.append("Packets in/out: ").append(engine.packetsIn).append('/').append(engine.packetsOut).append('\n')
            sb.append("Flows blocked: ").append(engine.flowsBlocked).append('\n')
            sb.append("Connect failures: ").append(engine.connectFailures).append('\n')
            sb.append("Route violations: ").append(engine.violations).append('\n')
            sb.append("Unparsed packets: ").append(engine.unparsed).append(", non TCP/UDP dropped: ").append(engine.otherDropped)
                .append(", queue overflow: ").append(engine.inboundDropped).append('\n')
            sb.append("DNS queries attributed to an app rule: ").append(engine.dnsAttributed)
                .append(", not attributable: ").append(engine.dnsUnattributed).append('\n')
        }
        sb.append('\n')

        sb.append("[Rules] (package = policy, enforcement)\n")
        if (rules.isEmpty()) sb.append("none\n")
        for ((pkg, policy) in rules) {
            val uid = Graph.apps.uidOf(pkg)
            val stats = if (uid != null) engine?.perUid?.get(uid) else null
            val level = EnforcementCalculator.levelFor(pkg, policy, status, net, stats)
            sb.append(pkg).append(" = ").append(policy).append(", ").append(level)
            if (stats != null) {
                sb.append(" (flows wifi/cell/blocked: ").append(stats.routedWifi).append('/').append(stats.routedCellular)
                    .append('/').append(stats.blocked).append(')')
            }
            sb.append('\n')
        }
        sb.append('\n')

        sb.append("[Recent network changes]\n")
        val events = Graph.network.events.value
        if (events.isEmpty()) sb.append("none\n")
        for (e in events) sb.append(tfmt.format(Date(e.atMs))).append(' ').append(e.text).append('\n')
        sb.append('\n')

        sb.append("[Recent engine events]\n")
        val ee = engine?.events ?: emptyList()
        if (ee.isEmpty()) sb.append("none\n")
        for (e in ee) sb.append(tfmt.format(Date(e.atMs))).append(' ').append(e.text).append('\n')
        return sb.toString()
    }

    private fun netLine(sb: StringBuilder, name: String, n: NetInfo?) {
        if (n == null) {
            sb.append(name).append(": not connected\n")
            return
        }
        sb.append(name).append(": connected, validated=").append(if (n.validated) "yes" else "no")
            .append(", captive portal=").append(if (n.captivePortal) "yes" else "no")
            .append(", metered=").append(if (n.metered) "yes" else "no")
            .append(", IPv4=").append(if (n.hasV4) "yes" else "no")
            .append(", IPv6=").append(if (n.hasV6) "yes" else "no")
            .append(", DNS servers=").append(n.dns.size).append('\n')
    }
}
