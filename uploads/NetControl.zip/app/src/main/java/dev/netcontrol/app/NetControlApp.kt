package dev.netcontrol.app

import android.app.Application

class NetControlApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}
