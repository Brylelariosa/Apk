package dev.netcontrol.app.vpn

import dev.netcontrol.app.net.ProbeResult
import dev.netcontrol.engine.Transport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Phase { STOPPED, STARTING, RUNNING }

enum class ErrorKind { PERMISSION_DENIED, REVOKED, ESTABLISH_FAILED, ENGINE_STOPPED, UNEXPECTED }

data class ProtectionError(val kind: ErrorKind, val detail: String)

data class ProtectionStatus(
    val phase: Phase = Phase.STOPPED,
    val sinceMs: Long = 0L,
    /** Packages currently inside the VPN capture set (rule applied at the OS level). */
    val captured: Set<String> = emptySet(),
    /** Packages with a rule that are not installed. */
    val missing: Set<String> = emptySet(),
    val error: ProtectionError? = null,
    val lastApplyMs: Long = 0L,
    val lastApplyOk: Boolean = true,
    val probes: Map<Transport, ProbeResult> = emptyMap(),
    val ipv6Active: Boolean = false
)

/** Observable state of the network-control service, shared with the UI. */
object ProtectionState {
    private val flow = MutableStateFlow(ProtectionStatus())
    val status: StateFlow<ProtectionStatus> = flow.asStateFlow()

    fun update(f: (ProtectionStatus) -> ProtectionStatus) {
        flow.update(f)
    }
}
