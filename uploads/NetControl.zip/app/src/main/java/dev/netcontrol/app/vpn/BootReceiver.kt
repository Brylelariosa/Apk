package dev.netcontrol.app.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import dev.netcontrol.app.Graph
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Restores protection after a reboot, only if the user left it enabled and VPN consent still exists. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val s = Graph.settings.flow.first()
                if (s.protectionEnabled && VpnService.prepare(context) == null) {
                    // Always start as a foreground service at boot; the service drops the
                    // notification again if the user disabled it in settings.
                    NetControlVpnService.start(context, true)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
