package dev.netcontrol.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import dev.netcontrol.engine.Addr
import dev.netcontrol.engine.SocketProvider
import dev.netcontrol.engine.Transport
import dev.netcontrol.engine.UidResolver
import dev.netcontrol.engine.Uplink
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.channels.DatagramChannel
import java.nio.channels.SocketChannel

/**
 * Creates sockets bound to a specific physical network with Network.bindSocket(). The VPN service
 * (when present) additionally protects them so they can never be routed back into the tunnel.
 */
class AndroidSocketProvider(private val vpn: VpnService?) : SocketProvider {

    private fun networkOf(u: Uplink): Network =
        (u.handle as? Network) ?: throw IOException("Uplink has no Android network handle")

    override fun openTcp(uplink: Uplink): SocketChannel {
        val net = networkOf(uplink)
        val ch = SocketChannel.open()
        try {
            net.bindSocket(ch.socket())
            vpn?.protect(ch.socket())
            return ch
        } catch (e: Exception) {
            try {
                ch.close()
            } catch (x: IOException) {
                // ignore
            }
            throw IOException("Cannot bind socket to " + uplink.transport + ": " + e.message)
        }
    }

    override fun openUdp(uplink: Uplink): DatagramChannel {
        val net = networkOf(uplink)
        val ch = DatagramChannel.open()
        try {
            net.bindSocket(ch.socket())
            vpn?.protect(ch.socket())
            return ch
        } catch (e: Exception) {
            try {
                ch.close()
            } catch (x: IOException) {
                // ignore
            }
            throw IOException("Cannot bind socket to " + uplink.transport + ": " + e.message)
        }
    }
}

/** Resolves which UID owns a tunnel flow (only works for the currently active VPN app). */
class ConnectionOwnerResolver(ctx: Context) : UidResolver {
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    override fun uidOf(protocol: Int, local: InetSocketAddress, remote: InetSocketAddress): Int {
        return try {
            cm.getConnectionOwnerUid(protocol, local, remote)
        } catch (e: SecurityException) {
            -1
        } catch (e: RuntimeException) {
            -1
        }
    }
}

enum class ProbeState { OK, NO_ROUTE, MISMATCH, UNKNOWN, ERROR }

data class ProbeResult(val transport: Transport, val v4: ProbeState, val v6: ProbeState, val atMs: Long) {
    /** The bound socket really used this network's address, and never the other network's. */
    val verified: Boolean
        get() = (v4 == ProbeState.OK || v6 == ProbeState.OK) &&
            v4 != ProbeState.MISMATCH && v6 != ProbeState.MISMATCH
}

/**
 * Route self-test. A UDP socket is bound to the uplink and "connected" to a public address: this only
 * performs a routing lookup, no packet is sent. The kernel-selected source address tells which
 * interface the route uses.
 */
object RouteProbe {
    fun run(provider: SocketProvider, uplink: Uplink, other: Uplink?): ProbeResult {
        val v4 = one(provider, uplink, other, "1.1.1.1")
        val v6 = one(provider, uplink, other, "2606:4700:4700::1111")
        return ProbeResult(uplink.transport, v4, v6, System.currentTimeMillis())
    }

    private fun one(provider: SocketProvider, uplink: Uplink, other: Uplink?, target: String): ProbeState {
        var ch: DatagramChannel? = null
        try {
            val c = provider.openUdp(uplink)
            ch = c
            c.connect(InetSocketAddress(InetAddress.getByName(target), 53))
            val local = c.socket().localAddress ?: return ProbeState.ERROR
            val a = Addr.of(local)
            if (other != null && other.addresses.contains(a)) return ProbeState.MISMATCH
            if (uplink.addresses.contains(a)) return ProbeState.OK
            return ProbeState.UNKNOWN
        } catch (e: IOException) {
            val m = (e.message ?: "").lowercase()
            return if (e is java.net.NoRouteToHostException || m.contains("unreachable") || m.contains("no route")) {
                ProbeState.NO_ROUTE
            } else {
                ProbeState.ERROR
            }
        } finally {
            try {
                ch?.close()
            } catch (e: IOException) {
                // ignore
            }
        }
    }
}
