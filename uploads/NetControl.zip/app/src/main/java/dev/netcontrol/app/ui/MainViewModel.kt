package dev.netcontrol.app.ui

import android.app.Application
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.netcontrol.app.Graph
import dev.netcontrol.app.data.AppEntry
import dev.netcontrol.app.data.Settings
import dev.netcontrol.app.data.ThemeMode
import dev.netcontrol.app.diag.ReportBuilder
import dev.netcontrol.app.net.AndroidSocketProvider
import dev.netcontrol.app.net.NetEvent
import dev.netcontrol.app.net.NetSnapshot
import dev.netcontrol.app.net.ProbeResult
import dev.netcontrol.app.net.RouteProbe
import dev.netcontrol.app.vpn.ErrorKind
import dev.netcontrol.app.vpn.NetControlVpnService
import dev.netcontrol.app.vpn.Phase
import dev.netcontrol.app.vpn.ProtectionError
import dev.netcontrol.app.vpn.ProtectionState
import dev.netcontrol.app.vpn.ProtectionStatus
import dev.netcontrol.engine.EngineSnapshot
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.Transport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val appsFlow = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = appsFlow.asStateFlow()

    private val loadingFlow = MutableStateFlow(true)
    val appsLoading: StateFlow<Boolean> = loadingFlow.asStateFlow()

    val rules: StateFlow<Map<String, Policy>> =
        Graph.rules.rules.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
    val settings: StateFlow<Settings> =
        Graph.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val net: StateFlow<NetSnapshot> = Graph.network.state
    val netEvents: StateFlow<List<NetEvent>> = Graph.network.events
    val status: StateFlow<ProtectionStatus> = ProtectionState.status

    /** Engine counters, polled once per second and only while a screen is actually collecting them. */
    val engineStats: StateFlow<EngineSnapshot?> = flow {
        while (true) {
            emit(Graph.engine?.snapshot())
            delay(1000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private var restoreTried = false

    init {
        refreshApps()
    }

    private fun appContext(): Application = getApplication<Application>()

    fun refreshApps() {
        viewModelScope.launch {
            loadingFlow.value = true
            val list = try {
                Graph.apps.load()
            } catch (e: Exception) {
                emptyList()
            }
            try {
                Graph.apps.applyDefaultPolicyToNew(list)
            } catch (e: Exception) {
                // default-policy handling is best effort
            }
            appsFlow.value = list
            loadingFlow.value = false
        }
    }

    fun setPolicy(pkg: String, p: Policy) {
        viewModelScope.launch { Graph.rules.set(pkg, p) }
    }

    fun resetAllRules() {
        viewModelScope.launch { Graph.rules.clear() }
    }

    fun markExplained() {
        viewModelScope.launch { Graph.settings.setVpnExplained(true) }
    }

    fun setDefaultPolicy(p: Policy) {
        viewModelScope.launch { Graph.settings.setDefaultPolicy(p) }
    }

    fun setPersistentNotification(v: Boolean) {
        viewModelScope.launch { Graph.settings.setPersistentNotification(v) }
    }

    fun setIpv6(v: Boolean) {
        viewModelScope.launch { Graph.settings.setIpv6(v) }
    }

    fun setTheme(t: ThemeMode) {
        viewModelScope.launch { Graph.settings.setTheme(t) }
    }

    fun stopProtection() {
        NetControlVpnService.stop(appContext())
    }

    /** Rebuilds the tunnel from the saved rules. */
    fun reapplyRules() {
        NetControlVpnService.reload(appContext())
    }

    fun reportPermissionDenied() {
        ProtectionState.update {
            it.copy(error = ProtectionError(ErrorKind.PERMISSION_DENIED, "VPN permission was not granted"))
        }
    }

    fun clearError() {
        ProtectionState.update { it.copy(error = null) }
    }

    /** If protection was left on but the service is gone (killed, crash), bring it back once per launch. */
    fun restoreIfNeeded() {
        if (restoreTried) return
        viewModelScope.launch {
            val s = Graph.settings.flow.first()
            if (s.protectionEnabled && ProtectionState.status.value.phase == Phase.STOPPED) {
                restoreTried = true
                if (VpnService.prepare(appContext()) == null) {
                    NetControlVpnService.start(appContext(), s.persistentNotification)
                }
            }
        }
    }

    fun runRouteCheck() {
        viewModelScope.launch(Dispatchers.IO) {
            val n = Graph.network.state.value
            val provider = AndroidSocketProvider(null)
            val w = n.wifi?.toUplink()
            val c = n.cellular?.toUplink()
            val results = HashMap<Transport, ProbeResult>()
            if (w != null) results[Transport.WIFI] = RouteProbe.run(provider, w, c)
            if (c != null) results[Transport.CELLULAR] = RouteProbe.run(provider, c, w)
            ProtectionState.update { it.copy(probes = results) }
        }
    }

    fun buildReport(): String =
        ReportBuilder.build(appContext(), rules.value, status.value, Graph.engine?.snapshot())
}
