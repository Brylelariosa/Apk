package dev.netcontrol.app

import android.app.Application
import android.content.Context
import dev.netcontrol.app.data.AppRepository
import dev.netcontrol.app.data.IconCache
import dev.netcontrol.app.data.RuleStore
import dev.netcontrol.app.data.SettingsStore
import dev.netcontrol.app.net.NetworkMonitor
import dev.netcontrol.engine.Engine

/** Process-wide singletons shared by the UI and the VPN service (same process). */
object Graph {
    private lateinit var appCtx: Application

    val context: Context get() = appCtx
    val rules: RuleStore by lazy { RuleStore(appCtx) }
    val settings: SettingsStore by lazy { SettingsStore(appCtx) }
    val network: NetworkMonitor by lazy { NetworkMonitor(appCtx) }
    val apps: AppRepository by lazy { AppRepository(appCtx) }
    val icons: IconCache by lazy { IconCache(appCtx) }

    /** The running packet engine, or null while protection is stopped. */
    @Volatile
    var engine: Engine? = null

    fun init(app: Application) {
        appCtx = app
        network.start()
    }
}
