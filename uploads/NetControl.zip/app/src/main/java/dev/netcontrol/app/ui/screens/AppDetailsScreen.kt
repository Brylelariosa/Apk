package dev.netcontrol.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.components.AppIcon
import dev.netcontrol.app.ui.components.InfoRow
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard
import dev.netcontrol.app.ui.components.StatusPill
import dev.netcontrol.app.ui.components.blockReasonLabel
import dev.netcontrol.app.ui.components.enforcementColor
import dev.netcontrol.app.ui.components.enforcementExplanation
import dev.netcontrol.app.ui.components.enforcementLabel
import dev.netcontrol.app.ui.components.policyDescription
import dev.netcontrol.app.ui.components.policyIconRes
import dev.netcontrol.app.ui.components.policyLabel
import dev.netcontrol.app.ui.components.yesNo
import dev.netcontrol.engine.Policy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppDetailsScreen(vm: MainViewModel, pkg: String, onBack: () -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val stats by vm.engineStats.collectAsStateWithLifecycle()

    val app = apps.firstOrNull { it.packageName == pkg }
    val policy = rules[pkg] ?: Policy.AUTOMATIC
    val uidStats = if (app == null) null else stats?.perUid?.get(app.uid)
    val level = EnforcementCalculator.levelFor(pkg, policy, status, net, uidStats)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(app?.label ?: pkg, onBack)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(pkg, 56.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(app?.label ?: pkg, style = MaterialTheme.typography.titleMedium)
                    Text(
                        pkg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionCard(stringResource(R.string.detail_policy)) {
                for (p in Policy.values()) {
                    PolicyOption(p, selected = p == policy, onClick = { vm.setPolicy(pkg, p) })
                }
            }

            SectionCard(stringResource(R.string.detail_enforcement)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(enforcementLabel(level, policy), enforcementColor(level))
                }
                Text(
                    enforcementExplanation(level, policy),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (policy != Policy.AUTOMATIC) {
                    Text(
                        stringResource(whenUnavailable(policy)),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            SectionCard(stringResource(R.string.detail_network)) {
                InfoRow(
                    stringResource(R.string.dash_wifi),
                    stringResource(if (net.wifi != null) R.string.net_connected else R.string.net_disconnected)
                )
                InfoRow(
                    stringResource(R.string.dash_cellular),
                    stringResource(if (net.cellular != null) R.string.net_available else R.string.net_unavailable)
                )
                InfoRow(stringResource(R.string.dash_default), defaultText(net.defaultNet))
                InfoRow(stringResource(R.string.detail_inside), yesNo(status.captured.contains(pkg)))
                if (status.lastApplyMs != 0L) {
                    val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(status.lastApplyMs))
                    InfoRow(stringResource(R.string.detail_last_apply), t)
                }
            }

            if (policy != Policy.AUTOMATIC) {
                SectionCard(stringResource(R.string.detail_observed)) {
                    if (uidStats == null) {
                        Text(
                            stringResource(R.string.detail_no_stats),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        InfoRow(stringResource(R.string.detail_flows_wifi), uidStats.routedWifi.toString())
                        InfoRow(stringResource(R.string.detail_flows_cell), uidStats.routedCellular.toString())
                        InfoRow(stringResource(R.string.detail_flows_blocked), uidStats.blocked.toString())
                        val reason = uidStats.lastBlock
                        if (reason != null) {
                            InfoRow(stringResource(R.string.detail_last_block), blockReasonLabel(reason))
                        }
                        InfoRow(stringResource(R.string.detail_bytes_up), formatBytes(uidStats.bytesUp))
                        InfoRow(stringResource(R.string.detail_bytes_down), formatBytes(uidStats.bytesDown))
                        Text(
                            stringResource(R.string.detail_stats_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}

private fun whenUnavailable(p: Policy): Int = when (p) {
    Policy.WIFI_ONLY -> R.string.policy_wifi_fail
    Policy.MOBILE_ONLY -> R.string.policy_mobile_fail
    Policy.BLOCK -> R.string.policy_block_fail
    Policy.AUTOMATIC -> R.string.policy_auto_desc
}

internal fun formatBytes(n: Long): String {
    if (n < 1024) return "$n B"
    val kb = n / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
    return String.format(Locale.US, "%.2f GB", mb / 1024.0)
}

@Composable
private fun PolicyOption(p: Policy, selected: Boolean, onClick: () -> Unit) {
    val border = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    val container = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = container,
        border = BorderStroke(1.dp, border),
        modifier = Modifier.fillMaxWidth().selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(policyIconRes(p)), null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(policyLabel(p), style = MaterialTheme.typography.titleSmall)
                Text(
                    policyDescription(p),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (selected) {
                Icon(painterResource(R.drawable.ic_check_circle), null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
