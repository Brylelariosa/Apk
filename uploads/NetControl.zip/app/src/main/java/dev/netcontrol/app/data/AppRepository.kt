package dev.netcontrol.app.data

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import dev.netcontrol.app.Graph
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.RoutingTable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class AppEntry(
    val packageName: String,
    val label: String,
    val uid: Int,
    val isSystem: Boolean
)

class AppRepository(private val ctx: Context) {

    /** UID of an installed package, or null when it is not installed. */
    fun uidOf(pkg: String): Int? = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).uid
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    /** Installed apps that can use the network (declare INTERNET) and run under an app UID. */
    suspend fun load(): List<AppEntry> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        val out = ArrayList<AppEntry>(packages.size)
        for (pi in packages) {
            val ai = pi.applicationInfo ?: continue
            if (ai.uid < RoutingTable.FIRST_APP_UID) continue
            if (pi.packageName == ctx.packageName) continue
            val perms = pi.requestedPermissions ?: continue
            if (!perms.contains(Manifest.permission.INTERNET)) continue
            val updatedSystem = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && !updatedSystem
            out.add(AppEntry(pi.packageName, pm.getApplicationLabel(ai).toString(), ai.uid, system))
        }
        out.sortBy { it.label.lowercase() }
        out
    }

    /**
     * Applies the "default policy for new apps" setting to packages that were not present on the
     * previous scan. The first scan only records a baseline and never changes any rule.
     */
    suspend fun applyDefaultPolicyToNew(installed: List<AppEntry>) {
        val names = installed.map { it.packageName }.toSet()
        val known = Graph.settings.knownPackages()
        if (known == null) {
            Graph.settings.setKnownPackages(names)
            return
        }
        val fresh = names - known
        if (fresh.isNotEmpty()) {
            val def = Graph.settings.flow.first().defaultPolicy
            if (def != Policy.AUTOMATIC) {
                val existing = Graph.rules.rules.first()
                val changes = HashMap<String, Policy>()
                for (p in fresh) {
                    if (!existing.containsKey(p)) changes[p] = def
                }
                if (changes.isNotEmpty()) Graph.rules.setMany(changes)
            }
        }
        if (names != known) Graph.settings.setKnownPackages(names)
    }
}

/** Small in-memory cache of launcher icons rendered at the size they are drawn (never full resolution). */
class IconCache(private val ctx: Context) {
    private val cache = LruCache<String, ImageBitmap>(160)

    suspend fun get(pkg: String, sizePx: Int): ImageBitmap? {
        val hit = cache.get(pkg)
        if (hit != null) return hit
        val bmp: ImageBitmap = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg)
                    .toBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                    .asImageBitmap()
            } catch (e: Exception) {
                null
            }
        } ?: return null
        cache.put(pkg, bmp)
        return bmp
    }
}
