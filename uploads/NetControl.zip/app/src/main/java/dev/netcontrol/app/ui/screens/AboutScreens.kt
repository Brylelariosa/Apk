package dev.netcontrol.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.netcontrol.app.R
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard

@Composable
fun AboutScreen(onBack: () -> Unit, onPrivacy: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.about_title), onBack)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard(stringResource(R.string.app_name)) {
                Text(stringResource(R.string.about_body), style = MaterialTheme.typography.bodyMedium)
            }
            SectionCard(stringResource(R.string.about_how_title)) {
                Text(stringResource(R.string.about_how), style = MaterialTheme.typography.bodyMedium)
            }
            SectionCard(stringResource(R.string.about_limits_title)) {
                Text(stringResource(R.string.about_limits), style = MaterialTheme.typography.bodyMedium)
            }
            SectionCard(stringResource(R.string.about_block_title)) {
                Text(stringResource(R.string.about_block), style = MaterialTheme.typography.bodyMedium)
            }
            OutlinedButton(onClick = onPrivacy, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.set_privacy))
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.privacy_title), onBack)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            SectionCard(null) {
                Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}
