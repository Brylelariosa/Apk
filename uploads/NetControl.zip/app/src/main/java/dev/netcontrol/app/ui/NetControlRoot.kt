package dev.netcontrol.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import dev.netcontrol.app.R
import dev.netcontrol.app.ui.screens.AboutScreen
import dev.netcontrol.app.ui.screens.AppDetailsScreen
import dev.netcontrol.app.ui.screens.AppsScreen
import dev.netcontrol.app.ui.screens.DashboardScreen
import dev.netcontrol.app.ui.screens.DiagnosticsScreen
import dev.netcontrol.app.ui.screens.PrivacyScreen
import dev.netcontrol.app.ui.screens.RulesScreen
import dev.netcontrol.app.ui.screens.SettingsScreen

private class TopLevel(val route: String, val icon: Int, val label: Int)

private val TOP_LEVEL = listOf(
    TopLevel(Routes.DASHBOARD, R.drawable.ic_dashboard, R.string.nav_dashboard),
    TopLevel(Routes.APPS, R.drawable.ic_apps, R.string.nav_apps),
    TopLevel(Routes.RULES, R.drawable.ic_rules, R.string.nav_rules),
    TopLevel(Routes.DIAGNOSTICS, R.drawable.ic_chart, R.string.nav_diagnostics),
    TopLevel(Routes.SETTINGS, R.drawable.ic_settings, R.string.nav_settings)
)

private fun NavHostController.goTop(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun NetControlRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val control = rememberProtectionControl(vm)
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val showBar = TOP_LEVEL.any { it.route == current }

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    for (item in TOP_LEVEL) {
                        NavigationBarItem(
                            selected = current == item.route,
                            onClick = { nav.goTop(item.route) },
                            icon = { Icon(painterResource(item.icon), null) },
                            label = { Text(stringResource(item.label), maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Routes.DASHBOARD, modifier = Modifier.padding(padding)) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(vm, control) { route ->
                    if (route == Routes.ABOUT) nav.navigate(route) else nav.goTop(route)
                }
            }
            composable(Routes.APPS) {
                AppsScreen(vm) { pkg -> nav.navigate(Routes.detail(pkg)) }
            }
            composable(Routes.RULES) {
                RulesScreen(vm) { pkg -> nav.navigate(Routes.detail(pkg)) }
            }
            composable(Routes.DIAGNOSTICS) { DiagnosticsScreen(vm) }
            composable(Routes.SETTINGS) {
                SettingsScreen(vm, control) { route -> nav.navigate(route) }
            }
            composable(Routes.ABOUT) {
                AboutScreen(onBack = { nav.popBackStack() }, onPrivacy = { nav.navigate(Routes.PRIVACY) })
            }
            composable(Routes.PRIVACY) { PrivacyScreen(onBack = { nav.popBackStack() }) }
            composable(Routes.DETAIL, arguments = listOf(navArgument("pkg") { type = NavType.StringType })) { e ->
                AppDetailsScreen(vm, e.arguments?.getString("pkg") ?: "", onBack = { nav.popBackStack() })
            }
        }
    }
    ProtectionDialogs(control)
}
