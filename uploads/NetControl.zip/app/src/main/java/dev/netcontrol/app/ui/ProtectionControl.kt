package dev.netcontrol.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import dev.netcontrol.app.Graph
import dev.netcontrol.app.R
import dev.netcontrol.app.vpn.NetControlVpnService

enum class StartStep { EXPLAIN, OTHER_VPN }

/**
 * Guides the user through starting protection: explanation of the local VPN, a warning when another
 * VPN is active, the optional notification permission, and Android's own VPN consent dialog.
 */
class ProtectionControl internal constructor(private val ctx: Context, private val vm: MainViewModel) {
    var step: StartStep? by mutableStateOf(null)
        private set

    internal var consentLauncher: ManagedActivityResultLauncher<Intent, ActivityResult>? = null
    internal var notifLauncher: ManagedActivityResultLauncher<String, Boolean>? = null

    fun requestStart() {
        if (!vm.settings.value.vpnExplained) {
            step = StartStep.EXPLAIN
            return
        }
        afterExplained()
    }

    fun confirmExplain() {
        vm.markExplained()
        step = null
        afterExplained()
    }

    fun confirmOtherVpn() {
        step = null
        proceed()
    }

    fun dismiss() {
        step = null
    }

    fun stop() {
        vm.stopProtection()
    }

    private fun afterExplained() {
        if (Graph.network.state.value.otherVpnActive) {
            step = StartStep.OTHER_VPN
            return
        }
        proceed()
    }

    private fun proceed() {
        val needsNotifPermission = Build.VERSION.SDK_INT >= 33 &&
            vm.settings.value.persistentNotification &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        val launcher = notifLauncher
        if (needsNotifPermission && launcher != null) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        launchConsent()
    }

    internal fun onNotificationResult() {
        launchConsent()
    }

    private fun launchConsent() {
        val intent = VpnService.prepare(ctx)
        val launcher = consentLauncher
        if (intent != null && launcher != null) {
            launcher.launch(intent)
        } else {
            startService()
        }
    }

    internal fun onConsentResult(granted: Boolean) {
        if (granted) startService() else vm.reportPermissionDenied()
    }

    private fun startService() {
        vm.clearError()
        NetControlVpnService.start(ctx, vm.settings.value.persistentNotification)
    }
}

@Composable
fun rememberProtectionControl(vm: MainViewModel): ProtectionControl {
    val ctx = LocalContext.current
    val control = remember { ProtectionControl(ctx, vm) }
    control.consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        control.onConsentResult(r.resultCode == Activity.RESULT_OK)
    }
    control.notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        control.onNotificationResult()
    }
    return control
}

@Composable
fun ProtectionDialogs(control: ProtectionControl) {
    when (control.step) {
        StartStep.EXPLAIN -> AlertDialog(
            onDismissRequest = { control.dismiss() },
            title = { Text(stringResource(R.string.vpn_explain_title)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(stringResource(R.string.vpn_explain_body))
                }
            },
            confirmButton = {
                TextButton(onClick = { control.confirmExplain() }) { Text(stringResource(R.string.action_continue)) }
            },
            dismissButton = {
                TextButton(onClick = { control.dismiss() }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
        StartStep.OTHER_VPN -> AlertDialog(
            onDismissRequest = { control.dismiss() },
            title = { Text(stringResource(R.string.other_vpn_title)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(stringResource(R.string.other_vpn_body))
                }
            },
            confirmButton = {
                TextButton(onClick = { control.confirmOtherVpn() }) { Text(stringResource(R.string.other_vpn_continue)) }
            },
            dismissButton = {
                TextButton(onClick = { control.dismiss() }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
        null -> {
        }
    }
}
