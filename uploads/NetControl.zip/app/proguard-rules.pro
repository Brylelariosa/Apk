# R8 full mode is the AGP default. Manifest components (activity, VpnService, receiver) are kept
# automatically by the rules AGP generates from AndroidManifest.xml.

# Strip verbose/debug logging from release builds.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}
