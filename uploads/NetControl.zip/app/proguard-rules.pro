# R8 full mode is the AGP default. Manifest components (activity, VpnService, receiver) are kept
# automatically by the rules AGP generates from AndroidManifest.xml.

# Keep real class and method names and line numbers in release builds. A crash report is written on the phone
# (Download/NetControl-crash-*.txt) and there is no mapping file there to translate an obfuscated stack trace,
# so a readable trace is worth more than the few KB that obfuscation saves. Delete these two lines to
# obfuscate again.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable

# Strip verbose/debug logging from release builds.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}
