# NetControl architecture

## 1. Why this design

Public Android APIs do not let one app move another app between Wi-Fi and mobile data:

* `Network.bindSocket()` and `ConnectivityManager.bindProcessToNetwork()` only affect sockets of the
  calling process. They do not redirect other apps.
* `VpnService.Builder.addAllowedApplication()` decides **which apps enter a VPN**, not which physical
  network they leave on.

The supported combination that can really enforce per-app routing without root is:

1. A local VPN that captures only the apps with a custom rule (`addAllowedApplication`).
2. A user-space packet engine that terminates each captured connection and re-opens it with a socket bound
   to the chosen physical network (`Network.bindSocket`, `VpnService.protect`).

Apps set to Automatic are never added to the VPN, so their networking is untouched. This is the least
disruptive way to honor Mode C. Capturing is static (not toggled on network changes) so there is no window
in which a Wi-Fi Only app can leak to mobile data while the VPN is being rebuilt.

## 2. Components

```
app (Android)                              engine (pure Kotlin/JVM)
-------------------------------            ---------------------------------------------
NetControlVpnService  --creates-->  tun fd  Engine: reader thread + selector thread
  computeCapture(rules)                       IpParser / PacketBuilder / Fragmenter / Reassembler
  buildTunnel()                               TcpFlow  (server-side TCP + remote SocketChannel)
  pushRouting() -> RoutingTable ------------> UdpFlow  (UDP mapping, DNS forwarding)
NetworkMonitor (callbacks, no polling)        RoutingTable.decide(uid) -> Route(uplink) | Block(reason)
AndroidSocketProvider (bindSocket+protect)    UidStats / EventLog / EngineSnapshot
ConnectionOwnerResolver (UID of a flow)
RouteProbe (source-address self test)
RuleStore / SettingsStore (DataStore)
Compose UI (Material 3)
```

The engine has no Android dependency; sockets and UID lookup are injected through `SocketProvider` and
`UidResolver`, which is why its codec, fragmentation and policy logic have JVM unit tests.

## 3. Packet path

* The tunnel has IPv4 `198.18.0.1/32` and (optional) IPv6 `fd6e:6574:636f:6e74::1/128`, default routes for both,
  MTU 1500, and virtual DNS servers `198.18.0.2` / `fd6e:6574:636f:6e74::2`.
* **TCP**: a SYN creates a `TcpFlow`: owner UID lookup, policy decision, bound `SocketChannel`, non-blocking
  connect. The SYN-ACK is sent to the app only after the remote connect succeeds. Data is relayed in both
  directions with sequence tracking, window scaling, cumulative ACKs, go-back-N retransmission, zero-window
  probing, FIN/RST handling and idle timeouts. Backpressure limits buffering to 256 KB per direction.
  Connect failure becomes a RST.
* **UDP**: one bound `DatagramChannel` per (source, destination) flow. Oversized replies are fragmented to the
  tunnel MTU; fragmented datagrams from apps are reassembled (IPv4 and IPv6). ICMP "port unreachable" is
  returned for blocked flows so apps fail fast instead of timing out (QUIC falls back to TCP quickly).
* **Not forwarded**: ICMP/ICMPv6 echo and any protocol other than TCP/UDP (counted as dropped).

## 4. Policy decision (`RoutingTable.decide`)

| Owner of the flow | Result |
|---|---|
| App with Wi-Fi Only | Route over Wi-Fi, otherwise Block(WIFI_UNAVAILABLE) |
| App with Mobile Data Only | Route over cellular, otherwise Block(CELLULAR_UNAVAILABLE) |
| App with Block Internet | Block(POLICY_BLOCK) |
| System UID (below 10000) | Follows the transport the rules need; with mixed rules the system default network; with only Block rules it is blocked |
| Unknown owner / unconfigured app UID | Allowed only when exactly one transport is in use by the rules, otherwise Block(UNATTRIBUTED) |

There is never a fall-through to the other network. Whenever rules or networks change, the engine re-evaluates
every open flow and resets those whose decision changed.

## 5. Keeping the cellular network available

While Wi-Fi is the default network Android may release the cellular network. When at least one app is set to
Mobile Data Only, `NetworkMonitor.holdCellular(true)` files a `requestNetwork` for cellular+INTERNET and
releases it again when it is no longer needed.

## 6. Verification model (what "Protected" means)

States: saved rule, service running, app inside the tunnel, route verified.

* `RouteProbe`: binds a UDP socket to each uplink and connects it to a public address (no packet is sent). The
  kernel-selected source address must belong to that network and not to the other one.
* Per flow: after connect, the local address must not belong to the other physical network. A socket on the
  wrong network is reset and counted as a routing violation (status "Routing Failure").
* "Protected" requires: service running + app captured + (Block, or required network present and probe or flow
  verified). Otherwise the UI shows Not Protected, Applying, Policy Not Verified, or Blocked (network missing).

## 7. DNS

* Apps with rules resolve through the virtual DNS address. The engine forwards the query to the DNS servers
  of the network chosen for that flow (UDP; TCP/53 is redirected the same way).
* When Android reports which app owns the lookup, the app policy applies. When it does not (system resolver
  UIDs), the system rule above applies, so with mixed Wi-Fi Only / Mobile Data Only rules an unattributed
  lookup may use the default network. Diagnostics counts attributed and unattributed lookups.
* Connections to the virtual DNS address on other ports (for example Private DNS on 853) are refused so Android
  falls back to normal DNS.
* DNS over HTTPS inside an app is an ordinary HTTPS connection and follows the app policy.

## 8. IPv6

Optional (Settings). When on, IPv6 is routed into the tunnel and forwarded like IPv4 (extension headers and
fragments handled). When off, apps with rules have no IPv6 route and Android blocks IPv6 for them, so there is
no bypass in either case.

## 9. Service behavior

* `START_STICKY`; restored after boot (if enabled and VPN consent exists) and once per app launch if it was
  left on but is gone.
* Foreground service with a notification by default; can be turned off in Settings (the VPN then runs without
  a notification and Android may stop it sooner).
* `onRevoke()` (another VPN took over, consent removed) stops everything, records the error, and does not
  re-take the VPN.
* All state changes are serialized on one service thread. No wake locks, no polling; networks are tracked with
  callbacks. UI counters poll once per second only while a screen that shows them is visible.

## 10. Known limits (stated honestly)

* Needs Android 10+.
* One VPN at a time: cannot coexist with another VPN app.
* Only apps with rules are controlled. System traffic, Play services, other VPNs, apps on Automatic: out of scope.
* Throughput is bounded by a user-space TCP implementation in Kotlin (no SACK, no timestamps, no congestion
  control towards the local app).
* Changing the set of captured apps rebuilds the tunnel and resets open connections of protected apps.
* ICMP is not forwarded.
* Existing connections of an app are reset when a rule is applied to it; apps normally reconnect.
* Package visibility: `QUERY_ALL_PACKAGES` is required to list and capture non-launcher apps, so the APK is
  meant for sideloading rather than Play Store distribution.

## 11. Crash reports

A crash on the phone has to be reportable without adb, root, Shizuku or a PC, so the app records its own.

* `NetControlApp.attachBaseContext` installs `CrashLogger` as the default uncaught-exception handler before any
  other app code runs (content providers, `Graph.init`, the first activity). It wraps the handler that was set
  before it and always calls that one last, so Android still shows its crash dialog and ends the process as usual.
* Three small pieces in `dev.netcontrol.app.diag`: `CrashReport` (text layout, pure Kotlin, unit tested),
  `DownloadsWriter` (saves a text file to the public Download folder through the MediaStore, which needs no
  permission from Android 10 on) and `CrashLogger` (collects the device details and the app's own recent log lines
  and ties the pieces together).
* A report is first written to private storage (`files/crash-logs`) and then copied to Download. If the copy
  fails (for example the disk is full) the private file stays and `CrashLogger.exportPending()` retries at the
  next start. At most the 10 newest reports that could not be exported are kept.
* The reporter never throws and never delays the crash by more than about 1.5 s (the time limit for reading the log).
* Release builds use `-dontobfuscate` and keep `SourceFile` and `LineNumberTable`, so a trace is readable
  without a mapping file.
* Limit: only Java and Kotlin exceptions are caught. A native crash, an ANR or a process killed by the system is
  not an uncaught exception and produces no file.
