# Test report

Nothing below is a result that was measured on a device. This file lists what was actually done when the
project was written and what still has to be run. Update the "Result" column after each run.

## Performed while writing the project (no compiler, no device available)

| Check | Result |
|---|---|
| Brace/parenthesis/bracket balance of all Kotlin files | passed (scripted) |
| Package declarations match directories | passed (scripted) |
| Project-internal imports resolve to declarations | passed (scripted) |
| Every `R.string`, `R.plurals`, `R.drawable` reference has a resource | passed (scripted) |
| All XML (manifest, resources, vector drawables) is well formed | passed (xmllint) |
| No non-ASCII characters (so no emoji) in any source or resource file | passed (scripted) |
| No `splits`, `abiFilters`, NDK or native library configuration | passed (grep) |
| Manual read-through of engine, service and UI for type/nullability errors | done once, not a compiler |

## Not performed (must be run)

| ID | Test | How | Expected | Result |
|---|---|---|---|---|
| H1 | Release build compiles | `gradle :app:assembleRelease` | success, APK present | not run |
| H2 | Unit tests | `gradle :engine:test` | all pass | not run |
| H3 | APK size | read `NETCONTROL_APK_REPORT` in the log | measured MB | not run |
| H4 | R8 / resource shrinking sanity | install release APK, open every screen | no crash, no missing resource | not run |
| H5 | One universal APK, no ABI splits | log line `lib/ entries = 0`, single file | 0 native entries | not run |
| A | Wi-Fi Only | Wi-Fi + data on, Opera = Wi-Fi Only, start, browse, turn Wi-Fi off, turn Wi-Fi on | works on Wi-Fi, no internet when Wi-Fi is off (never mobile data), returns with Wi-Fi | not run |
| B | Mobile Data Only | test app = Mobile Data Only, start, use it, turn mobile data off, on | works on mobile, no internet when data is off (never Wi-Fi), returns | not run |
| C | Block Internet | app = Block, try browsing and DoH, then Automatic | no connectivity while blocked, returns afterwards | not run |
| D | Automatic | app = Automatic | not in the tunnel (Diagnostics: apps inside tunnel does not count it) | not run |
| E | DNS | resolve names for apps of each mode, switch networks, disable the chosen network | lookups use the chosen network, fail when it is missing; check attributed/unattributed counters | not run |
| F | IPv4 / IPv6 | IPv6-capable network, toggle Settings > IPv6 | no bypass in either case | not run |
| G | Stability | Wi-Fi/mobile on-off, switch default network, restart app, stop/start service, reboot, revoke VPN consent | rules persist, state labels stay truthful, no crash | not run |

Things worth checking first on the first real run, because they depend on platform behavior that could not be
confirmed here:

1. `Network.bindSocket()` on NIO socket channels works on the target Android version (if it does not, flows fail
   with "Socket could not be bound to the network" and are blocked, never leaked).
2. `getConnectionOwnerUid()` returns the app UID for TCP and UDP flows and, ideally, DNS lookups
   (Diagnostics > DNS shows attributed vs unattributed counts).
3. Throughput of video streaming through the tunnel on the Infinix Hot 11 (user-space TCP in Kotlin).
