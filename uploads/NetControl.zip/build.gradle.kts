// Top-level build file. Versions are pinned for the existing pipeline (JDK 17, Gradle 8.6).
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.24" apply false
}
