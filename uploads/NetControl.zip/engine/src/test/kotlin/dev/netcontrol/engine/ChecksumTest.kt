package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class ChecksumTest {
    @Test
    fun ipv4HeaderKnownVector() {
        val h = intArrayOf(
            0x45, 0x00, 0x00, 0x73, 0x00, 0x00, 0x40, 0x00, 0x40, 0x11, 0x00, 0x00,
            0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, 0x00, 0xc7
        )
        val b = ByteArray(h.size) { h[it].toByte() }
        assertEquals(0xB861, Checksum.compute(b, 0, b.size))
        Bytes.put16(b, 10, 0xB861)
        assertEquals(0, Checksum.compute(b, 0, b.size))
    }

    @Test
    fun oddLengthIsPaddedWithZero() {
        val b = byteArrayOf(0x01, 0x02, 0x03)
        // words: 0x0102 + 0x0300 = 0x0402 -> complement 0xFBFD
        assertEquals(0xFBFD, Checksum.compute(b, 0, 3))
    }

    @Test
    fun byteQueueKeepsOrderAcrossGrowthAndDiscard() {
        val q = ByteQueue()
        val a = ByteArray(5000) { (it % 251).toByte() }
        q.append(a, 0, a.size)
        q.discard(1000)
        q.append(a, 0, 3000)
        assertEquals(7000, q.size)
        val out = ByteArray(7000)
        q.peek(0, out, 0, 7000)
        for (i in 0 until 4000) assertEquals(a[1000 + i], out[i])
        for (i in 0 until 3000) assertEquals(a[i], out[4000 + i])
    }
}
