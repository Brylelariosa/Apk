package dev.netcontrol.engine

import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Test

class BuffersTest {
    @Test
    fun clearForFillResetsPositionAndOpensTheWholeBuffer() {
        val bb = ByteBuffer.allocate(16)
        bb.put(byteArrayOf(1, 2, 3))
        bb.clearForFill()
        assertEquals(0, bb.position())
        assertEquals(16, bb.limit())
    }

    @Test
    fun clearForFillCapsTheWindowButNeverBeyondCapacity() {
        val bb = ByteBuffer.allocate(16)
        bb.clearForFill(5)
        assertEquals(5, bb.limit())
        bb.clearForFill(1000)
        assertEquals(16, bb.limit())
    }

    @Test
    fun flipForDrainExposesExactlyTheBytesThatWereWritten() {
        val bb = ByteBuffer.allocateDirect(16)
        bb.clearForFill()
        bb.put(byteArrayOf(7, 8, 9))
        bb.flipForDrain()
        assertEquals(3, bb.remaining())
        val out = ByteArray(3)
        bb.get(out, 0, 3)
        assertEquals(listOf<Byte>(7, 8, 9), out.toList())
    }
}
