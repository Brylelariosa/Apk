package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutingTableTest {
    private val wifi = Uplink(1L, Transport.WIFI, emptyList(), emptySet(), null)
    private val cell = Uplink(2L, Transport.CELLULAR, emptyList(), emptySet(), null)

    private fun routeOf(d: Decision): Uplink = (d as Decision.Route).uplink
    private fun reasonOf(d: Decision): BlockReason = (d as Decision.Block).reason

    @Test
    fun wifiOnlyUsesWifiAndNeverFallsBackToCellular() {
        val rules = mapOf(10001 to Policy.WIFI_ONLY)
        assertSame(wifi, routeOf(RoutingTable(rules, wifi, cell, Transport.CELLULAR).decide(10001)))
        val noWifi = RoutingTable(rules, null, cell, Transport.CELLULAR).decide(10001)
        assertTrue(noWifi is Decision.Block)
        assertEquals(BlockReason.WIFI_UNAVAILABLE, reasonOf(noWifi))
    }

    @Test
    fun mobileOnlyUsesCellularAndNeverFallsBackToWifi() {
        val rules = mapOf(10002 to Policy.MOBILE_ONLY)
        assertSame(cell, routeOf(RoutingTable(rules, wifi, cell, Transport.WIFI).decide(10002)))
        val noCell = RoutingTable(rules, wifi, null, Transport.WIFI).decide(10002)
        assertEquals(BlockReason.CELLULAR_UNAVAILABLE, reasonOf(noCell))
    }

    @Test
    fun blockAlwaysBlocks() {
        val rules = mapOf(10003 to Policy.BLOCK)
        val d = RoutingTable(rules, wifi, cell, Transport.WIFI).decide(10003)
        assertEquals(BlockReason.POLICY_BLOCK, reasonOf(d))
    }

    @Test
    fun unattributedFlowsAreBlockedWhenRulesAreMixed() {
        val rules = mapOf(10001 to Policy.WIFI_ONLY, 10002 to Policy.MOBILE_ONLY)
        val t = RoutingTable(rules, wifi, cell, Transport.WIFI)
        assertEquals(BlockReason.UNATTRIBUTED, reasonOf(t.decide(-1)))
        assertEquals(BlockReason.UNATTRIBUTED, reasonOf(t.decide(10999)))
    }

    @Test
    fun unattributedFlowsFollowTheOnlyTransportInUse() {
        val t = RoutingTable(mapOf(10001 to Policy.WIFI_ONLY), wifi, cell, Transport.CELLULAR)
        assertSame(wifi, routeOf(t.decide(-1)))
        val m = RoutingTable(mapOf(10001 to Policy.MOBILE_ONLY), wifi, cell, Transport.WIFI)
        assertSame(cell, routeOf(m.decide(-1)))
    }

    @Test
    fun systemUidsFollowDefaultNetworkWhenRulesAreMixed() {
        val rules = mapOf(10001 to Policy.WIFI_ONLY, 10002 to Policy.MOBILE_ONLY)
        assertSame(cell, routeOf(RoutingTable(rules, wifi, cell, Transport.CELLULAR).decide(1000)))
        assertSame(wifi, routeOf(RoutingTable(rules, wifi, cell, Transport.WIFI).decide(1000)))
    }

    @Test
    fun blockOnlyRulesBlockEverythingUnattributed() {
        val t = RoutingTable(mapOf(10003 to Policy.BLOCK), wifi, cell, Transport.WIFI)
        assertEquals(BlockReason.UNATTRIBUTED, reasonOf(t.decide(1000)))
    }

    @Test
    fun capturedMeansNonAutomatic() {
        val t = RoutingTable(mapOf(10001 to Policy.WIFI_ONLY), null, null, null)
        assertTrue(t.isCaptured(10001))
        assertFalse(t.isCaptured(10002))
    }

    @Test
    fun ruleCodecRoundTripsAndIgnoresGarbage() {
        val rules = mapOf(
            "com.example.a" to Policy.WIFI_ONLY,
            "com.example.b" to Policy.MOBILE_ONLY,
            "com.example.c" to Policy.BLOCK
        )
        val encoded = RuleCodec.encode(rules)
        assertEquals(rules, RuleCodec.decode(encoded))
        val noisy = encoded + setOf("broken", "x=Z", "=W", "pkg=A")
        assertEquals(rules, RuleCodec.decode(noisy))
    }
}
