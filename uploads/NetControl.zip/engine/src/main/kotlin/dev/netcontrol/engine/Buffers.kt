package dev.netcontrol.engine

import java.nio.Buffer
import java.nio.ByteBuffer

/*
 * Why these helpers exist: since JDK 9, `ByteBuffer.clear()`, `limit(int)` and `flip()` are redeclared with a
 * covariant `ByteBuffer` return type. This module is compiled against a modern JDK, so a direct call binds to
 * `ByteBuffer.flip()Ljava/nio/ByteBuffer;`, a method Android's runtime only has from API 33 on. On Android 10-12
 * (this app's minSdk is 29) that call throws NoSuchMethodError, which is an Error, not an Exception, so it would
 * silently end the engine thread. Calling the same methods through [Buffer] binds to the signature that exists on
 * every Android release. Keep all clear/limit/flip calls on a ByteBuffer inside this file.
 */

/** Empties the buffer ahead of a channel read, optionally capping how many bytes that read may deliver. */
internal fun ByteBuffer.clearForFill(maxBytes: Int = capacity()) {
    val buffer: Buffer = this
    buffer.clear()
    buffer.limit(minOf(maxBytes, capacity()))
}

/** Switches the buffer from "a channel just filled it" to "the caller reads what arrived". */
internal fun ByteBuffer.flipForDrain() {
    val buffer: Buffer = this
    buffer.flip()
}
