package dev.netcontrol.engine

import java.io.IOException
import java.net.InetSocketAddress
import java.net.PortUnreachableException
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectionKey

/**
 * One UDP mapping. Non-DNS flows use a connected socket (so the kernel filters foreign senders and
 * the bound route can be verified). DNS flows use an unconnected socket and may try several servers.
 */
internal class UdpFlow(
    private val eng: Engine,
    val key: FlowKey,
    val uid: Int,
    val uplink: Uplink,
    val isDns: Boolean,
    private val channel: DatagramChannel,
    private val targets: List<InetSocketAddress>
) : FlowHandler {

    var selKey: SelectionKey? = null

    private var lastActivity = eng.now()
    private var targetIdx = 0
    private var lastQuery: ByteArray? = null
    private var querySentAt = 0L
    private var closed = false

    fun onDatagram(d: ByteArray, off: Int, len: Int) {
        if (closed) return
        lastActivity = eng.now()
        try {
            val bb = ByteBuffer.wrap(d, off, len)
            if (isDns) channel.send(bb, targets[targetIdx]) else channel.write(bb)
            eng.addBytesUp(uid, len)
            if (isDns) {
                lastQuery = d.copyOfRange(off, off + len)
                querySentAt = lastActivity
            }
        } catch (e: PortUnreachableException) {
            notifyUnreachable()
            close()
        } catch (e: IOException) {
            close()
        }
    }

    override fun onConnectable() {
    }

    override fun onWritable() {
    }

    override fun onReadable() {
        var count = 0
        while (count < 16 && !closed) {
            count++
            val bb = eng.readBuf
            bb.clearForFill()
            var got = false
            try {
                if (isDns) {
                    val from = channel.receive(bb) ?: return
                    if (from is InetSocketAddress && fromAllowed(from)) got = true
                } else {
                    val n = channel.read(bb)
                    if (n <= 0) return
                    got = true
                }
            } catch (e: PortUnreachableException) {
                notifyUnreachable()
                close()
                return
            } catch (e: IOException) {
                close()
                return
            }
            if (!got) continue
            bb.flipForDrain()
            val len = bb.remaining()
            bb.get(eng.tmp, 0, len)
            lastActivity = eng.now()
            lastQuery = null
            eng.addBytesDown(uid, len)
            eng.emitUdpToClient(key, eng.tmp, 0, len)
        }
    }

    private fun fromAllowed(from: InetSocketAddress): Boolean {
        for (t in targets) {
            if (t.port == from.port && t.address == from.address) return true
        }
        return false
    }

    /** Tells the app the destination port is unreachable so it can fail fast (for example QUIC fallback). */
    private fun notifyUnreachable() {
        val empty = ByteArray(0)
        val orig = PacketBuilder.udp(key.src, key.dst, key.sport, key.dport, empty, 0, 0)
        val parsed = IpParser.parse(orig, orig.size) ?: return
        eng.emit(PacketBuilder.icmpUnreachable(parsed))
    }

    fun tick(now: Long) {
        if (closed) return
        val q = lastQuery
        if (isDns && q != null && now - querySentAt > DNS_RETRY_MS && targetIdx + 1 < targets.size) {
            targetIdx++
            querySentAt = now
            try {
                channel.send(ByteBuffer.wrap(q), targets[targetIdx])
            } catch (e: IOException) {
                close()
                return
            }
        }
        val idle = if (isDns) DNS_IDLE_MS else UDP_IDLE_MS
        if (now - lastActivity > idle) close()
    }

    fun close() {
        if (closed) return
        closed = true
        try {
            selKey?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        try {
            channel.close()
        } catch (e: IOException) {
            // ignore
        }
        eng.removeUdp(this)
    }

    fun shutdown() {
        close()
    }

    override fun abortFlow() {
        close()
    }

    private companion object {
        const val DNS_RETRY_MS = 1500L
        const val DNS_IDLE_MS = 10_000L
        const val UDP_IDLE_MS = 120_000L
    }
}
