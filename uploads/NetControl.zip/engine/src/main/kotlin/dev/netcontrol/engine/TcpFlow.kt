package dev.netcontrol.engine

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.CancelledKeyException
import java.nio.channels.SelectionKey
import java.nio.channels.SocketChannel
import java.util.concurrent.ThreadLocalRandom

/**
 * One proxied TCP connection. The app side is a minimal server-side TCP implementation (handshake,
 * cumulative ACKs, window scaling, go-back-N retransmission, FIN/RST handling); the remote side is a
 * real non-blocking socket bound to the uplink chosen by the routing policy.
 */
internal class TcpFlow(
    private val eng: Engine,
    val key: FlowKey,
    val uid: Int,
    val uplink: Uplink,
    val isDns: Boolean,
    private val channel: SocketChannel,
    syn: TcpSeg,
    ver: Int
) : FlowHandler {

    private enum class St { CONNECTING, ESTABLISHED, CLOSED }

    var selKey: SelectionKey? = null

    private var st = St.CONNECTING
    private val createdAt = eng.now()
    private var lastActivity = createdAt

    // app -> remote
    private var rcvNxt: Int = syn.seq + 1
    private val toRemote = ByteQueue()
    private var clientFin = false
    private var remoteShut = false

    // remote -> app
    private val sndIsn: Int = ThreadLocalRandom.current().nextInt()
    private var sndUna = 0
    private var sndNxt = 0
    private var sndMax = 0
    private val out = ByteQueue()
    private var remoteEof = false
    private var finSent = false
    private var finSeq = 0
    private var finAcked = false

    private val wsOk = syn.wscale >= 0
    private val peerShift = if (wsOk) syn.wscale else 0
    private val ourShift = if (wsOk) OUR_SHIFT else 0
    private var peerWnd = syn.window
    private val synMss = eng.mtu - (if (ver == 6) 60 else 40)
    private val mss = minOf(if (syn.mss > 0) syn.mss else 536, synMss)

    private var rtoMs = RTO_INITIAL_MS
    private var rtoAt = 0L
    private var rexmits = 0
    private var dupAcks = 0
    private var probeAt = 0L
    private var lastAvail = 0

    // ------------------------------------------------------------------ helpers

    private fun advWindow(): Int {
        val avail = REMOTE_CAP - toRemote.size
        lastAvail = avail
        return if (avail <= 0) 0 else minOf(0xFFFF, avail ushr ourShift)
    }

    private fun send(flags: Int, seq: Int, ack: Int, opts: ByteArray?, p: ByteArray?, pOff: Int, pLen: Int, window: Int) {
        eng.emit(PacketBuilder.tcp(key.dst, key.src, key.dport, key.sport, seq, ack, flags, window, opts, p, pOff, pLen))
    }

    private fun sendAck() {
        send(TcpFlags.ACK, sndNxt, rcvNxt, null, null, 0, 0, advWindow())
    }

    private fun sendRst() {
        val seq = if (st == St.CONNECTING) 0 else sndNxt
        send(TcpFlags.RST or TcpFlags.ACK, seq, rcvNxt, null, null, 0, 0, 0)
    }

    private fun sendSynAck() {
        val opts = if (wsOk) {
            byteArrayOf(2, 4, (synMss shr 8).toByte(), synMss.toByte(), 1, 3, 3, ourShift.toByte())
        } else {
            byteArrayOf(2, 4, (synMss shr 8).toByte(), synMss.toByte())
        }
        val w = minOf(0xFFFF, REMOTE_CAP - toRemote.size)
        send(TcpFlags.SYN or TcpFlags.ACK, sndIsn, rcvNxt, opts, null, 0, 0, w)
    }

    private fun updateInterest() {
        val k = selKey ?: return
        if (!k.isValid) return
        var ops = 0
        when (st) {
            St.CONNECTING -> ops = SelectionKey.OP_CONNECT
            St.ESTABLISHED -> {
                if (!remoteEof && out.size < OUT_CAP) ops = ops or SelectionKey.OP_READ
                if (toRemote.size > 0) ops = ops or SelectionKey.OP_WRITE
            }
            St.CLOSED -> ops = 0
        }
        try {
            if (k.interestOps() != ops) k.interestOps(ops)
        } catch (e: CancelledKeyException) {
            // closed concurrently
        }
    }

    private fun closeFlow() {
        if (st == St.CLOSED) return
        st = St.CLOSED
        try {
            selKey?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        try {
            channel.close()
        } catch (e: IOException) {
            // ignore
        }
        toRemote.clear()
        out.clear()
        eng.removeTcp(this)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onConnectable() {
        try {
            if (channel.finishConnect()) onConnected()
        } catch (e: IOException) {
            connectFailed(e.message ?: "connect failed")
        }
    }

    fun onConnected() {
        if (st != St.CONNECTING) return
        val local = try {
            channel.socket().localAddress
        } catch (e: Exception) {
            null
        }
        if (eng.checkRoute(uid, uplink, local) == Engine.ROUTE_VIOLATION) {
            reset()
            return
        }
        sndNxt = sndIsn + 1
        sndUna = sndNxt
        sndMax = sndNxt
        st = St.ESTABLISHED
        eng.noteRouted(uid, uplink.transport)
        sendSynAck()
        updateInterest()
    }

    fun connectFailed(msg: String) {
        if (st == St.CLOSED) return
        eng.noteConnectFailure(msg)
        sendRst()
        closeFlow()
    }

    /** Aborts the connection towards the app (RST) and releases the remote socket. */
    fun reset() {
        if (st == St.CLOSED) return
        sendRst()
        closeFlow()
    }

    /** Releases resources without notifying the app (engine shutdown). */
    fun shutdown() {
        closeFlow()
    }

    override fun abortFlow() {
        reset()
    }

    fun tick(now: Long) {
        when (st) {
            St.CONNECTING -> if (now - createdAt > CONNECT_TIMEOUT_MS) connectFailed("timeout")
            St.ESTABLISHED -> {
                if (rtoAt != 0L && now >= rtoAt) {
                    if (peerWnd == 0) rtoAt = now + RTO_MAX_MS else retransmit(true)
                }
                if (st == St.ESTABLISHED && peerWnd == 0 && !finSent && out.size > (sndNxt - sndUna) && now >= probeAt) {
                    probe(now)
                }
                val limit = if (clientFin || remoteEof) HALF_IDLE_MS else IDLE_MS
                if (st == St.ESTABLISHED && now - lastActivity > limit) reset()
            }
            St.CLOSED -> {
            }
        }
    }

    // ------------------------------------------------------------------ app -> remote

    fun onSegment(seg: TcpSeg, d: ByteArray) {
        lastActivity = eng.now()
        if (seg.rst) {
            closeFlow()
            return
        }
        if (st != St.ESTABLISHED) return
        if (seg.syn) {
            if (sndUna == sndIsn + 1 && sndNxt == sndUna && !finSent) sendSynAck()
            return
        }
        if (seg.hasAck) processAck(seg)
        if (st == St.CLOSED) return
        processData(seg, d)
        if (st == St.CLOSED) return
        pump()
        updateInterest()
        if (finAcked && clientFin) closeFlow()
    }

    private fun processAck(seg: TcpSeg) {
        val w = seg.window.toLong() shl peerShift
        peerWnd = if (w > MAX_WND) MAX_WND.toInt() else w.toInt()
        val ackNo = seg.ack
        val acked = ackNo - sndUna
        if (acked > 0 && (ackNo - sndMax) <= 0) {
            var dataAcked = acked
            if (finSent && (ackNo - (finSeq + 1)) >= 0) {
                finAcked = true
                dataAcked -= 1
            }
            if (dataAcked > 0) out.discard(dataAcked)
            sndUna = ackNo
            if ((sndNxt - sndUna) < 0) sndNxt = sndUna
            rexmits = 0
            dupAcks = 0
            rtoMs = RTO_INITIAL_MS
            rtoAt = if (sndUna != sndNxt) eng.now() + rtoMs else 0L
        } else if (acked == 0 && seg.payloadLen == 0 && !seg.fin && sndUna != sndNxt) {
            dupAcks++
            if (dupAcks == 3) retransmit(false)
        }
    }

    private fun processData(seg: TcpSeg, d: ByteArray) {
        var plen = seg.payloadLen
        val fin = seg.fin
        if (plen == 0 && !fin) {
            if (seg.seq != rcvNxt) sendAck()
            return
        }
        var off = seg.payloadOff
        val behind = rcvNxt - seg.seq
        if (behind > 0) {
            val total = plen + (if (fin) 1 else 0)
            if (behind >= total) {
                sendAck()
                return
            }
            val skip = minOf(behind, plen)
            off += skip
            plen -= skip
        } else if (behind < 0) {
            sendAck()
            return
        }
        val room = REMOTE_CAP - toRemote.size
        if (plen > room) {
            if (room > 0) {
                toRemote.append(d, off, room)
                rcvNxt += room
                eng.addBytesUp(uid, room)
            }
            sendAck()
            flushToRemote()
            return
        }
        if (plen > 0) {
            toRemote.append(d, off, plen)
            rcvNxt += plen
            eng.addBytesUp(uid, plen)
        }
        if (fin && !clientFin) {
            clientFin = true
            rcvNxt += 1
        }
        sendAck()
        flushToRemote()
    }

    override fun onWritable() {
        flushToRemote()
    }

    private fun flushToRemote() {
        if (st != St.ESTABLISHED) return
        try {
            while (toRemote.size > 0) {
                val n = minOf(toRemote.size, WRITE_CHUNK)
                toRemote.peek(0, eng.tmp, 0, n)
                val w = channel.write(ByteBuffer.wrap(eng.tmp, 0, n))
                if (w <= 0) break
                toRemote.discard(w)
            }
            if (toRemote.size == 0 && clientFin && !remoteShut) {
                remoteShut = true
                channel.shutdownOutput()
            }
        } catch (e: IOException) {
            reset()
            return
        }
        updateInterest()
        if (lastAvail < REMOTE_CAP / 4 && (REMOTE_CAP - toRemote.size) >= REMOTE_CAP / 2) sendAck()
    }

    // ------------------------------------------------------------------ remote -> app

    override fun onReadable() {
        if (st != St.ESTABLISHED) return
        val room = OUT_CAP - out.size
        if (room <= 0) {
            updateInterest()
            return
        }
        val bb = eng.readBuf
        bb.clear()
        bb.limit(minOf(room, bb.capacity()))
        var n = 0
        try {
            n = channel.read(bb)
        } catch (e: IOException) {
            reset()
            return
        }
        lastActivity = eng.now()
        if (n < 0) {
            remoteEof = true
        } else if (n > 0) {
            bb.flip()
            bb.get(eng.tmp, 0, n)
            out.append(eng.tmp, 0, n)
            eng.addBytesDown(uid, n)
        }
        pump()
        updateInterest()
    }

    /** Sends as much buffered remote data as the app's window allows, then the FIN if the remote closed. */
    private fun pump() {
        if (st != St.ESTABLISHED) return
        while (!finSent) {
            val inflight = sndNxt - sndUna
            val unsent = out.size - inflight
            if (unsent <= 0) break
            val room = peerWnd - inflight
            if (room <= 0) break
            val n = minOf(unsent, room, mss)
            out.peek(inflight, eng.tmp, 0, n)
            val push = if (n == unsent) TcpFlags.PSH else 0
            send(TcpFlags.ACK or push, sndNxt, rcvNxt, null, eng.tmp, 0, n, advWindow())
            sndNxt += n
            if ((sndMax - sndNxt) < 0) sndMax = sndNxt
            if (rtoAt == 0L) rtoAt = eng.now() + rtoMs
        }
        if (remoteEof && !finSent && out.size - (sndNxt - sndUna) <= 0) {
            send(TcpFlags.FIN or TcpFlags.ACK, sndNxt, rcvNxt, null, null, 0, 0, advWindow())
            finSent = true
            finSeq = sndNxt
            sndNxt += 1
            if ((sndMax - sndNxt) < 0) sndMax = sndNxt
            if (rtoAt == 0L) rtoAt = eng.now() + rtoMs
        }
    }

    private fun retransmit(isTimeout: Boolean) {
        if (isTimeout) {
            rexmits++
            if (rexmits > MAX_REXMIT) {
                reset()
                return
            }
            rtoMs = minOf(rtoMs * 2, RTO_MAX_MS)
        }
        dupAcks = 0
        sndNxt = sndUna
        if (!finAcked) finSent = false
        rtoAt = eng.now() + rtoMs
        pump()
    }

    private fun probe(now: Long) {
        probeAt = now + 1000
        val inflight = sndNxt - sndUna
        if (out.size - inflight <= 0) return
        out.peek(inflight, eng.tmp, 0, 1)
        send(TcpFlags.ACK, sndNxt, rcvNxt, null, eng.tmp, 0, 1, advWindow())
        sndNxt += 1
        if ((sndMax - sndNxt) < 0) sndMax = sndNxt
        if (rtoAt == 0L) rtoAt = now + rtoMs
    }

    private companion object {
        const val REMOTE_CAP = 262144
        const val OUT_CAP = 262144
        const val WRITE_CHUNK = 65536
        const val OUR_SHIFT = 4
        const val MAX_WND = 16L * 1024L * 1024L
        const val RTO_INITIAL_MS = 300L
        const val RTO_MAX_MS = 4000L
        const val MAX_REXMIT = 8
        const val CONNECT_TIMEOUT_MS = 20_000L
        const val IDLE_MS = 4L * 3600L * 1000L
        const val HALF_IDLE_MS = 120_000L
    }
}
