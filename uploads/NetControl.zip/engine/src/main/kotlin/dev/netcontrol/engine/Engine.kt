package dev.netcontrol.engine

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.CancelledKeyException
import java.nio.channels.ClosedSelectorException
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

internal data class FlowKey(val proto: Int, val src: Addr, val sport: Int, val dst: Addr, val dport: Int)

internal interface FlowHandler {
    fun onConnectable()
    fun onReadable()
    fun onWritable()
    fun abortFlow()
}

class EngineEvent(val atMs: Long, val level: Int, val text: String)

/** Small bounded in-memory log; never contains packet contents or hostnames. */
class EventLog(private val cap: Int = 120) {
    private val q = java.util.ArrayDeque<EngineEvent>()

    @Synchronized
    fun add(level: Int, text: String) {
        if (q.size >= cap) q.removeFirst()
        q.addLast(EngineEvent(System.currentTimeMillis(), level, text))
    }

    @Synchronized
    fun snapshot(): List<EngineEvent> = ArrayList(q)

    companion object {
        const val INFO = 0
        const val WARN = 1
        const val ERROR = 2
    }
}

internal class UidStats {
    @Volatile var tcpFlows = 0L
    @Volatile var udpFlows = 0L
    @Volatile var routedWifi = 0L
    @Volatile var routedCellular = 0L
    @Volatile var blocked = 0L
    @Volatile var violations = 0L
    @Volatile var verified = 0L
    @Volatile var bytesUp = 0L
    @Volatile var bytesDown = 0L
    @Volatile var lastBlock: BlockReason? = null

    fun view(uid: Int): UidStatsView = UidStatsView(
        uid, tcpFlows, udpFlows, routedWifi, routedCellular, blocked, violations, verified,
        bytesUp, bytesDown, lastBlock
    )
}

class UidStatsView(
    val uid: Int,
    val tcpFlows: Long,
    val udpFlows: Long,
    val routedWifi: Long,
    val routedCellular: Long,
    val blocked: Long,
    val violations: Long,
    val verifiedFlows: Long,
    val bytesUp: Long,
    val bytesDown: Long,
    val lastBlock: BlockReason?
)

class EngineSnapshot(
    val uptimeMs: Long,
    val activeTcp: Int,
    val activeUdp: Int,
    val packetsIn: Long,
    val packetsOut: Long,
    val flowsBlocked: Long,
    val connectFailures: Long,
    val violations: Long,
    val unparsed: Long,
    val otherDropped: Long,
    val inboundDropped: Long,
    val dnsAttributed: Long,
    val dnsUnattributed: Long,
    val perUid: Map<Int, UidStatsView>,
    val events: List<EngineEvent>
)

/**
 * User-space packet engine. Reads IP packets from the tunnel, terminates TCP/UDP locally, and
 * re-opens each flow on the uplink chosen by the [RoutingTable] (or drops/resets it). All flow
 * state is owned by the single engine thread.
 */
class Engine(
    private val cfg: EngineConfig,
    private val tunIn: InputStream,
    private val tunOut: OutputStream,
    private val sockets: SocketProvider,
    private val uids: UidResolver
) {
    val events = EventLog()

    /** Invoked from the reader thread if the tunnel stops delivering packets while running. */
    @Volatile
    var onTunnelClosed: ((String) -> Unit)? = null

    internal val mtu: Int = cfg.mtu
    internal val selector: Selector = Selector.open()
    internal val tmp = ByteArray(65536)
    internal val readBuf: ByteBuffer = ByteBuffer.allocateDirect(65536)

    private val inbound = ArrayBlockingQueue<ByteArray>(4096)
    private val commands = ConcurrentLinkedQueue<Runnable>()
    private val wakePending = AtomicBoolean(false)

    @Volatile private var running = false
    @Volatile private var table: RoutingTable = RoutingTable.EMPTY
    private var loopThread: Thread? = null
    private var readerThread: Thread? = null
    private var startedAt = 0L
    private var lastWriteWarn = 0L

    private val tcp = HashMap<FlowKey, TcpFlow>()
    private val udp = HashMap<FlowKey, UdpFlow>()
    private val reasm = Reassembler()
    private val statsMap = ConcurrentHashMap<Int, UidStats>()
    private val loggedBlocks = HashSet<Long>()

    @Volatile private var activeTcp = 0
    @Volatile private var activeUdp = 0
    @Volatile private var packetsIn = 0L
    @Volatile private var packetsOut = 0L
    @Volatile private var flowsBlocked = 0L
    @Volatile private var connectFailures = 0L
    @Volatile private var violations = 0L
    @Volatile private var unparsed = 0L
    @Volatile private var otherDropped = 0L
    @Volatile private var inboundDropped = 0L
    @Volatile private var dnsAttributed = 0L
    @Volatile private var dnsUnattributed = 0L

    // ---------------------------------------------------------------- lifecycle

    fun start() {
        if (running) return
        running = true
        startedAt = now()
        readerThread = Thread({ readLoop() }, "nc-tun-reader").also {
            it.isDaemon = true
            it.start()
        }
        loopThread = Thread({ mainLoop() }, "nc-engine").also {
            it.isDaemon = true
            it.start()
        }
    }

    /** Stops the engine. [closeTun] must close the tunnel descriptor so the blocked reader returns. */
    fun stop(closeTun: () -> Unit) {
        val wasRunning = running
        running = false
        try {
            selector.wakeup()
        } catch (e: Exception) {
            // selector already closed
        }
        try {
            closeTun()
        } catch (e: Exception) {
            // best effort
        }
        try {
            tunIn.close()
        } catch (e: IOException) {
            // best effort
        }
        if (wasRunning) {
            try {
                loopThread?.join(2000)
                readerThread?.join(500)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
    }

    fun updateRouting(t: RoutingTable) {
        table = t
        post(Runnable {
            loggedBlocks.clear()
            reevaluate()
        })
    }

    fun snapshot(): EngineSnapshot {
        val per = HashMap<Int, UidStatsView>()
        for ((uid, s) in statsMap) per[uid] = s.view(uid)
        return EngineSnapshot(
            if (startedAt == 0L) 0L else now() - startedAt,
            activeTcp, activeUdp, packetsIn, packetsOut, flowsBlocked, connectFailures, violations,
            unparsed, otherDropped, inboundDropped, dnsAttributed, dnsUnattributed, per, events.snapshot()
        )
    }

    private fun post(r: Runnable) {
        commands.add(r)
        wake()
    }

    private fun wake() {
        if (!wakePending.getAndSet(true)) {
            try {
                selector.wakeup()
            } catch (e: Exception) {
                // closed
            }
        }
    }

    // ---------------------------------------------------------------- threads

    private fun readLoop() {
        val buf = ByteArray(65536)
        var reason = "tunnel closed"
        while (running) {
            var n = 0
            try {
                n = tunIn.read(buf)
            } catch (e: IOException) {
                reason = "tunnel read ended: " + (e.message ?: "closed")
                break
            }
            if (n < 0) break
            if (n == 0) {
                try {
                    Thread.sleep(2)
                } catch (e: InterruptedException) {
                    break
                }
                continue
            }
            if (inbound.offer(buf.copyOf(n))) wake() else inboundDropped++
        }
        if (running) {
            events.add(EventLog.ERROR, reason)
            onTunnelClosed?.invoke(reason)
        }
    }

    private fun mainLoop() {
        var lastTick = now()
        try {
            while (running) {
                try {
                    if (inbound.isEmpty() && commands.isEmpty()) selector.select(TICK_MS) else selector.selectNow()
                    wakePending.set(false)
                    drainCommands()
                    handleKeys()
                    drainInbound()
                    val t = now()
                    if (t - lastTick >= TICK_MS) {
                        tick(t)
                        lastTick = t
                    }
                } catch (e: ClosedSelectorException) {
                    break
                } catch (e: IOException) {
                    events.add(EventLog.ERROR, "engine io error: " + e.message)
                } catch (e: RuntimeException) {
                    events.add(EventLog.ERROR, "engine error: $e")
                }
            }
        } finally {
            shutdownAll()
        }
    }

    private fun drainCommands() {
        while (true) {
            val r = commands.poll() ?: break
            try {
                r.run()
            } catch (e: RuntimeException) {
                events.add(EventLog.ERROR, "command error: $e")
            }
        }
    }

    private fun handleKeys() {
        val keys = selector.selectedKeys()
        if (keys.isEmpty()) return
        val it = keys.iterator()
        while (it.hasNext()) {
            val k = it.next()
            it.remove()
            val h = k.attachment() as? FlowHandler ?: continue
            try {
                if (k.isValid && k.isConnectable) h.onConnectable()
                if (k.isValid && k.isReadable) h.onReadable()
                if (k.isValid && k.isWritable) h.onWritable()
            } catch (e: CancelledKeyException) {
                // flow closed while handling
            } catch (e: RuntimeException) {
                events.add(EventLog.ERROR, "flow error: $e")
                h.abortFlow()
            }
        }
    }

    private fun drainInbound() {
        var count = 0
        while (count < 256) {
            val p = inbound.poll() ?: break
            count++
            try {
                handlePacket(p)
            } catch (e: RuntimeException) {
                events.add(EventLog.ERROR, "packet error: $e")
            }
        }
    }

    private fun tick(now: Long) {
        for (f in ArrayList(tcp.values)) f.tick(now)
        for (f in ArrayList(udp.values)) f.tick(now)
        reasm.expire(now)
    }

    private fun shutdownAll() {
        for (f in ArrayList(tcp.values)) f.shutdown()
        for (f in ArrayList(udp.values)) f.shutdown()
        try {
            selector.close()
        } catch (e: IOException) {
            // ignore
        }
        inbound.clear()
    }

    private fun reevaluate() {
        val t = table
        for (f in ArrayList(tcp.values)) {
            val d = t.decide(f.uid)
            if (d !is Decision.Route || d.uplink.id != f.uplink.id) f.reset()
        }
        for (f in ArrayList(udp.values)) {
            val d = t.decide(f.uid)
            if (d !is Decision.Route || d.uplink.id != f.uplink.id) f.shutdown()
        }
    }

    // ---------------------------------------------------------------- packet handling

    private fun handlePacket(raw: ByteArray) {
        packetsIn++
        val ip = IpParser.parse(raw, raw.size)
        if (ip == null) {
            unparsed++
            return
        }
        var pkt: IpPacket = ip
        if (ip.isFragment) {
            val whole = reasm.offer(ip, now()) ?: return
            pkt = whole
        }
        when (pkt.protocol) {
            Proto.TCP -> handleTcp(pkt)
            Proto.UDP -> handleUdp(pkt)
            else -> otherDropped++
        }
    }

    private fun isVirtualDns(a: Addr): Boolean = a == cfg.dns4 || (cfg.dns6 != null && a == cfg.dns6)

    private fun countDns(uid: Int) {
        if (table.rules.containsKey(uid)) dnsAttributed++ else dnsUnattributed++
    }

    private fun handleTcp(p: IpPacket) {
        val seg = TcpSeg.parse(p) ?: return
        val key = FlowKey(Proto.TCP, p.src, seg.srcPort, p.dst, seg.dstPort)
        val flow = tcp[key]
        if (flow != null) {
            flow.onSegment(seg, p.data)
            return
        }
        if (seg.syn && !seg.hasAck) {
            openTcp(p, seg, key)
        } else if (!seg.rst) {
            sendRstFor(p, seg)
        }
    }

    private fun openTcp(p: IpPacket, seg: TcpSeg, key: FlowKey) {
        val uid = uids.uidOf(
            Proto.TCP,
            InetSocketAddress(p.src.toInet(), seg.srcPort),
            InetSocketAddress(p.dst.toInet(), seg.dstPort)
        )
        val isDns = isVirtualDns(p.dst)
        if (isDns) countDns(uid)
        if (isDns && seg.dstPort != 53) {
            block(uid, BlockReason.DNS_PORT_UNSUPPORTED, true)
            sendRstFor(p, seg)
            return
        }
        if (tcp.size >= MAX_TCP) {
            block(uid, BlockReason.TABLE_FULL, false)
            sendRstFor(p, seg)
            return
        }
        val uplink: Uplink = when (val d = table.decide(uid)) {
            is Decision.Route -> d.uplink
            is Decision.Block -> {
                block(uid, d.reason, false)
                sendRstFor(p, seg)
                return
            }
        }
        var target: InetAddress = p.dst.toInet()
        var port = seg.dstPort
        if (isDns) {
            val server = uplink.dns.firstOrNull()
            if (server == null) {
                block(uid, BlockReason.DNS_UNAVAILABLE, false)
                sendRstFor(p, seg)
                return
            }
            target = server.toInet()
            port = 53
        }
        val ch: SocketChannel = try {
            sockets.openTcp(uplink)
        } catch (e: IOException) {
            connectFailures++
            block(uid, BlockReason.SOCKET_FAILURE, false)
            events.add(EventLog.WARN, "socket setup failed for uid=$uid: " + e.message)
            sendRstFor(p, seg)
            return
        }
        val flow = TcpFlow(this, key, uid, uplink, isDns, ch, seg, p.version)
        try {
            ch.configureBlocking(false)
            ch.socket().tcpNoDelay = true
            flow.selKey = ch.register(selector, SelectionKey.OP_CONNECT, flow)
            tcp[key] = flow
            activeTcp = tcp.size
            stats(uid).tcpFlows++
            if (ch.connect(InetSocketAddress(target, port))) flow.onConnected()
        } catch (e: IOException) {
            flow.connectFailed(e.message ?: "connect failed")
        }
    }

    private fun handleUdp(p: IpPacket) {
        val u = UdpDgram.parse(p) ?: return
        val key = FlowKey(Proto.UDP, p.src, u.srcPort, p.dst, u.dstPort)
        val flow = udp[key]
        if (flow != null) {
            flow.onDatagram(p.data, u.payloadOff, u.payloadLen)
            return
        }
        openUdp(p, u, key)
    }

    private fun openUdp(p: IpPacket, u: UdpDgram, key: FlowKey) {
        val uid = uids.uidOf(
            Proto.UDP,
            InetSocketAddress(p.src.toInet(), u.srcPort),
            InetSocketAddress(p.dst.toInet(), u.dstPort)
        )
        val isDns = isVirtualDns(p.dst)
        if (isDns) countDns(uid)
        if (isDns && u.dstPort != 53) {
            block(uid, BlockReason.DNS_PORT_UNSUPPORTED, true)
            emit(PacketBuilder.icmpUnreachable(p))
            return
        }
        if (udp.size >= MAX_UDP) {
            block(uid, BlockReason.TABLE_FULL, false)
            return
        }
        val uplink: Uplink = when (val d = table.decide(uid)) {
            is Decision.Route -> d.uplink
            is Decision.Block -> {
                block(uid, d.reason, false)
                emit(PacketBuilder.icmpUnreachable(p))
                return
            }
        }
        val targets: List<InetSocketAddress> = if (isDns) {
            uplink.dns.map { InetSocketAddress(it.toInet(), 53) }
        } else {
            listOf(InetSocketAddress(p.dst.toInet(), u.dstPort))
        }
        if (targets.isEmpty()) {
            block(uid, BlockReason.DNS_UNAVAILABLE, false)
            emit(PacketBuilder.icmpUnreachable(p))
            return
        }
        val ch: java.nio.channels.DatagramChannel = try {
            sockets.openUdp(uplink)
        } catch (e: IOException) {
            connectFailures++
            block(uid, BlockReason.SOCKET_FAILURE, false)
            events.add(EventLog.WARN, "udp socket setup failed for uid=$uid: " + e.message)
            emit(PacketBuilder.icmpUnreachable(p))
            return
        }
        try {
            ch.configureBlocking(false)
            if (!isDns) {
                ch.connect(targets[0])
                if (checkRoute(uid, uplink, ch.socket().localAddress) == ROUTE_VIOLATION) {
                    block(uid, BlockReason.ROUTE_VIOLATION, false)
                    try {
                        ch.close()
                    } catch (e: IOException) {
                        // ignore
                    }
                    emit(PacketBuilder.icmpUnreachable(p))
                    return
                }
            }
            val flow = UdpFlow(this, key, uid, uplink, isDns, ch, targets)
            flow.selKey = ch.register(selector, SelectionKey.OP_READ, flow)
            udp[key] = flow
            activeUdp = udp.size
            stats(uid).udpFlows++
            noteRouted(uid, uplink.transport)
            flow.onDatagram(p.data, u.payloadOff, u.payloadLen)
        } catch (e: IOException) {
            connectFailures++
            try {
                ch.close()
            } catch (e2: IOException) {
                // ignore
            }
            emit(PacketBuilder.icmpUnreachable(p))
        }
    }

    private fun sendRstFor(p: IpPacket, seg: TcpSeg) {
        val bytes = if (seg.hasAck) {
            PacketBuilder.tcp(p.dst, p.src, seg.dstPort, seg.srcPort, seg.ack, 0, TcpFlags.RST, 0, null, null, 0, 0)
        } else {
            val ackNo = seg.seq + seg.payloadLen + (if (seg.syn) 1 else 0) + (if (seg.fin) 1 else 0)
            PacketBuilder.tcp(
                p.dst, p.src, seg.dstPort, seg.srcPort, 0, ackNo,
                TcpFlags.RST or TcpFlags.ACK, 0, null, null, 0, 0
            )
        }
        emit(bytes)
    }

    private fun block(uid: Int, reason: BlockReason, quiet: Boolean) {
        val s = stats(uid)
        s.blocked++
        s.lastBlock = reason
        flowsBlocked++
        if (!quiet) {
            val k = (uid.toLong() shl 8) or reason.ordinal.toLong()
            if (loggedBlocks.add(k)) events.add(EventLog.INFO, "blocked flow uid=$uid reason=$reason")
        }
    }

    // ---------------------------------------------------------------- services for flows

    internal fun now(): Long = System.nanoTime() / 1_000_000L

    internal fun stats(uid: Int): UidStats = statsMap.getOrPut(uid) { UidStats() }

    internal fun emit(bytes: ByteArray) {
        try {
            tunOut.write(bytes)
            packetsOut++
        } catch (e: IOException) {
            val t = now()
            if (running && t - lastWriteWarn > 2000) {
                lastWriteWarn = t
                events.add(EventLog.WARN, "tunnel write failed: " + e.message)
            }
        }
    }

    internal fun emitUdpToClient(key: FlowKey, d: ByteArray, off: Int, len: Int) {
        val pkt = PacketBuilder.udp(key.dst, key.src, key.dport, key.sport, d, off, len)
        for (f in Fragmenter.split(pkt, mtu)) emit(f)
    }

    internal fun addBytesUp(uid: Int, n: Int) {
        stats(uid).bytesUp += n.toLong()
    }

    internal fun addBytesDown(uid: Int, n: Int) {
        stats(uid).bytesDown += n.toLong()
    }

    internal fun noteRouted(uid: Int, t: Transport) {
        val s = stats(uid)
        if (t == Transport.WIFI) s.routedWifi++ else s.routedCellular++
    }

    internal fun noteConnectFailure(msg: String) {
        connectFailures++
        events.add(EventLog.INFO, "connect failed: $msg")
    }

    internal fun removeTcp(f: TcpFlow) {
        if (tcp.remove(f.key) === f) activeTcp = tcp.size
    }

    internal fun removeUdp(f: UdpFlow) {
        if (udp.remove(f.key) === f) activeUdp = udp.size
    }

    /**
     * Verifies that a connected socket really uses the uplink it was bound to: the local address
     * must not belong to the other physical network.
     */
    internal fun checkRoute(uid: Int, uplink: Uplink, local: InetAddress?): Int {
        if (local == null || local.isAnyLocalAddress) return ROUTE_UNKNOWN
        val a = Addr.of(local)
        val s = stats(uid)
        if (uplink.addresses.contains(a)) {
            s.verified++
            return ROUTE_OK
        }
        val t = table
        val other = if (uplink.transport == Transport.WIFI) t.cellular else t.wifi
        if (other != null && other.addresses.contains(a)) {
            s.violations++
            violations++
            events.add(
                EventLog.ERROR,
                "ROUTE VIOLATION uid=$uid: socket bound to ${uplink.transport} used a ${other.transport} address"
            )
            return ROUTE_VIOLATION
        }
        return ROUTE_UNKNOWN
    }

    companion object {
        const val ROUTE_OK = 0
        const val ROUTE_UNKNOWN = 1
        const val ROUTE_VIOLATION = 2

        private const val TICK_MS = 250L
        private const val MAX_TCP = 4096
        private const val MAX_UDP = 2048
    }
}
