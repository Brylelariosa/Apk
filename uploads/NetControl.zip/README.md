# NetControl

Per-app internet connection manager for Android (no root). For every installed app you choose:

| Mode | Behavior |
|------|----------|
| Wi-Fi Only | Uses Wi-Fi, never mobile data. If Wi-Fi drops the app loses internet instead of falling back. |
| Mobile Data Only | Uses mobile data, never Wi-Fi. If mobile data is unavailable the app loses internet. |
| Automatic | Normal Android behavior. The app is not routed through NetControl at all. |
| Block Internet | No internet on Wi-Fi or mobile data. |

Wi-Fi and mobile data stay enabled at the same time.

## How it works (short)

* A local VPN is created with `addAllowedApplication()` for **only** the apps that have a custom rule.
  Everything else (including NetControl itself) never enters the tunnel.
* A user-space packet engine (module `engine`, pure Kotlin) terminates each TCP connection / UDP flow
  of those apps and opens it again with a socket bound to the chosen physical network
  (`Network.bindSocket()`, plus `VpnService.protect()`).
* The owner of each flow is found with `ConnectivityManager.getConnectionOwnerUid()` (API 29+).
* If the chosen network is missing the flow is reset (TCP RST / ICMP unreachable). There is no fallback.
* After connecting, the engine checks the socket source address; a socket that landed on the wrong
  network is dropped and reported as a routing violation.

See `docs/ARCHITECTURE.md` for the design, DNS/IPv6/fragmentation handling and the limits.

## Requirements

* Android 10 (API 29) or newer. (`getConnectionOwnerUid` does not exist before API 29.)
* Build: JDK 17, Gradle 8.6, Android Gradle Plugin 8.3.2, Kotlin 1.9.24, compileSdk 34.
  These match the existing GitHub Actions pipeline (JDK 17, Gradle 8.6).

## Build

```
gradle :app:assembleRelease          # or ./gradlew :app:assembleRelease
gradle :engine:test                  # JVM unit tests (packet codec, fragmentation, routing policy)
```

Output: `app/build/outputs/apk/release/app-release.apk` (signed, installable).
After `assembleRelease` the log prints lines starting with `NETCONTROL_APK_REPORT:` with the real APK size
in bytes/MB and the number of `lib/` entries (0 means no ABI-specific code).

* One universal APK, **no ABI splits**, no native libraries.
* R8 minification, resource shrinking, English-only resources, dependency metadata removed.
* `gradlew` downloads the official `gradle-wrapper.jar` for Gradle 8.6 on first use because a binary jar
  cannot be shipped in a text-only source drop. If your workflow uses its own Gradle, `gradlew` is not needed.

### Signing

`app/signing/netcontrol-release.p12` is a personal-use key stored with the project so every CI build has the
same signature and updates install over each other. Override with the environment variables
`NETCONTROL_KEYSTORE`, `NETCONTROL_STORE_PASSWORD`, `NETCONTROL_KEY_ALIAS`, `NETCONTROL_KEY_PASSWORD`.
Do not publish builds signed with this key.

## Project layout

```
engine/   pure Kotlin/JVM packet engine (IP/TCP/UDP codec, fragmentation, flows, routing table) + tests
app/      Android app: Compose UI, VpnService, network monitor, DataStore, diagnostics
docs/     ARCHITECTURE.md, TEST_REPORT.md
PRIVACY.md
```

## Status of verification

Read `docs/TEST_REPORT.md`. In short: the code was written and statically checked without a compiler or a
device. Compilation, the unit tests, the APK size, and every on-device networking test (A to H) still have to
be run by the build pipeline and on a phone. Nothing in this project reports a policy as "Protected"
unless the running service has applied it and the route has been verified at run time.
