# NetControl privacy statement

NetControl works entirely on your phone.

* Rules, settings and the list of apps are stored only on the device. Nothing is uploaded.
* There is no account, no analytics, no advertising and no tracking. NetControl contains no third-party
  code that sends data.
* The VPN is local. Traffic of apps with a custom rule passes through NetControl on the device and is
  forwarded directly to the network you chose. No NetControl server exists.
* NetControl does not record packet contents, web addresses or browsing history. It keeps only counters
  (for example number of connections and bytes) and short technical events in memory. They are cleared when
  the service stops.
* The diagnostic report contains network state, package names of apps with rules, counters and technical
  events. It is created only when you copy or save it. You decide whether to share it.

Permissions used: Internet (to forward the traffic of your apps), network state, change network state (to
keep mobile data available), foreground service and notifications (status notification), boot completed
(restore protection after a restart) and package visibility (to list installed apps).
