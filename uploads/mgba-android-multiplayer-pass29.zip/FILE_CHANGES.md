# FILE_CHANGES — Twenty-first pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** real-device bug report — Storage folder feature broke save/load.
See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Removed `NativeHandle` and `SaveEntry.nativePath()` — the `/proc/self/fd/<N>`
  bridge in its entirety.
- `SaveEntry.outputStream()`: now opens with explicit `"wt"` mode (was the
  2-arg `openOutputStream(uri)` default), so a write shorter than the
  previous save can't leave stale trailing bytes on providers that don't
  truncate on plain `"w"`.
- New `SaveEntry` methods: `stageForRead()`, `stageForWrite()`,
  `commitWrite()` (one-shot save-state/quicksave/thumbnail read/write —
  stage a SAF document's bytes to/from a local cache file, native only
  ever touches the local file) and `batteryMirrorPath()`,
  `syncBatteryMirror()` (session-long battery save — local mirror file the
  core mmaps for the whole session, synced out to the real document at a
  handful of call sites, not continuously).
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`: rewired
  from `entry.nativePath(...).use { }` to the new stage/commit methods.
- `loadRomFromUri()`/`resetGame()`: rewired from `saveEntry.nativePath(...)`
  to `saveEntry.batteryMirrorPath()`; `loadRomFromUri()` also now syncs the
  *outgoing* ROM's mirror before swapping in a new one.
- `onPause()`/`onDestroy()`/`closeGame()`: each now calls
  `syncBatteryMirror()` for the currently-loaded ROM, so the chosen
  folder's copy doesn't just sit stale until the app happens to reload a
  ROM again.

---

# FILE_CHANGES — Twentieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** new Storage-folder feature — see CHANGELOG.md/FEATURES_ADDED.md.
**What changed:**
- New `PREF_DATA_FOLDER_URI`, `dataFolderPicker` (SAF tree picker, mirrors
  the existing `romTreePicker`), `dataFolderTree()`, `dataSubfolder()`.
- New `SaveEntry` (inner class) + `NativeHandle`: the abstraction that
  lets every save-adjacent file live in either internal storage or the
  chosen folder transparently, including the `/proc/self/fd/<N>` bridge
  for native calls — see that class's own comment for the full mechanism.
- `batterySaveEntry()`/`stateSlotEntry()`/`stateThumbEntry()`/
  `quickStateEntry()`: thin wrappers over the existing (now "legacy",
  still the fallback) `batterySaveFile()`/`stateSlotFile()`/
  `stateThumbFile()`/`quickStateFile()`.
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`/
  `captureStateThumbnail()`/`backupIfExists()`/both `nativeLoadROM()` call
  sites (initial load + `resetGame()`): rewired from raw `File` to
  `SaveEntry`.
- `saveScreenshotBitmap()`: writes into the `screenshot` subfolder when a
  folder's chosen; unchanged `getExternalFilesDir()` fallback otherwise.
- New `showStorageSettings()` + a "Storage" row in the Settings menu.

---

# FILE_CHANGES — Nineteenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** This pass's two log captures covered different real-world spans
with no quick way to tell how different, or why.
**What changed:** `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line (same layout as the log's own timestamps) to
the text before it's shown/copied.

### `app/src/main/cpp/mgba_jni.c`
**Why:** record-keeping only.
**What changed:** New FIX 19 entry in the top-of-file history noting
Eighteenth pass's fix showed no observed change in this capture, and
pointing at the MainActivity.kt change above. No logic changed in this
file this pass.

---

# FILE_CHANGES — Eighteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** First real matched two-phone capture (see CHANGELOG.md/
KNOWN_LIMITATIONS.md) confirmed the network exchange is correct in both
directions, narrowing the still-open bug to the child ROM's own code.
Re-reading `nativeLinkChildExchange()` against that finding turned up a
gap the function's own comment already admitted: it never touched the
child device's own SIOCNT.
**What changed:**
- `nativeLinkChildExchange()`: after writing SIOMULTI0-3 and before
  raising the IRQ, now reads the child's current SIOCNT and refreshes
  bits 2 (child), 3 (ready), 4-5 (player ID), and clears bit 7 (busy) —
  preserving every other bit (mode, baud rate, IRQ-enable) exactly as the
  ROM last set it.
- Updated that function's own top comment (previously said it
  "deliberately does NOT touch SIOCNT"; no longer true).
- New FIX 18 entry in the file's top-of-file history comment.

---

# FILE_CHANGES — Seventeenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** `copyLinkDebugLog()`'s `logcat` dependency doesn't work on every
device (W's own two-phone split this pass — real output on one, nothing on
the other) and was blocking the one thing every pass since the Twelfth has
asked for: a synchronized two-phone capture. Separately, W's new
`wifi_host__1_.text`/`wifi_join__1_.text` captures (taken with Sixteenth
pass's exchange-result/child-exchange logging already in place) needed a
close read.
**What changed:**
- New includes: `<stdarg.h>`, `<stdio.h>`, `<time.h>`.
- `LOGI`/`LOGW`/`LOGE` macros now expand to a new `jni_log_line()` instead
  of calling `__android_log_print()` directly. Every existing call site in
  the file is unchanged — these are still plain macros.
- New: `g_link_log_mutex` (dedicated lock, never `g_core_mutex` — see its
  own comment for why reusing `g_core_mutex` would self-deadlock),
  `g_link_log_file`, `g_link_log_path`, `link_log_write_locked()`,
  `link_log_write()`, `jni_log_line()`. Together: every `LOGI`/`LOGW`/
  `LOGE` call now also appends a logcat-`threadtime`-formatted line to a
  private file, in addition to the normal `__android_log_print()` call
  (unchanged — Android Studio / a real debugger sees no difference).
- New: `Java_com_mgba_android_EmulatorEngine_nativeSetLinkLogPath()` —
  receives the file path from Kotlin once at startup, opens it in append
  mode.
- `nativeLinkStart()`: now re-opens the log file in truncate mode
  (`fopen(path, "w")`) at the start of every session, so a capture
  reflects one connection attempt.
- Top-of-file fix-history comment: added a FIX 17 entry covering both the
  logging infrastructure and this pass's reading of the new evidence
  (host/child value distributions, the re-check of FIX 9's bit2/bit3
  reflection, and an updated theory citing mGBA's own real lockstep
  implementation).
**Why this fixes it:** The logging change directly addresses "can't get
log on this device" — see FIX 17's own comment. It doesn't fix the
reported multiplayer bug itself; see KNOWN_LIMITATIONS.md for what this
pass's evidence actually shows and BUGS_FIXED.md for why this isn't
labeled a bug fix.
**Verification:** No NDK/Android SDK in this sandbox, as every pass — but
unlike every prior pass, this sandbox does have a plain `gcc`. The new
logging functions (`link_log_write_locked`, `link_log_write`,
`jni_log_line`, the macros, `nativeSetLinkLogPath`, and
`nativeLinkStart()`'s new truncate block) were extracted verbatim from the
edited file — not retyped — and compiled standalone against minimal
stand-ins for the Android/JNI-only pieces (`__android_log_print`, `JNIEnv`'s
`GetStringUTFChars`/`ReleaseStringUTFChars`), since the real NDK/mgba
headers aren't available here either. Compiled clean under
`gcc -Wall -Wextra -std=gnu11` (no explicit `C_STANDARD` is pinned in this
project's `CMakeLists.txt`, so this matches the NDK/Clang default
GNU-extended dialect rather than glibc's stricter plain `-std=c11`, which
does not expose `clock_gettime`/`CLOCK_REALTIME` without extra feature-test
macros — confirmed by hitting exactly that failure first and fixing the
*test's* dialect flag, not the real code, which needs no such fix under
the NDK). At runtime: opens the file, writes/reads back formatted lines
correctly, confirms a second `nativeSetLinkLogPath()` call appends rather
than truncates (per its own doc comment), and confirms `nativeLinkStart()`'s
new block does truncate. This is real verification of the new code's
syntax and logic that no prior pass in this project's history could do
("no compiler here" appears in nearly every previous pass's own
Verification section) — it is not a substitute for a real
`./gradlew assembleDebug` against the actual mgba/NDK headers, which
remains untested as always. Brace/paren counts on the full file checked
balanced before and after (68/68 braces, 363/363 parens).

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Kotlin-side declaration for the new native entry point.
**What changed:** Added `external fun nativeSetLinkLogPath(path: String):
Boolean` with a doc comment explaining when to call it and its
relationship to `nativeLinkStart()`'s truncation.
**Verification:** No Kotlin compiler in this sandbox. Signature matches
the JNI export name (`Java_com_mgba_android_EmulatorEngine_
nativeSetLinkLogPath`) exactly, following the same `Java_<package>_<class>_
<method>` pattern already proven by every other `external fun` in this
file (spot-checked against `nativeLinkStart`'s own export name). File-wide
brace/paren balance checked programmatically (comment- and string-aware,
not just a raw character count) — clean.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** See `mgba_jni.c` above — this is the Kotlin half of the same
change.
**What changed:**
- `onCreate()`: added one `EmulatorEngine.nativeSetLinkLogPath(...)` call
  right after `link = LinkMultiplayer(this)`, passing
  `File(filesDir, "link_debug.log").absolutePath`.
- `copyLinkDebugLog()`: no longer builds a `logcat` `Process` at all — now
  just reads `File(filesDir, "link_debug.log")` directly. Simpler than
  what it replaced (no `ProcessBuilder`/stream-draining/`waitFor()`), and
  removes the only place in this project that shelled out to a system
  binary for this feature.
- `showLinkDebugLogDialog()`: empty-state message updated to describe the
  new mechanism instead of the old tag-filtered-window one, including a
  pointer to check Logcat for the file-open confirmation line if the file
  is unexpectedly still empty after a real attempt.
- Doc comments above both functions rewritten to describe the new
  mechanism and reference this pass.
**Verification:** No Kotlin compiler here. Single call site of
`copyLinkDebugLog()`/`showLinkDebugLogDialog()` each, both unchanged
(quick-menu item 9 still calls `copyLinkDebugLog()` the same way). File-wide
brace/paren balance checked programmatically — clean.

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** See `mgba_jni.c` above — Fifteenth pass's 7 connection-lifecycle
log lines were logcat-only; without also mirroring them into the new file,
the file-based tool would be strictly less capable than the old
logcat-based one for anyone whose logcat access does work.
**What changed:**
- New imports: `java.io.File`, `java.text.SimpleDateFormat`,
  `java.util.Locale`.
- New `linkLog(level, msg, throwable?)` private helper: calls the normal
  `Log.i`/`Log.w`/`Log.e` (unchanged behavior for anyone watching Logcat
  directly) and additionally appends a matching line to
  `File(context.filesDir, "link_debug.log")`.
- All 7 existing `Log.i`/`Log.w` call sites (the BYE-send logging in
  `disconnect()`, the "Disconnected" line, and `handlePeerLost()`'s
  "Peer connection lost" line) now call `linkLog(...)` instead. No call
  site's actual logged content changed — only the function they go
  through.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No Kotlin compiler here. All 7 original call sites
confirmed replaced (`grep` for `Log\.` now only matches inside `linkLog()`
itself). File-wide brace/paren balance checked programmatically — clean.

---

# FILE_CHANGES — Sixteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** W's three real logcat captures (first genuine evidence in sixteen
passes) showed real exchange activity but left two specific things
unanswerable: whether the host's rapid exchange attempts were getting real
replies or timing out, and whether the child's own receive path
(`nativeLinkChildExchange()`) was ever running at all.
**What changed:**
- `link_sio_write_register()`'s host-only exchange branch: added
  `LOGI("SIO exchange result: sent=... recv=... timedOut=...")` right after
  `link_exchange()` returns.
- `nativeLinkChildExchange()`: added `LOGW` on its early-exit branch
  (previously silent) and `LOGI` on every successful call, logging both
  `hostData` and `childData`. Previously had no logging at all.
- Top-of-file fix-history comment: added a FIX 16 entry summarizing what
  the three logs actually showed and the theory (unconfirmed) that fits.
**Why this fixes it:** It doesn't fix the reported bug — it closes the two
remaining diagnostic blind spots standing between "we have activity" and
"we know what the activity means." See FIX 16's own comment and
CHANGELOG.md items 1-2.
**Verification:** No compiler/device here, as every pass. Brace/paren
counts checked balanced before and after. Both additions are pure logging
— no control flow, register values, or return values changed.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** `copyLinkDebugLog()`'s window (8000 lines, sized last pass against
boot noise) is short relative to real exchange activity's actual measured
rate this pass — `wifi_host.text` alone was 2243 lines in 1.67 seconds,
before this pass's two new trace points add more on top.
**What changed:** `logcat -t 8000` → `-t 20000`. Comment above the function
updated with the real measured numbers behind the bump.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No compiler here. Single call site of the modified
function unchanged.

---

# FILE_CHANGES — Earlier passes (summary)

Full diffs trimmed for length. File(s) touched per pass, condensed:

- **Fifteenth** — `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`:
  Sixteenth/Seventeenth pass's exchange-result/child-exchange trace
  logging groundwork, plus connection-lifecycle logging.
- **Fourteenth** — `MainActivity.kt`: compile-error fix only
  (`showLinkDebugLogDialog` parameter rename).
- **Thirteenth** — `MainActivity.kt`: save-state thumbnails.
- **Twelfth** — `MainActivity.kt`: original logcat-based "Copy link log"
  (superseded by Seventeenth pass's file-based version).
- **Eleventh** — `MainActivity.kt`: quick-menu tap regression fix.
- **Tenth** — `MainActivity.kt`: quick game menu restyle, Settings
  cleanup, immersive mode, display-cutout fix, Screenshot/Reset/Close.
- **Ninth** — `LinkMultiplayer.kt`: Wi-Fi host keepalive/liveness fix.
- **Eighth** — `mgba_jni.c`: trace logging only, no logic change.
- **Seventh** — `mgba_jni.c`: SIO IRQ raise (host + child).
- **Sixth** — `mgba_jni.c`, `EmulatorEngine.kt`, `LinkMultiplayer.kt`,
  `MainActivity.kt`: the original `nativeLinkChildExchange()` passive-
  responder fix, SIOCNT status bits, peer-disconnect detection,
  Bluetooth keepalive.
- **Fifth** — `LinkMultiplayer.kt`, `MainActivity.kt`,
  `AndroidManifest.xml`, `gradle.properties`, `README_SETUP.md`: first
  multiplayer-focused pass — thread-safety, socket cleanup, permissions.
