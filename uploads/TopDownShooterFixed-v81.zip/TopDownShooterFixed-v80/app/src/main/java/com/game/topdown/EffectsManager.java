package com.game.topdown;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Manages and renders all visual-only particle / FX effects.
 *
 * Owned by GameView. Call draw() inside the world-space canvas transform
 * (after scale + translate, before restore).
 */
class EffectsManager {

    // ── Lifetimes ─────────────────────────────────────────────────────────────
    static final long GHOST_LIFE_MS   = 420;
    static final long DASH_ANIM_MS    = 160;

    // ── Epoch reference for float-safe timestamps ──────────────────────────────
    // System.currentTimeMillis() is ~1.7 trillion ms — too large for float (ULP ≈ 131 s).
    // Store (absoluteMs - FX_EPOCH) instead; values stay < 16M ms → float ULP = 1 ms.
    static final long FX_EPOCH = System.currentTimeMillis();

    // ── Explosion rings  [x, y, spawnMs] ─────────────────────────────────────
    final List<long[]>  explosionFx    = new ArrayList<>();

    // ── Client-side bullet hit flash  [x, y, spawnMs] ─────────────────────────
    final List<long[]>  predictedHitFx = new ArrayList<>();

    // ── Shadow Blade slash arc trails  [cx, cy, r, spawnMs, angle, slot] ──────
    final List<float[]> slashTrails    = new ArrayList<>();

    // ── Shadow Blade crescent effect  [cx, cy, angle, spawnMs] ───────────────
    final List<float[]> crescentFx     = new ArrayList<>();

    // ── Local player dash ghost afterimages  [x, y, spawnMs] ─────────────────
    final List<float[]> dashGhosts     = new ArrayList<>();

    // ── Bot dash ghost afterimages  [x, y, spawnMs] ───────────────────────────
    final List<float[]> botDashGhosts  = new ArrayList<>();

    // ── Local player dash animation ───────────────────────────────────────────
    boolean dashAnimating;
    float   dashAnimStartX, dashAnimStartY;
    float   dashAnimEndX,   dashAnimEndY;
    long    dashAnimBegin;

    // ═════════════════════════════════════════════════════════════════════════
    // Status-effect particles  (spawned each frame per affected player)
    // All times stored relative to FX_EPOCH for float-safe comparisons.
    // ═════════════════════════════════════════════════════════════════════════

    // ── Slow particles ─────────────────────────────────────────────────────
    // Mist blob:    [x, y, vx, vy, spawnTimeRel, initRadius]
    final List<float[]> slowMist    = new ArrayList<>();
    // Crystal shard:[x, y, vx, vy, spawnTimeRel, size, rotAngle]
    final List<float[]> slowCrystal = new ArrayList<>();

    // ── Poison particles ───────────────────────────────────────────────────
    // Fume cloud:   [x, y, vx, vy, spawnTimeRel, initRadius]
    final List<float[]> poisonFume   = new ArrayList<>();
    // Drip drop:    [x, y, vy, spawnTimeRel, size]
    final List<float[]> poisonDrip   = new ArrayList<>();
    // Bubble ring:  [cx, cy, spawnTimeRel, maxRadius]
    final List<float[]> poisonBubble = new ArrayList<>();

    // ── Stun/shock particles ───────────────────────────────────────────────
    // Spark:        [x, y, vx, vy, spawnTimeRel, size]
    final List<float[]> stunSpark = new ArrayList<>();
    // Electric arc: [x1, y1, x2, y2, spawnTimeRel]
    final List<float[]> stunArc   = new ArrayList<>();
    // Energy pulse: [cx, cy, spawnTimeRel, maxRadius]
    final List<float[]> stunPulse = new ArrayList<>();

    // ── Particle lifetimes (ms) ────────────────────────────────────────────
    private static final long SLOW_MIST_LIFE    = 700L;
    private static final long SLOW_CRYSTAL_LIFE = 550L;
    private static final long POISON_FUME_LIFE  = 850L;
    private static final long POISON_DRIP_LIFE  = 380L;
    private static final long POISON_BUBBLE_LIFE= 480L;
    private static final long STUN_SPARK_LIFE   = 220L;
    private static final long STUN_ARC_LIFE     = 110L;
    private static final long STUN_PULSE_LIFE   = 280L;

    // ═════════════════════════════════════════════════════════════════════════
    // Spawn helpers
    // ═════════════════════════════════════════════════════════════════════════

    void spawnExplosion(float x, float y) {
        explosionFx.add(new long[]{ (long) x, (long) y, System.currentTimeMillis() });
    }

    void spawnHitFlash(float x, float y) {
        predictedHitFx.add(new long[]{ (long) x, (long) y, System.currentTimeMillis() });
    }

    void spawnCrescent(float x, float y, float angle) {
        crescentFx.add(new float[]{ x, y, angle, (float)(System.currentTimeMillis() - FX_EPOCH) });
    }

    void spawnDashGhost(float x, float y) {
        dashGhosts.add(new float[]{ x, y, (float)(System.currentTimeMillis() - FX_EPOCH) });
    }

    void spawnBotDashGhosts(float fromX, float fromY, float toX, float toY) {
        int numGhosts = 3;
        float dx = toX - fromX, dy = toY - fromY;
        long nowRel = System.currentTimeMillis() - FX_EPOCH;
        for (int i = 0; i <= numGhosts; i++) {
            float t = (float) i / numGhosts;
            botDashGhosts.add(new float[]{
                fromX + dx * t,
                fromY + dy * t,
                (float)(nowRel - (long)(t * 60f))
            });
        }
    }

    void beginDash(float startX, float startY, float endX, float endY) {
        dashAnimStartX = startX; dashAnimStartY = startY;
        dashAnimEndX   = endX;   dashAnimEndY   = endY;
        dashAnimBegin  = System.currentTimeMillis();
        dashAnimating  = true;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Draw — call once per frame inside world-space canvas transform
    // ═════════════════════════════════════════════════════════════════════════

    /** Call BEFORE drawing players — explosions, hit flashes, dash ghost trails. */
    void drawBehindPlayers(Canvas c) {
        drawExplosions(c);
        drawHitFlashes(c);
        drawSlashTrails(c);
        drawDashGhosts(c);
        drawBotDashGhosts(c);
    }

    /** Call AFTER drawing players — crescent appears on top of the player body. */
    void drawInFrontOfPlayers(Canvas c) {
        drawCrescents(c);
    }

    /** Call AFTER drawInFrontOfPlayers — bullets render on top of everything in world space. */
    void drawBullets(Canvas c, List<Bullet> bullets) {
        for (Bullet b : bullets) {
            if (b.isShadowBlade) continue; // shadow blades rendered as arcs in drawPlayer
            float bx = b.x, by = b.y;
            if (b.hookSpear) {
                // Hook spear: small diamond
                Paint hkP = new Paint(Paint.ANTI_ALIAS_FLAG);
                hkP.setStyle(Paint.Style.FILL);
                hkP.setColor(Color.rgb(200, 200, 255));
                Path diamond = new Path();
                diamond.moveTo(bx,       by - 10f);
                diamond.lineTo(bx + 7f,  by);
                diamond.lineTo(bx,       by + 10f);
                diamond.lineTo(bx - 7f,  by);
                diamond.close();
                c.drawPath(diamond, hkP);
            } else {
                int col;
                float br;
                if (b.isSoulReaper) {
                    // Soul Reaper bullets: dark purple with white-hot core, pulsing glow
                    long nowSR = System.currentTimeMillis();
                    float pulse = 0.6f + 0.4f * (float)Math.sin(nowSR / 120.0 + b.id * 1.7f);
                    br = b.explosive ? 11f : 8f;
                    // Outer dark soul glow
                    Paint srGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
                    srGlow.setStyle(Paint.Style.FILL);
                    srGlow.setColor(Color.argb((int)(80 * pulse), 140, 0, 220));
                    c.drawCircle(bx, by, br * 2.8f, srGlow);
                    // Mid purple ring
                    Paint srMid = new Paint(Paint.ANTI_ALIAS_FLAG);
                    srMid.setStyle(Paint.Style.FILL);
                    srMid.setColor(Color.argb((int)(180 * pulse), 180, 30, 255));
                    c.drawCircle(bx, by, br * 1.6f, srMid);
                    // Bright white-purple core
                    Paint srCore = new Paint(Paint.ANTI_ALIAS_FLAG);
                    srCore.setStyle(Paint.Style.FILL);
                    srCore.setColor(Color.argb(240, 230, 180, 255));
                    c.drawCircle(bx, by, br * 0.6f, srCore);
                    // Soul smoke trail (dark wisps behind bullet direction)
                    float spd = (float)Math.sqrt(b.vx*b.vx + b.vy*b.vy);
                    if (spd > 5f) {
                        float nx = -b.vx/spd, ny = -b.vy/spd;
                        Paint smokeP = new Paint(Paint.ANTI_ALIAS_FLAG);
                        smokeP.setStyle(Paint.Style.FILL);
                        for (int t = 1; t <= 4; t++) {
                            float tf = t / 4f;
                            float tx = bx + nx*br*t*2.2f, ty = by + ny*br*t*2.2f;
                            smokeP.setColor(Color.argb((int)(120*(1f-tf)), 100, 0, 180));
                            c.drawCircle(tx, ty, br*(1f-tf*0.6f), smokeP);
                        }
                    }
                    continue; // skip default rendering below
                } else if (b.explosive)     { col = Color.rgb(255, 120,  30); br = 9f; }
                else if (b.paintColor == 1) { col = Color.rgb( 80, 140, 255); br = 6f; }
                else if (b.paintColor == 2) { col = Color.rgb( 60, 220,  80); br = 6f; }
                else if (b.homing)          { col = Color.rgb(255,  60, 200); br = 6f; }
                else if (b.piercing)        { col = Color.rgb(255, 255, 100); br = 6f; }
                else if (b.ghost)           { col = Color.argb(180, 200, 230, 255); br = 6f; }
                else                        { col = Color.rgb(255, 218,   0); br = 6f; }

                // Glow
                Paint glowP = new Paint(Paint.ANTI_ALIAS_FLAG);
                glowP.setStyle(Paint.Style.FILL);
                glowP.setColor(Color.argb(90, Color.red(col), Color.green(col), Color.blue(col)));
                c.drawCircle(bx, by, br * 2f, glowP);

                // Core
                Paint coreP = new Paint(Paint.ANTI_ALIAS_FLAG);
                coreP.setStyle(Paint.Style.FILL);
                coreP.setColor(col);
                c.drawCircle(bx, by, br, coreP);
            }
        }
    }

    // ── Explosion rings ───────────────────────────────────────────────────────
    private void drawExplosions(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<long[]> it = explosionFx.iterator();
        while (it.hasNext()) {
            long[] fx = it.next();
            float age = (now - fx[2]) / 400f;
            if (age >= 1f) { it.remove(); continue; }
            float r = 120f * age;
            int alpha = (int)((1f - age) * 200);
            Paint ep = new Paint(Paint.ANTI_ALIAS_FLAG);
            ep.setStyle(Paint.Style.FILL);
            ep.setColor(Color.argb(alpha, 255, 200, 50));
            c.drawCircle(fx[0], fx[1], r, ep);
            Paint ep2 = new Paint(Paint.ANTI_ALIAS_FLAG);
            ep2.setStyle(Paint.Style.FILL);
            ep2.setColor(Color.argb(alpha / 2, 255, 100, 0));
            c.drawCircle(fx[0], fx[1], r * 0.5f, ep2);
        }
    }

    // ── Client-side bullet hit flash ──────────────────────────────────────────
    private void drawHitFlashes(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<long[]> it = predictedHitFx.iterator();
        while (it.hasNext()) {
            long[] ph = it.next();
            float age = (now - ph[2]) / 180f;
            if (age >= 1f) { it.remove(); continue; }
            float r = GameView.PR * (0.6f + age * 0.8f);
            int alpha = (int)((1f - age) * 220);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 255, 255, 255));
            c.drawCircle(ph[0], ph[1], r, p);
        }
    }

    // ── Shadow Blade slash arc trails ─────────────────────────────────────────
    private void drawSlashTrails(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<float[]> it = slashTrails.iterator();
        while (it.hasNext()) {
            float[] st = it.next();
            long age = now - (long) st[3];
            final long SLASH_LIFE = 420L;
            if (age > SLASH_LIFE) { it.remove(); continue; }
            float frac = 1f - (float) age / SLASH_LIFE;
            float easedFrac = frac * frac;

            float cx = st[0], cy = st[1], r = st[2];
            float slashAngle = st[4];
            int slot = (int) st[5];
            float sweepDeg = 110f;
            float startDeg = (float) Math.toDegrees(slashAngle) - sweepDeg * 0.5f;
            RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);

            if (slot == 0) {
                Paint haloP = new Paint(Paint.ANTI_ALIAS_FLAG);
                haloP.setStyle(Paint.Style.STROKE);
                haloP.setStrokeWidth(26f * frac);
                haloP.setColor(Color.argb((int)(55 * easedFrac), 180, 0, 255));
                c.drawArc(oval, startDeg, sweepDeg, false, haloP);

                Paint midP = new Paint(Paint.ANTI_ALIAS_FLAG);
                midP.setStyle(Paint.Style.STROKE);
                midP.setStrokeWidth(10f * frac);
                midP.setColor(Color.argb((int)(160 * frac), 255, 60, 200));
                c.drawArc(oval, startDeg, sweepDeg, false, midP);

                Paint coreP = new Paint(Paint.ANTI_ALIAS_FLAG);
                coreP.setStyle(Paint.Style.STROKE);
                coreP.setStrokeWidth(4f * frac);
                coreP.setColor(Color.argb((int)(255 * frac), 255, 220, 255));
                c.drawArc(oval, startDeg, sweepDeg, false, coreP);

                if (age < 180L) {
                    float bf = 1f - age / 180f;
                    float tipX = cx + (float) Math.cos(slashAngle) * r;
                    float tipY = cy + (float) Math.sin(slashAngle) * r;
                    Paint burstP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    burstP.setStyle(Paint.Style.FILL);
                    burstP.setColor(Color.argb((int)(200 * bf), 255, 180, 255));
                    c.drawCircle(tipX, tipY, 20f * bf, burstP);
                    Paint sparkP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    sparkP.setStyle(Paint.Style.STROKE);
                    sparkP.setStrokeWidth(2.5f * bf);
                    sparkP.setColor(Color.argb((int)(230 * bf), 255, 255, 255));
                    for (int k = 0; k < 4; k++) {
                        float sa = slashAngle + (float)(k * Math.PI / 2.0);
                        c.drawLine(tipX, tipY,
                                tipX + (float) Math.cos(sa) * 18f * bf,
                                tipY + (float) Math.sin(sa) * 18f * bf, sparkP);
                    }
                    float perpX = -(float) Math.sin(slashAngle) * 12f * bf;
                    float perpY =  (float) Math.cos(slashAngle) * 12f * bf;
                    c.drawLine(tipX - perpX, tipY - perpY, tipX + perpX, tipY + perpY, sparkP);
                }
            } else if (slot == 1 || slot == 3) {
                Paint innerP = new Paint(Paint.ANTI_ALIAS_FLAG);
                innerP.setStyle(Paint.Style.STROKE);
                innerP.setStrokeWidth(3.5f * easedFrac);
                innerP.setColor(Color.argb((int)(200 * easedFrac), 255, 50, 110));
                c.drawArc(oval, startDeg + 8f, sweepDeg - 16f, false, innerP);
            } else {
                float outerFrac = easedFrac * frac;
                Paint outerP = new Paint(Paint.ANTI_ALIAS_FLAG);
                outerP.setStyle(Paint.Style.STROKE);
                outerP.setStrokeWidth(2f * outerFrac);
                outerP.setColor(Color.argb((int)(140 * outerFrac), 160, 0, 220));
                c.drawArc(oval, startDeg - 12f, sweepDeg + 24f, false, outerP);
            }
        }
    }

    // ── Shadow Blade crescent effect ──────────────────────────────────────────
    private void drawCrescents(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = crescentFx.iterator();
        while (it.hasNext()) {
            float[] cr = it.next();
            long age = now - (long) cr[3];
            final long CRESCENT_LIFE = 380L;
            if (age < 0 || age > CRESCENT_LIFE) { it.remove(); continue; }
            float frac  = 1f - (float) age / CRESCENT_LIFE;
            float eased = frac * frac;

            c.save();
            c.translate(cr[0], cr[1]);
            c.rotate((float) Math.toDegrees(cr[2])); // +X = slash direction

            float outerR = 38f + (1f - frac) * 18f;
            float innerR = outerR * 0.68f;
            float offset = outerR * 0.42f;

            Path crescent = new Path();
            crescent.setFillType(Path.FillType.EVEN_ODD);
            crescent.addCircle(0f, 0f, outerR, Path.Direction.CW);
            crescent.addCircle(-offset, 0f, innerR, Path.Direction.CW);

            Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
            fillP.setStyle(Paint.Style.FILL);
            fillP.setColor(Color.argb((int)(255 * eased), 255, 255, 255));
            c.drawPath(crescent, fillP);

            Paint edgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
            edgeP.setStyle(Paint.Style.STROKE);
            edgeP.setStrokeWidth(2.5f * frac);
            edgeP.setColor(Color.argb((int)(180 * eased), 180, 225, 255));
            c.drawPath(crescent, edgeP);

            c.restore();
        }
    }

    // ── Local player dash ghost afterimages ───────────────────────────────────
    private void drawDashGhosts(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = dashGhosts.iterator();
        while (it.hasNext()) {
            float[] ghost = it.next();
            long age = now - (long) ghost[2];
            if (age < 0 || age > GHOST_LIFE_MS) { it.remove(); continue; }
            float frac  = (float) age / GHOST_LIFE_MS;
            float alpha = 1f - frac;
            float scale = 1f - frac * 0.35f;

            Paint gFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            gFill.setStyle(Paint.Style.FILL);
            gFill.setColor(Color.argb((int)(100 * alpha), 80, 200, 255));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, gFill);

            Paint gRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            gRing.setStyle(Paint.Style.STROKE);
            gRing.setStrokeWidth(3.5f * alpha);
            gRing.setColor(Color.argb((int)(230 * alpha), 140, 230, 255));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, gRing);

            if (frac < 0.15f && dashGhosts.size() > 1) {
                Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
                streak.setStyle(Paint.Style.STROKE);
                streak.setStrokeWidth(2f * alpha);
                streak.setColor(Color.argb((int)(160 * alpha), 100, 210, 255));
                streak.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f, 6f}, 0f));
                c.drawLine(ghost[0], ghost[1], dashAnimEndX, dashAnimEndY, streak);
            }
        }
    }

    // ── Bot dash ghost afterimages ─────────────────────────────────────────────
    private void drawBotDashGhosts(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Iterator<float[]> it = botDashGhosts.iterator();
        while (it.hasNext()) {
            float[] ghost = it.next();
            long age = now - (long) ghost[2];
            if (age < 0 || age > GHOST_LIFE_MS) { it.remove(); continue; }
            float frac  = (float) age / GHOST_LIFE_MS;
            float alpha = 1f - frac;
            float scale = 1f - frac * 0.35f;

            Paint bgFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgFill.setStyle(Paint.Style.FILL);
            bgFill.setColor(Color.argb((int)(110 * alpha), 255, 120, 30));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, bgFill);

            Paint bgRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgRing.setStyle(Paint.Style.STROKE);
            bgRing.setStrokeWidth(3.5f * alpha);
            bgRing.setColor(Color.argb((int)(230 * alpha), 255, 80, 0));
            c.drawCircle(ghost[0], ghost[1], GameView.PR * scale, bgRing);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Status-effect particle spawners  — call once per frame per affected player
    // ═════════════════════════════════════════════════════════════════════════

    /** Spawn slow (ice/cold mist) particles around (cx, cy). pr = player radius. */
    void spawnSlowParticles(float cx, float cy, float pr) {
        long nowRel = System.currentTimeMillis() - FX_EPOCH;
        // Cold mist blob (~40 % per frame)
        if (Math.random() < 0.40) {
            double ang  = Math.random() * Math.PI * 2;
            float  dist = pr * (0.3f + (float) Math.random() * 0.9f);
            float  ox   = (float) Math.cos(ang) * dist;
            float  oy   = (float) Math.sin(ang) * dist;
            float  vx   = ox * 0.04f + (float) (Math.random() - 0.5) * 8f;
            float  vy   = oy * 0.04f - 12f - (float) Math.random() * 10f; // slight upward drift
            float  rad  = 9f + (float) Math.random() * 13f;
            slowMist.add(new float[]{ cx + ox, cy + oy, vx, vy, nowRel, rad });
        }
        // Blue crystal shard snowflake (~20 % per frame)
        if (Math.random() < 0.20) {
            double ang   = Math.random() * Math.PI * 2;
            float  dist  = pr * (0.2f + (float) Math.random() * 1.1f);
            float  speed = 22f + (float) Math.random() * 28f;
            float  vx    = (float) Math.cos(ang) * speed;
            float  vy    = (float) Math.sin(ang) * speed - 8f;
            float  size  = 3f + (float) Math.random() * 4f;
            float  rot   = (float) (Math.random() * Math.PI);
            slowCrystal.add(new float[]{ cx + (float) Math.cos(ang) * dist,
                                         cy + (float) Math.sin(ang) * dist,
                                         vx, vy, nowRel, size, rot });
        }
    }

    /** Spawn poison (toxic fumes, drips, bubbles) particles around (cx, cy). */
    void spawnPoisonParticles(float cx, float cy, float pr) {
        long nowRel = System.currentTimeMillis() - FX_EPOCH;
        // Green fume cloud (~45 % per frame)
        if (Math.random() < 0.45) {
            double ang  = Math.random() * Math.PI * 2;
            float  dist = pr * (0.2f + (float) Math.random() * 0.8f);
            float  vx   = (float) (Math.random() - 0.5) * 14f;
            float  vy   = -38f - (float) Math.random() * 28f;   // rises upward
            float  rad  = 8f + (float) Math.random() * 10f;
            poisonFume.add(new float[]{ cx + (float) Math.cos(ang) * dist,
                                        cy + (float) Math.sin(ang) * dist,
                                        vx, vy, nowRel, rad });
        }
        // Dripping poison drop (~25 % per frame)
        if (Math.random() < 0.25) {
            float ox  = (float) (Math.random() - 0.5) * pr * 1.3f;
            float vy  = 55f + (float) Math.random() * 55f;
            float sz  = 3f + (float) Math.random() * 3f;
            poisonDrip.add(new float[]{ cx + ox, cy, vy, nowRel, sz });
        }
        // Bubble burst (~15 % per frame)
        if (Math.random() < 0.15) {
            double ang  = Math.random() * Math.PI * 2;
            float  dist = pr * (0.3f + (float) Math.random() * 0.7f);
            float  maxR = 7f + (float) Math.random() * 9f;
            poisonBubble.add(new float[]{ cx + (float) Math.cos(ang) * dist,
                                          cy + (float) Math.sin(ang) * dist,
                                          nowRel, maxR });
        }
    }

    /** Spawn stun/shock (electric arcs, sparks, pulses) particles around (cx, cy). */
    void spawnStunParticles(float cx, float cy, float pr) {
        long nowRel = System.currentTimeMillis() - FX_EPOCH;
        // Sparks bursting outward (~50 % chance to emit 1-2 per frame)
        int sparks = Math.random() < 0.5 ? (Math.random() < 0.4 ? 2 : 1) : 0;
        for (int i = 0; i < sparks; i++) {
            double ang   = Math.random() * Math.PI * 2;
            float  dist  = pr * (float) Math.random() * 0.5f;
            float  speed = 80f + (float) Math.random() * 130f;
            float  sz    = 2f + (float) Math.random() * 3f;
            stunSpark.add(new float[]{ cx + (float) Math.cos(ang) * dist,
                                       cy + (float) Math.sin(ang) * dist,
                                       (float) Math.cos(ang) * speed,
                                       (float) Math.sin(ang) * speed,
                                       nowRel, sz });
        }
        // Electric arc between two random points near the player (~35 % per frame)
        if (Math.random() < 0.35) {
            double a1 = Math.random() * Math.PI * 2;
            double a2 = a1 + Math.PI * (0.4 + Math.random() * 0.9);
            float  r1 = pr * (0.3f + (float) Math.random() * 0.8f);
            float  r2 = pr * (0.3f + (float) Math.random() * 0.8f);
            stunArc.add(new float[]{ cx + (float) Math.cos(a1) * r1,
                                     cy + (float) Math.sin(a1) * r1,
                                     cx + (float) Math.cos(a2) * r2,
                                     cy + (float) Math.sin(a2) * r2,
                                     nowRel });
        }
        // Expanding energy pulse (~8 % per frame — kept rare so they don't pile up)
        if (Math.random() < 0.08) {
            float maxR = pr * (1.1f + (float) Math.random() * 0.6f);
            stunPulse.add(new float[]{ cx, cy, nowRel, maxR });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Status-effect particle draw — call once per frame after player bodies
    // ═════════════════════════════════════════════════════════════════════════

    /** Draw all status-effect particles. Call after drawInFrontOfPlayers(). */
    void drawStatusParticles(Canvas c) {
        drawSlowParticles(c);
        drawPoisonParticles(c);
        drawStunParticles(c);
    }

    // ── Slow particles ─────────────────────────────────────────────────────────
    private void drawSlowParticles(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Cold mist blobs
        Iterator<float[]> it = slowMist.iterator();
        while (it.hasNext()) {
            float[] m = it.next();
            long  age  = now - (long) m[4];
            if (age > SLOW_MIST_LIFE || age < 0) { it.remove(); continue; }
            float frac  = (float) age / SLOW_MIST_LIFE;
            float t     = age / 1000f;
            float px    = m[0] + m[2] * t;
            float py    = m[1] + m[3] * t;
            float rad   = m[5] * (1f + frac * 0.65f);
            // Fade in briefly, then fade out — no hard pop-in
            float ramp  = frac < 0.1f ? frac / 0.1f : 1f;
            int   alpha = (int) ((1f - frac) * ramp * 105f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 155, 210, 255));
            c.drawCircle(px, py, rad, p);
        }

        // Blue crystal / snowflake shards — drawn as 4-armed asterisk
        Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
        cp.setStyle(Paint.Style.STROKE);
        Iterator<float[]> it2 = slowCrystal.iterator();
        while (it2.hasNext()) {
            float[] m  = it2.next();
            long  age   = now - (long) m[4];
            if (age > SLOW_CRYSTAL_LIFE || age < 0) { it2.remove(); continue; }
            float frac  = (float) age / SLOW_CRYSTAL_LIFE;
            float t     = age / 1000f;
            float px    = m[0] + m[2] * t;
            float py    = m[1] + m[3] * t;
            float size  = m[5];
            float rot   = m[6] + frac * 1.6f;  // slow spin as it drifts
            // Twinkle: alpha pulses quickly
            float twk   = (float) Math.abs(Math.sin(age * 0.025));
            int   alpha = (int) ((1f - frac) * twk * 235f);
            cp.setColor(Color.argb(alpha, 80, 170, 255));
            cp.setStrokeWidth(1.8f * (1f - frac * 0.5f));
            c.save();
            c.translate(px, py);
            c.rotate((float) Math.toDegrees(rot));
            // 4-armed snowflake: cardinal + diagonal arms
            c.drawLine(-size, 0,          size, 0,           cp);
            c.drawLine(0,     -size,       0,    size,         cp);
            c.drawLine(-size * 0.68f, -size * 0.68f,
                        size * 0.68f,  size * 0.68f, cp);
            c.drawLine( size * 0.68f, -size * 0.68f,
                       -size * 0.68f,  size * 0.68f, cp);
            c.restore();
        }
    }

    // ── Poison particles ────────────────────────────────────────────────────────
    private void drawPoisonParticles(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Toxic fume clouds (rising, expanding)
        Iterator<float[]> it = poisonFume.iterator();
        while (it.hasNext()) {
            float[] m = it.next();
            long  age  = now - (long) m[4];
            if (age > POISON_FUME_LIFE || age < 0) { it.remove(); continue; }
            float frac  = (float) age / POISON_FUME_LIFE;
            float t     = age / 1000f;
            float px    = m[0] + m[2] * t;
            float py    = m[1] + m[3] * t;
            float rad   = m[5] * (1f + frac * 0.9f);
            float ramp  = frac < 0.1f ? frac / 0.1f : 1f;
            int   alpha = (int) ((1f - frac) * ramp * 95f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 55, 200, 75));
            c.drawCircle(px, py, rad, p);
        }

        // Dripping toxic drops (falling, with a short tail)
        Iterator<float[]> it2 = poisonDrip.iterator();
        while (it2.hasNext()) {
            float[] m = it2.next();
            long  age  = now - (long) m[3];
            if (age > POISON_DRIP_LIFE || age < 0) { it2.remove(); continue; }
            float frac = (float) age / POISON_DRIP_LIFE;
            float t    = age / 1000f;
            float px   = m[0];
            float py   = m[1] + m[2] * t;
            float rad  = m[4] * (1f + frac * 0.25f);
            int   alpha= (int) ((1f - frac) * 215f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 85, 240, 55));
            c.drawCircle(px, py, rad, p);
            // Short upward tail
            if (frac < 0.65f) {
                Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp.setStyle(Paint.Style.STROKE);
                tp.setStrokeWidth(m[4] * 0.55f * (1f - frac));
                tp.setColor(Color.argb((int) ((1f - frac) * 150f), 85, 240, 55));
                float tailLen = 9f * (1f - frac);
                c.drawLine(px, py - rad, px, py - rad - tailLen, tp);
            }
        }

        // Bubble rings (expand outward and fade)
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        Iterator<float[]> it3 = poisonBubble.iterator();
        while (it3.hasNext()) {
            float[] m = it3.next();
            long  age  = now - (long) m[2];
            if (age > POISON_BUBBLE_LIFE || age < 0) { it3.remove(); continue; }
            float frac  = (float) age / POISON_BUBBLE_LIFE;
            float rad   = m[3] * frac;
            float ramp  = frac < 0.1f ? frac / 0.1f : 1f;
            int   alpha = (int) ((1f - frac) * ramp * 195f);
            bp.setColor(Color.argb(alpha, 110, 235, 95));
            bp.setStrokeWidth(1.8f * (1f - frac * 0.6f));
            c.drawCircle(m[0], m[1], rad, bp);
        }
    }

    // ── Stun/shock particles ────────────────────────────────────────────────────
    private void drawStunParticles(Canvas c) {
        long now = System.currentTimeMillis() - FX_EPOCH;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Electric sparks (small bright dots flying outward)
        Iterator<float[]> it = stunSpark.iterator();
        while (it.hasNext()) {
            float[] m = it.next();
            long  age  = now - (long) m[4];
            if (age > STUN_SPARK_LIFE || age < 0) { it.remove(); continue; }
            float frac  = (float) age / STUN_SPARK_LIFE;
            float t     = age / 1000f;
            float px    = m[0] + m[2] * t;
            float py    = m[1] + m[3] * t;
            float rad   = m[5] * (1f - frac * 0.55f);
            int   alpha = (int) ((1f - frac) * 255f);
            // Yellow-white outer
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(alpha, 255, 238, 70));
            c.drawCircle(px, py, rad, p);
            // Bright white core
            p.setColor(Color.argb((int) (alpha * 0.65f), 255, 255, 255));
            c.drawCircle(px, py, rad * 0.42f, p);
        }

        // Electric arcs — jagged lines, re-jittered every frame for flickering
        Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
        ap.setStyle(Paint.Style.STROKE);
        Iterator<float[]> it2 = stunArc.iterator();
        while (it2.hasNext()) {
            float[] m = it2.next();
            long  age  = now - (long) m[4];
            if (age > STUN_ARC_LIFE || age < 0) { it2.remove(); continue; }
            float frac  = (float) age / STUN_ARC_LIFE;
            int   alpha = (int) ((1f - frac) * 225f);
            float x1 = m[0], y1 = m[1], x2 = m[2], y2 = m[3];
            // Jitter mid-points for the jagged lightning look
            float jit = 14f * (1f - frac);
            float mx1 = x1 + (x2 - x1) * 0.33f + (float) (Math.random() - 0.5) * jit;
            float my1 = y1 + (y2 - y1) * 0.33f + (float) (Math.random() - 0.5) * jit;
            float mx2 = x1 + (x2 - x1) * 0.66f + (float) (Math.random() - 0.5) * jit;
            float my2 = y1 + (y2 - y1) * 0.66f + (float) (Math.random() - 0.5) * jit;
            // Outer glow
            ap.setStrokeWidth(3.5f * (1f - frac * 0.5f));
            ap.setColor(Color.argb((int) (alpha * 0.35f), 160, 200, 255));
            c.drawLine(x1, y1, mx1, my1, ap);
            c.drawLine(mx1, my1, mx2, my2, ap);
            c.drawLine(mx2, my2, x2, y2, ap);
            // Bright core arc
            ap.setStrokeWidth(1.4f);
            ap.setColor(Color.argb(alpha, 215, 240, 255));
            c.drawLine(x1, y1, mx1, my1, ap);
            c.drawLine(mx1, my1, mx2, my2, ap);
            c.drawLine(mx2, my2, x2, y2, ap);
        }

        // Energy pulses (fast-expanding rings)
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setStyle(Paint.Style.STROKE);
        Iterator<float[]> it3 = stunPulse.iterator();
        while (it3.hasNext()) {
            float[] m = it3.next();
            long  age  = now - (long) m[2];
            if (age > STUN_PULSE_LIFE || age < 0) { it3.remove(); continue; }
            float frac  = (float) age / STUN_PULSE_LIFE;
            float rad   = m[3] * frac;
            int   alpha = (int) ((1f - frac) * 190f);
            pp.setColor(Color.argb(alpha, 255, 228, 50));
            pp.setStrokeWidth(2.8f * (1f - frac));
            c.drawCircle(m[0], m[1], rad, pp);
        }
    }
}
