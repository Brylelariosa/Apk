package com.game.topdown;

/**
 * ════════════════════════════════════════════════════════════════════════════
 *  GUN STATS — edit this file to balance any weapon
 * ════════════════════════════════════════════════════════════════════════════
 *
 *  One row per gun.  Column guide:
 *
 *   maxAmmo      – clip size before reload is needed
 *   fireRate     – shots per second (higher = faster)
 *   damage       – HP removed per bullet (pellet guns: per pellet)
 *   speed        – bullet travel speed in world-px / second
 *   range        – max travel distance in world-px before despawn
 *   spread       – half-angle spray in radians (0 = perfectly accurate)
 *   reloadMs     – reload time in milliseconds
 *   pellets      – bullets fired per shot (shotgun = 6)
 *   zoom         – camera zoom  (< 1 = zoomed out,  > 1 = zoomed in)
 *
 *  Special flag columns (0 = off, 1 = on):
 *   bounces      – bullet ricochets off walls N times (0 = no bounce)
 *   piercing     – bullet passes through every enemy in the line
 *   explosive    – bullet detonates on impact (AOE)
 *   homing       – bullet steers toward nearby enemies
 *   ghost        – bullet phases through walls
 *   hookSpear    – on hit: pull + stun the target
 *   airStrike    – places an air-strike marker instead of a bullet
 *   coinScale    – damage scales with carrier's coin wealth
 *   paint        – override bullet color: 1=slow, 2=poison, 3=alternating
 *                  (leave 0 to auto-detect from slowMs/poisonMs below)
 *
 *  Per-gun status effect columns (0 = use default from StatusEffectConfig).
 *  Setting slowMs or poisonMs auto-enables the effect — no need to set paint manually:
 *   slowMs       – how long this gun's slow lasts (milliseconds); also auto-sets paint=1
 *   slowSpeed    – speed multiplier while slowed (e.g. 0.2 = very slow, 0.6 = light slow)
 *   poisonMs     – how long this gun's poison lasts (milliseconds); also auto-sets paint=2
 *   poisonDmg    – HP per poison tick from this gun
 *   stunBonusMs  – extra stun time after hook pull finishes (milliseconds)
 *   explosionDmg – AOE blast damage for explosive / air-strike guns
 */
public final class GunConfig {

    // ── Visual settings ───────────────────────────────────────────────────────
    /**
     * ShowStatusEffectVisuals — master toggle for status-effect particle visuals.
     *
     *   true  (default) — slow/poison/stun each show distinct particles:
     *                     slow   → cold mist + blue crystal shards + snowflake sparks
     *                     poison → green fumes + dripping droplets + bubble bursts
     *                     stun   → electric arcs + flickering sparks + energy pulses
     *   false           — all status effects still apply normally (slow still slows,
     *                     poison still damages, stun still freezes) but NO visuals
     *                     are drawn — zero screen clutter.
     */
    public static boolean ShowStatusEffectVisuals = true;

    // ── Column indices ────────────────────────────────────────────────────────
    static final int MAX_AMMO     = 0;
    static final int FIRE_RATE    = 1;
    static final int DAMAGE       = 2;
    static final int SPEED        = 3;
    static final int RANGE        = 4;
    static final int SPREAD       = 5;
    static final int RELOAD_MS    = 6;
    static final int PELLETS      = 7;
    static final int ZOOM         = 8;
    static final int BOUNCES      = 9;
    static final int PIERCING     = 10;
    static final int EXPLOSIVE    = 11;
    static final int HOMING       = 12;
    static final int GHOST        = 13;
    static final int HOOK_SPEAR   = 14;
    static final int AIR_STRIKE   = 15;
    static final int COIN_SCALE   = 16;
    static final int PAINT        = 17;
    // per-gun status effect overrides (0 = use StatusEffectConfig default)
    static final int SLOW_MS      = 18;
    static final int POISON_MS    = 19;
    static final int POISON_DMG   = 20;
    static final int STUN_BONUS_MS= 21;
    static final int SLOW_SPEED   = 22;  // speed mult while slowed (e.g. 0.2 = very slow; 0 = use global default)
    static final int EXPLOSION_DMG= 23;  // AOE damage on detonation  (0 = use global default)

    // ── Color table ───────────────────────────────────────────────────────────
    static final int[] COLORS = {
        0xFF4FC3F7,  // 0  Pistol        sky blue
        0xFF81C784,  // 1  SMG           green
        0xFFFF8A65,  // 2  Shotgun       orange
        0xFFFFB347,  // 3  Assault       amber
        0xFFCE93D8,  // 4  Sniper        lavender
        0xFF4DD0E1,  // 5  Burst         cyan
        0xFFFF5252,  // 6  Minigun       red
        0xFFFFD54F,  // 7  Revolver      yellow
        0xFF90A4AE,  // 8  LMG           steel
        0xFF00E5FF,  // 9  Plasma        bright cyan
        0xFF69F0AE,  // 10 Bouncer       mint
        0xFF40C4FF,  // 11 Piercer       light blue
        0xFFFF6E40,  // 12 Seeker        deep orange
        0xFFFFD740,  // 13 Blaster       gold
        0xFFEA80FC,  // 14 Ghost         purple
        0xFF26C6DA,  // 15 Paint         teal
        0xFFFFD700,  // 16 Coin Gun      gold
        0xFF80D8FF,  // 17 Volt Chakram  ice blue
        0xFFFF8F00,  // 18 Hook Spear    amber
        0xFFE040FB,  // 19 Air Strike    violet
        0xFF7B1FA2,  // 20 Soul Reaper   deep purple
        0xFFFF1744,  // 21 Shadow Blade   crimson
    };

    // ── Stat table ────────────────────────────────────────────────────────────
    //  Last 4 columns are status effect overrides.
    //  Set to 0 to use the global default in StatusEffectConfig.
    static final float[][] STATS = {

        // ── 0  Pistol ─────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   12,
            /* fireRate     */   3.0f,
            /* damage       */   34f,
            /* speed        */   1100f,
            /* range        */   650f,
            /* spread       */   0.04f,
            /* reloadMs     */   1000,
            /* pellets      */   1,
            /* zoom         */   1.0f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 1  SMG ────────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   30,
            /* fireRate     */   10.0f,
            /* damage       */   14f,
            /* speed        */   900f,
            /* range        */   620f,
            /* spread       */   0.12f,
            /* reloadMs     */   2000,
            /* pellets      */   1,
            /* zoom         */   1.2f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 2  Shotgun ────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   8,
            /* fireRate     */   1.9f,
            /* damage       */   20f,
            /* speed        */   950f,
            /* range        */   320f,
            /* spread       */   0.27f,
            /* reloadMs     */   1900,
            /* pellets      */   6,
            /* zoom         */   1.35f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 3  Assault ────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   20,
            /* fireRate     */   6.5f,
            /* damage       */   15f,
            /* speed        */   1200f,
            /* range        */   750f,
            /* spread       */   0.05f,
            /* reloadMs     */   1700,
            /* pellets      */   1,
            /* zoom         */   0.85f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 4  Sniper ─────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   5,
            /* fireRate     */   0.8f,
            /* damage       */   100f,
            /* speed        */   2000f,
            /* range        */   2100f,
            /* spread       */   0.005f,
            /* reloadMs     */   2800,
            /* pellets      */   1,
            /* zoom         */   0.52f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 5  Burst  (3 pellets per shot) ────────────────────────────────────
        {
            /* maxAmmo      */   24,
            /* fireRate     */   4.0f,
            /* damage       */   18f,
            /* speed        */   1080f,
            /* range        */   720f,
            /* spread       */   0.035f,
            /* reloadMs     */   2000,
            /* pellets      */   3,
            /* zoom         */   0.90f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 6  Minigun ────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   120,
            /* fireRate     */   25.0f,
            /* damage       */   10f,
            /* speed        */   1300f,
            /* range        */   700f,
            /* spread       */   0.25f,
            /* reloadMs     */   6500,
            /* pellets      */   1,
            /* zoom         */   1.1f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 7  Revolver ───────────────────────────────────────────────────────
        {
            /* maxAmmo      */   6,
            /* fireRate     */   2.0f,
            /* damage       */   55f,
            /* speed        */   1200f,
            /* range        */   850f,
            /* spread       */   0.02f,
            /* reloadMs     */   2200,
            /* pellets      */   1,
            /* zoom         */   0.95f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 8  LMG ────────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   80,
            /* fireRate     */   12.0f,
            /* damage       */   13f,
            /* speed        */   990f,
            /* range        */   850f,
            /* spread       */   0.13f,
            /* reloadMs     */   3800,
            /* pellets      */   1,
            /* zoom         */   1.0f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 9  Plasma ─────────────────────────────────────────────────────────
        {
            /* maxAmmo      */   15,
            /* fireRate     */   2.2f,
            /* damage       */   72f,
            /* speed        */   720f,
            /* range        */   1100f,
            /* spread       */   0.015f,
            /* reloadMs     */   2600,
            /* pellets      */   1,
            /* zoom         */   0.78f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 10 Bouncer  (3 wall bounces) ──────────────────────────────────────
        {
            /* maxAmmo      */   8,
            /* fireRate     */   1.8f,
            /* damage       */   45f,
            /* speed        */   600f,
            /* range        */   1400f,
            /* spread       */   0.02f,
            /* reloadMs     */   2000,
            /* pellets      */   1,
            /* zoom         */   0.90f,
            /* bounces      */   2,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 11 Piercer  (piercing) ────────────────────────────────────────────
        {
            /* maxAmmo      */   15,
            /* fireRate     */   2.2f,
            /* damage       */   32f,
            /* speed        */   1450f,
            /* range        */   1000f,
            /* spread       */   0.004f,
            /* reloadMs     */   1800,
            /* pellets      */   1,
            /* zoom         */   0.85f,
            /* bounces      */   0,
            /* piercing     */   1,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 12 Seeker  (homing) ───────────────────────────────────────────────
        {
            /* maxAmmo      */   5,
            /* fireRate     */   0.7f,
            /* damage       */   48f,
            /* speed        */   700f,
            /* range        */   800f,
            /* spread       */   0.0f,
            /* reloadMs     */   3500,
            /* pellets      */   1,
            /* zoom         */   0.82f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   1,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 13 Blaster  (explosive) ───────────────────────────────────────────
        {
            /* maxAmmo      */   6,
            /* fireRate     */   1.2f,
            /* damage       */   18f,    // direct hit damage (reduced — explosion is the main damage)
            /* speed        */   980f,
            /* range        */   650f,
            /* spread       */   0.03f,
            /* reloadMs     */   2200,
            /* pellets      */   1,
            /* zoom         */   0.88f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   1,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   60f,     // AOE blast damage (now actually used by doExplosion)
        },

        // ── 14 Ghost  (phases through walls) ─────────────────────────────────
        {
            /* maxAmmo      */   8,
            /* fireRate     */   2.5f,
            /* damage       */   22f,
            /* speed        */   880f,
            /* range        */   950f,   // was 200 — bullets now travel a meaningful distance through walls
            /* spread       */   0.02f,
            /* reloadMs     */   2800,
            /* pellets      */   1,
            /* zoom         */   1.15f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   1,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 15 Paint Launcher  (alternating poison/slow) ──────────────────────
        {
            /* maxAmmo      */   14,
            /* fireRate     */   2.5f,
            /* damage       */   15f,
            /* speed        */   920f,
            /* range        */   750f,
            /* spread       */   0.0f,
            /* reloadMs     */   1700,
            /* pellets      */   1,
            /* zoom         */   1.0f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   3,
            /* slowMs       */   3000,   // slow lasts 3 s
            /* poisonMs     */   6000,   // poison lasts 6 s
            /* poisonDmg    */   8,      // 8 dmg per poison tick
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 16 Coin Gun  (damage scales with coins) ───────────────────────────
        {
            /* maxAmmo      */   12,
            /* fireRate     */   3.0f,
            /* damage       */   20f,
            /* speed        */   1150f,
            /* range        */   850f,
            /* spread       */   0.03f,
            /* reloadMs     */   1600,
            /* pellets      */   1,
            /* zoom         */   0.92f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   1,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 17 Volt Chakram  (most stats handled in VoltChakram.java) ─────────
        {
            /* maxAmmo      */   3,
            /* fireRate     */   0.0f,
            /* damage       */   18f,
            /* speed        */   0f,
            /* range        */   660f,
            /* spread       */   0.0f,
            /* reloadMs     */   100,
            /* pellets      */   1,
            /* zoom         */   0.92f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 18 Hook Spear  (pull + stun on hit) ───────────────────────────────
        {
            /* maxAmmo      */   1,
            /* fireRate     */   1.5f,
            /* damage       */   5f,
            /* speed        */   1000f,
            /* range        */   790f,
            /* spread       */   0.0f,
            /* reloadMs     */   2800,
            /* pellets      */   1,
            /* zoom         */   0.92f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   1,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   600,   // 600 ms extra stun after pull ends
            /* slowSpeed    */   0f,      // 0 = use global default (0.4)
            /* explosionDmg */   0f,      // 0 = use global default (60)
        },

        // ── 19 Air Strike  (no real bullet — damage handled per explosion) ─────
        {
            /* maxAmmo      */   3,
            /* fireRate     */   0.6f,
            /* damage       */   0f,
            /* speed        */   0f,
            /* range        */   0f,
            /* spread       */   0.0f,
            /* reloadMs     */   4000,
            /* pellets      */   1,
            /* zoom         */   0.85f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   1,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,   // air strike applies no slow (slow config here was dead code)
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,
            /* explosionDmg */   0f,  // air strike uses AS_DAMAGE constant (handled separately)
        },

        // ── 20 Soul Reaper  (Tier 0: dark starter — viable but grows with kills) ─────
        // Tiers 1-5 are applied dynamically by Gun.applySoulLevel() on each kill.
        {
            /* maxAmmo      */   8,
            /* fireRate     */   2.2f,
            /* damage       */   28f,
            /* speed        */   900f,
            /* range        */   560f,
            /* spread       */   0.06f,
            /* reloadMs     */   1600,
            /* pellets      */   1,
            /* zoom         */   1.0f,
            /* bounces      */   0,
            /* piercing     */   0,
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,
            /* explosionDmg */   0f,
        },

        // ── 21 Shadow Blade  (hold to charge; release fires a dash-slash) ──────
        // Mechanic handled in GameView.launchShadowBlade; these are base values.
        {
            /* maxAmmo      */   1,
            /* fireRate     */   0.0f,   // release-fire only; not used for auto-fire
            /* damage       */   35f,    // base tap damage; scales up to 100 with charge
            /* speed        */   1500f,  // slash moves very fast (short melee range)
            /* range        */   260f,   // base slash reach; +150 at full charge
            /* spread       */   0.0f,
            /* reloadMs     */   550,    // fast enough for quick combos
            /* pellets      */   1,
            /* zoom         */   1.1f,
            /* bounces      */   0,
            /* piercing     */   1,      // always piercing (melee slash hits all in path)
            /* explosive    */   0,
            /* homing       */   0,
            /* ghost        */   0,
            /* hookSpear    */   0,
            /* airStrike    */   0,
            /* coinScale    */   0,
            /* paint        */   0,
            /* slowMs       */   0,
            /* poisonMs     */   0,
            /* poisonDmg    */   0,
            /* stunBonusMs  */   0,
            /* slowSpeed    */   0f,
            /* explosionDmg */   0f,
        },

    };

    // ── Gun names (same order) ────────────────────────────────────────────────
    static final String[] NAMES = {
        "Pistol", "SMG", "Shotgun", "Assault", "Sniper",
        "Burst", "Minigun", "Revolver", "LMG", "Plasma",
        "Bouncer", "Piercer", "Seeker", "Blaster", "Ghost",
        "Paint", "Coin Gun", "Volt Chakram", "Hook Spear", "Air Strike",
        "Soul Reaper", "Shadow Blade",
    };

    // ── Helpers ───────────────────────────────────────────────────────────────
    static Gun apply(Gun g, int row) {
        float[] s  = STATS[row];
        g.name         = NAMES[row];
        g.maxAmmo      = (int) s[MAX_AMMO];
        g.ammo         = g.maxAmmo;
        g.fireRate     = s[FIRE_RATE];
        g.damage       = s[DAMAGE];
        g.bulletSpeed  = s[SPEED];
        g.range        = s[RANGE];
        g.spread       = s[SPREAD];
        g.reloadMs     = (long) s[RELOAD_MS];
        g.pellets      = (int) s[PELLETS];
        g.zoom         = s[ZOOM] * 0.85f;
        g.color        = COLORS[row];

        g.bulletBounces   = (int) s[BOUNCES];
        g.bulletPiercing  = s[PIERCING]   > 0.5f;
        g.bulletExplosive = s[EXPLOSIVE]  > 0.5f;
        g.bulletHoming    = s[HOMING]     > 0.5f;
        g.bulletGhost     = s[GHOST]      > 0.5f;
        g.bulletHookSpear = s[HOOK_SPEAR] > 0.5f;
        g.bulletAirStrike = s[AIR_STRIKE] > 0.5f;
        g.coinScaling     = s[COIN_SCALE] > 0.5f;
        g.bulletShadowBlade = (row == 21);

        // Paint color: explicit > auto-detected from status effect columns
        // This means you can just set slowMs or poisonMs on any gun and it will work —
        // no need to also set paint=1/2/3 manually.
        int paint = (int) s[PAINT];
        if (paint > 0) {
            g.paintBulletColor = paint;
            g.paintShotToggle  = 2;
        } else {
            boolean hasSlow   = s[SLOW_MS]   > 0;
            boolean hasPoison = s[POISON_MS] > 0;
            if      (hasSlow && hasPoison) { g.paintBulletColor = 3; g.paintShotToggle = 2; } // alternating
            else if (hasSlow)              { g.paintBulletColor = 1; }  // slow only
            else if (hasPoison)            { g.paintBulletColor = 2; }  // poison only
        }

        // status effect overrides — 0 means "use StatusEffectConfig default"
        g.slowMs        = s[SLOW_MS]       > 0 ? (long) s[SLOW_MS]       : StatusEffectConfig.SLOW_DURATION_MS;
        g.slowSpeedMult = s[SLOW_SPEED]    > 0 ? s[SLOW_SPEED]           : StatusEffectConfig.SLOW_SPEED_MULT;
        g.poisonMs      = s[POISON_MS]     > 0 ? (long) s[POISON_MS]     : StatusEffectConfig.POISON_DURATION_MS;
        g.poisonDmg     = s[POISON_DMG]    > 0 ? s[POISON_DMG]           : StatusEffectConfig.POISON_TICK_DAMAGE;
        g.stunBonusMs   = s[STUN_BONUS_MS] > 0 ? (long) s[STUN_BONUS_MS] : StatusEffectConfig.HOOK_STUN_BONUS_MS;
        g.explosionDmg  = s[EXPLOSION_DMG] > 0 ? s[EXPLOSION_DMG]        : StatusEffectConfig.EXPLOSION_DAMAGE;

        return g;
    }

    private GunConfig() {}
}
