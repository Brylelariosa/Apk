# CHANGELOG — Twenty-sixth pass

User tested FIX 20 on a real device and sent back a fresh matched capture,
then separately reported trying Dragon Ball Z: Supersonic Warriors and
getting an instant "communication error" plus noticeable in-game lag.

---

## 1. `mgba_jni.c` — bound FIX 20's pacing to a short per-attempt window (FIX 21)

**Category:** Refinement of an experimental diagnostic, still not a
confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Real movement for the first time in this
project's history — the child's own SIOMLT_SEND is no longer stuck at only
`0x0000`/`0xFEFE`; it's now writing genuinely varying values, and the
~200ms restart loop documented since the Sixteenth pass is gone, replaced
by full attempts ~15-17s apart. Each attempt still ends in a new stall
(both sides write SIOCNT with Start cleared and sit for several seconds)
before restarting — a different, previously-invisible bottleneck.
**What the user separately reported:** Dragon Ball Z: Supersonic Warriors —
a real-time fighting game, far less tolerant than a slow retry-based
handshake — fails instantly with "communication error" and lags visibly.
No capture from that specific attempt, but consistent with FIX 20's own
documented cost: an unconditional ~16.74ms added to every host-triggered
exchange for the whole session, with no way to turn itself off.
**The fix:** Not a fix — a refinement of FIX 20's experiment. Pacing is now
bounded to a 3-second `LINK_PACE_WINDOW_NS` grace window, armed once at
session start and re-armed on every local RCNT write (i.e. every
negotiation restart, per every capture on file). Outside an armed window —
an established connection, exactly where a real-time game would be during
actual play — `link_pace_exchange()` is a single boolean check, identical
in cost to FIX 20 being off. See `mgba_jni.c`'s FIX 21 comment for the full
reasoning and exactly which capture the 3s figure comes from.
**Reason:** The aliasing/timing theory looks confirmed by the first result
(nothing else in 20 fixes had ever moved the child past two placeholder
values) but applying it as a flat, whole-session cost is too blunt — it
risks trading one game's stuck handshake for another game's broken
real-time play. Bounding it to short per-attempt windows keeps the
demonstrated benefit without the standing tax.
**Verification:** No device in this sandbox, as always. The windowed
pacing logic (arm/expire/re-arm, and that only the exchanges genuinely
inside the window ever sleep) was extracted verbatim and compiled
standalone against a controllable fake clock — 5 scenarios (unarmed,
armed-matches-FIX-20, expiry stops sleeping and clears the flag, a
400-call burst spanning the boundary only paces the ~179 calls actually
inside it, re-arming after expiry starts a fresh window) all passed under
`gcc -Wall -Wextra -std=gnu11` with zero warnings. File-wide brace/paren
balance checked before and after.
**Not answered by this pass:** Whether 3s is the right window, whether the
new SIOCNT=0x2003 stall is the next real bottleneck, and whether Dragon
Ball Z: Supersonic Warriors' failure was really pacing latency or
something else about that ROM — all need a real device and, ideally, a
capture from that specific game.

---

# CHANGELOG — Twenty-fifth pass

User-reported, with a fresh matched host+child capture (`log.text`/
`logt.text`, 07-17) attached: multiplayer still doesn't work, and — new
information, not previously on file — confirmed the same ROM's multiplayer
works outside this app, ruling out "this specific ROM's own link code is
unusual" as an explanation for the first time in this project's history.

---

## 1. `mgba_jni.c` — experimental exchange pacing (FIX 20)

**Category:** Diagnostic experiment, not a confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Identical to FIX 18/19's evidence, unchanged
across ten passes and five unrelated feature passes in between: the child's
own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and its own RCNT/SIOCNT
setup sequence still restarts roughly every 200ms (194-209ms apart across
five resets in this capture), while the host's own outgoing data still
arrives at the child correctly and varying, exactly as it always has.
**What's new:** With the ROM ruled out by the user directly, the bug has to
be in this app's own link implementation. That re-focuses attention on the
theory named since the Seventeenth pass but never acted on: this driver
resolves every transfer as one instantaneous blocking network round-trip,
with nothing pacing completion against real per-transfer cycle cost
(`GBASIOCyclesPerTransfer`, cited since FIX 10) — and `nativeLinkChildExchange()`
runs on a background thread with no correlation to when the child's own CPU
actually gets to execute, so at the observed exchange rate (hundreds/second)
roughly a dozen updates can land, each overwriting the last, for every
single frame's worth of CPU time the child ROM gets to run in.
**The fix:** Not a fix — a bounded, reversible experiment. `link_pace_exchange()`
makes a host-triggered exchange wait until at least one emulated GBA frame
(~16.74ms) has passed since the previous one before starting the network
round-trip, so the child's CPU gets a real chance to observe each exchange
before the next one lands. Toggleable via `LINK_PACE_EXCHANGES` (on by
default); set to 0 for this file's exact prior behavior. See `mgba_jni.c`'s
own FIX 20 comment for the full reasoning, including why a fully correct
fix (real `mTiming` scheduler integration) is not attempted here.
**Reason:** Every prior pass that named the timing-architecture theory
declined to test it, for lack of a way to check it without a device. This
gives the user a cheap, single-toggle way to test it on a real device
without this project taking on a full scheduler-integration rewrite blind.
**Expected outcome:** One of two informative results, either of which moves
this forward. If the ~200ms reset and the 0x0000/0xFEFE ceiling persist
unchanged with pacing on, the aliasing theory is very likely wrong (or not
the whole story), and the next pass should look elsewhere. If either
changes, that's real evidence to justify real scheduler integration next.
**Side effects:** Adds up to ~16.7ms of latency per host-triggered exchange
when the network reply would otherwise have arrived faster than that — on
top of the network round-trip's own latency, not instead of it. No effect
on the child role's own code path. No effect on data correctness — every
byte exchanged is identical to before, only the timing of when the next
exchange is allowed to start changes.
**Verification:** No Android/NDK toolchain or device in this sandbox, as
every pass. The pacing/interval math (GBA frame length → nanoseconds,
sleep-remaining-time logic, reset-on-reconnect) was extracted verbatim and
compiled standalone against a controllable fake clock (not real
`clock_gettime`/`nanosleep`, which need a real device to observe) — five
scenarios (first exchange, back-to-back, late-arriving, half-elapsed,
ten-in-a-row) all passed under `gcc -Wall -Wextra -std=gnu11` with zero
warnings. File-wide brace/paren balance checked comment- and string-aware
before and after. This confirms the arithmetic and control flow are correct
in isolation — it does not confirm the fix changes the reported symptom,
which (as with every pass in this project) needs a real device to know.

---

# CHANGELOG — Twenty-fourth pass

User-reported: the menu-based Save State/Load State flow (as opposed to
the Quick Save/Quick Load buttons fixed last pass) feels slow in two
places — the slot-picker dialog taking a moment to appear, and picking a
slot taking a moment to confirm.

---

## 1. `MainActivity.kt` — slot thumbnails cached in memory

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `showSaveStateSlotDialog()` re-read and re-decoded
every slot's PNG thumbnail from disk on *every single open*, even when
nothing about that slot had changed since the last time the dialog was
shown. On repeat opens — exactly what fast save/load testing does — this
was pure wasted disk I/O and PNG decode work.
**The fix:** Added `slotInfoCache`, an in-memory `ConcurrentHashMap` keyed
by ROM name + slot number, holding each slot's already-decoded `SlotInfo`.
A slot is only re-read/re-decoded when its `exists`/`lastModified()` no
longer match what's cached — i.e. only when it's actually stale, which in
practice means right after a save to that slot. Keyed by ROM name as well
as slot number since slot *numbers* repeat across ROMs but point at
different underlying files.
**Confidence:** High — this only removes redundant, correctness-neutral
work; the freshness check still falls back to a full re-decode any time
the underlying file has actually changed.

---

## 2. `MainActivity.kt`/`SaveEntry` — backup-before-save now a rename, not a copy

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `backupIfExists()` (called right before every save,
by both Quick Save and the menu's Save State) read an existing slot's
full bytes and wrote them out again to the `.bak` sibling — immediately
before `nativeSaveState()` was about to overwrite that same original file
anyway. That's up to 2x a save-state's worth of disk I/O for every single
save, all of it before the confirmation toast could fire.
**The fix:** Added `SaveEntry.moveInto()`. When no Storage folder is
configured (the common case), the backup is now a single
`File.renameTo()` — an instant, metadata-only move on the same volume —
instead of a byte-for-byte copy. Falls back to the old copy behavior if
the rename fails, or whenever a Storage folder IS configured (no
equivalent plain rename via `DocumentFile`).
**Confidence:** High for the internal-storage path (the default); the
Storage-folder path is unchanged from before, so no regression risk
there.

---

# CHANGELOG — Twenty-third pass

User-reported (from fast save/load testing): Quick Save/Quick Load
sometimes "saved on a different frame" than expected, and sometimes
appeared not to save at all when tapped quickly.

---

## 1. `MainActivity.kt` — quickSaveState()/quickLoadState() race fixed

**Category:** Bug fix (data race)
**Files modified:** `MainActivity.kt`
**What was wrong:** Every tap of Quick Save or Quick Load spawned a brand
new, totally unsynchronized `Thread`. `g_core_mutex` on the native side
only serializes the moment of the actual file write/read against the
running game thread — it says nothing about which Kotlin thread reaches
that point first. A fast double-tap of Quick Save, or Quick Save followed
immediately by Quick Load, raced: whichever thread happened to win the
mutex first went first, regardless of tap order. A Load that won the race
before a pending Save had written could read the file from before that
save (looks like "loaded the old/first save"); two Saves landing in
either order looks like "saved a different frame" than the one actually
displayed at the moment of the tap.
**The fix:** Added a shared `AtomicBoolean` busy-guard around both
functions. A tap that arrives while a prior quicksave/quickload is still
in flight is now a no-op with its own toast, instead of spawning a second
racing thread. Confirmed: `nativeSaveState()` already opens with
`O_TRUNC` (see `mgba_jni.c`), so an existing slot is always fully
replaced, never appended to or left partially overwritten — the
"different frame" symptom was the race above, not a failure to replace
the slot.
**Confidence:** The race is definite from the code (no lock, no debounce,
two independent Threads touching the same file/native calls). Not
re-confirmed on a real device this pass — no Android toolchain here.

---

# CHANGELOG — Twenty-second pass

Two user-reported issues, both in `MainActivity.kt`: a stray "Load ROM"
button rendering on top of the ROM browser it was supposed to sit behind,
and Save State feeling slow — the confirmation toast wasn't showing up
until well after the state had actually finished saving.

---

## 1. `MainActivity.kt` — floating "Load ROM" button removed

**Category:** Bug fix (visual — matches a screenshot showing the button
floating over the ROM browser's file list)
**Files modified:** `MainActivity.kt`
**What was wrong:** The purple "▶ Load ROM" `Button` sat behind
`romBrowserOverlay`/`settingsMenuOverlay` in add order (added to `root`
first), but a stock Material `Button` carries a small default elevation
even with nothing explicitly setting one. Android draws children with
non-zero elevation above children with zero elevation regardless of add
order once any Z-order is involved, so the button rendered ON TOP of the
overlays that were supposed to cover it — visible as a stray purple pill
hovering over the ROM browser's file list, exactly as reported.
**The fix:** Removed the button outright rather than patching its
elevation. `changeRom()` already auto-opens the ROM browser on first
launch and on Close (`closeGame()`), which covers the button's main
purpose already. Its other purpose — a way back into ROM selection when
the folder picker gets cancelled before any folder's chosen, or a ROM
load fails — is now handled by `onGameTouch()`: tapping the idle
(no-ROM-loaded) surface calls `changeRom()` directly. No button, no
elevation, no Z-order conflict possible.
**Confidence:** The elevation-over-opaque-sibling explanation matches
Android's own documented Z-order behavior and matches the reported
screenshot exactly (button visible mid-screen, over the file list, below
where "Use system file picker instead" sits). Not re-confirmed on a real
device this pass — no Android toolchain here — but removing the view
entirely can't reproduce a Z-order bug that only existed because the view
was there.

---

## 2. `MainActivity.kt` — Save State confirmation no longer waits on the thumbnail

**Category:** Bug fix (perceived performance — reported as "doesn't save
instantly")
**Files modified:** `MainActivity.kt`
**What was wrong:** In `showSaveStateSlotDialog()`'s save path, the
"Saved to Slot N" toast fired AFTER `captureStateThumbnail(slot)`
completed, not right after the actual state write. That thumbnail capture
waits on `PixelCopy.request()` (up to a 500ms `CountDownLatch.await()`),
then scales and PNG-encodes a full-screen bitmap — all of it fully
blocking, even though the save itself was already done and safely on disk
before any of it started. Every Save State via the slot dialog felt
delayed by however long that took. (The one-tap 💾 quicksave button —
`quickSaveState()` — never had this problem; it doesn't capture a
thumbnail at all.)
**The fix:** Reordered so the confirmation toast fires immediately after
`nativeSaveState()`/`nativeLoadState()` returns, and
`captureStateThumbnail()` runs afterward, still on the same background
thread but no longer gating the confirmation. The slot list just won't
show a brand-new thumbnail until it's next opened; the save itself is no
longer perceived as slow.
**Confidence:** The 500ms figure is read directly from
`captureStateThumbnail()`'s own `latch.await(500, TimeUnit.MILLISECONDS)`
call, so the worst case this fix removes from the confirmation's critical
path is exact, not estimated. Not verified against a real device's actual
felt latency this pass — no Android toolchain here — but the reorder
itself can't change save correctness, only when the toast fires relative
to work that was already happening.

---

# CHANGELOG — Twenty-first pass

Bug fix, real-device-reported: the Twentieth pass's Storage folder feature
broke save/load once someone actually tested it on a phone — reported as
"doesn't save and load" after turning that feature on. Root cause and fix
below; no new feature this pass.

---

## 1. `MainActivity.kt` — SAF native-fopen bridge replaced

**Category:** Bug fix (confirmed on real device this pass; Twentieth pass's
version of this was flagged in KNOWN_LIMITATIONS.md as unconfirmed)
**Files modified:** `MainActivity.kt`
**What was wrong:** `SaveEntry.nativePath()` bridged a SAF document to
native code via `/proc/self/fd/<N>` — reopening a `ParcelFileDescriptor`'s
fd as a plain path and handing that straight to `VFileOpen()`, including
for the battery save, which the core mmaps for the entire ROM session.
Nothing guarantees a re-opened SAF fd supports mmap/seek/`O_TRUNC` the way
native code needs — that's provider-specific — and a real-device test this
pass showed it doesn't hold up: saves and states appeared to go somewhere,
but loading them back either failed or didn't reflect what was saved.
**The fix:** Native code no longer touches a SAF document directly. It
always `fopen()`s a plain file under this app's own internal storage —
exactly as before the Storage-folder feature existed — and Kotlin copies
bytes to/from the chosen folder's document on either side of that call,
using `ContentResolver`'s stream APIs (`openInputStream`/`openOutputStream`),
which every `DocumentsProvider` is required to support. See
`SaveEntry.stageForRead()` / `stageForWrite()` / `commitWrite()` for the
one-shot save-state/quicksave/thumbnail case, and `batteryMirrorPath()` /
`syncBatteryMirror()` for the session-long battery save (synced out at
`onPause()`, before swapping to a different ROM, on `closeGame()`, and as a
last-resort in `onDestroy()`).
**Confidence:** Removes a specific, real failure mode confirmed this pass.
Still not run against every possible DocumentsProvider (cloud-storage-backed
folders in particular) — see KNOWN_LIMITATIONS.md — but no longer depends on
provider-specific mmap/seek/truncate behavior at all, only on the stream
APIs every provider must implement.

---

# CHANGELOG — Twentieth pass

New feature, unrelated to the link/multiplayer work above — user-chosen
Storage folder for saves/states/screenshots, so they can live somewhere
visible in a file manager instead of only under this app's own internal
storage (`Android/data/...`).

---

## 1. `MainActivity.kt` — Storage folder (Settings → Storage)

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What it does:** A new Settings row lets the user pick a folder (system
folder-picker/SAF — same mechanism the ROM browser already uses, see
`romTreePicker`, just with write access too). Once set, three subfolders
appear inside it — `save`, `cheat`, `screenshot` — and every battery save,
save-state, state thumbnail, quicksave, and screenshot goes there instead
of internal storage from that point on. `cheat` is provisioned but unused
— there's no cheat feature yet to write into it (see the "Cheats" menu
entry, still "not implemented yet").
**Why SAF, not a plain hardcoded path:** the obvious alternative
(`MANAGE_EXTERNAL_STORAGE`, giving raw `java.io.File` access anywhere)
was already deliberately rejected for the ROM browser for reasons that
apply just as much here — see that feature's own comment. The wrinkle
specific to this feature: `nativeSaveState()`/`nativeLoadState()`/
`nativeLoadROM()`'s save path all need a real fopen()-able path string,
which a SAF document's `content://` URI isn't. Bridged via
`/proc/self/fd/<N>` — open a `ParcelFileDescriptor` for the SAF document,
hand native code that path instead, close the descriptor once native code
has opened its own independent handle. No native code changed at all.
**No migration:** switching folders does not move whatever already exists
under internal storage — only new saves/states/screenshots go to the new
location. Stated plainly in the Settings screen itself before anyone taps
"Choose folder" — see KNOWN_LIMITATIONS.md for why automatic migration
isn't attempted.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren counts checked directly. The
`/proc/self/fd/` bridge itself is a well-known, long-used technique for
this exact SAF/native-fopen mismatch, but not confirmed against a real
device/provider here — see KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Nineteenth pass

Negative result, not a fix — re-tested Eighteenth pass's SIOCNT-mirroring
change against a real matched capture. No observed change: the child's own
`childData` is still only ever `0x0000`/`0xFEFE`, same as every capture
back to the Sixth pass. Not reverted — it's still correct on its own terms,
just not the fix for this ROM.

Also added: `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line to the exported text, so two phones' captures
can be time-aligned by eye. Prompted by this pass's two logs covering
different real-world spans — turned out to be expected (host logs ~3
lines per SIO exchange, child ~1, so the same 40,000-character cap holds
less real time on the host side), not a bug, but there was no quick way to
confirm that from the logs alone before now.

---

# CHANGELOG — Eighteenth pass

Scope note: `mgba_jni.c` only. First pass with a real matched capture — two
link logs, one per phone, from the same connection attempt (timestamps
overlapping to the second) instead of minutes apart, made possible by
Seventeenth pass's logcat-independent logging.

---

## 1. `mgba_jni.c` — child's own SIOCNT never reflected transfer completion

**Category:** Bug fix
**Files modified:** `mgba_jni.c`
**Problem:** Cross-referencing the new matched capture confirmed the
network layer is not the issue — the host's live, changing outgoing data
correctly reaches the child (visible as `hostData` in its exchange log),
and the child's own data correctly reaches the host (`recv`), both
directions, from a real simultaneous pair for the first time. That leaves
the child ROM's own code as the only place still unaccounted for. Reading
`nativeLinkChildExchange()` end to end turned up a gap it already
self-documented: it writes the SIOMULTI0-3 data registers and raises the
SIO IRQ, but never touched the child device's own SIOCNT. GBATEK documents
Multi-Player SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of
the parent's clock line on every connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises. A child ROM using that technique would see a flat, never-changing
value here, regardless of the IRQ or data registers already being correct.
**Solution:** `nativeLinkChildExchange()` now reads the child's current
SIOCNT, refreshes bits 2 (child), 3 (ready), 4-5 (player ID), and clears
bit 7 (busy) after every exchange, preserving every other bit (mode, baud
rate, IRQ-enable) exactly as the ROM last set it.
**Reason:** Closes a gap the code already admitted to itself in a comment,
cross-referenced against GBATEK — not a new guess about either test ROM's
internals.
**Expected improvement:** If either test ROM polls SIOCNT bit 7 to detect
new data (a common pattern alongside or instead of the IRQ), it should now
see it, instead of a flat value indistinguishable from "no cable."
**Side effects:** None on the host path — this only touches the child-role
function. Preserves mode/baud/IRQ-enable bits rather than clobbering them.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren count checked directly (69/69, 645/645
across the whole file). Not confirmed on a real device — see
KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Seventeenth pass

Scope note: `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`,
`LinkMultiplayer.kt`. Prompted by two things in the same message: "still
doesn't work multiplayer" (expected — see KNOWN_LIMITATIONS.md for what
this pass's new evidence actually shows) and "can't get log on this
device, only on other device" — the exact logcat-access split Sixteenth
pass flagged but didn't fix, now confirmed to still be blocking things.

1. **Durable, logcat-independent link debug logging.** `copyLinkDebugLog()`
   used to shell out to `logcat`, which reads back a process's own output
   fine on stock Android but which some OEM builds restrict further — W's
   own two-phone split (real output on one, nothing on the other, same
   build) is direct evidence of that, not of a bug in this app. Every
   `LOGI`/`LOGW`/`LOGE` in `mgba_jni.c` now also writes to a plain private
   file under this app's own `filesDir`, via a new `jni_log_line()` the
   existing `LOGI`/`LOGW`/`LOGE` macros expand to — every call site in the
   file is unchanged, since those are still plain macros. A new
   `nativeSetLinkLogPath()` JNI entry point (called once from
   `MainActivity.onCreate()`) hands the path in. Needs no logcat/READ_LOGS
   access at all, on any device, since it was never reading logcat to
   begin with.
2. **Fresh log per connection attempt, not an ever-growing file.**
   `nativeLinkStart()` re-truncates the log file at the start of every
   session, matching the actual workflow (connect, wait, read the log) —
   a capture reflects one attempt, not whatever a previous one left
   behind. An 8MB backstop cap in the new `link_log_write()` resets to
   empty if a single session ever runs long enough to hit it, which normal
   use shouldn't.
3. **Kotlin-side connection-lifecycle logging (Fifteenth pass's 7 log
   lines in `LinkMultiplayer.kt`) now mirrors into the same file** via a
   new `linkLog()` helper, instead of only going to `Log.i`/`Log.w`. One
   "Copy link log" read now captures the same combined picture the old
   3-tag logcat filter (`mGBA-JNI:* mGBA-Link:* mGBA:*`) used to, without
   depending on logcat access to get it.
4. **No protocol or timing behavior changed.** All four items above are
   logging/infrastructure only. See KNOWN_LIMITATIONS.md for this pass's
   actual investigation (a deeper read of the new host+child evidence, and
   an updated but still-unconfirmed theory) and BUGS_FIXED.md for why this
   isn't labeled a bug fix.

---

# CHANGELOG — Sixteenth pass

Scope note: `mgba_jni.c`, `MainActivity.kt` only. Prompted by the first
genuinely useful evidence this project has had: FIX 13 (Fifteenth pass)
worked, and W sent back four logs — a screenshot of an empty capture on one
phone, and three real logcat files (`wifi_host.text`, `wifi_join.text`,
`bluetoth__1_.text`) with actual multiplayer-attempt content instead of
boot noise.

Reading those three files is what this pass actually is. No new hypothesis
was chased from a cold read this time — everything below follows directly
from what the logs show, and from tracing the two remaining places this
codebase had *no* logging at all (the exchange result on the host side, and
the entire child-side receive path) once it became clear those were the
specific gaps stopping the new evidence from being conclusive.

**Still nothing here fixes the reported bug.** See KNOWN_LIMITATIONS.md.
What this pass adds is the other half of the trace FIX 11/13 started, so
the *next* capture — taken with both phones logging the same session,
which this one wasn't — has a real chance of showing the actual mechanism
rather than another layer of "here's activity, still can't tell what it
means."

---

## 1. Logged the SIO exchange result on the host side, not just the trigger

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()` (FIX 11/13) traced every write that
*triggers* an exchange, but never what `link_exchange()` actually returned.
`wifi_host.text` this pass showed 1124 Start-bit writes in 1.67 seconds —
mathematically far too fast to be hitting `WIFI_XCHG_MS=30` on each one
(that alone would take over 30 seconds) — strongly implying most were
completing fast with real replies, not timing out, but nothing in the log
said so directly, and the reply *content* was invisible either way.
**Solution:** Added `LOGI("SIO exchange result: sent=... recv=... timedOut=...")`
right after `link_exchange()` returns, inside the same host-only branch.
**Reason:** Directly motivated by not being able to answer "is the network
side actually working" from `wifi_host.text` alone, despite the timing
strongly suggesting yes.
**Expected improvement:** The next host-side capture will say, per
transfer, exactly what came back and whether it was a timeout.
**Side effects:** Roughly doubles this function's log volume during active
exchanges — expected and accounted for in item 3 below.
**Verification:** Not runnable here. Read-through only; placed inside the
already-host-gated branch, so no new conditions to get wrong.

---

## 2. Added logging to the entire child-side receive path (previously zero)

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `nativeLinkChildExchange()` — the only thing that ever updates
a child device's own SIOMULTI0/1 registers — had no logging in either its
early-exit or success path. Every log gathered across sixteen passes,
including this pass's three, is entirely blind to whether this function is
even being called, let alone what it exchanges. `wifi_join.text` and
`bluetoth__1_.text` both show the child ROM repeatedly restarting its own
SIOCNT/RCNT setup roughly every 200ms — consistent with a ROM that keeps
giving up on its own negotiation — but whether that's because this function
never runs, runs but with bad data, or runs fine and the ROM just doesn't
react, was and is unanswerable without this.
**Solution:** Added `LOGW` on the early-exit branch (active/host-role/core
pointer check) and `LOGI` on every successful call, logging both
`hostData` and `childData`.
**Reason:** Same motivation as item 1 — this was the single largest blind
spot left after item 1, and the one most directly relevant to the
"still doesn't work on rom" reports for a device acting as the child.
**Expected improvement:** The next child-side capture will show whether
this function runs at all during a real attempt, how often, and with what
data — directly testable against the host's own `wifi_host.text`-style
trace if both phones capture the same session.
**Side effects:** Adds log volume proportional to how often the child
actually receives host data — unknown until measured, since this pass's
child-role logs show no evidence either way.
**Verification:** Not runnable here. Read-through only.

---

## 3. Bumped the debug-log capture window again, 8000 → 20000 lines

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** Fifteenth pass's 8000-line bump was sized against *boot*
noise, before this pass's evidence showed real exchange activity running
at ~670/second on the host — 2243 lines in 1.67s from the write trace
alone, before items 1-2 above add more on top.
**Solution:** `-t 8000` → `-t 20000`. Comment above `copyLinkDebugLog()`
updated with the real numbers behind the bump this time, instead of a
guess.
**Reason:** Directly sized against this pass's own measured log rate, with
headroom for items 1-2's added volume.
**Expected improvement:** A capture spanning several seconds of real
exchange activity, from either role, shouldn't scroll its own start out
from under itself before W gets to read it.
**Side effects:** Larger worst-case clipboard/dialog payload — same
reasoning as the Fifteenth-pass bump, still well within what a
`ScrollView`/`TextView` and the clipboard handle fine.
**Verification:** Not runnable here. Read-through only.

---

## Not changed this pass

- The actual mechanism behind the child ROM's repeated resets, or whether
  it's the same mechanism on Wi-Fi and Bluetooth — items 1-2 are what
  would show this, not a fix for it yet.
- The empty-log-on-one-phone issue W also reported/screenshotted this
  pass. Very likely a normal Android self-logcat restriction that varies
  by device/OS version (not something this codebase controls), for which
  Shizuku — already working on W's other phone — is the practical
  workaround. Not attempted as a code fix this pass; see
  KNOWN_LIMITATIONS.md for why and what a real fix would involve.
- Everything else FIX 9-15 already covers.



Scope note: `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`. Prompted
by a retest reporting all three still-open symptoms at once: ROM detection
still failing on both transports, Wi-Fi disconnect not reaching the other
phone, and lag on Bluetooth. Two logcat dumps (one per transport) were
attached as evidence for the ROM-detection question specifically.

Reading those two dumps first, before touching any source, is what this
pass actually turned on: neither contained a single line from anywhere near
an actual link attempt — both covered barely 200ms of real time, entirely
boot-time noise. That's items 1-2 below. Item 3 is a design gap every prior
FIX 9-12 comment already described the intent for but never actually
enforced, found by re-reading `mgba_jni.c` end to end rather than from the
logs (which had no signal to read). Item 4 is the clipboard tool itself,
updated to match.

**None of this is confirmed to fix the reported symptoms** — see
KNOWN_LIMITATIONS.md's Fifteenth-pass entry for exactly what would. Items
1-2 are a confirmed, demonstrated bug (the evidence is the two attached
files) whose fix is straightforward; item 3 is a hardening whose actual
impact is unknown. What every item together should reliably produce,
even if the underlying multiplayer bug turns out to be something else
entirely, is a next debug-log capture that finally contains something to
read.

---

## 1. Filtered mGBA's own core logging out of `jni_log()`

**Category:** Bug fix (diagnostic capture) / possible general performance
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `jni_log()` — the callback that forwards mGBA's internal
logger to Android's logcat — forwarded every core log line, at every
level, to `LOGI` under the `mGBA-JNI` tag, with `(void)level` explicitly
discarding the one piece of information that would have let it filter
anything. Confirmed directly from both logcat files attached this pass:
every line in both was genuinely `mGBA-JNI` (the tag filter was never the
issue), but both covered barely 166-241ms of real time — pure boot-time
`"Starting DMA ..."` / `"Read from write-only I/O register: ..."` spam,
nothing from anywhere near an actual multiplayer attempt. Confirmed
against mgba-emu/mgba's real source this pass (not inferred): the latter
message is logged at `mLOG_STUB`, the same level FIX 12 already
identified for the (now-removed) `rawWrite16` no-op warnings. This chatter
is completely unrelated to link/multiplayer — any DMA-heavy ROM produces
dozens of these lines every single frame — so it was never specific to
this investigation, it just happened to be what finally made the capture
tool's output visibly useless enough to trace.
**Solution:** `jni_log()` now drops `mLOG_DEBUG`/`mLOG_STUB`/
`mLOG_GAME_ERROR` before they reach `LOGI`, matching mGBA's own
`src/platform/libretro/libretro.c` under `NDEBUG` (this project's own
`CMakeLists.txt` also builds with `NDEBUG`). `FATAL`/`ERROR`/`WARN`/`INFO`
are unaffected. Belt-and-suspenders on top of the level check: also drops
the two specific message prefixes actually observed flooding both attached
logs, regardless of level, in case either isn't DEBUG/STUB after all.
**Reason:** Directly demonstrated by the two files W attached — see
mgba_jni.c's own FIX 13 comment for the full trail.
**Expected improvement:** The next `Copy link log` capture should cover
much more real time and actually contain FIX 11's SIO trace lines and
LinkMultiplayer.kt's own connection-lifecycle logging, instead of nothing.
Secondary, unconfirmed: `__android_log_print` is a real syscall: cutting
dozens of avoidable calls per frame, on every ROM, may also just be a
general performance improvement — not only for the Bluetooth lag this pass
was asked about.
**Side effects:** None expected — pure log suppression, no behavior
change. If DEBUG/STUB-level core tracing is ever needed again for
unrelated debugging, this is the one place to temporarily loosen.
**Verification:** No compiler in this sandbox, as every pass. The two
attached logs are direct evidence the *problem* is real; the fix itself
(which specific mLogLevel constants exist, and that STUB is used for
exactly this "wrong-direction register access" case) is checked against
mgba-emu/mgba's real source this pass, not assumed.

---

## 2. Bumped the debug-log capture window, updated its guidance

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** `copyLinkDebugLog()`'s `logcat -t 2000` limit, combined with
Item 1's since-fixed noise, meant the window covered a fraction of a
second in practice.
**Solution:** Bumped `2000` to `8000`. Purely a safety margin on top of
Item 1's real fix, not a substitute for it — the comment above the
function, and the empty-state dialog message, were both updated to say so
and to explicitly mention re-testing the disconnect scenario (tap
Disconnect, wait a few seconds, then read the log), since that's now also
something this capture is meant to help diagnose.
**Reason:** Cheap extra headroom now that each line is worth far more
signal than before.
**Expected improvement:** A long test session (multiple connect/play/
disconnect cycles) is less likely to scroll early evidence back out.
**Side effects:** Slightly larger clipboard payload and dialog text in the
worst case; a plain monospace `TextView` inside a `ScrollView` handles a
few thousand lines fine.
**Verification:** Not runnable here (no device). Read-through only.

---

## 3. Host-gated the native SIO exchange trigger

**Category:** Hardening (protocol correctness) — impact unconfirmed
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()`'s exchange branch fired on *any*
SIOCNT write with the Start bit set, regardless of which role's own ROM
made that write. FIX 9's original comment already claimed this branch
"correctly never fires" on a child device, on the theory that a child ROM
never performs that write (GBATEK: Start/Busy is read-only for slaves) —
but nothing in the code actually enforced that; it was resting entirely on
that assumption holding for both test ROMs.
**Solution:** Added `&& g_link_is_host` to the branch condition; simplified
the two `g_link_is_host ? … : …` blocks inside it that the guard now makes
unreachable in the child case. The FIX 11 diagnostic warning is now also
host-gated, deliberately not logging the (now-expected) child case at all,
to avoid reintroducing Item 1's problem if a ROM's child-role code hits
this on every poll iteration.
**Reason:** Re-reading `mgba_jni.c` end to end for anything FIX 9-12 might
have missed, since the attached logs had no signal to point at anything
more specific. If either test ROM's link code shares one code path between
parent/child roles (plausible — Nintendo's SDK is commonly used that way)
and doesn't itself distinguish, this would have let a child device trigger
a second, spurious exchange of its own alongside the correct
network-triggered one — sending an unsolicited packet the host's *next*
real exchange could then consume as that round's reply. Fits the reported
symptom set well: identical ROM-detection failure on both transports (this
file is shared, unlike the already-hardened transport-specific Kotlin) and
worse lag specifically on Bluetooth (`BT_XCHG_MS=50` vs `WIFI_XCHG_MS=30` —
a stolen reply costs more there). Also may bear on the Twelfth-pass
KNOWN_LIMITATIONS entry that flagged suspiciously rapid repeated exchanges
in an earlier capture, never followed up.
**Expected improvement:** Unconfirmed — see KNOWN_LIMITATIONS.md. Cheap and
safe either way: host behavior is completely unchanged, since `is_host` was
already true on every path that used to run.
**Side effects:** None expected for the host role. For the child role. only
removes a call this design was never supposed to make in the first place.
**Verification:** Not runnable here. Design-intent gap identified by
reading, not by a build or device test.

---

## 4. Added specific reason logging to every disconnect/peer-lost path

**Category:** Bug fix (diagnostic capture)
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `disconnect()`'s outgoing BYE send had a bare
`catch (_: Exception) {}` — completely silent whether it succeeded, was
skipped (null socket/peer), or threw. Separately, all 8 call sites of
`handlePeerLost()` logged one identical generic line regardless of which
of the 6 listener locations detected it or why (explicit BYE vs. the 8s
liveness timeout). A captured log couldn't have distinguished "peer's BYE
never arrived", "it arrived but something else consumed it first", and
"neither side has sent one yet, still waiting on the watchdog" — three
very different bugs that all look identical from the report "if I
disconnect, it doesn't disconnect on the other phone."
**Solution:** `disconnect()` now logs the BYE send's outcome specifically
(sent + destination, skipped + which of socket/peer was null, or the
exception). `handlePeerLost()` now takes a `reason: String`; every call
site names itself and, where relevant, the specific trigger (BYE received
vs. timeout duration).
**Reason:** Purely additive — no timing or protocol logic changed, only
what gets logged and how specifically.
**Expected improvement:** The next capture of a disconnect test should say
exactly which side sent a BYE, whether it was received, and if not,
whether the other side eventually gave up via the 8s watchdog instead —
enough to actually localize the reported bug instead of re-guessing at it.
**Side effects:** None expected. Slightly more log volume on disconnect
specifically (a handful of lines, not per-frame) — not a concern after
Item 1.
**Verification:** Not runnable here. Read-through only; every call site
cross-checked to confirm none were missed (`grep -n "handlePeerLost("`).

---

## Not changed this pass

- The actual WiFi disconnect-propagation bug, if it's not just Item 3
  above or a timing/testing artifact — nothing else found it by reading.
- The actual Bluetooth ROM-detection failure and lag, beyond Items 1 and 3
  above — same.
- `BT_XCHG_MS`/`WIFI_XCHG_MS` themselves — no evidence yet that the
  timeout values are wrong rather than the timeouts being hit at all.
- Everything else FIX 9-14 already covers.



Scope note: one-line fix, `MainActivity.kt` only, prompted by a real CI
build log the user attached (the Thirteenth pass's zip failed
`compileReleaseKotlin`).

---

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (compile error)
**Files modified:** `MainActivity.kt`
**Problem:** `showLinkDebugLogDialog(text: String)`'s parameter name
collided with `TextView`'s own `text` property. Inside `TextView(this)
.apply { text = shown }`, the bare `text` on the left of the assignment
resolved to the outer parameter (immutable) rather than the receiver's
property, so the compiler rejected it as reassigning a `val`. Everywhere
else in the file, the same kind of assignment goes through an explicit
variable (`row.text = ...`), which is never ambiguous — this was the one
bare/unqualified case, and it happened to collide.
**Solution:** Renamed the parameter to `logText`; the function body's one
reference to it (`text.ifBlank { ... }`) updated to match, `text = shown`
inside the `apply` block left as-is since it's now unambiguous.
**Reason:** Real `compileReleaseKotlin` failure from an actual CI run —
see the attached build log's `14_Build APK.txt`.
**Expected improvement:** Build succeeds.
**Side effects:** None — pure rename, no behavior change. The one caller
(`copyLinkDebugLog()`) passes its argument positionally, so it's
unaffected by the parameter's internal name.
**Verification:** No compiler available in this sandbox, as always — but
this fix is about as close to "verified" as this project gets without
one: the failure came from a real Gradle/Kotlin compiler run, the
collision was fully diagnosed against the exact reported line/column, and
grepping confirmed no other function in either of the last two passes'
additions has a parameter name that collides with a property name used
bare inside a nested `apply`/similar block.

---

# CHANGELOG — Earlier passes (summary)

Full entries for these passes were trimmed to keep this file a
reasonable length. None of them touch multiplayer/link code except where
noted — see FILE_CHANGES.md's own history if the exact diff for one of
these ever matters again.

- **Thirteenth** — `MainActivity.kt`: save-state slot picker now shows a
  thumbnail per slot.
- **Twelfth** — `MainActivity.kt`: added the in-app "Copy link log"
  diagnostic (logcat-based at the time; superseded by Seventeenth pass's
  file-based version). Diagnostic only, not a link fix.
- **Eleventh** — `MainActivity.kt`: fixed a Tenth-pass regression where
  every row in the restyled quick game menu silently did nothing when
  tapped (`isClickable`/`isFocusable` on the row view was stealing the
  touch from the `ListView`'s own click dispatch).
- **Tenth** — `MainActivity.kt`: quick game menu restyled and expanded to
  match a reference screenshot (10 items instead of 5); two now-redundant
  Settings rows removed; immersive mode now re-applied on focus regain;
  display-cutout black bar fixed; Screenshot/Reset/Close actions added.
- **Fifth** — First pass to focus on `LinkMultiplayer.kt`/multiplayer
  internals specifically (four earlier undocumented passes had already
  covered audio, rendering, ROM-swap safety, and the control layout
  editor). Fixed missing `@Volatile` on six connection-state fields
  (a real cross-thread visibility bug) and an untracked discovery socket
  that made `disconnect()` a no-op for it.
