// Top-level build file: plugin versions are declared here and applied (without
// version) in app/build.gradle.kts. Keeping versions centralized avoids
// version drift if more modules are added later.
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
