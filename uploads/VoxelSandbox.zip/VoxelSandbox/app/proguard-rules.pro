# Custom views instantiated by the layout inflater from XML tag names (see
# overlay_hud.xml) rather than a direct constructor call in code -- R8's static call
# graph analysis can't see that usage, so without an explicit keep here a minified
# build can crash with InflateException/ClassNotFoundException the first time the
# HUD is shown. These are the ONLY two app classes that need this: everything else
# is reached through ordinary method calls that R8 already traces correctly.
-keep class com.voxelsandbox.game.ui.LookPadView { *; }
-keep class com.voxelsandbox.game.ui.VirtualJoystickView { *; }

# Keep stack traces in crash logs readable (real line numbers) even though class/
# method names are shortened -- negligible size cost, large debugging value.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

-dontwarn com.voxelsandbox.game.**
