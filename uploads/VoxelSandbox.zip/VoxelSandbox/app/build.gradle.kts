plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.voxelsandbox.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.voxelsandbox.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // Shrinks (removes unreachable code/resources) and obfuscates
            // (shortens class/method names) via R8. The keep rules in
            // proguard-rules.pro are narrowly scoped to just the two classes
            // that actually need protection (custom views instantiated by the
            // XML layout inflater), so this isn't the "keep everything" no-op
            // it would be with a blanket keep rule.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
        compose = false
        buildConfig = false // BuildConfig is never referenced anywhere in this project
    }

    packaging {
        resources.excludes.add("META-INF/*")
    }
}

// Intentionally no dependencies block: the engine is built entirely on the
// Android framework SDK + Kotlin stdlib to minimize dependency-resolution
// risk in CI. See the final report for the rationale.
