package com.voxelsandbox.game.world

/**
 * All block types are original (no Minecraft asset/name reuse). Each entry carries its
 * own top/side/bottom texture-atlas cell indices so the mesher can look up UVs without
 * any per-face special-casing.
 */
enum class BlockType(
    val id: Byte,
    val displayName: String,
    val solid: Boolean,
    val opaque: Boolean,
    val breakable: Boolean,
    val placeable: Boolean,
    val topCell: Int,
    val sideCell: Int,
    val bottomCell: Int
) {
    AIR(0, "Air", solid = false, opaque = false, breakable = false, placeable = false, topCell = -1, sideCell = -1, bottomCell = -1),
    GRASS(1, "Grass", solid = true, opaque = true, breakable = true, placeable = true, topCell = 0, sideCell = 1, bottomCell = 2),
    DIRT(2, "Dirt", solid = true, opaque = true, breakable = true, placeable = true, topCell = 2, sideCell = 2, bottomCell = 2),
    STONE(3, "Stone", solid = true, opaque = true, breakable = true, placeable = true, topCell = 3, sideCell = 3, bottomCell = 3),
    SAND(4, "Sand", solid = true, opaque = true, breakable = true, placeable = true, topCell = 4, sideCell = 4, bottomCell = 4),
    WOOD(5, "Wood", solid = true, opaque = true, breakable = true, placeable = true, topCell = 6, sideCell = 5, bottomCell = 6),
    LEAVES(6, "Leaves", solid = true, opaque = true, breakable = true, placeable = true, topCell = 7, sideCell = 7, bottomCell = 7),
    COAL_ORE(7, "Coal Ore", solid = true, opaque = true, breakable = true, placeable = true, topCell = 8, sideCell = 8, bottomCell = 8),
    WATER(8, "Water", solid = false, opaque = false, breakable = false, placeable = false, topCell = 9, sideCell = 9, bottomCell = 9);

    fun cellFor(face: Face): Int = when (face) {
        Face.TOP -> topCell
        Face.BOTTOM -> bottomCell
        else -> sideCell
    }

    companion object {
        private val byId: Array<BlockType?> = arrayOfNulls<BlockType>(16).also { arr ->
            values().forEach { arr[it.id.toInt()] = it }
        }

        fun fromId(id: Byte): BlockType = byId.getOrNull(id.toInt()) ?: AIR

        /** The fixed set of block types placeable from the hotbar, in slot order.
         *  Water is intentionally excluded (not player-placeable in this version). */
        val HOTBAR_ORDER: List<BlockType> = listOf(GRASS, DIRT, STONE, SAND, WOOD, LEAVES, COAL_ORE)
    }
}

enum class Face(val dx: Int, val dy: Int, val dz: Int) {
    TOP(0, 1, 0),
    BOTTOM(0, -1, 0),
    NORTH(0, 0, -1),
    SOUTH(0, 0, 1),
    EAST(1, 0, 0),
    WEST(-1, 0, 0);

    companion object {
        val ALL = values()
    }
}
