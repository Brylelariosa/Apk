package com.voxelsandbox.game.util

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Simple mutable 3D vector. Kept as a plain class (not data class with copy-on-write
 *  semantics) since it's mutated frequently in hot paths (physics/camera) and we want
 *  to avoid per-frame allocation. */
class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun set(nx: Float, ny: Float, nz: Float): Vec3 {
        x = nx; y = ny; z = nz
        return this
    }

    fun set(other: Vec3): Vec3 = set(other.x, other.y, other.z)

    fun add(dx: Float, dy: Float, dz: Float): Vec3 {
        x += dx; y += dy; z += dz
        return this
    }

    fun copy(): Vec3 = Vec3(x, y, z)
}

/** Axis-aligned bounding box, used for both the player collider and chunk/subchunk
 *  bounds used in frustum culling. */
class AABB(
    var minX: Float, var minY: Float, var minZ: Float,
    var maxX: Float, var maxY: Float, var maxZ: Float
) {
    fun offset(dx: Float, dy: Float, dz: Float): AABB =
        AABB(minX + dx, minY + dy, minZ + dz, maxX + dx, maxY + dy, maxZ + dz)

    fun intersects(o: AABB): Boolean =
        minX < o.maxX && maxX > o.minX &&
            minY < o.maxY && maxY > o.minY &&
            minZ < o.maxZ && maxZ > o.minZ

    fun containsPoint(px: Float, py: Float, pz: Float): Boolean =
        px in minX..maxX && py in minY..maxY && pz in minZ..maxZ
}

fun clamp(v: Float, lo: Float, hi: Float): Float = max(lo, min(hi, v))
fun clampInt(v: Int, lo: Int, hi: Int): Int = max(lo, min(hi, v))
fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Floor-divide/mod that behave correctly for negative inputs (unlike Kotlin's `/` and
 *  `%` on Int, which truncate toward zero). Used everywhere world coordinates are
 *  mapped to chunk-local coordinates. */
fun floorDiv(a: Int, b: Int): Int = Math.floorDiv(a, b)
fun floorMod(a: Int, b: Int): Int = Math.floorMod(a, b)

fun floorToInt(v: Float): Int = floor(v).toInt()
fun floorToInt(v: Double): Int = floor(v).toInt()
