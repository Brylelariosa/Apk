package com.voxelsandbox.game.ui

import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Attached to a HUD element only while HUD-customize mode is active (see
 * HudController.enterCustomizeMode). One finger drags the view by adjusting its
 * translationX/Y; a two-finger pinch resizes it by adjusting scaleX/Y uniformly,
 * pivoting on the view's own center (View's default pivot, so it grows/shrinks in
 * place rather than from a corner). [onAdjusted] fires once per gesture, on finger-up,
 * so the caller can persist the resulting position/scale.
 */
class DragResizeTouchListener(
    private val view: View,
    private val minScale: Float = 0.6f,
    private val maxScale: Float = 1.8f,
    private val onAdjusted: () -> Unit
) : View.OnTouchListener {
    private var lastRawX = 0f
    private var lastRawY = 0f

    private val scaleDetector = ScaleGestureDetector(
        view.context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val next = (view.scaleX * detector.scaleFactor).coerceIn(minScale, maxScale)
                view.scaleX = next
                view.scaleY = next
                return true
            }
        }
    )

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                // Also re-synced here on any pointer-count change so the next single-
                // finger MOVE computes its delta from the right starting point instead
                // of jumping using a stale pre-transition position.
                lastRawX = event.rawX
                lastRawY = event.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    v.translationX += event.rawX - lastRawX
                    v.translationY += event.rawY - lastRawY
                }
                lastRawX = event.rawX
                lastRawY = event.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjusted()
        }
        return true
    }
}
