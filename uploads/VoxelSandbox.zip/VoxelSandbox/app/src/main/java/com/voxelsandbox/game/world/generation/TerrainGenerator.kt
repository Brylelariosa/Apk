package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.roundToInt

/**
 * Deterministic seeded terrain generator: the same (seed, chunkX, chunkZ) always
 * produces the same chunk, which is what lets SaveManager store only player-modified
 * chunks and regenerate everything else from the seed on load.
 *
 * Trees are only placed with a margin from the chunk edge (see the `2 until SIZE-2`
 * loop bound below) so a tree's canopy never needs to write into a neighboring,
 * possibly-not-yet-generated chunk. That sacrifices a little tree density right at
 * chunk borders in exchange for avoiding cross-chunk generation races entirely —
 * a good trade given the spec's emphasis on crash/race safety.
 */
class TerrainGenerator(private val seed: Long) {
    private val continentNoise = NoiseGenerator(seed xor 0x9E3779B97F4A7C15L)
    private val detailNoise = NoiseGenerator(seed xor 0x1000193L)
    private val oreNoise = NoiseGenerator(seed xor 0x123456789ABCDEFL)

    fun generate(pos: ChunkPos): Chunk {
        val chunk = Chunk(pos)
        val baseX = pos.x * WorldConfig.CHUNK_SIZE
        val baseZ = pos.z * WorldConfig.CHUNK_SIZE
        val size = WorldConfig.CHUNK_SIZE

        val heights = IntArray(size * size)
        for (lx in 0 until size) {
            for (lz in 0 until size) {
                val wx = baseX + lx
                val wz = baseZ + lz
                val height = columnHeight(wx, wz)
                heights[lz * size + lx] = height
                fillColumn(chunk, lx, lz, wx, wz, height)
            }
        }

        for (lx in 2 until size - 2) {
            for (lz in 2 until size - 2) {
                val height = heights[lz * size + lx]
                if (height > WorldConfig.SEA_LEVEL + 1) {
                    val wx = baseX + lx
                    val wz = baseZ + lz
                    if (shouldPlaceTree(wx, wz)) placeTree(chunk, lx, height, lz)
                }
            }
        }
        return chunk
    }

    private fun columnHeight(wx: Int, wz: Int): Int {
        val continent = continentNoise.fbm2D(wx * 0.004, wz * 0.004, 3, 0.5, 2.0) // -1..1, broad regions
        val detail = detailNoise.fbm2D(wx * 0.02, wz * 0.02, 4, 0.5, 2.0) // -1..1, local shape
        val amplitude = 6.0 + (continent + 1.0) / 2.0 * 34.0 // plains(~6) .. mountains(~40)
        val height = WorldConfig.SEA_LEVEL + (detail * amplitude).roundToInt() + 4
        return height.coerceIn(1, WorldConfig.WORLD_HEIGHT - 1)
    }

    private fun fillColumn(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int) {
        val isBeach = height in (WorldConfig.SEA_LEVEL - 1)..(WorldConfig.SEA_LEVEL + 2)
        for (y in 0 until WorldConfig.WORLD_HEIGHT) {
            val block = when {
                y > height -> if (y <= WorldConfig.SEA_LEVEL) BlockType.WATER else BlockType.AIR
                y == height -> if (isBeach) BlockType.SAND else BlockType.GRASS
                y == 0 -> BlockType.STONE
                y >= height - 3 -> if (isBeach) BlockType.SAND else BlockType.DIRT
                else -> if (isCoalOre(wx, y, wz)) BlockType.COAL_ORE else BlockType.STONE
            }
            if (block != BlockType.AIR) chunk.setBlock(lx, y, lz, block)
        }
    }

    private fun isCoalOre(wx: Int, y: Int, wz: Int): Boolean {
        if (y > WorldConfig.SEA_LEVEL - 2) return false
        val n = oreNoise.noise2D(wx * 0.35 + y * 0.7, wz * 0.35 - y * 0.4)
        return n > 0.72
    }

    private fun shouldPlaceTree(wx: Int, wz: Int): Boolean {
        // Deterministic per-4x4 cell: a cell has at most one tree, at a hash-chosen
        // position within it. Keeps trees spaced out without a separate placement
        // pass or any neighbor coordination.
        val cellX = Math.floorDiv(wx, 4)
        val cellZ = Math.floorDiv(wz, 4)
        val h = hash(cellX, cellZ, seed)
        if ((h and 0xFF) >= 18) return false
        val px = (h ushr 8) and 3
        val pz = (h ushr 10) and 3
        return Math.floorMod(wx, 4) == px && Math.floorMod(wz, 4) == pz
    }

    private fun placeTree(chunk: Chunk, lx: Int, baseY: Int, lz: Int) {
        val h = hash(lx, lz, seed)
        val trunkHeight = 4 + ((h ushr 4) and 1)
        val topY = baseY + trunkHeight
        for (y in (baseY + 1)..topY) {
            if (y < WorldConfig.WORLD_HEIGHT) chunk.setBlock(lx, y, lz, BlockType.WOOD)
        }
        for (dx in -2..2) {
            for (dz in -2..2) {
                for (dy in -2..1) {
                    val dist = dx * dx + dz * dz + dy * dy
                    if (dist > 6) continue
                    val y = topY + dy
                    if (y !in 0 until WorldConfig.WORLD_HEIGHT) continue
                    val bx = lx + dx
                    val bz = lz + dz
                    if (bx !in 0 until WorldConfig.CHUNK_SIZE || bz !in 0 until WorldConfig.CHUNK_SIZE) continue
                    if (chunk.getBlock(bx, y, bz) == BlockType.AIR) {
                        chunk.setBlock(bx, y, bz, BlockType.LEAVES)
                    }
                }
            }
        }
    }

    companion object {
        private fun hash(x: Int, z: Int, seed: Long): Int {
            var h = x * 374761393 + z * 668265263 + seed.toInt() * 1274126177
            h = (h xor (h ushr 13)) * -1028477387
            return h xor (h ushr 16)
        }
    }
}
