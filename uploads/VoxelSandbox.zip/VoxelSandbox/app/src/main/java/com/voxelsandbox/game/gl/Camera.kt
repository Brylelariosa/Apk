package com.voxelsandbox.game.gl

import android.opengl.Matrix
import kotlin.math.cos
import kotlin.math.sin

/** yaw = 0 looks down -Z, matching Player's documented convention and the movement
 *  formula in GameEngine — the two must stay in sync or "forward" would visually
 *  drift from where the camera actually looks. */
class Camera {
    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    val viewProjMatrix = FloatArray(16)

    var fovYDegrees = 70f
    var nearPlane = 0.08f
    var farPlane = 420f

    fun setPerspective(aspect: Float) {
        Matrix.perspectiveM(projMatrix, 0, fovYDegrees, aspect, nearPlane, farPlane)
    }

    fun updateView(eyeX: Float, eyeY: Float, eyeZ: Float, yaw: Float, pitch: Float) {
        val dirX = cos(pitch) * sin(yaw)
        val dirY = sin(pitch)
        val dirZ = -cos(pitch) * cos(yaw)
        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            eyeX + dirX, eyeY + dirY, eyeZ + dirZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(viewProjMatrix, 0, projMatrix, 0, viewMatrix, 0)
    }
}
