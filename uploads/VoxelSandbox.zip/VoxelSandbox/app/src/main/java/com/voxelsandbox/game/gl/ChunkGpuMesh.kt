package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.mesh.MeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Owns one subchunk's GPU vertex/index buffers. Every method here issues GL calls,
 * so instances must only ever be touched from the GL thread (GameRenderer enforces
 * this by only creating/uploading/disposing from onDrawFrame).
 */
class ChunkGpuMesh {
    private var vbo = 0
    private var ibo = 0
    private var indexCount = 0
    private var allocated = false

    fun upload(data: MeshData) {
        if (data.isEmpty()) {
            dispose()
            return
        }
        if (!allocated) {
            val ids = IntArray(2)
            GLES30.glGenBuffers(2, ids, 0)
            vbo = ids[0]
            ibo = ids[1]
            allocated = true
        }

        val vertexBuffer = ByteBuffer.allocateDirect(data.vertexData.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(data.vertexData); position(0) }
        val indexBuffer = ByteBuffer.allocateDirect(data.indices.size * 4)
            .order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(data.indices); position(0) }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.vertexData.size * 4, vertexBuffer, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, data.indices.size * 4, indexBuffer, GLES30.GL_STATIC_DRAW)

        indexCount = data.indices.size
    }

    /** [mode] defaults to GL_TRIANGLES for normal terrain/particle/cloud meshes;
     *  GameRenderer passes GL_LINES for the block-highlight wireframe so it can
     *  reuse this same buffer/shader plumbing instead of a separate code path. */
    fun draw(mode: Int = GLES30.GL_TRIANGLES) {
        if (!allocated || indexCount == 0) return
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        val stride = 6 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, stride, 5 * 4)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glDrawElements(mode, indexCount, GLES30.GL_UNSIGNED_INT, 0)
    }

    fun dispose() {
        if (allocated) {
            GLES30.glDeleteBuffers(2, intArrayOf(vbo, ibo), 0)
            allocated = false
            indexCount = 0
        }
    }
}
