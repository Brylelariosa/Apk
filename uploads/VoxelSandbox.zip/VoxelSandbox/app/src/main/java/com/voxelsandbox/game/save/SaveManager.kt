package com.voxelsandbox.game.save

import android.content.Context
import com.voxelsandbox.game.inventory.Inventory
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

data class LoadedSave(
    val seed: Long,
    val playerX: Float, val playerY: Float, val playerZ: Float,
    val yaw: Float, val pitch: Float,
    val inventoryCounts: IntArray,
    val chunkOverrides: Map<ChunkPos, ByteArray>
)

/**
 * Single-slot world save to app-private internal storage (no storage permission
 * needed — nothing here is written anywhere the OS would prompt for access). Only
 * chunks the player has actually modified are written; everything else regenerates
 * deterministically from the seed, which is what keeps the save small no matter how
 * much of the world has been explored.
 *
 * Call from a background thread only (see GameEngine) — this does blocking file I/O.
 */
class SaveManager(context: Context) {
    private val saveFile = File(context.filesDir, "world1.sav")

    fun hasSave(): Boolean = saveFile.exists()

    fun save(seed: Long, player: Player, inventory: Inventory, world: World) {
        val tmp = File(saveFile.parentFile, saveFile.name + ".tmp")
        DataOutputStream(GZIPOutputStream(tmp.outputStream().buffered())).use { out ->
            out.writeInt(MAGIC)
            out.writeInt(VERSION)
            out.writeLong(seed)

            out.writeFloat(player.position.x)
            out.writeFloat(player.position.y)
            out.writeFloat(player.position.z)
            out.writeFloat(player.yaw)
            out.writeFloat(player.pitch)

            val counts = inventory.exportCounts()
            out.writeInt(counts.size)
            for (c in counts) out.writeInt(c)

            val modified = world.allChunks().filter { it.hasPlayerEdits }
            out.writeInt(modified.size)
            for (chunk in modified) {
                out.writeInt(chunk.pos.x)
                out.writeInt(chunk.pos.z)
                out.write(chunk.serializeBlocks())
            }
        }
        // Write to a temp file and swap it in only once fully written, so a crash or
        // low-battery kill mid-save can't leave a half-written, corrupt save file.
        tmp.copyTo(saveFile, overwrite = true)
        tmp.delete()
    }

    fun load(): LoadedSave? {
        if (!saveFile.exists()) return null
        return try {
            DataInputStream(GZIPInputStream(saveFile.inputStream().buffered())).use { input ->
                val magic = input.readInt()
                val version = input.readInt()
                if (magic != MAGIC || version != VERSION) return null

                val seed = input.readLong()
                val px = input.readFloat(); val py = input.readFloat(); val pz = input.readFloat()
                val yaw = input.readFloat(); val pitch = input.readFloat()

                val countSize = input.readInt()
                if (countSize < 0 || countSize > 64) return null
                val counts = IntArray(countSize) { input.readInt() }

                val chunkCount = input.readInt()
                if (chunkCount < 0 || chunkCount > 200_000) return null
                val overrides = HashMap<ChunkPos, ByteArray>(chunkCount * 2)
                repeat(chunkCount) {
                    val cx = input.readInt()
                    val cz = input.readInt()
                    val bytes = ByteArray(WorldConfig.BYTES_PER_CHUNK)
                    input.readFully(bytes)
                    overrides[ChunkPos(cx, cz)] = bytes
                }

                LoadedSave(seed, px, py, pz, yaw, pitch, counts, overrides)
            }
        } catch (t: Throwable) {
            // Corrupted or partial save: treat as "no usable save" rather than
            // crashing or propagating the exception.
            null
        }
    }

    companion object {
        private const val MAGIC = 0x56534158 // "VSAX"
        private const val VERSION = 1
    }
}
