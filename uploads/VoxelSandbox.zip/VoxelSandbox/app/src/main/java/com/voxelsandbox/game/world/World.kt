package com.voxelsandbox.game.world

import com.voxelsandbox.game.util.floorDiv
import com.voxelsandbox.game.util.floorMod
import java.util.concurrent.ConcurrentHashMap

/**
 * Owns the chunk map. Reads (getBlock/isOpaque/isSolid) are called from the GL/game
 * thread every frame (physics, raycasting) and from background generation/mesh worker
 * threads (neighbor lookups) — ConcurrentHashMap gives safe, lock-free reads. Writes
 * (putChunk/removeChunk) come from WorldManager only.
 *
 * A coordinate in a chunk that isn't loaded is treated as AIR/non-opaque. This is a
 * deliberate, safe default: it means chunk-boundary faces render (rather than leaving
 * holes) until the real neighbor loads and both sides remesh.
 */
class World {
    private val chunks = ConcurrentHashMap<ChunkPos, Chunk>()

    fun getChunk(pos: ChunkPos): Chunk? = chunks[pos]

    fun putChunk(chunk: Chunk) {
        chunks[chunk.pos] = chunk
    }

    fun removeChunk(pos: ChunkPos): Chunk? = chunks.remove(pos)

    fun allChunks(): Collection<Chunk> = chunks.values

    fun chunkCount(): Int = chunks.size

    fun getBlock(x: Int, y: Int, z: Int): BlockType {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return BlockType.AIR
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[ChunkPos(cx, cz)] ?: return BlockType.AIR
        val lx = floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = floorMod(z, WorldConfig.CHUNK_SIZE)
        return chunk.getBlock(lx, y, lz)
    }

    fun isOpaque(x: Int, y: Int, z: Int): Boolean = getBlock(x, y, z).opaque

    fun isSolid(x: Int, y: Int, z: Int): Boolean = getBlock(x, y, z).solid

    /** Returns false if the target chunk isn't loaded (caller should not treat this as
     *  a successful edit). */
    fun setBlock(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return false
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[ChunkPos(cx, cz)] ?: return false
        val lx = floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = floorMod(z, WorldConfig.CHUNK_SIZE)
        chunk.setBlock(lx, y, lz, type)
        chunk.hasPlayerEdits = true
        return true
    }
}
