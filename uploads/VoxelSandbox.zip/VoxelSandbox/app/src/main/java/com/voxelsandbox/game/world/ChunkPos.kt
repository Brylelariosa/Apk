package com.voxelsandbox.game.world

import com.voxelsandbox.game.util.floorDiv
import com.voxelsandbox.game.util.floorToInt

/** Chunk-grid coordinates (one unit = one CHUNK_SIZE column). */
data class ChunkPos(val x: Int, val z: Int) {

    fun distanceSquaredTo(other: ChunkPos): Long {
        val dx = (x - other.x).toLong()
        val dz = (z - other.z).toLong()
        return dx * dx + dz * dz
    }

    companion object {
        fun fromWorld(worldX: Float, worldZ: Float): ChunkPos = ChunkPos(
            floorDiv(floorToInt(worldX), WorldConfig.CHUNK_SIZE),
            floorDiv(floorToInt(worldZ), WorldConfig.CHUNK_SIZE)
        )
    }
}
