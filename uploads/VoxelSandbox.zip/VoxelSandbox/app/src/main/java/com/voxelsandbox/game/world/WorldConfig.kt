package com.voxelsandbox.game.world

/**
 * Central sizing constants for the voxel world.
 *
 * World height is deliberately 64 (not the spec-suggested 128): halving the vertical
 * extent halves per-chunk memory (16 KB vs 32 KB raw block bytes) which matters a lot
 * once you multiply by thousands of chunks at high render distances on a 4 GB device.
 * 64 blocks (sea level 24, max terrain ~60) is still enough vertical range for hills
 * and mountains at this world's scale. See WorldManager for the memory-budget system
 * that additionally bounds *how many* chunks stay resident regardless of this size.
 */
object WorldConfig {
    const val CHUNK_SIZE = 16 // X/Z extent of a chunk
    const val SUBCHUNK_HEIGHT = 16
    const val SUBCHUNKS_PER_CHUNK = 4
    const val WORLD_HEIGHT = SUBCHUNK_HEIGHT * SUBCHUNKS_PER_CHUNK // 64

    const val SEA_LEVEL = 24

    const val BLOCKS_PER_SUBCHUNK = CHUNK_SIZE * SUBCHUNK_HEIGHT * CHUNK_SIZE // 4096
    const val BYTES_PER_CHUNK = CHUNK_SIZE * WORLD_HEIGHT * CHUNK_SIZE // 16384

    const val MAX_INTERACT_REACH = 6f

    /** Player falling below this Y (e.g. an unloaded/void column) is teleported back
     *  to spawn rather than falling forever. */
    const val VOID_Y = -16f
}
