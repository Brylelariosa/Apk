package com.voxelsandbox.game.ui

import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.voxelsandbox.game.R
import com.voxelsandbox.game.input.InputState
import com.voxelsandbox.game.inventory.Inventory
import com.voxelsandbox.game.world.BlockType

/**
 * Wires the HUD's touch views (joystick, look pad, action buttons, hotbar) to the
 * shared InputState and Inventory. Kept separate from GameActivity so the activity
 * doesn't balloon into a god-class of findViewById calls.
 */
class HudController(
    private val root: View,
    private val input: InputState,
    private val inventory: Inventory,
    private val onPause: () -> Unit
) {
    private val joystick: VirtualJoystickView = root.findViewById(R.id.joystick)
    private val lookPad: LookPadView = root.findViewById(R.id.look_pad)
    private val btnJump: View = root.findViewById(R.id.btn_jump)
    private val btnBreak: View = root.findViewById(R.id.btn_break)
    private val btnPlace: View = root.findViewById(R.id.btn_place)
    private val btnInventory: View = root.findViewById(R.id.btn_inventory)
    private val btnPauseView: View = root.findViewById(R.id.btn_pause)
    private val hotbarContainer: LinearLayout = root.findViewById(R.id.hotbar_container)
    private val inventoryPanel: View = root.findViewById(R.id.inventory_panel)
    private val inventoryList: LinearLayout = root.findViewById(R.id.inventory_list)

    val debugText: TextView = root.findViewById(R.id.debug_text)

    private val hotbarSlotViews = ArrayList<TextView>()

    init {
        joystick.onChanged = { forward, strafe ->
            input.moveForward = forward
            input.moveStrafe = strafe
        }
        lookPad.onLookDelta = { dx, dy -> input.addLookDelta(dx, dy) }

        bindHold(btnJump) { input.jumpHeld = it }
        bindHold(btnBreak) { input.breakHeld = it }
        bindHold(btnPlace) { input.placeHeld = it }

        btnInventory.setOnClickListener { toggleInventoryPanel() }
        btnPauseView.setOnClickListener { onPause() }

        buildHotbar()
    }

    private fun bindHold(view: View, setter: (Boolean) -> Unit) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    setter(true)
                    v.isPressed = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    setter(false)
                    v.isPressed = false
                }
            }
            true
        }
    }

    private fun buildHotbar() {
        hotbarContainer.removeAllViews()
        hotbarSlotViews.clear()
        val density = root.resources.displayMetrics.density
        val slotSizePx = (54 * density).toInt()
        val marginPx = (4 * density).toInt()
        for (i in inventory.slots.indices) {
            val tv = TextView(root.context).apply {
                layoutParams = LinearLayout.LayoutParams(slotSizePx, slotSizePx).apply {
                    marginStart = marginPx
                    marginEnd = marginPx
                }
                gravity = Gravity.CENTER
                textSize = 10f
                setTextColor(Color.WHITE)
                setOnClickListener {
                    inventory.select(i)
                    refreshHotbar()
                }
            }
            hotbarSlotViews.add(tv)
            hotbarContainer.addView(tv)
        }
        refreshHotbar()
    }

    /** Called from GameActivity's periodic tick (a few times/sec) to keep counts
     *  and the selection highlight current — cheap enough (a handful of small
     *  TextViews) to just redraw rather than diff against previous state. */
    fun refreshHotbar() {
        for (i in inventory.slots.indices) {
            val tv = hotbarSlotViews[i]
            val block = inventory.slots[i]
            tv.text = "${shortName(block)}\n${inventory.countAt(i)}"
            tv.setBackgroundResource(
                if (i == inventory.selectedIndex) R.drawable.bg_hotbar_slot_selected else R.drawable.bg_hotbar_slot
            )
        }
        if (inventoryPanel.visibility == View.VISIBLE) refreshInventoryPanel()
    }

    private fun shortName(block: BlockType): String = if (block == BlockType.COAL_ORE) "Coal" else block.displayName

    private fun toggleInventoryPanel() {
        if (inventoryPanel.visibility == View.VISIBLE) {
            inventoryPanel.visibility = View.GONE
        } else {
            refreshInventoryPanel()
            inventoryPanel.visibility = View.VISIBLE
        }
    }

    private fun refreshInventoryPanel() {
        inventoryList.removeAllViews()
        for (i in inventory.slots.indices) {
            val block = inventory.slots[i]
            val row = TextView(root.context).apply {
                text = "${block.displayName}: ${inventory.countAt(i)}"
                setTextColor(if (i == inventory.selectedIndex) Color.parseColor("#F2C94C") else Color.WHITE)
                textSize = 13f
                setPadding(0, 6, 0, 6)
                setOnClickListener {
                    inventory.select(i)
                    refreshHotbar()
                }
            }
            inventoryList.addView(row)
        }
    }

    /** Releases all held inputs — used when leaving gameplay (pause/menu) so a
     *  finger lifted off-screen (e.g. by a system dialog) can't leave movement or
     *  break/place stuck "on". */
    fun releaseAllInputs() {
        input.moveForward = 0f
        input.moveStrafe = 0f
        input.jumpHeld = false
        input.breakHeld = false
        input.placeHeld = false
    }
}
