package com.voxelsandbox.game.gl

import kotlin.math.sqrt

/**
 * Extracts the 6 view-frustum planes from a combined view-projection matrix so
 * GameRenderer can skip drawing subchunks that can't possibly be visible — this is
 * the "renderer must not simply draw every loaded chunk" requirement.
 */
class Frustum {
    // Each plane: (a,b,c,d) for ax+by+cz+d=0, normalized, pointing inward.
    private val planes = Array(6) { FloatArray(4) }

    fun update(m: FloatArray) {
        // Android's Matrix utilities store column-major 4x4 (index = col*4+row), so
        // "row i" of the mathematical matrix is (m[i], m[4+i], m[8+i], m[12+i]).
        val r0 = floatArrayOf(m[0], m[4], m[8], m[12])
        val r1 = floatArrayOf(m[1], m[5], m[9], m[13])
        val r2 = floatArrayOf(m[2], m[6], m[10], m[14])
        val r3 = floatArrayOf(m[3], m[7], m[11], m[15])

        combine(r3, r0, 1f, planes[0])  // left
        combine(r3, r0, -1f, planes[1]) // right
        combine(r3, r1, 1f, planes[2])  // bottom
        combine(r3, r1, -1f, planes[3]) // top
        combine(r3, r2, 1f, planes[4])  // near
        combine(r3, r2, -1f, planes[5]) // far

        for (p in planes) normalize(p)
    }

    private fun combine(a: FloatArray, b: FloatArray, sign: Float, out: FloatArray) {
        out[0] = a[0] + sign * b[0]
        out[1] = a[1] + sign * b[1]
        out[2] = a[2] + sign * b[2]
        out[3] = a[3] + sign * b[3]
    }

    private fun normalize(p: FloatArray) {
        val len = sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2])
        if (len > 1e-6f) {
            p[0] /= len; p[1] /= len; p[2] /= len; p[3] /= len
        }
    }

    /** Conservative test: only returns false when the box is definitely fully
     *  outside at least one plane (the standard "positive vertex" method). */
    fun isBoxVisible(minX: Float, minY: Float, minZ: Float, maxX: Float, maxY: Float, maxZ: Float): Boolean {
        for (p in planes) {
            val px = if (p[0] >= 0f) maxX else minX
            val py = if (p[1] >= 0f) maxY else minY
            val pz = if (p[2] >= 0f) maxZ else minZ
            if (p[0] * px + p[1] * py + p[2] * pz + p[3] < 0f) return false
        }
        return true
    }
}
