package com.voxelsandbox.game.player

import com.voxelsandbox.game.util.Vec3
import com.voxelsandbox.game.util.clamp

/** Position is the feet position (bottom-center of the collision box). Yaw/pitch are
 *  in radians; yaw = 0 looks down -Z (see Camera for the matching view formula). */
class Player(
    val position: Vec3 = Vec3(0f, 48f, 0f),
    var yaw: Float = 0f,
    var pitch: Float = 0f
) {
    val velocity: Vec3 = Vec3(0f, 0f, 0f)
    var onGround: Boolean = false

    /** True until the spawn column has generated and the player has been dropped
     *  onto the surface; physics is held off until then so the player can't fall
     *  through not-yet-generated terrain. */
    var waitingForSpawn: Boolean = true

    companion object {
        const val WIDTH = 0.6f
        const val HEIGHT = 1.8f
        const val EYE_HEIGHT = 1.62f
        const val MAX_PITCH = 1.5533f // ~89 degrees, avoids camera flip at the poles
    }

    fun addLook(dYaw: Float, dPitch: Float) {
        yaw += dYaw
        pitch = clamp(pitch + dPitch, -MAX_PITCH, MAX_PITCH)
    }

    fun eyeX() = position.x
    fun eyeY() = position.y + EYE_HEIGHT
    fun eyeZ() = position.z
}
