package com.voxelsandbox.game.world

import android.app.ActivityManager
import android.content.Context
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.ChunkMesher
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.PriorityBlockingQueue
import kotlin.math.max
import kotlin.math.min

data class ChunkStats(val loadedChunks: Int, val genQueueSize: Int, val meshQueueSize: Int, val chunkBudget: Int)

/**
 * Owns chunk lifecycle end-to-end: deciding which chunks should exist for the
 * player's position and render distance, generating and meshing them off the main
 * thread with small bounded worker pools, and unloading chunks that fall out of
 * range. Player-driven edits (break/place) get top scheduling priority so they feel
 * instant even while the background streaming system is busy.
 *
 * GPU work (uploading a finished mesh, deleting a mesh for an unloaded chunk) cannot
 * happen on these worker threads — only the GL thread owns the EGL context — so
 * finished work is handed off via [pendingMeshUploads] / [pendingUnloads], which
 * GameRenderer drains once per frame from onDrawFrame.
 */
class WorldManager(
    private val world: World,
    private val generator: TerrainGenerator,
    private val atlas: TextureAtlas,
    context: Context,
    private val savedChunkOverrides: Map<ChunkPos, ByteArray> = emptyMap()
) {
    data class MeshResult(val pos: ChunkPos, val subY: Int, val data: MeshData)

    private data class GenJob(val pos: ChunkPos, val priority: Long)
    private data class MeshJob(val pos: ChunkPos, val subY: Int, val priority: Long)

    private val chunkStates = ConcurrentHashMap<ChunkPos, ChunkState>()
    private val genQueue = PriorityBlockingQueue<GenJob>(64, compareBy { it.priority })
    private val meshQueue = PriorityBlockingQueue<MeshJob>(64, compareBy { it.priority })
    private val queuedMeshKeys = ConcurrentHashMap.newKeySet<Long>()

    val pendingMeshUploads = LinkedBlockingQueue<MeshResult>()
    val pendingUnloads = LinkedBlockingQueue<ChunkPos>()

    val maxLoadedChunks: Int = computeChunkBudget(context)

    @Volatile private var running = false
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var renderDistance = 8
    @Volatile private var lastSchedCenter: ChunkPos? = null

    private var cachedOffsetRadius = -1
    private var cachedOffsets: Array<IntArray> = emptyArray()

    private val workerCount = max(1, min(2, Runtime.getRuntime().availableProcessors() / 2))
    private val threads = ArrayList<Thread>()

    fun start() {
        if (running) return
        running = true
        repeat(workerCount) { i ->
            Thread({ genWorkerLoop() }, "voxel-gen-$i").apply { isDaemon = true; start() }.also { threads.add(it) }
        }
        repeat(workerCount) { i ->
            Thread({ meshWorkerLoop() }, "voxel-mesh-$i").apply { isDaemon = true; start() }.also { threads.add(it) }
        }
        Thread({ schedulerLoop() }, "voxel-scheduler").apply { isDaemon = true; start() }.also { threads.add(it) }
    }

    fun shutdown() {
        running = false
        threads.forEach { it.interrupt() }
        threads.clear()
    }

    /** Cheap: just records the latest position/setting for the scheduler thread to
     *  pick up. Safe to call every frame from the game loop. */
    fun updatePlayerPosition(x: Float, z: Float, renderDistanceChunks: Int) {
        playerX = x
        playerZ = z
        renderDistance = renderDistanceChunks
    }

    fun stats(): ChunkStats = ChunkStats(world.chunkCount(), genQueue.size, meshQueue.size, maxLoadedChunks)

    fun isChunkGenerated(pos: ChunkPos): Boolean = chunkStates[pos] == ChunkState.GENERATED

    /** Forces a chunk to the very front of the generation queue. Used once at world
     *  start/load so the spawn column is ready quickly instead of waiting its turn. */
    fun requestImmediateChunk(pos: ChunkPos) {
        if ((chunkStates[pos] ?: ChunkState.UNLOADED) == ChunkState.UNLOADED) {
            chunkStates[pos] = ChunkState.QUEUED
            genQueue.put(GenJob(pos, Long.MIN_VALUE))
        }
    }

    /** Applies a player-driven block edit and schedules the minimal set of remeshes
     *  (this subchunk, plus neighbors across any boundary the edit touched) at top
     *  priority. */
    fun setBlockAndRemesh(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (!world.setBlock(x, y, z, type)) return false
        markDirtyAround(x, y, z)
        return true
    }

    private fun markDirtyAround(x: Int, y: Int, z: Int) {
        val cx = Math.floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = Math.floorDiv(z, WorldConfig.CHUNK_SIZE)
        val lx = Math.floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = Math.floorMod(z, WorldConfig.CHUNK_SIZE)
        val subY = (y / WorldConfig.SUBCHUNK_HEIGHT).coerceIn(0, WorldConfig.SUBCHUNKS_PER_CHUNK - 1)
        val ly = y % WorldConfig.SUBCHUNK_HEIGHT

        val affected = LinkedHashSet<Pair<ChunkPos, Int>>()
        affected.add(ChunkPos(cx, cz) to subY)
        if (lx == 0) affected.add(ChunkPos(cx - 1, cz) to subY)
        if (lx == WorldConfig.CHUNK_SIZE - 1) affected.add(ChunkPos(cx + 1, cz) to subY)
        if (lz == 0) affected.add(ChunkPos(cx, cz - 1) to subY)
        if (lz == WorldConfig.CHUNK_SIZE - 1) affected.add(ChunkPos(cx, cz + 1) to subY)
        if (ly == 0 && subY > 0) affected.add(ChunkPos(cx, cz) to subY - 1)
        if (ly == WorldConfig.SUBCHUNK_HEIGHT - 1 && subY < WorldConfig.SUBCHUNKS_PER_CHUNK - 1) {
            affected.add(ChunkPos(cx, cz) to subY + 1)
        }

        for ((pos, sy) in affected) {
            if (chunkStates[pos] == ChunkState.GENERATED) enqueueMesh(pos, sy, Long.MIN_VALUE)
        }
    }

    // ---- Scheduler: decides the wanted chunk set and drives load/unload ----------

    private fun schedulerLoop() {
        while (running) {
            try {
                val center = ChunkPos.fromWorld(playerX, playerZ)
                if (center != lastSchedCenter) {
                    lastSchedCenter = center
                    rebuildWantedSet(center, renderDistance)
                }
                Thread.sleep(150)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun offsetsFor(radius: Int): Array<IntArray> {
        if (radius != cachedOffsetRadius) {
            val list = ArrayList<IntArray>((2 * radius + 1) * (2 * radius + 1))
            for (dx in -radius..radius) for (dz in -radius..radius) list.add(intArrayOf(dx, dz))
            list.sortBy { it[0] * it[0] + it[1] * it[1] }
            cachedOffsets = list.toTypedArray()
            cachedOffsetRadius = radius
        }
        return cachedOffsets
    }

    private fun rebuildWantedSet(center: ChunkPos, radius: Int) {
        val offsets = offsetsFor(radius)
        val cap = min(offsets.size, maxLoadedChunks)
        val wanted = LinkedHashSet<ChunkPos>(cap * 2)
        for (i in 0 until cap) {
            val o = offsets[i]
            wanted.add(ChunkPos(center.x + o[0], center.z + o[1]))
        }

        for (pos in wanted) {
            val state = chunkStates[pos] ?: ChunkState.UNLOADED
            if (state == ChunkState.UNLOADED) {
                chunkStates[pos] = ChunkState.QUEUED
                genQueue.put(GenJob(pos, pos.distanceSquaredTo(center)))
            }
        }

        // The unload boundary must track whichever constraint is tighter right now:
        // the radius setting, or the memory budget cutting the wanted set off
        // earlier. Using only a fixed radius here would let already-loaded chunks
        // beyond the budget rank linger forever once render distance exceeds what
        // the budget allows — exactly the extreme (60-chunk) case the budget exists
        // for. A little hysteresis beyond the cutoff avoids thrashing chunks right
        // at the boundary in and out of existence every scheduler tick.
        val cutoffDistSq = if (cap > 0) {
            val o = offsets[cap - 1]
            (o[0] * o[0] + o[1] * o[1]).toLong()
        } else 0L
        val hysteresisDist = kotlin.math.sqrt(cutoffDistSq.toDouble()) + 2.0
        val hysteresisDistSq = (hysteresisDist * hysteresisDist).toLong()

        val toUnload = ArrayList<ChunkPos>()
        for (pos in chunkStates.keys) {
            if (wanted.contains(pos)) continue
            if (pos.distanceSquaredTo(center) > hysteresisDistSq) toUnload.add(pos)
        }
        for (pos in toUnload) unloadChunk(pos)
    }

    private fun unloadChunk(pos: ChunkPos) {
        chunkStates[pos] = ChunkState.UNLOADING
        world.removeChunk(pos)
        chunkStates.remove(pos)
        pendingUnloads.put(pos)
    }

    // ---- Generation ---------------------------------------------------------------

    private fun genWorkerLoop() {
        while (running) {
            val job = try {
                genQueue.take()
            } catch (e: InterruptedException) {
                return
            }
            if (chunkStates[job.pos] != ChunkState.QUEUED) continue // cancelled/obsolete
            chunkStates[job.pos] = ChunkState.GENERATING

            val chunk = try {
                val override = savedChunkOverrides[job.pos]
                if (override != null) {
                    Chunk(job.pos).apply {
                        deserializeBlocks(override)
                        hasPlayerEdits = true
                    }
                } else {
                    generator.generate(job.pos)
                }
            } catch (t: Throwable) {
                chunkStates.remove(job.pos)
                continue
            }

            if (chunkStates[job.pos] != ChunkState.GENERATING) continue // unloaded mid-generation

            world.putChunk(chunk)
            chunkStates[job.pos] = ChunkState.GENERATED
            onChunkGenerated(job.pos)
        }
    }

    private fun onChunkGenerated(pos: ChunkPos) {
        val center = lastSchedCenter ?: pos
        for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
            enqueueMesh(pos, subY, pos.distanceSquaredTo(center))
        }
        // Neighbors that already exist assumed "unknown" (non-opaque) across this
        // shared boundary; now that real data exists, they need to remesh too.
        val neighbors = arrayOf(
            ChunkPos(pos.x - 1, pos.z), ChunkPos(pos.x + 1, pos.z),
            ChunkPos(pos.x, pos.z - 1), ChunkPos(pos.x, pos.z + 1)
        )
        for (n in neighbors) {
            if (chunkStates[n] == ChunkState.GENERATED) {
                for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                    enqueueMesh(n, subY, n.distanceSquaredTo(center))
                }
            }
        }
    }

    /** Re-queues mesh jobs for every currently generated chunk. Used when the GL
     *  surface/context is recreated (e.g. after the app is backgrounded) and any
     *  previously uploaded GPU meshes are now invalid handles — the CPU-side block
     *  data itself is untouched, so this only needs to remesh, not regenerate. */
    fun remeshAllLoaded() {
        val center = lastSchedCenter
        for (chunk in world.allChunks()) {
            if (chunkStates[chunk.pos] != ChunkState.GENERATED) continue
            for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                val priority = center?.let { chunk.pos.distanceSquaredTo(it) } ?: 0L
                enqueueMesh(chunk.pos, subY, priority)
            }
        }
    }

    // ---- Meshing --------------------------------------------------------------

    private fun enqueueMesh(pos: ChunkPos, subY: Int, priority: Long) {
        val key = meshKey(pos, subY)
        if (!queuedMeshKeys.add(key)) return
        meshQueue.put(MeshJob(pos, subY, priority))
    }

    private fun meshKey(pos: ChunkPos, subY: Int): Long =
        (pos.x.toLong() and 0xFFFFFL) or ((pos.z.toLong() and 0xFFFFFL) shl 20) or (subY.toLong() shl 40)

    private fun meshWorkerLoop() {
        while (running) {
            val job = try {
                meshQueue.take()
            } catch (e: InterruptedException) {
                return
            }
            queuedMeshKeys.remove(meshKey(job.pos, job.subY))
            if (chunkStates[job.pos] != ChunkState.GENERATED) continue

            val chunk = world.getChunk(job.pos) ?: continue
            val sub = chunk.subChunks.getOrNull(job.subY) ?: continue
            sub.meshDirty = false

            val data = try {
                ChunkMesher.buildSubChunkMesh(world, job.pos.x, job.pos.z, job.subY, atlas)
            } catch (t: Throwable) {
                continue
            }
            sub.isEmpty = data.isEmpty()

            if (chunkStates[job.pos] == ChunkState.GENERATED) {
                pendingMeshUploads.put(MeshResult(job.pos, job.subY, data))
            }
        }
    }

    companion object {
        /** Budgets raw chunk-block-data memory to a small slice of total device RAM,
         *  rather than trusting the render-distance setting alone. This is what
         *  keeps a 60-chunk render distance from trying to hold hundreds of MB of
         *  voxel data on a 4 GB device: far corners beyond the budget simply don't
         *  load, no matter how far the visual setting is cranked. See the final
         *  report for the exact numbers this produces at each preset. */
        private fun computeChunkBudget(context: Context): Int {
            return try {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val info = ActivityManager.MemoryInfo()
                am.getMemoryInfo(info)
                val budgetBytes = (info.totalMem * 0.03).toLong()
                val perChunk = WorldConfig.BYTES_PER_CHUNK.toLong()
                (budgetBytes / perChunk).toInt().coerceIn(400, 20000)
            } catch (t: Throwable) {
                3000
            }
        }
    }
}
