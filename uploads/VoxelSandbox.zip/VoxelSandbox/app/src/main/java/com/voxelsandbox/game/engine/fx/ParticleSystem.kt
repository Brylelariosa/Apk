package com.voxelsandbox.game.engine.fx

import com.voxelsandbox.game.world.BlockType
import kotlin.random.Random

/**
 * Fixed-capacity pooled particle system: parallel primitive arrays, no per-particle
 * object allocation, so spawning/updating never triggers GC churn. Deliberately
 * knows nothing about GL/meshing — GameRenderer reads the active particles each
 * frame and builds tiny cube geometry from them (see GameRenderer), keeping this
 * class purely about physics/lifetime.
 */
class ParticleSystem(private val capacity: Int = 200) {
    private val posX = FloatArray(capacity)
    private val posY = FloatArray(capacity)
    private val posZ = FloatArray(capacity)
    private val velX = FloatArray(capacity)
    private val velY = FloatArray(capacity)
    private val velZ = FloatArray(capacity)
    private val life = FloatArray(capacity)
    private val maxLife = FloatArray(capacity)
    private val cell = IntArray(capacity)
    private var activeCount = 0

    private val rnd = Random(System.nanoTime())

    fun spawnBurst(x: Float, y: Float, z: Float, block: BlockType) {
        if (block == BlockType.AIR) return
        repeat(7) {
            if (activeCount >= capacity) return
            val i = activeCount++
            posX[i] = x; posY[i] = y; posZ[i] = z
            velX[i] = (rnd.nextFloat() - 0.5f) * 2.6f
            velY[i] = rnd.nextFloat() * 3.2f + 0.6f
            velZ[i] = (rnd.nextFloat() - 0.5f) * 2.6f
            maxLife[i] = 0.5f + rnd.nextFloat() * 0.3f
            life[i] = maxLife[i]
            cell[i] = block.topCell
        }
    }

    fun update(dt: Float) {
        var i = 0
        while (i < activeCount) {
            life[i] -= dt
            if (life[i] <= 0f) {
                // Swap-remove with the last active particle to keep the array dense.
                val last = activeCount - 1
                posX[i] = posX[last]; posY[i] = posY[last]; posZ[i] = posZ[last]
                velX[i] = velX[last]; velY[i] = velY[last]; velZ[i] = velZ[last]
                life[i] = life[last]; maxLife[i] = maxLife[last]; cell[i] = cell[last]
                activeCount--
                continue
            }
            velY[i] -= 9f * dt
            posX[i] += velX[i] * dt
            posY[i] += velY[i] * dt
            posZ[i] += velZ[i] * dt
            i++
        }
    }

    fun count(): Int = activeCount
    fun x(i: Int) = posX[i]
    fun y(i: Int) = posY[i]
    fun z(i: Int) = posZ[i]
    fun scale(i: Int) = 0.12f * (life[i] / maxLife[i]).coerceIn(0.15f, 1f)
    fun cellOf(i: Int) = cell[i]
}
