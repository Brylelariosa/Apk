package com.voxelsandbox.game.inventory

import com.voxelsandbox.game.world.BlockType

/**
 * Fixed hotbar: each slot is permanently assigned to one placeable block type (no
 * free-form drag/drop backpack in this version — a good follow-up; see the final
 * report). Breaking a block increments its slot's count; placing decrements it.
 */
class Inventory {
    val slots: List<BlockType> = BlockType.HOTBAR_ORDER
    private val counts = IntArray(slots.size)

    var selectedIndex: Int = 0
        private set

    init {
        // A small starting stock of common building blocks so play doesn't stall
        // before the player has broken anything.
        give(BlockType.DIRT, 20)
        give(BlockType.STONE, 20)
        give(BlockType.SAND, 10)
        give(BlockType.WOOD, 10)
    }

    fun select(index: Int) {
        if (index in slots.indices) selectedIndex = index
    }

    fun countAt(index: Int): Int = if (index in counts.indices) counts[index] else 0

    fun selectedBlock(): BlockType = slots.getOrElse(selectedIndex) { BlockType.DIRT }

    fun canPlaceSelected(): Boolean = countAt(selectedIndex) > 0

    fun consumeSelected() {
        if (counts[selectedIndex] > 0) counts[selectedIndex]--
    }

    fun add(block: BlockType, amount: Int = 1) {
        val idx = slots.indexOf(block)
        if (idx >= 0) counts[idx] += amount
    }

    private fun give(block: BlockType, amount: Int) {
        val idx = slots.indexOf(block)
        if (idx >= 0) counts[idx] = amount
    }

    /** For SaveManager: counts in slot order. */
    fun exportCounts(): IntArray = counts.copyOf()

    fun importCounts(saved: IntArray) {
        for (i in counts.indices) {
            counts[i] = if (i < saved.size) saved[i] else 0
        }
    }
}
