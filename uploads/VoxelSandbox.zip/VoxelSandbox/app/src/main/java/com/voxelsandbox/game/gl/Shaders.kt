package com.voxelsandbox.game.gl

/**
 * One shader handles chunk terrain, particles, and the cloud layer — they all share
 * the same vertex format (position + uv + shade) and differ only in geometry and the
 * uAlpha/fog uniforms, so a second program isn't needed.
 */
object Shaders {
    const val VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
}
"""

    const val FRAGMENT = """#version 300 es
precision mediump float;

in vec2 vTexCoord;
in float vShade;
in float vFogDist;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uAlpha;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(uTexture, vTexCoord);
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, texColor.a * uAlpha);
}
"""
}
