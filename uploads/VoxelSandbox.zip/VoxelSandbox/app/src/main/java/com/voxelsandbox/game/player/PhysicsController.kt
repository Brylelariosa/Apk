package com.voxelsandbox.game.player

import com.voxelsandbox.game.util.AABB
import com.voxelsandbox.game.util.Vec3
import com.voxelsandbox.game.world.World
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Axis-separated AABB-vs-voxel-grid collision: X, then Z, then Y are resolved
 * independently against solid blocks. This is simpler and much easier to verify
 * correct by inspection than full swept-AABB continuous collision, and is entirely
 * adequate at the movement speeds this game uses.
 */
class PhysicsController(private val world: World) {
    companion object {
        const val GRAVITY = 24f
        const val TERMINAL_VELOCITY = -40f
        const val JUMP_SPEED = 8.4f
        const val MOVE_SPEED = 4.3f
    }

    /** worldMoveX/worldMoveZ are already-rotated world-space direction components
     *  (see GameEngine, which turns joystick forward/strafe + yaw into these). */
    fun step(player: Player, worldMoveX: Float, worldMoveZ: Float, wantsJump: Boolean, dt: Float) {
        player.velocity.y = max(player.velocity.y - GRAVITY * dt, TERMINAL_VELOCITY)
        if (wantsJump && player.onGround) {
            player.velocity.y = JUMP_SPEED
        }

        var box = boxAt(player.position)

        val dx = resolveHorizontal(box, worldMoveX * MOVE_SPEED * dt, isX = true)
        box = box.offset(dx, 0f, 0f)
        val dz = resolveHorizontal(box, worldMoveZ * MOVE_SPEED * dt, isX = false)
        box = box.offset(0f, 0f, dz)

        val desiredDy = player.velocity.y * dt
        val dy = resolveVertical(box, desiredDy)

        if (desiredDy < 0f && dy > desiredDy) {
            player.onGround = true
            player.velocity.y = 0f
        } else if (desiredDy > 0f && dy < desiredDy) {
            player.velocity.y = 0f
            player.onGround = false
        } else {
            player.onGround = false
        }

        player.position.add(dx, dy, dz)

        // Fell into the void (e.g. an edge case in generation): return to spawn
        // height rather than falling forever.
        if (player.position.y < com.voxelsandbox.game.world.WorldConfig.VOID_Y) {
            player.position.set(player.position.x, 60f, player.position.z)
            player.velocity.set(0f, 0f, 0f)
        }
    }

    private fun boxAt(pos: Vec3): AABB {
        val hw = Player.WIDTH / 2f
        return AABB(pos.x - hw, pos.y, pos.z - hw, pos.x + hw, pos.y + Player.HEIGHT, pos.z + hw)
    }

    private fun resolveHorizontal(box: AABB, delta: Float, isX: Boolean): Float {
        if (delta == 0f) return 0f
        var d = delta
        val moved = if (isX) box.offset(d, 0f, 0f) else box.offset(0f, 0f, d)

        val minX = floor(min(box.minX, moved.minX)).toInt()
        val maxX = floor(max(box.maxX, moved.maxX) - 0.001f).toInt()
        val minY = floor(box.minY).toInt()
        val maxY = floor(box.maxY - 0.001f).toInt()
        val minZ = floor(min(box.minZ, moved.minZ)).toInt()
        val maxZ = floor(max(box.maxZ, moved.maxZ) - 0.001f).toInt()

        for (bx in minX..maxX) for (by in minY..maxY) for (bz in minZ..maxZ) {
            if (!world.isSolid(bx, by, bz)) continue
            val bb = AABB(bx.toFloat(), by.toFloat(), bz.toFloat(), bx + 1f, by + 1f, bz + 1f)
            d = if (isX) {
                when {
                    d > 0f -> min(d, bb.minX - box.maxX)
                    d < 0f -> max(d, bb.maxX - box.minX)
                    else -> d
                }
            } else {
                when {
                    d > 0f -> min(d, bb.minZ - box.maxZ)
                    d < 0f -> max(d, bb.maxZ - box.minZ)
                    else -> d
                }
            }
        }
        return d
    }

    private fun resolveVertical(box: AABB, delta: Float): Float {
        if (delta == 0f) return 0f
        var d = delta
        val moved = box.offset(0f, d, 0f)

        val minX = floor(box.minX).toInt()
        val maxX = floor(box.maxX - 0.001f).toInt()
        val minY = floor(min(box.minY, moved.minY)).toInt()
        val maxY = floor(max(box.maxY, moved.maxY)).toInt()
        val minZ = floor(box.minZ).toInt()
        val maxZ = floor(box.maxZ - 0.001f).toInt()

        for (bx in minX..maxX) for (by in minY..maxY) for (bz in minZ..maxZ) {
            if (!world.isSolid(bx, by, bz)) continue
            val bb = AABB(bx.toFloat(), by.toFloat(), bz.toFloat(), bx + 1f, by + 1f, bz + 1f)
            d = if (d > 0f) min(d, bb.minY - box.maxY) else max(d, bb.maxY - box.minY)
        }
        return d
    }
}
