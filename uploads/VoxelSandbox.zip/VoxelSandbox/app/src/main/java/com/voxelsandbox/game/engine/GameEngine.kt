package com.voxelsandbox.game.engine

import android.content.Context
import com.voxelsandbox.game.engine.fx.ParticleSystem
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.input.InputState
import com.voxelsandbox.game.inventory.Inventory
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.player.PhysicsController
import com.voxelsandbox.game.player.Raycaster
import com.voxelsandbox.game.player.RaycastHit
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.WorldManager
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.util.Locale
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * The GL-agnostic game loop: physics, input interpretation, world-streaming input,
 * and break/place actions. GameRenderer calls [update] once per frame from the GL
 * thread and then reads the exposed state (player, world, particles, ...) to draw.
 */
class GameEngine(context: Context, val settings: GameSettings, savedGame: LoadedSave?) {
    val world = World()
    val seed: Long = savedGame?.seed ?: Random.nextLong()
    private val generator = TerrainGenerator(seed)
    val atlas = TextureAtlas()
    val worldManager = WorldManager(world, generator, atlas, context, savedGame?.chunkOverrides ?: emptyMap())

    val player = Player()
    private val physics = PhysicsController(world)
    val inventory = Inventory()
    val particles = ParticleSystem()
    val input = InputState()

    private val spawnPos: ChunkPos
    private var breakCooldown = 0f
    private var placeCooldown = 0f
    private var bobPhase = 0f

    var bobOffset = 0f
        private set
    var lastHit: RaycastHit? = null
        private set

    init {
        if (savedGame != null) {
            player.position.set(savedGame.playerX, savedGame.playerY, savedGame.playerZ)
            player.yaw = savedGame.yaw
            player.pitch = savedGame.pitch
            inventory.importCounts(savedGame.inventoryCounts)
            player.waitingForSpawn = false // saved position is already known-good ground
        }
        spawnPos = ChunkPos.fromWorld(player.position.x, player.position.z)
        worldManager.requestImmediateChunk(spawnPos)
        worldManager.start()
    }

    fun shutdown() {
        worldManager.shutdown()
    }

    private val lookDelta = FloatArray(2)

    fun update(dt: Float) {
        val clampedDt = dt.coerceAtMost(0.05f) // guards against a huge dt after e.g. resuming from background

        if (player.waitingForSpawn) {
            if (worldManager.isChunkGenerated(spawnPos)) {
                dropPlayerToSurface()
                player.waitingForSpawn = false
            } else {
                return // hold everything until the spawn column actually exists
            }
        }

        input.consumeLookDelta(lookDelta)
        val lookSens = 0.0022f + settings.lookSensitivity * 0.0035f
        player.addLook(lookDelta[0] * lookSens, -lookDelta[1] * lookSens)

        // Slider sits at 1.0x speed in its default middle position rather than at a
        // fraction of walking speed, which would otherwise feel like a bug.
        val moveSens = 0.6f + settings.touchSensitivity.coerceIn(0f, 1f) * 0.8f
        val forward = input.moveForward * moveSens
        val strafe = input.moveStrafe * moveSens
        val yaw = player.yaw
        val worldMoveX = forward * sin(yaw) + strafe * cos(yaw)
        val worldMoveZ = -forward * cos(yaw) + strafe * sin(yaw)

        physics.step(player, worldMoveX, worldMoveZ, input.jumpHeld, clampedDt)
        updateViewBob(worldMoveX, worldMoveZ, clampedDt)

        worldManager.updatePlayerPosition(player.position.x, player.position.z, settings.renderDistance.chunks)
        particles.update(clampedDt)
        handleBreakPlace(clampedDt)
    }

    private fun updateViewBob(worldMoveX: Float, worldMoveZ: Float, dt: Float) {
        if (!settings.viewBobbing) {
            bobOffset = 0f
            return
        }
        val speed = hypot(worldMoveX.toDouble(), worldMoveZ.toDouble()).toFloat()
        if (player.onGround && speed > 0.05f) {
            bobPhase += dt * 9f
            bobOffset = sin(bobPhase) * 0.045f
        } else {
            bobOffset *= 0.85f
        }
    }

    private fun handleBreakPlace(dt: Float) {
        breakCooldown -= dt
        placeCooldown -= dt

        val dirX = cos(player.pitch) * sin(player.yaw)
        val dirY = sin(player.pitch)
        val dirZ = -cos(player.pitch) * cos(player.yaw)
        val hit = Raycaster.cast(world, player.eyeX(), player.eyeY(), player.eyeZ(), dirX, dirY, dirZ, WorldConfig.MAX_INTERACT_REACH)
        lastHit = hit
        if (hit == null) return

        if (input.breakHeld && breakCooldown <= 0f) {
            val target = world.getBlock(hit.blockX, hit.blockY, hit.blockZ)
            if (target.breakable) {
                if (worldManager.setBlockAndRemesh(hit.blockX, hit.blockY, hit.blockZ, BlockType.AIR)) {
                    inventory.add(target, 1)
                    if (settings.particlesEnabled) {
                        particles.spawnBurst(hit.blockX + 0.5f, hit.blockY + 0.5f, hit.blockZ + 0.5f, target)
                    }
                }
            }
            breakCooldown = 0.28f
        }

        if (input.placeHeld && placeCooldown <= 0f) {
            if (hit.faceX != 0 || hit.faceY != 0 || hit.faceZ != 0) {
                val px = hit.blockX + hit.faceX
                val py = hit.blockY + hit.faceY
                val pz = hit.blockZ + hit.faceZ
                val existing = world.getBlock(px, py, pz)
                val selected = inventory.selectedBlock()
                if (existing == BlockType.AIR && inventory.canPlaceSelected() && !intersectsPlayer(px, py, pz)) {
                    if (worldManager.setBlockAndRemesh(px, py, pz, selected)) {
                        inventory.consumeSelected()
                    }
                }
            }
            placeCooldown = 0.22f
        }
    }

    private fun intersectsPlayer(bx: Int, by: Int, bz: Int): Boolean {
        val hw = Player.WIDTH / 2f
        val px = player.position.x; val py = player.position.y; val pz = player.position.z
        return px + hw > bx && px - hw < bx + 1f &&
            py + Player.HEIGHT > by && py < by + 1f &&
            pz + hw > bz && pz - hw < bz + 1f
    }

    private fun dropPlayerToSurface() {
        val bx = floor(player.position.x).toInt()
        val bz = floor(player.position.z).toInt()
        var y = WorldConfig.WORLD_HEIGHT - 1
        while (y > 0 && world.getBlock(bx, y, bz) == BlockType.AIR) y--
        player.position.set(player.position.x, (y + 1).toFloat(), player.position.z)
    }

    fun debugStats(): String {
        val s = worldManager.stats()
        return String.format(
            Locale.US,
            "chunks:%d/%d  genQ:%d  meshQ:%d\npos: %.1f, %.1f, %.1f  particles:%d",
            s.loadedChunks, s.chunkBudget, s.genQueueSize, s.meshQueueSize,
            player.position.x, player.position.y, player.position.z, particles.count()
        )
    }
}
