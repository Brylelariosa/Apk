package com.voxelsandbox.game.input

/**
 * Small set of cross-thread shared fields: written from the main/UI thread (touch
 * handlers) and read once per frame from the GL/game thread. Each field is
 * independently @Volatile, which is sufficient here since nothing does a
 * read-modify-write across threads on the same field except consumeLookDelta, which
 * is only ever called from the single game thread.
 */
class InputState {
    @Volatile var moveForward: Float = 0f // -1..1
    @Volatile var moveStrafe: Float = 0f  // -1..1

    @Volatile private var lookDX: Float = 0f
    @Volatile private var lookDY: Float = 0f

    @Volatile var jumpHeld: Boolean = false
    @Volatile var breakHeld: Boolean = false
    @Volatile var placeHeld: Boolean = false

    fun addLookDelta(dx: Float, dy: Float) {
        lookDX += dx
        lookDY += dy
    }

    /** Called once per frame from the game thread; returns and resets the
     *  accumulated look delta since the last call. */
    fun consumeLookDelta(out: FloatArray) {
        out[0] = lookDX
        out[1] = lookDY
        lookDX = 0f
        lookDY = 0f
    }
}
