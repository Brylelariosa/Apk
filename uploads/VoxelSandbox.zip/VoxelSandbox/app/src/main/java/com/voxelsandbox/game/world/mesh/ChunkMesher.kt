package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Face
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig

class MeshData(val vertexData: FloatArray, val indices: IntArray, val vertexCount: Int) {
    fun isEmpty(): Boolean = vertexCount == 0
    companion object {
        val EMPTY = MeshData(FloatArray(0), IntArray(0), 0)
        /** Floats per vertex in [vertexData]: position(3) + uv(2) + shade(1). Public
         *  (unlike MeshBuilder's private copy of the same number) so GameRenderer can
         *  correctly concatenate multiple subchunks' MeshData into one combined
         *  per-column buffer without duplicating/guessing the stride. */
        const val FLOATS_PER_VERTEX = 6
    }
}

/** Interleaved vertex layout: position(3) + uv(2) + shade(1) = 6 floats/vertex. Kept
 *  private to this file — nothing outside the mesher needs to know the layout details,
 *  only the resulting MeshData. */
private class MeshBuilder(initialVerts: Int = 128) {
    companion object { const val FLOATS_PER_VERTEX = 6 }

    private var floats = FloatArray(initialVerts * FLOATS_PER_VERTEX)
    private var indices = IntArray(initialVerts)
    private var vertCount = 0
    private var indexCount = 0

    private fun ensureFloats(extra: Int) {
        val needed = vertCount * FLOATS_PER_VERTEX + extra
        if (needed > floats.size) floats = floats.copyOf(maxOf(floats.size * 2, needed))
    }

    private fun ensureIndices(extra: Int) {
        val needed = indexCount + extra
        if (needed > indices.size) indices = indices.copyOf(maxOf(indices.size * 2, needed))
    }

    private fun vertex(x: Float, y: Float, z: Float, u: Float, v: Float, shade: Float) {
        ensureFloats(FLOATS_PER_VERTEX)
        var i = vertCount * FLOATS_PER_VERTEX
        floats[i++] = x; floats[i++] = y; floats[i++] = z
        floats[i++] = u; floats[i++] = v; floats[i] = shade
        vertCount++
    }

    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        uv: UVRectLocal,
        shade: Float
    ) {
        ensureIndices(6)
        val base = vertCount
        vertex(x0, y0, z0, uv.u0, uv.v0, shade)
        vertex(x1, y1, z1, uv.u1, uv.v0, shade)
        vertex(x2, y2, z2, uv.u1, uv.v1, shade)
        vertex(x3, y3, z3, uv.u0, uv.v1, shade)
        indices[indexCount++] = base
        indices[indexCount++] = base + 1
        indices[indexCount++] = base + 2
        indices[indexCount++] = base
        indices[indexCount++] = base + 2
        indices[indexCount++] = base + 3
    }

    fun build(): MeshData =
        if (vertCount == 0) MeshData.EMPTY
        else MeshData(floats.copyOf(vertCount * FLOATS_PER_VERTEX), indices.copyOf(indexCount), vertCount)
}

private class UVRectLocal(val u0: Float, val v0: Float, val u1: Float, val v1: Float)

/**
 * Builds one mesh per subchunk using face culling: a face is emitted only when the
 * neighboring cell is non-opaque (an unloaded neighbor chunk reads as non-opaque too
 * — see World — so boundary faces render rather than leaving holes, until the real
 * neighbor loads and both sides remesh).
 *
 * This is the "simpler face-culling mesh" the spec explicitly allows as a stable
 * first version in place of full greedy meshing. Faces are already batched into one
 * mesh per subchunk rather than one draw per block; `emitFace` below is the natural
 * seam where coplanar-quad merging (greedy meshing) could be added later without
 * touching the streaming, threading, or rendering code around it.
 *
 * Backface culling is intentionally left disabled in the renderer (see GameRenderer),
 * so exact winding order per face doesn't matter here.
 */
object ChunkMesher {
    fun buildSubChunkMesh(world: World, chunkX: Int, chunkZ: Int, subY: Int, atlas: TextureAtlas): MeshData {
        val builder = MeshBuilder()
        val baseX = chunkX * WorldConfig.CHUNK_SIZE
        val baseZ = chunkZ * WorldConfig.CHUNK_SIZE
        val baseY = subY * WorldConfig.SUBCHUNK_HEIGHT

        for (ly in 0 until WorldConfig.SUBCHUNK_HEIGHT) {
            val wy = baseY + ly
            for (lz in 0 until WorldConfig.CHUNK_SIZE) {
                val wz = baseZ + lz
                for (lx in 0 until WorldConfig.CHUNK_SIZE) {
                    val wx = baseX + lx
                    val block = world.getBlock(wx, wy, wz)
                    if (block == BlockType.AIR) continue

                    for (face in Face.ALL) {
                        if (world.isOpaque(wx + face.dx, wy + face.dy, wz + face.dz)) continue
                        emitFace(builder, atlas, block, face, wx, wy, wz)
                    }
                }
            }
        }
        return builder.build()
    }

    private fun emitFace(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, face: Face, x: Int, y: Int, z: Int) {
        val fx = x.toFloat(); val fy = y.toFloat(); val fz = z.toFloat()
        val raw = atlas.uvFor(block.cellFor(face))
        val uv = UVRectLocal(raw.u0, raw.v0, raw.u1, raw.v1)
        val shade = shadeFor(face)

        when (face) {
            Face.TOP -> builder.quad(
                fx, fy + 1, fz, fx + 1, fy + 1, fz, fx + 1, fy + 1, fz + 1, fx, fy + 1, fz + 1,
                uv, shade
            )
            Face.BOTTOM -> builder.quad(
                fx, fy, fz + 1, fx + 1, fy, fz + 1, fx + 1, fy, fz, fx, fy, fz,
                uv, shade
            )
            Face.NORTH -> builder.quad(
                fx + 1, fy, fz, fx, fy, fz, fx, fy + 1, fz, fx + 1, fy + 1, fz,
                uv, shade
            )
            Face.SOUTH -> builder.quad(
                fx, fy, fz + 1, fx + 1, fy, fz + 1, fx + 1, fy + 1, fz + 1, fx, fy + 1, fz + 1,
                uv, shade
            )
            Face.WEST -> builder.quad(
                fx, fy, fz, fx, fy, fz + 1, fx, fy + 1, fz + 1, fx, fy + 1, fz,
                uv, shade
            )
            Face.EAST -> builder.quad(
                fx + 1, fy, fz + 1, fx + 1, fy, fz, fx + 1, fy + 1, fz, fx + 1, fy + 1, fz + 1,
                uv, shade
            )
        }
    }

    private fun shadeFor(face: Face): Float = when (face) {
        Face.TOP -> 1.0f
        Face.BOTTOM -> 0.4f
        Face.NORTH, Face.SOUTH -> 0.75f
        Face.EAST, Face.WEST -> 0.65f
    }
}
