package com.voxelsandbox.game.settings

import android.content.Context
import android.content.SharedPreferences

enum class RenderDistancePreset(val label: String, val chunks: Int) {
    VERY_LOW("Very Low", 4),
    LOW("Low", 8),
    MEDIUM("Medium", 12),
    HIGH("High", 20),
    VERY_HIGH("Very High", 32),
    EXTREME("Extreme", 60);

    companion object {
        fun fromOrdinalSafe(i: Int): RenderDistancePreset = values().getOrElse(i) { LOW }
    }
}

enum class GraphicsQuality(val label: String) {
    LOW("Low"), MEDIUM("Medium"), HIGH("High");

    companion object {
        fun fromOrdinalSafe(i: Int): GraphicsQuality = values().getOrElse(i) { MEDIUM }
    }
}

/**
 * Thin SharedPreferences wrapper. Values load once into memory at construction;
 * WorldManager/GameEngine read the in-memory fields every frame (no disk I/O in the
 * hot path). [persist] writes them back and is only called when the player taps
 * Apply in the settings screen.
 */
class GameSettings(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("voxel_settings", Context.MODE_PRIVATE)

    var renderDistance: RenderDistancePreset =
        RenderDistancePreset.fromOrdinalSafe(prefs.getInt(KEY_RENDER_DISTANCE, RenderDistancePreset.LOW.ordinal))
    var graphicsQuality: GraphicsQuality =
        GraphicsQuality.fromOrdinalSafe(prefs.getInt(KEY_GRAPHICS_QUALITY, GraphicsQuality.MEDIUM.ordinal))
    var showFps: Boolean = prefs.getBoolean(KEY_SHOW_FPS, false)
    var touchSensitivity: Float = prefs.getFloat(KEY_TOUCH_SENS, 0.5f)
    var lookSensitivity: Float = prefs.getFloat(KEY_LOOK_SENS, 0.5f)
    var viewBobbing: Boolean = prefs.getBoolean(KEY_BOBBING, true)
    var cloudsEnabled: Boolean = prefs.getBoolean(KEY_CLOUDS, true)
    var particlesEnabled: Boolean = prefs.getBoolean(KEY_PARTICLES, true)

    fun persist() {
        prefs.edit()
            .putInt(KEY_RENDER_DISTANCE, renderDistance.ordinal)
            .putInt(KEY_GRAPHICS_QUALITY, graphicsQuality.ordinal)
            .putBoolean(KEY_SHOW_FPS, showFps)
            .putFloat(KEY_TOUCH_SENS, touchSensitivity)
            .putFloat(KEY_LOOK_SENS, lookSensitivity)
            .putBoolean(KEY_BOBBING, viewBobbing)
            .putBoolean(KEY_CLOUDS, cloudsEnabled)
            .putBoolean(KEY_PARTICLES, particlesEnabled)
            .apply()
    }

    companion object {
        private const val KEY_RENDER_DISTANCE = "render_distance"
        private const val KEY_GRAPHICS_QUALITY = "graphics_quality"
        private const val KEY_SHOW_FPS = "show_fps"
        private const val KEY_TOUCH_SENS = "touch_sensitivity"
        private const val KEY_LOOK_SENS = "look_sensitivity"
        private const val KEY_BOBBING = "view_bobbing"
        private const val KEY_CLOUDS = "clouds"
        private const val KEY_PARTICLES = "particles"
    }
}
