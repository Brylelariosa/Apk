package com.voxelsandbox.game.world.generation

import kotlin.math.floor
import kotlin.random.Random

/**
 * Deterministic seeded 2D gradient noise. This is the classic, widely-known
 * "improved Perlin noise" lattice/permutation scheme — a generic, decades-old
 * algorithm with no relation to any specific game's implementation. Terrain height
 * is entirely derived from this, so the same seed always reproduces the same world.
 */
class NoiseGenerator(seed: Long) {
    private val perm = IntArray(512)

    init {
        val p = IntArray(256) { it }
        val rnd = Random(seed)
        for (i in 255 downTo 1) {
            val j = rnd.nextInt(i + 1)
            val tmp = p[i]; p[i] = p[j]; p[j] = tmp
        }
        for (i in 0 until 512) perm[i] = p[i and 255]
    }

    private fun fade(t: Double) = t * t * t * (t * (t * 6 - 15) + 10)
    private fun lerp(t: Double, a: Double, b: Double) = a + t * (b - a)

    private fun grad(hash: Int, x: Double, y: Double): Double {
        val h = hash and 7
        val u = if (h < 4) x else y
        val v = if (h < 4) y else x
        return (if (h and 1 == 0) u else -u) + (if (h and 2 == 0) v else -v)
    }

    fun noise2D(xIn: Double, yIn: Double): Double {
        val xf = floor(xIn)
        val yf = floor(yIn)
        val xi = xf.toInt() and 255
        val yi = yf.toInt() and 255
        val x = xIn - xf
        val y = yIn - yf
        val u = fade(x)
        val v = fade(y)
        val aa = perm[perm[xi] + yi]
        val ab = perm[perm[xi] + yi + 1]
        val ba = perm[perm[xi + 1] + yi]
        val bb = perm[perm[xi + 1] + yi + 1]
        val x1 = lerp(u, grad(aa, x, y), grad(ba, x - 1, y))
        val x2 = lerp(u, grad(ab, x, y - 1), grad(bb, x - 1, y - 1))
        return lerp(v, x1, x2)
    }

    /** Fractal Brownian motion: sums several octaves of the base noise for more
     *  natural-looking terrain (broad shapes + fine detail). Result is in ~[-1,1]. */
    fun fbm2D(x: Double, y: Double, octaves: Int, persistence: Double, lacunarity: Double): Double {
        var total = 0.0
        var freq = 1.0
        var amp = 1.0
        var maxAmp = 0.0
        repeat(octaves) {
            total += noise2D(x * freq, y * freq) * amp
            maxAmp += amp
            amp *= persistence
            freq *= lacunarity
        }
        return total / maxAmp
    }
}
