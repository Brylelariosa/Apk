package com.voxelsandbox.game.gl

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLUtils
import kotlin.random.Random

data class UVRect(val u0: Float, val v0: Float, val u1: Float, val v1: Float)

/**
 * All block textures are generated procedurally at startup (solid base color per cell
 * plus a seeded speckle pattern) rather than shipped as image assets. This keeps the
 * project asset-free and guarantees nothing is copied from Minecraft or anywhere
 * else. The bitmap itself needs no GL context to build, so it can be constructed
 * once up front and handed to background mesh-worker threads for UV lookups;
 * [uploadToGL] (which does need the context) is called once from the renderer on the
 * GL thread.
 */
class TextureAtlas {
    companion object {
        const val GRID = 4 // 4x4 cells
        const val CELL_PX = 32
        const val SIZE_PX = GRID * CELL_PX

        /** A plain white cell, reused (tinted via the shader's fog/shade/alpha
         *  uniforms) for clouds so no second shader or texture is needed. */
        const val WHITE_CELL = 10
    }

    private val bitmap: Bitmap = buildBitmap()
    private var textureId: Int = 0

    fun uvFor(cell: Int): UVRect {
        if (cell < 0) return UVRect(0f, 0f, 0f, 0f)
        val cx = cell % GRID
        val cy = cell / GRID
        // Inset by half a texel to avoid bilinear-adjacent-cell bleeding; irrelevant
        // with GL_NEAREST but kept cheap and harmless either way.
        val u0 = cx.toFloat() / GRID
        val v0 = cy.toFloat() / GRID
        val u1 = u0 + 1f / GRID
        val v1 = v0 + 1f / GRID
        return UVRect(u0, v0, u1, v1)
    }

    fun uploadToGL() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
    }

    fun bind(unit: Int = 0) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    private fun buildBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE_PX, SIZE_PX, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint()
        val rnd = Random(1337L) // fixed seed: identical atlas across runs/devices

        // cell index -> base color (opaque; see GameRenderer for why leaves/etc. are
        // not alpha-cutout in this version)
        val baseColors = mapOf(
            0 to Color.rgb(97, 172, 82),   // grass top
            1 to Color.rgb(120, 96, 62),   // grass side (dirt-ish with green fleck)
            2 to Color.rgb(107, 84, 53),   // dirt
            3 to Color.rgb(126, 126, 130), // stone
            4 to Color.rgb(214, 197, 145), // sand
            5 to Color.rgb(108, 74, 43),   // wood side (bark)
            6 to Color.rgb(176, 140, 92),  // wood top (rings)
            7 to Color.rgb(69, 133, 60),   // leaves
            8 to Color.rgb(120, 122, 128), // coal ore base
            9 to Color.rgb(63, 118, 201),  // water
            WHITE_CELL to Color.rgb(255, 255, 255) // flat white, used for clouds
        )

        for ((cell, color) in baseColors) {
            val cx = (cell % GRID) * CELL_PX
            val cy = (cell / GRID) * CELL_PX
            paint.color = color
            canvas.drawRect(cx.toFloat(), cy.toFloat(), (cx + CELL_PX).toFloat(), (cy + CELL_PX).toFloat(), paint)
            speckle(canvas, paint, cx, cy, color, cell, rnd)
        }
        return bmp
    }

    private fun speckle(canvas: Canvas, paint: Paint, cx: Int, cy: Int, base: Int, cell: Int, rnd: Random) {
        val dotCount = if (cell == 8) 26 else 16 // coal ore gets denser dark flecks
        val darken = if (cell == 8) 0.25f else 0.8f
        for (i in 0 until dotCount) {
            val px = cx + rnd.nextInt(CELL_PX)
            val py = cy + rnd.nextInt(CELL_PX)
            val shade = shadeColor(base, darken + rnd.nextFloat() * 0.15f)
            paint.color = shade
            canvas.drawRect(px.toFloat(), py.toFloat(), (px + 1.5f), (py + 1.5f), paint)
        }
        // Grass top and leaves get a couple of brighter flecks too, for a bit more life.
        if (cell == 0 || cell == 7) {
            for (i in 0 until 10) {
                val px = cx + rnd.nextInt(CELL_PX)
                val py = cy + rnd.nextInt(CELL_PX)
                paint.color = shadeColor(base, 1.25f)
                canvas.drawRect(px.toFloat(), py.toFloat(), (px + 1.5f), (py + 1.5f), paint)
            }
        }
    }

    private fun shadeColor(color: Int, factor: Float): Int {
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }
}
