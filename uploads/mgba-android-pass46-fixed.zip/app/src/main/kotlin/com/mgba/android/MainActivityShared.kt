package com.mgba.android

import android.graphics.Bitmap
import android.graphics.RectF

// ─────────────────────────────────────────────────────────────────────────
// FIX (pass 46 build failure): every declaration in this file used to be a
// *member* of MainActivity (nested inside its companion object or the class
// body itself) — see MainActivity.kt's own top-of-file FILE MAP comment for
// the split that moved the rest of the class's logic out into per-concern
// "internal fun MainActivity.foo()" extension-function files. That split's
// own comment assumed leaving these companion constants and small data/
// sealed classes nested would be harmless ("no behavior change, purely a
// file-organization move") — true for the actual business-logic functions,
// but not for these: an extension function only gets MainActivity's real
// *instance* members through its implicit receiver, not its companion
// object's constants or its nested types, which only resolve unqualified
// when the referencing code is textually inside the class body itself.
// Every one of pass 46's "Unresolved reference" build failures (TAG,
// every PREF_*/ORIENTATION_* constant, LayoutEntry, Geometry, ButtonDef,
// SlotInfo, SlotKind, MemRegion — plus everything that cascaded from those,
// like the "'when' expression must be exhaustive" errors on SlotKind and
// the ArrayAdapter<SlotInfo> overload-resolution failure) traces back to
// this one thing.
//
// Fix follows the precedent already set by PREFS/dp()/iconChipBackground()
// (see those in SharedUi.kt, and its own top-of-file comment) — same idea
// as PREFS's own inline comment in MainActivity.kt puts it: hoisted to
// plain top-level (package-scope) declarations, exactly like this file's
// name mirrors SharedUi.kt's. Kotlin resolves an unqualified top-level
// name the same way from *every* file in the same package, with no
// extension-receiver ambiguity — so every existing unqualified call site,
// in MainActivity.kt and in every split-out file alike, keeps compiling
// completely unchanged. SaveEntry is the one exception and stays a nested
// `inner class` of MainActivity — it genuinely needs the implicit outer-
// instance access that only real class nesting gives it (dataSubfolder(),
// dataFolderTree(), contentResolver, cacheDir); see MainActivity.kt's own
// FILE MAP comment for why. SlotInfo's `entry` field below is qualified
// as MainActivity.SaveEntry for that same reason.
// ─────────────────────────────────────────────────────────────────────────

// ── Shared constants (formerly MainActivity's companion object) ───────────
internal const val TAG             = "mGBA"
internal const val GAME_FRAC_NORM  = 0.52f

// ── Per-item editor toolbar (refreshEditToolbarPosition) ────────────
// Direct report: the popup "sometimes it get cut off its weird" when
// dragged near an edge. Both values below used to be bare pixel
// literals (4f/12f) inline in refreshEditToolbarPosition() — sub-1dp
// on anything past ~mdpi, i.e. not a real margin at all, which is
// what actually read as "cut off" even though the clamp itself was
// never letting the bar go fully off-screen. Named + dp-scaled here
// for the same reason resizeHandleTouchRadius() moved off a raw-pixel
// radius (see that function's own comment).
internal const val EDIT_TOOLBAR_SCREEN_MARGIN_DP = 8   // gap kept from every screen edge
internal const val EDIT_TOOLBAR_GAP_DP = 12            // gap kept from the selected control / top bar

// FEATURE (this pass — direct report: "make the pop up smaller"):
// the two biggest single contributors to editButtonBar's footprint,
// pulled out the same way EDIT_TOOLBAR_GAP_DP/_SCREEN_MARGIN_DP
// already are above — each is read from two call sites (row1/row2's
// bottomMargin; editSizeSlider's/editOpacitySlider's own row width),
// so one named number keeps both sites in step instead of two
// literals that could quietly drift apart in some future pass.
// Smaller one-off cosmetic values (chip/label padding, text size)
// stay as plain literals at their own call sites, same as
// everywhere else in this file — these two are promoted because
// they're shared, not because every size constant deserves to be.
internal const val EDIT_TOOLBAR_ROW_GAP_DP = 4          // was 6
internal const val EDIT_TOOLBAR_SLIDER_WIDTH_DP = 190   // was 240
// Floor for the same slider width on a screen too narrow for the
// 190dp design width above — see refreshEditToolbarPosition()'s
// own doc comment. Chosen so the fixed-width value-readout box
// (EDIT_TOOLBAR_VALUE_BOX_WIDTH_DP, 48dp, in SharedUi.kt) always
// keeps a real, still-draggable amount of SeekBar track next to
// it rather than being squeezed to nothing.
internal const val EDIT_TOOLBAR_SLIDER_MIN_WIDTH_DP = 90
// Floor for editButtonLabel's own maxWidth — see
// editRow1ChipsWidthPx's field comment and this same use in
// refreshEditToolbarPosition(). Same role as the slider floor
// above: below this, truncating the label further stops being
// worth it, same reasoning as that one's own comment.
internal const val EDIT_TOOLBAR_LABEL_MIN_WIDTH_DP = 40
// FEATURE (direct report: "add a way to move button without swipe
// like arrow up down left right"): how far one tap of the new
// ^/v/</> row moves the selected control, in dp so it's the same
// felt distance on any screen density — see nudgeSelected(). Small
// enough for real fine-tuning (the entire point of an alternative
// to dragging), large enough that a tap still visibly does
// something rather than needing several before any movement is
// even noticeable.
internal const val EDIT_NUDGE_STEP_DP = 4

// Edge margin for clampControlCenterToScreen() — deliberately tiny,
// unlike EDIT_TOOLBAR_SCREEN_MARGIN_DP above: that one keeps UI
// chrome comfortably inset from the screen edge, this one only
// exists to stop a dragged/resized control rendering fully off it.
// On-screen controls are routinely *meant* to sit flush against an
// edge (L/R in the corners, etc.), so this stays small rather than
// fighting that.
internal const val CONTROL_DRAG_EDGE_MARGIN_DP = 2

// ── GBA hardware timing ─────────────────────────────────────────────
// AUDIO FIX (root cause #1): the old loop paced itself with
// Thread.sleep(1_000_000_000.0 / 60.0) — i.e. it assumed an exact
// 60.000 Hz refresh. Real GBA hardware runs at CPU_CLOCK / CYCLES_PER_FRAME
// = 16777216 / 280896 ≈ 59.7275 Hz. Pacing 0.46% too fast meant the game
// thread fed the blip_buf resampler audio slightly faster than a
// 44.1 kHz AudioTrack could drain it. Since the old code wrote with
// WRITE_NON_BLOCKING and never checked the return value, that constant
// small surplus was silently dropped by AudioTrack roughly every 3–4
// real seconds — an audible periodic "stutter" that would read as
// "audio is a little broken" on a real device even though nothing was
// ever fully silent. Below are the exact constants (matching
// GBA_AUDIO_CLOCK in mgba_jni.c) used for the corrected pacing.
internal const val GBA_CPU_CLOCK_HZ    = 16_777_216L   // 2^24, ARM7TDMI clock
internal const val GBA_CYCLES_PER_FRAME = 280_896L     // 228 lines * 1232 cycles
// Only used as a *fallback* pacer for frames that produce no audio
// (e.g. the first frame or two right after a ROM loads, before the
// blip_buf resamplers have accumulated a full sample). Normal frames
// are paced by the AudioTrack itself — see startGameLoop().
internal val FALLBACK_FRAME_NS =
    GBA_CYCLES_PER_FRAME * 1_000_000_000L / GBA_CPU_CLOCK_HZ

// Headroom above the 16x fast-forward speed clamp (see
// showMiscSettings) for sizing ffAccumBuffer below.
internal const val FF_MAX_BATCH_FRAMES = 24

// SharedPreferences
// PREFS itself moved to SharedUi.kt this pass (top-level, shared
// with RomBrowserActivity) — everything below is still just this
// Activity's own keys within that same file.
internal const val PREF_FF_SPEED    = "ff_speed"
internal const val PREF_BTN_SCALE   = "btn_scale"
internal const val PREF_BTN_ALPHA   = "btn_alpha"
internal const val PREF_SCREEN_FRAC = "screen_frac"
internal const val PREF_STRETCH     = "stretch_to_fit"
internal const val PREF_MAX_SKIPS   = "max_frame_skips"
internal const val PREF_LINEAR_FILTER = "linear_filter"
// PREF_BTN_SOUND removed this pass — the standalone button-click
// sound feature it backed is gone entirely (direct report asked
// for it removed), replaced by the three keys below.
internal const val PREF_SOUND_ENABLED = "sound_enabled"
internal const val PREF_SOUND_VOLUME  = "sound_volume"
internal const val PREF_SOUND_FREQ    = "sound_freq"
// PREF_TURBO removed this pass — Turbo A/B moved into the same
// added-extras layout persistence every other opt-in button
// already uses (see extraControlIds/addedExtraButtons above),
// rather than a separate on/off flag of their own.
internal const val PREF_SHOW_FPS    = "show_fps"
// Misc setting — see autoSaveLoadEnabled's own field comment for
// what this actually drives.
internal const val PREF_AUTO_SAVE_LOAD = "auto_save_load"
// Editor alignment grid — see the gridDivisions/showGrid/snapToGrid
// field comments. Deliberately NOT orientation-suffixed (unlike
// PREF_LAYOUT_PREFIX below) — grid preference is a general editing
// preference, not something that should differ between portrait
// and landscape.
internal const val PREF_GRID_SIZE   = "grid_divisions"
internal const val PREF_SHOW_GRID   = "show_grid"
internal const val PREF_SNAP_GRID   = "snap_to_grid"
internal const val PREF_LAYOUT_PREFIX = "layout_"
// ADD/REMOVE CONTROL feature — which button ids are hidden, per
// orientation (same "land"/"port" split as PREF_LAYOUT_PREFIX above).
// See removedButtons / loadCustomLayout() / saveCustomLayout().
internal const val PREF_REMOVED_PREFIX = "removed_"
// Same idea, opposite default — which extraControlIds ids have been
// explicitly added. See addedExtraButtons / isButtonVisible().
internal const val PREF_EXTRAS_PREFIX = "extras_"
// The only two values orientationTag() ever returns — see its own
// definition. Pulled out as a constant purely for
// exportLayoutBackup()/importLayoutBackupIfNeeded() (pass 43) to
// iterate both profiles at once without duplicating this pair of
// literals a third time.
internal val ORIENTATION_TAGS = listOf("land", "port")
internal const val PREF_ORIENTATION   = "screen_orientation"  // Int, one of ORIENTATION_* below
// FEATURE: user-chosen Storage folder for saves/states/screenshots —
// see dataFolderTree()/showStorageSettings()/SaveEntry below. Absent
// (the default) means every save-adjacent file lives exactly where
// it always has: this app's own internal storage. Still a
// persisted SAF tree Uri (unlike the ROM browser's own
// PREF_ROMS_LAST_FOLDER, now in RomBrowserActivity.kt — a plain
// path, and this Activity doesn't need to know it exists at all
// any more) and read/write instead of read-only, since this one
// gets written to.
internal const val PREF_DATA_FOLDER_URI = "data_folder_tree_uri"

// Screen orientation choice, persisted under PREF_ORIENTATION — see
// applyScreenOrientationPref() and the "Screen orientation" radio
// group in showVideoSettings(). ORIENTATION_LANDSCAPE is the default
// (and was previously the only, hardcoded option — see onCreate/
// AndroidManifest.xml) so existing installs behave identically until
// someone actually opens Video settings and changes it.
internal const val ORIENTATION_AUTO              = 0
internal const val ORIENTATION_LANDSCAPE          = 1
internal const val ORIENTATION_REVERSE_LANDSCAPE  = 2
internal const val ORIENTATION_PORTRAIT           = 3
internal const val ORIENTATION_SYSTEM             = 4

// Number of independent save-state slots offered per ROM.
internal const val SAVE_STATE_SLOTS = 4

// Save-state thumbnail width in px; height is derived per-capture from
// the SurfaceView's actual aspect ratio at that moment (see
// captureStateThumbnail) rather than hardcoded, since the surface may
// be letterboxed/fullscreen differently across sessions and forcing a
// fixed WxH here would stretch the image instead of just cropping it.
internal const val STATE_THUMB_WIDTH_PX = 200

// Backstop cap for slotInfoCache below — see that field's own doc
// comment for why this is a "shouldn't realistically matter"
// safeguard rather than a fix for any actually-observed growth.
internal const val SLOT_INFO_CACHE_MAX = 500

// FEATURE (Settings → Debug — direct report: "setting add debug on it
// you can toggle rom memory viewer or link debug each one has toggle
// and if you off all of it on menu all of those is gone but you can
// toggle it back"): both default true — these two tools were always
// unconditionally in the game menu before this pass, so defaulting
// each toggle to "on" keeps that exact same menu for anyone upgrading;
// only turning either off is a change from today's behavior. See
// showDebugSettings() (MainActivitySettingsDialogs.kt) for the toggles
// themselves and showGameMenu() (MainActivityMenus.kt) for where each
// one actually hides its menu entry.
internal const val PREF_DEBUG_MEMORY_VIEWER = "debug_memory_viewer_enabled"
internal const val PREF_DEBUG_LINK_LOG = "debug_link_log_enabled"

// FEATURE — direct report: "in sound settings add a way to add
// background music like you select a folder with song inside and play
// it 1by1 or shuffle it like playlist." See MainActivityMusic.kt's
// top-of-file comment for the full design.
internal const val PREF_MUSIC_FOLDER_URI = "music_folder_uri"
internal const val PREF_MUSIC_ENABLED = "music_enabled"
internal const val PREF_MUSIC_SHUFFLE = "music_shuffle"
internal const val PREF_MUSIC_VOLUME = "music_volume"

// ── Shared data / sealed classes (formerly nested in MainActivity) ────────

// ── Control layout editor ────────────────────────────────────────────────
// Per-button position/size/opacity overrides, keyed by stable button id
// ("dpad","a","b","start","select","l","r","ff", …). Absent from the
// map == "use the default geometric layout computed in buildControlLayout()".
// Positions are stored as FRACTIONS of screen width/height (not raw
// pixels) so a saved layout still makes sense if the app is later run on
// a different screen size. Persisted as JSON in SharedPreferences, keyed
// per orientation (see orientationTag()) so portrait mode doesn't inherit
// an unsuitable landscape layout. FIX (this pass, spotted while adding
// layout presets — see MainActivityLayoutPresets.kt — which needed to
// know exactly how live this actually is): this comment used to say the
// activity was hard-locked to landscape, which stopped being true once
// android:screenOrientation went from "landscape" to "unspecified" plus
// a real Portrait choice in Video settings (see onCreate()'s own comment
// on that change, and applyScreenOrientationPref()) — some later pass
// than whichever pass wrote the claim below it. Both orientation
// profiles are real, storable, and reachable through that setting.
internal data class LayoutEntry(
    var xFrac: Float,
    var yFrac: Float,
    var scale: Float = 1f,
    var alphaOverride: Int = -1,   // -1 == inherit the global idle-alpha setting
    var locked: Boolean = false
)
internal data class Geometry(val cx: Float, val cy: Float, val w: Float, val h: Float)

internal data class ButtonDef(
    val id: String, val rect: RectF, val keyMask: Int, val label: String, val color: Int,
    val isDpad: Boolean = false
)

internal data class MemRegion(val label: String, val base: Int, val size: Int)

/** Row data for showSaveStateSlotDialog()'s ListView — hoisted out of
 *  that function (it used to be a local `data class`) so slotInfoCache
 *  below can hold instances of it between calls. */
internal data class SlotInfo(val kind: SlotKind, val entry: MainActivity.SaveEntry, val exists: Boolean, val modified: Long, val label: String, val thumb: Bitmap?)

/** Which underlying save-state file a slot-list row refers to — one of
 *  the numbered slots (1..SAVE_STATE_SLOTS), or one of the two special
 *  slots that live outside that numbered range. Direct report: "on
 *  save slot make a slot for quick save slot and autosave slot" —
 *  before this, SlotInfo only had a bare `slot: Int`, with no way to
 *  represent anything but a number, so Quick Save and Autosave (see
 *  quickStateFile()/autoStateFile()) were both reachable only through
 *  their own single-purpose buttons and never showed up here at all —
 *  see stateEntryFor()/stateThumbEntryFor() for where each variant
 *  resolves to its own file/thumbnail, and showSaveStateSlotDialog()
 *  for where the row list itself is built. */
internal sealed class SlotKind {
    object QuickSave : SlotKind()
    object Autosave : SlotKind()
    data class Numbered(val slot: Int) : SlotKind()

    /** Row label prefix — "Quick Save", "Autosave", or "Slot N". */
    fun displayName(): String = when (this) {
        QuickSave -> "Quick Save"
        Autosave -> "Autosave"
        is Numbered -> "Slot $slot"
    }

    /** Unique-per-kind suffix for slotInfoCache's key — see that
     *  field's own doc comment. */
    fun cacheKeySuffix(): String = when (this) {
        QuickSave -> "quicksave"
        Autosave -> "autosave"
        is Numbered -> "slot$slot"
    }
}
