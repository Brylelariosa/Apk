package com.mgba.android

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile

// ─────────────────────────────────────────────────────────────────────────
// FEATURE — direct report: "in sound settings add a way to add background
// music like you select a folder with song inside and play it 1by1 or
// shuffle it like playlist." MusicPlaylistPlayer.kt is the actual playback
// engine (self-contained, no MainActivity dependency) — this file is just
// the glue: turning a SAF folder into a list of playable Uris, wiring the
// folder-picker's result (musicFolderPicker, MainActivity.kt — has to be
// a field there, not here, since registerForActivityResult() must run at
// Activity construction time), persisting the 4 new prefs, and hooking
// play/pause to the activity lifecycle. Settings UI lives in
// MainActivitySettingsDialogs.kt's showAudioSettings()/
// showMusicVolumeDialog(), alongside every other settings screen.
//
// Recognized by extension AND by SAF's own reported mime type (falls back
// to extension when a provider reports a generic
// application/octet-stream for everything, which some do) — either
// matching is enough, since real-world SAF providers are inconsistent
// about which one they get right.
// ─────────────────────────────────────────────────────────────────────────

private val MUSIC_EXTENSIONS = setOf("mp3", "ogg", "oga", "wav", "m4a", "flac", "aac", "opus")

internal fun MainActivity.listMusicFiles(folderUri: Uri): List<Uri> {
    return try {
        val tree = DocumentFile.fromTreeUri(this, folderUri) ?: return emptyList()
        tree.listFiles()
            .filter { doc ->
                doc.isFile && (
                    (doc.type?.startsWith("audio/") == true) ||
                    (doc.name?.substringAfterLast('.', "")?.lowercase() in MUSIC_EXTENSIONS)
                )
            }
            .sortedBy { it.name?.lowercase() ?: "" }
            .map { it.uri }
    } catch (e: Exception) {
        Log.e(TAG, "listMusicFiles() failed for $folderUri", e)
        emptyList()
    }
}

/** musicFolderPicker's (MainActivity.kt) actual callback body — kept out
 *  of the field initializer itself so it reads the same "field declares,
 *  extension function does the work" way dataFolderPicker/romPicker's own
 *  callbacks do. */
internal fun MainActivity.onMusicFolderPicked(uri: Uri?) {
    uri ?: return
    try {
        contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
    } catch (e: Exception) {
        Log.e(TAG, "takePersistableUriPermission failed for music folder", e)
        uiToast("Couldn't get permission for that folder")
        return
    }
    musicFolderUri = uri
    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(PREF_MUSIC_FOLDER_URI, uri.toString())
        .apply()
    val tracks = listMusicFiles(uri)
    musicPlayer.setPlaylist(tracks, musicShuffle)
    uiToast(
        if (tracks.isEmpty()) "No songs found in that folder"
        else "Found ${tracks.size} song${if (tracks.size == 1) "" else "s"}" +
            (if (musicEnabled) " — playing" else "")
    )
    if (musicEnabled && tracks.isNotEmpty()) musicPlayer.play()
}

/** Called from onCreate() (a folder may already be configured from a
 *  previous session) and from the "Play background music" toggle turning
 *  on. No-ops quietly if nothing's configured yet — see that toggle's own
 *  subtitle in showAudioSettings(). */
internal fun MainActivity.startMusicIfEnabled() {
    if (!musicEnabled) return
    val uri = musicFolderUri ?: return
    if (musicPlayer.trackCount == 0) {
        musicPlayer.setPlaylist(listMusicFiles(uri), musicShuffle)
    }
    musicPlayer.play()
}

/** onPause()'s own call into this — background music has no business
 *  playing while the app itself isn't in front, same as everything else
 *  onPause() already stops (the game loop, screen recording). Deliberately
 *  pause() rather than release(): resumeMusicForLifecycle() below can
 *  then just call play() again on the SAME already-prepared MediaPlayer
 *  instead of re-decoding the current track's header from scratch on
 *  every single app switch. */
internal fun MainActivity.pauseMusicForLifecycle() {
    musicPlayer.pause()
}

internal fun MainActivity.resumeMusicForLifecycle() {
    if (musicEnabled) musicPlayer.play()
}
