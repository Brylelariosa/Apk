package com.bru.adaptiveautoscroll.engine

import android.view.accessibility.AccessibilityNodeInfo

enum class ContentType(val label: String, val emoji: String) {
    UNKNOWN(      "Analyzing…",     "⏳"),
    MANGA_IMAGE(  "Manga Images",   "📕"),
    WEBTOON_IMAGE("Webtoon Panels", "📱"),
    DENSE_TEXT(   "Dense Text",     "📖"),
    LIGHT_TEXT(   "Light Text",     "📄"),
    DIALOGUE(     "Dialogue",       "💬"),
    BLANK_SPACE(  "Blank Space",    "⬜"),
    MIXED(        "Mixed Content",  "🔀"),
    COMMENT_SECTION("Comments",     "💭"),
    VIDEO(        "Video",          "▶️"),
    AD(           "Advertisement",  "🚫"),
    NAVIGATION(   "Navigation",     "🧭"),
    CHAPTER_END(  "Chapter End",    "🏁")
}

/**
 * Result returned by ContentAnalyzer.
 *
 * @param contentType      What kind of content is on screen.
 * @param suggestedPauseMs > 0 when the analyzer recommends a reading pause (e.g. a manga
 *                         panel has just scrolled in).  Already includes ±25 % random
 *                         variance so pauses never feel mechanical.
 * @param largeImageCount  Number of large image nodes found; exposed for the service to
 *                         decide whether to re-trigger a pause on the next panel.
 */
data class AnalysisResult(
    val contentType:      ContentType,
    val suggestedPauseMs: Long = 0L,
    val largeImageCount:  Int  = 0
)

data class NodeStats(
    var totalNodes:            Int = 0,
    var imageNodes:            Int = 0,
    var textNodes:             Int = 0,
    var totalTextChars:        Int = 0,
    var longTextNodes:         Int = 0,
    var dialogueNodes:         Int = 0,
    var blankNodes:            Int = 0,
    var videoNodes:            Int = 0,
    var largeImageNodes:       Int = 0,
    var totalLargeImageHeight: Int = 0,   // sum of heights of large image nodes (px)
    var adIndicators:          Int = 0,
    var navIndicators:         Int = 0,
    var chapterEndIndicators:  Int = 0
)

class ContentAnalyzer {

    private val adKeywords = setOf(
        "advertisement", "sponsored", "ad", "promoted", "google_ads", "adsbygoogle"
    )
    private val navKeywords = setOf(
        "navbar", "navigation", "nav-bar", "menu", "header", "footer", "toolbar"
    )
    private val chapterKeywords = setOf(
        "chapter end", "end of chapter", "next chapter", "next episode",
        "load next", "continue reading", "you've reached", "chapter complete"
    )

    fun analyze(root: AccessibilityNodeInfo?): AnalysisResult {
        root ?: return AnalysisResult(ContentType.UNKNOWN)
        val stats = NodeStats()
        traverseTree(root, stats, depth = 0, maxDepth = 10)
        val type = classify(stats)
        val pause = estimateReadingPause(type, stats)
        return AnalysisResult(type, pause, stats.largeImageNodes)
    }

    // ── Tree traversal ────────────────────────────────────────────────────────

    private fun traverseTree(
        node: AccessibilityNodeInfo,
        stats: NodeStats,
        depth: Int,
        maxDepth: Int
    ) {
        if (depth > maxDepth) return
        stats.totalNodes++

        val className = node.className?.toString()?.lowercase() ?: ""
        val viewId    = node.viewIdResourceName?.lowercase() ?: ""
        val text      = node.text?.toString() ?: ""
        val desc      = node.contentDescription?.toString()?.lowercase() ?: ""

        // Videos
        if (className.contains("video") || className.contains("mediacontroller") ||
            viewId.contains("video") || viewId.contains("player")) {
            stats.videoNodes++
        }

        // Ads
        if (adKeywords.any { viewId.contains(it) || desc.contains(it) }) stats.adIndicators++

        // Navigation
        if (navKeywords.any { viewId.contains(it) || className.contains(it) }) stats.navIndicators++

        // Chapter end
        val combined = (text + " " + desc).lowercase()
        if (chapterKeywords.any { combined.contains(it) }) stats.chapterEndIndicators++

        // Images
        if (className.contains("imageview") || className.contains("image") ||
            (node.isClickable && desc.contains("image")) ||
            className.contains("photo") || className.contains("picture")) {

            stats.imageNodes++
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)
            val h = bounds.height()
            val w = bounds.width()
            if (h > 300 && w > 200) {
                stats.largeImageNodes++
                stats.totalLargeImageHeight += h
            }
        }

        // Text
        if (text.isNotBlank()) {
            stats.textNodes++
            val len = text.length
            stats.totalTextChars += len
            when {
                len > 200 -> stats.longTextNodes++
                len < 60 && (text.contains("said") || text.contains("asked") ||
                    text.contains("replied") || text.contains("...")) ->
                    stats.dialogueNodes++
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseTree(child, stats, depth + 1, maxDepth)
            child.recycle()
        }
    }

    // ── Classification ────────────────────────────────────────────────────────

    private fun classify(stats: NodeStats): ContentType {
        if (stats.totalNodes == 0)          return ContentType.UNKNOWN
        if (stats.chapterEndIndicators > 0) return ContentType.CHAPTER_END
        if (stats.videoNodes > 0)           return ContentType.VIDEO
        if (stats.adIndicators > 0)         return ContentType.AD
        if (stats.navIndicators > 2)        return ContentType.NAVIGATION

        val totalContentNodes = stats.imageNodes + stats.textNodes
        if (totalContentNodes == 0) {
            return if (stats.totalNodes < 8) ContentType.BLANK_SPACE else ContentType.UNKNOWN
        }

        val imageRatio     = stats.imageNodes.toFloat() / totalContentNodes
        val largeImageRatio = if (stats.imageNodes > 0)
            stats.largeImageNodes.toFloat() / stats.imageNodes else 0f

        // Manga: mostly large images, barely any text
        if (imageRatio > 0.6f && largeImageRatio > 0.5f && stats.totalTextChars < 200)
            return ContentType.MANGA_IMAGE

        // Webtoon: image-dominant, may have some text
        if (imageRatio > 0.5f && stats.largeImageNodes > 2)
            return ContentType.WEBTOON_IMAGE

        // Comment section
        if (stats.dialogueNodes > 5 && stats.totalTextChars > 500)
            return ContentType.COMMENT_SECTION

        // Dialogue heavy
        if (stats.dialogueNodes > stats.longTextNodes * 2 && stats.dialogueNodes > 3)
            return ContentType.DIALOGUE

        // Dense text
        if (stats.longTextNodes > 2 || stats.totalTextChars > 1000)
            return ContentType.DENSE_TEXT

        // Light text
        if (stats.textNodes > 0 && stats.totalTextChars > 100)
            return ContentType.LIGHT_TEXT

        // Blank
        if (stats.totalNodes < 6 && stats.totalTextChars < 50)
            return ContentType.BLANK_SPACE

        return ContentType.MIXED
    }

    // ── Reading-pause estimate ────────────────────────────────────────────────

    /**
     * Returns a suggested pause duration when image content is detected.
     *
     * Formula:
     *   base = 1 500 ms  +  600 ms per large image (capped at 4 panels = 3 900 ms)
     *   result = base × random[0.75 … 1.25]  (so pauses never sound like a metronome)
     *
     * Returns 0 for content types that don't warrant a reading pause.
     */
    private fun estimateReadingPause(type: ContentType, stats: NodeStats): Long {
        if (type !in listOf(ContentType.MANGA_IMAGE, ContentType.WEBTOON_IMAGE)) return 0L
        if (stats.largeImageNodes == 0) return 0L

        val panelCount = stats.largeImageNodes.coerceAtMost(4)
        val baseMs     = 1500L + (600L * panelCount)
        val variance   = 0.75f + (Math.random() * 0.50f).toFloat()   // 0.75 – 1.25
        return (baseMs * variance).toLong().coerceIn(1000L, 6000L)
    }
}
