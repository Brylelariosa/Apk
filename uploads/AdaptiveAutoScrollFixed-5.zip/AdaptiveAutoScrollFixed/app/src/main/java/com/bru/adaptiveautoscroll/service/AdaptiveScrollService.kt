package com.bru.adaptiveautoscroll.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.engine.AdaptiveScrollEngine
import com.bru.adaptiveautoscroll.engine.ContentAnalyzer
import com.bru.adaptiveautoscroll.engine.ContentType

class AdaptiveScrollService : AccessibilityService() {

    companion object {
        const val ACTION_START         = "com.bru.adaptiveautoscroll.START"
        const val ACTION_STOP          = "com.bru.adaptiveautoscroll.STOP"
        const val ACTION_PAUSE         = "com.bru.adaptiveautoscroll.PAUSE"
        const val ACTION_RESUME        = "com.bru.adaptiveautoscroll.RESUME"
        const val ACTION_SET_SPEED     = "com.bru.adaptiveautoscroll.SET_SPEED"
        const val ACTION_SET_PROFILE   = "com.bru.adaptiveautoscroll.SET_PROFILE"
        const val ACTION_STATUS_UPDATE = "com.bru.adaptiveautoscroll.STATUS_UPDATE"
        const val ACTION_SERVICE_CONN  = "com.bru.adaptiveautoscroll.SERVICE_CONNECTED"

        const val EXTRA_SPEED           = "extra_speed"
        const val EXTRA_SPEED_PROGRESS  = "extra_speed_progress"
        const val EXTRA_PROFILE         = "extra_profile"
        const val EXTRA_IS_SCROLLING    = "extra_is_scrolling"
        const val EXTRA_IS_PAUSED       = "extra_is_paused"
        const val EXTRA_CURRENT_SPEED   = "extra_current_speed"
        const val EXTRA_CONTENT_TYPE    = "extra_content_type"
        const val EXTRA_SLIDER_PROGRESS = "extra_slider_progress"

        var instance: AdaptiveScrollService? = null

        fun isRunning(): Boolean = instance != null
    }

    private lateinit var prefs:    PrefsManager
    lateinit var        engine:    AdaptiveScrollEngine
    private lateinit var analyzer: ContentAnalyzer

    private val mainHandler      = Handler(Looper.getMainLooper())
    private val volumeHandler    = Handler(Looper.getMainLooper())
    private val touchHandler     = Handler(Looper.getMainLooper())
    private val autoPauseHandler = Handler(Looper.getMainLooper())

    var isScrolling = false
        private set
    var isPaused    = false
        private set
    private var touchPaused = false
    private var autoPaused  = false

    private var analysisTickCounter    = 0
    private val ANALYSIS_EVERY_N_TICKS = 8

    // Track the last content type for which we triggered an image reading pause,
    // so we only fire once per transition into that type (not every analysis tick).
    private var lastImagePauseType: ContentType? = null

    // Volume key long-press tracking
    private var volUpRunnable:  Runnable? = null
    private var volDownRunnable: Runnable? = null
    private var volUpLongDone   = false
    private var volDownLongDone = false

    private val touchResumeRunnable = Runnable {
        touchPaused = false
        if (isScrolling && !isPaused && !autoPaused) broadcastStatus()
    }

    private val autoPauseResumeRunnable = Runnable {
        autoPaused = false
        if (isScrolling && !isPaused && !touchPaused) broadcastStatus()
    }

    private val scrollRunnable = object : Runnable {
        override fun run() {
            if (!isScrolling) return
            val effectivelyPaused = isPaused || touchPaused || autoPaused
            if (!effectivelyPaused) performScrollTick()
            mainHandler.postDelayed(this, engine.getScrollInterval())
        }
    }

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_START  -> startScrolling()
                ACTION_STOP   -> stopScrolling()
                ACTION_PAUSE  -> pauseScrolling(user = true)
                ACTION_RESUME -> resumeScrolling()
                ACTION_SET_SPEED -> {
                    val progress = intent.getIntExtra(EXTRA_SPEED_PROGRESS, 50)
                    engine.setSpeedFromSlider(progress)
                    broadcastStatus()
                }
                ACTION_SET_PROFILE -> {
                    val id = intent.getStringExtra(EXTRA_PROFILE) ?: return
                    engine.setProfile(id)
                    prefs.activeProfileId = id
                    broadcastStatus()
                }
            }
        }
    }

    /**
     * FIX 3 – Screen-lock stop.
     * Registered with FLAG_RECEIVER_REGISTERED_ONLY-compatible intents in onCreate.
     * ACTION_SCREEN_OFF is a protected broadcast so no manifest entry is needed.
     */
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_OFF && isScrolling) {
                stopScrolling()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs    = PrefsManager(this)
        engine   = AdaptiveScrollEngine(prefs)
        analyzer = ContentAnalyzer()

        val commandFilter = IntentFilter().apply {
            addAction(ACTION_START)
            addAction(ACTION_STOP)
            addAction(ACTION_PAUSE)
            addAction(ACTION_RESUME)
            addAction(ACTION_SET_SPEED)
            addAction(ACTION_SET_PROFILE)
        }
        registerReceiver(commandReceiver, commandFilter)

        // Screen-lock receiver
        val screenFilter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        registerReceiver(screenReceiver, screenFilter)

        sendBroadcast(Intent(ACTION_SERVICE_CONN))
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(screenReceiver)  } catch (_: Exception) {}
        stopScrolling()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (prefs.touchPauseEnabled && isScrolling && !touchPaused &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            touchPaused = true
            touchHandler.removeCallbacks(touchResumeRunnable)
            touchHandler.postDelayed(touchResumeRunnable, prefs.touchResumeDelayMs)
            broadcastStatus()
        }
    }

    override fun onInterrupt() { stopScrolling() }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!prefs.volumeKeysEnabled || !isScrolling) return false
        return when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        if (event.repeatCount == 0) {
                            volUpLongDone = false
                            volUpRunnable = Runnable {
                                volUpLongDone = true
                                resumeScrolling()
                            }.also { volumeHandler.postDelayed(it, 700) }
                        }
                        true
                    }
                    KeyEvent.ACTION_UP -> {
                        volUpRunnable?.let { volumeHandler.removeCallbacks(it) }
                        if (!volUpLongDone) { engine.adjustSpeed(0.5f); broadcastStatus() }
                        true
                    }
                    else -> false
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        if (event.repeatCount == 0) {
                            volDownLongDone = false
                            volDownRunnable = Runnable {
                                volDownLongDone = true
                                pauseScrolling(user = true)
                            }.also { volumeHandler.postDelayed(it, 700) }
                        }
                        true
                    }
                    KeyEvent.ACTION_UP -> {
                        volDownRunnable?.let { volumeHandler.removeCallbacks(it) }
                        if (!volDownLongDone) { engine.adjustSpeed(-0.5f); broadcastStatus() }
                        true
                    }
                    else -> false
                }
            }
            else -> false
        }
    }

    // ── Scroll control ────────────────────────────────────────────────────────

    fun startScrolling() {
        if (isScrolling) return
        isScrolling  = true
        isPaused     = false
        touchPaused  = false
        autoPaused   = false
        lastImagePauseType = null
        engine.reset()
        engine.setProfile(prefs.activeProfileId)
        prefs.totalSessions = prefs.totalSessions + 1

        startService(Intent(this, FloatingOverlayService::class.java))
        mainHandler.post(scrollRunnable)
        broadcastStatus()
    }

    fun stopScrolling() {
        if (!isScrolling) return
        isScrolling        = false
        isPaused           = false
        touchPaused        = false
        autoPaused         = false
        lastImagePauseType = null
        mainHandler.removeCallbacks(scrollRunnable)
        touchHandler.removeCallbacks(touchResumeRunnable)
        autoPauseHandler.removeCallbacks(autoPauseResumeRunnable)
        broadcastStatus()
    }

    fun pauseScrolling(user: Boolean = false) {
        if (!isScrolling || isPaused) return
        isPaused = true
        broadcastStatus()
    }

    fun resumeScrolling() {
        if (!isScrolling || !isPaused) return
        isPaused   = false
        autoPaused = false
        broadcastStatus()
    }

    // ── Scroll tick ───────────────────────────────────────────────────────────

    private fun performScrollTick() {
        analysisTickCounter++
        if (analysisTickCounter >= ANALYSIS_EVERY_N_TICKS) {
            analysisTickCounter = 0
            analyzeAndAdapt()
        }

        val pixels = engine.getScrollPixels()
        if (pixels <= 0) return
        dispatchScrollGesture(pixels)
    }

    private fun analyzeAndAdapt() {
        val root = rootInActiveWindow ?: return
        try {
            val result = analyzer.analyze(root)
            engine.updateContentType(result.contentType)
            prefs.incrementContentType(result.contentType.name)

            // ── FIX 4: Human-like image reading pause ────────────────────────
            // Trigger a randomised reading pause the first time we enter an
            // image-heavy content type (manga panel / webtoon panel).
            // We only fire once per transition so we don't pause on every tick
            // while the reader is still on the same screen.
            val isImageContent = result.contentType == ContentType.MANGA_IMAGE ||
                                 result.contentType == ContentType.WEBTOON_IMAGE
            val isNewImageContent = isImageContent && result.contentType != lastImagePauseType

            if (!autoPaused && isNewImageContent && result.suggestedPauseMs > 0) {
                lastImagePauseType = result.contentType
                autoPaused = true
                autoPauseHandler.removeCallbacks(autoPauseResumeRunnable)
                autoPauseHandler.postDelayed(autoPauseResumeRunnable, result.suggestedPauseMs)
            } else if (!isImageContent) {
                // Reset tracker so next image encounter fires a pause again
                lastImagePauseType = null
            }

            // Regular auto-pause (chapter end, dense text, video)
            if (!autoPaused && engine.shouldAutoPause()) {
                autoPaused = true
                autoPauseHandler.removeCallbacks(autoPauseResumeRunnable)
                autoPauseHandler.postDelayed(autoPauseResumeRunnable, engine.getAutoPauseDuration())
            }

            broadcastStatus()
        } finally {
            root.recycle()
        }
    }

    private fun dispatchScrollGesture(pixels: Int) {
        val dm     = resources.displayMetrics
        val sw     = dm.widthPixels
        val sh     = dm.heightPixels
        val startX = sw / 2f
        val startY = sh * 0.65f
        val endY   = (startY - pixels).coerceAtLeast(sh * 0.05f)

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }
        val stroke  = GestureDescription.StrokeDescription(path, 0L, engine.getGestureDuration())
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    // ── Broadcast ─────────────────────────────────────────────────────────────

    fun broadcastStatus() {
        val effectivePaused = isPaused || touchPaused || autoPaused
        sendBroadcast(Intent(ACTION_STATUS_UPDATE).apply {
            putExtra(EXTRA_IS_SCROLLING,    isScrolling)
            putExtra(EXTRA_IS_PAUSED,       effectivePaused)
            putExtra(EXTRA_CURRENT_SPEED,   engine.currentSpeed)
            putExtra(EXTRA_CONTENT_TYPE,    engine.currentContentType.name)
            putExtra(EXTRA_SLIDER_PROGRESS, engine.getSliderProgress())
        })
    }
}
