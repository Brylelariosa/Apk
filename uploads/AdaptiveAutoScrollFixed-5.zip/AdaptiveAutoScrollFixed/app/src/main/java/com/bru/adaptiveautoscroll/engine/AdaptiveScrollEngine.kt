package com.bru.adaptiveautoscroll.engine

import com.bru.adaptiveautoscroll.data.PrefsManager
import kotlin.math.abs
import kotlin.math.roundToInt

class AdaptiveScrollEngine(private val prefs: PrefsManager) {

    companion object {
        /**
         * How often the scroll loop fires.
         * Raised from 100 → 120 ms so each gesture is longer and feels fluid.
         */
        const val SCROLL_INTERVAL_MS = 120L

        /**
         * Duration of each swipe gesture.
         *
         * KEY FIX FOR WAGGY SCROLL:
         * Old value was 80 ms with a 100 ms interval → 20 ms dead-gap every tick
         * where nothing moved, creating the stop-scroll-stop judder.
         *
         * New value leaves only a 5 ms gap (120 - 115) which is imperceptible.
         */
        const val GESTURE_DURATION_MS = 115L

        /**
         * Pixels moved per speed unit per tick.
         * Adjusted (was 3f) so perceived speed is identical despite the longer interval:
         *   3 px/100 ms  ≈  3.6 px/120 ms  → same px/second.
         */
        const val PIXELS_PER_SPEED_UNIT = 3.6f
    }

    var currentSpeed: Float = prefs.baseSpeed
        private set

    var targetSpeed: Float = prefs.baseSpeed
        private set

    var currentContentType: ContentType = ContentType.UNKNOWN
        private set

    var manualSpeed:    Float   = prefs.baseSpeed
    var useManualSpeed: Boolean = false

    var autoPauseTriggered: Boolean = false
    var autoPauseEndTime:   Long    = 0L

    fun setProfile(profileId: String) {
        val profile = com.bru.adaptiveautoscroll.data.ProfileManager.getById(profileId)
        prefs.saveFromProfile(profile)
        manualSpeed  = profile.baseSpeed
        currentSpeed = profile.baseSpeed
        targetSpeed  = profile.baseSpeed
    }

    fun updateContentType(type: ContentType) {
        if (type == currentContentType) return
        currentContentType = type
        recalculateTargetSpeed()
    }

    fun getScrollPixels(): Int {
        if (!prefs.adaptiveEnabled) {
            val spd = if (useManualSpeed) manualSpeed else prefs.baseSpeed
            return (spd * PIXELS_PER_SPEED_UNIT).roundToInt().coerceAtLeast(1)
        }

        val diff = targetSpeed - currentSpeed
        if (abs(diff) > 0.1f) {
            val step = if (diff > 0) prefs.acceleration else -prefs.deceleration
            currentSpeed = (currentSpeed + step).coerceIn(prefs.minSpeed, prefs.maxSpeed)
        } else {
            currentSpeed = targetSpeed
        }

        return (currentSpeed * PIXELS_PER_SPEED_UNIT).roundToInt().coerceAtLeast(1)
    }

    fun getScrollInterval():  Long = SCROLL_INTERVAL_MS
    fun getGestureDuration(): Long = GESTURE_DURATION_MS

    fun adjustSpeed(delta: Float) {
        manualSpeed    = (manualSpeed + delta).coerceIn(prefs.minSpeed, prefs.maxSpeed)
        useManualSpeed = true
        targetSpeed    = manualSpeed
    }

    fun setSpeedFromSlider(progress: Int) {
        val speed = prefs.minSpeed + (prefs.maxSpeed - prefs.minSpeed) * (progress / 100f)
        manualSpeed    = speed
        useManualSpeed = true
        targetSpeed    = speed
        currentSpeed   = speed
    }

    fun getSliderProgress(): Int {
        val range = prefs.maxSpeed - prefs.minSpeed
        if (range <= 0) return 50
        return ((currentSpeed - prefs.minSpeed) / range * 100).roundToInt().coerceIn(0, 100)
    }

    fun shouldAutoPause(): Boolean {
        if (!prefs.adaptiveEnabled) return false
        return when (currentContentType) {
            ContentType.CHAPTER_END -> prefs.pauseAtChapterEnd
            ContentType.DENSE_TEXT  -> prefs.pauseOnLongText
            ContentType.VIDEO       -> prefs.pauseOnVideos
            else                    -> false
        }
    }

    fun getAutoPauseDuration(): Long = prefs.pauseDurationMs

    private fun recalculateTargetSpeed() {
        val base = if (useManualSpeed) manualSpeed else prefs.baseSpeed

        targetSpeed = when (currentContentType) {
            ContentType.MANGA_IMAGE     -> (base * prefs.imageSpeedupFactor)
            ContentType.WEBTOON_IMAGE   -> (base * (prefs.imageSpeedupFactor * 0.8f))
            ContentType.DENSE_TEXT      -> (base * prefs.textSlowdownFactor)
            ContentType.DIALOGUE        -> (base * (prefs.textSlowdownFactor * 1.2f))
            ContentType.LIGHT_TEXT      -> (base * (prefs.textSlowdownFactor * 1.5f))
            ContentType.BLANK_SPACE     -> (base * prefs.blankSpeedupFactor)
            ContentType.COMMENT_SECTION -> (base * 1.2f)
            ContentType.NAVIGATION      -> (base * 2.0f)
            ContentType.AD              -> (base * 2.5f)
            ContentType.VIDEO           -> 0f
            ContentType.CHAPTER_END     -> 0f
            ContentType.MIXED           -> base
            ContentType.UNKNOWN         -> base
        }.coerceIn(prefs.minSpeed, prefs.maxSpeed)
    }

    fun reset() {
        currentSpeed       = prefs.baseSpeed
        targetSpeed        = prefs.baseSpeed
        currentContentType = ContentType.UNKNOWN
        useManualSpeed     = false
        autoPauseTriggered = false
    }
}
