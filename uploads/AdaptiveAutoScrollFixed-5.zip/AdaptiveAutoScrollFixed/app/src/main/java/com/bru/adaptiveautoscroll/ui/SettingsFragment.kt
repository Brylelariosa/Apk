package com.bru.adaptiveautoscroll.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.databinding.FragmentSettingsBinding
import com.bru.adaptiveautoscroll.databinding.SettingSliderRowBinding
import com.bru.adaptiveautoscroll.databinding.SettingToggleRowBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())
        setupAllRows()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupAllRows() {
        // ── Speed ──────────────────────────────────────────────────────────
        slider(binding.rowBaseSpeed, "Base Speed",
            1f, 15f, prefs.baseSpeed, "%.1f") { prefs.baseSpeed = it }

        slider(binding.rowMinSpeed, "Minimum Speed",
            0.5f, 5f, prefs.minSpeed, "%.1f") { prefs.minSpeed = it }

        slider(binding.rowMaxSpeed, "Maximum Speed",
            5f, 30f, prefs.maxSpeed, "%.1f") { prefs.maxSpeed = it }

        slider(binding.rowAcceleration, "Acceleration Rate",
            0.1f, 2f, prefs.acceleration, "%.2f") { prefs.acceleration = it }

        slider(binding.rowDeceleration, "Deceleration Rate",
            0.1f, 2f, prefs.deceleration, "%.2f") { prefs.deceleration = it }

        // ── Adaptive ───────────────────────────────────────────────────────
        toggle(binding.rowAdaptiveEnabled, "Enable Adaptive Speed",
            prefs.adaptiveEnabled) { prefs.adaptiveEnabled = it }

        slider(binding.rowTextSlowdown, "Text Slowdown Factor",
            0.1f, 1f, prefs.textSlowdownFactor, "%.2f") { prefs.textSlowdownFactor = it }

        slider(binding.rowImageSpeedup, "Image Speed Multiplier",
            1f, 4f, prefs.imageSpeedupFactor, "%.2f") { prefs.imageSpeedupFactor = it }

        slider(binding.rowBlankSpeedup, "Blank Space Multiplier",
            1f, 5f, prefs.blankSpeedupFactor, "%.2f") { prefs.blankSpeedupFactor = it }

        // ── Pause ──────────────────────────────────────────────────────────
        toggle(binding.rowPauseLongText, "Pause on Long Text",
            prefs.pauseOnLongText) { prefs.pauseOnLongText = it }

        toggle(binding.rowPauseChapterEnd, "Pause at Chapter End",
            prefs.pauseAtChapterEnd) { prefs.pauseAtChapterEnd = it }

        toggle(binding.rowPauseVideos, "Pause on Videos",
            prefs.pauseOnVideos) { prefs.pauseOnVideos = it }

        slider(binding.rowPauseDuration, "Auto-Pause Duration",
            500f, 15000f, prefs.pauseDurationMs.toFloat(), "%.0fms") {
            prefs.pauseDurationMs = it.toLong()
        }

        slider(binding.rowLongTextThreshold, "Long Text Threshold (chars)",
            100f, 2000f, prefs.longTextThreshold.toFloat(), "%.0f") {
            prefs.longTextThreshold = it.toInt()
        }

        // ── Interaction ────────────────────────────────────────────────────
        toggle(binding.rowTouchPause, "Pause on Touch",
            prefs.touchPauseEnabled) { prefs.touchPauseEnabled = it }

        slider(binding.rowTouchResumeDelay, "Touch Resume Delay",
            500f, 10000f, prefs.touchResumeDelayMs.toFloat(), "%.0fms") {
            prefs.touchResumeDelayMs = it.toLong()
        }

        toggle(binding.rowVolumeKeys, "Volume Key Controls",
            prefs.volumeKeysEnabled) { prefs.volumeKeysEnabled = it }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun slider(
        b: SettingSliderRowBinding,
        label: String,
        minVal: Float, maxVal: Float,
        current: Float, format: String,
        onChanged: (Float) -> Unit
    ) {
        b.settingLabel.text = label
        val range    = maxVal - minVal
        val progress = ((current - minVal) / range * 100).toInt().coerceIn(0, 100)
        b.settingSeekbar.progress = progress
        b.settingValue.text       = format.format(current)

        b.settingSeekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val value = minVal + range * p / 100f
                b.settingValue.text = format.format(value)
                if (fromUser) onChanged(value)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun toggle(
        b: SettingToggleRowBinding,
        label: String,
        current: Boolean,
        onChanged: (Boolean) -> Unit
    ) {
        b.settingLabel.text     = label
        b.settingSwitch.isChecked = current
        b.settingSwitch.setOnCheckedChangeListener { _, checked -> onChanged(checked) }
    }
}
