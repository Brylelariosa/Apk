package com.bru.adaptiveautoscroll.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.bru.adaptiveautoscroll.R
import com.bru.adaptiveautoscroll.data.PrefsManager
import com.bru.adaptiveautoscroll.engine.ContentType

class FloatingOverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "scroll_overlay_channel"
        private const val NOTIF_ID   = 1001
        const val ACTION_DISMISS     = "com.bru.adaptiveautoscroll.DISMISS_OVERLAY"
    }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView:   View
    private lateinit var layoutParams:  WindowManager.LayoutParams
    private lateinit var prefs:         PrefsManager

    private var overlayAdded = false

    // ── FIX 1: Collapse / expand state ───────────────────────────────────────
    private var isCollapsed = false
    private lateinit var panelMain:    LinearLayout
    private lateinit var viewMiniTab:  LinearLayout

    // Drag tracking
    private var dragStartX  = 0f
    private var dragStartY  = 0f
    private var dragInitialPX = 0
    private var dragInitialPY = 0

    // View refs
    private lateinit var tvContentType: TextView
    private lateinit var tvMiniSpeed:   TextView
    private lateinit var tvStatus:      TextView
    private lateinit var seekbarSpeed:  SeekBar
    private lateinit var btnPlayPause:  ImageButton
    private lateinit var btnStop:       ImageButton
    private lateinit var btnClose:      ImageButton
    private lateinit var btnMinimize:   ImageButton
    private lateinit var btnManga:      Button
    private lateinit var btnWebtoon:    Button
    private lateinit var btnNovel:      Button
    private lateinit var btnArticle:    Button

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                AdaptiveScrollService.ACTION_STATUS_UPDATE -> updateUI(intent)
                AdaptiveScrollService.ACTION_STOP,
                ACTION_DISMISS -> dismissOverlay()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        setupOverlay()
        registerReceivers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISMISS) {
            dismissOverlay()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        if (overlayAdded) {
            try { windowManager.removeView(overlayView) } catch (_: Exception) {}
            overlayAdded = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Setup ─────────────────────────────────────────────────────────────────

    private fun setupOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView   = LayoutInflater.from(this)
            .inflate(R.layout.overlay_controls, null, false)

        val dm = resources.displayMetrics
        val screenW = dm.widthPixels

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // FIX 1: Start collapsed at right edge — out of the reading area
            x = screenW   // will be clamped after addView; collapseOverlay() corrects position
            y = 200
        }

        bindViews()
        setupDrag()
        setupControls()

        windowManager.addView(overlayView, layoutParams)
        overlayAdded = true

        // Start collapsed so the overlay doesn't block content immediately
        collapseOverlay()
    }

    private fun bindViews() {
        panelMain     = overlayView.findViewById(R.id.panel_main)
        viewMiniTab   = overlayView.findViewById(R.id.view_mini_tab)
        tvContentType = overlayView.findViewById(R.id.tv_overlay_content_type)
        tvMiniSpeed   = overlayView.findViewById(R.id.tv_mini_speed)
        tvStatus      = overlayView.findViewById(R.id.tv_overlay_status)
        seekbarSpeed  = overlayView.findViewById(R.id.overlay_seekbar_speed)
        btnPlayPause  = overlayView.findViewById(R.id.overlay_btn_play_pause)
        btnStop       = overlayView.findViewById(R.id.overlay_btn_stop)
        btnClose      = overlayView.findViewById(R.id.btn_close_overlay)
        btnMinimize   = overlayView.findViewById(R.id.btn_minimize_overlay)
        btnManga      = overlayView.findViewById(R.id.overlay_btn_manga)
        btnWebtoon    = overlayView.findViewById(R.id.overlay_btn_webtoon)
        btnNovel      = overlayView.findViewById(R.id.overlay_btn_novel)
        btnArticle    = overlayView.findViewById(R.id.overlay_btn_article)

        seekbarSpeed.progress = 50
    }

    private fun setupDrag() {
        val dragHandle = overlayView.findViewById<View>(R.id.drag_handle)
        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX    = event.rawX
                    dragStartY    = event.rawY
                    dragInitialPX = layoutParams.x
                    dragInitialPY = layoutParams.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = (dragInitialPX + (event.rawX - dragStartX)).toInt()
                    layoutParams.y = (dragInitialPY + (event.rawY - dragStartY)).toInt()
                    try { windowManager.updateViewLayout(overlayView, layoutParams) }
                    catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun setupControls() {
        // Mini tab: tap to expand
        viewMiniTab.setOnClickListener { expandOverlay() }

        // Minimise: collapse to mini tab
        btnMinimize.setOnClickListener { collapseOverlay() }

        btnPlayPause.setOnClickListener {
            val svc = AdaptiveScrollService.instance
            if (svc != null) {
                if (svc.isPaused) sendBroadcast(Intent(AdaptiveScrollService.ACTION_RESUME))
                else              sendBroadcast(Intent(AdaptiveScrollService.ACTION_PAUSE))
            }
        }

        btnStop.setOnClickListener {
            sendBroadcast(Intent(AdaptiveScrollService.ACTION_STOP))
            dismissOverlay()
        }

        btnClose.setOnClickListener { dismissOverlay() }

        seekbarSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                sendBroadcast(Intent(AdaptiveScrollService.ACTION_SET_SPEED).apply {
                    putExtra(AdaptiveScrollService.EXTRA_SPEED_PROGRESS, progress)
                })
                val speed = 1f + (14f * progress / 100f)
                tvMiniSpeed.text = "%.1fx".format(speed)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        btnManga.setOnClickListener   { setProfile("manga") }
        btnWebtoon.setOnClickListener { setProfile("webtoon") }
        btnNovel.setOnClickListener   { setProfile("novel") }
        btnArticle.setOnClickListener { setProfile("article") }
    }

    private fun setProfile(id: String) {
        sendBroadcast(Intent(AdaptiveScrollService.ACTION_SET_PROFILE).apply {
            putExtra(AdaptiveScrollService.EXTRA_PROFILE, id)
        })
    }

    // ── Collapse / Expand ─────────────────────────────────────────────────────

    /**
     * Collapse to a tiny 44 dp pill on the right edge.
     * The user can still see it clearly but it no longer overlaps the content.
     */
    private fun collapseOverlay() {
        isCollapsed = true
        panelMain.visibility  = View.GONE
        viewMiniTab.visibility = View.VISIBLE

        // Snap to the right edge so it's completely out of the reading area
        val dm = resources.displayMetrics
        layoutParams.x = dm.widthPixels - dpToPx(52)
        try { windowManager.updateViewLayout(overlayView, layoutParams) }
        catch (_: Exception) {}
    }

    private fun expandOverlay() {
        isCollapsed = false
        viewMiniTab.visibility = View.GONE
        panelMain.visibility  = View.VISIBLE

        // Move back to a comfortable left-edge position
        val dm = resources.displayMetrics
        layoutParams.x = dm.widthPixels - dpToPx(260)   // right-aligned but fully visible
        try { windowManager.updateViewLayout(overlayView, layoutParams) }
        catch (_: Exception) {}
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density + 0.5f).toInt()

    // ── UI Update ─────────────────────────────────────────────────────────────

    private fun updateUI(intent: Intent) {
        val isScrolling = intent.getBooleanExtra(AdaptiveScrollService.EXTRA_IS_SCROLLING, false)
        val isPaused    = intent.getBooleanExtra(AdaptiveScrollService.EXTRA_IS_PAUSED, false)
        val speed       = intent.getFloatExtra(AdaptiveScrollService.EXTRA_CURRENT_SPEED, 5f)
        val contentName = intent.getStringExtra(AdaptiveScrollService.EXTRA_CONTENT_TYPE)
            ?: ContentType.UNKNOWN.name
        val sliderProg  = intent.getIntExtra(AdaptiveScrollService.EXTRA_SLIDER_PROGRESS, 50)

        val type = try { ContentType.valueOf(contentName) } catch (_: Exception) { ContentType.UNKNOWN }

        tvMiniSpeed.text   = "%.1fx".format(speed)
        tvContentType.text = "${type.emoji} ${type.label}"
        seekbarSpeed.progress = sliderProg

        if (!isScrolling) {
            tvStatus.text = "Stopped"
            tvStatus.setTextColor(0xFFF2B8B5.toInt())
            btnPlayPause.setImageResource(R.drawable.ic_play)
        } else if (isPaused) {
            tvStatus.text = "Paused"
            tvStatus.setTextColor(0xFFFFC107.toInt())
            btnPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            tvStatus.text = "Scrolling"
            tvStatus.setTextColor(0xFF4CAF50.toInt())
            btnPlayPause.setImageResource(R.drawable.ic_pause)
        }
    }

    private fun dismissOverlay() {
        if (overlayAdded) {
            try { windowManager.removeView(overlayView) } catch (_: Exception) {}
            overlayAdded = false
        }
        stopSelf()
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(AdaptiveScrollService.ACTION_STATUS_UPDATE)
            addAction(ACTION_DISMISS)
        }
        registerReceiver(statusReceiver, filter)
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply { setShowBadge(false) }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_scroll_logo)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
}
