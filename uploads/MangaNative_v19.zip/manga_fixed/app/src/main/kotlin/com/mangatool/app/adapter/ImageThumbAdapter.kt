package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ImageMerger
import java.io.File

/**
 * Thumbnail adapter for extract-mode and merge-mode image grids.
 *
 * v19 changes — Glide replaces all manual bitmap loading:
 *
 *   BEFORE: Each bind launched a coroutine on BitmapUtils.decodeDispatcher,
 *   called BitmapFactory.decodeFile() manually, stored the result in
 *   AppState.thumbCache (an LruCache<String,Bitmap>), then posted setImageBitmap()
 *   to Main. Recycled views required manual job.cancel(). GC was responsible
 *   for reclaiming decoded Bitmaps.
 *
 *   AFTER: Glide.with(view).load(File).override(140).format(RGB_565)
 *   .diskCacheStrategy(RESOURCE)... handles the full pipeline:
 *     • Background decode on Glide's executor (not our custom dispatcher)
 *     • RGB_565 to halve per-bitmap memory vs ARGB_8888
 *     • Glide BitmapPool recycles decoded Bitmaps instead of creating/GCing
 *     • Disk cache stores the 140 px result so re-scrolls skip BitmapFactory
 *     • Memory LruCache keyed by (filepath + transform) — automatic eviction
 *     • Lifecycle-aware: loads cancel automatically on Activity destroy
 *     • No manual Job tracking, no CoroutineScope, no AppState.thumbCache calls
 *
 * RecyclerView optimisations (unchanged from v16):
 *   setHasStableIds(true), PAYLOAD_DIMS partial rebind, onViewRecycled cancel.
 */
class ImageThumbAdapter(
    private var items: List<Any>,
    private val isMerge: Boolean,
    private val group: ImageGroup? = null,
    private val groupIdx: Int = 0,
    var onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null,
    private val onSwapChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    companion object {
        /** Payload token for dims-only rebind — does NOT cancel in-flight Glide request. */
        const val PAYLOAD_DIMS = "dims"
    }

    init { setHasStableIds(true) }

    override fun getItemId(position: Int): Long = when (val item = items[position]) {
        is ImageItem -> item.originalIdx.toLong()
        is List<*>   -> (item.firstOrNull() as? ImageItem)?.originalIdx?.toLong()
                            ?: position.toLong()
        else         -> position.toLong()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:      ImageView  = v.findViewById(R.id.thumb_image)
        val overlay:    View       = v.findViewById(R.id.thumb_overlay)
        val dims:       TextView?  = v.findViewById(R.id.thumb_dims)
        val thumbLeft:  ImageView? = v.findViewById(R.id.thumb_left)
        val thumbRight: ImageView? = v.findViewById(R.id.thumb_right)
        val btnSwap:    Button?    = v.findViewById(R.id.btn_swap)
        // No Job fields — Glide manages request lifecycle per ImageView target
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (isMerge) R.layout.item_thumb_merge else R.layout.item_thumb
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val holder = VH(v)

        // Attach click listeners ONCE at creation — bindingAdapterPosition is
        // always fresh at click time, no stale index risk.
        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onItemClick(pos)
        }
        v.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (!isMerge && pos != RecyclerView.NO_ID.toInt())
                onItemLongClick?.invoke(items[pos] as ImageItem)
            true
        }
        holder.btnSwap?.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (group != null && pos != RecyclerView.NO_ID.toInt()) {
                @Suppress("UNCHECKED_CAST")
                val curPair = items[pos] as List<ImageItem>
                if (group.pairSwaps.contains(pos)) group.pairSwaps.remove(pos)
                else group.pairSwaps.add(pos)
                // Glide's cache key includes the File path. Swapping just
                // rebinds with the files in reversed order — no manual cache
                // eviction needed; Glide loads the correct file for each side.
                notifyItemChanged(pos)
                onSwapChanged?.invoke()
            }
        }
        return holder
    }

    override fun getItemCount() = items.size

    /**
     * Payload-aware bind: PAYLOAD_DIMS only updates the dims badge without
     * interrupting the in-flight Glide request on the ImageView.
     */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_DIMS }) {
            val img = items.getOrNull(position) as? ImageItem ?: return
            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.overlay.visibility = View.GONE
        holder.dims?.visibility   = View.GONE

        if (!isMerge) {
            // ── Extract mode ──────────────────────────────────────────────────
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE

            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }

            loadThumb(holder.image, img.filePath)

        } else {
            // ── Merge mode ────────────────────────────────────────────────────
            @Suppress("UNCHECKED_CAST")
            val pair    = items[position] as List<ImageItem>
            val swapped = group?.pairSwaps?.contains(position) == true
            val leftImg  = if (swapped && pair.size > 1) pair[1] else pair[0]
            val rightImg = if (swapped && pair.size > 1) pair[0] else pair.getOrNull(1)

            holder.thumbLeft?.let  { loadThumb(it, leftImg.filePath) }
            if (rightImg != null) {
                holder.thumbRight?.let { loadThumb(it, rightImg.filePath) }
            } else {
                holder.thumbRight?.let { Glide.with(it).clear(it) }
            }
        }
    }

    /**
     * Load a 140 px thumbnail via Glide.
     *
     * Configuration rationale:
     *   override(140)            — tiny target; inSampleSize decode saves IO + CPU
     *   PREFER_RGB_565           — 2 bytes/px vs 4 for ARGB_8888; manga JPEGs have
     *                              no alpha so there is zero visual difference
     *   DiskCacheStrategy.RESOURCE — caches the decoded+transformed 140 px result,
     *                              not the original file. Re-scrolling reads from
     *                              disk cache instead of re-running BitmapFactory
     *   skipMemoryCache(false)   — keep hot entries in Glide's LruCache for instant
     *                              re-bind when the same item scrolls back into view
     *   dontAnimate()            — skip crossfade; saves a frame of compositing
     *                              and eliminates the flicker on rapid scroll
     */
    private fun loadThumb(target: ImageView, filePath: String) {
        Glide.with(target)
            .load(File(filePath))
            .override(140)
            .format(DecodeFormat.PREFER_RGB_565)
            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
            .skipMemoryCache(false)
            .dontAnimate()
            .into(target)
    }

    override fun onViewRecycled(holder: VH) {
        // Explicitly cancel any in-flight request on the ImageView and release
        // the Bitmap reference back into Glide's BitmapPool for reuse.
        // Glide would eventually do this itself, but calling clear() eagerly
        // prevents a stale image briefly flashing on the recycled view.
        Glide.with(holder.itemView).clear(holder.image)
        holder.thumbLeft?.let  { Glide.with(holder.itemView).clear(it) }
        holder.thumbRight?.let { Glide.with(holder.itemView).clear(it) }
        super.onViewRecycled(holder)
    }

    /**
     * Swap the item list and rebind all visible cells.
     * Called by ChapterAdapter.update() after applyFilters() runs.
     */
    fun refreshItems(newItems: List<Any>) {
        items = newItems
        notifyDataSetChanged()
    }

    /** No-op: Glide manages request lifecycle — no explicit cleanup needed. */
    fun destroy() = Unit
}
