package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.adapter.ImageThumbAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.FolderSaver
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import java.io.File
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.recyclerview.widget.SimpleItemAnimator

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var chapterTouchHelper: ItemTouchHelper? = null
    private var processingJob: Job? = null

    // ── Share pre-cache ────────────────────────────────────────────────────────
    private val shareCacheAll   = mutableMapOf<String, List<Uri>>()
    private val shareCacheGroup = mutableMapOf<String, List<Uri>>()
    private var preCacheJob: Job? = null
    // Caps concurrent MHTML extractions. Without this, 50+ files launch 50+
    // simultaneous IO coroutines causing storage saturation and RAM spikes.
    // Coroutines beyond the limit suspend cheaply — no thread is held while waiting.
    private val extractLimiter = Semaphore(3)

    // ── File open pickers ──────────────────────────────────────────────────────
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    private val mergePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val folderName = r.data?.getStringExtra(MergeImagePickerActivity.RESULT_FOLDER_NAME) ?: ""
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris, folderName)
        }
    }

    // ── Built-in file manager launcher ─────────────────────────────────────────
    private val internalFileManagerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(InternalFileManagerActivity.RESULT_URIS)
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris)
        }
    }

    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) { applyFiltersAndRefresh() } }

    // ── Folder pickers — Settings "Choose" button ──────────────────────────────
    private val settingsExtractFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { persistAndRememberFolder(it, isMerge = false); updateSettingsFolderLabels() } }

    private val settingsMergeFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { persistAndRememberFolder(it, isMerge = true); updateSettingsFolderLabels() } }

    // ── (Folder launchers for save-without-folder removed — now redirects to Settings) ──
    // ── Folder helpers ─────────────────────────────────────────────────────────
    private fun persistAndRememberFolder(uri: Uri, isMerge: Boolean) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        val name = runCatching {
            androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)?.name
        }.getOrNull() ?: uri.lastPathSegment ?: "Selected folder"

        if (isMerge) {
            Prefs.mergeFolderUri  = uri.toString()
            Prefs.mergeFolderName = name
        } else {
            Prefs.extractFolderUri  = uri.toString()
            Prefs.extractFolderName = name
        }
    }

    /**
     * Returns the stored URI if it is still accessible (permission not revoked),
     * otherwise clears it from prefs and returns null so the user is asked to pick again.
     */
    private fun getValidFolderUri(isMerge: Boolean): Uri? {
        val stored = if (isMerge) Prefs.mergeFolderUri else Prefs.extractFolderUri
            ?: return null
        val uri = runCatching { Uri.parse(stored) }.getOrNull() ?: return null

        // Check we still have write permission by trying to open the DocumentFile
        val accessible = runCatching {
            val df = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri)
            df != null && df.canWrite()
        }.getOrDefault(false)

        return if (accessible) uri else {
            // Permission was revoked (e.g. app reinstall, ROM reset) — clear and re-ask
            if (isMerge) { Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null }
            else         { Prefs.extractFolderUri = null; Prefs.extractFolderName = null }
            updateSettingsFolderLabels()
            null
        }
    }

    private fun updateSettingsFolderLabels() {
        val eName = Prefs.extractFolderName
        b.tvExtractFolderName.text = eName ?: getString(R.string.folder_not_set)
        b.btnClearExtractFolder.visibility = if (eName != null) View.VISIBLE else View.GONE

        val mName = Prefs.mergeFolderName
        b.tvMergeFolderName.text = mName ?: getString(R.string.folder_not_set)
        b.btnClearMergeFolder.visibility = if (mName != null) View.VISIBLE else View.GONE
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb    = Prefs.minSizeKb
        AppState.excludeGifs  = Prefs.excludeGifs
        AppState.reverseOrder = Prefs.reverseOrder
        ImageSaver.clearShareCache(this)
        AppState.imgCacheDir = java.io.File(cacheDir, "img_cache")

        setupTabs()
        setupControls()
        setupActionBar()
        setupDragToReorder()
        applyMode(AppMode.EXTRACT)
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIncomingShareIntent(intent) }
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Glide.get(this).trimMemory(level) // Glide shrinks bitmap pool + memory cache under pressure
    }
    override fun onDestroy()                 { processingJob?.cancel(); super.onDestroy() }

    // ── Incoming share ─────────────────────────────────────────────────────────
    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) { processFiles(uris); setIntent(Intent(Intent.ACTION_MAIN)) }
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    private fun setupTabs() {
        b.tabExtract.setOnClickListener { applyMode(AppMode.EXTRACT) }
        b.tabMerge.setOnClickListener   { applyMode(AppMode.MERGE) }
    }

    private fun applyMode(mode: AppMode) {
        AppState.currentMode = mode
        val active   = 0xFFFFFFFF.toInt()
        val inactive = 0xFF9090B0.toInt()
        if (mode == AppMode.EXTRACT) {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active); b.tabExtract.setTextColor(active)
            b.tabMerge.setBackgroundResource(android.R.color.transparent); b.tabMerge.setTextColor(inactive)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active); b.tabMerge.setTextColor(active)
            b.tabExtract.setBackgroundResource(android.R.color.transparent); b.tabExtract.setTextColor(inactive)
        }
        // Close settings when switching mode; destroy adapter so it rebuilds
        // with the correct isMerge flag from AppState.currentMode.
        b.settingsPanel.visibility = View.GONE
        chapterAdapter?.destroy(); chapterAdapter = null
        applyFiltersAndRefresh()
    }

    // ── Controls ───────────────────────────────────────────────────────────────
    private fun setupControls() {
        // Settings toggle — one panel, both modes
        b.settingsToggle.setOnClickListener {
            b.settingsPanel.visibility =
                if (b.settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        // Extract folder
        b.btnSetExtractFolder.setOnClickListener { settingsExtractFolderLauncher.launch(null) }
        b.btnClearExtractFolder.setOnClickListener {
            Prefs.extractFolderUri = null; Prefs.extractFolderName = null
            updateSettingsFolderLabels()
        }

        // Merge folder
        b.btnSetMergeFolder.setOnClickListener { settingsMergeFolderLauncher.launch(null) }
        b.btnClearMergeFolder.setOnClickListener {
            Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null
            updateSettingsFolderLabels()
        }

        updateSettingsFolderLabels()

        // Extract filters
        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.invalidateAllFilters(); applyFiltersAndRefresh() }
        })
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.invalidateAllFilters(); applyFiltersAndRefresh() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.invalidateAllFilters(); applyFiltersAndRefresh() }

        b.dropZone.setOnClickListener { showFileManagerChooser() }
        val llm = LinearLayoutManager(this)
        llm.initialPrefetchItemCount = 5
        b.chapterList.layoutManager = llm
        b.chapterList.setItemViewCacheSize(20)   // doubled: keeps more VHs warm off-screen
        // Disable overscroll glow — removes a composition layer that causes jank
        b.chapterList.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        // Disable change animations — default ItemAnimator plays a fade/move on every
        // notifyItemChanged(); with 50+ chapters this causes visible jank on filter-slider drags.
        (b.chapterList.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener     { showFileManagerChooser() }
        b.btnDownload.setOnClickListener    { startSave(asCbz = false) }
        b.btnSaveCbz.setOnClickListener     { startSave(asCbz = true) }
        b.btnShareDirect.setOnClickListener { startShareAll() }
        b.btnViewAll.setOnClickListener     { if (AppState.groups.isNotEmpty()) startActivity(Intent(this, AllPhotosActivity::class.java)) }
        b.btnReset.setOnClickListener {
            processingJob?.cancel()          // stop any in-progress file loading
            preCacheJob?.cancel()
            chapterAdapter?.destroy(); chapterAdapter = null
            b.chapterList.adapter = null
            AppState.resetAll()  // also deletes cached image temp files
            Glide.get(this).clearMemory() // evict Glide's memory cache for now-deleted temp files
            invalidateShareCache()
            ImageSaver.clearShareCache(this)
            refreshChapterList()
        }
    }

    private fun setupDragToReorder() {
        val callback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val f = from.adapterPosition; val t = to.adapterPosition
                if (f < 0 || t < 0) return false
                Collections.swap(AppState.groups, f, t); chapterAdapter?.notifyItemMoved(f, t); return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            override fun isLongPressDragEnabled() = false
        }
        chapterTouchHelper = ItemTouchHelper(callback).also { it.attachToRecyclerView(b.chapterList) }
    }

    private fun updateSizeLabel() { b.sizeLabel.text = getString(R.string.size_kb, AppState.minSizeKb) }

    // ── Refresh UI ─────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        val isMerge   = AppState.currentMode == AppMode.MERGE

        b.dropZone.visibility    = if (hasGroups) View.GONE    else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE
        b.mergeTip.visibility    = if (isMerge && hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            b.btnDownload.text      = if (isMerge) "💾 Save Images" else "📁 Save Folder"
            b.btnSaveCbz.visibility = if (isMerge) View.GONE else View.VISIBLE
            b.btnAddMore.text       = if (isMerge) getString(R.string.btn_add_images) else getString(R.string.btn_add_more)
        }

        if (isMerge && hasGroups) {
            val total = AppState.groups.sumOf { it.displayImages.size }
            b.mergeImageCount.text = getString(R.string.merge_image_count, total, (total + 1) / 2)
        }

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            b.statsText.text = if (isMerge) {
                getString(R.string.stats_merge, AppState.groups.size, totalImgs, (totalImgs + 1) / 2, sizeStr)
            } else if (totalFiltered > 0) {
                getString(R.string.stats_extract_filtered, AppState.groups.size, totalImgs, sizeStr, totalFiltered)
            } else {
                getString(R.string.stats_extract, AppState.groups.size, totalImgs, sizeStr)
            }
        }
    }

    private fun refreshChapterList() {
        // Reuse the existing adapter (and its coroutine scope + warm thumbnail cache)
        // instead of destroying + recreating it on every small action.
        if (chapterAdapter != null) {
            chapterAdapter?.update()
            refreshUI()
            return
        }
        chapterAdapter = ChapterAdapter(
            groups           = AppState.groups,
            onImageClick     = { gIdx, iIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == AppMode.MERGE)
                })
            },
            onGroupRemove    = { idx ->
                val removed = AppState.groups.getOrNull(idx)
                AppState.groups.removeAt(idx)
                removed?.let { group ->
                    chapterAdapter?.destroyGroupAdapters(group.id)
                    if (group.sourceUri.isNotBlank()) AppState.seenUris.remove(group.sourceUri)
                }
                applyFiltersAndRefresh()
            },
            onGroupShare     = { idx -> shareGroup(idx) },
            onGroupRename    = { idx -> renameGroup(idx) },
            onImageLongClick = { img -> img.userDeleted = true; img.forceKeep = false; AppState.invalidateAllFilters(); applyFiltersAndRefresh() },
            onImageRestore   = { img -> img.forceKeep = true; img.userDeleted = false; AppState.invalidateAllFilters(); applyFiltersAndRefresh() },
            onFilteredPreview = { gIdx, filtIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filtIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
                })
            },
            onBatchRestore   = { gIdx ->
                AppState.groups.getOrNull(gIdx)?.allImages?.forEach { if (!it.userDeleted) it.forceKeep = true }
                applyFiltersAndRefresh()
                Toast.makeText(this, getString(R.string.toast_restored_all), Toast.LENGTH_SHORT).show()
            }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        refreshUI()
    }

    // ── Per-chapter share ──────────────────────────────────────────────────────
    private fun shareGroup(groupIdx: Int) {
        val group   = AppState.groups.getOrNull(groupIdx) ?: return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val key     = "${groupIdx}_${group.groupName}_${group.displayImages.size}"

        shareCacheGroup[key]?.let { launchShare(it); return }

        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(this@MainActivity, listOf(group), isMerge) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheGroup[key] = uris
                withContext(Dispatchers.Main) { b.progressArea.visibility = View.GONE; launchShare(uris) }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Per-chapter rename ─────────────────────────────────────────────────────
    private fun renameGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val defaultName = group.groupName
            .removeSuffix(".mhtml").removeSuffix(".mht").trim()

        // Custom styled dialog — transparent window so the layout's rounded
        // card background shows through cleanly.
        val dialog = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        val view = layoutInflater.inflate(R.layout.dialog_rename, null)
        dialog.setContentView(view)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setGravity(Gravity.CENTER)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        val input = view.findViewById<EditText>(R.id.rename_input)
        input.setText(defaultName)
        input.setSelection(0, defaultName.length)

        view.findViewById<Button>(R.id.btn_rename_cancel).setOnClickListener {
            dialog.dismiss()
        }
        view.findViewById<Button>(R.id.btn_rename_confirm).setOnClickListener {
            val newName = sanitizeName(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            refreshChapterList()
            dialog.dismiss()
        }
        // Trigger confirm on keyboard "Done"
        input.setOnEditorActionListener { _, _, _ ->
            val newName = sanitizeName(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            refreshChapterList()
            dialog.dismiss()
            true
        }

        dialog.show()
        input.post {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    // ── File manager ───────────────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        if (AppState.currentMode == AppMode.MERGE) {
            mergePickerLauncher.launch(Intent(this, MergeImagePickerActivity::class.java)); return
        }
        internalFileManagerLauncher.launch(Intent(this, InternalFileManagerActivity::class.java))
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }
            data?.data != null     -> listOf(data.data!!)
            else                   -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ────────────────────────────────────────────────────────

    /**
     * Run applyFilters on Dispatchers.Default (never block the main thread),
     * then call refreshChapterList() back on Main.
     * All filter toggle/slider/delete callers use this instead of calling
     * applyFilters() inline — eliminates all UI jank on filter changes.
     */
    private fun applyFiltersAndRefresh() {
        lifecycleScope.launch(Dispatchers.Default) {
            AppState.applyFilters()
            withContext(Dispatchers.Main) { refreshChapterList() }
        }
    }

    private fun processFiles(uris: List<Uri>, folderName: String = "") {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE

        processingJob = lifecycleScope.launch {
            val looseImages    = mutableListOf<ImageItem>()
            var duplicateCount = 0

            val looseTempDir = java.io.File(cacheDir, "img_cache/loose_${System.currentTimeMillis()}")

            // Only URIs that successfully produced a group are committed to seenUris.
            // Prevents a mid-cancel from poisoning seenUris with phantom entries.
            val successfulUris = java.util.concurrent.ConcurrentLinkedQueue<String>()

            val newUris = uris.filter { uri ->
                val s = uri.toString()
                if (AppState.seenUris.contains(s)) { duplicateCount++; false } else true
            }
            val totalFiles  = newUris.size
            val doneCount   = java.util.concurrent.atomic.AtomicInteger(0)

            // ── Separate MHTML from loose images ─────────────────────────────
            val mhtmlUris = newUris.filter { uri ->
                val n = getFileName(uri).lowercase()
                n.endsWith(".mhtml") || n.endsWith(".mht")
            }
            val looseUris = newUris.filter { uri ->
                getFileName(uri).lowercase().matches(Regex(""".*\.(jpg|jpeg|png|webp|gif)"""))
            }

            withContext(Dispatchers.Main) {
                b.progressStatus.text  = "Extracting $totalFiles files…"
                b.progressBar.progress = 0
            }

            // ── Parse all MHTML files in parallel ────────────────────────────
            // Each file gets its own IO coroutine. On a 4-core device this is
            // ~4× faster than the previous serial loop. Peak RAM stays bounded
            // because MhtmlParser holds only one image (~270 KB) at a time per
            // coroutine — total peak ≈ cores × 270 KB, not file-count × 270 KB.
            //
            // Results arrive out of order, so we collect into a thread-safe list
            // then sort by original URI order before adding to AppState.groups.
            val parsedGroups = java.util.concurrent.ConcurrentHashMap<Int, com.mangatool.app.model.ImageGroup>()

            coroutineScope {
                mhtmlUris.forEachIndexed { i, uri ->
                    launch(Dispatchers.IO) {
                        // Semaphore limits active extractions to 3 at a time.
                        // All 50+ coroutines launch immediately but suspend here
                        // until a slot opens — no thread is blocked while waiting.
                        extractLimiter.withPermit {
                            val uriStr      = uri.toString()
                            val displayName = getFileName(uri)
                            val tempDir     = java.io.File(cacheDir, "img_cache/${System.currentTimeMillis()}_$i")
                            val stream      = runCatching { contentResolver.openInputStream(uri) }.getOrNull()
                                ?: return@withPermit

                            val group = stream.use { s ->
                                MhtmlParser.parse(s, displayName, tempDir) { found ->
                                    val done = doneCount.get()
                                    b.root.post {
                                        b.progressStatus.text  = "Extracting… ${done + 1}/$totalFiles — $displayName ($found images)"
                                        b.progressBar.progress = ((done * 100) / totalFiles.coerceAtLeast(1))
                                            .coerceAtMost(99)
                                    }
                                }
                            } ?: return@withPermit

                            parsedGroups[i] = group.also { it.sourceUri = uriStr }
                            successfulUris.add(uriStr)
                            val done = doneCount.incrementAndGet()
                            b.root.post {
                                b.progressBar.progress = (done * 100) / totalFiles.coerceAtLeast(1)
                            }
                        }
                    }
                }
            }
            // Restore document order before appending to AppState.groups
            mhtmlUris.indices
                .mapNotNull { parsedGroups[it] }
                .forEach { AppState.groups.add(it) }

            // ── Handle loose images (unchanged) ──────────────────────────────
            looseUris.forEach { uri ->
                val uriStr = uri.toString()
                val name   = getFileName(uri).lowercase()
                val data   = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                } ?: return@forEach
                val ext = name.substringAfterLast('.')
                looseTempDir.mkdirs()
                val file = java.io.File(looseTempDir, "${looseImages.size.toString().padStart(6,'0')}.$ext")
                withContext(Dispatchers.IO) { file.writeBytes(data) }
                looseImages.add(ImageItem(looseImages.size, file.absolutePath, ext, data.size))
                successfulUris.add(uriStr)
            }

            AppState.invalidateAllFilters()
            AppState.seenUris.addAll(successfulUris)

            if (looseImages.isNotEmpty()) {
                val n = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE && folderName.isNotBlank() -> folderName
                    AppState.currentMode == AppMode.MERGE -> getString(R.string.merge_group_label, n, looseImages.size)
                    uris.size == 1 -> getFileName(uris[0]).substringBeforeLast('.').ifBlank { "Images $n" }
                    else           -> "Images $n (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            withContext(Dispatchers.Main) {
                b.progressBar.progress = 100
                val totalExtracted = AppState.groups.sumOf { it.allImages.size }
                b.progressStatus.text  = "✓ Done — $totalExtracted images ready"
            }
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            b.progressArea.visibility = View.GONE
            refreshChapterList()
            preCacheShareUris()

            // ── Background thumbnail warm-up via Glide preload ───────────────
            // Glide.preload() schedules background decode + caches the 140 px result
            // in both memory and disk cache. No manual BitmapFactory or cache puts.
            // Must run on Main thread (Glide.with(activity) lifecycle binding).
            withContext(Dispatchers.Main) {
                AppState.groups.forEach { group ->
                    val img = group.allImages.firstOrNull() ?: return@forEach
                    Glide.with(this@MainActivity)
                        .load(File(img.filePath))
                        .override(140)
                        .format(DecodeFormat.PREFER_RGB_565)
                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                        .preload()
                }
            }

            // ── Parallel dims decode ──────────────────────────────────────────
            // All groups decoded concurrently on the bounded decodeDispatcher pool.
            // Each group flushes dimension updates to the UI every 20 images to
            // avoid hammering the Main thread.
            lifecycleScope.launch(Dispatchers.IO) {
                coroutineScope {
                    AppState.groups.forEachIndexed { gIdx, group ->
                        launch(com.mangatool.app.util.BitmapUtils.decodeDispatcher) {
                            val origToDisplay = group.displayImages
                                .mapIndexedNotNull { dIdx, img -> img.originalIdx to dIdx }
                                .toMap()

                            val pending        = mutableListOf<Int>()
                            val displayUpdates = mutableMapOf<Int, Pair<Int, Int>>()

                            group.allImages.forEachIndexed { idx, img ->
                                if (img.width == 0) {
                                    val (w, h) = com.mangatool.app.util.BitmapUtils
                                        .decodeDimensions(img.filePath)
                                    group.allImages[idx] = img.copy(width = w, height = h)
                                    origToDisplay[img.originalIdx]?.let { dIdx ->
                                        displayUpdates[dIdx] = w to h
                                        pending += dIdx
                                    }
                                }
                                if (pending.size >= 20) {
                                    val batch = pending.toList(); pending.clear()
                                    val mut = group.displayImages.toMutableList()
                                    displayUpdates.forEach { (dIdx, wh) ->
                                        if (dIdx < mut.size) mut[dIdx] = mut[dIdx].copy(width = wh.first, height = wh.second)
                                    }
                                    group.displayImages = mut
                                    displayUpdates.clear()
                                    withContext(Dispatchers.Main) {
                                        batch.forEach { chapterAdapter?.notifyImageDimsChanged(gIdx, it) }
                                    }
                                }
                            }
                            if (pending.isNotEmpty()) {
                                val mut = group.displayImages.toMutableList()
                                displayUpdates.forEach { (dIdx, wh) ->
                                    if (dIdx < mut.size) mut[dIdx] = mut[dIdx].copy(width = wh.first, height = wh.second)
                                }
                                group.displayImages = mut
                                val batch = pending.toList()
                                withContext(Dispatchers.Main) {
                                    batch.forEach { chapterAdapter?.notifyImageDimsChanged(gIdx, it) }
                                }
                            }
                        }
                    }
                }
            }

            if (duplicateCount > 0) {
                Snackbar.make(b.root, getString(R.string.toast_duplicate_skipped, duplicateCount), Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"

    // ── Share pre-cache ────────────────────────────────────────────────────────
    private fun preCacheShareUris() {
        preCacheJob?.cancel()
        if (AppState.groups.isEmpty()) return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val allKey  = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        preCacheJob = lifecycleScope.launch(Dispatchers.IO) {
            if (!shareCacheAll.containsKey(allKey)) {
                runCatching { ImageSaver.buildShareUris(this@MainActivity, AppState.groups, isMerge) {} }
                    .onSuccess { shareCacheAll[allKey] = it }
            }
            AppState.groups.forEachIndexed { idx, group ->
                val key = "${idx}_${group.groupName}_${group.displayImages.size}"
                if (!shareCacheGroup.containsKey(key)) {
                    runCatching { ImageSaver.buildShareUris(this@MainActivity, listOf(group), isMerge) {} }
                        .onSuccess { shareCacheGroup[key] = it }
                }
            }
        }
    }

    private fun invalidateShareCache() {
        preCacheJob?.cancel()
        shareCacheAll.clear()
        shareCacheGroup.clear()
    }

    // ── Save ───────────────────────────────────────────────────────────────────
    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        when {
            asCbz -> checkWritePermission { showCbzNameDialog() }
            AppState.currentMode == AppMode.MERGE -> {
                val savedUri = getValidFolderUri(isMerge = true)
                if (savedUri != null) showMergeNameDialog(savedUri)
                else                  openSettingsToSetFolder(isMerge = true)
            }
            else -> {
                val savedUri = getValidFolderUri(isMerge = false)
                if (savedUri != null) performSaveExtract(savedUri)
                else                  openSettingsToSetFolder(isMerge = false)
            }
        }
    }

    /** No folder set yet — open Settings panel and highlight the right Choose button */
    private fun openSettingsToSetFolder(isMerge: Boolean) {
        // 1. Open the settings panel
        b.settingsPanel.visibility = View.VISIBLE

        // 2. Identify the row and button to highlight
        val row    = if (isMerge) b.rowMergeFolder    else b.rowExtractFolder
        val btn    = if (isMerge) b.btnSetMergeFolder else b.btnSetExtractFolder
        val label  = if (isMerge) "Merge"             else "Extract"

        // 3. Scroll the row into view (it may be offscreen)
        row.post { row.requestRectangleOnScreen(android.graphics.Rect(0, 0, row.width, row.height), true) }

        // 4. Pulse the row with an accent highlight 3× so the user sees it
        val accentColor  = androidx.core.content.ContextCompat.getColor(this, R.color.primary)
        val transparent  = android.graphics.Color.TRANSPARENT
        val pulse = android.animation.ObjectAnimator.ofArgb(row, "backgroundColor", transparent, accentColor, transparent)
        pulse.duration      = 500
        pulse.repeatCount   = 2
        pulse.repeatMode    = android.animation.ValueAnimator.REVERSE
        pulse.startDelay    = 200
        pulse.start()

        // 5. Show a Snackbar anchored above the action bar
        com.google.android.material.snackbar.Snackbar
            .make(b.root, getString(R.string.set_save_folder_first, label), com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
            .setAction("Choose") { btn.performClick() }
            .setAnchorView(b.actionBar)
            .show()
    }

    /** Merge — folder already known: just ask for the photo name */
    private fun showMergeNameDialog(treeUri: Uri) {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Merged"
        val input = EditText(this).apply {
            setText(default); setSelection(0, default.length)
            hint = "e.g. Chapter 1"; setPadding(48, 24, 48, 8)
        }
        val totalPairs = AppState.groups.sumOf {
            com.mangatool.app.util.ImageMerger.pairImages(it.displayImages).size
        }
        val hint = if (totalPairs == 1) "Saves as: Name.png"
                   else "Saves as: Name_1.png, Name_2.png…"
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.name_your_photos))
            .setMessage("Folder: ${Prefs.mergeFolderName}\n$hint")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = sanitizeName(input.text.toString(), default)
                performSaveMerge(treeUri, name)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showCbzNameDialog() {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"
        val input = EditText(this).apply {
            setText(default); setSelection(0, default.length)
            hint = "CBZ filename"; setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this).setTitle("Save as CBZ").setView(input)
            .setPositiveButton(getString(R.string.btn_save)) { _, _ ->
                val raw = sanitizeName(input.text.toString(), default)
                performSaveCbz(if (raw.endsWith(".cbz", true)) raw else "$raw.cbz")
            }
            .setNegativeButton(getString(R.string.btn_cancel), null).show()
    }

    private fun sanitizeName(input: String, fallback: String) =
        input.trim().replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { fallback }

    // ── Save workers ───────────────────────────────────────────────────────────
    private fun performSaveExtract(treeUri: Uri) {
        b.btnDownload.isEnabled = false; b.btnSaveCbz.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveExtractToTree(this@MainActivity, treeUri, AppState.groups) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    val subtitle = if (AppState.groups.size == 1)
                        "${result.count} images → ${result.folderName}/${AppState.groups[0].groupName}"
                    else
                        "${result.count} images → ${result.folderName}"
                    showSavedSheet(getString(R.string.saved_exclamation), subtitle, emptyList(), saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveMerge(treeUri: Uri, photoName: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveMergeToTree(this@MainActivity, treeUri, AppState.groups, photoName) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    showSavedSheet(
                        title     = "Saved ${result.count} photos",
                        subtitle  = "$photoName.png in ${result.folderName}",
                        shareUris = emptyList(),
                        saveFirst = true
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveCbz(filename: String) {
        b.btnDownload.isEnabled = false; b.btnSaveCbz.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                val uri = CbzCreator.create(this@MainActivity, AppState.groups, filename, false) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
                ImageSaver.SaveResult(listOf(uri), filename)
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    showSavedSheet("Saved: $filename", "Downloads/$filename", result.uris, saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share all ──────────────────────────────────────────────────────────────
    private fun startShareAll() {
        if (AppState.groups.isEmpty()) return
        val allKey = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        shareCacheAll[allKey]?.let { launchShare(it); return }

        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(this@MainActivity, AppState.groups, AppState.currentMode == AppMode.MERGE) { p ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheAll[allKey] = uris
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    launchShare(uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Saved bottom sheet ─────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>, saveFirst: Boolean) {
        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSavedBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        // Open in reader — only for a single CBZ
        sheet.btnOpenReader.visibility = if (saveFirst && shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareUris[0], "application/x-cbz")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(this, getString(R.string.no_cbz_reader), Toast.LENGTH_SHORT).show() }
        }

        // Share button — only when there are URIs (folder saves have none)
        sheet.btnShare.visibility = if (shareUris.isNotEmpty()) View.VISIBLE else View.GONE
        sheet.btnShare.setOnClickListener { dialog.dismiss(); launchShare(shareUris) }

        sheet.btnDone.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // ── Launch share intent ────────────────────────────────────────────────────
    private fun launchShare(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        // clipData is required on Android 10+ so every URI gets read permission,
        // not just the first one in EXTRA_STREAM
        val clip = ClipData.newRawUri("", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share images via…"))
    }

    private fun checkWritePermission(onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else onGranted()
    }
}
