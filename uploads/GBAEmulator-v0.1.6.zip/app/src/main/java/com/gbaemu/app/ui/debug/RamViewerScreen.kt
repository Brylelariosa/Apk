package com.gbaemu.app.ui.debug

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.gbaemu.app.core.EmulatorCore
import kotlinx.coroutines.delay

/** A lighter-weight alternative to the full debugger — just the memory hex dump. */
@Composable
fun RamViewerScreen(core: EmulatorCore, onClose: () -> Unit) {
    var baseAddr by remember { mutableStateOf(0x02000000) } // EWRAM by default — usually the most interesting region to poke at
    var addrText by remember { mutableStateOf(hex(0x02000000)) }
    var bytes by remember { mutableStateOf(ByteArray(0)) }

    LaunchedEffect(baseAddr) {
        while (true) {
            bytes = core.debugReadMemory(baseAddr, 512)
            delay(200)
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xEE0B0B14))) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Button(onClick = onClose) { Text("Close") }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("RAM", color = Color.White)
            MemoryAddressBar(
                addressText = addrText,
                onAddressTextChange = { addrText = it },
                onGo = { addr -> baseAddr = addr },
            )
            MemoryHexView(baseAddr, bytes, modifier = Modifier.fillMaxWidth().weight(1f))
        }
    }
}
