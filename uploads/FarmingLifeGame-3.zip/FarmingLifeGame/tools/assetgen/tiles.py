"""Terrain tiles: grass (4 seasons), dirt, path, sand, water, cliffs, floors, tilled soil, fringes, shore foam."""
import math, random
from PIL import Image
from .common import *

GRASS = {
    'spring': dict(base='#7cc455', d1='#6bb04a', d2='#4f9a3e', l1='#92d466', l2='#aee27e', fl=['#ffffff', '#ffc8dc', '#fff08a']),
    'summer': dict(base='#62b548', d1='#55a03e', d2='#3f8a33', l1='#7ac95a', l2='#92da6c', fl=['#fff08a', '#ffffff']),
    'autumn': dict(base='#b5ae4a', d1='#9e973f', d2='#827a33', l1='#cac45e', l2='#dad676', fl=[]),
    'winter': dict(base='#e4eff6', d1='#d2e2ee', d2='#b8d0e2', l1='#f4f9fd', l2='#ffffff', fl=[]),
}


def wrapped(cv, x, y, c):
    cv.px(x % cv.w, y % cv.h, c)


def grass_tile(season, v):
    g = GRASS[season]
    rng = random.Random('grass%s%d' % (season, v))
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, hx(g['base']))
    for _ in range(16):
        x, y = rng.randint(0, 15), rng.randint(0, 15)
        for dx, dy in rng.choice([[(0, 0), (1, 0)], [(0, 0), (1, 0), (0, 1)], [(0, 0)]]):
            wrapped(cv, x + dx, y + dy, hx(g['d1']))
    for _ in range(11):
        x, y = rng.randint(0, 15), rng.randint(0, 15)
        for dx, dy in rng.choice([[(0, 0), (1, 0)], [(0, 0)], [(0, 0), (0, 1)]]):
            wrapped(cv, x + dx, y + dy, hx(g['l1']))
    for _ in range(7):  # blades
        x, y = rng.randint(0, 15), rng.randint(1, 15)
        wrapped(cv, x, y, hx(g['d2']))
        wrapped(cv, x, y - 1, hx(g['l2']))
    if season == 'spring' and v in (1, 3):
        for _ in range(2 + v):
            x, y = rng.randint(1, 14), rng.randint(1, 14)
            c = hx(rng.choice(g['fl']))
            cv.px(x, y, c); cv.px(x + 1, y, c) if v == 3 else None
            cv.px(x, y + 1, hx('#f0b030') if v == 3 else hx(g['d2']))
    if season == 'summer' and v == 2:
        for _ in range(3):
            x, y = rng.randint(1, 13), rng.randint(1, 13)
            cv.px(x, y, hx('#fff08a')); cv.px(x + 1, y + 1, hx('#f0c030'))
    if season == 'autumn':
        for _ in range(3 + v):
            x, y = rng.randint(0, 13), rng.randint(0, 14)
            c = hx(rng.choice(['#d8782a', '#b8501e', '#e0a030', '#9a5a22']))
            cv.px(x, y, c); cv.px(x + 1, y, c)
            if rng.random() < 0.4: cv.px(x + 1, y + 1, shade(c, 0.8))
    if season == 'winter':
        for _ in range(7):
            x, y = rng.randint(0, 14), rng.randint(0, 15)
            cv.px(x, y, hx('#c4dcee')); cv.px(x + 1, y, hx('#c4dcee'))
        for _ in range(2):
            x, y = rng.randint(1, 14), rng.randint(1, 14)
            cv.px(x, y, (255, 255, 255, 255)); cv.px(x + 1, y, hx('#b8d8ee'))
        if v == 1:
            cv.px(4, 9, hx('#7a9a6a')); cv.px(5, 8, hx('#8aaa78')); cv.px(10, 3, hx('#7a9a6a'))
    return cv


def noise_tile(base, cols, n, v, tag, size=1):
    rng = random.Random('%s%d' % (tag, v))
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, hx(base))
    for c, cnt in cols:
        for _ in range(cnt):
            x, y = rng.randint(0, 15), rng.randint(0, 15)
            wrapped(cv, x, y, hx(c))
            if rng.random() < 0.5: wrapped(cv, x + 1, y, hx(c))
    return cv, rng


def dirt_tile(season, v):
    base = {'spring': '#a8794d', 'summer': '#a67a4a', 'autumn': '#9a6e44', 'winter': '#a89080'}[season]
    cv, rng = noise_tile(base, [(shade(hx(base), 0.88)[:3], 18), (shade(hx(base), 1.12)[:3], 14)], 0, v, 'dirt' + season)
    # convert tuple colours (noise_tile expects hex) - redo with explicit tuples
    return cv


def dirt_tile2(season, v):
    base = hx({'spring': '#a8794d', 'summer': '#a67a4a', 'autumn': '#9a6e44', 'winter': '#a8928a'}[season])
    rng = random.Random('dirt%s%d' % (season, v))
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, base)
    for _ in range(20):
        x, y = rng.randint(0, 15), rng.randint(0, 15)
        wrapped(cv, x, y, shade(base, 0.86)); wrapped(cv, x + 1, y, shade(base, 0.86))
    for _ in range(14):
        wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), shade(base, 1.14))
    for _ in range(3):
        x, y = rng.randint(1, 13), rng.randint(1, 13)
        cv.px(x, y, shade(base, 1.22)); cv.px(x + 1, y, shade(base, 1.22)); cv.px(x, y + 1, shade(base, 0.7)); cv.px(x + 1, y + 1, shade(base, 0.7))
    if season == 'winter':
        for _ in range(9):
            wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#e8f0f6'))
    return cv


def path_tile(season, v):
    base = hx('#b9ad98'); mortar = hx('#8d816d'); hi = hx('#d6ccb8'); lo = hx('#a0937e')
    rng = random.Random('path%d' % v)
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, mortar)
    rows = [(0, 5), (5, 5), (10, 6)] if v == 0 else [(0, 6), (6, 5), (11, 5)]
    for ri, (y0, h) in enumerate(rows):
        x = -rng.randint(0, 6) if ri % 2 == 0 else -rng.randint(2, 8)
        while x < 16:
            w = rng.randint(6, 9)
            x0, x1 = max(0, x + 1), min(15, x + w - 1)
            if x1 >= x0:
                cv.rect(x0, y0 + 1, x1, y0 + h - 2, base)
                cv.hline(x0, x1, y0 + 1, hi)
                cv.hline(x0, x1, y0 + h - 2, lo)
                if rng.random() < 0.5: cv.px(x0 + 1, y0 + 2, hi)
            x += w
    if season == 'winter':
        for _ in range(10):
            wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#eef4f8'))
    if season == 'autumn':
        for _ in range(2):
            wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#d8782a'))
    return cv


def sand_tile(season, v):
    base = hx('#ecd9a4'); rng = random.Random('sand%d' % v)
    cv = Cv(16, 16); cv.rect(0, 0, 15, 15, base)
    for _ in range(3):
        y = rng.randint(0, 15); x = rng.randint(0, 15)
        for i in range(rng.randint(4, 8)):
            wrapped(cv, x + i, y + (1 if i % 5 == 4 else 0), hx('#dcc78c'))
    for _ in range(14): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#f7ebc2'))
    for _ in range(9): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#cdb57a'))
    if season == 'winter':
        for _ in range(6): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#f4f8fb'))
    return cv


def water_tile(deep, v, f):
    base = hx('#2c74b4' if deep else '#4aa5db')
    hi = hx('#4a92d0' if deep else '#8fd6f6'); lo = hx('#1f5c9a' if deep else '#3a8acb')
    rng = random.Random('water%d%d' % (deep, v))
    cv = Cv(16, 16); cv.rect(0, 0, 15, 15, base)
    strokes = [(rng.randint(0, 15), rng.randint(0, 15), rng.randint(3, 6)) for _ in range(5 if not deep else 3)]
    for i, (x, y, l) in enumerate(strokes):
        ox = (x + f * 4 + (i * 3)) % 16
        for k in range(l):
            wrapped(cv, ox + k, y, hi)
        for k in range(l - 1):
            wrapped(cv, ox + k + 2, y + 2, lo)
    for _ in range(6): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), lo)
    return cv


def shore(edge, f):
    cv = Cv(16, 16)
    rng = random.Random('shore%s' % edge)
    prof = [rng.choice([1, 1, 2, 2, 3]) for _ in range(16)]
    for x in range(16):
        d = prof[x] + (1 if (x + f * 3) % 8 < 3 else 0)
        for y in range(min(5, d + 1)):
            a = [230, 170, 110, 60, 30][y]
            c = (232, 248, 255, a) if y < d else (170, 225, 245, 45)
            if edge == 'n': cv.px(x, y, c)
            elif edge == 's': cv.px(x, 15 - y, c)
            elif edge == 'w': cv.px(y, x, c)
            else: cv.px(15 - y, x, c)
    return cv


def fringe(season, edge, kind='grass'):
    g = GRASS[season]
    rng = random.Random('fr%s%s' % (season, edge))
    cv = Cv(16, 16)
    n_cols = ['#5a9c40' if season != 'winter' else '#b8d0e2']
    def put(x, y, d, depth):
        tip = d == depth - 1
        c = hx(g['d2']) if tip else (hx(g['l1']) if rng.random() < 0.3 else hx(g['base']))
        if tip and rng.random() < 0.4: c = hx(g['d1'])
        return c
    if len(edge) == 1:
        prof = []
        cur = 2
        for x in range(16):
            cur = clampi(cur + rng.choice([-1, 0, 0, 1]), 1, 3)
            prof.append(cur)
        for x in range(16):
            for d in range(prof[x]):
                c = put(x, d, d, prof[x])
                if edge == 'n': cv.px(x, d, c)
                elif edge == 's': cv.px(x, 15 - d, c)
                elif edge == 'w': cv.px(d, x, c)
                else: cv.px(15 - d, x, c)
    else:
        r = 4
        for y in range(r):
            for x in range(r):
                if math.hypot(x + 0.5, y + 0.5) <= r - 0.3 and rng.random() < 0.92:
                    c = hx(g['d2']) if math.hypot(x + .5, y + .5) > r - 1.4 else hx(g['base'])
                    px = x if 'w' in edge else 15 - x
                    py = y if 'n' in edge else 15 - y
                    cv.px(px, py, c)
    return cv


def clampi(v, a, b):
    return max(a, min(b, v))


def stone_top(v):
    rng = random.Random('stone%d' % v)
    cv = Cv(16, 16); cv.rect(0, 0, 15, 15, hx('#8e919c'))
    for _ in range(14): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#a2a6b1')); 
    for _ in range(14): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#7b7e8a'))
    for _ in range(2):
        x, y = rng.randint(2, 12), rng.randint(2, 12)
        for i in range(4): cv.px(x + i, y + (i // 2), hx('#666977'))
    return cv


def cliff_face(v, cave=False):
    rng = random.Random('face%d%d' % (v, cave))
    top, mid, low, lip = (('#4a4560', '#3d3850', '#2e2a3c', '#6a6484') if cave else ('#8e919c', '#7b7e8a', '#656876', '#b4b8c4'))
    cv = Cv(16, 16)
    for y in range(16):
        c = hx(mid) if y < 11 else hx(low)
        cv.hline(0, 15, y, c)
    for x in range(16):
        if rng.random() < 0.55:
            l = rng.randint(4, 12); y0 = rng.randint(1, 4)
            cv.vline(x, y0, y0 + l, hx(top) if rng.random() < 0.5 else hx(low))
    cv.hline(0, 15, 0, hx(lip)); cv.hline(0, 15, 1, hx(top))
    for _ in range(3):
        x, y = rng.randint(1, 13), rng.randint(4, 12)
        cv.px(x, y, hx(lip)); cv.px(x + 1, y, hx(top))
    if not cave and v == 1:
        for _ in range(4): wrapped(cv, rng.randint(0, 15), rng.randint(1, 4), hx('#6a9a4a'))
    cv.hline(0, 15, 15, shade(hx(low), 0.7))
    return cv


def cave_floor(v):
    rng = random.Random('cave%d' % v)
    cv = Cv(16, 16); cv.rect(0, 0, 15, 15, hx('#51495f'))
    for _ in range(16): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#5f5770'))
    for _ in range(14): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#433d52'))
    for _ in range(2):
        x, y = rng.randint(1, 13), rng.randint(1, 13)
        cv.px(x, y, hx('#726a88')); cv.px(x + 1, y, hx('#6a6280')); cv.px(x, y + 1, hx('#3a3548'))
    return cv


def cave_wall_top(v):
    rng = random.Random('cwall%d' % v)
    cv = Cv(16, 16); cv.rect(0, 0, 15, 15, hx('#2c2839'))
    for _ in range(14): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#383348'))
    for _ in range(8): wrapped(cv, rng.randint(0, 15), rng.randint(0, 15), hx('#211e2c'))
    return cv


def wood_floor(v):
    rng = random.Random('wood%d' % v)
    cv = Cv(16, 16)
    cols = ['#c9975c', '#c18f55', '#d0a06a', '#b98850']
    for i in range(4):
        base = hx(cols[(i + v) % 4])
        cv.rect(0, i * 4, 15, i * 4 + 2, base)
        cv.hline(0, 15, i * 4 + 3, hx('#8a5f34'))
        cv.hline(0, 15, i * 4, light(base, 0.18))
        sx = rng.randint(2, 12)
        cv.vline(sx, i * 4, i * 4 + 3, hx('#8a5f34'))
        for _ in range(3): wrapped(cv, rng.randint(0, 15), i * 4 + 1, shade(base, 0.9))
    return cv


def stone_floor(v):
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, hx('#8b8a96'))
    for (x0, y0) in [(0, 0), (8, 0), (0, 8), (8, 8)]:
        base = hx('#b8b6c2') if (x0 + y0 + v * 8) % 16 == 0 else hx('#adabb8')
        cv.rect(x0, y0, x0 + 6, y0 + 6, base)
        cv.hline(x0, x0 + 6, y0, light(base, .3)); cv.vline(x0, y0, y0 + 6, light(base, .2))
        cv.hline(x0, x0 + 6, y0 + 6, shade(base, .85))
    return cv


def wall_tile(lower, v):
    cv = Cv(16, 16)
    if not lower:
        cv.rect(0, 0, 15, 15, hx('#f0e2c2'))
        for x in range(0, 16, 4): cv.vline(x, 2, 15, hx('#e6d4b0'))
        cv.rect(0, 0, 15, 2, hx('#c9a46a')); cv.hline(0, 15, 3, hx('#a07a44'))
    else:
        cv.rect(0, 0, 15, 15, hx('#f0e2c2'))
        for x in range(0, 16, 4): cv.vline(x, 0, 3, hx('#e6d4b0'))
        cv.rect(0, 4, 15, 15, hx('#b98a52'))
        cv.hline(0, 15, 4, hx('#d8aa6e')); cv.hline(0, 15, 5, hx('#a07440'))
        for x in (0, 8): cv.vline(x, 6, 13, hx('#8a5f34'))
        cv.rect(0, 14, 15, 15, hx('#7a5230'))
    return cv


def bridge_tile(v):
    cv = Cv(16, 16)
    for i in range(4):
        base = hx(['#b8864e', '#c28f56', '#b08048', '#bc8a52'][(i + v) % 4])
        cv.rect(0, i * 4, 15, i * 4 + 2, base); cv.hline(0, 15, i * 4 + 3, hx('#6a4526'))
        cv.px(1, i * 4 + 1, hx('#5a3a20')); cv.px(14, i * 4 + 1, hx('#5a3a20'))
    return cv


def soil_tile(mask, wet):
    base = hx('#4a3424' if wet else '#6e4c30')
    furrow = hx('#382519' if wet else '#59391f')
    hi = hx('#5c4a4a' if wet else '#86603c')
    cv = Cv(16, 16)
    cv.rect(0, 0, 15, 15, base)
    for y in (3, 7, 11, 15):
        cv.hline(0, 15, y, furrow)
    for y in (1, 5, 9, 13):
        for x in range(0, 16, 4): cv.px((x + y) % 16, y, hi)
    if wet:
        for y in (2, 6, 10, 14):
            for x in range(1, 16, 5): cv.px((x + y) % 16, y, hx('#6a7a98'))
    rim, rimhi = hx('#3a2616' if wet else '#4a2f1a'), hx('#7a5a3c' if wet else '#946a44')
    # mask bits: N=1 E=2 S=4 W=8 -> neighbour is soil
    if not mask & 1: cv.hline(0, 15, 0, rim); cv.hline(1, 14, 1, rimhi)
    if not mask & 4: cv.hline(0, 15, 15, rim); cv.hline(1, 14, 14, shade(base, 0.8))
    if not mask & 8: cv.vline(0, 0, 15, rim); cv.vline(1, 1, 14, rimhi)
    if not mask & 2: cv.vline(15, 0, 15, rim); cv.vline(14, 1, 14, shade(base, 0.8))
    return cv


def draw_tiles(W):
    for s in SEASONS:
        for v in range(4):
            W.add('t_grass_%s_%d' % (s, v), grass_tile(s, v), 0, 0)
        for v in range(2):
            W.add('t_dirt_%s_%d' % (s, v), dirt_tile2(s, v), 0, 0)
            W.add('t_path_%s_%d' % (s, v), path_tile(s, v), 0, 0)
            W.add('t_sand_%s_%d' % (s, v), sand_tile(s, v), 0, 0)
        for e in ['n', 'e', 's', 'w', 'ne', 'se', 'sw', 'nw']:
            W.add('fr_grass_%s_%s' % (s, e), fringe(s, e), 0, 0)
    for deep, nm in [(0, 'water'), (1, 'deep')]:
        for v in range(2):
            for f in range(4):
                W.add('t_%s_%d_%d' % (nm, f, v), water_tile(deep, v, f), 0, 0)
    for e in ['n', 'e', 's', 'w']:
        for f in range(4):
            W.add('shore_%s_%d' % (e, f), shore(e, f), 0, 0)
    for v in range(2):
        W.add('t_cliff_%d' % v, stone_top(v), 0, 0)
        W.add('t_cliffface_%d' % v, cliff_face(v), 0, 0)
        W.add('t_cavewallface_%d' % v, cliff_face(v, True), 0, 0)
        W.add('t_wood_%d' % v, wood_floor(v), 0, 0)
        W.add('t_stone_%d' % v, stone_floor(v), 0, 0)
        W.add('t_bridge_%d' % v, bridge_tile(v), 0, 0)
        W.add('t_wall_%d' % v, wall_tile(bool(v), v), 0, 0)
        W.add('t_cavewall_%d' % v, cave_wall_top(v), 0, 0)
    for v in range(4):
        W.add('t_cave_%d' % v, cave_floor(v), 0, 0)
    for m in range(16):
        W.add('soil_%d' % m, soil_tile(m, False), 0, 0)
        W.add('soilw_%d' % m, soil_tile(m, True), 0, 0)
    sh = Cv(16, 8)
    for r, a in [(1.0, 40), (0.78, 70), (0.5, 90)]:
        rx, ry = 7.5 * r, 3.5 * r
        sh.ell(int(8 - rx), int(4 - ry), int(7 + rx), int(3 + ry), (20, 10, 40, a))
    W.add('fx_shadow', sh, 8, 4)
