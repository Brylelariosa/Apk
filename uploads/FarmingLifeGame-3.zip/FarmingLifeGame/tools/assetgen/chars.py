"""Villagers, portraits and farm animals (the player lives in farmer.py). All procedurally drawn pixel art."""
import math, random
from .common import *
from . import farmer

SHOE = hx('#4a3426')
STEEL, STEEL_D = hx('#c8ccd8'), hx('#8a8e9a')
HANDLE = hx('#9a6c3e')

def C(a, k, default=None):
    v = a.get(k, default)
    return hx(v) if isinstance(v, str) and v.startswith('#') else v


def outfit(a, season):
    o = dict(a)
    o['sleeve'] = 'short' if season == 'summer' else 'long'
    o['coat'] = season == 'winter'
    o['vest'] = season == 'autumn'
    o['scarf'] = hx('#c8402a') if season == 'winter' else None
    o['beanie'] = season == 'winter' and a.get('acc') not in ('straw_hat', 'bucket_hat')
    return o


def pose(anim, n, d):
    """Villager poses: idle, walk (4), swing (3, the blacksmith's hammer), talk (2).  The player is drawn by farmer.py."""
    P = dict(b=0, lL=0, lR=0, aL=0, aR=0, sw=0, tool=None, mouth=0, sa=0)
    if anim == 'walk':
        P['b'] = [0, -1, 0, -1][n]
        P['lR'] = 1 if n == 0 else 0
        P['lL'] = 1 if n == 2 else 0
        P['aL'] = [-1, 0, 1, 0][n]; P['aR'] = [1, 0, -1, 0][n]
        P['sw'] = [2, 0, -2, 0][n]; P['sa'] = -P['sw']
    elif anim == 'swing':
        P['tool'] = n
        P['b'] = [-1, 0, 1][n]
    elif anim == 'talk':
        P['mouth'] = n
    return P


def hair_front(cv, a, O, b, back):
    h = C(a, 'hair'); hs = shade(h, .72); hl = light(h, .22)
    style = a['style']; skin = C(a, 'skin')
    if back:
        cv.ell(2, 1 + b, 13, 11 + b, h); cv.rect(4, 8 + b, 11, 11 + b, hs)
        cv.hline(5, 9, 3 + b, hl)
    else:
        cv.ell(2, 1 + b, 13, 8 + b, h)
        cv.ell(3, 4 + b, 12, 11 + b, skin)
        for x in range(3, 13):
            if x in (7, 8) or (x in (5, 10) and style == 'messy'): continue
            cv.px(x, 4 + b, h)
        for x in (3, 4, 5, 6, 9, 10, 11, 12):
            cv.px(x, 5 + b, h)
        cv.px(4, 6 + b, h); cv.px(11, 6 + b, h)
        cv.hline(5, 8, 2 + b, hl)
    if style == 'long':
        cv.rect(2, 6 + b, 3, 16 + b, h); cv.rect(12, 6 + b, 13, 16 + b, h)
        if back: cv.rect(2, 11 + b, 13, 17 + b, h); cv.rect(4, 14 + b, 11, 17 + b, hs)
    elif style == 'bun':
        cv.ell(6, -1 + max(b, 0), 9, 2 + max(b, 0), h); cv.px(6, 0 + max(b, 0), hl)
        if back: cv.ell(5, 9 + b, 10, 13 + b, hs)
    elif style == 'braid':
        cv.rect(12, 9 + b, 13, 18 + b, h)
        for y in range(10 + b, 19 + b, 3): cv.hline(12, 13, y, hs)
        cv.px(12, 19 + b, hx('#c8402a')) if False else None
        if back: cv.rect(6, 11 + b, 9, 19 + b, h); [cv.hline(6, 9, y, hs) for y in range(12 + b, 20 + b, 3)]
    elif style == 'messy':
        for x, y in [(4, 1), (6, 0), (8, 1), (10, 0), (12, 1), (3, 3), (13, 3)]: cv.px(x, y + b, h)
    elif style == 'ponytail':
        if back: cv.rect(7, 10 + b, 8, 17 + b, h); cv.rect(7, 17 + b, 8, 18 + b, hs); cv.px(7, 10 + b, hx('#c8402a')); cv.px(8, 10 + b, hx('#c8402a'))
        else: cv.px(13, 5 + b, hx('#c8402a')); cv.px(13, 6 + b, h); cv.px(14, 6 + b, h)
    if a.get('acc') == 'glasses_shawl' and not back:
        cv.hline(4, 6, 7 + b, hx('#5a4a3a')); cv.hline(9, 11, 7 + b, hx('#5a4a3a')); cv.px(7, 7 + b, hx('#5a4a3a')); cv.px(8, 7 + b, hx('#5a4a3a'))


def face_front(cv, a, b, P):
    skin = C(a, 'skin'); eye = C(a, 'eyes')
    cv.px(5, 7 + b, eye); cv.px(5, 8 + b, eye); cv.px(10, 7 + b, eye); cv.px(10, 8 + b, eye)
    cv.px(5, 7 + b, shade(eye, 1.0)); cv.px(4, 9 + b, mix(skin, (255, 120, 120, 255), .35)); cv.px(11, 9 + b, mix(skin, (255, 120, 120, 255), .35))
    mc = shade(skin, .6)
    if P['mouth']: cv.rect(7, 10 + b, 8, 11 + b, hx('#a03a3a'))
    else: cv.px(7, 10 + b, mc); cv.px(8, 10 + b, mc)
    if a.get('acc') == 'smith': cv.rect(5, 9 + b, 10, 11 + b, shade(C(a, 'hair'), .9)); cv.rect(7, 10 + b, 8, 10 + b, shade(skin, .7)) if not P['mouth'] else None


def hats(cv, a, O, b, side=False, back=False):
    acc = a.get('acc'); c = C(a, 'acc_c')
    if acc == 'straw_hat':
        cv.ell(0, 2 + b, 15, 5 + b, c); cv.ell(4, -1 + b, 11, 5 + b, light(c, .15)); cv.hline(4, 11, 3 + b, hx('#c8402a'))
    elif acc == 'bucket_hat':
        cv.rect(1, 3 + b, 14, 5 + b, c); cv.ell(3, -1 + b, 12, 4 + b, light(c, .1)); cv.hline(3, 12, 3 + b, hx('#4a7ab0'))
    elif O.get('beanie'):
        bc = hx('#c8402a') if not O.get('scarf') else hx('#d8503a')
        cv.ell(2, 0 + b, 13, 6 + b, bc); cv.rect(2, 4 + b, 13, 5 + b, shade(bc, .8)); cv.px(8, -1 + b, hx('#fff4e0')) if b > 0 else cv.px(8, 0 + b, hx('#fff4e0'))


def draw_fb(cv, a, O, P, back):
    b = P['b']; skin = C(a, 'skin'); bottom = C(a, 'bottom'); top = C(O, 'top')
    if O['coat']: top = mix(top, hx('#4a5a78'), .55)
    sleeve = top
    # legs
    for x0, lift in ((5, P['lL']), (9, P['lR'])):
        bot = 23 - lift
        cv.rect(x0, 19, x0 + 1, bot - 2, bottom); cv.rect(x0, bot - 1, x0 + 1, bot, SHOE)
    cv.rect(4, 18, 11, 19, bottom)
    # torso
    cv.rect(4, 12 + b, 11, 18 + b // 2, top)
    cv.rect(4, 12 + b, 11, 12 + b, light(top, .2))
    if O['vest'] and not back: cv.rect(4, 13 + b, 5, 18 + b, shade(top, .7)); cv.rect(10, 13 + b, 11, 18 + b, shade(top, .7))
    if O['coat']:
        cv.rect(3, 13 + b, 12, 18 + b, top); cv.vline(7, 13 + b, 18 + b, shade(top, .7)); cv.px(6, 15 + b, hx('#e8d8b0')); cv.px(6, 17 + b, hx('#e8d8b0'))
    acc = a.get('acc'); ac = C(a, 'acc_c')
    if acc in ('apron', 'smith') and not back:
        cv.rect(5, 14 + b, 10, 19 + b, ac if acc == 'apron' else hx('#7a5230')); cv.hline(5, 10, 14 + b, light(ac, .3)); cv.rect(6, 17 + b, 9, 18 + b, shade(ac, .8))
    if acc == 'cloak':
        cv.rect(3, 12 + b, 12, 20 + b, ac); cv.rect(5, 12 + b, 10, 12 + b, light(ac, .3)); cv.hline(3, 12, 20 + b, shade(ac, .75))
        if not back: cv.vline(7, 14 + b, 20 + b, shade(ac, .7))
    if acc == 'glasses_shawl':
        cv.poly([(2, 12 + b), (13, 12 + b), (11, 19 + b), (4, 19 + b)], ac); cv.hline(3, 12, 12 + b, light(ac, .3)); cv.vline(7, 13 + b, 18 + b, shade(ac, .75))
    # head first when arms are lowered, arms last when raised
    def head():
        cv.ell(3, 2 + b, 12, 11 + b, skin) if back else None
        hair_front(cv, a, O, b, back)
        if not back: face_front(cv, a, b, P)
        cv.px(2, 7 + b, skin); cv.px(13, 7 + b, skin) if not back else None
        neck = shade(skin, .85); cv.rect(7, 11 + b, 8, 12 + b, neck)
        hats(cv, a, O, b, back=back)
    def arm(x0, dy):
        cap = 2 if O['sleeve'] == 'short' else 4
        y0 = 13 + b + dy
        cv.rect(x0, y0, x0 + 1, y0 + cap, sleeve); cv.rect(x0, y0 + cap + 1, x0 + 1, y0 + 4, skin)
    if isinstance(P['tool'], int):
        head()
        n = P['tool']
        if n == 0: arm(2, -1); cv.rect(12, 4 + b, 13, 13 + b, sleeve); cv.rect(12, 2 + b, 13, 4 + b, skin)
        elif n == 1: arm(2, 0); cv.rect(12, 9 + b, 13, 14 + b, sleeve); cv.rect(11, 14 + b, 12, 16 + b, skin)
        else: arm(2, 1); cv.rect(11, 13 + b, 12, 18 + b, sleeve); cv.rect(11, 18 + b, 12, 20 + b, skin)
        tool_front(cv, n, b)
    else:
        head(); arm(2, P['aL']); arm(12, P['aR'])


def tool_front(cv, n, b):
    if n == 0:
        cv.line(13, 3 + b, 13, -2 + b, HANDLE) if False else None
        cv.line(13, 3 + b, 13, 0, HANDLE); cv.rect(11, 0, 15, 1, STEEL); cv.px(11, 1, STEEL_D); cv.px(15, 1, STEEL_D)
    elif n == 1:
        cv.line(12, 15 + b, 9, 12 + b, HANDLE); cv.rect(7, 10 + b, 10, 12 + b, STEEL); cv.px(7, 12 + b, STEEL_D)
    else:
        cv.line(12, 20, 12, 15, HANDLE); cv.rect(10, 21, 14, 23, STEEL); cv.px(14, 23, STEEL_D); cv.px(10, 23, STEEL_D)


def draw_side(cv, a, O, P):
    b = P['b']; skin = C(a, 'skin'); bottom = C(a, 'bottom'); top = C(O, 'top'); hair = C(a, 'hair'); eye = C(a, 'eyes')
    if O['coat']: top = mix(top, hx('#4a5a78'), .55)
    sw = P['sw']
    # back leg then front leg
    for x0, off, col in ((5, -sw // 2, shade(bottom, .8)), (7, sw // 2, bottom)):
        lift = 1 if (off != 0 and (off > 0) != (x0 == 5)) else 0
        x = x0 + off
        bot = 23 - lift
        cv.rect(x, 19, x + 2, bot - 2, col); cv.rect(x + (1 if True else 0), bot - 1, x + 3, bot, SHOE)
    cv.rect(5, 18, 10, 19, bottom)
    # back arm
    cv.rect(6 - P['sa'] // 2, 13 + b, 7 - P['sa'] // 2, 17 + b, shade(top, .75))
    cv.rect(5, 12 + b, 10, 18 + b, top); cv.hline(5, 10, 12 + b, light(top, .2))
    acc = a.get('acc'); ac = C(a, 'acc_c')
    if O['vest']: cv.rect(5, 13 + b, 6, 18 + b, shade(top, .7))
    if O['coat']: cv.rect(4, 13 + b, 11, 18 + b, top); cv.vline(8, 13 + b, 18 + b, shade(top, .7))
    if acc in ('apron', 'smith'): cv.rect(8, 14 + b, 11, 19 + b, ac if acc == 'apron' else hx('#7a5230')); cv.hline(8, 11, 14 + b, light(ac, .3))
    if acc == 'cloak': cv.rect(4, 12 + b, 8, 20 + b, ac); cv.rect(5, 12 + b, 10, 12 + b, light(ac, .3)); cv.hline(4, 8, 20 + b, shade(ac, .75))
    if acc == 'glasses_shawl': cv.poly([(4, 12 + b), (10, 12 + b), (9, 18 + b), (4, 18 + b)], ac)
    # head
    cv.ell(4, 2 + b, 12, 11 + b, skin)
    cv.ell(3, 1 + b, 12, 8 + b, hair); cv.rect(3, 4 + b, 7, 10 + b, hair); cv.rect(4, 8 + b, 7, 10 + b, shade(hair, .75))
    cv.px(11, 4 + b, hair); cv.px(12, 5 + b, hair) if a['style'] != 'short' else None; cv.hline(11, 12, 4 + b, hair); cv.hline(5, 9, 2 + b, light(hair, .22))
    cv.px(13, 8 + b, skin); cv.px(10, 7 + b, eye); cv.px(10, 8 + b, eye); cv.px(11, 9 + b, mix(skin, (255, 120, 120, 255), .35))
    cv.px(11, 10 + b, shade(skin, .6)) if not P['mouth'] else cv.rect(11, 10 + b, 12, 11 + b, hx('#a03a3a'))
    cv.px(7, 7 + b, shade(skin, .85)); cv.rect(7, 11 + b, 8, 12 + b, shade(skin, .85))
    st = a['style']
    if st == 'long': cv.rect(3, 6 + b, 6, 17 + b, hair); cv.rect(3, 12 + b, 6, 17 + b, shade(hair, .8))
    if st == 'bun': cv.ell(3, -1 + max(b, 0), 7, 3 + max(b, 0), hair)
    if st == 'ponytail': cv.rect(2, 5 + b, 3, 14 + b, hair); cv.px(3, 5 + b, hx('#c8402a')); cv.px(3, 4 + b, hx('#c8402a'))
    if st == 'braid': cv.rect(3, 9 + b, 5, 18 + b, hair); [cv.hline(3, 5, y, shade(hair, .75)) for y in range(10 + b, 19 + b, 3)]
    if st == 'messy':
        for x, y in [(4, 1), (6, 0), (8, 1), (10, 0), (12, 2)]: cv.px(x, y + b, hair)
    if a.get('acc') == 'smith': cv.rect(9, 9 + b, 12, 11 + b, shade(hair, .9))
    if a.get('acc') == 'glasses_shawl': cv.hline(9, 12, 7 + b, hx('#5a4a3a')); cv.px(9, 6 + b, hx('#5a4a3a')) if False else None
    hats(cv, a, O, b)
    # near arm + tool
    sa = P['sa']
    t = P['tool']
    if isinstance(t, int):
        pts = [((6, 11 + b), (3, 2 + b)), ((11, 12 + b), (15, 8 + b)), ((12, 16 + b), (15, 22))][t]
        cv.line(pts[0][0], pts[0][1], pts[1][0], pts[1][1], HANDLE)
        cv.rect(pts[0][0] - 1, pts[0][1], pts[0][0] + 1, pts[0][1] + 3, top); cv.rect(pts[0][0] - 1, pts[0][1] + 3, pts[0][0] + 1, pts[0][1] + 4, skin)
        ex, ey = pts[1]
        cv.rect(ex - 2, ey - 1, ex + 1, ey + 1, STEEL); cv.px(ex + 1, ey + 1, STEEL_D)
    else:
        ax = 6 + sa // 2
        cv.rect(ax, 13 + b, ax + 2, 16 + b, top); cv.rect(ax, 17 + b, ax + 2, 18 + b, skin)
        cv.rect(ax, 13 + b, ax + 2, 13 + b, light(top, .2))


def draw_char(a, season, d, anim, n):
    O = outfit(a, season)
    P = pose(anim, n, d)
    cv = Cv(16, 24)
    if d == 's': draw_side(cv, a, O, P)
    else: draw_fb(cv, a, O, P, d == 'u')
    cv.outline()
    return cv


def npc_look(r):
    return dict(skin=r['skin'], hair=r['hair'], style=r['style'], top=r['top'], bottom=r['bottom'], acc=r.get('acc', 'none'), acc_c=r.get('acc_c', '#ffffff'), eyes=r.get('eyes', '#2a2a3a'))


def draw_characters(W):
    """Player frames (farmer.py) and villager frames.  Names: ch_<id>_<season|all>_<d|u|s>_<anim>_<n>."""
    from .common import load_data
    for look in range(len(farmer.LOOKS)):
        for view, anim, n, cv in farmer.frames(look):
            W.add('ch_player%d_all_%s_%s_%d' % (look, view, anim, n), cv, 8, 23)
    for r in [r for r in load_data('npcs.cfd') if r['_type'] == 'npc']:
        a = npc_look(r)
        for season in SEASONS:
            for d in 'dus':
                for anim, cnt in (('idle', 1), ('walk', 4), ('swing', 3)):
                    for n in range(cnt):
                        W.add('ch_%s_%s_%s_%s_%d' % (r['id'], season, d, anim, n), draw_char(a, season, d, anim, n), 8, 23)
            for n in range(2):
                W.add('ch_%s_%s_d_talk_%d' % (r['id'], season, n), draw_char(a, season, 'd', 'talk', n), 8, 23)


# ---------------------------------------------------------------- portraits
def portrait(a, expr):
    cv = Cv(48, 52)
    skin, hair, top, eye = C(a, 'skin'), C(a, 'hair'), C(a, 'top'), C(a, 'eyes')
    hs, hl = shade(hair, .72), light(hair, .22)
    style, acc, ac = a['style'], a.get('acc', 'none'), C(a, 'acc_c')
    # back hair
    if style == 'long': cv.rect(8, 14, 39, 50, hair); cv.rect(8, 34, 39, 50, hs)
    if style == 'bun': cv.ell(18, 0, 30, 12, hair); cv.ell(20, 2, 28, 8, hl)
    if style == 'braid': cv.rect(34, 30, 40, 51, hair); [cv.hline(34, 40, y, hs) for y in range(32, 52, 4)]
    if style == 'ponytail': cv.rect(36, 12, 42, 36, hair); cv.rect(36, 30, 42, 36, hs)
    # shoulders
    cv.ell(2, 38, 45, 62, shade(top, .8) if acc != 'cloak' else ac); cv.ell(3, 38, 44, 58, top if acc != 'cloak' else ac)
    if acc in ('apron', 'smith'): cv.rect(14, 44, 33, 52, ac if acc == 'apron' else hx('#7a5230')); cv.line(14, 41, 20, 48, ac if acc == 'apron' else hx('#7a5230'))
    if acc == 'glasses_shawl': cv.poly([(2, 42), (45, 42), (40, 52), (8, 52)], ac)
    cv.rect(20, 34, 27, 42, shade(skin, .85))
    # head
    cv.ell(9, 8, 38, 38, skin)
    cv.ell(7, 16, 10, 28, skin); cv.ell(37, 16, 40, 28, skin)
    # hair cap
    cv.ell(7, 3, 40, 24, hair); cv.ell(10, 12, 37, 36, skin)
    for x in range(10, 38):
        if 22 <= x <= 26: continue
        cv.rect(x, 12, x, 15 + ((x * 7) % 3), hair)
    cv.rect(8, 14, 11, 26, hair); cv.rect(36, 14, 39, 26, hair)
    cv.hline(14, 26, 6, hl); cv.hline(16, 22, 8, hl)
    if style == 'messy':
        for x, y in [(12, 4), (17, 1), (23, 0), (29, 1), (35, 4)]: cv.rect(x, y, x + 3, y + 5, hair)
    if style == 'long': cv.rect(6, 20, 11, 46, hair); cv.rect(36, 20, 41, 46, hair)
    # eyes
    for ex in (15, 29):
        cv.ell(ex, 21, ex + 6, 29, (255, 255, 255, 255)); cv.ell(ex + 1, 22, ex + 5, 29, eye)
        cv.rect(ex + 2, 23, ex + 3, 25, (10, 10, 20, 255)); cv.px(ex + 3, 22, (255, 255, 255, 255)); cv.px(ex + 4, 24, (255, 255, 255, 255))
        if expr == 'happy': cv.rect(ex - 1, 19, ex + 7, 20, hair) if False else None
    # brows
    bc = shade(hair, .7)
    if expr == 'sad':
        cv.line(14, 19, 20, 17, bc); cv.line(34, 19, 28, 17, bc)
    elif expr == 'happy':
        cv.line(14, 18, 20, 17, bc); cv.line(28, 17, 34, 18, bc)
    else:
        cv.line(14, 18, 20, 18, bc); cv.line(28, 18, 34, 18, bc)
    cv.px(24, 29, shade(skin, .8)); cv.px(23, 30, shade(skin, .85)); cv.px(24, 30, shade(skin, .85))
    pink = mix(skin, (255, 110, 120, 255), .4)
    cv.ell(12, 30, 17, 33, pink); cv.ell(31, 30, 36, 33, pink)
    mc = hx('#8a3a3a')
    if expr == 'happy':
        cv.poly([(19, 33), (29, 33), (27, 37), (21, 37)], hx('#a03a3a')); cv.hline(21, 27, 34, (255, 255, 255, 255))
    elif expr == 'sad':
        cv.line(20, 37, 23, 35, mc); cv.line(24, 35, 28, 37, mc); cv.hline(23, 24, 35, mc)
    else:
        cv.line(20, 35, 28, 35, mc); cv.px(19, 34, mc); cv.px(29, 34, mc)
    if acc == 'smith': cv.rect(14, 32, 34, 38, shade(hair, .9)); cv.rect(20, 34, 28, 35, shade(skin, .7)) if expr != 'sad' else None
    if acc == 'glasses_shawl':
        cv.d.ellipse([13, 19, 22, 30], outline=hx('#5a4a3a')); cv.d.ellipse([26, 19, 35, 30], outline=hx('#5a4a3a')); cv.hline(22, 26, 24, hx('#5a4a3a'))
    if acc == 'straw_hat': cv.ell(0, 7, 47, 17, ac); cv.ell(10, 0, 37, 14, light(ac, .15)); cv.hline(10, 37, 9, hx('#c8402a'))
    if acc == 'bucket_hat': cv.rect(3, 9, 44, 16, ac); cv.ell(10, 0, 37, 13, light(ac, .1)); cv.hline(10, 37, 10, hx('#4a7ab0'))
    return cv.outline()


def draw_portraits(U):
    from .common import load_data
    for r in [r for r in load_data('npcs.cfd') if r['_type'] == 'npc']:
        a = npc_look(r)
        for expr in ('neutral', 'happy', 'sad'):
            U.add('por_%s_%s' % (r['id'], expr), portrait(a, expr), 0, 0)


# ---------------------------------------------------------------- animals
def draw_bird(kind, c1, c2, anim, n, duck=False):
    cv = Cv(16, 16)
    body, wing = hx(c1), shade(hx(c1), .88)
    acc = hx(c2)
    orange = hx('#f0a020')
    bob = 0; hx_, hy_ = 11, 4; lift = [0, 0]; hop = 0; tuck = False
    if anim == 'walk': bob = [0, -1, 0, -1][n]; lift = [[1, 0], [0, 0], [0, 1], [0, 0]][n]
    elif anim == 'idle': hy_ = 4 + (1 if n else 0)
    elif anim == 'eat': hy_ = 9 if n == 0 else 10; hx_ = 12
    elif anim == 'sleep': tuck = True; bob = 2
    elif anim == 'play': hop = [2, 4][n]
    yb = bob - hop
    if tuck:
        cv.ell(2, 8 + yb, 13, 14, body); cv.ell(4, 9 + yb, 10, 13, wing); cv.ell(9, 6 + yb, 14, 11, body); cv.px(12, 8 + yb, hx('#2a2a3a')); cv.hline(11, 13, 8 + yb, hx('#2a2a3a'))
        cv.poly([(2, 9 + yb), (0, 6 + yb), (3, 7 + yb)], wing)
        return cv.outline()
    # tail
    if duck: cv.poly([(2, 8 + yb), (0, 6 + yb), (3, 7 + yb)], wing)
    else: cv.poly([(3, 8 + yb), (0, 3 + yb), (2, 3 + yb), (4, 6 + yb)], wing); cv.poly([(3, 8 + yb), (1, 5 + yb), (3, 5 + yb)], shade(wing, .9))
    cv.ell(3, 6 + yb, 12, 13 + yb, body); cv.hline(5, 9, 6 + yb, light(body, .3))
    cv.ell(4, 8 + yb, 9, 12 + yb, wing)
    if hop: cv.px(5, 7 + yb, wing); cv.px(8, 6 + yb, wing)
    # neck + head
    ny = hy_ + yb
    cv.rect(10, ny + 2, 12, 9 + yb, body) if hy_ > 4 else cv.rect(10, ny + 2, 12, 8 + yb, body)
    cv.ell(hx_ - 2, ny, hx_ + 2, ny + 4, body)
    if duck:
        cv.poly([(hx_ + 3, ny + 2), (15, ny + 3), (hx_ + 3, ny + 4)], orange)
    else:
        cv.px(hx_ - 1, ny - 1, acc); cv.px(hx_, ny - 2, acc); cv.px(hx_ + 1, ny - 1, acc)
        cv.poly([(hx_ + 3, ny + 1), (15, ny + 2), (hx_ + 3, ny + 3)], orange); cv.px(hx_ + 2, ny + 4, acc)
    cv.px(hx_ + 1, ny + 1, hx('#2a2a3a'))
    if not tuck and anim != 'sleep':
        for lx, lf in ((6, lift[0]), (9, lift[1])):
            cv.vline(lx, 13 + yb, 14 - lf, orange); cv.px(lx + 1, 14 - lf, orange) if True else None
    return cv.outline()


def draw_rabbit(c1, c2, anim, n):
    cv = Cv(16, 16)
    body, belly = hx(c1), hx(c2)
    bob = 0; hop = 0; sleep = False; head_dy = 0
    if anim == 'walk': hop = [0, 2, 3, 1][n]
    elif anim == 'idle': head_dy = 1 if n else 0
    elif anim == 'eat': head_dy = 4 if n == 0 else 3
    elif anim == 'sleep': sleep = True
    elif anim == 'play': hop = [3, 5][n]
    yb = -hop
    if sleep:
        cv.ell(2, 8, 13, 15, body); cv.ell(9, 7, 14, 13, body); cv.ell(10, 4, 11, 9, body); cv.ell(12, 5, 13, 9, shade(body, .85)); cv.hline(11, 13, 10, hx('#2a2a3a'))
        cv.ell(1, 10, 3, 13, belly); return cv.outline()
    cv.ell(1, 9 + yb, 4, 12 + yb, belly)
    cv.ell(3, 7 + yb, 11, 14 + yb, body); cv.ell(5, 9 + yb, 9, 13 + yb, light(body, .15))
    cv.ell(2, 11 + yb, 6, 15 + yb, shade(body, .9))
    hy = 4 + head_dy + yb
    cv.ell(9, hy, 14, hy + 6, body)
    cv.ell(10, hy - 5 + (head_dy // 2), 11, hy + 1, body); cv.ell(12, hy - 4 + (head_dy // 2), 13, hy + 1, body)
    cv.px(10, hy - 3 + (head_dy // 2), hx('#e8a0b0')); cv.px(12, hy - 2 + (head_dy // 2), hx('#e8a0b0'))
    cv.px(12, hy + 2, hx('#2a2a3a')); cv.px(14, hy + 3, hx('#e8a0b0'))
    cv.rect(10, 12 + yb, 11, 14 + yb, body)
    return cv.outline()


def draw_quad(kind, c1, c2, anim, n, shorn=False):
    sizes = {'sheep': (24, 20), 'goat': (24, 22), 'cow': (32, 26)}
    w, h = sizes[kind]
    cv = Cv(w, h)
    body, dk = hx(c1), hx(c2)
    bob = 0; legph = 0; head = 'up'; sleep = False; hop = 0
    if anim == 'walk': bob = [0, -1, 0, -1][n]; legph = n + 1
    elif anim == 'idle': head = 'up' if n == 0 else 'bob'
    elif anim == 'eat': head = 'down'
    elif anim == 'sleep': sleep = True
    elif anim == 'play': hop = [2, 4][n]
    yb = bob - hop
    gy = h - 1  # ground line
    legh = {'sheep': 6, 'goat': 8, 'cow': 9}[kind]
    def legs(xs):
        for i, x in enumerate(xs):
            if sleep: continue
            ph = (legph + i) % 4
            lift = 1 if (legph and ph in (1, 2)) else 0
            if legph and i % 2 == 0: lift = 1 if ph in (1,) else 0
            y1 = gy - lift
            cv.rect(x, y1 - legh + 1 + yb, x + 1, y1, dk if kind != 'cow' else body); 
            cv.rect(x, y1 - 1, x + 1, y1, hx('#3a3030') if kind == 'cow' else dk)
    if kind == 'sheep':
        wool = body
        cx, cy = 11, 10
        if sleep: cy += 3
        legs([5, 8, 14, 17])
        blobs = [(6, cy, 5), (12, cy - 2, 6), (17, cy, 5), (12, cy + 2, 6), (8, cy + 2, 4), (16, cy + 2, 4)] if not shorn else [(11, cy + 1, 5), (7, cy + 1, 3)]
        col = wool if not shorn else hx('#e8d0c0')
        for bx, by, r in blobs: cv.ell(bx - r, by - r + yb, bx + r, by + r + yb, shade(col, .88))
        for bx, by, r in blobs: cv.ell(bx - r, by - r - 1 + yb, bx + r - 1, by + r - 1 + yb, col)
        if not shorn:
            for bx, by, r in blobs[:3]: cv.ell(bx - r + 2, by - r + yb, bx + r - 3, by + yb - 1, light(col, .5))
        hy = 8 + (3 if head == 'down' else 0) + (1 if head == 'bob' else 0) + yb + (3 if sleep else 0)
        cv.ell(19, hy, 23, hy + 5, dk); cv.ell(17, hy + 1, 19, hy + 3, shade(dk, .85)); cv.px(21, hy + 1, hx('#f0e8d8')); cv.px(23, hy + 3, hx('#e8a0a8'))
        if sleep: cv.hline(20, 22, hy + 1, hx('#f0e8d8'))
        cv.rect(2, cy - 2 + yb, 3, cy + yb, col)
    elif kind == 'goat':
        legs([5, 8, 15, 18])
        cy = 10 + (3 if sleep else 0)
        cv.ell(3, cy - 4 + yb, 20, cy + 6 + yb, body); cv.ell(5, cy - 3 + yb, 16, cy + 1 + yb, light(body, .25)); cv.ell(4, cy + 1 + yb, 19, cy + 6 + yb, shade(body, .86))
        cv.rect(1, cy - 5 + yb, 3, cy - 3 + yb, body)
        hy = 3 + (6 if head == 'down' else 0) + (1 if head == 'bob' else 0) + yb + (6 if sleep else 0)
        cv.rect(17, hy + 3, 19, cy - 2 + yb, body) if head != 'down' else cv.rect(17, cy - 4 + yb, 19, hy + 2, body)
        cv.ell(18, hy, 23, hy + 6, body); cv.ell(18, hy + 3, 23, hy + 6, dk); cv.px(21, hy + 2, hx('#2a2a3a')); cv.px(23, hy + 5, hx('#f0c0b0'))
        cv.line(19, hy, 17, hy - 3, hx('#e8e0c8')); cv.line(21, hy, 20, hy - 3, hx('#e8e0c8')); cv.rect(21, hy + 6, 21, hy + 8, hx('#e8e0d0'))
        cv.px(18, hy + 1, dk); cv.px(18, hy + 2, dk)
    else:
        legs([6, 10, 21, 25])
        cy = 11 + (3 if sleep else 0)
        cv.ell(2, cy - 6 + yb, 27, cy + 8 + yb, body)
        cv.ell(4, cy - 5 + yb, 20, cy + 1 + yb, light(body, .2))
        for (px_, py_, rx, ry) in [(8, cy - 3, 4, 3), (19, cy, 5, 4), (14, cy + 4, 3, 2), (5, cy + 2, 2, 3)]:
            cv.ell(px_ - rx, py_ - ry + yb, px_ + rx, py_ + ry + yb, dk)
        cv.ell(4, cy + 4 + yb, 25, cy + 8 + yb, shade(body, .85))
        cv.ell(16, cy + 6 + yb, 20, cy + 10 + yb, hx('#f4b0b8')) if not sleep else None
        cv.rect(0, cy - 4 + yb, 2, cy + 3 + yb, dk); cv.px(0, cy + 4 + yb, dk); cv.px(1, cy + 4 + yb, hx('#a89888'))
        hy = 3 + (7 if head == 'down' else 0) + (1 if head == 'bob' else 0) + yb + (7 if sleep else 0)
        cv.rect(23, hy + 4, 27, cy - 2 + yb, body) if head != 'down' else cv.rect(23, cy - 4 + yb, 27, hy + 4, body)
        cv.ell(23, hy, 31, hy + 9, body); cv.ell(26, hy + 5, 31, hy + 9, hx('#f4b0b8')); cv.px(28, hy + 7, hx('#a85a68')); cv.px(30, hy + 7, hx('#a85a68'))
        cv.px(26, hy + 3, hx('#2a2a3a')); cv.px(27, hy + 3, hx('#2a2a3a')) if sleep else None
        cv.ell(22, hy + 1, 24, hy + 4, dk); cv.ell(30, hy + 1, 31, hy + 3, dk)
        cv.poly([(25, hy), (24, hy - 3), (26, hy - 3)], hx('#f0e8d0')); cv.poly([(29, hy), (30, hy - 3), (28, hy - 3)], hx('#f0e8d0'))
    return cv.outline()


def draw_animals(W):
    from .common import load_data
    rows = {r['id']: r for r in load_data('animals.cfd') if r['_type'] == 'animal'}
    anims = {'idle': 2, 'walk': 4, 'eat': 2, 'sleep': 2, 'play': 2}
    def emit(name, fn, ax, ay):
        for anim, cnt in anims.items():
            for n in range(cnt):
                W.add('an_%s_%s_%d' % (name, anim, n), fn(anim, n), ax, ay)
    for aid, r in rows.items():
        c1, c2 = r['c1'], r['c2']
        if aid == 'chicken': emit(aid, lambda a, n: draw_bird('chicken', c1, c2, a, n), 8, 15)
        elif aid == 'duck': emit(aid, lambda a, n: draw_bird('duck', c1, c2, a, n, True), 8, 15)
        elif aid == 'rabbit': emit(aid, lambda a, n: draw_rabbit(c1, c2, a, n), 8, 15)
        elif aid in ('sheep', 'goat', 'cow'):
            sz = {'sheep': (24, 20), 'goat': (24, 22), 'cow': (32, 26)}[aid]
            emit(aid, lambda a, n, aid=aid: draw_quad(aid, c1, c2, a, n), sz[0] / 2, sz[1] - 1)
            if aid == 'sheep': emit('sheep_shorn', lambda a, n: draw_quad('sheep', c1, c2, a, n, True), sz[0] / 2, sz[1] - 1)
