"""Farmer - the player character (two looks): straw hat, work shirt, denim overalls, boots.

Layered, palette-driven pixel art.  Every frame is 16x24, anchored at (8, 23), and the frame names match the
vocabulary cpp/animation/animation.cpp already loads (idle/walk/swing/water/fish/pick/talk/eat/happy), plus a
second idle frame (idle_1, a one-pixel breathing bob) which the renderer picks up when present.

Parts (hat+face, torso, legs, arms, props) are ASCII templates / tiny draw functions stamped through a per-look
palette, so a new look is a palette entry (+ optional hair overlay) and tweaking a part means editing a few
characters.  Light comes from the top-left.  Views: 'd' front, 'u' back, 's' side (faces right; the engine
mirrors it for left).
"""
from .common import *

W, H = 16, 24
HEAD_Y, TORSO_Y, HIP_Y, LEG_Y = 2, 13, 18, 19      # hat top row, shoulder row, hip row, first leg row (idle pose)
FOOT_Y = 22                                         # last boot row


# ---------------------------------------------------------------- looks (palettes)
def _look(**kw):
    base = dict(
        skin='#f3cfa6', skin_lo='#d9a57c', blush='#e89a8a', eye='#2b2233', mouth='#9a4a44',
        hat='#e2b252', hat_hi='#f6dc8e', hat_lo='#bd8a3c', hat_dk='#8f6428',
        shirt='#f6f1e7', shirt_lo='#d6ccbc', shirt_dk='#aea090',
        denim='#3f6fb2', denim_hi='#5e90cf', denim_lo='#2d4f8a', denim_dk='#1f3868', button='#f2c548',
        boot='#6d4529', boot_hi='#8f5d37', boot_lo='#46301f',
        steel='#cfd5e0', steel_lo='#8d96a8', wood='#9a6c3e', wood_lo='#6e4a28',
        can='#6a9ac8', can_hi='#a8d0f0', can_lo='#4a7aa8', water='#7cc4f2',
        fruit='#d94a3c', leaf='#5aa845', veg='#e8863a', spark='#fff6b0', line='#e8e4dc', mouth_in='#5c2c34',
    )
    base.update(kw)
    return {k: hx(v) for k, v in base.items()}


LOOKS = [
    _look(hair='#4b3125', hair_hi='#6f4a39', hair_lo='#33211b', band='#c9503c', band_lo='#8f3426'),
    _look(skin='#e9b78e', skin_lo='#cf9068', hair='#b4532b', hair_hi='#d97b3f', hair_lo='#7f3519',
          band='#3f7fb5', band_lo='#2a5880',
          shirt='#f0a24e', shirt_lo='#cf7f36', shirt_dk='#a35f26',
          denim='#4e7d72', denim_hi='#6fa293', denim_lo='#38605a', denim_dk='#274540'),
]
PONYTAIL = (False, True)            # per look: hair tied back (shows behind the hat / down the back)


def palette(look):
    L = LOOKS[look & 1]
    return {
        'a': L['hat_hi'], 'h': L['hat'], 's': L['hat_lo'], 'd': L['hat_dk'], 'B': L['band'], 'b': L['band_lo'],
        'K': L['hair'], 'k': L['hair_hi'], 'q': L['hair_lo'],
        'S': L['skin'], 'r': L['skin_lo'], 'c': L['blush'], 'E': L['eye'], 'M': L['mouth'],
        'W': L['shirt'], 'w': L['shirt_lo'], 'x': L['shirt_dk'],
        'N': L['denim'], 'n': L['denim_hi'], 'm': L['denim_lo'], 'o': L['denim_dk'], 'Y': L['button'],
        'T': L['boot'], 't': L['boot_hi'], 'u': L['boot_lo'], 'U': shade(L['boot'], .78),
        'F': L['steel'], 'f': L['steel_lo'], 'D': L['wood'], 'e': L['wood_lo'],
        'G': L['can'], 'g': L['can_hi'], 'j': L['can_lo'], 'v': L['water'],
        'R': L['fruit'], 'l': L['leaf'], 'V': L['veg'], 'P': L['spark'], 'L': L['line'], 'O': L['mouth_in'],
    }


def stamp(cv, art, x0, y0, pal):
    """Stamp an ASCII template ('.' = transparent) at (x0, y0)."""
    width = len(art[0])
    for r, row in enumerate(art):
        assert len(row) == width, 'ragged template row %r' % row
        for c, ch in enumerate(row):
            if ch != '.':
                cv.px(x0 + c, y0 + r, pal[ch])


# ---------------------------------------------------------------- parts: hat + head (14 wide, stamped at x=1)
HAT = [
    "....ahhhhs....",
    "...ahhhshhs...",
    "..ahhhhhhhhs..",
    "..BBBBBBBBBb..",
    "ahhhhshhhhhhhs",
    ".dssssssssssd.",
]
FACE = {
    'd': [
        "..KrrrrrrrrK..",
        "..KSESSSSESK..",
        "..KSESSSSESK..",
        "..KcSSMMSScK..",
        "...rSSSSSSr...",
    ],
    'u': [
        "..qqqqqqqqqq..",
        "..KkKKKKKKKK..",
        "..KKKKKKKKKK..",
        "..KKKKKKKKKK..",
        "...KKKKKKKK...",
    ],
    's': [
        "..qqrrrrrrr...",
        "..KKKSSSSES...",
        "..KKKSSSSESS..",
        "..KKKSSScSM...",
        "...KKSSSSS....",
    ],
}
MOUTH_OPEN = [(7, 11, 'O'), (8, 11, 'O'), (7, 12, 'M'), (8, 12, 'M')]      # front view only (talk / eat / happy)

# ---------------------------------------------------------------- parts: torso (shoulder row + 5 body rows)
TORSO = {
    'd': (3, [                      # stamped at x=3 (10 wide); arms are separate
        "WWWWrrWWWW",
        ".WNWWWWNW.",
        ".WYNNNNYW.",
        ".wNNnnNNw.",
        ".NNNNNNNN.",
        ".NNNNNNNN.",
    ]),
    'u': (3, [
        "WWWWrrWWWW",
        ".WNWWWWNW.",
        ".WNWWWWNW.",
        ".wNNNNNNw.",
        ".NNNNnnNN.",
        ".NNNNNNNN.",
    ]),
    's': (5, [                      # stamped at x=5 (6 wide)
        "wWWWWW",
        "wWWWNW",
        "wWWNNN",
        "wWWNYN",
        "NNNNNN",
        "nNNNNm",
    ]),
}


# ---------------------------------------------------------------- legs
def leg_fb(cv, pal, x, lift, outer):
    """One front/back leg (3px denim + 4px boot).  outer = -1 (left leg) / +1 (right leg); lift raises the foot."""
    foot = FOOT_Y - lift
    for yy in range(HIP_Y, foot - 1):
        cv.px(x, yy, pal['n']); cv.px(x + 1, yy, pal['N']); cv.px(x + 2, yy, pal['m'])
    bx = x - 1 if outer < 0 else x            # boot is one pixel wider on the outside
    cv.rect(bx, foot - 1, bx + 3, foot, pal['T'])
    cv.px(bx, foot - 1, pal['t']); cv.px(bx + 1, foot - 1, pal['t'])
    cv.hline(bx, bx + 3, foot, pal['u'])


def legs_fb(cv, pal, lL=0, lR=0):
    cv.rect(4, HIP_Y, 11, HIP_Y, pal['N'])
    leg_fb(cv, pal, 4, lL, -1)
    leg_fb(cv, pal, 9, lR, +1)


def legs_side(cv, pal, stride=0, lift=(0, 0)):
    """Side legs: thigh follows the stride by half, shin+boot by the full amount (a cheap knee bend).
    lift = (back, front) foot raise."""
    cv.rect(5, HIP_Y, 10, HIP_Y, pal['N'])
    for off, dim, lf in ((-stride, True, lift[0]), (stride, False, lift[1])):
        foot = FOOT_Y - lf
        main, edge, boot = (pal['m'], pal['o'], pal['U']) if dim else (pal['N'], pal['m'], pal['T'])
        x = 6 + off // 2
        for yy in range(LEG_Y, foot - 1):
            xx = x if yy < LEG_Y + 2 else 6 + off
            cv.hline(xx, xx + 2, yy, main); cv.px(xx + 2, yy, edge)
        bx = 6 + off
        cv.rect(bx, foot - 1, bx + 3, foot, boot)                      # boot, toe pointing right
        if not dim: cv.hline(bx, bx + 2, foot - 1, pal['t'])
        cv.hline(bx, bx + 3, foot, pal['u'])


# ---------------------------------------------------------------- arms
def arm_fb(cv, pal, side, ext, dy):
    """Hanging front/back arm (sleeve + rolled cuff + hand).  ext: -1 back (shorter) / 0 / +1 forward (longer)."""
    x = 2 if side < 0 else 12
    y0 = TORSO_Y + 1 + dy
    sl = 3 + min(0, ext)
    for i in range(sl):
        a, b = (pal['w'], pal['W']) if side < 0 else (pal['W'], pal['w'])
        cv.px(x, y0 + i, a); cv.px(x + 1, y0 + i, b)
    cv.hline(x, x + 1, y0 + sl - 1, pal['x'])
    ha, hb = (pal['r'], pal['S']) if side < 0 else (pal['S'], pal['r'])
    for j in range(2 + max(0, ext)):
        cv.px(x, y0 + sl + j, ha); cv.px(x + 1, y0 + sl + j, hb)


def arm_side(cv, pal, ax, dy, ext=0):
    """Near arm in the side view: 2px sleeve (back edge shaded) at x=ax and a 2px hand below it."""
    y0 = TORSO_Y + 1 + dy
    cv.rect(ax, y0, ax + 1, y0 + 2, pal['W']); cv.vline(ax, y0, y0 + 2, pal['w'])
    cv.rect(ax, y0 + 3, ax + 1, y0 + 4 + ext, pal['S']); cv.hline(ax, ax + 1, y0 + 4 + ext, pal['r'])


def hand(cv, pal, x, y, w=2, h=2):
    cv.rect(x, y, x + w - 1, y + h - 1, pal['S'])
    cv.hline(x, x + w - 1, y + h - 1, pal['r'])


def sleeve(cv, pal, x, y, w=2, h=2):
    cv.rect(x, y, x + w - 1, y + h - 1, pal['W'])
    cv.vline(x, y, y + h - 1, pal['w'])


def handle(cv, pal, x0, y0, x1, y1):
    cv.line(x0, y0, x1, y1, pal['D'])


def blade(cv, pal, x, y, w=4, h=3):
    """Generic tool head (hoe / axe / pick all share the swing frames)."""
    cv.rect(x, y, x + w - 1, y + h - 1, pal['F'])
    cv.hline(x, x + w - 1, y + h - 1, pal['f']); cv.px(x + w - 1, y, pal['f'])


def watering_can(cv, pal, x, y, tilt, spout_dx=1):
    """5x4 can at (x, y); the spout points towards +x (spout_dx=1)."""
    cv.rect(x, y, x + 4, y + 3, pal['G']); cv.hline(x, x + 4, y, pal['g']); cv.vline(x + 4, y + 1, y + 3, pal['j'])
    cv.hline(x, x + 4, y + 3, pal['j'])
    cv.vline(x - 1, y, y + 2, pal['j'])                                 # back handle
    cv.line(x + 4, y + 2, x + 6, y + 3 + tilt, pal['j']); cv.px(x + 6, y + 3 + tilt, pal['g'])
    if tilt:
        for (dx, dy) in [(7, 5), (6, 6), (7, 7), (6, 8)]: cv.px(x + dx, y + dy, pal['v'])


# ---------------------------------------------------------------- composition
class Pose:
    """Everything that varies between frames."""
    def __init__(self, **kw):
        self.dy = 0                    # head+torso+arms offset (down is positive); legs stay planted
        self.lift = (0, 0)             # front/back view: (left, right) foot lift
        self.stride = 0                # side view: front-leg forward offset (back leg mirrors it)
        self.slift = (0, 0)            # side view: (back, front) foot lift
        self.swing = (0, 0)            # front/back arm extension (left, right); None = arm drawn by the prop
        self.near = 0                  # side view: 0 = near arm hangs, None = drawn by the prop
        self.mouth = 0                 # 1 = open
        self.happy = False             # closed ^^ eyes
        self.carry = False             # pick_1: item held in front of the body
        self.prop = None               # prop drawer: draws held arms/tools after the hat
        self.__dict__.update(kw)


# -- props: (cv, pal, view, dy)  ------------------------------------------------------------------------------
def p_swing0(cv, pal, view, dy):                        # wind-up: tool overhead
    if view == 's':
        sleeve(cv, pal, 6, 9 + dy, 2, 5); hand(cv, pal, 5, 7 + dy)
        handle(cv, pal, 5, 7 + dy, 3, 2); blade(cv, pal, 1, 0, 4, 3)
    else:
        sleeve(cv, pal, 13, 7 + dy, 2, 7); hand(cv, pal, 13, 5 + dy)
        handle(cv, pal, 14, 5 + dy, 14, 1); blade(cv, pal, 11, 0, 5, 3)


def p_swing1(cv, pal, view, dy):                        # mid swing: tool crosses in front
    if view == 's':
        sleeve(cv, pal, 7, 14, 3, 2); hand(cv, pal, 10, 14)
        handle(cv, pal, 11, 14, 14, 10); blade(cv, pal, 12, 7, 3, 4)
    else:
        sleeve(cv, pal, 12, 15, 2, 3); hand(cv, pal, 12, 18)
        handle(cv, pal, 12, 18, 6, 15); blade(cv, pal, 3, 13, 4, 3)


def p_swing2(cv, pal, view, dy):                        # impact: tool head on the ground in front
    if view == 's':
        sleeve(cv, pal, 8, 15 + dy, 2, 3); hand(cv, pal, 10, 18 + dy)
        handle(cv, pal, 11, 19 + dy, 14, 21); blade(cv, pal, 12, 20, 4, 3)
    else:
        sleeve(cv, pal, 12, 15 + dy, 2, 3); hand(cv, pal, 12, 18 + dy)
        handle(cv, pal, 13, 19 + dy, 13, 21); blade(cv, pal, 10, 21, 5, 2)


def p_can(n):
    def f(cv, pal, view, dy):
        if view == 's':
            sleeve(cv, pal, 7, 14, 3, 2); hand(cv, pal, 10, 15)
            watering_can(cv, pal, 9, 15, n)
        else:
            sleeve(cv, pal, 12, 14, 2, 2); hand(cv, pal, 11, 16)
            watering_can(cv, pal, 9, 16, n)
    return f


def p_rod(n):
    def f(cv, pal, view, dy):
        if view == 's':
            sleeve(cv, pal, 7, 14, 3, 2); hand(cv, pal, 10, 14)
            tip = (15, 6) if n == 0 else (14, 2)
            handle(cv, pal, 11, 14, *tip)
            cv.vline(15, tip[1] + 1, tip[1] + (4 if n == 0 else 7), pal['L'])
        else:
            sleeve(cv, pal, 12, 14, 2, 2); hand(cv, pal, 12, 16)
            tip = (15, 6) if n == 0 else (14, 2)
            handle(cv, pal, 13, 16, *tip)
            cv.vline(tip[0], tip[1] + 1, tip[1] + (3 if n == 0 else 6), pal['L'])
    return f


def p_pick(n):
    def f(cv, pal, view, dy):
        if view == 's':
            sleeve(cv, pal, 7, 14 + dy + 1, 2, 3); hand(cv, pal, 9 + n, 17 + dy + 2 - n)
            if n:
                cv.rect(11, 16 + dy, 13, 18 + dy, pal['V']); cv.px(12, 15 + dy, pal['l']); cv.px(13, 15 + dy, pal['l'])
        else:
            if n and view == 'd':
                arm_fb(cv, pal, -1, 0, dy - 2); arm_fb(cv, pal, +1, 0, dy - 2)
                cv.rect(6, 15 + dy + 2, 9, 18 + dy + 1, pal['V']); cv.rect(6, 14 + dy + 2, 9, 14 + dy + 2, pal['l'])
                hand(cv, pal, 5, 17 + dy + 1); hand(cv, pal, 10, 17 + dy + 1)
    return f


def p_eat(n):
    def f(cv, pal, view, dy):
        sleeve(cv, pal, 11, 14, 2, 2)
        y = 12 + 2 * n                                           # apple at the lips, then lowered (bitten)
        hand(cv, pal, 9, y + 1)
        cv.rect(8, y, 9, y + 1, pal['R']); cv.px(8, y, pal['l']) if n == 0 else cv.px(9, y, pal['S'])
    return f


def p_happy(cv, pal, view, dy):
    for x in (1, 13):
        sleeve(cv, pal, x, 11 + dy, 2, 4); hand(cv, pal, x, 8 + dy + 1 - 1)
    cv.px(8, 0, pal['P']); cv.px(3, 1, pal['P']); cv.px(12, 1, pal['P'])


def make_pose(anim, n):
    if anim == 'idle':
        return Pose(dy=n)
    if anim == 'walk':
        return Pose(dy=[0, -1, 0, -1][n], lift=[(0, 1), (0, 0), (1, 0), (0, 0)][n], stride=[2, 0, -2, 0][n],
                    slift=[(0, 0), (0, 1), (0, 0), (1, 0)][n], swing=[(1, -1), (0, 0), (-1, 1), (0, 0)][n])
    if anim == 'talk':
        return Pose(mouth=n)
    if anim == 'swing':
        return [Pose(dy=-1, swing=(0, None), near=None, prop=p_swing0), Pose(dy=0, swing=(0, None), near=None, prop=p_swing1),
                Pose(dy=1, swing=(0, None), near=None, prop=p_swing2)][n]
    if anim == 'water':
        return Pose(swing=(0, None), near=None, prop=p_can(n))
    if anim == 'fish':
        return Pose(swing=(0, None), near=None, prop=p_rod(n))
    if anim == 'pick':
        return Pose(dy=3 - n, swing=(0, 0) if n == 0 else (None, None), near=0, prop=p_pick(n), carry=n == 1)
    if anim == 'eat':
        return Pose(swing=(0, None), near=None, mouth=1 - n, prop=p_eat(n))
    if anim == 'happy':
        return Pose(dy=-1, swing=(None, None), near=None, mouth=1, happy=True, prop=p_happy)
    raise ValueError(anim)


# ---------------------------------------------------------------- hair overlay (tied-back hair)
def ponytail(cv, pal, view, dy):
    if view == 'u':
        cv.rect(7, 11 + dy, 8, 11 + dy, pal['B'])
        cv.rect(7, 12 + dy, 8, 16 + dy, pal['K']); cv.vline(7, 12 + dy, 15 + dy, pal['k']); cv.hline(7, 8, 17 + dy, pal['q'])
    elif view == 's':
        cv.px(4, 10 + dy, pal['B'])
        cv.rect(2, 11 + dy, 4, 12 + dy, pal['K']); cv.rect(2, 13 + dy, 3, 15 + dy, pal['K']); cv.vline(2, 11 + dy, 14 + dy, pal['k']); cv.px(3, 16 + dy, pal['q'])


def draw_farmer(look, view, anim='idle', n=0):
    pal = palette(look)
    P = make_pose(anim, n)
    cv = Cv(W, H)
    if view == 's': legs_side(cv, pal, P.stride, P.slift)
    else: legs_fb(cv, pal, *P.lift)
    tx, torso = TORSO[view]
    stamp(cv, torso, tx, TORSO_Y + P.dy, pal)
    if view == 's':
        if P.near is not None: arm_side(cv, pal, 7 - P.stride // 2, P.dy)
    else:
        sw = P.swing if not (P.carry and view == 'u') else (0, 0)
        if sw[0] is not None: arm_fb(cv, pal, -1, sw[0], P.dy)
        if sw[1] is not None: arm_fb(cv, pal, +1, sw[1], P.dy)
    stamp(cv, FACE[view], 1, HEAD_Y + 6 + P.dy, pal)
    if view == 'd':
        if P.happy:
            for (x, y) in ((4, 9), (5, 9), (9, 9), (10, 9)): cv.px(x, y + P.dy, pal['S'])
            for (x, y) in ((4, 10), (5, 10), (9, 10), (10, 10)): cv.px(x, y + P.dy, pal['E'])
            cv.px(4, 9 + P.dy, pal['E']); cv.px(10, 9 + P.dy, pal['E'])
            for (x, y) in ((4, 10), (10, 10)): cv.px(x, y + P.dy, pal['S'])
    if P.mouth and view == 'd':
        for (x, y, c) in MOUTH_OPEN: cv.px(x, y + P.dy, pal[c])
    if PONYTAIL[look & 1]: ponytail(cv, pal, view, P.dy)
    stamp(cv, HAT, 1, HEAD_Y + P.dy, pal)
    if P.prop: P.prop(cv, pal, view, P.dy)
    cv.outline()
    return cv


# ---------------------------------------------------------------- frame table (names consumed by the engine)
FRAMES = {'idle': 2, 'walk': 4, 'swing': 3, 'water': 2, 'fish': 2, 'pick': 2}      # every view
FRONT_ONLY = {'talk': 2, 'eat': 2, 'happy': 1}


def frames(look):
    """Yields (view, anim, n, Cv) for every frame of one look."""
    for view in 'dus':
        for anim, cnt in FRAMES.items():
            for n in range(cnt):
                yield view, anim, n, draw_farmer(look, view, anim, n)
    for anim, cnt in FRONT_ONLY.items():
        for n in range(cnt):
            yield 'd', anim, n, draw_farmer(look, 'd', anim, n)
