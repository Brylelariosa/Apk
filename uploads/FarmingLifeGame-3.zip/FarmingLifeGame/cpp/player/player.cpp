// Player movement, collision, footsteps, warps and action animation timing.
#include "game/game.h"

namespace cf {

static float groundSpeed(Terrain t) { return t == Terrain::Path || t == Terrain::FloorWood || t == Terrain::FloorStone || t == Terrain::Bridge ? 1.0f : 0.94f; }

void Game::updatePlayer(float dt) {
  Player& p = s.pl; Map& m = map();
  p.happyT = std::max(0.f, p.happyT - dt);
  if (p.animKind) {
    p.animT += dt;
    if (!p.hitDone && p.animT >= p.animDur * 0.5f) { p.hitDone = true; applyAction(p.pending); }
    if (p.animT >= p.animDur) {
      p.animKind = 0; p.animT = 0;
      if (actionHeld && p.pending.act != Act::Eat && p.pending.act != Act::Fish) { ActionInfo a = resolveAction(); if (a.act == p.pending.act && a.tile == p.pending.tile) startAction(a); }
    }
    p.moving = false;
    return;
  }
  float mx = moveStick[0], my = moveStick[1], len = std::sqrt(mx * mx + my * my);
  p.moving = false;
  if (len > 0.14f) {
    float speed = 64.f * (1.f + 0.12f * p.buffAmount(BuffType::Speed)) * (p.energy <= 0 ? 0.7f : 1.f) * std::min(1.f, len);
    speed *= groundSpeed(m.terrain((int)(p.pos.x / kTile), (int)(p.pos.y / kTile)));
    float nx = mx / len, ny = my / len;
    Dir want = dirFromVec(nx, ny);
    if (want != p.facing) {   // hysteresis so diagonal drift does not flip the sprite
      bool horizP = p.facing == Dir::Left || p.facing == Dir::Right;
      float ax = std::fabs(nx), ay = std::fabs(ny);
      if ((horizP && ay > ax * 1.3f) || (!horizP && ax > ay * 1.3f) || (horizP == (want == Dir::Left || want == Dir::Right))) p.facing = want;
    }
    Vec2 np = p.pos;
    np.x += nx * speed * dt; if (collides(m, np)) np.x = p.pos.x;
    Vec2 tp = np; tp.y += ny * speed * dt; if (collides(m, tp)) tp.y = np.y;
    np = tp;
    np.x = clampv(np.x, 4.f, (float)m.w * kTile - 4.f); np.y = clampv(np.y, 4.f, (float)m.h * kTile - 3.f);
    if (std::fabs(np.x - p.pos.x) + std::fabs(np.y - p.pos.y) > 0.01f) p.moving = true;
    p.pos = np;
  }
  if (p.moving) {
    p.walkT += dt * 9.f; p.stepT += dt;
    if (p.stepT > 0.3f) { p.stepT = 0; audio->play(Sfx::Step, 0.35f, 0.9f + rng.f() * 0.25f); }
    if (settings.particles > 0 && rng.chance(0.05f) && m.terrain((int)(p.pos.x / kTile), (int)(p.pos.y / kTile)) != Terrain::Path) fx.emit(Fx::Dust, p.pos.x + rng.rangef(-2, 2), p.pos.y - 1, rng.rangef(-4, 4), -6, 0.4f, col::rgba(200, 180, 150, 140));
  } else p.walkT = 0, p.stepT = 0.2f;
  // warps
  IVec2 t = playerTile();
  if (!fading) if (const Warp* w = m.warpAt(t.x, t.y)) {
    std::string to = w->toMap, tp = w->toPoint;
    if (to == "mine_1" && s.deepestMine >= 5) {
      std::vector<std::pair<int, std::string>> ch{{300, "Floor 1"}};
      for (int f = 5; f <= s.deepestMine && f <= 20; f += 5) ch.push_back({300 + f, fmt("Floor %d (elevator)", f)});
      ch.push_back({299, "Never mind"});
      s.pl.pos = s.pl.pos + Vec2(0, 10);
      showDialogue("Mine Lift", "", "", "The old lift creaks. Where to?", ch);
      return;
    }
    audio->play(Sfx::Door);
    if (to == "house") { enterMap("house", tp); }
    else enterMap(to, tp);
  }
}

}  // namespace cf
