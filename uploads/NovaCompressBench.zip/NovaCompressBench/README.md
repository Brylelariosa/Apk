# NovaCompress Bench

An Android app that benchmarks standard lossless compressors (Zstandard, LZMA2/XZ,
Brotli, Deflate, Bzip2, LZ4, Snappy) against **NovaCompress**, an experimental
research compressor built from scratch for this project.

## Read this first

The original spec for this app is extremely ambitious - a production app
wrapping seven codecs *plus* a novel ten-component research compressor with
graph-based pattern compression, multiple entropy coders, streaming support
for 10GB+ files, full visualization, and CI, all in one pass. That's
realistically a multi-month project for a team, not a single-session build.

What you have here is a **complete, working, genuinely tested first version**
covering the full breadth of the spec - every screen, every architectural
piece, and a real NovaCompress pipeline that actually compresses and
decompresses correctly. Some of the more ambitious sub-features (true
graph-grammar compression, ANS coding, a Brotli *encoder*) are implemented as
clearly-documented simplifications rather than faked, for reasons explained
below. Treat this the way you'd treat any of your other projects that went
through several passes (mGBA, TopDownShooter, MangaNative) - this is pass
one, built to be genuinely correct and easy to extend rather than to look
complete and hide gaps.

## Verification - why you can trust the core algorithm

I don't have Android SDK, Gradle, or network access in the sandbox this was
built in, so I couldn't compile or run the actual Android project to check
it. What I *could* do: write the highest-risk algorithmic pieces (the range
coder, the LZ matcher, the predictor, the Huffman coder, the chunk container
format) as plain Java, run them with the JDK that was available, and
round-trip test them against ~115 cases before porting the verified logic
into Kotlin:

- **Range coder**: 47 cases - edge cases, uniform/skewed/adversarial
  distributions, a dedicated carry-propagation stress test (the classic bug
  class for this kind of coder).
- **Full NovaCompress pipeline** (matcher + predictor + entropy coding
  together): 30 cases - random, repetitive, text-like, JSON-like,
  self-overlapping runs, fuzzed mixes, and a case specifically constructed to
  make Huffman beat the range coder (exercising the auto-selection path).
- **Chunk container format** (the on-disk framing, including mixed
  STORE/NovaCompress segments interleaved within a chunk and multi-chunk
  streams): 8 cases, including empty input.
- A 4MB throughput sanity check (~7 MB/s encode, ~15 MB/s decode
  single-threaded on the sandbox's CPU - see "Performance expectations"
  below).

All of that passed. The Kotlin port mirrors the verified Java structurally
(same algorithm, same order of operations); the main risk left is Kotlin
syntax issues I couldn't catch without a Kotlin compiler in the sandbox, not
algorithmic correctness. The JUnit tests under `app/src/test` are the same
scenarios ported to Kotlin, so `./gradlew test` (or the CI workflow) is your
first real signal on that remaining risk, and will now also be the thing
that catches any *future* regressions.

## What's simplified or deferred, and why

Being upfront about this is more useful than pretending everything is fully
built out:

- **Brotli**: decompression is real (`org.brotli:dec`, a genuine portable
  Java decoder). Compression throws a clear `AlgorithmUnavailableException`
  instead of wiring up an encoder dependency I couldn't verify actually
  resolves or works correctly on Android. Adding a real encoder is the
  natural next step (see "Extending").
- **Snappy**: included per the spec (marked optional there too), but
  xerial's `snappy-java` is primarily built/tested for desktop JVMs and isn't
  guaranteed to ship a working native `.so` for every Android ABI. Wrapped
  defensively (`isAvailable()` actually exercises the native load path) so
  it reports "unavailable" instead of crashing if it can't load.
- **Graph-Based Pattern Compression** (spec stage 6): implemented as
  analytics over the matcher's own output (which regions get referenced,
  shown in Research Mode) rather than a second, separate compression pass. A
  real LZ matcher already deduplicates repeated structure; a second
  graph-grammar compressor on top of that would be redundant complexity and
  correctness risk for uncertain extra gain. A true recursive grammar/SLP
  compressor (templates containing templates) is a real, separate research
  direction if you want to pursue it later.
- **ANS entropy coding**: not implemented. The spec asks for arithmetic
  coding / ANS / Huffman / range coding with automatic selection.
  Range coding and Huffman are both implemented and auto-selected between
  (arithmetic coding and range coding are essentially the same technique
  wearing different clothes, so this covers 2 of the 4 named approaches).
  ANS (specifically rANS) has its own subtle renormalization correctness
  pitfalls, similar in spirit to the range coder's carry propagation but
  different in detail, and I'd want a compiler-in-the-loop to get it right
  rather than hand-write it once and hope - exactly the situation that
  produced the verification approach described above, and I ran out of scope
  to repeat it a third time this pass.
- **"Templates plus variable fields"** (fuzzy/approximate matching within
  the LZ stage): the matcher does exact matching only. An earlier design
  pass sketched fuzzy matching (a match that tolerates a small literal "gap"
  before resuming), but the decoder-side offset arithmetic needed to get
  exactly right was a real correctness risk for a feature I judged to be a
  nice-to-have rather than core. Exact matching still handles the common
  case (identical repeated records) correctly and is what's tested.
- **Global dictionary vs. parallel compression**: these two spec
  requirements are in genuine tension - a dictionary that spans the whole
  file needs sequential construction, but compressing segments in parallel
  means they can't share state built as-you-go. This isn't a gap so much as
  an inherent trade-off (production parallel compressors like `pigz` and
  zstd's multithreaded mode make the same one). See "Streaming and large
  files" below for how this project resolves it.
- **Parallel decompression**: only compression is parallelized. The chunk
  format doesn't currently prefix each chunk with its own compressed byte
  length, so a reader can't skip ahead to start decoding chunk *N+1* without
  fully parsing chunk *N* first. Decompression is also the cheaper direction
  (~2x the throughput of compression in testing), so this was left
  sequential rather than adding untested framing changes late in the pass.
- **Sample datasets**: the spec asks to test against real APK/ROM/ISO/video
  formats. Rather than bundle real copyrighted proprietary files (which I
  wouldn't do regardless of licensing, and couldn't fetch without network
  access anyway), the app includes a synthetic dataset generator covering
  the same entropy/structure spectrum (text, JSON-like records, random/
  high-entropy, tabular binary, a real generated BMP, executable-like
  padding) - clearly labeled as synthetic - plus a system file picker for
  testing against your own real files of any format.

## Architecture

Single Gradle module (`app`), package-organized Clean Architecture rather
than multiple Gradle modules - deliberately, since I couldn't verify
multi-module Gradle wiring compiles without a working build environment, and
minimizing structural risk mattered more here than following the letter of
"modular" when package-level separation gets you the same maintainability.

```
core/              CompressionAlgorithm interface, BenchmarkMetrics model
algorithms/        Standard codec wrappers (Deflate, Bzip2, LZMA2/XZ, LZ4, Zstd, Snappy, Brotli)
novacompress/
  analyzer/        Stage 1: entropy calc, magic-byte sniffing, region classification
  segment/         Stage 2: adaptive segmentation (STORE vs NovaCompress-pipeline)
  matcher/         Stages 3 & 7: long-range LZ-style structural pattern matching
  predictor/        Stages 5 & 10: order-2 adaptive byte predictor (the "learning component")
  entropy/         Stage 9: range coder, Huffman coder, auto-selector
  format/          Container (de)serialization + aggregated research report
  NovaSegmentCodec.kt     Ties matcher + predictor + entropy coding together
  NovaCompressAlgorithm.kt Top-level orchestrator: chunking, parallelism, streaming
benchmark/         Runner, SHA-256 verification, memory/CPU profiling
data/              Room persistence (benchmark history)
dataset/           Synthetic sample file generator
di/                Manual DI container (see below)
ui/                Compose screens (Home, Results, Research, History), theme, charts
```

### Why manual DI instead of Hilt

Room already needs KSP for its annotation processing. Adding Hilt would mean
a second framework riding on the same exact-version-pairing surface
(Kotlin <-> KSP <-> Hilt), none of which I could verify resolves without a
working Gradle environment. A dependency graph this small (`AppContainer` in
`di/`) doesn't need a framework - everything already takes its dependencies
through constructors, so swapping in Hilt later is mechanical if you want it.

### NovaCompress pipeline, stage by stage

| Spec stage | Where it lives | Notes |
|---|---|---|
| 1. File Analyzer | `analyzer/FileAnalyzer.kt`, `RegionClassifier.kt` | Windowed entropy + printable/null ratios + magic-byte sniffing |
| 2. Adaptive Segmentation | `segment/Segmenter.kt` | Merges windows into STORE/NOVA runs |
| 3. Structural Pattern Detection | `matcher/LongRangeMatcher.kt` | Whole-chunk hash-table LZ matching |
| 4. Multi-Level Dictionary | `dictionary/MultiLevelDictionary.kt` | Repeat-offsets (micro) + chunk-scoped hash table (local/global) |
| 5. Predictive Encoder | `predictor/ContextPredictor.kt` | Order-2 adaptive byte prediction |
| 6. Graph-Based Pattern Compression | `format/NovaResearchReport.kt` | Analytics over matcher output - see "simplified" section above |
| 7. Long-Range Matching | `matcher/LongRangeMatcher.kt` | Same matcher as stage 3 - whole chunk, not a small window |
| 8. Parallel Compression | `NovaCompressAlgorithm.kt` | Chunks compressed concurrently via coroutines on `Dispatchers.Default` |
| 9. Entropy Encoder | `entropy/EntropyCoderSelector.kt` | Range coding vs. Huffman, smaller output kept |
| 10. Learning Component | `predictor/ContextPredictor.kt` | Same adaptive model as stage 5 - one mechanism serves both |

## Streaming and large files

Input is read in bounded 16MB chunks (`NovaCompressAlgorithm.CHUNK_SIZE`) -
never the whole file - so a 10GB+ file has roughly the same peak memory as a
16MB one. This is also what gives the "global" dictionary level real meaning
without an unbounded-memory whole-file pass: all NovaCompress-pipeline
content *within* one chunk shares a single dictionary and entropy-coded
stream, so for any file at or under the chunk size (most real files) the
dictionary genuinely spans the whole file. Larger files get that same full
reach *within* each chunk, with chunks processed in parallel across up to 4
CPU cores - the same trade-off `pigz` and zstd's multithreaded mode make.

I couldn't test this against an actual 10GB file in the sandbox (no such
file, and no room for one), so this is a reasoned/bounded-memory design
verified at smaller multi-chunk scale (the JUnit tests force >48MB inputs
across multiple chunks), not something empirically confirmed at the 10GB
scale the spec asks for.

## Performance expectations

Single-threaded reference numbers from the sandbox's JVM (not a phone, and
without JIT warmup considered): NovaCompress ran about 7 MB/s compressing
and 15 MB/s decompressing on a 4MB mixed text/random input. That's
meaningfully slower than mature codecs like Zstandard (hundreds of MB/s) -
expected and worth being upfront about. This is a research prototype
prioritizing structural analysis over raw speed; the benchmark screen will
show you real, measured numbers rather than anything asserted here. Random/
already-compressed input mildly *expands* under general-purpose compression
(confirmed in testing, ~1.02-1.08x) - which is why the segmenter routes
high-entropy regions to STORE instead.

## Building

1. Open in Android Studio (Otter or newer recommended) - it will offer to
   generate the Gradle wrapper jar automatically on first sync, since this
   project ships `gradle/wrapper/gradle-wrapper.properties` but not the
   binary jar itself (nothing in this sandbox could produce or verify one).
2. Or push to GitHub - `.github/workflows/android-build.yml` installs
   Gradle directly (via `gradle/actions/setup-gradle`) and doesn't need the
   wrapper jar at all. It runs the unit test suite, then assembles a debug
   APK, uploaded as a build artifact. See the workflow file for optional
   release-signing secrets.
3. Pinned dependency versions (`gradle/libs.versions.toml`) are real,
   released versions as of early 2026 training knowledge, but Android
   tooling moves fast and I couldn't verify exact resolution. If Gradle
   can't resolve an exact pin, bump it via Android Studio's upgrade
   assistant - nothing in the architecture depends on the exact numbers.

## Extending

Natural next passes, roughly in order of value:

1. **Run it, fix whatever Gradle/Kotlin syntax issues turn up** - this is
   the one category of bug the sandbox genuinely couldn't catch.
2. **Real Brotli encoder** - swap the `AlgorithmUnavailableException` in
   `BrotliAlgorithm.compress()` for a native encoder once you've picked one
   you trust for Android.
3. **rANS entropy coder** - add as a third option in
   `EntropyCoderSelector`, with the same round-trip-test-first approach used
   for the range coder in this pass.
4. **Fuzzy/template matching with variable fields** - the LZ matcher in
   `LongRangeMatcher.kt` is the place to extend; get the decoder-side offset
   arithmetic covered by tests before trusting it.
5. **Parallel decompression** - add a compressed-length prefix to each
   chunk in `NovaContainerFormat` so a reader can skip ahead without fully
   parsing.
6. More chart types (the spec asks for timeline charts and full compression
   history visualization beyond what `HistoryScreen` currently shows).
