@echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.\

if defined JAVA_HOME (
    set JAVA_EXE=%JAVA_HOME%\bin\java.exe
    if not exist "%JAVA_EXE%" (
        echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
        exit /b 1
    )
) else (
    where java.exe >nul 2>nul
    if errorlevel 1 (
        echo ERROR: JAVA_HOME is not set and no 'java' executable was found on PATH.
        exit /b 1
    )
    set JAVA_EXE=java.exe
)

set WRAPPER_JAR=%DIRNAME%gradle\wrapper\gradle-wrapper.jar
if not exist "%WRAPPER_JAR%" (
    echo ERROR: %WRAPPER_JAR% not found.
    echo Fetch the wrapper jar matching the version in
    echo gradle\wrapper\gradle-wrapper.properties, or run "gradle wrapper"
    echo with any local Gradle install to regenerate it.
    exit /b 1
)

"%JAVA_EXE%" -Dorg.gradle.appname=gradlew.bat -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*

endlocal
