# Native-backed compression libraries resolve classes/methods via JNI or
# reflection; keep them intact under R8/ProGuard minification.
-keep class com.github.luben.zstd.** { *; }
-keep class org.lz4.** { *; }
-keep class org.xerial.snappy.** { *; }
-keep class org.brotli.dec.** { *; }
-keep class org.tukaani.xz.** { *; }
-keep class org.apache.commons.compress.** { *; }
-dontwarn org.apache.commons.compress.**

# NovaCompress container/model classes are (de)serialized by field layout in
# places; keep field names stable for debuggability.
-keepclassmembers class com.novacompress.bench.novacompress.** { *; }
-keepclassmembers class com.novacompress.bench.data.db.** { *; }
