plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.novacompress.bench"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novacompress.bench"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }

        // zstd-jni and snappy-java both bundle native .so files for every
        // ABI; x86/x86_64 are emulator/desktop-only and never match a real
        // phone, so shipping them is pure dead weight. Dropping them is a
        // straight size win with no feature or device-compatibility loss.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            // commons-compress / xz / zstd-jni / lz4-java ship some duplicate
            // license/module metadata under META-INF - excluded defensively
            // so packaging doesn't fail on first build.
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/LICENSE"
            excludes += "META-INF/LICENSE.txt"
            excludes += "META-INF/NOTICE"
            excludes += "META-INF/NOTICE.txt"
            excludes += "META-INF/*.kotlin_module"
        }
    }
}

dependencies {
    implementation(libs.core.ktx)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.viewmodel.compose)
    implementation(libs.activity.compose)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.navigation.compose)
    implementation(libs.coroutines.android)
    implementation(libs.coroutines.core)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    // Standard algorithm backends - see README "Algorithm implementation notes"
    // for what's fully native-tested vs. defensively wrapped.
    implementation(libs.commons.compress) // Bzip2, XZ/LZMA2 (needs xz below)
    implementation(libs.xz)
    // zstd-jni's default jar targets desktop/server JVMs (natives keyed by
    // os/arch like linux/aarch64, built for glibc - not Android's Bionic
    // libc, and not in a layout AGP's packaging recognizes as ABI-specific
    // jniLibs). The @aar classifier is the same library published with
    // proper arm64-v8a/armeabi-v7a jniLibs so System.loadLibrary can
    // actually find them at runtime. See https://github.com/luben/zstd-jni.
    implementation("com.github.luben:zstd-jni:${libs.versions.zstdJni.get()}@aar")
    implementation(libs.lz4.java)
    implementation(libs.snappy.java)
    implementation(libs.brotli.dec) // decode only - see README

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
}
