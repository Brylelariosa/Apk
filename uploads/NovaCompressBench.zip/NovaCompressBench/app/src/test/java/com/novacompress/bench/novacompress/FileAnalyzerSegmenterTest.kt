package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.analyzer.EntropyCalculator
import com.novacompress.bench.novacompress.analyzer.FileAnalyzer
import com.novacompress.bench.novacompress.analyzer.RegionKind
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.novacompress.segment.Segmenter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class EntropyCalculatorTest {
    @Test fun constantDataHasZeroEntropy() {
        val data = ByteArray(1000) { 5 }
        assertEquals(0.0, EntropyCalculator.shannonEntropy(data), 0.0001)
    }

    @Test fun uniformRandomDataHasNearMaxEntropy() {
        val data = ByteArray(100000)
        Random(1).nextBytes(data)
        val entropy = EntropyCalculator.shannonEntropy(data)
        assertTrue("Expected near-8 bits/byte for random data, got $entropy", entropy > 7.9)
    }

    @Test fun textHasModerateEntropy() {
        val data = "the quick brown fox jumps over the lazy dog ".repeat(200).toByteArray()
        val entropy = EntropyCalculator.shannonEntropy(data)
        assertTrue("Expected moderate entropy for text, got $entropy", entropy in 3.0..5.5)
    }

    @Test fun emptyDataHasZeroEntropy() {
        assertEquals(0.0, EntropyCalculator.shannonEntropy(ByteArray(0)), 0.0001)
    }
}

class FileAnalyzerSegmenterTest {
    @Test fun classifiesHighEntropyDataForStore() {
        val data = ByteArray(200000)
        Random(2).nextBytes(data)
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)
        assertTrue(segments.isNotEmpty())
        assertTrue(
            "High-entropy random data should be routed to STORE",
            segments.all { it.strategy == SegmentStrategy.STORE },
        )
    }

    @Test fun classifiesTextForNovaPipeline() {
        val data = "the quick brown fox ".repeat(20000).toByteArray()
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)
        assertTrue(segments.isNotEmpty())
        assertTrue(
            "Repetitive text should be routed to the NovaCompress pipeline",
            segments.all { it.strategy == SegmentStrategy.NOVA },
        )
    }

    @Test fun segmentsCoverTheWholeBufferWithNoGapsOrOverlap() {
        val r = Random(3)
        val out = java.io.ByteArrayOutputStream()
        while (out.size() < 300000) {
            if (r.nextBoolean()) {
                val b = ByteArray(10000); r.nextBytes(b); out.write(b)
            } else {
                out.write("structured text content ".repeat(200).toByteArray())
            }
        }
        val data = out.toByteArray()
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)

        var expectedOffset = 0
        for (seg in segments) {
            assertEquals(expectedOffset, seg.offset)
            expectedOffset += seg.length
        }
        assertEquals(data.size, expectedOffset)
    }

    @Test fun pngMagicBytesDetected() {
        val pngHeader = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 1, 2, 3, 4, 5, 6, 7, 8)
        val data = pngHeader + ByteArray(1000)
        val regions = FileAnalyzer.analyze(data)
        assertEquals(RegionKind.IMAGE_LIKE, regions.first().kind)
    }
}
