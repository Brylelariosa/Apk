package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.entropy.MatchFieldCoder
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MatchFieldCoderTest {
    private val minMatch = 4

    /** [distanceValues] are written as-is; [rebasedLengthValues] simulate
     *  already-rebased (length - MIN_MATCH) values the way NovaSegmentCodec
     *  writes them, so the expected round-tripped length is value+minMatch.
     *  [distRepSlots] defaults to 0 (the original encoding, still what the
     *  length field always uses) - existing tests below pass it explicitly
     *  only where they mean to exercise the repeat-offset cache. */
    private fun roundTrip(
        distanceValues: IntArray,
        rebasedLengthValues: IntArray,
        distRepSlots: Int = 0,
    ): MatchFieldCoder.Fields {
        val distWriter = MatchFieldCoder.FieldWriter(repSlots = distRepSlots)
        for (v in distanceValues) distWriter.write(v)
        val lenWriter = MatchFieldCoder.FieldWriter()
        for (v in rebasedLengthValues) lenWriter.write(v)
        val packed = MatchFieldCoder.pack(distWriter, lenWriter)
        return MatchFieldCoder.unpack(packed, distanceValues.size, minMatch, distRepSlots = distRepSlots)
    }

    private fun expectedLengths(rebasedLengthValues: IntArray) = IntArray(rebasedLengthValues.size) { rebasedLengthValues[it] + minMatch }

    @Test fun empty() {
        val fields = roundTrip(IntArray(0), IntArray(0))
        assertArrayEquals(IntArray(0), fields.distances)
        assertArrayEquals(IntArray(0), fields.lengths)
    }

    @Test fun singleMatch() {
        val fields = roundTrip(intArrayOf(5), intArrayOf(0))
        assertArrayEquals(intArrayOf(5), fields.distances)
        assertArrayEquals(intArrayOf(4), fields.lengths)
    }

    @Test fun everySlotBoundaryValue() {
        // 0 and 1 are the two values with no extra bits at all (slot 0 and
        // slot 1); the rest step through slot boundaries (2^k and 2^k - 1)
        // where the extra-bits count changes, plus the Int.MAX_VALUE edge.
        val values = intArrayOf(
            0, 1, 2, 3, 4, 7, 8, 15, 16, 127, 128, 255, 256,
            65535, 65536, 1 shl 29, (1 shl 30) - 1, 1 shl 30,
            Int.MAX_VALUE / 2, Int.MAX_VALUE,
        )
        // distances can't be 0 in real data, but the coder itself makes no
        // such assumption - only the rebased-length side ever writes 0.
        val fields = roundTrip(values, values)
        assertArrayEquals(values, fields.distances)
        assertArrayEquals(expectedLengths(values), fields.lengths)
    }

    @Test fun manyRandomSmallValues() {
        val r = Random(1)
        val distances = IntArray(5000) { 1 + r.nextInt(1000) }
        val lengths = IntArray(5000) { r.nextInt(60) }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun manyRandomLargeValues() {
        val r = Random(2)
        val distances = IntArray(2000) { 1 + r.nextInt(Int.MAX_VALUE / 2) }
        val lengths = IntArray(2000) { r.nextInt(200_000) }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun repeatedIdenticalValues() {
        val distances = IntArray(10000) { 4 }
        val lengths = IntArray(10000) { 0 }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun allRebasedLengthsAtSlotZero() {
        // The common case in practice: most matches are exactly MIN_MATCH
        // long, i.e. rebased length 0, which should be the cheapest code.
        val r = Random(3)
        val distances = IntArray(3000) { 1 + r.nextInt(50000) }
        val lengths = IntArray(3000) { 0 }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun skewedDistributionFuzz() {
        val r = Random(4)
        repeat(20) {
            val count = 100 + r.nextInt(4000)
            // Power-law-ish spread so most values are small with a long tail,
            // similar in shape to real match distance distributions.
            val distances = IntArray(count) { 1 + (Math.pow(r.nextDouble(), 6.0) * 500_000).toInt() }
            val lengths = IntArray(count) { (Math.pow(r.nextDouble(), 4.0) * 500).toInt() }
            val fields = roundTrip(distances, lengths)
            assertArrayEquals(distances, fields.distances)
            assertArrayEquals(expectedLengths(lengths), fields.lengths)
        }
    }

    @Test fun concentratedDistancesCompressSmallerThanSpreadOutOnes() {
        // Behavioral sanity check, not just round-trip correctness: reusing
        // a handful of distances over and over (the repeat-offset-heavy
        // case this coder is meant to reward) should pack into meaningfully
        // fewer bytes than the same count of scattered, unique distances.
        val r = Random(5)
        val count = 8000
        val concentrated = IntArray(count) { intArrayOf(1, 2, 3, 4)[r.nextInt(4)] }
        val scattered = IntArray(count) { 1 + r.nextInt(1_000_000) }
        val lengths = IntArray(count) { 0 }

        val concentratedWriter = MatchFieldCoder.FieldWriter()
        for (v in concentrated) concentratedWriter.write(v)
        val lenWriter1 = MatchFieldCoder.FieldWriter()
        for (v in lengths) lenWriter1.write(v)
        val concentratedPacked = MatchFieldCoder.pack(concentratedWriter, lenWriter1)

        val scatteredWriter = MatchFieldCoder.FieldWriter()
        for (v in scattered) scatteredWriter.write(v)
        val lenWriter2 = MatchFieldCoder.FieldWriter()
        for (v in lengths) lenWriter2.write(v)
        val scatteredPacked = MatchFieldCoder.pack(scatteredWriter, lenWriter2)

        assertTrue(
            "Concentrated distances (${concentratedPacked.size}B) should pack " +
                "smaller than scattered ones (${scatteredPacked.size}B)",
            concentratedPacked.size < scatteredPacked.size,
        )
    }

    // --- repeat-offset MRU cache (DIST_REPEAT_SLOTS) -----------------------

    @Test fun repeatCacheRoundTripsCorrectly() {
        val r = Random(6)
        // A handful of "hot" distances interleaved with occasional fresh
        // ones, similar in shape to periodic/structured data: mostly the
        // same offset reused, sometimes something new.
        val hot = intArrayOf(24, 6144, 96)
        val distances = IntArray(4000) {
            if (r.nextInt(5) == 0) 1 + r.nextInt(1_000_000) else hot[r.nextInt(hot.size)]
        }
        val lengths = IntArray(4000) { r.nextInt(40) }
        val fields = roundTrip(distances, lengths, distRepSlots = MatchFieldCoder.DIST_REPEAT_SLOTS)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun repeatCacheHandlesFewerUniqueValuesThanSlots() {
        // Only 2 distinct distances ever appear, well under DIST_REPEAT_SLOTS
        // (4) - exercises the cache's initial seed values never colliding
        // with real data by chance.
        val distances = IntArray(500) { if (it % 7 == 0) 10 else 20 }
        val lengths = IntArray(500) { 0 }
        val fields = roundTrip(distances, lengths, distRepSlots = MatchFieldCoder.DIST_REPEAT_SLOTS)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun repeatCacheEmptyAndSingleValue() {
        assertArrayEquals(IntArray(0), roundTrip(IntArray(0), IntArray(0), distRepSlots = 4).distances)
        val one = roundTrip(intArrayOf(6144), intArrayOf(0), distRepSlots = 4)
        assertArrayEquals(intArrayOf(6144), one.distances)
    }

    @Test fun repeatCacheShrinksRecurringDistanceVersusBaseline() {
        // The exact failure mode this change fixes: the same distance
        // recurring many times (e.g. one match per fixed-width record,
        // always referencing the same stride back) should collapse toward
        // "free" with the cache on, where the original encoding paid full
        // slot-plus-extra-bits price every single time.
        val distances = IntArray(6000) { 6144 }
        val lengths = IntArray(6000) { 0 }

        val baseline = roundTrip(distances, lengths, distRepSlots = 0)
        val withCache = roundTrip(distances, lengths, distRepSlots = MatchFieldCoder.DIST_REPEAT_SLOTS)
        assertArrayEquals(distances, baseline.distances)
        assertArrayEquals(distances, withCache.distances)

        val baseWriter = MatchFieldCoder.FieldWriter()
        for (v in distances) baseWriter.write(v)
        val baseLenWriter = MatchFieldCoder.FieldWriter()
        for (v in lengths) baseLenWriter.write(v)
        val basePacked = MatchFieldCoder.pack(baseWriter, baseLenWriter)

        val cacheWriter = MatchFieldCoder.FieldWriter(repSlots = MatchFieldCoder.DIST_REPEAT_SLOTS)
        for (v in distances) cacheWriter.write(v)
        val cacheLenWriter = MatchFieldCoder.FieldWriter()
        for (v in lengths) cacheLenWriter.write(v)
        val cachePacked = MatchFieldCoder.pack(cacheWriter, cacheLenWriter)

        assertTrue(
            "Repeat-offset cache (${cachePacked.size}B) should pack a constantly-" +
                "recurring distance far smaller than the baseline encoding (${basePacked.size}B)",
            cachePacked.size < basePacked.size / 2,
        )
    }
}
