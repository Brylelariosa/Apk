package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.entropy.MatchFieldCoder
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MatchFieldCoderTest {
    private val minMatch = 4

    /** [distanceValues] are written as-is; [rebasedLengthValues] simulate
     *  already-rebased (length - MIN_MATCH) values the way NovaSegmentCodec
     *  writes them, so the expected round-tripped length is value+minMatch. */
    private fun roundTrip(distanceValues: IntArray, rebasedLengthValues: IntArray): MatchFieldCoder.Fields {
        val distWriter = MatchFieldCoder.FieldWriter()
        for (v in distanceValues) distWriter.write(v)
        val lenWriter = MatchFieldCoder.FieldWriter()
        for (v in rebasedLengthValues) lenWriter.write(v)
        val packed = MatchFieldCoder.pack(distWriter, lenWriter)
        return MatchFieldCoder.unpack(packed, distanceValues.size, minMatch)
    }

    private fun expectedLengths(rebasedLengthValues: IntArray) = IntArray(rebasedLengthValues.size) { rebasedLengthValues[it] + minMatch }

    @Test fun empty() {
        val fields = roundTrip(IntArray(0), IntArray(0))
        assertArrayEquals(IntArray(0), fields.distances)
        assertArrayEquals(IntArray(0), fields.lengths)
    }

    @Test fun singleMatch() {
        val fields = roundTrip(intArrayOf(5), intArrayOf(0))
        assertArrayEquals(intArrayOf(5), fields.distances)
        assertArrayEquals(intArrayOf(4), fields.lengths)
    }

    @Test fun everySlotBoundaryValue() {
        // 0 and 1 are the two values with no extra bits at all (slot 0 and
        // slot 1); the rest step through slot boundaries (2^k and 2^k - 1)
        // where the extra-bits count changes, plus the Int.MAX_VALUE edge.
        val values = intArrayOf(
            0, 1, 2, 3, 4, 7, 8, 15, 16, 127, 128, 255, 256,
            65535, 65536, 1 shl 29, (1 shl 30) - 1, 1 shl 30,
            Int.MAX_VALUE / 2, Int.MAX_VALUE,
        )
        // distances can't be 0 in real data, but the coder itself makes no
        // such assumption - only the rebased-length side ever writes 0.
        val fields = roundTrip(values, values)
        assertArrayEquals(values, fields.distances)
        assertArrayEquals(expectedLengths(values), fields.lengths)
    }

    @Test fun manyRandomSmallValues() {
        val r = Random(1)
        val distances = IntArray(5000) { 1 + r.nextInt(1000) }
        val lengths = IntArray(5000) { r.nextInt(60) }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun manyRandomLargeValues() {
        val r = Random(2)
        val distances = IntArray(2000) { 1 + r.nextInt(Int.MAX_VALUE / 2) }
        val lengths = IntArray(2000) { r.nextInt(200_000) }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun repeatedIdenticalValues() {
        val distances = IntArray(10000) { 4 }
        val lengths = IntArray(10000) { 0 }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun allRebasedLengthsAtSlotZero() {
        // The common case in practice: most matches are exactly MIN_MATCH
        // long, i.e. rebased length 0, which should be the cheapest code.
        val r = Random(3)
        val distances = IntArray(3000) { 1 + r.nextInt(50000) }
        val lengths = IntArray(3000) { 0 }
        val fields = roundTrip(distances, lengths)
        assertArrayEquals(distances, fields.distances)
        assertArrayEquals(expectedLengths(lengths), fields.lengths)
    }

    @Test fun skewedDistributionFuzz() {
        val r = Random(4)
        repeat(20) {
            val count = 100 + r.nextInt(4000)
            // Power-law-ish spread so most values are small with a long tail,
            // similar in shape to real match distance distributions.
            val distances = IntArray(count) { 1 + (Math.pow(r.nextDouble(), 6.0) * 500_000).toInt() }
            val lengths = IntArray(count) { (Math.pow(r.nextDouble(), 4.0) * 500).toInt() }
            val fields = roundTrip(distances, lengths)
            assertArrayEquals(distances, fields.distances)
            assertArrayEquals(expectedLengths(lengths), fields.lengths)
        }
    }

    @Test fun concentratedDistancesCompressSmallerThanSpreadOutOnes() {
        // Behavioral sanity check, not just round-trip correctness: reusing
        // a handful of distances over and over (the repeat-offset-heavy
        // case this coder is meant to reward) should pack into meaningfully
        // fewer bytes than the same count of scattered, unique distances.
        val r = Random(5)
        val count = 8000
        val concentrated = IntArray(count) { intArrayOf(1, 2, 3, 4)[r.nextInt(4)] }
        val scattered = IntArray(count) { 1 + r.nextInt(1_000_000) }
        val lengths = IntArray(count) { 0 }

        val concentratedWriter = MatchFieldCoder.FieldWriter()
        for (v in concentrated) concentratedWriter.write(v)
        val lenWriter1 = MatchFieldCoder.FieldWriter()
        for (v in lengths) lenWriter1.write(v)
        val concentratedPacked = MatchFieldCoder.pack(concentratedWriter, lenWriter1)

        val scatteredWriter = MatchFieldCoder.FieldWriter()
        for (v in scattered) scatteredWriter.write(v)
        val lenWriter2 = MatchFieldCoder.FieldWriter()
        for (v in lengths) lenWriter2.write(v)
        val scatteredPacked = MatchFieldCoder.pack(scatteredWriter, lenWriter2)

        assertTrue(
            "Concentrated distances (${concentratedPacked.size}B) should pack " +
                "smaller than scattered ones (${scatteredPacked.size}B)",
            concentratedPacked.size < scatteredPacked.size,
        )
    }
}
