package com.novacompress.bench.algorithms

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.random.Random

class DeflateAlgorithmTest {
    @Test fun roundTripsRandomData() {
        val data = ByteArray(20000)
        Random(1).nextBytes(data)
        val algo = DeflateAlgorithm()

        val compressed = ByteArrayOutputStream()
        algo.compress(ByteArrayInputStream(data), compressed)
        val decompressed = ByteArrayOutputStream()
        algo.decompress(ByteArrayInputStream(compressed.toByteArray()), decompressed)

        assertArrayEquals(data, decompressed.toByteArray())
    }

    @Test fun compressesRepetitiveDataWell() {
        val data = "a".repeat(100000).toByteArray()
        val algo = DeflateAlgorithm()
        val compressed = ByteArrayOutputStream()
        algo.compress(ByteArrayInputStream(data), compressed)
        assertTrue(compressed.size() < data.size / 10)
    }

    @Test fun isAlwaysAvailable() {
        assertTrue(DeflateAlgorithm().isAvailable())
    }
}

class AlgorithmRegistryTest {
    @Test fun everyAlgorithmHasAUniqueId() {
        val ids = AlgorithmRegistry.all().map { it.id }
        assertTrue(ids.size == ids.toSet().size)
    }

    @Test fun novaCompressIsExperimentalAndEverythingElseIsStandard() {
        val all = AlgorithmRegistry.all()
        val experimental = all.filter { it.category == com.novacompress.bench.core.AlgorithmCategory.EXPERIMENTAL }
        assertTrue(experimental.size == 1)
        assertTrue(experimental.first().id == "novacompress")
    }

    @Test fun byIdFindsRegisteredAlgorithms() {
        assertTrue(AlgorithmRegistry.byId("deflate") != null)
        assertTrue(AlgorithmRegistry.byId("nonexistent_algorithm_id") == null)
    }
}
