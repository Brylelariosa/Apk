package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.entropy.EntropyCoderSelector
import com.novacompress.bench.novacompress.entropy.HuffmanCoder
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class HuffmanCoderTest {
    @Test fun buildAndRoundTripSkewed() {
        val r = Random(1)
        val symbols = IntArray(5000) {
            val u = r.nextDouble()
            (258 * Math.pow(u, 5.0)).toInt().coerceAtMost(257)
        }
        val counts = IntArray(258)
        for (s in symbols) counts[s]++
        val table = HuffmanCoder.build(counts)
        assertNotNull(table)
        val encoded = HuffmanCoder.encode(symbols, table!!)
        val decoded = HuffmanCoder.decode(encoded, table, symbols.size)
        assertArrayEquals(symbols, decoded)
    }

    @Test fun singleDistinctSymbol() {
        val symbols = IntArray(300) { 9 }
        val counts = IntArray(258)
        for (s in symbols) counts[s]++
        val table = HuffmanCoder.build(counts)!!
        val encoded = HuffmanCoder.encode(symbols, table)
        val decoded = HuffmanCoder.decode(encoded, table, symbols.size)
        assertArrayEquals(symbols, decoded)
    }

    @Test fun emptyInput() {
        val counts = IntArray(258)
        val table = HuffmanCoder.build(counts)!!
        val encoded = HuffmanCoder.encode(IntArray(0), table)
        val decoded = HuffmanCoder.decode(encoded, table, 0)
        assertArrayEquals(IntArray(0), decoded)
    }
}

class EntropyCoderSelectorTest {
    private fun roundTrip(symbols: IntArray, alphabet: Int = 258): IntArray {
        val encoded = EntropyCoderSelector.encode(symbols, alphabet)
        return EntropyCoderSelector.decode(encoded, symbols.size, alphabet)
    }

    @Test fun lowEntropyFavorsHuffmanAndStillRoundTrips() {
        // Slowly varying values that rarely repeat exactly (defeats LZ
        // matching upstream) but have low byte-value entropy - constructed
        // specifically to make Huffman competitive with/better than range
        // coding, exercising the selector's comparison logic both ways.
        val r = Random(42)
        var v = 0
        val symbols = IntArray(20000) {
            v += r.nextInt(3) - 1
            v = v.coerceIn(0, 15)
            v
        }
        assertArrayEquals(symbols, roundTrip(symbols))
    }

    @Test fun uniformRandomRoundTrips() {
        val r = Random(7)
        val symbols = IntArray(8000) { r.nextInt(258) }
        assertArrayEquals(symbols, roundTrip(symbols))
    }

    @Test fun emptyRoundTrips() {
        assertArrayEquals(IntArray(0), roundTrip(IntArray(0)))
    }

    @Test fun selectorPicksSmallerOutput() {
        // Extremely skewed distribution: Huffman should be able to compete
        // here. We don't assert *which* coder wins (that's an implementation
        // detail), only that the result round-trips correctly either way.
        val symbols = IntArray(10000) { if (it % 100 == 0) 200 else 1 }
        val decoded = roundTrip(symbols)
        assertArrayEquals(symbols, decoded)
    }
}
