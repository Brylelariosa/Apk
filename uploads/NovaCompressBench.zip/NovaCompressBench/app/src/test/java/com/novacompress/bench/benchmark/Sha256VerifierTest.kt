package com.novacompress.bench.benchmark

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import kotlin.random.Random

class Sha256VerifierTest {
    @Test fun identicalDataHashesEqual() {
        val data = ByteArray(10000)
        Random(1).nextBytes(data)
        val h1 = Sha256Verifier.hash(ByteArrayInputStream(data))
        val h2 = Sha256Verifier.hash(ByteArrayInputStream(data.copyOf()))
        assertTrue(Sha256Verifier.hashesEqual(h1, h2))
    }

    @Test fun differentDataHashesDiffer() {
        val a = ByteArray(10000); Random(1).nextBytes(a)
        val b = a.copyOf(); b[5000] = (b[5000] + 1).toByte()
        val h1 = Sha256Verifier.hash(ByteArrayInputStream(a))
        val h2 = Sha256Verifier.hash(ByteArrayInputStream(b))
        assertFalse(Sha256Verifier.hashesEqual(h1, h2))
    }

    @Test fun emptyStreamHashesConsistently() {
        val h1 = Sha256Verifier.hash(ByteArrayInputStream(ByteArray(0)))
        val h2 = Sha256Verifier.hash(ByteArrayInputStream(ByteArray(0)))
        assertTrue(Sha256Verifier.hashesEqual(h1, h2))
        // Known SHA-256 of the empty input.
        assertTrue(Sha256Verifier.toHex(h1) == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
    }
}
