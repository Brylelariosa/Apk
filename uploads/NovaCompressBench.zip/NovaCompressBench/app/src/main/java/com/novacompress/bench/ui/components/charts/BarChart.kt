package com.novacompress.bench.ui.components.charts

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

data class BarChartEntry(
    val label: String,
    val value: Float,
    val color: Color,
    val valueText: String,
)

@Composable
fun BarChart(entries: List<BarChartEntry>, modifier: Modifier = Modifier) {
    val maxValue = (entries.maxOfOrNull { it.value } ?: 0f).coerceAtLeast(0.0001f)
    Column(modifier = modifier) {
        entries.forEach { entry ->
            BarRow(entry, maxValue)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun BarRow(entry: BarChartEntry, maxValue: Float) {
    val fraction by animateFloatAsState(
        targetValue = (entry.value / maxValue).coerceIn(0f, 1f),
        animationSpec = tween(400),
        label = "bar",
    )
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
            Text(
                entry.label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            Spacer(Modifier.width(8.dp))
            Text(entry.valueText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(5.dp)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction.coerceIn(0.02f, 1f))
                    .height(10.dp)
                    .background(entry.color, RoundedCornerShape(5.dp))
                    .align(Alignment.CenterStart),
            )
        }
    }
}
