package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import java.io.InputStream
import java.io.OutputStream

/** XZ container around LZMA2 - the format requested as "LZMA2 / XZ". */
class Lzma2Algorithm : CompressionAlgorithm {
    override val id = "lzma2_xz"
    override val displayName = "LZMA2 / XZ"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable() = true

    override fun compress(input: InputStream, output: OutputStream) {
        XZCompressorOutputStream(output, 6).use { xos ->
            IoUtil.copyStream(input, xos)
        }
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        XZCompressorInputStream(input).use { xis ->
            IoUtil.copyStream(xis, output)
        }
    }
}
