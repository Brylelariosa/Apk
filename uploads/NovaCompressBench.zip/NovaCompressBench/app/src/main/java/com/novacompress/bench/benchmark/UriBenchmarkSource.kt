package com.novacompress.bench.benchmark

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.IOException
import java.io.InputStream

class UriBenchmarkSource(
    private val context: Context,
    private val uri: Uri,
) : BenchmarkSource {
    override val displayName: String = queryDisplayName()
    override val sizeBytes: Long = querySize()

    override fun openStream(): InputStream =
        context.contentResolver.openInputStream(uri) ?: throw IOException("Could not open $uri")

    private fun queryDisplayName(): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx) ?: fallbackName()
        }
        return fallbackName()
    }

    private fun querySize(): Long {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (idx >= 0 && cursor.moveToFirst() && !cursor.isNull(idx)) return cursor.getLong(idx)
        }
        return -1L
    }

    private fun fallbackName() = uri.lastPathSegment ?: "file"
}
