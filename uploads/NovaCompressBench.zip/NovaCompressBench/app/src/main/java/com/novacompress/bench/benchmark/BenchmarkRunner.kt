package com.novacompress.bench.benchmark

import com.novacompress.bench.core.AlgorithmUnavailableException
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.VerificationResult
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Runs one or more [CompressionAlgorithm]s against a [BenchmarkSource],
 * producing [BenchmarkMetrics] for each. Every requested metric from the
 * spec is a real measurement: wall-clock time via [System.nanoTime],
 * thread CPU time via [MemoryProfiler.currentThreadCpuTimeMs] (distinct
 * from wall time - shows scheduling/IO wait vs. actual compute), heap
 * delta via [MemoryProfiler.measureMemoryDelta], and correctness via
 * [Sha256Verifier].
 *
 * One algorithm failing (unavailable native library, unimplemented
 * direction like Brotli encode, or any other exception) produces a single
 * FAIL/UNAVAILABLE row with the reason attached - it never aborts the rest
 * of the batch.
 */
class BenchmarkRunner(private val cacheDir: File) {

    fun runAll(source: BenchmarkSource, algorithms: List<CompressionAlgorithm>): List<BenchmarkMetrics> =
        algorithms.map { runOne(source, it) }

    fun runOne(source: BenchmarkSource, algorithm: CompressionAlgorithm): BenchmarkMetrics {
        val now = System.currentTimeMillis()

        if (!algorithm.isAvailable()) {
            return BenchmarkMetrics(
                algorithmId = algorithm.id,
                algorithmName = algorithm.displayName,
                category = algorithm.category,
                sourceFileName = source.displayName,
                originalSizeBytes = source.sizeBytes,
                compressedSizeBytes = 0,
                compressionTimeMs = 0,
                decompressionTimeMs = 0,
                compressionCpuTimeMs = 0,
                decompressionCpuTimeMs = 0,
                peakMemoryDeltaBytes = 0,
                verified = VerificationResult.UNAVAILABLE,
                timestampEpochMs = now,
                failureReason = "Not available on this device/build",
            )
        }

        val compressedFile = File.createTempFile("bench_c_", ".bin", cacheDir)
        val decompressedFile = File.createTempFile("bench_d_", ".bin", cacheDir)
        try {
            val cpuBeforeCompress = MemoryProfiler.currentThreadCpuTimeMs()
            val compressStartNs = System.nanoTime()
            val (_, compressMemDelta) = MemoryProfiler.measureMemoryDelta {
                source.openStream().use { input ->
                    FileOutputStream(compressedFile).use { output ->
                        algorithm.compress(input, output)
                    }
                }
            }
            val compressMs = (System.nanoTime() - compressStartNs) / 1_000_000L
            val compressCpuMs = MemoryProfiler.currentThreadCpuTimeMs() - cpuBeforeCompress

            val cpuBeforeDecompress = MemoryProfiler.currentThreadCpuTimeMs()
            val decompressStartNs = System.nanoTime()
            FileInputStream(compressedFile).use { input ->
                FileOutputStream(decompressedFile).use { output ->
                    algorithm.decompress(input, output)
                }
            }
            val decompressMs = (System.nanoTime() - decompressStartNs) / 1_000_000L
            val decompressCpuMs = MemoryProfiler.currentThreadCpuTimeMs() - cpuBeforeDecompress

            val originalHash = source.openStream().use { Sha256Verifier.hash(it) }
            val decompressedHash = FileInputStream(decompressedFile).use { Sha256Verifier.hash(it) }
            val verified = if (Sha256Verifier.hashesEqual(originalHash, decompressedHash)) {
                VerificationResult.PASS
            } else {
                VerificationResult.FAIL
            }

            return BenchmarkMetrics(
                algorithmId = algorithm.id,
                algorithmName = algorithm.displayName,
                category = algorithm.category,
                sourceFileName = source.displayName,
                originalSizeBytes = source.sizeBytes,
                compressedSizeBytes = compressedFile.length(),
                compressionTimeMs = compressMs,
                decompressionTimeMs = decompressMs,
                compressionCpuTimeMs = compressCpuMs,
                decompressionCpuTimeMs = decompressCpuMs,
                peakMemoryDeltaBytes = compressMemDelta,
                verified = verified,
                timestampEpochMs = now,
                failureReason = if (verified == VerificationResult.FAIL) "Decompressed output did not match original (SHA-256 mismatch)" else null,
            )
        } catch (e: AlgorithmUnavailableException) {
            return failureMetrics(algorithm, source, now, VerificationResult.UNAVAILABLE, e.message ?: "Unavailable")
        } catch (e: Exception) {
            return failureMetrics(algorithm, source, now, VerificationResult.FAIL, e.message ?: e.toString())
        } finally {
            compressedFile.delete()
            decompressedFile.delete()
        }
    }

    private fun failureMetrics(
        algorithm: CompressionAlgorithm,
        source: BenchmarkSource,
        timestamp: Long,
        result: VerificationResult,
        reason: String,
    ) = BenchmarkMetrics(
        algorithmId = algorithm.id,
        algorithmName = algorithm.displayName,
        category = algorithm.category,
        sourceFileName = source.displayName,
        originalSizeBytes = source.sizeBytes,
        compressedSizeBytes = 0,
        compressionTimeMs = 0,
        decompressionTimeMs = 0,
        compressionCpuTimeMs = 0,
        decompressionCpuTimeMs = 0,
        peakMemoryDeltaBytes = 0,
        verified = result,
        timestampEpochMs = timestamp,
        failureReason = reason,
    )
}
