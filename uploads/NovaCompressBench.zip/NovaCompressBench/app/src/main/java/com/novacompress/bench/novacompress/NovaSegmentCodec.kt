package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.dictionary.Varint
import com.novacompress.bench.novacompress.entropy.EntropyCoderSelector
import com.novacompress.bench.novacompress.matcher.LongRangeMatcher
import com.novacompress.bench.novacompress.matcher.Token
import com.novacompress.bench.novacompress.predictor.ContextPredictor
import java.io.ByteArrayOutputStream

/**
 * Result of encoding one buffer. [tokenCount]/[matchTokenCount]/[predictHitCount]
 * are pure by-products of the encode pass, kept for Research Mode reporting
 * (detected-structure counts, prediction accuracy) rather than recomputed
 * separately.
 */
data class NovaEncodedBlock(
    val symbolCount: Int,
    val entropyBytes: ByteArray,
    val sideChannelBytes: ByteArray,
    val tokenCount: Int,
    val matchTokenCount: Int,
    val predictHitCount: Int,
)

/**
 * Encodes/decodes ONE contiguous buffer (a segment, or several segments
 * concatenated - see [NovaCompressAlgorithm] for why buffer size varies
 * between sequential and parallel mode) through the full pipeline:
 * long-range matching -> order-2 prediction -> entropy coding.
 *
 * Verified via 30 end-to-end round-trip tests (edge cases, random/skewed/
 * repetitive/JSON-like/fuzzed data, and a case specifically constructed to
 * make Huffman beat the range coder) before being ported into this
 * codebase - see README "Verification".
 *
 * The critical correctness invariant: [ContextPredictor] must be updated
 * with *every* reconstructed byte - literal misses, prediction hits, AND
 * every byte a match token copies - so encoder and decoder stay in
 * lockstep. This is the one thing to be most careful about if this file is
 * ever modified; NovaSegmentCodecTest exists specifically to catch a
 * regression here.
 */
object NovaSegmentCodec {
    const val SYM_MATCH = 256
    const val SYM_PREDICT_HIT = 257
    const val ALPHABET = 258

    fun encode(data: ByteArray): NovaEncodedBlock {
        val tokens = LongRangeMatcher.tokenize(data)
        val predictor = ContextPredictor()
        val symbols = ArrayList<Int>(data.size / 2 + 8)
        val side = ByteArrayOutputStream()

        var prevPrev = 0
        var prev = 0
        var pos = 0
        var matchCount = 0
        var hitCount = 0

        for (t in tokens) {
            when (t) {
                is Token.Literal -> {
                    val b = t.byte
                    val predicted = predictor.predict(prevPrev, prev)
                    if (predicted == b) {
                        symbols.add(SYM_PREDICT_HIT)
                        hitCount++
                    } else {
                        symbols.add(b.toInt() and 0xFF)
                    }
                    predictor.update(prevPrev, prev, b)
                    prevPrev = prev
                    prev = b.toInt() and 0xFF
                    pos++
                }
                is Token.Match -> {
                    symbols.add(SYM_MATCH)
                    matchCount++
                    Varint.write(side, t.distance)
                    Varint.write(side, t.length)
                    for (k in 0 until t.length) {
                        val b = data[pos + k]
                        predictor.update(prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                    }
                    pos += t.length
                }
            }
        }

        val symbolArray = symbols.toIntArray()
        val entropyBytes = EntropyCoderSelector.encode(symbolArray, ALPHABET)
        return NovaEncodedBlock(
            symbolCount = symbolArray.size,
            entropyBytes = entropyBytes,
            sideChannelBytes = side.toByteArray(),
            tokenCount = tokens.size,
            matchTokenCount = matchCount,
            predictHitCount = hitCount,
        )
    }

    fun decode(block: NovaEncodedBlock, originalLength: Int): ByteArray {
        val symbols = EntropyCoderSelector.decode(block.entropyBytes, block.symbolCount, ALPHABET)
        val output = ByteArray(originalLength)
        val predictor = ContextPredictor()
        val sidePos = intArrayOf(0)

        var prevPrev = 0
        var prev = 0
        var pos = 0

        for (sym in symbols) {
            when (sym) {
                SYM_PREDICT_HIT -> {
                    val b = predictor.predict(prevPrev, prev)
                    output[pos] = b
                    predictor.update(prevPrev, prev, b)
                    prevPrev = prev
                    prev = b.toInt() and 0xFF
                    pos++
                }
                SYM_MATCH -> {
                    val dist = Varint.read(block.sideChannelBytes, sidePos)
                    val len = Varint.read(block.sideChannelBytes, sidePos)
                    for (k in 0 until len) {
                        val b = output[pos - dist]
                        output[pos] = b
                        predictor.update(prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                        pos++
                    }
                }
                else -> {
                    val b = sym.toByte()
                    output[pos] = b
                    predictor.update(prevPrev, prev, b)
                    prevPrev = prev
                    prev = b.toInt() and 0xFF
                    pos++
                }
            }
        }
        return output
    }
}
