package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Encodes the non-negative integers that make up a match token's distance
 * and length - previously written as raw 7-bit varint bytes with no entropy
 * coding at all, which measured out to over 99% of NovaCompress's total
 * output on repetitive text (33798 matches on a 256KB file, ~2.4 raw
 * side-channel bytes each, while the entropy-coded symbol stream carrying
 * *which* token type each of those was cost under 250 bytes total - the
 * "which" was well compressed, the "how much"/"how far" never was).
 *
 * Each value is split into a slot (its bit-length, so ~13 distinct values
 * cover the full 32-bit range) and the extra bits needed to pick the exact
 * value within that slot's range - the same technique DEFLATE and LZMA use
 * for their length/distance codes. The slot is entropy-coded through
 * [EntropyCoderSelector] (adaptive, so a file that reuses a handful of
 * distances heavily - the common case, since [MultiLevelDictionary]'s
 * repeat-offset list already biases the matcher toward recent distances -
 * gets those slots for close to free); the extra bits are close to
 * uniformly distributed within a slot, so writing them raw costs no more
 * than an ideal coder would spend on them anyway, without paying for the
 * modeling overhead of trying to compress raw noise.
 */
object MatchFieldCoder {
    // Bit-lengths 0..32 cover every non-negative Int, including 0 itself
    // (rebased match lengths can be exactly 0 when length == MIN_MATCH).
    private const val SLOT_ALPHABET = 33

    private fun slotOf(value: Int): Int = 32 - Integer.numberOfLeadingZeros(value)
    private fun extraBitsFor(slot: Int): Int = maxOf(0, slot - 1)

    /** Accumulates one field's worth of values (all distances, or all
     *  rebased lengths, for one NOVA block) as they're discovered during
     *  the single left-to-right token pass NovaSegmentCodec already makes. */
    class FieldWriter {
        private val slots = ArrayList<Int>()
        private val extra = BitWriter()

        fun write(value: Int) {
            val slot = slotOf(value)
            slots.add(slot)
            val extraBits = extraBitsFor(slot)
            if (extraBits > 0) {
                extra.writeBits((value - (1 shl extraBits)).toLong(), extraBits)
            }
        }

        fun slotArray(): IntArray = slots.toIntArray()
        fun extraBytes(): ByteArray = extra.finish()
    }

    /** The decoded distance/length pairs for every match in a block, in the
     *  same left-to-right order they were written. */
    class Fields(val distances: IntArray, val lengths: IntArray)

    fun pack(distances: FieldWriter, lengths: FieldWriter): ByteArray {
        val distEntropy = EntropyCoderSelector.encode(distances.slotArray(), SLOT_ALPHABET)
        val distExtra = distances.extraBytes()
        val lenEntropy = EntropyCoderSelector.encode(lengths.slotArray(), SLOT_ALPHABET)
        val lenExtra = lengths.extraBytes()

        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            d.writeInt(distEntropy.size); d.write(distEntropy)
            d.writeInt(distExtra.size); d.write(distExtra)
            d.writeInt(lenEntropy.size); d.write(lenEntropy)
            d.writeInt(lenExtra.size); d.write(lenExtra)
        }
        return out.toByteArray()
    }

    /** [minMatch] is added back to every decoded length, undoing the
     *  rebasing the writer side applies (see NovaSegmentCodec) so that slot
     *  0 - the cheapest possible code - lines up with the most common
     *  length (exactly MIN_MATCH) rather than being wasted on a length that
     *  can never occur. */
    fun unpack(bytes: ByteArray, matchCount: Int, minMatch: Int): Fields {
        val din = DataInputStream(ByteArrayInputStream(bytes))
        val distEntropy = ByteArray(din.readInt()).also { din.readFully(it) }
        val distExtra = ByteArray(din.readInt()).also { din.readFully(it) }
        val lenEntropy = ByteArray(din.readInt()).also { din.readFully(it) }
        val lenExtra = ByteArray(din.readInt()).also { din.readFully(it) }

        val distSlots = EntropyCoderSelector.decode(distEntropy, matchCount, SLOT_ALPHABET)
        val lenSlots = EntropyCoderSelector.decode(lenEntropy, matchCount, SLOT_ALPHABET)
        val distReader = BitReader(distExtra)
        val lenReader = BitReader(lenExtra)

        // Explicit loops rather than IntArray(n) { ... } - both readers are
        // stateful (each read advances the bit cursor), so evaluation order
        // must be left-to-right, and this makes that requirement obvious at
        // the call site instead of resting on the array constructor's
        // (correct, but implicit) sequential-evaluation guarantee.
        val distances = IntArray(matchCount)
        for (i in 0 until matchCount) distances[i] = readValue(distSlots[i], distReader)
        val lengths = IntArray(matchCount)
        for (i in 0 until matchCount) lengths[i] = readValue(lenSlots[i], lenReader) + minMatch

        return Fields(distances, lengths)
    }

    private fun readValue(slot: Int, reader: BitReader): Int {
        val extraBits = extraBitsFor(slot)
        if (extraBits == 0) return if (slot == 0) 0 else 1
        return (1 shl extraBits) + reader.readBits(extraBits).toInt()
    }
}
