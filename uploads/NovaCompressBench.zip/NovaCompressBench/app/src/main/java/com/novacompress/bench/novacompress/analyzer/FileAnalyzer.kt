package com.novacompress.bench.novacompress.analyzer

data class Region(
    val offset: Int,
    val length: Int,
    val kind: RegionKind,
    val stats: RegionStats,
)

/**
 * Stage 1 of the pipeline ("File Analyzer" in the spec): scans a buffer in
 * fixed windows, classifying each one, and sniffs known file-format magic
 * bytes at the very start. The result is a "file structure map" that
 * [com.novacompress.bench.novacompress.segment.Segmenter] merges into
 * variable-length segments.
 *
 * Windowed rather than whole-buffer so mixed files (e.g. an APK containing
 * both compressed entries and a bit of manifest text) get a structure map
 * that actually reflects the mix, not one average classification.
 */
object FileAnalyzer {
    const val WINDOW_SIZE = 64 * 1024

    fun analyze(data: ByteArray): List<Region> {
        if (data.isEmpty()) return emptyList()
        val regions = ArrayList<Region>()
        val magic = RegionClassifier.sniffMagic(data)

        var offset = 0
        var first = true
        while (offset < data.size) {
            val length = minOf(WINDOW_SIZE, data.size - offset)
            val (statKind, stats) = RegionClassifier.classify(data, offset, length)
            val kind = if (first && magic != null) magic else statKind
            regions.add(Region(offset, length, kind, stats))
            offset += length
            first = false
        }
        return regions
    }
}
