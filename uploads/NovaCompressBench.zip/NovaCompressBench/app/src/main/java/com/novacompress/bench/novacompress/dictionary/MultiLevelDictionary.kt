package com.novacompress.bench.novacompress.dictionary

/**
 * Backing state for [com.novacompress.bench.novacompress.matcher.LongRangeMatcher] - see
 * BENCHMARKS.md Entry 6 ("matcher rewrite: tiered hashing + pooled workspace") for the full
 * before/after story.
 *
 * The spec asks for four cooperating dictionary levels (global / block / local / micro), which
 * (as in the original design) this still isn't four separate maps - it's two hash tables whose
 * effective *scope* is controlled by how much data the caller passes into a single call, plus a
 * repeat-offset list:
 *
 *  - **Micro**: [repDistances], a 4-entry MRU list of recently used match distances ("repeat
 *    offsets" - a technique borrowed from LZMA/Zstd). Checked first because repeats are cheaper
 *    to encode. Unlike every other field here, [beginCall] resets its four *values* back to
 *    `1, 2, 3, 4` on every call instead of pooling them across calls - a repeat-offset list is
 *    genuinely call-scoped state (recently-used distances from a *previous*, unrelated segment
 *    have no business influencing this one), not something reuse should carry forward.
 *  - **Local**: the default - tokenizing one segment's bytes gives a dictionary scoped to that
 *    segment.
 *  - **Block / Global**: tokenizing several segments' bytes concatenated together (what
 *    NovaContainerFormat does when merging segments, or NovaCompressAlgorithm does for files
 *    small enough to stay in one chunk) gives the *same* mechanism whole-file reach, with no
 *    separate seeding step required.
 *
 * Two things changed from the original single-hash-table design, both explained below: the
 * instance is now long-lived and reused rather than rebuilt per call, and there are two hash
 * levels instead of one.
 *
 * ### 1. One instance is now reused across many [beginCall]s, not constructed fresh per call
 *
 * The original had "one instance is created per tokenize() call" as a deliberate design note.
 * That's simple but costly: [NovaContainerFormat.encodeChunk][com.novacompress.bench.novacompress.format.NovaContainerFormat]
 * calls [com.novacompress.bench.novacompress.NovaSegmentCodec.encode] - and therefore
 * [com.novacompress.bench.novacompress.matcher.LongRangeMatcher.tokenize] - once per segment,
 * again for every merge/split trial NovaContainerFormat runs, which for a file with hundreds of
 * segments means hundreds of fresh `IntArray(hashSize)` allocations (each zero-filled by the
 * JVM/ART on construction) per chunk. [LongRangeMatcher] now keeps one `MultiLevelDictionary`
 * per compression thread (a `ThreadLocal`, since chunks run on
 * [kotlinx.coroutines.Dispatchers.Default]'s bounded worker pool - see
 * [com.novacompress.bench.novacompress.NovaCompressAlgorithm]'s KDoc) and calls [beginCall]
 * before every `tokenize()` instead of constructing a new one. [beginCall] only *grows* the
 * backing arrays (never shrinks, never reallocates once large enough) and never memsets them -
 * see "generation stamps" below for how that's still correct.
 *
 * ### 2. Two hash levels instead of one, sized to the call instead of fixed at 2^17
 *
 * [shortHead]/[shortHeadGen]/[prev] are what the original single `head`/`prev` pair was: a
 * 4-byte-keyed hash *chain* (walked in [LongRangeMatcher]'s bestMatchAt), long enough to also
 * catch [com.novacompress.bench.novacompress.matcher.LongRangeMatcher.MIN_MATCH]-length matches.
 * [tierHead]/[tierHeadGen] is new: a single-slot (no chain), 8-byte-keyed table used as an O(1)
 * pre-check for long matches before ever walking the 4-byte chain - see the matcher's KDoc for
 * why one extra 8-byte level earns its cost and a 16/32-byte level on top of it measurably
 * didn't.
 *
 * The original's hash table was a fixed 2^17 buckets regardless of how much data one `tokenize()`
 * call covered - fine for a typical few-hundred-KB segment, but for a multi-megabyte merged
 * run (or a `tokenize()` call over a large file compressed below the chunking threshold) the
 * chain behind every bucket got proportionally longer, and [LongRangeMatcher]'s bounded
 * per-position chain walk (`MAX_CHAIN` candidates) started truncating searches that a bigger
 * table wouldn't have needed to. [shortHashBitsFor]/[tierHashBitsFor] size each table to the
 * call, but conservatively: the *floor* is exactly the original's 2^17, so anything at or under
 * roughly the original's typical segment size sees a byte-identical table (and therefore
 * byte-identical cache behavior) to before. An earlier, more aggressive version of this formula
 * (scale straight off input size with no floor tying it back to the original) measurably
 * *regressed* speed on every one of the six sample fixtures, all well under a megabyte -
 * oversizing the table hurts cache locality even though (thanks to generation stamps) it costs
 * nothing to "clear." Growing only pays off once an input is big enough that the original's
 * fixed table would have produced long chains in the first place - see BENCHMARKS.md Entry 6.
 *
 * ### Generation stamps instead of clearing on reuse
 *
 * Every `*Gen` array pairs with a `*Head` array: a bucket only counts as occupied if
 * `xHeadGen[bucket] == generation`, so [beginCall] "resets" every table in O(1) by incrementing
 * [generation] rather than re-zeroing potentially millions of entries - the whole point of
 * pooling. [prev] doesn't need its own generation array: any `prev[cand]` the matcher ever reads
 * was written earlier in the *same* call, because the only way to reach `cand` at all is by
 * starting from a generation-checked-fresh `shortHead[bucket]` and following `prev` links that
 * were themselves written this call - so a stale leftover value can never be reached, whether the
 * array was just grown (zero-filled) or reused from three calls ago. See [beginCall]'s body for
 * why [generation] is never reset back to a small number even when the backing arrays grow -
 * doing that once seemed harmless (a freshly grown array's stamps are already all zero) but
 * risked resurrecting a genuinely stale entry sitting in some *other*, not-just-grown array as if
 * it were fresh.
 */
class MultiLevelDictionary {
    var generation: Int = 0
        private set
    var shortHashBits: Int = -1
        private set
    var tierHashBits: Int = -1
        private set

    var shortHead: IntArray = IntArray(0)
        private set
    var shortHeadGen: IntArray = IntArray(0)
        private set
    var prev: IntArray = IntArray(0)
        private set
    var tierHead: IntArray = IntArray(0)
        private set
    var tierHeadGen: IntArray = IntArray(0)
        private set

    /** 4-entry MRU repeat-offset list - see class KDoc "Micro". Reset to `1, 2, 3, 4` at the
     *  start of every call by [beginCall]; unlike the hash tables, its *contents* are never
     *  carried over between calls, only the backing array itself is reused. */
    val repDistances: IntArray = intArrayOf(1, 2, 3, 4)

    /** Prepares this (possibly-reused) instance for a `dataSize`-byte [tokenize] call: bumps
     *  [generation] (the O(1) "clear") and grows any backing array that's too small for
     *  `dataSize`, or too small (in hash-bucket-count terms) to give this call a reasonably
     *  short average chain length. Never shrinks and never reallocates an already-big-enough
     *  array, so a workspace that has already handled a large call stays sized for later, smaller
     *  ones - see class KDoc. Also resets [repDistances]' values (but not the hash tables) since
     *  those are genuinely call-scoped - see class KDoc "Micro". */
    fun beginCall(dataSize: Int) {
        generation++

        repDistances[0] = 1; repDistances[1] = 2; repDistances[2] = 3; repDistances[3] = 4

        if (dataSize > prev.size) {
            prev = IntArray(maxOf(dataSize, prev.size * 2))
        }

        val neededShortBits = shortHashBitsFor(dataSize)
        if (shortHashBits < 0 || neededShortBits > shortHashBits) {
            shortHashBits = neededShortBits
            val size = 1 shl shortHashBits
            shortHead = IntArray(size)
            shortHeadGen = IntArray(size)
        }

        val neededTierBits = tierHashBitsFor(dataSize)
        if (tierHashBits < 0 || neededTierBits > tierHashBits) {
            tierHashBits = neededTierBits
            val size = 1 shl tierHashBits
            tierHead = IntArray(size)
            tierHeadGen = IntArray(size)
        }
    }

    companion object {
        // Floors match the original shipped table (2^17) exactly - see class KDoc "Two hash
        // levels" for why that floor matters, not just the ceiling.
        private const val SHORT_HASH_BITS_FLOOR = 17
        private const val SHORT_HASH_BITS_CEIL = 22
        private const val TIER_HASH_BITS_FLOOR = 14
        private const val TIER_HASH_BITS_CEIL = 20

        private fun bitsFor(n: Int): Int = 32 - Integer.numberOfLeadingZeros(maxOf(1, n))
        fun shortHashBitsFor(n: Int): Int = (bitsFor(n) - 2).coerceIn(SHORT_HASH_BITS_FLOOR, SHORT_HASH_BITS_CEIL)
        fun tierHashBitsFor(n: Int): Int = (bitsFor(n) - 4).coerceIn(TIER_HASH_BITS_FLOOR, TIER_HASH_BITS_CEIL)
    }
}
