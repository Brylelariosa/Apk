package com.novacompress.bench.novacompress.analyzer

enum class RegionKind {
    TEXT,
    STRUCTURED_TEXT, // JSON/XML/markup-like: printable but with lots of repeated punctuation/structure
    REPETITIVE_BINARY, // tables/records: low-moderate entropy, high shingle repetition
    EXECUTABLE_LIKE,
    IMAGE_LIKE,
    ALREADY_COMPRESSED_OR_ENCRYPTED, // high entropy - matching/entropy coding won't help
    BINARY_UNKNOWN,
}

data class RegionStats(
    val entropy: Double,
    val printableRatio: Double,
    val nullRatio: Double,
    val repetitionRatio: Double,
)

object RegionClassifier {
    /** Sniffs well-known file-format magic bytes at the very start of a file.
     *  Only meaningful when [offset] == 0 in the whole-file buffer. */
    fun sniffMagic(data: ByteArray): RegionKind? {
        if (data.size < 4) return null
        val b0 = data[0].toInt() and 0xFF
        val b1 = data[1].toInt() and 0xFF
        val b2 = data[2].toInt() and 0xFF
        val b3 = data[3].toInt() and 0xFF

        return when {
            // PNG
            b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47 -> RegionKind.IMAGE_LIKE
            // JPEG
            b0 == 0xFF && b1 == 0xD8 && b2 == 0xFF -> RegionKind.IMAGE_LIKE
            // GIF
            b0 == 0x47 && b1 == 0x49 && b2 == 0x46 -> RegionKind.IMAGE_LIKE
            // BMP
            b0 == 0x42 && b1 == 0x4D -> RegionKind.IMAGE_LIKE
            // ZIP / APK / JAR (PK..)
            b0 == 0x50 && b1 == 0x4B && (b2 == 0x03 || b2 == 0x05 || b2 == 0x07) -> RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED
            // ELF executable
            b0 == 0x7F && b1 == 0x45 && b2 == 0x4C && b3 == 0x46 -> RegionKind.EXECUTABLE_LIKE
            // PDF
            b0 == 0x25 && b1 == 0x50 && b2 == 0x44 && b3 == 0x46 -> RegionKind.STRUCTURED_TEXT
            // Gzip / already-compressed streams
            b0 == 0x1F && b1 == 0x8B -> RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED
            else -> null
        }
    }

    fun classify(data: ByteArray, offset: Int, length: Int): Pair<RegionKind, RegionStats> {
        val entropy = EntropyCalculator.shannonEntropy(data, offset, length)
        val printable = EntropyCalculator.printableAsciiRatio(data, offset, length)
        val nulls = EntropyCalculator.nullByteRatio(data, offset, length)
        val repetition = EntropyCalculator.repetitionRatio(data, offset, length)
        val stats = RegionStats(entropy, printable, nulls, repetition)

        // A byte-value histogram can't see position/order, so a steadily
        // incrementing counter or a (position*k + n) ramp - maximally
        // predictable, and typically full of repeated shingles - reads as
        // "high entropy" exactly like true random data, since it visits
        // every byte value with similar frequency either way. Requiring low
        // repetition alongside high entropy is what tells the two apart:
        // genuinely already-compressed/encrypted data has both high entropy
        // AND near-zero shingle repetition (there's nothing left to repeat),
        // so this doesn't change how real high-entropy data gets classified.
        //
        // That said, the shingle check itself has a known gap: 8-byte
        // *non-overlapping* shingles only catch a repeat if it happens to
        // land on an 8-byte-aligned boundary within the window. A
        // fixed-stride record whose stride isn't a clean multiple/divisor of
        // 8 (synthetic_table.bin's 24-byte record is a multiple of 8, but
        // its *arithmetic-ramp* field values still change every record, so
        // the per-record shingles essentially never repeat within one
        // window) can measure well under [REPETITIVE_STRUCTURE_THRESHOLD]
        // and fall through to ALREADY_COMPRESSED_OR_ENCRYPTED even though
        // it's highly structured. Investigated for real compression-ratio
        // impact (BENCHMARKS.md, "FileAnalyzer/RegionClassifier periodicity
        // blind spot"): confirmed via the classifier's own numbers on
        // synthetic_table.bin (entropy ~7.95, repetition ~0.227 - just under
        // this threshold) and fixed with a stride-autocorrelation check, but
        // the fix produced a measured 0.00% change in final compressed size
        // on every fixture tried (the six built-in samples plus three
        // JSON/table/JSON mixes), because NovaContainerFormat.encodeChunk's
        // trial-encode-and-promote step (see its KDoc) already recovers the
        // ratio for any misclassified segment that's genuinely compressible
        // - all it costs is one redundant NovaSegmentCodec.encode() call per
        // such segment. Left unfixed here for that reason: a classifier
        // change with no measured ratio benefit isn't worth the added
        // complexity, per this project's "one subsystem, one measured
        // improvement, keep or revert based on the numbers" process. Worth
        // revisiting only alongside a change that removes or weakens that
        // safety net.
        val kind = when {
            entropy >= HIGH_ENTROPY_THRESHOLD && repetition < REPETITIVE_STRUCTURE_THRESHOLD ->
                RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED
            printable >= 0.90 && repetition < 0.15 -> RegionKind.TEXT
            printable >= 0.70 && repetition >= 0.15 -> RegionKind.STRUCTURED_TEXT
            repetition >= REPETITIVE_STRUCTURE_THRESHOLD -> RegionKind.REPETITIVE_BINARY
            nulls >= 0.30 && entropy < 5.5 -> RegionKind.EXECUTABLE_LIKE // padded/aligned binary sections
            else -> RegionKind.BINARY_UNKNOWN
        }
        return kind to stats
    }

    private const val HIGH_ENTROPY_THRESHOLD = 7.5
    private const val REPETITIVE_STRUCTURE_THRESHOLD = 0.25
}
