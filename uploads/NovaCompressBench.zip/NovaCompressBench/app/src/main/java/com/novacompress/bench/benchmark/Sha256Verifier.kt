package com.novacompress.bench.benchmark

import java.io.InputStream
import java.security.MessageDigest

object Sha256Verifier {
    fun hash(input: InputStream): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(256 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            digest.update(buffer, 0, read)
        }
        return digest.digest()
    }

    fun hashesEqual(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    fun toHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }
}
