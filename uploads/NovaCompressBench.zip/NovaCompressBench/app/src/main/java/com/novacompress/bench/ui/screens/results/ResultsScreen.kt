package com.novacompress.bench.ui.screens.results

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.VerificationResult
import com.novacompress.bench.novacompress.NovaCompressAlgorithm
import com.novacompress.bench.ui.BenchmarkUiState
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.components.charts.BarChart
import com.novacompress.bench.ui.components.charts.BarChartEntry
import com.novacompress.bench.ui.screens.home.formatBytes
import com.novacompress.bench.ui.theme.ColorExperimentalAlgorithm
import com.novacompress.bench.ui.theme.ColorFail
import com.novacompress.bench.ui.theme.ColorPass
import com.novacompress.bench.ui.theme.ColorStandardAlgorithm
import com.novacompress.bench.ui.theme.ColorUnavailable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: BenchmarkViewModel,
    onBack: () -> Unit,
    onOpenResearch: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val results = uiState.results.filter { it.verified != VerificationResult.UNAVAILABLE }
    val hasNova = uiState.results.any { it.algorithmId == NovaCompressAlgorithm().id }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Results") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(formatResultsAsText(uiState)))
                        Toast.makeText(context, "Results copied", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copy results as text")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Text(uiState.source?.displayName ?: "", style = MaterialTheme.typography.titleMedium)
                uiState.source?.let {
                    Text(formatBytes(it.sizeBytes), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (results.isNotEmpty()) {
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("Compression ratio", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            BarChart(
                                entries = results.map { m ->
                                    BarChartEntry(
                                        label = m.algorithmName,
                                        value = m.compressionRatio.toFloat(),
                                        color = colorFor(m),
                                        valueText = "%.2fx".format(m.compressionRatio),
                                    )
                                },
                            )
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("Compression throughput", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            BarChart(
                                entries = results.map { m ->
                                    BarChartEntry(
                                        label = m.algorithmName,
                                        value = m.compressionThroughputMBps.toFloat(),
                                        color = colorFor(m),
                                        valueText = "%.1f MB/s".format(m.compressionThroughputMBps),
                                    )
                                },
                            )
                        }
                    }
                }
            }

            item {
                Text("All metrics", style = MaterialTheme.typography.titleMedium)
            }
            items(uiState.results) { m -> ResultRow(m) }

            if (hasNova) {
                item {
                    FilledTonalButton(onClick = onOpenResearch, modifier = Modifier.fillMaxWidth()) {
                        Text("Open NovaCompress Research Mode")
                    }
                }
            }
        }
    }
}

private fun colorFor(m: BenchmarkMetrics) =
    if (m.category == AlgorithmCategory.EXPERIMENTAL) ColorExperimentalAlgorithm else ColorStandardAlgorithm

private fun formatResultsAsText(uiState: BenchmarkUiState): String {
    val source = uiState.source
    val header = if (source != null) {
        "NovaCompress Bench \u2014 ${source.displayName} (${formatBytes(source.sizeBytes)})"
    } else {
        "NovaCompress Bench"
    }
    val rows = uiState.results.joinToString("\n\n") { m ->
        when (m.verified) {
            VerificationResult.PASS, VerificationResult.FAIL -> {
                val reasonLine = m.failureReason?.let { "\n  $it" } ?: ""
                "${m.algorithmName}: ${m.verified}" +
                    "\n  ratio %.2fx, saved %.1f%%".format(m.compressionRatio, m.spaceSavingPercent) +
                    "\n  compress ${m.compressionTimeMs} ms (%.1f MB/s), decompress ${m.decompressionTimeMs} ms (%.1f MB/s)"
                        .format(m.compressionThroughputMBps, m.decompressionThroughputMBps) +
                    reasonLine
            }
            VerificationResult.UNAVAILABLE, VerificationResult.SKIPPED -> {
                "${m.algorithmName}: ${m.verified}" + (m.failureReason?.let { "\n  $it" } ?: "")
            }
        }
    }
    return "$header\n\n$rows"
}

@Composable
private fun ResultRow(m: BenchmarkMetrics) {
    Card {
        Column(Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(m.algorithmName, style = MaterialTheme.typography.titleMedium)
                VerificationBadge(m.verified)
            }
            if (m.verified == VerificationResult.UNAVAILABLE || m.failureReason != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    m.failureReason ?: "Unavailable",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (m.verified == VerificationResult.PASS || m.verified == VerificationResult.FAIL) {
                Spacer(Modifier.height(8.dp))
                MetricGrid(m)
            }
        }
    }
}

@Composable
private fun MetricGrid(m: BenchmarkMetrics) {
    val rows = listOf(
        "Original size" to formatBytes(m.originalSizeBytes),
        "Compressed size" to formatBytes(m.compressedSizeBytes),
        "Ratio" to "%.2fx".format(m.compressionRatio),
        "Space saved" to "%.1f%%".format(m.spaceSavingPercent),
        "Compress time" to "${m.compressionTimeMs} ms",
        "Decompress time" to "${m.decompressionTimeMs} ms",
        "Compress CPU time" to "${m.compressionCpuTimeMs} ms",
        "Decompress CPU time" to "${m.decompressionCpuTimeMs} ms",
        "Compress throughput" to "%.1f MB/s".format(m.compressionThroughputMBps),
        "Decompress throughput" to "%.1f MB/s".format(m.decompressionThroughputMBps),
        "Memory delta (approx.)" to formatBytes(m.peakMemoryDeltaBytes),
    )
    Column {
        rows.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                pair.forEach { (label, value) ->
                    Column(Modifier.weight(1f)) {
                        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(value, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun VerificationBadge(result: VerificationResult) {
    val (color, icon, label) = when (result) {
        VerificationResult.PASS -> Triple(ColorPass, Icons.Filled.CheckCircle, "PASS")
        VerificationResult.FAIL -> Triple(ColorFail, Icons.Filled.Error, "FAIL")
        VerificationResult.UNAVAILABLE -> Triple(ColorUnavailable, Icons.Filled.Error, "N/A")
        VerificationResult.SKIPPED -> Triple(ColorUnavailable, Icons.Filled.Error, "SKIPPED")
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(RoundedCornerShape(8.dp))) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = color)
    }
}
