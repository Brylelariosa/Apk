package com.novacompress.bench.novacompress.entropy

class RangeDecoder(private val data: ByteArray, private var pos: Int = 0) {
    private var code = 0L
    private var range = 0xFFFFFFFFL

    init {
        nextByte() // discard the encoder's leading placeholder byte
        repeat(4) { code = (code shl 8) or nextByte() }
    }

    private fun nextByte(): Long =
        if (pos < data.size) (data[pos++].toLong() and 0xFFL) else 0L

    fun decodeSymbol(model: FreqModel): Int {
        val total = model.total().toLong()
        range /= total
        var target = code / range
        if (target >= total) target = total - 1

        val sym = model.findSymbol(target.toInt())
        val cumLow = model.cumFreq[sym].toLong()
        val f = model.freq[sym].toLong()

        code -= cumLow * range
        range *= f

        while (range < TOP) {
            code = (code shl 8) or nextByte()
            range = range shl 8
        }
        model.update(sym)
        return sym
    }

    companion object {
        private const val TOP = 1L shl 24
    }
}
