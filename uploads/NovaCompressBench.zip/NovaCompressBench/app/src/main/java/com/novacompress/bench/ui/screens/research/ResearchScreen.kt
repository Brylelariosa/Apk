package com.novacompress.bench.ui.screens.research

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.components.charts.EntropyHeatmapStrip
import com.novacompress.bench.ui.components.charts.SegmentLegend
import com.novacompress.bench.ui.components.charts.SegmentStrip
import com.novacompress.bench.ui.screens.home.formatBytes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResearchScreen(viewModel: BenchmarkViewModel, onBack: () -> Unit) {
    val uiState by viewModel.uiState.collectAsState()
    val report = uiState.researchReport

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NovaCompress Research Mode") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
            )
        },
    ) { padding ->
        if (report == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            ) {
                Text(
                    "No research report available for this run - NovaCompress may not have been included, " +
                        "or the report pass failed independently of the benchmark itself.",
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Overall", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        StatLine("Original size", formatBytes(report.originalSize))
                        StatLine("Compressed size", formatBytes(report.compressedSize))
                        StatLine("Ratio", "%.2fx".format(report.overallRatio))
                        StatLine("Chunks processed", "${report.chunkStats.size}")
                        StatLine("Segments detected", "${report.allSegments.size}")
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("File structure & strategy", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Each block is one detected segment, sized proportionally to its share of the file.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        SegmentStrip(report.allSegments)
                        Spacer(Modifier.height(8.dp))
                        SegmentLegend()
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Entropy across the file", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Cool = low entropy (compresses well), hot = high entropy (already dense/random).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        EntropyHeatmapStrip(report.allSegments)
                    }
                }
            }

            item {
                val novaSegments = report.allSegments.count { it.strategy == SegmentStrategy.NOVA }
                val storeSegments = report.allSegments.size - novaSegments
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Adaptive segmentation", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        StatLine("NovaCompress pipeline segments", "$novaSegments")
                        StatLine("Stored (high-entropy) segments", "$storeSegments")
                        StatLine("Bytes through NovaCompress pipeline", formatBytes(report.totalNovaInputBytes))
                        StatLine("Bytes stored verbatim", formatBytes(report.totalStoreInputBytes))
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Structural pattern detection & matching", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        StatLine("Total tokens", "${report.totalTokens}")
                        StatLine("Match tokens (repeated structure found)", "${report.totalMatchTokens}")
                        StatLine("Literal tokens", "${report.totalTokens - report.totalMatchTokens}")
                        val matchShare = if (report.totalTokens == 0) 0.0 else report.totalMatchTokens.toDouble() / report.totalTokens
                        Spacer(Modifier.height(8.dp))
                        Text("Share of tokens that were matches: %.1f%%".format(matchShare * 100), style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(progress = { matchShare.toFloat() }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Predictive encoder / learning component", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Order-2 adaptive model predicting the next byte from the 2 preceding bytes - no cloud calls, no neural network.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(8.dp))
                        StatLine("Prediction hits", "${report.totalPredictHits}")
                        Text("Prediction accuracy: %.1f%%".format(report.predictionAccuracy * 100), style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(progress = { report.predictionAccuracy.toFloat() }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Compression stages applied", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        listOf(
                            "1. File Analyzer - entropy + magic-byte + structure classification per window",
                            "2. Adaptive Segmentation - windows merged into STORE/NovaCompress-pipeline segments",
                            "3+7. Structural Pattern Detection & Long-Range Matching - whole-chunk LZ-style matcher",
                            "4. Multi-Level Dictionary - repeat-offsets (micro) + chunk-wide hash table (local/global)",
                            "5+10. Predictive Encoder / Learning Component - order-2 adaptive byte predictor",
                            "6. Graph-Based Pattern Compression - shown above as structural-reuse analytics",
                            "8. Parallel Compression - chunks compressed concurrently across CPU cores",
                            "9. Entropy Encoder - range coding vs. Huffman, smaller output kept automatically",
                        ).forEach { stage ->
                            Text(stage, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(4.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
