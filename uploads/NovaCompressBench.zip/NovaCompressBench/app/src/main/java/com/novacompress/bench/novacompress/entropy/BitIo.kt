package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayOutputStream

class BitWriter {
    private val out = ByteArrayOutputStream()
    private var currentByte = 0
    private var bitsFilled = 0

    fun writeBits(value: Long, length: Int) {
        for (i in length - 1 downTo 0) {
            val bit = (value ushr i) and 1L
            currentByte = (currentByte shl 1) or bit.toInt()
            bitsFilled++
            if (bitsFilled == 8) {
                out.write(currentByte)
                currentByte = 0
                bitsFilled = 0
            }
        }
    }

    fun finish(): ByteArray {
        if (bitsFilled > 0) {
            currentByte = currentByte shl (8 - bitsFilled)
            out.write(currentByte)
        }
        return out.toByteArray()
    }
}

class BitReader(private val data: ByteArray) {
    private var bytePos = 0
    private var bitPos = 0

    fun readBit(): Int {
        if (bytePos >= data.size) return 0
        val byte = data[bytePos].toInt() and 0xFF
        val bit = (byte ushr (7 - bitPos)) and 1
        bitPos++
        if (bitPos == 8) {
            bitPos = 0
            bytePos++
        }
        return bit
    }
}
