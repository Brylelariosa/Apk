package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import org.xerial.snappy.SnappyInputStream
import org.xerial.snappy.SnappyOutputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

/** Listed as optional in the spec. xerial's snappy-java is primarily
 *  built/tested for desktop and server JVMs; its native loader is not
 *  guaranteed to ship a matching .so for every Android ABI, so this is
 *  checked defensively and will simply report "unavailable" rather than
 *  crash if it can't load on a given device. */
class SnappyAlgorithm : CompressionAlgorithm {
    override val id = "snappy"
    override val displayName = "Snappy"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable(): Boolean = try {
        SnappyOutputStream(ByteArrayOutputStream()).close()
        true
    } catch (t: Throwable) {
        false
    }

    override fun compress(input: InputStream, output: OutputStream) {
        SnappyOutputStream(output).use { sos ->
            IoUtil.copyStream(input, sos)
        }
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        SnappyInputStream(input).use { sis ->
            IoUtil.copyStream(sis, output)
        }
    }
}
