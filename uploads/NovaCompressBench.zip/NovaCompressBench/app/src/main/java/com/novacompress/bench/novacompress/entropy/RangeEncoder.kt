package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayOutputStream

/**
 * Byte-oriented range coder (LZMA-style carry-propagating renormalization).
 * Ported unchanged in structure from a Java prototype verified via 47
 * round-trip tests including carry-propagation stress cases - see README
 * "Verification" for why this specific design was chosen over a naive
 * arithmetic coder (carry handling is the classic correctness pitfall here).
 */
class RangeEncoder {
    private val out = ByteArrayOutputStream()
    private var low = 0L
    private var range = 0xFFFFFFFFL
    private var cache = 0
    private var cacheSize = 1L

    fun encode(model: FreqModel, sym: Int) {
        val total = model.total().toLong()
        val cumLow = model.cumFreq[sym].toLong()
        val f = model.freq[sym].toLong()

        range /= total
        low += cumLow * range
        range *= f

        while (range < TOP) {
            shiftLow()
            range = range shl 8
        }
        model.update(sym)
    }

    private fun shiftLow() {
        if (low < 0xFF000000L || low > MASK32) {
            var temp = cache
            do {
                out.write(((temp + (low ushr 32)).toInt()) and 0xFF)
                temp = 0xFF
            } while (--cacheSize != 0L)
            cache = ((low ushr 24) and 0xFF).toInt()
        }
        cacheSize++
        low = (low shl 8) and MASK32
    }

    fun finish(): ByteArray {
        repeat(5) { shiftLow() }
        return out.toByteArray()
    }

    companion object {
        private const val TOP = 1L shl 24
        private const val MASK32 = 0xFFFFFFFFL
    }
}
