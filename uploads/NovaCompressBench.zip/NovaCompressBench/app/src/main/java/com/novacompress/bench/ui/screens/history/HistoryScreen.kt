package com.novacompress.bench.ui.screens.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novacompress.bench.core.VerificationResult
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.theme.ColorFail
import com.novacompress.bench.ui.theme.ColorPass
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: BenchmarkViewModel, onBack: () -> Unit) {
    val fileNames by viewModel.historyFileNames.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Benchmark History") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
            )
        },
    ) { padding ->
        if (fileNames.isEmpty()) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text(
                    "No benchmark runs saved yet - results are saved automatically each time you run a benchmark.",
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(fileNames) { fileName ->
                    FileHistoryCard(viewModel, fileName)
                }
            }
        }
    }
}

@Composable
private fun FileHistoryCard(viewModel: BenchmarkViewModel, fileName: String) {
    val results by viewModel.historyForFile(fileName).collectAsState(initial = emptyList())
    Card {
        Column(Modifier.padding(16.dp)) {
            Text(fileName, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            results.take(10).forEach { m ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(m.algorithmName, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(m.timestampEpochMs)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    val ratioText = if (m.verified == VerificationResult.PASS || m.verified == VerificationResult.FAIL) {
                        "%.2fx".format(m.compressionRatio)
                    } else {
                        "-"
                    }
                    Text(
                        ratioText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = when (m.verified) {
                            VerificationResult.FAIL -> ColorFail
                            VerificationResult.PASS -> ColorPass
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
