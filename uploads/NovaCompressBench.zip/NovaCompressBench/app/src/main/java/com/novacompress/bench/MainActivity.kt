package com.novacompress.bench

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.navigation.NovaNavGraph
import com.novacompress.bench.ui.theme.NovaCompressTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as NovaCompressApp).container
        val factory = BenchmarkViewModel.factory(container)

        setContent {
            NovaCompressBenchApp(factory)
        }
    }
}

@Composable
private fun NovaCompressBenchApp(factory: androidx.lifecycle.ViewModelProvider.Factory) {
    NovaCompressTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            NovaNavGraph(viewModelFactory = factory)
        }
    }
}
