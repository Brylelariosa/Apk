package com.novacompress.bench.novacompress.dictionary

import java.io.ByteArrayOutputStream

object Varint {
    fun write(out: ByteArrayOutputStream, value: Int) {
        var v = value.toLong() and 0xFFFFFFFFL
        while (true) {
            val b = (v and 0x7F).toInt()
            v = v ushr 7
            if (v == 0L) {
                out.write(b)
                break
            }
            out.write(b or 0x80)
        }
    }

    /** Reads one varint starting at pos[0], advancing it past the value read. */
    fun read(data: ByteArray, pos: IntArray): Int {
        var shift = 0
        var result = 0L
        while (true) {
            val b = data[pos[0]++].toInt() and 0xFF
            result = result or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) break
            shift += 7
        }
        return result.toInt()
    }
}
