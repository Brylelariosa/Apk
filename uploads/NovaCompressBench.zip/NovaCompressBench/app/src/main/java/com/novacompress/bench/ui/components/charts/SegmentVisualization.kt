package com.novacompress.bench.ui.components.charts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.novacompress.bench.novacompress.segment.Segment
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.ui.theme.ColorNovaStrategy
import com.novacompress.bench.ui.theme.ColorStoreStrategy

/** Proportionally-weighted strip: one box per segment, width proportional to
 *  its share of the file, colored by strategy (STORE vs NOVA). This is both
 *  the spec's "segment visualization" and, since segment boundaries follow
 *  the analyzer's classification, its "file structure visualization". */
@Composable
fun SegmentStrip(segments: List<Segment>, modifier: Modifier = Modifier) {
    val total = segments.sumOf { it.length }.coerceAtLeast(1)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .clip(RoundedCornerShape(6.dp)),
    ) {
        segments.forEach { seg ->
            val weight = (seg.length.toFloat() / total).coerceAtLeast(0.001f)
            val color = if (seg.strategy == SegmentStrategy.NOVA) ColorNovaStrategy else ColorStoreStrategy
            Box(
                modifier = Modifier
                    .weight(weight)
                    .fillMaxWidth()
                    .height(28.dp)
                    .background(color),
            )
        }
    }
}

/** Entropy heatmap: same layout idea as [SegmentStrip], but colored by a
 *  continuous entropy value per segment (low = cool, high = hot) rather
 *  than a discrete strategy. */
@Composable
fun EntropyHeatmapStrip(segments: List<Segment>, modifier: Modifier = Modifier) {
    val total = segments.sumOf { it.length }.coerceAtLeast(1)
    val cool = Color(0xFF2C9C91)
    val hot = Color(0xFFE5484D)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(20.dp)
            .clip(RoundedCornerShape(6.dp)),
    ) {
        segments.forEach { seg ->
            val weight = (seg.length.toFloat() / total).coerceAtLeast(0.001f)
            val t = (seg.avgEntropy / 8.0).coerceIn(0.0, 1.0).toFloat()
            Box(
                modifier = Modifier
                    .weight(weight)
                    .fillMaxWidth()
                    .height(20.dp)
                    .background(lerp(cool, hot, t)),
            )
        }
    }
}

@Composable
fun SegmentLegend(modifier: Modifier = Modifier) {
    Row(modifier = modifier) {
        LegendDot(ColorNovaStrategy, "NovaCompress pipeline")
        Spacer(Modifier.width(16.dp))
        LegendDot(ColorStoreStrategy, "Stored (high-entropy)")
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row {
        Box(
            modifier = Modifier
                .height(10.dp)
                .width(10.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color),
        )
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
