package com.novacompress.bench.novacompress

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.novacompress.format.ChunkResearchStats
import com.novacompress.bench.novacompress.format.NovaContainerFormat
import com.novacompress.bench.novacompress.format.NovaResearchReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * The experimental research compressor. Ties together every stage from the
 * spec:
 *  - [com.novacompress.bench.novacompress.analyzer.FileAnalyzer] (Stage 1: File Analyzer)
 *  - [com.novacompress.bench.novacompress.segment.Segmenter] (Stage 2: Adaptive Segmentation)
 *  - [com.novacompress.bench.novacompress.matcher.LongRangeMatcher] (Stages 3 & 7: Structural
 *    Pattern Detection & Long-Range Matching; its repeat-offset list covers Stage 4's
 *    "micro" dictionary level)
 *  - [com.novacompress.bench.novacompress.predictor.ContextPredictor] (Stages 5 & 10:
 *    Predictive Encoder & Learning Component - one adaptive model serves both)
 *  - [com.novacompress.bench.novacompress.entropy.EntropyCoderSelector] (Stage 9: Entropy
 *    Encoder, auto-selecting range coding vs. Huffman)
 *
 * Stage 6 ("Graph-Based Pattern Compression") is deliberately *not* a
 * separate compression mechanism here: the long-range matcher already
 * deduplicates repeated structure, so a second graph-based pass over the
 * same data would be redundant engineering risk for little extra ratio.
 * Instead it shows up as analytics - which templates got referenced how
 * often - surfaced through [NovaResearchReport], matching what the spec's
 * own "Research Mode" section actually asks to *see* (detected structures,
 * repeated templates) rather than a second compressor.
 *
 * Input is read in bounded [CHUNK_SIZE] chunks - never the whole file at
 * once, so a 10GB+ file has the same peak memory as a 16MB one. Chunks
 * double as the dictionary's effective scope: all NOVA-strategy content
 * *within* one chunk shares a single match dictionary and entropy-coded
 * stream, which for any file at or under [CHUNK_SIZE] (most real files)
 * means genuinely whole-file ("global") reach with no separate mechanism
 * needed. Chunks within a batch of up to [PARALLEL_BATCH] are compressed
 * concurrently on [Dispatchers.Default] (Stage 8: Parallel Compression,
 * using all CPU cores), then written to the output stream in original
 * order. This is the same trade-off production parallel compressors make
 * (pigz, zstd's multithreaded mode): a dictionary can't usefully span
 * chunks being compressed concurrently, so the chunk boundary is where
 * "global reach" gives way to "parallel throughput" - see class-level docs
 * on [com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary]
 * for more.
 *
 * Decompression is sequential - chunks are small and independent, but
 * unlike compression there's no length-prefix on the *compressed* chunk
 * bytes to let a reader skip ahead without parsing, so parallel decode
 * would need that framing added first. Decompression is also the cheaper
 * direction (see README benchmark notes), so this was left sequential
 * rather than adding untested framing changes late in this pass.
 */
class NovaCompressAlgorithm : CompressionAlgorithm {
    override val id = "novacompress"
    override val displayName = "NovaCompress (experimental)"
    override val category = AlgorithmCategory.EXPERIMENTAL

    override fun isAvailable() = true

    override fun compress(input: InputStream, output: OutputStream) {
        compressWithReport(input, output)
    }

    /** Same as [compress], but also returns aggregated Stage 1-10 telemetry
     *  for the Research Mode screen. The generic [compress] entry point
     *  (used by the benchmark runner for every algorithm uniformly) just
     *  discards the report. */
    fun compressWithReport(input: InputStream, output: OutputStream): NovaResearchReport {
        val dout = DataOutputStream(output)
        NovaContainerFormat.writeHeader(dout)

        var originalTotal = 0L
        var compressedTotal = 5L // header: 4 magic + 1 version
        val allStats = ArrayList<ChunkResearchStats>()

        runBlocking {
            val readBuffer = ByteArray(CHUNK_SIZE)
            var streamEnded = false
            while (!streamEnded) {
                val batch = ArrayList<ByteArray>(PARALLEL_BATCH)
                for (i in 0 until PARALLEL_BATCH) {
                    val chunk = readFullyUpTo(input, readBuffer, CHUNK_SIZE)
                    if (chunk == null) {
                        streamEnded = true
                        break
                    }
                    batch.add(chunk)
                }
                if (batch.isEmpty()) break

                val deferred = batch.map { chunkData ->
                    async(Dispatchers.Default) { NovaContainerFormat.encodeChunk(chunkData) }
                }
                for (encoded in deferred.map { it.await() }) {
                    dout.write(encoded.bytes)
                    compressedTotal += encoded.bytes.size
                    allStats.add(encoded.stats)
                }
                originalTotal += batch.sumOf { it.size.toLong() }
            }
        }

        NovaContainerFormat.writeEndMarker(dout)
        compressedTotal += 1
        dout.flush()

        return NovaResearchReport(allStats, originalTotal, compressedTotal)
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        val din = DataInputStream(input)
        NovaContainerFormat.readAndVerifyHeader(din)

        while (true) {
            val marker = din.readUnsignedByte()
            if (marker == NovaContainerFormat.MARKER_END) break
            check(marker == NovaContainerFormat.MARKER_MORE) { "Corrupt NovaCompress stream: unknown chunk marker $marker" }
            NovaContainerFormat.decodeChunk(din, output)
        }
        output.flush()
    }

    /** Reads up to [maxLen] bytes into a right-sized copy, or null at EOF
     *  with nothing read. Returns fewer than [maxLen] bytes for a partial
     *  final chunk, which [NovaContainerFormat.encodeChunk] handles fine. */
    private fun readFullyUpTo(input: InputStream, buffer: ByteArray, maxLen: Int): ByteArray? {
        var total = 0
        while (total < maxLen) {
            val read = input.read(buffer, total, maxLen - total)
            if (read == -1) break
            total += read
        }
        if (total == 0) return null
        return buffer.copyOf(total)
    }

    companion object {
        /** 16MB: also the dictionary's effective "global" reach - see class KDoc. */
        const val CHUNK_SIZE = 16 * 1024 * 1024
        val PARALLEL_BATCH = maxOf(1, minOf(Runtime.getRuntime().availableProcessors(), 4))
    }
}
