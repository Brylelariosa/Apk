package com.novacompress.bench.algorithms

import com.github.luben.zstd.ZstdInputStream
import com.github.luben.zstd.ZstdOutputStream
import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

class ZstdAlgorithm : CompressionAlgorithm {
    override val id = "zstd"
    override val displayName = "Zstandard"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable(): Boolean = try {
        // Exercises the real native-library load path with negligible cost,
        // rather than assuming the .so resolved for this device's ABI.
        ZstdOutputStream(ByteArrayOutputStream()).close()
        true
    } catch (t: Throwable) {
        false
    }

    override fun compress(input: InputStream, output: OutputStream) {
        ZstdOutputStream(output).use { zos ->
            zos.setLevel(19)
            IoUtil.copyStream(input, zos)
        }
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        ZstdInputStream(input).use { zis ->
            IoUtil.copyStream(zis, output)
        }
    }
}
