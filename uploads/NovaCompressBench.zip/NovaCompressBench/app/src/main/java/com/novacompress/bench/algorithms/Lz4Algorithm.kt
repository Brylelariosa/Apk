package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import net.jpountz.lz4.LZ4FrameInputStream
import net.jpountz.lz4.LZ4FrameOutputStream
import java.io.InputStream
import java.io.OutputStream

class Lz4Algorithm : CompressionAlgorithm {
    override val id = "lz4"
    override val displayName = "LZ4"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable(): Boolean = try {
        // lz4-java auto-selects a native or pure-Java implementation; this
        // just confirms class loading succeeds on this device/ABI.
        LZ4FrameOutputStream::class.java.name.isNotEmpty()
    } catch (t: Throwable) {
        false
    }

    override fun compress(input: InputStream, output: OutputStream) {
        LZ4FrameOutputStream(output).use { los ->
            IoUtil.copyStream(input, los)
        }
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        LZ4FrameInputStream(input).use { lis ->
            IoUtil.copyStream(lis, output)
        }
    }
}
