package com.novacompress.bench.data.repository

import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.data.db.BenchmarkResultDao
import com.novacompress.bench.data.db.BenchmarkResultEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BenchmarkRepository(private val dao: BenchmarkResultDao) {
    suspend fun save(results: List<BenchmarkMetrics>) {
        dao.insertAll(results.map { BenchmarkResultEntity.fromMetrics(it) })
    }

    fun observeAll(): Flow<List<BenchmarkMetrics>> =
        dao.observeAll().map { list -> list.map { it.toMetrics() } }

    fun observeForFile(fileName: String): Flow<List<BenchmarkMetrics>> =
        dao.observeForFile(fileName).map { list -> list.map { it.toMetrics() } }

    fun observeDistinctFileNames(): Flow<List<String>> = dao.observeDistinctFileNames()

    suspend fun clearAll() = dao.clearAll()
}
