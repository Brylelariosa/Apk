package com.novacompress.bench.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.screens.history.HistoryScreen
import com.novacompress.bench.ui.screens.home.HomeScreen
import com.novacompress.bench.ui.screens.research.ResearchScreen
import com.novacompress.bench.ui.screens.results.ResultsScreen

object Routes {
    const val HOME = "home"
    const val RESULTS = "results"
    const val RESEARCH = "research"
    const val HISTORY = "history"
}

@Composable
fun NovaNavGraph(
    viewModelFactory: androidx.lifecycle.ViewModelProvider.Factory,
    navController: NavHostController = rememberNavController(),
) {
    val viewModel: BenchmarkViewModel = viewModel(factory = viewModelFactory)

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onRunComplete = { navController.navigate(Routes.RESULTS) },
                onOpenHistory = { navController.navigate(Routes.HISTORY) },
            )
        }
        composable(Routes.RESULTS) {
            ResultsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenResearch = { navController.navigate(Routes.RESEARCH) },
            )
        }
        composable(Routes.RESEARCH) {
            ResearchScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
