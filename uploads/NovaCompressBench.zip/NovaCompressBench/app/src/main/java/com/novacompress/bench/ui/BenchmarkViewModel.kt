package com.novacompress.bench.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novacompress.bench.benchmark.BenchmarkRunner
import com.novacompress.bench.benchmark.BenchmarkSource
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.data.repository.BenchmarkRepository
import com.novacompress.bench.di.AppContainer
import com.novacompress.bench.novacompress.NovaCompressAlgorithm
import com.novacompress.bench.novacompress.format.NovaResearchReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

data class BenchmarkUiState(
    val source: BenchmarkSource? = null,
    val selectedAlgorithmIds: Set<String> = emptySet(),
    val isRunning: Boolean = false,
    val progressCompleted: Int = 0,
    val progressTotal: Int = 0,
    val progressCurrentName: String? = null,
    val results: List<BenchmarkMetrics> = emptyList(),
    val researchReport: NovaResearchReport? = null,
    val errorMessage: String? = null,
)

class BenchmarkViewModel(
    val algorithms: List<CompressionAlgorithm>,
    private val runner: BenchmarkRunner,
    private val repository: BenchmarkRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(
        BenchmarkUiState(selectedAlgorithmIds = algorithms.map { it.id }.toSet())
    )
    val uiState: StateFlow<BenchmarkUiState> = _uiState.asStateFlow()

    val historyFileNames = repository.observeDistinctFileNames()
    fun historyForFile(fileName: String) = repository.observeForFile(fileName)

    fun selectSource(source: BenchmarkSource) {
        _uiState.value = _uiState.value.copy(
            source = source, results = emptyList(), researchReport = null, errorMessage = null,
        )
    }

    fun toggleAlgorithm(id: String) {
        val current = _uiState.value.selectedAlgorithmIds
        _uiState.value = _uiState.value.copy(
            selectedAlgorithmIds = if (id in current) current - id else current + id,
        )
    }

    fun runBenchmark(onComplete: () -> Unit) {
        val state = _uiState.value
        val source = state.source ?: return
        val selected = algorithms.filter { it.id in state.selectedAlgorithmIds }
        if (selected.isEmpty()) return

        _uiState.value = state.copy(
            isRunning = true, errorMessage = null,
            progressCompleted = 0, progressTotal = selected.size, progressCurrentName = null,
        )
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val results = runner.runAll(source, selected) { completed, total, currentName ->
                    _uiState.value = _uiState.value.copy(
                        progressCompleted = completed, progressTotal = total, progressCurrentName = currentName,
                    )
                }

                // NovaCompress runs a second time here to capture the detailed
                // Stage 1-10 report for the Research screen - the generic
                // runner above deliberately stays algorithm-agnostic (any
                // algorithm-specific branching there would leak implementation
                // details into shared benchmark code), so this is a known,
                // bounded extra cost rather than a free side channel.
                var report: NovaResearchReport? = null
                val novaAlgo = selected.filterIsInstance<NovaCompressAlgorithm>().firstOrNull()
                if (novaAlgo != null) {
                    _uiState.value = _uiState.value.copy(progressCurrentName = "NovaCompress (research report)")
                    try {
                        report = novaAlgo.compressWithReport(source.openStream(), ByteArrayOutputStream())
                    } catch (_: Exception) {
                        // Research report is a bonus; don't let it hide otherwise-successful results.
                    }
                }

                repository.save(results)
                // onComplete() navigates (NavController.navigate -> LifecycleRegistry.setCurrentState),
                // which asserts main thread - this whole block was running on Dispatchers.Default.
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, results = results, researchReport = report)
                    onComplete()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, errorMessage = e.message ?: "Benchmark failed")
                }
            }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return BenchmarkViewModel(
                        container.algorithms,
                        container.benchmarkRunner,
                        container.benchmarkRepository,
                    ) as T
                }
            }
    }
}
