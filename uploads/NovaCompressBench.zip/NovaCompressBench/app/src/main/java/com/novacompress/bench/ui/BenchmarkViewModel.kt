package com.novacompress.bench.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novacompress.bench.benchmark.BenchmarkRunner
import com.novacompress.bench.benchmark.BenchmarkSource
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.data.repository.BenchmarkRepository
import com.novacompress.bench.di.AppContainer
import com.novacompress.bench.novacompress.NovaCompressAlgorithm
import com.novacompress.bench.novacompress.format.NovaResearchReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

data class BenchmarkUiState(
    /** Every source queued up for the next run - one real picked file, one
     *  built-in sample, or (this is the point of allowing a list rather than
     *  a single nullable source) several built-in samples selected together
     *  so one tap benchmarks all of them in a single batch. */
    val sources: List<BenchmarkSource> = emptyList(),
    val selectedAlgorithmIds: Set<String> = emptySet(),
    val isRunning: Boolean = false,
    val progressCompleted: Int = 0,
    val progressTotal: Int = 0,
    val progressCurrentName: String? = null,
    /** Every algorithm x source combination from the most recent run,
     *  flattened into one list - each row already carries its own
     *  [BenchmarkMetrics.sourceFileName], so a batch of several sources
     *  doesn't need a different shape here, just more rows. */
    val results: List<BenchmarkMetrics> = emptyList(),
    /** One [NovaResearchReport] per source that included NovaCompress in the
     *  run (only ever >1 entry when several sources were benchmarked
     *  together). */
    val researchReports: List<NovaResearchReport> = emptyList(),
    val errorMessage: String? = null,
)

class BenchmarkViewModel(
    val algorithms: List<CompressionAlgorithm>,
    private val runner: BenchmarkRunner,
    private val repository: BenchmarkRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(
        BenchmarkUiState(selectedAlgorithmIds = algorithms.map { it.id }.toSet())
    )
    val uiState: StateFlow<BenchmarkUiState> = _uiState.asStateFlow()

    val historyFileNames = repository.observeDistinctFileNames()
    fun historyForFile(fileName: String) = repository.observeForFile(fileName)

    /** Adds one source (e.g. a file just picked from the system file picker)
     *  to the current selection, alongside whatever is already queued. */
    fun addSource(source: BenchmarkSource) {
        _uiState.value = _uiState.value.copy(
            sources = _uiState.value.sources + source,
            results = emptyList(), researchReports = emptyList(), errorMessage = null,
        )
    }

    /** Adds or removes a single built-in sample from the selection, matched
     *  by reference/structural equality against whatever instance the
     *  caller passes in - the Home screen holds a `remember`-stable list of
     *  sample instances so this comparison is reliable (two *separately
     *  generated* samples aren't guaranteed `equal` since their [ByteArray]
     *  payloads compare by reference, not content). */
    fun toggleSample(sample: BenchmarkSource) {
        val current = _uiState.value.sources
        val updated = if (current.contains(sample)) current - sample else current + sample
        _uiState.value = _uiState.value.copy(
            sources = updated, results = emptyList(), researchReports = emptyList(), errorMessage = null,
        )
    }

    fun removeSource(source: BenchmarkSource) {
        _uiState.value = _uiState.value.copy(
            sources = _uiState.value.sources - source,
            results = emptyList(), researchReports = emptyList(), errorMessage = null,
        )
    }

    fun clearSources() {
        _uiState.value = _uiState.value.copy(
            sources = emptyList(), results = emptyList(), researchReports = emptyList(), errorMessage = null,
        )
    }

    fun toggleAlgorithm(id: String) {
        val current = _uiState.value.selectedAlgorithmIds
        _uiState.value = _uiState.value.copy(
            selectedAlgorithmIds = if (id in current) current - id else current + id,
        )
    }

    /** Runs every selected algorithm against every selected source - one
     *  built-in sample and one real picked file behave identically here
     *  (both are just a [BenchmarkSource]), so "compress multiple built-in
     *  samples in one go" falls out of this loop for free rather than
     *  needing separate handling. Each source is still run through
     *  [BenchmarkRunner.runAll] exactly as before (that class is
     *  independently unit-tested and single-source by design, so it's left
     *  untouched); this just calls it once per source and concatenates the
     *  results, which works because every [BenchmarkMetrics] row already
     *  carries its own [BenchmarkMetrics.sourceFileName]. */
    fun runBenchmark(onComplete: () -> Unit) {
        val state = _uiState.value
        val sources = state.sources
        if (sources.isEmpty()) return
        val selected = algorithms.filter { it.id in state.selectedAlgorithmIds }
        if (selected.isEmpty()) return

        val totalSteps = sources.size * selected.size
        _uiState.value = state.copy(
            isRunning = true, errorMessage = null,
            progressCompleted = 0, progressTotal = totalSteps, progressCurrentName = null,
        )
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val allResults = ArrayList<BenchmarkMetrics>(totalSteps)
                var stepsDoneBeforeThisSource = 0
                for (source in sources) {
                    val sourceResults = runner.runAll(source, selected) { completed, _, currentName ->
                        val label = if (sources.size > 1) "${source.displayName}: $currentName" else currentName
                        _uiState.value = _uiState.value.copy(
                            progressCompleted = stepsDoneBeforeThisSource + completed,
                            progressTotal = totalSteps,
                            progressCurrentName = label,
                        )
                    }
                    allResults += sourceResults
                    stepsDoneBeforeThisSource += selected.size
                }

                // NovaCompress runs a second time per source here to capture the
                // detailed Stage 1-10 report for the Research screen - the generic
                // runner above deliberately stays algorithm-agnostic (any
                // algorithm-specific branching there would leak implementation
                // details into shared benchmark code), so this is a known,
                // bounded extra cost rather than a free side channel.
                val reports = ArrayList<NovaResearchReport>()
                val novaAlgo = selected.filterIsInstance<NovaCompressAlgorithm>().firstOrNull()
                if (novaAlgo != null) {
                    for (source in sources) {
                        _uiState.value = _uiState.value.copy(
                            progressCurrentName = "${source.displayName}: NovaCompress (research report)",
                        )
                        try {
                            val report = novaAlgo.compressWithReport(source.openStream(), ByteArrayOutputStream())
                            reports += report.copy(sourceName = source.displayName)
                        } catch (_: Exception) {
                            // Research report is a bonus per source; skip that
                            // source's report rather than hiding the rest of an
                            // otherwise-successful batch.
                        }
                    }
                }

                repository.save(allResults)
                // onComplete() navigates (NavController.navigate -> LifecycleRegistry.setCurrentState),
                // which asserts main thread - this whole block was running on Dispatchers.Default.
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, results = allResults, researchReports = reports)
                    onComplete()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRunning = false, errorMessage = e.message ?: "Benchmark failed")
                }
            }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return BenchmarkViewModel(
                        container.algorithms,
                        container.benchmarkRunner,
                        container.benchmarkRepository,
                    ) as T
                }
            }
    }
}
