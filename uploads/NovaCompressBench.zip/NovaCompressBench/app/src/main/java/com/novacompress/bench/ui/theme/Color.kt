package com.novacompress.bench.ui.theme

import androidx.compose.ui.graphics.Color

// Core palette
val NovaTeal = Color(0xFF4FD1C5)
val NovaTealDark = Color(0xFF2C9C91)
val NovaAmber = Color(0xFFF5A623)
val NovaCharcoal = Color(0xFF12141C)
val NovaCharcoalElevated = Color(0xFF1B1E29)
val NovaSlate = Color(0xFF2A2F3E)
val NovaFogLight = Color(0xFFF4F6F8)
val NovaFogElevated = Color(0xFFFFFFFF)
val NovaInk = Color(0xFF12141C)

// Semantic - algorithm category / benchmark result coloring, used directly
// by chart components rather than derived from the Material scheme, so
// meaning stays consistent across light/dark.
val ColorStandardAlgorithm = Color(0xFF6B8AFE)
val ColorExperimentalAlgorithm = NovaTeal
val ColorPass = Color(0xFF4CAF7D)
val ColorFail = Color(0xFFE5484D)
val ColorUnavailable = Color(0xFF8A8F98)
val ColorStoreStrategy = Color(0xFF8A8F98)
val ColorNovaStrategy = NovaTeal
