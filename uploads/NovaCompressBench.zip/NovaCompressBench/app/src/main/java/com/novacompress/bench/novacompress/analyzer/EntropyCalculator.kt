package com.novacompress.bench.novacompress.analyzer

import kotlin.math.ln

object EntropyCalculator {
    /** Shannon entropy in bits/byte (0.0 = perfectly uniform/constant, 8.0 = maximally random byte distribution). */
    fun shannonEntropy(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        val counts = IntArray(256)
        for (i in offset until offset + length) counts[data[i].toInt() and 0xFF]++

        var entropy = 0.0
        val n = length.toDouble()
        for (c in counts) {
            if (c == 0) continue
            val p = c / n
            entropy -= p * ln(p) / LN2
        }
        return entropy
    }

    fun printableAsciiRatio(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        var printable = 0
        for (i in offset until offset + length) {
            val b = data[i].toInt() and 0xFF
            if (b in 32..126 || b == 9 || b == 10 || b == 13) printable++
        }
        return printable.toDouble() / length
    }

    fun nullByteRatio(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        var zeros = 0
        for (i in offset until offset + length) if (data[i].toInt() == 0) zeros++
        return zeros.toDouble() / length
    }

    /** Fraction of 8-byte shingles in the window that repeat within the same window -
     *  a cheap proxy for "this looks like a table/records region" without running the
     *  full matcher over it. */
    fun repetitionRatio(data: ByteArray, offset: Int, length: Int): Double {
        if (length < 16) return 0.0
        val seen = HashSet<Long>()
        var repeats = 0
        var shingles = 0
        var i = offset
        val end = offset + length - 8
        while (i <= end) {
            var h = 0L
            for (k in 0 until 8) h = (h shl 8) or (data[i + k].toLong() and 0xFF)
            shingles++
            if (!seen.add(h)) repeats++
            i += 8
        }
        return if (shingles == 0) 0.0 else repeats.toDouble() / shingles
    }

    private const val LN2 = 0.6931471805599453
}
