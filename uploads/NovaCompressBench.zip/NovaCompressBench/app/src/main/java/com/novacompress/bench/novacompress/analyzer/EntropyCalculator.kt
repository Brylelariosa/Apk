package com.novacompress.bench.novacompress.analyzer

import kotlin.math.ln

object EntropyCalculator {
    /** Shannon entropy in bits/byte (0.0 = perfectly uniform/constant, 8.0 = maximally random byte distribution). */
    fun shannonEntropy(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        val counts = IntArray(256)
        for (i in offset until offset + length) counts[data[i].toInt() and 0xFF]++

        var entropy = 0.0
        val n = length.toDouble()
        for (c in counts) {
            if (c == 0) continue
            val p = c / n
            entropy -= p * ln(p) / LN2
        }
        return entropy
    }

    fun printableAsciiRatio(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        var printable = 0
        for (i in offset until offset + length) {
            val b = data[i].toInt() and 0xFF
            if (b in 32..126 || b == 9 || b == 10 || b == 13) printable++
        }
        return printable.toDouble() / length
    }

    fun nullByteRatio(data: ByteArray, offset: Int = 0, length: Int = data.size): Double {
        if (length <= 0) return 0.0
        var zeros = 0
        for (i in offset until offset + length) if (data[i].toInt() == 0) zeros++
        return zeros.toDouble() / length
    }

    /** Fraction of 8-byte shingles in the window that repeat within the same window -
     *  a cheap proxy for "this looks like a table/records region" without running the
     *  full matcher over it. */
    fun repetitionRatio(data: ByteArray, offset: Int, length: Int): Double {
        if (length < 16) return 0.0
        val seen = HashSet<Long>()
        var repeats = 0
        var shingles = 0
        var i = offset
        val end = offset + length - 8
        while (i <= end) {
            var h = 0L
            for (k in 0 until 8) h = (h shl 8) or (data[i + k].toLong() and 0xFF)
            shingles++
            if (!seen.add(h)) repeats++
            i += 8
        }
        return if (shingles == 0) 0.0 else repeats.toDouble() / shingles
    }

    /** Max-over-candidate-strides "dominant delta" rate: for each stride s, histograms
     *  byte[k]-byte[k-s] and takes the frequency of its single most common value. This catches
     *  both exact repetition (dominant delta 0 - the same signal [repetitionRatio]'s shingle
     *  check is after) AND arithmetic/ramping periodicity (a *constant nonzero* delta dominating
     *  - e.g. a per-record counter field that increments by the same step every record), which an
     *  exact-equality check can't see at all. A fixed-width record whose only varying field is a
     *  monotonic counter repeats *structurally* every record even though no two records are byte-
     *  identical - see RegionClassifier's periodicity-blind-spot note for why that distinction
     *  matters. True random data has no dominant delta at any stride (~1/256 of samples per
     *  bucket, uniformly), so this stays near zero there. */
    fun periodicityRatio(data: ByteArray, offset: Int, length: Int): Double {
        val strides = intArrayOf(2, 3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 48, 64)
        var best = 0.0
        for (s in strides) {
            if (2 * s > length) continue
            val total = length - s
            val deltaCounts = IntArray(256)
            for (k in s until length) {
                val delta = ((data[offset + k].toInt() and 0xFF) - (data[offset + k - s].toInt() and 0xFF)) and 0xFF
                deltaCounts[delta]++
            }
            var maxCount = 0
            for (c in deltaCounts) if (c > maxCount) maxCount = c
            val ratio = maxCount.toDouble() / total
            if (ratio > best) best = ratio
        }
        return best
    }

    private const val LN2 = 0.6931471805599453
}
