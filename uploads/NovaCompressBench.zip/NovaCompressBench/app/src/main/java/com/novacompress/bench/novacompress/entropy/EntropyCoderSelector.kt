package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Runs both entropy coders over the same symbol stream and keeps whichever
 * produced the smaller output - the literal "benchmark multiple entropy
 * coders... choose automatically" behavior requested for NovaCompress,
 * scoped to the two coders implemented here (see [HuffmanCoder] for why ANS
 * isn't one of them in this pass).
 */
object EntropyCoderSelector {
    private const val TYPE_RANGE = 0
    private const val TYPE_HUFFMAN = 1

    fun encode(symbols: IntArray, alphabet: Int): ByteArray {
        val rangeBytes = encodeRange(symbols, alphabet)

        val counts = IntArray(alphabet)
        for (s in symbols) counts[s]++
        val huffmanTable = HuffmanCoder.build(counts)
        val huffmanBytes = huffmanTable?.let { encodeHuffman(symbols, it) }

        val useHuffman = huffmanBytes != null && huffmanBytes.size < rangeBytes.size
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            if (useHuffman) {
                d.writeByte(TYPE_HUFFMAN)
                d.write(huffmanBytes!!)
            } else {
                d.writeByte(TYPE_RANGE)
                d.write(rangeBytes)
            }
        }
        return out.toByteArray()
    }

    fun decode(bytes: ByteArray, symbolCount: Int, alphabet: Int): IntArray {
        val din = DataInputStream(ByteArrayInputStream(bytes))
        return when (val type = din.readUnsignedByte()) {
            TYPE_RANGE -> decodeRange(din, symbolCount, alphabet)
            TYPE_HUFFMAN -> decodeHuffman(din, symbolCount, alphabet)
            else -> throw IllegalStateException("Unknown entropy coder type tag: $type")
        }
    }

    private fun encodeRange(symbols: IntArray, alphabet: Int): ByteArray {
        val model = FreqModel(alphabet)
        val enc = RangeEncoder()
        for (s in symbols) enc.encode(model, s)
        val payload = enc.finish()
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            d.writeInt(payload.size)
            d.write(payload)
        }
        return out.toByteArray()
    }

    private fun decodeRange(din: DataInputStream, symbolCount: Int, alphabet: Int): IntArray {
        val len = din.readInt()
        val payload = ByteArray(len)
        din.readFully(payload)
        val model = FreqModel(alphabet)
        val dec = RangeDecoder(payload)
        return IntArray(symbolCount) { dec.decodeSymbol(model) }
    }

    private fun encodeHuffman(symbols: IntArray, table: HuffmanCoder.Table): ByteArray {
        val bits = HuffmanCoder.encode(symbols, table)
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            for (len in table.codeLengths) d.writeByte(len)
            d.writeInt(bits.size)
            d.write(bits)
        }
        return out.toByteArray()
    }

    private fun decodeHuffman(din: DataInputStream, symbolCount: Int, alphabet: Int): IntArray {
        val lengths = IntArray(alphabet) { din.readUnsignedByte() }
        val len = din.readInt()
        val bits = ByteArray(len)
        din.readFully(bits)

        // Rebuild canonical codes from the transmitted lengths (identical
        // derivation to HuffmanCoder.build's canonicalize step).
        val codes = LongArray(alphabet)
        val order = (0 until alphabet).filter { lengths[it] > 0 }.sortedWith(compareBy({ lengths[it] }, { it }))
        var code = 0L
        var prevLen = 0
        for (sym in order) {
            val l = lengths[sym]
            code = code shl (l - prevLen)
            codes[sym] = code
            code++
            prevLen = l
        }
        val table = HuffmanCoder.Table(lengths, codes, alphabet)
        return HuffmanCoder.decode(bits, table, symbolCount)
    }
}
