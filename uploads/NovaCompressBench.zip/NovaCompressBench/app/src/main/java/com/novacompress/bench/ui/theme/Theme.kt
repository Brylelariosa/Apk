package com.novacompress.bench.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = NovaTeal,
    onPrimary = NovaInk,
    secondary = NovaAmber,
    onSecondary = NovaInk,
    background = NovaCharcoal,
    onBackground = Color(0xFFE7E9EE),
    surface = NovaCharcoalElevated,
    onSurface = Color(0xFFE7E9EE),
    surfaceVariant = NovaSlate,
    onSurfaceVariant = Color(0xFFB8BCC8),
    error = ColorFail,
)

private val LightColors = lightColorScheme(
    primary = NovaTealDark,
    onPrimary = Color.White,
    secondary = NovaAmber,
    onSecondary = NovaInk,
    background = NovaFogLight,
    onBackground = NovaInk,
    surface = NovaFogElevated,
    onSurface = NovaInk,
    surfaceVariant = Color(0xFFE3E7ED),
    onSurfaceVariant = Color(0xFF44485A),
    error = ColorFail,
)

@Composable
fun NovaCompressTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = NovaTypography,
        content = content,
    )
}
