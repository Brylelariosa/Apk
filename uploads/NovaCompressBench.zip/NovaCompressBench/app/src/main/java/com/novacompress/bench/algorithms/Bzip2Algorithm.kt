package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream
import java.io.InputStream
import java.io.OutputStream

class Bzip2Algorithm : CompressionAlgorithm {
    override val id = "bzip2"
    override val displayName = "Bzip2"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable() = true

    override fun compress(input: InputStream, output: OutputStream) {
        BZip2CompressorOutputStream(output, 9).use { bos ->
            IoUtil.copyStream(input, bos)
        }
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        BZip2CompressorInputStream(input).use { bis ->
            IoUtil.copyStream(bis, output)
        }
    }
}
