package com.novacompress.bench.novacompress.entropy

/**
 * Adaptive symbol frequency table backing [RangeEncoder]/[RangeDecoder].
 * Both sides update this identically after every symbol, so no frequency
 * table ever needs to be transmitted - that's what makes adaptive coding
 * attractive here.
 *
 * Ported from a standalone Java prototype that was round-trip tested against
 * 45+ cases (uniform/skewed/adversarial distributions, empty/huge inputs)
 * before being adapted into this codebase - see README "Verification".
 */
class FreqModel(val n: Int) {
    val freq = IntArray(n) { 1 }
    val cumFreq = IntArray(n + 1)

    init {
        rebuildCum()
    }

    private fun rebuildCum() {
        var acc = 0
        for (i in 0 until n) {
            cumFreq[i] = acc
            acc += freq[i]
        }
        cumFreq[n] = acc
    }

    fun total(): Int = cumFreq[n]

    fun findSymbol(target: Int): Int {
        var lo = 0
        var hi = n
        while (lo + 1 < hi) {
            val mid = (lo + hi) ushr 1
            if (cumFreq[mid] <= target) lo = mid else hi = mid
        }
        return lo
    }

    fun update(sym: Int) {
        freq[sym] += INCREMENT
        if (total() > MAX_TOTAL) {
            for (i in 0 until n) freq[i] = (freq[i] + 1) / 2
        }
        rebuildCum()
    }

    companion object {
        const val MAX_TOTAL = 1 shl 15
        const val INCREMENT = 32
    }
}
