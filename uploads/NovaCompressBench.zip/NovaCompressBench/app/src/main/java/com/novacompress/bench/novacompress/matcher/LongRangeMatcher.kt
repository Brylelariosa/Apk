package com.novacompress.bench.novacompress.matcher

import com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary

/**
 * Finds repeated byte sequences across the whole buffer passed to
 * [tokenize] - not a small fixed sliding window like Deflate's 32KB, hence
 * "long-range". Matches are tried against the repeat-offset list first
 * (cheap to encode), then a whole-buffer hash table.
 *
 * Ported unchanged in structure from a Java prototype verified via 29
 * round-trip tests (edge cases, random data, repeated/text/JSON-like
 * structures, self-overlapping runs, fuzzed mixes) plus a 4MB correctness +
 * throughput check - see README "Verification". The only change from the
 * verified version is depending on [MultiLevelDictionary] for its state
 * instead of two bare local arrays, which is a naming/encapsulation change
 * only - the actual match-finding logic is untouched.
 */
object LongRangeMatcher {
    const val MIN_MATCH = 4
    private const val HASH_BITS = 17
    private const val HASH_SIZE = 1 shl HASH_BITS
    private const val MAX_MATCH = 1 shl 18
    private const val MIX_CONST = -1640531535 // 0x9E3779B1 as signed Int

    private fun hash4(d: ByteArray, i: Int): Int {
        var h = ((d[i].toInt() and 0xFF) shl 24) or
            ((d[i + 1].toInt() and 0xFF) shl 16) or
            ((d[i + 2].toInt() and 0xFF) shl 8) or
            (d[i + 3].toInt() and 0xFF)
        h *= MIX_CONST
        return (h ushr (32 - HASH_BITS)) and (HASH_SIZE - 1)
    }

    private fun matchLen(d: ByteArray, p: Int, i: Int, n: Int): Int {
        var len = 0
        val max = minOf(MAX_MATCH, n - i)
        while (len < max && d[p + len] == d[i + len]) len++
        return len
    }

    fun tokenize(data: ByteArray): List<Token> {
        val tokens = ArrayList<Token>()
        val n = data.size
        val dict = MultiLevelDictionary(HASH_BITS)
        val head = dict.head
        val rep = dict.repDistances

        var i = 0
        while (i < n) {
            var bestLen = 0
            var bestDist = 0

            if (i + MIN_MATCH <= n) {
                for (rd in rep) {
                    if (rd <= i) {
                        val len = matchLen(data, i - rd, i, n)
                        if (len >= MIN_MATCH && len > bestLen) {
                            bestLen = len; bestDist = rd
                        }
                    }
                }
                val h = hash4(data, i)
                val cand = head[h]
                if (cand >= 0) {
                    val len = matchLen(data, cand, i, n)
                    if (len >= MIN_MATCH && len > bestLen) {
                        bestLen = len; bestDist = i - cand
                    }
                }
                head[h] = i
            }

            if (bestLen >= MIN_MATCH) {
                tokens.add(Token.Match(bestDist, bestLen))

                if (bestDist != rep[0]) {
                    val idx = rep.indexOf(bestDist).let { if (it < 0) rep.size - 1 else it }
                    for (m in idx downTo 1) rep[m] = rep[m - 1]
                    rep[0] = bestDist
                }

                var p = i + 1
                while (p < i + bestLen && p + MIN_MATCH <= n) {
                    head[hash4(data, p)] = p
                    p += 4
                }
                i += bestLen
            } else {
                tokens.add(Token.Literal(data[i]))
                i++
            }
        }
        return tokens
    }
}
