package com.novacompress.bench.novacompress.matcher

import com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary

/**
 * Finds repeated byte sequences across the whole buffer passed to
 * [tokenize] - not a small fixed sliding window like Deflate's 32KB, hence
 * "long-range". Matches are tried against the repeat-offset list first
 * (cheap to encode), then a whole-buffer hash table.
 *
 * Originally ported unchanged in structure from a Java prototype verified
 * via 29 round-trip tests (edge cases, random data, repeated/text/JSON-like
 * structures, self-overlapping runs, fuzzed mixes) plus a 4MB correctness +
 * throughput check - see README "Verification". That version's dictionary
 * only ever remembered the single most-recent position per hash, and every
 * match was taken the moment it hit [MIN_MATCH] - both leave ratio on the
 * table against multi-candidate, lazy matchers like LZMA/Zstd. This version
 * walks a bounded hash *chain* ([MultiLevelDictionary.prev], up to
 * [MAX_CHAIN] candidates) instead of trusting only the newest occurrence,
 * and does one step of lazy-match lookahead (would starting one byte later
 * find something longer?) before committing - both changes contained to
 * this file and [MultiLevelDictionary]. Token semantics are unchanged: a
 * [Token.Match] still just says "copy this many bytes from this distance
 * back," so [MatchFieldCoder] and everything downstream needs no changes.
 *
 * ### Cost-aware candidate ranking
 *
 * Both the chain walk and the lazy lookahead above used to rank candidates
 * by raw byte length alone. That's blind to what a match actually costs to
 * encode: [MatchFieldCoder] writes a distance already in the repeat-offset
 * MRU cache as one cheap slot symbol, but a fresh distance costs a slot
 * symbol *plus* its raw extra bits (up to ~17-18 for this codec's typical
 * buffer sizes) - measured on `text.txt`/`executable.bin`, that side
 * channel alone was 76-94% of total output (BENCHMARKS.md, "matcher's
 * parsing strategy" - the follow-up this entry closes out). A textbook
 * fix is genuine cost-based (LZMA-style optimal) parsing, but an analytic
 * bit-cost model tried here first measurably *hurt* `executable.bin` - its
 * literal byte distribution is skewed enough (~87% of bytes drawn from a
 * ~10-value opcode alphabet, the rest near-uniform) that no single formula
 * for "cost of a literal byte" fit both it and text/JSON/table well; see
 * BENCHMARKS.md for the two formulations that were tried and reverted.
 * [rankScore] instead applies the one part of that reasoning too robust to
 * need calibration: a repeat-offset match is always at least as cheap to
 * encode as a fresh one, so it's worth accepting somewhat shorter -
 * [REPEAT_BONUS] bytes' worth - *provided it's not so short
 * ([REPEAT_BONUS_MIN_LEN]) that "somewhat shorter" stops being a safe bet*.
 * Never rejects a match outright (MIN_MATCH is still the only accept/reject
 * floor for anyone) - only which candidate wins when more than one
 * qualifies - which is what keeps it safe to apply uniformly instead of
 * needing the content-specific tuning the analytic approach did. Swept
 * against real encoded output across all six built-in benchmark fixtures
 * plus two embedded-table mixed-content fixtures (BENCHMARKS.md): these
 * constants were the strongest point found that never made any single
 * fixture worse than the unmodified matcher, only equal or smaller.
 */
object LongRangeMatcher {
    const val MIN_MATCH = 4
    private const val HASH_BITS = 17
    private const val HASH_SIZE = 1 shl HASH_BITS
    private const val MAX_MATCH = 1 shl 18
    private const val MAX_CHAIN = 64 // candidates walked per hash bucket; higher = better ratio, slower
    private const val MIX_CONST = -1640531535 // 0x9E3779B1 as signed Int

    // See "Cost-aware candidate ranking" above for how these were picked.
    private const val REPEAT_BONUS = 2
    private const val REPEAT_BONUS_MIN_LEN = 8

    private fun isRepeatDistance(distance: Int, rep: IntArray): Boolean {
        for (rd in rep) if (rd == distance) return true
        return false
    }

    /** Effective length used to rank match candidates against each other -
     *  a repeat-offset distance counts as [REPEAT_BONUS] bytes longer than
     *  it really is, once it's already at least [REPEAT_BONUS_MIN_LEN]
     *  bytes, since it costs less to encode than a fresh distance of the
     *  same raw length. Does not affect whether a match is accepted at all
     *  (see class KDoc) - only which of several candidates wins. */
    private fun rankScore(distance: Int, length: Int, rep: IntArray): Int =
        if (length >= REPEAT_BONUS_MIN_LEN && isRepeatDistance(distance, rep)) length + REPEAT_BONUS else length

    private fun hash4(d: ByteArray, i: Int): Int {
        var h = ((d[i].toInt() and 0xFF) shl 24) or
            ((d[i + 1].toInt() and 0xFF) shl 16) or
            ((d[i + 2].toInt() and 0xFF) shl 8) or
            (d[i + 3].toInt() and 0xFF)
        h *= MIX_CONST
        return (h ushr (32 - HASH_BITS)) and (HASH_SIZE - 1)
    }

    private fun matchLen(d: ByteArray, p: Int, i: Int, n: Int): Int {
        var len = 0
        val max = minOf(MAX_MATCH, n - i)
        while (len < max && d[p + len] == d[i + len]) len++
        return len
    }

    // See bestMatchAt's KDoc for why this exists instead of returning
    // Token.Match directly. Distance and length are both well within 32
    // bits for any realistic chunk size (CHUNK_SIZE is 16MB), so packing
    // them into one Long's two halves loses no information.
    private const val NO_MATCH = -1L
    private fun packMatch(dist: Int, len: Int): Long = (dist.toLong() shl 32) or (len.toLong() and 0xFFFFFFFFL)
    private fun unpackDist(packed: Long): Int = (packed ushr 32).toInt()
    private fun unpackLen(packed: Long): Int = packed.toInt()

    /**
     * Best match at [i] against the repeat-offset list and the hash chain
     * for [i]'s 4-byte prefix, walking up to [MAX_CHAIN] prior positions -
     * not just the single most recent one - so a closer-but-shorter repeat
     * can't hide a longer one further back. Candidates are ranked by
     * [rankScore], not raw length, so a repeat-offset candidate can win
     * against a modestly longer fresh one (see class KDoc). Always inserts
     * [i] into the chain as a side effect whenever there's room for a
     * 4-byte key, same as the original single-candidate version did.
     *
     * Returns a packed `(distance, length)` [Long] instead of a [Token.Match]
     * - see "Entry 5" in BENCHMARKS.md. [tokenize] calls this twice per
     * matched position (the match itself, plus a one-step lazy lookahead -
     * see below), and the lookahead's result is discarded whenever the
     * original match wins, which measured as the common case. Returning a
     * primitive here means that discarded candidate never allocates a
     * [Token] at all; one is only constructed once a match is actually kept.
     * [NO_MATCH] (`-1L`) is a safe sentinel: a real match's distance is
     * always >= 1, so a valid packed value can never collide with it.
     */
    private fun bestMatchAt(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1

        for (rd in rep) {
            if (rd <= i) {
                val len = matchLen(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) {
                        bestScore = score; bestLen = len; bestDist = rd
                    }
                }
            }
        }

        val h = hash4(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < MAX_CHAIN) {
            val len = matchLen(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) {
                    bestScore = score; bestLen = len; bestDist = dist
                }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i

        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    fun tokenize(data: ByteArray): List<Token> {
        // Token count can never exceed data.size (every token covers >= 1
        // byte), so this is a safe upper-bound pre-size that eliminates all
        // internal array-copy-on-resize as the list grows from empty to
        // (typically) hundreds of thousands or millions of entries - see
        // "Entry 5" in BENCHMARKS.md.
        val tokens = ArrayList<Token>(data.size)
        val n = data.size
        val dict = MultiLevelDictionary(HASH_BITS, n)
        val head = dict.head
        val prev = dict.prev
        val rep = dict.repDistances

        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchAt(data, i, n, head, prev, rep)
            pending = NO_MATCH

            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)

                // Lazy matching: a candidate starting one byte later is
                // usually worth more than the literal byte it costs to get
                // there, so peek ahead before committing (classic zlib-style
                // lookahead), ranked the same cost-aware way as bestMatchAt
                // so the lookahead can't undo its repeat-offset preference.
                // This call also inserts i+1 into the chain, so the
                // "remaining positions" loop below starts at i+2 to avoid
                // indexing it a second time.
                val next = bestMatchAt(data, i + 1, n, head, prev, rep)
                if (next != NO_MATCH) {
                    val nextLen = unpackLen(next)
                    val nextDist = unpackDist(next)
                    if (rankScore(nextDist, nextLen, rep) > rankScore(foundDist, foundLen, rep)) {
                        tokens.add(Token.Literal(data[i]))
                        i++
                        pending = next
                        continue
                    }
                }

                tokens.add(Token.Match(foundDist, foundLen))
                if (foundDist != rep[0]) {
                    val idx = rep.indexOf(foundDist).let { if (it < 0) rep.size - 1 else it }
                    for (m in idx downTo 1) rep[m] = rep[m - 1]
                    rep[0] = foundDist
                }

                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    val ph = hash4(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.Literal(data[i]))
                i++
            }
        }
        return tokens
    }
}
