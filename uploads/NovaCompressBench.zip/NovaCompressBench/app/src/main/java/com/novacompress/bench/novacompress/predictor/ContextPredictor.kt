package com.novacompress.bench.novacompress.predictor

/**
 * Predicts the next byte from what's already been reconstructed, in three
 * tiers, each tried only when the one before has no confident answer:
 *
 * 1. Exact-context table: a bounded hash table of single (predicted-byte,
 *    confidence) slots keyed on the exact (prevPrev, prev) byte pair - a
 *    simplified, deterministic relative of Misra-Gries heavy-hitter
 *    counting, rather than a full per-context 256-way histogram (64K
 *    contexts x 256 counts would cost far more memory for limited extra
 *    benefit). Wins on data with recurring *exact* 2-byte contexts (text,
 *    repeated records/templates) - but a single early observation locks in
 *    a guess at confidence 1, and on data where 2-byte contexts are mostly
 *    one-off (tier 2's whole reason to exist) that guess is close to
 *    noise. [TIER1_MIN_CONFIDENCE] makes tier 1 prove itself - confirmed
 *    right at least twice, not just guessed once - before it can shadow
 *    tiers 2/3; testing on image-like data showed a single unconfirmed
 *    guess was blocking tier 2 on ~9 out of every 10 positions where tier
 *    2 actually had the better answer.
 * 2. Fixed-stride table: tries "the byte N positions back" for a small set
 *    of candidate strides (2/3/4/8 - common record/pixel/word widths),
 *    each with its own adaptively-updated confidence score, and uses
 *    whichever candidate currently has the best track record. Wins on
 *    structured binary data with a fixed record width the matcher can't
 *    catch because it repeats byte-by-byte rather than in exact runs (e.g.
 *    interleaved image channels: byte N usually equals byte N-3, but
 *    rarely 4 bytes of that in a row - LongRangeMatcher's MIN_MATCH=4
 *    exact-run requirement never fires, but this does).
 * 3. Linear/delta fallback: predicted = 2*prev - prevPrev (mod 256) -
 *    assumes the current trend continues. Exact for constant-stride
 *    counters/gradients; a reasonable guess for anything smoothly-varying.
 *
 * A wrong guess here costs nothing beyond what an unpredicted literal
 * already costs - NovaSegmentCodec emits the literal byte value either
 * way, there's no separate "miss" symbol - so tiers 2 and 3 are pure
 * upside whenever tier 1 doesn't have a confirmed answer, which is why
 * this always returns *some* prediction rather than abstaining.
 *
 * This doubles as the spec's "Learning Component": every table here adapts
 * continuously as bytes stream through, with no cloud calls and no neural
 * network - just adaptive counters (plus the stateless linear fallback),
 * exactly as specified.
 *
 * Both encoder and decoder must call [update] after *every* reconstructed
 * byte (literals, prediction hits, and match-copied bytes alike) to stay in
 * lockstep - see NovaSegmentCodec, where this invariant is the single most
 * important correctness property of the whole pipeline. [predict] and
 * [update] only ever read [buffer] at indices strictly before [pos] - the
 * encoder (source data, already fully known) and the decoder (output
 * reconstructed so far) agree on every byte before [pos] by construction,
 * which is what keeps tier 2's stride lookups in lockstep too, the same way
 * tier 1's (prevPrev, prev) already was.
 */
class ContextPredictor {
    private val predicted = ByteArray(TABLE_SIZE)
    private val confidence = IntArray(TABLE_SIZE)
    private val strideScore = IntArray(STRIDES.size)

    private fun hash(prevPrev: Int, prev: Int): Int {
        val h = (prevPrev * MIX_A) xor (prev * MIX_B)
        return (h xor (h ushr 15)) and MASK
    }

    fun predict(buffer: ByteArray, pos: Int, prevPrev: Int, prev: Int): Byte {
        val h = hash(prevPrev, prev)
        if (confidence[h] >= TIER1_MIN_CONFIDENCE) return predicted[h]

        var bestIdx = -1
        var bestScore = 0
        for (i in STRIDES.indices) {
            val s = STRIDES[i]
            if (s <= pos && strideScore[i] > bestScore) {
                bestScore = strideScore[i]
                bestIdx = i
            }
        }
        if (bestIdx >= 0) return buffer[pos - STRIDES[bestIdx]]

        return ((2 * prev - prevPrev) and 0xFF).toByte()
    }

    fun update(buffer: ByteArray, pos: Int, prevPrev: Int, prev: Int, actual: Byte) {
        val h = hash(prevPrev, prev)
        if (predicted[h] == actual) {
            if (confidence[h] < 1000) confidence[h]++
        } else {
            confidence[h]--
            if (confidence[h] <= 0) {
                predicted[h] = actual
                confidence[h] = 1
            }
        }
        // Every candidate stride learns from every byte, regardless of
        // whether it was the one predict() picked - a wrong guess costs
        // nothing, so there's no reason to only track the winner.
        for (i in STRIDES.indices) {
            val s = STRIDES[i]
            if (s <= pos) {
                strideScore[i] = if (buffer[pos - s] == actual) {
                    minOf(1000, strideScore[i] + 4)
                } else {
                    maxOf(-1000, strideScore[i] - 1)
                }
            }
        }
    }

    companion object {
        private const val TABLE_SIZE = 1 shl 16
        private const val MASK = TABLE_SIZE - 1
        // Odd mixing constants for hash dispersion (bit patterns of
        // 0x9E3779B1 / 0x85EBCA77 written as signed decimals to avoid any
        // hex-literal Int/Long inference ambiguity). Only affects hash
        // spread/compression efficiency, not correctness - decoder and
        // encoder always compute the same value for the same context.
        private const val MIX_A = -1640531535
        private const val MIX_B = -2048144777

        private const val TIER1_MIN_CONFIDENCE = 3
        private val STRIDES = intArrayOf(2, 3, 4, 8)
    }
}
