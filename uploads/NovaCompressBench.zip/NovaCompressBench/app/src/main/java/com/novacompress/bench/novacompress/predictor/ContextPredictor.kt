package com.novacompress.bench.novacompress.predictor

/**
 * Predicts the next byte from the 2 preceding bytes using a bounded hash
 * table of single (predicted-byte, confidence) slots per context - a
 * simplified, deterministic relative of Misra-Gries heavy-hitter counting,
 * rather than a full per-context 256-way histogram (64K contexts x 256
 * counts would cost far more memory for limited extra benefit).
 *
 * This doubles as the spec's "Learning Component": the table adapts
 * continuously as bytes stream through, with no cloud calls and no neural
 * network - just an adaptive counter, exactly as specified.
 *
 * Both encoder and decoder must call [update] after *every* reconstructed
 * byte (literals, prediction hits, and match-copied bytes alike) to stay in
 * lockstep - see NovaSegmentCodec, where this invariant is the single most
 * important correctness property of the whole pipeline.
 */
class ContextPredictor {
    private val predicted = ByteArray(TABLE_SIZE)
    private val confidence = IntArray(TABLE_SIZE)

    private fun hash(prevPrev: Int, prev: Int): Int {
        val h = (prevPrev * MIX_A) xor (prev * MIX_B)
        return (h xor (h ushr 15)) and MASK
    }

    fun predict(prevPrev: Int, prev: Int): Byte = predicted[hash(prevPrev, prev)]

    fun update(prevPrev: Int, prev: Int, actual: Byte) {
        val h = hash(prevPrev, prev)
        if (predicted[h] == actual) {
            if (confidence[h] < 1000) confidence[h]++
        } else {
            confidence[h]--
            if (confidence[h] <= 0) {
                predicted[h] = actual
                confidence[h] = 1
            }
        }
    }

    companion object {
        private const val TABLE_SIZE = 1 shl 16
        private const val MASK = TABLE_SIZE - 1
        // Odd mixing constants for hash dispersion (bit patterns of
        // 0x9E3779B1 / 0x85EBCA77 written as signed decimals to avoid any
        // hex-literal Int/Long inference ambiguity). Only affects hash
        // spread/compression efficiency, not correctness - decoder and
        // encoder always compute the same value for the same context.
        private const val MIX_A = -1640531535
        private const val MIX_B = -2048144777
    }
}
