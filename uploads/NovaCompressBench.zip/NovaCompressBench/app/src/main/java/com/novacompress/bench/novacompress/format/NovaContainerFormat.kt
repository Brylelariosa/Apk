package com.novacompress.bench.novacompress.format

import com.novacompress.bench.novacompress.NovaEncodedBlock
import com.novacompress.bench.novacompress.NovaSegmentCodec
import com.novacompress.bench.novacompress.analyzer.FileAnalyzer
import com.novacompress.bench.novacompress.segment.Segment
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.novacompress.segment.Segmenter
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.OutputStream

data class ChunkResearchStats(
    val segments: List<Segment>,
    val symbolCount: Int,
    val tokenCount: Int,
    val matchTokenCount: Int,
    val predictHitCount: Int,
    val novaInputBytes: Int,
    val storeInputBytes: Int,
)

data class EncodedChunk(val bytes: ByteArray, val stats: ChunkResearchStats)

/** One independently-encoded [NovaSegmentCodec] block plus the byte length
 *  it was built from - [NovaEncodedBlock] itself doesn't carry that
 *  (NovaSegmentCodec.decode takes it as a separate argument), but the
 *  writer needs it on-disk to size the decode buffer, so it travels
 *  alongside the block from the moment it's produced. */
private data class BlockEntry(val block: NovaEncodedBlock, val originalLength: Int)

/**
 * On-disk format for a NovaCompress stream: a header, then a sequence of
 * length-framed chunks, then an end marker. Chunks are processed
 * independently (see [NovaCompressAlgorithm] for why), so [encodeChunk] is
 * a pure function - no stream state - safe to call concurrently from
 * multiple coroutines, with the caller responsible for writing results to
 * the output stream in order afterward.
 *
 * Within a chunk, each maximal run of consecutive NOVA-strategy segments
 * (as decided by [Segmenter]) becomes one or more independently-encoded
 * [NovaSegmentCodec] *blocks*, always in file order. A run of more than one
 * segment is trial-encoded two ways - as a single merged block sharing one
 * dictionary/entropy model, and as one block per segment - and whichever
 * produces fewer total bytes (including each block's own framing overhead)
 * is what's kept; see [encodeChunk]. STORE-strategy segments are verified
 * rather than trusted outright, per-segment: [encodeChunk] trial-compresses
 * each one and only keeps it as raw inline bytes if that's genuinely
 * smaller, promoting it into its own effective-NOVA block otherwise (see
 * [encodeChunk] for why the classifier can be wrong here). A segment's
 * metadata (classifier strategy, length, dominant kind, average entropy)
 * is always recorded for Research Mode reporting, even when its bytes end
 * up promoted into a block instead of staying inline.
 *
 * Versions 1 and earlier concatenated *every* NOVA-strategy segment in a
 * chunk into one shared block regardless of how many segments existed or
 * how different their content was, with STORE segments that traded up to a
 * block getting appended at the very end of that shared buffer rather than
 * at their actual position. That was harmless as long as a promoted STORE
 * segment was already last in the file - but for any chunk where it sat
 * between two NOVA segments, the decoder's single sequential read cursor
 * over that shared buffer silently desynced from segment order, corrupting
 * every byte from that segment onward (verified directly: a
 * text/repetitive-binary/random-bytes/executable-like mix - not a
 * contrived adversarial case, just four different kinds of content in one
 * file - reliably failed to round-trip under the old design; see
 * BENCHMARKS.md). Building one buffer per run, in file order, both fixes
 * that (a block only ever covers the exact segments it was built from, at
 * their real position) and is what makes segmentation decisions actually
 * able to affect the compressed output - a decode format version bump
 * either way, so the fix rides along with the segmentation rewrite that
 * exposed it rather than needing a separate one.
 */
object NovaContainerFormat {
    const val MAGIC = 0x4E564331 // ASCII "NVC1"
    const val VERSION = 2
    const val MARKER_MORE = 0xC1
    const val MARKER_END = 0xFF

    /** Fixed per-block on-disk framing written by [writeBlock]: 7 ints
     *  (originalLength, symbolCount, tokenCount, matchTokenCount,
     *  predictHitCount, entropyBytes.size, sideChannelBytes.size) around
     *  the two payloads. Exposed so the merge-vs-split trial in
     *  [encodeChunk] can weigh a real byte cost against the modeling
     *  benefit of splitting, not a guess. */
    private const val BLOCK_FRAME_OVERHEAD = 7 * 4

    fun writeHeader(out: DataOutputStream) {
        out.writeInt(MAGIC)
        out.writeByte(VERSION)
    }

    fun readAndVerifyHeader(din: DataInputStream) {
        val magic = din.readInt()
        require(magic == MAGIC) { "Not a NovaCompress stream (bad magic number)" }
        val version = din.readUnsignedByte()
        require(version == VERSION) { "Unsupported NovaCompress stream version: $version" }
    }

    fun writeEndMarker(out: DataOutputStream) {
        out.writeByte(MARKER_END)
    }

    private fun blockByteSize(block: NovaEncodedBlock): Int =
        BLOCK_FRAME_OVERHEAD + block.entropyBytes.size + block.sideChannelBytes.size

    /** Analyzes, segments, and compresses one chunk's raw bytes. Pure
     *  function - safe to run on any dispatcher/thread. */
    fun encodeChunk(chunkData: ByteArray): EncodedChunk {
        val regions = FileAnalyzer.analyze(chunkData)
        val segments = Segmenter.segment(regions)

        // Per-segment STORE-vs-promote trial - see class KDoc. Strictly
        // more accurate than pooling every STORE segment in the chunk
        // together before deciding (the old design): different STORE
        // regions can have different real compressibility, and a shared
        // pooled trial only sees their average.
        val effectiveNova = BooleanArray(segments.size)
        for (i in segments.indices) {
            val seg = segments[i]
            if (seg.strategy == SegmentStrategy.NOVA) {
                effectiveNova[i] = true
                continue
            }
            val segBytes = chunkData.copyOfRange(seg.offset, seg.offset + seg.length)
            val trial = NovaSegmentCodec.encode(segBytes)
            effectiveNova[i] = trial.entropyBytes.size + trial.sideChannelBytes.size < segBytes.size
        }

        // Group consecutive effective-NOVA segments into runs, then decide
        // per run whether merging into one block beats splitting into one
        // block per segment - an actual measurement, not a heuristic guess
        // (see class KDoc for why this matters and BENCHMARKS.md for the
        // sweep that picked Segmenter's constants).
        val blocks = ArrayList<BlockEntry>()
        var i = 0
        while (i < segments.size) {
            if (!effectiveNova[i]) {
                i++
                continue
            }
            var j = i
            while (j < segments.size && effectiveNova[j]) j++
            val run = segments.subList(i, j)

            if (run.size == 1) {
                val seg = run[0]
                val bytes = chunkData.copyOfRange(seg.offset, seg.offset + seg.length)
                blocks.add(BlockEntry(NovaSegmentCodec.encode(bytes), bytes.size))
            } else {
                val mergedBytes = ByteArrayOutputStream().apply {
                    for (seg in run) write(chunkData, seg.offset, seg.length)
                }.toByteArray()
                val mergedBlock = NovaSegmentCodec.encode(mergedBytes)
                val mergedSize = blockByteSize(mergedBlock)

                val splitEntries = run.map { seg ->
                    val bytes = chunkData.copyOfRange(seg.offset, seg.offset + seg.length)
                    BlockEntry(NovaSegmentCodec.encode(bytes), bytes.size)
                }
                val splitSize = splitEntries.sumOf { blockByteSize(it.block) }

                if (splitSize < mergedSize) {
                    blocks.addAll(splitEntries)
                } else {
                    blocks.add(BlockEntry(mergedBlock, mergedBytes.size))
                }
            }
            i = j
        }

        val out = ByteArrayOutputStream()
        val d = DataOutputStream(out)
        d.writeByte(MARKER_MORE)
        d.writeInt(chunkData.size)
        d.writeInt(segments.size)
        d.writeInt(blocks.size)
        for (entry in blocks) writeBlock(d, entry)
        for (i2 in segments.indices) {
            val seg = segments[i2]
            d.writeByte(if (effectiveNova[i2]) 1 else 0)
            d.writeInt(seg.length)
            d.writeByte(seg.dominantKind.ordinal)
            d.writeDouble(seg.avgEntropy)
            if (!effectiveNova[i2]) {
                d.write(chunkData, seg.offset, seg.length)
            }
        }

        var novaInputBytes = 0
        for (i3 in segments.indices) if (effectiveNova[i3]) novaInputBytes += segments[i3].length
        val stats = ChunkResearchStats(
            segments = segments,
            symbolCount = blocks.sumOf { it.block.symbolCount },
            tokenCount = blocks.sumOf { it.block.tokenCount },
            matchTokenCount = blocks.sumOf { it.block.matchTokenCount },
            predictHitCount = blocks.sumOf { it.block.predictHitCount },
            novaInputBytes = novaInputBytes,
            storeInputBytes = chunkData.size - novaInputBytes,
        )
        return EncodedChunk(out.toByteArray(), stats)
    }

    /** [NovaEncodedBlock.tokenCount] and [NovaEncodedBlock.predictHitCount]
     *  aren't used by [NovaSegmentCodec.decode] (only
     *  [NovaEncodedBlock.matchTokenCount] is - it tells
     *  [MatchFieldCoder.unpack] how many distance/length pairs to read),
     *  but [NovaEncodedBlock]'s constructor needs a value for every field,
     *  so [decodeChunk] reads all three back off the wire regardless. */
    private fun writeBlock(d: DataOutputStream, entry: BlockEntry) {
        val block = entry.block
        d.writeInt(entry.originalLength)
        d.writeInt(block.symbolCount)
        d.writeInt(block.tokenCount)
        d.writeInt(block.matchTokenCount)
        d.writeInt(block.predictHitCount)
        d.writeInt(block.entropyBytes.size)
        d.write(block.entropyBytes)
        d.writeInt(block.sideChannelBytes.size)
        d.write(block.sideChannelBytes)
    }

    /**
     * Reads and reconstructs ONE chunk from [din], writing its original
     * bytes to [output]. [din] must be positioned immediately after a
     * marker byte the caller already confirmed equals [MARKER_MORE].
     */
    fun decodeChunk(din: DataInputStream, output: OutputStream) {
        din.readInt() // originalChunkLength - informational only, reconstruction is driven by per-segment lengths below
        val segmentCount = din.readInt()
        val blockCount = din.readInt()

        val blocks = ArrayList<ByteArray>(blockCount)
        repeat(blockCount) {
            val originalLength = din.readInt()
            val symbolCount = din.readInt()
            val tokenCount = din.readInt()
            val matchTokenCount = din.readInt()
            val predictHitCount = din.readInt()
            val entropyLen = din.readInt()
            val entropyBytes = ByteArray(entropyLen)
            din.readFully(entropyBytes)
            val sideLen = din.readInt()
            val sideBytes = ByteArray(sideLen)
            din.readFully(sideBytes)
            val block = NovaEncodedBlock(symbolCount, entropyBytes, sideBytes, tokenCount, matchTokenCount, predictHitCount)
            blocks.add(NovaSegmentCodec.decode(block, originalLength))
        }

        // Blocks are consumed in file order, one at a time, advancing to
        // the next only once the current one is exhausted - this is what
        // keeps a segment's bytes correctly positioned regardless of how
        // many blocks encodeChunk decided to split its run into (see class
        // KDoc for why the old single-shared-buffer version of this loop
        // could desync).
        var blockIndex = 0
        var blockPos = 0
        repeat(segmentCount) {
            val strategy = din.readUnsignedByte()
            val length = din.readInt()
            din.readUnsignedByte() // dominantKind - reporting only
            din.readDouble() // avgEntropy - reporting only
            if (strategy == 0) {
                val raw = ByteArray(length)
                din.readFully(raw)
                output.write(raw)
            } else {
                var remaining = length
                while (remaining > 0) {
                    val current = blocks[blockIndex]
                    val available = current.size - blockPos
                    val take = minOf(available, remaining)
                    output.write(current, blockPos, take)
                    blockPos += take
                    remaining -= take
                    if (blockPos >= current.size) {
                        blockIndex++
                        blockPos = 0
                    }
                }
            }
        }
    }
}
