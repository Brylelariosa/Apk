package com.claudemanager.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityEvent
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.AppDatabase
import com.claudemanager.app.data.Prefs
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings
import com.claudemanager.app.data.displayName
import com.claudemanager.app.data.findByName
import com.claudemanager.app.notify.TimerScheduler
import com.claudemanager.app.util.IdleCheck
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val dao = db.dao()
    private val prefs = Prefs(app)

    val settings = MutableStateFlow(prefs.load())

    /** null until the first database read finishes. */
    val projects: StateFlow<List<Project>?> =
        dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), null)

    /** Sorted by name (the email), which is also the order of the account picker. */
    val accounts: StateFlow<List<Account>> =
        dao.observeAccounts()
            .map { list -> list.sortedBy { it.displayName.lowercase() } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    /** Ticks once a second, but only while the UI is visible. */
    val ticker: StateFlow<Long> =
        flow {
            while (true) {
                emit(System.currentTimeMillis())
                delay(1_000L)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(0L), System.currentTimeMillis())

    init {
        // Alarms are lost on reboot (BootReceiver covers that) and on force-stop, so every
        // app start puts them back as well.
        viewModelScope.launch { rescheduleAll() }
    }

    fun events(projectId: Long): Flow<List<ActivityEvent>> = dao.observeEvents(projectId)

    // ------------------------------------------------------------------
    // Activity status (never touches the timer)
    // ------------------------------------------------------------------

    fun setStatus(id: Long, status: ActivityStatus, customLabel: String = "") {
        mutate(id) { cur, t ->
            val label = if (status == ActivityStatus.CUSTOM) customLabel.trim() else ""
            if (cur.activityStatus == status && cur.customStatusLabel == label) {
                null
            } else {
                logEvent(id, status, label, t)
                cur.copy(
                    activityStatus = status,
                    customStatusLabel = label,
                    activityNote = "",
                    lastActivityChangeAt = t
                )
            }
        }
    }

    fun setNote(id: Long, note: String) {
        mutate(id) { cur, _ ->
            val text = note.trim()
            dao.setLatestEventNote(id, text)
            cur.copy(activityNote = text)
        }
    }

    // ------------------------------------------------------------------
    // Reset time (the alarm)
    // ------------------------------------------------------------------

    /** START: begin the default-length window and mark the project RUNNING. */
    fun start(id: Long) {
        mutate(id) { cur, t ->
            logEvent(id, ActivityStatus.RUNNING, "", t)
            cur.copy(
                activityStatus = ActivityStatus.RUNNING,
                customStatusLabel = "",
                activityNote = "",
                timerStartTimestamp = t,
                timerEndTimestamp = t + cur.defaultDurationMillis,
                lastStartedAt = t,
                lastActivityChangeAt = t
            )
        }
    }

    /** RESET: clear the timer only. The activity status stays as it is. */
    fun resetTimer(id: Long) {
        mutate(id) { cur, _ ->
            cur.copy(timerStartTimestamp = null, timerEndTimestamp = null)
        }
    }

    /** Set the reset as a clock time (for example 9:00 AM) without touching the status. */
    fun setResetAt(id: Long, endMillis: Long) {
        mutate(id) { cur, t ->
            val remaining = endMillis - t
            val start = if (remaining <= cur.defaultDurationMillis) endMillis - cur.defaultDurationMillis else t
            cur.copy(timerStartTimestamp = start, timerEndTimestamp = endMillis)
        }
    }

    fun toggleFavorite(id: Long) {
        mutate(id) { cur, _ -> cur.copy(favorite = !cur.favorite) }
    }

    // ------------------------------------------------------------------
    // Projects
    // ------------------------------------------------------------------

    fun saveProject(
        id: Long?,
        name: String,
        accountId: Long?,
        newAccountEmail: String?,
        durationMillis: Long
    ) {
        viewModelScope.launch {
            val saved: Project = db.withTransaction {
                var resolvedAccount = accountId
                if (!newAccountEmail.isNullOrBlank()) {
                    resolvedAccount = findOrCreateAccount(newAccountEmail)
                }
                val existing = if (id != null) dao.getProject(id) else null
                if (existing != null) {
                    val updated = existing.copy(
                        name = name.trim(),
                        accountId = resolvedAccount,
                        defaultDurationMillis = durationMillis
                    )
                    dao.updateProject(updated)
                    updated
                } else {
                    val created = Project(
                        name = name.trim(),
                        accountId = resolvedAccount,
                        defaultDurationMillis = durationMillis
                    )
                    created.copy(id = dao.insertProject(created))
                }
            }
            reschedule(saved)
        }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            db.withTransaction {
                val project = dao.getProject(id)
                val accountId = project?.accountId
                if (project != null && accountId != null) {
                    // The account was used through this project, so deleting it must not make the
                    // account look free at once: keep it in use for 5 hours (or until the project's
                    // reset time, if that is later).
                    val holdUntil = maxOf(now + IdleCheck.DELETE_HOLD_MILLIS, project.timerEndTimestamp ?: 0L)
                    dao.extendAccountHold(accountId, holdUntil)
                }
                dao.deleteEvents(id)
                dao.deleteProject(id)
            }
            TimerScheduler.cancel(app, id)
        }
    }

    fun clearHistory(projectId: Long) {
        viewModelScope.launch { dao.deleteEvents(projectId) }
    }

    // ------------------------------------------------------------------
    // Accounts
    // ------------------------------------------------------------------

    /** Adds an account (id == null) or changes the email of an existing one. */
    fun saveAccount(id: Long?, email: String) {
        val value = email.trim()
        if (value.isEmpty()) return
        viewModelScope.launch {
            db.withTransaction { upsertAccount(id, value) }
            rescheduleAll()
        }
    }

    /** Ends the hold after a deleted project, for example when it was deleted by mistake. */
    fun clearHold(accountId: Long) {
        viewModelScope.launch { dao.clearAccountHold(accountId) }
    }

    fun deleteAccount(id: Long) {
        viewModelScope.launch {
            db.withTransaction {
                dao.clearAccount(id)
                dao.deleteAccount(id)
            }
            rescheduleAll()
        }
    }

    // ------------------------------------------------------------------
    // Settings
    // ------------------------------------------------------------------

    fun updateSettings(newSettings: Settings) {
        val old = settings.value
        settings.value = newSettings
        prefs.save(newSettings)
        viewModelScope.launch {
            if (newSettings.historyLimit < old.historyLimit) {
                for (p in dao.getProjects()) dao.trimEvents(p.id, newSettings.historyLimit)
            }
            if (newSettings.notificationsEnabled != old.notificationsEnabled) {
                rescheduleAll()
            }
        }
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /**
     * Re-reads the project inside a transaction, applies [block], and saves the result.
     * Returning null from [block] means "nothing to change".
     */
    private fun mutate(id: Long, block: suspend (Project, Long) -> Project?) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val updated: Project? = db.withTransaction {
                val current = dao.getProject(id)
                if (current == null) {
                    null
                } else {
                    val next = block(current, now)
                    if (next != null) dao.updateProject(next)
                    next
                }
            }
            if (updated != null) reschedule(updated)
        }
    }

    private suspend fun logEvent(
        projectId: Long,
        status: ActivityStatus,
        customLabel: String,
        timestamp: Long,
        note: String = ""
    ) {
        dao.insertEvent(
            ActivityEvent(
                projectId = projectId,
                status = status,
                customLabel = customLabel,
                timestamp = timestamp,
                note = note
            )
        )
        dao.trimEvents(projectId, settings.value.historyLimit)
    }

    /**
     * Inserts or renames an account, unless another account already has that email. The dialog
     * blocks that case too; this keeps the list free of duplicates whatever calls it.
     */
    private suspend fun upsertAccount(id: Long?, email: String) {
        if (dao.getAccounts().findByName(email, exceptId = id) != null) return
        if (id == null) {
            dao.insertAccount(Account(email = email))
        } else {
            val current = dao.getAccount(id) ?: return
            // Also drops the old free-text name, which is no longer used.
            dao.updateAccount(current.copy(label = "", email = email))
        }
    }

    /** The id of the account that already has this email, or of a new one. */
    private suspend fun findOrCreateAccount(email: String): Long {
        val value = email.trim()
        return dao.getAccounts().findByName(value)?.id ?: dao.insertAccount(Account(email = value))
    }

    private suspend fun reschedule(project: Project) {
        val accountName = project.accountId?.let { dao.getAccount(it)?.displayName }
        TimerScheduler.schedule(app, project, accountName, settings.value.notificationsEnabled)
    }

    private suspend fun rescheduleAll() = TimerScheduler.rescheduleAll(app)
}
