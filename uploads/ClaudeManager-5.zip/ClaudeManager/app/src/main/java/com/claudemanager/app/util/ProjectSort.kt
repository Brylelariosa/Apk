package com.claudemanager.app.util

import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.SortConfig
import com.claudemanager.app.data.SortGroup

/**
 * Orders the project list the way the user set it up (see [SortConfig]).
 *
 *   1. A project is listed in the first enabled group that fits it. Groups appear in the user's
 *      order, and projects that fit no group come last.
 *   2. Inside a group: starred first, then reset time reached (newest first), then the soonest
 *      reset, then projects with no reset time. Account and project name break any tie.
 *
 * FINISHED projects never count as "reset reached" or "almost reset": their account is free
 * again, but there is nothing left to resume.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object ProjectSort {

    /** [titleOf] is the text the list is alphabetised by (the account name, then the project). */
    fun sorted(
        projects: List<Project>,
        config: SortConfig,
        now: Long,
        titleOf: (Project) -> String
    ): List<Project> {
        val groups = config.active
        val soonMs = config.almostResetMinutes * 60_000L

        // Work out each project's group and title once, not once per comparison.
        val keyed = projects.map { p ->
            val index = groups.indexOfFirst { group -> fits(group, p, now, soonMs) }
            Keyed(p, if (index >= 0) index else groups.size, titleOf(p).lowercase())
        }

        return keyed
            .sortedWith(
                compareBy<Keyed> { it.rank }
                    .thenByDescending { it.project.favorite }
                    .thenBy { timeKey(it.project, now) }
                    .thenBy { it.title }
                    .thenBy { it.project.name.lowercase() }
            )
            .map { it.project }
    }

    private class Keyed(val project: Project, val rank: Int, val title: String)

    private fun fits(group: SortGroup, p: Project, now: Long, soonMs: Long): Boolean {
        val end = p.timerEndTimestamp
        val finished = p.activityStatus == ActivityStatus.FINISHED
        return when (group) {
            SortGroup.RESET_DONE -> !finished && end != null && end <= now
            SortGroup.RESET_SOON -> !finished && end != null && end > now && end - now <= soonMs
            else -> p.activityStatus == group.status
        }
    }

    /** Reset reached (newest first), then the soonest reset, then no reset time at all. */
    private fun timeKey(p: Project, now: Long): Long {
        val end = p.timerEndTimestamp ?: return Long.MAX_VALUE
        return if (end <= now) -end else end
    }
}
