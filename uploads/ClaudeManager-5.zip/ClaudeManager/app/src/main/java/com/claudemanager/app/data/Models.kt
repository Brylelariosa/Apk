package com.claudemanager.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

/**
 * What the project is doing right now. This is completely independent of the
 * countdown timer: changing the status never touches the timer fields.
 */
enum class ActivityStatus {
    READY, RUNNING, BUILDING, TESTING, WAITING, FINISHED, ERROR, CUSTOM
}

/**
 * A Claude account, identified by its email. [label] is the old free-text name from before accounts
 * were identified by email alone: it is no longer asked for, and only shows when [email] is empty.
 * Always read the name through [displayName] so the two can never disagree.
 */
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val label: String = "",
    val email: String = "",
    /**
     * Set when a project of this account is deleted: the account counts as in use until this time,
     * so deleting a project never makes the account look free at once. null = no hold.
     */
    val holdUntil: Long? = null
)

/** What an account is called everywhere in the app: its email. */
val Account.displayName: String
    get() = email.trim().ifEmpty { label.trim() }

/** The account that already goes by [name] (ignoring case, and [exceptId]), or null when it is free. */
fun List<Account>.findByName(name: String, exceptId: Long? = null): Account? {
    val wanted = name.trim()
    return firstOrNull { it.id != exceptId && it.displayName.equals(wanted, ignoreCase = true) }
}

@Entity(tableName = "projects", indices = [Index("accountId")])
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val accountId: Long? = null,
    val defaultDurationMillis: Long,
    val timerStartTimestamp: Long? = null,
    val timerEndTimestamp: Long? = null,
    val activityStatus: ActivityStatus = ActivityStatus.READY,
    val customStatusLabel: String = "",
    val activityNote: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastStartedAt: Long? = null,
    val lastActivityChangeAt: Long? = null,
    /**
     * Legacy column from the removed "wait time" feature (database v2). Nothing reads or writes it
     * any more; it stays only so existing databases keep opening without a table rebuild.
     */
    val waitUntil: Long? = null
)

@Entity(tableName = "activity_events", indices = [Index("projectId")])
data class ActivityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: Long,
    val status: ActivityStatus,
    val customLabel: String = "",
    val timestamp: Long,
    val note: String = ""
)

class Converters {
    @TypeConverter
    fun statusToString(status: ActivityStatus): String = status.name

    @TypeConverter
    fun stringToStatus(value: String): ActivityStatus =
        try {
            ActivityStatus.valueOf(value)
        } catch (e: IllegalArgumentException) {
            ActivityStatus.READY
        }
}
