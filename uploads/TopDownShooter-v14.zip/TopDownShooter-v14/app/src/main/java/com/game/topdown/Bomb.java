package com.game.topdown;

public class Bomb {
    public float  x, y;
    public float  vx, vy;           // throw velocity (world px/sec)
    public float  spawnX, spawnY;   // where it was thrown from
    public float  maxRange;          // landing distance cap (scales with throw power)
    public boolean hasLanded;
    public int    ownerId;
    public long   deployTime;
    public long   explodedAt = -1;

    public static final float RADIUS      = 130f;
    public static final int   DAMAGE      = 80;
    public static final long  FUSE_MS     = 2500;
    public static final long  FLASH_MS    = 400;
    public static final float THROW_SPEED = 560f;   // px/sec at full joystick push
    public static final float THROW_RANGE = 500f;   // max range at full power

    public Bomb(float x, float y, int ownerId) {
        this.x = x;  this.y = y;
        this.spawnX = x; this.spawnY = y;
        this.ownerId = ownerId;
        this.maxRange = THROW_RANGE;   // default; override with power scaling
        this.deployTime = System.currentTimeMillis();
    }

    public float traveledSq() {
        float dx = x - spawnX, dy = y - spawnY;
        return dx * dx + dy * dy;
    }

    public boolean shouldExplode() {
        return explodedAt < 0 && System.currentTimeMillis() - deployTime >= FUSE_MS;
    }
    public boolean isFlashing() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt < FLASH_MS;
    }
    public boolean isDone() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt >= FLASH_MS;
    }
}
