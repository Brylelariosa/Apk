package com.novaenhance.ai.ai.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UpscalePlanTest {

    @Test
    fun `a manga panel keeps the full 4x`() {
        assertEquals(4, UpscalePlan.effectiveFactor(512, 658, 4))
    }

    @Test
    fun `a 720p frame keeps 4x`() {
        assertEquals(4, UpscalePlan.effectiveFactor(1280, 720, 4))
    }

    @Test
    fun `a 1080p frame steps down to 3x because 4x would be over the draw limit`() {
        // 1920*1080*16 = 33.2 MP > 25 MP; *9 = 18.7 MP fits.
        assertEquals(3, UpscalePlan.effectiveFactor(1920, 1080, 4))
    }

    @Test
    fun `a 12 MP camera photo is not upscaled at all`() {
        assertEquals(1, UpscalePlan.effectiveFactor(4000, 3000, 2))
        assertEquals(1, UpscalePlan.effectiveFactor(4000, 3000, 4))
    }

    @Test
    fun `a 6 MP photo can still be doubled`() {
        assertEquals(2, UpscalePlan.effectiveFactor(3000, 2000, 4))
    }

    @Test
    fun `requesting 1x or less always means 1x`() {
        assertEquals(1, UpscalePlan.effectiveFactor(100, 100, 1))
        assertEquals(1, UpscalePlan.effectiveFactor(100, 100, 0))
        assertEquals(1, UpscalePlan.effectiveFactor(100, 100, -3))
    }

    @Test
    fun `the result never exceeds the output cap unless the source itself does`() {
        val sizes = listOf(1 to 1, 64 to 64, 512 to 658, 1080 to 1920, 3000 to 2000, 4000 to 3000, 6000 to 4000, 9000 to 9000)
        for ((w, h) in sizes) {
            for (requested in 1..4) {
                val factor = UpscalePlan.effectiveFactor(w, h, requested)
                assertTrue("factor in range for ${w}x$h @$requested", factor in 1..requested)
                val output = w.toLong() * h * factor * factor
                assertTrue("${w}x$h @$requested -> x$factor = $output px", factor == 1 || output <= UpscalePlan.MAX_OUTPUT_PIXELS)
            }
        }
    }

    @Test
    fun `the cap really is under Android's 100 MB single-bitmap draw limit`() {
        assertTrue(UpscalePlan.MAX_OUTPUT_PIXELS * 4 <= 100L * 1024 * 1024)
    }
}
