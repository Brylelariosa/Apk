package com.novaenhance.ai.ai.engine

import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.delay

/**
 * Thermal pacing shared by every band-by-band image stage ([BandProcessor]'s neural/denoise pass and
 * [UpscaleStage]'s resample+sharpen pass), so a manual "Enhance" on a hot phone backs off the same way no matter
 * which stage it is in - and so that rule lives in exactly one place.
 *
 * Call [threadsForNextBand] before each band: it waits out whatever cool-down [thermalGovernor] asks for and
 * returns the thread budget that band may use ([thermalGovernor] can only narrow `threadCeiling`, never widen
 * it). Without a governor it returns `threadCeiling` untouched.
 */
internal class BandPacer(private val thermalGovernor: ThermalGovernor?) {

    /** Bands that had to wait on a thermal cool-down so far. */
    var pacedBands: Int = 0
        private set

    suspend fun threadsForNextBand(threadCeiling: Int): Int {
        val governor = thermalGovernor ?: return threadCeiling
        val decision = governor.evaluate(concurrencyCeiling = threadCeiling)
        when (decision.action) {
            // There is no meaningful "pause" for one image mid-flight - back off as hard as the worst
            // COOL_DOWN case instead of abandoning the result.
            ThermalGovernor.ThrottleAction.PAUSE -> {
                pacedBands++
                delay(Constants.THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS)
            }
            ThermalGovernor.ThrottleAction.COOL_DOWN -> {
                pacedBands++
                delay(decision.cooldownMillis)
            }
            ThermalGovernor.ThrottleAction.PROCEED -> Unit
        }
        return decision.maxConcurrency
    }
}
