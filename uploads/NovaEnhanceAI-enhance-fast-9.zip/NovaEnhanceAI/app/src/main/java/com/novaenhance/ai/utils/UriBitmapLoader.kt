package com.novaenhance.ai.utils

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.OpenableColumns
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Loads photos the user picked (content [Uri]s from the photo picker, the camera or a file browser) - the
 * counterpart of BitmapDecoding.kt, which loads files this app already owns by path.
 *
 * Uses [ImageDecoder] first because, unlike `BitmapFactory.decodeStream`, it applies the photo's EXIF
 * orientation: a portrait photo taken on a phone is stored sideways with a rotation tag, and decoding it without
 * honouring the tag produced an enhanced result that came out rotated. It also downsamples while decoding, so an
 * oversized photo is never fully materialised. `BitmapFactory` stays as a fallback for the few inputs
 * ImageDecoder rejects.
 */

/**
 * Pixel ceiling for a photo that is about to be enhanced: 24 MP (e.g. 6000x4000) = 96 MB of ARGB_8888, which is
 * deliberately just under Android's 100 MB limit for drawing a single bitmap (`RecordingCanvas.throwIfCannotDraw`
 * throws above it - see UpscalePlan). It also bounds memory: enhancing needs the source plus a same-size result at
 * once. A 48 or 108 MP phone-camera original is therefore decoded at reduced size instead of crashing the preview
 * or running out of memory; everything below the ceiling, including every ordinary camera photo, is decoded at full
 * resolution.
 */
const val MAX_ENHANCE_SOURCE_PIXELS = 24_000_000L

/**
 * Decodes [uri] to an ARGB_8888 software bitmap suitable for `Bitmap.getPixels` (never a hardware bitmap),
 * EXIF-rotated, and no larger than [maxPixels]. Returns null if the image can't be read. Blocking: call off the
 * main thread.
 */
fun decodeUriBitmap(context: Context, uri: Uri, maxPixels: Long = MAX_ENHANCE_SOURCE_PIXELS): Bitmap? {
    val resolver = context.contentResolver
    return try {
        decodeWithImageDecoder(resolver, uri, maxPixels)
    } catch (t: Throwable) {
        NovaLog.w("UriBitmapLoader", "ImageDecoder could not read $uri, falling back to BitmapFactory", t)
        decodeWithBitmapFactory(resolver, uri, maxPixels)
    }
}

/**
 * A small preview of [uri] whose longest side is at most [maxSidePx], or null if it can't be read. Blocking: call
 * off the main thread.
 */
fun decodeUriThumbnail(context: Context, uri: Uri, maxSidePx: Int): Bitmap? = try {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
        val width = info.size.width
        val height = info.size.height
        val longest = max(width, height)
        if (longest > maxSidePx) {
            val scale = maxSidePx.toFloat() / longest
            decoder.setTargetSize(max(1, (width * scale).toInt()), max(1, (height * scale).toInt()))
        }
    }
} catch (t: Throwable) {
    null
}

/** The file name the provider reports for [uri] (e.g. "IMG_0042.jpg"), or null if it doesn't report one. */
fun queryDisplayName(context: Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
} catch (t: Throwable) {
    null
}

private fun decodeWithImageDecoder(resolver: ContentResolver, uri: Uri, maxPixels: Long): Bitmap {
    val source = ImageDecoder.createSource(resolver, uri)
    val decoded = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        // Software memory: the enhancer reads pixels with Bitmap.getPixels, which a hardware bitmap forbids.
        decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
        val width = info.size.width
        val height = info.size.height
        val pixels = width.toLong() * height.toLong()
        if (pixels > maxPixels) {
            val scale = sqrt(maxPixels.toDouble() / pixels.toDouble())
            decoder.setTargetSize(max(1, (width * scale).toInt()), max(1, (height * scale).toInt()))
        }
    }
    return asArgb8888(decoded)
}

/** Wide-gamut / 16-bit sources decode to RGBA_F16; the pipeline works on 8-bit ARGB, so convert once up front. */
private fun asArgb8888(bitmap: Bitmap): Bitmap {
    if (bitmap.config == Bitmap.Config.ARGB_8888) return bitmap
    val converted = bitmap.copy(Bitmap.Config.ARGB_8888, false)
    bitmap.recycle()
    return converted ?: error("Could not convert the decoded photo to ARGB_8888")
}

private fun decodeWithBitmapFactory(resolver: ContentResolver, uri: Uri, maxPixels: Long): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        null
    } else {
        var sampleSize = 1
        while ((bounds.outWidth.toLong() / sampleSize) * (bounds.outHeight.toLong() / sampleSize) > maxPixels) sampleSize *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }
} catch (t: Throwable) {
    null
}
