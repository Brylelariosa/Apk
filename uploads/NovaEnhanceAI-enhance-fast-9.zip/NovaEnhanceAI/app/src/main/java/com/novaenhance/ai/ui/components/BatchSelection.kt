package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.ui.viewmodel.BatchItem
import com.novaenhance.ai.ui.viewmodel.BatchItemStatus
import com.novaenhance.ai.ui.viewmodel.BatchUiState
import com.novaenhance.ai.utils.decodeUriThumbnail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val ThumbnailSize = 72.dp

/**
 * A horizontally scrolling strip with one thumbnail per selected photo. Tapping one makes it the photo shown in
 * the before/after preview; the active one is outlined, and each carries a small status badge once a batch run
 * has started working on it. [enabled] is false while a batch runs, so the preview can't be switched under it.
 */
@Composable
fun BatchThumbnailStrip(
    items: List<BatchItem>,
    activeIndex: Int,
    enabled: Boolean,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    // Keep the active (or, during a run, the working) photo in view.
    val focusIndex = items.indexOfFirst { it.status == BatchItemStatus.WORKING }.takeIf { it >= 0 } ?: activeIndex
    LaunchedEffect(focusIndex, items.size) {
        if (focusIndex in items.indices) listState.animateScrollToItem(focusIndex)
    }
    LazyRow(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(items, key = { index, item -> "$index|${item.uri}" }) { index, item ->
            BatchThumbnail(
                item = item,
                selected = index == activeIndex,
                enabled = enabled,
                onClick = { onSelect(index) }
            )
        }
    }
}

/**
 * The "Enhance & save all" control for a multi-photo selection: the button before a run, and while one is running
 * the overall progress with a Cancel button. [BatchUiState.summary] (what was saved / what failed) is shown
 * underneath once there is one.
 */
@Composable
fun BatchRunPanel(
    batch: BatchUiState,
    onEnhanceAll: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (batch.isRunning) {
            val working = batch.items.indexOfFirst { it.status == BatchItemStatus.WORKING }
            val position = if (working >= 0) working + 1 else (batch.doneCount + batch.failedCount + 1).coerceAtMost(batch.items.size)
            Text("Enhancing photo $position of ${batch.items.size}…", style = MaterialTheme.typography.bodyMedium)
            LinearProgressIndicator(progress = { batch.overallFraction }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        } else {
            Button(onClick = onEnhanceAll, modifier = Modifier.fillMaxWidth()) {
                Text("Enhance & save all ${batch.items.size} photos")
            }
            Text(
                "Uses the settings above for every photo and saves each result to your Gallery.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        batch.summary?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
private fun BatchThumbnail(item: BatchItem, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .size(ThumbnailSize)
            .clip(shape)
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                shape = shape
            )
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        UriThumbnail(uri = item.uri, size = ThumbnailSize)
        StatusBadge(item.status, modifier = Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun StatusBadge(status: BatchItemStatus, modifier: Modifier = Modifier) {
    when (status) {
        BatchItemStatus.PENDING -> Unit
        BatchItemStatus.WORKING -> Box(
            modifier = modifier
                .padding(4.dp)
                .size(22.dp)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
        }
        BatchItemStatus.DONE -> StatusPill("Done", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary, modifier)
        BatchItemStatus.FAILED -> StatusPill("Failed", MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.onError, modifier)
    }
}

@Composable
private fun StatusPill(text: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = foreground,
        modifier = modifier
            .padding(4.dp)
            .background(background, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

/**
 * Small preview of a picked photo ([uri] is a content URI, not a file - see ThumbnailImage for the on-disk
 * counterpart). Decodes a downsampled thumbnail off the main thread; a photo that can't be read just leaves the
 * plain background rather than looking alarming.
 */
@Composable
fun UriThumbnail(uri: Uri, modifier: Modifier = Modifier, size: Dp = ThumbnailSize) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri) {
        bitmap = null
        failed = false
        val decoded = withContext(Dispatchers.IO) { decodeUriThumbnail(context, uri, maxSidePx = 216) } // ~3x a 72dp box for hi-dpi screens
        if (decoded == null) failed = true else bitmap = decoded
    }

    Box(
        modifier = modifier
            .size(size)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        when {
            current != null -> Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(size),
                contentScale = ContentScale.Crop
            )
            failed -> Unit
            else -> CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}
