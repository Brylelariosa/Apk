package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.ComputeBudget
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max

/**
 * The single entry point the UI and validator both call to actually enhance
 * an image. Design split, spelled out because it's easy to lose track of
 * which layer does what:
 *
 *  - [NovaModelEngine] (the *learned* part): a CNN pass over whole bands of the
 *    image - multi-threaded and seam-free - that does denoise + sharpen +
 *    detail-restore + artifact-removal in one shot, and is the thing that
 *    literally gets better as the user trains it.
 *  - [NativeImageProcessor] (the *classical*, non-learned part): manual
 *    sharpen/denoise/saturation controls layered on top of the AI's output,
 *    so a user can nudge the result even between training sessions, and so
 *    "Upscaling" (which the learned model does not do - it's a fixed
 *    tile-size restoration model, not a super-resolution model) has an
 *    honest implementation rather than a fabricated claim.
 *  - [UpscaleStage]: Lanczos-3 resampling + edge-aware sharpening for the 2x/4x
 *    options. The sharpening happens ONCE, at the final resolution, on the
 *    resampled pixels - sharpening the small image first and again after the
 *    resize (what the bilinear-based pipeline did) only amplified compression
 *    noise twice.
 *  - [BandProcessor]: keeps peak memory bounded regardless of source image
 *    resolution, hands every band its true neighbouring rows as context (so
 *    there are no tile seams), and (given [thermalGovernor]) paces itself under
 *    thermal pressure - this is what makes a manual "Enhance" tap on a large
 *    photo back off the same way training's internal validation/rescoring
 *    passes do, since both go through this same class.
 */
class EnhancementEngine(
    private val modelEngine: NovaModelEngine,
    private val thermalGovernor: ThermalGovernor? = null
) {
    companion object {
        // Shared across every EnhancementEngine instance (a new one is created
        // per enhancement request - see EnhanceViewModel.runEnhancement), so
        // it actually bounds concurrent expensive processing globally instead
        // of per-request. Without this, the per-request thread budget
        // (ComputeBudget.enhancementThreads) only ever bounded ONE
        // request's own work - two overlapping requests (an old one not yet
        // stopped, plus a new one) each got their own independent budget, so
        // native work could still run for both at once even with the
        // generation/isStale checks in place (those stop a stale request from
        // *publishing*, and bound how long it keeps working before noticing
        // it's stale, but never stopped it from running *concurrently* with a
        // newer one in the meantime).
        //
        // A coroutine Mutex (not a thread lock) so acquiring it suspends the
        // calling coroutine without blocking a thread - enhance() already
        // only ever runs on Dispatchers.Default (see EnhanceViewModel), never
        // the main thread, so this doesn't introduce any new main-thread risk.
        private val nativeProcessingGate = Mutex()

        // Vertical reach, in rows, of each classical filter the pipeline layers on top of the network. They
        // mirror filters/convolution.cpp (bilateral window radius 2) and decide how many real context rows
        // every band needs so that band edges come out exactly as a whole-image pass would. The sharpen's own
        // reach is asked of the native code (NativeImageProcessor.sharpenReachRows) rather than duplicated here.
        private const val BILATERAL_RADIUS_PX = 2
        private const val DENOISE_SPATIAL_SIGMA = 1.5f

        // How the 0..1 Sharpness slider maps to the edge-aware sharpen's detail gain. The gate and the local
        // min/max clamp already remove most of what a plain unsharp mask would add, so the same slider position
        // needs a larger gain than the old unsharp amount (1.0 -> 1.6 at 1x, 2.0 once upscaled, where edges are
        // spread over several pixels and need more help). Tuned on manga line art and photos with
        // tools/upscale_verification's reference numbers; see README "Upscaling and sharpening".
        private const val SHARPEN_GAIN_1X = 1.6f
        private const val SHARPEN_GAIN_UPSCALED = 2.0f

        /** Sharpening for the 1x path, applied band-wise on the AI pass's output. */
        internal fun sharpenSpecFor1x(sharpness: Float): SharpenSpec =
            if (sharpness <= 0f) SharpenSpec.NONE
            else SharpenSpec(amount = sharpness * SHARPEN_GAIN_1X, sigma = 1.0f, overshoot = 0.05f, clampRadius = 1)

        /** Sharpening for the upscaled path, applied at the OUTPUT resolution (so sigma and radius scale with it). */
        internal fun sharpenSpecForUpscale(sharpness: Float, factor: Int): SharpenSpec =
            if (sharpness <= 0f) SharpenSpec.NONE
            else SharpenSpec(
                amount = sharpness * SHARPEN_GAIN_UPSCALED,
                sigma = 0.5f * factor,
                overshoot = SharpenSpec.DEFAULT_OVERSHOOT,
                clampRadius = max(1, factor / 2)
            )

        /**
         * Context rows the AI pass needs: the network plus whichever optional filters are enabled. [sharpen] is
         * the 1x sharpening to apply inside the pass ([SharpenSpec.NONE] when the sharpening is deferred until
         * after an upscale).
         */
        private fun aiPassContextRows(options: EnhancementOptions, sharpen: SharpenSpec): Int =
            NativeNeuralEngine.RECEPTIVE_FIELD_RADIUS_PX +
                (if (options.noiseReduction > 0f) BILATERAL_RADIUS_PX else 0) +
                NativeImageProcessor.sharpenReachRows(sharpen)
    }

    private val bandProcessor = BandProcessor(thermalGovernor = thermalGovernor)
    private val upscaleStage = UpscaleStage(thermalGovernor)

    data class EnhanceProgress(val fraction: Float, val stage: Stage) {
        enum class Stage { AI_TILES, UPSCALING, FINISHING }
    }

    suspend fun enhance(
        source: Bitmap,
        options: EnhancementOptions,
        onProgress: ((EnhanceProgress) -> Unit)? = null,
        // Checked before starting, between the AI pass and the upscale
        // pass, and (inside BandProcessor) between bands - so a
        // request superseded by a newer slider change stops within at most
        // one band's worth of native work instead of running the full
        // image to completion. This exists BECAUSE coroutine cancellation
        // alone can't do this: a native JNI call already in flight keeps
        // running to completion regardless of job.cancel() - see
        // EnhanceViewModel.runEnhancement for where this is wired to an
        // actual generation counter. Default `{ false }` preserves the
        // previous unconditional-completion behavior for any other caller
        // (e.g. ModelValidator's before/after comparison passes, which have
        // their own, separate TrainingControlFlow-based cancellation).
        isStale: () -> Boolean = { false }
    ): Bitmap {
        if (isStale()) throw CancellationException("Enhancement superseded before starting")

        // Everything below - the AI pass and, if applicable, the
        // upscale+resharpen pass - is exactly the "expensive processing" that
        // must not overlap with another request's. Held for the whole call,
        // not re-acquired per stage, so an old request's upscale/resharpen
        // work can't overlap a new request's AI-tile work either. withLock
        // (rather than manual lock()/unlock()) guarantees the gate is
        // released on every exit path, including the isStale() throws below
        // and any exception from deeper in the pipeline - there is no path
        // through this block that can leave it held.
        return nativeProcessingGate.withLock {
            // Re-checked now that this request actually holds the gate: it may
            // have been superseded by a newer one while waiting its turn, and
            // there is no reason to make it start expensive work now, only to
            // have its own isStale checks catch it a moment later.
            if (isStale()) throw CancellationException("Enhancement superseded while waiting for the native-processing gate")

            val threadCeiling = ComputeBudget.enhancementThreads(Runtime.getRuntime().availableProcessors())
            val startMs = System.currentTimeMillis()

            // What the photo can actually afford (see UpscalePlan) - decided BEFORE the AI pass because it also
            // decides where the sharpening happens: at 1x inside the AI pass, or after the upscale.
            val factor = UpscalePlan.effectiveFactor(source.width, source.height, options.upscaleFactor)
            if (factor != options.upscaleFactor) {
                NovaLog.i(
                    "EnhancementEngine",
                    "upscale x${options.upscaleFactor} limited to x$factor for a ${source.width}x${source.height} source " +
                        "(output cap ${UpscalePlan.MAX_OUTPUT_PIXELS / 1_000_000} MP)"
                )
            }
            val sharpenAt1x = if (factor == 1) sharpenSpecFor1x(options.sharpness) else SharpenSpec.NONE
            val contextRows = aiPassContextRows(options, sharpenAt1x)

            NovaLog.breadcrumb(
                "EnhancementEngine",
                "AI pass start ${source.width}x${source.height} contextRows=$contextRows threads<=$threadCeiling | ${MemoryStats.summary()}"
            )
            val aiEnhanced = bandProcessor.process(
                source,
                contextRows = contextRows,
                threadCeiling = threadCeiling,
                onProgress = { p ->
                    onProgress?.invoke(EnhanceProgress(p.rowsDone.toFloat() / p.rowsTotal, EnhanceProgress.Stage.AI_TILES))
                },
                isStale = isStale
            ) { bandPixels, bandW, bandH, threads ->
                NovaLog.breadcrumb("EnhancementEngine", "  neural pass ${bandW}x$bandH threads=$threads")
                val aiBand = modelEngine.inferRegion(bandPixels, bandW, bandH, threads)
                applyManualControls(blendWithOriginal(bandPixels, aiBand, options.strength), bandW, bandH, options, sharpenAt1x, threads)
            }
            NovaLog.i(
                "EnhancementEngine",
                "AI pass ${source.width}x${source.height} done in ${System.currentTimeMillis() - startMs}ms " +
                    "(kernels=${NativeNeuralEngine.backendName}, up to $threadCeiling threads)"
            )

            if (factor == 1) {
                onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
                return@withLock aiEnhanced
            }
            if (isStale()) {
                aiEnhanced.recycle() // not returning it, and nothing else references it yet - free it now rather than leaving it for GC
                throw CancellationException("Enhancement superseded before upscaling")
            }

            onProgress?.invoke(EnhanceProgress(0f, EnhanceProgress.Stage.UPSCALING))
            val upscaled = try {
                upscaleStage.upscale(
                    aiEnhanced,
                    factor = factor,
                    sharpen = sharpenSpecForUpscale(options.sharpness, factor),
                    threadCeiling = threadCeiling,
                    onProgress = { fraction -> onProgress?.invoke(EnhanceProgress(fraction, EnhanceProgress.Stage.UPSCALING)) },
                    isStale = isStale
                )
            } finally {
                // The 1x result is only an input to the upscale: free it whether that succeeded, was superseded
                // or failed, instead of leaving a full-resolution bitmap for GC to notice.
                aiEnhanced.recycle()
            }

            onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
            upscaled
        }
    }

    private fun blendWithOriginal(original: IntArray, aiOutput: IntArray, strength: Float): IntArray {
        if (strength >= 1f) return aiOutput
        if (strength <= 0f) return original
        val blended = IntArray(original.size)
        for (i in original.indices) {
            blended[i] = blendPixel(original[i], aiOutput[i], strength)
        }
        return blended
    }

    /**
     * The classical controls layered on the AI band: denoise, then (only when [sharpen] is enabled) edge-aware
     * sharpening, then saturation. When the result is going to be upscaled the sharpening is deferred to
     * [UpscaleStage], so the caller passes [SharpenSpec.NONE] here.
     */
    private fun applyManualControls(
        pixels: IntArray,
        width: Int,
        height: Int,
        options: EnhancementOptions,
        sharpen: SharpenSpec,
        threads: Int
    ): IntArray {
        var result = pixels
        if (options.noiseReduction > 0f) {
            NovaLog.breadcrumb("EnhancementEngine", "  denoiseBilateral ${width}x$height noiseReduction=${options.noiseReduction}")
            result = NativeImageProcessor.denoiseBilateral(
                result, width, height,
                spatialSigma = DENOISE_SPATIAL_SIGMA, rangeSigma = 10f + options.noiseReduction * 40f
            )
        }
        if (sharpen.isEnabled) {
            NovaLog.breadcrumb("EnhancementEngine", "  smartSharpen ${width}x$height $sharpen")
            result = NativeImageProcessor.smartSharpen(result, width, height, sharpen, threads)
        }
        if (options.colorRestoration > 0f) {
            NovaLog.breadcrumb("EnhancementEngine", "  saturation boost colorRestoration=${options.colorRestoration}")
            result = applySaturationBoost(result, options.colorRestoration)
        }
        return result
    }

    /** Simple luma-preserving saturation boost; the inverse of the native `colorFade` degradation. */
    private fun applySaturationBoost(pixels: IntArray, amount: Float): IntArray {
        val out = IntArray(pixels.size)
        val boost = 1f + amount // 1.0 (no change) .. 2.0 (double saturation)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val luma = (r * 299 + g * 587 + b * 114) / 1000

            val nr = (luma + (r - luma) * boost).toInt().coerceIn(0, 255)
            val ng = (luma + (g - luma) * boost).toInt().coerceIn(0, 255)
            val nb = (luma + (b - luma) * boost).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    private fun blendPixel(oldPixel: Int, newPixel: Int, newWeight: Float): Int {
        val oldWeight = 1f - newWeight
        val r = ((oldPixel shr 16 and 0xFF) * oldWeight + (newPixel shr 16 and 0xFF) * newWeight).toInt()
        val g = ((oldPixel shr 8 and 0xFF) * oldWeight + (newPixel shr 8 and 0xFF) * newWeight).toInt()
        val b = ((oldPixel and 0xFF) * oldWeight + (newPixel and 0xFF) * newWeight).toInt()
        return (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    }
}
