package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

private const val TAG = "UpscaleStage"

/**
 * The upscale half of the pipeline: Lanczos-3 resampling followed by edge-aware sharpening, done natively in
 * horizontal bands of the OUTPUT image.
 *
 * This replaces `Bitmap.createScaledBitmap` (bilinear) plus a plain unsharp mask. Bilinear interpolation turns
 * every edge into a soft ramp that no sharpening filter can fully undo; Lanczos keeps edges much steeper, and the
 * sharpening pass here is gated and halo-clamped (see [SharpenSpec]) so it can be strong on line art without
 * amplifying compression noise.
 *
 * Bands: the native call recomputes the few extra rows its sharpening needs around every band, so the pixels it
 * writes are bit-identical to a whole-image pass whatever the band height - there are no seams (checked by
 * tools/upscale_verification). Band height only trades peak scratch memory against per-call overhead, and gives
 * cancellation and thermal pacing a chance to act between bands, exactly as [BandProcessor] does for the AI pass.
 */
class UpscaleStage(thermalGovernor: ThermalGovernor? = null) {

    private val pacer = BandPacer(thermalGovernor)

    /**
     * @param factor integer upscale factor, 2..4 in practice (1 is accepted and just sharpens).
     * @param sharpen sharpening applied at the OUTPUT resolution; [SharpenSpec.NONE] for a pure resample.
     * @param onProgress receives the fraction of output rows done, 0..1.
     * @return a NEW bitmap of `factor x` [source]'s size; [source] is neither modified nor recycled.
     */
    suspend fun upscale(
        source: Bitmap,
        factor: Int,
        sharpen: SharpenSpec,
        threadCeiling: Int,
        onProgress: ((Float) -> Unit)? = null,
        isStale: () -> Boolean = { false }
    ): Bitmap {
        require(factor >= 1) { "factor must be at least 1, got $factor" }
        val targetW = source.width * factor
        val targetH = source.height * factor
        val rowsPerBand = bandRowsFor(targetW)
        val startMs = System.currentTimeMillis()
        NovaLog.breadcrumb(
            TAG,
            "upscale ${source.width}x${source.height} -> ${targetW}x$targetH (x$factor, ~${targetW.toLong() * targetH * 4L / (1024L * 1024L)}MB), " +
                "bands of $rowsPerBand rows, sharpen=$sharpen | ${MemoryStats.summary()}"
        )
        val output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        try {
            var bands = 0
            var y0 = 0
            while (y0 < targetH) {
                if (isStale()) throw CancellationException("Enhancement superseded - aborting before the next upscale band")
                val threads = pacer.threadsForNextBand(threadCeiling)
                val y1 = min(targetH, y0 + rowsPerBand)
                withContext(Dispatchers.Default) {
                    NativeImageProcessor.upscaleBand(source, output, factor, y0, y1, sharpen, threads)
                }
                bands++
                y0 = y1
                onProgress?.invoke(y0.toFloat() / targetH)
            }
            NovaLog.i(
                TAG,
                "Upscaled ${source.width}x${source.height} x$factor -> ${targetW}x$targetH in $bands band(s) " +
                    "in ${System.currentTimeMillis() - startMs}ms (up to $threadCeiling threads)"
            )
            return output
        } catch (t: Throwable) {
            // Covers the isStale() abort as much as a real failure: output is a large bitmap nothing else
            // references yet - free its native memory now instead of waiting for GC.
            output.recycle()
            throw t
        }
    }

    private companion object {
        // Native scratch for one band is roughly 28 bytes per output pixel of (band + context rows); capping a
        // band at ~1M pixels keeps that near 30 MB however wide the output is, while 256 rows is plenty for
        // narrow images (it matches BandProcessor's band height).
        const val MAX_BAND_PIXELS = 1_048_576
        const val MAX_BAND_ROWS = 256
        const val MIN_BAND_ROWS = 16

        fun bandRowsFor(outputWidth: Int): Int = max(MIN_BAND_ROWS, min(MAX_BAND_ROWS, MAX_BAND_PIXELS / max(1, outputWidth)))
    }
}
