package com.novaenhance.ai.ai.engine

/**
 * Decides how large an upscale a given photo can actually afford.
 *
 * Two limits make "just upscale by 4" unsafe for big photos:
 *
 *  1. Android refuses to DRAW any single bitmap over 100 MB (`RecordingCanvas.throwIfCannotDraw`, the same
 *     function that appears in the "trying to use a recycled bitmap" crash log) - it throws a RuntimeException,
 *     even if only a corner of the bitmap is on screen. The before/after preview draws the result, so a result
 *     above that size would crash the screen the moment it appeared. 100 MB is 26.2 MP of ARGB_8888.
 *  2. The result is held in memory next to the source and the 1x enhancement, and then JPEG-encoded; 4x of a
 *     12 MP camera photo would be a 192 MP bitmap, three quarters of a gigabyte, which a 4 GB phone cannot hold.
 *
 * Rather than ending in a crash (which in a batch would fail every large photo), the factor is stepped down until
 * the output fits [MAX_OUTPUT_PIXELS]. Manga panels, screenshots and 1080p frames are barely affected: a
 * 512x658 panel keeps 4x, a 1280x720 frame keeps 4x, a 1920x1080 frame gets 3x.
 */
object UpscalePlan {

    /** Largest output, in pixels, an upscale may produce: 25 MP = exactly 100,000,000 bytes, under Android's draw limit. */
    const val MAX_OUTPUT_PIXELS = 25_000_000L

    /**
     * The largest factor in 1..[requested] whose output for a [width] x [height] source stays within
     * [MAX_OUTPUT_PIXELS]; always at least 1 (a photo that is already too big is simply not upscaled).
     */
    fun effectiveFactor(width: Int, height: Int, requested: Int): Int {
        var factor = requested.coerceAtLeast(1)
        val sourcePixels = width.toLong() * height.toLong()
        while (factor > 1 && sourcePixels * factor * factor > MAX_OUTPUT_PIXELS) factor--
        return factor
    }
}
