package com.novaenhance.ai.ai.engine

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import com.novaenhance.ai.utils.decodeUriBitmap
import com.novaenhance.ai.utils.queryDisplayName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

private const val TAG = "BatchEnhancer"

/** What happened to one photo of a batch: either it was saved to the Gallery ([savedUri]) or it failed ([error]). */
data class BatchItemResult(val savedUri: Uri?, val error: String?) {
    val isSuccess: Boolean get() = savedUri != null
}

data class BatchSummary(val saved: Int, val failed: Int)

/**
 * Enhances a list of photos one after another with the SAME [EnhancementOptions], saving every result to the
 * Gallery as soon as it is done.
 *
 * Why strictly one at a time, and why each photo is released before the next is loaded: the native engine is a
 * single shared resource (see [EnhancementEngine]'s processing gate) and a photo plus its result is tens of MB.
 * Decode -> enhance -> save -> recycle keeps peak memory at ONE photo whatever the batch size, and means a batch
 * that is cancelled, or dies halfway, has already delivered everything it finished.
 *
 * A photo that fails (unreadable file, out of memory, the Gallery refusing the write) is reported through
 * [onItemFinished] and the batch carries on with the next one; only cancellation of the calling coroutine stops
 * it. Cancellation takes effect at the next band boundary inside the photo being processed.
 */
class BatchEnhancer(
    private val appContext: Context,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage,
    private val thermalGovernor: ThermalGovernor
) {

    /**
     * @param onItemStarted called with the photo's index just before it is decoded.
     * @param onItemProgress called with (index, 0..1) as that photo's enhancement advances.
     * @param onItemFinished called with the photo's index and its [BatchItemResult].
     * @throws CancellationException if the calling coroutine is cancelled (photos finished so far stay saved).
     */
    suspend fun run(
        uris: List<Uri>,
        options: EnhancementOptions,
        onItemStarted: (index: Int) -> Unit,
        onItemProgress: (index: Int, fraction: Float) -> Unit,
        onItemFinished: (index: Int, result: BatchItemResult) -> Unit
    ): BatchSummary {
        val activeModel = modelRepository.getOrCreateActiveModel()
        val enhancer = EnhancementEngine(modelRepository.getEngine(activeModel.id), thermalGovernor)
        val job = currentCoroutineContext()[Job]
        NovaLog.i(TAG, "BATCH_BEGIN ${uris.size} photo(s) options=$options")

        var saved = 0
        var failed = 0
        for ((index, uri) in uris.withIndex()) {
            currentCoroutineContext().ensureActive()
            onItemStarted(index)
            val result = processOne(index, uri, enhancer, options, onItemProgress) { job?.isActive == false }
            if (result.isSuccess) saved++ else failed++
            onItemFinished(index, result)
        }
        NovaLog.i(TAG, "BATCH_END saved=$saved failed=$failed")
        return BatchSummary(saved, failed)
    }

    private suspend fun processOne(
        index: Int,
        uri: Uri,
        enhancer: EnhancementEngine,
        options: EnhancementOptions,
        onItemProgress: (index: Int, fraction: Float) -> Unit,
        isStale: () -> Boolean
    ): BatchItemResult {
        var source: Bitmap? = null
        var enhanced: Bitmap? = null
        return try {
            source = withContext(Dispatchers.IO) { decodeUriBitmap(appContext, uri) }
                ?: return BatchItemResult(null, "Could not open this photo")
            val decoded: Bitmap = source
            NovaLog.i(TAG, "BATCH_ITEM $index ${decoded.width}x${decoded.height}")

            enhanced = withContext(Dispatchers.Default) {
                enhancer.enhance(
                    decoded,
                    options,
                    onProgress = { progress -> onItemProgress(index, progress.fraction) },
                    isStale = isStale
                )
            }
            val result: Bitmap = enhanced
            val name = outputName(uri)
            val savedUri = withContext(Dispatchers.IO) { storage.saveEnhancedPhotoToGallery(result, name) }
            if (savedUri != null) BatchItemResult(savedUri, null) else BatchItemResult(null, "Couldn't save to the Gallery")
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            NovaLog.w(TAG, "BATCH_ITEM $index failed", t)
            BatchItemResult(null, t.message ?: t::class.java.simpleName)
        } finally {
            // Nothing else references either bitmap, and no native call is still reading them: enhance() only
            // returns or throws after its last band finished. Free the pixel memory now instead of leaving it for GC.
            enhanced?.recycle()
            source?.recycle()
        }
    }

    /** "IMG_0042.jpg" -> "IMG_0042_enhanced.jpg"; the Gallery adds " (1)" itself if that name is already taken. */
    private fun outputName(uri: Uri): String {
        val original = queryDisplayName(appContext, uri) ?: "photo"
        val base = original.substringBeforeLast('.').ifBlank { "photo" }
        val safe = base.replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(60)
        return "${safe}_enhanced.jpg"
    }
}
