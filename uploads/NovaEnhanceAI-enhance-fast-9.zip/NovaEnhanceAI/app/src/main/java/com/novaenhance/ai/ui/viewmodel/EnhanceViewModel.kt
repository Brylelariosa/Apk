package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.engine.BatchEnhancer
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ResourceRetirement
import com.novaenhance.ai.utils.ThermalGovernor
import com.novaenhance.ai.utils.decodeUriBitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger

private const val TAG = "EnhanceViewModel"

// LabeledSlider reports every drag tick, not just the final value, and a
// full enhancement pass over a real photo is expensive (see BandProcessor).
// Without a debounce, dragging any slider for a second queues up dozens of
// full-image runs; since none were ever cancelled, they'd all keep running
// concurrently, competing for CPU and finishing in whatever order they
// happen to complete in rather than the order they were requested - both a
// performance and a correctness problem (a slow early run could overwrite
// a faster later one's result). This delay is how long the options have to
// stay still before a run actually starts.
private const val ENHANCEMENT_DEBOUNCE_MS = 200L

data class EnhanceUiState(
    val originalBitmap: Bitmap? = null,
    val enhancedBitmap: Bitmap? = null,
    val options: EnhancementOptions = EnhancementOptions(),
    val isProcessing: Boolean = false,
    val progressFraction: Float = 0f,
    val isSaving: Boolean = false,
    val savedUri: Uri? = null,
    val errorMessage: String? = null,
    /**
     * [com.novaenhance.ai.database.entities.ModelEntity.trainingSessionCount] of the model this
     * result came from, or null before that's known. 0 means the AI pass above is still the
     * fresh, near-identity initialization from `network.cpp`'s `initializeParams` (small-stddev
     * tail conv) - i.e. what's visible in [enhancedBitmap] right now is almost entirely the
     * classical sharpen/denoise/color controls, not learned enhancement, until a training
     * session gets promoted. Used to show an honest heads-up instead of leaving that silent.
     */
    val activeModelTrainingSessionCount: Int? = null
)

/** Where one photo of a multi-photo selection stands. */
enum class BatchItemStatus { PENDING, WORKING, DONE, FAILED }

data class BatchItem(val uri: Uri, val status: BatchItemStatus = BatchItemStatus.PENDING)

/**
 * The photos the user picked and, while "Enhance & save all" runs, how far along it is. A single photo (picked or
 * captured) is just a one-item selection, so [isBatch] is what decides whether batch controls are shown.
 */
data class BatchUiState(
    val items: List<BatchItem> = emptyList(),
    /** Index in [items] of the photo shown in the before/after preview. */
    val activeIndex: Int = 0,
    val isRunning: Boolean = false,
    /** Whole-batch progress, 0..1, counting the photo being processed fractionally. */
    val overallFraction: Float = 0f,
    /** One-line outcome of the last batch run, or null before one has finished. */
    val summary: String? = null
) {
    val isBatch: Boolean get() = items.size > 1
    val doneCount: Int get() = items.count { it.status == BatchItemStatus.DONE }
    val failedCount: Int get() = items.count { it.status == BatchItemStatus.FAILED }
}

class EnhanceViewModel(
    private val appContext: Context,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage,
    private val thermalGovernor: ThermalGovernor
) : ViewModel() {

    private val _uiState = MutableStateFlow(EnhanceUiState())
    val uiState: StateFlow<EnhanceUiState> = _uiState.asStateFlow()

    private var enhancementJob: Job? = null

    // Multi-photo selection and the "Enhance & save all" run. The batch itself lives in BatchEnhancer; this class
    // only mirrors its progress into UI state.
    private val batchEnhancer = BatchEnhancer(appContext, modelRepository, storage, thermalGovernor)
    private val _batchState = MutableStateFlow(BatchUiState())
    val batchState: StateFlow<BatchUiState> = _batchState.asStateFlow()
    private var batchJob: Job? = null

    // "Latest pick wins": decoding a photo takes a moment, so tapping thumbnails quickly (or picking again) can
    // start several loads. Only the newest may publish; an older one that finishes later recycles its own bitmap.
    private val previewLoadGeneration = AtomicInteger(0)

    // Monotonically increasing per enhancement request (each onImageSelected/
    // onOptionsChanged call bumps it). job.cancel() alone can't stop a
    // native JNI call that's already executing (see runEnhancement's isStale
    // lambda and EnhancementEngine.enhance's doc comment) - a rapid slider
    // drag could otherwise let an older, slower-finishing request publish
    // its result AFTER a newer one, or recycle a bitmap a newer request (or
    // Compose, still drawing it) is still using. Comparing against this on
    // every publish/recycle/progress-update is what actually prevents that,
    // independent of whatever coroutine-cancellation state the job is in.
    private val enhancementGeneration = AtomicInteger(0)

    // See ResourceRetirement's kdoc for why "no longer in _uiState" alone
    // doesn't mean "safe to recycle" - and for the rule BeforeAfterSlider
    // follows when it reports a bitmap as no longer displayed.
    private val bitmapRetirement = ResourceRetirement<Bitmap>(
        dispose = { it.recycle() },
        log = { NovaLog.d(TAG, it) }
    )

    /** Wired to BeforeAfterSlider's onOriginalDisplayChanged/onEnhancedDisplayChanged. */
    fun onBitmapDisplayChanged(bitmap: Bitmap, displayed: Boolean) {
        if (displayed) bitmapRetirement.hold(bitmap) else bitmapRetirement.release(bitmap)
    }

    /** A single photo (e.g. just captured): a one-item selection. */
    fun onImageSelected(uri: Uri) = onImagesSelected(listOf(uri))

    /**
     * The user picked one or more photos. The first is shown in the preview; with several, the strip under it
     * lets them switch, and "Enhance & save all" runs the whole selection with the current settings.
     */
    fun onImagesSelected(uris: List<Uri>) {
        val picked = uris.distinct()
        if (picked.isEmpty() || _batchState.value.isRunning) return
        _batchState.value = BatchUiState(items = picked.map { BatchItem(it) })
        loadForPreview(picked.first())
    }

    /** Shows photo [index] of the current selection in the preview. */
    fun selectBatchItem(index: Int) {
        val batch = _batchState.value
        if (batch.isRunning || index !in batch.items.indices || index == batch.activeIndex) return
        _batchState.value = batch.copy(activeIndex = index)
        loadForPreview(batch.items[index].uri)
    }

    private fun loadForPreview(uri: Uri) {
        val myLoad = previewLoadGeneration.incrementAndGet()
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                val decoded = decodeUriBitmap(appContext, uri)
                if (decoded != null && !isActive) {
                    decoded.recycle() // cancelled while decoding - nobody will ever see it
                    null
                } else {
                    decoded
                }
            }
            if (previewLoadGeneration.get() != myLoad) {
                bitmap?.recycle() // a newer pick superseded this one while it was decoding
                return@launch
            }
            if (bitmap == null) {
                _uiState.value = _uiState.value.copy(errorMessage = "Could not open that image")
                return@launch
            }
            // Bumped before anything else so any in-flight enhance() sees
            // itself as stale at its very next check, and joined (not just
            // cancelled) so we know it has actually stopped touching
            // originalBitmap/enhancedBitmap - cancel() alone doesn't
            // guarantee that (see the class-level doc comment on
            // enhancementGeneration): recycling those out from under a
            // still-running getPixels()/native call is exactly the kind of
            // race that crashes with "Canvas: trying to use a recycled
            // bitmap", not just a theoretical concern given a fresh photo
            // pick can land at any point in another enhancement's lifetime.
            enhancementGeneration.incrementAndGet()
            enhancementJob?.cancelAndJoin()
            if (previewLoadGeneration.get() != myLoad) {
                bitmap.recycle() // superseded while waiting for the previous enhancement to stop
                return@launch
            }

            val previous = _uiState.value
            _uiState.value = EnhanceUiState(originalBitmap = bitmap, options = previous.options)
            // Picking a new photo drops the previous original+enhanced bitmaps from
            // state; retire them rather than waiting on GC to notice - on a large
            // photo that's tens of MB of native pixel memory, and this screen's whole
            // point is running that scenario repeatedly. retire() recycles right away
            // if nothing still needs them, or defers via ResourceRetirement if
            // BeforeAfterSlider (or an in-flight save/enhancement - see its kdoc) does.
            bitmapRetirement.retire(previous.originalBitmap)
            bitmapRetirement.retire(previous.enhancedBitmap)
            // While a batch runs it owns the native engine; enhanceAndSaveAll() brings the preview back afterwards.
            if (!_batchState.value.isRunning) runEnhancement()
        }
    }

    fun onOptionsChanged(options: EnhancementOptions) {
        if (_batchState.value.isRunning) return // the batch is using the settings it started with
        _uiState.value = _uiState.value.copy(options = options)
        runEnhancement()
    }

    fun runEnhancement() {
        val original = _uiState.value.originalBitmap ?: return
        val myGeneration = enhancementGeneration.incrementAndGet()
        enhancementJob?.cancel()
        enhancementJob = viewModelScope.launch {
            delay(ENHANCEMENT_DEBOUNCE_MS) // superseded by a newer call -> cancelled before any real work starts
            // Belt-and-suspenders alongside job.cancel() above - see
            // enhancementGeneration's doc comment for why cancel() alone
            // isn't enough once real (native) work has actually started, but
            // for the debounce wait specifically, cancel() should already
            // have prevented us from reaching this line at all.
            if (isStale(myGeneration)) return@launch
            _uiState.value = _uiState.value.copy(isProcessing = true, progressFraction = 0f, errorMessage = null)
            var result: Bitmap? = null
            try {
                val activeModel = modelRepository.getOrCreateActiveModel()
                _uiState.value = _uiState.value.copy(activeModelTrainingSessionCount = activeModel.trainingSessionCount)
                val engine = modelRepository.getEngine(activeModel.id)
                val enhancer = EnhancementEngine(engine, thermalGovernor)
                val options = _uiState.value.options

                val startMs = System.currentTimeMillis()
                // original is read by the native call inside enhance() the whole time
                // it's running; held here so onCleared() (which can't suspend, so it
                // can't just await enhancementJob like onImageSelected does) knows not
                // to recycle out from under it - see ResourceRetirement's kdoc.
                // ENHANCE_BEGIN/END/FAIL/CANCEL (paired by gen=) let the crash log tell, after a crash or a
                // kill, that the app died in the middle of this enhancement - see PersistentLog.interruptedWork.
                NovaLog.i(TAG, "ENHANCE_BEGIN gen=$myGeneration ${original.width}x${original.height} options=$options | ${MemoryStats.summary()}")
                val enhanced = bitmapRetirement.withHold(original) {
                    withContext(Dispatchers.Default) {
                        enhancer.enhance(
                            original,
                            options,
                            onProgress = { progress ->
                                if (!isStale(myGeneration)) {
                                    _uiState.value = _uiState.value.copy(progressFraction = progress.fraction)
                                }
                            },
                            isStale = { isStale(myGeneration) }
                        )
                    }
                }
                result = enhanced // tracked so the catch block below can clean it up if anything past this point throws
                NovaLog.i(TAG, "ENHANCE_END gen=$myGeneration: Enhanced ${original.width}x${original.height} in ${System.currentTimeMillis() - startMs}ms (options=$options) | ${MemoryStats.summary()}")

                if (isStale(myGeneration)) {
                    // Superseded in the narrow window between enhance() returning
                    // and us getting to publish it - enhanced was never shown or
                    // referenced anywhere else, so it's safe (and necessary, to
                    // avoid leaking a full-resolution bitmap) to recycle it directly.
                    enhanced.recycle()
                    result = null
                    NovaLog.d(TAG, "ENHANCE_CANCEL gen=$myGeneration (superseded just before publishing)")
                    return@launch
                }
                val previousEnhanced = _uiState.value.enhancedBitmap
                _uiState.value = _uiState.value.copy(enhancedBitmap = enhanced, isProcessing = false, progressFraction = 1f, savedUri = null)
                result = null // ownership handed to _uiState - the catch block below must not also recycle it
                // Same reasoning as onImageSelected: every slider-driven re-enhance
                // supersedes the prior result bitmap, so retire it instead of leaving
                // it for GC - a slider drag can produce several of these in a few
                // seconds. previousEnhanced is what THIS generation displaced, which -
                // since we just confirmed above that WE are still the current
                // generation - is safe to retire regardless of which earlier
                // generation actually produced it. retire() (not a direct recycle())
                // is what actually prevents the slider-at-completion crash: see
                // ResourceRetirement's kdoc for why "displaced from _uiState" alone
                // isn't the same as "safe to free".
                bitmapRetirement.retire(previousEnhanced)
            } catch (c: CancellationException) {
                result?.recycle() // if we got a result before being cancelled/going stale, don't leak it
                NovaLog.d(TAG, "ENHANCE_CANCEL gen=$myGeneration (superseded by a newer slider change or image)")
                throw c // superseded by a newer options change/image pick - not a real failure, don't show an error for it
            } catch (t: Throwable) {
                result?.recycle()
                NovaLog.w(TAG, "ENHANCE_FAIL gen=$myGeneration: Enhancement failed | ${MemoryStats.summary()}", t)
                if (!isStale(myGeneration)) {
                    _uiState.value = _uiState.value.copy(isProcessing = false, errorMessage = "Enhancement failed: ${t.message}")
                }
            }
        }
    }

    private fun isStale(generation: Int) = enhancementGeneration.get() != generation

    /**
     * Enhances EVERY photo of the current selection with the current settings and saves each result to the Gallery
     * as soon as it is done (see [BatchEnhancer]). The live preview is paused for the duration - the batch owns
     * the native engine - and the settings are frozen at the values they have right now.
     */
    fun enhanceAndSaveAll() {
        val batch = _batchState.value
        if (batch.isRunning || batch.items.isEmpty()) return

        // Stop the preview: its generation is bumped so an enhancement already running notices at its next band.
        // (A photo still being decoded for the preview is left to finish; it just isn't enhanced until the batch ends.)
        enhancementGeneration.incrementAndGet()
        enhancementJob?.cancel()
        _uiState.value = _uiState.value.copy(isProcessing = false, errorMessage = null)

        val uris = batch.items.map { it.uri }
        val options = _uiState.value.options
        val total = uris.size
        _batchState.value = batch.copy(
            items = batch.items.map { it.copy(status = BatchItemStatus.PENDING) },
            isRunning = true,
            overallFraction = 0f,
            summary = null
        )

        batchJob = viewModelScope.launch {
            var firstError: String? = null
            try {
                val summary = batchEnhancer.run(
                    uris = uris,
                    options = options,
                    onItemStarted = { index ->
                        _batchState.update { it.copy(items = it.items.withStatus(index, BatchItemStatus.WORKING)) }
                    },
                    onItemProgress = { index, fraction ->
                        _batchState.update { it.copy(overallFraction = (index + fraction) / total) }
                    },
                    onItemFinished = { index, result ->
                        if (!result.isSuccess && firstError == null) firstError = result.error
                        val status = if (result.isSuccess) BatchItemStatus.DONE else BatchItemStatus.FAILED
                        _batchState.update {
                            it.copy(items = it.items.withStatus(index, status), overallFraction = (index + 1f) / total)
                        }
                    }
                )
                _batchState.update {
                    it.copy(isRunning = false, overallFraction = 1f, summary = batchSummaryText(summary.saved, summary.failed, total, firstError))
                }
            } catch (c: CancellationException) {
                _batchState.update {
                    it.copy(
                        isRunning = false,
                        items = it.items.map { item -> if (item.status == BatchItemStatus.WORKING) item.copy(status = BatchItemStatus.PENDING) else item },
                        summary = "Stopped - ${it.doneCount} of $total photos were saved to your Gallery"
                    )
                }
                throw c
            } catch (t: Throwable) {
                NovaLog.w(TAG, "BATCH_FAIL: batch stopped by an unexpected error | ${MemoryStats.summary()}", t)
                _batchState.update {
                    it.copy(isRunning = false, summary = "Stopped by an error: ${t.message ?: t::class.java.simpleName}")
                }
            } finally {
                // The preview may have been interrupted before it ever published (a freshly loaded photo): bring it back.
                val ui = _uiState.value
                if (ui.originalBitmap != null && ui.enhancedBitmap == null) runEnhancement()
            }
        }
    }

    /** Stops a running batch after the photo being processed reaches its next band; finished photos stay saved. */
    fun cancelBatch() {
        batchJob?.cancel()
    }

    private fun List<BatchItem>.withStatus(index: Int, status: BatchItemStatus): List<BatchItem> =
        mapIndexed { i, item -> if (i == index) item.copy(status = status) else item }

    private fun batchSummaryText(saved: Int, failed: Int, total: Int, firstError: String?): String = when {
        failed == 0 -> if (saved == 1) "Saved 1 photo to your Gallery" else "Saved $saved photos to your Gallery"
        saved == 0 -> "None of the $total photos could be enhanced" + (firstError?.let { " ($it)" } ?: "")
        else -> "Saved $saved of $total photos - $failed failed" + (firstError?.let { " ($it)" } ?: "")
    }

    /**
     * Saves the enhanced result into the shared Gallery (via
     * [AppStorage.saveEnhancedPhotoToGallery]) rather than this app's
     * private storage, so it actually shows up somewhere the user can find
     * it - see that function's doc comment for why the old destination was
     * indistinguishable from Save not working at all.
     */
    fun saveResult() {
        val enhanced = _uiState.value.enhancedBitmap ?: return
        // Held for the whole save, independent of _uiState: a re-enhance can
        // supersede and retire() this exact bitmap while the gallery write below
        // is still reading its pixels on Dispatchers.IO, and without this hold
        // that's another path to recycling a bitmap something else still needs.
        bitmapRetirement.hold(enhanced)
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true, errorMessage = null)
            try {
                val uri = withContext(Dispatchers.IO) {
                    storage.saveEnhancedPhotoToGallery(enhanced, "enhanced_${System.currentTimeMillis()}.jpg")
                }
                _uiState.value = if (uri != null) {
                    _uiState.value.copy(isSaving = false, savedUri = uri)
                } else {
                    _uiState.value.copy(isSaving = false, errorMessage = "Couldn't save the photo - please try again")
                }
            } finally {
                bitmapRetirement.release(enhanced)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        enhancementJob?.cancel()
        batchJob?.cancel()
        // cancel() is cooperative and onCleared() can't suspend to await it (unlike
        // onImageSelected's cancelAndJoin()), so a native enhance() call - or a
        // gallery write from saveResult() - can still be actively using these
        // bitmaps here. retire() defers via ResourceRetirement in that case instead of
        // recycling out from under it; it also still waits on BeforeAfterSlider if
        // Compose hasn't torn this screen's composition down yet.
        bitmapRetirement.retire(_uiState.value.originalBitmap)
        bitmapRetirement.retire(_uiState.value.enhancedBitmap)
    }
}
