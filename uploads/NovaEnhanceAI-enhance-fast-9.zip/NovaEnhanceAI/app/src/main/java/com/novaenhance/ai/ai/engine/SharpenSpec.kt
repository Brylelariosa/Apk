package com.novaenhance.ai.ai.engine

/**
 * Parameters of the native edge-aware sharpen (see `filters/upscale.h`, which this mirrors field for field).
 *
 * A plain unsharp mask adds `amount * (pixel - blur)` everywhere, which boosts compression noise in flat areas and
 * leaves halos around strong edges. The "smart" variant measures the detail on luma only, scales it by a gate that
 * is closed in flat/noisy areas and open on real edges, and clamps the result to the local min..max (plus a small
 * [overshoot]) so no halos appear.
 *
 * @property amount detail gain; 0 disables sharpening. Useful range 0..3.
 * @property sigma Gaussian sigma, in OUTPUT pixels, of the blur the detail is measured against (native clamps to 0.3..8).
 * @property overshoot how far past the local min/max a pixel may go, as a fraction of the local range (0..1).
 * @property clampRadius radius of the local min/max window (native clamps to 1..4).
 * @property gateLow gradient (levels per pixel) at or below which detail is not boosted at all.
 * @property gateHigh gradient at or above which detail gets the full [amount]; when `<= gateLow` the gate is off.
 */
data class SharpenSpec(
    val amount: Float,
    val sigma: Float,
    val overshoot: Float = DEFAULT_OVERSHOOT,
    val clampRadius: Int = 1,
    val gateLow: Float = DEFAULT_GATE_LOW,
    val gateHigh: Float = DEFAULT_GATE_HIGH
) {
    val isEnabled: Boolean get() = amount > 0f

    companion object {
        const val DEFAULT_OVERSHOOT = 0.08f
        const val DEFAULT_GATE_LOW = 2f
        const val DEFAULT_GATE_HIGH = 12f

        /** A spec that changes nothing. */
        val NONE = SharpenSpec(amount = 0f, sigma = 1f)
    }
}
