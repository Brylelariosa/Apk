#include <jni.h>
#include <android/log.h>
#include <android/bitmap.h>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

#include "filters/convolution.h"
#include "filters/degradation.h"
#include "filters/upscale.h"
#include "nn/inference.h"
#include "nn/network.h"

#define LOG_TAG "NovaEnhanceNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

// Copies a Java int[] into a std::vector<int32_t> without extra bounds churn.
std::vector<int32_t> toVector(JNIEnv* env, jintArray arr) {
    jsize len = env->GetArrayLength(arr);
    std::vector<int32_t> out(len);
    env->GetIntArrayRegion(arr, 0, len, reinterpret_cast<jint*>(out.data()));
    return out;
}

jintArray toJavaArray(JNIEnv* env, const std::vector<int32_t>& vec) {
    jintArray result = env->NewIntArray(static_cast<jsize>(vec.size()));
    if (result == nullptr) return nullptr;
    env->SetIntArrayRegion(result, 0, static_cast<jsize>(vec.size()),
                            reinterpret_cast<const jint*>(vec.data()));
    return result;
}

// A reasonable ceiling on any one image dimension passed across the JNI boundary - mirrors
// NativeImageProcessor.kt's MAX_IMAGE_DIMENSION. Enhancement works in full-width bands (BandProcessor), so a
// "tile" here can be as wide as a whole photo: phone cameras already exceed the old 4096px ceiling (the
// HOT 11's 13 MP main camera is 4208 px wide) and a 4x upscale of a photo is wider still. It exists to
// reject an obviously-wrong value before it can reach an integer multiplication or a vector allocation
// sized from it, not as a real limit.
constexpr int64_t kMaxImageDimension = 16384;

// Explicit JNI-boundary validation for the tile-based (int[] pixels, width,
// height, ...) filter calls - see NativeImageProcessor.kt's validateTileArgs
// for the equivalent Kotlin-side check this mirrors as defense in depth
// (Kotlin should already have rejected anything this catches, but nothing
// forces every caller, forever, through that one call path). Throws a Java
// IllegalArgumentException and returns false on any problem; callers MUST
// return a safe default (nullptr for a jintArray/jfloatArray result)
// immediately when this returns false rather than proceeding - an exception
// is already pending in `env` at that point, and touching more JNI state
// before returning to Java is unsafe.
//
// int64_t throughout so a bad width/height is caught by this comparison
// itself rather than by whatever 32-bit `width * height` it would otherwise
// silently overflow into inside the filter code.
bool validatePixelArray(JNIEnv* env, jintArray pixels, jint width, jint height, const char* fnName) {
    auto fail = [&](const std::string& reason) {
        jclass exClass = env->FindClass("java/lang/IllegalArgumentException");
        if (exClass != nullptr) {
            env->ThrowNew(exClass, (std::string(fnName) + ": " + reason).c_str());
        }
        return false;
    };

    if (pixels == nullptr) return fail("pixels array is null");
    if (width <= 0 || height <= 0) {
        return fail("width/height must be positive (got " + std::to_string(width) +
                     "x" + std::to_string(height) + ")");
    }
    if (width > kMaxImageDimension || height > kMaxImageDimension) {
        return fail("width/height exceeds the " + std::to_string(kMaxImageDimension) + "px ceiling");
    }

    int64_t expected = static_cast<int64_t>(width) * static_cast<int64_t>(height);
    if (expected > static_cast<int64_t>(std::numeric_limits<jsize>::max())) {
        return fail("width*height overflows a JVM array index");
    }

    jsize actualLen = env->GetArrayLength(pixels);
    if (static_cast<int64_t>(actualLen) != expected) {
        return fail("pixels array length (" + std::to_string(actualLen) + ") does not match width*height (" +
                     std::to_string(expected) + ")");
    }
    return true;
}

// Largest integer upscale factor the native upscaler accepts (the app only ever asks for 2-4; this is a sanity
// bound, mirrored by upscale.h's documentation).
constexpr int kMaxUpscaleFactor = 8;

// Throws a Java IllegalArgumentException. The caller must return immediately afterwards.
void throwIllegalArgument(JNIEnv* env, const std::string& message) {
    jclass exClass = env->FindClass("java/lang/IllegalArgumentException");
    if (exClass != nullptr) env->ThrowNew(exClass, message.c_str());
}

novaenhance::SharpenParams makeSharpenParams(jfloat amount, jfloat sigma, jfloat overshoot, jint clampRadius,
                                             jfloat gateLow, jfloat gateHigh) {
    novaenhance::SharpenParams p;
    p.amount = amount;
    p.sigma = sigma;
    p.overshoot = overshoot;
    p.clampRadius = clampRadius;
    p.gateLow = gateLow;
    p.gateHigh = gateHigh;
    return p;
}

}  // namespace

extern "C" {

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeGaussianBlur(
        JNIEnv* env, jobject /* this */, jintArray pixels, jint width, jint height, jfloat sigma) {
    if (!validatePixelArray(env, pixels, width, height, "gaussianBlur")) return nullptr;
    auto in = toVector(env, pixels);
    auto out = novaenhance::gaussianBlur(in, width, height, sigma);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeUnsharpMask(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat sigma, jfloat amount) {
    if (!validatePixelArray(env, pixels, width, height, "unsharpMask")) return nullptr;
    auto in = toVector(env, pixels);
    auto out = novaenhance::unsharpMask(in, width, height, sigma, amount);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeDenoiseBilateral(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height,
        jfloat spatialSigma, jfloat rangeSigma) {
    if (!validatePixelArray(env, pixels, width, height, "denoiseBilateral")) return nullptr;
    auto in = toVector(env, pixels);
    auto out = novaenhance::denoiseBilateral(in, width, height, spatialSigma, rangeSigma);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeResizeBilinear(
        JNIEnv* env, jobject, jintArray pixels, jint srcWidth, jint srcHeight,
        jint dstWidth, jint dstHeight) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::resizeBilinear(in, srcWidth, srcHeight, dstWidth, dstHeight);
    return toJavaArray(env, out);
}

JNIEXPORT jfloat JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeQuickSimilarityScore(
        JNIEnv* env, jobject, jintArray a, jintArray b, jint width, jint height) {
    auto va = toVector(env, a);
    auto vb = toVector(env, b);
    return novaenhance::quickSimilarityScore(va, vb, width, height);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeAddGaussianNoise(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat amount, jint seed) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::addGaussianNoise(in, width, height, amount, static_cast<uint32_t>(seed));
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeSimulateJpegArtifacts(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jint qualityPercent) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::simulateJpegArtifacts(in, width, height, qualityPercent);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeMotionBlur(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat angleDegrees, jint lengthPx) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::motionBlur(in, width, height, angleDegrees, lengthPx);
    return toJavaArray(env, out);
}

JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeColorFade(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat fadeAmount) {
    auto in = toVector(env, pixels);
    auto out = novaenhance::colorFade(in, width, height, fadeAmount);
    return toJavaArray(env, out);
}

// Direct-bitmap fast path used for cheap dashboard/gallery thumbnails, where
// copying through a Kotlin IntArray twice (Bitmap -> IntArray -> JNI -> IntArray
// -> Bitmap) would waste memory on top of the two Bitmap objects already
// involved. This is the one place we use jnigraphics' native bitmap locking
// directly instead of the int-array tile API.
// NOTE on byte order: AndroidBitmap_lockPixels exposes raw native memory in
// RGBA_8888 byte order, which is NOT the same int32 layout as the ARGB_8888
// ints Bitmap.getPixels()/setPixels() hand to the int-array pipeline above.
// resizeBilinear is safe to use directly on this raw buffer because it only
// does independent per-byte-slot linear interpolation and repacks each slot
// back into its original position - it never assigns channel-specific
// meaning (e.g. luma weighting) to a given slot. If a future native-bitmap
// function needs channel-aware math (denoise, color fade, similarity), it
// MUST NOT reuse resizeBilinear's assumption; convert to the int-array path
// (which is guaranteed ARGB_8888) or add explicit RGBA-aware channel maths.
JNIEXPORT jboolean JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeResizeBitmapInto(

        JNIEnv* env, jobject, jobject srcBitmap, jobject dstBitmap) {
    AndroidBitmapInfo srcInfo, dstInfo;
    void* srcPixels = nullptr;
    void* dstPixels = nullptr;

    if (AndroidBitmap_getInfo(env, srcBitmap, &srcInfo) < 0 ||
        AndroidBitmap_getInfo(env, dstBitmap, &dstInfo) < 0) {
        LOGE("nativeResizeBitmapInto: failed to read bitmap info");
        return JNI_FALSE;
    }
    if (srcInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888 ||
        dstInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        LOGE("nativeResizeBitmapInto: only RGBA_8888 is supported");
        return JNI_FALSE;
    }

    if (AndroidBitmap_lockPixels(env, srcBitmap, &srcPixels) < 0) return JNI_FALSE;
    if (AndroidBitmap_lockPixels(env, dstBitmap, &dstPixels) < 0) {
        AndroidBitmap_unlockPixels(env, srcBitmap);
        return JNI_FALSE;
    }

    std::vector<int32_t> srcVec(srcInfo.width * srcInfo.height);
    memcpy(srcVec.data(), srcPixels, srcVec.size() * sizeof(int32_t));

    auto resized = novaenhance::resizeBilinear(
            srcVec, static_cast<int>(srcInfo.width), static_cast<int>(srcInfo.height),
            static_cast<int>(dstInfo.width), static_cast<int>(dstInfo.height));

    memcpy(dstPixels, resized.data(), resized.size() * sizeof(int32_t));

    AndroidBitmap_unlockPixels(env, srcBitmap);
    AndroidBitmap_unlockPixels(env, dstBitmap);
    return JNI_TRUE;
}


// Edge-aware sharpening of an ARGB int buffer (see filters/upscale.h). Used by the 1x enhancement path, where
// it replaces the plain unsharp mask.
JNIEXPORT jintArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeSmartSharpen(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloat amount, jfloat sigma,
        jfloat overshoot, jint clampRadius, jfloat gateLow, jfloat gateHigh, jint threads) {
    if (!validatePixelArray(env, pixels, width, height, "smartSharpen")) return nullptr;
    auto in = toVector(env, pixels);
    auto out = novaenhance::smartSharpen(
            in, width, height, makeSharpenParams(amount, sigma, overshoot, clampRadius, gateLow, gateHigh), threads);
    return toJavaArray(env, out);
}

// How many real context rows above/below a band smartSharpen needs - the Kotlin side asks instead of
// duplicating the formula, so the two can never disagree.
JNIEXPORT jint JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeSharpenReachRows(
        JNIEnv*, jobject, jfloat sigma, jint clampRadius) {
    novaenhance::SharpenParams p;
    p.amount = 1.0f;
    p.sigma = sigma;
    p.clampRadius = clampRadius;
    return novaenhance::sharpenReachRows(p);
}

// Lanczos-3 upscale of output rows [y0, y1) of `dst` from `src`, plus edge-aware sharpening (filters/upscale.h).
// Works directly on bitmap memory (RGBA_8888, as AndroidBitmap_lockPixels exposes it): no int[] round trip, so a
// 4x result never exists as a second full-size copy. Returns false (with the reason logged) if a bitmap can't be
// locked - e.g. it was recycled or is a hardware bitmap; throws IllegalArgumentException for bad arguments.
JNIEXPORT jboolean JNICALL
Java_com_novaenhance_ai_ai_engine_NativeImageProcessor_nativeUpscaleBand(
        JNIEnv* env, jobject, jobject srcBitmap, jobject dstBitmap, jint factor, jint y0, jint y1,
        jfloat amount, jfloat sigma, jfloat overshoot, jint clampRadius, jfloat gateLow, jfloat gateHigh,
        jint threads) {
    if (srcBitmap == nullptr || dstBitmap == nullptr) {
        throwIllegalArgument(env, "upscaleBand: bitmap is null");
        return JNI_FALSE;
    }
    if (factor < 1 || factor > kMaxUpscaleFactor) {
        throwIllegalArgument(env, "upscaleBand: factor must be in 1.." + std::to_string(kMaxUpscaleFactor) +
                                      " (got " + std::to_string(factor) + ")");
        return JNI_FALSE;
    }

    AndroidBitmapInfo srcInfo, dstInfo;
    if (AndroidBitmap_getInfo(env, srcBitmap, &srcInfo) < 0 || AndroidBitmap_getInfo(env, dstBitmap, &dstInfo) < 0) {
        LOGE("nativeUpscaleBand: failed to read bitmap info");
        return JNI_FALSE;
    }
    if (srcInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888 || dstInfo.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        LOGE("nativeUpscaleBand: only RGBA_8888 bitmaps are supported");
        return JNI_FALSE;
    }
    if (static_cast<int64_t>(dstInfo.width) != static_cast<int64_t>(srcInfo.width) * factor ||
        static_cast<int64_t>(dstInfo.height) != static_cast<int64_t>(srcInfo.height) * factor) {
        throwIllegalArgument(env, "upscaleBand: destination must be exactly factor x the source size");
        return JNI_FALSE;
    }
    if (y0 < 0 || y1 > static_cast<jint>(dstInfo.height) || y0 > y1) {
        throwIllegalArgument(env, "upscaleBand: row range " + std::to_string(y0) + ".." + std::to_string(y1) +
                                      " is outside the " + std::to_string(dstInfo.height) + "-row destination");
        return JNI_FALSE;
    }
    if (y0 == y1) return JNI_TRUE;  // empty band: nothing to do

    void* srcPixels = nullptr;
    void* dstPixels = nullptr;
    if (AndroidBitmap_lockPixels(env, srcBitmap, &srcPixels) < 0) {
        LOGE("nativeUpscaleBand: could not lock the source bitmap");
        return JNI_FALSE;
    }
    if (AndroidBitmap_lockPixels(env, dstBitmap, &dstPixels) < 0) {
        AndroidBitmap_unlockPixels(env, srcBitmap);
        LOGE("nativeUpscaleBand: could not lock the destination bitmap");
        return JNI_FALSE;
    }

    novaenhance::upscaleRows(
            static_cast<const uint8_t*>(srcPixels), srcInfo.stride, static_cast<int>(srcInfo.width),
            static_cast<int>(srcInfo.height), static_cast<uint8_t*>(dstPixels), dstInfo.stride, factor, y0, y1,
            makeSharpenParams(amount, sigma, overshoot, clampRadius, gateLow, gateHigh), threads);

    AndroidBitmap_unlockPixels(env, dstBitmap);
    AndroidBitmap_unlockPixels(env, srcBitmap);
    return JNI_TRUE;
}

// ============================================================================
// NativeNeuralEngine - the from-scratch (no TensorFlow) CNN. See
// nn/network.h for the architecture and nn/network.cpp for the verified
// forward/backward/Adam implementation. Every array here is passed by
// direct reference (GetFloatArrayElements, mode 0 on release) since
// nativeTrainStep mutates params/momentum/velocity IN PLACE - there's no
// native-side persistent state or handle to manage, which keeps the
// Kotlin/JNI lifetime story simple (nothing to leak, nothing to explicitly
// destroy).
// ============================================================================

JNIEXPORT void JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInitializeParams(
        JNIEnv* env, jobject, jfloatArray params, jlong seed) {
    jfloat* p = env->GetFloatArrayElements(params, nullptr);
    novaenhance::nn::initializeParams(p, static_cast<uint32_t>(seed));
    env->ReleaseFloatArrayElements(params, p, 0);
}

JNIEXPORT jfloatArray JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInfer(
        JNIEnv* env, jobject, jfloatArray input, jfloatArray params) {
    jfloat* inputPtr = env->GetFloatArrayElements(input, nullptr);
    jfloat* paramsPtr = env->GetFloatArrayElements(params, nullptr);

    std::vector<float> output(novaenhance::nn::OUTPUT_FLOATS);
    novaenhance::nn::inferForward(inputPtr, paramsPtr, output.data());

    env->ReleaseFloatArrayElements(input, inputPtr, JNI_ABORT);   // read-only, no need to copy back
    env->ReleaseFloatArrayElements(params, paramsPtr, JNI_ABORT); // read-only for inference

    jfloatArray result = env->NewFloatArray(static_cast<jsize>(output.size()));
    if (result == nullptr) {
        return nullptr;  // OOM - JVM already has a pending exception, nothing more to do here
    }
    env->SetFloatArrayRegion(result, 0, static_cast<jsize>(output.size()), output.data());
    return result;
}

JNIEXPORT jfloat JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeTrainStep(
        JNIEnv* env, jobject,
        jfloatArray inputBatch, jfloatArray targetBatch, jint batchSize,
        jfloatArray params, jfloatArray momentum, jfloatArray velocity,
        jfloatArray anchorParams,  // nullable
        jint adamStepNumber, jfloat learningRate, jfloat l2SpLambda,
        jint threads) {
    jfloat* inputPtr = env->GetFloatArrayElements(inputBatch, nullptr);
    jfloat* targetPtr = env->GetFloatArrayElements(targetBatch, nullptr);
    jfloat* paramsPtr = env->GetFloatArrayElements(params, nullptr);
    jfloat* momentumPtr = env->GetFloatArrayElements(momentum, nullptr);
    jfloat* velocityPtr = env->GetFloatArrayElements(velocity, nullptr);
    jfloat* anchorPtr = anchorParams != nullptr ? env->GetFloatArrayElements(anchorParams, nullptr) : nullptr;

    float loss = novaenhance::nn::trainStep(
            inputPtr, targetPtr, batchSize,
            paramsPtr, momentumPtr, velocityPtr,
            anchorPtr, adamStepNumber, learningRate, l2SpLambda, threads);

    env->ReleaseFloatArrayElements(inputBatch, inputPtr, JNI_ABORT);
    env->ReleaseFloatArrayElements(targetBatch, targetPtr, JNI_ABORT);
    env->ReleaseFloatArrayElements(params, paramsPtr, 0);      // mutated - commit back
    env->ReleaseFloatArrayElements(momentum, momentumPtr, 0);  // mutated - commit back
    env->ReleaseFloatArrayElements(velocity, velocityPtr, 0);  // mutated - commit back
    if (anchorParams != nullptr) {
        env->ReleaseFloatArrayElements(anchorParams, anchorPtr, JNI_ABORT);  // read-only
    }

    return loss;
}

// Whole-region inference: ARGB_8888 in, ARGB_8888 out, any size up to kMaxImageDimension. Runs the
// fused streaming forward pass on the shared native thread pool (see nn/inference.h). `out` is a
// caller-owned array of the same length as `pixels` so a band-by-band caller allocates nothing per call.
JNIEXPORT void JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeInferRegion(
        JNIEnv* env, jobject, jintArray pixels, jint width, jint height, jfloatArray params, jint threads,
        jintArray out) {
    if (!validatePixelArray(env, pixels, width, height, "inferRegion")) return;
    if (out == nullptr || env->GetArrayLength(out) != env->GetArrayLength(pixels)) {
        jclass exClass = env->FindClass("java/lang/IllegalArgumentException");
        if (exClass != nullptr) env->ThrowNew(exClass, "inferRegion: out array must match pixels length");
        return;
    }
    if (params == nullptr || env->GetArrayLength(params) != novaenhance::nn::TOTAL_PARAMS) {
        jclass exClass = env->FindClass("java/lang/IllegalArgumentException");
        if (exClass != nullptr) env->ThrowNew(exClass, "inferRegion: params must hold TOTAL_PARAMS floats");
        return;
    }

    const jsize count = env->GetArrayLength(pixels);
    std::vector<uint32_t> input(static_cast<size_t>(count));
    std::vector<uint32_t> output(static_cast<size_t>(count));
    env->GetIntArrayRegion(pixels, 0, count, reinterpret_cast<jint*>(input.data()));
    jfloat* paramsPtr = env->GetFloatArrayElements(params, nullptr);

    novaenhance::nn::inferRegion(input.data(), width, height, paramsPtr, output.data(), threads);

    env->ReleaseFloatArrayElements(params, paramsPtr, JNI_ABORT);  // read-only
    env->SetIntArrayRegion(out, 0, count, reinterpret_cast<const jint*>(output.data()));
}

JNIEXPORT void JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeReleaseTrainingWorkspace(JNIEnv*, jobject) {
    novaenhance::nn::releaseTrainingWorkspace();
}

JNIEXPORT jstring JNICALL
Java_com_novaenhance_ai_ai_engine_NativeNeuralEngine_nativeBackendName(JNIEnv* env, jobject) {
    return env->NewStringUTF(novaenhance::nn::backendName());
}

}  // extern "C"
