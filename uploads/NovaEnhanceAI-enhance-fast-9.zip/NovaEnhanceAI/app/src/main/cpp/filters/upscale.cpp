#include "upscale.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>

#include "util/thread_pool.h"

namespace novaenhance {

namespace {

constexpr int kLanczosA = 3;
constexpr int kTaps = 2 * kLanczosA;  // 6 taps per output sample
constexpr double kPi = 3.14159265358979323846;

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

/** Rows handed to one pool job: enough pixels (~8K) that a job is worth scheduling. */
inline int rowsPerJobFor(int width) { return std::max(2, 8192 / std::max(1, width)); }

/**
 * Runs fn(rowBegin, rowEnd) over [0, rows) in blocks on the shared pool and returns when every block is done.
 * Every stage below computes "output row = f(a few input rows)", so blocks never write the same memory and the
 * result does not depend on how rows are split or which thread ran them.
 */
template <typename Fn>
void forRowBlocks(int rows, int rowsPerJob, int threads, Fn&& fn) {
    if (rows <= 0) return;
    const int jobs = (rows + rowsPerJob - 1) / rowsPerJob;
    if (jobs <= 1) {
        fn(0, rows);
        return;
    }
    const std::function<void(int, int)> job = [&](int j, int /*worker*/) {
        fn(j * rowsPerJob, std::min(rows, (j + 1) * rowsPerJob));
    };
    ThreadPool::instance().parallelFor(jobs, threads, job);
}

SharpenParams sanitize(SharpenParams p) {
    p.amount = std::max(0.0f, p.amount);
    p.sigma = clampf(p.sigma, 0.3f, 8.0f);
    p.overshoot = clampf(p.overshoot, 0.0f, 1.0f);
    p.clampRadius = clampi(p.clampRadius, 1, 4);
    return p;
}

int gaussianRadius(float sigma) { return std::max(1, static_cast<int>(std::ceil(sigma * 3.0f))); }

std::vector<float> makeGaussian(float sigma, int radius) {
    std::vector<double> raw(static_cast<size_t>(2 * radius + 1));
    double sum = 0.0;
    const double twoSigmaSq = 2.0 * static_cast<double>(sigma) * static_cast<double>(sigma);
    for (int i = -radius; i <= radius; ++i) {
        const double v = std::exp(-(static_cast<double>(i) * i) / twoSigmaSq);
        raw[static_cast<size_t>(i + radius)] = v;
        sum += v;
    }
    std::vector<float> kernel(raw.size());
    for (size_t i = 0; i < raw.size(); ++i) kernel[i] = static_cast<float>(raw[i] / sum);
    return kernel;
}

// ----------------------------------------------------------------------------------------------------------
// Luma detail: the shared core of the 1x (ARGB int) and upscaled (RGBA float) sharpening paths.
// ----------------------------------------------------------------------------------------------------------

/**
 * For a luma plane Y (w x h, 0..255) computes, per pixel, the luma change the smart sharpen wants to apply:
 *
 *   detail   = Y - gaussian(Y, sigma)
 *   gate     = smoothstep(gateLow, gateHigh, |sobel(Y)| / 8)          // flat/noisy areas -> 0, edges -> 1
 *   sharp    = Y + amount * gate * detail
 *   result   = clamp(sharp, min - overshoot*range, max + overshoot*range)    // min/max over the (2r+1)^2 window
 *   delta    = result - Y
 *
 * Image edges replicate. Every pixel only reads Y within max(gaussianRadius, clampRadius, 1) rows/columns of it.
 */
void lumaDetailDelta(const float* Y, int w, int h, const SharpenParams& p, float* delta, int threads) {
    const size_t n = static_cast<size_t>(w) * static_cast<size_t>(h);
    const int R = gaussianRadius(p.sigma);
    const std::vector<float> g = makeGaussian(p.sigma, R);
    std::vector<float> tmp(n);
    const int rpj = rowsPerJobFor(w);

    // Horizontal Gaussian: Y -> tmp. Interior columns need no clamping; the k loop is outermost there so the
    // inner x loop is contiguous (and vectorizes) while each pixel still accumulates its taps in the same order.
    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            const float* row = Y + static_cast<size_t>(y) * w;
            float* out = tmp.data() + static_cast<size_t>(y) * w;
            const int xBegin = std::min(R, w);
            const int xEnd = std::max(xBegin, w - R);
            for (int x = 0; x < xBegin; ++x) {
                float acc = 0.0f;
                for (int k = -R; k <= R; ++k) acc += g[static_cast<size_t>(k + R)] * row[clampi(x + k, 0, w - 1)];
                out[x] = acc;
            }
            for (int x = xBegin; x < xEnd; ++x) out[x] = 0.0f;
            for (int k = -R; k <= R; ++k) {
                const float wk = g[static_cast<size_t>(k + R)];
                for (int x = xBegin; x < xEnd; ++x) out[x] += wk * row[x + k];
            }
            for (int x = xEnd; x < w; ++x) {
                float acc = 0.0f;
                for (int k = -R; k <= R; ++k) acc += g[static_cast<size_t>(k + R)] * row[clampi(x + k, 0, w - 1)];
                out[x] = acc;
            }
        }
    });

    // Vertical Gaussian: tmp -> delta (holds the blurred luma until the final stage overwrites it in place).
    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            float* out = delta + static_cast<size_t>(y) * w;
            for (int x = 0; x < w; ++x) out[x] = 0.0f;
            for (int k = -R; k <= R; ++k) {
                const float wk = g[static_cast<size_t>(k + R)];
                const float* src = tmp.data() + static_cast<size_t>(clampi(y + k, 0, h - 1)) * w;
                for (int x = 0; x < w; ++x) out[x] += wk * src[x];
            }
        }
    });

    // Final stage: gate, sharpen, clamp to the local range; delta[i] goes from "blurred luma" to "luma change".
    const int r = p.clampRadius;  // sanitized: 1..4
    std::vector<int> xcl(static_cast<size_t>(w) + 2 * static_cast<size_t>(r));
    for (int i = 0; i < w + 2 * r; ++i) xcl[static_cast<size_t>(i)] = clampi(i - r, 0, w - 1);
    const bool gated = p.gateHigh > p.gateLow;
    const float gateLow = p.gateLow;
    const float gateInv = gated ? 1.0f / (p.gateHigh - p.gateLow) : 0.0f;
    const float amount = p.amount;
    const float overshoot = p.overshoot;

    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        std::vector<const float*> rows(static_cast<size_t>(2 * r + 1));
        for (int y = a; y < b; ++y) {
            for (int dy = -r; dy <= r; ++dy) {
                rows[static_cast<size_t>(dy + r)] = Y + static_cast<size_t>(clampi(y + dy, 0, h - 1)) * w;
            }
            const float* ru = rows[static_cast<size_t>(r - 1)];
            const float* rc = rows[static_cast<size_t>(r)];
            const float* rd = rows[static_cast<size_t>(r + 1)];
            float* out = delta + static_cast<size_t>(y) * w;
            for (int x = 0; x < w; ++x) {
                const int* xc = &xcl[static_cast<size_t>(x + r)];  // xc[dx] = clamped column of x + dx
                const float yc = rc[x];

                float mn = yc, mx = yc;
                for (int dy = 0; dy <= 2 * r; ++dy) {
                    const float* rr = rows[static_cast<size_t>(dy)];
                    for (int dx = -r; dx <= r; ++dx) {
                        const float v = rr[xc[dx]];
                        mn = v < mn ? v : mn;
                        mx = v > mx ? v : mx;
                    }
                }

                const int xl = xc[-1], xr = xc[1];
                const float gx = (ru[xr] + 2.0f * rc[xr] + rd[xr]) - (ru[xl] + 2.0f * rc[xl] + rd[xl]);
                const float gy = (rd[xl] + 2.0f * rd[x] + rd[xr]) - (ru[xl] + 2.0f * ru[x] + ru[xr]);
                const float grad = std::sqrt(gx * gx + gy * gy) * 0.125f;

                float gate = 1.0f;
                if (gated) {
                    const float t = clampf((grad - gateLow) * gateInv, 0.0f, 1.0f);
                    gate = t * t * (3.0f - 2.0f * t);
                }

                const float blur = out[x];
                float sharp = yc + amount * gate * (yc - blur);
                const float range = mx - mn;
                sharp = clampf(sharp, mn - overshoot * range, mx + overshoot * range);
                out[x] = sharp - yc;
            }
        }
    });
}

inline float lumaOf(float r, float g, float b) { return 0.299f * r + 0.587f * g + 0.114f * b; }

inline uint8_t toByte(float v) {
    const int i = static_cast<int>(v + 0.5f);
    return static_cast<uint8_t>(i < 0 ? 0 : (i > 255 ? 255 : i));
}

// ----------------------------------------------------------------------------------------------------------
// Lanczos-3 resampling tables
// ----------------------------------------------------------------------------------------------------------

double lanczos3(double x) {
    const double ax = std::fabs(x);
    if (ax < 1e-9) return 1.0;
    if (ax >= kLanczosA) return 0.0;
    const double px = kPi * x;
    return kLanczosA * std::sin(px) * std::sin(px / kLanczosA) / (px * px);
}

/** Taps for output samples [first, first + count) of one axis: source indices (clamped) and normalised weights. */
struct AxisTable {
    std::vector<int> idx;
    std::vector<float> w;
};

AxisTable makeAxisTable(int first, int count, int srcN, int factor) {
    AxisTable t;
    t.idx.resize(static_cast<size_t>(count) * kTaps);
    t.w.resize(static_cast<size_t>(count) * kTaps);
    for (int i = 0; i < count; ++i) {
        const int out = first + i;
        // Half-pixel-centre mapping, the convention every mainstream resampler uses.
        const double s = (static_cast<double>(out) + 0.5) / factor - 0.5;
        const int base = static_cast<int>(std::floor(s));
        double raw[kTaps];
        double sum = 0.0;
        for (int k = 0; k < kTaps; ++k) {
            raw[k] = lanczos3(s - static_cast<double>(base - (kLanczosA - 1) + k));
            sum += raw[k];
        }
        for (int k = 0; k < kTaps; ++k) {
            t.w[static_cast<size_t>(i) * kTaps + k] = static_cast<float>(raw[k] / sum);
            t.idx[static_cast<size_t>(i) * kTaps + k] = clampi(base - (kLanczosA - 1) + k, 0, srcN - 1);
        }
    }
    return t;
}

}  // namespace

int sharpenReachRows(const SharpenParams& params) {
    const SharpenParams p = sanitize(params);
    return std::max(std::max(gaussianRadius(p.sigma), p.clampRadius), 1);
}

std::vector<int32_t> smartSharpen(const std::vector<int32_t>& pixels, int width, int height,
                                  const SharpenParams& params, int threads) {
    if (pixels.empty() || width <= 0 || height <= 0 || !sharpenEnabled(params)) return pixels;
    const size_t n = static_cast<size_t>(width) * static_cast<size_t>(height);
    if (pixels.size() != n) return pixels;
    const SharpenParams p = sanitize(params);

    std::vector<float> luma(n);
    std::vector<float> delta(n);
    const int rpj = rowsPerJobFor(width);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
            const uint32_t px = static_cast<uint32_t>(pixels[i]);
            luma[i] = lumaOf(static_cast<float>((px >> 16) & 0xFF), static_cast<float>((px >> 8) & 0xFF),
                             static_cast<float>(px & 0xFF));
        }
    });
    lumaDetailDelta(luma.data(), width, height, p, delta.data(), threads);

    std::vector<int32_t> out(n);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
            const uint32_t px = static_cast<uint32_t>(pixels[i]);
            const float d = delta[i];
            const uint32_t alpha = (px >> 24) & 0xFF;
            const uint32_t r = toByte(static_cast<float>((px >> 16) & 0xFF) + d);
            const uint32_t g = toByte(static_cast<float>((px >> 8) & 0xFF) + d);
            const uint32_t bl = toByte(static_cast<float>(px & 0xFF) + d);
            out[i] = static_cast<int32_t>((alpha << 24) | (r << 16) | (g << 8) | bl);
        }
    });
    return out;
}

void upscaleRows(const uint8_t* src, size_t srcStride, int srcW, int srcH,
                 uint8_t* dst, size_t dstStride, int factor, int y0, int y1,
                 const SharpenParams& sharpenIn, int threads) {
    if (src == nullptr || dst == nullptr || srcW <= 0 || srcH <= 0 || factor < 1) return;
    const int dstW = srcW * factor;
    const int dstH = srcH * factor;
    y0 = std::max(0, y0);
    y1 = std::min(dstH, y1);
    if (y0 >= y1) return;

    const SharpenParams sharpen = sanitize(sharpenIn);
    const bool doSharpen = sharpenEnabled(sharpen);
    // Output rows recomputed above/below the band purely as sharpening context (only where the image has them).
    const int reach = doSharpen ? sharpenReachRows(sharpen) : 0;
    const int ys = std::max(0, y0 - reach);
    const int ye = std::min(dstH, y1 + reach);
    const int bandRows = ye - ys;

    const AxisTable xt = makeAxisTable(0, dstW, srcW, factor);
    const AxisTable yt = makeAxisTable(ys, bandRows, srcH, factor);

    // Source rows the vertical taps of this band touch (after edge clamping).
    int r0 = srcH - 1, r1 = 0;
    for (int idx : yt.idx) {
        r0 = std::min(r0, idx);
        r1 = std::max(r1, idx);
    }
    const int srcRows = r1 - r0 + 1;
    const size_t rowFloats = static_cast<size_t>(dstW) * 4;
    const int rpj = rowsPerJobFor(dstW);

    // 1) Horizontal pass: each needed source row, resampled to the output width (float RGBA).
    std::vector<float> hbuf(static_cast<size_t>(srcRows) * rowFloats);
    forRowBlocks(srcRows, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const uint8_t* srow = src + static_cast<size_t>(r0 + r) * srcStride;
            float* out = hbuf.data() + static_cast<size_t>(r) * rowFloats;
            for (int x = 0; x < dstW; ++x) {
                const int* ix = &xt.idx[static_cast<size_t>(x) * kTaps];
                const float* wx = &xt.w[static_cast<size_t>(x) * kTaps];
                float c0 = 0.0f, c1 = 0.0f, c2 = 0.0f, c3 = 0.0f;
                for (int k = 0; k < kTaps; ++k) {
                    const uint8_t* q = srow + static_cast<size_t>(ix[k]) * 4;
                    const float wk = wx[k];
                    c0 += wk * static_cast<float>(q[0]);
                    c1 += wk * static_cast<float>(q[1]);
                    c2 += wk * static_cast<float>(q[2]);
                    c3 += wk * static_cast<float>(q[3]);
                }
                float* o = out + static_cast<size_t>(x) * 4;
                o[0] = c0;
                o[1] = c1;
                o[2] = c2;
                o[3] = c3;
            }
        }
    });

    // 2) Vertical pass: the six taps of every output row, summed in a fixed order.
    std::vector<float> band(static_cast<size_t>(bandRows) * rowFloats);
    forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const int* iy = &yt.idx[static_cast<size_t>(r) * kTaps];
            const float* wy = &yt.w[static_cast<size_t>(r) * kTaps];
            const float* s0 = hbuf.data() + static_cast<size_t>(iy[0] - r0) * rowFloats;
            const float* s1 = hbuf.data() + static_cast<size_t>(iy[1] - r0) * rowFloats;
            const float* s2 = hbuf.data() + static_cast<size_t>(iy[2] - r0) * rowFloats;
            const float* s3 = hbuf.data() + static_cast<size_t>(iy[3] - r0) * rowFloats;
            const float* s4 = hbuf.data() + static_cast<size_t>(iy[4] - r0) * rowFloats;
            const float* s5 = hbuf.data() + static_cast<size_t>(iy[5] - r0) * rowFloats;
            const float w0 = wy[0], w1 = wy[1], w2 = wy[2], w3 = wy[3], w4 = wy[4], w5 = wy[5];
            float* o = band.data() + static_cast<size_t>(r) * rowFloats;
            for (size_t i = 0; i < rowFloats; ++i) {
                o[i] = w0 * s0[i] + w1 * s1[i] + w2 * s2[i] + w3 * s3[i] + w4 * s4[i] + w5 * s5[i];
            }
        }
    });
    std::vector<float>().swap(hbuf);  // release before the sharpening scratch is allocated

    // 3) Smart sharpen on the float band (context rows included so the rows we keep are exact).
    if (doSharpen) {
        const size_t n = static_cast<size_t>(dstW) * static_cast<size_t>(bandRows);
        std::vector<float> luma(n);
        std::vector<float> delta(n);
        forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
            for (int y = a; y < b; ++y) {
                const float* px = band.data() + static_cast<size_t>(y) * rowFloats;
                float* out = luma.data() + static_cast<size_t>(y) * dstW;
                for (int x = 0; x < dstW; ++x) out[x] = lumaOf(px[x * 4], px[x * 4 + 1], px[x * 4 + 2]);
            }
        });
        lumaDetailDelta(luma.data(), dstW, bandRows, sharpen, delta.data(), threads);
        forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
            for (int y = a; y < b; ++y) {
                float* px = band.data() + static_cast<size_t>(y) * rowFloats;
                const float* d = delta.data() + static_cast<size_t>(y) * dstW;
                for (int x = 0; x < dstW; ++x) {
                    px[x * 4] = clampf(px[x * 4] + d[x], 0.0f, 255.0f);
                    px[x * 4 + 1] = clampf(px[x * 4 + 1] + d[x], 0.0f, 255.0f);
                    px[x * 4 + 2] = clampf(px[x * 4 + 2] + d[x], 0.0f, 255.0f);
                }
            }
        });
    }

    // 4) Write the band's own rows. Colour is capped at alpha (premultiplied RGBA); for opaque images a no-op.
    forRowBlocks(y1 - y0, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const float* in = band.data() + static_cast<size_t>(y0 - ys + r) * rowFloats;
            uint8_t* out = dst + static_cast<size_t>(y0 + r) * dstStride;
            for (int x = 0; x < dstW; ++x) {
                const float* px = in + static_cast<size_t>(x) * 4;
                const float alpha = clampf(px[3], 0.0f, 255.0f);
                out[x * 4] = toByte(clampf(px[0], 0.0f, alpha));
                out[x * 4 + 1] = toByte(clampf(px[1], 0.0f, alpha));
                out[x * 4 + 2] = toByte(clampf(px[2], 0.0f, alpha));
                out[x * 4 + 3] = toByte(alpha);
            }
        }
    });
}

}  // namespace novaenhance
