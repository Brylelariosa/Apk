// Verification of the native Lanczos-3 upscaler + edge-aware sharpener (app/src/main/cpp/filters/upscale.cpp):
//
//   1. BAND INVARIANCE  - upscaleRows over any split of the output into row bands, on 1 or many threads, writes
//                         exactly (bit-for-bit) the pixels one whole-image call writes. This is what makes the
//                         seam-free band pipeline in the app (see UpscaleStage.kt) trustworthy.
//   2. REFERENCE MATCH  - against a deliberately naive double-precision implementation of the same algorithm
//                         (no tables, no tiling, no threads): at most 1 level of difference.
//   3. smartSharpen     - the 1x ARGB int path, same reference, alpha preserved.
//   4. SANITY           - flat images stay flat, factor 1 + no sharpening is the identity, output is in range.
//   5. TIMING           - 512x658 -> 4x (the size from the original bug report), 1 thread vs all.
//
//   ./run.sh            full
//   ./run.sh --quick    fewer cases
#include "filters/upscale.h"
#include "util/thread_pool.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

using namespace novaenhance;

namespace {

std::mt19937 rng(7);
bool g_ok = true;
int g_cases = 0;

double nowMs() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// RGBA bytes, tightly packed, deliberately with a row stride > width*4 sometimes (see callers).
std::vector<uint8_t> makeRgba(int w, int h, int kind, size_t stride) {
    std::vector<uint8_t> px(stride * h, 0xAB);  // padding bytes are poisoned: they must never be read
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            uint8_t r, g, b, a = 255;
            switch (kind) {
                case 0: r = rng() & 255; g = rng() & 255; b = rng() & 255; break;                      // noise
                case 1: r = g = b = 200; break;                                                         // flat
                case 2: r = (x * 255) / std::max(1, w - 1); g = (y * 255) / std::max(1, h - 1); b = 90; break;  // gradient
                case 3: r = g = b = (((x / 2) + (y / 2)) & 1) ? 235 : 20; break;                        // hard edges
                default: {                                                                              // "line art"
                    const bool line = ((x * 3 + y * 2) % 11) < 2;
                    r = g = b = line ? 25 : 225;
                    break;
                }
            }
            uint8_t* p = &px[static_cast<size_t>(y) * stride + static_cast<size_t>(x) * 4];
            p[0] = r; p[1] = g; p[2] = b; p[3] = a;
        }
    return px;
}

SharpenParams makeParams(int variant, int factor) {
    SharpenParams p;
    switch (variant) {
        case 0: p.amount = 0.0f; break;                                           // no sharpening
        case 1: p.amount = 1.0f; p.sigma = 0.5f * factor; p.clampRadius = std::max(1, factor / 2); break;
        case 2: p.amount = 2.2f; p.sigma = 2.5f; p.clampRadius = 3; p.overshoot = 0.0f; break;   // wide reach
        case 3: p.amount = 0.7f; p.sigma = 0.8f; p.gateLow = 5; p.gateHigh = 5; break;            // gate disabled
        default: p.amount = 1.4f; p.sigma = 1.3f; p.clampRadius = 1; p.overshoot = 0.3f; break;
    }
    return p;
}

// ------------------------------------------------------------------------------------------------------------
// Naive double-precision reference of the same algorithm.
// ------------------------------------------------------------------------------------------------------------
double lz(double x) {
    const double ax = std::fabs(x);
    if (ax < 1e-9) return 1.0;
    if (ax >= 3.0) return 0.0;
    const double px = M_PI * x;
    return 3.0 * std::sin(px) * std::sin(px / 3.0) / (px * px);
}
int cl(int v, int lo, int hi) { return std::min(hi, std::max(lo, v)); }

// 1-D resample weights for output sample `o` of an axis: returns {firstIndex, weights[6]}.
void taps(int o, int factor, double w[6], int& first) {
    const double s = (o + 0.5) / factor - 0.5;
    first = static_cast<int>(std::floor(s)) - 2;
    double sum = 0;
    for (int k = 0; k < 6; ++k) { w[k] = lz(s - (first + k)); sum += w[k]; }
    for (int k = 0; k < 6; ++k) w[k] /= sum;
}

// planes: 4 channels, double, row-major dstW x dstH
std::vector<double> refResample(const std::vector<uint8_t>& src, size_t stride, int sw, int sh, int factor) {
    const int dw = sw * factor, dh = sh * factor;
    std::vector<double> out(static_cast<size_t>(dw) * dh * 4);
    for (int y = 0; y < dh; ++y) {
        double wy[6]; int fy; taps(y, factor, wy, fy);
        for (int x = 0; x < dw; ++x) {
            double wx[6]; int fx; taps(x, factor, wx, fx);
            for (int c = 0; c < 4; ++c) {
                double acc = 0;
                for (int j = 0; j < 6; ++j) {
                    double row = 0;
                    const int sy = cl(fy + j, 0, sh - 1);
                    for (int k = 0; k < 6; ++k) {
                        const int sx = cl(fx + k, 0, sw - 1);
                        row += wx[k] * src[static_cast<size_t>(sy) * stride + static_cast<size_t>(sx) * 4 + c];
                    }
                    acc += wy[j] * row;
                }
                out[(static_cast<size_t>(y) * dw + x) * 4 + c] = acc;
            }
        }
    }
    return out;
}

// luma delta for a plane, naive: blur radius ceil(3 sigma), Sobel, smoothstep gate, local min/max clamp.
std::vector<double> refDelta(const std::vector<double>& Y, int w, int h, const SharpenParams& p0) {
    SharpenParams p = p0;
    p.sigma = std::min(8.0f, std::max(0.3f, p.sigma));
    p.overshoot = std::min(1.0f, std::max(0.0f, p.overshoot));
    p.clampRadius = std::min(4, std::max(1, p.clampRadius));
    const int R = std::max(1, static_cast<int>(std::ceil(p.sigma * 3.0f)));
    std::vector<double> k(2 * R + 1);
    double sum = 0;
    for (int i = -R; i <= R; ++i) { k[i + R] = std::exp(-(double(i) * i) / (2.0 * double(p.sigma) * p.sigma)); sum += k[i + R]; }
    for (double& v : k) v /= sum;
    auto at = [&](const std::vector<double>& a, int x, int y) { return a[static_cast<size_t>(cl(y, 0, h - 1)) * w + cl(x, 0, w - 1)]; };
    std::vector<double> tmp(Y.size()), blur(Y.size()), delta(Y.size());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { double a = 0; for (int i = -R; i <= R; ++i) a += k[i + R] * at(Y, x + i, y); tmp[static_cast<size_t>(y) * w + x] = a; }
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { double a = 0; for (int i = -R; i <= R; ++i) a += k[i + R] * at(tmp, x, y + i); blur[static_cast<size_t>(y) * w + x] = a; }
    const int r = p.clampRadius;
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
        double mn = 1e9, mx = -1e9;
        for (int dy = -r; dy <= r; ++dy) for (int dx = -r; dx <= r; ++dx) { const double v = at(Y, x + dx, y + dy); mn = std::min(mn, v); mx = std::max(mx, v); }
        const double gx = (at(Y, x + 1, y - 1) + 2 * at(Y, x + 1, y) + at(Y, x + 1, y + 1)) - (at(Y, x - 1, y - 1) + 2 * at(Y, x - 1, y) + at(Y, x - 1, y + 1));
        const double gy = (at(Y, x - 1, y + 1) + 2 * at(Y, x, y + 1) + at(Y, x + 1, y + 1)) - (at(Y, x - 1, y - 1) + 2 * at(Y, x, y - 1) + at(Y, x + 1, y - 1));
        const double grad = std::sqrt(gx * gx + gy * gy) / 8.0;
        double gate = 1.0;
        if (p.gateHigh > p.gateLow) { double t = std::min(1.0, std::max(0.0, (grad - p.gateLow) / (p.gateHigh - p.gateLow))); gate = t * t * (3 - 2 * t); }
        const double yc = Y[static_cast<size_t>(y) * w + x];
        double s = yc + p.amount * gate * (yc - blur[static_cast<size_t>(y) * w + x]);
        const double range = mx - mn;
        s = std::min(mx + p.overshoot * range, std::max(mn - p.overshoot * range, s));
        delta[static_cast<size_t>(y) * w + x] = s - yc;
    }
    return delta;
}

std::vector<uint8_t> refUpscale(const std::vector<uint8_t>& src, size_t stride, int sw, int sh, int factor, const SharpenParams& p) {
    const int dw = sw * factor, dh = sh * factor;
    std::vector<double> f = refResample(src, stride, sw, sh, factor);
    std::vector<double> d;
    if (p.amount > 0) {
        std::vector<double> Y(static_cast<size_t>(dw) * dh);
        for (size_t i = 0; i < Y.size(); ++i) Y[i] = 0.299 * f[i * 4] + 0.587 * f[i * 4 + 1] + 0.114 * f[i * 4 + 2];
        d = refDelta(Y, dw, dh, p);
    }
    std::vector<uint8_t> out(static_cast<size_t>(dw) * dh * 4);
    for (size_t i = 0; i < static_cast<size_t>(dw) * dh; ++i) {
        const double dd = d.empty() ? 0.0 : d[i];
        const double a = std::min(255.0, std::max(0.0, f[i * 4 + 3]));
        for (int c = 0; c < 3; ++c) {
            double v = std::min(255.0, std::max(0.0, f[i * 4 + c] + dd));
            v = std::min(v, a);
            out[i * 4 + c] = static_cast<uint8_t>(std::min(255.0, std::max(0.0, std::floor(v + 0.5))));
        }
        out[i * 4 + 3] = static_cast<uint8_t>(std::floor(a + 0.5));
    }
    return out;
}

void report(const char* what, int w, int h, int factor, int kind, int variant, const char* detail) {
    g_ok = false;
    printf("  [FAIL] %s %dx%d x%d kind=%d sharpen=%d: %s\n", what, w, h, factor, kind, variant, detail);
}

// Compares the used bytes of two destination buffers (stride may include poisoned padding).
int maxDiff(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b, size_t aStride, size_t bStride, int w, int h, size_t* nDiff) {
    int m = 0; *nDiff = 0;
    for (int y = 0; y < h; ++y) for (int x = 0; x < w * 4; ++x) {
        const int d = std::abs(int(a[static_cast<size_t>(y) * aStride + x]) - int(b[static_cast<size_t>(y) * bStride + x]));
        if (d) ++*nDiff;
        m = std::max(m, d);
    }
    return m;
}

void checkCase(int sw, int sh, int factor, int kind, int variant, bool strided, bool quick) {
    const size_t sStride = static_cast<size_t>(sw) * 4 + (strided ? 12 : 0);
    const auto src = makeRgba(sw, sh, kind, sStride);
    const int dw = sw * factor, dh = sh * factor;
    const size_t dStride = static_cast<size_t>(dw) * 4 + (strided ? 20 : 0);
    const SharpenParams p = makeParams(variant, factor);

    // Whole image in one call (the definition of "correct" for the invariance check).
    std::vector<uint8_t> whole(dStride * dh, 0xCD);
    upscaleRows(src.data(), sStride, sw, sh, whole.data(), dStride, factor, 0, dh, p, 1);
    ++g_cases;

    // (1) band invariance
    const int splits[] = {1, 3, 7, std::max(1, dh / 2 + 1), 32};
    for (int bandRows : splits) {
        for (int threads : {1, 0}) {
            std::vector<uint8_t> banded(dStride * dh, 0xCD);
            for (int y = 0; y < dh; y += bandRows) {
                upscaleRows(src.data(), sStride, sw, sh, banded.data(), dStride, factor, y, std::min(dh, y + bandRows), p, threads);
            }
            ++g_cases;
            if (std::memcmp(banded.data(), whole.data(), whole.size()) != 0) {
                size_t n; const int m = maxDiff(banded, whole, dStride, dStride, dw, dh, &n);
                char buf[160]; snprintf(buf, sizeof buf, "band split %d rows, threads=%d differs from whole-image result (%zu bytes, max %d)", bandRows, threads, n, m);
                report("band-invariance", sw, sh, factor, kind, variant, buf);
            }
        }
        if (quick) break;
    }

    // (2) naive reference
    if (static_cast<int64_t>(dw) * dh <= 40000) {
        const auto ref = refUpscale(src, sStride, sw, sh, factor, p);
        size_t n; const int m = maxDiff(whole, ref, dStride, static_cast<size_t>(dw) * 4, dw, dh, &n);
        ++g_cases;
        if (m > 1) { char buf[96]; snprintf(buf, sizeof buf, "differs from reference by up to %d levels (%zu bytes)", m, n); report("reference", sw, sh, factor, kind, variant, buf); }
    }

    // (4) padding bytes untouched
    for (int y = 0; y < dh; ++y) for (size_t i = static_cast<size_t>(dw) * 4; i < dStride; ++i)
        if (whole[static_cast<size_t>(y) * dStride + i] != 0xCD) { report("padding", sw, sh, factor, kind, variant, "wrote outside the row"); y = dh; break; }
}

void checkSmartSharpen(int w, int h, int kind, int variant) {
    const size_t stride = static_cast<size_t>(w) * 4;
    const auto rgba = makeRgba(w, h, kind, stride);
    std::vector<int32_t> argb(static_cast<size_t>(w) * h);
    for (size_t i = 0; i < argb.size(); ++i) {
        const uint8_t a = (i % 5 == 0) ? 77 : 255;  // varied alpha: must be preserved
        argb[i] = static_cast<int32_t>((uint32_t(a) << 24) | (uint32_t(rgba[i * 4]) << 16) | (uint32_t(rgba[i * 4 + 1]) << 8) | rgba[i * 4 + 2]);
    }
    const SharpenParams p = makeParams(variant, 1);
    const auto out1 = smartSharpen(argb, w, h, p, 1);
    const auto outN = smartSharpen(argb, w, h, p, 0);
    ++g_cases;
    if (out1 != outN) report("smartSharpen threads", w, h, 1, kind, variant, "1 thread and pool disagree");
    if (p.amount <= 0) { ++g_cases; if (out1 != argb) report("smartSharpen", w, h, 1, kind, variant, "disabled sharpen must return the input"); return; }
    // reference
    std::vector<double> Y(argb.size());
    for (size_t i = 0; i < Y.size(); ++i) { const uint32_t px = uint32_t(argb[i]); Y[i] = 0.299 * ((px >> 16) & 255) + 0.587 * ((px >> 8) & 255) + 0.114 * (px & 255); }
    const auto d = refDelta(Y, w, h, p);
    int worst = 0;
    for (size_t i = 0; i < argb.size(); ++i) {
        const uint32_t px = uint32_t(argb[i]), o = uint32_t(out1[i]);
        if ((o >> 24) != (px >> 24)) { report("smartSharpen", w, h, 1, kind, variant, "alpha changed"); return; }
        for (int s : {16, 8, 0}) {
            const double v = std::min(255.0, std::max(0.0, double((px >> s) & 255) + d[i]));
            worst = std::max(worst, std::abs(int(std::floor(v + 0.5)) - int((o >> s) & 255)));
        }
    }
    ++g_cases;
    if (worst > 1) { char buf[64]; snprintf(buf, sizeof buf, "differs from reference by up to %d levels", worst); report("smartSharpen", w, h, 1, kind, variant, buf); }
}

void sanity() {
    // flat image: flat output, any factor, any sharpening
    for (int factor : {1, 2, 3, 4}) {
        const int sw = 9, sh = 6, dw = sw * factor, dh = sh * factor;
        const auto src = makeRgba(sw, sh, 1, sw * 4);
        std::vector<uint8_t> dst(static_cast<size_t>(dw) * dh * 4);
        upscaleRows(src.data(), sw * 4, sw, sh, dst.data(), dw * 4, factor, 0, dh, makeParams(1, factor), 0);
        ++g_cases;
        for (size_t i = 0; i < dst.size(); i += 4)
            if (dst[i] != 200 || dst[i + 1] != 200 || dst[i + 2] != 200 || dst[i + 3] != 255) { report("flat", sw, sh, factor, 1, 1, "flat image changed"); break; }
    }
    // factor 1, no sharpening: identity
    {
        const int w = 23, h = 17;
        const auto src = makeRgba(w, h, 0, w * 4);
        std::vector<uint8_t> dst(src.size());
        upscaleRows(src.data(), w * 4, w, h, dst.data(), w * 4, 1, 0, h, makeParams(0, 1), 0);
        ++g_cases;
        if (dst != src) report("identity", w, h, 1, 0, 0, "factor 1 without sharpening must be the identity");
    }
    // out-of-range band request is clamped, empty band is a no-op
    {
        const int w = 8, h = 8;
        const auto src = makeRgba(w, h, 0, w * 4);
        std::vector<uint8_t> dst(static_cast<size_t>(w) * 2 * h * 2 * 4, 0xCD);
        upscaleRows(src.data(), w * 4, w, h, dst.data(), w * 2 * 4, 2, -5, 0, makeParams(1, 2), 0);
        upscaleRows(src.data(), w * 4, w, h, dst.data(), w * 2 * 4, 2, 10, 10, makeParams(1, 2), 0);
        ++g_cases;
        for (uint8_t b : dst) if (b != 0xCD) { report("empty band", w, h, 2, 0, 1, "empty/out-of-range band wrote pixels"); break; }
    }
}

void timing() {
    const int sw = 512, sh = 658, factor = 4;
    const auto src = makeRgba(sw, sh, 4, sw * 4);
    const int dw = sw * factor, dh = sh * factor;
    std::vector<uint8_t> dst(static_cast<size_t>(dw) * dh * 4);
    const SharpenParams p = makeParams(1, factor);
    for (int threads : {1, 0}) {
        const double t0 = nowMs();
        const int band = 256;
        for (int y = 0; y < dh; y += band) upscaleRows(src.data(), sw * 4, sw, sh, dst.data(), dw * 4, factor, y, std::min(dh, y + band), p, threads);
        printf("  512x658 -> %dx%d (4x, sharpen on, 256-row bands), threads=%s: %.0f ms\n", dw, dh, threads == 1 ? "1" : "pool", nowMs() - t0);
    }
}

}  // namespace

int main(int argc, char** argv) {
    const bool quick = argc > 1 && std::string(argv[1]) == "--quick";
    printf("upscale/sharpen verification (%s), pool max threads = %d\n", quick ? "quick" : "full", ThreadPool::instance().maxThreads());

    const int sizes[][2] = {{1, 1}, {2, 3}, {5, 7}, {17, 13}, {31, 9}, {3, 41}, {24, 24}};
    const int factors[] = {1, 2, 3, 4, 8};
    for (const auto& s : sizes)
        for (int factor : factors) {
            if (static_cast<int64_t>(s[0]) * s[1] * factor * factor > 40000 * 4) continue;
            for (int kind = 0; kind < (quick ? 2 : 5); ++kind)
                for (int variant = 0; variant < (quick ? 3 : 5); ++variant)
                    checkCase(s[0], s[1], factor, kind, variant, (kind + variant) % 2 == 0, quick);
        }
    for (const auto& s : sizes)
        for (int kind = 0; kind < 5; ++kind)
            for (int variant = 0; variant < 5; ++variant) checkSmartSharpen(s[0], s[1], kind, variant);
    sanity();
    timing();
    printf("%d checks: %s\n", g_cases, g_ok ? "ALL PASSED" : "FAILURES (see above)");
    return g_ok ? 0 : 1;
}
