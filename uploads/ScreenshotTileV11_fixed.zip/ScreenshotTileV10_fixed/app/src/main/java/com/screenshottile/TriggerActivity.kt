package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowInsets

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * SCREENSHOT TIMING
 * -----------------
 * Primary:  onWindowFocusChanged(hasFocus=true) — fires once the panel animation
 *           is fully complete; most accurate trigger.
 * Fallback: onResume + 600 ms — for home screen / launcher / menus where Android
 *           does not grant focus to a translucent window overlaid on the launcher,
 *           so onWindowFocusChanged(true) never arrives.
 * Both paths are guarded by screenshotTaken so only one fires.
 *
 * SAVE RELIABILITY — HOME SCREEN / LAUNCHER / MENUS
 * --------------------------------------------------
 * Android 12+ shows the screenshot preview animation regardless, but suppresses
 * the MediaStore file write when a non-system Activity surface is visible in the
 * layer stack over the launcher. The fix: if focus was never granted (hadWindowFocus
 * stays false = home screen path), finish() first to remove our surface, then
 * delegate the actual trigger to ScreenshotAccessibilityService.scheduleScreenshot()
 * after a short settle delay.
 *
 * IMPORTANT: do NOT check hasWindowFocus() at call time inside takeScreenshot().
 * The screenshot action itself can cause onWindowFocusChanged(false) to fire
 * between the focus callback and our takeScreenshot() call — making hasWindowFocus()
 * return false even in-app. Use the hadWindowFocus flag instead, which is set
 * only when onWindowFocusChanged(true) genuinely fired for our window.
 *
 * SAVE RELIABILITY — GENERAL
 * --------------------------
 * performGlobalAction() returns a Boolean — true = dispatched, not saved.
 * If it returns false (system briefly busy), we retry once after 200 ms.
 * For the in-app path, finish() is delayed 1500 ms so our foreground component
 * keeps the process at a higher priority while the system completes the async
 * MediaStore write.
 *
 * CPU / GPU
 * ---------
 * • Handler(mainLooper) instead of view.postDelayed — avoids triggering the
 *   view traversal machinery (measure / layout / draw pass) for plain delays.
 * • window.setBackgroundDrawable(null) — prevents first-frame surface composite
 *   from producing a visible flash.
 * • hardwareAccelerated=false in the manifest — no GPU layer allocated at all.
 */
class TriggerActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private var screenshotTaken = false
    private var retryCount = 0
    private var screenshotRunnable: Runnable? = null
    private var finishRunnable: Runnable? = null

    // Set to true the moment onWindowFocusChanged(true) fires for our window.
    // Used in takeScreenshot() to distinguish in-app vs home screen path.
    // Polling hasWindowFocus() inside takeScreenshot() is unreliable — the
    // screenshot action itself can cause focus loss before we read it.
    private var hadWindowFocus = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(null)
        if (ScreenshotAccessibilityService.instance == null) { finish(); return }
    }

    override fun onResume() {
        super.onResume()
        if (!screenshotTaken && screenshotRunnable == null) {
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 600L)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            hadWindowFocus = true
            // On API 30+ the XML attribute alone may not be honoured for gesture
            // navigation, so also hide imperatively before the screenshot fires.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.hide(WindowInsets.Type.navigationBars())
            }
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
            takeScreenshot()
        }
    }

    private fun takeScreenshot() {
        if (screenshotTaken) return

        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finish(); return }

        if (!hadWindowFocus) {
            // HOME SCREEN / LAUNCHER / MENU PATH
            // onWindowFocusChanged(true) never fired — we are over the launcher.
            // Finish first to remove our surface from the composition stack, then
            // let the service fire the screenshot once the surface teardown settles.
            screenshotTaken = true
            finish()
            service.scheduleScreenshot(300L)
            return
        }

        // IN-APP PATH — focus was genuinely granted, fire immediately.
        val dispatched = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        if (!dispatched && retryCount < 1) {
            retryCount++
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 200L)
            return
        }

        screenshotTaken = true

        val r = Runnable { finish() }
        finishRunnable = r
        handler.postDelayed(r, 1500L)
    }

    override fun onPause() {
        super.onPause()
        if (!screenshotTaken) {
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        screenshotRunnable = null
        finishRunnable = null
    }
}
