package com.gary.voidsurvivors

import kotlin.math.*
import kotlin.random.Random

// ═══════════════════════════════════════════════════════════════
//  Data types
// ═══════════════════════════════════════════════════════════════

data class Vec2(var x: Float, var y: Float) {
    fun len() = sqrt(x * x + y * y)
    fun norm(): Vec2 {
        val l = len()
        return if (l > 0.001f) Vec2(x / l, y / l) else Vec2(0f, 0f)
    }
    operator fun plus(o: Vec2)  = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
}

enum class EnemyType { BASIC, FAST, TANK, SHOOTER, SWARM }

enum class Phase { PLAYING, LEVEL_UP, DEAD }

// ── Player ──────────────────────────────────────────────────────

class Player(worldW: Float, worldH: Float) {
    var x = worldW / 2f
    var y = worldH / 2f
    val radius = 26f
    var speed     = 280f
    var maxHp     = 100f
    var hp        = 100f
    var xp        = 0f
    var xpNext    = 60f
    var level     = 1
    var damage    = 20f
    var fireRate  = 1.4f   // shots/sec
    var fireTimer = 0f
    var projectiles = 1
    var range     = 300f
    var regen     = 0f    // hp/sec
    var magnet    = 85f
    var iFrames   = 0f    // invincibility seconds remaining
    val iFrameLen = 0.35f
}

// ── Enemies ─────────────────────────────────────────────────────

class Enemy(
    var x: Float, var y: Float,
    val radius: Float,
    val speed: Float,
    val maxHp: Float,
    var hp: Float,
    val contactDmg: Float,
    val xpDrop: Float,
    val type: EnemyType
) {
    var shootTimer = 2.5f
    var flashTimer = 0f
}

// ── Bullets ─────────────────────────────────────────────────────

class Bullet(
    var x: Float, var y: Float,
    val vx: Float, val vy: Float,
    val damage: Float,
    val radius: Float,
    var life: Float,
    val fromPlayer: Boolean
)

// ── XP Orbs ─────────────────────────────────────────────────────

class XPOrb(var x: Float, var y: Float, val value: Float = 5f, val radius: Float = 7f)

// ── Floating damage/xp text ─────────────────────────────────────

class FloatText(var x: Float, var y: Float, val text: String, var life: Float, val color: Int)

// ── Upgrades ────────────────────────────────────────────────────

enum class UpType { DAMAGE, FIRE_RATE, MAX_HP, SPEED, EXTRA_PROJ, REGEN, MAGNET, HEAL_NOW, RANGE }

data class Upgrade(val type: UpType, val name: String, val desc: String, val rarity: Int)

// ═══════════════════════════════════════════════════════════════
//  Game State
// ═══════════════════════════════════════════════════════════════

class GameState(val worldW: Float, val worldH: Float) {
    val player     = Player(worldW, worldH)
    val enemies    = mutableListOf<Enemy>()
    val bullets    = mutableListOf<Bullet>()
    val orbs       = mutableListOf<XPOrb>()
    val floatTexts = mutableListOf<FloatText>()

    var phase      = Phase.PLAYING
    var wave       = 1
    var waveTimer  = 0f
    var waveDuration   = 30f
    var spawnTimer     = 0f
    var spawnInterval  = 2.0f
    var kills      = 0
    var elapsed    = 0f

    var pendingUpgrades: List<Upgrade> = emptyList()
}

// ═══════════════════════════════════════════════════════════════
//  Game Logic
// ═══════════════════════════════════════════════════════════════

object GameLogic {

    private val rng = Random.Default

    // All possible upgrades (picked randomly on level-up)
    private val UPGRADE_POOL = listOf(
        Upgrade(UpType.DAMAGE,     "Power Up",      "+25% damage",         1),
        Upgrade(UpType.DAMAGE,     "Big Damage",    "+50% damage",         2),
        Upgrade(UpType.DAMAGE,     "Devastate",     "+80% damage",         3),
        Upgrade(UpType.FIRE_RATE,  "Rapid Fire",    "+20% fire rate",      1),
        Upgrade(UpType.FIRE_RATE,  "Hyper Fire",    "+40% fire rate",      2),
        Upgrade(UpType.MAX_HP,     "Tough Skin",    "+30 max HP",          1),
        Upgrade(UpType.MAX_HP,     "Iron Body",     "+70 max HP",          2),
        Upgrade(UpType.SPEED,      "Quick Feet",    "+15% move speed",     1),
        Upgrade(UpType.SPEED,      "Dash",          "+30% move speed",     2),
        Upgrade(UpType.EXTRA_PROJ, "Twin Shot",     "+1 projectile",       2),
        Upgrade(UpType.EXTRA_PROJ, "Triple Shot",   "+2 projectiles",      3),
        Upgrade(UpType.REGEN,      "Regeneration",  "+2 HP/sec",           2),
        Upgrade(UpType.REGEN,      "Life Leech",    "+5 HP/sec",           3),
        Upgrade(UpType.MAGNET,     "Magnet",        "XP attract +60%",     1),
        Upgrade(UpType.HEAL_NOW,   "First Aid",     "Heal 40 HP now",      1),
        Upgrade(UpType.HEAL_NOW,   "Full Restore",  "Heal 80 HP now",      2),
        Upgrade(UpType.RANGE,      "Long Reach",    "+25% attack range",   1),
    )

    fun pickUpgrades(): List<Upgrade> = UPGRADE_POOL.shuffled(rng).take(3)

    fun applyUpgrade(state: GameState, up: Upgrade) {
        val p = state.player
        when (up.type) {
            UpType.DAMAGE      -> p.damage    *= if (up.rarity >= 3) 1.8f else if (up.rarity == 2) 1.5f else 1.25f
            UpType.FIRE_RATE   -> p.fireRate  *= if (up.rarity >= 2) 1.4f else 1.2f
            UpType.MAX_HP      -> { val add = if (up.rarity >= 2) 70f else 30f; p.maxHp += add; p.hp += add }
            UpType.SPEED       -> p.speed     *= if (up.rarity >= 2) 1.3f else 1.15f
            UpType.EXTRA_PROJ  -> p.projectiles += if (up.rarity >= 3) 2 else 1
            UpType.REGEN       -> p.regen     += if (up.rarity >= 3) 5f else 2f
            UpType.MAGNET      -> p.magnet    *= 1.6f
            UpType.HEAL_NOW    -> p.hp = minOf(p.hp + if (up.rarity >= 2) 80f else 40f, p.maxHp)
            UpType.RANGE       -> p.range     *= 1.25f
        }
        state.phase = Phase.PLAYING
    }

    // ── Main update ─────────────────────────────────────────────

    fun update(state: GameState, dt: Float, moveX: Float, moveY: Float) {
        if (state.phase != Phase.PLAYING) return

        val p = state.player
        state.elapsed  += dt
        state.waveTimer += dt

        // Passive regen
        if (p.regen > 0f) p.hp = minOf(p.hp + p.regen * dt, p.maxHp)
        if (p.iFrames > 0f) p.iFrames -= dt

        // Move player (joystick input)
        val mLen = sqrt(moveX * moveX + moveY * moveY)
        if (mLen > 0.01f) {
            val nx = moveX / mLen
            val ny = moveY / mLen
            p.x = (p.x + nx * p.speed * dt).coerceIn(p.radius, state.worldW - p.radius)
            p.y = (p.y + ny * p.speed * dt).coerceIn(p.radius, state.worldH - p.radius)
        }

        // Spawning
        tickSpawn(state, dt)

        // Enemies
        tickEnemies(state, dt)

        // Auto-attack
        p.fireTimer -= dt
        if (p.fireTimer <= 0f && state.enemies.isNotEmpty()) {
            fireWeapon(state)
            p.fireTimer = 1f / p.fireRate
        }

        // Move bullets
        val bIter = state.bullets.iterator()
        while (bIter.hasNext()) {
            val b = bIter.next()
            b.x  += b.vx * dt
            b.y  += b.vy * dt
            b.life -= dt
            if (b.life <= 0f || b.x < -50f || b.x > state.worldW + 50f ||
                b.y < -50f || b.y > state.worldH + 50f) {
                bIter.remove()
            }
        }

        // Bullet ↔ enemy collisions (player bullets only)
        bulletHitEnemies(state)

        // XP orb magnet + pickup
        tickOrbs(state, dt)

        // Float texts
        val ftIter = state.floatTexts.iterator()
        while (ftIter.hasNext()) {
            val ft = ftIter.next()
            ft.y  -= 55f * dt
            ft.life -= dt
            if (ft.life <= 0f) ftIter.remove()
        }

        // Next wave
        if (state.waveTimer >= state.waveDuration) {
            state.wave++
            state.waveTimer = 0f
            state.waveDuration   = (state.waveDuration   * 0.93f).coerceAtLeast(14f)
            state.spawnInterval  = (state.spawnInterval  * 0.82f).coerceAtLeast(0.45f)
        }
    }

    // ── Spawn ───────────────────────────────────────────────────

    private fun tickSpawn(state: GameState, dt: Float) {
        state.spawnTimer -= dt
        if (state.spawnTimer <= 0f) {
            spawnEnemy(state)
            state.spawnTimer = state.spawnInterval
        }
    }

    private fun spawnEnemy(state: GameState) {
        val w = state.worldW; val h = state.worldH
        // Pick spawn edge
        val ex: Float; val ey: Float
        when (rng.nextInt(4)) {
            0 -> { ex = rng.nextFloat() * w;  ey = -50f   }
            1 -> { ex = w + 50f;              ey = rng.nextFloat() * h }
            2 -> { ex = rng.nextFloat() * w;  ey = h + 50f }
            else -> { ex = -50f;              ey = rng.nextFloat() * h }
        }

        val scale = 1f + (state.wave - 1) * 0.18f
        val roll  = rng.nextFloat()

        val enemy = when {
            // Basic — always available
            state.wave < 2 || roll < 0.40f -> Enemy(
                ex, ey, radius = 22f, speed = (85f + rng.nextFloat() * 30f) * scale.coerceAtMost(2.2f),
                maxHp = 40f * scale, hp = 40f * scale, contactDmg = 8f, xpDrop = 5f, type = EnemyType.BASIC
            )
            // Fast
            roll < 0.60f -> Enemy(
                ex, ey, radius = 14f, speed = 185f + rng.nextFloat() * 40f,
                maxHp = 20f * scale, hp = 20f * scale, contactDmg = 5f, xpDrop = 4f, type = EnemyType.FAST
            )
            // Tank (wave 3+)
            roll < 0.76f && state.wave >= 3 -> Enemy(
                ex, ey, radius = 38f, speed = 52f,
                maxHp = 160f * scale, hp = 160f * scale, contactDmg = 18f, xpDrop = 18f, type = EnemyType.TANK
            )
            // Shooter (wave 5+)
            roll < 0.90f && state.wave >= 5 -> Enemy(
                ex, ey, radius = 18f, speed = 65f,
                maxHp = 32f * scale, hp = 32f * scale, contactDmg = 3f, xpDrop = 9f, type = EnemyType.SHOOTER
            )
            // Swarm
            else -> Enemy(
                ex, ey, radius = 11f, speed = 150f + rng.nextFloat() * 55f,
                maxHp = 12f * scale, hp = 12f * scale, contactDmg = 4f, xpDrop = 2f, type = EnemyType.SWARM
            )
        }

        state.enemies.add(enemy)

        // Spawn extra swarmers
        if (enemy.type == EnemyType.SWARM) {
            val extras = rng.nextInt(3) + 1
            repeat(extras) {
                state.enemies.add(Enemy(
                    ex + rng.nextFloat() * 70f - 35f,
                    ey + rng.nextFloat() * 70f - 35f,
                    enemy.radius, enemy.speed, enemy.maxHp, enemy.maxHp,
                    enemy.contactDmg, enemy.xpDrop, EnemyType.SWARM
                ))
            }
        }
    }

    // ── Enemy AI ────────────────────────────────────────────────

    private fun tickEnemies(state: GameState, dt: Float) {
        val p = state.player
        val iter = state.enemies.iterator()

        while (iter.hasNext()) {
            val e = iter.next()

            // Dead → drop XP
            if (e.hp <= 0f) {
                val pieces = (e.xpDrop / 5f).toInt().coerceAtLeast(1)
                repeat(pieces) {
                    state.orbs.add(XPOrb(
                        e.x + rng.nextFloat() * 24f - 12f,
                        e.y + rng.nextFloat() * 24f - 12f, 5f
                    ))
                }
                state.kills++
                state.floatTexts.add(FloatText(e.x, e.y, "+${e.xpDrop.toInt()}xp", 0.9f, 0xFF88FF44.toInt()))
                iter.remove()
                continue
            }

            if (e.flashTimer > 0f) e.flashTimer -= dt

            // Move toward player
            val dx = p.x - e.x
            val dy = p.y - e.y
            val dist = sqrt(dx * dx + dy * dy)
            if (dist > 1f) {
                e.x += (dx / dist) * e.speed * dt
                e.y += (dy / dist) * e.speed * dt
            }

            // Shooter fires a bullet at player
            if (e.type == EnemyType.SHOOTER && dist < 450f) {
                e.shootTimer -= dt
                if (e.shootTimer <= 0f) {
                    val spd = 210f
                    state.bullets.add(Bullet(
                        e.x, e.y,
                        (dx / dist) * spd, (dy / dist) * spd,
                        damage = 11f, radius = 8f, life = 2.8f, fromPlayer = false
                    ))
                    e.shootTimer = 2.5f + rng.nextFloat() * 0.5f
                }
            }

            // Contact damage to player
            if (dist < p.radius + e.radius && p.iFrames <= 0f) {
                p.hp -= e.contactDmg
                p.iFrames = p.iFrameLen
                state.floatTexts.add(FloatText(p.x, p.y - 30f, "-${e.contactDmg.toInt()}", 0.7f, 0xFFFF4455.toInt()))
                if (p.hp <= 0f) { p.hp = 0f; state.phase = Phase.DEAD }
            }
        }

        // Enemy bullets vs player
        val bIter = state.bullets.iterator()
        while (bIter.hasNext()) {
            val b = bIter.next()
            if (b.fromPlayer) continue
            val dx = p.x - b.x
            val dy = p.y - b.y
            if (sqrt(dx * dx + dy * dy) < p.radius + b.radius && p.iFrames <= 0f) {
                p.hp    -= b.damage
                p.iFrames = p.iFrameLen
                state.floatTexts.add(FloatText(p.x, p.y - 30f, "-${b.damage.toInt()}", 0.7f, 0xFFFF4455.toInt()))
                bIter.remove()
                if (p.hp <= 0f) { p.hp = 0f; state.phase = Phase.DEAD }
            }
        }
    }

    // ── Auto-attack ─────────────────────────────────────────────

    private fun fireWeapon(state: GameState) {
        val p = state.player

        // Gather enemies in range, sorted by distance
        data class Candidate(val e: Enemy, val dx: Float, val dy: Float, val dist: Float)

        val inRange = state.enemies
            .mapNotNull { e ->
                val dx = e.x - p.x; val dy = e.y - p.y
                val d  = sqrt(dx * dx + dy * dy)
                if (d <= p.range) Candidate(e, dx, dy, d) else null
            }
            .sortedBy { it.dist }

        if (inRange.isEmpty()) return

        val targets = inRange.take(p.projectiles)
        val bulletSpeed = 500f

        targets.forEach { c ->
            // Tiny random spread for multi-projectile feel
            val spreadAngle = if (p.projectiles > 1) (rng.nextFloat() - 0.5f) * 0.25f else 0f
            val baseAngle   = atan2(c.dy, c.dx) + spreadAngle
            state.bullets.add(Bullet(
                p.x, p.y,
                cos(baseAngle) * bulletSpeed,
                sin(baseAngle) * bulletSpeed,
                damage = p.damage,
                radius = 7f,
                life   = p.range / bulletSpeed,
                fromPlayer = true
            ))
        }
    }

    // ── Bullet ↔ enemy ──────────────────────────────────────────

    private fun bulletHitEnemies(state: GameState) {
        val toRemove = mutableListOf<Bullet>()
        outer@ for (b in state.bullets) {
            if (!b.fromPlayer) continue
            for (e in state.enemies) {
                if (e.hp <= 0f) continue
                val dx = e.x - b.x; val dy = e.y - b.y
                if (sqrt(dx * dx + dy * dy) < e.radius + b.radius) {
                    e.hp -= b.damage
                    e.flashTimer = 0.08f
                    state.floatTexts.add(FloatText(
                        e.x + rng.nextFloat() * 16f - 8f,
                        e.y - 12f,
                        b.damage.toInt().toString(),
                        0.55f, 0xFFFFFF44.toInt()
                    ))
                    toRemove.add(b)
                    continue@outer
                }
            }
        }
        state.bullets.removeAll(toRemove)
    }

    // ── XP orbs ─────────────────────────────────────────────────

    private fun tickOrbs(state: GameState, dt: Float) {
        val p = state.player
        val iter = state.orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val dx   = p.x - orb.x
            val dy   = p.y - orb.y
            val dist = sqrt(dx * dx + dy * dy)

            // Magnet pull
            if (dist < p.magnet && dist > 1f) {
                val spd = 230f + (1f - dist / p.magnet) * 180f
                orb.x += (dx / dist) * spd * dt
                orb.y += (dy / dist) * spd * dt
            }

            // Pickup
            if (dist < p.radius + orb.radius) {
                p.xp += orb.value
                iter.remove()
                if (p.xp >= p.xpNext) {
                    p.xp   -= p.xpNext
                    p.xpNext = (p.xpNext * 1.45f)
                    p.level++
                    state.phase           = Phase.LEVEL_UP
                    state.pendingUpgrades = pickUpgrades()
                }
            }
        }
    }

    // ── Reset ───────────────────────────────────────────────────

    fun reset(state: GameState) {
        val p = state.player
        p.x = state.worldW / 2f;  p.y = state.worldH / 2f
        p.speed = 280f;  p.maxHp = 100f;  p.hp = 100f
        p.xp = 0f;  p.xpNext = 60f;  p.level = 1
        p.damage = 20f;  p.fireRate = 1.4f;  p.fireTimer = 0f
        p.projectiles = 1;  p.range = 300f
        p.regen = 0f;  p.magnet = 85f;  p.iFrames = 0f

        state.enemies.clear();  state.bullets.clear()
        state.orbs.clear();  state.floatTexts.clear()

        state.phase          = Phase.PLAYING
        state.wave           = 1
        state.waveTimer      = 0f
        state.waveDuration   = 30f
        state.spawnTimer     = 0f
        state.spawnInterval  = 2.0f
        state.kills          = 0
        state.elapsed        = 0f
        state.pendingUpgrades = emptyList()
    }
}
