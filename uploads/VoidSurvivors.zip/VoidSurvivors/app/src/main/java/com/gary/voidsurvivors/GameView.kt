package com.gary.voidsurvivors

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.*

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    // ── Thread ───────────────────────────────────────────────────
    private var thread: Thread? = null
    @Volatile private var running = false
    private var lastNano = 0L

    // ── Game state ───────────────────────────────────────────────
    private var state: GameState? = null
    private var sw = 1f; private var sh = 1f   // screen size

    // ── Joystick ─────────────────────────────────────────────────
    private val jBase  = PointF()
    private val jKnob  = PointF()
    private var jActive  = false
    private var jPointer = -1
    private val jRadius  = 90f
    @Volatile private var moveX = 0f
    @Volatile private var moveY = 0f

    // ── Level-up card hit regions (computed each draw) ────────────
    private var cardStartY = 0f; private var cardH = 0f
    private var cardSpacing = 0f; private var cardX = 0f; private var cardW = 0f

    // ── Paints ───────────────────────────────────────────────────
    private val pFill   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    // ── Colours ──────────────────────────────────────────────────
    private val C_BG       = Color.parseColor("#0B0B1A")
    private val C_GRID     = Color.parseColor("#14142A")
    private val C_PLAYER   = Color.parseColor("#00E5FF")
    private val C_GLOW     = Color.parseColor("#5500CCFF")
    private val C_BASIC    = Color.parseColor("#EE3333")
    private val C_FAST     = Color.parseColor("#FF8800")
    private val C_TANK     = Color.parseColor("#992222")
    private val C_SHOOTER  = Color.parseColor("#CC00CC")
    private val C_SWARM    = Color.parseColor("#FF5577")
    private val C_BULP     = Color.parseColor("#FFFF33")   // player bullet
    private val C_BULE     = Color.parseColor("#FF2200")   // enemy bullet
    private val C_XP       = Color.parseColor("#33FF88")
    private val C_HP_BAR   = Color.parseColor("#FF3355")
    private val C_XP_BAR   = Color.parseColor("#00EE66")
    private val C_RANGE    = Color.parseColor("#181835")

    // Reusable path for polygon shapes
    private val shapePath = Path()

    init { holder.addCallback(this) }

    // ── Lifecycle ────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        sw = width.toFloat().coerceAtLeast(1f)
        sh = height.toFloat().coerceAtLeast(1f)
        if (state == null) state = GameState(sw, sh)
        startThread()
    }

    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        sw = w.toFloat(); sh = h.toFloat()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) { stopThread() }

    fun pause()  = stopThread()
    fun resume() { state?.let { startThread() } }

    private fun startThread() {
        if (running) return
        running  = true
        lastNano = System.nanoTime()
        thread   = Thread(this, "GameLoop").also { it.start() }
    }

    private fun stopThread() {
        running = false
        thread?.join(300)
        thread  = null
    }

    // ── Game loop ────────────────────────────────────────────────

    override fun run() {
        while (running) {
            val now  = System.nanoTime()
            val dt   = ((now - lastNano) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastNano = now

            val s = state ?: continue
            GameLogic.update(s, dt, moveX, moveY)

            val canvas = holder.lockCanvas() ?: continue
            try { drawFrame(canvas, s) } finally { holder.unlockCanvasAndPost(canvas) }

            val usedMs = (System.nanoTime() - now) / 1_000_000L
            val sleepMs = 16L - usedMs
            if (sleepMs > 1) Thread.sleep(sleepMs)
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Rendering
    // ══════════════════════════════════════════════════════════════

    private fun drawFrame(c: Canvas, s: GameState) {
        when (s.phase) {
            Phase.PLAYING  -> drawGame(c, s)
            Phase.LEVEL_UP -> { drawGame(c, s); drawLevelUp(c, s) }
            Phase.DEAD     -> drawDead(c, s)
        }
    }

    // ── Game world ───────────────────────────────────────────────

    private fun drawGame(c: Canvas, s: GameState) {
        val p = s.player

        // Background
        pFill.color = C_BG
        c.drawRect(0f, 0f, sw, sh, pFill)

        // Grid
        pStroke.color = C_GRID
        pStroke.strokeWidth = 1f
        val gs = 70f
        var gx = 0f; while (gx <= sw) { c.drawLine(gx, 0f, gx, sh, pStroke); gx += gs }
        var gy = 0f; while (gy <= sh) { c.drawLine(0f, gy, sw, gy, pStroke); gy += gs }

        // Range ring (subtle)
        pStroke.color = C_RANGE
        pStroke.strokeWidth = 1.5f
        c.drawCircle(p.x, p.y, p.range, pStroke)

        // XP orbs
        pFill.color = C_XP
        for (orb in s.orbs) c.drawCircle(orb.x, orb.y, orb.radius, pFill)

        // Bullets
        for (b in s.bullets) {
            pFill.color = if (b.fromPlayer) C_BULP else C_BULE
            c.drawCircle(b.x, b.y, b.radius, pFill)
        }

        // Enemies
        for (e in s.enemies) {
            val base = when (e.type) {
                EnemyType.BASIC   -> C_BASIC
                EnemyType.FAST    -> C_FAST
                EnemyType.TANK    -> C_TANK
                EnemyType.SHOOTER -> C_SHOOTER
                EnemyType.SWARM   -> C_SWARM
            }
            pFill.color = if (e.flashTimer > 0f) Color.WHITE else base
            when (e.type) {
                EnemyType.BASIC   -> drawSquare(c, e.x, e.y, e.radius)
                EnemyType.FAST    -> drawTriangle(c, e.x, e.y, e.radius,
                                        atan2(p.y - e.y, p.x - e.x))
                EnemyType.TANK    -> drawHexagon(c, e.x, e.y, e.radius)
                EnemyType.SHOOTER -> drawDiamond(c, e.x, e.y, e.radius)
                EnemyType.SWARM   -> c.drawCircle(e.x, e.y, e.radius, pFill)
            }
            // Enemy HP bar
            val hpF = (e.hp / e.maxHp).coerceIn(0f, 1f)
            pFill.color = Color.parseColor("#55000000")
            c.drawRect(e.x - e.radius, e.y - e.radius - 10f, e.x + e.radius, e.y - e.radius - 3f, pFill)
            pFill.color = C_HP_BAR
            c.drawRect(e.x - e.radius, e.y - e.radius - 10f, e.x - e.radius + e.radius * 2f * hpF, e.y - e.radius - 3f, pFill)
        }

        // Player glow
        pFill.color = C_GLOW
        c.drawCircle(p.x, p.y, p.radius + 14f, pFill)
        // Player body
        pFill.color = if (p.iFrames > 0f && (p.iFrames * 10).toInt() % 2 == 0) Color.WHITE else C_PLAYER
        c.drawCircle(p.x, p.y, p.radius, pFill)
        pStroke.color = Color.WHITE; pStroke.strokeWidth = 2.5f
        c.drawCircle(p.x, p.y, p.radius, pStroke)

        // Floating texts
        for (ft in s.floatTexts) {
            val alpha = ((ft.life / 0.9f) * 255).toInt().coerceIn(0, 255)
            pText.color = (ft.color and 0x00FFFFFF) or (alpha shl 24)
            pText.textSize = 26f
            pText.textAlign = Paint.Align.CENTER
            c.drawText(ft.text, ft.x, ft.y, pText)
        }

        drawHUD(c, s)
    }

    // ── HUD ──────────────────────────────────────────────────────

    private fun drawHUD(c: Canvas, s: GameState) {
        val p   = s.player
        val pad = 18f
        val bh  = 20f
        val bw  = sw * 0.52f
        val rr  = 5f

        // HP bar
        pFill.color = Color.parseColor("#55000000")
        c.drawRoundRect(pad - 4f, pad - 4f, pad + bw + 4f, pad + bh + 4f, rr, rr, pFill)
        pFill.color = Color.parseColor("#44FF0033")
        c.drawRoundRect(pad, pad, pad + bw, pad + bh, rr, rr, pFill)
        val hpF = (p.hp / p.maxHp).coerceIn(0f, 1f)
        pFill.color = C_HP_BAR
        if (hpF > 0f) c.drawRoundRect(pad, pad, pad + bw * hpF, pad + bh, rr, rr, pFill)
        pText.color = Color.WHITE; pText.textSize = 20f; pText.textAlign = Paint.Align.LEFT
        c.drawText("HP  ${p.hp.toInt()} / ${p.maxHp.toInt()}", pad + 6f, pad + bh - 2f, pText)

        // XP bar
        val xy = pad + bh + 10f
        pFill.color = Color.parseColor("#55000000")
        c.drawRoundRect(pad - 4f, xy - 4f, pad + bw + 4f, xy + bh + 4f, rr, rr, pFill)
        pFill.color = Color.parseColor("#2200FF55")
        c.drawRoundRect(pad, xy, pad + bw, xy + bh, rr, rr, pFill)
        val xpF = (p.xp / p.xpNext).coerceIn(0f, 1f)
        pFill.color = C_XP_BAR
        if (xpF > 0f) c.drawRoundRect(pad, xy, pad + bw * xpF, xy + bh, rr, rr, pFill)
        pText.color = Color.WHITE; pText.textSize = 20f
        c.drawText("LV ${p.level}   XP ${p.xp.toInt()} / ${p.xpNext.toInt()}", pad + 6f, xy + bh - 2f, pText)

        // Top-right stats
        pText.textAlign = Paint.Align.RIGHT; pText.textSize = 24f
        val el = s.elapsed.toInt()
        c.drawText("Wave ${s.wave}   ${el / 60}:%02d".format(el % 60), sw - pad, pad + 22f, pText)
        pText.textSize = 20f
        c.drawText("Kills  ${s.kills}", sw - pad, pad + 48f, pText)

        // Joystick
        if (jActive) {
            pFill.color = Color.parseColor("#38FFFFFF")
            c.drawCircle(jBase.x, jBase.y, jRadius, pFill)
            pFill.color = Color.parseColor("#77FFFFFF")
            c.drawCircle(jKnob.x, jKnob.y, jRadius * 0.44f, pFill)
        }
    }

    // ── Level-up screen ──────────────────────────────────────────

    private fun drawLevelUp(c: Canvas, s: GameState) {
        // Dim overlay
        pFill.color = Color.parseColor("#CC00001A")
        c.drawRect(0f, 0f, sw, sh, pFill)

        pText.textAlign = Paint.Align.CENTER
        pText.color = Color.WHITE; pText.textSize = 56f
        c.drawText("LEVEL  UP!", sw / 2f, sh * 0.18f, pText)
        pText.textSize = 26f; pText.color = Color.parseColor("#AAFFCC")
        c.drawText("Choose an upgrade", sw / 2f, sh * 0.26f, pText)

        val cw  = sw * 0.80f
        val ch  = 100f
        val cx  = (sw - cw) / 2f
        val spc = ch + 22f
        val sy  = sh * 0.33f

        // Store for hit-testing
        cardStartY = sy; cardH = ch; cardSpacing = spc; cardX = cx; cardW = cw

        s.pendingUpgrades.forEachIndexed { i, up ->
            val cy = sy + i * spc

            // Card fill by rarity
            pFill.color = when (up.rarity) {
                3 -> Color.parseColor("#AA6600CC")
                2 -> Color.parseColor("#AA0055CC")
                else -> Color.parseColor("#AA005533")
            }
            c.drawRoundRect(cx, cy, cx + cw, cy + ch, 16f, 16f, pFill)

            // Card border
            pStroke.strokeWidth = 3f
            pStroke.color = when (up.rarity) {
                3 -> Color.parseColor("#CC55FF")
                2 -> Color.parseColor("#55AAFF")
                else -> Color.parseColor("#55FF99")
            }
            c.drawRoundRect(cx, cy, cx + cw, cy + ch, 16f, 16f, pStroke)

            // Rarity label
            val rarityLabel = when (up.rarity) { 3 -> "★★★ EPIC"; 2 -> "★★ RARE"; else -> "★ COMMON" }
            pText.textSize = 18f
            pText.color = pStroke.color
            c.drawText(rarityLabel, sw / 2f, cy + 24f, pText)

            // Name
            pText.color = Color.WHITE; pText.textSize = 30f
            c.drawText(up.name, sw / 2f, cy + 56f, pText)

            // Desc
            pText.color = Color.parseColor("#CCCCCC"); pText.textSize = 22f
            c.drawText(up.desc, sw / 2f, cy + 84f, pText)
        }
    }

    // ── Death screen ─────────────────────────────────────────────

    private fun drawDead(c: Canvas, s: GameState) {
        pFill.color = Color.parseColor("#1A0000")
        c.drawRect(0f, 0f, sw, sh, pFill)

        pText.textAlign = Paint.Align.CENTER
        pText.color = Color.parseColor("#FF3333"); pText.textSize = 68f
        c.drawText("YOU DIED", sw / 2f, sh * 0.28f, pText)

        pText.color = Color.WHITE; pText.textSize = 30f
        val el = s.elapsed.toInt()
        c.drawText("Survived  ${el / 60}m %02ds".format(el % 60), sw / 2f, sh * 0.42f, pText)
        c.drawText("Wave ${s.wave}    Kills ${s.kills}", sw / 2f, sh * 0.51f, pText)
        c.drawText("Level ${s.player.level}", sw / 2f, sh * 0.60f, pText)

        // Restart button
        pFill.color = Color.parseColor("#AA441111")
        c.drawRoundRect(sw * 0.22f, sh * 0.72f, sw * 0.78f, sh * 0.84f, 18f, 18f, pFill)
        pStroke.color = Color.parseColor("#FF4444"); pStroke.strokeWidth = 3f
        c.drawRoundRect(sw * 0.22f, sh * 0.72f, sw * 0.78f, sh * 0.84f, 18f, 18f, pStroke)
        pText.color = Color.WHITE; pText.textSize = 40f
        c.drawText("PLAY AGAIN", sw / 2f, (sh * 0.72f + sh * 0.84f) / 2f + 14f, pText)
    }

    // ══════════════════════════════════════════════════════════════
    //  Shape helpers (all use pFill — set color before calling)
    // ══════════════════════════════════════════════════════════════

    private fun drawSquare(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawRect(cx - r, cy - r, cx + r, cy + r, pFill)
    }

    private fun drawTriangle(c: Canvas, cx: Float, cy: Float, r: Float, angle: Float) {
        shapePath.reset()
        for (i in 0..2) {
            val a = angle + i * (2f * PI.toFloat() / 3f)
            val x = cx + cos(a) * r; val y = cy + sin(a) * r
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    private fun drawHexagon(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        for (i in 0..5) {
            val a = i * (PI.toFloat() / 3f)
            val x = cx + cos(a) * r; val y = cy + sin(a) * r
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    private fun drawDiamond(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        shapePath.moveTo(cx,     cy - r)
        shapePath.lineTo(cx + r, cy)
        shapePath.lineTo(cx,     cy + r)
        shapePath.lineTo(cx - r, cy)
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    // ══════════════════════════════════════════════════════════════
    //  Touch input
    // ══════════════════════════════════════════════════════════════

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action = ev.actionMasked
        val idx    = ev.actionIndex
        val pid    = ev.getPointerId(idx)
        val tx     = ev.getX(idx)
        val ty     = ev.getY(idx)
        val s      = state ?: return true

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                when (s.phase) {
                    Phase.DEAD -> {
                        if (ty > sh * 0.72f && ty < sh * 0.84f) GameLogic.reset(s)
                    }
                    Phase.LEVEL_UP -> {
                        s.pendingUpgrades.forEachIndexed { i, up ->
                            val cy = cardStartY + i * cardSpacing
                            if (tx >= cardX && tx <= cardX + cardW && ty >= cy && ty <= cy + cardH) {
                                GameLogic.applyUpgrade(s, up)
                            }
                        }
                    }
                    Phase.PLAYING -> {
                        if (!jActive) {
                            jPointer = pid
                            jBase.set(tx, ty); jKnob.set(tx, ty)
                            jActive = true; moveX = 0f; moveY = 0f
                        }
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (s.phase == Phase.PLAYING && jActive) {
                    val ji = ev.findPointerIndex(jPointer)
                    if (ji >= 0) {
                        val jx = ev.getX(ji); val jy = ev.getY(ji)
                        val dx = jx - jBase.x;  val dy = jy - jBase.y
                        val d  = sqrt(dx * dx + dy * dy)
                        val clamped = d.coerceAtMost(jRadius)
                        val nx = if (d > 0f) dx / d else 0f
                        val ny = if (d > 0f) dy / d else 0f
                        jKnob.set(jBase.x + nx * clamped, jBase.y + ny * clamped)
                        moveX = clamped / jRadius * nx
                        moveY = clamped / jRadius * ny
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pid == jPointer) {
                    jActive = false; jPointer = -1; moveX = 0f; moveY = 0f
                }
            }
        }
        return true
    }
}
