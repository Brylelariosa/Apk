# Living World Simulator 2.3 (Rust engine)

A procedurally generated planet that is simulated, not painted: plate tectonics build the crust, erosion carves it,
a coupled seasonal climate (sun, pressure belts, winds, ocean gyres, moisture, rain shadows, snow, ice) drives rivers,
lakes, soils and biomes. Everything is rendered live as a streamed, level-of-detail globe from orbit down to the ground.

## Architecture

| Part | Language | Where |
|---|---|---|
| Simulation (noise, tectonics, terrain, climate, hydrology, ecology, "Why?" explanations) | Rust | `rust/src/*.rs` |
| Renderer (OpenGL ES 3, chunk streaming, LOD, clouds, atmosphere), camera, gestures, sim thread | Rust | `render.rs`, `camera.rs`, `app.rs` |
| JNI bridge | Rust (hand-written, no crates) | `jni_bridge.rs` |
| Android shell (window, widgets, dialogs) | Kotlin | `app/src/main/java/...` (3 small files) |

The Rust crate has **no external dependencies**. The CI workflow builds it with `cargo-ndk` (ABIs from `rustAbis=` in
`gradle.properties`) into `app/src/main/jniLibs`, and Gradle only packages the result.

The shared library is named `libvoxelsandbox.so` because the workflow's Rust step looks for exactly that file name.
If you ever want a different name, change both `[lib] name` in `rust/Cargo.toml` + `System.loadLibrary` in `Native.kt`
and the `libvoxelsandbox.so` check in the workflow.

## Controls

* one finger drag - grab the globe (the surface under the finger follows it; slower when the planet is small on screen)
* release - gentle inertia, capped and quickly fading
* pinch - zoom, two-finger twist - rotate the view, two-finger vertical drag - tilt
* double tap - glide to that point and zoom in (zooms back out when already close)
* the **+** in the middle of the screen marks the spot that **Settle here** and **Why?** refer to
* Reset view, Sun +6h, Step, speed (1 hour/s ... 1 million years/s), SIMULATE/PAUSE, layers (DEBUG), "Why?" explains the point under the crosshair

## Play: a living world (new in 2.1)

* **Settle here** puts 400 settlers on the land under the + (it picks the nearest liveable cell if you are on water or ice). The first
  time, the clock starts at 10 years/s so you can watch. People grow, spread along rivers and coasts, found cities, cross seas and
  suffer the planet's real earthquakes, eruptions, floods, droughts and pandemics. Cities show as dots on the day side and glow
  at night.
* Carrying capacity is computed from the simulated planet, not painted: biome, soil fertility, NPP, rivers, coasts, aridity,
  temperature comfort, slope and elevation. Technology (farming -> metals -> industry) raises it; industry stalls on worlds
  without coal, iron and oil, so every planet tells a different story.
* **Chronicle** lists the history (settlements, ages, population milestones, disasters, famines); important events also pop up above the
  bottom bar. "Why?" now also shows habitability and the people living at the crosshair.
* **Climate is the game:** open *Planet parameters*, pick a preset (Ice age, Hothouse, Extreme seasons, ...) or move the dials, and
  tap *Apply*. When only climate settings changed (CO2, sunlight, pressure, tilt, rotation, orbit, salinity) the **continents and your
  people are kept** and only the climate and ecosystems are recomputed from the current state (a few seconds instead of a full planet
  build). Watch deserts spread, ice advance and your civilization react. Changing radius, gravity, ocean cover, geothermal or sea
  level builds a new planet.
* A geological step (1 million years/s) remakes the continents, so every civilization is lost - by design.

## New in 2.3: walk on the planet, plants and props, ground-level sky

**Walk.** The *Walk* button flies in to the ground under the crosshair and drops you there in first person. The joystick
(bottom left) moves, dragging anywhere else looks around, *Jump* hops, the speed button cycles walk / run / fast / turbo /
hyper (3, 9, 40, 160, 800 m/s, so that a whole planet can be crossed), *Exit walk* flies back out. You wade through
shallow water and swim (at half speed) in deep water; steep cliffs are not climbed at the two slow speeds. While walking,
*Settle here*, *Why?* and the debug read-outs refer to the spot you stand on. Code: `walk.rs` (position, vertical motion),
`camera.rs` (first-person pose, look), `app.rs` (commands, joystick input), `WalkStick.kt` + `MainActivity.kt` (controls).

**Zoom.** The orbit camera now zooms in to 2.5 m (it stopped at 60 m before), the terrain refines to 80 cm texels
(level 17) and the ground gets procedural grain at 1 m / 25 cm / 6 cm in the fragment shader, because the texture
alone is a smooth blur at that scale.

**Plants and props** (`flora.rs`, `flora_mesh.rs`, `flora_gl.rs`). Grass, tall grass, flowers, ferns, bushes, rocks,
broadleaf trees, conifers, palms, acacias, cacti and dead trees. They are not painted: the ground is divided into 32 m tiles
on the cube-sphere grid, every tile reads the same simulated climate, snow, fertility and slope as the terrain texture,
decides the biome from it and scatters plants from a deterministic hash, so a tile always holds the same plants. Forests
have clearings and stands, savannas are golden and have acacias, deserts have cacti and rocks, the tundra has rocks and
dwarf shrubs, rainforests have ferns and palms. Everything is drawn instanced (12 draw calls); instances shrink away with
distance (grass 44 m, bushes 110 m, trees 220 m). Tiles are generated on demand within 2.5 ms per frame. If the plant code
ever fails it switches itself off and the rest of the game keeps running.

**Sky.** Close to the ground a sky pass draws a zenith-to-horizon gradient whose horizon colour equals the distance haze of
the terrain (so far land melts into it), the sun with twilight glow, and a drifting cloud deck whose coverage follows the
simulated cloud cover. The haze is strong at ground level and weak from space.

**Chunk streaming fixed for low altitude.** The bounding sphere of every chunk was centred at sea level with 12 km of
padding, which refined all chunks within ~6 km of a low camera to the finest level. Chunks now report a tight sphere around
the middle of their real height range once built (`meta[3]`, `meta[9]`), the split threshold relaxes near the ground
(1.7 px per texel in orbit, 3.6 px at ground level) and up to 700 chunks are kept there instead of 420. City dots are hidden
below 1.5 km (they would float in the air).

## Fixed in 2.2: dots of water on land and in the shallow sea

The dots had three causes, all in how the fine fractal detail is added on top of the simulated planet:

* **Phantom lakes.** The grid stores "lake level == terrain height" wherever there is no lake. The chunk builder flooded a spot
  whenever that level was above the *detailed* height, so every dip of the fractal noise on dry land became a pond (the more rugged
  the land, the more ponds). A spot is now flooded only where the simulation really has a lake: the interpolated lake level must
  exceed the interpolated terrain height (`lake_flooded` in `sampler.rs`, used by the renderer, the camera, the city markers and
  the "Why?" panel alike).
* **Islets and ponds along coasts.** In the shallow shelf (0 to -30 m) the detail had the full land amplitude (up to ~500 m), so it
  pushed tiny islands out of the water and dug ponds into coastal plains. The detail now fades out towards sea level
  (`detail_envelope`) and can never flip a spot between land and sea (`keep_shoreline`): the coastline is exactly where the
  simulation put it.
* **Speckled shallow water.** The sea-floor relief shading used a fixed light direction without removing the part that depends on
  where the spot lies on the globe, so shallow water was tinted by position instead of by slope. Only the slope counts now.

Also fixed: city markers used the smooth cell height, so they could hide under the fractal relief or float over water at a coast;
they now sit on the drawn ground.

Cheaper as a side effect: the deep sea floor (below -1500 m, under opaque water) gets no detail noise, and the fractal noise for the
sea is only evaluated where sea ice needs it.

## Performance (2.1)

* **Visual refresh is paced by real time.** While the simulation ran, every ~18 simulated days all visible terrain tiles were rebuilt
  and the cloud texture regenerated, which kept every worker thread busy forever at month/year-per-second speeds. Refreshes are now
  spaced 1-4 s apart depending on speed, and when the simulation pauses or slows down the latest state is shown immediately.
* **Layers only rebuild when their data changed.** Elevation, rainfall, plates, soil and ocean-depth tiles no longer rebuild on weather
  stamps, only after a slow ecosystem update.
* Loading screen shows how many of the 6 base tiles are ready ("3 of 6 base tiles ready") to make a stuck build visible.
* Same planet, same pixels: nothing about generation, terrain detail or rendering quality was reduced.

## What changed from 1.x

* **Net / perforated look on the planet fixed.** The cloud shell was a 64x32 low-poly sphere: between its vertices the flat
  triangles dip a few kilometres *below* the surface, so the depth test cut a regular lattice of holes into it. The shell is now a
  denser cube-sphere whose vertices are pushed outward so the faceted surface can never sink below the true sphere.
* **Clouds follow the simulation.** Cloud opacity is generated from the simulated cloud cover with a soft threshold on
  domain-warped noise: mean coverage is ~59% with clear gaps (the old mapping was ~88% opaque, a white ball).
* **Swipe rotation fixed.** The old pan moved the globe a fixed distance per pixel (huge when zoomed out, so one swipe could
  spin the planet 300 degrees) and flings carried it much further. Now it is a true "grab the globe" drag with altitude-aware
  gain and a capped, quickly damped inertia.
* **Water budget closes.** Evaporation exceeded precipitation by ~22%; the residual is now returned as ocean rain each month
  (land hydrology and biomes are untouched). Debug panel shows the remaining error (~0%).
* **Smooth simulation time.** Time advances continuously (not one jump per second), keeps accumulating while a slow update runs,
  and slow ecosystem updates no longer block the screen with a loading overlay.
* **Faster generation.** Terrain, climate downscaling, soils/biomes and resources run on all cores (deterministic: the same seed
  gives the same planet on every device and thread count).
* Crash/diagnostic log: Rust panics and Java exceptions are written to `files/crash.log` and shown (with a Copy button) on the next
  launch, since device logs are not readable without a PC.

## Tests

`cargo test --lib` (run by the CI workflow, non-blocking) checks the deterministic math, noise, grid lookups, seed parsing and camera.
