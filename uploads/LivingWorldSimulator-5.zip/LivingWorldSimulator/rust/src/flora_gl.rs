//! OpenGL ES side of the plants: one VAO per kind (mesh buffers + a per-instance buffer), drawn with instancing.
//! Instance data is (x, y, z, scale) and (yaw, tint r, g, b), positions in metres relative to the build anchor, which
//! the vertex shader places in the world with the anchor's position and local east / north / up axes.

use crate::flora::KIND_INFO;
use crate::flora_mesh::*;
use crate::gl::*;
use std::ffi::c_void;
use std::time::Instant;

const FLORA_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec4 aCol;
layout(location = 2) in float aSway;
layout(location = 3) in vec4 iPosScale;
layout(location = 4) in vec4 iYawTint;
uniform mat4 uVP;
uniform vec3 uAnchor;
uniform vec3 uE;
uniform vec3 uN;
uniform vec3 uU;
uniform vec2 uFade;
uniform float uTime;
out vec3 vRel;
out vec3 vCol;
void main() {
    float cy = cos(iYawTint.x);
    float sy = sin(iYawTint.x);
    vec3 lp = aPos * iPosScale.w;
    vec3 rp = vec3(cy * lp.x - sy * lp.y, sy * lp.x + cy * lp.y, lp.z);
    vec3 basePos = uAnchor + uE * iPosScale.x + uN * iPosScale.y + uU * iPosScale.z;
    float dist = length(basePos);
    float k = 1.0 - smoothstep(uFade.x, uFade.y, dist);
    float ph = iPosScale.x * 0.31 + iPosScale.y * 0.47;
    float gust = sin(uTime * 1.6 + ph) + 0.6 * sin(uTime * 2.7 + ph * 1.9);
    rp.x += aSway * gust * 0.07 * iPosScale.w;
    rp.y += aSway * gust * 0.045 * iPosScale.w;
    vec3 wp = basePos + (uE * rp.x + uN * rp.y + uU * rp.z) * k;
    gl_Position = uVP * vec4(wp, 1.0);
    vRel = wp;
    vCol = aCol.rgb * mix(vec3(1.0), iYawTint.yzw, aCol.a);
}
"#;

const FLORA_FS: &str = r#"#version 300 es
precision highp float;
in vec3 vRel;
in vec3 vCol;
uniform vec3 uU;
uniform vec3 uSun;
uniform float uHazeK;
uniform float uHazeAmt;
uniform vec3 uHazeColor;
uniform float uSoft;
out vec4 fragColor;
void main() {
    vec3 U = normalize(uU);
    vec3 f0 = cross(dFdx(vRel), dFdy(vRel));
    float fl = length(f0);
    vec3 fnorm = fl > 1e-12 ? f0 / fl : U;
    float dist = length(vRel);
    vec3 V = -vRel / max(dist, 0.001);
    if (dot(fnorm, V) < 0.0) {
        fnorm = -fnorm;
    }
    vec3 n = normalize(mix(fnorm, U, uSoft));
    vec3 L = normalize(uSun);
    float day = smoothstep(-0.07, 0.10, dot(U, L));
    float diff = max(dot(n, L), 0.0);
    float back = max(dot(-n, L), 0.0) * 0.25;
    vec3 alb = vCol * vCol;
    vec3 ambient = vec3(0.020, 0.028, 0.050) + vec3(0.075, 0.095, 0.135) * day;
    vec3 col = alb * (ambient + vec3(1.10, 1.04, 0.96) * (diff + back) * day);
    float haze = (1.0 - exp(-dist * uHazeK)) * uHazeAmt;
    float hf = mix(0.25, 0.04, clamp(uHazeK * 20000.0, 0.0, 1.0));
    col = mix(col, uHazeColor * (hf + (1.0 - hf) * day), clamp(haze, 0.0, 0.92));
    col = col / (1.0 + 0.18 * col);
    fragColor = vec4(sqrt(max(col, 0.0)), 1.0);
}
"#;

/// per-frame values for drawing (all vectors in world axes, positions relative to the camera)
pub struct FloraDraw {
    pub vp: [f32; 16],
    pub anchor_rel: [f32; 3],
    pub e: [f32; 3],
    pub n: [f32; 3],
    pub u: [f32; 3],
    pub sun: [f32; 3],
    pub haze_k: f32,
    pub haze_amt: f32,
    pub haze_color: [f32; 3],
    /// scales every view range (0 hides everything, 1 = full range)
    pub fade: f32,
}

pub struct FloraGl {
    prog: u32,
    u: [i32; 12],
    vao: [u32; K_COUNT],
    vbo: [u32; K_COUNT],
    ibo: [u32; K_COUNT],
    inst: [u32; K_COUNT],
    idx_count: [i32; K_COUNT],
    count: [i32; K_COUNT],
    start: Instant,
    pub ready: bool,
    pub error: String,
}

impl FloraGl {
    pub fn new() -> FloraGl {
        FloraGl {
            prog: 0,
            u: [-1; 12],
            vao: [0; K_COUNT],
            vbo: [0; K_COUNT],
            ibo: [0; K_COUNT],
            inst: [0; K_COUNT],
            idx_count: [0; K_COUNT],
            count: [0; K_COUNT],
            start: Instant::now(),
            ready: false,
            error: String::new(),
        }
    }

    /// compile the shader and upload the meshes (call with a current GL context)
    pub fn init(&mut self) {
        self.ready = false;
        self.error.clear();
        self.prog = 0;
        for k in 0..K_COUNT {
            self.vao[k] = 0;
            self.vbo[k] = 0;
            self.ibo[k] = 0;
            self.inst[k] = 0;
            self.count[k] = 0;
            self.idx_count[k] = 0;
        }
        match compile_program(FLORA_VS, FLORA_FS) {
            Ok(p) => self.prog = p,
            Err(e) => {
                self.error = format!("plants shader {}", e);
                log(&self.error);
                return;
            }
        }
        let names = ["uVP", "uAnchor", "uE", "uN", "uU", "uSun", "uHazeK", "uHazeAmt", "uHazeColor", "uFade", "uSoft", "uTime"];
        for i in 0..names.len() {
            self.u[i] = uniform_loc(self.prog, names[i]);
        }
        let meshes = build_meshes();
        for k in 0..K_COUNT {
            let m = &meshes[k];
            let mut vao = 0u32;
            let mut vbo = 0u32;
            let mut ibo = 0u32;
            let mut inst = 0u32;
            unsafe {
                glGenVertexArrays(1, &mut vao);
                glBindVertexArray(vao);
                glGenBuffers(1, &mut vbo);
                glBindBuffer(GL_ARRAY_BUFFER, vbo);
                glBufferData(GL_ARRAY_BUFFER, (m.verts.len() * 4) as isize, m.verts.as_ptr() as *const c_void, GL_STATIC_DRAW);
                glEnableVertexAttribArray(0);
                glVertexAttribPointer(0, 3, GL_FLOAT, 0, 32, std::ptr::null());
                glEnableVertexAttribArray(1);
                glVertexAttribPointer(1, 4, GL_FLOAT, 0, 32, 12usize as *const c_void);
                glEnableVertexAttribArray(2);
                glVertexAttribPointer(2, 1, GL_FLOAT, 0, 32, 28usize as *const c_void);
                glGenBuffers(1, &mut ibo);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
                glBufferData(GL_ELEMENT_ARRAY_BUFFER, (m.idx.len() * 2) as isize, m.idx.as_ptr() as *const c_void, GL_STATIC_DRAW);
                glGenBuffers(1, &mut inst);
                glBindBuffer(GL_ARRAY_BUFFER, inst);
                glBufferData(GL_ARRAY_BUFFER, 32, std::ptr::null(), GL_DYNAMIC_DRAW);
                glEnableVertexAttribArray(3);
                glVertexAttribPointer(3, 4, GL_FLOAT, 0, 32, std::ptr::null());
                glVertexAttribDivisor(3, 1);
                glEnableVertexAttribArray(4);
                glVertexAttribPointer(4, 4, GL_FLOAT, 0, 32, 16usize as *const c_void);
                glVertexAttribDivisor(4, 1);
                glBindVertexArray(0);
                glBindBuffer(GL_ARRAY_BUFFER, 0);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
            }
            self.vao[k] = vao;
            self.vbo[k] = vbo;
            self.ibo[k] = ibo;
            self.inst[k] = inst;
            self.idx_count[k] = m.idx.len() as i32;
        }
        self.ready = true;
    }

    /// the GL context is gone: forget every object name
    pub fn lose(&mut self) {
        self.prog = 0;
        for k in 0..K_COUNT {
            self.vao[k] = 0;
            self.vbo[k] = 0;
            self.ibo[k] = 0;
            self.inst[k] = 0;
            self.count[k] = 0;
        }
        self.ready = false;
    }

    /// replace the instances of one kind (8 floats each: x y z scale yaw r g b)
    pub fn upload_kind(&mut self, k: usize, data: &[f32]) {
        if !self.ready || k >= K_COUNT {
            return;
        }
        let n = data.len() / 8;
        self.count[k] = n as i32;
        unsafe {
            glBindBuffer(GL_ARRAY_BUFFER, self.inst[k]);
            glBufferData(GL_ARRAY_BUFFER, (n * 32) as isize, data.as_ptr() as *const c_void, GL_DYNAMIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }
    }

    pub fn draw(&self, d: &FloraDraw) {
        if !self.ready || self.prog == 0 {
            return;
        }
        let u = self.u;
        let t = (self.start.elapsed().as_secs_f64() % 3600.0) as f32;
        unsafe {
            glUseProgram(self.prog);
            glUniformMatrix4fv(u[0], 1, 0, d.vp.as_ptr());
            glUniform3f(u[1], d.anchor_rel[0], d.anchor_rel[1], d.anchor_rel[2]);
            glUniform3f(u[2], d.e[0], d.e[1], d.e[2]);
            glUniform3f(u[3], d.n[0], d.n[1], d.n[2]);
            glUniform3f(u[4], d.u[0], d.u[1], d.u[2]);
            glUniform3f(u[5], d.sun[0], d.sun[1], d.sun[2]);
            glUniform1f(u[6], d.haze_k);
            glUniform1f(u[7], d.haze_amt);
            glUniform3f(u[8], d.haze_color[0], d.haze_color[1], d.haze_color[2]);
            glUniform1f(u[11], t);
            for k in 0..K_COUNT {
                if self.count[k] <= 0 {
                    continue;
                }
                let range = (KIND_INFO[k].range as f32) * d.fade;
                if range < 1.0 {
                    continue;
                }
                glUniform2f(u[9], range * 0.72, range);
                glUniform1f(u[10], KIND_INFO[k].soft);
                glBindVertexArray(self.vao[k]);
                glDrawElementsInstanced(GL_TRIANGLES, self.idx_count[k], GL_UNSIGNED_SHORT, std::ptr::null(), self.count[k]);
            }
            glBindVertexArray(0);
        }
    }
}
