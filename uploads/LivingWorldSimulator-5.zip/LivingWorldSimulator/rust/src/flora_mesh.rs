//! Procedural low-poly meshes for plants and props (grass, flowers, ferns, bushes, rocks and several kinds of trees).
//! They are built once at start-up and drawn instanced. Coordinates are metres in a local frame with x = east,
//! y = north, z = up and the origin at the foot of the object. A vertex is (x, y, z, r, g, b, tint, sway): the colour
//! is an sRGB-ish albedo, `tint` says how much of the per-instance tint colour is multiplied into it (0 keeps the
//! colour, 1 takes it fully) and `sway` (0..1) how much the vertex moves in the wind.

use crate::mathx::*;
use std::collections::HashMap;

pub const K_GRASS: usize = 0;
pub const K_TALL_GRASS: usize = 1;
pub const K_FLOWER: usize = 2;
pub const K_FERN: usize = 3;
pub const K_BUSH: usize = 4;
pub const K_ROCK: usize = 5;
pub const K_BROADLEAF: usize = 6;
pub const K_CONIFER: usize = 7;
pub const K_PALM: usize = 8;
pub const K_ACACIA: usize = 9;
pub const K_CACTUS: usize = 10;
pub const K_DEAD_TREE: usize = 11;
pub const K_COUNT: usize = 12;

/// floats per vertex: x y z r g b tint sway
pub const VERT_FLOATS: usize = 8;

pub struct Mesh {
    pub verts: Vec<f32>,
    pub idx: Vec<u16>,
}

struct Builder {
    verts: Vec<f32>,
    idx: Vec<u16>,
}

impl Builder {
    fn new() -> Builder {
        Builder { verts: Vec::new(), idx: Vec::new() }
    }

    fn vert(&mut self, p: V3, c: [f32; 3], tint: f32, sway: f32) -> u16 {
        let i = (self.verts.len() / VERT_FLOATS) as u16;
        self.verts.push(p.x as f32);
        self.verts.push(p.y as f32);
        self.verts.push(p.z as f32);
        self.verts.push(c[0]);
        self.verts.push(c[1]);
        self.verts.push(c[2]);
        self.verts.push(tint);
        self.verts.push(sway);
        i
    }

    fn tri(&mut self, a: u16, b: u16, c: u16) {
        self.idx.push(a);
        self.idx.push(b);
        self.idx.push(c);
    }

    fn finish(self) -> Mesh {
        Mesh { verts: self.verts, idx: self.idx }
    }
}

fn mix3(a: [f32; 3], b: [f32; 3], t: f32) -> [f32; 3] {
    [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
}

fn hash01(seed: u64, k: u64) -> f64 {
    let h = mix64(seed.wrapping_mul(0x9E3779B97F4A7C15u64).wrapping_add(k.wrapping_mul(0xD1B54A32D192ED03u64)));
    ((h >> 11) as f64) * (1.0 / 9007199254740992.0)
}

// ---------------------------------------------------------------------------------------------------
// building blocks
// ---------------------------------------------------------------------------------------------------

/// A bent grass blade: a ribbon of three triangles that narrows towards the tip and leans outwards.
fn blade(b: &mut Builder, ang: f64, r0: f64, lean: f64, height: f64, width: f64, c0: [f32; 3], c1: [f32; 3], tint: f32) {
    let (s, c) = dsincos(ang);
    let bx = c * r0;
    let by = s * r0;
    let hw = width * 0.5;
    let p0 = V3::new(bx - s * hw, by + c * hw, 0.0);
    let p1 = V3::new(bx + s * hw, by - c * hw, 0.0);
    let mx = bx + c * lean * 0.35;
    let my = by + s * lean * 0.35;
    let mh = height * 0.55;
    let q0 = V3::new(mx - s * hw * 0.6, my + c * hw * 0.6, mh);
    let q1 = V3::new(mx + s * hw * 0.6, my - c * hw * 0.6, mh);
    let tip = V3::new(bx + c * lean, by + s * lean, height);
    let cm = mix3(c0, c1, 0.55);
    let a = b.vert(p0, c0, tint, 0.0);
    let d = b.vert(p1, c0, tint, 0.0);
    let m0 = b.vert(q0, cm, tint, 0.35);
    let m1 = b.vert(q1, cm, tint, 0.35);
    let t = b.vert(tip, c1, tint, 1.0);
    b.tri(a, d, m1);
    b.tri(a, m1, m0);
    b.tri(m0, m1, t);
}

/// A curved leaf strip that rises and then droops, tapering to a point (ferns, palm fronds).
fn frond(b: &mut Builder, base: V3, az: f64, length: f64, width: f64, rise: f64, droop: f64, segs: usize, c0: [f32; 3], c1: [f32; 3], tint: f32) {
    let (s, c) = dsincos(az);
    let mut prev: Option<(u16, u16)> = None;
    for i in 0..=segs {
        let t = (i as f64) / (segs as f64);
        let out = length * t;
        let z = rise * t - droop * t * t;
        let w = width * (1.0 - t * 0.92) * 0.5;
        let cx = base.x + c * out;
        let cy = base.y + s * out;
        let cz = base.z + z;
        let col = mix3(c0, c1, t as f32);
        let l = b.vert(V3::new(cx - s * w, cy + c * w, cz), col, tint, t as f32);
        let r = b.vert(V3::new(cx + s * w, cy - c * w, cz), col, tint, t as f32);
        if let Some((pl, pr)) = prev {
            b.tri(pl, pr, r);
            b.tri(pl, r, l);
        }
        prev = Some((l, r));
    }
}

/// a tapered tube between two points (trunks, branches, cactus arms, cones when r1 is 0)
fn frustum(b: &mut Builder, p0: V3, p1: V3, r0: f64, r1: f64, segs: usize, c0: [f32; 3], c1: [f32; 3], tint: f32, sway0: f32, sway1: f32) {
    let axis = normalize(p1 - p0);
    let helper = if axis.z.abs() > 0.9 { V3::new(1.0, 0.0, 0.0) } else { V3::new(0.0, 0.0, 1.0) };
    let u = normalize(cross(axis, helper));
    let w = cross(axis, u);
    let mut ring0: Vec<u16> = Vec::with_capacity(segs);
    let mut ring1: Vec<u16> = Vec::with_capacity(segs);
    for k in 0..segs {
        let a = (k as f64) * (TAU / (segs as f64));
        let (s, c) = dsincos(a);
        let off = u * c + w * s;
        ring0.push(b.vert(p0 + off * r0, c0, tint, sway0));
        ring1.push(b.vert(p1 + off * r1, c1, tint, sway1));
    }
    for k in 0..segs {
        let k2 = (k + 1) % segs;
        b.tri(ring0[k], ring0[k2], ring1[k2]);
        b.tri(ring0[k], ring1[k2], ring1[k]);
    }
}

fn midpoint(v: &mut Vec<V3>, cache: &mut HashMap<(usize, usize), usize>, a: usize, b: usize) -> usize {
    let key = if a < b { (a, b) } else { (b, a) };
    if let Some(&i) = cache.get(&key) {
        return i;
    }
    let m = normalize((v[a] + v[b]) * 0.5);
    v.push(m);
    let i = v.len() - 1;
    cache.insert(key, i);
    i
}

/// unit icosphere with shared vertices; `subdiv` 0 = 12 vertices / 20 faces, 1 = 42 / 80
fn icosphere(subdiv: usize) -> (Vec<V3>, Vec<[usize; 3]>) {
    let t = (1.0 + 5.0f64.sqrt()) / 2.0;
    let raw: [(f64, f64, f64); 12] = [
        (-1.0, t, 0.0),
        (1.0, t, 0.0),
        (-1.0, -t, 0.0),
        (1.0, -t, 0.0),
        (0.0, -1.0, t),
        (0.0, 1.0, t),
        (0.0, -1.0, -t),
        (0.0, 1.0, -t),
        (t, 0.0, -1.0),
        (t, 0.0, 1.0),
        (-t, 0.0, -1.0),
        (-t, 0.0, 1.0),
    ];
    let mut v: Vec<V3> = Vec::new();
    for p in raw.iter() {
        v.push(normalize(V3::new(p.0, p.1, p.2)));
    }
    let mut f: Vec<[usize; 3]> = vec![
        [0, 11, 5],
        [0, 5, 1],
        [0, 1, 7],
        [0, 7, 10],
        [0, 10, 11],
        [1, 5, 9],
        [5, 11, 4],
        [11, 10, 2],
        [10, 7, 6],
        [7, 1, 8],
        [3, 9, 4],
        [3, 4, 2],
        [3, 2, 6],
        [3, 6, 8],
        [3, 8, 9],
        [4, 9, 5],
        [2, 4, 11],
        [6, 2, 10],
        [8, 6, 7],
        [9, 8, 1],
    ];
    for _ in 0..subdiv {
        let mut cache: HashMap<(usize, usize), usize> = HashMap::new();
        let mut nf: Vec<[usize; 3]> = Vec::with_capacity(f.len() * 4);
        for tri in f.iter() {
            let a = tri[0];
            let b = tri[1];
            let c = tri[2];
            let ab = midpoint(&mut v, &mut cache, a, b);
            let bc = midpoint(&mut v, &mut cache, b, c);
            let ca = midpoint(&mut v, &mut cache, c, a);
            nf.push([a, ab, ca]);
            nf.push([b, bc, ab]);
            nf.push([c, ca, bc]);
            nf.push([ab, bc, ca]);
        }
        f = nf;
    }
    (v, f)
}

/// A lumpy ellipsoid (leaf crowns, bushes, boulders). Every vertex is pushed in or out by up to rough / 2.
fn blob(b: &mut Builder, centre: V3, radii: V3, subdiv: usize, seed: u64, rough: f64, c_bot: [f32; 3], c_top: [f32; 3], tint: f32, sway: f32) {
    let (verts, faces) = icosphere(subdiv);
    let mut ids: Vec<u16> = Vec::with_capacity(verts.len());
    for (k, p) in verts.iter().enumerate() {
        let jit = 1.0 + rough * (hash01(seed, k as u64) - 0.5);
        let q = V3::new(centre.x + p.x * radii.x * jit, centre.y + p.y * radii.y * jit, centre.z + p.z * radii.z * jit);
        let t = (p.z * 0.5 + 0.5) as f32;
        ids.push(b.vert(q, mix3(c_bot, c_top, t), tint, sway * (0.5 + 0.5 * t)));
    }
    for f in faces.iter() {
        b.tri(ids[f[0]], ids[f[1]], ids[f[2]]);
    }
}

// ---------------------------------------------------------------------------------------------------
// the plants
// ---------------------------------------------------------------------------------------------------

fn grass_tuft() -> Mesh {
    let mut b = Builder::new();
    let heights = [0.30, 0.42, 0.26, 0.38, 0.34, 0.46, 0.28];
    for i in 0..7usize {
        let ang = (i as f64) * (TAU / 7.0) + 0.35 * (((i * 5) % 7) as f64);
        let r0 = 0.03 + 0.012 * ((i % 3) as f64);
        let lean = 0.10 + 0.05 * ((i % 4) as f64);
        blade(&mut b, ang, r0, lean, heights[i], 0.05, [0.20, 0.30, 0.10], [0.62, 0.82, 0.36], 1.0);
    }
    b.finish()
}

fn tall_grass() -> Mesh {
    let mut b = Builder::new();
    let heights = [0.95, 1.15, 0.80, 1.05, 0.90, 1.10];
    for i in 0..6usize {
        let ang = (i as f64) * (TAU / 6.0) + 0.5 * (((i * 3) % 5) as f64);
        let r0 = 0.02 + 0.015 * ((i % 2) as f64);
        let lean = 0.18 + 0.07 * ((i % 3) as f64);
        blade(&mut b, ang, r0, lean, heights[i], 0.045, [0.30, 0.38, 0.14], [0.78, 0.74, 0.38], 1.0);
    }
    b.finish()
}

fn flower() -> Mesh {
    let mut b = Builder::new();
    blade(&mut b, 0.0, 0.0, 0.03, 0.32, 0.025, [0.18, 0.30, 0.10], [0.28, 0.45, 0.16], 0.4);
    let centre = b.vert(V3::new(0.0, 0.0, 0.345), [1.0, 0.86, 0.35], 0.25, 1.0);
    let mut ring: Vec<u16> = Vec::new();
    for k in 0..6usize {
        let a = (k as f64) * (TAU / 6.0);
        let (s, c) = dsincos(a);
        ring.push(b.vert(V3::new(c * 0.065, s * 0.065, 0.375), [1.0, 1.0, 1.0], 1.0, 1.0));
    }
    for k in 0..6usize {
        b.tri(centre, ring[k], ring[(k + 1) % 6]);
    }
    b.finish()
}

fn fern() -> Mesh {
    let mut b = Builder::new();
    for k in 0..7usize {
        let az = (k as f64) * (TAU / 7.0) + 0.3;
        frond(&mut b, V3::new(0.0, 0.0, 0.02), az, 0.80, 0.20, 0.42, 0.55, 3, [0.08, 0.26, 0.08], [0.24, 0.52, 0.18], 1.0);
    }
    b.finish()
}

fn bush() -> Mesh {
    let mut b = Builder::new();
    let c0 = [0.11, 0.26, 0.08];
    let c1 = [0.28, 0.50, 0.17];
    blob(&mut b, V3::new(0.0, 0.0, 0.42), V3::new(0.62, 0.60, 0.46), 1, 31, 0.32, c0, c1, 1.0, 0.4);
    blob(&mut b, V3::new(0.48, 0.22, 0.34), V3::new(0.40, 0.38, 0.32), 0, 32, 0.32, c0, c1, 1.0, 0.4);
    blob(&mut b, V3::new(-0.38, -0.30, 0.32), V3::new(0.38, 0.36, 0.30), 0, 33, 0.32, c0, c1, 1.0, 0.4);
    b.finish()
}

fn rock() -> Mesh {
    let mut b = Builder::new();
    blob(&mut b, V3::new(0.0, 0.0, 0.16), V3::new(0.55, 0.46, 0.34), 1, 41, 0.55, [0.28, 0.27, 0.25], [0.52, 0.50, 0.46], 0.25, 0.0);
    b.finish()
}

fn broadleaf() -> Mesh {
    let mut b = Builder::new();
    let bark = [0.34, 0.23, 0.14];
    frustum(&mut b, V3::new(0.0, 0.0, 0.0), V3::new(0.08, 0.0, 2.9), 0.21, 0.10, 6, bark, [0.28, 0.19, 0.12], 0.12, 0.0, 0.05);
    blob(&mut b, V3::new(0.05, 0.0, 4.5), V3::new(2.3, 2.3, 1.9), 1, 11, 0.30, [0.12, 0.30, 0.09], [0.30, 0.58, 0.20], 1.0, 0.5);
    blob(&mut b, V3::new(1.35, 0.55, 3.7), V3::new(1.35, 1.30, 1.10), 0, 12, 0.30, [0.12, 0.30, 0.09], [0.28, 0.54, 0.18], 1.0, 0.5);
    blob(&mut b, V3::new(-1.25, -0.70, 3.8), V3::new(1.25, 1.20, 1.05), 0, 13, 0.30, [0.12, 0.30, 0.09], [0.28, 0.54, 0.18], 1.0, 0.5);
    b.finish()
}

fn conifer() -> Mesh {
    let mut b = Builder::new();
    frustum(&mut b, V3::new(0.0, 0.0, 0.0), V3::new(0.0, 0.0, 1.4), 0.17, 0.12, 6, [0.30, 0.20, 0.12], [0.26, 0.18, 0.11], 0.1, 0.0, 0.03);
    let tiers: [(f64, f64, f64); 4] = [(0.9, 1.75, 2.3), (2.2, 1.40, 2.1), (3.4, 1.05, 1.9), (4.5, 0.70, 1.7)];
    for (i, t) in tiers.iter().enumerate() {
        let shade = 1.0 - 0.08 * (i as f32);
        let low = [0.07 * shade, 0.20 * shade, 0.11 * shade];
        frustum(&mut b, V3::new(0.0, 0.0, t.0), V3::new(0.0, 0.0, t.0 + t.2), t.1, 0.0, 8, low, [0.15, 0.36, 0.22], 1.0, 0.08, 0.45);
    }
    b.finish()
}

fn palm() -> Mesh {
    let mut b = Builder::new();
    let trunk = [0.44, 0.34, 0.22];
    let pts: [(f64, f64, f64); 5] = [(0.0, 0.0, 0.0), (0.12, 0.0, 1.6), (0.30, 0.05, 3.2), (0.48, 0.05, 4.8), (0.55, 0.05, 6.0)];
    for i in 0..4usize {
        let a = pts[i];
        let c = pts[i + 1];
        let r0 = 0.19 - 0.025 * (i as f64);
        let r1 = 0.19 - 0.025 * ((i + 1) as f64);
        frustum(&mut b, V3::new(a.0, a.1, a.2), V3::new(c.0, c.1, c.2), r0, r1, 6, trunk, trunk, 0.1, 0.05 * (i as f32), 0.05 * ((i + 1) as f32));
    }
    let top = V3::new(0.55, 0.05, 6.0);
    for k in 0..9usize {
        let az = (k as f64) * (TAU / 9.0) + 0.2;
        frond(&mut b, top, az, 2.7, 0.60, 0.9, 1.9, 4, [0.16, 0.40, 0.12], [0.36, 0.64, 0.22], 1.0);
    }
    b.finish()
}

fn acacia() -> Mesh {
    let mut b = Builder::new();
    let bark = [0.36, 0.26, 0.17];
    frustum(&mut b, V3::new(0.0, 0.0, 0.0), V3::new(0.35, 0.0, 2.3), 0.17, 0.11, 6, bark, bark, 0.1, 0.0, 0.05);
    frustum(&mut b, V3::new(0.35, 0.0, 2.3), V3::new(1.35, 0.45, 3.3), 0.10, 0.06, 5, bark, bark, 0.1, 0.05, 0.10);
    frustum(&mut b, V3::new(0.35, 0.0, 2.3), V3::new(-0.70, -0.50, 3.2), 0.09, 0.05, 5, bark, bark, 0.1, 0.05, 0.10);
    blob(&mut b, V3::new(0.45, 0.0, 3.75), V3::new(3.0, 3.0, 0.55), 1, 21, 0.25, [0.20, 0.36, 0.10], [0.46, 0.60, 0.20], 1.0, 0.4);
    blob(&mut b, V3::new(1.60, 0.70, 3.50), V3::new(1.4, 1.4, 0.40), 0, 22, 0.25, [0.20, 0.36, 0.10], [0.44, 0.58, 0.19], 1.0, 0.4);
    b.finish()
}

fn cactus() -> Mesh {
    let mut b = Builder::new();
    let g0 = [0.16, 0.38, 0.17];
    let g1 = [0.26, 0.52, 0.26];
    frustum(&mut b, V3::new(0.0, 0.0, 0.0), V3::new(0.0, 0.0, 2.4), 0.28, 0.26, 8, g0, g1, 0.35, 0.0, 0.05);
    frustum(&mut b, V3::new(0.0, 0.0, 2.4), V3::new(0.0, 0.0, 2.85), 0.26, 0.0, 8, g1, g1, 0.35, 0.05, 0.10);
    frustum(&mut b, V3::new(0.2, 0.0, 1.2), V3::new(0.85, 0.0, 1.4), 0.12, 0.12, 6, g0, g1, 0.35, 0.0, 0.05);
    frustum(&mut b, V3::new(0.85, 0.0, 1.4), V3::new(0.9, 0.0, 2.1), 0.12, 0.11, 6, g0, g1, 0.35, 0.05, 0.10);
    frustum(&mut b, V3::new(0.9, 0.0, 2.1), V3::new(0.9, 0.0, 2.45), 0.11, 0.0, 6, g1, g1, 0.35, 0.10, 0.10);
    frustum(&mut b, V3::new(-0.2, 0.0, 0.9), V3::new(-0.7, 0.0, 1.05), 0.10, 0.10, 6, g0, g1, 0.35, 0.0, 0.05);
    frustum(&mut b, V3::new(-0.7, 0.0, 1.05), V3::new(-0.74, 0.0, 1.65), 0.10, 0.09, 6, g0, g1, 0.35, 0.05, 0.10);
    frustum(&mut b, V3::new(-0.74, 0.0, 1.65), V3::new(-0.74, 0.0, 1.95), 0.09, 0.0, 6, g1, g1, 0.35, 0.10, 0.10);
    b.finish()
}

fn dead_tree() -> Mesh {
    let mut b = Builder::new();
    let wood = [0.38, 0.32, 0.27];
    let grey = [0.30, 0.26, 0.22];
    frustum(&mut b, V3::new(0.0, 0.0, 0.0), V3::new(0.1, 0.0, 3.1), 0.20, 0.06, 6, wood, grey, 0.0, 0.0, 0.10);
    let branches: [(f64, f64); 5] = [(1.5, 0.3), (2.0, 2.4), (2.4, 4.2), (2.7, 5.5), (1.2, 3.4)];
    for br in branches.iter() {
        let z = br.0;
        let (s, c) = dsincos(br.1);
        let start = V3::new(0.03 * z, 0.0, z);
        let end = V3::new(start.x + c, start.y + s, z + 0.7);
        frustum(&mut b, start, end, 0.06, 0.02, 4, wood, grey, 0.0, 0.05, 0.25);
    }
    b.finish()
}

/// all meshes, indexed by the K_* constants
pub fn build_meshes() -> Vec<Mesh> {
    let mut v: Vec<Mesh> = Vec::with_capacity(K_COUNT);
    v.push(grass_tuft());
    v.push(tall_grass());
    v.push(flower());
    v.push(fern());
    v.push(bush());
    v.push(rock());
    v.push(broadleaf());
    v.push(conifer());
    v.push(palm());
    v.push(acacia());
    v.push(cactus());
    v.push(dead_tree());
    v
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn meshes_are_well_formed() {
        let m = build_meshes();
        assert_eq!(m.len(), K_COUNT);
        for mesh in m.iter() {
            assert!(!mesh.verts.is_empty());
            assert_eq!(mesh.verts.len() % VERT_FLOATS, 0);
            let n = mesh.verts.len() / VERT_FLOATS;
            assert!(n < 60000);
            assert_eq!(mesh.idx.len() % 3, 0);
            for &i in mesh.idx.iter() {
                assert!((i as usize) < n);
            }
            for &f in mesh.verts.iter() {
                assert!(f.is_finite());
            }
        }
    }

    #[test]
    fn icosphere_counts() {
        let (v0, f0) = icosphere(0);
        assert_eq!(v0.len(), 12);
        assert_eq!(f0.len(), 20);
        let (v1, f1) = icosphere(1);
        assert_eq!(v1.len(), 42);
        assert_eq!(f1.len(), 80);
    }
}
