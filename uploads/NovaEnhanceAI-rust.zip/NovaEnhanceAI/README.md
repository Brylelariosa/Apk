# NovaEnhance AI

An Android photo enhancer that runs entirely on the phone: a small residual CNN you can train on your own photos,
plus a full classical photo-enhancement toolkit, and a scene analysis ("Auto enhance") that decides what each photo needs.

**Build 12: the whole native core is now Rust** (`/rust`). The Kotlin/Compose app (screens, database, training
orchestration, gallery access) is unchanged apart from the new controls; everything that touches pixels - the CNN,
every filter, the upscaler, the analysis - is Rust, and it works on the bitmap's memory directly.

## What changed in build 12

1. **Rust instead of C++.** `/rust` is a dependency-free crate (`cdylib`) built per ABI by Gradle. The C++ sources and
   CMake are gone. Panics and bad arguments become Java exceptions instead of killing the app.
2. **Memory- and RAM-efficient pipeline.** One native *session* per photo: it reads the source bitmap's pixel memory,
   processes it in bounded bands and writes the destination bitmap's memory. No pixel crosses into the Java heap
   (the old path copied every band through several `IntArray`s), and native working memory is capped by a band
   budget instead of growing with the photo's resolution. Details below.
3. **Every mainstream enhancement technique**, each with its own slider, plus **Auto enhance**. Table below.
4. **In-place batch mode**: "Enhance all" decodes each photo mutable and enhances it in place, so the second
   photo-sized bitmap (up to ~96 MB for a 24 MP photo) is never allocated.
5. Training memory: activations for 4 samples at a time (~17 MB) instead of 8 (~34 MB); larger batches run in waves.

The network architecture and the checkpoint/parameter layout are unchanged: **every existing `.novamodel` loads exactly as before.**

## Memory model (how it stays small)

| Stage | What is held in memory |
|---|---|
| Decode | the source bitmap (4 bytes/pixel) - the unavoidable part. In batch mode it is also the output (in place). |
| Analysis (`open`) | a <= 320 px thumbnail (<= 1.2 MB), a 256-bin histogram, 64 CLAHE tile histograms (64 KB), a few counters per worker |
| Plan | tone curve (4 KB), CLAHE curves (64 KB), thumbnail-resolution maps for the local techniques (<= 0.4 MB each) |
| Band | float RGB for ONE band + its context rows: 12 bytes/pixel, capped at `NativeEnhancer.DEFAULT_MAX_BAND_PIXELS` (800 000 px = ~9.6 MB); each stage adds a few band-sized temporaries that are freed before the next stage |
| In-place carry | at most `contextRows` rows of the original (about 1 MB for a 4000 px wide photo) |
| Upscale | the band of output rows being resampled, ~20 bytes per output pixel of band + context rows |

So the native working set is tens of megabytes (roughly 35-60 MB with every technique switched on, far less with a
few) **for any photo size** - these are design estimates from the buffer sizes above, not measurements; check
`logcat` tag `BandProcessor` (it logs `MemoryStats` per band) on your phone. Large techniques never need a
full-size blurred copy of the photo: shadows/highlights, clarity, low-light and dehaze read *thumbnail-resolution maps*
sampled bilinearly, which also makes them independent of how the photo is split into bands.

## Techniques

All values 0..1 (0 = off) unless noted. **Auto enhance** switches on, for every slider left at 0, the amount the
analysis suggests; a slider you move always wins. The analysis result is logged (`EnhancementEngine`, "analysis: ...").

| Technique | Slider | How it works | Auto turns it on when |
|---|---|---|---|
| Learned restoration (CNN) | *Strength* | the 44K-parameter residual CNN, blended with the original | (always as set) |
| Compression-artifact removal | *Noise reduction* | joint bilateral in YCbCr, 17 taps/axis (blotches, ringing, mosquito noise) | (as set) |
| Hot-pixel / speckle removal | Hot pixels | isolated 8-neighbour outliers replaced by the neighbours' median | many isolated outliers |
| Denoise | Denoise | non-local means on luma (3x3 patches, 5x5 or 7x7 search, weight table) + guided-filter chroma smoothing | estimated noise > 1.5 levels |
| Remove banding | Deband | separable threshold-limited mean (only averages neighbours within 1-3 levels) | gaps in the luma histogram |
| Deblur | Deblur | Richardson-Lucy deconvolution (Gaussian PSF, damped, de-ringed) | low gradient 95th percentile |
| White balance | White balance | grey-world gains from the thumbnail (ignoring near-black/white), limited to 0.7-1.43x | colour cast > ~10% |
| Auto levels | Auto levels | 0.4% / 99.6% percentile stretch | tonal range < 85% |
| Exposure | Exposure (-1..1) | gamma on the tone curve | mean luma far from 0.45 |
| Contrast | Contrast (-1..1) | symmetric monotone S-curve `x - k*sin(2*pi*x)/(2*pi)` | low luma std-dev |
| Shadows / Highlights | Shadows, Highlights | gain driven by an edge-aware (guided-filter) blurred-luminance map | many dark / bright pixels |
| Local contrast | Local contrast (CLAHE) | 8x8 tile histograms with clip limit, bilinear interpolation between tile curves | flat tonal distribution |
| Low-light | Low-light boost | Retinex-style `gain = illumination^(gamma-1)` with a highlight knee | mean luma < 0.30 |
| Dehaze | Dehaze | dark-channel prior: atmospheric light + guided-filter-refined transmission at thumbnail resolution | high mean dark channel |
| Clarity | Clarity | large-radius local contrast against the blurred-luminance map, mid-tones only | light touch by default |
| Fine detail | Fine detail | guided-filter base/detail split, noise-aware soft threshold, gain | low noise |
| Vibrance / Saturation | Vibrance, *Color restoration* | muted colours boosted more than vivid ones / plain saturation | low mean saturation |
| Vignette | Vignette fix (-1..1) | radial gain | manual |
| Sharpening | *Sharpness* | halo-free edge push + gated, range-clamped unsharp mask (luma only) | (as set) |
| Upscaling | *Upscale* 1x/2x/4x | Lanczos-3 with anti-ringing clamp, then the sharpening at the final resolution | (as set) |

*Italic* sliders are the original ones. Order inside a band: CNN -> hot pixels -> artifact removal -> denoise -> deband ->
deblur -> (vignette, white balance, clarity, dehaze, low-light, shadows/highlights, CLAHE, tone curve, vibrance/saturation)
-> fine detail -> sharpen -> write. Tone curves are folded into one lookup table; the per-pixel stages are one fused pass.

Not included (they need face/lens/sensor data this app does not have): red-eye or skin retouching, lens-distortion /
chromatic-aberration profiles, RAW demosaicing, multi-frame HDR/panorama, learned super-resolution.

Every neighbourhood technique reports its reach in rows; a band carries that many real context rows, so results are
identical for any band split (no seams). This is covered by `enhance::session::tests::banded_processing_matches_whole_image_processing`.

## Building

**Requirements**: JDK 17, Android SDK + NDK 25.2.9519653 (as before), **a Rust toolchain** (`cargo`). GitHub's
`ubuntu-latest` runners already have Rust; `rust/build-android.sh` adds the Android targets with `rustup`
(`aarch64-linux-android`, `thumbv7neon-linux-androideabi`) and prints a clear message if `cargo` is missing.

```
./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
```

Gradle runs `rust/build-android.sh` once per ABI (always `cargo build --release`, also for debug APKs: unoptimised
image/CNN code would be ~20x slower), then packages `libnovaenhance_native.so` from `app/build/rustJniLibs`.
The crate has no dependencies, so nothing is downloaded except the Rust target's standard library.
Expect a few minutes for the first native build (fat LTO).

### Tests

```
cd rust && cargo test --release          # on a PC: kernels vs naive reference, gradient/threading, band-seam and
                                         # in-place equivalence, every filter and technique
python3 tools/jni_crosscheck.py          # every Kotlin `external fun` vs its Rust `Java_...` export (names, arity, types)
./gradlew testDebugUnitTest              # Kotlin unit tests
```

## Verification status - please read

**This build was written without access to a Rust compiler.** What *was* checked, mechanically: bracket balance
and string/comment scanning of all Rust sources, function-call arity across the crate, that every `crate::` path
and import resolves to a public item, and that all 19 Kotlin `external fun` declarations match the Rust JNI exports
name for name, parameter for parameter, type for type (`tools/jni_crosscheck.py`). The algorithms were designed
against the old, tested C++ implementation (same layouts, constants and tables) and each ships with unit tests -
but none of it has been *compiled or run yet*. Expect that the first `cargo` build may report a type or borrow error
or two: they will name the file and line (the Gradle log shows cargo's output), and each is typically a one-line fix.
The numbers in this README that are estimates say so.

## Architecture

```
app/                              Kotlin / Jetpack Compose app (unchanged structure)
  ai/engine/NativeEnhancer.kt       JNI: open(analyse+plan) / processBand / close   -> rust/src/enhance
  ai/engine/BandProcessor.kt        the band loop: cancellation, thermal pacing, progress
  ai/engine/EnhancementEngine.kt    one entry point for UI + validator; sharpen-spec mapping; upscale path
  ai/engine/EnhancementOptions.kt   the sliders (original + 18 new techniques + Auto)
  ai/engine/NativeNeuralEngine.kt   JNI: init / infer / train step                  -> rust/src/nn
  ai/engine/NativeImageProcessor.kt JNI: int[] filters, upscaleBand                 -> rust/src/filters
  ui/components/AdvancedEnhancementControls.kt  Auto switch + collapsible technique sliders
rust/
  Cargo.toml, build-android.sh      no dependencies; one cargo build per ABI
  src/bridge.rs                     all JNI exports (panic-safe), session registry
  src/jni.rs, src/sys.rs            hand-written JNI table access; logcat + bitmap locking (jnigraphics)
  src/par.rs                        scoped-thread pool: dynamic scheduling, disjoint &mut row chunks, no unsafe
  src/nn/                           kernels (register-blocked 3x3 conv), packed weights, streaming inference, training, Adam, L2-SP
  src/img/                          Gaussian / box / guided filters, colour helpers
  src/filters/                      restore (joint bilateral), sharpen (edge push + unsharp), lanczos, ARGB int[] filters
  src/enhance/                      options, analysis, plan (auto), tone (fused pass), denoise, deblur, session (bands, in-place)
tools/jni_crosscheck.py             static JNI consistency check
```

## The network

Unchanged: `input -> Conv3x3(3->48)+ReLU -> Conv3x3(48->48)+ReLU -> Conv3x3(48->48)+ReLU -> Conv3x3(48->3)`, global
residual `clip(input + out, 0, 1)`, 44 211 parameters, L1 loss, Adam, L2-SP against a base checkpoint, gradient-norm
clip 1.0. Inference streams rows through all four layers (3-row ring buffers, ~150 KB per worker) in column strips with a
4 px halo, so any image size works with no tile seams. 32-bit ARM uses the NEON-enabled `thumbv7neon` target.

## Upscaling and sharpening

Unchanged in behaviour: the learned model is a fixed-size restoration model, not super-resolution, so 2x/4x is Lanczos-3
(ringing clamped to the surrounding 2x2 source pixels) with the sharpening applied once at the final resolution. The
Lanczos band no longer stores per-row min/max planes (the anti-ringing range is read straight from the 4 source pixels),
which removes two of the three horizontal-pass float buffers.

## Honest limitations

- The CNN is small and close to an identity until trained; most visible change comes from the classical techniques.
- Auto enhance is a set of conservative heuristics, not a learned judge: it can be wrong on unusual pictures (a deliberately
  blue-toned scene, a night shot you want dark). Move a slider or use "Reset advanced techniques" to override it.
- The dehaze, low-light and shadows/highlights maps are thumbnail-resolution and edge-aware, but extreme local contrast can
  still show faint halos; lower the slider.
- Deblur (Richardson-Lucy) assumes a Gaussian-like blur; strong motion blur is only partly undone.
- Non-local-means denoise with every other technique enabled is the most expensive stage; the thermal governor still paces bands.
- Nothing here has been timed on the Infinix HOT 11 (2022): speed claims from earlier builds applied to the C++ kernels and
  are not repeated.
