import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

// Optional local signing override for developers building outside CI:
// app/keystore.properties (git-ignored) with storeFile/storePassword/keyAlias/keyPassword.
val keystoreProps = Properties().apply {
    val f = rootProject.file("app/keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.novaenhance.ai"
    compileSdk = 34
    ndkVersion = "25.2.9519653"

    defaultConfig {
        applicationId = "com.novaenhance.ai"
        minSdk = 29 // Android 10+, per offline/on-device requirement
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Only build for real device ABIs actually in use on modern phones -
        // skip x86/x86_64 emulator ABIs to keep the release APK small.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }

        // Room schema export location, used for migration testing.
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
            arg("room.incremental", "true")
        }
    }

    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("RELEASE_STORE_FILE")
                ?: keystoreProps.getProperty("storeFile")
            if (storeFilePath != null && file(storeFilePath).exists()) {
                storeFile = file(storeFilePath)
                storePassword = System.getenv("RELEASE_STORE_PASSWORD")
                    ?: keystoreProps.getProperty("storePassword")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS")
                    ?: keystoreProps.getProperty("keyAlias")
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD")
                    ?: keystoreProps.getProperty("keyPassword")
            }
            // If nothing is configured, this signing config simply has no
            // store attached below and release falls back to the debug key
            // (see buildTypes.release) so `assembleRelease` still succeeds
            // out of the box on a brand-new checkout with zero setup.
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (signingConfigs.getByName("release").storeFile != null) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=kotlin.RequiresOptIn",
            // TopAppBar (used in every screen) and a few other Material3
            // components are still marked @ExperimentalMaterial3Api in this
            // Compose BOM version. Opting in globally here is simpler and
            // more honest than sprinkling @OptIn on 6+ near-identical
            // composables - the experimental-ness is a property of the
            // library version, not something that varies per screen.
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api"
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        // Compatible with Kotlin 1.9.24 per the JetBrains Compose-Kotlin
        // compatibility map.
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
        jniLibs {
            useLegacyPackaging = false
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    // No Robolectric in this project - JVM unit tests are meant to stay fast/
    // lightweight and stick to plain Kotlin logic. A few of them (checkpoint
    // save/recovery in particular - see AtomicCheckpointFileTest/
    // NovaModelEngineCheckpointTest) incidentally exercise NovaLog, which
    // calls straight through to android.util.Log. Without this, the *first*
    // such call throws ("Method i in android.util.Log not mocked") and fails
    // the test for a harness reason having nothing to do with the checkpoint
    // logic actually under test - this makes those (and Log/other simple
    // android.* stub calls in any future test) return a default value
    // instead, exactly as the Android Gradle Plugin intends this flag for.
    testOptions {
        unitTests {
            isReturnDefaultValues = true
        }
    }
}

// ------------------------------------------------------------------------------------------------------------
// Rust native core (/rust): one `cargo build` per ABI, driven by rust/build-android.sh, packaged as jniLibs.
//
//  * No CMake / C++ anymore. The crate has NO dependencies, so the only thing the build needs is a Rust toolchain
//    (GitHub's ubuntu runners ship one; the script adds the Android target with rustup) and the NDK linker.
//  * Always built in cargo's `release` profile, also for debug APKs: an unoptimised build of the image/CNN code
//    would be ~20x slower and unusable on a phone.
//  * armeabi-v7a uses the thumbv7neon target so the CNN kernels get NEON on 32-bit ARM.
// ------------------------------------------------------------------------------------------------------------
val rustJniLibsDir = layout.buildDirectory.dir("rustJniLibs").get().asFile
val rustTargetDir = layout.buildDirectory.dir("rustTarget").get().asFile

// ABI to (rust target triple, NDK clang prefix)
val rustTargets = listOf(
    Triple("arm64-v8a", "aarch64-linux-android", "aarch64-linux-android"),
    Triple("armeabi-v7a", "thumbv7neon-linux-androideabi", "armv7a-linux-androideabi")
)

// Finds the NDK without relying on AGP APIs that changed between versions: the pinned side-by-side NDK in the SDK
// first, then ANDROID_NDK_HOME / ANDROID_NDK_ROOT, then any other side-by-side NDK that is installed.
fun resolveNdkDir(): String {
    val pinned = "25.2.9519653"
    val sdkRoots = mutableListOf<String>()
    System.getenv("ANDROID_HOME")?.let { sdkRoots.add(it) }
    System.getenv("ANDROID_SDK_ROOT")?.let { sdkRoots.add(it) }
    val localProps = rootProject.file("local.properties")
    if (localProps.exists()) {
        val props = Properties()
        localProps.inputStream().use { props.load(it) }
        props.getProperty("sdk.dir")?.let { sdkRoots.add(it) }
    }
    for (sdk in sdkRoots) {
        val dir = file("$sdk/ndk/$pinned")
        if (dir.exists()) return dir.absolutePath
    }
    for (envName in listOf("ANDROID_NDK_HOME", "ANDROID_NDK_ROOT")) {
        val value = System.getenv(envName)
        if (value != null && file(value).exists()) return value
    }
    for (sdk in sdkRoots) {
        val any = file("$sdk/ndk").listFiles()?.filter { it.isDirectory }?.maxByOrNull { it.name }
        if (any != null) return any.absolutePath
    }
    throw GradleException("Android NDK not found. Install NDK $pinned (sdkmanager \"ndk;$pinned\").")
}

val rustBuildTasks = rustTargets.map { target ->
    val abi = target.first
    val triple = target.second
    val clangPrefix = target.third
    tasks.register<Exec>("buildRust" + abi.replace("-", "_")) {
        group = "rust"
        description = "Builds the Rust core for $abi"
        val crateDir = rootProject.file("rust")
        workingDir = crateDir
        inputs.dir(crateDir.resolve("src"))
        inputs.file(crateDir.resolve("Cargo.toml"))
        inputs.file(crateDir.resolve("build-android.sh"))
        outputs.file(rustJniLibsDir.resolve("$abi/libnovaenhance_native.so"))
        environment("CARGO_TARGET_DIR", rustTargetDir.absolutePath)
        commandLine(
            "bash",
            crateDir.resolve("build-android.sh").absolutePath,
            abi,
            triple,
            clangPrefix,
            resolveNdkDir(),
            rustJniLibsDir.absolutePath,
            "29"
        )
    }
}

android.sourceSets.getByName("main").jniLibs.srcDir(rustJniLibsDir)

tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("JniLibFolders")) {
        dependsOn(rustBuildTasks)
    }
}
tasks.named("preBuild") {
    dependsOn(rustBuildTasks)
}


dependencies {
    // --- Core / Compose ---
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // --- Coroutines ---
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- Room (dataset / training history / model registry) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // --- WorkManager (background training) ---
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // --- DataStore (settings) ---
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // NOTE: no TensorFlow/TFLite dependency - the AI engine is a from-scratch CNN written in Rust (see
    // /rust/src/nn/), not a bundled TensorFlow model. TFLite's on-device training needs a .tflite file authored
    // once via a separate Python/TensorFlow step, which not every build pipeline can run. The from-scratch
    // engine needs nothing but this Kotlin code and the Rust crate in /rust.

    // --- Desugaring (java.time etc. on minSdk 29, kept for forward compat) ---
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // --- Tests ---
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    // Android's unit-test stub android.jar does NOT implement org.json's
    // actual parsing behavior (methods throw unless stubbed) - this pulls in
    // the real reference implementation so ModelMetadataTest exercises real
    // JSON parsing rather than Android's "not mocked" stub.
    testImplementation("org.json:json:20231013")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
