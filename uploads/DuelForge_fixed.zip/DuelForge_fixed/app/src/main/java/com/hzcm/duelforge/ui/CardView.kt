package com.hzcm.duelforge.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.model.*

/** Default card dimensions used throughout the field/hand. */
val CardWidth = 44.dp
val CardHeight = 60.dp

/**
 * Renders one card.
 *  - [instance] null -> an empty zone outline.
 *  - [instance] face-down (and [revealFaceDown] false) -> a card back.
 *  - Otherwise -> the card's artwork (if present in assets/cards/) or a generated
 *    placeholder colored by card type, with name + ATK/DEF/Level.
 *
 * [revealFaceDown] lets the human player see their OWN set cards face-up even though
 * [CardInstance.faceUp] is false (the opponent's set cards stay hidden).
 */
@Composable
fun CardView(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val base = modifier
        .size(CardWidth, CardHeight)
        .clip(RoundedCornerShape(6.dp))
        .border(
            width = if (selected) 3.dp else 1.dp,
            color = if (selected) Color(0xFFFFD54F) else Color(0xFF555555),
            shape = RoundedCornerShape(6.dp)
        )
        .let { m -> if (onClick != null) m.clickable { onClick() } else m }

    if (instance == null) {
        Box(
            modifier = base.background(Color(0xFF1A1A1A)),
            contentAlignment = Alignment.Center
        ) {}
        return
    }

    val showFace = instance.faceUp || revealFaceDown
    if (!showFace) {
        CardBack(modifier = base)
        return
    }

    val context = LocalContext.current
    val bitmap = remember(instance.card.imageId) { ImageLoader.loadCardImage(context, instance.card.imageId) }

    Box(modifier = base.background(cardTypeColor(instance.card))) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = instance.card.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Stat overlay for monsters even when art is present.
            if (instance.card.isMonster) {
                StatOverlay(instance)
            }
        } else {
            PlaceholderCardContent(instance)
        }

        if (!instance.faceUp) {
            // Human's own face-down card, revealed via revealFaceDown - tint it to remind
            // the player it's actually hidden from the opponent.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x66000000))
            )
        }
    }
}

@Composable
private fun CardBack(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(Color(0xFF2B2D6E)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(CardWidth - 16.dp, CardHeight - 16.dp)
                .border(1.dp, Color(0xFF6E72C7), RoundedCornerShape(4.dp))
        )
    }
}

@Composable
private fun PlaceholderCardContent(instance: CardInstance) {
    val card = instance.card
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(3.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = card.name,
            color = Color.Black,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )

        if (card.isMonster) {
            Column {
                Text(
                    text = "${card.attribute?.name ?: ""} ${card.race?.name?.replace('_', ' ') ?: ""}".trim(),
                    color = Color(0xFF222222),
                    fontSize = 6.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Lv${card.level ?: 0}  ATK ${card.atk ?: 0}/DEF ${card.def ?: 0}",
                    color = Color.Black,
                    fontSize = 6.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        } else {
            Text(
                text = if (card.isSpell) "SPELL" else "TRAP",
                color = Color.Black,
                fontSize = 6.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/** Small ATK/DEF/position readout drawn over real artwork. */
@Composable
private fun StatOverlay(instance: CardInstance) {
    Box(modifier = Modifier.fillMaxSize()) {
        val posLabel = if (instance.battlePosition == BattlePosition.ATTACK) "ATK" else "DEF"
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xAA000000))
        ) {
            Text(
                text = "${instance.effectiveAtk}/${instance.effectiveDef} $posLabel",
                color = Color.White,
                fontSize = 7.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
            )
        }
    }
}

/** Background color used for the generated placeholder, by card type / monster category. */
private fun cardTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP -> Color(0xFFE07FA8)
}
