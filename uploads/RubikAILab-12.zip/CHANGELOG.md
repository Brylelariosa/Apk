# Changelog

## 2.8 - 2026-10-24
- Skewb: a swipe, tap or hold on a corner piece now turns JUST THAT CORNER PIECE (the owner asked for exactly this: "turn only that one corner piece"). What the owner saw before was correct Skewb behaviour: a real corner twist turns half the puzzle (4 corners + 3 centres), so "the whole thing" turned. A single corner turning alone is not a move a real Skewb can make, so it is a free extra:
  - Native core (cpp/core/puzzle.cpp, puzzle.h): the Skewb now has 32 moves. Moves 0..15 are the real half-puzzle twists (unchanged, solver moves 0..7 unchanged); moves 16..31 are the same eight corners both ways with a layer that is only the slab beyond 1.45 on the corner's axis, which holds exactly that corner's three stickers and its one solid piece (every other sticker projects to 0.87 or less, the corner's own to 2.02; the corner's solid piece has class point 1.60). Names are lower case (urf, urf', ...). New Puzzle::playMoves = how many moves are real (16 for the Skewb, = moves for every other puzzle). The solid pieces are still cut only by the real moves' planes (solid::cutPlanes), so there are still 14 of them; the free corner twist turns a whole corner solid, which is symmetric about that axis, so it looks right. The solver, trainer and checkpoints only use aiMoves, the piece structure is unchanged (14 slots, 4 classes, 111 features), so trained Skewb checkpoints stay valid.
  - Kotlin: PuzzleModel.realMoves (16 for the Skewb, Puzzles.SKEWB_REAL_MOVES, must match Puzzle::playMoves) is what scrambling, the pad and the picker use, so a scramble never makes an unreachable state. Picker.cornerOnly: a swipe on a corner piece returns the free move of the same corner and direction (real move + 16); Picker.tapMove does the same for a tap (clockwise) and a hold (counter-clockwise). Swipes on the middle diamond of a face still twist half the puzzle. PuzzleView.skewbCornerOnly passes the setting to the picker.
  - Setting: Play settings > Skewb corners > "Corners turn on their own" (Lab.skewbCornerOnly, on by default). Off gives the real half twist from a corner swipe, as in v2.5.
  - The AI cannot solve a state that came from a single-corner turn (it is not reachable by real moves). PlayPage.freeTwist remembers that; AI solve then says so and asks for Reset or Scramble; Reset, Scramble and loading clear it. Hint text changes with the setting.
  - Checked on the host: all native tests pass, including a new one (each free move is a 3-cycle inside one corner piece, cubed is the identity, eight corners covered, none is a solver move) and the unchanged solver and canonicalisation tests; tests/preview/skewb_sweep.py runs both settings over 336 views: every corner drag turns the touched corner alone (setting on) or twists half (off), none dead, no middle-piece swipe ever picks a free move; preview renders of the free twist look right (the corner spins in place and its three colours cycle). NOT checked on a phone, Kotlin not compiled.
- Turn sound: the owner said it "doesn't sound like a real cube" and has no cube to record. Real recordings exist and are free (SpaceJoe's CC0 "Rubik Cube Turn - 10" on Freesound, SpaceJoe's "Rubik Cube Small Noises" on Pixabay under the Pixabay licence, nicola_ariutti's packs on Freesound) but the sandbox cannot download audio and both sites block scripted requests, so the samples are still synthesised, now rebuilt from how a real cube sounds (tests/sound/make_sounds.py): the click is two or three tiny knocks a few ms apart, each noise that starts bright and darkens within about 10 ms (a one-pole low-pass whose cutoff glides from 9.5 kHz to 1.5 kHz), coloured by two low-Q plastic-shell formants (about 1150 and 2350 Hz) over a short soft thock; nothing rings. The slide is no longer a steady hiss but a crackle of random tiny contacts in three bands over a faint rumble, so no two grains are alike. Still nobody has listened to them. If the owner wants the real thing: download one of the free clips above and send it; ffmpeg is available here to cut it into turn_click_1..3.wav and turn_slide_1..3.wav (mono 16-bit WAV, click about 70 ms, slide about 220 ms) in app/src/main/res/raw, and nothing else changes.
- Kotlin only, not compiled here; bracket-checked and reviewed by hand.

## 2.7 - 2026-10-24
- Turn sound: the owner heard "a weird sound at the end" of a turn. That was the click: v2.6 built it from ringing tonal resonances plus a doubled strike and pitched it +-8%, which reads as a "boing" rather than plastic. It is now a dry click with no tones (tests/sound/make_sounds.py: three tiny band-limited noise knocks a few ms apart over a soft low-mid thock, 60 ms long), played with at most +-3% pitch change and slightly quieter; the slide now ends before the click instead of overlapping it. Real cube recordings do exist online (e.g. Duke's Sonic Dictionary \"Rubiks Cube\", the paid \"Micro Movements: Puzzle Cubes\" pack) but none has a licence that can be bundled and the sandbox cannot download audio, so the samples stay synthesised. To use real ones, replace the six files in app/src/main/res/raw (turn_click_1..3.wav, turn_slide_1..3.wav, short mono 16-bit WAV, click about 60 ms, slide about 220 ms) - nothing else changes.
- Skewb corners: the v2.6 changes (near-miss pick, tap, hold) did not help on the owner's phone, so the cause is not in the swipe maths or the picking tolerance (all of it passes on the host in every view). Nothing more can be found by reading the code, so v2.7 adds a diagnostic: Play settings > Troubleshooting > Show touch info (Lab.touchInfo, off by default). While it is on, the status line at the top shows for each touch: where it landed and the view size / free area / view angles, whether the picker HIT a piece (which, how many sides, which face, where it is drawn) or MISSED (the nearest piece and how many pixels away it is drawn - a large number means the drawn puzzle and the picker disagree), what the swipe / tap / hold chose, and whether the turn was applied or IGNORED (busy / solving). Code: Picker.describeTouch, PuzzleView.touchInfo / reportTouch, PlayPage.applyTouchInfo and the checks in onUserMove. Ask the owner for a screenshot taken right after touching a corner piece with it on.
- Kotlin only, not compiled here; bracket-checked and reviewed by hand.

## 2.6 - 2026-10-24
- Skewb corners, third attempt. The owner still could not turn the four corner pieces of a face seen straight on (the view the face strip swings to). The swipe rule itself is not what fails: the host check passes in every view, including looking straight at the top or bottom face (pitch 90), which the v2.5 sweep did not include. So the touch handling was made forgiving, Skewb only (gl/Picker.kt, gl/PuzzleView.kt):
  - A touch that lands just outside a corner piece, within 16 dp of its outline, counts as touching it (Picker.pickNear). The sharp tip of a corner piece is the very edge of the picture and a fingertip rarely lands exactly on it; before, such a touch started an orbit of the view, so nothing turned.
  - A tap on a corner piece twists it clockwise seen from the corner, a press-and-hold (450 ms) twists it the other way (Picker.tapMove, PuzzleView ACTION_UP), so a corner turns with no drag direction at all. A touch that only stops the swing to a face is not a tap.
  - The turn pad lists all sixteen corner twists (clockwise and counter-clockwise for each of the eight corners). v2.5 had eight, so for example the ULB corner of the top face had no button. The status hint now says "Swipe or tap a corner to twist it (hold for the other way)".
  - Checked on the host (tests/preview/skewb_sweep.py): 336 views including pitch +-90, all 119,808 corner drags twist the touched corner, none dead; every corner piece seen straight on gives the right move for a tap and a hold; 1,040 touches just outside a corner tip pick that corner, and touches beyond the reach do not. NOT checked on a phone: the real cause on the device is still unconfirmed. If a corner still does not turn, log in PuzzleView.onTouchEvent what pick() returns on ACTION_DOWN and whether onUserMove is reached; the problem is then in touch delivery or busy/solving state, not in the swipe maths.
- Turn sounds: a soft plastic slide while a layer turns and a dry click when it seats, like a real cube. gl/TurnSound.kt plays them through a SoundPool; the renderer calls it when a move starts and when it ends (PuzzleRenderer.sound, Frame.started / duration), so the player's turns, scrambles and the AI's solution all make sound, while the Train tab's live view stays silent. The six short samples in res/raw (turn_slide_1..3, turn_click_1..3) are synthesised by tests/sound/make_sounds.py (numpy only, no recordings): an impact burst, damped plastic-shell resonances and a rebound for the click, ratcheting shaped noise for the slide. Every play varies the pitch a little; turns shorter than 90 ms (scrambles) only click, quieter, and clicks are at least 18 ms apart. The slide is stretched to the length of the turn. Play settings has Sound > Turn sounds (Lab.turnSounds, on by default); the sound pool exists only while the Play page is shown. The samples were checked as waveform and spectrogram figures only, nobody has listened to them: judge by ear and retune make_sounds.py (decay times, levels) if they are too hissy or too clicky.
- Kotlin only, not compiled here (no Kotlin compiler in the authoring sandbox); bracket-checked and reviewed by hand, touch and swipe maths checked on the host.

## 2.5 - 2026-10-23
- Skewb: a swipe on a corner piece (a triangle) now ALWAYS twists that corner, in whichever direction the drag points at it; the drag only decides clockwise or counter-clockwise (the way the touched sticker travels on screen). v2.4 still handed drags that were more than about 78 degrees off that path to a neighbouring corner, which the owner read as "I can't turn the edge". A swipe on a centre piece (the big diamond) now turns the best-matching corner however oblique the view, so the Skewb has no dead swipes (before: about 1 centre drag in 100 was dead). Checked on the host with the new tests/preview/skewb_sweep.py: 288 camera views x 36 drag directions per visible sticker; all 112,896 corner drags twist the touched corner and none of the 141,120 corner and centre drags is dead.
- Skewb turn pad: the "Turn pad" switch now also exists for the Skewb, with the eight corner twists the solver uses (URF, URB, DRF, ULF and their inverses), as a guaranteed way to turn any corner. PuzzleModel.padMoves; the pad shows four buttons per row when the move count is not a multiple of six.
- Play screen redesign (ui/PlayPage.kt): the top bar is gone. The puzzle picker, timer with the move counter and the settings button moved to one control panel at the bottom, above Scramble / Reset / AI solve. The "Rotate view" chip and the "Turn pad" button became two small icon switches in the same row (new icon ic_orbit); the hint row is merged into the status line, which now carries a short how-to for the loaded puzzle (Puzzles.hint). The scramble / solution strip floats under the status line at the top, so scrambling no longer resizes the puzzle. The face strip moved from the bottom to the top, so the puzzle sits between the two. A drag that starts on the panel no longer spins the view.
- Ui.kt: roundedTop (panel background) and toggleBackground (icon switch) helpers.
- Kotlin only, not compiled here (no Kotlin compiler in the authoring sandbox); bracket-checked and reviewed by hand, swipe maths checked on the host.

## 2.4 - 2026-10-23
- Skewb: a swipe on a corner piece (a triangle sticker) now twists that corner, the turn about the axis through it, for any drag that roughly follows the way the sticker travels (12 to 14 of 16 drag directions; before, 0 to 8, so the corner often seemed stuck because a neighbouring corner's turn won). Diamond (centre) stickers choose as before. Host check: tests/preview/picker_check.py mirrors the rule.
- Layout: the puzzle view now fills the whole Play page, under the top bar and the buttons, which float over it. The camera (gl/Camera.kt) sizes the puzzle to the free space between them and centres it there, and fits it tighter (97% of the free width instead of about 81%): the Skewb's resting view is about 79% of the screen width instead of 65%.
- Top band: the camera-hole inset is no longer applied to the whole screen. It goes to the pages (PageView.setTopInset); a small centred hole reserves almost nothing, a wide notch or a hole near a control reserves its full height.
- Kotlin only, not compiled here; bracket-checked, camera and swipe maths checked on the host (tests/preview).

## 2.3 - 2026-10-23
- View: no pitch limit any more, the puzzle can be turned over the top and under the bottom; the sideways drag is mirrored while it is upside down so it follows the finger.
- New face strip (gl/FacePreview.kt) over the puzzle: one small picture per face with its current colours; tap one and the view swings to look straight at that face.
- Play settings (the sliders icon) has a View > Face previews switch that hides or shows the strip; it applies at once and is remembered.
- Fullscreen: status and navigation bars hidden (swipe from the edge to show them briefly) and the window runs under a camera hole or notch (layoutInDisplayCutoutMode shortEdges); controls are padded clear of the cutout.
- Kotlin only, not compiled here (no Kotlin compiler in the authoring sandbox); bracket-checked, and the look-at-face and upside-down drag maths were checked numerically.

## v2.2 (2026-10-22)
Cube and Pyraminx look and handling, from the owner's report: thick block lines, a wrong-looking Pyraminx, black
lines / pieces that did not turn with their layer, and the view spinning freely.
- Pieces: the dark bodies are now real pieces. Each puzzle is cut by the planes its moves turn about (`solid::`
  in core/puzzle.cpp: convex cells by half-space clipping) giving 8 / 27 / 64 / 125 cubies, 15 Pyraminx pieces
  (4 tips, 4 axial, 6 edges, hidden core) and 14 Skewb pieces. Every piece lies entirely inside or outside every
  turning layer, so it turns with a layer or stays, never half of each. This replaces the per-sticker tapered
  "frustum" bodies and the static core, which slid through each other when a Pyraminx layer turned.
- Look: stickers are inset by a fixed margin (`stickerInset`, so every dark line is equally thin on cubes,
  triangles and diamonds) with rounded corners (`stickerRound`, gl/StickerShape.kt) instead of 14% shrink with
  chamfered corners; piece edges are chamfered; the body colour is lighter than the background so the puzzle reads as
  a solid object and its black plastic is visible while layers turn.
- Pyraminx: now a solid tetrahedron of real pieces, starts in an edge-on view where two faces read clearly
  (`Puzzles.viewYaw/viewPitch`; cubes keep -35 / 28). Swiping a tip sticker now turns the tip on its own
  (u / l / r / b): of equally good layers the smallest wins. Before, tips could only turn together with the layer
  below, so tip scrambles could not be undone by hand.
- Gestures: a drag that starts on the puzzle (including its dark lines) never rotates the view any more; it turns a
  layer (within about 80 degrees of the layer's direction) or does nothing. Drag on the empty background, or use
  "Rotate view", to look around. A new puzzle starts in its own default view.
- JNI: `nativePuzzleStyle` now returns [radius, inset, lift, round] (was radius, scale, lift). `PuzzleModel.stickerScale`
  became `stickerInset` and `stickerRound` was added.
- Tests: host tests check the piece counts, that no piece corner lies across a layer boundary (rigid pieces), that
  piece faces point outward and that every sticker sits on a piece that is in exactly its layers.
  `tests/preview/` renders the puzzles on the host (camera, shading and mesh rules mirror the Kotlin renderer) and
  re-checks the swipe logic; see BUILD.md.

## v2.1 (2026-10-21)
- Build fix: CI run 1868 (release build) stopped in compileReleaseKotlin with
  `PlayPage.kt:66:17 Variable 'timerView' must be initialized`. The timer Runnable (`ticker`) was declared
  above the `init` block that assigns `timerView`; it now sits below that block. No behaviour change.
- That run had already built the native library for all four ABIs (x86, x86_64, arm64-v8a, armeabi-v7a)
  without errors, so only the Kotlin step was left to fix. The rebuild has not been run yet.

## v2
- Six puzzles: 2x2, 3x3, 4x4, 5x5, Pyraminx, Skewb, all built from one generic geometry-driven model.
  The 3x3 now also has middle-layer turns.
- AI for 2x2, 3x3, Pyraminx and Skewb with one network and checkpoint per puzzle.
- Training: pool-based value iteration (each expensive target is reused for several gradient steps),
  newest-depth sampling, deeper default curriculum for the 3x3 (16), progress reporting per round.
- Heat: Cool / Balanced / Fast presets, thermal governor with duty cycling, background priority, thread caps.
- Train tab: live view of the AI practising on fresh scrambles, round progress, chart, temperature and effort.
- Play tab: swipe to turn layers, drag to look around, timer with personal bests, turn pad, AI solve.
- Test tab: held-out or fresh scrambles, learned AI or conventional baseline, saved results.
- Layout: every main control fits on one screen without scrolling; vector icons; bottom navigation.
- Checkpoints are now per puzzle (checkpoint_<id>.bin, format version 3). The v1 checkpoint is not read.

## Rust core + learned method solvers (v9 -> v10)
- Native core rewritten in Rust (`rust`), same JNI surface and library name, so every Kotlin screen,
  the renderer and the saved checkpoints are unchanged. Geometry, move tables and piece meshes are ported 1:1.
- The C++ core stays in `app/src/main/cpp` as a safety net: `useRust=false` in gradle.properties builds it instead.
- New `method.rs`: learned-method solvers. 3x3 = cross, four first-two-layer pairs (tables learned by BFS over tracked
  stickers, IDA*), then last layer by algorithms the program discovers itself and a Dijkstra over all 62208
  last-layer states. 2x2 / Skewb / Pyraminx = exact meet-in-the-middle tables. The network stays as fallback and is
  still trained from the Train tab.
- NOT YET COMPILED: the Rust code was written without a Rust toolchain. The algorithms were first verified in C++
  (3x3: 300/300 random cubes, avg 54.6 quarter turns, max 269 ms; 2x2/Skewb 200/200; Pyraminx 200/200).
