package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * The black stickman hero.
 *
 * Movement: run, variable-height jump (asymmetric gravity, apex hang, coyote time, jump buffer, ceiling-corner and
 * ledge assists), double jump with a somersault, ground dash and (after Wraith Stride) air dash.
 * Combat: a 3-hit ground combo, a 3-hit aerial combo that ends in a plunge, and a dash slash. Every move has
 * startup / active / recovery frames; hits are tested against the swept blade, so damage lands when the sword
 * visibly passes through the enemy.
 * Animation: every state writes a target pose, and a blend system moves the displayed pose towards it, so no state
 * change pops.
 */
final class Player extends Body {
    // ------------------------------------------------------------------ locomotion tuning (units/s, fixed 60 Hz step)
    static final float RUN = 190f;
    private static final float JUMP_V = 520f, DJ_V = 520f;
    private static final float G_RISE = 1500f, G_FALL = 2150f, G_APEX = 1000f, G_CUT = 5000f, APEX_V = 80f, V_MAX = 900f;
    /** After a double jump the descent is floatier (Wraith Stride): keeps the DJ-gated gaps comfortably crossable. */
    private static final float G_FALL_DJ = 1300f;
    private static final float ACC_GROUND = 2600f, ACC_AIR = 1900f, ACC_TURN = 2400f, DRAG_AIR = 700f;
    private static final float COYOTE = 0.10f, JUMP_BUF = 0.14f, ATK_BUF = 0.22f, DASH_BUF = 0.18f, MIN_JUMP_T = 0.04f;
    private static final float STEP_UP = 7f, NUDGE = 6f;
    private static final float FLIP_T = 0.36f;

    // ------------------------------------------------------------------ dash tuning
    static final float DASH_V = 510f, DASH_EXIT = 170f, DASH_HOLD = 0.55f, DASH_CD = 0.55f, DASH_IFR = 0.30f;
    static final float DASH_T_GROUND = 0.24f, DASH_T_AIR = 0.20f;
    private static final float DASH_JUMP_VX = RUN, GHOST_LIFE = 0.26f;

    // ------------------------------------------------------------------ combat tables (index = move id)
    /** Move ids: 1-3 ground combo, 4-5 aerial slashes, 6 plunge, 7 dash slash. */
    static final int M_PLUNGE = 6, M_DASH = 7;
    static final float FRAME = 1f / 60f;
    /** Startup frames: the blade winds up, no damage. */
    static final int[] ST = {0, 3, 3, 8, 3, 3, 6, 3};
    /** Active frames: the blade sweeps and the hit test runs (the plunge is active until it lands). */
    static final int[] AC = {0, 5, 5, 6, 5, 5, 30, 6};
    /** Recovery frames: follow-through; the next move, a jump or a dash may cancel it. */
    static final int[] RC = {0, 9, 10, 16, 8, 9, 9, 10};
    static final int[] DMG = {0, 10, 12, 22, 10, 12, 22, 12};
    static final float[] KB = {0f, 190f, 190f, 300f, 170f, 170f, 300f, 230f};
    private static final float[] LUNGE = {0f, 140f, 170f, 260f, 70f, 70f, 0f, 330f};
    /** How far the visible slash arc (and the hit region) extends beyond the blade tip. */
    static final float[] EXT = {0f, 12f, 12f, 16f, 12f, 12f, 14f, 14f};
    static final float[] STOP = {0f, 0.045f, 0.055f, 0.10f, 0.045f, 0.055f, 0.10f, 0.06f};
    private static final float[] SHK = {0f, 2.5f, 3f, 5.5f, 2.5f, 3f, 6f, 3.5f};
    static final float BLADE_R = 6f;
    private static final float PLUNGE_V = 640f, HIT_HOVER = 0.14f, HOVER_G = 0.3f;

    // ------------------------------------------------------------------ pose keyframes
    /** Pose vector: lean, legF, kneeF, legB, kneeB, armB, sword, wrist, reach, plant, hipH, footF, footB.
     *  plant 0 = the legs follow the four angle values (running, air); plant 1 = both feet are planted on the ground
     *  at the given stance (hip height above the floor, front foot forward, back foot behind) and the leg angles come
     *  from two-bone IK, so no foot ever hovers during a grounded move. */
    private static final int NP = 13;
    private static final int P_PLANT = 9, P_HIP = 10, P_FF = 11, P_FB = 12;

    private static float[] k(float... v) {
        return v;
    }

    /** KEY[move] = {wind-up (end of startup), strike (end of active), follow-through}. */
    private static final float[][][] KEY = {
        {},
        // 1: diagonal chop from overhead
        {k(-0.18f, 0.55f, 0.70f, -0.60f, 0.50f, 1.80f, 3.30f, -0.50f, 0.85f, 1f, 12.2f, 4.0f, -5.5f),
         k(0.55f, 0.95f, 0.55f, -0.95f, 0.25f, -0.50f, 0.55f, 0.35f, 1.25f, 1f, 9.4f, 9.8f, -9.0f),
         k(0.45f, 0.80f, 0.60f, -0.80f, 0.35f, -0.20f, 0.25f, 0.20f, 1.10f, 1f, 10.0f, 9.0f, -8.0f)},
        // 2: rising reverse slash
        {k(0.35f, 0.70f, 0.60f, -0.75f, 0.40f, 0.20f, -0.35f, -0.35f, 0.90f, 1f, 10.6f, 8.5f, -7.5f),
         k(0.20f, 0.80f, 0.70f, -0.70f, 0.60f, 1.90f, 3.10f, 0.45f, 1.25f, 1f, 11.6f, 6.5f, -7.0f),
         k(0.10f, 0.70f, 0.80f, -0.60f, 0.70f, 1.50f, 3.30f, 0.30f, 1.10f, 1f, 12.0f, 5.0f, -6.0f)},
        // 3: overhead finisher (deep coil, big lunge)
        {k(-0.28f, 0.60f, 1.25f, -0.50f, 1.15f, 1.40f, 4.10f, -0.60f, 0.80f, 1f, 9.6f, 5.5f, -5.5f),
         k(0.75f, 1.00f, 0.60f, -1.10f, 0.20f, -0.40f, 0.20f, 0.40f, 1.30f, 1f, 8.0f, 10.8f, -10.2f),
         k(0.60f, 0.95f, 0.70f, -1.00f, 0.30f, -0.20f, 0.05f, 0.20f, 1.15f, 1f, 9.0f, 10.0f, -9.0f)},
        // 4: aerial slash
        {k(0.00f, 0.60f, 1.30f, -0.20f, 1.10f, 1.20f, 2.60f, -0.40f, 0.90f, 0f, 11f, 3f, -3f),
         k(0.35f, 0.70f, 1.00f, -0.40f, 0.90f, 0.20f, 0.90f, 0.35f, 1.25f, 0f, 11f, 3f, -3f),
         k(0.30f, 0.60f, 0.90f, -0.35f, 0.80f, 0.40f, 0.60f, 0.20f, 1.10f, 0f, 11f, 3f, -3f)},
        // 5: aerial reverse slash
        {k(0.25f, 0.50f, 0.90f, -0.50f, 0.80f, 0.40f, -0.20f, -0.30f, 0.90f, 0f, 11f, 3f, -3f),
         k(0.05f, 0.70f, 1.20f, -0.20f, 1.00f, 1.70f, 3.00f, 0.40f, 1.25f, 0f, 11f, 3f, -3f),
         k(0.05f, 0.60f, 1.20f, -0.20f, 1.00f, 1.50f, 3.20f, 0.30f, 1.10f, 0f, 11f, 3f, -3f)},
        // 6: plunge (wind-up in the air, dive, planted landing crouch)
        {k(0.00f, 0.50f, 1.40f, -0.30f, 1.30f, 2.20f, 3.00f, -0.30f, 0.90f, 0f, 11f, 3f, -3f),
         k(0.90f, 0.10f, 0.10f, -0.35f, 0.20f, -1.00f, 0.45f, 0.25f, 1.30f, 0f, 11f, 3f, -3f),
         k(0.50f, 0.90f, 1.60f, -0.70f, 1.40f, 0.60f, 0.10f, 0.10f, 1.00f, 1f, 8.6f, 6.0f, -5.5f)},
        // 7: dash slash (low, planted slide): the dash pose already is the wind-up, the blade scoops forward from behind
        {k(0.95f, 1.15f, 0.35f, -1.35f, 0.25f, -1.30f, -1.00f, 0.00f, 1.00f, 1f, 8.4f, 9.0f, -11.2f),
         k(0.72f, 1.00f, 0.50f, -1.10f, 0.40f, -0.60f, 1.40f, 0.12f, 1.55f, 1f, 9.0f, 9.5f, -11.0f),
         k(0.55f, 0.85f, 0.50f, -0.90f, 0.40f, -0.30f, 1.25f, 0.12f, 1.20f, 1f, 10.0f, 8.0f, -9.0f)},
    };

    // ------------------------------------------------------------------ public state (read by Game, enemies and tests)
    int hp = 100, maxHp = 100, facing = 1, atk, swing;
    boolean dead, hasDJ, edge;
    float invuln, hurtT, dodgeT, dodgeCd, atkT, atkDur, lastSafeX, lastSafeY;
    final Art.Fig fig = new Art.Fig();

    // ------------------------------------------------------------------ private state
    private float moveDir, groundW = 1f, t, phase, coyote, jumpBuf, atkBuf, dashBuf, landT, landPow, takeoffT, flipT, flickerT, jumpT, postDash, skidT;
    private float runDustT, hitHover, dashLen, dashDir, dashVy, ghostAcc, poseRate;
    private int airJumps, gi;
    private boolean usedDJ, jumping, cutting, airDashUsed, dashAir, active, plunging, trailStart, hasBlade, dashSlashed;
    private float pHx, pHy, pTx, pTy;
    private final float[] cur = new float[NP], tgt = new float[NP], from = new float[NP], prevCur = new float[NP], ik = new float[2];
    private float clampSide = 1f;
    private boolean landBlend;
    private static final int GN = 7;
    private final float[][] gj = new float[GN][26];
    private final float[] ga = new float[GN], gl = new float[GN], gr = new float[GN], gaa = new float[GN];
    private final int[] gc = new int[GN];

    Player() {
        w = 14f;
        h = 34f;
        resetPose();
    }

    private void resetPose() {
        set(cur, 0.06f, 0.14f, 0.12f, -0.14f, 0.10f, 0.25f, 1.0f, 0.12f, 1f);
        ground(cur, 13.75f, 1.2f, -1.2f);
        groundW = 1f;
        System.arraycopy(cur, 0, tgt, 0, NP);
        System.arraycopy(cur, 0, prevCur, 0, NP);
    }

    /** Puts the hero at a position without touching health. */
    void place(float px, float py) {
        x = px;
        y = py;
        vx = 0f;
        vy = 0f;
        lastSafeX = px;
        lastSafeY = py;
        snap();
        atk = 0;
        dodgeT = 0f;
        hurtT = 0f;
        onGround = false;
        clearActions();
        for (int i = 0; i < GN; i++) ga[i] = 0f;
        resetPose();
    }

    /** Drops every transient action (used when teleporting, taking a hit or respawning). */
    private void clearActions() {
        usedDJ = false;
        hitHover = 0f;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        dodgeT = 0f;
        flipT = 0f;
        jumping = false;
        cutting = false;
        jumpBuf = 0f;
        atkBuf = 0f;
        dashBuf = 0f;
        postDash = 0f;
        skidT = 0f;
        landT = 0f;
        takeoffT = 0f;
    }

    void revive() {
        dead = false;
        hp = maxHp;
        invuln = 1.2f;
        flickerT = 1.2f;
    }

    /** Air jumps still available (0 or 1); read by the headless tests. */
    int jumpsLeft() {
        return airJumps;
    }

    /** 0..1: how recharged the dash is (1 = ready). */
    float dashReady() {
        return dodgeCd <= 0f ? 1f : Math.max(0f, 1f - dodgeCd / DASH_CD);
    }

    /** False while a dash is impossible regardless of cooldown (mid-air before Wraith Stride, or after the air dash is spent). */
    boolean dashAvailable() {
        return !dead && hurtT <= 0f && (onGround || coyote > 0f || (hasDJ && !airDashUsed));
    }

    private boolean canDash() {
        if (dead || dodgeCd > 0f || hurtT > 0f) return false;
        return onGround || coyote > 0f || (hasDJ && !airDashUsed);
    }

    // ================================================================== update

    void update(Game g, Input in, float dt) {
        t += dt;
        if (invuln > 0f) invuln -= dt;
        if (hurtT > 0f) hurtT -= dt;
        if (dodgeCd > 0f) dodgeCd -= dt;
        if (coyote > 0f) coyote -= dt;
        if (jumpBuf > 0f) jumpBuf -= dt;
        if (atkBuf > 0f) atkBuf -= dt;
        if (dashBuf > 0f) dashBuf -= dt;
        if (landT > 0f) landT -= dt;
        if (takeoffT > 0f) takeoffT -= dt;
        if (flickerT > 0f) flickerT -= dt;
        if (postDash > 0f) postDash -= dt;
        if (skidT > 0f) skidT -= dt;
        for (int i = 0; i < GN; i++) if (ga[i] > 0f) ga[i] -= dt;
        if (in.takeJump()) jumpBuf = JUMP_BUF;
        if (in.takeAttack()) atkBuf = ATK_BUF;
        if (in.takeDodge()) dashBuf = DASH_BUF;

        final float dir = (in.right ? 1f : 0f) - (in.left ? 1f : 0f);
        moveDir = dir;
        final boolean stunned = hurtT > 0f;
        final boolean was = onGround;
        final float vyBefore = vy;

        if (!stunned && dodgeT <= 0f && dashBuf > 0f && canDash()) startDash(g, dir);
        if (stunned) {
            vx = approach(vx, 0f, 700f * dt);
            gravity = vy < 0f ? G_RISE : G_FALL;
        } else if (dodgeT > 0f) {
            dashStep(g, in, dir, dt);
        } else {
            freeStep(g, in, dir, dt);
        }

        stepPhysics(g.world, dt);
        afterPhysics(g, was, vyBefore, dir);

        phase += Math.abs(vx) * dt * 0.075f;
        pose(g, dt);
        Art.solve(fig);
        bladeStep(g);
        ghosts(dt);
    }

    // ================================================================== dash

    private void startDash(Game g, float dir) {
        final boolean grounded = onGround || coyote > 0f;
        dashAir = !grounded;
        if (dashAir) airDashUsed = true;
        dashDir = dir != 0f ? dir : facing;
        facing = dashDir > 0f ? 1 : -1;
        dashLen = dashAir ? DASH_T_AIR : DASH_T_GROUND;
        dodgeT = dashLen;
        dodgeCd = DASH_CD;
        dashBuf = 0f;
        dashVy = Math.min(0f, vy) * 0.3f;
        invuln = Math.max(invuln, DASH_IFR);
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        flipT = 0f;
        jumping = false;
        cutting = false;
        dashSlashed = false;
        ghostAcc = 30f;
        vy = 0f;
        g.fx.dustTrail(cx(), y + h, dashDir, 6);
        g.fx.ring(cx() - dashDir * 6f, y + h * 0.5f, 22f, 0xFF58E0FF);
        g.fx.kick(-dashDir * 2.5f, 0f);
    }

    private void dashStep(Game g, Input in, float dir, float dt) {
        dodgeT -= dt;
        final float k = Math.min(1f, (dashLen - dodgeT) / dashLen);
        float sp = DASH_V;
        if (k > DASH_HOLD) sp = DASH_V + (DASH_EXIT - DASH_V) * eio((k - DASH_HOLD) / (1f - DASH_HOLD));
        vx = dashDir * sp;
        vy = 0f;
        gravity = 0f;
        g.fx.streak(cx() - dashDir * 5f, y + 5f + g.fx.rnd.nextFloat() * (h - 10f), 14f + g.fx.rnd.nextFloat() * 22f, dashDir, g.fx.rnd.nextFloat() < 0.5f ? 0xFFE8FFFF : 0xFF58E0FF);
        runDustT -= dt;
        if (!dashAir && onGround && runDustT <= 0f) {
            runDustT = 0.05f;
            g.fx.dustTrail(cx(), y + h, dashDir, 2);
        }
        // attack input: the dash turns into a dash slash once it is past its first half
        if (atkBuf > 0f && k >= 0.45f && !dashSlashed) {
            dashSlashed = true;
            dodgeT = 0f;
            postDash = 0f;
            vx = dashDir * Math.max(DASH_EXIT, sp * 0.8f);
            startMove(g, M_DASH, dashDir);
            return;
        }
        // a jump cancels a grounded dash into a long hop (speed capped so it cannot out-jump a normal run-jump by much)
        if (jumpBuf > 0f && onGround && k >= 0.25f) {
            dodgeT = 0f;
            vx = Body.clamp(vx, -DASH_JUMP_VX, DASH_JUMP_VX);
            postDash = 0f;
            groundJump(g, dir);
            gravity = G_RISE;
            return;
        }
        if (dodgeT <= 0f) endDash();
    }

    private void endDash() {
        dodgeT = 0f;
        postDash = 0.12f;
        vx = dashDir * DASH_EXIT;
        vy = dashVy;
        skidT = 0f;
    }

    // ================================================================== free movement, jumping, attacking

    private void freeStep(Game g, Input in, float dir, float dt) {
        // ---- jumps: a jump press cancels any attack
        if (jumpBuf > 0f) {
            if (onGround || coyote > 0f) groundJump(g, dir);
            else if (hasDJ && airJumps > 0 && !groundSoon(g.world)) doubleJump(g, dir);
        }
        if (jumping) {
            jumpT += dt;
            if (!in.jump && vy < -150f && jumpT >= MIN_JUMP_T) {
                jumping = false;
                cutting = true;
            }
        }
        if (vy >= 0f) {
            jumping = false;
            cutting = false;
        }

        // ---- attacks
        if (atkBuf > 0f) tryAttack(g, dir);
        if (atk > 0) advanceAttack(g, dir, dt);

        // ---- horizontal control
        if (atk == 0) {
            if (onGround && dir != 0f && vx * dir < -100f && skidT <= 0f) {
                skidT = 0.12f;
                g.fx.dustTrail(cx(), y + h, -dir, 4);
            }
            horizontal(dir, dt, 1f);
            if (onGround && Math.abs(vx) > 120f) {
                runDustT -= dt;
                if (runDustT <= 0f) {
                    runDustT = 0.16f;
                    g.fx.dustTrail(cx() - facing * 3f, y + h, facing, 1);
                }
            }
        }

        // ---- gravity
        float gv;
        if (vy < 0f) gv = cutting ? G_CUT : G_RISE;
        else gv = usedDJ ? G_FALL_DJ : G_FALL;
        if (!cutting && Math.abs(vy) < APEX_V && !onGround) gv = G_APEX;
        if (atk > 0 && !onGround) gv = attackGravity(gv, dt);
        if (hitHover > 0f) {
            // a slash that connects holds the hero up for a moment so the combo can continue; it only slows a fall, never a rise
            hitHover -= dt;
            if (vy >= 0f) {
                gv = G_RISE * HOVER_G;
                if (vy > 60f) vy = approach(vy, 60f, 3200f * dt);
            }
        }
        gravity = gv;
    }

    private void horizontal(float dir, float dt, float scale) {
        final float target = dir * RUN;
        if (onGround) {
            vx = approach(vx, target, ACC_GROUND * scale * dt);
        } else if (dir == 0f) {
            vx = approach(vx, 0f, DRAG_AIR * scale * dt);
        } else if (vx * dir < 0f) {
            vx = approach(vx, target, ACC_TURN * scale * dt);
        } else {
            vx = approach(vx, target, ACC_AIR * scale * dt);
        }
        if (dir != 0f) facing = dir > 0f ? 1 : -1;
    }

    private void groundJump(Game g, float dir) {
        vy = -JUMP_V;
        vx = Body.clamp(vx, -RUN, RUN);      // a jump never launches faster than a run (no banking dash or lunge speed)
        jumping = true;
        cutting = false;
        jumpT = 0f;
        jumpBuf = 0f;
        coyote = 0f;
        onGround = false;
        takeoffT = 0.09f;
        landT = 0f;
        flipT = 0f;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        g.fx.dust(cx(), y + h);
    }

    private void doubleJump(Game g, float dir) {
        vy = -DJ_V;
        usedDJ = true;
        airJumps--;
        jumpBuf = 0f;
        jumping = true;
        cutting = false;
        jumpT = 0f;
        flipT = FLIP_T;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        ghostAcc = 0f;
        // a double jump may redirect the hero: grab the held direction at once
        if (dir != 0f) {
            if (vx * dir < 0f) vx = dir * RUN * 0.6f;
            else vx = dir * Math.max(Math.abs(vx), RUN * 0.6f);
            facing = dir > 0f ? 1 : -1;
        }
        g.fx.ring(cx(), y + h, 34f, 0xFF58E0FF);
        g.fx.ring(cx(), y + h + 4f, 20f, 0xFFFFFFFF);
        g.fx.burst(cx(), y + h, 9, 0xFF9AF0FF, 100f, 0.35f, 2f);
        for (int i = 0; i < 7; i++) {
            g.fx.emit(cx() + (g.fx.rnd.nextFloat() - 0.5f) * 14f, y + h - 2f, (g.fx.rnd.nextFloat() - 0.5f) * 60f, 90f + g.fx.rnd.nextFloat() * 120f, 0.35f + 0.2f * g.fx.rnd.nextFloat(), 2.2f, 0xFF9AF0FF, 0f);
        }
        g.fx.kick(0f, 1.2f);
    }

    /** True when the ground is about to arrive: a buffered jump should wait for it instead of burning the double jump. */
    private boolean groundSoon(World wd) {
        if (vy <= 0f) return false;
        final float feet = y + h, reach = vy * 0.12f + 6f;
        final int tl = (int) Math.floor(x / World.TS), tr = (int) Math.floor((x + w - 0.01f) / World.TS);
        for (int row = (int) Math.floor(feet / World.TS); row * World.TS <= feet + reach; row++) {
            if (wd.solid(tl, row) || wd.solid(tr, row)) return row * World.TS - feet <= reach;
        }
        return false;
    }

    // ------------------------------------------------------------------ attacks

    private void tryAttack(Game g, float dir) {
        final boolean air = !onGround;
        if (atk == 0) {
            int m = air ? 4 : 1;
            if (postDash > 0f && !air) m = M_DASH;
            startMove(g, m, dir);
            return;
        }
        // chain: allowed once the active frames are over
        int next = 0;
        switch (atk) {
            case 1: next = 2; break;
            case 2: next = 3; break;
            case 4: next = 5; break;
            case 5: next = M_PLUNGE; break;
            case M_DASH: next = 2; break;
            default: break;
        }
        if (next != 0 && atkT / FRAME >= ST[atk] + AC[atk] - 0.001f) startMove(g, next, dir);
    }

    private void startMove(Game g, int m, float dir) {
        atk = m;
        atkT = 0f;
        active = false;
        plunging = false;
        hasBlade = false;
        atkDur = (ST[m] + AC[m] + RC[m]) * FRAME;
        landBlend = false;
        swing++;
        atkBuf = 0f;
        trailStart = true;
        System.arraycopy(cur, 0, from, 0, NP);
        if (dir != 0f) facing = dir > 0f ? 1 : -1;
    }

    private void advanceAttack(Game g, float dir, float dt) {
        final int m = atk;
        atkT += dt;
        final float fr = atkT / FRAME + 0.001f;
        if (!active && dir != 0f) facing = dir > 0f ? 1 : -1;     // can still turn while the blade winds up
        if (!active && fr >= ST[m]) beginActive(g, m);
        final boolean recovering = fr >= ST[m] + AC[m] && !plunging;
        if (onGround) {
            vx = approach(vx, 0f, (active && !recovering ? 650f : 900f) * dt);
            if (Math.abs(vx) > 70f) {
                runDustT -= dt;
                if (runDustT <= 0f) {
                    runDustT = 0.06f;
                    g.fx.dustTrail(cx() - facing * 5f, y + h, facing, 1);
                }
            }
        } else if (m == M_PLUNGE) {
            if (!active) vx = approach(vx, 0f, 900f * dt);
        } else if (recovering) {
            horizontal(dir, dt, 0.6f);
        } else {
            vx = approach(vx, 0f, 220f * dt);
        }
        if (fr >= (ST[m] + AC[m] + RC[m]) - 0.001f) {
            atk = 0;
            active = false;
            plunging = false;
            hasBlade = false;
            return;
        }
        // an aerial slash that finishes after touching down hands control back immediately
        if (onGround && (m == 4 || m == 5) && recovering) {
            atk = 0;
            active = false;
            hasBlade = false;
        }
    }

    private float attackGravity(float gv, float dt) {
        if (atk == M_PLUNGE) {
            if (!active) vy = approach(vy, 0f, 2600f * dt);
            return 0f;
        }
        return gv;
    }

    private void beginActive(Game g, int m) {
        active = true;
        if (m == M_PLUNGE) {
            plunging = true;
            vy = PLUNGE_V;
            vx *= 0.15f;
            g.fx.burst(cx(), y + h * 0.5f, 6, 0xFFFFFFFF, 120f, 0.25f, 2f);
            return;
        }
        final float lunge = LUNGE[m];
        if (onGround || m == M_DASH) {
            float v = lunge;
            final float dx = targetDx(g);
            if (dx >= 0f) v = Body.clamp((float) Math.sqrt(2f * 650f * Math.max(0f, dx - 34f)), 0.4f * lunge, 1.25f * lunge);
            final float cv = vx * facing;
            vx = facing * Math.max(v, cv > 0f ? cv * 0.9f : 0f);
            if (onGround) g.fx.dustTrail(cx(), y + h, facing, 2);
        } else {
            vx = Body.clamp(vx + facing * lunge, -RUN, RUN);
        }
    }

    /** Distance (centre to centre) to the nearest enemy in front within reach, or -1. Used to land the lunge at striking range. */
    private float targetDx(Game g) {
        float best = -1f;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead) continue;
            best = nearer(best, (e.cx() - cx()) * facing, e.cy() - cy());
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable()) best = nearer(best, (b.cx() - cx()) * facing, b.cy() - cy());
        return best;
    }

    private static float nearer(float best, float dx, float dy) {
        if (dx < -4f || dx > 130f || Math.abs(dy) > 50f) return best;
        return best < 0f || dx < best ? Math.max(0f, dx) : best;
    }

    // ------------------------------------------------------------------ blade: hit detection and slash trail

    /** Runs after the pose is solved: tests the swept blade against enemies and lays down the slash trail. */
    private void bladeStep(Game g) {
        if (atk == 0 || dead) {
            hasBlade = false;
            return;
        }
        final float[] j = fig.j;
        final float hx = j[20], hy = j[21], tx = j[22], ty = j[23];
        final float fr = atkT / FRAME, end = ST[atk] + AC[atk];
        if (active && (plunging || fr < end)) {
            trailSamples(g, hx, hy, tx, ty);
            hitCheck(g, hx, hy, tx, ty);
        } else if (active && fr < end + 1.5f) {
            trailSamples(g, hx, hy, tx, ty);      // a short fade-out so the end of the arc has no gap
        }
        pHx = hx;
        pHy = hy;
        pTx = tx;
        pTy = ty;
        hasBlade = true;
    }

    private void trailSamples(Game g, float hx, float hy, float tx, float ty) {
        final int col = bladeColor();
        final float ext = EXT[atk];
        final int steps = hasBlade ? 3 : 1;
        final float a0 = (float) Math.atan2(pTy - pHy, pTx - pHx), a1 = (float) Math.atan2(ty - hy, tx - hx);
        float da = a1 - a0;
        while (da > Math.PI) da -= 2f * (float) Math.PI;
        while (da < -Math.PI) da += 2f * (float) Math.PI;
        final float l0 = (float) Math.hypot(pTx - pHx, pTy - pHy), l1 = (float) Math.hypot(tx - hx, ty - hy);
        for (int s = 1; s <= steps; s++) {
            final float u = s / (float) steps;
            final float ox = hasBlade ? pHx + (hx - pHx) * u : hx, oy = hasBlade ? pHy + (hy - pHy) * u : hy;
            final float a = hasBlade ? a0 + da * u : a1, len = (hasBlade ? l0 + (l1 - l0) * u : l1) + ext;
            final float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            final float floorY = onGround ? y + h : 1e9f;      // while standing the arc is cut off by the floor instead of cutting into it
            g.fx.trail(ox + ca * len * 0.3f, Math.min(floorY, oy + sa * len * 0.3f), ox + ca * len, Math.min(floorY, oy + sa * len), trailStart, col);
            trailStart = false;
        }
    }

    private int bladeColor() {
        final int base = edge ? 0xFFFF3050 : 0xFF58E0FF;
        return atk == 3 || atk == M_PLUNGE ? Art.mix(base, 0xFFFFFFFF, 0.35f) : base;
    }

    private void hitCheck(Game g, float hx, float hy, float tx, float ty) {
        final int m = atk;
        final float ext = EXT[m] + (edge ? 10f : 0f);
        final int dmg = Math.round(DMG[m] * (edge ? 1.5f : 1f));
        boolean hitAny = false;
        float ix = 0f, iy = 0f;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead || e.lastSwing == swing) continue;
            if (bladeHits(hx, hy, tx, ty, ext, e.x, e.y, e.w, e.h)) {
                e.lastSwing = swing;
                e.hurt(g, dmg, cx(), KB[m]);
                hitAny = true;
                ix = e.cx();
                iy = e.cy();
            }
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable() && b.lastSwing != swing && bladeHits(hx, hy, tx, ty, ext, b.x, b.y, b.w, b.h)) {
            b.lastSwing = swing;
            b.hurt(g, dmg);
            hitAny = true;
            ix = b.cx();
            iy = b.cy();
        }
        if (hitAny) impact(g, m, ix, iy, tx, ty);
    }

    /** Feedback for a landed hit: hit-stop, shake, camera shove, flash and sparks thrown along the swing. */
    private void impact(Game g, int m, float ix, float iy, float tx, float ty) {
        final float big = (m == 3 || m == M_PLUNGE) ? 1f : 0f;
        g.fx.freeze = Math.max(g.fx.freeze, STOP[m]);
        if (!onGround && (m == 4 || m == 5)) hitHover = HIT_HOVER;
        g.fx.shake(SHK[m]);
        g.fx.kick(facing * (2.2f + 2.4f * big), m == M_PLUNGE ? 2.5f : 0f);
        final float px = Body.clamp(ix, tx - 18f, tx + 18f), py = Body.clamp(iy, ty - 18f, ty + 18f);
        g.fx.flash(px, py, 26f + 22f * big);
        g.fx.sparksAng(px, py, facing > 0 ? -0.35f : (float) Math.PI + 0.35f, 6 + (int) (6 * big), 0xFFFFE8B0);
        g.fx.ring(px, py, 20f + 16f * big, 0xFFFFFFFF);
    }

    /** Swept test: the blade (hilt to tip, extended by ext) between last frame and this one touches the box. */
    private boolean bladeHits(float hx, float hy, float tx, float ty, float ext, float bx, float by, float bw, float bh) {
        final float l = bx - BLADE_R, t0 = by - BLADE_R, r = bx + bw + BLADE_R, b = by + bh + BLADE_R;
        final int steps = hasBlade ? 4 : 1;
        for (int s = 0; s < steps; s++) {
            final float u = hasBlade ? (s + 1f) / steps : 1f;
            final float h0x = hasBlade ? pHx + (hx - pHx) * u : hx, h0y = hasBlade ? pHy + (hy - pHy) * u : hy;
            float t0x = hasBlade ? pTx + (tx - pTx) * u : tx, t0y = hasBlade ? pTy + (ty - pTy) * u : ty;
            final float dx = t0x - h0x, dy = t0y - h0y, len = (float) Math.sqrt(dx * dx + dy * dy) + 0.0001f;
            t0x += dx / len * ext;
            t0y += dy / len * ext;
            if (segBox(h0x, h0y, t0x, t0y, l, t0, r, b)) return true;
        }
        return false;
    }

    /** Liang-Barsky segment against an axis-aligned box. */
    static boolean segBox(float x0, float y0, float x1, float y1, float l, float t, float r, float b) {
        float tmin = 0f, tmax = 1f;
        final float dx = x1 - x0, dy = y1 - y0;
        if (Math.abs(dx) < 1e-6f) {
            if (x0 < l || x0 > r) return false;
        } else {
            float ta = (l - x0) / dx, tb = (r - x0) / dx;
            if (ta > tb) { float s = ta; ta = tb; tb = s; }
            tmin = Math.max(tmin, ta);
            tmax = Math.min(tmax, tb);
            if (tmin > tmax) return false;
        }
        if (Math.abs(dy) < 1e-6f) {
            if (y0 < t || y0 > b) return false;
        } else {
            float ta = (t - y0) / dy, tb = (b - y0) / dy;
            if (ta > tb) { float s = ta; ta = tb; tb = s; }
            tmin = Math.max(tmin, ta);
            tmax = Math.min(tmax, tb);
            if (tmin > tmax) return false;
        }
        return true;
    }

    // ================================================================== physics

    private void stepPhysics(World wd, float dt) {
        vy += gravity * dt;
        if (vy > V_MAX) vy = V_MAX;
        hitWall = false;
        final float dx = vx * dt;
        int n = Math.max(1, (int) Math.ceil(Math.abs(dx) / 8f));
        final float sdx = dx / n;
        for (int i = 0; i < n; i++) {
            final float ox = x, svx = vx;
            moveX(wd, sdx);
            if (hitWall && sdx != 0f && vy > -200f && dodgeT <= 0f) {
                // ledge assist: a corner that is only a few units above the feet is stepped onto instead of bonked into
                for (float up = 1f; up <= STEP_UP; up += 1f) {
                    if (free(wd, ox + sdx, y - up)) {
                        x = ox + sdx;
                        y -= up;
                        vx = svx;
                        hitWall = false;
                        break;
                    }
                }
            }
            if (hitWall) break;
        }
        onGround = false;
        final float dy = vy * dt;
        n = Math.max(1, (int) Math.ceil(Math.abs(dy) / 8f));
        final float sdy = dy / n;
        for (int i = 0; i < n; i++) {
            if (sdy < 0f) cornerNudge(wd, sdy);
            moveY(wd, sdy);
        }
    }

    /** Rising into the edge of a ceiling block by a few units slides the hero past it instead of stopping the jump. */
    private void cornerNudge(World wd, float sdy) {
        final float ny = y + sdy;
        final int ty = (int) Math.floor(ny / World.TS);
        final int tl = (int) Math.floor(x / World.TS), tr = (int) Math.floor((x + w - 0.01f) / World.TS);
        final boolean sl = wd.solid(tl, ty), sr = wd.solid(tr, ty);
        if (sl == sr) return;
        if (sl) {
            final float ov = (tl + 1) * World.TS - x;
            if (ov <= NUDGE && free(wd, x + ov + 0.05f, ny)) x += ov + 0.05f;
        } else {
            final float ov = x + w - tr * World.TS;
            if (ov <= NUDGE && free(wd, x - ov - 0.05f, ny)) x -= ov + 0.05f;
        }
    }

    private void afterPhysics(Game g, boolean was, float vyBefore, float dir) {
        if (dodgeT > 0f && hitWall && dodgeT > 0.03f) {
            // the dash ends against a wall: bump instead of grinding along it
            g.fx.sparksAng(cx() + dashDir * 8f, y + h * 0.5f, dashDir > 0f ? (float) Math.PI : 0f, 5, 0xFFB8E8FF);
            g.fx.kick(-dashDir * 2f, 0f);
            dodgeT = 0f;
            postDash = 0f;
            vx = 0f;
            vy = dashVy;
        }
        if (onGround) {
            coyote = COYOTE;
            airJumps = hasDJ ? 1 : 0;
            airDashUsed = false;
            usedDJ = false;
            hitHover = 0f;
            jumping = false;
            cutting = false;
            flipT = 0f;
            if (!was && vyBefore > 140f) land(g, vyBefore);
            if (plunging) plungeLand(g);
            if (dodgeT <= 0f && g.world.safeSpot(this)) {
                lastSafeX = x;
                lastSafeY = y;
            }
        }
        // coyote time forgives walking off a ledge; it is not a movement option, so it is void when the hero leaves the
        // ground mid-dash or at lunge speed (otherwise dash -> dash slash -> coyote jump would launch from mid-air)
        if (!onGround && (dodgeT > 0f || Math.abs(vx) > RUN * 1.1f)) coyote = 0f;
        if (flipT > 0f) flipT -= FRAME;
    }

    private void land(Game g, float vyBefore) {
        landPow = Body.clamp((vyBefore - 140f) / 480f, 0f, 1f);
        landT = 0.05f + 0.07f * landPow;
        g.fx.dustLand(cx(), y + h, landPow);
        if (landPow > 0.85f) g.fx.kick(0f, 1.6f);
        skidT = 0f;
    }

    private void plungeLand(Game g) {
        plunging = false;
        System.arraycopy(cur, 0, from, 0, NP);      // the landing crouch blends from the pose on screen
        landBlend = true;
        atkT = (ST[M_PLUNGE] + AC[M_PLUNGE]) * FRAME;     // jump straight to the recovery phase
        final float gx = cx(), gy = y + h;
        g.fx.ring(gx, gy - 2f, 48f, 0xFFB8E8FF);
        g.fx.ring(gx, gy - 2f, 30f, 0xFF58E0FF);
        g.fx.dustLand(gx, gy, 1f);
        g.fx.burst(gx, gy - 4f, 10, 0xFFB8E8FF, 160f, 0.35f, 2.2f);
        g.fx.shake(SHK[M_PLUNGE]);
        g.fx.kick(0f, 3.2f);
        // ground slam: anything near the landing spot that the dive did not already hit takes a lighter blow
        boolean any = false;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead || e.lastSwing == swing) continue;
            if (overlap(gx - 46f, gy - 36f, 92f, 44f, e.x, e.y, e.w, e.h)) {
                e.lastSwing = swing;
                e.hurt(g, Math.round(12 * (edge ? 1.5f : 1f)), gx, 240f);
                any = true;
            }
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable() && b.lastSwing != swing && overlap(gx - 46f, gy - 36f, 92f, 44f, b.x, b.y, b.w, b.h)) {
            b.lastSwing = swing;
            b.hurt(g, Math.round(12 * (edge ? 1.5f : 1f)));
            any = true;
        }
        if (any) g.fx.freeze = Math.max(g.fx.freeze, 0.07f);
    }

    // ================================================================== damage

    void hurt(Game g, int dmg, float srcX) {
        if (invuln > 0f || dead) return;
        hp -= dmg;
        if (hp < 0) hp = 0;
        invuln = 0.9f;
        flickerT = 0.9f;
        hurtT = 0.3f;
        clearActions();
        float d = cx() < srcX ? -1f : 1f;
        vx = d * 230f;
        vy = -240f;
        onGround = false;
        g.fx.shake(6f);
        g.fx.freeze = Math.max(g.fx.freeze, 0.07f);
        g.fx.flashA = 0.4f;
        g.fx.flashC = 0xFFFF2040;
        g.fx.burst(cx(), cy(), 10, 0xFFFF4060, 150f, 0.4f, 2.4f);
        g.fx.text(cx(), y - 6f, "-" + dmg, 0xFFFF6070);
    }

    /** Falling into a pit: small damage, then back to the last safe ground. */
    void pitReset(Game g) {
        if (dead) return;
        x = lastSafeX;
        y = lastSafeY;
        snap();
        vx = 0f;
        vy = 0f;
        if (invuln <= 0f) {
            hp = Math.max(0, hp - 15);
            g.fx.shake(5f);
            g.fx.flashA = 0.3f;
            g.fx.flashC = 0xFFFF2040;
            g.fx.text(cx(), y - 6f, "-15", 0xFFFF6070);
        }
        invuln = 1.2f;
        flickerT = 1.2f;
        hurtT = 0f;
        clearActions();
        g.fx.burst(cx(), cy(), 12, 0xFF58E0FF, 120f, 0.4f, 2f);
    }

    // ================================================================== animation

    /** Sets the nine angle parameters and un-plants the feet. */
    private static void set(float[] o, float a0, float a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        o[0] = a0; o[1] = a1; o[2] = a2; o[3] = a3; o[4] = a4; o[5] = a5; o[6] = a6; o[7] = a7; o[8] = a8;
        o[P_PLANT] = 0f;
    }

    /** Plants both feet: hip height above the floor and how far in front of / behind the hip each foot stands. */
    private static void ground(float[] o, float hip, float footF, float footB) {
        o[P_PLANT] = 1f;
        o[P_HIP] = hip;
        o[P_FF] = footF;
        o[P_FB] = footB;
    }

    /** Two-bone IK for one 7+7 unit leg: out = {thigh angle, knee bend} so the foot lands dx ahead of a hip hipH above the floor. */
    private static void ikLeg(float hipH, float dx, float[] out) {
        final float maxD = 13.95f;
        final float hh = Body.clamp(hipH, 3f, 13.9f);
        float d = (float) Math.hypot(dx, hh);
        if (d > maxD) {
            dx = Math.copySign((float) Math.sqrt(maxD * maxD - hh * hh), dx);
            d = maxD;
        }
        final float alpha = (float) Math.acos(Math.min(1f, d / 14f));
        out[0] = (float) Math.atan2(dx, hh) + alpha;
        out[1] = 2f * alpha;
    }

    /** Smooth-start, slightly fast-middle curve used for wind-ups and sweeps: no frame covers more than ~30% of the move. */
    private static float sw(float u) {
        u = Body.clamp(u, 0f, 1f);
        final float q = 1f - (1f - u) * (1f - u);
        return 0.5f * q + 0.5f * (u * u * (3f - 2f * u));
    }

    private static float eo(float u) {
        u = Body.clamp(u, 0f, 1f);
        final float v = 1f - u;
        return 1f - v * v * v;
    }

    private static float eio(float u) {
        u = Body.clamp(u, 0f, 1f);
        return u * u * (3f - 2f * u);
    }

    /** Fills tgt with the pose the current locomotion state wants and sets poseRate (how fast cur chases it). */
    private void locomotionTarget() {
        final float[] o = tgt;
        final float sp = Math.min(1f, Math.abs(vx) / RUN);
        if (hurtT > 0f) {
            set(o, -0.3f, 0.25f, 0.3f, -0.5f, 0.6f, 2.4f, 2.6f, 0.12f, 1f);
            poseRate = 60f;
        } else if (dodgeT > 0f) {
            if (dashAir) {
                set(o, 0.9f, 0.95f, 0.9f, -1.2f, 0.8f, -1.3f, -1.0f, 0f, 1f);
            } else {
                set(o, 0.95f, 1.15f, 0.35f, -1.35f, 0.25f, -1.3f, -1.0f, 0f, 1f);
                ground(o, 8.4f, 9.0f, -11.2f);      // a low slide: both feet stay on the floor
            }
            poseRate = 42f;
        } else if (!onGround) {
            if (flipT > 0f) {
                set(o, 0.5f, 1.5f, 2.2f, 1.2f, 2.0f, 1.2f, 1.3f, 0.12f, 1f);
                poseRate = 45f;
            } else if (takeoffT > 0f && vy < 0f) {
                set(o, 0.02f, 0.15f, 0.15f, -0.55f, 0.95f, -0.5f, 2.3f, 0.12f, 1f);
                poseRate = 40f;
            } else if (vy < -APEX_V) {
                set(o, 0.10f, 0.65f, 1.35f, -0.35f, 0.65f, 2.3f, 2.0f, 0.12f, 1f);
                poseRate = 18f;
            } else if (vy <= APEX_V) {
                set(o, 0.06f, 0.80f, 1.50f, -0.10f, 1.20f, 1.5f, 1.6f, 0.12f, 1f);
                poseRate = 14f;
            } else {
                final float f = Body.clamp((vy - 200f) / 500f, 0f, 1f);
                set(o, 0.0f, 0.30f - 0.15f * f, 0.30f - 0.2f * f, -0.50f + 0.2f * f, 0.40f - 0.3f * f, 2.6f + 0.2f * f, 2.45f, 0.12f, 1f);
                poseRate = 14f;
            }
        } else if (landT > 0f && sp < 0.7f) {
            final float p = landPow;
            set(o, 0.15f + 0.25f * p, 0.70f + 0.25f * p, 1.0f + 0.7f * p, -0.5f - 0.15f * p, 0.9f + 0.5f * p, 0.6f, 0.9f, 0.12f, 1f);
            ground(o, 11.6f - 2.6f * p, 5.0f, -4.5f);
            poseRate = 50f;
        } else if (skidT > 0f) {
            set(o, -0.15f, 0.5f, 0.2f, -0.9f, 0.6f, 1.0f, 1.2f, 0.12f, 1f);
            ground(o, 11.6f, 9.0f, -2.5f);
            poseRate = 40f;
        } else if (sp > 0.1f && (moveDir != 0f || sp > 0.55f)) {      // coasting to a stop after a lunge keeps the planted stance
            final float cs = (float) Math.cos(phase), sn = (float) Math.sin(phase);
            set(o, 0.3f * sp, sn * 0.95f, 0.15f + Math.max(0f, cs) * 0.9f, -sn * 0.95f, 0.15f + Math.max(0f, -cs) * 0.9f,
                0.3f - sn * 0.9f, 0.9f - sn * 0.2f, 0.12f, 1f);
            poseRate = 24f;
        } else {
            final float b = (float) Math.sin(t * 2.2f);
            set(o, 0.06f, 0.14f, 0.12f + 0.06f * b, -0.14f, 0.1f - 0.05f * b, 0.25f + 0.05f * b, 1.0f + 0.05f * b, 0.12f, 1f);
            ground(o, 13.75f + 0.12f * b, 1.2f, -1.2f);
            poseRate = 18f;
        }
    }

    private void pose(Game g, float dt) {
        locomotionTarget();
        if (atk > 0) attackPose(dt);
        else {
            final float kk = 1f - (float) Math.exp(-poseRate * dt);
            for (int i = 0; i < NP; i++) cur[i] += (tgt[i] - cur[i]) * kk;
        }
        groundW += ((onGround ? 1f : 0f) - groundW) * (1f - (float) Math.exp(-45f * dt));
        final boolean strike = atk > 0 && active && atkT / FRAME < ST[atk] + (plunging ? 3 : AC[atk]) + 0.001f;
        final Art.Fig f = fig;
        applyPose(f);
        // keep the blade tip off the floor while standing: it rests just above the ground instead of cutting through it.
        // The side it is pushed to (forward or back) only flips with hysteresis, and the result is slew-limited below,
        // so a blade swinging through "straight down" never snaps from one side to the other.
        // (during the strike sweep itself the blade may dip through the floor: clamping there would flip it sideways)
        final float bladeAng = f.swordAng + f.wrist;
        if (bladeAng > 0.2f) clampSide = 1f;
        else if (bladeAng < -0.2f) clampSide = -1f;
        if (onGround && f.rot == 0f && !strike) {
            final float floorY = y + h - (atk == M_PLUNGE ? 0f : 2.5f);
            for (int i = 0; i < 24 && f.j[23] > floorY && Math.abs(f.swordAng) < 1.55f; i++) {
                f.swordAng += 0.06f * clampSide;
                Art.solve(f);
            }
            cur[6] = f.swordAng;
        }
        // while the blade sweeps through the ground it is cut short at the floor line (continuous, unlike pushing it aside)
        if (onGround && f.rot == 0f && strike && f.j[23] > y + h) {
            final float cb = (float) Math.cos(f.swordAng + f.wrist);
            if (cb > 0.05f) {
                f.bladeLen = Body.clamp((y + h - f.j[21]) / cb, 6f, 24f);
                Art.solve(f);
            }
        }
        // no pose parameter may jump further than a human limb could in one frame, except inside the blade's strike sweep
        if (!strike) {
            boolean changed = false;
            for (int i = 0; i < NP; i++) {
                final float lim = i == 8 ? 0.3f : i >= P_HIP ? 3f : i == P_PLANT ? 0.6f : i == 6 || i == 7 ? 0.9f : 1.2f;
                final float d = cur[i] - prevCur[i];
                if (d > lim) { cur[i] = prevCur[i] + lim; changed = true; }
                else if (d < -lim) { cur[i] = prevCur[i] - lim; changed = true; }
            }
            if (changed) applyPose(f);
        }
        System.arraycopy(cur, 0, prevCur, 0, NP);
    }

    /** Writes the current pose vector into the figure (planted feet by IK) and solves its joints. */
    private void applyPose(Art.Fig f) {
        Art.hero(f, edge);
        f.x = cx();
        f.y = y + h;
        f.s = 1f;
        f.dir = facing;
        f.t = t;
        f.vx = vx;
        f.vy = vy;
        f.lean = cur[0];
        f.legF = cur[1];
        f.kneeF = cur[2];
        f.legB = cur[3];
        f.kneeB = cur[4];
        // planted stance: while standing on something, both feet are placed by IK so neither one hovers
        final float pw = Body.clamp(cur[P_PLANT], 0f, 1f) * groundW;
        if (pw > 0.001f) {
            ikLeg(cur[P_HIP], cur[P_FF], ik);
            f.legF += (ik[0] - f.legF) * pw;
            f.kneeF += (ik[1] - f.kneeF) * pw;
            ikLeg(cur[P_HIP], cur[P_FB], ik);
            f.legB += (ik[0] - f.legB) * pw;
            f.kneeB += (ik[1] - f.kneeB) * pw;
        }
        f.armB = cur[5];
        f.swordAng = cur[6];
        f.wrist = cur[7];
        f.reach = cur[8];
        f.rot = flipT > 0f ? eio(1f - flipT / FLIP_T) * 2f * (float) Math.PI * facing : 0f;
        Art.solve(f);
    }

    /** Pose while a move is playing: keyframed wind-up, strike and follow-through, then handed back to locomotion. */
    private void attackPose(float dt) {
        final int m = atk;
        final float fr = atkT / FRAME;
        final float[][] kf = KEY[m];
        final int st = ST[m];
        final int ac = plunging ? 3 : AC[m];
        final float[] a = kf[0], b = kf[1], c = kf[2];
        // a long wind-up (the finisher, the plunge) keeps coiling while it holds: lean back, blade back, hips sink
        final float creep = st >= 6 ? Body.clamp((fr / st - 0.4f) / 0.6f, 0f, 1f) : 0f;
        if (fr < st) {
            final float u = sw(fr / st), up = sw(Math.min(1f, fr / (st * 0.5f)));
            for (int i = 0; i < NP; i++) cur[i] = from[i] + (a[i] - from[i]) * (i == P_PLANT ? up : u);
            cur[0] -= 0.07f * creep;
            cur[6] += 0.25f * creep;
            cur[P_HIP] -= 0.7f * creep * cur[P_PLANT];
        } else if (fr < st + ac) {
            final float u = sw((fr - st) / ac);
            for (int i = 0; i < NP; i++) cur[i] = a[i] + (b[i] - a[i]) * u;
            if (st >= 6) {      // the coil unwinds into the strike instead of snapping back
                final float rel = Math.max(0f, 1f - u * 5f);
                cur[0] -= 0.07f * rel;
                cur[6] += 0.25f * rel;
                cur[P_HIP] -= 0.7f * rel * cur[P_PLANT];
            }
        } else {
            final float rc = RC[m];
            final float u = (fr - st - AC[m]) / rc;
            if (u < 0.35f) {
                final float v = sw(u / 0.35f);
                final float[] start = landBlend ? from : b;
                for (int i = 0; i < NP; i++) cur[i] = start[i] + (c[i] - start[i]) * v;
            } else {
                final float kk = 1f - (float) Math.exp(-9f * dt);
                for (int i = 0; i < NP; i++) cur[i] += (tgt[i] - cur[i]) * kk;
            }
        }
    }

    // ------------------------------------------------------------------ afterimages

    private void ghosts(float dt) {
        if (dodgeT > 0f) {
            ghostAcc += Math.abs(vx) * dt;
            if (ghostAcc >= 30f) {
                ghostAcc -= 30f;
                addGhost(0xFF58E0FF, 130);
            }
        } else if (flipT > FLIP_T * 0.3f) {
            ghostAcc += Math.abs(vy) * dt;
            if (ghostAcc >= 30f) {
                ghostAcc -= 30f;
                addGhost(0xFF9AF0FF, 95);
            }
        } else {
            ghostAcc = 0f;
        }
    }

    private void addGhost(int col, int alpha) {
        System.arraycopy(fig.j, 0, gj[gi], 0, 26);
        ga[gi] = GHOST_LIFE;
        gl[gi] = GHOST_LIFE;
        gaa[gi] = alpha;
        gr[gi] = fig.rot;
        gc[gi] = col;
        gi = (gi + 1) % GN;
    }

    // ================================================================== draw

    /** Draws the hero between last step's position and this step's (alpha 0..1) so motion stays smooth on any display rate. */
    void draw(Canvas c, float alpha) {
        if (!hasPrev || alpha >= 1f) {
            draw(c);
            return;
        }
        final float ox = x, oy = y, fx0 = fig.x, fy0 = fig.y;
        x = this.px + (ox - this.px) * alpha;
        y = this.py + (oy - this.py) * alpha;
        fig.x = fx0 + (x - ox);
        fig.y = fy0 + (y - oy);
        draw(c);
        x = ox;
        y = oy;
        fig.x = fx0;
        fig.y = fy0;
    }

    void draw(Canvas c) {
        for (int i = 0; i < GN; i++) {
            if (ga[i] <= 0f) continue;
            Art.ghost(c, gj[i], 1f, gr[i], gc[i], (int) (gaa[i] * ga[i] / gl[i]));
        }
        if (dead) return;
        final float boost = dodgeT > 0f ? 0.35f : 0f;
        Art.glow(c, Art.GLOW_CYAN, cx(), y + h * 0.5f, 56f + 16f * boost / 0.35f * (dodgeT > 0f ? 1f : 0f), 0.5f + boost);
        fig.alpha = (flickerT > 0f && ((int) (t * 24f) & 1) == 0) ? 110 : 255;
        fig.flash = hurtT > 0f ? 1f : 0f;
        Art.draw(c, fig);
    }
}
