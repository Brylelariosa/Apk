// Mutation fuzzer: feeds damaged versions of the presets (plus raw garbage) to the engine.
// Every outcome except a crash/sanitizer report is acceptable. Build with
//   g++ -std=c++17 -O1 -g -fsanitize=address,undefined -I app/src/main/cpp tools/fuzz_test.cpp <engine .cpp files>
#include <dirent.h>

#include <cctype>
#include <cstdio>
#include <utility>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include "engine/engine.h"

int main(int argc, char** argv) {
  const std::string dir = argc > 1 ? argv[1] : "app/src/main/assets/presets";
  const int rounds = argc > 2 ? std::atoi(argv[2]) : 300;
  std::vector<std::string> seeds;
  if (DIR* d = opendir(dir.c_str())) {
    while (dirent* e = readdir(d)) {
      const std::string n = e->d_name;
      if (n.size() > 4 && n.substr(n.size() - 4) == ".cws") {
        std::ifstream f(dir + "/" + n);
        std::stringstream ss;
        ss << f.rdbuf();
        seeds.push_back(ss.str());
      }
    }
    closedir(d);
  }
  if (seeds.empty()) return 2;
  cw::Rng rng(12345);
  cw::Engine engine;
  cw::GenerateSettings gs;
  gs.sampleRate = 22050;
  int ok = 0, scriptErr = 0, other = 0;
  const char junk[] = "();,.=-+*/ \n\t0123456789abcdefABCDEF#\"'{}[]_ e";
  for (int r = 0; r < rounds; ++r) {
    std::string s = seeds[rng.next() % seeds.size()];
    const int edits = 1 + (int)(rng.next() % 6);
    for (int k = 0; k < edits && !s.empty(); ++k) {
      const size_t pos = rng.next() % s.size();
      switch (rng.next() % 5) {
        case 0: s.erase(pos, 1 + rng.next() % 8); break;
        case 1: s.insert(pos, 1, junk[rng.next() % (sizeof(junk) - 1)]); break;
        case 2: s[pos] = junk[rng.next() % (sizeof(junk) - 1)]; break;
        case 3: s.insert(pos, std::to_string((int)(rng.next() % 100000) - 500)); break;
        default: s.resize(pos); break;
      }
    }
    if (r % 2 == 1) {  // numeric mode: keep the syntax valid, push one value to an extreme
      std::string t = seeds[rng.next() % seeds.size()];
      static const char* kExtreme[] = {"0", "0.0001", "1", "19999", "20000", "0.01", "30", "128", "0.999", "-1", "24", "96", "3.3"};
      for (int k = 0; k < 3; ++k) {
        std::vector<std::pair<size_t, size_t>> nums;
        for (size_t i = 0; i < t.size();) {
          if (isdigit((unsigned char)t[i]) && (i == 0 || !isalpha((unsigned char)t[i - 1]))) {
            size_t j = i;
            while (j < t.size() && (isdigit((unsigned char)t[j]) || t[j] == '.')) ++j;
            nums.push_back({i, j - i});
            i = j;
          } else {
            ++i;
          }
        }
        if (nums.empty()) break;
        const auto n = nums[rng.next() % nums.size()];
        t.replace(n.first, n.second, kExtreme[rng.next() % (sizeof(kExtreme) / sizeof(kExtreme[0]))]);
      }
      s = t;
    }
    if (r % 50 == 0) {  // raw binary garbage
      s.clear();
      for (int i = 0; i < 400; ++i) s.push_back((char)(rng.next() & 0xFF));
    }
    gs.channels = (r & 1) ? 1 : 2;
    const cw::GenStatus st = engine.generate(s, gs, nullptr);
    if (st == cw::GenStatus::Ok) ++ok; else if (st == cw::GenStatus::ScriptError) ++scriptErr; else ++other;
  }
  std::printf("rounds=%d ok=%d scriptError=%d other=%d\n", rounds, ok, scriptErr, other);
  return 0;
}
