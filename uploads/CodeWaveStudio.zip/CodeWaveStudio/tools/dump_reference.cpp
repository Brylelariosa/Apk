// Prints the command list of the language reference straight from the command table, so the
// in-app reference can never drift from what the parser accepts.
//   g++ -std=c++17 -I app/src/main/cpp tools/dump_reference.cpp app/src/main/cpp/parser/commands.cpp -o dumpref
#include <cstdio>
#include <string>

#include "parser/commands.h"

int main() {
  using namespace cw;
  struct Group {
    Cat cat;
    const char* title;
  };
  const Group groups[] = {
      {Cat::Structure, "STRUCTURE"},
      {Cat::Source, "SOURCES  (create sound)"},
      {Cat::Modifier, "MODIFIERS  (change the oscillator written just before)"},
      {Cat::Processor, "PROCESSORS  (act on everything in the current layer, in order)"},
  };
  for (const Group& g : groups) {
    std::printf("%s\n", g.title);
    std::string lastNs;
    for (const CommandSpec& c : commandTable()) {
      if (c.cat != g.cat) continue;
      if (g.cat == Cat::Processor && lastNs != c.ns && !lastNs.empty()) std::printf("\n");
      lastNs = c.ns;
      std::printf("  %s\n", usageOf(c).c_str());
    }
    std::printf("\n");
  }
  return 0;
}
