#!/bin/sh
# Builds the native engine for the host machine and renders every preset (no Android SDK needed).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
OUT="${TMPDIR:-/tmp}/cwtest_out"
mkdir -p "$OUT"
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" "$ROOT/tools/desktop_test.cpp" \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/cwtest"
for f in "$ROOT"/app/src/main/assets/presets/*.cws; do
  printf '%-28s ' "$(basename "$f")"
  "$OUT/cwtest" "$f" "$OUT/$(basename "$f" .cws).wav"
done
