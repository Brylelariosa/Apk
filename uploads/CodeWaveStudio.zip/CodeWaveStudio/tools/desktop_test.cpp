// Desktop harness for the CodeWave engine: renders .cws scripts to WAV and prints stats.
//   g++ -std=c++17 -O2 -I app/src/main/cpp tools/desktop_test.cpp <engine .cpp files> -o cwtest
//   ./cwtest script.cws out.wav [sampleRate] [channels]
// See tools/build_and_test.sh.
#include <fcntl.h>
#include <unistd.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>

#include "audio/audio_io.h"
#include "engine/engine.h"

int main(int argc, char** argv) {
  if (argc < 2) {
    std::fprintf(stderr, "usage: %s script.cws [out.wav] [sampleRate] [channels]\n", argv[0]);
    return 2;
  }
  std::ifstream in(argv[1], std::ios::binary);
  if (!in) {
    std::fprintf(stderr, "cannot open %s\n", argv[1]);
    return 2;
  }
  std::stringstream ss;
  ss << in.rdbuf();

  cw::GenerateSettings gs;
  if (argc > 3) gs.sampleRate = std::atoi(argv[3]);
  if (argc > 4) gs.channels = std::atoi(argv[4]);

  cw::Engine engine;
  const cw::GenStatus st = engine.generate(ss.str(), gs, nullptr);
  if (st != cw::GenStatus::Ok) {
    std::printf("FAILED status=%d line=%d\n%s\n", (int)st, engine.lastErrorLine(), engine.lastError().c_str());
    return 1;
  }
  auto snd = engine.sound();
  double sum = 0.0, peak = 0.0;
  long n = 0;
  for (int c = 0; c < snd->channels; ++c) {
    for (int i = 0; i < snd->frames; ++i) {
      const double v = snd->ch[c][(size_t)i];
      if (!std::isfinite(v)) {
        std::printf("NON-FINITE sample at %d ch %d\n", i, c);
        return 1;
      }
      sum += v * v;
      peak = std::max(peak, std::fabs(v));
      ++n;
    }
  }
  std::printf("OK frames=%d ch=%d sr=%d peak=%.3f rms=%.3f ms=%d warn=[%s]\n", snd->frames, snd->channels,
              snd->sampleRate, peak, std::sqrt(sum / (double)std::max(1L, n)), engine.lastRenderMillis(),
              engine.lastWarnings().c_str());
  if (argc > 2) {
    const int fd = ::open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0 || cw::writeWav(*snd, fd, argc > 5 ? std::atoi(argv[5]) : 16) != 0) {
      std::fprintf(stderr, "wav write failed\n");
      return 1;
    }
    ::close(fd);
  }
  return 0;
}
