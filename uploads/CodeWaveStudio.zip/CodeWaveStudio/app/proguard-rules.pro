# --- JNI -------------------------------------------------------------------------------
# The C++ side finds these Java members by exact name and signature, so R8 must neither
# rename nor remove them.
-keep class com.codewave.studio.engine.NativeBridge { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Called back from native code (ProgressListener.onProgress(float)).
-keep interface com.codewave.studio.engine.ProgressListener { *; }
-keepclassmembers class * implements com.codewave.studio.engine.ProgressListener {
    public void onProgress(float);
}

# Keep line numbers for readable crash reports; hide the original file names.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
