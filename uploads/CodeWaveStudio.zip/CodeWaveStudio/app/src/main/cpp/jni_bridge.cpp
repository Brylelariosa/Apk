// JNI bridge for com.codewave.studio.engine.NativeBridge.
// No C++ exception ever crosses this boundary and nothing here lets script text reach
// anything but the audio engine.
#include <jni.h>

#include <new>

#include <chrono>
#include <functional>
#include <string>

#include "audio/audio_io.h"
#include "engine/engine.h"

namespace {

using cw::Engine;

inline Engine* eng(jlong h) { return reinterpret_cast<Engine*>(h); }

// Calls ProgressListener.onProgress(float), throttled to ~16 updates per second.
class JniProgress {
 public:
  JniProgress(JNIEnv* env, jobject listener) : env_(env), listener_(listener), last_(std::chrono::steady_clock::now()) {
    if (listener_) {
      jclass cls = env_->FindClass("com/codewave/studio/engine/ProgressListener");
      if (cls) {
        mid_ = env_->GetMethodID(cls, "onProgress", "(F)V");
        env_->DeleteLocalRef(cls);
      }
      if (env_->ExceptionCheck()) env_->ExceptionClear();
    }
  }
  void operator()(float f) {
    if (!listener_ || !mid_) return;
    const auto now = std::chrono::steady_clock::now();
    if (f < 1.0f && now - last_ < std::chrono::milliseconds(60)) return;
    last_ = now;
    env_->CallVoidMethod(listener_, mid_, (jfloat)f);
    if (env_->ExceptionCheck()) env_->ExceptionClear();
  }

 private:
  JNIEnv* env_;
  jobject listener_;
  jmethodID mid_ = nullptr;
  std::chrono::steady_clock::time_point last_;
};

jstring toJString(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL Java_com_codewave_studio_engine_NativeBridge_create(JNIEnv*, jclass) {
  try {
    return reinterpret_cast<jlong>(new Engine());
  } catch (...) {
    return 0;
  }
}

JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_destroy(JNIEnv*, jclass, jlong h) {
  delete eng(h);
}

JNIEXPORT void JNICALL Java_com_codewave_studio_engine_NativeBridge_cancel(JNIEnv*, jclass, jlong h) {
  if (h) eng(h)->cancel();
}

// Returns a cw::GenStatus value (0 ok, 1 script error, 2 out of memory, 3 cancelled, 4 internal).
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_generate(JNIEnv* env, jclass, jlong h,
                                                                             jstring script, jint sampleRate,
                                                                             jint channels, jfloat defaultDuration,
                                                                             jobject listener) {
  if (!h || !script) return (jint)cw::GenStatus::Internal;
  std::string text;
  try {
    const jsize len = env->GetStringUTFLength(script);
    const char* utf = env->GetStringUTFChars(script, nullptr);
    if (!utf) return (jint)cw::GenStatus::OutOfMemory;
    text.assign(utf, (size_t)len);
    env->ReleaseStringUTFChars(script, utf);

    cw::GenerateSettings gs;
    gs.sampleRate = (sampleRate == 22050 || sampleRate == 48000) ? sampleRate : 44100;
    gs.channels = channels == 1 ? 1 : 2;
    gs.defaultDuration = cw::clampd((double)defaultDuration, cw::limits::kMinDurationSec, cw::limits::kMaxDurationSec);

    JniProgress progress(env, listener);
    return (jint)eng(h)->generate(text, gs, [&progress](float f) { progress(f); });
  } catch (const std::bad_alloc&) {
    return (jint)cw::GenStatus::OutOfMemory;
  } catch (...) {
    return (jint)cw::GenStatus::Internal;
  }
}

JNIEXPORT jstring JNICALL Java_com_codewave_studio_engine_NativeBridge_lastError(JNIEnv* env, jclass, jlong h) {
  return toJString(env, h ? eng(h)->lastError() : std::string());
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_lastErrorLine(JNIEnv*, jclass, jlong h) {
  return h ? eng(h)->lastErrorLine() : 0;
}
JNIEXPORT jstring JNICALL Java_com_codewave_studio_engine_NativeBridge_lastWarnings(JNIEnv* env, jclass, jlong h) {
  return toJString(env, h ? eng(h)->lastWarnings() : std::string());
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_renderMillis(JNIEnv*, jclass, jlong h) {
  return h ? eng(h)->lastRenderMillis() : 0;
}

JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_frameCount(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->frames : 0;
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_channelCount(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->channels : 0;
}
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_sampleRate(JNIEnv*, jclass, jlong h) {
  const auto s = h ? eng(h)->sound() : nullptr;
  return s ? s->sampleRate : 0;
}

// Fills dst with interleaved 16-bit PCM. Returns the number of frames copied.
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_copyPcm16(JNIEnv* env, jclass, jlong h,
                                                                              jshortArray dst, jint startFrame,
                                                                              jint frames) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s || !dst) return 0;
  const int capacityFrames = (int)env->GetArrayLength(dst) / s->channels;
  const int n = frames < capacityFrames ? frames : capacityFrames;
  jshort* p = static_cast<jshort*>(env->GetPrimitiveArrayCritical(dst, nullptr));
  if (!p) return 0;
  const int copied = cw::copyPcm16(*s, reinterpret_cast<int16_t*>(p), startFrame, n);
  env->ReleasePrimitiveArrayCritical(dst, p, 0);
  return copied;
}

JNIEXPORT jboolean JNICALL Java_com_codewave_studio_engine_NativeBridge_peaks(JNIEnv* env, jclass, jlong h,
                                                                              jint columns, jfloatArray out) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s || !out || columns < 1 || env->GetArrayLength(out) < 2 * columns) return JNI_FALSE;
  jfloat* p = env->GetFloatArrayElements(out, nullptr);
  if (!p) return JNI_FALSE;
  cw::computePeaks(*s, columns, p);
  env->ReleaseFloatArrayElements(out, p, 0);
  return JNI_TRUE;
}

// Writes a WAV to an open file descriptor (owned and closed by the caller). 0 = success, else errno.
JNIEXPORT jint JNICALL Java_com_codewave_studio_engine_NativeBridge_writeWav(JNIEnv*, jclass, jlong h, jint fd,
                                                                             jint bits) {
  const auto s = h ? eng(h)->sound() : nullptr;
  if (!s) return -1;
  try {
    return cw::writeWav(*s, fd, bits == 32 ? 32 : 16);
  } catch (...) {
    return -2;
  }
}

}  // extern "C"
