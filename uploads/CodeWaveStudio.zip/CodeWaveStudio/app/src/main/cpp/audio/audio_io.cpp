#include "audio_io.h"

#include <cerrno>
#include <cmath>
#include <cstring>
#include <vector>

#include <unistd.h>

namespace cw {
namespace {

inline int16_t toS16(float x) {
  long v = std::lrintf(x * 32767.0f);
  if (v > 32767) v = 32767;
  if (v < -32768) v = -32768;
  return (int16_t)v;
}

void put16(std::vector<uint8_t>& v, uint32_t x) {
  v.push_back((uint8_t)(x & 0xFF));
  v.push_back((uint8_t)((x >> 8) & 0xFF));
}
void put32(std::vector<uint8_t>& v, uint32_t x) {
  put16(v, x & 0xFFFF);
  put16(v, (x >> 16) & 0xFFFF);
}
void putTag(std::vector<uint8_t>& v, const char* tag) { v.insert(v.end(), tag, tag + 4); }

int writeAll(int fd, const uint8_t* data, size_t len) {
  while (len > 0) {
    const ssize_t w = ::write(fd, data, len);
    if (w < 0) {
      if (errno == EINTR) continue;
      return errno ? errno : EIO;
    }
    if (w == 0) return EIO;
    data += (size_t)w;
    len -= (size_t)w;
  }
  return 0;
}

}  // namespace

int copyPcm16(const Sound& s, int16_t* dst, int startFrame, int frames) {
  if (startFrame < 0 || startFrame >= s.frames || frames <= 0) return 0;
  const int n = std::min(frames, s.frames - startFrame);
  if (s.channels == 1) {
    const float* a = s.ch[0].data() + startFrame;
    for (int i = 0; i < n; ++i) dst[i] = toS16(a[i]);
  } else {
    const float* l = s.ch[0].data() + startFrame;
    const float* r = s.ch[1].data() + startFrame;
    for (int i = 0; i < n; ++i) {
      dst[2 * i] = toS16(l[i]);
      dst[2 * i + 1] = toS16(r[i]);
    }
  }
  return n;
}

void computePeaks(const Sound& s, int columns, float* out) {
  if (columns < 1) return;
  for (int c = 0; c < columns; ++c) {
    long long i0 = (long long)c * s.frames / columns;
    long long i1 = (long long)(c + 1) * s.frames / columns;
    if (i1 <= i0) i1 = std::min<long long>(s.frames, i0 + 1);
    float mn = 0.0f, mx = 0.0f;
    for (int ch = 0; ch < s.channels; ++ch) {
      const float* x = s.ch[ch].data();
      for (long long i = i0; i < i1 && i < s.frames; ++i) {
        mn = std::min(mn, x[i]);
        mx = std::max(mx, x[i]);
      }
    }
    out[2 * c] = mn;
    out[2 * c + 1] = mx;
  }
}

int writeWav(const Sound& s, int fd, int bits) {
  const bool isFloat = bits == 32;
  const uint32_t ch = (uint32_t)s.channels;
  const uint32_t bytesPer = isFloat ? 4u : 2u;
  const uint64_t dataBytes = (uint64_t)s.frames * ch * bytesPer;
  if (dataBytes > 0xFFFFF000ull) return EFBIG;

  std::vector<uint8_t> h;
  h.reserve(64);
  const uint32_t fmtSize = isFloat ? 18u : 16u;
  const uint32_t factSize = isFloat ? 12u : 0u;
  putTag(h, "RIFF");
  put32(h, (uint32_t)(4 + 8 + fmtSize + factSize + 8 + dataBytes));
  putTag(h, "WAVE");
  putTag(h, "fmt ");
  put32(h, fmtSize);
  put16(h, isFloat ? 3 : 1);
  put16(h, ch);
  put32(h, (uint32_t)s.sampleRate);
  put32(h, (uint32_t)s.sampleRate * ch * bytesPer);
  put16(h, ch * bytesPer);
  put16(h, bytesPer * 8);
  if (isFloat) {
    put16(h, 0);  // cbSize
    putTag(h, "fact");
    put32(h, 4);
    put32(h, (uint32_t)s.frames);
  }
  putTag(h, "data");
  put32(h, (uint32_t)dataBytes);
  int err = writeAll(fd, h.data(), h.size());
  if (err) return err;

  const int kChunk = 8192;
  std::vector<uint8_t> buf((size_t)kChunk * ch * bytesPer);
  for (int f0 = 0; f0 < s.frames; f0 += kChunk) {
    const int n = std::min(kChunk, s.frames - f0);
    uint8_t* p = buf.data();
    for (int i = 0; i < n; ++i) {
      for (uint32_t c = 0; c < ch; ++c) {
        const float x = s.ch[c][(size_t)(f0 + i)];
        if (isFloat) {
          std::memcpy(p, &x, 4);
          p += 4;
        } else {
          const int16_t v = toS16(x);
          p[0] = (uint8_t)(v & 0xFF);
          p[1] = (uint8_t)((v >> 8) & 0xFF);
          p += 2;
        }
      }
    }
    err = writeAll(fd, buf.data(), (size_t)n * ch * bytesPer);
    if (err) return err;
  }
  return 0;
}

}  // namespace cw
