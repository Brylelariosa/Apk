#pragma once

#include <cstdint>

#include "../dsp/audio_buf.h"

namespace cw {

// Interleaved, clipped 16-bit PCM for AudioTrack. Returns the number of frames written.
int copyPcm16(const Sound& s, int16_t* dst, int startFrame, int frames);

// Min/max per column over all channels: out[2*i] = min, out[2*i+1] = max. `columns` >= 1.
void computePeaks(const Sound& s, int columns, float* out);

// Writes a complete RIFF/WAVE file to a file descriptor (works for pipes too: no seeking).
// bits = 16 (PCM) or 32 (IEEE float). Returns 0 on success, otherwise an errno value.
int writeWav(const Sound& s, int fd, int bits);

}  // namespace cw
