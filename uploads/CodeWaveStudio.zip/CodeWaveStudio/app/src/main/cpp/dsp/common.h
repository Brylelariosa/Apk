// CodeWave Studio - shared engine types.
// Everything an untrusted script can influence is bounded by the limits below.
#pragma once

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <string>

namespace cw {

constexpr double kPi = 3.14159265358979323846;
constexpr double kTwoPi = 2.0 * kPi;

namespace limits {
constexpr double kMaxDurationSec = 30.0;
constexpr double kMinDurationSec = 0.01;
constexpr size_t kMaxScriptBytes = 128 * 1024;
constexpr int kMaxCommands = 2000;
constexpr int kMaxLayerDepth = 4;
constexpr int kMaxRepeatCount = 128;
constexpr int kMaxLayerInstances = 1024;
constexpr int kMaxPendingSources = 16;
constexpr int kMaxSourcesTotal = 2048;
constexpr int kMaxProcessorsPerLayer = 64;
constexpr size_t kMemoryBudgetBytes = 96u * 1024u * 1024u;
constexpr double kWorkBudget = 4.0e9;  // abstract "frame operations"
}  // namespace limits

enum class ErrorKind { Script, Limit, Memory };

// Thrown for anything the user can fix by editing the script (or by asking for less).
struct EngineError : public std::runtime_error {
  ErrorKind kind;
  int line;          // 1-based script line, 0 when not tied to a line
  std::string hint;  // extra lines, e.g. "Expected:\nsine\nsquare"

  EngineError(ErrorKind k, int ln, const std::string& msg, const std::string& h = std::string())
      : std::runtime_error(msg), kind(k), line(ln), hint(h) {}

  std::string format() const {
    std::string s;
    if (line > 0) s += "Line " + std::to_string(line) + ":\n";
    s += what();
    if (!hint.empty()) {
      s += "\n\n";
      s += hint;
    }
    return s;
  }
};

struct Cancelled {};

// xorshift32: tiny, fast and fully deterministic (same script => same sound).
struct Rng {
  uint32_t s;
  explicit Rng(uint32_t seed = 1u) : s(seed ? seed : 0x9E3779B9u) {
    for (int i = 0; i < 4; ++i) next();
  }
  uint32_t next() {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
  }
  float uni() { return (next() >> 8) * (1.0f / 16777216.0f); }  // [0,1)
  float bi() { return uni() * 2.0f - 1.0f; }                    // [-1,1)
};

inline double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double lerpd(double a, double b, double t) { return a + (b - a) * t; }
inline double dbToLin(double db) { return std::pow(10.0, db / 20.0); }
inline float undenorm(float v) { return std::fabs(v) < 1e-18f ? 0.0f : v; }
inline int toFrames(double seconds, int sr) { return (int)std::lround(seconds * (double)sr); }

// Per-generation context: sample rate, deterministic RNG, memory + work budgets
// and cooperative cancellation. Not thread-safe (one render per context).
class RenderCtx {
 public:
  const int sr;
  Rng rng;

  RenderCtx(int sampleRate, uint32_t seed, const std::atomic<bool>* cancelFlag,
            size_t memLimit = limits::kMemoryBudgetBytes, double workLimit = limits::kWorkBudget)
      : sr(sampleRate), rng(seed), cancel_(cancelFlag), memLimit_(memLimit), workLimit_(workLimit) {}

  void allocate(size_t bytes) {
    if (memUsed_ + bytes > memLimit_) {
      throw EngineError(ErrorKind::Memory, 0,
                        "This sound needs more memory than the safety budget allows.",
                        "Use a shorter duration, fewer nested layers, or a lower sample rate.");
    }
    memUsed_ += bytes;
  }
  void release(size_t bytes) { memUsed_ = bytes > memUsed_ ? 0 : memUsed_ - bytes; }

  // Charge `units` of work (about one unit per processed sample); also polls cancellation.
  void spend(double units) {
    work_ += units;
    if (work_ > workLimit_) {
      throw EngineError(ErrorKind::Limit, 0, "This script is too expensive to render.",
                        "Reduce the duration, the number of layers/repeats, or heavy effects "
                        "(reverb, vocoder, pitch/time stretch).");
    }
    check();
  }
  void check() const {
    if (cancel_ && cancel_->load(std::memory_order_relaxed)) throw Cancelled();
  }

 private:
  const std::atomic<bool>* cancel_;
  size_t memLimit_;
  double workLimit_;
  size_t memUsed_ = 0;
  double work_ = 0;
};

}  // namespace cw
