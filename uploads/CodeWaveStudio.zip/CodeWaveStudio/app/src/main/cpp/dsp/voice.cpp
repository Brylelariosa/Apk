// Voice section: convincing *synthetic* human / robot effects (not real speech synthesis).
#include "dsp.h"

namespace cw {
namespace {

struct Vowel {
  float f[3];   // formant centre frequencies (Hz)
  float bw[3];  // bandwidths (Hz)
  float g[3];   // relative gains
  float norm;   // loudness compensation for the human source
};

// a e i o u uh  (classic adult-male formant values)
const Vowel kVowels[kVowelCount] = {
    {{730, 1090, 2440}, {90, 110, 140}, {1.0f, 0.50f, 0.30f}, 4.6f},
    {{530, 1840, 2480}, {80, 110, 140}, {1.0f, 0.45f, 0.30f}, 3.7f},
    {{270, 2290, 3010}, {60, 120, 150}, {1.0f, 0.30f, 0.20f}, 2.5f},
    {{570, 840, 2410}, {80, 90, 140}, {1.0f, 0.50f, 0.25f}, 3.9f},
    {{300, 870, 2240}, {60, 90, 140}, {1.0f, 0.35f, 0.20f}, 3.5f},
    {{520, 1190, 2390}, {90, 110, 140}, {1.0f, 0.50f, 0.30f}, 4.2f},
};

constexpr double kHumanGain = 0.55;  // with the per-vowel 'norm', volume = 1 gives a peak of about 0.6

// Three parallel resonators, optionally morphing between two vowels.
class FormantBank {
 public:
  explicit FormantBank(int sr) : sr_(sr) {}
  void set(int a, int b, double t, double size, double sharp) {
    const Vowel& va = kVowels[a];
    for (int k = 0; k < 3; ++k) {
      double f = va.f[k], bw = va.bw[k], g = va.g[k];
      if (b >= 0) {
        const Vowel& vb = kVowels[b];
        f = f * std::pow((double)vb.f[k] / f, t);
        bw = lerpd(bw, vb.bw[k], t);
        g = lerpd(g, vb.g[k], t);
      }
      f = clampd(f * size, 60.0, sr_ * 0.45);
      const double q = clampd(f / (bw * size / std::max(0.1, sharp)), 0.5, 40.0);
      coef_[k] = designBiquad(FilterType::Band, f, q, sr_);
      gain_[k] = g;
    }
  }
  float process(float x) {
    double y = 0.0;
    for (int k = 0; k < 3; ++k) y += gain_[k] * biquadTick(coef_[k], st_[k], x);
    return (float)y;
  }

 private:
  int sr_;
  BiquadCoef coef_[3] = {};
  BiquadState st_[3];
  double gain_[3] = {0, 0, 0};
};

double rmsOf(const float* x, int n) {
  double s = 0.0;
  for (int i = 0; i < n; ++i) s += (double)x[i] * x[i];
  return n > 0 ? std::sqrt(s / n) : 0.0;
}

// x = dry*(1-mix) + wet*mix, with wet scaled to the dry loudness.
void blendMatched(float* x, const float* wet, int n, double mix) {
  const double rin = rmsOf(x, n), rw = rmsOf(wet, n);
  const double scale = rw > 1e-9 ? std::min(40.0, rin / rw) : 0.0;
  const float w = (float)mix, s = (float)scale;
  for (int i = 0; i < n; ++i) x[i] = x[i] * (1.0f - w) + wet[i] * s * w;
}

struct FracComb {
  std::vector<float> line;
  int w = 0;
  double d = 2.0;
  float fb = 0.0f;
  void init(double delay, float feedback) {
    d = std::max(2.0, delay);
    fb = feedback;
    line.assign((size_t)d + 4, 0.0f);
    w = 0;
  }
  float tick(float x) {
    const int size = (int)line.size();
    double pos = (double)w - d;
    if (pos < 0.0) pos += size;
    const int i0 = (int)pos;
    const float fr = (float)(pos - i0);
    const int i1 = i0 + 1 >= size ? 0 : i0 + 1;
    const float del = line[(size_t)i0] * (1.0f - fr) + line[(size_t)i1] * fr;
    const float y = x + fb * del;
    line[(size_t)w] = undenorm(y);
    if (++w >= size) w = 0;
    return y;
  }
};

}  // namespace

// Glottal-like saw -> tilt filter -> formants, with vibrato, jitter, shimmer and breath.
void renderHuman(const SourceParams& p, float* out, int n, double pitchMul, double gain, RenderCtx& cx) {
  const int sr = cx.sr;
  const double inv = 1.0 / sr;
  Rng rng(cx.rng.next());
  FreqTrack ft(p, pitchMul, sr);
  FormantBank bank(sr);
  const int kBlock = 32;
  const int jitInterval = std::max(1, sr / 100);
  const double lpA = 1.0 - std::exp(-kTwoPi * 3000.0 / sr);
  double phase = 0.0, vibPh = 0.0, lp = 0.0;
  double jit = 0.0, jitT = 0.0, shim = 1.0, shimT = 1.0;
  for (int i = 0; i < n; ++i) {
    if ((i & 16383) == 0) cx.check();
    if (i == 0 || (p.vowelB >= 0 && i % kBlock == 0)) {
      bank.set(p.vowelA, p.vowelB, p.vowelB >= 0 ? (double)i / (double)n : 0.0, p.size, 1.0);
    }
    if (i % jitInterval == 0) {
      jitT = rng.bi() * p.jitter;
      shimT = 1.0 + rng.bi() * p.shimmer;
    }
    jit += (jitT - jit) * 0.003;
    shim += (shimT - shim) * 0.003;
    double f = ft.next(i);
    const double onset = std::min(1.0, i * inv / 0.25);
    f *= std::exp2(p.vibVoice * onset * std::sin(vibPh) / 12.0) * (1.0 + jit);
    vibPh += kTwoPi * 5.5 * inv;
    f = clampd(f, 30.0, sr * 0.45);
    const double dt = f * inv;
    phase += dt;
    if (phase >= 1.0) phase -= 1.0;
    const double saw = 2.0 * phase - 1.0 - polyblep(phase, dt);
    lp += lpA * (saw - lp);
    const double src = lp + p.breath * 0.6 * rng.bi();
    const double tmix = p.vowelB >= 0 ? (double)i / (double)n : 0.0;
    const double norm = lerpd(kVowels[p.vowelA].norm, p.vowelB >= 0 ? kVowels[p.vowelB].norm : kVowels[p.vowelA].norm, tmix);
    out[i] += (float)(bank.process((float)src) * shim * gain * kHumanGain * norm);
  }
}

void applyFormant(AudioBuf& b, int vowelA, int vowelB, double sharpness, double mix, double size, RenderCtx& cx) {
  const int n = b.frames();
  cx.spend((double)n * b.channels() * 15.0);
  AudioBuf wet(cx, n, 1);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    float* w = wet.ch(0);
    FormantBank bank(cx.sr);
    const int kBlock = 32;
    for (int i = 0; i < n; ++i) {
      if (i == 0 || (vowelB >= 0 && i % kBlock == 0)) {
        bank.set(vowelA, vowelB, vowelB >= 0 ? (double)i / (double)n : 0.0, size, sharpness);
      }
      if ((i & 16383) == 0) cx.check();
      w[i] = bank.process(x[i]);
    }
    blendMatched(x, w, n, mix);
  }
}

// Channel vocoder: the buffer is the modulator, an internal synth is the carrier.
void applyVocoder(AudioBuf& b, int bands, double pitch, double mix, int carrier, RenderCtx& cx) {
  const int n = b.frames();
  const int sr = cx.sr;
  bands = bands < 4 ? 4 : (bands > 32 ? 32 : bands);
  cx.spend((double)n * b.channels() * (bands * 5.0 + 5.0));

  AudioBuf car(cx, n, 1);
  {
    float* cr = car.ch(0);
    if (carrier == 2) {
      Rng r(cx.rng.next());
      for (int i = 0; i < n; ++i) cr[i] = r.bi() * 0.5f;
    } else {
      const double dt = clampd(pitch, 20.0, sr * 0.4) / sr;
      double ph = 0.0;
      for (int i = 0; i < n; ++i) {
        float v;
        if (carrier == 1) {
          v = ph < 0.3 ? 1.0f : -1.0f;
          v += polyblep(ph, dt);
          double t2 = ph + 0.7;
          if (t2 >= 1.0) t2 -= 1.0;
          v -= polyblep(t2, dt);
        } else {
          v = (float)(2.0 * ph - 1.0) - polyblep(ph, dt);
        }
        cr[i] = v * 0.5f;
        ph += dt;
        if (ph >= 1.0) ph -= 1.0;
      }
    }
  }

  const double fmin = 110.0, fmax = std::min(7500.0, sr * 0.45);
  const double ratio = std::pow(fmax / fmin, 1.0 / (bands - 1));
  const double q = clampd(1.5 / (ratio - 1.0 / ratio), 1.5, 10.0);
  const double atk = std::exp(-1.0 / (0.004 * sr)), rel = std::exp(-1.0 / (0.025 * sr));
  AudioBuf wet(cx, n, 1);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    float* w = wet.ch(0);
    const float* cr = car.ch(0);
    std::fill(w, w + n, 0.0f);
    for (int k = 0; k < bands; ++k) {
      cx.check();
      const BiquadCoef co = designBiquad(FilterType::Band, fmin * std::pow(ratio, k), q, sr);
      BiquadState sm, sc;
      double env = 0.0;
      for (int i = 0; i < n; ++i) {
        const double a = std::fabs(biquadTick(co, sm, x[i]));
        env = a > env ? atk * env + (1.0 - atk) * a : rel * env + (1.0 - rel) * a;
        w[i] += (float)(biquadTick(co, sc, cr[i]) * env);
      }
    }
    blendMatched(x, w, n, mix);
  }
}

// Two inharmonic feedback combs: a ringing, metallic resonance.
void applyMetallic(AudioBuf& b, double freq, double amount, RenderCtx& cx) {
  const int n = b.frames();
  const double d1 = cx.sr / clampd(freq, 20.0, 8000.0);
  cx.spend((double)n * b.channels() * 10.0);
  AudioBuf wet(cx, n, 1);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    float* w = wet.ch(0);
    FracComb a, bb;
    a.init(d1, (float)(0.35 + 0.55 * amount));
    bb.init(d1 / 1.4142135, (float)(0.30 + 0.45 * amount));
    for (int i = 0; i < n; ++i) w[i] = 0.5f * (a.tick(x[i]) + bb.tick(x[i]));
    blendMatched(x, w, n, clampd(amount * 1.2, 0.0, 1.0));
  }
}

}  // namespace cw
