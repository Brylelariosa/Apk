#include "dsp.h"

namespace cw {
namespace {

// Tape-style resample: out[i] = in(i * ratio), linear interpolation. Reads past the end give silence.
AudioBuf resampleTape(const AudioBuf& in, double ratio, int outFrames, RenderCtx& cx) {
  AudioBuf out(cx, outFrames, in.channels());
  const int n = in.frames();
  cx.spend((double)outFrames * in.channels() * 5.0);
  for (int c = 0; c < in.channels(); ++c) {
    const float* s = in.ch(c);
    float* d = out.ch(c);
    for (int i = 0; i < outFrames; ++i) {
      const double pos = i * ratio;
      const int i0 = (int)pos;
      if (i0 >= n - 1) {
        if (i0 == n - 1) d[i] = s[n - 1];
        break;
      }
      const float fr = (float)(pos - i0);
      d[i] = s[i0] * (1.0f - fr) + s[i0 + 1] * fr;
    }
  }
  return out;
}

// Waveform-similarity overlap-add. factor > 1 lengthens, < 1 shortens; output has outFrames frames.
AudioBuf wsola(const AudioBuf& in, double factor, int outFrames, RenderCtx& cx) {
  const int sr = cx.sr;
  const int n = in.frames();
  int N = (int)(0.030 * sr);
  N += N & 1;
  N = std::max(N, 256);
  const int Hs = N / 2;
  const int radius = N / 4;
  const double Ha = Hs / factor;
  const int D = 4;

  const int nd = n / D;
  std::vector<float> guide((size_t)nd + 1, 0.0f);
  for (int j = 0; j < nd; ++j) {
    float s = 0.0f;
    for (int c = 0; c < in.channels(); ++c) {
      const float* x = in.ch(c) + (size_t)j * D;
      for (int k = 0; k < D; ++k) s += x[k];
    }
    guide[(size_t)j] = s / (float)(D * in.channels());
  }

  AudioBuf out(cx, outFrames, in.channels());
  std::vector<float> win((size_t)N);
  for (int k = 0; k < N; ++k) win[(size_t)k] = (float)(0.5 - 0.5 * std::cos(kTwoPi * k / N));

  const int len = N / D;
  const double frameCost = ((double)(2 * radius / D + 1) * len * 2.0 + (double)N * in.channels()) * 0.45;
  int prev = 0;
  for (int f = 0;; ++f) {
    const int outPos = f * Hs;
    if (outPos >= outFrames) break;
    cx.spend(frameCost);
    int pos = 0;
    if (f > 0) {
      const int ideal = (int)std::lround(f * Ha);
      const int lo = std::max(0, ideal - radius);
      const int hi = std::min(n - N, ideal + radius);
      if (hi < lo) {
        pos = std::max(0, std::min(ideal, std::max(0, n - N)));
      } else {
        const int target = prev + Hs;
        if (target + N > n) {
          pos = std::min(std::max(ideal, lo), hi);
        } else {
          int bestPos = lo;
          double best = -1e30;
          const int tD = target / D;
          for (int cand = lo; cand <= hi; cand += D) {
            const int cD = cand / D;
            double dot = 0.0, en = 0.0;
            for (int k = 0; k < len; ++k) {
              const float a = guide[(size_t)(cD + k)], g = guide[(size_t)(tD + k)];
              dot += (double)a * g;
              en += (double)a * a;
            }
            const double score = dot / std::sqrt(en + 1e-9);
            if (score > best) {
              best = score;
              bestPos = cand;
            }
          }
          pos = bestPos;
        }
      }
    }
    for (int c = 0; c < in.channels(); ++c) {
      const float* s = in.ch(c);
      float* d = out.ch(c);
      for (int k = 0; k < N; ++k) {
        const int oi = outPos + k;
        if (oi >= outFrames) break;
        const int ii = pos + k;
        const float v = ii < n ? s[ii] : 0.0f;
        const float w = (f == 0 && k < Hs) ? 1.0f : win[(size_t)k];  // no fade-in on the first frame
        d[oi] += v * w;
      }
    }
    prev = pos;
  }
  return out;
}

}  // namespace

float peakOf(const AudioBuf& b) {
  float pk = 0.0f;
  for (int c = 0; c < b.channels(); ++c) {
    const float* x = b.ch(c);
    for (int i = 0; i < b.frames(); ++i) pk = std::max(pk, std::fabs(x[i]));
  }
  return pk;
}

void applyNormalize(AudioBuf& b, double level, RenderCtx& cx) {
  cx.spend((double)b.frames() * b.channels() * 2.0);
  const float pk = peakOf(b);
  if (pk < 1e-9f) return;
  applyGain(b, level / pk);
}

void applyFade(AudioBuf& b, double fadeIn, double fadeOut, RenderCtx& cx) {
  const int n = b.frames();
  const int fi = std::min(n, toFrames(fadeIn, cx.sr));
  const int fo = std::min(n, toFrames(fadeOut, cx.sr));
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    for (int i = 0; i < fi; ++i) x[i] *= (float)i / (float)fi;
    for (int i = 0; i < fo; ++i) x[n - 1 - i] *= (float)i / (float)fo;
  }
}

void applyReverse(AudioBuf& b, RenderCtx& cx) {
  cx.spend((double)b.frames() * b.channels());
  for (int c = 0; c < b.channels(); ++c) std::reverse(b.ch(c), b.ch(c) + b.frames());
}

void applyGain(AudioBuf& b, double gain) {
  const float g = (float)gain;
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    for (int i = 0; i < b.frames(); ++i) x[i] *= g;
  }
}

void applyPan(AudioBuf& b, double pan) {
  if (pan == 0.0) return;
  b.makeStereo();
  const double ang = (clampd(pan, -1.0, 1.0) + 1.0) * kPi / 4.0;
  const float gl = (float)(std::cos(ang) * 1.41421356237), gr = (float)(std::sin(ang) * 1.41421356237);
  float* l = b.ch(0);
  float* r = b.ch(1);
  for (int i = 0; i < b.frames(); ++i) {
    l[i] *= gl;
    r[i] *= gr;
  }
}

void mixInto(AudioBuf& dst, const AudioBuf& src, int dstOffset, double gain, double pan) {
  const int len = std::min(src.frames(), dst.frames() - dstOffset);
  if (len <= 0 || !src.valid()) return;
  if (src.channels() > 1 || pan != 0.0) dst.makeStereo();
  const double ang = (clampd(pan, -1.0, 1.0) + 1.0) * kPi / 4.0;
  const float gl = (float)(gain * std::cos(ang) * 1.41421356237);
  const float gr = (float)(gain * std::sin(ang) * 1.41421356237);
  if (dst.channels() == 1) {
    float* d = dst.ch(0) + dstOffset;
    const float* s = src.ch(0);
    const float g = (float)gain;
    for (int i = 0; i < len; ++i) d[i] += s[i] * g;
  } else if (src.channels() == 1) {
    float* dl = dst.ch(0) + dstOffset;
    float* dr = dst.ch(1) + dstOffset;
    const float* s = src.ch(0);
    for (int i = 0; i < len; ++i) {
      dl[i] += s[i] * gl;
      dr[i] += s[i] * gr;
    }
  } else {
    float* dl = dst.ch(0) + dstOffset;
    float* dr = dst.ch(1) + dstOffset;
    const float* sl = src.ch(0);
    const float* sr = src.ch(1);
    for (int i = 0; i < len; ++i) {
      dl[i] += sl[i] * gl;
      dr[i] += sr[i] * gr;
    }
  }
}

void applyPitch(AudioBuf& b, double semitones, bool keepTime, RenderCtx& cx) {
  const int n = b.frames();
  if (std::fabs(semitones) < 1e-6 || n < 2) return;
  const double r = std::exp2(semitones / 12.0);
  if (!keepTime) {
    AudioBuf t = resampleTape(b, r, n, cx);
    b = std::move(t);
    return;
  }
  const int tapeLen = (int)std::min(std::ceil(n / r), 4.0 * n);
  AudioBuf tape = resampleTape(b, r, tapeLen, cx);
  AudioBuf out = wsola(tape, r, n, cx);
  b = std::move(out);
}

void applyStretch(AudioBuf& b, double factor, RenderCtx& cx) {
  const int n = b.frames();
  if (std::fabs(factor - 1.0) < 1e-6 || n < 2) return;
  AudioBuf out = wsola(b, factor, n, cx);
  b = std::move(out);
}

}  // namespace cw
