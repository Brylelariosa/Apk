#include "dsp.h"

namespace cw {
namespace {

inline double waveSample(Wave w, double ph, double dt, double width) {
  switch (w) {
    case Wave::Sine:
      return std::sin(kTwoPi * ph);
    case Wave::Saw:
      return 2.0 * ph - 1.0 - polyblep(ph, dt);
    case Wave::Square: {
      double v = ph < 0.5 ? 1.0 : -1.0;
      v += polyblep(ph, dt);
      double t2 = ph + 0.5;
      if (t2 >= 1.0) t2 -= 1.0;
      v -= polyblep(t2, dt);
      return v;
    }
    case Wave::Pulse: {
      double v = ph < width ? 1.0 : -1.0;
      v += polyblep(ph, dt);
      double t2 = ph + 1.0 - width;
      if (t2 >= 1.0) t2 -= 1.0;
      v -= polyblep(t2, dt);
      return v - (2.0 * width - 1.0);  // keep the pulse DC-free
    }
    case Wave::Triangle: {
      double t = ph + 0.75;
      if (t >= 1.0) t -= 1.0;
      return 4.0 * std::fabs(t - 0.5) - 1.0;
    }
    default:
      return 0.0;
  }
}

// Approximate nanoseconds per frame, used for the work budget.
double tonalCost(const SourceParams& p) {
  return 25.0 + (p.fm ? 30.0 : 0.0) + (p.vib ? 30.0 : 0.0) + (p.sweepF ? 30.0 : 0.0) + (p.sweepP ? 20.0 : 0.0) +
         (p.quant ? 50.0 : 0.0);
}

void renderTonal(const SourceParams& p, float* out, int n, double pitchMul, double gain, RenderCtx& cx) {
  const double inv = 1.0 / cx.sr;
  FreqTrack ft(p, pitchMul, cx.sr);
  const double idx0 = p.fmIndex;
  const double idx1 = p.fmIndexEnd < 0.0 ? p.fmIndex : p.fmIndexEnd;
  double phase = 0.0, fmPhase = 0.0;
  for (int i = 0; i < n; ++i) {
    if ((i & 16383) == 0) cx.check();
    const double f = ft.next(i);
    const double dt = f * inv;
    double ph = phase;
    if (p.fm) {
      const double idx = idx0 + (idx1 - idx0) * ((double)i / (double)n);
      ph += idx * std::sin(fmPhase) * (1.0 / kTwoPi);
      ph -= std::floor(ph);
      const double mf = p.fmRatio ? p.fmFreq * f : p.fmFreq;
      fmPhase += kTwoPi * mf * inv;
      if (fmPhase > kTwoPi) fmPhase -= kTwoPi * std::floor(fmPhase / kTwoPi);
    }
    out[i] += (float)(waveSample(p.wave, ph, dt, p.width) * gain);
    phase += dt;
    if (phase >= 1.0) phase -= 1.0;
  }
}

void renderNoise(Wave w, float* out, int n, double gain, RenderCtx& cx) {
  Rng r(cx.rng.next());
  const float g = (float)gain;
  if (w == Wave::White) {
    for (int i = 0; i < n; ++i) out[i] += r.bi() * g;
  } else if (w == Wave::Pink) {  // Paul Kellet's economy pink filter
    float b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (int i = 0; i < n; ++i) {
      const float x = r.bi();
      b0 = 0.99886f * b0 + x * 0.0555179f;
      b1 = 0.99332f * b1 + x * 0.0750759f;
      b2 = 0.96900f * b2 + x * 0.1538520f;
      b3 = 0.86650f * b3 + x * 0.3104856f;
      b4 = 0.55000f * b4 + x * 0.5329522f;
      b5 = -0.7616f * b5 - x * 0.0168980f;
      const float pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + x * 0.5362f;
      b6 = x * 0.115926f;
      out[i] += pink * 0.11f * g;
    }
  } else {  // brown: leaky integrated white noise
    float last = 0.0f;
    for (int i = 0; i < n; ++i) {
      last = (last + 0.02f * r.bi()) / 1.02f;
      out[i] += last * 3.5f * g;
    }
  }
}

}  // namespace

void renderSource(const SourceParams& p, float* out, int n, double pitchMul, double gain, RenderCtx& cx) {
  const double g = gain * p.vol;
  switch (p.wave) {
    case Wave::White:
    case Wave::Pink:
    case Wave::Brown:
      cx.spend((double)n * 20.0);
      renderNoise(p.wave, out, n, g, cx);
      break;
    case Wave::Voice:
      cx.spend((double)n * 60.0);
      renderHuman(p, out, n, pitchMul, g, cx);
      break;
    default:
      cx.spend((double)n * tonalCost(p));
      renderTonal(p, out, n, pitchMul, g, cx);
      break;
  }
}

}  // namespace cw
