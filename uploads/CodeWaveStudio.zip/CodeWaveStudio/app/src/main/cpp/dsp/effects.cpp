#include "dsp.h"

namespace cw {
namespace {

template <typename Fn>
void mapSamples(AudioBuf& b, Fn fn) {
  const int n = b.frames();
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    for (int i = 0; i < n; ++i) x[i] = fn(x[i]);
  }
}

struct Comb {
  std::vector<float> buf;
  int idx = 0;
  float store = 0.0f;
};
struct Allpass {
  std::vector<float> buf;
  int idx = 0;
};

}  // namespace

// ------------------------------------------------------------- distortion
void applyDistortion(AudioBuf& b, double amount, double mix, RenderCtx& cx) {
  const float drive = (float)(1.0 + amount * 14.0);
  const float norm = 1.0f / std::tanh(drive);
  const float w = (float)mix;
  cx.spend((double)b.frames() * b.channels() * 13.0);
  mapSamples(b, [&](float x) {
    const float y = std::tanh(x * drive) * norm;
    return x + (y - x) * w;
  });
}

void applyHardClip(AudioBuf& b, double amount, RenderCtx& cx) {
  const float drive = (float)(1.0 + amount * 20.0);
  cx.spend((double)b.frames() * b.channels() * 2.0);
  mapSamples(b, [&](float x) { return clampf(x * drive, -1.0f, 1.0f); });
}

void applyFold(AudioBuf& b, double amount, RenderCtx& cx) {
  const float drive = (float)((1.0 + amount * 8.0) * (kPi / 2.0));
  cx.spend((double)b.frames() * b.channels() * 10.0);
  mapSamples(b, [&](float x) { return std::sin(x * drive); });
}

void applySaturation(AudioBuf& b, double amount, RenderCtx& cx) {
  const float drive = (float)(1.0 + amount * 4.0);
  const float bias = (float)(0.25 * amount);
  const float tb = std::tanh(bias);
  const float norm = 1.0f / std::max(0.05f, std::tanh(drive + bias) - tb);
  cx.spend((double)b.frames() * b.channels() * 13.0);
  mapSamples(b, [&](float x) { return (std::tanh(x * drive + bias) - tb) * norm; });
}

void applyBitcrush(AudioBuf& b, int bits, double rate, RenderCtx& cx) {
  const float levels = (float)std::pow(2.0, bits - 1);
  const bool decimate = rate > 0.0 && rate < cx.sr;
  const double step = decimate ? rate / cx.sr : 1.0;
  const int n = b.frames();
  cx.spend((double)n * b.channels() * 2.0);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    float hold = 0.0f;
    double acc = 1.0;
    for (int i = 0; i < n; ++i) {
      if (decimate) {
        acc += step;
        if (acc >= 1.0) {
          acc -= 1.0;
          hold = std::round(clampf(x[i], -1.0f, 1.0f) * levels) / levels;
        }
        x[i] = hold;
      } else {
        x[i] = std::round(clampf(x[i], -1.0f, 1.0f) * levels) / levels;
      }
    }
  }
}

// ------------------------------------------------------------------ delay
void applyDelay(AudioBuf& b, double time, double feedback, double mix, RenderCtx& cx) {
  const int n = b.frames();
  const int d = std::max(1, std::min(toFrames(time, cx.sr), 2 * cx.sr));
  const float fb = (float)feedback, wet = (float)mix;
  cx.spend((double)n * b.channels() * 2.0);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    std::vector<float> line((size_t)d, 0.0f);
    int idx = 0;
    for (int i = 0; i < n; ++i) {
      const float in = x[i];
      const float y = line[idx];
      line[idx] = undenorm(in + y * fb);
      if (++idx >= d) idx = 0;
      x[i] = in + y * wet;
    }
  }
}

// ----------------------------------------------------------------- reverb
// Freeverb-style network (8 combs + 4 all-passes per channel), stereo output.
void applyReverb(AudioBuf& b, double mix, double size, double damping, RenderCtx& cx) {
  static const int kComb[8] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
  static const int kAllpass[4] = {556, 441, 341, 225};
  const int kSpread = 23;
  const int n = b.frames();
  const double scale = cx.sr / 44100.0;
  b.makeStereo();
  cx.spend((double)n * 45.0);

  Comb comb[2][8];
  Allpass ap[2][4];
  for (int c = 0; c < 2; ++c) {
    for (int k = 0; k < 8; ++k) comb[c][k].buf.assign((size_t)std::max(8, (int)((kComb[k] + c * kSpread) * scale)), 0.0f);
    for (int k = 0; k < 4; ++k) ap[c][k].buf.assign((size_t)std::max(4, (int)((kAllpass[k] + c * kSpread) * scale)), 0.0f);
  }
  const float feedback = (float)(0.70 + 0.28 * size);
  const float damp1 = (float)(0.4 * damping), damp2 = 1.0f - damp1;
  const float wetGain = 3.0f, wetMix = (float)mix, dryMix = 1.0f - wetMix;
  float* l = b.ch(0);
  float* r = b.ch(1);
  for (int i = 0; i < n; ++i) {
    if ((i & 16383) == 0) cx.check();
    const float in = (l[i] + r[i]) * 0.5f * 0.015f;
    float wet[2];
    for (int c = 0; c < 2; ++c) {
      float acc = 0.0f;
      for (int k = 0; k < 8; ++k) {
        Comb& cb = comb[c][k];
        const float out = cb.buf[(size_t)cb.idx];
        cb.store = undenorm(out * damp2 + cb.store * damp1);
        cb.buf[(size_t)cb.idx] = in + cb.store * feedback;
        if (++cb.idx >= (int)cb.buf.size()) cb.idx = 0;
        acc += out;
      }
      for (int k = 0; k < 4; ++k) {
        Allpass& a = ap[c][k];
        const float bo = a.buf[(size_t)a.idx];
        const float o = bo - acc;
        a.buf[(size_t)a.idx] = undenorm(acc + bo * 0.5f);
        if (++a.idx >= (int)a.buf.size()) a.idx = 0;
        acc = o;
      }
      wet[c] = acc;
    }
    l[i] = l[i] * dryMix + wet[0] * wetGain * wetMix;
    r[i] = r[i] * dryMix + wet[1] * wetGain * wetMix;
  }
}

// ---------------------------------------------------------------- tremolo
void applyTremolo(AudioBuf& b, double rate, double depth, int shape, RenderCtx& cx) {
  const int n = b.frames();
  const double inc = rate / cx.sr;
  const float coef = (float)(1.0 - std::exp(-1.0 / (0.002 * cx.sr)));  // 2 ms smoothing, no clicks
  cx.spend((double)n * b.channels() * 8.0);
  double ph = 0.0;
  float sm = 1.0f;
  float* l = b.ch(0);
  float* r = b.channels() > 1 ? b.ch(1) : nullptr;
  for (int i = 0; i < n; ++i) {
    double lfo;
    switch (shape) {
      case 1: lfo = 4.0 * std::fabs(ph - 0.5) - 1.0; break;  // triangle
      case 2: lfo = ph < 0.5 ? 1.0 : -1.0; break;            // square
      case 3: lfo = 1.0 - 2.0 * ph; break;                   // saw
      default: lfo = std::cos(kTwoPi * ph); break;           // sine
    }
    const float g = (float)(1.0 - depth * 0.5 * (1.0 - lfo));
    sm += (g - sm) * coef;
    ph += inc;
    if (ph >= 1.0) ph -= std::floor(ph);
    l[i] *= sm;
    if (r) r[i] *= sm;
  }
}

// ----------------------------------------------------------------- chorus
void applyChorus(AudioBuf& b, double rate, double depth, double mix, int voices, RenderCtx& cx) {
  const int n = b.frames();
  const int sr = cx.sr;
  const int K = std::max(2, std::min(voices, 4));
  b.makeStereo();
  cx.spend((double)n * 55.0);
  const int size = (int)(0.08 * sr) + 4;
  std::vector<float> line((size_t)size, 0.0f);
  int w = 0;
  double ph[4];
  for (int k = 0; k < 4; ++k) ph[k] = (double)k / K;
  const double inc = rate / sr;
  const double base = 0.016 * sr, dep = depth * 0.006 * sr;
  const float wetMix = (float)mix, dryMix = 1.0f - wetMix;
  float* l = b.ch(0);
  float* r = b.ch(1);
  for (int i = 0; i < n; ++i) {
    line[(size_t)w] = 0.5f * (l[i] + r[i]);
    float wet[2] = {0.0f, 0.0f};
    int cnt[2] = {0, 0};
    for (int k = 0; k < K; ++k) {
      const double lfo = std::sin(kTwoPi * ph[k]);
      ph[k] += inc * (1.0 + 0.11 * k);
      if (ph[k] >= 1.0) ph[k] -= std::floor(ph[k]);
      double pos = (double)w - (base + k * 0.0013 * sr + lfo * dep);
      while (pos < 0.0) pos += size;
      const int i0 = (int)pos;
      const float fr = (float)(pos - i0);
      const int i1 = i0 + 1 >= size ? 0 : i0 + 1;
      wet[k & 1] += line[(size_t)i0] * (1.0f - fr) + line[(size_t)i1] * fr;
      cnt[k & 1]++;
    }
    if (++w >= size) w = 0;
    l[i] = l[i] * dryMix + (wet[0] / cnt[0]) * wetMix;
    r[i] = r[i] * dryMix + (wet[1] / cnt[1]) * wetMix;
  }
}

// ------------------------------------------------------------- compressor
void applyCompressor(AudioBuf& b, double thresholdDb, double ratio, double attack, double release,
                     double makeupDb, RenderCtx& cx) {
  const int n = b.frames();
  const double sr = cx.sr;
  const double aC = std::exp(-1.0 / (std::max(attack, 1e-4) * sr));
  const double rC = std::exp(-1.0 / (std::max(release, 1e-3) * sr));
  const double makeup = dbToLin(makeupDb);
  const double slope = 1.0 - 1.0 / std::max(1.0, ratio);
  cx.spend((double)n * 18.0);
  float* l = b.ch(0);
  float* r = b.channels() > 1 ? b.ch(1) : nullptr;
  double env = 0.0;
  for (int i = 0; i < n; ++i) {
    const double pk = std::max(std::fabs((double)l[i]), r ? std::fabs((double)r[i]) : 0.0);
    env = pk > env ? aC * env + (1.0 - aC) * pk : rC * env + (1.0 - rC) * pk;
    const double envDb = 8.685889638065035 * std::log(std::max(env, 1e-6));
    const double over = envDb - thresholdDb;
    const double gr = over > 0.0 ? over * slope : 0.0;
    const float g = (float)(std::exp(-gr * 0.11512925464970229) * makeup);
    l[i] *= g;
    if (r) r[i] *= g;
  }
}

}  // namespace cw
