#pragma once

#include <utility>
#include <vector>

#include "common.h"

namespace cw {

// Planar float buffer (1 or 2 channels). Every allocation is charged to the RenderCtx
// budget, so a hostile script can never request an unbounded amount of memory.
class AudioBuf {
 public:
  AudioBuf() = default;
  AudioBuf(RenderCtx& cx, int frames, int channels = 1) : cx_(&cx), n_(frames), nch_(0) {
    for (int c = 0; c < channels; ++c) {
      allocChannel(c);
      nch_ = c + 1;
    }
  }
  ~AudioBuf() { freeAll(); }

  AudioBuf(const AudioBuf&) = delete;
  AudioBuf& operator=(const AudioBuf&) = delete;
  AudioBuf(AudioBuf&& o) noexcept { moveFrom(o); }
  AudioBuf& operator=(AudioBuf&& o) noexcept {
    if (this != &o) {
      freeAll();
      moveFrom(o);
    }
    return *this;
  }

  bool valid() const { return nch_ > 0; }
  int frames() const { return n_; }
  int channels() const { return nch_; }
  float* ch(int c) { return d_[c].data(); }
  const float* ch(int c) const { return d_[c].data(); }

  // Mono -> stereo (copies channel 0 into a new channel 1).
  void makeStereo() {
    if (nch_ != 1) return;
    allocChannel(1);
    std::copy(d_[0].begin(), d_[0].end(), d_[1].begin());
    nch_ = 2;
  }

  // Hands a channel's storage to the caller and stops charging it to the budget.
  std::vector<float> takeChannel(int c) {
    std::vector<float> v = std::move(d_[c]);
    d_[c] = std::vector<float>();
    cx_->release(held_[c]);
    held_[c] = 0;
    return v;
  }

 private:
  void allocChannel(int c) {
    const size_t bytes = (size_t)n_ * sizeof(float);
    cx_->allocate(bytes);
    try {
      d_[c].assign((size_t)n_, 0.0f);
    } catch (...) {
      cx_->release(bytes);
      throw;
    }
    held_[c] = bytes;
  }
  void freeAll() {
    if (!cx_) return;
    for (int c = 0; c < 2; ++c) {
      if (held_[c]) cx_->release(held_[c]);
      held_[c] = 0;
      std::vector<float>().swap(d_[c]);
    }
    nch_ = 0;
  }
  void moveFrom(AudioBuf& o) {
    cx_ = o.cx_;
    n_ = o.n_;
    nch_ = o.nch_;
    for (int c = 0; c < 2; ++c) {
      d_[c] = std::move(o.d_[c]);
      held_[c] = o.held_[c];
      o.held_[c] = 0;
    }
    o.nch_ = 0;
    o.n_ = 0;
  }

  RenderCtx* cx_ = nullptr;
  int n_ = 0;
  int nch_ = 0;
  std::vector<float> d_[2];
  size_t held_[2] = {0, 0};
};

// Finished sound: planar float PCM, owned by the Engine until replaced.
struct Sound {
  int sampleRate = 44100;
  int channels = 2;
  int frames = 0;
  std::vector<float> ch[2];
  float peak = 0.0f;
};

}  // namespace cw
