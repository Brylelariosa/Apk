// CodeWave Studio - DSP building blocks. All processors work in place on an AudioBuf
// (offline, whole-buffer rendering) and charge their cost to the RenderCtx.
#pragma once

#include <vector>

#include "audio_buf.h"
#include "common.h"

namespace cw {

// ------------------------------------------------------------------ sources
enum class Wave { Sine, Square, Triangle, Saw, Pulse, White, Pink, Brown, Voice };

struct SourceParams {
  Wave wave = Wave::Sine;
  double freq = 440.0, vol = 1.0, width = 0.25;
  // FM (phase modulation). fmIndexEnd < 0 means "same as fmIndex".
  bool fm = false, fmRatio = false;
  double fmFreq = 0.0, fmIndex = 0.0, fmIndexEnd = -1.0;
  bool vib = false;
  double vibRate = 5.5, vibDepth = 0.3;  // depth in semitones
  bool sweepF = false;
  double sweepFrom = 0, sweepTo = 0, sweepFTime = 0, sweepFCurve = 1;
  bool sweepP = false;
  double sweepSemis = 0, sweepPTime = 0, sweepPCurve = 1;
  bool quant = false;
  double quantStep = 1.0;  // semitones
  // voice.human only
  int vowelA = 0, vowelB = -1;
  double size = 1.0, breath = 0.05, vibVoice = 0.2, jitter = 0.01, shimmer = 0.04;
};

inline double sweepProgress(double t, double time, double curve) {
  if (time <= 0.0) return 1.0;
  const double x = t / time;
  if (x >= 1.0) return 1.0;
  if (x <= 0.0) return 0.0;
  return curve == 1.0 ? x : 1.0 - std::pow(1.0 - x, curve);
}

// Instantaneous frequency of a source: base pitch, sweeps, vibrato, quantisation.
class FreqTrack {
 public:
  FreqTrack(const SourceParams& p, double pitchMul, int sr)
      : p_(p), pm_(pitchMul), inv_(1.0 / sr), nyq_(sr * 0.49) {}
  double next(int i) {
    const double t = i * inv_;
    double f = p_.freq * pm_;
    if (p_.sweepF) {
      f = p_.sweepFrom * std::pow(p_.sweepTo / p_.sweepFrom, sweepProgress(t, p_.sweepFTime, p_.sweepFCurve)) * pm_;
    }
    if (p_.sweepP) f *= std::exp2(p_.sweepSemis / 12.0 * sweepProgress(t, p_.sweepPTime, p_.sweepPCurve));
    if (p_.vib) {
      f *= std::exp2(p_.vibDepth / 12.0 * std::sin(vibPhase_));
      vibPhase_ += kTwoPi * p_.vibRate * inv_;
    }
    if (p_.quant) {
      double st = 12.0 * std::log2(f / 440.0);
      st = std::round(st / p_.quantStep) * p_.quantStep;
      f = 440.0 * std::exp2(st / 12.0);
    }
    return f < 1.0 ? 1.0 : (f > nyq_ ? nyq_ : f);
  }

 private:
  const SourceParams& p_;
  double pm_, inv_, nyq_;
  double vibPhase_ = 0.0;
};

inline float polyblep(double t, double dt) {
  if (t < dt) {
    t /= dt;
    return (float)(t + t - t * t - 1.0);
  }
  if (t > 1.0 - dt) {
    t = (t - 1.0) / dt;
    return (float)(t * t + t + t + 1.0);
  }
  return 0.0f;
}

// Adds the rendered source into out[0..n). pitchMul/gain come from the enclosing layer.
void renderSource(const SourceParams& p, float* out, int n, double pitchMul, double gain, RenderCtx& cx);

// ------------------------------------------------------------------ filters
enum class FilterType { Low, High, Band, Notch };
struct BiquadCoef {
  double b0, b1, b2, a1, a2;
};
struct BiquadState {
  double z1 = 0.0, z2 = 0.0;
};
BiquadCoef designBiquad(FilterType t, double fc, double q, int sr);
inline double biquadTick(const BiquadCoef& c, BiquadState& s, double x) {
  const double y = c.b0 * x + s.z1;
  s.z1 = c.b1 * x - c.a1 * y + s.z2;
  s.z2 = c.b2 * x - c.a2 * y;
  return y;
}
// fcEnd > 0 sweeps the cutoff exponentially from fc to fcEnd over `time` seconds (0 = whole buffer).
void applyFilter(AudioBuf& b, FilterType type, double fc, double q, int order, double fcEnd, double time,
                 RenderCtx& cx);

// ---------------------------------------------------------------- envelopes
void applyAdsr(AudioBuf& b, double a, double d, double s, double r, double curve, RenderCtx& cx);
void applyExpDecay(AudioBuf& b, double decay, double attack, RenderCtx& cx);
void applyLinearDecay(AudioBuf& b, double decay, double attack, RenderCtx& cx);
void applyCustomEnv(AudioBuf& b, const std::vector<double>& timeValuePairs, RenderCtx& cx);

// -------------------------------------------------------------- modulation
void applyAm(AudioBuf& b, double freq, double depth, RenderCtx& cx);
void applyRing(AudioBuf& b, double freq, double mix, RenderCtx& cx);

// ----------------------------------------------------------------- effects
void applyDistortion(AudioBuf& b, double amount, double mix, RenderCtx& cx);
void applyHardClip(AudioBuf& b, double amount, RenderCtx& cx);
void applyFold(AudioBuf& b, double amount, RenderCtx& cx);
void applySaturation(AudioBuf& b, double amount, RenderCtx& cx);
void applyBitcrush(AudioBuf& b, int bits, double rate, RenderCtx& cx);
void applyDelay(AudioBuf& b, double time, double feedback, double mix, RenderCtx& cx);
void applyReverb(AudioBuf& b, double mix, double size, double damping, RenderCtx& cx);
void applyTremolo(AudioBuf& b, double rate, double depth, int shape, RenderCtx& cx);
void applyChorus(AudioBuf& b, double rate, double depth, double mix, int voices, RenderCtx& cx);
void applyCompressor(AudioBuf& b, double thresholdDb, double ratio, double attack, double release,
                     double makeupDb, RenderCtx& cx);

// ------------------------------------------------------------------- voice
constexpr int kVowelCount = 6;  // a e i o u uh
void renderHuman(const SourceParams& p, float* out, int n, double pitchMul, double gain, RenderCtx& cx);
void applyFormant(AudioBuf& b, int vowelA, int vowelB, double sharpness, double mix, double size, RenderCtx& cx);
void applyVocoder(AudioBuf& b, int bands, double pitch, double mix, int carrier, RenderCtx& cx);
void applyMetallic(AudioBuf& b, double freq, double amount, RenderCtx& cx);

// ----------------------------------------------------------------- utility
float peakOf(const AudioBuf& b);
void applyNormalize(AudioBuf& b, double level, RenderCtx& cx);
void applyFade(AudioBuf& b, double fadeIn, double fadeOut, RenderCtx& cx);
void applyReverse(AudioBuf& b, RenderCtx& cx);
void applyGain(AudioBuf& b, double gain);
void applyPan(AudioBuf& b, double pan);
void applyPitch(AudioBuf& b, double semitones, bool keepTime, RenderCtx& cx);
void applyStretch(AudioBuf& b, double factor, RenderCtx& cx);
// dst[dstOffset + i] += src[i] * gain (equal-power pan; promotes dst to stereo when needed).
void mixInto(AudioBuf& dst, const AudioBuf& src, int dstOffset, double gain, double pan);

}  // namespace cw
