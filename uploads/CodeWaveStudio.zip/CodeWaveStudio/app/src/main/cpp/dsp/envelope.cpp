#include "dsp.h"

namespace cw {
namespace {

// Multiplies every channel by the per-sample gain produced by `fn(i)`.
template <typename Fn>
void applyGainCurve(AudioBuf& b, Fn fn) {
  const int n = b.frames();
  float* l = b.ch(0);
  float* r = b.channels() > 1 ? b.ch(1) : nullptr;
  for (int i = 0; i < n; ++i) {
    const float g = (float)fn(i);
    l[i] *= g;
    if (r) r[i] *= g;
  }
}

// Short fade on the last samples so a truncated tail can never click.
void antiClickTail(AudioBuf& b) {
  const int n = b.frames();
  const int len = std::min(n / 4, 64);
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    for (int i = 0; i < len; ++i) x[n - 1 - i] *= (float)i / (float)len;
  }
}

}  // namespace

void applyAdsr(AudioBuf& b, double a, double d, double s, double r, double curve, RenderCtx& cx) {
  const int n = b.frames();
  const double len = (double)n / cx.sr;
  const double total = a + d + r;
  if (total > len && total > 0.0) {
    const double f = len / total;
    a *= f;
    d *= f;
    r *= f;
  }
  const int na = toFrames(a, cx.sr), nd = toFrames(d, cx.sr), nr = toFrames(r, cx.sr);
  const int relStart = std::max(na + nd, n - nr);
  const bool lin = curve == 1.0;
  cx.spend((double)n * b.channels() * 3.0);
  applyGainCurve(b, [&](int i) -> double {
    if (i < na) return na > 0 ? (double)i / na : 1.0;
    if (i < na + nd) {
      const double p = (double)(i - na) / nd;
      const double q = lin ? 1.0 - p : std::pow(1.0 - p, curve);
      return s + (1.0 - s) * q;
    }
    if (i < relStart) return s;
    const int rl = n - relStart;
    const double p = rl > 0 ? (double)(i - relStart + 1) / rl : 1.0;
    const double q = lin ? 1.0 - p : std::pow(std::max(0.0, 1.0 - p), curve);
    return s * q;
  });
}

void applyExpDecay(AudioBuf& b, double decay, double attack, RenderCtx& cx) {
  const double sr = cx.sr;
  const double k = 3.0 * std::log(10.0) / std::max(decay, 1e-4);  // -60 dB after `decay`
  cx.spend((double)b.frames() * b.channels() * 8.0);
  applyGainCurve(b, [&](int i) -> double {
    const double t = i / sr;
    const double att = attack > 0.0 && t < attack ? t / attack : 1.0;
    return att * std::exp(-k * t);
  });
  antiClickTail(b);
}

void applyLinearDecay(AudioBuf& b, double decay, double attack, RenderCtx& cx) {
  const double sr = cx.sr;
  cx.spend((double)b.frames() * b.channels() * 3.0);
  applyGainCurve(b, [&](int i) -> double {
    const double t = i / sr;
    const double att = attack > 0.0 && t < attack ? t / attack : 1.0;
    return att * std::max(0.0, 1.0 - t / std::max(decay, 1e-4));
  });
  antiClickTail(b);
}

void applyCustomEnv(AudioBuf& b, const std::vector<double>& pts, RenderCtx& cx) {
  const size_t np = pts.size() / 2;
  if (np == 0) return;
  const double sr = cx.sr;
  size_t seg = 0;
  cx.spend((double)b.frames() * b.channels() * 3.0);
  applyGainCurve(b, [&](int i) -> double {
    const double t = i / sr;
    while (seg + 1 < np && t >= pts[2 * (seg + 1)]) ++seg;
    const double t0 = pts[2 * seg], v0 = pts[2 * seg + 1];
    if (t <= t0 || seg + 1 >= np) return v0;
    const double t1 = pts[2 * (seg + 1)], v1 = pts[2 * (seg + 1) + 1];
    const double span = t1 - t0;
    return span > 0.0 ? v0 + (v1 - v0) * (t - t0) / span : v1;
  });
}

void applyAm(AudioBuf& b, double freq, double depth, RenderCtx& cx) {
  const int n = b.frames();
  const double inc = kTwoPi * freq / cx.sr;
  cx.spend((double)n * b.channels() * 7.0);
  double ph = 0.0;
  float* l = b.ch(0);
  float* r = b.channels() > 1 ? b.ch(1) : nullptr;
  for (int i = 0; i < n; ++i) {
    const float g = (float)((1.0 - depth) + depth * (0.5 + 0.5 * std::sin(ph)));
    ph += inc;
    l[i] *= g;
    if (r) r[i] *= g;
  }
}

void applyRing(AudioBuf& b, double freq, double mix, RenderCtx& cx) {
  const int n = b.frames();
  const double inc = kTwoPi * freq / cx.sr;
  cx.spend((double)n * b.channels() * 7.0);
  double ph = 0.0;
  float* l = b.ch(0);
  float* r = b.channels() > 1 ? b.ch(1) : nullptr;
  for (int i = 0; i < n; ++i) {
    const float m = (float)std::sin(ph);
    ph += inc;
    const float w = (float)mix;
    l[i] = l[i] * (1.0f - w) + l[i] * m * w;
    if (r) r[i] = r[i] * (1.0f - w) + r[i] * m * w;
  }
}

}  // namespace cw
