#include "dsp.h"

namespace cw {

BiquadCoef designBiquad(FilterType t, double fc, double q, int sr) {
  fc = clampd(fc, 10.0, sr * 0.49);
  q = clampd(q, 0.1, 30.0);
  const double w0 = kTwoPi * fc / sr;
  const double cs = std::cos(w0), sn = std::sin(w0);
  const double alpha = sn / (2.0 * q);
  double b0, b1, b2;
  switch (t) {
    case FilterType::Low:
      b0 = (1.0 - cs) * 0.5;
      b1 = 1.0 - cs;
      b2 = b0;
      break;
    case FilterType::High:
      b0 = (1.0 + cs) * 0.5;
      b1 = -(1.0 + cs);
      b2 = b0;
      break;
    case FilterType::Band:  // constant 0 dB peak gain
      b0 = alpha;
      b1 = 0.0;
      b2 = -alpha;
      break;
    default:  // notch
      b0 = 1.0;
      b1 = -2.0 * cs;
      b2 = 1.0;
      break;
  }
  const double a0 = 1.0 + alpha;
  return BiquadCoef{b0 / a0, b1 / a0, b2 / a0, (-2.0 * cs) / a0, (1.0 - alpha) / a0};
}

void applyFilter(AudioBuf& b, FilterType type, double fc, double q, int order, double fcEnd, double time,
                 RenderCtx& cx) {
  const int n = b.frames();
  const int sr = cx.sr;
  order = order < 1 ? 1 : (order > 4 ? 4 : order);
  const bool sweep = fcEnd > 0.0 && std::fabs(fcEnd - fc) > 1e-9;
  const double span = time > 0.0 ? time * sr : (double)n;
  const int kBlock = 32;
  cx.spend((double)n * b.channels() * order * (sweep ? 12.0 : 7.0));
  for (int c = 0; c < b.channels(); ++c) {
    float* x = b.ch(c);
    BiquadState st[4];
    BiquadCoef co = designBiquad(type, fc, q, sr);
    for (int i0 = 0; i0 < n; i0 += kBlock) {
      if (sweep) {
        const double p = clampd(i0 / span, 0.0, 1.0);
        co = designBiquad(type, fc * std::pow(fcEnd / fc, p), q, sr);
      }
      if ((i0 & 32767) == 0) cx.check();
      const int i1 = std::min(n, i0 + kBlock);
      for (int i = i0; i < i1; ++i) {
        double v = x[i];
        for (int s = 0; s < order; ++s) v = biquadTick(co, st[s], v);
        x[i] = (float)v;
      }
    }
  }
}

}  // namespace cw
