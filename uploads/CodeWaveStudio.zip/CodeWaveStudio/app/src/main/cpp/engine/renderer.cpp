#include "renderer.h"

#include <memory>
#include <vector>

#include "../dsp/dsp.h"

namespace cw {
namespace {

// One signal chain: a buffer plus the oscillators that have not been rendered yet.
// Oscillators are rendered lazily so modifiers (fm, vibrato, sweeps) written after
// an oscillator can still change it.
struct Layer {
  int start = 0;   // offset inside the parent buffer, in frames
  int length = 0;  // frames
  AudioBuf buf;
  std::vector<SourceParams> pending;
  double pitchMul = 1.0;
  double gainMul = 1.0;
};

struct LoopFrame {
  size_t beginPc;
  int iter;
  int count;
  double interval, lengthSec, pitchVar, gainVar, decay;
};

class Renderer {
 public:
  Renderer(const Program& p, const RenderSettings& rs, RenderCtx& cx, const ProgressFn& pf)
      : prog_(p), rs_(rs), cx_(cx), progress_(pf) {}

  RenderResult run() {
    const int total = std::max(1, toFrames(prog_.cmds.front().p[0], cx_.sr));
    layers_.push_back(std::make_unique<Layer>());
    layers_.back()->length = total;

    const size_t n = prog_.cmds.size();
    size_t pc = 1;
    bool done = false;
    while (pc < n && !done) {
      cx_.check();
      const Command& c = prog_.cmds[pc];
      if (progress_ && (pc & 3) == 0) progress_((float)pc / (float)n);
      Layer& L = *layers_.back();
      switch (c.spec->cat) {
        case Cat::Structure:
          switch (c.op) {
            case Op::SoundEnd:
              done = true;
              break;
            case Op::LayerBegin:
              if (!beginLayer(toFrames(c.p[0], cx_.sr), c.p[1] > 0.0 ? toFrames(c.p[1], cx_.sr) : 0, 1.0, 1.0)) {
                pc = (size_t)c.match + 1;
                continue;
              }
              break;
            case Op::LayerEnd:
              endLayer(c.p[0], c.p[1]);
              break;
            case Op::RepeatBegin: {
              LoopFrame f{pc, 0, (int)c.p[0], c.p[1], c.p[2], c.p[3], c.p[4], c.p[5]};
              loops_.push_back(f);
              if (!beginIteration(loops_.back())) {
                loops_.pop_back();
                pc = (size_t)c.match + 1;
                continue;
              }
              break;
            }
            case Op::RepeatEnd: {
              endLayer(1.0, 0.0);
              LoopFrame& f = loops_.back();
              ++f.iter;
              if (f.iter < f.count && beginIteration(f)) {
                pc = f.beginPc + 1;
                continue;
              }
              loops_.pop_back();
              break;
            }
            default:
              break;
          }
          break;
        case Cat::Source:
          addSource(L, c);
          break;
        case Cat::Modifier:
          modify(L, c);
          break;
        case Cat::Processor:
          process(L, c);
          break;
      }
      ++pc;
    }
    if (progress_) progress_(1.0f);
    return finish(total);
  }

 private:
  void ensureBuf(Layer& L) {
    if (!L.buf.valid()) L.buf = AudioBuf(cx_, L.length, 1);
  }

  void flush(Layer& L) {
    if (L.pending.empty()) return;
    ensureBuf(L);
    for (const SourceParams& sp : L.pending) renderSource(sp, L.buf.ch(0), L.length, L.pitchMul, L.gainMul, cx_);
    L.pending.clear();
  }

  bool beginLayer(int startFrames, int lengthFrames, double pitchMul, double gainMul) {
    Layer& parent = *layers_.back();
    const int pl = parent.length;
    if (startFrames >= pl) return false;
    int len = lengthFrames > 0 ? lengthFrames : pl - startFrames;
    len = std::min(len, pl - startFrames);
    if (len < 1) return false;
    flush(parent);
    auto L = std::make_unique<Layer>();
    L->start = startFrames;
    L->length = len;
    L->pitchMul = parent.pitchMul * pitchMul;
    L->gainMul = parent.gainMul * gainMul;
    layers_.push_back(std::move(L));
    return true;
  }

  bool beginIteration(const LoopFrame& f) {
    const int st = toFrames(f.iter * f.interval, cx_.sr);
    const int len = f.lengthSec > 0.0 ? toFrames(f.lengthSec, cx_.sr) : std::max(1, toFrames(f.interval, cx_.sr));
    const double pm = f.pitchVar > 0.0 ? std::exp2((double)cx_.rng.bi() * f.pitchVar / 12.0) : 1.0;
    const double gm = (f.gainVar > 0.0 ? 1.0 + (double)cx_.rng.bi() * f.gainVar : 1.0) * std::pow(1.0 - f.decay, f.iter);
    return beginLayer(st, len, pm, gm);
  }

  void endLayer(double gain, double pan) {
    std::unique_ptr<Layer> L = std::move(layers_.back());
    layers_.pop_back();
    flush(*L);
    if (!L->buf.valid()) return;
    Layer& parent = *layers_.back();
    ensureBuf(parent);
    mixInto(parent.buf, L->buf, L->start, gain, pan);
  }

  void addSource(Layer& L, const Command& c) {
    SourceParams s;
    switch (c.op) {
      case Op::OscSine: s.wave = Wave::Sine; break;
      case Op::OscSquare: s.wave = Wave::Square; break;
      case Op::OscTriangle: s.wave = Wave::Triangle; break;
      case Op::OscSaw: s.wave = Wave::Saw; break;
      case Op::OscPulse: s.wave = Wave::Pulse; break;
      case Op::OscNoise:
      case Op::NoiseWhite: s.wave = Wave::White; break;
      case Op::NoisePink: s.wave = Wave::Pink; break;
      case Op::NoiseBrown: s.wave = Wave::Brown; break;
      default: s.wave = Wave::Voice; break;
    }
    if (c.op == Op::OscNoise || c.op == Op::NoiseWhite || c.op == Op::NoisePink || c.op == Op::NoiseBrown) {
      s.vol = c.p[0];
    } else {
      s.freq = c.p[0];
      s.vol = c.p[1];
      if (c.op == Op::OscPulse) s.width = c.p[2];
      if (c.op == Op::VoiceHuman) {
        s.vowelA = (int)c.p[2];
        s.vowelB = c.p[3] > 0.5 ? (int)c.p[3] - 1 : -1;
        s.size = c.p[4];
        s.breath = c.p[5];
        s.vibVoice = c.p[6];
        s.jitter = c.p[7];
        s.shimmer = c.p[8];
      }
    }
    L.pending.push_back(s);
  }

  void modify(Layer& L, const Command& c) {
    if (L.pending.empty()) return;
    SourceParams& s = L.pending.back();
    const double lenSec = (double)L.length / cx_.sr;
    switch (c.op) {
      case Op::FmModulate:
      case Op::FmRatio:
        s.fm = true;
        s.fmRatio = c.op == Op::FmRatio;
        s.fmFreq = c.p[0];
        s.fmIndex = c.p[1];
        s.fmIndexEnd = c.p[2] < 0.0 ? -1.0 : c.p[2];
        break;
      case Op::VibratoAdd:
        s.vib = true;
        s.vibRate = c.p[0];
        s.vibDepth = c.p[1];
        break;
      case Op::SweepFrequency:
        s.sweepF = true;
        s.sweepFrom = c.p[0];
        s.sweepTo = c.p[1];
        s.sweepFTime = c.p[2] > 0.0 ? c.p[2] : lenSec;
        s.sweepFCurve = c.p[3];
        break;
      case Op::SweepPitch:
        s.sweepP = true;
        s.sweepSemis = c.p[0];
        s.sweepPTime = c.p[1] > 0.0 ? c.p[1] : lenSec;
        s.sweepPCurve = c.p[2];
        break;
      case Op::PitchQuantize:
        s.quant = true;
        s.quantStep = c.p[0];
        break;
      default:
        break;
    }
  }

  void process(Layer& L, const Command& c) {
    flush(L);
    ensureBuf(L);
    AudioBuf& b = L.buf;
    const double* p = c.p;
    switch (c.op) {
      case Op::AmModulate: applyAm(b, p[0], p[1], cx_); break;
      case Op::RingModulate: applyRing(b, p[0], p[1], cx_); break;
      case Op::EnvAdsr: applyAdsr(b, p[0], p[1], p[2], p[3], p[4], cx_); break;
      case Op::EnvExp: applyExpDecay(b, p[0], p[1], cx_); break;
      case Op::EnvLinear: applyLinearDecay(b, p[0], p[1], cx_); break;
      case Op::EnvCustom: applyCustomEnv(b, c.extra, cx_); break;
      case Op::FilterLow: applyFilter(b, FilterType::Low, p[0], p[1], (int)p[4], p[2], p[3], cx_); break;
      case Op::FilterHigh: applyFilter(b, FilterType::High, p[0], p[1], (int)p[4], p[2], p[3], cx_); break;
      case Op::FilterBand: applyFilter(b, FilterType::Band, p[0], p[1], (int)p[4], p[2], p[3], cx_); break;
      case Op::FilterNotch: applyFilter(b, FilterType::Notch, p[0], p[1], (int)p[4], p[2], p[3], cx_); break;
      case Op::DistortionSoft: applyDistortion(b, p[0], p[1], cx_); break;
      case Op::DistortionHard: applyHardClip(b, p[0], cx_); break;
      case Op::DistortionFold: applyFold(b, p[0], cx_); break;
      case Op::Saturation: applySaturation(b, p[0], cx_); break;
      case Op::Bitcrush: applyBitcrush(b, (int)std::lround(p[0]), p[1], cx_); break;
      case Op::DelayEcho: applyDelay(b, p[0], p[1], p[2], cx_); break;
      case Op::ReverbRoom: applyReverb(b, p[0], p[1], p[2], cx_); break;
      case Op::TremoloAdd: applyTremolo(b, p[0], p[1], (int)p[2], cx_); break;
      case Op::ChorusAdd: applyChorus(b, p[0], p[1], p[2], (int)std::lround(p[3]), cx_); break;
      case Op::CompressorAdd: applyCompressor(b, p[0], p[1], p[2], p[3], p[4], cx_); break;
      case Op::VoiceFormant: applyFormant(b, (int)p[0], p[1] > 0.5 ? (int)p[1] - 1 : -1, p[2], p[3], p[4], cx_); break;
      case Op::VoiceVocoder: applyVocoder(b, (int)std::lround(p[0]), p[1], p[2], (int)p[3], cx_); break;
      case Op::VoiceMetallic: applyMetallic(b, p[0], p[1], cx_); break;
      case Op::SoundNormalize: applyNormalize(b, p[0], cx_); break;
      case Op::SoundFade: applyFade(b, p[0], p[1], cx_); break;
      case Op::SoundReverse: applyReverse(b, cx_); break;
      case Op::SoundPitch: applyPitch(b, p[0], p[1] >= 0.5, cx_); break;
      case Op::SoundStretch: applyStretch(b, p[0], cx_); break;
      case Op::SoundGain: applyGain(b, p[0]); break;
      case Op::SoundPan: applyPan(b, p[0]); break;
      default: break;
    }
  }

  RenderResult finish(int total) {
    Layer& M = *layers_.front();
    flush(M);
    ensureBuf(M);
    AudioBuf& mb = M.buf;
    RenderResult rr;
    if (rs_.channels == 1 && mb.channels() == 2) {
      float* l = mb.ch(0);
      const float* r = mb.ch(1);
      for (int i = 0; i < total; ++i) l[i] = 0.5f * (l[i] + r[i]);
    } else if (rs_.channels == 2 && mb.channels() == 1) {
      mb.makeStereo();
    }
    const int outCh = rs_.channels == 1 ? 1 : 2;

    // DC blocker (~8 Hz one-pole high-pass): removes any offset left by waveshapers or noise.
    {
      const double R = 1.0 - kTwoPi * 8.0 / cx_.sr;
      for (int c = 0; c < outCh; ++c) {
        float* x = mb.ch(c);
        double px = 0.0, py = 0.0;
        for (int i = 0; i < total; ++i) {
          const double in = x[i];
          py = in - px + R * py;
          px = in;
          x[i] = (float)py;
        }
      }
    }

    // Declick the very first/last samples (0.5 ms in, 2 ms out).
    const int fi = std::min(total / 8, std::max(1, toFrames(0.0005, cx_.sr)));
    const int fo = std::min(total / 8, std::max(1, toFrames(0.002, cx_.sr)));
    for (int c = 0; c < outCh; ++c) {
      float* x = mb.ch(c);
      for (int i = 0; i < fi; ++i) x[i] *= (float)i / (float)fi;
      for (int i = 0; i < fo; ++i) x[total - 1 - i] *= (float)i / (float)fo;
    }

    float pk = 0.0f;
    for (int c = 0; c < outCh; ++c) {
      const float* x = mb.ch(c);
      for (int i = 0; i < total; ++i) pk = std::max(pk, std::fabs(x[i]));
    }
    if (pk > 1.0f) {  // safety limiter: only ever turns down, never clips
      const float g = 1.0f / pk;
      for (int c = 0; c < outCh; ++c) {
        float* x = mb.ch(c);
        for (int i = 0; i < total; ++i) x[i] *= g;
      }
      rr.autoScaleDb = 20.0 * std::log10((double)g);
      pk = 1.0f;
    }
    rr.silent = pk < 1e-5f;
    rr.sound.sampleRate = cx_.sr;
    rr.sound.channels = outCh;
    rr.sound.frames = total;
    rr.sound.peak = pk;
    for (int c = 0; c < outCh; ++c) rr.sound.ch[c] = mb.takeChannel(c);
    return rr;
  }

  const Program& prog_;
  RenderSettings rs_;
  RenderCtx& cx_;
  ProgressFn progress_;
  std::vector<std::unique_ptr<Layer>> layers_;
  std::vector<LoopFrame> loops_;
};

}  // namespace

RenderResult renderProgram(const Program& prog, const RenderSettings& rs, RenderCtx& cx, const ProgressFn& progress) {
  Renderer r(prog, rs, cx, progress);
  return r.run();
}

}  // namespace cw
