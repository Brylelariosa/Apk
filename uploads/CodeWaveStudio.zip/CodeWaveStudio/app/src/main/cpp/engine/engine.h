#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "renderer.h"

namespace cw {

enum class GenStatus { Ok = 0, ScriptError = 1, OutOfMemory = 2, Cancelled = 3, Internal = 4 };

struct GenerateSettings {
  int sampleRate = 44100;
  int channels = 2;
  double defaultDuration = 2.0;
};

// Owns the most recent successfully generated Sound. A failed generation never touches it,
// so the previous waveform/audio stays available. All accessors are thread-safe; readers get
// a shared_ptr snapshot that stays valid even if a new sound replaces it meanwhile.
class Engine {
 public:
  GenStatus generate(const std::string& script, const GenerateSettings& settings, const ProgressFn& progress);
  void cancel() { cancel_.store(true); }

  std::shared_ptr<const Sound> sound() const;
  std::string lastError() const;
  int lastErrorLine() const;
  std::string lastWarnings() const;
  int lastRenderMillis() const;

 private:
  mutable std::mutex mu_;
  std::mutex genMu_;
  std::shared_ptr<const Sound> sound_;
  std::string error_, warnings_;
  int errorLine_ = 0;
  int millis_ = 0;
  std::atomic<bool> cancel_{false};
};

}  // namespace cw
