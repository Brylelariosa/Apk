#include "engine.h"

#include <chrono>
#include <cstdio>
#include <new>

#include "../parser/parser.h"

namespace cw {

GenStatus Engine::generate(const std::string& script, const GenerateSettings& gs, const ProgressFn& progress) {
  std::lock_guard<std::mutex> one(genMu_);  // one generation at a time
  cancel_.store(false);
  const auto t0 = std::chrono::steady_clock::now();

  GenStatus status = GenStatus::Ok;
  std::string err, warn;
  int errLine = 0;
  std::shared_ptr<const Sound> result;

  try {
    ParseOptions po;
    po.defaultDuration = gs.defaultDuration;
    const Program prog = parseScript(script, po);
    if (progress) progress(0.0f);

    const uint32_t seed = (uint32_t)prog.cmds.front().p[1] * 2654435761u + 0x1234567u;
    RenderCtx cx(gs.sampleRate, seed, &cancel_);
    RenderSettings rs;
    rs.sampleRate = gs.sampleRate;
    rs.channels = gs.channels == 1 ? 1 : 2;
    RenderResult rr = renderProgram(prog, rs, cx, progress);

    if (rr.silent) warn += "The generated sound is silent.\n";
    if (rr.autoScaleDb < -0.05) {
      char buf[96];
      std::snprintf(buf, sizeof(buf), "Output was turned down by %.1f dB to avoid clipping.\n", -rr.autoScaleDb);
      warn += buf;
    }
    result = std::make_shared<const Sound>(std::move(rr.sound));
  } catch (const Cancelled&) {
    status = GenStatus::Cancelled;
    err = "Generation cancelled.";
  } catch (const EngineError& e) {
    status = e.kind == ErrorKind::Memory ? GenStatus::OutOfMemory : GenStatus::ScriptError;
    err = e.format();
    errLine = e.line;
  } catch (const std::bad_alloc&) {
    status = GenStatus::OutOfMemory;
    err = "Out of memory while generating.\n\nUse a shorter duration, fewer layers, or a lower sample rate.";
  } catch (const std::exception&) {
    status = GenStatus::Internal;
    err = "Internal engine error. Please simplify the script and try again.";
  } catch (...) {
    status = GenStatus::Internal;
    err = "Unknown engine error.";
  }

  const int ms = (int)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
  std::lock_guard<std::mutex> lk(mu_);
  millis_ = ms;
  error_ = err;
  errorLine_ = errLine;
  warnings_ = warn;
  if (status == GenStatus::Ok) sound_ = result;
  return status;
}

std::shared_ptr<const Sound> Engine::sound() const {
  std::lock_guard<std::mutex> lk(mu_);
  return sound_;
}
std::string Engine::lastError() const {
  std::lock_guard<std::mutex> lk(mu_);
  return error_;
}
int Engine::lastErrorLine() const {
  std::lock_guard<std::mutex> lk(mu_);
  return errorLine_;
}
std::string Engine::lastWarnings() const {
  std::lock_guard<std::mutex> lk(mu_);
  return warnings_;
}
int Engine::lastRenderMillis() const {
  std::lock_guard<std::mutex> lk(mu_);
  return millis_;
}

}  // namespace cw
