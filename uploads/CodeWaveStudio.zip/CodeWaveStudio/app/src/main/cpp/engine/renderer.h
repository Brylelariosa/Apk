#pragma once

#include <functional>

#include "../dsp/audio_buf.h"
#include "../dsp/common.h"
#include "../parser/parser.h"

namespace cw {

struct RenderSettings {
  int sampleRate = 44100;
  int channels = 2;  // output channels: 1 or 2
};

struct RenderResult {
  Sound sound;
  double autoScaleDb = 0.0;  // < 0 when the safety limiter had to turn the sound down
  bool silent = false;
};

using ProgressFn = std::function<void(float)>;

// Executes the program offline. Throws EngineError / Cancelled.
RenderResult renderProgram(const Program& prog, const RenderSettings& rs, RenderCtx& cx, const ProgressFn& progress);

}  // namespace cw
