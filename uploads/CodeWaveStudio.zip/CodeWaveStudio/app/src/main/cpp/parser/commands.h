// The complete CodeWave scripting surface. A script can only ever call commands listed
// in this table - there is no other way to reach the engine.
#pragma once

#include <string>
#include <vector>

namespace cw {

enum class Op {
  SoundBegin, SoundEnd, LayerBegin, LayerEnd, RepeatBegin, RepeatEnd,
  OscSine, OscSquare, OscTriangle, OscSaw, OscPulse, OscNoise,
  NoiseWhite, NoisePink, NoiseBrown, VoiceHuman,
  FmModulate, FmRatio, VibratoAdd, SweepFrequency, SweepPitch, PitchQuantize,
  AmModulate, RingModulate,
  EnvAdsr, EnvExp, EnvLinear, EnvCustom,
  FilterLow, FilterHigh, FilterBand, FilterNotch,
  DistortionSoft, DistortionHard, DistortionFold, Saturation, Bitcrush,
  DelayEcho, ReverbRoom, TremoloAdd, ChorusAdd, CompressorAdd,
  VoiceFormant, VoiceVocoder, VoiceMetallic,
  SoundNormalize, SoundFade, SoundReverse, SoundPitch, SoundStretch, SoundGain, SoundPan
};

// Structure: begin/end blocks. Source: creates an oscillator/noise. Modifier: changes the
// preceding oscillator. Processor: transforms everything accumulated in the current layer.
enum class Cat { Structure, Source, Modifier, Processor };
enum class ParamKind { Num, Freq, Enum };

constexpr int kMaxParams = 10;

struct ParamSpec {
  const char* name;
  const char* alias;  // comma separated alternative names ("" = none)
  double def;
  double lo, hi;
  ParamKind kind;
  const char* enums;  // comma separated names for Enum params
  bool required;
};

struct CommandSpec {
  const char* ns;
  const char* name;
  Op op;
  Cat cat;
  std::vector<ParamSpec> params;
  bool variadic;    // extra numeric values allowed (envelope.custom)
  bool tonalOnly;   // modifier that needs a pitched oscillator
};

const std::vector<CommandSpec>& commandTable();
const CommandSpec* findCommand(const std::string& ns, const std::string& name);
std::vector<std::string> methodsOf(const std::string& ns);
std::vector<std::string> namespaceNames();
std::string usageOf(const CommandSpec& spec);
std::string lowerCopy(const std::string& s);
bool paramMatches(const ParamSpec& p, const std::string& lowerName);
// Index of `value` (case-insensitive) in a comma separated list, or -1.
int enumIndex(const char* list, const std::string& value);
std::vector<std::string> splitList(const char* list);
// "A4", "C#3", "Bb2" -> Hz. Returns false when the text is not a note name.
bool noteToHz(const std::string& text, double* hz);
std::string fmtNum(double v);

}  // namespace cw
