#include "commands.h"

#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <utility>

namespace cw {
namespace {

ParamSpec N(const char* name, double def, double lo, double hi, const char* alias = "") {
  return ParamSpec{name, alias, def, lo, hi, ParamKind::Num, nullptr, false};
}
ParamSpec F(const char* name, double def, const char* alias = "freq,frequency") {
  return ParamSpec{name, alias, def, 1.0, 20000.0, ParamKind::Freq, nullptr, false};
}
ParamSpec E(const char* name, double defIndex, const char* names) {
  return ParamSpec{name, "", defIndex, 0.0, 0.0, ParamKind::Enum, names, false};
}
ParamSpec R(ParamSpec p) {
  p.required = true;
  return p;
}

const char* kVowels = "a,e,i,o,u,uh";
const char* kVowelsTo = "same,a,e,i,o,u,uh";

std::vector<CommandSpec> build() {
  std::vector<CommandSpec> t;
  auto add = [&](const char* ns, const char* name, Op op, Cat cat, std::vector<ParamSpec> params,
                 bool variadic = false, bool tonalOnly = false) {
    t.push_back(CommandSpec{ns, name, op, cat, std::move(params), variadic, tonalOnly});
  };
  const ParamSpec vol = N("volume", 1.0, 0.0, 4.0, "vol,amplitude");

  // ---- structure
  add("sound", "begin", Op::SoundBegin, Cat::Structure, {N("duration", 0.0, 0.01, 30.0, "length,seconds"), N("seed", 1.0, 0.0, 1000000.0)});
  add("sound", "end", Op::SoundEnd, Cat::Structure, {});
  add("layer", "begin", Op::LayerBegin, Cat::Structure, {N("start", 0.0, 0.0, 30.0), N("length", 0.0, 0.0, 30.0)});
  add("layer", "end", Op::LayerEnd, Cat::Structure, {N("gain", 1.0, 0.0, 4.0, "volume"), N("pan", 0.0, -1.0, 1.0)});
  add("repeat", "begin", Op::RepeatBegin, Cat::Structure,
      {R(N("count", 1.0, 1.0, 128.0)), R(N("interval", 0.25, 0.005, 30.0)), N("length", 0.0, 0.0, 30.0),
       N("pitch_var", 0.0, 0.0, 24.0, "pitchvar"), N("gain_var", 0.0, 0.0, 1.0, "gainvar"), N("decay", 0.0, 0.0, 0.95)});
  add("repeat", "end", Op::RepeatEnd, Cat::Structure, {});

  // ---- sources
  add("oscillator", "sine", Op::OscSine, Cat::Source, {R(F("frequency", 440.0)), vol});
  add("oscillator", "square", Op::OscSquare, Cat::Source, {R(F("frequency", 440.0)), vol});
  add("oscillator", "triangle", Op::OscTriangle, Cat::Source, {R(F("frequency", 440.0)), vol});
  add("oscillator", "saw", Op::OscSaw, Cat::Source, {R(F("frequency", 440.0)), vol});
  add("oscillator", "pulse", Op::OscPulse, Cat::Source, {R(F("frequency", 440.0)), vol, N("width", 0.25, 0.02, 0.98)});
  add("oscillator", "noise", Op::OscNoise, Cat::Source, {vol});
  add("noise", "add", Op::NoiseWhite, Cat::Source, {vol});
  add("noise", "pink", Op::NoisePink, Cat::Source, {vol});
  add("noise", "brown", Op::NoiseBrown, Cat::Source, {vol});
  add("voice", "human", Op::VoiceHuman, Cat::Source,
      {F("pitch", 140.0), vol, E("vowel", 0, kVowels), E("to", 0, kVowelsTo), N("size", 1.0, 0.5, 2.0),
       N("breath", 0.05, 0.0, 1.0), N("vibrato", 0.2, 0.0, 2.0), N("jitter", 0.01, 0.0, 0.1), N("shimmer", 0.04, 0.0, 0.5)});

  // ---- modifiers of the preceding oscillator
  add("fm", "modulate", Op::FmModulate, Cat::Modifier, {R(N("frequency", 0.0, 0.01, 20000.0, "freq")), N("index", 2.0, 0.0, 50.0), N("to", -1.0, -1.0, 50.0)}, false, true);
  add("fm", "ratio", Op::FmRatio, Cat::Modifier, {R(N("ratio", 1.0, 0.01, 32.0)), N("index", 2.0, 0.0, 50.0), N("to", -1.0, -1.0, 50.0)}, false, true);
  add("vibrato", "add", Op::VibratoAdd, Cat::Modifier, {N("rate", 5.5, 0.1, 40.0), N("depth", 0.3, 0.0, 24.0)}, false, true);
  add("sweep", "frequency", Op::SweepFrequency, Cat::Modifier,
      {R(F("from", 440.0, "start")), R(F("to", 440.0, "end")), N("time", 0.0, 0.0, 30.0), N("curve", 1.0, 0.1, 8.0)}, false, true);
  add("sweep", "pitch", Op::SweepPitch, Cat::Modifier, {R(N("semitones", 0.0, -96.0, 96.0, "st")), N("time", 0.0, 0.0, 30.0), N("curve", 1.0, 0.1, 8.0)}, false, true);
  add("pitch", "quantize", Op::PitchQuantize, Cat::Modifier, {N("step", 1.0, 0.1, 12.0)}, false, true);

  // ---- processors (act on everything accumulated in the current layer)
  add("am", "modulate", Op::AmModulate, Cat::Processor, {R(N("frequency", 5.0, 0.01, 20000.0, "freq")), N("depth", 0.5, 0.0, 1.0)});
  add("ring", "modulate", Op::RingModulate, Cat::Processor, {R(N("frequency", 30.0, 0.01, 20000.0, "freq")), N("mix", 1.0, 0.0, 1.0)});
  add("envelope", "adsr", Op::EnvAdsr, Cat::Processor,
      {N("attack", 0.01, 0.0, 30.0), N("decay", 0.1, 0.0, 30.0), N("sustain", 0.7, 0.0, 1.0), N("release", 0.2, 0.0, 30.0), N("curve", 1.0, 0.2, 6.0)});
  add("envelope", "exp", Op::EnvExp, Cat::Processor, {N("decay", 0.3, 0.005, 30.0, "time"), N("attack", 0.002, 0.0, 5.0)});
  add("envelope", "linear", Op::EnvLinear, Cat::Processor, {N("decay", 0.3, 0.005, 30.0, "time"), N("attack", 0.002, 0.0, 5.0)});
  add("envelope", "custom", Op::EnvCustom, Cat::Processor, {}, true);

  const ParamSpec fcut = R(F("cutoff", 1000.0));
  add("filter", "lowpass", Op::FilterLow, Cat::Processor, {fcut, N("q", 0.707, 0.1, 30.0, "resonance"), N("to", 0.0, 0.0, 20000.0), N("time", 0.0, 0.0, 30.0), N("order", 1.0, 1.0, 4.0)});
  add("filter", "highpass", Op::FilterHigh, Cat::Processor, {fcut, N("q", 0.707, 0.1, 30.0, "resonance"), N("to", 0.0, 0.0, 20000.0), N("time", 0.0, 0.0, 30.0), N("order", 1.0, 1.0, 4.0)});
  add("filter", "bandpass", Op::FilterBand, Cat::Processor, {fcut, N("q", 1.0, 0.1, 30.0, "resonance"), N("to", 0.0, 0.0, 20000.0), N("time", 0.0, 0.0, 30.0), N("order", 1.0, 1.0, 4.0)});
  add("filter", "notch", Op::FilterNotch, Cat::Processor, {fcut, N("q", 2.0, 0.1, 30.0, "resonance"), N("to", 0.0, 0.0, 20000.0), N("time", 0.0, 0.0, 30.0), N("order", 1.0, 1.0, 4.0)});

  add("distortion", "amount", Op::DistortionSoft, Cat::Processor, {N("amount", 0.5, 0.0, 1.0), N("mix", 1.0, 0.0, 1.0)});
  add("distortion", "hard", Op::DistortionHard, Cat::Processor, {N("amount", 0.5, 0.0, 1.0)});
  add("distortion", "fold", Op::DistortionFold, Cat::Processor, {N("amount", 0.5, 0.0, 1.0)});
  add("saturation", "amount", Op::Saturation, Cat::Processor, {N("amount", 0.5, 0.0, 1.0)});
  add("bitcrush", "amount", Op::Bitcrush, Cat::Processor, {N("bits", 8.0, 1.0, 16.0), N("rate", 0.0, 0.0, 48000.0)});
  add("delay", "echo", Op::DelayEcho, Cat::Processor, {N("time", 0.25, 0.001, 2.0), N("feedback", 0.4, 0.0, 0.95), N("mix", 0.35, 0.0, 1.0)});
  add("reverb", "room", Op::ReverbRoom, Cat::Processor, {N("mix", 0.3, 0.0, 1.0), N("size", 0.5, 0.0, 1.0), N("damping", 0.5, 0.0, 1.0)});
  add("tremolo", "add", Op::TremoloAdd, Cat::Processor, {N("rate", 5.0, 0.05, 60.0), N("depth", 0.5, 0.0, 1.0), E("shape", 0, "sine,triangle,square,saw")});
  add("chorus", "add", Op::ChorusAdd, Cat::Processor, {N("rate", 0.8, 0.05, 10.0), N("depth", 0.5, 0.0, 1.0), N("mix", 0.5, 0.0, 1.0), N("voices", 2.0, 1.0, 4.0)});
  add("compressor", "add", Op::CompressorAdd, Cat::Processor,
      {N("threshold", -18.0, -60.0, 0.0), N("ratio", 4.0, 1.0, 20.0), N("attack", 0.005, 0.0001, 1.0), N("release", 0.1, 0.001, 5.0), N("makeup", 0.0, -12.0, 24.0)});

  add("voice", "formant", Op::VoiceFormant, Cat::Processor,
      {E("vowel", 0, kVowels), E("to", 0, kVowelsTo), N("sharpness", 1.0, 0.3, 3.0, "q"), N("mix", 1.0, 0.0, 1.0), N("size", 1.0, 0.5, 2.0)});
  add("voice", "vocoder", Op::VoiceVocoder, Cat::Processor, {N("bands", 16.0, 4.0, 32.0), F("pitch", 110.0), N("mix", 1.0, 0.0, 1.0), E("carrier", 0, "saw,pulse,noise")});
  add("voice", "metallic", Op::VoiceMetallic, Cat::Processor, {F("frequency", 220.0), N("amount", 0.5, 0.0, 1.0)});

  add("sound", "normalize", Op::SoundNormalize, Cat::Processor, {N("level", 0.9, 0.01, 1.0)});
  add("sound", "fade", Op::SoundFade, Cat::Processor, {N("in", 0.0, 0.0, 30.0), N("out", 0.0, 0.0, 30.0)});
  add("sound", "reverse", Op::SoundReverse, Cat::Processor, {});
  add("sound", "pitch", Op::SoundPitch, Cat::Processor, {R(N("semitones", 0.0, -24.0, 24.0, "st")), N("keep_time", 1.0, 0.0, 1.0, "keeptime")});
  add("sound", "stretch", Op::SoundStretch, Cat::Processor, {R(N("factor", 1.0, 0.25, 4.0))});
  add("sound", "gain", Op::SoundGain, Cat::Processor, {N("gain", 1.0, 0.0, 8.0, "volume")});
  add("sound", "pan", Op::SoundPan, Cat::Processor, {N("pan", 0.0, -1.0, 1.0)});
  return t;
}

struct AliasRow {
  const char *ans, *an, *ns, *n;
};
const AliasRow kAliases[] = {
    {"noise", "white", "noise", "add"},          {"reverb", "amount", "reverb", "room"},
    {"reverb", "add", "reverb", "room"},         {"delay", "add", "delay", "echo"},
    {"delay", "amount", "delay", "echo"},        {"tremolo", "amount", "tremolo", "add"},
    {"chorus", "amount", "chorus", "add"},       {"vibrato", "amount", "vibrato", "add"},
    {"compressor", "amount", "compressor", "add"}, {"saturation", "add", "saturation", "amount"},
    {"bitcrush", "add", "bitcrush", "amount"},   {"distortion", "add", "distortion", "amount"},
    {"distortion", "soft", "distortion", "amount"}, {"mix", "gain", "sound", "gain"},
    {"mix", "pan", "sound", "pan"},              {"sound", "volume", "sound", "gain"},
    {"fm", "add", "fm", "modulate"},             {"am", "add", "am", "modulate"},
    {"ring", "add", "ring", "modulate"},         {"envelope", "exponential", "envelope", "exp"},
    {"envelope", "decay", "envelope", "exp"},
};

}  // namespace

const std::vector<CommandSpec>& commandTable() {
  static const std::vector<CommandSpec> table = build();
  return table;
}

std::string lowerCopy(const std::string& s) {
  std::string r = s;
  for (char& c : r) c = (char)std::tolower((unsigned char)c);
  return r;
}

const CommandSpec* findCommand(const std::string& ns, const std::string& name) {
  const std::string n1 = lowerCopy(ns), n2 = lowerCopy(name);
  for (const CommandSpec& c : commandTable())
    if (n1 == c.ns && n2 == c.name) return &c;
  for (const AliasRow& a : kAliases) {
    if (n1 == a.ans && n2 == a.an) {
      for (const CommandSpec& c : commandTable())
        if (!std::strcmp(c.ns, a.ns) && !std::strcmp(c.name, a.n)) return &c;
    }
  }
  return nullptr;
}

std::vector<std::string> methodsOf(const std::string& ns) {
  const std::string n1 = lowerCopy(ns);
  std::vector<std::string> out;
  for (const CommandSpec& c : commandTable())
    if (n1 == c.ns) out.push_back(c.name);
  if (out.empty())
    for (const AliasRow& a : kAliases)
      if (n1 == a.ans) out.push_back(a.an);
  return out;
}

std::vector<std::string> namespaceNames() {
  std::vector<std::string> out;
  for (const CommandSpec& c : commandTable()) {
    bool seen = false;
    for (const std::string& s : out) seen = seen || s == c.ns;
    if (!seen) out.push_back(c.ns);
  }
  return out;
}

std::string fmtNum(double v) {
  char buf[32];
  std::snprintf(buf, sizeof(buf), "%g", v);
  return buf;
}

std::vector<std::string> splitList(const char* list) {
  std::vector<std::string> out;
  if (!list) return out;
  std::string cur;
  for (const char* p = list;; ++p) {
    if (*p == ',' || *p == 0) {
      if (!cur.empty()) out.push_back(cur);
      cur.clear();
      if (*p == 0) break;
    } else {
      cur += *p;
    }
  }
  return out;
}

int enumIndex(const char* list, const std::string& value) {
  const std::string v = lowerCopy(value);
  const std::vector<std::string> items = splitList(list);
  for (size_t i = 0; i < items.size(); ++i)
    if (items[i] == v) return (int)i;
  return -1;
}

bool paramMatches(const ParamSpec& p, const std::string& lowerName) {
  if (lowerName == p.name) return true;
  for (const std::string& a : splitList(p.alias))
    if (a == lowerName) return true;
  return false;
}

std::string usageOf(const CommandSpec& s) {
  std::string u = std::string(s.ns) + "." + s.name + "(";
  bool first = true;
  for (const ParamSpec& p : s.params) {
    if (!first) u += ", ";
    first = false;
    u += p.name;
    if (!p.required) {
      u += " = ";
      if (p.kind == ParamKind::Enum) {
        const std::vector<std::string> items = splitList(p.enums);
        u += (size_t)p.def < items.size() ? items[(size_t)p.def] : "?";
      } else if (p.def < p.lo) {
        u += "auto";  // default lies outside the valid range: a sentinel meaning "use the app default"
      } else if (p.def == -1.0 && p.lo == -1.0) {
        u += "same";
      } else {
        u += fmtNum(p.def);
      }
    }
  }
  if (s.variadic) u += "time, value, time, value, ...";
  return u + ")";
}

bool noteToHz(const std::string& text, double* hz) {
  if (text.size() < 2 || text.size() > 4) return false;
  static const int kSemis[7] = {9, 11, 0, 2, 4, 5, 7};  // A B C D E F G
  const char L = (char)std::toupper((unsigned char)text[0]);
  if (L < 'A' || L > 'G') return false;
  int semi = kSemis[L - 'A'];
  size_t i = 1;
  if (text[i] == '#') {
    ++semi;
    ++i;
  } else if (text[i] == 'b' || text[i] == 'B') {
    --semi;
    ++i;
  }
  if (i >= text.size()) return false;
  int oct = 0;
  for (; i < text.size(); ++i) {
    if (!std::isdigit((unsigned char)text[i])) return false;
    oct = oct * 10 + (text[i] - '0');
  }
  if (oct > 9) return false;
  const int midi = 12 * (oct + 1) + semi;
  *hz = 440.0 * std::pow(2.0, (midi - 69) / 12.0);
  return *hz >= 1.0 && *hz <= 20000.0;
}

}  // namespace cw
