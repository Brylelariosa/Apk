#pragma once

#include <string>
#include <vector>

#include "../dsp/common.h"
#include "commands.h"

namespace cw {

// One validated command: parameters are already bound, range-checked and converted
// (note names -> Hz, enum names -> index).
struct Command {
  const CommandSpec* spec = nullptr;
  Op op = Op::SoundEnd;
  int line = 0;
  int col = 0;
  double p[kMaxParams] = {};
  std::vector<double> extra;  // envelope.custom time/value pairs
  int match = -1;             // index of the matching begin/end for layer.* and repeat.*
};

struct Program {
  std::vector<Command> cmds;
};

struct ParseOptions {
  double defaultDuration = 2.0;
  double maxDuration = limits::kMaxDurationSec;
};

// Parses and fully validates a script. Throws EngineError (ErrorKind::Script) with a
// line number and a helpful hint; never executes anything.
Program parseScript(const std::string& text, const ParseOptions& opt);

}  // namespace cw
