#include "parser.h"

#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <map>
#include <utility>

namespace cw {
namespace {

enum class Tok { End, Ident, Number, String, Dot, LParen, RParen, Comma, Semi, Equals, Plus, Minus, Star, Slash };

struct Token {
  Tok t = Tok::End;
  std::string text;
  double num = 0.0;
  int line = 1;
  int col = 1;
};

[[noreturn]] void fail(int line, const std::string& msg, const std::string& hint = std::string()) {
  throw EngineError(ErrorKind::Script, line, msg, hint);
}

// Echo user text safely (ASCII only, truncated) so error messages are always valid UTF-8.
std::string safe(const std::string& s) {
  std::string r;
  for (size_t i = 0; i < s.size() && i < 40; ++i) {
    const unsigned char c = (unsigned char)s[i];
    r += (c >= 32 && c < 127) ? (char)c : '?';
  }
  if (s.size() > 40) r += "...";
  return r;
}

std::string listLines(const std::vector<std::string>& items) {
  std::string s;
  for (const std::string& i : items) {
    if (!s.empty()) s += "\n";
    s += i;
  }
  return s;
}

int editDistance(const std::string& a, const std::string& b) {
  std::vector<int> prev(b.size() + 1), cur(b.size() + 1);
  for (size_t j = 0; j <= b.size(); ++j) prev[j] = (int)j;
  for (size_t i = 1; i <= a.size(); ++i) {
    cur[0] = (int)i;
    for (size_t j = 1; j <= b.size(); ++j) {
      const int sub = prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1);
      cur[j] = std::min(std::min(prev[j] + 1, cur[j - 1] + 1), sub);
    }
    prev = cur;
  }
  return prev[b.size()];
}

std::string closest(const std::string& word, const std::vector<std::string>& options) {
  int best = 3;
  std::string res;
  const std::string w = lowerCopy(word);
  for (const std::string& o : options) {
    const int d = editDistance(w, o);
    if (d < best) {
      best = d;
      res = o;
    }
  }
  return res;
}

std::string describe(const Token& t) {
  switch (t.t) {
    case Tok::End: return "the end of the script";
    case Tok::Ident: return "'" + safe(t.text) + "'";
    case Tok::Number: return "the number " + safe(t.text);
    case Tok::String: return "a quoted string";
    case Tok::Dot: return "'.'";
    case Tok::LParen: return "'('";
    case Tok::RParen: return "')'";
    case Tok::Comma: return "','";
    case Tok::Semi: return "';'";
    case Tok::Equals: return "'='";
    case Tok::Plus: return "'+'";
    case Tok::Minus: return "'-'";
    case Tok::Star: return "'*'";
    case Tok::Slash: return "'/'";
  }
  return "?";
}

// ------------------------------------------------------------------- lexer
std::vector<Token> lex(const std::string& s) {
  std::vector<Token> out;
  size_t i = 0, lineStart = 0;
  int line = 1;
  while (i < s.size()) {
    const unsigned char c = (unsigned char)s[i];
    if (c == '\n') {
      ++line;
      ++i;
      lineStart = i;
      continue;
    }
    if (c == ' ' || c == '\t' || c == '\r') {
      ++i;
      continue;
    }
    if (c == '#' || (c == '/' && i + 1 < s.size() && s[i + 1] == '/')) {
      while (i < s.size() && s[i] != '\n') ++i;
      continue;
    }
    if (c == '/' && i + 1 < s.size() && s[i + 1] == '*') {
      const int startLine = line;
      size_t j = i + 2;
      bool closed = false;
      while (j + 1 < s.size()) {
        if (s[j] == '*' && s[j + 1] == '/') {
          closed = true;
          break;
        }
        if (s[j] == '\n') {
          ++line;
          lineStart = j + 1;
        }
        ++j;
      }
      if (!closed) fail(startLine, "Unterminated /* comment");
      i = j + 2;
      continue;
    }
    Token t;
    t.line = line;
    t.col = (int)(i - lineStart) + 1;
    if (std::isalpha(c) || c == '_') {
      size_t j = i;
      while (j < s.size() && (std::isalnum((unsigned char)s[j]) || s[j] == '_')) ++j;
      // Sharp note names such as C#4.
      if (j < s.size() && s[j] == '#' && j - i == 1 && std::strchr("ABCDEFGabcdefg", s[i]) && j + 1 < s.size() &&
          std::isdigit((unsigned char)s[j + 1])) {
        ++j;
        while (j < s.size() && std::isdigit((unsigned char)s[j])) ++j;
      }
      t.t = Tok::Ident;
      t.text = s.substr(i, j - i);
      i = j;
    } else if (std::isdigit(c) || (c == '.' && i + 1 < s.size() && std::isdigit((unsigned char)s[i + 1]))) {
      size_t j = i;
      while (j < s.size() && std::isdigit((unsigned char)s[j])) ++j;
      if (j < s.size() && s[j] == '.') {
        ++j;
        while (j < s.size() && std::isdigit((unsigned char)s[j])) ++j;
      }
      if (j < s.size() && (s[j] == 'e' || s[j] == 'E')) {
        size_t k = j + 1;
        if (k < s.size() && (s[k] == '+' || s[k] == '-')) ++k;
        if (k < s.size() && std::isdigit((unsigned char)s[k])) {
          while (k < s.size() && std::isdigit((unsigned char)s[k])) ++k;
          j = k;
        }
      }
      t.t = Tok::Number;
      t.text = s.substr(i, j - i);
      t.num = std::strtod(t.text.c_str(), nullptr);
      if (j < s.size() && std::isalpha((unsigned char)s[j])) {
        fail(line, "Unexpected text right after the number " + t.text,
             "Use plain numbers: seconds for time, Hz for frequency (for example 0.5 or 440).");
      }
      i = j;
    } else if (c == '"' || c == '\'') {
      size_t j = i + 1;
      while (j < s.size() && s[j] != (char)c && s[j] != '\n') ++j;
      if (j >= s.size() || s[j] != (char)c) fail(line, "Unterminated string");
      t.t = Tok::String;
      t.text = s.substr(i + 1, j - i - 1);
      i = j + 1;
    } else {
      switch (c) {
        case '.': t.t = Tok::Dot; break;
        case '(': t.t = Tok::LParen; break;
        case ')': t.t = Tok::RParen; break;
        case ',': t.t = Tok::Comma; break;
        case ';': t.t = Tok::Semi; break;
        case '=': t.t = Tok::Equals; break;
        case '+': t.t = Tok::Plus; break;
        case '-': t.t = Tok::Minus; break;
        case '*': t.t = Tok::Star; break;
        case '/': t.t = Tok::Slash; break;
        default:
          if (c >= 128) fail(line, "Unexpected non-ASCII character", "Scripts must use plain ASCII outside of comments.");
          fail(line, std::string("Unexpected character '") + (char)(c >= 32 ? c : '?') + "'");
      }
      ++i;
    }
    out.push_back(t);
  }
  Token end;
  end.t = Tok::End;
  end.line = line;
  out.push_back(end);
  return out;
}

// ------------------------------------------------------------------ parser
struct Value {
  bool isNum = true;
  double num = 0.0;
  std::string sym;
  int line = 0;
};

struct RawArg {
  bool named = false;
  std::string name;
  Value v;
  int line = 0;
};

class Parser {
 public:
  Parser(std::vector<Token> toks, const ParseOptions& opt) : t_(std::move(toks)), opt_(opt) {}

  Program run() {
    while (cur().t != Tok::End) statement();
    validate();
    return std::move(prog_);
  }

 private:
  const Token& cur() const { return t_[i_]; }
  const Token& peek() const { return t_[std::min(i_ + 1, t_.size() - 1)]; }

  void expect(Tok k, const char* what) {
    if (cur().t != k) {
      fail(cur().line, std::string("Expected ") + what + " but found " + describe(cur()),
           cur().t == Tok::End ? "Is a closing ')' or ';' missing?" : "");
    }
    ++i_;
  }

  // ---- expressions
  void needNum(const Value& v, int line) {
    if (!v.isNum) fail(line, "'" + safe(v.sym) + "' is not a number", "Unknown name. Define it first with:  let name = 1.5;");
  }
  Value expr() {
    Value v = term();
    while (cur().t == Tok::Plus || cur().t == Tok::Minus) {
      const Tok op = cur().t;
      const int ln = cur().line;
      ++i_;
      Value r = term();
      needNum(v, ln);
      needNum(r, ln);
      v.num = op == Tok::Plus ? v.num + r.num : v.num - r.num;
    }
    return v;
  }
  Value term() {
    Value v = unary();
    while (cur().t == Tok::Star || cur().t == Tok::Slash) {
      const Tok op = cur().t;
      const int ln = cur().line;
      ++i_;
      Value r = unary();
      needNum(v, ln);
      needNum(r, ln);
      if (op == Tok::Slash && r.num == 0.0) fail(ln, "Division by zero");
      v.num = op == Tok::Star ? v.num * r.num : v.num / r.num;
    }
    return v;
  }
  Value unary() {
    if (cur().t == Tok::Minus) {
      const int ln = cur().line;
      ++i_;
      Value v = unary();
      needNum(v, ln);
      v.num = -v.num;
      return v;
    }
    if (cur().t == Tok::Plus) {
      ++i_;
      return unary();
    }
    return primary();
  }
  Value primary() {
    const Token t = cur();
    Value v;
    v.line = t.line;
    if (t.t == Tok::Number) {
      ++i_;
      v.num = t.num;
      return v;
    }
    if (t.t == Tok::String) {
      ++i_;
      v.isNum = false;
      v.sym = t.text;
      return v;
    }
    if (t.t == Tok::LParen) {
      ++i_;
      v = expr();
      expect(Tok::RParen, "')'");
      return v;
    }
    if (t.t == Tok::Ident) {
      ++i_;
      const std::string low = lowerCopy(t.text);
      auto it = vars_.find(low);
      if (it != vars_.end()) {
        v.num = it->second;
      } else if (low == "pi") {
        v.num = kPi;
      } else if (low == "tau") {
        v.num = kTwoPi;
      } else {
        v.isNum = false;
        v.sym = t.text;
      }
      return v;
    }
    fail(t.line, "Expected a value but found " + describe(t));
  }

  // ---- statements
  void statement() {
    const Token first = cur();
    if (first.t == Tok::Semi) {
      ++i_;
      return;
    }
    if (first.t != Tok::Ident) {
      fail(first.line, "Expected a command such as oscillator.sine(440, 0.8); but found " + describe(first));
    }
    if (lowerCopy(first.text) == "let") {
      ++i_;
      const Token name = cur();
      expect(Tok::Ident, "a variable name");
      expect(Tok::Equals, "'='");
      Value v = expr();
      needNum(v, name.line);
      vars_[lowerCopy(name.text)] = v.num;
      if (cur().t == Tok::Semi) ++i_;
      return;
    }
    ++i_;
    if (cur().t != Tok::Dot) {
      std::string hint = "Commands look like group.method(...);  for example oscillator.sine(440, 0.8);";
      const std::string near = closest(first.text, namespaceNames());
      if (!near.empty()) hint += "\nDid you mean '" + near + "'?";
      fail(first.line, "Unknown command: " + safe(first.text), hint);
    }
    ++i_;
    const Token m = cur();
    expect(Tok::Ident, "a command name after '.'");
    const CommandSpec* spec = findCommand(first.text, m.text);
    if (!spec) unknownCommand(first, m);
    std::vector<RawArg> args = arguments();
    Command c;
    c.spec = spec;
    c.op = spec->op;
    c.line = first.line;
    c.col = first.col;
    bind(spec, args, c);
    if (cur().t == Tok::Semi) ++i_;
    prog_.cmds.push_back(std::move(c));
    if ((int)prog_.cmds.size() > limits::kMaxCommands) {
      fail(first.line, "The script has too many commands (maximum " + std::to_string(limits::kMaxCommands) + ")");
    }
  }

  [[noreturn]] void unknownCommand(const Token& ns, const Token& method) {
    const std::vector<std::string> methods = methodsOf(ns.text);
    const std::string name = safe(ns.text) + "." + safe(method.text);
    if (methods.empty()) {
      std::string hint = "Expected one of these command groups:\n" + listLines(namespaceNames());
      const std::string near = closest(ns.text, namespaceNames());
      if (!near.empty()) hint = "Did you mean '" + near + "'?\n\n" + hint;
      fail(ns.line, "Unknown command: " + name, hint);
    }
    std::string hint = "Expected:\n" + listLines(methods);
    const std::string near = closest(method.text, methods);
    if (!near.empty()) hint = "Did you mean " + lowerCopy(ns.text) + "." + near + "?\n\n" + hint;
    fail(ns.line, "Unknown command: " + name, hint);
  }

  std::vector<RawArg> arguments() {
    std::vector<RawArg> args;
    expect(Tok::LParen, "'('");
    if (cur().t == Tok::RParen) {
      ++i_;
      return args;
    }
    for (;;) {
      RawArg a;
      a.line = cur().line;
      if (cur().t == Tok::Ident && peek().t == Tok::Equals) {
        a.named = true;
        a.name = lowerCopy(cur().text);
        i_ += 2;
      }
      a.v = expr();
      args.push_back(std::move(a));
      if (args.size() > 40) fail(cur().line, "Too many values in one command");
      if (cur().t == Tok::Comma) {
        ++i_;
        if (cur().t == Tok::RParen) {
          ++i_;
          break;
        }
        continue;
      }
      if (cur().t == Tok::RParen) {
        ++i_;
        break;
      }
      const bool missingComma = cur().t == Tok::Ident || cur().t == Tok::Number;
      fail(cur().line, "Expected ',' or ')' but found " + describe(cur()),
           missingComma ? "Is a comma missing between two values?" : (cur().t == Tok::End ? "Is a closing ')' missing?" : ""));
    }
    return args;
  }

  // ---- binding
  static std::string cmdName(const CommandSpec* s) { return std::string(s->ns) + "." + s->name; }

  void assign(const CommandSpec* spec, size_t idx, const Value& val, int line, Command& c, bool* given) {
    const ParamSpec& ps = spec->params[idx];
    double v = 0.0;
    const std::string usage = "Usage: " + usageOf(*spec);
    switch (ps.kind) {
      case ParamKind::Num:
        if (!val.isNum) {
          fail(line, "'" + std::string(ps.name) + "' in " + cmdName(spec) + " must be a number, got '" + safe(val.sym) + "'", usage);
        }
        v = val.num;
        break;
      case ParamKind::Freq:
        if (val.isNum) {
          v = val.num;
        } else if (!noteToHz(val.sym, &v)) {
          fail(line, "'" + safe(val.sym) + "' is not a frequency", "Use a number in Hz (440) or a note name (A4, C#3, Bb2).\n" + usage);
        }
        break;
      case ParamKind::Enum: {
        int e = -1;
        const std::vector<std::string> items = splitList(ps.enums);
        if (!val.isNum) {
          e = enumIndex(ps.enums, val.sym);
        } else if (val.num >= 0 && val.num < (double)items.size() && val.num == std::floor(val.num)) {
          e = (int)val.num;
        }
        if (e < 0) fail(line, "Invalid value '" + (val.isNum ? fmtNum(val.num) : safe(val.sym)) + "' for '" + ps.name + "'", "Expected:\n" + listLines(items));
        v = e;
        break;
      }
    }
    if (!std::isfinite(v)) fail(line, "Invalid number for '" + std::string(ps.name) + "'");
    if (ps.kind != ParamKind::Enum && (v < ps.lo || v > ps.hi)) {
      std::string msg;
      if (v < 0.0 && ps.lo >= 0.0) {
        msg = "'" + std::string(ps.name) + "' cannot be negative (got " + fmtNum(v) + ")";
      } else if (std::strcmp(ps.name, "duration") == 0) {
        msg = "Duration " + fmtNum(v) + " s is outside the allowed range of " + fmtNum(ps.lo) + " to " + fmtNum(ps.hi) + " seconds";
      } else {
        msg = "'" + std::string(ps.name) + "' must be between " + fmtNum(ps.lo) + " and " + fmtNum(ps.hi) + " (got " + fmtNum(v) + ")";
      }
      fail(line, msg, usage);
    }
    c.p[idx] = v;
    given[idx] = true;
  }

  void bind(const CommandSpec* spec, const std::vector<RawArg>& args, Command& c) {
    const size_t np = spec->params.size();
    bool given[kMaxParams] = {};
    for (size_t k = 0; k < np; ++k) c.p[k] = spec->params[k].def;
    size_t pos = 0;
    bool sawNamed = false;
    const std::string usage = "Usage: " + usageOf(*spec);
    for (const RawArg& a : args) {
      if (!a.named) {
        if (sawNamed) fail(a.line, "Positional value after a named value in " + cmdName(spec), "Put plain values first, then name = value pairs.\n" + usage);
        if (pos < np) {
          assign(spec, pos, a.v, a.line, c, given);
          ++pos;
        } else if (spec->variadic) {
          if (!a.v.isNum) fail(a.line, cmdName(spec) + " only accepts numbers", usage);
          c.extra.push_back(a.v.num);
        } else {
          fail(a.line, cmdName(spec) + " takes at most " + std::to_string(np) + " value(s)", usage);
        }
      } else {
        sawNamed = true;
        int idx = -1;
        for (size_t k = 0; k < np; ++k)
          if (paramMatches(spec->params[k], a.name)) idx = (int)k;
        if (idx < 0) {
          std::string names;
          for (const ParamSpec& p : spec->params) names += (names.empty() ? "" : ", ") + std::string(p.name);
          fail(a.line, "Unknown parameter '" + safe(a.name) + "' for " + cmdName(spec), names.empty() ? usage : "Valid parameters: " + names + "\n" + usage);
        }
        if (given[idx]) fail(a.line, "Parameter '" + std::string(spec->params[(size_t)idx].name) + "' was given twice", usage);
        assign(spec, (size_t)idx, a.v, a.line, c, given);
      }
    }
    for (size_t k = 0; k < np; ++k) {
      if (spec->params[k].required && !given[k]) {
        fail(c.line, "Missing parameter '" + std::string(spec->params[k].name) + "' for " + cmdName(spec), usage);
      }
    }
    if (c.op == Op::SoundBegin && !given[0]) {
      c.p[0] = clampd(opt_.defaultDuration, limits::kMinDurationSec, opt_.maxDuration);
    }
    if (c.op == Op::SoundBegin && c.p[0] > opt_.maxDuration) {
      fail(c.line, "Duration " + fmtNum(c.p[0]) + " s is too long (maximum " + fmtNum(opt_.maxDuration) + " s)", usage);
    }
    if (c.op == Op::EnvCustom) {
      if (c.extra.size() < 2 || c.extra.size() % 2 != 0 || c.extra.size() > 32) {
        fail(c.line, "envelope.custom needs 1 to 16 pairs of (time, value)", usage);
      }
      for (size_t k = 0; k < c.extra.size(); k += 2) {
        if (c.extra[k] < 0 || c.extra[k] > 30) fail(c.line, "envelope.custom time must be 0..30 seconds (got " + fmtNum(c.extra[k]) + ")", usage);
        if (k >= 2 && c.extra[k] < c.extra[k - 2]) fail(c.line, "envelope.custom times must be in increasing order", usage);
        if (c.extra[k + 1] < 0 || c.extra[k + 1] > 4) fail(c.line, "envelope.custom value must be 0..4 (got " + fmtNum(c.extra[k + 1]) + ")", usage);
      }
    }
    if (c.op == Op::SweepFrequency && (c.p[0] <= 0.0 || c.p[1] <= 0.0)) fail(c.line, "sweep.frequency needs positive frequencies", usage);
  }

  // ---- structure validation (runs before any audio is rendered)
  static bool tonalSource(Op op) {
    return op == Op::OscSine || op == Op::OscSquare || op == Op::OscTriangle || op == Op::OscSaw ||
           op == Op::OscPulse || op == Op::VoiceHuman;
  }

  void validate() {
    std::vector<Command>& cmds = prog_.cmds;
    if (cmds.empty()) {
      fail(0, "The script is empty.", "Start with:\nsound.begin(1.0);\noscillator.sine(440, 0.8);\nsound.end();");
    }
    if (cmds.front().op != Op::SoundBegin) {
      fail(cmds.front().line, "The script must start with sound.begin(duration);", "Example:\nsound.begin(1.5);");
    }
    if (cmds.back().op != Op::SoundEnd) {
      fail(cmds.back().line, "The script must finish with sound.end();", "Add  sound.end();  as the last command.");
    }
    struct Frame {
      bool repeat;
      size_t beginIdx;
      bool pending;
      bool pendingTonal;
      int sources;
      int processors;
      long mult;
    };
    std::vector<Frame> st;
    st.push_back(Frame{false, 0, false, false, 0, 0, 1});
    long instances = 0, sourcesTotal = 0;
    for (size_t k = 0; k < cmds.size(); ++k) {
      Command& c = cmds[k];
      Frame& top = st.back();
      switch (c.spec->cat) {
        case Cat::Structure:
          if (c.op == Op::SoundBegin) {
            if (k != 0) fail(c.line, "Only one sound.begin() is allowed per script", "Use layer.begin(...) / layer.end() to build a sound from several layers.");
          } else if (c.op == Op::SoundEnd) {
            if (k + 1 != cmds.size()) fail(c.line, "sound.end() must be the last command");
            if (st.size() != 1) {
              const Frame& open = st.back();
              fail(cmds[open.beginIdx].line, std::string(open.repeat ? "repeat.begin" : "layer.begin") + " is never closed",
                   std::string("Add ") + (open.repeat ? "repeat.end();" : "layer.end();") + " before sound.end();");
            }
          } else if (c.op == Op::LayerBegin || c.op == Op::RepeatBegin) {
            const bool rep = c.op == Op::RepeatBegin;
            top.pending = false;
            if ((int)st.size() > limits::kMaxLayerDepth) fail(c.line, "Layers are nested too deeply (maximum " + std::to_string(limits::kMaxLayerDepth) + ")");
            const long mult = top.mult * (rep ? (long)c.p[0] : 1L);
            instances += mult;
            if (instances > limits::kMaxLayerInstances) fail(c.line, "Too many layer/repeat instances (maximum " + std::to_string(limits::kMaxLayerInstances) + ")", "Reduce repeat counts.");
            st.push_back(Frame{rep, k, false, false, 0, 0, mult});
          } else {  // LayerEnd / RepeatEnd
            const bool rep = c.op == Op::RepeatEnd;
            if (st.size() == 1 || st.back().repeat != rep) {
              fail(c.line, std::string(rep ? "repeat.end" : "layer.end") + " has no matching " + (rep ? "repeat.begin" : "layer.begin"));
            }
            const size_t b = st.back().beginIdx;
            cmds[b].match = (int)k;
            c.match = (int)b;
            st.pop_back();
          }
          break;
        case Cat::Source:
          if (top.sources + 1 > limits::kMaxPendingSources) fail(c.line, "Too many oscillators in one layer (maximum " + std::to_string(limits::kMaxPendingSources) + ")", "Put some of them in separate layers.");
          sourcesTotal += top.mult;
          if (sourcesTotal > limits::kMaxSourcesTotal) fail(c.line, "The script creates too many oscillators in total", "Reduce repeat counts.");
          top.pending = true;
          top.pendingTonal = tonalSource(c.op);
          top.sources++;
          break;
        case Cat::Modifier:
          if (!top.pending) {
            fail(c.line, cmdName(c.spec) + " must come directly after an oscillator",
                 "It modifies the oscillator written just before it, e.g.\noscillator.saw(90, 0.7);\n" + cmdName(c.spec) + "(...);");
          }
          if (c.spec->tonalOnly && !top.pendingTonal) {
            fail(c.line, cmdName(c.spec) + " needs a pitched oscillator, not noise", "Use sine, square, triangle, saw, pulse or voice.human.");
          }
          break;
        case Cat::Processor:
          top.pending = false;
          if (++top.processors > limits::kMaxProcessorsPerLayer) fail(c.line, "Too many processing commands in one layer (maximum " + std::to_string(limits::kMaxProcessorsPerLayer) + ")");
          break;
      }
    }
  }

  std::vector<Token> t_;
  size_t i_ = 0;
  ParseOptions opt_;
  std::map<std::string, double> vars_;
  Program prog_;
};

}  // namespace

Program parseScript(const std::string& text, const ParseOptions& opt) {
  if (text.size() > limits::kMaxScriptBytes) {
    fail(0, "The script is too large (" + std::to_string(text.size() / 1024) + " KB, maximum " + std::to_string(limits::kMaxScriptBytes / 1024) + " KB)");
  }
  bool blank = true;
  for (char ch : text) blank = blank && std::isspace((unsigned char)ch);
  if (blank) {
    fail(0, "The script is empty.", "Start with:\nsound.begin(1.0);\noscillator.sine(440, 0.8);\nsound.end();");
  }
  Parser p(lex(text), opt);
  return p.run();
}

}  // namespace cw
